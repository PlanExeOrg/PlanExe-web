
## Documents to Create

### 1. Project Charter

**ID:** f3e65f03-cdad-4509-9821-db131b2c05f8

**Description:** Formal document authorizing the project, defining high-level scope, objectives (SMART criteria reviewed), strategic constraints ($90M budget, NZ location), key governance structure (CSEO/Legal focus), and linking to the chosen 'Builder's Foundation' strategy. Primary audience: Executive Sponsors/Approving Authorities.

**Responsible Role Type:** Chief Strategy & Ethics Officer (CSEO)

**Primary Template:** PMI Project Charter Template

**Secondary Template:** High-Risk Venture Governance Framework

**Steps:**

- Incorporate final strategic decisions (Donor Pairing, Lease location) from strategic review.
- Define high-level budget allocation ($54M pre-revenue allocation confirmed).
- Secure formal mandate to engage regulatory counsel for HTA/MCNZ review.
- Obtain Executive Sponsor approval based on risk profile documented in SWOT.

**Approval Authorities:** Executive Project Sponsors

### 2. Critical Regulatory Compliance Strategy & HTA Risk Mitigation Plan

**ID:** 7913706b-1b23-4eee-9f83-87e6e0ac95a2

**Description:** A dedicated strategic document addressing the fundamental legal risks identified by the Regulatory Specialist regarding the Human Tissue Act 2008 (HTA) and MCNZ procedural requirements. This plan outlines the legally defensible tissue acquisition pathway (replacing the compensated model) and the procedural governance plan required by MCNZ for novel surgery.

**Responsible Role Type:** Legal Counsel & Contract Architect (NZ Focus)

**Primary Template:** Regulatory Compliance Mapping Document

**Secondary Template:** Risk Response Plan (Regulatory Focus)

**Steps:**

- Conduct emergency review of HTA 2008 constraints on non-therapeutic tissue use.
- Draft and submit preliminary protocol documentation to MCNZ for surgical procedure review.
- Define the *strictly altruistic* tissue sourcing protocol that satisfies local HDEC criteria.
- Obtain initial sign-off from Regulatory/Legal Liaison on HTA compliance viability.

**Approval Authorities:** Chief Strategy & Ethics Officer (CSEO)

### 3. Revised LTV and Cost-to-Serve Financial Model

**ID:** 391495f9-9a0d-45bf-a49c-852439a6bdb5

**Description:** A financial model that recalculates the Lifetime Value (LTV) and the required 'Maintenance Fee' based on the true, risk-adjusted cost of long-term immunosuppression management (Decision 10) and the 18-month psycho-social overhead (Decision 8). This document addresses the regulatory specialist's finding of financial insolvency in the original 'low fee' structure.

**Responsible Role Type:** Subscription Finance & Compliance Manager

**Primary Template:** Actuarial Pricing Model for Medical Services

**Secondary Template:** Burn Rate Sensitivity Analysis

**Steps:**

- Calculate projected 5-year cost of immunosuppression management utilizing Dr. Kellar's protocol estimates.
- Define the minimum viable monthly maintenance fee necessary to cover operational burn + risk buffer.
- Recalculate LTV based on the new fee structure and sensitivity analysis results.
- Present revised fee structure recommendation to Executive Sponsors.

**Approval Authorities:** Chief Strategy & Ethics Officer (CSEO), Executive Sponsors

### 4. Facility Technical Requirements and Retrofit Specification (Layer-4 CapEx Blueprint)

**ID:** 9aa6064a-4f41-4541-89a4-5968982420a5

**Description:** Detailed engineering specifications derived from the Facility Design Engineer's expected input, outlining the precise utility loads, security partitioning, HVAC requirements, and space allocation needed to support Layer-4 Biosecurity standards and advanced laboratory functions within the selected Auckland lease. This informs the final lease negotiation.

**Responsible Role Type:** Facility & Bio-Security Operations Director

**Primary Template:** High-Security Medical Facility Design Specification

**Secondary Template:** MEP Load Calculation Sheet

**Steps:**

- Finalize minimum verifiable square footage/utility load requirements for Layer-4 and Cryo-storage.
- Incorporate mandates for dedicated, redundant power systems for critical labs/cryo.
- Produce engineering drawings showing partitioning layers to meet anonymity requirements (Decision 11).
- Obtain internal sign-off from Lead Surgeon regarding guaranteed 20-day uptime accessibility vs. security.

**Approval Authorities:** Chief Strategy & Ethics Officer (CSEO), Lead Transplantation Surgeon & Protocol Architect

### 5. Remote Biometric Monitoring Proof-of-Concept (PoC) & Compliance Fallback Plan

**ID:** 6f0da407-2855-41d6-9194-07296d30e921

**Description:** A technical strategy document detailing the testing protocol for the remote compliance system (Assumption Issue 2). It must include compliance mapping against the NZ Privacy Act 2020 and define the immediate, legally actionable, time-based billing trigger that replaces the biometric function if validation fails or regulatory uncertainty arises.

**Responsible Role Type:** Technology & Data Integrity Lead

**Primary Template:** Technology Proof of Concept (PoC) Validation Report

**Secondary Template:** Digital Health Regulatory Compliance Gap Analysis

**Steps:**

- Complete technical validation plan for the remote monitoring hardware/software.
- Secure Legal Counsel sign-off on the contractual fallback billing mechanism (milestone-based).
- Conduct initial security audit simulation against NZ Privacy Act requirements.
- Determine threshold criteria for declaring the biometric trigger 'unreliable' for contractual purposes.

**Approval Authorities:** Subscription Finance & Compliance Manager, Legal Counsel & Contract Architect (NZ Focus)

### 6. Stakeholder Communication & External Relations Charter

**ID:** 2f0311fb-8cbe-4bf8-8d9d-87834a432c3e

**Description:** A foundational PR charter (as recommended in 'Omissions') outlining proactive communication strategies for media management, community engagement, and managing the sensitive disclosure related to donor families, designed to preempt ethical backlash (Risks 4, 7). It will define controlled messaging around medical necessity vs. elective status.

**Responsible Role Type:** Chief Strategy & Ethics Officer (CSEO)

**Primary Template:** High-Stakes Public Relations Strategy Template

**Secondary Template:** Crisis Communication Flowchart

**Steps:**

- Define key messages mitigating 'status surgery' perception.
- Establish the framework for controlled testimonial capture from Patient Journey Specialist.
- Map out mandatory disclosure points for HDEC/MCNZ that will be made public.
- Select/retain an external specialist PR firm for crisis management modeling.

**Approval Authorities:** Executive Project Sponsors

### 7. Staffing Model Restructuring Proposal (Fixed Cost Reduction)

**ID:** 633f22bc-8804-4942-afc9-6e17063ffe02

**Description:** A formal proposal detailing the revised staffing structure intended to reduce fixed salary overhead from the core three surgeons/support staff (Decision 7) by introducing more flexible, performance-contingent contracts or equity components, mitigating financial risk identified by the Business Model Architect.

**Responsible Role Type:** Chief Strategy & Ethics Officer (CSEO)

**Primary Template:** HR Strategy Alignment Document

**Secondary Template:** Compensation Structure Proposal Template

**Steps:**

- Benchmark competitive rates for specialist surgeons using alternative models (consultant/equity mix).
- Draft initial revision of the proposed 5-year surgeon contracts to reduce guaranteed base salary.
- Calculate the impact of the revised staffing model on the 12-month OpEx runway.
- Present revised proposal for approval alongside the Revised LTV Model.

**Approval Authorities:** Executive Project Sponsors

## Documents to Find

### 1. New Zealand Human Tissue Act 2008 Legislation Text

**ID:** 877aee27-60e4-45b0-9004-4bc9541f9523

**Description:** The primary legal document governing the donation, use, and storage of human tissue in New Zealand. Crucial for legally defining the Tissue Acquisition Protocol and ensuring the non-monetary benefit structure (Decision 4) is compliant.

**Recency Requirement:** Current legislation, including all amendments.

**Responsible Role Type:** Legal Counsel & Contract Architect (NZ Focus)

**Access Difficulty:** Easy

**Steps:**

- Search New Zealand Legislation website (Legislation.govt.nz).
- Obtain certified copy via Ministry of Health portal.
- Cross-reference with HDEC and MCNZ guidance documents.

### 2. New Zealand Health and Disability Ethics Committee (HDEC) Application Guidelines for Novel Procedures

**ID:** 67f57d5b-ee2b-4da2-a30e-aa4398ef2f78

**Description:** Official guidance documents detailing the procedural, documentation, and scientific rigor required by the local Auckland HDEC for approving experimental, high-risk, non-life-saving human procedures. Essential input for the Regulatory Compliance Strategy.

**Recency Requirement:** Most current published guidelines.

**Responsible Role Type:** Chief Strategy & Ethics Officer (CSEO)

**Access Difficulty:** Medium

**Steps:**

- Search official HDEC portal for current procedural manuals.
- Obtain internal checklists utilized by the outsourced International Ethics Review Consortium for alignment.
- Request specific procedural guidance from Auckland HDEC administration regarding previous transplantation case reviews.

### 3. NZ Health Practitioners Competence Assurance Act 2003 (HPCAA) Standards

**ID:** 13a48082-7ca1-4ab1-bc48-755a6958528b

**Description:** Legislation defining competence standards for medical practitioners in NZ. Crucial for understanding the requirements the Lead Surgeon and team must meet to gain MCNZ approval for performing experimental facial transplantation procedures.

**Recency Requirement:** Current official version.

**Responsible Role Type:** Legal Counsel & Contract Architect (NZ Focus)

**Access Difficulty:** Easy

**Steps:**

- Search New Zealand Legislation portal for HPCAA.
- Consult with MCNZ for any specific supplementary guidelines related to high-risk elective surgery.

### 4. Data on Global Long-Term Immunosuppression and Rejection Cost Metrics for Allografts

**ID:** 249d1c2b-9261-45f5-bf3e-2c9d1c3ad4f6

**Description:** De-identified statistical data or published literature outlining the projected cost trajectory (pharmacy/hospitalization) associated with managing immunosuppression regimens in transplant patients over a 3-5 year horizon, needed to accurately price the maintenance fee (Revised LTV Model).

**Recency Requirement:** Published within the last 5 years.

**Responsible Role Type:** Lead Transplantation Surgeon & Protocol Architect

**Access Difficulty:** Medium

**Steps:**

- Search academic databases (PubMed, Scopus) using terms like 'Allograft Cost of Care Longitudinal Study' and 'Transplant Pharmacoeconomics'.
- Review published literature from major centers like NYU or international immunology journals.
- Inquire via formal channels with the Mayo Clinic contact regarding their cost modeling.

### 5. NZ Privacy Act 2020 Full Text and Associated Regulatory Guidance (Health Data)

**ID:** c079caa1-4584-4ea1-ace3-f6e2a93849a7

**Description:** The complete data privacy legislation required for securing the locally hosted EHR and validating the remote biometric monitoring system against local security and encryption standards mandated for health information.

**Recency Requirement:** Current, including any recent regulatory interpretations or amendments.

**Responsible Role Type:** Technology & Data Integrity Lead

**Access Difficulty:** Easy

**Steps:**

- Search the official New Zealand legislation website.
- Obtain specific guidance documents from the Office of the Privacy Commissioner relating to biometric and real-time health data.
- Cross-reference with Health Sector specific data handling guidelines.

### 6. Auckland Commercial Rental Market Data: Specialized Surgical/Medical Retrofit Spaces

**ID:** ca95940a-b063-4f69-840c-aa3ad25e4888

**Description:** Current commercial leasing data for specialized medical facilities in Auckland, focusing on available square footage conducive to high-security retrofitting, utility capacity (power load for cryo/labs), and average long-term lease costs (10+ years). Essential for validating the Facility Blueprint against the lease negotiation strategy.

**Recency Requirement:** Last 6 months of market transactional data.

**Responsible Role Type:** Facility & Bio-Security Operations Director

**Access Difficulty:** Medium

**Steps:**

- Engage commercial real estate brokers specializing in New Zealand medical/high-security properties.
- Analyze public datasets for commercial property listings matching required square footage and utility needs.
- Search for historical data on lease rates for retrofitted surgical theaters in major NZ medical precincts.