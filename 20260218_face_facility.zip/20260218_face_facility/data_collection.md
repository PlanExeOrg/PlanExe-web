## 1. Tissue Acquisition Protocol Legal Viability & Cost Re-assessment

This data is critical because the current tissue acquisition strategy (Decision 4) risks immediate regulatory shutdown under NZ law, and the revenue model (Decision 3) is financially insolvent given the projected high ongoing biological costs. This addresses the most severe fatal flaws identified by experts.

### Data to Collect

- Precise constraints under the New Zealand Human Tissue Act 2008 regarding non-therapeutic tissue use.
- Legal defensibility (risk score) of providing 'non-financial restorative benefits' (Decision 4) versus cash compensation.
- Revised actuarial cost model to fully cover 5 years of post-transplant immunosuppression and late-stage intervention for maximal compatibility matches.
- Minimum required recurring monthly maintenance fee based on revised cost model (to replace 'low monthly maintenance fee').

### Simulation Steps

- Legal modeling software (e.g., LexisNexis/Westlaw with NZ jurisdiction filters) to cross-reference Decision 4 strategies against HTA 2008 statutes.
- Financial modeling in Excel/VBA to run Monte Carlo simulations on LTV based on the cost of long-term, high-complexity immunosuppression, updating Decision 3 fee structure.

### Expert Validation Steps

- Consult the Healthcare Regulatory Specialist (NZ) regarding HTA 2008 compliance for Decision 4.
- Consult the Transplant Immunologist to validate the long-term cost input for late-stage rejection management into the recurrence fee model.
- Consult the Subscription Business Model Architect to assess the commercial viability of the revised mandatory recurring fee.

### Responsible Parties

- Chief Strategy & Ethics Officer (CSEO)
- Legal Counsel & Contract Architect (NZ Focus)
- Subscription Finance & Compliance Manager

### Assumptions

- **High:** A legally viable non-compensated tissue sourcing protocol can be established using altruistic pathways that satisfies both HTA 2008 and the need for high-volume, specific facial tissue.
- **High:** The cost of long-term immunosuppression management for maximal compatibility matches can be accurately modeled over a minimum 5-year period.

### SMART Validation Objective

By 2026-09-15, secure written confirmation from NZ regulatory counsel confirming a legally compliant, non-compensated Tissue Acquisition Protocol (Decision 4) and finalize a revised recurring monthly fee structure that models a minimum 40% operating margin over projected 5-year LTV, validated against MCNZ procedural guidelines.

### Notes

- Focus must shift entirely to altruistic/deceased donor pathways acceptable under HTA 2008.
- The 'low' maintenance fee is definitively invalidated by expert review and must be corrected immediately.


## 2. Regulatory Pathway Certification for Novel Procedure & Monitoring Tech

Regulatory approval (Risk 1, Issue 1.6) is an existential dependency. Specifically, the MCNZ sanctioning of the *procedure* and the biometric technology is necessary to legally operate and to trigger revenue.

### Data to Collect

- Specific MCNZ requirements for surgeon credentialing related to experimental facial transplantation (Decision 1/7).
- Classification, pathway, and timeline for securing approval for the proprietary remote biometric monitoring system (as a medical device/diagnostic tool).
- Detailed documentation package required by NZ HDEC to validate the outsourced International Ethics Review Consortium's findings.

### Simulation Steps

- Timeline simulation charting the MCNZ credentialing process against the 18-month operational readiness target, assuming standard review times.
- Regulatory mapping software to track submission status between Legal Counsel, CSEO, and the International Ethics Consortium against regulatory milestones.

### Expert Validation Steps

- Consult the Healthcare Regulatory Specialist (NZ) regarding MCNZ procedural requirements and HDEC submission mapping.
- Consult the Digital Health Compliance Auditor to assess the regulatory classification risk of the biometric RPM system.
- Consult the Legal Counsel (NZ Focus) to integrate MCNZ requirements into the operational readiness checklist.

### Responsible Parties

- Chief Strategy & Ethics Officer (CSEO)
- Legal Counsel & Contract Architect (NZ Focus)
- Technology & Data Integrity Lead

### Assumptions

- **High:** The surgeon team (Dr. Kellar et al.) possesses sufficient antecedent CV data to meet MCNZ requirements for performing novel procedures under the supervision of an outsourced ethics board.
- **High:** The proprietary remote monitoring technology can be classified and approved by NZ authorities (Medsafe/other) within 12 months.

### SMART Validation Objective

Within 12 months (by 2027-06-10), secure provisional MCNZ accreditation sign-off for the core surgical team's protocol and define the regulatory submission path (including risk classification) for the remote biometric monitoring system, evidenced by formal meeting minutes with relevant NZ bodies.

### Notes

- Regulatory gap identified: The plan underrepresented MCNZ burden relative to HDEC.
- If biometric approval is delayed past M12, the fallback billing mechanism (milestone payments) must be contractualized immediately.


## 3. Facility Physical Readiness & Uptime Confirmation

Facility readiness dictates surgical capacity (which drives revenue) and security compliance (which manages ethical risk). Conflict between security infrastructure needs and guaranteed surgical days fundamentally undermines operational planning.

### Data to Collect

- Finalized technical specifications for Layer-4 Biosecurity hardening required in the Auckland leasehold.
- Guaranteed minimum dedicated surgical day allotments (must confirm 20 days/month) factoring in utility allocation conflicts (cryo storage vs. OR function).
- Cost and feasibility report for retrofitting the top 3 lease candidates against the $36M CapEx budget, specifically quantifying utility load accommodation for Decision 14.

### Simulation Steps

- MEP (Mechanical, Electrical, Plumbing) simulation using CAD/BIM software comparing the load profile of Layer-4 cryo-storage against the capacity of the proposed retrofit sites.
- Schedule simulation in project management software, modeling operational slack when only 15 surgical days/month are available (Risk mitigation failure). Costing the impact of lost T1 revenue.

### Expert Validation Steps

- Consult the Biomedical Facility Design Engineer (via search/industry contact) to validate Layer-4 retrofit requirements against the proposed Auckland sites.
- Consult the Facility & Bio-Security Operations Director (Tāne) to verify lease negotiation success regarding guaranteed 20-day uptime.

### Responsible Parties

- Facility & Bio-Security Operations Director
- Lead Transplantation Surgeon & Protocol Architect

### Assumptions

- **Medium:** The necessary specialized equipment (microscopy, robotics, cryo-storage) specified by the Surgeon Architect can be procured within the $36M CapEx allocation.
- **High:** The chosen Auckland venue allows for the necessary 15% power surge (estimated) required for continuous Level 4 cryo-storage without violating lease terms or requiring disproportionate CapEx upgrades.

### SMART Validation Objective

By 2026-09-01, secure and architecturally approve the lease for the Auckland facility (Decision 2) demonstrating technical feasibility for 20 surgical days per month alongside validated support for Layer-4 biosecurity infrastructure within 85% of the dedicated CapEx budget for fit-out.

### Notes

- This must resolve the security partitioning tension identified by the review team (Issue 3).


## 4. Staffing Model Cost/Retention Analysis

Staffing (Risk 5) is the primary driver of the high fixed monthly burn rate ($1.5M OpEx). The model must ensure the proposed high salaries/long contracts are cost-justified by revenue stability and retention metrics.

### Data to Collect

- Detailed compensation packages for the three core surgeons, breaking down fixed salary vs. performance bonus targets (knowledge transfer, complication rate adherence).
- Cost analysis of implementing the recommended Knowledge Transfer performance bonuses (per Team Reviewer recommendation).
- Projected cost impact of switching 20% of specialist support roles to tiered contractor relationships to reduce fixed OpEx exposure.

### Simulation Steps

- Financial modeling to determine the required monthly surgical throughput necessary to fund the high fixed salary costs ($1.5M OpEx projection) under three scenarios: (1) Baseline 2 procedures/month, (2) 3 procedures/month, (3) Compliance failure (1.5 procedures/month).
- Contract modeling comparing FTE vs. Independent Contractor structures for non-core roles (e.g., Patient Journey Specialist overlap) to quantify fixed cost reduction.

### Expert Validation Steps

- Consult the Healthcare Compensation Strategist (via search/industry contact) to benchmark the proposed 5-year surgeon contracts and knowledge retention structure.
- Consult the Subscription Finance Manager to integrate staffing costs directly into the M18 break-even analysis.

### Responsible Parties

- Subscription Finance & Compliance Manager
- Lead Transplantation Surgeon & Protocol Architect
- Chief Strategy & Ethics Officer (CSEO)

### Assumptions

- **Medium:** The specialized labor market in NZ/Global allows recruitment of three surgeons meeting Dr. Kellar's standard, even with the fixed 5-year contract structure.
- **Medium:** Performance bonuses focused on knowledge transfer and complication rates are sufficient retention levers, offsetting high financial commitment risk.

### SMART Validation Objective

By 2026-09-30, finalize the Staffing Plan that demonstrates fixed salary costs can be reduced by 10% via optimized contracting (Contractor vs. FTE ratio), or confirm that the required patient volume to cover the current $1.5M OpEx budget is achievable by M+10 post-launch.

### Notes

- Reviewer highlighted the need to move towards greater staffing flexibility where possible.

## Summary

The project plan is structurally sound based on the 'Builder's Foundation' but contains critical, potentially fatal flaws in regulatory compliance and financial structure, as highlighted by expert review. Immediate action must prioritize validating the legal basis for tissue sourcing (Data Collection 1) and correcting the revenue model to account for true long-term biological liabilities (Data Collection 1). Concurrently, securing operational footing requires confirming facility readiness against security mandates and guaranteeing surgical uptime (Data Collection 3) and cost-justifying the high fixed staffing model (Data Collection 4).

### Immediate Actionable Tasks:
1. **Legal & Financial Restructure:** Task the CSEO and Finance Manager to halt all non-compliant tissue discussions and immediately calculate the revised, risk-adjusted **Minimum Sustainable Recurring Fee** based on a 5-year immunosuppression liability model. (Data Collection 1 Priority).
2. **Regulatory Roadmap Lock:** Instruct the Legal Counsel to initiate an emergency deep-dive review on the NZ Human Tissue Act 2008 compliance for the chosen tissue protocol and simultaneously map the MCNZ pathway, targeting the M+9 MOU goal. (Data Collection 2 Priority).
3. **Facility Verification:** The Facility Director must lock down lease options based on technical feasibility for Layer-4 security retrofitting without exceeding 85% of the dedicated CapEx budget ceiling. (Data Collection 3 Priority).