A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The compliance status of recipients, judged via proprietary remote biometric monitoring, will be legally and technically unassailable as a trigger for the recurring monthly subscription fee. | Initiate immediate, parallel Proof-of-Concept (PoC) testing on the remote biometric system with an external Digital Health Compliance Auditor to map classification risk against MedSafe/NZ Privacy Act 2020 standards. | Regulatory body (Medsafe/HDEC) mandates a significant redesign of the biometric data collection/encryption protocols, or the PoC demonstrates an unacceptably high (>= 5%) rate of false negatives/inability to securely transmit data. |
| A2 | The non-financial restorative benefits offered to donor families can legally and practically satisfy the requirements of the New Zealand Human Tissue Act 2008 for procuring facial tissue for elective procedures. | Instruct Legal Counsel (Alistair Finch) and the CSEO to secure written MCNZ/HDEC confirmation that the specific non-financial benefits package is legally equivalent to 'altruistic donation' pathways for non-life-saving tissue. | NZ Regulatory Counsel issues a definitive warning (equivalent to Expert 1.4.D Consequence) that the proposed compensation structure is either illegal under the HTA 2008 or will result in immediate suspension of tissue procurement activities upon regulator review. |
| A3 | The fixed operational costs ($1.5M/month burn rate projected against high fixed salaries and facility lease) are appropriately covered by the initial steep fee augmented by the planned 'low monthly maintenance fee' ($X) over the minimum 3-year commitment. | Task the Subscription Finance Manager to conduct a gap analysis, recalculating the required 'low' fee based on the true projected 5-year cost of chronic immunosuppression management (Expert 1.5 analysis), and stress-test the LTV model against an 18-month patient onboarding delay. | Recalculated sustainable mandatory monthly fee is greater than a 50% increase over the initially planned 'low maintenance fee,' OR the mandated 18-month runway is insufficient to cover the burn rate if the fee structure is not immediately altered. |
| A4 | The specialized, high-security surgical and laboratory equipment procured under the initial $36M CapEx allocation (Decision 13) will arrive on schedule and integrate seamlessly with the retrofitted Auckland facility's existing utility infrastructure load capacity. | Conduct a mandatory, integrated site visit with the Biomedical Facility Design Engineer and Equipment Vendor representatives to verify the physical dimensions and actual utility requirements (power/HVAC/plumbing load) of all long-lead equipment against the signed capacity limits of the top-tier Auckland lease option. | The integrated load from specialized cryo/lab equipment exceeds the confirmed available utility capacity by 10%, requiring an unplanned $3M+ facility upgrade (consuming contingency budget) or forcing a 90-day delay in installation/commissioning timeline. |
| A5 | Recipient Post-Operative Reintegration Support (Decision 8) provides tangible, measurable benefit that successfully drives the 18-month psychological acceptance review outcome, justifying its inclusion in the base subscription fee. | Immediately launch a structured pilot test involving 5 mock recipients to rigorously apply the 18-month reintegration curriculum, measuring standardized identity stabilization scores (pre-defined metric) and comparing against a control group receiving only physical aftercare. | The pilot test shows no statistically significant difference (p>0.05) in identity stabilization scores between the supported group and the control group, rendering the 18-month expensive support program a material, unrecoverable OpEx drain. |
| A6 | The decision to structure the recurring fee as a 'low monthly maintenance fee' (Decision 3) is sufficient to cover the 5-year projected need for complex, late-stage intervention (rejection management/toxicity mitigation) associated with maximal compatibility transplants (Decision 1). | Task the Transplant Immunologist and Finance Manager to co-author a new actuarial model projecting the total cost of care for a Level 3 rejection event occurring in Year 3, compared directly against 36 months of the contracted low monthly fee income for that single patient. | The actuarial model concludes that the cost of managing one Level 3 rejection event exceeds 12 months of the contracted 'low monthly maintenance fee' income, making the financial exposure uninsurable through the current structure. |
| A7 | The core team's operational structure, which relies heavily on assigning cross-functional oversight to specialist contractors (e.g., Legal Counsel, Compensation Strategist) who are not Full-Time Employees, will maintain cohesive, timely execution against aggressive deadlines (M+9, M+12, M+18). | The CSEO must mandate a 'Contractor Synchronization Crucible,' requiring all 4 key external contractors (Legal, Compensation, PR Firm, Digital Auditor) to meet weekly for 8 consecutive weeks, tracking dependencies and cross-contractual deliverable completion rates using a shared project dashboard. | The cross-contractual dependency tracking reveals a critical deliverable missed by one contractor due to lack of organizational control, resulting in a cascading delay of >30 days for a subsequent deliverable owned by a different contractor or FTE. |
| A8 | The decision to prioritize maximal compatibility matching (Decision 1) instead of relying solely on the ultra-conservative sibling-only pairing (rejected path) will not result in an unacceptable long-term increase in total graft rejection/toxicity requiring intervention costs that dwarf the contribution margin of the low monthly maintenance fee. | The Lead Transplantation Surgeon must submit a preliminary 12-month projection for allograft tissue viability under the current maximal match protocol, classifying expected patient outcomes into three tiers: (1) Stable, (2) Managed Complication (Low Cost), (3) Severe Rejection (High Cost), with quantified associated probability weighting derived from NYU Langone precedent data. | The weighted probability of necessary intervention in Tier 3 (High Cost) exceeds 15% across the first 6 enrolled patients, suggesting the long-term liability cost profile invalidates the 'low monthly maintenance fee' structure. |
| A9 | The specialized expertise required to staff the proprietary local EHR/Cryo-Inventory/RPM integration (Decision 8, Assumption Q8) can be recruited and retained within the $18M OpEx runway, even with the high financial pressure exerted by the fixed high salaries for the core surgical team. | The Technology & Data Integrity Lead must secure signed, non-contingent employment agreements (including salary band justification) for the two most critical unhired FTE support roles: the Remote Monitoring Technician and the Security Analyst, securing them before M+6. | The average salary required to secure the two critical technical FTEs exceeds the budget allocated for them in the financial plan by 20%, or recruitment outreach yields zero qualified candidates willing to sign 5-year contracts within the budgeted band. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Ethical Procurement Freeze: Insolvency from Legal Tissue Blockage | Process/Financial | A2 | Chief Strategy & Ethics Officer (CSEO) | CRITICAL (20/25) |
| FM2 | The Compliance Chokehold: Digital Revenue Failure Post-Discharge | Technical/Logistical | A1 | Technology & Data Integrity Lead | CRITICAL (25/25) |
| FM3 | The Fixed-Cost Burnout: Talent Exodus Under Undersupported Mandate | Market/Human | A3 | Lead Transplantation Surgeon & Protocol Architect | CRITICAL (15/25) |
| FM4 | Utility Gridlock: Critical Equipment Starves the Operating Table | Technical/Logistical | A4 | Facility & Bio-Security Operations Director | CRITICAL (16/25) |
| FM5 | The Rejection Deficit: Low Maintenance Fee Bankrupts Long-Term Care | Process/Financial | A6 | Subscription Finance & Compliance Manager | CRITICAL (20/25) |
| FM6 | The Hollow Support Service: Wasted OpEx on Ineffective Reintegration | Market/Human | A5 | Patient Journey & Reintegration Specialist | HIGH (12/25) |
| FM7 | The Contractor Cascade: Synchronization Failure Cripples Regulatory Timeline | Process/Financial | A7 | Chief Strategy & Ethics Officer (CSEO) | CRITICAL (16/25) |
| FM8 | The Tolerance Overdraw: Maximal Match Toxicity Breaks LTV Promise | Technical/Logistical | A8 | Lead Transplantation Surgeon & Protocol Architect | CRITICAL (15/25) |
| FM9 | The Specialist Vacuum: Tech Team Collapse Under Fixed Salary Burden | Market/Human | A9 | Technology & Data Integrity Lead | HIGH (12/25) |


### Failure Modes

#### FM1 - The Ethical Procurement Freeze: Insolvency from Legal Tissue Blockage

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: Chief Strategy & Ethics Officer (CSEO)
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project commits to a non-compensated, restorative benefit sourcing strategy (Decision 4). This strategy is predicated on the assumption (A2) that it is legally viable under the strict NZ Human Tissue Act 2008 for elective procedures. Expert analysis strongly indicates this approach is either non-compliant or highly defensible but insufficient for scaling volume required for viability. Failure to secure a compliant, high-volume tissue pipeline means the surgical schedule stagnates immediately following the procurement contracts being enacted. With high fixed operating costs ($1.5M/month burn rate for staff/lease already contracted for 12-18 months), the project exhausts its $18M OpEx runway without generating the necessary initial revenue, leading to insolvency and staff redundancy before the first cohort matures.

##### Early Warning Signs
- NZ Regulatory Counsel issues a revised liability risk score of 4/5 or higher on the Tissue Acquisition Protocol within 90 days.
- Lead Transplantation Surgeon reports tissue pipeline is generating < 1 viable match per quarter across the first two quarters.
- Biological Supply Chain Coordinator misses the M+9 deadline for activating secondary tissue sourcing MoUs.

##### Tripwires
- Legal confirmation (HTA) of non-altruistic tissue pathway viability is not secured by M+9.
- Tissue inventory sustains fewer than 1 surgical slot per month by M+15.

##### Response Playbook
- Contain: Immediately pause all payments related to donor family relationship managers and halt all tissue procurement initiation contracts.
- Assess: CSEO and Legal Counsel generate a rapid pivot plan to utilize only established, deceased-donor 'pass-through' pathways, quantifying the expected 30-day delay per unit for scheduling.
- Respond: Freeze all CapEx spending not directly related to regulatory compliance remediation, and initiate emergency bridge-funding talks to cover 9 further months of fixed OpEx before pivot revenue stabilizes.


**STOP RULE:** Failure to secure a legally compliant, scalable tissue sourcing mechanism by the M+12 mark, irrespective of HDEC approval status.

---

#### FM2 - The Compliance Chokehold: Digital Revenue Failure Post-Discharge

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A1
- **Owner**: Technology & Data Integrity Lead
- **Risk Level:** CRITICAL 25/25 (Likelihood 5/5 × Impact 5/5)

##### Failure Story
The Project’s recurring revenue is structurally dependent on the Subscription Finance Manager (Davies) triggering monthly billing based on remote biometric confirmation of immunosuppressant adherence (Decision 3, Assumption A1). If the proprietary technology fails regulatory scrutiny (NZ Privacy Act/Medsafe classification) or technical stability standards (unreliable data transmission), the validation needed for billing fails. Logistically, this translates into an inability to validate patient adherence for the contractually required compliance window, preventing the project from commencing the crucial 3-year LTV clock for any discharged patient. This creates a cascading cash flow catastrophe where fixed costs continue to accrue against zero qualified recurring revenue, exhausting the $18M runway far faster than anticipated.

##### Early Warning Signs
- Technology Lead reports the remote monitoring system fails to achieve >99.5% data integrity consistency during internal stress tests.
- Digital Health Compliance Auditor issues a formal finding that the system requires classification as a complex medical device, projecting >12 months for full regulatory approval.
- Subscription Finance Manager reports that initial contract finalization is stalled because the contract architect cannot lock the payment trigger clause due to regulatory uncertainty.

##### Tripwires
- Regulatory classification pathway for the biometric monitoring system is not formally defined by M+9.
- The technology fails to successfully validate 90% of adherence data points across two test cohorts prior to Day 1 of patient discharge.

##### Response Playbook
- Contain: Immediately halt all patient onboarding schedules predicated on the biometric trigger being active, reverting to a milestone-payment structure for any newly signed patient.
- Assess: Technology Lead and Finance Manager must quantify the exact cost and timeline required to implement the contractual fallback billing mechanism (milestone payment logic) and assess its impact on LTV (Expert 2.4.C).
- Respond: If the fallback mechanism reduces LTV by >15%, CSEO initiates emergency negotiations to extend surgeon contracts from 5 years to 7 years, banking on future revenue to offset short-term losses.


**STOP RULE:** If the remote biometric monitoring system is deemed fundamentally unapprovable by NZ authorities within 15 months, indicating permanent failure of the core revenue trigger mechanism.

---

#### FM3 - The Fixed-Cost Burnout: Talent Exodus Under Undersupported Mandate

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Lead Transplantation Surgeon & Protocol Architect
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
This failure results from the mismatch identified in Assumption A3: high fixed costs derived from 5-year guaranteed surgeon contracts and a premium Auckland lease colliding with an 'too-low' recurring maintenance fee. Expert review indicated the low fee is fundamentally insufficient to cover long-term biological liabilities AND sustained high fixed overhead. The human consequence crystallizes when the clinical team (Dr. Kellar and 2 other surgeons) recognizes that the low monthly revenue cannot sustain the required resources (staffing, lab overhead, high-complexity protocol adherence) needed for the 'maximal compatibility' matches. Facing potential budget cuts or resource starvation for complex care, the core talent, secured on rigid contracts, opts for early exit (e.g., through contractual buyouts or performance disputes), prioritizing risk management over the project’s flawed financial structure. This causes a total halt in surgical capacity.

##### Early Warning Signs
- Lead Surgeon requests unscheduled meeting with CSEO and HR regarding resource allocation adequacy for post-transplant maintenance (Decision 10).
- Subscription Finance Manager reports that the monthly recurring revenue (MRR) is less than 70% of the fixed $1.5M OpEx cost for two consecutive months post-launch.
- HR verifies that 25% of the non-surgeon FTE support staff requested reassignment to flexible contractor status to avoid liability exposure.

##### Tripwires
- The average realized revenue per patient per month falls below 80% of the minimum sustainable threshold defined by the latest LTV model.
- Any core surgeon initiates contract review or termination clause discussion prior to Month 30.

##### Response Playbook
- Contain: Immediately invoke knowledge transfer bonus clauses retroactively for the entire surgical team to signal financial investment in retention, regardless of current revenue.
- Assess: CSEO, Surgeon, and Finance Manager conduct a 48-hour review to identify non-critical fixed costs (e.g., facility upgrades deferred) that can be temporarily cut to bridge the OpEx gap by $250k/month.
- Respond: If a surgeon exits, activate the contingency plan to immediately execute the knowledge transfer bonus on the remaining surgeons while placing an immediate hiring freeze company-wide, prioritizing liquidity over maintaining the 2-3 procedure/month baseline.


**STOP RULE:** If two or more of the three contracted core surgeons formally resign or violate performance metrics within the first 36 months, leading to irreversible loss of core procedural competency.

---

#### FM4 - Utility Gridlock: Critical Equipment Starves the Operating Table

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A4
- **Owner**: Facility & Bio-Security Operations Director
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project assumed that the specialized, high-load surgical and cryopreservation equipment could integrate into the utility infrastructure of the selected leased Auckland facility without major structural overruns. Assumption A4 proves false when the specialized cryo-storage units (Decision 14) and advanced laboratory equipment (Decision 10) are installed, drawing 15% more power than the building's verified capacity. This forces a negotiation deadlock with the landlord or requires an immediate CapEx reallocation of $3M+ to upgrade the municipal service connection and internal distribution within the leased space. This unexpected CapEx forces the project to cannibalize the operational runway contingency fund ($10M reserve) just for setup, leaving zero financial buffer for immediate post-launch risks (e.g., regulatory delays or initial low case volume). The subsequent delay in commissioning the lab equipment also prevents the testing of proprietary immunosuppressants, creating an immediate procedural bottleneck.

##### Early Warning Signs
- Biomedical Facility Design Engineer issues a formal 'Red Flag' during the final site walk-through regarding HVAC/electrical load partitioning.
- Equipment vendor quotes exceed the allocated utility upgrade contingency by 20% before construction formally starts.
- The 20-day surgical uptime guarantee (Decision 14) cannot be verified by the facility director due to utility brown-outs during parallel equipment testing.

##### Tripwires
- Unplanned CapEx exceeding $2M for facility utility hardening logged during the fit-out phase.
- Projected equipment installation schedule slips by >45 days due to utility service upgrade lead times.

##### Response Playbook
- Contain: Immediately halt all non-essential equipment installation, focusing resources solely on maintaining the OR and essential cold-chain storage for existing tissue.
- Assess: Task the Lead Surgeon and Surgeon Protocol Architect to re-sequence the initial 6-month surgical schedule, prioritizing procedures that require minimal lab-based pre-testing.
- Respond: CSEO initiates a formal request to draw $2.5M from the $10M contingency fund, reallocating it to 'Critical Infrastructure Remediation,' thereby forfeiting the financial buffer for other foreseen risks.


**STOP RULE:** If utility upgrade negotiations threaten to delay the facility commissioning readiness sign-off past the M+18 operational launch date.

---

#### FM5 - The Rejection Deficit: Low Maintenance Fee Bankrupts Long-Term Care

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A6
- **Owner**: Subscription Finance & Compliance Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Assumption A6 proves fatal: the low monthly maintenance fee, designed to enhance subscription uptake, fails to cover the true, high cost of ongoing management for patients receiving maximal compatibility tissue. The actuarial model reveals that a single Level 3 acute rejection episode in Year 3 costs $550k in specialized pharmacy, lab work, and nursing triage, while the patient has only contributed $48k (36 months x $1,333/month fee) toward post-graft care. When the first such event occurs 20 months in, the associated 2x surge in required services immediately drains the operational buffer intended for regulatory delays, forcing the project into a state of under-funding patient care to satisfy immediate OpEx requirements elsewhere. This forces the CSEO to either declare bankruptcy due to inadequate reserves or legally abandon patients to public health systems, destroying post-subscription revenue goals (Decision 15) and reputation.

##### Early Warning Signs
- Lead Surgeon reports that the cost center for post-graft intervention pharmacy orders has exceeded 150% of the allocated budget for two consecutive months.
- Subscription Finance Manager confirms the LTV model is now insolvent under the expected complication rate (based on Decision 1 choice).
- The primary insurance/funding source (if established) rejects coverage for the specific intervention on grounds of 'experimental protocol deviation.'

##### Tripwires
- Total operational spend dedicated to intervention for the first 5 patients exceeds 200% of the budgeted allocation for that cohort.
- The average monthly fee collected is less than 3x the average monthly cost of care for the entire active patient base.

##### Response Playbook
- Contain: Immediately freeze all new patient enrollment until the fee structure is unilaterally renegotiated by contract addendum with all active patients, pushing liability back onto the recipient.
- Assess: Finance/Legal team model the financial impact of converting the low monthly fee into a high-deductible co-pay structure for all acute care events occurring after Month 18.
- Respond: CSEO publicly announces a temporary 'Paused Intake' while the project recalibrates its financial covenant to ensure clinical quality is not compromised by revenue shortfall.


**STOP RULE:** If the total cost of acute care interventions for Year 2 exceeds 20% of the total collected subscription revenue for that year.

---

#### FM6 - The Hollow Support Service: Wasted OpEx on Ineffective Reintegration

- **Archetype**: Market/Human
- **Root Cause**: Assumption A5
- **Owner**: Patient Journey & Reintegration Specialist
- **Risk Level:** HIGH 12/25 (Likelihood 4/5 × Impact 3/5)

##### Failure Story
Assumption A5 dictates that the 18-month mandatory psycho-social reintegration program (Decision 8) provides measurable value in driving patient acceptance, which in turn validates the subscription continuity criteria. The pilot test reveals this assumption is false: the expensive, resource-intensive program (staffing Patient Journey Specialist, dedicated consulting time) shows no statistically significant impact on the primary outcome metric (identity stabilization score) compared to minimal or elective support groups. This failure means the high fixed cost associated with the Patient Journey Specialist FTE (plus contractor support) is pure, unrecoverable OpEx drain throughout the entire 18-month period for every patient enrolled. This unnecessary $1.5M+ annual drag on the burn rate, combined with other financial pressures, accelerates insolvency by approximately 6 months, causing the project to require *additional* bridge funding far earlier than anticipated, putting immense pressure on the Executive team to secure capital based on a demonstrably inefficient operational expenditure.

##### Early Warning Signs
- Pilot study analysis shows the P-value for the reintegration support vs. physical recovery control group exceeds 0.10.
- Patient Journey & Reintegration Specialist reports that 50% of curriculum time is spent managing logistical complaints rather than core identity transition support.
- The Patient Journey Specialist role begins actively lobbying for a reduction in their mandatory 18-month program scope.

##### Tripwires
- Pilot program results confirm reintegration support drives <10% improvement in standardized acceptance score post-90 days.
- The operational burn rate increases by $100k/month due to unreimbursed specialist staffing costs associated with the program.

##### Response Playbook
- Contain: Immediately place the Patient Journey Specialist role on a hiring freeze and reduce all curriculum delivery hours by 50%, shifting focus only to necessary 90-day compliance check-ins.
- Assess: CSEO and Lead Surgeon quantify the exact staff hours/cost associated with the 18-month program vs. the actual administrative load for the 90-day trigger, isolating the true wasted OpEx.
- Respond: Reallocate the salary savings identified to extend the runway for the technology team working on the biometric PoC (if A1 is still in progress), viewing the personnel saved as a short-term lifeline for the revenue-critical technology team.


**STOP RULE:** If two consecutive quarters post-launch show that the costs associated with the 18-month support program are not correlated with improved patient compliance rates (>90%) above the baseline established by the 90-day trigger.

---

#### FM7 - The Contractor Cascade: Synchronization Failure Cripples Regulatory Timeline

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Chief Strategy & Ethics Officer (CSEO)
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project heavily relies on external, specialized contractors (Legal, Compensation, Auditing) for mission-critical, time-bound achievements, notably securing the M+9 MOU with HDEC and finalizing the compliant biometric submission. Assumption A7 proves false when the inherent loss of granular control over distributed, independent contractor workflows leads to failure in dependency management. For example, the Legal Counsel fails to provide liability sign-off on the biometric integration *before* the Digital Health Compliance Auditor needed to finalize the MCNZ submission package. This 45-day delay in regulatory submission forces the project past a critical internal management milestone, immediately triggering a contractual penalty clause in the Auckland lease requiring a $500k payment for failing to meet the 'readiness' timeline, which drains contingency funds intended for unforeseen clinical costs. The financial shock, caused by process breakdown, erodes investor confidence in executive control.

##### Early Warning Signs
- CSEO reports that two or more critical contractual milestones owned by external contractors were missed in the same reporting period in Q1 post-planning.
- Key contractor utilization reports show less than 50% active alignment/collaboration time with internal FTEs during cross-functional synchronization meetings.
- Dependency tracking tool flags a critical sequential task delay that traces back directly to an external contractor's non-delivery.

##### Tripwires
- Total accumulated schedule slippage attributed to contractor dependencies exceeds 60 calendar days by M+9 timeline.

##### Response Playbook
- Contain: Immediately suspend all outgoing payments to the single contractor identified as the critical path blocker, reallocating their remaining contracted scope for emergency review by an internal FTE (via temporary budget reallocation).
- Assess: CSEO leads a triage effort to identify the next three dependent milestones, prioritizing those linked to the HDEC submission, and assigns an internal FTE as a temporary 'Contract Liaison' to manage the remaining contractors back on schedule.
- Respond: Freeze all new engagement with *future* external contractors until the immediate synchronization failure is resolved and a new, mandatory weekly reporting structure is imposed on all existing external partners.


**STOP RULE:** If the required M+9 HDEC MOU milestone is missed due to reliance on external contractor dependency failure.

---

#### FM8 - The Tolerance Overdraw: Maximal Match Toxicity Breaks LTV Promise

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Lead Transplantation Surgeon & Protocol Architect
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Assumption A8 proves false when the clinical reality of maximal compatibility matching demonstrates a higher rate of severe, resource-intensive rejection events than projected in the conservative model. The first significant rejection occurs in Month 22 (Tier 3 event), requiring specialized, multi-drug sequencing and extended hospitalization not covered by the 'low monthly maintenance fee.' This single event costs $600k in unbudgeted intervention. Because the LTV model was based on this low fee covering all long-term risks, the project now faces a structural deficit. The Lead Surgeon must inform the CSEO that the protocol choice is either clinically unsustainable under the current fee model or mandates immediate escalation of the fee. Since contractually increasing the fee is impossible without contract renegotiation (which recipients will refuse), the project has knowingly underpriced its core medical liability, accelerating the cash-flow crisis predicted by the financial review.

##### Early Warning Signs
- The weighted average toxicity score across the first 10 patients exceeds the projected score by 2 standard deviations.
- Lead Surgeon formally recommends protocol deviation, requesting access to higher-tier, more expensive immunosuppressants than budgeted for the low maintenance tier.
- Cryo-Inventory reports that the required Level 3 rejection management protocols necessitate borrowing tissue from the contingency bank (if available).

##### Tripwires
- Cumulative intervention costs for rejection management across all active patients in any given quarter exceeds 30% of the total collected maintenance fees for that quarter.

##### Response Playbook
- Contain: Temporarily halt enrollment of any new patients whose donor match profile closely mirrors the patient who experienced the severe rejection event until the protocol is surgically reviewed.
- Assess: Finance/Legal team must immediately model the insolvency timeline if the current realized cost-of-care is extrapolated forward for the next 12 months, and create a 'High-Risk Surcharge' proposal for all future enrollments.
- Respond: CSEO initiates a formal review with the International Ethics Consortium to stress-test the ethical defenses for imposing an emergency, high-deductible rider specifically for future Level 3 rejection events.


**STOP RULE:** If the cumulative cost of managing rejection episodes across the first year of operation equals or exceeds the entire $10M contingency fund.

---

#### FM9 - The Specialist Vacuum: Tech Team Collapse Under Fixed Salary Burden

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Technology & Data Integrity Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
Assumption A9 proves false when the specialized talent required to maintain the critical integrated EHR and RPM systems—specifically the Remote Monitoring Technician and Security Analyst—cannot be hired within the allocated OpEx budget due to market scarcity for experts comfortable with NZ compliance hurdles and high-security medical IoT. The required salary band for these niche roles exceeds the budget by 20%. The Technology Lead is forced to hire less experienced staff or delay hiring critical support functions for months, placing unsustainable technical monitoring demands on the already stretched FTEs (like Rina Sato, the Technology Lead). This shortage leads directly to instability (Risk 8/T-1): the biometric monitoring system begins generating intermittent data failures and critical security logging issues. This technical failure prevents the Subscription Finance Manager from triggering monthly revenue, creating immediate, unexpected cash flow interruption precisely when the fixed surgical salaries are due, leading to a high-stakes governance crisis.

##### Early Warning Signs
- Technology Lead documents that recruitment efforts for the key technical FTEs remain unsuccessful for >120 days post-OpEx initiation.
- The Digital Health Compliance Auditor flags the RPM system for 'Inadequate Real-Time Monitoring Logs' during pre-launch testing.
- Security Analyst role remains vacant 60 days past the projected facility readiness date.

##### Tripwires
- Security breach alerts (minor or major) trigger more than 5 times in a single month due to unpatched risks in the RPM integration.
- Salary costs for the technology team run 15% over budget in two consecutive months due to reliance on expensive short-term consultants.

##### Response Playbook
- Contain: Immediately suspend all spending on facility aesthetic upgrades (non-essential CapEx) and divert those funds to create a specialized 'Hiring Incentive Bonus' for the two critical vacant tech roles.
- Assess: Technology Lead must conduct a risk assessment on which technical functions can be temporarily outsourced to a managed service provider (MSP) for 6 months, quantifying the MSP cost vs. the risk of security/revenue failure.
- Respond: CSEO presents the executive team with a revised staffing plan that elevates the compensation band for critical post-launch technical roles above the initial budget cap, requiring an immediate drawdown from the financial contingency to cover the fixed salary difference.


**STOP RULE:** If the biometric revenue trigger mechanism experiences a verifiable, systemic failure lasting more than 45 days during the initial 6-month post-launch stabilization period.
