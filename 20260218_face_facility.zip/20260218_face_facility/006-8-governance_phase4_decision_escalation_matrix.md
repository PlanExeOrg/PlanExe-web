**Budget Request Exceeding Core Project Team Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the Core Project Team's financial authority and requires strategic oversight.
Negative Consequences: Potential for budget overruns and financial instability.

**Critical Risk Materialization Requiring Additional Resources**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Contingency Plan
Rationale: The Core Project Team lacks the authority to allocate significant additional resources or alter the project plan in response to a critical risk.
Negative Consequences: Project delays, increased costs, and potential project failure.

**Ethics & Compliance Committee Deadlock on Patient Selection Criteria**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Final Decision
Rationale: The Ethics & Compliance Committee cannot reach a consensus on a critical ethical issue, requiring a higher level of review and decision-making.
Negative Consequences: Compromised ethical standards, legal challenges, and reputational damage.

**Proposed Major Scope Change Impacting Project Timeline or Budget**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval
Rationale: Significant changes to the project scope require strategic review and approval due to their potential impact on the project's timeline, budget, and objectives.
Negative Consequences: Project delays, budget overruns, and failure to meet project goals.

**Reported Ethical Violation Involving Senior Project Team Member**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Investigation and Disciplinary Action
Rationale: Requires independent review and action due to the potential for conflicts of interest and the severity of the ethical implications.
Negative Consequences: Legal liabilities, reputational damage, and loss of public trust.

**Technical Advisory Group cannot agree on surgical technique**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: The Technical Advisory Group cannot reach a consensus on a critical technical issue, requiring a higher level of review and decision-making.
Negative Consequences: Compromised patient safety, legal challenges, and reputational damage.