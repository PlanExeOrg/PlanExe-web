# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Healthcare Regulatory Specialist (NZ)

**Knowledge**: NZ HDEC, Human Tissue Act, Medical Council of NZ

**Why**: The plan hinges on regulatory approval for novel elective surgery which poses the highest existential risk per SWOT/Regulatory section.

**What**: Review all planned submissions to HDEC/MCNZ and validate the proposed reliance on the International Ethics Consortium.

**Skills**: Regulatory affairs, compliance mapping, clinical trial governance, legislative interpretation

**Search**: NZ Health and Disability Ethics Committee regulatory pathway, experimental medical procedure authorization NZ

## 1.1 Primary Actions

- Immediately halt all discussions and contractual steps regarding *compensated* tissue acquisition (Decision 4, Strategy 3) due to high probable illegality under the Human Tissue Act 2008.
- Direct regulatory counsel to conduct an emergency review of the **Human Tissue Act 2008** constraints specifically prohibiting or severely limiting the use of non-life-saving tissue for elective procedures in New Zealand.
- Recalculate the required 'low monthly maintenance fee' (Decision 3) based on worst-case, risk-adjusted costs for 5 years of complex immunosuppression management and 18 months of mandatory psycho-social support (Decisions 8 & 10). The fee structure is currently financially insolvent.
- Require the team to define a clear, legally viable, *non-compensated* ethical pathway for procuring facial tissue that satisfies both MCNZ standards for tissue viability and HDEC requirements for elective use, linking this directly to the primary lease acquisition deadline.

## 1.2 Secondary Actions

- Begin parallel Proof-of-Concept (PoC) testing for the biometric monitoring system but establish a pre-agreed, fully costed contractual fallback billing mechanism (e.g., milestone payments) that activates the moment regulatory uncertainty arises regarding the biometric trigger.
- Task the design team to analyze the implications of implementing Decision 6, Strategy 2 (maintaining original legal identity) to reduce administrative friction in NZ, rather than mandating a new biometric identity, given the potential regulatory resistance.
- Seek preliminary, informal technical consultation with Medsafe/MoH regarding the classification and regulatory pathway of the proprietary remote monitoring technology that underpins the recurring revenue stream.

## 1.3 Follow Up Consultation

The next consultation must centre entirely on the validated regulatory compliance pathway for tissue sourcing under the Human Tissue Act 2008 and the revised LTV/Operating Cost analysis. We must establish if the $90M budget can survive the necessary restructuring of the fee schedule required to cover the true cost of long-term immunosuppression management without violating the 'not aggressive' mandate.

## 1.4.A Issue - Fundamental Misinterpretation of Regulatory Framework: Human Tissue Act Non-Compliance

The entire premise of procuring and transplanting faces hinges on compliance with the **Human Tissue Act 2008 (HTA)** in New Zealand. Your strategy focuses heavily on post-mortem *organ* donation protocols (Decision 4, Strategy 1) or commercial compensation (Decision 4, Strategy 3), while ignoring the specific regulatory landscape for *tissues* and *transplantation beyond life-saving organs*. The HTA strictly regulates post-mortem tissue donation, requiring explicit consent mechanisms that often preclude commercialization, and it imposes severe restrictions on what can be used for non-therapeutic (i.e., elective cosmetic) purposes. Furthermore, conducting an experimental transplant facility requires rigorous MCNZ oversight and specific HDEC approval, which your plan acknowledges peripherally but does not tackle head-on given the elective nature of the service. The concept of a 'compensated' system (Strategy 3) for facial tissue in NZ is inherently toxic and likely illegal under current interpretations related to commercialization of human material.

### 1.4.B Tags

- Regulatory Barrier
- Human Tissue Act
- Ethical/Legal Non-starter
- Tissue Sourcing Protocol

### 1.4.C Mitigation

Immediately halt all planning related to *compensated* tissue acquisition. The legal team/regulatory consultant MUST conduct a deep dive into the HTA 2008 regarding non-therapeutic tissue use and gain explicit sign-off from the Ministry of Health/HDEC that your proposed procurement model (even the non-financial benefit one) is defensible under current legislation. Define the procurement using only strictly altruistic, pre-existing donor pathways until specific HTA amendments or novel approvals are secured. Consult the **Health Practitioner Competence Assurance Act 2003 (HPCAA)** regarding the novel application of procedures not covered by established guidance.

### 1.4.D Consequence

Proceeding with the current tissue acquisition strategy guarantees an immediate regulatory halt, likely involving the EPA or Police if commercialization elements are suspected. The facility will never receive operational approval, rendering the $90M investment moot.

### 1.4.E Root Cause

Empty

## 1.5.A Issue - Unrealistic Revenue Model: Low Maintenance Fee vs. High Fixed Costs and Biological Risk

Your chosen revenue model (Decision 3: Steep initial fee, followed by a *low monthly maintenance fee*) is catastrophically misaligned with the known liabilities of complex, lifelong immunosuppression in emergent medicine. Facial transplants require continuous, high-touch immunosuppressive management (Decision 10) and 18 months of intensive psycho-social support (Decision 8). High fixed costs ($1.5M/month burn, Decision 7) cannot be sustained by a 'low' monthly fee, especially when that fee is contingent on biometric monitoring (Decision 3/Assumption Issue 2). What happens in year 2 when a patient experiences manageable but resource-intensive rejection requiring specialized pharmacy/monitoring outside the 'low fee' budget? The LTV calculation is inherently flawed; the true cost of managing chronic allograft rejection vastly exceeds simple maintenance.

### 1.5.B Tags

- Financial Viability
- LTV Flaw
- Cost Misalignment
- Risk Underpricing

### 1.5.C Mitigation

Revisit Decision 3 immediately. The recurring charge cannot be 'low.' It must be restructured to cover the *full, projected cost of care* for immunosuppression and mandatory monitoring for the duration of the contract (Decision 12). Consult the finance/actuarial team to calculate the minimum *risk-adjusted* monthly premium required to cover not just facility costs, but projected late-stage intervention costs for the 3-to-5 year term. If patients resist a high maintenance fee, the upfront fee must be drastically increased, or the mandatory wearing duration (Decision 12) must be extended to dilute the OpEx burden over a longer period.

### 1.5.D Consequence

The project will face a severe cash flow crisis within 15-18 months as operational costs outpace subscription revenue, leading to immediate insolvency, especially since the revenue trigger (biometric compliance) is itself unproven.

### 1.5.E Root Cause

Empty

## 1.6.A Issue - Regulatory Pathway Assessment Ignores MCNZ Requirements for Novel Medical Devices/Procedures

While you correctly identify the need for HDEC submission and hired external consultants, the plan severely downplays the Medical Council of New Zealand (MCNZ) oversight, particularly concerning procedures that fall outside established clinical guidelines (like facial transplantation). MCNZ governs practitioner competence. To perform this, the surgeons must demonstrate competence via rigorous evidence, likely requiring specific MCNZ approval for the defined *procedure itself*, not just ethical clearance. Furthermore, the success of the revenue trigger hinges on proprietary remote monitoring technology, which may be classified as a regulated medical device or diagnostic tool under NZ law. The plan assumes that regulatory approval is primarily an ethics/HDEC issue, which is insufficient for a multi-year operational license involving highly invasive, novel surgery.

### 1.6.B Tags

- MCNZ Compliance Gap
- Medical Device Regulation
- Procedural Governance
- Regulatory Oversight Underestimation

### 1.6.C Mitigation

Immediately task the regulatory consultants (as per pre-project assessment) to map the entire path for MCNZ accreditation for the specific surgical team and the procedure itself. Concurrently, engage a specialized regulatory affairs expert familiar with MedTech certification (potentially requiring Medsafe consultation if the monitoring system processes biologically active data). The prerequisite for HDEC sign-off must explicitly include MCNZ provisional approval for the surgical protocol (Decision 2).

### 1.6.D Consequence

The project will be halted post-HDEC approval when MCNZ reviews surgeon credentials and procedural standards, or when the monitoring technology fails to gain necessary classification/approval, blocking the subscription payment mechanism.

### 1.6.E Root Cause

Empty

---

# 2 Expert: Subscription Business Model Architect

**Knowledge**: LTV forecasting, MRR stability, usage-based billing, tiered subscription design

**Why**: The core viability relies on the Subscription Recurrence Definition which conflicts with cash flow predictability. Needs LTV optimization.

**What**: Redesign the initial steep fee + low maintenance fee structure to maximize 3-year LTV while ensuring $1.5M/month burn coverage projections.

**Skills**: Revenue strategy, financial modeling, consumer contract design, churn analysis

**Search**: Subscription revenue model optimization for medical services, usage-based medical billing

## 2.1 Primary Actions

- Conduct a feasibility study on the biometric confirmation system and explore alternative billing mechanisms.
- Reassess the staffing model to include flexible contracts and reduce fixed costs.
- Develop a comprehensive public relations strategy to address ethical concerns and build community trust.

## 2.2 Secondary Actions

- Engage technology experts to assess the viability of the biometric system and potential backup solutions.
- Implement a phased hiring approach based on patient volume projections.
- Schedule regular community engagement sessions to discuss the ethical implications and benefits of the service.

## 2.3 Follow Up Consultation

Discuss the outcomes of the feasibility study on the biometric system and any alternative revenue models explored. Review the revised staffing model and public relations strategy effectiveness.

## 2.4.A Issue - Unclear Revenue Model

The reliance on a biometric confirmation system for subscription billing is unproven and poses a significant risk to revenue stability. If this system fails, the entire financial model could collapse, leading to cash flow issues.

### 2.4.B Tags

- revenue_model
- risk
- biometric_system

### 2.4.C Mitigation

Conduct a thorough feasibility study on the biometric confirmation system and explore alternative billing mechanisms that do not rely solely on this technology. Engage with technology experts to assess the viability and potential backup systems.

### 2.4.D Consequence

Without a reliable revenue model, the project risks financial instability, leading to potential operational shutdowns and inability to cover fixed costs.

### 2.4.E Root Cause

Over-reliance on untested technology for core revenue generation.

## 2.5.A Issue - High Fixed Costs

The project has high fixed operational costs due to the leased facility and long-term surgeon contracts, which create vulnerability if patient uptake is lower than expected.

### 2.5.B Tags

- fixed_costs
- vulnerability
- patient_uptake

### 2.5.C Mitigation

Reassess the staffing model to include more flexible contracts or part-time specialists to reduce fixed costs. Additionally, implement a phased approach to hiring based on patient volume projections.

### 2.5.D Consequence

If patient uptake does not meet projections, the project may face severe cash flow issues, risking its ability to sustain operations.

### 2.5.E Root Cause

Inflexible staffing and high overhead costs without guaranteed patient volume.

## 2.6.A Issue - Ethical and Reputational Risks

The project faces significant ethical scrutiny regarding tissue acquisition and the potential perception of commodifying human tissue, which could lead to reputational damage and public backlash.

### 2.6.B Tags

- ethical_risks
- reputation
- public_backlash

### 2.6.C Mitigation

Develop a comprehensive public relations strategy that emphasizes the ethical sourcing of tissues and the medical necessity of the procedures. Engage with community stakeholders to build trust and transparency.

### 2.6.D Consequence

Failure to address ethical concerns could lead to negative media coverage, regulatory scrutiny, and a decline in subscriber interest.

### 2.6.E Root Cause

Lack of a proactive strategy to manage public perception and ethical sourcing.

---

# The following experts did not provide feedback:

# 3 Expert: Transplant Immunologist

**Knowledge**: Allogeneic tissue compatibility, graft survival, chronic rejection management, immunosuppression dosing

**Why**: Decision 1 prioritizes maximal compatibility, needing expert validation that this choice aligns with the low maintenance fee chosen for long-term care.

**What**: Analyze the projected long-term toxicity profile resulting from maximal matching vs. the inadequacy of the low monthly maintenance fee for late-stage graft intervention.

**Skills**: Tissue typing, pharmacology, clinical outcomes research, laboratory services integration

**Search**: Facial transplant long-term rejection rates, tissue compatibility success metrics, immunosuppression financial risk

# 4 Expert: Biomedical Facility Design Engineer

**Knowledge**: High-security lab retrofitting, cleanroom standards, cryopreservation infrastructure, specialized utility capacity

**Why**: The plan allocates significant CapEx ($36M) to a leased, retrofitted facility requiring Layer-4 Biosecurity and specialized lab integration (Decision 2 dependency).

**What**: Audit the requirements for Layer-4 Biosecurity and specialized cryopreservation, validating the feasibility within the Auckland lease constraints and budget allocation.

**Skills**: MEP design, capital project management, biosafety level standards, facility hardening

**Search**: Layer 4 biosecurity facility retrofit cost, advanced cryopreservation infrastructure requirements

# 5 Expert: Medical Ethics & Policy Advisor

**Knowledge**: Tissue sourcing ethics, compensated donation law, patient autonomy in experimental care

**Why**: Decision 4 regarding tissue sourcing via non-financial restoration conflicts with established practice and risks severe ethical backlash in NZ.

**What**: Assess the legal and reputational exposure of offering 'restorative benefits' versus cash compensation for tissue procurement in the NZ context.

**Skills**: Bioethics review, informed consent best practices, international donor legislation, public trust management

**Search**: Ethics compensated tissue donation New Zealand, restorative benefits medical procurement law

# 6 Expert: Digital Health Compliance Auditor

**Knowledge**: NZ Privacy Act 2020, biometric data security, remote patient monitoring validation

**Why**: The project critically relies on a remote biometric monitoring system for revenue triggers, which faces regulatory uncertainty per the Missing Information section.

**What**: Map the technical specifications of the biometric adherence monitoring system against specific articles of the NZ Privacy Act 2020 for immediate auditing.

**Skills**: GDPR compliance, data encryption standards, health information technology audit, digital liability assessment

**Search**: NZ Privacy Act 2020 biometric data, remote patient monitoring legal compliance

# 7 Expert: Healthcare Compensation Strategist

**Knowledge**: Surgical talent retention, high-risk medical employment contracts, equity compensation structures

**Why**: Staffing relies on high-cost, core surgical talent via 5-year contracts, posing a major fixed cost and retention risk (Weakness 2, Risk O-2).

**What**: Develop alternative, tiered compensation models for the three core surgeons that reduce immediate fixed salary reliance while maximizing knowledge transfer and retention incentives.

**Skills**: HR strategy, executive compensation, knowledge transfer protocols, performance-based incentives

**Search**: Retaining specialist surgeons fixed cost mitigation, equity vesting for medical professionals

# 8 Expert: Identity Management Legal Counsel

**Knowledge**: Biometric identity law, cross-border recognition of altered identity, NZ administrative law

**Why**: Decision 6 mandates legally treating the new face as the sole biometric identity, creating massive administrative and legal friction post-operation in NZ.

**What**: Detail the exact legal pathways and timelines required in New Zealand to formally update identity documents (passport, license) following a successful transplant.

**Skills**: Administrative law, identity documentation revision, cross-jurisdictional legal analysis, high-net-worth client services

**Search**: Changing legal identity based on physical alteration NZ, biometric recognition law New Zealand