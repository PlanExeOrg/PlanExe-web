## Positive Constraints

- Facility for transplanting faces between people, inspired by the movie 'Face Off'.
- Location: New Zealand.
- Users pay a subscription fee every month they wear another person's face.
- Budget: $90M USD.
- Project start ASAP.

## Negative Constraints

- Avoid the most aggressive scenario.
