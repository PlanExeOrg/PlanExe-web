## Primary Decisions
The vital few decisions that have the most impact.


The project's strategic success hinges on managing the critical tension between ethical/reputational risk and commercial viability. The 'Critical' levers—Subscription Recurrence Definition, Tissue Acquisition Protocol, and Ethical Gatekeeping—directly govern the business model foundation, input supply ethics, and overall viability insurance. High-impact levers address fixed cost structure (Staffing) and defining customer value (Duration). Collectively, these focus on stabilizing high-cost revenue generation against inherent ethical scrutiny in an experimental medical service.

### Decision 1: Donor/Recipient Pairing Protocol
**Lever ID:** `d95cb7ac-3aa3-496d-92f7-db898861250b`

**The Core Decision:** This protocol dictates the precise immunological and biological criteria for pairing available donor tissue with subscribing recipients. Success is primarily measured by long-term graft survival rates and minimizing acute rejection episodes. By prioritizing strict compatibility, the project secures high-fidelity initial outcomes, trading immediate volume growth for reduced operational risk associated with chronic graft failure management.

**Why It Matters:** Establishing strictly limited criteria for acceptable tissue and immune compatibility reduces the probability of immediate graft rejection, thereby improving initial surgical success rates. However, this tight filtering drastically shrinks the addressable market of potential subscribers who can actually receive the service, directly pressuring subscription volume needed to cover fixed facility overhead.

**Strategic Choices:**

1. Implement a maximal compatible donor-recipient matching algorithm prioritizing long-term immune stability over cosmetic expediency for all procedures.
2. Adopt a phased clinical protocol relying solely on genetically near-identical (e.g., sibling) pairings for the initial five years of operation to secure proof of concept.
3. Leverage experimental immunosuppressive regimens on a case-by-case basis, accepting elevated short-term morbidity risk to maximize the pool of eligible subscribers.

**Trade-Off / Risk:** Selecting near-identical genetic matches guarantees short-term success but severely restricts the revenue base by failing to serve the broader market segment willing to assume higher risk for facial restoration.

**Strategic Connections:**

**Synergy:** It strongly supports the Immunosuppression Regimen Complexity by ensuring that the most stringent protocols have the highest probability of success, validating intensive treatment plans.

**Conflict:** It directly conflicts with the Subscription Recurrence Definition by severely limiting the pool of potential recipients, putting pressure on revenue stability needed to cover fixed costs.

**Justification:** *High*, This lever is critical as it directly governs the project's viability by balancing surgical success (quality) against market size (revenue potential). Its conflict with subscription volume defines the core tension between clinical rigor and commercial necessity.

### Decision 2: Facility Build-Out Scope & Location
**Lever ID:** `80eecae9-0576-4355-a56c-ae3369417421`

**The Core Decision:** This determines the physical footprint, construction method, and geographic positioning of the primary surgical hub in New Zealand. Balancing capital expenditure against operational accessibility is key. A faster, modular build minimizes initial burn rate, allowing earlier revenue capture, but an inaccessible location may strain Staffing Model for Surgical Success and increase recipient logistical burdens.

**Why It Matters:** Opting for modular, pre-fabricated surgical suites rather than ground-up construction accelerates the time-to-revenue generation and conserves capital within the $90M budget. This speed trade-off might compromise long-term operational flexibility or require leasing expensive specialized space near centers of existing surgical talent, increasing recurring operational expenditures.

**Strategic Choices:**

1. Secure a long-term lease for an existing, retrofitted specialized surgical theatre in Auckland, focusing capital on equipment and staffing rather than land acquisition and new construction.
2. Construct a purpose-built, high-security facility in a remote, low-cost region of the South Island, accepting the challenge of recruiting specialist surgical and nursing staff away from established urban hospitals.
3. Establish a decentralized partnership model by funding accredited external surgical centers to perform the procedure under our supervision, minimizing onsite long-term capital outlay.

**Trade-Off / Risk:** Decentralizing execution via external centers drastically lowers fixed facility burden but introduces unmanageable risks regarding procedural consistency, intellectual property security, and consistent application of experimental protocols.

**Strategic Connections:**

**Synergy:** Leveraging a modular build accelerates ability to launch, enabling faster synergy with the Subscription Payment Trigger Mechanism to start collecting revenue sooner from the first cohort.

**Conflict:** Constructing in a remote South Island location conflicts with the perceived need for accessibility required by the Recipient Post-Operative Reintegration Support, increasing friction for subscribers.

**Justification:** *High*, This lever controls the major initial capital allocation within the $90M budget and sets the physical context for operational success. Location fundamentally dictates accessibility, recruitment feasibility, and construction speed, impacting all time-to-revenue calculations.

### Decision 3: Subscription Recurrence Definition
**Lever ID:** `c3bde353-8d90-47f1-aaa4-29736273c92b`

**The Core Decision:** This lever defines how and when the recurring revenue stream is generated from subscribers. Aligning billing with active 'face-wearing' ties perceived value directly to cost, enhancing customer buy-in. Success relies on robust monitoring systems to accurately track usage, while unpredictable revenue challenges the stability required for continuous high-cost medical operations.

**Why It Matters:** Structuring the recurring fee only against the patient’s active utilization of the new face—for example, charging only when biometric identity verification confirms face-wearing—aligns short-term customer perception with value received. This directly exchanges predictable monthly revenue stability for variable income dependent on adherence to mandatory follow-up and monitoring protocols.

**Strategic Choices:**

1. Charge a steep, non-refundable initial procedure fee followed by a low monthly maintenance fee contingent upon strict adherence to compliance monitoring schedules.
2. Implement an 'identity-locked' monthly subscription fee that auto-renews only if the recipient actively maintains the transplanted tissue through required immunosuppressant drug refills.
3. Structure the fee as a one-time, seven-figure acquisition charge payable upon successful graft integration, treating the subscription model solely as a post-surgical warranty vehicle.

**Trade-Off / Risk:** Shifting to a one-time acquisition charge maximizes immediate high-net cash inflow but fails the specified goal of supporting operations via a recurring subscription revenue model, jeopardizing long-term viability.

**Strategic Connections:**

**Synergy:** This strongly aligns with Recipient Face-Wearing Duration, as the billing cycle directly becomes a quantifiable measure of how long the patient elects to maintain the high-cost service.

**Conflict:** Aligning payments with utilization directly conflicts with the goal of stable recurring revenue, as it creates revenue unpredictability that stresses budgeting for the Facility Infrastructure Cadence for Upgrades.

**Justification:** *Critical*, As the project is explicitly revenue-model driven, this lever defines the nature of recurring income. It directly trades predictable stability against customer perception/value alignment, which is foundational to the business purpose.

### Decision 4: Tissue Acquisition Protocol
**Lever ID:** `1bfd7299-e104-4132-9775-e6ca4bb110b8`

**The Core Decision:** This protocol governs the ethical sourcing and procurement of necessary facial tissues, balancing speed against ethical optics. Developing a compensated mechanism accelerates supply necessary for meeting subscription demand. The key metric is the volume of viable, ethically sourced tissue secured monthly, weighed against potential reputational damage from perceived tissue commodification.

**Why It Matters:** Establishing a formal, compensated tissue donation program accelerates the pipeline of viable donors by offering market-rate incentives to next-of-kin, which provides necessary volume for the subscription base. This commoditization introduces significant negative publicity risk if perceived as exploiting vulnerable populations for elective cosmetic/status procedures.

**Strategic Choices:**

1. Source 100% of requisite facial tissues exclusively from deceased donors qualifying under existing rigorous organ donation protocols, avoiding any direct pre-mortem compensation.
2. Create a highly specialized, ethically vetted procurement contract offering substantial, non-financial restorative benefits (e.g., free future cosmetic surgeries) to eligible donor families.
3. Establish a competitive, upfront cash compensation program for donor families sourced via specific pre-agreed neurological criteria to ensure rapid tissue viability upon procurement.

**Trade-Off / Risk:** Direct cash compensation for tissues raises immediate ethical red flags in a sensitive medical field, potentially attracting intense negative media scrutiny that could shutter the facility before profitability is reached.

**Strategic Connections:**

**Synergy:** Accelerating tissue flow via compensation directly enables the Donor/Recipient Pairing Protocol to run more frequently, maximizing utilization of available surgical slots.

**Conflict:** Establishing a cash compensation program heavily conflicts with Ethical Gatekeeping and Patient Screening Intensity, as high financial incentives can compromise the objectivity of donor family consent.

**Justification:** *Critical*, Tissue supply is the foundational physical input. The protocol choice (compensation vs. strict altruism) manages the primary ethical flashpoint and defines the volume pipeline necessary to satisfy any defined market size.

### Decision 5: Ethical Gatekeeping and Patient Screening Intensity
**Lever ID:** `b78f3a19-5e45-48a3-a173-fb5b6e3107d7`

**The Core Decision:** This lever establishes the strictness of pre-operative screening for recipients, balancing profound ethical responsibility against commercial viability. High intensity buffers against severe reputational and legal crises, ensuring operational continuity. Success is defined by near-zero external regulatory intervention and a managed, sufficient volume of paying clients to sustain the fixed operational costs.

**Why It Matters:** Stringent pre-screening minimizes the likelihood of high-profile complications or regulatory backlash which could halt operations entirely, providing necessary insurance against reputational risk. However, overly restrictive screening drastically reduces the pool of eligible, paying recipients, threatening the unit volume required to service the high fixed facility costs. The process must balance clinical safety with commercial feasibility.

**Strategic Choices:**

1. Implement the most rigorous established international bioethics standards for experimental procedure consent, accepting a smaller initial recipient pool to ensure maximum legal and reputational insulation.
2. Streamline the psychological and social screening process to focus only on acute, non-mitigatable risks, prioritizing throughput to begin revenue generation sooner.
3. Outsource the entire ethical review panel to an independent, established international consortium, absorbing their external vetting costs in exchange for reduced internal liability exposure.

**Trade-Off / Risk:** The rigor of ethical screening directly constrains the addressable market size; excessive prudence dramatically increases the risk of financial underutilization relative to the large capital investment.

**Strategic Connections:**

**Synergy:** Stringent intensity directly supports Ethical Gatekeeping and Patient Screening Intensity by defining the required rigor and diligence applied to the selection process.

**Conflict:** It constrains Recipient Identity Management Strategy; extremely high screening intensity requires significantly more robust (and costly) identity verification to justify the intense scrutiny.

**Justification:** *Critical*, This lever directly controls the regulatory and reputational risk profile, which is existential for a novel, high-cost medical venture. It acts as the primary gatekeeper to all revenue streams by defining the addressable market.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Recipient Identity Management Strategy
**Lever ID:** `fa505e78-0113-400a-a86e-74446ec05b33`

**The Core Decision:** This defines the legal and social standing of the transplanted face concerning the subscriber's identity documents and public interactions. Establishing the new face as the primary identity streamlines transactional friction post-surgery, crucial for integration. Success is measured by the reduction in administrative conflicts during the reintegration phase, provided legal compliance is maintained.

**Why It Matters:** Defining the grafted face as the recipient’s sole legal identifier simplifies insurance and regulatory interaction but exponentially increases the psychological and legal burden should the transplant fail or the donor's identity leak into public records. The alternative maintains dual identities, which adds administrative complexity and cost during routine interactions.

**Strategic Choices:**

1. Legally mandate that the recipient adopts the donor's facial structure as their new, sole biometric identity for all governmental and financial records post-transplant completion.
2. Maintain the recipient's original legal identity across all official documents, treating the face as an advanced, non-biological prosthetic appendage requiring constant reassessment.
3. Develop a proprietary, encrypted digital identity ledger tied to the facility's health records, bypassing conventional government identification standards for initial operational phases.

**Trade-Off / Risk:** Bypassing standard government identification complicates essential daily functions like banking and travel, creating significant friction that could rapidly erode subscriber confidence and prompt regulatory intervention.

**Strategic Connections:**

**Synergy:** A clear Recipient Identity Management Strategy simplifies the necessary coordination required by the Recipient Post-Operative Reintegration Support services, reducing psychological friction.

**Conflict:** Mandating a new identity conflicts with the Donor Vetting and Biological Material Tenure process, as it risks unnecessary public exposure or potential posthumous claims related to the donor's original identity.

**Justification:** *High*, This is a foundational operational and legal hub. It determines the friction clients face post-surgery and links directly to regulatory acceptance and the success of the Post-Operative Reintegration Support, profoundly affecting long-term market acceptance.

### Decision 7: Staffing Model for Surgical Success
**Lever ID:** `d14e68b2-9b56-488b-bef4-66fe371fe8f8`

**The Core Decision:** This lever determines the human capital strategy for surgical execution, balancing fixed salary costs against specialized expertise and operational flexibility. Success hinges on stabilizing surgeon retention through attractive, long-term compensation to ensure procedure consistency, directly impacting the quality benchmark for the high-cost service delivered.

**Why It Matters:** Hiring world-class, proprietary surgeons on high guaranteed salaries ensures peak early procedural expertise but locks the business into extremely high fixed operating expenses, making cost recovery highly sensitive to subscription churn. Conversely, relying on visiting international consultants dilutes knowledge transfer but lowers the fixed salary burden.

**Strategic Choices:**

1. Recruit and retain a core team of three surgeons and matching support staff on five-year guaranteed contracts, ensuring procedure standardization within the facility walls.
2. Maintain an ultra-lean core staff augmented by international visiting surgical specialists paid high per-case incentive fees, retaining the ability to significantly scale down personnel costs quickly.
3. Structure compensation heavily toward equity participation in the facility, aligning surgeon financial interest with long-term profitability rather than just immediate surgical throughput.

**Trade-Off / Risk:** Tying surgeon compensation primarily to long-term equity dilutes their focus on immediate, high-risk surgical outcomes, potentially causing short-term patient safety incidents that destroy early revenue momentum.

**Strategic Connections:**

**Synergy:** It strongly supports Staffing Model for Surgical Success by funding high fixed costs, provided the Subscription Payment Trigger Mechanism guarantees sufficient initial revenue.

**Conflict:** High fixed costs from guaranteed salaries conflict with the need for low initial burn rate, potentially pressing the constraints imposed by the Facility Build-Out Scope & Location budget.

**Justification:** *High*, This lever controls a primary fixed operating cost driver. The choice between high fixed salaries for expertise versus consultant-based variable costs dictates long-term financial stability and success dependence on subscription churn rates.

### Decision 8: Recipient Post-Operative Reintegration Support
**Lever ID:** `0e3d3274-fe57-4912-b342-9e52271ee1ca`

**The Core Decision:** This governs the long-term success and perceived value of face-wearing by defining the duration and scope of psycho-social support offered to recipients. High levels ensure adherence to the subscription model but inflate operational costs; metrics include recipient compliance rates and long-term identity stabilization scores.

**Why It Matters:** The level of mandatory post-surgery psychological and social integration support directly influences the recurring subscription value proposition and necessary facility overhead. Reducing this support reduces fixed operational costs but drastically increases the risk of long-term recipient non-compliance or psychological failure, threatening brand reputation.

**Strategic Choices:**

1. Mandate a minimum 18-month, facility-managed structured social and psychological readaptation program funded entirely through the base subscription tier.
2. Offer a basic, 3-month stabilization package, requiring recipients to contract with external, specialized, and self-funded identity counseling services afterward.
3. Focus post-operative support exclusively on physical healing management, treating psychological challenges as an elective, high-cost add-on service.

**Trade-Off / Risk:** Scaling back essential identity reintegration support cuts immediate operational costs but transforms non-financial risks, like patient relapse or legal challenges, into high-impact reputational liabilities.

**Strategic Connections:**

**Synergy:** It directly enhances the perceived value established by the Subscription Recurrence Definition, justifying higher recurring fees while complementing the long-term focus of Recipient Face-Wearing Duration.

**Conflict:** Extensive support increases overhead, conflicting with cost optimization efforts driven by the Staffing Model for Surgical Success, which seeks to control fixed personnel expenses.

**Justification:** *Medium*, While a major driver of operational cost and perceived value, it appears downstream of the core revenue definition and tissue supply constraints. It primarily functions to maintain the integrity of the subscription relationship.

### Decision 9: Subscription Payment Trigger Mechanism
**Lever ID:** `cfd57f21-a859-4c92-bb19-05b6871420ce`

**The Core Decision:** This lever dictates when subscription revenue begins, directly balancing initial client financial friction against project operational liquidity. Aligning payment only after robust psychological acceptance minimizes client drop-off but forces the facility to cover high variable costs entirely on initial financing until maturity.

**Why It Matters:** Delaying the start of the recurring subscription fee until the recipient is demonstrably stable in their new identity shifts initial capital burden away from the client but severely strains early operational cash flow. Conversely, front-loading payments guarantees initial liquidity but risks client abandonment during critical, high-cost recovery phases.

**Strategic Choices:**

1. Initiate the monthly subscription payments immediately upon client discharge from inpatient critical care, regardless of ongoing outpatient follow-up necessity.
2. Defer all subscription billing until the recipient successfully passes a formalized, 90-day psychological and functional acceptance review post-surgery.
3. Structure payments as quarterly installments tied exclusively to the successful completion of mandated post-operative regenerative therapy milestones.

**Trade-Off / Risk:** Delaying the revenue trigger reduces client pressure at critical junctures but increases the fixed operational burn rate required to sustain the recipient through the first three months of high-cost care.

**Strategic Connections:**

**Synergy:** Deferring payment dramatically increases the required financial runway established by the Facility Build-Out Scope & Location budget, necessitating careful alignment with the overall $90M constraint.

**Conflict:** Delaying revenue strains immediate cash flow, increasing the vulnerability captured by the Staffing Model for Surgical Success if relying on high-salary fixed contracts rather than lean augmented staffing.

**Justification:** *Medium*, This lever directly impacts initial project liquidity by adjusting the time until cash flow begins. While crucial for early survival, its effect is largely temporal, dictated by the definition set in Subscription Recurrence Definition.

### Decision 10: Immunosuppression Regimen Complexity
**Lever ID:** `b3137fd0-37a3-488f-b37e-eac65a02bcaa`

**The Core Decision:** This choice affects both immediate operational complexity and long-term biological viability. Complex regimens offer superior rejection control but demand substantial investment in specialized laboratory services and highly trained personnel, directly impacting the quality assurance metrics for the transplant procedure.

**Why It Matters:** Selecting a more novel or complex immunosuppressive drug regimen can reduce the likelihood of acute rejection, potentially lowering expensive long-term intervention costs, but it introduces higher immediate toxicity monitoring overhead and specialized pharmacy requirements.

**Strategic Choices:**

1. Utilize only highly standardized, widely available triple-drug immunosuppression protocols supplemented by facility-specific local anti-rejection adjuncts.
2. Invest capital in developing proprietary, localized delivery mechanisms for third-generation targeted immunosuppressants to minimize systemic toxicity exposure.
3. Adopt a personalized, dynamic dosing model driven by continuous ex vivo monitoring of T-cell activity, requiring dedicated, high-throughput laboratory services.

**Trade-Off / Risk:** Opting for cutting-edge personalized dosing promises better long-term outcomes by limiting toxicity, but demands substantially higher initial investment in specialized, never-before-seen intra-project laboratory infrastructure.

**Strategic Connections:**

**Synergy:** Advanced regimens synergize with the Donor/Recipient Pairing Protocol by allowing higher-risk or more complex tissue compatibility profiles to be successfully managed post-operation.

**Conflict:** High complexity and specialized monitoring requirements clash with the need to maintain a lean core staff model, creating tension with the overall Staffing Model for Surgical Success.

**Justification:** *Medium*, This is a key clinical quality lever that interacts strongly with the Pairing Protocol, driving complex staffing requirements. However, it is secondary to the fundamental choice of *if* and *how* the project generates revenue.

### Decision 11: Facility Design for Anonymity vs. Accessibility
**Lever ID:** `debe565b-6ab8-4206-aac2-5481acab98a5`

**The Core Decision:** This lever defines the physical layout concerning public interaction versus operational privacy. Anonymity shields the controversial operations from public scrutiny, stabilizing the project's political environment, but restricts logistical efficiency, impacting the timing set by the Facility Infrastructure Cadence for Upgrades.

**Why It Matters:** Prioritizing extreme biometric and physical anonymity in the facility's architecture reduces potential public scrutiny and protest, stabilizing operations, but it significantly increases construction complexity and may negatively impact emergency responder access during critical events.

**Strategic Choices:**

1. Design the facility as a near-opaque, self-contained structure with limited external visual or digital footprint, prioritizing security over rapid external logistical access.
2. Embrace high visibility through transparent, modern architectural elements situated near major transport hubs to signal legitimacy and accessibility to an elite clientele.
3. Locate the facility on a remote, privately acquired land parcel where regulatory hurdles are low, offsetting accessibility issues with total environmental control.

**Trade-Off / Risk:** Maximizing operational security through remote, opaque construction appeases ethical critics by limiting visibility, yet it clashes directly with the need for efficient patient and surgical team logistics.

**Strategic Connections:**

**Synergy:** Prioritizing anonymity complements the Ethical Gatekeeping and Patient Screening Intensity by controlling external visibility, thereby reducing community friction perceived by high-risk patients.

**Conflict:** Designing for extreme anonymity often forces the facility into remote locations, conflicting with the desire for rapid logistical access required for urgent surgical interventions dictated by the Tissue Acquisition Protocol.

**Justification:** *Medium*, This lever manages external risk (scrutiny) versus internal logistics. It is highly coupled with staffing and location decisions, making it important, but not a primary driver of the overall business model success.

### Decision 12: Recipient Face-Wearing Duration
**Lever ID:** `9943254d-724b-4dd9-ac51-942aadb72e24`

**The Core Decision:** This lever governs the mandatory duration occupants must maintain facial transplantation, directly calibrating the Lifetime Value (LTV) of each subscriber. Setting a fixed, lengthy duration maximizes predictable recurring revenue streams but heightens long-term risk exposure regarding unknown biological complications. Success is measured by stable LTV forecasting and controlled complication rates over the established term.

**Why It Matters:** The prescribed length of time a recipient must maintain the transplant directly influences the long-term lifetime value (LTV) projected from the subscription fee. Shorter required durations decrease the total accumulated revenue per user but might enhance initial market adoption by lowering the total commitment required. Longer mandatory periods increase LTV but raise the risk profile related to long-term immunological or psychosocial complications.

**Strategic Choices:**

1. Mandate a minimum maintenance period of five years before re-evaluation for a potential switch, maximizing recurrent revenue predictability within safety parameters.
2. Offer tiered subscription packages based on commitment length, where shorter-term users pay a significant premium per month to cover the lower LTV.
3. Establish a flexible model where the recipient's clinical markers, rather than a fixed calendar time, dictate the minimum wearing duration, creating high variability in revenue forecasting.

**Trade-Off / Risk:** Altering the required wearing time shifts the fundamental revenue profile from a short-term cash injection model to a long-term annuity, sharply trading immediate adoption rate against predictable financial longevity.

**Strategic Connections:**

**Synergy:** It amplifies Subscription Recurrence Definition by setting the minimum financial commitment period, which anchors the LTV calculation directly into the subscription structure.

**Conflict:** It conflicts with Subscription Payment Trigger Mechanism as longer durations may require different, perhaps less frequent, payment triggers to maintain user engagement.

**Justification:** *High*, This lever directly calibrates Lifetime Value (LTV), which is the ultimate metric for a subscription business. It explicitly trades market adoption speed (shorter duration) against long-term revenue predictability.

### Decision 13: Facility Infrastructure Cadence for Upgrades
**Lever ID:** `c230264c-a0bb-482d-a0f1-32b132aa74d1`

**The Core Decision:** This determines the capital allocation strategy for technological relevance, either by front-loading construction with future-proof capacity or relying on subsequent revenue for phased upgrades. The goal is to optimize the return on physical assets against the risk of rapid technological erosion in surgical capabilities. Success hinges on maintaining competitive advantage without exhausting the initial budget.

**Why It Matters:** Deciding whether to build a facility capable of immediate cutting-edge integration (high initial CapEx) or deferring technological updates impacts future operational efficiency and competitive positioning. Delaying upgrades saves capital now but risks making the facility technologically obsolete within three years of opening, potentially undermining the premium pricing structure. Accelerated integration consumes budget needed for contingency funds.

**Strategic Choices:**

1. Construct the initial facility using modular, easily upgradable components, accepting a slightly lower initial operational capacity to allow for rapid integration of proven Phase II technologies.
2. Adopt a 'minimum viable facility' approach, securing only essential Class III medical space now, planning a complete multi-year tech refresh funded entirely by subscription revenue five years post-launch.
3. Over-engineer the initial clean room and utility capacity to support three generations of predicted hardware upgrades, significantly increasing upfront construction complexity and cost.

**Trade-Off / Risk:** The choice between upfront infrastructure augmentation and phased upgrading pits immediate capital conservation against the long-term risk of technological obsolescence in a continuously evolving surgical field.

**Strategic Connections:**

**Synergy:** It enables Facility Build-Out Scope & Location by dictating the necessary utility backbone and spatial planning required to support the chosen upgrade trajectory.

**Conflict:** Adopting an accelerated cadence conflicts with the overall Budget constraint, potentially consuming resources better allocated to contingency funds or staffing needs.

**Justification:** *Low*, This is an infrastructure optimization choice concerning future-proofing. It influences budget trade-offs but is less critical than defining the immediate operational viability (staffing, location, revenue model).

### Decision 14: Donor Vetting and Biological Material Tenure
**Lever ID:** `1ed574e3-fe07-4766-899c-0b4fb9a4adba`

**The Core Decision:** This defines the permissible lifespan of preserved facial tissue inventory, directly impacting surgical scheduling agility versus bio-banking overhead. Long tenures allow better patient matching (higher success probability) but demand sophisticated, high-cost cryo-management systems. Metrics include inventory decay rate and the match-to-procurement ratio.

**Why It Matters:** The length of time procured facial tissue can be held in cryogenic or preserved status without re-validation directly influences operational scheduling flexibility. Longer storage times allow surgeons to wait for the ideal recipient match, increasing success rates, but this increases the cost associated with specialized, long-term bio-banking infrastructure and associated inventory write-offs.

**Strategic Choices:**

1. Establish a strict two-year maximum viable storage limit for preserved facial tissue, necessitating rapid matching to minimize inventory holding costs and technical degradation risk.
2. Invest heavily in novel long-term cryopreservation techniques to extend potential viability beyond five years, treating the bio-bank assets as high-value, slow-moving inventory requiring extensive maintenance.
3. Align donor acquisition strictly to immediate recipient scheduling needs, requiring a near-perfect donor-recipient synchronicity to eliminate all long-term storage costs.

**Trade-Off / Risk:** Extending tissue viability increases scheduling flexibility but introduces substantial, non-trivial costs associated with high-security, ultra-low temperature bio-banking infrastructure and inventory management.

**Strategic Connections:**

**Synergy:** Extending tenure significantly enhances Donor/Recipient Pairing Protocol flexibility by decoupling biological availability from immediate surgical scheduling pressure.

**Conflict:** Longer tenure increases the required scale and sophistication of Facility Infrastructure Cadence for Upgrades, as bio-banking technology requires specialized climate control.

**Justification:** *Medium*, This lever dictates inventory management of the core physical asset (tissue). It enhances scheduling flexibility but its impact is largely focused on logistics efficiency rather than foundational strategy, unless storage costs prove prohibitive.

### Decision 15: Post-Subscription Transition Pathway
**Lever ID:** `d20089fd-3eae-43c0-ac8e-fadd08b351cd`

**The Core Decision:** This strategy dictates the ongoing relationship and resource draw after the primary subscription term ends, balancing residual revenue capture against long-term liability. A successful pathway minimizes organizational commitment post-term while retaining avenues for necessary biological stability oversight, ensuring positive testimonials for future marketing.

**Why It Matters:** Defining what happens when a recipient completes their term determines both future optional revenue streams and potential long-term liability exposure. Offering continued, lower-cost maintenance services ensures a trickle of revenue but requires ongoing facility resource allocation and maintenance oversight far beyond the initial contract period. Abrupt cessation transfers all long-term care liability back to public systems, potentially impacting site reputation.

**Strategic Choices:**

1. Automatically downgrade all completed contracts to a mandatory, heavily subsidized 'Biological Stability Monitoring' tier for an additional ten years to control long-term outcome data.
2. Implement a clean break after the term, requiring the recipient to purchase a new, full-cost subscription for any further elective services or adjustments.
3. Create a phased retirement program where the recipient can opt-in to transition to a lower-frequency, high-deductible maintenance contract funded by a small portion of their final subscription year.

**Trade-Off / Risk:** The end-of-contract pathway forces a choice between securing minor, protracted revenue streams versus completely shedding long-term maintenance liability and minimizing future operational commitment.

**Strategic Connections:**

**Synergy:** It directly conditions the ongoing need for a reduced Immunosuppression Regimen Complexity support structure after the primary contract concludes.

**Conflict:** Creating high-cost, continuous maintenance options conflicts with Recipient Face-Wearing Duration, as excessively long post-term oversight undermines the initial revenue maximization goal.

**Justification:** *Low*, This addresses long-term liability and residual revenue streams post-term. It is important for sustained legacy but is strategically secondary to establishing a profitable primary contract term (governed by Duration and Recurrence Definition).
