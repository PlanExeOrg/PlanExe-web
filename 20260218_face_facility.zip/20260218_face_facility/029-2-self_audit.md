Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 17 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 3 | Material risk with plausible path. |
| ✅ Low | 0 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because success depends on face transplantation, which is physics-consistent but unproven at the required scale for a commercial facility. The plan does not address conventional fallbacks. "The plan is highly ambitious, aiming to create a commercial facility for face transplantation with a subscription model."

**Mitigation**: Project Team: Conduct a thorough market analysis to determine the potential demand and financial viability of the face transplantation facility within 90 days.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of face transplantation, a subscription model, and radical technologies without independent evidence at comparable scale. "The plan is extremely high-risk and novel. Face transplantation is a complex and experimental procedure, and the subscription-based model adds another layer of untested innovation."

**Mitigation**: Project Team: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Owner: Project Manager / Deliverable: Validation Report / Date: 180 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions several strategic concepts (e.g., Ethical Oversight Strategy, Regulatory Approval Strategy) but lacks one-pagers defining their mechanism-of-action, owners, and measurable outcomes. "A key missing strategic dimension is a detailed plan for donor face acquisition and preservation."

**Mitigation**: Project Manager: Assign owners to each strategic concept (e.g., Ethical Oversight, Regulatory Approval) to produce one-pagers with value hypotheses, success metrics, and decision hooks by 2024-12-31.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because a major hazard class (donor face acquisition) is absent or minimized. The plan lacks a detailed strategy for acquiring and preserving donor faces. "A key missing strategic dimension is a detailed plan for donor face acquisition and preservation."

**Mitigation**: Head of Operations: Develop a comprehensive Donor Face Acquisition and Preservation Plan, including partnerships, consent protocols, logistics, preservation techniques, inventory management, and ethical oversight, by 2024-12-31.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions regulatory requirements but lacks a comprehensive timeline or permit matrix. "The Regulatory Approval Strategy defines the approach to obtaining necessary approvals from regulatory bodies."

**Mitigation**: Regulatory Liaison: Create a permit/approval matrix with lead times, dependencies, and NO-GO thresholds by 2024-12-31. Include typical lead times in the jurisdiction.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a detailed financing plan listing sources/status, draw schedule, and covenants. The document mentions securing funding but provides no specifics. "Secure funding for the facility and operations."

**Mitigation**: CFO: Develop a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO‑GO on missed financing gates by 2024-12-31.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget of $50M lacks substantiation via benchmarks or vendor quotes normalized by area. The plan states, "Assumption: $50 million USD (Facility: $20M, Staffing: $15M, Compliance: $15M)."

**Mitigation**: CFO: Obtain ≥3 vendor quotes for facility construction, staffing, and compliance, normalize costs per m², and adjust the budget or de-scope by 2024-12-31.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., budget, timeline) as single numbers without ranges or alternative scenarios. "Assumption: $50 million USD (Facility: $20M, Staffing: $15M, Compliance: $15M)." and "Assumption: 36 months (Regulatory: 12 months, Construction: 18 months, Training: 6 months)."

**Mitigation**: Project Manager: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the budget and timeline projections by 2024-12-31.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because build-critical components lack engineering artifacts. The plan lacks technical specifications, interface definitions, test plans, and an integration map. "A key missing strategic dimension is a detailed plan for donor face acquisition and preservation."

**Mitigation**: Head of Engineering: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components by 2025-01-31.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes critical claims without verifiable artifacts. For example, the plan states, "Establish partnerships with organ donation organizations," but lacks evidence of existing agreements or even preliminary discussions.

**Mitigation**: Head of Operations: Secure letters of intent from at least three organ donation organizations expressing willingness to partner, outlining potential face donation protocols, by 2024-12-31.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the deliverable, 'Risk Mitigation Protocol,' lacks specific, verifiable qualities. The plan mentions minimizing risks but doesn't define measurable outcomes. "The Risk Mitigation Protocol aims to minimize potential legal, financial, and reputational risks associated with face transplantation."

**Mitigation**: Risk Manager: Define SMART criteria for the Risk Mitigation Protocol, including a KPI for risk reduction (e.g., <10% incident rate) by 2024-12-31.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'subscription-based face swapping service' does not directly support the core project goals of ethical operation or regulatory approval. The goal statement is to "Establish a commercial face transplantation facility in New Zealand with a subscription-based face swapping service."

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of the 'subscription-based face swapping service', complete with a KPI, owner, and estimated cost, or move the feature to the project backlog by 2024-12-31.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Donor Relations & Acquisition Specialist' role is essential, novel, and likely difficult to fill given ethical sensitivities and logistical challenges. The plan states, "Develops and manages relationships with organ donation organizations...to secure a steady supply of donor faces."

**Mitigation**: Head of Operations: Validate the talent market for a Donor Relations & Acquisition Specialist by contacting ≥3 recruiters specializing in medical/nonprofit talent within 60 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a regulatory matrix (authority, artifact, lead time, predecessors) and a fatal-flaw analysis. The plan states, "The Regulatory Approval Strategy defines the approach to obtaining necessary approvals from regulatory bodies."

**Mitigation**: Regulatory Liaison: Create a regulatory matrix (authority, artifact, lead time, predecessors) and a fatal-flaw analysis, flagging NO-GO findings, by 2024-12-31.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan lacks a detailed operational sustainability plan. While the plan mentions long-term sustainability as a risk, it does not provide a clear strategy for ensuring the project's long-term viability. "Long-term sustainability is uncertain."

**Mitigation**: Project Manager: Develop an operational sustainability plan including a funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms by 2025-01-31.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a regulatory matrix (authority, artifact, lead time, predecessors) and a fatal-flaw analysis. The plan states, "The Regulatory Approval Strategy defines the approach to obtaining necessary approvals from regulatory bodies."

**Mitigation**: Regulatory Liaison: Create a regulatory matrix (authority, artifact, lead time, predecessors) and a fatal-flaw analysis, flagging NO-GO findings, by 2024-12-31.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks evidence of contracts/SLAs with vendors for critical services (e.g., organ transportation, data security). The plan mentions reliance on a complex supply chain but lacks specifics. "Facility relies on complex supply chain."

**Mitigation**: Facility Operations Manager: Secure draft SLAs with vendors for organ transportation, data security, and other critical services, including tested failover procedures, by 2025-01-31.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the 'Finance Department' is incentivized by budget adherence, while the 'Technological Development Approach' is incentivized by innovation, creating a conflict over experimental spending. The plan does not address this conflict.

**Mitigation**: Project Manager: Create a shared OKR that aligns the Finance Department and the Technological Development Approach on a common outcome, such as 'achieve X% improvement in transplant outcomes within budget Y' by 2025-01-31.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient. The plan does not describe a review cadence.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board. Define thresholds for re-planning or stopping the project by 2024-12-31.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan has ≥3 High risks (e.g., regulatory, ethical, technical) that are strongly coupled. For example, reliance on xenotransplantation (Technical) increases regulatory hurdles and ethical concerns, creating a multi-domain failure mode. The plan lacks a cross-impact analysis.

**Mitigation**: Risk Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO‑GO/contingency thresholds by 2025-01-31. Include a concrete cascade or a specific overlooked critical risk.