This plan involves money.

## Currencies

- **NZD:** Local currency for facility operations, salaries, and local transactions in New Zealand.
- **USD:** Stable international currency for budgeting, reporting, and potentially for subscription fees to mitigate currency fluctuation risks.

**Primary currency:** USD

**Currency strategy:** Due to the project's innovative and potentially unstable nature, USD is recommended for budgeting and reporting to mitigate risks. NZD will be used for local transactions. Consider hedging strategies to manage exchange rate fluctuations between USD and NZD.