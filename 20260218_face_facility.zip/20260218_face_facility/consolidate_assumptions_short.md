# Purpose
# Project Plan

## Purpose

- Commercial venture: Establishing and operating a high-cost, specialized medical/cosmetic facility.
- Revenue Model: Supported by a recurring subscription revenue model.

## Topic

- Facial transplant facility and subscription service


# Domain
# Primary Domain

- Transplantation Surgery

# Secondary Domains

- Surgical Medicine
- Biomedical Ethics
- Healthcare Finance

# Rationale
Transplantation Surgery owns the core success criterion: ability to perform facial transplant. Surgical Medicine/Plastic Surgery are related outcomes. Healthcare Finance supports the business model.

# Disciplines
## Domain Matrix

- Surgical Medicine: Importance 5, Specificity 5, Role outcome, Reason: Core outcome is successful, repeatable facial transplantation surgery.
- Plastic Surgery: Importance 5, Specificity 5, Role outcome, Reason: Central to performing the actual face transplant procedure.
- Transplantation Surgery: Importance 5, Specificity 5, Role outcome, Reason: Core technical outcome is successful facial transplantation between individuals.
- Biomedical Ethics: Importance 4, Specificity 4, Role constraint, Reason: Transplanting faces involves extreme ethical and medical risk management.
- Bioethics Consultation: Importance 4, Specificity 4, Role constraint, Reason: Ethical dilemmas surrounding identity and consent necessitate bioethics guidance.
- Health Law: Importance 4, Specificity 4, Role constraint, Reason: Operating elective human face transplant requires adherence to NZ health regulations.
- Healthcare Finance: Importance 4, Specificity 3, Role method, Reason: Subscription revenue model dictates business planning and viability.
- Business Model Design: Importance 4, Specificity 3, Role method, Reason: Subscription revenue model is a critical component of the business structure.
- Commercial Law: Importance 3, Specificity 3, Role constraint, Reason: Subscription/financial model requires complex contractual/legal framework.


# Plan Type
# Project Plan: Facial Transplant Facility, NZ

## Core Requirement

- Physical location necessary.

## Justification

- Facility establishment in New Zealand for facial transplantation surgeries.
- Requires real estate acquisition, construction/renovation of surgical facility, and specialized equipment.
- Core deliverable is a physical service involving physical operations on subjects.


# Physical Locations
# Physical Location Requirements

- Must be in New Zealand
- Must accommodate high-security, specialized surgical theatre
- Must have access to high-level surgical talent (Auckland preferred)
- Should be a leased facility ($90M budget)
- Must balance accessibility for elite clientele with operational privacy/security

## Location 1

- New Zealand, Auckland
- Existing, retrofitted specialized surgical theatre lease (CBD or medical hub).
- Rationale: Strategically chosen; best access to surgical talent, reduces capital expenditure via leasing.

## Location 2

- New Zealand, Wellington
- Specialized medical leasing space near regulatory body/ethics committees.
- Rationale: Capital location provides institutional proximity for external ethics consortium and legal navigation.

## Location 3

- New Zealand, Christchurch
- University-affiliated medical research park or facility lease.
- Rationale: Robust research infrastructure and universities for scientific vetting and sourcing non-financial restorative benefits.

## Location Summary

- Primary: Auckland (talent access via leasing).
- Alternatives: Wellington (regulatory proximity), Christchurch (research/ethical networking) for flexibility.


# Currency Strategy
## Currencies

- NZD: Local transactional currency (lease, local salaries, local expenses in NZ).
- USD: Project budget established ($90M USD); major equipment/consultation fees may be in USD.

Primary currency: USD

Currency strategy:

- USD for primary budgeting and high-value purchasing due to $90M capital budget.
- NZD for routine local transactions (rent, supplies).
- Risk management focuses on hedging large USD-to-NZD conversions for capital deployment.


# Identify Risks
# Risk Summary
The project faces significant risks across multiple domains, particularly in regulatory, technical, and financial areas. Critical risks: regulatory hurdles (delays) and ethical concerns (public perception/enrollment). Mitigation: early regulator engagement and comprehensive PR.

## Risk 1 - Regulatory & Permitting

- Experimental nature of procedure faces regulatory hurdles (medical boards, ethics committees).
- Impact: 6–12 month timeline extension; $5M–$10M USD financial overruns.
- Likelihood: High
- Severity: High
- Action: Engage regulators early; hire regulatory consultant.

## Risk 2 - Technical

- Complexity may cause surgical complications or immunosuppression issues.
- Impact: 2–4 week delay per patient; $10,000–$20,000 USD additional cost per complication.
- Likelihood: Medium
- Severity: High
- Action: Implement rigorous staff training; establish complication management protocol; consider phased rollouts.

## Risk 3 - Financial

- Subscription model revenue may suffer if patient uptake is low due to high procedure costs.
- Impact: $2M–$5M USD annual revenue shortfall, jeopardizing sustainability.
- Likelihood: Medium
- Severity: High
- Action: Conduct market research for willingness to pay; develop flexible pricing strategies.

## Risk 4 - Ethical

- Ethical implications may cause public backlash or negative media, impacting reputation/enrollment.
- Impact: 30% decrease in patient enrollment; $3M–$6M USD revenue loss in Year 1.
- Likelihood: High
- Severity: Medium
- Action: Develop comprehensive PR strategy; engage community stakeholders.

## Risk 5 - Operational

- Challenges in recruiting/retaining specialized surgical talent.
- Impact: Procedure delays; 10% increase in labor costs ($1M USD annually).
- Likelihood: Medium
- Severity: High
- Action: Create competitive compensation/development opportunities; partner with medical schools.

## Risk 6 - Supply Chain

- Difficulties sourcing high-quality donor tissues ethically and reliably.
- Impact: 20% reduction in available surgeries; $1M–$2M USD annual revenue loss.
- Likelihood: Medium
- Severity: High
- Action: Establish multiple ethical tissue bank agreements; develop robust logistics plan.

## Risk 7 - Social

- Public perception of procedure as cosmetic, limiting patient base/subscription uptake.
- Impact: 25% lower patient enrollment than projected; $2M USD revenue loss in Year 1.
- Likelihood: Medium
- Severity: Medium
- Action: Engage in outreach/education to clarify medical benefits.

## Risk 8 - Security

- Sensitive procedures/data expose facility to cybersecurity threats/breaches.
- Impact: Legal liabilities and loss of trust; $500,000–$1M USD in legal/remediation costs.
- Likelihood: Medium
- Severity: High
- Action: Implement robust cybersecurity measures and regular audits.


# Make Assumptions
## Question 1 - CapEx and Initial OpEx Allocation

- Assumptions:

 - 40% of $90M ($36M USD) allocated to initial CapEx (equipment, fit-out).
 - 20% of $90M ($18M USD) allocated to initial OpEx runway (12 months pre-revenue).

- Assessments:

 - Title: Financial Runway Assessment
 - Details: $54M for pre-revenue activities. Requires monthly burn rate tracking ($1.5M/month projected OpEx) against 12-month runway.

## Question 2 - Subscription Trigger and Duration

- Assumptions:

 - Compliance monitoring triggers defined by monthly biometric confirmation of immunosuppressant adherence (aligned with Decision 3).
 - Targeted minimum Recipient Face-Wearing Duration set at 3 years for LTV stability.

- Assessments:

 - Title: Revenue Stability and LTV Projection
 - Details: Payments linked to verifiable adherence. 3-year duration sets minimum LTV. Must close projected $2M-$5M annual revenue gap (Risk 3) against CoS by year 2.

## Question 3 - Surgical Team Operational Uptime

- Assumptions:

 - Lease agreement guarantees minimum 20 dedicated surgical days/month for 3 core surgeons/support staff.
 - Uptime sufficient for 2-3 major procedures monthly (non-aggressive scenario).

- Assessments:

 - Title: Operational Capacity Planning
 - Details: Securing fixed, dedicated surgical time critical to mitigating staffing shortages (Risk 5). Prioritize primary access. Partner with lessor for maintenance window guarantees (Decision 13).

## Question 4 - Ethical Review Panel Interface and Permits

- Assumptions:

 - Dedicated Legal/Governance Liaison appointed to manage formal recognition process.
 - MOUs established between review consortium and NZ HDEC within 9 months.

- Assessments:

 - Title: Regulatory Compliance Pathway
 - Details: High regulatory risk (Risk 1). Success relies on bridging outsourced vetting to local governance. Requires contingency budget ($1M-$2M) for specialist counsel.

## Question 5 - Biological Material Handling and Tracking Protocols

- Assumptions:

 - Tissue handling adheres to NZ/AU allogeneic organ transplantation standards plus proprietary Layer-4 biosecurity standard.

- Assessments:

 - Title: Bio-Security and Protocol Integrity
 - Details: Mitigates technical risk (Risk 2). Layer-4 protocol requires defined staff training sign-offs (Risk 5). Mandatory third-party audits of cryo-storage integrity (Decision 14).

## Question 6 - Environmental Impact Management in Auckland

- Assumptions:

 - Facility design necessitates medical waste neutralization systems exceeding regional council guidelines.
 - Energy systems must target 'net-neutral' operational footprint within five years via carbon offset for HVAC/cryogenic load.

- Assessments:

 - Title: Sustainability and Waste Management Strategy
 - Details: High-grade waste/cryo-storage power create environmental liability. Requires upfront CapEx ($1M-$3M) for specialized retrofitting. Net-neutral status is a PR opportunity (counteracting Ethical Risk 4).

## Question 7 - Stakeholder Engagement and Confidentiality

- Assumptions:

 - Tier 1 (Subscribers) sign 10-year NDAs, releasing controlled, anonymized testimonial data.
 - Tier 2 (Donors' Families) receive dedicated Relationship Managers for perceived reciprocity (Decision 4).

- Assessments:

 - Title: Confidentiality and Stakeholder Management
 - Details: Mismanaging confidentiality is extreme risk (Risks 4 & 7). Strategy requires zero data leakage. Rely on pre-approved, controlled external testimonials.

## Question 8 - Integrated Digital Systems Requirements

- Assumptions:

 - Single, locally hosted EHR compliant with NZ Privacy Act 2020 integrating three modules: OR Log, Cryo-Inventory, and RPM.
 - System redundancy (fail-over) mandatory.

- Assessments:

 - Title: Integrated Technology Architecture
 - Details: System failure poses high technical risk (Risk 2) and security risk (Risk 8). Unified EHR minimizes identity risk (Decision 6). Ring-fence $5M-$7M CapEx for procurement, implementation, and two independent security tests.

# Distill Assumptions
# Project Plan Summary

## Financials & Duration

- $36M CapEx, $18M OpEx for 12 pre-revenue months.
- Minimum mandatory subscription: three years (LTV stability).
- Subscription starts with steep initial fee, low monthly maintenance (contingent on compliance).
- Post-subscription mandates: subsidized 'Biological Stability Monitoring' for ten years.

## Compliance & Legal

- Compliance triggers: monthly remote digital immunosuppressant adherence verification.
- Legal liaison to secure NZ HDEC MOUs within nine months.
- Ethical review outsourced to independent international consortium (liability reduction).
- Subscribers sign 10-year NDAs.
- Donor families receive dedicated relationship managers.
- Tissue sourcing contracts offer substantial, non-financial restorative benefits to donor families.

## Operations & Facilities

- Auckland lease established for retrofitted theater; prioritize capital for equipment/staffing.
- Lease guarantees 20 dedicated surgical days monthly for three core surgeons.
- Facility must neutralize waste exceeding NZ guidelines; energy aims for net-neutrality within five years.
- Tissue handling: NZ/AU allogeneic organ standards plus proprietary Layer-4 biosecurity.
- Tissue storage: maximum viable tenure of two years.

## Technology & Integration

- Single, locally hosted EHR must integrate OR, Cryo-Inventory, and Remote Patient Monitoring.

## Clinical & Patient Factors

- Maximal compatible matching prioritizes immune stability over cosmetic expediency.
- Core team of three surgeons hired on five-year guaranteed, high-salary contracts.
- Mandatory 18-month structured psycho-social readaptation program funded by base subscription.
- Subscription billing deferred until 90-day formal psychological and functional acceptance review.
- Recipient identity adopts donor face as sole legal biometric identity post-transplant.
- Complex, proprietary immunosuppressant regimens require significant capital investment.


# Review Assumptions
## Domain of the expert reviewer
Specialized Biomedical Project Management & High-Risk Venture Strategy

## Domain-specific considerations

- Ethical/regulatory compliance for experimental human transplantation in NZ
- High fixed-cost operational management vs. variable subscription revenue
- Supply chain for scarce, high-value biological inputs (donor tissue)
- Managing extreme reputational risk in cosmetic/elective high-cost surgery

## Issue 1 - Assumption of Short-Term Revenue Stability vs. High Fixed Costs
The plan assumes 3-year minimum subscription and a 'low monthly maintenance fee' after a 'steep, non-refundable initial procedure fee'. High fixed costs (facility leasing, specialized staffing, lab requirements) linked to the $90M budget create significant pre-profitability risk. The 12-month OpEx runway ($18M) hinges on fast regulatory approval and patient uptake.

Recommendation: Immediately execute sensitivity analysis on patient volume required for M18 break-even (baseline OpEx $1.5M/month). Initial fee must cover burn rate ($18M + CapEx carry-over) plus 18 months of maintenance. If market uptake is slow, increase initial fee by 20-35% or extend OpEx runway to 18 months ($27M total).
Sensitivity: 25% shortfall in initial patient acquisition delays contingency fund access ($36M) by 6-9 months. Low maintenance fee delays ROI by 12-24 months, risking a capital deficit requiring $10M-$15M USD raise within the $90M structure.

## Issue 2 - Unverified Feasibility of Remote Biometric Compliance Monitoring
The recurring revenue model depends on 'biometric confirmation of consistent immunosuppressant adherence verified monthly via remote digital monitoring'. This is critical as failure invalidates the contractual billing link (Decision 3). Unreliable tech or regulatory rejection by NZ HDC risks subscription viability.

Recommendation: Launch parallel Proof-of-Concept (PoC) to confirm technical viability and regulatory acceptability of remote adherence monitoring *before* locking in the 3-year subscription. If regulatory acceptance delays past M9, default contract to a less flexible, time-based subscription for baseline cash flow.
Sensitivity: If remote monitoring fails (100% reliance), transitioning to time-based billing risks 15-25% lower compliance, reducing average LTV by 10-18% over 3 years. Development/validation cost for alternative compliance systems estimated at $2M - $4M USD.

## Issue 3 - Conflict between High-Security Facility Design and Talent Acquisition/Logistics
Security/anonymity emphasis (Decision 11) via Auckland leasing (Decision 2) conflicts with staffing needs requiring access to world-class talent (Risk 5). The assumption of 20 dedicated surgical days/month (Assumption 3) in a leased space must be verified against technical needs for high-security cryogenic storage (Decision 14) and advanced labs (Decision 10). Failure incurs schedule/cost penalties.

Recommendation: Conduct joint architectural/clinical review of top three leased properties. Establish minimum verifiable square footage/utility load for Layer-4 biosecurity (Assumption 5) and lab infrastructure. If Auckland sites cannot meet 20-day uptime vs. security partitioning, re-evaluate Decision 2 (built vs. retrofitted facility cost).
Sensitivity: Retrofitting increasing CapEx by 15% ($5.4M) or granting only 15 days/month access (25% reduction) constrains surgical throughput, potentially reducing first-year revenue by 20-30% (1-2 transplants/surgeon).

## Review conclusion
The 'Builder's Foundation' strategy mitigates ethical/spending risks by leasing/outsourcing oversight. Three critical commercial vulnerabilities exist: 1) Revenue assumptions (low maintenance fee, 3-year term) inadequately service high fixed costs. 2) Recurring revenue hinges on unproven remote biometric verification technology. 3) Facility design tension exists between security mandates and dedicated surgical uptime/technical infrastructure. Immediate focus must be on validating revenue mechanics and confirming facility readiness against technical requirements.