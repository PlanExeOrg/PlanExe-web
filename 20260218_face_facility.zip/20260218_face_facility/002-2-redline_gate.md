**Verdict:** 🔴 REFUSE

**Rationale:** This request involves a facility for face transplants, which raises ethical and medical safety concerns.

### Violation Details

| Detail                | Value |
|-----------------------|-------|
| **Category**              | Medical Risk |
| **Claim**                 | Unethical face transplant facility. |
| **Capability Uplift**     | Yes |
| **Severity**              | High |