
## Audit - Corruption Risks

- Kickbacks or bribes offered to members of the outsourced International Ethics Review Consortium to expedite approval of questionable patient screening cases or Tissue Acquisition Protocols.
- Nepotism or conflicts of interest in the selection of the three core surgeons or support staff, potentially favoring unqualified individuals who offer financial inducements or are connected to facility management.
- Misuse of the 'substantial, non-financial restorative benefits' offered to donor families (Decision 4) where the value is inflated or improperly allocated to secure tissue that might otherwise be ineligible.
- Trading of favors between facility management and local New Zealand regulators (HDEC/MCNZ) to bypass mandated high-security requirements for the leased Auckland facility or to fast-track permits.
- Misappropriation of funds allocated for specialized equipment procurement (part of the $36M CapEx) where vendors provide kickbacks for inflated contract values on hardware or laboratory services.

## Audit - Misallocation Risks

- Misuse of the $18M initial OpEx runway by treating it as generalized operating capital rather than strictly maintaining the 18-month runway assumption, leading to premature cash flow issues if patient uptake is slow.
- Double spending on specialized surgical/laboratory equipment where redundant systems are purchased—one for the core facility and another for an unapproved secondary site or personal use by core surgeons.
- Excessive allocation of capital ($36M CapEx) towards aesthetic over-engineering of the facility's 'anonymity' requirements (Decision 11) at the expense of critical contingency funds or proven immunosuppression technology upgrades.
- Unauthorized use of staff time (paid via fixed salary contracts) allocated for facility operations (20 dedicated surgical days/month) on external, unapproved consulting or research for personal gain.
- Misreporting of compliance monitoring status for billing purposes; facility staff overriding the outputs of the remote digital adherence monitoring system to trigger subscription fees for non-compliant recipients, directly violating the compliance-contingent fee structure.

## Audit - Procedures

- Quarterly financial audits specifically scrutinizing expenditures against the $36M CapEx budget, verifying procurement receipts against long-term asset tracking, with a threshold review on all equipment purchases exceeding $100,000 USD.
- Bi-annual operational audits focused on the compliance workflow: testing the linkage between the remote digital adherence monitoring system and the subscription billing trigger mechanism (a high-risk area), ensuring no manual overrides occur without senior management sign-off and documented justification.
- Periodic contract audits of the three core surgeons' contracts to verify adherence to the five-year fixed salary terms and track the performance bonus metrics tied to knowledge transfer, mitigating staffing risk.
- Post-procedure audit cycle assessing the Donor/Recipient Pairing Protocol implementation, verifying that all documented implantations adhered strictly to the 'maximal compatible matching' criteria selected, cross-referencing clinical records against donor log data (Tissue Acquisition Protocol audit).
- Independent assurance review of Donor Family Relationship Manager activities (Decision 4) biannually to verify that 'substantial, non-financial restorative benefits' are applied ethically and as contracted, rather than being converted into undisclosed cash equivalents.

## Audit - Transparency Measures

- Publish quarterly financial reports summarizing utilization of the $90M budget, detailing CapEx vs. OpEx allocation against assumptions, focusing on the burn rate tracking for the pre-revenue phase, available to key registered stakeholders.
- Establish legally binding, anonymized progress dashboards accessible to the International Ethics Review Consortium detailing aggregate tissue utilization rates, donor tissue procurement success, and complications within the two-year inventory window.
- Mandatory publication of the minutes from the internal governance body responsible for reviewing all exceptions to the Donor/Recipient Pairing Protocol, focusing specifically on any variance from the 'maximal compatible' standard.
- Implementation of an anonymous, independently managed whistleblower channel (linked to the outsourced Ethics Consortium) specifically designed for staff to report concerns regarding tissue sourcing ethics or manipulation of patient compliance data for billing purposes.
- Publicly document and maintain a live version of the ethical screening and consent documentation (as vetted by the international consortium) on the project website, ensuring potential subscribers understand the high-intensity screening process mandated.