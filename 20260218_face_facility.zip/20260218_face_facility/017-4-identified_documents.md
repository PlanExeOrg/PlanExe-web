
## Documents to Create

### 1. Project Charter

**ID:** b2aa5a4a-f722-4573-a020-57478ea88c86

**Description:** A formal document that authorizes the project, defines its objectives, and outlines the roles and responsibilities of key stakeholders. This Project Charter will focus on the establishment of a commercial face transplantation facility in New Zealand with a subscription-based face swapping service. It will define the project's scope, objectives, and governance structure, including ethical considerations and regulatory compliance.

**Responsible Role Type:** Project Manager

**Primary Template:** PMI Project Charter Template

**Steps:**

- Define project objectives and scope.
- Identify key stakeholders and their roles.
- Establish project governance structure.
- Outline high-level budget and timeline.
- Obtain approval from key stakeholders.

**Approval Authorities:** CEO, Board of Directors

### 2. Risk Register

**ID:** 7cbd1f51-7401-4d55-895e-c9652ef7beba

**Description:** A comprehensive log of identified risks associated with the project, including their potential impact, likelihood, and mitigation strategies. This Risk Register will specifically address risks related to regulatory approval, ethical concerns, technical complications, financial viability, donor face acquisition, psychological impact, and data privacy. It will also include mitigation strategies for each identified risk.

**Responsible Role Type:** Risk Manager

**Primary Template:** ISO 31000 Risk Management Template

**Steps:**

- Identify potential risks through brainstorming and expert consultation.
- Assess the likelihood and impact of each risk.
- Develop mitigation strategies for each risk.
- Assign responsibility for monitoring and managing each risk.
- Regularly review and update the Risk Register.

**Approval Authorities:** Project Manager, Risk Committee

### 3. Communication Plan

**ID:** 1c2564d2-e650-4dc0-bf4a-2ca3c04ebcd9

**Description:** A detailed plan outlining how project information will be communicated to stakeholders, including the frequency, method, and responsible party for each communication. This Communication Plan will address communication with regulatory bodies, patients, donor families, investors, and the general public. It will also outline strategies for managing public relations and addressing ethical concerns.

**Responsible Role Type:** Communication Specialist

**Primary Template:** Project Management Communication Plan Template

**Steps:**

- Identify key stakeholders and their communication needs.
- Define communication channels and frequency.
- Assign responsibility for each communication activity.
- Establish a process for managing communication feedback.
- Regularly review and update the Communication Plan.

**Approval Authorities:** Project Manager, Head of Public Relations

### 4. Stakeholder Engagement Plan

**ID:** f3b599e4-c3d9-4570-9585-26064e172037

**Description:** A plan outlining how stakeholders will be engaged throughout the project lifecycle, including strategies for managing their expectations and addressing their concerns. This Stakeholder Engagement Plan will focus on engaging with regulatory bodies, patients, donor families, investors, and the general public. It will also outline strategies for managing ethical concerns and building trust with stakeholders.

**Responsible Role Type:** Stakeholder Manager

**Primary Template:** Project Management Stakeholder Engagement Plan Template

**Steps:**

- Identify key stakeholders and their interests.
- Assess stakeholder influence and impact.
- Develop engagement strategies for each stakeholder group.
- Establish a process for managing stakeholder feedback.
- Regularly review and update the Stakeholder Engagement Plan.

**Approval Authorities:** Project Manager, Head of Public Relations

### 5. Change Management Plan

**ID:** 734df1be-c549-4b01-9f66-9623ae2c6afc

**Description:** A plan outlining how changes to the project will be managed, including the process for requesting, evaluating, and implementing changes. This Change Management Plan will address changes to the project scope, budget, timeline, and resources. It will also outline strategies for managing the impact of changes on stakeholders.

**Responsible Role Type:** Change Manager

**Primary Template:** Project Management Change Management Plan Template

**Steps:**

- Establish a change control board.
- Define the process for requesting and evaluating changes.
- Assess the impact of each change on the project.
- Implement approved changes.
- Communicate changes to stakeholders.

**Approval Authorities:** Change Control Board, Project Manager

### 6. High-Level Budget/Funding Framework

**ID:** 834ed053-8aa8-48af-aee7-3c20c751a320

**Description:** A high-level overview of the project's budget, including estimated costs for facility construction, staffing, regulatory compliance, and ongoing operations. This framework will also outline potential funding sources, such as investors, grants, and revenue from the subscription model. It will provide a basis for developing a detailed financial model.

**Responsible Role Type:** Financial Analyst

**Primary Template:** Project Budget Template

**Steps:**

- Estimate costs for each project activity.
- Identify potential funding sources.
- Develop a high-level budget overview.
- Obtain approval from key stakeholders.
- Regularly review and update the budget framework.

**Approval Authorities:** CFO, Board of Directors

### 7. Funding Agreement Structure/Template

**ID:** a7b85999-cce8-4b27-ae37-768b1527bace

**Description:** A template for structuring funding agreements with investors, outlining the terms and conditions of the investment, including equity stakes, repayment schedules, and reporting requirements. This template will be used to secure funding for the project and ensure that the terms of the investment are clearly defined.

**Responsible Role Type:** Legal Counsel

**Primary Template:** Standard Investment Agreement Template

**Steps:**

- Consult with legal counsel to develop a standard funding agreement template.
- Define the terms and conditions of the investment.
- Outline reporting requirements for investors.
- Obtain approval from key stakeholders.
- Regularly review and update the funding agreement template.

**Approval Authorities:** Legal Counsel, CFO

### 8. Initial High-Level Schedule/Timeline

**ID:** 9654bd16-74ac-4cbf-83e7-fd8654818964

**Description:** A high-level timeline outlining the key milestones and activities for the project, including regulatory approval, facility construction, staff training, and the launch of the subscription service. This timeline will provide a roadmap for the project and help to track progress.

**Responsible Role Type:** Project Scheduler

**Primary Template:** Gantt Chart Template

**Steps:**

- Identify key project milestones and activities.
- Estimate the duration of each activity.
- Sequence activities and create a project timeline.
- Obtain approval from key stakeholders.
- Regularly review and update the project timeline.

**Approval Authorities:** Project Manager, CEO

### 9. M&E Framework

**ID:** 931ed1a4-78ae-40f5-b90c-42e7d621469a

**Description:** A framework for monitoring and evaluating the project's progress and impact, including key performance indicators (KPIs) and data collection methods. This M&E Framework will focus on tracking regulatory compliance, patient satisfaction, donor face acquisition, financial performance, and ethical considerations. It will provide a basis for making data-driven decisions and ensuring that the project is achieving its objectives.

**Responsible Role Type:** M&E Specialist

**Primary Template:** Logical Framework Template

**Steps:**

- Define project objectives and outcomes.
- Identify key performance indicators (KPIs).
- Develop data collection methods.
- Establish a process for analyzing and reporting data.
- Regularly review and update the M&E Framework.

**Approval Authorities:** Project Manager, Head of Research

### 10. Risk Mitigation Protocol

**ID:** 44a67dca-df83-4279-a16a-c0f6c1c26e2a

**Description:** A framework for minimizing potential legal, financial, and reputational risks associated with face transplantation. It controls the implementation of safety measures, informed consent processes, and insurance coverage. Success is measured by the reduction in legal claims, insurance payouts, and negative publicity. The objective is to create a safe and responsible environment for both patients and the organization, ensuring long-term sustainability and public trust.

**Responsible Role Type:** Risk Manager

**Primary Template:** Risk Management Plan Template

**Steps:**

- Identify potential risks associated with face transplantation.
- Assess the likelihood and impact of each risk.
- Develop mitigation strategies for each risk.
- Assign responsibility for monitoring and managing each risk.
- Establish a process for reviewing and updating the Risk Mitigation Protocol.

**Approval Authorities:** Risk Committee, Legal Counsel

### 11. Operational Scalability Model

**ID:** e1f97527-ba5a-4677-b8af-9f7e8e1a317b

**Description:** A model defining how the face transplantation facility will expand its operations to meet growing demand. It controls the infrastructure, staffing, and standardization of procedures. The objective is to achieve efficient growth while maintaining quality and safety. Key success metrics include the number of procedures performed, patient satisfaction, and cost per procedure. This lever determines the organization's capacity to serve a larger market.

**Responsible Role Type:** Operations Manager

**Primary Template:** Business Scalability Model Template

**Steps:**

- Assess current operational capacity.
- Forecast future demand for face transplantation services.
- Develop a plan for scaling infrastructure, staffing, and procedures.
- Identify key performance indicators (KPIs) for measuring scalability.
- Establish a process for reviewing and updating the Operational Scalability Model.

**Approval Authorities:** Operations Committee, CEO

### 12. Ethical Oversight Strategy

**ID:** 9c41f3ae-6aac-49a4-b1be-3862a1447ffc

**Description:** A framework for addressing the complex moral implications of face transplantation. It controls the ethical review process, patient autonomy, and public perception. The objective is to ensure responsible innovation and maintain public trust. Key success metrics include patient satisfaction, ethical compliance, and positive media coverage. This lever guides the organization's ethical decision-making and promotes transparency.

**Responsible Role Type:** Ethics Review Board Coordinator

**Primary Template:** Ethical Framework Template

**Steps:**

- Establish an ethics review board.
- Develop ethical guidelines for patient selection, consent, and data handling.
- Establish a process for reviewing and addressing ethical concerns.
- Identify key performance indicators (KPIs) for measuring ethical compliance.
- Establish a process for reviewing and updating the Ethical Oversight Strategy.

**Approval Authorities:** Ethics Review Board, Legal Counsel

### 13. Regulatory Approval Strategy

**ID:** 321dec0a-4aab-4bde-b9bf-5acef5ba33b0

**Description:** A strategy defining the approach to obtaining necessary approvals from regulatory bodies. It controls compliance efforts, engagement with regulators, and jurisdictional selection. The objective is to secure the legal right to operate the face transplantation facility. Key success metrics include the speed and success rate of regulatory applications. This lever determines the organization's ability to legally offer its services.

**Responsible Role Type:** Regulatory Affairs Manager

**Primary Template:** Regulatory Compliance Plan Template

**Steps:**

- Identify all necessary regulatory approvals.
- Develop a plan for engaging with regulatory bodies.
- Prepare documentation for regulatory applications.
- Monitor the progress of regulatory applications.
- Establish a process for reviewing and updating the Regulatory Approval Strategy.

**Approval Authorities:** Legal Counsel, CEO

### 14. Technological Development Approach

**ID:** bd5041f8-c700-46f6-bc69-e90d3ebb80de

**Description:** A strategy dictating the approach for advancing the face transplantation technology. It controls the level of investment and focus on different technological areas, ranging from incremental improvements to radical disruptions. The objective is to improve transplant outcomes, reduce risks, and potentially overcome limitations like donor scarcity. Success is measured by improvements in surgical techniques, reduced rejection rates, and the successful integration of new technologies.

**Responsible Role Type:** Chief Technology Officer

**Primary Template:** Technology Roadmap Template

**Steps:**

- Assess current technological capabilities.
- Identify areas for technological improvement.
- Develop a plan for investing in technological development.
- Establish key performance indicators (KPIs) for measuring technological progress.
- Establish a process for reviewing and updating the Technological Development Approach.

**Approval Authorities:** Technology Committee, CEO

### 15. Operational Efficiency Strategy

**ID:** ab583cb9-2d19-4e4a-a02a-e5a74c05531f

**Description:** A strategy focusing on optimizing resource allocation and streamlining processes to minimize costs and maximize throughput. It controls administrative procedures, surgical techniques, and supply chain management. The objective is to achieve a cost-effective and efficient operation. Key success metrics include cost per procedure, surgical time, and patient turnover rate. This lever drives the organization's profitability and competitiveness.

**Responsible Role Type:** Operations Manager

**Primary Template:** Operational Efficiency Plan Template

**Steps:**

- Assess current operational efficiency.
- Identify areas for improvement.
- Develop a plan for optimizing resource allocation and streamlining processes.
- Establish key performance indicators (KPIs) for measuring operational efficiency.
- Establish a process for reviewing and updating the Operational Efficiency Strategy.

**Approval Authorities:** Operations Committee, CFO

### 16. Market Validation Strategy

**ID:** 6de9f0ef-d043-43c1-aade-d823747ce438

**Description:** A strategy defining how the face transplantation service is introduced to the market. It controls the scope and pace of service rollout, ranging from a limited pilot program to an open access model. The objective is to assess market demand, gather feedback, and refine the service offering while managing risks and ethical considerations. Success is measured by customer satisfaction, adoption rates, and the ability to address potential ethical concerns.

**Responsible Role Type:** Chief Marketing Officer

**Primary Template:** Market Validation Plan Template

**Steps:**

- Assess market demand for face transplantation services.
- Develop a plan for introducing the service to the market.
- Establish key performance indicators (KPIs) for measuring market validation.
- Establish a process for gathering feedback from customers.
- Establish a process for reviewing and updating the Market Validation Strategy.

**Approval Authorities:** Marketing Committee, CEO

### 17. Subscription Model Design

**ID:** 7df8263f-630e-4c96-925a-7acb66d5168d

**Description:** A design determining the structure and pricing of the face-wearing subscription service. It controls the level of access, customization, and pricing options available to subscribers. The objective is to maximize revenue, attract a diverse customer base, and ensure fair compensation for face donors. Success is measured by subscription rates, customer retention, and revenue generated, as well as donor satisfaction.

**Responsible Role Type:** Product Manager

**Primary Template:** Subscription Model Canvas

**Steps:**

- Define the target customer base.
- Develop different subscription tiers with varying levels of access and customization.
- Establish pricing for each subscription tier.
- Establish a process for compensating face donors.
- Establish a process for reviewing and updating the Subscription Model Design.

**Approval Authorities:** Product Committee, CFO

### 18. Current State Assessment of Face Transplantation

**ID:** 7beeaf4e-f1ee-4f55-a725-29473e67acf1

**Description:** A report summarizing the current state of face transplantation, including surgical techniques, immunosuppression protocols, ethical considerations, and regulatory landscape. This assessment will provide a baseline for the project and help to identify areas for improvement.

**Responsible Role Type:** Research Analyst

**Primary Template:** SWOT Analysis Template

**Steps:**

- Conduct a literature review on face transplantation.
- Consult with experts in the field.
- Summarize the current state of face transplantation.
- Identify areas for improvement.
- Obtain approval from key stakeholders.

**Approval Authorities:** Chief Medical Officer, Head of Research

### 19. Donor Face Acquisition and Preservation Plan

**ID:** 3af44de7-707e-41c6-96a5-0625a573b76a

**Description:** A detailed plan for acquiring and preserving donor faces, including partnerships with organ donation organizations, ethical consent protocols, detailed transportation logistics, advanced preservation techniques, and a robust inventory management system. This plan is crucial for ensuring a steady supply of faces, impacting operational capacity and financial viability.

**Responsible Role Type:** Donor Relations & Acquisition Specialist

**Primary Template:** Organ Procurement Protocol Template

**Steps:**

- Establish partnerships with organ donation organizations, hospitals, and mortuaries.
- Develop ethical consent protocols for face donation.
- Develop a detailed transportation plan for rapid and secure transfer of donor faces.
- Invest in advanced preservation techniques.
- Implement a robust inventory management system.

**Approval Authorities:** Head of Operations, Ethics Review Board

### 20. Psychological Support Program

**ID:** 9bffb2cd-c33a-4f87-aecb-567718107a31

**Description:** A comprehensive program addressing the mental health needs of face transplant recipients and donor families, including pre-transplant counseling, post-transplant therapy, donor family support, psychiatric assessments, ethical guidelines for managing psychological issues, and a supportive community for recipients and donor families.

**Responsible Role Type:** Patient Liaison & Psychological Support Coordinator

**Primary Template:** Mental Health Support Program Template

**Steps:**

- Engage with experienced psychologists and psychiatrists specializing in transplantation and identity issues.
- Conduct a comprehensive literature review on the psychological impact of face transplantation.
- Develop a detailed psychological support program.
- Establish partnerships with mental health organizations and community support groups.
- Collect and provide data on the proposed psychological support program.

**Approval Authorities:** Chief Medical Officer, Ethics Review Board

### 21. Data Privacy and Security Plan

**ID:** f59b3798-5003-496e-94df-f54fc553ea21

**Description:** A comprehensive plan for protecting patient data and complying with regulations, including a compliance assessment of applicable data privacy regulations, data encryption techniques, strict access controls, a data breach response plan, regular security audits, and comprehensive employee training.

**Responsible Role Type:** Data Security & Privacy Officer

**Primary Template:** Data Security Plan Template

**Steps:**

- Conduct a thorough assessment of all applicable data privacy regulations.
- Implement robust data encryption techniques.
- Implement strict access controls.
- Develop a detailed data breach response plan.
- Conduct regular security audits.

**Approval Authorities:** Chief Technology Officer, Legal Counsel

## Documents to Find

### 1. New Zealand Ministry of Health Regulations

**ID:** 27d85bbf-7f94-4fed-8260-50c1b2dbd29d

**Description:** Regulations and guidelines issued by the New Zealand Ministry of Health pertaining to medical facilities, surgical procedures, and patient care. These regulations are crucial for ensuring compliance and obtaining necessary approvals for the face transplantation facility. Intended audience: Regulatory Affairs Manager, Legal Counsel.

**Recency Requirement:** Current regulations essential

**Responsible Role Type:** Regulatory Affairs Manager

**Access Difficulty:** Medium: Requires navigating government websites and potentially contacting the Ministry of Health directly.

**Steps:**

- Search the New Zealand Ministry of Health website.
- Contact the Ministry of Health directly.
- Consult with legal experts specializing in healthcare regulations.

### 2. New Zealand Medsafe Guidelines

**ID:** e6b9856b-c756-4eca-8537-9a88d4894812

**Description:** Guidelines issued by Medsafe, the New Zealand Medicines and Medical Devices Safety Authority, pertaining to medical devices and surgical procedures. These guidelines are crucial for ensuring compliance and obtaining necessary approvals for the face transplantation facility. Intended audience: Regulatory Affairs Manager, Legal Counsel.

**Recency Requirement:** Current guidelines essential

**Responsible Role Type:** Regulatory Affairs Manager

**Access Difficulty:** Medium: Requires navigating government websites and potentially contacting Medsafe directly.

**Steps:**

- Search the Medsafe website.
- Contact Medsafe directly.
- Consult with legal experts specializing in healthcare regulations.

### 3. New Zealand Organ Donation and Transplantation Policies

**ID:** bf18d8d3-cc21-4aca-b1af-9103aed4faab

**Description:** Policies and guidelines related to organ donation and transplantation in New Zealand, including consent protocols, ethical considerations, and logistical requirements. These policies are crucial for developing a robust and ethical donor face acquisition plan. Intended audience: Donor Relations & Acquisition Specialist, Ethics Review Board Coordinator.

**Recency Requirement:** Current policies essential

**Responsible Role Type:** Donor Relations & Acquisition Specialist

**Access Difficulty:** Medium: Requires navigating government websites and potentially contacting the Organ Donation Service directly.

**Steps:**

- Search the New Zealand Organ Donation Service website.
- Contact the New Zealand Organ Donation Service directly.
- Consult with ethicists specializing in organ donation.

### 4. New Zealand Data Privacy Laws and Regulations

**ID:** 503245df-a067-41ca-9952-c439c53016fe

**Description:** Laws and regulations related to data privacy in New Zealand, including the Health Information Privacy Code and the Privacy Act. These laws are crucial for ensuring compliance and protecting patient data. Intended audience: Data Security & Privacy Officer, Legal Counsel.

**Recency Requirement:** Current laws and regulations essential

**Responsible Role Type:** Data Security & Privacy Officer

**Access Difficulty:** Medium: Requires navigating government websites and consulting legal resources.

**Steps:**

- Search the New Zealand Privacy Commissioner website.
- Consult with legal experts specializing in data privacy law.
- Review relevant legislation and case law.

### 5. New Zealand Ethical Guidelines for Medical Research

**ID:** 9d4a70e0-43d5-4d1b-aa3a-c9366bc6ae2b

**Description:** Ethical guidelines for medical research in New Zealand, including guidelines for informed consent, patient autonomy, and data handling. These guidelines are crucial for ensuring ethical conduct and protecting patient rights. Intended audience: Ethics Review Board Coordinator, Chief Medical Officer.

**Recency Requirement:** Current guidelines essential

**Responsible Role Type:** Ethics Review Board Coordinator

**Access Difficulty:** Medium: Requires navigating government websites and consulting ethical resources.

**Steps:**

- Search the New Zealand Ministry of Health website.
- Consult with ethicists specializing in medical research.
- Review relevant ethical codes and guidelines.

### 6. New Zealand Mental Health Act

**ID:** 58f83615-ab16-4d3a-9e14-4b1ca8dde420

**Description:** Legislation governing mental health services and patient rights in New Zealand. This act is relevant to the psychological support program and ensuring appropriate care for patients and donor families. Intended audience: Patient Liaison & Psychological Support Coordinator, Legal Counsel.

**Recency Requirement:** Current legislation essential

**Responsible Role Type:** Patient Liaison & Psychological Support Coordinator

**Access Difficulty:** Medium: Requires navigating government websites and consulting legal resources.

**Steps:**

- Search the New Zealand Legislation website.
- Consult with legal experts specializing in mental health law.
- Review relevant case law.

### 7. Participating Nations Organ Donation Rates Statistical Data

**ID:** 637a3e70-7c44-4750-8773-daea2505e75f

**Description:** Statistical data on organ donation rates in New Zealand and other relevant countries. This data is crucial for assessing the feasibility of acquiring donor faces and developing a robust donor acquisition plan. Intended audience: Donor Relations & Acquisition Specialist, Research Analyst.

**Recency Requirement:** Most recent available year

**Responsible Role Type:** Research Analyst

**Access Difficulty:** Medium: Requires navigating websites and potentially contacting organizations directly.

**Steps:**

- Search the Australia and New Zealand Organ Donation Registry (ANZOD) website.
- Search the Global Observatory on Donation and Transplantation (GODT) website.
- Contact organ donation organizations directly.

### 8. Existing New Zealand Healthcare Insurance Policies

**ID:** 17b9563d-b406-442a-8234-92845d57bca4

**Description:** Information on existing healthcare insurance policies in New Zealand, including coverage for transplant procedures and related services. This information is crucial for developing a financial model and assessing the affordability of the subscription service. Intended audience: Financial Analyst, Insurance Specialist.

**Recency Requirement:** Most recent available

**Responsible Role Type:** Financial Analyst

**Access Difficulty:** Easy: Publicly available information on insurance company websites.

**Steps:**

- Search insurance company websites.
- Contact insurance brokers directly.
- Review government healthcare policies.

### 9. New Zealand Medical Facility Licensing Requirements

**ID:** 0a6f0349-c615-4bb9-972b-7e908197c175

**Description:** Specific requirements for licensing a medical facility in New Zealand, including building codes, safety standards, and staffing requirements. This information is crucial for planning the construction and operation of the face transplantation facility. Intended audience: Facility Operations Manager, Regulatory Affairs Manager.

**Recency Requirement:** Current requirements essential

**Responsible Role Type:** Facility Operations Manager

**Access Difficulty:** Medium: Requires navigating government websites and potentially contacting local authorities.

**Steps:**

- Search the New Zealand Ministry of Health website.
- Contact local building authorities.
- Consult with architects and engineers specializing in medical facilities.

### 10. Official New Zealand Population Health Survey Data

**ID:** 06d60972-6d8e-4f32-bb3c-55bece90f430

**Description:** Results from official population health surveys in New Zealand, including data on mental health, body image, and attitudes towards medical procedures. This data is crucial for understanding the potential psychological impact of face transplantation and developing a comprehensive support program. Intended audience: Patient Liaison & Psychological Support Coordinator, Research Analyst.

**Recency Requirement:** Published within last 5 years

**Responsible Role Type:** Research Analyst

**Access Difficulty:** Medium: Requires navigating government websites and potentially contacting researchers.

**Steps:**

- Search the New Zealand Ministry of Health website.
- Search Statistics New Zealand website.
- Contact public health researchers.

### 11. Existing New Zealand Organ Donation Public Awareness Campaign Materials

**ID:** cda2c99b-9d96-4a26-995f-9dffbad7bede

**Description:** Materials from existing public awareness campaigns related to organ donation in New Zealand. These materials can provide insights into effective communication strategies and help to address public concerns about face transplantation. Intended audience: Community Engagement & Public Relations Specialist.

**Recency Requirement:** Most recent available

**Responsible Role Type:** Community Engagement & Public Relations Specialist

**Access Difficulty:** Easy: Publicly available information on organization websites.

**Steps:**

- Search the New Zealand Organ Donation Service website.
- Contact organ donation organizations directly.
- Review media coverage of organ donation.

### 12. Existing New Zealand Consumer Protection Laws

**ID:** ba9a32ba-ef03-4165-bdec-0c25aebb9560

**Description:** Laws related to consumer protection in New Zealand, relevant to the subscription model and ensuring fair business practices. Intended audience: Legal Counsel, Product Manager.

**Recency Requirement:** Current laws essential

**Responsible Role Type:** Legal Counsel

**Access Difficulty:** Medium: Requires navigating government websites and consulting legal resources.

**Steps:**

- Search the New Zealand Legislation website.
- Consult with legal experts specializing in consumer law.
- Review relevant case law.