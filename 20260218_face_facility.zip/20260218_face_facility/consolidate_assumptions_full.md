# Purpose

**Purpose:** business

**Purpose Detailed:** Establishing and operating a high-cost, specialized medical/cosmetic facility supported by a recurring subscription revenue model, indicating a commercial venture.

**Topic:** Facial transplant facility and subscription service

# Domain

**Primary domain:** Transplantation Surgery

**Secondary domains:** Surgical Medicine, Biomedical Ethics, Healthcare Finance

**Rationale:** Transplantation Surgery owns the core success criterion: the ability to perform the facial transplant itself. While Surgical Medicine and Plastic Surgery are related outcomes, Transplantation Surgery is most specific to the mechanism involving two individuals. Healthcare Finance is a method supporting the business model.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Surgical Medicine | 5 | 5 | outcome | The core outcome is successful, repeatable facial transplantation surgery. |
| Plastic Surgery | 5 | 5 | outcome | Plastic Surgery is central to performing the actual face transplant procedure. |
| Transplantation Surgery | 5 | 5 | outcome | The core technical outcome is successful facial transplantation between individuals. |
| Biomedical Ethics | 4 | 4 | constraint | Transplanting faces involves extreme ethical and medical risk management. |
| Bioethics Consultation | 4 | 4 | constraint | Ethical dilemmas surrounding identity and consent necessitate bioethics guidance. |
| Health Law | 4 | 4 | constraint | Operating an elective human face transplant requires adherence to NZ health regulations. |
| Healthcare Finance | 4 | 3 | method | The subscription revenue model dictates the business planning and viability. |
| Business Model Design | 4 | 3 | method | The subscription revenue model is a critical component of the business structure. |
| Commercial Law | 3 | 3 | constraint | The subscription and financial model requires complex contractual and legal framework. |

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** The plan involves establishing a physical medical facility in New Zealand specifically for performing facial transplantation surgeries. This requires securing real estate, constructing or renovating a surgical facility, acquiring specialized medical equipment, and physically operating on human subjects. Despite the financial and ethical planning elements, the core deliverable is a physical service conducted in a specific location, classifying it as unequivocally physical.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Must be located in New Zealand
- Must accommodate a high-security, specialized surgical theatre
- Must have access to high-level medical/surgical talent (Auckland preferred)
- Should be a leased facility to conserve capital within the $90M budget
- Must balance accessibility for elite clientele with operational privacy/security

## Location 1
New Zealand

Auckland

Existing, retrofitted specialized surgical theatre lease in Auckland CBD or surrounding medical hub.

**Rationale**: This is the strategically chosen location (Decision 2: Builder's Foundation). Auckland offers the best access to established surgical talent and reduces facility build-out capital expenditure by seeking a long-term lease.

## Location 2
New Zealand

Wellington

Specialized medical leasing space near the national regulatory body/ethics committees.

**Rationale**: Wellington, as the capital, provides strong institutional proximity, which is beneficial when utilizing an external ethics consortium (Decision 5) and navigating the complex legal landscape of this novel procedure.

## Location 3
New Zealand

Christchurch

University-affiliated medical research park or facility lease.

**Rationale**: Christchurch hosts robust research infrastructure and universities, providing established scientific vetting and potential pathways for sourcing non-financial restorative benefits (Decision 4) through affiliated research bodies.

## Location Summary
The primary location is mandated as Auckland, New Zealand, based on strategic decisions favoring established surgical talent access via leasing. Two alternative locations in New Zealand—Wellington (for regulatory proximity) and Christchurch (for research/ethical networking)—are suggested to provide logistical and operational flexibility.

# Currency Strategy

This plan involves money.

## Currencies

- **NZD:** New Zealand Dollar is the local transactional currency for facility lease, local staff salaries, and local expenses within New Zealand.
- **USD:** The project budget is established in USD ($90M USD), and major equipment purchases or international consultation fees may be denominated in USD.

**Primary currency:** USD

**Currency strategy:** Given the large initial capital budget ($90M USD) and the high-value nature of the services, USD will be used for primary budgeting and high-value purchasing. Routine local transactions (rent, local supplies) will be conducted in NZD. Given the project is centrally located in a stable economy (New Zealand), currency risk management will focus on hedging large USD-to-NZD conversions for capital deployment, rather than managing hyperinflation risk.

# Identify Risks


## Risk 1 - Regulatory & Permitting
The facility may face significant regulatory hurdles due to the experimental nature of facial transplantation. This includes obtaining necessary approvals from medical boards and ethics committees, which can delay the project.

**Impact:** Delays in regulatory approval could result in a project timeline extension of 6–12 months, leading to potential financial overruns of $5M–$10M USD due to extended operational costs and lost revenue opportunities.

**Likelihood:** High

**Severity:** High

**Action:** Engage with regulatory bodies early in the planning process to understand requirements and streamline the approval process. Consider hiring a regulatory consultant with experience in medical innovations.

## Risk 2 - Technical
The complexity of facial transplantation procedures may lead to unforeseen technical challenges, including complications during surgeries or issues with immunosuppression regimens.

**Impact:** Surgical complications could lead to increased patient recovery times, resulting in a potential delay of 2–4 weeks per patient and additional costs of $10,000–$20,000 USD per complication due to extended hospital stays and additional treatments.

**Likelihood:** Medium

**Severity:** High

**Action:** Implement rigorous training programs for surgical staff and establish a detailed protocol for managing complications. Consider phased rollouts of procedures to mitigate risks.

## Risk 3 - Financial
The reliance on a subscription model may not generate the expected revenue if patient uptake is lower than anticipated, especially given the high costs associated with the procedures.

**Impact:** If subscription rates fall short, the facility may face a revenue shortfall of $2M–$5M USD annually, jeopardizing operational sustainability and the ability to cover fixed costs.

**Likelihood:** Medium

**Severity:** High

**Action:** Conduct market research to better understand potential customer demographics and willingness to pay. Develop flexible pricing strategies to attract a broader audience.

## Risk 4 - Ethical
The ethical implications of facial transplantation may lead to public backlash or negative media coverage, impacting the facility's reputation and patient enrollment.

**Impact:** Negative publicity could result in a 30% decrease in patient enrollment, translating to a potential revenue loss of $3M–$6M USD in the first year.

**Likelihood:** High

**Severity:** Medium

**Action:** Develop a comprehensive public relations strategy to address ethical concerns and promote the benefits of the procedure. Engage with community stakeholders to build trust.

## Risk 5 - Operational
The facility may struggle with staffing challenges, including recruiting and retaining specialized surgical talent, which is critical for operational success.

**Impact:** Staffing shortages could lead to delays in procedures and increased operational costs, potentially resulting in a 10% increase in labor costs, estimated at $1M USD annually.

**Likelihood:** Medium

**Severity:** High

**Action:** Create competitive compensation packages and professional development opportunities to attract and retain top talent. Consider partnerships with medical schools for recruitment.

## Risk 6 - Supply Chain
Challenges in sourcing high-quality donor tissues ethically and reliably could disrupt the surgical schedule and impact patient outcomes.

**Impact:** Supply chain disruptions could lead to a 20% reduction in available surgeries, resulting in a revenue loss of $1M–$2M USD annually due to missed opportunities.

**Likelihood:** Medium

**Severity:** High

**Action:** Establish multiple sourcing agreements with ethical tissue banks and develop a robust logistics plan to ensure a steady supply of donor tissues.

## Risk 7 - Social
Public perception of facial transplantation as a cosmetic procedure rather than a medical necessity may limit the patient base and subscription uptake.

**Impact:** If public perception remains negative, the facility could see a 25% lower patient enrollment than projected, leading to a potential revenue loss of $2M USD in the first year.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Engage in community outreach and education campaigns to clarify the medical benefits of the procedure and address misconceptions.

## Risk 8 - Security
The sensitive nature of the procedures and patient data may expose the facility to cybersecurity threats and data breaches.

**Impact:** A data breach could result in legal liabilities and loss of patient trust, potentially costing $500,000–$1M USD in legal fees and remediation efforts.

**Likelihood:** Medium

**Severity:** High

**Action:** Implement robust cybersecurity measures and regular audits to protect patient data and ensure compliance with data protection regulations.

## Risk summary
The project faces significant risks across multiple domains, particularly in regulatory, technical, and financial areas. The most critical risks include regulatory hurdles that could delay the project and ethical concerns that may impact public perception and patient enrollment. Effective mitigation strategies, including early engagement with regulators and comprehensive public relations efforts, are essential to navigate these challenges and ensure the project's success.

# Make Assumptions


## Question 1 - Given the $90M USD budget and the lease strategy in Auckland, what initial capital expenditure (CapEx) allocation is planned for specialized surgical equipment and initial operating expenses (OpEx) necessary before first subscription revenue triggers?

**Assumptions:** Assumption: Based on industry benchmarks for specialized medical facilities, 40% of the $90M budget ($36M USD) will be allocated to initial CapEx (equipment, specialized fit-out within the leasehold) and 20% ($18M USD) to cover initial OpEx runway (staff salaries, insurance) for the 12 months prior to positive cash flow.

**Assessments:** Title: Financial Runway Assessment
Description: Evaluation of the initial capital drain against the project timeline.
Details: Allocating $54M USD to pre-revenue activities aligns with a prudent approach, supporting the $90M budget constraint by leaving $36M for contingencies and post-launch scale-up. Risk mitigation requires mandatory monthly tracking of burn rate against the $1.5M/month projected OpEx to ensure the 12-month runway is not breached, especially considering regulatory delays (Risk 1).

## Question 2 - Considering the 'low monthly maintenance fee' subscription model, what specific definition of 'compliance monitoring' will trigger the recurring payment cycle, and what is the targeted duration of mandatory subscription (Face-Wearing Duration)?

**Assumptions:** Assumption: Compliance monitoring triggers will be defined by biometric confirmation of consistent immunosuppressant adherence verified monthly via remote digital monitoring, aligned with Decision 3. The targeted minimum Recipient Face-Wearing Duration will be set at 3 years to establish initial revenue LTV stability.

**Assessments:** Title: Revenue Stability and LTV Projection
Description: Analysis of the contractual framework defining recurring income.
Details: Linking payments to verifiable immunosuppressant adherence (technical feasibility must be confirmed) provides a strong justification for the 'maintenance fee.' A 3-year duration yields an estimated minimum LTV per customer, which must be calculated against the projected cost-of-service (CoS) per patient to ensure the projected $2M-$5M annual revenue gap (Risk 3) is demonstrably closed by year 2.

## Question 3 - What concrete steps are established within the Auckland lease strategy to ensure the hired core surgical team (Staffing Model) has access to the facility's required specialized operational uptime, respecting the non-aggressive scenario constraint?

**Assumptions:** Assumption: The leased facility lease agreement must guarantee a minimum of 20 dedicated surgical days per month for high-complexity procedures, covering 3 core surgeons and essential support staff. This uptime is sufficient for scheduling 2-3 major procedures monthly, adhering to the non-aggressive scenario.

**Assessments:** Title: Operational Capacity Planning
Description: Assessment of facility access adequacy for the core clinical team.
Details: Securing fixed, dedicated surgical time in the leased Auckland theatre is critical to mitigating staffing shortages (Risk 5). Negotiations must prioritize primary access over shared hospital time. Opportunity exists to partner with the lessor for guaranteed maintenance windows, preventing infrastructure upgrades (Decision 13) from impacting critical surgical schedules.

## Question 4 - How will the outsourced international ethical review panel (Ethical Gatekeeping) interface logistically and legally with New Zealand's national medical oversight bodies to secure necessary operational permits (Governance & Regulations)?

**Assumptions:** Assumption: A dedicated Legal/Governance Liaison will be appointed to manage the formal recognition process, establishing memoranda of understanding (MOUs) between the independent review consortium and New Zealand's Health Practitioners Disciplinary Tribunal/HDEC within the first 9 months.

**Assessments:** Title: Regulatory Compliance Pathway
Description: Mapping the interface between external ethics governance and local compliance.
Details: Regulatory risk (Risk 1) is high; the success relies on bridging the gap between outsourced ethical vetting and mandated local clinical trial/procedure governance. A dedicated liaison is essential to translate external validation into local permits. Failure here stalls the entire timeline, requiring a contingency budget ($1M-$2M) for specialist regulatory law counsel.

## Question 5 - What specific safety protocols will govern the handling, preservation, and tracking of procured facial tissues to meet the requirements mandated by New Zealand's Health and Disability Commissioner regarding biological material (Safety & Risk Management)?

**Assumptions:** Assumption: All tissue handling, matching, and storage will adhere strictly to standards equivalent to those governing allogeneic organ transplantation in NZ/AU, plus an additional proprietary Layer-4 biosecurity standard for facial tissue viability, directly addressing the need for high-security/privacy.

**Assessments:** Title: Bio-Security and Protocol Integrity
Description: Establishing safety benchmarks for all tissue handling.
Details: Adherence to existing high standards mitigates technical risk (Risk 2) associated with infection or tissue degradation. The proprietary Layer-4 protocol must be treated as a critical IP asset and requires defined training sign-offs from all relevant staff (Risk 5). Regular third-party audits of cryo-storage integrity are mandatory to prevent inventory decay (Decision 14).

## Question 6 - Given the facility is in Auckland, what is the strategy for managing the environmental impact (waste streams, energy use for high-security containment) associated with complex, multi-year patient management (Environmental Impact)?

**Assumptions:** Assumption: Facility design, informed by the lease agreement, must incorporate medical waste neutralization systems built to exceed New Zealand's regional council hazardous waste guidelines, and energy systems must prioritize carbon offset for HVAC/cryogenic load to maintain a 'net-neutral' operational footprint within five years.

**Assessments:** Title: Sustainability and Waste Management Strategy
Description: Evaluation of required environmental controls for an experimental surgical site.
Details: High-grade medical waste and continuous power for cryo-storage (Decision 14) represent major environmental liability. Mitigation requires upfront CapEx investment in specialized HVAC/waste management within the leasehold retrofitting ($1M-$3M allocation). Achieving net-neutral status is a significant PR opportunity (counteracting Ethical Risk 4) but requires diligent long-term energy auditing.

## Question 7 - How will the facility engage with high-net-worth, privacy-seeking subscribers and the donor families (who receive non-financial benefits) to maximize positive testimonials while managing the extreme confidentiality inherent in the procedure (Stakeholder Involvement)?

**Assumptions:** Assumption: A tiered confidentiality agreement will be established: Tier 1 (Subscribers) sign 10-year Nondisclosure Agreements (NDAs), releasing controlled, anonymized testimonial data only. Tier 2 (Donors' Families) will receive dedicated Relationship Managers to ensure perceived reciprocity regarding the non-financial benefits (Decision 4).

**Assessments:** Title: Confidentiality and Stakeholder Management
Description: Balancing marketing needs with extreme client privacy requirements.
Details: Mismanagement of confidentiality is an extreme ethical/social risk (Risks 4 & 7). The strategy must guarantee zero data leakage. Positive feedback must be pre-approved and managed through legal channels—relying on controlled external testimonials rather than direct patient endorsements is safer to maintain the high-cost perception without risking patient reintegration failure.

## Question 8 - What integrated digital systems are required between the surgical theater, the bio-bank (Decision 14), and the compliance monitoring platform (Decision 2) to ensure seamless data flow and identity reconciliation post-transplant (Operational Systems)?

**Assumptions:** Assumption: A single, highly secure, locally hosted Electronic Health Record (EHR) system, compliant with NZ Privacy Act 2020, will integrate three modules: OR/Surgical Log, Cryo-Inventory Management, and Remote Patient Monitoring (RPM). System redundancy (fail-over capability planned) is mandatory for operations.

**Assessments:** Title: Integrated Technology Architecture
Description: Assessment of the digital backbone supporting surgical and billing operations.
Details: System failure or data mismatch poses high technical risk (Risk 2) and security risk (Risk 8). A unified, vetted EHR system minimizes identity risk (Decision 6). The initial $36M CapEx budget must ring-fence $5M-$7M for procurement, implementation, and two full independent security penetration tests before patient onboarding commences.

# Distill Assumptions

- $36M CapEx and $18M OpEx allocated for 12 pre-revenue months.
- Compliance triggers defined by monthly remote digital immunosuppressant adherence verification.
- Minimum mandatory subscription duration set at three years to establish LTV stability.
- Lease guarantees 20 dedicated surgical days monthly for three core surgeons.
- Legal liaison appointed to secure NZ HDEC MOUs within the first nine months.
- Tissue handling adheres to NZ/AU allogeneic organ standards plus proprietary Layer-4 biosecurity.
- Facility must neutralize waste exceeding NZ guidelines; energy aims for net-neutrality within five years.
- Subscribers sign 10-year NDAs; donor families receive dedicated relationship managers.
- A single, locally hosted EHR must integrate OR, Cryo-Inventory, and Remote Patient Monitoring systems.
- Maximal compatible matching prioritizes immune stability over cosmetic expediency.
- Auckland lease established for retrofitted theater, prioritizing capital for equipment/staffing.
- Subscription starts with a steep initial fee, followed by low monthly maintenance contingent on compliance.
- Tissue sourcing contracts offer substantial, non-financial restorative benefits to donor families.
- Ethical review outsourced to an independent international consortium for liability reduction.
- Recipient identity adopts donor face as sole legal biometric identity post-transplant.
- Core team of three surgeons hired on five-year guaranteed, high-salary contracts.
- Mandatory 18-month structured psycho-social readaptation program funded by base subscription.
- Subscription billing deferred until 90-day formal psychological and functional acceptance review.
- Complex, proprietary immunosuppressant regimens require significant capital investment.
- Tissue storage is strictly limited to a maximum viable tenure of two years.
- Post-subscription mandates downgrade contracts to subsidized 'Biological Stability Monitoring' for ten years.

# Review Assumptions

## Domain of the expert reviewer
Specialized Biomedical Project Management & High-Risk Venture Strategy

## Domain-specific considerations

- Ethical and regulatory compliance for experimental human transplantation in NZ
- High fixed-cost operational management against variable subscription revenue
- Supply chain management for scarce, high-value biological inputs (donor tissue)
- Managing extreme reputational risk inherent in cosmetic/elective high-cost surgery

## Issue 1 - Assumption of Short-Term Revenue Stability vs. High Fixed Costs
The plan assumes a 3-year minimum subscription duration and a 'low monthly maintenance fee' following a 'steep, non-refundable initial procedure fee' (Decision 3 & Assumption 2). Given the extremely high fixed costs associated with specialized facility leasing ($90M budget implies high ongoing overhead, specialized staffing on 5-year contracts, and complex lab requirements), this revenue structure introduces significant pre-profitability risk. The adequacy of the 12-month OpEx runway ($18M) following the initial procedure fee is highly sensitive to the speed of regulatory approval and patient uptake.

**Recommendation:** Immediately execute a sensitivity analysis on the required patient volume needed to break even by Month 18, given the fixed OpEx baseline ($1.5M/month). The initial fee structure must be calibrated such that the combined initial fee + 18 months of maintenance fees covers the total pre-revenue burn rate ($18M + CapEx carry-over). If the market analysis (Risk 3) suggests slower uptake than required for this break-even point, the initial fee must increase by 20-35% or the OpEx runway extended to 18 months ($27M total).

**Sensitivity:** If the required revenue per patient (Initial Fee + 36 months of Maintenance) is calculated to cover fixed costs, a 25% shortfall in initial patient acquisition (baseline: X acquired patients) will delay the point where the retained $36M contingency fund is accessed by 6-9 months. If the maintenance fee is too low, delaying ROI by 12-24 months, the project faces a capital deficit within the original $90M structure, requiring an additional capital raise estimated at $10M-$15M USD.

## Issue 2 - Unverified Feasibility of Remote Biometric Compliance Monitoring
The recurring revenue model hinges on 'biometric confirmation of consistent immunosuppressant adherence verified monthly via remote digital monitoring' (Assumption 2). This is a critical technical and regulatory assumption for a novel face transplant. If the required remote monitoring technology (e.g., integrated smart dispensing or continuous biomarker monitoring linked to the face's biometric signature) is unavailable, unreliable, or rejected by NZ regulators (Health & Disability Commissioner), the entire contractual link between service/value and billing (Decision 3) collapses, putting subscription viability at risk.

**Recommendation:** Immediately launch a parallel Proof-of-Concept (PoC) stream focused solely on confirming the technical viability and regulatory acceptability of the remote adherence monitoring system *before* locking in the 3-year subscription model. If regulatory acceptance is delayed beyond Month 9 (Assumption 4), the contract must default to a less flexible, but more conventional, time-based subscription to secure baseline cash flow, even if it negatively impacts patient perception.

**Sensitivity:** If remote monitoring fails validation (baseline: 100% reliance), transitioning to a simpler, time-based billing model could reduce compliance rates by 15-25% (due to reduced patient incentive), potentially lowering average LTV by 10-18% over the 3-year term. The cost to develop and validate alternative compliance hardware/software is estimated at $2M - $4M USD.

## Issue 3 - Conflict between High-Security Facility Design and Talent Acquisition/Logistics
The chosen strategy emphasizes security/anonymity (Decision 11), opting for a leased facility in Auckland (Decision 2). However, securing the core surgical team requires high accessibility to world-class talent (Risk 5). While Auckland is specified, the assumption guaranteeing 20 dedicated surgical days per month (Assumption 3) within a leased space (potentially shared or retrofitted) must be rigorously verified against the physical requirements for high-security cryogenic storage (Decision 14) and advanced immunosuppression labs (Decision 10). If the leased space cannot support the required technical infrastructure or dedicated uptime without compromising security/anonymity mandates, the project incurs severe schedule and cost penalties.

**Recommendation:** Conduct a joint architectural/clinical review of the top three shortlisted leased properties. Establish minimum verifiable square footage and utility load capacities required for the Layer-4 biosecurity (Assumption 5) and complex lab infrastructure. If the preferred Auckland sites cannot meet both dedicated 20-day uptime and necessary security partitioning, immediately re-evaluate Decision 2, considering the specialized construction cost of a purpose-built (but smaller) facility in a less expensive area vs. the political stability gained by staying in Auckland.

**Sensitivity:** If the required retrofitting increases build-out CapEx (from the allocated $36M) by 15% ($5.4M) due to mandated security features or if the lease agreement only grants primary access 15 days/month (a 25% reduction in surgical time), surgical throughput is immediately constrained. This limits the number of annual successful transplants by 1-2 per surgeon, potentially leading to a 20-30% revenue reduction in the first operating year based on projected volume.

## Review conclusion
The project is strategically sound in its 'Builder's Foundation' approach, mitigating the highest risks (ethical backlash, extreme spending) by leasing space and outsourcing ethical oversight. However, the plan contains three critical vulnerabilities relating to its commercial foundation. First, the initial revenue assumptions (low maintenance fee, 3-year term) do not appear robust enough to service the high fixed costs mandated by the specialized staffing and initial capital burn rate. Second, the entire recurring revenue model depends on an unproven technology assumption: remote biometric verification for compliance. Third, the tension between facility security mandates and dedicated surgical uptime/technical infrastructure required for world-class staffing has not been fully resolved within the property assumptions. Prioritizing validation of the revenue mechanics and confirming facility readiness against technical requirements should be the immediate planning focus.