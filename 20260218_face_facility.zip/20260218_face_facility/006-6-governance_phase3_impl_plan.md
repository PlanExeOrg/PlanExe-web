### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 2. Circulate Draft SteerCo ToR for review by nominated members (CEO, CFO, Chief Medical Officer, Independent Bioethicist, Legal Counsel).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager finalizes the Project Steering Committee ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. CEO formally appoints the Project Steering Committee Chair.

**Responsible Body/Role:** CEO

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Email

### 6. Hold initial Project Steering Committee kick-off meeting to review ToR, establish meeting schedule, and define reporting requirements from other governance bodies.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Approved Meeting Schedule
- Defined Reporting Requirements

**Dependencies:**

- Meeting Invitation
- Final SteerCo ToR v1.0

### 7. Project Manager defines roles and responsibilities for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Roles and Responsibilities Document

**Dependencies:**

- Project Plan Approved

### 8. Project Manager establishes communication protocols for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Communication Protocols Document

**Dependencies:**

- Core Project Team Roles and Responsibilities Document

### 9. Project Manager sets up project management tools for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Management Tool Configuration

**Dependencies:**

- Core Project Team Communication Protocols Document

### 10. Project Manager develops a detailed project schedule for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Detailed Project Schedule

**Dependencies:**

- Project Management Tool Configuration

### 11. Project Manager schedules the initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Detailed Project Schedule

### 12. Hold initial Core Project Team kick-off meeting to review roles, responsibilities, communication protocols, and project schedule.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Core Project Team Roles and Responsibilities Document
- Core Project Team Communication Protocols Document
- Detailed Project Schedule

### 13. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Steering Committee Established

### 14. Circulate Draft Ethics & Compliance Committee ToR for review by nominated members (Independent Bioethicist, Legal Counsel, Patient Advocate, Community Representative, Chief Medical Officer, Data Protection Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 15. Project Manager finalizes the Ethics & Compliance Committee ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary

### 16. Project Steering Committee formally appoints the Ethics & Compliance Committee Chair (Independent Bioethicist).

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 17. Ethics & Compliance Committee Chair schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Independent Bioethicist

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Email

### 18. Hold initial Ethics & Compliance Committee kick-off meeting to review ToR, establish meeting schedule, develop ethical guidelines and protocols, and establish a process for handling ethical complaints.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Approved Meeting Schedule
- Draft Ethical Guidelines and Protocols
- Ethical Complaint Handling Process

**Dependencies:**

- Meeting Invitation
- Final Ethics & Compliance Committee ToR v1.0

### 19. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Steering Committee Established

### 20. Circulate Draft Technical Advisory Group ToR for review by nominated members (Lead Surgeon, Experienced Transplant Surgeon, Immunologist, Microbiologist, Biomedical Engineer, Chief Technician).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1

### 21. Project Manager finalizes the Technical Advisory Group ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Final Technical Advisory Group ToR v1.0

**Dependencies:**

- Feedback Summary

### 22. Project Steering Committee formally appoints the Technical Advisory Group Chair (Lead Surgeon).

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Technical Advisory Group ToR v1.0

### 23. Technical Advisory Group Chair schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Lead Surgeon

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Email

### 24. Hold initial Technical Advisory Group kick-off meeting to review ToR, establish meeting schedule, develop technical protocols and procedures, and establish a process for monitoring technical performance.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Approved Meeting Schedule
- Draft Technical Protocols and Procedures
- Technical Performance Monitoring Process

**Dependencies:**

- Meeting Invitation
- Final Technical Advisory Group ToR v1.0