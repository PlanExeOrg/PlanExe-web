
## Question 1 - Given the $90M USD budget and the lease strategy in Auckland, what initial capital expenditure (CapEx) allocation is planned for specialized surgical equipment and initial operating expenses (OpEx) necessary before first subscription revenue triggers?

**Assumptions:** Assumption: Based on industry benchmarks for specialized medical facilities, 40% of the $90M budget ($36M USD) will be allocated to initial CapEx (equipment, specialized fit-out within the leasehold) and 20% ($18M USD) to cover initial OpEx runway (staff salaries, insurance) for the 12 months prior to positive cash flow.

**Assessments:** Title: Financial Runway Assessment
Description: Evaluation of the initial capital drain against the project timeline.
Details: Allocating $54M USD to pre-revenue activities aligns with a prudent approach, supporting the $90M budget constraint by leaving $36M for contingencies and post-launch scale-up. Risk mitigation requires mandatory monthly tracking of burn rate against the $1.5M/month projected OpEx to ensure the 12-month runway is not breached, especially considering regulatory delays (Risk 1).

## Question 2 - Considering the 'low monthly maintenance fee' subscription model, what specific definition of 'compliance monitoring' will trigger the recurring payment cycle, and what is the targeted duration of mandatory subscription (Face-Wearing Duration)?

**Assumptions:** Assumption: Compliance monitoring triggers will be defined by biometric confirmation of consistent immunosuppressant adherence verified monthly via remote digital monitoring, aligned with Decision 3. The targeted minimum Recipient Face-Wearing Duration will be set at 3 years to establish initial revenue LTV stability.

**Assessments:** Title: Revenue Stability and LTV Projection
Description: Analysis of the contractual framework defining recurring income.
Details: Linking payments to verifiable immunosuppressant adherence (technical feasibility must be confirmed) provides a strong justification for the 'maintenance fee.' A 3-year duration yields an estimated minimum LTV per customer, which must be calculated against the projected cost-of-service (CoS) per patient to ensure the projected $2M-$5M annual revenue gap (Risk 3) is demonstrably closed by year 2.

## Question 3 - What concrete steps are established within the Auckland lease strategy to ensure the hired core surgical team (Staffing Model) has access to the facility's required specialized operational uptime, respecting the non-aggressive scenario constraint?

**Assumptions:** Assumption: The leased facility lease agreement must guarantee a minimum of 20 dedicated surgical days per month for high-complexity procedures, covering 3 core surgeons and essential support staff. This uptime is sufficient for scheduling 2-3 major procedures monthly, adhering to the non-aggressive scenario.

**Assessments:** Title: Operational Capacity Planning
Description: Assessment of facility access adequacy for the core clinical team.
Details: Securing fixed, dedicated surgical time in the leased Auckland theatre is critical to mitigating staffing shortages (Risk 5). Negotiations must prioritize primary access over shared hospital time. Opportunity exists to partner with the lessor for guaranteed maintenance windows, preventing infrastructure upgrades (Decision 13) from impacting critical surgical schedules.

## Question 4 - How will the outsourced international ethical review panel (Ethical Gatekeeping) interface logistically and legally with New Zealand's national medical oversight bodies to secure necessary operational permits (Governance & Regulations)?

**Assumptions:** Assumption: A dedicated Legal/Governance Liaison will be appointed to manage the formal recognition process, establishing memoranda of understanding (MOUs) between the independent review consortium and New Zealand's Health Practitioners Disciplinary Tribunal/HDEC within the first 9 months.

**Assessments:** Title: Regulatory Compliance Pathway
Description: Mapping the interface between external ethics governance and local compliance.
Details: Regulatory risk (Risk 1) is high; the success relies on bridging the gap between outsourced ethical vetting and mandated local clinical trial/procedure governance. A dedicated liaison is essential to translate external validation into local permits. Failure here stalls the entire timeline, requiring a contingency budget ($1M-$2M) for specialist regulatory law counsel.

## Question 5 - What specific safety protocols will govern the handling, preservation, and tracking of procured facial tissues to meet the requirements mandated by New Zealand's Health and Disability Commissioner regarding biological material (Safety & Risk Management)?

**Assumptions:** Assumption: All tissue handling, matching, and storage will adhere strictly to standards equivalent to those governing allogeneic organ transplantation in NZ/AU, plus an additional proprietary Layer-4 biosecurity standard for facial tissue viability, directly addressing the need for high-security/privacy.

**Assessments:** Title: Bio-Security and Protocol Integrity
Description: Establishing safety benchmarks for all tissue handling.
Details: Adherence to existing high standards mitigates technical risk (Risk 2) associated with infection or tissue degradation. The proprietary Layer-4 protocol must be treated as a critical IP asset and requires defined training sign-offs from all relevant staff (Risk 5). Regular third-party audits of cryo-storage integrity are mandatory to prevent inventory decay (Decision 14).

## Question 6 - Given the facility is in Auckland, what is the strategy for managing the environmental impact (waste streams, energy use for high-security containment) associated with complex, multi-year patient management (Environmental Impact)?

**Assumptions:** Assumption: Facility design, informed by the lease agreement, must incorporate medical waste neutralization systems built to exceed New Zealand's regional council hazardous waste guidelines, and energy systems must prioritize carbon offset for HVAC/cryogenic load to maintain a 'net-neutral' operational footprint within five years.

**Assessments:** Title: Sustainability and Waste Management Strategy
Description: Evaluation of required environmental controls for an experimental surgical site.
Details: High-grade medical waste and continuous power for cryo-storage (Decision 14) represent major environmental liability. Mitigation requires upfront CapEx investment in specialized HVAC/waste management within the leasehold retrofitting ($1M-$3M allocation). Achieving net-neutral status is a significant PR opportunity (counteracting Ethical Risk 4) but requires diligent long-term energy auditing.

## Question 7 - How will the facility engage with high-net-worth, privacy-seeking subscribers and the donor families (who receive non-financial benefits) to maximize positive testimonials while managing the extreme confidentiality inherent in the procedure (Stakeholder Involvement)?

**Assumptions:** Assumption: A tiered confidentiality agreement will be established: Tier 1 (Subscribers) sign 10-year Nondisclosure Agreements (NDAs), releasing controlled, anonymized testimonial data only. Tier 2 (Donors' Families) will receive dedicated Relationship Managers to ensure perceived reciprocity regarding the non-financial benefits (Decision 4).

**Assessments:** Title: Confidentiality and Stakeholder Management
Description: Balancing marketing needs with extreme client privacy requirements.
Details: Mismanagement of confidentiality is an extreme ethical/social risk (Risks 4 & 7). The strategy must guarantee zero data leakage. Positive feedback must be pre-approved and managed through legal channels—relying on controlled external testimonials rather than direct patient endorsements is safer to maintain the high-cost perception without risking patient reintegration failure.

## Question 8 - What integrated digital systems are required between the surgical theater, the bio-bank (Decision 14), and the compliance monitoring platform (Decision 2) to ensure seamless data flow and identity reconciliation post-transplant (Operational Systems)?

**Assumptions:** Assumption: A single, highly secure, locally hosted Electronic Health Record (EHR) system, compliant with NZ Privacy Act 2020, will integrate three modules: OR/Surgical Log, Cryo-Inventory Management, and Remote Patient Monitoring (RPM). System redundancy (fail-over capability planned) is mandatory for operations.

**Assessments:** Title: Integrated Technology Architecture
Description: Assessment of the digital backbone supporting surgical and billing operations.
Details: System failure or data mismatch poses high technical risk (Risk 2) and security risk (Risk 8). A unified, vetted EHR system minimizes identity risk (Decision 6). The initial $36M CapEx budget must ring-fence $5M-$7M for procurement, implementation, and two full independent security penetration tests before patient onboarding commences.