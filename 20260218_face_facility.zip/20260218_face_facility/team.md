*Roles Needed & Example People*

# Roles

## 1. Chief Strategy & Ethics Officer (CSEO)

**Contract Type**: `full_time_employee`

**Contract Type Justification**: This C-level strategic role owns executive oversight over existential risks (ethics, regulation, strategy) and requires deep commitment/control over the organization's direction. The role must be highly integrated for critical decision-making.

**Explanation**:
Responsible for overseeing the high-stakes ethical gatekeeping, regulatory navigation (NZ HDEC/Consortium alignment), and strategic alignment across all complex decisions (especially tissue sourcing and patient screening intensity). This role bridges the $90M budget constraint with the ethical mandate.

**Consequences**:
Existential threat due to immediate regulatory shutdown or catastrophic reputational collapse, as ethical compliance is the primary project risk buffer.

**People Count**:
1

**Typical Activities**:
Developing the Charter and Operating Mandate for the outsourced International Ethics Review Consortium; drafting liability waivers and consent forms that protect the facility against challenges related to identity management; leading quarterly meetings with NZ health regulators (HDEC/MoH); and authoring the official justification documents for the Tissue Acquisition Protocol used for external stakeholder communication.

**Background Story**:
Dr. Elara Vance, hailing from Geneva, Switzerland, holds a dual Ph.D. in Bioethics and International Regulatory Law, complemented by an LL.M focused on emerging transplant legislation. Her experience includes serving as a chief compliance auditor for the World Health Organization's organ trafficking task force, giving her unparalleled insight into the delicate balance between medical necessity and ethical commodification. She is intimately familiar with crafting risk-mitigation frameworks for high-sensitivity medical procedures and is crucial here because her background allows her to immediately structure the outsourced ethical review (Decision 5) to satisfy both international scrutiny and the specific constraints of the New Zealand regulatory environment while safeguarding the commercial viability of the subscription model.

**Equipment Needs**:
Secure, compliant server infrastructure for hosting Level 4 Biosecurity/EHR systems; High-security biometric access control hardware for facility partitioning.

**Facility Needs**:
Office space with secure connectivity integrated into the secured Auckland leasehold; Dedicated meeting rooms for confidential interactions with the International Ethics Review Consortium.

## 2. Lead Transplantation Surgeon & Protocol Architect

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The core surgeon dictates the primary technical success metric (graft survival) and protocol design. High expertise requires long-term dedication and adherence to the facility's standardized operational procedures, aligning with the five-year guaranteed contracts assumed for retention.

**Explanation**:
Oversees the core technical delivery. Responsible for establishing the maximal compatibility pairing algorithm, defining the surgical standards, and coordinating the technical aspects of the immunosuppression regimen complexity. Directly manages the contracted core surgical team.

**Consequences**:
Surgical failure, high acute rejection rates, and inability to secure specialized surgeon contracts (Risk 5), leading to immediate operational stagnation.

**People Count**:
1

**Typical Activities**:
Designing the 'maximal compatible donor-recipient matching algorithm' parameters; overseeing the development and validation of the proprietary immunosuppressive adjuncts; conducting surgical simulations and training the core surgeon team on perioperative management; and establishing the quality metrics for the Lead Transplantation Surgeon role.

**Background Story**:
Dr. Rhys Kellar, a globally recognized pioneer in transplant immunology and surgical technique, originates from Edinburgh, Scotland. He received his training at Johns Hopkins, specializing in complex maxillofacial transplantation, and has published seminal work on molecular compatibility matching far beyond standard HLA typing. His specific expertise lies in developing novel, site-specific immunosuppressive regimens that minimize systemic toxicity, which directly informs the complexity chosen for Decision 10. Dr. Kellar is necessary because he bridges the theoretical maximal compatibility algorithm (Decision 1) with practical, executable surgical protocols that ensure long-term graft survival, which is the core clinical deliverable underpinning the entire subscription lifespan.

**Equipment Needs**:
Advanced surgical microscopy and robotics suite for complex facial structure reconstruction; High-throughput, specialized laboratory equipment for proprietary immunosuppressive testing and matching assays; Two-year cryopreservation/bio-banking infrastructure capable of Layer-4 biosecurity adherence.

**Facility Needs**:
Dedicated Operating Theatres (OT) within the leased Auckland facility, guaranteed 20 surgical days/month access; Adjacent sterile research/validation lab space for protocol refinement.

## 3. Facility & Bio-Security Operations Director

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Managing a high-security, specialized facility build-out, cryopreservation, and ensuring 20 dedicated surgical days/month requires full control over operations, security implementation (Layer-4 biosecurity), and infrastructure maintenance timelines.

**Explanation**:
Manages the physical footprint in Auckland (leased retrofitting), facilities infrastructure cadence, and implementation of Layer-4 biosecurity and tissue storage protocols (Decision 14). Ensures surgical uptime aligns with lease agreements (20 days/month).

**Consequences**:
Violations of building code/health standards, failure of critical cryo-storage resulting in tissue loss, or insufficient physical capacity to support core surgical team, causing catastrophic scheduling delays.

**People Count**:
min 1, max 2, depending on project scale and workload.

**Typical Activities**:
Overseeing the CapEx deployment for facility retrofitting; specifying and sourcing specialized, high-load HVAC and cryogenic storage units required by Decision 14; ensuring the physical layout adheres to required security partitioning to maintain recipient anonymity (Decision 11); and negotiating lease terms to guarantee the 20 dedicated surgical days per month uptime.

**Background Story**:
Kaiora Tāne, based in Wellington, New Zealand, is an expert in complex facility logistics and high-security infrastructure development, having previously managed the secure decommissioning and retrofitting of sensitive government data centers across the South Island. With a background in civil engineering and specific certifications in Grade A cleanroom standards and cryogenics management, he understands the physical constraints of operating experimental medical technology under a tight budget. Mr. Tāne is essential as he is tasked with transforming the chosen Auckland leasehold into a compliant, secure operational theater that can support Layer-4 biosecurity and the extensive, power-intensive laboratory requirements for tissue preservation and immunosuppression monitoring.

**Equipment Needs**:
Specialized, high-load HVAC and power conditioning systems to support continuous cryogenic storage and cleanroom standards; Industrial-grade medical waste neutralization/disposal systems exceeding regional council minimums; Redundant Uninterruptible Power Supply (UPS) dedicated to life-support/cryo infrastructure.

**Facility Needs**:
Retrofit construction oversight management for the leased Auckland theater, ensuring compliance with NZ Building Code and maximizing surgical team uptime (Decision 11/13 alignment); Dedicated, secure storage bay for high-value capital equipment.

## 4. Subscription Finance & Compliance Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: This role directly manages the project's financial viability: collecting the steep initial fee, ensuring valid monthly revenue triggers via remote biometric compliance, and achieving specific ROI targets. This requires intimate knowledge and control over the billing and monitoring systems.

**Explanation**:
Owns the revenue model: defining the steep initial fee, managing the low monthly maintenance structure, and ensuring the remote biometric monitoring system validates billing triggers. Direct accountability for meeting ROI sensitivity analysis targets.

**Consequences**:
Financial collapse due to cash flow crisis (under-covering the $1.5M/month burn rate) or failure to legally trigger recurring revenue due to non-compliant monitoring systems (Risk T-1).

**People Count**:
2

**Typical Activities**:
Finalizing the financial model to ensure the initial payments cover the extended 18-month runway (as suggested by risk review); designing the billing logic integrated with the remote monitoring system for monthly adherence confirmation; forecasting Lifetime Value (LTV) based on the 3-year mandatory duration; and preparing financial reports tracking patient acquisition costs against subscription maturity.

**Background Story**:
Ms. Chloe Davies, an innovative finance professional from Sydney, Australia, built her career specializing in launching high-barrier-to-entry subscription services in boutique luxury and experimental healthcare sectors. Her skills lie in complex financial modeling, particularly structuring initial acquisition fees against long-term, compliance-dependent maintenance revenues, directly addressing the core conflict identified in Decision 3. Ms. Davies is indispensable because she must engineer the pricing structure—steep initial fee followed by low, conditional maintenance—to cover the high fixed operational burn rate ($1.5M/month) while ensuring the remote biometric monitoring system integrates flawlessly with billing triggers to avoid immediate cash flow crises.

**Equipment Needs**:
Integrated Electronic Health Record (EHR) system with validated billing module utilizing NZ Privacy Act 2020 compliant encryption; Secure hardware for deploying and managing the proof-of-concept remote digital patient monitoring system (RPM).

**Facility Needs**:
Secure server room/data center located within the Auckland facility for locally hosted, fully redundant EHR infrastructure; Private office space with high-level digital security clearance to conduct financial modeling and contract review.

## 5. Patient Journey & Reintegration Specialist

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Designing the 18-month reintegration support and managing donor family relationships are specialized, long-term supportive functions. This expertise can be sourced contractually to provide focused service delivery without locking in permanent salary overhead, especially since the service scales with each new cohort.

**Explanation**:
Designs and oversees the 18-month mandatory post-operative reintegration support and manages the Donor Family Relationship Managers. Critical for maintaining recipient compliance (supporting subscription recurrence) and managing public perception via controlled testimonial data.

**Consequences**:
Psychological failure of recipients, decreased subscription renewal rates post-term, and erosion of brand reputation due to unmanaged patient outcomes (Risk 4).

**People Count**:
min 1, max 3, depending on initial cohort size.

**Typical Activities**:
Developing curriculum content for the 18-month mandatory psycho-social support program; establishing the criteria for the 90-day psychological acceptance review that triggers subscription commencement; training the Relationship Managers who interface with donor families; and managing the controlled release of anonymized testimonial data captured from successful long-term recipients.

**Background Story**:
Mr. Liam O'Connell, based in Dublin, Ireland, is a seasoned clinical psychologist and organizational consultant specializing in identity transition and complex trauma recovery in high-profile medical cases. He spent years guiding high-stakes reconstructive surgery patients through mandatory integration periods, making him intimately familiar with the psychosocial friction points of identity shift. Mr. O'Connell is vital because he is responsible for designing the structure and content of the mandatory 18-month post-operative reintegration support program, ensuring recipient compliance is maximized to validate the subscription model and maintain positive reputational feedback.

**Equipment Needs**:
Technology platform and software licenses for scalable remote patient monitoring (RPM) data intake to trigger billing compliance; Secure digital workflow management system for psycho-social curriculum delivery and tracking 18-month mandatory progress.

**Facility Needs**:
Designated private consultation/counseling rooms within the facility for mandatory initial and 90-day psychological assessments; Secure, private administrative space for Donor Family Relationship Managers.

## 6. Legal Counsel & Contract Architect (NZ Focus)

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Requires deep specialization in complex NZ Health Law, identity contracts, and regulatory documentation. This specialized legal counsel is best engaged on a project basis or retainer (independent contractor) to navigate acute licensing and liability risks.

**Explanation**:
Specializes in New Zealand Health Law (HDC/ACC), responsible for drafting long-term recipient NDAs, managing the legal framework around identity management (Decision 6), and ensuring the specialized tissue agreements comply with local statutes.

**Consequences**:
Massive legal liability exposure from identity issues or procedural complications; delays in securing the core operational license (Risk 1).

**People Count**:
1

**Typical Activities**:
Drafting and finalizing all recipient subscription contracts, including the terms for mandatory identity adoption and long-term NDAs; securing the required Ministry of Health and ACC authorizations for novel surgical liability coverage; managing the flow of documentation required by the outsourced Ethics Consortium to satisfy local NZ governance requirements by the M+9 deadline; and ensuring the integrated EHR system complies with NZ Privacy Act 2020.

**Background Story**:
Alistair Finch, a sharp transactional lawyer from Auckland, New Zealand, possesses deep expertise in Health Law, specifically concerning the NZ Human Tissue Act 2008 and the intricacies of the Privacy Act 2020. Having previously advised local hospitals on liability regarding novel surgical interventions, Mr. Finch understands the specific documentation required by the MCNZ and HDEC for experimental procedures. His immediate task is to navigate the official permitting process, draft the recipient NDAs, and architect the legal framework ensuring the recipient's identity adoption (Decision 6) remains legally defensible under local statutes, thereby insulating the project from immediate legal challenge.

**Equipment Needs**:
Access to specialized legal databases pertaining to NZ Health Law, Human Tissue Act, and high-stakes contractual precedents (NDAs, identity mandates); Secure digital platform for document exchange with the International Ethics Consortium.

**Facility Needs**:
Designated, secure consultation room for privileged legal review meetings with executive staff; Office access allowing close proximity to the regulatory consulting team premises (if co-located near Wellington/Auckland regulatory hubs).

## 7. Biological Supply Chain Coordinator

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Managing the complex, ethically sensitive sourcing agreements and delivery logistics for tissues—which relies on external banks and donor families—is best managed via a specialized coordinator engaged on a vendor or contractual basis, focused on fulfillment metrics.

**Explanation**:
Manages the specialized, non-financial restorative benefit sourcing mechanism for donor families and oversees the relationship with tissue banks to ensure supply matches the strict 2-year viability window and pairing protocol constraints. Focuses heavily on ethical optics.

**Consequences**:
Complete stall in surgical schedule due to lack of ethically sourced, viable tissue inventory (Risk 6), wasting pre-booked surgeon time and infrastructure capacity.

**People Count**:
1

**Typical Activities**:
Negotiating and executing MOUs with specialized tissue banks capable of meeting the non-financial restorative benefit contract tier; managing the logistics pipeline to ensure tissue viability upon delivery, maintaining adherence to the Layer-4 biosecurity standards; and liaising with the Lead Surgeon to forecast tissue needs based on the ongoing pairing algorithm results.

**Background Story**:
Dr. Samir Khan, who trained in procurement logistics in Toronto, Canada, is an expert in managing highly specialized, low-volume, and ethically sensitive biological supply chains. His experience includes brokering complex agreements with national organ procurement organizations (OPOs). Dr. Khan is essential because he must operationalize the ethically vetted tissue sourcing method (offering non-financial restorative benefits), ensuring a reliable flow of viable tissue inventory that meets the demands of the pairing protocol within the stringent two-year holding window, thereby preventing surgical schedule disruption.

**Equipment Needs**:
Validated cold-chain logistics tracking equipment compatible with Layer-4 biosecurity standards; Contract management software for tracking and fulfilling complex, non-financial restorative benefit packages to donor families.

**Facility Needs**:
Dedicated, secure staging/inspection area co-located with the primary bio-banking facility to facilitate the rapid validation of incoming tissue supply (within the 2-year viability constraint).

## 8. Technology & Data Integrity Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The EHR integrity, cybersecurity posture, and the integration of the mission-critical remote compliance monitoring system require continuous, deep organizational control and immediate response capabilities that align better with a full-time employee status.

**Explanation**:
Responsible for designing, securing, and maintaining the locally hosted EHR, which integrates OR logs, Cryo-Inventory, and the remote Patient Monitoring (RPM) system. Owns cybersecurity posture and compliance with the NZ Privacy Act 2020 (Risk 8).

**Consequences**:
Data breach leading to regulatory fines and public trust failure, or system failure that prevents revenue generation via non-verifiable compliance data.

**People Count**:
1

**Typical Activities**:
Designing the architecture for the unified, locally-hosted EHR platform; overseeing the implementation of encryption and access controls that satisfy both internal Layer-4 biosecurity mandates and NZ Privacy Act requirements; designing the failover and redundancy systems for the critical remote RPM data stream; and conducting initial penetration testing on the digital adherence monitoring proof-of-concept.

**Background Story**:
Rina Sato, operating virtually from Tokyo, Japan, is a lead cybersecurity architect specializing in medical IoT and integrated clinical systems in highly regulated environments. She has designed redundant, locally hosted Electronic Health Record (EHR) systems compliant with global privacy standards, including the specific mandates of the NZ Privacy Act. Ms. Sato is tasked with architecting the necessary three-module integrated digital system (OR, Cryo, RPM) and building robust cybersecurity defense layers required to protect sensitive patient data and, critically, ensure the uncompromised functionality and data integrity of the remote immunosuppression monitoring system.

**Equipment Needs**:
Managed, locally hosted, high-availability EHR solution (integrating OR, Cryo, RPM); Advanced cybersecurity suite including continuous penetration testing tools and compliance logging mechanisms; Redundant network infrastructure for all critical data streams (Risk 8 mitigation).

**Facility Needs**:
Dedicated, climate-controlled server room with mandated physical access controls (Layer-4 compliance) to house the integrated EHR and data backups.

---

# Omissions

## 1. Missing Role: Regulatory/Legal Specialist for NZ Compliance

While the CSEO handles high-level ethics oversight and the Legal Counsel focuses on contracts, the project hinges on securing specific NZ operational licenses (HDEC, Human Tissue Act) within 18 months. No dedicated role is assigned responsibility for the daily, hands-on management of the regulatory submission pipeline (Risk 1).

**Recommendation**:
Assign one of the two FTE Legal/Compliance staff (or the existing Legal Contractor) the explicit, measurable metric of securing MOU with NZ HDEC by M+9. If the Legal Counsel (Finch) is focused heavily on contract architecture, a dedicated Regulatory Liaison FTE should be added to manage submissions, leveraging the budget set aside for specialized counsel.

## 2. Missing Role: Remote Monitoring Technologist/Support

The entire recurring revenue mechanism relies on the Subscription Finance Manager (Davies) being able to validate monthly compliance via a remote digital monitoring system. There is no technical role dedicated to deploying, maintaining, troubleshooting, and providing Tier 1 support for this mission-critical remote technology for up to 3-year contracts (Assumption Issue 2).

**Recommendation**:
Dedicate one full-time employee FTE, reporting to the Technology Lead (Sato), specifically as the 'Remote Patient Monitoring Technician.' This role will manage the deployment, user training, and daily triage of digital compliance data, directly supporting the Finance Manager's revenue triggers.

## 3. Missing Functional Area: Dedicated Public Relations/Stakeholder Communication

Reputational risk (Risk 4 & 7) is explicitly high. While the CSEO drafts justifications and the Patient Specialist manages donor families/testimonials, there is no dedicated role or function defined to proactively manage media perception, community outreach, or crisis communication specific to the transplant controversy.

**Recommendation**:
Task the CSEO with creating a formal 'Communication & Media Strategy Charter,' and assign the necessary budget ($2M allocated for outreach) to contract a specialized, remote PR firm retainer focused on high-stakes medical/ethical issues for external outreach.

---

# Potential Improvements

## 1. Clarify Revenue Trigger Logic vs. Reintegration Support

There is a conflict: Subscriptions are triggered only after a 90-day 'psychological acceptance review,' but the mandatory psycho-social support lasts 18 months. It is unclear if the low monthly maintenance fee applies during this initial exclusion period, or if the entire 18-month period is covered by the steep initial fee, inflating the initial cash burn.

**Recommendation**:
The Subscription Finance Manager (Davies) must finalize the contract language to state explicitly: Subscriptions/monthly fees commence immediately upon hospital discharge (M0), but the first automated payment installment is deferred until successful completion of the 90-day acceptance review milestone, ensuring the 18-month support is fully financed.

## 2. Over-reliance on Specialist Contractor Expertise for Key Technical Outputs

The Facility Director (Tāne) is responsible for implementing Layer-4 biosecurity and highly specialized HVAC/Cryogenics, which are critical to tissue viability (Risk 6). The staffing model heavily relies on his independent contract status, which offers less organizational control than an FTE.

**Recommendation**:
Mandate that the Facility Director contractually agrees to recruit and manage an internal, FTE Biomedical Technician specializing in critical lab infrastructure maintenance (HVAC/Cryo) within the first 6 months to ensure continuity beyond the initial fit-out phase governed by his contract term.

## 3. Need for Defined Interdependency between Surgeon and Finance Roles

The Surgeon Protocol Architect (Kellar) defines the compatibility matching, which dictates tissue use rate. The Finance Manager optimizes LTV based on the 3-year duration and compliance monitoring results. There is no formal meeting cadence to reconcile these two critical streams of data.

**Recommendation**:
Establish a mandatory monthly 'Clinical Viability & Revenue Reconciliation' meeting between Dr. Kellar, Ms. Davies, and the CSEO. Dr. Kellar must provide tissue utilization trends and predicted future match requirements, allowing Ms. Davies to adjust LTV forecasts and compliance data expectations proactively.