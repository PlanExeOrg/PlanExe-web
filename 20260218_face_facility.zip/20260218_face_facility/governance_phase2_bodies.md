### 1. Project Executive Steering Committee (PESC)

**Rationale for Inclusion:** Required for high-level strategic oversight, critical financial approvals, and navigating the intense ethical/regulatory landscape inherent in experimental human transplantation, especially given the tight $90M budget and reliance on specialized NZ regulatory navigation.

**Responsibilities:**

- Approve project phase completion and authorize subsequent tranche funding.
- Review and approve any change requests affecting the total $90M budget by more than 5% or impacting the 18-month operational runway assumption.
- Oversight of the primary strategic risk profile (Regulatory, Ethical, Financial Viability).
- Final approval of the Donor/Recipient Pairing Protocol standards and any deviation waivers.
- Serve as the final escalation point for all governance bodies.

**Initial Setup Actions:**

- Finalize and approve the PESC Terms of Reference (ToR), including conflict of interest policies.
- Define the Chair and establish voting procedures, including protocols for accessing contingency funds.
- Review and formally ratify the key strategic decisions made in the 'Builder's Foundation' scenario.

**Membership:**

- Executive Sponsor (Chair)
- Chief Executive/Project Director
- Chief Financial Officer (CFO)
- External Legal Counsel (Non-voting, Expert Advisor)
- Chair of the Technical Assurance Group (TAG)

**Decision Rights:** All decisions exceeding a $3M financial threshold, modification of the 3-year minimum LTV projection, or formal acceptance/rejection of major milestones (e.g., Facility Handover, First Patient In).

**Decision Mechanism:** Consensus preferred. Requires 80% majority vote (3 out of 4 voting members) in case of irreconcilable difference. Tie-breaker defaults to the Executive Sponsor.

**Meeting Cadence:** Monthly, escalating to bi-weekly during critical milestones (Facility Build-Out or First Patient Cycle).

**Typical Agenda Items:**

- Review of financial burn rate vs. planned OpEx runway ($18M/ $27M assumption).
- High-level risk register review (focus on top 3 strategic risks).
- Quarterly comprehensive external audit summary review.
- Review of external Ethics Consortium advisory status.

**Escalation Path:** Issues unresolved after two PESC meetings or requiring external shareholder consultation escalate directly to the Corporate Board (External to this project governance structure).
### 2. Operational Management Team (OMT)

**Rationale for Inclusion:** Needed to manage the day-to-day execution against aggressive timelines (18 months to readiness) and oversee the complex integration of technical, HR, and contractual dependencies related to the leased Auckland facility and core staffing.

**Responsibilities:**

- Manage the $36M CapEx budget and ensure adherence to the facility fit-out schedule.
- Oversee the recruitment and contractual management of the core surgical team (salaries, compliance with knowledge transfer KPIs).
- Manage operational risks (e.g., staffing shortages, minor procurement delays).
- Implement and enforce the Layer-4 Biosecurity Protocol and manage tissue flow within the 2-year viability window.
- Ensure the remote digital adherence monitoring system is functional and compliant with NZ Privacy Act 2020 prior to patient discharge.

**Initial Setup Actions:**

- Define and document the Standard Operating Procedures (SOPs) for all core surgical and lab functions.
- Finalize staffing acquisition plans for core team hires for the guaranteed five-year contracts.
- Establish initial procurement contracts for specialized Class III equipment.

**Membership:**

- Chief Operating Officer (Chair)
- Lead Biomedical Engineer/Facility Manager
- Head of Human Resources & Administration
- Lead Regulatory/Compliance Liaison (Non-voting)

**Decision Rights:** All operational decisions below the $3M financial threshold (PESC threshold); approval of non-standard staff onboarding/offboarding; scheduling of surgical block time (must secure 20 dedicated days/month). Decisions impacting compliance protocol can only be made with documented review from the Specialized Advisory Group.

**Decision Mechanism:** Simple majority vote. If immediate impasse occurs on technical execution that delays readiness past M+15, the decision is escalated immediately to the PESC Chair.

**Meeting Cadence:** Weekly formal reviews.

**Typical Agenda Items:**

- CapEx expenditure tracking against monthly burn rate.
- Staffing utilization and retention metrics (knowledge transfer tracking).
- Status update on facility retrofitting and security implementation (Decision 11).
- Review of tissue inventory levels vs. scheduling requirements (Decision 14).

**Escalation Path:** Issues requiring budget changes over $3M, unresolved ethical conflicts related to compliance overrides, or failure to secure 20 surgical days/month are escalated to the Project Executive Steering Committee (PESC).
### 3. Specialized Assurance & Ethics Panel (SAEP)

**Rationale for Inclusion:** Due to the high ethical risk, novel consent requirements (Decision 5), and reliance on non-standard tissue sourcing (Decision 4), an independent/outsourced review body is critical to maintain reputational insulation and satisfy regulatory demands (HDEC reliance).

**Responsibilities:**

- Provide independent assurance that the Donor/Recipient Pairing Protocol meets maximal compatibility thresholds and that all waivers are justified.
- Vet and continuously audit the ethical integrity of the Tissue Acquisition Protocol, specifically the non-financial restorative benefits offered to donor families.
- Review and provide binding opinion on all recipient psychological screening results prior to surgical approval.
- Conduct bi-annual audits of the billing compliance workflow to ensure remote biometric data integrity is not manipulated for revenue purposes.
- Manage and oversee the anonymous whistleblower channel.

**Initial Setup Actions:**

- Finalize legal Service Level Agreement (SLA) with the International Ethics Review Consortium.
- Establish internal data sharing protocols for audited patient files with zero data leakage risk concerning personal identity.
- Finalize the Memorandum of Understanding (MOU) with NZ HDEC regarding reliance on the SAEP vetting process (per Assumption Issue 4).

**Membership:**

- Chair of International Ethics Review Consortium (Independent/External)
- Lead Bioethicist (Independent Consultant)
- Chief Compliance Officer (Internal, Non-voting)
- Legal Counsel specializing in NZ Health Law (Non-voting)

**Decision Rights:** Binding authority over patient acceptance/rejection based on ethical and psychological screening outcomes. Veto power over any operational change that compromises the integrity of the Tissue Acquisition Protocol or the digital compliance monitoring system.

**Decision Mechanism:** Unanimous vote required for all binding patient approvals or ethical vetoes. External Chair holds final sign-off on material ethical divergence.

**Meeting Cadence:** Bi-weekly during pre-launch/enrollment phases; Monthly thereafter for active patient oversight.

**Typical Agenda Items:**

- Review of all recipient screening exception requests outside standard parameters.
- Audit findings on Tissue Acquisition implementation and donor family engagement.
- Review of identity management strategy efficacy concerning public risk exposure.
- External compliance audit review focusing on billing data verification.

**Escalation Path:** If the SAEP vetoes a critical operational decision (e.g., surgical readiness scheduling) or identifies a material breach in ethical commitment by the OMT, the issue is immediately escalated to the PESC for emergency review and remedial action.