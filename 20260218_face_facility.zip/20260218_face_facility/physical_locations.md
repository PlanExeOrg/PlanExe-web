This plan implies one or more physical locations.

## Requirements for physical locations

- Must be located in New Zealand
- Must accommodate a high-security, specialized surgical theatre
- Must have access to high-level medical/surgical talent (Auckland preferred)
- Should be a leased facility to conserve capital within the $90M budget
- Must balance accessibility for elite clientele with operational privacy/security

## Location 1
New Zealand

Auckland

Existing, retrofitted specialized surgical theatre lease in Auckland CBD or surrounding medical hub.

**Rationale**: This is the strategically chosen location (Decision 2: Builder's Foundation). Auckland offers the best access to established surgical talent and reduces facility build-out capital expenditure by seeking a long-term lease.

## Location 2
New Zealand

Wellington

Specialized medical leasing space near the national regulatory body/ethics committees.

**Rationale**: Wellington, as the capital, provides strong institutional proximity, which is beneficial when utilizing an external ethics consortium (Decision 5) and navigating the complex legal landscape of this novel procedure.

## Location 3
New Zealand

Christchurch

University-affiliated medical research park or facility lease.

**Rationale**: Christchurch hosts robust research infrastructure and universities, providing established scientific vetting and potential pathways for sourcing non-financial restorative benefits (Decision 4) through affiliated research bodies.

## Location Summary
The primary location is mandated as Auckland, New Zealand, based on strategic decisions favoring established surgical talent access via leasing. Two alternative locations in New Zealand—Wellington (for regulatory proximity) and Christchurch (for research/ethical networking)—are suggested to provide logistical and operational flexibility.