A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Donor face acquisition will consistently meet demand. | Contact three major organ donation organizations in New Zealand and request their historical data on face donations or potential face donors. | All three organizations report zero historical face donations and express significant reservations about the feasibility of acquiring face donations in the future due to ethical and logistical challenges. |
| A2 | Radical technological approaches (CRISPR, xenotransplantation) will be viable within the project timeline and budget. | Commission a feasibility study from an independent scientific consultancy specializing in xenotransplantation and CRISPR, focusing on regulatory hurdles, technical challenges, and estimated timelines for clinical application in New Zealand. | The feasibility study concludes that xenotransplantation and CRISPR face insurmountable regulatory hurdles in New Zealand within the next 5-7 years and would require at least $50 million in additional R&D funding to even reach the clinical trial stage. |
| A3 | The subscription model will be socially acceptable and commercially viable. | Conduct a survey of 1000 New Zealand residents, assessing their attitudes towards face transplantation and their willingness to pay for a face-swapping subscription service, including questions about ethical concerns and perceived value. | The survey reveals that over 75% of respondents find the concept of a face-swapping subscription service ethically objectionable, and less than 5% express any willingness to pay for such a service, even at a nominal price. |
| A4 | The facility can maintain a high level of data security and patient privacy. | Conduct a penetration test by a reputable cybersecurity firm to assess the vulnerability of the facility's IT systems and data storage protocols. | The penetration test reveals multiple critical vulnerabilities that could allow unauthorized access to patient data, including medical records, financial information, and personal details. |
| A5 | The facility can effectively manage the psychological impact on both face recipients and donor families. | Consult with a panel of psychologists and psychiatrists specializing in transplantation and identity issues to review the facility's psychological support program and assess its adequacy in addressing the complex emotional needs of recipients and donor families. | The panel of experts concludes that the psychological support program is inadequate and lacks the resources and expertise necessary to effectively address the long-term psychological challenges faced by recipients and donor families, particularly in the context of face transplantation. |
| A6 | The facility can secure and maintain adequate insurance coverage at a reasonable cost. | Obtain quotes from multiple insurance providers for comprehensive medical liability insurance, including coverage for potential complications, ethical breaches, and data breaches, and assess the affordability and scope of coverage. | All insurance providers decline to offer coverage due to the high-risk nature of face transplantation and the novelty of the subscription model, or the premiums quoted are prohibitively expensive, exceeding 20% of the facility's projected annual revenue. |
| A7 | The facility will be able to attract and retain qualified medical personnel (surgeons, nurses, technicians, ethicists) within the allocated budget. | Conduct a salary survey of comparable medical facilities in New Zealand and Australia to determine the prevailing market rates for the required medical personnel, and compare these rates to the facility's proposed salary budget. | The salary survey reveals that the facility's proposed salary budget is significantly below market rates, making it unlikely to attract and retain qualified medical personnel, particularly experienced surgeons and ethicists. |
| A8 | The supply chain for specialized medical supplies and equipment will be reliable and cost-effective. | Obtain quotes from multiple suppliers for all essential medical supplies and equipment, including specialized surgical instruments, immunosuppressant drugs, and data security systems, and assess the reliability of the supply chain and the potential for disruptions. | The quotes reveal that the cost of specialized medical supplies and equipment is significantly higher than anticipated, and the supply chain is vulnerable to disruptions due to reliance on a limited number of suppliers and potential geopolitical instability. |
| A9 | The facility will be able to effectively manage public perception and maintain a positive brand image. | Conduct a focus group study with members of the general public to assess their initial reactions to the facility's proposed services and marketing materials, and identify potential concerns and misconceptions. | The focus group study reveals that the public has significant concerns about the ethical implications of face transplantation and the subscription model, and the facility's marketing materials are perceived as sensationalistic and insensitive, potentially damaging the brand image. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Empty Facade: A Donor Drought Bankrupts the Dream | Process/Financial | A1 | Head of Operations | CRITICAL (20/25) |
| FM2 | The CRISPR Catastrophe: A Technological Dead End | Technical/Logistical | A2 | Head of Engineering | CRITICAL (15/25) |
| FM3 | The Face Value Fiasco: Public Rejection Kills the Subscription Dream | Market/Human | A3 | Chief Marketing Officer | CRITICAL (20/25) |
| FM4 | The Data Breach Debacle: A Privacy Nightmare | Process/Financial | A4 | Data Security & Privacy Officer | CRITICAL (15/25) |
| FM5 | The Psychological Fallout: A Mental Health Crisis | Market/Human | A5 | Patient Liaison & Psychological Support Coordinator | CRITICAL (20/25) |
| FM6 | The Insurance Implosion: Uninsurable Risks Sink the Ship | Technical/Logistical | A6 | Facility Operations Manager | CRITICAL (15/25) |
| FM7 | The Talent Drain: A Staffing Shortage Cripples the Facility | Process/Financial | A7 | Facility Operations Manager | CRITICAL (20/25) |
| FM8 | The Supply Chain Snarl: A Logistical Nightmare | Technical/Logistical | A8 | Facility Operations Manager | CRITICAL (15/25) |
| FM9 | The Brand Blunder: A Public Relations Disaster | Market/Human | A9 | Chief Marketing Officer | CRITICAL (20/25) |


### Failure Modes

#### FM1 - The Empty Facade: A Donor Drought Bankrupts the Dream

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Head of Operations
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The core assumption that donor face acquisition will meet demand proves false. 
*   Initial partnerships with organ donation organizations yield far fewer faces than projected.
*   Ethical concerns and logistical challenges further restrict the supply.
*   The facility operates far below capacity, leading to significant revenue shortfalls.
*   Fixed costs (facility maintenance, staffing) remain high, eroding profit margins.
*   Investors lose confidence, and further funding dries up.
*   The subscription model collapses due to lack of available faces to 'swap'.
*   The facility is forced to declare bankruptcy.

##### Early Warning Signs
- Organ donation organizations report a significant decline in overall organ donation rates in New Zealand.
- The ethics review board raises concerns about the ethical implications of face acquisition protocols.
- The facility struggles to secure even a single donor face within the first six months of operation.

##### Tripwires
- Number of acquired donor faces <= 2 within the first year.
- Subscription fulfillment rate <= 50% due to donor face shortages.
- Operating costs exceed revenue by >= 25% for two consecutive quarters.

##### Response Playbook
- Contain: Immediately halt all marketing and advertising efforts to avoid over-promising services.
- Assess: Conduct a thorough review of the donor face acquisition strategy and identify alternative sources.
- Respond: Explore alternative business models, such as focusing on research and development or offering specialized reconstructive surgery services that do not rely on donor faces.


**STOP RULE:** The facility is unable to secure at least 5 donor faces per year for two consecutive years.

---

#### FM2 - The CRISPR Catastrophe: A Technological Dead End

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's reliance on radical technologies like CRISPR and xenotransplantation proves to be a fatal flaw.
*   CRISPR technology encounters unforeseen technical challenges, leading to significant delays and cost overruns.
*   Xenotransplantation faces insurmountable regulatory hurdles and ethical objections, preventing clinical application.
*   The facility is unable to deliver on its promise of cutting-edge face transplantation services.
*   Patients lose interest, and subscriber enrollment plummets.
*   The facility is stuck with outdated technology and a lack of viable alternatives.
*   The project becomes a laughingstock in the medical community, damaging its reputation beyond repair.
*   The facility is forced to shut down due to technological obsolescence and lack of innovation.

##### Early Warning Signs
- Research publications report significant setbacks in CRISPR technology for transplantation.
- Regulatory bodies express strong reservations about the ethical and safety implications of xenotransplantation.
- The facility fails to achieve any significant technological breakthroughs within the first two years of operation.

##### Tripwires
- CRISPR-related research milestones delayed by >= 180 days.
- Regulatory bodies formally reject xenotransplantation clinical trial application.
- R&D spending exceeds budget by >= 50% without demonstrable progress.

##### Response Playbook
- Contain: Immediately re-allocate R&D resources to focus on refining existing surgical techniques and immunosuppression protocols.
- Assess: Conduct a thorough review of the technological development strategy and identify more realistic and achievable goals.
- Respond: Pivot to a more conservative technological approach, focusing on incremental improvements and established technologies.


**STOP RULE:** The facility fails to demonstrate any significant technological advancements in face transplantation within three years of operation.

---

#### FM3 - The Face Value Fiasco: Public Rejection Kills the Subscription Dream

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Chief Marketing Officer
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The assumption that the subscription model will be socially acceptable and commercially viable proves disastrously wrong.
*   Public opinion turns sharply against the concept of face-swapping, viewing it as unethical, superficial, and even grotesque.
*   Social media campaigns and protests target the facility, damaging its reputation.
*   Potential subscribers are deterred by the negative publicity and ethical concerns.
*   The facility struggles to attract a sufficient subscriber base to sustain operations.
*   Advertisers and sponsors withdraw their support, further eroding revenue.
*   The project becomes a social pariah, ostracized by the community and the media.
*   The facility is forced to close its doors due to lack of public acceptance and commercial viability.

##### Early Warning Signs
- Social media sentiment analysis reveals a sharp increase in negative comments and criticism towards the facility.
- Public opinion polls show a significant decline in support for face transplantation and the subscription model.
- The facility struggles to attract even a small number of subscribers within the first year of operation.

##### Tripwires
- Negative social media sentiment exceeds positive sentiment by >= 20%.
- Subscriber enrollment falls short of projections by >= 50% within the first year.
- Key sponsors withdraw their support due to ethical concerns.

##### Response Playbook
- Contain: Immediately launch a public relations campaign to address ethical concerns and promote the benefits of face transplantation.
- Assess: Conduct a thorough review of the marketing strategy and identify the root causes of the negative public perception.
- Respond: Pivot to a more ethically responsible and socially conscious marketing approach, emphasizing the reconstructive and life-changing aspects of face transplantation rather than the face-swapping concept.


**STOP RULE:** Public opinion polls consistently show that over 60% of the population opposes the face transplantation facility and the subscription model.

---

#### FM4 - The Data Breach Debacle: A Privacy Nightmare

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Data Security & Privacy Officer
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The assumption of maintaining high data security proves false.
*   A sophisticated cyberattack breaches the facility's IT systems.
*   Sensitive patient data, including medical records, financial information, and personal details, is exposed.
*   The breach triggers a massive public outcry and legal action.
*   The facility faces significant fines and penalties for violating data privacy regulations.
*   Patients lose trust, and subscriber enrollment plummets.
*   The facility's reputation is irreparably damaged.
*   The project collapses under the weight of legal liabilities and reputational damage.

##### Early Warning Signs
- Security audits reveal persistent vulnerabilities in the facility's IT systems.
- Employees report phishing attempts and suspicious activity on the network.
- The facility experiences a series of minor data breaches or security incidents.

##### Tripwires
- Number of successful cyberattacks >= 1.
- Data breach affecting >= 100 patient records.
- Fines and penalties for data privacy violations exceed $1 million.

##### Response Playbook
- Contain: Immediately shut down all affected IT systems and isolate the breach.
- Assess: Conduct a thorough forensic investigation to determine the scope and cause of the breach.
- Respond: Notify affected patients, regulatory authorities, and the media, and implement a comprehensive data breach response plan.


**STOP RULE:** A data breach exposes sensitive patient data, leading to significant legal liabilities and reputational damage.

---

#### FM5 - The Psychological Fallout: A Mental Health Crisis

- **Archetype**: Market/Human
- **Root Cause**: Assumption A5
- **Owner**: Patient Liaison & Psychological Support Coordinator
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The assumption of effectively managing the psychological impact on recipients and donor families proves tragically wrong.
*   Face transplant recipients struggle with identity issues, body image concerns, and the psychological burden of wearing another person's face.
*   Donor families experience grief, guilt, and complex emotions related to the donation.
*   The facility's psychological support program is inadequate and fails to address the complex emotional needs of patients and families.
*   Patients experience depression, anxiety, and post-traumatic stress disorder.
*   Some recipients attempt suicide or experience severe mental health crises.
*   The facility faces lawsuits and public criticism for failing to provide adequate psychological support.
*   The project is deemed unethical and irresponsible, leading to its downfall.

##### Early Warning Signs
- Patient satisfaction surveys reveal widespread dissatisfaction with the psychological support program.
- Therapists report a high rate of patient attrition and difficulty in engaging patients in therapy.
- The facility experiences a series of mental health crises among recipients and donor families.

##### Tripwires
- Patient attrition rate from psychological support program >= 25%.
- Number of reported mental health crises among recipients and donor families >= 5.
- Lawsuits filed against the facility for inadequate psychological support >= 1.

##### Response Playbook
- Contain: Immediately increase staffing levels and resources for the psychological support program.
- Assess: Conduct a thorough review of the psychological support program and identify areas for improvement.
- Respond: Partner with leading mental health organizations to provide specialized care and support to patients and families.


**STOP RULE:** Multiple face transplant recipients experience severe mental health crises, leading to significant harm or loss of life.

---

#### FM6 - The Insurance Implosion: Uninsurable Risks Sink the Ship

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A6
- **Owner**: Facility Operations Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The assumption of securing adequate insurance coverage at a reasonable cost proves to be a critical miscalculation.
*   Insurance providers deem face transplantation too risky and the subscription model too novel to offer coverage.
*   The facility is unable to obtain comprehensive medical liability insurance.
*   The lack of insurance coverage exposes the facility to significant financial risks in the event of complications, ethical breaches, or data breaches.
*   Investors become wary and withdraw their support.
*   The facility is unable to operate without insurance coverage.
*   The project is deemed financially unsustainable and is forced to shut down.

##### Early Warning Signs
- Insurance providers decline to offer coverage or quote prohibitively expensive premiums.
- The facility struggles to secure even basic medical liability insurance.
- Investors express concerns about the lack of insurance coverage.

##### Tripwires
- Insurance providers decline to offer comprehensive medical liability insurance.
- Insurance premiums exceed 20% of the facility's projected annual revenue.
- Investors withdraw their support due to the lack of insurance coverage.

##### Response Playbook
- Contain: Immediately explore alternative insurance options, such as self-insurance or captive insurance.
- Assess: Conduct a thorough risk assessment to identify and mitigate potential liabilities.
- Respond: Revise the business model to reduce risk and improve insurability, such as focusing on less complex procedures or partnering with established medical institutions.


**STOP RULE:** The facility is unable to secure adequate insurance coverage to protect against potential liabilities.

---

#### FM7 - The Talent Drain: A Staffing Shortage Cripples the Facility

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Facility Operations Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The assumption that qualified medical personnel can be attracted and retained within budget proves false.
*   The facility's salary budget is insufficient to compete with other medical facilities in New Zealand and Australia.
*   Experienced surgeons, nurses, technicians, and ethicists are unwilling to join the facility due to low pay and perceived ethical concerns.
*   The facility is forced to hire less qualified personnel, compromising the quality of care.
*   High staff turnover leads to increased training costs and operational inefficiencies.
*   The facility struggles to maintain accreditation and regulatory compliance.
*   Patient outcomes suffer, and the facility's reputation is tarnished.
*   The project collapses due to a lack of skilled medical professionals.

##### Early Warning Signs
- Job postings for medical personnel remain unfilled for extended periods.
- The facility experiences a high rate of staff turnover.
- Patient satisfaction surveys reveal concerns about the competence and experience of medical staff.

##### Tripwires
- Staff turnover rate exceeds 25% annually.
- Number of unfilled medical positions >= 3 for more than 90 days.
- Patient satisfaction scores related to staff competence fall below 70%.

##### Response Playbook
- Contain: Immediately increase salaries and benefits to attract and retain qualified medical personnel.
- Assess: Conduct a thorough review of the facility's compensation and benefits packages and identify areas for improvement.
- Respond: Partner with leading medical institutions to offer training and mentorship opportunities to attract top talent.


**STOP RULE:** The facility is unable to recruit and retain a qualified lead transplant surgeon within six months.

---

#### FM8 - The Supply Chain Snarl: A Logistical Nightmare

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Facility Operations Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The assumption that the supply chain for specialized medical supplies and equipment will be reliable and cost-effective proves to be a critical vulnerability.
*   The facility relies on a limited number of suppliers for specialized surgical instruments, immunosuppressant drugs, and data security systems.
*   Geopolitical instability and supply chain disruptions lead to shortages and price increases.
*   The facility is unable to procure essential medical supplies and equipment in a timely manner.
*   Surgical procedures are delayed or canceled, leading to patient dissatisfaction and revenue losses.
*   The facility is forced to use substandard supplies and equipment, compromising patient safety.
*   The project is deemed unreliable and unsustainable, leading to its downfall.

##### Early Warning Signs
- Suppliers report delays in shipments and price increases.
- The facility experiences frequent stockouts of essential medical supplies.
- The facility is forced to use alternative suppliers with lower quality products.

##### Tripwires
- Lead times for essential medical supplies exceed 30 days.
- Price increases for key medical supplies exceed 15%.
- Stockouts of critical medical supplies occur more than twice per month.

##### Response Playbook
- Contain: Immediately diversify the supply chain by identifying and contracting with alternative suppliers.
- Assess: Conduct a thorough risk assessment of the supply chain and identify potential vulnerabilities.
- Respond: Implement a robust inventory management system and stockpile essential medical supplies to mitigate potential disruptions.


**STOP RULE:** The facility is unable to procure essential medical supplies and equipment for more than 30 consecutive days.

---

#### FM9 - The Brand Blunder: A Public Relations Disaster

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Chief Marketing Officer
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The assumption that the facility can effectively manage public perception and maintain a positive brand image proves disastrously wrong.
*   The public perceives the facility's services as unethical, superficial, and insensitive.
*   The facility's marketing materials are deemed sensationalistic and exploitative.
*   Social media campaigns and protests target the facility, damaging its reputation.
*   Potential subscribers are deterred by the negative publicity and ethical concerns.
*   Advertisers and sponsors withdraw their support, further eroding revenue.
*   The project becomes a social pariah, ostracized by the community and the media.
*   The facility is forced to close its doors due to lack of public acceptance and commercial viability.

##### Early Warning Signs
- Social media sentiment analysis reveals overwhelmingly negative feedback towards the facility.
- Public opinion polls show a significant decline in support for face transplantation and the subscription model.
- Advertisers and sponsors withdraw their support due to ethical concerns.

##### Tripwires
- Negative social media sentiment exceeds positive sentiment by >= 50%.
- Public opinion polls show that less than 20% of the population supports the facility.
- Key advertisers and sponsors withdraw their support due to ethical concerns.

##### Response Playbook
- Contain: Immediately halt all marketing and advertising efforts and issue a public apology for any perceived insensitivity.
- Assess: Conduct a thorough review of the marketing strategy and identify the root causes of the negative public perception.
- Respond: Develop a new marketing strategy that emphasizes the reconstructive and life-changing aspects of face transplantation and addresses ethical concerns in a transparent and responsible manner.


**STOP RULE:** Public opinion polls consistently show that less than 10% of the population supports the face transplantation facility and the subscription model.
