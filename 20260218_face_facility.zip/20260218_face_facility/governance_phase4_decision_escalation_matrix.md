**Budget Request Exceeding $3M Threshold for Critical Infrastructure Upgrade (Decision 13)**
Escalation Level: Project Executive Steering Committee (PESC)
Approval Process: 80% majority vote (3 out of 4 voting members) required.
Rationale: Exceeds the OMT's $3M financial threshold for operational and CapEx decisions concerning facility upgrades, potentially requiring access to contingency funds.
Negative Consequences: Project delay beyond month 18 readiness, or depletion of contingency funds required for Risk 1 mitigation.

**OMT Deadlock on Facility Modification Affecting Guaranteed Surgical Uptime (Decision 2/11)**
Escalation Level: Project Executive Steering Committee (PESC)
Approval Process: Immediate presentation to PESC Chair for emergency review; requires consensus preference.
Rationale: Impasse between operational requirements (e.g., security partitioning vs. access) directly threatens the guaranteed 20 dedicated surgical days/month milestone.
Negative Consequences: 25% reduction in surgical throughput, jeopardizing revenue projections and ability to service fixed staffing costs.

**SAEP Veto Over Patient Selection Based on Ethical or Psychological Screening Waivers (Decision 5)**
Escalation Level: Project Executive Steering Committee (PESC)
Approval Process: Immediate elevation for emergency review; requires SAEP Chair to present rationale directly to PESC.
Rationale: SAEP holds binding authority over patient acceptance/rejection critical for reputation insurance. Veto indicates a material ethical breach possibility.
Negative Consequences: Stagnation of patient pipeline, potential regulatory intervention (HDEC scrutiny), and massive reputational damage.

**Technical Failure/Rejection of Remote Biometric Monitoring System (Assumption Issue 2)**
Escalation Level: Specialized Assurance & Ethics Panel (SAEP)
Approval Process: Unanimous vote required by SAEP to either halt patient enrollment or approve a contractually compliant fallback billing mechanism.
Rationale: The feasibility of the remote monitoring system is the core technical dependency underpinning the recurring revenue contract structure (Decision 3).
Negative Consequences: If unresolved, the project cannot execute the intended low-friction subscription model, potentially requiring a 10-18% reduction in projected LTV.

**Unresolved Conflict in Tissue Sourcing Between Viability Window and Ethics Protocol (Decision 4/14)**
Escalation Level: Project Executive Steering Committee (PESC)
Approval Process: PESC decision, requiring 80% vote, to authorize funding for supplementary tissue sourcing methods or accept reduced surgical schedule.
Rationale: Conflict between the 2-year tissue tenure limit and ethical demands on non-financial restorative benefits creates an irreconcilable supply chain blockage.
Negative Consequences: 20% reduction in available surgeries, jeopardizing the ability to cover high fixed staffing costs against the initial 12-month OpEx runway.

**Proposal for Change to Minimum Subscription Duration (Decision 12)**
Escalation Level: Project Executive Steering Committee (PESC)
Approval Process: PESC vote must confirm LTV projections are maintained or adjusted before proceeding.
Rationale: Modification of the 3-year minimum Recipient Face-Wearing Duration directly alters the fundamental Lifetime Value (LTV) calculation, which dictates the project's financial justification.
Negative Consequences: Failure to secure LTV stability may require capital raise or severely constrain future operational funding/upgrades.