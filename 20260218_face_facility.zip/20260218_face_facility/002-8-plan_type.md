This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** This plan *unequivocally requires* a physical location (New Zealand), a physical facility, medical professionals, and patients. Face transplantation is a complex surgical procedure, making this *inherently* a physical endeavor.