### 1. Project Sponsor identifies and confirms the Executive Sponsor and designates the Project Director/Chief Executive for the initial setup phase.

**Responsible Body/Role:** Corporate Board / Project Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Confirmed Executive Sponsor
- Designated Project Director/Chief Executive

**Dependencies:**

- Project Charter Approval

### 2. Project Director drafts initial Terms of Reference (ToR) for the Project Executive Steering Committee (PESC), incorporating budget controls ($90M) and key strategic decisions (Builder's Foundation).

**Responsible Body/Role:** Project Director/Chief Executive

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PESC ToR v0.1

**Dependencies:**

- Executive Sponsor Confirmed

### 3. External Legal Counsel is retained and begins engagement with NZ regulatory bodies regarding the reliance on the outsourced Ethical Review Consortium.

**Responsible Body/Role:** Executive Sponsor / Project Director (via Legal Hire)

**Suggested Timeframe:** Project Week 1 - 2

**Key Outputs/Deliverables:**

- Legal Firm Contract Signed
- Initial Regulatory Engagement Strategy Document

**Dependencies:**

- Draft PESC ToR v0.1

### 4. Executive Sponsor formally appoints Chair and voting members for the PESC, including the CFO and Lead Engineer (to become OMT Chair designee).

**Responsible Body/Role:** Executive Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Formal PESC Membership Confirmation

**Dependencies:**

- Draft PESC ToR v0.1

### 5. PESC holds its inaugural meeting: Review and formally approve the PESC ToR, confirm the 'Builder's Foundation' scenario, and authorize the engagement of the International Ethics Review Consortium.

**Responsible Body/Role:** PESC

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved PESC ToR v1.0
- PESC Meeting Minutes 1 with authorization for Consortium Engagement

**Dependencies:**

- Formal PESC Membership Confirmation
- Legal Counsel Retained

### 6. Project Director/Lead Engineer drafts initial ToR for the Operational Management Team (OMT), focusing on CapEx management ($36M) and facility readiness milestones.

**Responsible Body/Role:** Project Director/Chief Executive

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft OMT ToR v0.1

**Dependencies:**

- PESC Inception Hold

### 7. PESC reviews and approves the OMT ToR, authorizing the COO/Project Director to formally select and appoint the OMT Chair (COO) and finalize membership.

**Responsible Body/Role:** PESC

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved OMT ToR v1.0
- OMT Chair Appointment Confirmed

**Dependencies:**

- Draft OMT ToR v0.1
- PESC Meeting Minutes 1

### 8. Upon PESC authorization, the designated CEO/Project Director formally initiates recruitment for the core 3 surgeons and the Lead Regulatory Liaison using the 5-year guaranteed contract structure.

**Responsible Body/Role:** Head of Human Resources & Administration (under OMT oversight)

**Suggested Timeframe:** Project Week 4 - 8

**Key Outputs/Deliverables:**

- Core Staffing Acquisition Plan Finalized
- Offer Letters Issued for 3 Surgeons

**Dependencies:**

- Approved OMT ToR v1.0

### 9. The International Ethics Review Consortium finalizes the Service Level Agreement (SLA) with the Project Director, which the lead Legal Counsel reviews for NZ alignment.

**Responsible Body/Role:** International Ethics Review Consortium / Legal Counsel

**Suggested Timeframe:** Project Month 2

**Key Outputs/Deliverables:**

- Draft SAEP SLA v0.5

**Dependencies:**

- PESC authorization for Consortium Engagement

### 10. Draft ToR for the Specialized Assurance & Ethics Panel (SAEP) is created, specifying binding veto rights over patient acceptance and tissue protocols.

**Responsible Body/Role:** Lead Regulatory/Compliance Liaison (Initial Draft)

**Suggested Timeframe:** Project Month 2

**Key Outputs/Deliverables:**

- Draft SAEP ToR v0.1

**Dependencies:**

- Draft PESC ToR v0.1

### 11. PESC approves the SAEP SLA and ToR, formalizing the outsourcing of ethical gatekeeping and authorizing the Chief Compliance Officer appointment to the SAEP structure (Non-voting).

**Responsible Body/Role:** PESC

**Suggested Timeframe:** Project Month 3

**Key Outputs/Deliverables:**

- Finalized SAEP SLA and ToR v1.0
- Chief Compliance Officer appointed to SAEP

**Dependencies:**

- Draft SAEP ToR v0.1
- Draft SAEP SLA v0.5

### 12. OMT finalizes facility lease location in Auckland and begins procurement of Class III surgical/lab equipment, allocating initial CapEx tranche.

**Responsible Body/Role:** Operational Management Team (OMT)

**Suggested Timeframe:** Project Month 3 - 5

**Key Outputs/Deliverables:**

- Auckland Facility Lease Signed
- Initial Equipment Purchase Orders Issued

**Dependencies:**

- Approved PESC Budget Tranche
- Decision 2: Auckland Lease Choice Confirmed

### 13. SAEP holds its organizational meeting: Finalize internal data sharing protocols and sign MOU with NZ HDEC (relying on SAEP vetting) to mitigate Regulatory Risk 1.

**Responsible Body/Role:** Specialized Assurance & Ethics Panel (SAEP)

**Suggested Timeframe:** Project Month 4

**Key Outputs/Deliverables:**

- SAEP Kick-off Minutes
- HDEC Reliance MOU Executed

**Dependencies:**

- Finalized SAEP SLA and ToR v1.0

### 14. OMT oversees the facility fit-out, ensuring compliance with Layer-4 Biosecurity requirements and utility infrastructure support for specialized cryo-storage.

**Responsible Body/Role:** Operational Management Team (OMT)

**Suggested Timeframe:** Project Month 5 - 12

**Key Outputs/Deliverables:**

- Facility Retrofit Completion Certificate
- Layer-4 Biosecurity Audit Clearance

**Dependencies:**

- Auckland Facility Lease Signed
- Initial Equipment Purchase Orders Issued

### 15. Core surgical team (3 Surgeons) is contracted and begins specialized procedural/protocol training, focusing on the Maximal Compatible Pairing Protocol and Layer-4 protocols.

**Responsible Body/Role:** Head of Human Resources & Administration (Monitored by OMT)

**Suggested Timeframe:** Project Month 6

**Key Outputs/Deliverables:**

- Core Team Fully Onboarded
- Completion Sign-off on Layer-4 and Pairing Protocol Training

**Dependencies:**

- Offer Letters Issued for 3 Surgeons
- Finalized Donor/Recipient Pairing Protocol Standards (PESC Approval)

### 16. OMT oversees the delivery and install of the Integrated Digital EHR system (Hospitals/CRM/Cryo-Inventory) and secures independent third-party security audit.

**Responsible Body/Role:** Lead Biomedical Engineer/Facility Manager (OMT)

**Suggested Timeframe:** Project Month 8 - 14

**Key Outputs/Deliverables:**

- Integrated EHR System Installed and Tested
- Initial Cybersecurity Audit Report

**Dependencies:**

- Initial Equipment Purchase Orders Issued
- Assumption Issue 8: Integrated Digital Systems Requirements Met

### 17. SAEP conducts final review of the Tissue Acquisition Protocol documentation (non-financial benefits structure) and vendor contracts.

**Responsible Body/Role:** Specialized Assurance & Ethics Panel (SAEP)

**Suggested Timeframe:** Project Month 10

**Key Outputs/Deliverables:**

- Binding Opinion on Tissue Acquisition Protocol Integrity

**Dependencies:**

- Finalized Donor/Recipient Pairing Protocol Standards
- Legal Counsel retainer established

### 18. OMT confirms the technical readiness of the Remote Patient Monitoring (RPM) system, validating its biometric adherence trigger function against contractual requirements, as required by the recurring revenue model.

**Responsible Body/Role:** Lead Biomedical Engineer/Facility Manager (OMT)

**Suggested Timeframe:** Project Month 15

**Key Outputs/Deliverables:**

- RPM System Technical Validation Report
- Compliance Acceptance for Subscription Trigger

**Dependencies:**

- SAEP Reviews Ethical Protocol
- Initial Cybersecurity Audit Report

### 19. PESC grants 'Operational Readiness Approval' contingent on final facility inspections, confirming budget adherence, staffing, and SAEP/HDEC alignment. This authorizes patient enrollment commencement.

**Responsible Body/Role:** Project Executive Steering Committee (PESC)

**Suggested Timeframe:** Project Month 17

**Key Outputs/Deliverables:**

- PESC Final Sign-off: Operational Readiness Authorized
- Facility Handover Documentation

**Dependencies:**

- Facility Retrofit Completion Certificate
- HDEC Reliance MOU Executed
- RPM System Technical Validation Report

### 20. OMT commences patient scheduling and pre-operative screening based on the approved Maximal Compatible Pairing Protocol.

**Responsible Body/Role:** Operational Management Team (OMT)

**Suggested Timeframe:** Project Month 18

**Key Outputs/Deliverables:**

- First Patient Scheduled
- 18-Month Post-Operative Reintegration Support initiated for Patient 1

**Dependencies:**

- PESC Final Sign-off: Operational Readiness Authorized

### 21. SAEP begins binding review of Patient 1's psychological screening and ethical consent documentation prior to surgery.

**Responsible Body/Role:** Specialized Assurance & Ethics Panel (SAEP)

**Suggested Timeframe:** Project Month 18

**Key Outputs/Deliverables:**

- Binding Opinion for Patient 1 Surgical Approval

**Dependencies:**

- First Patient Scheduled