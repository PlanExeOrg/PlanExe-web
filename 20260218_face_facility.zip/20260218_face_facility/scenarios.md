# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** Highly ambitious and scientifically groundbreaking, involving creating a novel, specialized medical/cosmetic service (facial transplantation) within a constrained national jurisdiction (New Zealand).

**Risk and Novelty:** Extremely high risk and novelty, involving experimental surgery, significant ethical hurdles, and reliance on high-value, subscription-based medical services. The plan explicitly steers away from the 'most aggressive scenario.'

**Complexity and Constraints:** High complexity due to multidisciplinary requirements (surgery, ethics, supply chain, real estate) constrained by a $90M budget and the need for a recurring physical presence.

**Domain and Tone:** Commercial/Medical Technology venture, characterized by a pragmatic tone focused on establishing a long-term, high-cost operational business supported by recurring revenue.

**Holistic Profile:** 

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Builder's Foundation
**Strategic Logic:** This path seeks a dependable, scalable business model by balancing innovation with regulatory prudence. It utilizes a proven physical footprint and prioritizes securing the core recurring revenue stream via managed compliance, leading to stable, long-term growth.

**Fit Score:** 9/10

**Why This Path Was Chosen:** This scenario balances innovation (experimental protocols implicitly accepted via non-sibling matching) with prudence (leased facility, managed compliance/subscription model). It seeks dependable growth without reckless abandonment of safety, fitting the plan's explicit constraint.

**Key Strategic Decisions:**

- **Donor/Recipient Pairing Protocol:** Implement a maximal compatible donor-recipient matching algorithm prioritizing long-term immune stability over cosmetic expediency for all procedures.
- **Facility Build-Out Scope & Location:** Secure a long-term lease for an existing, retrofitted specialized surgical theatre in Auckland, focusing capital on equipment and staffing rather than land acquisition and new construction.
- **Subscription Recurrence Definition:** Charge a steep, non-refundable initial procedure fee followed by a low monthly maintenance fee contingent upon strict adherence to compliance monitoring schedules.
- **Tissue Acquisition Protocol:** Create a highly specialized, ethically vetted procurement contract offering substantial, non-financial restorative benefits (e.g., free future cosmetic surgeries) to eligible donor families.
- **Ethical Gatekeeping and Patient Screening Intensity:** Outsource the entire ethical review panel to an independent, established international consortium, absorbing their external vetting costs in exchange for reduced internal liability exposure.

**The Decisive Factors:**

The Builder's Foundation is the optimal fit because the plan demands a complex, novel scientific venture ($90M, physical facility, facial transplant) while explicitly rejecting the 'most aggressive scenario.'

*   **Alignment:** This scenario balances the need for innovation (using maximal compatibility matching) with prudent risk management (leasing an existing site in Auckland, using a regulated initial fee plus maintenance for subscription revenue).
*   **Rejection of Pioneer's Leap:** It avoids the severe risks associated with the Pioneer's Leap, such as cash compensation for tissue and highly streamlined ethical screening, which contradict the need for long-term operational stability.
*   **Rejection of Consolidator's Caution:** It is superior to the Consolidator's Caution because leaning exclusively on sibling pairings (Consolidator strategy) would starve the operation of necessary revenue to cover the massive fixed facility costs inherent in this high-ambition project, making 'The Builder's Foundation' the only viable long-term strategy.

---
## Alternative Paths
### The Pioneer's Leap
**Strategic Logic:** This is the high-risk, high-reward path prioritizing technological acceleration and market capture. It accepts higher immediate internal risks (clinical and ethical) to establish technological leadership quickly, funding aggressive expansion through high initial cash flow from less restrictive patient acquisition.

**Fit Score:** 4/10

**Assessment of this Path:** This scenario is highly aggressive, embracing market capture through high risk (experimental regimes, cash compensation for tissue, streamlined vetting). This violates the explicit constraint to 'Don't go for the most aggressive scenario.'

**Key Strategic Decisions:**

- **Donor/Recipient Pairing Protocol:** Leverage experimental immunosuppressive regimens on a case-by-case basis, accepting elevated short-term morbidity risk to maximize the pool of eligible subscribers.
- **Facility Build-Out Scope & Location:** Construct a purpose-built, high-security facility in a remote, low-cost region of the South Island, accepting the challenge of recruiting specialist surgical and nursing staff away from established urban hospitals.
- **Subscription Recurrence Definition:** Structure the fee as a one-time, seven-figure acquisition charge payable upon successful graft integration, treating the subscription model solely as a post-surgical warranty vehicle.
- **Tissue Acquisition Protocol:** Establish a competitive, upfront cash compensation program for donor families sourced via specific pre-agreed neurological criteria to ensure rapid tissue viability upon procurement.
- **Ethical Gatekeeping and Patient Screening Intensity:** Streamline the psychological and social screening process to focus only on acute, non-mitigatable risks, prioritizing throughput to begin revenue generation sooner.

### The Consolidator's Caution
**Strategic Logic:** This scenario emphasizes risk mitigation and capital preservation, aligning with the mandate not to pursue the most aggressive path. It focuses on ultra-low friction operations by relying solely on existing regulatory frameworks, accepting a smaller initial addressable market.

**Fit Score:** 7/10

**Assessment of this Path:** This scenario is too risk-averse for the inherent high-novelty of facial transplants. Relying only on genetically near-identical siblings severely limits service adoption, jeopardizing the $90M fixed cost coverage, though it adheres strictly to low-risk ethical/tissue sourcing.

**Key Strategic Decisions:**

- **Donor/Recipient Pairing Protocol:** Adopt a phased clinical protocol relying solely on genetically near-identical (e.g., sibling) pairings for the initial five years of operation to secure proof of concept.
- **Facility Build-Out Scope & Location:** Secure a long-term lease for an existing, retrofitted specialized surgical theatre in Auckland, focusing capital on equipment and staffing rather than land acquisition and new construction.
- **Subscription Recurrence Definition:** Implement an 'identity-locked' monthly subscription fee that auto-renews only if the recipient actively maintains the transplanted tissue through required immunosuppressant drug refills.
- **Tissue Acquisition Protocol:** Source 100% of requisite facial tissues exclusively from deceased donors qualifying under existing rigorous organ donation protocols, avoiding any direct pre-mortem compensation.
- **Ethical Gatekeeping and Patient Screening Intensity:** Implement the most rigorous established international bioethics standards for experimental procedure consent, accepting a smaller initial recipient pool to ensure maximum legal and reputational insulation.
