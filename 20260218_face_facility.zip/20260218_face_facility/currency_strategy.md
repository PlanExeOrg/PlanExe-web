This plan involves money.

## Currencies

- **NZD:** New Zealand Dollar is the local transactional currency for facility lease, local staff salaries, and local expenses within New Zealand.
- **USD:** The project budget is established in USD ($90M USD), and major equipment purchases or international consultation fees may be denominated in USD.

**Primary currency:** USD

**Currency strategy:** Given the large initial capital budget ($90M USD) and the high-value nature of the services, USD will be used for primary budgeting and high-value purchasing. Routine local transactions (rent, local supplies) will be conducted in NZD. Given the project is centrally located in a stable economy (New Zealand), currency risk management will focus on hedging large USD-to-NZD conversions for capital deployment, rather than managing hyperinflation risk.