Persuasive elevator pitch.

# European Cross-Border Rail Through-Ticketing Programme

## Project Overview

**Break the fragmentation barrier: unlock 40% of European cross-border rail journeys with one ticket, one payment, one promise.** Today, passengers buying a multi-carrier journey across Europe face multiple bookings, multiple payments, and zero continuity rights if a connection fails. This programme delivers the technical, commercial and governance infrastructure to fix that by Month 60 (2031-10-08): a shared real-time inventory layer, certified distributor access, accredited payment providers, passenger-rights protection, and regional hubs enabling smaller carriers to participate immediately.

The Pragmatic Foundation approach avoids years of legal set-up by using existing institutions, tiered access certification instead of price-fixing, and milestone-based carrier co-funding rather than heavy new entities. With a EUR 1.5 billion public coordination budget and a realistic path to the Month 30 (2029-04-08) mandatory API deadline, this programme makes rail competitive with short-haul flying across four priority corridors and builds the foundation for EU-wide through-ticketing. It is not the most aggressive option on any lever—it is the realistic one that protects the critical path, includes smaller operators, and actually gets built.

## Target Audience

**Primary audience:** DG MOVE, the Commission and Parliament's TRAN committee, member-state governments and transport ministers evaluating the Regulation and programme commitment.

**Secondary audience:** Major carriers (SNCF, Deutsche Bahn, ÖBB, Renfe, Trenitalia, NS, SJ) and distributors (Trainline, Omio) assessing participation risk and benefit.

**Tertiary audience:** National transport regulators and consumer bodies assessing consumer and competition safeguards.

The pitch appeals to each stakeholder group distinctly: to the Commission and member states, the fiscal discipline and milestone-based approach prove manageability; to carriers, the tiered access and co-funding reduce integration burden; to regulators and consumers, the accessibility and passenger-rights backstop show inclusion and protection. The emphasis on **realistic execution** speaks to all audiences sceptical of over-ambitious EU programmes.

## Risks and Mitigation Strategies

- **Regulation adoption slips past Month 9 (2027-07-08)**: Standards work runs in shadow from Month 0 (2026-10-08); if adoption is delayed past Month 10 (2027-08-08), carrier onboarding pauses and the critical path resets, extending the Month 30 (2029-04-08) milestone. *Mitigation:* Hire external standards consortium by Month 8 (2027-06-08) if needed; negotiate phase-in periods with Parliament.

- **Arbitration panel cannot enforce against large incumbents**: A panel with technical binding power but no commercial control may lack teeth when SNCF or Deutsche Bahn resist access terms. *Mitigation:* Secure written Commission delegation with escalation to DG COMP for repeated non-compliance; tie carrier co-funding to compliance with access decisions.

- **Budget overrun of 20–30% (EUR 300–450 million) exceeds the EUR 215 million free contingency**: A supplementary authority of EUR 100–200 million (estimate) may still not close the gap. *Mitigation:* Freeze co-funding at 10% after Month 24 (2028-10-08) if quarterly spend exceeds 115% pro-rata; seek early mid-course reviews at Months 12 and 24 (2027-10-08, 2028-10-08).

- **Smaller carriers cannot meet Month 30 (2029-04-08) API deadline without hub infrastructure**: Regional hub delays leave 12–18 carriers behind. *Mitigation:* Contract hubs by Month 3 (2027-01-08); run 2–4 week dual-runs before go-live and suspend onboarding if booking-failure exceeds 2% for one week.

- **GDPR or competition-law challenge to the shared data layer**: A court ruling that the neutral data operator or fare-sharing rules violate competition law could unwind the clearing model. *Mitigation:* Complete DPIA by Month 2 (2026-12-08); reach EDPB/DPA consensus by Month 4 (2027-02-08); consult DG COMP on data scope by Month 6 (2027-04-08); seek formal clarity or block exemption if time allows.

## Metrics for Success

- **Through-ticket share**: 40% of cross-border rail journeys sold as through-tickets by Month 60 (2031-10-08), validated by quarterly carrier and distributor reporting with independent auditor spot-checks. Interim gate: at least 15% by Month 24 (2028-10-08). Below 15% triggers co-funding review.

- **Distributor complaints**: Reduced to at or below 50% of the Month 9 (2027-07-08) validated baseline by Month 60 (2031-10-08), measured by standardised complaint taxonomy across the public reference distributor, Trainline, Omio and national platforms.

- **Corridor bookability**: At least 90% of traffic on each priority corridor bookable end-to-end by Month 30 (2029-04-08); below 90% triggers Commission review.

- **Carrier conformance**: 100% of carriers above EUR 50 million cross-border revenue meeting the conformance testing standard by Month 30 (2029-04-08); smaller carriers via hubs or native implementation by Month 30 (2029-04-08), measured through the 90% corridor-bookability threshold, with any smaller-carrier exemption documented and time-limited.

- **API and clearing performance**: p95 search latency under 2 seconds, 99.95% uptime, hub recovery under 2 hours, settlement completion under 48 hours.

- **Accessibility**: Assistance confirmation within 24 hours at 90%+ rate; delivery at 95%+; complaint rate under 2%.

- **Budget adherence**: Spend within the EUR 1.5 billion cap with free contingency of EUR 215 million; quarterly reviews at Months 12, 24, 36 (2027-10-08, 2028-10-08, 2029-10-08); overrun triggers Tier 1–3 spending cuts.

- **Stakeholder trust**: Dispute resolution time under 60 days; absence of antitrust complaints; carrier and distributor participation above 85% of eligible operators.

## Stakeholder Benefits

**For carriers**: **Reduced compliance cost** via tiered access certification (no early price-fixing) and milestone-based co-funding (EUR 234 million grants for API and system integration). Smaller carriers access regional hubs (EUR 44 million) rather than building native APIs alone. Larger carriers gain guaranteed non-discriminatory access to all distributors and visibility into through-ticket demand. Revenue upside from 40% through-ticket share and the modal-shift opportunity.

**For distributors**: **Non-discriminatory OSDM API access** for any distributor that passes conformance testing, enabling Trainline, Omio and smaller platforms to sell the same through-products. Early API access (Month 15 = 2028-01-08) with integration incentive payments tied to verified through-ticket sales.

**For passengers**: **Single booking reference, single payment and continuity-of-journey rights** (reroute under 4 hours, refund under 10 days) across carriers—eliminating the multiple-booking pain point. Accessibility assistance confirmed within 24 hours.

**For member states and regulators**: **Strengthened capacity** through twinning and a lead-authority network for cross-border dispute resolution, reducing fragmentation of enforcement. Clear standards by Month 18 (2028-04-08) remove regulatory uncertainty.

**For smaller and newer entrants** (startups, regional operators): The public reference distributor and open conformance testing level the playing field; hub access and capacity-building funding (EUR 100 million) support operators excluded from traditional distribution channels.

**For transport policy**: A realistic, achievable path to the EU Regulation on Digital Booking and Ticketing; 40% through-ticket penetration and a 5–15% modal shift from short-haul air (planning range, estimate) support decarbonisation and mobility objectives without requiring aggressive price controls or new central institutions.

## Ethical Considerations

**Non-discrimination and access**: The certification-based tiered access scheme is designed to prevent the discriminatory practices (slow inventory feeds, higher latency, limited itineraries) that incumbents can impose. Auditable conformance testing and carrier audits of distributors create mutual accountability. A neutral data-layer operator with segregated carrier data access logs prevents any carrier from seeing competitors' commercial inputs. This protects **competition** and smaller market entrants.

**Passenger protection**: The single-contact passenger-rights backstop gives travellers one clear promise: if a connection is missed, the selling distributor handles rerouting and refunds, with cost recovered from the liable carrier. This removes the risk that passengers are passed between carriers. GDPR safeguards (90-day PII deletion, with extension only for active refund or complaints) prevent long-term personal data pooling.

**Accessibility and inclusion**: Assistance booking is embedded in the standard interface, not an add-on; confirmation within 24 hours is mandatory. The public reference distributor and accessibility data in the shared layer ensure that persons with reduced mobility are not left behind by commercial platforms.

**Fiscal discipline and public accountability**: The EUR 1.5 billion budget is fixed; quarterly spending reviews and Tier 1–3 cuts if spend exceeds 115% pro-rata prevent unchecked cost growth. The arbitration panel's technical decisions are published and subject to Commission review; no decisions are made in private.

**Realistic pragmatism**: The Pragmatic Foundation scenario avoids fixing prices before the legislation and cost data exist, which would risk both economic inefficiency and legal challenge. It uses existing institutions (accredited payment providers, national regulators, the EU Agency for Railways) rather than building new central entities, reducing the legal set-up burden and leaving sovereignty with member states. This builds trust by showing **restraint**.

## Collaboration Opportunities

**With carriers**: Seek **Commitment Letters** by Month 3 (2027-01-08) naming native API, hub or gateway pathway; participate in the quarterly Steering Committee and carrier roundtables (dedicated slots for smaller operators). Co-invest in integration through milestone-based grants and hub access.

**With distributors** (Trainline, Omio, national platforms): Sign integration roadmaps by Month 3 with early API access (Month 15 = 2028-01-08) in exchange for through-ticket sales commitments. Distributor advisory council meets monthly with veto over consumer-facing design. Co-market the through-ticket with shared campaign budgets (EUR 10–20 million, estimate).

**With payment institutions**: Apply for accreditation by Month 2 (2026-12-08) to operate split-payment and refund orchestration as a competitive service; at least two accredited providers are required. Fee subsidy covers 60% of transaction fees (Months 0–24 = 2026-10-08 to 2028-10-08) to lower adoption barriers.

**With member states and regulators**: Participate in the Standing Regulators Committee; apply for twinning and capacity-building grants (EUR 100 million) to align enforcement procedures. Designate a lead regulator for cross-border access disputes.

**With data and accessibility bodies**: Support EDPB/DPA consensus-building (Months 0–4 = 2026-10-08 to 2027-02-08) on Standard Contractual Clauses and data-sharing scope. Accessibility working group meets monthly; organisations can propose standards and test cases.

**With research and academia**: Independent evaluator hired Month 3 (2027-01-08) to build counterfactual model of modal shift and validate the 40% through-ticket target. Open access to anonymised programme data for peer-reviewed research on modal shift, competition effects and accessibility outcomes.

## Long-term Vision

**Months 0–30 (2026-10-08 to 2029-04-08) (Foundation Phase)**: Establishes the binding technical standards (Month 18 = 2028-04-08), mandatory OSDM APIs (Month 30 = 2029-04-08), accredited payment providers, certified distributor access and regional hubs. By Month 30 (2029-04-08), any conformant distributor can sell through-tickets across any participating carrier on the four priority corridors (Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin), with passenger-rights protection and accessibility confirmation.

**Months 30–60 (2029-04-08 to 2031-10-08) (Scale and Impact Phase)**: Expands through-ticketing from early-adopter corridors to mainstream market share. The 40% through-ticket target is reached by Month 60 (2031-10-08). Accessibility delivery matures above 95%; distributor complaints fall to half the baseline. A 5–15% modal shift from short-haul air is achieved through superior pricing and convenience.

**Month 36 (2029-10-08) onwards (TEN-T Extension)**: Begins expansion beyond the four priority corridors to the full Trans-European Transport Network, supported by EUR 12 million TEN-T hubs reserved at launch and community co-funding. Regional and smaller operators join via the certified hub pathway.

**Post-Month 60 (2031-10-08) and Beyond (Sustainability Transition)**: The programme transitions from public coordination funding to a cost-recovery model: payment providers recover fees from carriers and distributors; hub operators aim to move to fee-based models; the shared data layer and public reference distributor seek sustainable funding (EUR 45 million/year, estimate; funding model to be decided by Month 48 = 2030-10-08). Multimodal hooks to buses, ferries and short-haul air create seamless mobility, with rail as the spine. The through-ticket becomes the default for European cross-border travel, driving further modal shift and supporting EU decarbonisation targets. Lessons learned feed into global standards (UIC/OSJD) and regional initiatives (e.g. Rail Baltica, Nordic corridors) beyond the EU.

## Call to Action

- **Carriers**: Commit **Binding Commitment Letters** by Month 3 (2027-01-08) naming your native API or hub pathway and IT investment.

- **Distributors** (Trainline, Omio, national platforms): Sign the integration roadmap with early API access and incentive payment tied to through-ticket volumes from Month 18 (2028-04-08).

- **Member states**: Prepare national regulator capacity: fund DPA twinning and appoint a lead regulator for cross-border access disputes.

- **Payment institutions**: Apply for accreditation by Month 2 (2026-12-08)—at least two competitive providers are essential to the clearing model.

- **Programme launch**: The programme launches formally at Month 1 (2026-11-08); the arbitration panel delegation must be signed by Month 2 (2026-12-08) for standards work to start on schedule.

- **Coordination hub**: Visit the programme's coordination hub (launch Month 2 = 2026-12-08) for the full standards roadmap, hub eligibility criteria, and co-funding application templates.
