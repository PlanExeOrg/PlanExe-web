Persuasive elevator pitch.

# EU Cross-Border Rail Ticketing and Passenger Protection Programme

## Project Overview

Imagine boarding a train in Paris and seamlessly transferring across three carriers to reach Vienna with a single ticket, unified passenger protection, and automatic rerouting if a connection fails. Today, that journey requires separate bookings, separate liability, and no recourse if one carrier's delay strands you.

This programme delivers that vision: a **federated EU cross-border rail ticketing system** that turns fragmented national rail networks into one integrated market. By layering shared real-time data, carrier-funded liability protection and universal booking access over existing carrier systems, the programme enables **40% of cross-border journeys to be sold as single through-tickets within five years**—halving distributor complaints. It does so on a fixed EUR 1.5 billion public budget, with carriers funding their own connection liability and a private last-resort distributor handling the rest. Subject to adoption of the Regulation (not verified) and DG COMP guidance, this is regulation-backed, pragmatically federated, and delivers transformational passenger value without centralised control risk.

## Target Audience

**Primary stakeholders:** EU institutions (DG MOVE, the Agency for Railways, the Commission); national rail operators and CER; independent distributors (Trainline, Omio); member-state governments.

**Secondary stakeholders:** National railway regulators, disability-rights and consumer bodies, and DG COMP.

The pitch aligns institutional interests (member states and the Commission want digital integration), industry interests (carriers want network effects and regulatory certainty for investment; distributors want fair access), and passenger interests (seamless cross-border travel). The language avoids jargon but assumes familiarity with EU transport regulation and rail industry structure.

## Risks and Mitigation Strategies

- **Carrier refusal over unpriceable connection liability:** Mitigated by an actuarial study (Month 6 = 2027-04-12) and a carrier-signed guarantee pool with per-incident caps, coinsurance thresholds and trailing-performance incentives.

- **Legacy IT delays:** Tiers spread mandatory API exposure across Months 30/36/42 (2029-04-12, 2029-10-12, 2030-04-12), with EUR 240M adapter budget line for legacy modernisation (EUR 30M shared adapter modules tendered by Month 12 (2027-10-12); EUR 210M tiered carrier funding released on verified conformance).

- **Regulation adoption slip:** Parallel shadow-standards workstream prepared, with pilot authority, by Month 6 (2027-04-12), to be launched if the regulation slips past Month 9 (2027-07-12).

- **Competition-law challenge:** Pre-notification to DG COMP at Month 2 (2026-12-12), guidance by Month 12 (2027-10-12), clean-team protocol for Article 101 safe-harbour by Month 14 (2027-12-12).

- **Budget overrun:** EUR 150M force-majeure reserve and variance triggers at EUR 100M (defer TEN-T extension), EUR 200M (cut concession funding 20%, i.e. EUR 60M of the EUR 300M envelope, and extend term from 5 to 7 years) and EUR 300M (restrict to four corridors).

## Metrics for Success

**Outcome metrics:**

- 40% of cross-border journeys sold as single through-tickets by Month 60 (2031-10-12)
- Distributor complaints halved

**Delivery metrics:**

- Binding standards by Month 18 (2028-04-12)
- Tier 1 API exposure achieved by all Tier 1 carriers (count fixed by the Month 6 (2027-04-12) tier assignment) by Month 30 (2029-04-12); 25+ carriers network-wide by Month 42 (2030-04-12)
- Four corridors live by Month 48 (2030-10-12)
- Full TEN-T network by Month 60 (2031-10-12)

**Operational metrics:**

- p95 latency below 2 seconds, availability 99.5%, stale-seat failures below 1%
- Settlement cycle 5 business days, reconciliation error below 0.5%
- SLA misses trigger 5% tranche penalties

**Budget metric:**

- Public spend within EUR 1,500M cap; concession operating subsidy capped at EUR 60M over five years

## Stakeholder Benefits

**Passengers:** Unified cross-border tickets with automatic rerouting if a connection fails, halved complaints and reduced distributor friction.

**National operators:** Network effects from through-ticketing drive passenger volumes; carrier-funded liability pool shares connection risk fairly; mandatory API access is intended to be regulation-backed, subject to adoption of the Regulation (not verified), not ad-hoc.

**Member states:** EU decarbonisation targets supported (indicative 5–10% air-to-rail shift on benchmarked routes, estimate); digital **integration** strengthens European competitiveness; coordinated funding leverages EUR 1.5 billion alongside EUR 1.5–3.0 billion (estimate) of carrier-financed IT investment.

**Independent distributors:** Level playing field enforced by the conformance gate and commission band (2.5–4.5%, indicative); non-discriminatory OSDM API access; public last-resort distributor is a concessionaire (private), not a competitor.

**DG COMP:** Data-sharing and clearing structures are targeted for legal comfort via DG COMP pre-notification at Month 2 (2026-12-12) and guidance by Month 12 (2027-10-12) (not verified); clean-team protocol limits commercial data visibility.

## Ethical Considerations

**Passenger protection:** Existing EU rail passenger-rights regulation is the floor; independent legal review by Month 6 (2027-04-12) ensures through-ticket liability rules are accessible and enforceable.

**Accessibility:** Persons with reduced mobility and bicycle reservations are bookable through-components; 80% wheelchair access and 90% assistance within 4 hours' notice (proposed threshold) on corridors by Month 40 (2030-02-12).

**Fair competition:** Commission-supervised commission band (identical for all distributors); non-discriminatory API access; public last-resort channel is tendered to a private concessionaire, not operated by the state.

**Data governance:** Clean-team protocol ensures carriers' commercial data is held only by a neutral trustee; no data pooling for purposes beyond clearing and settlement.

**Inclusivity:** Biweekly steering group includes disability-rights and consumer bodies as observers; usability testing by Month 18 (2028-04-12).

## Collaboration Opportunities

**Carriers (CER, national operators):**

- Design and sign off the liability model (Months 1–6 = 2026-11-12 to 2027-04-12)
- Commit Tier 1 API readiness (by Month 30 = 2029-04-12)
- Shape commission band and SLA standards through the steering group

**Distributors (Trainline, Omio, CRS):**

- Contribute conformance test scenarios
- Serve on the API design working group
- Bid on the EUR 300M concession or backend integration contracts

**Member states and regulators:**

- Receive national carrier support and training, delivered to member states from the EUR 200M capacity-building envelope financed from the public cap
- Co-host the Technical Secretariat (Agency at Valenciennes)
- Conduct local regulator impact assessments by Month 3 (2027-01-12)

**Technology and fintech partners:**

- Develop shared adapter modules (EUR 30M), real-time cache and event-feed infrastructure (EUR 50M), federated clearing platform (EUR 220M)

**International railways (SBB, DB, ÖBB, SNCF):**

- Lead by example on Tier 1 API exposure
- Pilot disruption re-accommodation choreography at Months 12–18 (2027-10-12 to 2028-04-12)

## Long-term Vision

By Month 60 (2031-10-12), the programme establishes cross-border rail as seamlessly bookable and reliably protected as domestic rail today—. This is sustained beyond the programme by transferring governance to the EU Agency for Railways (custodian of the OSDM standard and conformance test suite), a permanent carrier steering committee and national regulators as observers.

The **federated architecture** (streamed availability shadow, carrier-funded liability, distributed clearing) scales to multimodal integration with bus, ferry and short-haul air under the same OSDM and liability frameworks. The EUR 1.5 billion public investment catalyses EUR 1.5–3.0 billion in carrier IT, creating a permanent **digital infrastructure layer** that supports not just through-ticketing but real-time disruption management, carbon-intensity signalling and demand-responsive services.

The 40% through-ticket target and halved complaints reduce regulator burden and distributor friction for decades, making European rail a model for other continents.

## Call to Action

**Member-state governments and national operators:** Commit now to the steering group and liability model sign-off by Month 4 (2027-02-12); early commitment unlocks EUR 80M in conformance support.

**Independent distributors:** Join the Month 1 (2026-11-12) governance launch to shape the commission band and API access rules before binding standards.

**Investors and technology partners:** Contact DG MOVE to bid on the EUR 50M real-time layer, EUR 220M clearing infrastructure and EUR 30M shared adapter modules—all to be tendered by Month 12 (2027-10-12); the remaining EUR 210M of the adapter line is tiered carrier funding released on verified conformance.

**The Commission:** Adopt the Digital Booking and Ticketing Regulation by Month 18 (2028-04-12) with OSDM pinned, and secure DG COMP competition-law guidance by Month 12 (2027-10-12).