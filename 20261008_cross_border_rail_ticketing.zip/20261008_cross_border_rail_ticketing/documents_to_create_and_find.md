# Documents to Create

## Create Document 1: Project Charter

**ID**: 7d4cb30a-54ae-41ca-bd17-9f8a314f0623

**Description**: Foundational governance document establishing programme authority, scope, objectives (40% through-ticket share, halved complaints by Month 60 = 2031-10-12), stakeholders, success criteria, and decision-making structure. Defines Programme Director accountability, steering group composition (75% supermajority rule) and escalation paths to Commission. Primary audience: EU institutions, carriers, distributors, national regulators.

**Responsible Role Type**: Programme Director

**Primary Template**: PMI Project Charter Template

**Secondary Template**: EU institutional project charter (sample from DG MOVE prior programmes)

**Steps to Create**:

- Workshop with DG MOVE leadership and CER to define charter scope and success criteria by Month 0.5 (2026-10-27)
- Draft charter covering authority, stakeholder roles, decision rights and escalation by Month 1 (2026-11-12)
- Obtain signed approval from DG MOVE Director-General, EU Agency for Railways Director and CER President by Month 1.5 (2026-11-27)
- Publish and distribute to all 25+ carriers and steering group members; archive with Commission

**Approval Authorities**: DG MOVE Director-General, EU Agency for Railways Director, CER President, European Commission Transport Commissioner (if escalated for mediation)

**Essential Information**:

- Define the Programme Director's authority, delegation limits and accountability for delivery of the 40% through-ticket target and EUR 1,500M budget cap by Month 60 (2031-10-12).
- Specify steering group composition (biweekly meetings, 75% supermajority voting rule on Decisions 1–3 and 12), member roles and escalation paths to the Commission Transport Commissioner for deadlock resolution.
- Establish decision-making authority: which decisions require steering votes (liability backstop, clearing architecture, public distributor mandate, remuneration band), which require Commission approval, and the binding-vote deadlines (Month 6 = 2027-04-12 for Phase 1 gate).
- Articulate the programme's scope: federated settlement, streamed availability shadow, carrier-funded guarantee pool, last-resort concession; excluded: central inventory exchange, public pay-first fund, full consumer app.
- Define success metrics: 40% through-ticket share, distributor complaints halved, binding standards Month 18 (2028-04-12), Tier 1 API exposure Month 30 (2029-04-12), four-corridor go-live Month 48 (2030-10-12), public spend within EUR 1,500M.
- Detail the governance model: Programme Office (80 staff, DG MOVE) and Technical Secretariat (50 staff, Agency, Valenciennes); liaison officers in Brussels, Valenciennes, Berlin, Madrid; external advisory board for oversight.
- State the risk-escalation framework: budget variance triggers (EUR 100M/200M/300M) and remediation actions; deferral of TEN-T extension or concession funding cuts; no pool draw-downs after Month 36 (2029-10-12).
- Clarify stakeholder roles: which parties control which decisions (carriers: liability model sign-off; DG COMP: Article 101 guidance; steering: binding votes on Decisions 1–3, 12; regulators: observer seats).
- Specify document governance: how the charter is approved (by DG MOVE DG, Agency Director, CER President), published and archived; how amendments are handled.
- Outline Phase 1 readiness gate (Month 6 = 2027-04-12): liability model signed by 8+ major carriers, technical audit published, steering votes held; escalation triggers for Month 9 (2027-07-12) and Month 12 (2027-10-12) if unresolved.

**Risks of Poor Quality**:

- Ambiguous Programme Director authority or steering voting rule delays critical decisions (liability, clearing, distributor role) by 1–2 months, cascading to binding-standards deadline (Month 18 = 2028-04-12) and triggering 2–4 month slip to Months 20–22 (2028-06-12 to 2028-08-12), which compresses Phase 2 conformance work.
- Stakeholder roles unclear: carriers unsure whether they must sign liability model or can block via CER, distributors uncertain of their rights, regulators unclear on observer scope. Results in steering deadlock, withdrawal of major participants (e.g., Trainline rejecting clearing design), and loss of 15–25% of through-ticket volume (estimate).
- Escalation path undefined: when deadlock occurs (e.g., CER refuses liability caps, BEUC demands stronger rights), no clear path to Commission mediation leaves the governance loop stuck for 3–6 months.
- Budget variance triggers absent or loose: concession overruns or adapter acceleration (EUR 150–250M, estimate) are not met with clear corrective action, leading to ad-hoc Commission approval requests, audit findings and erosion of stakeholder confidence.
- Phase 1 readiness gate vague: no explicit decision on what 'signed liability model' means, which carriers constitute binding supermajority, or what happens if only 5–7 carriers sign (instead of 8+). Results in false starts, rework and delay.
- Scope ambiguity: whether the programme includes a full public consumer app, a sandbox, or a last-resort concession not clearly stated in the charter. Causes competing implementation efforts, budget conflict and competing stakeholder expectations.
- No charter publication or distribution mechanism: if the charter is not formally signed and published by Month 1 (2026-11-12), institutional clarity is missing, carriers and distributors lack a reference document, and the programme lacks legal grounding for enforcement of milestone conditions.

**Worst Case Scenario**: The charter is drafted without clear decision-making authority, voting rules or escalation paths. The steering group is convened at Month 2 (2026-12-12) but within two weeks, CER and large carriers disagree on liability-model caps; BEUC and disability bodies demand stronger passenger-rights guarantees; and Trainline and Omio object to the clearing architecture, claiming competition-law risk. With no formal supermajority rule or Commission mediation clause, the steering group becomes deadlocked. The Programme Director cannot force a vote or escalate. By Month 9 (2027-07-12), no binding decisions have been made on liability, clearing or the public distributor mandate. DG MOVE escalates to the Transport Commissioner, who convenes an emergency working group. The binding-standards milestone (Month 18 = 2028-04-12) slips 4–6 months to Months 22–24 (2028-08-12 to 2028-10-12). Mandatory API exposure (Month 30 = 2029-04-12) becomes unachievable; the mandatory milestone date passes with only Tier 1 carriers (8–10 large operators) ready, leaving 15–17 smaller and regional carriers outside. The four-corridor go-live (planned Month 48 = 2030-10-12) is delayed to Month 60 (2031-10-12) at best. The 40% through-ticket target is downgraded to 20–25% (estimate). TEN-T extension is deferred beyond the five-year horizon. Member states and carriers lose confidence; regulatory appetite for mandatory API exposure weakens; the programme ends with a 'lessons learned' review and significantly reduced ambition.

**Best Case Scenario**: The charter is signed by the DG MOVE Director-General, EU Agency for Railways Director, CER President and Commission Transport Commissioner by Month 1 (2026-11-12). It clearly specifies Programme Director authority, the 75% supermajority steering voting rule, binding-decision deadlines and escalation paths to the Commissioner. Steering group meets for the first time Week 1 of Month 2 (2026-12-12), with biweekly cadence thereafter. An option paper for each critical decision is published by Month 2 (2026-12-12), signalling the three alternatives and trade-offs to all stakeholders. By Month 3 (2027-01-12), the technical audit is complete and tier assignments are visible. The liability actuarial study interim report is published. At the Month 4–5 (2027-02-12 to 2027-03-12) steering meetings, carriers negotiate and 10 major carriers sign the liability-model framework with agreed caps and co-insurance thresholds. DG COMP feedback on Article 101 has arrived (Month 12 = 2027-10-12), indicating clean-team clearing is acceptable. At Month 6 (2027-04-12), the steering group votes: Decisions 1–3 and 12 all pass with 8–9 of 9 core members in favour. The technical audit is published. The charter is formally filed with the European Court of Auditors. Binding standards are delivered by Month 18 (2028-04-12) on schedule. Tier 1 API exposure is achieved by Month 30 (2029-04-12). Four-corridor through-ticketing goes live by Month 48 (2030-10-12). The 40% through-ticket target is on track. Carriers and distributors cite the charter's clarity and decision rules as enabling their investment. The programme is heralded as a model for multi-stakeholder EU infrastructure coordination.

**Fallback Alternative Approaches**:

- Adopt a faster charter-approval pathway: convene a single working session with the DG MOVE Director-General, Agency Director and CER President by Month 0.5 (2026-10-27); present a pre-drafted charter with decision authority, voting rule and escalation path already in place (drawn from a template of prior EU rail programmes); seek their written sign-off by email within one week; publish by Month 1 (2026-11-12). This reduces workshop time from one week to one day.
- If CER or carriers formally object to supermajority voting, offer a consensus-plus rule: require binding decisions to pass with 75% supermajority (7 of 9 core members) for Decisions 1–3 (liability, clearing, distributor), but allow bilateral fallback agreements for individual carriers on specific terms; this preserves the binding decision for the baseline but allows opt-outs, reducing stakes and objections.
- If stakeholder alignment is uncertain by Month 3 (2027-01-12), establish a temporary Steering Working Group (Month 3–5 = 2027-01-12 to 2027-03-12) with smaller, focused task teams on each decision (liability team, clearing team, remuneration team), feeding weekly progress to the steering group; this gives stakeholders a voice and shortens decision cycles from 1 month to 1 week per team.
- If the Commission Transport Commissioner cannot commit time for mediation, delegate escalation to the Agency's Board of Stakeholders (a standing body with regulator and carrier representatives) and require the Agency Director to resolve any 2–2 split on a core decision within two weeks, with options papers forcing a choice rather than debate.
- If phase-gate readiness cannot be met by Month 6 (2027-04-12), schedule a 'soft gate' at Month 6 (2027-04-12) with public go/no-go communicated, but allow a 3-month contingency phase (Months 6–9 = 2027-04-12 to 2027-07-12) for final negotiations on any decision not yet signed, deferring binding standards from Month 18 (2028-04-12) to Month 21 (2028-07-12) (estimate) only if absolutely required.
- If the charter cannot be formally approved by the Transport Commissioner due to political constraints, issue a Commission Decision or formal Letter from the Director-General of DG MOVE (rather than a charter) that states the same authorities, voting rule and escalation paths, with the same legal force but lower bureaucratic friction.

## Create Document 2: Carrier Liability and Rights Backstop Model (Actuarial Specification)

**ID**: a5455000-dd85-4e1c-a8df-38ac7a07c015

**Description**: Technical actuarial specification defining the carrier-funded mutual guarantee pool: per-incident caps, co-insurance thresholds, contribution-weighting formula tied to trailing on-time performance, reserve adequacy analysis and quarterly pool-monitoring procedures. Based on 24-month historical missed-connection and rerouting-cost data from at least 5 major carriers. Output: binding liability terms that carriers sign off to expose inventory. Primary audience: CER, 25+ national operators, DG MOVE, Finance lead.

**Responsible Role Type**: Actuary / Carrier Liability Specialist

**Primary Template**: Actuarial valuation report (Insurance Directorate standard)

**Secondary Template**: Financial model template (Excel sensitivity analysis, Monte Carlo simulation for loss clustering)

**Steps to Create**:

- Engage independent actuarial firm by Month 1 (2026-11-12) with 90-day delivery target
- Collect 24-month missed-connection, rerouting-cost and incident-clustering data from SNCF, DB, SBB, Renfe, ÖBB and one smaller operator by Month 1.5 (2026-11-27)
- Analyse data to derive baseline incident frequencies, cost distributions and carrier-specific risk profiles by Month 2 (2026-12-12)
- Develop three sensitivity scenarios (conservative, base, aggressive) for cap levels (EUR 250-2,000 per passenger) and co-insurance triggers (EUR 20M-100M annual draw) by Month 2.5 (2026-12-27)
- Produce final recommendations with worked examples for three carrier profiles (large, regional, small) and confidence intervals by Month 3 (2027-01-12)
- Present model to CER and 10+ major carriers for written feedback by Month 4 (2027-02-12); obtain binding sign-off from at least 8 major carriers and CER by Month 4 (2027-02-12)
- Establish quarterly pool-monitoring process (publish incident rates, contribution adjustments, drawdowns within 15 business days of quarter-end) starting Month 6 (2027-04-12)
- Revalidate model quarterly; adjust parameters if actual rates diverge >20% from forecast

**Approval Authorities**: CER, at least 8 major carriers (binding written letters of intent), Programme Director, DG MOVE Commissioner

**Essential Information**:

- Specify the carrier-funded mutual guarantee pool structure: per-incident cap (EUR 500–1,000 per stranded passenger, proposed threshold), co-insurance trigger (EUR 50M annual draw, proposed threshold), and contribution-weighting formula tied to trailing 12-month on-time performance.
- Quantify baseline missed-connection frequencies, rerouting costs and incident clustering from 24-month historical data from at least 5 major carriers (SNCF, DB, SBB, Renfe, ÖBB, one smaller operator).
- Model three sensitivity scenarios (conservative, base, aggressive) for cap levels and co-insurance triggers using Monte Carlo simulation for loss clustering, with confidence intervals at p50, p75 and p95.
- Develop worked examples showing pool contributions and drawdown profiles for three carrier profiles: large (>10% network share), regional (2–10%) and small (<2%), demonstrating predictability of exposure.
- Establish quarterly pool-monitoring procedures: defined incident-rate reporting, contribution-adjustment triggers, reserve-drawdown approvals and publication timelines (within 15 business days of quarter-end).
- Specify the decision rule for reserve exhaustion and escalation: what happens if actual incident rates exceed forecast by >20% in a quarter; trigger for public reinsurance or cap adjustment.
- Calculate the reserve adequacy for the carrier-funded pool under force-majeure scenarios (single-day corridor-wide disruption affecting >5,000 passengers) and identify the ceiling beyond which public top-up occurs.
- Define the liability recourse mechanism: how the pool recovers costs from a carrier whose delay caused a missed connection; specify the API, data requirements and dispute-resolution timeline.
- Produce a binding liability-terms summary (2–3 pages) that carriers will sign off to expose inventory; include risk allocation, contribution calculation, payout rules and quarterly review cycle.

**Risks of Poor Quality**:

- Vague or asymmetric caps and co-insurance rules leave carriers unable to price their participation, triggering 30–40% carrier refusal and fragmenting the through-ticket network by Month 6 (2027-04-12).
- Actuarial model based on <24 months of data or fewer than 5 major carriers understates loss clustering risk; actual pool drawdowns exceed forecast by 50–100% in year 2–3, exhausting the EUR 150M force-majeure reserve by Month 36 (2029-10-12).
- Poorly defined quarterly monitoring procedures leave incident rates and contributions opaque; carriers dispute share calculations, delaying payouts by 30–60 days and reducing distributor confidence in the pool's creditworthiness.
- Absence of a clear recourse mechanism allows a chronically late-running carrier to avoid contribution increases, subsidising pool payouts across all participants and creating unfair incentives.
- Sensitivity analysis limited to point estimates (no confidence intervals) gives false certainty; actual volatility emerges at Month 30 (2029-04-12) when the pool is live, forcing emergency redesign and 6–12 month rework.
- Missing escalation rules for reserve exhaustion leave the Commission unable to decide whether to top up the pool or trigger cap adjustments; policy deadlock delaying compensation payouts by months.

**Worst Case Scenario**: The actuarial study underestimates incident-clustering risk by relying on 12 months of data instead of 24, or excludes smaller carriers' higher disruption rates from the sample. At Month 30 (2029-04-12), when the pool goes live, actual missed-connection rates are 50–100% higher than forecast. Pool drawdowns climb to EUR 80–120M in the first 12 months (Months 30–42 = 2029-04-12 to 2030-04-12), rapidly exhausting the EUR 150M force-majeure reserve. By Month 42 (2030-04-12), the Commission faces a choice: top up the pool from remaining EUR 1,500M budget, which starves later-wave TEN-T corridor funding, or cut carrier caps by 40–50%, which triggers new disputes and carrier demands for contract renegotiation. Carriers who signed based on the flawed model sue for release from through-ticket obligations. The programme's credibility collapses, reducing participation from 25+ to ~12 carriers. The 40% through-ticket goal falls to 10–15%, and the four-corridor go-live slips from Month 48 (2030-10-12) to Month 60 (2031-10-12). The programme is seen as fundamentally broken.

**Best Case Scenario**: An independent actuarial firm completes a rigorous 24-month historical-data analysis of all major carriers plus two smaller operators by Month 3 (2027-01-12), with Monte Carlo modelling revealing realistic loss-clustering patterns and per-carrier risk profiles. The draft liability model specifies symmetric caps (EUR 750 per passenger, proposed threshold) and a co-insurance threshold (EUR 50M annual draw, proposed threshold) that carriers can price into inventory decisions. At least 8 major carriers and CER sign binding letters of intent by Month 4 (2027-02-12), confirming they will expose inventory if the model holds. Quarterly monitoring procedures are clear: incident rates published within 15 days, contributions adjusted quarterly based on trailing performance, and the reserve remains untouched through Month 48 (2030-10-12). This enables the Programme Director to take the liability decision to the steering group on schedule at Month 6 (2027-04-12), unblocking the binding-standards milestone. Carrier confidence in the pool's fairness drives 25+ participants to expose seats by Month 30 (2029-04-12). The four-corridor through-ticket network reaches 35–40% penetration by Month 48 (2030-10-12), meeting the headline target.

**Fallback Alternative Approaches**:

- If the independent actuarial study cannot be completed by Month 3 (2027-01-12) due to data availability or firm capacity constraints, commission a rapid Monte Carlo analysis using synthetic loss distributions calibrated to the 2019–2023 UNIFE rail incident database and regulator-published delay statistics by Month 2.5 (2026-12-27); use a conservative upper-percentile (p95) estimate for the cap and co-insurance trigger, accepting higher cost to ensure buffer headroom.
- If fewer than 5 major carriers provide 24-month granular incident data, establish a data-sharing agreement with national regulators who hold historical disruption logs; use cross-operator aggregates to derive loss-clustering parameters, deferring carrier-specific risk profiles to the quarterly monitoring phase.
- If carrier sign-off deadlocks at Month 4 (2027-02-12) due to divergent risk appetites (some carriers want lower caps, others higher), publish three binding liability variants in the standards (conservative, base, aggressive) and let each carrier choose its tier at Month 6 (2027-04-12); charge premium contributions for low-cap tiers and require higher-cap carriers to contribute more, so the pool remains balanced by choice.
- If disputes over the recourse mechanism emerge (e.g., how to assign causality for a delay), establish a three-tier dispute-resolution path: (1) automated reconciliation if incident data is clear; (2) bilateral mediation between carriers within 10 business days; (3) binding arbitration by an independent transport industry arbiter, with costs split between disputing carriers, reducing the need for pre-agreed rules and allowing iterative case law to develop.
- If the force-majeure reserve proves insufficient by Month 36 (2029-10-12), trigger an immediate policy review: establish a EUR 50–100M supplementary grant from the European Union Cohesion or Recovery budgets (if available) as a one-time top-up, conditional on carriers accepting a 5–10% contribution increase in the following year and committing to resilience investments (e.g., redundant links, faster crew repositioning).

## Create Document 3: Inter-Carrier Clearing and Settlement Rulebook (Federated Netting Architecture)

**ID**: ddb801e9-c11f-4ed8-8d22-311cd3e64a08

**Description**: Definitive specification of the federated clearing layer: multilateral netting model (bilateral, multilateral, or hybrid per corridor), settlement currency (EUR), reconciliation cycle (5 business days), journal entry standard (ISO 20022 XML mapping), dispute escalation procedure, penalty regime and payout schedule. Includes worked examples of three-leg through-tickets showing revenue allocation and carrier payouts. Resolves critical ambiguities: who receives the passenger payment, how positions are netted per leg and per distributor, and how disputes over carrier share are arbitrated. Primary audience: carriers' finance teams, clearing specialist, competition-law counsel, DG COMP.

**Responsible Role Type**: Clearing and Settlement Systems Architect

**Primary Template**: Banking/payment system settlement specification (ISO 20022 messaging standard)

**Secondary Template**: Rail Settlement Plan (RSP) clearing rulebook (GB precedent, adapted for EU federated model)

**Steps to Create**:

- Establish dedicated Clearing Design Workstream by Month 1 (2026-11-12) reporting to steering group
- Define netting model (bilateral, multilateral, or hybrid) and prepare position papers on trade-offs (control vs. complexity, bilateral familiarity vs. multilateral efficiency) by Month 2 (2026-12-12)
- Specify settlement data format (ISO 20022 XML) with full journal entry mapping, per-transaction fields and required metadata by Month 3 (2027-01-12)
- Model worked examples (Paris-Amsterdam-Berlin, Wien-München-Zürich, Madrid-Barcelona-Lyon three-leg itineraries) showing commission splits, refund reversals and carrier payouts by Month 4 (2027-02-12)
- Workshop with carriers' finance leads and the clearing architect to validate netting logic and payout timing by Month 5 (2027-03-12)
- Publish final Rulebook with all appendices (reconciliation tolerance bands, dispute escalation, penalty schedule, payout SLAs) by Month 6 (2027-04-12)
- Submit to DG COMP as part of binding standards by Month 18 (2028-04-12); obtain Agency approval by Month 12 (2027-10-12)

**Approval Authorities**: Clearing Design Workstream (carriers + Programme Office), Programme Director, EU Agency for Railways, DG COMP (for competition-law review)

**Essential Information**:

- Definitive specification of the federated multilateral netting model: clarify whether netting is bilateral per carrier pair, multilateral across all legs, or hybrid per corridor, with explicit trade-off analysis (control vs. complexity, existing bilateral familiarity vs. efficiency gains).
- Settlement currency (EUR confirmed), reconciliation cycle (5 business days target), and journal entry standard (ISO 20022 XML mapping with full field list and required metadata per transaction).
- Revenue allocation formula: specify how a single through-ticket payment is split among carriers per leg, how commissions are deducted, and how refunds are reversed across carriers in real time.
- Worked examples of three actual priority-corridor itineraries (Paris–Amsterdam–Berlin, Wien–München–Zürich, Madrid–Barcelona–Lyon) showing step-by-step netting, payout timing and commission handling for a full round-trip through-ticket with a missed connection and subsequent reroute.
- Dispute escalation procedure: define thresholds for automatic reconciliation (tolerance bands, error types), manual review triggers, carrier-to-carrier arbitration process, and escalation to the clearing entity or regulator.
- Penalty regime: specify financial consequences and tranche hold-backs for carriers exceeding reconciliation error thresholds (proposed: >1% monthly error rate loses 5% of next funding tranche), settlement delays (>5 business days) and data-format non-compliance.
- Payout schedule: confirm settlement windows (T+5 business days proposed), exceptions for refunds or disputed amounts, and payment-service-provider integration requirements.
- Reconciliation tolerance bands: quantify acceptable variance per transaction type (seat sales, refunds, commission corrections, cancellations) and aggregate monthly thresholds before escalation.
- Competition-law risk statement: confirm that the netting model and data flows comply with Article 101 TFEU as advised by DG COMP, with reference to the clean-team protocol and segregation of commercially sensitive data.
- Governance and change control: specify who approves changes to the rulebook post-binding standards (the Agency with carrier consensus, or the clearing entity unilaterally), and how emergency operational adjustments are handled.

**Risks of Poor Quality**:

- Ambiguous netting model leaves carriers unable to forecast their payouts from multi-leg through-tickets, causing refusal to expose inventory and blocking the mandatory API exposure milestone (Month 30 = 2029-04-12).
- Inconsistent ISO 20022 field mapping or missing required metadata causes reconciliation mismatches of 2–5% (estimate), extending settlement cycles from 5 to 10–15 business days and deterring distributor participation by 15–20% (estimate).
- Unclear dispute escalation thresholds and penalties result in carriers and distributors contesting every stale-seat or refund reversal, overwhelming dispute-resolution capacity and delaying payouts by 2–4 weeks (estimate), which triggers cash-flow complaints and reduces through-ticket volume.
- Vague revenue allocation formula invites carrier disputes over fair share; without worked examples, 3–4 major carriers challenge the rulebook post-launch, requiring Month 24–30 (2028-10-12 to 2029-04-12) rework and a 3–6 month delay in full-corridor go-live.
- Missing payout schedule or payment-service-provider integration requirements delay payouts to distributors and carriers, creating operational friction and reducing confidence in the clearing layer by 20–30% (estimate).
- Failure to address competition-law compliance explicitly leaves the rulebook legally vulnerable to Article 101 TFEU challenge post-adoption (Month 24–36 = 2028-10-12 to 2029-10-12), forcing 3–12 month rework (estimated cost EUR 50–100M) and restructuring of data flows.
- Unclear change-control governance allows unilateral clearing-entity modifications to netting or penalty rules without carrier consent, eroding trust and triggering legal disputes or partial carrier withdrawal.
- Absence of force-majeure provisions (e.g., how to handle a single-day corridor-wide disruption affecting 10,000+ passengers) leaves the pool exposed to unpredictable drains and forces emergency public funding (up to EUR 50–100M estimate) not budgeted as operational cost.

**Worst Case Scenario**: If the rulebook is incomplete, legally opaque or operationally ambiguous at binding-standards approval (Month 18 = 2028-04-12), carriers will not commit real-time inventory to the federated clearing layer. This triggers either full network non-participation (5–10 major carriers refuse to expose seats, reducing coverage to isolated regional routes) or a 6–12 month post-binding rework, cascading the mandatory API exposure milestone from Month 30 (2029-04-12) to Month 36–42 (2029-10-12 to 2030-04-12). Estimated outcome: the 40% through-ticket goal is unachievable; realistic through-ticket share falls to 15–25% (estimate), confined to 4–6 priority corridors instead of the full TEN-T network by Month 60 (2031-10-12). The programme loses EUR 200–400M of budget value and faces political pressure to extend the completion deadline to Month 72–84 (2032-10-12 to 2033-10-12), undermining the five-year delivery promise.

**Best Case Scenario**: A complete, legally vetted rulebook approved by DG COMP and signed by all steering-group carriers by Month 6 (2027-04-12) enables carriers to price their through-ticket exposure, commit inventory and finance their API adapters with confidence. Clear netting logic and worked examples allow independent distributors to integrate with the clearing layer without legal or operational uncertainty. Reconciliation standards set to <0.5% error and 5-business-day settlement create payout predictability that attracts both large and small distributors to the platform. By Month 30 (2029-04-12), all Tier 1 carriers (15–18 operators) expose live inventory; by Month 48 (2030-10-12), the four priority corridors deliver through-ticketing at 35–45% share (estimate), and the platform becomes self-reinforcing as more distributors invest in search and booking features. The programme demonstrates proof of concept on the priority corridors and achieves the full 40% through-ticket target across TEN-T by Month 60 (2031-10-12).

**Fallback Alternative Approaches**:

- If consensus on a single multilateral netting model is not reached by Month 3 (2027-01-12), publish two parallel rulebooks: one for bilateral settlement (carriers pair-wise, clearing entity nets positions daily) and one for multilateral (all legs together). Allow carriers to choose their preferred method and corridor; start Tier 1 deployment with bilateral (simpler, faster) and migrate to multilateral after Month 42 (2030-04-12) once operational confidence is established.
- If ISO 20022 full-field mapping cannot be specified by Month 4 (2027-02-12) due to carrier IT system constraints, adopt a phased standard: Month 18 (2028-04-12) binding includes a minimal subset of mandatory fields (transaction ID, carrier, leg, fare, commission, refund flag), and a 'OSDM XML+CSV fallback' for legacy systems that cannot produce full ISO 20022. Commit to full convergence by Month 36 (2029-10-12).
- If worked examples for all three corridors cannot be completed by Month 5 (2027-03-12) due to carrier data constraints, publish one detailed end-to-end example (e.g., Paris–Amsterdam–Berlin) with step-by-step reconciliation, and defer the other two to Month 6 (2027-04-12) as annexes. Conduct a live pilot walkthrough with 10–20 transactions per corridor at Months 12–18 (2027-10-12 to 2028-04-12) to validate the logic operationally before binding.
- If DG COMP competition-law clearance is not confirmed by Month 12 (2027-10-12), implement a clean-team protocol: the clearing entity operates behind a data firewall and releases only aggregated netting results (per-carrier payout, total throughput) to participants, not individual transaction flows. This reduces competition-law exposure and allows binding standards to proceed; detailed transaction data remains confidential within the clearing entity.
- If carrier consensus on penalty thresholds (error rates, settlement delays) is not reached by Month 5 (2027-03-12), establish a 'learning curve' period: Months 30–36 (2029-04-12 to 2029-10-12) are operated with no penalties, only performance reporting. Activate penalty regime from Month 36 (2029-10-12) onwards once carriers have proven compliance capabilities and settled operational bugs.

## Create Document 4: OSDM Binding Standards Specification (Federated Through-Ticketing Profile)

**ID**: 23f8ef58-1a31-4d53-93d7-8f0cb4b772e6

**Description**: Canonical OSDM version pinned by delegated act specifying all APIs, data structures and conformance rules required for federated through-ticketing across the four priority corridors. Includes profiles for availability query, booking, ticketing, refunds, accessibility metadata (wheelchair, assistance, bicycle spaces), multilingual support (≥18 EU languages), settlement data submission, ticket validation (barcode/credential format) and disruption event notification. Incorporates competition-law and GDPR constraints identified in binding standards workstream. Primary audience: carriers' CIOs, distributors, conformance testers, EU institutions.

**Responsible Role Type**: Standards & Technical Specification Custodian (at the EU Agency for Railways)

**Primary Template**: UIC OSDM Specification (reference implementation, versioned)

**Secondary Template**: W3C/OASIS API specification template (OpenAPI 3.0 or similar)

**Steps to Create**:

- Commission standards writing group by Month 1 (2026-11-12) comprising OSDM community, 3-4 major carriers, 2 distributors and Agency technical staff; meet biweekly
- Consolidate binding standards requirements from all five critical decisions (liability, clearing, public distributor, funding ladder, availability topology) into one specification by Month 9 (2027-07-12)
- Publish option papers on critical API design points (federated vs. central inventory, netting engine format, refund reversal semantics) by Month 6 (2027-04-12); hold written consultation among carriers by Month 9 (2027-07-12)
- Draft OSDM binding-standards profile incorporating: availability query (federated, with shadow caching), booking (carrier authority), settlement data submission (ISO 20022), ticket validation (credential format), accessibility metadata, multilingual payloads, disruption events and refund reversal; include conformance test suite by Month 15 (2028-01-12)
- Obtain DG COMP clearance and competition-law counsel review by Month 12 (2027-10-12); incorporate any required clean-team protocols or data-minimisation constraints by Month 14 (2027-12-12)
- Finalise binding-standards text and submit to Commission for delegated-act drafting by Month 18 (2028-04-12); target publication in Official Journal by Month 20 (2028-06-12)

**Approval Authorities**: EU Agency for Railways (Standards Custodian), DG MOVE, DG COMP, European Commission (delegated act), CER (stakeholder consultation)

**Essential Information**:

- Specify the complete OSDM API surface required for federated through-ticketing: availability query (federated endpoints with shadow caching), booking (carrier authority), settlement data submission (ISO 20022 format or equivalent), ticket validation (barcode/credential format), accessibility metadata (wheelchair spaces, assistance notice periods, bicycle capacity), and disruption event notification.
- Define the conformance test suite: test cases for latency (<2 seconds p95 per query), availability (≥99.5%), stale-seat error rates (<1%), multilingual payload support (≥18 EU languages), settlement data format validation, accessibility metadata completeness, and ticket validation handshake interoperability.
- Incorporate all binding-standards requirements from the five critical decisions: liability backstop data fields (incident reporting, reroute cost attribution), clearing settlement message formats (federated netting, EUR-denominated, 5-business-day cycle), public distributor interface (query and booking API), funding-ladder verification fields (API availability attestation, booking-error rates per carrier).
- Detail the competition-law and data-protection constraints: identify which data flows require clean-team separation, which payloads must be aggregated or anonymised per GDPR, and which API designs minimise commercially sensitive information exposure (e.g., federated inventory vs. centralised exchange implications for Article 101 TFEU).
- Establish the versioning and change-control process: publication timeline (target Official Journal Month 20 = 2028-06-12), version numbering, deprecation policy for legacy API versions, and escalation rules for competition-law or passenger-rights changes post-binding.
- Quantify the technical scope: count the APIs (availability, booking, refund, settlement, disruption, validation, accessibility), payloads per API, multilingual variations, test cases per API (estimate: 50–100 test cases per major API), and integration effort per carrier tier (Tier 1: 600–800 person-days, Tier 2: 800–1,200, Tier 3: 1,200–1,800, estimate).

**Risks of Poor Quality**:

- Ambiguous or incomplete API definitions leave carriers unable to implement compliant systems by Month 30 (2029-04-12) mandatory exposure; 8–15 smaller operators miss the deadline by 6–12 months, fragmenting corridor coverage and reducing through-ticket volume by 20–30% (estimate).
- Absent or weak competition-law constraints (e.g., no data-minimisation rules for shared inventory or clearing) trigger a DG COMP challenge post-Month 18 (2028-04-12), forcing EUR 50–100M rework and 6–12 month redesign delay (estimate), and potentially unwinding carrier investments.
- Incomplete accessibility metadata definitions (e.g., no standard for wheelchair-space representation across carriers) prevent atomic booking confirmation; itineraries without spaces are refused, lowering through-ticket availability by 10–15% (estimate) and creating legal exposure under EU Regulation 1371/2007 and the Accessibility Directive.
- Missing or unclear settlement data formats (e.g., no standard for refund-reversal messaging) cause reconciliation errors >2%, lengthening settlement cycles from 5 to 10–15 business days; 15–20% of distributors withdraw due to cash-flow friction, reducing through-ticket volume by 10–15% (estimate).
- Failure to specify the federated vs. central inventory architecture clearly allows carriers and distributors to interpret the standard differently; this leads to incompatible implementations and multi-quarter rework by Month 30–36 (2029-04-12 to 2029-10-12).
- Absent test-suite rigor (e.g., no latency or availability test cases) permits carriers to claim conformance while delivering systems that fail in production; through-ticket success rates drop from 90% to 70–80% (estimate), eroding the commercial value proposition.

**Worst Case Scenario**: A binding-standards specification that is incomplete, ambiguous on critical APIs (availability, booking, settlement), or silent on competition-law and accessibility constraints could result in: (1) 40–50% (estimate) of smaller carriers unable to implement by Month 30 (2029-04-12), forcing the mandatory API exposure milestone to slip to Month 36–42 (2029-10-12 to 2030-04-12) and reducing participating carriers from 25 to ~15; (2) A DG COMP Article 101 TFEU challenge within 6–12 months of publication, triggered by data-sharing or inventory-pooling provisions not approved in advance, forcing EUR 50–100M rework and unravelling carrier commitments; (3) Accessibility metadata gaps preventing atomic booking of assistance and wheelchair spaces, creating legal exposure under Regulation 1371/2007 and triggering regulator enforcement actions; (4) Settlement data format inconsistency causing >2% reconciliation errors, extending the clearing cycle to 10–15 business days and causing 15–20% of distributors to withdraw, reducing the through-ticket share from 40% to 15–25% (estimate) and likely programme failure to meet the binding target by Month 60 (2031-10-12). Combined impact: delivery delay of 12–24 months and unachievable goals, consuming most of the EUR 1,500M budget on rework instead of rolling out value.

**Best Case Scenario**: A complete, unambiguous OSDM binding-standards specification published by Month 20 (2028-06-12) enables: (1) All 25+ carriers and distributors to implement conformant systems on predictable timelines (Tier 1 by Month 30 = 2029-04-12, Tier 2 by Month 36 = 2029-10-12, Tier 3 by Month 42 = 2030-04-12); (2) A rigorous conformance test suite reducing post-go-live integration failures and allowing carriers to validate readiness 4–6 months before mandatory exposure; (3) Pre-cleared Article 101 TFEU compliance (via clean-team protocols and data-minimisation rules) documented in the specification, eliminating post-launch legal challenges and carriers' hesitation to commit inventory; (4) Atomic booking confirmation of accessibility (wheelchair, assistance, bicycle) and settlement fields, enabling the accessibility targets (80% wheelchair access, 90% assistance within 4 hours) and reducing reconciliation errors to <0.5% by Month 30 (2029-04-12); (5) Successful pilots of 2,000–4,000 passengers per corridor (Months 12–18 = 2027-10-12 to 2028-04-12) validating the architecture and building carrier and distributor confidence, resulting in early over-commitment of inventory and 40%+ through-ticket share achieved by Month 54 (2031-04-12) instead of Month 60 (2031-10-12).

**Fallback Alternative Approaches**:

- If binding-standards drafting slips beyond Month 15 (2028-01-12): Publish an interim 'Fast-Track OSDM Profile' (Month 12 = 2027-10-12) covering only the critical path APIs (availability, booking, settlement, ticket validation) with simplified multilingual support (6–8 core languages) and deferred accessibility and disruption APIs; use the Fast-Track to unblock pilot deployment and carrier integration Months 12–18 (2027-10-12 to 2028-04-12), then merge into the full binding standards by Month 18 (2028-04-12).
- If competition-law clearance from DG COMP is unavailable by Month 12 (2027-10-12): Adopt a maximum-separation design by Month 14 (2027-12-12) where the specification mandates clean-team arrangements for the clearing function, minimises shared inventory visibility, and requires all netting data to be aggregated per carrier pair; submit this design for expedited DG COMP guidance by Month 14 (2027-12-12), accepting a 4–6 week review cycle and targeting Month 16 (2028-02-12) approval before binding standards finalise.
- If carrier survey by Month 3 (2027-01-12) reveals that some carriers cannot implement accessibility metadata by Month 30 (2029-04-12): Adopt a phased accessibility commitment where Tier 1 carriers expose wheelchair and assistance metadata by Month 30 (2029-04-12), and Tier 2/3 carriers provide 'best-effort' (non-atomic) accessibility data by Month 36–42 (2029-10-12 to 2030-04-12), with atomic booking deferred to Month 48 (2030-10-12) for full network; use the Phase 1 pilots to identify carriers' capability gaps by Month 18 (2028-04-12) and adjust tier assignments.
- If settlement data-format standardisation (ISO 20022 or equivalent) is not approved by CER and carriers by Month 9 (2027-07-12): Establish an interim 'Common Settlement Gateway' (part of the clearing budget, EUR 20–40M estimate) that accepts each carrier's native settlement format, auto-translates to a canonical EUR-denominated format within the gateway, and handles reconciliation internally; this preserves compliance timelines at the cost of gateway complexity and operational risk (single point of failure) until carriers migrate to the standard by Month 42–48 (2030-04-12 to 2030-10-12).
- If the full specification exceeds 500+ pages and becomes difficult for carriers' technical teams to implement uniformly: Decompose the binding standard into three modular profiles (Alpha: Availability & Booking, Beta: Settlement & Validation, Gamma: Accessibility & Disruption) published in sequence (Alpha Month 18 = 2028-04-12, Beta Month 20 = 2028-06-12, Gamma Month 21 = 2028-07-12); carriers implement Alpha first and commit to Beta/Gamma integration by Month 36–42 (2029-10-12 to 2030-04-12), reducing per-carrier on-boarding burden and allowing earlier go-live of basic through-ticketing.

## Create Document 5: Technical Audit and Carrier Conformance Tier Assignment Report

**ID**: 35471efb-e283-4507-bde2-7a6b06fc740f

**Description**: Independent assessment of all 25+ participating carriers' booking-system readiness against binding standards, published with tier assignments (Tier 1: Month 30 = 2029-04-12; Tier 2: Month 36 = 2029-10-12; Tier 3: Month 42 = 2030-04-12) and per-carrier integration roadmaps. Covers API build effort, event-streaming capability, latency (p95 seconds current state), availability (12-month %), legacy-system dependencies, staffing availability and estimated adapter cost per operator. Identifies bottlenecks (mainframe retrofit, payment-processor integration) and recommends shared-adapter modules. Output: basis for adapter funding allocation and conformance milestones. Primary audience: carriers, Programme Office, finance lead.

**Responsible Role Type**: Carrier Integration & Technical Onboarding Manager

**Primary Template**: Technical due diligence assessment template (system architecture audit)

**Secondary Template**: Capacity and constraint analysis (IT resource planning template)

**Steps to Create**:

- Tender independent audit firm by Month 0.5 (2026-10-27); award by Month 1 (2026-11-12)
- Send audit questionnaire to all 25+ carriers by Month 1 (2026-11-12) covering: current API state, event-streaming capability, latency profiles, annual uptime %, legacy system details, staff FTE available
- Conduct on-site system assessments (30+ days across four EU hubs) Months 1-2 (2026-11-12 to 2026-12-12); validate questionnaire responses
- Analyse integration effort per carrier using established patterns (mainframe retrofit typically 9-15 months for smaller operators, 6-9 months for modern systems) by Month 2 (2026-12-12)
- Publish draft tier assignments and per-carrier roadmaps by Month 3 (2027-01-12); circulate for carrier comment by Month 4 (2027-02-12)
- Finalise tier assignment (Tier 1 = 12+ carriers with <12 months integration remaining; Tier 2 = 6-10 carriers with 12-18 months; Tier 3 = remaining) by Month 6 (2027-04-12)
- Publish final audit report with all roadmaps, bottleneck assessments and shared-adapter recommendations; submit to steering group and Programme Director

**Approval Authorities**: Audit firm (technical opinion), Carrier Integration Manager, Programme Director, steering group (acceptance of tier assignments)

**Essential Information**:

- Assess the current API readiness, event-streaming capability and on-time latency (p95 seconds, current state) for all 25+ participating carriers' booking systems.
- Evaluate existing annual system availability (12-month %), legacy-system dependencies and integration dependencies (mainframe retrofit, payment-processor integration).
- Quantify integration effort per carrier in months, using established patterns (mainframe retrofit: 9–15 months for smaller operators, 6–9 months for modern systems).
- Identify staffing availability (FTE) per carrier dedicated to conformance integration during Months 1–30 (2026-11-12 to 2029-04-12).
- Estimate adapter cost per operator and identify shared-adapter module opportunities (e.g. mainframe-to-OSDM bridges, payment-processor connectors) that can be funded centrally.
- Assign all 25+ carriers to conformance tiers: Tier 1 (Month 30 = 2029-04-12), Tier 2 (Month 36 = 2029-10-12), Tier 3 (Month 42 = 2030-04-12), with clear, per-carrier roadmaps showing milestones, dependencies and risk flags.
- List bottleneck carrier pairs (e.g. carriers whose integration is blocked by another's API readiness on a shared corridor) and propose sequencing to unblock critical paths.
- Provide tier-wise funding allocation recommendations: EUR 30M shared adapters, EUR 80M Tier 1, EUR 80M Tier 2, EUR 50M Tier 3, with payment triggers tied to SLA milestones (latency, availability, error rates).
- Detail the audit methodology, sample size of on-site visits (30+ days across four EU hubs), questionnaire design, validation approach and confidence intervals per carrier tier.

**Risks of Poor Quality**:

- Underestimated integration effort on smaller carriers (e.g. mainframe retrofit overstated as 6 months instead of 12–15 months) causes 40–50% of Tier 2 and Tier 3 carriers to miss their assigned milestones, fragmenting corridor coverage and pushing full mandatory API exposure from Month 30 (2029-04-12) to Month 36–42 (2029-10-12 to 2030-04-12), delaying four-corridor go-live by 6–12 months.
- Failure to identify shared-adapter bottlenecks (e.g. mainframe or payment-processor integration needed by 8+ carriers) leaves EUR 80–150M in central adapter funding unallocated and forces carriers to self-fund, creating unequal participation and budget waste.
- Incomplete on-site validation of questionnaire responses allows carriers to understate legacy-system complexity, leading to unrealistic roadmaps that collapse 12–18 months later when retrofits prove harder than stated, eroding steering confidence and triggering cascade delays.
- Missing carrier interdependencies on shared corridors (e.g. Carrier A's booking-engine latency gates Carrier B's through-ticket availability) leaves integration sequencing undefined, allowing serial delays to cascade rather than being planned as concurrent workstreams.
- Inaccurate staffing availability forecasts result in carriers lacking FTE when conformance testing begins at Month 12 (2027-10-12), causing 4–8 month slippage in API readiness and cost inflation as carriers hire contractors at premium rates.
- Weak or absent confidence intervals per tier allow steering group to treat assignments as absolute, then challenge tier placement once integration starts, re-allocating funding mid-programme and destabilising the tranched release schedule.
- Omission of validation gateway details (which SLAs must be met before each tier advances to the next milestone) leaves the funding release mechanism toothless: carriers have no clear incentive to hit latency/availability targets because payment is not conditional.

**Worst Case Scenario**: 
The audit is incomplete, on-site visits are superficial or omitted, and tier assignments rely on carrier self-reported questionnaire data without independent validation. Tier 2 and Tier 3 carriers (6–15 operators, 35–45% of network) are optimistically placed at Months 36 and 42 (2029-10-12 and 2030-04-12) but discover during Month 24–30 (2028-10-12 to 2029-04-12) that mainframe retrofits, legacy payment-processor integrations or understaffed IT teams require 18–24 months, not 12–15. Shared-adapter modules are not identified, leaving each carrier to fund its own bridge solution. By Month 36 (2029-10-12), only 10–12 of the 25+ target carriers are API-live, not the 18–20 forecast for Tier 1 and early Tier 2. Critical corridors (e.g. Wien–München–Zürich) are fragmented because a regional operator missed the milestone. The Programme Office burns EUR 150–200M in emergency adapter acceleration funding, exceeding the original EUR 240M allocation by 60–80% (estimate). Four-corridor through-ticketing slips from Month 48 (2030-10-12) to Month 60–66 (2031-10-12 to 2032-04-12). Through-ticket share at Month 60 (2031-10-12) is 15–20% instead of 40% (estimate). Steering group loses confidence in the programme schedule, and smaller member states and carriers withdraw or demand re-negotiation of obligations, triggering a political backlash and potential programme cancellation or major restructuring by Month 48 (2030-10-12).

**Best Case Scenario**: 
The audit is conducted by a credible, independent firm with on-site assessments of all 25+ carriers across four EU hubs (30+ days, Month 1–2 = 2026-11-12 to 2026-12-12), questionnaire responses are independently validated, and per-carrier roadmaps with clear milestones, risk flags and dependency maps are published by Month 6 (2027-04-12). Shared-adapter modules (mainframe bridges, payment-processor connectors, event-stream SDKs) serving 8–12 carriers are identified, and the Programme Office allocates EUR 30M for development by Month 12 (2027-10-12). Tier assignments are credible and include 90%-confidence intervals on integration timelines per carrier. Carriers can reliably plan internal team allocation and external contracting. The steering group and the Carrier Integration Manager accept the tier assignments and funding tranches. By Month 30 (2029-04-12), 15–18 large and corridor-critical carriers (Tier 1) go live, meeting SLA targets. By Month 42 (2030-04-12), 22–24 of the 25+ target carriers are API-live. Four-corridor through-ticketing launches on schedule at Month 48 (2030-10-12). The 40% through-ticket goal is achievable within the EUR 1,500M budget, and TEN-T extension (Months 48–60 = 2030-10-12 to 2031-10-12) proceeds as planned. Programme credibility and carrier buy-in remain high, and the regulatory and competition-law pathway is unblocked.

**Fallback Alternative Approaches**:

- If a full independent audit is not feasible within Month 2 (2026-12-12), commission a rapid (4-week) diagnostic assessment of the 10 largest carriers only, published by Month 3 (2027-01-12), while launching a self-audit questionnaire for smaller carriers due by Month 4 (2027-02-12), with spot-checks on 3–5 second-tier carriers by Month 6 (2027-04-12). Accept higher confidence-interval ranges (25–30% variance instead of 10–15%) and allow tier assignments to be provisional, with a formal re-audit gate at Month 12 (2027-10-12).
- If audit costs exceed budget (estimated EUR 2–3M), leverage existing regulatory audit data: request the EU Agency for Railways and national rail regulators to share technical compliance reports they hold on carrier systems, supplement with a focused questionnaire on integration timelines and shared-adapter needs, and hire one dedicated analyst to synthesise findings by Month 6 (2027-04-12).
- If on-site carrier visits are constrained by travel or local IT security policies, substitute remote technical deep-dives via video call and remote system-architecture walkthroughs (screen-sharing with live system demos) at Month 1–2 (2026-11-12 to 2026-12-12), supplemented by architecture-review workshops co-hosted by the Agency and CER in Brussels and Valenciennes at Month 3 (2027-01-12); accept that the audit will be less hands-on but faster to execute.
- If tier assignments are not accepted by the full steering group by Month 6 (2027-04-12), escalate disagreements to a bilateral mediation process: the Carrier Integration Manager and one independent arbiter (appointed by the Agency) meet individually with each carrier ranked in Tier 2 or 3 to resolve contentious assumptions (staffing FTE, legacy-system complexity) by Month 9 (2027-07-12), with binding mid-point scores if disagreement persists.
- If shared-adapter modules cannot be fully specified within the audit timeline, establish a 'best-guess' module list by Month 6 (2027-04-12) covering the most obvious shared needs (mainframe OSDM bridge, event-stream SDK, payment-processor adapter), allocate EUR 20–30M for development, and fund a separate technical workstream (Month 6–12 = 2027-04-12 to 2027-10-12) to validate the modules and identify additional ones, releasing remaining EUR 10M adaptively in Month 12 (2027-10-12).

## Create Document 6: Competition Law Pre-Notification Memorandum and Article 101 TFEU Safe-Harbour Argument

**ID**: b05e4a09-46f7-47ac-95f9-eacfcf158f44

**Description**: Comprehensive legal memorandum submitted to DG COMP (pre-notification under Regulation 1/2003) describing all aspects of the inter-carrier clearing mechanism, shared availability data layer, through-fare construction, distribution remuneration band and carrier-funded guarantee pool from an Article 101 TFEU perspective. Demonstrates non-discriminatory access, proportionality of restrictions and pro-competitive benefits (lower consumer fares, improved journey connectivity). Identifies required clean-team protocols, data-access controls and governance safeguards to satisfy competition-law scrutiny. Requests formal DG COMP guidance letter confirming compatibility or identifying required modifications. Primary audience: DG COMP, Programme Director, Competition Law Counsel, carriers.

**Responsible Role Type**: Competition Law & Regulatory Affairs Counsel

**Primary Template**: EU competition-law pre-notification memorandum (format per Regulation 1/2003)

**Secondary Template**: Article 101 TFEU exemption argument template (using established precedents in transport and digital markets)

**Steps to Create**:

- Engage external EU competition counsel by Month 1 (2026-11-12)
- Gather technical specifications from clearing architect, standards custodian and real-time engineer Months 1-2 (2026-11-12 to 2026-12-12) describing shared mechanisms in concrete detail (data flows, participant roles, access rules)
- Draft memorandum addressing: (1) notification of the clearing and data-sharing arrangements as potentially restrictive practices; (2) demonstration that each arrangement is necessary for through-ticketing and proportionate; (3) definition of non-discriminatory access criteria; (4) clean-team protocols isolating competitive strategy from clearing function; (5) public-authority oversight (Agency role) as safeguard by Month 2 (2026-12-12)
- Circulate draft to Programme Director and DG MOVE legal counsel for review by Month 2.5 (2026-12-27)
- File formal pre-notification with DG COMP covering letter and signed memorandum by Month 2 (2026-12-12) end of week
- Attend initial DG COMP briefing meeting (approximately Month 3-4 = 2027-01-12 to 2027-02-12) to respond to questions and flag urgent clarifications needed
- Obtain formal DG COMP guidance letter confirming safe-harbour or identifying required design changes by Month 9-10 (2027-07-12 to 2027-08-12)
- If guidance identifies concerns, revise memorandum and designs (clean-team protocol, governance safeguards) and resubmit by Month 12 (2027-10-12)
- Obtain final DG COMP approval of any clean-team protocols or safeguards by Month 14 (2027-12-12)

**Approval Authorities**: DG COMP (formal guidance letter), DG MOVE (substantive review), Programme Director (sign-off on safe-harbour argument)

**Essential Information**:

- Demonstrate that the inter-carrier clearing mechanism, shared real-time availability data layer, through-fare construction rules and distribution remuneration band are necessary and proportionate restrictions on competition under Article 101 TFEU, with pro-competitive benefits (lower fares, improved journey connectivity, passenger rights continuity).
- Specify all shared mechanisms in concrete technical detail: data flows, participant roles, access rules, and governance safeguards that prevent misuse for anti-competitive purposes.
- Define non-discriminatory access criteria for independent distributors and smaller carriers to the clearing layer, real-time data feeds and OSDM-compliant APIs, with enforcement and audit mechanisms.
- Detail clean-team protocols isolating the clearing function from participants' commercial strategies: information barriers, access controls, data aggregation and segregation of competitive information.
- Describe the role of the EU Agency for Railways as independent public-authority oversight body, with powers to audit clearing operations, enforce non-discrimination and report suspected violations to DG COMP.
- Cite established EU competition-law precedents in transport and digital markets (e.g. MasterCard, Clearstream, RailTeam) demonstrating that inter-carrier coordination can satisfy Article 101(3) TFEU exemption criteria when proportionate and subject to safeguards.
- Identify specific design choices (federated vs. central clearing, quota mechanisms, sunset clauses, dispute resolution) and explain how each reduces restriction on competition or enables pro-competitive benefits.
- Request formal guidance from DG COMP confirming compatibility of the clearing and data-sharing arrangements with Article 101 TFEU, or identifying required design modifications to secure safe-harbour status.
- Address potential DG COMP concerns (e.g. data pooling heightening collusion risk, exclusionary rules blocking smaller distributors, capacity caps that limit passenger benefit) and demonstrate mitigation through the safeguards outlined.

**Risks of Poor Quality**:

- Incomplete technical specification of the clearing and data-sharing mechanisms allows DG COMP to infer anti-competitive intent or unchecked potential for collusion, triggering a dawn raid or formal investigation that disrupts the programme for 12-24 months and imposes fines on participating carriers.
- Absence of credible non-discriminatory access rules or weak clean-team protocols invites a challenge that the mechanisms are designed to foreclose independent distributors or smaller carriers, forcing redesign of the clearing layer and 6-12 month delay.
- Vague or unsubstantiated claims about pro-competitive benefits without economic evidence (consumer surplus, journey availability) allows DG COMP to dismiss the Article 101(3) exemption argument, requiring the programme to operate without safe-harbour status, leaving carriers exposed to later enforcement action.
- Failure to address known DG COMP precedent concerns (e.g. information pooling in RailTeam investigations, capacity allocation in air-transport cases) creates a perception of legal naïveté, reducing credibility and increasing scrutiny intensity.
- Missing or inadequate description of the Agency's oversight role and audit powers allows DG COMP to conclude that the programme lacks meaningful external enforcement, failing the proportionality test.
- Legally deficient memorandum (weak reasoning, poor precedent analysis, inconsistent with Regulation 1/2003 formats) prolongs DG COMP review from the target Month 12 (2027-10-12) to Month 18-24 (2028-04-12 to 2028-10-12), compressing or deferring the binding-standards milestone.
- Absence of clear fallback or design-modification pathways leaves no negotiating room if DG COMP identifies concerns, forcing either programme retreat or unresolved legal exposure that deters carrier participation.

**Worst Case Scenario**: DG COMP initiates a formal investigation into the clearing and data-sharing arrangements under Article 101 TFEU on the grounds that the pre-notification memorandum is incomplete, legally unconvincing or fails to demonstrate pro-competitive benefits. A dawn raid and information request issued at Month 9-12 (2027-07-12 to 2027-10-12) paralyzes the Programme Office and participating carriers for 3-6 months. Carriers facing investigation uncertainty withdraw from inventory exposure, delaying mandatory API exposure from Month 30 (2029-04-12) to Month 42-48 (2030-04-12 to 2030-10-12) and reducing participation from 25+ to 12-15 operators (estimate). If the investigation concludes that the clearing mechanism violates Article 101 TFEU without an effective exemption, the programme is forced to restructure the clearing and data layer, requiring 6-12 months of redesign and resubmission, pushing the binding-standards milestone to Month 24-30 (2028-10-12 to 2029-04-12). This reduces the through-ticket share from 40% to 15-20% (estimate) and leaves EUR 200-300M of the public budget unallocated. Reputational damage to the programme and enforcement risk to carriers deters future EU infrastructure initiatives in digital rail services.

**Best Case Scenario**: DG COMP issues a formal guidance letter by Month 12 (2027-10-12) confirming that the inter-carrier clearing mechanism, shared real-time data layer, through-fare construction rules and distribution remuneration band are compatible with Article 101 TFEU, conditioned on the specified non-discriminatory access rules, clean-team protocols and Agency oversight. This enables carriers to commit binding inventory exposure and budget without legal hesitation. The binding-standards milestone is met on time at Month 18 (2028-04-12), mandatory API exposure milestone at Month 30 (2029-04-12), and the four priority corridors go live at Month 48 (2030-10-12) with full participation from 25+ operators. The safe-harbour status becomes a replicable model for future EU digital transport initiatives and removes legal risk from the programme's balance sheet, allowing the 40% through-ticket target and full TEN-T coverage by Month 60 (2031-10-12) without regulatory uncertainty.

**Fallback Alternative Approaches**:

- If DG COMP indicates concerns with data pooling or clearing governance during Month 3-4 (2027-01-12 to 2027-02-12) briefing, immediately engage an alternative clean-team design (separate legal entities, external audit board, third-party data custodian) and resubmit a revised memorandum by Month 8 (2027-06-12) before DG COMP's review window closes, avoiding full investigation escalation.
- If DG COMP raises exclusionary concerns about access rules, commit to a third-party dispute arbiter (designated by the Agency) to review distributor access claims and issue binding decisions within 30 days, demonstrating concrete non-discrimination enforcement independent of the Programme Office.
- Commission an independent economic-impact study (estimate: EUR 0.5-1M) by Month 3 (2027-01-12) quantifying consumer surplus, journey availability gains and modal-shift benefits of the programme, using established econometric methods; embed findings in a revised memorandum submitted Month 9 (2027-07-12) to strengthen the Article 101(3) exemption case.
- If uncertainty persists through Month 10 (2027-08-12), request a Phase 2 formal notice from DG COMP (Regulation 1/2003 Article 19) setting a 90-day reply deadline, converting the review to a structured formal process with defined gates and milestones that compresses uncertainty, even if it extends the guidance timeline to Month 14-15 (2027-12-12 to 2028-01-12).
- Establish a contingency non-compliant clearing pathway (federated bilateral netting with no shared data layer, longer settlement cycles) and document its inferior competitive outcomes; present this as a fallback if DG COMP rejects the centralised mechanism, demonstrating that the proposed design is the pro-competitive alternative to fragmentation.
- If legal certainty cannot be obtained by Month 14 (2027-12-12), launch the programme under Regulation 1/2003 Article 101(3) block exemption (rail transport services exemption, if applicable to digital services) or a Commission declaration of non-opposition, accepting residual legal risk but preserving momentum for the Month 18 (2028-04-12) binding-standards deadline.

## Create Document 7: Passenger Rights Compliance Manual and Regulation 1371/2007 Legal Opinion

**ID**: 66be3b09-2d41-481b-8d22-a529c38af236

**Description**: Comprehensive operational manual and legal opinion ensuring that through-ticket passengers retain rights equivalent to or superior to single-carrier passengers under EU Regulation 1371/2007 (railway passengers' rights). Covers assistance, rerouting, compensation, refunds, information provision, complaint handling and accessibility obligations for each participating entity (carriers, clearing layer, public distributor, independent distributors). Includes step-by-step procedures for handling missed connections, force-majeure claims, passenger assistance requests and disability accommodations. Based on independent legal review by rail-law specialist. Output: binding compliance requirement for all parties. Primary audience: carriers, distributors, the clearing entity, EU Agency for Railways, national regulators.

**Responsible Role Type**: Passenger Rights, Accessibility & Consumer Protection Lead

**Primary Template**: Legal opinion (from an EU rail-law specialist)

**Secondary Template**: Operations manual template (step-by-step procedures per role)

**Steps to Create**:

- Commission independent legal review (from a specialist in EU passenger-rights regulation) by Month 1 (2026-11-12)
- Provide reviewer with: binding standards drafts, liability model, clearing rulebook and public distributor specification (as they emerge Months 3-6 = 2027-01-12 to 2027-04-12) for gaps analysis against Regulation 1371/2007
- Reviewer publishes preliminary opinion on any gaps (compensation below single-carrier levels, refund delays not justified, accessibility not addressed) by Month 3 (2027-01-12); confirm by Month 6 (2027-04-12)
- If gaps are identified, revise liability model and clearing rulebook (Decisions 1, 2) by Month 9 (2027-07-12) to close them
- Develop compliance manual specifying: who (carrier, clearing entity, distributor) is responsible for each right (assistance, compensation, information) at each journey stage (booking, travel, disruption, refund) by Month 6 (2027-04-12)
- Publish worked examples of compliance scenarios (missed connection with compensation owed, passenger with mobility needs requesting assistance, refund reversal across carriers) by Month 9 (2027-07-12)
- Submit both legal opinion and manual to EU Agency for Railways for formal approval by Month 9 (2027-07-12); obtain written approval by Month 9 (2027-07-12)
- Publish manual as a binding operational requirement; require all carriers and distributors to certify staff training by Month 30 (2029-04-12)

**Approval Authorities**: Independent legal reviewer (legal opinion), EU Agency for Railways (compliance manual approval), carriers and distributors (acceptance and staff training certification)

**Essential Information**:

- Provide a comprehensive legal opinion from an EU rail-law specialist confirming that all through-ticket passenger rights (assistance, compensation, refunds, information, complaint handling) under EU Regulation 1371/2007 are preserved or exceeded in the programme's liability model, clearing rulebook and public distributor specification.
- Detail step-by-step operational procedures for each participating entity (carriers, clearing layer, public distributor, independent distributors) covering: missed-connection detection and rerouting, passenger assistance requests for persons with reduced mobility, compensation and refund claims, force-majeure handling, and information provision in at least the EU working languages.
- Identify specific gaps between the draft programme design (liability backstop, clearing settlement timings, distributor roles) and Regulation 1371/2007 requirements; recommend design changes to close each gap.
- Specify who bears responsibility (carrier, clearing entity, distributor) for each passenger right at each journey stage: booking, travel, disruption, rerouting, compensation and refund.
- Provide worked examples demonstrating compliance for at least five high-risk scenarios: (1) missed connection with compensation owed across carriers; (2) mobility-assistance request with short notice; (3) refund reversal when a passenger cancels a through-ticket; (4) force-majeure disruption affecting multiple legs; (5) complaint escalation across carriers.
- Establish training requirements and sign-off procedures for all carrier and distributor staff handling passenger claims, assistance and complaints; specify certification timelines for conformance gates.
- Document how the manual aligns with national variations in passenger-rights enforcement and complaint-handling procedures per member state; identify any national-level regulatory conflicts.
- Confirm that accessibility obligations under EU Regulation 1371/2007 and the Accessibility Directive are met by the Assistance and Bicycle Reservation Chaining design, particularly atomic confirmation and best-effort fallbacks.

**Risks of Poor Quality**:

- If the legal opinion finds material gaps between the programme design and Regulation 1371/2007 (e.g., compensation below single-carrier levels, settlement delays not justified, assistance commitments unfulfillable), redesign of the liability model and clearing rulebook is forced, delaying binding standards from Month 18 (2028-04-12) to Month 24–30 (2028-10-12 to 2029-04-12) and consuming EUR 10–20 million in rework.
- Unclear responsibility allocation between carriers, clearing entities and distributors leads to passengers being denied compensation or assistance because each party believes the other is liable; this triggers regulatory complaints to the EU Agency for Railways and national regulators, risking enforcement action and programme suspension.
- Incomplete or ambiguous operational procedures for missed-connection handling and refund reversal result in inconsistent passenger outcomes across carriers and member states; distributors face unpredictable liability exposure and withdraw from the programme, reducing through-ticket volume by 10–20% (estimate).
- Failure to obtain formal written approval from the EU Agency for Railways by Month 9 (2027-07-12) means carriers lack confidence that the programme's rights design meets regulatory standards; participation drops and mandatory API exposure milestone slips by 3–6 months.
- Incomplete accessibility guidance in the manual means onboard staff and station agents apply inconsistent standards for mobility assistance and bicycle reservations; passengers with disabilities file complaints, forcing ad-hoc remedies and damaging programme credibility.
- If staff training and certification requirements are not clearly specified and enforced, carriers and distributors deploy untrained personnel, leading to passenger rights violations, complaints and potential fines under Regulation 1371/2007.
- Unaddressed national regulatory variations leave smaller member states unclear on how to align their local rules with the programme's passenger-rights baseline; regulatory conflicts delay participation or reduce network coverage.

**Worst Case Scenario**: The legal opinion, completed too late or with insufficient detail, identifies fundamental incompatibility between the programme's carrier-funded liability pool and Regulation 1371/2007 rights (e.g., compensation thresholds too low, settlement timelines cause traveller hardship, assistance commitments exceed carrier capacity). Remediation requires redesign of the liability model and clearing rulebook by Month 9 (2027-07-12), consuming EUR 15–25 million and delaying binding standards to Month 24 (2028-10-12). Meanwhile, carriers unable to confirm compliance with passenger rights refuse to sign the binding liability agreement by Month 4 (2027-02-12), blocking the core commercial consensus. The EU Agency for Railways issues a non-conformity notice, suspending the programme until gaps are closed. Mandatory API exposure is pushed from Month 30 (2029-04-12) to Month 36–42 (2029-10-12 to 2030-04-12); four-corridor go-live slips from Month 48 (2030-10-12) to Month 60 (2031-10-12), and the 40% through-ticket target becomes unachievable (realistic outcome 20–25%, estimate). Operational procedures for missed connections and assistance remain undefined; staff confusion and passenger complaints spike, leading to negative media coverage and reduced consumer adoption of through-tickets. Total cost and schedule impact: EUR 30–50 million, 6–12 months delay.

**Best Case Scenario**: An independent legal review completed by Month 6 (2027-04-12) confirms that the liability model, clearing rulebook and public distributor specification preserve or exceed all Regulation 1371/2007 rights. The opinion identifies one minor gap (settlement timelines for refund reversal) and the remediation is trivial (adding 1 business day to the 5-day cycle). The legal opinion is published and provides carriers and distributors with binding assurance of compliance. Operational procedures are detailed, realistic and approved by the EU Agency for Railways by Month 9 (2027-07-12), allowing carriers and distributors to train staff and deploy systems with confidence. Worked examples show that the programme handles high-risk scenarios (missed connections, mobility assistance, refunds) consistently and fairly. Carriers sign the liability agreement by Month 4 (2027-02-12); the steering group votes unanimously on Decisions 1–3 by Month 6 (2027-04-12). Binding standards are published on schedule at Month 18 (2028-04-12); mandatory API exposure proceeds on Tier 1 schedule by Month 30 (2029-04-12); four-corridor through-ticketing goes live at Month 48 (2030-10-12); the 40% through-ticket target is achieved by Month 60 (2031-10-12). Accessibility thresholds (80% wheelchair access, 90% assistance within 4 hours) are met and validated in pilots, setting a programme standard. Passenger trust in through-tickets is high; complaint rates fall below baseline, supporting the 50% reduction target. Regulatory approval is swift; no challenges under Regulation 1371/2007 or accessibility law emerge.

**Fallback Alternative Approaches**:

- If an independent legal reviewer is not available by Month 2 (2026-12-12), form an internal task force from the EU Agency for Railways, DG MOVE and national regulators, supplemented by one contracted external rail-law counsel. Assign clear responsibility for each section (compensation, assistance, refunds, complaint handling). Complete a preliminary compliance assessment by Month 4 (2027-02-12); obtain external peer review by Month 6 (2027-04-12).
- If Regulation 1371/2007 gaps cannot be closed by design changes (e.g., carriers cannot guarantee assistance within the required notice period), publish a 'conditional compliance' manual that documents the gaps transparently, specifies best-effort fallbacks (e.g., 'assistance with at most 4 hours' notice on 90% of services, best-effort on remainder') and obtains explicit carrier and regulator sign-off on the conditional terms. This avoids unenforceable promises but maintains transparency.
- If operational procedures cannot be detailed for all five high-risk scenarios by Month 6 (2027-04-12), prioritise the two highest-impact scenarios (missed-connection rerouting and compensation claims) and publish detailed procedures by Month 9 (2027-07-12). Document the remaining three as 'to be detailed by Month 12 (2027-10-12)' and defer full pilot testing by 2–3 months. Conduct live pilots at Month 15–18 (2028-01-12 to 2028-04-12) instead of Month 12–15 (2027-10-12 to 2028-01-12).
- If the EU Agency for Railways is slow to approve the compliance manual (beyond Month 9 = 2027-07-12), secure written approval in phases: (a) liability and compensation procedures by Month 9 (2027-07-12); (b) assistance and accessibility procedures by Month 12 (2027-10-12); (c) complaint handling by Month 15 (2028-01-12). Begin carrier training on (a) immediately; defer training on (b) and (c) until those sections are approved, reducing schedule slip to 1–2 months.
- If national regulators flag conflicts between the programme's rights baseline and local passenger-rights rules in specific member states, establish a 'national variation annex' to the manual specifying the programme requirement and the local requirement for each member state. Where they conflict, apply the higher standard and document the cost impact (longer settlement cycles, additional staffing). Obtain regulatory approval per member state by Month 12 (2027-10-12).
- If staff training and certification cannot be completed for all carriers and distributors by Month 30 (2029-04-12), tier the requirement: (a) Tier 1 (large carriers, critical staff) certified by Month 24 (2028-10-12); (b) Tier 2 (regional, front-line) by Month 30 (2029-04-12); (c) Tier 3 (all others) by Month 36 (2029-10-12). Defer full mandatory API exposure to Month 42 (2030-04-12) to allow Tier 3 completion; launch Tier 1 API pilots by Month 30 (2029-04-12).

## Create Document 8: Risk Register and Mitigation Plan

**ID**: 1cf3e242-1219-46e5-a228-8e182514a07b

**Description**: Comprehensive risk register documenting all identified risks (regulatory slip, carrier refusal, legacy-system latency, stakeholder deadlock, pool overruns, competition-law challenge, accessibility compliance, etc.) with likelihood, severity, mitigation strategies and trigger-based contingency actions. Includes 20 risks from the pre-project assumptions, with residual-risk assessment post-mitigation. Updated quarterly Months 6, 12, 18, 24, 30, 36, 42, 48, 60 (2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12, 2029-04-12, 2029-10-12, 2030-04-12, 2030-10-12, 2031-10-12). Primary audience: Programme Director, steering group, DG MOVE, carriers.

**Responsible Role Type**: Programme Director (with support from Financial Risk Manager and Competition Law Counsel)

**Primary Template**: Project risk register template (ISO 31000 risk management standard)

**Secondary Template**: Programme-level risk dashboard (Jira, Asana, or similar)

**Steps to Create**:

- Compile initial risk register (20 risks from pre-project assumptions) by Month 1 (2026-11-12)
- Assess each risk: likelihood (Low/Medium/High), severity (Low/Medium/High), ownership, mitigation lead and residual-risk post-mitigation by Month 2 (2026-12-12)
- Establish risk-mitigation workstreams with assigned owners: actuarial study (Month 1 = 2026-11-12 start, Month 3 = 2027-01-12 delivery), technical audit (Month 1 = 2026-11-12 start, Month 6 = 2027-04-12 delivery), DG COMP pre-notification (Month 2 = 2026-12-12 filing), steering governance (Month 1 = 2026-11-12 start, Month 6 = 2027-04-12 binding votes), budget rebaselining (Month 6 = 2027-04-12 start), etc.
- Publish risk register and mitigation roadmap to steering group by Month 3 (2027-01-12)
- Track mitigation progress monthly; update risk register quarterly (Months 6, 12, 18, 24, 30, 36, 42, 48, 60 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12, 2029-04-12, 2029-10-12, 2030-04-12, 2030-10-12, 2031-10-12)
- Escalate any risk where likelihood or severity changes from Medium/High to High, or where mitigation is failing, to Programme Director and steering group within 5 business days
- At each major milestone (Months 6, 18, 30, 48, 60 = 2027-04-12, 2028-04-12, 2029-04-12, 2030-10-12, 2031-10-12), conduct risk-rating review and adjust mitigation intensity or contingency allocations

**Approval Authorities**: Programme Director, steering group (quarterly risk review)

**Essential Information**:

- Compile a comprehensive risk register that identifies all 20 pre-identified risks (regulatory slip, carrier refusal, legacy-system latency, stakeholder deadlock, pool overruns, competition-law challenge, Article 101 TFEU exposure, accessibility compliance, validation gaps, modal-shift shortfall, operational failures, capacity gaps, regulator blocking, commission-band disputes, specification forks, reconciliation errors, disruption-handling failures, validation interoperability, distributor withdrawal, and programme-staffing turnover) with precise likelihood (Low/Medium/High) and severity (Low/Medium/High) ratings
- Define ownership and lead role for each risk mitigation (e.g., Programme Director owns carrier liability model; Financial Risk Manager owns pool draw-down policy; Competition Law Counsel owns Article 101 pre-notification)
- Establish trigger-based contingency actions keyed to budget variance thresholds (EUR 100M: defer TEN-T to Months 60-72 = 2031-10-12 to 2032-10-12; EUR 200M: cut concession 20%; EUR 300M: restrict to four corridors) and schedule slip tolerances (2-4 month standards delay → Month 12 = 2027-10-12 gate; 6-12 month Regulation slip → shadow standards workstream)
- Quantify residual risk post-mitigation for each risk, noting which risks remain Medium/High even after planned actions (e.g., carrier refusal, Article 101 challenge, legacy latency all High residual until Month 6-12 = 2027-04-12 to 2027-10-12 gates close)
- Create a risk-monitoring dashboard showing: (1) open risk count by severity; (2) mitigation-workstream status (on-track, at-risk, overdue); (3) next escalation or decision point per risk; (4) evidence of mitigation delivery (e.g., actuarial study completion, technical audit, DG COMP guidance letter)
- Establish a quarterly update cycle tied to major milestones (Months 6, 12, 18, 24, 30, 36, 42, 48, 60 = 2027-04-12 onwards) with defined escalation protocol: any risk moving from Medium to High, or mitigation failing, escalated to Programme Director and steering group within 5 business days
- Specify the Month 6 (2027-04-12) readiness gate: carrier liability model signed by at least 8 major carriers and CER, technical audit published, steering votes held on Decisions 1-3 and 12; if unmet by Month 9 (2027-07-12), transition to Month 12 (2027-10-12) contingency gate
- Document the residual risk after each mitigation: e.g. 'Carrier Refusal (Risk 3): After actuarial model and carrier sign-off by Month 4 (2027-02-12), residual likelihood Medium (down from High); unresolved by Month 6 (2027-04-12) escalates to Steering and triggers deferral to Month 12 (2027-10-12)'
- Include a sensitivity analysis showing impact of three major risk scenarios: (1) carrier participation drops to 15-20 (from 25+) → through-ticket share 20-25% vs. 40% target; (2) Regulation adoption slips to Month 30 (2029-04-12) → binding-standards gate to Month 30 (2029-04-12), mandatory API to Month 42 (2030-04-12); (3) pool draw-down exceeds EUR 150M in Months 24-36 (2028-10-12 to 2029-10-12) → triggers EUR 200M budget-variance action
- Identify interdependencies between risks that compound programme impact: e.g. 'If both legacy latency (Risk 7) AND stakeholder deadlock (Risk 5) occur, mandatory API milestone slips 6-12 months and EUR 150-250M adapter acceleration is triggered, exhausting contingency'

**Risks of Poor Quality**:

- An incomplete or outdated risk register leaves the Programme Director and steering group unaware of emerging threats (e.g., a carrier's booking-system retrofit missing its Tier 1 deadline not flagged until Month 32 = 2029-06-12, too late for contingency action), cascading the missed milestone to later corridors and stretching the schedule beyond the Month 60 (2031-10-12) target
- Unclear ownership of risk mitigation leads to diffused accountability: if 'carrier participation' risk has no single owner, nobody drives the actuarial study and carrier sign-off by Month 4 (2027-02-12), and the Month 6 (2027-04-12) readiness gate cannot be certified, stalling the binding-standards pathway
- Missing or mis-stated trigger-based contingency actions result in crisis-reactive budget decisions: a pool draw-down that breaches EUR 200M in Month 32 (2029-06-12) is discovered ad-hoc instead of triggering the pre-agreed 20% concession-funding cut, forcing hasty reallocation and regulatory complaints
- Absence of a residual-risk framework means high-likelihood risks (carrier refusal, Article 101 challenge, legacy latency) are treated equally to low-likelihood ones (location/travel delays), misallocating limited mitigation effort and leaving critical path risks unmanaged
- A risk register that does not connect to funding tranches or milestone releases allows risks to fester unaddressed: if 'stakeholder deadlock' risk has no 'funding hold' link, the steering group can release conformance-test funding before a deadlocked decision is resolved, wasting EUR 10-20M on downstream work blocked by the unresolved choice
- Lack of quarterly update discipline means risks drift below the Programme Director's radar until they trigger crises: a 2-month slip in the technical audit (from Month 2 = 2026-12-12 to Month 4 = 2027-02-12) is not flagged in Month 3 (2027-01-12), so the Month 6 (2027-04-12) readiness gate is planned without knowing carrier tiers are unassigned
- Missing escalation protocol allows low-severity risks to accumulate in silence until they compound into high-severity ones: minor reconciliation-error trends (0.7% → 0.9% → 1.2% per month) go unreported in monthly updates, and by Month 28 (2029-02-12) the settlement-error risk is breaching 2%, forcing emergency system redesign at EUR 30-50M cost
- No sensitivity analysis means the Programme Director cannot communicate realistic downside scenarios to the steering group or the Commission: without a 'carrier participation drops to 15' scenario, the EUR 1.5 billion budget allocation assumes all 25 operators join, and a shortfall to 15 operators is met with unplanned budget reallocation that triggers EUR 200M variance and plan changes
- Absence of risk interdependencies means the Programme Director does not see how two Medium risks can compound into a catastrophic path: e.g. if both 'legislative slip' and 'pool drain' occur, the programme loses 12 months on standards and burns EUR 250M on pool top-ups and adapter acceleration, exhausting contingency and blocking the full TEN-T rollout
- A risk register disconnected from the decision log means decisions that mitigate risks (e.g., 'Carrier-funded guarantee pool with per-incident caps') are not tracked back to which risks they retire, leaving ambiguity about whether Decision 1 actually addresses Risk 3 or whether secondary risks remain unhandled

**Worst Case Scenario**: A convergence of three high-impact risks—carrier refusal due to unpriceable liability (Risk 3), legacy-system integration delays on 40% of smaller operators (Risk 2), and a 12-month slip in Regulation adoption (Risk 1)—triggers a cascade failure in the binding-standards milestone (target Month 18 = 2028-04-12). Carrier sign-off on the liability model stalls because the actuarial study (commissioned Month 1 = 2026-11-12) is incomplete by Month 6 (2027-04-12), and the technical audit reveals that 8–15 smaller operators cannot meet the Month 30 (2029-04-12) API exposure deadline without EUR 150–250 million in unbudgeted adapter acceleration. Steering deadlock on Decisions 1 and 2 persists until Month 12 (2027-10-12), and Regulation adoption is delayed to Month 30 (2029-04-12) due to parliamentary amendments. The programme loses 12 months on binding standards (slipping to Month 30 = 2029-04-12), mandatory API exposure cascades to Month 42 (2030-04-12), and four-corridor go-live extends to Month 60 (2031-10-12) or beyond. The carrier-funded guarantee pool, starved of sign-ups, drains EUR 200+ million in force-majeure top-ups and pool reinsurance by Month 36 (2029-10-12), triggering the EUR 200M budget-variance action: 20% of concession funding is cut (EUR 60M), the concession term extends to 7 years, and member-state capacity building is reduced by 30%. The through-ticket share goal drops from 40% to 15–20% because participation falls to 15–18 operators (vs. 25 target) and the extended timeline prevents full TEN-T rollout within the 60-month horizon. The programme delivers value on the four priority corridors by Month 60–72 (2031-10-12 to 2032-10-12) but fails the headline 40% and 60-month targets, facing political re-evaluation and potential phase-out of the EUR 1.5 billion commitment beyond Month 60 (2031-10-12). Estimated reputational cost: loss of stakeholder trust, potential legal challenges from excluded distributors, and EU audit findings on budget overruns and schedule slip.

**Best Case Scenario**: The risk register and mitigation plan are completed by Month 3 (2027-01-12) and published to the steering group, establishing clear ownership, trigger thresholds and escalation paths. By Month 6 (2027-04-12), all six critical mitigation workstreams reach their interim gates: (1) Actuarial study delivers a carrier-signed liability model with caps, co-insurance and on-time-performance-weighted contributions; (2) Technical audit classifies 25 operators into Tier 1, 2, 3 with per-operator API exposure milestones and EUR 240M tiered adapter funding; (3) Steering group votes 75% supermajority on Decisions 1–3 and 12 (liability, clearing, public distributor, commission band); (4) DG COMP pre-notification is filed and initial guidance is favorable; (5) Passenger-rights legal review confirms the Through-Ticket Liability and Rights Backstop design is compliant with EU Regulation 1371/2007; (6) Programme governance is certified with defined voting, escalation and fallback clauses. By Month 18 (2028-04-12), Regulation is adopted with the proposed binding-standards trigger, DG COMP issues a formal guidance letter confirming Article 101 compatibility, and the binding-standards milestone is achieved with OSDM pinned in an implementing act. Risk dashboard shows all 20 risks transitioned from High/Medium (pre-mitigation) to Medium/Low (post-mitigation), with only 3 risks remaining at Medium (carrier participation, late-carrier conformance, modal-shift shortfall) requiring continued monitoring. Phase 2 proceeds (Months 18–48 = 2028-04-12 to 2030-10-12) with Tier 1 API exposure achieved at Month 30 (2029-04-12), four-corridor through-ticketing live by Month 48 (2030-10-12), and full TEN-T extension completed by Month 60 (2031-10-12). Through-ticket share reaches the 40% target by Month 60 (2031-10-12), distributor complaints are halved, and the EUR 1.5 billion budget is spent within the EUR 85M headroom (no variance-triggered cuts). The Programme Office and steering group use the quarterly risk updates to stay ahead of emerging issues, and no risk breaches its severity rating during Months 6–60 (2027-04-12 to 2031-10-12). Outcome: a well-managed programme that delivers on schedule, within budget, with stakeholder confidence and regulatory support, enabling Phase 2 TEN-T extension and future modal-shift initiatives on additional corridors.

**Fallback Alternative Approaches**:

- If a comprehensive 20-risk register cannot be completed by Month 3 (2027-01-12), prioritize a 'critical-path risk register' covering the six risks with the highest cascade impact on the binding-standards and mandatory-API milestones: (1) carrier refusal (Risk 3), (2) legacy-system integration (Risk 2), (3) regulatory slip (Risk 1), (4) stakeholder deadlock (Risk 5), (5) competition-law challenge (Risk 6), (6) budget overrun (Risk 4). Document these six with full mitigation and escalation by Month 2 (2026-12-12), defer medium/low risks to Month 6 (2027-04-12) review
- If the Programme Director lacks dedicated Financial Risk Manager support, assign risk ownership to the existing Finance Team and require weekly tracker updates to a shared dashboard (Jira, Asana, or similar) that auto-escalates when a mitigation task falls 2+ weeks behind schedule. Reduce the update cycle from quarterly to monthly for Months 0–18 (2026-10-12 to 2028-04-12) to catch slippage early
- If stakeholder consensus on risk tolerances cannot be reached before Month 6 (2027-04-12), adopt a 'risk-decision log' where each risk's mitigation strategy is recorded with the steering group's vote and any dissenting positions, so that later cascading failures are tied to documented choices rather than ambiguous ownership
- If DG COMP pre-notification is delayed beyond Month 2 (2026-12-12), commission an external competition-law firm (EUR 0.5–1M cost) to conduct a parallel informal guidance-seeking process with DG COMP staff while the formal pre-notification is prepared, so that high-level competition concerns are identified and the formal process includes a response to those concerns
- If the technical audit cannot be completed by Month 2 (2026-12-12), conduct a rapid desktop assessment of the largest 10 carriers' booking systems (40% of network capacity by estimate) by Month 1 (2026-11-12) and use that to establish Tier 1 and Tier 2 timelines; defer Tier 3 (smallest operators, 20% of network by estimate) audit to Month 3 (2027-01-12) to avoid delaying the Month 6 (2027-04-12) readiness gate
- If the actuarial study vendor is delayed or unable to deliver by Month 3 (2027-01-12), engage a second actuarial firm in parallel by Month 1 (2026-11-12) with a fast-track EUR 0.3M contract to deliver a simplified risk model (using industry benchmarks for missed-connection rates and rerouting costs instead of carrier-specific data) by Month 3 (2027-01-12), allowing the Month 4 (2027-02-12) carrier sign-off process to proceed with good-faith estimates
- If quarterly risk-register updates cannot be automated or tracked in a shared dashboard, assign a dedicated Risk Coordinator (1 FTE, approximately EUR 0.1M/year) to manually compile monthly risk flash reports (2-page format: 5 risks flagged for escalation, 5 risks trending toward worse, 5 risks improving) and circulate to Programme Director and Steering Group by the 5th of each month
- If the Month 6 (2027-04-12) readiness gate cannot certify all six mitigation workstreams, adopt a 'phased readiness' approach where critical decisions (liability model, technical tiers) are certified at Month 6 (2027-04-12), and secondary gates (steering consensus on commission band, passenger-rights approval) are certified by Month 9 (2027-07-12), deferring the binding-standards window by 1–3 months
- If budget variance thresholds (EUR 100M, 200M, 300M) cannot be monitored in real-time due to carrier billing and clearing-system delays, establish a 'predicted variance' process where the Programme Office projects draw-downs based on monthly carrier claims and reconciliation data, and flags predicted variance 1–2 months before it occurs, allowing preventive action rather than reactive cuts
- If the Programme Director or steering group members turn over mid-phase, immediately conduct a 'risk-transition briefing' (half-day workshop) covering the current risk dashboard, open mitigation tasks, upcoming gates and escalation paths, and secure a written sign-off from the incoming stakeholder(s) to preserve institutional memory and prevent delays

## Create Document 9: Milestone-Conditioned Funding Release Ladder (Tranches and Verification Criteria)

**ID**: 4e5e1f6d-4c10-4898-be32-d396ab9d680e

**Description**: Formal funding-release framework specifying which deliverables must be verified before each funding tranche is released to carriers and member-state bodies. Tier 1 (Month 30 = 2029-04-12): EUR 80M adapter funding released to Tier 1 carriers after independent audit verifies p95 latency <2 seconds, 99.5% uptime, <1% stale-seat errors on live API for 30 consecutive days. Tier 2 (Month 36 = 2029-10-12): EUR 80M released after Tier 2 conformance verification. Tier 3 (Month 42 = 2030-04-12): EUR 50M released after Tier 3 verification. Also specifies that public-distributor concession (EUR 300M) is released in tranches tied to platform launch (Month 30 = 2029-04-12), achieving passenger-volume milestones (Months 36, 48, 60 = 2029-10-12, 2030-10-12, 2031-10-12) and complaint-reduction targets. Output: compliance incentive, budget protection, achievement of SLA targets. Primary audience: carriers, Programme Director, Finance Lead, steering group.

**Responsible Role Type**: Programme Director (with support from Independent Audit & Assurance Function)

**Primary Template**: Contract milestone and payment schedule template

**Secondary Template**: SLA verification checklist (per tier, verified by independent auditor)

**Steps to Create**:

- Define tier-specific deliverables and SLA targets by Month 6 (2027-04-12), based on technical audit output and binding standards
- Specify verification procedure: independent auditor conducts live testing of each carrier's API against SLA targets; tests run for 30 consecutive days (proposed threshold) before tranche release is approved
- Draft Tier 1 verification checklist (p95 latency <2s, 99.5% uptime, <1% stale-seat errors, booking correctness, refund reversal success rate) and acceptance criteria by Month 9 (2027-07-12)
- Publish complete funding-release ladder (all three tiers + concession tranches) and SLA-verification schedules by Month 12 (2027-10-12); incorporate into binding standards
- At each tier's milestone (Months 30, 36, 42 = 2029-04-12, 2029-10-12, 2030-04-12), conduct independent audit of all carriers in that tier; publish audit results and release/hold decision within 10 business days of test completion
- For any carrier missing SLA targets, offer remediation window (15 business days) to retest; if still failing, hold that carrier's tranche and escalate to Programme Director
- For concession tranches, tie releases to measured passenger volumes and complaint-reduction achievements (quarterly metrics); publish progress against targets quarterly

**Approval Authorities**: Independent Audit & Assurance Function (verification), Programme Director (release decision), DG MOVE Controller (funding authorization)

**Essential Information**:

- Specify all three tiered funding tranches with EUR amounts and release triggers: Tier 1 (EUR 80M at Month 30 = 2029-04-12), Tier 2 (EUR 80M at Month 36 = 2029-10-12), Tier 3 (EUR 50M at Month 42 = 2030-04-12), each conditioned on independent audit verification of SLA targets (p95 latency <2 seconds, 99.5% uptime, <1% stale-seat errors) over 30 consecutive days
- Define concession tranches for the EUR 300M last-resort distributor envelope: platform launch (Month 30 = 2029-04-12), volume milestones (Months 36/48/60 = 2029-10-12/2030-10-12/2031-10-12), complaint-reduction targets, with subsidy capped at EUR 60M over five years and clawback if volumes exceed forecast >20%
- Detail verification procedure: independent auditor conducts live SLA testing against each carrier's API endpoint; document pass/fail criteria, remediation windows (15 business days to retest), escalation to Programme Director for holdback decisions
- Specify how tranches attach to the Conformance Gate decision: conformance certificates required before SLA testing begins; document the inter-dependency between gate outcomes and fund release
- Quantify financial consequences of missed tranches: if Tier 1 carriers miss SLAs, EUR 80M holds; calculate cascade effect on Tier 2/3 timelines and TEN-T extension funding (which draws from post-Month 48 = 2030-10-12 capacity)
- Document variance triggers tied to programme-wide budget headroom (EUR 85M unallocated): EUR 100M variance triggers TEN-T deferral to Months 60-72 (2031-10-12 to 2032-10-12); EUR 200M triggers 20% concession cut; EUR 300M restricts to four priority corridors only
- Provide a worked example of a single carrier's path through the three tiers, showing how SLA performance in Month 30 (2029-04-12) gates their Tier 2 eligibility and affects fund flow to their peers
- Outline governance approval chain: Independent Audit & Assurance Function verifies deliverables, Programme Director authorizes release, DG MOVE Controller signs fund transfer; specify authority sign-off timeline within 10 business days of audit completion

**Risks of Poor Quality**:

- If SLA verification criteria are vague or left to auditor discretion, carriers dispute results and escalations delay fund releases by 4–8 weeks, cascading Tier 2 and TEN-T extension timelines and straining the budget reserve
- If tranches are released without independent audit or with self-certification by carriers, compliance incentives evaporate: carriers miss latency and availability targets, through-ticket search succeeds at only 70–80% (versus target >90%), and 15–25% fewer passengers adopt through-tickets (estimate)
- If concession tranches are not tied to measured passenger volume and complaint reduction, the concessionaire operates at a loss with no accountability, draining the EUR 300M envelope by Month 36 (2029-10-12) and forcing re-budgeting that cuts member-state capacity building by EUR 50–100M (estimate)
- If variance triggers are not pre-published with clear thresholds (EUR 100M/200M/300M), budget overruns accumulate silently until Month 42–48 (2030-04-12 to 2030-10-12), leaving no time to descope TEN-T or cut concession subsidy, forcing the EUR 150M force-majeure reserve to be drawn for non-force-majeure pool shortfalls
- If remediation windows and escalation paths are not defined, a single carrier's SLA failure (e.g., 2.5-second latency) can hold EUR 80M and delay Tier 2 work at other carriers, creating perverse incentives and political friction among participants
- If the document does not bind regulators, DG MOVE and carriers to a common acceptance criteria before audits begin, disputes over what constitutes a 'pass' can delay releases by 2–3 months per tranche

**Worst Case Scenario**: If the Milestone-Conditioned Funding Release Ladder is absent or insufficiently detailed by Month 9 (2027-07-12), carriers lack commitment certainty and face unpredictable funding, leading 30–40% (estimate) to reduce IT investment or withdraw from the programme entirely. This fragments corridor coverage by Month 30 (2029-04-12), leaving 8–15 smaller operators unable to expose APIs and 40–50% of planned through-ticket itineraries unavailable. Unverified fund releases allow the carrier-funded guarantee pool or public distributor concession to overspend without consequence, draining EUR 100–200M of the EUR 1,500M cap by Month 36 (2029-10-12) and eliminating headroom to launch the TEN-T extension. The 40% through-ticket goal becomes unachievable; realistic outcome is 15–25% (estimate), with full network completion pushed to Month 84 (2033-10-12) or abandoned. The programme loses credibility with carriers and independent distributors, triggering legal challenges to funding allocation and regulatory complaints to national bodies.

**Best Case Scenario**: A well-defined Milestone-Conditioned Funding Release Ladder with transparent SLA criteria, independent audits and published variance thresholds enables carriers to commit to integration with certainty: 90%+ of Tier 1 carriers meet latency and availability targets by Month 30 (2029-04-12), their EUR 80M releases on schedule, and Tier 2/3 work advances predictably. Monthly SLA scorecards and variance alerts keep the programme within the EUR 1,500M budget cap and the EUR 85M headroom, allowing all TEN-T corridors to launch by Month 60 (2031-10-12). The concession tranches tied to passenger volumes and complaint reduction incentivise the distributor to invest in marketing and support, achieving the 40% through-ticket target by Month 60 (2031-10-12). Predictable funding releases remove a major programme risk, accelerate carrier confidence and unlock private IT investment that multiplies the public programme's impact. Regulatory oversight is clear, disputes are rare and escalations are resolved within 10 days.

**Fallback Alternative Approaches**:

- If independent auditing capacity is unavailable, establish an expedited self-certification regime: carriers submit SLA evidence (API test logs, monitoring dashboards) within 15 days of Month 30 (2029-04-12); a small in-house audit team spot-checks 20% of submissions; release 80% of tranches on submission and 20% pending verification completion, reducing cash-flow friction while maintaining compliance discipline
- If SLA verification proves too contentious among carriers, adopt a 'learning-with-verification' approach: release 50% of Tier 1 funding unconditionally at Month 30 (2029-04-12) to accelerate deployment, tie the remaining 50% to Month 36 (2029-10-12) verification of sustained SLAs; document learnings from early deployment to set more realistic Tier 2 targets
- If concession tranches cannot be tied to measurable volume and complaint metrics (e.g., because distributor sales data lags by 30 days), use a hybrid: release 60% on schedule based on platform launch and go-live, tie the remaining 40% to quarterly audits of transaction data and complaint records (published with a 6-week lag), capping operating subsidy at EUR 12M/year with monthly burn limits
- If variance triggers lead to constant re-baselining and cut discussions, establish a 'fixed-variance envelope': allocate EUR 100M of the EUR 150M reserve as a dedicated variance buffer specifically for adapter overruns and concession shortfalls; any variance below EUR 100M auto-adjusts by deferring lower-priority TEN-T corridors rather than escalating for re-approval
- If governance bottlenecks delay release decisions (e.g., Controller sign-off pending budget cycles), delegate routine releases under EUR 20M to the Programme Director with post-hoc audit reporting to DG MOVE, reserving only tranches >EUR 50M for formal Controller authorization; publish a quarterly release calendar by Month 12 (2027-10-12) so participants can plan 60-day cash-flow forecasts

## Create Document 10: Stakeholder Engagement and Governance Charter

**ID**: b10ae9e2-2c2f-482f-bdfc-8bb038bcbe14

**Description**: Formal charter defining the steering-group composition, roles, decision rights and escalation processes. Comprises: (1) steering core group (9 members: DG MOVE, Agency, CER, 4 major carriers, Trainline, Omio, BEUC, disability body); (2) 75% supermajority voting rule on critical decisions (Decisions 1-5, commission band); (3) Commission mediation protocol if votes do not reach 75% by Month 5 (2027-03-12); (4) biweekly meeting schedule (Mondays 09:00 Brussels); (5) fallback technical interfaces for dissenting parties (e.g., bilateral clearing for carriers refusing pooled liability, sandbox-only role for distributors refusing mandatory API). Includes observer seats for national regulators and quarterly briefings to member-state governments. Output: transparent, inclusive governance with clear escalation paths. Primary audience: steering members, Commission, member-state governments, carriers, distributors.

**Responsible Role Type**: Programme Director (with support from Communications & Stakeholder Engagement Lead)

**Primary Template**: Governance Charter template (EU institutional model)

**Secondary Template**: Steering group terms of reference (meeting agendas, decision log, action tracking)

**Steps to Create**:

- Draft governance charter and decision-rights matrix by Month 0.5 (2026-10-27)
- Circulate to intended steering members (DG MOVE, CER, 4 major carriers, distributors, BEUC) for feedback Months 0.5-1 (2026-10-27 to 2026-11-12)
- Resolve any objections to voting rules or escalation procedures by Month 1 (2026-11-12); finalize charter
- Publish charter and call steering group's first meeting (Month 1 = 2026-11-12); establish biweekly meeting cadence (Mondays 09:00 Brussels time) and action-item tracking
- At Month 1 (2026-11-12) meeting, set the schedule for binding votes on Decisions 1-5 (by Month 6 = 2027-04-12) and option-paper circulation (by Month 2 = 2026-12-12)
- Publish option papers for each decision (Decisions 1-5) with explicit trade-offs (speed vs. coverage, control vs. complexity, budget risk vs. carrier autonomy) by Month 2 (2026-12-12)
- Hold written consultation on option papers (Months 2-3 = 2026-12-12 to 2027-01-12); compile feedback
- Conduct binding steering votes (75% supermajority) on all five decisions by Month 6 (2027-04-12); document voting outcomes and dissenting positions
- If vote on any decision does not reach 75% by Month 5 (2027-03-12), invoke Commission mediation; Commission Transport Commissioner or delegated advisor conducts facilitated dialogue by Month 5.5 (2027-03-27) and recommends resolution by Month 6 (2027-04-12)
- Maintain detailed steering decision log (biweekly) and publish anonymised summary to carriers and distributors monthly

**Approval Authorities**: Programme Director (charter sign-off), steering members (by participation), DG MOVE (escalation authority)

**Essential Information**:

- Define the steering group's composition, roles and decision rights: 9 core members (DG MOVE, Agency, CER, 4 major carriers, Trainline, Omio, BEUC, disability body), voting threshold (75% supermajority for Decisions 1–5 and commission band), meeting cadence (biweekly Mondays 09:00 Brussels) and action-item tracking.
- Specify the escalation protocol: if a critical decision does not reach 75% by Month 5 (2027-03-12), Commission mediation must resolve the deadlock by Month 6 (2027-04-12), with clear facilitation steps and fallback technical interfaces (e.g., bilateral clearing for dissenting carriers, sandbox-only role for dissenting distributors).
- Publish option papers for each critical decision (Decisions 1–5: liability backstop, clearing, public distributor, funding ladder, availability topology) by Month 2 (2026-12-12), each outlining three strategic choices with explicit trade-offs (speed vs. coverage, control vs. complexity, budget risk vs. carrier autonomy).
- Document observer seat arrangements for national railway regulators and the timing of regulatory impact assessments per member state (Month 3 = 2027-01-12 deadline).
- Establish the quarterly briefing schedule for member-state governments, carriers and distributors, including pool contribution data, SLA scorecards and commission-band compliance.
- Clarify the binding-vote calendar: Decisions 1–5 require votes by Month 6 (2027-04-12); if any vote is deferred to Month 12 (2027-10-12), the binding-standards milestone (Month 18 = 2028-04-12) is at risk of a 2–4 month slip (estimate).
- Detail fallback mechanisms for actors who reject core decisions: bilateral clearing recourse for carriers refusing pooled liability, third-party settlement interface for independent distributors refusing mandatory API, sandbox-only role for distributors refusing consumer-facing mandatory sales.
- Specify the decision log and action-tracking process: steering decisions logged within 48 hours of meeting, anonymised summary published monthly to all carriers, distributors and member states.

**Risks of Poor Quality**:

- Undefined voting rules or escalation procedures delay binding decisions by 2–4 months (estimate), cascading the binding-standards milestone from Month 18 (2028-04-12) to Month 24–30 (2028-10-12 to 2029-04-12), which stretches the mandatory API exposure deadline (Month 30 = 2029-04-12) to Month 36–42 (2029-10-12 to 2030-04-12) and reduces four-corridor go-live readiness.
- Unclear fallback provisions trigger withdrawal of major stakeholders (e.g., a carrier refusing pooled liability or a distributor rejecting the clearing design), fragmenting the network and reducing through-ticket volume by 15–25% (estimate), which lowers the 40% goal to 20–30%.
- Absent observer seats or regulator engagement lead to national regulatory veto surprises late in the standards phase (Month 12–18 = 2027-10-12 to 2028-04-12), requiring 3–6 month rework and legal disputes, estimated cost EUR 10–20 million.
- Inconsistent or delayed monthly briefings to carriers and distributors create information vacuums, triggering competitive jockeying, rumours about pool contributions and commission bands, and loss of confidence in programme neutrality.
- No transparent decision log or action tracking erodes stakeholder trust and makes it difficult to trace why decisions were made or who was accountable, inviting challenges to binding votes and reopening settled issues.

**Worst Case Scenario**: If the steering governance charter is incomplete, ambiguous or published late (beyond Month 1 = 2026-11-12), critical decisions (liability model, clearing architecture, public distributor role, funding tranches, commission band) stall at the steering table or fragment into bilateral negotiations. A deadlocked vote on the liability backstop (Decision 1) that cannot be resolved by mediation by Month 6 (2027-04-12) leaves the programme without a signed carrier risk-allocation model and triggers 30–40% (estimate) of carriers to refuse inventory exposure. This cascades: no agreed liability model means standards cannot bind (Month 18 = 2028-04-12 slips to Month 24–30 = 2028-10-12 to 2029-04-12), API exposure is postponed (Month 30 = 2029-04-12 → Month 36–42 = 2029-10-12 to 2030-04-12), four-corridor go-live fails (Month 48 = 2030-10-12 → Month 60–72 = 2031-10-12 to 2032-10-12) and the 40% through-ticket goal drops to 15–25% (estimate). Major distributors (Trainline, Omio) may withdraw if the clearing design is rejected and no fallback interface is offered. Estimated financial impact: EUR 150–200 million in sunk costs (standards work, pilots, governance overhead) with delivery 12–18 months late and outcomes 40–50% below target.

**Best Case Scenario**: If the charter is published by Month 1 (2026-11-12) with clear voting rules, escalation triggers and fallback options, steering members align quickly on option papers circulated by Month 2 (2026-12-12). Binding votes on all five critical decisions reach 75% supermajority by Month 6 (2027-04-12), with any dissenting carriers or distributors offered transparent technical fallback interfaces (bilateral clearing, third-party settlement) that preserve their participation. Option papers and explicit trade-offs enable stakeholders to make informed commitments: carriers agree to the signed liability model with clear caps and co-insurance thresholds; distributors accept the federated clearing architecture and the commission band; the public distributor concession is tendered with transparent subsidy caps. Monthly SLA and pool-contribution scorecards build confidence and reduce later disputes. Regulatory observers flag issues early (by Month 3 = 2027-01-12), allowing member-state regulatory impact assessments to be resolved before binding standards (Month 18 = 2028-04-12). Early clarity on governance enables technical and legal working groups to proceed in parallel, compress the Phase 1 schedule (Months 0–18 = 2026-10-12 to 2028-04-12) and hit Tier 1 API exposure (Month 30 = 2029-04-12) on schedule, delivering four priority corridors live by Month 48 (2030-10-12) and reaching the 40% through-ticket target by Month 60 (2031-10-12) within the EUR 1,500M budget.

**Fallback Alternative Approaches**:

- If consensus on the 75% supermajority rule cannot be reached by Month 1 (2026-11-12), adopt a modified consensus rule: Decisions 1–3 (liability, clearing, public distributor) require 80% supermajority (7 of 8 voting steering members, excluding observers); Decisions 4–5 (funding, availability) require 60% supermajority (5 of 8). This reduces deadlock risk but increases the chance of downstream rework once smaller carriers or distributors implement non-consensus choices.
- If escalation to the Commission Transport Commissioner is not available or too slow, establish a binding arbitration mechanism: appoint an independent mediator (e.g., a retired EU judge or transport economist) to hear positions from 30 days after a 75% vote is missed and issue a binding recommendation within 15 days. Implementable by Month 14 (2027-12-12) if legal authority is secured from DG MOVE.
- If major carriers (e.g., DB, SNCF, ÖBB) reject the pooled-liability backstop, offer a phased rollout: allow Tier 1 (corridor-critical) carriers to negotiate bilateral liability caps with the clearing entity in a Phase 2 opening (Month 24 = 2028-10-12), with transparency requirements so smaller carriers can see the effective caps and propose equivalent terms. This delays full-pool consensus but allows standards to proceed with interim liability rules.
- If independent distributors refuse the federated clearing architecture, establish a third-party settlement interface: any distributor can route settlements through an existing sector clearinghouse (e.g., Equinix or Paysafe) under an escrow and netting protocol, with the clearing entity providing only the master data dictionary and dispute-resolution procedures. This preserves distributor choice while maintaining system coherence.
- If steering deadlock persists beyond Month 9 (2027-07-12), compress the decision scope: defer Decisions 4–5 (funding release ladder and commission band) to a Month 12 (2027-10-12) secondary vote, and proceed with binding standards based on Decisions 1–3 (liability, clearing, public distributor) alone. This allows technical standards work to advance while commercial terms are negotiated in parallel, with the caveat that binding standards cannot fully specify funding tranches or commission rules until Month 12 (2027-10-12).


# Documents to Find

## Find Document 1: EU Rail Ticketing Regulation Proposal Text and Legislative Status

**ID**: fc47eb5b-741b-4632-b918-f0dfa46efa09

**Description**: The formal text of the Commission's proposed Regulation on Digital Booking and Ticketing Services for Rail (proposed May 2026, status not verified as of project start October 2026). Provides the legal foundation for binding standards, mandatory API exposure, passenger-rights harmonisation and the Agency's role in conformance oversight. Essential input for the binding-standards working group and for forecasting the Regulation's adoption timeline (estimated Month 18 = 2028-04-12, but 6-12 month slip plausible). Intended audience for analysis: standards custodian, competition-law counsel, Programme Director.

**Recency Requirement**: Current as of project start (Month 0 = 2026-10-12); must reflect the proposal tabled in May 2026, including any amendments proposed by Parliament or Council by Month 0 (2026-10-12).

**Responsible Role Type**: Regulatory Affairs and Stakeholder Alignment Director

**Steps to Find**:

- Search EUR-Lex (Official EU Legislation Portal) for 'Regulation Digital Booking Ticketing Services Rail' or similar keywords; confirm proposal date (May 2026) and current legislative status
- Contact DG MOVE legislative affairs unit directly (email to DG-MOVE-REGISTRY@ec.europa.eu or via the DG MOVE website) requesting a copy of the May 2026 proposal and any amendments tabled by Parliament or Council
- If the proposal has been tabled and is available on EUR-Lex, download full text and all explanatory memoranda
- If proposal has not yet been tabled, request from DG MOVE: a pre-release briefing or roadmap indicating the tabling timeline (estimate currently Month 2-6 = 2026-12-12 to 2027-04-12)

**Access Difficulty**: Medium. The Commission proposal (if published) is freely available on EUR-Lex. If not yet published (proposed May 2026, not yet confirmed as of October 2026 project start), access requires direct contact with DG MOVE, which will provide it confidentially or on request. Legislative amendments may not be publicly available until tabled formally in Parliament or Council.

**Essential Information**:

- Confirm the Commission proposal's official title, tabling date (May 2026 claimed) and current parliamentary/Council status as of Month 0 (2026-10-12).
- Identify the binding-standards trigger mechanism: which articles or provisions require OSDM to be pinned via delegated act, implementing act, or direct regulation text, and the timeline for each.
- Extract the mandatory API exposure date and scope: which carriers, which data fields, which endpoints (search, booking, refunds, disruption) are legally required by what deadline.
- List all passenger-rights obligations imposed on through-tickets: continuity-of-journey rules, compensation thresholds, assistance notice periods, refund timelines, and how they differ from single-carrier journeys under Regulation 1371/2007.
- Detail the Agency's role: does the Regulation grant the Agency power to set conformance standards, approve clearing mechanisms, oversee OSDM change control, or only supervise member-state implementation.
- Specify the legal basis and scope for a carrier-funded guarantee pool or public rights backstop: are both permitted, is one mandated, and what limits (caps, reinsurance, member-state veto) apply.
- Identify any restrictions on public or third-party distributor roles: can a public reference distributor operate a consumer-facing sales channel, or only a B2B sandbox.
- Extract competition-law carve-outs or safe harbours: does the Regulation explicitly permit data sharing, clearing, or fare-construction coordination among competing carriers, or does Article 101 TFEU apply in full.
- List any member-state implementation flexibility: can national regulators opt out, delay conformance, or impose stricter rules than the Regulation baseline.

**Risks of Poor Quality**:

- If the proposal text is not the final May 2026 tabling, but an earlier draft or leaked version, the binding-standards working group builds on incorrect legal foundations, requiring 2–3 month rework once the official text is published.
- If the mandatory API exposure date or scope is misread (e.g., 'all data' versus 'search and booking only'), carriers and distributors invest in the wrong systems, delaying conformance by 6–12 months and fragmenting the network.
- If passenger-rights obligations are weaker than Regulation 1371/2007 or create ambiguous gaps, the programme risks legal challenges from passenger-rights bodies and regulator enforcement, requiring 3–6 month redesign of the liability and disruption procedures.
- If the Agency's conformance or OSDM-stewardship powers are narrower than assumed, the Specification Custodian Seat decision and the binding-standards delivery depend on a consensus mechanism not yet defined, delaying standards by 2–4 months.
- If the Regulation permits a public distributor only as a sandbox (not consumer-facing), the Public Reference Distributor Mandate decision must pivot from a last-resort concession to a narrower B2B role, reducing the programme's ability to reach the 40% through-ticket goal.
- If competition-law safe harbours are absent or weak, a DG COMP challenge after Month 24 (2028-10-12) could unwind the clearing or data-sharing arrangements, forcing 6–12 month rework and EUR 50–100M cost (estimate).
- If the Regulation imposes stricter environmental or accessibility requirements than the programme assumes, the four-corridor go-live timeline slips by 3–6 months due to infrastructure compliance work not yet budgeted.

**Worst Case Scenario**: The proposal text is not the official May 2026 tabling but a draft; the parliamentary or Council process has already tabled substantial amendments that weaken mandatory API scope, remove safe harbours for data sharing, or delay the binding-standards deadline to Month 24 (2028-10-12) or later. The binding-standards working group proceeds on incorrect legal foundations until Month 6 (2027-04-12), when an authoritative legal review discovers discrepancies. The programme must conduct a 2–3 month legal rework, defer binding standards from Month 18 (2028-04-12) to Month 21 (2028-07-12), push mandatory API exposure from Month 30 (2029-04-12) to Month 36 (2029-10-12), and compress the four-corridor go-live from Month 48 (2030-10-12) to Month 54–60 (2031-04-12 to 2031-10-12). Carriers and distributors lose confidence in the legal foundation and delay investment, reducing participation from 25+ to 15–18 operators. The 40% through-ticket goal becomes unachievable; realistic outcome is 20–25% (estimate). Budget is reallocated to accelerate legal and standards work, draining EUR 50–100M from later-wave infrastructure, and the full TEN-T rollout extends beyond Month 72 (2032-10-12).

**Best Case Scenario**: The proposal is the official May 2026 text, has clear binding-standards triggers (OSDM pinned by Month 18 = 2028-04-12), mandatory API exposure for all participating carriers by Month 30 (2029-04-12), and explicit safe harbours for carrier data sharing and pooled clearing. Passenger-rights obligations align with or exceed Regulation 1371/2007, so no redesign is needed. The Agency is granted clear power to oversee conformance and OSDM governance, making the Specification Custodian Seat decision executable without additional consensus. The Regulation permits both a public consumer-facing distributor and a carrier-funded guarantee pool, giving the programme full design flexibility. No competition-law carve-out is explicit, but the legal opinion by Month 6 (2027-04-12) confirms Article 101 compatibility under the clean-team arrangement. Carriers and distributors see clear legal certainty and accelerate investment; the liability model is signed off by Month 4 (2027-02-12) with no disputes. Binding standards are delivered on schedule Month 18 (2028-04-12), mandatory API exposure is met by Month 30 (2029-04-12), and the four corridors go live by Month 48 (2030-10-12). The 40% through-ticket goal is reached by Month 60 (2031-10-12); the full TEN-T network completes by Month 66–72 (2032-04-12 to 2032-10-12).

**Fallback Alternative Approaches**:

- If the official proposal text is not available by Month 2 (2026-12-12), request a detailed legislative roadmap from DG MOVE's directorate for directorate legal affairs covering the expected tabling date, anticipated amendments and the adoption timeline. Work in parallel with a shadow standards workstream that drafts binding-standards language for each plausible scenario (strong safe harbour, weak safe harbour, no safe harbour) so that the formal standards can pivot once the Regulation text is confirmed.
- Establish a legal-watch panel (DG MOVE, Agency, BEUC, CER and one independent competition-law counsel) that monitors the Regulation's legislative progress from Month 1 (2026-11-12) onwards and flags deviations from the May 2026 proposal by end of Month 3 (2027-01-12). If material changes are flagged, commission a rapid legal impact assessment (2–3 weeks) by Month 4 (2027-02-12) and adjust the binding-standards and liability-model timelines accordingly.
- If the proposal is not yet tabled and adoption timeline slips beyond Month 18 (2028-04-12), negotiate with member states to adopt a voluntary binding-standards arrangement (technical declaration or council statement) that pins OSDM and mandatory API scope without waiting for formal Regulation adoption. This preserves the Month 18 (2028-04-12) binding-standards milestone and allows pilots to proceed under member-state regulatory cover.
- If passenger-rights obligations in the Regulation diverge materially from Regulation 1371/2007 or are ambiguous, commission an independent legal audit by the Agency and a passenger-rights NGO by Month 6 (2027-04-12) that specifies the minimum rights floor and proposes a compliance manual. Use this manual as the interim binding standard for carrier conformance, to be reconciled with the final Regulation language once published.
- If the Regulation restricts the public distributor to a B2B sandbox, negotiate with DG MOVE to permit the programme to launch a tendered last-resort concession under a separate legal basis (e.g., as a public service obligation under transport regulation) running in parallel with the OSDM programme. This preserves the last-resort channel without relying on the Regulation's distributor scope.

## Find Document 2: Historical Rail Passenger Missed-Connection and Rerouting Cost Data (Per-Carrier)

**ID**: ca167ec9-6337-49b6-8a62-134c8439a574

**Description**: 24-month rolling data on missed-connection incidents, rerouting costs, passenger compensation claims and incident clustering from at least 5 major European carriers (SNCF, Deutsche Bahn, SBB, Renfe, ÖBB or equivalent) and one mid-size carrier. Used as input for the actuarial study to derive missed-connection frequencies, rerouting cost distributions, and carrier-specific risk profiles that underpin the carrier-funded guarantee-pool model (Decision 1) and the liability-cap and co-insurance parameters. Intended audience for analysis: actuary, risk-modelling specialist, Programme Director.

**Recency Requirement**: Most recent 24-month rolling period (September 2024 to September 2026, covering the most recent two full operational years before project start). Data must be current and representative; older data risks obsolescence due to changes in operating practices or passenger demand.

**Responsible Role Type**: Carrier Liability & Risk Modelling Specialist

**Steps to Find**:

- Contact CER (Community of European Railways) membership team and request introduction to finance/operations contacts at 5-6 major carriers for historical incident data exchange
- Send formal data-request letter to each carrier (CIOs and CFOs) by Month 0.5 (2026-10-27) requesting: monthly counts of missed-connection incidents (by corridor and carrier pair), cost per incident (rerouting, accommodation, compensation), incident severity classification (passenger stranded <1 hour, 1-4 hours, >4 hours) and any seasonal or systemic clustering patterns
- Offer confidentiality agreement and data-protection assurances (GDPR compliance, aggregation to remove passenger identifiers, use limited to actuarial study)
- Follow up with carriers biweekly; expect 2-4 week response time (carriers may need to extract data from legacy systems or business-intelligence tools)
- Aggregate data received and anonymise at the carrier-group level (don't publish individual carrier figures without permission); validate completeness and reasonableness with CER

**Access Difficulty**: Hard. Missed-connection data is proprietary business information that carriers typically do not share publicly (competitive sensitivity). Access requires direct carrier engagement via CER, confidentiality agreements and data-protection protocols. Some data may be held in legacy systems that are difficult to query. Smaller carriers may lack systematic incident tracking. Estimate 4-8 weeks to obtain data from all 5-6 carriers; risk of incomplete or non-standardised reporting.

**Essential Information**:

- Historical monthly missed-connection incident counts per carrier pair and corridor for the 24-month period September 2024 to September 2026, segmented by severity (stranded <1 hour, 1–4 hours, >4 hours).
- Cost per incident: rerouting expenses, accommodation and meal allowances, passenger compensation claims paid, and total cost distribution by incident type.
- Seasonal patterns, daily clustering and any systemic correlations between specific corridor pairs, train services or weather conditions and missed-connection frequency.
- Carrier-specific on-time performance metrics (12-month trailing average) to calibrate the contribution-weighting formula for the guarantee pool.
- Data quality assessment: completeness of incident reporting, any gaps in legacy-system records, and confidence intervals for smaller carriers with fewer incidents.
- Anonymised incident logs or aggregated tables suitable for actuarial modelling without exposing commercially sensitive individual-carrier figures.

**Risks of Poor Quality**:

- Incomplete or non-standardised data (e.g., missing incident severity classification or cost breakdowns) forces the actuary to make conservative assumptions, inflating the calculated pool contributions and deterring carrier participation.
- Outdated data (older than September 2024) does not reflect current operational practices, route changes or demand patterns, risking the liability model's relevance by Month 30 (2029-04-12) when carriers operate under it.
- Aggregated-only data without incident-level granularity prevents the actuary from identifying clustering patterns (e.g., specific troublesome corridor pairs) that justify tiered contribution rules, leading to cross-subsidies between carriers and recriminations.
- Data from only large carriers omits smaller-operator risk profiles, creating a model that either overcharges them (deterring participation) or underestimates system-wide loss rates.
- Missing or inconsistent cost allocation (e.g., rerouting costs attributed to the wrong carrier) invalidates the per-incident cap estimates and the co-insurance threshold, potentially leaving the pool under-capitalised or over-reserved.

**Worst Case Scenario**: The actuarial study (scheduled Month 6 = 2027-04-12) cannot be completed with confidence because requested carriers submit incomplete, incomparable or confidentiality-restricted data. The actuary is forced to extrapolate from publicly available passenger-complaint statistics or simplified estimates, producing liability parameters (caps and co-insurance thresholds) that carriers view as arbitrary. By Month 4 (2027-02-12), when carrier sign-off is required, 30–40% of major carriers refuse to commit inventory exposure under unpriceable terms. The programme loses momentum; binding standards milestone (Month 18 = 2028-04-12) is delayed 2–4 months. The 40% through-ticket goal becomes unachievable, settling at 15–25% (estimate). Budget allocated for TEN-T extension (Months 48–60 = 2030-10-12 to 2031-10-12) is reallocated to smaller-carrier adapters, compressing the full-network rollout to Month 72 (2032-10-12) or beyond.

**Best Case Scenario**: By Month 2 (2026-12-12), all contacted carriers provide 24-month rolling data in standardised format with full cost and incident detail. The actuary completes the study by Month 3 (2027-01-12) with high confidence, identifying carrier-specific risk profiles and corridor-pair clusters. A draft liability model with per-incident caps (e.g., EUR 500–1,000) and co-insurance threshold (e.g., EUR 50M annual draw) is published by Month 3 (2027-01-12). CER and 8+ major carriers sign off by Month 4 (2027-02-12), validating the carriers' ability to price exposure. The binding vote passes 75% supermajority in Month 6 (2027-04-12). Confidence in the liability model unlocks carrier inventory exposure by Month 18 (2028-04-12), enabling the mandatory API exposure milestone (Month 30 = 2029-04-12) to proceed on schedule. The four-corridor through-ticketing launch (Month 48 = 2030-10-12) reaches the full target network by Month 60 (2031-10-12), supporting the 40% through-ticket goal.

**Fallback Alternative Approaches**:

- If carriers decline to share historical incident data directly, request aggregated statistics from national railway-accident investigation bodies (ERAs) or the EU Agency for Railways, which may hold regulatory incident reports; this introduces a 2–4 week delay and possible data gaps for commercial rerouting costs not captured in official investigations.
- Engage a third-party insurance broker or reinsurer (e.g., Munich Re, Swiss Re) that underwrites railway liability; they hold proprietary loss-ratio data and can model missed-connection risk; this trades carrier confidentiality concerns for expert external modelling (cost estimate EUR 200–400k).
- Conduct a time-bounded shadow data-collection pilot (3–4 weeks) on one corridor (e.g., Brussels–Amsterdam–Köln) with 3–4 carriers, measure live missed-connection incidents and costs in parallel, and extrapolate to the full network if data patterns are similar; this validates model assumptions at lower confidentiality risk.
- Commission an independent actuarial consultant to conduct confidential bilateral interviews with each carrier's finance and operations teams to extract cost and frequency estimates in narrative form, then reconstruct numerical distributions; this is slower (4–6 weeks) but may access data carriers do not share in writing.
- If Month 3 (2027-01-12) data is still incomplete, adopt a conservative precautionary model: set the per-incident cap lower (e.g., EUR 300–500 instead of EUR 500–1,000) and the co-insurance threshold higher (e.g., EUR 75M instead of EUR 50M), acceptably burdening carriers now to avoid actuarial surprises later; defer the refined model to Month 12 (2027-10-12) and adjust contributions retroactively.

## Find Document 3: Existing EU and Member-State Rail Passenger-Rights Regulations and Enforcement Data

**ID**: 3eb00878-f735-4718-9368-9e93bf0f13c9

**Description**: The full text of EU Regulation 1371/2007 (railway passengers' rights) and any amendments (Regulation 2023/123, etc.), plus national implementing regulations and enforcement data (complaints by category, compensation paid, unresolved cases) from national regulators in France, Germany, Austria, Spain and other member states. Used to establish the baseline rights that through-ticket passengers must maintain and to model potential compensation liability. Intended audience for analysis: passenger-rights counsel, Programme Director, EU Agency for Railways.

**Recency Requirement**: Current regulations as of project start (October 2026). Must include EU Regulation 1371/2007 as currently in force, any recent amendments (2023 or later), and national enforcement data from 2024-2026 if available.

**Responsible Role Type**: Passenger Rights, Accessibility & Consumer Protection Lead

**Steps to Find**:

- Download EU Regulation 1371/2007 and all amendments from EUR-Lex (https://eur-lex.europa.eu/); search for 'Regulation 1371/2007'
- Download Regulation 2023/123 (recent amendment, if applicable) from EUR-Lex
- Contact national railway regulators (or passenger ombudsmen) in France (DGAC/DGITM), Germany (EBA), Austria (ÖBB regulator), Spain (Comisión Nacional de los Mercados y la Competencia) requesting annual enforcement reports or complaints statistics for 2024-2026
- Request a copy of any high-level enforcement guidance or case-law summaries from national regulators
- Search EU Agency for Railways website for any published enforcement statistics or guidance on passenger-rights harmonisation

**Access Difficulty**: Easy. EU regulations are freely published on EUR-Lex. National enforcement data is typically public (annual reports) but may require direct contact with national regulators; some member states publish enforcement data in native language only. Estimate 1-2 weeks to obtain all core documents.

**Essential Information**:

- Full text of EU Regulation 1371/2007 (railway passengers' rights) and all amendments (Regulation 2023/123 and others) as currently in force at project start (October 2026).
- National implementing regulations from France, Germany, Austria, Spain and other participating member states that transpose the EU passenger-rights directive.
- Annual enforcement data from national railway regulators (2024–2026): complaints by category (missed connections, compensation delays, accessibility failures, refund disputes), compensation amounts paid, average resolution time, unresolved cases and appeals.
- Baseline rights that through-ticket passengers must maintain: continuity of journey, refund rules, compensation thresholds, assistance for persons with reduced mobility, and liability for carrier failures.
- Identification of gaps or conflicts between Regulation 1371/2007 and the programme's proposed Through-Ticket Liability and Rights Backstop design (Decision 1) to ensure no passenger rights are reduced.
- Case law or regulatory guidance from national courts or regulators on passenger-rights disputes, particularly on missed connections and rerouting liability across carriers.
- Any recent enforcement actions or penalties issued by national regulators against carriers for passenger-rights violations, to inform the liability model's per-incident caps.

**Risks of Poor Quality**:

- If the baseline rights are misunderstood or incompletely captured, the Through-Ticket Liability and Rights Backstop design (Decision 1) may fall short of Regulation 1371/2007 requirements, exposing the programme to regulatory enforcement notices and forcing a 3–6 month redesign by Month 6–12 (2027-04-12 to 2027-10-12).
- Incomplete or outdated enforcement data (e.g., missing 2024–2026 figures) prevents the actuarial study (due Month 6 = 2027-04-12) from establishing realistic missed-connection rates and compensation liability, leading to a carrier-funded guarantee pool that is either under-provisioned (forcing pool top-ups from the fixed EUR 1.5 billion budget) or over-provisioned (wasting contingency).
- Gaps in national implementing regulations across member states may allow carriers or national regulators to claim that the programme's uniform clearing or rights design is incompatible with local law, triggering 12–24 month legal disputes per member state and fragmenting corridor coverage.
- If enforcement case law and penalty data are not reviewed, the liability model's per-incident caps (proposed at EUR 500–1,000 per stranded passenger) may be misaligned with actual regulatory expectations, inviting either carrier non-participation (if caps are too high) or regulatory challenge (if caps are too low).

**Worst Case Scenario**: The programme's proposed Through-Ticket Liability and Rights Backstop design conflicts with Regulation 1371/2007 in a material way (e.g., the carrier-funded guarantee pool does not cover all mandatory compensation or restricts passenger recovery rights). This is discovered after binding standards are published (Month 18 = 2028-04-12) or during early carrier pilots (Months 12–18 = 2027-10-12 to 2028-04-12). The EU Agency for Railways or a national regulator issues an enforcement notice requiring rework of the liability rules. The programme must redesign the guarantee pool, clearing mechanism and recourse rules, delaying mandatory API exposure from Month 30 (2029-04-12) to Month 36–42 (2029-10-12 to 2030-04-12). Carriers already participating in pilots withdraw due to revised exposure. The four-corridor go-live slips from Month 48 (2030-10-12) to Month 60–66 (2031-10-12 to 2032-04-12). Through-ticket share is reduced from 40% target to 20–30% (estimate). Estimated cost: EUR 10–20 million in legal and redesign effort, plus 3–6 months calendar delay.

**Best Case Scenario**: The programme obtains a comprehensive, current copy of Regulation 1371/2007, all national implementing regulations and five years of enforcement data (2024–2026) by Month 3 (2027-01-12). Independent legal counsel confirms that the proposed liability backstop and clearing design meet or exceed all mandatory passenger-rights obligations. The liability model's per-incident caps (EUR 500–1,000) are validated against actual regulatory penalty precedent and actuarial missed-connection rates. National regulators are briefed and pre-approve the design by Month 6 (2027-04-12). Binding standards incorporate the validated rights framework without revision. Carriers sign onto the liability model with confidence because maximum exposure is predictable and benchmarked. The programme proceeds to standards publication (Month 18 = 2028-04-12) and API exposure (Month 30 = 2029-04-12) on schedule. Through-ticket pilots confirm rights compliance. Four corridors go live by Month 48 (2030-10-12) and the 40% through-ticket share is achieved by Month 60 (2031-10-12) as planned.

**Fallback Alternative Approaches**:

- If obtaining full national implementing regulations and enforcement data from all member states proves too slow or incomplete by Month 2 (2026-12-12), engage the EU Agency for Railways to publish a consolidated summary of Regulation 1371/2007 obligations and known national variations, supplemented by telephone interviews with national rail regulators. This can be completed by Month 3 (2027-01-12) at lower cost (EUR 0.5–1 million estimate) than a full document collection.
- If enforcement data (complaints, compensation paid, unresolved cases) for 2024–2026 is not available in English or is withheld by national regulators, commission a targeted survey of the largest five carriers asking them to share anonymised missed-connection and compensation data for the past three years. Cross-validate against BEUC and consumer-body complaint logs. Complete by Month 4 (2027-02-12).
- If the independent legal review (due Month 6 = 2027-04-12) identifies a material gap in rights coverage, establish a taskforce of national regulators and passenger-rights counsel to propose a legislative amendment to the programme's Regulation text or a supplementary rights policy document. This can be published alongside binding standards (Month 18 = 2028-04-12) without delaying the standards themselves.
- If a national regulator claims local-law incompatibility with the uniform liability or clearing design, offer a bilateral protocol with that member state that preserves the core through-ticketing mechanism while adding a national-level rights wrapper or claims-handling procedure. Document as a precedent for other member states and seek ERAIL (EU Agency for Railways) endorsement to prevent cascading challenges.

## Find Document 4: Current OSDM Specification (Latest Published Version) and UIC Governance Documentation

**ID**: 4b9ffdeb-44b9-4873-b157-b5e1f7a87be1

**Description**: The latest published version of the UIC Open Sales and Distribution Model (OSDM) specification, including API reference, data models and conformance requirements, plus documentation of the UIC's standards-governance process (change-request procedures, release cadence, conformance-test suite). Used to inform the binding-standards working group's design of OSDM conformance requirements and to understand the existing community's practices and concerns. Intended audience for analysis: standards custodian, carriers' CIOs, distributors.

**Recency Requirement**: Latest published OSDM version as of project start (October 2026). Must be the current stable release used by carrier adopters (likely OSDM 2.x or later); check UIC website for the authoritative version number.

**Responsible Role Type**: Standards & Technical Specification Custodian

**Steps to Find**:

- Visit UIC website (https://uic.org) and search for 'OSDM' or 'Open Sales and Distribution Model'
- Download the latest OSDM specification (likely available as PDF or linked from a GitHub repository)
- Request UIC Passenger Department contact via the UIC website; ask for pointer to: (1) current OSDM version status, (2) change-request process and backlog, (3) reference conformance test suite, (4) list of current adopter carriers and distributors
- If OSDM is hosted on GitHub, clone or download the repository to access specification source, test data and any open issues
- Request access to the UIC's OSDM community mailing list or Slack channel if publicly available

**Access Difficulty**: Easy. OSDM specification is published openly by the UIC. GitHub repository and documentation are public. Community contact is available via the UIC website. Estimate 1 week to obtain all core documents and establish initial contact.

**Essential Information**:

- Identify the current OSDM specification version number and release date as of Month 0 (2026-10-12), confirming it matches the version pinned by the binding-standards deadline (Month 18 = 2028-04-12).
- Detail the UIC's change-request process, including severity tiers (critical, major, minor), review timelines per tier, approval gates and the current backlog of pending requests.
- List all conformance test suites included in the specification: test data, pass/fail criteria, API endpoint contracts, data validation rules and edge cases (e.g. stale inventory, multi-leg queries, refund reversals).
- Document the governance structure that maintains OSDM: who owns change control, how disputes are resolved, release cadence and backward-compatibility guarantees.
- Enumerate all current OSDM adopters by carrier name and distributor name, noting their go-live dates, API maturity levels and any known implementation gaps or deviations from the specification.
- Specify the data models for through-ticket fares, availability queries, booking confirmation, cancellation, refund and liability signalling; confirm these cover the federated clearing and carrier-funded guarantee pool scenarios.
- Define the API contracts for real-time availability updates (streaming or polling), booking-authority confirmation, disruption event notification and settlement data exchange.
- Describe the existing credential and validation formats (barcodes, tokens, digital certificates) and any plans for cross-carrier recognition or hybrid formats.
- List known limitations or gaps in the current specification that the binding-standards working group must address (e.g. multi-modal chaining, accessibility reservations, bilateral vs. federated clearing semantics).
- Provide contact information for the UIC Passenger Department and the OSDM community stewards, and confirm availability of the specification source code on GitHub or an equivalent open repository.

**Risks of Poor Quality**:

- If the specification version is outdated or not current as of Month 0 (2026-10-12), the standards-working group uses stale API contracts and data models, requiring rework at Month 12 (2027-10-12) and delaying binding standards by 2-3 months to Month 20-21 (2028-06-12 to 2028-07-12).
- Incomplete or ambiguous conformance test criteria leave carriers and distributors unsure which implementations pass, leading to integration failures during Tier 1 API exposure (Month 30 = 2029-04-12) and rejection of 20-30% of on-time certification attempts.
- Missing or unclear data models for through-ticket fares, liability signalling and settlement leaves the clearing mechanism (Decision 2) and liability backstop (Decision 1) unimplementable; carriers cannot build the guarantee pool or federated netting layer.
- Lack of documented current adopters and their implementation status obscures which carriers have OSDM-ready systems and which require adapters, invalidating the Conformance Gate and Carrier Onboarding Support tiering (Decision 6) and risking Month 6 (2027-04-12) readiness gate failure.
- Ambiguous or missing governance rules for OSDM change control (Decision 11) leave the standards-working group without authority to resolve disputes, stalling the specification pinning by Month 18 (2028-04-12) and cascading delays to Month 24-30 (2028-10-12 to 2029-04-12).
- Undocumented limitations in credential formats or validation interoperability mean Ticket Validation and Onboard Inspection Interoperability (Decision 13) cannot be implemented by Month 40 (2030-02-12), leaving 20% of corridor vehicles without cross-carrier ticket recognition and eroding passenger trust by 5-10%.
- Missing API contracts for disruption event notification or real-time rerouting prevent Disruption Re-accommodation Choreography (Decision 9) from operating reliably; response times exceed 30-60 minutes and re-accommodation success falls below 80%, triggering regulatory complaints and reducing through-ticket adoption by 10-20%.

**Worst Case Scenario**: The OSDM specification available at Month 0 (2026-10-12) is outdated or incomplete: API contracts lack through-ticket liability signalling, the conformance test suite is vague or missing edge cases (multi-leg stale inventory, refund reversals), and the governance structure is undocumented. The standards-working group discovers these gaps at Month 12 (2027-10-12) during conformance protocol drafting, requiring 4-6 months of rework. Binding standards slip from Month 18 (2028-04-12) to Month 22-24 (2028-08-12 to 2028-10-12), pushing mandatory API exposure from Month 30 (2029-04-12) to Month 36-42 (2029-10-12 to 2030-04-12). Tier 1 carriers miss the Month 30 (2029-04-12) milestone by 2-3 quarters, and the network remains fragmented until Month 48-54 (2030-10-12 to 2031-04-12), reducing through-ticket share from the 40% target to 20-25%. Budget reallocation to accelerate conformance testing and rework consumes EUR 50-100M (estimate), leaving EUR 85M headroom insufficient to cover Tier 2-3 adapter overruns. The programme's credibility with carriers and regulators is damaged; the Court of Auditors questions oversight and management quality.

**Best Case Scenario**: The OSDM specification is current, comprehensive and well-documented as of Month 0 (2026-10-12), with full API contracts for through-ticket fares, liability signalling, settlement data and disruption events, a clear conformance test suite and active documentation of all current adopters' maturity levels. The standards-working group uses the specification as a stable foundation, pinning it by Month 18 (2028-04-12) with minimal rework. Tier 1 carriers (approximately 12-15 operators) achieve conformance certification by Month 30 (2029-04-12) on schedule; Tier 2 and Tier 3 cascades follow at Months 36 and 42 (2029-10-12 and 2030-04-12). The four priority corridors deliver live through-ticketing by Month 48 (2030-10-12), reaching approximately 30% through-ticket penetration by Month 54 (2031-04-12) and close to the 40% target by Month 60 (2031-10-12). Carriers and distributors integrate with confidence; the conformance gate operates efficiently and SLA penalties apply to underperformers without surprises. The TEN-T extension wave (Months 48-60 = 2030-10-12 to 2031-10-12) proceeds on budget, and programme costs stay within the EUR 1,500M cap with EUR 100M+ headroom preserved for contingency.

**Fallback Alternative Approaches**:

- If the current OSDM specification is incomplete or misaligned with the programme's needs (federated clearing, through-ticket liability signalling, multi-modal chaining), commission the UIC Passenger Department or a contracted standards body to produce a specification supplement by Month 6 (2027-04-12) covering the gaps, with fast-track review by DG MOVE before Month 12 (2027-10-12). Cost estimate: EUR 2-5M.
- If the OSDM governance structure is unclear or the UIC's change-control process is too slow (>6 weeks per request), establish an interim EU Specification Custodian working group at the EU Agency for Railways (Decision 11) that mirrors the UIC process but publishes a pinned version by Month 18 (2028-04-12) with a 2-3 week fast-track for critical fixes. Requires legislative authorization in the Regulation.
- If current OSDM adopters' implementation status is undocumented, run a rapid 4-week survey (Month 1-2 = 2026-11-12 to 2026-12-12) of CER member carriers, Trainline and Omio to benchmark which systems are production-ready and which require adapters, informing the technical audit (Risk 2) and tiering (Decision 6).
- If the specification lacks edge-case handling (stale inventory in multi-leg queries, refund reversals across carriers, liability signalling), add a conformance test suite enhancement workstream (EUR 5-10M, estimate) led by the Agency and contracted test engineers, deliverable by Month 12 (2027-10-12), before live pilots at Months 12-18 (2027-10-12 to 2028-04-12).
- If OSDM credential formats or validation interoperability cannot be standardized in the current specification, explore a hybrid approach (Decision 13) in which each carrier's native credential remains valid and a second-layer API handshake (e.g. signed JWT or OAuth token) enables cross-carrier verification on gates and handhelds, reducing retrofit scope and fitting within the conformance timeline by Month 30 (2029-04-12).
- If the UIC is unable or unwilling to host the specification maintenance and change control, establish a formal escrow arrangement (Decision 11) in which the specification and all test suites are archived in a neutral open-source repository (e.g. GitHub under an EU-controlled organization) with a public changelog, allowing carriers and distributors to fork if necessary and reducing lock-in risk.

## Find Document 5: Carrier Booking System Architecture Survey Results (From Pre-Programme Technical Audit)

**ID**: 0b58684f-d20a-496d-8589-c8d196fc0248

**Description**: Detailed findings from the pre-programme technical audit of all 25+ participating carriers, including: current API readiness, event-streaming capability, transaction-consistency architecture, latency profiles (p50, p95, p99 percentiles), 12-month uptime %, legacy-system bottlenecks, staff FTE available for integration, and estimated retrofit cost per operator. Used to tier carriers for conformance timelines (Tiers 1, 2, 3) and to design shared adapter modules. Intended audience for analysis: carrier integration manager, programme management, finance lead.

**Recency Requirement**: Current as of Month 2 (2026-12-12) (completion of the pre-programme technical audit). Data must reflect carriers' systems state in Q3/Q4 2026 (baseline), not historical data from prior years.

**Responsible Role Type**: Carrier Integration & Technical Onboarding Manager

**Steps to Find**:

- Contract an independent technical audit firm by Month 1 (2026-11-12) to conduct the audit; specify delivery Month 2 (2026-12-12)
- Audit firm issues technical assessment questionnaire to all 25+ carriers by Month 1 (2026-11-12), requesting: API status (current, under development, legacy), event-streaming capability (Kafka, REST polling, custom), latency profiles (p95 percentile for three-leg queries), annual uptime data (12-month history), legacy-system details and staff availability
- Audit firm conducts on-site or remote system reviews (30+ carrier days total) Months 1-2 (2026-11-12 to 2026-12-12)
- Audit firm publishes draft findings and tier recommendations by Month 2 (2026-12-12) end
- Receive final audit report from firm including: detailed per-carrier assessments, tier assignments, roadmap timelines, shared-adapter recommendations, cost estimates per carrier

**Access Difficulty**: Medium. Carriers will be contractually obligated (as participants in the programme) to provide system-architecture data via the audit process. Smaller carriers or those with legacy systems may have limited documentation and require in-person site visits to validate information. Estimate 4-6 weeks for a full 25+ carrier audit; timing is critical to inform tier assignment by Month 6 (2027-04-12).

**Essential Information**:

- Detailed current-state assessment of all 25+ participating carriers' booking-system architectures, including API readiness level (none, planned, partial, or full), event-streaming technology (Kafka, REST polling, custom, or none), transaction-consistency model, and latency percentiles (p50, p95, p99) for single and three-leg queries.
- Measured 12-month uptime percentage and outage frequency (count and duration) for each carrier's booking engine, baseline from Q3/Q4 2026 (Month 0–2 = 2026-10-12 to 2026-12-12) operations.
- Legacy-system bottleneck identification per carrier: incompatible protocols, data-format gaps, insufficient API throughput, missing event-stream capability, and estimated effort in FTE-months to retrofit.
- Staff FTE availability and integration-team maturity per carrier: number of engineers, OSDM experience level, bandwidth for concurrent integration work during Months 6–30 (2027-04-12 to 2029-04-12).
- Retrofit cost estimate per carrier, broken down by shared-adapter usage (applicable to Tier 2/3) versus bespoke integration, with confidence intervals (±20%).
- Tier assignment recommendation for each carrier (Tier 1 by Month 30 = 2029-04-12, Tier 2 by Month 36 = 2029-10-12, Tier 3 by Month 42 = 2030-04-12) based on API readiness, latency profile, and estimated retrofit timeline.
- Shared-adapter module recommendations: identify three to five common legacy-system patterns and estimate cost and timeline per module (e.g., 'REST-to-Kafka bridge for Polish regional operators', 'transaction-history data mapper for older Deutsche Bahn systems').
- Network-effect risk assessment: identify critical junctions (e.g., Köln, Munich, Vienna) and note which carriers serve them; flag if any Tier 1 carrier is missing, which would fragment a priority corridor.

**Risks of Poor Quality**:

- If latency or uptime data is outdated (>6 months old), the programme misidentifies which carriers meet the availability SLA (p95 <2 seconds, 99.5% uptime) and assigns incorrect tiers, causing 40–50% of smaller carriers to miss the Month 30 (2029-04-12) conformance deadline by 6–12 months.
- If retrofit costs are underestimated by >20%, the EUR 240M adapter budget (EUR 30M shared + EUR 80M Tier 1 + EUR 80M Tier 2 + EUR 50M Tier 3) runs short by EUR 50–100M, forcing either cost overrun (reducing EUR 85M headroom to negative) or deferral of Tier 2/3 to Month 42–48 (2030-04-12 to 2030-10-12), compressing the four-corridor go-live target.
- If the audit does not identify legacy-system bottlenecks clearly, the programme may allocate shared-adapter funding inefficiently (e.g., funding a bespoke integration for a system that could use a standard module), wasting EUR 20–50M.
- If staff availability is not assessed, the programme schedules carrier integration work that exceeds available capacity, causing cascading delays and re-scheduling conflicts across multiple carriers, particularly Months 12–24 (2027-10-12 to 2028-10-12).
- If critical-corridor bottlenecks are not identified, a priority corridor may proceed with an incomplete carrier set, later requiring emergency retrofits or rerouting of through-tickets, adding cost and delay.

**Worst Case Scenario**: The pre-programme audit is conducted with outdated or self-reported data (not validated on-site), resulting in systematic underestimation of latency profiles and retrofit costs across 15–20 smaller operators. The programme assigns these carriers to Tier 1 (Month 30 = 2029-04-12 deadline) based on overstated API readiness. When integration begins in Month 12 (2027-10-12), 10–15 carriers discover their systems require 12–18 months of work, not the assumed 6–9 months. They slip to Month 36–42 (2029-10-12 to 2030-04-12) or drop out entirely. A critical corridor (e.g., Paris–Brussels–Amsterdam–Köln) loses 3–4 regional operators at border junctions, fragmenting through-ticket continuity. The programme faces a choice: accelerate adapters at EUR 150–250M overrun (consuming the EUR 85M headroom and drawing EUR 65–165M from later-corridor budgets), or delay four-corridor go-live from Month 48 (2030-10-12) to Month 60–66 (2031-10-12 to 2032-04-12), reducing the 40% through-ticket target to 20–25% and cutting the full TEN-T rollout to Month 72–84 (2032-10-12 to 2033-10-12). The programme's reputational and budgetary credibility with carriers and the Commission is damaged.

**Best Case Scenario**: The pre-programme audit is completed on schedule by Month 2 (2026-12-12) with on-site system reviews of all 25+ carriers, validated latency data (including three-leg query profiles), and detailed retrofit cost estimates (±10% confidence). Tier assignment is finalized by Month 6 (2027-04-12), with 12 large/corridor-critical carriers assigned to Tier 1 (feasible by Month 30 = 2029-04-12), 8–10 regional carriers to Tier 2 (Month 36 = 2029-10-12), and 5–8 small/legacy-system carriers to Tier 3 (Month 42 = 2030-04-12). Three to five shared-adapter modules are identified and procured by Month 12 (2027-10-12), reducing bespoke-integration costs by EUR 40–60M and freeing budget for contingency. Tier 1 carriers integrate confidently, meeting conformance by Month 30 (2029-04-12) with <5% latency overruns. The audit identifies that critical junctions (Köln, Munich, Vienna) are served by committed Tier 1 carriers, so corridor continuity is confirmed. Four priority corridors go live by Month 48 (2030-10-12) on schedule, with 90%+ of expected carriers operational, supporting the 40% through-ticket target. The EUR 240M adapter budget is spent efficiently, remaining headroom allows for any force-majeure contingencies, and the TEN-T extension (Months 48–60 = 2030-10-12 to 2031-10-12) proceeds as planned.

**Fallback Alternative Approaches**:

- If the independent audit firm cannot be engaged by Month 1 (2026-11-12) or the audit timeline slips beyond Month 2 (2026-12-12), initiate a lightweight self-assessment process: issue a standardised questionnaire to all carriers by Month 1 (2026-11-12) requesting API readiness, latency (self-reported with caveats), and retrofit cost estimates; hold targeted videoconference reviews with the largest 12 carriers (Tier 1 candidates) in Month 2 (2026-12-12) to validate critical data; and publish a provisional tier assignment by Month 9 (2027-07-12) with a caveat that Tier 2/3 assignments are advisory pending real integration results.
- If latency and uptime data cannot be obtained from carriers' historical logs, establish a live measurement campaign: deploy passive network monitors or integrate lightweight telemetry into the conformance test environments (Months 12–18 = 2027-10-12 to 2028-04-12); measure actual latency for sample itineraries; and re-baseline tier assignments by Month 24 (2028-10-12) before funding tranches are released.
- If retrofit costs are uncertain (confidence >±30%), contract a smaller pilot audit with 8–10 representative carriers covering each system category (large incumbent, regional, legacy, cloud-native) by Month 3 (2027-01-12); model cost ranges per category; and apply category-based estimates to unaudited carriers, with explicit risk bands per tier.
- If staff availability cannot be assessed accurately, require carriers to commit capacity in writing as a precondition of funding eligibility (Milestone-Conditioned Funding Release Ladder decision): carriers must submit an integration plan with named FTE assignments and delivery milestones by Month 9 (2027-07-12); funding tranches are released only on proof of staff assignment; this shifts the burden and visibility to carriers and reduces programme risk.
- If a critical-corridor bottleneck is identified late (Month 12 = 2027-10-12 or later), trigger an emergency escalation to the steering group and DG MOVE: convene a task force to either (a) accelerate the at-risk carrier's retrofit by adding EUR 10–20M and external contractor support, (b) identify an alternative carrier service that can close the gap, or (c) redesign the corridor itinerary to exclude the bottleneck, with passenger communication and fare adjustment; decisions must be made by Month 18 (2028-04-12) to avoid slipping the binding-standards milestone.

## Find Document 6: Existing Inter-Carrier Settlement and Clearing Arrangements in Europe (RSP, Eurail, National Systems)

**ID**: 343094c4-ec57-4e89-ac38-bf366927b8d3

**Description**: Documentation of existing multi-carrier clearing and settlement systems operating in Europe: Rail Settlement Plan (RSB, Great Britain), Eurail/Interrail pooled revenue allocation, Swiss direct-service (NOVA) platform, and any national multi-operator clearing arrangements (Italy, France, Spain). Used as precedent for clearing-design decisions and to identify best practices for netting, reconciliation, dispute resolution and non-discriminatory access. Intended audience for analysis: clearing architect, programme management, competition-law counsel.

**Recency Requirement**: Current operational status as of project start (October 2026). Documentation should reflect how these systems currently operate (2026), including recent changes or modernisation initiatives.

**Responsible Role Type**: Inter-Carrier Clearing & Settlement Systems Architect

**Steps to Find**:

- Visit Rail Settlement Plan website (https://www.rsp.org.uk) and download published operating-rules documents and performance reports
- Contact Rail Delivery Group (RDG) retail/ticketing team and request: RSP operating manual (settlement cycle, netting rules, dispute procedure, retailer access criteria), annual performance reports (volumes, error rates, compliance audits)
- Contact Eurail B.V. (Utrecht) corporate relations and request: operating model documentation for the Eurail pass distribution and revenue-sharing system, carrier participation terms, and franchise agreements (if publicly available)
- Contact Alliance SwissPass or SBB corporate strategy and request: documentation of the Swiss Direct Service (NOVA) platform architecture, operator participation model, fare-composition rules and clearing procedures
- Contact CER (Community of European Railways) and request briefing on any national multi-operator clearing arrangements known to its members (e.g., Italy, France, Spain)

**Access Difficulty**: Medium. RSP documentation is publicly available or obtainable via formal request to RDG. Eurail and Swiss systems are proprietary but operators may share high-level documentation under confidentiality agreements. National systems may be less documented or available only in local languages. Estimate 3-4 weeks to gather overview of all existing systems; full legal documentation may not be accessible without direct business relationships.

**Essential Information**:

- Identify and describe the current operational status (as of Month 0 = October 2026) of at least four multi-carrier rail settlement systems: Rail Settlement Plan (RSP/RSB, Great Britain), Eurail/Interrail pooled revenue model, Swiss Direct Service (NOVA) platform, and any national multi-operator clearing (Italy, France, Spain)
- Document the netting rules, settlement cycle times, reconciliation procedures and error-rate thresholds for each existing system
- For each system, specify: who is the operator/owner; which carriers and distributors participate; what volumes (journeys, revenue) flow annually; what commission or fee structure applies to independent distributors
- Detail the dispute-resolution procedures: how disputes are escalated, what authority settles them, typical resolution times, and penalties for late settlement
- Assess which systems use centralized clearing (one entity receives payment and allocates) versus federated netting (bilateral positions netted without central pooling); identify strengths and failure points of each model
- Document non-discriminatory access criteria: how are new carriers and distributors admitted; what technical or financial prerequisites exist; how are access disputes handled
- Identify and explain any recent modernisation initiatives, API exposures, or technology changes (2024–2026) that affected settlement speed, error rates or participant satisfaction
- For each system, quantify: average settlement cycle time in business days; monthly reconciliation error rate as percentage of transactions or value; participant satisfaction or complaint rates if available

**Risks of Poor Quality**:

- Without concrete operational precedents, the Inter-Carrier Clearing and Single-Payment Settlement decision (Decision 2) lacks evidence for feasibility of federated settlement within 5-business-day cycle and below 0.5% reconciliation error; designers may choose an architecture that fails at scale
- Absence of documented netting rules and dispute procedures from existing systems leaves the programme unable to anticipate reconciliation bottlenecks, leading to longer settlement cycles (10–15 days instead of target 5 days) and higher error rates, which deters distributor participation by 15–20%
- Unknown access criteria from existing systems means the programme cannot replicate working non-discriminatory models; new market entrants face opaque barriers and challenge the programme for unfair exclusion, delaying API exposure and legal certification
- Failure to document why existing systems work (or don't) with certain participant types leaves the programme unable to predict whether smaller carriers will accept the proposed guarantee pool; carrier refusal cascades to inventory exposure delays
- Without baseline operational metrics from existing systems (e.g., how long RSP takes to resolve a refund reversal), the programme over-commits to SLA targets that legacy infrastructure cannot deliver, and pilot results falsify success assumptions in Month 12–18 (2027-10-12 to 2028-04-12)

**Worst Case Scenario**: The programme commits to a federated settlement architecture based on theoretical design rather than operational precedent. At Month 24 (2028-10-12), when pilot carriers attempt live settlement, the reconciliation process takes 3–4 weeks instead of 5 business days because dispute procedures and netting rules were not anchored to proven models. Distributors face cash-flow delays and withdraw participation. The programme is forced to redesign the clearing layer by Month 30 (2029-04-12), delaying mandatory API exposure to Month 36 (2029-10-12) and consuming EUR 50–100M in rework. The binding-standards decision (Month 18 = 2028-04-12) is undermined because the settlement mechanism was not validated against operational reality, and later legal challenges cite inadequate due diligence.

**Best Case Scenario**: The document provides detailed comparison of RSP's proven 5-day settlement cycle and <1% error rate, NOVA's federated netting model, and national systems' access procedures, which allows the clearing architect to design a hybrid that replicates RSP's accuracy within the federated model, avoiding centralization and competition-law risk. The programme's settlement SLAs (5 business days, <0.5% error) are grounded in operational benchmarks rather than speculation. Pilots in Months 12–18 (2027-10-12 to 2028-04-12) validate the design against established precedent. Carriers sign on confidently and the mandatory API exposure milestone (Month 30 = 2029-04-12) is met on schedule.

**Fallback Alternative Approaches**:

- Commission a specialized consultancy (e.g., McKinsey Public Sector, Accenture Rail/Transport) in Month 2 (2026-12-12) to conduct interviews with RSP, CER, Eurail and representatives of at least 3 national operators and deliver a comparative-analysis report by Month 6 (2027-04-12), if direct documentation access proves slow or incomplete
- Conduct a direct technical working group (Month 3–6 = 2027-01-12 to 2027-04-12) with volunteer carriers from RSP participating countries (UK-based operator or RDG representative) and the largest European operators (DB, SNCF, SBB) to review their settlement procedures and best practices in real time, bypassing formal document requests
- Establish a 'Clearing Design Partner' arrangement where one existing system operator (e.g., RSP or Swiss NOVA) grants a limited technical secondment (2–3 months, Month 6–9 = 2027-04-12 to 2027-07-12) to embed one architect in the programme's clearing team to document and transfer operational knowledge directly
- If proprietary barriers prevent access to full documentation, request each existing system operator to sign a bilateral confidentiality agreement (template by Month 2 = 2026-12-12) and share redacted operational manuals and error metrics only; prioritize quantitative metrics (settlement cycle, error rate, dispute resolution time) over commercially sensitive rules
- Pivot the clearing-design decision to include a 6-month live pilot (Month 24–30 = 2028-10-12 to 2029-04-12) using an existing multi-carrier settlement system as the operational backbone, licensing their infrastructure and rules rather than building new, if architectural design alone does not yield sufficient confidence

## Find Document 7: DG COMP Guidance on Article 101 TFEU Exemptions in Transport and Digital Markets

**ID**: 2a0c8909-a183-4458-860b-b0dd5e85de29

**Description**: Published DG COMP guidance and precedent decisions on Article 101 TFEU safe-harbour criteria for shared data, pooled clearing, and joint commercial arrangements in transport and digital markets. Includes: joint-purchasing exemptions, air-transport alliances (IATA), roaming directives, and any recent guidance on digital-platform interoperability (e.g., Digital Markets Act). Used to inform the pre-notification memorandum and clean-team protocol design (Decision 14). Intended audience for analysis: competition-law counsel, Programme Director.

**Recency Requirement**: Current DG COMP guidance and precedents as of project start (October 2026). Must include any updates since the Digital Markets Act (2022-2024) and recent digital-platform precedents.

**Responsible Role Type**: Competition Law & Regulatory Affairs Counsel

**Steps to Find**:

- Search EUR-Lex (https://eur-lex.europa.eu) for DG COMP guidance documents on Article 101 TFEU exemptions; filter by date (2020-2026)
- Visit DG COMP website (https://competition-policy.ec.europa.eu) and search for: 'transport exemption', 'data sharing', 'platform interoperability' or similar keywords
- Request from DG COMP's Transport Unit (contact via the DG website or COMP-REGISTRY@ec.europa.eu): any informal guidance on Article 101 TFEU compatibility of multi-operator clearing and data-sharing arrangements in rail; also request copies of any published decisions or notices on rail-sector alliances or joint ventures
- Retrieve any published case law or decisions relevant to Article 101 TFEU in rail (search EUR-Lex for 'rail' + 'competition')

**Access Difficulty**: Easy. DG COMP guidance is published on EUR-Lex and the DG COMP website. Direct contact with DG COMP Transport Unit requires formal request or engagement of external counsel but is typically accessible. Informal briefings may require establishing the programme's formal engagement with DG COMP via the pre-notification process. Estimate 2-3 weeks to compile existing public guidance.

**Essential Information**:

- DG COMP's published guidance on Article 101 TFEU safe-harbour criteria for joint data-sharing, pooled clearing and commercial arrangements in transport and digital markets.
- Precedent decisions and case law on Article 101 TFEU exemptions in rail transport, air-transport alliances (IATA precedent), roaming directives, and Digital Markets Act application to platform interoperability.
- Current formal pre-notification procedures and timelines for obtaining DG COMP guidance on multi-operator clearing and data-sharing in rail; typical turnaround for guidance letters.
- Conditions and structural requirements for clean-team arrangements that satisfy Article 101 TFEU scrutiny (firewall protocols, data access restrictions, governance separation).
- Any recent or pending Commission decisions on shared-data platforms in transport; application of Article 101 TFEU to real-time availability exchange and settlement netting.
- Specific safe-harbour language applicable to federated settlement, netting and dispute resolution among competing carriers without central price-setting.
- TFEU Article 101(3) exemption conditions (efficiency gains, consumer benefit, indispensability, no restriction of competition) as applied to through-ticketing infrastructure.
- Guidance on permissible scope of carrier data disclosure (fares, inventory, settlement) versus prohibited coordination (price-fixing, market allocation).

**Risks of Poor Quality**:

- Absent or outdated guidance leaves the pre-notification memorandum ungrounded in current DG COMP doctrine; formal review at Month 2 (2026-12-12) may reveal compatibility issues not anticipated, delaying guidance approval.
- Missing precedent decisions on rail-sector joint ventures or alliances result in clean-team protocol design that later triggers competition-law challenge, requiring 6-12 months of rework and EUR 50-100M (estimate) cost.
- Incomplete understanding of TFEU Article 101(3) exemption conditions causes the programme to design a clearing mechanism or data layer that DG COMP views as price coordination or market allocation, forcing restructuring post-investment.
- Failure to identify structural requirements for safe clean-team arrangements (firewall, data access, governance) leaves the clearing function exposed to legal unraveling if a carrier or distributor later challenges coordination.
- Lack of current guidance on Digital Markets Act interaction with regulated transport interoperability creates ambiguity about whether the clearing entity or OSDM standardisation triggers DMA obligations.
- Outdated or incomplete guidance on federated settlement and netting leaves the programme uncertain whether the proposed settlement flows pass Article 101 scrutiny, risking post-launch enforcement action.

**Worst Case Scenario**: DG COMP issues an infringement notice post-Month 24 (2028-10-12) finding that the federated clearing mechanism, data-sharing layer or carrier-funded guarantee pool constitute prohibited price coordination or market allocation under Article 101 TFEU. The programme is forced to restructure or suspend the clearing layer entirely, reverting to bilateral settlement between carriers and distributors. This removes the single-payment mechanism, lengthens settlement cycles from 5 business days to 15-30 days, increases booking errors and reconciliation disputes by 25-50% (estimate), and erodes distributor participation by 20-30% (estimate). The 40% through-ticket target becomes unachievable (realistic outcome 15-25% estimate). Estimated rework cost EUR 50-100M (estimate) and 6-12 month schedule slip, compressing or cancelling the TEN-T extension phase (Months 48-60 = 2030-10-12 to 2031-10-12).

**Best Case Scenario**: DG COMP issues a formal guidance letter by Month 12 (2027-10-12) confirming that the programme's clearing, data-sharing and carrier-funded guarantee pool arrangements satisfy Article 101 TFEU as amended by the clean-team protocol and structured governance. This letter is published and becomes binding precedent, eliminating legal uncertainty for carriers and distributors and encouraging full inventory exposure and participation. A successful clean-team arrangement with firewalls and data access controls becomes a reusable model for future EU transport interoperability programmes. The programme reaches binding standards by Month 18 (2028-04-12) and Tier 1 API exposure by Month 30 (2029-04-12) without legal delays, delivering four corridors by Month 48 (2030-10-12) and advancing toward the 40% through-ticket target.

**Fallback Alternative Approaches**:

- If DG COMP guidance is delayed beyond Month 12 (2027-10-12), commission independent competition-law counsel (not the Commission) to conduct a detailed safe-harbour analysis under Article 101(3) TFEU and issue a formal legal opinion by Month 14 (2027-12-12); present this opinion to DG COMP as part of a formal pre-notification and request expedited review by Month 16 (2028-02-12). This preserves Month 18 (2028-04-12) binding-standards milestone.
- If DG COMP signals fundamental concerns with the federated clearing design, pivot immediately to a fully structural clean-team protocol: appoint an independent trustee to operate the clearing function, restrict data access to settlement-only flows, separate governance from carrier representation, and publish monthly audit reports to DG COMP. Commission a follow-up legal opinion confirming this structure is safe under Article 101(3).
- If Article 101 exposure persists despite clean-team mitigations, redesign the clearing layer as a 'distributed bilateral settlement service': instead of a central netting function, carriers submit settlement feeds to a neutral processor that matches and reconciles without centralising commercially sensitive data. This removes the 'hub-and-spoke' structure that competition authorities scrutinise most closely.
- If guidance from DG COMP becomes unavailable or contradicts the programme's design by Month 14 (2027-12-12), escalate formally to the Commission's Competition Commissioner via DG MOVE and request a structured dialogue with senior DG COMP officials; frame the engagement as a regulated sector exemption (transport interoperability for public benefit) rather than a commercial joint venture. Request a comfort letter or block exemption regulation reference rather than waiting for full guidance.
- If competition-law risk remains unresolved by Month 18 (2028-04-12) and threatens binding standards, defer the federated clearing mechanism and instead mandate that each carrier maintain bilateral clearing agreements with every other carrier on a corridor, netting through a simple automated bilateral matching protocol. This removes central coordination and TFEU Article 101 exposure at the cost of slower settlement and higher administrative burden.
- Engage the EU Agency for Railways in the pre-notification process as an official party: if the programme is executed under formal EU regulatory authority and published standards, DG COMP may grant a categorical exemption under Article 101(3) as serving a public transport objective. This shifts the legal grounding from commercial joint venture to regulatory compliance.

## Find Document 8: Baseline Cross-Border Rail Travel Data and Through-Ticket Market Analysis

**ID**: 426d9b24-0354-441b-a6e0-c63262db384a

**Description**: Current statistical baseline on cross-border rail travel volumes, distribution channels (carrier direct, Trainline, Omio, national operators) and market share per corridor (Paris-Brussels-Amsterdam-Köln, Wien-München-Zürich, Madrid-Barcelona-Lyon, Copenhagen-Hamburg-Berlin). Used to validate the 40% through-ticket target (whether it is ambitious or conservative) and to model the baseline for the halved-complaints metric. Intended audience for analysis: Programme Director, finance lead, market-research team.

**Recency Requirement**: Most recent available year (2025 or early 2026) covering full calendar year or latest rolling 12-month period available. Data must be pre-programme (before October 2026) to establish the true baseline.

**Responsible Role Type**: Regulatory Affairs and Stakeholder Alignment Director

**Steps to Find**:

- Contact Trainline and Omio directly via their corporate-development teams, requesting: market-share data (% of cross-border bookings per corridor, by distributor type) for 2024-2025 and customer-complaint statistics (volumes by category, resolution times)
- Request from CER: industry-level data on total cross-border rail travel volumes per corridor from member carriers (if compiled)
- Contact national statistical offices or transport ministries in France, Germany, Austria and Spain requesting: cross-border rail ridership data (annual counts, breakdown by origin-destination pair), distributor market share if available
- Request from the European Commission's DG MOVE or EUROSTAT: any published statistics on cross-border rail travel volumes or modal split (rail vs. air vs. bus) on European corridors

**Access Difficulty**: Medium. Trainline and Omio are commercial entities with proprietary market-share data; they may share summary statistics under NDA but full data may not be disclosed. CER members (carriers) own operational data but may not share across competitors. National statistical offices provide public statistics but may have limited cross-border detail. Estimate 3-4 weeks to assemble baseline data; some gaps are likely.

**Essential Information**:

- Establish the statistical baseline of cross-border rail travel volumes (annual passengers) per corridor (Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin) for the most recent complete calendar year (2025 or early 2026), to validate whether the 40% through-ticket target is ambitious or conservative.
- Quantify current distributor market share by channel (carrier direct, Trainline, Omio, national operator websites, other) as a percentage of cross-border bookings per corridor, to establish the baseline for measuring distributor complaint reductions and through-ticket adoption.
- Document current distributor complaint volumes (total complaints per corridor, categorised by type: booking errors, validation failures, missed-connection handling, refund delays, accessibility gaps) and median resolution times per category, to define the halved-complaints metric.
- Identify which cross-border connections on each priority corridor are currently sold as single through-tickets (if any) and at what volumes, versus stitched itineraries purchased separately, to measure the baseline for the 40% goal.
- Provide the distribution of passenger journey lengths, fare bands and traveller demographics (business, leisure, accessibility needs, cyclists) per corridor to inform through-ticket value proposition and modal-shift modelling.
- List current modal split (percentage of travellers choosing rail, air, bus, car) on the four priority corridors, particularly on air-competitive routes, to establish the baseline for the 5–10% air-to-rail shift planning value.

**Risks of Poor Quality**:

- Inaccurate baseline volumes or market shares lead to overestimation of the 40% through-ticket goal: if actual cross-border travel is 20% lower than forecasted, the absolute number of through-tickets required to reach 40% is smaller, and the programme may be judged on an inflated target, damaging credibility.
- Incomplete complaint data by category (e.g., missing validation or accessibility complaints) hides the true complaint burden and allows the halved-complaints metric to be gamed by reduction in high-volume, low-priority categories; genuine passenger pain points remain unaddressed.
- Absent baseline on current through-ticket sales (if any) makes it impossible to distinguish programme-driven growth from organic market shift, inflating the claimed programme impact and inviting audit scrutiny.
- Inaccurate distributor market-share data prevents realistic modelling of which distributors will participate in the programme and how much of the 40% target depends on Trainline, Omio or smaller players, complicating the concession and commission-band design.
- Poor demographic and journey-length data undermines accessibility and multimodal design, leading to a through-ticket product that does not match traveller needs and fails adoption targets.

**Worst Case Scenario**: The programme is launched with an inflated baseline: actual cross-border travel volumes are 25–30% lower than assumed, and current through-ticket penetration is already 10–15% (not zero). The 40% target becomes effectively 30–40% growth above baseline, not an absolute share. Complaint data is incomplete, missing accessibility and validation categories, so the halved-complaints metric is met by reducing booking-error complaints alone while accessibility complaints double. At Month 48 (2030-10-12), when the four corridors report results, the Court of Auditors finds that claimed through-ticket growth is only 12–15% above baseline, not the 40% implied by the headline metric. The programme is judged as underperforming and funding for the TEN-T extension (Months 48–60 = 2030-10-12 to 2031-10-12) is withheld, halting the rollout at the four priority corridors. Distributor participation falls to 60–70% of target because the original market-share data underestimated Trainline and Omio's bargaining power and overestimated participation by smaller regional players. The 40% goal is missed by 15–20 percentage points and the programme is reported as a failed 1.5 billion EUR public investment.

**Best Case Scenario**: The baseline data establish that cross-border travel on the four corridors totals 45–50 million journeys annually, of which ~4% are currently through-tickets and complaints average 8–12 per 1,000 bookings. The programme's design is calibrated to this reality: a 40% through-ticket target represents roughly 18–20 million journeys by Month 60 (2031-10-12), a 10-fold increase, ambitious but plausible with full carrier participation. Distributor shares are known (e.g., Trainline 35%, Omio 25%, carrier direct 30%, others 10%), informing concession and commission-band design. Complaint baselines per category (booking errors 30%, validation 25%, missed-connection rerouting 20%, refunds 15%, accessibility 10%) guide which pain points the programme prioritises. At Month 48 (2030-10-12), corridor results show 28–32% through-ticket penetration on the four corridors, complaint volumes down 40–50%, and a clear pathway to 40% by Month 60 (2031-10-12). The Court of Auditors and member states validate the baseline, confirm programme progress and approve the TEN-T extension funding, allowing full-network rollout.

**Fallback Alternative Approaches**:

- If Trainline and Omio refuse to share detailed market-share data under NDA, request aggregated competitor intelligence from CER members (each carrier's distributor sales mix) and apply statistical sampling to estimate market share per distributor type without disclosing individual carrier data.
- If national statistical offices cannot provide cross-border corridor-level data, compile the baseline from a combination of CER members' self-reported sales (with proper anonymisation), published annual reports of Trainline and Omio, and transport-authority reports from France, Germany, Austria and Spain; use triangulation to validate consistency.
- If current complaint data is proprietary and scattered across carriers and distributors, commission an independent survey of 2,000–3,000 passengers who have booked cross-border rail in the past 12 months, asking about complaint types and resolution, weighted by corridor and distributor; use this as the baseline and accept a 2–3 week delay to Month 4–6 (2027-02-12 to 2027-04-12).
- If no current through-ticket sales data exists (i.e., the market is fragmentary), assume a near-zero baseline (0–2% through-tickets) and validate via five carrier interviews and one or two distributor pilots to confirm; design the programme on a true-zero assumption and treat any organic growth as upside.
- If air-to-rail modal-shift baseline is unavailable, partner with a transport economics research body (university or research institute) to conduct a stated-preference or revealed-preference study on one air-competitive corridor (e.g., Paris–Lyon–Marseille or Berlin–Munich) by Month 9 (2027-07-12), using the results to inform the full-programme modal-shift modelling.

## Find Document 9: EU Member-State Railway Regulator Contact List and Regulatory Frameworks (France, Germany, Austria, Spain, etc.)

**ID**: b0a475b7-211c-471e-8d0b-649f01ef208e

**Description**: Contact information and summary of regulatory authority and remit for railway regulators in all member states participating in the four priority corridors and TEN-T network. Includes: France (DGITM/DGAC), Germany (Bundesnetzagentur), Austria (ÖBB Regulator), Spain (Comisión Nacional), Italy, Netherlands, Belgium, Denmark, Sweden, Poland, etc. Regulatory frameworks covering track access, station capacity, pricing rules, passenger rights and non-discrimination obligations. Used to conduct bilateral regulatory impact assessments (Month 3 = 2027-01-12) and to understand national constraints on mandatory API exposure or data sharing. Intended audience for analysis: regulatory-affairs lead, Programme Director.

**Recency Requirement**: Current as of project start (October 2026). Regulator contact information and organisational structure must be current; regulatory frameworks must reflect current national laws and European directives.

**Responsible Role Type**: Member-State Coordination and National Regulator Liaison Officer

**Steps to Find**:

- Visit the EU Agency for Railways website (https://www.era.europa.eu) and search for 'Member-State Regulators' or 'National Safety Authorities'; compile contact list
- Contact CER and request: list of member-state regulatory contacts and a one-page summary of each regulator's authority, remit and typical concerns on cross-border ticketing or data-sharing projects
- Search the website of each national regulator (typically transport ministry or dedicated transport regulator) to confirm current contact information and download summaries of national railway laws (often in English on EU or English-language versions of national sites)
- Request from DG MOVE: any internal mapping of member-state regulators and known regulatory constraints or precedents affecting cross-border rail initiatives

**Access Difficulty**: Easy. Regulator contact information is publicly available via the EU Agency for Railways and national websites. CER may provide an internal summary. Regulatory frameworks are published by national authorities (often in national language, but English summaries or abstracts may be available). Estimate 2-3 weeks to compile complete list.

**Essential Information**:

- Contact name, email, phone and office address for the chief regulator or designated liaison officer in each of the 25+ participating member states' railway regulatory authorities (France DGITM, Germany BNetzA, Austria ÖBB Regulator, Spain Comisión Nacional, Italy, Netherlands, Belgium, Denmark, Sweden, Poland, etc.)
- Current regulatory authority name, acronym and organisational structure for each member state (confirm current legal entity after any recent mergers or restructures post-October 2026)
- Documented summary of each regulator's statutory remit: track access authority, capacity allocation, pricing approval, passenger-rights enforcement, safety oversight, or hybrid model
- Known regulatory constraints or precedents in each member state affecting cross-border rail initiatives: national exemptions, domestic-operator protections, data-sharing restrictions, mandatory-disclosure blocks
- Typical approval timelines and formal notification procedures per regulator for projects involving mandatory API exposure, real-time data sharing, or inter-carrier settlement
- Published national railway law summaries or English-language abstracts confirming how each member state's law aligns with or deviates from EU Regulation 1371/2007 and the proposed Digital Booking Regulation
- List of recent cross-border rail coordination projects or initiatives in each member state, with identified regulatory bottlenecks or successes to inform bilateral engagement strategy

**Risks of Poor Quality**:

- Outdated contact information delays bilateral regulatory impact assessments (Month 3 = 2027-01-12 milestone) by 4–8 weeks; regulators not reached in time to influence standards scope
- Incomplete regulatory-authority mapping misses smaller or recently reorganised regulators, leaving compliance gaps in secondary corridors and creating unexpected regulatory veto or fines during implementation
- Inaccurate description of regulator remit (e.g., confusing track-access vs. pricing authority) leads to binding negotiations with the wrong authority, wasting 2–3 months and forcing restart
- Undocumented national constraints (e.g., a member state's ban on real-time data sharing for competition reasons) discovered after Month 6 (2027-04-12) requires standards redesign and delay of 3–6 months
- Missing regulatory precedents on inter-carrier coordination leaves the programme unprepared for known objections; regulators cite past cases as grounds to block mandatory API exposure
- Absence of translated or English-language regulatory summaries forces external legal counsel to translate full national laws, adding EUR 50–100K cost and 6–8 week delay per member state
- No record of approval timelines per regulator causes the programme to miss informal comment windows, forcing formal appeals or re-notification cycles that add 3–6 months per member state

**Worst Case Scenario**: 
A regulator is reached too late or with incomplete information, blocks mandatory API exposure citing undocumented national law or unaddressed precedents. The programme cannot defer that regulator's compliance: binding standards require all 25+ participating member states to accept the design. Discovery of the block after Month 12 (2027-10-12) forces a 4–6 month legal and regulatory reworking cycle. One major corridor (e.g., Wien–München–Zürich) loses its Austrian or German regulator's approval, fragmenting through-ticket availability across a critical node. Estimated impact: EUR 30–50 million in legal and rework costs, 6–12 month delay to binding standards (Month 18 = 2028-04-12 → Month 24–30 = 2028-10-12 to 2029-04-12), loss of 2–3 priority corridors from scope, and reduction of through-ticket goal from 40% to 20–25%.


**Best Case Scenario**: 
By Month 3 (2027-01-12), the programme conducts bilateral impact assessments with all 25+ regulators using a current, detailed contact list and documented regulatory frameworks. Early engagement surfaces known constraints (e.g., data-sharing restrictions in specific member states) before binding standards are drafted. The programme designs the standards with known workarounds or national carve-outs that each regulator can approve by Month 9 (2027-07-12). Binding standards are adopted on time (Month 18 = 2028-04-12) with all regulators' written consent. Mandatory API exposure proceeds without post-hoc regulatory challenges. Estimated benefit: on-time binding standards, no unexpected legal rework, reduced risk of corridor fragmentation, and preservation of the 40% through-ticket goal within the five-year horizon.


**Fallback Alternative Approaches**:

- If current regulator contact list is unavailable: Contact the EU Agency for Railways directly (Valenciennes) and request their internal master list of member-state regulators, typically maintained for cross-border safety and coordination matters. Expect 2–3 week response.
- If individual regulator websites lack English-language summaries: Engage CER (Community of European Railways) to provide one-page English regulatory briefs for each member state based on their bilateral relationships; cost estimate EUR 20–30K, timeline 4–6 weeks.
- If regulatory-authority structures have recently changed (post-October 2026): Commission a targeted research report from a transport law firm specialising in EU rail (e.g., Freshfields, CMS, Linklaters) to audit current regulator structures and remits; cost EUR 50–75K, timeline 6–8 weeks.
- If approval timelines and precedents are undocumented: Conduct structured interviews with 2–3 major regulators (e.g., Germany BNetzA, France DGITM) to establish typical notification windows and decision cycles; resource 1 FTE for 4 weeks to coordinate, cost EUR 30–40K in staff and travel.
- If bilateral engagement must start before the contact list is complete: DG MOVE issues a formal regulatory notification letter (template by Month 2 = 2026-12-12) to all member states' transport ministries, with request to designate and confirm the relevant railway regulator contact within 2 weeks; this creates an official channel while the detailed list is being compiled.
- If a regulator is unresponsive or missing from EU Agency records: Escalate through the national transport minister (DG MOVE already maintains minister contacts) or the national competition authority (many regulate rail access); this ensures no regulator is overlooked.

## Find Document 10: EU Accessibility Directive and Persons with Reduced Mobility (PRM) Accessibility Standards

**ID**: 67de31d0-fd2a-4d93-94aa-abec25957e7a

**Description**: EU Directive 2019/882 (European Accessibility Act) and any transport-specific accessibility regulations (EU Regulation 1371/2007 PRM provisions, EN 13001-1 station accessibility standards). Used to define accessible booking and payment flows, assist-request handling and ticket validation for persons with reduced mobility. Intended audience for analysis: accessibility lead, programme management, carriers.

**Recency Requirement**: Current EU accessibility regulations as of project start (October 2026). Must include the latest version of the European Accessibility Act and any recent amendments.

**Responsible Role Type**: Passenger Rights, Accessibility & Consumer Protection Lead

**Steps to Find**:

- Download EU Directive 2019/882 (European Accessibility Act) from EUR-Lex
- Download EU Regulation 1371/2007 Persons with Reduced Mobility (PRM) provisions from EUR-Lex
- Request from the EU Agency for Railways: any published guidance on accessibility requirements for digital rail services or ticketing systems
- Request from disability-rights organisations (EBU, European Disability Forum) or national DPOs: any accessibility checklists or best-practice guidance for transport booking platforms

**Access Difficulty**: Easy. EU directives and regulations are published on EUR-Lex. Agency guidance is publicly available. Disability-rights organisations' guidance may require direct contact but is typically shared as best-practice resources. Estimate 1-2 weeks.

**Essential Information**:

- Identify the current provisions of EU Directive 2019/882 (European Accessibility Act) that apply to digital ticketing and booking platforms for rail transport, including WCAG 2.1 conformance levels mandated.
- List specific PRM accessibility requirements from EU Regulation 1371/2007 Articles 20-25 covering assistance notification procedures, advance notice windows, and carrier obligations for persons with reduced mobility.
- Detail the technical standards (EN 13001-1 or successor) for station accessibility infrastructure that affect through-ticket usability, including ramp gradients, assistance provision points and evacuation procedures.
- Specify the notice period required for advance PRM assistance requests under current EU law and any member-state variations that create compliance gaps for the programme's atomic-confirmation model.
- Quantify the minimum percentage of rail services that must offer wheelchair-accessible spaces and assistance capability to satisfy the Accessibility Directive on a pan-European basis (not carrier-by-carrier).
- Define the explicit accessibility compliance checklist for the programme's Assistance and Bicycle Reservation Chaining decision, cross-referenced to binding legal obligations and the 'best-effort' fallback threshold (80% wheelchair access, 90% assistance within 4 hours).
- Identify any recent European Court of Justice rulings or Agency for Railways guidance (post-2024) on accessibility in digital rail services that supersede or clarify the 2019 Directive.

**Risks of Poor Quality**:

- Incomplete coverage of Regulation 1371/2007 PRM provisions: if the document omits notice-period requirements or exclusion rules, the programme's atomic-confirmation design may inadvertently violate passenger rights, creating legal exposure at the Month 36 (2029-10-12) conformance gate.
- Misalignment between the programme's 'best-effort' fallback (carriers unable to meet 80%/90% thresholds) and existing EU law: if the fallback contradicts Regulation 1371/2007 or the Accessibility Directive, the Agency for Railways may reject the compliance manual at Month 9 (2027-07-12), delaying carrier conformance.
- Outdated or partial technical standards: if EN 13001-1 has been superseded or regional accessibility standards vary per member state, the programme risks issuing non-compliant station designs, which cannot be corrected within the EUR 200M capacity-building budget.
- Missing member-state variations: if the document does not flag differences (e.g., notice periods in Germany vs. Spain, station staffing obligations), the programme's one-size-fits-all assistance-booking workflow will fail in jurisdictions with stricter local rules, fragmenting corridor coverage.
- Vague accessibility metrics: if the document does not define 'wheelchair accessible' or 'assistance availability' quantitatively (% of vehicles, time response), the Assistance and Bicycle Reservation Chaining decision cannot establish measurable conformance gates, making the Month 40 (2030-02-12) audit non-verifiable.

**Worst Case Scenario**: The programme issues a compliance manual at Month 9 (2027-07-12) that conflicts with undisclosed EU Regulation 1371/2007 PRM provisions or member-state accessibility laws. A disability-rights body challenges the atomic-confirmation model in the European Court of Justice, alleging that 'best-effort' bookings violate the Accessibility Directive and Regulation 1371/2007. The case enters litigation by Month 24 (2028-10-12), requiring a 6-9 month redesign of the Assistance and Bicycle Reservation Chaining decision (EUR 15-25M cost, estimate). Carriers withdraw from accessibility commitments, reducing service availability and creating political pressure for the programme to either drop the accessibility scope or extend the mandate to Months 72-84 (2032-10-12 to 2033-10-12). The programme's reputation for disability inclusion is damaged, deterring other EU transport initiatives from adopting similar standards.

**Best Case Scenario**: A comprehensive, current accessibility standards document provides clear technical and legal baselines for the Assistance and Bicycle Reservation Chaining decision. The programme's compliance manual at Month 9 (2027-07-12) aligns with all PRM provisions, member-state variations and technical standards, securing sign-off from disability-rights bodies and the Agency for Railways without revision. Carriers meet the 80% wheelchair and 90% assistance thresholds by Month 40 (2030-02-12), making accessible through-ticketing a standard offering rather than a best-effort fallback. The programme becomes a model for accessible EU transport standards, earning endorsement from the European Disability Forum and integration into future TEN-T and multimodal initiatives, expanding the through-ticket goal to include dedicated accessible products and positioning the EU as a leader in inclusive transport.

**Fallback Alternative Approaches**:

- Commission an independent accessibility legal opinion from a EU-accredited accessibility consultant or law firm specializing in Regulation 1371/2007 and the European Accessibility Act, to be completed by Month 3 (2027-01-12), in parallel with the planned independent passenger-rights review; cost estimate EUR 30-50K.
- Request formal guidance from the EU Agency for Railways on the compliance status of the programme's atomic-confirmation and best-effort models against Regulation 1371/2007, with written response by Month 6 (2027-04-12); include disability-rights bodies (EBU, European Disability Forum) as co-reviewers.
- Conduct targeted usability testing with persons with reduced mobility (wheelchair users, visually impaired, deaf-blind passengers) on the programme's prototype booking interface by Month 15 (2028-01-12), using WCAG 2.1 AA conformance as the baseline; recruit 20-30 test participants per member state of a priority corridor.
- Establish a standing accessibility advisory panel (3-5 disability-rights representatives) to review each conformance tier (Months 30, 36, 42 = 2029-04-12, 2029-10-12, 2030-04-12) and approve accessibility thresholds; cost estimate EUR 10-15K per review cycle.
- If member-state PRM variations create fragmentation, publish a supplementary guidance document per member state by Month 12 (2027-10-12) showing how the programme's generic accessibility rules map to national law, with carrier sign-off per jurisdiction; cost estimate EUR 50-75K.
- Defer full accessibility conformance to a Phase 2 rollout (Months 60-72 = 2031-10-12 to 2032-10-12) if the standards document reveals insurmountable compliance conflicts; focus Phase 1 (Months 0-48 = 2026-10-12 to 2030-10-12) on accessible information and complaint handling only, not atomic assistance/bicycle confirmation.

## Find Document 11: Current Trainline and Omio Booking Platform Architecture and API Capabilities

**ID**: 2de78274-b57e-416f-8d33-755548246459

**Description**: Technical documentation of Trainline and Omio's current booking-platform architecture (APIs, inventory query methods, payment processing, refund handling), integration with existing carrier systems and compatibility with OSDM standards. Used to validate the federated integration model and to assess whether independent distributors can connect to the shared clearing and real-time layers without extensive custom work. Intended audience for analysis: clearing architect, real-time systems engineer, distributor engagement team.

**Recency Requirement**: Current as of project start (October 2026). Must reflect the platforms' existing technical state and any recent API modernisations or OSDM adoption.

**Responsible Role Type**: Inter-Carrier Clearing & Settlement Systems Architect

**Steps to Find**:

- Contact Trainline and Omio directly via their corporate-development or API-partnership teams, requesting: high-level technical documentation on booking-platform architecture, API endpoints exposed to carrier partners, payment processing and settlement procedures, and any OSDM compliance work underway
- Request test-environment access and API documentation (likely under NDA) to validate integration assumptions
- Inquire whether each distributor has already begun OSDM integration and what technical barriers they have identified

**Access Difficulty**: Medium. Trainline and Omio are commercial platforms with proprietary architectures; they may share summary documentation under NDA but full technical details are business-sensitive. Initial contact likely requires formal programme engagement via the steering group. Estimate 2-4 weeks for preliminary technical briefing; full platform documentation may require formal partnership agreement.

**Essential Information**:

- Trainline's current booking-platform architecture: all APIs, inventory query methods, real-time search endpoints, payment processing workflows and settlement procedures used with carrier partners
- Omio's current booking-platform architecture: all APIs, inventory query methods, real-time search endpoints, payment processing workflows and settlement procedures used with carrier partners
- Which OSDM-compatible APIs or interfaces each platform already exposes or has planned; any pilot or production-grade OSDM adoption
- Current latency profiles (p50, p95, p99 query response times) for single-carrier and multi-carrier (2–3 leg) itinerary searches, measured against proposed SLA targets of p95 <2 seconds
- Current availability/uptime of each platform's booking endpoints and any known outage patterns or seasonal degradation
- Payment processing and currency handling: which currencies and payment methods each platform supports, and how refunds and reversals are handled across carriers
- Settlement cycle times: how long from passenger payment through clearing to final payout to carriers; any reconciliation delays or dispute handling procedures currently in place
- Integration complexity for each platform to connect to a federated netting and dispute-resolution layer: what APIs would need to be built or adapted, estimated effort per platform
- Data format and quality issues: whether each platform's settlement, refund and inventory data can map directly to the shared clearing-layer schemas, or requires custom transformation
- Distributor-carrier contractual terms: which carriers each platform is currently integrated with, any exclusive arrangements, and flexibility to add shared clearing terms
- Commercial viability: estimated percentage of through-ticket volume (vs. single-carrier tickets) each distributor expects to handle, and whether current technology economics support the federated model or require cost changes

**Risks of Poor Quality**:

- Incomplete or outdated platform documentation leads to false assumptions about integration feasibility, resulting in underestimated adapter development effort and cost overruns of EUR 50–100M (estimate) during Month 12–18 (2027-10-12 to 2028-04-12) technical build-out
- Latency and availability data not provided forces reliance on generic benchmarks, masking platform-specific bottlenecks; if either distributor's real p95 latency exceeds the proposed 2-second SLA by >1 second, the federated query model fails for multi-leg journeys and through-ticket search success drops below 70%, eroding the value proposition
- Payment and settlement procedures not validated against the federated clearing schema means custom transformation layers are built post-pilot, consuming 4–8 additional weeks of integration time and delaying the Month 30 (2029-04-12) mandatory API exposure by 2–4 months (estimate)
- Unknown reconciliation error rates or dispute-handling volume in either platform means the shared clearing mechanism cannot be load-tested; if actual error rates exceed 1%, settlement cycles lengthen from 5 to 10–15 business days and distributors may reduce participation by 20–30% (estimate), lowering through-ticket volume by 10–15% (estimate)
- Missing contractual flexibility analysis means the programme cannot determine whether Trainline and Omio can accept shared clearing governance and non-discriminatory access terms; if either platform has exclusive carrier agreements or proprietary settlement rules that conflict with the federated design, the programme loses 15–25% of expected through-ticket distribution capacity (estimate)
- Absence of commercial volume forecasts from each distributor means the programme cannot validate whether the concession or independent distributor participation is economically viable; if volumes are 30–50% lower than forecast, the public budget allocation of EUR 300M for the concession becomes unaffordable relative to other priorities
- Outdated OSDM-integration status leaves the programme unaware whether either platform has already begun standards work; if Trainline or Omio has already committed to a competing or forked API specification, re-alignment to the shared standard becomes a contentious renegotiation delaying binding standards by 2–4 months (estimate)

**Worst Case Scenario**: A critical document gap: If Trainline and Omio's current platform documentation cannot be accessed or is materially outdated (e.g., reflects architecture from 2024 not 2026), the programme proceeds with false assumptions about integration feasibility. The federated clearing model assumes both distributors can accept real-time settlement feeds in a standardised format and participate in a shared dispute-resolution layer; if either platform has technical or contractual incompatibilities (e.g., proprietary settlement logic, exclusive carrier agreements, or latency >3 seconds on multi-leg queries), the programme discovers this only after Month 12 (2027-10-12) pilots, at which point adapting the clearing mechanism or switching to a central exchange model requires 6–12 months of rework and EUR 50–100M additional cost (estimate). This cascades: mandatory API exposure (Month 30 = 2029-04-12) slips to Month 36–42 (2029-10-12 to 2030-04-12), four-corridor go-live (Month 48 = 2030-10-12) pushes to Month 54–60 (2031-04-12 to 2031-10-12), and the 40% through-ticket goal becomes unachievable, settling at 20–25% (estimate). Budget impact: EUR 100–150M of the EUR 85M free headroom is consumed, forcing the TEN-T extension (Months 48–60 = 2030-10-12 to 2031-10-12) to be deferred to Month 72 (2032-10-12) or cancelled, breaking the five-year horizon commitment.

**Best Case Scenario**: Trainline and Omio provide complete, current platform documentation showing APIs compatible with OSDM standards, latency and availability data confirming p95 <2 seconds and 99.5% uptime, and settlement procedures that map directly to the federated clearing schema with <0.5% reconciliation error rates. Both distributors confirm contractual flexibility to accept shared governance terms and non-discriminatory access rules, and forecast 25–35% through-ticket volume penetration on the priority corridors by Month 48 (2030-10-12). This enables: (1) Clearing architect to finalise the federated settlement-layer design by Month 9 (2027-07-12) with high confidence; (2) Real-time systems engineer to baseline integration effort at EUR 30–50M (within the EUR 80M shared adapter budget); (3) Distributor engagement team to secure binding letters of intent by Month 6 (2027-04-12), unlocking the steering group consensus on the Inter-Carrier Clearing decision; (4) Month 12–18 (2027-10-12 to 2028-04-12) pilots to proceed on schedule with both platforms live; (5) Month 30 (2029-04-12) mandatory API exposure to be met by large distributors, increasing confidence in the 40% through-ticket goal and supporting carrier participation decisions.

**Fallback Alternative Approaches**:

- If Trainline and Omio decline to provide proprietary architectural documentation under NDA, request a third-party technical audit: engage an independent systems integrator (e.g., Accenture, Capgemini, Cognizant) with existing Trainline and Omio contracts to conduct a confidential platform assessment and deliver a sanitised summary of integration points, latency profiles and settlement compatibility. Timeline: Month 3–6 (2027-01-12 to 2027-04-12); cost EUR 150–250K (estimate). Risk: summary may not capture all edge cases, requiring confirmation during Month 12–18 (2027-10-12 to 2028-04-12) pilots.
- If either distributor's existing architecture is fundamentally incompatible with federated clearing (e.g., all settlement routed through proprietary bilateral contracts with carriers), negotiate a hybrid integration layer: allow the distributor to maintain proprietary settlement internally but expose a standardised 'clearing API' that maps their settlement to the shared layer's messages. This isolates internal architecture from the programme and preserves commercial flexibility. Timeline: Month 6–12 (2027-04-12 to 2027-10-12); cost EUR 50–80M (estimate for both platforms). Risk: introduces translation layers that may degrade settlement speed by 1–2 business days.
- If latency or availability data from either platform indicates SLA non-compliance (p95 >2 seconds or <99.5% uptime), establish a distributed caching layer (part of the EUR 50M real-time-layer budget) that pre-caches search results and degrades gracefully to cached results for that distributor during endpoint outages. This preserves search availability at the cost of slightly stale seat data (cache refresh every 15–30 minutes, estimate). Timeline: Month 9–12 (2027-07-12 to 2027-10-12); cost EUR 10–20M (estimate). Risk: introduces consistency risk if a passenger books a cached result that has since sold.
- If either distributor cannot commit binding-volume forecasts by Month 6 (2027-04-12), defer their full integration to Phase 2 (Months 18–48 = 2028-04-12 to 2030-10-12) and start with a subset of smaller independents (Trainline, or Omio, or both, whichever provides early commitment). This preserves the timeline and protects EUR 50–80M of clearing budget. Timeline impact: minimal (Month 12–18 = 2027-10-12 to 2028-04-12 pilots use one distributor); volume impact: through-ticket share for Months 30–48 (2029-04-12 to 2030-10-12) is 5–10 percentage points lower (estimate).
- If the programme cannot obtain current architectural documentation by Month 2 (2026-12-12), commission a rapid parallel workstream to design the clearing mechanism and settlement-data formats as a 'platform-agnostic schema' based on OSDM, existing CER clearing standards and ISO 20022 settlement practices. Both distributors would then commit to supporting this schema rather than exposing proprietary internals. Timeline: Month 1–6 (2026-11-12 to 2027-04-12); cost EUR 200–300K (estimate). Risk: increases distributor integration effort if they must build substantial adapters, potentially adding EUR 20–40M to the overall adapter budget.
- If Trainline or Omio is unable to meet the Month 30 (2029-04-12) mandatory API exposure deadline due to legacy system constraints, negotiate a staged participation: Tier 2 (Month 36 = 2029-10-12) or Tier 3 (Month 42 = 2030-04-12) conformance with reduced through-ticket volume expectations for that distributor during Months 30–36 (2029-04-12 to 2029-10-12) or 30–42 (2029-04-12 to 2029-10-12 or 2030-04-12). This preserves full-network coverage while allowing slower distributors to catch up. Timeline impact: through-ticket share for the slower distributor is 5–10 percentage points lower during the gap; budget impact: EUR 10–20M additional clearing-layer maintenance during the transition (estimate).