## Suggestion 1 - OSDM – Open Sales and Distribution Model (UIC / OSJD-independent, with CER and EU-Rail partners)

OSDM is an open API standard for selling rail products across operators, led by the International Union of Railways (UIC) with members such as DB, SBB, ÖBB, SNCF and others. It covers offers, bookings, fulfilment, refunds and exchanges. It has been developed and maintained since about 2020 and is being adopted by several operators and distributors. It is the technical basis named in the programme brief.

### Success Metrics

Live implementations by several operators and distributors (exact count not verified).
Published versioned specification and open documentation.
Reuse of the standard in procurement and EU-level proposals.

### Risks and Challenges Faced

Uneven adoption by carriers: handled by voluntary working groups and published reference implementations, but pace remains slow.
Competing national formats: addressed through mapping to existing UIC and TAP/TSI messages.
No enforcement power: still unresolved; this is where the programme's panel and regulation must add force.

### Where to Find More Information

https://osdm.io
UIC website, OSDM pages: https://uic.org
CER (Community of European Railway and Infrastructure Companies): https://www.cer.be

### Actionable Steps

Contact the OSDM working group via the contact form on osdm.io and ask for the conformance-test approach and governance charter.
Approach UIC's digital/distribution unit (role: OSDM programme manager) for a briefing on adoption data.
Ask CER's passenger/ticketing policy officer for the carriers' view on mandatory API exposure.

### Rationale for Suggestion

Direct technical match: the programme requires OSDM-compatible APIs. The OSDM community shows how a standard is governed, versioned and conformance-tested among competing carriers, which informs the Month 18 (2028-04-08) binding standards and the certification scheme. Geography matches (pan-European, Swiss and EU carriers). It lacks binding enforcement, which the programme adds.
## Suggestion 2 - Alliance SwissPass / Swiss Direct Service (Nationale Direkter Verkehr) clearing

Switzerland's public transport sector runs a shared ticketing and revenue-allocation system through the Alliance SwissPass and the Direct Service (Direkter Verkehr) arrangement, in which hundreds of transport companies sell and accept each other's tickets and apportion revenue through a common allocation system. The sector association (VöV/Alliance SwissPass) operates the rules and the clearing. It has run for decades and is continuously updated.

### Success Metrics

Near-universal national through-ticket coverage across operators (exact figures not verified).
Stable long-run operation of allocation and clearing.
Single customer account across modes.

### Risks and Challenges Faced

Fair allocation between large and small operators: handled by agreed allocation keys and periodic reviews.
Data protection for customer data: handled through the SwissPass account design and sector rules.
Governance among many companies: addressed by a sector association with defined decision rules.

### Where to Find More Information

https://www.allianceswisspass.ch
VöV/UTP: https://www.voev.ch
SBB: https://www.sbb.ch

### Actionable Steps

Contact Alliance SwissPass through its published contact channel and request a briefing on allocation rules and dispute handling.
Ask VöV/UTP (role: head of tariffs and distribution) how disputes between operators are resolved.
Connect with SBB's international distribution team via its corporate contacts.

### Rationale for Suggestion

It is a working example of single-ticket, multi-carrier sales with automatic revenue split, close to the programme's settlement and apportionment challenge, including small and large operators together. It supports the choice to extend shared rules rather than build a new central payment entity. Switzerland is also directly involved in the Wien–München–Zürich corridor. Limits: one country, one legal regime.
## Suggestion 3 - Deutschlandticket (Germany) – nationwide flat-rate ticket with sector clearing

Launched in May 2023, the Deutschlandticket is a monthly subscription valid on regional and local public transport across Germany, sold by many operators and distributors, with revenue shared among about a thousand transport companies through a clearing arrangement and federal-state compensation funding. Distribution and clearing are coordinated by the sector (VDV and associated bodies).

### Success Metrics

Several million subscribers reported shortly after launch (exact figure not verified).
Participation of nearly all regional operators.
Operating continuously since launch.

### Risks and Challenges Faced

Funding uncertainty between federal and state governments: handled by repeated political agreements, still a recurring risk.
Revenue allocation among many operators: handled by a sector clearing key and later adjustments.
Fast launch on legacy IT: handled by allowing existing sales channels plus a common data format.

### Where to Find More Information

https://www.vdv.de
Federal Ministry for Digital and Transport: https://bmdv.bund.de
Deutsche Bahn: https://www.bahn.de

### Actionable Steps

Contact VDV (role: head of tariff and distribution) for lessons on clearing and interface standardisation.
Ask the Federal Ministry's rail-policy unit about the co-funding mechanism.
Request an interview with DB Vertrieb's product team through DB's press office.

### Rationale for Suggestion

It shows a large multi-operator product launched quickly (months, not years) on existing sector structures, with standardised distribution interfaces, shared revenue split and public co-funding tied to results. This informs the milestone co-funding and no-new-entity approach. It also shows the funding-cliff risk the programme faces after Month 60 (2031-10-08). It is domestic and subscription-based, not a per-journey cross-border through-ticket.
## Suggestion 4 - Secondary: Rail Baltica joint ticketing preparation (Baltic states)

Secondary suggestion. Rail Baltica is a new cross-border rail link among Estonia, Latvia and Lithuania with Poland connections, and the planning includes shared, interoperable passenger ticketing across several national operators. Details of the ticketing design are limited and not fully verified.

### Success Metrics

Not yet established; ticketing is not live (not verified).

### Risks and Challenges Faced

Small national operators with differing systems and budgets.
Long infrastructure timelines delaying ticketing decisions.

### Where to Find More Information

https://www.railbaltica.org

### Actionable Steps

Contact RB Rail AS through the website to ask about the ticketing workstream and any lessons on shared back-ends.

### Rationale for Suggestion

Shows early-stage multi-country ticketing planning among smaller operators with weaker IT, relevant to the hub and smaller-carrier strand and the Lisbon–Tallinn ambition. Evidence of delivered outcomes is limited.

## Summary

Reference projects for the EU cross-border rail through-ticketing programme (Pragmatic Foundation: certified access, accredited payment providers, regional hubs, arbitration panel). Primary references are real and documented: the OSDM standard (UIC), the Swiss Alliance SwissPass/NRT public-transport distribution and clearing, and Germany's Deutschlandticket with its clearing and revenue-split model. A secondary reference is the Nordic/Baltic Rail Baltica ticketing effort. Figures are stated only where reasonably established; others are marked unverified. Geographic proximity is high for all of them (Europe). None is a full multi-country, multi-carrier through-ticket regime with a passenger-rights backstop, so lessons apply by component. Contacts are organisations and roles, not named individuals. Links should be checked before use (not verified).