## Suggestion 1 - OSDM (Open Sales and Distribution Model), UIC-led with Swiss SBB, DB, ÖBB, SNCF and others

Industry open standard of APIs for searching, booking, ticketing, refunds and after-sales across railway undertakings, developed under the International Union of Railways (UIC) with SBB, Deutsche Bahn, ÖBB and others as lead contributors. Published openly with a reference specification and test tooling. Adopted by several European operators and distributors for cross-border sales; it is the standard the proposed Regulation is expected to reference.

### Success Metrics

Number of operators and distributors live on OSDM endpoints (obtain current count from UIC; not verified).
Cross-border sales volume sold via OSDM (not published in verified form).
Release cadence and count of external contributors.

### Risks and Challenges Faced

Uneven carrier adoption and legacy back-ends: mitigated by phased profiles and open reference implementation.
Governance dependence on incumbents: mitigated through open publication and participation by distributors.
Version fragmentation across implementers: mitigated by versioned releases and a change-request process.

### Where to Find More Information

UIC OSDM page: https://uic.org (search 'OSDM')
OSDM specification repository on GitHub (search 'UIC OSDM')
CER and European Commission DG MOVE material on the Digital Booking and Ticketing proposal

### Actionable Steps

Contact the UIC Passenger Department / OSDM Steering team via the UIC website contact form.
Approach SBB's OSDM project lead via the SBB corporate contact and LinkedIn (identify the OSDM product owner role).
Join the OSDM community working group as an observer to review change-control practice.

### Rationale for Suggestion

Direct technical foundation of the plan's real-time data layer. Its governance, versioning and conformance experience informs the Specification Custodian and Conformance Gate decisions. Geographically and institutionally identical (European carriers, same stakeholders).
## Suggestion 2 - Rail Settlement Plan (RSP), Great Britain

Industry-owned clearing and settlement body for GB rail ticket revenue. It receives sales from all retailers (operators and third parties such as Trainline), allocates revenue to train operators by agreed rules (the Ticketing and Settlement Agreement, ORCATS allocation) and settles on a fixed cycle. Operated for decades on behalf of the rail industry (RDG).

### Success Metrics

Annual ticket revenue settled (published by RDG/RSP; confirm current figure).
Settlement cycle and error rates (request from RSP).
Number of authorised retailers.

### Risks and Challenges Faced

Disputes over revenue allocation: mitigated by deterministic allocation rules and an arbitration process.
Retailer access fairness: mitigated by retailer agreements and published terms.
Concentration of operational risk in one body: mitigated by industry governance and audit.

### Where to Find More Information

Rail Delivery Group: https://www.raildeliverygroup.com
Rail Settlement Plan: https://www.rsp.org.uk
ORR retail market reviews: https://www.orr.gov.uk

### Actionable Steps

Contact RSP through the corporate contact page and ask for the settlement and retailer-access team.
Request an expert briefing from Rail Delivery Group's retail/ticketing group.
Engage the ORR retail regulation team on competition oversight of industry settlement.

### Rationale for Suggestion

Best-documented real example of multi-operator through-ticket apportionment, single-payment settlement, refunds across carriers and non-discriminatory third-party retail access. Informs the federated clearing design, commission terms and dispute handling. Not EU, but the closest large-scale working model; note differences in a single national regulatory context.
## Suggestion 3 - Eurail/Interrail pass distribution and TAP/TSI telematics for rail passengers

Pan-European rail products sold across dozens of operators with multi-carrier revenue sharing and distribution through carriers and third-party channels, run by Eurail B.V. (Utrecht). Complemented by the EU TAP TSI telematics specifications that mandate interoperable data exchange for passenger services, managed by the EU Agency for Railways.

### Success Metrics

Number of participating operators and countries (published by Eurail).
TAP TSI compliance status by member state (Agency reports).
Pass sales volumes (company-reported; confirm).

### Risks and Challenges Faced

Allocating pooled revenue fairly among carriers: mitigated by agreed usage-based allocation rules.
Slow implementation of TAP TSI data exchange: mitigated by phased deadlines and Agency monitoring.
Competition-law scrutiny of shared arrangements: mitigated by documented rules and open participation.

### Where to Find More Information

Eurail: https://www.eurail.com
EU Agency for Railways TAP TSI pages: https://www.era.europa.eu
Commission TAP TSI Regulation (EU) 454/2011 on EUR-Lex

### Actionable Steps

Contact Eurail B.V. corporate or partner relations (Utrecht) via its website.
Contact the EU Agency for Railways telematics/TAP TSI sector via the Agency's contact form.
Ask CER's passenger group for introductions to carrier settlement teams.

### Rationale for Suggestion

Demonstrates a working multi-carrier revenue-pooling and clearing arrangement across about 30 European countries and the Agency's real role in mandating telematics specifications. Relevant for governance, clearing and carrier incentive design. Differs by being a pass, not point-to-point fares.
## Suggestion 4 - Swiss Direct Service (Direkter Verkehr) and NOVA platform (secondary suggestion)

Swiss national public-transport ticketing and revenue-sharing system run by Alliance SwissPass for over 200 transport companies. NOVA is the shared sales and distribution platform that allows any retailer to sell through-tickets across operators with common fare rules and automated revenue allocation. Secondary suggestion: national rather than cross-border.

### Success Metrics

Number of participating transport companies (published by Alliance SwissPass).
Share of journeys sold as through-tickets (not verified).

### Risks and Challenges Faced

Onboarding small operators: addressed through a shared platform and common rules.
Governance among many companies: addressed through an alliance body.

### Where to Find More Information

Alliance SwissPass: https://www.allianceswisspass.ch
SBB: https://www.sbb.ch

### Actionable Steps

Contact Alliance SwissPass via the website contact form for the NOVA/Direct Service team.
Approach SBB's distribution unit through its corporate contacts.

### Rationale for Suggestion

Shows a federated, mandated through-ticket model across many carriers with a common distribution platform, relevant to fare construction, clearing and carrier onboarding. Fewer details given; scale and governance differ from EU level.

## Summary

Recommended references cover the programme's core mechanisms: OSDM-based cross-border distribution, inter-carrier clearing, a shared rail-air-bus liability model, and public-funded interoperability governance. The closest real precedents are the UIC/OSDM standard and its adopters (primary), the Rail Settlement Plan in Great Britain and the DB/ÖBB/SBB/SNCF-led NeTEx/TAP-TSI and Eurail/Interrail distribution arrangements (primary), and the Swiss Direct Service/NOVA national integration (secondary). Geographic proximity is high (EU/Switzerland), but no precedent combines mandatory API exposure, a carrier-funded guarantee pool and a public last-resort distributor. Contact details are given as organisations or roles; individual names and figures should be confirmed directly with each body (not verified).