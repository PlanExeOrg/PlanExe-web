
## Risk 1 - Regulatory & Legislative
The proposed EU Regulation on Digital Booking and Ticketing Services for Rail (Commission proposal status not fully verified; as of October 2026, adoption timeline uncertain) may face parliamentary opposition, be substantially amended, or stall in Council negotiations. If the Regulation is delayed beyond Month 18 (2028-04-12), the binding-standards deadline becomes unachievable and carriers lose the legal mandate to expose inventory through OSDM APIs. If the Regulation is watered down or sets weaker conformance requirements, smaller carriers may remain outside the network, fragmenting the corridor coverage.

**Impact:** A 12–18 month delay in Regulation adoption could push binding standards from Month 18 (2028-04-12) to Month 30 (2029-04-12) or later, cascading the mandatory API exposure milestone and full corridor go-live. Weaker requirements could reduce participating carriers from the target 25+ to 15–20, leaving gaps in less commercially attractive corridors (e.g., Baltic routes) and lowering the through-ticket share from the 40% goal to 25–30%. Budget reallocation to fill coverage gaps could consume €200–400 million of the fixed €1.5 billion.

**Likelihood:** Medium

**Severity:** High

**Action:** Secure formal legal assurance from the Commission's legislative affairs unit that the Regulation will be tabled by Month 6 (2027-04-12) and adopted by Month 18 (2028-04-12), with binding-standards triggers contingent on publication in the Official Journal. Maintain a shadow legislative workstream that documents compliance with the Regulation's requirements as they evolve, so that standards and conformance tests do not depend on a finalised text. Establish contingency corridor definitions that include smaller operators earlier if coverage risk emerges.

## Risk 2 - Technical & Systems Integration
Legacy booking systems operated by smaller carriers (e.g., regional operators in CEE, the Balkans, Spain and Portugal) cannot be retrofitted to expose real-time availability through OSDM-compatible APIs within the Month 30 (2029-04-12) mandatory exposure deadline. Older systems may lack the architecture for event streaming, federated queries or transactional consistency required by the shared real-time layer. Integration adapters (funded from the €1.5 billion budget under the Conformance Gate decision) may be delayed or require longer development cycles than scheduled.

**Impact:** Smaller carriers may miss the Month 30 (2029-04-12) conformance deadline by 2–4 quarters, leaving 8–15 operators outside the network at critical corridor junctions (e.g., Austrian and Czech operators on the Wien–München corridor, Iberian regional carriers). This fragments the through-ticket path and forces passengers to stitch itineraries manually at borders. Estimated cost overrun to accelerate adapters: €150–250 million. Delay in full TEN-T rollout: 12–24 months beyond Month 60 (2031-10-12).

**Likelihood:** High

**Severity:** High

**Action:** Initiate a pre-programme technical audit of all participating carriers' booking-system architectures (by Month 2 = 2026-12-12) to identify retrofit bottlenecks and establish realistic Month 30 (2029-04-12) conformance timelines per operator. Co-fund shared adapter modules (middleware bridging legacy systems to OSDM) via the Conformance Gate and Carrier Onboarding Support decision, allocating €200–300 million of the public budget to this layer. Tier conformance into baseline (Month 30 = 2029-04-12), extended (Month 36 = 2029-10-12) and advanced (Month 42 = 2030-04-12) phases, releasing funding tranches based on verifiable API availability and booking-error rates rather than a one-time gate.

## Risk 3 - Commercial & Carrier Incentives
Carriers refuse to expose inventory and accept through-ticket connection liability because the liability backstop (Decision 1) and clearing mechanism (Decision 2) leave them unable to price the shared exposure to missed-connection delays and rerouting costs. If the carrier-funded mutual guarantee pool is weighted solely on incident rates, carriers face unpredictable exposure linked to operational performance they do not fully control (e.g., SBB delays caused by SNCF congestion). Without a clear liability cap or insurance backstop, large carriers (DB, SNCF, RZD) may refuse to expose seats and restrict sales to their own channels.

**Impact:** If 30% of expected carriers (i.e., 7–8 major operators) refuse to participate, the through-ticket network loses coverage on critical corridors: the Köln–Amsterdam leg becomes unavailable, the München–Zürich corridor is fragmented, and the Madrid–Barcelona–Lyon route loses a key connector. Estimated impact: a 3–5 quarter delay in reaching the mandatory API exposure milestone (Month 30 = 2029-04-12), pushing full corridor through-ticketing to Month 72 (2032-10-12) or beyond. The 40% through-ticket goal becomes unachievable; realistic outcome is 15–20%.

**Likelihood:** High

**Severity:** High

**Action:** Complete the Through-Ticket Liability and Rights Backstop decision by Month 3 (2027-01-12) with a published carrier risk-allocation model that specifies: (a) maximum carrier exposure per incident (e.g., capped at €X per missed connection + rerouting costs), (b) insurance or co-insurance for exposure above the cap, and (c) contribution-weighting rules tied to controllable factors (e.g., on-time performance in the 12 months prior, not forward-looking incident rates). Present this model to CER and the largest 10 carriers by Month 4 (2027-02-12) for binding commercial sign-off before standards are finalised. Establish a separate technical working group to model cash flows for the carrier-funded guarantee pool, so carriers see realistic annual contribution ranges before Month 6 (2027-04-12).

## Risk 4 - Financial & Budget
The €1.5 billion public coordination budget (user constraint) is allocated across standards work (€50–100 million), the clearing and settlement mechanism (€200–300 million), the public reference distributor concession (€300–500 million over five years), member-state capacity building (€200–300 million), conformance testing and carrier adapters (€200–300 million) and consumer rollout (€100–150 million), leaving little contingency. If the carrier-funded guarantee pool experiences a major incident surge (e.g., weather, labour strikes or a corridor-wide incident affecting thousands of passengers), the pool drains faster than projected and the Commission faces pressure to top it up from the public budget. Similarly, if the public distributor concession runs deeper operating losses than forecast (e.g., lower through-ticket volumes, higher payment processing and customer-service costs), the contract may require subsidy beyond the tendered allocation.

**Impact:** A €100–200 million draw on the public budget to cover guarantee-pool or distributor deficits in years 2–3 leaves only €100–200 million for the final-wave TEN-T extension (planned for Month 48–60 = 2030-10-12 to 2031-10-12), essentially cancelling the full-network rollout. This cuts the through-ticket goal from 40% to ~25%, primarily covering the four priority corridors. Member-state capacity building is cut by 30–50%, leaving smaller MS without training or testing resources.

**Likelihood:** Medium

**Severity:** High

**Action:** Commission an independent actuarial study of the carrier-funded guarantee pool (by Month 6 = 2027-04-12) with confidence intervals on missed-connection rates, rerouting costs and incident clustering. Establish a reserve fund of €150–200 million (drawn from the public budget allocation) earmarked for pool top-ups only in the case of force-majeure incidents (single-day corridor-wide disruptions affecting >5,000 passengers). For the public distributor concession, require monthly financial reporting and a trigger clause for subsidy increases if volumes fall below 60% of the forecast; if triggered, scale back the rollout to the four priority corridors and extend Month 60 (2031-10-12) completion to Month 72 (2032-10-12). Establish a policy with the Commission and the European Court of Auditors that public budget draw-downs on carrier pools beyond Month 36 (2029-10-12) will not occur, forcing recalibration of pool contributions or carrier participation instead.

## Risk 5 - Governance & Stakeholder Coordination
The program involves DG MOVE, the EU Agency for Railways, CER, 25+ national operators, independent distributors (Trainline, Omio), national regulators, BEUC and disability-rights bodies. Alignment on the Through-Ticket Liability (Decision 1), Inter-Carrier Clearing (Decision 2) and Public Reference Distributor Mandate (Decision 3) decisions by Month 3–6 (2027-01-12 to 2027-04-12) requires consensus among parties with conflicting interests. CER and large carriers favour bilateral clearing and distributed liability; independent distributors demand a single clearing entity and a public guarantee; disability bodies require accessible, auditable assistance booking. Failure to secure consensus delays decisions, leaving the standards-working group without a liability model or clearing architecture to build against.

**Impact:** If consensus is not reached by Month 9 (2027-07-12), the binding-standards milestone (Month 18 = 2028-04-12) is at risk because standards-working groups cannot finalise specifications without knowing the liability allocation and clearing rulebook. Estimated delay: 2–4 months. Additionally, if independent distributors reject the final clearing design, they may legally challenge it or withdraw, reducing the through-ticket volume available to passengers by 20–30% (Trainline and Omio account for a significant share of cross-border searches).

**Likelihood:** Medium

**Severity:** High

**Action:** Establish a dedicated governance layer within the Programme Office (by Month 1 = 2026-11-12) with biweekly steering meetings of the key stakeholders (CER, DG MOVE, Agency for Railways, 3–4 major carriers, Trainline, Omio, BEUC, a national disability body and a representative national regulator). Issue a non-binding position paper by Month 2 (2026-12-12) outlining three options for each critical decision (Decisions 1, 2, 3) with trade-offs clearly stated. Require binding votes on the final decisions by Month 6 (2027-04-12), with Commission mediation available if a vote is deadlocked. For distributors that reject the clearing design, negotiate a fallback technical interface that allows them to settle through a third party (e.g., a payment provider) rather than the central clearing layer, preserving their participation.

## Risk 6 - Competition Law & Regulatory
The Inter-Carrier Clearing and Single-Payment Settlement (Decision 2) and Distribution Remuneration and Commission Corridor (Decision 12) mechanisms involve competitors (25+ carriers, multiple distributors) exchanging commercially sensitive data (fares, inventory, settlement data) and potentially agreeing on commission rates or fare-construction rules. These arrangements could be viewed as prohibited coordination under Article 101 TFEU. The programme relies on the Joint Conduct Safe-Harbour for Shared Data and Clearing (Decision 14) decision to secure Commission comfort before binding standards are finalised (Month 18 = 2028-04-12). If comfort is not obtained in time, or if a future challenge unwinds the clearing arrangements, carriers will not commit real-time inventory and the through-ticket network collapses.

**Impact:** A competition-law challenge after Month 24 (2028-10-12) could force the programme to restructure the clearing mechanism and data-sharing layer, requiring 6–12 months of legal work and technical rework. Estimated cost: €50–100 million. If the challenge succeeds, the programme loses the centralised clearing or data layer, reverting to bilateral settlement and federated inventory queries, which add 3–4 months to settlement cycle times and increase booking-error rates by 15–25%, eroding the through-ticket value proposition.

**Likelihood:** Medium

**Severity:** High

**Action:** Initiate formal pre-notification with the Commission's Directorate for Competition (DG COMP) by Month 2 (2026-12-12), before any technical specifications are fixed. Request a formal guidance letter (under Commission competition procedure) by Month 12 (2027-10-12) that confirms the clearing and data-sharing arrangements as compatible with Article 101 TFEU, conditioned on the specific design choices made. If DG COMP indicates concerns, establish a clean-team arrangement (Decision 14, option 3) whereby the clearing function operates behind firewalls and releases only aggregated settlement data to carriers, not their competitors' fares or inventory. Ensure this arrangement is documented and signed off by DG COMP before Month 18 (2028-04-12).

## Risk 7 - Technical & Data Quality
The Availability Query Topology and Authoritative Booking Source (Decision 5, pragmatic option) relies on a streamed availability shadow (cached search layer) and carrier booking-engine authority. If carriers' booking engines are unavailable or respond slowly (>5 seconds), the system degrades to scheduled-only offers, which breaks through-ticketing (a passenger cannot book a through-ticket on a train that is not scheduled yet; real-time seat inventory is required). Legacy carrier systems, particularly smaller operators, often have 5–15 second query latency and 2–4 hour outages per month. Multiplicative latency and availability risk: a three-leg through-ticket requires three queries, so if each has 95% availability, the combined through-ticket availability is ~86%, not acceptable.

**Impact:** If carrier booking engines fail to meet <2 second latency and 99.5% availability targets, through-ticket search success rates fall to 70–80%, and the fallback to scheduled-only offers removes the commercial advantage of through-ticketing. Passengers revert to stitching itineraries manually or using single-carrier tools. Estimated impact: 30–50% lower through-ticket volume than forecast, pushing the 40% goal to 20–25%.

**Likelihood:** High

**Severity:** Medium

**Action:** Establish strict SLA targets for carrier booking-engine latency (<2 seconds per query, p95) and availability (99.5%) as part of the conformance gate (Decision 6). Build a monitored availability proxy that tracks each carrier's latency and availability in real time (Month 12 = 2027-10-12 onwards) and publishes a monthly scorecard. Attach tranches of the Milestone-Conditioned Funding Release Ladder (Decision 4) to carriers meeting these SLAs: carriers that miss SLAs in two consecutive months lose a portion of their next funding tranche. Concurrently, fund a lightweight caching layer (distributed, not central, to avoid a single point of failure) that holds recent search results and degrades gracefully to cached results if a carrier endpoint fails, so that scheduled offers are available at all times even if real-time inventory is not.

## Risk 8 - Operational & Service Delivery
The Disruption Re-accommodation Choreography (Decision 9) and Assistance and Bicycle Reservation Chaining (Decision 10) require real-time, coordinated action across carrier networks: detecting a missed connection, proposing alternatives on competitors' trains, securing seats and confirming reroutes within minutes. This depends on shared operational data (train delays, seat inventory) that carriers have historically guarded and on staff at stations and onboard who are trained to recognise across-carrier re-accommodation and accessible reservations. Smaller operators may lack 24/7 customer-service centres or English-speaking staff at border stations. A missed connection during night hours or a weekend may go undetected for hours.

**Impact:** If re-accommodation response times exceed 30–60 minutes, or if passengers are not re-accommodated at all (e.g., left stranded at a border station overnight), the program faces public backlash and liability claims. Estimated cost: €10–20 million in compensation and reputation damage per major incident. If assistance requests (wheelchairs, service animals, reduced-mobility support) are delayed or unfulfilled due to staffing or coordination gaps, the programme violates accessibility law (EU Regulation 1371/2007) and faces complaints to national regulators. Disruption handling failures could reduce through-ticket adoption by 10–20% due to passenger loss of trust.

**Likelihood:** Medium

**Severity:** High

**Action:** Develop a detailed operational manual for all participating carriers by Month 9 (2027-07-12) covering missed-connection detection, re-accommodation procedures, seat-access protocols, assistance escalation and passenger communication at border stations. Conduct live pilots on each of the four priority corridors (Month 12–18 = 2027-10-12 to 2028-04-12) with 500–1,000 passengers per corridor, measuring response times, reroute success and passenger satisfaction. Use pilot results to calibrate SLAs (e.g., re-accommodation decision within 15 minutes, assistance confirmation within 30 minutes) and incorporate them into carrier conformance gates. Require carriers to establish 24/7 customer-service centres and train staff at key border stations (at least one English-speaking agent at each) as a precondition of conformance certification by Month 30 (2029-04-12). Fund capacity-building and staff training through the member-state capacity-building budget (€200–300 million allocation within the €1.5 billion).

## Risk 9 - Technical & Systems Integration
The Ticket Validation and Onboard Inspection Interoperability (Decision 13) decision requires every train crew member, station agent and gate system on participating corridors to accept and validate through-tickets issued by any participating carrier. The pragmatic approach (hybrid credentials or API handshakes) is slower than a single-format mandate but avoids the cost and schedule risk of retrofitting handheld devices and gates on 1,000+ trains across four carriers. If carrier IT teams fail to implement the API handshake or hybrid credential format by Month 30 (2029-04-12), conductors and station agents have no way to validate across-carrier tickets, and manual workarounds (checking papers, holding passengers) reappear, eroding the through-ticket value.

**Impact:** If even 20% of corridor vehicles lack proper validation capability by Month 60 (2031-10-12), passengers face validation disputes, penalties and delays at stations, degrading the through-ticket experience. Estimated impact: 5–10% reduction in through-ticket adoption due to trust loss. If a validation failure leads to a passenger boarding a train without a valid ticket due to system incompatibility, the carrier faces a regulatory fine and reputational damage.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Specify the API handshake or hybrid credential format as part of the OSDM standard by Month 6 (2027-04-12) and include it in conformance tests (Decision 6). Require all carriers to deploy validation capability to all corridor rolling stock and key stations by Month 40 (2030-02-12) (10 months before full corridor go-live), with intermediate audits at Month 30 (2029-04-12) and Month 35 (2029-09-12). Tie funding tranches (Decision 4) to validation rollout milestones: carriers that fall 2+ months behind in validation deployment lose their next funding tranche. Fund a small team of on-site validation testers at each priority corridor (Month 24 = 2028-10-12 onwards) to conduct monthly audits of handheld and gate compatibility, publishing a publicly available scoreboard.

## Risk 10 - Market & Competitive
The Air-to-Rail Competitiveness Package (Decision 7) aims to shift passengers from short-haul flights to rail through through-ticketing, intermodal products and information. However, the program has limited direct control over carrier pricing (through-fare construction is a carrier-led negotiation in Decision 8) and cannot control flight-operator pricing or schedule changes. If flight operators respond to increased rail competition by cutting fares on competitive routes to €20–40 one-way (which is commercially viable given lower fuel and staff costs), rail through-fares will struggle to compete even with the convenience factor. Additionally, passengers' modal choice depends on total journey time (including airport check-in and security), which the program does not control.

**Impact:** If modal shift from air to rail is slower than forecast (e.g., 5–10% instead of 15–20%), the 40% through-ticket goal is reached but the headline outcome—'fewer travellers choose the plane'—is not achieved, creating a political narrative of programme failure despite 40% penetration. The program may face pressure to shift funding toward price subsidies for rail, draining the fixed €1.5 billion budget.

**Likelihood:** Medium

**Severity:** Low

**Action:** Conduct a baseline modal-shift study by Month 6 (2027-04-12) measuring current air-to-rail ratios on the four priority corridors and the impact of through-ticketing, intermodal information and journey-time visibility on booking behaviour. Establish conservative modal-shift targets tied to through-ticketing availability, not price, so that the programme success is measured by through-ticket penetration and complaint reduction, not flight-passenger reduction. In the Air-to-Rail Competitiveness Package decision, focus on display neutrality and journey-time information (low cost) rather than fare commitments, which create subsidy dependencies. If modal shift is slower than forecast, use Month 48 (2030-10-12) evaluation findings to adjust the tone of programme communications, emphasizing convenience and reliability over environmental or air-replacement goals.

## Risk 11 - Physical & Logistical
The programme is distributed across four member states (Belgium, France, Germany, Austria/Switzerland, Spain) with programme offices in Brussels, Valenciennes, Berlin and Madrid. Coordination across time zones, languages and national regulatory environments adds overhead. The EU Agency for Railways is in Valenciennes, far from Brussels (Commission HQ) and from the largest carrier IT centres (Berlin, Munich, Zurich). Travel time, visa requirements for non-EU staff and local staffing constraints can slow governance meetings and technical working groups.

**Impact:** Coordination delays, particularly in standards-working groups and conformance testing, could add 1–2 months to binding-standards and mandatory API exposure milestones. Estimated cost of additional coordination: €5–10 million in staff travel and extended contracts.

**Likelihood:** Low

**Severity:** Low

**Action:** Establish a virtual-first governance model with scheduled in-person meetings only for critical decisions (Decisions 1–5, competition-law clearance). Use video conferencing for biweekly steering and technical working groups. Rotate in-person meetings between Brussels, Valenciennes and a carrier IT hub (Berlin or Munich) on a quarterly cycle, with participation costs covered by the programme budget. Hire at least one full-time liaison officer based in each of the four physical locations (Brussels, Valenciennes, Berlin, Madrid) to support async coordination and local stakeholder engagement.

## Risk 12 - Regulatory & Policy
National railway regulators (e.g., ORE in France, BNetzA in Germany, NaBB in Austria) retain authority over track access, station capacity and pricing in their respective territories. The programme's binding standards and mandatory API exposure may conflict with existing national regulations or incumbent operator privileges. For example, a mandate to share real-time inventory through a central or federated layer could trigger concerns about incumbent cost-shifting or non-discriminatory access. If a national regulator blocks the programme's data-sharing or clearing arrangements on competition or incumbent-protection grounds, the programme cannot proceed in that member state.

**Impact:** If one major corridor (e.g., the Wien–München–Zürich or the Paris–Brussels–Amsterdam–Köln route) loses a national regulator's approval, the through-ticket network is fragmented and the corridor is blocked for 12–24 months while regulatory issues are resolved. Estimated impact: delay in mandatory API exposure milestone of 6–12 months and a reduction in through-ticket reach of 20–30%.

**Likelihood:** Medium

**Severity:** High

**Action:** By Month 3 (2027-01-12), the DG MOVE and the EU Agency for Railways must conduct bilateral engagement with each national regulator on the programme's scope, data-sharing arrangements and competition-law compliance. Prepare a regulatory-impact assessment for each member state that identifies potential conflicts with national law. If conflicts are identified, work with national regulators to adapt the programme design or secure regulatory waivers by Month 12 (2027-10-12). Include national regulators as observers in the standards-working groups so they can flag regulatory constraints early. If a regulator's concerns cannot be resolved by Month 12 (2027-10-12), consider deferring that member state's participation to a Phase 2 rollout (Month 60 = 2031-10-12 onwards) rather than the four priority corridors.

## Risk 13 - Accessibility & Inclusivity
The Assistance and Bicycle Reservation Chaining (Decision 10) aims to make through-tickets accessible for persons with reduced mobility (PRM) and cyclists. However, compliance depends on carriers to provide wheelchair spaces, assistance at stations and onboard staff training. Rolling stock ages and accessibility standards vary widely across operators (e.g., older trainsets on regional routes may have no wheelchair spaces). Atomic confirmation of assistance and bicycle reservations as part of the through-ticket booking means that itineraries without available spaces are refused, reducing the volume of through-tickets available to these passenger groups and potentially creating legal exposure under EU Regulation 1371/2007 (railway passengers' rights) and the Accessibility Directive.

**Impact:** If participating carriers cannot guarantee assistance or bicycle space on 50%+ of through-ticket itineraries, the programme risks legal complaints to national regulators and the European Court of Justice. Alternatively, if atomic confirmation is dropped in favour of 'best-effort' booking, passengers are left uncertain whether they will have access at journey time, eroding trust. Estimated reputational and legal cost: €20–50 million.

**Likelihood:** Medium

**Severity:** Medium

**Action:** By Month 6 (2027-04-12), require all participating carriers to publish their rolling-stock accessibility inventory (wheelchair spaces, assistance availability, onboard staff language skills) for each service on the priority corridors. Establish minimum accessibility levels (e.g., wheelchair access on ≥80% of services, assistance availability with ≤4 hours' notice on ≥90% of services) as a precondition of conformance (Decision 6). For carriers unable to meet these levels by Month 40 (2030-02-12), allow a fallback to 'best-effort' booking with transparent communication to passengers (e.g., 'wheelchair space availability uncertain; you will receive confirmation 48 hours before departure'). Engage disability-rights bodies (e.g., EBU) as observers in the Assistance and Bicycle Reservation Chaining working group and conduct usability testing with PRM passengers by Month 18 (2028-04-12). Fund accessibility infrastructure improvements (rolling-stock retrofits, station accessibility) through member-state capacity-building budget if carriers cannot self-fund.

## Risk 14 - Financial & Budget
The Public Reference Distributor Mandate (Decision 3, pragmatic option: tendered last-resort concession) requires the Commission to contract a private operator to run a last-resort sales channel. The concession contract must specify service levels (availability, booking success, complaint resolution time), volume targets and subsidy triggers. If the concessionaire overstates their cost efficiency, the contract runs into operating losses within 18–24 months and requests subsidy increases from the €1.5 billion budget. Alternatively, if volume forecast is too optimistic, the concessionaire operates at a loss and may withdraw, leaving the Commission without a last-resort channel.

**Impact:** If the concessionaire withdraws by Month 36 (2029-10-12) or requests a subsidy increase >€50 million, the Commission must either operate the distributor directly (consuming staff and overhead) or leave the last-resort role unfilled, which undermines the programme's claim to provide a neutral channel. Estimated risk: €75–150 million in subsidy overrun or €30–50 million in government operating costs to take over directly.

**Likelihood:** Medium

**Severity:** Medium

**Action:** By Month 9 (2027-07-12), the Commission must develop a detailed business case for the public distributor concession, including volume forecasts, cost benchmarks (from Trainline, Omio and carrier apps) and margin assumptions. Issue a competitive tender for the concession by Month 12 (2027-10-12) with a two-stage evaluation: (a) technical requirements (system architecture, compliance with OSDM, accessibility, multilingual support) and (b) financial viability (total cost of ownership, subsidy threshold). Cap the initial subsidy at €60 million over five years and include a clawback clause: if through-ticket volumes exceed forecast by >20%, the concessionaire must rebate surplus fees to the Commission. Require the concessionaire to publish quarterly financial reports and trigger a contract review if operating costs exceed budget by >15% in any quarter.

## Risk 15 - Technical & Data Quality
The Inter-Carrier Clearing and Single-Payment Settlement (Decision 2, pragmatic option: federated layer) depends on carriers submitting consistent, timely settlement data (fares, refunds, reroute costs, commission splits). If carriers' financial systems use different formats, currencies or accounting methods, reconciliation is slow and error-prone. A 2–3% reconciliation error rate (which is typical in financial services) translates to thousands of disputed transactions per month, overwhelming dispute-resolution capacity and delaying payouts to distributors.

**Impact:** If reconciliation error rates exceed 2%, settlement cycle times lengthen from the targeted 5 business days to 10–15 days, cash flow friction increases for distributors, and distributor complaints about delayed payouts rise. Estimated impact: 15–20% of distributors may reduce their participation in through-ticket sales due to cash-flow concerns, lowering through-ticket volume by 10–15%.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish a detailed data-format standard for settlement feeds (fares, refunds, reroute costs, commission) as part of the OSDM specification by Month 6 (2027-04-12). Require all carriers to submit settlement data in the standard format via a validated API by Month 24 (2028-10-12), with test environments available from Month 12 (2027-10-12) onwards. Fund a shared reconciliation platform (part of the clearing mechanism budget) that automates basic matching and flags mismatches for manual review. Set a target reconciliation error rate of <0.5% by Month 30 (2029-04-12), with automatic penalties for carriers exceeding 1% error rates in any month (e.g., 0.1% reduction in their next funding tranche).

## Risk 16 - Operational & Service Delivery
Member-state capacity building (€200–300 million allocation within the €1.5 billion budget) is required to train national railway operators, regulators and consumer bodies on the new standards, systems and passenger-rights procedures. Smaller member states (e.g., Baltic countries, Luxembourg, Cyprus) may lack in-country expertise and depend on external training from the EU Agency for Railways or contractors. If capacity building is delayed or under-resourced, local operators and regulators may not meet the mandatory API exposure or conformance milestones, delaying the full TEN-T rollout.

**Impact:** A 6–9 month delay in capacity building for smaller member states could push their participation in the full TEN-T rollout from Month 60 (2031-10-12) to Month 72 (2032-10-12) or later. This fragments the pan-European through-ticket coverage and reduces the overall through-ticket share from 40% to 30–35%.

**Likelihood:** Low

**Severity:** Medium

**Action:** Allocate €30–50 million of the capacity-building budget specifically for external training programs, delivered by the EU Agency for Railways or contracted trainers, targeting smaller member states and less-resourced operators. Establish regional training hubs in Brussels, Valenciennes, Berlin and one southern hub (e.g., Madrid or Rome) so that training is accessible without extensive travel. Conduct a skills audit by Month 6 (2027-04-12) to identify member states with capacity gaps and tailor training curricula. Schedule intensive training programs (2–3 weeks per operator) at Month 18–24 (2028-04-12 to 2028-10-12) to coincide with the binding-standards deadline, so operators can begin implementation planning immediately after training.

## Risk 17 - Regulatory & Policy
The programme's success relies on attracting independent distributors (Trainline, Omio and smaller platforms) to integrate with the shared real-time data layer and clearing mechanism. The Distribution Remuneration and Commission Corridor (Decision 12) sets the terms under which carriers pay distributors per through-ticket sold. If the negotiated commission rates are too low, distributors reduce their investment in through-ticket search and promotions; if too high, carriers view through-distribution as unprofitable and restrict inventory access. A misstep in commission design can fracture the distributor ecosystem and lower through-ticket sales.

**Impact:** If commission rates are set below distributors' cost of acquisition and support (typically 3–5% of fare), large independents (Trainline, Omio) may deprioritise the programme's through-tickets in their search results and marketing, reducing through-ticket volume by 20–30%. Alternatively, if rates are set above 5%, smaller distributors and new entrants cannot sustain a business, and the market consolidates to incumbents, reducing competition and innovation. Estimated impact: 15–20% reduction in through-ticket share if either scenario occurs.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Commission an industry survey by Month 3 (2027-01-12) of Trainline, Omio and 5–10 smaller distributors to establish their cost of acquisition, customer support and payment processing for cross-border through-tickets. Use this data to establish a commission-rate band (e.g., 2.5–4.5% of through-fare) that covers distributors' costs while allowing carriers margins. Include the band in the Distribution Remuneration and Commission Corridor decision (Decision 12) by Month 9 (2027-07-12). Require the clearing function to publish monthly commission-rate data by distributor type and check for discrimination; publish results quarterly. If a distributor claims discrimination, require a mediated review with the Agency for Railways before Month 30 (2029-04-12).

## Risk 18 - Technical & Systems Integration
The Specification Custodian Seat for OSDM Evolution (Decision 11, pragmatic option: Agency for Railways anchoring with an escrowed open-source reference implementation) requires a formal, published change-control process for the OSDM specification. If the process is too slow (e.g., change requests take 3–6 months to be reviewed and approved), carriers and distributors may fork the specification or apply proprietary extensions, fragmenting the ecosystem. If the process is too fast (e.g., changes approved in weeks), carriers with legacy systems struggle to keep pace and integration failures emerge.

**Impact:** If the specification forks or diverges significantly from carriers' implementations by Month 42 (2030-04-12), conformance testing becomes ambiguous and the mandatory API exposure milestone is delayed or fails. Estimated delay: 3–6 months. A slow change process (>2 month review cycles) could delay critical bug fixes or security updates by 6–9 months, creating vulnerability windows.

**Likelihood:** Low

**Severity:** Medium

**Action:** Establish the OSDM change-control process as part of the Agency for Railways mandate by Month 3 (2027-01-12), with published criteria for change request severity (critical: security/safety; major: functional gaps; minor: optimisations), review timelines (critical: 2 weeks; major: 6 weeks; minor: 8 weeks) and approval gates (technical review by at least 3 independent carriers, competition-law check for sensitive changes). Publish a quarterly release cadence so carriers can plan integration work. Archive all historical versions in an open-source repository with escrowed backups, so carriers can fork if needed. Establish a change-request dashboard showing pending and approved changes, helping carriers plan their implementation roadmaps.

## Risk 19 - Compliance & Legal
Passenger rights on cross-border rail journeys are governed by EU Regulation 1371/2007 (railway passengers' rights), which covers compensation, assistance and liability for operators. The Through-Ticket Liability and Rights Backstop (Decision 1) and Disruption Re-accommodation Choreography (Decision 9) must ensure that a through-ticket passenger has equivalent rights regardless of the number of carriers involved. If the programme's rights backstop and liability rules are less generous than Regulation 1371/2007 or create gaps, passengers may lose rights and the programme faces regulatory complaints.

**Impact:** If passengers lose rights (e.g., compensation for delays due to an unclear liability allocation), the EU Agency for Railways or national regulators may issue enforcement notices, forcing the programme to redesign the liability and disruption-handling rules, delaying implementation by 3–6 months. Estimated cost: €10–20 million in legal work and programme redesign.

**Likelihood:** Low

**Severity:** Medium

**Action:** By Month 3 (2027-01-12), commission an independent legal review of the Through-Ticket Liability and Rights Backstop (Decision 1) design against EU Regulation 1371/2007, ensuring that through-ticket passengers have equivalent or better rights than single-carrier passengers. Publish the legal opinion and any required design adjustments by Month 6 (2027-04-12). Ensure that the Disruption Re-accommodation Choreography (Decision 9) operating manual includes step-by-step procedures for compensation claims, assistance and liability that comply with Regulation 1371/2007. Submit the manual to the EU Agency for Railways for formal review and approval by Month 9 (2027-07-12) before carrier pilots begin.

## Risk 20 - Organizational & Governance
The programme requires a Programme Office (within DG MOVE) and a Technical Secretariat (within or supporting the EU Agency for Railways) to coordinate standards work, conformance testing, funding releases and stakeholder engagement across five years and four locations. Programme staff turnover, particularly in leadership roles, can disrupt continuity and delay decision-making. Additionally, if the Programme Office lacks clear authority over budget releases or standards-working groups, carrier and distributor consensus becomes harder to achieve.

**Impact:** A change in Programme Director or Technical Lead at critical junctures (e.g., Month 12–18 = 2027-10-12 to 2028-04-12 for binding standards, Month 24–30 = 2028-10-12 to 2029-04-12 for API exposure) could add 2–3 months of ramp-up time and defer milestones. If the Programme Office cannot enforce milestone conditions (e.g., conformance certificates before funding release), compliance will drop and the schedule will slip. Estimated cost: €5–10 million in extended programme management and consultant engagement.

**Likelihood:** Medium

**Severity:** Low

**Action:** By Month 1 (2026-11-12), the Commission must formally establish the Programme Office and Technical Secretariat with clear governance (reporting lines, decision authority), a multi-year budget (€50–100 million for programme management) and retention incentives for key staff (e.g., 3–5 year appointments with continuity clauses). Define success milestones and annual review cycles so that leadership changes are planned at low-risk points (e.g., after month 12 = 2027-10-12, month 36 = 2029-10-12 reports). Establish an advisory board of external experts (from carriers, distributors and academics) to provide independent oversight and escalation paths if the Programme Office is blocked by stakeholders.

## Risk summary
This is a large, multi-stakeholder public infrastructure program spanning five years, four priority corridors and the full TEN-T network. It layers shared standards (OSDM-compatible APIs, clearing, rights backstop) over existing national carrier systems to enable seamless cross-border rail through-ticketing. The program operates under a fixed €1.5 billion public coordination budget (user constraint) and faces three interconnected critical risks: (1) Carrier unwillingness to expose inventory and accept connection liability unless the backstop design and clearing mechanism guarantee they can price the risk fairly—blocking the binding-standards milestone if not resolved by Month 18 (2028-04-12); (2) Legacy IT integration delays and conformance failures on priority corridors, particularly with smaller operators' systems, which could push the mandatory API exposure milestone (Month 30 = 2029-04-12) into the later quarters and starve funding for subsequent corridors; (3) Budget exhaustion if the carrier-funded guarantee pool drains faster than projected or the public distributor concession runs deeper deficits, cutting funding for member-state capacity building and reducing the likelihood of the 40% through-ticket goal. The regulatory and competition-law pathway is complex, with a Regulation proposal in Commission hands (not fully verified) and Article 101 TFEU clearance needed before binding standards. Physical location dependencies (EU institutions in Brussels, Agency for Railways in Valenciennes, carrier IT in Berlin/Munich/Zürich, pilot corridors across four member states) add coordination overhead. The program also depends on passenger behaviour change, multimodal integration and disability-rights compliance that are largely outside the program's control. Most critical are the carrier liability and inventory-exposure decisions (Decision 1 and 5), which, if mishandled, could trigger carrier non-participation and unravel the entire through-ticketing stack.