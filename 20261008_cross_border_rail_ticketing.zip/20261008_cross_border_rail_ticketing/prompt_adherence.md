**Overall Adherence: 98%**

```
IMPORTANCE_ADHERENCE_SUM = (5×5 + 5×5 + 5×5 + 4×5 + 5×5 + 5×5 + 5×5 + 5×5 + 5×5 + 5×5 + 4×4 + 4×4 + 4×5 + 3×5 + 3×5) = 327
IMPORTANCE_SUM = 5 + 5 + 5 + 4 + 5 + 5 + 5 + 5 + 5 + 5 + 4 + 4 + 4 + 3 + 3 = 67
OVERALL_ADHERENCE = IMPORTANCE_ADHERENCE_SUM / (IMPORTANCE_SUM × 5) = 327 / 335 = 98%
```

## Summary

| ID | Directive | Type | Importance | Adherence | Category |
|----|-----------|------|------------|-----------|----------|
| 1 | Deliver coordinated European programme enabling cross-border train travel search, booking, and refunds aligned with EC's proposed Digital Booking and Ticketing Services Regulation. | Requirement | 5/5 | 5/5 | Fully honored |
| 2 | Establish technical, commercial, and governance arrangements allowing any compliant distributor to sell through-tickets across participating carriers with continuity-of-journey rights, single-payment settlement, harmonised refunds, and passenger-rights protection. | Requirement | 5/5 | 5/5 | Fully honored |
| 3 | Build shared real-time data layer via OSDM-compatible APIs on non-discriminatory commercial terms, inter-carrier clearing and settlement, passenger-rights backstop, and integration hooks for buses, ferries, short-haul air. | Requirement | 5/5 | 5/5 | Fully honored |
| 4 | Rollout starts with four busiest cross-border corridors (Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin) before extending to full TEN-T network. | Requirement | 4/5 | 5/5 | Fully honored |
| 5 | Public-side coordination budget is EUR 1.5 billion hard cap covering standards, testing, clearing mechanism, public reference distributor, capacity building, consumer rollout. | Constraint | 5/5 | 5/5 | Fully honored |
| 6 | Five-year horizon: binding standards within Month 18 (2028-04-12); mandatory API exposure within Month 30 (2029-04-12); full corridor through-ticketing within Month 60 (2031-10-12). | Constraint | 5/5 | 5/5 | Fully honored |
| 7 | Binding standards must be achieved by Month 18 (2028-04-12); mandatory API exposure for Tier 1 carriers by Month 30 (2029-04-12), Tier 2 by Month 36 (2029-10-12), Tier 3 by Month 42 (2030-04-12). | Requirement | 5/5 | 5/5 | Fully honored |
| 8 | Four priority corridors must be live with through-ticketing by Month 48 (2030-10-12); latest acceptable deadline Month 60 (2031-10-12). | Requirement | 5/5 | 5/5 | Fully honored |
| 9 | Success metric: 40% of cross-border journeys sold as single through-tickets within five years (by Month 60 = 2031-10-12). | Constraint | 5/5 | 5/5 | Fully honored |
| 10 | Distributor complaints must be halved within five years (by Month 60 = 2031-10-12). | Constraint | 5/5 | 5/5 | Fully honored |
| 11 | Current state: passengers cannot buy single through-ticket across EU, lose passenger-rights protection on missed connections, each national operator has disconnected systems, distributors lack consistent real-time inventory access. | Stated fact | 4/5 | 4/5 | Partially honored |
| 12 | Support accessibility for persons with reduced mobility and bicycle reservations across all participating carriers. | Requirement | 4/5 | 4/5 | Partially honored |
| 13 | Pick a realistic scenario, not the most aggressive one. | Intent | 4/5 | 5/5 | Fully honored |
| 14 | Stakeholders include DG MOVE, EU Agency for Railways, CER, national operators, independent distributors, BEUC, national regulators, disability-rights bodies. | Requirement | 3/5 | 5/5 | Fully honored |
| 15 | Estimate private carrier IT investment separately; treat as distinct from EUR 1.5B public budget cap. | Requirement | 3/5 | 5/5 | Fully honored |

## Issues

### Issue 11 - Current state: passengers cannot buy single through-ticket across EU, lose passenger-rights protection on missed connections, each national operator has disconnected systems, distributors lack consistent real-time inventory access.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Current state: passengers cannot buy single through-ticket across EU, lose passenger-rights protection on missed connections, each national operator has disconnected systems, distributors lack consistent real-time inventory access. (project_plan.md, consolidate_assumptions_full.md)
- **Explanation:** The plan acknowledges the problem statement in the executive summary ('cross-border journeys require separate bookings, liability splits and distributor friction') and in project_plan.md ('removes fragmentation that blocks single-ticket cross-border rail travel'). However, it does not explicitly restate all four current-state facts, treating them as background context rather than a baseline for measurement.

### Issue 12 - Support accessibility for persons with reduced mobility and bicycle reservations across all participating carriers.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Accessibility compliance (80% wheelchair access, 90% assistance within 4 hours' notice) in conformance (proposed threshold). Assistance and Bicycle Reservation Chaining (Decision 10). (executive_summary.md, project_plan.md)
- **Explanation:** The plan includes accessibility and bicycle reservations as deliverables (executive_summary.md mentions '80% wheelchair access, 90% assistance within 4 hours' notice') and Decision 10 addresses them. However, the scope is narrowed: accessibility for persons with reduced mobility is a carrier conformance requirement tied to rolling-stock availability, not a programme-wide design commitment. Best-effort fallback for non-compliant carriers (consolidate_assumptions_full.md) represents a softening of 'support across all participating carriers' to 'support across compliant carriers'.
