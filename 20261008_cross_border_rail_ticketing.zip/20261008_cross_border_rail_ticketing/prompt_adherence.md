**Overall Adherence: 99%**

```
IMPORTANCE_ADHERENCE_SUM = (5×5 + 5×5 + 5×5 + 5×5 + 5×5 + 5×5 + 4×5 + 5×4 + 4×5 + 4×5 + 4×5 + 4×5 + 5×5 + 3×5 + 5×5) = 335
IMPORTANCE_SUM = 5 + 5 + 5 + 5 + 5 + 5 + 4 + 5 + 4 + 4 + 4 + 4 + 5 + 3 + 5 = 68
OVERALL_ADHERENCE = IMPORTANCE_ADHERENCE_SUM / (IMPORTANCE_SUM × 5) = 335 / 340 = 99%
```

## Summary

| ID | Directive | Type | Importance | Adherence | Category |
|----|-----------|------|------------|-----------|----------|
| 1 | Establish coordinated European program enabling cross-border train travel to be searchable, bookable, and refundable as easily as domestic travel, aligned with EC Regulation on Digital Booking and Ticketing Services for Rail. | Requirement | 5/5 | 5/5 | Fully honored |
| 1 | Establish coordinated European program enabling cross-border train travel to be searchable, bookable, and refundable as easily as domestic travel, aligned with EC Regulation on Digital Booking and Ticketing Services for Rail. | Requirement | 5/5 | 5/5 | Fully honored |
| 2 | Enable any compliant distributor (operator, third-party platform, or public European booking service) to sell through-tickets across all participating carriers with continuity-of-journey rights, single-payment settlement, and harmonised refunds. | Requirement | 5/5 | 5/5 | Fully honored |
| 3 | Public-side coordination budget capped at EUR 1.5 billion over Months 0–60 (2026-10-08 to 2031-10-08). Private carrier IT investment (EUR 0.5–2.0 billion midpoint EUR 1.25 billion) is separate and outside this cap. | Constraint | 5/5 | 5/5 | Fully honored |
| 4 | Binding standards established by Month 18 (2028-04-08); mandatory API exposure by Month 30 (2029-04-08); full through-ticketing on four priority corridors by Month 60 (2031-10-08). | Constraint | 5/5 | 5/5 | Fully honored |
| 5 | Scope includes shared real-time data layer (OSDM-compatible APIs, non-discriminatory terms), inter-carrier clearing and settlement, passenger-rights backstop, and integration hooks for buses, ferries, and short-haul air. | Requirement | 5/5 | 5/5 | Fully honored |
| 6 | Rollout starts with four priority corridors (Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin) before extending to full TEN-T network at Month 36 (2029-10-08). | Constraint | 5/5 | 5/5 | Fully honored |
| 7 | Integrate reduction cards, accessibility for persons with reduced mobility, and bicycle reservations into through-ticket sales across all distributors. | Requirement | 4/5 | 5/5 | Fully honored |
| 8 | Success target: 40% of cross-border rail journeys sold as single through-tickets by Month 60 (2031-10-08); distributor complaints halved; train more attractive than flying on competitive short-haul routes. | Constraint | 5/5 | 4/5 | Partially honored |
| 9 | Today, cross-border rail relies on disconnected national operators (SNCF, Deutsche Bahn, Trenitalia, Renfe, ÖBB, NS, SJ, and ~20 more), each with separate fares, booking systems, refund policies, and disruption handling; distributors lack consistent access to real-time inventory. | Stated fact | 4/5 | 5/5 | Fully honored |
| 10 | Passenger-rights protection must be continuous across connections; passengers buying Lisbon-to-Tallinn through-ticket retain protection throughout journey; single contact for refund/reroute. | Constraint | 4/5 | 5/5 | Fully honored |
| 11 | Establish governance arrangements with DG MOVE, EU Agency for Railways, CER, national operators, independent distributors, BEUC, regulators, and disability-rights bodies as stakeholders. | Requirement | 4/5 | 5/5 | Fully honored |
| 12 | Select a realistic, pragmatic scenario—not the most aggressive approach—for technical, commercial, and governance implementation. | Intent | 4/5 | 5/5 | Fully honored |
| 13 | Establish inter-carrier clearing and settlement mechanism with single-payment processing and non-discriminatory commercial access terms for all compliant distributors. | Requirement | 5/5 | 5/5 | Fully honored |
| 14 | Do not implement aggressive or maximum-ambition scenarios; choose pragmatic, phased rollout approach that respects carrier constraints and testing timelines. | Banned | 3/5 | 5/5 | Fully honored |

## Issues

### Issue 8 - Success target: 40% of cross-border rail journeys sold as single through-tickets by Month 60 (2031-10-08); distributor complaints halved; train more attractive than flying on competitive short-haul routes.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 5/5
- **Evidence:** Executive summary: '(1) 40% through-ticket share of cross-border rail journeys by Month 60 (2031-10-08); (2) Distributor complaints ≤50% of baseline by Month 60 (2031-10-08); (3) Modal shift 5–15% from short-haul air (planning range, not commitment).' The third success metric is stated as a 'planning range' and explicitly noted as not a commitment.
- **Explanation:** The 40% through-ticket target is fully honoured as a binding metric. Distributor complaints halved (≤50% of baseline validated at Month 9 = 2027-07-08) is honoured. Modal shift is SOFTENED: the directive aims for modal shift that makes 'train the more attractive option than flying on competitive short-haul routes,' implying a target of 25%+ reduction. The plan hedges this as 5-15% (a 'planning range, not a commitment'), acknowledging fare-competitiveness barriers but not committing to the ambition. This is realistic but weaker than the directive's intent.
