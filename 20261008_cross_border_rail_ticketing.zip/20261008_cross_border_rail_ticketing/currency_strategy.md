This plan involves money.

## Currencies

- **EUR:** Primary currency for EU budget allocation, programme-level disbursement, milestone payments, carrier co-funding and consolidated financial reporting. Covers most priority corridors and eurozone operations.
- **DKK:** Copenhagen–Hamburg–Berlin corridor; DSB and Danish regional operators; local capacity building and hub operations in Denmark.
- **SEK:** Swedish railways (SJ) and TEN-T network extensions into Sweden; local procurement and capacity building in Sweden.
- **CHF:** Wien–München–Zürich corridor; SBB (Swiss Federal Railways) and Swiss carrier operations; local contracting and hub operations outside the eurozone.
- **PLN:** Poland's TEN-T network extension and carrier participation; national regulator capacity building and later-phase corridor rollout.
- **CZK:** Czechia's TEN-T participation and regional carrier operations; local procurement and capacity building in central Europe.
- **HUF:** Hungary's TEN-T network and carrier integration; central European capacity building and procurement.
- **BGN:** Bulgaria's TEN-T participation and later-phase rollout; national capacity building in southeast Europe.
- **RON:** Romania's TEN-T network extension and carrier participation; southeast European capacity building and procurement.

**Primary currency:** EUR

**Currency strategy:** EUR is used as the consolidated reporting and settlement currency for all public disbursements, milestone payments and programme-level accountability. Non-eurozone transactions (local procurement, regional hub operations, smaller carrier co-funding, national capacity building in Denmark, Sweden, Switzerland, Poland, Czechia, Hungary, Bulgaria and Romania) occur in local currencies and are budgeted and tracked in EUR equivalents using fixed monthly conversion rates to prevent currency fluctuation from consuming the fixed €1.5 billion budget (user constraint). Accredited payment institutions selected under the Pragmatic Foundation scenario handle multi-currency refunds and carrier settlements; apportionment rules specify whether currency conversion costs are borne by the responsible carrier, distributor or a defined pool. No hedging or alternative currency arrangements are required; all transactions follow standard EU budget execution procedures and member-state reimbursement protocols.