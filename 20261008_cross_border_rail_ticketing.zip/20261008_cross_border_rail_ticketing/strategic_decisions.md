## Primary Decisions
The vital few decisions that have the most impact.


The Critical levers (access terms, clearing and settlement, funding allocation, legacy IT migration, governance) address the programme's core tensions: enforceable openness versus incumbent buy-in, central versus federated risk, a fixed budget versus carrier readiness, and decision authority versus the Month 18 (2028-04-08) deadline. High levers refine delivery, rights, data and fares. No major dimension is missing, though consumer-facing rollout and communication are only lightly covered.

### Decision 1: OSDM Access Terms and Enforcement Model
**Lever ID:** `3356b1d1-4008-4b3c-8245-318c0e4cc69d`

**The Core Decision:** Defines what "non-discriminatory" access to inventory, fares and post-sale functions means in practice, who audits it, and what sanctions apply. Success is measured by time-to-onboard for a new distributor, inventory parity and API latency against carriers' own channels, and the share of distributor complaints resolved. The choice sets the credibility of the Month 30 (2029-04-08) mandatory API exposure milestone.

**Why It Matters:** This lever sets how non-discriminatory distributor access to real-time inventory, fares and post-sale operations is defined and enforced. Tight, regulator-audited terms speed distributor onboarding and support the goal of halving complaints, but they raise compliance cost and legal friction for incumbents. Looser, negotiated terms win early carrier buy-in but leave room for the discriminatory practices the proposed regulation is meant to end.

**Strategic Choices:**

1. Mandate a single regulated reference price and service-level schedule for API access, enforced by national regulators with EU Agency for Railways audit rights over inventory parity and latency.
2. Let carriers publish their own FRAND-style access terms within a common template, with a complaints-driven review by regulators and penalties only after repeated findings of discrimination.
3. Tie API access terms to a certification scheme under which distributors earn tiered inventory access by meeting conformance and consumer-protection tests, with carriers able to audit distributors in return.

**Trade-Off / Risk:** A regulated price schedule gives distributors certainty, but fixing terms before the legislation is final and before real cost data exists risks mispricing access, and national regulators differ widely in resources and appetite to enforce.

**Strategic Connections:**

**Synergy:** Strengthens Competition-Law Firewalls for Shared Fare and Inventory Data by giving data-sharing clear rules, and works with Member-State Regulator Capacity and Cross-Border Enforcement Cooperation, since auditable terms only deter discrimination if regulators can enforce them.

**Conflict:** Strict, regulator-audited terms strain Funding Allocation and Carrier Incentives, because incumbents bear compliance costs and may demand compensation. They also pull against Legacy Carrier IT Migration Pathway, where slower carriers cannot yet meet parity and latency obligations.

**Justification:** *Critical*, Critical because it defines non-discriminatory access, the core of the regulation, and sets the credibility of the Month 30 (2029-04-08) API milestone. It links to competition firewalls, regulator capacity, funding and legacy migration, and controls the compliance-cost versus carrier buy-in trade-off.

### Decision 2: Clearing and Settlement Architecture
**Lever ID:** `562282e0-88fd-478f-b1b7-4f2d657224bb`

**The Core Decision:** Chooses the money-flow backbone for single-payment through-tickets: who holds passenger funds, how revenue is apportioned across carriers, and how refunds are reversed. Key metrics are settlement cycle time, refund turnaround, dispute rate and default exposure. The choice drives trust among carriers and distributors, and it sets licensing, capital and governance needs that can lengthen the critical path.

**Why It Matters:** This lever determines how revenue from a single payment is split across carriers and how refunds are reversed. A central public clearing house gives uniform rules and visibility but concentrates operational and credit risk in one entity. A federated model reuses existing bilateral settlement between carriers and is quicker to start, but it leaves reconciliation disputes and refund delays that undermine through-ticket confidence.

**Strategic Choices:**

1. Establish a single publicly governed clearing entity that receives passenger payments, applies agreed apportionment rules and pays carriers on a fixed cycle, with a guarantee fund for defaults.
2. Extend existing bilateral and multilateral carrier settlement arrangements with a common message standard and an independent dispute-resolution body, avoiding any new central payment entity.
3. Contract regulated payment institutions to run split-payment and refund orchestration as a competitive service, with carriers choosing among accredited providers that meet common settlement rules.

**Trade-Off / Risk:** Central clearing simplifies refunds and apportionment, but it demands licensing, capital and carrier trust that take years to build and could delay the Month 30 (2029-04-08) API mandate if made a precondition.

**Strategic Connections:**

**Synergy:** Enables Passenger-Rights Backstop and Liability Allocation, since fault-based reimbursements and pooled guarantees run through the clearing mechanism, and supports Through-Fare Composition and Reduction Card Rules by providing the apportionment logic for split revenue.

**Conflict:** A central clearing entity competes with Programme Governance Vehicle and Decision Rights for institutional design and risk ownership. Making it a precondition could delay Corridor Sequencing and Onboarding Gates and the Month 30 (2029-04-08) API mandate.

**Justification:** *Critical*, Critical because it is the money-flow backbone for single-payment through-tickets. It enables the passenger-rights backstop and fare apportionment, and it sets licensing and capital needs that can lengthen the critical path to Month 30 (2029-04-08). It controls the central-versus-federated risk trade-off.

### Decision 3: Funding Allocation and Carrier Incentives
**Lever ID:** `26395e1c-310a-4258-92c2-0f80537b7c92`

**The Core Decision:** Determines how the €1.5 billion public budget (user constraint) is divided among standards, conformance testing, the clearing mechanism, the public reference distributor, capacity building and carrier co-funding. Key metrics are the share of funds reaching smaller carriers, disbursement tied to API and data-quality milestones (Months 18 and 30 = 2028-04-08, 2029-04-08), additionality of subsidies against private IT spend, and avoidance of paying for work already planned.

**Why It Matters:** This lever sets how the €1.5 billion public budget (user constraint) is split between standards, shared infrastructure, public distribution, capacity building and direct co-funding of carrier integration. Subsidising carrier IT work reduces resistance and speeds up integration but could duplicate private investment that carriers must fund anyway. Concentrating on shared infrastructure keeps public money visible but leaves smaller carriers unable to comply.

**Strategic Choices:**

1. Reserve most of the budget for shared infrastructure, conformance testing and the clearing mechanism, leaving carrier-side integration to be funded privately under the mandate.
2. Make a significant portion of the budget available as milestone-based co-funding for carriers, prioritising smaller and state-weak operators, conditional on meeting API and data-quality deadlines.
3. Hold back a competitive pool of funds that carriers and distributors bid for to deliver jointly proposed integration projects, with payment tied to verified through-ticket volumes.

**Trade-Off / Risk:** Co-funding carrier integration lowers adoption barriers, but it risks subsidising work that incumbents would have to do anyway, while volume-linked payments reward corridors that were already succeeding.

**Strategic Connections:**

**Synergy:** Amplifies Legacy Carrier IT Migration Pathway, since milestone co-funding can finance gateway or hub onboarding for weaker operators. Also strengthens Corridor Sequencing and Onboarding Gates, because payments can be released only when readiness gates are passed.

**Conflict:** Competes with Role of the Public Reference Distributor and Clearing and Settlement Architecture for a fixed budget; generous carrier co-funding leaves less for shared infrastructure, while volume-linked payments may favour corridors that were already succeeding.

**Justification:** *Critical*, Critical because it allocates the fixed €1.5 billion budget (user constraint) across clearing, distributor, standards and carrier co-funding. It is a hub that competes with other levers for money and releases payments against gates and milestones, controlling the cost versus scope trade-off.

### Decision 4: Legacy Carrier IT Migration Pathway
**Lever ID:** `1a590841-cc26-4b57-b4a4-02fa39c06ba1`

**The Core Decision:** Chooses how carriers with ageing booking back-ends reach the standard OSDM-compatible interface: native builds, a public gateway or regional hubs. It sets the size of the private IT bill, the pace at which the long tail of operators joins before the mandatory API date (Month 30 = 2029-04-08), and operational dependency on gateway or hub operators. Metrics are carriers conformant by deadline and migration cost per carrier.

**Why It Matters:** Carriers differ greatly in the age and openness of their booking back-ends, so the migration route sets both the private IT bill and how quickly the long tail of smaller operators can join. Forcing native implementations preserves carrier control but leaves weaker operators behind. Shared adapters reduce effort but create a dependency on whoever operates them.

**Strategic Choices:**

1. Require every carrier to build and operate its own native interface, using public funds only for standards work and testing, and accept uneven readiness among smaller operators.
2. Fund a publicly hosted gateway that translates legacy carrier systems into the standard interface, which smaller carriers can use until they modernise their back-ends.
3. Offer regional shared booking-service hubs, run by consortia of neighbouring carriers or by procured third-party operators, that host inventory and fare logic for several carriers behind one interface.

**Trade-Off / Risk:** A shared gateway lowers the entry barrier for smaller carriers, but it risks becoming a permanent crutch and a single point of failure, undermining the incentive to modernise that the mandatory API date is meant to create.

**Strategic Connections:**

**Synergy:** Works with Funding Allocation and Carrier Incentives, which can subsidise gateway or hub use, and with OSDM Access Terms and Enforcement Model, because a translation layer lets smaller carriers meet non-discriminatory access duties on time.

**Conflict:** Shared gateways or hubs can weaken the modernisation incentive behind OSDM Access Terms and Enforcement Model. They also create a single point of failure that undermines Real-Time Inventory and Disruption Data Model quality commitments.

**Justification:** *Critical*, Critical because the slowest carrier back-ends constrain corridor gates, data freshness, access obligations and ticket validation. The choice between native builds, a gateway and hubs sets the private IT bill and whether the Month 30 (2029-04-08) mandate is achievable.

### Decision 5: Programme Governance Vehicle and Decision Rights
**Lever ID:** `1771a340-d031-467b-8348-a1a87115d3f2`

**The Core Decision:** Sets who holds binding decision rights over standards, conformance and funding disputes, and how fast contested technical choices are settled. The choice shapes legal set-up time before the Month 18 (2028-04-08) standards milestone, accountability for the €1.5 billion public budget (user constraint), and incumbents' ability to stall. Metrics: dispute resolution time, milestone adherence and stakeholder trust.

**Why It Matters:** Choosing who holds binding decision rights (the Commission directly, a dedicated joint body, or an agency-hosted board) determines how quickly standards disputes between carriers and distributors are resolved. A heavier vehicle adds legal set-up time before the Month 18 (2028-04-08) standards milestone, while a lighter one risks lacking authority when large incumbents resist.

**Strategic Choices:**

1. Run the programme from DG MOVE with the EU Agency for Railways as technical secretariat, using advisory working groups and keeping all binding decisions inside existing EU institutional procedures.
2. Establish a dedicated joint undertaking with carrier, distributor and consumer seats, giving it its own budget authority, staff and a tie-breaking mechanism for contested technical decisions.
3. Create a small independent standards arbitration panel with time-boxed rulings, layered on top of existing institutions, so disputes resolve quickly without building a full new legal entity.

**Trade-Off / Risk:** A dedicated body gives clearer accountability and budget control, but its legal creation can consume the first year, whereas reusing existing institutions starts faster yet leaves incumbents able to stall contested decisions.

**Strategic Connections:**

**Synergy:** Provides the authority that makes OSDM Access Terms and Enforcement Model and Corridor Sequencing and Onboarding Gates enforceable, and gives Funding Allocation and Carrier Incentives a clear budget holder to release payments against milestones.

**Conflict:** A heavier vehicle's set-up time conflicts with the Month 18 (2028-04-08) standards deadline and delays Corridor Sequencing and Onboarding Gates; a lighter one leaves it dependent on Member-State Regulator Capacity and Cross-Border Enforcement Cooperation for real enforcement.

**Justification:** *Critical*, Critical because it sets who can bind incumbents, resolve standards disputes and hold the €1.5 billion budget (user constraint). It makes access terms and gating enforceable, and its set-up time directly threatens the Month 18 (2028-04-08) standards milestone.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Role of the Public Reference Distributor
**Lever ID:** `64d93888-c3bb-4a65-810d-da8fb4b8aa70`

**The Core Decision:** Sets the mandate, scale and lifespan of the publicly funded distributor: neutral benchmark, full retail channel or last-resort service. It determines the budget share absorbed by consumer-facing operations, long-term operating liability, and the signal sent to commercial platforms. Metrics include conformance reuse by small operators, accessibility-assisted bookings served, and through-ticket share attributable to the public channel.

**Why It Matters:** This lever decides whether the publicly funded distributor is a neutral benchmark, a full consumer-facing retail service, or a fallback. A full retail service gives travellers a direct, rights-compliant channel and can show what good looks like. It also risks crowding out Trainline, Omio and similar platforms, whose cooperation is needed to reach the 40% through-ticket share, and it creates a long-term operating liability.

**Strategic Choices:**

1. Build the reference distributor as a fully branded consumer booking service funded from the programme budget and operated by a dedicated public entity, with a sunset review once market share is reached.
2. Limit it to an open-source reference implementation and a conformance sandbox that commercial distributors and small operators can reuse, with no direct consumer sales.
3. Run it as a consumer service of last resort that sells only the corridor itineraries and accessibility-assisted journeys that commercial distributors decline to carry, funded by a per-ticket levy.

**Trade-Off / Risk:** A public retail service shows regulatory seriousness, but if it competes directly with commercial distributors the program risks losing their cooperation, while a code-only reference does little for passengers who need a trustworthy channel.

**Strategic Connections:**

**Synergy:** Amplifies Assistance Booking and Accessibility Integration, since a public channel can serve assisted journeys that commercial sellers decline, and supports OSDM Access Terms and Enforcement Model by showing what compliant access and conformance testing look like.

**Conflict:** A full retail service competes with commercial distributors and strains Funding Allocation and Carrier Incentives by drawing budget into running costs. It also risks Competition-Law Firewalls for Shared Fare and Inventory Data if its privileged data access looks discriminatory.

**Justification:** *Medium*, Matters for budget share and the signal sent to Trainline and Omio, but it is an optimisation of one channel. It is less central than the access, settlement and funding levers, and its main effects run through them.

### Decision 7: Corridor Sequencing and Onboarding Gates
**Lever ID:** `a612a767-6705-46c6-9709-af45f933b2f9`

**The Core Decision:** Controls the order, pace and entry criteria for going live on Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich, Madrid–Barcelona–Lyon and Copenhagen–Hamburg–Berlin. It balances credible journey continuity against momentum. Metrics include carriers passing conformance on schedule, share of corridor itineraries bookable end to end, and clarity of what travellers can buy. It also decides how early learning feeds the later TEN-T extension.

**Why It Matters:** This lever sets the order and pace of corridor rollout and what carriers must pass before going live. Holding the four starting corridors to strict gates builds a credible base, but waiting for the weakest carrier can stall momentum. Letting the fastest carriers go first yields early results but can create a two-speed network in which the through-ticket works only on parts of a journey.

**Strategic Choices:**

1. Launch the four named corridors together under common gates, so that no corridor goes live until every carrier on it passes conformance and settlement integration tests.
2. Go live corridor by corridor as each reaches readiness, starting with the one with the most advanced OSDM implementations, and use its results to set gates for the others.
3. Start with a small number of high-demand city pairs across several corridors, selected on competition with short-haul air, and expand along routes once through-ticket volumes show demand.

**Trade-Off / Risk:** Gating by weakest carrier protects journey continuity, but a single slow operator can hold up every corridor, while staggered launches make it harder to explain to travellers what is actually bookable.

**Strategic Connections:**

**Synergy:** Works with Outcome Measurement, Baselines and Attribution, since staged launches create comparable early data, and with Funding Allocation and Carrier Incentives, since funding can be tied to passing gates and rewarding readiness.

**Conflict:** Strict common gates collide with Legacy Carrier IT Migration Pathway, as the slowest carrier holds up every corridor. Staggered or city-pair launches conflict with Through-Fare Composition and Reduction Card Rules, because partial coverage complicates consistent fares and traveller messaging.

**Justification:** *High*, Governs the momentum versus journey-continuity trade-off and links to legacy migration, funding release, measurement and fare consistency. It is largely a downstream delivery lever that depends on governance and funding choices, so it ranks High rather than Critical.

### Decision 8: Passenger-Rights Backstop and Liability Allocation
**Lever ID:** `24c81358-0ae3-43a8-9ff9-f2b64e410eba`

**The Core Decision:** Allocates responsibility and funding for rerouting, care and refunds when a missed connection occurs on a multi-carrier through-ticket. It must align with the revised EU rail passenger rights rules and give travellers one clear promise. Metrics include time to reroute or refund, claim dispute rate, distributor willingness to sell risky itineraries, and backstop cost per ticket sold.

**Why It Matters:** This lever determines who is responsible when a missed connection occurs on a through-ticket sold by a third party covering several carriers. A single point of liability and a guaranteed rerouting or refund gives travellers real protection but must be funded and must be reconciled with the revised rail passenger rights rules. Distributing liability among carriers keeps costs with the cause of the delay but weakens the passenger-facing promise.

**Strategic Choices:**

1. Make the selling distributor the single point of contact for rerouting and refunds, with carriers reimbursing it through the clearing mechanism according to a fixed fault-allocation schedule.
2. Fund a pooled EU-level guarantee mechanism that pays out to passengers first and then recovers costs from the responsible carriers, administered alongside the clearing entity.
3. Assign the first carrier on the through-ticket as accountable for the whole journey, with national enforcement bodies handling complaints in that carrier's home state.

**Trade-Off / Risk:** A single point of contact is easy for passengers to understand, but without a funded way of recovering costs from the carriers at fault, distributors may decline to sell risky itineraries or carriers may contest every claim.

**Strategic Connections:**

**Synergy:** Builds on Clearing and Settlement Architecture, which provides the reimbursement and recovery channel, and reinforces Real-Time Inventory and Disruption Data Model, since reliable disruption data lets fault be allocated and rerouting triggered quickly.

**Conflict:** A strong single-contact or pooled guarantee increases financial exposure, tensioning with Funding Allocation and Carrier Incentives, and may clash with Member-State Regulator Capacity and Cross-Border Enforcement Cooperation, as national bodies interpret rights and fault differently.

**Justification:** *High*, Delivers the continuity-of-journey promise that makes through-tickets trustworthy and sets financial exposure. It depends on clearing and disruption data and tensions with funding and regulator consistency, so it has many strong interactions, but it builds on upstream choices.

### Decision 9: Through-Fare Composition and Reduction Card Rules
**Lever ID:** `f3c80ae9-6a26-4bb0-af61-d6d24fc3ab81`

**The Core Decision:** Sets how prices from several carriers become one through-fare, and how national reduction cards are recognised across borders. It decides whether passengers see a single, competitive price against airlines and how much pricing freedom carriers keep. Metrics include through-fare price versus competing air fares on priority corridors, reduction-card recognition coverage, and the revenue shifts passed to clearing.

**Why It Matters:** Rules for assembling a through-fare from several carriers' prices decide whether passengers see one price that competes with a flight. They also set how much pricing freedom carriers keep. Recognising reduction cards across borders adds appeal but shifts revenue between carriers, which the clearing mechanism then has to absorb.

**Strategic Choices:**

1. Allow through-fares to be the sum of each carrier's segment price, with only a transparency duty requiring the total and its breakdown to be shown before purchase.
2. Designate a lead carrier per journey that sets one through-fare under agreed apportionment rules, with the lead carrier bearing the pricing risk across the other segments.
3. Introduce a regulated cross-border fare product with a ceiling tied to distance bands on priority corridors, and require mutual recognition of national reduction cards at a defined discount.

**Trade-Off / Risk:** A summed-segment model is easiest to adopt but rarely beats airline pricing on competitive short-haul routes, while regulated fare ceilings could achieve the modal-shift goal yet invite competition-law challenge and carrier resistance.

**Strategic Connections:**

**Synergy:** Supports the 40% through-ticket target when combined with Clearing and Settlement Architecture, which can apportion revenue automatically, and with Outcome Measurement, Baselines and Attribution, which can show whether fare rules drive modal shift.

**Conflict:** Regulated fare ceilings or lead-carrier pricing collide with Competition-Law Firewalls for Shared Fare and Inventory Data, since coordinated pricing invites antitrust scrutiny. Reduction-card recognition also adds revenue-allocation load on Clearing and Settlement Architecture.

**Justification:** *High*, Determines whether passengers see a single competitive price against air fares, so it bears directly on the 40% and modal-shift targets. It trades carrier pricing freedom against antitrust risk and loads clearing, but it is narrower in scope than the foundation levers.

### Decision 10: Real-Time Inventory and Disruption Data Model
**Lever ID:** `6c3c7ad8-741d-48bb-9754-1963cc5f7790`

**The Core Decision:** Defines the architecture of the shared data layer: federated queries, a central availability cache or event-streamed disruption data. It governs search latency, accuracy of seat availability for distributors, speed of detecting missed connections for rights claims, and who bears data-quality liability. Metrics are search response time, oversell and booking-failure rates, and disruption-event latency.

**Why It Matters:** The shared data layer can hold inventory centrally, leave it with carriers behind federated queries, or stream events as they occur. This choice sets search speed, the accuracy of availability shown to distributors, and how quickly a missed connection is detected for rights purposes. Each model also changes who bears data-quality liability.

**Strategic Choices:**

1. Use federated queries in which each carrier keeps authoritative inventory and national access points route requests, accepting variable response times between operators.
2. Maintain a European availability cache that carriers feed continuously, so distributors search one fast source and only confirm final bookings with the carrier.
3. Build an event-streaming disruption mesh in which delays, cancellations and platform changes are published as they occur, with data quality commitments written into carrier access terms.

**Trade-Off / Risk:** A central cache gives distributors fast, uniform search, but stale availability turns into oversold seats and disputes, while federated queries avoid duplication yet let the slowest carrier define the passenger experience on every through-journey.

**Strategic Connections:**

**Synergy:** Feeds Passenger-Rights Backstop and Liability Allocation with timely missed-connection evidence, and supports Assistance Booking and Accessibility Integration by enabling live platform, lift and assistance updates for travellers with reduced mobility.

**Conflict:** A central cache or shared mesh raises concerns under Competition-Law Firewalls for Shared Fare and Inventory Data, because pooled commercial data can enable collusion. It also depends on Legacy Carrier IT Migration Pathway, since slow back-ends limit data freshness.

**Justification:** *High*, Defines the shared data layer architecture, which drives search quality, oversell rates and disruption evidence for rights claims. It feeds the backstop and accessibility, and it depends on legacy migration and the competition firewalls, making it a major technical hub.

### Decision 11: Ticket Format, Validation and Passenger Data Model
**Lever ID:** `5b18310c-0cc6-4816-b164-8513132f11a3`

**The Core Decision:** Specifies what a through-ticket is, how any carrier's staff or validators verify it on board, and what passenger data flows between carriers. It drives interoperability on trains, GDPR exposure and the cost of upgrading inspection devices. Metrics include ticket acceptance rate across carriers, validator coverage by deadline, validation performance in low-connectivity areas, and the volume of personal data shared.

**Why It Matters:** What a through-ticket physically is, and how it is checked on board, determines whether a passenger holding one ticket is accepted by every carrier's staff and validators. The same choice defines how much personal data moves between carriers, which brings GDPR obligations. A common format simplifies inspection but requires new validator software on many networks.

**Strategic Choices:**

1. Mandate a common offline-verifiable barcode ticket format that any carrier's handheld device can validate, with carriers given a transition period to update inspection equipment.
2. Link tickets to a digital identity wallet credential, so inspection checks the passenger's entitlement online and avoids passing full booking records between carriers.
3. Keep each carrier's native ticket format but require a standard machine-readable wrapper and a shared validation service that carriers query in real time on boarding.

**Trade-Off / Risk:** An offline barcode works in tunnels and border areas with weak coverage but needs broad device upgrades, while wallet-based or service-based validation reduces data sharing at the cost of dependence on connectivity on the very corridors being prioritised.

**Strategic Connections:**

**Synergy:** Enables Passenger-Rights Backstop and Liability Allocation by giving a verifiable single-ticket entitlement that proves continuity of journey, and supports Clearing and Settlement Architecture through reliable usage records for apportioning revenue.

**Conflict:** A mandated common barcode requires validator upgrades that compete for money with Funding Allocation and Carrier Incentives and burden Legacy Carrier IT Migration Pathway. Online wallet or service validation instead depends on connectivity along prioritised corridors, affecting Corridor Sequencing and Onboarding Gates.

**Justification:** *Medium*, Important for on-board acceptance and GDPR exposure, and it supports the backstop and clearing records. It is a largely technical standard choice with a contained set of conflicts (validator upgrade cost), so it is useful but not a core strategic driver.

### Decision 12: Assistance Booking and Accessibility Integration
**Lever ID:** `1747a9ca-836b-49cd-bd26-b7907b8f9425`

**The Core Decision:** Defines how passengers with reduced mobility request, receive confirmation of and rely on assistance within a through-ticket purchase. Scope covers request formats, response windows, cross-border handovers between carriers and stations, and accessibility data. Success metrics: share of requests confirmed before payment, share of confirmed assistance actually delivered on the platform, and accessibility-related complaint rates.

**Why It Matters:** How assistance for persons with reduced mobility is requested and confirmed through the booking flow determines whether through-tickets are usable by those passengers. Treating it as a core booking step increases cost and complexity for carriers. Treating it as an add-on keeps rollout simple but risks leaving the group out of the through-ticket benefit.

**Strategic Choices:**

1. Make assistance requests a mandatory field in the standard booking interface, with each carrier required to confirm or reject within a defined response window before payment completes.
2. Establish a single European assistance coordination desk that receives requests from all distributors and arranges handovers between carriers and stations across borders.
3. Publish a station and rolling-stock accessibility registry through the data layer, so distributors can offer only itineraries whose transfers and vehicles match the passenger's declared needs.

**Trade-Off / Risk:** Embedding assistance in the booking step gives certainty before payment, but it depends on station staffing that this program funds only indirectly, so a confirmed request can still fail on the platform.

**Strategic Connections:**

**Synergy:** Amplifies Real-Time Inventory and Disruption Data Model by feeding accessibility and assistance status into the shared data layer, and strengthens Passenger-Rights Backstop and Liability Allocation by giving a clear record of confirmed assistance obligations.

**Conflict:** Mandatory confirmation windows add cost and latency for carriers, trading off against Funding Allocation and Carrier Incentives, and may slow Legacy Carrier IT Migration Pathway where older systems cannot return timely confirmations.

**Justification:** *Medium*, Essential for inclusion and a stated scope item, but it is a feature-level lever. Its connections to the data layer, backstop and funding are real but limited, and it does not govern the programme's main structural trade-offs.

### Decision 13: Competition-Law Firewalls for Shared Fare and Inventory Data
**Lever ID:** `7236cb11-ae18-4988-a1d5-2c201a5f57f1`

**The Core Decision:** Determines what commercially sensitive data (fares, load factors, sales volumes) the shared layer may expose among competing carriers, and the safeguards that keep it pro-competitive rather than a facilitator of coordination. It sets the usable data depth for distributors and the legal risk for participants. Metrics: regulator acceptance, absence of antitrust challenges, and distributor data usability.

**Why It Matters:** A shared real-time data layer exposes commercially sensitive fares, load factors and sales volumes among carriers that also compete. The safeguards chosen determine whether regulators view the layer as pro-competitive access or as a facilitator of coordination, and how much data distributors can actually use.

**Strategic Choices:**

1. Restrict shared data to the minimum needed for booking and clearing, with aggregated or delayed reporting for any competitively sensitive fields, validated by an upfront competition-authority consultation.
2. Place the data layer under an independent neutral operator that holds carrier data in segregated form and publishes audited access logs, so no carrier sees another's commercial inputs.
3. Seek a formal block-exemption-style clearance from the Commission for the full data-sharing scheme, accepting a longer legal lead time in exchange for durable certainty for all participants.

**Trade-Off / Risk:** Tight data minimisation lowers antitrust risk but can starve distributors of the inventory detail needed for good through-fare offers, while broad sharing improves search quality at the cost of enforcement exposure.

**Strategic Connections:**

**Synergy:** Gives legal certainty to OSDM Access Terms and Enforcement Model and Clearing and Settlement Architecture, since clear data boundaries let carriers join without fearing antitrust exposure, and supports the neutral positioning of Role of the Public Reference Distributor.

**Conflict:** Tight minimisation limits the detail available to Real-Time Inventory and Disruption Data Model and Through-Fare Composition and Reduction Card Rules, weakening search quality, while formal clearance routes lengthen lead time against the Month 18 (2028-04-08) standards target.

**Justification:** *High*, Sets the legal feasibility of the shared data layer and trades antitrust safety against data usability. It gives certainty to access terms, clearing and the data model, but its effect is mostly as an enabling constraint rather than a primary driver.

### Decision 14: Outcome Measurement, Baselines and Attribution
**Lever ID:** `9022ccc5-3420-4db6-a573-6d0a33ee3351`

**The Core Decision:** Establishes how the programme's three headline targets (40% through-ticket share, halved distributor complaints, modal shift from air) are baselined, defined, tracked and attributed. It fixes what counts as a through-ticket, the data sources and the evaluation design. Metrics: baseline set early, methodology acceptance by stakeholders, and timely triggers for mid-course correction.

**Why It Matters:** The programme targets a 40% through-ticket share, halved distributor complaints and modal shift from air, yet cross-border sales data are fragmented and no common baseline is assumed to exist. The measurement approach determines whether results can be credibly attributed to the programme, and whether mid-course corrections are triggered early enough.

**Strategic Choices:**

1. Define the baseline in the first months through mandatory carrier and distributor reporting templates, then track the three headline targets quarterly using a single published methodology.
2. Commission an independent evaluator to build a counterfactual using comparison routes outside the rollout corridors, separating programme effects from fuel prices, aviation taxes and capacity changes.
3. Tie a portion of carrier incentive payments to audited through-ticket volumes and complaint resolution data, so reporting accuracy becomes a financial interest rather than a compliance burden.

**Trade-Off / Risk:** Counterfactual evaluation produces credible attribution of modal shift, but it takes longer and costs more, while simple self-reported tracking is quick yet vulnerable to definitional disputes over what counts as a through-ticket.

**Strategic Connections:**

**Synergy:** Supplies evidence that lets Funding Allocation and Carrier Incentives reward verified results, and informs Corridor Sequencing and Onboarding Gates by showing which corridors are performing and where expansion is justified.

**Conflict:** Mandatory reporting templates and audited volumes burden carriers during Legacy Carrier IT Migration Pathway, and counterfactual evaluation competes for budget and time with Member-State Regulator Capacity and Cross-Border Enforcement Cooperation.

**Justification:** *Medium*, Needed to define the through-ticket and verify the three headline targets, and it informs incentive payments and corridor expansion. It is an enabling and monitoring lever that does not shape the main delivery trade-offs.

### Decision 15: Member-State Regulator Capacity and Cross-Border Enforcement Cooperation
**Lever ID:** `3561617d-7835-4c9b-83f3-cd6cb00513a6`

**The Core Decision:** Aligns national regulators' capacity, procedures and cooperation so access, refund and accessibility duties are enforced consistently across borders. Options range from training and twinning to a lead-authority network or agency-level mediation. Metrics: time to resolve discriminatory-access complaints, consistency of outcomes across states, and the number of cross-border cases escalated.

**Why It Matters:** National regulators will enforce access, refund and accessibility duties differently unless capacity and procedures are aligned. The cooperation model chosen affects consistency of enforcement across borders and how quickly a distributor's complaint about discriminatory access can be resolved.

**Strategic Choices:**

1. Fund bilateral twinning between stronger and weaker national regulators, with shared training and common inspection checklists, leaving enforcement decisions entirely with each national authority.
2. Create a standing network of regulators with a lead-authority rule for cross-border cases, so one regulator handles a dispute and its decision is recognised in all participating states.
3. Give the EU Agency for Railways a limited supervisory and mediation role over cross-border access disputes, with escalation to the Commission for repeated non-compliance by any carrier.

**Trade-Off / Risk:** A lead-authority network speeds cross-border resolution, but it needs mutual recognition that some member states may resist on sovereignty grounds, while twinning alone builds capacity without fixing inconsistent enforcement outcomes.

**Strategic Connections:**

**Synergy:** Gives real force to OSDM Access Terms and Enforcement Model and Passenger-Rights Backstop and Liability Allocation, because consistent national enforcement makes access and refund duties credible for distributors and passengers.

**Conflict:** Lead-authority recognition and agency supervisory roles may collide with sovereignty concerns and with the decision rights set in Programme Governance Vehicle and Decision Rights, risking overlapping or contested authority over disputes.

**Justification:** *High*, Determines whether access, refund and accessibility duties are enforced consistently across states, which gives force to access terms and the backstop. It involves sovereignty tensions with governance, so it carries significant systemic weight.
