## Primary Decisions
The vital few decisions that have the most impact.


The Critical and High levers address the program's core tensions: central control vs. carrier autonomy (clearing, availability architecture), risk-sharing vs. budget exhaustion (liability backstop, funding ladder), and coverage vs. quality (conformance gate). Fare construction, the public distributor and competition-law clearance decide whether commercial and legal acceptance follows. Medium and Low levers are largely execution layers. No major strategic dimension appears missing, though member-state capacity building and corridor sequencing are not explicitly covered.

### Decision 1: Through-Ticket Liability and Rights Backstop
**Lever ID:** `1d2d447b-fab1-4f1b-94cb-5926fcfc2c3c`

**The Core Decision:** Allocates financial and service responsibility when a protected connection fails across carriers, covering assistance, rerouting, compensation and cost recovery. Success metrics: share of missed-connection claims settled within a fixed window, number of carriers willing to expose cross-carrier connections, drawdown of any public fund against the €1.5 billion budget, and recovery rate from the responsible carrier. Precise recourse rules determine whether incentives reward punctuality.

**Why It Matters:** This decides who pays and who answers to the passenger when a connection between two carriers is missed on a single through-ticket. A pooled arrangement lowers the retail risk for distributors but requires carriers to accept shared exposure for delays they do not control. Whichever model is chosen sets the incentive for carriers to open inventory, because carriers refuse to sell connections whose liability they cannot price.

**Strategic Choices:**

1. Establish a carrier-funded mutual guarantee pool that pays assistance, rerouting and compensation on any through-ticket, with contributions weighted by each carrier's share of missed-connection incidents.
2. Make the selling distributor the single point of liability toward the passenger and require it to hold insurance, with contractual recourse against the carrier whose delay caused the missed connection.
3. Create a publicly capitalised rights backstop fund within the €1.5 billion budget that pays passengers immediately and later recovers costs from the responsible carrier through the clearing mechanism.

**Trade-Off / Risk:** A pooled or public backstop gives distributors certainty, but unless recourse rules are precise it rewards chronic late-running carriers, and any public fund that pays first can drain the budget before the later corridors are reached.

**Strategic Connections:**

**Synergy:** Amplifies Inter-Carrier Clearing and Single-Payment Settlement, since pool contributions and recourse claims can be netted through the same rails, and Disruption Re-accommodation Choreography, since settled liability lets rerouting proceed without disputes over who pays.

**Conflict:** Trades off against Milestone-Conditioned Funding Release Ladder, because a public pay-first fund draws on the budget needed for later corridors, and Through-Fare Construction Doctrine, because wider protected connections raise carrier exposure and invite resistance.

**Justification:** *Critical*, Hub deciding who pays when a connection fails; carriers will not expose connections whose liability they cannot price. Links to clearing, disruption handling and fare construction, and draws on the €1.5 billion budget, controlling the risk-sharing vs. budget-drain trade-off.

### Decision 2: Inter-Carrier Clearing and Single-Payment Settlement
**Lever ID:** `bebf01c8-c60c-4af4-a866-03db2fdc3463`

**The Core Decision:** Defines the financial plumbing that turns one passenger payment into correct carrier shares, reverses refunds across carriers and pays out on schedule. Scope includes netting, reconciliation formats, dispute resolution and settlement timing for carriers and independent distributors. Success metrics: settlement cycle time, reconciliation error rate, refund reversal completion time, and independent distributors' acceptance of the governance mandate. The choice also fixes how much cash and operational risk sits centrally.

**Why It Matters:** This determines how one passenger payment is split among several carriers and how refunds are reversed across them. A central clearing entity gives uniform rules and reconciliation, but concentrates operational risk and needs a governance mandate that carriers and independent distributors both accept. A split-at-source design reduces the amount held centrally but pushes more complexity onto payment providers and distributors.

**Strategic Choices:**

1. Build a single EU-level clearing entity that receives the passenger payment, nets positions across carriers and distributors, and pays out on a fixed schedule under a common rulebook.
2. Federate settlement through a shared netting and dispute-resolution layer that connects existing bilateral and sector clearing arrangements, so carriers keep their current accounting flows.
3. Split payments at the point of sale through licensed payment service providers that allocate each fare component directly to the carriers, leaving the clearing layer to handle only refunds and disputes.

**Trade-Off / Risk:** A central clearing entity delivers uniform rules but becomes a single point of failure and a governance fight; the federated option is quicker to launch but may leave refund reversals inconsistent across carriers.

**Strategic Connections:**

**Synergy:** Enables Through-Fare Construction Doctrine, since apportionment rules need a settlement engine to execute them, and Distribution Remuneration and Commission Corridor, since distributor commissions can be deducted and reported automatically at payout.

**Conflict:** Strains Joint Conduct Safe-Harbour for Shared Data and Clearing, because centralised netting concentrates commercially sensitive data and competition-law scrutiny, and Milestone-Conditioned Funding Release Ladder, because a central entity front-loads capital and governance effort before corridors prove value.

**Justification:** *Critical*, Financial backbone enabling single-payment through-tickets, refund reversal, fare apportionment and commission netting. Many levers (fare construction, remuneration, liability recourse) depend on it; it also fixes central vs. federated risk and governance concentration.

### Decision 3: Public Reference Distributor Mandate
**Lever ID:** `66907c16-7bdd-4a30-bd78-d40dd776eeb3`

**The Core Decision:** Determines the role of the publicly funded booking service: neutral consumer channel, technical benchmark, or distributor of last resort. It shapes how much of the €1.5 billion goes to consumer apps, multilingual support and complaint handling versus sandbox tooling. Success metrics: share of through-tickets sold via the service, journeys purchasable somewhere on participating carriers, complaint resolution time, and absence of successful competition-law challenges from commercial distributors.

**Why It Matters:** This defines what the public booking service is for: a market competitor, a fallback, or a compliance benchmark. A full consumer app gives passengers a trusted neutral channel but competes with Trainline, Omio and carrier channels, which invites competition-law complaints. A narrower role limits that risk but may do little for the 40% through-ticket target.

**Strategic Choices:**

1. Operate a full consumer-facing public booking service in all EU languages with complaint handling, positioned as a neutral channel alongside commercial distributors.
2. Run a business-to-business reference implementation and sandbox that demonstrates correct OSDM use, with consumer sales left to commercial distributors under common rules.
3. Tender a distributor-of-last-resort concession that guarantees any journey on participating carriers can be bought somewhere, with a private operator running the service under public service-level terms.

**Trade-Off / Risk:** A full public app guarantees a neutral channel but risks displacing private distributors it relies on for volume; a sandbox-only role is safer legally yet may not move passenger behaviour toward through-tickets.

**Strategic Connections:**

**Synergy:** Amplifies Conformance Gate and Carrier Onboarding Support, since a reference implementation and sandbox gives carriers a test bed, and Assistance and Bicycle Reservation Chaining, since a public channel can set the benchmark for accessible booking flows.

**Conflict:** Conflicts with Distribution Remuneration and Commission Corridor, because a publicly funded channel selling at low or zero commission can undercut commercial distributors, and with Milestone-Conditioned Funding Release Ladder, because consumer app costs compete for tranche-limited budget.

**Justification:** *High*, Defines the public channel's role and the budget share spent on consumer apps. Governs the trade-off between driving the 40% through-ticket target and competition-law and commercial-distributor backlash; conflicts with remuneration and funding levers.

### Decision 4: Milestone-Conditioned Funding Release Ladder
**Lever ID:** `861f756d-bdec-40fb-bb4a-6b27ecc926a1`

**The Core Decision:** Controls the timing and conditions under which the €1.5 billion public coordination budget (user constraint) reaches carriers, member-state bodies and shared infrastructure. It is the program's main compliance leverage over actors the Commission cannot otherwise direct. Success metrics are the share of budget disbursed against verified deliverables, the time from milestone to payment, and the number of carriers that start work because of the funding.

**Why It Matters:** Governs how the public coordination budget flows to carriers, member-state bodies and the shared infrastructure: upfront grants, verified milestones or measured outcomes. Conditional release gives leverage over compliance but starves carriers that need cash to start IT work, while unconditional grants speed starts and weaken leverage.

**Strategic Choices:**

1. Release funds in tranches tied to verified technical milestones, such as conformance certificates and live API exposure, paid to carriers and member-state bodies on verification.
2. Pool funds in a competitive call where carriers and distributors co-finance corridor integration projects, ranked by expected through-ticket volume and passenger benefit.
3. Reserve a large share for outcome-based payments released only after measured through-ticket sales and complaint reductions appear, requiring carriers to pre-finance the work.

**Trade-Off / Risk:** Outcome-based payment aligns money with the success metrics, but carriers that must pre-finance IT work at their own risk may simply decline, leaving the public budget unspent on the corridors that matter most.

**Strategic Connections:**

**Synergy:** Uses certificates from the Conformance Gate and Carrier Onboarding Support as payment triggers, which gives the gate real consequences, and gives the Public Reference Distributor Mandate a predictable funding profile.

**Conflict:** Conflicts with the Specification Custodian Seat for OSDM Evolution, because formal change cycles can delay the milestones that release payments, and with the Public Reference Distributor Mandate, which competes for the same fixed budget.

**Justification:** *Critical*, Main compliance leverage over actors the Commission cannot direct; controls how the €1.5 billion reaches carriers and bodies. Conflicts with liability, clearing, reference distributor and specification levers, governing the leverage vs. carrier-cash-need trade-off.

### Decision 5: Availability Query Topology and Authoritative Booking Source
**Lever ID:** `1c8c4cd2-6e94-46f5-8396-570f3f180f7e`

**The Core Decision:** Chooses the architecture for search and purchase: where availability is held, who confirms the sale, and how the system degrades when a carrier endpoint fails. It determines search latency, strain on legacy carrier inventory systems and sell-through error rates. Metrics: response time for multi-carrier itineraries, stale-seat booking failures, outage resilience and integration effort per distributor.

**Why It Matters:** How distributors learn which seats and fares exist, and who confirms a sale, sets latency, load on legacy carrier systems and resilience during outages. A central exchange simplifies distributor integration but creates a single point of failure and governance contention. A federated model keeps carriers in control but multiplies integration effort and makes through-ticket pricing slower.

**Strategic Choices:**

1. Build a central inventory exchange that carriers feed continuously, so distributors query one endpoint and carriers retain only final booking authority.
2. Keep inventory federated at each carrier, with distributors querying carrier OSDM endpoints directly through a shared routing and discovery registry that the program operates.
3. Publish an event-streamed availability shadow for search, treat each carrier's booking engine as sole authority at purchase, and degrade to scheduled-only offers whenever a carrier endpoint is unavailable.

**Trade-Off / Risk:** Cached or centralised availability makes search fast but invites sell-through errors on stale seats, whereas direct federated queries are accurate yet expose the search experience to the slowest legacy carrier system on any itinerary.

**Strategic Connections:**

**Synergy:** Enables Conformance Gate and Carrier Onboarding Support by defining a concrete endpoint contract to test against, and underpins Disruption Re-accommodation Choreography, which needs fast, trustworthy real-time inventory to reroute stranded passengers.

**Conflict:** Collides with Joint Conduct Safe-Harbour for Shared Data and Clearing, since a central exchange pooling competitors' live inventory heightens competition-law exposure, and slows Through-Fare Construction Doctrine when federated queries wait on the slowest carrier.

**Justification:** *Critical*, Foundational architecture choice for search and purchase, setting latency, sell-through errors, resilience and legacy-system load. Underpins conformance testing and disruption rebooking, and carries competition-law exposure for a central exchange; hard to reverse once built.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Conformance Gate and Carrier Onboarding Support
**Lever ID:** `c606999a-541a-4bab-8aef-7fea6fb8bd78`

**The Core Decision:** Sets the admission test carriers must pass before exposing inventory through OSDM-compatible APIs, and who pays to modernise legacy booking systems. Covers certification scope, test environments, tiering, adapter funding and enforcement. Success metrics: share of participating carriers connected by the mandatory API exposure milestone (Month 30 = 2029-04-12), certification turnaround time, post-onboarding API availability and booking-error rates, and public spend per connected carrier.

**Why It Matters:** This determines how carriers prove they meet the standard and who pays to modernise legacy booking systems. Strict certification protects distributors and passengers but can exclude smaller carriers with older systems, delaying full TEN-T coverage. Subsidised adapters widen participation but consume part of the €1.5 billion that is separate from the larger private carrier IT investment.

**Strategic Choices:**

1. Require independent conformance certification before any carrier may expose inventory, with a published pass list and no public co-funding of carrier systems.
2. Certify carriers in tiers by size and system age, and co-fund shared adapter modules that let smaller operators connect legacy back-ends without full replacement.
3. Replace upfront certification with a live-performance regime that publishes each carrier's API availability, latency and booking-error rates, and attaches penalties to repeated underperformance.

**Trade-Off / Risk:** Hard certification gates protect quality but may leave small carriers outside the network; shared adapters broaden coverage yet make the public budget responsible for technical debt that carriers would otherwise carry themselves.

**Strategic Connections:**

**Synergy:** Amplifies Specification Custodian Seat for OSDM Evolution, since a stable, versioned specification gives certification a clear target, and Availability Query Topology and Authoritative Booking Source, since conformance tests can verify authoritative-inventory behaviour.

**Conflict:** Trades off against Milestone-Conditioned Funding Release Ladder, since adapter subsidies draw on funds while slow small-carrier onboarding can stall releases, and Through-Fare Construction Doctrine, since strict gates leave coverage gaps in through-fare routes.

**Justification:** *High*, Controls how many carriers actually connect by the Month 30 (2029-04-12) mandatory API milestone and who funds legacy modernisation. Trades coverage against quality and ties to funding triggers, the specification and the availability architecture.

### Decision 7: Air-to-Rail Competitiveness Package
**Lever ID:** `6d14cef1-1b7d-4919-93fa-e30e10e00321`

**The Core Decision:** Targets the modal-shift objective by shaping how rail competes with short-haul flights on selected routes, using search presentation, intermodal products, fare commitments or reliability guarantees. Scope is limited to air-competitive corridors and depends on the through-ticketing stack for delivery. Success metrics: rail share on benchmarked air-competitive routes, conversion from neutral search results, price gap versus flights, and public cost per passenger shifted (estimate).

**Why It Matters:** This decides how the program tries to make rail the more attractive choice on short-haul routes where flights compete. Neutral display and intermodal tickets influence booking choices at low public cost, whereas fare commitments require carriers to accept margin risk. The measure of success is the shift in traveller behaviour, which depends on price and reliability as well as ticketing.

**Strategic Choices:**

1. Mandate neutral search results with emissions-based sorting and sell combined rail-air and rail-bus tickets, relying on information and convenience rather than price intervention.
2. Agree corridor-specific fare commitments with carriers for through-tickets, such as fare families and reduction-card recognition, co-funded for a limited introductory period.
3. Pair through-ticketing with a guaranteed-connection product where the selling platform automatically rebooks onto the next train or a replacement bus at no charge, making reliability the selling point.

**Trade-Off / Risk:** Display rules are cheap and quick but may not outweigh a lower flight fare; fare commitments change behaviour but create a subsidy dependency that may vanish once the introductory period ends.

**Strategic Connections:**

**Synergy:** Amplifies Disruption Re-accommodation Choreography, since a guaranteed-connection product relies on automated rebooking, and Through-Fare Construction Doctrine, since fare families and reduction-card recognition depend on clear through-fare rules.

**Conflict:** Conflicts with Distribution Remuneration and Commission Corridor, since fare commitments squeeze margins available for distributor commissions, and with Through-Ticket Liability and Rights Backstop, since guaranteed rebooking raises the liability exposure carriers must price.

**Justification:** *Medium*, Targets the modal-shift goal but is a downstream outcome lever that depends on the through-ticketing stack, fare rules and reliability. Important for the headline objective, yet less of a hub shaping the underlying system.

### Decision 8: Through-Fare Construction Doctrine
**Lever ID:** `025c9abb-298f-4439-b7fc-e4bbd20b4ee1`

**The Core Decision:** Determines the rule by which one through-ticket price is assembled from several carriers' legs, and therefore the passenger-visible price, the allocation of revenue between carriers, and the dispute load on clearing. Key metrics are the through-ticket price relative to stitched itineraries and air fares, the share of fares priced without manual negotiation, and the number of fare-allocation disputes per period.

**Why It Matters:** Sets how a single through-ticket price is built from several carriers' legs: summed leg fares, a corridor tariff, or composed bundles. The choice drives whether passengers see a price advantage over stitched itineraries, how revenue shifts between carriers, and how many disputes reach the clearing mechanism.

**Strategic Choices:**

1. Standardise on sum-of-legs pricing with a connection-protection guarantee, leaving each carrier's fare logic unchanged and minimising inter-carrier negotiation.
2. Develop a distance-and-class through tariff per corridor, negotiated by carrier groups under Agency for Railways supervision, with common fare classes and reduction-card mapping.
3. Allow distributors to compose bundle prices from carrier-published leg price ranges within a floor and cap, with bundle margin shared among carriers by a pre-agreed formula.

**Trade-Off / Risk:** Sum-of-legs is fast to deliver but gives no price reason to prefer rail over air, while negotiated corridor tariffs deliver that advantage at the cost of bargaining that can stall past the standards deadline.

**Strategic Connections:**

**Synergy:** Feeds Inter-Carrier Clearing and Single-Payment Settlement, since a deterministic construction rule makes revenue allocation automatic, and supports the Air-to-Rail Competitiveness Package by determining whether rail through-fares can actually undercut short-haul air.

**Conflict:** Clashes with Distribution Remuneration and Commission Corridor, because bundle margins and corridor tariffs compete with distributor commissions for the same revenue, and with Joint Conduct Safe-Harbour, since negotiated corridor tariffs raise competition-law exposure.

**Justification:** *High*, Determines the passenger-visible through-price, carrier revenue allocation and dispute load on clearing. Decides whether rail can undercut air; trades delivery speed against negotiated tariffs and clashes with remuneration and competition-law exposure.

### Decision 9: Disruption Re-accommodation Choreography
**Lever ID:** `07ef7d35-a183-412f-896c-205fce312df7`

**The Core Decision:** Sets the operating model for the moment a connection breaks: who detects it, who owns the reroute decision, and how seats on competitors' trains are accessed. It is the practical test of through-ticket credibility. Success is measured by time from delay detection to a confirmed alternative, the share of affected passengers rebooked without visiting a counter, and the number of passengers stranded.

**Why It Matters:** Defines who first sees a missed connection, who decides the reroute, and how alternative itineraries are offered across carrier boundaries in real time. A shared event feed reduces stranded passengers, but requires carriers to share operational data they currently guard and exposes them to dependence on competitors' data quality.

**Strategic Choices:**

1. Establish a shared disruption event feed to which all carriers publish and distributors subscribe, with each distributor responsible for proposing reroutes to its own customers.
2. Assign the issuing carrier of the through-ticket as sole re-accommodation owner, obliged to rebook across any carrier using pre-agreed seat access on following services.
3. Pilot a neutral automated rebooking service that proposes and holds seats on alternative trains once a delay breaches a connection threshold, with the passenger confirming by notification.

**Trade-Off / Risk:** Real-time rerouting is the visible test of through-ticket credibility, yet it depends on operational data quality that carriers have never shared, so the feed may be technically live while still too unreliable to act on.

**Strategic Connections:**

**Synergy:** Operationalises the Through-Ticket Liability and Rights Backstop by turning liability rules into a concrete rebooking action, and relies on Availability Query Topology and Authoritative Booking Source to hold and confirm alternative seats reliably.

**Conflict:** Strains Availability Query Topology and Authoritative Booking Source, since seat holds on rival carriers' services contend with each carrier's inventory control, and loads Inter-Carrier Clearing and Single-Payment Settlement with unplanned reroute costs between carriers.

**Justification:** *Medium*, Practical credibility test for through-tickets, but largely operationalises decisions made in the liability, availability and clearing levers. Valuable execution layer with significant data-sharing dependencies rather than a foundational choice.

### Decision 10: Assistance and Bicycle Reservation Chaining
**Lever ID:** `0712ad24-64d5-4b27-b6f2-902b02aba10a`

**The Core Decision:** Makes assistance for persons with reduced mobility and bicycle spaces bookable components tied to the through-ticket rather than separate phone-based requests. Its scope reaches into stations, staffing and rolling stock that differ per carrier. Key metrics are the share of assisted and bicycle journeys completed as promised, the notice period achieved across carriers, and the number of itineraries refused for lack of capacity.

**Why It Matters:** Treats assistance requests for persons with reduced mobility and bicycle spaces as bookable components bound to the through-ticket, despite differing notice periods, rolling-stock capacity and station staffing among carriers. Binding them raises usability for affected travellers but exposes physical capacity mismatches that software cannot fix.

**Strategic Choices:**

1. Define a single assistance-request message propagated to every carrier on the itinerary, with a common notice period that all participating carriers commit to meeting.
2. Make bicycle and wheelchair space reservations conditional components confirmed together with the seat, so a through-ticket is not issued if any leg lacks the required capacity.
3. Have disability-rights bodies and operators jointly run a staffed assistance coordination desk per corridor that brokers requests manually while the automated chain is built.

**Trade-Off / Risk:** Atomic confirmation guarantees honest promises to travellers, but it will block many itineraries where rolling stock has no spaces, converting an accessibility ambition into a visible drop in through-ticket availability.

**Strategic Connections:**

**Synergy:** Depends on and strengthens Ticket Validation and Onboard Inspection Interoperability, since reserved spaces must be recognised by onboard staff, and uses Availability Query Topology and Authoritative Booking Source to query space capacity per leg.

**Conflict:** Trades off against the Air-to-Rail Competitiveness Package, because atomic confirmation removes itineraries and lowers through-ticket availability, and complicates Disruption Re-accommodation Choreography, since rerouted journeys must re-secure scarce assistance and bicycle spaces.

**Justification:** *Medium*, Required accessibility and bicycle scope with real physical constraints, but affects a subset of journeys. Atomic confirmation can reduce itinerary availability, creating a local trade-off rather than steering the core system.

### Decision 11: Specification Custodian Seat for OSDM Evolution
**Lever ID:** `adf2b2a1-82aa-4e6d-b58a-da2e7a0bbeae`

**The Core Decision:** Decides who owns the OSDM specification, its change requests, versioning and reference test suite, and so who can shape the standard after the binding-standards deadline. It governs both release speed and the trust of independent distributors in non-discriminatory access. Success is measured by median change-request turnaround, the diversity of contributors, and the absence of forks or stalled releases.

**Why It Matters:** Deciding who controls change requests, versioning and the reference test suite determines how fast the standard can adapt and how much regulatory force it carries. Anchoring it in an EU body gives legal certainty but can slow releases; leaving it with industry speeds iteration but concentrates influence among incumbents. The choice also shapes whether independent distributors trust the standard to stay non-discriminatory.

**Strategic Choices:**

1. Anchor OSDM change control in the EU Agency for Railways with a statutory change-request procedure, giving the specification regulatory force at the cost of slower, more formal release cycles.
2. Keep OSDM maintenance in the existing industry-led community and have the Commission reference a pinned version by delegated act, preserving release cadence while accepting dependence on a body outside EU institutional control.
3. Place the specification and its conformance test suite in a neutral open-source foundation with escrowed copies held by the Agency, so any carrier or distributor can fork the standard if governance stalls.

**Trade-Off / Risk:** Regulatory anchoring buys legal certainty but risks freezing a standard that carriers still need to iterate; industry stewardship moves faster yet leaves non-incumbent distributors dependent on the goodwill of the parties they compete against.

**Strategic Connections:**

**Synergy:** Provides the authoritative test suite on which the Conformance Gate and Carrier Onboarding Support depends, and gives the Public Reference Distributor Mandate a stable specification to build against.

**Conflict:** Constrains the Milestone-Conditioned Funding Release Ladder, since slower formal release cycles can delay milestones tied to a pinned version, and interacts with Availability Query Topology and Authoritative Booking Source, where API changes force carrier rework.

**Justification:** *Medium*, Sets standard governance and independent-distributor trust, feeding conformance tests and the reference distributor. Important for long-term neutrality, but its effects flow mainly through the conformance and funding levers.

### Decision 12: Distribution Remuneration and Commission Corridor
**Lever ID:** `6f84e666-fb53-432b-a893-6f0e65374058`

**The Core Decision:** Sets what carriers pay distributors per through-ticket sold and who supervises that price, which decides whether third-party platforms, carrier channels and the public reference distributor can survive side by side. Success metrics: dispersion of effective commission rates across distributor types, number of discrimination disputes reaching regulators, and carrier inventory exposure compliance at the mandatory API milestone (Month 30 = 2029-04-12).

**Why It Matters:** The fee a carrier pays a distributor for selling its seats decides whether third-party platforms, carriers' own channels and a public reference distributor can compete on equal terms. A rigid cap protects passengers from fare mark-ups but may starve smaller distributors; open bilateral bargaining favours large incumbents. Remuneration design also feeds directly into the settlement mechanism and the carriers' willingness to expose inventory.

**Strategic Choices:**

1. Set a regulator-supervised commission band applied identically to every distributor, with carriers free to price inside the band but not to discriminate between distributors.
2. Allow bilateral commission negotiation but require filing of all rates with national regulators and periodic audit for discrimination, trading price flexibility for a heavier supervisory workload.
3. Introduce a pooled through-ticket distribution fee set by the clearing function that falls as combined volume across all carriers grows, rewarding multi-carrier itineraries instead of single-operator sales.

**Trade-Off / Risk:** A uniform commission band simplifies enforcement but ignores wide differences in distributor cost structures, while bilateral deals preserve commercial freedom at the price of disputes that regulators must adjudicate carrier by carrier.

**Strategic Connections:**

**Synergy:** Amplifies Inter-Carrier Clearing and Single-Payment Settlement, since commission splits can be netted in the same flows, and supports Public Reference Distributor Mandate by giving it a transparent, level fee basis to compete on.

**Conflict:** Trades off against Joint Conduct Safe-Harbour for Shared Data and Clearing, because a uniform band or pooled fee resembles price coordination among competitors, and constrains Through-Fare Construction Doctrine, since commission levels limit how revenue can be apportioned.

**Justification:** *Medium*, Shapes whether third-party, carrier and public distributors coexist and carriers expose inventory. Well connected to clearing and fare levers, but largely a commercial-terms optimisation constrained by competition law and upstream choices.

### Decision 13: Ticket Validation and Onboard Inspection Interoperability
**Lever ID:** `ffa8b25b-d42d-4bdd-9e5f-3820906984ed`

**The Core Decision:** Ensures every conductor, gate and station agent on a corridor accepts a through-ticket issued by any participating carrier without manual workarounds. Scope covers credential format, offline verification, handheld and gate upgrades, and legacy phase-out. Metrics: share of inspections passed without intervention, validation-related disputes and penalty fares, and proportion of corridor rolling stock and gates equipped by go-live.

**Why It Matters:** A through-ticket is only useful if conductors, gates and station staff from every carrier on the itinerary accept it without manual workarounds. Mandating one credential format simplifies passenger experience but forces hardware and handheld upgrades across rolling stock and stations. Leaving validation to each carrier shifts the burden to passengers and raises the dispute rate the program aims to reduce.

**Strategic Choices:**

1. Mandate a single ticket credential and barcode format accepted by every conductor handheld and station gate on participating corridors, funding the device upgrades through the public budget.
2. Let each carrier keep its native validation method and require only a cross-recognition handshake, so that each carrier can verify the others' tickets through an API without replacing hardware.
3. Issue a short-lived, cryptographically signed journey token that conductors can verify offline, replacing printed and per-carrier barcodes on corridor trains while legacy formats are phased out.

**Trade-Off / Risk:** A single credential removes inspection friction for passengers but demands rolling-stock and handheld retrofits that follow vehicle maintenance cycles, so corridor go-live may depend on hardware schedules the program does not control.

**Strategic Connections:**

**Synergy:** Strengthens Through-Ticket Liability and Rights Backstop, because an accepted credential gives clear proof of entitlement, and Assistance and Bicycle Reservation Chaining, whose reservations can be carried inside the same credential.

**Conflict:** Retrofit costs compete for the public budget with Public Reference Distributor Mandate, and hardware schedules tied to vehicle maintenance cycles can delay corridor go-live, straining Milestone-Conditioned Funding Release Ladder gates.

**Justification:** *Low*, Largely tactical, hardware-driven enabler tied to vehicle maintenance cycles. Supports liability proof and assistance reservations, but mostly executes upstream decisions; its retrofit costs and schedule risk are manageable on a corridor basis.

### Decision 14: Joint Conduct Safe-Harbour for Shared Data and Clearing
**Lever ID:** `12449661-297c-48ff-8258-3e9b460a7123`

**The Core Decision:** Provides legal certainty that exchanging fares, inventory and settlement data through shared mechanisms is compatible with EU competition rules (Article 101 TFEU), so carriers invest without fearing later unwinding. Metrics: time to obtain comfort relative to the binding-standards milestone (Month 18 = 2028-04-12), carrier participation rates, absence of successful challenges, and no forced redesign of clearing or data-sharing arrangements.

**Why It Matters:** Carriers exchanging fares, inventory and settlement data through a common mechanism could be viewed as coordination between competitors. Establishing legal comfort early reduces hesitation in participating carriers but requires time with competition authorities. Skipping it risks later challenges that could unwind the clearing and data arrangements after carriers have invested.

**Strategic Choices:**

1. Seek formal guidance from the Commission's competition directorate before the standards are binding, so that data-sharing and clearing designs are confirmed compatible with competition rules in advance.
2. Rely on the legal obligation created by the Regulation as the basis for data exposure and appoint a monitoring trustee to audit compliance and report suspected misuse to authorities.
3. Structurally separate the clearing function behind a clean-team arrangement that sees only the flows needed for settlement and releases carriers' commercial data to nobody, including participants.

**Trade-Off / Risk:** Early competition-law clearance protects carriers' investments but could consume months before binding standards, while relying on mandated disclosure alone leaves unresolved exposure if the final regulation changes or is read narrowly.

**Strategic Connections:**

**Synergy:** Enables Inter-Carrier Clearing and Single-Payment Settlement and Availability Query Topology and Authoritative Booking Source, because legal comfort lets carriers commit real-time inventory and settlement data to these shared mechanisms without hesitation.

**Conflict:** Clearance time pressures the Month 18 (2028-04-12) binding-standards schedule and Milestone-Conditioned Funding Release Ladder, while a clean-team structure limits the data visibility that Inter-Carrier Clearing and Single-Payment Settlement may need for reconciliation and dispute resolution.

**Justification:** *High*, Legal precondition for carriers to commit inventory and settlement data; failure could unwind investments. Its clearance timing pressures the Month 18 (2028-04-12) binding-standards milestone and constrains the clearing, availability and remuneration designs.
