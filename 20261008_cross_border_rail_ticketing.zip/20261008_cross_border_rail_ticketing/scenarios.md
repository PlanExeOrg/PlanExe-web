# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** Very high. EU-wide, multi-stakeholder public infrastructure and governance programme covering 27 member states and about 25+ carriers. It spans a shared real-time data layer, clearing and settlement, a passenger-rights backstop, a public reference distributor and multimodal hooks. Public coordination budget is €1.5 billion (user constraint). Milestones: binding standards by Month 18 (2028-04-08), mandatory API exposure by Month 30 (2029-04-08), full corridor through-ticketing by Month 60 (2031-10-08). Outcome targets: 40% of cross-border journeys sold as through-tickets, distributor complaints halved, and modal shift from air.

**Risk and Novelty:** Moderate to high. The legislative basis is only proposed (Commission proposals published May 2026; adoption by Parliament and Council still pending, so the final text is not confirmed). OSDM is an existing standard, but a pan-European through-ticketing and clearing regime with non-discriminatory access is novel. Key risks are incumbent resistance, uneven carrier IT maturity, regulator capacity differences and legal set-up delays. The brief explicitly asks for a realistic scenario, not the most aggressive one.

**Complexity and Constraints:** Very high complexity. Legacy booking back-ends vary widely. Multiple legal regimes apply (competition law, payment services licensing, passenger rights). Fixed €1.5 billion public budget, with private carrier IT spend estimated separately. Hard milestones at Months 18, 30 and 60 (2028-04-08, 2029-04-08, 2031-10-08). Phased corridor rollout. Needs conformance testing, member-state capacity building and consumer-side rollout. The critical path is sensitive to governance and clearing set-up time.

**Domain and Tone:** Public policy and regulatory transport infrastructure with a business and governance framing. Formal, institutional, stakeholder-heavy tone. Digital systems (APIs, payments) are tied to physical rail operations and corridors.

**Holistic Profile:** A large, politically sensitive, regulation-aligned EU programme that must deliver on fixed milestones with a fixed public budget. It needs credible enforcement of non-discrimination but should avoid fixing prices or building heavy new legal entities before the legislation is final. The brief calls for a balanced, risk-managed path that supports smaller carriers and protects the Month 30 (2029-04-08) deadline while still moving toward the 40% target.

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Pragmatic Foundation: Certified Access, Competitive Settlement
**Strategic Logic:** This path avoids fixing prices before the legislation is final and before real cost data exists. It ties inventory access to a distributor certification scheme, uses accredited payment institutions for split payment and refunds so no new central payment entity is needed, and co-funds carriers against milestones with priority for smaller and state-weak operators. Regional hubs let smaller carriers meet the Month 30 (2029-04-08) API date without a permanent central gateway. A time-boxed arbitration panel on top of existing institutions resolves contested technical decisions without a new legal entity. This is the realistic, recommended path: it balances progress against delivery risk, and it does not need the most aggressive option on any lever.

**Fit Score:** 9/10

**Why This Path Was Chosen:** Certification-based tiered access, accredited payment providers, milestone co-funding for smaller carriers, regional hubs and a lightweight arbitration panel avoid long legal set-up and early price-fixing. It still gives enforceable access rules and a path to the Month 30 (2029-04-08) mandate and the through-ticket targets. It matches the 'realistic, not most aggressive' brief.

**Key Strategic Decisions:**

- **OSDM Access Terms and Enforcement Model:** Tie API access terms to a certification scheme under which distributors earn tiered inventory access by meeting conformance and consumer-protection tests, with carriers able to audit distributors in return.
- **Clearing and Settlement Architecture:** Contract regulated payment institutions to run split-payment and refund orchestration as a competitive service, with carriers choosing among accredited providers that meet common settlement rules.
- **Funding Allocation and Carrier Incentives:** Make a significant portion of the budget available as milestone-based co-funding for carriers, prioritising smaller and state-weak operators, conditional on meeting API and data-quality deadlines.
- **Legacy Carrier IT Migration Pathway:** Offer regional shared booking-service hubs, run by consortia of neighbouring carriers or by procured third-party operators, that host inventory and fare logic for several carriers behind one interface.
- **Programme Governance Vehicle and Decision Rights:** Create a small independent standards arbitration panel with time-boxed rulings, layered on top of existing institutions, so disputes resolve quickly without building a full new legal entity.

**The Decisive Factors:**

- **Balanced ambition and risk:** The programme is large and carries fixed milestones (Months 18, 30, 60 = 2028-04-08, 2029-04-08, 2031-10-08) and a €1.5 billion budget (user constraint). The Pragmatic Foundation advances every lever without requiring the most aggressive option on any of them, as the brief asks.
- **Legislation still pending:** The Commission proposals (May 2026) have not been adopted. Tiered, certification-based access avoids fixing a regulated price before the final text and real cost data exist.
- **Protects the critical path:** Accredited payment institutions and a time-boxed arbitration panel avoid new legal entities and licensing delays that could threaten the Month 18 (2028-04-08) and Month 30 (2029-04-08) milestones.
- **Inclusive adoption:** Milestone-based co-funding and regional hubs address the long tail of smaller carriers without creating a permanent single-point-of-failure gateway.
- **Why not The Pioneer's Gambit:** Its central clearing entity, joint undertaking and regulated price add legal set-up time and execution risk, and its volume-linked funding favours corridors that already succeed.
- **Why not The Consolidator's Compact:** Its self-published terms, complaints-driven enforcement and incumbent-influenced governance make the 40% and halved-complaints targets unlikely.

---
## Alternative Paths
### The Pioneer's Gambit: Central Rails, Market-Driven Delivery
**Strategic Logic:** This path builds central institutions first: a regulated access price, a publicly governed clearing entity and a joint undertaking with its own budget authority and tie-breaking power. It rewards carriers and distributors only for verified through-ticket volume, so public money follows outcomes. It accepts the risks of a long legal set-up (the joint undertaking and clearing licensing could consume much of the first year, which threatens the Month 30 = 2029-04-08 API mandate), uneven readiness among smaller carriers, and funding that favours corridors already succeeding. In return it offers the strongest chance of reaching the 40% target and the strongest enforcement of non-discrimination.

**Fit Score:** 3/10

**Assessment of this Path:** It pairs the strongest enforcement with a regulated price, a new central clearing entity and a joint undertaking. The legal and licensing set-up would likely use up much of the first year and threaten the Month 18 (2028-04-08) and Month 30 (2029-04-08) milestones. It also fixes prices before the legislation or cost data exist and leaves smaller carriers behind, which makes it the most aggressive option and not a realistic one.

**Key Strategic Decisions:**

- **OSDM Access Terms and Enforcement Model:** Mandate a single regulated reference price and service-level schedule for API access, enforced by national regulators with EU Agency for Railways audit rights over inventory parity and latency.
- **Clearing and Settlement Architecture:** Establish a single publicly governed clearing entity that receives passenger payments, applies agreed apportionment rules and pays carriers on a fixed cycle, with a guarantee fund for defaults.
- **Funding Allocation and Carrier Incentives:** Hold back a competitive pool of funds that carriers and distributors bid for to deliver jointly proposed integration projects, with payment tied to verified through-ticket volumes.
- **Legacy Carrier IT Migration Pathway:** Require every carrier to build and operate its own native interface, using public funds only for standards work and testing, and accept uneven readiness among smaller operators.
- **Programme Governance Vehicle and Decision Rights:** Establish a dedicated joint undertaking with carrier, distributor and consumer seats, giving it its own budget authority, staff and a tie-breaking mechanism for contested technical decisions.

### The Consolidator's Compact: Proven Tools, Protected Deadlines
**Strategic Logic:** This path puts schedule certainty and cost control first by relying on what already exists. Carriers publish their own access terms within a common template, settle through existing arrangements with a common message standard, and run under current EU institutional procedures. Public money goes to shared infrastructure and testing, and a publicly hosted gateway lets smaller carriers meet the Month 30 (2029-04-08) mandate. The cost is weaker enforcement against discrimination and slower, incumbent-influenced decisions. The 40% through-ticket target and the halving of distributor complaints are therefore less likely to be met.

**Fit Score:** 5/10

**Assessment of this Path:** It protects schedule and cost, but self-published access terms, penalties only after repeated findings, incumbent-influenced governance and no carrier co-funding undercut the non-discrimination goal. The 40% through-ticket and halved-complaints targets would likely be missed. It is safe but under-ambitious for the programme's goals.

**Key Strategic Decisions:**

- **OSDM Access Terms and Enforcement Model:** Let carriers publish their own FRAND-style access terms within a common template, with a complaints-driven review by regulators and penalties only after repeated findings of discrimination.
- **Clearing and Settlement Architecture:** Extend existing bilateral and multilateral carrier settlement arrangements with a common message standard and an independent dispute-resolution body, avoiding any new central payment entity.
- **Funding Allocation and Carrier Incentives:** Reserve most of the budget for shared infrastructure, conformance testing and the clearing mechanism, leaving carrier-side integration to be funded privately under the mandate.
- **Legacy Carrier IT Migration Pathway:** Fund a publicly hosted gateway that translates legacy carrier systems into the standard interface, which smaller carriers can use until they modernise their back-ends.
- **Programme Governance Vehicle and Decision Rights:** Run the programme from DG MOVE with the EU Agency for Railways as technical secretariat, using advisory working groups and keeping all binding decisions inside existing EU institutional procedures.
