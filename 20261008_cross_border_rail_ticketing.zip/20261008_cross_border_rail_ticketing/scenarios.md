# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** Continental, multi-stakeholder public program across about 25 national operators and independent distributors. It covers four priority corridors, then the full TEN-T network, over a five-year horizon (binding standards by Month 18 = 2028-04-12, mandatory API exposure by Month 30 = 2029-04-12, full corridor through-ticketing by Month 60 = 2031-10-12). Targets are 40% of cross-border journeys sold as through-tickets, halved distributor complaints and a modal shift from short-haul air to rail. The public coordination budget is €1.5 billion (user constraint).

**Risk and Novelty:** Moderate-to-high risk, built on partly proven components (OSDM, existing clearing arrangements, an EU rail ticketing regulation proposal; a May 2026 Commission proposal was confirmed by search, adoption status and final content not verified). Novel elements are cross-carrier liability pooling, a public reference distributor and mandatory API exposure. Main risks: carrier refusal over unpriceable connection liability, competition-law challenges, legacy IT latency and legislative uncertainty. The plan explicitly asks for a realistic scenario, not the most aggressive one.

**Complexity and Constraints:** Very high operational and governance complexity: standards, conformance testing, real-time data, clearing and settlement, passenger-rights backstop, PRM accessibility, bicycle reservations and multimodal hooks. The fixed €1.5 billion public budget must cover standards, clearing, a public distributor and rollout, while private carrier IT cost is estimated separately. Carriers cannot be directed by the Commission except through regulation and funding leverage. Sequenced corridor rollout and fixed regulatory milestones leave little slack.

**Domain and Tone:** Public-sector regulatory and infrastructure program: EU institutions, rail transport, consumer protection and digital standards. Formal, institutional and compliance-oriented, with a balance between neutrality toward commercial distributors and consumer outcomes.

**Holistic Profile:** A large, regulation-aligned, publicly funded interoperability program that needs carrier buy-in more than central control. It should deliver through-ticketing on priority corridors by layering shared standards over legacy systems, protect the fixed public budget, and keep a neutral last-resort sales channel. It aims at the 40% target without taking on the governance and budget risks of a fully centralised public backbone.

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Pragmatic Foundation: Federated Build with Verified Milestones
**Strategic Logic:** Delivers through-ticketing on the four priority corridors by layering shared standards over existing carrier systems: a federated settlement layer, a streamed availability shadow with carrier booking authority, and a carrier-funded guarantee pool that protects the public budget. Money is released against verifiable technical milestones, and a private concession covers last-resort sales, which balances speed, neutrality and carrier buy-in. This is the recommended realistic pathway.

**Fit Score:** 9/10

**Why This Path Was Chosen:** Delivers the plan's full scope (shared real-time layer, clearing, rights backstop, public last-resort channel) on the priority corridors by layering over existing carrier systems. The carrier-funded pool and milestone tranches protect the public budget while keeping leverage over compliance.

**Key Strategic Decisions:**

- **Through-Ticket Liability and Rights Backstop:** Establish a carrier-funded mutual guarantee pool that pays assistance, rerouting and compensation on any through-ticket, with contributions weighted by each carrier's share of missed-connection incidents.
- **Inter-Carrier Clearing and Single-Payment Settlement:** Federate settlement through a shared netting and dispute-resolution layer that connects existing bilateral and sector clearing arrangements, so carriers keep their current accounting flows.
- **Public Reference Distributor Mandate:** Tender a distributor-of-last-resort concession that guarantees any journey on participating carriers can be bought somewhere, with a private operator running the service under public service-level terms.
- **Milestone-Conditioned Funding Release Ladder:** Release funds in tranches tied to verified technical milestones, such as conformance certificates and live API exposure, paid to carriers and member-state bodies on verification.
- **Availability Query Topology and Authoritative Booking Source:** Publish an event-streamed availability shadow for search, treat each carrier's booking engine as sole authority at purchase, and degrade to scheduled-only offers whenever a carrier endpoint is unavailable.

**The Decisive Factors:**

- **Matches the realism mandate:** federated settlement and a streamed availability shadow layer over legacy carrier systems, so the four priority corridors can be delivered within the 18/30/60-month milestones.
- **Protects the €1.5 billion budget (user constraint):** the carrier-funded guarantee pool avoids a public pay-first fund, and tranches tied to conformance certificates give compliance leverage without forcing carriers to pre-finance.
- **Keeps the plan's scope and neutrality:** a tendered last-resort concession provides a public channel without competing with Trainline or Omio.
- **Pioneer's Gambit is too risky:** central inventory, a single clearing entity and a full public app concentrate failure, budget and competition-law exposure.
- **Prudent Consolidator is too thin:** a sandbox-only public role and distributor-only liability make the 40% through-ticket goal and carrier participation unlikely.

---
## Alternative Paths
### The Pioneer's Gambit: A Public European Booking Backbone
**Strategic Logic:** Builds a fully public-led, uniform European layer (central inventory, single clearing entity, public rights fund and a full consumer-facing public service) to reach the 40% through-ticket goal and the air-to-rail shift as fast as possible. It accepts the highest budget drain, governance conflict, single-point-of-failure and carrier-refusal risks in exchange for maximum control and consistency.

**Fit Score:** 3/10

**Assessment of this Path:** Maximally ambitious: a central exchange, a single clearing entity, a public pay-first fund and a full public app would drain the €1.5 billion budget, invite competition-law challenges, and outcome-only payments with carrier pre-financing risk carrier refusal. This is the aggressive option the plan asks to avoid.

**Key Strategic Decisions:**

- **Through-Ticket Liability and Rights Backstop:** Create a publicly capitalised rights backstop fund within the €1.5 billion budget that pays passengers immediately and later recovers costs from the responsible carrier through the clearing mechanism.
- **Inter-Carrier Clearing and Single-Payment Settlement:** Build a single EU-level clearing entity that receives the passenger payment, nets positions across carriers and distributors, and pays out on a fixed schedule under a common rulebook.
- **Public Reference Distributor Mandate:** Operate a full consumer-facing public booking service in all EU languages with complaint handling, positioned as a neutral channel alongside commercial distributors.
- **Milestone-Conditioned Funding Release Ladder:** Reserve a large share for outcome-based payments released only after measured through-ticket sales and complaint reductions appear, requiring carriers to pre-finance the work.
- **Availability Query Topology and Authoritative Booking Source:** Build a central inventory exchange that carriers feed continuously, so distributors query one endpoint and carriers retain only final booking authority.

### The Prudent Consolidator: Standards First, Markets Deliver
**Strategic Logic:** Keeps public exposure and new infrastructure minimal: distributors carry passenger liability with insured recourse to carriers, carriers keep existing accounting flows and endpoints, and the public role is a B2B reference sandbox. Funding is a co-financed competitive call, so scarce public money goes only where carriers and distributors commit their own capital. It gives up some speed and the full 40% ambition for budget control and delivery certainty.

**Fit Score:** 6/10

**Assessment of this Path:** Low-risk and budget-safe, but it drops the public reference distributor and the shared real-time layer, puts all liability on distributors, and leaves the 40% through-ticket and modal-shift goals unlikely. Competitive co-financed calls may also skip less commercial corridors.

**Key Strategic Decisions:**

- **Through-Ticket Liability and Rights Backstop:** Make the selling distributor the single point of liability toward the passenger and require it to hold insurance, with contractual recourse against the carrier whose delay caused the missed connection.
- **Inter-Carrier Clearing and Single-Payment Settlement:** Federate settlement through a shared netting and dispute-resolution layer that connects existing bilateral and sector clearing arrangements, so carriers keep their current accounting flows.
- **Public Reference Distributor Mandate:** Run a business-to-business reference implementation and sandbox that demonstrates correct OSDM use, with consumer sales left to commercial distributors under common rules.
- **Milestone-Conditioned Funding Release Ladder:** Pool funds in a competitive call where carriers and distributors co-finance corridor integration projects, ranked by expected through-ticket volume and passenger benefit.
- **Availability Query Topology and Authoritative Booking Source:** Keep inventory federated at each carrier, with distributors querying carrier OSDM endpoints directly through a shared routing and discovery registry that the program operates.
