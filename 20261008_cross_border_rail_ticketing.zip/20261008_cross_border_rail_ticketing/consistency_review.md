## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Is the written Council/Commission delegation of binding technical authority to the arbitration panel signed by Month 2 (2026-12-08)? | Signed by Month 2 (2026-12-08) (target Month 1.5 = 2026-11-23). Failure trigger: Council Legal Service estimates the delegation will take more than 4 months, or the delegation is unsigned at Month 2 (2026-12-08). | Signed delegation instrument, plus the Council Legal Service timeline opinion requested in Months 0-1 (2026-10-08 to 2026-11-08). Answerable at Month 2 (2026-12-08). | Delay. Pause carrier commitments and escalate to the Commission for Council fast-tracking. Do not start binding-standards drafting in earnest until the delegation is signed. If it runs past about 4 months, re-baseline the Month 18 (2028-04-08) and Month 30 (2029-04-08) milestones or revisit the lightweight-panel model. |
| 2 | Have carriers above EUR 50M cross-border revenue signed binding Commitment Letters (including the escrow penalty) by Month 3 (2027-01-08)? | At least 95% of carriers above EUR 50M signed by Month 3 (2027-01-08) (proposed threshold). Every top-5 carrier signed by Month 4 (2027-02-08), otherwise the Steering Committee re-baselines. | Signed letters naming the native API, hub or gateway pathway and the IT investment. Bilateral sessions with the 8 largest carriers in Months 0-1 give early signals. Answerable at Month 3-4 (2027-01-08 to 2027-02-08). | Delay and downsize. Hold co-funding awards and hub and payment awards. Escalate to the Commission. Re-scope the Month 30 (2029-04-08) mandate to the carriers that have signed (a corridor-by-corridor start), or stop if a top-5 incumbent refuses. |
| 3 | Does the bottom-up cost model, based on binding quotes, fit inside the EUR 1,500M cap and the EUR 215M free contingency? | Base-case co-funding demand no more than 20% above the EUR 290M line, and distributor run-rate at or below EUR 50M/year (estimate), using binding quotes from 8-12 carriers and the distributor operator candidates. | Cost model due Month 2 (2026-12-08). Binding quotes by Month 4 (2027-02-08) (Month 6 = 2027-04-08 at the latest). Decision on distributor scope (reference-only vs full retail) by Month 2 (2026-12-08). | Downsize or decide before committing. Apply the Tier 2 co-funding cut (20% to 10%), fix the distributor at reference scope, or take an explicit decision on who finances the excess. Do not make irreversible awards on an unfunded plan. |
| 4 | Does demand evidence show travellers will actually choose the through-ticket at EUR 70-90? | At least 8% of conjoint respondents (300-500 per product) prefer the through-ticket at EUR 70-90 by Month 4 (2027-02-08). Pilot conversion at least 3% by Month 12 (2027-10-08). Share at least 15% by Month 24 (2028-10-08) (stop below 8%). | Conjoint willingness-to-pay survey on the four corridors by Month 4 (2027-02-08). One-corridor MVP pilot from Month 9 (2027-07-08). Share data from Month 18 (2028-04-08). | Downsize or split. Stop scaling marketing beyond the pilot corridor and refocus on corridors with weak air competition. Take a Steering Committee decision to reset the 40% target or fund fare support (unfunded, so it needs a new decision). |
| 5 | Has the Regulation been adopted by Month 9 (2027-07-08), and at the latest by the Month 10 (2027-08-08) hard gate, without material change to liability, data scope or API scope? | Adopted by Month 9 (2027-07-08). Hard gate at Month 10 (2027-08-08). Adoption probability at least 70% at Month 6 (2027-04-08) (proposed threshold). Material divergence in fewer than 2 of the 4 areas (liability, data scope, API scope, access definition). | Parliament and Council vote calendar and a weekly tracker by Month 0.5 (2026-10-23). Gap analysis of amendments against the shadow standards, with an update at Month 6 (2027-04-08). | Delay. At Month 8-8.5 contract the external standards consortium. At Month 10 (2027-08-08) pause carrier onboarding commitments and re-baseline the critical path. If still unadopted at Month 12 (2027-10-08), consider restructuring or stopping. |
| 6 | Is the settlement and hub layer ready: at least 2 accredited payment providers operational, and 4 hubs live below the failure threshold? | At least 2 payment providers applying by Month 6 (2027-04-08) and operational at Month 12 (2027-10-08), with fees at or below 0.7% (target 0.3-0.5%) and settlement under 48 h in dry-run. Hubs operational by Month 9 (2027-07-08) with booking-failure rate at or below 2% (target under 0.5%). At least 8 DPA written non-objections by Month 4 (2027-02-08) as a precondition. | Accreditation decision at Month 8 (2027-06-08). Provider and hub go-live evidence at Months 9-12 (2027-07-08 to 2027-10-08). Dual-run results in Months 15-18 (2028-01-08 to 2028-04-08). | Delay. Switch to bilateral settlement or emergency procurement (EUR 10M reserve). Route affected carriers via a gateway or bilateral pairing. Do not open any corridor to through-ticket sales without under-48h settlement in dry-run by Month 18 (2028-04-08). Drop a hub from the Month 30 (2029-04-08) plan if it stays above 2% after two remediation cycles. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: executive_summary; pitch; project_plan
    canonical: public_budget_cap_eur = EUR 1,500 million, fixed, Months 0-60 (2026-10-08 to 2031-10-08)
    observed:  Supplementary authority of EUR 100-200M sought outside the cap if Tier 2 triggers
HIGH CF-002  document: review_plan (Review 2.1)
    canonical: private_carrier_it_estimate_eur = EUR 0.5-2.0 billion; planning value EUR 1.25 billion (estimate)
    observed:  EUR 1.25-2.5 billion ROI over Months 30-60 (2029-04-08 to 2031-10-08) from a EUR 60-200M/year revenue pool
HIGH CF-003  document: review_plan (Reviews 1-2, 6.1, 14.2); executive_summary Feedback
    canonical: measurement_baseline = Interim through-ticket share gate 15% at Month 24 (2028-10-08) (proposed threshold)
    observed:  Contingency at <8% willingness-to-pay/modal-shift at Month 12 (2027-10-08) or Month 24 (2028-10-08)
MEDIUM CF-004  document: executive_summary; review_plan; premortem
    canonical: standards_critical_path = Standards drafting Months 4-18 (2027-02-08 to 2028-04-08); adoption gate Month 9 (2027-07-08), pause at Month 10 (2027-08-08)
    observed:  Window compresses 50% / from 9 months to 3-4 months
MEDIUM CF-005  document: pitch; review_plan
    canonical: fallback_hub_failure_and_fare_support = Subsidised through-fares if modal shift is under 10% at Month 48 (2030-10-08) are unfunded and need a new decision
    observed:  Modal shift 'is achieved through superior pricing'; trigger under 8% at Month 48 (2030-10-08)
MEDIUM CF-006  document: executive_summary
    canonical: consumer_app_timeline = Four-corridor consumer go-live Month 27 (2029-01-08)
    observed:  First corridor through-ticketing go-live Month 30 (2029-04-08)
MEDIUM CF-007  document: executive_summary
    canonical: payment_accreditation_timeline = Call Month 2 (2026-12-08); decision Month 8 (2027-06-08); at least 2 providers operational Month 12 (2027-10-08)
    observed:  Award hub and payment-provider contracts at Month 3 (2027-01-08)
MEDIUM CF-008  document: executive_summary; review_plan
    canonical: governance_prerequisites = Written delegation by Month 2 (2026-12-08) (target Month 1.5 = 2026-11-23)
    observed:  Present for legal review at Month 1.5 (2026-11-23) / Council adoption by Month 1.5 (2026-11-23)
MEDIUM CF-009  document: review_plan; premortem
    canonical: alloc_carrier_cofunding_eur = EUR 290 million = grants EUR 234M + hubs EUR 44M + accessibility EUR 12M
    observed:  EUR 234M grants + EUR 44M hubs; EUR 20-30M per carrier; EUR 310M trigger
MEDIUM CF-010  document: pitch
    canonical: api_mandate_threshold = At least 90% of corridor traffic bookable end-to-end by Month 30 (2029-04-08)
    observed:  Smaller carriers conform by Month 36 (2029-10-08)
MEDIUM CF-011  document: canonical_facts
    canonical: hub_timeline = Hub sunset/cost-recovery Month 48 (2030-10-08)
    observed:  Hub gap ~EUR 1.9M/yr persists after Month 60 (2031-10-08); TEN-T carriers join via hubs from Month 36 (2029-10-08)
MEDIUM CF-012  document: review_plan; premortem
    canonical: api_mandate_threshold = At least 90% of corridor traffic bookable by Month 30 (2029-04-08); below 90% triggers Commission review
    observed:  Month 24 (2028-10-08) target 75% vs stop rule 80%; fragmentation below 80% at Month 30 (2029-04-08)
```

### 1. Fixed cap vs overrun beyond contingency (who finances the excess) (🔴 High) — needs a project decision

- **executive_summary (Timeline and Budget; Risk 3); pitch (Fiscal discipline); project_plan (mitigation):** EUR 1,500M is a fixed cap, with EUR 215M free contingency. The mitigation is a 'supplementary authority request' of EUR 100-200M at Month 12 (2027-10-08) if Tier 2 triggers.
- **canonical fallback_budget_overrun_exceeds_cap; review_plan Review 1.3:** A 20-30% overrun (EUR 300-450M) exceeds free contingency by EUR 85-235M. The EUR 100-200M supplementary authority is outside the cap and does not cover the upper case.
- **Why it conflicts:** A fixed cap cannot be exceeded by a supplementary authority outside it. The documents offer no funding source for the EUR 0-135M gap in the upper case (235 less 100, which is EUR 35M if the 200M authority is granted). Nothing establishes who pays if Tiers 1-3 do not close it.
- **Suggested resolution:** Do not present the cap as absolute while relying on supplementary authority. State that overruns beyond EUR 215M must be absorbed by Tier 1-3 scope cuts, or take an explicit decision (Commission, Council or member states) on who finances excess. Options: cut scope; raise the cap; shift cost to carriers, distributors or member states. Decide this before the Month 12 (2027-10-08) review.

### 2. Private IT ROI vs revenue pool arithmetic (🔴 High)

- **review_plan Review 2.1:** A successful Month 30 (2029-04-08) mandate 'generates EUR 1.25-2.5 billion private carrier IT ROI over Months 30-60 (2029-04-08 to 2031-10-08)' and the revenue pool 'justifies private spend'.
- **review_plan Review 2.1; canonical private_carrier_it_estimate_eur:** The same item computes the pool as 1.2-2.0M through-tickets/year x EUR 50-100 = EUR 60-200M per year. Private IT is EUR 0.5-2.0B (planning value EUR 1.25B).
- **Why it conflicts:** EUR 60-200M/year over 2.5 years (Months 30-60 = 2029-04-08 to 2031-10-08) is EUR 150-500M of revenue, not EUR 1.25-2.5B of ROI. It would take roughly 6-20 years of the whole revenue pool to repay EUR 1.25B. The 3-5M passenger base also comes from only two corridors in the assumptions, not all cross-border traffic.
- **Suggested resolution:** Withdraw the ROI figure and the 'justifies private spend' claim. Rebuild the carrier business case on a stated passenger base (all cross-border vs four corridors), with revenue, avoided costs and mandated compliance shown separately. Treat private spend as mandated compliance cost rather than commercial ROI unless the rebuilt model shows otherwise.

### 3. The '8%' threshold is applied to different metrics and months (🔴 High)

- **premortem A3 and FM3; canonical measurement_baseline; pitch Metrics:** Survey preference below 8% at Month 4 (2027-02-08) is a failure trigger. Share below 8% at Month 24 (2028-10-08) is a stop rule. The 15% interim gate at Month 24 (2028-10-08) triggers a co-funding review.
- **review_plan Review 1-2, 6.1, 14.2; executive_summary Feedback (2):** 'If willingness-to-pay is below 8% by Month 12 (2027-10-08)' or 'at Month 24 (2028-10-08)' escalate contingency. 'Modal-shift willingness <8%' triggers contingency by Month 24 (2028-10-08).
- **Why it conflicts:** The same 8% is used for survey preference, modal shift and through-ticket share, with contingency decision dates of Month 4, 12 and 24 (2027-02-08, 2027-10-08, 2028-10-08). This is the demand go/no-go gate. A reader cannot tell which metric, month or action applies. A survey preference of 8% is also far below the 40% share the plan needs.
- **Suggested resolution:** Fix a metric ladder. Survey preference at least 8% at Month 4 (2027-02-08). Pilot conversion at least 3% at Month 12 (2027-10-08). Through-ticket share at least 15% at Month 24 (2028-10-08) (canonical gate), with a stop below 8%. Modal shift is a separate metric, with its own trigger (see the modal-shift item). Remove WTP-at-Month-24 and modal-shift-willingness wording.

### 4. Standards-window arithmetic after a Regulation slip (🟡 Medium)

- **executive_summary Risk 1; review_plan Review 1.1, 13.1; premortem FM4:** If adoption slips past Month 9 (2027-07-08), the standards window 'compresses 50%' / 'shrinks from 9 months to 3-4 months'.
- **canonical standards_critical_path and regulation_adoption_gate:** Standards run Months 4-18 (2027-02-08 to 2028-04-08) and adoption is gated at Month 9 (2027-07-08). The hard stop is Month 10 (2027-08-08) (a window of about 8 months to Month 18 = 2028-04-08). Month 12 (2027-10-08) leaves 6 months.
- **Why it conflicts:** 9 to 3-4 months is a 55-67% cut, not 50%. A 3-4 month window would require adoption at about Month 14-15 (2027-12-08 to 2028-01-08), well past the Month 10 (2027-08-08) pause gate. A one-month slip to Month 10 (2027-08-08) cuts the window from 9 to 8 months. The assumptions document's own '3-month slip, 9 to 6 months' is arithmetically sound.
- **Suggested resolution:** Restate as: adoption at Month 9 (2027-07-08) leaves 9 months to Month 18 (2028-04-08); each month of slip removes one month (Month 12 = 2027-10-08 leaves 6; Month 14-15 = 2027-12-08 to 2028-01-08 leaves 3-4). Keep the Month 10 (2027-08-08) pause gate, justified by lost margin and rework risk rather than by a 3-4 month window.

### 5. Modal-shift triggers sit inside the planning range; pitch states outcomes as achieved (🟡 Medium) — needs a project decision

- **canonical modal_shift_planning_range, through_fare_rule; executive_summary:** Modal shift is a planning range of 5-15%, not a commitment. Through-fares are sum-of-segment prices, with no ceilings.
- **pitch Long-term Vision; review_plan Review 8.2; premortem FM3:** The pitch says '5-15% modal shift is achieved through superior pricing and convenience' and that 40% 'is reached'. Review 8.2 uses a trigger of modal shift under 8% by Month 48 (2030-10-08). Premortem FM3 and canonical use under 10% at Month 48 (2030-10-08).
- **Why it conflicts:** Planned outcomes are written as achievements. 'Superior pricing' contradicts sum-of-segment pricing and the documents' own EUR 70-90 through-fare vs EUR 40-70 flight estimate. The Month 48 (2030-10-08) trigger is 8% in one place and 10% in another, and both lie inside the 5-15% planning range, so a normal outcome would trigger an unfunded fare-support decision.
- **Suggested resolution:** Rewrite the pitch as targets or planning ranges and drop 'superior pricing'. Use one Month 48 (2030-10-08) trigger (10%, per canonical). Decide now whether fare support is in scope and who funds it, or state that a miss means a target reset rather than a subsidy.

### 6. Corridor go-live sequence (🟡 Medium) — needs a project decision

- **executive_summary Key Deliverables:** First corridor (Paris-Brussels-Amsterdam-Koln) through-ticketing goes live at Month 30 (2029-04-08). Four-corridor full deployment is at Month 60 (2031-10-08).
- **pitch Long-term Vision and Metrics; canonical consumer_app_timeline and api_mandate_threshold:** At Month 30 (2029-04-08) any conformant distributor can sell across the four corridors, and 90% of traffic on each corridor is bookable end-to-end. Four-corridor consumer go-live is at Month 27 (2029-01-08).
- **Why it conflicts:** The summary has one corridor live at Month 30 (2029-04-08). The pitch and canonical have four corridors bookable by Month 30 (2029-04-08), and consumer go-live on all four at Month 27 (2029-01-08), before the 'first' corridor goes live. No document says which corridor goes first or what 'go-live' means versus the Month 30 (2029-04-08) API mandate versus the Month 60 (2031-10-08) 'full' deployment.
- **Suggested resolution:** Decide and publish a corridor sequence and a definition of go-live for each phase (API mandate, consumer go-live, full through-ticketing). Options: (a) phased corridors with Paris-Brussels-Amsterdam-Koln first; (b) all four corridors at Month 30 (2029-04-08), with Month 60 (2031-10-08) meaning the 40% share. Then align Month 27, 30 and 60 (2029-01-08, 2029-04-08, 2031-10-08) across all documents.

### 7. Payment-provider award month (🟡 Medium)

- **executive_summary Action Orientation:** At Month 3 (2027-01-08), 'award hub and payment-provider contracts'. Payment-provider RFPs are issued in Months 1-2 (2026-11-08 to 2026-12-08).
- **canonical payment_accreditation_timeline; project_plan Compliance Actions:** Market sounding Months 0-1 (2026-10-08 to 2026-11-08), call for applicants Month 2 (2026-12-08), accreditation decision Month 8 (2027-06-08), at least 2 providers operational Month 12 (2027-10-08).
- **Why it conflicts:** Payment providers are accredited through a call, not procured as contracts. The decision is at Month 8 (2027-06-08), five months after the Month 3 (2027-01-08) award stated in the summary. Month 3 (2027-01-08) is correct only for hubs.
- **Suggested resolution:** Keep Month 3 (2027-01-08) for hub contracts only. State that payment-provider accreditation is called at Month 2 (2026-12-08) and decided at Month 8 (2027-06-08). Also fix the pitch, which asks payment institutions to 'apply by Month 2 (2026-12-08)' when the call opens at Month 2 (2026-12-08).

### 8. Council delegation: Month 1.5 (2026-11-23) is 'legal review' in one place and 'adoption' in another (🟡 Medium)

- **executive_summary Action Orientation:** At Month 1.5 (2026-11-23), present the Council delegation for formal legal review. The gate is a signed delegation by Month 2 (2026-12-08).
- **review_plan Review 1.2, 3.3, 12.2; canonical governance_prerequisites:** Secure Council formal adoption by Month 1.5 (2026-11-23). Written delegation by Month 1.5 (2026-11-23) (target).
- **Why it conflicts:** The summary starts legal review at Month 1.5 (2026-11-23), so adoption cannot also occur at Month 1.5 (2026-11-23). A Council decision within about 2 weeks of the first review is not credible. This is the first hard prerequisite, and every later gate (Commitment Letters at Month 3 = 2027-01-08, standards) depends on it.
- **Suggested resolution:** Keep canonical: signed delegation required by Month 2 (2026-12-08), with Month 1.5 (2026-11-23) as a target only. Redefine Month 1.5 (2026-11-23) as 'legal review complete / text agreed', and Month 2 (2026-12-08) as 'signed'. Plan Month 3 (2027-01-08) Commitment Letters around the Month 2 (2026-12-08) date, not Month 1.5 (2026-11-23).

### 9. Carrier co-funding line components and demand thresholds (🟡 Medium)

- **canonical alloc_carrier_cofunding_eur:** Carrier co-funding is EUR 290M = EUR 234M grants + EUR 44M hubs + EUR 12M accessibility.
- **review_plan Reviews 3.1, 11.2, 14.3; premortem A2 and FM1:** 'EUR 290 million = EUR 234M grants + EUR 44M hubs' (sums to 278). Demand is 'EUR 20-30M per carrier x 12-18'. A2 triggers at 20% over EUR 290M (about EUR 348M), but the FM1 tripwire is EUR 310M of requests.
- **Why it conflicts:** The sum omits the EUR 12M accessibility programme. EUR 20-30M per carrier contradicts the EUR 2-8M (small) and EUR 10-15M (mid-size) bands used in the same reviews. Demand thresholds (EUR 310M, about EUR 348M) are compared against the EUR 290M line even though only EUR 234M is grants. Review 5 raises grants from 234M to 280M without saying where the funds come from.
- **Suggested resolution:** Use EUR 234M grants + EUR 44M hubs + EUR 12M accessibility everywhere. Replace the EUR 20-30M per carrier with the EUR 2-15M bands. Define whether thresholds compare grant demand to EUR 234M or total demand to EUR 290M. Align the A2 (20% over) and FM1 (EUR 310M) triggers as early-warning and failure levels.

### 10. Smaller-carrier readiness: Month 30 (2029-04-08) vs Month 36 (2029-10-08) (🟡 Medium)

- **executive_summary Key Deliverables; canonical api_mandate_threshold:** Regional hubs enable 12-18 legacy-IT carriers to meet the Month 30 (2029-04-08) deadline. At least 90% of corridor traffic is bookable by Month 30 (2029-04-08).
- **pitch Metrics (Carrier conformance):** 'Smaller carriers via hubs or native implementation by Month 36 (2029-10-08)'.
- **Why it conflicts:** The pitch gives smaller (hub) carriers six more months than the mandate, and Month 36 (2029-10-08) is also the TEN-T extension start. The plan has not decided whether smaller carriers get a time-limited exemption. The 90%-of-traffic test may in practice tolerate it.
- **Suggested resolution:** Align the pitch to Month 30 (2029-04-08). Express the test as the 90% traffic threshold, with any smaller-carrier exemption documented and time-limited. If a Month 36 (2029-10-08) grace period is intended, add it as a canonical decision.

### 11. Hub end state at Month 48 (2030-10-08) (sunset vs cost-recovery) and TEN-T hub use (🟡 Medium) — needs a project decision

- **canonical hub_timeline and hub_scope_and_funding; pitch Long-term Vision:** Hub sunset / cost-recovery at Month 48 (2030-10-08). TEN-T extension from Month 36 (2029-10-08) via the certified hub pathway, with 2 TEN-T hubs reserved (decision at Month 30 = 2029-04-08).
- **canonical hub_economics_gap and post_month60_unfunded_run_cost:** Hub fee revenue at capacity is about EUR 0.73M/yr vs opex of about EUR 1.2M/yr. The EUR 1.9M/yr hub gap is still counted as unfunded after Month 60 (2031-10-08).
- **Why it conflicts:** Cost recovery at Month 48 (2030-10-08) cannot be reached at current fees, since revenue covers about 61% of opex at capacity. 'Sunset' (hubs stop and carriers migrate to native) conflicts with hubs continuing after Month 60 (2031-10-08) and with TEN-T carriers joining via hubs from Month 36 (2029-10-08). The gap total also does not reconcile (EUR 9.5M over 5 years in the self-audit vs hubs operating only from Month 9 = 2027-07-08).
- **Suggested resolution:** Decide the hub end state: (a) raise fees to full cost recovery, (b) fund the gap, (c) a real sunset with a native-migration path for carriers joining after Month 36 (2029-10-08). Then align the cost-recovery date, the gap total, and TEN-T onboarding eligibility.

### 12. Month 24 (2028-10-08) readiness target vs stop rule (🟡 Medium)

- **review_plan Review 6.2:** Month 24 (2028-10-08) readiness gate: 75% projected ready.
- **premortem FM2 stop rule; review_plan Review 6.2; canonical api_mandate_threshold:** Re-baseline if bookable corridor traffic is projected below 80% at Month 24 (2028-10-08). Also, 'below 80% at Month 30 (2029-04-08) the network fragments', while the canonical review threshold at Month 30 (2029-04-08) is 90%.
- **Why it conflicts:** A 75% target sits below the 80% stop rule, so meeting the target would already trigger a re-baseline. The Month 30 (2029-04-08) fragmentation line (80%) also differs from the 90% Commission-review threshold. Gates at Month 24 (2028-10-08) and Month 30 (2029-04-08) are therefore unclear.
- **Suggested resolution:** Keep 90% at Month 30 (2029-04-08) (canonical). Set one Month 24 (2028-10-08) projection gate (for example 80% projected, as the stop rule) and a higher target. Treat 80% at Month 30 (2029-04-08) as a severe case, not the standard.

## Summary

The core milestones (Month 18 = 2028-04-08 standards, Month 30 = 2029-04-08 API mandate, Month 60 = 2031-10-08 full deployment) and the budget lines (which sum to EUR 1,500M) are consistent across the documents. Most differences are in secondary figures, such as gate months, thresholds and the sums for co-funding. The serious problems are structural. The cap is called fixed, yet overruns beyond the EUR 215M free contingency rely on supplementary authority outside it. The private-ROI arithmetic does not hold. The 8% threshold is reused across metrics and months. Corridor sequencing and the hub end state are undecided. Fix the repairable items, and take explicit decisions on the funding of excess overruns, corridor sequence, hub end state and fare support, before committing to the Month 2-3 (2026-12-08 to 2027-01-08) prerequisites.