## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Is the Regulation timetable confirmed in writing, with adoption at about Month 18 (2028-04-12) and no priority-corridor national regulator signalling a block on data sharing or clearing? | Written Commission timetable showing adoption at about Month 18 (2028-04-12), and not later than Month 24 (2028-10-12) (premortem A6 failure trigger; FM5 tripwire is Month 21 = 2028-07-12). Regulator impact assessments completed for every member state on the four corridors by Month 3 (2027-01-12), with none signalling a refusal to enforce API exposure. | Written timetable from the Commission legislative affairs unit and bilateral regulator impact assessments, both due Month 3 (2027-01-12). | Do not bind carriers on a legal mandate. Launch the shadow-standards workstream and pilot authority, re-sequence the tiers to the adoption date, and defer any blocking member state to a later wave. Convert to a voluntary corridor pilot model if adoption has not happened by Month 30 (2029-04-12). |
| 2 | Have at least 8 major carriers and CER signed the carrier-funded liability model with actuarially priced caps and co-insurance? | At least 8 major carriers and CER signed by Month 4 (2027-02-12). Indicative parameters (proposed threshold): cap EUR 500-1,000 per stranded passenger, co-insurance above EUR 50M annual pool draw. Steering vote at 75% (at least 7 of 9 core members) at Month 6 (2027-04-12). | Actuarial interim results at Month 3 (2027-01-12), final study at Month 6 (2027-04-12), signed carrier letters at Month 4 (2027-02-12), steering vote at Month 6 (2027-04-12). | Escalate to Commission mediation at Month 5 (2027-03-12) and offer the two-tier pool with reinsurance for smaller operators. Defer the gate to Month 12 (2027-10-12) if unresolved at Month 9 (2027-07-12). Pivot to the Prudent Consolidator model if fewer than 6 major carriers commit by Month 12 (2027-10-12), and treat the 40% target as the 15-30% planning range (estimate). |
| 3 | Does the technical audit show enough carriers can credibly reach the SLA by their tier dates with shared adapters? | No more than 35% of carriers unable to show a credible path to p95 latency below 2 seconds and 99.5% availability by their tier date. Shared adapters cover at least 60% of observed legacy patterns. At least 15 operators conformant (minimum viable 15-20). | Technical audit with synthetic three-leg queries by Month 2 (2026-12-12); tier assignment and per-operator timelines published Month 6 (2027-04-12); adapter modules procured Month 12 (2027-10-12). | Re-tier with a Tier 1.5 cohort, cap per-carrier adapter spend, and restrict scope to corridors whose carriers all meet the SLA (stop rule: fewer than 15 conformant by Month 36 = 2029-10-12). Treat the EUR 150-250M adapter exposure as a variance trigger against the EUR 85M headroom. |
| 4 | Does the concession business case hold within the subsidy cap and with a settled envelope split? | At least 3 credible bidders; subsidy at most EUR 60M over five years (average EUR 12M/year); volume at least 60% of forecast. The split of the EUR 300M envelope between set-up and service payments is decided by steering vote. | Market sounding and business case with binding cost quotes at Month 9 (2027-07-12); tender at Month 12 (2027-10-12); award about Month 18 (2028-04-12). | Hold the tender award and rebuild the business case. Test direct public operation at EUR 30-50M (estimate). Withdraw the concession and run a minimal public last-resort service if no compliant bid is within the cap by Month 18 (2028-04-12). |
| 5 | Has DG COMP given Article 101 comfort and has the clean-team clearing protocol been approved without redesign? | Guidance letter received by Month 12 (2027-10-12); clean-team protocol approved by Month 14 (2027-12-12) and no later than Month 18 (2028-04-12); cumulative rework variance below EUR 50M (estimate). | DG COMP pre-notification Month 2 (2026-12-12); interim feedback; guidance letter Month 12 (2027-10-12); protocol approval Month 14 (2027-12-12). | Freeze clearing platform and carrier feed commitments tied to contested data flows. Pivot to bilateral clearing with a neutral dispute layer. Cancel the shared clearing layer if no compliant design is approved by Month 18 (2028-04-12). |
| 6 | Do the live pilots show that through-tickets work for passengers and carriers before Tier 1 exposure and corridor go-live? | Through-ticket conversion above the stitched-itinerary control; itinerary rejection for accessibility below 15%; scheduled-only fallback below 5% of searches; stale-seat failures below 1%; p95 latency below 2 seconds; reconciliation error below 0.5% (all proposed thresholds). 500-1,000 passengers per corridor. | Pilots Months 12-18 (2027-10-12 to 2028-04-12) on the four corridors, weekly SLA scorecards, redacted findings published Month 18 (2028-04-12). | Switch accessibility to best-effort booking and adjust display, fare products and fallback design. Narrow scope to corridors with proven conversion. Re-baseline the 40% target within the 15-30% planning range (estimate) and apply the Month 54 (2031-04-12) corrective trigger (share below 35%) early. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: executive summary; pitch; review plan Review 5
    canonical: mandatory_api_exposure_milestone = Month 30 (2029-04-12) for Tier 1 (large and corridor-critical carriers); Month 36 (2029-10-12) Tier 2; Month 42 (2030-04-12) Tier 3
    observed:  20+ carriers at Month 30 (2029-04-12) (Executive Summary); 25+ carriers at Month 30 (2029-04-12) (Pitch); Tier 1 <20 qualified carriers trigger (Review 5)
HIGH CF-002  document: executive summary Key Deliverables
    canonical: through_ticket_share_target = 40% of cross-border journeys sold as single through-tickets by Month 60 (2031-10-12)
    observed:  40% market share by Month 48 (2030-10-12)
HIGH CF-003  document: review plan Reviews 5, 11, 14 (and canonical pool_draw_policy needs clarification)
    canonical: pool_draw_policy = No public budget draw-downs on carrier pools after Month 36 (2029-10-12); reserve drawable for force-majeure only
    observed:  Reserve 'escrowed for pool top-ups only after Month 36 (2029-10-12)'
HIGH CF-004  document: review plan Review 11 item 1 and Review 1 item 3 (canonical split remains an open decision)
    canonical: concession_subsidy_cap_eur_m = EUR 60M operating subsidy over five years (average EUR 12M/year)
    observed:  EUR 60M annually; EUR 250-270M for operating subsidy; EUR 80-100M annually
HIGH CF-005  document: executive summary Risks; review plan Reviews 2, 3, 5, 6, 10, 11
    canonical: budget_unallocated_headroom_eur_m = EUR 85M free uncommitted headroom (5.7% of cap)
    observed:  EUR 50M adapter-acceleration reserve + EUR 15M + EUR 5-10M + EUR 30-80M validation hardware + EUR 30-50M shadow standards
HIGH CF-006  document: review plan Review 3 item 2; executive summary Risks and Action Orientation; self-audit #17
    canonical: technical_audit_and_tiers = Tier assignment and per-operator timelines published Month 6 (2027-04-12); shared adapter modules procured by Month 12 (2027-10-12)
    observed:  Binding fixed-price agreements locked by Month 6 (2027-04-12); contract by Month 9 (2027-07-12)
MEDIUM CF-007  document: executive summary Action Orientation
    canonical: pilots_and_validation = Live pilots Months 12-18 (2027-10-12 to 2028-04-12) with 500-1,000 passengers per corridor
    observed:  begin Tier 1 pilots at Month 18 (2028-04-12)
MEDIUM CF-008  document: executive summary; review plan Review 9; premortem A1; self-audit
    canonical: liability_decision_timeline = Commissioned Month 1 (2026-11-12), interim Month 3 (2027-01-12), final Month 6 (2027-04-12); carrier sign-off Month 4 (2027-02-12); mediation Month 5 (2027-03-12); binding vote Month 6 (2027-04-12)
    observed:  validated caps by Month 4 (2027-02-12); binding sign-off by Month 5 (2027-03-12); letters of intent; engage by Month 0/0.5 (2026-10-12, 2026-10-27)
MEDIUM CF-009  document: pitch Risks and Mitigation; review plan Review 2
    canonical: budget_variance_triggers = EUR 200M: cut concession funding 20% (EUR 60M of the EUR 300M envelope) and extend term 5 to 7 years
    observed:  cut concession subsidy; subsidy reduced to EUR 48M (20% cut)
MEDIUM CF-010  document: executive summary Timeline and Budget; review plan Review 2; self-audit #20
    canonical: budget_line_realtime_layer_eur_m = EUR 50M real-time layer; committed lines total EUR 1,415M; headroom EUR 85M
    observed:  Lines listed total EUR 1,365M without the real-time layer; 'exceed headroom by EUR 65-415M'
MEDIUM CF-011  document: pitch
    canonical: private_carrier_it_investment_eur = EUR 1.5-3.0 billion, carrier-financed, outside the cap (estimate)
    observed:  tens of billions of carrier IT investment; pre-notified legal comfort
MEDIUM CF-012  document: executive summary Purpose and Goals; pitch Metrics for Success
    canonical: modal_shift_planning_value = 5-10% air-to-rail shift on benchmarked routes (estimate); not a success metric
    observed:  'shift 5-10% of short-haul air journeys' as goal; listed as outcome metric
```

### 1. Number of carriers exposing APIs at Month 30 (2029-04-12) (Tier 1) vs tiered exposure (🔴 High)

- **Canonical facts (mandatory_api_exposure_milestone, carrier_participation); executive summary Key Deliverables (Tier 1-3 at Months 30/36/42 = 2029-04-12, 2029-10-12, 2030-04-12):** Tier 1 = large and corridor-critical carriers at Month 30 (2029-04-12); Tier 2 at Month 36 (2029-10-12); Tier 3 at Month 42 (2030-04-12); about 25 carriers targeted, 8-15 smaller operators at risk of missing Month 30 (2029-04-12).
- **Executive summary Purpose and Goals; pitch Metrics for Success; review plan Review 5 item 3:** 'Mandatory API exposure for 20+ carriers (Month 30 = 2029-04-12)' (Executive Summary); 'Tier 1 API exposure achieved by 25+ carriers by Month 30 (2029-04-12)' (Pitch); 'defer Tier 2 if Tier 1 has <20 qualified carriers' (Review 5).
- **Why it conflicts:** With about 25 carriers in total and 8-15 smaller operators in Tiers 2-3, Tier 1 can hold roughly 10-17 carriers, not 20-25. The Month 30 (2029-04-12) gate threshold therefore differs across documents (20+, 25+, <20) and cannot be met by definition.
- **Suggested resolution:** Define the Month 30 (2029-04-12) gate as 'all Tier 1 carriers conformant' with the Tier 1 count fixed by the Month 6 (2027-04-12) tier assignment. Keep 25+ as the network total by Month 42 (2030-04-12). Remove '20+' and '25+ by Month 30 (2029-04-12)' and recompute the Month 36 (2029-10-12) deferral rule from the real Tier 1 count.

### 2. 40% through-ticket share date (🔴 High)

- **Canonical facts; executive summary Purpose and Goals; project plan Goal Statement:** 40% of cross-border journeys sold as through-tickets by Month 60 (2031-10-12) (user constraint). Four corridors live by Month 48 (2030-10-12) is a plan target, with a planning range of 15-30% if prerequisites slip.
- **Executive summary, Key Deliverables and Outcomes:** 'Four-corridor through-ticketing with 40% market share by Month 48 (2030-10-12)'
- **Why it conflicts:** The same document asks for 40% at Month 48 (2030-10-12) and 40% at Month 60 (2031-10-12). A 40% target at Month 48 (2030-10-12) pulls the headline gate forward by 12 months and conflicts with the premortem's Month 48 (2030-10-12) stop rule (narrow scope below 15%) and the Month 54 (2031-04-12) corrective trigger (below 35%).
- **Suggested resolution:** Keep 40% at Month 60 (2031-10-12). State Month 48 (2030-10-12) only as the four-corridor go-live, with a share milestone set from the pilots. Align the corrective thresholds: Review 6 and the premortem use below 35% at Month 54 (2031-04-12), while the self-audit mitigation uses below 30%; keep 35%. Delete the unsupported '40% ±5% (user constraint)' wording in Review 6.

### 3. Force-majeure reserve vs 'no draw-downs after Month 36 (2029-10-12)' (🔴 High) — needs a project decision

- **Canonical facts (pool_draw_policy); project plan Mitigation Plans:** No public budget draw-downs on carrier pools after Month 36 (2029-10-12); reserve of EUR 150M drawable only for force-majeure pool top-ups.
- **Review plan Review 5 item 2; Review 11 item 3; Review 14 item 3:** 'EUR 150M reserve is escrowed for pool top-ups only after Month 36 (2029-10-12), with a ban on public draw-downs post-Month 36 (2029-10-12)'; pool draws of EUR 100-200M expected by Month 42 (2030-04-12) 'invoking the reserve'.
- **Why it conflicts:** The reserve is described as usable only after Month 36 (2029-10-12), but pool draw-downs are banned after Month 36 (2029-10-12). Pool stress is expected at Months 30-42 (2029-04-12 to 2030-04-12), so the reserve is either unusable when needed or the ban is breached (Review 14 acknowledges this). Documents do not settle whether the ban covers the force-majeure reserve.
- **Suggested resolution:** A decision is needed. Options: (a) the ban excludes force-majeure draws, with a written drawdown trigger (more than 5,000 passengers in a single-day corridor-wide disruption); (b) the reserve is available only until Month 36 (2029-10-12) and then released to headroom; (c) the reserve stays escrowed beyond Month 36 (2029-10-12) under a Commission policy exemption. Fix the policy by Month 9 (2027-07-12) as Review 14 proposes.

### 4. Concession envelope vs subsidy cap and set-up cost (🔴 High) — needs a project decision

- **Canonical facts (budget_line_concession_eur_m, concession_subsidy_cap_eur_m); executive summary:** EUR 300M envelope (platform set-up and public service-level payments), of which operating subsidy is capped at EUR 60M over five years (EUR 12M/year).
- **Review plan Review 11 item 1; Review 1 item 3:** 'capped EUR 60M annually'; 'EUR 250-270M for operating subsidy'; subsidy 'EUR 80-100M annually, consuming EUR 400-500M of the EUR 300M envelope'.
- **Why it conflicts:** EUR 60M annually (EUR 300M over five years) would equal the whole envelope and contradicts the EUR 60M five-year cap. With set-up at EUR 30-50M (estimate) and subsidy at EUR 60M, about EUR 190-210M of the EUR 300M has no stated use. 'EUR 400-500M of the EUR 300M envelope' is arithmetically incoherent.
- **Suggested resolution:** A decision is needed on the economic content of the EUR 300M line (open decision 1): what the service-level payments beyond set-up and the EUR 60M subsidy buy, and whether unspent envelope is returned. Options: (a) cut the envelope to set-up plus the capped subsidy plus a defined service payment; (b) keep EUR 300M and define the service payments and their cap; (c) shift unused envelope into headroom. Correct 'EUR 60M annually' to 'over five years'.

### 5. The same EUR 85M headroom is earmarked several times (🔴 High) — needs a project decision

- **Canonical facts; executive summary Timeline and Budget:** EUR 85M free uncommitted headroom (5.7% of cap) after EUR 1,415M committed lines.
- **Executive summary Risks; Review 2/3; Review 6 KPI 1 and 3; Review 11 item 2; Review 5; Review 10:** A separate 'EUR 50M adapter-acceleration reserve', 'EUR 15M emergency reserve from headroom', 'EUR 5-10M from headroom' for complaints, EUR 30-80M validation hardware 'carved from headroom', EUR 30-50M shadow-standards workstream.
- **Why it conflicts:** The earmarks sum to well over EUR 85M (EUR 50M + EUR 15M + EUR 5-10M + EUR 30-80M + EUR 30-50M), and a EUR 50M reserve leaves only EUR 35M 'unallocated'. No canonical line contains an adapter-acceleration reserve. Financing of validation hardware is an open decision, yet Month 40 (2030-02-12) deployment is planned as fact.
- **Suggested resolution:** A decision is needed on the order of claims on the headroom: which items may draw on it, with caps, and who finances validation hardware (open decision 2: carriers, 50/50, or public). Until then do not describe the headroom as EUR 85M available and also commit it to a EUR 50M reserve.

### 6. Fixed-price contract lock at Month 6 (2027-04-12) vs legal comfort and procurement sequence (🔴 High)

- **Canonical facts (technical_audit_and_tiers, competition_law_timeline); executive summary Action Orientation; pitch Call to Action (all tendered by Month 12 = 2027-10-12):** Shared adapter modules procured by Month 12 (2027-10-12); DG COMP guidance letter Month 12 (2027-10-12); clean-team protocol approved by Month 14 (2027-12-12); tier assignment published Month 6 (2027-04-12).
- **Review plan Review 3 item 2; executive summary Risks (60% fixed-price by Month 6 = 2027-04-12); self-audit #17:** 'Lock binding fixed-price agreements with penalty clauses by Month 6 (2027-04-12)' for standards, clearing and adapters; 'select and contract by Month 9 (2027-07-12)'; 'secure DG COMP interim guidance' at Month 6 (2027-04-12).
- **Why it conflicts:** A fixed-price EUR 220M clearing contract and adapter contracts are locked before DG COMP guidance (Month 12 = 2027-10-12) and the clean-team protocol (Month 14 = 2027-12-12), and in the same month the tier assignment that sizes the adapters is published. This repeats the FM1 failure story (investment before legal comfort). Documents also differ on when DG COMP gives guidance: interim at Month 6 (2027-04-12), request at Months 9-10 (2027-07-12 to 2027-08-12), letter at Month 12 (2027-10-12).
- **Suggested resolution:** Keep the canonical sequence: tier assignment Month 6 (2027-04-12), adapter procurement Month 12 (2027-10-12), clearing contract conditional on DG COMP guidance (Month 12 = 2027-10-12) and clean-team approval (Month 14 = 2027-12-12). At Month 6 (2027-04-12) fix only price ceilings and framework terms with conditions precedent. Reword the 'interim guidance at Month 6 (2027-04-12)' as a request for interim feedback by Month 9 (2027-07-12).

### 7. Start of live pilots (🟡 Medium)

- **Canonical facts; project plan Mitigation Plans; pitch Collaboration:** Live pilots Months 12-18 (2027-10-12 to 2028-04-12) with 500-1,000 passengers per corridor (2,000-4,000 total).
- **Executive summary Action Orientation:** 'Month 18 (2028-04-12): Obtain binding standards adoption and begin Tier 1 pilots'.
- **Why it conflicts:** The executive summary starts pilots at Month 18 (2028-04-12), when the other documents end them. Pilots at Month 12-14 (2027-10-12 to 2027-12-12) would also run before the clean-team protocol is approved (Month 14 = 2027-12-12), yet the FM1 containment relies on not sharing data flows before protocol approval.
- **Suggested resolution:** Use Months 12-18 (2027-10-12 to 2028-04-12) for pilots and correct the executive summary. State explicitly that pilots before Month 14 (2027-12-12) run on non-contested data flows, or move the start of data-sharing pilots to after clean-team approval.

### 8. Liability decision timeline and sign-off bindingness (🟡 Medium)

- **Canonical facts (liability_decision_timeline):** Actuarial study commissioned Month 1 (2026-11-12), interim Month 3 (2027-01-12), final Month 6 (2027-04-12); draft model Month 3 (2027-01-12); carrier sign-off Month 4 (2027-02-12); mediation Month 5 (2027-03-12); binding vote Month 6 (2027-04-12).
- **Executive summary Risks; review plan Review 9 item 1; premortem A1; self-audit #2-#6:** 'deliver validated caps by Month 4 (2027-02-12)' (Executive Summary); 'non-binding letters of interest by Month 4 (2027-02-12) and binding sign-off by Month 5 (2027-03-12)' (Review 9); sign-off by 'letters of intent' (premortem A1); firm engaged by 'Month 0 (2026-10-12) / Month 0.5 (2026-10-27)' with a 90-day target (self-audit).
- **Why it conflicts:** Validated caps are placed at Month 4 (2027-02-12) although the final study is due at Month 6 (2027-04-12). Binding sign-off is Month 4 (2027-02-12) in one place and Month 5 (2027-03-12) in another (overlapping the Month 5 = 2027-03-12 escalation). Letters of intent are not binding commitments. The self-audit also engages the firm at Month 0/0.5 (2026-10-12, 2026-10-27), not Month 1 (2026-11-12).
- **Suggested resolution:** Keep the canonical chain: carriers sign at Month 4 (2027-02-12) against the Month 3 (2027-01-12) interim parameters, with a clause that the final Month 6 (2027-04-12) study can only be adjusted within an agreed band. Mediation Month 5 (2027-03-12), vote Month 6 (2027-04-12). Decide and state whether the Month 4 (2027-02-12) instrument is binding or a letter of intent. Use Month 1 (2026-11-12) for commissioning.

### 9. Variance trigger EUR 200M: what is cut (🟡 Medium)

- **Canonical facts (budget_variance_triggers):** EUR 200M variance: cut concession funding 20% (EUR 60M of the EUR 300M envelope) and extend its term from 5 to 7 years.
- **Pitch Risks; review plan Review 2 item 2; executive summary:** 'EUR 200M (cut concession subsidy)' (Pitch); 'concession subsidy reduced to EUR 48M (20% cut)' (Review 2); 'EUR 200M cuts concession' (Executive Summary).
- **Why it conflicts:** A 20% cut of the envelope is EUR 60M. A 20% cut of the EUR 60M subsidy is EUR 12M, giving EUR 48M. Two different cuts, an order of magnitude apart, are described under one trigger, and the term extension is omitted.
- **Suggested resolution:** Use the canonical wording: 20% of the EUR 300M envelope (EUR 60M), term extended from 5 to 7 years. Delete the 'EUR 48M' reading and 'subsidy' in the pitch.

### 10. Budget lines do not sum to EUR 1,500M / exceedance arithmetic (🟡 Medium)

- **Canonical facts (budget lines, budget_unallocated_headroom_eur_m):** EUR 1,415M committed lines incl. EUR 50M real-time layer and EUR 150M reserve, plus EUR 85M headroom = EUR 1,500M.
- **Executive summary Timeline and Budget; review plan Review 2 item 2; self-audit #20:** Eight listed lines (80+220+240+300+200+100+75+150 = EUR 1,365M) plus 'EUR 85M headroom'. Fallback exposures EUR 275-500M 'exceed headroom by EUR 65-415M'.
- **Why it conflicts:** Recomputed: the listed lines plus headroom equal EUR 1,450M, because the EUR 50M real-time layer is omitted, although the pitch tenders it. EUR 275-500M less EUR 85M is EUR 190-415M, not EUR 65-415M; EUR 65M is the excess of the adapter item alone.
- **Suggested resolution:** Add the EUR 50M real-time layer line (distributed cache EUR 15-25M, SLA proxy, event feed) to the executive summary. Restate the aggregate exceedance as EUR 190-415M, or give per-item exceedances (adapters EUR 65-165M; concession up to EUR 65M; Article 101 up to EUR 15M).

### 11. Private carrier IT investment and legal comfort overstated in the pitch (🟡 Medium)

- **Canonical facts; pitch Long-term Vision; executive summary:** Private carrier IT investment EUR 1.5-3.0 billion, carrier-financed (estimate). DG COMP pre-notification at Month 2 (2026-12-12), guidance letter at Month 12 (2027-10-12) (estimate).
- **Pitch Stakeholder Benefits and Project Overview:** 'leverages EUR 1.5 billion into tens of billions of carrier IT investment'; 'DG COMP: Data-sharing and clearing structures have pre-notified legal comfort'; 'regulation-backed'.
- **Why it conflicts:** 'Tens of billions' is at least 3-10 times the EUR 1.5-3.0 billion stated in the same pitch. DG COMP comfort is an open assumption (A3, Month 12 = 2027-10-12) and Regulation adoption is not verified, but both are presented as achieved facts.
- **Suggested resolution:** Replace 'tens of billions' with EUR 1.5-3.0 billion (estimate). Reword the DG COMP and regulation statements as targets (pre-notification Month 2 = 2026-12-12, guidance by Month 12 = 2027-10-12, adoption assumed at about Month 18 = 2028-04-12, not verified).

### 12. Modal shift treated as a goal/success metric (🟡 Medium)

- **Canonical facts (modal_shift_planning_value); project plan Related Goals:** 5-10% air-to-rail shift on benchmarked routes is a planning value (estimate) and not a success metric.
- **Executive summary Purpose and Goals; pitch Metrics for Success and Long-term Vision:** Goal 'shift 5-10% of short-haul air journeys to rail on competitive corridors' (Executive Summary Purpose and Goals); '5-10% air-to-rail modal shift' listed under Outcome metrics (Pitch); 'competitively priced against short-haul air' (Pitch).
- **Why it conflicts:** The planning value is promoted to a goal/outcome metric against the canonical rule. The pitch also claims price competitiveness, although the design uses sum-of-legs fare construction with no fare commitments, and FM6 notes that through-fares show no advantage when low-fare airlines respond.
- **Suggested resolution:** Move modal shift out of goals and outcome metrics and report it as an indicative observation (5-10% planning value, estimate). Remove the price-competitiveness claim or support it with a fare mechanism.

## Summary

The plan's core architecture and most headline values (EUR 1,500M cap, 40% by Month 60 = 2031-10-12, Month 18/30/36/42/48/60 = 2028-04-12, 2029-04-12, 2029-10-12, 2030-04-12, 2030-10-12, 2031-10-12 milestones, Month 6 = 2027-04-12 gate, 75% rule, liability and DG COMP sequences) are consistent with the canonical facts, and the Month offsets and date pairings check out. The main faults are drift in the later documents. The executive summary and pitch misstate the Tier 1 count, pull 40% forward to Month 48 (2030-10-12) and omit a budget line. The review layer treats the EUR 85M headroom and the force-majeure reserve as if they were available for several competing purposes and misreads the concession figures. Three items cannot be repaired by text correction alone: the economic content of the EUR 300M concession envelope, the availability of the reserve after Month 36 (2029-10-12), and the claims on headroom including who finances validation hardware. Resolve these decisions before the Month 6 (2027-04-12) gate. The Month 6 (2027-04-12) fixed-price contract lock should also be re-sequenced behind DG COMP guidance.