### 1. Milestone and Critical-Path Tracking
**Monitoring Tools/Platforms:**

  - Project-Management Tool (Asana, Monday.com or equivalent) with real-time dashboard
  - Monthly Milestone Status Report (PMO to Steering Committee)
  - Critical-Path Gantt Chart and dependency tracker
  - Regulation Adoption Tracking Dashboard (weekly)

**Frequency:** Weekly PMO status update (internal); monthly deep-dive (PMO all-hands); quarterly Steering Committee review (Months 3, 6, 9, 12 onwards = 2027-01-08 to 2027-10-08 and thereafter)

**Responsible Role:** Programme Management Office (PMO) Director and Deputy, with Programme Steering Committee oversight

**Adaptation Process:** PMO flags any slippage >2 weeks within 5 working days. Working groups and carriers propose corrective actions (resource increase, scope reduction, timeline adjustment). If slippage exceeds 4 weeks or threatens a hard gate (Month 18 = 2028-04-08, Month 30 = 2029-04-08, Month 60 = 2031-10-08), escalate to Steering Committee for binding decision on timeline adjustment, contingency activation, or scope reduction.

**Adaptation Trigger:** Milestone slippage >2 weeks (triggers PMO escalation); >4 weeks (triggers Steering Committee session within 1 week); Regulation adoption delay past Month 9 (2027-07-08) (hard gate, triggers contingency activation and contingency standards-review); any hard milestone at risk of being missed more than 2 months in advance (triggers re-baselining).

### 2. Budget Burn Rate and Contingency Monitoring
**Monitoring Tools/Platforms:**

  - Monthly Budget Burn Report (Finance Officer to PMO and Steering Committee)
  - Budget Forecast Spreadsheet (EUR 1.5 billion cap tracked by component)
  - Contingency Activation Triggers and Tier 1/2/3 Decision Matrix
  - Carrier Co-Funding Disbursement Log (tied to milestone completion)

**Frequency:** Monthly financial reporting (by the 15th of each month); quarterly Steering Committee budget review (Months 3, 6, 9, 12 = 2027-01-08 to 2027-10-08 and thereafter); contingency-activation triggers assessed at each monthly PMO all-hands

**Responsible Role:** Finance Officer (PMO), with Steering Committee budget authority above EUR 50M per item

**Adaptation Process:** Finance Officer produces monthly burn-rate summary vs. pro-rata forecast. If monthly spend exceeds 115% of pro-rata budget, flag immediately (within 2 working days). If overrun is 10-15% (Tier 1), PMO reviews discretionary spend (marketing, distributor co-ops) for deferral. If overrun is 15-25% (Tier 2), Steering Committee convenes within 1 week to approve cost-reduction measures: reduce carrier co-funding rate from 20% to 10-15%, defer TEN-T hub procurement, or scale back consumer-app features. If overrun exceeds 25% (Tier 3), Steering Committee immediately requests supplementary budget authority from DG MOVE and the Commission.

**Adaptation Trigger:** Monthly spend >115% of pro-rata forecast (Tier 1 trigger); cumulative overrun reaching 15% (Tier 2, triggers SC decision within 1 week); overrun reaching 25% (Tier 3, triggers immediate Commission escalation); free contingency (EUR 215M) consumed by >80% (triggers DG MOVE notification and request for supplementary authority); co-funding demand from carriers exceeds EUR 350M (signals pipeline risk, triggers co-funding-rate reduction decision by Month 12 = 2027-10-08).

### 3. Carrier Integration Readiness and Conformance Tracking
**Monitoring Tools/Platforms:**

  - Carrier Conformance and Readiness Dashboard (monthly, by corridor and carrier)
  - Conformance Test Queue and Lab Capacity Report (monthly)
  - Carrier Milestone Completion Log (API design review Month 15 = 2028-01-08, test-bed Month 18 = 2028-04-08, dual-run Months 21-24 = 2028-07-08 to 2028-10-08, pre-production Months 24-27 = 2028-10-08 to 2029-01-08, go-live Month 30 = 2029-04-08)
  - Carrier Commitment Letter Compliance Tracker (penalties in escrow monitored)

**Frequency:** Monthly carrier readiness update (PMO Carrier Onboarding Lead to PMO all-hands); quarterly detailed readiness report to Steering Committee; weekly testing-lab capacity review (internal PMO)

**Responsible Role:** Carrier Onboarding and Conformance Lead (PMO), with testing labs and EU Agency for Railways liaison

**Adaptation Process:** PMO tracks each carrier's progress through readiness gates. If a carrier misses a gate (e.g., API design review not completed by Month 15 = 2028-01-08), PMO issues a 2-week remediation notice and assigns a technical mentor. If the carrier does not meet the remediation deadline, PMO suspends co-funding tranches (0.5-1% of quarterly through-ticket revenue, held in escrow, is accelerated to forfeiture) and escalates to the Steering Committee. If a major carrier (>EUR 100M cross-border revenue, >30% of corridor traffic) signals they will not meet the Month 30 (2029-04-08) API deadline, Steering Committee convenes emergency session within 5 days, invokes the Commitment Letter penalty, and initiates enforcement escalation to DG MOVE (public distributor bypass, regulatory pressure).

**Adaptation Trigger:** Carrier misses a readiness gate by >2 weeks (triggers remediation notice); multiple carriers (>3) slip past a gate simultaneously (triggers Steering Committee review and possible timeline extension or scope reduction); a major incumbent carrier (Deutsche Bahn, SNCF, Trenitalia, ÖBB, >30% corridor traffic) signals non-compliance or delay >6 months (triggers emergency SC session and enforcement escalation); less than 80% of major carriers pass conformance audit by Month 24 (2028-10-08) (triggers Month 30 = 2029-04-08 API mandate risk assessment); less than 75% of smaller carriers ready via hubs by Month 30 (2029-04-08) (triggers TEN-T extension delay decision).

### 4. Standards Development Progress and Technical Dispute Resolution
**Monitoring Tools/Platforms:**

  - Technical Standards Working Group Monthly Status Report (sub-group deliverables, consensus gaps, escalations)
  - Draft Standards Document Status (chapters complete, review cycle status)
  - Arbitration Panel Case Log (disputes received, rulings issued, compliance tracking)
  - OSDM Specification Alignment Tracker (comparison to published OSDM standard and Regulation requirements)

**Frequency:** Monthly standards working-group all-hands meeting and PMO reporting; bi-weekly sub-group check-ins on critical workstreams (OSDM, data-layer, clearing/settlement); arbitration panel decisions logged and published within 5 working days of issuance; quarterly Steering Committee review of standards progress (Months 3, 6, 9, 12 = 2027-01-08 to 2027-10-08)

**Responsible Role:** Technical Standards Lead (PMO, chair of working group), with Arbitration Panel Chair and EU Agency for Railways liaison

**Adaptation Process:** Standards Lead tracks sub-group progress against planned deliverables. If a sub-group cannot reach consensus on a technical issue by the target date (e.g., data-layer architecture by Month 9 = 2027-07-08), the Standards Lead escalates the dispute to the Arbitration Panel within 5 working days with written positions from all parties. The Panel issues a binding ruling within 60 days. If the ruling is contested (within 10 days), the dispute escalates to the Commission (DG MOVE, DG COMP if competition concerns) for final decision within 14 days. Meanwhile, the Standards Lead proceeds with drafting on all non-disputed sections so the Month 18 (2028-04-08) standards gate is not delayed by single disputed issues. If the disputed issue is resolved late (Month 12-15 = 2027-10-08 to 2028-01-08), a 2-4 week draft-incorporation cycle is scheduled before the Month 18 (2028-04-08) approval gate.

**Adaptation Trigger:** Sub-group unable to reach consensus by planned date (triggers escalation to arbitration panel within 1 week); arbitration panel ruling contested (triggers Commission escalation); more than 2 major technical disputes unresolved by Month 12 (2027-10-08) (triggers Steering Committee risk assessment and possible extension of standards deadline to Month 21 = 2028-07-08, with Month 30 = 2029-04-08 API mandate at risk); draft standards not complete by Month 15 (2028-01-08) (triggers 2-week extension and expedited final review, risking Month 18 = 2028-04-08 deadline).

### 5. Real-Time Data Layer and API Performance Monitoring
**Monitoring Tools/Platforms:**

  - API Operations Centre Dashboard (latency p95, uptime %, throughput, error rates, incident log)
  - Monthly API Performance Report (by carrier and corridor)
  - Hub Performance Dashboard (uptime, latency, booking-failure rate, mapping-accuracy metrics)
  - Infrastructure Provider SLA Compliance Tracker
  - Carrier Infrastructure Assessment and Co-Funding Allocation Log

**Frequency:** 24/7 automated monitoring (API ops centre); daily incident summary (if any critical events >15 min downtime); weekly ops-centre meeting (Monday morning); monthly performance report (by the 5th of each month); quarterly Steering Committee review (Months 6, 9, 12 = 2027-04-08 to 2027-10-08 and thereafter)

**Responsible Role:** API Operations Centre Manager and Data-Layer Technical Lead (PMO), with infrastructure provider escalation protocols

**Adaptation Process:** API ops centre monitors latency, uptime and throughput against SLAs (p95 <2 sec, 99.95% uptime, ≥500 req/s per corridor). If latency exceeds 5 seconds p95 or uptime drops below 99.5% for >1 hour, ops centre issues a critical incident alert (within 15 minutes) to the carrier or infrastructure provider responsible. Incident must be resolved within 2 hours (target). If a carrier's infrastructure cannot meet SLAs (latency consistently >3 sec or throughput <300 req/s), the PMO triggers co-funding for infrastructure upgrades (EUR 0.5-2M per carrier, Month 6-18 = 2027-04-08 to 2028-04-08). If a hub's booking-failure rate exceeds 2% for more than 1 week, the PMO suspends new carrier onboarding to that hub and convenes a remediation task force (hub operator + carriers + PMO technical team) to debug the mapping errors. Hub downtime >12 hours triggers a postmortem review (within 48 hours) and root-cause analysis. Hub mapping errors >1% of transactions trigger liability-insurance claim and carrier reimbursement (from hub operator's E&O policy).

**Adaptation Trigger:** API latency p95 exceeds 3 seconds for any corridor for >4 hours (triggers infrastructure review and capacity upgrade plan); API uptime falls below 99.5% for >2 consecutive days (triggers infrastructure provider penalty and failover activation); hub booking-failure rate exceeds 2% for >1 week (triggers carrier onboarding freeze and remediation sprint); hub mapping errors >1% of transactions (triggers retest and carrier compensation from E&O insurance); API response timeout rate >1% during peak hours (triggers load-test and chaos-engineering exercise).

### 6. Through-Ticket Volume and Measurement Baseline Tracking
**Monitoring Tools/Platforms:**

  - Quarterly Through-Ticket Volume Dashboard (% of cross-border journeys sold as through-tickets, by corridor and channel)
  - Measurement Baseline Report (Month 9 = 2027-07-08 validated baseline)
  - Carrier and Distributor Reporting Template (monthly from Month 18 = 2028-04-08)
  - Independent Evaluator Counterfactual Model and Progress Report (quarterly)
  - Modal-Shift Analysis (air fares vs. through-fares, short-haul air trip trends, by corridor)

**Frequency:** Baseline survey and definition of 'through-ticket' (Months 0-2 = 2026-10-08 to 2026-12-08, report Month 6 = 2027-04-08); validated baseline at Month 9 (2027-07-08); mandatory carrier/distributor reporting monthly starting Month 18 (2028-04-08); quarterly measurement dashboard (Month 18 = 2028-04-08 onward); quarterly Steering Committee review of progress toward the 40% target and complaints-halved target (Months 6, 9, 12, 15 = 2027-04-08 to 2028-01-08 and thereafter)

**Responsible Role:** Measurement and Evaluation Lead (PMO), with independent evaluator and carriers/distributors providing data

**Adaptation Process:** Baseline survey (Month 9 = 2027-07-08) establishes: current cross-border through-ticket share (estimated 5-10%), current distributor complaint rate (baseline for 'halved' target), modal split (baseline for modal-shift planning range). From Month 18 (2028-04-08), carriers and accredited distributors submit monthly through-ticket volumes and complaint metrics. Independent evaluator aggregates data quarterly and applies counterfactual methodology (comparing programme corridors to non-programme control routes) to isolate programme impact from external factors (fuel prices, airline capacity, aviation taxes). If baseline measurement at Month 9 (2027-07-08) invalidates the 40% target's plausibility (e.g., baseline is <3% through-ticket share, suggesting much lower market penetration), Steering Committee triggers a 4-week strategic review and may revise the target or increase co-marketing investment. Interim gate at Month 24 (2028-10-08): if through-ticket share is <15% of cross-border journeys, Steering Committee triggers co-funding hold and determines whether to increase public investment or accept a lower outcome. Final evaluation at Month 60 (2031-10-08) will report actual through-ticket share, complaints reduction and modal-shift attribution.

**Adaptation Trigger:** Baseline measurement at Month 9 (2027-07-08) shows through-ticket share <3% (signals unachievability of 40% target, triggers strategic review); interim gate at Month 24 (2028-10-08) shows through-ticket share <15% (triggers co-funding review and possible contingency reallocation); quarterly through-ticket growth stalls (no increase for 2+ consecutive quarters) (triggers analysis of barriers and possible accelerated consumer-app rollout or co-marketing boost); modal-shift analysis shows through-fares not competitive with airlines on any corridor (triggers assessment of whether regulated fare ceilings or subsidies are needed); distributor complaints remain >baseline at Month 36 (2029-10-08) (triggers investigation and possible claim-resolution process redesign).

### 7. Governance Body Effectiveness and Risk-Register Monitoring
**Monitoring Tools/Platforms:**

  - Risk Register (20+ initial risks identified, updated monthly with new risks, mitigation owners, and status)
  - Steering Committee Decision Log (decisions, owners, deadlines, closure tracking)
  - Governance Body Meeting Minutes and Attendance Tracker (PMO responsibility)
  - Escalation Log (issues escalated from working groups, resolution status, closed-out items)
  - Stakeholder Satisfaction Survey (annual, starting Month 12 = 2027-10-08)

**Frequency:** Monthly PMO risk review (PMO Risk Officer presents top 10 risks at PMO all-hands); Steering Committee risk escalation and mitigation tracking (quarterly, Months 3, 6, 9, 12 = 2027-01-08 to 2027-10-08 and thereafter); governance-body effectiveness self-assessment (Month 6 = 2027-04-08 mid-programme review); annual stakeholder satisfaction survey (Month 12 = 2027-10-08, Month 24 = 2028-10-08, Month 36 = 2029-10-08)

**Responsible Role:** Governance and Risk Officer (PMO), with Programme Steering Committee oversight and Community Liaison Officer (stakeholder satisfaction)

**Adaptation Process:** Risk Officer maintains a living risk register with ~20 key risks (regulatory adoption, governance deadlock, budget overrun, carrier non-compliance, hub failures, GDPR/competition challenges, smaller-carrier readiness, modal-shift viability). Each risk has a mitigation owner (e.g., PMO Stakeholder Lead for political/governance risks, Technical Lead for technical risks, Finance Officer for budget risks). Monthly review assesses: has the risk materialized? Is mitigation on track? Have new risks emerged? If a risk's mitigation action is overdue or ineffective, or if the risk's probability/impact increases, the Risk Officer escalates to the Steering Committee within 5 working days with a decision request (approve revised mitigation, escalate to Commission, or accept the risk). Unmitigated critical risks (e.g., Regulation adoption slips past Month 9 = 2027-07-08) trigger a contingency-activation decision at the Steering Committee. Governance-body effectiveness self-assessment (Month 6 = 2027-04-08) reviews: Are decisions being made on schedule (target: resolve issues within 4 weeks)? Are working groups productive or becoming 'talking shops'? Is stakeholder engagement sufficient (target: >70% satisfaction among all stakeholder groups)? If satisfaction drops below 70% in any group, Community Liaison Officer triggers 4-week focused outreach. If working groups are producing re-litigated decisions (same issues debated repeatedly), Steering Committee enforces decision finality and narrows working-group scope.

**Adaptation Trigger:** Any critical risk (probability×impact >15/25) unmitigated (triggers Steering Committee decision within 5 days); risk mitigation action overdue by >2 weeks (escalation to action owner's manager); new critical risk identified (triggers rapid assessment and mitigation planning within 1 week); Steering Committee decision delayed >4 weeks (triggers chair escalation and simplified decision-making protocol); stakeholder satisfaction <70% in any group (triggers focused outreach; if <60%, escalation to DG MOVE); governance-body meeting cancellations or no-shows >2 in a quarter (signals disengagement, triggers restructuring or workload reduction); more than 3 decisions re-litigated in Steering Committee (signals working-group lack of clarity, triggers tighter TOR and decision-finality rule).