### 1. Tracking Key Performance Indicators (KPIs) Against Project Plan
**Monitoring Tools/Platforms:**

  - Programme Office KPI Dashboard (shared spreadsheet or BI tool)
  - Quarterly Financial Variance Report (EUR 1,500M budget tracking)
  - Monthly SLA Scorecard (latency, availability, error rates by carrier)
  - Through-Ticket Volume and Penetration Report (trending toward 40% target)

**Frequency:** Monthly KPI and SLA tracking; quarterly financial reports; monthly variance trending against EUR 100M, EUR 200M, EUR 300M triggers

**Responsible Role:** Operational Management Board (OMB), with Programme Director and Financial Planning Lead executing daily tracking and escalating variances

**Adaptation Process:** KPI shortfalls (e.g., latency >2s p95, availability <99.5%, stale-seat failures >1%) trigger remediation discussions in the OMB; carriers missing SLAs for two consecutive months lose 5% of next funding tranche. Through-ticket volume lagging 40% target by Month 36 (2029-10-12) mid-programme review triggers course corrections (e.g., accelerated TEN-T sequencing, distributor engagement intensification). Financial variance reaching EUR 100M/EUR 200M/EUR 300M triggers PSC policy adjustment (e.g., TEN-T scope reduction, concession subsidy reallocation).

**Adaptation Trigger:** SLA deviation (latency/availability/error) on a single carrier for two consecutive months; financial variance cumulative spend exceeds EUR 100M, EUR 200M or EUR 300M thresholds; through-ticket penetration tracking >15% below linear ramp-to-40% by Month 36 (2029-10-12); concessionaire operating costs exceed budget by >15% in any quarter

### 2. Milestone and Conformance Gate Monitoring
**Monitoring Tools/Platforms:**

  - Conformance-Certification Registry (public, per-carrier, updated monthly from Month 24 = 2028-10-12 onwards)
  - Technical Audit Report and Tier Assignment Schedule (Month 2 = 2026-12-12 baseline, per-carrier timeline)
  - OSDM Binding Specification and Change-Request Dashboard (versions, approvals, backlog)
  - Conformance Test Results and Audit Reports (Tier 1 Months 24–30 = 2028-10-12 to 2029-04-12; Tier 2 Months 30–36 = 2029-04-12 to 2029-10-12; Tier 3 Months 36–42 = 2029-10-12 to 2030-04-12)

**Frequency:** Weekly during Phase 1 (Months 0–18 = 2026-10-12 to 2028-04-12) standards development and readiness-gate prep; monthly conformance audits (Months 24–42 = 2028-10-12 to 2030-04-12); corridor go-live readiness assessments at Month 42 (2030-04-12), Month 45 (2030-07-12)

**Responsible Role:** Technical Standards and Interoperability Working Group (TSWG) Chair and Head of Standards and Conformance for specification and conformance audits; Operational Management Board for milestone tracking and carrier tier remediation decisions

**Adaptation Process:** Carriers failing conformance audits (latency, availability, stale-seat failure thresholds) are assigned remediation tasks: retest, accelerated adapter funding, or deferral to next tier. Tier deferral (e.g., Tier 1 carrier → Tier 2, or Tier 2 → Tier 3) is documented with revised conformance deadline. If a corridor-critical carrier (e.g., on Wien–München–Zürich corridor) fails by its tier deadline, corridor go-live is deferred or that carrier is replaced by a backup (if available). OSDM specification change requests are processed via the published change-control process (critical: 2 weeks, major: 6 weeks, minor: 8 weeks); changes requiring carrier rework are flagged to OMB for impact assessment.

**Adaptation Trigger:** Carrier fails conformance audit on latency p95 >2 seconds, availability <99.5%, stale-seat failures >1%; two consecutive months of SLA misses trigger funding-tranche withholding; >5 carriers or a Tier 1 corridor-critical carrier deferred from their tier deadline by >2 months; OSDM specification change request flagged as affecting binding-standards commitments or requiring >4 weeks carrier rework; >20% of corridor rolling stock or stations non-compliant with ticket-validation deployment by Month 40 (2030-02-12) audit

### 3. Carrier Participation and Liability Backstop Monitoring
**Monitoring Tools/Platforms:**

  - Carrier Sign-Off Register (liability model acceptance, on-time performance data submission)
  - Guarantee Pool Contribution Model and Incident Tracking Log (monthly pool draw, contributions by carrier, incident rates)
  - Carrier Bilateral Engagement Log (briefings, concerns, contract commitments)
  - Missed-Connection and Reroute Performance Baseline (pilot data Months 12–18 = 2027-10-12 to 2028-04-12; live data post-Month 30 = 2029-04-12)

**Frequency:** Biweekly carrier bilateral briefings Months 2–6 (2026-12-12 to 2027-04-12) during liability model negotiation; monthly carrier sign-off status tracking (liability model, technical integration); monthly pool-contribution and incident-rate monitoring post-Month 30 (2029-04-12)

**Responsible Role:** Head of Carrier Engagement (Programme Office) for bilateral engagement and sign-off tracking; Head of Clearing and Settlement for pool contribution and reconciliation monitoring; OMB for escalation of carrier participation risks

**Adaptation Process:** If a major carrier (>5% of network) signals intent to refuse inventory exposure due to liability concerns, Head of Carrier Engagement escalates to OMB within five business days with remediation options: revised cap/co-insurance formula, additional insurance subsidy, or re-mediation with Commission Transport Commissioner via PSC. If carrier signs off on liability model by Month 4 (2027-02-12), commitment is binding; failure to expose inventory by their tier deadline results in funding-tranche withholding and potential exclusion. Post-deployment, if pool contribution methodology results in systematically higher costs for one carrier (indicating disproportionate incident rates), actuarial study is refreshed (Month 36 = 2029-10-12 or Month 48 = 2030-10-12) to adjust contribution weights and signal operational performance issues for remediation.

**Adaptation Trigger:** A major carrier (>5% of network) declines to sign liability model by Month 4 (2027-02-12); carrier signals publicly or privately that it will not expose inventory by its tier deadline; carrier participation drops below 20 operators (down from 25+ target) before binding standards Month 18 (2028-04-12); missed-connection incident rate on a carrier exceeds 2% of through-tickets post-Month 30 (2029-04-12) triggering pool contributions >EUR 1M/month; carrier pool contribution estimated to exceed carrier's forecast margin, signaling refusal to renew participation beyond initial phase

### 4. Regulation Adoption and Competition-Law Compliance Monitoring
**Monitoring Tools/Platforms:**

  - Regulation Adoption Status Tracker (Commission legislative-affairs updates, expected adoption date)
  - DG COMP Engagement Log and Guidance-Letter Timeline (pre-notification sent Month 2 = 2026-12-12; guidance expected Month 12 = 2027-10-12)
  - Compliance Certifications Register (Article 101 guidance letter, passenger-rights legal opinion, GDPR assessment, accessibility compliance)
  - Clean-Team Protocol Approval and Clearing-Function Audit Trail (segregation of clearing operations, aggregated data release, competitive safeguards)

**Frequency:** Monthly during Phase 1 (Months 0–18 = 2026-10-12 to 2028-04-12) for Regulation adoption and DG COMP guidance tracking; quarterly compliance audits post-Month 18 (2028-04-12); biennial independent audit of clearing and data-sharing compliance post-Month 30 (2029-04-12)

**Responsible Role:** Compliance, Competition Law and Passenger Rights Committee (CCPR) Chair for monitoring and escalation; Head of Compliance and Risk (Programme Office) for day-to-day tracking; DG MOVE and DG COMP liaison for legislative and competition-law status updates

**Adaptation Process:** If Regulation adoption is delayed beyond Month 18 (2028-04-12) (e.g., no Official Journal publication), CCPR issues a warning to PSC by Month 16 (2028-02-12); standards-working group shifts to a shadow workstream with provisional compliance assumptions, and binding-standards approval is deferred to Month 24 (2028-10-12) or Month 30 (2029-04-12) pending Regulation publication. If DG COMP guidance letter is delayed beyond Month 12 (2027-10-12), CCPR escalates to PSC by Month 12 (2027-10-12); a provisional clean-team protocol is established by Month 14 (2027-12-12) to protect clearing operations even if formal guidance is pending. If DG COMP guidance raises unforeseen Article 101 concerns, CCPR recommends design modifications (data firewalls, restricted carrier access, independent trustee oversight) by Month 14 (2027-12-12); OMB and TSWG assess implementation burden; PSC votes on remediation by Month 18 (2028-04-12).

**Adaptation Trigger:** Regulation adoption delayed >6 months beyond Month 18 (2028-04-12) target; DG COMP guidance letter not received or is unfavorably conditional by Month 12 (2027-10-12); passenger-rights legal opinion identifies material gaps vs. Regulation 1371/2007 by Month 6 (2027-04-12); GDPR or data-governance assessment flags compliance risks in clearing or disruption-feed design by Month 6 (2027-04-12); accessibility compliance audit finds >20% of services unable to meet assistance or wheelchair-access thresholds by Month 40 (2030-02-12)

### 5. Distributor Participation and Commission-Rate Monitoring
**Monitoring Tools/Platforms:**

  - Distributor Engagement and Commitment Log (Trainline, Omio, concessionaire, smaller platforms)
  - Published Commission-Rate Data (monthly by distributor type and corridor, audited for discrimination)
  - Distributor Complaint and Discrimination Log (filed with Programme Office, escalated to regulators if unresolved)
  - Through-Ticket Sales Attribution by Distributor (volume share, growth trajectory, concessionaire performance vs. private platforms)

**Frequency:** Biweekly distributor briefings Months 2–6 (2026-12-12 to 2027-04-12) during commission-band negotiation; monthly commission-rate publication and discrimination audit post-Month 12 (2027-10-12); quarterly through-ticket sales reporting by distributor post-Month 30 (2029-04-12)

**Responsible Role:** Head of Distributor and Consumer Affairs (Programme Office) for bilateral engagement and sales tracking; CCPR for discrimination audits and regulatory escalations; concessionaire (contract oversight) for last-resort service performance

**Adaptation Process:** If Trainline, Omio or another major distributor declines to integrate with the clearing and settlement layer, Head of Distributor and Consumer Affairs negotiates a fallback technical interface (third-party settlement intermediary, alternative reconciliation format) within two weeks; if rejected, Programme Office documents the withdrawal and estimates impact on through-ticket volumes. If commission-rate data shows systemic discrimination (e.g., concessionaire charged 1.0% vs. private platforms charged 3.5%), CCPR launches a discrimination investigation; if findings confirm bias, concession contract is reviewed and rates are adjusted retroactively or the concession is opened to competitive re-tender. If a distributor's through-ticket volumes lag forecast by >30%, OMB reviews distributor engagement strategy and may reallocate funding or support to accelerate platform integration or marketing.

**Adaptation Trigger:** A major distributor (Trainline, Omio) announces non-participation or delayed integration by Month 12 (2027-10-12); published commission rates show >1.5% dispersion between distributor types (indicating potential discrimination); through-ticket sales attributed to distributors fall >20% below forecast by Month 36 (2029-10-12); concessionaire operating subsidy draw exceeds EUR 15M/year (triggering subsidy-cap review); discriminatory commission-rate complaint filed by a distributor, unresolved after 30 days

### 6. Operational Readiness and Passenger-Experience Monitoring
**Monitoring Tools/Platforms:**

  - Live-Pilot Report (500–1,000 passengers per corridor, Months 12–18 = 2027-10-12 to 2028-04-12)
  - Disruption Re-accommodation Performance Dashboard (response time to missed connections, reroute success rate, passenger satisfaction, post-Month 12 = 2027-10-12 pilots)
  - Ticket-Validation Deployment Audit and Scorecard (% of corridor rolling stock and stations with validation capability, monthly Months 30–40 = 2029-04-12 to 2030-02-12)
  - Passenger-Rights and Accessibility Monitoring Dashboard (complaints, resolution time, assistance and bicycle-reservation fulfillment, post-Month 48 = 2030-10-12 go-live)

**Frequency:** Live-pilot data collection and weekly review Months 12–18 (2027-10-12 to 2028-04-12); validation deployment audits at Months 30, 35, 40 (2029-04-12, 2029-09-12, 2030-02-12); post-go-live passenger-experience monitoring monthly from Month 48 (2030-10-12) onwards

**Responsible Role:** Head of Carrier Engagement (Programme Office) and corridor liaison officers for pilot and validation deployment tracking; CCPR Chair for passenger-rights compliance audits post-deployment; OMB for operational readiness assessments before corridor go-live

**Adaptation Process:** Pilot findings (Months 12–18 = 2027-10-12 to 2028-04-12) showing >20% booking failures, disruption response times >60 minutes, or <80% passenger satisfaction trigger operational-manual revisions and carrier re-training by Month 18 (2028-04-12) before pilots close. If ticket-validation deployment lags (e.g., only 60% of corridor vehicles equipped by Month 40 = 2030-02-12), corridor go-live is deferred by 6 months to allow completion; alternatively, a hybrid validation (API handshake + fallback manual verification) is deployed as interim measure. Post-deployment, if passenger complaints about missed-connection re-accommodation exceed 5% of through-tickets or resolution time exceeds 48 hours, operationalmanual procedures are audited and carriers are required to retest re-accommodation procedures within 30 days or face tranch withholding.

**Adaptation Trigger:** Live-pilot booking-success rate <85% or disruption response time >60 minutes by Month 18 (2028-04-12); ticket-validation deployment <70% of corridor capacity by Month 40 (2030-02-12); post-go-live passenger complaints about re-accommodation or refunds >5% of through-tickets; assistance or bicycle-reservation request fulfillment <80% within promised timeframe; accessibility audit (post-Month 48 = 2030-10-12) finds >30% of through-ticket itineraries cannot guarantee wheelchair access or assistance, forcing atomic-confirmation failures

### 7. Risk Register and Issue Escalation Monitoring
**Monitoring Tools/Platforms:**

  - Compliance and Risk Register (top 15–20 risks, tracking trigger conditions, mitigation status, owner, escalation paths)
  - Monthly Risk Status Report (OMB and CCPR briefings to PSC, escalation decisions)
  - Issue Log and Remediation Tracking (carrier participation, technical bottlenecks, budget variances, regulatory blockers)
  - Steering Committee Escalation Log (PSC decisions on variances, deadlocks, milestone deferrals)

**Frequency:** Monthly risk-register review by OMB and CCPR; escalations to PSC within five business days if a risk trigger is hit; quarterly risk-trend reporting to PSC (Months 6, 12, 18, 24, 30, 36, 42, 48, 60 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12, 2029-04-12, 2029-10-12, 2030-04-12, 2030-10-12, 2031-10-12 plus ad hoc)

**Responsible Role:** Head of Compliance and Risk (Programme Office) for register maintenance and monthly reporting; Programme Director (OMB Chair) for remediation decisions and escalations; PSC Chair for strategic risk decisions and mitigation approvals

**Adaptation Process:** If a risk trigger is hit (e.g., carrier participation drops below 20, or financial variance exceeds EUR 100M), Head of Compliance and Risk notifies OMB immediately; OMB convenes within two business days to evaluate mitigation options. Remediation is proposed by OMB and escalated to PSC for approval within five business days (e.g., accelerated adapter funding, tier deferral, TEN-T scope reduction). PSC approves mitigation by majority vote (5 of 9 members); if mitigation is contentious, escalation to Commission Transport Commissioner is triggered by Month 5 (2027-03-12 for Month 6 = 2027-04-12 decisions) or immediately for runtime issues (post-binding-standards). Accepted mitigation is published within ten business days to affected stakeholders (carriers, distributors, regulators).

**Adaptation Trigger:** Any risk tracked in the Compliance and Risk Register reaches its defined trigger condition (e.g., 'Carrier refusal if liability model not agreed by Month 4 = 2027-02-12', 'Legislative delay >6 months', 'Article 101 guidance not received by Month 12 = 2027-10-12', 'Budget variance EUR 100M/EUR 200M/EUR 300M'); a new critical risk not previously identified is raised by stakeholder or internal assessment; two or more active risks reach trigger conditions simultaneously (compound risk), escalating to PSC and Commission for coordinated response