Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 13 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 6 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is a regulatory and systems-integration programme to coordinate rail booking, settlement, and passenger rights across EU member states. Its load-bearing mechanisms are software (APIs, databases, settlement platforms), commercial contracts (clearing arrangements, liability pools), and institutional governance (standards bodies, regulators, mediation protocols). None of these depends on violating conservation laws, causality, or the speed-of-light limit, nor does the plan assert that non-physical mechanisms (sentiment, cultural alignment, or unmeasured causal factors) produce its success outcomes. Modal shift, complaint reduction, and through-ticket uptake are attributed to improved service design and transparency — ordinary human decision-making and economic behaviour, both physical.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan addresses the core dependency (actuarial study commissioned by Month 1 = 2026-11-12, priced parameters by Month 6 = 2027-04-12, carrier sign-off by Month 4 = 2027-02-12) with measurable gates and escalation protocols (Commission mediation by Month 5 = 2027-03-12). However, two material gaps remain unresolved: (1) no independent actuarial firm has been engaged yet (assumed to occur at Month 0 = 2026-10-12 project start), so delivery is at risk from late engagement or data access delays; (2) the fallback if liability model fails to win carrier consensus by Month 6 (2027-04-12) is only the "readiness-gate deferral to Month 12 (2027-10-12)," which itself slides binding standards by 6 months and cascades throughout Phase 1 without triggering programme-level contingency decisions (e.g., pivot to a two-tier pool, bilateral liability model, or scope reduction). The 30–40% (estimate) carrier refusal risk remains the single largest threat to network viability, and mitigation stops at administrative escalation rather than pre-approved design fallbacks.

**Mitigation**: Actuarial Project Lead: Engage an independent actuarial firm by Month 0 (2026-10-12) with a 90-day completion target; require carrier claims data (missed-connection rates, rerouting costs, incident clustering) from 5+ major carriers by Month 1 (2026-11-12); deliver interim results and three cap/co-insurance scenarios by Month 3 (2027-01-12); conduct bilateral validation workshops with at least 8 major carriers and CER by Month 4 (2027-02-12); secure signed letters of intent by Month 4 (2027-02-12), or escalate to Commission mediation for design revision by Month 5 (2027-03-12). Additionally, prepare a fallback two-tier pool (core carriers + optional reinsurance for smaller operators) as a pre-approved contingency ready to deploy at Month 5 (2027-03-12) if unmodified pool design fails sign-off.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies a critical strategic blind spot in the programme's core mechanism: the Through-Ticket Liability and Rights Backstop (Decision 1) is pinned to indicative parameters (EUR 500–1,000 per-incident caps, EUR 50M co-insurance threshold, proposed thresholds) that lack actuarial foundation. The plan acknowledges this dependency—'Rated HIGH if any strategic concept driving the plan is undefined'—and the liability model is the primary blocker to carrier participation. The canonical facts state 'Commission the actuarial study... deliver interim Month 3 (2027-01-12), final Month 6 (2027-04-12),' yet no actuarial firm has been engaged at Month 0 (2026-10-12) project start, and the timeline compresses carrier sign-off (Month 4 = 2027-02-12, estimate) to one month after parameters are published. Without priced, carrier-validated liability by Month 4 (2027-02-12), the Month 6 (2027-04-12) steering vote on Decisions 1–5 cannot proceed; 30–40% (estimate) of 25+ target carriers will refuse inventory exposure, fragmenting the network and reducing the 40% through-ticket goal to 15–25% (estimate). The plan provides escalation to Commission mediation by Month 5 (2027-03-12) if consensus fails, but no pre-approved fallback design (e.g., two-tier pool, bilateral liability, scope reduction) is documented. A second undefined element: the split of the EUR 300M concession envelope between platform set-up (estimated EUR 30–50M) and operating subsidy (capped EUR 60M, proposed threshold) remains open at the plan's publication; this ambiguity prevents accurate budget tracking and creates risk of subsidy creep (estimated EUR 75–150M variance, estimate). The Federated Clearing Rulebook (Decision 2) is specified to be published by Month 6 (2027-04-12), providing concrete netting rules and reconciliation tolerance bands; the Availability Query Topology (Decision 5) and Conformance Gate (Decision 6) carry detailed functional specs in the canonical facts. In contrast, Decision 1 and Decision 3 lack the mechanism-of-action clarity required for the steering group to evaluate trade-offs and lock binding votes. Consequently, strategic clarity on the two largest budget items and the two highest participation-risk levers is materially incomplete as of project Month 0 (2026-10-12).

**Mitigation**: Actuarial and Concession Project Leads: Commission the independent actuarial study by Month 0.5 (2026-10-27) with a 90-day completion target (deliverable by Month 3 = 2027-01-12); deliver draft liability model with three cap/co-insurance scenarios and carrier-profile examples by Month 3 (2027-01-12), then conduct bilateral validation workshops Months 2.5–3.5 (2026-12-27 to 2027-01-27) with 8+ major carriers and CER to identify acceptance thresholds. Secure signed letters of intent from at least 8 carriers and CER by Month 4 (2027-02-12) confirming 'will expose through-ticket inventory under [parameters],' or escalate to Commission mediation by Month 5 (2027-03-12) with a pre-prepared two-tier fallback pool ready to deploy. Additionally, Procurement Lead to issue the business-case RFP for the concession by Month 2 (2026-12-12) specifying platform set-up cost breakdown and operating subsidy calculation method; publish finalized business case with binding cost controls and subsidy terms by Month 9 (2027-07-12) before tender issuance Month 12 (2027-10-12). Target completion: liability model with carrier sign-offs and concession business case locked by Month 6 (2027-04-12) steering gate, enabling Decisions 1 and 3 votes at 75% supermajority.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the through-ticket liability model—the critical carrier-participation blocker—remains actuarially unvalidated. The plan specifies indicative caps (EUR 500–1,000 per stranded passenger) and co-insurance thresholds (EUR 50M annual draw), yet no carrier has provided 24-month claims data, no independent actuarial firm has been engaged at project Month 0 (2026-10-12), and the compressed timeline (interim results Month 3 = 2027-01-12, carrier sign-off Month 4 = 2027-02-12) leaves only one month between parameter publication and binding commitment. Without priced, actuarially validated liability by Month 4 (2027-02-12), 30–40% (estimate) of 25+ target carriers will refuse inventory exposure, fragmenting corridors and reducing the 40% through-ticket goal to 15–25% (estimate). Additionally, two material gaps in the strategic choices remain unresolved: (1) the split of the EUR 300M concession envelope between platform set-up (estimated EUR 30–50M) and public service-level payments is undefined, preventing accurate budget tracking and risking subsidy creep of EUR 75–150M (estimate); (2) the fallback if the liability model fails sign-off by Month 6 (2027-04-12) is only deferral to Month 12 (2027-10-12), which itself compresses binding standards (Month 18 = 2028-04-12) without pre-approved design contingencies (e.g., two-tier pool, bilateral liability, scope reduction). The plan articulates detailed functional specs for Decisions 2, 5 and 6 (clearing, availability topology, conformance gate) but leaves Decisions 1 and 3—the two highest participation-risk and largest budget-risk levers—at the indicative/unvalidated stage as of project Month 0 (2026-10-12).

**Mitigation**: Actuarial Project Lead: Engage independent actuarial firm by Month 0.5 (2026-10-27) with 90-day completion target; require 5+ major carriers to provide 24-month missed-connection and rerouting-cost data by Month 1 (2026-11-12); deliver draft liability model with three cap/co-insurance scenarios by Month 3 (2027-01-12); conduct bilateral validation workshops with 8+ major carriers and CER Months 2.5–3.5 (2026-12-27 to 2027-01-27); secure signed letters of intent by Month 4 (2027-02-12), or escalate to Commission mediation by Month 5 (2027-03-12) with pre-approved two-tier fallback pool ready to deploy. Concession Procurement Lead: Issue business-case RFP by Month 2 (2026-12-12) specifying platform set-up cost breakdown and operating subsidy calculation; publish finalized business case with binding cost controls by Month 9 (2027-07-12) before tender issuance at Month 12 (2027-10-12).


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because three critical path predecessors are either unvalidated or carry unmitigated slip risk that jeopardizes the Month 18 (2028-04-12) binding-standards milestone. First, the Regulation adoption status is "(not verified)"; a 6–12 month (estimate) slip is plausible, moving standards from Month 18 (2028-04-12) to Month 24–30 (2028-10-12 to 2029-04-12). Second, DG COMP Article 101 guidance is due Month 12 (2027-10-12), leaving only 6 months to integrate clean-team protocol and standards text; if guidance raises concerns, rework compresses to 4–6 weeks. Third, the actuarial study (liability model sign-off Month 4 = 2027-02-12) and technical audit (tier assignment Month 6 = 2027-04-12) are both compressed into Phase 1, and both feed into binding votes (Month 6 = 2027-04-12); if either slips past Month 6 (2027-04-12), Phase 1 readiness defers to Month 12 (2027-10-12), pushing standards to Month 24 (2028-10-12) and mandatory API exposure to Month 36 (2029-10-12), compressing Phase 2 by 6 months and raising risk of incomplete network coverage."

**Mitigation**: DG MOVE & EU Agency for Railways: File DG COMP pre-notification by Month 2 (2026-12-12) with detailed clearing and data-flow architecture; request expedited interim guidance by Month 9 (2027-07-12) and final guidance by Month 12 (2027-10-12). Simultaneously, develop a shadow OSDM specification aligned with Article 101 safe-harbour by Month 12 (2027-10-12) ready to launch if DG COMP signals extended review. Establish a Phase 1 readiness-gate contingency: if liability sign-off or audit results slip past Month 6 (2027-04-12), invoke a pre-approved deferral to Month 12 (2027-10-12) and adjust binding-standards target to Month 24 (2028-10-12), ensuring stakeholder alignment on contingency authority before Month 3 (2027-01-12)."


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the carrier-funded guarantee pool (Decision 1: Through-Ticket Liability and Rights Backstop) remains actuarially unvalidated as of project Month 0 (2026-10-12). The plan specifies indicative liability caps (EUR 500–1,000 per stranded passenger, proposed threshold) and co-insurance above EUR 50M (proposed threshold), yet no carrier has provided 24-month claims data, no independent actuarial firm has been engaged, and the compressed timeline (interim results Month 3 = 2027-01-12, carrier sign-off Month 4 = 2027-02-12) leaves only one month for bilateral validation before binding steering votes at Month 6 (2027-04-12). Without priced, actuarially validated liability parameters by Month 4 (2027-02-12), an estimated 30–40% of 25+ target carriers will refuse inventory exposure, fragmenting corridors and reducing the 40% through-ticket goal to 15–25% (estimate). Additionally, the Concession Procurement strategy (Decision 3: Public Reference Distributor Mandate) leaves undefined the split of the EUR 300M envelope between platform set-up (estimated EUR 30–50M) and public service-level payments (capped EUR 60M operating subsidy over five years, proposed threshold), preventing accurate budget tracking and creating risk of subsidy creep of EUR 75–150M (estimate). The fallback if liability consensus fails by Month 6 (2027-04-12) is only deferral to Month 12 (2027-10-12), which compresses binding standards from Month 18 (2028-04-12) to Month 24 (2028-10-12) without pre-approved design contingencies (two-tier pool, bilateral liability, scope reduction). Compared to Decisions 2 (Clearing), 5 (Availability Topology) and 6 (Conformance Gate), which include detailed functional specifications in the canonical facts, Decisions 1 and 3—the two highest carrier-participation-risk and largest budget-risk levers—remain at the indicative stage.

**Mitigation**: Actuarial Project Lead: Commission independent actuarial firm by Month 0.5 (2026-10-27) with 90-day completion target; secure 24-month missed-connection and rerouting-cost data from 5+ major carriers by Month 1 (2026-11-12); deliver draft liability model with three cap/co-insurance scenarios by Month 3 (2027-01-12); conduct bilateral validation Months 2.5–3.5 (2026-12-27 to 2027-01-27) with 8+ major carriers and CER; secure signed letters of intent by Month 4 (2027-02-12), or escalate to Commission mediation by Month 5 (2027-03-12) with pre-prepared two-tier fallback pool. Concession Procurement Lead: Issue business-case RFP by Month 2 (2026-12-12) specifying platform set-up cost breakdown and operating subsidy calculation; publish finalized business case with binding cost controls by Month 9 (2027-07-12) before tender issuance Month 12 (2027-10-12).


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the EUR 1,500M budget lacks vendor quotes or scale-appropriate cost benchmarks for three largest line items (clearing EUR 220M, adapters EUR 240M, concession EUR 300M, totalling EUR 760M or 50% of cap). No per-area normalization (EUR/km, EUR/carrier, EUR/transaction) is provided. Concession envelope has undefined set-up vs. subsidy split; validation-hardware financing unresolved; adapter costs assume EUR 240M covers all tiers without evidence from technical audit. Contingency is thin: EUR 85M headroom (5.7%) faces fallback exposures of EUR 275–500M (adapter acceleration, concession cost overrun, Article 101 rework), creating high probability of budget variance triggers (EUR 100M, EUR 200M, EUR 300M cuts).

**Mitigation**: Procurement Lead: Obtain binding cost quotes from ≥3 vendors for clearing platform (EUR 220M line) and real-time infrastructure (EUR 50M line) by Month 6 (2027-04-12). Concession Procurement Lead: Issue RFP for platform set-up cost breakdown by Month 2 (2026-12-12); publish business case with fixed platform cap (EUR 40–50M ±20%) and operating subsidy formula by Month 9 (2027-07-12). Carrier Integration Manager: Complete technical audit by Month 2 (2026-12-12); validate adapter costs per carrier and per shared-module pattern; rebudget Tier 2–3 adapters if cost-per-carrier exceeds EUR 30M. Finance Lead: Run three-scenario variance analysis (base, +30%, +50%) by Month 6 (2027-04-12); publish monthly cash-flow forecast with variance triggers tied to contingency draws.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents the 40% through-ticket share (Month 60 = 2031-10-12, user constraint) as a single point estimate without providing a range, confidence interval, or alternative scenarios (best/worst/base case). The canonical facts and strategic decisions specify "40% by Month 60 (2031-10-12)" without documenting sensitivity to carrier participation (target 25+, minimum viable 15-20), API exposure tiering (if Tier 2/3 slip 6-12 months, estimate), concession volume forecast, or modal shift assumptions. Pre-assessment identifies that if carrier liability fails Month 4 (2027-02-12) sign-off, the 40% goal collapses to "15–30% planning range (estimate)," yet this range is buried in the assumptions section, not presented as an alternative scenario in the binding strategic plan. The plan lacks documented sensitivity analysis showing how the 40% metric varies under the explicitly identified risk scenarios (30–40% carrier refusal, 40–50% adapter delay, Article 101 rework, budget variance triggers). A realistic scenario analysis should have shown base case (25 carriers, Tier 1 only = 35% estimated), scenario A (20 carriers, Tier 2 slip = 25% estimated), scenario B (15 carriers, Tier 3 excluded = 15% estimated). Without this, stakeholders cannot assess credibility or make informed funding and participation decisions.

**Mitigation**: Finance & Analytics Lead: Commission a sensitivity analysis by Month 3 (2027-01-12) modeling through-ticket share under three scenarios—base (25 carriers, on-time delivery), downside (15–20 carriers, Tier 2/3 slip 6–12 months), and upside (30 carriers, early TEN-T)—with carrier participation, pilot conversion rates and concession volume as key drivers. Publish base/worst/conservative case scenarios (targets 35%, 15%, 25%, estimate) in the binding strategic plan by Month 6 (2027-04-12) alongside the 40% headline, so steering votes and carrier commitment are informed by range, not point estimate.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan defines build-critical components with partial artifact coverage but leaves significant gaps unresolved. The OSDM specification is referenced as binding standards (Month 18 = 2028-04-12, user constraint), the conformance test suite is committed by Month 12 (2027-10-12), and interface contracts (ISO 20022 settlement schema, OSDM availability shadow specification) are detailed in the Federated Clearing Rulebook (Month 6 = 2027-04-12, decision) and Availability Query Topology architecture (Month 6 = 2027-04-12, decision). However, two material gaps remain: (1) acceptance tests for through-ticket end-to-end flows (booking → settlement → validation → rerouting) are mentioned only in pilot scope (Months 12-18 = 2027-10-12 to 2028-04-12), not in conformance specifications; no binding acceptance criteria are documented for the federated clearing platform or the disruption event feed before Tier 1 exposure (Month 30 = 2029-04-12). (2) Non-functional requirements for multi-carrier queries are proposed (p95 latency <2 seconds, 99.5% availability, <1% stale-seat failures, proposed thresholds) but lack stress-test validation under realistic load; three-leg query combined availability = 0.995³ ≈ 98.5%, below the 99.5% target, yet no mitigation (e.g., cached shadow fallback strategy) is architecturally specified in binding standards. (3) Integration plan across 25+ carriers is articulated as a phased tier structure (Months 30/36/42 = 2029-04-12, 2029-10-12, 2030-04-12) with adapter procurement (Month 12 = 2027-10-12), but per-carrier integration contracts, handoff criteria between tiers, and rollback/escalation procedures for failed integrations are not documented. Non-functional requirements for the clearing infrastructure (settlement cycle 5 business days, reconciliation error <0.5%, proposed thresholds) are stated but not stress-tested against production-scale transaction volumes or failure modes (carrier bankruptcy, payment processor outage, clock skew across carriers).

**Mitigation**: Standards & Technical Specification Custodian: Publish binding acceptance test suite for through-ticket end-to-end flows (booking, settlement, refund reversal, validation, rerouting) integrated into OSDM conformance specification by Month 12 (2027-10-12). Document non-functional acceptance criteria: settlement cycle 5 business days verified with ≥10,000 daily transactions; reconciliation error <0.5% measured over 30 consecutive business days; p95 latency <2 seconds on three-leg queries under peak load (1,000 concurrent passengers, estimate). Clearing Systems Architect: Stress-test the federated clearing platform under production-scale load (10,000 transactions/day, 25 carrier feeds, multi-currency reconciliation) and publish results with confidence intervals on error rates and settlement-cycle times by Month 24 (2028-10-12). Publish a detailed integration plan per tier (Tier 1, 2, 3) specifying per-carrier handoff criteria, SLA acceptance gates, and rollback/escalation procedures (e.g., if reconciliation error >1% for 2 consecutive months, suspend that carrier from new enrollments) by Month 6 (2027-04-12), binding into conformance requirements.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because three critical legal/operational claims lack verifiable artifacts: (1) "Regulation adopted with amendments by about Month 18 (2028-04-12)" — status not verified, no formal Commission timetable, Council position or Parliament rapporteur report cited; (2) "DG COMP guidance letter by Month 12 (2027-10-12)" — no pre-notification template, service-level agreement or binding timeline confirmation documented; (3) "Binding written sign-off from at least 8 major carriers and CER by Month 4 (2027-02-12)" on liability model — no letters of intent, carrier commitments or contractual templates exist at project start.

**Mitigation**: DG MOVE & Programme Director: Obtain written Regulation adoption timetable from Commission legislative affairs unit and formal OSDM pinning commitment from the EU Agency by Month 2 (2026-12-12). File DG COMP pre-notification by Month 2 (2026-12-12) and secure an expedited guidance schedule. Secure signed letters of intent from at least 8 major carriers and CER confirming inventory exposure under the liability model by Month 4 (2027-02-12).


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the programme's final outputs are poorly specified across three critical dimensions: (1) the Through-Ticket Liability and Rights Backstop (Decision 1) lacks SMART criteria for 'protected connection' entitlement scope, rerouting latency SLA and compensation thresholds per incident type—currently stated only as indicative EUR 500–1,000 per stranded passenger (proposed threshold) without defining 'stranded' (e.g., >30 minutes missed connection, >2 hours reroute wait); (2) the four priority corridors' 'live' go-live date (Month 48 = 2030-10-12) and acceptance criteria are not specified—does 'live' mean 100% of scheduled services have through-tickets, 50% volume, 90% of routes, or p95 latency <2 seconds across all three-leg queries on both directions, and (3) the distributor-complaint 'halved' target (Month 60 = 2031-10-12, user constraint) lacks a documented baseline measurement (complaint volume per corridor, categories, resolution time) and acceptance KPIs (reduction of 50% in complaints per distributor type, or 50% in resolution time, or both?).

**Mitigation**: Passenger Rights & Clearing Operations Leads: Define SMART acceptance criteria by Month 9 (2027-07-12) for the Through-Ticket Liability (Decision 1) specifying: (a) 'protected connection' definition (e.g., >30 minutes missed connection = automatic rerouting or compensation), (b) rerouting latency SLA (e.g., 60-minute response time from delay detection to confirmed alternative seat), (c) compensation matrix per incident type (e.g., EUR 50 for 30–90 minute missed connection, EUR 100 for 90-minute+), with binding acceptance test at Month 30 (2029-04-12) measuring 95% compliance. Define 'four-corridor live' acceptance criteria (e.g., 100% of scheduled services eligible for through-tickets, 90%+ routes bookable within 24 hours, p95 latency <2 seconds on three-leg queries, <1% stale-seat failures, accessibility thresholds met per prior decision) by Month 42 (2030-04-12). Establish baseline complaints audit by Month 3 (2027-01-12) and define 'halved' KPI with quantified per-distributor and per-category targets (e.g., complaint resolution time reduced from 45 to 25 days, complaint volume reduced by 50% per distributor type) by Month 36 (2029-10-12).


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Assistance and Bicycle Reservation Chaining feature (Decision 10, embedded in the programme scope) adds EUR 25–40M (estimated, allocated from the EUR 100M consumer-rollout budget) and operational complexity without directly supporting the 40% through-ticket share or complaints-halving targets. The feature mandates atomic confirmation of accessibility and bicycle spaces—rejecting itineraries if any leg lacks required capacity. This is presented as "required accessibility" (per EU Regulation 1371/2007), yet the plan acknowledges that atomic confirmation will visibly reduce itinerary availability by 10–20% (estimate), creating a trade-off: passengers with disabilities see fewer options than non-disabled passengers, reversing inclusivity intent. The core through-ticketing and modal-shift objectives do not depend on atomic confirmation of accessibility; they depend on search availability, latency, and price competitiveness. A best-effort accessibility model (booking with transparent notice to passenger, separate assistance workflow) would deliver accessibility rights compliance at lower cost and complexity, without blocking itineraries. The atomic model is a design choice (arguably appropriate on equity grounds) but lacks binding legal requirement and creates measurable gold-plating: EUR 25–40M spent to reduce passenger choice.

**Mitigation**: Project Director: Commission a cost-benefit analysis by Month 3 (2027-01-12) comparing atomic confirmation versus best-effort accessibility booking, measuring EUR cost per itinerary preserved and passenger satisfaction per model. If atomic confirmation reduces itinerary availability >15% and satisfaction <70% in pilot testing (Months 12–18 = 2027-10-12 to 2028-04-12), move to best-effort model and reallocate EUR 15–25M from accessibility to complaints-handling staffing or modal-shift features.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Standards & Technical Specification Custodian role is mission-critical and rare. OSDM expertise combined with standards governance authority is scarce and concentrated. This role unblocks binding standards (Month 18 = 2028-04-12) and all API exposure milestones. Vacancy or turnover at critical gates (Months 6, 18 = 2027-04-12, 2028-04-12) collapses standards-working group productivity and delays conformance by 2–4 months.

**Mitigation**: EU Agency for Railways: Validate the talent market for OSDM custodian and governance specialists by Month 2 (2026-12-12) through targeted outreach to UIC standards community, major carriers' OSDM leads, and academic rail systems researchers. Conduct offer-acceptance testing at planned EU grade by Month 3 (2027-01-12) and secure written acceptance from a qualified candidate by Month 4 (2027-02-12) to serve as early go/no-go gate.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because legality is substantially unclear on four critical fronts: (1) Regulation adoption timeline is not verified; 6–12 month slip is plausible, making the binding-standards milestone (Month 18 = 2028-04-12) infeasible without contingency authority; (2) DG COMP Article 101 TFEU guidance is due Month 12 (2027-10-12), with only 6 months to integrate clean-team protocol before standards lock—post-investment challenge risk EUR 50–100M rework; (3) national regulator approval pathways are unmapped—bilateral impact assessments due Month 3 (2027-01-12) but no pre-agreed waivers or corridors-of-agreement exist, creating medium probability of corridor blocking (Risk 12); (4) GDPR compliance is unvalidated—no data-protection impact assessment exists, personal-data flows through shared layers are unmapped, and DPA sign-off is not secured. State-aid clearance for the EUR 60M concession subsidy is also unmapped. Controlling regimes (Regulation proposal, Article 101, GDPR, Regulation 1371/2007, accessibility law, national regulator mandates) are identified but approval status, timing and contingency authority are absent.

**Mitigation**: DG MOVE & Competition/Legal Team: Commission a Fatal-Flaw Analysis by Month 1 (2026-11-12) mapping all regulatory approvals required (Regulation adoption, DG COMP guidance, national regulator bilateral clearances, state-aid pre-approval, GDPR compliance, accessibility law alignment) with authority, required artifact, lead time and predecessors per controlling regime. File DG COMP pre-notification by Month 2 (2026-12-12) with data-flow architecture; conduct bilateral regulator impact assessments by Month 3 (2027-01-12); secure DG BUDG state-aid pre-clearance for concession subsidy by Month 6 (2027-04-12); commission GDPR impact assessment by Month 2 (2026-12-12) and obtain DPA sign-off by Month 12 (2027-10-12). Establish NO-GO rule: if Regulation adoption is not confirmed for Month 18 (2028-04-12) by Month 6 (2027-04-12), or if DG COMP guidance raises unfixable Article 101 barriers, or if any national regulator issues an enforcement hold by Month 9 (2027-07-12), invoke the Month 12 (2027-10-12) readiness-gate deferral and contingency authority to launch shadow standards or voluntary pilot.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because a sustainable operational model exists for the core through-ticketing infrastructure (OSDM standards, federated clearing, SLA monitoring) but material gaps remain in post-Month 60 (2031-10-12) funding and cost-recovery mechanisms. Evidence: The plan specifies "transfer [ongoing] operations to permanent governance (Agency custodian, carrier steering, regulator oversight) by Month 60 (2031-10-12)," and the clearing platform, settlement operations, and conformance test suite are designed for long-term institutional stewardship at the EU Agency for Railways. However, two critical sustainability gaps are unresolved: (1) no post-Month 60 (2031-10-12) cost-recovery model exists—operations cost estimated at EUR 30–50M annually (estimate) is currently grant-financed with no documented revenue streams or carrier/distributor fee structure beyond the concession subsidy cap; (2) the concession transition is undefined—the five-year term (Month 60 = 2031-10-12) ends without clarity on whether operations transfer to public direct management (EUR 30–50M annual cost to the Commission) or a second-wave concessionaire, creating a fiscal cliff. Concerns can be addressed by designing fee-sharing and governance handover protocols by Month 36 (2029-10-12), but absence of binding cost-share agreements by project completion creates medium-term sustainability risk.

**Mitigation**: Finance & Governance Lead: Commission a post-Month 60 (2031-10-12) sustainability plan by Month 24 (2028-10-12) modeling three cost-recovery scenarios—(1) public funding extension via EU transport budget, (2) carrier and distributor fee-sharing (e.g., 1–2% of transaction value per line item), (3) hybrid cost-share with regulatory mandates. Publish binding governance charter and cost-allocation terms by Month 36 (2029-10-12) specifying Agency custodian roles, carrier steering committee authority, fee structures and transfer-of-operations protocol. Issue a second-wave concession RFP by Month 48 (2030-10-12) for post-Month 60 (2031-10-12) operations, securing concessionaire commitment by Month 54 (2031-04-12).


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the programme depends on three binding hard constraints—the Regulation adoption (Month 18 = 2028-04-12, user constraint), Article 101 TFEU competition-law clearance (Month 12 = 2027-10-12), and national railway regulator approval (Month 3 = 2027-01-12 baseline bilateral assessments)—yet none have been confirmed or approved as of project Month 0 (2026-10-12). The pre-project assessment states Regulation adoption status as "(not verified)"; a 6–12 month slip is "plausible (estimate)." DG COMP guidance is due Month 12 (2027-10-12) with only 6 months to integrate clean-team protocol before standards lock (Month 18 = 2028-04-12), creating post-investment rework risk of EUR 50–100M (estimate) if Article 101 concerns emerge. Risk 12 identifies medium probability that a national regulator on a priority corridor blocks data-sharing or clearing on incumbent-protection grounds, fragmenting the network for 12–24 months (estimate). However, the plan explicitly schedules mitigation: (1) DG COMP pre-notification by Month 2 (2026-12-12); (2) bilateral regulator impact assessments by Month 3 (2027-01-12) with deferral options for non-compliant corridors; (3) shadow standards workstream ready by Month 12 (2027-10-12) if prerequisites slip; (4) fallback pilot authority by Month 6 (2027-04-12) if Regulation adoption is not confirmed. Material gaps remain: no written confirmation of Regulation timetable has been obtained as of Month 0 (2026-10-12); no pre-agreed regulatory waivers or corridors-of-agreement exist; state-aid clearance for the EUR 60M concession subsidy is unmapped. The programme can proceed under Decisions 1–5 with conditional deferral to Month 12 (2027-10-12) if regulatory prerequisites are not met by Month 9 (2027-07-12), but this contingency is not explicitly linked to binding-standards authority or carrier participation commitments."

**Mitigation**: DG MOVE & Competition Law Counsel: File DG COMP pre-notification describing federated clearing, data flows and through-fare construction by Month 2 (2026-12-12); obtain written Regulation adoption timetable from Commission legislative affairs unit and bilateral regulatory approval pathways from each member state on the four priority corridors by Month 3 (2027-01-12); secure DG COMP interim guidance and national regulator sign-off by Month 9 (2027-07-12); if Regulation adoption is not confirmed for Month 18 (2028-04-12) or any priority-corridor regulator issues an enforcement hold, invoke the pre-approved Month 12 (2027-10-12) readiness-gate deferral and contingency authority (shadow standards or voluntary pilot).


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the programme's core real-time data infrastructure—the streamed availability shadow, federated disruption event feed, and settlement reconciliation platform—depends entirely on external vendor delivery (EUR 50M real-time layer, EUR 220M clearing platform, EUR 30M shared adapters). No contracts have been signed, no vendor performance baselines exist, and no contingency suppliers are identified. The availability shadow must sustain sub-100ms cache lookups and <5-minute staleness; the disruption event feed must guarantee exactly-once message delivery across 25+ carriers with <5-second propagation lag; the reconciliation platform must process >10,000 transactions/day with <0.5% error rate. If the primary vendors miss SLAs (proposed: latency >2 seconds, availability <99.5%, reconciliation error >1%), fallback suppliers are not contracted, and rework cascades to Phase 2 (Months 18–48 = 2028-04-12 to 2030-10-12). The pre-project assessment identifies this as 'single points of failure with no tested fallback' for the streamed availability layer and settlement reconciliation, meeting the HIGH threshold. Contingency architecture (distributed cache failover to scheduled-only, bilateral settlement fallback to carrier netting) is described conceptually but not stress-tested or contractually locked. Three-leg query combined availability at 95% per leg = 86% combined (below the 99.5% SLA), requiring architectural mitigation that is not procurement-locked. Estimated consequence: if vendor delivery slips 6–12 months or performance misses SLAs, stale-seat failures exceed 5%, reconciliation errors spike to 2–3%, and distributors exit; Phase 2 timeline slips 3–6 months, pushing four-corridor go-live from Month 48 (2030-10-12) to Month 54–60 (2031-04-12 to 2031-10-12), compressing TEN-T extension window.

**Mitigation**: Procurement Lead: Issue RFPs for the three critical layers by Month 3 (2027-01-12): (1) distributed cache and event-streaming platform (EUR 15–25M real-time layer subset); (2) federated netting and reconciliation platform (EUR 20–40M clearing subset); (3) shared adapter modules (EUR 30M). Obtain binding fixed-price proposals from at least 3 vendors per layer by Month 6 (2027-04-12); select and contract the lowest-qualified bidder by Month 9 (2027-07-12). Include contractual SLA penalties (5% of contract value per month if latency >3 seconds, availability <99%, reconciliation error >1.0%), tested failover procedures (scheduled-only fallback, bilateral clearing fallback) in all contracts, and mandatory stress-testing at Months 12, 24, 36 (2027-10-12, 2028-10-12, 2029-10-12) under production-scale load (10,000 transactions/day, 25-carrier feeds). Identify and pre-qualify a secondary vendor for the reconciliation platform by Month 12 (2027-10-12) so rework does not create a single-supplier lockdown if the primary vendor misses conformance gates.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies the fundamental conflict between Finance Department incentives (quarterly budget adherence, cost minimisation) and the R&D/Carrier Integration Team incentives (long-term capability, schedule adherence, quality outcomes) but does not establish binding shared success criteria that would align both parties. The canonical facts specify that the Programme Office (80 staff, estimate) must coordinate 25+ national operators, independent distributors, and member-state bodies under a 75% supermajority steering rule, yet no explicit mechanism locks Finance and Carrier Integration to a unified through-ticket goal (40% by Month 60 = 2031-10-12) with measurable intermediate milestones. Finance is incentivised to hold budget variance within EUR 100M (defer TEN-T) and release tranches only when conformance gates are formally verified; the Carrier Integration team is incentivised to achieve API readiness (Months 30/36/42 = 2029-04-12, 2029-10-12, 2030-04-12) on their tier dates, which may conflict with Finance's budget-release conditions if verification audits slip 2-3 weeks past funding decision dates.

**Mitigation**: Steering Group Finance Committee: Design a shared OKR by Month 3 (2027-01-12) uniting Finance and Carrier Integration: Key Result 1 (Finance owner): maintain cumulative variance below EUR 100M through Month 36 (2029-10-12); Key Result 2 (Integration owner): 80% of Tier 1, 70% of Tier 2, 60% of Tier 3 carriers achieve conformance by their tier dates (Months 30, 36, 42 = 2029-04-12, 2029-10-12, 2030-04-12). Publish the OKR in the binding programme charter (Month 6 = 2027-04-12); establish monthly Joint Finance & Integration Dashboard showing variance burn, conformance progress, and contingency triggers (EUR 50M, EUR 100M, EUR 200M) visible to both teams. Schedule quarterly Executive Alignment Reviews (Months 9, 18, 27, 36 = 2027-07-12, 2028-04-12, 2029-01-12, 2029-10-12) where Programme Director, Finance Lead and Integration Manager jointly review OKR progress and agree corrective actions if either KR is at risk of miss.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan specifies KPIs (40% through-ticket share, <0.5% reconciliation error, halved complaints), review cadence (biweekly steering, monthly SLA reports, quarterly budget re-baselining), owners (Programme Director, Finance Lead, Carrier Integration Manager, Clearing Operations Lead), and change-control thresholds (EUR 100M/200M/300M variance triggers with pre-defined scope cuts). However, three material gaps prevent a LOW rating: (1) no unified governance charter documents the change-control decision body, escalation protocol and authority to invoke stop/re-plan—feedback loop elements are scattered across nine role descriptions; (2) escalation timelines and decision rules for individual KPI misses are implicit, not binding (e.g., if through-ticket share <30% at Month 54 = 2031-04-12, what is the escalation path and decision deadline?); (3) the variance triggers are pre-approved scope cuts, not re-plan/stop decisions—there is no documented threshold at which the entire programme is re-scoped or halted.

**Mitigation**: Programme Director: Develop a unified Change-Control Governance Charter by Month 3 (2027-01-12) establishing a Change Control Board (steering core members), monthly KPI review protocol with escalation rules per KPI (if through-ticket share <30% by Month 54 = 2031-04-12, escalate to Transport Commissioner within 10 days), variance-trigger decision authority (EUR 100/200/300M triggers automatically convene the Board and require a decision within 5 business days), and a formal stop rule (e.g., if net carrier participation drops below 12 operators by Month 42 = 2030-04-12, invoke programme re-plan or halt authority).


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the programme's core dependencies—liability model (FM3), technical integration (FM2), regulatory clearance (FM5), clearing mechanism (FM1) and concession funding (FM7)—form 5 distinct but tightly coupled critical-path risks. A single failure (e.g., actuarial study delay, Regulation adoption slip, DG COMP Article 101 concerns) cascades across 3+ domains: FM3 (liability failure) → FM2 (carrier refusal) → FM4 (staffing stretched) → FM5 (standards slip). Fallback cost exposures (EUR 275–500M) exceed headroom (EUR 85M) by EUR 65–415M, triggering variance-cut cascades (EUR 100M/200M/300M thresholds) that force TEN-T deferral, concession cuts, or scope restriction to four corridors, each reducing through-ticket share from 40% to 15–25% (estimate). No integrating bow-tie or FTA analysis published.

**Mitigation**: Risk Integration Lead: Develop a formal risk cross-impact matrix and bow-tie diagram by Month 6 (2027-04-12) showing linkages among FM1–FM9, identifying 3+ shared root causes (e.g., Programme Office capacity, Regulation adoption timeline, carrier data availability) and 5+ multi-domain failure paths (liability → participation → budget → schedule, data governance → regulatory → rework). Establish NO-GO thresholds: if any two concurrent risks from different clusters materialize (e.g., FM3 + FM5 by Month 9 = 2027-07-12, or FM2 + FM7 by Month 24 = 2028-10-12), invoke contingency re-plan or scope reduction; publish contingency triggers and pre-approved response playbooks by Month 3 (2027-01-12).