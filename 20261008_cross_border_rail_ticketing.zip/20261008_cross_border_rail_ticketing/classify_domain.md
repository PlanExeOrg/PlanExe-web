**Primary domain:** Rail Ticketing Interoperability

**Secondary domains:** Transport Regulation, Clearing and Settlement, Passenger Rights Law

**Rationale:** Rail Ticketing Interoperability is the only outcome-role candidate and matches the core mechanism of cross-border through-ticketing. Transport Regulation, Data Interoperability Architecture, Clearing and Settlement and Public Program Management are constraints or methods subordinate to that goal.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Rail Ticketing Interoperability | 5 | 5 | outcome | Core mechanism: OSDM-compatible through-ticketing, distribution, and booking across carriers on cross-border corridors. |
| Transport Regulation | 5 | 4 | constraint | Must align with the EC proposed rail booking regulation, passenger rights, and national regulators. |
| Data Interoperability Architecture | 5 | 4 | method | Shared real-time data layer with OSDM-compatible APIs demands standards-based API and data architecture. |
| Clearing and Settlement | 4 | 4 | method | Inter-carrier revenue clearing and single-payment settlement underpin through-ticket sales. |
| Passenger Rights Law | 4 | 4 | constraint | Continuity-of-journey, refund harmonisation and passenger-rights backstop require EU consumer and transport law expertise. |
| Competition Law | 4 | 4 | constraint | Non-discriminatory distributor access and inter-carrier data and fare sharing raise antitrust and access obligations. |
| Payment Systems | 4 | 4 | method | Single-payment settlement and refunds across carriers require payment orchestration and split-payment design. |
| Public Program Management | 4 | 3 | method | Coordinating a €1.5 billion, multi-stakeholder, five-year program across member states requires program governance. |
| Accessibility Compliance | 3 | 4 | constraint | Persons with reduced mobility assistance booking must meet accessibility rules and disability-rights requirements. |