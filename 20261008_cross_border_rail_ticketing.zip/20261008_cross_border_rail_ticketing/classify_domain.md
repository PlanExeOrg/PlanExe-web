**Primary domain:** Rail Ticketing Interoperability

**Secondary domains:** Transport Regulation, Public Program Management, Clearing And Settlement

**Rationale:** Rail Ticketing Interoperability is the outcome-role candidate with the highest importance × specificity (25) and names the program's core mechanism: OSDM-based cross-border through-ticketing. Transport Economics is a narrower outcome; Transport Regulation, Clearing And Settlement and API Standardization are constraints or methods.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Rail Ticketing Interoperability | 5 | 5 | outcome | Core mechanism: OSDM-based cross-border through-ticketing, distribution, clearing and refunds across carriers. |
| Transport Regulation | 5 | 4 | constraint | Program must align with proposed EU Regulation and passenger-rights and non-discrimination obligations. |
| Clearing And Settlement | 4 | 5 | method | Inter-carrier revenue clearing and single-payment settlement mechanism is a core build component. |
| Passenger Rights Law | 4 | 4 | constraint | Continuity-of-journey, refund harmonisation and rights backstop must satisfy EU passenger-rights rules. |
| API Standardization | 4 | 4 | method | OSDM-compatible real-time data layer needs binding standards, conformance testing and non-discriminatory access. |
| Transport Economics | 4 | 4 | outcome | Success depends on modal shift from short-haul air to rail and on fare and cost modelling. |
| Competition Law | 4 | 4 | constraint | Non-discriminatory distributor access and inter-carrier data and settlement arrangements raise EU competition issues. |
| Data Governance | 4 | 4 | method | The shared real-time data layer needs rules on access, data protection, quality and stewardship. |
| Public Program Management | 4 | 3 | method | Coordinating €1.5 billion multi-stakeholder rollout across member states, corridors and five-year milestones. |