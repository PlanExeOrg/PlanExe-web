### Premise Attack 1 — Integrity
_Forensic audit of foundational soundness across axes._

**[STRATEGIC] The program treats booking friction as the main reason people fly rather than take the train, but short-haul rail loses on journey time, track capacity, rolling stock and price, which a €1.5 billion ticketing and data program cannot change, so its headline targets are disconnected from its levers.**

**Bottom Line:** REJECT: A €1.5 billion ticketing and data program cannot deliver the 40% through-ticket and plane-to-train shift it promises, and its schedule outruns a proposal that has not been adopted.


#### Reasons for Rejection

- The Commission's own estimate for its May 2026 proposal is that easier single-ticket booking could raise rail travel by up to 5 percent, so a target of 40% of cross-border journeys sold as through-tickets in five years and a mode shift away from flying is not supported by the premise's own benchmark.
- The Lisbon-to-Tallinn through-ticket example promises a product that cannot be run reliably: the Iberian gauge break, uneven cross-border capacity and the unfinished Baltic link mean a single ticket would sell a connection chain the infrastructure cannot honour, and continuity-of-journey liability would land on carriers that control none of the delay.
- Binding standards at Month 18 (2028-04-08), mandatory APIs at Month 30 (2029-04-08) and full corridor through-ticketing at Month 60 (2031-10-08) (user constraint), with a start 'ASAP' (Month 0 = 2026-10-08), run ahead of a Commission proposal presented in May 2026 that Parliament and Council have not adopted, so the program builds mandatory technical obligations on a legal text that can still change.
- A publicly funded reference distributor inside the €1.5 billion competes with Trainline and Omio, which are also the 'independent distributors' whose complaints the program promises to halve, and the program is also expected to arbitrate their access terms.
- The €1.5 billion public budget (user constraint) pays for standards, testing, a clearing mechanism and apps, while the private IT cost of about 25 carriers rebuilding inventory, fare and settlement systems is left as a separate, larger estimate, so the public money only subsidises the cheapest part of the transition and cannot make the carriers deliver the expensive part.

#### Second-Order Effects

- 0–6 months: Carriers and distributors treat the work as a lobbying arena, with CER members, Trainline and Omio fighting over API terms and clearing rules while the legislative text is still open, so no implementation starts.
- 1–3 years: Standards are frozen at Month 18 (2028-04-08) before the final regulation settles, which forces rework, and carriers expose minimal APIs to meet the Month 30 (2029-04-08) deadline without making real-time inventory available for through-sales.
- 5–10 years: The through-ticket share stays far below 40%, short-haul flying is barely affected, and the program is judged on its measurable outputs (APIs, clearing volume) while a public booking app with little traffic keeps needing money.

#### Evidence

- Law/Standard — Regulation (EU) 2021/782 on rail passengers' rights (2021): Article 12 already requires through-tickets and missed-connection protection for sole undertakings, and the overlap with this program's continuity-of-journey scope is not addressed.
- Case/Incident — Commission proposal on digital rail booking and ticketing, rail passenger package (May 2026): the Commission's own impact estimate is up to 5 percent more rail travel, far below the scale this program assumes.



### Premise Attack 2 — Accountability
_Rights, oversight, jurisdiction-shopping, enforceability._

**[STRATEGIC] — Cart Before The Statute: A €1.5 billion (user constraint) public program is built to execute a Commission proposal that, at Month 0 (2026-10-08), is still unadopted law, and it bundles three incompatible goals (through-tickets, distributor fairness, fewer flights) under one 40% target that no single instrument can deliver.**

**Bottom Line:** REJECT: Cart Before The Statute — this program spends €1.5 billion (user constraint) to implement a law that does not yet exist, and it promises a mode shift from air that a booking-channel metric cannot show. It deserves no gate pass until the premise stops treating a pending proposal as settled ground.


#### Reasons for Rejection

- Passengers are promised continuity-of-journey rights and single-payment settlement while the legal text that defines who owes what is still being negotiated, so riders would be sold protections whose legal basis can change after they buy.
- A shared data layer, a clearing mechanism, a public reference distributor and a rights backstop put one coordinating body in charge of inventory, money and complaints across 25-plus carriers, with no named party answerable when a Lisbon–Tallinn itinerary fails in the middle.
- Starting on four rich corridors and then extending to the full TEN-T network invites every carrier and distributor to copy the interface and pricing rules at once, and a wrong settlement or fare-sharing formula would be baked into millions of tickets before anyone could withdraw it.
- The value case rots at the core: the 40% through-ticket target (user constraint) measures sales channel behaviour, not whether trains beat planes on price and time, so public money could succeed on paper while Lisbon–Tallinn remains slower and dearer than a flight, and the public reference distributor competes against Trainline and Omio using taxpayer funds.

#### Second-Order Effects

- **T+0–6 months — The Cracks Appear:** Carriers and distributors stall on commitments because binding standards (Month 18 = 2028-04-08 target, user constraint) depend on a regulation not yet adopted, and the program spends its first budget tranche on workshops about rules that may be rewritten.
- **T+1–3 years — Copycats Arrive:** Neighbouring modes and national governments demand equal public subsidy for their own booking and settlement layers, producing parallel platforms that each claim to be the neutral one.
- **T+5–10 years — Norms Degrade:** Incumbents treat mandatory API exposure (Month 30 = 2029-04-08 target, user constraint) as a compliance chore, expose thin or delayed inventory, and the shared real-time layer becomes a catalogue of what carriers are willing to admit is available.
- **T+10+ years — The Reckoning:** An audit finds that through-ticket share moved because of bundling and default placement rather than better journeys, flight volumes on the target routes barely changed, and the public distributor is kept alive only because closing it would strand the passengers who rely on it.

#### Evidence

- Case/Report — The European Commission's "Passenger Package" (published 13 May 2026, per web search) comprises proposals on rail ticketing (Single Digital Booking and Ticketing Regulation), multimodal digital mobility services and revised rail passenger rights; it is a proposal, not adopted law, so a program built on it presumes its outcome.
- Law/Standard — Regulation (EU) 2021/782 on rail passengers' rights and obligations already sets through-ticket, assistance and compensation rules, so a parallel passenger-rights backstop duplicates or contradicts an instrument already in force.
- Case/Report — UIC's Open Sales and Distribution Model (OSDM), now specified as UIC IRS 90918-10, is an industry-built standard whose first national rollout was Sweden on 16 April 2024 (per UIC/CER release); the sector is already building the interface this program would fund again with public money.
- Law/Standard — Directive (EU) 2019/882 (European Accessibility Act) and Regulation (EU) 2021/782 both impose accessibility duties; stacking a separate accessibility regime onto a 25-carrier clearing layer sets up conflicting obligations. (Applicability to this specific program not verified.)



### Premise Attack 3 — Spectrum
_Enforced breadth: distinct reasons across ethical/feasibility/governance/societal axes._

**[STRATEGIC] Treating a booking-software gap as the reason trains lose to planes, the program spends €1.5 billion on ticketing while track, rolling stock, timetables and fares stay untouched.**

**Bottom Line:** REJECT: A €1.5 billion ticketing program cannot make trains beat planes, and it would leave Europe with a public distributor, a settlement bureaucracy and the same slow, scarce cross-border trains.


#### Reasons for Rejection

- Feasibility and causation: selling a Lisbon–Tallinn through-ticket does not create a Lisbon–Tallinn train, so the goal of fewer travellers choosing the plane depends on journey times and capacity that a ticketing program cannot buy.
- Governance and timeline: binding standards by Month 18 (2028-04-08), mandatory APIs by Month 30 (2029-04-08) and full corridor through-ticketing by Month 60 (2031-10-08) all rest on a Commission regulation that was only proposed in May 2026, so the program starts ASAP on a text that is not yet law.
- Budget: €1.5 billion (user constraint) of public money funds standards, testing, clearing and apps, while the far larger carrier IT investment, which decides whether any of it works, is left unpriced and in the hands of more than 25 operators.
- Legitimacy and competition: a publicly funded reference distributor competing with Trainline and Omio, in a program that also writes the non-discriminatory access terms those rivals must live under, makes the state both referee and player.
- Incentives and liability: a clearing mechanism and passenger-rights backstop make each carrier answerable for connections missed on a rival's network, while hooks into short-haul air build a flight-selling channel into a program whose success metric is fewer flights.

#### Second-Order Effects

- 0–6 months: Operators and distributors wait for the legislative text to settle and bargain over conformance rules, so the first months of the €1.5 billion go to committees and consultations (estimate), not to a single ticket sold.
- 1–3 years: By the Month 30 (2029-04-08) API deadline, incumbents comply minimally by exposing limited or high-priced inventory, distributors file the complaints the program promised to halve, and the clearing mechanism turns into a dispute forum over who pays for missed connections.
- 5–10 years: Through-tickets exist on the four named corridors but make up well under the 40% target (estimate), airlines keep their short-haul routes because train times and capacity have not changed, and a permanent publicly funded distributor and settlement body remains as an entrenched cost.

#### Evidence

- Report/Guidance — European Commission, 'One journey, one ticket, full rights' press release (2026): shows the single digital booking and ticketing regulation was only proposed in May 2026, so binding obligations still depend on adoption by Parliament and Council.
- Law/Standard — Regulation (EU) No 454/2011, TAP TSI (2011): the EU already mandates telematic data exchange for rail passenger services, and cross-border through-ticketing remained fragmented anyway, so software standards alone have not delivered it.
- Law/Standard — Regulation (EU) 2021/782 on rail passengers' rights (2021): the recast regulation already contains through-ticket and rights provisions, and the gap this program targets persists despite them.



### Premise Attack 4 — Cascade
_Tracks second/third-order effects and copycat propagation._

**Strategic flaw: the program treats fragmented booking software as the reason Europeans fly instead of ride, and it sets a 60-month delivery clock on a regulation that is only a proposal, opposed by the carriers whose inventory, fares and liability it needs. A €1.5 billion public layer cannot override incumbents' commercial incentives to withhold inventory, or the physical timetable, capacity and price gaps that decide the train-versus-plane choice.**

**Bottom Line:** Abandon the premise: building a continent-wide booking and clearing layer on an unadopted regulation, against the commercial interests of the carriers it depends on, will not make rail beat air. The constraints on modal shift are the timetable, price, capacity and infrastructure, not the ticket-purchase interface, so no implementation of this plan reaches its goals.


#### Reasons for Rejection

- The Phantom Mandate Clock: the 18/30/60-month milestones assume the Commission's May 2026 proposals become binding law, with usable delegated and implementing acts, on a schedule the project does not control. Starting 'ASAP' means Months 0-18 (2026-10-08 to 2028-04-08) of standards work, conformance tooling and hiring run ahead of any legal obligation. Carriers can cooperate or stall at no legal cost, and the proposal's own text can change in trilogue (the legislative negotiation between Commission, Parliament and Council).
- The Inventory Hostage Equilibrium: through-ticketing needs incumbents to expose real-time inventory and fares to rivals and to Trainline or Omio-type platforms. Their dominant-platform and price-rise warnings (CER, May 2026) show that they see exposure as a threat, not a service. Expect compliant-on-paper APIs that return stale, restricted, or worse-priced inventory, with 'non-discriminatory terms' contested for years.
- The Settlement Tug-of-War: a clearing mechanism must split one through-ticket's revenue across 25+ carriers with different yield-management regimes, VAT treatment, reduction cards and refund exposures. Every allocation key creates winners and losers, so governance becomes a standing dispute among carriers. No €1.5 billion budget line settles who absorbs a missed connection or a refunded segment.
- The Referee-Player Trap: funding a public reference distributor while regulating private distributors puts the program in competition with the Trainline and Omio class it needs to onboard. Private platforms will read it as a subsidised rival, and carriers will see another gatekeeper. If it succeeds commercially it distorts the market, and if it does not, it is a €-scale demo app.
- The Booking-Funnel Fallacy: the success metric, rail beating air on competitive short-haul routes, depends mainly on door-to-door time, price, frequency, night-train and rolling-stock supply, track access charges and border-crossing infrastructure. A better checkout changes none of these. The 40% through-ticket share and the modal-shift goal are measured on different causal chains, so hitting one will not deliver the other.

#### Second-Order Effects

- Months 0-12 (2026-10-08 to 2027-10-08): Standards bodies, DG MOVE, ERA and CER begin work before the legal text is settled. Carriers join as 'participants' to shape the specification, not to commit inventory. Funds go to workshops, reference implementations and conformance testing for a standard that may be rewritten when the regulation is amended.
- Months 12-30 (2027-10-08 to 2029-04-08): Binding standards land and API exposure is due. Incumbents deliver minimal-compliance endpoints with delayed or restricted fares. Distributors file complaints, which the 'halve complaints' target treats as a metric. National regulators with uneven capacity apply the rules inconsistently, so complaints go up in the short run, not down.
- Months 30-48 (2029-04-08 to 2030-10-08): The clearing mechanism goes live on the first corridors. Disputes over revenue allocation, refund liability and reduction-card reimbursement stall settlement. Some carriers withhold the cheapest fares from through-ticket channels to avoid exposure, so through-tickets cost more than separate tickets and uptake stays far below 40% (estimate: single-digit to low-teens share on pilot corridors).
- Months 48-60 (2030-10-08 to 2031-10-08): Corridor through-ticketing reaches only part of the busiest routes. The private carrier IT bill (estimate: several billion euros, not verified, to be costed separately) falls on operators already carrying legacy systems, and some pass it into fares. Airlines' short-haul routes are unaffected because time and price gaps remain, so the headline modal-shift claim is not met.
- Months 60-120 (2031-10-08 to 2036-10-08): The program becomes a permanent consortium cost centre. A new round of legislation is proposed to 'fix' enforcement, repeating the cycle of earlier rail-passenger-rights and TAP-era promises. Politicians declare the booking layer done and the modal-shift goal unmet, and the credibility of EU rail digitalisation falls.

#### Evidence

- The EU already tried this: the Telematics Applications for Passenger Services TSI (TAP TSI) was adopted as Commission Regulation (EU) No 454/2011, in force from May 2011, to create Europe-wide procedures and interfaces for journey information and ticket issuing. Fifteen years later, the Commission is again proposing through-ticketing rules because passengers still cannot buy reliable through-tickets. A binding standard did not produce a market, and this plan repeats the approach with a bigger budget.
- The Commission presented its multimodal-booking and rail-ticketing proposals on 13 May 2026, so they are not adopted law. The Community of European Railway and Infrastructure Companies (CER) publicly warned that they could raise ticket prices, weaken operators and strengthen large digital platforms. The plan's main stakeholder opposes its premise.
- The draft would require operators holding at least 50% of a national rail market to show competing domestic services on their websites and sell those tickets on request. This is a forced-neutrality design: the dominant party must advertise its rivals. History across regulated industries suggests incumbents then comply formally and compete on defaults, fare buckets and friction.
- Rail IT interoperability projects in the TAP/TAF era were reported to face costly changes and strict deployment-plan coordination across infrastructure managers and railway undertakings. A plan to coordinate 25+ operators plus buses, ferries and airlines in 60 months has no direct precedent at this scope (exact project cost overruns not verified).



### Premise Attack 5 — Escalation
_Narrative of worsening failure from cracks → amplification → reckoning._

**[STRATEGIC] — Single-Ticket Mirage: The plan treats a fragmented, sovereign, incumbent-controlled rail market as a software-integration problem, then promises a 40% through-ticket share and a shift from air to rail that no booking layer, public reference distributor or €1.5 billion coordination fund can deliver, because the binding constraints are scarce paths, rolling stock, incompatible national liabilities and carriers' commercial incentives to withhold inventory.**

**Bottom Line:** REJECT: This is a booking-convenience reform presented as a modal-shift revolution. It promises rights it cannot enforce and a mode switch it does not control, and it concentrates the sector's data and money in one state-backed chokepoint. The gate is closed.


#### Reasons for Rejection

- Rights and dignity: promising 'full rights' on a through-ticket across 20+ carriers, with persons with reduced mobility, bicycle reservations and refunds all harmonised, invites a two-tier system. Passengers who book through the favoured channel get continuity-of-journey protection, and those who split tickets or book at a station do not. The most vulnerable travellers, who need assistance handovers between carriers that have never shared a duty of care, are the ones exposed when the handover fails.
- Accountability and oversight: the plan spreads responsibility across DG MOVE, the EU Agency for Railways, CER and national operators, independent distributors and national regulators. It also creates a clearing mechanism and a state-funded reference distributor that compete with the private distributors they regulate. When a missed connection is disputed, each actor can point to another's API, tariff or regulator, and nobody owns the passenger's loss. The state is also referee and market participant at once.
- Systemic risk and scale: a shared real-time inventory layer, a single-payment clearing house and mandatory API exposure create one chokepoint for pricing, availability and money across the continent. An outage, a settlement dispute or a cyberattack would cascade from a local failure into a continent-wide inability to sell or refund tickets. A fixed 18/30/60-month calendar also forces standards to be frozen before the underlying legislation is settled.
- Value-proposition rot: the headline outcomes are hubris dressed as metrics. 'More attractive than flying' depends on journey time, frequency, track access fees, night-train and rolling-stock supply, and cross-border path capacity, none of which a booking regulation changes. A 40% through-ticket share can be hit by relabelling bundled sales, while the 'fewer people choose the plane' claim stays unproven. The scheme sells a booking-convenience fix as a modal-shift programme.

#### Second-Order Effects

- T+0–6 months — The Cracks Appear: Carriers contest what 'non-discriminatory terms' means, and the first conformance tests expose that OSDM-compatible does not mean interoperable in practice. The lead corridors miss their first milestones. Officials then redefine 'through-ticket' to count bundled or partner sales so the headline metric can be reported as on track.
- T+1–3 years — Copycats Arrive: Neighbouring modes and non-participating states demand equivalent mandates, and a patchwork of national add-on rules spreads. Incumbents respond by gating their best fares and inventory behind their own apps or direct channels, leaving distributors with the allocations the incumbents do not want. The public reference distributor, meant as a neutral baseline, becomes the default for politically supported routes and crowds out independent distributors.
- T+5–10 years — Norms Degrade: 'Compliant' becomes a box-ticking certificate rather than a service guarantee. Refund and disruption backstops become the clearing house's loss centre, so carriers ration compensation through fine print and delays in paying out. Passengers learn that the through-ticket is a promise that fails exactly when a connection is missed. Trust in the label falls, and so does the willingness to book complex international itineraries.
- T+10+ years — The Reckoning: An audit finds that aviation's short-haul share on the target routes barely changed, because the real determinants were capacity, track charges and time. The €1.5 billion public layer and the larger private carrier IT spend are written off as a legacy platform that must be maintained. The sector is left with a politically owned monopoly-like distribution infrastructure and a settled public grievance against it.

#### Evidence

- Case/Report — The Commission's 2026 'one journey, one ticket, full rights' passenger and mobility package consists of proposed regulations on multimodal booking and rail ticketing. As of Month 0 (2026-10-08) they are proposals, not adopted law. The Commission's own impact estimate is that rail travel could rise by up to 5% (not verified in detail), far below a transformation of air-rail modal share. The plan's 18/30/60-month binding calendar presumes adoption and content that do not yet exist.
- Case/Report — OSDM, the UIC and industry Open Sales and Distribution Model, went live in 2021, and about 22 rail companies, aggregators and retailers had reportedly adopted it by 2024. Years after adoption, the plan itself concedes that passengers still cannot reliably buy a Lisbon–Tallinn through-ticket. The bottleneck is commercial willingness and fare-and-liability harmonisation, not the absence of a standard, so a further layer of the same standard cannot cure it.
- Law/Standard — Regulation (EU) 2021/782 on rail passengers' rights and obligations already provides through-ticket protections, and it has been criticised for exceptions and uneven enforcement across member states (not verified in detail). A new overlay on top of an existing, weakly enforced regime adds a second set of rules with unclear precedence rather than resolving the first.
- Principle/Analogue — Industrial Organisation (platform economics): when a public body runs a reference distributor in a market where it also sets access rules, private distributors face an incentive to depend on the public channel and a risk of regulatory capture. Non-discriminatory access then becomes something carriers game, not something they observe.