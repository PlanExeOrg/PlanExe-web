### Premise Attack 1 — Integrity
_Forensic audit of foundational soundness across axes._

**[STRATEGIC] The program spends €1.5 billion of public money to build a booking-and-clearing layer on the assumption that fragmented ticketing is what keeps travellers off cross-border trains and in planes, when timetables, capacity, track access and fares decide that, and the layer pre-empts a regulation that is still only a proposal.**

**Bottom Line:** REJECT: The premise treats a ticket-packaging problem as the cause of low cross-border rail use, front-runs an unenacted regulation, and promises a modal shift that booking infrastructure cannot deliver.


#### Reasons for Rejection

- Binding standards at Month 18 (2028-04-12) and mandatory API exposure at Month 30 (2029-04-12) presuppose an enacted regulation, yet the Commission's rail ticketing proposal is still before Parliament and Council, so an ASAP start commits public money to obligations that have no legal basis and may be rewritten or diluted.
- The 40% target counts cross-border journeys sold as a single through-ticket, which measures how tickets are packaged, not whether anyone travels more; a distributor that bundles two existing fares into one invoice hits the metric without adding a seat or a train.
- The goal that the train becomes more attractive than flying on competitive short-haul routes cannot be reached with ticketing software, because journey time, price, rolling-stock availability and track capacity on Paris–Brussels–Amsterdam–Köln or Madrid–Barcelona–Lyon are unaffected by a €1.5 billion data and settlement layer, so every deliverable could ship on time and the headline outcome still fail.
- A public reference distributor funded by the programme competes directly with Trainline and Omio, the independents the plan claims to serve on non-discriminatory terms, and it is built by a coordination body that also writes the standards those rivals must comply with.
- The €1.5 billion covers only coordination, standards, testing, clearing and consumer rollout, while the larger carrier IT bill across SNCF, Deutsche Bahn, Trenitalia, Renfe, ÖBB, NS, SJ and about twenty more is left unpriced, so the programme depends on the very incumbents it is trying to open up to fund and accept the changes.

#### Second-Order Effects

- 0–6 months: Carriers and national regulators hold back commitments until the legislative text settles, while standards-body and conformance-testing contracts are awarded against a specification that may change.
- 1–3 years: Incumbents deliver minimal OSDM-compatible API exposure on the four launch corridors to meet the Month 30 (2029-04-12) deadline; independent distributors get access to inventory but not to the best fares, and complaint volumes shift from 'cannot book' to 'cannot get the through-ticket price'.
- 5–10 years: A publicly funded clearing mechanism and reference distributor become permanent infrastructure whose upkeep competes with track and rolling-stock budgets, while short-haul flight volumes on the target routes move little and the programme is judged on ticket share alone.

#### Evidence

- Law/Standard — Commission Regulation (EU) No 1305/2014, TAP TSI (2014): a binding EU technical standard for rail passenger information and booking data exchange has existed for over a decade, yet booking systems remain fragmented per operator, so mandating data layers has not by itself produced through-ticketing.
- Law/Standard — Regulation (EU) 2021/782 (2021): the recast rail passenger-rights regulation already defines through-tickets and missed connections, so the missing protection turns on what legally counts as a through-ticket rather than on a €1.5 billion technical layer.
- Law/Standard — French Climate and Resilience Law (2021): France restricted domestic short-haul flights where a rail alternative exists, showing that modal shift from air has been pursued through route-level regulation rather than booking tools.



### Premise Attack 2 — Accountability
_Rights, oversight, jurisdiction-shopping, enforceability._

**[STRATEGIC] — The Ticket-Without-a-Train Fallacy: the plan spends €1.5 billion (user constraint) perfecting how seats are sold across two dozen-plus carriers while the scarce thing is the train itself, so a 'train beats plane' outcome cannot follow from a better checkout.**

**Bottom Line:** REJECT: The Ticket-Without-a-Train Fallacy is fatal: selling through-tickets more smoothly does not create trains, paths or seats, so the plan cannot deliver the modal shift it is justified by. A public machine of clearing, standards and apps is built to optimise a sales channel, not to get anyone out of an aircraft.


#### Reasons for Rejection

- Pooling real-time inventory, accessibility-assistance needs, bicycle reservations and single-payment data across more than two dozen national operators and third-party platforms puts travellers' health-related and movement data into a shared layer they never chose and cannot practically opt out of.
- A clearing mechanism, a public reference distributor that competes with Trainline and Omio while its own rules are being written, and a split of duties among DG MOVE, the EU Agency for Railways and national regulators leaves no single party answerable when a missed connection is disputed, and invites carriers to push disputes toward the most lenient regulator.
- A mandatory Europe-wide inventory and settlement layer becomes one failure and attack point for ticket sales across the continent, and once carriers retire their parallel channels and align fare and refund rules to it, it cannot be unwound; other regions would copy the model.
- The success metric (40% of cross-border journeys sold as through-tickets, a user constraint) measures the sales channel rather than whether anyone left the plane, and the money funds apps, multilingual support and complaint handling rather than the timetables, rolling stock and track capacity that decide whether rail wins on short-haul routes.

#### Second-Order Effects

- **Months 0–18 (2026-10-12 to 2028-04-12) — The Standards Swamp:** The binding-standards deadline arrives before the underlying legislation is settled, so carriers, platforms and national regulators spend the window lobbying over fee and data-access terms rather than building.
- **Months 18–36 (2028-04-12 to 2029-10-12) — The Hollow Metric:** Through-ticket share rises on paper because carriers re-label existing multi-leg sales, while seats on the busiest corridors stay full and the extra demand has nowhere to go.
- **Months 36–60 (2029-10-12 to 2031-10-12) — The Toll Booth Forms:** The dominant distributors become unavoidable intermediaries and collect distribution fees that flow into fares, while smaller carriers carry compliance costs they cannot recover.
- **Months 60–120 (2031-10-12 to 2036-10-12) — The Reckoning:** The program is judged on flights not displaced and fares not lowered, and Europe is left with an expensive shared system that is hard to dismantle and a promise of continuous journeys that carriers cannot physically deliver.

#### Evidence

- Law/Standard — Regulation (EU) 2021/782 on rail passengers' rights and obligations, in application since 2023, already contains through-ticket provisions; the problem is that they are narrow in scope and miss many single-platform bookings, not that Europe lacks a booking law.
- Law/Standard — GDPR Art. 9 (special categories of personal data, including health data): accessibility-assistance requests for persons with reduced mobility, pooled across dozens of carriers and distributors, fall squarely within it.
- Case/Report — The Community of European Railway and Infrastructure Companies (CER) and rail trade press have warned that the Commission's 2026 ticketing proposal, by compelling distribution agreements, could strengthen large platforms and push up distribution fees and ticket prices (as reported; details not verified).
- Case/Report — The rail-industry-built OSDM standard has already been associated with a sharp rise in international digital rail ticket sales without a €1.5 billion public machine (growth figures not verified).



### Premise Attack 3 — Spectrum
_Enforced breadth: distinct reasons across ethical/feasibility/governance/societal axes._

**[STRATEGIC] A €1.5 billion booking-layer mandate treats a shortage of capacity, affordable fares and rolling stock as an interface problem, so it will perfect the checkout while trains stay scarce, expensive and late.**

**Bottom Line:** REJECT: Europe's cross-border rail problem is scarce capacity and fares, not a missing booking interface, and a €1.5 billion mandate aimed at the interface will enrich platforms, saddle carriers with open-ended liability and leave the planes full.


#### Reasons for Rejection

- Causality: the program's headline success claim, that the train beats the plane on competitive short-haul routes, depends on fares, seat supply, journey time and punctuality, none of which a shared real-time data layer or OSDM-compatible APIs can change.
- Governance: binding standards by Month 18 (2028-04-12) and mandatory API exposure by Month 30 (2029-04-12) presuppose a Regulation that was only proposed in 2026 and still has to survive Parliament and Council, so the program would start building to a legal text that does not yet exist and can still be rewritten.
- Incentives: forcing SNCF, Deutsche Bahn, Trenitalia, Renfe, ÖBB, NS, SJ and roughly twenty more carriers to expose inventory on non-discriminatory terms hands the sales margin and customer relationship to the largest platforms such as Trainline and Omio, while the carriers keep the cost of running the trains.
- Liability and budget: a passenger-rights backstop for missed connections across every participating carrier and every compliant distributor creates open-ended claims that a €1.5 billion envelope, already earmarked for standards, conformance testing, clearing, a public distributor, capacity building and apps, cannot cap.
- Privacy: single-payment through-ticketing with accessibility assistance for persons with reduced mobility and bicycle reservations pushes health-related and travel-pattern data into a shared layer reachable by twenty-plus carriers and any compliant distributor, multiplying breach and misuse exposure for a convenience gain.

#### Second-Order Effects

- 0–6 months: With no adopted legal text at Month 0 (2026-10-12), standards working groups spend the opening months arguing over fee terms, API scope and liability allocation, and every amendment in Council or Parliament reopens specifications already drafted.
- 1–3 years: When mandatory API exposure arrives around Month 30 (2029-04-12), the biggest platforms capture the cross-border sales flow, carriers raise distribution fees or fares to recover the loss, the public reference distributor becomes a subsidised competitor with thin volume, and complaints rise as more through-tickets create more disputes at the seams between carriers.
- 5–10 years: By Month 60 (2031-10-12) the clearing mechanism and the passenger-rights backstop are entrenched as a permanent shared liability pool no member state can unwind, through-ticket share sits well short of 40% (estimate) because corridor seats and track-access charges are unchanged, and short-haul air traffic on competitive routes is largely where it started.

#### Evidence

- Law/Standard — Regulation (EU) 2021/782 on rail passengers' rights and obligations (2021): already imposes through-ticket and missed-connection duties, yet commentary notes these obligations remain limited in scope, showing that mandating through-ticketing on paper does not produce it in practice.
- Report/Guidance — CER press release on the Commission's Passenger Package proposal (2026): the rail sector's own trade body reacted to the proposed single digital booking and ticketing regulation, and trade-press coverage reports concerns about platform market power and higher distribution fees (detail of the release not verified).
- Report/Guidance — European Court of Auditors Special Report 19/2018 on the EU high-speed rail network (2018): found EU-level rail coordination had produced an ineffective patchwork rather than a coherent cross-border network (not verified by search).



### Premise Attack 4 — Cascade
_Tracks second/third-order effects and copycat propagation._

**The plan treats a retail-layer problem (search, booking, refund) as the cause of a capacity, pricing and incentive problem, and sets 18-month and 30-month binding deadlines against a regulation that is still only a May 2026 Commission proposal. A €1.5 billion (user constraint) public budget cannot buy compliance from carriers who own the inventory, bear the liability and have every reason to keep distributors at arm's length, and the headline success metrics (40% through-ticketing, modal shift from air) are not controllable by the instruments the programme actually has.**

**Bottom Line:** Abandon this premise: it mistakes a distribution-layer fix for a rail-capacity and incentive problem and attaches binding deadlines and modal-shift targets to a law that does not yet exist. The failure is built into the goal itself, since no ticketing standard, however well funded, can make carriers sell inventory they would rather keep or make trains more attractive than planes.


#### Reasons for Rejection

- The Legislative Quicksand Foundation: the programme starts 'ASAP' (Month 0 = 2026-10-12) and commits to binding standards by Month 18 (2028-04-12) and mandatory API exposure by Month 30 (2029-04-12), yet the underlying Regulation is a proposal (May 2026) that still has to pass Parliament and Council, with delegated and implementing acts to follow. Any standards work done before the legal text settles risks being rewritten, and a 'mandatory' date cannot precede the mandate. Carriers will rationally wait for the final text before spending anything.
- The Ticket-Is-Not-The-Train Fallacy: through-ticketing fixes the purchase, not the journey. Lisbon-Tallinn is not constrained by checkout friction but by missing track capacity, incompatible signalling and gauge, unsynchronised timetables, scarce rolling stock and fares that are higher than low-cost air. A beautifully unified booking flow selling seats that do not exist, at connections that do not work, raises the number of failed sales rather than the number of train journeys.
- The Clearing-House Hostage Trap: the inter-carrier settlement and passenger-rights backstop makes the programme the de facto insurer of missed connections across ~25 carriers with different liability rules, fare structures and national regulators. Every carrier's incentive is to minimise inventory offered and keep its own channel privileged (the 'non-discriminatory terms' are policed by 27 national regulators with uneven capacity). The first large disrupted-journey dispute exposes who actually pays, and nobody has agreed in advance.
- The Forty-Percent Denominator Mirage: '40% of cross-border journeys sold as single through-tickets' has no defined baseline. Most cross-border rail trips are short regional hops that are already one ticket or are bought as day-passes, while the long-haul multi-carrier journeys the programme is designed for are a tiny volume. The metric can be hit by redefinition or missed despite real improvement, so it cannot discipline the programme and invites statistical gaming.
- The Flight-Substitution Attribution Fantasy: 'train more attractive than flying, so fewer choose the plane' is a macro outcome driven by ticket prices, aviation taxation, journey time, night-train capacity and airline route economics. A booking-layer programme has no lever on any of these, and a five-year horizon is shorter than the delivery time for new rolling stock and cross-border infrastructure. Success will be claimed or denied on factors outside the programme's control.

#### Second-Order Effects

- Within Months 0-6 (2026-10-12 to 2027-04-12): the programme stands up governance (DG MOVE, ERA, CER, regulators, BEUC) before the legal text is final; scope fights over who owns the clearing mechanism and the public reference distributor consume the first year, and incumbent operators and platforms such as Trainline and Omio lobby for opposite fee and data-access terms.
- Months 6-18 (2027-04-12 to 2028-04-12): standards drafting proceeds against a moving legislative target and against existing OSDM, TAP TSI and national APIs; competing versions fragment conformance testing. The Month 18 (2028-04-12) 'binding standards' milestone is met only by narrowing to a minimum common profile that excludes bicycles, PRM assistance and reduction cards, which are the features sold to the public.
- Months 18-36 (2028-04-12 to 2029-10-12): carriers meet the Month 30 (2029-04-12) API-exposure date with technically compliant but commercially throttled interfaces (rate limits, delayed inventory, partial fare classes). Distributor complaints do not halve; they shift from 'no access' to 'access without usable inventory', and the private IT bill (estimate: a multiple of the €1.5 billion public envelope, not verified) is borne by carriers that then demand compensation.
- Months 36-60 (2029-10-12 to 2031-10-12): the first corridors go live with through-tickets that work in normal operations but fail under disruption; liability disputes over the settlement and backstop mechanism reach national regulators and courts, and consumer trust, which is the stated objective, is damaged more than by the status quo. Reported through-ticket share is contested because of the baseline problem.
- Months 60-120 (2031-10-12 to 2036-10-12): the public reference distributor is either a loss-making duplicate of existing platforms or crowds out independent distributors it was meant to level the field with. Air short-haul volumes on competitive routes move little, because prices and capacity were unchanged, and the programme is judged a €1.5 billion (user constraint) IT standards exercise that did not deliver the modal shift it promised.

#### Evidence

- The Commission's own May 2026 proposals (multimodal booking and rail ticketing) acknowledge that multimodal options exist on 76% of representative EU routes but are rarely shown or combined by platforms: the problem is distributor and carrier behaviour, not an absence of technology, which a standards programme alone does not change (Council document ST-9313-2026; Legislative Observatory summary).
- The TAP TSI (Commission Regulation (EU) No 454/2011, in force since May 2011) already mandated common telematics for passenger information and ticketing; fifteen years later cross-border through-ticketing is still described as unsolved, which is direct evidence that technical standards without carrier commercial incentives do not produce integrated sales.
- OSDM, the industry's own standard, had 22 railway undertakings signed up, but only six (SNCF, SBB/CFF, Deutsche Bahn, ÖBB, Trenitalia, PKP) applying it by the end of 2024, with others from 2025 (per CER/UIC releases and trade coverage); even a voluntary, carrier-led standard has moved gradually, so a 30-month mandatory deadline across all TEN-T carriers is aggressive even for the 'realistic' scenario.
- Commission Delegated Regulation (EU) 2017/1926 on EU-wide multimodal travel information services (MMTIS) required national access points for travel data but did not produce seamless multimodal booking; this is the nearest precedent for the proposed mandate and it is cited here from memory (not verified).



### Premise Attack 5 — Escalation
_Narrative of worsening failure from cracks → amplification → reckoning._

**[STRATEGIC] — The Checkout Fallacy: The program treats a fragmented booking screen as the reason travellers fly, then spends €1.5 billion (user constraint) polishing the screen while leaving the tracks, timetables, fares and carrier incentives that actually decide the journey untouched.**

**Bottom Line:** REJECT: A €1.5 billion ticketing superstructure sold as aviation substitution is a category error that will deliver paperwork, not modal shift, and concentrates risk and unaccountable power in exchange for a metric it can game. The gate is closed.


#### Reasons for Rejection

- Rights and dignity: A single digital ticket with a 'backstop' promises a stranded passenger, a wheelchair user or a cyclist protection across some twenty-plus carriers (user constraint), yet the assistance, boarding ramps, bicycle spaces and re-routing are delivered by staff and rolling stock the program does not control, so the promise is a screen-deep guarantee that fails exactly when a person is stuck at a platform at night.
- Accountability and oversight: Authority is split among DG MOVE, the EU Agency for Railways, CER, national operators, national regulators and a publicly funded reference distributor that is simultaneously rule-maker, competitor and clearing participant, so when a through-ticket fails there is no single party that owns the harm and every party can point to another's standard.
- Systemic risk and scale: A shared real-time inventory layer plus an inter-carrier clearing mechanism concentrates every carrier's availability, pricing and settlement flows into one mandated chokepoint, creating a single cyber and outage target and a competition-law hazard in the form of pooled commercially sensitive data among rivals.
- Value-proposition rot: The headline success claim, that trains become more attractive than planes and fewer people fly, is smuggled in as an outcome of ticketing, whereas the measurable target (40% of cross-border journeys sold as through-tickets, user constraint) is a product metric that can be met by relabelling bundles while door-to-door time, price and frequency, which drive mode choice, remain exactly as they were.

#### Second-Order Effects

- T+0–6 months (Months 0-6 = 2026-10-12 to 2027-04-12) — The Cracks Appear: Work starts 'ASAP' while the Regulation is still a Commission proposal, so budget, working groups and conformance vendors are committed before the legal text, definitions and liability rules are settled, and the first months are spent arguing over whose interpretation of 'through-ticket' binds.
- T+1–3 years (Months 12-36 = 2027-10-12 to 2029-10-12) — Copycats Arrive: Carriers expose APIs at minimum compliance, with throttled, delayed or fare-restricted inventory while the best fares stay on their own channels, independent distributors litigate over 'non-discriminatory' terms, and the corridor-first rollout sorts Europe into a ticketed core and an unserved periphery that copies the same workaround.
- T+5–10 years (Months 60-120 = 2031-10-12 to 2036-10-12) — Norms Degrade: Through-ticket share and complaint counts are managed by redefining what is counted, carriers price missed-connection liability into fares and lengthen scheduled transfer buffers so journeys get slower, and the clearing fee becomes an opaque levy that nobody can audit or exit.
- T+10+ years (Months 120+) — The Reckoning: Europe owns an expensive, brittle clearing apparatus and a public distributor that crowds out private ones, flights on competitive short-haul routes are essentially unchanged, auditors document a modal-shift goal that was never connected to its instrument, and public trust in rail-first policy is spent.

#### Evidence

- Law/Standard — Regulation (EU) 2021/782 on rail passengers' rights (in application since 2023): its through-ticket definition leaves many single-transaction multi-operator purchases without missed-connection protection, and a 2026 Commission proposal (COM(2026) 233) already moves to close that gap, so the program's 'backstop' duplicates or collides with a legal text still in motion.
- Case/Report — European Court of Auditors Special Report 13/2017 on ERTMS deployment: found a European rail IT harmonisation effort fragmented by national interests and slow delivery (report figures not verified), the same pattern that awaits a mandated multi-carrier IT layer.
- Case/Report — France's restriction on domestic short-haul flights where a rail alternative exists (climate law of 2021, applied from 2023): the instrument that actually targeted flying acted on route supply and legal permission, not on booking convenience, and covered only a handful of routes (route count not verified).
- Principle/Analogue — Transport Economics: mode choice follows generalised cost (door-to-door time, fare, frequency, reliability); booking friction is a small component, so improving it cannot by itself outcompete a cheap, fast flight.