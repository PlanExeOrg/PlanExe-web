## 1. Regulatory Adoption Status and Legislative Text Alignment

The programme's entire timeline and governance model depend on the Commission Regulation being adopted by Month 9 (2027-07-08) and defining non-discriminatory access, settlement, and passenger-rights obligations. If adoption slips beyond Month 10 (2027-08-08) or the final text diverges materially (e.g., stricter liability, narrower data-sharing scope, or mandatory API exemptions), the Month 18 (2028-04-08) binding standards deadline and the Month 30 (2029-04-08) API mandate are at risk of 6–12 month delays. Early tracking and shadow standards pre-work reduce re-work downstream and enable accelerated standards finalisation if adoption is delayed.

### Data to Collect

- Final adopted text of the Commission's proposed Regulation on Digital Booking and Ticketing Services for Rail (expected adoption Month 6–12 = 2027-04-08 to 2027-10-08)
- Parliamentary amendments (TRAN, IMCO committees) and member-state negotiating positions on liability, data-sharing scope, mandatory API timelines, and non-discriminatory access definitions
- Gaps between the final Regulation text and OSDM v2.1 specification, access-term templates, settlement message standards, and passenger-rights protocols
- Timeline confirmation for Council delegation of binding technical authority to the arbitration panel (target Month 1.5 = 2026-11-23)

### Simulation Steps

- Track weekly Parliament TRAN and IMCO rapporteur briefings (Months 0–9 = 2026-10-08 to 2027-07-08) using public Parliament legislative tracking (Europarl.europa.eu legislative observatory)
- Monitor member-state positions via Council Presidency summaries and official transport minister statements (EUR-Lex, Council website, bilateral liaison with Germany, France, Belgium, Austria, Spain transport ministers)
- Conduct gap analysis: compare Commission's May 2026 proposed text against OSDM v2.1 (UIC specification) and draft candidate standards on access-term templates, settlement formats, and passenger-rights rules using a shadow standards pre-work team (5–8 FTE)
- Model three adoption scenarios (Month 9 = 2027-07-08, Month 11–12 = 2027-09-08 to 2027-10-08 with text changes, blocked past Month 12 = 2027-10-08) with pre-drafted standards language for contested areas so accelerated standards-setting can begin immediately post-adoption

### Expert Validation Steps

- Engage DG MOVE, Commission legal services and EU Agency for Railways to confirm the Council delegation pathway and legal feasibility of binding the arbitration panel by Month 2 (2026-12-08)
- Consult the European Parliament's TRAN and IMCO rapporteurs monthly (Months 0–9 = 2026-10-08 to 2027-07-08) to obtain early-warning signalling of blocking amendments or adoption delays
- Present draft standards (from shadow pre-work) to a UIC OSDM working-group representative and to a carrier technology advisory panel (CER-nominated) by Month 6 (2027-04-08) to validate technical feasibility and carrier buy-in
- Secure written confirmation from the Commission and Council that the final Regulation text aligns with the programme's OSDM and access-term assumptions by Month 9 (2027-07-08); if material divergence is identified, trigger re-baseline decision by Month 12 (2027-10-08)

### Responsible Parties

- DG MOVE (programme owner; regulatory liaison with Parliament and member states)
- EU Agency for Railways (technical secretariat; OSDM gap analysis)
- Shadow standards pre-work team (5–8 FTE; OSDM specialist, legal counsel, carrier IT representative) hired by Month 0 (2026-10-08)
- CER (carrier federation; transportation of carrier feedback on standards feasibility)

### Assumptions

- **High:** The Commission's proposed Regulation will be adopted by Parliament and Council by Month 9 (2027-07-08) with only minor text divergence from the May 2026 proposal (sensitivity: high). If adoption slips to Month 11–12 (2027-09-08 to 2027-10-08) or the text diverges materially on liability or data-sharing scope, the standards-setting window compresses from 9 months to 3–4 months, forcing either non-consensus or rushed standards.
- **High:** The Council will grant written delegation of binding technical-decision authority to the arbitration panel by Month 2 (2026-12-08) (sensitivity: high). This is a political decision not yet confirmed; delays in Council adoption will compress the carrier-commitment timeline and risk incumbent non-compliance.
- **Medium:** OSDM v2.1 specification will remain stable and compatible with the proposed Regulation's mandatory API scope (sensitivity: medium). If UIC releases OSDM v3.0 with material changes during Months 0–12 (2026-10-08 to 2027-10-08), standards work must be re-scoped.
- **Medium:** DG MOVE and the Commission will publicly signal support for the programme and the arbitration panel's authority by Month 1 (2026-11-08) (sensitivity: medium). Political wavering or ambiguity undermines carrier buy-in for Commitment Letters.
- **Low:** CER member carriers will provide honest feedback on standards feasibility and IT integration timelines during gap analysis (Months 2–4 = 2026-12-08 to 2027-02-08) (sensitivity: low). Carriers may downplay readiness to extract co-funding or demand exemptions.

### SMART Validation Objective

By Month 6 (2027-04-08), confirm that (1) Parliament and Council adoption is on track for Month 9 (2027-07-08) or identify a specific blocking issue and revised target; (2) shadow standards pre-work has completed gap analysis against OSDM v2.1 and drafted candidate access-term and settlement standards for at least two contested areas (inventory parity, refund processing timelines); (3) at least 4 of 8 major carriers (estimated) have reviewed draft standards and signalled technical feasibility for Month 30 (2029-04-08) API exposure. If any condition is not met, escalate to Steering Committee by Month 7 (2027-05-08) for re-baseline decision.

### Notes

- Regulation adoption is the critical upstream gate; every month of delay compresses the standards window (baseline 9 months, floor 3–4 months) and threatens Month 18 (2028-04-08) binding standards deadline.
- Shadow standards pre-work (5–8 FTE from Month 0 = 2026-10-08) is essential to enable rapid post-adoption finalisation; without pre-work, standards finalisation would require 9–12 months and miss Month 18 (2028-04-08).
- Council delegation is a political/legal prerequisite; absence of written authority undermines arbitration panel credibility and carrier Commitment Letters. Secure delegation target Month 2 (2026-12-08), target Month 1.5 (2026-11-23).
- Material text divergence from the Commission proposal (especially on liability, data-sharing scope, or API exemptions) would require standards re-work; establish re-baseline gate by Month 7 (2027-05-08) if adoption text diverges significantly.
- Contingency acceleration pathway: if adoption slips past Month 8 (2027-06-08), contract external standards consortium by Month 8.5 (2027-06-23) for 4–6 week compressed standards finalisation (EUR 1–2M cost from EUR 10M governance line budget).


## 2. Carrier Commitment and Incumbent Acceptance of Arbitration Panel Authority

Carrier commitment is the foundation of the arbitration panel's authority and the Month 30 (2029-04-08) API mandate. Without binding Commitment Letters signed by major incumbents (SNCF, Deutsche Bahn, ÖBB) by Month 3 (2027-01-08), the panel is advisory and carries no enforcement power. Large carriers can delay or contest technical rulings, fragmenting the network and missing the critical-path milestones. Incumbent non-compliance by any of the top 5 carriers would reduce through-ticket coverage to below 70% of potential corridors, undermining the 40% share target.

### Data to Collect

- Written Commitment Letters from all carriers with annual cross-border revenue above EUR 50 million, signed by Month 3 (2027-01-08), accepting arbitration panel authority, 14-day compliance deadlines, and penalties (0.5–1% of quarterly through-ticket revenue in escrow for non-compliance)
- Individual carrier IT readiness assessments: estimated integration cost (native API vs. hub), timeline to Month 30 (2029-04-08) API exposure, and private IT investment budget per carrier
- Incumbent carrier political positioning and signalling of non-compliance risk (Deutsche Bahn, SNCF, ÖBB, Renfe, Trenitalia, ÖBB) from bilateral executive negotiation (Months 0–3 = 2026-10-08 to 2027-01-08)
- Smaller carriers' eligibility for hub integration (cross-border revenue under EUR 50M, booking system older than 10 years, or IT staff under 10 FTE) and their co-funding requests

### Simulation Steps

- Model carrier-by-carrier IT integration cost using baseline scenarios: native OSDM API implementation (EUR 10–20M per major carrier, EUR 2–8M per SME), hub integration (EUR 2–5M per carrier), or regional hub use without IT investment. Sensitivity: cost variance ±30% depending on legacy-system age and in-house IT capacity.
- Conduct bilateral executive engagement with SNCF, Deutsche Bahn, ÖBB, Renfe, Trenitalia and NS leadership (Months 0–2 = 2026-10-08 to 2026-12-08.5 = 2026-10-08 to 2026-12-23) to present the arbitration panel framework, escrow penalties, and co-funding offers. Record each carrier's stated compliance commitment and any preconditions (e.g. delay, API scope exemptions, co-funding rate).
- Use CER quarterly roundtables (December 2026, February 2027, April 2027) to publicly present Commitment Letter terms and facilitate signature-gathering; measure attendance and signatory intent as a proxy for coalition strength.
- Model the consequence of non-compliance by any of the top 5 carriers (SNCF, DB, Trenitalia, Renfe, ÖBB) on corridor coverage: estimate what percentage of cross-border traffic remains bookable end-to-end if one major carrier refuses API exposure (estimate: 60–75% if incumbent excludes one corridor).

### Expert Validation Steps

- Have the arbitration panel secretariat and DG MOVE legal counsel review final Commitment Letter language by Month 1 (2026-11-08) to confirm enforceability of penalties under EU law and national insolvency/contract law.
- Engage CER's legal and policy lead to validate that the proposed carrier commitment terms are realistic and enforceable under CER member-company bylaws and carrier regulatory frameworks.
- Present the arbitration panel delegation document to three major carrier CIOs (representative sample from SNCF, DB, ÖBB) by Month 1.5 (2026-11-23) to assess technical and institutional feasibility of the panel's authority; flag any legal or operational blocker for escalation to DG MOVE.
- Validate incumbent non-compliance signalling by Month 3 (2027-01-08): if any carrier above EUR 100M revenue has not signed the Commitment Letter, escalate to DG MOVE and the Commission for enforcement action (threaten EU funding suspension or antitrust investigation) by Month 4 (2027-02-08).

### Responsible Parties

- DG MOVE (programme owner; responsible for political negotiation with member states and incumbent carriers, and for escalation to Commission if carriers refuse commitment)
- Carrier Engagement Manager / Coalition Builder (designated by Month 1 = 2026-11-08; leads bilateral negotiations with SNCF, DB, ÖBB, Renfe, Trenitalia, NS, SJ, SNCB)
- CER (facilitates public roundtables and coordinates smaller-carrier and association input)
- Arbitration panel secretariat (validates legal enforceability of panel authority and penalties by Month 1.5 = 2026-11-23)

### Assumptions

- **High:** All carriers above EUR 50M annual cross-border revenue will sign binding Commitment Letters by Month 3 (2027-01-08) accepting arbitration panel authority and penalties (sensitivity: high). If a major incumbent (SNCF, DB, ÖBB) refuses, the panel becomes advisory and large carriers can delay or contest rulings indefinitely.
- **High:** Incumbent carriers' estimated IT integration cost (native API EUR 10–20M per major, EUR 2–8M per SME) is accurate and carriers' private IT budgets are sufficient to fund integration without requesting 100% public co-funding (sensitivity: high). If carriers demand greater than 30% co-funding for native builds, the EUR 290M co-funding allocation will be exhausted and trigger Tier 2–3 contingency cuts.
- **Medium:** Smaller carriers (12–18 estimated) meeting hub-eligibility criteria (revenue <EUR 50M, legacy system >10 years, or IT staff <10 FTE) will choose hub integration over native API build, reducing their co-funding demand (sensitivity: medium). If more carriers demand full co-funding for native APIs, co-funding budget shortfall occurs.
- **Medium:** The Commission will take enforcement action (EU funding suspension, antitrust investigation) against any major carrier that refuses the Commitment Letter by Month 4 (2027-02-08), signalling credible consequences for non-compliance (sensitivity: medium). Political reluctance to enforce against domestic 'champion' carriers could weaken this signal.
- **Low:** CER will cooperate in facilitating public roundtables and carrier signature-gathering (sensitivity: low). CER is institutionally committed to cross-border interoperability but is also accountable to incumbent members; it may seek to water down enforcement terms.

### SMART Validation Objective

By Month 3 (2027-01-08), confirm that (1) at least 95% of carriers above EUR 50M revenue (estimated ~20 carriers) have signed binding Commitment Letters accepting arbitration authority and penalties; (2) all eight major carriers (SNCF, DB, Trenitalia, Renfe, ÖBB, NS, SJ, SNCB) have signed; (3) each carrier has provided an estimated IT integration cost, timeline and private investment commitment; (4) at least 10 of 12–18 hub-eligible smaller carriers have confirmed hub-integration preference or native-API co-funding request. If <95% have signed or any major incumbent refuses, escalate to DG MOVE by Month 4 (2027-02-08) for Commission enforcement action and re-baseline decision (pause programme if enforcement is not credible).

### Notes

- Incumbent resistance is the highest-risk factor for the arbitration panel's credibility; secure Commitment Letters before Month 3 (2027-01-08) is a critical gate.
- Bilateral negotiation with SNCF, DB, ÖBB and other large carriers (Months 0–2 = 2026-10-08 to 2026-12-08.5 = 2026-10-08 to 2026-12-23) must be personally conducted by the Carrier Engagement Manager and the Programme Director; phone calls and formal letters are insufficient.
- Non-compliance by a single major carrier on one corridor (e.g., DB refusing to expose inventory data on the Paris–Brussels–Amsterdam–Köln route) fragments the through-ticket network and undermines the Month 30 (2029-04-08) mandate; escalate and enforce immediately.
- Smaller carriers' co-funding requests should be capped at EUR 2–8M per carrier (hub integration) or EUR 10–15M (native API); any request above this range should trigger cost-justification review by Month 2 (2026-12-08).
- If cumulative carrier co-funding requests exceed EUR 350M by Month 3 (2027-01-08) (vs. EUR 290M budget), trigger Tier 2 contingency (reduce co-funding rate to 10%, limit hubs to priority corridors) by Month 6 (2027-04-08).


## 3. Hub Procurement, Operationalization and Carrier Integration Readiness

Regional hubs are the mechanism for enabling 12–18 smaller legacy-system carriers to meet the Month 30 (2029-04-08) API mandate without expensive native integration (estimated EUR 10–20M per carrier). Hub readiness is on the critical path: if hub procurement slips past Month 3 (2027-01-08) or hubs are not operational by Month 9 (2027-07-08), integration window for carriers is compressed to 6–9 months, reducing Month 30 (2029-04-08) readiness from ~85% to ~60–70% and fragmenting the through-ticket network. Hub data-quality failures (mapping errors causing >2% booking-failure rate) undermine distributor and passenger trust and trigger refund disputes exceeding the EUR 10M passenger-rights reserve.

### Data to Collect

- Hub operator qualifications and bids (technical architecture, uptime SLAs, latency targets, capacity, disaster-recovery plans) for 4–6 regional hubs (Four priority corridors + 2 TEN-T hubs)
- Integration timelines and mapping accuracy: legacy-carrier system architecture assessment, data-format compatibility, and estimated dual-run testing duration per carrier (target 2–4 weeks)
- Hub operating costs (opex), revenue models (per-booking fees or annual subscriptions), and cost-recovery feasibility by Month 48 (2030-10-08)
- Smaller-carrier integration readiness: IT staff capacity, network latency constraints, and commitment to participate in hub integration by Month 30 (2029-04-08)

### Simulation Steps

- Issue RFP for regional hub operators by Month 0.5 (2026-10-23) specifying technical requirements (99.9% uptime, <2-second latency, <2-hour incident recovery, ≥10,000 bookings/day capacity). Request cost estimates: upfront development EUR 0.5–1M per hub, annual opex EUR 0.8–1.2M per hub, and fee revenue model (EUR 0.5–1.5 per booking or EUR 50–200K per carrier per year).
- Model hub economics: baseline opex EUR 1.2M/year vs. fee revenue EUR 0.73M/year at capacity, leaving a EUR 0.47M/year gap (EUR 1.9M/year for 4 hubs, ~EUR 9.5M over 5 years). Sensitivity: cost variance ±20% depending on carrier-concentration and booking-volume growth; revenue variance ±30% if carrier adoption is slower than planned.
- Conduct joint technical integration workshops pairing hub operators and 2–3 eligible legacy-system carriers per hub (Month 4 = 2027-02-08) to identify network latency, API compatibility and data-format mismatches. Estimate dual-run pilot duration per carrier: 2–4 weeks (baseline), 4–8 weeks if mapping errors are detected.
- Simulate hub failure scenarios: if a hub serving 6 carriers fails and recovery takes 12–48 hours (vs. target 2-hour SLA), model the operational and financial impact (estimated 10,000–50,000 daily searches affected, EUR 100–500K in cascade refunds and claims per incident).

### Expert Validation Steps

- Have an independent integration consultant assess hub operator bids for technical feasibility and SLA achievability by Month 2 (2026-12-08); flag any bid with unachievable latency (<2 seconds) or uptime (99.9%) guarantees.
- Conduct technical due diligence with 3–4 hub operator finalists (Month 3 = 2027-01-08) to validate their disaster-recovery plans, data-encryption protocols, and compliance with GDPR and payment-services regulations.
- Engage 2–3 eligible legacy-system carriers (one per region: central Europe, southeast Europe, Iberia) in pilot integration workshops (Month 4 = 2027-02-08) and validate that their network latency and API compatibility issues can be resolved within the 2–4 week dual-run window.
- Commission an independent hub-economics audit (Month 2 = 2026-12-08) to validate cost estimates and fee-revenue assumptions; flag any hub projected to have an annual loss above EUR 0.5M by Month 48 (2030-10-08), signalling cost-recovery risk.

### Responsible Parties

- Smaller Carriers and Regional Integration Lead (responsible for hub procurement RFP, contract negotiation, and pilot integration)
- Regional support coordinators (3–5 FTE, hired by Month 4 = 2027-02-08; on-site integration troubleshooting)
- Hub operator (contractor; responsible for 99.9% uptime SLA, mapping accuracy, incident response)
- Independent integration consultant (validates hub technical feasibility and smaller-carrier readiness)

### Assumptions

- **Medium:** At least 4–6 qualified hub operator bidders will respond to RFP by Month 2 (2026-12-08) with competitive pricing and credible SLA commitments (sensitivity: medium). If fewer than 3 qualified bidders respond, there is limited competitive choice and cost competition is weak.
- **High:** Hub data-mapping accuracy will be validated to below 0.5% booking-failure rate (target) and below 2% threshold for onboarding suspension by Month 18 (2028-04-08) (sensitivity: high). Legacy-system translation errors (missing seat allocations, incorrect pricing, duplicate bookings) could cause 2–5% failure rate post-launch, requiring 4–8 week rework per carrier.
- **Medium:** Hub cost-recovery is achievable by Month 48 (2030-10-08) through carrier-subscription fees (EUR 50–200K per carrier per year or per-booking fees) combined with volume growth (sensitivity: medium). If carrier adoption is slower than planned or fee-revenue models are uncompetitive, EUR 1.9M/year gap (for 4 hubs) persists, requiring extended public subsidy.
- **Medium:** Smaller carriers' network latency and API compatibility issues can be resolved within the 2–4 week dual-run pilot window (sensitivity: medium). Carriers with extremely constrained network connectivity (e.g., regional operators in southeast Europe with limited bandwidth) may require 4–8 week pilots or custom network solutions, delaying integration.
- **Medium:** Hub operators will maintain 99.9% uptime SLA and <2-hour incident recovery through the 5-year programme (sensitivity: medium). A single catastrophic hub failure lasting >12 hours could affect 4–6 carriers simultaneously and trigger cascading refund claims exceeding the EUR 10M passenger-rights reserve.

### SMART Validation Objective

By Month 3 (2027-01-08), confirm that (1) at least 4 qualified hub operators have been awarded contracts with operational start by Month 9 (2027-07-08); (2) each hub has committed to 99.9% uptime, <2-second latency and <2-hour recovery SLAs in writing; (3) all 12–18 hub-eligible carriers have participated in technical integration workshops and provided data-format compatibility assessments; (4) at least 6–8 carriers have committed to pilot integration with assigned dual-run dates in Months 15–18 (2028-01-08 to 2028-04-08). By Month 9 (2027-07-08), confirm all hubs are operational and ready for pilot carriers. By Month 18 (2028-04-08), confirm that all hubs and assigned carriers have completed dual-run pilots with booking-failure rate below 0.5%; any hub or carrier with failure rate above 2% for >1 week shall be escalated for re-work (estimated 4–8 week delay) and suspended from new onboarding.

### Notes

- Hub procurement is the critical upstream task; delay past Month 3 (2027-01-08) cascades to Month 9 (2027-07-08) operational start and compresses carrier integration to 6–9 months (vs. planned 12 months), causing 15–25% readiness slippage by Month 30 (2029-04-08).
- Hub economics gap (EUR 0.47M/year per hub) is an unfunded item in the budget; cost-recovery decision must be made by Month 30 (2029-04-08) (extend public subsidy vs. raise carrier fees vs. consolidate hubs). If decision is deferred, hub losses compound to EUR 5–10M by Month 48 (2030-10-08).
- Data-mapping errors are the highest operational risk; independent validation by Month 6 (2027-04-08) and mandatory dual-run pilots (Months 15–18 = 2028-01-08 to 2028-04-08) before production go-live are essential to prevent post-launch refund disputes.
- Hub failure stop threshold (2% booking-failure rate for >1 week) is a gate: suspend new carrier onboarding to a failed hub immediately and allocate 4–8 weeks for rework. If multiple hubs fail simultaneously, escalate to Programme Director and consider fallback to gateway or bilateral pairing (cost unestimated).
- Smaller carriers' IT resources are limited; on-site mentoring by 3–5 regional coordinators (budget EUR 1–2M over five years) is essential to support successful integration during Months 6–30 (2027-04-08 to 2029-04-08).


## 4. Budget Burn Rate and Contingency Trigger Events

The EUR 1,500M cap is fixed (user constraint) and the EUR 215M free contingency (EUR 225M – EUR 10M earmarked) is the only buffer against overruns. A 20–30% overrun (EUR 300–450M) exceeds free contingency by EUR 85–235M. Early detection of overrun signals (by Month 12–18 = 2027-10-08 to 2028-04-08) enables timely contingency-tier response (cost cuts, co-funding rate reductions) that protects critical-path items (conformance testing, capacity building, smaller-carrier support). Delayed detection leads to late-stage cuts (Month 24–30 = 2028-10-08 to 2029-04-08) that compromise Month 30 (2029-04-08) readiness by 15–25 percentage points (smaller carriers slip, network fragments). Supplementary funding authority (EUR 100–200M proposed) is outside the cap and not yet secured; early trigger (Month 12 = 2027-10-08) is needed to allow Commission decision by Month 18 (2028-04-08) before conformance-testing phase.

### Data to Collect

- Monthly cumulative spend vs. pro-rata forecast (EUR 25M/month baseline) by line item: standards EUR 280M, clearing EUR 120M, distributor EUR 215M, capacity EUR 100M, consumer EUR 150M, co-funding EUR 290M, data layer EUR 60M, governance EUR 60M
- Early overrun signals: actual carrier co-funding requests vs. EUR 290M budget, distributor operating-cost actuals vs. EUR 43M/year, payment-provider fee exposure vs. EUR 15M subsidy cap, hub cost-recovery gaps vs. EUR 1.9M/year unfunded
- Contingency-tier trigger events: Tier 1 (10–15% overrun), Tier 2 (15–25%), Tier 3 (>25%), with identified line-item cuts and escalation owners
- Supplementary funding authority request timing and likelihood of approval by Month 12 (2027-10-08) if Tier 2 is triggered

### Simulation Steps

- Establish monthly budget-burn dashboard by Month 3 (2027-01-08) with real-time cumulative spend vs. pro-rata forecast (EUR 1,500M ÷ 60 months = EUR 25M/month baseline). Identify variance threshold: escalate to DG MOVE within 5 working days if quarterly spend exceeds 115% of pro-rata (i.e., EUR 86.25M in a 3-month quarter vs. EUR 75M pro-rata).
- Model cost overrun scenarios: (a) Carrier co-funding demand reaches EUR 350–400M (vs. EUR 290M budget) due to larger-than-expected hub-eligible population or cost per carrier exceeding estimate. (b) Distributor operating cost rises to EUR 50–65M/year (from EUR 43M estimate) if retail scope expands beyond planned scope. (c) Payment-provider fee subsidy rises to EUR 20–25M (from EUR 15M cap) if through-ticket adoption is slower than planned and subsidy extends beyond Month 24 (2028-10-08). (d) Hub cost-recovery gap persists (EUR 1.9M/year unfunded) beyond Month 30 (2029-04-08).
- Simulate Tier 1–3 contingency responses: Tier 1 (10–15% overrun = EUR 150–225M): defer consumer-app polish (reduce EUR 30M design budget to EUR 15M), reduce distributor co-marketing from EUR 10M to EUR 5M. Tier 2 (15–25% overrun = EUR 225–375M): reduce carrier co-funding rate from 20% to 10% (save EUR 50–90M), limit hub openings to priority corridors only (defer 2–3 TEN-T hubs to post-Month 60 = 2031-10-08). Tier 3 (>25% overrun = EUR 375–450M): suspend new hub openings, scale capacity building from EUR 100M to EUR 60–70M (defer weaker-capacity regulator twinning to post-Month 36 = 2029-10-08).
- Model the impact of each contingency tier on critical-path milestones: Tier 1 delays consumer app launch by 2–4 weeks (Month 15–19 = 2028-01-08 to 2028-05-08) and reduces early-adopter distributor engagement by ~10%. Tier 2 delays smaller-carrier co-funding release by 3–6 months, pushing 20–30% of carriers past Month 30 (2029-04-08) API deadline, fragmenting network coverage to 70–80% of potential traffic. Tier 3 forces abandonment of capacity-building for weaker regulators, leaving 4–8 member-state regulators under-resourced for enforcement, creating a two-tier compliance landscape.

### Expert Validation Steps

- Commission an independent cost-modelling firm by Month 0.5 (2026-10-23) to validate the EUR 1,500M budget allocation across all line items and to sensitivity-test each line for ±20–30% cost variance; deliver detailed cost forecast by Month 2 (2026-12-08) with scenario recommendations.
- Have DG MOVE finance controller review the monthly burn-rate dashboard methodology by Month 2 (2026-12-08) to confirm it accurately tracks programme spend and flags overruns in real-time.
- Conduct a mid-course budget review at Months 12 and 24 (2027-10-08, 2028-10-08) with the Steering Committee, Programme Director and DG MOVE budget authority; compare cumulative spend to pro-rata forecast, assess any triggered contingency tier, and decide escalation to Commission for supplementary funding if needed.
- Validate that the EUR 225M contingency reserve is held separately at DG MOVE and not subject to automatic release without explicit Steering Committee decision; confirm the reserve is protected from other EU programme encroachments by Month 3 (2027-01-08).

### Responsible Parties

- Budget Controller and Financial Manager (responsible for monthly dashboard, variance analysis, and contingency escalation)
- DG MOVE finance authority (holds contingency reserve; decides Tier 2–3 responses and supplementary funding request)
- Independent cost-modelling consultant (validates budget allocation and scenarios)
- Steering Committee (decides Tier 2–3 responses and supplementary funding strategy at mid-course reviews)

### Assumptions

- **High:** Carrier co-funding demand will track the EUR 290M budget estimate (12–18 carriers × EUR 15–25M average per carrier) (sensitivity: high). If actual demand is 30% higher (EUR 350–400M), contingency is triggered at Month 12 (2027-10-08) and Tier 2 response (reduce co-funding rate to 10%) must be invoked, delaying smaller-carrier integration by 3–6 months.
- **High:** Distributor operating cost will be EUR 43M/year as budgeted (based on reference-implementation scope, not full retail channel) (sensitivity: high). If retail scope expands or consumer support costs are underestimated, operating cost could rise to EUR 50–65M/year, consuming EUR 35–110M from free contingency.
- **Medium:** Payment-provider fee subsidy will be EUR 15M (60% of fees Months 0–24 = 2026-10-08 to 2028-10-08) and will not extend beyond Month 24 (2028-10-08) (sensitivity: medium). If through-ticket adoption is slow or carriers demand extended subsidy, actual cost could reach EUR 20–25M, consuming EUR 5–10M from free contingency.
- **Medium:** Hub cost-recovery gap (EUR 0.47M/year per hub, EUR 1.9M/year for 4 hubs) will be managed by Month 30 (2029-04-08) through carrier-fee increases or cost reduction (sensitivity: medium). If hub operators cannot achieve cost recovery and public subsidy extends beyond Month 30 (2029-04-08), cumulative deficit reaches EUR 5–10M and forces hub consolidation or extended public funding.
- **Medium:** DG MOVE will seek supplementary budget authority from the Commission by Month 12 (2027-10-08) if Tier 2 is triggered, with a 60-day Commission decision gate (approval target Month 18 = 2028-04-08) (sensitivity: medium). Political reluctance or competing budget priorities could delay supplementary authority, forcing unplanned Tier 3 cuts.

### SMART Validation Objective

By Month 12 (2027-10-08), confirm that (1) monthly burn-rate dashboard is operational and cumulative spend through Month 11 (2027-09-08) is within 110% of pro-rata forecast (EUR 275M vs. EUR 250M pro-rata; acceptable variance); (2) no Tier 2 or Tier 3 contingency has been triggered; (3) early overrun signals from carrier co-funding requests, distributor cost actuals, or payment-fee demand have been identified and flagged to DG MOVE within 2 weeks of detection. By Month 24 (2028-10-08), reconfirm that cumulative spend is within 115% of pro-rata forecast (EUR 575M vs. EUR 500M pro-rata); if Tier 2 is triggered, escalate supplementary funding request to Commission with target EUR 100–200M and decision gate Month 30 (2029-04-08). If cumulative spend exceeds 125% of pro-rata (EUR 625M at Month 24 = 2028-10-08), trigger Tier 3 and immediately suspend new hub or capacity-building commitments.

### Notes

- Early detection of overrun signals is critical; delays of more than 2 weeks in flagging a variance reduce the window for contingency response from 6–12 months to 2–4 months, preventing orderly mitigation.
- Contingency-tier responses have cascading effects: Tier 2 (reduce co-funding to 10%, limit hubs to priority corridors) delays smaller-carrier integration by 3–6 months and risks fragmenting the network; Tier 3 (suspend new hub openings, scale-back capacity building) compromises the Month 30 (2029-04-08) mandate and halved-complaints target. Escalate any trigger immediately to Steering Committee.
- Supplementary funding (EUR 100–200M proposed) is outside the cap and not pre-approved; early triggering (Month 12 = 2027-10-08) is essential to allow Commission decision before conformance-testing phase (Month 18 = 2028-04-08).
- Hub cost-recovery gap (EUR 1.9M/year unfunded) is a known item; decide cost-recovery strategy by Month 30 (2029-04-08) (extend public subsidy, raise carrier fees, or consolidate hubs) to avoid cumulative EUR 5–10M deficit by Month 48 (2030-10-08).
- Reserve the EUR 225M contingency strictly for programme use; prevent other EU priorities from encroaching on the reserve. Confirm separation at DG MOVE by Month 3 (2027-01-08).


## 5. Data Protection Impact Assessment (DPIA) and GDPR Consensus from National DPAs

Passenger PII flows across 5+ data controllers (distributors, carriers, payment institutions, clearing entity, national regulators), and cross-border data transfers require GDPR compliance via Standard Contractual Clauses (SCCs) or similar mechanisms. Unresolved GDPR governance can halt payment-institution accreditation (payment institutions will not partner without clear data-governance framework) and delay the data layer by 6–12 months if a national DPA issues a unilateral stop order on cross-border flows. Accessibility data (mobility restrictions, medical conditions) is special-category under GDPR Article 9 and requires heightened consent; if the programme requires explicit consent at booking time, it may create friction that reduces assisted-travel uptake. Early engagement with national DPAs (Months 1–2 = 2026-11-08 to 2026-12-08) reduces the risk of a late-stage blocking challenge (Month 6–9 = 2027-04-08 to 2027-07-08).

### Data to Collect

- Complete Data Protection Impact Assessment mapping all passenger PII flows by transaction type (booking, payment, refund, disruption notification, accessibility assistance request) across 5+ data controllers (distributors, carriers, payment institutions, clearing entity, national regulators)
- Standard Contractual Clauses (SCCs) templates for carrier-to-carrier data transfers, carrier-to-clearing transfers, and third-party distributor access to carrier inventory data
- Data residency rules and national DPA positions from Austria, Germany, France, Netherlands, Poland, Bulgaria, Romania, Spain, Sweden on whether carrier data must be stored in home member state or may be stored in a EU-wide data centre
- Accessibility data consent regime and special-category data (GDPR Article 9) governance: whether explicit consent is required at booking time or implicit opt-in is lawful
- Cross-border refund-dispute data sharing protocols: which member state's data-protection law applies when a German passenger disputes a refund with French and Austrian carriers

### Simulation Steps

- Commission a Data Protection Impact Assessment by Month 1 (2026-11-08) mapping all PII flows by transaction type and identifying minimum-necessary data per flow (booking: name, email, payment details, mobility attributes; payment: card details to accredited providers only; refund: booking reference, original payment method, passenger contact; disruption: passenger email/SMS only). Sensitivity: if data minimisation is too strict, distributors lack inventory detail for good through-fare offers (e.g., seat availability, loading factor); if too loose, GDPR audit will flag over-collection.
- Model three data-governance scenarios: (a) Federated (each carrier holds authoritative data, access points route queries, no central cache): slower latency (5–10 seconds), lower residency risk, higher complexity; (b) Central cache (EU-wide availability cache, carriers feed continuously): faster latency (<2 seconds), higher residency risk, depends on DPA consensus; (c) Hybrid (federated + event-streaming for disruption data only): medium latency, medium residency risk, acceptable to most DPAs.
- Conduct 1-on-1 pre-engagement consultations with 7–9 national DPAs (Austria, Germany, France, Netherlands, Poland, Bulgaria, Romania, Spain, Sweden) by Month 1.5 (2026-11-23) to identify residency, consent, or data-minimisation concerns early, before formal DPIA publication.
- Develop SCC templates for three data-flow categories (carrier-to-carrier inventory sharing, carrier-to-clearing revenue apportionment, distributor-to-carrier for booking/refund) and circulate drafts to task-force DPAs by Month 2 (2026-12-08) for pre-review and feedback.

### Expert Validation Steps

- Present the draft DPIA and SCC templates to the EDPB secretariat by Month 3 (2027-01-08) and request guidance on a single harmonised SCC template covering all multi-carrier through-ticketing data flows (target guidance Month 4 = 2027-02-08). If EDPB escalates the question to full EDPB plenary (risk: 6–9 month delay), trigger emergency procedure (propose supplementary legal instrument or Commission adequacy decision) by Month 5 (2027-03-08).
- Obtain written sign-off from at least 8 of 27 member-state DPAs on the DPIA and SCC framework by Month 4 (2027-02-08); flag any DPA that signals a unilateral stop order on cross-border data flows as a blocking risk and escalate to Commission for emergency mediation.
- Have an EU data-protection law specialist review the final DPIA and SCC templates for compliance with Schrems II and recent EDPB guidance on Standard Contractual Clauses (risk of invalidation by courts or regulatory challenge) by Month 3 (2027-01-08).
- Validate accessibility-data consent regime (implicit vs. explicit) with BEUC and disability-rights organizations by Month 2 (2026-12-08) to confirm the chosen model does not create barriers to booking assistance (e.g., if explicit consent is required, will passengers refuse and thus not be able to book accessible itineraries?).

### Responsible Parties

- Data Protection Impact Assessment Lead / GDPR Compliance Specialist (hired by Month 1 = 2026-11-08; leads DPIA drafting and DPA engagement)
- DPA Task Force (7–9 member-state DPAs: Austria, Germany, France, Netherlands, Poland, Bulgaria, Romania, Spain, Sweden; provides pre-engagement feedback and signs off on DPIA and SCC framework by Month 4 = 2027-02-08)
- EU Data Protection Law Specialist (validates DPIA and SCCs for Schrems II and EDPB guidance compliance)
- EDPB secretariat (provides guidance on harmonised SCC template for multi-carrier through-ticketing, if needed)

### Assumptions

- **High:** At least 8 of 27 member-state DPAs will review and sign off on the DPIA and SCC framework by Month 4 (2027-02-08) (sensitivity: high). If fewer than 8 DPAs sign off or if a major DPA (Austria, Germany, France) refuses, the framework is rejected and must be redesigned, delaying payment-institution accreditation by 3–6 months.
- **High:** The EDPB will issue guidance on a single harmonised SCC template for multi-carrier through-ticketing by Month 4 (2027-02-08) or will accept the programme's proposed SCCs without further escalation (sensitivity: high). If the EDPB escalates to full plenary or requests major revisions, the timeline extends 6–9 months and payment-institution accreditation is delayed.
- **Medium:** Accessibility data (mobility attributes, medical conditions) can be handled via implicit opt-in consent (passive consent at booking time unless explicitly refused) (sensitivity: medium). If GDPR Article 9 requires explicit opt-in consent, passengers may refuse or become confused during booking, reducing assisted-travel uptake by 10–20%.
- **Medium:** Data residency rules will allow EU-wide storage of carrier inventory and booking data (with encryption and access controls) rather than requiring home-member-state residency only (sensitivity: medium). If Bulgaria, Romania or Hungary demand local residency, the data layer must be redesigned to federated queries (slower latency, higher complexity).
- **Low:** The recent Schrems II court ruling on Standard Contractual Clauses (and EDPB follow-up guidance) will be stable and will not require rework of SCCs during the programme (sensitivity: low). Further court challenges or DPA guidance updates in 2027–2028 could force revision of the programme's data-governance framework post-DPIA.

### SMART Validation Objective

By Month 4 (2027-02-08), confirm that (1) the DPIA is complete and maps all PII flows by transaction type with minimum-necessary data identified for each; (2) SCC templates for three data-flow categories (carrier-to-carrier, carrier-to-clearing, distributor-to-carrier) are drafted and have been reviewed by at least 8 national DPAs; (3) the EDPB has issued or indicated acceptance of the programme's SCC framework without requiring major revisions; (4) the accessibility-data consent regime (implicit opt-in) has been validated by BEUC and disability-rights organizations as not creating barriers to assisted-travel booking. By Month 6 (2027-04-08), if no DPA has issued a unilateral stop order or blocking challenge, escalate DPIA sign-off to Payment Provider Accreditation task force as a prerequisite for accreditation. If a DPA blocks the framework, trigger emergency escalation to Commission for dispute resolution (4-week target).

### Notes

- GDPR governance is on the critical path for payment-institution accreditation (Month 8 = 2027-06-08 decision). Unresolved DPIA or DPA consensus delays accreditation to Month 12–15 (2027-10-08 to 2028-01-08), compressing the data-layer deployment window and threatening Month 30 (2029-04-08) API mandate.
- Austria, Germany, France and Poland are known to have strict data-governance regimes; early 1-on-1 engagement (Month 1.5 = 2026-11-23) with these DPAs is essential to identify blocking concerns before formal DPIA publication.
- Schrems II ruling on SCCs is already in effect (from July 2020 decision, enforcement varies by DPA); validate that the programme's SCCs comply with EDPB follow-up guidance (October 2020 and follow-ups) by Month 2 (2026-12-08) to avoid late-stage rework.
- Accessibility data consent is a tension: GDPR Article 9 requires heightened protection of special-category data, but disability-rights advocacy demands easy assistance booking. The programme must balance these via a consent model that is lawful but not burdensome; pilot with BEUC by Month 2 (2026-12-08).
- Data residency divergence (home-state only vs. EU-wide cache) is a major architectural choice; if residency is mandated, the data layer must be re-architected to federated queries (slower, more complex). Decision point: Month 4 (2027-02-08).


## 6. Killer Application Definition and Through-Ticket Valuation Hypothesis Testing

The programme targets 40% through-ticket share and 5–15% modal shift from air, yet no validated product or pricing strategy demonstrates traveller demand for these outcomes. Without a compelling killer application—a product that travellers prefer over flying or buying separate tickets—distributor incentive, carrier willingness to invest, and passenger adoption all remain weak. The programme risks hitting 40% volume through convenience alone (single booking) but missing the modal-shift and halved-complaints goals. Early customer research (Months 1–6 = 2026-11-08 to 2027-04-08) and a pilot (Months 9–12 = 2027-07-08 to 2027-10-08) validate whether a killer application is viable before the programme commits to full-scale rollout (Month 27 = 2029-01-08).

### Data to Collect

- Customer research on traveller willingness to pay for three candidate killer applications: (1) guaranteed-connection through-ticket (4-hour reroute, 10-day refund, single contact), (2) air-rail city-pair (all-inclusive fare vs. flight competitor), (3) assisted-travel journey (pre-confirmed assistance + priority seating + platform handover)
- Pricing elasticity and cross-elasticity: through-fare competitiveness vs. budget airlines (baseline flight price EUR 40–70, through-fare estimate EUR 70–90), vs. separate operator tickets (EUR 60–80)
- Traveller booking intent and conversion rate: percentage of surveyed travellers willing to book each killer application vs. existing alternatives (flight, separate tickets, car)
- Reduction-card effectiveness: cross-border reduction-card recognition value (~10–15% effective discount) and traveller response to unified reduction-card scheme

### Simulation Steps

- Commission customer research (willingness-to-pay study, conjoint analysis) on three candidate killer applications by Month 1 (2026-11-08) targeting 300–500 surveyed travellers per application, stratified by route (Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin) and traveller segment (frequent business, leisure, budget-conscious). Baseline question: 'Would you choose rail over a flight if the through-fare were EUR X [vary 60, 70, 80, 90] and you could change trains for free if you missed your connection?' Sensitivity: pricing elasticity and switching behaviour vary by route (short-haul air competition is strong on Paris–Brussels; moderate on Wien–München; weaker on Copenhagen–Hamburg).
- Model through-fare competitiveness: baseline through-fare (sum of segment prices) EUR 70–90 on priority corridors vs. low-cost airlines (EUR 40–70 on aggressive routes, EUR 50–80 on moderate competition). Estimate mode-shift elasticity (% of air passengers switching to rail per 10% fare reduction) and apply to annual short-haul air volumes on each corridor to forecast baseline modal-shift rate (5–10% without killer application, 15–25% with validated killer application).
- Pilot one killer application on one corridor (Paris–Brussels–Amsterdam–Köln or Wien–München–Zürich) by Month 9 (2027-07-08) with real traveller bookings (target 500–1,000 bookings over 3-month pilot). Track booking conversion rate, customer satisfaction (NPS, 5-star rating), and actual usage (completion rate, refund frequency). Measure: did guaranteed-connection messaging increase conversion vs. standard multi-operator tickets? Did 4-hour reroute promise and 10-day refund reduce passenger anxiety and increase loyalty?
- Sensitivity test: if pilot conversion rate is <3% (vs. existing single-operator rail product at 5–8%), the killer application lacks valuation and demand is driven by convenience only. If conversion rate is >8%, the product has strong appeal and should be scaled to all four corridors.

### Expert Validation Steps

- Engage Trainline, Omio and the public reference distributor in co-design of the killer application (Month 2–4 = 2026-12-08 to 2027-02-08) to ensure the product is technically feasible (booking interface, rerouting system integration, refund processing) and commercially viable (margin requirements). Request these distributors' historical through-ticket booking data and willingness-to-promote the product in exchange for early API access (proposed at Month 9–12 = 2027-07-08 to 2027-10-08).
- Present the willingness-to-pay study findings to a carrier product council (SNCF, DB, ÖBB, Renfe, Trenitalia representatives) by Month 6 (2027-04-08) to validate that the promised reroute (<4 hours) and refund (<10 days) timelines are operationally feasible and that reduction-card recognition is acceptable to carriers.
- Commission an independent modal-shift analyst to validate the research's elasticity assumptions and to reconcile the study's stated willingness to pay against observed market pricing (e.g., current Trainline and Omio through-ticket share and pricing strategy on comparable corridors) by Month 6 (2027-04-08).
- After the pilot (Month 12 = 2027-10-08), present conversion-rate and satisfaction results to the Steering Committee; if conversion rate is <3%, escalate and propose a contingency decision (regulated fare ceilings, modal-shift subsidy, or re-scope of the 40% target) by Month 15 (2028-01-08).

### Responsible Parties

- Consumer Product and App Development Lead (owns killer-application design and pilot rollout)
- Independent customer-research firm (conducts willingness-to-pay study and pilot conversion/satisfaction tracking)
- Distributor partners (Trainline, Omio, public reference distributor; co-design the killer application and provide booking and refund-processing integration)
- Carrier product council (validates operational feasibility of promised reroute and refund timelines)

### Assumptions

- **High:** Customer willingness-to-pay research will show that a guaranteed-connection through-ticket with 4-hour reroute and 10-day refund, priced at EUR 70–80, is preferable to a budget flight at EUR 40–70 by at least 15–20% of surveyed travellers (sensitivity: high). If <10% prefer the through-ticket, demand is weak and the 40% target is unachievable without subsidies.
- **Medium:** Reduction-card harmonisation (cross-border recognition at 10–15% effective discount) will increase through-ticket conversion by 5–10 percentage points (sensitivity: medium). If reduction-card value is lower or recognition is incomplete, the conversion uplift is smaller.
- **High:** The pilot killer application will achieve conversion rate >3% (vs. existing single-operator rail at 5–8% estimate) by Month 12 (2027-10-08) (sensitivity: high). If conversion is <3%, the product lacks demand and the 40% target requires either fare subsidies, regulatory mandates, or re-scoping.
- **Medium:** Carriers will agree that promised reroute (<4 hours) and refund (<10 days) timelines are operationally feasible given existing disruption-handling and refund procedures (sensitivity: medium). If operationally infeasible, promises cannot be kept and passenger dissatisfaction erodes demand.
- **Medium:** Trainline and Omio will commit to early API access and co-marketing support in exchange for killer-application co-design and preferential treatment at launch (Month 15 = 2028-01-08) (sensitivity: medium). If distributors lack margin incentive or are unwilling to prioritise the programme, the product lacks distribution channels.

### SMART Validation Objective

By Month 6 (2027-04-08), confirm that (1) willingness-to-pay research is complete and shows that at least 15–20% of surveyed travellers prefer the killer application over budget flights or separate tickets at the target through-fare (EUR 70–90); (2) one killer application has been selected for pilot (e.g., guaranteed-connection through-ticket) and is in co-design with Trainline, Omio and carrier partners; (3) operational feasibility of promised reroute (<4 hours) and refund (<10 days) timelines has been validated by a carrier product council. By Month 12 (2027-10-08), confirm that the pilot has been live for 3 months and conversion rate is >3% (vs. benchmark 5–8% for single-operator rail); customer satisfaction is ≥4.0/5; refund and reroute timelines are being met >90% of the time. If conversion is <3% or satisfaction is <3.5/5, escalate to Steering Committee and propose contingency decision (regulate fares, subsidy, or re-scope target) by Month 15 (2028-01-08). If pilot is successful, scale to all four corridors and four-corridor consumer go-live at Month 27 (2029-01-08).

### Notes

- Killer application is the missing link in the programme's commercial strategy; without validated traveller demand, the 40% through-ticket and modal-shift targets are aspirational and unachievable via regulatory mandate alone.
- Willingness-to-pay study should include pricing sensitivity across routes (short-haul air is competitive on Paris–Brussels, weaker on Copenhagen–Hamburg) and traveller segments (business vs. leisure); bulk findings may hide important route-level divergence.
- Pilot conversion rate <3% signals weak demand and should trigger a re-baseline decision: either introduce regulated fare ceilings (antitrust risk), offer modal-shift subsidies (budget impact), or re-scope the 40% target to exclude air-competitive routes.
- Reduction-card harmonisation is a secondary driver of conversion; estimate its contribution (5–10 percentage points) separately from the killer application's primary benefit (single booking, guaranteed connection).
- Distributor buy-in is critical; without Trainline and Omio prioritising the killer application, commercial reach is limited and consumer adoption lags. Offer early API access and co-marketing budget (EUR 5–10M over Months 15–27 = 2028-01-08 to 2029-01-08) to secure commitment by Month 6 (2027-04-08).


## 7. Post-Month 60 (2031-10-08) Funding Model for Distributor, Hubs, Data Layer and Regulator Capacity

The programme's public budget ends at Month 60 (2031-10-08), but core infrastructure dependencies (distributor, hubs, data layer, regulator capacity) have recurring costs estimated at EUR 45M/year unfunded (distributor EUR 43M + hub gap EUR 1.9M). Without a decision on post-Month 60 (2031-10-08) funding by Month 48 (2030-10-08), the programme risks operational collapse at Month 60 (2031-10-08), with the distributor forced to shut down, hubs abandoned, and the data layer orphaned. This would strand all prior investment and revert cross-border rail to pre-programme fragmentation. Early sustainability planning (Months 30–48 = 2029-04-08 to 2030-10-08) allows time for political negotiation, member-state commitment, and orderly transition design.

### Data to Collect

- Sustainable operating costs for core infrastructure beyond the 5-year programme: public reference distributor (estimated EUR 43M/year, post-Month 60 = 2031-10-08), hub cost-recovery gap (EUR 0.47M/year per hub, EUR 1.9M/year for 4 hubs), data-layer operations (EUR 15–30M/year estimated), regulator capacity maintenance (EUR 5–10M/year estimated)
- Revenue models and fee-recovery scenarios: carrier subscription fees for hub use, distributor transaction fees passed to travellers/carriers, payment-provider cost recovery, data-layer access fees
- Transition mechanisms: timeline for shifting from programme subsidy to sustainable funding (cost-recovery transition deadline Month 48 = 2030-10-08, funding model decision Month 48 = 2030-10-08, implementation Month 55 = 2031-05-08)
- Contingency funding sources if fee-recovery is insufficient: member-state co-funding, EU structural funds, voluntary carrier contributions, or sunset/consolidation of services

### Simulation Steps

- Establish a Sustainability Task Force by Month 30 (2029-04-08) with representatives from DG MOVE, the EU Agency for Railways, hub operators, the reference distributor, carrier federation (CER) and a payment services provider. Commission a financial sustainability study: model the operating costs for each core service post-Month 60 (2031-10-08) (distributor EUR 43M/year baseline, hub EUR 1.9M/year gap, data layer EUR 20M/year estimate, regulators EUR 8M/year estimate) and estimate fee-revenue potential (hub fees EUR 50–200K per carrier per year, distributor transaction fees 0.5–1% per ticket, data-layer access fees if applicable).
- Develop three scenarios: (a) Cost-recovery via fees: carriers and distributors pay for hub use, distributor operations, and data-layer access; revenue gap estimated at EUR 10–30M/year if through-ticket volume is 40% as targeted (spread across 1,000s of transactions, fee per transaction 1–2% may be infeasible without raising traveller fares). (b) Member-state co-funding: 27 member states commit to shared contribution (EUR 5–15M/year from collective transport budgets) to sustain regulator capacity and hub operations; feasibility depends on national political commitments by Month 48 (2030-10-08). (c) Sunset/consolidation: public distributor shuts down by Month 60 (2031-10-08), hubs transition to paid carrier consortia or private operators, data layer transferred to EU Agency for Railways with reduced feature set (federated queries only, no central cache).
- Sensitivity test: if through-ticket volume plateaus at 25% instead of 40% by Month 60 (2031-10-08), fee-revenue potential decreases 35–40%, making cost-recovery via fees unachievable and forcing reliance on member-state co-funding or sunset.

### Expert Validation Steps

- Engage the EU Agency for Railways and DG MOVE by Month 30 (2029-04-08) to confirm willingness to absorb data-layer operations post-Month 60 (2031-10-08) under a sustainable funding model (membership fees, EU budget allocation, or carrier levies).
- Present the sustainability study to the Steering Committee by Month 42 (2030-04-08) and request guidance on the preferred funding model (fee-recovery vs. member-state co-funding vs. sunset).
- Secure written commitment from at least 15 of 27 member states to contribute to post-Month 60 (2031-10-08) regulator capacity funding (EUR 5–15M/year collectively) by Month 48 (2030-10-08), conditional on demonstrating the 40% through-ticket share and halved-complaints targets by Month 60 (2031-10-08).
- Negotiate hub transition agreements with hub operators by Month 42 (2030-04-08) specifying: if cost-recovery is chosen, hub fees are raised to EUR 100–300K per carrier per year (from estimated EUR 50–200K); if member-state funding is chosen, hubs continue under programme subsidy transition; if sunset is chosen, hubs shut down by Month 60 (2031-10-08) and carriers transition to native APIs or consortia-run hubs (unplanned cost for carriers).

### Responsible Parties

- Sustainability Task Force (established by Month 30 = 2029-04-08; includes DG MOVE, EU Agency for Railways, hub operators, distributor, CER, payment provider; leads financial sustainability study and scenario modelling)
- Independent financial sustainability consultant (models operating costs, fee-revenue potential, and funding scenarios)
- EU Agency for Railways (confirms willingness to absorb data-layer operations post-Month 60 = 2031-10-08 under sustainable funding)
- DG MOVE (negotiates member-state commitment to post-Month 60 = 2031-10-08 regulator capacity funding)

### Assumptions

- **High:** Through-ticket volume will reach 40% of cross-border rail journeys by Month 60 (2031-10-08), generating sufficient fee-revenue (1–2% per transaction across millions of annual bookings) to offset some operational costs (sensitivity: high). If actual volume is 25–30%, fee-revenue potential is reduced 35–40%, making cost-recovery via fees insufficient and forcing reliance on member-state co-funding or sunset.
- **Medium:** Member states will commit to EUR 5–15M/year collective contribution to post-Month 60 (2031-10-08) regulator capacity funding if the 40% through-ticket target is achieved (sensitivity: medium). If targets are missed (through-ticket share 25%, complaints not halved), member-state political commitment weakens.
- **Medium:** Hub operators will accept a transition from programme subsidy to fee-revenue (EUR 100–300K per carrier per year) or will opt out and shut down hubs by Month 60 (2031-10-08) (sensitivity: medium). If hub operators demand extended public subsidy post-Month 60 (2031-10-08), the programme's cost obligation extends indefinitely.
- **Medium:** The EU Agency for Railways will agree to absorb data-layer operations post-Month 60 (2031-10-08) as part of its core mandate, with dedicated budget allocation or fee-recovery via access charges (sensitivity: medium). If the Agency declines, the data layer is orphaned or transferred to a commercial operator.
- **Low:** The public reference distributor can transition to either (a) cost-recovery (transaction fees to carriers/distributors/travellers), (b) hand-off to a commercial operator, or (c) orderly shutdown by Month 60 (2031-10-08) (sensitivity: low). If none of these options are viable, the distributor becomes a long-term unfunded liability.

### SMART Validation Objective

By Month 42 (2030-04-08), confirm that (1) the Sustainability Task Force has completed a financial sustainability study estimating post-Month 60 (2031-10-08) operating costs for distributor, hubs, data layer and regulators; (2) three funding scenarios (fee-recovery, member-state co-funding, sunset) have been modelled with realistic cost and revenue projections; (3) the Steering Committee has recommended a preferred funding model. By Month 48 (2030-10-08), confirm that (1) the preferred funding model has been formally decided by DG MOVE and the Commission; (2) at least 15 member states have committed in writing to post-Month 60 (2031-10-08) regulator capacity funding (if member-state co-funding is chosen); (3) hub operators have been notified of the transition plan and fee schedule (if fee-recovery is chosen); (4) the public distributor has a transition plan (shutdown, hand-off, or cost-recovery) with a target implementation date (Month 55 = 2031-05-08). If no funding model is agreed by Month 48 (2030-10-08), escalate to the Commission with a contingency recommendation (e.g., sunset of distributor, consolidation of hubs, data-layer transition to Agency) to prevent programme collapse at Month 60 (2031-10-08).

### Notes

- Post-Month 60 (2031-10-08) funding is a critical but deferred decision; early planning (Months 30–48 = 2029-04-08 to 2030-10-08) is needed to avoid operational collapse. The EUR 45M/year unfunded cost must be resolved, not assumed to continue indefinitely from EU budget allocations.
- Through-ticket volume at Month 60 (2031-10-08) directly determines fee-revenue potential; if the 40% target is missed, fee-recovery scenarios are less viable and member-state co-funding becomes essential. Use measurement dashboard (Months 18–60 = 2028-04-08 to 2031-10-08) to forecast Month 60 (2031-10-08) volume by Month 42 (2030-04-08) and adjust sustainability plans accordingly.
- Hub cost-recovery gap (EUR 0.47M/year per hub, EUR 1.9M/year for 4 hubs) is an unfunded item in the current budget; decision to extend public subsidy beyond Month 48 (2030-10-08) or raise carrier fees (EUR 50–300K per carrier per year) must be made by Month 30 (2029-04-08) to give carriers time to plan.
- EU Agency for Railways' willingness to assume data-layer operations is a political decision not yet confirmed; early engagement (Month 30 = 2029-04-08) is needed to signal expectations and secure commitment.
- If cost-recovery via fees is chosen, traveller fares may increase 1–2% (depending on volume and margin) due to distributor, hub, and data-layer fees; model the impact on through-ticket demand and fee-revenue feedback loops.

## Summary

This project data-collection plan identifies 7 critical validation areas essential to the EUR 1.5 billion, five-year EU cross-border rail through-ticketing programme: (1) Regulation adoption and standards alignment (Month 9 = 2027-07-08 gate); (2) Carrier commitment to arbitration panel authority (Month 3 = 2027-01-08 gate); (3) Hub procurement and smaller-carrier integration readiness (Month 9 = 2027-07-08 operationalization); (4) Budget burn-rate monitoring and contingency triggers (monthly dashboards, Tier 2–3 decisions); (5) GDPR/DPA consensus on data governance (Month 4 = 2027-02-08 gate); (6) Killer-application validation and traveller demand testing (Months 6–12 = 2027-04-08 to 2027-10-08 pilot); and (7) Post-Month 60 (2031-10-08) sustainability planning (Month 48 = 2030-10-08 decision). Immediate actionable tasks: (A) Launch regulatory adoption tracking and engagement with Parliament/member states by Month 0.5 (2026-10-23); commission shadow standards pre-work and cost model by Month 1 (2026-11-08); (B) Secure Council/Commission delegation of arbitration panel authority by Month 2 (2026-12-08, target 1.5 = 2026-11-23); (C) Issue hub operator RFP by Month 0.5 (2026-10-23) and award contracts by Month 3 (2027-01-08); (D) Commission DPIA and convene DPA task force by Month 1 (2026-11-08); (E) Launch customer research on killer applications and pilot one by Month 9 (2027-07-08); (F) Establish monthly budget dashboards with 115% spend trigger by Month 3 (2027-01-08). Success hinges on securing the three highest-sensitivity prerequisites: Regulation adoption by Month 9 (2027-07-08), arbitration panel delegation by Month 2 (2026-12-08), and carrier Commitment Letters by Month 3 (2027-01-08). If any prerequisite slips beyond its gate, the critical path shifts downstream, threatening Month 18 (2028-04-08) standards and Month 30 (2029-04-08) API mandate. Contingency: if Regulation adoption slips past Month 8 (2027-06-08), contract external standards consortium by Month 8.5 (2027-06-23) for accelerated pre-work; if budget overruns exceed 115% of pro-rata by Month 12 (2027-10-08), trigger Tier 2 contingency (reduce co-funding, limit hubs); if GDPR consensus is not reached by Month 4 (2027-02-08), escalate to EDPB for expedited guidance.