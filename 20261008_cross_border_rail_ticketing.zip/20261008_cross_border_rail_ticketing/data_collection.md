## 1. Carrier Liability Model Actuarial Validation and Risk Parameters

The carrier-funded guarantee pool is the core incentive-alignment mechanism that determines whether 25+ operators will expose connections. Without actuarially validated caps and contribution weights, carriers cannot price participation and will refuse, fragmenting corridors and collapsing the 40% through-ticket target to 15–25%. This is the highest-impact blocking dependency.

### Data to Collect

- 24-month historical missed-connection incident rates per carrier (frequency, severity, clustering patterns)
- Rerouting cost distributions (passenger assistance, alternative ticket issuance, accommodation) by carrier and route
- Carrier on-time performance data (12-month rolling) to calibrate contribution-weighting formula
- Insurance market quotes for pool coverage above proposed co-insurance thresholds
- Carrier financial capacity statements (loss reserves, credit lines available for pool contributions)

### Simulation Steps

- Build a Monte Carlo incident-clustering model using historical rail disruption data from Rail Settlement Plan (GB), Trenitalia–ÖBB bilateral clearing, and CER aggregate reports to project pool cash flows under three scenarios (conservative, base, aggressive)
- Run sensitivity analysis in Excel or R on proposed caps (EUR 250, 500, 1,000, 2,000 per passenger) and co-insurance triggers (EUR 20M, 50M, 100M annual draw) to show per-carrier contribution ranges and risk distribution
- Use insurance-industry benchmarks (e.g., Munich Re, Swiss Re) to validate that proposed caps align with similar transport liability pools and to quote reinsurance cost for tail exposure
- Stress-test the pool model against historically volatile periods (e.g., winter 2021-22 rail disruptions, COVID-19 lockdown rerouting spikes) to identify worst-case drawdown scenarios

### Expert Validation Steps

- Engage an independent actuarial firm (e.g., Deloitte Consulting, Mercer, or specialist rail insurance actuaries) to conduct the statistical analysis and deliver priced liability parameters by Month 3 (2027-01-12)
- Present the actuarial model to the EU Agency for Railways and CER for technical review and sign-off on methodology by Month 4 (2027-02-12)
- Conduct bilateral meetings with at least 8 major carriers (SNCF, DB, SBB, ÖBB, Renfe, NS, Trenitalia, ČD) to present worked examples for their carrier profile and obtain non-binding feedback on acceptable exposure levels by Month 4 (2027-02-12)
- Secure binding written commitment from at least 8 major carriers and CER confirming they will expose through-ticket inventory under the final priced model by Month 4 (2027-02-12), or escalate design issues to Commission mediation by Month 5 (2027-03-12)

### Responsible Parties

- Independent actuarial firm (commissioned Month 1 = 2026-11-12; reports Month 3–6 = 2027-01-12 to 2027-04-12)
- EU Agency for Railways (technical review of methodology)
- CER and 8+ major carriers (bilateral feedback and sign-off)
- Programme Office (escalation to Commission mediation if consensus not reached by Month 5 = 2027-03-12)

### Assumptions

- **High:** Historical missed-connection and rerouting cost data are available from at least 3 major carriers (CER, RSC, bilateral arrangements) spanning 24 months with granular incident classification (delay cause, reroute cost, passenger demographic).
- **High:** Carriers will provide proprietary loss data to the actuarial firm under confidentiality agreements and will engage constructively in validation workshops; refusal by >2 major carriers stalls the entire liability model.
- **Medium:** Insurance market reinsurance cost for pool coverage (EUR 20–100M threshold) is commercially available and priced at <5% of limit, fitting within EUR 150M reserve or EUR 220M clearing budget.
- **High:** Actuarial modelling of through-ticket-specific incidents (multi-leg clustering, disruption correlation) is feasible using historical single-operator data with adjustment factors; no through-ticket baseline is available.
- **High:** At least 8 carriers sign binding letters of intent by Month 4 (2027-02-12); if <6 sign, the month 6 (2027-04-12) readiness gate defers and triggers month 12 (2027-10-12) contingency.

### SMART Validation Objective

By Month 4 (2027-02-12), deliver an actuarially validated liability model with per-incident caps, co-insurance thresholds, and contribution weights specific to three carrier profiles (large, regional, small), supported by 24-month incident data analysis. Secure binding written commitment from 8+ major carriers confirming participation at proposed risk levels. Establish quarterly pool monitoring by Month 6 (2027-04-12) to track actual vs. forecast incident rates with adjustment triggers.

### Notes

- Actuarial study timeline is compressed (Month 1–6 = 2026-11-12 to 2027-04-12); parallel workstreams (technical audit, DG COMP pre-notification, steering governance) must run without blocking.
- Failure to reach consensus on liability model by Month 6 (2027-04-12) cascades to month 12 (2027-10-12) readiness-gate deferral, pushing binding standards to month 24 (2028-10-12) and API exposure to month 36 (2029-10-12).
- Quarterly pool reports (starting Month 6 = 2027-04-12) are essential for carrier confidence; if actual incident rates exceed forecast by >20% within first 12 months, model adjustment and contributor communication are urgent.
- Reserve reinsurance cost (estimated EUR 5–10M if needed) from the EUR 150M force-majeure budget or EUR 220M clearing line; confirm funding source by Month 3 (2027-01-12).
- If Commission mediation is required (Month 5 = 2027-03-12), identify fallback liability designs (e.g., two-tier pool: core carriers + optional reinsurance for smaller operators) immediately.


## 2. Pre-Programme Technical Audit of Carrier Booking Systems and Tier Assignment

40–50% of smaller carriers (8–15 operators) are at high risk of missing the mandatory API exposure milestone (Month 30 = 2029-04-12) due to legacy system constraints. Without a pre-project technical baseline, adapter funding (EUR 240M) is allocated without evidence, and carriers that miss deadlines create corridor fragmentation. This blocks network connectivity and threatens the 40% through-ticket goal.

### Data to Collect

- OSDM API readiness per carrier: existing OSDM implementation status, API maturity level (design, prototype, live), planned completion date
- Real-time inventory capability: event-streaming support (Kafka, RabbitMQ, or custom), transaction consistency across legs, booking confirmation latency (p50, p95, p99 milliseconds)
- Monthly availability: 12-month uptime % per carrier (excluding planned maintenance), outage frequency and duration distribution
- Legacy system dependencies: mainframe, flat-file settlement, custom payment integration; estimated retrofit timeline per system
- Staffing allocation: FTE available per carrier for API integration, testing and operations support through Month 42 (2030-04-12)

### Simulation Steps

- Use OSDM reference test suite (available from UIC or community) to run conformance checks against each carrier's current API implementation (or planned API stub if not yet live); identify API profile compliance gaps
- Simulate multi-leg latency queries: run synthetic three-leg bookings (Paris–Amsterdam–Berlin, Wien–München–Zürich, Madrid–Barcelona–Lyon) through carrier APIs in sequence, measuring end-to-end p50/p95/p99 latency under normal load; model combined availability assuming independent 95% per leg (yields ~86% three-leg availability, below the proposed 99.5% SLA)
- Model carrier availability using publicly available operational data (e.g., CER annual disruption reports, NaBaRo NaBaRo database, national regulator filings) and each carrier's recent outage frequency to estimate achievable 99.5% uptime target by Month 30 (2029-04-12)
- Interview carrier IT leads to estimate retrofit timeline for legacy systems (mainframe APIs, flat-file settlement feeds, custom payment integration); use industry benchmarks (e.g., legacy banking system modernisation studies) to validate estimates

### Expert Validation Steps

- Commission an independent technical audit firm (e.g., Deloitte, Capgemini, or specialist rail IT consultancy) by Month 1 (2026-11-12) to assess all 25+ carriers' systems in-person or remotely; deliver interim readiness signals by Month 1.5 (2026-11-27) and a detailed 25-carrier assessment with per-carrier roadmaps and tier assignments by Month 6 (2027-04-12)
- Engage the EU Agency for Railways and standards-working group to review and validate the audit methodology (test coverage, latency measurement, conformance criteria) by Month 3 (2027-01-12) to ensure audit credibility with carriers
- Present audit results and tier assignments to CER and the steering group by Month 6 (2027-04-12); if >35% of targeted carriers cannot achieve Month 30 (2029-04-12) API exposure, propose revised tier structure (e.g., Tier 1.5 at Month 33 = 2029-07-12, or pilot-only Phase 1 with binding commitment for Month 36 = 2029-10-12) and obtain steering vote

### Responsible Parties

- Independent technical audit firm (Months 1–6 = 2026-11-12 to 2027-04-12)
- EU Agency for Railways and standards-working group (validate methodology and credibility by Month 3 = 2027-01-12)
- Carrier IT leads (respond to audit questionnaires and participate in roadmap discussions)
- Programme Office (publish tier assignments and release adapter funding in tranches against verified performance)

### Assumptions

- **High:** All 25+ targeted carriers cooperate with the audit process, providing system access or detailed questionnaire responses; refusal by >3 carriers stalls the tier assignment.
- **Medium:** OSDM reference test suite is available from UIC and covers sufficient API profiles to assess conformance; if test coverage is <80%, supplementary conformance tests must be developed by Month 3 (2027-01-12).
- **Medium:** Synthetic latency tests using three-leg queries reflect realistic load and carrier endpoint performance; carriers may argue synthetic tests underestimate real-world latency under peak loads (e.g., summer booking surge), requiring pilot validation.
- **High:** Smaller carriers with legacy systems can be retrofitted (mainframe APIs, flat-file feeds, payment integration) within the Tier 2 (Month 36 = 2029-10-12) and Tier 3 (Month 42 = 2030-04-12) timelines; if retrofit complexity exceeds estimates, carriers miss deadlines and corridors fragment.
- **Medium:** Shared adapter modules (EUR 30–50M) can address 60–70% of common legacy patterns; if carriers have unique integration barriers, per-carrier custom adapters (EUR 10–20M each) are required, consuming contingency headroom.

### SMART Validation Objective

By Month 6 (2027-04-12), conduct a detailed technical audit of all 25+ carriers assessing API readiness, real-time latency, availability and legacy system retrofit timelines. Publish tier assignments (Tier 1: Month 30 = 2029-04-12; Tier 2: Month 36 = 2029-10-12; Tier 3: Month 42 = 2030-04-12) with per-carrier roadmaps and identified bottlenecks. Identify the top 3 shared adapter patterns and allocate EUR 30–50M to procure them by Month 12 (2027-10-12). Release subsequent adapter funding (Tier 2, Tier 3) only after independent verification of live API performance (99.5% uptime, p95 latency <2 sec, <1% stale-seat failures).

### Notes

- Audit must account for carriers' varied IT maturity: large operators (SNCF, DB, SBB) likely have OSDM prototypes or live APIs; regional operators have partial APIs; smaller operators have legacy mainframes with limited API capability.
- Latency and availability thresholds (p95 <2 seconds, 99.5% monthly uptime) are proposed and must be confirmed as feasible by Month 3 (2027-01-12) based on audit interim findings; if infeasible for >30% of Tier 2/3 carriers, thresholds must be revised.
- Tier 3 operators (Month 42 = 2030-04-12 deadline) represent 18 months of retrofit and testing time; if audit reveals >6 months of bottleneck per carrier, Tier 3 date slips to Month 48 (2030-10-12) or beyond, fragmenting Phase 2 final-wave TEN-T.
- Shared adapter procurement (Month 12 = 2027-10-12) is a critical supplier-engagement milestone; delays in identifying or procuring modules cascade to Tier 2 and 3 readiness.
- If >35% of carriers remain unready by Month 36 (2029-10-12), trigger emergency adapter acceleration (EUR 150–250M contingency spend) or defer Phase 3 TEN-T extension to Month 60–72 (2031-10-12 to 2032-10-12).


## 3. DG COMP Article 101 TFEU Competition-Law Clearance and Data-Sharing Governance

Competitors sharing real-time inventory, settlement data, and pricing information through shared clearing and availability layers raises novel Article 101 TFEU issues. A post-launch competition challenge could force EUR 50–100M rework and 6–12 months delay, unraveling the entire clearing and availability stack. Early DG COMP comfort (by Month 12 = 2027-10-12) is essential to lock carrier participation and binding-standards design.

### Data to Collect

- Detailed specification of the federated clearing mechanism: netting rules, dispute resolution process, access terms for independent distributors and smaller carriers
- Shared availability layer architecture: who controls the streamed availability shadow, how inventory updates are pooled, what data is exposed to competitors, access-denial criteria
- Through-fare construction doctrine: whether fare-composition rules (sum-of-legs, corridor tariff, or composite bundle) constitute price coordination under Article 101
- Distribution remuneration and commission band: proposed commission rate range, how rates are set and enforced, whether there are mechanisms for discrimination or margin squeezing against independent distributors
- Carrier-funded guarantee pool governance: who controls the pool rules, dispute adjudication, and reserve investment; whether pool governance creates cartel-like coordination on liability pricing

### Simulation Steps

- Document the clearing and data-sharing arrangements as implemented in competing transport sectors (e.g., air-transport IATA clearing, bus-industry bilateral arrangements, electricity market clearing) to identify Article 101 precedents and safe-harbour patterns; use CJEU and General Court case law (e.g., Wouters, Pechstein, Comb. Practices cases) to stress-test the programme's design against known blocking issues
- Build a data-flow diagram showing what commercially sensitive information (fares, inventory, rerouting decisions, settlement positions, on-time performance, contribution weights) passes through each shared layer (availability shadow, clearing, disruption feed, pool monitoring); identify which flows are unavoidable and which could be redesigned to reduce exposure
- Model two alternative governance structures for the shared layers: (A) centralized (one entity controls rules and data access), (B) federated (bilateral arrangements with a netting overlay); compare each against Article 101 Regulation 1/2003 exemption criteria (restrictions are proportionate, not harmful to consumers, do not allow competitors to eliminate competition in a substantial part of the market) and identify which design carries lower legal risk
- Simulate a post-launch Article 101 challenge: if a distributor or smaller carrier claims exclusion or discrimination, what evidence in the governance charter and access logs would defend the programme? Model the cost and timeline of a redesign forced by DG COMP or EU court judgment (estimated EUR 50–100M and 6–12 months)

### Expert Validation Steps

- Engage an external EU competition law specialist (e.g., major law firm with Brussels office: Cleary Gottlieb, Jones Day, White & Case; or specialist rail transport counsel) by Month 1 (2026-11-12) to draft a detailed DG COMP pre-notification memorandum (estimated EUR 300–500K); submit to DG COMP by Month 2 (2026-12-12)
- Engage in formal dialogue with DG COMP directorate (DG COMP/B or /C sector desk) starting Month 2 (2026-12-12); request expedited review and interim guidance by Month 9 (2027-07-12), final guidance by Month 12 (2027-10-12)
- If DG COMP raises Article 101 concerns, work with external counsel to design a clean-team arrangement (independent compliance officer with sole access to sensitive data, firewalls between clearing and competitive functions) and obtain DG COMP approval by Month 14 (2027-12-12), no later than Month 18 (2028-04-12) binding standards
- Retain competition counsel for ongoing monitoring (Months 18–60 = 2028-04-12 to 2031-10-12) to detect early signals of post-launch challenges; prepare contingency redesign documentation (options for bilateral clearing, third-party settlement, or other alternatives) by Month 24 (2028-10-12)

### Responsible Parties

- External EU competition law firm (pre-notification memorandum, dialogue with DG COMP, clean-team protocol design)
- DG COMP (issuance of guidance letter by Month 12 = 2027-10-12)
- Standards-working group (integrate Article 101 safe-harbour conditions into OSDM binding text by Month 18 = 2028-04-12)
- Programme Office and carriers (implement agreed clean-team and data-governance protocols by Month 24 = 2028-10-12)

### Assumptions

- **High:** DG COMP will engage constructively and provide guidance within 9–12 months; if review extends beyond Month 12 (2027-10-12), binding standards slip and Programme timeline compresses by 3–6 months.
- **High:** The federated clearing and shared availability designs can be modified to satisfy Article 101 without material loss of efficiency or carrier participation; if fundamental redesign is required (e.g., abandoning the shared availability shadow in favor of federated-only queries), latency and through-ticket success rates degrade by 10–20% (estimate).
- **Medium:** A clean-team arrangement (independent compliance officer, IT firewalls, data-access logs) is legally and operationally feasible and will satisfy DG COMP; if DG COMP judges the clean-team insufficient, more drastic separation (e.g., separate legal entities for clearing and data layers) may be required.
- **High:** No third-party distributor or smaller carrier launches a post-launch Article 101 challenge; if one does before the programme is commercially proven (Month 36–48 = 2029-10-12 to 2030-10-12), the challenge could succeed, forcing design rework during the critical four-corridor go-live phase.
- **Medium:** The clean-team protocol (if required) can be implemented by Month 14 (2027-12-12) without delaying binding standards (Month 18 = 2028-04-12); if implementation requires >4 months, standards slip by 2–3 months.

### SMART Validation Objective

By Month 12 (2027-10-12), obtain a written guidance letter from DG COMP confirming that the inter-carrier clearing, shared availability layer, through-fare construction and carrier-funded pool design are compatible with Article 101 TFEU, or identifying specific conditions (e.g., clean-team protocol, governance safeguards, access-denial appeal process) required for compatibility. Publish a binding Governance Charter by Month 6 (2027-04-12) specifying non-discriminatory access rules, composition of decision-making bodies, and appeal procedures. Implement agreed clean-team protocol and data-governance safeguards by Month 14 (2027-12-12). Integrate DG COMP guidance into OSDM binding standards by Month 18 (2028-04-12).

### Notes

- Article 101 risk is highest for the shared availability layer and inter-carrier clearing; through-fare construction and commission band face moderate risk depending on negotiation and enforcement mechanisms.
- DG COMP's guidance letter is not binding, but formal comfort provided before standards bind significantly reduces post-launch challenge risk (probability reduction estimated 50–70%).
- If DG COMP's interim feedback (expected Month 9 = 2027-07-12) indicates fundamental concerns, the standards-working group must pivot to alternative designs immediately; delaying redesign past Month 12 (2027-10-12) will cascade to binding-standards slip.
- Clean-team implementation requires appointing an independent compliance officer (role, authority, conflicts policy) and establishing IT firewalls; this is a governance and technical task best completed in parallel with binding-standards development (Months 12–18 = 2027-10-12 to 2028-04-12).
- Retain external counsel through Month 60 (2031-10-12) for ongoing monitoring and contingency rework planning; budget EUR 2–5M for three-year engagement.


## 4. Federated Inter-Carrier Clearing and Settlement Mechanism Design and Reconciliation Platform

The federated clearing layer (EUR 220M investment) is the financial backbone enabling single-payment through-tickets, refund reversals, and commission netting across 25+ carriers and independent distributors. Without a concrete, validated clearing rulebook and reconciliation platform by Month 6 (2027-04-12), carriers cannot model settlement risks and distributors cannot price integration costs. Reconciliation errors >2% will lengthen settlement cycles from the target 5 business days to 15–30 days, deterring distributor participation and threatening the 40% through-ticket goal.

### Data to Collect

- Existing bilateral and sector clearing arrangements: settlement formats used by RSC (GB), Trenitalia–ÖBB bilateral, SBB–partner operators; netting rules, dispute procedures, settlement cycle times
- Carrier financial accounting systems: whether carriers use ISO 20022 XML or legacy formats for revenue reporting; payment processing timelines and bank reconciliation capabilities
- Distributor settlement data requirements: what financial reporting and reconciliation information distributors need to verify carrier shares and commission allocations
- Third-party payment processor capabilities: which processors can support multi-leg transactions, netting reversals, and refund reversals across carriers within a 5-business-day cycle
- Current reconciliation error rates and dispute resolution procedures in existing transport clearing (RSC, airline clearing) to set realistic thresholds for the federated model

### Simulation Steps

- Build a detailed ledger model of a three-leg through-ticket (Paris–Amsterdam–Berlin) showing: passenger payment (EUR 200), carrier A leg share (EUR 60), carrier B leg share (EUR 80), carrier C leg share (EUR 50), distributor commission (3%, EUR 6), clearing transaction fee (0.5%, EUR 1), with refund reversal and stale-seat adjustment scenarios; trace the netting and payout in Excel or a specialized settlement simulator
- Simulate the settlement data flow: passenger books through Distributor X on through-ticket, Distributor X submits transaction to clearing platform by 17:00 UTC T+0, clearing platform matches against carrier submissions (A, B, C each submit leg-level journals), reconciliation flags mismatches (amount variance >0.50%, timing variance >2 business days), escalation procedure triggered if unresolved by end of T+2, payout to Distributor X and carriers scheduled for T+5
- Model the ISO 20022 XML mapping required to standardize journal entries across carriers; identify common data gaps (missing booking reference, conflicting amounts, timestamp variance) and design tolerance bands and automated recovery procedures
- Simulate four reconciliation-error scenarios (missing transaction, duplicate transaction, amount variance EUR 0.50 vs. EUR 5.00, timing variance 1 day vs. 5 days); measure error detection time, manual review effort and payout delay per scenario; compare against the proposed 0.5% error target and EUR 5-business-day settlement SLA

### Expert Validation Steps

- Commission an independent clearing and settlement specialist (e.g., consultancy with fintech or banking clearing expertise: Gartner, EY, or specialized clearing-house operator) by Month 1 (2026-11-12) to review existing RSC, Trenitalia–ÖBB and airline clearing precedents; deliver findings by Month 3 (2027-01-12)
- Establish a dedicated Clearing Design Workstream (reporting to steering group) by Month 1 (2026-11-12) to publish a Federated Clearing Rulebook by Month 6 (2027-04-12) specifying netting model (bilateral/multilateral), journal entry standard (ISO 20022), settlement cycle (5 business days), reconciliation tolerance (amount <0.50%, timing <2 days), and dispute procedure; present three worked examples (Paris–Amsterdam–Berlin, Wien–München–Zürich, Madrid–Barcelona–Lyon)
- Engage payment service providers (e.g., SWIFT, Euroclear, or a fintech settlement platform) by Month 6 (2027-04-12) to validate that the clearing rulebook is technically feasible and that refund reversals and stale-seat adjustments can be processed within the settlement cycle; obtain binding letters of intent by Month 12 (2027-10-12)
- Pilot the federated clearing mechanism on one priority corridor with 500–1,000 transactions (Months 18–24 = 2028-04-12 to 2028-10-12) to validate reconciliation procedures, measure actual error rates and payout times; if error rate exceeds 2%, refine tolerance bands and escalation procedures before rolling out to remaining three corridors

### Responsible Parties

- Independent clearing and settlement specialist (methodology review, existing-system analysis)
- Clearing Design Workstream (rulebook development, worked examples, coordination with carriers and PSPs)
- EU Agency for Railways (review and approval of rulebook by Month 9 = 2027-07-12)
- Payment service providers (technical validation and platform procurement)
- Programme Office (release of EUR 220M clearing budget against verified reconciliation performance; establishment of settlement operations team by Month 24 = 2028-10-12)

### Assumptions

- **High:** Existing clearing precedents (RSC, bilateral arrangements, airline clearing) can be adapted to the federated through-ticket model without fundamental architectural change; if the federated model requires novel netting semantics (e.g., multilateral netting across >5 carriers simultaneously), development time extends beyond Month 6 (2027-04-12).
- **High:** All carriers will submit settlement data in a standardized ISO 20022 XML format by Month 24 (2028-10-12); carriers with legacy financial systems may resist format migration, requiring custom adapters (EUR 10–20M estimate) and extending deployment to Month 36 (2029-10-12).
- **High:** A reconciliation error rate of 0.5% by Month 30 (2029-04-12) is achievable; in reality, federated multi-carrier settlement typically experiences 2–5% error rates initially, declining with operational maturity. If actual rates exceed 1.0% for >2 consecutive months, the proposed penalty regime (5% tranche loss) will trigger carrier suspension, fragmenting the network.
- **Medium:** Payment service providers can support EUR settlement netting and refund reversals within a 5-business-day cycle; if PSP latency constraints force a 10-business-day cycle, cash-flow friction for distributors increases and participation drops by 10–15% (estimate).
- **Medium:** The reconciliation platform (EUR 20–40M) can be procured as a commercial offering (SaaS or managed service); if custom development is required, cost escalates to EUR 50–100M and timeline extends to Month 30–36 (2029-04-12 to 2029-10-12).

### SMART Validation Objective

By Month 6 (2027-04-12), publish a Federated Clearing Rulebook specifying netting model, settlement currency (EUR), journal entry standard (ISO 20022 XML), settlement cycle (5 business days with daily netting), reconciliation tolerance bands (amount <0.50%, timing <2 days), dispute procedure and payout schedule. Include three worked examples showing journal entries, netting and payout per distributor and carrier. Obtain approval from the EU Agency for Railways and steering group. Procure a shared reconciliation platform capable of processing >10,000 transactions/day by Month 24 (2028-10-12). Pilot the clearing mechanism on one priority corridor (500–1,000 transactions) at Months 18–24 (2028-04-12 to 2028-10-12) and achieve <0.5% error rate by Month 30 (2029-04-12).

### Notes

- The clearing rulebook is a policy and technical document; it must be owned by a dedicated workstream (not delegated to a contractor) so governance authority and carrier buy-in are maintained.
- Reconciliation tolerance thresholds (0.5% error, <2 day timing variance) are aggressive for federated multi-carrier settlement; validate against industry benchmarks (RSC, airline clearing) by Month 3 (2027-01-12) and revise if infeasible.
- Refund and stale-seat adjustment procedures are novel in rail clearing; pilot testing (Months 18–24 = 2028-04-12 to 2028-10-12) is essential to validate that these edge cases do not cause settlement delays or disputes.
- Settlement operations team (Clearing and Settlement Operations Lead, 1–2 FTE) must be hired and on-boarded by Month 18 (2028-04-12) to prepare for Month 30 (2029-04-12) live operations.
- If pilot error rate exceeds 1.0% at Month 24 (2028-10-12), escalate to Programme Director and DG MOVE; consider deferring Tier 2 API exposure (Month 36 = 2029-10-12) until clearing is stable.


## 5. Real-Time Availability Layer Architecture, SLA Monitoring and Graceful Degradation

The availability query topology (Decision 5) determines whether distributors can reliably show through-tickets to passengers within acceptable latency. If combined three-leg queries exceed 5 seconds or fail >1% of the time due to carrier outages, passengers will prefer single-operator bookings or competitor platforms. The streamed availability shadow and graceful degradation to scheduled-only are essential to masking carrier outages and maintaining through-ticket attractiveness without centralizing inventory (which carries competition-law risk).

### Data to Collect

- Carrier booking-engine latency and availability baselines: p50, p95, p99 query response times and monthly uptime % per carrier, measured over 12-month rolling window
- Shared event-streaming platform capabilities: can Kafka, RabbitMQ or similar support seat inventory updates from 25+ carriers with <5-second propagation delay and exactly-once or at-least-once delivery guarantees
- Distributed cache feasibility: can a Redis or similar cache hold 24-hour seat snapshots for 100,000+ itineraries (Paris–Amsterdam–Berlin, Wien–München–Zürich, Madrid–Barcelona–Lyon corridors) with stale-data TTL <5 minutes and sub-100ms lookup latency
- Failover and degradation thresholds: at what latency (3 sec? 5 sec?) and availability (99%? 98.5%?) should through-ticket search fall back to scheduled-only offers without real-time seats
- Passenger preference and SLA trade-offs: do passengers accept scheduled-only (no pricing, no seat choice) fallback if real-time is unavailable, or will they abandon through-tickets for single-operator bookings

### Simulation Steps

- Model multi-leg latency: assume each carrier's booking engine operates at p95 latency of 2 seconds (proposed threshold); when a distributor queries three carriers in sequence (Paris, then Amsterdam, then Berlin), combined latency = 6 seconds + network variance (±1 second estimate) = 5–7 seconds total, already exceeding any reasonable SLA for search; model parallel queries (concurrent calls to all three carriers) and show that p95 combined latency depends on the slowest responder, reducing to ~2–3 seconds if each responder meets the SLA
- Simulate availability: if each carrier is 95% available (industry baseline), combined three-leg availability = 0.95^3 = 0.857 (85.7%), below the proposed 99.5% SLA; model the effect of upgrading carriers to 99.5% (combined = 0.995^3 = 0.985, 98.5%, still below 99.5%); show that 99.5% combined requires each carrier to exceed 99.83% (unrealistic without redundancy). Recommend that the SLA target be revised or a cached shadow introduced to mask carrier outages.
- Design the availability shadow cache: distributed Redis nodes hold recent search results (itinerary + prices + seat availability) keyed by origin, destination, date, class; update frequency every 5 minutes from carrier event feeds; expiration policy: if a result is >5 minutes stale, mark as 'stale' in search UI but still display it; if carrier API is unavailable, degrade to scheduled-only (no pricing, no seats) rather than showing expired prices that cause booking failures
- Model graceful degradation: when a carrier endpoint is unavailable >30 seconds, the distributed cache switches search results to scheduled-only for routes involving that carrier; publish a user-facing message ('Real-time seat availability temporarily unavailable; scheduled services are shown below'); measure passenger impact: how many passengers abandon search vs. accept scheduled-only fallback (requires usability testing, Months 12–18 = 2027-10-12 to 2028-04-12)
- Simulate failure scenarios: (1) carrier endpoint down 2 hours during peak booking (summer season); (2) network partition between EU hub and carrier datacenter (60 second lag before failover); (3) event-stream publisher backlog (availability shadow is 2 hours stale); for each scenario, measure: detection time, user-visible fallback, recovery time and payout delay in clearing

### Expert Validation Steps

- Commission a distributed-systems architect and real-time platform specialist by Month 1 (2026-11-12) to validate the streamed availability shadow design against production requirements (sub-100ms cache lookup, <5-minute staleness, graceful degradation to scheduled-only); deliver architecture design by Month 6 (2027-04-12)
- Deploy SLA monitoring synthetic probes by Month 12 (2027-10-12) that query each carrier's booking engine every 5 minutes from geographically distributed locations, measure latency percentiles and uptime, and publish monthly public scoreboard showing p50/p95/p99 latency and availability per carrier; attach automatic escalation: if p95 latency >3 seconds or availability <99% in a month, notify carrier CIO within 24 hours and escalate to steering group if unresolved in 15 business days
- Conduct chaos-engineering tests at Months 18, 30, 42 (2028-04-12, 2029-04-12, 2030-04-12) simulating carrier endpoint failure, network partition and event-stream lag; verify that the distributed cache switches to scheduled-only within 30 seconds and that passengers are informed transparently; validate reconciliation platform recovery (no lost or duplicated transactions) when clearing system resumes operation
- Run live pilots on one priority corridor (Months 12–18 = 2027-10-12 to 2028-04-12) with 500–1,000 passengers; measure stale-seat booking failures (target <1%), graceful-degradation frequency (target <2% of searches fallback to scheduled-only), passenger satisfaction with fallback experience and reroute success rates; publish findings by Month 18 (2028-04-12) and adjust thresholds if needed

### Responsible Parties

- Distributed-systems architect (architecture design and validation)
- Real-time platform team (SLA monitoring proxy, distributed cache deployment by Month 12 = 2027-10-12)
- Carriers (achieve and maintain SLA targets: p95 latency <2 seconds, 99.5% availability)
- Standards-working group (integrate SLA requirements and cache architecture into OSDM binding standards by Month 18 = 2028-04-12)
- Programme Office (publish SLA scorecards, attach funding tranche penalties for SLA misses, trigger chaos-engineering tests)

### Assumptions

- **High:** A p95 latency of <2 seconds per carrier is achievable; legacy booking systems may not meet this target without infrastructure upgrades. If <70% of carriers achieve p95 <2 sec by Month 30 (2029-04-12), the combined three-leg SLA is unachievable and the programme must either (a) accept higher latency and lower through-ticket conversion, or (b) rely more heavily on cached shadow, which increases stale-seat failure risk.
- **High:** A 99.5% combined three-leg availability is achievable with 99.83% per-carrier SLA, which is unrealistic without carrier infrastructure investment or redundancy; the actual achievable combined availability with 99.5% per-carrier SLA is ~98.5% (0.995^3), below the 99.5% target. The SLA target must be revised or passengers must accept scheduled-only fallback for ~1.5% of searches.
- **Medium:** Passengers accept scheduled-only (no real-time pricing, no seat selection) as a fallback for ~1–2% of searches when a carrier is unavailable; if <50% of passengers accept scheduled-only fallback, through-ticket conversion drops by 5–10% (estimate) when fallbacks are frequent.
- **Medium:** A distributed cache (Redis or equivalent) can be procured and operated at EUR 15–25M; if custom development is required, cost escalates and timeline extends beyond Month 12 (2027-10-12).
- **High:** Event-stream ordering and exactly-once delivery can be maintained across 25+ carriers using Kafka-like topology; if carriers experience >1% of events lost or duplicated, the availability shadow becomes unreliable and scheduled-only fallback frequency increases.

### SMART Validation Objective

By Month 6 (2027-04-12), publish a detailed architecture specification for the streamed availability shadow (cache architecture, stale-data TTL, fallback thresholds, event-stream ordering guarantees). By Month 12 (2027-10-12), deploy SLA monitoring synthetic probes and public scoreboard showing p50/p95/p99 latency and monthly availability per carrier. Establish p95 latency <2 seconds and 99.5% availability as binding SLA targets in conformance gate (Decision 6). Attach funding tranches to SLA performance: carriers missing SLA targets for two consecutive months lose 5% of their next funding tranche. Conduct chaos-engineering tests at Months 18, 30, 42 (2028-04-12, 2029-04-12, 2030-04-12) and validate graceful degradation to scheduled-only within 30 seconds. Run live pilots (Months 12–18 = 2027-10-12 to 2028-04-12) achieving <1% stale-seat failure and <2% scheduled-only fallback frequency.

### Notes

- The p95 latency <2 seconds and 99.5% availability SLA targets are ambitious and may require carrier infrastructure investment beyond their private IT budget (EUR 1.5–3.0 billion estimate); confirm feasibility with carriers by Month 3 (2027-01-12) and revise targets if needed.
- SLA monitoring is a critical lever for ensuring through-ticket reliability; public scorecards create transparency and market pressure for carrier compliance, but must be updated monthly and published without delay.
- Graceful degradation to scheduled-only is a safety valve, not a solution; if >5% of searches trigger scheduled-only fallback, passengers will migrate to competitors and the through-ticket value proposition erodes.
- Chaos-engineering tests at Months 18, 30, 42 (2028-04-12, 2029-04-12, 2030-04-12) are essential operational readiness gates; if tests fail (e.g., cache recovery takes >5 minutes, clearing platform loses transactions), remediation is mandatory before proceeding to the next tier or corridor.
- Stale-seat and reconciliation errors are linked: if the availability shadow is too stale (>5 minutes), stale-seat failures cascade to clearing disputes when a passenger attempts to book a seat that was already sold by another distributor. Tolerance bands in reconciliation must account for this edge case.


## 6. Passenger Rights Legal Compliance and Accessibility Conformance Validation

Through-tickets must deliver passenger-rights protection equivalent to or better than single-operator services, or the programme violates Regulation 1371/2007 and exposes the Commission and carriers to enforcement actions and lawsuits. Accessibility (wheelchair spaces, assistance, multilingual information) must be designed into booking and rerouting flows early, not retrofitted post-launch. Complaints handling (target: halved distributor complaints by Month 60 = 2031-10-12) requires a professional staffed operation, not a secondary administrative task, to deliver credible passenger experience and regulatory compliance.

### Data to Collect

- Through-ticket passenger entitlements per EU Regulation 1371/2007: assistance, compensation, refunds, information rights, disability accommodation; comparison with single-carrier entitlements
- Carrier accessibility resource inventory: wheelchair spaces available per service, assistance notice periods per carrier, bicycle spaces, accessibility of stations and vehicles
- Baseline passenger complaints per corridor: complaint volume, categories (booking error, payment, disruption, refund, accessibility, lost luggage), resolution time, appeal outcomes per carrier
- Multilingual user needs: passenger cohort breakdown by first language (EU member-state official languages), reading proficiency levels, sensory accessibility needs (screen reader, captions)
- Existing passenger-rights compliance procedures in single-operator rail services to adapt for through-tickets

### Simulation Steps

- Map through-ticket passenger rights against Regulation 1371/2007 requirements in a compliance matrix: for each right (assistance, compensation, refunds, information, accessibility), specify: (1) what a single-operator passenger gets, (2) what a through-ticket passenger gets under the proposed programme design, (3) any gaps or disadvantages for through-ticket passengers. Highlight discrepancies and design adjustments needed.
- Model accessibility scenarios: a wheelchair-using passenger books Paris–Amsterdam–Berlin through-ticket requiring assistance at station, wheelchair space on each leg, and accessible toilet facilities onboard; trace the atomic confirmation logic (Decision 10: reject itinerary if any leg lacks capacity) and show how many itineraries are rejected due to accessibility gaps; estimate accessibility availability under the proposed 80% wheelchair access and 90% assistance thresholds
- Simulate complaints handling: baseline complaint volume (estimated 100–200 per corridor annually, sourced from CER data); segment by category (15% booking/payment, 30% disruption/rerouting, 20% refund, 20% accessibility, 15% other); model resolution time (target: 30 days for standard, 15 days for priority accessibility cases); estimate staffing (target: 40–60 FTE for complaints team serving four corridors)
- Usability test scenarios with diverse passenger cohorts: (1) non-native speaker (test multilingual error messages, accessibility of help text at B1 CEFR reading level); (2) visually impaired (test screen-reader compatibility, high-contrast mode); (3) mobility-impaired (test assistance request flow, confirmation feedback); (4) elderly (test font size, clickability, layout clarity). Measure task completion rate and time-on-task for each cohort.

### Expert Validation Steps

- Commission an independent legal review by Month 1 (2026-11-12) from rail-passenger-rights counsel (e.g., European transport law specialists at university law clinics or transport law practices) to assess through-ticket design against Regulation 1371/2007 requirements; deliver opinion by Month 6 (2027-04-12) identifying any compliance gaps or required design adjustments
- Engage disability-rights organisations (European Disability Forum (EDF), European Blind Union (EBU), Disability Equality Europe) and BEUC (consumer) as observers in a Passenger Rights Oversight Board starting Month 6 (2027-04-12); conduct quarterly reviews of compliance manual, accessibility audit findings, and complaints data
- Conduct accessibility usability testing with 50+ passengers (≥15 with mobility/sensory disabilities, ≥15 non-native speakers) on wireframes of booking, assistance request and complaints flows at Months 4, 8, 14 (2027-02-12, 2027-06-12, 2027-12-12); iterate designs and test again before binding standards (Month 18 = 2028-04-12)
- Commission an independent accessibility audit of all four priority corridors (Month 6 = 2027-04-12) covering station and vehicle accessibility, staff training on PRM assistance, rolling-stock capacity; map gaps and develop carrier-specific remediation plans; make corridor go-live (Month 48 = 2030-10-12) conditional on meeting minimum accessibility thresholds (proposed: 80% wheelchair access, 90% assistance within 4 hours' notice)
- Obtain formal approval from the EU Agency for Railways of the Passenger Rights Compliance Manual (Month 9 = 2027-07-12) and the Accessibility Audit (Month 9 = 2027-07-12); make these documents binding operational requirements for all carriers and the clearing entity

### Responsible Parties

- Independent passenger-rights legal counsel (Month 1 = 2026-11-12 to Month 6 = 2027-04-12)
- Passenger Rights Lead role (develop compliance manual, lead accessibility audit, establish complaints handling)
- EU Agency for Railways (approve compliance manual and accessibility audit)
- Disability-rights and consumer organisations (quarterly oversight board participation, usability testing)
- Carriers (implement accessibility improvements, staff training, compliance certification)
- Clearing entity and public distributor concession (support complaints handling and accessibility features)

### Assumptions

- **High:** Through-ticket design can meet or exceed Regulation 1371/2007 entitlements without material cost escalation or schedule slip; if design gaps require significant rework (e.g., extending assistance notice period from 24 hours to 72 hours across all carriers), programme schedule slips 2–3 months.
- **High:** Accessibility thresholds (80% wheelchair access, 90% assistance within 4 hours) are achievable by Month 40 (2030-02-12) for the four priority corridors; carriers report that rolling-stock retrofits and staff training require 18–24 months. If <70% of services meet thresholds by Month 40 (2030-02-12), atomic confirmation (Decision 10) will reject 15–25% of itineraries, reducing through-ticket availability and passenger choice.
- **Medium:** Complaints handling can be operationalised with 40–60 FTE and EUR 25–40M budget allocation; if complaints volume is 2–3x higher than baseline estimate (due to new system complexity, transition period friction), staffing scales to 80–100 FTE and cost escalates to EUR 50–75M, exceeding the EUR 100M consumer-rollout budget.
- **Medium:** Disability-rights and consumer organisations will participate constructively in co-design and oversight starting Month 6 (2027-04-12); if organisations withhold endorsement due to design gaps or perceived tokenism, they may publicly oppose programme launch, triggering political and regulatory scrutiny.
- **Low:** Multilingual usability testing with 50+ passengers is feasible within budget (EUR 50–100K estimate) and will yield actionable design revisions; if testing reveals widespread comprehension gaps in error messages or assistance flows, additional iteration (Month 14–18 = 2027-12-12 to 2028-04-12) may be required, compressing the final standards approval cycle.

### SMART Validation Objective

By Month 6 (2027-04-12), obtain independent legal opinion confirming that through-ticket passenger rights meet or exceed Regulation 1371/2007 entitlements; identify any gaps and publish required design adjustments. By Month 9 (2027-07-12), publish a Passenger Rights Compliance Manual approved by the EU Agency for Railways and an Accessibility Audit of all four priority corridors with carrier-specific remediation plans. Establish accessibility thresholds (80% wheelchair access, 90% assistance within 4 hours) as conditions of corridor go-live (Month 48 = 2030-10-12). Conduct usability testing with 50+ passengers (≥15 disabled, ≥15 non-native speakers) at Months 4, 8, 14 (2027-02-12, 2027-06-12, 2027-12-12) and achieve >85% task completion rate for all cohorts. Establish a Passenger Rights Oversight Board (Agency, disability-rights and consumer organisations) meeting quarterly starting Month 6 (2027-04-12) to audit compliance and complaints trends.

### Notes

- The Passenger Rights Compliance Manual is a binding operational document; all carriers must certify staff training to its procedures as a precondition of conformance (Decision 6) by Month 30 (2029-04-12).
- Atomic confirmation of accessibility and bicycle spaces (Decision 10) will visibly reduce through-ticket availability if carriers lack capacity; expect 10–20% itinerary rejection (estimate) initially. Design must include fallback options (best-effort booking with compensation, manual assistance by staff) or passengers will prefer single-operator bookings.
- Complaints handling is a critical service-level metric; if resolution time exceeds 30 days for 30%+ of cases, the target of 'halved complaints by Month 60 (2031-10-12)' is unachievable. Staffing and systems must scale dynamically.
- Multilingual information design requires professional translation and localization (not machine translation); budget EUR 50–100K for professional translation of key passenger information into at least 18 EU official languages and testing at B1 CEFR reading level.
- Accessibility audit (Month 6 = 2027-04-12) must feed into corridor-specific remediation plans with cost, timeline and responsibility assigned to each carrier. Make audit results public (anonymised per GDPR) to create transparency and market pressure for compliance.

## Summary

This project plan establishes six critical data-collection and validation workstreams for an EU cross-border rail through-ticketing programme targeting 40% of cross-border journeys within EUR 1.5 billion public budget by Month 60 (2031-10-12). The six most sensitive areas—carrier liability pricing (high sensitivity: determines participation), technical system integration (high sensitivity: determines schedule feasibility), competition-law clearance (high sensitivity: determines clearing design viability), clearing and settlement mechanism (high sensitivity: determines financial backbone), real-time availability architecture (high sensitivity: determines search reliability), and passenger-rights compliance (high sensitivity: determines regulatory risk)—must all proceed in parallel Months 0–6 (2026-10-12 to 2027-04-12) to unblock the Month 6 (2027-04-12) readiness gate. The most urgent immediate actions are: (1) Commission the actuarial study by Month 1 (2026-11-12) and deliver interim carrier feedback by Month 4 (2027-02-12) to obtain carrier sign-off; (2) conduct the technical audit by Month 2 (2026-12-12) and publish tier assignments by Month 6 (2027-04-12); (3) file DG COMP pre-notification by Month 2 (2026-12-12) and secure guidance by Month 12 (2027-10-12); (4) establish steering governance with 75% supermajority voting by Month 1 (2026-11-12) and hold binding votes on Decisions 1–5 by Month 6 (2027-04-12); (5) rebase the EUR 1.5 billion budget with variance triggers (EUR 100M, EUR 200M, EUR 300M) and publish monthly cash-flow forecasts starting Month 1 (2026-11-12); (6) commission passenger-rights legal review by Month 1 (2026-11-12) and obtain Agency approval of compliance manual by Month 9 (2027-07-12). If any of these workstreams slip past their gate (Month 4 = 2027-02-12 for liability, Month 6 = 2027-04-12 for audit and steering votes, Month 12 = 2027-10-12 for DG COMP guidance), the binding-standards milestone (Month 18 = 2028-04-12) is at risk and the entire timeline compresses or defers to Month 12 (2027-10-12) contingency.