
## Documents to Create

### 1. Project Charter

**ID:** 7d4cb30a-54ae-41ca-bd17-9f8a314f0623

**Description:** Foundational governance document establishing programme authority, scope, objectives (40% through-ticket share, halved complaints by Month 60 = 2031-10-12), stakeholders, success criteria, and decision-making structure. Defines Programme Director accountability, steering group composition (75% supermajority rule) and escalation paths to Commission. Primary audience: EU institutions, carriers, distributors, national regulators.

**Responsible Role Type:** Programme Director

**Primary Template:** PMI Project Charter Template

**Secondary Template:** EU institutional project charter (sample from DG MOVE prior programmes)

**Steps:**

- Workshop with DG MOVE leadership and CER to define charter scope and success criteria by Month 0.5 (2026-10-27)
- Draft charter covering authority, stakeholder roles, decision rights and escalation by Month 1 (2026-11-12)
- Obtain signed approval from DG MOVE Director-General, EU Agency for Railways Director and CER President by Month 1.5 (2026-11-27)
- Publish and distribute to all 25+ carriers and steering group members; archive with Commission

**Approval Authorities:** DG MOVE Director-General, EU Agency for Railways Director, CER President, European Commission Transport Commissioner (if escalated for mediation)

### 2. Carrier Liability and Rights Backstop Model (Actuarial Specification)

**ID:** a5455000-dd85-4e1c-a8df-38ac7a07c015

**Description:** Technical actuarial specification defining the carrier-funded mutual guarantee pool: per-incident caps, co-insurance thresholds, contribution-weighting formula tied to trailing on-time performance, reserve adequacy analysis and quarterly pool-monitoring procedures. Based on 24-month historical missed-connection and rerouting-cost data from at least 5 major carriers. Output: binding liability terms that carriers sign off to expose inventory. Primary audience: CER, 25+ national operators, DG MOVE, Finance lead.

**Responsible Role Type:** Actuary / Carrier Liability Specialist

**Primary Template:** Actuarial valuation report (Insurance Directorate standard)

**Secondary Template:** Financial model template (Excel sensitivity analysis, Monte Carlo simulation for loss clustering)

**Steps:**

- Engage independent actuarial firm by Month 1 (2026-11-12) with 90-day delivery target
- Collect 24-month missed-connection, rerouting-cost and incident-clustering data from SNCF, DB, SBB, Renfe, ÖBB and one smaller operator by Month 1.5 (2026-11-27)
- Analyse data to derive baseline incident frequencies, cost distributions and carrier-specific risk profiles by Month 2 (2026-12-12)
- Develop three sensitivity scenarios (conservative, base, aggressive) for cap levels (EUR 250-2,000 per passenger) and co-insurance triggers (EUR 20M-100M annual draw) by Month 2.5 (2026-12-27)
- Produce final recommendations with worked examples for three carrier profiles (large, regional, small) and confidence intervals by Month 3 (2027-01-12)
- Present model to CER and 10+ major carriers for written feedback by Month 4 (2027-02-12); obtain binding sign-off from at least 8 major carriers and CER by Month 4 (2027-02-12)
- Establish quarterly pool-monitoring process (publish incident rates, contribution adjustments, drawdowns within 15 business days of quarter-end) starting Month 6 (2027-04-12)
- Revalidate model quarterly; adjust parameters if actual rates diverge >20% from forecast

**Approval Authorities:** CER, at least 8 major carriers (binding written letters of intent), Programme Director, DG MOVE Commissioner

### 3. Inter-Carrier Clearing and Settlement Rulebook (Federated Netting Architecture)

**ID:** ddb801e9-c11f-4ed8-8d22-311cd3e64a08

**Description:** Definitive specification of the federated clearing layer: multilateral netting model (bilateral, multilateral, or hybrid per corridor), settlement currency (EUR), reconciliation cycle (5 business days), journal entry standard (ISO 20022 XML mapping), dispute escalation procedure, penalty regime and payout schedule. Includes worked examples of three-leg through-tickets showing revenue allocation and carrier payouts. Resolves critical ambiguities: who receives the passenger payment, how positions are netted per leg and per distributor, and how disputes over carrier share are arbitrated. Primary audience: carriers' finance teams, clearing specialist, competition-law counsel, DG COMP.

**Responsible Role Type:** Clearing and Settlement Systems Architect

**Primary Template:** Banking/payment system settlement specification (ISO 20022 messaging standard)

**Secondary Template:** Rail Settlement Plan (RSP) clearing rulebook (GB precedent, adapted for EU federated model)

**Steps:**

- Establish dedicated Clearing Design Workstream by Month 1 (2026-11-12) reporting to steering group
- Define netting model (bilateral, multilateral, or hybrid) and prepare position papers on trade-offs (control vs. complexity, bilateral familiarity vs. multilateral efficiency) by Month 2 (2026-12-12)
- Specify settlement data format (ISO 20022 XML) with full journal entry mapping, per-transaction fields and required metadata by Month 3 (2027-01-12)
- Model worked examples (Paris-Amsterdam-Berlin, Wien-München-Zürich, Madrid-Barcelona-Lyon three-leg itineraries) showing commission splits, refund reversals and carrier payouts by Month 4 (2027-02-12)
- Workshop with carriers' finance leads and the clearing architect to validate netting logic and payout timing by Month 5 (2027-03-12)
- Publish final Rulebook with all appendices (reconciliation tolerance bands, dispute escalation, penalty schedule, payout SLAs) by Month 6 (2027-04-12)
- Submit to DG COMP as part of binding standards by Month 18 (2028-04-12); obtain Agency approval by Month 12 (2027-10-12)

**Approval Authorities:** Clearing Design Workstream (carriers + Programme Office), Programme Director, EU Agency for Railways, DG COMP (for competition-law review)

### 4. OSDM Binding Standards Specification (Federated Through-Ticketing Profile)

**ID:** 23f8ef58-1a31-4d53-93d7-8f0cb4b772e6

**Description:** Canonical OSDM version pinned by delegated act specifying all APIs, data structures and conformance rules required for federated through-ticketing across the four priority corridors. Includes profiles for availability query, booking, ticketing, refunds, accessibility metadata (wheelchair, assistance, bicycle spaces), multilingual support (≥18 EU languages), settlement data submission, ticket validation (barcode/credential format) and disruption event notification. Incorporates competition-law and GDPR constraints identified in binding standards workstream. Primary audience: carriers' CIOs, distributors, conformance testers, EU institutions.

**Responsible Role Type:** Standards & Technical Specification Custodian (at the EU Agency for Railways)

**Primary Template:** UIC OSDM Specification (reference implementation, versioned)

**Secondary Template:** W3C/OASIS API specification template (OpenAPI 3.0 or similar)

**Steps:**

- Commission standards writing group by Month 1 (2026-11-12) comprising OSDM community, 3-4 major carriers, 2 distributors and Agency technical staff; meet biweekly
- Consolidate binding standards requirements from all five critical decisions (liability, clearing, public distributor, funding ladder, availability topology) into one specification by Month 9 (2027-07-12)
- Publish option papers on critical API design points (federated vs. central inventory, netting engine format, refund reversal semantics) by Month 6 (2027-04-12); hold written consultation among carriers by Month 9 (2027-07-12)
- Draft OSDM binding-standards profile incorporating: availability query (federated, with shadow caching), booking (carrier authority), settlement data submission (ISO 20022), ticket validation (credential format), accessibility metadata, multilingual payloads, disruption events and refund reversal; include conformance test suite by Month 15 (2028-01-12)
- Obtain DG COMP clearance and competition-law counsel review by Month 12 (2027-10-12); incorporate any required clean-team protocols or data-minimisation constraints by Month 14 (2027-12-12)
- Finalise binding-standards text and submit to Commission for delegated-act drafting by Month 18 (2028-04-12); target publication in Official Journal by Month 20 (2028-06-12)

**Approval Authorities:** EU Agency for Railways (Standards Custodian), DG MOVE, DG COMP, European Commission (delegated act), CER (stakeholder consultation)

### 5. Technical Audit and Carrier Conformance Tier Assignment Report

**ID:** 35471efb-e283-4507-bde2-7a6b06fc740f

**Description:** Independent assessment of all 25+ participating carriers' booking-system readiness against binding standards, published with tier assignments (Tier 1: Month 30 = 2029-04-12; Tier 2: Month 36 = 2029-10-12; Tier 3: Month 42 = 2030-04-12) and per-carrier integration roadmaps. Covers API build effort, event-streaming capability, latency (p95 seconds current state), availability (12-month %), legacy-system dependencies, staffing availability and estimated adapter cost per operator. Identifies bottlenecks (mainframe retrofit, payment-processor integration) and recommends shared-adapter modules. Output: basis for adapter funding allocation and conformance milestones. Primary audience: carriers, Programme Office, finance lead.

**Responsible Role Type:** Carrier Integration & Technical Onboarding Manager

**Primary Template:** Technical due diligence assessment template (system architecture audit)

**Secondary Template:** Capacity and constraint analysis (IT resource planning template)

**Steps:**

- Tender independent audit firm by Month 0.5 (2026-10-27); award by Month 1 (2026-11-12)
- Send audit questionnaire to all 25+ carriers by Month 1 (2026-11-12) covering: current API state, event-streaming capability, latency profiles, annual uptime %, legacy system details, staff FTE available
- Conduct on-site system assessments (30+ days across four EU hubs) Months 1-2 (2026-11-12 to 2026-12-12); validate questionnaire responses
- Analyse integration effort per carrier using established patterns (mainframe retrofit typically 9-15 months for smaller operators, 6-9 months for modern systems) by Month 2 (2026-12-12)
- Publish draft tier assignments and per-carrier roadmaps by Month 3 (2027-01-12); circulate for carrier comment by Month 4 (2027-02-12)
- Finalise tier assignment (Tier 1 = 12+ carriers with <12 months integration remaining; Tier 2 = 6-10 carriers with 12-18 months; Tier 3 = remaining) by Month 6 (2027-04-12)
- Publish final audit report with all roadmaps, bottleneck assessments and shared-adapter recommendations; submit to steering group and Programme Director

**Approval Authorities:** Audit firm (technical opinion), Carrier Integration Manager, Programme Director, steering group (acceptance of tier assignments)

### 6. Shared Adapter Modules and Integration Toolkit

**ID:** 62aee1e3-6247-40e8-9d6b-2f4b0896436a

**Description:** Open-source or vendor-supplied reference implementations of common legacy-system patterns (mainframe inventory integration, flat-file settlement feed, legacy payment processing) that Tier 2 and Tier 3 carriers can reuse or adapt, reducing integration cost by 30-40% (estimate) and accelerating conformance timelines. Includes test data, API stubs, reconciliation scripts, troubleshooting guides and example carrier implementations. Procured or developed Month 6-12 (2027-04-12 to 2027-10-12), costing EUR 30-50M (estimate). Output: accelerated conformance for smaller carriers. Primary audience: carriers' IT teams, system integrators, conformance auditors.

**Responsible Role Type:** Carrier Integration & Technical Onboarding Manager

**Primary Template:** Open-source software reference implementation (GitHub or similar repository)

**Secondary Template:** Integration testing toolkit (Docker containers, test scripts, CI/CD pipeline)

**Steps:**

- Analyse audit results (Month 2 = 2026-12-12) to identify top 2-3 legacy-system patterns (e.g., mainframe Cobol inventory, flat-file CSV settlement, legacy payment gateway integration)
- Solicit bids from system integrators to build reusable adapter modules for each pattern by Month 4 (2027-02-12); evaluate on cost, code quality and reusability by Month 5 (2027-03-12)
- Commission adapter development by Month 6 (2027-04-12); set delivery target Month 12 (2027-10-12)
- Publish first adapter module (e.g., mainframe inventory) by Month 10 (2027-08-12) as beta; gather feedback from first 2-3 adopter carriers
- Finalise toolkit (adapters + test data + scripts) by Month 12 (2027-10-12); publish on open-source repository with MIT or EU-compatible license
- Provide support (email, biweekly office hours) to Tier 2 carriers integrating adapters Months 12-36 (2027-10-12 to 2029-10-12)
- Maintain toolkit with bug fixes and performance updates throughout Phase 2

**Approval Authorities:** Carrier Integration Manager, Programme Director, CER (stakeholder feedback on toolkit usability)

### 7. Real-Time Availability Shadow and SLA Monitoring Architecture Specification

**ID:** 1e55b9b5-5591-4843-b59e-9ca647e462d7

**Description:** Technical specification of the streamed availability shadow (cached search layer, event-driven updates, stale-data time-to-live, fallback to scheduled-only offers) and the SLA monitoring proxy (synthetic queries every 5 minutes, p50/p95/p99 latency tracking, uptime measurement, stale-seat error rate). Includes failure-mode analysis (carrier endpoint down, network partition, event-feed lag >60 seconds) and graceful degradation logic. Specifies monitoring infrastructure (Prometheus/Datadog), alerting rules (if p95 latency >3 seconds, notify carrier CIO within 24 hours), and public-facing SLA scoreboard. Output: baseline for real-time architecture validation and SLA enforcement. Primary audience: carriers' CIOs, real-time systems engineer, Programme Office.

**Responsible Role Type:** Real-Time Data Layer & Availability Platform Engineer

**Primary Template:** Distributed systems architecture specification (CQRS pattern, event sourcing)

**Secondary Template:** Observability and SLA monitoring specification (Prometheus/Grafana template)

**Steps:**

- Engage a distributed-systems expert by Month 1 (2026-11-12) to workshop shadow architecture and caching strategy with carriers' architects
- Draft detailed specification (event schema, cache TTL, ordered delivery guarantees, fallback thresholds) by Month 3 (2027-01-12)
- Conduct validation workshop with 5-6 carrier CIOs and the real-time engineer by Month 3.5 (2027-01-27) to confirm feasibility on legacy systems
- Specify SLA targets: p95 latency <2 seconds, uptime 99.5%, stale-seat errors <1% by Month 4 (2027-02-12)
- Define alerting rules and escalation procedures (notification within 24 hours if target missed, remediation plan within 10 business days) by Month 5 (2027-03-12)
- Finalise specification incorporating DG COMP competition-law and GDPR data-minimisation constraints by Month 6 (2027-04-12)
- Procure SLA monitoring tooling (Prometheus, Grafana, alerting system) by Month 6 (2027-04-12); deploy proxy by Month 12 (2027-10-12)
- Publish SLA scoreboard monthly from Month 12 (2027-10-12) onwards, showing all carriers' latency and availability

**Approval Authorities:** Real-Time Systems Engineer, Standards Custodian, Programme Director, DG COMP (data minimisation review)

### 8. Competition Law Pre-Notification Memorandum and Article 101 TFEU Safe-Harbour Argument

**ID:** b05e4a09-46f7-47ac-95f9-eacfcf158f44

**Description:** Comprehensive legal memorandum submitted to DG COMP (pre-notification under Regulation 1/2003) describing all aspects of the inter-carrier clearing mechanism, shared availability data layer, through-fare construction, distribution remuneration band and carrier-funded guarantee pool from an Article 101 TFEU perspective. Demonstrates non-discriminatory access, proportionality of restrictions and pro-competitive benefits (lower consumer fares, improved journey connectivity). Identifies required clean-team protocols, data-access controls and governance safeguards to satisfy competition-law scrutiny. Requests formal DG COMP guidance letter confirming compatibility or identifying required modifications. Primary audience: DG COMP, Programme Director, Competition Law Counsel, carriers.

**Responsible Role Type:** Competition Law & Regulatory Affairs Counsel

**Primary Template:** EU competition-law pre-notification memorandum (format per Regulation 1/2003)

**Secondary Template:** Article 101 TFEU exemption argument template (using established precedents in transport and digital markets)

**Steps:**

- Engage external EU competition counsel by Month 1 (2026-11-12)
- Gather technical specifications from clearing architect, standards custodian and real-time engineer Months 1-2 (2026-11-12 to 2026-12-12) describing shared mechanisms in concrete detail (data flows, participant roles, access rules)
- Draft memorandum addressing: (1) notification of the clearing and data-sharing arrangements as potentially restrictive practices; (2) demonstration that each arrangement is necessary for through-ticketing and proportionate; (3) definition of non-discriminatory access criteria; (4) clean-team protocols isolating competitive strategy from clearing function; (5) public-authority oversight (Agency role) as safeguard by Month 2 (2026-12-12)
- Circulate draft to Programme Director and DG MOVE legal counsel for review by Month 2.5 (2026-12-27)
- File formal pre-notification with DG COMP covering letter and signed memorandum by Month 2 (2026-12-12) end of week
- Attend initial DG COMP briefing meeting (approximately Month 3-4 = 2027-01-12 to 2027-02-12) to respond to questions and flag urgent clarifications needed
- Obtain formal DG COMP guidance letter confirming safe-harbour or identifying required design changes by Month 9-10 (2027-07-12 to 2027-08-12)
- If guidance identifies concerns, revise memorandum and designs (clean-team protocol, governance safeguards) and resubmit by Month 12 (2027-10-12)
- Obtain final DG COMP approval of any clean-team protocols or safeguards by Month 14 (2027-12-12)

**Approval Authorities:** DG COMP (formal guidance letter), DG MOVE (substantive review), Programme Director (sign-off on safe-harbour argument)

### 9. Passenger Rights Compliance Manual and Regulation 1371/2007 Legal Opinion

**ID:** 66be3b09-2d41-481b-8d22-a529c38af236

**Description:** Comprehensive operational manual and legal opinion ensuring that through-ticket passengers retain rights equivalent to or superior to single-carrier passengers under EU Regulation 1371/2007 (railway passengers' rights). Covers assistance, rerouting, compensation, refunds, information provision, complaint handling and accessibility obligations for each participating entity (carriers, clearing layer, public distributor, independent distributors). Includes step-by-step procedures for handling missed connections, force-majeure claims, passenger assistance requests and disability accommodations. Based on independent legal review by rail-law specialist. Output: binding compliance requirement for all parties. Primary audience: carriers, distributors, the clearing entity, EU Agency for Railways, national regulators.

**Responsible Role Type:** Passenger Rights, Accessibility & Consumer Protection Lead

**Primary Template:** Legal opinion (from an EU rail-law specialist)

**Secondary Template:** Operations manual template (step-by-step procedures per role)

**Steps:**

- Commission independent legal review (from a specialist in EU passenger-rights regulation) by Month 1 (2026-11-12)
- Provide reviewer with: binding standards drafts, liability model, clearing rulebook and public distributor specification (as they emerge Months 3-6 = 2027-01-12 to 2027-04-12) for gaps analysis against Regulation 1371/2007
- Reviewer publishes preliminary opinion on any gaps (compensation below single-carrier levels, refund delays not justified, accessibility not addressed) by Month 3 (2027-01-12); confirm by Month 6 (2027-04-12)
- If gaps are identified, revise liability model and clearing rulebook (Decisions 1, 2) by Month 9 (2027-07-12) to close them
- Develop compliance manual specifying: who (carrier, clearing entity, distributor) is responsible for each right (assistance, compensation, information) at each journey stage (booking, travel, disruption, refund) by Month 6 (2027-04-12)
- Publish worked examples of compliance scenarios (missed connection with compensation owed, passenger with mobility needs requesting assistance, refund reversal across carriers) by Month 9 (2027-07-12)
- Submit both legal opinion and manual to EU Agency for Railways for formal approval by Month 9 (2027-07-12); obtain written approval by Month 9 (2027-07-12)
- Publish manual as a binding operational requirement; require all carriers and distributors to certify staff training by Month 30 (2029-04-12)

**Approval Authorities:** Independent legal reviewer (legal opinion), EU Agency for Railways (compliance manual approval), carriers and distributors (acceptance and staff training certification)

### 10. Public Reference Distributor Concession Business Case and Competitive Tender

**ID:** dae155d6-e3e4-403e-a043-47007dcc5460

**Description:** Detailed financial and operational business case for the last-resort distributor concession (EUR 300M envelope), specifying: platform set-up costs (estimated EUR 30-50M, cap EUR 50M ±20%), operating-subsidy model (fixed percentage of through-ticket revenue or capped annual amount, proposed EUR 12M/year maximum), volume forecasts (conservative, base, aggressive), clawback and penalty clauses (subsidy review if volume <60% forecast, clawback if volume >20% forecast), performance-bond requirements (25% of annual subsidy) and contract-term length (5 years, extendable to 7 only by Commission decision). Includes competitive tender RFQ with two-stage evaluation (technical requirements and financial viability). Output: competitive selection of concessionaire, fixed cost control, service-level commitments for passenger accessibility and complaint handling. Primary audience: concession manager, finance lead, steering group, potential bidders.

**Responsible Role Type:** Public Reference Distributor Concession Manager

**Primary Template:** Public concession business case (EU public procurement template)

**Secondary Template:** Competitive tender RFQ (two-stage technical and financial evaluation)

**Steps:**

- Commission independent business-case consultant by Month 1 (2026-11-12); set delivery Month 9 (2027-07-12)
- Conduct market research (biweekly benchmarking with Trainline, Omio, other distributors) Months 1-6 (2026-11-12 to 2027-04-12) to establish realistic platform costs and subsidy requirements
- Model three volume scenarios (conservative 5% of total rail bookings, base 8%, aggressive 12%) and corresponding subsidy draw Months 4-6 (2027-02-12 to 2027-04-12)
- Publish draft business case by Month 6 (2027-04-12); circulate for steering-group comment by Month 8 (2027-06-12)
- Resolve open decision on concession envelope split (set-up vs. service) by Month 9 (2027-07-12); lock cost allocations
- Publish final business case and concession terms (subsidy cap EUR 12M/year, clawback and review triggers, performance-bond requirement, SLA for multilingual support and complaint resolution <15 business days) by Month 9 (2027-07-12)
- Draft and publish competitive RFQ with two evaluation stages (Stage 1: technical capability, passenger experience design, accessibility and multilingual support; Stage 2: financial bid) by Month 10 (2027-08-12)
- Issue RFQ publicly by Month 12 (2027-10-12); accept bids for 8 weeks; conduct evaluation Months 14-16 (2027-12-12 to 2028-02-12); award by Month 18 (2028-04-12)

**Approval Authorities:** Finance lead, steering group (business case approval), Commission procurement directorate (RFQ compliance), Programme Director (concession award)

### 11. Risk Register and Mitigation Plan

**ID:** 1cf3e242-1219-46e5-a228-8e182514a07b

**Description:** Comprehensive risk register documenting all identified risks (regulatory slip, carrier refusal, legacy-system latency, stakeholder deadlock, pool overruns, competition-law challenge, accessibility compliance, etc.) with likelihood, severity, mitigation strategies and trigger-based contingency actions. Includes 20 risks from the pre-project assumptions, with residual-risk assessment post-mitigation. Updated quarterly Months 6, 12, 18, 24, 30, 36, 42, 48, 60 (2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12, 2029-04-12, 2029-10-12, 2030-04-12, 2030-10-12, 2031-10-12). Primary audience: Programme Director, steering group, DG MOVE, carriers.

**Responsible Role Type:** Programme Director (with support from Financial Risk Manager and Competition Law Counsel)

**Primary Template:** Project risk register template (ISO 31000 risk management standard)

**Secondary Template:** Programme-level risk dashboard (Jira, Asana, or similar)

**Steps:**

- Compile initial risk register (20 risks from pre-project assumptions) by Month 1 (2026-11-12)
- Assess each risk: likelihood (Low/Medium/High), severity (Low/Medium/High), ownership, mitigation lead and residual-risk post-mitigation by Month 2 (2026-12-12)
- Establish risk-mitigation workstreams with assigned owners: actuarial study (Month 1 = 2026-11-12 start, Month 3 = 2027-01-12 delivery), technical audit (Month 1 = 2026-11-12 start, Month 6 = 2027-04-12 delivery), DG COMP pre-notification (Month 2 = 2026-12-12 filing), steering governance (Month 1 = 2026-11-12 start, Month 6 = 2027-04-12 binding votes), budget rebaselining (Month 6 = 2027-04-12 start), etc.
- Publish risk register and mitigation roadmap to steering group by Month 3 (2027-01-12)
- Track mitigation progress monthly; update risk register quarterly (Months 6, 12, 18, 24, 30, 36, 42, 48, 60 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12, 2029-04-12, 2029-10-12, 2030-04-12, 2030-10-12, 2031-10-12)
- Escalate any risk where likelihood or severity changes from Medium/High to High, or where mitigation is failing, to Programme Director and steering group within 5 business days
- At each major milestone (Months 6, 18, 30, 48, 60 = 2027-04-12, 2028-04-12, 2029-04-12, 2030-10-12, 2031-10-12), conduct risk-rating review and adjust mitigation intensity or contingency allocations

**Approval Authorities:** Programme Director, steering group (quarterly risk review)

### 12. Monthly Cash-Flow Forecast and Budget Variance Report

**ID:** 9ca871e8-9990-429b-98f6-5ad4900f513d

**Description:** Live monthly cash-flow forecast tracking committed, invoiced and accrued spend against EUR 1,500M budget cap across all nine budget lines (standards EUR 80M, clearing EUR 220M, adapters EUR 240M, real-time layer EUR 50M, concession EUR 300M, capacity building EUR 200M, consumer rollout EUR 100M, programme management EUR 75M, force-majeure reserve EUR 150M, headroom EUR 85M). Shows cumulative variance, triggers for scope reduction (EUR 100M/200M/300M), and quarterly rebaselining. Updated by 10th of each month and presented to steering group biweekly. Output: early warning of budget risk and automated decision triggers for scope cuts. Primary audience: Finance lead, Programme Director, steering group, DG MOVE Controller, European Court of Auditors.

**Responsible Role Type:** Financial Risk and Budget Assurance Manager

**Primary Template:** Programme-level financial tracking spreadsheet (Excel or Tableau)

**Secondary Template:** Variance analysis and trigger-action framework (stored in financial system of record)

**Steps:**

- Set up detailed budget baseline with all committed spend (contracts, grants, staff costs) by Month 1 (2026-11-12)
- Establish monthly cash-flow process: request invoices and accruals from all budget owners (carriers' integration leads, clearing architect, concession manager, etc.) by 5th of following month
- Aggregate actuals into forecast by 10th of month; prepare variance report (committed vs. budget, accrued vs. committed, triggers breached?) by 10th
- Publish forecast and variance report to steering group biweekly (every other Monday) Months 1-60 (2026-11-12 to 2031-10-12)
- Escalate any variance >EUR 50M within 5 business days to Programme Director and Finance Lead; recommend corrective action
- Implement variance triggers automatically: if cumulative variance approaches EUR 100M, prepare deferral of TEN-T extension plan; at EUR 200M, prepare concession subsidy-cut options; at EUR 300M, prepare restriction-to-four-corridors plan
- Conduct quarterly re-baselining (Months 6, 12, 18, 24, 30, 36, 42, 48, 60 = 2027-04-12, etc.) revising estimates for remaining quarters based on actuals to date
- Maintain audit trail of all budget decisions, approvals and re-baselining; ensure full traceability for European Court of Auditors review

**Approval Authorities:** Finance Lead, Programme Director, DG MOVE Director of Budget and Financial Management

### 13. Milestone-Conditioned Funding Release Ladder (Tranches and Verification Criteria)

**ID:** 4e5e1f6d-4c10-4898-be32-d396ab9d680e

**Description:** Formal funding-release framework specifying which deliverables must be verified before each funding tranche is released to carriers and member-state bodies. Tier 1 (Month 30 = 2029-04-12): EUR 80M adapter funding released to Tier 1 carriers after independent audit verifies p95 latency <2 seconds, 99.5% uptime, <1% stale-seat errors on live API for 30 consecutive days. Tier 2 (Month 36 = 2029-10-12): EUR 80M released after Tier 2 conformance verification. Tier 3 (Month 42 = 2030-04-12): EUR 50M released after Tier 3 verification. Also specifies that public-distributor concession (EUR 300M) is released in tranches tied to platform launch (Month 30 = 2029-04-12), achieving passenger-volume milestones (Months 36, 48, 60 = 2029-10-12, 2030-10-12, 2031-10-12) and complaint-reduction targets. Output: compliance incentive, budget protection, achievement of SLA targets. Primary audience: carriers, Programme Director, Finance Lead, steering group.

**Responsible Role Type:** Programme Director (with support from Independent Audit & Assurance Function)

**Primary Template:** Contract milestone and payment schedule template

**Secondary Template:** SLA verification checklist (per tier, verified by independent auditor)

**Steps:**

- Define tier-specific deliverables and SLA targets by Month 6 (2027-04-12), based on technical audit output and binding standards
- Specify verification procedure: independent auditor conducts live testing of each carrier's API against SLA targets; tests run for 30 consecutive days (proposed threshold) before tranche release is approved
- Draft Tier 1 verification checklist (p95 latency <2s, 99.5% uptime, <1% stale-seat errors, booking correctness, refund reversal success rate) and acceptance criteria by Month 9 (2027-07-12)
- Publish complete funding-release ladder (all three tiers + concession tranches) and SLA-verification schedules by Month 12 (2027-10-12); incorporate into binding standards
- At each tier's milestone (Months 30, 36, 42 = 2029-04-12, 2029-10-12, 2030-04-12), conduct independent audit of all carriers in that tier; publish audit results and release/hold decision within 10 business days of test completion
- For any carrier missing SLA targets, offer remediation window (15 business days) to retest; if still failing, hold that carrier's tranche and escalate to Programme Director
- For concession tranches, tie releases to measured passenger volumes and complaint-reduction achievements (quarterly metrics); publish progress against targets quarterly

**Approval Authorities:** Independent Audit & Assurance Function (verification), Programme Director (release decision), DG MOVE Controller (funding authorization)

### 14. Stakeholder Engagement and Governance Charter

**ID:** b10ae9e2-2c2f-482f-bdfc-8bb038bcbe14

**Description:** Formal charter defining the steering-group composition, roles, decision rights and escalation processes. Comprises: (1) steering core group (9 members: DG MOVE, Agency, CER, 4 major carriers, Trainline, Omio, BEUC, disability body); (2) 75% supermajority voting rule on critical decisions (Decisions 1-5, commission band); (3) Commission mediation protocol if votes do not reach 75% by Month 5 (2027-03-12); (4) biweekly meeting schedule (Mondays 09:00 Brussels); (5) fallback technical interfaces for dissenting parties (e.g., bilateral clearing for carriers refusing pooled liability, sandbox-only role for distributors refusing mandatory API). Includes observer seats for national regulators and quarterly briefings to member-state governments. Output: transparent, inclusive governance with clear escalation paths. Primary audience: steering members, Commission, member-state governments, carriers, distributors.

**Responsible Role Type:** Programme Director (with support from Communications & Stakeholder Engagement Lead)

**Primary Template:** Governance Charter template (EU institutional model)

**Secondary Template:** Steering group terms of reference (meeting agendas, decision log, action tracking)

**Steps:**

- Draft governance charter and decision-rights matrix by Month 0.5 (2026-10-27)
- Circulate to intended steering members (DG MOVE, CER, 4 major carriers, distributors, BEUC) for feedback Months 0.5-1 (2026-10-27 to 2026-11-12)
- Resolve any objections to voting rules or escalation procedures by Month 1 (2026-11-12); finalize charter
- Publish charter and call steering group's first meeting (Month 1 = 2026-11-12); establish biweekly meeting cadence (Mondays 09:00 Brussels time) and action-item tracking
- At Month 1 (2026-11-12) meeting, set the schedule for binding votes on Decisions 1-5 (by Month 6 = 2027-04-12) and option-paper circulation (by Month 2 = 2026-12-12)
- Publish option papers for each decision (Decisions 1-5) with explicit trade-offs (speed vs. coverage, control vs. complexity, budget risk vs. carrier autonomy) by Month 2 (2026-12-12)
- Hold written consultation on option papers (Months 2-3 = 2026-12-12 to 2027-01-12); compile feedback
- Conduct binding steering votes (75% supermajority) on all five decisions by Month 6 (2027-04-12); document voting outcomes and dissenting positions
- If vote on any decision does not reach 75% by Month 5 (2027-03-12), invoke Commission mediation; Commission Transport Commissioner or delegated advisor conducts facilitated dialogue by Month 5.5 (2027-03-27) and recommends resolution by Month 6 (2027-04-12)
- Maintain detailed steering decision log (biweekly) and publish anonymised summary to carriers and distributors monthly

**Approval Authorities:** Programme Director (charter sign-off), steering members (by participation), DG MOVE (escalation authority)

### 15. Disruption Event Feed and Real-Time Rerouting Specification

**ID:** 735b8039-cb59-4c2b-b267-6e30dadf98a4

**Description:** Technical specification for the shared disruption event feed enabling carriers to publish delay, cancellation and operational-status signals and distributors/rerouting services to subscribe and automate rebooking. Covers event schema (delay event, reroute event, cancellation, station incident), publish-subscribe guarantees (at-least-once delivery, ordered by timestamp, deduplication), publisher and subscriber lag monitoring, and recovery from feed unavailability. Specifies that distributed rerouting service maintains seat holds on alternative trains for stranded passengers, with 15-minute hold window (proposed threshold) and automatic fallback to manual phone-based rerouting if API-based rebooking fails. Includes operational procedures for 24/7 customer-service centre coordination. Output: reliable, automated rebooking that operationalises the through-ticket liability backstop. Primary audience: carriers, distributors, rerouting service operator, Programme Office.

**Responsible Role Type:** Data Architecture & Real-Time Systems Assurance Officer

**Primary Template:** Event-driven architecture specification (pub-sub pattern, Kafka or similar)

**Secondary Template:** Disruption operations manual (procedures for delay detection, rerouting, passenger notification)

**Steps:**

- Establish disruption event-feed design working group by Month 2 (2026-12-12) with carriers, distributors and the real-time systems engineer; meet biweekly Months 2-6 (2026-12-12 to 2027-04-12)
- Define event schema (delay, reroute, cancellation events with required fields: carrier ID, service ID, delay duration, affected seats, timestamp UTC, deduplication ID) by Month 3 (2027-01-12)
- Specify publish-subscribe guarantees: at-least-once delivery, ordered by timestamp within a partition (corridor), zero deduplication failures, replay of missed events if subscriber lag >60 seconds by Month 4 (2027-02-12)
- Design broker topology: Kafka-based, one topic per corridor, retain events 7 days, alerting if publisher lag >60s or subscriber lag >30s by Month 4 (2027-02-12)
- Specify rerouting service logic: upon receiving a delay event, query availability for alternative services within +2 hour window, hold seats for 15 minutes (proposed threshold), send rebooking notification to passenger, confirm rebooking or escalate to manual rerouting within 30 minutes (proposed threshold) by Month 5 (2027-03-12)
- Draft operational manual covering: 24/7 customer-service centre staffing, escalation procedures if automated rebooking fails, fallback to phone-based rerouting, staff training on PRM assistance and multilingual support by Month 6 (2027-04-12)
- Conduct chaos-engineering tests (kill carrier endpoints, delay event-feed publication) at Months 18, 30, 42 (2028-04-12, 2029-04-12, 2030-04-12) to validate rerouting reliability and fallback procedures
- Assign 24/7 operational ownership (4-6 staff per shift) starting Month 12 (2027-10-12); cost estimate EUR 1-2M/year (fits in programme-management budget)

**Approval Authorities:** Real-Time Systems Engineer, Programme Director, carriers (via working group consensus), EU Agency for Railways (operational oversight)

### 16. Accessibility Conformance and PRM User Research Findings

**ID:** eaa499a4-c03e-4c98-b99e-4692053e88ee

**Description:** Co-designed accessibility specification and user-research findings validating that through-ticketing design meets or exceeds EU accessibility requirements and addresses the needs of persons with reduced mobility (PRM). Includes: (1) atomic assistance-reservation design validated with 200+ PRM users in Months 2-4 (2026-12-12 to 2027-02-12) (pilot results at Months 12-18 = 2027-10-12 to 2028-04-12); (2) wheelchair-access and assistance thresholds (80% of services have wheelchair access, 90% can provide assistance with ≤4 hours' notice) with evidence of feasibility from baseline audit; (3) impact assessment showing itinerary-availability loss if atomic confirmation is enabled and mitigation options (phased rollout, best-effort fallback with compensation); (4) multilingual accessibility conformance matrix (WCAG 2.1 AA, screen-reader support, captions, B1 CEFR readability); (5) quarterly accessibility audit procedures and acceptance criteria for corridor go-live. Output: accessibility design that does not unintentionally exclude PRM passengers; regulatory compliance with Regulation 1371/2007 and EU Accessibility Directive. Primary audience: disability-rights organisations, EU Agency for Railways, carriers, public distributor.

**Responsible Role Type:** Passenger Rights, Accessibility & Consumer Protection Lead

**Primary Template:** Accessibility Impact Assessment template (EN 301 549, WCAG 2.1 standard)

**Secondary Template:** User research findings report (accessibility and multilingual usability testing)

**Steps:**

- Commission PRM user research workstream by Month 1 (2026-11-12), led jointly by Programme Office and ≥2 disability-rights organisations (EBU, EDF)
- Co-design accessibility and assistance-reservation flow with 200+ PRM users in structured workshops Months 2-4 (2026-12-12 to 2027-02-12); validate atomic confirmation concept, notice-period feasibility, and fallback preferences
- Conduct baseline accessibility audit of all four priority corridors (stations, trains, assistance staffing) by Month 3 (2027-01-12); map accessibility gaps and carrier remediation plans
- Publish wheelchair-access and assistance thresholds (80/90% proposed) with baseline data and feasibility assessment by Month 6 (2027-04-12); identify phased rollout path (e.g., Tier 1 carriers meet 80/90% by Month 30 = 2029-04-12, Tier 2 by Month 36 = 2029-10-12)
- Develop accessibility-conformance test suite (WCAG 2.1 AA validation, screen-reader testing, caption verification) and include in binding standards by Month 18 (2028-04-12)
- Run live pilot of atomic assistance-reservation and multilingual accessibility with 200-500 PRM users on 2 corridors Months 12-18 (2027-10-12 to 2028-04-12); measure itinerary-availability loss, satisfaction, rerouting success
- Publish pilot findings and impact assessment by Month 18 (2028-04-12); if availability loss >15% or satisfaction <70%, propose phased rollout or best-effort fallback alternatives
- Establish quarterly accessibility audit cadence (Months 30, 35, 40, 45, 50, 55, 60 = 2029-04-12 onwards); audit all carriers' conformance and publish findings; make audit results a condition of corridor continued operation

**Approval Authorities:** Disability-rights organisations (co-design consensus), Passenger Rights Lead, EU Agency for Railways (accessibility audit oversight)

### 17. Monthly Stakeholder Communications and Programme Update Newsletter

**ID:** 251d33cc-4e5e-4b6d-8d15-12b65fbbfd7c

**Description:** Standardised monthly newsletter distributed to all 25+ carriers, independent distributors, national regulators, CER, BEUC and disability bodies. Covers: (1) steering-group decisions and voting outcomes (anonymised positions); (2) programme-milestone status (on-time, at-risk, slipped); (3) budget variance and forecast (actual spend vs. budget, headroom remaining, variance triggers approached); (4) SLA scoreboard (carriers' latency, availability and error rates); (5) accessibility and multilingual usability-test findings (quarterly summary); (6) upcoming milestones and decisions; (7) frequently asked questions from carriers and distributors. Published by 10th of each month (starting Month 1 = 2026-11-12) in at least five languages (EN, FR, DE, ES, IT). Output: transparency, stakeholder alignment, early signals of programme risk or delay. Primary audience: carriers (CIOs, CFOs), distributors (product, legal), regulators, member-state governments.

**Responsible Role Type:** Communications & Stakeholder Engagement Lead

**Primary Template:** Newsletter template (Mailchimp or equivalent email-marketing platform)

**Secondary Template:** Multilingual content-management system (to support 5+ language maintenance)

**Steps:**

- Establish newsletter content structure and publishing cadence by Month 1 (2026-11-12)
- Compile steering-group decision summaries and voting outcomes from monthly decision log by 8th of each month
- Collect milestone-status updates from programme workstream leads (actuarial study, technical audit, clearing design, standards, competition law, etc.) by 8th of month
- Extract budget variance and SLA scoreboard data from monthly financial and monitoring reports by 8th of month
- Write, translate and proof-read newsletter in five languages by 9th of month; publish by 10th
- Maintain subscriber list of all 25+ carriers, distributors, regulators and government contacts; monitor delivery rates and unsubscribe requests
- Include brief FAQ section addressing common questions from carriers and distributors (e.g., 'When are conformance tests available?', 'How do I know if I'm Tier 1 or Tier 2?', 'What is the commission band?')
- Publish archive of all newsletters on programme website; archive also in a searchable database for audit trail

**Approval Authorities:** Communications Lead, Programme Director (review for accuracy before publication)

### 18. Quarterly Budget Variance and Risk Review Report

**ID:** 612c25ea-23fe-4ff3-92a1-97bc986ea595

**Description:** Cumulative report produced at Months 6, 12, 18, 24, 30, 36, 42, 48, 60 (2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12, 2029-04-12, 2029-10-12, 2030-04-12, 2030-10-12, 2031-10-12) summarizing actual spend vs. budget, identified risks that have materialised or escalated, mitigation effectiveness, and outlook for remaining year and full programme. Includes decision on whether variance triggers (EUR 100M, EUR 200M, EUR 300M) have been approached, and if so, recommends scope reductions or contingency activations. Primary audience: steering group, Commission, Court of Auditors.

**Responsible Role Type:** Financial Risk and Budget Assurance Manager

**Primary Template:** Programme quarterly financial review template (variance analysis + risk assessment)

**Secondary Template:** Risk-dashboard update (Jira or equivalent, exported as PDF summary)

**Steps:**

- Extract cumulative spend data from monthly cash-flow forecasts at each quarter-end
- Calculate variance (actual vs. budget) for each budget line and overall programme
- Assess whether cumulative variance triggers (EUR 100M, EUR 200M, EUR 300M) have been breached; if so, calculate which contingency scope-reduction actions apply
- Review risk register: identify any risks that have materialised, assess whether residual risk has increased, and confirm whether mitigation activities are on track
- Project spend for remaining quarters based on current run-rate and any known changes (e.g., acceleration of adapters, deferral of consumer rollout)
- Prepare recommendations: continue as-is, activate contingency, or revise budget allocation
- Draft report and present to steering group and DG MOVE finance director within 15 business days of quarter-end

**Approval Authorities:** Financial Risk Manager, Programme Director, DG MOVE Director of Budget (if variance >EUR 50M)

### 19. Specification Custodian Change-Control and Release Roadmap

**ID:** 85b25c90-d1d7-4dd4-9458-b00a9939b5ac

**Description:** Published roadmap documenting the OSDM specification's version-release schedule, change-request procedure (time-to-resolution per severity level), approved change requests awaiting release, and any known version-forking or divergence among adopter carriers. Updated quarterly starting Month 6 (2027-04-12). Provides transparency on whether the specification is stable and predictable (supporting carrier and distributor integration) or volatile and contested (signalling governance fragility). Primary audience: standards custodian, carriers, distributors, conformance testers.

**Responsible Role Type:** Standards & Technical Specification Custodian

**Primary Template:** Software release roadmap (GitHub or similar open-source project format)

**Secondary Template:** Change-control log (tracking change requests, approval status, and resolution dates)

**Steps:**

- Publish first roadmap by Month 12 (2027-10-12) covering Months 12-24 (2027-10-12 to 2028-10-12), specifying quarterly minor-release schedule and any major-version release planned before Month 18 (2028-04-12) binding-standards lock
- For each release, document: approved changes, estimated impact on carriers, required migration procedures and testing
- Maintain a public change-request tracker (GitHub Issues, Jira or equivalent) where any carrier or distributor can submit requests, with target time-to-decision (critical 2 weeks, major 6 weeks, minor 8 weeks)
- Publish quarterly updates to the roadmap at Months 18, 24, 30, 36, 42, 48, 54, 60 (2028-04-12, etc.), confirming delivery against prior projections and any changes to future planned releases
- Monitor for version fragmentation (carriers implementing different OSDM versions or dialects) and publish a quarterly divergence report if >10% of adopters are not on the current version

**Approval Authorities:** Standards Custodian, EU Agency for Railways (oversight)

### 20. Quarterly Conformance Audit and Carrier Performance Scoreboard

**ID:** 453c7077-4c14-4592-b423-c44c5462e987

**Description:** Quarterly independent audit of all participating carriers' API performance against SLA targets (p95 latency <2 seconds, 99.5% uptime, <1% stale-seat errors), accessibil-ity (wheelchair access, assistance availability), multilingual support and ticket-validation readiness. Produced at Months 12, 18, 24, 30, 36, 42, 48, 54, 60 (2027-10-12, 2028-04-12, 2028-10-12, 2029-04-12, 2029-10-12, 2030-04-12, 2030-10-12, 2030-04-12, 2031-10-12) and published as a public scoreboard showing each carrier's performance trend. Used to determine funding tranche release and to flag carriers requiring remediation. Primary audience: steering group, carriers, Programme Director, national regulators.

**Responsible Role Type:** Independent Audit & Assurance Function (external audit firm or EU-internal audit office)

**Primary Template:** Conformance audit report template (technical and compliance testing)

**Secondary Template:** Performance scoreboard (public website, updated monthly with SLA metrics)

**Steps:**

- Establish independent audit framework by Month 6 (2027-04-12); identify audit firm or internal audit function
- Specify audit procedures: live testing of each carrier's API for 30 consecutive days, sampling of accessibility and multilingual features, review of ticket-validation readiness documentation
- Conduct first audit Months 12-30 (2027-10-12 to 2029-04-12) on Tier 1 carriers; publish results and performance scoreboard by Month 30 (2029-04-12)
- Conduct Tier 2 audit Months 30-36 (2029-04-12 to 2029-10-12); publish scoreboard by Month 36 (2029-10-12)
- Conduct Tier 3 audit Months 36-42 (2029-10-12 to 2030-04-12); publish by Month 42 (2030-04-12)
- Publish updated scoreboard monthly starting Month 12 (2027-10-12), showing rolling p50/p95/p99 latency, uptime %, stale-seat errors and accessibility compliance per carrier
- Escalate carriers missing SLA targets to Programme Director; recommend remediation window or funding hold

**Approval Authorities:** Independent Audit Function, Programme Director (funding release decisions based on audit results)

### 21. Settlement Reconciliation Error Analysis and Dispute Resolution Quarterly Report

**ID:** 319f8e82-e31b-4303-9332-19f274f4dcee

**Description:** Quarterly report on the federated clearing layer's reconciliation performance: error rates (target <0.5% by Month 30 = 2029-04-12), mean time to resolution (target 5 business days), dispute categories (revenue allocation, refund reversal, commission disputes, payment-processor errors), and escalations to independent arbitration. Produced at Months 12, 18, 24, 30, 36, 42, 48, 54, 60 (2027-10-12 onwards, once settlement is live at Month 30 = 2029-04-12, then quarterly). Used to assess clearing-layer stability and to identify systemic issues (e.g., recurring disputes with a specific carrier or distributor) requiring design review. Primary audience: clearing architect, Programme Director, carriers, distributors.

**Responsible Role Type:** Clearing and Settlement Operations Lead

**Primary Template:** Financial-services settlement performance report (tracking error rates, dispute volumes, resolution times)

**Secondary Template:** Dispute-category taxonomy and root-cause analysis (Excel or BI dashboard)

**Steps:**

- By Month 24 (2028-10-12), establish reconciliation monitoring and dispute-logging procedures
- From Month 30 (2029-04-12) onwards, collect daily reconciliation results (transaction counts, variance by carrier-pair, errors flagged) and monthly error rates
- Categorise disputes (revenue allocation variance, refund reversal failure, commission calculation error, payment-processor timeout, etc.) and track root causes
- For each quarterly report (Months 30, 36, 42, 48, 54, 60 = 2029-04-12 onwards), publish: aggregated error rate, median time-to-resolution, top dispute categories, and any carriers or distributors exceeding 1% error threshold
- Conduct root-cause analysis for disputes exceeding the error threshold; recommend process changes (e.g., tighter reconciliation tolerance rules, carrier system audit, distributor training)

**Approval Authorities:** Clearing Operations Lead, Programme Director (decision on remediation or sanctions)

### 22. Through-Ticket Market Penetration and Modal-Shift Quarterly Monitoring Report

**ID:** b6acd97d-d462-4d06-bcdc-595203cacaf5

**Description:** Quarterly analysis (starting Month 30 = 2029-04-12 when four-corridor service goes live, then quarterly at Months 36, 42, 48, 54, 60 = 2029-10-12, 2030-04-12, 2030-10-12, 2031-04-12, 2031-10-12) of through-ticket volumes and market share per corridor, distributor type (carrier direct, Trainline, Omio, public distributor), and passenger demographics. Compares against baseline (Month 0 = 2026-10-12) to assess progress toward the 40% through-ticket target and the halved-complaints metric. Also tracks air-to-rail mode shift on benchmarked short-haul corridors (Paris-Lyon, Wien-München, Madrid-Barcelona, Copenhagen-Hamburg). Output: evidence of programme efficacy and course correction if targets are off track. Primary audience: Programme Director, steering group, Commission.

**Responsible Role Type:** Programme Director (or delegated market-research team)

**Primary Template:** Market analysis and key-metric tracking report (PowerPoint or PDF with data visualizations)

**Secondary Template:** Data extraction template (from carriers, distributors and booking platforms)

**Steps:**

- By Month 24 (2028-10-12), establish data-collection agreements with Trainline, Omio, carrier booking systems and the public distributor to provide monthly through-ticket volumes and market-share data (anonymised, aggregated by corridor)
- By Month 30 (2029-04-12), establish baseline comparison: collect historical data from pre-programme period (Months -12 to 0 = Oct 2025 to Oct 2026, estimate) and compile first quarterly report at Month 30 (2029-04-12)
- At each quarterly report, calculate: (1) through-ticket share (% of cross-border bookings that are through-tickets); (2) distributor market share (% via each channel); (3) passenger volume trends per corridor; (4) air-to-rail mode shift on benchmarked routes (compare booking volumes for rail vs. flights on identical origin-destination pairs)
- Compare against the 40% through-ticket target and halved-complaints metric; if trending significantly below target, recommend programme adjustments (e.g., increased commission band, consumer-rollout acceleration, dispute-resolution staffing)
- Publish findings in a public quarterly report, with anonymised country/corridor-level breakdowns where possible

**Approval Authorities:** Programme Director, steering group (review and course-correction decisions if targets off track)

### 23. Accessibility Compliance Audit Report and PRM Service-Quality Quarterly Assessment

**ID:** 92065d81-acd3-4229-a428-d14285d72107

**Description:** Quarterly accessibility audit (starting Month 30 = 2029-04-12, then at Months 35, 40, 45, 50, 55, 60 = 2029-09-12, 2030-02-12, etc.) assessing carriers' compliance with 80% wheelchair-access and 90% assistance-within-4-hours thresholds, and measuring PRM passengers' end-to-end journey satisfaction (booking flow usability, assistance experience, ticket validation, refund handling). Published as a quarterly public report. Used to enforce accessibility conformance and to identify carriers or corridor bottlenecks requiring remediation. Primary audience: disability-rights organisations, EU Agency for Railways, national regulators, steering group.

**Responsible Role Type:** Passenger Rights, Accessibility & Consumer Protection Lead

**Primary Template:** Accessibility compliance audit template (EN 301 549 / WCAG 2.1 standards)

**Secondary Template:** PRM user-satisfaction survey and journey-experience data collection template

**Steps:**

- By Month 18 (2028-04-12), finalise accessibility audit procedures: on-site station accessibility assessments, train-equipment inspections, rolling-stock inventory validation, staff training audits
- Establish baseline accessibility measurements per carrier and per corridor by Month 24 (2028-10-12) (before go-live)
- Starting Month 30 (2029-04-12), conduct quarterly audits: on-site visits to 2-3 key stations per corridor, review of rolling-stock accessibility documentation, interviews with station staff and onboard crew
- Conduct PRM passenger experience surveys: recruit 50-100 PRM passengers per corridor per quarter to complete end-to-end journey (booking, travel, refund/reroute if applicable); measure satisfaction (1-5 scale) for booking accessibility, information clarity, assistance quality, ticket validation and complaint handling
- Compile quarterly audit findings: (1) accessibility scorecard per carrier (% of services meeting wheelchair/assistance thresholds); (2) PRM satisfaction scores; (3) gap analysis (which corridors or operators fall short of 80/90% targets); (4) recommended remediation (staff training, equipment upgrades, timetable adjustments)
- Publish quarterly report; escalate any corridor or carrier falling >10% below target thresholds to Programme Director for remediation planning

**Approval Authorities:** Accessibility Lead, EU Agency for Railways (oversight), disability-rights organisations (consultation on audit findings)

### 24. Multilingual Support and Usability Quarterly Test Report

**ID:** 84c38204-0f9e-40c7-947b-18f33ead5054

**Description:** Quarterly usability testing (Months 12, 18, 24, 30, 36, 42, 48, 54, 60 = 2027-10-12, 2028-04-12, etc.) of through-ticketing booking and complaint-handling flows in 5+ EU languages (English, French, German, Spanish, Italian minimum), conducted with panels of native speakers and non-native speakers. Measures: booking-flow success rate per language, error-message clarity, refund-procedure understanding, complaint-submission usability. Identifies language-specific gaps or confusing translations that impede booking or support. Published as a quarterly usability report with recommended translations/UX changes. Primary audience: public distributor (concession operator), programme management, carriers.

**Responsible Role Type:** Passenger Rights, Accessibility & Consumer Protection Lead (with support from usability-testing vendor)

**Primary Template:** User-research findings report (qualitative and quantitative usability metrics)

**Secondary Template:** Usability scorecard (success rate, error rate, task-completion time per language)

**Steps:**

- By Month 12 (2027-10-12), establish usability-testing vendor and recruit multilingual test panels (200+ users across 5 languages minimum)
- Define test scenarios: booking a through-ticket, modifying reservation, submitting complaint, requesting refund, asking for assistance accommodation
- Conduct first test round (Month 12 = 2027-10-12) on prototype or beta booking interface; measure success rate, time-to-task completion, error rate per language; conduct debriefing interviews to identify confusing wording or terminology
- At each quarterly test (Months 18, 24, 30, 36, 42, 48, 54, 60 = 2028-04-12 onwards), test the production booking flow (if live) and measure usability metrics
- Publish quarterly usability report with: (1) success rate per language; (2) average time-to-task completion; (3) top errors by language; (4) qualitative feedback on unclear terms or confusing flows
- Escalate any language with <80% success rate to the concession operator with recommended UX/translation improvements

**Approval Authorities:** Accessibility Lead, Programme Director, public distributor concession operator (responsible for fixes)

### 25. Distributor Complaints Analysis and Resolution Trends Quarterly Report

**ID:** 6b97af88-a923-4ee8-9245-9bf09c700b42

**Description:** Quarterly analysis of distributor complaints (from Trainline, Omio, smaller independents, public distributor) by root cause (booking errors, payment failures, settlement delays, disruption rerouting failures, refund reversals, accessibility, multilingual support), resolution time and appeal rate. Compares quarterly data to baseline (Month 0 = 2026-10-12) and tracks progress toward the halved-complaints target by Month 60 (2031-10-12). Published at Months 12, 18, 24, 30, 36, 42, 48, 54, 60 (2027-10-12 onwards, after complaints infrastructure is live at Month 30 = 2029-04-12). Identifies systematic issues (e.g., recurring settlement delays with a specific carrier) and recommends process changes. Primary audience: Programme Director, steering group, carriers, distributors, BEUC.

**Responsible Role Type:** Passenger Rights, Accessibility & Consumer Protection Lead (with support from complaint-handling operations team)

**Primary Template:** Complaints analytics report (aggregated volumes by category, trends, root-cause analysis)

**Secondary Template:** Distributor feedback survey and verbatim-complaint database

**Steps:**

- By Month 30 (2029-04-12), establish complaints data collection: all complaints (from passengers to distributors, distributors to carriers, carriers to clearing) are logged in a central system with category, resolution time and outcome
- Compile baseline complaints data from the 12 months pre-programme (Months -12 to 0 = Oct 2025 to Oct 2026, estimate): request historical data from Trainline, Omio and major carriers
- Starting Month 30 (2029-04-12), collect live complaints data monthly; aggregate into quarterly reports
- At each quarterly report, calculate: (1) total complaint volume; (2) breakdown by category (booking error, payment, settlement, refund, disruption rerouting, accessibility, language support, other); (3) median resolution time per category; (4) appeal rate (% of resolved complaints that are re-opened); (5) year-on-year comparison to baseline to assess progress toward halved-complaints target
- Conduct root-cause analysis for any category showing >20% increase from prior quarter (signals a systematic issue); identify contributing factor (system glitch, carrier process failure, distributor misdirection, missing training) and recommend remediation
- Publish quarterly report with anonymised complaint examples and recommended corrective actions; escalate critical issues (e.g., >10 complaints/week on the same root cause) to Programme Director and steering group within 5 business days

**Approval Authorities:** Accessibility Lead, Programme Director, complaints-operations director (responsible for remediation)

## Documents to Find

### 1. EU Rail Ticketing Regulation Proposal Text and Legislative Status

**ID:** fc47eb5b-741b-4632-b918-f0dfa46efa09

**Description:** The formal text of the Commission's proposed Regulation on Digital Booking and Ticketing Services for Rail (proposed May 2026, status not verified as of project start October 2026). Provides the legal foundation for binding standards, mandatory API exposure, passenger-rights harmonisation and the Agency's role in conformance oversight. Essential input for the binding-standards working group and for forecasting the Regulation's adoption timeline (estimated Month 18 = 2028-04-12, but 6-12 month slip plausible). Intended audience for analysis: standards custodian, competition-law counsel, Programme Director.

**Recency Requirement:** Current as of project start (Month 0 = 2026-10-12); must reflect the proposal tabled in May 2026, including any amendments proposed by Parliament or Council by Month 0 (2026-10-12).

**Responsible Role Type:** Regulatory Affairs and Stakeholder Alignment Director

**Access Difficulty:** Medium. The Commission proposal (if published) is freely available on EUR-Lex. If not yet published (proposed May 2026, not yet confirmed as of October 2026 project start), access requires direct contact with DG MOVE, which will provide it confidentially or on request. Legislative amendments may not be publicly available until tabled formally in Parliament or Council.

**Steps:**

- Search EUR-Lex (Official EU Legislation Portal) for 'Regulation Digital Booking Ticketing Services Rail' or similar keywords; confirm proposal date (May 2026) and current legislative status
- Contact DG MOVE legislative affairs unit directly (email to DG-MOVE-REGISTRY@ec.europa.eu or via the DG MOVE website) requesting a copy of the May 2026 proposal and any amendments tabled by Parliament or Council
- If the proposal has been tabled and is available on EUR-Lex, download full text and all explanatory memoranda
- If proposal has not yet been tabled, request from DG MOVE: a pre-release briefing or roadmap indicating the tabling timeline (estimate currently Month 2-6 = 2026-12-12 to 2027-04-12)

### 2. Historical Rail Passenger Missed-Connection and Rerouting Cost Data (Per-Carrier)

**ID:** ca167ec9-6337-49b6-8a62-134c8439a574

**Description:** 24-month rolling data on missed-connection incidents, rerouting costs, passenger compensation claims and incident clustering from at least 5 major European carriers (SNCF, Deutsche Bahn, SBB, Renfe, ÖBB or equivalent) and one mid-size carrier. Used as input for the actuarial study to derive missed-connection frequencies, rerouting cost distributions, and carrier-specific risk profiles that underpin the carrier-funded guarantee-pool model (Decision 1) and the liability-cap and co-insurance parameters. Intended audience for analysis: actuary, risk-modelling specialist, Programme Director.

**Recency Requirement:** Most recent 24-month rolling period (September 2024 to September 2026, covering the most recent two full operational years before project start). Data must be current and representative; older data risks obsolescence due to changes in operating practices or passenger demand.

**Responsible Role Type:** Carrier Liability & Risk Modelling Specialist

**Access Difficulty:** Hard. Missed-connection data is proprietary business information that carriers typically do not share publicly (competitive sensitivity). Access requires direct carrier engagement via CER, confidentiality agreements and data-protection protocols. Some data may be held in legacy systems that are difficult to query. Smaller carriers may lack systematic incident tracking. Estimate 4-8 weeks to obtain data from all 5-6 carriers; risk of incomplete or non-standardised reporting.

**Steps:**

- Contact CER (Community of European Railways) membership team and request introduction to finance/operations contacts at 5-6 major carriers for historical incident data exchange
- Send formal data-request letter to each carrier (CIOs and CFOs) by Month 0.5 (2026-10-27) requesting: monthly counts of missed-connection incidents (by corridor and carrier pair), cost per incident (rerouting, accommodation, compensation), incident severity classification (passenger stranded <1 hour, 1-4 hours, >4 hours) and any seasonal or systemic clustering patterns
- Offer confidentiality agreement and data-protection assurances (GDPR compliance, aggregation to remove passenger identifiers, use limited to actuarial study)
- Follow up with carriers biweekly; expect 2-4 week response time (carriers may need to extract data from legacy systems or business-intelligence tools)
- Aggregate data received and anonymise at the carrier-group level (don't publish individual carrier figures without permission); validate completeness and reasonableness with CER

### 3. Existing EU and Member-State Rail Passenger-Rights Regulations and Enforcement Data

**ID:** 3eb00878-f735-4718-9368-9e93bf0f13c9

**Description:** The full text of EU Regulation 1371/2007 (railway passengers' rights) and any amendments (Regulation 2023/123, etc.), plus national implementing regulations and enforcement data (complaints by category, compensation paid, unresolved cases) from national regulators in France, Germany, Austria, Spain and other member states. Used to establish the baseline rights that through-ticket passengers must maintain and to model potential compensation liability. Intended audience for analysis: passenger-rights counsel, Programme Director, EU Agency for Railways.

**Recency Requirement:** Current regulations as of project start (October 2026). Must include EU Regulation 1371/2007 as currently in force, any recent amendments (2023 or later), and national enforcement data from 2024-2026 if available.

**Responsible Role Type:** Passenger Rights, Accessibility & Consumer Protection Lead

**Access Difficulty:** Easy. EU regulations are freely published on EUR-Lex. National enforcement data is typically public (annual reports) but may require direct contact with national regulators; some member states publish enforcement data in native language only. Estimate 1-2 weeks to obtain all core documents.

**Steps:**

- Download EU Regulation 1371/2007 and all amendments from EUR-Lex (https://eur-lex.europa.eu/); search for 'Regulation 1371/2007'
- Download Regulation 2023/123 (recent amendment, if applicable) from EUR-Lex
- Contact national railway regulators (or passenger ombudsmen) in France (DGAC/DGITM), Germany (EBA), Austria (ÖBB regulator), Spain (Comisión Nacional de los Mercados y la Competencia) requesting annual enforcement reports or complaints statistics for 2024-2026
- Request a copy of any high-level enforcement guidance or case-law summaries from national regulators
- Search EU Agency for Railways website for any published enforcement statistics or guidance on passenger-rights harmonisation

### 4. Current OSDM Specification (Latest Published Version) and UIC Governance Documentation

**ID:** 4b9ffdeb-44b9-4873-b157-b5e1f7a87be1

**Description:** The latest published version of the UIC Open Sales and Distribution Model (OSDM) specification, including API reference, data models and conformance requirements, plus documentation of the UIC's standards-governance process (change-request procedures, release cadence, conformance-test suite). Used to inform the binding-standards working group's design of OSDM conformance requirements and to understand the existing community's practices and concerns. Intended audience for analysis: standards custodian, carriers' CIOs, distributors.

**Recency Requirement:** Latest published OSDM version as of project start (October 2026). Must be the current stable release used by carrier adopters (likely OSDM 2.x or later); check UIC website for the authoritative version number.

**Responsible Role Type:** Standards & Technical Specification Custodian

**Access Difficulty:** Easy. OSDM specification is published openly by the UIC. GitHub repository and documentation are public. Community contact is available via the UIC website. Estimate 1 week to obtain all core documents and establish initial contact.

**Steps:**

- Visit UIC website (https://uic.org) and search for 'OSDM' or 'Open Sales and Distribution Model'
- Download the latest OSDM specification (likely available as PDF or linked from a GitHub repository)
- Request UIC Passenger Department contact via the UIC website; ask for pointer to: (1) current OSDM version status, (2) change-request process and backlog, (3) reference conformance test suite, (4) list of current adopter carriers and distributors
- If OSDM is hosted on GitHub, clone or download the repository to access specification source, test data and any open issues
- Request access to the UIC's OSDM community mailing list or Slack channel if publicly available

### 5. Carrier Booking System Architecture Survey Results (From Pre-Programme Technical Audit)

**ID:** 0b58684f-d20a-496d-8589-c8d196fc0248

**Description:** Detailed findings from the pre-programme technical audit of all 25+ participating carriers, including: current API readiness, event-streaming capability, transaction-consistency architecture, latency profiles (p50, p95, p99 percentiles), 12-month uptime %, legacy-system bottlenecks, staff FTE available for integration, and estimated retrofit cost per operator. Used to tier carriers for conformance timelines (Tiers 1, 2, 3) and to design shared adapter modules. Intended audience for analysis: carrier integration manager, programme management, finance lead.

**Recency Requirement:** Current as of Month 2 (2026-12-12) (completion of the pre-programme technical audit). Data must reflect carriers' systems state in Q3/Q4 2026 (baseline), not historical data from prior years.

**Responsible Role Type:** Carrier Integration & Technical Onboarding Manager

**Access Difficulty:** Medium. Carriers will be contractually obligated (as participants in the programme) to provide system-architecture data via the audit process. Smaller carriers or those with legacy systems may have limited documentation and require in-person site visits to validate information. Estimate 4-6 weeks for a full 25+ carrier audit; timing is critical to inform tier assignment by Month 6 (2027-04-12).

**Steps:**

- Contract an independent technical audit firm by Month 1 (2026-11-12) to conduct the audit; specify delivery Month 2 (2026-12-12)
- Audit firm issues technical assessment questionnaire to all 25+ carriers by Month 1 (2026-11-12), requesting: API status (current, under development, legacy), event-streaming capability (Kafka, REST polling, custom), latency profiles (p95 percentile for three-leg queries), annual uptime data (12-month history), legacy-system details and staff availability
- Audit firm conducts on-site or remote system reviews (30+ carrier days total) Months 1-2 (2026-11-12 to 2026-12-12)
- Audit firm publishes draft findings and tier recommendations by Month 2 (2026-12-12) end
- Receive final audit report from firm including: detailed per-carrier assessments, tier assignments, roadmap timelines, shared-adapter recommendations, cost estimates per carrier

### 6. Existing Inter-Carrier Settlement and Clearing Arrangements in Europe (RSP, Eurail, National Systems)

**ID:** 343094c4-ec57-4e89-ac38-bf366927b8d3

**Description:** Documentation of existing multi-carrier clearing and settlement systems operating in Europe: Rail Settlement Plan (RSB, Great Britain), Eurail/Interrail pooled revenue allocation, Swiss direct-service (NOVA) platform, and any national multi-operator clearing arrangements (Italy, France, Spain). Used as precedent for clearing-design decisions and to identify best practices for netting, reconciliation, dispute resolution and non-discriminatory access. Intended audience for analysis: clearing architect, programme management, competition-law counsel.

**Recency Requirement:** Current operational status as of project start (October 2026). Documentation should reflect how these systems currently operate (2026), including recent changes or modernisation initiatives.

**Responsible Role Type:** Inter-Carrier Clearing & Settlement Systems Architect

**Access Difficulty:** Medium. RSP documentation is publicly available or obtainable via formal request to RDG. Eurail and Swiss systems are proprietary but operators may share high-level documentation under confidentiality agreements. National systems may be less documented or available only in local languages. Estimate 3-4 weeks to gather overview of all existing systems; full legal documentation may not be accessible without direct business relationships.

**Steps:**

- Visit Rail Settlement Plan website (https://www.rsp.org.uk) and download published operating-rules documents and performance reports
- Contact Rail Delivery Group (RDG) retail/ticketing team and request: RSP operating manual (settlement cycle, netting rules, dispute procedure, retailer access criteria), annual performance reports (volumes, error rates, compliance audits)
- Contact Eurail B.V. (Utrecht) corporate relations and request: operating model documentation for the Eurail pass distribution and revenue-sharing system, carrier participation terms, and franchise agreements (if publicly available)
- Contact Alliance SwissPass or SBB corporate strategy and request: documentation of the Swiss Direct Service (NOVA) platform architecture, operator participation model, fare-composition rules and clearing procedures
- Contact CER (Community of European Railways) and request briefing on any national multi-operator clearing arrangements known to its members (e.g., Italy, France, Spain)

### 7. EU Agency for Railways Standards and Conformance-Testing Procedures (TAP TSI, Technical Acceptance Procedures)

**ID:** dda61b80-8a94-48ed-b394-729aad595782

**Description:** Documentation of the EU Agency for Railways' existing standards-governance procedures, particularly the TAP TSI (Technical Acceptance Procedures, Regulation 454/2011) specification and conformance-testing framework. Used to inform how the OSDM binding standards and conformance gate will be managed and enforced (Decision 11). Intended audience for analysis: standards custodian, conformance-testing lead, Programme Director.

**Recency Requirement:** Current Agency procedures and TAP TSI specification as of project start (October 2026). Must reflect the Agency's current conformance-governance role in the rail sector.

**Responsible Role Type:** Standards & Technical Specification Custodian

**Access Difficulty:** Easy. TAP TSI and Agency documentation are publicly available on the Agency's website and EUR-Lex. Briefings on procedure require direct contact with the Agency (telematics@era.europa.eu), but the Agency is typically responsive. Estimate 1-2 weeks.

**Steps:**

- Visit EU Agency for Railways website (https://www.era.europa.eu) and download TAP TSI Regulation (EU) 454/2011 and all amendments
- Request from the Agency's Telematics and Interoperability Division: documentation of the TAP TSI conformance-testing procedures, test environments and any reference test suites
- Request briefing on the Agency's experience managing open standards (TAP TSI) in terms of change-request backlogs, version-release cadence and community engagement
- Inquire whether the Agency has guidance on how to establish a 'conformance gate' (approval barrier) for new operators or services entering a network

### 8. DG COMP Guidance on Article 101 TFEU Exemptions in Transport and Digital Markets

**ID:** 2a0c8909-a183-4458-860b-b0dd5e85de29

**Description:** Published DG COMP guidance and precedent decisions on Article 101 TFEU safe-harbour criteria for shared data, pooled clearing, and joint commercial arrangements in transport and digital markets. Includes: joint-purchasing exemptions, air-transport alliances (IATA), roaming directives, and any recent guidance on digital-platform interoperability (e.g., Digital Markets Act). Used to inform the pre-notification memorandum and clean-team protocol design (Decision 14). Intended audience for analysis: competition-law counsel, Programme Director.

**Recency Requirement:** Current DG COMP guidance and precedents as of project start (October 2026). Must include any updates since the Digital Markets Act (2022-2024) and recent digital-platform precedents.

**Responsible Role Type:** Competition Law & Regulatory Affairs Counsel

**Access Difficulty:** Easy. DG COMP guidance is published on EUR-Lex and the DG COMP website. Direct contact with DG COMP Transport Unit requires formal request or engagement of external counsel but is typically accessible. Informal briefings may require establishing the programme's formal engagement with DG COMP via the pre-notification process. Estimate 2-3 weeks to compile existing public guidance.

**Steps:**

- Search EUR-Lex (https://eur-lex.europa.eu) for DG COMP guidance documents on Article 101 TFEU exemptions; filter by date (2020-2026)
- Visit DG COMP website (https://competition-policy.ec.europa.eu) and search for: 'transport exemption', 'data sharing', 'platform interoperability' or similar keywords
- Request from DG COMP's Transport Unit (contact via the DG website or COMP-REGISTRY@ec.europa.eu): any informal guidance on Article 101 TFEU compatibility of multi-operator clearing and data-sharing arrangements in rail; also request copies of any published decisions or notices on rail-sector alliances or joint ventures
- Retrieve any published case law or decisions relevant to Article 101 TFEU in rail (search EUR-Lex for 'rail' + 'competition')

### 9. Baseline Cross-Border Rail Travel Data and Through-Ticket Market Analysis

**ID:** 426d9b24-0354-441b-a6e0-c63262db384a

**Description:** Current statistical baseline on cross-border rail travel volumes, distribution channels (carrier direct, Trainline, Omio, national operators) and market share per corridor (Paris-Brussels-Amsterdam-Köln, Wien-München-Zürich, Madrid-Barcelona-Lyon, Copenhagen-Hamburg-Berlin). Used to validate the 40% through-ticket target (whether it is ambitious or conservative) and to model the baseline for the halved-complaints metric. Intended audience for analysis: Programme Director, finance lead, market-research team.

**Recency Requirement:** Most recent available year (2025 or early 2026) covering full calendar year or latest rolling 12-month period available. Data must be pre-programme (before October 2026) to establish the true baseline.

**Responsible Role Type:** Regulatory Affairs and Stakeholder Alignment Director

**Access Difficulty:** Medium. Trainline and Omio are commercial entities with proprietary market-share data; they may share summary statistics under NDA but full data may not be disclosed. CER members (carriers) own operational data but may not share across competitors. National statistical offices provide public statistics but may have limited cross-border detail. Estimate 3-4 weeks to assemble baseline data; some gaps are likely.

**Steps:**

- Contact Trainline and Omio directly via their corporate-development teams, requesting: market-share data (% of cross-border bookings per corridor, by distributor type) for 2024-2025 and customer-complaint statistics (volumes by category, resolution times)
- Request from CER: industry-level data on total cross-border rail travel volumes per corridor from member carriers (if compiled)
- Contact national statistical offices or transport ministries in France, Germany, Austria and Spain requesting: cross-border rail ridership data (annual counts, breakdown by origin-destination pair), distributor market share if available
- Request from the European Commission's DG MOVE or EUROSTAT: any published statistics on cross-border rail travel volumes or modal split (rail vs. air vs. bus) on European corridors

### 10. EU Member-State Railway Regulator Contact List and Regulatory Frameworks (France, Germany, Austria, Spain, etc.)

**ID:** b0a475b7-211c-471e-8d0b-649f01ef208e

**Description:** Contact information and summary of regulatory authority and remit for railway regulators in all member states participating in the four priority corridors and TEN-T network. Includes: France (DGITM/DGAC), Germany (Bundesnetzagentur), Austria (ÖBB Regulator), Spain (Comisión Nacional), Italy, Netherlands, Belgium, Denmark, Sweden, Poland, etc. Regulatory frameworks covering track access, station capacity, pricing rules, passenger rights and non-discrimination obligations. Used to conduct bilateral regulatory impact assessments (Month 3 = 2027-01-12) and to understand national constraints on mandatory API exposure or data sharing. Intended audience for analysis: regulatory-affairs lead, Programme Director.

**Recency Requirement:** Current as of project start (October 2026). Regulator contact information and organisational structure must be current; regulatory frameworks must reflect current national laws and European directives.

**Responsible Role Type:** Member-State Coordination and National Regulator Liaison Officer

**Access Difficulty:** Easy. Regulator contact information is publicly available via the EU Agency for Railways and national websites. CER may provide an internal summary. Regulatory frameworks are published by national authorities (often in national language, but English summaries or abstracts may be available). Estimate 2-3 weeks to compile complete list.

**Steps:**

- Visit the EU Agency for Railways website (https://www.era.europa.eu) and search for 'Member-State Regulators' or 'National Safety Authorities'; compile contact list
- Contact CER and request: list of member-state regulatory contacts and a one-page summary of each regulator's authority, remit and typical concerns on cross-border ticketing or data-sharing projects
- Search the website of each national regulator (typically transport ministry or dedicated transport regulator) to confirm current contact information and download summaries of national railway laws (often in English on EU or English-language versions of national sites)
- Request from DG MOVE: any internal mapping of member-state regulators and known regulatory constraints or precedents affecting cross-border rail initiatives

### 11. GDPR Data Protection Impact Assessment (DPIA) Guidance and Transport-Sector Precedents

**ID:** d81d3696-f81a-4dfd-bb46-4935fd11e5c4

**Description:** EU GDPR Article 35 Data Protection Impact Assessment (DPIA) guidance and published examples from transport-sector digital platforms or data-sharing projects. Used to design GDPR-compliant data flows in the real-time layer, settling mechanism and disruption event feed. Intended audience for analysis: data governance officer, programme management.

**Recency Requirement:** Current GDPR and EDPB guidance as of project start (October 2026). Must reflect EDPB recommendations on DPIA and any recent guidance on cross-border data sharing in regulated sectors.

**Responsible Role Type:** Data Governance and Privacy Officer

**Access Difficulty:** Easy. EDPB guidance is freely published. Published DPIAs vary in availability; many companies keep DPIAs confidential (internal compliance documents). Estimate 1-2 weeks to gather public guidance; internal DPIAs from other transport companies may not be accessible.

**Steps:**

- Download GDPR guidance from the European Data Protection Board (EDPB) website (https://www.edpb.europa.eu); search for 'DPIA guidance' and 'cross-border transfers'
- Request from national DPAs (French CNIL, German BfDI, Austrian DSB, etc.): any published examples of DPIAs for transport or mobility-data platforms
- Search for published DPIAs from TomTom, Uber or other mobility platforms on their websites (many large tech companies publish DPIAs or privacy-impact summaries)
- Request from DG MOVE: any existing GDPR guidance documents related to rail or transport data-sharing projects

### 12. EU Accessibility Directive and Persons with Reduced Mobility (PRM) Accessibility Standards

**ID:** 67de31d0-fd2a-4d93-94aa-abec25957e7a

**Description:** EU Directive 2019/882 (European Accessibility Act) and any transport-specific accessibility regulations (EU Regulation 1371/2007 PRM provisions, EN 13001-1 station accessibility standards). Used to define accessible booking and payment flows, assist-request handling and ticket validation for persons with reduced mobility. Intended audience for analysis: accessibility lead, programme management, carriers.

**Recency Requirement:** Current EU accessibility regulations as of project start (October 2026). Must include the latest version of the European Accessibility Act and any recent amendments.

**Responsible Role Type:** Passenger Rights, Accessibility & Consumer Protection Lead

**Access Difficulty:** Easy. EU directives and regulations are published on EUR-Lex. Agency guidance is publicly available. Disability-rights organisations' guidance may require direct contact but is typically shared as best-practice resources. Estimate 1-2 weeks.

**Steps:**

- Download EU Directive 2019/882 (European Accessibility Act) from EUR-Lex
- Download EU Regulation 1371/2007 Persons with Reduced Mobility (PRM) provisions from EUR-Lex
- Request from the EU Agency for Railways: any published guidance on accessibility requirements for digital rail services or ticketing systems
- Request from disability-rights organisations (EBU, European Disability Forum) or national DPOs: any accessibility checklists or best-practice guidance for transport booking platforms

### 13. EU and Carrier Environmental and Climate Policy (Green Deal, Modal Shift Targets)

**ID:** 9889795d-2a19-449b-9c3f-3c55f645b6fa

**Description:** EU Green Deal commitments, transport modal-shift targets (e.g., 50% reduction in car/short-haul-flight journeys by 2050) and any published baseline data on air-rail modal split or carbon-reduction targets for short-haul corridors. Used to contextualise the programme's modal-shift goal (5-10% air-to-rail planning value) and to validate whether it is aligned with EU climate objectives. Intended audience for analysis: Programme Director, stakeholder communications.

**Recency Requirement:** Current EU climate and transport policy as of project start (October 2026). Must reflect the EU Green Deal and any updated modal-shift targets or climate pledges from 2025-2026.

**Responsible Role Type:** Regulatory Affairs and Stakeholder Alignment Director

**Access Difficulty:** Easy. EU policy documents are published on Commission websites and EUR-Lex. Policy papers are typically available. NGO analyses require direct outreach but are usually shared. Estimate 1-2 weeks.

**Steps:**

- Download the EU Green Deal (European Commission, 2019 and subsequent updates) from the Commission website or EUR-Lex
- Search DG MOVE website for published targets on modal shift and short-haul air-to-rail competition
- Request from DG MOVE: any policy papers or assessments of the potential environmental impact of through-ticketing or cross-border rail integration
- Contact environmental NGOs (e.g., Transport & Environment) for any independent analysis of rail's competitive position vs. short-haul air and modal-shift potential

### 14. Current Trainline and Omio Booking Platform Architecture and API Capabilities

**ID:** 2de78274-b57e-416f-8d33-755548246459

**Description:** Technical documentation of Trainline and Omio's current booking-platform architecture (APIs, inventory query methods, payment processing, refund handling), integration with existing carrier systems and compatibility with OSDM standards. Used to validate the federated integration model and to assess whether independent distributors can connect to the shared clearing and real-time layers without extensive custom work. Intended audience for analysis: clearing architect, real-time systems engineer, distributor engagement team.

**Recency Requirement:** Current as of project start (October 2026). Must reflect the platforms' existing technical state and any recent API modernisations or OSDM adoption.

**Responsible Role Type:** Inter-Carrier Clearing & Settlement Systems Architect

**Access Difficulty:** Medium. Trainline and Omio are commercial platforms with proprietary architectures; they may share summary documentation under NDA but full technical details are business-sensitive. Initial contact likely requires formal programme engagement via the steering group. Estimate 2-4 weeks for preliminary technical briefing; full platform documentation may require formal partnership agreement.

**Steps:**

- Contact Trainline and Omio directly via their corporate-development or API-partnership teams, requesting: high-level technical documentation on booking-platform architecture, API endpoints exposed to carrier partners, payment processing and settlement procedures, and any OSDM compliance work underway
- Request test-environment access and API documentation (likely under NDA) to validate integration assumptions
- Inquire whether each distributor has already begun OSDM integration and what technical barriers they have identified

### 15. European Payment Service Providers Settlement and Clearing Capabilities (Banking Sector)

**ID:** 7d0c6bef-535e-42fb-a6ae-b3266c33d210

**Description:** Information on settlement and clearing capabilities of major payment service providers (PSPs) operating in Europe (e.g., Worldpay, Adyen, Stripe, or European bank clearing networks SEPA, TARGET2) regarding multi-currency settlement, real-time payment processing and dispute handling for travel and ticketing use cases. Used to validate whether the federated clearing layer can leverage existing payment infrastructure or requires custom settlement mechanisms. Intended audience for analysis: clearing architect, finance lead.

**Recency Requirement:** Current services and capabilities as of project start (October 2026).

**Responsible Role Type:** Inter-Carrier Clearing & Settlement Systems Architect

**Access Difficulty:** Easy. PSPs maintain public documentation and enterprise-sales teams are accessible. SEPA information is public. Estimate 1-2 weeks for initial briefing; detailed commercial terms may require NDA and formal negotiation.

**Steps:**

- Contact major PSPs (Adyen, Worldpay, Stripe, Payoneer) via their enterprise-sales teams, requesting: documentation on multi-currency settlement, real-time payment processing (if available), dispute-resolution procedures, and integration with travel and ticketing platforms
- Inquire whether any PSP has experience with multi-operator fare-splitting or settlement netting (used in airline and bus sectors)
- Contact SEPA (Single Euro Payments Area) clearing network and request: documentation on SEPA instant payments and any support for multi-party settlement or netting

### 16. EU Agency for Railways Conformance Testing Infrastructure and Tooling

**ID:** e6a202a3-a4fe-4d1a-8e06-880ac714a815

**Description:** Documentation of the EU Agency for Railways' existing conformance-testing infrastructure (test environments, test data, automated testing frameworks) used for TAP TSI and other standards. Used to assess whether the Agency can support conformance testing for the new OSDM binding standards or whether custom testing tooling must be commissioned. Intended audience for analysis: standards custodian, conformance-testing lead.

**Recency Requirement:** Current state of Agency testing infrastructure as of project start (October 2026).

**Responsible Role Type:** Standards & Technical Specification Custodian

**Access Difficulty:** Medium. Agency information is internal but typically shared with standards partners. Direct contact with the Agency is required. Estimate 2-3 weeks.

**Steps:**

- Contact EU Agency for Railways Telematics and Interoperability Division (contact via https://www.era.europa.eu) and request: documentation on existing conformance-testing infrastructure (tools, environments, test data), capacity to expand testing for new standards, and any gaps that would require external tooling
- Request examples of TAP TSI conformance test suite to understand testing methodology and tooling

### 17. Existing Rail and Transport Modal-Shift Research and Air-to-Rail Demand Elasticity Studies

**ID:** 05857abb-3a4c-4dd1-9710-15af7c6ec26f

**Description:** Academic research and industry studies on fare elasticity (passenger demand response to price changes) and modal-shift potential (what share of short-haul flights can be converted to rail) on key European corridors. Used to validate the planning assumption that 5-10% air-to-rail modal shift is achievable and to inform pricing strategy for through-tickets on air-competitive corridors. Intended audience for analysis: Programme Director, market-research team.

**Recency Requirement:** Recent research (2020-2026) on EU transport demand and modal-shift elasticity; must be current and specific to the four priority corridors or similar European routes where air-rail competition exists.

**Responsible Role Type:** Regulatory Affairs and Stakeholder Alignment Director

**Access Difficulty:** Easy. Academic research is published and searchable. Consulting-firm reports are often publicly available or can be requested. Estimate 1-2 weeks to compile relevant studies.

**Steps:**

- Search academic databases (Google Scholar, SSRN, transport research journals) for papers on 'air-rail competition elasticity', 'modal shift short-haul Europe', 'through-ticket demand Europe'
- Request from Transport & Environment (environmental NGO) any published research on air-to-rail modal-shift potential and carbon reductions
- Contact Roland Berger, McKinsey, or other transport-consulting firms that publish research on European rail and modal shift; request summary reports or published case studies