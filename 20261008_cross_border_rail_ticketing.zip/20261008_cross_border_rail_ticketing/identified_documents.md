
## Documents to Create

### 1. Project Charter and Programme Authority Framework

**ID:** 20bfc80f-1561-4b0f-86ab-09346e1cf583

**Description:** Foundational governance document establishing the programme's legal authority, scope, objectives, stakeholder roles, and decision-making structures. Specifies the arbitration panel's binding technical authority, Council delegation, member-state regulator coordination, and escalation procedures. Audience: DG MOVE, EU Agency for Railways, member-state transport ministries, carriers, distributors. Approval required from the Commission and Council.

**Responsible Role Type:** Governance and Legal Affairs Advisor

**Primary Template:** EU Programme Charter Template (adapted for multi-stakeholder infrastructure)

**Secondary Template:** Commission Decision on Delegated Authority Framework

**Steps:**

- 1. Draft the charter's executive summary, scope, objectives and success criteria aligned to the user constraints (EUR 1.5B cap, Month 18/30/60 = 2028-04-08, 2029-04-08, 2031-10-08 milestones, 40% through-ticket target, halved complaints).
- 2. Define the arbitration panel's authority: binding decision scope (technical standards, access terms, settlement formats; excluded: commercial pricing), 60-day cycles, 14-day compliance deadlines, escalation to Commission.
- 3. Specify governance structure: PMO reporting to DG MOVE and Steering Committee; Standing Regulators Committee with lead-authority rule for cross-border disputes; twinning for capacity building.
- 4. Include risk governance: contingency tiers (Tier 1–3 triggers at 115% spend), mid-course reviews (Months 12, 24 = 2027-10-08, 2028-10-08), decision gates for Regulation adoption, hub readiness, payment accreditation.
- 5. Obtain legal review from DG MOVE legal services and Council Presidency (target Month 0.5 = 2026-10-23); present for formal Council adoption by Month 2 (2026-12-08).

**Approval Authorities:** European Council (for delegation of authority); Commission (DG MOVE); Member-state transport ministers (for regulator coordination)

### 2. Pragmatic Foundation Scenario: Certified Access, Accredited Payment Providers, Regional Hubs, Arbitration Panel

**ID:** 0e5914b1-d5f9-40f9-a43a-f4cf5f0f22c2

**Description:** High-level strategic plan articulating the chosen Pragmatic Foundation scenario: certification-based tiered access to OSDM APIs, accredited payment institutions for split-payment settlement, milestone-based carrier co-funding, regional shared hubs for legacy-IT carriers, and a lightweight arbitration panel. Contrasts with alternatives (Pioneer's Gambit, Consolidator's Compact). Audience: Steering Committee, carriers, distributors, DG MOVE, Parliament. Explains rationale, trade-offs and how the scenario balances progress against delivery risk.

**Responsible Role Type:** Strategy and Programme Director

**Primary Template:** EU Strategic Scenario Framework

**Steps:**

- 1. Articulate the core rationale: avoids new legal entities (joint undertaking delays), defers price-fixing until legislation is final, uses existing market mechanisms (accredited payment providers), includes smaller carriers via hubs.
- 2. Map each strategic decision to the scenario: Decision 1 (certification-based access), Decision 2 (accredited payment providers), Decision 3 (milestone co-funding), Decision 4 (regional hubs), Decision 5 (arbitration panel).
- 3. Identify synergies and conflicts with secondary decisions (e.g., how hubs enable smaller-carrier migration; how certification supports competition-law firewalls).
- 4. Define success metrics: 90% of corridor traffic bookable end-to-end by Month 30 (2029-04-08); 40% through-ticket share by Month 60 (2031-10-08); distributor complaints at or below 50% of baseline.
- 5. Highlight critical dependencies: Regulation adoption by Month 9 (2027-07-08), Council delegation by Month 2 (2026-12-08), carrier Commitment Letters by Month 3 (2027-01-08).
- 6. Communicate to all stakeholders: present at Steering Committee (Month 2 = 2026-12-08), Parliament TRAN committee (Month 3 = 2027-01-08), carrier roundtables (Months 1–3 = 2026-11-08 to 2027-01-08).

**Approval Authorities:** Steering Committee; DG MOVE; Commission

### 3. OSDM-Compatible API Specification and Binding Standards Document

**ID:** 87b09b1b-9803-4d4d-ab98-e04a1fe62a2c

**Description:** Comprehensive technical standards binding on all participating carriers and distributors, aligned to OSDM v2.1 and the (final) EU Regulation on Digital Booking and Ticketing. Covers access-term templates (non-discriminatory inventory, fare and post-sale API exposure), data-quality SLAs (latency, uptime, inventory freshness, disruption timeliness), settlement message formats, ticket validation protocols, GDPR compliance rules, accessibility requirements, and certification conformance criteria. Audience: carriers, distributors, test labs, national regulators. Due Month 18 (2028-04-08); locked and non-negotiable thereafter.

**Responsible Role Type:** Chief Technical Standards Officer / OSDM and API Architecture Lead

**Primary Template:** OSDM v2.1 Specification (extended)

**Secondary Template:** EU Technical Standards Framework (CEN/CENELEC model)

**Steps:**

- 1. Conduct a gap analysis Month 4–6 (2027-02-08 to 2027-04-08) between the Commission's final Regulation text (adopted by Month 9 = 2027-07-08 target) and OSDM v2.1, identifying areas requiring specification or clarification.
- 2. Draft candidate access-term templates (inventory API, fare API, post-sale API) specifying fields, response times, error handling, retry logic.
- 3. Define data-quality SLAs: API p95 latency under 2 seconds, uptime 99.95%, throughput at least 500 requests/second per corridor, inventory freshness under 5 minutes, disruption-event latency under 2 minutes.
- 4. Embed GDPR compliance rules (from the DPIA and DPA consensus by Month 4 = 2027-02-08), accessibility requirements (24-hour assistance confirmation, 90%+ confirmation rate, 95%+ delivery), and liability-allocation framework for passenger rights.
- 5. Define conformance-test criteria (test harnesses, successful API calls, data-quality samples, performance benchmarks) to be validated by independent testing labs starting Month 9 (2027-07-08).
- 6. Hold stakeholder consultation rounds (Months 7–17 = 2027-05-08 to 2028-03-08), with formal technical dispute resolution by the arbitration panel for contested items.
- 7. Publish the binding standards document by Month 18 (2028-04-08) with signatures from DG MOVE, EU Agency for Railways, CER, and major carriers acknowledging adoption.

**Approval Authorities:** Arbitration Panel (technical validation); Commission (final approval); Member-state regulators (enforcement authority)

### 4. Clearing and Settlement Architecture Design and Accredited Payment Provider Specification

**ID:** 0634d9ee-b437-4f8a-9151-b1603b008392

**Description:** Detailed specification of the clearing and settlement mechanism using 2–3 accredited payment institutions (not a central clearing entity). Defines revenue apportionment rules (how multi-carrier fares are split), refund reversal protocols, dispute resolution within 5 business days, settlement cycle under 48 hours, SLA guarantees (99.95% uptime), and transaction-fee management. Includes accreditation criteria (PSD2 licensing, multi-currency support, SLAs), applicant evaluation framework, and fallback procurement if fewer than 2 providers apply. Audience: payment institutions, carriers, distributors, clearing-entity operators, regulators.

**Responsible Role Type:** Clearing and Settlement Mechanism Designer / Payment Systems Specialist

**Primary Template:** PSD2 Accreditation Framework (EU Central Bank guidance)

**Secondary Template:** Settlement Architecture Standards (ISO 20022, SEPA specifications)

**Steps:**

- 1. Conduct market sounding (Months 0–1 = 2026-10-08 to 2026-11-08) identifying potential accredited providers and their capacity.
- 2. Draft the accreditation criteria document (Month 1 = 2026-11-08): PSD2 compliance, multi-currency support (EUR, DKK, SEK, CHF, PLN, CZK, HUF, BGN, RON), settlement cycle under 48 hours, refund processing under 10 days, error handling and dispute resolution within 5 business days, SLA guarantees (99.95% uptime).
- 3. Issue a formal call for applicants (Month 2 = 2026-12-08) with detailed RFP specifying technical, operational and financial requirements.
- 4. Define the apportionment logic (Month 2–3 = 2026-12-08 to 2027-01-08): which carrier receives what share of the passenger fare based on segment distance, time or agreed allocation keys; specify rounding and residual handling.
- 5. Design the refund-reversal protocol (Month 2–3 = 2026-12-08 to 2027-01-08): when a distributor refunds a passenger, how the cost flows back to the responsible carrier via the accredited provider; dispute escalation if the carrier contests the refund.
- 6. Evaluate applications and make accreditation decisions (Month 8 = 2027-06-08); target at least 2 accredited providers operational by Month 12 (2027-10-08).
- 7. Define the fallback: if fewer than 2 providers qualify by Month 6 (2027-04-08), activate contingency procurement or bilateral carrier settlement by Month 8 (2027-06-08).

**Approval Authorities:** European Central Bank (PSD2 oversight); DG MOVE (settlement governance); Commission (final framework approval)

### 5. Regulation Adoption Tracking and Shadow Standards Pre-Work Plan

**ID:** 9efb0ff1-7161-49c8-b445-c7fb2f3b4709

**Description:** Strategic plan for tracking the Commission's proposed Regulation on Digital Booking and Ticketing Services for Rail through Parliament and Council, identifying blocking amendments, and conducting pre-work on binding standards (Month 0–18 = 2026-10-08 to 2028-04-08) without formally binding the programme until adoption. Includes weekly adoption-status updates, scenario planning (adoption Month 9, 11–12, or blocked post-Month 12 = 2027-10-08, 2027-09-08 to 2027-10-08, or 2027-10-08+), contingency standards-acceleration pathways, and decision gates. Audience: DG MOVE, Parliament TRAN/IMCO rapporteurs, member-state transport ministers, arbitration panel, working groups.

**Responsible Role Type:** Governance and Legal Affairs Advisor; Strategy and Programme Director (co-owners)

**Primary Template:** EU Legislative Tracking and Contingency Planning Framework

**Steps:**

- 1. Establish weekly liaison with Parliament TRAN and IMCO rapporteurs and key member-state ministers (Germany, France, Belgium, Austria, Spain) by Month 0.5 (2026-10-23).
- 2. Map the Parliament and Council legislative timeline: identify likely debate windows, amendment deadlines, rapporteur positions, and member-state consensus blockers.
- 3. Conduct a gap analysis (Month 0–2 = 2026-10-08 to 2026-12-08) comparing the Commission's proposed text (May 2026) to OSDM v2.1 and the Pragmatic Foundation scenario, identifying any material divergences on liability, access-term scope, data-sharing rules, or API mandates.
- 4. Commission a shadow standards pre-work team (5–8 FTE, Month 0 = 2026-10-08 onwards) to draft candidate standards on access-term templates, settlement message formats and passenger-rights protocols without formally binding the programme until adoption is confirmed.
- 5. Define three adoption scenarios: (a) adoption by Month 9 (2027-07-08) as proposed, (b) adoption by Month 11–12 (2027-09-08 to 2027-10-08) with text changes, (c) adoption blocked or deferred beyond Month 12 (2027-10-08). For each, specify standards-finalisation timeline and escalation actions.
- 6. Establish decision gates: (a) Month 6 (2027-04-08): if adoption probability drops below 60%, escalate to Commission and assess whether to pause carrier onboarding; (b) Month 8 (2027-06-08): if adoption is not imminent, contract external standards-review consortium for accelerated pre-work; (c) Month 10 (2027-08-08): if adoption is not secured, pause carrier commitments and re-baseline the critical path.
- 7. Prepare a 2-week rapid-deployment standards-finalisation sequence (detailed specs, stakeholder validation, formal vote) for immediate activation post-adoption.

**Approval Authorities:** DG MOVE (tracking and scenario decisions); Commission (liaison authority)

### 6. Carrier Commitment Letter and Non-Compliance Consequences Protocol

**ID:** e3138ca0-02ae-4064-89f6-c2ba5d0b45a8

**Description:** Binding commitment from each participating carrier above EUR 50 million annual cross-border revenue, specifying acceptance of arbitration panel authority, compliance with technical standards and access-term requirements by Month 30 (2029-04-08), and agreement to penalties for non-compliance. Includes the Non-Compliance Consequences Protocol detailing graduated penalties (first violation: written notice and 48-hour cure; second: 0.5% of quarterly through-ticket revenue in escrow; third: 1% of annual cross-border revenue withheld, escalated to Commission). Audience: major carriers (SNCF, Deutsche Bahn, Trenitalia, ÖBB, Renfe, NS, SJ, SNCB and others), DG MOVE, arbitration panel.

**Responsible Role Type:** Carrier Engagement and Stakeholder Manager / Coalition Builder

**Primary Template:** EU Service Agreement Template (adapted for rail sector)

**Secondary Template:** CER Standard Terms and Conditions for Cooperative Initiatives

**Steps:**

- 1. Define the commitment scope: carriers accept arbitration panel rulings as binding, commit to API exposure by Month 30 (2029-04-08), meet data-quality SLAs (inventory freshness, latency, uptime), comply with non-discriminatory access duties, and participate in conformance testing.
- 2. Draft the Non-Compliance Consequences Protocol (Month 0–1 = 2026-10-08 to 2026-11-08): specify the three violation levels, penalties in escrow, and escalation to the Commission.
- 3. Conduct bilateral negotiations with carriers above EUR 50M cross-border revenue (Month 2.5 = 2026-12-23, target): address carrier-specific concerns (IT cost sharing, integration timelines, API design input), offer early API-design participation or co-funding in exchange for signatures.
- 4. Prepare executive-summary talking points for DG MOVE negotiators: emphasise the carrier's role in the through-ticket ecosystem, the competitive advantage of early adoption, the enforcement risk if they refuse.
- 5. Collect signatures by Month 3 (2027-01-08); escalate any major carrier refusing to sign to the Commission for political intervention by Month 2.5 (2026-12-23).
- 6. Publish a summary of signatories (names, dates) to signal broad coalition buy-in and deter holdouts from contesting standards later.

**Approval Authorities:** Carriers themselves (signatories); DG MOVE (witness); Commission (enforcement authority for non-compliance)

### 7. Data Protection Impact Assessment and GDPR Compliance Framework

**ID:** 3c79f33b-24be-43b5-a0b7-cd61a637248d

**Description:** Comprehensive Data Protection Impact Assessment (DPIA) mapping all passenger personally identifiable information (PII) flows among distributors, carriers, payment institutions, clearing entities, and national regulators. Specifies minimum-necessary PII per transaction type (search, booking, refund, dispute), data-residency rules, Standard Contractual Clauses (SCCs) for cross-border transfers, consent and special-category data governance (accessibility attributes), and breach-response protocols. Includes EDPB and national DPA engagement plan to achieve written consensus by Month 4 (2027-02-08). Audience: national DPAs, EDPB, payment institutions, clearing entity, carriers, distributors, legal counsel.

**Responsible Role Type:** Data Protection Impact Assessment and GDPR Compliance Lead

**Primary Template:** GDPR Article 35 Data Protection Impact Assessment Template (European Data Protection Board)

**Secondary Template:** Standard Contractual Clauses Module (EU Commission-approved templates)

**Steps:**

- 1. Map all PII flows (Month 1 = 2026-11-08): identify each transaction type (search, booking, payment, refund, dispute), which data controllers are involved, what PII is transferred, and the legal basis (contract, legitimate interest, consent).
- 2. Identify minimum-necessary PII per flow (Month 1 = 2026-11-08): baseline (name, contact, booking reference, seat/assistance notes) vs. extended (payment details to payment institution only, carrier PII for refund communication only).
- 3. Define data-residency rules (Month 1–2 = 2026-11-08 to 2026-12-08): can carrier data be stored in an EU-wide data centre or must it stay in the carrier's home member state? Propose: any EU member state if encrypted and access-controlled.
- 4. Draft SCC templates (Month 2–3 = 2026-12-08 to 2027-01-08) for carrier-to-carrier data transfers (e.g., Austrian carrier sharing passenger name with Italian carrier for disruption notification) and carrier-to-clearing transfers (booking and revenue data).
- 5. Specify consent and special-category governance (Month 2–3 = 2026-12-08 to 2027-01-08): accessibility data (mobility, health-related assistance) is special-category under GDPR Article 9; propose passive opt-in consent at booking time (if passenger does not explicitly refuse, deemed consented); document in booking confirmation.
- 6. Engage EDPB and 7–9 national DPAs (Austria, Germany, France, Netherlands, Poland, Bulgaria, Romania, Spain, Sweden) by Month 1.5 (2026-11-23); conduct joint review of draft SCC and consent models (Months 2–3 = 2026-12-08 to 2027-01-08); seek written sign-off from at least 8 DPAs by Month 4 (2027-02-08).
- 7. If fewer than 8 DPAs sign off by Month 4 (2027-02-08), escalate to EDPB for expedited guidance (target 4 weeks) and reserve EUR 3–5M from GDPR line for emergency SCC negotiation or re-architecture.
- 8. Embed resolved GDPR rules and SCC details in the binding standards (Month 18 = 2028-04-08).

**Approval Authorities:** European Data Protection Board; National DPAs (written consensus required); Commission (if additional legal instruments needed)

### 8. Budget and Financial Management Framework, Including Contingency Tiers and Mid-Course Review Gates

**ID:** 81ae85a7-b43a-4301-9940-e11ea5fd843f

**Description:** Detailed activity-based cost model specifying EUR 1.5 billion public budget allocation across eight major cost lines (standards/conformance EUR 280M, clearing/settlement EUR 120M, reference distributor EUR 215M, capacity building EUR 100M, consumer rollout EUR 150M, carrier co-funding EUR 290M, data layer EUR 60M, governance/measurement EUR 60M), with EUR 225 million contingency (EUR 215M free). Monthly burn-rate dashboards, Tier 1–3 contingency actions (triggered at 115% of pro-rata spend), mid-course reviews (Months 12, 24 = 2027-10-08, 2028-10-08), and decision gates for supplementary budget authority. Includes sensitivity analysis for hub economics, distributor operating cost, payment-fee exposure, and carrier co-funding demand.

**Responsible Role Type:** Budget Controller and Financial Manager / Contingency Steward

**Primary Template:** EU Programme Budget Framework (multi-year financial planning model)

**Secondary Template:** Activity-Based Budgeting Template (Commission)

**Steps:**

- 1. Commission an independent cost-modelling firm (Month 0.5 = 2026-10-23); deliver detailed forecast by Month 2 (2026-12-08) specifying: carrier co-funding per carrier size (EUR 2–8M per SME, EUR 10–15M per mid-size, EUR 0.5–2M per major), hub opex per hub (EUR 1.2M/year vs. fee revenue EUR 0.73M/year = gap EUR 0.47M/year), reference distributor annual opex (EUR 50–65M/year for full retail, EUR 20–30M/year for reference-implementation only), and payment-institution fee exposure (EUR 80–160M over five years at 0.5–1.0% per transaction).
- 2. Allocate the EUR 1.5 billion cap to the eight cost lines per the canonical facts (standards EUR 280M, clearing EUR 120M, distributor EUR 215M, capacity EUR 100M, consumer EUR 150M, co-funding EUR 290M, data EUR 60M, governance EUR 60M).
- 3. Establish monthly burn-rate dashboards (Month 3 = 2027-01-08) showing cumulative spend vs. pro-rata forecast (EUR 25M/month baseline), with automatic escalation if quarterly spend exceeds 115% of budget line.
- 4. Define contingency tiers and responses: Tier 1 (10–15% overrun): defer consumer-app polish, reduce co-marketing by 20%; Tier 2 (15–25% overrun): reduce carrier co-funding from 20% to 10%, limit hub openings to priority corridors; Tier 3 (>25% overrun): suspend new hub openings, scale capacity building to 3–4 priority member states.
- 5. Schedule mid-course reviews at Months 12 and 24 (2027-10-08, 2028-10-08) to assess cumulative spend, trigger contingency actions, and request supplementary authority from the Commission if needed.
- 6. Secure DG MOVE commitment (Month 3 = 2027-01-08) to seek supplementary budget authority (EUR 100–200M) from the Commission by Month 12 (2027-10-08) if Tier 2 is triggered.
- 7. Include sensitivity analyses: impact on contingency if hub opex is 30% higher, distributor cost runs EUR 60M/year instead of EUR 43M/year, or payment-fee subsidy demand is EUR 25M instead of EUR 15M.

**Approval Authorities:** DG MOVE (budget approval and mid-course decisions); Commission (supplementary authority requests)

### 9. Regional Shared Booking Hub Specification, Procurement and Operational Plan

**ID:** 1d5e829c-f56a-40b9-8785-1cec5d7662f6

**Description:** Specification for 4–6 regional shared booking hubs serving legacy-IT carriers (estimated 12–18 carriers with annual revenue under EUR 50M, booking systems older than 10 years, or IT staff under 10 FTE). Defines hub technology (OSDM translation layer, inventory mapping, API gateway), operational SLAs (99.9% uptime, <2-second latency, <2-hour incident recovery, 10,000+ bookings/day capacity), governance (hub operators, data governance, security), and cost model (EUR 5–8M per hub over five years, with annual opex EUR 1.2M vs. fee revenue EUR 0.73M/year, creating EUR 0.47M/year gap per hub). Includes hub-eligibility criteria, procurement RFP timeline (Month 0.5 = 2026-10-23, awards by Month 3 = 2027-01-08, operational Month 9 = 2027-07-08), pilot testing (Months 15–18 = 2028-01-08 to 2028-04-08), and sunset/cost-recovery gate (Month 48 = 2030-10-08). Audience: hub operators, smaller carriers, regional coordinators, national regulators.

**Responsible Role Type:** Smaller Carriers and Regional Integration Lead / Digital Inclusion Specialist

**Primary Template:** EU Service Provider Agreement Template (IT infrastructure provision)

**Secondary Template:** OSDM Hub Technical Specification (UIC guidance adapted)

**Steps:**

- 1. Define hub eligibility (Month 1 = 2026-11-08): annual cross-border revenue under EUR 50M, or booking system older than 10 years, or IT staff under 10 FTE; estimate 12–18 carriers.
- 2. Specify hub technology (Month 1–2 = 2026-11-08 to 2026-12-08): OSDM-translation layer mapping legacy inventory and business rules to OSDM standards, API gateway, secure data transfer, redundancy (dual data centres per hub).
- 3. Define hub SLAs (Month 2 = 2026-12-08): 99.9% uptime, <2-second latency for distributor queries, <2-hour incident recovery, capacity 10,000+ bookings/day without degradation.
- 4. Establish cost model (Month 2 = 2026-12-08): opex EUR 1.2M/year per hub (staffing, infrastructure, vendor fees), fee revenue EUR 0.73M/year at capacity (EUR 0.1–0.3 per booking), creating EUR 0.47M/year gap; hubs are programme-financed (EUR 5–8M per hub over five years).
- 5. Issue RFP (Month 0.5 = 2026-10-23): 4 priority hubs (one per corridor) + 2 TEN-T hubs reserved; operational start by Month 9 (2027-07-08).
- 6. Award contracts (Month 3 = 2027-01-08); establish technical integration workshops with eligible carriers (Month 4 = 2027-02-08).
- 7. Schedule pilot tests (Months 15–18 = 2028-01-08 to 2028-04-08): 2–3 eligible carriers per hub, 2–4 week dual-run (hub + native), resolve mapping errors before production cutover.
- 8. Establish hub stop threshold: suspend new carrier onboarding to a hub if booking-failure rate exceeds 2% for more than 1 week.
- 9. Define sunset clause: hub operation expires Month 48 (2030-10-08); all carriers must migrate to native OSDM or alternative hub by that date; fee-recovery transition begins Month 36 (2029-10-08) (from programme subsidy toward carrier-paid fees).

**Approval Authorities:** DG MOVE (procurement approval); EU Agency for Railways (technical oversight); Hub operators (implementation)

### 10. Member-State Regulator Capacity-Building and Enforcement-Alignment Programme

**ID:** 936a4696-e816-4c0c-b82c-45430669f4fd

**Description:** Comprehensive plan for aligning 27 member-state rail regulators' capacity, procedures and enforcement of through-ticket duties (non-discrimination, passenger rights, accessibility). Includes capacity-audit findings (Month 2 = 2026-12-08), twinning partnerships pairing strong and weak regulators (Month 4 = 2027-02-08), joint training courses (Months 6–12 = 2027-04-08 to 2027-10-08), shared inspection checklists, and enforcement SLAs (access disputes resolved within 30 days, refund claims within 10 days). Establishes Standing Regulators Committee (Month 1.5 = 2026-11-23) with lead-authority rule for cross-border disputes and escalation to Commission for non-compliance. Budget EUR 10–15M over five years. Audience: national DPAs, national rail regulators, EU Agency for Railways, DG MOVE.

**Responsible Role Type:** Member-State Regulator Capacity and Cross-Border Enforcement Lead

**Primary Template:** EU Capacity-Building and Twinning Framework (used for other transport directives)

**Secondary Template:** Standing Committee Operational Procedures (EU model)

**Steps:**

- 1. Conduct capacity audit (Month 2 = 2026-12-08) of all 27 member-state regulators, assessing staff, budget, IT systems, enforcement experience, and data-protection maturity.
- 2. Identify 8–12 weaker-capacity regulators (Poland, Bulgaria, Romania, Hungary, Slovakia, Slovenia, Croatia, Malta) for targeted support.
- 3. Establish Standing Regulators Committee (Month 1.5 = 2026-11-23) with monthly meetings, escalation authority for cross-border disputes, and lead-authority recognition rule (one regulator takes the lead on a dispute; all others recognise its ruling without re-litigation).
- 4. Design twinning partnerships (Month 4 = 2027-02-08): pair strong regulators (France, Germany, Netherlands, Austria, Sweden, Belgium) with weak ones; specify 3–4 week joint training courses on access enforcement, data-quality auditing, complaint handling.
- 5. Develop shared inspection checklists and auditing procedures (Month 8 = 2027-06-08) covering access-term compliance, non-discrimination practices, and data-quality validation.
- 6. Define enforcement SLAs (Month 6 = 2027-04-08): all access-related disputes resolved within 30 days (not exceeding 60 days); all refund claims processed within 10 days. Include penalties for non-compliance (EUR 50K–EUR 500K fines for consistent regulator non-enforcement).
- 7. Schedule quarterly joint-enforcement reviews starting Month 12 (2027-10-08) to share case findings, align interpretations and escalate systemic issues to the Commission.
- 8. Reserve EUR 10–15M over five years for training, travel, and twinning coordination; report progress at monthly Steering Committee meetings.

**Approval Authorities:** EU Agency for Railways (coordination authority); Commission (enforcement escalation); Member-state transport ministries (commitment to regulator participation)

### 11. Consumer Product and Public Reference Distributor Specification

**ID:** a5607fb2-0fab-4779-9718-5ec9b0de3016

**Description:** Specification for the public reference distributor app and multilingual booking interface, defining the killer application (guaranteed-connection through-ticket, air-rail city-pair, or assisted-travel journey), user experience, accessibility (WCAG 2.1 AA), customer support (sub-1-hour response time for critical issues, 24+ languages), and rollout schedule. Includes MVP pilot design (Month 9 = 2027-07-08, one corridor), public launch (Month 15 = 2028-01-08, four corridors by Month 27 = 2029-01-08), success metrics (satisfaction ≥4.0/5, booking-failure rate <0.5%), and operating cost model (EUR 43–65M/year, or EUR 20–30M/year if reference-implementation only). Audience: consumers, commercial distributors (Trainline, Omio), carriers, accessibility advocates.

**Responsible Role Type:** Consumer Product and App Development Lead / Digital User Experience Director

**Primary Template:** Consumer Product Requirements and Design Document

**Secondary Template:** WCAG 2.1 AA Accessibility Compliance Checklist

**Steps:**

- 1. Commission customer research (Month 1 = 2026-11-08) to validate three candidate flagship products: (a) guaranteed-connection through-ticket (4-hour reroute, 10-day refund, single contact), (b) air-rail city-pair (fare competitiveness vs. flight), (c) assisted-travel journey (confirmed assistance, priority seating, platform handover). Test willingness to pay via conjoint analysis; select winning product by Month 6 (2027-04-08).
- 2. Define the killer application product spec (Month 6 = 2027-04-08): target audience, key features, competitive positioning, price point relative to alternatives.
- 3. Design the MVP for one-corridor pilot (Month 6–8 = 2027-04-08 to 2027-06-08): user flows (search, booking, payment, refund, help), wireframes, accessibility requirements (WCAG 2.1 AA).
- 4. Build and test the MVP on one corridor (Month 9 = 2027-07-08) with 50–100 real users; conduct unmoderated usability testing (weekly for 4 weeks, Months 9–10 = 2027-07-08 to 2027-08-08); track NPS (Net Promoter Score) and satisfaction weekly.
- 5. Iterate based on feedback (Months 10–12 = 2027-08-08 to 2027-10-08); release updates fortnightly; if satisfaction is below 3.8/5 at Month 12 (2027-10-08), extend MVP phase 4–6 weeks and delay public launch.
- 6. Scale to full multilingual support and platform scaling (Months 12–15 = 2027-10-08 to 2028-01-08); launch public app Month 15 (2028-01-08) with phased rollout (one corridor initially, full four corridors by Month 27 = 2029-01-08).
- 7. Establish customer-support operations: target sub-1-hour response time for critical issues, tiered escalation (FAQ, human support, dispute panel), support in 24+ languages.
- 8. Include accessibility testing: quarterly WCAG 2.1 AA audits (external firm) and monthly screen-reader testing with persons with visual impairments.
- 9. Monitor app ratings quarterly (target >4.0/5 stars at Month 18 = 2028-04-08); if satisfaction falls below 4.0, pause rollout and conduct 4–6 week redesign.

**Approval Authorities:** DG MOVE (product approval); Steering Committee (launch gates at Months 15, 27 = 2028-01-08, 2029-01-08); BEUC and disability-rights representatives (accessibility sign-off)

### 12. Passenger-Rights Backstop and Liability Allocation Framework

**ID:** 72109965-2674-42da-b09e-c99766f9ced1

**Description:** Operational design for rerouting, care, and refund obligations when a through-ticket's connection is missed due to carrier delay or infrastructure failure. Specifies single point of contact (selling distributor), decision and payment timelines (<4 hours reroute decision, <10 days refund), fault-allocation protocol (which carrier is responsible when multiple carriers are involved), cost recovery via accredited payment providers, and a pooled guarantee fund (EUR 30–40M reserve, or 8–12% of tickets estimated at EUR 10–40M over five years). Includes dispute-resolution panel (5-day ruling), insurance requirements (EUR 2–10M errors-and-omissions per entity), and audit/compliance procedures. Aligns with revised EU Regulation 1371/2007 and the programme's non-discrimination goals. Audience: distributors, carriers, payment institutions, regulators, passengers.

**Responsible Role Type:** Cross-Border Rail Passenger Rights and Liability Framework Specialist

**Primary Template:** EU Rail Passenger Rights Operational Procedures (Regulation 1371/2007 adapted)

**Secondary Template:** Multi-Operator Liability Allocation Template (ICC Incoterms model adapted)

**Steps:**

- 1. Commission an actuarial study (Month 2 = 2026-12-08) estimating claim rate (baseline 3–5%, stress case 8–12%), average claim cost (EUR 50–200), and total exposure (EUR 10–40M over five years).
- 2. Draft the Fault-Allocation Protocol (Month 2–3 = 2026-12-08 to 2027-01-08): specify who makes the fault decision (e.g. independent arbiter or the responsible carrier initially with appeal to dispute panel), timeline (24–48 hours), and the cost-allocation logic (which carrier reimburses the distributor's refund advance).
- 3. Define single-point-of-contact procedures (Month 3 = 2027-01-08): the selling distributor is the passenger-facing contact for rerouting and refund; the distributor advances cost and recovers from liable carrier(s) via accredited payment providers.
- 4. Specify response timelines: rerouting decision within 4 hours of notification (automatic for missed connections due to the programme's API integration); refund decision within 10 days.
- 5. Design dispute-resolution panel (Month 3 = 2027-01-08): 5–7 members (rotating carrier and distributor representatives), empowered to rule on contested claims within 5 business days.
- 6. Define the pooled guarantee fund (Month 3 = 2027-01-08): EUR 30–40M reserve (or 8–12% claim-rate estimate) to cover unrecovered first-level refunds if a liable carrier is insolvent or disputes the refund; administer via the clearing entity.
- 7. Require all operational entities (distributors, hubs, payment institutions, clearing entity) to carry errors-and-omissions liability insurance (EUR 2–10M minimum, EUR 5M target) by Month 4 (2027-02-08); verify coverage before go-live.
- 8. Pilot the refund process on one corridor (Paris–Brussels–Amsterdam) by Month 15 (2028-01-08): measure claim volume, resolution time, dispute rate; if resolution time exceeds 10 days for >5% of claims or dispute rate exceeds 3%, increase the guarantee fund by EUR 10–20M by Month 18 (2028-04-08).
- 9. Embed the framework and SLAs in the binding standards (Month 18 = 2028-04-08); include compliance audits in quarterly regulator reviews (starting Month 12 = 2027-10-08).

**Approval Authorities:** Commission (through binding standards Month 18 = 2028-04-08); Member-state regulators (enforcement); Steering Committee (guarantee-fund adjustments)

### 13. Measurement Baseline, Through-Ticket Definition and Evaluation Methodology

**ID:** 2648beee-5f21-41d1-b18a-d06f1414aa1a

**Description:** Operational definition of 'through-ticket' (single booking reference + single payment + continuity-of-journey rights on a multi-carrier journey), baseline survey methodology (Months 0–2 = 2026-10-08 to 2026-12-08), and independent counterfactual evaluation design to separate programme effects from fuel prices and aviation-tax policy. Specifies mandatory monthly reporting by carriers and distributors (starting Month 18 = 2028-04-08), quarterly aggregated dashboards, interim gates (15% through-ticket share by Month 24 = 2028-10-08), and attribution analysis for the three headline targets (40% through-ticket share, halved complaints, modal shift 5–15%). Budget EUR 5–10M over five years for baseline, evaluator contract, and analytics. Audience: Steering Committee, carriers, distributors, Parliament, Commission.

**Responsible Role Type:** Measurement, Evaluation and Evidence Lead / Impact Analytics Director

**Primary Template:** EU Evaluation Framework (Regulation (EU) 1303/2013 adapted)

**Secondary Template:** Counterfactual Evaluation Design Template (World Bank guidance)

**Steps:**

- 1. Define 'through-ticket' operationally (Month 2 = 2026-12-08): single booking reference + single payment + continuity-of-journey rights (rerouting/refund if connection missed) on a multi-carrier journey, sold via any distributor or operator platform. Lock this definition; do not re-interpret later.
- 2. Conduct baseline survey (Months 0–2 = 2026-10-08 to 2026-12-08) asking carriers, distributors and airports for current cross-border sales volumes, complaint rates and modal-split estimates (with confidentiality protections).
- 3. Validate and publish the baseline (Month 9 = 2027-07-08): baseline through-ticket share, complaint rate (e.g., 3 complaints per 1,000 bookings), and modal-split estimate on the four priority corridors.
- 4. Commission an independent external evaluator (Month 3 = 2027-01-08) to design a counterfactual evaluation: compare through-ticket adoption on priority corridors to control routes outside the rollout, using difference-in-differences or propensity-score matching to isolate programme effects from fuel prices, aviation taxes and capacity changes. Deliver methodology by Month 9 (2027-07-08).
- 5. Mandate carrier and distributor reporting (starting Month 18 = 2028-04-08): monthly through-ticket volumes and complaint counts, aggregated and published quarterly with a 1-month lag to protect commercial sensitivity.
- 6. Establish interim gates: 15% through-ticket share by Month 24 (2028-10-08) (proposed threshold); if missed, escalate to Steering Committee and assess mid-course corrections (e.g., increase co-marketing budget, distributor incentives, or activate killer-application contingencies).
- 7. Publish quarterly progress dashboards (starting Month 18 = 2028-04-08) tracking: through-ticket share (target 40% by Month 60 = 2031-10-08), complaints baseline vs. target (halved by Month 60 = 2031-10-08), and modal-shift estimate (planning range 5–15%).
- 8. Conduct mid-programme evaluation (Months 30–36 = 2029-04-08 to 2029-10-08) assessing interim success, informing TEN-T extension scope and post-Month 60 (2031-10-08) sustainability decisions.
- 9. Allocate EUR 5–10M within the programme budget for baseline survey, evaluator contract, and analytics infrastructure.

**Approval Authorities:** Steering Committee (baseline approval and interim gates); Commission (final evaluation results)

### 14. Accessibility Integration and Assistance-Delivery Framework

**ID:** a090fb3f-a2cb-489f-9834-a1ca613d9085

**Description:** Operational design for integrating passengers with reduced mobility into the through-ticket ecosystem, covering booking-system accessibility (WCAG 2.1 AA), assistance-request confirmation timelines (within 24 hours, not 48 hours), cross-border assistance handovers, accessibility-data governance (GDPR special-category handling), and performance metrics (assistance confirmation rate >90%, delivery rate >95%, accessibility-related complaints <2%). Includes accessible-station and rolling-stock registry (real-time updates on platform lifts, accessible toilets, accessible seating availability, staff capability), quarterly independent audits, and engagement with BEUC and national disability-rights organizations. Requirements locked in the binding standards (Month 18 = 2028-04-08). Budget EUR 10–15M over five years for infrastructure and support. Audience: passengers with mobility limitations, carriers, stations, accessibility advocates, regulators.

**Responsible Role Type:** Assistance Booking and Accessibility Integration Lead (proposed new role, or joint responsibility with Consumer Product Lead)

**Primary Template:** EU Accessibility Directive Implementation Framework (Directive 2019/882 adapted)

**Secondary Template:** WCAG 2.1 AA Accessibility Technical Standard

**Steps:**

- 1. Establish an Accessibility Working Group (Month 0 = 2026-10-08) with BEUC, national disability-rights organizations, carriers and accessibility experts.
- 2. Define accessibility requirements (Month 2–4 = 2026-12-08 to 2027-02-08): booking-interface accessibility (WCAG 2.1 AA), assistance-request/confirmation timelines (within 24 hours), station/rolling-stock accessibility data (lift, accessible toilet, accessible seating availability, staff capability), and cross-border assistance handovers.
- 3. Develop the public-reference distributor app with accessibility as a core feature from MVP (Month 9 = 2027-07-08): keyboard navigation, screen-reader support, high-contrast modes, real-time assistance-request tracking.
- 4. Build an accessibility-data registry (Month 9–15 = 2027-07-08 to 2028-01-08) capturing station and rolling-stock accessibility attributes; require carriers to publish updates within 5 days of any change.
- 5. Design assistance-confirmation and delivery procedures (Month 3 = 2027-01-08): passenger requests assistance at booking, carrier confirms or proposes alternative within 24 hours (before payment completes), passenger has binding commitment of assistance. Specify handover procedures at connecting stations (who is responsible, what support is provided).
- 6. Define accessibility SLAs (Month 4 = 2027-02-08): assistance-confirmation rate >90%, assistance-delivery rate >95% (audited quarterly by external firm), accessibility-related complaint rate <2%.
- 7. Establish quarterly independent audits (external accessibility-testing firm, 1 FTE, EUR 0.5–1M/year) sampling 50–100 assisted journeys per quarter per corridor; unannounced spot-checks on station and rolling-stock accessibility.
- 8. Include accessibility metrics in conformance checklist (Month 4 = 2027-02-08) and the binding standards (Month 18 = 2028-04-08); tie carrier conditional funding to accessibility SLA compliance (if delivery rate falls below 95%, withhold disbursement tranches).
- 9. Allocate EUR 10–15M over five years for accessibility infrastructure, platform updates, train-on-board systems, and quarterly auditing.
- 10. Engage BEUC and disability-rights representatives in quarterly review forums (starting Month 9 = 2027-07-08) to validate accessibility usability and escalate any delivery failures.

**Approval Authorities:** Steering Committee (accessibility requirements approval); Carriers and stations (implementation); BEUC and disability-rights organizations (user advocacy sign-off)

### 15. Competence and Compliance Audit Framework and Test-Lab Accreditation

**ID:** dd2bdb59-9b7d-4e05-8712-9a399bb57ef7

**Description:** Specification for independent conformance testing and audit procedures ensuring that participating carriers, hubs, payment institutions, distributors, and data-layer components meet the binding standards (Month 18 = 2028-04-08 onwards). Includes test-lab accreditation criteria (ISO 17025 compliance, OSDM expertise, independent governance), test-harness design (API correctness, data-quality validation, performance benchmarks), carrier-readiness assessment (with distinct gates for major carriers Month 24 = 2028-10-08, smaller carriers Month 30 = 2029-04-08), and non-compliance escalation (if a carrier fails conformance by Month 30 = 2029-04-08, suspend through-ticket sales on affected routes pending remediation). Budget EUR 50–80M within the standards/conformance EUR 280M allocation. Audience: test labs, carriers, hubs, payment institutions, national regulators, DG MOVE.

**Responsible Role Type:** Chief Technical Standards Officer (co-owner with test-lab management)

**Primary Template:** ISO/IEC 17025:2017 Accreditation Framework (adapted for API and data-quality testing)

**Secondary Template:** EU Conformance Testing Standard (CEN/CENELEC model)

**Steps:**

- 1. Define test-lab accreditation criteria (Month 4–6 = 2027-02-08 to 2027-04-08): ISO 17025 compliance, demonstrated OSDM expertise, independent governance (no conflict of interest with carriers or distributors), capacity to test 50+ carriers over 18 months.
- 2. Issue a call for test-lab applications (Month 6 = 2027-04-08) targeting 4–6 independent laboratories across Europe; award accreditation by Month 9 (2027-07-08).
- 3. Design test harnesses (Months 4–9 = 2027-02-08 to 2027-07-08) covering: (a) API correctness (proper OSDM schema, error handling, response codes), (b) data-quality validation (inventory freshness, no double-counting of seats, correct fares), (c) performance benchmarks (p95 latency under 2 seconds, uptime 99.95%, throughput at least 500 req/s per corridor), (d) accessibility compliance (WCAG 2.1 AA, assistance-confirmation timelines), (e) GDPR compliance (data-handling, SCCs, consent).
- 4. Publish detailed test-harness documentation (Month 9 = 2027-07-08) so carriers understand expectations before scheduling tests.
- 5. Establish carrier-readiness gates (Month 12 = 2027-10-08 onwards): major carriers (SNCF, DB, ÖBB, Trenitalia, Renfe, NS, SJ, SNCB) must achieve conformance certification by Month 24 (2028-10-08); smaller carriers and hub-eligible operators by Month 30 (2029-04-08).
- 6. Schedule conformance tests (rotating across four test labs): major carriers Months 12–24 (2027-10-08 to 2028-10-08), smaller carriers Months 18–30 (2028-04-08 to 2029-04-08).
- 7. Publish quarterly conformance status (starting Month 12 = 2027-10-08): which carriers have passed, which are in progress, and which have failed and need remediation.
- 8. Define non-compliance escalation: if a carrier fails conformance by Month 30 (2029-04-08), suspend through-ticket sales on affected routes (or require mandatory hub use) pending remediation; escalate to the Commission for enforcement action.
- 9. Allocate EUR 50–80M within the standards/conformance EUR 280M line for test-lab operations, test-harness maintenance, and carrier support.

**Approval Authorities:** EU Agency for Railways (test-lab accreditation); Arbitration Panel (standards validation); DG MOVE (non-compliance escalation)

### 16. Post-Month 60 (2031-10-08) Sustainability Transition and Operating-Model Decision

**ID:** 89c93787-49f4-4e15-9af6-771732ceeb2a

**Description:** Strategic plan for transitioning the programme from the five-year public-coordination phase (Months 0–60 = 2026-10-08 to 2031-10-08) to sustainable operations post-Month 60 (2031-10-08). Evaluates three models: (a) cost-recovery fees on distributors and carriers (charging EUR 0.2–0.5 per booking for data-layer and clearing; hub usage fees; distributor licensing), (b) member-state co-funding (carriers' home states commit ongoing funding for regulator capacity and data-layer operations), (c) phased shutdown (public distributor and some hubs sunset; core OSDM APIs and data layer are handed off to the EU Agency for Railways for long-term stewardship). Estimates recurring run costs at EUR 45M/year (distributor EUR 43M + hub gap EUR 1.9M) plus EUR 10–20M/year for data-layer and regulator costs. Establishes a Sustainability Task Force (Month 36 = 2029-10-08) and a decision gate (Month 48 = 2030-10-08) to lock the chosen model before implementation (Month 55 = 2031-05-08 onwards). Audience: DG MOVE, member-state transport ministers, carriers, distributors, the EU Agency for Railways, Steering Committee.

**Responsible Role Type:** Strategy and Programme Director (co-owner with Finance Controller)

**Primary Template:** EU Long-Term Sustainability Strategy Template

**Steps:**

- 1. Model three sustainability scenarios in Month 36 (2029-10-08): (a) cost-recovery (distributors/carriers charged per-booking or licence fees; data-layer runs on trading/settlement fees), (b) member-state co-funding (27 member states commit EUR 1–2M/year each for regulator capacity and shared infrastructure), (c) phased sunset (public distributor closes Month 60 = 2031-10-08; hubs wind down; core OSDM APIs are transferred to a permanent institution like the EU Agency for Railways).
- 2. Quantify the cost and revenue model for each scenario: recurring opex (distributor EUR 43M/year, data-layer EUR 8–10M/year, regulator coordination EUR 5–10M/year), fee/revenue sources (per-booking charges EUR 0.2–0.5, licence fees for hubs and distributors, member-state appropriations), sustainability timeframe (break-even, surplus, or shortfall by Month 120 = 2036-10-08).
- 3. Establish a Sustainability Task Force (Month 36 = 2029-10-08) with representatives from DG MOVE, member-state transport ministers, carriers, distributors, the EU Agency for Railways, and the Steering Committee.
- 4. Conduct a mid-programme evaluation (Months 30–36 = 2029-04-08 to 2029-10-08) assessing programme outcomes (40% through-ticket share status, complaints reduction, modal shift, distributor/passenger satisfaction) and identifying which components have permanent value vs. temporary support.
- 5. Draft transition plans for each component (Month 42 = 2030-04-08): if the data layer is to be transferred to the EU Agency for Railways, specify governance transfer, budget transition, and staffing handoff. If hubs are to operate on fee recovery, define the fee structure and carrier-adoption path.
- 6. Decide the chosen sustainability model (Month 48 = 2030-10-08) and obtain written commitment from all stakeholder groups (DG MOVE, member-state ministries, major carriers, distributors, and the EU Agency for Railways).
- 7. Implement the transition (Month 55 = 2031-05-08 onwards) with a 5-month phase-in (Months 55–60 = 2031-05-08 to 2031-10-08) to minimize service disruptions.
- 8. Document lessons learned and best practices (Month 60 = 2031-10-08) for potential replication in other EU transport modes or regions.

**Approval Authorities:** Commission (sustainability model approval); Member-state transport ministers (co-funding commitment); Steering Committee (implementation oversight)

### 17. Stakeholder Engagement, Communication and Change-Management Plan

**ID:** 93a92fb9-fba1-4016-8d3a-0f270ddc1880

**Description:** Comprehensive plan for engaging 25+ carriers, distributors, 27 national regulators, disability-rights organizations, Parliament, member-state ministries and the travelling public throughout the programme. Specifies communication channels (quarterly stakeholder forums, bilateral carrier negotiations, public consultation events), key messages (non-discrimination, passenger protection, convenient cross-border travel), milestone announcements, and change-management support for carriers and regulators. Includes crisis-communication protocols for operational failures (API outages, hub failures, booking-failure spikes, passenger incidents) and political escalation procedures. Budget EUR 10–15M over five years (within the governance/measurement EUR 60M allocation). Audience: all stakeholders listed above.

**Responsible Role Type:** Stakeholder Alignment and Carrier Commitment Lead; Communications and Reputational Risk Manager (joint)

**Primary Template:** EU Stakeholder Engagement and Communications Framework

**Secondary Template:** EU Crisis Communication Protocol (Commission guidance)

**Steps:**

- 1. Identify stakeholder segments (Month 0 = 2026-10-08): major carriers, smaller carriers, distributors, regulators, Parliament, member-state ministers, BEUC, disability-rights bodies, consumers, media.
- 2. Develop tailored messages for each segment (Month 1 = 2026-11-08): (a) carriers: efficiency gains, access to new markets, reduction of unilateral distributor control; (b) distributors: early API access, margin support, co-marketing funds; (c) passengers: single ticket, continuity protection, reduction in barriers to cross-border travel; (d) regulators: clearer enforcement rules, capacity support, consistent application across borders; (e) Parliament: environmental benefits, competition support, consumer choice.
- 3. Establish regular engagement forums (Month 1 = 2026-11-08): quarterly roundtables with major carriers (CER hosting), monthly Standing Regulators Committee meetings, quarterly Steering Committee meetings (with Parliament and member-state representation), biannual public consultation events.
- 4. Plan milestone announcements (Month 2 = 2026-12-08): Council delegation (Month 2 = 2026-12-08), carrier Commitment Letters (Month 3 = 2027-01-08), Regulation adoption (Month 9 = 2027-07-08 target), binding standards publication (Month 18 = 2028-04-08), API mandate achievement (Month 30 = 2029-04-08), full four-corridor through-ticketing (Month 60 = 2031-10-08).
- 5. Design change-management support for carriers (Month 2–3 = 2026-12-08 to 2027-01-08): workshops on OSDM, access-term compliance, settlement procedures; mentoring for smaller carriers; recognition/awards for early adopters.
- 6. Draft a crisis-communication protocol (Month 2 = 2026-12-08): for API outages (notify distributors and passengers within 15 minutes), hub failures (within 30 minutes), booking-failure spikes (within 1 hour), passenger incidents (within 2 hours). Specify escalation to DG MOVE, media statement template, and stakeholder notification procedures.
- 7. Conduct quarterly stakeholder satisfaction surveys (Month 3 = 2027-01-08 onwards) assessing buy-in; if satisfaction drops below 70% for any segment, trigger targeted outreach (1-on-1 interviews, dedicated focus group, adjustment of engagement approach).
- 8. Allocate EUR 10–15M for communications staff, events, printed materials, media outreach, and digital platforms (website, newsletter, Q&A forums).

**Approval Authorities:** Steering Committee (engagement strategy approval); DG MOVE (crisis-communication protocols); Communications Director (day-to-day execution)

### 18. Regulation Adoption Risk Register and Contingency Scenario Plans (Scenario A: On-Time Adoption Month 9 = 2027-07-08; Scenario B: Adoption Months 11–12 = 2027-09-08 to 2027-10-08 with Text Changes; Scenario C: Adoption Blocked or Deferred Beyond Month 12 = 2027-10-08)

**ID:** c7b2e447-b630-46fa-94bf-00c3a8363573

**Description:** Strategic contingency planning document mapping three adoption scenarios for the Commission's proposed Regulation on Digital Booking and Ticketing Services. Scenario A (on-time Month 9 = 2027-07-08) proceeds with 9-month standards window; Scenario B (Months 11–12 = 2027-09-08 to 2027-10-08 with amendments) compresses standards to 6–7 months and adapts to text divergences; Scenario C (adoption blocked) pauses the programme and resets the critical path. Each scenario includes decision triggers, resource activation, stakeholder communications and revised milestone dates. Owned by DG MOVE with input from the arbitration panel and Parliament liaison. Due Month 2 (2026-12-08) as a working document.

**Responsible Role Type:** Governance and Legal Affairs Advisor; Strategy and Programme Director

**Primary Template:** EU Risk Management and Scenario-Planning Framework

**Steps:**

- 1. Map the three adoption scenarios (Month 1 = 2026-11-08) based on Parliament and Council negotiation timelines, member-state political signals, and rapporteur public statements.
- 2. For Scenario A (on-time Month 9 = 2027-07-08): outline the standard timeline (Months 4–18 = 2027-02-08 to 2028-04-08) and confirm all prerequisite gates (Council delegation, carrier Commitment Letters, hub awards, payment accreditation).
- 3. For Scenario B (Months 11–12 = 2027-09-08 to 2027-10-08 with text changes): design a 6–7 month standards acceleration (detailed specs Month 10 = 2027-08-08, stakeholder validation Months 10–16 = 2027-08-08 to 2028-02-08, formal vote Month 17 = 2028-03-08, publication Month 18 = 2028-04-08), specify likely text divergences (liability, data scope, API mandate scope) and required rework.
- 4. For Scenario C (adoption blocked): outline programme pause (Month 13 onwards = 2027-11-08+), rebaselining window (Months 13–21 = 2027-11-08 to 2028-09-08), and reset decision on whether to proceed with shadow standards or await new Commission proposal.
- 5. Define decision gates (Month 6 = 2027-04-08: adoption probability assessment; Month 8 = 2027-06-08: standards consortium contingency activation; Month 10 = 2027-08-08: Scenario C pause decision) with assigned owners and escalation procedures.
- 6. Publish as a working document (Month 2 = 2026-12-08) and update monthly (Months 3–12 = 2027-01-08 to 2027-10-08) as adoption tracking progresses.

**Approval Authorities:** DG MOVE (scenario decisions); Steering Committee (monthly review)

### 19. Killer Application Product Requirements and Competitive Positioning Document

**ID:** a83ddcb8-0ac9-4004-8570-aa5e29a9d9fc

**Description:** Specification of the flagship through-ticket product (guaranteed-connection ticket, air-rail city-pair offer, or assisted-travel journey) that will drive adoption and modal shift. Includes target customer segment, core features (reroute timeline, refund guarantee, reduction-card recognition, assistance confirmation), competitive positioning vs. alternatives (flying, separate tickets), willingness-to-pay validation, and pilot launch plan (Month 9 = 2027-07-08, one corridor, public app Month 15 = 2028-01-08). Based on customer research conducted Months 1–3 (2026-11-08 to 2027-01-08). Document is created by the consumer-product team and shared with carriers, distributors and the Steering Committee by Month 6 (2027-04-08).

**Responsible Role Type:** Consumer Product and App Development Lead / Digital User Experience Director; Strategy and Programme Director

**Primary Template:** Consumer Product Strategy and Requirements Document

**Steps:**

- 1. Conduct customer research (Months 1–3 = 2026-11-08 to 2027-01-08) with focus groups on three candidate products: guaranteed-connection, air-rail city-pair, assisted-travel. Test feature preferences, price sensitivity, and willingness to switch from alternative modes.
- 2. Analyse research findings (Month 4 = 2027-02-08) and select the winning product that shows highest potential for uptake and competitive differentiation.
- 3. Develop the product spec (Months 4–6 = 2027-02-08 to 2027-04-08): customer journey (discovery, booking, payment, refund, help), core features, pricing strategy, positioning statement, success metrics (adoption rate, satisfaction, modal-shift attribution).
- 4. Share the spec with major carriers and distributors for feedback (Month 5 = 2027-03-08); incorporate their input on feasibility and incentives.
- 5. Lock the product spec by Month 6 (2027-04-08) and begin MVP design (Months 6–9 = 2027-04-08 to 2027-07-08).

**Approval Authorities:** Steering Committee (product selection approval); Carriers and distributors (feasibility sign-off)

### 20. Competitive Intelligence and Airline Response Scenario Planning

**ID:** 175e29c8-8b45-495c-b0c3-ea8531fee15a

**Description:** Market intelligence document tracking airline pricing, capacity and competitive strategies on the four priority corridors (Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin) to forecast how airlines will respond to through-ticket competition. Includes scenario planning: if through-fares are EUR 70–90 vs. airline EUR 50–70, what is airlines' likely pricing and capacity response? Will they add flights, cut fares, or target premium segments? Needed to validate the modal-shift planning range (5–15%) and to inform commercial strategy for the killer application. Updated quarterly (Months 6, 9, 12, 15 onwards = 2027-04-08, 2027-07-08, 2027-10-08, 2028-01-08 onwards). Audience: strategy team, killer-application product manager, financial modeller.

**Responsible Role Type:** Strategy and Programme Director; Consumer Product and App Development Lead

**Primary Template:** Competitive Intelligence Report

**Steps:**

- 1. Collect baseline data (Months 0–2 = 2026-10-08 to 2026-12-08) on current airline pricing, frequency, load factors and capacity on the four priority corridors (via IATA, airline websites, booking data).
- 2. Model through-fare competitiveness (Month 3 = 2027-01-08) under three scenarios: (a) baseline fuel/tax policies, (b) fuel +30% or aviation-tax introduction, (c) airlines cut capacity 10–20%.
- 3. Forecast airline responses (Month 4 = 2027-02-08): price elasticity, capacity adjustments, premium-segment focus.
- 4. Update quarterly (Months 6, 9, 12, 15 onwards = 2027-04-08, 2027-07-08, 2027-10-08, 2028-01-08 onwards) with actual pricing and capacity data and adjust modal-shift forecasts if needed.
- 5. Share findings with the Steering Committee and killer-application team to inform marketing and product positioning.

**Approval Authorities:** Steering Committee (quarterly review)

### 21. Hub Readiness Audit and Dual-Run Pilot Testing Protocol

**ID:** 41f43cf2-6300-4a3e-8403-87d4a0850b72

**Description:** Detailed audit protocol for validating each regional hub's readiness to go live (operational Month 9 = 2027-07-08) and a standard 2–4 week dual-run pilot procedure (Months 15–18 = 2028-01-08 to 2028-04-08) for testing the hub's inventory mapping against each eligible carrier's native system. Includes test criteria (zero booking-failure rate during pilot, acceptable inventory parity, API latency <2 seconds), escalation procedures if errors are found, and recovery timelines. Stop threshold: if a hub's failure rate exceeds 2% during production, suspend new carrier onboarding immediately. Document prepared by the hub programme lead (Smaller Carriers and Regional Integration Lead) by Month 3 (2027-01-08) and updated as each pilot completes.

**Responsible Role Type:** Smaller Carriers and Regional Integration Lead / Digital Inclusion Specialist

**Primary Template:** System Testing and Readiness-Assessment Protocol

**Steps:**

- 1. Define hub readiness criteria (Month 2 = 2026-12-08): 99.9% uptime achieved in pre-production, API latency <2 seconds (p95), inventory mapping tested against at least 2 legacy carriers without errors.
- 2. Design the dual-run pilot procedure (Month 2–3 = 2026-12-08 to 2027-01-08): run hub in parallel with each carrier's native system for 2–4 weeks, compare availability and booking outcomes, log all discrepancies, measure API latency and uptime, capture carrier and distributor feedback.
- 3. Define acceptance criteria for each pilot: <0.1% booking-failure rate (not 0.5%; propose tighter threshold for early confidence), zero inventory parity errors, API response time <2 seconds in 95% of requests.
- 4. Schedule pilots (Months 15–18 = 2028-01-08 to 2028-04-08): 2–3 carriers per hub, staggered so lessons from early pilots inform later ones.
- 5. Document outcomes and escalation triggers: if errors are found, specify root-cause analysis, fix timeline and rework testing before production cutover.
- 6. Update the protocol after each pilot (by Month 18 = 2028-04-08) to incorporate lessons learned.

**Approval Authorities:** Smaller Carriers and Regional Integration Lead (approval of readiness); Steering Committee (escalation if threshold is breached)

### 22. Payment-Institution Accreditation Evaluation Framework and Selection Criteria

**ID:** 175a48cb-77fd-4ad6-9881-c5975d12c3fb

**Description:** Detailed evaluation framework for assessing applicants to the accredited payment-institution role, specifying minimum criteria (PSD2 licensing, multi-currency support, SLA guarantees, error handling, dispute resolution) and scoring methodology. Accreditation decision due Month 8 (2027-06-08). Framework includes financial stability checks (to prevent provider failure during operations), reference checks (prior settlement experience, customer references), and contractual requirements (redundancy, failover protocols, penalty clauses for SLA breach). Prepared by the clearing-mechanism designer (Clearing and Settlement Mechanism Designer / Payment Systems Specialist) by Month 2 (2026-12-08).

**Responsible Role Type:** Clearing and Settlement Mechanism Designer / Payment Systems Specialist

**Primary Template:** Vendor Evaluation and Selection Framework (EU procurement model)

**Steps:**

- 1. Define minimum accreditation criteria (Month 1 = 2026-11-08): PSD2 licence (mandatory), multi-currency support for EUR, DKK, SEK, CHF, PLN, CZK, HUF, BGN, RON; settlement cycle <48 hours; dispute resolution <5 business days; uptime SLA 99.95%; throughput ≥10,000 transactions/day.
- 2. Design financial stability and reference checks (Month 1–2 = 2026-11-08 to 2026-12-08): verify capital adequacy (Tier 1 ratio >12%, industry standard), review audit reports, obtain customer references from major payment flows.
- 3. Draft contractual requirements (Month 2 = 2026-12-08): redundancy (dual data centres, failover <30 minutes), error handling (chargebacks, duplicates, reversal protocols), penalty clauses (0.5–1% of monthly fees for SLA breach), insurance requirements (EUR 5–10M cyber liability).
- 4. Prepare the evaluation scoring rubric (Month 2 = 2026-12-08): weight criteria (e.g., PSD2 compliance 20%, multi-currency 20%, SLAs 20%, stability 20%, cost 20%; adjust as needed).
- 5. Issue the formal RFP (Month 2 = 2026-12-08) with the evaluation framework attached; collect applications Month 2–6 (2026-12-08 to 2027-04-08).
- 6. Evaluate applicants (Months 6–8 = 2027-04-08 to 2027-06-08) and publish accreditation decisions by Month 8 (2027-06-08).

**Approval Authorities:** Clearing-mechanism designer (evaluation authority); DG MOVE (final accreditation approval)

## Documents to Find

### 1. Commission Proposed Regulation on Digital Booking and Ticketing Services for Rail (May 2026) - Final Adopted Text

**ID:** 6c2661ec-f1a0-4164-9b41-2257b33f7440

**Description:** The foundational legislative instrument defining mandatory OSDM-compatible API exposure, non-discriminatory access duties, passenger-rights backstop, and enforcement mechanisms across EU member states. This is the legal basis for the entire programme and determines scope (which carriers and routes are in-scope), access-term definitions, liability allocation, and the regulatory authority of member-state enforcement bodies. Essential for standards development (Month 18 = 2028-04-08 deadline) and governing the non-discrimination framework. Audience: DG MOVE, arbitration panel, standards working group, carriers, regulators, legal counsel.

**Recency Requirement:** Final adopted text; expected Month 9 (2027-07-08) but may slip to Month 10–12 (2027-08-08 to 2027-10-08) depending on Parliament and Council negotiations.

**Responsible Role Type:** Governance and Legal Affairs Advisor; Strategy and Programme Director

**Access Difficulty:** Easy. The Commission proposal (May 2026) is already public on EUR-Lex. Final adopted text will be published immediately upon Council adoption and is freely accessible.

**Steps:**

- 1. Track Commission publication of the Regulation in the EU Official Journal (EUR-Lex database).
- 2. Contact the Parliament's TRAN and IMCO rapporteurs (Month 0.5 = 2026-10-23) to obtain advance notice of adoption timing and any significant amendments.
- 3. Once adopted, download the full legislative text from EUR-Lex (https://eur-lex.europa.eu/) and analyse for gaps vs. OSDM v2.1 and the Pragmatic Foundation scenario.

### 2. OSDM v2.1 and Later Specifications (UIC/CER Open Sales and Distribution Model Standard)

**ID:** 5195ce98-9e28-4a53-8ed1-bf8350d5d896

**Description:** The technical standard for API design, data formats, and interoperability among EU rail carriers, used as the baseline for the binding standards (Month 18 = 2028-04-08). Specifies inventory API (offers, availability, fares), booking API (purchase, reservation), and post-sale API (changes, cancellations, refunds). Current version is v2.1; the programme may require v2.2 or v3.0 if Parliament amendments extend scope (e.g., multimodal integration). Audience: standards working group, carriers, test labs, distributors, data-layer architects.

**Recency Requirement:** Current OSDM v2.1 (published 2024) or later versions released during Months 0–9 (2026-10-08 to 2027-07-08). Gap analysis by Month 6 (2027-04-08) will identify any evolution needed.

**Responsible Role Type:** Chief Technical Standards Officer / OSDM and API Architecture Lead

**Access Difficulty:** Medium. OSDM v2.1 is published by UIC but access may require membership or a formal request. Smaller carriers and distributors often receive copies via their sector organisations (CER, BEUC). Request from UIC by Month 0.5 (2026-10-23).

**Steps:**

- 1. Contact UIC (International Union of Railways) directly via https://uic.org/ or the OSDM working group contact.
- 2. Request the latest OSDM specification version (current v2.1, published 2024) in PDF format.
- 3. Review versioning roadmap: check whether UIC has published v2.2 or announced v3.0 to incorporate EU Regulation changes by Month 6 (2027-04-08).

### 3. Existing EU Rail Passenger Rights Regulations (Regulation 1371/2007 and Revised Text, Adopted 2023)

**ID:** 4f828f62-e943-437f-bc85-b61dda97101c

**Description:** Current and revised EU rules governing passenger rights (cancellations, delays, refunds, accessibility assistance, liability allocation) that the programme's backstop must align with. Regulation 1371/2007 is the baseline; the revised text (adopted 2023, effective 2025) strengthens consumer protections and accessibility duties. Essential for designing the fault-allocation protocol and refund timelines in the Passenger-Rights Backstop Framework (Month 3 = 2027-01-08). Audience: legal counsel, arbitration panel, carriers, regulators.

**Recency Requirement:** Current: Regulation (EU) 2023/1300 (revised text, effective 2025 or later). The programme design must comply with the revised rules, not the older 1371/2007.

**Responsible Role Type:** Cross-Border Rail Passenger Rights and Liability Framework Specialist

**Access Difficulty:** Easy. EU regulations are published in the Official Journal and freely accessible on EUR-Lex.

**Steps:**

- 1. Access EUR-Lex (https://eur-lex.europa.eu/) and search for 'Regulation 2023/1300' (or the OJ reference if published more recently).
- 2. Download the full legislative text in all EU languages; English version is primary for legal analysis.
- 3. Cross-reference with existing Regulation 1371/2007 to identify what changed and how it affects the programme's backstop design.

### 4. Statistical Data on Cross-Border Rail Journey Volumes and Passenger Demographics (EU Member States, 2023–2025)

**ID:** cf95677b-1d1f-4946-89cb-0ce53d2e73d9

**Description:** Baseline data on the number of cross-border rail journeys per year, passenger demographic profiles (age, income, mobility status, geography), and booking/ticketing patterns (single-operator vs. multi-operator journeys, use of distributors, payment methods). Needed to validate the 40% through-ticket target, design the measurement baseline (Month 9 = 2027-07-08), and model the through-ticket addressable market. Sources: national rail regulators' annual reports, CER sector statistics, EUROSTAT transport data. Audience: measurement team, programme evaluators, financial modellers.

**Recency Requirement:** Most recent available year (2024 or 2025). Preliminary 2024 data is acceptable; final 2025 data by Month 9 (2027-07-08) is required for the measurement baseline.

**Responsible Role Type:** Measurement, Evaluation and Evidence Lead; Strategy and Programme Director

**Access Difficulty:** Medium. Eurostat data is freely available but aggregate cross-border journey data by country pair may require custom statistical request (1–4 weeks). National regulators sometimes publish annual reports on their websites; others require formal requests.

**Steps:**

- 1. Contact Eurostat (https://ec.europa.eu/eurostat) and request transport statistics on rail journeys by country pair and year.
- 2. Reach out to the Community of European Railway and Infrastructure Companies (CER, https://www.cer.be/) for aggregated sector statistics and member-company reports.
- 3. Query individual national rail regulators (e.g., SNCF's annual report, Deutsche Bahn financial statements) for domestic and cross-border journey volumes.
- 4. Check the EU Agency for Railways website (https://www.era.europa.eu/) for any published statistics on EU-wide rail mobility trends.

### 5. GDPR Data Protection Authority Positions and National Data-Residency Policies (Austria, Germany, Poland, France, Bulgaria, Romania)

**ID:** d9c14abe-3b1a-45e3-b317-a2311f7629ff

**Description:** Guidance from the European Data Protection Board (EDPB) and individual national DPAs on cross-border PII transfers, Standard Contractual Clauses (SCCs), data-residency requirements, and special-category data (accessibility attributes) consent regimes. Needed to design the GDPR Compliance Framework (Month 1 = 2026-11-08) and secure DPA consensus by Month 4 (2027-02-08). Key DPAs for this programme: Austria (strict on data minimisation), Germany (GDPR enforcement leader), Poland (national data-residency sensitivity), France (CNIL active on consumer data), Bulgaria and Romania (developing but potentially restrictive). Audience: data-protection lead, legal counsel, payment-institution advisors.

**Recency Requirement:** Current EDPB guidance (2024–2025) and national DPA positions as of Month 0 (2026-10-08). Requests to national authorities in Months 1–3 (2026-11-08 to 2027-01-08) will yield official positions by Month 4 (2027-02-08).

**Responsible Role Type:** Data Protection Impact Assessment and GDPR Compliance Lead; Governance and Legal Affairs Advisor

**Access Difficulty:** Medium. EDPB guidance is published and freely available. Individual DPA positions require formal requests and follow-up; responses may be slow (4–8 weeks in some member states). Early engagement (Month 1 = 2026-11-08) is essential.

**Steps:**

- 1. Check the EDPB website (https://edpb.ec.europa.eu/) for published guidance on cross-border data transfers, SCCs, and special-category data consent.
- 2. Submit formal information requests to the Austrian DPA, German BfDI, Polish UODO, French CNIL, Bulgarian DPA and Romanian ANSPDCP, asking for their positions on cross-border rail-ticketing data flows and any national residency requirements (Month 1 = 2026-11-08). Allow 4–6 weeks for responses.
- 3. Contact the European Data Protection Board secretariat directly to request expedited guidance if a key DPA's position conflicts with the programme design (Month 2–3 = 2026-12-08 to 2027-01-08).

### 6. EU Competition Law Framework and DG COMP Guidance on Shared Data and Access Obligations (Articles 101–102 TFEU, Digital Markets Act Principles)

**ID:** 9121e8e1-033b-44c4-931e-3ea04bc8bc74

**Description:** Competitive analysis and regulator expectations on the legality of the shared real-time data layer (shared inventory, fares, disruption data among competing carriers). Needed to design the Competition-Law Firewalls framework (Decision 13) and determine what data can be pooled without violating Articles 101–102 TFEU. DG COMP's Digital Markets Act principles and any pre-existing guidance on transport data-sharing are essential inputs. Audience: legal counsel, data-layer architects, competition specialists, payment-institution advisors.

**Recency Requirement:** Current DG COMP guidance on shared infrastructure and data access (2024–2025). Request a pre-filing consultation or comfort letter by Month 2 (2026-12-08).

**Responsible Role Type:** EU Competition Law and Digital Markets Counsel; Governance and Legal Affairs Advisor

**Access Difficulty:** Medium. DG COMP published guidance is available. Pre-filing consultations require legal counsel and may take 4–12 weeks. Early submission (Month 1 = 2026-11-08) is critical to avoid delays in standards finalisation.

**Steps:**

- 1. Access DG COMP's website (https://ec.europa.eu/competition/) and download guidance on joint-venture data-sharing, block exemptions, and shared infrastructure.
- 2. Review published decisions on transport, telecommunications and digital services where shared data pools were approved (e.g., case T–19/18 Google and Others v Commission on search-engine interoperability).
- 3. Submit a pre-filing consultation memo to DG COMP (Month 1–2 = 2026-11-08 to 2026-12-08) outlining the shared data-layer architecture, data fields to be pooled, and safeguards (neutral operator, access logs, data minimisation). Request comfort letter or expedited guidance by Month 6 (2027-04-08).

### 7. EU Agency for Railways Regulatory Framework and Authority Documents (Delegated Acts, Technical Standards, Enforcement Procedures)

**ID:** 251a8f8d-5184-4d53-90e1-c0dfc80ff158

**Description:** The EU Agency for Railways' mandate, enforcement powers, and existing technical standards (especially the Technical Specifications for Interoperability – TSI) that the programme must align with or extend. Needed to understand the Agency's role as technical secretariat to the arbitration panel (Decision 5) and how OSDM API standards fit within the broader EU rail-standardisation framework. Audience: arbitration panel, standards working group, DG MOVE, national regulators.

**Recency Requirement:** Current (2024–2025) Agency delegated acts and technical standards published in the Official Journal.

**Responsible Role Type:** Governance and Legal Affairs Advisor; Chief Technical Standards Officer

**Access Difficulty:** Easy. Agency documents are published on its website and in EUR-Lex. Direct contact with the Agency is straightforward via the published contact methods.

**Steps:**

- 1. Visit the EU Agency for Railways website (https://www.era.europa.eu/) and download all published delegated acts, technical standards and guidance documents.
- 2. Search the Official Journal (EUR-Lex) for the Agency's recent decisions and technical specifications, especially any related to digital ticketing or interoperability.
- 3. Contact the Agency directly (Month 1 = 2026-11-08) to request clarification on how OSDM APIs fit within the TSI framework and whether any TSI updates are needed to support the programme.

### 8. Payment Services Directive (PSD2) and Electronic Money Directive (EMD2) Regulatory Framework and Competent-Authority Guidance

**ID:** eb88554c-3add-4cea-b7be-3836777532ee

**Description:** EU rules governing licensed payment institutions, settlement procedures, multi-currency handling, fraud liability and SLA requirements. Needed to design the accreditation criteria for payment providers (Clearing and Settlement Architecture document, Month 2–3 = 2026-12-08 to 2027-01-08) and to understand member-state regulators' expectations for through-ticket settlement. Audience: clearing-mechanism designer, payment-institution applicants, competent authorities (national banking regulators).

**Recency Requirement:** Current PSD2 (Directive (EU) 2015/2366) and any amendments or EDPB guidance on multi-currency settlement and through-ticketing scenarios (2024–2025).

**Responsible Role Type:** Clearing and Settlement Mechanism Designer / Payment Systems Specialist; Governance and Legal Affairs Advisor

**Access Difficulty:** Easy. PSD2 and EBA guidance are published and freely available. ECB consultation requires a formal request but is straightforward (2–4 weeks response time).

**Steps:**

- 1. Download PSD2 from EUR-Lex (https://eur-lex.europa.eu/) and the European Banking Authority (EBA) regulatory technical standards (RTS) on payment security and data protection.
- 2. Contact the EBA (https://www.eba.europa.eu/) to request guidance on through-ticket settlement as a novel use case under PSD2.
- 3. Engage the European Central Bank (ECB, https://www.ecb.europa.eu/) on multi-currency settlement and FX exposure management (Month 1–2 = 2026-11-08 to 2026-12-08).

### 9. Current Cross-Border Rail Booking and Ticketing Practices, Including Carrier IT Systems Assessment and Distributor Capabilities

**ID:** e02934d1-a4a0-4be0-b65a-946a1c3af9e7

**Description:** Technical and operational audit of the 25+ participating carriers' current booking systems, APIs, data maturity, and integration readiness. Needed for the Legacy Carrier IT Migration Pathway (Decision 4), hub eligibility assessment (identify which 12–18 carriers need hub access), and budget forecasting for carrier co-funding (Month 2 = 2026-12-08 cost model). Includes legacy-system inventory (mainframe vs. cloud), API maturity assessment (OSDM readiness, security, performance), and distributor integration capabilities (Trainline, Omio). Audience: smaller-carriers support team, cost modellers, hub programme lead.

**Recency Requirement:** Surveys and assessments conducted Months 0–3 (2026-10-08 to 2027-01-08) with carriers and distributors directly. Self-assessment templates issued by Month 0.5 (2026-10-23); responses due Month 2 (2026-12-08).

**Responsible Role Type:** Smaller Carriers and Regional Integration Lead; Large Enterprise IT Legacy System Migration Program Director

**Access Difficulty:** Medium. Carriers may be reluctant to disclose system details for competitive reasons. CER can help as a trusted intermediary. Expect 40–60% response rate on initial questionnaire; follow-up calls are essential to fill gaps. Plan 4–6 weeks for the full assessment.

**Steps:**

- 1. Prepare a standardised carrier IT-readiness questionnaire (Month 0 = 2026-10-08) covering: current booking-system age and architecture, API maturity, current distributor integrations, IT staff capacity, and timeline for OSDM readiness.
- 2. Issue the questionnaire to all CER member carriers (via CER, https://www.cer.be/) by Month 0.5 (2026-10-23); collect responses by Month 2 (2026-12-08).
- 3. Conduct follow-up calls with carriers showing legacy systems or low OSDM readiness (identified as hub-eligible in Month 1 = 2026-11-08) to refine the assessment.
- 4. Engage major distributors (Trainline, Omio, others) separately to assess their integration timeline and API-development roadmap.

### 10. Member-State National Rail Regulatory Capacity and Enforcement Capability Assessment (All 27 Member States)

**ID:** 1ad74e82-df4e-498a-a81c-8247c3eb86ec

**Description:** Audit of the 27 member-state rail regulators' staffing, expertise, IT systems, enforcement experience, and capacity to enforce non-discrimination, passenger rights and data-quality duties under the programme. Needed to design the regulator capacity-building plan (Member-State Regulator Capacity-Building and Enforcement-Alignment Programme, Month 2 = 2026-12-08) and to identify priority targets for twinning support (estimated 8–12 weaker-capacity regulators). Includes assessment of each regulator's GDPR and competition-law expertise, dispute-resolution procedures, and cross-border coordination mechanisms. Audience: regulator-capacity lead, Standing Regulators Committee, twinning coordinators.

**Recency Requirement:** Assessments conducted Months 1–3 (2026-11-08 to 2027-01-08) with direct engagement of national regulators. Self-assessment templates issued Month 1 (2026-11-08); responses due Month 3 (2027-01-08).

**Responsible Role Type:** Member-State Regulator Capacity and Cross-Border Enforcement Lead

**Access Difficulty:** Medium. National regulators are often cooperative with EU-level capacity initiatives but may take time to respond (6–8 weeks is typical). Direct contact via the EU Agency for Railways helps. Some regulators have limited English proficiency; consider offering assessment in national languages.

**Steps:**

- 1. Prepare a standardised regulator capacity-assessment template (Month 1 = 2026-11-08) covering: number of staff, expertise areas (access enforcement, passenger rights, GDPR, competition law), IT systems, current dispute-resolution procedures, and cross-border coordination experience.
- 2. Issue the template to all 27 member-state national rail regulators via the EU Agency for Railways (https://www.era.europa.eu/) by Month 1 (2026-11-08); collect responses by Month 3 (2027-01-08).
- 3. Conduct bilateral calls with regulators identified as lower-capacity (expected: Poland, Bulgaria, Romania, Hungary, Slovakia, Slovenia, Croatia, Malta) to understand specific needs and design targeted twinning support.
- 4. Aggregate findings in a capacity report due Month 4 (2027-02-08) to inform the Standing Regulators Committee and twinning partnerships.

### 11. Distributor Market Research: Trainline, Omio and Other Commercial Platforms' Margin Requirements, Integration Capacity and Co-Marketing Preferences

**ID:** dff2502f-f5a0-466e-a715-904906ee843c

**Description:** Detailed market research on the three largest rail-ticketing distributors (Trainline, Omio, others) to understand their business models, margin expectations (typically 5–10% of booking value for rail, lower for through-tickets), current IT investment capacity, likely timeline for OSDM API integration, and co-marketing incentive requirements. Needed to design the distributor engagement and incentive strategy (Carrier Engagement and Stakeholder Manager) and to forecast whether early API access and co-marketing support (EUR 5–10M budget proposed) will be sufficient to secure integration by Month 18 (2028-04-08). Audience: distributor engagement lead, budget planner, consumer product lead.

**Recency Requirement:** Market research conducted Months 1–3 (2026-11-08 to 2027-01-08) via interviews and questionnaires to platform leadership. Collect responses by Month 2 (2026-12-08).

**Responsible Role Type:** Carrier Engagement and Stakeholder Manager / Coalition Builder

**Access Difficulty:** Medium. Major distributors are reachable via public contacts and usually willing to meet for strategic dialogue. Expect preliminary answers in Months 1–2 (2026-11-08 to 2026-12-08); detailed financial and timeline estimates may require follow-up (Months 2–3 = 2026-12-08 to 2027-01-08).

**Steps:**

- 1. Schedule bilateral meetings with Trainline (Group Chief Technology Officer or VP Partnerships), Omio (Chief Product Officer or VP Partnerships), and 2–3 smaller platforms (Month 1 = 2026-11-08).
- 2. Ask each platform: (a) current gross margin on rail bookings; (b) estimated cost of OSDM API integration (development, testing, operations); (c) timeline for live integration if early API access is offered; (d) marketing budget and co-marketing discount expectations; (e) data-access requirements (e.g., real-time inventory, competitor pricing visibility).
- 3. Document responses in a distributor-readiness matrix (Month 3 = 2027-01-08) and use findings to tailor the distributor engagement strategy and incentive package.

### 12. Carrier Financial Benchmarking and Willingness-to-Pay Analysis for Through-Ticket Integration and Co-Funding (Major and Smaller Carriers)

**ID:** 58a58352-8eed-4fca-bbd8-2c63a8fc2d8b

**Description:** Financial analysis of the 25+ participating carriers' likely tolerance for integration costs, their expected return on investment from increased through-ticket volumes, and the co-funding rates that would incentivise adoption. Needed for the Funding Allocation and Carrier Incentives framework (Decision 3) and the cost model (Month 2 = 2026-12-08). Includes assessment of each carrier's integration cost (hub use EUR 2–5M, native build EUR 10–20M) and expected revenue uplift from through-ticket sales. Audience: financial modeller, carrier engagement lead, budget planner.

**Recency Requirement:** Analysis conducted Months 1–3 (2026-11-08 to 2027-01-08) via surveys and interviews. Estimates due Month 2 (2026-12-08).

**Responsible Role Type:** Budget Controller and Financial Manager; Carrier Engagement and Stakeholder Manager

**Access Difficulty:** Medium. Carriers are often willing to share cost estimates with the Commission but may be coy about expected revenue uplifts (competitive sensitivity). CER coordination helps; expect 50–70% response rate initially and 80%+ after follow-up.

**Steps:**

- 1. Prepare a carrier financial-assessment template (Month 1 = 2026-11-08) requesting: estimated IT integration cost (hub or native), expected revenue from through-tickets as % of total cross-border revenue, and acceptable co-funding rate (10%, 20%, 50%).
- 2. Issue the template to carriers above EUR 10M annual cross-border revenue via CER (Month 1 = 2026-11-08); collect responses by Month 2 (2026-12-08).
- 3. Conduct follow-up calls with carriers that initially indicate low willingness-to-pay to understand cost barriers and alternative incentive structures.
- 4. Aggregate findings in a cost-model input document (Month 2 = 2026-12-08) to inform the budget framework.

### 13. Existing EU Accessibility Standards and Guidelines (WCAG 2.1 AA, EU Accessibility Directive 2019/882, UN Convention on Rights of Persons with Disabilities)

**ID:** f90ede28-8172-4606-8956-a6b6f4107ad0

**Description:** Technical and legal standards for digital booking accessibility, assistance for persons with reduced mobility, and cross-border accessibility data sharing. Needed for the Accessibility Integration and Assistance-Delivery Framework and for embedding accessibility requirements in the binding standards (Month 18 = 2028-04-08). Includes WCAG 2.1 AA technical specifications, the EU Accessibility Directive's requirements for public transport booking, and the UN Convention's principles on equal access. Audience: accessibility specialist, standards working group, consumer-product team.

**Recency Requirement:** Current standards: WCAG 2.1 (published 2018, stable); EU Directive 2019/882 (effective 2025+); UN Convention (adopted 2006, ongoing). Use versions current as of Month 0 (2026-10-08).

**Responsible Role Type:** Assistance Booking and Accessibility Integration Lead

**Access Difficulty:** Easy. All three sources are published online and freely accessible. WCAG technical specifications are detailed; allow time for study and interpretation (2–4 weeks).

**Steps:**

- 1. Download WCAG 2.1 AA specification from the World Wide Web Consortium (W3C, https://www.w3.org/WAI/WCAG21/quickref/).
- 2. Access EU Directive 2019/882 from EUR-Lex and review Title II (Public Transport) requirements for booking and real-time information.
- 3. Consult the UN Convention on the Rights of Persons with Disabilities (https://www.un.org/development/desa/disabilities/) for principles on accessibility to information and transportation.

### 14. Baseline Datasets: Current Cross-Border Rail Complaint Volumes, Types and Resolution Times (by Carrier, Distributor, Member State)

**ID:** de3a90d9-03a9-4ac5-a29c-41322ff673e3

**Description:** Historical data on the number and nature of complaints lodged against carriers and distributors related to cross-border journeys (e.g., refund delays, lost bookings, accessibility issues, communication failures), average resolution times, and outcomes. Needed to establish the baseline for the 'halved complaints' target (Month 9 = 2027-07-08 validated baseline) and to design the dispute-resolution and customer-support frameworks. Sources: national regulators' annual reports, carrier complaint logs, distributor internal data, BEUC consumer surveys. Audience: measurement team, passenger-rights framework designer, customer-support lead.

**Recency Requirement:** Most recent available year (2024–2025). Preliminary 2024 data is acceptable; final 2025 data by Month 9 (2027-07-08) is required for the baseline.

**Responsible Role Type:** Measurement, Evaluation and Evidence Lead; Cross-Border Rail Passenger Rights and Liability Framework Specialist

**Access Difficulty:** Medium. National regulators often publish annual reports with complaint statistics (easy to obtain). Carrier and distributor self-reports require confidentiality agreements and may be incomplete (some carriers do not publish complaint data). BEUC surveys are published but may not be recent or detailed enough for this specific use case. Allow 8–12 weeks to assemble a comprehensive baseline.

**Steps:**

- 1. Request complaint data from national rail regulators (via EU Agency for Railways or direct contact) covering complaints against participating carriers for cross-border journeys (Months 0–2 = 2026-10-08 to 2026-12-08).
- 2. Contact BEUC (Bureau Européen des Unions de Consommateurs, https://www.beuc.eu/) for consumer-complaint surveys related to rail travel and cross-border journeys.
- 3. Conduct a survey of major carriers and distributors asking them to self-report complaint volumes, types and resolution times for cross-border bookings (Month 1–2 = 2026-11-08 to 2026-12-08). Aggregate responses with confidentiality protections.
- 4. Compile findings into a baseline-complaints report (Month 9 = 2027-07-08) specifying the 'halved complaints' target numerically.

### 15. Current European Short-Haul Aviation Market Data: Fares, Capacity, Load Factors, Frequency on Priority Corridors (Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin)

**ID:** 5bdf4ee1-a567-4476-b65c-944621d1b9c9

**Description:** Baseline competitive data on low-cost and full-service airline fares, capacity (seats/day), load factors and flight frequency on the four priority corridors to model through-ticket competitive positioning and forecast modal-shift responses. Needed for killer-application pricing strategy and to validate the modal-shift planning range (5–15%). Sources: IATA, airline financial reports, booking-data aggregators (OAG, Travelport), aviation-market research firms. Data should span at least 2 years (2024–2025) to identify trends.

**Recency Requirement:** Most recent 12–24 months (2024–2025 preferred). Monthly updates starting Month 6 (2027-04-08) to track airline responses to through-ticket launches.

**Responsible Role Type:** Strategy and Programme Director; Competitive Intelligence Analyst

**Access Difficulty:** Medium to Hard. IATA and OAG data are commercial products (subscription required, estimated EUR 5K–20K/year). Airline financial reports are free but published quarterly or annually (4–6 week lag). Booking-data aggregators may require special requests. Allow 4–8 weeks to secure initial dataset; establish subscription contracts by Month 1 (2026-11-08).

**Steps:**

- 1. Contact IATA (International Air Transport Association, https://www.iata.org/) for aggregate capacity and load-factor data on short-haul European routes.
- 2. Request detailed fare data from OAG (On-Time Performance, https://www.oag.com/) or Travelport (https://www.travelport.com/) covering published fares, low-cost carrier prices, and premium fares on the four corridors.
- 3. Download public financial reports from major airlines (Ryanair, easyJet, Lufthansa, Air France, Iberia, SAS) to extract revenue trends and capacity plans on these routes.
- 4. Obtain quarterly updates (Months 6, 9, 12, 15 onwards = 2027-04-08, 2027-07-08, 2027-10-08, 2028-01-08 onwards) to track how airlines respond to through-ticket launches.

### 16. Fuel Price Forecasts and Aviation-Tax Policy Proposals (EU Commission, Member States, IEA, World Bank)

**ID:** 9371a854-2c3b-4862-a017-78bf718a8a36

**Description:** Forecasts of crude oil and jet-fuel prices and evolution of aviation-tax policies (EU CO2-tax proposals, member-state kerosene-tax plans) over the programme period (Months 0–60 = 2026-10-08 to 2031-10-08) to model fuel-price sensitivity of through-ticket competitiveness and modal-shift viability. Needed for scenario planning (Scenario 1: fuel EUR 40–60/barrel, no aviation tax → low modal shift; Scenario 2: fuel EUR 80–100/barrel or CO2-tax introduced → higher modal shift). Sources: IEA World Energy Outlook, World Bank, ICIS Energy, ECB inflation forecasts, Commission impact assessments of aviation-tax proposals.

**Recency Requirement:** Most recent forecasts (2024–2025). IEA publishes annually; World Bank quarterly. Commission aviation-tax proposals expected Months 3–6 (2027-01-08 to 2027-04-08).

**Responsible Role Type:** Strategy and Programme Director; Financial Modeller

**Access Difficulty:** Easy to Medium. IEA and World Bank forecasts are published online (free or low-cost subscriptions). Commission proposals are published in EUR-Lex and DG MOVE website (free). Member-state policies require monitoring government websites and CER communications. Allow 2–4 weeks to compile initial dataset; set up quarterly update alerts.

**Steps:**

- 1. Download the IEA World Energy Outlook 2024 (https://www.iea.org/) which includes oil and jet-fuel price forecasts to 2050.
- 2. Check the World Bank commodity-price forecasts (https://www.worldbank.org/) for oil-price expectations (updated quarterly).
- 3. Monitor the Commission's legislative proposals (EUR-Lex and DG MOVE website) for aviation-tax policy evolution and fiscal impact assessments.
- 4. Track member-state announcements on kerosene-tax harmonisation (check transport-ministry websites and CER communications).
- 5. Obtain ECB inflation and interest-rate forecasts (https://www.ecb.europa.eu/) as a proxy for broader economic trends affecting fares.

### 17. EU Accessibility Directive Implementation Data and Member-State Station/Rolling-Stock Accessibility Inventories

**ID:** 74afda0d-a5d5-48b8-823f-23df00753ee9

**Description:** Current data on member-state compliance with the EU Accessibility Directive 2019/882 (effective 2025+) for public transport accessibility, including inventories of station and rolling-stock accessibility attributes (lifts, accessible toilets, low-floor vehicles, accessible seating, staff-assistance capability) by carrier and member state. Needed to populate the accessibility-data registry and to assess baseline accessibility for the four priority corridors. Sources: national transport authorities' accessibility reports, carrier rolling-stock specifications, station management organisations (e.g., SNCF Gares & Connexions for France).

**Recency Requirement:** Current (2024–2025) implementation data. EU Directive effective 2025+, so member-state reports expected Months 3–6 (2027-01-08 to 2027-04-08). Current inventories (as-is at Month 0 = 2026-10-08) are acceptable for baseline.

**Responsible Role Type:** Assistance Booking and Accessibility Integration Lead; Smaller Carriers and Regional Integration Lead

**Access Difficulty:** Medium. Carrier rolling-stock data is often proprietary but carriers are increasingly disclosing accessibility specs publicly. Member-state reports are being developed (effective 2025+) and will be published by transport ministries. Station accessibility info is usually available on station websites. Allow 6–8 weeks to compile an initial inventory; expect gaps that require direct carrier requests.

**Steps:**

- 1. Contact the EU Agency for Railways (https://www.era.europa.eu/) for links to member-state accessibility reports and compliance documentation.
- 2. Request accessibility inventories directly from participating carriers (rolling-stock manufacturers, station accessibility audits) via CER coordination (Month 1 = 2026-11-08).
- 3. Search national transport-authority websites (SNCF, DB, ÖBB, Renfe, NS, SJ, SNCB) for published accessibility data and accessibility plans (usually in sustainability/CSR reports).
- 4. Check station-management organisations and airports for published accessibility information on the priority corridors' major hubs (Paris, Brussels, Amsterdam, Cologne, Vienna, Munich, Zurich, Madrid, Barcelona, Lyon, Copenhagen, Hamburg, Berlin).

### 18. Financial Data on Carrier Profitability, IT Investment Trends and Digital Transformation Roadmaps (Annual Reports, Sustainability Reports, Investor Presentations)

**ID:** 563640cd-a87a-4189-b4a3-a1065cbd73c4

**Description:** Financial and strategic data on the 25+ participating carriers' revenue trends, operating margins, capital expenditure on IT and digital systems, and published digital-transformation roadmaps. Needed to validate the assumption that carriers can afford and will prioritise OSDM integration and to design the co-funding incentive structure. Sources: carriers' public financial reports (annual reports, investor presentations, sustainability reports), CER aggregated sector data, transport-ministry data on carrier health and strategic funding.

**Recency Requirement:** Most recent published data (2024–2025 financial year reports, expected to be published early 2025 or mid-2025). Investor presentations updated quarterly.

**Responsible Role Type:** Budget Controller and Financial Manager; Strategy and Programme Director

**Access Difficulty:** Easy to Medium. Publicly listed carriers publish annual reports (free on investor websites). CER data is publicly available. State-aid and ministry funding information requires government website searches and formal requests. Allow 4–6 weeks to compile initial dataset from public sources; supplement with 2–3 weeks of direct carrier outreach if needed.

**Steps:**

- 1. Download annual financial reports from publicly listed carriers (SNCF, Deutsche Bahn, ÖBB, Renfe, Trenitalia, NS, SJ, SNCB – most file on their investor relations websites or via stock-exchange filings).
- 2. Request publicly available investor presentations covering digital-transformation strategies and capital plans from each carrier (or access via stock-exchange databases like Refinitiv, Bloomberg).
- 3. Obtain CER sectoral financial data (https://www.cer.be/) for aggregated trends in rail-operator profitability and IT investment.
- 4. Check national transport ministries for strategic funding plans and state-aid data on carriers (especially state-owned operators like SNCF, Deutsche Bahn, ÖBB).
- 5. Compile a carrier financial-health scorecard (Months 2–3 = 2026-12-08 to 2027-01-08) to inform co-funding allocation and readiness assessment.