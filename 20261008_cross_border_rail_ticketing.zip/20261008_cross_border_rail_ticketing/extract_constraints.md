## Positive Constraints

- Deliver a coordinated European program making cross-border train travel easy to search, book, and refund
- Align with the European Commission's proposed Regulation on Digital Booking and Ticketing Services for Rail
- Any compliant distributor (incumbent operator, third-party platform such as Trainline or Omio, or a new public European booking service) must be able to sell through-tickets across all participating carriers
- Provide continuity-of-journey rights for through-tickets
- Provide single-payment settlement
- Provide harmonised refunds
- Support reduction cards
- Provide accessibility for persons with reduced mobility
- Support bicycle reservations
- Build a shared real-time data layer exposed through OSDM-compatible APIs on non-discriminatory commercial terms
- Build an inter-carrier clearing and settlement mechanism
- Include a passenger-rights backstop
- Include integration hooks for buses, ferries and short-haul air
- Start rollout with the busiest cross-border corridors: Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin
- Extend from the initial corridors to the full TEN-T network
- Cover stakeholders: DG MOVE, EU Agency for Railways, CER and national operators, independent distributors, BEUC, national regulators, disability-rights bodies
- Horizon of five years
- Binding standards within eighteen months
- Mandatory API exposure within thirty months
- Full corridor through-ticketing within sixty months
- Public-side coordination budget of €1.5 billion covering standards work, conformance testing, the clearing mechanism, a public reference distributor, member-state capacity building, and consumer-side rollout (apps, multilingual support, complaint handling)
- Estimate the larger private carrier IT investment separately from the public budget
- Success target: 40% of cross-border journeys sold as single through-tickets within five years
- Success target: distributor complaints halved
- Success target: train becomes more attractive than flying on competitive short-haul routes so fewer travellers choose the plane
- Pick a realistic scenario
- Project starts ASAP (Month 0 = 2026-10-12)
- Refer to points in time as month offsets from project start (e.g. Month 3 = 2027-01-12, Months 48-72 = 2030-10-12 to 2032-10-12)
- Mark figures that are not user constraints or established benchmarks as estimates or proposed thresholds
- Write in the impersonal voice of a planning document

## Negative Constraints

- Do not pick the most aggressive scenario
- Do not present invented numbers as facts
- Do not turn example values from the input documents ("e.g. ...") into requirements
- Do not refer to the author or process in the first person (no "I", "my knowledge", "I could not verify")
- Do not write calendar dates; use month offsets instead
