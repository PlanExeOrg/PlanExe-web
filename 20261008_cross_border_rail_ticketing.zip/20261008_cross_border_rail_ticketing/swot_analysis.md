
## Strengths 👍💪🦾
- Clear scenario (Pragmatic Foundation): certified access, accredited payment institutions, milestone co-funding, regional hubs and an arbitration panel avoid new legal entities and early price-fixing.
- OSDM is an existing, versioned standard with live implementations, so the programme builds on proven technical foundations.
- Public budget of EUR 1,500 million (user constraint) with a EUR 225 million contingency (15%) held at DG MOVE, and defined Tier 1-3 overrun responses.
- Specific milestones (Month 18 = 2028-04-08 standards, Month 30 = 2029-04-08 API, Month 60 = 2031-10-08 corridors) and a fixed through-ticket definition give measurable direction.
- Reference models exist: Swiss Direct Service clearing and the Deutschlandticket show multi-operator revenue split without a new central payment entity.
- Strong stakeholder architecture: working groups, Steering Committee, Standing Regulators Committee, accessibility and consumer groups.

## Weaknesses 👎😱🪫⚠️
- KILLER APPLICATION MISSING: no single flagship use-case is defined that makes through-tickets compelling on their own. The plan relies on broad convenience (sum-of-segment fares, no price ceilings), which is a weak pull against low-cost flights.
- Panel rulings depend on Council/Commission delegation not yet secured; the panel has no direct enforcement power over large incumbents.
- Fixed budget is fragile: a 20-30% overrun (EUR 300-450M) exceeds the EUR 215M free contingency (estimate).
- Legacy carrier IT: 12-18 carriers (estimate) need hubs, which carry mapping-error and single-point-of-failure risk.
- No consolidated baseline for cross-border sales, complaints or modal split until Month 9 (2027-07-08).
- Consumer rollout and communication are only lightly covered; the app launches at Month 15 (2028-01-08) and four-corridor consumer go-live is at Month 27 (2029-01-08).
- Post-Month 60 (2031-10-08) run costs of about EUR 45M/year (estimate) are unfunded.

## Opportunities 🌈🌐
- KILLER APPLICATION CAN BE DEVELOPED: a flagship 'one ticket, guaranteed connection' product on a single high-demand corridor (e.g. Paris-Brussels-Amsterdam-Koln). One booking, one payment, a 4-hour reroute decision and a 10-day refund, with reduction cards honoured (about 10-15% effective discount). Pilot it first, then scale it. Variants: an air-rail city-pair offer where rail competes with short-haul flights, or an assisted-travel journey for persons with reduced mobility.
- Obstacles to the killer application: through-fares may not beat budget airlines; the Regulation is not yet adopted; Trainline and Omio may lack margin incentive; weakest-carrier readiness limits end-to-end coverage; liability for missed connections is not fully funded; and mixed pilot corridors could confuse travellers.
- Regulation adoption gives a legal base for mandatory API exposure and non-discriminatory access.
- Distributors (Trainline, Omio) can supply large existing audiences if given early API access and co-marketing support.
- Environmental positioning and rising aviation taxes or fuel prices could improve rail competitiveness.
- Multimodal hooks (bus, ferry, short-haul air) extend the product beyond rail.
- Lessons from OSDM, SwissPass and the Deutschlandticket can speed design and reduce risk.

## Threats ☠️🛑🚨☢︎💩☣︎
- Regulation adoption slips past Month 9 (2027-07-08), compressing the standards window and threatening Month 18 (2028-04-08).
- Incumbents (DB, SNCF, OBB) signal non-compliance or seek exemptions, turning the Month 30 (2029-04-08) mandate advisory.
- GDPR challenges from national data protection authorities, or a competition-law investigation into shared fare and inventory data, could force redesign.
- Airlines respond with lower fares and more frequency; fuel-price falls weaken modal shift (planning range 5-15%, estimate).
- Fewer than 2 payment providers apply, or one withdraws.
- Uneven national regulator capacity and sovereignty objections undermine consistent enforcement.
- Peak-load API failures or hub outages, and poor consumer-app quality, could damage trust early.
- Non-EU participation (e.g. Swiss SBB) is uncertain on the Wien-Munchen-Zurich corridor.

## Recommendations 💡✅
- Define and pilot the killer application (guaranteed-connection through-ticket on one corridor) by Month 9 (2027-07-08) and launch it with the public app at Month 15 (2028-01-08). Owner: PMO with the consumer product team and corridor carriers.
- Secure written Council/Commission delegation to the arbitration panel by Month 2 (2026-12-08) (target Month 1.5 = 2026-11-23), and Commitment Letters from carriers above EUR 50M cross-border revenue by Month 3 (2027-01-08). Owner: DG MOVE.
- Track Regulation adoption weekly from Month 0 (2026-10-08) and run shadow standards pre-work; if adoption slips past Month 8 (2027-06-08), contract an external standards consortium. Owner: DG MOVE with the EU Agency for Railways.
- Complete the cost model by Month 2 (2026-12-08), apply the 115% trigger and Tier 1-3 responses, and hold reviews at Months 12 and 24 (2027-10-08, 2028-10-08). Owner: DG MOVE finance lead.
- Contract hubs by Month 3 (2027-01-08), run 2-4 week dual-runs in Months 15-18 (2028-01-08 to 2028-04-08), and suspend onboarding if failures exceed 2% for a week. Owner: Hub programme lead with the smaller-carrier coordinators.
- Run payment accreditation (call Month 2 = 2026-12-08, decision Month 8 = 2027-06-08, at least 2 providers live at Month 12 = 2027-10-08), and agree distributor margin support and early API access by Month 6 (2027-04-08). Owner: Clearing workstream lead and distributor advisory council.

## Strategic Objectives 🎯🔭⛳🏅
- Fix the through-ticket definition by Month 2 (2026-12-08) and validate the measurement baseline by Month 9 (2027-07-08), with monthly reporting from Month 18 (2028-04-08).
- Adopt binding standards (including accessibility and GDPR rules) by Month 18 (2028-04-08), and make at least 90% of corridor traffic bookable end-to-end by Month 30 (2029-04-08) (proposed threshold).
- Reach at least 15% through-ticket share by Month 24 (2028-10-08) (proposed threshold) and 40% of cross-border rail journeys by Month 60 (2031-10-08), with the killer-application product live on at least one corridor by Month 15 (2028-01-08).
- Cut distributor complaints to 50% or less of the Month 9 (2027-07-08) baseline by Month 60 (2031-10-08).
- Keep spend within the EUR 1,500 million cap and agree the post-Month 60 (2031-10-08) funding model for the distributor, hubs and data layer by Month 48 (2030-10-08).

## Assumptions 🤔🧠🔍
- The Regulation is adopted by Month 9 (2027-07-08) with only minor changes to the Commission proposal.
- The Council/Commission delegation to the arbitration panel is granted by Month 2 (2026-12-08).
- Private carrier IT spend of EUR 0.5-2.0 billion (estimate, planning value EUR 1.25 billion) stays outside the cap.
- Through-fares are the sum of segment prices with no regulated ceilings, so modal shift is a planning range of 5-15% (estimate), not a commitment.
- Trainline and Omio take part given early API access and co-marketing support.
- Switzerland participates in the Wien-Munchen-Zurich corridor.

## Missing Information 🧩🤷‍♂️🤷‍♀️
- Which flagship use-case travellers value most (customer research and willingness to pay versus flights).
- Baseline cross-border sales, complaint volumes and modal split.
- Per-carrier IT readiness and actual integration cost.
- Final text of the Regulation, especially on liability and the meaning of non-discriminatory access.
- Distributor margin requirements and integration timelines.
- Competition authority and data protection authority positions.
- Post-Month 60 (2031-10-08) funding and operating model, and the UK and Swiss scope.

## Questions 🙋❓💬📌
- Which single journey or product would make a traveller choose a through-ticket over buying separate tickets or flying, and what evidence supports that?
- What would the programme do if the Regulation is adopted after Month 9 (2027-07-08) or the final text differs materially?
- Can the arbitration panel realistically bind Deutsche Bahn or SNCF, and what happens if a major carrier refuses?
- Is the 40% through-ticket target meaningful without competitive fares, and should modal shift be tracked as a separate target?
- Which budget lines would be cut first in a 20-30% overrun, and who decides on supplementary funding?