
## Strengths 👍💪🦾
- Builds on proven components: OSDM standard, existing clearing arrangements and the Commission's proposed Regulation, so the programme layers over legacy carrier systems rather than replacing them.
- Federated design (federated settlement, streamed availability shadow, carrier booking authority) limits single-point-of-failure and competition-law exposure versus a central backbone.
- Carrier-funded guarantee pool with caps and no public pay-first fund protects the EUR 1,500M cap (user constraint); milestone tranches give compliance leverage over carriers the Commission cannot direct.
- Clear sequencing: Month 6 (2027-04-12) readiness gate, tiered conformance (Months 30/36/42 = 2029-04-12, 2029-10-12, 2030-04-12), pilots at Months 12-18 (2027-10-12 to 2028-04-12), four corridors by Month 48 (2030-10-12), with a fallback if prerequisites slip.
- Strong risk preparation: technical audit, DG COMP pre-notification, passenger-rights review, SLA scorecards and variance triggers already defined.
- Broad stakeholder base with defined governance (75% supermajority, Commission mediation) and a neutral last-resort concession capped at EUR 60M subsidy.

## Weaknesses 👎😱🪫⚠️
- Liability model is not yet priced: caps (EUR 500-1,000 per passenger) and co-insurance (EUR 50M) are indicative, so carriers cannot yet price exposure.
- Thin contingency: EUR 85M free headroom (5.7%) against fallback exposures of EUR 150-250M for adapter acceleration (estimate).
- Budget line items show a gap: the EUR 300M concession envelope split and who finances validation hardware retrofits remain open decisions.
- Legacy-system latency: three-leg queries at 95% availability each yield about 86% combined, below the 99.5% SLA, and 8-15 smaller operators risk missing Month 30 (2029-04-12) (estimate).
- Sum-of-legs fare construction gives no price reason to prefer rail over air, limiting the modal-shift outcome.
- Heavy dependence on scarce OSDM, clearing and actuarial expertise and on a programme office of about 80 staff (estimate) across four hubs.

## Opportunities 🌈🌐
- Passengers gain a single through-ticket with continuous rights on busy corridors; early corridor wins (Paris-Brussels-Amsterdam-Köln, Wien-München-Zürich) can build momentum and set the network effect for later extension.
- Distributor integration through non-discriminatory OSDM access can use Trainline and Omio reach to lift through-ticket share without public sales spend.
- Precedents (Rail Settlement Plan, Eurail/Interrail, Swiss NOVA) supply tested apportionment, dispute and onboarding practices that cut design time.
- Neutral, emissions-sorted display and guaranteed-rebooking products can improve rail's appeal against short-haul air at low public cost.
- Shared adapter modules and a reference test suite can lower integration cost for smaller carriers and create reusable assets.
- Legislative momentum around the Regulation gives political backing and a legal basis for mandatory API exposure.

## Threats ☠️🛑🚨☢︎💩☣︎
- Regulation adoption slips 6-12 months beyond Month 18 (2028-04-12) (estimate, not verified), removing the legal mandate for standards and API exposure.
- Carrier refusal if connection liability remains unpriceable; 30-40% refusal (estimate) would fragment corridors and cut the 40% goal to 15-25%.
- Article 101 TFEU challenge after investment could force EUR 50-100M rework and 6-12 months delay (estimate).
- Stakeholder deadlock or withdrawal of a major distributor by Month 9 (2027-07-12) could delay standards 2-4 months and cut volume 15-25% (estimate).
- Pool or concession overruns could drain budget needed for the TEN-T extension wave.
- Low-fare airline responses and national regulator objections limit modal shift and corridor access.

## Recommendations 💡✅
- Programme Office and actuaries: commission the actuarial study at Month 1 (2026-11-12), publish the draft liability model at Month 3 (2027-01-12), obtain written sign-off from at least 8 major carriers and CER at Month 4 (2027-02-12); use the Month 6 (2027-04-12) gate, deferring to Month 12 (2027-10-12) if unresolved.
- EU Agency for Railways: complete the technical audit of all carriers by Month 2 (2026-12-12), publish tier timelines at Month 6 (2027-04-12), and procure shared adapter modules by Month 12 (2027-10-12); tie EUR 240M adapter funds to verified API performance.
- DG MOVE and DG COMP liaison: file pre-notification at Month 2 (2026-12-12), obtain the guidance letter by Month 12 (2027-10-12) and clean-team protocol by Month 14 (2027-12-12); keep competition counsel engaged from Month 6 (2027-04-12).
- Programme Office: set the steering group at Month 1 (2026-11-12) with 75% supermajority, publish option papers at Month 2 (2026-12-12), and agree the fallback interfaces for dissenting parties by Month 6 (2027-04-12).
- Finance lead: ring-fence the EUR 150M reserve, run quarterly re-baselining from Month 6 (2027-04-12), and resolve the open concession split and validation-hardware financing by Month 9 (2027-07-12).
- Technical lead: launch the SLA proxy and scorecard at Month 12 (2027-10-12) and run 2,000-4,000 passenger pilots at Months 12-18 (2027-10-12 to 2028-04-12) to validate latency, reroute and loss rates before binding standards.

## Strategic Objectives 🎯🔭⛳🏅
- Obtain signed carrier liability model from at least 8 major carriers and CER by Month 4 (2027-02-12), with the binding steering vote by Month 6 (2027-04-12).
- Publish binding OSDM standards and clean-team clearing protocol by Month 18 (2028-04-12), with DG COMP guidance received by Month 12 (2027-10-12).
- Reach Tier 1 API exposure at p95 latency below 2 seconds and 99.5% availability by Month 30 (2029-04-12), with Tier 2 at Month 36 (2029-10-12) and Tier 3 at Month 42 (2030-04-12).
- Launch through-ticketing on four priority corridors by Month 48 (2030-10-12), with reconciliation error below 0.5% by Month 30 (2029-04-12).
- Reach 40% of cross-border journeys as through-tickets (planning range 15-30% if prerequisites slip) and halve distributor complaints by Month 60 (2031-10-12) within the EUR 1,500M cap, tracking cost per through-ticket sold.

## Assumptions 🤔🧠🔍
- The Regulation is adopted with amendments by about Month 18 (2028-04-12), with a 6-12 month slip plausible (not verified).
- Carriers participate voluntarily if exposure is capped and priced; about 25 targeted, 15-20 minimum viable.
- Private carrier IT investment of EUR 1.5-3.0 billion (estimate) is financed outside the EUR 1,500M cap.
- Federated settlement, streamed availability shadow and tendered concession remain the chosen design.
- Modal shift of 5-10% on benchmarked routes (estimate) is a planning value, not a success metric.

## Missing Information 🧩🤷‍♂️🤷‍♀️
- Actuarial loss data: missed-connection rates, rerouting costs and incident clustering per carrier.
- Technical audit results: API readiness, latency and availability per carrier and tier assignment.
- Current adoption count of OSDM operators and distributors, and verified legislative status of the Regulation.
- Baseline through-ticket share, distributor complaint volume and air-rail ratios on the four corridors.
- DG COMP and national regulator positions on data sharing and commission band.
- Who finances ticket-validation retrofits, and the concession set-up versus service split.

## Questions 🙋❓💬📌
- Which carriers would still refuse to expose connections at the proposed caps, and what exposure level would change that?
- If the Regulation slips 12 months, which parts can proceed on a voluntary basis and which stall?
- Is EUR 85M of free headroom plus the reserve enough given adapter and concession overrun scenarios, and what would be cut first?
- What evidence at the Month 12-18 (2027-10-12 to 2028-04-12) pilots would show passengers choose through-tickets over stitched itineraries or flights?
- How will independent distributors and smaller carriers be kept inside the network if the steering vote goes against them?