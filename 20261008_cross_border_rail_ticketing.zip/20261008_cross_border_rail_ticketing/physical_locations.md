This plan implies one or more physical locations.

## Requirements for physical locations

- Proximity to EU institutions (DG MOVE, EU Agency for Railways) for governance and standards work
- Access to priority corridors: Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin
- Secure data-centre and high-availability connectivity for the real-time data layer and clearing
- Test environments with access to live rolling stock, stations and gates for conformance pilots
- Easy access for national operators, CER, regulators, distributors and consumer/disability bodies
- Multilingual, skilled IT and financial-services workforce for clearing and distributor operations
- Competition-law-sensitive separation of the clearing function (clean-team arrangement)

## Location 1
Belgium

Brussels

European Quarter (DG MOVE, CER and BEUC offices) and Brussels-Midi/Bruxelles-Midi station area

**Rationale**: Seat of DG MOVE, CER and BEUC; central on the Paris–Brussels–Amsterdam–Köln corridor. Natural hub for governance, stakeholder coordination and the programme office.

## Location 2
France

Valenciennes / Lille area, Hauts-de-France

EU Agency for Railways headquarters (Valenciennes) with Lille-Europe station as corridor test access

**Rationale**: Hosts the EU Agency for Railways, which supervises standards, conformance testing and OSDM change control. Close to Paris–Brussels corridor trains for live pilots.

## Location 3
Germany / Switzerland / Austria

Berlin, Munich, Zürich and Wien corridor nodes

Operator IT and operations centres (e.g. Deutsche Bahn, SBB, ÖBB) along Wien–München–Zürich and Copenhagen–Hamburg–Berlin

**Rationale**: Large carrier IT and operations teams, OSDM expertise and busy cross-border corridors. Suited to conformance testing, carrier onboarding, clean-team clearing operations and the private concession for the last-resort distributor.

## Location 4
Spain / France

Madrid, Barcelona and Lyon

Renfe and SNCF operational hubs and stations on the Madrid–Barcelona–Lyon corridor

**Rationale**: Priority corridor with air competition and differing national systems; suited for pilots on through-ticketing, assistance and bicycle reservations, and modal-shift measurement.

## Location Summary
The programme is European-wide and tied to named rail corridors and EU institutions. Brussels is proposed as the governance and coordination hub, Valenciennes/Lille for the EU Agency for Railways and conformance work, German-speaking corridor nodes for carrier IT and clearing operations, and Madrid–Barcelona–Lyon for air-competitive corridor pilots.