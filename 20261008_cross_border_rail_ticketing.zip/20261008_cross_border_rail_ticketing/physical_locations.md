This plan implies one or more physical locations.

## Requirements for physical locations

- Major EU transport hubs and capital cities with strong rail infrastructure
- Four priority cross-border rail corridors: Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin
- Access to national rail operators and regulatory authorities
- Proximity to conformance testing facilities and carrier IT operations centres
- Capacity for multi-stakeholder governance coordination (DG MOVE, EU Agency for Railways, CER, national regulators, BEUC)
- Integration with broader TEN-T network infrastructure
- Accessibility to member-state capacity-building venues and workshops

## Location 1
Belgium

Brussels

Brussels, European Quarter or near Central Station

**Rationale**: Brussels is the primary hub for EU institutional coordination (DG MOVE, Commission, Council). It is central to the Paris–Brussels–Amsterdam–Köln corridor and sits at the intersection of major cross-border rail networks. Hosting the programme governance vehicle, arbitration panel and stakeholder coordination here ensures proximity to decision-makers and regulatory authorities while serving the initial priority corridors.

## Location 2
Germany

Cologne (Köln) and/or Frankfurt

Cologne or Frankfurt rail hub or regional IT centres

**Rationale**: Cologne terminates one of the four priority corridors (Paris–Brussels–Amsterdam–Köln). Frankfurt is Deutsche Bahn's operational hub and a major European rail and logistics centre. Either location enables conformance testing, carrier IT coordination and integration of one of the most complex multicarrier operations (SNCF, SNCB, NS, Deutsche Bahn) within the priority network.

## Location 3
Austria

Vienna

Vienna, central rail hub or near ÖBB operations centre

**Rationale**: Vienna anchors the Wien–München–Zürich corridor and is home to ÖBB (Austrian Federal Railways) and the EU Agency for Railways. It serves as a secondary coordination hub for central European carriers and regulators, and enables testing and capacity building for the eastern TEN-T extension beyond the initial four corridors.

## Location Summary
The programme is physically rooted in the four priority cross-border rail corridors and the broader TEN-T network. Governance and standards coordination are centred in Brussels (proximity to EU institutions and DG MOVE). Conformance testing, carrier IT integration and initial corridor rollout are deployed across the corridor hubs: Cologne/Frankfurt for the Paris–Brussels–Amsterdam–Köln route, Vienna for Wien–München–Zürich, and Madrid/Barcelona and Copenhagen/Hamburg/Berlin for the southern and northern corridors respectively. Each location serves as a base for carrier onboarding, regulatory liaison, and real-world testing against live rail operations, while the regional shared booking hubs (per the Pragmatic Foundation scenario) are sited in consortia-run facilities near major operators in each corridor region.