_Consistency: first pass found 3 high / 6 medium / 0 low contradictions. Repair: round 1: 41 edits → 2 high / 7 medium; round 2: 42 edits → 0 high / 4 medium. Published: round 2 (fewest high-severity issues). Shown below: the final check of the repaired documents (0 high / 4 medium / 1 low)._

## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Does the Month 2 technical audit show that no more than 35% of carriers lack a credible path to the p95 <2 s / 99.5% SLA by their tier date, and that shared adapters cover at least 60% of observed legacy patterns? | At most 35% of carriers unable to meet the SLA by tier date; shared adapter patterns cover at least 60% of legacy systems (A2 / FM2 tripwires, proposed thresholds). The audit must also cover carriers on all four priority corridors. | Technical audit of all carriers with synthetic three-leg queries, due Month 2; per-operator tier assignment published Month 6. | Downsize or split. Re-tier with a Tier 1.5 cohort, rely on the distributed cache, and restrict the first wave to corridors whose carriers all meet the SLA. Treat the EUR 240M adapter line and the 8-15 at-risk operators as a re-baselining item; FM2 stop rule applies if fewer than 15 operators are conformant by Month 36. |
| 2 | Is there written confirmation of a Regulation timetable that keeps adoption at about Month 18, with no adoption later than Month 24, and do regulators on the four priority corridors accept the data-sharing and clearing design? | Written timetable from the Commission legislative affairs unit showing adoption no later than Month 24 (A6 trigger, proposed threshold; target about Month 18); no national regulator on a priority corridor signalling it will not enforce API exposure; DG COMP pre-notification filed by Month 2. | Legislative timetable confirmation and regulator impact assessments, due Month 3; DG COMP pre-notification filed Month 2. | Delay or downsize. Launch the shadow-standards workstream and pilot authority, issue a voluntary conformance profile, and plan on the 15-30% planning range (estimate). If adoption is still not in sight, the FM5 fallback is a voluntary corridor-pilot model; the stop date needs to be set (see contradictions). |
| 3 | Have at least 8 major carriers and CER signed non-binding letters of intent to expose inventory under the interim liability parameters? | At least 8 major carriers plus CER sign by Month 4, against the Month 3 interim parameters (indicative cap EUR 500-1,000 per stranded passenger; co-insurance above EUR 50M annual pool draw; both proposed thresholds). Loss data supplied by at least 3 major carriers (FM3 tripwire). | Actuarial interim results and draft model at Month 3; signed letters of intent at Month 4; mediation at Month 5 if short. | Delay and redesign. Escalate to Commission mediation at Month 5 and pause dependent procurement. Offer a two-tier pool with reinsurance for smaller operators and use the Month 12 deferral. Stop rule: pivot to the Prudent Consolidator model if fewer than 6 major carriers commit by Month 12. |
| 4 | Does the Month 6 gate pass: the liability model is signed within the agreed band of the final actuarial study, steering votes on Decisions 1-5 reach the 75% supermajority, and the audit and tier assignment are published? | At least 75% (7 of 9 core members) on Decisions 1, 2, 3 and 12; final study within the agreed band of the interim parameters; tiers published at Month 6; unresolved at Month 9 means deferral to Month 12. | Binding steering votes, final actuarial study and tier assignment at Month 6; mediation outcome at Month 5. | Delay. Defer the gate to Month 12 under the pre-agreed rule and compress Phase 1. Month 18 binding standards remains the user constraint, so every month of deferral is a schedule risk to be reported, not absorbed. Prepare pilot authority and shadow standards. |
| 5 | Does the concession market test support a bounded last-resort service: at least 3 credible bidders, subsidy within EUR 60M over five years, volume at least 60% of forecast, and a decided split of the EUR 300M envelope? | At least 3 credible bidders; subsidy at or below EUR 60M over five years; forecast volume at least 60% of plan; envelope split between set-up and service payments decided (proposed thresholds). | Market sounding with 5-8 concessionaires, business case and 75% steering approval at Month 9; tender issued Month 12; award about Month 18. | Downsize. Hold the tender, re-scope to a lean last-resort service or direct public operation (EUR 30-50M, estimate), and re-baseline under the variance triggers. Stop rule: withdraw the concession and run a minimal public service if no compliant bid is within the cap by Month 18. |
| 6 | Has DG COMP issued guidance confirming that the federated clearing and data-sharing design is compatible with Article 101, with the clean-team protocol approved, before the clearing contract becomes unconditional? | Guidance letter by Month 12; clean-team protocol approved by Month 14 and no later than Month 18; cumulative rework variance below EUR 50M; at least 6 carriers confirming feed commitments by Month 15 (FM1 tripwires). | DG COMP guidance letter (Month 12), clean-team approval (Month 14), interim feedback requested by Month 9. | Stop or downsize the clearing layer. Freeze clearing commitments, pivot to bilateral clearing with a neutral dispute layer, and re-baseline the EUR 220M line. Stop rule: cancel the shared clearing layer if no compliant design is approved by Month 18. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: repaired_review_plan.md (Reviews 5.2, 11.3, 14.3)
    canonical: pool_draw_policy = No public budget draw-downs on carrier pools after Month 36 (2029-10-12); reserve drawable for force-majeure only
    observed:  reserve escrowed for pool top-ups only after Month 36 (2029-10-12)
HIGH CF-002  document: repaired_review_plan.md (Reviews 11.1, 1.3, 3.3)
    canonical: budget_line_concession_eur_m = EUR 300M envelope (platform set-up and public service-level payments), of which operating subsidy is capped at EUR 60M
    observed:  EUR 250-270M for operating subsidy; overrun 'exceeding the EUR 300M envelope'
HIGH CF-003  document: repaired_review_plan.md (Reviews 3.2, 6.1, 6.3, 11.2) and repaired_executive_summary.md
    canonical: budget_unallocated_headroom_eur_m = EUR 85M free uncommitted headroom (5.7% of cap) after EUR 1,415M committed lines
    observed:  EUR 50M separate reserve plus EUR 15M, EUR 5-10M, EUR 30-80M and EUR 30-50M claims on the same headroom
MEDIUM CF-004  document: repaired_review_plan.md (Reviews 1.2, 2.2, 3.2) and repaired_self_audit.md (item 18)
    canonical: budget_variance_triggers = EUR 100M: defer TEN-T; EUR 200M: cut concession 20% and extend term 5 to 7 years; EUR 300M: restrict to four priority corridors
    observed:  Triggers compared on gross and net-of-headroom bases; Self-Audit 18 lists EUR 50M, 100M, 200M
MEDIUM CF-005  document: repaired_self_audit.md (items 5, 14, 16) and repaired_review_plan.md (Reviews 2.3, 5.1)
    canonical: phase1_readiness_gate = Month 6 gate; if unresolved by Month 9 (2027-07-12), defer to Month 12 (2027-10-12); binding standards Month 18 (user constraint)
    observed:  deferral if slip past Month 6, binding standards target moved to Month 24; pilot authority by Month 3 / Month 6, triggered past Month 6 / Month 9
MEDIUM CF-006  document: repaired_review_plan.md (Review 14.1), repaired_self_audit.md (item 15), repaired_premortem.md (FM7)
    canonical: concession_timeline = Business case Month 9; tender issued Month 12; award about Month 18; service live about Month 30 (estimate)
    observed:  concession term ends Month 60; tender close in Month 12
MEDIUM CF-007  document: repaired_premortem.md (A6 and FM5)
    canonical: regulation_adoption_assumption = Adopted with amendments by about Month 18 (2028-04-12); 6-12 month slip plausible (not verified)
    observed:  tripwire Month 21; failure trigger Month 24; stop rule Month 30
MEDIUM CF-008  document: repaired_review_plan.md (Reviews 15.3, 16.2) and repaired_executive_summary.md
    canonical: pilots_and_validation = Live pilots Months 12-18 with 500-1,000 passengers per corridor
    observed:  pilots assessed on reconciliation error while clearing contract is conditional until Month 14
MEDIUM CF-009  document: repaired_premortem.md (FM3, FM4), repaired_review_plan.md (Review 8.1), repaired_pitch.md
    canonical: liability_decision_timeline = Study commissioned Month 1, interim Month 3, final Month 6; sign-off Month 4; mediation Month 5; binding vote Month 6
    observed:  actuarial firm contracted by Month 2; loss data from fewer than 3 carriers; study (Month 6) cited for Month 4 sign-off
MEDIUM CF-010  document: repaired_self_audit.md (item 3), repaired_review_plan.md (Review 7.3)
    canonical: liability_indicative_parameters = Cap EUR 500-1,000 per stranded passenger; co-insurance above EUR 50M annual pool draw (proposed threshold)
    observed:  EUR 500-1,000 per-incident caps
MEDIUM CF-011  document: repaired_self_audit.md (item 15), repaired_review_plan.md (Reviews 14.1, 14.2)
    canonical: fallback_cost_exposures_vs_headroom = direct operation EUR 30-50M (fits) (estimate)
    observed:  EUR 30-50M annual cost to the Commission
LOW CF-012  document: repaired_executive_summary.md (Feedback) and repaired_review_plan.md (Review 10.3)
    canonical: competition_law_timeline = DG COMP pre-notification Month 2 (2026-12-12)
    observed:  by Month 2, not Month 2, to recover 4-6 week buffer
```

### 1. Force-majeure reserve usable only 'after Month 36' vs ban on public pool draw-downs after Month 36 (🔴 High) — needs a project decision

- **Review 5.2, Review 11.3, Review 14.3:** The EUR 150M force-majeure reserve 'is escrowed for pool top-ups only after Month 36'; the pool is expected to be stressed in Months 30-42.
- **Canonical pool_draw_policy; Review 14.3 itself ('violating the Month 36 ban'); Project Plan mitigation plans:** 'No public budget draw-downs on carrier pools after Month 36'; the reserve is 'drawable only for force-majeure pool top-ups'.
- **Why it conflicts:** The reserve is described as available only from the date after which public pool draw-downs are banned. Either the reserve is unusable when needed or the ban is breached. The canonical text lets the reserve be drawn for force-majeure but says nothing on whether the ban covers it. 'Only after Month 36' is not a canonical condition.
- **Suggested resolution:** A project decision is needed on whether the force-majeure reserve is exempt from the Month 36 ban. Options: (a) exempt, drawable for qualifying force-majeure events at any time, with the ban applying to ordinary pool deficits; (b) covered by the ban, so the reserve is released or re-allocated at Month 36; (c) post-Month 36 deficits fall entirely on carriers or recalibrated contributions. Remove the phrase 'only after Month 36' from the reviews once decided.

### 2. Concession envelope arithmetic: subsidy cap vs EUR 300M envelope (🔴 High) — needs a project decision

- **Review 11.1; Review 1.3:** Platform set-up EUR 30-50M, 'leaving EUR 250-270M for operating subsidy (capped at EUR 60M over five years, about EUR 12M/year)'. Subsidy overrun of EUR 75-150M is said to exceed the EUR 300M envelope.
- **Canonical budget_line_concession_eur_m, concession_subsidy_cap_eur_m, open_decisions (1); Review 3.3; Self-Audit 3:** Operating subsidy is capped at EUR 60M over five years; set-up is EUR 30-50M (proposed), so roughly EUR 190-210M of the EUR 300M has no stated use. EUR 60M + EUR 150M overrun = EUR 210M, which is below EUR 300M.
- **Why it conflicts:** EUR 250-270M cannot be 'operating subsidy' when the subsidy is capped at EUR 60M. The overrun cannot 'exceed the envelope' while about EUR 200M of the envelope is unassigned. The 20% concession cut (EUR 60M) equals the whole subsidy cap, so it is unclear what is being cut. Review 3.3's claim that the business case 'locks the EUR 300M envelope' rests on only about EUR 110M of defined use.
- **Suggested resolution:** Decide what the remaining roughly EUR 190-210M funds ('public service-level payments' is named but unquantified), or whether the envelope should be reduced and the difference returned to headroom. Until then, show the set-up / subsidy / unallocated split explicitly and remove 'exceeding the envelope' and 'EUR 250-270M operating subsidy'.

### 3. EUR 85M headroom claimed several times over; no funding source for the EUR 50M reserve (🔴 High) — needs a project decision

- **Canonical budget_unallocated_headroom_eur_m; Exec Summary Risks; Review 1.2, 2.2, 3.2:** Free headroom is EUR 85M. A separate EUR 50M adapter-acceleration reserve is created, and the reserve 'preserves EUR 50M+ of headroom'.
- **Review 6.1, 6.3, 11.2, 5.1, 10.2, 15.1, 5.3, 10.1; Premortem A8:** Further draws on headroom: EUR 15M concession emergency (KPI 1), EUR 5-10M complaint handling (KPI 3), EUR 30-80M validation hardware (Review 11.2), EUR 30-50M or EUR 50M shadow-standards workstream (Reviews 10.2, 5.1), EUR 5-10M per slip (Review 15.1), EUR 50-75M bilateral/reallocation (Reviews 5.3, 10.1).
- **Why it conflicts:** Named claims sum to roughly EUR 130-205M against EUR 85M. A EUR 50M reserve taken from headroom leaves EUR 35M, not 'EUR 50M+'. No canonical budget line contains an adapter-acceleration reserve; the lines sum to EUR 1,415M. A8 requires validation financing 'without drawing on the EUR 85M headroom' while Review 11.2 says it comes from headroom. Financing of validation hardware is an open decision (canonical open_decisions 2).
- **Suggested resolution:** Decide the funding source and priority order for contingency claims: whether the EUR 50M reserve is carved from headroom (leaving EUR 35M), from the EUR 240M adapter line, or is dropped; and who finances validation hardware (carriers, public, or split). Then cap total claims on headroom at EUR 85M and delete 'preserves EUR 50M+ of headroom'.

### 4. Variance triggers (EUR 100/200/300M) vs EUR 85M headroom and hard cap; inconsistent trigger set (🟡 Medium) — needs a project decision

- **Review 2.2 vs Review 1.2, 3.2:** Fallback exposures 'exceed unallocated headroom by EUR 190-415M', and triggers at EUR 100/200/300M are 'mathematically likely' (net of headroom basis). Elsewhere the same triggers are compared with gross EUR 275-500M exposures and 'adapter slip + concession overrun = EUR 200M+'.
- **Canonical public_budget_cap_eur_m, budget_variance_triggers; Self-Audit 18:** Total public budget is a hard cap of EUR 1,500M with only EUR 85M free headroom; the first scope-cut trigger is EUR 100M. Self-Audit 18 lists contingency triggers of 'EUR 50M, EUR 100M, EUR 200M'.
- **Why it conflicts:** If variance is net of headroom, spend can exceed the hard cap by EUR 100M before any cut. If it is gross, an overrun of EUR 85-100M has no funding and breaches the cap before the first trigger. The basis is not stated, and Self-Audit 18 introduces a EUR 50M trigger and a different top trigger (EUR 200M) than the canonical set.
- **Suggested resolution:** Define the variance measure and base (gross cost growth against committed lines, or net of headroom) so that no trigger can fire after the hard cap is exceeded. Replace the Self-Audit 18 trigger list with the canonical EUR 100M / 200M / 300M set. If the first trigger is meant to sit at or below the headroom, that changes a canonical value and needs a deliberate decision.

### 5. Deferral trigger and effect on the Month 18 binding-standards milestone; pilot-authority dates (🟡 Medium)

- **Canonical phase1_readiness_gate, binding_standards_milestone; Review 13.1; Project Plan:** Gate at Month 6; if unresolved by Month 9, defer to Month 12; binding standards remain Month 18 (user constraint). Deferral 'compresses Phase 1 by 3-6 months'.
- **Self-Audit 5, Self-Audit 14, Review 2.3, 5.1, 8.3, 9.3, 10.2:** 'If liability sign-off or audit results slip past Month 6, invoke a pre-approved deferral to Month 12 and adjust binding-standards target to Month 24.' Pilot authority is set 'by Month 3 if prerequisites slip past Month 6' (Reviews 2.3, 5.1) but 'if prerequisites slip past Month 9' (Reviews 9.3, 10.2) and 'by Month 6' (Review 8.3, Self-Audit 16, Pitch).
- **Why it conflicts:** The trigger is Month 6 in some places and Month 9 in others. A pre-approved retarget of binding standards to Month 24 contradicts the Month 18 user constraint, while other documents keep Month 18 and compress Phase 1. The pilot and shadow-standards contingency carries three different readiness and trigger dates.
- **Suggested resolution:** Keep the canonical rule: gate at Month 6, deferral to Month 12 if unresolved by Month 9. Keep Month 18 as the milestone and record any slip beyond it as a risk outcome (estimate), not a pre-approved re-baseline. Set one date for shadow-standards and pilot-authority readiness (Month 6) and one launch trigger (slip past Month 9).

### 6. Concession term and timeline vs five-year programme horizon (🟡 Medium) — needs a project decision

- **Canonical concession_timeline, concession_subsidy_cap_eur_m, budget_variance_triggers:** Tender issued Month 12, award about Month 18, service live about Month 30; subsidy cap EUR 60M 'over five years'; EUR 200M trigger extends the term from 5 to 7 years.
- **Review 14.1; Self-Audit 15; Premortem FM7:** 'The concession term ends Month 60' and 'the five-year term (Month 60) ends'. FM7 tripwire: 'fewer than 3 compliant bids at tender close in Month 12'.
- **Why it conflicts:** A five-year term starting at service launch (about Month 30) runs to about Month 90, or longer with the 7-year extension, so it cannot end at Month 60. Subsidy paid after Month 60 sits outside the five-year public funding horizon. The tender is issued at Month 12, so it cannot also close in Month 12.
- **Suggested resolution:** Specify when the five-year term starts (award or service launch) and who pays subsidy beyond Month 60; the term needs a decision if it is meant to end with the programme (then it is about 2.5-3.5 years, not five). Correct the FM7 tripwire to a tender-close date after Month 12, before the award at about Month 18.

### 7. Regulation-slip thresholds in FM5 and their relation to the Tier 1 date (🟡 Medium) — needs a project decision

- **Premortem A6, FM5 tripwires; canonical regulation_adoption_assumption:** A6 failure trigger: adoption later than Month 24. FM5 tripwire: Regulation not adopted by Month 21. A 6-12 month slip beyond Month 18 is 'plausible', i.e. Month 24-30.
- **Premortem FM5 stop rule; canonical mandatory_api_exposure_milestone:** FM5 stop rule: convert to a voluntary corridor-pilot model only if the Regulation is not adopted by Month 30, which is also the Tier 1 mandatory API exposure date.
- **Why it conflicts:** The failure trigger (Month 24), tripwire (Month 21) and stop (Month 30) disagree. The plausible slip band reaches the failure and stop dates. By Month 30 the Tier 1 build and EUR 80M tranche release are due, so the stop point comes after the commitment has been made. Tier 1 exposure at Month 30 is described as unenforceable without a statute.
- **Suggested resolution:** Set one adoption-slip tolerance and say what it triggers: for example, which month adoption must be confirmed so that Tier 1 funding (Month 30) is not released on a voluntary basis. This is a project decision (the thresholds are proposed values); the options are to stop earlier than Month 30 or to accept voluntary Tier 1 exposure.

### 8. Pilots (Months 12-18) test settlement and reconciliation before clearing and adapters exist (🟡 Medium) — needs a project decision

- **Review 15.3; Exec Summary; canonical pilots_and_validation:** Pilots at Months 12-18 with 500-1,000 passengers per corridor are the basis for 'ready for Phase 2' and check '>2% reconciliation errors' and rerouting latency.
- **Review 3.2, 16.2; Exec Summary Action Orientation; Project Plan mitigation plans:** Shared adapters are procured by Month 12; the clearing contract is conditional on DG COMP guidance (Month 12) and clean-team approval (Month 14); pilots before Month 14 run 'on non-contested data flows only'; reconciliation-platform automation is piloted at Months 18-24.
- **Why it conflicts:** Settlement and reconciliation are the contested data flows, and their platform is not contracted or built when the pilots start. The pilots therefore cannot verify reconciliation, settlement cycle or the Phase 2 readiness criteria that depend on them. The dependency (platform, clean-team approval) is scheduled after the activity that needs it.
- **Suggested resolution:** State what the pilots cover: which flows are live, which are simulated, and which settlement mechanism is interim. Move reconciliation and settlement-cycle criteria out of the Month 18 pilot readiness test, or add an interim bilateral settlement arrangement before Month 14. Both are options for a project decision.

### 9. Liability gate: contracting date, data thresholds and what is validated when (🟡 Medium)

- **Canonical liability_decision_timeline; Review 13.1, 8.1, 3.1; Self-Audit 2:** Actuarial study commissioned Month 1 (contracted no later than Month 1.5), interim Month 3, carrier loss data from 5+ major carriers by Month 1, 36 months of claims data; trailing 12-month on-time contributions; sign-off Month 4 against interim parameters.
- **Premortem FM3, FM4; Review 8.1; Pitch Risks and Call to Action:** FM4 tripwire: actuarial firm 'not contracted by Month 2' (leaving one month to the Month 3 interim). FM3 tripwire: loss data 'from fewer than 3 major carriers'. Review 8.1 asks for 24 months of data. Pitch lists 'actuarial study (Month 6)' as the mitigation for the Month 4 sign-off.
- **Why it conflicts:** A Month 2 contracting deadline is later than the Month 1.5 deadline and leaves one month for the interim. A threshold of 3 carriers is below the 5+ required elsewhere. The claims-data window is 24 vs 36 months. The Pitch cites the Month 6 study as the basis for a Month 4 sign-off. The Month 4 sign-off rests only on Month 3 interim parameters.
- **Suggested resolution:** Use Month 1.5 as the latest contracting date (tripwire at Month 1.5, not 2), 5+ carriers as the loss-data minimum, and one data window. State in the Pitch that Month 4 sign-off is against interim parameters, with the Month 6 final study adjustable only within the agreed band.

### 10. Per-incident cap vs per-stranded-passenger cap (unit mismatch) (🟡 Medium)

- **Canonical liability_indicative_parameters; Review 1.1; Self-Audit 4; Premortem A1:** Indicative cap is 'EUR 500-1,000 per stranded passenger'.
- **Self-Audit 3; Review 7.3:** 'indicative parameters (EUR 500-1,000 per-incident caps, EUR 50M co-insurance threshold)' and 'EUR 500-1,000 per-incident caps'.
- **Why it conflicts:** A per-incident cap of EUR 500-1,000 would be negligible against a EUR 50M co-insurance threshold, while a per-passenger amount of the same size would scale with incident size. The unit is per passenger. The actual per-incident aggregate cap is not specified.
- **Suggested resolution:** Use 'per stranded passenger' for the EUR 500-1,000 value everywhere (proposed threshold) and add that the per-incident aggregate cap is to be set by the actuarial study.

### 11. Direct-operation cost: EUR 30-50M total vs EUR 30-50M per year (🟡 Medium)

- **Canonical fallback_cost_exposures_vs_headroom; Premortem FM7:** Concession failure fallback: direct public operation EUR 30-50M (estimate), which 'fits' within the EUR 85M headroom.
- **Self-Audit 15; Review 14.1, 14.2:** 'public direct management (EUR 30-50M annual cost to the Commission)'; ongoing operations 'EUR 30-50M annually', i.e. EUR 150-250M over five years.
- **Why it conflicts:** If the figure is annual, direct operation over a five-year horizon is EUR 150-250M and does not fit the EUR 85M headroom. The same range is used for a total in one place and an annual figure in another, and for the concession in one case and the whole programme in another. Review 14.1's EUR 150-300M five-year extension (30-50M x 5 = 150-250M) is also not consistent with its own annual figure.
- **Suggested resolution:** State the basis (total or per year) and scope (concession only or whole-programme operations) of the EUR 30-50M figure. Keep the canonical total for the concession fallback; present post-Month 60 operating cost as a separate estimate with its own unit.

### 12. DG COMP pre-notification timing recommendation contradicts itself (⚪ Low)

- **Executive Summary Feedback; Review 10.3:** Lock DG COMP pre-notification 'by Month 2 (2026-12-12), not Month 2 (2026-12-12), to recover 4-6 week schedule buffer'.
- **Canonical competition_law_timeline; Project Plan; Premortem A3:** DG COMP pre-notification Month 2 (2026-12-12), as in the canonical competition_law_timeline and all other documents.
- **Why it conflicts:** The recommendation contrasts a date with itself, so it states no change, yet claims a 4-6 week buffer gain that would require filing earlier than Month 2.
- **Suggested resolution:** Keep Month 2 as the canonical filing date and delete the 'not Month 2' clause and the buffer claim, unless an earlier filing is deliberately adopted, which would change the canonical value.

## Summary

The plan is largely coherent on the headline structure: canonical budget lines sum to EUR 1,415M with EUR 85M headroom, tier funding sums to EUR 240M, and the Month 4 non-binding sign-off versus the Month 6 binding vote, the audit and the clearing/DG COMP timing are now mostly consistent. The unresolved problems are mainly missing project decisions rather than typos: how the reserve relates to the Month 36 draw-down ban, what the EUR 300M concession envelope actually funds and for how long, who funds the several claims on the EUR 85M headroom (including validation hardware), and on what basis the EUR 100/200/300M triggers are measured against a hard cap. A few residual date, unit and threshold mismatches remain (deferral and pilot-authority dates, Month 24 re-baselining against the Month 18 user constraint, per-incident vs per-passenger cap, annual vs total direct-operation cost), all of which are repairable by correcting text to the canonical value.