_Consistency: first pass found 2 high / 6 medium / 0 low contradictions, and the arithmetic check found 2 wrong calculations. Repair: round 1: 38 edits → 0 high / 4 medium. Shown below: the final check of the repaired documents (0 high / 4 medium / 1 low)._

## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Is the written Council/Commission delegation of binding technical authority to the arbitration panel signed? | Signed by Month 2 (text agreed by Month 1.5 as target); panel 8-12 FTE, rulings within 60 days, 14 days to comply or escalate. Failure trigger in the premortem: Council Legal Service estimates more than 4 months. | Signed delegation instrument; Council Legal Service opinion (Month 1); bilateral carrier sessions (Months 0-1). | Escalate to the Commission for fast-tracking and pause carrier commitments. If still unsigned after the premortem's 4-month tolerance, re-baseline the governance model (e.g. a heavier legal vehicle, accepting delay) or stop. Note that the delegation precedes Regulation adoption (Month 9), so its legal basis must be confirmed. |
| 2 | Have carriers above EUR 50M cross-border revenue signed Commitment Letters (including escrow penalties of 0.5-1% of quarterly through-ticket revenue)? | At least 95% of carriers above EUR 50M signed by Month 3 (proposed threshold); no top-5 carrier unsigned at Month 4. | Signed Commitment Letters collected at Month 3; written preconditions from DB, SNCF, OBB gathered in Months 0-1. | Steering Committee re-baseline at Month 4. Hold co-funding and onboarding commitments. If a top-5 carrier refuses binding rulings, reduce scope to willing carriers/corridors or stop. |
| 3 | Does the willingness-to-pay evidence show enough demand for the sum-of-segment through-ticket (EUR 70-90 vs flights at EUR 40-70)? | At least 8% of respondents prefer the through-ticket at Month 4 (proposed threshold, to be justified against the 40% target); pilot conversion at least 3% at Month 12 (proposed threshold). | Conjoint survey (300-500 respondents per corridor) by Month 4; one-corridor pilot from Month 9 with conversion read at Month 12. | Stop scaling marketing beyond the pilot corridor, focus on corridors with weak air competition, and re-scope the 40% target or take a new, unfunded decision on fare support. |
| 4 | Does the bottom-up cost model with binding quotes keep demand inside the budget lines? | Co-funding grant demand within the EUR 234M grant line (failure level about 20% over); distributor run-rate at or below EUR 50M/year; any projected overrun fits the EUR 215M free contingency. | Cost model (Month 2); binding quotes from 8-12 carriers and distributor-operator candidates (Months 4-6); distributor scope decision (Month 2); funding decision on supplementary authority. | Downsize: cut the co-funding rate (Tier 2, 20% to 10%) or reduce the distributor to reference scope. If exposure still exceeds the free contingency, either obtain an explicit cap increase before committing awards, or reduce scope. Do not rely on an unsecured supplementary authority. |
| 5 | Has the Regulation been adopted by the gate, leaving a workable standards window? | Adopted by Month 9; if not adopted by Month 10, pause carrier onboarding commitments and re-baseline. Adoption probability at or below 70% at Month 6 triggers the external standards consortium (proposed thresholds). | Parliament/Council adoption record; weekly tracking with TRAN/IMCO rapporteurs; divergence check against shadow standards (liability, data scope, API scope, access definition). | Delay: pause onboarding and re-baseline Month 18 and Month 30 (each month of slip removes one standards month). If still unadopted at Month 12, restructure the programme or stop. |
| 6 | Are hubs and settlement ready to carry real traffic? | At least 2 accredited payment providers operational by Month 12 (fewer than 2 applicants by Month 6 triggers the fallback); 4 hubs operational by Month 9 with booking-failure rate below 2% (target below 0.5%); settlement under 48 h in dry-run before any corridor opens (by Month 18). | Accreditation decision (Month 8) and provider go-live (Month 12); hub contracts (Month 3), operational start (Month 9), dual-runs and pilots (Months 15-18); settlement dry-run results. | Use the bilateral-settlement or emergency-procurement fallback (EUR 10M clearing reserve). Do not open corridors to through-ticket sales without a settlement route under 48 h. Drop failing hubs from the Month 30 plan and downsize the 90% bookability expectation (below 90% triggers Commission review). |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: executive summary / premortem FM1 / pitch
    canonical: fallback_budget_overrun_exceeds_cap = EUR 300-450M overrun exceeds EUR 215M free contingency by EUR 85-235M; supplementary authority EUR 100-200M is outside the cap and would not cover the upper case
    observed:  Supplementary authority presented as the mitigation for a fixed-cap programme
HIGH CF-002  document: review (Critical Assumptions / Data Quality / Changed Assumptions) and premortem A3
    canonical: measurement_baseline = interim through-ticket share gate 15% at Month 24 (proposed threshold)
    observed:  8% used as survey, share and modal-shift trigger
HIGH CF-003  document: canonical_facts / premortem FM3 / review KPIs
    canonical: measurement_baseline = interim through-ticket share gate 15% at Month 24 (proposed threshold)
    observed:  Gate at Month 24 while first-corridor go-live is Month 30 and consumer four-corridor go-live Month 27
MEDIUM CF-004  document: review plan
    canonical: contingency_free_eur = EUR 215 million free contingency (225 - 10)
    observed:  EUR 60-110M excess said to exhaust free contingency by Month 18
MEDIUM CF-005  document: review plan
    canonical: private_carrier_it_estimate_eur = EUR 0.5-2.0 billion total; planning value EUR 1.25 billion, outside the cap (estimate)
    observed:  ROI erosion of 20-30% on EUR 1.25B against a EUR 60-200M/year pool
MEDIUM CF-006  document: pitch / review plan
    canonical: fallback_hub_failure_and_fare_support = Subsidised through-fares if modal shift is under 10% at Month 48 are unfunded and need a new decision
    observed:  'below 8% by Month 48'; 'achieved through superior pricing'
MEDIUM CF-007  document: executive summary
    canonical: consumer_app_timeline = Four-corridor consumer go-live Month 27
    observed:  First corridor go-live by Month 30
MEDIUM CF-008  document: self-audit / review plan / premortem FM1
    canonical: alloc_carrier_cofunding_eur = EUR 290 million = grants EUR 234M + hubs EUR 44M + accessibility EUR 12M
    observed:  EUR 310M trigger; grants raised to EUR 280M; EUR 348M used as both warning and failure
MEDIUM CF-009  document: pitch / self-audit
    canonical: hub_economics_gap = Gap about EUR 0.47M/yr per hub (about EUR 1.9M/yr for 4 hubs); sunset/cost-recovery at Month 48
    observed:  'aim to move to fee-based models'; EUR 9.5M total gap
MEDIUM CF-010  document: self-audit / review plan
    canonical: alloc_reference_distributor_eur = EUR 215 million over Months 0-60 (avg about EUR 43M/year)
    observed:  EUR 43M/year said to be reference-only scope
MEDIUM CF-011  document: pitch
    canonical: payment_accreditation_timeline = Call for applicants Month 2; decision Month 8; at least 2 providers operational Month 12
    observed:  'Apply for accreditation by Month 2'; distributor roadmaps by Month 3, early API access Month 15
LOW CF-012  document: executive summary
    canonical: api_mandate_threshold = At least 90% of corridor traffic bookable end-to-end by Month 30; below 90% triggers Commission review (proposed threshold)
    observed:  Month 30 to 90 (...)%+ of corridor traffic
```

### 1. Fixed cap vs overrun beyond free contingency (who pays the excess) (🔴 High) — needs a project decision

- **Executive summary (Timeline and Budget); project plan Goal Statement; pitch (Fiscal discipline):** Public budget is a fixed EUR 1,500 million cap with EUR 215 million free contingency.
- **Executive summary Risk 3; review (Critical Issues 3); pitch (Risks); premortem FM1:** A 20-30% overrun (EUR 300-450M) exceeds free contingency by EUR 85-235M; a supplementary authority of EUR 100-200M (estimate) is proposed, 'not yet secured' and 'may still not close the gap'.
- **Why it conflicts:** A supplementary authority is by definition outside a fixed cap. The documents give no source for the residual gap: EUR 35M if the full EUR 200M is granted, up to EUR 235M if nothing is granted. They do not say who finances it if Tiers 1-3 cannot close it.
- **Suggested resolution:** Decide explicitly before Month 3 between: (a) a pre-agreed Commission/Council top-up that formally lifts the cap; (b) Tier 3 cuts sized to absorb the full EUR 85-235M exposure; (c) hard limits on co-funding awards so committed exposure never exceeds the EUR 215M free contingency. Until then, stop describing the cap as 'fixed' and the supplementary authority as a mitigation.

### 2. The '8%' threshold is reused for different metrics and months (🔴 High) — needs a project decision

- **Premortem A3/FM3; review (Critical Assumptions, Changed Assumptions 3, Report Objectives):** Stop/escalate if survey preference for the through-ticket is below 8% at Month 4; pilot conversion below 3% at Month 12.
- **Review (KPIs 1, Data Quality 2, Changed Assumptions 3); premortem FM3/FM6 stop rules:** Stop/contingency if through-ticket share is below 8% at Month 24, and if modal shift is below 8% by Month 48 (stop level also used for 'elasticity below 8% modal shift' at Month 12).
- **Why it conflicts:** One number is used as a stated-preference threshold, a market-share stop level and a modal-shift trigger, with decision dates at Months 4, 12, 24 and 48. A reader cannot tell which metric and month apply. A survey preference of 8% is also far below the 40% share the plan needs, so passing it proves little. The same review gives the willingness-to-pay study as 'Months 1-6' in one place and 'complete by Month 4' elsewhere.
- **Suggested resolution:** Define three separately named thresholds, each with a metric, month and owner: (1) stated-preference at Month 4, justified against the 40% target; (2) pilot conversion at Month 12 (3%, proposed threshold); (3) through-ticket share at Month 24 (15% gate, 8% stop). Treat modal shift separately (see modal-shift item). Fix the survey window at Months 1-4.

### 3. Month 24 share gate and Month 12 pilot precede the capabilities they measure (🔴 High) — needs a project decision

- **Canonical facts; pitch (Metrics); review (KPIs 1, Recommended Actions 2); premortem FM3:** Interim gate: through-ticket share at least 15% at Month 24; fee subsidy ends at Month 24 unless share reaches 15%. Pilot conversion measured at Month 12 from a pilot launched by Month 9.
- **Executive summary (Deliverables); canonical facts; premortem A8:** First corridor go-live at Month 30; four-corridor consumer go-live at Month 27; API mandate Month 30; binding standards Month 18; accredited payment providers operational only at Month 12; monthly reporting starts Month 18.
- **Why it conflicts:** A 15% share of all cross-border journeys is required at Month 24, before any corridor is live for through-tickets (Month 27/30) and before the API mandate. The Month 9 pilot, which needs single-payment settlement and refunds, starts before providers are operational (Month 12) and before the Month 18 standards. The documents do not say what counts toward the Month 24 share or how it is measured. The gate that triggers co-funding review, subsidy end and the stop rule may therefore be unreachable by design.
- **Suggested resolution:** Decide what the Month 24 gate measures (e.g. share on live pilot corridors only, or share of eligible journeys), or move it after first-corridor go-live. State which settlement route the Month 9 pilot uses (bilateral/interim) and keep the Month 12 conversion test tied to it.

### 4. Contingency exhaustion claims do not reconcile with the sized cost drivers (🟡 Medium)

- **Review (Critical Issues 3; Budget Clarifications 2; Financial Strategy 3):** Free contingency of EUR 215M is 'exhausted by Month 24 under realistic cost scenarios'. A EUR 60-110M co-funding excess is said to exhaust it 'by Month 18'.
- **Review (Critical Issues 3; Review 2 item 3; Review 4 item 3; Financial Strategy 1):** The same review sizes the identified drivers at EUR 50-200M 'unaccounted' and the co-funding excess at EUR 60-110M, both below EUR 215M. Other sections give exhaustion at Month 24-30 or Month 30.
- **Why it conflicts:** Arithmetic: EUR 60-110M cannot exhaust EUR 215M, and EUR 50-200M is below it. Exhaustion needs the 20-30% (EUR 300-450M) headline scenario, which the identified drivers do not produce. The exhaustion month varies between Month 18, 24 and 30 across the review.
- **Suggested resolution:** Restate: the named drivers consume about 25-95% of free contingency (EUR 50-200M of EUR 215M), and exhaustion occurs only if several drivers combine or the 20-30% scenario materialises. Use one exhaustion month, or give a range tied to a named scenario.

### 5. Private IT spend vs through-ticket revenue pool (🟡 Medium)

- **Review (Implementation Consequences 1; Motivation Factors 1); canonical facts:** Private carrier IT planning value EUR 1.25 billion; carrier ROI said to erode 20-30% if the mandate slips.
- **Review (Implementation Consequences 1); assumptions Q5:** Revenue pool EUR 60-200M per year (40% of ~3-5 million passengers at EUR 50-100); the 3-5 million base comes from two corridors in the assumptions, not all cross-border traffic.
- **Why it conflicts:** The pool earns EUR 150-500M over Months 30-60, so it could not repay EUR 1.25B (it would take roughly 6-20 years of the whole pool). The passenger base is borrowed from a two-corridor modal-shift estimate. The ROI language implies a payback the arithmetic does not support.
- **Suggested resolution:** Drop ROI language. Present private IT as a mandated compliance cost with benefits shown separately (revenue, avoided costs). State the passenger base and its scope, and label the revenue pool (estimate).

### 6. Modal-shift outcome stated as achieved; Month 48 trigger inconsistent (🟡 Medium)

- **Pitch (Long-term Vision):** 'A 5-15% modal shift from short-haul air is achieved through superior pricing and convenience.'
- **Canonical facts; review (Data Quality 2) vs premortem FM3 and canonical:** Through-fare is sum of segments with no ceilings (EUR 70-90 vs flight EUR 40-70); 5-15% is a planning range, not a commitment. Fare support is triggered if modal shift is below 8% by Month 48 in one place and below 10% in another.
- **Why it conflicts:** The pitch turns an estimate into an achievement and names 'superior pricing', which the through-fare rule and the plan's own price estimates contradict. Both Month 48 triggers sit inside the 5-15% planning range, so a normal outcome would trigger an unfunded fare-support decision.
- **Suggested resolution:** Reword the pitch as a planning range, driven by convenience and reduction-card recognition rather than price. Use the canonical Month 48 trigger of under 10% everywhere (the 8% in the review is wrong). Decide separately whether the trigger should sit below the planning range.

### 7. Corridor go-live sequence undefined (🟡 Medium) — needs a project decision

- **Executive summary (Key Deliverables); review (Motivation Factors 1):** First corridor (Paris-Brussels-Amsterdam-Koln) through-ticketing go-live by Month 30; the first corridor must show at least 5% of corridor traffic (estimate).
- **Pitch (Long-term Vision); canonical consumer_app_timeline:** By Month 30 any conformant distributor sells through-tickets on all four priority corridors; four-corridor consumer go-live at Month 27; 'full' deployment at Month 60.
- **Why it conflicts:** All four corridors are consumer-live at Month 27, before the 'first' corridor goes live at Month 30. 'Go-live', the Month 30 API mandate and Month 60 'full deployment' are not distinguished.
- **Suggested resolution:** Define the terms. Suggested reading: consumer go-live (Month 27, app on four corridors), API mandate (Month 30, 90% bookable), full through-ticketing (Month 60, 40% share). Name which corridor goes first and drop the 'first corridor at Month 30' wording if all four are live earlier.

### 8. Carrier co-funding line: thresholds and funding of the increase (🟡 Medium) — needs a project decision

- **Canonical facts; review (Budget Clarifications 2); premortem FM1:** Co-funding line EUR 290M = EUR 234M grants + EUR 44M hubs + EUR 12M accessibility; early-warning level EUR 290M, failure level about EUR 348M (20% over).
- **Self-audit (Budget Too Low); review (Critical Assumptions 1):** Tier 2 triggered if requests exceed EUR 310M by Month 12; grants raised 'from EUR 234M to EUR 280M' at Month 18 if private spend is under 70% of plan, with no stated source.
- **Why it conflicts:** Three different trigger levels (290, 310, 348) are in use. Demand is compared with the full EUR 290M although only EUR 234M is grants. Raising grants by EUR 46M has no source in a fixed budget; the premortem uses EUR 348M as both early warning and failure level. A larger co-funding line also conflicts with the Tier 2 aim of cutting the rate to protect the cap.
- **Suggested resolution:** Use one demand metric (grant demand vs EUR 234M) with one early-warning level and one failure level (EUR 348M is the 20%-over figure for the full line; recompute if grants only). Remove or fund the 234 to 280 increase explicitly (e.g. from free contingency).

### 9. Hub end state at Month 48 and unresolved hub gap (🟡 Medium) — needs a project decision

- **Canonical hub_timeline; pitch (Long-term Vision):** Hub sunset/cost-recovery at Month 48; hub operators 'aim to move to fee-based models'.
- **Canonical post_month60_unfunded_run_cost; pitch; self-audit (Budget Too Low):** Hubs lose about EUR 0.47M per year each at capacity (about EUR 1.9M/year for 4), a gap that continues after Month 60. TEN-T carriers join via hubs from Month 36, with TEN-T hub decision at Month 30. Self-audit puts the gap at EUR 9.5M over 5 years.
- **Why it conflicts:** Cost recovery at Month 48 cannot be reached at current fees, since fee revenue covers about 61% of opex at capacity. 'Sunset' (carriers migrate to native) conflicts with hubs continuing after Month 60 and with TEN-T carriers joining via hubs. EUR 9.5M assumes five full years, but hubs operate only from Month 9.
- **Suggested resolution:** Decide the end state: (a) fee increase to full cost recovery, (b) a continued subsidy included in the post-Month 60 funding decision, or (c) a true sunset with migration. Recompute the gap from Month 9 (about 4.25 years).

### 10. Reference distributor scope vs EUR 43M/year budget (🟡 Medium) — needs a project decision

- **Self-audit (Money Issues; Budget Too Low):** EUR 43M/year 'assumes reference-implementation scope'; full retail could reach EUR 65M/year.
- **Review (Budget Clarifications 1); canonical alloc_reference_distributor_eur:** Reference-implementation only is EUR 20-30M/year and full retail EUR 60-100M/year; EUR 215M (about EUR 43M/year) sits between them, and scope is 'undefined'.
- **Why it conflicts:** The self-audit calls EUR 43M the reference-only cost; the review says reference-only is EUR 20-30M. The EUR 43M therefore funds neither scope as sized, and the EUR 50-110M, EUR 110M and EUR 150-250M overruns are not computed on a common base. Post-Month 60 cost also carries EUR 43M/year.
- **Suggested resolution:** Take the scope decision (planned by Month 2): reference-only, hybrid or full retail. Then restate the EUR 215M allocation against that scope, and base overrun figures and the EUR 50M/year tripwire on it.

### 11. Payment accreditation: 'apply by Month 2' vs call opening at Month 2 (🟡 Medium)

- **Pitch (Collaboration Opportunities; Call to Action):** 'Payment institutions: Apply for accreditation by Month 2.'
- **Canonical payment_accreditation_timeline; executive summary; project plan:** Call for applicants is issued at Month 2, decision at Month 8; fewer than 2 applicants by Month 6 triggers the fallback.
- **Why it conflicts:** Providers cannot apply by the same month in which the call opens. The pitch also asks distributors to sign roadmaps by Month 3 with early API access at Month 15, while the review has agreements by Month 6 and early access at Month 9, and the premortem tripwire is Month 6.
- **Suggested resolution:** Pitch: 'respond to the call opened at Month 2; application window to Month 6'. Align the distributor roadmap (Month 6) and early-access month (Month 9 or 15) across pitch, review and premortem.

### 12. Garbled API-mandate goal in executive summary (⚪ Low)

- **Executive summary (Purpose and Goals, item 4):** 'Mandatory API exposure by Month 30 to 90 (2029-04-08 to 2034-04-08)%+ of corridor traffic'.
- **Canonical api_mandate_threshold; project plan (Measurable); executive summary (Deliverables):** Mandatory API exposure by Month 30 with at least 90% of corridor traffic bookable end-to-end.
- **Why it conflicts:** The text reads as a Month 30 to Month 90 deadline range extending past the five-year horizon, instead of a 90% threshold at Month 30.
- **Suggested resolution:** Replace with 'by Month 30, at least 90% of priority-corridor traffic bookable end-to-end (proposed threshold)'.

## Summary

The plan is largely coherent. The budget lines sum to EUR 1,500 million, the contingency split (225 total, 215 free, 10 earmarked) is used consistently, and the Month 2/3/9/12/18/30/60 milestones mostly match the canonical facts. Several earlier problems are now fixed: standards-window arithmetic, payment award month, Council delegation sequencing, smaller-carrier Month 30 target and Month 24 readiness gates. The main open issues are economic and decision-related. The fixed cap has no stated funding source for an overrun beyond free contingency. The demand gates reuse an 8% threshold for different metrics and sit before the corridors go live. The co-funding line, distributor scope and hub end-state are not settled. The pitch still overstates modal-shift outcomes and has some timing slips.