### 1. Project Sponsor (DG MOVE Director or Transport Commissioner) formally initiates the programme and designates a senior DG MOVE official as Interim Programme Director to lead pre-governance setup activities. Interim Director is responsible for establishing the governance framework, engaging stakeholders, and preparing for formal Committee establishment.

**Responsible Body/Role:** Project Sponsor / DG MOVE Director

**Suggested Timeframe:** Project Week 0-1 (by Month 0.2 = 2026-10-18)

**Key Outputs/Deliverables:**

- Programme Initiation Memo signed by Project Sponsor
- Interim Programme Director appointed and briefed
- High-level stakeholder contact list and engagement calendar established

**Dependencies:**

- Project start date confirmed
- Budget allocation (EUR 1.5B) formally approved by the Commission

### 2. Interim Programme Director drafts the charter, membership, voting rules, and meeting schedule for the Programme Steering Committee (PSC). The charter must specify 75% supermajority voting for Decisions 1–5, escalation paths to the Commission Transport Commissioner, and monthly biweekly cadence. Draft charter is circulated to identified steering members for consultation.

**Responsible Body/Role:** Interim Programme Director (DG MOVE)

**Suggested Timeframe:** Month 0.3-1 (October–November 2026)

**Key Outputs/Deliverables:**

- Draft PSC Charter v0.1 (roles, voting, escalation, meeting schedule)
- Membership roster and stakeholder contact details
- Consultation feedback summary

**Dependencies:**

- Interim Programme Director appointed
- Stakeholder list and preliminary engagement complete

### 3. Project Sponsor formally approves the PSC Charter and appoints the Chair (DG MOVE Director or Transport Commissioner designate) and Vice-Chair (EU Agency for Railways Director). Appointment letters are issued by Month 1 (2026-11-12); both assume office immediately.

**Responsible Body/Role:** Project Sponsor / DG MOVE Director

**Suggested Timeframe:** Month 1 (2026-11-12)

**Key Outputs/Deliverables:**

- PSC Charter (approved, published version)
- Chair Appointment Letter
- Vice-Chair Appointment Letter

**Dependencies:**

- Draft Charter consulted and finalized
- Project Sponsor and Transport Commissioner alignment secured

### 4. Chair (DG MOVE) and Vice-Chair (Agency) jointly circulate binding commitment letters to the nine core PSC members (CER, three–four major carriers, Trainline, Omio, BEUC, disability-rights body, and one regulator observer) requesting formal acceptance of their seat, voting responsibility, and biweekly attendance by Month 2 (2026-12-12).

**Responsible Body/Role:** PSC Chair and Vice-Chair

**Suggested Timeframe:** Month 1.2-1.5 (mid-November 2026)

**Key Outputs/Deliverables:**

- Formal invitation letters to nine core members
- Binding commitment letters from each member (confirming attendance, voting authority, confidentiality)
- Signed Member Roster

**Dependencies:**

- PSC Charter approved and published
- Chair and Vice-Chair in office

### 5. Chair and Vice-Chair confirm all nine core members have signed binding commitment letters and are formally appointed to the PSC by Month 2 (2026-12-12). A kick-off briefing is scheduled for Month 1.5 (2026-11-27) to introduce the Charter, voting procedures, critical decision timeline and escalation paths.

**Responsible Body/Role:** PSC Chair

**Suggested Timeframe:** Month 2 (2026-12-12)

**Key Outputs/Deliverables:**

- Confirmed Member Roster (all nine signatures)
- PSC Formally Established Memo
- Kick-off Meeting Minutes and attendee list

**Dependencies:**

- Commitment letters from all nine core members
- Charter approved

### 6. Interim Programme Director commissions a detailed technical audit of all 25+ participating carriers' booking-system architectures, assessing OSDM API readiness, event-streaming capability, transaction consistency, latency and availability benchmarks. Audit is contracted to an independent systems integrator and is scheduled for completion by Month 2 (2026-12-12).

**Responsible Body/Role:** Interim Programme Director / Programme Office (once established)

**Suggested Timeframe:** Month 0.5-2 (October 2026–December 2026)

**Key Outputs/Deliverables:**

- RFP issued for technical audit
- Audit contract awarded
- Technical Audit Report: summary of each carrier's API readiness, legacy-system constraints, estimated integration timeline per tier

**Dependencies:**

- Interim Programme Director in place
- Carrier contact list and preliminary engagement complete
- Budget headroom identified for audit cost

### 7. Interim Programme Director commissions an independent actuarial firm to model missed-connection rates, rerouting costs, incident clustering and liability-pool sustainability. The study is to establish per-incident caps, co-insurance thresholds and contribution-weighting formulas tied to on-time performance. Interim findings due Month 3 (2027-01-12); final report due Month 6 (2027-04-12).

**Responsible Body/Role:** Interim Programme Director / Programme Office

**Suggested Timeframe:** Month 1-3 (November 2026–January 2027)

**Key Outputs/Deliverables:**

- RFP issued for actuarial study
- Actuarial contract awarded
- Interim Actuarial Report (Month 3 = 2027-01-12): draft liability model, indicative cap and co-insurance thresholds
- Final Actuarial Report (Month 6 = 2027-04-12): validated model with confidence intervals

**Dependencies:**

- Budget allocated for actuarial study
- Interim Programme Director appointed

### 8. Interim Programme Director initiates formal pre-notification with DG COMP (Competition Directorate) outlining the programme's data-sharing and clearing arrangements, requesting Article 101 TFEU guidance. A detailed legal brief is submitted to DG COMP, including the proposed federated clearing architecture, shared data layer and non-discriminatory distributor-access rules.

**Responsible Body/Role:** Interim Programme Director / Compliance Lead (engaged as external counsel or DG MOVE legal service)

**Suggested Timeframe:** Month 2 (2026-12-12)

**Key Outputs/Deliverables:**

- Legal brief to DG COMP (pre-notification package)
- Formal request for Article 101 guidance letter
- Confirmation of receipt from DG COMP

**Dependencies:**

- Clearing and data-sharing architecture decisions made (from scenario inputs)
- Legal counsel engaged

### 9. Interim Programme Director commissions an independent legal firm to conduct a detailed review of the Through-Ticket Liability and Rights Backstop design against EU Regulation 1371/2007 (existing rail passenger-rights law). The review assesses whether the proposed guarantee pool and liability model ensure that through-ticket passengers retain or exceed existing passenger-rights protections. Opinion due Month 6 (2027-04-12).

**Responsible Body/Role:** Interim Programme Director / Compliance Lead

**Suggested Timeframe:** Month 1-6 (November 2026–April 2027)

**Key Outputs/Deliverables:**

- RFP issued for passenger-rights legal review
- Legal review contract awarded
- Passenger-Rights Legal Opinion (Month 6 = 2027-04-12): assessment of compliance with Regulation 1371/2007, identified gaps, remediation recommendations

**Dependencies:**

- Liability model design clarified (from scenario inputs)
- Independent legal counsel engaged

### 10. Interim Programme Director, with the EU Agency for Railways, commences bilateral regulatory-impact assessments with each participating member state (approximately 5–6 member states, 25+ operators). Each assessment documents national railway regulations, antitrust rules, data-protection requirements and any conflicts with the programme's design. Assessments are completed by Month 3 (2027-01-12).

**Responsible Body/Role:** Interim Programme Director and EU Agency for Railways

**Suggested Timeframe:** Month 2-3 (December 2026–January 2027)

**Key Outputs/Deliverables:**

- Regulatory-Impact Assessment per member state (template and filled versions)
- Summary of identified conflicts and escalation flags
- Preliminary member-state engagement calendar

**Dependencies:**

- Participating member states and operators identified
- EU Agency for Railways capacity available for bilateral work

### 11. Interim Programme Director drafts three strategic options for each of Decisions 1–5 (Liability Backstop, Clearing Architecture, Public Distributor Role, Funding Release Ladder, Availability Query Topology), explicitly laying out trade-offs, budget implications, timeline impacts and carrier/distributor implications. The option-papers document is circulated to PSC members by Month 2 (2026-12-12) to inform their deliberation.

**Responsible Body/Role:** Interim Programme Director / Programme Office

**Suggested Timeframe:** Month 1.5-2 (late November–early December 2026)

**Key Outputs/Deliverables:**

- Strategic Options Document: Decision 1–5 with three variants each, trade-off analysis, impact on schedule and budget

**Dependencies:**

- Scenario pathway selected (pragmatic foundation, from input documents)
- Key stakeholder preliminary positions gathered

### 12. Interim Programme Director establishes the Operational Management Board (OMB) as a sub-committee of the PSC, appointing its Chair (Programme Director, full-time DG MOVE official) and Secretary (Operations Manager). The OMB Charter is drafted, specifying roles, weekly cadence during Phase 1, and escalation thresholds (€10M budget authority, milestone-tracking delegation). The Charter is circulated to OMB members for binding acceptance by Month 1.5 (2026-11-27).

**Responsible Body/Role:** PSC Chair and Interim Programme Director

**Suggested Timeframe:** Month 1-1.5 (November 2026)

**Key Outputs/Deliverables:**

- OMB Charter (roles, responsibilities, decision thresholds, meeting cadence)
- OMB Chair and Secretary appointments
- OMB Member roster (7 members) with binding commitment letters

**Dependencies:**

- PSC formally established
- Programme Director appointed (full-time)

### 13. Interim Programme Director appoints the Head of Standards and Conformance (Technical Secretariat lead at the Agency) and commissions the Technical Standards and Interoperability Working Group (TSWG). The TSWG Chair (senior OSDM expert) is appointed; membership includes carrier IT leads, distributor representatives, accessibility specialists and the Agency liaison. TSWG Charter is published by Month 1.5 (2026-11-27); first meeting held by Month 3 (2027-01-12).

**Responsible Body/Role:** Interim Programme Director and EU Agency for Railways

**Suggested Timeframe:** Month 1-3 (November 2026–January 2027)

**Key Outputs/Deliverables:**

- TSWG Charter (roles, decision authority, specification change-control process)
- TSWG Chair and membership roster
- Published OSDM change-control process (2-week critical, 6-week major, 8-week minor review timelines; quarterly release cadence)
- TSWG kick-off meeting minutes

**Dependencies:**

- EU Agency for Railways confirmed as OSDM custodian
- Technical expertise identified and available

### 14. Interim Programme Director appoints the Chair of the Compliance, Competition Law and Passenger Rights Committee (CCPR). The Chair is an external EU competition and transport-law expert, independent of DG MOVE and DG COMP. The CCPR Charter is drafted, specifying roles, decision authority (compliance certification, warnings, blocks), and monthly cadence during Phase 1. Charter is published by Month 1.5 (2026-11-27); membership letters issued to legal counsel, GDPR specialist, accessibility lead and BEUC observer by Month 2 (2026-12-12).

**Responsible Body/Role:** PSC Chair and Interim Programme Director

**Suggested Timeframe:** Month 1-2 (November–December 2026)

**Key Outputs/Deliverables:**

- CCPR Charter (roles, decision authority, escalation rules, quarterly reporting)
- CCPR Chair appointment (external legal expert, independent)
- CCPR Member roster (7 members) with binding commitment letters
- Compliance Roadmap (quarterly reporting schedule, legal-opinion milestones)

**Dependencies:**

- External legal expertise sourced (competition law, transport law, GDPR)
- PSC established with governance authority

### 15. Interim Programme Director establishes the Programme Office as a dedicated unit within DG MOVE, aiming for 80 staff (range 60–100). Initial staffing includes Programme Director, Operations Manager, Head of Standards and Conformance, Head of Clearing and Settlement, Head of Carrier Engagement, Head of Distributor and Consumer Affairs, Head of Compliance and Risk, and Financial Planning lead. Job descriptions are finalized by Month 1.5 (2026-11-27); recruitment begins immediately. Core staff onboarded by Month 3 (2027-01-12).

**Responsible Body/Role:** Interim Programme Director / DG MOVE HR and Budget

**Suggested Timeframe:** Month 1-3 (November 2026–January 2027)

**Key Outputs/Deliverables:**

- Programme Office Organizational Chart
- Job descriptions for 8–10 key roles
- Recruitment plan and timeline
- Initial staffing contracts signed (core team by Month 3 = 2027-01-12)

**Dependencies:**

- Budget allocated for programme management (EUR 75M)
- Interim Programme Director appointed
- DG MOVE HR approval secured

### 16. Interim Programme Director coordinates with the EU Agency for Railways to establish the Technical Secretariat (approximately 50 staff, range 40–60) at the Agency's Valenciennes headquarters. The Secretariat houses standards work, conformance testing, OSDM change control, and serves as the technical backbone for the programme. Organizational structure, staffing plan and budget are finalized by Month 2 (2026-12-12); recruitment begins Month 1.5 (2026-11-27). Core staff onboarded by Month 4 (2027-02-12).

**Responsible Body/Role:** EU Agency for Railways Director and Programme Director

**Suggested Timeframe:** Month 1-4 (November 2026–February 2027)

**Key Outputs/Deliverables:**

- Technical Secretariat Organizational Chart
- Staffing plan and job descriptions
- Budget allocation (from EUR 75M programme-management envelope) confirmed
- Recruitment contracts signed (core team by Month 4 = 2027-02-12)

**Dependencies:**

- EU Agency for Railways committed to hosting the Secretariat
- Budget headroom allocated
- Agency HR and governance approval

### 17. Programme Director (now in full-time office) establishes four physical liaison hubs in Brussels (EU institutions), Valenciennes (Agency), Berlin (carrier IT and corridor access), and Madrid (air-competitive corridor pilots). One full-time liaison officer is stationed at each hub by Month 3 (2027-01-12) to coordinate local stakeholder engagement, oversee pilots, and support async decision-making. Liaison roles are staffed from the Programme Office headcount budget.

**Responsible Body/Role:** Programme Director / Programme Office HR

**Suggested Timeframe:** Month 2-3 (December 2026–January 2027)

**Key Outputs/Deliverables:**

- Liaison hub locations and office arrangements confirmed
- Four liaison officer job descriptions and recruitment initiated
- Liaison officers onboarded (Month 3 = 2027-01-12)
- Hub communications infrastructure (video conferencing, secure networks) deployed

**Dependencies:**

- Physical location agreements reached
- Programme Office staffing plan includes liaison positions
- Budget allocated for travel and liaison staffing

### 18. PSC Chair schedules the first formal PSC meeting for Month 1.5 (2026-11-27), with a second follow-up meeting by Month 2 (2026-12-12). The agenda covers: (1) adoption of the PSC Charter and voting procedures; (2) circulation of the strategic options document (Decisions 1–5); (3) briefing on the technical audit and actuarial study timelines; (4) introduction of the OMB, TSWG and CCPR; (5) confirmation of biweekly meeting schedule through Month 6 (2027-04-12). Meeting minutes and attendance are published within 15 days.

**Responsible Body/Role:** PSC Chair

**Suggested Timeframe:** Month 1.5-2 (late November–early December 2026)

**Key Outputs/Deliverables:**

- PSC Meeting Agenda and briefing materials
- PSC Meeting Minutes (first and second meetings)
- Confirmed biweekly meeting schedule through Month 6 (2027-04-12)
- Published voting procedures and decision-record template

**Dependencies:**

- PSC formally established
- All nine core members committed and briefed
- PSC Chair and Secretary in office

### 19. CCPR Chair commissions four independent legal studies in parallel: (1) Article 101 TFEU compatibility of data-sharing and clearing; (2) passenger-rights compliance against Regulation 1371/2007; (3) GDPR and data-governance assessment; (4) accessibility and EU Accessibility Directive compliance. RFPs are issued by Month 1.5 (2026-11-27); contracts awarded by Month 2 (2026-12-12). Studies are scheduled for completion by Month 6 (2027-04-12) (interim findings available Month 3 = 2027-01-12).

**Responsible Body/Role:** CCPR Chair and Compliance Lead

**Suggested Timeframe:** Month 1.5-2 (late November–December 2026)

**Key Outputs/Deliverables:**

- RFPs issued for four legal studies
- Contracts awarded to independent legal firms
- Study schedules with interim and final milestones
- Interim findings briefing (Month 3 = 2027-01-12)

**Dependencies:**

- CCPR Chair appointed and in office
- Budget allocated for legal counsel (from programme-management envelope)
- CCPR Charter approved

### 20. Technical Secretariat Head (once onboarded by Month 3 = 2027-01-12) procures shared infrastructure for standards work, conformance testing and real-time monitoring: (1) shared reconciliation platform for settlement data (EUR 20–40M estimate, part of EUR 220M clearing budget); (2) SLA monitoring proxy for latency/availability/error-rate tracking (EUR 5–10M estimate, part of EUR 50M real-time layer budget); (3) test environments and conformance-testing infrastructure; (4) distributed caching layer for the availability shadow (EUR 15–25M estimate, part of EUR 50M real-time layer budget). RFPs issued by Month 3 (2027-01-12); contracts awarded by Month 4 (2027-02-12); deployment target Month 6 (2027-04-12).

**Responsible Body/Role:** Technical Secretariat Head and Head of Standards and Conformance

**Suggested Timeframe:** Month 3-6 (January–April 2027)

**Key Outputs/Deliverables:**

- RFPs and procurement strategy for shared infrastructure
- Contracts awarded for reconciliation platform, SLA proxy, test environments and caching layer
- Infrastructure deployment timeline and success criteria
- Initial SLA monitoring proxy live (limited carrier data, Month 6 = 2027-04-12)

**Dependencies:**

- Technical Secretariat staffed
- Budget allocated for infrastructure (EUR 270M total across clearing and real-time layer)
- Carrier data-feed pilots defined

### 21. Programme Director commissions external advisors to conduct a survey of Trainline, Omio and 5–10 smaller independent distributors to establish their cost-of-acquisition, customer-support, and payment-processing costs for cross-border through-tickets. The survey informs the Distribution Remuneration and Commission Corridor decision by establishing a cost-based commission band. Survey issued Month 2 (2026-12-12); results available Month 4 (2027-02-12); band recommendation ready for PSC decision by Month 6 (2027-04-12).

**Responsible Body/Role:** Programme Director and Head of Distributor and Consumer Affairs

**Suggested Timeframe:** Month 2-6 (December 2026–April 2027)

**Key Outputs/Deliverables:**

- Distributor survey RFP and questionnaire
- Survey completion and data analysis (Month 4 = 2027-02-12)
- Commission-band recommendation (proposed 2.5–4.5% of through-fare, or variant based on survey findings) ready for PSC approval (Month 6 = 2027-04-12)

**Dependencies:**

- Distributor contacts and willingness to participate confirmed
- Budget for survey consultant
- Programme Director and OMB established to frame the survey

### 22. Programme Director issues an RFP for the development of a reference OSDM implementation (sandbox and technical benchmark). The sandbox serves as a reference for carrier integration, a conformance test target and a basis for distributor client testing. RFP issued Month 2 (2026-12-12); contract awarded Month 3 (2027-01-12); initial sandbox delivered by Month 9 (2027-07-12); public release (open-source) by Month 12 (2027-10-12) to make it available to carriers for testing before Tier 1 conformance audits begin (Month 24 = 2028-10-12).

**Responsible Body/Role:** Technical Secretariat Head / TSWG Chair

**Suggested Timeframe:** Month 2-12 (December 2026–October 2027)

**Key Outputs/Deliverables:**

- RFP for reference OSDM implementation
- Sandbox development contract awarded
- Reference OSDM Sandbox v1.0 (private, Month 9 = 2027-07-12)
- Public Release (open-source, Month 12 = 2027-10-12)

**Dependencies:**

- OSDM specification defined (from TSWG work)
- Budget allocated for development (part of EUR 80M standards/conformance)
- Technical Secretariat capacity available

### 23. TSWG Chair, in consultation with participating carriers, publishes the formal OSDM change-control process and quarterly release schedule. The process specifies review timelines (critical: 2 weeks, major: 6 weeks, minor: 8 weeks), governance (technical review by at least three independent carriers, competition-law check for sensitive changes), version numbering and archiving. The process is published by Month 3 (2027-01-12); first quarterly release planned for Month 6 (2027-04-12). This process remains in effect post-binding standards (Month 18 = 2028-04-12) as the basis for specification evolution.

**Responsible Body/Role:** TSWG Chair and Technical Secretariat Head

**Suggested Timeframe:** Month 1-3 (November 2026–January 2027)

**Key Outputs/Deliverables:**

- OSDM Change-Control Process (published document with review timelines, approval gates, versioning rules)
- Quarterly Release Calendar
- Change-request dashboard template

**Dependencies:**

- TSWG established
- OSDM custodianship (EU Agency for Railways) confirmed
- Carrier input on process acceptability gathered

### 24. Programme Director and Head of Carrier Engagement conduct bilateral briefings with the ten largest carriers (DB, SNCF, Renfe, SBB, ÖBB, NS, SJ, Trenitalia, CFF, Ferrovie dello Stato or others based on network position) to introduce the programme, the technical audit, and the liability-model development timeline. Briefings take place during Months 2–3 (December 2026–January 2027); participants are offered observer seats on TSWG and invited to nominate IT representatives for the technical working group. Feedback is documented for incorporation into the actuarial study and liability model.

**Responsible Body/Role:** Programme Director and Head of Carrier Engagement

**Suggested Timeframe:** Month 2-3 (December 2026–January 2027)

**Key Outputs/Deliverables:**

- Bilateral briefing agenda and talking points
- Briefing attendance and feedback summary (per carrier)
- Carrier IT representative nominations for TSWG
- Preliminary carrier concerns and constraints documented

**Dependencies:**

- Programme Director in office
- Carrier contact list and availability confirmed
- Strategic options document and technical audit findings ready to share

### 25. TSWG Chair develops detailed conformance test cases for OSDM API compliance, latency (p95 <2 seconds proposed threshold), availability (99.5% proposed threshold), stale-seat failures (<1% proposed threshold), and booking-error rates. Test-case design is informed by carrier input and the reference OSDM implementation. Draft test cases are ready for review by Month 6 (2027-04-12); final test cases published by Month 12 (2027-10-12). Test environments are made available to Tier 1 carriers by Month 12 (2027-10-12) to begin integration testing before formal conformance audits (Month 24 = 2028-10-12).

**Responsible Body/Role:** TSWG Chair and Head of Standards and Conformance

**Suggested Timeframe:** Month 3-12 (January–October 2027)

**Key Outputs/Deliverables:**

- Conformance Test-Case Specification (API compliance, latency, availability, error-rate criteria)
- Test Environment Setup and Carrier Access Guidelines
- Public Conformance-Certification Registry (template, ready by Month 12 = 2027-10-12)

**Dependencies:**

- OSDM specification drafted or stabilized
- Reference OSDM implementation available for alignment
- Carrier and distributor input on test criteria gathered

### 26. Technical Audit Lead (contracted independent firm or Programme Office technical team) completes the detailed technical audit of all 25+ participating carriers' booking-system architectures and publishes the Technical Audit Report by Month 2 (2026-12-12). The report documents each carrier's API readiness, event-streaming capability, transaction consistency, latency benchmarks, availability data and estimated integration timeline. Carriers are assigned to three tiers: Tier 1 (large, corridor-critical, ready by Month 30 = 2029-04-12); Tier 2 (regional, ready Month 36 = 2029-10-12); Tier 3 (small, legacy-heavy, ready Month 42 = 2030-04-12).

**Responsible Body/Role:** Interim Programme Director / Programme Office (with contracted audit firm)

**Suggested Timeframe:** Month 0.5-2 (October–December 2026)

**Key Outputs/Deliverables:**

- Technical Audit Report: per-carrier assessment, tier assignment rationale, estimated integration timeline per tier
- Carrier Tier Assignment List (Tier 1, Tier 2, Tier 3)

**Dependencies:**

- Audit contract awarded (Month 1 = 2026-11-12)
- Carrier data and system access provided

### 27. Programme Director and OMB establish a published quarterly financial reporting and budget-variance tracking process. Reports track cumulative spend per budget line (standards EUR 80M, clearing EUR 220M, adapters EUR 240M, concession EUR 300M, capacity building EUR 200M, consumer rollout EUR 100M, programme management EUR 75M, reserve EUR 150M, headroom EUR 85M). Variance triggers at EUR 100M, EUR 200M and EUR 300M are defined with automatic escalation and mitigation actions. First financial baseline is published by Month 3 (2027-01-12); monthly tracking begins Month 4 (2027-02-12).

**Responsible Body/Role:** OMB Chair (Programme Director) and Financial Planning Lead

**Suggested Timeframe:** Month 2-3 (December 2026–January 2027)

**Key Outputs/Deliverables:**

- Quarterly Financial Reporting Template and Process (published)
- Budget Baseline by Line (EUR 1,500M total allocation)
- Variance Trigger Matrix (EUR 100M/200M/300M thresholds with mitigation rules)
- Initial Financial Baseline Report (Month 3 = 2027-01-12)

**Dependencies:**

- Programme Office established
- OMB operational
- Budget allocation confirmed by the Commission

### 28. Programme Director issues an RFP for the Tier 1 carrier-adapter modules (shared code, middleware, API adapters for large carriers' legacy booking systems). RFP issued Month 2 (2026-12-12); contracts awarded Month 6 (2027-04-12); adapter modules procured by Month 12 (2027-10-12) (EUR 30M estimate for shared modules, part of EUR 240M adapter budget). These modules are made available to all Tier 1 carriers to accelerate their Month 30 (2029-04-12) API exposure deadline.

**Responsible Body/Role:** Programme Director and Head of Carrier Engagement

**Suggested Timeframe:** Month 2-12 (December 2026–October 2027)

**Key Outputs/Deliverables:**

- Adapter RFP and technical specifications
- Adapter development contracts awarded (Month 6 = 2027-04-12)
- Shared Adapter Module v1.0 (Tier 1, Month 12 = 2027-10-12)
- Adapter Deployment Guide and Support Package

**Dependencies:**

- Technical audit completed with tier assignments
- Budget allocated for adapters (EUR 240M total)
- Carrier input on common integration bottlenecks

### 29. Interim Programme Director issues an RFP for the business case and financial model of the last-resort public distributor concession, including volume forecasts, cost benchmarks, margin assumptions, operating-cost estimates and subsidy-cap analysis (target EUR 60M over five years, proposed threshold). RFP issued Month 6 (2027-04-12); business case completed by Month 9 (2027-07-12); formal concession tender issued by Month 12 (2027-10-12) (per the pragmatic scenario, a tendered last-resort concession, not a full public booking service).

**Responsible Body/Role:** Programme Director and Head of Distributor and Consumer Affairs

**Suggested Timeframe:** Month 6-12 (April–October 2027)

**Key Outputs/Deliverables:**

- Business Case RFP
- Business Case Report (Month 9 = 2027-07-12): volume forecasts, cost benchmarks, subsidy analysis
- Concession Tender RFP (Month 12 = 2027-10-12)
- Concession Service-Level Terms (availability, response time, complaint handling SLAs)

**Dependencies:**

- Strategic decision on public distributor role finalized (Decision 3)
- Distributor survey data on costs available (Month 4 = 2027-02-12)
- Budget envelope confirmed (EUR 300M, of which EUR 60M operating subsidy over five years)

### 30. PSC holds an interim decision-readiness review at Month 3 (2027-01-12). The review assesses progress on the four preparatory studies: (1) technical audit (interim findings from Month 2 = 2026-12-12); (2) actuarial study (interim findings available); (3) passenger-rights legal review (interim findings available); (4) DG COMP pre-notification status. The OMB and CCPR brief the PSC on any blockers or schedule risks. The PSC confirms that the Month 6 (2027-04-12) binding-vote readiness gate is on track or reschedules if critical inputs are delayed.

**Responsible Body/Role:** PSC Chair and Programme Director

**Suggested Timeframe:** Month 3 (2027-01-12)

**Key Outputs/Deliverables:**

- PSC Interim Review Meeting Agenda
- Interim findings briefing from OMB, CCPR and TSWG
- Readiness Assessment (are Month 6 = 2027-04-12 binding votes achievable?)
- PSC Meeting Minutes with any schedule adjustments

**Dependencies:**

- Interim findings from technical audit, actuarial study, legal reviews available
- DG COMP pre-notification acknowledged

### 31. OMB identifies common carrier integration bottlenecks through TSWG technical working sessions (Months 2–3 = December 2026–January 2027). Based on the technical audit and carrier feedback, the OMB proposes specific shared-adapter development for legacy event-streaming, transaction-consistency and federation-layer issues. Adapter-development recommendations are documented in a Carrier Support Plan issued by Month 3 (2027-01-12).

**Responsible Body/Role:** TSWG Chair and Head of Carrier Engagement

**Suggested Timeframe:** Month 2-3 (December 2026–January 2027)

**Key Outputs/Deliverables:**

- Common Bottleneck Summary (from technical audit and carrier briefings)
- Carrier Support Plan: recommended shared-adapter modules, development timeline, cost estimate
- Adapter scope aligned with EUR 240M budget allocation

**Dependencies:**

- Technical audit completed
- Carrier bilateral briefings conducted
- TSWG technical working sessions convened

### 32. Programme Director drafts the Compliance and Risk Register, tracking the top 10–15 programme risks (as documented in the assumptions and risk-assessment sections of the input). The register includes: risk description, trigger condition, probability, impact, mitigation action, owner, and escalation path. The register is published by Month 3 (2027-01-12) and updated monthly by the OMB and CCPR. Risks reaching trigger conditions are escalated to the PSC within five business days.

**Responsible Body/Role:** Programme Director and Head of Compliance and Risk

**Suggested Timeframe:** Month 2-3 (December 2026–January 2027)

**Key Outputs/Deliverables:**

- Compliance and Risk Register (template and initial population)
- Risk Trigger Definitions and Escalation Procedures
- Monthly Risk Update Report (starting Month 4 = 2027-02-12)

**Dependencies:**

- Risk assessments from input documents reviewed and prioritized
- Ownership and escalation paths assigned
- Programme Office structure in place to track

### 33. CCPR Chair briefs the PSC at Month 4 (2027-02-12) on the status of four legal studies: (1) Article 101 TFEU guidance letter from DG COMP (expected Month 12 = 2027-10-12, track whether on schedule); (2) passenger-rights legal opinion (interim findings Month 3 = 2027-01-12, final Month 6 = 2027-04-12); (3) GDPR and data-governance assessment (interim findings Month 3 = 2027-01-12); (4) accessibility compliance review (interim findings Month 3 = 2027-01-12). Any legal gaps that could block binding-standards approval (Month 18 = 2028-04-12) are escalated to the PSC for remediation planning.

**Responsible Body/Role:** CCPR Chair

**Suggested Timeframe:** Month 4 (2027-02-12)

**Key Outputs/Deliverables:**

- Compliance Status Briefing to PSC
- Legal Studies Progress Report: timeline risks, interim findings, remediation actions
- Escalation flags (if any legal review is delayed or identifies blocking issues)

**Dependencies:**

- CCPR established
- Legal studies contracted and underway
- Interim findings available from studies

### 34. Programme Director conducts the Month 6 (2027-04-12) readiness gate, a formal milestone assessment that determines whether the programme can proceed to binding-standards finalization (target Month 18 = 2028-04-12). The gate requires: (1) liability model signed by at least 8 major carriers and CER; (2) technical audit and tier assignment published; (3) passenger-rights legal opinion approved; (4) DG COMP Article 101 guidance on track for Month 12 (2027-10-12); (5) steering votes on Decisions 1–5 scheduled for Month 6 (2027-04-12) PSC meeting. If gate conditions are not met by Month 6 (2027-04-12), the binding-standards milestone is deferred to Month 12 (2027-10-12) or later, risking cascade delays to Month 30 (2029-04-12) API exposure and Month 48 (2030-10-12) corridor go-live.

**Responsible Body/Role:** Programme Director and OMB

**Suggested Timeframe:** Month 6 (2027-04-12)

**Key Outputs/Deliverables:**

- Month 6 (2027-04-12) Readiness Gate Assessment Report
- Liability Model (final, with carrier signatures confirming cap, co-insurance and contribution thresholds)
- Passenger-Rights Legal Opinion (approved by CCPR and Agency)
- Gate Go/No-Go Decision and escalation (if delayed)

**Dependencies:**

- Actuarial study completed (final, Month 6 = 2027-04-12)
- Carrier sign-offs on liability model (Month 4 = 2027-02-12)
- Legal reviews substantially complete
- DG COMP guidance letter confirmed on track for Month 12 (2027-10-12)

### 35. PSC holds a critical binding-vote meeting at Month 6 (2027-04-12) to approve Decisions 1–5 (Through-Ticket Liability and Rights Backstop, Inter-Carrier Clearing and Single-Payment Settlement, Public Reference Distributor Mandate, Milestone-Conditioned Funding Release Ladder, Availability Query Topology). Voting requires 75% supermajority (at least 7 of 9 core members). The Chair documents all votes and dissents. If a vote falls below 75%, the issue is escalated to the Commission Transport Commissioner with a mediation request by Month 5 (2027-03-12), and mediation is completed by Month 6 (2027-04-12) or a fallback governance path is invoked. Meeting minutes and voting record are published within 15 days (redacting sensitive data).

**Responsible Body/Role:** PSC Chair

**Suggested Timeframe:** Month 6 (2027-04-12)

**Key Outputs/Deliverables:**

- PSC Meeting Agenda and decision dossiers for Decisions 1–5
- Binding Vote Record (per decision, supermajority confirmation, dissent documentation)
- Mediation Brief (if any decision deadlocked, sent to Transport Commissioner by Month 5 = 2027-03-12)
- PSC Meeting Minutes (published within 15 days, redacted as needed)
- Approved Decision Summaries (for public release)

**Dependencies:**

- Month 6 (2027-04-12) readiness gate passed
- All preparatory studies completed and briefed
- PSC Charter voting procedures established and understood by members
- Liability model carrier sign-offs secured

### 36. CCPR Chair commissions a detailed legal review of the approved liability model against EU Regulation 1371/2007 to ensure that through-ticket passengers are not disadvantaged compared to single-carrier passengers. If gaps are found, a remediation plan is prepared by Month 9 (2027-07-12). The CCPR approves a detailed Compliance Manual covering assistance, rerouting, compensation and refund procedures that comply with or exceed Regulation 1371/2007. The manual is formally approved by the EU Agency for Railways by Month 9 (2027-07-12) before any pilot deployment begins (Months 12–18 = 2027-10-12 to 2028-04-12).

**Responsible Body/Role:** CCPR Chair and Head of Compliance and Risk

**Suggested Timeframe:** Month 6-9 (April–July 2027)

**Key Outputs/Deliverables:**

- Legal Review of Liability Model against Regulation 1371/2007
- Passenger-Rights Compliance Manual (procedures for assistance, rerouting, compensation, refunds)
- Agency Approval of Compliance Manual (Month 9 = 2027-07-12)
- Remediation Plan (if gaps identified)

**Dependencies:**

- Decisions 1–5 approved (Month 6 = 2027-04-12)
- Liability model finalized and signed by carriers
- CCPR Chair and compliance expertise in place

### 37. Technical Secretariat Head, in coordination with TSWG, begins drafting the binding OSDM specification covering: (1) API definitions for availability queries, booking, settlement, disruption and ticket validation; (2) real-time data formats for the streamed availability shadow; (3) settlement data-feed standards (reconciliation format, currency, timing); (4) assistance and bicycle-space reservation schemas; (5) ticket-validation credential or token formats. Draft specification is published by Month 9 (2027-07-12) for carrier and distributor review; public consultation period runs Months 9–12 (2027-07-12 to 2027-10-12); final specification approved by TSWG by Month 12 (2027-10-12).

**Responsible Body/Role:** TSWG Chair and Head of Standards and Conformance

**Suggested Timeframe:** Month 6-12 (April–October 2027)

**Key Outputs/Deliverables:**

- OSDM Binding Specification Draft v0.1 (Month 9 = 2027-07-12)
- Public Consultation Summary and feedback incorporation (Months 9–12 = 2027-07-12 to 2027-10-12)
- OSDM Binding Specification Final v1.0 (approved by TSWG, Month 12 = 2027-10-12)

**Dependencies:**

- Strategic decisions on clearing, availability topology and liability model finalized (Decisions 1–5, Month 6 = 2027-04-12)
- Reference OSDM implementation and test cases under development
- Carrier and distributor input gathered via bilateral briefings

### 38. CCPR Chair tracks DG COMP's Article 101 guidance-letter process. DG COMP pre-notification was filed at Month 2 (2026-12-12). Formal guidance letter is expected by Month 12 (2027-10-12). If guidance is not received on schedule, CCPR issues a compliance warning to the PSC by Month 12 (2027-10-12). Regardless, the CCPR establishes a clean-team protocol for the clearing function (physically and logically separating the clearing team from carriers and distributors, releasing only aggregated settlement data) by Month 14 (2027-12-12), to ensure that clearing operations are protected from competition-law challenges even if formal guidance is delayed beyond Month 18 (2028-04-12) binding-standards deadline.

**Responsible Body/Role:** CCPR Chair and Head of Compliance and Risk

**Suggested Timeframe:** Month 6-18 (April 2027–April 2028)

**Key Outputs/Deliverables:**

- DG COMP Engagement Log (pre-notification status, guidance-letter timeline, any clarifications requested)
- DG COMP Compliance Warning (issued to PSC if guidance not on track by Month 12 = 2027-10-12)
- Clean-Team Protocol for Clearing Function (published by Month 14 = 2027-12-12)
- Clearing Function Charter (operational rules, data firewalls, aggregated reporting only)

**Dependencies:**

- DG COMP pre-notification filed at Month 2 (2026-12-12)
- CCPR Chair has direct communication line to DG COMP
- Clearing architecture finalized (Decision 2, Month 6 = 2027-04-12)

### 39. Programme Director issues an RFP for the operational manual for disruption re-accommodation and passenger-assistance procedures covering all participating carriers on the four priority corridors. The manual specifies: (1) missed-connection detection and escalation triggers; (2) reroute-proposal procedures and seat-access protocols; (3) passenger communication and staff training requirements; (4) assistance escalation and onboard/station procedures; (5) compensation processing through the clearing mechanism. Draft manual is ready by Month 9 (2027-07-12); Agency review and approval by Month 9 (2027-07-12); final manual published by Month 12 (2027-10-12) for carrier implementation before pilots begin (Months 12–18 = 2027-10-12 to 2028-04-12).

**Responsible Body/Role:** Head of Carrier Engagement and Compliance Lead

**Suggested Timeframe:** Month 6-12 (April–October 2027)

**Key Outputs/Deliverables:**

- Disruption Re-accommodation Operational Manual (draft Month 9 = 2027-07-12, final Month 12 = 2027-10-12)
- Agency approval and publication
- Carrier implementation checklist and training materials

**Dependencies:**

- Decisions 1–5 approved (liability, clearing, disruption choreography)
- Passenger-rights compliance manual approved
- Carrier input on procedures and constraints gathered

### 40. CCPR Chair assembles the accessibility compliance requirements and conduct usability testing with persons with reduced mobility to assess the programme's assistance and bicycle-reservation design. Testing is contracted to accessibility specialists and conducted with representative users from disability-rights bodies. Initial findings available by Month 12 (2027-10-12); full usability-testing report by Month 18 (2028-04-12). Thresholds for conformance are defined: wheelchair access on at least 80% of services (proposed threshold), assistance within 4 hours' notice on at least 90% of services (proposed threshold).

**Responsible Body/Role:** CCPR Chair and accessibility specialist (contractor)

**Suggested Timeframe:** Month 6-18 (April 2027–April 2028)

**Key Outputs/Deliverables:**

- Accessibility Usability-Testing Plan and RFP (Month 6 = 2027-04-12)
- Accessibility Test Report (Month 18 = 2028-04-12): findings, user feedback, conformance thresholds
- Accessibility Compliance Thresholds (published for conformance gate enforcement)

**Dependencies:**

- Assistance and bicycle-reservation specifications drafted
- Disability-rights bodies engaged as testers
- Budget allocated for testing (part of EUR 100M consumer rollout)

### 41. Programme Director opens test environments and conformance-testing access to Tier 1 carriers by Month 12 (2027-10-12). Test environments include the reference OSDM implementation, shared adapters, SLA monitoring proxy and conformance test cases. Carriers are invited to begin integration testing of their legacy systems and APIs. Support sessions are held biweekly (managed by Head of Carrier Engagement) to address technical questions and integration bottlenecks. Integration-testing progress is tracked monthly by the OMB.

**Responsible Body/Role:** Technical Secretariat Head and Head of Carrier Engagement

**Suggested Timeframe:** Month 12 (2027-10-12)

**Key Outputs/Deliverables:**

- Test Environment Documentation and Carrier Access Credentials
- Reference OSDM Sandbox (public release, open-source)
- Conformance Test Cases (published for self-testing by carriers)
- Biweekly Integration-Support Sessions (held Months 12–24 = 2027-10-12 to 2028-10-12)

**Dependencies:**

- OSDM binding specification finalized (Month 12 = 2027-10-12)
- Reference implementation and test cases available
- Shared adapters procured
- Tier 1 carriers notified and ready for testing

### 42. Programme Director commences formal concession-tender evaluation (issued Month 12 = 2027-10-12, per earlier steps). A two-stage process is followed: (1) technical-requirements evaluation (service offerings, volume handling, SLA capability, complaint-handling procedures); (2) financial-viability assessment (cost benchmarks, margin assumptions, subsidy forecast, clawback conditions). Tender evaluation completes by Month 18 (2028-04-12); concessionaire award announced by Month 18 (2028-04-12); contract signed by Month 24 (2028-10-12); service deployment target Month 30 (2029-04-12) (concurrent with Tier 1 API exposure).

**Responsible Body/Role:** Head of Distributor and Consumer Affairs and Procurement Officer

**Suggested Timeframe:** Month 12-24 (October 2027–October 2028)

**Key Outputs/Deliverables:**

- Concession Tender Evaluation Report (Month 18 = 2028-04-12)
- Concessionaire Selection and Award Notification (Month 18 = 2028-04-12)
- Concession Contract (signed Month 24 = 2028-10-12)
- Concession Service-Deployment Plan and timeline

**Dependencies:**

- Business case completed (Month 9 = 2027-07-12)
- Tender issued (Month 12 = 2027-10-12)
- Budget envelope confirmed (EUR 300M, EUR 60M subsidy cap)

### 43. DG COMP delivers the formal Article 101 TFEU guidance letter by Month 12 (2027-10-12) (expected timeline). If guidance is received, CCPR Chair reviews it against the approved clearing architecture and data-sharing design (Decisions 1–2). If guidance confirms compatibility, the CCPR issues a Compliance Certificate by Month 14 (2027-12-12) and reports to the PSC. If guidance raises concerns, remediation actions are taken (clean-team protocol, adjusted data firewalls) by Month 14 (2027-12-12) to protect binding-standards approval (Month 18 = 2028-04-12).

**Responsible Body/Role:** CCPR Chair and DG COMP

**Suggested Timeframe:** Month 12-14 (October–December 2027)

**Key Outputs/Deliverables:**

- DG COMP Article 101 Guidance Letter (Month 12 = 2027-10-12)
- CCPR Compliance Review and Certificate (Month 14 = 2027-12-12)
- Remediation Actions (if required) and revised clearing protocol (by Month 14 = 2027-12-12)

**Dependencies:**

- DG COMP pre-notification filed at Month 2 (2026-12-12)
- CCPR and DG COMP maintained regular communication
- Clearing architecture finalized (Decision 2, Month 6 = 2027-04-12)

### 44. TSWG Chair finalizes conformance test cases, SLA thresholds and certification procedures by Month 12 (2027-10-12). Thresholds are published: p95 latency <2 seconds (proposed threshold), 99.5% availability (proposed threshold), stale-seat failures <1% (proposed threshold), booking-error rates within acceptable bounds. Carriers can self-test in environments from Month 12 (2027-10-12) onwards. Independent conformance audits begin Month 24 (2028-10-12) for Tier 1 carriers (deadline Month 30 = 2029-04-12). Audit schedule for Tier 2 (deadline Month 36 = 2029-10-12) and Tier 3 (deadline Month 42 = 2030-04-12) is published.

**Responsible Body/Role:** TSWG Chair and Head of Standards and Conformance

**Suggested Timeframe:** Month 12 (2027-10-12)

**Key Outputs/Deliverables:**

- Final Conformance Test Cases and SLA Thresholds (published)
- Conformance Audit Schedule: Tier 1 (Months 24–30 = 2028-10-12 to 2029-04-12), Tier 2 (Months 30–36 = 2029-04-12 to 2029-10-12), Tier 3 (Months 36–42 = 2029-10-12 to 2030-04-12)
- Independent Test Laboratory contracted and ready (by Month 18 = 2028-04-12)

**Dependencies:**

- OSDM binding specification finalized (Month 12 = 2027-10-12)
- Test cases reviewed by TSWG and carrier representatives
- SLA thresholds agreed with carriers (informed by bilateral briefings)

### 45. Technical Secretariat Head arranges live pilot deployments on each of the four priority corridors (Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin) with 500–1,000 passengers per corridor (2,000–4,000 total). Pilots are conducted Months 12–18 (2027-10-12 to 2028-04-12) to test end-to-end through-ticket booking, disruption re-accommodation, validation acceptance and passenger satisfaction. Pilot findings are documented in a Live-Pilot Report delivered by Month 18 (2028-04-12) to inform any adjustments before binding-standards finalization.

**Responsible Body/Role:** Head of Carrier Engagement and liaison officers (four corridor hubs)

**Suggested Timeframe:** Month 12-18 (October 2027–April 2028)

**Key Outputs/Deliverables:**

- Pilot Deployment Plan (per-corridor timelines, carrier participation, passenger recruitment, metrics)
- Pilot Operations (500–1,000 passengers per corridor)
- Live-Pilot Report (Month 18 = 2028-04-12): booking completion rates, disruption re-accommodation response times, validation acceptance, passenger satisfaction, accessibility issues

**Dependencies:**

- Operationaldisruption manual approved (Month 12 = 2027-10-12)
- Tier 1 carriers ready to participate
- Passenger-rights legal compliance confirmed
- Test environments and shared adapters available

### 46. Technical Secretariat Head finalizes the binding OSDM specification (version 1.0) by Month 18 (2028-04-12) for formal adoption. The specification is submitted to the Commission for anchoring in a delegated or implementing act. The specification custodianship (EU Agency for Railways) is confirmed; an escrowed open-source copy is archived; version history and change-control governance are documented. The specification is formally pinned by delegated or implementing act by the end of Month 18 (2028-04-12).

**Responsible Body/Role:** TSWG Chair, Technical Secretariat Head and EU Agency for Railways

**Suggested Timeframe:** Month 18 (2028-04-12)

**Key Outputs/Deliverables:**

- OSDM Binding Specification v1.0 (final, approved by TSWG and PSC)
- Delegated or Implementing Act anchoring OSDM version (Commission adoption)
- Escrowed Open-Source Archive (with Agency custodianship documentation)
- Specification Governance Charter (change control, quarterly release cadence, version history)

**Dependencies:**

- Binding-standards milestone (Month 18 = 2028-04-12) confirmed
- Carrier and distributor feedback from pilots and testing incorporated
- Commission adoption of Regulation (assumed Month 18 = 2028-04-12, per scenario)

### 47. PSC Chair holds a post-binding-standards review meeting at Month 18 (2028-04-12) to confirm: (1) binding OSDM specification adopted (pinned by delegated act); (2) DG COMP Article 101 guidance obtained and clean-team protocol in place; (3) passenger-rights legal compliance manual approved; (4) pilots completed and key findings documented; (5) Tier 1 carrier conformance audits scheduled (Month 24 = 2028-10-12 start); (6) Phase 2 (API exposure and conformance, Months 18–48 = 2028-04-12 to 2030-10-12) kicked off. Any blockers are escalated; if none, the PSC confirms the programme proceeds to mandatory API exposure target (Month 30 = 2029-04-12).

**Responsible Body/Role:** PSC Chair

**Suggested Timeframe:** Month 18 (2028-04-12)

**Key Outputs/Deliverables:**

- PSC Post-Binding-Standards Review Meeting
- Binding-Standards Milestone Confirmation Report
- Phase 2 Launch Memo (API exposure, conformance, corridor go-live timelines)
- PSC Meeting Minutes and any escalations

**Dependencies:**

- OSDM binding specification finalized and adopted
- DG COMP Article 101 guidance received or mitigated
- Live pilots completed (Month 18 = 2028-04-12)
- Tier 1 carrier readiness confirmed for conformance audits

### 48. OMB establishes SLA monitoring by deploying the SLA monitoring proxy (part of the real-time layer). The proxy tracks monthly metrics for all carriers: latency (p95 <2 seconds proposed threshold), availability (99.5% proposed threshold), stale-seat failures (<1% proposed threshold). Monthly SLA scorecards are published by the OMB by Month 24 (2028-10-12), with results available to the PSC, carriers and distributors. Carriers missing SLAs for two consecutive months face recommended funding-tranche withholding (5% of next tranche).

**Responsible Body/Role:** OMB and Technical Secretariat Head

**Suggested Timeframe:** Month 18-24 (April–October 2028)

**Key Outputs/Deliverables:**

- SLA Monitoring Proxy deployment (Month 18 = 2028-04-12)
- SLA Scoring Methodology and escalation rules (published)
- First SLA Scorecards (by Month 24 = 2028-10-12, for all carriers with active data feeds)

**Dependencies:**

- SLA monitoring proxy infrastructure ready (deployed by Month 6 = 2027-04-12)
- Carrier data feeds established (from test environments)
- SLA thresholds published (Month 12 = 2027-10-12)

### 49. Tier 1 Carriers (large, corridor-critical) undergo formal independent conformance audits by an contracted test laboratory. Audits begin Month 24 (2028-10-12) and must complete by Month 30 (2029-04-12) (mandatory API exposure deadline). Carriers are expected to: (1) expose OSDM-compatible APIs with p95 latency <2 seconds, 99.5% availability; (2) demonstrate stale-seat failure rates <1%; (3) provide settlement data feeds matching the standard format; (4) pass ticket-validation credential interoperability testing. Audit results are published monthly on the public Conformance-Certification Registry.

**Responsible Body/Role:** Head of Standards and Conformance and independent test laboratory

**Suggested Timeframe:** Month 24-30 (October 2028–April 2029)

**Key Outputs/Deliverables:**

- Conformance Audit Reports (per Tier 1 carrier, monthly from Month 24 = 2028-10-12)
- Public Conformance-Certification Registry (updated monthly)
- Remediation tracking for carriers missing criteria
- Tier 1 Conformance Certification Awards (by Month 30 = 2029-04-12)

**Dependencies:**

- Test laboratory contracted and ready (by Month 18 = 2028-04-12)
- Test cases, SLA thresholds and audit procedures finalized (Month 12 = 2027-10-12)
- Carrier integration testing in environments completed (Months 12–24 = 2027-10-12 to 2028-10-12)
- Shared adapters deployed to carriers (Month 12 = 2027-10-12)

### 50. Head of Carrier Engagement monitors Tier 1 carrier conformance progress monthly during Months 24–30 (2028-10-12 to 2029-04-12). Any carrier with SLA misses (latency, availability) or stale-seat failures is offered remediation support: additional adapter funding, extended integration timelines or deferral to Tier 2 (Month 36 = 2029-10-12). By Month 30 (2029-04-12), all Tier 1 carriers are either certified or formally deferred to Tier 2 with a revised compliance timeline.

**Responsible Body/Role:** Head of Carrier Engagement and OMB

**Suggested Timeframe:** Month 24-30 (October 2028–April 2029)

**Key Outputs/Deliverables:**

- Monthly Carrier Remediation Status Report (Months 24–30 = 2028-10-12 to 2029-04-12)
- Tier 1 Final Certification List (Month 30 = 2029-04-12)
- Tier 1 Deferrals to Tier 2 (documented with revised timelines)

**Dependencies:**

- Tier 1 conformance audits underway
- Shared adapters available for rapid deployment
- SLA scorecards informing remediation decisions

### 51. Concessionaire (selected via tender Month 18 = 2028-04-12, contract signed Month 24 = 2028-10-12) commences service deployment by Month 30 (2029-04-12), coinciding with Tier 1 API exposure. The concessionaire establishes IT platform, booking interface, multilingual support, complaint handling and integration with participating carriers' APIs. Service is launched on the four priority corridors first, expanding to additional corridors by Month 48 (2030-10-12). Monthly financial reports track volume, operating costs and subsidy draw (capped at EUR 60M over five years).

**Responsible Body/Role:** Concessionaire and Head of Distributor and Consumer Affairs

**Suggested Timeframe:** Month 24-30 (October 2028–April 2029)

**Key Outputs/Deliverables:**

- Concessionaire Service-Deployment Plan (platform, API integration, languages, support)
- Service Launch (Month 30 = 2029-04-12 on priority corridors)
- Monthly Financial Reports (volume, operating cost, subsidy tracking)

**Dependencies:**

- Concession contract signed (Month 24 = 2028-10-12)
- Tier 1 carriers certified and APIs live (Month 30 = 2029-04-12)
- Distribution remuneration band set (Decision 12, Month 9 = 2027-07-12)

### 52. OMB declares the mandatory API exposure milestone (Month 30 = 2029-04-12) achieved when all Tier 1 carriers are certified and live, the concessionaire is operational, and the first through-tickets are being sold. The milestone is formally confirmed by the PSC; progress toward the four-corridor go-live (Month 48 = 2030-10-12) is confirmed on schedule. Phase 2 continues with Tier 2 audits (Months 30–36 = 2029-04-12 to 2029-10-12) and Tier 3 preparation (targeting Month 42 = 2030-04-12).

**Responsible Body/Role:** OMB Chair (Programme Director) and PSC Chair

**Suggested Timeframe:** Month 30 (2029-04-12)

**Key Outputs/Deliverables:**

- API Exposure Milestone Confirmation Report
- Tier 1 Certification Summary (certified carriers, API endpoints live)
- First Through-Tickets Sold Report (volume, routes, passenger feedback)
- Phase 2 Progress and Tier 2/3 Readiness Assessment

**Dependencies:**

- All Tier 1 carriers certified (Month 30 = 2029-04-12)
- Concessionaire service live (Month 30 = 2029-04-12)
- SLA monitoring and compliance tracking functional

### 53. Tier 2 Carriers (regional and mid-size) undergo conformance audits Months 30–36 (2029-04-12 to 2029-10-12). Tier 2 carriers receive shared adapters, extended support and potentially additional funding for legacy-system retrofits. Conformance audit results are published monthly; remediation and deferrals follow the same process as Tier 1. By Month 36 (2029-10-12), all Tier 2 carriers are either certified or deferred to Tier 3 (Month 42 = 2030-04-12).

**Responsible Body/Role:** Head of Standards and Conformance and independent test laboratory

**Suggested Timeframe:** Month 30-36 (April–October 2029)

**Key Outputs/Deliverables:**

- Tier 2 Conformance Audit Reports (monthly)
- Tier 2 Final Certification List (Month 36 = 2029-10-12)
- Tier 2 Deferrals to Tier 3 (with revised timelines)

**Dependencies:**

- Tier 1 completed and live
- Shared adapters (Tier 2 versions) deployed
- Tier 2 carriers registered for audits

### 54. Tier 3 Carriers (small and legacy-heavy) undergo conformance audits Months 36–42 (2029-10-12 to 2030-04-12). Tier 3 carriers receive maximum support: shared adapters for legacy event-streaming and transaction-consistency, dedicated integration support, and potentially 80–90% funding for adapter modules. Conformance audit results are published monthly; any carriers unable to achieve compliance by Month 42 (2030-04-12) are considered for deferral to the TEN-T extension wave (Months 48–60 = 2030-10-12 to 2031-10-12) or full exclusion if technical viability is questioned.

**Responsible Body/Role:** Head of Standards and Conformance and Head of Carrier Engagement

**Suggested Timeframe:** Month 36-42 (October 2029–April 2030)

**Key Outputs/Deliverables:**

- Tier 3 Conformance Audit Reports (monthly)
- Tier 3 Final Certification List (Month 42 = 2030-04-12)
- Carrier Exclusion or Deferral Decisions (with justification)
- TEN-T extension planning based on Tier 3 outcomes

**Dependencies:**

- Tier 2 completed (Month 36 = 2029-10-12)
- Shared adapters (Tier 3 versions) deployed
- Tier 3 carriers integrated with test environments

### 55. OMB prepares a formal Corridor Go-Live Readiness Assessment by Month 42 (2030-04-12) for each of the four priority corridors (Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin). Assessment criteria: (1) all participating carriers on the corridor are certified (Tiers 1–3); (2) real-time data flows (availability shadow, disruption event feed, settlement data) are live and validated for at least one month; (3) ticket-validation credentials are deployed to at least 80% of corridor rolling stock and key stations; (4) operational procedures (disruption re-accommodation, assistance, complaint handling) are staffed and tested; (5) concessionaire is selling tickets on the corridor. Go-live decision is made by the PSC by Month 45 (2030-07-12); corridors are brought live by Month 48 (2030-10-12).

**Responsible Body/Role:** OMB and corridor liaison officers

**Suggested Timeframe:** Month 42-48 (April–October 2030)

**Key Outputs/Deliverables:**

- Corridor Go-Live Readiness Assessment (per corridor, Month 42 = 2030-04-12)
- PSC Go-Live Decision (Month 45 = 2030-07-12)
- Corridor Launch Plan (traffic management, passenger comms, issue escalation)
- Four-Corridor Through-Ticketing Milestone Confirmation (Month 48 = 2030-10-12)

**Dependencies:**

- Tier 3 conformance completed or deferred (Month 42 = 2030-04-12)
- Ticket-validation deployment nearing completion (target Month 40 = 2030-02-12)
- Operational procedures tested in pilots (Months 12–18 = 2027-10-12 to 2028-04-12)

### 56. Technical Secretariat Head audits ticket-validation capability on corridor rolling stock and key stations. Validation deployment began during integration testing; audit checklist requires: (1) API handshake or cryptographic-token verification working on conductor handhelds and station gates; (2) offline validation capability for environments with poor connectivity; (3) cross-carrier credential acceptance (all carriers recognize each other's tickets); (4) accessibility compliance (ticket presentation, audio guidance, tactile feedback). Audits are conducted at Months 30 (2029-04-12), 35 (2029-09-12) and 40 (2030-02-12); results inform remediation priorities. Target: 80%+ of corridor vehicles and key stations compliant by Month 40 (2030-02-12) (10 months before go-live at Month 48 = 2030-10-12).

**Responsible Body/Role:** Technical Secretariat Head and corridor liaison officers

**Suggested Timeframe:** Month 30-40 (April 2029–February 2030)

**Key Outputs/Deliverables:**

- Validation Deployment Audit Checklist (published)
- Audit Reports (Months 30, 35, 40 = 2029-04-12, 2029-09-12, 2030-02-12)
- Validation Compliance Scorecard (% vehicles/stations compliant by corridor)
- Remediation Plan for non-compliant sites

**Dependencies:**

- Ticket-validation credential format finalized in OSDM spec (Month 18 = 2028-04-12)
- Carrier IT integration of validation capability completed
- Hardware (handhelds, gates) upgrades funded and scheduled

### 57. Concession head and Head of Distributor and Consumer Affairs track concessionaire service metrics monthly: through-ticket volume (targeting ramp-up toward 40% of cross-border journeys), passenger satisfaction, complaint resolution time, operating costs versus budget. If volume is <60% of forecast, a contract-review clause is triggered, which may require service-level adjustments or subsidy review. Clawback conditions apply if volume exceeds forecast by >20%: surplus fees are rebated to the Commission. Monthly reports are submitted to the OMB and PSC; annual reports to the European Court of Auditors.

**Responsible Body/Role:** Head of Distributor and Consumer Affairs and Financial Planning Lead

**Suggested Timeframe:** Month 30-60 (April 2029–October 2031) ongoing

**Key Outputs/Deliverables:**

- Monthly Concession Performance Report (volume, satisfaction, complaint resolution, cost vs. budget)
- Clawback or subsidy-review triggers (documented and escalated to PSC if triggered)
- Annual Audit Report to Court of Auditors

**Dependencies:**

- Concessionaire service live (Month 30 = 2029-04-12)
- Carrier API availability and booking volumes trending upward

### 58. OMB and Head of Compliance and Risk track cumulative programme spend quarterly against the EUR 1,500M budget. Variance triggers at EUR 100M (defer TEN-T extension to Months 60–72 = 2031-10-12 to 2032-10-12), EUR 200M (cut concession funding 20%, extend concession term 5–7 years), and EUR 300M (restrict to four priority corridors only). If any variance trigger is reached, the OMB recommends mitigation actions to the PSC within 10 business days. The PSC approves policy adjustments (e.g., scaling back TEN-T, extending concession term, deferring non-critical components). Quarterly variance reports are published to the Commission and the Court of Auditors.

**Responsible Body/Role:** OMB and Financial Planning Lead

**Suggested Timeframe:** Month 3-60 (January 2027–October 2031) quarterly

**Key Outputs/Deliverables:**

- Quarterly Variance Tracking Report (cumulative spend by line, variance triggers, mitigation status)
- Variance Trigger Escalation (if threshold reached, within 10 business days to OMB and PSC)
- PSC Policy Adjustment Decision (if mitigation required)

**Dependencies:**

- Financial reporting system operational (Month 3 = 2027-01-12)
- Budget baseline and spending authority established

### 59. OMB and Head of Compliance and Risk conduct a mid-programme evaluation at Month 36 (2029-10-12) assessing: (1) progress toward binding-standards (achieved Month 18 = 2028-04-12); (2) API exposure readiness for Tier 2 carriers (on schedule Month 36 = 2029-10-12); (3) through-ticket volume ramp-up (targeting 15–20% by Month 36 = 2029-10-12 as a planning range estimate toward 40% by Month 60 = 2031-10-12); (4) distributor complaints trending down; (5) budget variance and concession performance; (6) risk-mitigation effectiveness. Evaluation findings are briefed to the PSC; course corrections (e.g., accelerating Tier 3, adjusting commission band) are recommended and decided by Month 36 (2029-10-12).

**Responsible Body/Role:** Programme Director and independent evaluation firm (contracted)

**Suggested Timeframe:** Month 36 (2029-10-12)

**Key Outputs/Deliverables:**

- Mid-Programme Evaluation Report (progress toward goals, risk status, course-correction recommendations)
- PSC Briefing and Decision (Month 36 = 2029-10-12 or Month 39 = 2030-01-12)

**Dependencies:**

- Binding-standards achieved (Month 18 = 2028-04-12)
- Tier 2 conformance underway (Months 30–36 = 2029-04-12 to 2029-10-12)
- Initial through-ticket data available from Tier 1 (Months 30–36 = 2029-04-12 to 2029-10-12)

### 60. Technical Secretariat Head and TSWG Chair establish a post-Month-18 (2028-04-12) specification-evolution governance process. Change requests for the OSDM specification are managed using the published change-control process (critical: 2 weeks, major: 6 weeks, minor: 8 weeks). Quarterly releases are published (following the release schedule established at Month 3 = 2027-01-12). A change-request dashboard is maintained showing pending and approved requests. Any change requests affecting binding-standards commitments or requiring carrier rework are escalated to the OMB for impact assessment before approval.

**Responsible Body/Role:** TSWG Chair and Technical Secretariat Head

**Suggested Timeframe:** Month 18-60 (April 2028–October 2031) ongoing

**Key Outputs/Deliverables:**

- Change-Request Dashboard (published monthly, updated)
- Quarterly OSDM Release Notes (describing approved changes and version number)
- Escalation Decisions (change requests flagged for OMB review)

**Dependencies:**

- Change-control process published (Month 3 = 2027-01-12)
- OSDM specification pinned by delegated act (Month 18 = 2028-04-12)

### 61. OMB and Head of Compliance and Risk establish a post-go-live passenger-rights and accessibility monitoring programme. Starting Month 48 (2030-10-12) (when first corridors go live), the programme tracks: (1) passenger complaints related to liability, refunds and compensation; (2) assistance and bicycle-reservation request fulfillment rates; (3) ticket-validation errors and disputes on corridor trains; (4) through-ticket passenger satisfaction and Net Promoter Score. Monthly reports are compiled and escalated to the CCPR; annual compliance audits are conducted by the EU Agency for Railways. Any systematic rights violations are escalated to national regulators and the Commission for enforcement action.

**Responsible Body/Role:** OMB, CCPR Chair and corridor liaison officers

**Suggested Timeframe:** Month 48-60 (October 2030–October 2031) ongoing

**Key Outputs/Deliverables:**

- Passenger-Rights Monitoring Dashboard (complaints, resolution time, escalations)
- Monthly Compliance Report (CCPR briefing)
- Annual Accessibility Audit (EU Agency for Railways)

**Dependencies:**

- Corridors live (Month 48 = 2030-10-12)
- Compliance manual operational (Month 12 = 2027-10-12)
- Concessionaire complaint handling live (Month 30 = 2029-04-12)

### 62. OMB and Head of Carrier Engagement launch planning for the TEN-T network extension (Months 48–60 = 2030-10-12 to 2031-10-12). The extension adds operators and corridors beyond the four initial priority corridors, targeting full TEN-T coverage by Month 60 (2031-10-12). Funding for TEN-T extension (estimated EUR 200–400M, to be allocated from the budget headroom EUR 85M + reserve EUR 150M, with variance-trigger conditions) is released on a phased basis as Tier 1/2/3 adoption succeeds and budget headroom is confirmed. Planning documents include: (1) corridor prioritization (air-competitive routes, high-volume cross-border links); (2) carrier inclusion criteria (conformance readiness, API maturity); (3) funding tranches and release conditions; (4) timeline (Months 48–60 = 2030-10-12 to 2031-10-12 target, Month 72 = 2032-10-12 fallback accepted).

**Responsible Body/Role:** Programme Director and OMB

**Suggested Timeframe:** Month 36-48 (October 2029–October 2030)

**Key Outputs/Deliverables:**

- TEN-T Extension Plan (corridor prioritization, carrier inclusion, funding tranches, timeline)
- PSC approval of TEN-T scope and sequencing (Month 42 = 2030-04-12 or Month 45 = 2030-07-12)
- TEN-T Funding Release Framework (conditions, tranches, monitoring)

**Dependencies:**

- Four-corridor go-live completed (Month 48 = 2030-10-12)
- Budget headroom and reserve status known (quarterly variance reports)
- Tier 2/3 outcomes inform network expansion viability

### 63. OMB and Head of Distributor and Consumer Affairs establish a competitive call or direct-engagement process for additional carriers and corridors in the TEN-T extension wave (Months 48–60 = 2030-10-12 to 2031-10-12). Using milestone-conditioned funding (the pragmatic scenario), TEN-T funding is released in tranches tied to verified API exposure, conformance certification and through-ticket volume milestones. New corridor onboarding follows the Tier-assignment process: rapid-track for carriers already conformant (Tier 1/2 ready by Months 48–54 = 2030-10-12 to 2031-04-12), standard-track for new entrants (Months 54–60 = 2031-04-12 to 2031-10-12). By Month 60 (2031-10-12), the target is full TEN-T coverage and 40% of cross-border journeys sold as through-tickets.

**Responsible Body/Role:** Programme Director and Head of Distributor and Consumer Affairs

**Suggested Timeframe:** Month 48-60 (October 2030–October 2031)

**Key Outputs/Deliverables:**

- TEN-T Extension Call or Direct-Engagement RFP
- New Carrier Onboarding (conformance audits, rapid-track vs. standard-track assignment)
- Corridor Launch Schedule (TEN-T corridors brought live by Month 60 = 2031-10-12)
- Final Through-Ticket Market Penetration Report (Month 60 = 2031-10-12): share of cross-border journeys sold as through-tickets, progress toward 40% target

**Dependencies:**

- Four-corridor go-live successful (Month 48 = 2030-10-12)
- TEN-T extension plan approved (Month 42-48 = 2030-04-12 to 2030-10-12)
- Funding tranches released (approved by PSC quarterly variance tracking)

### 64. OMB commissions a final post-programme evaluation at Month 60 (2031-10-12) assessing: (1) achievement of the 40% through-ticket goal (or identified shortfall); (2) distributor complaints halved (baseline from Month 1 = 2026-11-12); (3) modal shift from short-haul air to rail (conservative 5–10% planning value estimate, not a success metric but reported); (4) accessibility compliance for assistance and bicycle reservations; (5) financial performance (total spend vs. EUR 1,500M budget, concession subsidy draw, clawback conditions); (6) regulatory and competition-law compliance; (7) passenger and carrier satisfaction. Findings are documented in the Final Evaluation Report; recommendations for programme sustaining (beyond Month 60 = 2031-10-12) are developed. The report is submitted to the Commission, the Court of Auditors and the European Parliament.

**Responsible Body/Role:** Programme Director and independent evaluation firm

**Suggested Timeframe:** Month 60 (2031-10-12)

**Key Outputs/Deliverables:**

- Final Evaluation Report (Month 60 = 2031-10-12): goal achievement, lessons learned, recommendations for sustaining
- Submission to Commission, Court of Auditors and European Parliament

**Dependencies:**

- TEN-T extension completed or decisioned (Month 60 = 2031-10-12)
- Four-corridor and priority TEN-T corridors live for minimum 6–12 months (data available)
- Financial and operational data collected throughout Months 0–60 (2026-10-12 to 2031-10-12)

### 65. PSC Chair convenes a final PSC meeting at Month 60 (2031-10-12) to formally close the programme governance (Phase 1, 2, 3: Months 0–60 = 2026-10-12 to 2031-10-12) or transition to a sustaining governance phase (if the programme continues managing network expansion or ongoing compliance beyond Month 60 = 2031-10-12). The PSC reviews final evaluation findings, confirms the through-ticket goal status, and decides on: (1) dissolution of the Programme Office and Technical Secretariat (or transition to a smaller sustained-governance body under the EU Agency for Railways); (2) handover of OSDM custodianship and change control to the Agency (if not already formalized); (3) ongoing funding for network sustaining, passenger-rights monitoring and accessibility compliance; (4) any residual budget (if unspent headroom remains, disposition is decided). The closing decision is documented in a PSC Final Report, published to the Commission and member states.

**Responsible Body/Role:** PSC Chair and Programme Director

**Suggested Timeframe:** Month 60 (2031-10-12)

**Key Outputs/Deliverables:**

- PSC Final Meeting Agenda and briefing materials
- PSC Final Report (programme closure or transition, recommendations, final votes)
- PSC Meeting Minutes
- Notification to all stakeholders of programme governance transition

**Dependencies:**

- Final evaluation completed (Month 60 = 2031-10-12)
- Four-corridor through-ticketing confirmed as sustainable (at least 6 months operating experience)
- Financial closure and audit complete