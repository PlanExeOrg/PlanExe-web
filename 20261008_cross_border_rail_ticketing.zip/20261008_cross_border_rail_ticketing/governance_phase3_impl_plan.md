### 1. Project Sponsor (DG MOVE) formally initiates the programme and establishes initial programme authority. Publish the project charter, confirm programme start date (Month 0 = 2026-10-08), approve the governance structure, and designate the Programme Director role with interim decision authority during set-up.

**Responsible Body/Role:** Project Sponsor (DG MOVE)

**Suggested Timeframe:** Within 1 week of project start (Month 0.1 = 2026-10-11)

**Key Outputs/Deliverables:**

- Signed Project Charter
- Programme Director Role Specification and Interim Authority Memorandum
- Initial Communication to All Stakeholders (Regulation text, timeline, governance overview)

**Dependencies:**

- Project start decision
- Identified Project Sponsor and initial programme leadership

### 2. Programme Director (once designated) establishes the core Programme Management Office (PMO) and convenes a governance-setup task force. Define PMO staffing plan, office location (Brussels), project-management tools and reporting cadence. Initiate recruitment of 10–15 core PMO staff (director, deputy, standards lead, technical architect, budget officer, communications lead, risk officer).

**Responsible Body/Role:** Programme Director

**Suggested Timeframe:** Within 2 weeks of project start (Months 0–1 = 2026-10-08 to 2026-11-08)

**Key Outputs/Deliverables:**

- PMO Organization Chart and Staffing Plan
- Office/Meeting Facilities Lease Agreement (Brussels)
- Project Management Tool Setup (Asana, Monday.com, or equivalent)
- PMO Recruitment Initiation (job descriptions, outreach)

**Dependencies:**

- Project Sponsor authorization
- Budget authorization for PMO operations

### 3. Programme Director drafts the Memorandum of Understanding (MOU) governing the Programme Steering Committee (SteerCo): authority, decision rights, decision-making rules, escalation procedures, meeting cadence. Define quorum, tie-breaking provisions and record-keeping protocols.

**Responsible Body/Role:** Programme Director (with input from Legal Counsel and DG MOVE)

**Suggested Timeframe:** Within 3 weeks of project start (Months 0–1 = 2026-10-08 to 2026-11-08)

**Key Outputs/Deliverables:**

- Draft Steering Committee MOU (authority, scope, decision rules)
- Proposed Steering Committee Membership List
- Nominated Steering Committee Chair (to be approved by DG MOVE)

**Dependencies:**

- Project Charter approved
- PMO established
- Understanding of stakeholder landscape (carriers, regulators, distributors)

### 4. Senior Management (DG MOVE) formally appoints the Steering Committee Chair and confirms initial membership. Chair must be a senior DG MOVE or Commission representative; deputy chair a representative from a smaller/weaker-capacity member state or regulator. Secure written commitment from all nominated members (Months 1–2 = 2026-11-08 to 2026-12-08).

**Responsible Body/Role:** Project Sponsor (DG MOVE) / Senior Management

**Suggested Timeframe:** By end of Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Steering Committee Chair Appointment Letter (signed)
- Steering Committee Deputy Chair Appointment Letter (signed)
- Signed Membership Confirmation from All Committee Members
- Finalized Steering Committee MOU (all parties endorsed)

**Dependencies:**

- Draft MOU prepared
- Proposed membership identified and vetted for conflicts of interest
- DG MOVE approval of chair and governance structure

### 5. Steering Committee Chair (newly appointed) schedules the first kick-off meeting. Distribute agenda (programme overview, governance roadmap, critical path overview, month 0–3 = 2026-10-08 to 2027-01-08 priorities). Hold the first formal Steering Committee meeting to confirm governance, approve the PMO operating procedures and authorize the next wave of working-group setup.

**Responsible Body/Role:** Programme Steering Committee (led by Chair)

**Suggested Timeframe:** Within 2 weeks of chair appointment (Month 1.5 = 2026-11-23)

**Key Outputs/Deliverables:**

- Steering Committee Kick-off Meeting Minutes
- Approved PMO Operating Procedures and Meeting Schedule
- Approved Working-Group Charter (standards, carrier engagement, consumer product, etc.)
- Decision Log (decisions, action owners, deadlines)

**Dependencies:**

- Steering Committee formally appointed
- MOU finalized and endorsed
- PMO draft operating procedures ready for SC review

### 6. Programme Director, in consultation with DG MOVE and the EU Agency for Railways, establishes the Technical Standards and Conformance Working Group. Identify and recruit lead standards engineer/chair, recruit 2–3 OSDM experts, carrier IT representatives, distributor technical leads, payment-systems specialist, and accessibility expert. Define sub-groups: OSDM/API, data-layer, clearing/settlement, ticket format, passenger rights/accessibility, GDPR/compliance.

**Responsible Body/Role:** Programme Director (PMO Standards Lead, with input from EU Agency for Railways)

**Suggested Timeframe:** Months 1–2 (2026-11-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Technical Working Group Charter (scope, sub-groups, decision rules)
- Working-Group Membership List (confirmed representatives)
- Sub-group Assignments and Lead Identification
- First Monthly Meeting Schedule (starting Month 2 = 2026-12-08)

**Dependencies:**

- PMO staffing underway (Standards Lead identified)
- Steering Committee endorsement of working-group charter
- Stakeholder stakeholder outreach to identify representatives

### 7. Standards Working Group, in collaboration with legal counsel and the EU Agency for Railways, conducts a gap analysis comparing the Commission's proposed Regulation (May 2026) to OSDM standards and legacy-carrier IT capabilities. Identify areas where standards development can proceed immediately ('shadow work') versus areas dependent on final Regulation text. Publish findings by Month 3 (2027-01-08).

**Responsible Body/Role:** Technical Standards and Conformance Working Group (with PMO support)

**Suggested Timeframe:** Months 1–3 (2026-11-08 to 2027-01-08)

**Key Outputs/Deliverables:**

- Gap Analysis Report (Regulation vs. OSDM, standards gaps, legacy-IT impact)
- Pre-Work Scope Definition (standards work that can proceed before adoption)
- Regulatory Tracking Dashboard (timeline to adoption, potential amendments)

**Dependencies:**

- Working Group formally established and meeting
- Access to Regulation proposal text and parliamentary tracking
- Input from carriers on IT capabilities and timelines

### 8. Programme Director, in collaboration with the Commission (DG MOVE, DG COMP) and the EU Agency for Railways, drafts a Written Delegation of Authority to the independent arbitration panel. Specify: binding decision scope (technical standards only), time limits (60-day ruling cycle, 14-day compliance deadline), panel authority, escalation procedures to the Commission if non-compliance occurs. Secure written agreement from the Commission and Council by Month 2 (2026-12-08).

**Responsible Body/Role:** Programme Director (with Legal Counsel and DG MOVE)

**Suggested Timeframe:** Months 0–2 (2026-10-08 to 2026-12-08) (target Month 1.5 = 2026-11-23)

**Key Outputs/Deliverables:**

- Draft Written Delegation of Authority (scope, decision rights, time limits, escalation)
- Commission and Council Signed Endorsement
- Arbitration Panel Operating Procedures (conflict of interest, confidentiality, ruling publication)

**Dependencies:**

- Project Sponsor authorization to negotiate with Commission/Council
- Legal counsel input on delegation authority under EU law
- Initial arbitration-panel charter draft

### 9. Programme Director recruits and appoints the independent Arbitration Panel members (8–12 FTE: chair, OSDM/API experts, data-architect specialist, payment-systems expert, accessibility expert, legal/competition specialist, regulator representative, and secretary). Ensure all members sign conflict-of-interest and confidentiality agreements. Publish panel governance framework and dispute-submission procedures.

**Responsible Body/Role:** Programme Director (with advice from DG MOVE and EU Agency for Railways)

**Suggested Timeframe:** Months 1–2 (2026-11-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Arbitration Panel Member Appointment Confirmations (all members signed)
- Conflict-of-Interest and Confidentiality Agreements (signed by all members)
- Panel Governance Charter (terms of office, decision protocols, tie-breaking rules)
- Dispute-Submission Procedures (written guidance for working groups and Steering Committee)

**Dependencies:**

- Written Delegation of Authority secured
- Identified pool of potential panel members (external experts, academics, EU Agency for Railways)
- Panel budget authorized (estimated EUR 6M over 5 years)

### 10. Programme Director convenes the first Arbitration Panel meeting. Confirm panel operating procedures, publish the dispute-submission process, and establish a 30-day readiness review so disputes can be received by Month 3 (2027-01-08).

**Responsible Body/Role:** Arbitration Panel (led by Chair, with PMO support)

**Suggested Timeframe:** Within 3 weeks of all members appointed (Month 2.5 = 2026-12-23)

**Key Outputs/Deliverables:**

- Arbitration Panel Kick-off Meeting Minutes
- Confirmed Operating Procedures and Meeting Schedule
- Published Dispute-Submission Guidelines and Timeline
- Panel Secretary Coordination Contact Information (PMO-accessible)

**Dependencies:**

- All panel members appointed and onboarded
- Written Delegation of Authority finalized
- Panel office/logistics arranged

### 11. Programme Director, working with CER (Confederation of European Railway Operators) and major carriers (Deutsche Bahn, SNCF, Trenitalia, Renfe, ÖBB, NS, SJ, SNCB), drafts a Carrier Commitment Protocol. Define binding commitments: carriers above EUR 50M cross-border revenue commit to API integration by Month 30 (2029-04-08); acceptance of arbitration outcomes; penalties for non-compliance (0.5–1% of quarterly through-ticket revenue in escrow). Distribute for signature by Month 3 (2027-01-08).

**Responsible Body/Role:** Programme Director (PMO) and Project Sponsor (DG MOVE) (with input from CER)

**Suggested Timeframe:** Months 1–3 (2026-11-08 to 2027-01-08)

**Key Outputs/Deliverables:**

- Draft Carrier Commitment Protocol (scope, timelines, penalties)
- Carrier Commitment Letters (signed by each carrier above EUR 50M threshold)
- Signed Escrow Arrangement (with a neutral financial agent holding penalty reserves)
- Carrier Engagement Roadmap (monthly roundtables starting Month 2 = 2026-12-08)

**Dependencies:**

- Programme scope and timeline finalized
- Identified threshold carriers (estimated 8–12 major carriers above EUR 50M)
- Legal counsel guidance on binding commitment enforceability

### 12. Programme Director establishes the Member-State Regulator Coordination Committee and Capacity Building Programme. Conduct a regulator capacity audit (Month 1–2 = 2026-11-08 to 2026-12-08) identifying gaps in each member state. Elect a committee chair (strong-capacity regulator, e.g., Germany, Netherlands) and deputy chair (weak-capacity regulator). Define lead-authority framework for cross-border disputes. Initiate bilateral twinning partnerships.

**Responsible Body/Role:** Programme Director (with EU Agency for Railways and DG MOVE)

**Suggested Timeframe:** Months 1–3 (2026-11-08 to 2027-01-08)

**Key Outputs/Deliverables:**

- Regulator Capacity Audit Report (member-state gaps, resource needs, training priorities)
- Standing Regulators Committee Charter (membership, chair, decision procedures)
- Lead-Authority Framework Document (cross-border dispute resolution procedures)
- Twinning Partnership Agreements (2–3 pilot pairings signed)
- Capacity-Building Programme Outline (training schedule, budget allocation, curriculum)

**Dependencies:**

- Identified regulator representatives in each member state
- Funding authorization for capacity building (EUR 10–15M over 5 years)
- EU Agency for Railways endorsement and technical secretariat commitment

### 13. Member-State Regulator Coordination Committee, led by the newly elected chair, convenes its first meeting. Confirm committee governance, approve lead-authority procedures, and authorize the first quarter of twinning and training activities (Months 2–4 = 2026-12-08 to 2027-02-08). Establish a monthly call schedule between the chair, deputy, PMO and the EU Agency for Railways.

**Responsible Body/Role:** Member-State Regulator Coordination Committee (led by Chair)

**Suggested Timeframe:** Within 2 weeks of chair appointment (Month 2 = 2026-12-08)

**Key Outputs/Deliverables:**

- First Standing Regulators Committee Meeting Minutes
- Approved Lead-Authority Procedures Document
- Twinning Partnership Launch Authorization (budget release)
- Regulator Training Schedule (Months 2–12 = 2026-12-08 to 2027-10-08)
- Monthly Call Schedule (chair, deputy, PMO, EU Agency for Railways)

**Dependencies:**

- Committee chair and deputy appointed
- Capacity audit completed
- Twinning partnerships identified
- Budget allocation confirmed

### 14. Programme Director recruits and establishes the Consumer Product and Support Team (20–30 FTE: product director, product manager, engineering lead, backend/frontend engineers, UX designers, localization specialist, support-centre manager, support agents, data analyst). Begin user research and persona development (Months 2–4 = 2026-12-08 to 2027-02-08) for the through-ticket booking app.

**Responsible Body/Role:** Programme Director (PMO) / Consumer Product Director (once hired)

**Suggested Timeframe:** Months 1–2 (2026-11-08 to 2026-12-08) (staffing completion)

**Key Outputs/Deliverables:**

- Consumer Product Team Organization Chart
- Product Director and Core Team Member Hiring Confirmations
- User Research Plan (persona development, accessibility requirements)
- App Feature Roadmap (MVP scope, launch targets, Phase 1 corridors)
- Support-Centre Infrastructure Plan (24/7 multilingual coverage, escalation procedures)

**Dependencies:**

- Programme budget authorization (EUR 150M for consumer rollout)
- App development and support budget allocated and committed
- Accessibility and consumer-advocacy input on requirements

### 15. Consumer Product Director convenes the first product team meeting. Review user-research findings, finalize MVP scope (search, booking, refund flow, accessibility requests), and establish weekly development rituals (product prioritization, sprint planning, support-centre operational reviews). Define pilot-testing timeline (Month 9 = 2027-07-08 for one corridor).

**Responsible Body/Role:** Consumer Product and Support Team (led by Product Director)

**Suggested Timeframe:** Within 2 weeks of core team staffing (Month 2.5 = 2026-12-23)

**Key Outputs/Deliverables:**

- First Product Team Kick-off Meeting Minutes
- MVP Specification Document (features, user flows, acceptance criteria)
- Development Sprint Schedule (Months 2–15 = 2026-12-08 to 2028-01-08)
- Pilot-Testing Plan (one corridor, 100–500 users, Month 9 = 2027-07-08)
- Support-Centre Operational Readiness Timeline

**Dependencies:**

- Consumer Product Team fully staffed
- User research completed
- Carrier and distributor requirements input
- Technology stack and cloud infrastructure decisions made

### 16. Programme Director, with DG MOVE and legal counsel, commissions a comprehensive Data Protection Impact Assessment (DPIA) and initiates early consultation with the European Data Protection Board (EDPB) and national data protection authorities. Define minimum-necessary PII per transaction (booking, payment, fulfillment, refund, accessibility). Seek DPA consensus on Standard Contractual Clauses (SCCs) and data residency by Month 4 (2027-02-08).

**Responsible Body/Role:** Programme Director (with Data Protection Specialist and Legal Counsel)

**Suggested Timeframe:** Months 0–2 (2026-10-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- DPIA Commissioning Decision (external consultant or internal specialist)
- Draft DPIA Report (PII flows, risks, mitigation)
- Letter to EDPB Requesting Early Consultation (scope of data sharing, consent regimes)
- Draft Data-Governance Framework (PII minimization, SCCs, consent protocols, deletion rules)
- National DPA Engagement Plan (twinning, early feedback, national-specific requirements)

**Dependencies:**

- Project authorization
- Budget for DPIA consultant (if external)
- Access to EDPB and national DPA contact points
- Legal counsel skilled in GDPR and cross-border data flows

### 17. Programme Director recruits and establishes the Ethics, Compliance and Accessibility Oversight Committee. Appoint independent ethics and accessibility experts as chair and deputy chair. Recruit members: GDPR specialist, accessibility expert, ethics/compliance officer (programme staff), finance auditor, BEUC/consumer-advocacy representative. Draft ethics code and conflict-of-interest policy. Publish whistleblower-protection procedures.

**Responsible Body/Role:** Programme Director (with DG MOVE and Ethics Council if available)

**Suggested Timeframe:** Months 0–1 (2026-10-08 to 2026-11-08)

**Key Outputs/Deliverables:**

- Ethics Committee Charter (scope, membership, authority)
- Chair and Deputy Chair Appointment Confirmations
- Ethics Code and Conflict-of-Interest Policy (signed by all programme staff and stakeholders)
- Whistleblower Channel Setup (confidential reporting, retaliation-protection assurance)
- Accessibility Requirements Framework (aligned with WCAG 2.1 AA, 24-hour assistance confirmation, etc.)
- Compliance Checklist Template (for carriers, distributors, payment institutions)

**Dependencies:**

- Identified independent ethics and accessibility experts
- Budget for committee operations and compliance activities (estimated EUR 10M in the governance/compliance line)
- Accessibility Working Group input on requirements

### 18. Ethics, Compliance and Accessibility Oversight Committee convenes its first meeting. Review the DPIA (in draft), confirm accessibility requirements, and approve the ethics code. Require all programme staff and Steering Committee members to sign the ethics code and conflict-of-interest declaration by Month 2 (2026-12-08). Establish quarterly compliance-review procedures.

**Responsible Body/Role:** Ethics, Compliance and Accessibility Oversight Committee (led by Chair)

**Suggested Timeframe:** Within 3 weeks of committee appointment (Month 1.5 = 2026-11-23)

**Key Outputs/Deliverables:**

- First Committee Meeting Minutes
- Reviewed and Endorsed Accessibility Requirements
- DPIA Feedback and Next-Steps Assignment
- Signed Ethics Code and Conflict-of-Interest Forms (all staff and SC members)
- Quarterly Compliance-Review Schedule (starting Month 6 = 2027-04-08)

**Dependencies:**

- Committee chair and deputy appointed
- DPIA report available for review (draft acceptable)
- Accessibility Working Group input on requirements finalized
- Ethics code drafted

### 19. Programme Director initiates formal carrier and distributor engagement. Establish Carrier Advisory Roundtables (quarterly starting Month 2 = 2026-12-08) with major carriers, CER and smaller-operator representatives. Establish Distributor Advisory Council (quarterly starting Month 2 = 2026-12-08) with Trainline, Omio, smaller platforms and the public reference distributor team. Share the programme roadmap, discuss IT capabilities and integration timelines, and address co-funding and commercial incentive questions.

**Responsible Body/Role:** Programme Director (PMO Stakeholder Lead, with Carrier Onboarding Lead)

**Suggested Timeframe:** Months 1–2 (2026-11-08 to 2026-12-08) (initiation and first meeting scheduling)

**Key Outputs/Deliverables:**

- Carrier Advisory Roundtable Agenda and Attendee Confirmation (first meeting Month 2 = 2026-12-08)
- Distributor Advisory Council Charter and Membership Confirmation
- Engagement Communication (programme roadmap, milestones, co-funding framework)
- Notes and Action Items from First Roundtable/Council Meetings
- Carrier IT Capability Assessment Template (to be completed Month 3–4 = 2027-01-08 to 2027-02-08)

**Dependencies:**

- Programme roadmap and timeline finalized
- Co-funding framework defined and approved by Steering Committee
- Identified carrier and distributor representatives
- Commitment protocol drafted and ready for discussion

### 20. Distributor Advisory Council, in collaboration with the PMO, begins defining distributor commercial incentives (co-marketing funds, early API access, fee waivers). Negotiate margin-support measures (estimated EUR 5–10M over 24 months) and commitment letters from Trainline, Omio and other platforms specifying integration timelines (API ready by Month 18 = 2028-04-08).

**Responsible Body/Role:** Distributor Advisory Council (chair or PMO liaison)

**Suggested Timeframe:** Months 2–4 (2026-12-08 to 2027-02-08)

**Key Outputs/Deliverables:**

- Distributor Incentive Framework (co-marketing, fee waivers, early access terms)
- Distributor Commitment Letter Template and Signed Letters (from major platforms)
- Margin-Support Budget Allocation (breakdown of EUR 5–10M co-marketing)
- Distributor Integration Milestone Tracking (API readiness gates by Month 18 = 2028-04-08)

**Dependencies:**

- Distributor Advisory Council established
- Commercial terms and co-funding framework approved by Steering Committee
- Distributor representatives committed to engagement

### 21. Programme Director commissions a detailed activity-based cost model estimating: carrier IT integration costs by carrier size and legacy-system status; hub operating costs per region; public reference distributor annual operating costs; payment-institution transaction fees. Define budget burn forecast, trigger points for contingency activation (monthly spend exceeding 115% of pro-rata forecast), and decision gates (Months 12 and 24 = 2027-10-08, 2028-10-08).

**Responsible Body/Role:** Programme Director (Finance Officer, PMO)

**Suggested Timeframe:** Months 0–2 (2026-10-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Activity-Based Cost Model (detailed breakdown by component: standards, hubs, distributor, capacity building, etc.)
- Five-Year Budget Burn Forecast (monthly and annual)
- Contingency-Activation Trigger Framework (Tier 1, 2, 3 decision points at 115%, 120%+, 125%+ spend)
- Mid-Course Review Gates (Month 12 and 24 = 2027-10-08, 2028-10-08) with decision authority delegation

**Dependencies:**

- Carrier cost estimates from IT capability assessments (to be collected Month 3–4 = 2027-01-08 to 2027-02-08)
- Hub operator quotes and operational cost estimates
- Payment-institution fee benchmarking
- Steering Committee approval of budget-tracking procedures

### 22. Programme Director establishes the project-tracking and risk-management office function within the PMO. Implement a shared project-management tool (Asana, Monday.com, or equivalent) with real-time visibility to all stakeholders. Set up weekly PMO status dashboards covering: milestones, budget burn, carrier readiness, working-group progress, risks and issues, escalations. Publish internal risk register with mitigation owners and tracking.

**Responsible Body/Role:** Programme Director (with PMO Operations Lead and Risk Officer)

**Suggested Timeframe:** Months 0–1 (2026-10-08 to 2026-11-08)

**Key Outputs/Deliverables:**

- Project-Management Tool Configuration and Stakeholder Access Setup
- Weekly Status-Dashboard Template (milestones, budget, risks, decisions)
- Risk Register Template and Initial Risk Identification (baseline ~20 key risks)
- Risk-Escalation Procedures (severity levels, escalation timeframes)
- Monthly PMO Deep-Dive Agenda (budget, risk, milestone, stakeholder reviews)

**Dependencies:**

- PMO core staff hired (at least Operations Lead and Risk Officer)
- Project-management tool procurement authorized and funded
- Risk taxonomy and escalation authority defined

### 23. Programme Director, with DG MOVE, conducts Parliamentary and regulatory tracking. Establish direct liaison with European Parliament TRAN (Transport) and IMCO (Internal Market) committees and key member-state transport ministers. Track Regulation adoption progress weekly (starting Month 0 = 2026-10-08). Set a hard gate: if adoption has not occurred by Month 10 (2027-08-08), pause carrier onboarding commitments and conduct a critical-path review.

**Responsible Body/Role:** Programme Director (Communication Lead, with DG MOVE)

**Suggested Timeframe:** Months 0–2 (2026-10-08 to 2026-12-08) (initial setup and liaison)

**Key Outputs/Deliverables:**

- Regulatory Tracking Dashboard (weekly updates on Regulation adoption progress)
- Parliamentary Liaison Contacts and Meeting Schedule
- Member-State Engagement Plan (key minister briefs, coordination calls)
- Shadow Standards Roadmap (pre-work on OSDM, access terms, settlement architecture, starting Month 0 = 2026-10-08 under 'without-prejudice' frame)
- Contingency Activation Procedure (if adoption slips past Month 9 = 2027-07-08)

**Dependencies:**

- DG MOVE authorization to engage Parliament and member states
- Access to Regulation tracking (e.g., from Parliament Legislative Observatory)
- Identified stakeholder contacts in Parliament and member-state governments

### 24. Programme Director launches market sounding for accredited payment institutions. Issue a Request for Information (RFI) outlining accreditation criteria: multi-currency support (EUR, DKK, SEK, CHF, PLN, CZK, HUF, BGN, RON), settlement cycle <48 hours, refund processing <10 days, SLAs (99.95% uptime), financial stability (PSD2 license required). Target: identify 4–6 potential providers by Month 1 (2026-11-08), issue formal call for applications by Month 2 (2026-12-08).

**Responsible Body/Role:** Programme Director (Finance Officer, PMO) with DG MOVE and ECB guidance

**Suggested Timeframe:** Months 0–2 (2026-10-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Request for Information (RFI) to Payment-Institution Market
- Accreditation Criteria Document (technical, regulatory, financial requirements)
- Call for Applicants (published Month 2 = 2026-12-08, deadline Month 6 = 2027-04-08)
- Accreditation Decision Timeline (decision by Month 8 = 2027-06-08, minimum 2 providers operational by Month 12 = 2027-10-08)
- Fee Negotiation Framework (cap 0.3–0.5% per transaction; subsidy covering 50–70% in Months 0–24 = 2026-10-08 to 2028-10-08)

**Dependencies:**

- Settlement and clearing architecture design completed (defines requirements)
- ECB and payment-regulator input on licensing and compliance
- Budget for accreditation and payment-subsidy (EUR 120M in the clearing line)

### 25. Programme Director, in consultation with CER, smaller-carrier representatives and hub operators, launches hub-operator procurement. Issue a Request for Proposal (RFP) for 4 regional hubs (Paris–Brussels–Amsterdam–Köln, Wien–München–Zurich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin), each to serve 3–5 smaller carriers with legacy booking systems. Specify hub responsibilities: OSDM-compliant API translation, dual-run testing, SLAs (99.9% uptime, <2-hour incident recovery, <2-second latency). Budget per hub: EUR 6M over 5 years; total hub budget EUR 24M launch + EUR 20M reserved for two TEN-T hubs (decisions at Month 30 = 2029-04-08).

**Responsible Body/Role:** Programme Director (Hub Coordination Lead, PMO) with CER

**Suggested Timeframe:** Months 0–2 (2026-10-08 to 2026-12-08) (RFP prep and issue)

**Key Outputs/Deliverables:**

- Hub-Operator RFP (technical requirements, SLAs, cost structure, sunset provisions)
- Hub-Eligibility Criteria (cross-border revenue <EUR 50M, or booking-system age >10 years, or IT staff <10 FTE)
- List of Identified Hub-Eligible Carriers (estimated 12–18 carriers)
- Hub-Procurement Timeline (deadline Month 3 = 2027-01-08, contracts signed by Month 3 = 2027-01-08, operational Month 9 = 2027-07-08)
- Hub-Performance Dashboard Template (uptime, latency, booking-failure rate, mapping-error logs)

**Dependencies:**

- Data-layer architecture design finalized (defines hub responsibilities)
- Smaller-carrier engagement and buy-in (they will use the hubs)
- Hub operator market exists (procured vendors or consortia of carriers)
- Budget authorized (EUR 44M for hubs in the carrier co-funding line)

### 26. Programme Director publishes a comprehensive Stakeholder Engagement and Communication Strategy. Define tiered engagement: monthly all-hands forum (all stakeholders), Steering Committee (quarterly), working groups (monthly/bi-weekly), carrier and distributor advisory councils (quarterly), regulator coordination (monthly). Publish a programme roadmap, FAQ document, and quarterly stakeholder newsletters (starting Month 3 = 2027-01-08). Establish a Community Liaison Officer (1 FTE) to manage regional outreach and transport-union engagement.

**Responsible Body/Role:** Programme Director (Communication Lead, PMO)

**Suggested Timeframe:** Months 1–2 (2026-11-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Stakeholder Engagement Strategy Document
- Communication Plan (channels, cadence, audience segmentation)
- Programme Roadmap (public version, timeline, milestones, funding allocation)
- FAQ and Frequently-Escalated-Questions Document
- Community Liaison Officer Hiring Confirmation
- First Quarterly Stakeholder Newsletter (Month 3 = 2027-01-08)
- Transport-Union Engagement Plan and First Meeting Schedule

**Dependencies:**

- Programme scope and roadmap finalized
- Steering Committee guidance on communication tone and transparency
- Identified stakeholder constituencies and communication preferences
- Budget for communication (estimated EUR 2–3M over 5 years)

### 27. Steering Committee, at its second meeting (Month 3 = 2027-01-08), formally approves the binding standards development pathway and gates. Confirm the Month 18 (2028-04-08) binding-standards deadline, approve the working-group charter and sub-group assignments, and authorize commencement of shadow standards work on OSDM, data-layer design, clearing/settlement, and ticket formats.

**Responsible Body/Role:** Programme Steering Committee

**Suggested Timeframe:** Month 3 (2027-01-08) (quarterly SC meeting)

**Key Outputs/Deliverables:**

- Approved Technical Standards Development Pathway
- Standards Workstream Charter and Sub-Group Assignments (finalized)
- Month 18 (2028-04-08) Binding-Standards Gate Confirmed
- Shadow-Work Scope Definition and Approved Pre-Work Roadmap
- Standards Development Budget Allocation (EUR 280M confirmed)

**Dependencies:**

- Gap analysis and regulatory tracking completed
- Standards working group established and meeting
- Regulation adoption tracking (if adopted by this point, accelerate full standards work; if not, continue shadow work)

### 28. Steering Committee, in consultation with the arbitration panel and technical working groups, formalizes the dispute-resolution protocol for the standards-development phase. Define how contested technical issues are escalated from working groups to the arbitration panel, decision timelines (60 days to ruling), and compliance consequences. Publish this protocol by Month 3 (2027-01-08) so all working groups use it.

**Responsible Body/Role:** Programme Steering Committee (with Arbitration Panel Chair and Standards Lead)

**Suggested Timeframe:** Month 3 (2027-01-08)

**Key Outputs/Deliverables:**

- Approved Dispute-Escalation Protocol (working group -> arbitration panel -> Steering Committee)
- Decision Timelines and Escalation Triggers (published and widely communicated)
- Arbitration Panel Readiness Confirmation (panel can receive disputes by Month 3 = 2027-01-08)

**Dependencies:**

- Arbitration panel fully appointed and trained
- Technical working groups established and operational
- Steering Committee authority over technical disputes confirmed

### 29. Programme Director initiates the Measurement, Baseline and Attribution programme. Hire an independent evaluation firm (Month 3 = 2027-01-08) to design a counterfactual evaluation framework. Commission a baseline survey (Month 0–2 = 2026-10-08 to 2026-12-08, reporting Month 6 = 2027-04-08) asking carriers, distributors and airports for current cross-border sales volumes, complaint metrics and modal-split estimates. Define the 'through-ticket' operational definition (single booking reference + single payment + continuity-of-journey rights) by Month 2 (2026-12-08).

**Responsible Body/Role:** Programme Director (Measurement and Evaluation Lead, PMO)

**Suggested Timeframe:** Months 0–3 (2026-10-08 to 2027-01-08)

**Key Outputs/Deliverables:**

- Independent Evaluator Contract Signed (Month 3 = 2027-01-08)
- Through-Ticket Definition (operationalized, approved by Steering Committee)
- Baseline Survey Design and Respondent List (Month 0–2 = 2026-10-08 to 2026-12-08)
- Baseline Survey Report (Month 6 = 2027-04-08, covering current cross-border volumes, complaints, modal split)
- Counterfactual Evaluation Framework (comparison routes, confounding factors, attribution methodology)
- Quarterly Measurement Dashboard Template (to track 40% through-ticket target, complaints halved, modal shift)

**Dependencies:**

- Measurement budget authorized (EUR 5–10M over 5 years)
- Identification of baseline data sources (carriers, distributors, EUROSTAT, national regulators)
- Steering Committee endorsement of measurement approach

### 30. Steering Committee formally approves the Smaller-Carrier Support Programme (SCSP). Allocate EUR 100–150M in co-funding grants to 12–18 carriers with legacy booking systems or limited IT capacity. Define co-funding tiers (EUR 2–8M per SME, up to EUR 15M per medium-sized operator) conditional on reaching readiness milestones (Month 12, 18, 24, 30 = 2027-10-08 to 2029-04-08). Authorize the PMO to recruit 5 regional coordinators (Budapest, Warsaw, Sofia, Bucharest) to provide on-site mentoring.

**Responsible Body/Role:** Programme Steering Committee (with Finance Officer and Smaller-Carrier representative)

**Suggested Timeframe:** Month 6 (2027-04-08) (quarterly SC meeting)

**Key Outputs/Deliverables:**

- Approved Smaller-Carrier Support Programme Charter
- Co-Funding Allocation Framework (eligible carriers, grant amounts, conditions)
- Regional Coordinator Hiring Plan and Budget (EUR 5M over 5 years for salaries, travel, on-site support)
- Co-Funding Disbursement Schedule (tranches tied to readiness milestones)
- Peer-Mentoring Network Launch (pairing large carriers with small carriers, Month 6–9 = 2027-04-08 to 2027-07-08)

**Dependencies:**

- Carrier IT capability assessments completed (Month 3–4 = 2027-01-08 to 2027-02-08)
- Identified hub-eligible and smaller-carrier representatives
- Budget allocated to carrier co-funding (EUR 290M in the carrier-cofunding line)

### 31. Programme Director, working with the Technical Standards Working Group, launches the EU Agency for Railways market engagement on OSDM and conformance testing. Request that the EU Agency for Railways issue a call for independent conformance testing laboratories (RFP, Month 2 = 2026-12-08; deadline Month 6 = 2027-04-08; contracts signed by Month 8 = 2027-06-08). Secure at least 2–3 labs across different European regions (EU-West, EU-Central, EU-East) to provide testing capacity starting Month 9 (2027-07-08). SLAs: turn around carrier tests within 6 weeks of booking.

**Responsible Body/Role:** Programme Director (with EU Agency for Railways and Standards Lead)

**Suggested Timeframe:** Months 2–3 (2026-12-08 to 2027-01-08) (RFP preparation and issue)

**Key Outputs/Deliverables:**

- EU Agency for Railways Conformance Testing RFP (criteria: OSDM expertise, testing capacity, geographic reach, SLA commitments)
- Call for Testing Laboratory Applicants (Month 2 = 2026-12-08, deadline Month 6 = 2027-04-08)
- Selected Testing Laboratory Contracts (signed by Month 8 = 2027-06-08, ~EUR 30–50M over 5 years)
- Conformance Testing Procedure and Checklist (OSDM compliance, accessibility, GDPR, data quality, safety, financial stability)
- Testing Queue Management Process (allocate slots to carriers based on readiness, priority corridors first)

**Dependencies:**

- Standards working group progress on OSDM specifications (sufficient detail to define testing criteria by Month 6–9 = 2027-04-08 to 2027-07-08)
- EU Agency for Railways commitment to procurement and oversight
- Testing laboratory market exists and has capacity

### 32. Steering Committee, at Month 6 (2027-04-08), conducts a mid-programme review of governance setup. Assess: programme governance bodies formally established (Steering Committee, PMO, working groups, arbitration panel, regulators, consumer team, ethics committee), stakeholder engagement underway, risk register active, budget tracking operational. Confirm critical-path milestones (Regulation adoption tracking, standards pre-work, carrier commitment letters, accredited payment-institution timeline). Address any governance gaps or conflicts discovered in Months 0–6 (2026-10-08 to 2027-04-08).

**Responsible Body/Role:** Programme Steering Committee

**Suggested Timeframe:** Month 6 (2027-04-08) (mid-point of governance-setup phase)

**Key Outputs/Deliverables:**

- Governance Setup Review Report (status of each body, challenges, remediation actions)
- Governance Maturity Assessment (scale: not established, established but not operational, operational with issues, fully operational)
- Critical-Path Status Summary (standards pre-work, carrier engagement, accreditation, hub procurement, measurement baseline)
- Steering Committee Process Improvements (if any governance issues detected, approve corrective actions)
- Decision: Proceed to full standards development (Month 6 = 2027-04-08) or adjust trajectory based on findings

**Dependencies:**

- All governance bodies have been established and have held at least one meeting
- Progress reports available from working groups, PMO, arbitration panel, regulators, consumer team
- Risk register with at least 15–20 key risks identified and mitigation owners assigned

### 33. Steering Committee formally approves the commencement of binding standards development (Month 6–9 = 2027-04-08 to 2027-07-08), conditional on the Regulation being adopted by Month 9 (2027-07-08) or the shadow work being sufficiently advanced to proceed. Confirm the Month 18 (2028-04-08) binding-standards gate and authorize escalation to the arbitration panel if working-group consensus cannot be achieved on any technical issue by Month 12 (2027-10-08).

**Responsible Body/Role:** Programme Steering Committee

**Suggested Timeframe:** Month 9 (2027-07-08)

**Key Outputs/Deliverables:**

- Approved Full Standards-Development Roadmap (Month 6–18 = 2027-04-08 to 2028-04-08)
- Regulation Adoption Status (adopted, or shadow work sufficient to proceed; if not, contingency timeline)
- Sub-Group Work Schedules and Deliverables (OSDM, data layer, clearing, ticket format, passenger rights, accessibility, GDPR)
- Escalation Trigger: If any sub-group cannot reach consensus by Month 12 (2027-10-08), dispute escalates to arbitration panel by Month 15 (2028-01-08) for Month 18 (2028-04-08) finalization
- Public Communication Plan (publish draft standards by Month 15 = 2028-01-08 for 4-week stakeholder comment period)

**Dependencies:**

- Regulation adoption (or clear indication of final text by Month 9 = 2027-07-08)
- Shadow standards work substantially complete
- Technical working groups and arbitration panel operational
- Carrier and distributor feedback on early standards drafts (incorporated into working group work)

### 34. Steering Committee formally approves the Technology Infrastructure Procurement plan. Procure a European-wide API hosting and caching infrastructure (Month 2–6 = 2026-12-08 to 2027-04-08, contracts signed by Month 8 = 2027-06-08) to support the shared data layer. Specify: redundancy across ≥3 data centres per region (EU-West, EU-Central, EU-East), automatic failover (<30 seconds), SLAs (API latency p95 <2 seconds, uptime 99.95%, throughput ≥500 req/s per corridor). Establish 24/7 API operations centre (Month 6 = 2027-04-08) with escalation to carriers within 15 minutes of any critical incident.

**Responsible Body/Role:** Programme Steering Committee (with Technical Architect and Data-Layer Lead)

**Suggested Timeframe:** Month 6 (2027-04-08) (SC approval)

**Key Outputs/Deliverables:**

- Technology Infrastructure RFP (hosting, caching, redundancy, SLA requirements)
- Infrastructure Provider Selection (signed contracts by Month 8 = 2027-06-08)
- API Operations Centre Setup Plan (location, staffing, escalation protocols)
- Performance Monitoring Dashboard (latency, uptime, throughput, incident response)
- Carrier Infrastructure Assessment and Co-Funding Plan (identify carriers unable to meet API SLAs; co-fund upgrades)
- Load-Testing and Chaos-Engineering Plan (quarterly exercises starting Month 9 = 2027-07-08)

**Dependencies:**

- Data-layer architecture finalized by working group
- Technology budget authorized (EUR 60M in the data-layer line)
- Carrier IT capability assessments completed (Month 3–4 = 2027-01-08 to 2027-02-08)

### 35. Steering Committee formally approves the Consumer Product Pilot Plan (Month 9 = 2027-07-08). Authorize the Consumer Product Team to deploy an MVP of the through-ticket booking app to one priority corridor (e.g., Paris–Brussels–Amsterdam) with 100–500 test users (Month 9 = 2027-07-08). Gather user feedback and iterate (Months 10–12 = 2027-08-08 to 2027-10-08). Set a go/no-go gate for full development (Month 12 = 2027-10-08): if user satisfaction is below 3.8/5 or critical usability issues are uncovered, conduct a 4-week redesign cycle before proceeding to full build-out.

**Responsible Body/Role:** Programme Steering Committee (with Consumer Product Director)

**Suggested Timeframe:** Month 9 (2027-07-08)

**Key Outputs/Deliverables:**

- Approved Consumer Product Pilot Plan (scope, timeline, success criteria)
- MVP Deployment to Pilot Corridor (Month 9 = 2027-07-08)
- User Testing Report and Feedback Summary (Months 9–12 = 2027-07-08 to 2027-10-08)
- Go/No-Go Decision Gate (Month 12 = 2027-10-08)
- Approved Full-Build Roadmap (Months 12–15 = 2027-10-08 to 2028-01-08 for production app, localization, support-centre setup)

**Dependencies:**

- Consumer Product Team fully staffed and operational
- MVP development completed (Month 9 = 2027-07-08)
- Carrier and distributor support for pilot (willing to integrate with pilot app for testing)
- Access to real passenger data (anonymized) or test-user pool

### 36. Member-State Regulator Coordination Committee convenes at Month 9 (2027-07-08) to review twinning and capacity-building progress. Assess: training completion rates, regulator readiness to enforce access and passenger-rights rules, cross-border dispute procedures functioning. Finalize the lead-authority framework and publish enforcement guidance for all member states. Confirm that regulators are equipped to conduct conformance audits of carriers starting Month 18 (2028-04-08).

**Responsible Body/Role:** Member-State Regulator Coordination Committee

**Suggested Timeframe:** Month 9 (2027-07-08)

**Key Outputs/Deliverables:**

- Twinning and Capacity-Building Progress Report
- Regulator Readiness Assessment (by member state, identifying any ongoing gaps)
- Finalized Lead-Authority Procedures (published and mandated for cross-border disputes)
- Enforcement Guidance Document (access-compliance audit procedures, complaint handling, passenger-rights enforcement)
- Conformance Auditor Training Plan (certify regulators to conduct OSDM, accessibility, GDPR audits of carriers starting Month 18 = 2028-04-08)

**Dependencies:**

- Twinning partnerships operational and funded (Months 2–9 = 2026-12-08 to 2027-07-08)
- Regulator capacity audit identified specific training needs (Month 1–2 = 2026-11-08 to 2026-12-08)
- EU Agency for Railways providing technical secretariat support

### 37. Steering Committee holds its Month 12 (2027-10-08) mid-course budget and milestone review. Assess: actual spending vs. forecast (trigger Tier 1, 2, or 3 contingency decisions if overrun exceeds 115%); Regulation adoption status (confirm adopted or update shadow-work schedule); standards-development progress (confirm on track for Month 18 = 2028-04-08 deadline); carrier commitment-letter status (target: 90%+ of major carriers signed); accreditation progress (target: 2+ payment providers selected or finalists identified); hub procurement (target: contracts signed by Month 12 = 2027-10-08 or imminent); measurement baseline validation (Month 9 = 2027-07-08 baseline confirmed).

**Responsible Body/Role:** Programme Steering Committee

**Suggested Timeframe:** Month 12 (2027-10-08)

**Key Outputs/Deliverables:**

- Budget Mid-Course Review Report (actual vs. forecast, contingency-activation decision)
- Milestone Status Summary (Regulation, standards, carrier engagement, hub procurement, accreditation, measurement)
- Critical-Path Risk Assessment (identify any blockers to Month 18 = 2028-04-08 or Month 30 = 2029-04-08 gates)
- Steering Committee Decision: Proceed on schedule, adjust trajectory, or activate contingency levers
- Revised Programme Roadmap (if any adjustments made)

**Dependencies:**

- Monthly budget reports available (Months 0–12 = 2026-10-08 to 2027-10-08)
- Progress reports from all working groups and external partners
- Measurement baseline finalized (Month 9 = 2027-07-08)
- Risk register updated with emerging issues

### 38. Steering Committee at Month 12 (2027-10-08) formally establishes the Carrier Conformance and Readiness Assessment Process. Define readiness gates for each carrier: API design review (Month 15 = 2028-01-08), test-bed deployment (Month 18 = 2028-04-08), dual-run testing (Months 21–24 = 2028-07-08 to 2028-10-08), pre-production trial (Months 24–27 = 2028-10-08 to 2029-01-08), production go-live (Month 30 = 2029-04-08). Assign conformance testing labs and reserve queue slots. Define go/no-go criteria (passing conformance audit, payment-settlement integration, accessibility confirmation).

**Responsible Body/Role:** Programme Steering Committee (with Carrier Onboarding Lead and Testing Lab Lead)

**Suggested Timeframe:** Month 12 (2027-10-08)

**Key Outputs/Deliverables:**

- Carrier Conformance and Readiness Framework (gates, timeline, criteria)
- Carrier-Specific Readiness Roadmaps (for major carriers and hub-eligible carriers)
- Conformance Testing Schedule (queue allocation by corridor and carrier priority)
- Testing Lab SLA Agreements (turn-around time, quality standards, incident escalation)
- Readiness Dashboard (track each carrier's progress against gates, published monthly starting Month 15 = 2028-01-08)
- Hub and Legacy-Carrier Timeline (dual-run testing Months 15–18 = 2028-01-08 to 2028-04-08; pilot deployment Month 18 = 2028-04-08)

**Dependencies:**

- Conformance testing labs procured and operational
- Standards framework sufficiently defined (working-group consensus or arbitration-panel rulings on OSDM, data-layer design)
- Carrier commitment letters signed (target: 90%+ of major carriers)
- Hub operator contracts signed (target: all 4 hubs by Month 12 = 2027-10-08)

### 39. Technical Standards Working Group delivers the draft binding standards document (Month 15 = 2028-01-08) covering OSDM API specifications, data-layer interfaces, clearing/settlement message formats, ticket format and validation, passenger rights (continuity-of-journey, rerouting, refund), accessibility requirements (24-hour assistance confirmation, accessibility data publishing), and GDPR/compliance rules. Publish for 4-week public stakeholder comment period (Months 15–18 = 2028-01-08 to 2028-04-08).

**Responsible Body/Role:** Technical Standards and Conformance Working Group (led by Standards Lead)

**Suggested Timeframe:** Month 15 (2028-01-08)

**Key Outputs/Deliverables:**

- Draft Binding Standards Document (OSDM, data-layer, clearing, ticket, passenger rights, accessibility, GDPR, ~150–200 pages)
- Implementation Guidance and Worked Examples (for carriers, distributors, hub operators)
- Public Stakeholder Comment Period Launch (Month 15–18 = 2028-01-08 to 2028-04-08)
- Feedback Summary Report (Month 18 = 2028-04-08, incorporating major comments into final document)

**Dependencies:**

- All sub-groups substantially complete their sections (by Month 12–15 = 2027-10-08 to 2028-01-08)
- Arbitration panel has resolved any major technical disputes (via rulings issued by Month 12 = 2027-10-08)
- Regulation adopted (or sufficient clarity on final text)
- Carrier and distributor input integrated (from advisory councils and working groups)

### 40. Steering Committee formally approves the final binding standards document (Month 18 = 2028-04-08). Incorporate feedback from the public comment period (Months 15–18 = 2028-01-08 to 2028-04-08). Once approved, the standards are legally binding for all participating carriers, distributors, payment institutions and member-state regulators. Publish the standards and formally notify all stakeholders of their adoption. Set a 90-day technical transition period (through Month 21 = 2028-07-08) for systems adjustments before full conformance testing begins.

**Responsible Body/Role:** Programme Steering Committee

**Suggested Timeframe:** Month 18 (2028-04-08) (hard milestone)

**Key Outputs/Deliverables:**

- Approved Final Binding Standards Document (signed by Steering Committee Chair and DG MOVE)
- Standards Publication and Stakeholder Notification
- Conformance Checklist (auditable criteria for OSDM, data-layer, clearing, ticket, passenger rights, accessibility, GDPR)
- Technical Transition Plan (Month 18–21 = 2028-04-08 to 2028-07-08, carriers make system adjustments)
- Conformance Testing Commencement Schedule (Month 21 = 2028-07-08 onward)

**Dependencies:**

- Standards working group delivers final draft and incorporates feedback
- Arbitration panel has resolved all outstanding disputes
- Steering Committee consensus or supermajority approval
- Regulation adopted (standards must align with final regulation text)

### 41. Steering Committee and the arbitration panel jointly publish a formal technical compliance and enforcement framework (Month 18 = 2028-04-08). Specify: conformance audit procedures (by designated testing labs), remediation timelines (if non-compliance found), penalties (0.5–1% of quarterly through-ticket revenue per conformance breach, held in escrow), and escalation to national regulators for market-conduct violations (non-discrimination, passenger-rights denial). Confirm the arbitration panel's continued role in resolving interpretation disputes (through Month 30 = 2029-04-08 and beyond).

**Responsible Body/Role:** Programme Steering Committee (jointly with Arbitration Panel Chair)

**Suggested Timeframe:** Month 18 (2028-04-08)

**Key Outputs/Deliverables:**

- Conformance and Enforcement Framework Document
- Audit Procedures and Testing Lab Protocols
- Remediation and Penalty Schedule
- Escalation Procedures (non-compliance to national regulators and Commission)
- Arbitration Panel Continuity Plan (ongoing dispute resolution through Month 30 = 2029-04-08 and beyond)

**Dependencies:**

- Binding standards approved (Month 18 = 2028-04-08)
- Arbitration panel fully operational
- Member-state regulators trained and ready to enforce
- Conformance testing labs operational and equipped to audit

### 42. Consumer Product and Support Team completes and launches the public through-ticket booking app (Month 27 = 2029-01-08) on all four priority corridors (Paris–Brussels–Amsterdam–Köln, Wien–München–Zurich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin). App features: multilingual search and booking (24+ languages), accessibility request and confirmation (24-hour SLA), refund-claim submission (via app or support hotline), real-time disruption notifications, passenger-rights promise display. Simultaneously launch 24/7 multilingual support centre with target <1-hour response for critical issues.

**Responsible Body/Role:** Consumer Product and Support Team (led by Product Director)

**Suggested Timeframe:** Month 27 (2029-01-08)

**Key Outputs/Deliverables:**

- Public Through-Ticket Booking App (production launch, all priority corridors, 24+ languages)
- App Performance Metrics (latency, uptime, search success rate, user satisfaction)
- Multilingual Support Centre Operations (24/7 coverage, response-time SLAs, escalation procedures)
- First Month Support Metrics (complaint volume, resolution time, accessibility requests)
- Post-Launch Roadmap (Phase 2: TEN-T corridor support, starting Month 36 = 2029-10-08)

**Dependencies:**

- App development and localization completed (Months 12–27 = 2027-10-08 to 2029-01-08)
- Carrier and distributor API integration completed (so app can fetch real booking data)
- Payment-integration and refund-processing tested and working
- Support infrastructure (call centre, CRM, knowledge base) operational

### 43. Steering Committee conducts a mid-programme review at Month 24 (2028-10-08). Assess: standards approved (Month 18 = 2028-04-08, completed), carrier conformance readiness (target: 80%+ of major carriers through compliance audit), through-ticket volumes (target baseline: 15% of cross-border journeys, gate for continued co-funding), app development progress (target MVP pilot completed, full app launch on track for Month 27 = 2029-01-08), budget burn (trigger Tier 2/3 decisions if overrun >120%). Confirm critical path to Month 30 (2029-04-08) API mandate (at least 90% of corridor traffic bookable end-to-end).

**Responsible Body/Role:** Programme Steering Committee

**Suggested Timeframe:** Month 24 (2028-10-08) (second mid-course review)

**Key Outputs/Deliverables:**

- Mid-Programme Progress Report (standards, carrier readiness, through-ticket volumes, budget status)
- Through-Ticket Volume Validation (baseline measurement, 15% gate for co-funding continuity)
- Carrier Conformance Status Summary (% compliant by corridor, remaining work to Month 30 = 2029-04-08)
- Consumer Product Progress Report (app usability, support performance, TEN-T expansion planning)
- Steering Committee Decision: Proceed to Month 30 (2029-04-08) API mandate, adjust corridor sequencing, or defer less-ready carriers

**Dependencies:**

- Measurement baseline finalized and validated (Month 9 = 2027-07-08)
- Carrier conformance testing underway (Months 21–24 = 2028-07-08 to 2028-10-08)
- Monthly budget reports and spend tracking active
- App pilot-testing and feedback loop completed

### 44. Steering Committee formally declares the Month 30 (2029-04-08) mandatory API exposure milestone. Confirm: at least 90% of cross-border traffic on the four priority corridors is bookable end-to-end through a compliant OSDM API or hub access; all major carriers (above EUR 50M cross-border revenue) are live with conforming APIs or have a time-bound plan to reach compliance by Month 36 (2029-10-08); smaller carriers not yet ready are using hub access and can demonstrate a credible migration path to native OSDM by Month 36 (2029-10-08).

**Responsible Body/Role:** Programme Steering Committee

**Suggested Timeframe:** Month 30 (2029-04-08) (hard milestone)

**Key Outputs/Deliverables:**

- Mandatory API Exposure Achievement Confirmation (90%+ readiness on all four priority corridors)
- Carrier Compliance Status Report (live carriers, hub-access carriers, non-compliant carriers with remediation plans)
- Through-Ticket Volume Summary (actual vs. target progress toward 40% by Month 60 = 2031-10-08)
- Consumer Product Status (app live on all four corridors, support centre operational, user satisfaction metrics)
- Decision: Proceed to TEN-T expansion (Month 36 = 2029-10-08), or adjust corridor or carrier timelines

**Dependencies:**

- Binding standards approved and enforced (Month 18 = 2028-04-08)
- Carrier conformance testing completed (Months 21–30 = 2028-07-08 to 2029-04-08)
- Payment-institution accreditation and settlement infrastructure operational
- Measurement and evaluation framework tracking progress toward targets

### 45. Steering Committee, at Month 36 (2029-10-08), makes the formal decision to expand through-ticketing beyond the four priority corridors to the broader TEN-T network. Define the TEN-T extension corridors and priorities; allocate funding for two additional regional hubs (EUR 12M reserved, finalized at Month 30 = 2029-04-08). Confirm carrier readiness for TEN-T corridors (target: 70%+ major carriers + hub-eligible carriers in place by Month 36 = 2029-10-08). Set intermediate goals for TEN-T completion (target: Month 48 = 2030-10-08 for secondary corridors, Month 60 = 2031-10-08 for full network).

**Responsible Body/Role:** Programme Steering Committee

**Suggested Timeframe:** Month 36 (2029-10-08)

**Key Outputs/Deliverables:**

- TEN-T Expansion Approval and Corridor Prioritization
- Additional Regional Hub Procurement Decision (EUR 12M for 2 TEN-T hubs)
- TEN-T Corridor Readiness Assessment (carrier compliance, hub deployment status)
- TEN-T Rollout Timeline (Phase 2: Months 36–48 = 2029-10-08 to 2030-10-08; Phase 3: Months 48–60 = 2030-10-08 to 2031-10-08)
- Budget Allocation for TEN-T (EUR 50–100M additional if needed from contingency or supplementary authority)

**Dependencies:**

- Four priority corridors operational and meeting through-ticket volume targets (Month 30 = 2029-04-08)
- Measurement showing positive momentum and no major issues requiring rework
- Carrier and hub-operator readiness assessments for TEN-T routes
- Budget contingency sufficient or supplementary authority available

### 46. Steering Committee, at Month 48 (2030-10-08), initiates the post-Month 60 (2031-10-08) sustainability planning phase. Establish a Sustainability Working Group to design transition models for each programme component: (1) Data-layer operations: identify a permanent operational host (e.g., EU Agency for Railways or multi-carrier consortium) and define governance/financing by Month 54 (2031-04-08). (2) Clearing mechanism: shift to operational cost-recovery or permanent public funding commitment. (3) Public reference distributor: decide on post-Month 60 (2031-10-08) model (shutdown, hand-off to commercial operator, or downsizing to niche service). (4) Regulator capacity: secure member-state commitment to maintain funding.

**Responsible Body/Role:** Programme Steering Committee (with PMO and external sustainability advisor)

**Suggested Timeframe:** Month 48 (2030-10-08)

**Key Outputs/Deliverables:**

- Sustainability Working Group Charter and Membership
- Preliminary Transition Models for Each Programme Component
- Financial Sustainability Assessment (EUR 45M/year recurring run-cost not covered by the cap identified)
- Decision Gates: Data-layer permanent host selected (by Month 54 = 2031-04-08), Distributor wind-down or hand-off plan approved (by Month 54 = 2031-04-08), Regulator funding commitment secured (by Month 54 = 2031-04-08)

**Dependencies:**

- Programme is on track to complete Month 60 (2031-10-08) full corridor through-ticketing
- Measurement and evaluation showing positive outcomes (40% through-ticket share, complaints halved, modal shift data)
- Stakeholder buy-in for long-term through-ticketing infrastructure (regulators, carriers, distributors confirm ongoing value)

### 47. Steering Committee, in consultation with the Sustainability Working Group, secures written commitments from the Commission, Council and member states (by Month 54 = 2031-04-08) confirming post-Month 60 (2031-10-08) funding and operational arrangements for: data-layer operations, clearing mechanism, regulator capacity building, and (if applicable) public distributor operations. Finalize transition-execution plans and regulatory authorities' roles.

**Responsible Body/Role:** Programme Steering Committee (with DG MOVE and member-state representatives)

**Suggested Timeframe:** Month 54 (2031-04-08)

**Key Outputs/Deliverables:**

- Commission and Council Commitment Letters (post-Month 60 = 2031-10-08 funding and operational governance)
- Member-State Funding Commitments (regulator capacity building, national enforcement)
- Finalized Data-Layer Permanent-Host Agreement (governance, SLAs, funding)
- Clearing Mechanism Post-Month 60 (2031-10-08) Operating Model (cost recovery or public funding)
- Public Distributor Transition Plan (wind-down, hand-off, or operational model)
- Regulatory Transition Procedures (handover of enforcement and compliance monitoring to national regulators)

**Dependencies:**

- Sustainability Working Group preliminary models finalized (Month 48–54 = 2030-10-08 to 2031-04-08)
- Stakeholder (regulator, carrier, distributor) agreement on long-term sustainability model
- Financial commitments from national budgets or European multi-annual framework secured

### 48. Programme Director, with the Measurement and Evaluation Lead, delivers the comprehensive final evaluation report (Month 60 = 2031-10-08). Report includes: (1) Achievement of the three headline targets (40% through-ticket share, complaints halved, modal shift), (2) Counterfactual attribution (separated from confounding factors like fuel prices or aviation-tax policy), (3) Process evaluation (governance effectiveness, working-group efficiency, stakeholder satisfaction), (4) Lessons learned and recommendations for future EU programmes.

**Responsible Body/Role:** Programme Director (with Independent Evaluator and Measurement Lead)

**Suggested Timeframe:** Month 60 (2031-10-08) (end of programme)

**Key Outputs/Deliverables:**

- Final Evaluation Report (120–150 pages, comprehensive assessment of outcomes, process, impact, lessons)
- Final Outcome Dashboard (40% through-ticket share final figure, complaints reduction%, modal shift%, distributor satisfaction)
- Public Dissemination (summary report for Parliament, member states, media)
- Recommendations for Future Programmes (governance, timeline, budget, risk management)

**Dependencies:**

- Quarterly measurement and evaluation data collected throughout Months 0–60 (2026-10-08 to 2031-10-08)
- Counterfactual model developed and applied (baseline vs. programme corridors)
- Independent evaluator contracted and engaged throughout the programme
- Final outcome data validated (through-ticket volumes, complaint metrics, modal shift indicators)

### 49. Programme Steering Committee formally closes the programme (Month 60 = 2031-10-08). Confirm: all four priority corridors operating with through-ticketing (at scale supporting 40% of cross-border journeys), TEN-T extension launched and on track for Month 72 (2032-10-08) full-network completion (or revised timeline as warranted). Conduct a final programme review, release staff, transition operational responsibilities to permanent hosts (data-layer, clearing, regulator networks, distributor channels), and hand over all programme documentation to DG MOVE and the EU Agency for Railways for archival and future reference.

**Responsible Body/Role:** Programme Steering Committee (led by Chair)

**Suggested Timeframe:** Month 60 (2031-10-08)

**Key Outputs/Deliverables:**

- Programme Closure Report (summary of achievements, budget final close-out, staff release plan)
- Handover Documentation (all systems, contracts, policies, compliance records)
- Transition Confirmation Letters (from permanent hosts confirming receipt and operational continuity)
- Final Steering Committee Meeting Minutes (programme close-out decision, vote of thanks)
- Public Announcement of Programme Completion (communication to Parliament, member states, media)

**Dependencies:**

- All programme deliverables substantially complete or transitioned to permanent operations
- Final evaluation report completed (Month 60 = 2031-10-08)
- Permanent-host arrangements confirmed and operational (Month 54–60 = 2031-04-08 to 2031-10-08)
- Steering Committee and all governance bodies ready to stand down