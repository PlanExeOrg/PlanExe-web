# Governance Audit


## Audit - Corruption Risks

- Preferential API access granted to favored distributors in exchange for kickbacks or side agreements, violating non-discrimination duties and certification schemes.
- Hub operators steering smaller carriers toward unnecessary or overpriced services, or manipulating mapping logic to inflate usage fees and transaction volumes.
- Carrier executives accepting co-funding grants in exchange for inflating invoices or falsely certifying API compliance, diverting public money to private benefit.
- Payment-institution staff delaying or misdirecting settlement funds to affiliated entities, exploiting the multi-carrier clearing mechanism for personal gain.
- Regulators accepting informal favors (travel, consulting contracts for family members) from major carriers in exchange for lax enforcement of access-term compliance.
- Programme staff or arbitration-panel members leveraging insider knowledge of technical decisions to advise carriers or distributors on how to circumvent or game the standards.

## Audit - Misallocation Risks

- Co-funding grants to carriers are inflated or allocated to carriers not meeting the eligibility criteria (revenue > EUR 50M or IT staff > 10 FTE), leaving truly disadvantaged carriers unfunded.
- Hub operational budgets (EUR 44M allocated) are misused for non-core activities (marketing, staff perks) instead of integration support and resilience, causing hubs to fail and requiring emergency replacement spending.
- Conformance-testing budget (EUR 280M standards + testing) is front-loaded to early carriers, exhausting resources before smaller or slower operators can be tested, delaying their Month 30 (2029-04-08) readiness.
- Programme staff travel and overhead consume 20–30% of PMO and governance costs without proportional output; inefficient meeting structure and decision-making delay standards work by 2–4 months.
- Public reference distributor budget (EUR 215M over 5 years, ~EUR 43M/year) is used to launch a full retail service with margins and marketing spend that crowds out commercial distributors, rather than being limited to reference implementation and pilot accessibility services.
- Payment-institution accreditation budget and fee-subsidy reserves (EUR 15M in fee subsidy + EUR 5–10M provider-switch contingency) are consumed by single-provider dominance or early provider failure, leaving no resources for genuine competition or failover.

## Audit - Procedures

- Quarterly co-funding recipient audits (starting Month 6 = 2027-04-08): verify that grant recipients meet eligibility criteria, that invoice amounts are reasonable and supported by documentation, and that promised integration milestones (API exposure, data-quality SLAs) are achieved; withhold next disbursement if audit raises red flags.
- Monthly hub operational reviews (starting Month 9 = 2027-07-08): inspect hub operator's incident logs, uptime records, booking-failure rates and mapping-accuracy samples; if booking-failure rate exceeds 2% for >1 week, freeze new carrier onboarding and conduct root-cause audit.
- Conformance-testing capacity and throughput audits (quarterly, Month 12 onward = 2027-10-08 onward): track test-lab utilization, queue times for carriers awaiting slots, and distribution of testing resources across carrier size cohorts; if small carriers face >8-week delays while majors are tested within 2 weeks, reallocate lab capacity.
- Payment-institution performance and fee audits (monthly, Month 12 onward = 2027-10-08 onward): verify settlement cycle compliance (<48 hours), refund-processing SLA (decision <10 days), transaction-fee caps (target 0.3–0.5%, max 0.7%), and absence of preferential treatment of affiliated or large-carrier accounts.
- Carrier co-funding claim audits (quarterly, Month 6 onward = 2027-04-08 onward): sample 5–10% of invoices, interview carrier IT teams about milestone progress, verify that private spend (assumed EUR 0.5–2.0 billion) is actually occurring and is not being substituted by public funding, and reconcile carrier-reported spending against commitments made in Month 3 (2027-01-08) Commitment Letters.
- Post-implementation external compliance audit (Month 42–48 = 2030-04-08 to 2030-10-08): hire independent auditor to verify that all major systems (data layer, clearing, hubs, public distributor, regulator capacity) are operating within SLAs, that access terms are enforced consistently across member states, and that no unbudgeted liabilities have accumulated; use findings to validate Month 60 (2031-10-08) sustainability model.

## Audit - Transparency Measures

- Monthly public dashboard (published on DG MOVE website, starting Month 6 = 2027-04-08) showing: cumulative spend by budget line item vs. plan, carrier compliance status (on-time or delayed) for each corridor, hub operational metrics (uptime %, booking-failure rate), and provisional through-ticket volumes and complaints metrics; dashboard updated within 2 weeks of quarter-end to provide real-time visibility.
- Quarterly Steering Committee meeting minutes published (within 2 weeks of meeting) including: decisions made, dissenting views from any stakeholder, technical disputes that went to arbitration, and budget or schedule changes; confidential commercial data (individual carrier cost, specific carrier IT architecture) redacted; all meetings held in Brussels with open audio/video feed option for observers (non-decision makers).
- Arbitration panel rulings and reasoning documents published (within 5 working days of decision, Month 1 onward = 2026-11-08 onward) showing the technical question, competing positions, evidence considered, and the panel's rationale; dissenting opinions from panel members recorded and published alongside the majority ruling.
- Carrier and distributor certification and access-term audit results published quarterly (aggregate form, Month 18 onward = 2028-04-08 onward): percentage of carriers and distributors meeting OSDM conformance, number and outcome of non-discrimination complaints filed and resolved, average API latency and uptime per corridor, and any enforcement actions or penalties imposed.
- Public reference distributor operational transparency report (quarterly, Month 15 onward = 2028-01-08 onward): through-ticket volumes, revenue, operating cost, accessibility-assisted bookings, complaint types and resolution times, and financial sustainability outlook; identify any subsidy draw above budget or structural deficits requiring mid-course intervention.
- Annual programme evaluation and progress report (first report Month 12 = 2027-10-08, then annually) published by an independent evaluator, comparing baseline (Month 9 = 2027-07-08) to latest outcomes on the three headline targets (40% through-ticket share, complaints halved, modal shift in planning range 5–15%), and disclosing methodology, any data gaps or attribution uncertainty, and recommendations for course corrections.

# Internal Governance Bodies

### 1. Programme Steering Committee

**Rationale for Inclusion:** This €1.5 billion, five-year, multi-stakeholder EU programme requires strategic oversight across 27 member states, 25+ carriers, and multiple regulatory domains (rail, payment, competition, GDPR). The Steering Committee provides high-level direction on standards priorities, corridor sequencing, funding allocation disputes, and milestone enforcement. It is the ultimate decision-making body for choices that cannot be resolved at operational level and ensures political and institutional alignment with DG MOVE and the Commission.

**Responsibilities:**

- Approve binding standards (Month 18 = 2028-04-08) and API mandate enforcement thresholds (Month 30 = 2029-04-08)
- Allocate and approve deviations from the EUR 1,500 million budget and trigger contingency tiers
- Resolve escalated technical disputes and policy conflicts between carriers, distributors, regulators and member states
- Approve corridor sequencing gates and readiness thresholds (proposed: 90% of traffic bookable end-to-end)
- Monitor milestone adherence and make formal decisions on timeline adjustments or deferrals
- Oversee through-ticket target progress and authorize mid-course strategic pivots

**Initial Setup Actions:**

- Draft and sign a Memorandum of Understanding defining Steering Committee authority, decision rules and escalation triggers (Month 1 = 2026-11-08)
- Elect a steering committee chair and establish a quarterly meeting schedule (Month 1 = 2026-11-08)
- Define binding decision thresholds (e.g., budget deviations >EUR 50M require SC approval; technical rulings >60 days trigger escalation)
- Establish a formal conflict-resolution process for Steering Committee disputes (majority vote with tie-breaker role specified)
- Secure written Council/Commission delegation of final authority over binding standards and milestone enforcement (Month 2 = 2026-12-08)

**Membership:**

- DG MOVE representative (chair or co-chair)
- EU Agency for Railways representative (technical lead)
- Programme director (operations lead)
- Three to four major-carrier representatives (rotating annually; e.g., Deutsche Bahn, SNCF, Trenitalia, ÖBB)
- One SME/smaller-carrier representative (elected by CER members)
- One distributor representative (Trainline, Omio, or public reference distributor; rotating)
- One national regulator representative (elected by Standing Regulators Committee)
- One BEUC or disability-rights representative

**Decision Rights:** Binding authority over standards approval (Months 18 baseline + amendments through Month 30 = 2029-04-08), corridor gates and readiness thresholds, funding allocations above EUR 50 million, milestone deferrals >4 weeks, and escalated technical/commercial disputes. Authority is limited to strategic-level decisions; operational execution (daily carrier onboarding, individual API compliance checks) remains with the PMO and working groups.

**Decision Mechanism:** Quarterly in-person meeting (120 minutes, Brussels) with written agenda and consent agenda for routine approvals. Major decisions require consensus or, if unattainable after 2 weeks of negotiation, a supermajority vote (2/3 of voting members, excluding the chair). Tie-breaker: if votes are evenly split, the chair (DG MOVE) casts the deciding vote. Escalated disputes from working groups are tabled and decided within 4 weeks; if a decision cannot be reached, the issue is escalated to the Commission with a minority-position record.

**Meeting Cadence:** Quarterly (Months 3, 6, 9, 12, 15 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08, 2028-01-08... starting Month 3 = 2027-01-08). Emergency meetings may be convened within 5 working days if a milestone-threatening issue arises (e.g., major carrier non-compliance, budget overrun exceeding Tier 2 threshold, or legal challenge). Written decisions on routine items (budget approvals within threshold, minor timeline adjustments) may be made by written consent between meetings.

**Typical Agenda Items:**

- Progress report on the critical path: standards finalisation, carrier integration, hub readiness, API performance metrics
- Monthly spend report and budget variance analysis; triggering of contingency tiers if needed
- Escalated disputes from working groups or the arbitration panel (technical or governance conflicts)
- Milestone gate reviews (e.g., Month 18 = 2028-04-08 standards approval, Month 30 = 2029-04-08 API readiness assessment)
- Corridor sequencing decisions and readiness-gate outcomes
- Stakeholder engagement and political risk updates

**Escalation Path:** Unresolved Steering Committee disputes escalate to the Commission (DG MOVE, DG COMP if competition concerns are present) for binding decision within 2 weeks. If the Commission cannot decide, the issue is referred to the Council or European Parliament TRAN committee for legislative or policy guidance (estimated escalation cycle: 3–4 weeks). For non-consensus decisions where voting results in 2/3 supermajority, the dissenting minority may request a written Commission review within 10 days.
### 2. Programme Management Office (PMO) and Core Project Team

**Rationale for Inclusion:** Day-to-day execution of a EUR 1,500 million, five-year programme spanning 27 member states and 25+ carriers requires a dedicated, professionally staffed operational hub. The PMO manages carrier onboarding, standards development workstreams, budget tracking, risk escalation and milestone delivery. It is the operational nerve centre that bridges strategic direction from the Steering Committee with execution by technical working groups and external partners.

**Responsibilities:**

- Manage the critical path and monthly milestone tracking; flag slippage >2 weeks within 5 working days
- Oversee standards working groups and ensure consensus on OSDM, data-layer design, clearing and settlement rules, and ticket formats by Month 18 (2028-04-08)
- Coordinate carrier onboarding workflow: assess readiness, allocate co-funding tranches tied to milestones, and track progress toward Month 30 (2029-04-08) API mandate
- Manage the budget and spend tracking; alert the Steering Committee when monthly burn rates exceed plan or when contingency usage is needed
- Coordinate accreditation of payment institutions, hub operators and distributors; maintain a conformance dashboard
- Operate and escalate the risk-management process: identify new risks monthly, track mitigation actions and escalate unmitigated risks to the Steering Committee
- Manage the quarterly measurement and evaluation process; produce the public dashboard of progress metrics

**Initial Setup Actions:**

- Recruit 10–15 core PMO staff (director, deputy, standards lead, technical architect, budget officer, comms lead, risk officer) by Month 2 (2026-12-08)
- Establish a shared project-management tool (e.g., Asana, Monday.com) with visibility to all stakeholders, updated weekly with status, red flags and decisions (Month 1 = 2026-11-08)
- Define PMO operating procedures: decision authority, escalation triggers, meeting schedules for working groups and carrier engagement (Month 1 = 2026-11-08)
- Secure an office in Brussels with meeting facilities and colocation for the core team (Month 1 = 2026-11-08)
- Publish the project charter and kick-off communication to all stakeholders (Month 1 = 2026-11-08)

**Membership:**

- Programme Director (1 FTE, overall accountability)
- Deputy Director / Operations Lead (1 FTE)
- Standards and Technical Lead (1 FTE, OSDM/data-layer architecture)
- Budget and Finance Officer (1 FTE)
- Carrier Onboarding and Conformance Lead (1 FTE)
- Governance and Risk Officer (1 FTE)
- Communication and Stakeholder Lead (1 FTE)
- Data Protection and Legal Specialist (0.5 FTE, GDPR, competition law)
- Evaluation and Measurement Lead (1 FTE)
- Hub and Gateway Coordination (1 FTE)
- Administrative support (2 FTE)

**Decision Rights:** Operational decisions within the PMO's authority: carrier onboarding approvals (subject to co-funding thresholds), weekly working-group facilitation, escalation to the Steering Committee or arbitration panel, risk flag and mitigation tracking, and monthly dashboard publication. The PMO does not have authority to approve major strategy changes, override arbitration panel rulings, or commit budget above EUR 10 million per item; these escalate to the Steering Committee.

**Decision Mechanism:** Daily stand-up (15 min) among PMO leadership; weekly PMO all-hands meeting (60 min) to review status and risks; working-group leads report to the PMO on Wednesday each week with highlight updates (by 14:00 Brussels time) so the PMO can flag issues by EOD. Operational decisions are made by the PMO Director in consultation with relevant leads (e.g., budget decisions with the Finance Officer); decisions affecting the critical path or involving disputes between two stakeholders are escalated to the Steering Committee or arbitration panel within 5 working days.

**Meeting Cadence:** Weekly PMO all-hands and governance review (Thursdays, 10:00–11:00 Brussels time); working-group leads submit written status by Wednesday EOD each week. Monthly PMO deep-dive (last Thursday of each month) reviewing budget, risk, milestone and stakeholder updates. Quarterly reporting to the Steering Committee (aligned with SC meeting calendar). Emergency escalation protocol: any issue that threatens a hard milestone is flagged immediately to the Programme Director and escalated within 24 hours.

**Typical Agenda Items:**

- Milestone tracking: standards workstream progress, carrier integration readiness by corridor, API performance metrics, hub operational status
- Budget and spend tracking: monthly burn rate vs. forecast, contingency-tier triggers, co-funding pipeline
- Carrier onboarding: new carriers requesting integration, co-funding approvals, conformance testing queue
- Risk and issues: new risks identified, mitigation tracking, escalations to Steering Committee or arbitration panel
- Working-group updates: OSDM, data-layer design, clearing/settlement, consumer app, accessibility, regulator capacity building
- Stakeholder engagement: political tracking (Regulation adoption, member-state support), media/reputational issues

**Escalation Path:** Operational issues escalate from working groups to the PMO (48 hours to triage); if unresolved within 1 week, escalate to the arbitration panel (if technical) or Steering Committee (if strategic/budget). Issues requiring inter-member-state coordination escalate to the Standing Regulators Committee or, if involving non-EU partners (Switzerland), to DG MOVE's international affairs team. Issues involving competition-law concerns escalate immediately to DG COMP with a formal request for guidance.
### 3. Technical Standards and Conformance Working Group

**Rationale for Inclusion:** The binding standards (Month 18 = 2028-04-08 deadline) define OSDM-compatible APIs, data-layer architecture, clearing and settlement message formats, ticket formats, passenger-rights rules, accessibility requirements and GDPR compliance boundaries. This working group must deliver consensus-based standards that carriers, distributors, payment institutions and regulators all accept as feasible and enforceable. It is the technical engine of the programme.

**Responsibilities:**

- Define and publish the binding standards document covering OSDM API specifications, data-layer query interfaces, clearing message standards, through-ticket definition, refund and rerouting procedures, accessibility requirements and GDPR/compliance rules
- Conduct iterative technical consultation with carriers, distributors, payment institutions and regulator representatives; manage disputes through working-group consensus or escalation to arbitration panel
- Establish conformance-testing criteria and oversee procurement of independent testing laboratories by Month 3 (2027-01-08)
- Publish conformance checklist and audit procedures for carriers and distributors; manage quarterly conformance reviews
- Advise the Steering Committee on technical feasibility of proposed milestone dates and corridor sequencing; flag readiness risks

**Initial Setup Actions:**

- Establish sub-working groups by Month 2 (2026-12-08): OSDM/API design, data-layer architecture, clearing/settlement, ticket format, passenger rights/accessibility, GDPR compliance
- Conduct a gap analysis (Month 2–3 = 2026-12-08 to 2027-01-08) comparing the Regulation's assumed framework to the Commission's proposal; flag divergences and propose resolutions
- Begin 'shadow standards' pre-work (Month 0–3 = 2026-10-08 to 2027-01-08) on technical issues that do not depend on final Regulation text (e.g., OSDM API latency targets, data-minimisation rules)
- Establish a technical dispute-resolution process: if two sub-groups cannot agree on an issue by Month 12 (2027-10-08), escalate to the arbitration panel for binding ruling
- Publish a draft standards document by Month 12 (2027-10-08) for public consultation; collect feedback by Month 15 (2028-01-08) and incorporate before final approval

**Membership:**

- Chair: Standards Lead from the PMO (1 FTE equivalent)
- OSDM sub-group: 2–3 OSDM experts (external), 2–3 carrier IT leads, 1 distributor technical representative
- Data-Layer sub-group: 1–2 data-architecture specialists, 1 carrier operations lead, 1 EU Agency for Railways representative
- Clearing/Settlement sub-group: 1 payment-systems architect, 1 carrier finance lead, 1 distributor lead, 1 legal/compliance representative
- Ticket Format sub-group: 1 ticket-system expert, 2 carrier representatives, 1 validator-device manufacturer representative
- Passenger Rights/Accessibility sub-group: 1 legal specialist (passenger rights), 1 accessibility expert, 1 carrier operations representative, 1 BEUC/disability-rights representative
- GDPR/Compliance sub-group: 1 DPA specialist, 1 competition-law representative, 1 carrier privacy officer, 1 data-protection specialist

**Decision Rights:** The working group develops consensus standards for Steering Committee approval (Month 18 = 2028-04-08 deadline). Sub-groups can agree on technical specifications within their scope; if consensus is not achievable within a sub-group, the issue escalates to the full working group (2-week resolution target) or to the arbitration panel if still unresolved. The working group has no authority to override regulatory requirements or change the binding-standards deadline; it operates within the constraints set by the Regulation and the Steering Committee.

**Decision Mechanism:** Monthly full working-group meeting (120 min, Brussels or hybrid) with consensus-based decision-making. Each sub-group meets bi-weekly (60 min, hybrid). Technical disputes within a sub-group are escalated to the full working group with a position paper from each side; the full group attempts consensus within 2 weeks. If consensus fails, the arbitration panel is asked for a binding ruling within 60 days. Major technical decisions (e.g., federated vs. central data layer) are made by the full group with supermajority (2/3) consensus if needed.

**Meeting Cadence:** Monthly full working-group meetings (2nd Tuesday of each month, 14:00–16:00 Brussels time); bi-weekly sub-group meetings (staggered schedule so no carrier or distributor is in back-to-back meetings). Emergency technical deep-dives scheduled ad hoc if a dispute arises.

**Typical Agenda Items:**

- OSDM API specification: latency SLAs, throughput targets, error handling, backward compatibility
- Data-layer architecture: federated query performance, central cache design, disruption-event streaming, data-quality rules
- Clearing message standards: revenue apportionment algorithms, settlement cycle, dispute-resolution procedures
- Ticket format and validation: barcode vs. digital wallet, offline vs. online verification, GDPR data minimisation
- Passenger rights and accessibility: assistance confirmation timelines, rerouting procedures, accessibility data requirements
- GDPR and competition law: data-sharing safeguards, Standard Contractual Clauses, confidentiality rules

**Escalation Path:** Unresolved technical disputes escalate from sub-groups to the full working group (2-week deadline); if still unresolved, escalate to the arbitration panel for binding ruling within 60 days. If the arbitration panel ruling is contested (e.g., a major carrier claims it is technically infeasible), the issue escalates to the Steering Committee for a policy decision. Major standards conflicts that cannot be resolved technically (e.g., conflict between GDPR minimisation and detailed disruption reporting) escalate to the Commission for guidance.
### 4. Independent Arbitration Panel for Technical Disputes

**Rationale for Inclusion:** The programme's critical path depends on resolving contested technical decisions (e.g., inventory-parity thresholds, API latency SLAs, settlement message formats) quickly and with binding force. The lightweight arbitration panel avoids the 12–18 month legal setup of a joint undertaking while providing clear, time-boxed dispute resolution. It is essential for keeping standards-setting on track and preventing re-litigation of settled technical issues.

**Responsibilities:**

- Receive escalated technical disputes from working groups or the Steering Committee and conduct independent technical review
- Issue binding rulings on contested technical standards, conformance criteria and SLAs within 60 days of receiving a dispute
- Publish reasoned rulings explaining the technical rationale, evidence considered and any dissenting panel-member positions
- Track compliance with rulings: carriers and entities have 14 days to confirm adoption or request escalation to the Commission
- Provide advisory guidance (non-binding) on emerging technical issues raised by working groups or the PMO

**Initial Setup Actions:**

- Secure written Council/Commission delegation of binding authority by Month 2 (2026-12-08); delegation must specify decision scope (technical standards only, not commercial terms), time limits (60 days to ruling, 14 days to comply) and escalation procedures
- Recruit and appoint 8–12 panel members (Month 1–2 = 2026-11-08 to 2026-12-08): 2–3 OSDM or rail-IT experts, 1–2 data-architecture specialists, 1 payment-systems expert, 1 accessibility expert, 1 legal/compliance specialist, 1–2 independent arbitrators (no carrier/distributor affiliation), and 1 panel secretary (0.5 FTE)
- Establish panel governance: term of office (3–5 years), conflict-of-interest rules (panel members cannot advise carriers or distributors during their tenure), and a tie-breaking or consensus protocol
- Define the dispute-submission process: working groups or Steering Committee submit a written dispute with positions from all parties (limit 5 pages per position); panel has 10 days to declare the dispute admissible
- Publish panel operating procedures and communication protocols by Month 1 (2026-11-08)

**Membership:**

- Panel Chair (1, independent expert, e.g., from an external neutral institution like the EU Agency for Railways or an academic)
- OSDM/API specialists (2–3, external; rotational participation in disputes to avoid bias)
- Data-architecture expert (1, external)
- Payment-systems expert (1, external; may be a payment-institution representative with firewall rules to prevent conflicts)
- Accessibility expert (1, external; e.g., from a disability-rights organisation or accessibility standards body)
- Legal/competition specialist (1, external; for GDPR and antitrust questions)
- Transport regulation specialist (1, may be from the EU Agency for Railways with appropriate independence)
- Panel Secretary (0.5–1 FTE, employed by the programme to manage scheduling, documentation and publication)

**Decision Rights:** Binding authority over technical standards disputes: API latency SLAs, throughput requirements, data-layer architecture choices, message-format specifications, conformance-testing criteria, and allocation of technical liability (e.g., who is responsible for mapping errors in a hub). Authority is limited to technical feasibility and standards alignment; the panel cannot override the Regulation's requirements, approve budget deviations or make commercial decisions (e.g., carrier pricing, fee caps). If a dispute involves both technical and commercial elements (e.g., whether an access term is non-discriminatory), the panel issues a technical ruling and escalates the commercial implications to the Steering Committee.

**Decision Mechanism:** When a dispute is received, the panel's chair convenes a panel roster (5–7 members) with expertise relevant to the dispute. Panel members review written submissions from all parties (5 pages each, plus exhibits). The panel conducts a technical review (10–20 days), may request clarifications from parties (3-day response window) and holds a closed deliberation meeting (day 30–40). The panel issues a written ruling (day 60) with findings, technical rationale and the decision. If panel members disagree, dissenting opinions are published alongside the majority ruling. Tie-breaking: if the panel is evenly split (rare, given odd roster size), the chair casts a deciding vote.

**Meeting Cadence:** Panel roster convenes within 5 working days of a dispute being declared admissible. Panel deliberations are internal (not public). Rulings are published within 5 working days of issuance (day 65 of the cycle). The full panel meets quarterly for governance and to review emerging technical issues; panels for individual disputes meet as needed (estimated 1–3 disputes per quarter during the standards-development phase = Months 4–18 = 2027-02-08 to 2028-04-08).

**Typical Agenda Items:**

- Escalated dispute submissions: technical positions from all parties, feasibility assessments
- Deliberation on the dispute: technical evidence, regulatory constraints, impact on critical path
- Drafting of the ruling and resolution of any dissents
- Quarterly review of panel operations: caseload, decision quality, emerging patterns in disputes

**Escalation Path:** If a party (e.g., a major carrier) contests a panel ruling and claims it is technically infeasible or conflicts with national law, the party may request escalation to the Commission within 10 days of the ruling. The Commission has 14 days to affirm or overturn the ruling (this is rare and only for exceptional cases). If the Commission affirms the ruling and a carrier still refuses to comply, the issue escalates to DG MOVE for enforcement action (co-funding holds, public-channel bypass, or regulatory escalation). For disputes involving competition-law or GDPR questions, the panel's ruling is immediately referred to DG COMP or the EDPB for concurrence; if those bodies disagree, the matter escalates to the Steering Committee and Commission for a final decision.
### 5. Member-State Regulator Coordination Committee and Capacity Building Programme

**Rationale for Inclusion:** National rail regulators across 27 member states must enforce access, refund and accessibility duties consistently for through-tickets to be credible and non-discriminatory. However, regulators vary widely in resources, expertise and enforcement traditions. A dedicated coordination committee and capacity-building programme ensure consistent enforcement, cross-border dispute resolution and alignment with the programme's access-term rules. This is essential for the non-discrimination goal and for the credibility of the Month 30 (2029-04-08) API mandate.

**Responsibilities:**

- Harmonise enforcement procedures across member states for access terms, passenger rights and accessibility compliance; publish common inspection checklists and audit standards by Month 12 (2027-10-08)
- Establish a lead-authority mechanism for cross-border disputes: when a distributor complains that a carrier in another member state is denying API access, designate one national regulator as the lead, with other member states recognising its decision
- Provide capacity building and twinning partnerships for weaker regulators: training on access-enforcement, data-quality auditing, complaint handling and cross-border coordination
- Operate a Standing Regulators Committee (quarterly) to review enforcement outcomes, escalate systemic issues to the Commission, and update procedures
- Track and report on compliance metrics: access-complaint resolution times, non-discrimination audit findings, and consistency of passenger-rights enforcement across member states

**Initial Setup Actions:**

- Conduct a regulator capacity audit in Month 1–2 (2026-11-08 to 2026-12-08) identifying staff, budget and enforcement expertise gaps in each member state
- Establish the Standing Regulators Committee and elect a chair (preferably from a strong-capacity regulator, e.g., Germany, Netherlands, France) by Month 1 (2026-11-08)
- Define a lead-authority framework (Month 2–3 = 2026-12-08 to 2027-01-08): specify which member state's regulator leads for disputes involving carriers in that state; establish mutual recognition of lead-authority decisions
- Fund bilateral twinning partnerships (Month 2–6 = 2026-12-08 to 2027-04-08): pair weak-capacity regulators with strong ones; provide training budgets (EUR 0.5–1M per partnership over 3 years)
- Develop common inspection checklists and audit procedures for access compliance by Month 6 (2027-04-08); publish a regulator toolkit for smaller member states

**Membership:**

- Chair: Head of a major national regulator (e.g., Germany, France, Netherlands, Austria), elected for a 2-year term
- Deputy Chair: Head of a regulator from a smaller or weaker-capacity member state (rotating)
- 27 member-state regulator representatives (one per member state; may be director or deputy director level)
- EU Agency for Railways representative (ex-officio, advisory role on cross-border coordination)
- Programme Director or Deputy (PMO observer, for coordination with programme timelines)
- Technical secretariat: 1 FTE (hosted by the EU Agency for Railways or a volunteering member-state regulator), managing meeting schedules, documentation and capacity-building coordination

**Decision Rights:** Recommends (not binding, absent escalation) common enforcement procedures, regulator training curricula, and audit standards to the Steering Committee. Binding authority: lead-authority decisions on cross-border disputes are final and recognised by all member states (absent Commission override). The committee can escalate systemic enforcement failures (e.g., a member state consistently failing to investigate non-discrimination complaints) to the Commission for investigation and enforcement action. The committee cannot override national regulations or force a regulator to act beyond its legal powers.

**Decision Mechanism:** Quarterly meeting (120 min) with supermajority consensus (2/3 of voting members) on enforcement standards and procedures. Lead-authority decisions on individual cross-border disputes are made by the lead regulator (as designated in the framework) within 30 days; other member-state regulators have 5 days to file a dissent with the committee chair, who then refers the matter to the Standing Regulators Committee for review. If 2+ member states dispute the lead decision, escalate to the EU Agency for Railways or Commission for mediation (14-day resolution target).

**Meeting Cadence:** Quarterly in-person or hybrid meetings (typically aligned with Steering Committee calendar, with 1 week separation). Emergency virtual meetings can be convened within 2 working days if a cross-border dispute requires urgent resolution. Monthly calls (30 min) among the chair, deputy chair, PMO and the EU Agency for Railways to track emerging issues.

**Typical Agenda Items:**

- Enforcement review: number and type of access-discrimination complaints received and resolved; average resolution time per member state
- Cross-border disputes: updates on lead-authority investigations, recognition of decisions, and escalations
- Regulator capacity: twinning partnership progress, training attendance, resource gaps
- Systemic issues: patterns of non-compliance by carriers in particular member states, need for procedural updates
- Coordination with the programme: critical-path tracking, milestone readiness, impact of enforcement on corridor gates

**Escalation Path:** Member-state enforcement failures escalate from the Standing Regulators Committee to the Commission (DG MOVE) for investigation and potential enforcement action under Article 258 TFEU (infringement proceedings). Cross-border disputes that the lead regulator cannot resolve escalate to the EU Agency for Railways for mediation (14-day resolution target); if still unresolved, escalate to DG MOVE for a binding decision. If a member state refuses to recognise a lead-authority decision, the issue escalates to the Commission and potentially to CJEU (Court of Justice of the European Union) for ruling on mutual-recognition obligations.
### 6. Consumer Product and Support Team

**Rationale for Inclusion:** The programme's success depends on passenger uptake of through-tickets via the public reference distributor (and complementary commercial platforms). A dedicated consumer product team builds the multilingual booking app, ensures user experience quality, and operates a 24/7 support centre for passenger complaints and accessibility requests. This team is responsible for the consumer-facing brand and credibility of the through-ticketing system, directly supporting the 40% through-ticket target.

**Responsibilities:**

- Design and build a multilingual EU through-ticketing booking app (launch Month 15 = 2028-01-08; four-corridor rollout by Month 27 = 2029-01-08)
- Implement real-time search, booking and refund flows; integrate accessibility request and confirmation; display through-ticket continuity-of-journey promises and refund guarantees
- Operate a 24/7 multilingual customer support centre (launch Month 15 = 2028-01-08): handle booking errors, refund claims, accessibility requests, and complaints in 24+ languages; target <1-hour response for critical issues
- Monitor app performance, user satisfaction and complaint trends; iterate the app design quarterly based on user feedback and A/B testing
- Coordinate with carriers, distributors and payment institutions to resolve passenger-escalated technical issues (e.g., booking failed at confirmation, refund not received)
- Produce quarterly public reports on customer satisfaction, complaint types, accessibility-assisted bookings and support-queue metrics

**Initial Setup Actions:**

- Recruit the consumer product team (20–30 FTE) by Month 1 (2026-11-08): product manager, engineering lead, UX/design leads, backend engineers, localization specialists, and support-centre manager
- Conduct user research and persona development (Month 2–4 = 2026-12-08 to 2027-02-08); wireframe core flows (search, booking, refund, accessibility request)
- Build an MVP (minimum viable product) for pilot testing on one corridor (Month 5–8 = 2027-03-08 to 2027-06-08); deploy to 100–500 test users
- Iterate based on pilot feedback (Month 9–12 = 2027-07-08 to 2027-10-08); conduct UX refinement and accessibility testing (WCAG 2.1 AA compliance)
- Begin full-scale development and localization in Month 12 (2027-10-08); target production-ready by Month 15 (2028-01-08)
- Establish the support centre infrastructure (call centre, email ticketing, knowledge base, escalation procedures) by Month 14 (2027-12-08)

**Membership:**

- Consumer Product Director (1 FTE, accountability for app and brand)
- Product Manager (1 FTE, feature prioritization and roadmap)
- Engineering Lead (1 FTE, technical architecture and delivery)
- Backend Engineers (3–4 FTE, API integration, data handling)
- Frontend/UX Engineers (2–3 FTE, user interface, accessibility)
- Localization and Content Manager (1 FTE, multilingual support, legal disclaimers)
- Support Centre Manager (1 FTE, team leadership, quality assurance)
- Support Agents (4–6 FTE initially, scaling to 10–15 FTE by Month 24 = 2028-10-08, covering 24/7 coverage in 24+ languages via subcontractors for non-major languages)
- Data Analyst (0.5 FTE, monitoring satisfaction metrics, complaint patterns)

**Decision Rights:** Operational decisions: app feature prioritization, support procedures, multilingual content, and technology stack choices. The team does not have authority to commit budget above EUR 2 million per item (e.g., major infrastructure upgrades), change through-ticket definition or refund policies (set by the Steering Committee), or commit carrier/distributor integration timelines (negotiated with the PMO). User experience decisions and support procedures are made by the team with input from carriers, distributors and passenger advisory representatives.

**Decision Mechanism:** Weekly product prioritization meeting (60 min): product manager, engineering lead and UX lead discuss incoming requirements (from carriers, distributors, support tickets) and update the feature roadmap. Support centre manager and quality-assurance lead review complaint trends and procedural issues in a weekly meeting (30 min). Major decisions (e.g., whether to pivot from a native app to a web-based offering, or whether to integrate a partner payment processor) escalate to the Steering Committee or PMO for approval.

**Meeting Cadence:** Weekly product team meetings (Monday, 10:00–11:00 Brussels time); weekly support-centre operational meeting (Friday, 10:00–10:30); biweekly full team sync (first and third Thursday of each month, 14:00–15:30). Monthly retrospective and planning session (last Friday of each month, 13:00–15:00) reviewing metrics and upcoming iterations.

**Typical Agenda Items:**

- App development progress: feature completion, bug tracking, performance metrics (latency, crash rates, search success rate)
- User satisfaction and feedback: app-store reviews, NPS (Net Promoter Score), user-research findings, accessibility feedback
- Support centre operations: complaint volume by category (booking errors, refund delays, accessibility, technical issues), average resolution time, escalations to carriers or payment institutions
- Multilingual content and localization: translation quality reviews, cultural adaptation for different EU markets
- Integration with carriers, distributors and payment systems: API changes, new data feeds, coordination on messaging to passengers

**Escalation Path:** Technical issues that require carrier or payment-institution intervention escalate from support tickets to the PMO (via the support-centre manager) with a severity rating (critical: <2-hour resolution target; high: <24-hour; medium: <5 days). PMO coordinates carrier/distributor response. If a support issue reveals a systemic problem (e.g., >100 complaints per week about failed refunds), escalate to the Steering Committee for investigation and corrective action. Accessibility issues escalate immediately to the Accessibility Working Group and to BEUC/disability-rights representatives for guidance.
### 7. Ethics, Compliance and Accessibility Oversight Committee

**Rationale for Inclusion:** The programme involves sensitive areas: passenger data (PII, accessibility information, payment details), access-to-essential-transport (persons with reduced mobility), and fair competition among carriers and distributors. A dedicated ethics and compliance committee ensures adherence to GDPR, accessibility standards, disability-rights principles and anti-corruption rules. It provides independent assurance that the programme's governance and operations are credible and inclusive.

**Responsibilities:**

- Oversee GDPR compliance across all programme entities: commissioning and reviewing the DPIA (Months 0–2 = 2026-10-08 to 2026-12-08), securing EDPB/DPA consensus on data-flow safeguards by Month 4 (2027-02-08), and conducting quarterly compliance audits on data-handling practices (starting Month 18 = 2028-04-08)
- Monitor accessibility compliance: ensuring that booking systems, assistance request/confirmation flows and accessibility data meet WCAG 2.1 AA and EU accessibility directives; conducting quarterly accessibility audits of the public app and carrier systems
- Establish and enforce ethics guidelines for programme staff, carrier and distributor representatives, and regulator participants: conflict-of-interest rules, anti-corruption provisions, whistleblower protections
- Oversee passenger-data handling: review data-sharing agreements among carriers, distributors, payment institutions and the clearing mechanism; ensure data minimisation and consent compliance
- Review and approve compliance scorecards for carriers and distributors; report quarterly to the Steering Committee on ethics and compliance status

**Initial Setup Actions:**

- Recruit committee members and establish terms of office (Month 0–1 = 2026-10-08 to 2026-11-08); ensure membership includes external, independent ethics and accessibility experts with no conflicts of interest
- Commission the DPIA and request EDPB consultation (Month 0–2 = 2026-10-08 to 2026-12-08); establish a timeline for DPA consensus by Month 4 (2027-02-08)
- Draft an ethics code and conflict-of-interest policy (Month 1 = 2026-11-08); require all programme staff, carriers and distributors to sign by Month 2 (2026-12-08)
- Establish accessibility requirements and conformance checklist (Month 2–4 = 2026-12-08 to 2027-02-08) aligned with the Accessibility Working Group; define audit procedures
- Create a confidential whistleblower channel (Month 1 = 2026-11-08); communicate it to all stakeholders and protect reporters from retaliation

**Membership:**

- Chair: Independent ethics or compliance expert (external, e.g., from an EU ethics body or academic institution); 3-year term
- Deputy Chair: Independent accessibility expert (external, e.g., from a disability-rights organisation); 3-year term
- GDPR/Data Protection Specialist (external, e.g., from a DPA or data-protection consultancy)
- Accessibility and Inclusive Design Expert (external, e.g., from an accessibility standards organisation)
- Ethics and Compliance Officer (programme staff, 1 FTE, working closely with the committee)
- Finance and Audit Representative (external, independent auditor or audit firm, rotating 2-year terms)
- Passenger Advocacy Representative (e.g., from BEUC or a consumer-protection body)

**Decision Rights:** Advisory authority: the committee makes recommendations to the Steering Committee on GDPR compliance, accessibility standards and ethics enforcement. Binding authority (in consultation with DG MOVE): suspension of a carrier's or distributor's participation in the programme if serious GDPR or ethics violations are found (e.g., mishandling of passenger data, corruption). The committee cannot override the Regulation or change the programme's core objectives; it operates within the legal and policy framework set by the Commission and Steering Committee.

**Decision Mechanism:** Quarterly full committee meeting (120 min, in-person or hybrid). Consensus-based decision-making; if a member dissents on a recommendation to the Steering Committee, the dissent is documented and both positions are submitted to the SC. Emergency meetings (within 5 working days) may be convened if a critical ethics or compliance issue is discovered (e.g., evidence of corruption or a major data breach).

**Meeting Cadence:** Quarterly formal meetings (aligned with Steering Committee calendar); monthly virtual calls (30 min) among the chair, deputy chair and the ethics/compliance officer to review emerging issues. Ad-hoc meetings if urgent escalations arise.

**Typical Agenda Items:**

- GDPR compliance status: data-flow architecture, DPA consensus tracking, carrier/distributor data-handling practices, incidents and remediation
- Accessibility compliance: app and carrier system audits, accessibility-assisted booking metrics, passenger complaints related to accessibility
- Ethics and conflict-of-interest review: new programme staff and stakeholder representatives, potential conflicts, compliance with the ethics code
- Passenger data security and breach response: quarterly review of data-handling incidents, mitigation actions
- Whistleblower cases: confidential review of any reported ethics violations or compliance concerns; recommendation of investigation or corrective action

**Escalation Path:** Recommendations on GDPR, accessibility or ethics compliance escalate to the Steering Committee for decision or action (e.g., co-funding suspension, mandatory corrective action by a carrier). Serious violations (evidence of corruption, major data breaches, severe accessibility failures) escalate immediately to DG MOVE and the Commission for investigation and potential enforcement. GDPR and accessibility issues may also escalate to the relevant national DPA or accessibility authority for guidance or enforcement.

# Governance Implementation Plan

### 1. Project Sponsor (DG MOVE) formally initiates the programme and establishes initial programme authority. Publish the project charter, confirm programme start date (Month 0 = 2026-10-08), approve the governance structure, and designate the Programme Director role with interim decision authority during set-up.

**Responsible Body/Role:** Project Sponsor (DG MOVE)

**Suggested Timeframe:** Within 1 week of project start (Month 0.1 = 2026-10-11)

**Key Outputs/Deliverables:**

- Signed Project Charter
- Programme Director Role Specification and Interim Authority Memorandum
- Initial Communication to All Stakeholders (Regulation text, timeline, governance overview)

**Dependencies:**

- Project start decision
- Identified Project Sponsor and initial programme leadership

### 2. Programme Director (once designated) establishes the core Programme Management Office (PMO) and convenes a governance-setup task force. Define PMO staffing plan, office location (Brussels), project-management tools and reporting cadence. Initiate recruitment of 10–15 core PMO staff (director, deputy, standards lead, technical architect, budget officer, communications lead, risk officer).

**Responsible Body/Role:** Programme Director

**Suggested Timeframe:** Within 2 weeks of project start (Months 0–1 = 2026-10-08 to 2026-11-08)

**Key Outputs/Deliverables:**

- PMO Organization Chart and Staffing Plan
- Office/Meeting Facilities Lease Agreement (Brussels)
- Project Management Tool Setup (Asana, Monday.com, or equivalent)
- PMO Recruitment Initiation (job descriptions, outreach)

**Dependencies:**

- Project Sponsor authorization
- Budget authorization for PMO operations

### 3. Programme Director drafts the Memorandum of Understanding (MOU) governing the Programme Steering Committee (SteerCo): authority, decision rights, decision-making rules, escalation procedures, meeting cadence. Define quorum, tie-breaking provisions and record-keeping protocols.

**Responsible Body/Role:** Programme Director (with input from Legal Counsel and DG MOVE)

**Suggested Timeframe:** Within 3 weeks of project start (Months 0–1 = 2026-10-08 to 2026-11-08)

**Key Outputs/Deliverables:**

- Draft Steering Committee MOU (authority, scope, decision rules)
- Proposed Steering Committee Membership List
- Nominated Steering Committee Chair (to be approved by DG MOVE)

**Dependencies:**

- Project Charter approved
- PMO established
- Understanding of stakeholder landscape (carriers, regulators, distributors)

### 4. Senior Management (DG MOVE) formally appoints the Steering Committee Chair and confirms initial membership. Chair must be a senior DG MOVE or Commission representative; deputy chair a representative from a smaller/weaker-capacity member state or regulator. Secure written commitment from all nominated members (Months 1–2 = 2026-11-08 to 2026-12-08).

**Responsible Body/Role:** Project Sponsor (DG MOVE) / Senior Management

**Suggested Timeframe:** By end of Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Steering Committee Chair Appointment Letter (signed)
- Steering Committee Deputy Chair Appointment Letter (signed)
- Signed Membership Confirmation from All Committee Members
- Finalized Steering Committee MOU (all parties endorsed)

**Dependencies:**

- Draft MOU prepared
- Proposed membership identified and vetted for conflicts of interest
- DG MOVE approval of chair and governance structure

### 5. Steering Committee Chair (newly appointed) schedules the first kick-off meeting. Distribute agenda (programme overview, governance roadmap, critical path overview, month 0–3 = 2026-10-08 to 2027-01-08 priorities). Hold the first formal Steering Committee meeting to confirm governance, approve the PMO operating procedures and authorize the next wave of working-group setup.

**Responsible Body/Role:** Programme Steering Committee (led by Chair)

**Suggested Timeframe:** Within 2 weeks of chair appointment (Month 1.5 = 2026-11-23)

**Key Outputs/Deliverables:**

- Steering Committee Kick-off Meeting Minutes
- Approved PMO Operating Procedures and Meeting Schedule
- Approved Working-Group Charter (standards, carrier engagement, consumer product, etc.)
- Decision Log (decisions, action owners, deadlines)

**Dependencies:**

- Steering Committee formally appointed
- MOU finalized and endorsed
- PMO draft operating procedures ready for SC review

### 6. Programme Director, in consultation with DG MOVE and the EU Agency for Railways, establishes the Technical Standards and Conformance Working Group. Identify and recruit lead standards engineer/chair, recruit 2–3 OSDM experts, carrier IT representatives, distributor technical leads, payment-systems specialist, and accessibility expert. Define sub-groups: OSDM/API, data-layer, clearing/settlement, ticket format, passenger rights/accessibility, GDPR/compliance.

**Responsible Body/Role:** Programme Director (PMO Standards Lead, with input from EU Agency for Railways)

**Suggested Timeframe:** Months 1–2 (2026-11-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Technical Working Group Charter (scope, sub-groups, decision rules)
- Working-Group Membership List (confirmed representatives)
- Sub-group Assignments and Lead Identification
- First Monthly Meeting Schedule (starting Month 2 = 2026-12-08)

**Dependencies:**

- PMO staffing underway (Standards Lead identified)
- Steering Committee endorsement of working-group charter
- Stakeholder stakeholder outreach to identify representatives

### 7. Standards Working Group, in collaboration with legal counsel and the EU Agency for Railways, conducts a gap analysis comparing the Commission's proposed Regulation (May 2026) to OSDM standards and legacy-carrier IT capabilities. Identify areas where standards development can proceed immediately ('shadow work') versus areas dependent on final Regulation text. Publish findings by Month 3 (2027-01-08).

**Responsible Body/Role:** Technical Standards and Conformance Working Group (with PMO support)

**Suggested Timeframe:** Months 1–3 (2026-11-08 to 2027-01-08)

**Key Outputs/Deliverables:**

- Gap Analysis Report (Regulation vs. OSDM, standards gaps, legacy-IT impact)
- Pre-Work Scope Definition (standards work that can proceed before adoption)
- Regulatory Tracking Dashboard (timeline to adoption, potential amendments)

**Dependencies:**

- Working Group formally established and meeting
- Access to Regulation proposal text and parliamentary tracking
- Input from carriers on IT capabilities and timelines

### 8. Programme Director, in collaboration with the Commission (DG MOVE, DG COMP) and the EU Agency for Railways, drafts a Written Delegation of Authority to the independent arbitration panel. Specify: binding decision scope (technical standards only), time limits (60-day ruling cycle, 14-day compliance deadline), panel authority, escalation procedures to the Commission if non-compliance occurs. Secure written agreement from the Commission and Council by Month 2 (2026-12-08).

**Responsible Body/Role:** Programme Director (with Legal Counsel and DG MOVE)

**Suggested Timeframe:** Months 0–2 (2026-10-08 to 2026-12-08) (target Month 1.5 = 2026-11-23)

**Key Outputs/Deliverables:**

- Draft Written Delegation of Authority (scope, decision rights, time limits, escalation)
- Commission and Council Signed Endorsement
- Arbitration Panel Operating Procedures (conflict of interest, confidentiality, ruling publication)

**Dependencies:**

- Project Sponsor authorization to negotiate with Commission/Council
- Legal counsel input on delegation authority under EU law
- Initial arbitration-panel charter draft

### 9. Programme Director recruits and appoints the independent Arbitration Panel members (8–12 FTE: chair, OSDM/API experts, data-architect specialist, payment-systems expert, accessibility expert, legal/competition specialist, regulator representative, and secretary). Ensure all members sign conflict-of-interest and confidentiality agreements. Publish panel governance framework and dispute-submission procedures.

**Responsible Body/Role:** Programme Director (with advice from DG MOVE and EU Agency for Railways)

**Suggested Timeframe:** Months 1–2 (2026-11-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Arbitration Panel Member Appointment Confirmations (all members signed)
- Conflict-of-Interest and Confidentiality Agreements (signed by all members)
- Panel Governance Charter (terms of office, decision protocols, tie-breaking rules)
- Dispute-Submission Procedures (written guidance for working groups and Steering Committee)

**Dependencies:**

- Written Delegation of Authority secured
- Identified pool of potential panel members (external experts, academics, EU Agency for Railways)
- Panel budget authorized (estimated EUR 6M over 5 years)

### 10. Programme Director convenes the first Arbitration Panel meeting. Confirm panel operating procedures, publish the dispute-submission process, and establish a 30-day readiness review so disputes can be received by Month 3 (2027-01-08).

**Responsible Body/Role:** Arbitration Panel (led by Chair, with PMO support)

**Suggested Timeframe:** Within 3 weeks of all members appointed (Month 2.5 = 2026-12-23)

**Key Outputs/Deliverables:**

- Arbitration Panel Kick-off Meeting Minutes
- Confirmed Operating Procedures and Meeting Schedule
- Published Dispute-Submission Guidelines and Timeline
- Panel Secretary Coordination Contact Information (PMO-accessible)

**Dependencies:**

- All panel members appointed and onboarded
- Written Delegation of Authority finalized
- Panel office/logistics arranged

### 11. Programme Director, working with CER (Confederation of European Railway Operators) and major carriers (Deutsche Bahn, SNCF, Trenitalia, Renfe, ÖBB, NS, SJ, SNCB), drafts a Carrier Commitment Protocol. Define binding commitments: carriers above EUR 50M cross-border revenue commit to API integration by Month 30 (2029-04-08); acceptance of arbitration outcomes; penalties for non-compliance (0.5–1% of quarterly through-ticket revenue in escrow). Distribute for signature by Month 3 (2027-01-08).

**Responsible Body/Role:** Programme Director (PMO) and Project Sponsor (DG MOVE) (with input from CER)

**Suggested Timeframe:** Months 1–3 (2026-11-08 to 2027-01-08)

**Key Outputs/Deliverables:**

- Draft Carrier Commitment Protocol (scope, timelines, penalties)
- Carrier Commitment Letters (signed by each carrier above EUR 50M threshold)
- Signed Escrow Arrangement (with a neutral financial agent holding penalty reserves)
- Carrier Engagement Roadmap (monthly roundtables starting Month 2 = 2026-12-08)

**Dependencies:**

- Programme scope and timeline finalized
- Identified threshold carriers (estimated 8–12 major carriers above EUR 50M)
- Legal counsel guidance on binding commitment enforceability

### 12. Programme Director establishes the Member-State Regulator Coordination Committee and Capacity Building Programme. Conduct a regulator capacity audit (Month 1–2 = 2026-11-08 to 2026-12-08) identifying gaps in each member state. Elect a committee chair (strong-capacity regulator, e.g., Germany, Netherlands) and deputy chair (weak-capacity regulator). Define lead-authority framework for cross-border disputes. Initiate bilateral twinning partnerships.

**Responsible Body/Role:** Programme Director (with EU Agency for Railways and DG MOVE)

**Suggested Timeframe:** Months 1–3 (2026-11-08 to 2027-01-08)

**Key Outputs/Deliverables:**

- Regulator Capacity Audit Report (member-state gaps, resource needs, training priorities)
- Standing Regulators Committee Charter (membership, chair, decision procedures)
- Lead-Authority Framework Document (cross-border dispute resolution procedures)
- Twinning Partnership Agreements (2–3 pilot pairings signed)
- Capacity-Building Programme Outline (training schedule, budget allocation, curriculum)

**Dependencies:**

- Identified regulator representatives in each member state
- Funding authorization for capacity building (EUR 10–15M over 5 years)
- EU Agency for Railways endorsement and technical secretariat commitment

### 13. Member-State Regulator Coordination Committee, led by the newly elected chair, convenes its first meeting. Confirm committee governance, approve lead-authority procedures, and authorize the first quarter of twinning and training activities (Months 2–4 = 2026-12-08 to 2027-02-08). Establish a monthly call schedule between the chair, deputy, PMO and the EU Agency for Railways.

**Responsible Body/Role:** Member-State Regulator Coordination Committee (led by Chair)

**Suggested Timeframe:** Within 2 weeks of chair appointment (Month 2 = 2026-12-08)

**Key Outputs/Deliverables:**

- First Standing Regulators Committee Meeting Minutes
- Approved Lead-Authority Procedures Document
- Twinning Partnership Launch Authorization (budget release)
- Regulator Training Schedule (Months 2–12 = 2026-12-08 to 2027-10-08)
- Monthly Call Schedule (chair, deputy, PMO, EU Agency for Railways)

**Dependencies:**

- Committee chair and deputy appointed
- Capacity audit completed
- Twinning partnerships identified
- Budget allocation confirmed

### 14. Programme Director recruits and establishes the Consumer Product and Support Team (20–30 FTE: product director, product manager, engineering lead, backend/frontend engineers, UX designers, localization specialist, support-centre manager, support agents, data analyst). Begin user research and persona development (Months 2–4 = 2026-12-08 to 2027-02-08) for the through-ticket booking app.

**Responsible Body/Role:** Programme Director (PMO) / Consumer Product Director (once hired)

**Suggested Timeframe:** Months 1–2 (2026-11-08 to 2026-12-08) (staffing completion)

**Key Outputs/Deliverables:**

- Consumer Product Team Organization Chart
- Product Director and Core Team Member Hiring Confirmations
- User Research Plan (persona development, accessibility requirements)
- App Feature Roadmap (MVP scope, launch targets, Phase 1 corridors)
- Support-Centre Infrastructure Plan (24/7 multilingual coverage, escalation procedures)

**Dependencies:**

- Programme budget authorization (EUR 150M for consumer rollout)
- App development and support budget allocated and committed
- Accessibility and consumer-advocacy input on requirements

### 15. Consumer Product Director convenes the first product team meeting. Review user-research findings, finalize MVP scope (search, booking, refund flow, accessibility requests), and establish weekly development rituals (product prioritization, sprint planning, support-centre operational reviews). Define pilot-testing timeline (Month 9 = 2027-07-08 for one corridor).

**Responsible Body/Role:** Consumer Product and Support Team (led by Product Director)

**Suggested Timeframe:** Within 2 weeks of core team staffing (Month 2.5 = 2026-12-23)

**Key Outputs/Deliverables:**

- First Product Team Kick-off Meeting Minutes
- MVP Specification Document (features, user flows, acceptance criteria)
- Development Sprint Schedule (Months 2–15 = 2026-12-08 to 2028-01-08)
- Pilot-Testing Plan (one corridor, 100–500 users, Month 9 = 2027-07-08)
- Support-Centre Operational Readiness Timeline

**Dependencies:**

- Consumer Product Team fully staffed
- User research completed
- Carrier and distributor requirements input
- Technology stack and cloud infrastructure decisions made

### 16. Programme Director, with DG MOVE and legal counsel, commissions a comprehensive Data Protection Impact Assessment (DPIA) and initiates early consultation with the European Data Protection Board (EDPB) and national data protection authorities. Define minimum-necessary PII per transaction (booking, payment, fulfillment, refund, accessibility). Seek DPA consensus on Standard Contractual Clauses (SCCs) and data residency by Month 4 (2027-02-08).

**Responsible Body/Role:** Programme Director (with Data Protection Specialist and Legal Counsel)

**Suggested Timeframe:** Months 0–2 (2026-10-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- DPIA Commissioning Decision (external consultant or internal specialist)
- Draft DPIA Report (PII flows, risks, mitigation)
- Letter to EDPB Requesting Early Consultation (scope of data sharing, consent regimes)
- Draft Data-Governance Framework (PII minimization, SCCs, consent protocols, deletion rules)
- National DPA Engagement Plan (twinning, early feedback, national-specific requirements)

**Dependencies:**

- Project authorization
- Budget for DPIA consultant (if external)
- Access to EDPB and national DPA contact points
- Legal counsel skilled in GDPR and cross-border data flows

### 17. Programme Director recruits and establishes the Ethics, Compliance and Accessibility Oversight Committee. Appoint independent ethics and accessibility experts as chair and deputy chair. Recruit members: GDPR specialist, accessibility expert, ethics/compliance officer (programme staff), finance auditor, BEUC/consumer-advocacy representative. Draft ethics code and conflict-of-interest policy. Publish whistleblower-protection procedures.

**Responsible Body/Role:** Programme Director (with DG MOVE and Ethics Council if available)

**Suggested Timeframe:** Months 0–1 (2026-10-08 to 2026-11-08)

**Key Outputs/Deliverables:**

- Ethics Committee Charter (scope, membership, authority)
- Chair and Deputy Chair Appointment Confirmations
- Ethics Code and Conflict-of-Interest Policy (signed by all programme staff and stakeholders)
- Whistleblower Channel Setup (confidential reporting, retaliation-protection assurance)
- Accessibility Requirements Framework (aligned with WCAG 2.1 AA, 24-hour assistance confirmation, etc.)
- Compliance Checklist Template (for carriers, distributors, payment institutions)

**Dependencies:**

- Identified independent ethics and accessibility experts
- Budget for committee operations and compliance activities (estimated EUR 10M in the governance/compliance line)
- Accessibility Working Group input on requirements

### 18. Ethics, Compliance and Accessibility Oversight Committee convenes its first meeting. Review the DPIA (in draft), confirm accessibility requirements, and approve the ethics code. Require all programme staff and Steering Committee members to sign the ethics code and conflict-of-interest declaration by Month 2 (2026-12-08). Establish quarterly compliance-review procedures.

**Responsible Body/Role:** Ethics, Compliance and Accessibility Oversight Committee (led by Chair)

**Suggested Timeframe:** Within 3 weeks of committee appointment (Month 1.5 = 2026-11-23)

**Key Outputs/Deliverables:**

- First Committee Meeting Minutes
- Reviewed and Endorsed Accessibility Requirements
- DPIA Feedback and Next-Steps Assignment
- Signed Ethics Code and Conflict-of-Interest Forms (all staff and SC members)
- Quarterly Compliance-Review Schedule (starting Month 6 = 2027-04-08)

**Dependencies:**

- Committee chair and deputy appointed
- DPIA report available for review (draft acceptable)
- Accessibility Working Group input on requirements finalized
- Ethics code drafted

### 19. Programme Director initiates formal carrier and distributor engagement. Establish Carrier Advisory Roundtables (quarterly starting Month 2 = 2026-12-08) with major carriers, CER and smaller-operator representatives. Establish Distributor Advisory Council (quarterly starting Month 2 = 2026-12-08) with Trainline, Omio, smaller platforms and the public reference distributor team. Share the programme roadmap, discuss IT capabilities and integration timelines, and address co-funding and commercial incentive questions.

**Responsible Body/Role:** Programme Director (PMO Stakeholder Lead, with Carrier Onboarding Lead)

**Suggested Timeframe:** Months 1–2 (2026-11-08 to 2026-12-08) (initiation and first meeting scheduling)

**Key Outputs/Deliverables:**

- Carrier Advisory Roundtable Agenda and Attendee Confirmation (first meeting Month 2 = 2026-12-08)
- Distributor Advisory Council Charter and Membership Confirmation
- Engagement Communication (programme roadmap, milestones, co-funding framework)
- Notes and Action Items from First Roundtable/Council Meetings
- Carrier IT Capability Assessment Template (to be completed Month 3–4 = 2027-01-08 to 2027-02-08)

**Dependencies:**

- Programme roadmap and timeline finalized
- Co-funding framework defined and approved by Steering Committee
- Identified carrier and distributor representatives
- Commitment protocol drafted and ready for discussion

### 20. Distributor Advisory Council, in collaboration with the PMO, begins defining distributor commercial incentives (co-marketing funds, early API access, fee waivers). Negotiate margin-support measures (estimated EUR 5–10M over 24 months) and commitment letters from Trainline, Omio and other platforms specifying integration timelines (API ready by Month 18 = 2028-04-08).

**Responsible Body/Role:** Distributor Advisory Council (chair or PMO liaison)

**Suggested Timeframe:** Months 2–4 (2026-12-08 to 2027-02-08)

**Key Outputs/Deliverables:**

- Distributor Incentive Framework (co-marketing, fee waivers, early access terms)
- Distributor Commitment Letter Template and Signed Letters (from major platforms)
- Margin-Support Budget Allocation (breakdown of EUR 5–10M co-marketing)
- Distributor Integration Milestone Tracking (API readiness gates by Month 18 = 2028-04-08)

**Dependencies:**

- Distributor Advisory Council established
- Commercial terms and co-funding framework approved by Steering Committee
- Distributor representatives committed to engagement

### 21. Programme Director commissions a detailed activity-based cost model estimating: carrier IT integration costs by carrier size and legacy-system status; hub operating costs per region; public reference distributor annual operating costs; payment-institution transaction fees. Define budget burn forecast, trigger points for contingency activation (monthly spend exceeding 115% of pro-rata forecast), and decision gates (Months 12 and 24 = 2027-10-08, 2028-10-08).

**Responsible Body/Role:** Programme Director (Finance Officer, PMO)

**Suggested Timeframe:** Months 0–2 (2026-10-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Activity-Based Cost Model (detailed breakdown by component: standards, hubs, distributor, capacity building, etc.)
- Five-Year Budget Burn Forecast (monthly and annual)
- Contingency-Activation Trigger Framework (Tier 1, 2, 3 decision points at 115%, 120%+, 125%+ spend)
- Mid-Course Review Gates (Month 12 and 24 = 2027-10-08, 2028-10-08) with decision authority delegation

**Dependencies:**

- Carrier cost estimates from IT capability assessments (to be collected Month 3–4 = 2027-01-08 to 2027-02-08)
- Hub operator quotes and operational cost estimates
- Payment-institution fee benchmarking
- Steering Committee approval of budget-tracking procedures

### 22. Programme Director establishes the project-tracking and risk-management office function within the PMO. Implement a shared project-management tool (Asana, Monday.com, or equivalent) with real-time visibility to all stakeholders. Set up weekly PMO status dashboards covering: milestones, budget burn, carrier readiness, working-group progress, risks and issues, escalations. Publish internal risk register with mitigation owners and tracking.

**Responsible Body/Role:** Programme Director (with PMO Operations Lead and Risk Officer)

**Suggested Timeframe:** Months 0–1 (2026-10-08 to 2026-11-08)

**Key Outputs/Deliverables:**

- Project-Management Tool Configuration and Stakeholder Access Setup
- Weekly Status-Dashboard Template (milestones, budget, risks, decisions)
- Risk Register Template and Initial Risk Identification (baseline ~20 key risks)
- Risk-Escalation Procedures (severity levels, escalation timeframes)
- Monthly PMO Deep-Dive Agenda (budget, risk, milestone, stakeholder reviews)

**Dependencies:**

- PMO core staff hired (at least Operations Lead and Risk Officer)
- Project-management tool procurement authorized and funded
- Risk taxonomy and escalation authority defined

### 23. Programme Director, with DG MOVE, conducts Parliamentary and regulatory tracking. Establish direct liaison with European Parliament TRAN (Transport) and IMCO (Internal Market) committees and key member-state transport ministers. Track Regulation adoption progress weekly (starting Month 0 = 2026-10-08). Set a hard gate: if adoption has not occurred by Month 10 (2027-08-08), pause carrier onboarding commitments and conduct a critical-path review.

**Responsible Body/Role:** Programme Director (Communication Lead, with DG MOVE)

**Suggested Timeframe:** Months 0–2 (2026-10-08 to 2026-12-08) (initial setup and liaison)

**Key Outputs/Deliverables:**

- Regulatory Tracking Dashboard (weekly updates on Regulation adoption progress)
- Parliamentary Liaison Contacts and Meeting Schedule
- Member-State Engagement Plan (key minister briefs, coordination calls)
- Shadow Standards Roadmap (pre-work on OSDM, access terms, settlement architecture, starting Month 0 = 2026-10-08 under 'without-prejudice' frame)
- Contingency Activation Procedure (if adoption slips past Month 9 = 2027-07-08)

**Dependencies:**

- DG MOVE authorization to engage Parliament and member states
- Access to Regulation tracking (e.g., from Parliament Legislative Observatory)
- Identified stakeholder contacts in Parliament and member-state governments

### 24. Programme Director launches market sounding for accredited payment institutions. Issue a Request for Information (RFI) outlining accreditation criteria: multi-currency support (EUR, DKK, SEK, CHF, PLN, CZK, HUF, BGN, RON), settlement cycle <48 hours, refund processing <10 days, SLAs (99.95% uptime), financial stability (PSD2 license required). Target: identify 4–6 potential providers by Month 1 (2026-11-08), issue formal call for applications by Month 2 (2026-12-08).

**Responsible Body/Role:** Programme Director (Finance Officer, PMO) with DG MOVE and ECB guidance

**Suggested Timeframe:** Months 0–2 (2026-10-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Request for Information (RFI) to Payment-Institution Market
- Accreditation Criteria Document (technical, regulatory, financial requirements)
- Call for Applicants (published Month 2 = 2026-12-08, deadline Month 6 = 2027-04-08)
- Accreditation Decision Timeline (decision by Month 8 = 2027-06-08, minimum 2 providers operational by Month 12 = 2027-10-08)
- Fee Negotiation Framework (cap 0.3–0.5% per transaction; subsidy covering 50–70% in Months 0–24 = 2026-10-08 to 2028-10-08)

**Dependencies:**

- Settlement and clearing architecture design completed (defines requirements)
- ECB and payment-regulator input on licensing and compliance
- Budget for accreditation and payment-subsidy (EUR 120M in the clearing line)

### 25. Programme Director, in consultation with CER, smaller-carrier representatives and hub operators, launches hub-operator procurement. Issue a Request for Proposal (RFP) for 4 regional hubs (Paris–Brussels–Amsterdam–Köln, Wien–München–Zurich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin), each to serve 3–5 smaller carriers with legacy booking systems. Specify hub responsibilities: OSDM-compliant API translation, dual-run testing, SLAs (99.9% uptime, <2-hour incident recovery, <2-second latency). Budget per hub: EUR 6M over 5 years; total hub budget EUR 24M launch + EUR 20M reserved for two TEN-T hubs (decisions at Month 30 = 2029-04-08).

**Responsible Body/Role:** Programme Director (Hub Coordination Lead, PMO) with CER

**Suggested Timeframe:** Months 0–2 (2026-10-08 to 2026-12-08) (RFP prep and issue)

**Key Outputs/Deliverables:**

- Hub-Operator RFP (technical requirements, SLAs, cost structure, sunset provisions)
- Hub-Eligibility Criteria (cross-border revenue <EUR 50M, or booking-system age >10 years, or IT staff <10 FTE)
- List of Identified Hub-Eligible Carriers (estimated 12–18 carriers)
- Hub-Procurement Timeline (deadline Month 3 = 2027-01-08, contracts signed by Month 3 = 2027-01-08, operational Month 9 = 2027-07-08)
- Hub-Performance Dashboard Template (uptime, latency, booking-failure rate, mapping-error logs)

**Dependencies:**

- Data-layer architecture design finalized (defines hub responsibilities)
- Smaller-carrier engagement and buy-in (they will use the hubs)
- Hub operator market exists (procured vendors or consortia of carriers)
- Budget authorized (EUR 44M for hubs in the carrier co-funding line)

### 26. Programme Director publishes a comprehensive Stakeholder Engagement and Communication Strategy. Define tiered engagement: monthly all-hands forum (all stakeholders), Steering Committee (quarterly), working groups (monthly/bi-weekly), carrier and distributor advisory councils (quarterly), regulator coordination (monthly). Publish a programme roadmap, FAQ document, and quarterly stakeholder newsletters (starting Month 3 = 2027-01-08). Establish a Community Liaison Officer (1 FTE) to manage regional outreach and transport-union engagement.

**Responsible Body/Role:** Programme Director (Communication Lead, PMO)

**Suggested Timeframe:** Months 1–2 (2026-11-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Stakeholder Engagement Strategy Document
- Communication Plan (channels, cadence, audience segmentation)
- Programme Roadmap (public version, timeline, milestones, funding allocation)
- FAQ and Frequently-Escalated-Questions Document
- Community Liaison Officer Hiring Confirmation
- First Quarterly Stakeholder Newsletter (Month 3 = 2027-01-08)
- Transport-Union Engagement Plan and First Meeting Schedule

**Dependencies:**

- Programme scope and roadmap finalized
- Steering Committee guidance on communication tone and transparency
- Identified stakeholder constituencies and communication preferences
- Budget for communication (estimated EUR 2–3M over 5 years)

### 27. Steering Committee, at its second meeting (Month 3 = 2027-01-08), formally approves the binding standards development pathway and gates. Confirm the Month 18 (2028-04-08) binding-standards deadline, approve the working-group charter and sub-group assignments, and authorize commencement of shadow standards work on OSDM, data-layer design, clearing/settlement, and ticket formats.

**Responsible Body/Role:** Programme Steering Committee

**Suggested Timeframe:** Month 3 (2027-01-08) (quarterly SC meeting)

**Key Outputs/Deliverables:**

- Approved Technical Standards Development Pathway
- Standards Workstream Charter and Sub-Group Assignments (finalized)
- Month 18 (2028-04-08) Binding-Standards Gate Confirmed
- Shadow-Work Scope Definition and Approved Pre-Work Roadmap
- Standards Development Budget Allocation (EUR 280M confirmed)

**Dependencies:**

- Gap analysis and regulatory tracking completed
- Standards working group established and meeting
- Regulation adoption tracking (if adopted by this point, accelerate full standards work; if not, continue shadow work)

### 28. Steering Committee, in consultation with the arbitration panel and technical working groups, formalizes the dispute-resolution protocol for the standards-development phase. Define how contested technical issues are escalated from working groups to the arbitration panel, decision timelines (60 days to ruling), and compliance consequences. Publish this protocol by Month 3 (2027-01-08) so all working groups use it.

**Responsible Body/Role:** Programme Steering Committee (with Arbitration Panel Chair and Standards Lead)

**Suggested Timeframe:** Month 3 (2027-01-08)

**Key Outputs/Deliverables:**

- Approved Dispute-Escalation Protocol (working group -> arbitration panel -> Steering Committee)
- Decision Timelines and Escalation Triggers (published and widely communicated)
- Arbitration Panel Readiness Confirmation (panel can receive disputes by Month 3 = 2027-01-08)

**Dependencies:**

- Arbitration panel fully appointed and trained
- Technical working groups established and operational
- Steering Committee authority over technical disputes confirmed

### 29. Programme Director initiates the Measurement, Baseline and Attribution programme. Hire an independent evaluation firm (Month 3 = 2027-01-08) to design a counterfactual evaluation framework. Commission a baseline survey (Month 0–2 = 2026-10-08 to 2026-12-08, reporting Month 6 = 2027-04-08) asking carriers, distributors and airports for current cross-border sales volumes, complaint metrics and modal-split estimates. Define the 'through-ticket' operational definition (single booking reference + single payment + continuity-of-journey rights) by Month 2 (2026-12-08).

**Responsible Body/Role:** Programme Director (Measurement and Evaluation Lead, PMO)

**Suggested Timeframe:** Months 0–3 (2026-10-08 to 2027-01-08)

**Key Outputs/Deliverables:**

- Independent Evaluator Contract Signed (Month 3 = 2027-01-08)
- Through-Ticket Definition (operationalized, approved by Steering Committee)
- Baseline Survey Design and Respondent List (Month 0–2 = 2026-10-08 to 2026-12-08)
- Baseline Survey Report (Month 6 = 2027-04-08, covering current cross-border volumes, complaints, modal split)
- Counterfactual Evaluation Framework (comparison routes, confounding factors, attribution methodology)
- Quarterly Measurement Dashboard Template (to track 40% through-ticket target, complaints halved, modal shift)

**Dependencies:**

- Measurement budget authorized (EUR 5–10M over 5 years)
- Identification of baseline data sources (carriers, distributors, EUROSTAT, national regulators)
- Steering Committee endorsement of measurement approach

### 30. Steering Committee formally approves the Smaller-Carrier Support Programme (SCSP). Allocate EUR 100–150M in co-funding grants to 12–18 carriers with legacy booking systems or limited IT capacity. Define co-funding tiers (EUR 2–8M per SME, up to EUR 15M per medium-sized operator) conditional on reaching readiness milestones (Month 12, 18, 24, 30 = 2027-10-08 to 2029-04-08). Authorize the PMO to recruit 5 regional coordinators (Budapest, Warsaw, Sofia, Bucharest) to provide on-site mentoring.

**Responsible Body/Role:** Programme Steering Committee (with Finance Officer and Smaller-Carrier representative)

**Suggested Timeframe:** Month 6 (2027-04-08) (quarterly SC meeting)

**Key Outputs/Deliverables:**

- Approved Smaller-Carrier Support Programme Charter
- Co-Funding Allocation Framework (eligible carriers, grant amounts, conditions)
- Regional Coordinator Hiring Plan and Budget (EUR 5M over 5 years for salaries, travel, on-site support)
- Co-Funding Disbursement Schedule (tranches tied to readiness milestones)
- Peer-Mentoring Network Launch (pairing large carriers with small carriers, Month 6–9 = 2027-04-08 to 2027-07-08)

**Dependencies:**

- Carrier IT capability assessments completed (Month 3–4 = 2027-01-08 to 2027-02-08)
- Identified hub-eligible and smaller-carrier representatives
- Budget allocated to carrier co-funding (EUR 290M in the carrier-cofunding line)

### 31. Programme Director, working with the Technical Standards Working Group, launches the EU Agency for Railways market engagement on OSDM and conformance testing. Request that the EU Agency for Railways issue a call for independent conformance testing laboratories (RFP, Month 2 = 2026-12-08; deadline Month 6 = 2027-04-08; contracts signed by Month 8 = 2027-06-08). Secure at least 2–3 labs across different European regions (EU-West, EU-Central, EU-East) to provide testing capacity starting Month 9 (2027-07-08). SLAs: turn around carrier tests within 6 weeks of booking.

**Responsible Body/Role:** Programme Director (with EU Agency for Railways and Standards Lead)

**Suggested Timeframe:** Months 2–3 (2026-12-08 to 2027-01-08) (RFP preparation and issue)

**Key Outputs/Deliverables:**

- EU Agency for Railways Conformance Testing RFP (criteria: OSDM expertise, testing capacity, geographic reach, SLA commitments)
- Call for Testing Laboratory Applicants (Month 2 = 2026-12-08, deadline Month 6 = 2027-04-08)
- Selected Testing Laboratory Contracts (signed by Month 8 = 2027-06-08, ~EUR 30–50M over 5 years)
- Conformance Testing Procedure and Checklist (OSDM compliance, accessibility, GDPR, data quality, safety, financial stability)
- Testing Queue Management Process (allocate slots to carriers based on readiness, priority corridors first)

**Dependencies:**

- Standards working group progress on OSDM specifications (sufficient detail to define testing criteria by Month 6–9 = 2027-04-08 to 2027-07-08)
- EU Agency for Railways commitment to procurement and oversight
- Testing laboratory market exists and has capacity

### 32. Steering Committee, at Month 6 (2027-04-08), conducts a mid-programme review of governance setup. Assess: programme governance bodies formally established (Steering Committee, PMO, working groups, arbitration panel, regulators, consumer team, ethics committee), stakeholder engagement underway, risk register active, budget tracking operational. Confirm critical-path milestones (Regulation adoption tracking, standards pre-work, carrier commitment letters, accredited payment-institution timeline). Address any governance gaps or conflicts discovered in Months 0–6 (2026-10-08 to 2027-04-08).

**Responsible Body/Role:** Programme Steering Committee

**Suggested Timeframe:** Month 6 (2027-04-08) (mid-point of governance-setup phase)

**Key Outputs/Deliverables:**

- Governance Setup Review Report (status of each body, challenges, remediation actions)
- Governance Maturity Assessment (scale: not established, established but not operational, operational with issues, fully operational)
- Critical-Path Status Summary (standards pre-work, carrier engagement, accreditation, hub procurement, measurement baseline)
- Steering Committee Process Improvements (if any governance issues detected, approve corrective actions)
- Decision: Proceed to full standards development (Month 6 = 2027-04-08) or adjust trajectory based on findings

**Dependencies:**

- All governance bodies have been established and have held at least one meeting
- Progress reports available from working groups, PMO, arbitration panel, regulators, consumer team
- Risk register with at least 15–20 key risks identified and mitigation owners assigned

### 33. Steering Committee formally approves the commencement of binding standards development (Month 6–9 = 2027-04-08 to 2027-07-08), conditional on the Regulation being adopted by Month 9 (2027-07-08) or the shadow work being sufficiently advanced to proceed. Confirm the Month 18 (2028-04-08) binding-standards gate and authorize escalation to the arbitration panel if working-group consensus cannot be achieved on any technical issue by Month 12 (2027-10-08).

**Responsible Body/Role:** Programme Steering Committee

**Suggested Timeframe:** Month 9 (2027-07-08)

**Key Outputs/Deliverables:**

- Approved Full Standards-Development Roadmap (Month 6–18 = 2027-04-08 to 2028-04-08)
- Regulation Adoption Status (adopted, or shadow work sufficient to proceed; if not, contingency timeline)
- Sub-Group Work Schedules and Deliverables (OSDM, data layer, clearing, ticket format, passenger rights, accessibility, GDPR)
- Escalation Trigger: If any sub-group cannot reach consensus by Month 12 (2027-10-08), dispute escalates to arbitration panel by Month 15 (2028-01-08) for Month 18 (2028-04-08) finalization
- Public Communication Plan (publish draft standards by Month 15 = 2028-01-08 for 4-week stakeholder comment period)

**Dependencies:**

- Regulation adoption (or clear indication of final text by Month 9 = 2027-07-08)
- Shadow standards work substantially complete
- Technical working groups and arbitration panel operational
- Carrier and distributor feedback on early standards drafts (incorporated into working group work)

### 34. Steering Committee formally approves the Technology Infrastructure Procurement plan. Procure a European-wide API hosting and caching infrastructure (Month 2–6 = 2026-12-08 to 2027-04-08, contracts signed by Month 8 = 2027-06-08) to support the shared data layer. Specify: redundancy across ≥3 data centres per region (EU-West, EU-Central, EU-East), automatic failover (<30 seconds), SLAs (API latency p95 <2 seconds, uptime 99.95%, throughput ≥500 req/s per corridor). Establish 24/7 API operations centre (Month 6 = 2027-04-08) with escalation to carriers within 15 minutes of any critical incident.

**Responsible Body/Role:** Programme Steering Committee (with Technical Architect and Data-Layer Lead)

**Suggested Timeframe:** Month 6 (2027-04-08) (SC approval)

**Key Outputs/Deliverables:**

- Technology Infrastructure RFP (hosting, caching, redundancy, SLA requirements)
- Infrastructure Provider Selection (signed contracts by Month 8 = 2027-06-08)
- API Operations Centre Setup Plan (location, staffing, escalation protocols)
- Performance Monitoring Dashboard (latency, uptime, throughput, incident response)
- Carrier Infrastructure Assessment and Co-Funding Plan (identify carriers unable to meet API SLAs; co-fund upgrades)
- Load-Testing and Chaos-Engineering Plan (quarterly exercises starting Month 9 = 2027-07-08)

**Dependencies:**

- Data-layer architecture finalized by working group
- Technology budget authorized (EUR 60M in the data-layer line)
- Carrier IT capability assessments completed (Month 3–4 = 2027-01-08 to 2027-02-08)

### 35. Steering Committee formally approves the Consumer Product Pilot Plan (Month 9 = 2027-07-08). Authorize the Consumer Product Team to deploy an MVP of the through-ticket booking app to one priority corridor (e.g., Paris–Brussels–Amsterdam) with 100–500 test users (Month 9 = 2027-07-08). Gather user feedback and iterate (Months 10–12 = 2027-08-08 to 2027-10-08). Set a go/no-go gate for full development (Month 12 = 2027-10-08): if user satisfaction is below 3.8/5 or critical usability issues are uncovered, conduct a 4-week redesign cycle before proceeding to full build-out.

**Responsible Body/Role:** Programme Steering Committee (with Consumer Product Director)

**Suggested Timeframe:** Month 9 (2027-07-08)

**Key Outputs/Deliverables:**

- Approved Consumer Product Pilot Plan (scope, timeline, success criteria)
- MVP Deployment to Pilot Corridor (Month 9 = 2027-07-08)
- User Testing Report and Feedback Summary (Months 9–12 = 2027-07-08 to 2027-10-08)
- Go/No-Go Decision Gate (Month 12 = 2027-10-08)
- Approved Full-Build Roadmap (Months 12–15 = 2027-10-08 to 2028-01-08 for production app, localization, support-centre setup)

**Dependencies:**

- Consumer Product Team fully staffed and operational
- MVP development completed (Month 9 = 2027-07-08)
- Carrier and distributor support for pilot (willing to integrate with pilot app for testing)
- Access to real passenger data (anonymized) or test-user pool

### 36. Member-State Regulator Coordination Committee convenes at Month 9 (2027-07-08) to review twinning and capacity-building progress. Assess: training completion rates, regulator readiness to enforce access and passenger-rights rules, cross-border dispute procedures functioning. Finalize the lead-authority framework and publish enforcement guidance for all member states. Confirm that regulators are equipped to conduct conformance audits of carriers starting Month 18 (2028-04-08).

**Responsible Body/Role:** Member-State Regulator Coordination Committee

**Suggested Timeframe:** Month 9 (2027-07-08)

**Key Outputs/Deliverables:**

- Twinning and Capacity-Building Progress Report
- Regulator Readiness Assessment (by member state, identifying any ongoing gaps)
- Finalized Lead-Authority Procedures (published and mandated for cross-border disputes)
- Enforcement Guidance Document (access-compliance audit procedures, complaint handling, passenger-rights enforcement)
- Conformance Auditor Training Plan (certify regulators to conduct OSDM, accessibility, GDPR audits of carriers starting Month 18 = 2028-04-08)

**Dependencies:**

- Twinning partnerships operational and funded (Months 2–9 = 2026-12-08 to 2027-07-08)
- Regulator capacity audit identified specific training needs (Month 1–2 = 2026-11-08 to 2026-12-08)
- EU Agency for Railways providing technical secretariat support

### 37. Steering Committee holds its Month 12 (2027-10-08) mid-course budget and milestone review. Assess: actual spending vs. forecast (trigger Tier 1, 2, or 3 contingency decisions if overrun exceeds 115%); Regulation adoption status (confirm adopted or update shadow-work schedule); standards-development progress (confirm on track for Month 18 = 2028-04-08 deadline); carrier commitment-letter status (target: 90%+ of major carriers signed); accreditation progress (target: 2+ payment providers selected or finalists identified); hub procurement (target: contracts signed by Month 12 = 2027-10-08 or imminent); measurement baseline validation (Month 9 = 2027-07-08 baseline confirmed).

**Responsible Body/Role:** Programme Steering Committee

**Suggested Timeframe:** Month 12 (2027-10-08)

**Key Outputs/Deliverables:**

- Budget Mid-Course Review Report (actual vs. forecast, contingency-activation decision)
- Milestone Status Summary (Regulation, standards, carrier engagement, hub procurement, accreditation, measurement)
- Critical-Path Risk Assessment (identify any blockers to Month 18 = 2028-04-08 or Month 30 = 2029-04-08 gates)
- Steering Committee Decision: Proceed on schedule, adjust trajectory, or activate contingency levers
- Revised Programme Roadmap (if any adjustments made)

**Dependencies:**

- Monthly budget reports available (Months 0–12 = 2026-10-08 to 2027-10-08)
- Progress reports from all working groups and external partners
- Measurement baseline finalized (Month 9 = 2027-07-08)
- Risk register updated with emerging issues

### 38. Steering Committee at Month 12 (2027-10-08) formally establishes the Carrier Conformance and Readiness Assessment Process. Define readiness gates for each carrier: API design review (Month 15 = 2028-01-08), test-bed deployment (Month 18 = 2028-04-08), dual-run testing (Months 21–24 = 2028-07-08 to 2028-10-08), pre-production trial (Months 24–27 = 2028-10-08 to 2029-01-08), production go-live (Month 30 = 2029-04-08). Assign conformance testing labs and reserve queue slots. Define go/no-go criteria (passing conformance audit, payment-settlement integration, accessibility confirmation).

**Responsible Body/Role:** Programme Steering Committee (with Carrier Onboarding Lead and Testing Lab Lead)

**Suggested Timeframe:** Month 12 (2027-10-08)

**Key Outputs/Deliverables:**

- Carrier Conformance and Readiness Framework (gates, timeline, criteria)
- Carrier-Specific Readiness Roadmaps (for major carriers and hub-eligible carriers)
- Conformance Testing Schedule (queue allocation by corridor and carrier priority)
- Testing Lab SLA Agreements (turn-around time, quality standards, incident escalation)
- Readiness Dashboard (track each carrier's progress against gates, published monthly starting Month 15 = 2028-01-08)
- Hub and Legacy-Carrier Timeline (dual-run testing Months 15–18 = 2028-01-08 to 2028-04-08; pilot deployment Month 18 = 2028-04-08)

**Dependencies:**

- Conformance testing labs procured and operational
- Standards framework sufficiently defined (working-group consensus or arbitration-panel rulings on OSDM, data-layer design)
- Carrier commitment letters signed (target: 90%+ of major carriers)
- Hub operator contracts signed (target: all 4 hubs by Month 12 = 2027-10-08)

### 39. Technical Standards Working Group delivers the draft binding standards document (Month 15 = 2028-01-08) covering OSDM API specifications, data-layer interfaces, clearing/settlement message formats, ticket format and validation, passenger rights (continuity-of-journey, rerouting, refund), accessibility requirements (24-hour assistance confirmation, accessibility data publishing), and GDPR/compliance rules. Publish for 4-week public stakeholder comment period (Months 15–18 = 2028-01-08 to 2028-04-08).

**Responsible Body/Role:** Technical Standards and Conformance Working Group (led by Standards Lead)

**Suggested Timeframe:** Month 15 (2028-01-08)

**Key Outputs/Deliverables:**

- Draft Binding Standards Document (OSDM, data-layer, clearing, ticket, passenger rights, accessibility, GDPR, ~150–200 pages)
- Implementation Guidance and Worked Examples (for carriers, distributors, hub operators)
- Public Stakeholder Comment Period Launch (Month 15–18 = 2028-01-08 to 2028-04-08)
- Feedback Summary Report (Month 18 = 2028-04-08, incorporating major comments into final document)

**Dependencies:**

- All sub-groups substantially complete their sections (by Month 12–15 = 2027-10-08 to 2028-01-08)
- Arbitration panel has resolved any major technical disputes (via rulings issued by Month 12 = 2027-10-08)
- Regulation adopted (or sufficient clarity on final text)
- Carrier and distributor input integrated (from advisory councils and working groups)

### 40. Steering Committee formally approves the final binding standards document (Month 18 = 2028-04-08). Incorporate feedback from the public comment period (Months 15–18 = 2028-01-08 to 2028-04-08). Once approved, the standards are legally binding for all participating carriers, distributors, payment institutions and member-state regulators. Publish the standards and formally notify all stakeholders of their adoption. Set a 90-day technical transition period (through Month 21 = 2028-07-08) for systems adjustments before full conformance testing begins.

**Responsible Body/Role:** Programme Steering Committee

**Suggested Timeframe:** Month 18 (2028-04-08) (hard milestone)

**Key Outputs/Deliverables:**

- Approved Final Binding Standards Document (signed by Steering Committee Chair and DG MOVE)
- Standards Publication and Stakeholder Notification
- Conformance Checklist (auditable criteria for OSDM, data-layer, clearing, ticket, passenger rights, accessibility, GDPR)
- Technical Transition Plan (Month 18–21 = 2028-04-08 to 2028-07-08, carriers make system adjustments)
- Conformance Testing Commencement Schedule (Month 21 = 2028-07-08 onward)

**Dependencies:**

- Standards working group delivers final draft and incorporates feedback
- Arbitration panel has resolved all outstanding disputes
- Steering Committee consensus or supermajority approval
- Regulation adopted (standards must align with final regulation text)

### 41. Steering Committee and the arbitration panel jointly publish a formal technical compliance and enforcement framework (Month 18 = 2028-04-08). Specify: conformance audit procedures (by designated testing labs), remediation timelines (if non-compliance found), penalties (0.5–1% of quarterly through-ticket revenue per conformance breach, held in escrow), and escalation to national regulators for market-conduct violations (non-discrimination, passenger-rights denial). Confirm the arbitration panel's continued role in resolving interpretation disputes (through Month 30 = 2029-04-08 and beyond).

**Responsible Body/Role:** Programme Steering Committee (jointly with Arbitration Panel Chair)

**Suggested Timeframe:** Month 18 (2028-04-08)

**Key Outputs/Deliverables:**

- Conformance and Enforcement Framework Document
- Audit Procedures and Testing Lab Protocols
- Remediation and Penalty Schedule
- Escalation Procedures (non-compliance to national regulators and Commission)
- Arbitration Panel Continuity Plan (ongoing dispute resolution through Month 30 = 2029-04-08 and beyond)

**Dependencies:**

- Binding standards approved (Month 18 = 2028-04-08)
- Arbitration panel fully operational
- Member-state regulators trained and ready to enforce
- Conformance testing labs operational and equipped to audit

### 42. Consumer Product and Support Team completes and launches the public through-ticket booking app (Month 27 = 2029-01-08) on all four priority corridors (Paris–Brussels–Amsterdam–Köln, Wien–München–Zurich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin). App features: multilingual search and booking (24+ languages), accessibility request and confirmation (24-hour SLA), refund-claim submission (via app or support hotline), real-time disruption notifications, passenger-rights promise display. Simultaneously launch 24/7 multilingual support centre with target <1-hour response for critical issues.

**Responsible Body/Role:** Consumer Product and Support Team (led by Product Director)

**Suggested Timeframe:** Month 27 (2029-01-08)

**Key Outputs/Deliverables:**

- Public Through-Ticket Booking App (production launch, all priority corridors, 24+ languages)
- App Performance Metrics (latency, uptime, search success rate, user satisfaction)
- Multilingual Support Centre Operations (24/7 coverage, response-time SLAs, escalation procedures)
- First Month Support Metrics (complaint volume, resolution time, accessibility requests)
- Post-Launch Roadmap (Phase 2: TEN-T corridor support, starting Month 36 = 2029-10-08)

**Dependencies:**

- App development and localization completed (Months 12–27 = 2027-10-08 to 2029-01-08)
- Carrier and distributor API integration completed (so app can fetch real booking data)
- Payment-integration and refund-processing tested and working
- Support infrastructure (call centre, CRM, knowledge base) operational

### 43. Steering Committee conducts a mid-programme review at Month 24 (2028-10-08). Assess: standards approved (Month 18 = 2028-04-08, completed), carrier conformance readiness (target: 80%+ of major carriers through compliance audit), through-ticket volumes (target baseline: 15% of cross-border journeys, gate for continued co-funding), app development progress (target MVP pilot completed, full app launch on track for Month 27 = 2029-01-08), budget burn (trigger Tier 2/3 decisions if overrun >120%). Confirm critical path to Month 30 (2029-04-08) API mandate (at least 90% of corridor traffic bookable end-to-end).

**Responsible Body/Role:** Programme Steering Committee

**Suggested Timeframe:** Month 24 (2028-10-08) (second mid-course review)

**Key Outputs/Deliverables:**

- Mid-Programme Progress Report (standards, carrier readiness, through-ticket volumes, budget status)
- Through-Ticket Volume Validation (baseline measurement, 15% gate for co-funding continuity)
- Carrier Conformance Status Summary (% compliant by corridor, remaining work to Month 30 = 2029-04-08)
- Consumer Product Progress Report (app usability, support performance, TEN-T expansion planning)
- Steering Committee Decision: Proceed to Month 30 (2029-04-08) API mandate, adjust corridor sequencing, or defer less-ready carriers

**Dependencies:**

- Measurement baseline finalized and validated (Month 9 = 2027-07-08)
- Carrier conformance testing underway (Months 21–24 = 2028-07-08 to 2028-10-08)
- Monthly budget reports and spend tracking active
- App pilot-testing and feedback loop completed

### 44. Steering Committee formally declares the Month 30 (2029-04-08) mandatory API exposure milestone. Confirm: at least 90% of cross-border traffic on the four priority corridors is bookable end-to-end through a compliant OSDM API or hub access; all major carriers (above EUR 50M cross-border revenue) are live with conforming APIs or have a time-bound plan to reach compliance by Month 36 (2029-10-08); smaller carriers not yet ready are using hub access and can demonstrate a credible migration path to native OSDM by Month 36 (2029-10-08).

**Responsible Body/Role:** Programme Steering Committee

**Suggested Timeframe:** Month 30 (2029-04-08) (hard milestone)

**Key Outputs/Deliverables:**

- Mandatory API Exposure Achievement Confirmation (90%+ readiness on all four priority corridors)
- Carrier Compliance Status Report (live carriers, hub-access carriers, non-compliant carriers with remediation plans)
- Through-Ticket Volume Summary (actual vs. target progress toward 40% by Month 60 = 2031-10-08)
- Consumer Product Status (app live on all four corridors, support centre operational, user satisfaction metrics)
- Decision: Proceed to TEN-T expansion (Month 36 = 2029-10-08), or adjust corridor or carrier timelines

**Dependencies:**

- Binding standards approved and enforced (Month 18 = 2028-04-08)
- Carrier conformance testing completed (Months 21–30 = 2028-07-08 to 2029-04-08)
- Payment-institution accreditation and settlement infrastructure operational
- Measurement and evaluation framework tracking progress toward targets

### 45. Steering Committee, at Month 36 (2029-10-08), makes the formal decision to expand through-ticketing beyond the four priority corridors to the broader TEN-T network. Define the TEN-T extension corridors and priorities; allocate funding for two additional regional hubs (EUR 12M reserved, finalized at Month 30 = 2029-04-08). Confirm carrier readiness for TEN-T corridors (target: 70%+ major carriers + hub-eligible carriers in place by Month 36 = 2029-10-08). Set intermediate goals for TEN-T completion (target: Month 48 = 2030-10-08 for secondary corridors, Month 60 = 2031-10-08 for full network).

**Responsible Body/Role:** Programme Steering Committee

**Suggested Timeframe:** Month 36 (2029-10-08)

**Key Outputs/Deliverables:**

- TEN-T Expansion Approval and Corridor Prioritization
- Additional Regional Hub Procurement Decision (EUR 12M for 2 TEN-T hubs)
- TEN-T Corridor Readiness Assessment (carrier compliance, hub deployment status)
- TEN-T Rollout Timeline (Phase 2: Months 36–48 = 2029-10-08 to 2030-10-08; Phase 3: Months 48–60 = 2030-10-08 to 2031-10-08)
- Budget Allocation for TEN-T (EUR 50–100M additional if needed from contingency or supplementary authority)

**Dependencies:**

- Four priority corridors operational and meeting through-ticket volume targets (Month 30 = 2029-04-08)
- Measurement showing positive momentum and no major issues requiring rework
- Carrier and hub-operator readiness assessments for TEN-T routes
- Budget contingency sufficient or supplementary authority available

### 46. Steering Committee, at Month 48 (2030-10-08), initiates the post-Month 60 (2031-10-08) sustainability planning phase. Establish a Sustainability Working Group to design transition models for each programme component: (1) Data-layer operations: identify a permanent operational host (e.g., EU Agency for Railways or multi-carrier consortium) and define governance/financing by Month 54 (2031-04-08). (2) Clearing mechanism: shift to operational cost-recovery or permanent public funding commitment. (3) Public reference distributor: decide on post-Month 60 (2031-10-08) model (shutdown, hand-off to commercial operator, or downsizing to niche service). (4) Regulator capacity: secure member-state commitment to maintain funding.

**Responsible Body/Role:** Programme Steering Committee (with PMO and external sustainability advisor)

**Suggested Timeframe:** Month 48 (2030-10-08)

**Key Outputs/Deliverables:**

- Sustainability Working Group Charter and Membership
- Preliminary Transition Models for Each Programme Component
- Financial Sustainability Assessment (EUR 45M/year recurring run-cost not covered by the cap identified)
- Decision Gates: Data-layer permanent host selected (by Month 54 = 2031-04-08), Distributor wind-down or hand-off plan approved (by Month 54 = 2031-04-08), Regulator funding commitment secured (by Month 54 = 2031-04-08)

**Dependencies:**

- Programme is on track to complete Month 60 (2031-10-08) full corridor through-ticketing
- Measurement and evaluation showing positive outcomes (40% through-ticket share, complaints halved, modal shift data)
- Stakeholder buy-in for long-term through-ticketing infrastructure (regulators, carriers, distributors confirm ongoing value)

### 47. Steering Committee, in consultation with the Sustainability Working Group, secures written commitments from the Commission, Council and member states (by Month 54 = 2031-04-08) confirming post-Month 60 (2031-10-08) funding and operational arrangements for: data-layer operations, clearing mechanism, regulator capacity building, and (if applicable) public distributor operations. Finalize transition-execution plans and regulatory authorities' roles.

**Responsible Body/Role:** Programme Steering Committee (with DG MOVE and member-state representatives)

**Suggested Timeframe:** Month 54 (2031-04-08)

**Key Outputs/Deliverables:**

- Commission and Council Commitment Letters (post-Month 60 = 2031-10-08 funding and operational governance)
- Member-State Funding Commitments (regulator capacity building, national enforcement)
- Finalized Data-Layer Permanent-Host Agreement (governance, SLAs, funding)
- Clearing Mechanism Post-Month 60 (2031-10-08) Operating Model (cost recovery or public funding)
- Public Distributor Transition Plan (wind-down, hand-off, or operational model)
- Regulatory Transition Procedures (handover of enforcement and compliance monitoring to national regulators)

**Dependencies:**

- Sustainability Working Group preliminary models finalized (Month 48–54 = 2030-10-08 to 2031-04-08)
- Stakeholder (regulator, carrier, distributor) agreement on long-term sustainability model
- Financial commitments from national budgets or European multi-annual framework secured

### 48. Programme Director, with the Measurement and Evaluation Lead, delivers the comprehensive final evaluation report (Month 60 = 2031-10-08). Report includes: (1) Achievement of the three headline targets (40% through-ticket share, complaints halved, modal shift), (2) Counterfactual attribution (separated from confounding factors like fuel prices or aviation-tax policy), (3) Process evaluation (governance effectiveness, working-group efficiency, stakeholder satisfaction), (4) Lessons learned and recommendations for future EU programmes.

**Responsible Body/Role:** Programme Director (with Independent Evaluator and Measurement Lead)

**Suggested Timeframe:** Month 60 (2031-10-08) (end of programme)

**Key Outputs/Deliverables:**

- Final Evaluation Report (120–150 pages, comprehensive assessment of outcomes, process, impact, lessons)
- Final Outcome Dashboard (40% through-ticket share final figure, complaints reduction%, modal shift%, distributor satisfaction)
- Public Dissemination (summary report for Parliament, member states, media)
- Recommendations for Future Programmes (governance, timeline, budget, risk management)

**Dependencies:**

- Quarterly measurement and evaluation data collected throughout Months 0–60 (2026-10-08 to 2031-10-08)
- Counterfactual model developed and applied (baseline vs. programme corridors)
- Independent evaluator contracted and engaged throughout the programme
- Final outcome data validated (through-ticket volumes, complaint metrics, modal shift indicators)

### 49. Programme Steering Committee formally closes the programme (Month 60 = 2031-10-08). Confirm: all four priority corridors operating with through-ticketing (at scale supporting 40% of cross-border journeys), TEN-T extension launched and on track for Month 72 (2032-10-08) full-network completion (or revised timeline as warranted). Conduct a final programme review, release staff, transition operational responsibilities to permanent hosts (data-layer, clearing, regulator networks, distributor channels), and hand over all programme documentation to DG MOVE and the EU Agency for Railways for archival and future reference.

**Responsible Body/Role:** Programme Steering Committee (led by Chair)

**Suggested Timeframe:** Month 60 (2031-10-08)

**Key Outputs/Deliverables:**

- Programme Closure Report (summary of achievements, budget final close-out, staff release plan)
- Handover Documentation (all systems, contracts, policies, compliance records)
- Transition Confirmation Letters (from permanent hosts confirming receipt and operational continuity)
- Final Steering Committee Meeting Minutes (programme close-out decision, vote of thanks)
- Public Announcement of Programme Completion (communication to Parliament, member states, media)

**Dependencies:**

- All programme deliverables substantially complete or transitioned to permanent operations
- Final evaluation report completed (Month 60 = 2031-10-08)
- Permanent-host arrangements confirmed and operational (Month 54–60 = 2031-04-08 to 2031-10-08)
- Steering Committee and all governance bodies ready to stand down

# Decision Escalation Matrix

**Budget Overrun Exceeding Contingency Threshold**
Escalation Level: Programme Steering Committee
Approval Process: Written decision within 5 working days. Supermajority vote (2/3 of members) if consensus cannot be reached. Escalation to the Commission (DG MOVE) if Tier 3 contingency (>25% overrun) is triggered or if free contingency is exhausted.
Rationale: The fixed EUR 1,500 million budget is a hard user constraint. Overruns exceeding 15% (Tier 2) threaten funding for standards work, conformance testing, and carrier co-funding. Monthly budget tracking triggers escalation when spend exceeds 115% of pro-rata forecast. A Tier 2 or Tier 3 event requires immediate strategic decisions (cut co-funding rates, defer TEN-T extension, seek supplementary authority) that only the Steering Committee can authorise.
Negative Consequences: Unmitigated budget overruns force arbitrary cuts to conformance testing (delaying smaller-carrier certification by 6–12 months), capacity building (weakening regulator enforcement), or consumer rollout (reducing through-ticket adoption). A EUR 300–450M overrun (Tier 3) exceeds free contingency and risks programme failure or compressed delivery without quality assurance.

**Carrier Non-Compliance or Major Incumbent Signalling Delay Past Month 30 (2029-04-08) Mandatory API Deadline**
Escalation Level: Programme Steering Committee, with escalation to the Commission (DG MOVE) and potential enforcement action (co-funding hold, public-channel competition, regulatory escalation)
Approval Process: Steering Committee convenes an emergency meeting within 5 working days of non-compliance signal. Reviews evidence (missed integration milestones, insufficient IT investment, formal delay announcement). If a major carrier (>30% of corridor traffic) signals non-compliance, Steering Committee authorises contingency levers: hold co-funding tranches, escalate to the Commission for enforcement negotiations, and consider public distributor expansion to bypass the non-compliant carrier.
Rationale: Large incumbents (Deutsche Bahn, SNCF, Trenitalia, ÖBB) have political leverage and can stall the entire programme if they contest compliance deadlines or demand exemptions. The Month 30 (2029-04-08) API mandate is legally binding under the adopted Regulation. If a major carrier continues non-compliant practices after an arbitration panel ruling, the programme's credibility collapses and smaller carriers lose incentive to integrate.
Negative Consequences: Non-compliance by one major carrier (accounting for 30–40% of cross-border traffic) fractures the coalition. The Month 30 (2029-04-08) mandate becomes advisory rather than binding, and competing carriers demand similar extensions, reducing API coverage from 90% to 70–80% of cross-border journeys. The 40% through-ticket target becomes unachievable.

**Regulation Adoption Delayed or Materially Divergent from Assumed Framework**
Escalation Level: Programme Steering Committee and Project Sponsor (DG MOVE), with parliamentary liaison and member-state coordination
Approval Process: Steering Committee reviews the regulatory status quarterly (starting Month 3 = 2027-01-08). If adoption slips to Month 9 (2027-07-08) or later, the Committee convenes an emergency session to activate contingency: (1) accelerate shadow standards work (already underway from Month 0 = 2026-10-08) and contract external standards consortium for rapid finalisation; (2) pause new carrier onboarding commitments until final Regulation text is clear. If final text diverges materially on scope, access terms, or liability, the Committee authorises a 2–4 week 'rapid standards adjustment' post-adoption (by Month 12 = 2027-10-08) rather than attempting finalisation before text is confirmed.
Rationale: The Commission's proposed Regulation (May 2026) remains unadopted as of Month 0 (2026-10-08). Parliament and Council negotiations could extend adoption to Month 6–12 (2027-04-08 to 2027-10-08), compressing the Month 18 (2028-04-08) standards-setting window from 9 months to 3–4 months. A hard gate of Month 9 (2027-07-08) ensures that if adoption slips further, the critical path is re-baselined before momentum is lost.
Negative Consequences: If adoption occurs after Month 9 (2027-07-08), standards-setting margin is eliminated. Either rushed, low-quality standards (risking non-compliance by carriers) or a formal Month 18 (2028-04-08) deadline miss results. Material divergence in final text (e.g., narrowed scope or weaker non-discrimination rules) invalidates much of the pre-work and requires rework, adding 4–8 weeks and threatening the Month 30 (2029-04-08) API mandate.

**Arbitration Panel Ruling Contested or Rejected by a Major Carrier or Member State; Governance Deadlock**
Escalation Level: Commission (DG MOVE, and DG COMP if competition concerns arise) for binding decision and enforcement authority
Approval Process: If a carrier or member-state regulator contests an arbitration panel ruling (issued within 60 days) within 10 days, the issue escalates to the Commission with a written statement from the panel, the dissenting party and any affected stakeholders. The Commission has 14 days to affirm or overturn the ruling. If affirmed and a carrier continues non-compliant practices, the Commission can impose remedial action: mandatory corrective measures, interim API access revocation, or escalation to national enforcement authorities.
Rationale: The lightweight arbitration panel lacks direct enforcement authority. If a major incumbent contests a technical ruling (e.g., on inventory-parity thresholds or API latency SLAs) and refuses to comply, the panel's only recourse is escalation to the Commission. Without explicit written Council delegation (target Month 2 = 2026-12-08) and carrier Commitment Letters with penalty provisions, the panel cannot compel compliance.
Negative Consequences: Unresolved disputes cascade: a contested ruling on, e.g., API latency (2 seconds vs. 3 seconds) holds up standards approval, carrier integration and the Month 18 (2028-04-08) deadline. Escalation to the Commission for mediation takes 2–4 months, and if the carrier is politically protected (e.g., a national champion), the Commission may negotiate weaker terms, undermining the non-discrimination goal. The programme's authority is questioned by other carriers, and compliance rates drop.

**GDPR or Competition-Law Challenge to the Shared Data Layer; Regulatory Investigation or Mandated Redesign**
Escalation Level: European Commission (DG COMP for competition law; EDPB for GDPR), with programme suspension contingency
Approval Process: If a competition authority or data protection authority initiates a formal investigation into alleged data-sharing collusion or GDPR non-compliance (estimated Month 12–18 = 2027-10-08 to 2028-04-08 risk window), the Steering Committee is notified immediately. The Committee authorises the programme's legal team and DG MOVE to engage in the investigation. If the authority issues a preliminary ruling requiring redesign or forbearance, the Committee convenes an emergency session within 5 working days to assess impact on the Month 30 (2029-04-08) API mandate and authorise contingency measures: data-layer architecture redesign, temporary suspension of shared data (revert to pure federated queries), or timeline extension to Month 36 (2029-10-08).
Rationale: The shared real-time data layer exposes carrier fares, load factors and sales volumes—commercially sensitive information. Even with safeguards (data minimisation, neutral operator, access logs), a competition investigation can create legal uncertainty and force carriers to curtail data contributions. Similarly, a GDPR challenge over cross-border PII flows or consent regimes can disrupt payment-institution accreditation and clearing operations.
Negative Consequences: A competition authority investigation lasting 12–24 months delays full data-layer rollout. Carriers become unwilling to participate, reducing inventory coverage. GDPR intervention forcing local data residency or explicit consent for every journey transaction creates friction and reduces through-ticket volumes by 10–20%. Worst case: the data layer is ordered to be dismantled, requiring a 6–12 month overhaul and a 2–6 month extension of the Month 30 (2029-04-08) API deadline.

**Through-Ticket Volume Significantly Lags Target (Baseline Measurement at Month 9 = 2027-07-08 Invalidates 40% Projection)**
Escalation Level: Programme Steering Committee, with potential pivot to contingency funding or scope adjustment
Approval Process: At Month 9 (2027-07-08), the validated baseline is reviewed by the Measurement and Evaluation Lead and presented to the Steering Committee. If the baseline survey reveals that current cross-border through-ticket share is significantly lower than assumed (e.g., <5% vs. 8% estimated), the Committee triggers a 4-week strategic review. Based on findings, the Committee may: (1) increase co-marketing budgets (EUR 5–10M additional); (2) accelerate the public distributor's launch (from Month 27 = 2029-01-08 to Month 15 = 2028-01-08); (3) revise the 40% target downward and adjust the programme narrative to focus on volume and convenience rather than market-share percentage.
Rationale: The 40% through-ticket target depends on accurate baseлining of current cross-border rail volumes and modal split. If the baseline is systematically misestimated or if baseline measurement reveals structural barriers to through-ticketing adoption (e.g., distributors resist integration, airlines compete aggressively on price), the programme's ROI case weakens and stakeholder confidence erodes.
Negative Consequences: If the baseline invalidates the 40% target's plausibility, the programme loses political momentum and stakeholder buy-in. Funding may be redirected to other priorities, or the programme's scope may be reduced (e.g., to two corridors instead of four). By Month 24 (2028-10-08), a missed interim gate (15% through-ticket share) triggers co-funding hold and forces a decision on whether to increase public investment or accept a lower outcome.

# Monitoring Progress

### 1. Milestone and Critical-Path Tracking
**Monitoring Tools/Platforms:**

  - Project-Management Tool (Asana, Monday.com or equivalent) with real-time dashboard
  - Monthly Milestone Status Report (PMO to Steering Committee)
  - Critical-Path Gantt Chart and dependency tracker
  - Regulation Adoption Tracking Dashboard (weekly)

**Frequency:** Weekly PMO status update (internal); monthly deep-dive (PMO all-hands); quarterly Steering Committee review (Months 3, 6, 9, 12 onwards = 2027-01-08 to 2027-10-08 and thereafter)

**Responsible Role:** Programme Management Office (PMO) Director and Deputy, with Programme Steering Committee oversight

**Adaptation Process:** PMO flags any slippage >2 weeks within 5 working days. Working groups and carriers propose corrective actions (resource increase, scope reduction, timeline adjustment). If slippage exceeds 4 weeks or threatens a hard gate (Month 18 = 2028-04-08, Month 30 = 2029-04-08, Month 60 = 2031-10-08), escalate to Steering Committee for binding decision on timeline adjustment, contingency activation, or scope reduction.

**Adaptation Trigger:** Milestone slippage >2 weeks (triggers PMO escalation); >4 weeks (triggers Steering Committee session within 1 week); Regulation adoption delay past Month 9 (2027-07-08) (hard gate, triggers contingency activation and contingency standards-review); any hard milestone at risk of being missed more than 2 months in advance (triggers re-baselining).

### 2. Budget Burn Rate and Contingency Monitoring
**Monitoring Tools/Platforms:**

  - Monthly Budget Burn Report (Finance Officer to PMO and Steering Committee)
  - Budget Forecast Spreadsheet (EUR 1.5 billion cap tracked by component)
  - Contingency Activation Triggers and Tier 1/2/3 Decision Matrix
  - Carrier Co-Funding Disbursement Log (tied to milestone completion)

**Frequency:** Monthly financial reporting (by the 15th of each month); quarterly Steering Committee budget review (Months 3, 6, 9, 12 = 2027-01-08 to 2027-10-08 and thereafter); contingency-activation triggers assessed at each monthly PMO all-hands

**Responsible Role:** Finance Officer (PMO), with Steering Committee budget authority above EUR 50M per item

**Adaptation Process:** Finance Officer produces monthly burn-rate summary vs. pro-rata forecast. If monthly spend exceeds 115% of pro-rata budget, flag immediately (within 2 working days). If overrun is 10-15% (Tier 1), PMO reviews discretionary spend (marketing, distributor co-ops) for deferral. If overrun is 15-25% (Tier 2), Steering Committee convenes within 1 week to approve cost-reduction measures: reduce carrier co-funding rate from 20% to 10-15%, defer TEN-T hub procurement, or scale back consumer-app features. If overrun exceeds 25% (Tier 3), Steering Committee immediately requests supplementary budget authority from DG MOVE and the Commission.

**Adaptation Trigger:** Monthly spend >115% of pro-rata forecast (Tier 1 trigger); cumulative overrun reaching 15% (Tier 2, triggers SC decision within 1 week); overrun reaching 25% (Tier 3, triggers immediate Commission escalation); free contingency (EUR 215M) consumed by >80% (triggers DG MOVE notification and request for supplementary authority); co-funding demand from carriers exceeds EUR 350M (signals pipeline risk, triggers co-funding-rate reduction decision by Month 12 = 2027-10-08).

### 3. Carrier Integration Readiness and Conformance Tracking
**Monitoring Tools/Platforms:**

  - Carrier Conformance and Readiness Dashboard (monthly, by corridor and carrier)
  - Conformance Test Queue and Lab Capacity Report (monthly)
  - Carrier Milestone Completion Log (API design review Month 15 = 2028-01-08, test-bed Month 18 = 2028-04-08, dual-run Months 21-24 = 2028-07-08 to 2028-10-08, pre-production Months 24-27 = 2028-10-08 to 2029-01-08, go-live Month 30 = 2029-04-08)
  - Carrier Commitment Letter Compliance Tracker (penalties in escrow monitored)

**Frequency:** Monthly carrier readiness update (PMO Carrier Onboarding Lead to PMO all-hands); quarterly detailed readiness report to Steering Committee; weekly testing-lab capacity review (internal PMO)

**Responsible Role:** Carrier Onboarding and Conformance Lead (PMO), with testing labs and EU Agency for Railways liaison

**Adaptation Process:** PMO tracks each carrier's progress through readiness gates. If a carrier misses a gate (e.g., API design review not completed by Month 15 = 2028-01-08), PMO issues a 2-week remediation notice and assigns a technical mentor. If the carrier does not meet the remediation deadline, PMO suspends co-funding tranches (0.5-1% of quarterly through-ticket revenue, held in escrow, is accelerated to forfeiture) and escalates to the Steering Committee. If a major carrier (>EUR 100M cross-border revenue, >30% of corridor traffic) signals they will not meet the Month 30 (2029-04-08) API deadline, Steering Committee convenes emergency session within 5 days, invokes the Commitment Letter penalty, and initiates enforcement escalation to DG MOVE (public distributor bypass, regulatory pressure).

**Adaptation Trigger:** Carrier misses a readiness gate by >2 weeks (triggers remediation notice); multiple carriers (>3) slip past a gate simultaneously (triggers Steering Committee review and possible timeline extension or scope reduction); a major incumbent carrier (Deutsche Bahn, SNCF, Trenitalia, ÖBB, >30% corridor traffic) signals non-compliance or delay >6 months (triggers emergency SC session and enforcement escalation); less than 80% of major carriers pass conformance audit by Month 24 (2028-10-08) (triggers Month 30 = 2029-04-08 API mandate risk assessment); less than 75% of smaller carriers ready via hubs by Month 30 (2029-04-08) (triggers TEN-T extension delay decision).

### 4. Standards Development Progress and Technical Dispute Resolution
**Monitoring Tools/Platforms:**

  - Technical Standards Working Group Monthly Status Report (sub-group deliverables, consensus gaps, escalations)
  - Draft Standards Document Status (chapters complete, review cycle status)
  - Arbitration Panel Case Log (disputes received, rulings issued, compliance tracking)
  - OSDM Specification Alignment Tracker (comparison to published OSDM standard and Regulation requirements)

**Frequency:** Monthly standards working-group all-hands meeting and PMO reporting; bi-weekly sub-group check-ins on critical workstreams (OSDM, data-layer, clearing/settlement); arbitration panel decisions logged and published within 5 working days of issuance; quarterly Steering Committee review of standards progress (Months 3, 6, 9, 12 = 2027-01-08 to 2027-10-08)

**Responsible Role:** Technical Standards Lead (PMO, chair of working group), with Arbitration Panel Chair and EU Agency for Railways liaison

**Adaptation Process:** Standards Lead tracks sub-group progress against planned deliverables. If a sub-group cannot reach consensus on a technical issue by the target date (e.g., data-layer architecture by Month 9 = 2027-07-08), the Standards Lead escalates the dispute to the Arbitration Panel within 5 working days with written positions from all parties. The Panel issues a binding ruling within 60 days. If the ruling is contested (within 10 days), the dispute escalates to the Commission (DG MOVE, DG COMP if competition concerns) for final decision within 14 days. Meanwhile, the Standards Lead proceeds with drafting on all non-disputed sections so the Month 18 (2028-04-08) standards gate is not delayed by single disputed issues. If the disputed issue is resolved late (Month 12-15 = 2027-10-08 to 2028-01-08), a 2-4 week draft-incorporation cycle is scheduled before the Month 18 (2028-04-08) approval gate.

**Adaptation Trigger:** Sub-group unable to reach consensus by planned date (triggers escalation to arbitration panel within 1 week); arbitration panel ruling contested (triggers Commission escalation); more than 2 major technical disputes unresolved by Month 12 (2027-10-08) (triggers Steering Committee risk assessment and possible extension of standards deadline to Month 21 = 2028-07-08, with Month 30 = 2029-04-08 API mandate at risk); draft standards not complete by Month 15 (2028-01-08) (triggers 2-week extension and expedited final review, risking Month 18 = 2028-04-08 deadline).

### 5. Real-Time Data Layer and API Performance Monitoring
**Monitoring Tools/Platforms:**

  - API Operations Centre Dashboard (latency p95, uptime %, throughput, error rates, incident log)
  - Monthly API Performance Report (by carrier and corridor)
  - Hub Performance Dashboard (uptime, latency, booking-failure rate, mapping-accuracy metrics)
  - Infrastructure Provider SLA Compliance Tracker
  - Carrier Infrastructure Assessment and Co-Funding Allocation Log

**Frequency:** 24/7 automated monitoring (API ops centre); daily incident summary (if any critical events >15 min downtime); weekly ops-centre meeting (Monday morning); monthly performance report (by the 5th of each month); quarterly Steering Committee review (Months 6, 9, 12 = 2027-04-08 to 2027-10-08 and thereafter)

**Responsible Role:** API Operations Centre Manager and Data-Layer Technical Lead (PMO), with infrastructure provider escalation protocols

**Adaptation Process:** API ops centre monitors latency, uptime and throughput against SLAs (p95 <2 sec, 99.95% uptime, ≥500 req/s per corridor). If latency exceeds 5 seconds p95 or uptime drops below 99.5% for >1 hour, ops centre issues a critical incident alert (within 15 minutes) to the carrier or infrastructure provider responsible. Incident must be resolved within 2 hours (target). If a carrier's infrastructure cannot meet SLAs (latency consistently >3 sec or throughput <300 req/s), the PMO triggers co-funding for infrastructure upgrades (EUR 0.5-2M per carrier, Month 6-18 = 2027-04-08 to 2028-04-08). If a hub's booking-failure rate exceeds 2% for more than 1 week, the PMO suspends new carrier onboarding to that hub and convenes a remediation task force (hub operator + carriers + PMO technical team) to debug the mapping errors. Hub downtime >12 hours triggers a postmortem review (within 48 hours) and root-cause analysis. Hub mapping errors >1% of transactions trigger liability-insurance claim and carrier reimbursement (from hub operator's E&O policy).

**Adaptation Trigger:** API latency p95 exceeds 3 seconds for any corridor for >4 hours (triggers infrastructure review and capacity upgrade plan); API uptime falls below 99.5% for >2 consecutive days (triggers infrastructure provider penalty and failover activation); hub booking-failure rate exceeds 2% for >1 week (triggers carrier onboarding freeze and remediation sprint); hub mapping errors >1% of transactions (triggers retest and carrier compensation from E&O insurance); API response timeout rate >1% during peak hours (triggers load-test and chaos-engineering exercise).

### 6. Through-Ticket Volume and Measurement Baseline Tracking
**Monitoring Tools/Platforms:**

  - Quarterly Through-Ticket Volume Dashboard (% of cross-border journeys sold as through-tickets, by corridor and channel)
  - Measurement Baseline Report (Month 9 = 2027-07-08 validated baseline)
  - Carrier and Distributor Reporting Template (monthly from Month 18 = 2028-04-08)
  - Independent Evaluator Counterfactual Model and Progress Report (quarterly)
  - Modal-Shift Analysis (air fares vs. through-fares, short-haul air trip trends, by corridor)

**Frequency:** Baseline survey and definition of 'through-ticket' (Months 0-2 = 2026-10-08 to 2026-12-08, report Month 6 = 2027-04-08); validated baseline at Month 9 (2027-07-08); mandatory carrier/distributor reporting monthly starting Month 18 (2028-04-08); quarterly measurement dashboard (Month 18 = 2028-04-08 onward); quarterly Steering Committee review of progress toward the 40% target and complaints-halved target (Months 6, 9, 12, 15 = 2027-04-08 to 2028-01-08 and thereafter)

**Responsible Role:** Measurement and Evaluation Lead (PMO), with independent evaluator and carriers/distributors providing data

**Adaptation Process:** Baseline survey (Month 9 = 2027-07-08) establishes: current cross-border through-ticket share (estimated 5-10%), current distributor complaint rate (baseline for 'halved' target), modal split (baseline for modal-shift planning range). From Month 18 (2028-04-08), carriers and accredited distributors submit monthly through-ticket volumes and complaint metrics. Independent evaluator aggregates data quarterly and applies counterfactual methodology (comparing programme corridors to non-programme control routes) to isolate programme impact from external factors (fuel prices, airline capacity, aviation taxes). If baseline measurement at Month 9 (2027-07-08) invalidates the 40% target's plausibility (e.g., baseline is <3% through-ticket share, suggesting much lower market penetration), Steering Committee triggers a 4-week strategic review and may revise the target or increase co-marketing investment. Interim gate at Month 24 (2028-10-08): if through-ticket share is <15% of cross-border journeys, Steering Committee triggers co-funding hold and determines whether to increase public investment or accept a lower outcome. Final evaluation at Month 60 (2031-10-08) will report actual through-ticket share, complaints reduction and modal-shift attribution.

**Adaptation Trigger:** Baseline measurement at Month 9 (2027-07-08) shows through-ticket share <3% (signals unachievability of 40% target, triggers strategic review); interim gate at Month 24 (2028-10-08) shows through-ticket share <15% (triggers co-funding review and possible contingency reallocation); quarterly through-ticket growth stalls (no increase for 2+ consecutive quarters) (triggers analysis of barriers and possible accelerated consumer-app rollout or co-marketing boost); modal-shift analysis shows through-fares not competitive with airlines on any corridor (triggers assessment of whether regulated fare ceilings or subsidies are needed); distributor complaints remain >baseline at Month 36 (2029-10-08) (triggers investigation and possible claim-resolution process redesign).

### 7. Governance Body Effectiveness and Risk-Register Monitoring
**Monitoring Tools/Platforms:**

  - Risk Register (20+ initial risks identified, updated monthly with new risks, mitigation owners, and status)
  - Steering Committee Decision Log (decisions, owners, deadlines, closure tracking)
  - Governance Body Meeting Minutes and Attendance Tracker (PMO responsibility)
  - Escalation Log (issues escalated from working groups, resolution status, closed-out items)
  - Stakeholder Satisfaction Survey (annual, starting Month 12 = 2027-10-08)

**Frequency:** Monthly PMO risk review (PMO Risk Officer presents top 10 risks at PMO all-hands); Steering Committee risk escalation and mitigation tracking (quarterly, Months 3, 6, 9, 12 = 2027-01-08 to 2027-10-08 and thereafter); governance-body effectiveness self-assessment (Month 6 = 2027-04-08 mid-programme review); annual stakeholder satisfaction survey (Month 12 = 2027-10-08, Month 24 = 2028-10-08, Month 36 = 2029-10-08)

**Responsible Role:** Governance and Risk Officer (PMO), with Programme Steering Committee oversight and Community Liaison Officer (stakeholder satisfaction)

**Adaptation Process:** Risk Officer maintains a living risk register with ~20 key risks (regulatory adoption, governance deadlock, budget overrun, carrier non-compliance, hub failures, GDPR/competition challenges, smaller-carrier readiness, modal-shift viability). Each risk has a mitigation owner (e.g., PMO Stakeholder Lead for political/governance risks, Technical Lead for technical risks, Finance Officer for budget risks). Monthly review assesses: has the risk materialized? Is mitigation on track? Have new risks emerged? If a risk's mitigation action is overdue or ineffective, or if the risk's probability/impact increases, the Risk Officer escalates to the Steering Committee within 5 working days with a decision request (approve revised mitigation, escalate to Commission, or accept the risk). Unmitigated critical risks (e.g., Regulation adoption slips past Month 9 = 2027-07-08) trigger a contingency-activation decision at the Steering Committee. Governance-body effectiveness self-assessment (Month 6 = 2027-04-08) reviews: Are decisions being made on schedule (target: resolve issues within 4 weeks)? Are working groups productive or becoming 'talking shops'? Is stakeholder engagement sufficient (target: >70% satisfaction among all stakeholder groups)? If satisfaction drops below 70% in any group, Community Liaison Officer triggers 4-week focused outreach. If working groups are producing re-litigated decisions (same issues debated repeatedly), Steering Committee enforces decision finality and narrows working-group scope.

**Adaptation Trigger:** Any critical risk (probability×impact >15/25) unmitigated (triggers Steering Committee decision within 5 days); risk mitigation action overdue by >2 weeks (escalation to action owner's manager); new critical risk identified (triggers rapid assessment and mitigation planning within 1 week); Steering Committee decision delayed >4 weeks (triggers chair escalation and simplified decision-making protocol); stakeholder satisfaction <70% in any group (triggers focused outreach; if <60%, escalation to DG MOVE); governance-body meeting cancellations or no-shows >2 in a quarter (signals disengagement, triggers restructuring or workload reduction); more than 3 decisions re-litigated in Steering Committee (signals working-group lack of clarity, triggers tighter TOR and decision-finality rule).

# Governance Extra

## Governance Validation Checks

1. Completeness Confirmation: All core governance components from Stages 2–5 are generated and present: internal governance bodies (Steering Committee, PMO, working groups, arbitration panel, regulators, consumer team, ethics committee), implementation plan (step-by-step governance setup from Month 0 = 2026-10-08 to Month 60 = 2031-10-08), decision-escalation matrix (11 major issue types with approval processes and negative consequences), and monitoring progress (five approach tracks with tools, frequency, adaptation triggers). The governance framework is internally complete.
2. Internal Consistency Check: The framework is logically aligned across stages. Implementation plan activations (e.g., Steering Committee appointment at Month 1 = 2026-11-08, arbitration panel at Month 2 = 2026-12-08) feed into decision-escalation procedures, which rely on authority delegations secured in setup phase. Monitoring tracks (budget, milestones, conformance, disputes, measurement) all feed escalation triggers to the bodies defined in Stage 2. Working-group deliverables (binding standards by Month 18 = 2028-04-08) are gated by Steering Committee decisions and supported by arbitration panel dispute resolution. Consistency confirmed with one minor note: the ethics committee's oversight of compliance is mentioned but not formally invoked as an escalation endpoint in the matrix; recommend adding ethics escalation for GDPR/accessibility/conflict-of-interest discoveries.
3. Clarity of Roles and Authority: The programme sponsor (DG MOVE) holds ultimate authority and budget-holder role, confirmed in Stage 2 and Stage 3. Steering Committee has binding authority over standards, corridors, and budget above EUR 50M; PMO has operational authority up to EUR 10M and escalates disputes. Arbitration panel authority is explicitly scoped to technical standards only, with escalation to Commission for conflicts. Member-state regulators hold enforcement authority with lead-regulator mechanism for cross-border cases. Consumer product director owns the app and support centre. Ethics committee is advisory but can recommend suspension of participants. This structure is clear, though the Programme Director's authority during governance setup (Months 0–1 = 2026-10-08 to 2026-11-08) before Steering Committee appointment could be explicitly stated as interim/transitional (currently implied).
4. Process Depth and Clarity: Key operational processes are defined at moderate detail. Conformance testing (Stage 5) specifies testing labs, checklist items, and queue allocation; passenger-rights backstop (assumptions) specifies reroute timelines and refund procedures; refund dispute resolution (Stage 5 escalation matrix) specifies 5-day panel ruling targets; GDPR compliance includes DPIA, DPA consensus, and consent protocols (Stage 3). However, three areas lack granular definition: (a) **Conflict-of-interest management**: ethics code is drafted (Stage 3), but procedures for handling discovered conflicts during programme execution (e.g., a Steering Committee member's carrier receives co-funding) are not detailed; recommend adding a conflict-of-interest escalation procedure to the ethics committee. (b) **Whistleblower investigation**: confidential channel is established (Stage 3), but investigation procedures (who investigates, how findings are acted on, retaliation-protection enforcement) are not specified; recommend defining a formal investigation SOP. (c) **Change control**: no formal change-control board is described for mid-programme adjustments to scope, timelines, or budget allocation; recommend that major changes (scope reduction, deadline extension >4 weeks, budget reallocation >EUR 50M) require Steering Committee approval via a structured change-request process.
5. Thresholds and Delegation Clarity: Delegation is well-defined for budget (PMO up to EUR 10M, Steering Committee EUR 50M+, Commission above cap), milestones (Steering Committee binding on standards/corridors/gates; arbitration panel on technical disputes within 60 days; Commission on regulatory conflicts). Escalation thresholds are specific: budget overrun triggers at 115% of pro-rata spend (Tier 1), 120%+ (Tier 2), 125%+ (Tier 3); milestone slippage >2 weeks triggers PMO escalation, >4 weeks triggers Steering Committee; carrier non-compliance by >2 weeks triggers remediation notice, >4 weeks triggers co-funding hold and enforcement escalation. However, one gap: the arbitration panel's decision authority ends at Month 30 (2029-04-08) per the decision-escalation matrix, but the monitoring plan (Stage 5) does not explicitly state what happens to ongoing technical disputes after Month 30 (2029-04-08) (e.g., if a carrier disputes a data-quality audit finding post-API mandate). Recommend clarifying that the panel's authority extends through Month 60 (2031-10-08) for any remaining standards disputes or that a new body takes over.
6. Integration and Information Flow: Components are well-integrated. Budget tracking (Stage 5) informs Steering Committee decisions on contingency activation; measurement dashboard (Stage 5) feeds gate decisions (15% through-ticket share at Month 24 = 2028-10-08 gate); carrier conformance tracking informs corridor readiness gates; risk register (Stage 5) escalates unmitigated critical risks to Steering Committee within 5 days. Information flow is hierarchical (PMO to Steering Committee weekly, Steering Committee to Commission via escalation matrix as needed). One area for improvement: the flow of **regulator compliance findings** to the Steering Committee is mentioned in Stage 5 (Standing Regulators Committee monthly call with PMO) but not explicitly included in the Steering Committee's quarterly agenda template; recommend adding 'Member-State Regulator Enforcement Report' as a standard SC agenda item starting Month 6 (2027-04-08).

## Tough Questions

1. What is the current probability-weighted forecast for the Regulation on Digital Booking and Ticketing Services adoption by Month 9 (2027-07-08), and what credible contingency plan exists if Parliament or Council votes for material amendments (e.g., narrowed scope, weaker non-discrimination rules) that invalidate the pre-work standards? Is the 'shadow standards' team (proposed Month 0–3 = 2026-10-08 to 2027-01-08) staffed and adequately funded to execute a 2–4 week rapid-rework cycle if final text diverges?
2. Show evidence that the written Council/Commission delegation of binding arbitration authority to the panel will be secured by Month 2 (2026-12-08). What is the legal pathway, and which Commission and Council contacts have pre-agreed the delegation scope? If delegation slips past Month 2 (2026-12-08), what is the contingency governance model, and how does it avoid losing authority over the Month 18 (2028-04-08) standards approval?
3. Provide a detailed cost breakdown and committed funding sources for the EUR 215 million free contingency reserve. How is it held at DG MOVE, what is the release process, and who has authority to commit it (Steering Committee or Commission)? If free contingency is consumed by Month 24 (2028-10-08), does the programme have a mechanism to request supplementary budget authority, and what is the realistic timeline (6–12 months?) for Commission approval?
4. Which 12–18 carriers have been formally identified as hub-eligible (revenue under EUR 50M, or IT staff under 10 FTE)? Have regional hub operators been pre-identified or pre-qualified to confirm they can deliver the four priority-corridor hubs operational by Month 9 (2027-07-08)? If hub procurement slips beyond Month 3 (2027-01-08) or hub operators cannot be contracted, what is the fallback (e.g., mandatory native OSDM integration for all carriers, or use a publicly hosted gateway)?
5. What is the verified baseline measurement (Month 9 = 2027-07-08) of current cross-border through-ticket share (assumed 5–10%), and does that baseline support the plausibility of a 40% target by Month 60 (2031-10-08)? If the baseline is below 3%, what decision triggers (co-marketing surge, regulated fares, or target revision) will the Steering Committee pre-commit to at Month 12 (2027-10-08) before momentum is lost?
6. Have the 2–3 accredited payment institutions been pre-marketed or pre-vetted to confirm they will apply for accreditation (call Month 2 = 2026-12-08, decision Month 8 = 2027-06-08)? What transaction-fee benchmarking has been done to validate the EUR 0.3–0.5% cap target? If fewer than 2 providers apply, what is the credible fallback (emergency procurement timeline, cost, and operational risk)?
7. Provide written confirmation from Deutsche Bahn, SNCF, Trenitalia, Renfe, ÖBB, NS, SJ and SNCB (or their representatives in CER) that they commit to API integration by Month 30 (2029-04-08) and accept the penalty (0.5–1% of quarterly through-ticket revenue in escrow) for non-compliance. If any major incumbent declines to sign a Commitment Letter by Month 3 (2027-01-08), what enforcement strategy will the programme execute, and does it risk political intervention that softens the Month 30 (2029-04-08) deadline?

## Summary

The governance framework for the EUR 1.5 billion, five-year EU through-ticketing programme is comprehensive and operationally grounded. It establishes a clear hierarchy (DG MOVE as sponsor, Steering Committee with binding strategic authority, PMO with operational execution, arbitration panel for technical disputes, member-state regulators for enforcement) and defines detailed procedures for standards development (Month 18 = 2028-04-08 gate), carrier integration (Month 30 = 2029-04-08 API mandate), measurement (40% through-ticket target), and budget control (contingency tiers). Key strengths are the explicit escalation matrix linking each decision type to approval bodies and timelines, the month-by-month implementation roadmap (Stages 3–5) with specific deliverables and adaptation triggers, and the risk-aware contingency planning (Tier 1–3 budget activation, regulation adoption gate, carrier non-compliance procedures). Primary dependencies are regulatory adoption by Month 9 (2027-07-08), written Council delegation of arbitration authority by Month 2 (2026-12-08), and carrier Commitment Letters by Month 3 (2027-01-08). The framework is realistic for a pragmatic, non-aggressive scenario but requires early political buy-in from major member states and carriers, disciplined budget tracking with clear contingency triggers, and sustained stakeholder engagement to manage the inherent tensions between incumbent carrier resistance, smaller-operator inclusion, and fixed timelines. Post-Month 60 (2031-10-08) sustainability (estimated EUR 45M/year unfunded run-cost) must be addressed by Month 48 (2030-10-08) to avoid programme collapse.