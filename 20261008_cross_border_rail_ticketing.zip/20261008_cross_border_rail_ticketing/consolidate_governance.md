# Governance Audit


## Audit - Corruption Risks

- Collusion among major carriers to exclude smaller competitors from the shared real-time data layer or clearing mechanism by leveraging privileged access to the OSDM API or settlement data, circumventing the non-discriminatory access mandate and the Joint Conduct Safe-Harbour decision.
- Bribery or corrupt influence by carriers or distributors on standards-working groups or conformance certification bodies to weaken accessibility requirements, latency SLAs or reconciliation accuracy thresholds, allowing non-compliant systems to access through-ticket corridors.
- Nepotism or conflict-of-interest appointments within the Programme Office or Technical Secretariat, where staff members approve funding tranches (Month 30 = 2029-04-12, Month 36 = 2029-10-12) for carriers or adapter vendors that employ their relatives or former employers, bypassing competitive procurement.
- Misuse of commercially sensitive carrier data (fares, inventory, settlement flows, on-time performance) shared within the clearing or data-sharing layer by staff members trading on the information or disclosing it to competitors outside the clean-team arrangement.
- Kickbacks or side payments from the last-resort distributor concessionaire or payment-service providers to Commission procurement officials or steering-group members in exchange for favorable contract terms, subsidy increases above the EUR 60M cap, or relief from performance penalties.
- Fraudulent conformance certification by carriers or test laboratories claiming OSDM API compliance and latency/availability SLAs (p95 <2 seconds, 99.5% uptime) without genuine technical validation, allowing non-compliant systems onto the priority corridors and triggering failures during Month 48 (2030-10-12) go-live.

## Audit - Misallocation Risks

- Budget drift: Adapter funding (EUR 240M allocation) overspends by EUR 150-250M due to emergency acceleration for missed Tier 1 timelines (Month 30 = 2029-04-12), consuming EUR 65-165M more than the EUR 85M headroom and forcing reallocation from capacity building or TEN-T extension to the reserve.
- Double spending or uncoordinated invoicing across the Programme Office and Technical Secretariat, where both entities reimburse the same external legal counsel, actuaries or integration contractors, inflating programme management costs beyond the EUR 75M allocation.
- Inefficient allocation of the EUR 150M force-majeure reserve: draw-downs after Month 36 (2029-10-12) to cover carrier-pool overruns or concession subsidy gaps that should instead trigger policy recalibration, depleting the reserve and leaving no contingency for genuine disruptions.
- Misuse of the EUR 300M concession envelope by shifting subsidy payments to the last-resort distributor to cover cost overruns beyond the EUR 60M cap without triggering contract reviews or clawback clauses, reducing funding available for other programme functions.
- Unauthorized or poorly documented use of the EUR 100M consumer-rollout budget (multilingual support, complaint handling, accessibility testing) for programme communications or marketing that benefits carriers or distributors rather than passengers, diverting funds from intended consumer services.
- Incomplete or late reporting of settlement reconciliation errors, latency SLAs and conformance audit results to the steering group and Commission, obscuring milestone status and delaying trigger-based funding releases or variance corrections, allowing non-compliant systems to remain live past Month 30 (2029-04-12).

## Audit - Procedures

- Quarterly financial reconciliation audits (Month 3 = 2027-01-12 onwards) verifying that all budget lines (programme management, standards, clearing, adapters, concession, capacity building, consumer rollout, reserve) are allocated and spent against documented approvals, no double invoicing, and variance triggers at EUR 100M/200M/300M are tracked and reported to the Commission within 10 business days.
- Independent actuarial audit of the carrier-funded guarantee pool at Month 6 (2027-04-12) and annually thereafter, confirming that missed-connection rates, rerouting costs and pool contributions are calculated according to the signed liability model, per-incident caps are enforced, and no draw-downs occur after Month 36 (2029-10-12) without force-majeure certification.
- Conformance certification audit for each carrier at Months 24, 30, 36 and 42 (2028-10-12, 2029-04-12, 2029-10-12, 2030-04-12), verifying OSDM API compliance, latency (p95 <2 seconds), availability (99.5%), stale-seat failures (<1%), and booking-error rates via independent test laboratories; results published to the steering group and used to trigger funding tranches.
- Settlement and reconciliation audit (monthly by Month 24 = 2028-10-12, then quarterly) confirming EUR settlement cycle time (5 business days), reconciliation error rate (<0.5%), and that carrier contributions to the clearing layer match their invoice-to-invoice settlement volumes and do not exceed agreed commercial terms; dispute-resolution cases sampled for proper authority.
- Post-concession audit at Months 30, 48 and 60 (2029-04-12, 2030-10-12, 2031-10-12), reviewing concessionaire operating costs against budget, through-ticket volumes against forecast, subsidy claims against the EUR 60M cap, clawback calculations and contract-review triggers; auditors must be independent of the procurement authority.
- Biennial external audit (Month 24 = 2028-10-12 and Month 48 = 2030-10-12) by the European Court of Auditors or contracted firm covering programme governance, steering-group voting records, funding-tranche release conditions and adherence to the 75% supermajority rule, competition-law compliance (DG COMP guidance letter filing, clean-team data segregation), and passenger-rights legal review sign-offs.

## Audit - Transparency Measures

- Published monthly SLA dashboard accessible to steering group and regulators, displaying each carrier's OSDM API latency (p95), availability, stale-seat error rate and booking failures; carriers missing targets for two consecutive months identified with explanation and tranche-release impact.
- Quarterly public financial report (Month 3, 6, 9, 12 = 2027-01-12, 2027-04-12, 2027-07-12, 2027-10-12, … = 2027-01-12 onwards) showing cumulative spend per budget line, variance against allocation, forecast-to-completion, reserve balance and any draw-downs approved; flagged thresholds (EUR 100M, EUR 200M, EUR 300M) trigger a published variance-mitigation explanation within 10 business days.
- Steering group meeting minutes published within 15 days (redacting competition-sensitive data), including voting records, dissents, escalation decisions and Commission mediation outcomes; binding votes on core decisions (liability, clearing, concession, commission) recorded with each member's position.
- Conformance certification results published per carrier on a public registry maintained by the EU Agency for Railways, showing pass/fail status, test-report summary, any remediation required and certification expiry date; carriers must disclose any failed audit attempts before receiving a pass certificate.
- Carrier-funded guarantee pool actuarial reports published annually, showing missed-connection incident rates by carrier, pool contributions, claim payouts, co-insurance thresholds triggered and reserve balance; individual carrier data redacted to comply with commercial confidentiality, but aggregate statistics disclosed.
- Public concession performance dashboard updated monthly, displaying through-ticket volumes sold via the last-resort distributor against forecast, operating costs against budget, subsidy drawn against the EUR 60M cap, clawback calculations if volumes exceed forecast by >20%, and any contract-review triggers if costs exceed budget by >15% in a quarter.

# Internal Governance Bodies

### 1. Programme Steering Committee (PSC)

**Rationale for Inclusion:** This is a large, multi-stakeholder, regulation-dependent public infrastructure program with a fixed €1.5B budget, distributed execution across four corridors, and critical dependencies on carrier participation, legislative adoption, and competition-law clearance. The programme has multiple high-impact strategic decisions (liability backstop, clearing architecture, public distributor role, funding release conditions) that require binding votes by Month 6 (2027-04-12) to unblock standards work and maintain the Month 18 (2028-04-12) binding-standards milestone. Strategic oversight must operate above operational delivery and hold explicit decision authority over funding tranches, milestone conditions and escalation to the Commission.

**Responsibilities:**

- Approve and enforce critical strategic decisions (Through-Ticket Liability and Rights Backstop, Inter-Carrier Clearing and Single-Payment Settlement, Public Reference Distributor Mandate, Milestone-Conditioned Funding Release Ladder, Availability Query Topology) by binding votes at Month 6 (2027-04-12).
- Set and approve annual programme budgets and funding-tranche release conditions; trigger variance-mitigation actions when cumulative spend reaches thresholds (EUR 100M, EUR 200M, EUR 300M).
- Approve conformance-gate and carrier-tier assignments; escalate conformance failures or missed SLA targets (latency, availability, reconciliation error) to the Programme Office for remedial action or funding tranche withholding.
- Oversee and approve the binding Commission guidance letter from DG COMP on Article 101 TFEU and passenger-rights legal compliance by Month 14 (2027-12-12); escalate unresolved legal or regulatory conflicts to Commission Transport Commissioner.
- Monitor and approve quarterly SLA and financial reports; authorize policy recalibrations (e.g., reserve draws, concession subsidy increases above the EUR 60M cap, TEN-T extension deferrals) if contingencies are triggered.
- Resolve deadlocked steering votes or stakeholder disputes via a formal escalation and mediation process; record all votes and dissents; publish meeting minutes within 15 days (redacting sensitive data).

**Initial Setup Actions:**

- Formally establish the Committee by Commission decision at Month 1 (2026-11-12) with explicit charter, voting rules (75% supermajority for core decisions), and escalation authority to the Transport Commissioner.
- Appoint Chair (DG MOVE Director or equivalent) and Secretary (Technical Secretariat lead) by Month 1 (2026-11-12).
- Confirm membership and secure binding commitment letters from all nine core members (DG MOVE, Agency, CER, 3-4 major carriers, Trainline, Omio, BEUC, disability body) by Month 2 (2026-12-12).
- Publish the option-papers document outlining three variants for each of Decisions 1-5 with explicit trade-offs by Month 2 (2026-12-12) to inform stakeholder positions.
- Establish a published voting and decision-recording process, including dissent documentation and tie-breaker rules, by Month 1 (2026-11-12).
- Schedule biweekly meetings (rotating virtual and in-person) for Months 1-12 (2026-11-12 to 2027-10-12) to maintain momentum on the Month 6 (2027-04-12) readiness gate and Month 18 (2028-04-12) binding-standards milestone.

**Membership:**

- Chair: DG MOVE (Director or Transport Commissioner designate)
- Vice-Chair: EU Agency for Railways (Director)
- CER (Chief Executive)
- Deutsche Bahn (or ÖBB/SBB if DB unavailable)
- SNCF (Chief Commercial Officer)
- Renfe or SJ (second major carrier)
- Trainline (Head of Policy or Chief Executive)
- Omio (Head of Regulatory Affairs or Chief Executive)
- BEUC (Head of Transport Policy)
- European Disability Forum (or equivalent disability-rights representative) (independent observer, non-voting)

**Decision Rights:** Binding strategic decisions over critical programme levers (liability backstop, clearing architecture, public distributor role, funding-tranche conditions, conformance gates, SLA thresholds, regulatory escalations). Decisions above EUR 100M cumulative variance or affecting programme schedule milestones must be approved by the Committee. Decisions below EUR 10M or operational (e.g., monthly reconciliation reviews, individual carrier SLA remediation) are delegated to the Programme Office without Committee approval.

**Decision Mechanism:** Supermajority voting (at least 7 of 9 core members, 75%) required for approval of Decisions 1-5 and for any variance triggers above EUR 100M. Simple majority (5 of 9) for procedural matters (meeting schedule, charter updates) and quarterly financial reports. In the event of a deadlock (vote below 75%), the issue is escalated to the Commission Transport Commissioner with a formal briefing by Month 5 (2027-03-12); mediation is completed by Month 6 (2027-04-12) or the decision defers to a fallback governance path (e.g., bilateral clearing interface for distributors, tiered conformance with mixed gates). Tie-breaker: the Chair (DG MOVE) casts the deciding vote only if the vote is 4.5-4.5 or a member abstains; otherwise, deadlock triggers escalation. All votes and dissents are recorded in minutes published within 15 days.

**Meeting Cadence:** Biweekly during Phase 1 (Months 1-18 = 2026-11-12 to 2028-04-12) to maintain momentum on standards-setting and stakeholder consensus; monthly during Phase 2 (Months 18-48 = 2028-04-12 to 2030-10-12) to oversee API exposure, conformance audits and funding tranches; quarterly during Phase 3 (Months 48-60 = 2030-10-12 to 2031-10-12) for TEN-T extension and final evaluation. Emergency sessions convoked within five business days if a funding variance trigger is hit or a regulatory escalation occurs.

**Typical Agenda Items:**

- Voting on critical decisions (liability model sign-off, clearing architecture, public distributor concession award, funding tranche conditions) by Month 6 (2027-04-12).
- Quarterly SLA and financial reports: conformance-certification results, latency/availability scorecards, settlement reconciliation error rates, pool-contribution and clawback calculations, concession operating costs vs. budget.
- Regulatory and legal updates: DG COMP guidance-letter status, passenger-rights legal-review findings, national regulator impact assessments, clean-team protocol approval.
- Variance-trigger management: review of cumulative spend against budget lines, authorization of contingency draws (reserve, concession subsidy cap), policy recalibrations if thresholds (EUR 100M, EUR 200M, EUR 300M) are crossed.
- Stakeholder escalations: resolution of deadlocked votes, discrimination complaints from distributors, carrier non-participation signals, national regulator conflicts.
- Schedule and milestone tracking: binding-standards progress, API exposure tier readiness, corridor go-live date confirmation, TEN-T extension planning.

**Escalation Path:** Unresolved deadlocks on core decisions (Decisions 1-5) at the Committee escalate to the Commission Transport Commissioner with a formal briefing and mediation request by Month 5 (2027-03-12); mediation completes by Month 6 (2027-04-12) or a fallback governance path is invoked. Funding variances above EUR 300M or programme-scope reductions (deferral of TEN-T extension beyond Month 72 = 2032-10-12, restriction to four corridors only) escalate to the Commission's Financial Controller and the Court of Auditors. Regulatory or competition-law conflicts that block standards adoption escalate to DG COMP and DG MOVE's legal service for resolution by Month 12 (2027-10-12) or standards are deferred. Carrier or distributor disputes unresolved by the Committee after 30 days escalate to the Commission for independent mediation or binding arbitration.
### 2. Programme Office and Operational Management Board (OMB)

**Rationale for Inclusion:** The programme spans four physical locations, 25+ carriers, independent distributors, and five-year delivery horizons with fixed regulatory milestones (Month 18 = 2028-04-12, Month 30 = 2029-04-12, Month 60 = 2031-10-12). Day-to-day programme management, budget execution, milestone tracking, carrier engagement, and operational risk management require a dedicated operational governance body with clear authority below the Steering Committee's strategic thresholds. The OMB must manage EUR 1.5B budget execution, oversee the Programme Office's 80+ staff, coordinate standards-working groups, conduct conformance testing and audits, manage funding tranches, and escalate blockers to the Steering Committee. Separating operational from strategic governance prevents agenda congestion at the Committee level and gives clear accountability for delivery.

**Responsibilities:**

- Execute the Programme Office mandate: manage the 80-person team across DG MOVE, coordinate the Technical Secretariat (50 staff) at the Agency, deploy liaison officers in Brussels, Valenciennes, Berlin and Madrid, and maintain the shared reconciliation platform and SLA proxy.
- Manage EUR 1.5B public budget execution: prepare quarterly financial reports showing cumulative spend per line (standards EUR 80M, clearing EUR 220M, adapters EUR 240M, concession EUR 300M, capacity building EUR 200M, consumer rollout EUR 100M, reserve EUR 150M), track variances against allocations, and recommend contingency triggers (EUR 100M, EUR 200M, EUR 300M) to the Steering Committee.
- Own technical audit and tier assignment: conduct the full audit of all 25+ carriers' booking systems by Month 2 (2026-12-12), assign carriers to tiers (Tier 1: Month 30 = 2029-04-12; Tier 2: Month 36 = 2029-10-12; Tier 3: Month 42 = 2030-04-12), and publish per-operator integration timelines and adapter funding allocations.
- Manage conformance testing and certification: operate test environments, conduct independent audits for OSDM API compliance, latency (p95 <2 seconds), availability (99.5%), stale-seat failures (<1%), and booking-error rates; publish monthly SLA scorecards by carrier; recommend funding tranche withholding for carriers missing SLAs for two consecutive months.
- Manage funding-tranche releases: verify milestone conditions (API exposure, conformance certificates, SLA targets) before authorizing each tranche; track clawback and subsidy-cap conditions for the concession; escalate funding-release delays or remediation needs to the Steering Committee.
- Coordinate standards-working groups: chair the technical working group on OSDM, liability model, clearing architecture, fare construction, disruption re-accommodation and ticket validation; prepare option papers and steering-group briefings; track standards progress against Month 18 (2028-04-12) deadline.
- Manage carrier and distributor engagement: conduct bilateral briefings with carriers on liability model, conformance requirements and funding tranches; mediate commission-rate disputes and discrimination complaints; manage fallback interfaces for distributors rejecting the clearing design.
- Oversee pilots and live validation: conduct live pilots of 500-1,000 passengers per corridor at Months 12-18 (2027-10-12 to 2028-04-12); track reroute response times, passenger satisfaction and re-accommodation success; manage validation deployment to corridor rolling stock and station gates by Month 40 (2030-02-12).
- Manage risk and issues: maintain a register of top risks and issues; track mitigation actions (e.g., DG COMP guidance letter, passenger-rights legal review, national regulator impact assessments); escalate risks reaching their trigger conditions (e.g., legislation delay, carrier participation drop) to the Steering Committee within five business days.

**Initial Setup Actions:**

- Appoint Programme Director and Operations Manager by Month 1 (2026-11-12); establish the Operational Management Board as a sub-committee of the Steering Committee with Chair (Programme Director), Secretary (Operations Manager), and representatives from Programme Office, Technical Secretariat, carrier leads and distributor lead.
- Commission the technical audit of all carriers' booking systems by Month 1 (2026-11-12); complete by Month 2 (2026-12-12).
- Establish the Programme Office (80 staff) and Technical Secretariat (50 staff) by Month 1 (2026-11-12); hire core staff for standards, conformance, clearing, adapters, capacity building and consumer rollout by Month 3 (2027-01-12).
- Procure shared reconciliation platform, SLA proxy and test-environment infrastructure by Month 3 (2027-01-12); deploy by Month 6 (2027-04-12).
- Commission carrier-liability actuarial study and competition-law pre-notification to DG COMP by Month 1 (2026-11-12).
- Establish and publish the quarterly financial reporting and variance-tracking process by Month 2 (2026-12-12).

**Membership:**

- Chair: Programme Director (DG MOVE, appointed by Month 1 = 2026-11-12)
- Secretary: Operations Manager (Programme Office, appointed by Month 1 = 2026-11-12)
- Head of Standards and Conformance (Technical Secretariat lead)
- Head of Clearing and Settlement (Programme Office, clearing function lead)
- Head of Carrier Engagement (Programme Office, liaison to CER and major carriers)
- Head of Distributor and Consumer Affairs (Programme Office, liaison to Trainline, Omio and last-resort concessionaire)
- Head of Compliance and Risk (Programme Office, legal, competition-law and passenger-rights lead)
- Representative from Financial Planning and Control (DG MOVE Finance)

**Decision Rights:** Operational decisions on budget execution below EUR 10M per line, milestone tracking, conformance-certification results, SLA scorecards, funding-tranche conditions (verification of milestone achievement), carrier tier assignment and adapter funding allocation, and pilot results. Decisions on funding tranches up to EUR 50M are delegated to the OMB; larger releases (EUR 80M Tier 1, EUR 80M Tier 2, EUR 50M Tier 3) require Steering Committee approval. Decisions on variance responses below EUR 50M (e.g., accelerating adapter schedules within existing budget, reallocating between standards and testing) are delegated; responses exceeding EUR 50M escalate to the Committee. Conformance-gate remediation (requiring carriers to retest, withholding tranches) is delegated; deferral of entire tiers or carriers from the programme escalates to the Steering Committee.

**Decision Mechanism:** Simple majority (at least 4 of 7 OMB members) for operational decisions. Consensus preferred for budget execution and milestone tracking to maintain transparency; if consensus is not reached, the Chair (Programme Director) decides, with written record to the Steering Committee within five business days. Any decision affecting the Steering Committee's strategic milestones (Month 18 = 2028-04-12, Month 30 = 2029-04-12, Month 48 = 2030-10-12) requires Steering Committee approval, not OMB-only decision. Tie-breaker: Programme Director casts deciding vote.

**Meeting Cadence:** Weekly during Phase 1 (Months 1-18 = 2026-11-12 to 2028-04-12) to maintain momentum on standards and readiness-gate prep; biweekly during Phase 2 (Months 18-48 = 2028-04-12 to 2030-10-12) to track API exposure, conformance and funding tranches; monthly during Phase 3 (Months 48-60 = 2030-10-12 to 2031-10-12) for TEN-T extension. Emergency sessions within two business days if a conformance audit fails, a carrier signals non-participation, or a funding variance reaches a trigger threshold.

**Typical Agenda Items:**

- Technical audit findings and carrier tier assignment (Month 2 = 2026-12-12).
- Standards-working group progress: OSDM specification, liability model, clearing architecture, fare construction, disruption choreography, ticket validation.
- Quarterly financial reports: cumulative spend per budget line, variance tracking, reserve balance, concession operating-cost and subsidy tracking, clawback calculations.
- Conformance audit results: monthly SLA scorecards by carrier, latency/availability/error-rate trends, remediation tracking for carriers missing targets, tranche-withholding recommendations.
- Funding-tranche verification: milestone-completion evidence (API exposure certificates, conformance certificates), conditions for next tranche release.
- Carrier and distributor engagement: feedback from bilateral briefings, commission-rate disputes, discrimination complaints, fallback-interface adoption.
- Pilot results: passenger satisfaction, reroute response times, accessibility issues, validation acceptance rates (by Month 18 = 2028-04-12).
- Risk and issue tracking: top 10 risks, mitigation status, trigger-condition monitoring, escalation flags.

**Escalation Path:** Funding variances above EUR 50M, conformance failures affecting entire tiers, carrier non-participation affecting corridor connectivity, or delays to Month 18/30/48/60 (2028-04-12, 2029-04-12, 2030-10-12, 2031-10-12) milestones escalate to the Steering Committee within two business days. Regulatory or competition-law blockers escalate to the Steering Committee's legal-escalation path (DG COMP, passenger-rights review). Unresolved carrier or distributor disputes escalate to the Steering Committee after 30 days. Budget variances reaching thresholds (EUR 100M, EUR 200M, EUR 300M) trigger automatic escalation to the Committee and a published variance-mitigation plan within ten business days.
### 3. Compliance, Competition Law and Passenger Rights Committee (CCPR)

**Rationale for Inclusion:** This is a regulation-aligned public infrastructure programme operating at the intersection of EU transport regulation (Digital Booking and Ticketing Regulation, passenger-rights regulation 1371/2007), competition law (Article 101 TFEU, data-sharing and clearing arrangements) and accessibility law (Regulation 1371/2007, EU Accessibility Directive). The programme creates several competition-law exposures: shared data exchange through a clearing layer, potential rate-fixing on commissions, and exclusive access to real-time inventory could trigger Article 101 scrutiny. Passenger-rights continuity across carriers, liability allocation, and assistance/bicycle-reservation guarantees must comply with existing law. Accessibility for persons with reduced mobility is a legal requirement with reputational and liability risk. A dedicated specialized body ensures systematic compliance monitoring, early escalation of legal risks, and documented due diligence that protects both the programme and participating carriers. This committee reports to the Steering Committee and the Commission's legal services.

**Responsibilities:**

- Secure and maintain DG COMP Article 101 guidance: manage pre-notification to DG COMP at Month 2 (2026-12-12), obtain formal guidance letter by Month 12 (2027-10-12), establish clean-team protocol for the clearing function by Month 14 (2027-12-12), and publish a compliance certificate by Month 18 (2028-04-12) confirming that data-sharing and clearing arrangements are compatible with competition rules.
- Monitor and ensure passenger-rights compliance: commission independent legal review of the Through-Ticket Liability and Rights Backstop design against EU Regulation 1371/2007 by Month 1 (2026-11-12), obtain opinion by Month 6 (2027-04-12), approve a detailed compliance manual by Month 9 (2027-07-12) covering assistance, rerouting, compensation and refund procedures that meet or exceed existing passenger-rights protections.
- Oversee accessibility compliance: establish accessibility thresholds (wheelchair access on ≥80% of services, assistance within ≤4 hours' notice on ≥90% of services) as a precondition of conformance; conduct usability testing with persons with reduced mobility by Month 18 (2028-04-12); publish annual accessibility audit results; establish fallback procedures for carriers unable to meet thresholds.
- Manage data governance and GDPR compliance: establish rules for handling commercially sensitive data (fares, inventory, settlement flows) within the clearing and data-sharing layers; ensure the shared reconciliation platform and disruption event feed comply with GDPR; publish a data-governance policy by Month 6 (2027-04-12); conduct annual GDPR impact assessments.
- Monitor national regulatory alignment: conduct bilateral regulatory-impact assessments per member state by Month 3 (2027-01-12) to identify conflicts between the programme's design and national railway regulations; escalate conflicts to the Steering Committee and national regulators for resolution by Month 12 (2027-10-12) or defer that member state's participation.
- Oversee discrimination and fair-access monitoring: audit commission-rate data published by the clearing function monthly to detect discrimination between distributor types; investigate complaints from distributors claiming unfair access or pricing; publish a discrimination-monitoring report quarterly; escalate substantive discrimination findings to national regulators.
- Document and audit compliance: maintain a compliance register tracking Article 101 guidance, passenger-rights legal opinions, accessibility certifications, GDPR assessments and discrimination audits; publish a biennial external audit by the Court of Auditors or contracted firm; produce quarterly compliance reports to the Steering Committee.

**Initial Setup Actions:**

- Establish the Committee and appoint Chair (external legal expert with EU competition and transport-law experience) by Month 1 (2026-11-12).
- Commission independent legal reviews: (1) Article 101 TFEU compatibility of data-sharing and clearing by Month 1 (2026-11-12); (2) Passenger-rights compliance against Regulation 1371/2007 by Month 1 (2026-11-12); (3) GDPR and data-governance assessment by Month 2 (2026-12-12); (4) Accessibility and EU Accessibility Directive compliance by Month 2 (2026-12-12).
- File Article 101 pre-notification with DG COMP by Month 2 (2026-12-12); request guidance letter by Month 12 (2027-10-12).
- Publish the compliance roadmap and quarterly compliance reporting schedule by Month 3 (2027-01-12).
- Conduct bilateral regulatory-impact assessments per member state (25+ operators across 5-6 member states) by Month 3 (2027-01-12).
- Establish a discrimination-monitoring protocol and data-audit schedule by Month 6 (2027-04-12) to track commission-rate data from the clearing function.

**Membership:**

- Chair: External EU competition and transport-law expert (appointed by Month 1 = 2026-11-12), independent of DG MOVE and DG COMP
- Legal Counsel from DG MOVE
- Legal Counsel from DG COMP (observer seat)
- Head of Passenger-Rights Compliance (commissioned external specialist)
- Head of Data Governance and GDPR (Programme Office or external specialist)
- Representative from the EU Agency for Railways (regulatory liaison)
- Observer: BEUC (consumer representative) (non-voting)

**Decision Rights:** Authority to approve compliance certifications (Article 101 guidance letter, passenger-rights legal opinion, accessibility audit results, GDPR assessments) before they are released to the Steering Committee and public. Authority to issue compliance warnings to the Steering Committee if Article 101 guidance is not obtained by Month 12 (2027-10-12) or passenger-rights review is not approved by Month 9 (2027-07-12). Authority to block the release of any programme milestone (binding standards, API exposure, corridor go-live) if a material compliance gap is not addressed. Authority to recommend discrimination investigations and escalations to national regulators. Authority to recommend Member-State participation deferrals if regulatory conflicts cannot be resolved by Month 12 (2027-10-12). Decisions on compliance policy (thresholds, audit schedules, reporting formats) are made by simple majority; escalations to the Steering Committee require Committee approval.

**Decision Mechanism:** Consensus preferred on compliance certifications to ensure rigorous review; if consensus is not reached within 10 business days, the Chair (external legal expert) makes the decision and documents dissenting views. Compliance warnings and block decisions require Chair approval only, issued immediately to the Steering Committee. All formal compliance opinions (Article 101, passenger-rights, accessibility, GDPR) must be signed off by the Chair and at least one other member before publication.

**Meeting Cadence:** Monthly during Phase 1 (Months 1-18 = 2026-11-12 to 2028-04-12) to track Article 101 guidance, passenger-rights review and accessibility compliance; quarterly during Phase 2 (Months 18-48 = 2028-04-12 to 2030-10-12) to monitor discrimination audits and national-regulator alignment; biannually during Phase 3 (Months 48-60 = 2030-10-12 to 2031-10-12) for final compliance audit. Emergency sessions within three business days if a compliance gap blocks a milestone or a discrimination complaint is escalated.

**Typical Agenda Items:**

- Article 101 guidance letter status and clean-team protocol approval (Months 2-18 = 2026-12-12 to 2028-04-12).
- Passenger-rights legal review findings and compliance-manual approval (Months 1-9 = 2026-11-12 to 2027-07-12).
- Accessibility audit results and thresholds enforcement (ongoing from Month 6 = 2027-04-12).
- GDPR and data-governance compliance for clearing and disruption event feed.
- National regulator impact assessments and conflict resolution (Months 3-12 = 2027-01-12 to 2027-10-12).
- Quarterly discrimination audits: commission-rate data analysis by distributor type, complaint investigation results, escalations to regulators.
- Compliance register and audit tracking: biennial external audit status, quarterly reporting to Steering Committee.

**Escalation Path:** Unresolved compliance gaps or failed Article 101 guidance by Month 12 (2027-10-12) escalate to the Commission Transport Commissioner and DG COMP for resolution; if unresolved by Month 18 (2028-04-12), binding standards are deferred. Material discrimination findings or national-regulator conflicts unresolved by Month 12 (2027-10-12) escalate to the Steering Committee; the Committee decides whether to defer that Member State or require programme redesign. Any compliance gap that would block a Steering Committee milestone decision (binding standards, API exposure, corridor go-live) is escalated to the Committee with a recommended remediation plan within five business days. Passenger-rights gaps discovered post-deployment (after Month 30 = 2029-04-12) escalate immediately to the Commission and the EU Agency for Railways for emergency remediation and passenger notification.
### 4. Technical Standards and Interoperability Working Group (TSWG)

**Rationale for Inclusion:** The programme depends on binding technical standards (OSDM-compatible APIs, real-time data formats, clearing settlement feeds, ticket validation credentials) by Month 18 (2028-04-12) and mandatory API exposure by Month 30 (2029-04-12). The TSWG must own specification development, conformance test design, reference implementation, carrier-integration support and change-control governance. This is a specialized operational and advisory body that reports to the Operational Management Board and the Steering Committee. Unlike the Steering Committee (which makes binding strategic decisions on liability and clearing architectures), the TSWG makes technical decisions on how those architectures are specified, tested and evolved. Without a dedicated technical body with clear authority over standards and conformance, the programme risks specification drift, inconsistent testing, and missed binding-standards deadlines.

**Responsibilities:**

- Develop and publish the binding OSDM specification: establish a formal change-control process (critical: 2-week review, major: 6-week review, minor: 8-week review) and quarterly release cadence; anchor specification custodianship in the EU Agency for Railways with an escrowed open-source copy; pin the version via delegated or implementing act by Month 18 (2028-04-12).
- Design and operate conformance testing: develop test cases for OSDM API compliance, latency (p95 <2 seconds), availability (99.5%), stale-seat failures (<1%), booking-error rates; establish independent test laboratories; conduct conformance audits for all carriers by Months 24, 30, 36, 42 (2028-10-12, 2029-04-12, 2029-10-12, 2030-04-12); publish certification results on a public registry.
- Maintain and evolve the reference implementation: develop a reference OSDM implementation as a sandbox and technical benchmark; publish it under open-source terms; use it to validate carrier integrations and test distributor client implementations; make it available to carriers for testing by Month 12 (2027-10-12).
- Coordinate carrier-integration support: chair technical working sessions with carrier integration teams monthly; provide guidance on OSDM adoption, API design patterns, and legacy system adaptation; identify common adapter bottlenecks and escalate to the Programme Office for shared-adapter development.
- Define and enforce SLA thresholds: establish and publish SLA targets for API latency, availability, error rates, and settlement-reconciliation accuracy; monitor monthly SLA scorecards; recommend funding-tranche withholding for carriers missing SLAs for two consecutive months.
- Specify ticket validation and credential formats: define the API handshake, barcode, or cryptographic token format for cross-carrier ticket validation; coordinate with conductor handheld and station-gate system upgrades; ensure validation works offline and across all participating carriers by Month 40 (2030-02-12).
- Coordinate disruption and real-time data specs: develop specifications for the shared disruption event feed, availability shadow architecture, and settlement data formats; ensure all are compatible with carrier billing systems and independent distributor platforms.
- Support accessibility and bicycle-reservation integration: work with disability-rights bodies to specify assistance and bicycle-space reservation schemas; ensure these are auditable and cannot be bypassed; validate via usability testing by Month 18 (2028-04-12).

**Initial Setup Actions:**

- Establish the Working Group and appoint Chair (senior OSDM expert) by Month 1 (2026-11-12).
- Publish the formal OSDM change-control process and quarterly release schedule by Month 3 (2027-01-12).
- Develop conformance test cases for OSDM API, latency, availability, error rates by Month 6 (2027-04-12); release test environments to carriers by Month 12 (2027-10-12).
- Commission or develop a reference OSDM implementation (sandbox) by Month 9 (2027-07-12); publish under open-source licence by Month 12 (2027-10-12).
- Establish public conformance-certification registry by Month 12 (2027-10-12); publish first carrier audit results by Month 24 (2028-10-12).
- Coordinate with carrier integration teams to identify and resolve common technical bottlenecks by Month 12 (2027-10-12); recommend shared-adapter development for legacy systems by Month 3 (2027-01-12).

**Membership:**

- Chair: Senior OSDM or rail-API technical expert (appointed by Month 1 = 2026-11-12), from the Technical Secretariat or external contractor
- OSDM specification custodian (EU Agency for Railways or delegated external body)
- Head of Conformance Testing (independent test laboratory or Programme Office)
- Representative from carrier IT (rotating among Tier 1 carriers: DB, SNCF, SBB, ÖBB, Renfe)
- Representative from independent distributor IT (Trainline or Omio)
- Reference-implementation lead (open-source steward or Programme Office)
- Accessibility specialist (disability-rights body or accessibility consultant) (non-voting observer)
- EU Agency for Railways technical liaison (regulatory perspective)

**Decision Rights:** Authority to approve OSDM specifications and versions for binding-standards release by Month 18 (2028-04-12). Authority to set and enforce conformance test cases, SLA thresholds (latency, availability, error rates) and certification requirements. Authority to approve or reject carrier conformance certifications; recommend to the Steering Committee funding-tranche withholding for non-certified carriers. Authority to make technical decisions on specification content (e.g., which OSDM fields are mandatory, how settlement data is formatted) without Steering Committee approval, provided they align with strategic decisions already made (liability model, clearing architecture). Authority to approve change requests to the pinned OSDM specification post-Month 18 (2028-04-12) within the formal change-control process. Decisions on conformance test design, test-case severity, and certification remediation timelines are made by simple majority; SLA threshold changes require Steering Committee approval if they affect milestone or budget assumptions.

**Decision Mechanism:** Consensus preferred on technical specifications to ensure carrier and distributor buy-in; if consensus is not reached within 15 business days, the Chair makes the decision, with documented dissent and escalation to the Operational Management Board within five business days. Conformance certification decisions require unanimous sign-off by the Chair and the independent test-laboratory representative to ensure impartiality. SLA threshold decisions require Steering Committee approval if they change targets or enforcement mechanisms; routine monitoring and reporting are delegated to the Chair without approval.

**Meeting Cadence:** Weekly during Phase 1 (Months 1-18 = 2026-11-12 to 2028-04-12) to develop specifications and test cases; biweekly during Phase 2 (Months 18-48 = 2028-04-12 to 2030-10-12) to oversee conformance audits and carrier integrations; monthly during Phase 3 (Months 48-60 = 2030-10-12 to 2031-10-12) for post-go-live specification evolution. Emergency sessions within two business days if a conformance audit fails or a critical specification gap is discovered that affects binding-standards release.

**Typical Agenda Items:**

- OSDM specification drafting and change-request review (Months 1-18 = 2026-11-12 to 2028-04-12).
- Conformance test-case design and validation (Months 3-12 = 2027-01-12 to 2027-10-12).
- Carrier integration support: common bottlenecks, adapter guidance, legacy-system compatibility.
- SLA monitoring: monthly latency/availability/error-rate scorecards by carrier, remediation tracking.
- Reference implementation development and validation (Months 6-18 = 2027-04-12 to 2028-04-12).
- Accessibility and bicycle-reservation schema design and usability testing (Months 6-18 = 2027-04-12 to 2028-04-12).
- Disruption event feed and settlement data-format specifications.
- Ticket-validation credential design and cross-carrier acceptance testing (Months 12-40 = 2027-10-12 to 2030-02-12).

**Escalation Path:** Unresolved specification disputes (e.g., carrier disagreement on a mandatory OSDM field) that block progress toward Month 18 (2028-04-12) escalate to the Operational Management Board within ten business days; if unresolved by the OMB, they escalate to the Steering Committee for binding decision. Conformance failures affecting ≥5 carriers or ≥1 Tier 1 corridor-critical carrier escalate to the Operational Management Board for remediation planning; if a carrier cannot remediate by their tier deadline (Month 30/36/42 = 2029-04-12, 2029-10-12, 2030-04-12), the OMB recommends deferral of that carrier to a later tier or programme phase. Specification changes post-Month 18 (2028-04-12) that affect binding-standards commitments or require carrier rework escalate to the Steering Committee for approval. SLA threshold violations affecting >20% of carriers or delaying corridor go-live escalate to the OMB and Steering Committee within five business days.

# Governance Implementation Plan

### 1. Project Sponsor (DG MOVE Director or Transport Commissioner) formally initiates the programme and designates a senior DG MOVE official as Interim Programme Director to lead pre-governance setup activities. Interim Director is responsible for establishing the governance framework, engaging stakeholders, and preparing for formal Committee establishment.

**Responsible Body/Role:** Project Sponsor / DG MOVE Director

**Suggested Timeframe:** Project Week 0-1 (by Month 0.2 = 2026-10-18)

**Key Outputs/Deliverables:**

- Programme Initiation Memo signed by Project Sponsor
- Interim Programme Director appointed and briefed
- High-level stakeholder contact list and engagement calendar established

**Dependencies:**

- Project start date confirmed
- Budget allocation (EUR 1.5B) formally approved by the Commission

### 2. Interim Programme Director drafts the charter, membership, voting rules, and meeting schedule for the Programme Steering Committee (PSC). The charter must specify 75% supermajority voting for Decisions 1–5, escalation paths to the Commission Transport Commissioner, and monthly biweekly cadence. Draft charter is circulated to identified steering members for consultation.

**Responsible Body/Role:** Interim Programme Director (DG MOVE)

**Suggested Timeframe:** Month 0.3-1 (October–November 2026)

**Key Outputs/Deliverables:**

- Draft PSC Charter v0.1 (roles, voting, escalation, meeting schedule)
- Membership roster and stakeholder contact details
- Consultation feedback summary

**Dependencies:**

- Interim Programme Director appointed
- Stakeholder list and preliminary engagement complete

### 3. Project Sponsor formally approves the PSC Charter and appoints the Chair (DG MOVE Director or Transport Commissioner designate) and Vice-Chair (EU Agency for Railways Director). Appointment letters are issued by Month 1 (2026-11-12); both assume office immediately.

**Responsible Body/Role:** Project Sponsor / DG MOVE Director

**Suggested Timeframe:** Month 1 (2026-11-12)

**Key Outputs/Deliverables:**

- PSC Charter (approved, published version)
- Chair Appointment Letter
- Vice-Chair Appointment Letter

**Dependencies:**

- Draft Charter consulted and finalized
- Project Sponsor and Transport Commissioner alignment secured

### 4. Chair (DG MOVE) and Vice-Chair (Agency) jointly circulate binding commitment letters to the nine core PSC members (CER, three–four major carriers, Trainline, Omio, BEUC, disability-rights body, and one regulator observer) requesting formal acceptance of their seat, voting responsibility, and biweekly attendance by Month 2 (2026-12-12).

**Responsible Body/Role:** PSC Chair and Vice-Chair

**Suggested Timeframe:** Month 1.2-1.5 (mid-November 2026)

**Key Outputs/Deliverables:**

- Formal invitation letters to nine core members
- Binding commitment letters from each member (confirming attendance, voting authority, confidentiality)
- Signed Member Roster

**Dependencies:**

- PSC Charter approved and published
- Chair and Vice-Chair in office

### 5. Chair and Vice-Chair confirm all nine core members have signed binding commitment letters and are formally appointed to the PSC by Month 2 (2026-12-12). A kick-off briefing is scheduled for Month 1.5 (2026-11-27) to introduce the Charter, voting procedures, critical decision timeline and escalation paths.

**Responsible Body/Role:** PSC Chair

**Suggested Timeframe:** Month 2 (2026-12-12)

**Key Outputs/Deliverables:**

- Confirmed Member Roster (all nine signatures)
- PSC Formally Established Memo
- Kick-off Meeting Minutes and attendee list

**Dependencies:**

- Commitment letters from all nine core members
- Charter approved

### 6. Interim Programme Director commissions a detailed technical audit of all 25+ participating carriers' booking-system architectures, assessing OSDM API readiness, event-streaming capability, transaction consistency, latency and availability benchmarks. Audit is contracted to an independent systems integrator and is scheduled for completion by Month 2 (2026-12-12).

**Responsible Body/Role:** Interim Programme Director / Programme Office (once established)

**Suggested Timeframe:** Month 0.5-2 (October 2026–December 2026)

**Key Outputs/Deliverables:**

- RFP issued for technical audit
- Audit contract awarded
- Technical Audit Report: summary of each carrier's API readiness, legacy-system constraints, estimated integration timeline per tier

**Dependencies:**

- Interim Programme Director in place
- Carrier contact list and preliminary engagement complete
- Budget headroom identified for audit cost

### 7. Interim Programme Director commissions an independent actuarial firm to model missed-connection rates, rerouting costs, incident clustering and liability-pool sustainability. The study is to establish per-incident caps, co-insurance thresholds and contribution-weighting formulas tied to on-time performance. Interim findings due Month 3 (2027-01-12); final report due Month 6 (2027-04-12).

**Responsible Body/Role:** Interim Programme Director / Programme Office

**Suggested Timeframe:** Month 1-3 (November 2026–January 2027)

**Key Outputs/Deliverables:**

- RFP issued for actuarial study
- Actuarial contract awarded
- Interim Actuarial Report (Month 3 = 2027-01-12): draft liability model, indicative cap and co-insurance thresholds
- Final Actuarial Report (Month 6 = 2027-04-12): validated model with confidence intervals

**Dependencies:**

- Budget allocated for actuarial study
- Interim Programme Director appointed

### 8. Interim Programme Director initiates formal pre-notification with DG COMP (Competition Directorate) outlining the programme's data-sharing and clearing arrangements, requesting Article 101 TFEU guidance. A detailed legal brief is submitted to DG COMP, including the proposed federated clearing architecture, shared data layer and non-discriminatory distributor-access rules.

**Responsible Body/Role:** Interim Programme Director / Compliance Lead (engaged as external counsel or DG MOVE legal service)

**Suggested Timeframe:** Month 2 (2026-12-12)

**Key Outputs/Deliverables:**

- Legal brief to DG COMP (pre-notification package)
- Formal request for Article 101 guidance letter
- Confirmation of receipt from DG COMP

**Dependencies:**

- Clearing and data-sharing architecture decisions made (from scenario inputs)
- Legal counsel engaged

### 9. Interim Programme Director commissions an independent legal firm to conduct a detailed review of the Through-Ticket Liability and Rights Backstop design against EU Regulation 1371/2007 (existing rail passenger-rights law). The review assesses whether the proposed guarantee pool and liability model ensure that through-ticket passengers retain or exceed existing passenger-rights protections. Opinion due Month 6 (2027-04-12).

**Responsible Body/Role:** Interim Programme Director / Compliance Lead

**Suggested Timeframe:** Month 1-6 (November 2026–April 2027)

**Key Outputs/Deliverables:**

- RFP issued for passenger-rights legal review
- Legal review contract awarded
- Passenger-Rights Legal Opinion (Month 6 = 2027-04-12): assessment of compliance with Regulation 1371/2007, identified gaps, remediation recommendations

**Dependencies:**

- Liability model design clarified (from scenario inputs)
- Independent legal counsel engaged

### 10. Interim Programme Director, with the EU Agency for Railways, commences bilateral regulatory-impact assessments with each participating member state (approximately 5–6 member states, 25+ operators). Each assessment documents national railway regulations, antitrust rules, data-protection requirements and any conflicts with the programme's design. Assessments are completed by Month 3 (2027-01-12).

**Responsible Body/Role:** Interim Programme Director and EU Agency for Railways

**Suggested Timeframe:** Month 2-3 (December 2026–January 2027)

**Key Outputs/Deliverables:**

- Regulatory-Impact Assessment per member state (template and filled versions)
- Summary of identified conflicts and escalation flags
- Preliminary member-state engagement calendar

**Dependencies:**

- Participating member states and operators identified
- EU Agency for Railways capacity available for bilateral work

### 11. Interim Programme Director drafts three strategic options for each of Decisions 1–5 (Liability Backstop, Clearing Architecture, Public Distributor Role, Funding Release Ladder, Availability Query Topology), explicitly laying out trade-offs, budget implications, timeline impacts and carrier/distributor implications. The option-papers document is circulated to PSC members by Month 2 (2026-12-12) to inform their deliberation.

**Responsible Body/Role:** Interim Programme Director / Programme Office

**Suggested Timeframe:** Month 1.5-2 (late November–early December 2026)

**Key Outputs/Deliverables:**

- Strategic Options Document: Decision 1–5 with three variants each, trade-off analysis, impact on schedule and budget

**Dependencies:**

- Scenario pathway selected (pragmatic foundation, from input documents)
- Key stakeholder preliminary positions gathered

### 12. Interim Programme Director establishes the Operational Management Board (OMB) as a sub-committee of the PSC, appointing its Chair (Programme Director, full-time DG MOVE official) and Secretary (Operations Manager). The OMB Charter is drafted, specifying roles, weekly cadence during Phase 1, and escalation thresholds (€10M budget authority, milestone-tracking delegation). The Charter is circulated to OMB members for binding acceptance by Month 1.5 (2026-11-27).

**Responsible Body/Role:** PSC Chair and Interim Programme Director

**Suggested Timeframe:** Month 1-1.5 (November 2026)

**Key Outputs/Deliverables:**

- OMB Charter (roles, responsibilities, decision thresholds, meeting cadence)
- OMB Chair and Secretary appointments
- OMB Member roster (7 members) with binding commitment letters

**Dependencies:**

- PSC formally established
- Programme Director appointed (full-time)

### 13. Interim Programme Director appoints the Head of Standards and Conformance (Technical Secretariat lead at the Agency) and commissions the Technical Standards and Interoperability Working Group (TSWG). The TSWG Chair (senior OSDM expert) is appointed; membership includes carrier IT leads, distributor representatives, accessibility specialists and the Agency liaison. TSWG Charter is published by Month 1.5 (2026-11-27); first meeting held by Month 3 (2027-01-12).

**Responsible Body/Role:** Interim Programme Director and EU Agency for Railways

**Suggested Timeframe:** Month 1-3 (November 2026–January 2027)

**Key Outputs/Deliverables:**

- TSWG Charter (roles, decision authority, specification change-control process)
- TSWG Chair and membership roster
- Published OSDM change-control process (2-week critical, 6-week major, 8-week minor review timelines; quarterly release cadence)
- TSWG kick-off meeting minutes

**Dependencies:**

- EU Agency for Railways confirmed as OSDM custodian
- Technical expertise identified and available

### 14. Interim Programme Director appoints the Chair of the Compliance, Competition Law and Passenger Rights Committee (CCPR). The Chair is an external EU competition and transport-law expert, independent of DG MOVE and DG COMP. The CCPR Charter is drafted, specifying roles, decision authority (compliance certification, warnings, blocks), and monthly cadence during Phase 1. Charter is published by Month 1.5 (2026-11-27); membership letters issued to legal counsel, GDPR specialist, accessibility lead and BEUC observer by Month 2 (2026-12-12).

**Responsible Body/Role:** PSC Chair and Interim Programme Director

**Suggested Timeframe:** Month 1-2 (November–December 2026)

**Key Outputs/Deliverables:**

- CCPR Charter (roles, decision authority, escalation rules, quarterly reporting)
- CCPR Chair appointment (external legal expert, independent)
- CCPR Member roster (7 members) with binding commitment letters
- Compliance Roadmap (quarterly reporting schedule, legal-opinion milestones)

**Dependencies:**

- External legal expertise sourced (competition law, transport law, GDPR)
- PSC established with governance authority

### 15. Interim Programme Director establishes the Programme Office as a dedicated unit within DG MOVE, aiming for 80 staff (range 60–100). Initial staffing includes Programme Director, Operations Manager, Head of Standards and Conformance, Head of Clearing and Settlement, Head of Carrier Engagement, Head of Distributor and Consumer Affairs, Head of Compliance and Risk, and Financial Planning lead. Job descriptions are finalized by Month 1.5 (2026-11-27); recruitment begins immediately. Core staff onboarded by Month 3 (2027-01-12).

**Responsible Body/Role:** Interim Programme Director / DG MOVE HR and Budget

**Suggested Timeframe:** Month 1-3 (November 2026–January 2027)

**Key Outputs/Deliverables:**

- Programme Office Organizational Chart
- Job descriptions for 8–10 key roles
- Recruitment plan and timeline
- Initial staffing contracts signed (core team by Month 3 = 2027-01-12)

**Dependencies:**

- Budget allocated for programme management (EUR 75M)
- Interim Programme Director appointed
- DG MOVE HR approval secured

### 16. Interim Programme Director coordinates with the EU Agency for Railways to establish the Technical Secretariat (approximately 50 staff, range 40–60) at the Agency's Valenciennes headquarters. The Secretariat houses standards work, conformance testing, OSDM change control, and serves as the technical backbone for the programme. Organizational structure, staffing plan and budget are finalized by Month 2 (2026-12-12); recruitment begins Month 1.5 (2026-11-27). Core staff onboarded by Month 4 (2027-02-12).

**Responsible Body/Role:** EU Agency for Railways Director and Programme Director

**Suggested Timeframe:** Month 1-4 (November 2026–February 2027)

**Key Outputs/Deliverables:**

- Technical Secretariat Organizational Chart
- Staffing plan and job descriptions
- Budget allocation (from EUR 75M programme-management envelope) confirmed
- Recruitment contracts signed (core team by Month 4 = 2027-02-12)

**Dependencies:**

- EU Agency for Railways committed to hosting the Secretariat
- Budget headroom allocated
- Agency HR and governance approval

### 17. Programme Director (now in full-time office) establishes four physical liaison hubs in Brussels (EU institutions), Valenciennes (Agency), Berlin (carrier IT and corridor access), and Madrid (air-competitive corridor pilots). One full-time liaison officer is stationed at each hub by Month 3 (2027-01-12) to coordinate local stakeholder engagement, oversee pilots, and support async decision-making. Liaison roles are staffed from the Programme Office headcount budget.

**Responsible Body/Role:** Programme Director / Programme Office HR

**Suggested Timeframe:** Month 2-3 (December 2026–January 2027)

**Key Outputs/Deliverables:**

- Liaison hub locations and office arrangements confirmed
- Four liaison officer job descriptions and recruitment initiated
- Liaison officers onboarded (Month 3 = 2027-01-12)
- Hub communications infrastructure (video conferencing, secure networks) deployed

**Dependencies:**

- Physical location agreements reached
- Programme Office staffing plan includes liaison positions
- Budget allocated for travel and liaison staffing

### 18. PSC Chair schedules the first formal PSC meeting for Month 1.5 (2026-11-27), with a second follow-up meeting by Month 2 (2026-12-12). The agenda covers: (1) adoption of the PSC Charter and voting procedures; (2) circulation of the strategic options document (Decisions 1–5); (3) briefing on the technical audit and actuarial study timelines; (4) introduction of the OMB, TSWG and CCPR; (5) confirmation of biweekly meeting schedule through Month 6 (2027-04-12). Meeting minutes and attendance are published within 15 days.

**Responsible Body/Role:** PSC Chair

**Suggested Timeframe:** Month 1.5-2 (late November–early December 2026)

**Key Outputs/Deliverables:**

- PSC Meeting Agenda and briefing materials
- PSC Meeting Minutes (first and second meetings)
- Confirmed biweekly meeting schedule through Month 6 (2027-04-12)
- Published voting procedures and decision-record template

**Dependencies:**

- PSC formally established
- All nine core members committed and briefed
- PSC Chair and Secretary in office

### 19. CCPR Chair commissions four independent legal studies in parallel: (1) Article 101 TFEU compatibility of data-sharing and clearing; (2) passenger-rights compliance against Regulation 1371/2007; (3) GDPR and data-governance assessment; (4) accessibility and EU Accessibility Directive compliance. RFPs are issued by Month 1.5 (2026-11-27); contracts awarded by Month 2 (2026-12-12). Studies are scheduled for completion by Month 6 (2027-04-12) (interim findings available Month 3 = 2027-01-12).

**Responsible Body/Role:** CCPR Chair and Compliance Lead

**Suggested Timeframe:** Month 1.5-2 (late November–December 2026)

**Key Outputs/Deliverables:**

- RFPs issued for four legal studies
- Contracts awarded to independent legal firms
- Study schedules with interim and final milestones
- Interim findings briefing (Month 3 = 2027-01-12)

**Dependencies:**

- CCPR Chair appointed and in office
- Budget allocated for legal counsel (from programme-management envelope)
- CCPR Charter approved

### 20. Technical Secretariat Head (once onboarded by Month 3 = 2027-01-12) procures shared infrastructure for standards work, conformance testing and real-time monitoring: (1) shared reconciliation platform for settlement data (EUR 20–40M estimate, part of EUR 220M clearing budget); (2) SLA monitoring proxy for latency/availability/error-rate tracking (EUR 5–10M estimate, part of EUR 50M real-time layer budget); (3) test environments and conformance-testing infrastructure; (4) distributed caching layer for the availability shadow (EUR 15–25M estimate, part of EUR 50M real-time layer budget). RFPs issued by Month 3 (2027-01-12); contracts awarded by Month 4 (2027-02-12); deployment target Month 6 (2027-04-12).

**Responsible Body/Role:** Technical Secretariat Head and Head of Standards and Conformance

**Suggested Timeframe:** Month 3-6 (January–April 2027)

**Key Outputs/Deliverables:**

- RFPs and procurement strategy for shared infrastructure
- Contracts awarded for reconciliation platform, SLA proxy, test environments and caching layer
- Infrastructure deployment timeline and success criteria
- Initial SLA monitoring proxy live (limited carrier data, Month 6 = 2027-04-12)

**Dependencies:**

- Technical Secretariat staffed
- Budget allocated for infrastructure (EUR 270M total across clearing and real-time layer)
- Carrier data-feed pilots defined

### 21. Programme Director commissions external advisors to conduct a survey of Trainline, Omio and 5–10 smaller independent distributors to establish their cost-of-acquisition, customer-support, and payment-processing costs for cross-border through-tickets. The survey informs the Distribution Remuneration and Commission Corridor decision by establishing a cost-based commission band. Survey issued Month 2 (2026-12-12); results available Month 4 (2027-02-12); band recommendation ready for PSC decision by Month 6 (2027-04-12).

**Responsible Body/Role:** Programme Director and Head of Distributor and Consumer Affairs

**Suggested Timeframe:** Month 2-6 (December 2026–April 2027)

**Key Outputs/Deliverables:**

- Distributor survey RFP and questionnaire
- Survey completion and data analysis (Month 4 = 2027-02-12)
- Commission-band recommendation (proposed 2.5–4.5% of through-fare, or variant based on survey findings) ready for PSC approval (Month 6 = 2027-04-12)

**Dependencies:**

- Distributor contacts and willingness to participate confirmed
- Budget for survey consultant
- Programme Director and OMB established to frame the survey

### 22. Programme Director issues an RFP for the development of a reference OSDM implementation (sandbox and technical benchmark). The sandbox serves as a reference for carrier integration, a conformance test target and a basis for distributor client testing. RFP issued Month 2 (2026-12-12); contract awarded Month 3 (2027-01-12); initial sandbox delivered by Month 9 (2027-07-12); public release (open-source) by Month 12 (2027-10-12) to make it available to carriers for testing before Tier 1 conformance audits begin (Month 24 = 2028-10-12).

**Responsible Body/Role:** Technical Secretariat Head / TSWG Chair

**Suggested Timeframe:** Month 2-12 (December 2026–October 2027)

**Key Outputs/Deliverables:**

- RFP for reference OSDM implementation
- Sandbox development contract awarded
- Reference OSDM Sandbox v1.0 (private, Month 9 = 2027-07-12)
- Public Release (open-source, Month 12 = 2027-10-12)

**Dependencies:**

- OSDM specification defined (from TSWG work)
- Budget allocated for development (part of EUR 80M standards/conformance)
- Technical Secretariat capacity available

### 23. TSWG Chair, in consultation with participating carriers, publishes the formal OSDM change-control process and quarterly release schedule. The process specifies review timelines (critical: 2 weeks, major: 6 weeks, minor: 8 weeks), governance (technical review by at least three independent carriers, competition-law check for sensitive changes), version numbering and archiving. The process is published by Month 3 (2027-01-12); first quarterly release planned for Month 6 (2027-04-12). This process remains in effect post-binding standards (Month 18 = 2028-04-12) as the basis for specification evolution.

**Responsible Body/Role:** TSWG Chair and Technical Secretariat Head

**Suggested Timeframe:** Month 1-3 (November 2026–January 2027)

**Key Outputs/Deliverables:**

- OSDM Change-Control Process (published document with review timelines, approval gates, versioning rules)
- Quarterly Release Calendar
- Change-request dashboard template

**Dependencies:**

- TSWG established
- OSDM custodianship (EU Agency for Railways) confirmed
- Carrier input on process acceptability gathered

### 24. Programme Director and Head of Carrier Engagement conduct bilateral briefings with the ten largest carriers (DB, SNCF, Renfe, SBB, ÖBB, NS, SJ, Trenitalia, CFF, Ferrovie dello Stato or others based on network position) to introduce the programme, the technical audit, and the liability-model development timeline. Briefings take place during Months 2–3 (December 2026–January 2027); participants are offered observer seats on TSWG and invited to nominate IT representatives for the technical working group. Feedback is documented for incorporation into the actuarial study and liability model.

**Responsible Body/Role:** Programme Director and Head of Carrier Engagement

**Suggested Timeframe:** Month 2-3 (December 2026–January 2027)

**Key Outputs/Deliverables:**

- Bilateral briefing agenda and talking points
- Briefing attendance and feedback summary (per carrier)
- Carrier IT representative nominations for TSWG
- Preliminary carrier concerns and constraints documented

**Dependencies:**

- Programme Director in office
- Carrier contact list and availability confirmed
- Strategic options document and technical audit findings ready to share

### 25. TSWG Chair develops detailed conformance test cases for OSDM API compliance, latency (p95 <2 seconds proposed threshold), availability (99.5% proposed threshold), stale-seat failures (<1% proposed threshold), and booking-error rates. Test-case design is informed by carrier input and the reference OSDM implementation. Draft test cases are ready for review by Month 6 (2027-04-12); final test cases published by Month 12 (2027-10-12). Test environments are made available to Tier 1 carriers by Month 12 (2027-10-12) to begin integration testing before formal conformance audits (Month 24 = 2028-10-12).

**Responsible Body/Role:** TSWG Chair and Head of Standards and Conformance

**Suggested Timeframe:** Month 3-12 (January–October 2027)

**Key Outputs/Deliverables:**

- Conformance Test-Case Specification (API compliance, latency, availability, error-rate criteria)
- Test Environment Setup and Carrier Access Guidelines
- Public Conformance-Certification Registry (template, ready by Month 12 = 2027-10-12)

**Dependencies:**

- OSDM specification drafted or stabilized
- Reference OSDM implementation available for alignment
- Carrier and distributor input on test criteria gathered

### 26. Technical Audit Lead (contracted independent firm or Programme Office technical team) completes the detailed technical audit of all 25+ participating carriers' booking-system architectures and publishes the Technical Audit Report by Month 2 (2026-12-12). The report documents each carrier's API readiness, event-streaming capability, transaction consistency, latency benchmarks, availability data and estimated integration timeline. Carriers are assigned to three tiers: Tier 1 (large, corridor-critical, ready by Month 30 = 2029-04-12); Tier 2 (regional, ready Month 36 = 2029-10-12); Tier 3 (small, legacy-heavy, ready Month 42 = 2030-04-12).

**Responsible Body/Role:** Interim Programme Director / Programme Office (with contracted audit firm)

**Suggested Timeframe:** Month 0.5-2 (October–December 2026)

**Key Outputs/Deliverables:**

- Technical Audit Report: per-carrier assessment, tier assignment rationale, estimated integration timeline per tier
- Carrier Tier Assignment List (Tier 1, Tier 2, Tier 3)

**Dependencies:**

- Audit contract awarded (Month 1 = 2026-11-12)
- Carrier data and system access provided

### 27. Programme Director and OMB establish a published quarterly financial reporting and budget-variance tracking process. Reports track cumulative spend per budget line (standards EUR 80M, clearing EUR 220M, adapters EUR 240M, concession EUR 300M, capacity building EUR 200M, consumer rollout EUR 100M, programme management EUR 75M, reserve EUR 150M, headroom EUR 85M). Variance triggers at EUR 100M, EUR 200M and EUR 300M are defined with automatic escalation and mitigation actions. First financial baseline is published by Month 3 (2027-01-12); monthly tracking begins Month 4 (2027-02-12).

**Responsible Body/Role:** OMB Chair (Programme Director) and Financial Planning Lead

**Suggested Timeframe:** Month 2-3 (December 2026–January 2027)

**Key Outputs/Deliverables:**

- Quarterly Financial Reporting Template and Process (published)
- Budget Baseline by Line (EUR 1,500M total allocation)
- Variance Trigger Matrix (EUR 100M/200M/300M thresholds with mitigation rules)
- Initial Financial Baseline Report (Month 3 = 2027-01-12)

**Dependencies:**

- Programme Office established
- OMB operational
- Budget allocation confirmed by the Commission

### 28. Programme Director issues an RFP for the Tier 1 carrier-adapter modules (shared code, middleware, API adapters for large carriers' legacy booking systems). RFP issued Month 2 (2026-12-12); contracts awarded Month 6 (2027-04-12); adapter modules procured by Month 12 (2027-10-12) (EUR 30M estimate for shared modules, part of EUR 240M adapter budget). These modules are made available to all Tier 1 carriers to accelerate their Month 30 (2029-04-12) API exposure deadline.

**Responsible Body/Role:** Programme Director and Head of Carrier Engagement

**Suggested Timeframe:** Month 2-12 (December 2026–October 2027)

**Key Outputs/Deliverables:**

- Adapter RFP and technical specifications
- Adapter development contracts awarded (Month 6 = 2027-04-12)
- Shared Adapter Module v1.0 (Tier 1, Month 12 = 2027-10-12)
- Adapter Deployment Guide and Support Package

**Dependencies:**

- Technical audit completed with tier assignments
- Budget allocated for adapters (EUR 240M total)
- Carrier input on common integration bottlenecks

### 29. Interim Programme Director issues an RFP for the business case and financial model of the last-resort public distributor concession, including volume forecasts, cost benchmarks, margin assumptions, operating-cost estimates and subsidy-cap analysis (target EUR 60M over five years, proposed threshold). RFP issued Month 6 (2027-04-12); business case completed by Month 9 (2027-07-12); formal concession tender issued by Month 12 (2027-10-12) (per the pragmatic scenario, a tendered last-resort concession, not a full public booking service).

**Responsible Body/Role:** Programme Director and Head of Distributor and Consumer Affairs

**Suggested Timeframe:** Month 6-12 (April–October 2027)

**Key Outputs/Deliverables:**

- Business Case RFP
- Business Case Report (Month 9 = 2027-07-12): volume forecasts, cost benchmarks, subsidy analysis
- Concession Tender RFP (Month 12 = 2027-10-12)
- Concession Service-Level Terms (availability, response time, complaint handling SLAs)

**Dependencies:**

- Strategic decision on public distributor role finalized (Decision 3)
- Distributor survey data on costs available (Month 4 = 2027-02-12)
- Budget envelope confirmed (EUR 300M, of which EUR 60M operating subsidy over five years)

### 30. PSC holds an interim decision-readiness review at Month 3 (2027-01-12). The review assesses progress on the four preparatory studies: (1) technical audit (interim findings from Month 2 = 2026-12-12); (2) actuarial study (interim findings available); (3) passenger-rights legal review (interim findings available); (4) DG COMP pre-notification status. The OMB and CCPR brief the PSC on any blockers or schedule risks. The PSC confirms that the Month 6 (2027-04-12) binding-vote readiness gate is on track or reschedules if critical inputs are delayed.

**Responsible Body/Role:** PSC Chair and Programme Director

**Suggested Timeframe:** Month 3 (2027-01-12)

**Key Outputs/Deliverables:**

- PSC Interim Review Meeting Agenda
- Interim findings briefing from OMB, CCPR and TSWG
- Readiness Assessment (are Month 6 = 2027-04-12 binding votes achievable?)
- PSC Meeting Minutes with any schedule adjustments

**Dependencies:**

- Interim findings from technical audit, actuarial study, legal reviews available
- DG COMP pre-notification acknowledged

### 31. OMB identifies common carrier integration bottlenecks through TSWG technical working sessions (Months 2–3 = December 2026–January 2027). Based on the technical audit and carrier feedback, the OMB proposes specific shared-adapter development for legacy event-streaming, transaction-consistency and federation-layer issues. Adapter-development recommendations are documented in a Carrier Support Plan issued by Month 3 (2027-01-12).

**Responsible Body/Role:** TSWG Chair and Head of Carrier Engagement

**Suggested Timeframe:** Month 2-3 (December 2026–January 2027)

**Key Outputs/Deliverables:**

- Common Bottleneck Summary (from technical audit and carrier briefings)
- Carrier Support Plan: recommended shared-adapter modules, development timeline, cost estimate
- Adapter scope aligned with EUR 240M budget allocation

**Dependencies:**

- Technical audit completed
- Carrier bilateral briefings conducted
- TSWG technical working sessions convened

### 32. Programme Director drafts the Compliance and Risk Register, tracking the top 10–15 programme risks (as documented in the assumptions and risk-assessment sections of the input). The register includes: risk description, trigger condition, probability, impact, mitigation action, owner, and escalation path. The register is published by Month 3 (2027-01-12) and updated monthly by the OMB and CCPR. Risks reaching trigger conditions are escalated to the PSC within five business days.

**Responsible Body/Role:** Programme Director and Head of Compliance and Risk

**Suggested Timeframe:** Month 2-3 (December 2026–January 2027)

**Key Outputs/Deliverables:**

- Compliance and Risk Register (template and initial population)
- Risk Trigger Definitions and Escalation Procedures
- Monthly Risk Update Report (starting Month 4 = 2027-02-12)

**Dependencies:**

- Risk assessments from input documents reviewed and prioritized
- Ownership and escalation paths assigned
- Programme Office structure in place to track

### 33. CCPR Chair briefs the PSC at Month 4 (2027-02-12) on the status of four legal studies: (1) Article 101 TFEU guidance letter from DG COMP (expected Month 12 = 2027-10-12, track whether on schedule); (2) passenger-rights legal opinion (interim findings Month 3 = 2027-01-12, final Month 6 = 2027-04-12); (3) GDPR and data-governance assessment (interim findings Month 3 = 2027-01-12); (4) accessibility compliance review (interim findings Month 3 = 2027-01-12). Any legal gaps that could block binding-standards approval (Month 18 = 2028-04-12) are escalated to the PSC for remediation planning.

**Responsible Body/Role:** CCPR Chair

**Suggested Timeframe:** Month 4 (2027-02-12)

**Key Outputs/Deliverables:**

- Compliance Status Briefing to PSC
- Legal Studies Progress Report: timeline risks, interim findings, remediation actions
- Escalation flags (if any legal review is delayed or identifies blocking issues)

**Dependencies:**

- CCPR established
- Legal studies contracted and underway
- Interim findings available from studies

### 34. Programme Director conducts the Month 6 (2027-04-12) readiness gate, a formal milestone assessment that determines whether the programme can proceed to binding-standards finalization (target Month 18 = 2028-04-12). The gate requires: (1) liability model signed by at least 8 major carriers and CER; (2) technical audit and tier assignment published; (3) passenger-rights legal opinion approved; (4) DG COMP Article 101 guidance on track for Month 12 (2027-10-12); (5) steering votes on Decisions 1–5 scheduled for Month 6 (2027-04-12) PSC meeting. If gate conditions are not met by Month 6 (2027-04-12), the binding-standards milestone is deferred to Month 12 (2027-10-12) or later, risking cascade delays to Month 30 (2029-04-12) API exposure and Month 48 (2030-10-12) corridor go-live.

**Responsible Body/Role:** Programme Director and OMB

**Suggested Timeframe:** Month 6 (2027-04-12)

**Key Outputs/Deliverables:**

- Month 6 (2027-04-12) Readiness Gate Assessment Report
- Liability Model (final, with carrier signatures confirming cap, co-insurance and contribution thresholds)
- Passenger-Rights Legal Opinion (approved by CCPR and Agency)
- Gate Go/No-Go Decision and escalation (if delayed)

**Dependencies:**

- Actuarial study completed (final, Month 6 = 2027-04-12)
- Carrier sign-offs on liability model (Month 4 = 2027-02-12)
- Legal reviews substantially complete
- DG COMP guidance letter confirmed on track for Month 12 (2027-10-12)

### 35. PSC holds a critical binding-vote meeting at Month 6 (2027-04-12) to approve Decisions 1–5 (Through-Ticket Liability and Rights Backstop, Inter-Carrier Clearing and Single-Payment Settlement, Public Reference Distributor Mandate, Milestone-Conditioned Funding Release Ladder, Availability Query Topology). Voting requires 75% supermajority (at least 7 of 9 core members). The Chair documents all votes and dissents. If a vote falls below 75%, the issue is escalated to the Commission Transport Commissioner with a mediation request by Month 5 (2027-03-12), and mediation is completed by Month 6 (2027-04-12) or a fallback governance path is invoked. Meeting minutes and voting record are published within 15 days (redacting sensitive data).

**Responsible Body/Role:** PSC Chair

**Suggested Timeframe:** Month 6 (2027-04-12)

**Key Outputs/Deliverables:**

- PSC Meeting Agenda and decision dossiers for Decisions 1–5
- Binding Vote Record (per decision, supermajority confirmation, dissent documentation)
- Mediation Brief (if any decision deadlocked, sent to Transport Commissioner by Month 5 = 2027-03-12)
- PSC Meeting Minutes (published within 15 days, redacted as needed)
- Approved Decision Summaries (for public release)

**Dependencies:**

- Month 6 (2027-04-12) readiness gate passed
- All preparatory studies completed and briefed
- PSC Charter voting procedures established and understood by members
- Liability model carrier sign-offs secured

### 36. CCPR Chair commissions a detailed legal review of the approved liability model against EU Regulation 1371/2007 to ensure that through-ticket passengers are not disadvantaged compared to single-carrier passengers. If gaps are found, a remediation plan is prepared by Month 9 (2027-07-12). The CCPR approves a detailed Compliance Manual covering assistance, rerouting, compensation and refund procedures that comply with or exceed Regulation 1371/2007. The manual is formally approved by the EU Agency for Railways by Month 9 (2027-07-12) before any pilot deployment begins (Months 12–18 = 2027-10-12 to 2028-04-12).

**Responsible Body/Role:** CCPR Chair and Head of Compliance and Risk

**Suggested Timeframe:** Month 6-9 (April–July 2027)

**Key Outputs/Deliverables:**

- Legal Review of Liability Model against Regulation 1371/2007
- Passenger-Rights Compliance Manual (procedures for assistance, rerouting, compensation, refunds)
- Agency Approval of Compliance Manual (Month 9 = 2027-07-12)
- Remediation Plan (if gaps identified)

**Dependencies:**

- Decisions 1–5 approved (Month 6 = 2027-04-12)
- Liability model finalized and signed by carriers
- CCPR Chair and compliance expertise in place

### 37. Technical Secretariat Head, in coordination with TSWG, begins drafting the binding OSDM specification covering: (1) API definitions for availability queries, booking, settlement, disruption and ticket validation; (2) real-time data formats for the streamed availability shadow; (3) settlement data-feed standards (reconciliation format, currency, timing); (4) assistance and bicycle-space reservation schemas; (5) ticket-validation credential or token formats. Draft specification is published by Month 9 (2027-07-12) for carrier and distributor review; public consultation period runs Months 9–12 (2027-07-12 to 2027-10-12); final specification approved by TSWG by Month 12 (2027-10-12).

**Responsible Body/Role:** TSWG Chair and Head of Standards and Conformance

**Suggested Timeframe:** Month 6-12 (April–October 2027)

**Key Outputs/Deliverables:**

- OSDM Binding Specification Draft v0.1 (Month 9 = 2027-07-12)
- Public Consultation Summary and feedback incorporation (Months 9–12 = 2027-07-12 to 2027-10-12)
- OSDM Binding Specification Final v1.0 (approved by TSWG, Month 12 = 2027-10-12)

**Dependencies:**

- Strategic decisions on clearing, availability topology and liability model finalized (Decisions 1–5, Month 6 = 2027-04-12)
- Reference OSDM implementation and test cases under development
- Carrier and distributor input gathered via bilateral briefings

### 38. CCPR Chair tracks DG COMP's Article 101 guidance-letter process. DG COMP pre-notification was filed at Month 2 (2026-12-12). Formal guidance letter is expected by Month 12 (2027-10-12). If guidance is not received on schedule, CCPR issues a compliance warning to the PSC by Month 12 (2027-10-12). Regardless, the CCPR establishes a clean-team protocol for the clearing function (physically and logically separating the clearing team from carriers and distributors, releasing only aggregated settlement data) by Month 14 (2027-12-12), to ensure that clearing operations are protected from competition-law challenges even if formal guidance is delayed beyond Month 18 (2028-04-12) binding-standards deadline.

**Responsible Body/Role:** CCPR Chair and Head of Compliance and Risk

**Suggested Timeframe:** Month 6-18 (April 2027–April 2028)

**Key Outputs/Deliverables:**

- DG COMP Engagement Log (pre-notification status, guidance-letter timeline, any clarifications requested)
- DG COMP Compliance Warning (issued to PSC if guidance not on track by Month 12 = 2027-10-12)
- Clean-Team Protocol for Clearing Function (published by Month 14 = 2027-12-12)
- Clearing Function Charter (operational rules, data firewalls, aggregated reporting only)

**Dependencies:**

- DG COMP pre-notification filed at Month 2 (2026-12-12)
- CCPR Chair has direct communication line to DG COMP
- Clearing architecture finalized (Decision 2, Month 6 = 2027-04-12)

### 39. Programme Director issues an RFP for the operational manual for disruption re-accommodation and passenger-assistance procedures covering all participating carriers on the four priority corridors. The manual specifies: (1) missed-connection detection and escalation triggers; (2) reroute-proposal procedures and seat-access protocols; (3) passenger communication and staff training requirements; (4) assistance escalation and onboard/station procedures; (5) compensation processing through the clearing mechanism. Draft manual is ready by Month 9 (2027-07-12); Agency review and approval by Month 9 (2027-07-12); final manual published by Month 12 (2027-10-12) for carrier implementation before pilots begin (Months 12–18 = 2027-10-12 to 2028-04-12).

**Responsible Body/Role:** Head of Carrier Engagement and Compliance Lead

**Suggested Timeframe:** Month 6-12 (April–October 2027)

**Key Outputs/Deliverables:**

- Disruption Re-accommodation Operational Manual (draft Month 9 = 2027-07-12, final Month 12 = 2027-10-12)
- Agency approval and publication
- Carrier implementation checklist and training materials

**Dependencies:**

- Decisions 1–5 approved (liability, clearing, disruption choreography)
- Passenger-rights compliance manual approved
- Carrier input on procedures and constraints gathered

### 40. CCPR Chair assembles the accessibility compliance requirements and conduct usability testing with persons with reduced mobility to assess the programme's assistance and bicycle-reservation design. Testing is contracted to accessibility specialists and conducted with representative users from disability-rights bodies. Initial findings available by Month 12 (2027-10-12); full usability-testing report by Month 18 (2028-04-12). Thresholds for conformance are defined: wheelchair access on at least 80% of services (proposed threshold), assistance within 4 hours' notice on at least 90% of services (proposed threshold).

**Responsible Body/Role:** CCPR Chair and accessibility specialist (contractor)

**Suggested Timeframe:** Month 6-18 (April 2027–April 2028)

**Key Outputs/Deliverables:**

- Accessibility Usability-Testing Plan and RFP (Month 6 = 2027-04-12)
- Accessibility Test Report (Month 18 = 2028-04-12): findings, user feedback, conformance thresholds
- Accessibility Compliance Thresholds (published for conformance gate enforcement)

**Dependencies:**

- Assistance and bicycle-reservation specifications drafted
- Disability-rights bodies engaged as testers
- Budget allocated for testing (part of EUR 100M consumer rollout)

### 41. Programme Director opens test environments and conformance-testing access to Tier 1 carriers by Month 12 (2027-10-12). Test environments include the reference OSDM implementation, shared adapters, SLA monitoring proxy and conformance test cases. Carriers are invited to begin integration testing of their legacy systems and APIs. Support sessions are held biweekly (managed by Head of Carrier Engagement) to address technical questions and integration bottlenecks. Integration-testing progress is tracked monthly by the OMB.

**Responsible Body/Role:** Technical Secretariat Head and Head of Carrier Engagement

**Suggested Timeframe:** Month 12 (2027-10-12)

**Key Outputs/Deliverables:**

- Test Environment Documentation and Carrier Access Credentials
- Reference OSDM Sandbox (public release, open-source)
- Conformance Test Cases (published for self-testing by carriers)
- Biweekly Integration-Support Sessions (held Months 12–24 = 2027-10-12 to 2028-10-12)

**Dependencies:**

- OSDM binding specification finalized (Month 12 = 2027-10-12)
- Reference implementation and test cases available
- Shared adapters procured
- Tier 1 carriers notified and ready for testing

### 42. Programme Director commences formal concession-tender evaluation (issued Month 12 = 2027-10-12, per earlier steps). A two-stage process is followed: (1) technical-requirements evaluation (service offerings, volume handling, SLA capability, complaint-handling procedures); (2) financial-viability assessment (cost benchmarks, margin assumptions, subsidy forecast, clawback conditions). Tender evaluation completes by Month 18 (2028-04-12); concessionaire award announced by Month 18 (2028-04-12); contract signed by Month 24 (2028-10-12); service deployment target Month 30 (2029-04-12) (concurrent with Tier 1 API exposure).

**Responsible Body/Role:** Head of Distributor and Consumer Affairs and Procurement Officer

**Suggested Timeframe:** Month 12-24 (October 2027–October 2028)

**Key Outputs/Deliverables:**

- Concession Tender Evaluation Report (Month 18 = 2028-04-12)
- Concessionaire Selection and Award Notification (Month 18 = 2028-04-12)
- Concession Contract (signed Month 24 = 2028-10-12)
- Concession Service-Deployment Plan and timeline

**Dependencies:**

- Business case completed (Month 9 = 2027-07-12)
- Tender issued (Month 12 = 2027-10-12)
- Budget envelope confirmed (EUR 300M, EUR 60M subsidy cap)

### 43. DG COMP delivers the formal Article 101 TFEU guidance letter by Month 12 (2027-10-12) (expected timeline). If guidance is received, CCPR Chair reviews it against the approved clearing architecture and data-sharing design (Decisions 1–2). If guidance confirms compatibility, the CCPR issues a Compliance Certificate by Month 14 (2027-12-12) and reports to the PSC. If guidance raises concerns, remediation actions are taken (clean-team protocol, adjusted data firewalls) by Month 14 (2027-12-12) to protect binding-standards approval (Month 18 = 2028-04-12).

**Responsible Body/Role:** CCPR Chair and DG COMP

**Suggested Timeframe:** Month 12-14 (October–December 2027)

**Key Outputs/Deliverables:**

- DG COMP Article 101 Guidance Letter (Month 12 = 2027-10-12)
- CCPR Compliance Review and Certificate (Month 14 = 2027-12-12)
- Remediation Actions (if required) and revised clearing protocol (by Month 14 = 2027-12-12)

**Dependencies:**

- DG COMP pre-notification filed at Month 2 (2026-12-12)
- CCPR and DG COMP maintained regular communication
- Clearing architecture finalized (Decision 2, Month 6 = 2027-04-12)

### 44. TSWG Chair finalizes conformance test cases, SLA thresholds and certification procedures by Month 12 (2027-10-12). Thresholds are published: p95 latency <2 seconds (proposed threshold), 99.5% availability (proposed threshold), stale-seat failures <1% (proposed threshold), booking-error rates within acceptable bounds. Carriers can self-test in environments from Month 12 (2027-10-12) onwards. Independent conformance audits begin Month 24 (2028-10-12) for Tier 1 carriers (deadline Month 30 = 2029-04-12). Audit schedule for Tier 2 (deadline Month 36 = 2029-10-12) and Tier 3 (deadline Month 42 = 2030-04-12) is published.

**Responsible Body/Role:** TSWG Chair and Head of Standards and Conformance

**Suggested Timeframe:** Month 12 (2027-10-12)

**Key Outputs/Deliverables:**

- Final Conformance Test Cases and SLA Thresholds (published)
- Conformance Audit Schedule: Tier 1 (Months 24–30 = 2028-10-12 to 2029-04-12), Tier 2 (Months 30–36 = 2029-04-12 to 2029-10-12), Tier 3 (Months 36–42 = 2029-10-12 to 2030-04-12)
- Independent Test Laboratory contracted and ready (by Month 18 = 2028-04-12)

**Dependencies:**

- OSDM binding specification finalized (Month 12 = 2027-10-12)
- Test cases reviewed by TSWG and carrier representatives
- SLA thresholds agreed with carriers (informed by bilateral briefings)

### 45. Technical Secretariat Head arranges live pilot deployments on each of the four priority corridors (Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin) with 500–1,000 passengers per corridor (2,000–4,000 total). Pilots are conducted Months 12–18 (2027-10-12 to 2028-04-12) to test end-to-end through-ticket booking, disruption re-accommodation, validation acceptance and passenger satisfaction. Pilot findings are documented in a Live-Pilot Report delivered by Month 18 (2028-04-12) to inform any adjustments before binding-standards finalization.

**Responsible Body/Role:** Head of Carrier Engagement and liaison officers (four corridor hubs)

**Suggested Timeframe:** Month 12-18 (October 2027–April 2028)

**Key Outputs/Deliverables:**

- Pilot Deployment Plan (per-corridor timelines, carrier participation, passenger recruitment, metrics)
- Pilot Operations (500–1,000 passengers per corridor)
- Live-Pilot Report (Month 18 = 2028-04-12): booking completion rates, disruption re-accommodation response times, validation acceptance, passenger satisfaction, accessibility issues

**Dependencies:**

- Operationaldisruption manual approved (Month 12 = 2027-10-12)
- Tier 1 carriers ready to participate
- Passenger-rights legal compliance confirmed
- Test environments and shared adapters available

### 46. Technical Secretariat Head finalizes the binding OSDM specification (version 1.0) by Month 18 (2028-04-12) for formal adoption. The specification is submitted to the Commission for anchoring in a delegated or implementing act. The specification custodianship (EU Agency for Railways) is confirmed; an escrowed open-source copy is archived; version history and change-control governance are documented. The specification is formally pinned by delegated or implementing act by the end of Month 18 (2028-04-12).

**Responsible Body/Role:** TSWG Chair, Technical Secretariat Head and EU Agency for Railways

**Suggested Timeframe:** Month 18 (2028-04-12)

**Key Outputs/Deliverables:**

- OSDM Binding Specification v1.0 (final, approved by TSWG and PSC)
- Delegated or Implementing Act anchoring OSDM version (Commission adoption)
- Escrowed Open-Source Archive (with Agency custodianship documentation)
- Specification Governance Charter (change control, quarterly release cadence, version history)

**Dependencies:**

- Binding-standards milestone (Month 18 = 2028-04-12) confirmed
- Carrier and distributor feedback from pilots and testing incorporated
- Commission adoption of Regulation (assumed Month 18 = 2028-04-12, per scenario)

### 47. PSC Chair holds a post-binding-standards review meeting at Month 18 (2028-04-12) to confirm: (1) binding OSDM specification adopted (pinned by delegated act); (2) DG COMP Article 101 guidance obtained and clean-team protocol in place; (3) passenger-rights legal compliance manual approved; (4) pilots completed and key findings documented; (5) Tier 1 carrier conformance audits scheduled (Month 24 = 2028-10-12 start); (6) Phase 2 (API exposure and conformance, Months 18–48 = 2028-04-12 to 2030-10-12) kicked off. Any blockers are escalated; if none, the PSC confirms the programme proceeds to mandatory API exposure target (Month 30 = 2029-04-12).

**Responsible Body/Role:** PSC Chair

**Suggested Timeframe:** Month 18 (2028-04-12)

**Key Outputs/Deliverables:**

- PSC Post-Binding-Standards Review Meeting
- Binding-Standards Milestone Confirmation Report
- Phase 2 Launch Memo (API exposure, conformance, corridor go-live timelines)
- PSC Meeting Minutes and any escalations

**Dependencies:**

- OSDM binding specification finalized and adopted
- DG COMP Article 101 guidance received or mitigated
- Live pilots completed (Month 18 = 2028-04-12)
- Tier 1 carrier readiness confirmed for conformance audits

### 48. OMB establishes SLA monitoring by deploying the SLA monitoring proxy (part of the real-time layer). The proxy tracks monthly metrics for all carriers: latency (p95 <2 seconds proposed threshold), availability (99.5% proposed threshold), stale-seat failures (<1% proposed threshold). Monthly SLA scorecards are published by the OMB by Month 24 (2028-10-12), with results available to the PSC, carriers and distributors. Carriers missing SLAs for two consecutive months face recommended funding-tranche withholding (5% of next tranche).

**Responsible Body/Role:** OMB and Technical Secretariat Head

**Suggested Timeframe:** Month 18-24 (April–October 2028)

**Key Outputs/Deliverables:**

- SLA Monitoring Proxy deployment (Month 18 = 2028-04-12)
- SLA Scoring Methodology and escalation rules (published)
- First SLA Scorecards (by Month 24 = 2028-10-12, for all carriers with active data feeds)

**Dependencies:**

- SLA monitoring proxy infrastructure ready (deployed by Month 6 = 2027-04-12)
- Carrier data feeds established (from test environments)
- SLA thresholds published (Month 12 = 2027-10-12)

### 49. Tier 1 Carriers (large, corridor-critical) undergo formal independent conformance audits by an contracted test laboratory. Audits begin Month 24 (2028-10-12) and must complete by Month 30 (2029-04-12) (mandatory API exposure deadline). Carriers are expected to: (1) expose OSDM-compatible APIs with p95 latency <2 seconds, 99.5% availability; (2) demonstrate stale-seat failure rates <1%; (3) provide settlement data feeds matching the standard format; (4) pass ticket-validation credential interoperability testing. Audit results are published monthly on the public Conformance-Certification Registry.

**Responsible Body/Role:** Head of Standards and Conformance and independent test laboratory

**Suggested Timeframe:** Month 24-30 (October 2028–April 2029)

**Key Outputs/Deliverables:**

- Conformance Audit Reports (per Tier 1 carrier, monthly from Month 24 = 2028-10-12)
- Public Conformance-Certification Registry (updated monthly)
- Remediation tracking for carriers missing criteria
- Tier 1 Conformance Certification Awards (by Month 30 = 2029-04-12)

**Dependencies:**

- Test laboratory contracted and ready (by Month 18 = 2028-04-12)
- Test cases, SLA thresholds and audit procedures finalized (Month 12 = 2027-10-12)
- Carrier integration testing in environments completed (Months 12–24 = 2027-10-12 to 2028-10-12)
- Shared adapters deployed to carriers (Month 12 = 2027-10-12)

### 50. Head of Carrier Engagement monitors Tier 1 carrier conformance progress monthly during Months 24–30 (2028-10-12 to 2029-04-12). Any carrier with SLA misses (latency, availability) or stale-seat failures is offered remediation support: additional adapter funding, extended integration timelines or deferral to Tier 2 (Month 36 = 2029-10-12). By Month 30 (2029-04-12), all Tier 1 carriers are either certified or formally deferred to Tier 2 with a revised compliance timeline.

**Responsible Body/Role:** Head of Carrier Engagement and OMB

**Suggested Timeframe:** Month 24-30 (October 2028–April 2029)

**Key Outputs/Deliverables:**

- Monthly Carrier Remediation Status Report (Months 24–30 = 2028-10-12 to 2029-04-12)
- Tier 1 Final Certification List (Month 30 = 2029-04-12)
- Tier 1 Deferrals to Tier 2 (documented with revised timelines)

**Dependencies:**

- Tier 1 conformance audits underway
- Shared adapters available for rapid deployment
- SLA scorecards informing remediation decisions

### 51. Concessionaire (selected via tender Month 18 = 2028-04-12, contract signed Month 24 = 2028-10-12) commences service deployment by Month 30 (2029-04-12), coinciding with Tier 1 API exposure. The concessionaire establishes IT platform, booking interface, multilingual support, complaint handling and integration with participating carriers' APIs. Service is launched on the four priority corridors first, expanding to additional corridors by Month 48 (2030-10-12). Monthly financial reports track volume, operating costs and subsidy draw (capped at EUR 60M over five years).

**Responsible Body/Role:** Concessionaire and Head of Distributor and Consumer Affairs

**Suggested Timeframe:** Month 24-30 (October 2028–April 2029)

**Key Outputs/Deliverables:**

- Concessionaire Service-Deployment Plan (platform, API integration, languages, support)
- Service Launch (Month 30 = 2029-04-12 on priority corridors)
- Monthly Financial Reports (volume, operating cost, subsidy tracking)

**Dependencies:**

- Concession contract signed (Month 24 = 2028-10-12)
- Tier 1 carriers certified and APIs live (Month 30 = 2029-04-12)
- Distribution remuneration band set (Decision 12, Month 9 = 2027-07-12)

### 52. OMB declares the mandatory API exposure milestone (Month 30 = 2029-04-12) achieved when all Tier 1 carriers are certified and live, the concessionaire is operational, and the first through-tickets are being sold. The milestone is formally confirmed by the PSC; progress toward the four-corridor go-live (Month 48 = 2030-10-12) is confirmed on schedule. Phase 2 continues with Tier 2 audits (Months 30–36 = 2029-04-12 to 2029-10-12) and Tier 3 preparation (targeting Month 42 = 2030-04-12).

**Responsible Body/Role:** OMB Chair (Programme Director) and PSC Chair

**Suggested Timeframe:** Month 30 (2029-04-12)

**Key Outputs/Deliverables:**

- API Exposure Milestone Confirmation Report
- Tier 1 Certification Summary (certified carriers, API endpoints live)
- First Through-Tickets Sold Report (volume, routes, passenger feedback)
- Phase 2 Progress and Tier 2/3 Readiness Assessment

**Dependencies:**

- All Tier 1 carriers certified (Month 30 = 2029-04-12)
- Concessionaire service live (Month 30 = 2029-04-12)
- SLA monitoring and compliance tracking functional

### 53. Tier 2 Carriers (regional and mid-size) undergo conformance audits Months 30–36 (2029-04-12 to 2029-10-12). Tier 2 carriers receive shared adapters, extended support and potentially additional funding for legacy-system retrofits. Conformance audit results are published monthly; remediation and deferrals follow the same process as Tier 1. By Month 36 (2029-10-12), all Tier 2 carriers are either certified or deferred to Tier 3 (Month 42 = 2030-04-12).

**Responsible Body/Role:** Head of Standards and Conformance and independent test laboratory

**Suggested Timeframe:** Month 30-36 (April–October 2029)

**Key Outputs/Deliverables:**

- Tier 2 Conformance Audit Reports (monthly)
- Tier 2 Final Certification List (Month 36 = 2029-10-12)
- Tier 2 Deferrals to Tier 3 (with revised timelines)

**Dependencies:**

- Tier 1 completed and live
- Shared adapters (Tier 2 versions) deployed
- Tier 2 carriers registered for audits

### 54. Tier 3 Carriers (small and legacy-heavy) undergo conformance audits Months 36–42 (2029-10-12 to 2030-04-12). Tier 3 carriers receive maximum support: shared adapters for legacy event-streaming and transaction-consistency, dedicated integration support, and potentially 80–90% funding for adapter modules. Conformance audit results are published monthly; any carriers unable to achieve compliance by Month 42 (2030-04-12) are considered for deferral to the TEN-T extension wave (Months 48–60 = 2030-10-12 to 2031-10-12) or full exclusion if technical viability is questioned.

**Responsible Body/Role:** Head of Standards and Conformance and Head of Carrier Engagement

**Suggested Timeframe:** Month 36-42 (October 2029–April 2030)

**Key Outputs/Deliverables:**

- Tier 3 Conformance Audit Reports (monthly)
- Tier 3 Final Certification List (Month 42 = 2030-04-12)
- Carrier Exclusion or Deferral Decisions (with justification)
- TEN-T extension planning based on Tier 3 outcomes

**Dependencies:**

- Tier 2 completed (Month 36 = 2029-10-12)
- Shared adapters (Tier 3 versions) deployed
- Tier 3 carriers integrated with test environments

### 55. OMB prepares a formal Corridor Go-Live Readiness Assessment by Month 42 (2030-04-12) for each of the four priority corridors (Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin). Assessment criteria: (1) all participating carriers on the corridor are certified (Tiers 1–3); (2) real-time data flows (availability shadow, disruption event feed, settlement data) are live and validated for at least one month; (3) ticket-validation credentials are deployed to at least 80% of corridor rolling stock and key stations; (4) operational procedures (disruption re-accommodation, assistance, complaint handling) are staffed and tested; (5) concessionaire is selling tickets on the corridor. Go-live decision is made by the PSC by Month 45 (2030-07-12); corridors are brought live by Month 48 (2030-10-12).

**Responsible Body/Role:** OMB and corridor liaison officers

**Suggested Timeframe:** Month 42-48 (April–October 2030)

**Key Outputs/Deliverables:**

- Corridor Go-Live Readiness Assessment (per corridor, Month 42 = 2030-04-12)
- PSC Go-Live Decision (Month 45 = 2030-07-12)
- Corridor Launch Plan (traffic management, passenger comms, issue escalation)
- Four-Corridor Through-Ticketing Milestone Confirmation (Month 48 = 2030-10-12)

**Dependencies:**

- Tier 3 conformance completed or deferred (Month 42 = 2030-04-12)
- Ticket-validation deployment nearing completion (target Month 40 = 2030-02-12)
- Operational procedures tested in pilots (Months 12–18 = 2027-10-12 to 2028-04-12)

### 56. Technical Secretariat Head audits ticket-validation capability on corridor rolling stock and key stations. Validation deployment began during integration testing; audit checklist requires: (1) API handshake or cryptographic-token verification working on conductor handhelds and station gates; (2) offline validation capability for environments with poor connectivity; (3) cross-carrier credential acceptance (all carriers recognize each other's tickets); (4) accessibility compliance (ticket presentation, audio guidance, tactile feedback). Audits are conducted at Months 30 (2029-04-12), 35 (2029-09-12) and 40 (2030-02-12); results inform remediation priorities. Target: 80%+ of corridor vehicles and key stations compliant by Month 40 (2030-02-12) (10 months before go-live at Month 48 = 2030-10-12).

**Responsible Body/Role:** Technical Secretariat Head and corridor liaison officers

**Suggested Timeframe:** Month 30-40 (April 2029–February 2030)

**Key Outputs/Deliverables:**

- Validation Deployment Audit Checklist (published)
- Audit Reports (Months 30, 35, 40 = 2029-04-12, 2029-09-12, 2030-02-12)
- Validation Compliance Scorecard (% vehicles/stations compliant by corridor)
- Remediation Plan for non-compliant sites

**Dependencies:**

- Ticket-validation credential format finalized in OSDM spec (Month 18 = 2028-04-12)
- Carrier IT integration of validation capability completed
- Hardware (handhelds, gates) upgrades funded and scheduled

### 57. Concession head and Head of Distributor and Consumer Affairs track concessionaire service metrics monthly: through-ticket volume (targeting ramp-up toward 40% of cross-border journeys), passenger satisfaction, complaint resolution time, operating costs versus budget. If volume is <60% of forecast, a contract-review clause is triggered, which may require service-level adjustments or subsidy review. Clawback conditions apply if volume exceeds forecast by >20%: surplus fees are rebated to the Commission. Monthly reports are submitted to the OMB and PSC; annual reports to the European Court of Auditors.

**Responsible Body/Role:** Head of Distributor and Consumer Affairs and Financial Planning Lead

**Suggested Timeframe:** Month 30-60 (April 2029–October 2031) ongoing

**Key Outputs/Deliverables:**

- Monthly Concession Performance Report (volume, satisfaction, complaint resolution, cost vs. budget)
- Clawback or subsidy-review triggers (documented and escalated to PSC if triggered)
- Annual Audit Report to Court of Auditors

**Dependencies:**

- Concessionaire service live (Month 30 = 2029-04-12)
- Carrier API availability and booking volumes trending upward

### 58. OMB and Head of Compliance and Risk track cumulative programme spend quarterly against the EUR 1,500M budget. Variance triggers at EUR 100M (defer TEN-T extension to Months 60–72 = 2031-10-12 to 2032-10-12), EUR 200M (cut concession funding 20%, extend concession term 5–7 years), and EUR 300M (restrict to four priority corridors only). If any variance trigger is reached, the OMB recommends mitigation actions to the PSC within 10 business days. The PSC approves policy adjustments (e.g., scaling back TEN-T, extending concession term, deferring non-critical components). Quarterly variance reports are published to the Commission and the Court of Auditors.

**Responsible Body/Role:** OMB and Financial Planning Lead

**Suggested Timeframe:** Month 3-60 (January 2027–October 2031) quarterly

**Key Outputs/Deliverables:**

- Quarterly Variance Tracking Report (cumulative spend by line, variance triggers, mitigation status)
- Variance Trigger Escalation (if threshold reached, within 10 business days to OMB and PSC)
- PSC Policy Adjustment Decision (if mitigation required)

**Dependencies:**

- Financial reporting system operational (Month 3 = 2027-01-12)
- Budget baseline and spending authority established

### 59. OMB and Head of Compliance and Risk conduct a mid-programme evaluation at Month 36 (2029-10-12) assessing: (1) progress toward binding-standards (achieved Month 18 = 2028-04-12); (2) API exposure readiness for Tier 2 carriers (on schedule Month 36 = 2029-10-12); (3) through-ticket volume ramp-up (targeting 15–20% by Month 36 = 2029-10-12 as a planning range estimate toward 40% by Month 60 = 2031-10-12); (4) distributor complaints trending down; (5) budget variance and concession performance; (6) risk-mitigation effectiveness. Evaluation findings are briefed to the PSC; course corrections (e.g., accelerating Tier 3, adjusting commission band) are recommended and decided by Month 36 (2029-10-12).

**Responsible Body/Role:** Programme Director and independent evaluation firm (contracted)

**Suggested Timeframe:** Month 36 (2029-10-12)

**Key Outputs/Deliverables:**

- Mid-Programme Evaluation Report (progress toward goals, risk status, course-correction recommendations)
- PSC Briefing and Decision (Month 36 = 2029-10-12 or Month 39 = 2030-01-12)

**Dependencies:**

- Binding-standards achieved (Month 18 = 2028-04-12)
- Tier 2 conformance underway (Months 30–36 = 2029-04-12 to 2029-10-12)
- Initial through-ticket data available from Tier 1 (Months 30–36 = 2029-04-12 to 2029-10-12)

### 60. Technical Secretariat Head and TSWG Chair establish a post-Month-18 (2028-04-12) specification-evolution governance process. Change requests for the OSDM specification are managed using the published change-control process (critical: 2 weeks, major: 6 weeks, minor: 8 weeks). Quarterly releases are published (following the release schedule established at Month 3 = 2027-01-12). A change-request dashboard is maintained showing pending and approved requests. Any change requests affecting binding-standards commitments or requiring carrier rework are escalated to the OMB for impact assessment before approval.

**Responsible Body/Role:** TSWG Chair and Technical Secretariat Head

**Suggested Timeframe:** Month 18-60 (April 2028–October 2031) ongoing

**Key Outputs/Deliverables:**

- Change-Request Dashboard (published monthly, updated)
- Quarterly OSDM Release Notes (describing approved changes and version number)
- Escalation Decisions (change requests flagged for OMB review)

**Dependencies:**

- Change-control process published (Month 3 = 2027-01-12)
- OSDM specification pinned by delegated act (Month 18 = 2028-04-12)

### 61. OMB and Head of Compliance and Risk establish a post-go-live passenger-rights and accessibility monitoring programme. Starting Month 48 (2030-10-12) (when first corridors go live), the programme tracks: (1) passenger complaints related to liability, refunds and compensation; (2) assistance and bicycle-reservation request fulfillment rates; (3) ticket-validation errors and disputes on corridor trains; (4) through-ticket passenger satisfaction and Net Promoter Score. Monthly reports are compiled and escalated to the CCPR; annual compliance audits are conducted by the EU Agency for Railways. Any systematic rights violations are escalated to national regulators and the Commission for enforcement action.

**Responsible Body/Role:** OMB, CCPR Chair and corridor liaison officers

**Suggested Timeframe:** Month 48-60 (October 2030–October 2031) ongoing

**Key Outputs/Deliverables:**

- Passenger-Rights Monitoring Dashboard (complaints, resolution time, escalations)
- Monthly Compliance Report (CCPR briefing)
- Annual Accessibility Audit (EU Agency for Railways)

**Dependencies:**

- Corridors live (Month 48 = 2030-10-12)
- Compliance manual operational (Month 12 = 2027-10-12)
- Concessionaire complaint handling live (Month 30 = 2029-04-12)

### 62. OMB and Head of Carrier Engagement launch planning for the TEN-T network extension (Months 48–60 = 2030-10-12 to 2031-10-12). The extension adds operators and corridors beyond the four initial priority corridors, targeting full TEN-T coverage by Month 60 (2031-10-12). Funding for TEN-T extension (estimated EUR 200–400M, to be allocated from the budget headroom EUR 85M + reserve EUR 150M, with variance-trigger conditions) is released on a phased basis as Tier 1/2/3 adoption succeeds and budget headroom is confirmed. Planning documents include: (1) corridor prioritization (air-competitive routes, high-volume cross-border links); (2) carrier inclusion criteria (conformance readiness, API maturity); (3) funding tranches and release conditions; (4) timeline (Months 48–60 = 2030-10-12 to 2031-10-12 target, Month 72 = 2032-10-12 fallback accepted).

**Responsible Body/Role:** Programme Director and OMB

**Suggested Timeframe:** Month 36-48 (October 2029–October 2030)

**Key Outputs/Deliverables:**

- TEN-T Extension Plan (corridor prioritization, carrier inclusion, funding tranches, timeline)
- PSC approval of TEN-T scope and sequencing (Month 42 = 2030-04-12 or Month 45 = 2030-07-12)
- TEN-T Funding Release Framework (conditions, tranches, monitoring)

**Dependencies:**

- Four-corridor go-live completed (Month 48 = 2030-10-12)
- Budget headroom and reserve status known (quarterly variance reports)
- Tier 2/3 outcomes inform network expansion viability

### 63. OMB and Head of Distributor and Consumer Affairs establish a competitive call or direct-engagement process for additional carriers and corridors in the TEN-T extension wave (Months 48–60 = 2030-10-12 to 2031-10-12). Using milestone-conditioned funding (the pragmatic scenario), TEN-T funding is released in tranches tied to verified API exposure, conformance certification and through-ticket volume milestones. New corridor onboarding follows the Tier-assignment process: rapid-track for carriers already conformant (Tier 1/2 ready by Months 48–54 = 2030-10-12 to 2031-04-12), standard-track for new entrants (Months 54–60 = 2031-04-12 to 2031-10-12). By Month 60 (2031-10-12), the target is full TEN-T coverage and 40% of cross-border journeys sold as through-tickets.

**Responsible Body/Role:** Programme Director and Head of Distributor and Consumer Affairs

**Suggested Timeframe:** Month 48-60 (October 2030–October 2031)

**Key Outputs/Deliverables:**

- TEN-T Extension Call or Direct-Engagement RFP
- New Carrier Onboarding (conformance audits, rapid-track vs. standard-track assignment)
- Corridor Launch Schedule (TEN-T corridors brought live by Month 60 = 2031-10-12)
- Final Through-Ticket Market Penetration Report (Month 60 = 2031-10-12): share of cross-border journeys sold as through-tickets, progress toward 40% target

**Dependencies:**

- Four-corridor go-live successful (Month 48 = 2030-10-12)
- TEN-T extension plan approved (Month 42-48 = 2030-04-12 to 2030-10-12)
- Funding tranches released (approved by PSC quarterly variance tracking)

### 64. OMB commissions a final post-programme evaluation at Month 60 (2031-10-12) assessing: (1) achievement of the 40% through-ticket goal (or identified shortfall); (2) distributor complaints halved (baseline from Month 1 = 2026-11-12); (3) modal shift from short-haul air to rail (conservative 5–10% planning value estimate, not a success metric but reported); (4) accessibility compliance for assistance and bicycle reservations; (5) financial performance (total spend vs. EUR 1,500M budget, concession subsidy draw, clawback conditions); (6) regulatory and competition-law compliance; (7) passenger and carrier satisfaction. Findings are documented in the Final Evaluation Report; recommendations for programme sustaining (beyond Month 60 = 2031-10-12) are developed. The report is submitted to the Commission, the Court of Auditors and the European Parliament.

**Responsible Body/Role:** Programme Director and independent evaluation firm

**Suggested Timeframe:** Month 60 (2031-10-12)

**Key Outputs/Deliverables:**

- Final Evaluation Report (Month 60 = 2031-10-12): goal achievement, lessons learned, recommendations for sustaining
- Submission to Commission, Court of Auditors and European Parliament

**Dependencies:**

- TEN-T extension completed or decisioned (Month 60 = 2031-10-12)
- Four-corridor and priority TEN-T corridors live for minimum 6–12 months (data available)
- Financial and operational data collected throughout Months 0–60 (2026-10-12 to 2031-10-12)

### 65. PSC Chair convenes a final PSC meeting at Month 60 (2031-10-12) to formally close the programme governance (Phase 1, 2, 3: Months 0–60 = 2026-10-12 to 2031-10-12) or transition to a sustaining governance phase (if the programme continues managing network expansion or ongoing compliance beyond Month 60 = 2031-10-12). The PSC reviews final evaluation findings, confirms the through-ticket goal status, and decides on: (1) dissolution of the Programme Office and Technical Secretariat (or transition to a smaller sustained-governance body under the EU Agency for Railways); (2) handover of OSDM custodianship and change control to the Agency (if not already formalized); (3) ongoing funding for network sustaining, passenger-rights monitoring and accessibility compliance; (4) any residual budget (if unspent headroom remains, disposition is decided). The closing decision is documented in a PSC Final Report, published to the Commission and member states.

**Responsible Body/Role:** PSC Chair and Programme Director

**Suggested Timeframe:** Month 60 (2031-10-12)

**Key Outputs/Deliverables:**

- PSC Final Meeting Agenda and briefing materials
- PSC Final Report (programme closure or transition, recommendations, final votes)
- PSC Meeting Minutes
- Notification to all stakeholders of programme governance transition

**Dependencies:**

- Final evaluation completed (Month 60 = 2031-10-12)
- Four-corridor through-ticketing confirmed as sustainable (at least 6 months operating experience)
- Financial closure and audit complete

# Decision Escalation Matrix

**Carrier Refusal to Expose Inventory Due to Unpriceable Liability**
Escalation Level: Programme Steering Committee (PSC)
Approval Process: Supermajority vote (75%, at least 7 of 9 core members) on a revised liability-backstop design or risk-sharing mechanism. Commission Transport Commissioner mediates if vote deadlocks. Decision enforced by conditional funding release: carriers refusing participation lose funding-tranche eligibility.
Rationale: Inability to price connection liability is a critical carrier-participation blocker that threatens network coverage. This exceeds the Operational Management Board's authority to remediate and risks the binding-standards milestone (Month 18 = 2028-04-12) if 30%+ of expected carriers refuse. The PSC's access to the actuarial study, liability model and carrier sign-offs enables fact-based negotiation and binding revision.
Negative Consequences: If unresolved by Month 6 (2027-04-12), the through-ticket goal drops from 40% to 15–25% (estimate), critical corridors become fragmented, and the mandatory API exposure milestone (Month 30 = 2029-04-12) slips to Month 36–42 (2029-10-12 to 2030-04-12). Estimated cost: EUR 100–150M in lost programme value and budget reallocation.

**Legacy Booking-System Integration Failure Preventing Tier Conformance by Scheduled Deadline**
Escalation Level: Operational Management Board (OMB) with escalation to PSC if affecting >5 carriers or a corridor-critical carrier
Approval Process: OMB approves per-carrier remediation: accelerated adapter funding, extended conformance timeline (deferral to next tier), or exclusion from that wave. If remediation costs exceed EUR 50M or delays affect the Month 30 (2029-04-12) API exposure milestone, escalation to PSC for variance and TEN-T extension planning approval. PSC decides whether to absorb cost overrun (triggering variance triggers: EUR 100M, EUR 200M, EUR 300M) or restrict to fewer carriers.
Rationale: Technical integration challenges are the OMB's operational domain, but when deferral or exclusion affects network connectivity, programme schedule or budget headroom, the PSC's strategic authority is required. A single deferred corridor-critical carrier (e.g., on Wien–München–Zürich) can block that corridor's go-live.
Negative Consequences: If 8–15 smaller carriers miss Month 30 (2029-04-12), the four-corridor through-ticketing target (Month 48 = 2030-10-12) extends to Month 60–66 (2031-10-12 to 2032-04-12). Budget impact: EUR 150–250M (estimate) in adapter acceleration or EUR 200–300M in unused budget if later corridors cannot launch. Network coverage shrinks from 25+ to ~15 carriers, reducing through-ticket share from 40% to 20–25% (estimate).

**Budget Variance Exceeding a Trigger Threshold (EUR 100M, EUR 200M, or EUR 300M cumulative)**
Escalation Level: Programme Steering Committee (PSC), with prior OMB investigation and recommendation
Approval Process: OMB investigates variance root cause and proposes mitigation (scale TEN-T extension scope, extend concession term, accelerate cost recovery, or reduce budget commitments). PSC votes on mitigation by simple majority (5 of 9 members). Approved mitigation is published to the Commission and the Court of Auditors within 10 business days. If mitigation is rejected, variance handling escalates to the Commission's Financial Controller.
Rationale: Budget variance triggers represent policy thresholds where the fixed EUR 1,500M cap (user constraint) is at risk. The OMB tracks variances quarterly, but exceeding a trigger threshold requires strategic decisions (e.g., deferring TEN-T, cutting concession funding, or restricting corridors) that only the PSC can approve without Commission intervention.
Negative Consequences: EUR 100M variance: TEN-T extension deferred from Month 60 (2031-10-12) to Month 72 (2032-10-12), reducing final through-ticket penetration to 25–30%. EUR 200M variance: concession funding cut 20% and term extended 5–7 years, risking service quality and volumes. EUR 300M variance: programme restricted to four priority corridors only, abandoning TEN-T expansion and setting final through-ticket goal at 15–20% (estimate). Any variance exceeding EUR 300M exhausts the public budget.

**DG COMP Article 101 Guidance Not Obtained or Unfavorably Resolved, Threatening Competition-Law Clearance**
Escalation Level: Compliance, Competition Law and Passenger Rights Committee (CCPR), with escalation to PSC and Commission Transport Commissioner if unresolved by Month 12 (2027-10-12)
Approval Process: CCPR monitors DG COMP engagement and guidance-letter status monthly. If guidance is not received by Month 12 (2027-10-12), CCPR issues a compliance warning to PSC. If guidance raises concerns (e.g., about shared data or clearing arrangements), CCPR recommends design modifications (clean-team protocol, data firewalls, restricted access) by Month 14 (2027-12-12). PSC approves remediation or escalates to the Commission Transport Commissioner and DG COMP legal service for dispute resolution by Month 18 (2028-04-12).
Rationale: Competition-law clearance is a Compliance Committee responsibility, but unresolved conflicts block binding-standards approval (Month 18 = 2028-04-12) and require Commission-level intervention. The PSC and Commission cannot finalize standards without confirmation that the clearing and data-sharing designs are compatible with Article 101 TFEU.
Negative Consequences: If DG COMP guidance is unfavorable or delayed beyond Month 18 (2028-04-12), the binding-standards milestone is deferred 3–6 months, cascading to Month 24–30 (2028-10-12 to 2029-04-12) and the API exposure deadline to Month 36–42 (2029-10-12 to 2030-04-12). Estimated rework cost: EUR 50–100M and 6–12 months technical redesign. If a challenge post-deployment (after Month 30 = 2029-04-12) unwinds the clearing or data-sharing arrangements, carriers must revert to bilateral settlement, adding 3–4 months to settlement cycle times and increasing booking-error rates 15–25%, eroding through-ticket value.

**Passenger-Rights Compliance Gap Identified in Legal Review Against Regulation 1371/2007**
Escalation Level: Compliance, Competition Law and Passenger Rights Committee (CCPR), with escalation to PSC and EU Agency for Railways if remediation requires specification changes
Approval Process: CCPR commissions independent legal review (due Month 6 = 2027-04-12). If gaps are identified, CCPR recommends remediation actions (revised liability model, enhanced compensation procedures, improved accessibility thresholds). If remediation requires changes to the OSDM specification or operational manual, CCPR escalates to the Technical Standards and Interoperability Working Group (TSWG) and OMB for integration by Month 9 (2027-07-12). PSC approves any material changes affecting binding standards (Month 18 = 2028-04-12).
Rationale: Passenger-rights compliance is a statutory and reputational risk. The CCPR has specialized legal expertise, but through-ticket passengers and disability-rights bodies cannot accept rights inferior to existing rail regulations. If compliance gaps are discovered post-binding-standards, the programme faces enforcement action from national regulators and the EU Agency for Railways.
Negative Consequences: If material gaps are found (e.g., liability allocation leaves through-ticket passengers without compensation for missed connections), remediation requires 3–6 months of legal and technical rework. Estimated cost: EUR 10–20M. If gaps are discovered post-deployment (after Month 30 = 2029-04-12), the programme faces passenger complaints, regulatory enforcement, legal challenges and reputational damage. Estimated cost: EUR 20–50M in compensation claims and remediation.

**Steering Committee Deadlock on Critical Strategic Decision (Decisions 1–5) Due to Carrier, Distributor or Regulator Disagreement**
Escalation Level: Commission Transport Commissioner, with mediation and binding decision authority
Approval Process: If a PSC vote on Decisions 1–5 falls below 75% supermajority (fewer than 7 of 9 core members voting in favor), the Chair (DG MOVE) files an escalation brief to the Commission Transport Commissioner by Month 5 (2027-03-12). The Commissioner convenes a mediation session with dissenting stakeholders by Month 6 (2027-04-12). If consensus cannot be reached, the Commissioner issues a binding decision (authorizing a fallback technical interface for distributors, revised liability allocations, or phased funding release) by Month 6 (2027-04-12). Alternatively, if the deadlock cannot be resolved, a fallback governance path is invoked (e.g., bilateral clearing for independent distributors, tiered conformance with mixed gates).
Rationale: The PSC is designed to achieve consensus, but supplier and commercial conflicts can create deadlocks that delay binding standards (target Month 18 = 2028-04-12). The Commission's Transport Commissioner has the political and institutional authority to break deadlocks and enforce compliance. If the PSC cannot approve Decisions 1–5 by Month 6 (2027-04-12), the binding-standards schedule is at risk.
Negative Consequences: If deadlock persists beyond Month 9 (2027-07-12), binding standards are deferred from Month 18 (2028-04-12) to Month 24–30 (2028-10-12 to 2029-04-12) (estimated 2–4 month slip). This cascades to API exposure (Month 30 = 2029-04-12 → Month 36 = 2029-10-12) and corridor go-live (Month 48 = 2030-10-12 → Month 54–60 = 2031-04-12 to 2031-10-12). If a major distributor (e.g., Trainline, Omio) rejects a decision and withdraws, through-ticket volume drops 15–25%, reducing the 40% goal to 20–30%.

# Monitoring Progress

### 1. Tracking Key Performance Indicators (KPIs) Against Project Plan
**Monitoring Tools/Platforms:**

  - Programme Office KPI Dashboard (shared spreadsheet or BI tool)
  - Quarterly Financial Variance Report (EUR 1,500M budget tracking)
  - Monthly SLA Scorecard (latency, availability, error rates by carrier)
  - Through-Ticket Volume and Penetration Report (trending toward 40% target)

**Frequency:** Monthly KPI and SLA tracking; quarterly financial reports; monthly variance trending against EUR 100M, EUR 200M, EUR 300M triggers

**Responsible Role:** Operational Management Board (OMB), with Programme Director and Financial Planning Lead executing daily tracking and escalating variances

**Adaptation Process:** KPI shortfalls (e.g., latency >2s p95, availability <99.5%, stale-seat failures >1%) trigger remediation discussions in the OMB; carriers missing SLAs for two consecutive months lose 5% of next funding tranche. Through-ticket volume lagging 40% target by Month 36 (2029-10-12) mid-programme review triggers course corrections (e.g., accelerated TEN-T sequencing, distributor engagement intensification). Financial variance reaching EUR 100M/EUR 200M/EUR 300M triggers PSC policy adjustment (e.g., TEN-T scope reduction, concession subsidy reallocation).

**Adaptation Trigger:** SLA deviation (latency/availability/error) on a single carrier for two consecutive months; financial variance cumulative spend exceeds EUR 100M, EUR 200M or EUR 300M thresholds; through-ticket penetration tracking >15% below linear ramp-to-40% by Month 36 (2029-10-12); concessionaire operating costs exceed budget by >15% in any quarter

### 2. Milestone and Conformance Gate Monitoring
**Monitoring Tools/Platforms:**

  - Conformance-Certification Registry (public, per-carrier, updated monthly from Month 24 = 2028-10-12 onwards)
  - Technical Audit Report and Tier Assignment Schedule (Month 2 = 2026-12-12 baseline, per-carrier timeline)
  - OSDM Binding Specification and Change-Request Dashboard (versions, approvals, backlog)
  - Conformance Test Results and Audit Reports (Tier 1 Months 24–30 = 2028-10-12 to 2029-04-12; Tier 2 Months 30–36 = 2029-04-12 to 2029-10-12; Tier 3 Months 36–42 = 2029-10-12 to 2030-04-12)

**Frequency:** Weekly during Phase 1 (Months 0–18 = 2026-10-12 to 2028-04-12) standards development and readiness-gate prep; monthly conformance audits (Months 24–42 = 2028-10-12 to 2030-04-12); corridor go-live readiness assessments at Month 42 (2030-04-12), Month 45 (2030-07-12)

**Responsible Role:** Technical Standards and Interoperability Working Group (TSWG) Chair and Head of Standards and Conformance for specification and conformance audits; Operational Management Board for milestone tracking and carrier tier remediation decisions

**Adaptation Process:** Carriers failing conformance audits (latency, availability, stale-seat failure thresholds) are assigned remediation tasks: retest, accelerated adapter funding, or deferral to next tier. Tier deferral (e.g., Tier 1 carrier → Tier 2, or Tier 2 → Tier 3) is documented with revised conformance deadline. If a corridor-critical carrier (e.g., on Wien–München–Zürich corridor) fails by its tier deadline, corridor go-live is deferred or that carrier is replaced by a backup (if available). OSDM specification change requests are processed via the published change-control process (critical: 2 weeks, major: 6 weeks, minor: 8 weeks); changes requiring carrier rework are flagged to OMB for impact assessment.

**Adaptation Trigger:** Carrier fails conformance audit on latency p95 >2 seconds, availability <99.5%, stale-seat failures >1%; two consecutive months of SLA misses trigger funding-tranche withholding; >5 carriers or a Tier 1 corridor-critical carrier deferred from their tier deadline by >2 months; OSDM specification change request flagged as affecting binding-standards commitments or requiring >4 weeks carrier rework; >20% of corridor rolling stock or stations non-compliant with ticket-validation deployment by Month 40 (2030-02-12) audit

### 3. Carrier Participation and Liability Backstop Monitoring
**Monitoring Tools/Platforms:**

  - Carrier Sign-Off Register (liability model acceptance, on-time performance data submission)
  - Guarantee Pool Contribution Model and Incident Tracking Log (monthly pool draw, contributions by carrier, incident rates)
  - Carrier Bilateral Engagement Log (briefings, concerns, contract commitments)
  - Missed-Connection and Reroute Performance Baseline (pilot data Months 12–18 = 2027-10-12 to 2028-04-12; live data post-Month 30 = 2029-04-12)

**Frequency:** Biweekly carrier bilateral briefings Months 2–6 (2026-12-12 to 2027-04-12) during liability model negotiation; monthly carrier sign-off status tracking (liability model, technical integration); monthly pool-contribution and incident-rate monitoring post-Month 30 (2029-04-12)

**Responsible Role:** Head of Carrier Engagement (Programme Office) for bilateral engagement and sign-off tracking; Head of Clearing and Settlement for pool contribution and reconciliation monitoring; OMB for escalation of carrier participation risks

**Adaptation Process:** If a major carrier (>5% of network) signals intent to refuse inventory exposure due to liability concerns, Head of Carrier Engagement escalates to OMB within five business days with remediation options: revised cap/co-insurance formula, additional insurance subsidy, or re-mediation with Commission Transport Commissioner via PSC. If carrier signs off on liability model by Month 4 (2027-02-12), commitment is binding; failure to expose inventory by their tier deadline results in funding-tranche withholding and potential exclusion. Post-deployment, if pool contribution methodology results in systematically higher costs for one carrier (indicating disproportionate incident rates), actuarial study is refreshed (Month 36 = 2029-10-12 or Month 48 = 2030-10-12) to adjust contribution weights and signal operational performance issues for remediation.

**Adaptation Trigger:** A major carrier (>5% of network) declines to sign liability model by Month 4 (2027-02-12); carrier signals publicly or privately that it will not expose inventory by its tier deadline; carrier participation drops below 20 operators (down from 25+ target) before binding standards Month 18 (2028-04-12); missed-connection incident rate on a carrier exceeds 2% of through-tickets post-Month 30 (2029-04-12) triggering pool contributions >EUR 1M/month; carrier pool contribution estimated to exceed carrier's forecast margin, signaling refusal to renew participation beyond initial phase

### 4. Regulation Adoption and Competition-Law Compliance Monitoring
**Monitoring Tools/Platforms:**

  - Regulation Adoption Status Tracker (Commission legislative-affairs updates, expected adoption date)
  - DG COMP Engagement Log and Guidance-Letter Timeline (pre-notification sent Month 2 = 2026-12-12; guidance expected Month 12 = 2027-10-12)
  - Compliance Certifications Register (Article 101 guidance letter, passenger-rights legal opinion, GDPR assessment, accessibility compliance)
  - Clean-Team Protocol Approval and Clearing-Function Audit Trail (segregation of clearing operations, aggregated data release, competitive safeguards)

**Frequency:** Monthly during Phase 1 (Months 0–18 = 2026-10-12 to 2028-04-12) for Regulation adoption and DG COMP guidance tracking; quarterly compliance audits post-Month 18 (2028-04-12); biennial independent audit of clearing and data-sharing compliance post-Month 30 (2029-04-12)

**Responsible Role:** Compliance, Competition Law and Passenger Rights Committee (CCPR) Chair for monitoring and escalation; Head of Compliance and Risk (Programme Office) for day-to-day tracking; DG MOVE and DG COMP liaison for legislative and competition-law status updates

**Adaptation Process:** If Regulation adoption is delayed beyond Month 18 (2028-04-12) (e.g., no Official Journal publication), CCPR issues a warning to PSC by Month 16 (2028-02-12); standards-working group shifts to a shadow workstream with provisional compliance assumptions, and binding-standards approval is deferred to Month 24 (2028-10-12) or Month 30 (2029-04-12) pending Regulation publication. If DG COMP guidance letter is delayed beyond Month 12 (2027-10-12), CCPR escalates to PSC by Month 12 (2027-10-12); a provisional clean-team protocol is established by Month 14 (2027-12-12) to protect clearing operations even if formal guidance is pending. If DG COMP guidance raises unforeseen Article 101 concerns, CCPR recommends design modifications (data firewalls, restricted carrier access, independent trustee oversight) by Month 14 (2027-12-12); OMB and TSWG assess implementation burden; PSC votes on remediation by Month 18 (2028-04-12).

**Adaptation Trigger:** Regulation adoption delayed >6 months beyond Month 18 (2028-04-12) target; DG COMP guidance letter not received or is unfavorably conditional by Month 12 (2027-10-12); passenger-rights legal opinion identifies material gaps vs. Regulation 1371/2007 by Month 6 (2027-04-12); GDPR or data-governance assessment flags compliance risks in clearing or disruption-feed design by Month 6 (2027-04-12); accessibility compliance audit finds >20% of services unable to meet assistance or wheelchair-access thresholds by Month 40 (2030-02-12)

### 5. Distributor Participation and Commission-Rate Monitoring
**Monitoring Tools/Platforms:**

  - Distributor Engagement and Commitment Log (Trainline, Omio, concessionaire, smaller platforms)
  - Published Commission-Rate Data (monthly by distributor type and corridor, audited for discrimination)
  - Distributor Complaint and Discrimination Log (filed with Programme Office, escalated to regulators if unresolved)
  - Through-Ticket Sales Attribution by Distributor (volume share, growth trajectory, concessionaire performance vs. private platforms)

**Frequency:** Biweekly distributor briefings Months 2–6 (2026-12-12 to 2027-04-12) during commission-band negotiation; monthly commission-rate publication and discrimination audit post-Month 12 (2027-10-12); quarterly through-ticket sales reporting by distributor post-Month 30 (2029-04-12)

**Responsible Role:** Head of Distributor and Consumer Affairs (Programme Office) for bilateral engagement and sales tracking; CCPR for discrimination audits and regulatory escalations; concessionaire (contract oversight) for last-resort service performance

**Adaptation Process:** If Trainline, Omio or another major distributor declines to integrate with the clearing and settlement layer, Head of Distributor and Consumer Affairs negotiates a fallback technical interface (third-party settlement intermediary, alternative reconciliation format) within two weeks; if rejected, Programme Office documents the withdrawal and estimates impact on through-ticket volumes. If commission-rate data shows systemic discrimination (e.g., concessionaire charged 1.0% vs. private platforms charged 3.5%), CCPR launches a discrimination investigation; if findings confirm bias, concession contract is reviewed and rates are adjusted retroactively or the concession is opened to competitive re-tender. If a distributor's through-ticket volumes lag forecast by >30%, OMB reviews distributor engagement strategy and may reallocate funding or support to accelerate platform integration or marketing.

**Adaptation Trigger:** A major distributor (Trainline, Omio) announces non-participation or delayed integration by Month 12 (2027-10-12); published commission rates show >1.5% dispersion between distributor types (indicating potential discrimination); through-ticket sales attributed to distributors fall >20% below forecast by Month 36 (2029-10-12); concessionaire operating subsidy draw exceeds EUR 15M/year (triggering subsidy-cap review); discriminatory commission-rate complaint filed by a distributor, unresolved after 30 days

### 6. Operational Readiness and Passenger-Experience Monitoring
**Monitoring Tools/Platforms:**

  - Live-Pilot Report (500–1,000 passengers per corridor, Months 12–18 = 2027-10-12 to 2028-04-12)
  - Disruption Re-accommodation Performance Dashboard (response time to missed connections, reroute success rate, passenger satisfaction, post-Month 12 = 2027-10-12 pilots)
  - Ticket-Validation Deployment Audit and Scorecard (% of corridor rolling stock and stations with validation capability, monthly Months 30–40 = 2029-04-12 to 2030-02-12)
  - Passenger-Rights and Accessibility Monitoring Dashboard (complaints, resolution time, assistance and bicycle-reservation fulfillment, post-Month 48 = 2030-10-12 go-live)

**Frequency:** Live-pilot data collection and weekly review Months 12–18 (2027-10-12 to 2028-04-12); validation deployment audits at Months 30, 35, 40 (2029-04-12, 2029-09-12, 2030-02-12); post-go-live passenger-experience monitoring monthly from Month 48 (2030-10-12) onwards

**Responsible Role:** Head of Carrier Engagement (Programme Office) and corridor liaison officers for pilot and validation deployment tracking; CCPR Chair for passenger-rights compliance audits post-deployment; OMB for operational readiness assessments before corridor go-live

**Adaptation Process:** Pilot findings (Months 12–18 = 2027-10-12 to 2028-04-12) showing >20% booking failures, disruption response times >60 minutes, or <80% passenger satisfaction trigger operational-manual revisions and carrier re-training by Month 18 (2028-04-12) before pilots close. If ticket-validation deployment lags (e.g., only 60% of corridor vehicles equipped by Month 40 = 2030-02-12), corridor go-live is deferred by 6 months to allow completion; alternatively, a hybrid validation (API handshake + fallback manual verification) is deployed as interim measure. Post-deployment, if passenger complaints about missed-connection re-accommodation exceed 5% of through-tickets or resolution time exceeds 48 hours, operationalmanual procedures are audited and carriers are required to retest re-accommodation procedures within 30 days or face tranch withholding.

**Adaptation Trigger:** Live-pilot booking-success rate <85% or disruption response time >60 minutes by Month 18 (2028-04-12); ticket-validation deployment <70% of corridor capacity by Month 40 (2030-02-12); post-go-live passenger complaints about re-accommodation or refunds >5% of through-tickets; assistance or bicycle-reservation request fulfillment <80% within promised timeframe; accessibility audit (post-Month 48 = 2030-10-12) finds >30% of through-ticket itineraries cannot guarantee wheelchair access or assistance, forcing atomic-confirmation failures

### 7. Risk Register and Issue Escalation Monitoring
**Monitoring Tools/Platforms:**

  - Compliance and Risk Register (top 15–20 risks, tracking trigger conditions, mitigation status, owner, escalation paths)
  - Monthly Risk Status Report (OMB and CCPR briefings to PSC, escalation decisions)
  - Issue Log and Remediation Tracking (carrier participation, technical bottlenecks, budget variances, regulatory blockers)
  - Steering Committee Escalation Log (PSC decisions on variances, deadlocks, milestone deferrals)

**Frequency:** Monthly risk-register review by OMB and CCPR; escalations to PSC within five business days if a risk trigger is hit; quarterly risk-trend reporting to PSC (Months 6, 12, 18, 24, 30, 36, 42, 48, 60 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12, 2029-04-12, 2029-10-12, 2030-04-12, 2030-10-12, 2031-10-12 plus ad hoc)

**Responsible Role:** Head of Compliance and Risk (Programme Office) for register maintenance and monthly reporting; Programme Director (OMB Chair) for remediation decisions and escalations; PSC Chair for strategic risk decisions and mitigation approvals

**Adaptation Process:** If a risk trigger is hit (e.g., carrier participation drops below 20, or financial variance exceeds EUR 100M), Head of Compliance and Risk notifies OMB immediately; OMB convenes within two business days to evaluate mitigation options. Remediation is proposed by OMB and escalated to PSC for approval within five business days (e.g., accelerated adapter funding, tier deferral, TEN-T scope reduction). PSC approves mitigation by majority vote (5 of 9 members); if mitigation is contentious, escalation to Commission Transport Commissioner is triggered by Month 5 (2027-03-12 for Month 6 = 2027-04-12 decisions) or immediately for runtime issues (post-binding-standards). Accepted mitigation is published within ten business days to affected stakeholders (carriers, distributors, regulators).

**Adaptation Trigger:** Any risk tracked in the Compliance and Risk Register reaches its defined trigger condition (e.g., 'Carrier refusal if liability model not agreed by Month 4 = 2027-02-12', 'Legislative delay >6 months', 'Article 101 guidance not received by Month 12 = 2027-10-12', 'Budget variance EUR 100M/EUR 200M/EUR 300M'); a new critical risk not previously identified is raised by stakeholder or internal assessment; two or more active risks reach trigger conditions simultaneously (compound risk), escalating to PSC and Commission for coordinated response

# Governance Extra

## Governance Validation Checks

1. All core governance components requested have been generated: internal governance bodies (4 specialized committees with clear charters), implementation plan (40+ sequenced steps across 60 months), decision escalation matrix (5 critical issues with defined escalation paths and approval processes), monitoring progress plan (5 monitoring approaches with triggers and adaptation mechanisms). The framework is complete and internally referenced.
2. Internal consistency confirmed across stages: (1) Implementation Plan uses the correct governance bodies established in Phase 2 (PSC, OMB, CCPR, TSWG); (2) each body has defined decision thresholds (e.g., OMB: <EUR 10M, PSC: >EUR 50M and strategic decisions); (3) Escalation Matrix properly routes issues to appropriate bodies (carrier refusal → PSC, technical integration failure → OMB with PSC escalation if >EUR 50M); (4) Monitoring Plan tracks KPIs, milestones and risks with OMB ownership, escalating to PSC or CCPR when triggers are hit; (5) all governance bodies report to PSC as the strategic anchor, creating a coherent hierarchy and decision flow. No internal contradictions detected.
3. Clarity of roles gaps: (1) Project Sponsor authority is mentioned but not formally defined—does the Sponsor retain any approval authority post-Month 1 (2026-11-12), or is all authority delegated to PSC Chair? No escalation path exists back to Sponsor if PSC deadlocks unresolved by Commission mediation. (2) EU Agency for Railways' relationship to the Programme Office is hierarchical but their concurrent roles (OSDM custodian, standards authority, compliance validator) create potential conflicts of interest if the Agency must approve standards it has designed. Recommend independent technical review separate from Agency. (3) Independent distributors (Trainline, Omio) have PSC observer seats but no voting rights; fallback clause mentions 'third-party settlement interface' but this interface design is not specified, leaving a potential escape hatch for dissenting distributors that could fragment the network. Interface must be defined operationally before binding standards (Month 18 = 2028-04-12).
4. Process depth and operational clarity gaps: (1) Conflict-of-interest management within the Programme Office and CCPR is not mentioned. If Programme Office staff approve funding tranches for carriers that employed them previously, or if CCPR legal counsel has prior relationships with DG COMP, governance credibility is at risk. Recommend a published conflict-of-interest policy and annual disclosure by all governance staff. (2) Change control for the OSDM specification post-binding-standards (Month 18 = 2028-04-12) specifies review timelines but does not define what happens if a critical security or safety bug is discovered and cannot wait 2 weeks for review. Emergency change procedures must be documented. (3) Whistleblower or complaints escalation procedures for governance participants (e.g., a carrier witnessing collusion among competitors, or a distributor experiencing discrimination) are not defined. A confidential escalation channel to an independent ombudsman or DG COMP should be established. (4) Member-State regulatory alignment is addressed via bilateral impact assessments by Month 3 (2027-01-12), but no formal procedure exists if a national regulator blocks the programme's design after binding standards are finalized (Month 18 = 2028-04-12). Current text says to 'defer that Member State' but operational mechanics and financial implications are undefined.
5. Thresholds, delegation and granularity gaps: (1) The Programme Office (80 staff) is responsible for EUR 1,500M budget execution and conformance audits for 25+ carriers, yet no sub-delegation structure below Programme Director is defined for day-to-day spending authority. Who approves invoices >EUR 100k? Who can commit funds for pilot support without OMB? Financial governance is too centralized for operational scale. Recommend clear spending matrices by role (e.g., Head of Clearing: <EUR 500k without approval, EUR 500k-EUR 5M with Programme Director, >EUR 5M with OMB). (2) Conformance testing assigns all carrier audits to 'independent test laboratory' (singular) but no redundancy is specified. If one lab is overwhelmed or compromised, the entire Tier 1 audit schedule (Months 24-30 = 2028-10-12 to 2029-04-12) is at risk. Recommend contracting 2-3 test laboratories with clear workload allocation. (3) SLA scorecards are published monthly to 'steering group and regulators' but no defined procedure exists for a carrier to formally dispute a scorecard result before it is published (potentially triggering funding-tranche withholding). A 10-business-day dispute and remediation review window before public release should be added.
6. Integration and information flow gaps: (1) Settlement reconciliation errors (target <0.5%) feed SLA scorecards, which trigger funding tranches, yet the clearing function's reconciliation results are owned by Head of Clearing and Settlement, not the independent test laboratory. A systematically erroneous clearing mechanism could bias all funding decisions, and no independent audit of the clearing function is scheduled before Month 30 (2029-04-12) go-live. Recommend an independent quarterly audit of clearing reconciliation from Month 6 (2027-04-12) onwards. (2) Passenger-rights compliance monitoring (CCPR) and operational re-accommodation monitoring (OMB/liaison officers) operate independently until post-Month 30 (2029-04-12) when a passenger-experience dashboard is created. During Months 12-18 (2027-10-12 to 2028-04-12) pilots and Months 30-48 (2029-04-12 to 2030-10-12) initial go-live, a passenger-rights gap discovered via operational complaints has no direct escalation path to CCPR until the next quarterly compliance review. A real-time escalation for 'passenger loses rights' incidents should be added. (3) Funding tranches are conditioned on conformance certificates, SLA targets and milestone achievement, but no mechanism exists to claw back or condition funding if a carrier fails post-certification (e.g., on Month 35 = 2029-09-12 an API fails and latency becomes 5 seconds). Recommend quarterly SLA re-audits post-certification and conditional funding holds if performance degrades.

## Tough Questions

1. By Month 4 (2027-02-12), have at least 8 major carriers (representing >70% of cross-border capacity) signed the liability model with binding caps, co-insurance thresholds and on-time-performance contribution weightings? If not, what is the plan B—are we deferring the Month 18 (2028-04-12) binding-standards deadline, or will we proceed with incomplete carrier buy-in, risking non-participation post-standards and fragmenting the network?
2. What is the specific technical design of the 'fallback technical interface' for independent distributors who reject the clearing architecture (Decision 2)? Has this interface been prototyped with Trainline, Omio or another distributor, and does it preserve settlement finality and SLA targets, or does it introduce a separate, slower settlement stream that could reduce through-ticket volumes by 15-25%?
3. By Month 12 (2027-10-12), have DG COMP confirmed in writing that the federated clearing layer with shared real-time data exchange is compatible with Article 101 TFEU, or is guidance still pending? If guidance is delayed beyond Month 12 (2027-10-12), do we freeze the OSDM specification at Month 18 (2028-04-12) with contingent compliance conditions, or do we defer binding standards and risk cascade delays to the mandatory API exposure deadline (Month 30 = 2029-04-12)?
4. What is the independent actuarial confidence interval (e.g., 90th percentile) on carrier-pool missed-connection incident rates and rerouting costs used to set the per-incident liability cap (proposed EUR 500-1,000 per stranded passenger) and co-insurance threshold (proposed EUR 50M annual pool draw)? If actual claims exceed the confidence interval significantly by Month 36 (2029-10-12), what are the policy triggers to adjust contributions or invoke the public reserve (EUR 150M), and at what point does pool sustainability force carriers to withdraw?
5. How many of the 25+ participating carriers have been formally committed (binding letters signed) to meet their assigned tier conformance deadline (Tier 1: Month 30 = 2029-04-12, Tier 2: Month 36 = 2029-10-12, Tier 3: Month 42 = 2030-04-12), and what is the financial consequence to a carrier that misses its deadline—do they lose 5%, 10% or 25% of their next funding tranche, and is there a point beyond which they are excluded from the programme entirely?
6. By Month 24 (2028-10-12), when Tier 1 conformance audits begin, will there be a published, independent technical review (by a third party, not the EU Agency for Railways) of the OSDM specification and test cases to ensure they do not inadvertently advantage incumbent carriers or disadvantage smaller operators? If not, what independent quality assurance exists to catch specification gaps that only emerge during carrier implementation?
7. What is the documented evidence that the proposed distribution-commission band (2.5-4.5% of through-fare, regulative supervision, identical for all distributors) actually covers distributors' cost of acquisition, payment processing and customer support for cross-border through-tickets? Has this band been validated against the distributor survey results (Month 4 = 2027-02-12)? If the band is below cost for any significant distributor type, will they participate, or will the commission band need to be widened post-Month 9 (2027-07-12)?
8. By Month 3 (2027-01-12), have all national railway regulators (across 5-6 member states with 25+ operators) been engaged bilaterally and formally signaled their regulatory approval or concern regarding the programme's data-sharing, clearing and mandatory API exposure requirements? If major regulatory conflicts are identified, what is the timeline and procedure to resolve them by Month 18 (2028-04-12) binding standards, or do we defer certain member states to a Phase 2 rollout (post-Month 60 = 2031-10-12)?
9. If the concessionaire (selected by Month 18 = 2028-04-12, service live by Month 30 = 2029-04-12) operates at 60% of forecast volume in its first 12 months (Month 30-42 = 2029-04-12 to 2030-04-12), triggering a contract-review clause, what is the contingency—do we increase subsidy (within the EUR 60M cap), redirect passengers to private distributors, defer TEN-T extension, or invoke a service-replacement process? Is this decision OMB-level or escalated to PSC?
10. By Month 42 (2030-04-12), when Tier 3 conformance is complete (or deferred), what percentage of the 25+ participating carriers are expected to be live with full conformance (Tiers 1-3), and what happens to carriers who remain outside the programme after Month 42 (2030-04-12)—are they permanently excluded, invited to join TEN-T extension (Months 48-60 = 2030-10-12 to 2031-10-12), or does the programme explicitly accept that full TEN-T coverage will not be reached by Month 60 (2031-10-12)?

## Summary

The governance framework establishes a multi-tiered structure with clear strategic (PSC, 75% supermajority voting), operational (OMB, week-to-month cycles), compliance (CCPR, legal expertise), and technical (TSWG, standards custodianship) layers, anchored by a dedicated Programme Office (80 staff) and Technical Secretariat (50 staff) reporting to the EU Agency for Railways. Critical decisions (liability backstop, clearing architecture, public distributor role, funding release conditions) are locked in by Month 6 (2027-04-12), binding standards by Month 18 (2028-04-12), and mandatory API exposure by Month 30 (2029-04-12), with four-corridor through-ticketing by Month 48 (2030-10-12) and full TEN-T extension by Month 60-72 (2031-10-12). Governance credibility rests on three pillars: (1) escalation clarity—unresolved conflicts at PSC level escalate to the Commission Transport Commissioner by Month 5 (2027-03-12) for binding mediation; (2) financial controls—quarterly variance tracking with EUR 100M/EUR 200M/EUR 300M triggers that force policy adjustments rather than silent budget creep; (3) independent oversight—CCPR ensures competition-law and passenger-rights compliance, and conformance audits by independent test laboratories validate carrier readiness. Key gaps requiring closure before binding standards: formal definition of the distributor fallback interface (technical and operational), conflict-of-interest and whistleblower procedures for governance staff, independent audit of the clearing reconciliation mechanism, sub-delegation spending matrices within the Programme Office, and bilateral regulatory approval from all participating member states. The framework is operationally complex but strategically coherent, with clear role boundaries and escalation paths that should sustain the EUR 1,500M public budget and five-year timeline provided stakeholder consensus is achieved by Month 6 (2027-04-12) and regulatory/competition-law obstacles are resolved by Month 18 (2028-04-12).