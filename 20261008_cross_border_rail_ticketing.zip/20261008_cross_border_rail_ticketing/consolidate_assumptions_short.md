# Purpose
# Coordinated European Program for Cross-Border Rail Through-Ticketing and Digital Booking

## Overview

Large-scale, multi-stakeholder public infrastructure and governance initiative. Covers OSDM-compatible shared real-time data layer, inter-carrier clearing and settlement mechanism, passenger-rights backstop, public reference distributor, and consumer-side rollout. Enables any compliant distributor to sell through-tickets across EU carriers over a five-year horizon.

## Key Milestones

- Binding standards by Month 18 (2028-04-08)
- Mandatory API exposure by Month 30 (2029-04-08)
- Full corridor through-ticketing by Month 60 (2031-10-08)

## Budget and Investment

- Public coordination budget: €1.5 billion (user constraint)
- Private carrier IT investment estimated separately

## Targets

- 40% of cross-border journeys sold as through-tickets
- Distributor complaints halved
- Modal shift from short-haul air to rail


# Domain
# Primary domain: Rail Ticketing Interoperability

## Secondary domains

- Transport Regulation
- Clearing and Settlement
- Passenger Rights Law

## Rationale

Rail Ticketing Interoperability is the outcome-role candidate and matches the core mechanism of cross-border through-ticketing. Transport Regulation, Data Interoperability Architecture, Clearing and Settlement and Public Program Management are constraints or methods subordinate to that goal.

## Disciplines this project involves

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Rail Ticketing Interoperability | 5 | 5 | outcome | Core mechanism: OSDM-compatible through-ticketing, distribution, and booking across carriers on cross-border corridors. |
| Transport Regulation | 5 | 4 | constraint | Must align with the EC proposed rail booking regulation, passenger rights, and national regulators. |
| Data Interoperability Architecture | 5 | 4 | method | Shared real-time data layer with OSDM-compatible APIs demands standards-based API and data architecture. |
| Clearing and Settlement | 4 | 4 | method | Inter-carrier revenue clearing and single-payment settlement underpin through-ticket sales. |
| Passenger Rights Law | 4 | 4 | constraint | Continuity-of-journey, refund harmonisation and passenger-rights backstop require EU consumer and transport law expertise. |
| Competition Law | 4 | 4 | constraint | Non-discriminatory distributor access and inter-carrier data and fare sharing raise antitrust and access obligations. |
| Payment Systems | 4 | 4 | method | Single-payment settlement and refunds across carriers require payment orchestration and split-payment design. |
| Public Program Management | 4 | 3 | method | Coordinating a €1.5 billion, multi-stakeholder, five-year program across member states requires program governance. |
| Accessibility Compliance | 3 | 4 | constraint | Persons with reduced mobility assistance booking must meet accessibility rules and disability-rights requirements. |

# Plan Type
# Physical Execution Requirement

This plan requires one or more physical locations and cannot be executed digitally.

## Rationale

The plan centres on digital artefacts (OSDM-compatible APIs, shared real-time data layer, booking systems, clearing and settlement mechanism) but is a multi-year EU-wide rail transport programme with extensive physical dependencies:

- Rail operations and passenger journey: goal is to ease cross-border train travel and shift travellers from short-haul flights to trains. Outcome is physical movement of passengers on trains across Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich, Madrid–Barcelona–Lyon and Copenhagen–Hamburg–Berlin corridors, and later across the TEN-T network.

- Physical stations and rolling stock: through-ticketing with continuity-of-journey rights, disruption handling, passenger-rights backstop, bicycle reservations and assistance for reduced-mobility persons require on-the-ground operations including station staff, boarding and assistance services, bicycle spaces on trains, and ticket validation and inspection on board.

- Integration with other transport modes: scope includes hooks for buses, ferries and short-haul air, which are physical services at terminals, ports and airports.

- Conformance and field testing: conformance testing of carrier systems and pilots on live corridors require test environments, devices (validators, handheld inspection devices, kiosks and ticket machines) and real-world trials with operators and passengers.

- Hardware and facilities: carrier IT investment, data centres, development workspaces, and physical hardware that standards work and software development depend on.

- In-person governance and stakeholder coordination: programme involves DG MOVE, EU Agency for Railways, CER, national operators, national regulators, BEUC and disability-rights bodies. Includes member-state capacity building through workshops, meetings in Brussels and national capitals, and regulator engagement.

- Consumer-side rollout: apps and multilingual support are digital, but rollout needs physical channels such as station information, staff training and call centres.

- Large-scale delivery with €1.5 billion public budget over five years requires offices, staff, procurement and site work. Software and API development have physical elements: workspaces, hardware and real-device testing.

Under the "any doubt means physical" rule, and because the programme's real-world outcomes depend on physical trains, stations, people and locations, it is physical.

# Physical Locations
# Physical Locations

## Requirements for physical locations

- Major EU transport hubs and capital cities with strong rail infrastructure
- Four priority cross-border rail corridors: Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin
- Access to national rail operators and regulatory authorities
- Proximity to conformance testing facilities and carrier IT operations centres
- Capacity for multi-stakeholder governance coordination (DG MOVE, EU Agency for Railways, CER, national regulators, BEUC)
- Integration with broader TEN-T network infrastructure
- Accessibility to member-state capacity-building venues and workshops

## Location 1: Belgium – Brussels

Brussels, European Quarter or near Central Station

## Rationale

Brussels is the primary hub for EU institutional coordination (DG MOVE, Commission, Council). It is central to the Paris–Brussels–Amsterdam–Köln corridor and sits at the intersection of major cross-border rail networks. Hosting the programme governance vehicle, arbitration panel and stakeholder coordination here ensures proximity to decision-makers and regulatory authorities while serving the initial priority corridors.

## Location 2: Germany – Cologne (Köln) and/or Frankfurt

Cologne or Frankfurt rail hub or regional IT centres

## Rationale

Cologne terminates one of the four priority corridors (Paris–Brussels–Amsterdam–Köln). Frankfurt is Deutsche Bahn's operational hub and a major European rail and logistics centre. Either location enables conformance testing, carrier IT coordination and integration of one of the most complex multicarrier operations (SNCF, SNCB, NS, Deutsche Bahn) within the priority network.

## Location 3: Austria – Vienna

Vienna, central rail hub or near ÖBB operations centre

## Rationale

Vienna anchors the Wien–München–Zürich corridor and is home to ÖBB (Austrian Federal Railways) and the EU Agency for Railways. It serves as a secondary coordination hub for central European carriers and regulators, and enables testing and capacity building for the eastern TEN-T extension beyond the initial four corridors.

## Location Summary

The programme is physically rooted in the four priority cross-border rail corridors and the broader TEN-T network. Governance and standards coordination are centred in Brussels (proximity to EU institutions and DG MOVE). Conformance testing, carrier IT integration and initial corridor rollout are deployed across the corridor hubs: Cologne/Frankfurt for the Paris–Brussels–Amsterdam–Köln route, Vienna for Wien–München–Zürich, and Madrid/Barcelona and Copenhagen/Hamburg/Berlin for the southern and northern corridors respectively. Each location serves as a base for carrier onboarding, regulatory liaison, and real-world testing against live rail operations, while the regional shared booking hubs (per the Pragmatic Foundation scenario) are sited in consortia-run facilities near major operators in each corridor region.

# Currency Strategy
and

# Identify Risks
# Risk 1 - Regulatory & Permitting

The Commission's proposed Regulation on Digital Booking and Ticketing Services for Rail (May 2026) remains unadopted by Parliament and Council. Parliamentary amendments, member-state negotiations and legal review could extend adoption into Month 6–12 (2027-04-08 to 2027-10-08). If adoption slips beyond Month 9 (2027-07-08), insufficient time remains to complete binding standards (Month 18 = 2028-04-08) and produce tested implementations before the mandatory API exposure deadline (Month 30 = 2029-04-08). Final text divergence could require rework of standards and access-term rules.

## Impact

Delay of final regulation beyond Month 9 (2027-07-08) reduces the standards-setting window from 9 months to 3–4 months, eliminating margin for stakeholder consultation or dispute resolution. This forces either rushed, untested standards (risking non-compliance) or missed Month 18 (2028-04-08) targets. A slipped deadline undermines buy-in for later gates. Estimated impact: Month 18 (2028-04-08) standard missed or delivered without consensus, and Month 30 (2029-04-08) mandate questioned by carriers and member-state regulators.

## Likelihood

Medium

## Severity

High

## Action

Establish direct liaison between DG MOVE and Parliamentary rapporteurs (TRAN, IMCO) and key member-state transport ministers to track adoption from Month 0 (2026-10-08) onward. Conduct shadow legislative tracking and begin technical standards pre-work (gap analysis against OSDM, access-term sketches) in Month 0–3 (2026-10-08 to 2027-01-08) under a 'without prejudice' frame. If adoption slips beyond Month 8 (2027-06-08), contract rapid standards review by external consortium and trigger early carrier engagement workshops to assess readiness and unblock technical surprises.

# Risk 2 - Governance & Institutional

The Pragmatic Foundation proposes a lightweight arbitration panel layered on existing institutions (DG MOVE, EU Agency for Railways) to avoid new legal entities and their set-up delays. However, establishing binding authority for technical disputes without explicit legal power or formal board can lead to non-compliance when large incumbents contest rulings. Member-state sovereignty concerns and differing national regulatory powers may limit enforcement of arbitration outcomes, especially in cross-border access and refund disputes. The lack of dedicated budget holder and staff resource could slow decision cycles.

## Impact

Contested technical decisions drag on 2–6 months without binding resolution, holding up corridor gates and carrier onboarding. Incumbents can challenge arbitration findings, forcing escalation to Commission or court, which delays implementation. An estimated 2–4 month slippage per major dispute (inventory parity thresholds, refund timing rules) compounds across Month 18–30 (2028-04-08 to 2029-04-08). Non-compliance by a major carrier on access terms could force renegotiation of the entire access model.

## Likelihood

Medium

## Severity

High

## Action

Secure explicit written mandate from the Commission and Council before Month 1 (2026-11-08), delegating binding technical decision authority to the arbitration panel with time limits (60 days to ruling, 14 days to comply or escalate). Draft a Memorandum of Understanding among DG MOVE, the EU Agency for Railways and the panel, specifying governance, staffing, budget and escalation to the Commission for non-compliance. Allocate 8–12 FTE to the panel in Month 1–2 (2026-11-08 to 2026-12-08), with authority to call emergency meetings. Schedule carrier engagement workshops (Month 2–4 = 2026-12-08 to 2027-02-08) on access terms, inventory rules and settlement so contested areas surface early before the panel is forced to arbitrate.

# Risk 3 - Technical & Integration

Carriers' booking back-ends range from modern (SNCF, Deutsche Bahn newer systems) to legacy mainframe (some regional operators, ÖBB, older systems). The Pragmatic Foundation proposes regional shared hubs to bridge weaker operators until they modernise, but hub effectiveness depends on how faithfully a hub translation layer maps legacy inventory and business rules to OSDM. Mapping errors (oversold seats, missing restrictions, incorrect pricing) break through-tickets and trigger rights claims. Hub operators may lack incentive to innovate, becoming bottleneck dependencies.

## Impact

A regional hub mapping error (missing seat allocation logic, double-booking of restricted inventory) causes 5–15% of booked through-tickets to fail at final confirmation or on boarding, triggering passenger complaints, refund disputes and distributor liability claims. Each corridor's hub failure holds up 1–3 months of onboarding while the mapping is debugged. If a hub operating as a single point of failure covers 4–6 operators, its outage grounds through-ticketing for that region for 6–48 hours, causing estimated cascading refund obligations of €100,000–500,000 per incident. Estimated recovery cost per hub: €0.5–2 million over Years 1–3.

## Likelihood

Medium

## Severity

High

## Action

Define hub API specifications and test harnesses in Month 2–4 (2026-12-08 to 2027-02-08) in close collaboration with legacy operators and hub operators; use external test lab to validate mapping correctness against real inventory samples from each carrier before go-live. Mandate dual-run (hub and native) for 2–4 weeks per carrier to detect mapping errors before traffic is cut over. Establish a hub incident response team with on-call escalation to the carrier's inventory team, with target resolution time of 2 hours for critical failures. Require hub operators to carry E&O liability insurance covering overstated availability and inventory errors.

# Risk 4 - Financial & Budget

The €1.5 billion public coordination budget (user constraint) is fixed over five years and must cover standards work, conformance testing, the clearing mechanism, a public reference distributor, member-state capacity building and consumer-side rollout. The Pragmatic Foundation allocates milestone-based co-funding to smaller carriers. However, actual carrier IT integration costs and the scale of public reference distributor operations are not yet estimated. If private carrier spend is significantly higher than expected, or if the reference distributor must operate longer than planned, budget pressure could force cuts to capacity building or conformance testing, slowing smaller carriers' adoption.

## Impact

If co-funding commitments to carriers exceed budget by 20–30% (€300–450 million shortfall), conformance testing budget is cut by 40–50%, slowing certification of smaller operators by 6–12 months and pushing some past the Month 30 (2029-04-08) mandate. The public reference distributor, intended as temporary benchmark, may need to operate until Month 48 (2030-10-08) or beyond to capture the 40% through-ticket target, consuming €200–400 million in operating costs not provisioned. Estimated shortfall risk: €150–500 million before Month 36 (2029-10-08).

## Likelihood

Medium

## Severity

High

## Action

Commission a detailed cost model in Month 0–2 (2026-10-08 to 2026-12-08) estimating private carrier IT spend by carrier size, public reference distributor annual operating cost, and per-carrier co-funding need for gateway/hub use, with sensitivity to currency fluctuations across non-eurozone carriers (DKK, SEK, CHF). Define baseline budget burn and trigger points for mid-course reviews (Month 12 = 2027-10-08, Month 24 = 2028-10-08). Establish a contingency reserve of 10–15% (€150–225 million) held at DG MOVE for urgent gaps. Tie co-funding disbursement to verified milestone completion (API exposure, data-quality attestation) to avoid moral hazard.

# Risk 5 - Competitive & Market

The programme aims for 40% of cross-border journeys sold as through-tickets within five years, and modal shift from short-haul flights. These targets assume through-tickets become cheaper, faster or more convenient than separate operator tickets or competing flights. However, through-fares are constrained by sum-of-segment pricing (the Pragmatic Foundation scenario allows transparency but not regulated fare ceilings), and commercial distributors (Trainline, Omio) may lack sufficient incentive to promote the programme if margins are compressed. Airlines have strong incentive to compete aggressively on price and frequency on the priority corridors.

## Impact

If through-fares remain 10–25% more expensive than sum-of-separate-operator-tickets or competing flights, the 40% target is unachievable; uptake plateaus at 15–25%, missing the headline goal. Airlines respond with aggressive pricing and increased frequency on Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich and Madrid–Barcelona–Lyon by Month 18–24 (2028-04-08 to 2028-10-08), capturing price-sensitive passengers. Commercial distributors capture only the convenience premium, while the public reference distributor is forced to maintain higher volumes to show success, consuming extra budget. Estimated shortfall: 5–15 percentage points below target by Month 60 (2031-10-08).

## Likelihood

Medium

## Severity

Medium

## Action

Conduct detailed competitive pricing and margin analysis in Month 2–4 (2026-12-08 to 2027-02-08) comparing through-fares to competing flights and separate tickets, with sensitivities to fuel prices, aviation taxes and seat load factors. Model the effect of reduction-card harmonisation and cross-border accessibility assistance on price perception. Work with Trainline and Omio in Month 3–6 (2027-01-08 to 2027-04-08) to understand margin requirements and agree on promotional commitments in exchange for early API access or preferred inventory terms. Reserve a portion of the public reference distributor budget for targeted campaigns on the priority corridors where air competition is strongest, positioned as 'train travel made simple' rather than price-focused.

# Risk 6 - Operational & Implementation

The programme requires simultaneous capacity building in member-state regulators (27 different legal systems, enforcement traditions and data-protection practices), technical standards alignment across 25+ carriers, conformance testing infrastructure, clearing and settlement integration, and consumer-side rollout (apps, multilingual support, complaint handling). Coordination across multiple European hubs involves constant travel, workshops and real-time decision-making. A complex governance structure with multiple working groups, advisory bodies and decision forums can lead to meetings overhead, slow circulation of minutes and decisions, and stakeholder fatigue.

## Impact

Governance overhead and working-group proliferation consume 20–30% of programme staff time without proportional output, slowing standards finalisation by 3–6 months. Regulator capacity building courses are planned but poorly attended or not funded by member states, leaving weaker regulators unable to enforce access duties, creating a two-tier compliance landscape. Conformance testing backlogs build up, delaying carrier certification and forcing gate relaxation. Consumer-side rollout (app, support, complaint handling) is under-resourced and launches late, leaving passengers confused about which itineraries are actually bookable. Estimated delay impact: Month 30 (2029-04-08) API mandate at risk if more than 3–4 carriers slip, and consumer satisfaction targets missed.

## Likelihood

High

## Severity

Medium

## Action

Establish a lean core programme management office (PMO) of 10–15 FTE in Month 1 (2026-11-08) based in Brussels, with decision authority over meeting schedules, agendas and minutes circulation. Implement a project tracking tool (e.g., Asana, Monday.com) visible to all stakeholders, with weekly status dashboards, red-flag escalation, and a single clearinghouse for decisions. Fund regulator capacity building as a dedicated workstream with identified trainers and attendees in Month 2–3 (2026-12-08 to 2027-01-08), with follow-up coaching for slower regulators in Month 12–18 (2027-10-08 to 2028-04-08). Establish a conformance testing steering committee that tracks carrier readiness weekly and flags slippage to funding levers by Month 12 (2027-10-08). Ring-fence consumer-side rollout as a separate project with dedicated budget and a clear go-live date (Month 27 = 2029-01-08) for pilot corridors.

# Risk 7 - Legal & Regulatory

Cross-border rail journeys involve passenger data flows across 27 member states with varying GDPR interpretations, data residency rules and consent regimes. A through-ticket clearinghouse or hub necessarily sees passenger PII (name, contact, payment details, accessibility needs), and distributing that data among carriers for fulfillment creates both compliance risk and consumer trust vulnerability. National data protection authorities may impose conflicting requirements on data location, retention and consent, especially for accessibility information and refund-related communications.

## Impact

A data protection authority in one member state challenges the data-sharing architecture and issues a ban on cross-border data flow without explicit consent, forcing a redesign 6–12 months into implementation. This delays Month 18 (2028-04-08) standards approval or creates a workaround that weakens through-ticket continuity (no automatic assistance rerouting, no real-time disruption messaging to passengers). Compliance costs to carriers (consent management, data minimization, audit trails) increase by 10–20%, adding €50–150 million to private IT budgets and deterring smaller carriers. Estimated delay: 3–6 months if a standards revision is needed; consumer trust impact if passengers feel data is misused.

## Likelihood

Medium

## Severity

High

## Action

Commission a GDPR and data-protection impact assessment (DPIA) in Month 0–2 (2026-10-08 to 2026-12-08), mapping which PII flows are necessary for booking, fulfillment, refund and accessibility, and identifying minimum-data designs for each. Conduct early engagement with the European Data Protection Board (EDPB) and national authorities in Month 2–4 (2026-12-08 to 2027-02-08) to achieve informal consensus on data residency, cross-border transfer mechanisms (Standard Contractual Clauses, Binding Corporate Rules) and consent regimes before standards are finalised. Embed a data-protection specialist in the standards working group, and include GDPR compliance in the conformance checklist so carriers are audited on consent, retention and breach notification.

# Risk 8 - Supply Chain & Integration

The through-ticketing programme depends on payment institutions (for split-payment orchestration), clearing systems (message standards, revenue apportionment), IT service providers (hub operations, testing infrastructure), and telecom/data-centre operators (APIs, data-layer hosting). The Pragmatic Foundation proposes accredited payment institutions, but there is no pre-established market of providers meeting the requirements (multi-currency, multi-carrier settlement, EU licensing, SLA guarantees). If accreditation is lengthy or few providers apply, the programme is forced to fall back on bilateral carrier-to-carrier settlement (weaker, slower) or delay clearing until custom providers are built.

## Impact

Accreditation process takes 6–12 months (Month 2–14 = 2026-12-08 to 2027-12-08), and only 1–2 providers come forward initially, leaving little choice. If an accredited provider fails or withdraws during Month 18–30 (2028-04-08 to 2029-04-08), switching to a replacement is disruptive and could delay the API mandate. A shortage of qualified testing infrastructure labs delays conformance testing by 2–4 months per carrier. Estimated impact: Month 30 (2029-04-08) mandatory API exposure at risk if settling mechanism is not fully operational, and carrier onboarding gates slip by 4–8 weeks per carrier.

## Likelihood

Medium

## Severity

Medium

## Action

Launch a market sounding in Month 0–1 (2026-10-08 to 2026-11-08) to identify potential payment and clearing-service providers, communicate accreditation criteria and timeline, and gauge provider interest. Draft accreditation rules in Month 1–3 (2026-11-08 to 2027-01-08) in consultation with licensed payment institutions and the ECB, and issue a call for applicants by Month 2 (2026-12-08) with a target decision by Month 8 (2027-06-08). Require at least 2–3 accredited providers by Month 12 (2027-10-08), with contractual provisions for continuity and redundancy if any withdraw. For testing infrastructure, procure a European network of conformance testing labs in Month 1–3 (2026-11-08 to 2027-01-08) with SLAs guaranteeing carrier test slots within 6 weeks of booking.

# Risk 9 - Operational & Implementation

The programme aims to harmonise refund policies, disruption handling and passenger-rights claims across carriers and distributors, but existing EU rail passenger rights rules (Regulation 1371/2007) differ from the revised text (adopted 2023, effective 2025), and member states have not yet harmonised enforcement. Some carriers interpret care obligations narrowly (meal vouchers only), others broadly (hotel, transport). A through-ticket sold by a distributor that promises continuity-of-journey rights must resolve claims faster and more consistently than multi-operator journeys today, but carriers have no shared process and national enforcement is fragmented.

## Impact

A passenger's through-ticket is disrupted, and the distributor and two carriers trade blame for 4–8 weeks while the passenger waits for refund or compensation. Public complaints about slow, inconsistent refunds and unmet care obligations force intervention by national regulators, creating reputational damage and media coverage. If refund disputes consume more than 10–15% of through-tickets sold, the programme's credibility collapses and distributors withdraw. Estimated impact: 5–10% of through-tickets disputed, average claim resolution 8–12 weeks (vs. target of <10 days), and estimated liability pool of €20–50 million in years 2–3.

## Likelihood

Medium

## Severity

Medium

## Action

Develop a common refund and rights-claim protocol in Month 2–4 (2026-12-08 to 2027-02-08) specifying: (1) single point of contact (distributor or carrier, clearly assigned per journey); (2) required response time (48 hours acknowledgement, 10 days decision); (3) evidence collection (real-time disruption data, booking record); (4) apportionment rules (who bears cost of rerouting, care, refund). Draft a Memorandum of Understanding binding all carriers and accredited distributors, with penalties (0.5–1% of quarterly through-ticket revenue) for consistent non-compliance. Establish a dispute-resolution panel (Month 6 = 2027-04-08) with rotating carrier and distributor representatives, empowered to rule on contested claims within 5 days. Fund a pilot on one corridor (e.g., Paris–Brussels–Amsterdam) in Month 12–18 (2027-10-08 to 2028-04-08) to test the process and refine timelines before full rollout.

# Risk 10 - Market & Competition

The programme creates a shared real-time inventory and fare data layer with strict non-discrimination rules to prevent incumbents from blocking distributor access. However, Articles 101 and 102 TFEU competition law and merger control could be triggered if competitors (carriers) coordinate on fares, load factors or ancillary services through the shared layer. Even with safeguards (data minimisation, neutral operator, access logs), regulators (DG Comp, national authorities) may open investigations into anticompetitive data sharing, especially if modal-shift goals incentivise carriers to act in concert on pricing.

## Impact

DG Comp or a national competition authority initiates an investigation into alleged data-sharing collusion in Month 12–18 (2027-10-08 to 2028-04-08), creating legal uncertainty and requiring carriers to curtail data contributions until cleared. An investigation lasting 12–24 months delays full data-layer rollout and carrier integration, pushing the Month 30 (2029-04-08) API mandate at risk. In a worst-case scenario, a decision orders the data layer to be redesigned or dismantled, requiring a 6–12 month overhaul. Legal and compliance costs to the programme rise by €10–30 million, and carrier trust erodes. Estimated delay impact: Month 30–42 (2029-04-08 to 2030-04-08) if investigation and remedy take 12 months.

## Likelihood

Medium

## Severity

Medium

## Action

Secure a formal block-exemption letter or comfort letter from DG Comp in Month 2–6 (2026-12-08 to 2027-04-08) specifying the data-sharing scope and safeguards that will prevent antitrust scrutiny. Draft a detailed competition-law analysis (submitted to DG Comp as a pre-filing memo) explaining why the data layer is pro-competitive (enables distributor entry, combats incumbent lock-in) and what access and confidentiality rules preclude collusion. If a full block exemption is not feasible within timeline, seek a negative-clearance decision or a comfort letter. Establish a designated neutral operator for the data layer with clear governance rules (no preferential access, transparent logging of all queries) to demonstrate independence. Include antitrust compliance audits in the conformance testing process.

# Risk 11 - Stakeholder & Political

The programme must balance incumbent carriers' IT investment burden (estimated €500 million to €2 billion private spend, not in the €1.5 billion public budget), smaller carriers' adoption risk (especially weaker operators in southern and eastern Europe), and distributors' margin pressure. Political pressure from member states (especially those with large incumbent carriers) and from transport unions (fearing job losses in disrupted operations) could slow decision-making or force compromises that weaken non-discrimination rules. If a major carrier (Deutsche Bahn, SNCF, ÖBB) signals non-compliance or demands exemptions, other incumbents follow, fracturing the coalition.

## Impact

Deutsche Bahn or SNCF announces in Month 12–18 (2027-10-08 to 2028-04-08) that API integration will not meet the Month 30 (2029-04-08) deadline due to legacy system incompatibility, forcing a renegotiation of the mandate timeline. Other carriers use this as justification for slower rollout, and the Paris–Brussels–Amsterdam–Köln corridor gates slip by 6–12 months. Political pressure from Germany or France results in weaker enforcement provisions in the final Regulation or in exemptions for 'strategic' operators. Distributor confidence erodes, and commercial platforms hold back full investment, forcing the public reference distributor to expand beyond its intended scope. Estimated impact: Month 30 (2029-04-08) mandate becomes advisory rather than binding, and 40% through-ticket target drops to 25–30%.

## Likelihood

Medium

## Severity

High

## Action

Establish a formal carrier engagement and negotiation stream in Month 1 (2026-11-08) with quarterly roundtables between DG MOVE, CER and the largest carriers (Deutsche Bahn, SNCF, Trenitalia, Renfe, ÖBB, NS, SJ, SNCB). Use these forums to identify IT cost-sharing opportunities (shared hubs, co-funding for legacy migration) and to air concerns early before they harden into political demands. Engage transport unions from Month 2 (2026-12-08) onward with transparency about job impacts and a commitment to funding transition support (retraining, consultation). Build political cover by securing visible member-state support (Belgium, Netherlands, Austria) early and regularly reporting programme progress to the European Parliament's TRAN committee. If a major carrier signals non-compliance, escalate immediately to the Commission and invoke contingency funding levers (co-funding holds) to signal consequences.

# Risk 12 - Technical & Integration

The shared real-time data layer exposes inventory, fares and disruption data via OSDM-compatible APIs to distributors and other carriers. API reliability, latency and uptime directly affect passenger experience and distributor confidence. If APIs are slow (>5 seconds per search), unreliable (>99.9% uptime target unmet), or return stale data (seats unavailable when booking), through-tickets fail, passengers complain and distributors lose confidence. Legacy carriers' systems may not support the required API throughput (estimated 100–500 requests/second per corridor during peak hours), requiring expensive infrastructure upgrades.

## Impact

API latency exceeds 5 seconds during peak hours (Month 18–24 = 2028-04-08 to 2028-10-08), causing 10–20% of search sessions to timeout. Distributors report poor user experience and pull back from promoting through-tickets. An unplanned API outage of 4–8 hours affects 10,000–50,000 daily searches, generating escalations to DG MOVE and negative media coverage. A cache or hub serving a corridor fails and takes 12–48 hours to recover, stranding all through-ticket bookings on that route. Estimated impact: distributor frustration and withdrawal, passenger complaints, and potential Month 30 (2029-04-08) credibility hit.

## Likelihood

Medium

## Severity

Medium

## Action

Define API performance SLAs in Month 2–3 (2026-12-08 to 2027-01-08): latency <2 seconds (p95), uptime 99.95%, throughput ≥500 req/s per corridor. Conduct a carrier infrastructure assessment (Month 3–4 = 2027-01-08 to 2027-02-08) to identify systems that cannot meet these targets and prioritise co-funding for upgrades. Procure a European-wide API hosting and caching infrastructure in Month 2–6 (2026-12-08 to 2027-04-08) with guaranteed SLAs, redundancy across data centres and failover protocols. Establish a 24/7 API operations centre in Month 6 (2027-04-08) with escalation to carriers within 15 minutes of any incident. Conduct load testing and chaos engineering exercises quarterly starting Month 9 (2027-07-08) to identify weak points before they affect production.

# Risk 13 - Financial & Budget

The programme uses accredited payment institutions to handle split-payment orchestration and refund processing, avoiding licensing delays of a central clearing entity. However, payment institutions charge transaction fees (estimated 0.5–2% per transaction, or €5–20 million annually for anticipated through-ticket volumes). These costs must come from the €1.5 billion public budget or be borne by carriers and distributors, who will pass them to passengers in higher fares. Additionally, multi-currency settlement across 9+ currencies (EUR, DKK, SEK, CHF, PLN, CZK, HUF, BGN, RON) incurs foreign-exchange costs and conversion-rate volatility that could consume €2–5 million annually.

## Impact

Transaction fees to payment institutions total €80–120 million over five years, consuming 5–8% of the fixed public budget and requiring cuts elsewhere (conformance testing, capacity building). If passengers see higher through-fares as a result of bundled fees, the 40% target becomes harder to reach. Currency volatility in Years 2–5 causes €10–25 million in unexpected FX losses if not hedged, further straining the budget. A less efficient payment infrastructure (settling only nightly instead of real-time) delays carrier payouts by 1–3 days, undermining cash-flow confidence and raising financing costs for smaller carriers.

## Likelihood

High

## Severity

Low

## Action

Model transaction fee scenarios in Month 1–2 (2026-11-08 to 2026-12-08) and negotiate fee caps (0.3–0.5% per transaction) into the accreditation criteria. Establish a fee-sharing formula in which the programme subsidises 50–70% of payment-institution fees for the first 2 years (Month 0–24 = 2026-10-08 to 2028-10-08), with carriers and distributors bearing the remainder, conditional on through-ticket volumes reaching 15% (Month 24 = 2028-10-08 baseline). For FX management, implement a quarterly hedging policy that caps exposure to non-EUR currencies at 5–10% of quarterly disbursements, using EUR-denominated forward contracts. Require accredited payment institutions to offer real-time settlement (intraday clearing) at no extra cost as part of the accreditation SLA.

# Risk 14 - Operational & Implementation

The programme's consumer-side rollout includes a multilingual booking app, customer support in 24+ languages, and complaint handling across member-state jurisdictions. Launching a consumer product at EU scale within Months 15–27 (2028-01-08 to 2029-01-08) requires design iteration, user testing, platform scaling and localization. If the app is poorly designed, slow or untrustworthy, it will damage the programme's credibility and reduce through-ticket adoption. Supporting passengers in multiple languages and navigating cross-border disputes requires a large, trained support team.

## Impact

The app is released 3–6 months late (Month 21–24 = 2028-07-08 to 2028-10-08 instead of Month 15 = 2028-01-08), missing the momentum of early corridor launches. Initial user satisfaction is low (3.5/5 stars) due to poor search, confusing refund flows or missing accessibility features, discouraging adoption. Support queue times exceed 2 hours, and a backlog of unresolved complaints (1,000+) accumulates within 3 months of launch. Estimated impact: 20–30% reduction in through-ticket volumes driven through the public reference distributor, and reputational damage requiring a costly app redesign and support surge.

## Likelihood

Medium

## Severity

Medium

## Action

Establish a dedicated consumer product team in Month 1 (2026-11-08) with 20–30 FTE (product managers, engineers, UX designers, localization specialists). Conduct user research and wireframing in Month 2–4 (2026-12-08 to 2027-02-08), then build a minimum viable product (MVP) for pilot testing on one corridor by Month 9 (2027-07-08). Iterate based on user feedback during Month 10–12 (2027-08-08 to 2027-10-08), and begin full-scale localization and platform scaling in Month 12–15 (2027-10-08 to 2028-01-08). Launch the public app by Month 15 (2028-01-08) with a phased rollout (four priority corridors first, then TEN-T) and a commitment to sub-1-hour support response time for critical issues. Budget €20–30 million for app development, infrastructure and support over Months 15–27 (2028-01-08 to 2029-01-08).

# Risk 15 - Measurement & Evaluation

The programme targets 40% of cross-border journeys sold as through-tickets, halved distributor complaints, and modal shift from air. However, baseline data on current cross-border rail sales, complaint volumes and modal split do not exist in a consolidated form. Carriers report different metrics, distributors guard proprietary data and aviation data come from EUROSTAT (not real-time). Defining and tracking the targets consistently requires establishing common data collection, but carriers may resist mandatory reporting if they fear exposure of commercial sensitivities.

## Impact

Baseline is not established until Month 9–12 (2027-07-08 to 2027-10-08), delaying mid-course correction insights until Year 2. Without a clear baseline, disputes arise over whether targets are being met, undermining credibility of progress reports. If carriers refuse to report through-ticket volumes, the programme relies on distributor data only, missing operator-to-operator sales and understating true market share. An estimated 15–25% undercount of true through-ticket share is possible, requiring either disclaimer caveats or expensive corrective measurement programmes. By Month 36–48 (2029-10-08 to 2030-10-08), claims about achieving targets become contested and politically vulnerable.

## Likelihood

Medium

## Severity

Low

## Action

Commission a baseline survey in Month 0–2 (2026-10-08 to 2026-12-08) asking carriers, distributors and airports for current cross-border sales volumes, complaint handling metrics and modal split estimates (with confidentiality protections for sensitive data). Define 'through-ticket' operationally in Month 1–2 (2026-11-08 to 2026-12-08): e.g., 'single booking reference, single payment, continuity-of-journey rights for a multi-carrier journey.' Mandate that all participating carriers and distributors report through-ticket volumes monthly starting Month 18 (2028-04-08), with data aggregated and published quarterly with a 1-month lag (to protect commercial sensitivity). Hire an independent evaluation firm in Month 3 (2027-01-08) to build a counterfactual model comparing through-ticket adoption on priority corridors to control routes outside the rollout, capturing the modal-shift impact separately from fuel prices and capacity changes. Reserve €5–10 million of the public budget for measurement and evaluation.

# Risk 16 - Regulatory & Permitting

The four priority corridors (Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin) cross multiple national rail regulators with different inspection powers, license frameworks and operational safety requirements. A through-ticket system must be compatible with each regulator's safety and operational standards, and any accident or incident (e.g., a through-ticket passenger injured due to missed connection, or accessibility failure) could trigger a formal investigation that holds others liable. Regulatory fragmentation also means that a carrier can argue that through-ticket obligations (e.g., guaranteed rerouting in under 2 hours) are incompatible with its national safety rules.

## Impact

A regulator (e.g., Austria's regulator for ÖBB) issues a preliminary ruling that passenger-rights obligations for through-tickets exceed its domestic safety and operational standards, creating ambiguity that slows carrier buy-in. A passenger incident (e.g., an assisted-travel passenger misses their connection due to a system error and incurs costs) triggers a formal investigation by a national authority, creating reputational damage and forcing a public response from the programme. If regulators diverge on how to interpret through-ticket liability, the backwards-compatibility of the system with national frameworks is questioned, and carriers demand exemptions. Estimated impact: 2–4 month delay in one corridor's rollout if a regulator requires a safety impact assessment or compliance review.

## Likelihood

Low

## Severity

High

## Action

Engage the four priority corridors' national regulators in Month 1–3 (2026-11-08 to 2027-01-08) with a technical briefing on through-ticket design, passenger-rights obligations and safety implications. Commission a cross-border safety and liability impact assessment (Month 2–4 = 2026-12-08 to 2027-02-08) reviewing how through-ticket obligations interact with each regulator's standards, and propose harmonised rules (maximum rerouting time, accessibility obligations) that all regulators agree to in advance. Establish a Standing Regulators Committee (Month 3 = 2027-01-08) chaired by the EU Agency for Railways, meeting monthly to resolve operational and safety questions before they become disputes. Include through-ticket safety and liability rules in the binding standards document (Month 18 = 2028-04-08) so they are legally anchored and not subject to later re-interpretation by individual regulators.

# Risk 17 - Operational & Implementation

Smaller carriers in southern, central and eastern Europe (regional operators in Romania, Bulgaria, Poland) have ageing IT systems, limited staff expertise and lower revenue resilience than incumbent operators. The Pragmatic Foundation proposes regional shared booking hubs to lower their IT barrier, but if hub operators do not effectively support smaller carriers, or if hub outages disproportionately affect them, adoption remains incomplete. These carriers may lack the internal resources to comply with new operational requirements (real-time inventory updates, structured refund processing, accessibility assistance protocols), requiring the programme to provide hands-on capacity building and potentially longer timelines.

## Impact

By Month 24 (2028-10-08), only 50–60% of smaller carriers have completed through-ticket integration, compared to 90%+ for major operators, creating a two-tier network in which through-tickets are reliable only on the major corridors. Regional hubs become bottlenecks, with queues of smaller carriers waiting for hub integration and testing slots. A hub failure affecting 4–6 regional operators leaves a significant portion of the TEN-T network unable to support through-tickets, and rollout extension beyond the four priority corridors slips by 6–12 months (pushing to Month 42–48 = 2030-04-08 to 2030-10-08 instead of Month 36 = 2029-10-08). Smaller carriers, unable to compete on through-tickets, resist ongoing API obligations and push back against access-enforcement audits, creating enforcement challenges.

## Likelihood

Medium

## Severity

Medium

## Action

Establish a dedicated Smaller Carriers Support Programme in Month 1 (2026-11-08) with 5–10 FTE regional coordinators (based in Budapest, Warsaw, Sofia, Bucharest) providing hands-on mentoring. Fund a 'migration grant' of €100,000–500,000 per smaller carrier for IT integration, legacy system upgrades and staff training (Month 6–24 = 2027-04-08 to 2028-10-08). Develop a simplified OSDM-lite interface for carriers with very old systems, reducing integration complexity (but maintaining data parity and access obligations). Schedule regional hubs' technical support team to rotate and spend 1–2 weeks per quarter on-site with smaller carriers to debug integration issues and plan upgrades. Establish a peer-mentoring network pairing larger, more advanced carriers with smaller ones to share integration lessons learned (Month 9–18 = 2027-07-08 to 2028-04-08).

# Risk 18 - Technical & Integration

Real-time inventory and disruption data is critical for booking, refund decisions and accessibility assistance. The Pragmatic Foundation proposes a federated-query or event-streaming architecture. However, implementing a reliable, sub-second-latency data layer across 25+ carriers with heterogeneous IT systems and network infrastructure (especially in less-developed regions like central and southeastern Europe) is technically challenging. If inventory data is stale (>5 minutes old), overbooking and availability errors increase. If disruption events (delays, cancellations, platform changes) are not published in real time, missed-connection detection is late and passenger communication is delayed.

## Impact

A regional carrier's integration with the event-streaming disruption layer has a 2–4 month implementation delay due to network limitations and legacy system incompatibility (Month 12–16 = 2027-10-08 to 2028-02-08 instead of Month 12 = 2027-10-08). Stale inventory data (20–30 minutes old) causes 5–10% of bookings to fail at final confirmation, generating passenger refunds and complaints. A cascade of missed-connection claims arises when disruption data is delayed by 10–15 minutes, too late for rerouting systems to react. Estimated impact: 2–4 month slippage in data-layer rollout, 5–10% booking-failure rate during the first 6 months of operation (Month 18–24 = 2028-04-08 to 2028-10-08), and €5–15 million in unplanned refunds and customer compensation.

## Likelihood

Medium

## Severity

Medium

## Action

Conduct a detailed data-layer architecture workshop in Month 2–3 (2026-12-08 to 2027-01-08) with carrier CIOs and IT teams to assess feasibility of event-streaming vs. federated-query models, identify network and system bottlenecks, and estimate implementation timelines per carrier. Choose a phased approach: launch with a central availability cache for the four priority corridors (higher readiness), deferring event-streaming for disruption data to Month 21–24 (2028-07-08 to 2028-10-08) once infrastructure is proven. Fund a European data-centre network and CDN edge caches to reduce latency (Month 3–6 = 2027-01-08 to 2027-04-08) with redundancy so no single-point failure affects any corridor. Establish data-quality SLAs: inventory freshness <5 minutes, disruption event latency <2 minutes, and require carriers to publish status updates within 5 minutes of any operational change. Test the data layer monthly with synthetic load starting Month 12 (2027-10-08).

# Risk 19 - Operational & Implementation

The programme's success depends on distributors (Trainline, Omio, commercial platforms) actively promoting and selling through-tickets. These platforms earn revenue from booking margins, and if through-fares are commoditized or margins are squeezed by low prices or high processing fees, their incentive to invest in integration and marketing diminishes. They may also resist integration timelines if their own IT backlogs are heavy, or demand preferential access to inventory or pricing in exchange for early buy-in.

## Impact

Trainline or Omio signal in Month 12–15 (2027-10-08 to 2028-01-08) that full API integration will not be complete until Month 24–27 (2028-10-08 to 2029-01-08), after the Month 18 (2028-04-08) standards deadline and risking the Month 30 (2029-04-08) API mandate. They demand preferential inventory access (e.g., advanced notice of discount fares) in exchange for early implementation, which regulators view as discriminatory. If major distributors do not promote through-tickets actively, uptake remains low (15–25% instead of 40%), forcing the public reference distributor to expand and consume more budget. Estimated impact: distributor commitment delays by 4–8 weeks, and the 40% target becomes unachievable without heavy public spending and forced distributor participation.

## Likelihood

Medium

## Severity

Medium

## Action

Engage Trainline, Omio and other commercial distributors in formal working groups (Month 1 = 2026-11-08) to understand their IT priorities, margin sensitivities and promotional incentives. Offer early API access (Month 9–12 = 2027-07-08 to 2027-10-08) to platforms that commit to integration and promotion by Month 18 (2028-04-08). Establish a distributor advisory council (Month 2 = 2026-12-08) that provides input on data formats, settlement timing and consumer features, ensuring their concerns are heard early. Agree on margin-support measures in Month 4–6 (2027-02-08 to 2027-04-08), such as co-marketing funds (€5–10 million) for the first 24 months (through Month 24 = 2028-10-08), conditional on through-ticket volumes and customer satisfaction targets. Reserve slots in the conformance testing schedule for distributors' internal systems and provide free technical support to accelerate their integration.

# Risk 20 - Social & Stakeholder

The programme commits to accessibility for persons with reduced mobility, including booking systems that allow request and confirmation of assistance, real-time accessibility data on stations and rolling stock, and cross-border assistance coordination. However, accessibility is often treated as a compliance checklist rather than a core service, and carriers' existing assistance infrastructure varies widely. If the programme launches with poor accessibility, it signals exclusion and invites complaints from disability-rights organizations (BEUC, national advocacy groups) that can slow deployment and create reputational damage.

## Impact

Accessibility data is incomplete or inaccurate at launch (Month 18 = 2028-04-08), forcing distributors to exclude accessible itineraries from search results, leaving persons with reduced mobility with fewer options than before the programme. Assistance confirmation windows are too long (48 hours instead of 24 hours), making it impossible for passengers to book confidently for last-minute journeys. Cross-border assistance handovers fail (e.g., a passenger arrives at a station after assistance is withdrawn), generating complaints and safety incidents. Disability-rights organizations issue a formal complaint to the Commission, triggering an investigation and negative media coverage. Estimated reputational impact: 10–20% reduction in public support and political pressure for the programme's continuation or expansion.

## Likelihood

Low

## Severity

High

## Action

Establish an Accessibility Working Group in Month 0 (2026-10-08) with representatives from BEUC, national disability-rights organizations, accessibility experts and carriers. Define accessibility requirements in Month 2–4 (2026-12-08 to 2027-02-08) covering booking interfaces, assistance request/confirmation timelines, station and vehicle accessibility data, and cross-border coordination. Include accessibility in the binding standards (Month 18 = 2028-04-08) as a non-negotiable requirement, not optional. Fund a €10–15 million accessibility infrastructure programme (Month 6–24 = 2027-04-08 to 2028-10-08) to support carriers' deployment of assistance request systems and accessibility data publishing. Pilot accessibility features on one corridor (e.g., Wien–München) in Month 12–18 (2027-10-08 to 2028-04-08) with feedback from disability-rights organizations before full rollout. Include accessibility metrics (assisted-journey booking rate, assistance confirmation rate, assistance delivery rate) in the quarterly measurement dashboard.

# Risk summary

This €1.5 billion, five-year EU rail infrastructure programme faces compounded risks spanning regulatory, technical, financial, governance and operational domains. The most critical risks are:

- Regulatory adoption delay: The Commission's proposed Regulation on Digital Booking and Ticketing Services is not yet adopted, and delays beyond Month 6–9 (2027-04-08 to 2027-07-08) threaten the Month 18 (2028-04-08) binding standards milestone and the entire timeline.

- Incumbent carrier resistance and legacy IT migration: The slowest carriers' ageing booking back-ends constrain the critical path, and strategic delay by dominant operators could force gate relaxation or sideline smaller carriers.

- Governance and decision authority deadlock: Establishing binding decision rights without either light-touch institutional lag or heavy legal set-up delays is the fulcrum for all downstream delivery, and sovereignty tensions over cross-border enforcement could paralyse dispute resolution.

The Pragmatic Foundation scenario mitigates these by using accredited payment institutions (avoiding new licensing delays), tiered certification-based access (deferring price regulation until legislation is final), milestone co-funding (incentivizing smaller carriers), and a lightweight arbitration panel (avoiding new legal entities). Secondary risks include uneven regulator capacity, passenger data GDPR exposure, clearing settlement disputes, and unproven modal-shift assumptions. Together, these risks demand early governance clarity, decisive regulation adoption, carrier buy-in strategy and realistic measurement baselines.

# Make Assumptions
# Question 1 – Budget Adequacy and Allocation Trade-Off

## Scope of €1.5 billion Public Budget

The €1.5 billion fixed budget (Month 0–60 = 2026-10-08 to 2031-10-08) covers all public-side coordination, governance, testing infrastructure and consumer-facing operations. Carrier IT integration costs are borne separately by carriers, with the public budget providing co-funding grants estimated at 15–25% of carrier integration cost. Carrier-specific IT adaptation costs (€500 million to €2 billion) are explicitly excluded and borne entirely by private spend.

## Spending Forecast and Risk Threshold

Baseline budget burn: €250–300 million per year. Estimated allocation:

- Standards and conformance testing: €200–300 million
- Clearing and settlement infrastructure: €100–200 million
- Public reference distributor operations: €300–500 million over five years
- Member-state capacity building: €100–150 million
- Consumer rollout and apps: €150–200 million

Total: €850–1,350 million, leaving €150–650 million for carrier co-funding and contingency.

If carrier co-funding demand exceeds €400 million (plausible for 15–20 smaller operators), a 20–30% budget shortfall emerges. Conformance testing and standards work face cuts if carrier co-funding consumes more than 30–40% of the budget.

## Mitigation

Mid-course review triggers at Month 12 (2027-10-08) and Month 24 (2028-10-08) to assess actual spending against forecast and adjust co-funding rates downward if burn-rate exceeds plan. Reserve 10–15% contingency and tie disbursements to verified milestone completion.

---

# Question 2 – Timeline Criticality and Milestone Dependency

## Milestone Status and Legal Binding

Three hard milestones are treated as regulatory targets tied to the adopted Regulation and thus legally binding once Parliament and Council finalize the text (expected Month 6–9 = 2027-04-08 to 2027-07-08):

- Binding standards by Month 18 (2028-04-08)
- Mandatory API exposure by Month 30 (2029-04-08)
- Full corridor through-ticketing by Month 60 (2031-10-08)

Slippage beyond these dates carries legal and reputational consequences (enforcement directives, fines for non-compliant carriers, political damage).

## Definition of 'Mandatory API Exposure'

Every carrier required to participate under the Regulation must have either live OSDM-compatible API access or validated exemption (e.g., hub access for legacy systems). Exemptions must be documented and time-limited. In practice, 90%+ of corridor traffic must be bookable end-to-end by Month 30 (2029-04-08); <90% compliance triggers Commission review and possible enforcement action.

## Critical Path

- Regulation adoption → governance setup (Month 1–3 = 2026-11-08 to 2027-01-08) → standards finalization (Month 4–18 = 2027-02-08 to 2028-04-08) → carrier integration (Month 18–30 = 2028-04-08 to 2029-04-08)

Month 18 (2028-04-08) binding standards deadline requires substantive standards-setting work begin no later than Month 4–5 (2027-02-08 to 2027-03-08), leaving Month 0–3 (2026-10-08 to 2027-01-08) for governance setup, legislative tracking and pre-work. A 3-month delay in regulation adoption compresses standards-setting from 9 months to 6 months, creating quality and consensus risk.

Month 30 (2029-04-08) API mandate is gated by: (1) standards finalization (hard prerequisite), (2) carrier readiness (80–95% achievable by Month 28–30 = 2029-02-08 to 2029-04-08 for major operators, 60–80% for smaller operators via hubs), (3) payment-institution accreditation (must be complete by Month 12–18 = 2027-10-08 to 2028-04-08 to allow 12-month production deployment).

## Mitigation

Establish monthly milestone tracking, trigger early escalation for >2-week slippage, and resource dispute resolution to prevent re-litigation of settled technical issues.

---

# Question 3 – Legacy IT Migration and Hub Dependency

## Hub Eligibility and Coverage

Hub-eligible carriers: (1) annual cross-border revenue <€50 million, or (2) booking-system architecture >10 years old, or (3) IT staff capacity <10 FTE. Estimated 12–18 carriers across 27 member states meet this criterion.

Hub footprint: 4–6 regional hubs covering the four priority corridors (Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin) plus 2–3 additional hubs for TEN-T extensions (central Europe, southeast Europe, Nordic).

## Hub Operator Model and Pricing

Hub operators are initially non-profit, funded by the programme (€20–40 million over five years), with transition to cost-recovery pricing by Month 48 (2030-10-08). Carriers using hubs pay usage fees (€0.10–0.30 per booking, or a fixed annual fee of €50,000–200,000 depending on volume).

## Benefits and Risks

Benefits: Regional hubs reduce the barrier to through-ticket compliance for 12–18 smaller carriers, enabling ~85–95% of cross-border traffic (by volume) to be covered by Month 30 (2029-04-08). Without hubs, only 60–70% of carriers would be ready. Carriers avoid €500,000–2 million native integration costs and accelerate deployment by 6–12 months.

Risks:

- Hub failure affects 4–6 dependent carriers simultaneously, with estimated 12–48 hour recovery time
- Hub operators may become permanent dependencies, increasing long-term costs
- Mapping errors in legacy system translation cause 2–5% booking failures per region
- Hub capacity constraints (10,000+ bookings/day per operator) create latency and search timeout
- Governance ambiguity if a hub operator withdraws mid-deployment

## Mitigation

Hub SLAs must specify 99.9% uptime, <2-second latency, and incident recovery <2 hours. Require hub operators to maintain redundancy (dual data centres). Set sunset clause (hub operation expires Month 48 = 2030-10-08, carriers must migrate to native or new hub by then). Allocate €5–10 million for hub resilience and training. Cost per hub: €5–8 million over five years.

---

# Question 4 – Governance Authority and Cross-Border Enforcement

## Arbitration Panel Structure and Authority

A lightweight arbitration panel (8–12 FTE, based in Brussels) operates with time-boxed decision authority (60 days to ruling) over contested technical and standards disputes. Panel has binding authority on technical disputes (inventory parity thresholds, API latency SLs, settlement message formats) but not commercial terms (subject to negotiation and FRAND compliance).

## Dispute Handling by Level

Operational and commercial disputes (discriminatory API access pricing, passenger refund claims) are handled by national regulators in the first instance, with EU Agency for Railways mediation and escalation to the Commission for cross-border cases.

Member-state regulators commit to enforcing panel rulings consistently; non-compliance is escalated to Commission enforcement action.

## Governance Advantages and Risks

Advantages: avoids 12–18 month joint-undertaking legal setup, preserves existing national regulatory roles, keeps decision speed high.

Risks: (1) if a major incumbent contests a technical ruling, national regulators may not enforce consistently, and the panel lacks direct enforcement power; (2) sovereignty concerns in some member states could limit acceptance of binding rulings; (3) panel credibility depends entirely on Commission backing.

## Mitigation

Secure explicit written delegation from Council (Month 0–2 = 2026-10-08 to 2026-12-08). Establish a Standing Regulators Committee with the panel. Pre-negotiate a carrier Memorandum of Understanding (Month 2–4 = 2026-12-08 to 2027-02-08) in which carriers agree to binding arbitration and accept penalties for non-compliance (0.5–1% of quarterly through-ticket revenue held in escrow for compliance infractions).

Cost: €2–3 million over five years for panel operations.

---

# Question 5 – Modal Shift and Through-Fare Competitiveness

## Through-Fare Pricing and Airline Competition

Through-tickets will be more convenient (single booking, single payment, continuity-of-journey protection) and faster than buying separate operator tickets, but unlikely to undercut airline prices on all corridors without external intervention.

Example: Paris–Brussels–Amsterdam–Köln through-fare estimated at €60–90 (12 hours train), vs. €40–70 airline (4 hours). Without modal-shift incentive, price-sensitive passengers choose flights.

## Modal Shift Targets and Achievability

Pragmatic Foundation accepts that the 40% through-ticket target is achievable only on selected high-demand city pairs (e.g., Paris–Brussels, Amsterdam–Köln) and corridors with weak airline competition. Modal shift estimated at 5–15% reduction in short-haul air trips on priority corridors by Month 60 (2031-10-08), vs. headline ambition of >25% shift.

Baseline modelling of Paris–Brussels–Amsterdam–Köln and Madrid–Barcelona–Lyon corridors (estimated 3–5 million passengers per year) suggests modal shift with no additional levers: 5–10% by Month 60 (2031-10-08). With reduction-card harmonization and environmental messaging: 10–20% shift.

## Fare Strategy and Incentives (No Regulated Ceilings)

The programme does not introduce regulated fare ceilings (to avoid antitrust risk and incumbent resistance) but relies on: (1) reduction-card harmonization (estimated 10–15% effective discount across borders), (2) environmental branding and sustainability messaging, (3) convenience and reliability of through-ticketing attracting premium passengers, and (4) early public distributor campaigns on price-sensitive routes.

Convenience premium (single booking, luggage handling integration, real-time disruption communication) is valued at ~€5–15 per journey.

## Risk and Repositioned Target

Risk: political disappointment if modal shift lags expectations (e.g., 10% actual vs. 25% promised), inviting calls for price regulation or subsidies.

The Pragmatic Foundation scenario repositions the 40% target as '40% of cross-border rail journeys sold as through-tickets (not necessarily 40% modal shift from air),' allowing the programme to succeed on volume metrics even if modal shift falls short.

## Mitigation

Clarify headline targets early (through-ticket share vs. modal shift are separate metrics). Conduct quarterly competitive pricing analysis. Reserve campaign budget (€10–20 million over five years) for targeted air-route competition on high-sensitivity corridors.

---

# Question 6 – GDPR Compliance and Cross-Border Data Governance

## Data Flow and Controller Roles

Through-ticketing requires passenger PII (name, contact, payment card, accessibility attributes) flow among: (1) booking distributor, (2) selling carrier, (3) connecting carrier(s), (4) payment institution (for split payments), and (5) clearing entity (for revenue apportionment and refund reversal). Each actor is a data controller or joint controller under GDPR Article 26.

## Data Protection Assessment and Safeguards

A Data Protection Impact Assessment (DPIA) is commissioned in Month 0–2 (2026-10-08 to 2026-12-08) to identify: (1) minimum necessary PII per transaction, (2) data residency constraints per member state (none formally mandated by EU law, but Poland and Hungary have expressed preferences), and (3) consent regimes (explicit consent for cross-border data sharing may be required).

Safeguards: Standard Contractual Clauses (SCCs) govern cross-border transfers; Binding Corporate Rules (BCRs) for large multi-country operators; deletion protocols (PII deleted 90 days post-journey unless refund or complaint is pending, then 12 months).

## Compliance Costs and Risk Vectors

GDPR compliance costs estimated at €2–5 million upfront (DPIA, legal review, consent-management infrastructure) and €500,000–1 million annually for audits and breach response.

Risk vectors: (1) a national DPA challenges cross-border data flow and imposes local-consent or data-residency requirements; (2) payment institutions refuse to sign on if data-governance is ambiguous; (3) accessibility data (special category under GDPR Article 9) requires heightened consent, creating friction at booking time and reducing assisted-journey uptake.

## Mitigation

Secure early EDPB and national DPA consensus (Month 2–4 = 2026-12-08 to 2027-02-08) on common data-flow model and SCCs. Implement privacy-by-design (data minimization, pseudonymization where feasible). Establish a data-governance officer role within the programme and quarterly data-protection audits. Include GDPR compliance in the conformance checklist.

Cost: €5–10 million over five years.

---

# Question 7 – Stakeholder Involvement and Conflict Resolution

## Tiered Stakeholder Engagement Structure

Stakeholder engagement follows a tiered structure:

- Working Groups (Month 0 = 2026-10-08 onward): technical and standards groups (OSDM, clearing, data-layer design) with carrier, distributor and standards-body participation; Governance and Stakeholder Group; Consumer and Accessibility Group with BEUC and disability-rights representation
- Steering Committee (quarterly, Month 1 = 2026-11-08 onward): senior representatives from DG MOVE, EU Agency for Railways, CER, 2–3 carrier representatives, distributors, regulators
- Escalation Path: disputes escalated from working groups to Steering Committee (within 2 weeks), and if unresolved, to arbitration panel for technical or Commission for institutional disputes

Smaller carriers and distributors are given explicit voice (dedicated SME representative slots) and early funding certainty (co-funding commitments announced in Month 6–9 = 2027-04-08 to 2027-07-08).

## Conflict Resolution Mechanisms

Conflict resolution relies on transparent interest articulation, early negotiation (disputes surfaced in Month 2–6 = 2026-12-08 to 2027-04-08, not left until Month 12+), and fallback to binding arbitration if voluntary consensus fails.

## Risks and Mitigation

Risks: (1) working groups can become talking shops if decisions are re-litigated at Steering Committee level; (2) smaller carriers and distributors can feel unheard if dominated by incumbents; (3) consensus-seeking can delay decisions.

Mitigation: Steering Committee has authority to close technical decisions after working-group consensus, with only major policy reversals escalated. 50% time ring-fenced for SME/distributor concerns, rotating facilitation. Time-boxed working-group decisions with majority voting as fallback.

Estimated governance-overhead time: 15–20% of programme staff effort, or ~€5–10 million over five years.

---

# Question 8 – Operational Systems Architecture and Ownership

## System Ownership and Governance Boundaries

Operational systems governed as follows:

- OSDM API standards and conformance testing: owned by programme via EU Agency for Railways, testing infrastructure procured from independent labs (Month 0–3 = 2026-10-08 to 2027-01-08)
- Real-time data layer (inventory, fares, disruption): federated architecture with carriers holding authoritative data and national access points routing queries, or central European cache (programme-owned) operated by procured neutral-operator entity
- Payment institutions and settlement: competitive market of 2–3 accredited providers selected via public call (Month 2–8 = 2026-12-08 to 2027-06-08), each meeting common SLAs
- Clearing mechanism: programme-owned reference implementation operated by dedicated entity under close programme oversight

Each system has defined SLAs (API latency <2 seconds p95, uptime 99.95%, settlement <48 hours) backed by financial penalties (0.5–1% of quarterly fees withheld for breach).

## Dispute Escalation

Carrier/distributor disputes with a payment institution go to the accredited provider's internal dispute resolution (first), then to the programme's Independent Dispute Panel if unresolved (48–72 hour resolution target).

## Architecture Choices and Risks

Federated vs. central data layer: Federated (carriers keep data, queries route through access points) is resilient but slower; Central cache is fast but creates single-point-of-failure risk. Pragmatic Foundation leans toward federated for launch (Month 18–30 = 2028-04-08 to 2029-04-08) with optional cache layer added later.

Competitive vs. monopoly payment providers: Competitive (2–3 accredited providers) encourages innovation and avoids monopoly risk, but requires harmonized settlement rules and complicates dispute resolution. Pragmatic Foundation requires competitive providers with common SLA framework and Programme-run dispute panel as tiebreaker.

Risks: (1) a payment provider withdraws mid-programme, forcing carrier migration and causing 2–4 week disruption; (2) API latency degrades during holiday peak periods due to traffic surge; (3) data-layer inconsistency causes overbooking and refund disputes.

## Mitigation

Require redundancy (payment providers must have failover partners). Load-test APIs quarterly starting Month 9 (2027-07-08). Establish 24/7 ops centres for critical systems. Mandate incident communication protocols (carrier notified <15 minutes, distributors and passengers <30 minutes).

Cost for operations: €10–15 million over five years.

# Distill Assumptions
# Project Overview

- €1.5 billion public budget fixed over five years; carrier integration costs borne separately by private spend.
- Binding standards required by Month 18 (2028-04-08); mandatory API exposure by Month 30 (2029-04-08); full corridor through-ticketing by Month 60 (2031-10-08).
- Regional shared booking hubs serve 12–18 smaller legacy-IT carriers unable to achieve native OSDM compliance by Month 30 (2029-04-08).
- Lightweight arbitration panel (8–12 FTE) resolves technical disputes in 60 days; national regulators enforce outcomes.
- Through-tickets priced as sum of segment fares; no regulated ceilings; modal shift estimated 5–20%.
- Passenger PII flows across 5–8 data controllers; GDPR compliance via Standard Contractual Clauses and Data Protection Impact Assessment.
- Tiered stakeholder governance: working groups → steering committee → arbitration panel; conflicts escalated within 2 weeks.
- Accredited payment institutions (2–3 providers) run settlement; carriers choose among common SLA-compliant options.
- Federated real-time data layer with carriers holding authoritative inventory; access points route distributor queries.
- Certification-based distributor access: tiered inventory access earned through conformance and consumer-protection testing.
- Milestone-based carrier co-funding prioritizes smaller operators; 15–25% of carrier integration cost covered by public budget.
- 40% through-ticket target is cross-border rail volume share, distinct from modal-shift metric.
- Conformance testing and standards work funded from public budget; carrier-specific IT costs borne by private investment.
- Governance delays >2 weeks trigger escalation; Month 18 (2028-04-08) and Month 30 (2029-04-08) milestones are legally binding per final Regulation.

## Critical Path

- Regulation adoption → governance setup (Months 1–3 = 2026-11-08 to 2027-01-08) → standards (Months 4–18 = 2027-02-08 to 2028-04-08) → carrier integration (Months 18–30 = 2028-04-08 to 2029-04-08).


# Review Assumptions
# Through-Ticketing Programme Risk Review: €1.5 Billion, Five-Year EU Initiative

## Executive Summary

This €1.5 billion, five-year EU through-ticketing programme aims to integrate booking and sales across 27 member states and 25+ carriers by Month 60 (2031-10-08), with binding milestones at Month 18 (2028-04-08) for standards, Month 30 (2029-04-08) for API mandate, and Month 60 (2031-10-08) for full deployment. Three critical, interconnected risks threaten these milestones.

First, the Commission's proposed Regulation on Digital Booking (May 2026) remains unadopted; if adoption slips beyond Month 9 (2027-07-08), the standards-setting window shrinks from 9 months to 3–4 months, eliminating margin for stakeholder consensus and directly jeopardizing the Month 18 (2028-04-08) deadline.

Second, the lightweight arbitration-panel governance model lacks direct enforcement authority over major incumbents. Escalation to the Commission takes 2–4 months; if Deutsche Bahn or SNCF contest a ruling and continue non-compliant practices, the panel has limited leverage, and the coalition fractures.

Third, the €1.5 billion budget is fragile. Core infrastructure (standards, conformance, clearing, public distributor, capacity building, consumer rollout) requires €850–1,350M; carrier co-funding demand for 12–18 smaller operators (€150–300M), hub operations (€5–8M per hub), and unplanned costs (extended distributor operation, data-layer resilience, refund exposure) could trigger 20–30% shortfalls by Month 24 (2028-10-08), forcing cuts to conformance testing or capacity building that delay smaller-carrier adoption and fragment the network.

Secondary risks include unclear modal-shift viability (through-fares may not compete with flights without regulated ceilings, limiting air-to-rail transition to 5–20% instead of implied 25%+), GDPR data-governance challenges, uneven technology infrastructure, and unclear post-Month 60 (2031-10-08) sustainability.

The Pragmatic Foundation scenario mitigates these by deferring price regulation, using competitive accredited payment institutions, enabling regional hubs for smaller carriers, and establishing a time-boxed arbitration panel. This approach is feasible only if: regulation is adopted by Month 9 (2027-07-08); the arbitration panel receives explicit written Council delegation by Month 2 (2026-12-08); budget contingency (10–15%) is protected through Month 24 (2028-10-08); and major carriers sign binding Commitment Letters accepting the Month 30 (2029-04-08) deadline.

## Issue 1 - Regulation Adoption Delay Threatens Critical-Path Milestones

The Commission's proposed Regulation on Digital Booking (May 2026) has not been adopted by Parliament and Council. Parliamentary amendments, member-state negotiations and legal review could extend adoption to Month 6–12 (2027-04-08 to 2027-10-08). If adoption slips beyond Month 9 (2027-07-08), the window for binding standards-setting (Month 18 = 2028-04-08 deadline) shrinks from 9 months to 3–4 months, eliminating margin for stakeholder consultation or dispute resolution. This is the single highest-impact upstream risk.

## Recommendation

- Establish direct liaison with TRAN and IMCO rapporteurs and key member-state transport ministers from Month 0 (2026-10-08), tracking adoption progress weekly.
- Conduct parallel 'shadow standards' pre-work (Month 0–3 = 2026-10-08 to 2027-01-08) on OSDM alignment, access-term sketches and settlement architecture under a 'without-prejudice' frame, enabling rapid finalisation within 2–3 weeks of adoption.
- If adoption slips beyond Month 8 (2027-06-08), trigger contingency: contract external standards-review consortium and accelerate carrier engagement workshops to Month 4–6 (2027-02-08 to 2027-04-08).
- Set hard gate: if regulation is not adopted by Month 10 (2027-08-08), pause carrier onboarding commitments and conduct revised critical-path review.

## Sensitivity

Baseline: regulation adopted Month 6–7 (2027-04-08 to 2027-05-08), allowing 11–12 months for standards-setting. If adoption slips to Month 9 (2027-07-08), standards-setting window is compressed by 2–3 months, increasing quality risk and stakeholder consensus failure. If adoption slips to Month 12 (2027-10-08) or beyond, the Month 18 (2028-04-08) deadline becomes unachievable, forcing either rushed standards (high non-compliance risk) or formal delay. Estimated impact: delay of Month 18–30 (2028-04-08 to 2029-04-08) milestones by 2–6 months, or risk of missed deadline with low-compliance implementation.

---

## Issue 2 - €1.5 Billion Budget Fragility and Carrier Co-Funding Demand Mismatch

The €1.5 billion must cover 7 major programmes: standards (€200–300M), conformance testing (€100–150M), clearing/settlement (€100–200M), public reference distributor operations (€300–500M over 5 years), member-state capacity building (€100–150M), consumer rollout and apps (€150–200M), and carrier co-funding. Early baseline suggests €850–1,350M for core infrastructure, leaving only €150–650M for co-funding. However, 12–18 smaller carriers requiring co-funding to meet Month 30 (2029-04-08) via hubs or gateway integration could demand €150–300M (€5–15M per carrier for IT modernisation or hub fees). A 20–30% budget shortfall (€300–450M) is plausible by Month 24 (2028-10-08), forcing cuts to conformance testing (delaying certification), capacity building (weakening regulator enforcement), or distributor operations (shrinking public channel reach).

## Recommendation

- Commission detailed activity-based cost model in Month 0–2 (2026-10-08 to 2026-12-08) covering: (1) carrier co-funding need per carrier size and legacy-IT status (baseline estimate: €2–8M per SME, €10–15M per medium operator); (2) hub operating cost and capacity per regional hub (baseline: €5–8M per hub over 5 years); (3) public distributor annual operating cost (baseline: €60–100M/year for full retail channel, €20–30M/year for reference-implementation only).
- Establish quarterly budget-tracking dashboards (Month 3 = 2027-01-08 onward) with burn-rate forecasts and trigger points: if quarterly spend >115% of pro-rata budget, initiate cost-reduction review within 1 week.
- Define contingency tiers: (1) Tier 1 (10–15% overrun): defer consumer-app polish, reduce distributor marketing; (2) Tier 2 (15–25% overrun): reduce carrier co-funding rate from 20–25% to 10–15%, prioritise top 5 corridors only; (3) Tier 3 (>25% overrun): suspend new hub openings, scale back capacity building to priority member states.
- Secure commitment from DG MOVE to seek supplementary budget authority by Month 12 (2027-10-08) if Tier 2 triggers.

## Sensitivity

Baseline budget burn: €250–300M/year over 5 years. If carrier co-funding demand exceeds €300M (plausible if hub fees are underestimated or more operators qualify), shortfall is €300–450M by Month 36 (2029-10-08). Impact on ROI and timeline: conformance-testing cuts delay 40% of carrier certifications by 4–8 weeks per carrier, extending Month 30 (2029-04-08) readiness gate by 8–16 weeks for slower operators. Public distributor reductions (e.g., scaling from €80M/year to €50M/year) reduce market-presence investment, lowering through-ticket volumes by estimated 5–10 percentage points. Currency volatility (DKK, SEK, CHF, PLN against EUR) could consume €10–20M annually if not hedged, further reducing effective spending power by 2–3%.

---

## Issue 3 - Lightweight Arbitration Panel Lacks Enforcement Authority Over Incumbents; Governance Deadlock Risk

The Pragmatic Foundation proposes a small arbitration panel (8–12 FTE) with time-boxed (60-day) binding authority over technical disputes, avoiding the 12–18 month legal setup of a dedicated joint undertaking. However, the panel has no direct enforcement power: if Deutsche Bahn or SNCF contests a ruling on inventory-parity thresholds or refund-timing rules, the panel's only escalation is to the Commission, which takes 2–4 months to respond. Without explicit written delegation from the Council (not yet secured), the panel's authority is questioned, and member-state regulators may not enforce consistently. A major dispute unresolved by Month 12–15 (2027-10-08 to 2028-01-08) cascades to standards finalisation disputes and delays the entire Month 18 (2028-04-08) deadline.

## Recommendation

- Secure explicit written delegation of binding technical-decision authority from both the Commission and Council in Month 0–2 (2026-10-08 to 2026-12-08), specifying: (1) scope (technical standards, conformance rules, settlement message formats), (2) authority limits (not commercial terms like pricing), (3) time limits (60-day decision cycle, 14-day compliance deadline, escalation path to Commission if carrier does not comply), (4) standing (panel rulings are binding on all participants unless formally overturned by Commission within 30 days).
- Draft a Memorandum of Understanding (MOU) among DG MOVE, EU Agency for Railways and the panel, with staffing and budget locked in Month 1–2 (2026-11-08 to 2026-12-08).
- Require all participating carriers to sign a binding Commitment Letter (Month 2–3 = 2026-12-08 to 2027-01-08) accepting arbitration and penalties for non-compliance (0.5–1% of quarterly through-ticket revenue held in escrow).
- Establish a Standing Regulators Committee (Month 1 = 2026-11-08) with power to enforce panel rulings consistently; escalate any member state's non-enforcement to the Commission within 2 weeks.
- If a major carrier signals non-compliance in Month 9–12 (2027-07-08 to 2027-10-08), invoke immediate co-funding hold and regulatory escalation.

## Sensitivity

Baseline scenario: panel has clear delegation, carriers sign MOU, disputes resolved within 60 days, no major non-compliance. If delegation is delayed to Month 4–6 (2027-02-08 to 2027-04-08), panel credibility is questioned early, and carriers negotiate weaker access terms. Estimated impact: Month 18 (2028-04-08) standards missed or delivered without incumbents' buy-in, increasing non-compliance risk. If a major incumbent (40–50% of cross-border traffic) contests a panel ruling and escalation to Commission takes 8–12 weeks instead of 4 weeks, the Month 30 (2029-04-08) API mandate is at risk (estimated 2–4 month slip). If enforcement is not consistent across all member states (e.g., Austria enforces a ruling but Germany does not), the through-ticket system is perceived as two-tier, reducing distributor investment and passenger trust.

---

## Issue 4 - Modal-Shift Target Mismatch: 40% Through-Ticket Share Does Not Guarantee Air-to-Rail Competition Gain

The programme's headline targets are: '40% of cross-border journeys sold as through-tickets' and 'modal shift from short-haul air.' These are conflated in political messaging but operationally distinct. The 40% is achievable through volume (capturing passengers already choosing rail), but modal shift requires through-fares to be competitive or more convenient than flights. Modelling of priority corridors suggests through-fares will be €70–90, competing with airline fares of €50–80 on price-competitive days but losing to budget airlines at €30–50. Without regulated fare ceilings (rejected in Pragmatic Foundation to avoid antitrust risk), modal shift is estimated at 5–20%, not the implied 25%+. The programme can hit 40% through-ticket volume by capturing convenience-premium passengers and capturing share from multi-operator rail bookings, but the environmental and capacity-benefit case (implicit in the infrastructure investment) relies on modal shift that may not materialise.

## Recommendation

- Decouple the two targets operationally in Month 1–2 (2026-11-08 to 2026-12-08): define '40% through-ticket share of cross-border rail journeys sold' (volume metric, achievable via sum-of-segment pricing and convenience) separately from 'modal shift: reduce short-haul air trips by 15–25% on priority corridors' (mode-choice metric, dependent on price and fuel prices).
- Conduct detailed competitive pricing analysis in Month 2–4 (2026-12-08 to 2027-02-08) for each priority corridor, modelling through-fare competitiveness against airlines under scenarios of fuel-price change (±30%), aviation-tax policy (current vs. proposed CO2-tax levels), and airline capacity (current vs. 20% capacity increase).
- Use scenarios to set realistic modal-shift targets: if fuel prices rise 30% (baseline: €60/barrel), modal shift to 15–20% is plausible; if fuel is flat, expect 5–10%.
- Communicate this clearly to stakeholders by Month 6 (2027-04-08).
- Reserve €10–20M from the programme budget for targeted air-route competition campaigns (e.g., on Paris–Brussels, Amsterdam–Köln) where air is strongest; position as 'train travel convenience' rather than price-focused.
- If actual modal shift by Month 48 (2030-10-08) is <10%, trigger mid-course review: consider revenue-recovery mechanisms (e.g., reduction-card pooling) or price-support measures (subsidised through-fares on pilot routes) to meet the implicit environmental target.

## Sensitivity

Baseline modelling: through-fare €70–90 vs. airline €50–80, resulting in 5–15% modal shift (conservative). If fuel prices rise to €100/barrel by Month 36 (2029-10-08), airlines raise fares to €70–100, and modal shift rises to 15–25% (aligned with target). If fuel prices fall to €40/barrel, airline fares drop to €35–50, and modal shift remains 2–5%, missing the environmental goal. Estimated ROI impact: if modal shift is 5% instead of 20%, the infrastructure investment per diverted passenger rises 4-fold, reducing cost-benefit ratio and inviting criticism. Through-ticket volume of 40% is still achievable and valuable (capturing rail-to-rail switching), but the mode-shift case—implicit in the €1.5B public investment—may not hold unless fuel prices or aviation taxes rise unexpectedly.

---

## Issue 5 - GDPR and Cross-Border Data-Governance Uncertainty; Risk of Regulatory Intervention Halting Core Systems

Passenger PII (name, contact, payment, accessibility needs) flows across 5–8 entities: distributors, carriers, payment institutions, clearing mechanism, and national regulators for dispute handling. Each is a data controller or joint controller under GDPR Article 26. Data Protection Authorities in some member states (Austria, Poland, Bulgaria) have expressed preferences for data residency and have scrutinised cross-border data flows in other EU programmes. A DPIA (Data Protection Impact Assessment) has not yet been commissioned, and no consensus exists on data-flow minimisation or consent regimes. If a national DPA challenges the data-sharing architecture and issues a directive to restrict cross-border flows (e.g., requiring explicit opt-in consent for each journey), the clearing mechanism and distributor APIs could be held up 6–12 months for redesign. Accessibility data (mobility needs, assistance requests) is classified as special category under GDPR Article 9, requiring heightened consent and potentially creating friction at booking time.

## Recommendation

- Commission a comprehensive DPIA and cross-border data-governance consultation in Month 0–2 (2026-10-08 to 2026-12-08), engaging the European Data Protection Board (EDPB) and national authorities (Austria, Poland, Bulgaria, France, Germany).
- Define minimum-necessary PII per transaction in Month 1 (2026-11-08): baseline (name, contact, booking reference, seat/assistance notes); extended (payment details to accredited payment institutions only, carrier PII for refund/disruption communication only).
- Seek early consensus on Standard Contractual Clauses (SCCs) for cross-border carrier-to-carrier and carrier-to-clearing transfers by Month 4 (2027-02-08).
- Separate accessibility data governance: treat accessibility attributes (mobility, assistance needs) as special category requiring explicit consent, but allow consent at booking time (passive opt-in for future assistance offers, explicit opt-out for data retention >90 days).
- Draft data-governance rules as part of the binding standards document (Month 18 = 2028-04-08), so DPAs review them alongside legal framework, not separately post-facto.
- Allocate €2–3M from the public budget for privacy infrastructure (consent management, data-minimisation tools, breach-response protocols).
- Include GDPR compliance and data-handling practices in the conformance checklist starting Month 18 (2028-04-08).

## Sensitivity

Baseline scenario: EDPB provides early consensus, SCCs are pre-agreed, and GDPR compliance is absorbed into the standards-development process with no additional delays. If a member state (e.g., Poland) issues a unilateral data-residency requirement in Month 9–12 (2027-07-08 to 2027-10-08), data-layer architecture must be redesigned to keep citizen data in local data centres, requiring 3–6 month engineering rework and potentially fragmenting the shared layer. If a DPA investigation into alleged non-compliance is opened in Month 12–18 (2027-10-08 to 2028-04-08), it can delay standards approval and carrier certification until cleared, adding 6–12 months to the critical path. Estimated impact: if data governance is not resolved by Month 6 (2027-04-08), payment-institution accreditation is held up, and Month 30 (2029-04-08) API mandate is at risk by 2–4 months.

---

## Issue 6 - Smaller-Carrier Adoption Cliff and Regional-Hub Dependency: Month 30 (2029-04-08) Readiness Uneven

The Pragmatic Foundation proposes regional shared booking hubs for 12–18 smaller legacy-IT carriers that cannot achieve native OSDM compliance by Month 30 (2029-04-08). However, hub implementation depends on: (1) hub operators being procured and operational by Month 9 (2027-07-08), (2) legacy-system mapping being accurate (avoiding oversold seats, missed restrictions), (3) smaller carriers having internal resources to integrate with hubs (many lack dedicated IT staff). If hub procurement slips to Month 12 (2027-10-08) or later, integration timelines compress to 6–9 months for 12–18 carriers, creating congestion in testing and deployment. If hub mapping errors are detected only during live operation (Month 18–24 = 2028-04-08 to 2028-10-08), recovery takes 4–8 weeks per carrier, and some operators slip past the Month 30 (2029-04-08) mandate. Result: a two-tier network in which through-tickets are reliable on major corridors (90%+ carrier readiness) but fragile on smaller routes (60–70% readiness), undermining passenger confidence and creating liability disputes.

## Recommendation

- Accelerate hub-operator procurement to Month 1–3 (2026-11-08 to 2027-01-08), and secure legal commitments (Statements of Work) with hub operators by Month 4 (2027-02-08), specifying: (1) operational start date (Month 6–9 = 2027-04-08 to 2027-07-08), (2) SLAs (99.9% uptime, <2-second latency, <2-hour incident recovery), (3) capacity (minimum 10,000 bookings/day per operator without degradation), (4) redundancy (dual data centres, failover protocols).
- Define hub-eligible carriers early (Month 1 = 2026-11-08) using clear criteria: annual cross-border revenue <€50M, booking-system age >10 years, or IT staff <10 FTE.
- Conduct joint technical workshops (Month 2–4 = 2026-12-08 to 2027-02-08) pairing hub operators and eligible carriers to identify integration blockers (network latency, API compatibility, data format mismatch) early.
- Allocate €5–10M for hub resilience and capacity upgrades (Month 6–18 = 2027-04-08 to 2028-04-08).
- Establish a Smaller-Carriers Support Team (3–5 FTE regional coordinators) based in hub regions (Budapest, Warsaw, Sofia, Bucharest) providing on-site mentoring and troubleshooting during integration (Month 6–30 = 2027-04-08 to 2029-04-08).
- Schedule mandatory pilot tests (Month 15–18 = 2028-01-08 to 2028-04-08) of each hub's integration with 2–3 eligible carriers before the conformance-testing phase.
- If a hub is not ready by Month 9 (2027-07-08), escalate to the Steering Committee and consider alternative integration paths (gateway use, bilateral pairings with larger operators) for affected carriers.

## Sensitivity

Baseline: hub operators procured by Month 3 (2027-01-08), integration begins Month 6, 85–90% of smaller carriers ready by Month 30 (2029-04-08). If hub procurement slips to Month 6 (2027-04-08), integration window is reduced to 9 months for 12–18 carriers, and readiness at Month 30 (2029-04-08) drops to 70–80% (20–30% slip past deadline). If hub mapping errors cause 2–5% booking-failure rate post-launch (Month 18–24 = 2028-04-08 to 2028-10-08), recovery takes 4–8 weeks per carrier and adds 8–16 week delay for affected corridors. Estimated impact: each month of hub-procurement delay reduces smaller-carrier readiness by 3–5 percentage points; if <75% of smaller carriers are ready by Month 30 (2029-04-08), the TEN-T extension beyond priority corridors slips by 6–12 months (to Month 36–42 = 2029-10-08 to 2030-04-08).

---

## Issue 7 - Accredited Payment-Institution Accreditation Timeline Risk; Settlement Mechanism Delayed

The Pragmatic Foundation proposes competitive accredited payment institutions (2–3 providers) running split-payment and refund orchestration, avoiding the licensing and setup delays of a central clearing entity. However, accreditation is phased: (1) market sounding (Month 0–1 = 2026-10-08 to 2026-11-08), (2) criteria definition (Month 1–3 = 2026-11-08 to 2027-01-08), (3) application call (Month 2–6 = 2026-12-08 to 2027-04-08), (4) decision (Month 8 = 2027-06-08). If only 1–2 providers apply (plausible if transaction volumes are low or compliance costs are high), there is little competitive choice. If a provider withdraws or fails after accreditation, switching to a replacement during Month 18–30 (2028-04-08 to 2029-04-08) creates 2–4 week disruption and requires carrier re-integration. Additionally, settlement transaction fees (estimated 0.5–2% per transaction, or €80–120M over five years) consume 5–8% of the fixed €1.5B budget, forcing cuts elsewhere.

## Recommendation

- Launch market sounding in Month 0–1 (2026-10-08 to 2026-11-08) with published accreditation criteria specifying: multi-currency support (EUR, DKK, SEK, CHF, PLN, CZK, HUF, BGN, RON), settlement cycle (<48 hours), refund processing (<10 days), error handling (dispute resolution <5 days), SLAs (99.95% uptime), and financial stability (must be licensed payment institution under PSD2).
- Issue the call for applications by Month 2 (2026-12-08) with a target decision by Month 8 (2027-06-08).
- Require at least 2 accredited providers to be operational by Month 12 (2027-10-08), with contractual provisions for redundancy: if one provider fails, carriers automatically failover to a backup, with the programme funding the transition cost (up to €1M per incident).
- Negotiate transaction-fee caps during accreditation (target: 0.3–0.5% per transaction, not >0.7%).
- Establish a fee-subsidy model: programme covers 50–70% of payment-institution fees in Years 1–2 (Month 0–24 = 2026-10-08 to 2028-10-08), with carriers and distributors bearing the remainder, conditional on through-ticket volumes reaching 15% by Month 24 (2028-10-08).
- Reserve €1–2M for contingency provider-switching costs.
- If fewer than 2 qualified providers apply by Month 6 (2027-04-08), escalate to DG MOVE and consider fallback options: temporary settlement via existing carrier-to-carrier bilateral arrangements (slower, but known), or emergency procurement of a custom settlement service.

## Sensitivity

Baseline: 2–3 providers accredited, fees capped at 0.5% of transaction value, settlement operational by Month 12 (2027-10-08). If only 1 provider qualifies, the programme has no backup if that provider fails or withdraws; estimated switching cost €5–10M if replacement is needed in Month 18–30 (2028-04-08 to 2029-04-08). If accreditation takes until Month 12–15 (2027-10-08 to 2028-01-08) instead of Month 8 (2027-06-08), settlement infrastructure deployment is compressed from 12 months to 6–9 months, reducing testing and integration quality. If transaction fees average 1.0% (not the 0.5% target), the five-year cost is €160–240M, consuming 10–16% of the public budget and forcing cuts to conformance testing or distributor operations (estimated 10–20% reduction in testing capacity or distributor market reach).

---

## Issue 8 - Unresolved Definition of 'Through-Ticket' and '40% Target': Measurement Baseline Delay Threatens Mid-Course Correction

The programme targets '40% of cross-border journeys sold as through-tickets' by Month 60 (2031-10-08), but no consensus definition of 'through-ticket' exists. Is it: (1) a single booking reference and payment? (2) guaranteed continuity-of-journey rights? (3) sale through a distributor platform (vs. direct operator sale)? Carriers and distributors propose different definitions to optimise their interests. Additionally, baseline data on current cross-border rail sales, complaint volumes and modal split do not exist in consolidated form; carriers report proprietary metrics, distributors guard booking data, aviation data come from EUROSTAT (1-month lag). If the baseline is not established until Month 9–12 (2027-07-08 to 2027-10-08), mid-course correction insights are delayed until Year 2 (Month 12–18 = 2027-10-08 to 2028-04-08), and stakeholder disputes over whether targets are being met undermine programme credibility. An estimated 15–25% undercount of true through-ticket share is plausible if carriers refuse to report volumes or if definitions vary by country.

## Recommendation

- Define 'through-ticket' operationally in Month 1–2 (2026-11-08 to 2026-12-08) with stakeholder consensus: 'single booking reference, single point of payment, continuity-of-journey protection (rerouting/refund if connection missed), sold through any distributor or operator platform.'
- Publish this definition in the binding standards document (Month 18 = 2028-04-08) so it is legally anchored.
- Commission a baseline survey in Month 0–2 (2026-10-08 to 2026-12-08) asking carriers, distributors and airports for current cross-border sales volumes, complaint-handling metrics and modal-split estimates, with strict confidentiality protections (aggregated reporting, no carrier-level disclosure).
- Mandate that all participating carriers and accredited distributors report through-ticket volumes monthly starting Month 18 (2028-04-08), with data aggregated and published quarterly with a 1-month lag (to protect commercial sensitivity).
- Hire an independent evaluation firm in Month 3 (2027-01-08) to build a counterfactual model comparing through-ticket adoption on priority corridors to control routes outside the rollout, separating programme effects from fuel prices and aviation-capacity changes.
- Establish a Measurement Steering Group (quarterly, Month 3 = 2027-01-08 onward) to oversee baseline validation, definition refinement and quarterly progress dashboards.
- Reserve €5–10M of the public budget for measurement and evaluation.

## Sensitivity

Baseline scenario: 'through-ticket' defined by Month 2 (2026-12-08), baseline established by Month 9 (2027-07-08), monthly reporting begins Month 18 (2028-04-08). If definition is delayed to Month 4–6 (2027-02-08 to 2027-04-08), stakeholder disputes consume resources and push baseline survey to Month 6–9 (2027-04-08 to 2027-07-08), delaying insights to Month 12–15 (2027-10-08 to 2028-01-08). If carriers refuse to report volumes (claiming commercial sensitivity), the programme relies on distributor data only, undercounting true market share by 15–25% and making it impossible to verify whether 40% target is being met. Estimated impact: if mid-course correction is delayed 6 months due to measurement uncertainty, and the target is actually 30% (not 40%), the programme does not detect this until Month 18–24 (2028-04-08 to 2028-10-08), leaving only 6–12 months to adjust strategy (add co-funding, accelerate distributor campaigns, introduce fare-support measures) before it is too late to course-correct.

---

## Issue 9 - Distributor Incentive and Involvement Uncertainty: Trainline and Omio Buy-In Not Secured

The programme's success depends on distributors (Trainline, Omio, commercial platforms) actively promoting and selling through-tickets. However, their involvement is assumed but not contractually secured. If distributor margins are compressed by low through-fares or high processing fees, their incentive to invest in integration and marketing diminishes. Trainline and Omio may also resist integration timelines if their own IT backlogs are heavy, or demand preferential inventory access (which regulators view as discriminatory). If either major distributor signals non-compliance (e.g., 'full API integration will not be ready until Month 24–27 = 2028-10-08 to 2029-01-08 instead of Month 18 = 2028-04-08') in Month 12–15 (2027-10-08 to 2028-01-08), other distributors may follow, and the programme is forced to expand the public reference distributor to fill the gap, consuming extra budget and crowding out commercial platforms.

## Recommendation

- Establish formal Distributor Advisory Working Groups in Month 1 (2026-11-08) with Trainline, Omio, smaller platforms and commercial aggregators.
- Conduct detailed margin and IT-capacity analysis in Month 2–4 (2026-12-08 to 2027-02-08) to understand their integration costs, margin requirements and timeline constraints.
- Offer early API access (Month 9–12 = 2027-07-08 to 2027-10-08) and data-access priority to platforms that commit to full integration and promotion by Month 18 (2028-04-08).
- Agree on margin-support measures in Month 4–6 (2027-02-08 to 2027-04-08): co-marketing funds (€5–10M over 24 months), performance bonuses for through-ticket volumes, and transaction-fee waivers (programme covers payment-institution fees for first 12–18 months).
- Establish a Distributor Commitment Letter (Month 3–4 = 2027-01-08 to 2027-02-08) specifying integration timeline, promotion commitment and penalties for non-compliance (e.g., loss of early API access, withholding of co-marketing funds).
- Reserve time-slots in the conformance-testing schedule for distributors' internal systems (Month 12–18 = 2027-10-08 to 2028-04-08), with free technical support to accelerate integration.
- Monitor distributor progress quarterly (Month 3 = 2027-01-08 onward) and escalate any major slippage to the Steering Committee within 2 weeks.

## Sensitivity

Baseline: Trainline and Omio commit to integration by Month 12–15 (2027-10-08 to 2028-01-08), both platforms live by Month 18 (2028-04-08). If distributor commitment is delayed to Month 6–9 (2027-04-08 to 2027-07-08), and either Trainline or Omio signals non-compliance, the programme must increase public-distributor operations by 20–30%, adding €60–90M to operating costs and consuming 4–6% of the public budget. If through-ticket volumes on distributor platforms are <50% of the total (due to poor integration or insufficient promotion), the 40% target becomes achievable only through the public channel and operator direct sales, which are less scalable and create sustainability risk (public distributor must operate for 5+ years, not 3 as planned).

---

## Issue 10 - Member-State Regulator Capacity Gaps and Enforcement Inconsistency; Cross-Border Dispute Resolution Unproven

National regulators across 27 member states vary widely in resources, enforcement powers and interpretation of passenger rights. Some (France, Germany, Netherlands, Austria) have strong rail regulators; others (especially in southeast Europe and smaller member states) have limited staff and expertise. If enforcement of non-discrimination duties and passenger-rights claims is inconsistent across borders, the through-ticket system is perceived as unreliable and passengers lose confidence. Additionally, cross-border disputes (e.g., a distributor complains that a carrier in another member state is denying API access) have no clear resolution path under the Pragmatic Foundation; escalation to the EU Agency for Railways is slow (4–8 weeks), and national regulators may not recognise arbitration panel rulings without explicit legal backing.

## Recommendation

- Establish a Member-State Regulator Capacity Building Programme in Month 0–2 (2026-10-08 to 2026-12-08), funded with €10–15M over five years.
- Conduct a capacity audit (Month 1–2 = 2026-11-08 to 2026-12-08) identifying regulator gaps (staff, budget, IT systems, enforcement experience).
- Fund twinning partnerships (Month 3–6 = 2027-01-08 to 2027-04-08) pairing stronger and weaker regulators, with shared training (access-enforcement, data-quality auditing, complaint handling), common inspection checklists and experience exchange.
- Establish a Standing Regulators Committee (Month 1 = 2026-11-08) meeting monthly, chaired by the EU Agency for Railways, to harmonise enforcement procedures and resolve cross-border disputes.
- Define a lead-authority rule for cross-border cases (Month 2–4 = 2026-12-08 to 2027-02-08): if a distributor complains that a carrier in Austria is denying API access, the Austrian regulator takes the lead, with support from the EU Agency for Railways and other affected-member-state regulators.
- Agree that lead-authority decisions are recognised across all member states (no re-litigation).
- Include enforcement capacity and cross-border-dispute procedures in the binding standards (Month 18 = 2028-04-08).
- Schedule regulator capacity reviews quarterly (starting Month 6 = 2027-04-08) to assess progress and identify ongoing gaps; if a regulator is not meeting standards (e.g., >60-day case resolution time), escalate to the Commission for targeted support or enforcement authority adjustment.

## Sensitivity

Baseline: regulators are trained by Month 12 (2027-10-08), enforcement procedures harmonised by Month 18 (2028-04-08), cross-border disputes resolved within 30 days. If regulator capacity building is delayed to Month 6–9 (2027-04-08 to 2027-07-08) or underfunded, enforcement remains patchy; disputes in weak-capacity member states (Poland, Bulgaria, Romania) take 60–120 days to resolve (vs. 30-day target), delaying carrier compliance and distributor onboarding. If one regulator refuses to recognise arbitration panel rulings (e.g., asserting national sovereignty), the cross-border dispute-resolution system breaks down, and carriers in that member state can maintain discriminatory practices without consequence. Estimated impact: 10–20% of disputes unresolved within SLA, driving distributor complaints and reputation damage; smaller carriers in weak-capacity regions slip past Month 30 (2029-04-08) mandate, fragmenting the network.

---

## Issue 11 - Passenger-Rights Backstop Funding and Liability Exposure Under-Estimated; Refund Disputes Could Consume Contingency

The programme promises continuity-of-journey rights: if a passenger misses a connection on a multi-carrier through-ticket, they are rerouted or refunded. However, the cost of rerouting (care, alternative transport, hotel) and the liability for false promises (e.g., a distributor sells a risky itinerary with tight connections, and the connection fails) are not fully budgeted. The Pragmatic Foundation proposes that distributors bear first-line liability and recover costs from carriers via the clearing mechanism, but if disputes are frequent (e.g., 10–15% of through-tickets result in claims), refund processing becomes a bottleneck, and the programme's credibility is undermined. Additionally, if accessibility assistance is promised but not delivered (e.g., a station lifts are out of order on boarding day), the programme faces both liability and reputational damage.

## Recommendation

- Establish a Passenger-Rights Backstop and Liability Framework in Month 2–4 (2026-12-08 to 2027-02-08), specifying: (1) who is the single point of contact for rerouting/refunds (distributor or first carrier), (2) required response time (rerouting decision <4 hours, refund <10 days), (3) financial responsibility (distributor advances cost, then recovers from responsible carrier via clearing), (4) pooled guarantee mechanism (if a carrier is insolvent, a pooled fund covers passenger refunds).
- Conduct an actuarial study (Month 3–6 = 2027-01-08 to 2027-04-08) estimating refund volumes and costs: baseline assumption is 3–5% of through-tickets result in claims (conservative estimate based on existing multi-carrier journeys); average claim cost is €50–200 (rerouting, care, refund). This suggests €10–40M in refund costs over five years, or €2–8M annually.
- Reserve €5–10M in contingency for higher-than-expected refund volumes.
- Establish a Dispute Resolution Panel (Month 6 = 2027-04-08) with rotating carrier and distributor representatives, empowered to rule on contested claims within 5 days.
- Pilot the refund process on one corridor (e.g., Paris–Brussels–Amsterdam) in Month 12–18 (2027-10-08 to 2028-04-08) to test procedures and refine timelines.
- Include refund-processing metrics (claim response time, resolution time, dispute rate) in the quarterly measurement dashboard starting Month 18 (2028-04-08).
- If actual claim rates exceed 8% by Month 24 (2028-10-08), or average resolution time >15 days, escalate to Steering Committee and consider capacity-building for dispute handlers or procedural simplification.

## Sensitivity

Baseline: 3–5% claim rate, €50–150 average cost, €5–15M total five-year cost. If claim rate is 8–10% (e.g., due to tight connections or aggressive through-fare marketing), five-year costs rise to €20–40M, consuming 1–3% of the public budget and crowding out other spending (e.g., capacity building). If average claim resolution time is 20–30 days (not the 10-day target), passengers complain and distributor confidence erodes, reducing through-ticket sales by 5–10 percentage points. If a major carrier (accounting for 30–40% of through-tickets) contests a high volume of claims (e.g., 15–20% vs. expected 3–5%), the clearing entity is forced to arbitrate hundreds of monthly disputes, creating a processing backlog and refund delays. Estimated impact: uncontrolled refund exposure could consume 5–8% of the public budget and delay through-ticket expansion; poor claim resolution damages programme credibility and lowers adoption by 10–20%.

---

## Issue 12 - Technology Infrastructure Scalability and Performance Risk: API Latency and Data-Layer Reliability Under Peak Load

The shared real-time data layer and OSDM APIs must handle peak-hour search traffic estimated at 100–500 requests per second per corridor during holiday periods. Legacy carriers' infrastructure is not designed for this scale; a carrier with 20-year-old booking systems may struggle to support >10 req/s without degradation. If API latency exceeds 5 seconds during peak hours (Month 18–24 = 2028-04-08 to 2028-10-08), searches timeout, distributors report poor user experience and pull back investment. A hub or cache serving a corridor fails and takes 12–48 hours to recover, stranding all through-ticket bookings on that route and generating cascading refund obligations. Data-quality issues (stale inventory, 20–30 minutes old) cause 5–10% of bookings to fail at confirmation, creating disputes and refund costs.

## Recommendation

- Conduct carrier infrastructure assessment in Month 3–4 (2027-01-08 to 2027-02-08) to identify systems that cannot meet the required API performance SLAs (latency <2 seconds p95, throughput ≥500 req/s, uptime 99.95%).
- For carriers that fail, co-fund infrastructure upgrades (€500K–2M per carrier) in Month 6–18 (2027-04-08 to 2028-04-08).
- Procure a European-wide API hosting and caching infrastructure in Month 2–6 (2026-12-08 to 2027-04-08) with guaranteed SLAs, redundancy across ≥3 data centres per region (EU-West, EU-Central, EU-East), and automatic failover (target <30 seconds).
- Establish 24/7 API operations centre in Month 6 (2027-04-08) with escalation to carriers within 15 minutes of any incident.
- Define data-quality SLAs: inventory freshness <5 minutes, disruption-event latency <2 minutes.
- Conduct monthly load testing and quarterly chaos-engineering exercises (starting Month 9 = 2027-07-08) to identify weak points before they affect production.
- Budget €10–15M for infrastructure procuracy, operations and testing over five years.
- If a carrier cannot meet performance SLAs by Month 24 (2028-10-08), delay its integration to Month 30 (2029-04-08) and route its traffic through a hub or federated access point (accepting slightly higher latency).

## Sensitivity

Baseline: API infrastructure procured by Month 6 (2027-04-08), load testing validates performance by Month 12 (2027-10-08), production launch Month 18 (2028-04-08) with target <2-second latency. If infrastructure procurement slips to Month 9–12 (2027-07-08 to 2027-10-08), production deployment is delayed from Month 18 (2028-04-08) to Month 21–24 (2028-07-08 to 2028-10-08), compressing the Month 30 (2029-04-08) integration window for slower carriers. If 20% of carriers' back-ends require co-funded upgrades and the budget is insufficient (e.g., only 10 carriers can be funded due to cost limits), the slower carriers slip past the Month 30 (2029-04-08) mandate, reducing through-ticket coverage from 90% to 70–75% of cross-border traffic. If API latency is 3–5 seconds instead of 2 seconds (due to network constraints or hub congestion), distributor-side search timeouts increase from <1% to 5–10%, reducing user satisfaction and lowering through-ticket volumes by 10–20%.

---

## Issue 13 - Accessibility Integration Complexity and Assistance-Delivery Risk; Exclusion of Vulnerable Populations

The programme commits to accessibility for persons with reduced mobility, including booking-system requests for assistance, cross-border assistance coordination, and real-time accessibility data on stations and rolling stock. However, accessibility is often under-resourced: carriers' existing assistance infrastructure varies widely (good in western Europe, limited in southeast Europe). If the programme launches with incomplete accessibility data or slow assistance-confirmation windows (e.g., 48 hours instead of 24 hours), persons with reduced mobility face barriers that non-disabled passengers do not, creating exclusion and inviting complaints from BEUC and national disability-rights organizations. Cross-border assistance handovers are particularly risky: if a passenger's confirmed assistance (e.g., platform lift) is not available on boarding day due to equipment failure, the passenger is stranded and the programme is liable.

## Recommendation

- Establish an Accessibility Working Group in Month 0 (2026-10-08) with BEUC, national disability-rights organizations, carriers and accessibility experts.
- Define accessibility requirements in Month 2–4 (2026-12-08 to 2027-02-08): booking-interface accessibility (WCAG 2.1 AA standard), assistance-request/confirmation timelines (<24 hours for confirmation, <48 hours for rerouting), station and vehicle accessibility data (lift, accessible toilet, accessible seating availability, staff assistance capability).
- Include accessibility as a binding non-negotiable requirement in the standards (Month 18 = 2028-04-08), not optional.
- Fund a €10–15M Accessibility Infrastructure Programme (Month 6–24 = 2027-04-08 to 2028-10-08) supporting carriers' deployment of assistance-request systems and accessibility-data APIs.
- Pilot accessibility features on one corridor (e.g., Wien–München) in Month 12–18 (2027-10-08 to 2028-04-08) with real passengers and feedback from disability-rights organizations.
- Establish accessibility-specific SLAs: assistance-confirmation rate >90%, assistance-delivery rate >95%, assistance-related complaint rate <2%.
- Include accessibility metrics in the quarterly measurement dashboard.
- If a carrier cannot meet accessibility SLAs by Month 24 (2028-10-08), conditional funding is withheld until compliance is demonstrated.

## Sensitivity

Baseline: accessibility requirements defined by Month 4 (2027-02-08), pilot corridor operational by Month 18 (2028-04-08), 90%+ of carriers meet accessibility SLAs by Month 30 (2029-04-08). If accessibility requirements are delayed to Month 6–9 (2027-04-08 to 2027-07-08) or weakened (e.g., assistance confirmation window extended to 48 hours), uptake among persons with reduced mobility lags other passenger groups by 15–25 percentage points. If cross-border assistance handovers fail at a rate >5% (e.g., a passenger arrives at a connecting station and assistance is not available), incidents escalate to disability-rights organizations and media, damaging the programme's reputation. Estimated impact: if accessibility is poorly integrated, the programme excludes 5–10% of potential passengers (persons with mobility limitations) and invites regulatory intervention by national disability-rights authorities.

---

## Issue 14 - Incumbent Carrier Non-Compliance Risk: Month 18 (2028-04-08) Standards Deadline Under Threat if Major Carriers Demand Exemptions or Extensions

The programme's credibility depends on binding standards and mandatory API exposure deadlines (Month 18 = 2028-04-08, Month 30 = 2029-04-08). However, large incumbents (Deutsche Bahn, SNCF, Trenitalia, ÖBB, Renfe) have significant political leverage: if one signals non-compliance or demands extensions, others follow, and the Commission is forced to negotiate weaker terms or grant exemptions. Political pressure from member states (especially Germany and France) could soften enforcement. If SNCF announces in Month 12–15 (2027-10-08 to 2028-01-08) that API integration will not be ready until Month 36 (2029-10-08) due to legacy system incompatibility, the entire timeline becomes discretionary, and carriers see no consequences for slippage.

## Recommendation

- Establish formal carrier engagement and negotiation stream in Month 1 (2026-11-08) with quarterly roundtables between DG MOVE, CER and the 8 largest carriers (Deutsche Bahn, SNCF, Trenitalia, Renfe, ÖBB, NS, SJ, SNCB).
- Use these forums to: (1) understand IT cost-sharing opportunities (e.g., hub use for phased integration, gateway sharing for legacy systems), (2) air concerns early before they harden into political positions, (3) offer co-funding and timeline flexibility (e.g., carrier A gets extra 6 months if it demonstrates genuine technical blocker, but loses co-funding premium).
- Build political cover by securing visible member-state support (Belgium, Netherlands, Austria, Spain) early and regularly reporting programme progress to European Parliament's TRAN committee.
- Establish a 'Major Carrier Commitment Protocol' (Month 2–3 = 2026-12-08 to 2027-01-08) requiring all carriers >€100M annual cross-border revenue to sign a binding letter specifying compliance timeline, API readiness date (no later than Month 30 = 2029-04-08), and acceptance of arbitration outcomes.
- If a major carrier signals non-compliance in Month 9–12 (2027-07-08 to 2027-10-08), escalate immediately to Commission with evidence (missed milestones, insufficient investment) and invoke contingency: hold co-funding, public channel bypasses (public distributor offers competing service), or regulatory escalation (Commission mandates compliance and threatens fines).
- Communicate non-compliance risk to stakeholders transparently so distributor and passenger expectations are managed.

## Sensitivity

Baseline: major carriers commit to Month 30 (2029-04-08) compliance in Month 1–3 (2026-11-08 to 2027-01-08), no major signalling of non-compliance by Month 18 (2028-04-08). If SNCF or Deutsche Bahn signals non-compliance in Month 9–12 (2027-07-08 to 2027-10-08), and Commission negotiates an extension (e.g., to Month 36 = 2029-10-08), other carriers follow, and the mandatory deadline becomes advisory, reducing compliance rate from 90%+ to 70–80%. If political pressure forces the Commission to grant exemptions (e.g., SNCF exempt from API mandate on domestic routes), the through-ticket system is fragmented and unreliable, and the 40% target becomes unachievable. Estimated impact: if non-compliance by 1–2 major carriers is not addressed firmly, the entire Month 30 (2029-04-08) mandate is undermined, and the programme's credibility is damaged for years.

---

## Issue 15 - Consumer-Facing Rollout Delay: App Launch and Support Capacity Underfunded

The programme's consumer-side rollout includes a multilingual booking app, customer support in 24+ languages, and complaint handling across member-state jurisdictions. Launching a consumer product at EU scale within Months 15–27 (2028-01-08 to 2029-01-08) is ambitious: design iteration, user testing, platform scaling and localization typically take 12–18 months for a new product. If the app is released 3–6 months late (Month 21–24 = 2028-07-08 to 2028-10-08 instead of Month 15 = 2028-01-08), momentum from early corridor launches is lost. If the app is poorly designed, slow or untrustworthy (e.g., confusing refund flow, missing accessibility features), user ratings are low (3.5/5 stars), and distributor confidence is shaken. Support capacity is often under-estimated: if support queue times exceed 2 hours and a backlog of 1,000+ unresolved complaints accumulates within 3 months of launch, reputational damage is significant.

## Recommendation

- Establish a dedicated Consumer Product Team in Month 1 (2026-11-08) with 20–30 FTE (product managers, engineers, UX designers, localization specialists, support staff).
- Conduct user research and personas in Month 2–4 (2026-12-08 to 2027-02-08), then wireframe and prototype in Month 4–6 (2027-02-08 to 2027-04-08).
- Build a minimum viable product (MVP) for pilot testing on one corridor by Month 9 (2027-07-08).
- Iterate based on user feedback during Month 10–12 (2027-08-08 to 2027-10-08), then begin full-scale localization and platform scaling in Month 12–15 (2027-10-08 to 2028-01-08).
- Target public app launch by Month 15 (2028-01-08) with phased rollout (four priority corridors first, then TEN-T).
- Budget €20–30M for app development, infrastructure and support over Months 15–27 (2028-01-08 to 2029-01-08).
- Establish a support team with sub-1-hour response-time target for critical issues, tiered escalation (level-1 FAQs, level-2 human support, level-3 dispute resolution).
- Conduct app-store and third-party reviews throughout the pilot and post-launch periods (Month 9 = 2027-07-08 onward) to catch usability issues early.
- If user satisfaction is <4.0/5 stars at Month 18 (2028-04-08), pause rollout and conduct a 4–6 week redesign cycle before resuming.

## Sensitivity

Baseline: app launched Month 15, 1 (2028-01-08, 2026-11-08)-hour support response time, user satisfaction >4.2/5 stars. If app launch slips to Month 18–21 (2028-04-08 to 2028-07-08), early-corridor momentum is lost and through-ticket volumes drop by 10–15 percentage points (passengers use manual, multi-step booking instead). If user satisfaction is <4.0/5 stars and is publicised (app-store reviews, media coverage), distributor confidence is shaken and commercial platforms reduce co-marketing investment by 20–30%. If support queue times exceed 4 hours and complaints backlog reaches 2,000+ by Month 21 (2028-07-08), resolving the backlog takes 4–8 weeks and generates negative media coverage. Estimated impact: consumer-product delays or poor quality reduce through-ticket volumes by 10–20 percentage points and require budget surge for reputation repair (€5–10M in crisis messaging and support surge).

---

## Issue 16 - Unclear Private-Sector Financial Commitment: Carrier IT Investment Estimates (€500M–€2B) Not Binding; Funding Gaps Possible

The programme assumes that carrier IT integration costs (€500M–€2B private spend, estimated separately from the €1.5B public budget) are borne entirely by carriers. However, no binding commitments exist: carriers can delay or under-invest if they perceive weak enforcement of the mandatory API deadline or if co-funding is insufficient to offset their costs. Smaller carriers, especially in southeast Europe and with weak financial positions, may claim they cannot afford integration and lobby for further public funding or exemptions. If actual private spend is 30–50% lower than estimated (e.g., €350M–€1B instead of €500M–€2B), integration is incomplete by Month 30 (2029-04-08), and through-ticket coverage is fragmented.

## Recommendation

- Commission a detailed activity-based cost analysis in Month 0–2 (2026-10-08 to 2026-12-08) estimating carrier IT integration costs by carrier size, legacy-system age and roadmap (native build vs. hub use).
- Present findings to CER and major carriers in Month 3 (2027-01-08) and seek binding commitments (Signed Letters of Intent) specifying: (1) estimated integration cost per carrier, (2) expected timeline (Month 18–30 = 2028-04-08 to 2029-04-08 for major carriers, Month 30–36 = 2029-04-08 to 2029-10-08 for smaller operators), (3) technology choices (native API vs. hub vs. gateway).
- Use these commitments to benchmark actual private spend against forecast; if carriers are under-investing (actual spend <70% of commitment), escalate to CER and DG MOVE and trigger enforcement levers (mandatory audits, co-funding holds).
- Establish a quarterly Carrier Investment Tracking Dashboard (starting Month 6 = 2027-04-08) reporting estimated cumulative private spend vs. forecast, flagging any carrier that is 20%+ behind schedule.
- If total private spend by Month 24 (2028-10-08) is <60% of the annual forecast, revise the Month 30 (2029-04-08) readiness assumptions and consider extending the mandate or increasing public co-funding.
- Reserve €50–100M of programme budget as 'contingency co-funding' for carriers that would otherwise miss Month 30 (2029-04-08) but can demonstrate genuine technical blocker and willingness to accelerate if funded.

## Sensitivity

Baseline: carriers commit to €100–200M annual IT spend, totalling €500M–€1B+ over five years. If carriers invest only 60–70% of their commitments (e.g., €50–120M annually due to budget constraints or competing priorities), cumulative private spend is €250M–€600M, a 30–50% shortfall. This creates a funding gap: if carriers are under-investing and public co-funding is insufficient to compensate, 15–25% of carriers slip past the Month 30 (2029-04-08) mandate, fragmenting the network. Estimated impact: fragmented network reduces through-ticket volumes by 10–20 percentage points and extends the full-network timeline (Month 60 = 2031-10-08) to Month 66–72 (2032-04-08 to 2032-10-08), delaying environmental and capacity benefits.

---

## Issue 17 - Data Quality and Inventory Accuracy Risk: Legacy-System Mapping Errors Cause Booking Failures and Liability Disputes

Regional hubs translate legacy carrier inventory and business rules into the OSDM standard, but mapping errors (e.g., double-counting of restricted seats, misalignment of fare conditions, incorrect availability windows) break through-tickets and trigger liability disputes. If 2–5% of bookings fail at final confirmation due to hub mapping errors (e.g., seat shows available in search but unavailable at confirmation), passengers experience frustration, refund disputes accumulate, and distributors lose confidence. Hub operators lack incentive to invest in accuracy if volumes are low or if liability is unclear. By Month 18–24 (2028-04-08 to 2028-10-08), if hub mapping errors are discovered in live operation, recovery takes 4–8 weeks per carrier and requires expensive rework.

## Recommendation

- Define comprehensive hub API specifications and test harnesses in Month 2–4 (2026-12-08 to 2027-02-08) in collaboration with legacy operators and hub operators.
- Conduct external validation (Month 4–6 = 2027-02-08 to 2027-04-08) using an independent test lab, comparing hub output against real inventory samples from each carrier across 30–50 test journeys per carrier.
- Require dual-run (hub and native) for 2–4 weeks per carrier (Month 15–18 = 2028-01-08 to 2028-04-08) before traffic is cut over, detecting mapping errors in pre-production.
- Establish a hub incident-response team with on-call escalation to the carrier's inventory team, targeting <2-hour resolution for critical failures.
- Require hub operators to carry errors-and-omissions liability insurance covering overstated availability and inventory errors, with a minimum policy limit of €2–5M per hub.
- Include hub data-quality metrics (booking-failure rate, oversell rate, mapping-accuracy rate) in the conformance checklist and monthly measurement dashboard starting Month 18 (2028-04-08).
- If a hub's booking-failure rate exceeds 2% for >1 week, suspend new carrier onboarding to that hub until the issue is resolved.

## Sensitivity

Baseline: hub mapping is validated externally by Month 6 (2027-04-08), dual-run catches errors by Month 18 (2028-04-08), booking-failure rate is <0.5%. If external validation is delayed to Month 8–9 (2027-06-08 to 2027-07-08), errors are not caught until live operation (Month 18–24 = 2028-04-08 to 2028-10-08), adding 4–8 week recovery per carrier and delaying smaller-carrier readiness by 4–12 weeks. If booking-failure rate is 2–5% instead of <0.5%, refund volume increases by 3–10M passengers per year, consuming €150–500M in unplanned refunds and liability reserves (estimated 10–30% contingency consumption). If hub mapping errors are not resolved by Month 30 (2029-04-08), smaller carriers' through-ticket reliability is questionable, and distributors scale back integration and marketing, reducing through-ticket volumes by 10–20 percentage points.

---

## Issue 18 - Incomplete Stakeholder Buy-In: Smaller Carriers, Member-State Regulators and Community Opposition Risk

The programme requires buy-in from 27 member-state regulators, 25+ carriers of varying sizes, disability-rights organizations, and community stakeholders. Smaller carriers and weaker regulators may feel marginalised if programme decisions are made without sufficient consultation or if co-funding is limited. Regional opposition (e.g., transport unions fearing job losses in ticketing services) can create political friction. If 1–2 key member states withdraw support or key stakeholder groups publicly oppose the programme by Month 12–18 (2027-10-08 to 2028-04-08), political momentum erodes and parliamentary or Commission support softens.

## Recommendation

- Establish a robust stakeholder-engagement framework in Month 0–1 (2026-10-08 to 2026-11-08) with: (1) monthly all-hands forum (Month 1 = 2026-11-08 onward) including all major carriers, smaller-operator representatives (CER), all national regulators, BEUC, disability-rights organizations and transport unions; (2) dedicated SME (small/medium carrier) working group with rotating leadership, meeting bi-weekly (Month 1 = 2026-11-08 onward) to ensure smaller operators' concerns are heard; (3) Community Liaison Officer (1 FTE) managing communication with transport unions and regional stakeholders, conducting quarterly regional workshops in each priority-corridor area (Month 3 = 2027-01-08 onward).
- Publish a comprehensive stakeholder communication strategy (Month 2 = 2026-12-08) clarifying: (1) timeline and milestones, (2) funding allocation and co-funding eligibility, (3) costs and benefits per stakeholder group, (4) escalation path for grievances.
- Conduct a mid-programme stakeholder satisfaction survey (Month 18 = 2028-04-08) to gauge engagement and identify emerging concerns; if satisfaction is <70% among any stakeholder group, trigger a 4-week focused outreach campaign.
- If a member state or major stakeholder publicly opposes the programme by Month 12 (2027-10-08), escalate immediately to DG MOVE and Commission for political engagement and remedial action.

## Sensitivity

Baseline: stakeholder satisfaction >80%, no major public opposition by Month 18 (2028-04-08). If satisfaction drops to 60–70% and opposition emerges (e.g., transport unions file formal complaint to the Commission), political pressure could force weaker standards or longer timelines (estimated 2–6 month delay in decision-making). If 2+ member states withdraw support, the programme loses regulatory leverage and enforcement credibility, reducing carrier compliance by 20–30 percentage points and extending timelines by 6–12 months.

---

## Issue 19 - Post-Month 60 (2031-10-08) Sustainability and Continuity: Programme Ends at Month 60 (2031-10-08), But Operations Continue; Funding Cliff Risk

The programme's public coordination is budgeted through Month 60 (2031-10-08), but the through-ticketing system's operational dependencies (data layer, clearing mechanism, public reference distributor, regulator capacity) do not end. If the programme dissolves at Month 60 (2031-10-08) and does not transition to sustainable operational funding models (e.g., the data layer is privatised, the public distributor is handed to a commercial operator, or regulator funding is devolved to member states), operational continuity is at risk. Member states may be unwilling or unable to fund regulator capacity building beyond the programme period; payment institutions may exit if transaction volumes are insufficient for profitability; the public distributor may be unable to operate commercially and may be forced to close, reducing passenger choice.

## Recommendation

- Establish a Sustainability Working Group in Month 30 (2029-04-08) to design transition models for each programme component: (1) Data-layer operations: identify a permanent operational host (e.g., EU Agency for Railways or a multi-carrier consortium) and transition governance and financing by Month 48 (2030-10-08); (2) Clearing mechanism: shift to operational cost recovery (transaction fees cover ops costs) or permanent public funding commitment from the Commission; (3) Public reference distributor: define a post-Month 60 (2031-10-08) operating model (shutdown, hand-off to commercial operator, or downsizing to niche service); (4) Regulator capacity: secure member-state commitment to maintain funding (e.g., via national budgets or EU multi-annual framework).
- Secure written commitment from the Commission, Council and member states by Month 48 (2030-10-08) confirming post-Month 60 (2031-10-08) funding and operational arrangements.
- If member states do not commit to regulator funding, trigger contingency: consolidate regulator roles at EU Agency for Railways level and shift costs to carrier license-fee revenue.
- If the public distributor is not handed off to a commercial operator by Month 60 (2031-10-08), conduct an orderly shutdown (3–6 month wind-down, passenger notification, endpoint services).
- Plan for a formal handover and sustainability review (Month 54–60 = 2031-04-08 to 2031-10-08) to ensure continuity and avoid sudden service disruptions.

## Sensitivity

Baseline: transition plans are agreed by Month 48 (2030-10-08), permanent funding is secured by Month 54 (2031-04-08), operations continue seamlessly post-Month 60 (2031-10-08). If transition planning is delayed to Month 48+ or funding commitments are not secured, operational continuity is at risk. If member states do not commit to regulator funding, regulator capacity and enforcement decay post-Month 60 (2031-10-08), and non-discrimination compliance weakens. If the public distributor is not handed off or shut down cleanly, it continues operating unsustainably (burning public money) or operates under commercial contracts that are not cost-effective. Estimated impact: failure to plan sustainability could result in programme collapse at Month 60 (2031-10-08), undermining all prior investment and leaving through-ticket infrastructure orphaned and operationally fragile.

---

## Issue 20 - Regulatory and Legal Alignment Risk: Final Regulation Text Divergence From Assumed Framework; Standards Rework Required

The programme's design is based on the Commission's proposed Regulation on Digital Booking and Ticketing Services (May 2026), which is not yet adopted. Parliamentary amendments and member-state negotiations could significantly alter the final text, especially on: (1) scope (which corridors and carriers are in-scope), (2) access-term definitions (what 'non-discriminatory' means), (3) liability allocation (who bears costs for failed connections), (4) passenger-rights integration with existing rail-rights rules. If final text diverges materially, standards and operational rules developed before adoption may require significant rework (Month 18–24 = 2028-04-08 to 2028-10-08), delaying implementation and frustrating stakeholders.

## Recommendation

- Establish a Legislative Tracking and Alignment Team in Month 0 (2026-10-08) that monitors Parliament and Council negotiations monthly and identifies divergences from the Commission's proposed text.
- Conduct a quarterly alignment review (Month 3 = 2027-01-08 onwards) comparing assumed framework vs. emerging final text; if material divergences are detected, escalate to DG MOVE and Programme Governance for decision on whether to adjust programme assumptions or advocate for Commission negotiating position.
- Maintain a flexibility buffer in standards-development methodology: defer detailed specification of contested areas (e.g., access-term pricing, liability allocation) until Month 12–15 (2027-10-08 to 2028-01-08), giving Parliament and Council time to finalise legal text.
- If final Regulation text is materially different from assumptions, activate contingency: reserve 2–4 week 'rapid standards adjustment' period post-adoption (by Month 9–12 = 2027-07-08 to 2027-10-08) to rework standards as needed, rather than attempting to finalise standards before adoption is complete.

## Sensitivity

Baseline: final Regulation is adopted Month 6–9 (2027-04-08 to 2027-07-08) with minor deviations from the Commission proposal. If Parliament or Council makes substantial amendments (e.g., narrowing scope to only 4 corridors instead of TEN-T, or weakening non-discrimination requirements), standards-setting must be reworked, adding 4–8 weeks delay to Month 18 (2028-04-08) deadline. If final text diverges on liability allocation (e.g., making distributors liable rather than carriers), operational rules and payment-clearing logic must be re-engineered, adding 6–12 week delay. Estimated impact: material divergence discovered in Month 10–12 (2027-08-08 to 2027-10-08) forces a 4–8 week standards rework and risks missing the Month 18 (2028-04-08) deadline or delivering standards that carriers and distributors reject as infeasible.

---

## Issue 21 - International Coordination Beyond EU: Switzerland, Norway, UK Post-Brexit; Corridor Extension Complexity

The four priority corridors (Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin) involve non-EU actors: Switzerland (SBB), possibly Norway (NSB if Scandinavia corridors are extended), and the UK (post-Brexit, not EU). The Wien–München–Zürich corridor explicitly involves Switzerland; if SBB is not willing or able to integrate (due to regulatory differences, data-protection rules, or IT constraints), the corridor is incomplete and through-tickets cannot bridge to/from Switzerland. UK coordination post-Brexit is also unclear; if short-haul air reduction targets include UK routes (e.g., London-Paris-Brussels), UK carriers and regulators must be engaged but are not EU actors and may not accept EU standards.

## Recommendation

- Establish a Non-EU Stakeholder Engagement Stream in Month 1 (2026-11-08) covering: (1) Switzerland: secure an early Letter of Interest from SBB and the Swiss Federal Transport Office (OFT) confirming intention to participate in Wien–München–Zürich corridor and adopt OSDM standards by Month 30 (2029-04-08). (2) Norway: if Scandinavia corridors are prioritised, engage NSB and Norwegian regulator. (3) UK: clarify whether UK routes are in-scope for through-ticketing; if yes, establish a bilateral coordination mechanism with UK Department for Transport and UK carriers, separate from the EU programme but aligned on standards.
- Define bilateral agreements (Memoranda of Understanding) with each non-EU jurisdiction by Month 4–6 (2027-02-08 to 2027-04-08), specifying data-flow rules, liability allocation and dispute resolution.
- If Switzerland or other non-EU actor declines to participate, adjust corridor definition (e.g., Wien–München corridor stops at the Swiss border, and travellers to Switzerland must make separate bookings); communicate this clearly to stakeholders and adjust the 40% through-ticket target if corridor scope is reduced.

## Sensitivity

Baseline: Switzerland participates in Wien–München–Zürich corridor by Month 30 (2029-04-08), data-protection and regulatory alignment is resolved by Month 12 (2027-10-08), no material delays. If Switzerland delays commitment to Month 9–12 (2027-07-08 to 2027-10-08), and SBB signals IT integration challenges, the corridor's completion is delayed to Month 36–42 (2029-10-08 to 2030-04-08). If UK post-Brexit coordination is unclear and UK carriers are not integrated, any London-Paris or London-Brussels through-ticketing is not possible, reducing the programme's EU-UK mobility benefit. Estimated impact: if Switzerland or UK are out of scope or delayed, through-ticket volumes on affected corridors drop by 10–30 percentage points, and the 40% target becomes harder to achieve (requiring compensatory growth on all-EU corridors).

---

## Issue 22 - Climate and Energy Uncertainty: Fuel-Price Volatility and Aviation-Tax Policy Changes Affect Mode-Shift Viability

The modal-shift target (air-to-rail transition) assumes energy and taxation conditions remain stable over the five-year programme horizon. However, crude oil prices are volatile (current: ~€70–100/barrel; historical range: €30–150+), and aviation taxation is evolving (EU Commission proposed CO2-tax on aviation; several member states advocating for kerosene-tax harmonisation). If fuel prices drop 30–40% by Month 36 (2029-10-08), airline fares fall, and the through-fare (€70–90) is no longer competitive, modal shift plateaus at 2–5% instead of 10–20%. Conversely, if fuel prices spike to €150+/barrel or aviation taxes are introduced, airline fares rise sharply, and modal shift could exceed 25%. The programme's infrastructure case is sensitive to these external factors, yet they are largely outside the programme's control.

## Recommendation

- Conduct scenario planning in Month 2–4 (2026-12-08 to 2027-02-08) modelling through-ticket competitiveness under fuel-price ranges (€40–150/barrel) and aviation-tax scenarios (current policy, proposed CO2-tax, full kerosene harmonisation).
- Use scenarios to define 'target ranges' for modal shift (e.g., 'if fuel price is <€60, modal shift target is 5–10%; if fuel is €80–100, target is 10–20%; if fuel is >€120, target is 15–30%').
- Establish quarterly fuel-price and aviation-tax monitoring (starting Month 6 = 2027-04-08) and update modal-shift forecasts in the measurement dashboard.
- If energy prices or aviation policy shift materially (e.g., fuel drops >30% or aviation tax is repealed), trigger a mid-course programme review (Month 24–30 = 2028-10-08 to 2029-04-08) to reassess the mode-shift case and adjust targets and budgets if needed.
- Hedge against mode-shift miss by emphasising 'cross-border rail journey convenience' messaging and building through-ticket uptake on routes where rail already has competitive advantage (not just modal-shift routes).

## Sensitivity

Baseline: fuel price €70–100/barrel, no aviation tax until Month 36+, modal shift forecast 10–20%. If fuel drops to €40–50/barrel by Month 30 (2029-04-08), airline fares fall 20–30%, and modal shift drops to 2–5%, missing the 10–20% target by 50–75%. This would signal that the infrastructure investment's environmental case is weaker than assumed. If fuel spikes to €120+/barrel or aviation tax is introduced by Month 24 (2028-10-08), modal shift could exceed 20–25%, exceeding the target and validating the infrastructure case. Estimated impact: fuel-price volatility creates 15–25 percentage-point variance in modal-shift outcomes, and the programme's environmental and infrastructure case is correspondingly exposed to energy-market dynamics outside its control.

---

## Issue 23 - Legal Liability and Insurance Coverage Gap: Through-Ticket Accidents, Incidents and Cascading Failures Not Fully Insured

The programme introduces new liability vectors: if a through-ticket passenger is injured in a missed-connection incident (e.g., rushing between platforms, missing assistance), or if a system failure (API outage, hub failure) strands thousands of passengers, who bears liability? Insurance coverage for the clearing mechanism, hub operators, and payment institutions is assumed but not yet secured. If a major incident occurs (e.g., an API outage during a holiday period leaves 50,000+ passengers unable to access their bookings), liability exposure could be €10–50M, and if insurance is insufficient, the programme or carriers must absorb the loss.

## Recommendation

- Commission a comprehensive liability and insurance audit in Month 1–3 (2026-11-08 to 2027-01-08) identifying: (1) who is liable for which failures (distributor, carrier, payment institution, hub operator, programme entity), (2) insurance policies and coverage limits for each, (3) gaps (under-insurance, exclusions).
- Establish a Liability Framework document (Month 4–6 = 2027-02-08 to 2027-04-08) specifying liability allocation: carrier is liable for its operational failures (missed connections, accessibility delivery); distributor is liable for booking errors and false promises; payment institution is liable for settlement failures; hub operator is liable for mapping errors and service outages; programme carries residual liability for systemic failures (API infrastructure, data-layer integrity).
- Require all operational entities (hub operators, payment institutions, public distributor) to carry comprehensive liability insurance (errors & omissions, cyber, business interruption) with minimum limits of €2–10M depending on entity risk.
- Include liability requirements in conformance checklist and quarterly compliance reviews.
- Establish a Risk Pool or Contingency Fund (€5–10M reserve) for incidents exceeding individual-entity insurance limits, managed by the programme and funded from remaining budget contingency.
- If a major incident occurs and estimated liability exceeds insurance, activate the Risk Pool and conduct a root-cause analysis to prevent recurrence.

## Sensitivity

Baseline: all entities carry adequate insurance (limits: €2–10M per entity), Risk Pool of €5–10M is funded, no incidents exceeding total coverage. If an entity is under-insured (e.g., hub operator has only €500K coverage), and an incident occurs causing €5M loss, the shortfall (€4.5M) falls to the programme or other carriers. If a cascading failure (e.g., API outage + hub failure + payment-settlement delay) causes losses exceeding €20M, insurance may not cover the full amount, and recovery takes legal action (6–12 months). Estimated impact: under-insurance or uncovered incidents could consume 1–5% of the remaining programme budget and generate litigation (12–24 month resolution), creating opportunity costs and reputational damage.

---

## Issue 24 - Talent and Staffing Continuity Risk: Tight Labour Market for Specialists; Key-Person Dependency

The programme requires specialised expertise: OSDM standards engineers, rail-operations specialists, payment-system architects, regulator-capacity trainers, and EU institutional expertise. The tight labour market for such skills means hiring and retaining key staff is difficult and expensive. If the programme's Project Management Office or critical working groups lose key staff (e.g., standards lead, governance officer), continuity is disrupted. Distributed governance across Brussels, Vienna, Cologne and other hubs requires significant travel, which increases burnout and turnover risk. If staff turnover exceeds 20% annually (plausible for EU programme roles), knowledge loss and decision lag accumulate.

## Recommendation

- Establish a Talent Acquisition and Retention Strategy in Month 0–1 (2026-10-08 to 2026-11-08), covering: (1) competitive salary and benefits packages to attract specialised talent, (2) flexible working arrangements (hybrid, reduced travel), (3) professional development and skill-building (training budgets, conference attendance), (4) leadership continuity (succession planning for key roles).
- Staff the core Programme Management Office (PMO) by Month 2 (2026-12-08) with 10–15 FTE core team (programme director, technical leads, governance officer, communication lead), with recruitment locked in to reduce later hiring risk.
- Establish a 'knowledge transfer' protocol requiring key staff to document decision rationales, maintain shared wikis and provide 2–4 week handover to successors if they leave.
- Offer 10–15% salary premium and flexible working arrangements to key specialists (standards lead, API architect, regulator trainer) to reduce turnover.
- Establish a 'trusted advisors' network of external experts and consultants (2–3 on retainer) to backfill key roles if staff turnover occurs.
- If a key staff member leaves, activate contingency: accelerate backfill hiring and engage advisors to maintain continuity for 4–8 weeks until replacement is productive.

## Sensitivity

Baseline: core PMO is fully staffed by Month 3 (2027-01-08), staff turnover is <10% annually, key roles have identified backups. If staffing is delayed to Month 4–6 (2027-02-08 to 2027-04-08), governance and decision-making lag, and early working groups lack leadership (adding 2–4 week delays per group). If turnover is 15–20% annually, institutional knowledge is lost, decisions are re-litigated, and efficiency drops 15–25% (estimated impact: 3–6 month cumulative delay by Month 30 = 2029-04-08). If a key role (e.g., standards lead) turns over without backfill, standards finalisation is delayed 4–8 weeks (Month 18 = 2028-04-08 deadline at risk).

---

## Issue 25 - Post-Programme Evaluation and Learning: No Pre-Planned Evaluation Framework; Counterfactual Attribution Difficult

The programme is novel at EU scale (integrated through-ticketing across 27 member states, 25+ carriers, multiple modes). A rigorous evaluation will inform future EU transport infrastructure investment. However, the programme's assumptions do not include a pre-planned evaluation framework, baseline data are incomplete, and counterfactual attribution (separating programme effects from fuel prices, aviation policy, and other confounders) requires sophisticated methodology. If evaluation is not embedded from the start, by Month 60 (2031-10-08), it is difficult to credibly claim that mode-shift targets were met or to quantify return on investment. This undermines the programme's political case and weakens support for scaling to other corridors or for future similar initiatives.

## Recommendation

- Establish an Evaluation Framework and Commission an Independent Evaluator in Month 2–3 (2026-12-08 to 2027-01-08). Define evaluation scope: (1) process evaluation (governance, decision-making speed, stakeholder satisfaction), (2) output evaluation (standards adoption, carrier compliance, API/data-layer performance), (3) outcome evaluation (through-ticket volumes, modal shift, passenger satisfaction, distributor complaints), (4) impact evaluation (modal shift attribution, environmental impact, economic benefits).
- Conduct baseline survey in Month 0–2 (2026-10-08 to 2026-12-08) to establish starting conditions (cross-border sales volumes, modal split, complaint rates).
- Build a counterfactual model using comparison routes (non-rollout corridors) to separate programme effects from external factors (fuel prices, aviation taxes, capacity changes).
- Establish quarterly data-collection protocols and annual evaluation reports (starting Month 12 = 2027-10-08) to track progress and inform mid-course corrections.
- Budget €5–10M for comprehensive evaluation over five years.
- Use evaluation findings to adjust strategy, communicate progress to stakeholders and build the case for scaling beyond Month 60 (2031-10-08).

## Sensitivity

Baseline: evaluation framework is established by Month 3 (2027-01-08), baseline data collected by Month 6 (2027-04-08), quarterly tracking begins Month 12 (2027-10-08). If evaluation setup is delayed to Month 6–12 (2027-04-08 to 2027-10-08), baseline data quality is compromised and early programme tracking is weak. If counterfactual methodology is not robust (e.g., comparison routes are not comparable, or fuel prices vary too much), attribution of modal shift to the programme is questionable, and claims about environmental benefits are contested. Estimated impact: weak evaluation undermines the political case for the programme and makes it difficult to justify follow-on EU investment in similar initiatives; scrapping or scaling-back the programme at Month 48–60 (2030-10-08 to 2031-10-08) would represent a loss of momentum and credibility.

---

## Conclusion

This €1.5 billion, five-year EU through-ticketing programme faces three critical, interconnected risks that threaten its core milestones (Month 18 = 2028-04-08 standards, Month 30 = 2029-04-08 API mandate, Month 60 = 2031-10-08 full deployment).

First, regulatory adoption delay (Commission proposal unadopted as of Month 0 = 2026-10-08) could compress the standards-setting window from 9 months to 3–4 months, eliminating margin for consensus.

Second, the lightweight arbitration-panel governance model lacks binding enforcement authority over major incumbents; if Deutsche Bahn or SNCF resist compliance, escalation to the Commission is slow and discretionary.

Third, the €1.5 billion budget is fragile: carrier co-funding demand (€150–300M for 12–18 smaller operators), hub operations (€5–8M per hub), and unplanned costs could trigger 20–30% shortfalls by Month 24 (2028-10-08), forcing cuts to conformance testing or capacity building that slow smaller-carrier adoption.

Secondary risks include unclear modal-shift viability (through-fares may not compete with flights without regulated ceilings), GDPR data-governance challenges, uneven technology infrastructure, and unclear post-Month 60 (2031-10-08) sustainability.

The Pragmatic Foundation scenario mitigates these by deferring price regulation, using competitive accredited payment institutions, enabling regional hubs for smaller carriers, and establishing a time-boxed arbitration panel. Feasibility depends on: (1) regulation adoption by Month 9 (2027-07-08); (2) explicit written Council delegation to the arbitration panel by Month 2 (2026-12-08); (3) budget contingency (10–15%) protected through Month 24 (2028-10-08); (4) major carriers signing binding Commitment Letters accepting the Month 30 (2029-04-08) deadline.

Priority Actions:

- Establish regulation adoption tracking and political buy-in from Month 0 (2026-10-08).
- Secure written Council delegation to the arbitration panel by Month 2 (2026-12-08).
- Establish quarterly budget-burn dashboards and mid-course review gates at Month 12 (2027-10-08) and Month 24 (2028-10-08).
- Negotiate binding carrier commitment letters by Month 3 (2027-01-08), with explicit penalties for non-compliance.

The programme is ambitious and complex, but realistic delivery is feasible under the Pragmatic Foundation scenario if governance clarity, regulatory certainty and budget discipline are established immediately.