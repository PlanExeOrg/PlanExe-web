# Purpose
and

# Domain
# Primary domain: Rail Ticketing Interoperability

## Secondary domains

- Transport Regulation
- Public Program Management
- Clearing And Settlement

## Rationale

Rail Ticketing Interoperability is the outcome-role candidate with the highest importance × specificity (25) and names the program's core mechanism: OSDM-based cross-border through-ticketing.

## Disciplines this project involves

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Rail Ticketing Interoperability | 5 | 5 | outcome | Core mechanism: OSDM-based cross-border through-ticketing, distribution, clearing and refunds across carriers. |
| Transport Regulation | 5 | 4 | constraint | Program must align with proposed EU Regulation and passenger-rights and non-discrimination obligations. |
| Clearing And Settlement | 4 | 5 | method | Inter-carrier revenue clearing and single-payment settlement mechanism is a core build component. |
| Passenger Rights Law | 4 | 4 | constraint | Continuity-of-journey, refund harmonisation and rights backstop must satisfy EU passenger-rights rules. |
| API Standardization | 4 | 4 | method | OSDM-compatible real-time data layer needs binding standards, conformance testing and non-discriminatory access. |
| Transport Economics | 4 | 4 | outcome | Success depends on modal shift from short-haul air to rail and on fare and cost modelling. |
| Competition Law | 4 | 4 | constraint | Non-discriminatory distributor access and inter-carrier data and settlement arrangements raise EU competition issues. |
| Data Governance | 4 | 4 | method | The shared real-time data layer needs rules on access, data protection, quality and stewardship. |
| Public Program Management | 4 | 3 | method | Coordinating €1.5 billion multi-stakeholder rollout across member states, corridors and five-year milestones. |

# Plan Type
and

# Physical Locations
# Physical Locations

## Requirements for physical locations

- Proximity to EU institutions (DG MOVE, EU Agency for Railways) for governance and standards work
- Access to priority corridors: Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin
- Secure data-centre and high-availability connectivity for real-time data layer and clearing
- Test environments with access to live rolling stock, stations and gates for conformance pilots
- Easy access for national operators, CER, regulators, distributors and consumer/disability bodies
- Multilingual, skilled IT and financial-services workforce for clearing and distributor operations
- Competition-law-sensitive separation of clearing function (clean-team arrangement)

## Location 1: Belgium – Brussels

European Quarter (DG MOVE, CER and BEUC offices) and Brussels-Midi/Bruxelles-Midi station area

## Seat of DG MOVE, CER and BEUC

Central on Paris–Brussels–Amsterdam–Köln corridor. Natural hub for governance, stakeholder coordination and programme office.

## Location 2: France – Valenciennes / Lille area, Hauts-de-France

EU Agency for Railways headquarters (Valenciennes) with Lille-Europe station as corridor test access

## EU Agency for Railways location

Hosts EU Agency for Railways supervising standards, conformance testing and OSDM change control. Close to Paris–Brussels corridor trains for live pilots.

## Location 3: Germany / Switzerland / Austria – Berlin, Munich, Zürich and Wien corridor nodes

Operator IT and operations centres (e.g. Deutsche Bahn, SBB, ÖBB) along Wien–München–Zürich and Copenhagen–Hamburg–Berlin

## Large carrier operations and cross-border corridors

Large carrier IT and operations teams, OSDM expertise and busy cross-border corridors. Suited to conformance testing, carrier onboarding, clean-team clearing operations and private concession for last-resort distributor.

## Location 4: Spain / France – Madrid, Barcelona and Lyon

Renfe and SNCF operational hubs and stations on Madrid–Barcelona–Lyon corridor

## Air-competitive corridor pilots

Priority corridor with air competition and differing national systems. Suited for pilots on through-ticketing, assistance and bicycle reservations, and modal-shift measurement.

## Location Summary

Programme is European-wide and tied to named rail corridors and EU institutions. Brussels serves as governance and coordination hub, Valenciennes/Lille for EU Agency for Railways and conformance work, German-speaking corridor nodes for carrier IT and clearing operations, and Madrid–Barcelona–Lyon for air-competitive corridor pilots.

# Currency Strategy
` and `

# Identify Risks
# Risk 1 - Regulatory & Legislative

The proposed EU Regulation on Digital Booking and Ticketing Services for Rail (adoption timeline uncertain as of October 2026) may face parliamentary opposition, substantial amendments or Council negotiation delays. If adoption is delayed beyond Month 18 (2028-04-12), the binding-standards deadline becomes unachievable and carriers lose the legal mandate to expose inventory through OSDM APIs. Weaker conformance requirements could reduce participating carriers from the target 25+ to 15–20, fragmenting corridor coverage and lowering the through-ticket share from 40% to 25–30%.

Impact: Regulatory delay could cascade the mandatory API exposure milestone from Month 30 (2029-04-12) to Month 42 (2030-04-12) or later. Budget reallocation to fill coverage gaps could consume €200–400 million of the fixed €1.5 billion.

Likelihood: Medium

Severity: High

Action: Secure formal legal assurance from the Commission's legislative affairs unit that the Regulation will be tabled by Month 6 (2027-04-12) and adopted by Month 18 (2028-04-12), with binding-standards triggers contingent on publication in the Official Journal. Maintain a shadow legislative workstream documenting evolving compliance requirements. Establish contingency corridor definitions that include smaller operators earlier if coverage risk emerges.

# Risk 2 - Technical & Systems Integration

Legacy booking systems operated by smaller carriers cannot be retrofitted to expose real-time availability through OSDM-compatible APIs within the Month 30 (2029-04-12) mandatory exposure deadline. Older systems may lack architecture for event streaming, federated queries or transactional consistency. Integration adapters may be delayed or require longer development cycles than scheduled.

Impact: Smaller carriers may miss the Month 30 (2029-04-12) conformance deadline by 2–4 quarters, leaving 8–15 operators outside the network at critical corridor junctions. This fragments the through-ticket path. Estimated cost overrun to accelerate adapters: €150–250 million. Estimated delay in full TEN-T rollout: 12–24 months beyond Month 60 (2031-10-12).

Likelihood: High

Severity: High

Action: Initiate a pre-programme technical audit of all participating carriers' booking-system architectures by Month 2 (2026-12-12) to identify retrofit bottlenecks and establish realistic Month 30 (2029-04-12) conformance timelines per operator. Co-fund shared adapter modules via the Conformance Gate and Carrier Onboarding Support decision, allocating €200–300 million of the public budget to this layer. Tier conformance into baseline (Month 30 = 2029-04-12), extended (Month 36 = 2029-10-12) and advanced (Month 42 = 2030-04-12) phases, releasing funding tranches based on verifiable API availability and booking-error rates.

# Risk 3 - Commercial & Carrier Incentives

Carriers refuse to expose inventory and accept through-ticket connection liability because the liability backstop and clearing mechanism leave them unable to price exposure to missed-connection delays and rerouting costs. If the carrier-funded mutual guarantee pool is weighted solely on incident rates, carriers face unpredictable exposure linked to operational performance they do not fully control. Without a clear liability cap or insurance backstop, large carriers may refuse to expose seats.

Impact: If 30% of expected carriers refuse to participate, critical corridors become fragmented: the Köln–Amsterdam leg becomes unavailable, the München–Zürich corridor is fragmented. Estimated impact: 3–5 quarter delay in reaching the mandatory API exposure milestone, pushing full corridor through-ticketing to Month 72 (2032-10-12) or beyond. The 40% through-ticket goal becomes unachievable; realistic outcome is 15–20%.

Likelihood: High

Severity: High

Action: Complete the Through-Ticket Liability and Rights Backstop decision by Month 3 (2027-01-12) with a published carrier risk-allocation model specifying maximum carrier exposure per incident, insurance for exposure above the cap, and contribution-weighting rules tied to controllable factors (on-time performance in the 12 months prior, not forward-looking incident rates). Present this model to CER and the largest 10 carriers by Month 4 (2027-02-12) for binding commercial sign-off before standards are finalised. Establish a separate technical working group to model cash flows for the carrier-funded guarantee pool by Month 6 (2027-04-12).

# Risk 4 - Financial & Budget

The €1.5 billion public coordination budget (user constraint) is allocated across standards work (€50–100 million), clearing and settlement mechanism (€200–300 million), public reference distributor concession (€300–500 million over five years), member-state capacity building (€200–300 million), conformance testing and carrier adapters (€200–300 million) and consumer rollout (€100–150 million), leaving little contingency. If the carrier-funded guarantee pool drains faster than projected or the public distributor concession runs deeper operating losses than forecast, the Commission faces pressure to top it up from the public budget.

Impact: A €100–200 million draw on the public budget to cover guarantee-pool or distributor deficits in years 2–3 leaves only €100–200 million for the final-wave TEN-T extension (planned for Month 48–60 = 2030-10-12 to 2031-10-12), essentially cancelling the full-network rollout. This cuts the through-ticket goal from 40% to ~25%, primarily covering the four priority corridors. Member-state capacity building is cut by 30–50%.

Likelihood: Medium

Severity: High

Action: Commission an independent actuarial study of the carrier-funded guarantee pool by Month 6 (2027-04-12) with confidence intervals on missed-connection rates, rerouting costs and incident clustering. Establish a reserve fund of €150–200 million (drawn from the public budget allocation) earmarked for pool top-ups only in the case of force-majeure incidents (single-day corridor-wide disruptions affecting >5,000 passengers). For the public distributor concession, require monthly financial reporting and a trigger clause for subsidy increases if volumes fall below 60% of the forecast; if triggered, scale back the rollout to the four priority corridors and extend Month 60 (2031-10-12) completion to Month 72 (2032-10-12). Establish a policy with the Commission and the European Court of Auditors that public budget draw-downs on carrier pools beyond Month 36 (2029-10-12) will not occur, forcing recalibration of pool contributions or carrier participation instead.

# Risk 5 - Governance & Stakeholder Coordination

The program involves DG MOVE, the EU Agency for Railways, CER, 25+ national operators, independent distributors, national regulators, BEUC and disability-rights bodies. Alignment on critical decisions by Month 3–6 (2027-01-12 to 2027-04-12) requires consensus among parties with conflicting interests. CER and large carriers favour bilateral clearing and distributed liability; independent distributors demand a single clearing entity and a public guarantee; disability bodies require accessible, auditable assistance booking. Failure to secure consensus delays decisions, leaving the standards-working group without a liability model or clearing architecture.

Impact: If consensus is not reached by Month 9 (2027-07-12), the binding-standards milestone (Month 18 = 2028-04-12) is at risk. Estimated delay: 2–4 months. If independent distributors reject the final clearing design, they may legally challenge it or withdraw, reducing through-ticket volume by 20–30%.

Likelihood: Medium

Severity: High

Action: Establish a dedicated governance layer within the Programme Office by Month 1 (2026-11-12) with biweekly steering meetings of key stakeholders. Issue a non-binding position paper by Month 2 (2026-12-12) outlining three options for each critical decision with trade-offs clearly stated. Require binding votes on final decisions by Month 6 (2027-04-12), with Commission mediation available if a vote is deadlocked. For distributors that reject the clearing design, negotiate a fallback technical interface that allows them to settle through a third party, preserving their participation.

# Risk 6 - Competition Law & Regulatory

The Inter-Carrier Clearing, Single-Payment Settlement and Distribution Remuneration mechanisms involve competitors exchanging commercially sensitive data and potentially agreeing on commission rates or fare-construction rules. These arrangements could be viewed as prohibited coordination under Article 101 TFEU. The programme relies on the Joint Conduct Safe-Harbour for Shared Data and Clearing decision to secure Commission comfort before binding standards are finalised (Month 18 = 2028-04-12). If comfort is not obtained in time, or if a future challenge unwinds the clearing arrangements, carriers will not commit real-time inventory.

Impact: A competition-law challenge after Month 24 (2028-10-12) could force the programme to restructure the clearing mechanism and data-sharing layer, requiring 6–12 months of legal work and technical rework. Estimated cost: €50–100 million. If the challenge succeeds, the programme loses the centralised clearing or data layer, reverting to bilateral settlement and federated inventory queries, which add 3–4 months to settlement cycle times and increase booking-error rates by 15–25%, eroding the through-ticket value proposition.

Likelihood: Medium

Severity: High

Action: Initiate formal pre-notification with DG COMP by Month 2 (2026-12-12), before any technical specifications are fixed. Request a formal guidance letter by Month 12 (2027-10-12) confirming the clearing and data-sharing arrangements as compatible with Article 101 TFEU, conditioned on the specific design choices made. If DG COMP indicates concerns, establish a clean-team arrangement whereby the clearing function operates behind firewalls and releases only aggregated settlement data to carriers. Ensure this arrangement is documented and signed off by DG COMP before Month 18 (2028-04-12).

# Risk 7 - Technical & Data Quality

The Availability Query Topology relies on a streamed availability shadow (cached search layer) and carrier booking-engine authority. If carriers' booking engines are unavailable or respond slowly (>5 seconds), the system degrades to scheduled-only offers, which breaks through-ticketing. Legacy carrier systems, particularly smaller operators, often have 5–15 second query latency and 2–4 hour outages per month. A three-leg through-ticket requires three queries, so if each has 95% availability, the combined through-ticket availability is ~86%, not acceptable.

Impact: If carrier booking engines fail to meet <2 second latency and 99.5% availability targets, through-ticket search success rates fall to 70–80%, and the fallback to scheduled-only offers removes the commercial advantage of through-ticketing. Estimated impact: 30–50% lower through-ticket volume than forecast, pushing the 40% goal to 20–25%.

Likelihood: High

Severity: Medium

Action: Establish strict SLA targets for carrier booking-engine latency (<2 seconds per query, p95) and availability (99.5%) as part of the conformance gate. Build a monitored availability proxy that tracks each carrier's latency and availability in real time from Month 12 (2027-10-12) onwards and publishes a monthly scorecard. Attach tranches of the Milestone-Conditioned Funding Release Ladder to carriers meeting these SLAs: carriers that miss SLAs in two consecutive months lose a portion of their next funding tranche. Fund a lightweight caching layer (distributed, not central) that holds recent search results and degrades gracefully to cached results if a carrier endpoint fails.

# Risk 8 - Operational & Service Delivery

The Disruption Re-accommodation Choreography and Assistance and Bicycle Reservation Chaining require real-time, coordinated action across carrier networks: detecting a missed connection, proposing alternatives on competitors' trains, securing seats and confirming reroutes within minutes. This depends on shared operational data that carriers have historically guarded and on staff at stations and onboard who are trained to recognise across-carrier re-accommodation and accessible reservations. Smaller operators may lack 24/7 customer-service centres or English-speaking staff at border stations.

Impact: If re-accommodation response times exceed 30–60 minutes, or if passengers are not re-accommodated at all, the programme faces public backlash and liability claims. Estimated cost: €10–20 million in compensation and reputation damage per major incident. If assistance requests are delayed or unfulfilled, the programme violates accessibility law (EU Regulation 1371/2007). Disruption handling failures could reduce through-ticket adoption by 10–20%.

Likelihood: Medium

Severity: High

Action: Develop a detailed operational manual for all participating carriers by Month 9 (2027-07-12) covering missed-connection detection, re-accommodation procedures, seat-access protocols, assistance escalation and passenger communication at border stations. Conduct live pilots on each of the four priority corridors (Month 12–18 = 2027-10-12 to 2028-04-12) with 500–1,000 passengers per corridor, measuring response times, reroute success and passenger satisfaction. Require carriers to establish 24/7 customer-service centres and train staff at key border stations (at least one English-speaking agent at each) as a precondition of conformance certification by Month 30 (2029-04-12). Fund capacity-building and staff training through the member-state capacity-building budget.

# Risk 9 - Technical & Systems Integration

The Ticket Validation and Onboard Inspection Interoperability decision requires every train crew member, station agent and gate system on participating corridors to accept and validate through-tickets issued by any participating carrier. If carrier IT teams fail to implement the API handshake or hybrid credential format by Month 30 (2029-04-12), conductors and station agents have no way to validate across-carrier tickets, and manual workarounds reappear, eroding the through-ticket value.

Impact: If 20% of corridor vehicles lack proper validation capability by Month 60 (2031-10-12), passengers face validation disputes, penalties and delays, degrading the through-ticket experience. Estimated impact: 5–10% reduction in through-ticket adoption due to trust loss. If a validation failure leads to a passenger boarding without a valid ticket due to system incompatibility, the carrier faces a regulatory fine and reputational damage.

Likelihood: Medium

Severity: Medium

Action: Specify the API handshake or hybrid credential format as part of the OSDM standard by Month 6 (2027-04-12) and include it in conformance tests. Require all carriers to deploy validation capability to all corridor rolling stock and key stations by Month 40 (2030-02-12) (10 months before full corridor go-live), with intermediate audits at Month 30 (2029-04-12) and Month 35 (2029-09-12). Tie funding tranches to validation rollout milestones: carriers that fall 2+ months behind lose their next funding tranche. Fund a small team of on-site validation testers at each priority corridor from Month 24 (2028-10-12) onwards, publishing a publicly available scoreboard.

# Risk 10 - Market & Competitive

The Air-to-Rail Competitiveness Package aims to shift passengers from short-haul flights to rail through through-ticketing, intermodal products and information. However, the programme has limited direct control over carrier pricing and cannot control flight-operator pricing or schedule changes. If flight operators respond by cutting fares to €20–40 one-way, rail through-fares will struggle to compete even with the convenience factor.

Impact: If modal shift from air to rail is slower than forecast (5–10% instead of 15–20%), the 40% through-ticket goal is reached but the headline outcome—'fewer travellers choose the plane'—is not achieved, creating a political narrative of programme failure. The programme may face pressure to shift funding toward price subsidies for rail, draining the fixed €1.5 billion budget.

Likelihood: Medium

Severity: Low

Action: Conduct a baseline modal-shift study by Month 6 (2027-04-12) measuring current air-to-rail ratios on the four priority corridors and the impact of through-ticketing, intermodal information and journey-time visibility on booking behaviour. Establish conservative modal-shift targets tied to through-ticketing availability, not price. In the Air-to-Rail Competitiveness Package decision, focus on display neutrality and journey-time information (low cost) rather than fare commitments. If modal shift is slower than forecast, use Month 48 (2030-10-12) evaluation findings to adjust programme communications, emphasizing convenience and reliability over environmental goals.

# Risk 11 - Physical & Logistical

The programme is distributed across four member states with programme offices in Brussels, Valenciennes, Berlin and Madrid. The EU Agency for Railways is in Valenciennes, far from Commission HQ and from the largest carrier IT centres. Travel time, visa requirements and local staffing constraints can slow governance meetings and technical working groups.

Impact: Coordination delays, particularly in standards-working groups and conformance testing, could add 1–2 months to binding-standards and mandatory API exposure milestones. Estimated cost: €5–10 million in staff travel and extended contracts.

Likelihood: Low

Severity: Low

Action: Establish a virtual-first governance model with scheduled in-person meetings only for critical decisions. Use video conferencing for biweekly steering and technical working groups. Rotate in-person meetings between Brussels, Valenciennes and a carrier IT hub (Berlin or Munich) on a quarterly cycle, with participation costs covered by the programme budget. Hire at least one full-time liaison officer based in each of the four physical locations to support async coordination and local stakeholder engagement.

# Risk 12 - Regulatory & Policy

National railway regulators retain authority over track access, station capacity and pricing in their respective territories. The programme's binding standards and mandatory API exposure may conflict with existing national regulations or incumbent operator privileges. If a national regulator blocks the programme's data-sharing or clearing arrangements on competition or incumbent-protection grounds, the programme cannot proceed in that member state.

Impact: If one major corridor loses a national regulator's approval, the through-ticket network is fragmented and the corridor is blocked for 12–24 months while regulatory issues are resolved. Estimated impact: 6–12 month delay in mandatory API exposure milestone and a reduction in through-ticket reach of 20–30%.

Likelihood: Medium

Severity: High

Action: By Month 3 (2027-01-12), DG MOVE and the EU Agency for Railways must conduct bilateral engagement with each national regulator on the programme's scope, data-sharing arrangements and competition-law compliance. Prepare a regulatory-impact assessment for each member state. If conflicts are identified, work with national regulators to adapt the programme design or secure regulatory waivers by Month 12 (2027-10-12). Include national regulators as observers in the standards-working groups so they can flag regulatory constraints early. If a regulator's concerns cannot be resolved by Month 12 (2027-10-12), consider deferring that member state's participation to a Phase 2 rollout (Month 60 = 2031-10-12 onwards).

# Risk 13 - Accessibility & Inclusivity

The Assistance and Bicycle Reservation Chaining aims to make through-tickets accessible for persons with reduced mobility and cyclists. Compliance depends on carriers to provide wheelchair spaces, assistance at stations and onboard staff training. Rolling stock ages and accessibility standards vary widely across operators. Atomic confirmation of assistance and bicycle reservations means that itineraries without available spaces are refused, potentially creating legal exposure under EU Regulation 1371/2007 and the Accessibility Directive.

Impact: If participating carriers cannot guarantee assistance or bicycle space on 50%+ of through-ticket itineraries, the programme risks legal complaints to national regulators and the European Court of Justice. If atomic confirmation is dropped, passengers are left uncertain whether they will have access at journey time, eroding trust. Estimated reputational and legal cost: €20–50 million.

Likelihood: Medium

Severity: Medium

Action: By Month 6 (2027-04-12), require all participating carriers to publish their rolling-stock accessibility inventory for each service on the priority corridors. Establish minimum accessibility levels (wheelchair access on ≥80% of services, assistance availability with ≤4 hours' notice on ≥90% of services) as a precondition of conformance. For carriers unable to meet these levels by Month 40 (2030-02-12), allow a fallback to 'best-effort' booking with transparent communication to passengers. Engage disability-rights bodies as observers in the Assistance and Bicycle Reservation Chaining working group and conduct usability testing with persons with reduced mobility by Month 18 (2028-04-12). Fund accessibility infrastructure improvements through member-state capacity-building budget if carriers cannot self-fund.

# Risk 14 - Financial & Budget

The Public Reference Distributor Mandate (pragmatic option: tendered last-resort concession) requires the Commission to contract a private operator to run a last-resort sales channel. If the concessionaire overstates their cost efficiency, the contract runs into operating losses within 18–24 months and requests subsidy increases. If volume forecast is too optimistic, the concessionaire operates at a loss and may withdraw.

Impact: If the concessionaire withdraws by Month 36 (2029-10-12) or requests a subsidy increase >€50 million, the Commission must either operate the distributor directly or leave the last-resort role unfilled, undermining the programme's claim to provide a neutral channel. Estimated risk: €75–150 million in subsidy overrun or €30–50 million in government operating costs.

Likelihood: Medium

Severity: Medium

Action: By Month 9 (2027-07-12), develop a detailed business case for the public distributor concession, including volume forecasts, cost benchmarks and margin assumptions. Issue a competitive tender by Month 12 (2027-10-12) with a two-stage evaluation: technical requirements and financial viability. Cap the initial subsidy at €60 million over five years and include a clawback clause: if through-ticket volumes exceed forecast by >20%, the concessionaire must rebate surplus fees to the Commission. Require quarterly financial reports and trigger a contract review if operating costs exceed budget by >15% in any quarter.

# Risk 15 - Technical & Data Quality

The Inter-Carrier Clearing and Single-Payment Settlement (pragmatic option: federated layer) depends on carriers submitting consistent, timely settlement data. If carriers' financial systems use different formats, currencies or accounting methods, reconciliation is slow and error-prone. A 2–3% reconciliation error rate translates to thousands of disputed transactions per month, overwhelming dispute-resolution capacity and delaying payouts to distributors.

Impact: If reconciliation error rates exceed 2%, settlement cycle times lengthen from the targeted 5 business days to 10–15 days, cash flow friction increases for distributors. Estimated impact: 15–20% of distributors may reduce participation, lowering through-ticket volume by 10–15%.

Likelihood: Medium

Severity: Medium

Action: Establish a detailed data-format standard for settlement feeds as part of the OSDM specification by Month 6 (2027-04-12). Require all carriers to submit settlement data in the standard format via a validated API by Month 24 (2028-10-12), with test environments available from Month 12 (2027-10-12) onwards. Fund a shared reconciliation platform (part of the clearing mechanism budget) that automates basic matching and flags mismatches for manual review. Set a target reconciliation error rate of <0.5% by Month 30 (2029-04-12), with automatic penalties for carriers exceeding 1% error rates in any month.

# Risk 16 - Operational & Service Delivery

Member-state capacity building (€200–300 million allocation within the €1.5 billion budget) is required to train national railway operators, regulators and consumer bodies on the new standards, systems and passenger-rights procedures. Smaller member states may lack in-country expertise and depend on external training. If capacity building is delayed or under-resourced, local operators and regulators may not meet the mandatory API exposure or conformance milestones.

Impact: A 6–9 month delay in capacity building for smaller member states could push their participation from Month 60 (2031-10-12) to Month 72 (2032-10-12) or later, fragmenting pan-European coverage and reducing the through-ticket share from 40% to 30–35%.

Likelihood: Low

Severity: Medium

Action: Allocate €30–50 million of the capacity-building budget specifically for external training programs delivered by the EU Agency for Railways or contracted trainers, targeting smaller member states and less-resourced operators. Establish regional training hubs in Brussels, Valenciennes, Berlin and one southern hub (e.g., Madrid or Rome). Conduct a skills audit by Month 6 (2027-04-12) to identify member states with capacity gaps and tailor training curricula. Schedule intensive training programs (2–3 weeks per operator) at Month 18–24 (2028-04-12 to 2028-10-12) to coincide with the binding-standards deadline.

# Risk 17 - Regulatory & Policy

The programme's success relies on attracting independent distributors to integrate with the shared real-time data layer and clearing mechanism. The Distribution Remuneration and Commission Corridor sets the terms under which carriers pay distributors per through-ticket sold. If commission rates are too low, distributors reduce investment in through-ticket search and promotions; if too high, carriers view through-distribution as unprofitable and restrict inventory access.

Impact: If commission rates are set below distributors' cost of acquisition and support (typically 3–5% of fare), large independents may deprioritise through-tickets, reducing through-ticket volume by 20–30%. If rates are set above 5%, the market consolidates to incumbents, reducing competition and innovation. Estimated impact: 15–20% reduction in through-ticket share.

Likelihood: Medium

Severity: Medium

Action: Commission an industry survey by Month 3 (2027-01-12) of Trainline, Omio and 5–10 smaller distributors to establish their cost of acquisition, customer support and payment processing for cross-border through-tickets. Use this data to establish a commission-rate band (e.g., 2.5–4.5% of through-fare) that covers distributors' costs while allowing carriers margins. Include the band in the Distribution Remuneration and Commission Corridor decision by Month 9 (2027-07-12). Require the clearing function to publish monthly commission-rate data by distributor type and check for discrimination. If a distributor claims discrimination, require a mediated review by Month 30 (2029-04-12).

# Risk 18 - Technical & Systems Integration

The Specification Custodian Seat for OSDM Evolution (pragmatic option: Agency for Railways anchoring with an escrowed open-source reference implementation) requires a formal, published change-control process for the OSDM specification. If the process is too slow (3–6 months per request), carriers and distributors may fork the specification. If too fast (weeks), carriers with legacy systems struggle to keep pace and integration failures emerge.

Impact: If the specification forks significantly by Month 42 (2030-04-12), conformance testing becomes ambiguous and the mandatory API exposure milestone is delayed. Estimated delay: 3–6 months. A slow change process could delay critical bug fixes or security updates by 6–9 months.

Likelihood: Low

Severity: Medium

Action: Establish the OSDM change-control process as part of the Agency for Railways mandate by Month 3 (2027-01-12), with published criteria for change request severity (critical: security/safety; major: functional gaps; minor: optimisations), review timelines (critical: 2 weeks; major: 6 weeks; minor: 8 weeks) and approval gates (technical review by at least 3 independent carriers, competition-law check for sensitive changes). Publish a quarterly release cadence. Archive all historical versions in an open-source repository with escrowed backups. Establish a change-request dashboard showing pending and approved changes.

# Risk 19 - Compliance & Legal

Passenger rights on cross-border rail journeys are governed by EU Regulation 1371/2007 (railway passengers' rights). The Through-Ticket Liability and Rights Backstop and Disruption Re-accommodation Choreography must ensure that a through-ticket passenger has equivalent rights regardless of the number of carriers involved. If the programme's rights backstop and liability rules are less generous than Regulation 1371/2007 or create gaps, passengers may lose rights and the programme faces regulatory complaints.

Impact: If passengers lose rights, the EU Agency for Railways or national regulators may issue enforcement notices, forcing the programme to redesign the liability and disruption-handling rules, delaying implementation by 3–6 months. Estimated cost: €10–20 million in legal work and programme redesign.

Likelihood: Low

Severity: Medium

Action: By Month 3 (2027-01-12), commission an independent legal review of the Through-Ticket Liability and Rights Backstop design against EU Regulation 1371/2007, ensuring that through-ticket passengers have equivalent or better rights than single-carrier passengers. Publish the legal opinion and any required design adjustments by Month 6 (2027-04-12). Ensure that the Disruption Re-accommodation Choreography operating manual includes step-by-step procedures for compensation claims, assistance and liability that comply with Regulation 1371/2007. Submit the manual to the EU Agency for Railways for formal review and approval by Month 9 (2027-07-12) before carrier pilots begin.

# Risk 20 - Organizational & Governance

The programme requires a Programme Office and a Technical Secretariat to coordinate standards work, conformance testing, funding releases and stakeholder engagement across five years and four locations. Programme staff turnover, particularly in leadership roles, can disrupt continuity and delay decision-making. If the Programme Office lacks clear authority over budget releases or standards-working groups, carrier and distributor consensus becomes harder to achieve.

Impact: A change in Programme Director or Technical Lead at critical junctures (Month 12–18 = 2027-10-12 to 2028-04-12 for binding standards, Month 24–30 = 2028-10-12 to 2029-04-12 for API exposure) could add 2–3 months of ramp-up time and defer milestones. If the Programme Office cannot enforce milestone conditions, compliance will drop and the schedule will slip. Estimated cost: €5–10 million in extended programme management and consultant engagement.

Likelihood: Medium

Severity: Low

Action: By Month 1 (2026-11-12), the Commission must formally establish the Programme Office and Technical Secretariat with clear governance, a multi-year budget (€50–100 million for programme management) and retention incentives for key staff (3–5 year appointments with continuity clauses). Define success milestones and annual review cycles so that leadership changes are planned at low-risk points (Month 12 = 2027-10-12 and Month 36 = 2029-10-12). Establish an advisory board of external experts (from carriers, distributors and academics) to provide independent oversight and escalation paths.

## Risk Summary

This is a large, multi-stakeholder public infrastructure program spanning five years, four priority corridors and the full TEN-T network. It layers shared standards (OSDM-compatible APIs, clearing, rights backstop) over existing national carrier systems to enable seamless cross-border rail through-ticketing. The program operates under a fixed €1.5 billion public coordination budget (user constraint) and faces three interconnected critical risks: (1) Carrier unwillingness to expose inventory and accept connection liability unless the backstop design and clearing mechanism guarantee they can price the risk fairly—blocking the binding-standards milestone if not resolved by Month 18 (2028-04-12); (2) Legacy IT integration delays and conformance failures on priority corridors, particularly with smaller operators' systems, which could push the mandatory API exposure milestone (Month 30 = 2029-04-12) into later quarters and starve funding for subsequent corridors; (3) Budget exhaustion if the carrier-funded guarantee pool drains faster than projected or the public distributor concession runs deeper deficits, cutting funding for member-state capacity building and reducing the likelihood of the 40% through-ticket goal. The regulatory and competition-law pathway is complex, with a Regulation proposal in Commission hands (not verified) and Article 101 TFEU clearance needed before binding standards. Physical location dependencies add coordination overhead. The program depends on passenger behaviour change, multimodal integration and disability-rights compliance that are largely outside the program's control. Most critical are the carrier liability and inventory-exposure decisions, which, if mishandled, could trigger carrier non-participation and unravel the entire through-ticketing stack.

# Make Assumptions
# Financial Allocation and Budget

## Budget Split Across Priorities

- Standards: €50–100M
- Clearing: €200–300M
- Last-resort concession: €300–500M
- Adapters: €200–300M
- Capacity building and consumer rollout: €200–300M
- Reserve: €150–200M

Private carrier IT investment estimated separately at €1.5–3B.

## Financial Feasibility Assessment

Upper-range allocations exceed €1.5B, leaving thin contingency. Risks include pool top-ups and concession/adapter overruns (€75–250M estimate). Mitigation: milestone tranches, reserve for force-majeure only, subsidy cap on concession, quarterly budget re-baselining, and carrier co-financing of adapters.

# Schedule and Milestones

## Realistic Milestone Sequence

- Month 1 (2026-11-12): Governance set-up
- Month 6 (2027-04-12): Liability and clearing decisions
- Month 18 (2028-04-12): Binding standards
- Month 30 (2029-04-12): Mandatory API exposure
- Month 42 (2030-04-12): Tiered conformance
- Month 48 (2030-10-12): Four-corridor through-ticketing
- Month 60–72 (2031-10-12 to 2032-10-12): Full TEN-T coverage

## Schedule Realism Assessment

Critical path: Regulation text → DG COMP comfort → liability model → standards. A 12–18 month legislative delay moves Month 18 (2028-04-12) to Month 30 (2029-04-12) (estimate). Mitigation: shadow standards workstream, pilots at Months 12–18 (2027-10-12 to 2028-04-12), tiered conformance, and Month 72 (2032-10-12) fallback for full TEN-T. Priority corridors deliver value by Month 48 (2030-10-12) even if network completion extends beyond.

# Staffing and Expertise

## Resource Requirements

- Programme Office: 60–100 staff in DG MOVE
- Technical Secretariat: 40–60 at Agency in Valenciennes
- Contracted test engineers, actuaries and legal specialists
- Carrier integration teams with liaison officers in Brussels, Valenciennes, Berlin and Madrid

## Resource Capacity Assessment

OSDM and clearing expertise is scarce and concentrated. Risks: key-person turnover, competition with carriers for engineers, capacity gaps in smaller member states. Mitigation: multi-year appointments, framework contracts with integrators, regional training hubs, external advisory board. Budget: €50–100M for programme management (estimate).

# Legal Framework and Approvals

## Legal Instruments

- Regulation adopted with amendments by Month 18 (2028-04-12) (estimate)
- OSDM pinned via delegated or implementing act
- DG COMP guidance on Article 101 sought from Month 2 (2026-12-12)
- Regulation 1371/2007 passenger rights remain the floor
- National regulators join as observers

## Regulatory Compliance Assessment

Largest exposure: Article 101 challenge post-investment (€50–100M rework estimate). Mitigation: early pre-notification, clean-team clearing, independent legal review by Month 3 (2027-01-12), regulator impact assessments per member state. Gaps in rights versus Regulation 1371/2007 would require 3–6 month redesign. Early certainty encourages carrier commitment.

# Liability and Risk Management

## Liability Framework

- Carrier-funded guarantee pool with per-incident caps
- Co-insurance above caps, contributions based on trailing on-time performance
- Reserve for force-majeure only
- Availability SLAs: p95 latency under 2 seconds, 99.5% uptime (proposed)
- Reconciliation error under 0.5% (proposed)

## Risk Exposure Assessment

Highest risks: carrier refusal over unpriceable liability, availability across three-leg queries (approximately 86% at 95% each), pool drain from disruption clusters. Mitigation: actuarial study by Month 6 (2027-04-12), caps, SLA scorecards linked to tranches, cached fallback. Residual risk remains medium until pilots validate loss rates.

# Environmental Outcomes

## Environmental Impact Assessment

Programme-level impact is mainly indirect via air-to-rail shift on competitive corridors. Baseline measured by Month 6 (2027-04-12) (estimate). Targets: through-ticket penetration and observed shift, conservative 5–10% on benchmarked routes (estimate). Hardware retrofits follow maintenance cycles; data centres use existing carrier or cloud capacity. Risks: low-fare airline response, attribution difficulty, e-waste from upgrades. Mitigation: baseline and control routes, emissions-sorted neutral display, device reuse and recycling clauses, Month 48 (2030-10-12) evaluation. Do not promise air-replacement as a success metric.

# Stakeholder Engagement

## Steering Group Composition

- DG MOVE and the Agency
- CER, 3–4 major carriers
- Trainline, Omio
- BEUC and disability body
- Regulator observers
- Biweekly meetings with binding votes on core decisions by Month 6 (2027-04-12)
- Commission mediation if needed
- Independent distributors settle via third-party fallback interface

## Stakeholder Alignment Assessment

Conflicts: carriers prefer bilateral clearing, distributors want neutral central rules, disability bodies need auditable assistance booking. Failure by Month 9 (2027-07-12) risks 2–4 month standards delay and 20–30% loss of distributor volume (estimate). Mitigation: option papers by Month 2 (2026-12-12), transparent commission band, observer seats, PRM usability testing by Month 18 (2028-04-12). Early buy-in reduces later legal challenge.

# Operational Systems and Processes

## Core Systems Required

- Streamed availability shadow with carrier booking authority
- Federated netting layer on EUR settlement with 5-business-day cycle (proposed)
- Shared disruption event feed
- API handshake or signed journey token for validation
- 24/7 support and monitored SLA dashboard
- Live pilots of 500–1,000 passengers per corridor (proposed)

## Operational Readiness Assessment

Legacy latency, data quality and unshared operational data are main constraints. Risks: stale-seat errors, reconciliation backlog, validation gaps on 20% of vehicles lowering adoption 5–10% (estimate). Mitigation: operational manual by Month 9 (2027-07-12), pilots Months 12–18 (2027-10-12 to 2028-04-12), validation deployment by Month 40 (2030-02-12), shared reconciliation platform. Staged tiers allow strong carriers to go live first.

# Distill Assumptions
# Budget

- Public coordination budget: €1.5 billion (user constraint), covering standards, clearing, concession, adapters, capacity building and rollout.
- Private carrier IT investment: roughly €1.5–3 billion (estimate).
- Budget split (estimates): standards €50–100M, clearing €200–300M, concession €300–500M, adapters €200–300M, capacity building €200–300M, consumer rollout €100–150M, reserve €150–200M (force majeure only).
- Upper-range allocations exceed €1.5B; contingency is thin. Quarterly budget re-baselining and concession subsidy cap apply.
- Funds released in tranches against verified milestones (conformance certificates, live API exposure).

# Timeline

- Governance set up by Month 1 (2026-11-12).
- Liability and clearing decisions by Month 6 (2027-04-12).
- Binding standards due by Month 18 (2028-04-12).
- Mandatory API exposure by Month 30 (2029-04-12).
- Tiered conformance runs to Month 42 (2030-04-12).
- Four-corridor through-ticketing delivered by Month 48 (2030-10-12).
- Full TEN-T completes Months 60–72 (2031-10-12 to 2032-10-12), with Month 72 (2032-10-12) as pre-agreed fallback.
- Regulation adoption assumed with amendments by about Month 18 (2028-04-12) (6–12 month slip plausible, not verified).
- Pilots of 500–1,000 passengers per corridor run Months 12–18 (2027-10-12 to 2028-04-12); validation deployment completes by Month 40 (2030-02-12).

# Approach

- Federated settlement, streamed availability shadow, carrier booking authority, carrier-funded guarantee pool, tendered last-resort concession.
- Guarantee pool uses per-incident caps, co-insurance above caps, and contributions based on trailing on-time performance; actuarial study by Month 6 (2027-04-12).
- DG COMP Article 101 guidance sought from Month 2 (2026-12-12); clean-team clearing and legal review of backstop by Month 3 (2027-01-12).
- OSDM pinned via delegated or implementing act; Regulation 1371/2007 rights remain the floor.

# Settlement and Service Levels

- Settlement uses EUR with 5-business-day cycle; reconciliation error stays under 0.5% (proposed).
- Availability SLAs: p95 latency under 2 seconds and 99.5% uptime (proposed thresholds).

# Governance and Stakeholders

- Steering group: DG MOVE, Agency, CER, 3–4 major carriers, Trainline, Omio, BEUC, disability body and regulator.
- Meets biweekly; binding votes on core decisions by Month 6 (2027-04-12) with Commission mediation.
- Programme Office: 60–100 staff at DG MOVE (estimate); Agency secretariat: 40–60 staff (estimate).
- Carriers supply integration teams; OSDM and clearing expertise is scarce.

# Targets and Impact

- 40% of cross-border journeys as through-tickets, distributor complaints halved, within five years.
- Modal shift conservative at 5–10% on benchmarked routes (estimate); air replacement not a success metric.

# Key Risks

- Carrier refusal over unpriceable liability.
- Article 101 challenge (€50–100M rework).
- Legacy latency.
- Legislative delay.
- Stakeholder alignment failure by Month 9 (2027-07-12) risks 2–4 month standards delay and 20–30% distributor volume loss (estimates).


# Review Assumptions
# Domain of the Expert Reviewer
Public infrastructure programme planning and multi-stakeholder governance, with focus on regulatory alignment, financial risk and operational integration at scale.

## Domain-Specific Considerations

- Fixed public budget (€1.5 billion, user constraint) covers five-year rollout across four corridors and full TEN-T; no contingency for cost overruns beyond force majeure
- Carrier participation is voluntary and depends on predictable liability pricing; unpriceable risk exposure triggers non-participation and network fragmentation
- Regulatory pathway uncertain: Regulation adoption status not verified; Article 101 TFEU comfort needed before binding standards; Regulation 1371/2007 rights must be preserved
- Legacy systems integration: smaller operators' booking engines may not meet latency and availability targets, delaying mandatory API exposure by 6–12 months
- Multi-stakeholder consensus among 25+ carriers, independent distributors, national regulators and disability bodies required by Month 6 (2027-04-12); failure cascades to standards
- Through-ticket value depends on seamless operational coordination across independent national operators with varying systems and cultures

# Issue 1: Carrier Liability Pricing Model Not Defined

## Background

The programme assumes carriers will expose through-ticket connections and accept shared liability via a carrier-funded guarantee pool (Decision 1), but the liability-weighting formula, per-incident caps, co-insurance thresholds and risk-transfer mechanism are not specified. Carriers cannot price participation or commit inventory without knowing maximum exposure and contribution rules. Absence of a published liability model by Month 3 (2027-01-12) leaves the core commercial assumption untested and triggers carrier refusal.

## Recommendation

By Month 2 (2026-12-12), commission an independent actuarial study to model missed-connection rates, rerouting costs and incident clustering using historical data from each carrier. Publish a draft liability-weighting formula by Month 3 (2027-01-12) specifying:

- Maximum per-incident cap (e.g., €500–1,000 per stranded passenger) (proposed threshold)
- Co-insurance threshold (e.g., carriers self-insure up to €50M annual pool draw, above which public or reinsurance cover applies) (proposed threshold)
- Contribution weights tied to controllable factors (on-time performance, booking-system availability) not forward-looking incident rates

Present this model to CER and the 10 largest carriers by Month 4 (2027-02-12) for binding commercial sign-off before standards are finalised. Establish a quarterly pool-monitoring process that publishes incident rates and contribution adjustments.

## Sensitivity

If the liability model is not agreed by Month 6 (2027-04-12), carriers face unpriceable risk and 30–40% (estimate) may refuse to expose inventory. This delays mandatory API exposure from Month 30 (2029-04-12) to Month 36 (2029-10-12) or later and reduces network coverage by 20–30% (estimate), pushing the 40% through-ticket goal to 15–25% (estimate). Cost impact: €100–150 million in lost programme value. Budget impact: funding for later corridors (Months 48–60 = 2030-10-12 to 2031-10-12) faces reallocation to cover smaller operator adapter overruns, compressing the full TEN-T rollout to Month 72–84 (2032-10-12 to 2033-10-12) instead of Month 60 (2031-10-12).

# Issue 2: Legacy System Integration Timeline and Adapter Costs Not Validated

## Background

The plan allocates €200–300 million (estimate) for conformance testing and carrier adapters to retrofit legacy booking systems to OSDM standards. A pre-programme technical audit of all 25+ operators' systems and realistic integration timelines per operator tier has not been conducted. Smaller carriers' systems may require 9–15 months of development per operator, not the 18–24 months between Month 12 (2027-10-12) and Month 30 (2029-04-12) mandatory exposure. Risk: adapters miss the Month 30 (2029-04-12) milestone, leaving 8–15 operators outside the network and fragmenting corridor coverage.

## Recommendation

Conduct a detailed technical audit of all participating carriers' booking-system architectures by Month 2 (2026-12-12), assessing API readiness, event-streaming capability, transaction consistency and on-time/availability data quality. Establish a per-operator conformance timeline (baseline, extended, advanced tiers) and publish it by Month 6 (2027-04-12). Allocate adapter funding in tranches:

- Tier 1 (large carriers, Month 30 = 2029-04-12): €80–100M (estimate)
- Tier 2 (regional, Month 36 = 2029-10-12): €80–100M (estimate)
- Tier 3 (small, Month 42 = 2030-04-12): €50–80M (estimate)

Require carriers in each tier to demonstrate API availability and booking-error rates (<1% stale-seat failures) before their tier release, not a one-time conformance gate.

## Sensitivity

If tier-based funding is not adopted and all carriers are held to a single Month 30 (2029-04-12) gate, 40–50% (estimate) of smaller and regional carriers miss the deadline by 6–12 months. This creates a 12–18 month delay in reaching full-corridor through-ticketing (from Month 48 = 2030-10-12 to Month 60–66 = 2031-10-12 to 2032-04-12). Budget impact: adapter overruns of €150–250 million (estimate) due to emergency acceleration, or alternatively, €200–300 million in unused budget if later corridors cannot launch. Network coverage drops from 25+ carriers to ~15 by Month 48 (2030-10-12), reducing the through-ticket share from 40% to 20–25% (estimate).

# Issue 3: Stakeholder Consensus Mechanism and Fallback Governance Not Defined

## Background

The plan requires binding decisions on liability (Decision 1), clearing architecture (Decision 2), public distributor role (Decision 3) and remuneration (Decision 12) by Month 6 (2027-04-12), involving 25+ carriers, CER, Trainline, Omio, BEUC, disability bodies and national regulators with conflicting interests. No formal consensus mechanism, escalation path or fallback governance is defined if a vote is deadlocked or a stakeholder withdraws. A single veto can block standards and push binding milestones from Month 18 (2028-04-12) to Month 24–30 (2028-10-12 to 2029-04-12).

## Recommendation

Establish a tiered governance structure by Month 1 (2026-11-12):

- Biweekly steering group of CER, DG MOVE, Agency, 3–4 major carriers (DB, SNCF, SBB, ÖBB or Renfe), Trainline, Omio, BEUC and one disability-rights body
- Voting rule requiring supermajority (75%) of steering members to approve Decisions 1, 2, 3, 12
- Formal escalation to the Commission Transport Commissioner if a vote does not reach 75% by Month 5 (2027-03-12), with Commission mediation required by Month 6 (2027-04-12)
- Fallback clause: if a major carrier (>5% of network) refuses a decision, the programme offers a technical fallback (e.g., bilateral clearing with netting, or a third-party settlement interface for distributors) rather than stalling the entire decision

Publish an option paper for each decision by Month 2 (2026-12-12) outlining three variants with trade-offs, so stakeholders see alternatives before voting.

## Sensitivity

If consensus is not reached by Month 9 (2027-07-12), binding standards are delayed from Month 18 (2028-04-12) to Month 24–30 (2028-10-12 to 2029-04-12), a 2–4 month slip (estimate). This cascades to mandatory API exposure (Month 30 = 2029-04-12 → Month 36 = 2029-10-12, estimate) and four-corridor go-live (Month 48 = 2030-10-12 → Month 54–60 = 2031-04-12 to 2031-10-12, estimate). If a major distributor (e.g., Trainline or Omio) rejects the clearing design, they withdraw from the programme, reducing available through-ticket volume by 15–25% (estimate), which lowers the 40% goal to 20–30%. Estimated cost to resolve deadlock: €10–20 million and 3–6 month delay.

# Review Conclusion

The programme's three most critical missing assumptions are:

- A published, actuarially validated carrier liability-pricing model specifying caps, co-insurance and contribution weights, absent by Month 3 (2027-01-12), which triggers carrier refusal and threatens network participation
- A pre-programme technical audit and per-operator tier-based adapter funding plan, absent which 40–50% of smaller carriers miss the Month 30 (2029-04-12) API exposure deadline and compress later-wave funding
- A formal multi-stakeholder consensus mechanism with escalation and fallback clauses, absent which deadlock on Decisions 1–3 delays binding standards by 2–4 months and cascades throughout the schedule

Each missing assumption poses a 15–25% risk to the 40% through-ticket goal and €100–250 million budget variance. Complete liability modelling by Month 3 (2027-01-12), conduct a technical audit by Month 2 (2026-12-12) and establish steering governance with published options by Month 2 (2026-12-12). These three workstreams must run in parallel Months 0–6 (2026-10-12 to 2027-04-12) to unlock the binding-standards pathway.