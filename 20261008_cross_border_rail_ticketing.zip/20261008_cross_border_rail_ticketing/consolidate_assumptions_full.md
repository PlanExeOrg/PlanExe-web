# Purpose

**Purpose:** business

**Purpose Detailed:** Public-sector, multi-stakeholder infrastructure and regulatory program led by EU institutions (DG MOVE, EU Agency for Railways) with national operators, distributors, regulators and consumer/disability bodies to establish technical standards (OSDM-compatible APIs), a shared real-time data layer, an inter-carrier clearing and settlement mechanism, a passenger-rights backstop, a public reference distributor and consumer-side rollout across European corridors over five years, funded by a €1.5 billion public coordination budget, with a separate estimate of private carrier IT investment. Goals: 40% of cross-border journeys sold as single through-tickets, halved distributor complaints, and modal shift from short-haul air to rail.

**Topic:** Coordinated European program for seamless cross-border rail through-ticketing (search, booking, refund) aligned with the EU proposed Regulation on Digital Booking and Ticketing Services for Rail

# Domain

**Primary domain:** Rail Ticketing Interoperability

**Secondary domains:** Transport Regulation, Public Program Management, Clearing And Settlement

**Rationale:** Rail Ticketing Interoperability is the outcome-role candidate with the highest importance × specificity (25) and names the program's core mechanism: OSDM-based cross-border through-ticketing. Transport Economics is a narrower outcome; Transport Regulation, Clearing And Settlement and API Standardization are constraints or methods.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Rail Ticketing Interoperability | 5 | 5 | outcome | Core mechanism: OSDM-based cross-border through-ticketing, distribution, clearing and refunds across carriers. |
| Transport Regulation | 5 | 4 | constraint | Program must align with proposed EU Regulation and passenger-rights and non-discrimination obligations. |
| Clearing And Settlement | 4 | 5 | method | Inter-carrier revenue clearing and single-payment settlement mechanism is a core build component. |
| Passenger Rights Law | 4 | 4 | constraint | Continuity-of-journey, refund harmonisation and rights backstop must satisfy EU passenger-rights rules. |
| API Standardization | 4 | 4 | method | OSDM-compatible real-time data layer needs binding standards, conformance testing and non-discriminatory access. |
| Transport Economics | 4 | 4 | outcome | Success depends on modal shift from short-haul air to rail and on fare and cost modelling. |
| Competition Law | 4 | 4 | constraint | Non-discriminatory distributor access and inter-carrier data and settlement arrangements raise EU competition issues. |
| Data Governance | 4 | 4 | method | The shared real-time data layer needs rules on access, data protection, quality and stewardship. |
| Public Program Management | 4 | 3 | method | Coordinating €1.5 billion multi-stakeholder rollout across member states, corridors and five-year milestones. |

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** This plan is a large, multi-stakeholder European public program to make cross-border rail through-ticketing work. Although a large share of the deliverables are digital (OSDM-compatible APIs, a shared real-time data layer, a clearing and settlement mechanism, a public reference booking app), the plan as a whole has clear and unavoidable physical requirements and benefits from physical presence in many ways: (1) Rollout is tied to real railway corridors (Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin) and later the full TEN-T network, which means real trains, stations, ticket offices, gates and on-board systems must be integrated, tested and operated. (2) Accessibility for persons with reduced mobility and bicycle reservations are physical-service requirements: they require assistance at stations, wheelchair spaces, and bicycle spaces on rolling stock, as well as coordination with disability-rights bodies. (3) The passenger-rights backstop and disruption handling relate to physical journeys, missed connections, rerouting, and staffed assistance at stations. (4) Integration hooks for buses, ferries and short-haul air connect to physical terminals and modal interchanges. (5) Conformance testing needs physical test environments, devices and real-world pilots on live corridors. (6) Governance involves in-person work among DG MOVE, the EU Agency for Railways, CER, national operators, regulators and consumer bodies, and member-state capacity building requires on-site training and workshops. (7) Delivery by carriers and the public reference distributor needs teams in physical offices and data centres, procurement of hardware, and consumer-side rollout (apps plus multilingual support, complaint handling, and station information). (8) Success is measured by changes in real-world travel behaviour, modal shift from short-haul flights to trains. The plan cannot be executed exclusively online, and it gains substantial benefit from physical locations and activities, so it is classified as physical.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Proximity to EU institutions (DG MOVE, EU Agency for Railways) for governance and standards work
- Access to priority corridors: Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin
- Secure data-centre and high-availability connectivity for the real-time data layer and clearing
- Test environments with access to live rolling stock, stations and gates for conformance pilots
- Easy access for national operators, CER, regulators, distributors and consumer/disability bodies
- Multilingual, skilled IT and financial-services workforce for clearing and distributor operations
- Competition-law-sensitive separation of the clearing function (clean-team arrangement)

## Location 1
Belgium

Brussels

European Quarter (DG MOVE, CER and BEUC offices) and Brussels-Midi/Bruxelles-Midi station area

**Rationale**: Seat of DG MOVE, CER and BEUC; central on the Paris–Brussels–Amsterdam–Köln corridor. Natural hub for governance, stakeholder coordination and the programme office.

## Location 2
France

Valenciennes / Lille area, Hauts-de-France

EU Agency for Railways headquarters (Valenciennes) with Lille-Europe station as corridor test access

**Rationale**: Hosts the EU Agency for Railways, which supervises standards, conformance testing and OSDM change control. Close to Paris–Brussels corridor trains for live pilots.

## Location 3
Germany / Switzerland / Austria

Berlin, Munich, Zürich and Wien corridor nodes

Operator IT and operations centres (e.g. Deutsche Bahn, SBB, ÖBB) along Wien–München–Zürich and Copenhagen–Hamburg–Berlin

**Rationale**: Large carrier IT and operations teams, OSDM expertise and busy cross-border corridors. Suited to conformance testing, carrier onboarding, clean-team clearing operations and the private concession for the last-resort distributor.

## Location 4
Spain / France

Madrid, Barcelona and Lyon

Renfe and SNCF operational hubs and stations on the Madrid–Barcelona–Lyon corridor

**Rationale**: Priority corridor with air competition and differing national systems; suited for pilots on through-ticketing, assistance and bicycle reservations, and modal-shift measurement.

## Location Summary
The programme is European-wide and tied to named rail corridors and EU institutions. Brussels is proposed as the governance and coordination hub, Valenciennes/Lille for the EU Agency for Railways and conformance work, German-speaking corridor nodes for carrier IT and clearing operations, and Madrid–Barcelona–Lyon for air-competitive corridor pilots.

# Currency Strategy

This plan involves money.

## Currencies

- **EUR:** Primary currency for all public coordination budget (€1.5 billion user constraint), standards work, conformance testing, clearing mechanism, public reference distributor and member-state capacity building across the EU. All four priority corridors and the full TEN-T network are within the Eurozone or countries with direct EUR integration (Belgium, France, Germany, Austria, Switzerland via bilateral arrangements). Simplifies settlement within the inter-carrier clearing layer and avoids hedging costs on the majority of transactions.
- **GBP:** Secondary consideration for any post-delivery integration with UK rail operators or distributors (Trainline, National Rail) should the scope extend beyond the initial EU-25 to include cross-Channel services. Not in immediate scope but may arise during corridor extension phases. Mark as optional pending regulatory evolution.

**Primary currency:** EUR

**Currency strategy:** The public coordination budget of €1.5 billion (user constraint) is disbursed entirely in EUR through tranches tied to verified technical milestones (conformance certificates, live API exposure, corridor go-live). All clearing, settlement and inter-carrier netting occurs in EUR to eliminate foreign-exchange friction in the clearing mechanism and preserve the fixed public budget from exchange volatility. The carrier-funded mutual guarantee pool for through-ticket liability contributes and draws in EUR, and the tendered last-resort distributor concession operates in EUR. Private carrier IT investment is estimated separately and may be denominated locally by each carrier, but all inter-carrier transactions flow through EUR settlement. If future corridor extensions reach non-Eurozone members (e.g., Sweden, Denmark, Poland), a secondary hedging strategy using corridor-specific bilateral forward contracts may be needed, but this is not in scope for the initial five-year horizon.

# Identify Risks


## Risk 1 - Regulatory & Legislative
The proposed EU Regulation on Digital Booking and Ticketing Services for Rail (Commission proposal status not fully verified; as of October 2026, adoption timeline uncertain) may face parliamentary opposition, be substantially amended, or stall in Council negotiations. If the Regulation is delayed beyond Month 18 (2028-04-12), the binding-standards deadline becomes unachievable and carriers lose the legal mandate to expose inventory through OSDM APIs. If the Regulation is watered down or sets weaker conformance requirements, smaller carriers may remain outside the network, fragmenting the corridor coverage.

**Impact:** A 12–18 month delay in Regulation adoption could push binding standards from Month 18 (2028-04-12) to Month 30 (2029-04-12) or later, cascading the mandatory API exposure milestone and full corridor go-live. Weaker requirements could reduce participating carriers from the target 25+ to 15–20, leaving gaps in less commercially attractive corridors (e.g., Baltic routes) and lowering the through-ticket share from the 40% goal to 25–30%. Budget reallocation to fill coverage gaps could consume €200–400 million of the fixed €1.5 billion.

**Likelihood:** Medium

**Severity:** High

**Action:** Secure formal legal assurance from the Commission's legislative affairs unit that the Regulation will be tabled by Month 6 (2027-04-12) and adopted by Month 18 (2028-04-12), with binding-standards triggers contingent on publication in the Official Journal. Maintain a shadow legislative workstream that documents compliance with the Regulation's requirements as they evolve, so that standards and conformance tests do not depend on a finalised text. Establish contingency corridor definitions that include smaller operators earlier if coverage risk emerges.

## Risk 2 - Technical & Systems Integration
Legacy booking systems operated by smaller carriers (e.g., regional operators in CEE, the Balkans, Spain and Portugal) cannot be retrofitted to expose real-time availability through OSDM-compatible APIs within the Month 30 (2029-04-12) mandatory exposure deadline. Older systems may lack the architecture for event streaming, federated queries or transactional consistency required by the shared real-time layer. Integration adapters (funded from the €1.5 billion budget under the Conformance Gate decision) may be delayed or require longer development cycles than scheduled.

**Impact:** Smaller carriers may miss the Month 30 (2029-04-12) conformance deadline by 2–4 quarters, leaving 8–15 operators outside the network at critical corridor junctions (e.g., Austrian and Czech operators on the Wien–München corridor, Iberian regional carriers). This fragments the through-ticket path and forces passengers to stitch itineraries manually at borders. Estimated cost overrun to accelerate adapters: €150–250 million. Delay in full TEN-T rollout: 12–24 months beyond Month 60 (2031-10-12).

**Likelihood:** High

**Severity:** High

**Action:** Initiate a pre-programme technical audit of all participating carriers' booking-system architectures (by Month 2 = 2026-12-12) to identify retrofit bottlenecks and establish realistic Month 30 (2029-04-12) conformance timelines per operator. Co-fund shared adapter modules (middleware bridging legacy systems to OSDM) via the Conformance Gate and Carrier Onboarding Support decision, allocating €200–300 million of the public budget to this layer. Tier conformance into baseline (Month 30 = 2029-04-12), extended (Month 36 = 2029-10-12) and advanced (Month 42 = 2030-04-12) phases, releasing funding tranches based on verifiable API availability and booking-error rates rather than a one-time gate.

## Risk 3 - Commercial & Carrier Incentives
Carriers refuse to expose inventory and accept through-ticket connection liability because the liability backstop (Decision 1) and clearing mechanism (Decision 2) leave them unable to price the shared exposure to missed-connection delays and rerouting costs. If the carrier-funded mutual guarantee pool is weighted solely on incident rates, carriers face unpredictable exposure linked to operational performance they do not fully control (e.g., SBB delays caused by SNCF congestion). Without a clear liability cap or insurance backstop, large carriers (DB, SNCF, RZD) may refuse to expose seats and restrict sales to their own channels.

**Impact:** If 30% of expected carriers (i.e., 7–8 major operators) refuse to participate, the through-ticket network loses coverage on critical corridors: the Köln–Amsterdam leg becomes unavailable, the München–Zürich corridor is fragmented, and the Madrid–Barcelona–Lyon route loses a key connector. Estimated impact: a 3–5 quarter delay in reaching the mandatory API exposure milestone (Month 30 = 2029-04-12), pushing full corridor through-ticketing to Month 72 (2032-10-12) or beyond. The 40% through-ticket goal becomes unachievable; realistic outcome is 15–20%.

**Likelihood:** High

**Severity:** High

**Action:** Complete the Through-Ticket Liability and Rights Backstop decision by Month 3 (2027-01-12) with a published carrier risk-allocation model that specifies: (a) maximum carrier exposure per incident (e.g., capped at €X per missed connection + rerouting costs), (b) insurance or co-insurance for exposure above the cap, and (c) contribution-weighting rules tied to controllable factors (e.g., on-time performance in the 12 months prior, not forward-looking incident rates). Present this model to CER and the largest 10 carriers by Month 4 (2027-02-12) for binding commercial sign-off before standards are finalised. Establish a separate technical working group to model cash flows for the carrier-funded guarantee pool, so carriers see realistic annual contribution ranges before Month 6 (2027-04-12).

## Risk 4 - Financial & Budget
The €1.5 billion public coordination budget (user constraint) is allocated across standards work (€50–100 million), the clearing and settlement mechanism (€200–300 million), the public reference distributor concession (€300–500 million over five years), member-state capacity building (€200–300 million), conformance testing and carrier adapters (€200–300 million) and consumer rollout (€100–150 million), leaving little contingency. If the carrier-funded guarantee pool experiences a major incident surge (e.g., weather, labour strikes or a corridor-wide incident affecting thousands of passengers), the pool drains faster than projected and the Commission faces pressure to top it up from the public budget. Similarly, if the public distributor concession runs deeper operating losses than forecast (e.g., lower through-ticket volumes, higher payment processing and customer-service costs), the contract may require subsidy beyond the tendered allocation.

**Impact:** A €100–200 million draw on the public budget to cover guarantee-pool or distributor deficits in years 2–3 leaves only €100–200 million for the final-wave TEN-T extension (planned for Month 48–60 = 2030-10-12 to 2031-10-12), essentially cancelling the full-network rollout. This cuts the through-ticket goal from 40% to ~25%, primarily covering the four priority corridors. Member-state capacity building is cut by 30–50%, leaving smaller MS without training or testing resources.

**Likelihood:** Medium

**Severity:** High

**Action:** Commission an independent actuarial study of the carrier-funded guarantee pool (by Month 6 = 2027-04-12) with confidence intervals on missed-connection rates, rerouting costs and incident clustering. Establish a reserve fund of €150–200 million (drawn from the public budget allocation) earmarked for pool top-ups only in the case of force-majeure incidents (single-day corridor-wide disruptions affecting >5,000 passengers). For the public distributor concession, require monthly financial reporting and a trigger clause for subsidy increases if volumes fall below 60% of the forecast; if triggered, scale back the rollout to the four priority corridors and extend Month 60 (2031-10-12) completion to Month 72 (2032-10-12). Establish a policy with the Commission and the European Court of Auditors that public budget draw-downs on carrier pools beyond Month 36 (2029-10-12) will not occur, forcing recalibration of pool contributions or carrier participation instead.

## Risk 5 - Governance & Stakeholder Coordination
The program involves DG MOVE, the EU Agency for Railways, CER, 25+ national operators, independent distributors (Trainline, Omio), national regulators, BEUC and disability-rights bodies. Alignment on the Through-Ticket Liability (Decision 1), Inter-Carrier Clearing (Decision 2) and Public Reference Distributor Mandate (Decision 3) decisions by Month 3–6 (2027-01-12 to 2027-04-12) requires consensus among parties with conflicting interests. CER and large carriers favour bilateral clearing and distributed liability; independent distributors demand a single clearing entity and a public guarantee; disability bodies require accessible, auditable assistance booking. Failure to secure consensus delays decisions, leaving the standards-working group without a liability model or clearing architecture to build against.

**Impact:** If consensus is not reached by Month 9 (2027-07-12), the binding-standards milestone (Month 18 = 2028-04-12) is at risk because standards-working groups cannot finalise specifications without knowing the liability allocation and clearing rulebook. Estimated delay: 2–4 months. Additionally, if independent distributors reject the final clearing design, they may legally challenge it or withdraw, reducing the through-ticket volume available to passengers by 20–30% (Trainline and Omio account for a significant share of cross-border searches).

**Likelihood:** Medium

**Severity:** High

**Action:** Establish a dedicated governance layer within the Programme Office (by Month 1 = 2026-11-12) with biweekly steering meetings of the key stakeholders (CER, DG MOVE, Agency for Railways, 3–4 major carriers, Trainline, Omio, BEUC, a national disability body and a representative national regulator). Issue a non-binding position paper by Month 2 (2026-12-12) outlining three options for each critical decision (Decisions 1, 2, 3) with trade-offs clearly stated. Require binding votes on the final decisions by Month 6 (2027-04-12), with Commission mediation available if a vote is deadlocked. For distributors that reject the clearing design, negotiate a fallback technical interface that allows them to settle through a third party (e.g., a payment provider) rather than the central clearing layer, preserving their participation.

## Risk 6 - Competition Law & Regulatory
The Inter-Carrier Clearing and Single-Payment Settlement (Decision 2) and Distribution Remuneration and Commission Corridor (Decision 12) mechanisms involve competitors (25+ carriers, multiple distributors) exchanging commercially sensitive data (fares, inventory, settlement data) and potentially agreeing on commission rates or fare-construction rules. These arrangements could be viewed as prohibited coordination under Article 101 TFEU. The programme relies on the Joint Conduct Safe-Harbour for Shared Data and Clearing (Decision 14) decision to secure Commission comfort before binding standards are finalised (Month 18 = 2028-04-12). If comfort is not obtained in time, or if a future challenge unwinds the clearing arrangements, carriers will not commit real-time inventory and the through-ticket network collapses.

**Impact:** A competition-law challenge after Month 24 (2028-10-12) could force the programme to restructure the clearing mechanism and data-sharing layer, requiring 6–12 months of legal work and technical rework. Estimated cost: €50–100 million. If the challenge succeeds, the programme loses the centralised clearing or data layer, reverting to bilateral settlement and federated inventory queries, which add 3–4 months to settlement cycle times and increase booking-error rates by 15–25%, eroding the through-ticket value proposition.

**Likelihood:** Medium

**Severity:** High

**Action:** Initiate formal pre-notification with the Commission's Directorate for Competition (DG COMP) by Month 2 (2026-12-12), before any technical specifications are fixed. Request a formal guidance letter (under Commission competition procedure) by Month 12 (2027-10-12) that confirms the clearing and data-sharing arrangements as compatible with Article 101 TFEU, conditioned on the specific design choices made. If DG COMP indicates concerns, establish a clean-team arrangement (Decision 14, option 3) whereby the clearing function operates behind firewalls and releases only aggregated settlement data to carriers, not their competitors' fares or inventory. Ensure this arrangement is documented and signed off by DG COMP before Month 18 (2028-04-12).

## Risk 7 - Technical & Data Quality
The Availability Query Topology and Authoritative Booking Source (Decision 5, pragmatic option) relies on a streamed availability shadow (cached search layer) and carrier booking-engine authority. If carriers' booking engines are unavailable or respond slowly (>5 seconds), the system degrades to scheduled-only offers, which breaks through-ticketing (a passenger cannot book a through-ticket on a train that is not scheduled yet; real-time seat inventory is required). Legacy carrier systems, particularly smaller operators, often have 5–15 second query latency and 2–4 hour outages per month. Multiplicative latency and availability risk: a three-leg through-ticket requires three queries, so if each has 95% availability, the combined through-ticket availability is ~86%, not acceptable.

**Impact:** If carrier booking engines fail to meet <2 second latency and 99.5% availability targets, through-ticket search success rates fall to 70–80%, and the fallback to scheduled-only offers removes the commercial advantage of through-ticketing. Passengers revert to stitching itineraries manually or using single-carrier tools. Estimated impact: 30–50% lower through-ticket volume than forecast, pushing the 40% goal to 20–25%.

**Likelihood:** High

**Severity:** Medium

**Action:** Establish strict SLA targets for carrier booking-engine latency (<2 seconds per query, p95) and availability (99.5%) as part of the conformance gate (Decision 6). Build a monitored availability proxy that tracks each carrier's latency and availability in real time (Month 12 = 2027-10-12 onwards) and publishes a monthly scorecard. Attach tranches of the Milestone-Conditioned Funding Release Ladder (Decision 4) to carriers meeting these SLAs: carriers that miss SLAs in two consecutive months lose a portion of their next funding tranche. Concurrently, fund a lightweight caching layer (distributed, not central, to avoid a single point of failure) that holds recent search results and degrades gracefully to cached results if a carrier endpoint fails, so that scheduled offers are available at all times even if real-time inventory is not.

## Risk 8 - Operational & Service Delivery
The Disruption Re-accommodation Choreography (Decision 9) and Assistance and Bicycle Reservation Chaining (Decision 10) require real-time, coordinated action across carrier networks: detecting a missed connection, proposing alternatives on competitors' trains, securing seats and confirming reroutes within minutes. This depends on shared operational data (train delays, seat inventory) that carriers have historically guarded and on staff at stations and onboard who are trained to recognise across-carrier re-accommodation and accessible reservations. Smaller operators may lack 24/7 customer-service centres or English-speaking staff at border stations. A missed connection during night hours or a weekend may go undetected for hours.

**Impact:** If re-accommodation response times exceed 30–60 minutes, or if passengers are not re-accommodated at all (e.g., left stranded at a border station overnight), the program faces public backlash and liability claims. Estimated cost: €10–20 million in compensation and reputation damage per major incident. If assistance requests (wheelchairs, service animals, reduced-mobility support) are delayed or unfulfilled due to staffing or coordination gaps, the programme violates accessibility law (EU Regulation 1371/2007) and faces complaints to national regulators. Disruption handling failures could reduce through-ticket adoption by 10–20% due to passenger loss of trust.

**Likelihood:** Medium

**Severity:** High

**Action:** Develop a detailed operational manual for all participating carriers by Month 9 (2027-07-12) covering missed-connection detection, re-accommodation procedures, seat-access protocols, assistance escalation and passenger communication at border stations. Conduct live pilots on each of the four priority corridors (Month 12–18 = 2027-10-12 to 2028-04-12) with 500–1,000 passengers per corridor, measuring response times, reroute success and passenger satisfaction. Use pilot results to calibrate SLAs (e.g., re-accommodation decision within 15 minutes, assistance confirmation within 30 minutes) and incorporate them into carrier conformance gates. Require carriers to establish 24/7 customer-service centres and train staff at key border stations (at least one English-speaking agent at each) as a precondition of conformance certification by Month 30 (2029-04-12). Fund capacity-building and staff training through the member-state capacity-building budget (€200–300 million allocation within the €1.5 billion).

## Risk 9 - Technical & Systems Integration
The Ticket Validation and Onboard Inspection Interoperability (Decision 13) decision requires every train crew member, station agent and gate system on participating corridors to accept and validate through-tickets issued by any participating carrier. The pragmatic approach (hybrid credentials or API handshakes) is slower than a single-format mandate but avoids the cost and schedule risk of retrofitting handheld devices and gates on 1,000+ trains across four carriers. If carrier IT teams fail to implement the API handshake or hybrid credential format by Month 30 (2029-04-12), conductors and station agents have no way to validate across-carrier tickets, and manual workarounds (checking papers, holding passengers) reappear, eroding the through-ticket value.

**Impact:** If even 20% of corridor vehicles lack proper validation capability by Month 60 (2031-10-12), passengers face validation disputes, penalties and delays at stations, degrading the through-ticket experience. Estimated impact: 5–10% reduction in through-ticket adoption due to trust loss. If a validation failure leads to a passenger boarding a train without a valid ticket due to system incompatibility, the carrier faces a regulatory fine and reputational damage.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Specify the API handshake or hybrid credential format as part of the OSDM standard by Month 6 (2027-04-12) and include it in conformance tests (Decision 6). Require all carriers to deploy validation capability to all corridor rolling stock and key stations by Month 40 (2030-02-12) (10 months before full corridor go-live), with intermediate audits at Month 30 (2029-04-12) and Month 35 (2029-09-12). Tie funding tranches (Decision 4) to validation rollout milestones: carriers that fall 2+ months behind in validation deployment lose their next funding tranche. Fund a small team of on-site validation testers at each priority corridor (Month 24 = 2028-10-12 onwards) to conduct monthly audits of handheld and gate compatibility, publishing a publicly available scoreboard.

## Risk 10 - Market & Competitive
The Air-to-Rail Competitiveness Package (Decision 7) aims to shift passengers from short-haul flights to rail through through-ticketing, intermodal products and information. However, the program has limited direct control over carrier pricing (through-fare construction is a carrier-led negotiation in Decision 8) and cannot control flight-operator pricing or schedule changes. If flight operators respond to increased rail competition by cutting fares on competitive routes to €20–40 one-way (which is commercially viable given lower fuel and staff costs), rail through-fares will struggle to compete even with the convenience factor. Additionally, passengers' modal choice depends on total journey time (including airport check-in and security), which the program does not control.

**Impact:** If modal shift from air to rail is slower than forecast (e.g., 5–10% instead of 15–20%), the 40% through-ticket goal is reached but the headline outcome—'fewer travellers choose the plane'—is not achieved, creating a political narrative of programme failure despite 40% penetration. The program may face pressure to shift funding toward price subsidies for rail, draining the fixed €1.5 billion budget.

**Likelihood:** Medium

**Severity:** Low

**Action:** Conduct a baseline modal-shift study by Month 6 (2027-04-12) measuring current air-to-rail ratios on the four priority corridors and the impact of through-ticketing, intermodal information and journey-time visibility on booking behaviour. Establish conservative modal-shift targets tied to through-ticketing availability, not price, so that the programme success is measured by through-ticket penetration and complaint reduction, not flight-passenger reduction. In the Air-to-Rail Competitiveness Package decision, focus on display neutrality and journey-time information (low cost) rather than fare commitments, which create subsidy dependencies. If modal shift is slower than forecast, use Month 48 (2030-10-12) evaluation findings to adjust the tone of programme communications, emphasizing convenience and reliability over environmental or air-replacement goals.

## Risk 11 - Physical & Logistical
The programme is distributed across four member states (Belgium, France, Germany, Austria/Switzerland, Spain) with programme offices in Brussels, Valenciennes, Berlin and Madrid. Coordination across time zones, languages and national regulatory environments adds overhead. The EU Agency for Railways is in Valenciennes, far from Brussels (Commission HQ) and from the largest carrier IT centres (Berlin, Munich, Zurich). Travel time, visa requirements for non-EU staff and local staffing constraints can slow governance meetings and technical working groups.

**Impact:** Coordination delays, particularly in standards-working groups and conformance testing, could add 1–2 months to binding-standards and mandatory API exposure milestones. Estimated cost of additional coordination: €5–10 million in staff travel and extended contracts.

**Likelihood:** Low

**Severity:** Low

**Action:** Establish a virtual-first governance model with scheduled in-person meetings only for critical decisions (Decisions 1–5, competition-law clearance). Use video conferencing for biweekly steering and technical working groups. Rotate in-person meetings between Brussels, Valenciennes and a carrier IT hub (Berlin or Munich) on a quarterly cycle, with participation costs covered by the programme budget. Hire at least one full-time liaison officer based in each of the four physical locations (Brussels, Valenciennes, Berlin, Madrid) to support async coordination and local stakeholder engagement.

## Risk 12 - Regulatory & Policy
National railway regulators (e.g., ORE in France, BNetzA in Germany, NaBB in Austria) retain authority over track access, station capacity and pricing in their respective territories. The programme's binding standards and mandatory API exposure may conflict with existing national regulations or incumbent operator privileges. For example, a mandate to share real-time inventory through a central or federated layer could trigger concerns about incumbent cost-shifting or non-discriminatory access. If a national regulator blocks the programme's data-sharing or clearing arrangements on competition or incumbent-protection grounds, the programme cannot proceed in that member state.

**Impact:** If one major corridor (e.g., the Wien–München–Zürich or the Paris–Brussels–Amsterdam–Köln route) loses a national regulator's approval, the through-ticket network is fragmented and the corridor is blocked for 12–24 months while regulatory issues are resolved. Estimated impact: delay in mandatory API exposure milestone of 6–12 months and a reduction in through-ticket reach of 20–30%.

**Likelihood:** Medium

**Severity:** High

**Action:** By Month 3 (2027-01-12), the DG MOVE and the EU Agency for Railways must conduct bilateral engagement with each national regulator on the programme's scope, data-sharing arrangements and competition-law compliance. Prepare a regulatory-impact assessment for each member state that identifies potential conflicts with national law. If conflicts are identified, work with national regulators to adapt the programme design or secure regulatory waivers by Month 12 (2027-10-12). Include national regulators as observers in the standards-working groups so they can flag regulatory constraints early. If a regulator's concerns cannot be resolved by Month 12 (2027-10-12), consider deferring that member state's participation to a Phase 2 rollout (Month 60 = 2031-10-12 onwards) rather than the four priority corridors.

## Risk 13 - Accessibility & Inclusivity
The Assistance and Bicycle Reservation Chaining (Decision 10) aims to make through-tickets accessible for persons with reduced mobility (PRM) and cyclists. However, compliance depends on carriers to provide wheelchair spaces, assistance at stations and onboard staff training. Rolling stock ages and accessibility standards vary widely across operators (e.g., older trainsets on regional routes may have no wheelchair spaces). Atomic confirmation of assistance and bicycle reservations as part of the through-ticket booking means that itineraries without available spaces are refused, reducing the volume of through-tickets available to these passenger groups and potentially creating legal exposure under EU Regulation 1371/2007 (railway passengers' rights) and the Accessibility Directive.

**Impact:** If participating carriers cannot guarantee assistance or bicycle space on 50%+ of through-ticket itineraries, the programme risks legal complaints to national regulators and the European Court of Justice. Alternatively, if atomic confirmation is dropped in favour of 'best-effort' booking, passengers are left uncertain whether they will have access at journey time, eroding trust. Estimated reputational and legal cost: €20–50 million.

**Likelihood:** Medium

**Severity:** Medium

**Action:** By Month 6 (2027-04-12), require all participating carriers to publish their rolling-stock accessibility inventory (wheelchair spaces, assistance availability, onboard staff language skills) for each service on the priority corridors. Establish minimum accessibility levels (e.g., wheelchair access on ≥80% of services, assistance availability with ≤4 hours' notice on ≥90% of services) as a precondition of conformance (Decision 6). For carriers unable to meet these levels by Month 40 (2030-02-12), allow a fallback to 'best-effort' booking with transparent communication to passengers (e.g., 'wheelchair space availability uncertain; you will receive confirmation 48 hours before departure'). Engage disability-rights bodies (e.g., EBU) as observers in the Assistance and Bicycle Reservation Chaining working group and conduct usability testing with PRM passengers by Month 18 (2028-04-12). Fund accessibility infrastructure improvements (rolling-stock retrofits, station accessibility) through member-state capacity-building budget if carriers cannot self-fund.

## Risk 14 - Financial & Budget
The Public Reference Distributor Mandate (Decision 3, pragmatic option: tendered last-resort concession) requires the Commission to contract a private operator to run a last-resort sales channel. The concession contract must specify service levels (availability, booking success, complaint resolution time), volume targets and subsidy triggers. If the concessionaire overstates their cost efficiency, the contract runs into operating losses within 18–24 months and requests subsidy increases from the €1.5 billion budget. Alternatively, if volume forecast is too optimistic, the concessionaire operates at a loss and may withdraw, leaving the Commission without a last-resort channel.

**Impact:** If the concessionaire withdraws by Month 36 (2029-10-12) or requests a subsidy increase >€50 million, the Commission must either operate the distributor directly (consuming staff and overhead) or leave the last-resort role unfilled, which undermines the programme's claim to provide a neutral channel. Estimated risk: €75–150 million in subsidy overrun or €30–50 million in government operating costs to take over directly.

**Likelihood:** Medium

**Severity:** Medium

**Action:** By Month 9 (2027-07-12), the Commission must develop a detailed business case for the public distributor concession, including volume forecasts, cost benchmarks (from Trainline, Omio and carrier apps) and margin assumptions. Issue a competitive tender for the concession by Month 12 (2027-10-12) with a two-stage evaluation: (a) technical requirements (system architecture, compliance with OSDM, accessibility, multilingual support) and (b) financial viability (total cost of ownership, subsidy threshold). Cap the initial subsidy at €60 million over five years and include a clawback clause: if through-ticket volumes exceed forecast by >20%, the concessionaire must rebate surplus fees to the Commission. Require the concessionaire to publish quarterly financial reports and trigger a contract review if operating costs exceed budget by >15% in any quarter.

## Risk 15 - Technical & Data Quality
The Inter-Carrier Clearing and Single-Payment Settlement (Decision 2, pragmatic option: federated layer) depends on carriers submitting consistent, timely settlement data (fares, refunds, reroute costs, commission splits). If carriers' financial systems use different formats, currencies or accounting methods, reconciliation is slow and error-prone. A 2–3% reconciliation error rate (which is typical in financial services) translates to thousands of disputed transactions per month, overwhelming dispute-resolution capacity and delaying payouts to distributors.

**Impact:** If reconciliation error rates exceed 2%, settlement cycle times lengthen from the targeted 5 business days to 10–15 days, cash flow friction increases for distributors, and distributor complaints about delayed payouts rise. Estimated impact: 15–20% of distributors may reduce their participation in through-ticket sales due to cash-flow concerns, lowering through-ticket volume by 10–15%.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish a detailed data-format standard for settlement feeds (fares, refunds, reroute costs, commission) as part of the OSDM specification by Month 6 (2027-04-12). Require all carriers to submit settlement data in the standard format via a validated API by Month 24 (2028-10-12), with test environments available from Month 12 (2027-10-12) onwards. Fund a shared reconciliation platform (part of the clearing mechanism budget) that automates basic matching and flags mismatches for manual review. Set a target reconciliation error rate of <0.5% by Month 30 (2029-04-12), with automatic penalties for carriers exceeding 1% error rates in any month (e.g., 0.1% reduction in their next funding tranche).

## Risk 16 - Operational & Service Delivery
Member-state capacity building (€200–300 million allocation within the €1.5 billion budget) is required to train national railway operators, regulators and consumer bodies on the new standards, systems and passenger-rights procedures. Smaller member states (e.g., Baltic countries, Luxembourg, Cyprus) may lack in-country expertise and depend on external training from the EU Agency for Railways or contractors. If capacity building is delayed or under-resourced, local operators and regulators may not meet the mandatory API exposure or conformance milestones, delaying the full TEN-T rollout.

**Impact:** A 6–9 month delay in capacity building for smaller member states could push their participation in the full TEN-T rollout from Month 60 (2031-10-12) to Month 72 (2032-10-12) or later. This fragments the pan-European through-ticket coverage and reduces the overall through-ticket share from 40% to 30–35%.

**Likelihood:** Low

**Severity:** Medium

**Action:** Allocate €30–50 million of the capacity-building budget specifically for external training programs, delivered by the EU Agency for Railways or contracted trainers, targeting smaller member states and less-resourced operators. Establish regional training hubs in Brussels, Valenciennes, Berlin and one southern hub (e.g., Madrid or Rome) so that training is accessible without extensive travel. Conduct a skills audit by Month 6 (2027-04-12) to identify member states with capacity gaps and tailor training curricula. Schedule intensive training programs (2–3 weeks per operator) at Month 18–24 (2028-04-12 to 2028-10-12) to coincide with the binding-standards deadline, so operators can begin implementation planning immediately after training.

## Risk 17 - Regulatory & Policy
The programme's success relies on attracting independent distributors (Trainline, Omio and smaller platforms) to integrate with the shared real-time data layer and clearing mechanism. The Distribution Remuneration and Commission Corridor (Decision 12) sets the terms under which carriers pay distributors per through-ticket sold. If the negotiated commission rates are too low, distributors reduce their investment in through-ticket search and promotions; if too high, carriers view through-distribution as unprofitable and restrict inventory access. A misstep in commission design can fracture the distributor ecosystem and lower through-ticket sales.

**Impact:** If commission rates are set below distributors' cost of acquisition and support (typically 3–5% of fare), large independents (Trainline, Omio) may deprioritise the programme's through-tickets in their search results and marketing, reducing through-ticket volume by 20–30%. Alternatively, if rates are set above 5%, smaller distributors and new entrants cannot sustain a business, and the market consolidates to incumbents, reducing competition and innovation. Estimated impact: 15–20% reduction in through-ticket share if either scenario occurs.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Commission an industry survey by Month 3 (2027-01-12) of Trainline, Omio and 5–10 smaller distributors to establish their cost of acquisition, customer support and payment processing for cross-border through-tickets. Use this data to establish a commission-rate band (e.g., 2.5–4.5% of through-fare) that covers distributors' costs while allowing carriers margins. Include the band in the Distribution Remuneration and Commission Corridor decision (Decision 12) by Month 9 (2027-07-12). Require the clearing function to publish monthly commission-rate data by distributor type and check for discrimination; publish results quarterly. If a distributor claims discrimination, require a mediated review with the Agency for Railways before Month 30 (2029-04-12).

## Risk 18 - Technical & Systems Integration
The Specification Custodian Seat for OSDM Evolution (Decision 11, pragmatic option: Agency for Railways anchoring with an escrowed open-source reference implementation) requires a formal, published change-control process for the OSDM specification. If the process is too slow (e.g., change requests take 3–6 months to be reviewed and approved), carriers and distributors may fork the specification or apply proprietary extensions, fragmenting the ecosystem. If the process is too fast (e.g., changes approved in weeks), carriers with legacy systems struggle to keep pace and integration failures emerge.

**Impact:** If the specification forks or diverges significantly from carriers' implementations by Month 42 (2030-04-12), conformance testing becomes ambiguous and the mandatory API exposure milestone is delayed or fails. Estimated delay: 3–6 months. A slow change process (>2 month review cycles) could delay critical bug fixes or security updates by 6–9 months, creating vulnerability windows.

**Likelihood:** Low

**Severity:** Medium

**Action:** Establish the OSDM change-control process as part of the Agency for Railways mandate by Month 3 (2027-01-12), with published criteria for change request severity (critical: security/safety; major: functional gaps; minor: optimisations), review timelines (critical: 2 weeks; major: 6 weeks; minor: 8 weeks) and approval gates (technical review by at least 3 independent carriers, competition-law check for sensitive changes). Publish a quarterly release cadence so carriers can plan integration work. Archive all historical versions in an open-source repository with escrowed backups, so carriers can fork if needed. Establish a change-request dashboard showing pending and approved changes, helping carriers plan their implementation roadmaps.

## Risk 19 - Compliance & Legal
Passenger rights on cross-border rail journeys are governed by EU Regulation 1371/2007 (railway passengers' rights), which covers compensation, assistance and liability for operators. The Through-Ticket Liability and Rights Backstop (Decision 1) and Disruption Re-accommodation Choreography (Decision 9) must ensure that a through-ticket passenger has equivalent rights regardless of the number of carriers involved. If the programme's rights backstop and liability rules are less generous than Regulation 1371/2007 or create gaps, passengers may lose rights and the programme faces regulatory complaints.

**Impact:** If passengers lose rights (e.g., compensation for delays due to an unclear liability allocation), the EU Agency for Railways or national regulators may issue enforcement notices, forcing the programme to redesign the liability and disruption-handling rules, delaying implementation by 3–6 months. Estimated cost: €10–20 million in legal work and programme redesign.

**Likelihood:** Low

**Severity:** Medium

**Action:** By Month 3 (2027-01-12), commission an independent legal review of the Through-Ticket Liability and Rights Backstop (Decision 1) design against EU Regulation 1371/2007, ensuring that through-ticket passengers have equivalent or better rights than single-carrier passengers. Publish the legal opinion and any required design adjustments by Month 6 (2027-04-12). Ensure that the Disruption Re-accommodation Choreography (Decision 9) operating manual includes step-by-step procedures for compensation claims, assistance and liability that comply with Regulation 1371/2007. Submit the manual to the EU Agency for Railways for formal review and approval by Month 9 (2027-07-12) before carrier pilots begin.

## Risk 20 - Organizational & Governance
The programme requires a Programme Office (within DG MOVE) and a Technical Secretariat (within or supporting the EU Agency for Railways) to coordinate standards work, conformance testing, funding releases and stakeholder engagement across five years and four locations. Programme staff turnover, particularly in leadership roles, can disrupt continuity and delay decision-making. Additionally, if the Programme Office lacks clear authority over budget releases or standards-working groups, carrier and distributor consensus becomes harder to achieve.

**Impact:** A change in Programme Director or Technical Lead at critical junctures (e.g., Month 12–18 = 2027-10-12 to 2028-04-12 for binding standards, Month 24–30 = 2028-10-12 to 2029-04-12 for API exposure) could add 2–3 months of ramp-up time and defer milestones. If the Programme Office cannot enforce milestone conditions (e.g., conformance certificates before funding release), compliance will drop and the schedule will slip. Estimated cost: €5–10 million in extended programme management and consultant engagement.

**Likelihood:** Medium

**Severity:** Low

**Action:** By Month 1 (2026-11-12), the Commission must formally establish the Programme Office and Technical Secretariat with clear governance (reporting lines, decision authority), a multi-year budget (€50–100 million for programme management) and retention incentives for key staff (e.g., 3–5 year appointments with continuity clauses). Define success milestones and annual review cycles so that leadership changes are planned at low-risk points (e.g., after month 12 = 2027-10-12, month 36 = 2029-10-12 reports). Establish an advisory board of external experts (from carriers, distributors and academics) to provide independent oversight and escalation paths if the Programme Office is blocked by stakeholders.

## Risk summary
This is a large, multi-stakeholder public infrastructure program spanning five years, four priority corridors and the full TEN-T network. It layers shared standards (OSDM-compatible APIs, clearing, rights backstop) over existing national carrier systems to enable seamless cross-border rail through-ticketing. The program operates under a fixed €1.5 billion public coordination budget (user constraint) and faces three interconnected critical risks: (1) Carrier unwillingness to expose inventory and accept connection liability unless the backstop design and clearing mechanism guarantee they can price the risk fairly—blocking the binding-standards milestone if not resolved by Month 18 (2028-04-12); (2) Legacy IT integration delays and conformance failures on priority corridors, particularly with smaller operators' systems, which could push the mandatory API exposure milestone (Month 30 = 2029-04-12) into the later quarters and starve funding for subsequent corridors; (3) Budget exhaustion if the carrier-funded guarantee pool drains faster than projected or the public distributor concession runs deeper deficits, cutting funding for member-state capacity building and reducing the likelihood of the 40% through-ticket goal. The regulatory and competition-law pathway is complex, with a Regulation proposal in Commission hands (not fully verified) and Article 101 TFEU clearance needed before binding standards. Physical location dependencies (EU institutions in Brussels, Agency for Railways in Valenciennes, carrier IT in Berlin/Munich/Zürich, pilot corridors across four member states) add coordination overhead. The program also depends on passenger behaviour change, multimodal integration and disability-rights compliance that are largely outside the program's control. Most critical are the carrier liability and inventory-exposure decisions (Decision 1 and 5), which, if mishandled, could trigger carrier non-participation and unravel the entire through-ticketing stack.

# Make Assumptions


## Question 1 - How should the €1.5 billion public budget be split across standards, clearing, the last-resort concession, adapters, capacity building and contingency, and what reserve is held?

**Assumptions:** Assumption: Allocation follows the pragmatic path: standards €50-100M, clearing €200-300M, concession €300-500M, adapters €200-300M, capacity building €200-300M, consumer rollout €100-150M (all estimates), with a €150-200M reserve (proposed). Private carrier IT investment is estimated separately, roughly €1.5-3B (estimate).

**Assessments:** Title: Financial Feasibility Assessment
Description: Tests whether the fixed budget covers scope with contingency.
Details: Upper-range allocations sum above €1.5B, so contingency is thin. Risks: pool top-ups, concession losses (€75-150M overrun, estimate), adapter overruns (€150-250M, estimate). Mitigation: milestone tranches, a reserve for force-majeure only, a subsidy cap on the concession, and quarterly budget re-baselining. Opportunity: carrier co-financing of adapters lowers public draw.

## Question 2 - What is the realistic sequence of milestones from Month 0 (2026-10-12) to Month 60 (2031-10-12), and how much slack exists if the Regulation's adoption slips?

**Assumptions:** Assumption: Governance set-up by Month 1 (2026-11-12); liability and clearing decisions by Month 6 (2027-04-12); binding standards by Month 18 (2028-04-12); mandatory API exposure by Month 30 (2029-04-12); tiered conformance to Month 42 (2030-04-12); four-corridor through-ticketing by Month 48 (2030-10-12); full TEN-T by Month 60-72 (2031-10-12 to 2032-10-12) (realistic, not aggressive). A 6-12 month slip in the Regulation is plausible.

**Assessments:** Title: Schedule Realism Assessment
Description: Evaluates milestone feasibility and dependencies.
Details: Critical path: Regulation text, DG COMP comfort, liability model, then standards. A 12-18 month legislative delay moves Month 18 (2028-04-12) to Month 30 (2029-04-12) (estimate). Mitigation: shadow standards workstream, pilots at Months 12-18 (2027-10-12 to 2028-04-12), tiered conformance, and a pre-agreed Month 72 (2032-10-12) fallback for full TEN-T. Benefit: priority corridors deliver visible value by Month 48 (2030-10-12) even if the network completes later.

## Question 3 - Which teams and expertise are required in the Programme Office, Technical Secretariat, conformance labs and corridor pilots, and who supplies them?

**Assumptions:** Assumption: Programme Office of about 60-100 staff in DG MOVE (estimate), technical secretariat of 40-60 at the Agency in Valenciennes (estimate), plus contracted test engineers, actuaries and legal specialists. Carriers supply their own integration teams; liaison officers sit in Brussels, Valenciennes, Berlin and Madrid.

**Assessments:** Title: Resource Capacity Assessment
Description: Reviews availability of skilled personnel and leadership continuity.
Details: OSDM and clearing expertise is scarce and concentrated at a few carriers and vendors. Risks: key-person turnover, competition with carriers for engineers, and capacity gaps in smaller member states. Mitigation: multi-year appointments, framework contracts with integrators, regional training hubs, and an external advisory board. Budget about €50-100M for programme management (estimate).

## Question 4 - Which legal instruments and approvals underpin binding standards, competition-law comfort, passenger-rights equivalence and national regulator consent?

**Assumptions:** Assumption: The Regulation is adopted with amendments by about Month 18 (2028-04-12); OSDM is pinned via delegated or implementing act; DG COMP guidance on Article 101 is sought from Month 2 (2026-12-12); Regulation 1371/2007 rights remain the floor; national regulators join as observers. Adoption status of the proposal is not verified.

**Assessments:** Title: Regulatory Compliance Assessment
Description: Maps legal preconditions to programme decisions.
Details: Largest exposure is Article 101 challenge after investment (€50-100M rework, estimate). Mitigation: early pre-notification, clean-team clearing, independent legal review of the backstop by Month 3 (2027-01-12), and regulator impact assessments per member state. Gaps in rights versus Regulation 1371/2007 would force 3-6 month redesign. Benefit: legal certainty encourages carrier commitment of inventory.

## Question 5 - How will liability for missed connections, platform outages, settlement errors and accessibility failures be capped, insured and monitored?

**Assumptions:** Assumption: A carrier-funded guarantee pool with per-incident caps, co-insurance above caps and contributions based on trailing on-time performance; reserve for force majeure only; availability SLAs of p95 latency under 2 seconds and 99.5% uptime (proposed thresholds); reconciliation error under 0.5% (proposed).

**Assessments:** Title: Risk Exposure Assessment
Description: Evaluates liability, technical and operational hazards.
Details: Highest risks: carrier refusal over unpriceable liability (high likelihood), compounded availability across three-leg queries (about 86% at 95% each, recomputed), and pool drain from disruption clusters. Mitigation: actuarial study by Month 6 (2027-04-12), caps, SLA scorecards linked to tranches, cached fallback. Residual risk stays medium until pilots validate loss rates.

## Question 6 - What environmental outcomes are expected, and how will modal shift and the footprint of new IT and rolling-stock upgrades be measured?

**Assumptions:** Assumption: Programme-level impact is mainly indirect via air-to-rail shift on competitive corridors; baseline measured by Month 6 (2027-04-12); targets stated as through-ticket penetration and observed shift, with a conservative 5-10% shift on benchmarked routes (estimate). Hardware retrofits follow maintenance cycles, and data centres use existing carrier or cloud capacity.

**Assessments:** Title: Environmental Impact Assessment
Description: Judges net climate benefit and measurement validity.
Details: Rail emits far less CO2 per passenger-km than short-haul flights, so even modest shift gives net benefit. Risks: low-fare airline response, attribution difficulty, and added e-waste from device upgrades. Mitigation: baseline and control routes, emissions-sorted neutral display, device reuse and recycling clauses, and a Month 48 (2030-10-12) evaluation. Do not promise air-replacement as a success metric.

## Question 7 - Which stakeholders hold decision or veto power, and how will consensus be reached among carriers, distributors, consumer and disability bodies?

**Assumptions:** Assumption: A steering group meets biweekly with DG MOVE, the Agency, CER, 3-4 major carriers, Trainline, Omio, BEUC, a disability body and a regulator; binding votes on core decisions by Month 6 (2027-04-12) with Commission mediation; independent distributors may settle via a third-party fallback interface.

**Assessments:** Title: Stakeholder Alignment Assessment
Description: Assesses consensus risk and engagement structure.
Details: Conflicts: carriers prefer bilateral clearing, distributors want neutral central rules, disability bodies need auditable assistance booking. Failure by Month 9 (2027-07-12) risks a 2-4 month standards delay (estimate) and 20-30% loss of distributor volume. Mitigation: option papers by Month 2 (2026-12-12), transparent commission band, observer seats, PRM usability testing by Month 18 (2028-04-12). Benefit: early buy-in lowers later legal challenge.

## Question 8 - What operational systems and service processes are needed: availability layer, clearing platform, disruption handling, validation, support and monitoring?

**Assumptions:** Assumption: Streamed availability shadow with carrier booking authority; federated netting layer on EUR settlement with 5-business-day cycle (proposed); shared disruption event feed; API handshake or signed journey token for validation; 24/7 support and monitored SLA dashboard; live pilots of 500-1,000 passengers per corridor (proposed).

**Assessments:** Title: Operational Readiness Assessment
Description: Evaluates whether systems and processes work end to end.
Details: Legacy latency, data quality and unshared operational data are main constraints. Risks: stale-seat errors, reconciliation backlog, validation gaps on 20% of vehicles lowering adoption 5-10% (estimate). Mitigation: operational manual by Month 9 (2027-07-12), pilots Months 12-18 (2027-10-12 to 2028-04-12), validation deployment by Month 40 (2030-02-12), shared reconciliation platform. Benefit: staged tiers let strong carriers go live first.

# Distill Assumptions

- Public coordination budget is fixed at €1.5 billion (user constraint), covering standards, clearing, concession, adapters, capacity building and rollout.
- Private carrier IT investment is estimated separately at roughly €1.5-3B (estimate).
- Budget split (estimates): standards €50-100M, clearing €200-300M, concession €300-500M, adapters €200-300M, capacity building €200-300M.
- Consumer rollout is €100-150M (estimate); reserve of €150-200M (proposed) is for force majeure only.
- Upper-range allocations exceed €1.5B, so contingency is thin; quarterly budget re-baselining and a concession subsidy cap apply.
- Governance is set up by Month 1 (2026-11-12); liability and clearing decisions are made by Month 6 (2027-04-12).
- Binding standards are due by Month 18 (2028-04-12); mandatory API exposure by Month 30 (2029-04-12).
- Tiered conformance runs to Month 42 (2030-04-12); four-corridor through-ticketing is delivered by Month 48 (2030-10-12).
- Full TEN-T completes Months 60-72 (2031-10-12 to 2032-10-12), with Month 72 (2032-10-12) as pre-agreed fallback.
- Regulation adoption is assumed with amendments by about Month 18 (2028-04-12); status is not verified; 6-12 month slip is plausible.
- Pilots of 500-1,000 passengers per corridor run Months 12-18 (2027-10-12 to 2028-04-12); validation deployment completes by Month 40 (2030-02-12).
- Pragmatic path chosen: federated settlement, streamed availability shadow, carrier booking authority, carrier-funded guarantee pool, tendered last-resort concession.
- Funds are released in tranches against verified milestones such as conformance certificates and live API exposure.
- Guarantee pool uses per-incident caps, co-insurance above caps, and contributions based on trailing on-time performance; actuarial study by Month 6 (2027-04-12).
- DG COMP Article 101 guidance is sought from Month 2 (2026-12-12); clean-team clearing and legal review of backstop by Month 3 (2027-01-12).
- OSDM is pinned via delegated or implementing act; Regulation 1371/2007 rights remain the floor.
- Stakeholders: DG MOVE, Agency, CER, 3-4 major carriers, Trainline, Omio, BEUC, disability body and regulator sit in a steering group.
- Steering group meets biweekly; binding votes on core decisions by Month 6 (2027-04-12) with Commission mediation.
- Programme Office has 60-100 staff at DG MOVE; Agency secretariat has 40-60 staff (estimates).
- Carriers supply their own integration teams; OSDM and clearing expertise is scarce.
- Settlement uses EUR with a 5-business-day cycle; reconciliation error stays under 0.5% (proposed).
- Availability SLAs are p95 latency under 2 seconds and 99.5% uptime (proposed thresholds).
- Targets: 40% of cross-border journeys as through-tickets, distributor complaints halved, within five years.
- Modal shift is conservative at 5-10% on benchmarked routes (estimate); air replacement is not a success metric.
- Key risks: carrier refusal over unpriceable liability, Article 101 challenge (€50-100M rework), legacy latency, legislative delay.
- Stakeholder alignment failure by Month 9 (2027-07-12) risks a 2-4 month standards delay and 20-30% distributor volume loss (estimates).

# Review Assumptions

## Domain of the expert reviewer
Public infrastructure programme planning and multi-stakeholder governance, with focus on regulatory alignment, financial risk and operational integration at scale

## Domain-specific considerations

- Fixed public budget (€1.5 billion, user constraint) must cover five-year rollout across four corridors and full TEN-T; no contingency for cost overruns beyond force majeure
- Carrier participation is voluntary and depends on predictable liability pricing; unpriceable risk exposure triggers non-participation and network fragmentation
- Regulatory pathway uncertain: Regulation adoption status not verified; Article 101 TFEU comfort needed before binding standards; Regulation 1371/2007 rights must be preserved
- Legacy systems integration: smaller operators' booking engines may not meet latency and availability targets, delaying mandatory API exposure milestone by 6–12 months
- Multi-stakeholder consensus among 25+ carriers, independent distributors, national regulators and disability bodies is required by Month 6 (2027-04-12); failure cascades to standards
- Through-ticket value depends on seamless operational coordination (disruption rebooking, validation, accessibility) across independent national operators with varying systems and cultures

## Issue 1 - Critical Missing Assumption: Carrier Liability Pricing Model Not Defined
The programme assumes carriers will expose through-ticket connections and accept shared liability via a carrier-funded guarantee pool (Decision 1), but the liability-weighting formula, per-incident caps, co-insurance thresholds and risk-transfer mechanism are not yet specified. Carriers cannot price their participation or commit inventory without knowing their maximum exposure and contribution rules. Absence of a published liability model by Month 3 (2027-01-12) leaves the core commercial assumption untested and triggers carrier refusal.

**Recommendation:** By Month 2 (2026-12-12), commission an independent actuarial study to model missed-connection rates, rerouting costs and incident clustering using historical data from each participating carrier. Publish a draft liability-weighting formula by Month 3 (2027-01-12) that specifies: (a) maximum per-incident cap (e.g., €500–1,000 per stranded passenger), (b) co-insurance threshold (e.g., carriers self-insure up to €50M annual pool draw, above which public or reinsurance cover applies), and (c) contribution weights tied to controllable factors (on-time performance, booking-system availability) not forward-looking incident rates. Present this model to CER and the 10 largest carriers by Month 4 (2027-02-12) for binding commercial sign-off before standards are finalised. Establish a quarterly pool-monitoring process that publishes incident rates and contribution adjustments.

**Sensitivity:** If the liability model is not agreed by Month 6 (2027-04-12), carriers face unpriceable risk and 30–40% (estimate) may refuse to expose inventory. This delays mandatory API exposure from Month 30 (2029-04-12) to Month 36 (2029-10-12) or later and reduces network coverage by 20–30%, pushing the 40% through-ticket goal to 15–25% (estimate). Cost impact: €100–150 million in lost programme value if the goal is unachievable. Budget impact: funding for later corridors (Months 48–60 = 2030-10-12 to 2031-10-12) faces reallocation to cover smaller operator adapter overruns, compressing the full TEN-T rollout to Month 72–84 (2032-10-12 to 2033-10-12) instead of Month 60 (2031-10-12).

## Issue 2 - Critical Missing Assumption: Legacy System Integration Timeline and Hidden Adapter Costs Not Validated
The plan allocates €200–300 million (estimate) for conformance testing and carrier adapters to retrofit legacy booking systems to OSDM standards. However, a pre-programme technical audit of all 25+ operators' systems and realistic integration timelines per operator tier (large, regional, small) has not been conducted. Smaller carriers' systems may require 9–15 months of development per operator, not the 18–24 months between Month 12 (2027-10-12) and Month 30 (2029-04-12) mandatory exposure. Risk: adapters miss the Month 30 (2029-04-12) milestone, leaving 8–15 operators outside the network and fragmenting the corridor coverage.

**Recommendation:** Conduct a detailed technical audit of all participating carriers' booking-system architectures by Month 2 (2026-12-12), assessing API readiness, event-streaming capability, transaction consistency and on-time/availability data quality. Establish a per-operator conformance timeline (baseline, extended, advanced tiers) and publish it by Month 6 (2027-04-12). Allocate adapter funding in tranches: Tier 1 (large carriers, Month 30 = 2029-04-12) receives €80–100M (estimate); Tier 2 (regional, Month 36 = 2029-10-12) receives €80–100M (estimate); Tier 3 (small, Month 42 = 2030-04-12) receives €50–80M (estimate). Require carriers in each tier to demonstrate API availability and booking-error rates (<1% stale-seat failures) before their tier release, not a one-time conformance gate.

**Sensitivity:** If tier-based funding is not adopted and all carriers are held to a single Month 30 (2029-04-12) gate, 40–50% (estimate) of smaller and regional carriers miss the deadline by 6–12 months. This creates a 12–18 month delay in reaching full-corridor through-ticketing (from Month 48 = 2030-10-12 to Month 60–66 = 2031-10-12 to 2032-04-12). Budget impact: adapter overruns of €150–250 million (estimate) due to emergency acceleration efforts, or alternatively, € 200–300 million in unused budget if the later corridors cannot launch. Network coverage drops from 25+ carriers to ~15 by Month 48 (2030-10-12), reducing the through-ticket share from 40% to 20–25% (estimate).

## Issue 3 - Critical Missing Assumption: Stakeholder Consensus Mechanism and Fallback Governance for Deadlocked Decisions
The plan requires binding decisions on liability (Decision 1), clearing architecture (Decision 2), public distributor role (Decision 3) and remuneration (Decision 12) by Month 6 (2027-04-12), involving 25+ carriers, CER, Trainline, Omio, BEUC, disability bodies and national regulators with conflicting interests. No formal consensus mechanism, escalation path or fallback governance is defined if a vote is deadlocked or a stakeholder withdraws. Without this, a single veto (e.g., from a large carrier or an independent distributor) can block standards and push binding milestones from Month 18 (2028-04-12) to Month 24–30 (2028-10-12 to 2029-04-12).

**Recommendation:** Establish a tiered governance structure by Month 1 (2026-11-12): (a) biweekly steering group of CER, DG MOVE, Agency, 3–4 major carriers (DB, SNCF, SBB, ÖBB or Renfe), Trainline, Omio, BEUC and one disability-rights body; (b) a voting rule requiring supermajority (75%) of steering members to approve Decisions 1, 2, 3, 12; (c) formal escalation to the Commission Transport Commissioner if a vote does not reach 75% by Month 5 (2027-03-12), with Commission mediation required by Month 6 (2027-04-12); (d) a fallback clause that if a major carrier (>5% of network) refuses a decision, the programme offers a technical fallback (e.g., bilateral clearing with netting, or a third-party settlement interface for distributors) rather than stalling the entire decision. Publish an option paper for each decision by Month 2 (2026-12-12) outlining three variants with trade-offs, so stakeholders see alternatives before voting.

**Sensitivity:** If consensus is not reached by Month 9 (2027-07-12), binding standards are delayed from Month 18 (2028-04-12) to Month 24–30 (2028-10-12 to 2029-04-12), a 2–4 month slip (estimate). This cascades to mandatory API exposure (Month 30 = 2029-04-12 → Month 36 = 2029-10-12, estimate) and four-corridor go-live (Month 48 = 2030-10-12 → Month 54–60 = 2031-04-12 to 2031-10-12, estimate). If a major distributor (e.g., Trainline or Omio) rejects the clearing design, they withdraw from the programme, reducing available through-ticket volume by 15–25% (estimate), which lowers the 40% goal to 20–30%. Estimated cost to resolve deadlock through litigation or renegotiation: €10–20 million and 3–6 month delay.

## Review conclusion
The programme's three most critical missing assumptions are: (1) a published, actuarially validated carrier liability-pricing model specifying caps, co-insurance and contribution weights, absent by Month 3 (2027-01-12), which triggers carrier refusal and threatens network participation; (2) a pre-programme technical audit and per-operator tier-based adapter funding plan, absent which 40–50% of smaller carriers miss the Month 30 (2029-04-12) API exposure deadline and compress later-wave funding; and (3) a formal multi-stakeholder consensus mechanism with escalation and fallback clauses, absent which deadlock on Decisions 1–3 delays binding standards by 2–4 months and cascades throughout the schedule. Each missing assumption poses a 15–25% risk to the 40% through-ticket goal and €100–250 million budget variance. Recommendation: complete liability modelling by Month 3 (2027-01-12), conduct a technical audit by Month 2 (2026-12-12) and establish steering governance with published options by Month 2 (2026-12-12). These three workstreams must run in parallel Months 0–6 (2026-10-12 to 2027-04-12) to unlock the binding-standards pathway.