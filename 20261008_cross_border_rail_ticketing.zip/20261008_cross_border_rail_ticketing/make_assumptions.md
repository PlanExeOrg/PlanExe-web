
## Question 1 - How should the €1.5 billion public budget be split across standards, clearing, the last-resort concession, adapters, capacity building and contingency, and what reserve is held?

**Assumptions:** Assumption: Allocation follows the pragmatic path: standards €50-100M, clearing €200-300M, concession €300-500M, adapters €200-300M, capacity building €200-300M, consumer rollout €100-150M (all estimates), with a €150-200M reserve (proposed). Private carrier IT investment is estimated separately, roughly €1.5-3B (estimate).

**Assessments:** Title: Financial Feasibility Assessment
Description: Tests whether the fixed budget covers scope with contingency.
Details: Upper-range allocations sum above €1.5B, so contingency is thin. Risks: pool top-ups, concession losses (€75-150M overrun, estimate), adapter overruns (€150-250M, estimate). Mitigation: milestone tranches, a reserve for force-majeure only, a subsidy cap on the concession, and quarterly budget re-baselining. Opportunity: carrier co-financing of adapters lowers public draw.

## Question 2 - What is the realistic sequence of milestones from Month 0 (2026-10-12) to Month 60 (2031-10-12), and how much slack exists if the Regulation's adoption slips?

**Assumptions:** Assumption: Governance set-up by Month 1 (2026-11-12); liability and clearing decisions by Month 6 (2027-04-12); binding standards by Month 18 (2028-04-12); mandatory API exposure by Month 30 (2029-04-12); tiered conformance to Month 42 (2030-04-12); four-corridor through-ticketing by Month 48 (2030-10-12); full TEN-T by Month 60-72 (2031-10-12 to 2032-10-12) (realistic, not aggressive). A 6-12 month slip in the Regulation is plausible.

**Assessments:** Title: Schedule Realism Assessment
Description: Evaluates milestone feasibility and dependencies.
Details: Critical path: Regulation text, DG COMP comfort, liability model, then standards. A 12-18 month legislative delay moves Month 18 (2028-04-12) to Month 30 (2029-04-12) (estimate). Mitigation: shadow standards workstream, pilots at Months 12-18 (2027-10-12 to 2028-04-12), tiered conformance, and a pre-agreed Month 72 (2032-10-12) fallback for full TEN-T. Benefit: priority corridors deliver visible value by Month 48 (2030-10-12) even if the network completes later.

## Question 3 - Which teams and expertise are required in the Programme Office, Technical Secretariat, conformance labs and corridor pilots, and who supplies them?

**Assumptions:** Assumption: Programme Office of about 60-100 staff in DG MOVE (estimate), technical secretariat of 40-60 at the Agency in Valenciennes (estimate), plus contracted test engineers, actuaries and legal specialists. Carriers supply their own integration teams; liaison officers sit in Brussels, Valenciennes, Berlin and Madrid.

**Assessments:** Title: Resource Capacity Assessment
Description: Reviews availability of skilled personnel and leadership continuity.
Details: OSDM and clearing expertise is scarce and concentrated at a few carriers and vendors. Risks: key-person turnover, competition with carriers for engineers, and capacity gaps in smaller member states. Mitigation: multi-year appointments, framework contracts with integrators, regional training hubs, and an external advisory board. Budget about €50-100M for programme management (estimate).

## Question 4 - Which legal instruments and approvals underpin binding standards, competition-law comfort, passenger-rights equivalence and national regulator consent?

**Assumptions:** Assumption: The Regulation is adopted with amendments by about Month 18 (2028-04-12); OSDM is pinned via delegated or implementing act; DG COMP guidance on Article 101 is sought from Month 2 (2026-12-12); Regulation 1371/2007 rights remain the floor; national regulators join as observers. Adoption status of the proposal is not verified.

**Assessments:** Title: Regulatory Compliance Assessment
Description: Maps legal preconditions to programme decisions.
Details: Largest exposure is Article 101 challenge after investment (€50-100M rework, estimate). Mitigation: early pre-notification, clean-team clearing, independent legal review of the backstop by Month 3 (2027-01-12), and regulator impact assessments per member state. Gaps in rights versus Regulation 1371/2007 would force 3-6 month redesign. Benefit: legal certainty encourages carrier commitment of inventory.

## Question 5 - How will liability for missed connections, platform outages, settlement errors and accessibility failures be capped, insured and monitored?

**Assumptions:** Assumption: A carrier-funded guarantee pool with per-incident caps, co-insurance above caps and contributions based on trailing on-time performance; reserve for force majeure only; availability SLAs of p95 latency under 2 seconds and 99.5% uptime (proposed thresholds); reconciliation error under 0.5% (proposed).

**Assessments:** Title: Risk Exposure Assessment
Description: Evaluates liability, technical and operational hazards.
Details: Highest risks: carrier refusal over unpriceable liability (high likelihood), compounded availability across three-leg queries (about 86% at 95% each, recomputed), and pool drain from disruption clusters. Mitigation: actuarial study by Month 6 (2027-04-12), caps, SLA scorecards linked to tranches, cached fallback. Residual risk stays medium until pilots validate loss rates.

## Question 6 - What environmental outcomes are expected, and how will modal shift and the footprint of new IT and rolling-stock upgrades be measured?

**Assumptions:** Assumption: Programme-level impact is mainly indirect via air-to-rail shift on competitive corridors; baseline measured by Month 6 (2027-04-12); targets stated as through-ticket penetration and observed shift, with a conservative 5-10% shift on benchmarked routes (estimate). Hardware retrofits follow maintenance cycles, and data centres use existing carrier or cloud capacity.

**Assessments:** Title: Environmental Impact Assessment
Description: Judges net climate benefit and measurement validity.
Details: Rail emits far less CO2 per passenger-km than short-haul flights, so even modest shift gives net benefit. Risks: low-fare airline response, attribution difficulty, and added e-waste from device upgrades. Mitigation: baseline and control routes, emissions-sorted neutral display, device reuse and recycling clauses, and a Month 48 (2030-10-12) evaluation. Do not promise air-replacement as a success metric.

## Question 7 - Which stakeholders hold decision or veto power, and how will consensus be reached among carriers, distributors, consumer and disability bodies?

**Assumptions:** Assumption: A steering group meets biweekly with DG MOVE, the Agency, CER, 3-4 major carriers, Trainline, Omio, BEUC, a disability body and a regulator; binding votes on core decisions by Month 6 (2027-04-12) with Commission mediation; independent distributors may settle via a third-party fallback interface.

**Assessments:** Title: Stakeholder Alignment Assessment
Description: Assesses consensus risk and engagement structure.
Details: Conflicts: carriers prefer bilateral clearing, distributors want neutral central rules, disability bodies need auditable assistance booking. Failure by Month 9 (2027-07-12) risks a 2-4 month standards delay (estimate) and 20-30% loss of distributor volume. Mitigation: option papers by Month 2 (2026-12-12), transparent commission band, observer seats, PRM usability testing by Month 18 (2028-04-12). Benefit: early buy-in lowers later legal challenge.

## Question 8 - What operational systems and service processes are needed: availability layer, clearing platform, disruption handling, validation, support and monitoring?

**Assumptions:** Assumption: Streamed availability shadow with carrier booking authority; federated netting layer on EUR settlement with 5-business-day cycle (proposed); shared disruption event feed; API handshake or signed journey token for validation; 24/7 support and monitored SLA dashboard; live pilots of 500-1,000 passengers per corridor (proposed).

**Assessments:** Title: Operational Readiness Assessment
Description: Evaluates whether systems and processes work end to end.
Details: Legacy latency, data quality and unshared operational data are main constraints. Risks: stale-seat errors, reconciliation backlog, validation gaps on 20% of vehicles lowering adoption 5-10% (estimate). Mitigation: operational manual by Month 9 (2027-07-12), pilots Months 12-18 (2027-10-12 to 2028-04-12), validation deployment by Month 40 (2030-02-12), shared reconciliation platform. Benefit: staged tiers let strong carriers go live first.