Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 10 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 8 | Material risk with plausible path. |
| ✅ Low | 2 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is a systems-integration and regulatory coordination programme to enable unified booking and ticketing across European rail operators. All core deliverables — standards, APIs, payment clearing, consumer applications, and hubs — are implemented as software, contracts, and operational infrastructure running on hardware. These are physical mechanisms (information processing, financial flows, human behaviour) consistent with the laws of physics. No part of the plan requires breaking conservation laws, causality, or speed-of-light limits, nor does it depend on a non-physical causal mechanism to achieve stated outcomes.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: ✅ Low

**Justification**: Rated LOW because the programme's core mechanisms—software APIs, financial settlement, information networks, human coordination, and physical train operations—all operate within the laws of physics. No outcome requires breaking conservation laws, violating causality, exceeding physical speed limits, or invoking non-physical causal mechanisms. Infrastructure, timeline and budget are physically feasible.

**Mitigation**: No physics-related action required. The plan does not invoke mechanisms that violate the laws of physics. Continue with standard project risk management for execution, market, regulatory and governance risks documented separately.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan defines operational levers (access terms, clearing, funding, hubs, governance) with clear mechanisms-of-action, owners and measurable outputs. However, headline strategic concepts (40% through-ticket share, modal shift from air, distributor buy-in, halved complaints) lack validated customer-value hypotheses, causal models linking programme actions to outcomes, or ownership assignments. Missing: willingness-to-pay evidence for through-fares, traveller switching drivers (price vs. convenience vs. trust), distributor value proposition, and complaint root-cause analysis. The plan assumes these outcomes will follow from technical execution without demonstrating the strategic assumptions that connect execution to results.

**Mitigation**: Stakeholder Engagement Lead: Define and validate the killer-application customer value hypothesis, distributor incentive model, and complaint-reduction causal chain through structured willingness-to-pay research (Months 1–4 = 2026-11-08 to 2027-02-08) and distributor interviews (Months 1–6 = 2026-11-08 to 2027-04-08); produce one-pagers for each strategic concept with value hypothesis, success metrics, and decision hooks for the Steering Committee by Month 6 (2027-04-08).


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan documents major cascading risks (Regulation delay → standards compression → API slip, budget overrun → contingency exhaustion → conformance testing cuts → smaller-carrier miss) with quantified impacts and mitigation playbooks. However, three material gaps remain: (1) supplier/ecosystem collapse cascades (hub operator, payment-institution, or data-centre insolvent mid-programme) are identified for payment only, not for other critical vendors; (2) cross-border enforcement-divergence cascade (regulator inconsistency → discrimination evaded → complaints rise) is not mapped despite acknowledged regulator capacity variance; (3) no joint-delay scenario testing addresses correlated slippages (Regulation adoption + governance delegation + hub procurement slipping together). These gaps could allow 2–3 month undetected cascade by Month 18–24 (2028-04-08 to 2028-10-08) before escalation is forced.

**Mitigation**: Risk & Compliance Lead: Expand the risk register by Month 3 (2027-01-08) to add vendor-collapse, cross-border enforcement-divergence, and joint-delay cascade mappings; for each, define tripwire metrics (e.g., if 2+ critical-path items slip >4 weeks simultaneously, convene re-baselining within 5 working days); establish monthly cascade-review steering check starting Month 6 (2027-04-08).


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the programme has tight but plausible critical-path sequencing: Regulation adoption (Month 9 = 2027-07-08 gate) compresses to standards (Month 18 = 2028-04-08) in 9 months; governance delegation and hub procurement are front-loaded (Months 1–3 = 2026-11-08 to 2027-01-08); payment accreditation by Month 12 (2027-10-08). The plan identifies shadow standards pre-work and cascade dependencies. However, material gaps remain: (1) no formal permit/approval matrix specifies authorities, lead times, or escalation for GDPR (Month 4 = 2027-02-08 target), competition-authority comfort (Month 6 = 2027-04-08 target), or regulator alignment (Month 4 = 2027-02-08 target); (2) no-go gates lack binding enforcement authority; (3) conformance testing (Months 18–30 = 2028-04-08 to 2029-04-08) for 25+ carriers assumes 4–6 parallel lab capacity without verification; (4) Regulation adoption assumed Month 9 (2027-07-08) but EU legislative timelines are 12–18 months, risking compression of standards window if adoption slips to Month 11–12 (2027-09-08 to 2027-10-08).

**Mitigation**: Programme Director: Build and publish a formal Permit/Approval Matrix (Regulation adoption, GDPR consensus, competition clearance, regulator alignment) specifying authorities, authoritative lead times, escalation paths, and binding no-go thresholds by Month 1 (2026-11-08). Establish weekly Regulation adoption tracking with Parliament TRAN rapporteurs by Month 0.5 (2026-10-23); set hard gate at Month 10 (2027-08-08)—if Regulation unadopted, pause carrier onboarding and re-baseline critical path within 2 weeks.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan allocates EUR 1,500 million across 8 line items with EUR 215 million free contingency (Month 0-60 = 2026-10-08 to 2031-10-08), defines milestone gates (Months 18, 30, 60 = 2028-04-08, 2029-04-08, 2031-10-08), and identifies cost overrun tripwires. However, material assumptions remain unvalidated: (1) carrier co-funding demand (EUR 290M allocated, but 12-18 carriers requesting EUR 2-15M each per size band) lacks binding cost quotes; (2) distributor operating cost (EUR 43M/year) assumes reference-only scope—if full retail is chosen, cost could reach EUR 65M/year, consuming EUR 110M additional; (3) hub economics gap (EUR 1.9M/year unfunded across 4 hubs) is acknowledged but unresolved; (4) a 20-30% overrun (EUR 300-450M) exceeds free contingency by EUR 85-235M, and the proposed supplementary authority (EUR 100-200M) is not secured and is outside the cap; (5) post-Month 60 (2031-10-08) recurring costs (EUR 45M/year unfunded) have no committed funding model (decision deferred to Month 48 = 2030-10-08). Monthly burn-rate dashboards with Tier 1-3 contingency cuts are planned but not operationalized.

**Mitigation**: Budget Controller & Financial Manager: Operationalize monthly budget-burn dashboards with actual spend data by Month 3 (2027-01-08); obtain binding IT cost quotes from 8-12 representative carriers (EUR per carrier by size band) and distributor operator candidates by Month 4 (2027-02-08); lock distributor scope decision (reference-only vs. full retail) and operating-cost estimate by Month 2 (2026-12-08); establish written supplementary authority request pathway with DG MOVE by Month 3 (2027-01-08), targeting EUR 100-200M if Tier 2 overrun signals emerge.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan allocates EUR 1,500 million across eight line items with EUR 215 million free contingency, but three material cost assumptions lack validation. First, carrier co-funding (EUR 290M) assumes EUR 2-8M per SME and EUR 10-15M per mid-size operator, but no binding IT cost quotes exist; a 30-50% cost overage (EUR 60-110M additional) would exhaust contingency by Month 18 (2028-04-08). Second, distributor operating cost (EUR 43M/year) assumes reference-implementation scope; if full retail is selected, cost could reach EUR 65M/year (EUR 110M additional over five years). Third, hub economics gap (EUR 1.9M/year unfunded, EUR 9.5M total) is acknowledged but unresolved. Additionally, no normalized per-area or per-carrier benchmarking validates these figures against industry comparables, and a 20-30% overrun (EUR 300-450M) exceeds free contingency by EUR 85-235M, requiring supplementary authority (EUR 100-200M) not yet secured. Monthly burn-rate dashboards are planned for Month 3 (2027-01-08) but not yet active.

**Mitigation**: Budget Controller & Financial Manager: Obtain binding IT cost quotes from 8-12 representative carriers (grouped by size band: SME, mid-size, major) and one distributor operator candidate by Month 6 (2027-04-08); lock distributor scope decision (reference-only vs. full retail) and operating-cost estimate by Month 2 (2026-12-08); establish monthly budget-burn dashboard with actual spend data and 115% pro-rata trigger by Month 3 (2027-01-08); normalize costs per carrier onboarded and per through-ticket transaction; if cumulative co-funding requests exceed EUR 310M by Month 12 (2027-10-08), initiate Tier 2 response (reduce rate from 20% to 10%, save EUR 50M).


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents seven critical projections (40% through-ticket share, 5–15% modal shift, €1.25B private IT spend, €43M/year distributor cost, €1.9M/year hub gap, 90%+ Month 30 = 2029-04-08 compliance, Month 9 = 2027-07-08 Regulation adoption) as single points without ranges, confidence intervals, or alternative scenarios. Willingness-to-pay research to validate through-fare competitiveness is not planned until Months 1–4 (2026-11-08 to 2027-02-08), leaving the 40% target ungrounded. No best-/worst-/base-case scenarios model regulation delay, cost overrun cascade, or modal-shift miss. The contingency framework (Tier 1–3 cuts) is reactive, not forward-looking. This one-sidedness masks material optimism: if through-fares cannot compete (proposed threshold: willingness-to-pay below 8%), or if Regulation adoption slips beyond Month 10 (2027-08-08), or if carrier IT costs rise 30–50%, the entire programme timeline and the 40% target unravel.

**Mitigation**: Analytics Lead: Conduct sensitivity and scenario analysis for the four most critical projections by Month 3 (2027-01-08): (1) Through-ticket share at 25%, 40%, 50% by Month 60 (2031-10-08), given willingness-to-pay elasticity ranges; (2) Regulation adoption at Months 9, 11, 13 (2027-07-08, 2027-09-08, 2027-11-08) with cascading impact on standards and carrier readiness; (3) Private carrier IT spend at €0.6B, €1.25B, €1.8B with impact on co-funding demand and hub dependency; (4) Hub economics at cost-recovery, deficit, or shutdown scenarios. Publish a scenario summary showing month 60 (2031-10-08) outcomes (through-ticket share ±10pp, corridor readiness ±20%, budget variance ±€200M) and decision triggers for each scenario by Month 6 (2027-04-08).


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan defines critical technical components (OSDM APIs, clearing settlement, data layer, hub architecture, ticket validation) with work-breakdown structures and high-level specifications, but material gaps remain in engineering depth. Binding standards are due Month 18 (2028-04-08), yet only "draft access-term templates, settlement message standards" and "define passenger-rights allocation" are specified as Month 4–18 (2027-02-08 to 2028-04-08) activities with no baseline interface contracts, performance SLAs validated by external testing, or a complete integration map with identified owners and dependencies. The data layer (federated queries + cache + event-streaming) lacks detail on message schemas, API payload limits, latency budgets per component, or failover procedures. Hub mapping logic for legacy systems is unvalidated; acceptance tests for "oversell detection and carrier-attribution disputes" are mentioned as Month 6 (2027-04-08) tasks but tests themselves are not specified. The programme assumes 25+ carriers will integrate by Month 30 (2029-04-08) through conformance testing, but the test harness design, conformance pass/fail criteria, and non-functional requirements (99.95% uptime, <2 second p95 latency) are defined as SLAs only, not as testable specifications embedded in the acceptance framework. The critical path compresses standards to 9 months if regulation adoption reaches Month 9 (2027-07-08), leaving limited time for detailed interface contracts and integration plan validation.

**Mitigation**: Chief Technical Standards Officer: Produce detailed engineering artifacts by Month 6 (2027-04-08) specifying: (1) API interface contracts for inventory, fares, and post-sale functions (OpenAPI 3.0 or equivalent, with request/response payloads and rate-limiting rules); (2) data-layer message schema (booking, settlement, disruption events, accessibility attributes with GDPR minimization); (3) hub legacy-to-OSDM mapping specification with test vectors for oversell, restrictions, and pricing rules; (4) non-functional requirements (uptime 99.95%, latency p95 <2s, throughput ≥500 req/s per corridor) with performance test methodology; (5) integration map naming carrier IT owner, hub operator, payment provider, and data-centre roles, with documented dependencies and sign-off gates at Months 12, 18, 24, 30 (2027-10-08, 2028-04-08, 2028-10-08, 2029-04-08). Allocate EUR 2–3M from the standards budget for external validation of the interface contracts and a dry-run conformance lab by Month 12 (2027-10-08).


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan asserts five critical operational claims without verified supporting artifacts: (1) "the EUR 1.5 billion public budget will cover carrier co-funding (EUR 290M), distributor operations (EUR 215M), hub operations (EUR 44M), and contingency (EUR 215M)" yet no binding cost quotes from carriers, distributors or hub operators exist to validate these allocations; (2) "carriers will sign Commitment Letters by Month 3 (2027-01-08) accepting binding arbitration panel authority and 0.5–1% escrow penalties" yet the Council/Commission delegation granting the panel authority is not confirmed and no carrier pre-engagement signals willingness; (3) "payment-institution accreditation will yield 2+ qualified providers by Month 12 (2027-10-08) at fees below 0.7% per transaction" yet no applicant market-testing exists and payment providers have not been consulted on the data-governance requirements; (4) "through-ticket share will reach 40% by Month 60 (2031-10-08) and modal shift will occur (planning range 5–15%)" yet no willingness-to-pay research, competitor pricing analysis, or traveller demand study has been conducted; (5) "the four regional hubs can be operational by Month 9 (2027-07-08) with booking-failure rates below 0.5%" yet no hub operator has been engaged and no legacy-system mapping validation has been performed. Without these five evidence packages, the programme cannot commit to Months 18, 30 and 60 (2028-04-08, 2029-04-08, 2031-10-08) milestones or the 40% through-ticket target. The plan assumes these will follow from execution rather than from validated assumptions and committed agreements.

**Mitigation**: Governance Lead: Establish an Evidence Acquisition Task Force by Month 1 (2026-11-08) to obtain five missing evidence packages by Month 6 (2027-04-08): (1) binding IT cost quotes from 8–12 representative carriers (via RFI to CER members); (2) written Commitment Letter preconditions from SNCF, Deutsche Bahn and ÖBB (via bilateral engagement); (3) market-sounding responses from licensed PSD2 payment institutions on accreditation criteria and fees (via public notice); (4) willingness-to-pay survey (300–500 respondents per corridor, conjoint methodology); (5) signed hub operator bids with operational timelines and SLA commitments (via RFP). Escalate to Steering Committee if any evidence package is not complete by Month 6 (2027-04-08); do not proceed with carrier onboarding or procurement until all five are secured or scope is formally reduced.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because a major flagship deliverable—the "killer application" through-ticket product—is mentioned throughout the plan (40% adoption target, modal shift from air, "one ticket, guaranteed connection") without specific, verifiable qualities validated by customer research. The plan assumes through-fares and convenience alone will drive adoption, yet no willingness-to-pay study, competitor pricing analysis, or traveller demand research validates this value proposition. Acceptance criteria for the product (booking speed, refund turnaround, accessibility confirmation) lack quantified targets aligned to the halved-complaints goal.

**Mitigation**: Consumer Product and App Development Lead: Commission a willingness-to-pay study (300–500 respondents per corridor, conjoint methodology) and competitor pricing analysis by Month 4 (2027-02-08); define SMART acceptance criteria for the killer-application product (through-ticket adoption >= 8% of corridor traffic, booking confirmation within 15 minutes, refund within 10 days, assistance confirmation within 24 hours, satisfaction >= 4.0/5 stars) by Month 6 (2027-04-08); pilot the product on one corridor Months 6–12 (2027-04-08 to 2027-10-08).


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because Decision 14 (Outcome Measurement, Baselines and Attribution) proposes a full independent counterfactual evaluation with comparison routes, external evaluator hire, and quarterly tracking, costing EUR 5–10M estimated. The core goals are measurable via simpler carrier/distributor self-reported through-ticket volumes (40% target) and complaint counts (halved target). A counterfactual separating programme effects from fuel prices and aviation-tax changes is intellectually rigorous but not required to determine if 40% share or halved complaints are met. The plan omits the direct cost-benefit of this comprehensive evaluation against the core goals; it assumes evaluation rigour without showing how it advances 40% adoption or complaints reduction.

**Mitigation**: Finance Lead: Produce a one-page Benefit Case for the counterfactual evaluation by Month 3 (2027-01-08) specifying: (1) decision trigger (e.g., if actual share is within 5pp of 40%, counterfactual not needed); (2) alternative simpler measurement (self-reported data + internal audit); (3) KPI (e.g., evaluation credibility score, regulator acceptance); (4) estimated cost EUR 5–10M; (5) owner. If KPI cannot be quantified or benefit is deemed "nice-to-have," move counterfactual evaluation to post-Month 60 (2031-10-08) backlog and use EUR 5–10M for core-goal activities (carrier co-funding, hub resilience).


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Data Layer and Real-Time Systems Architect role combines four rarely co-existing specialisms: distributed systems design at pan-European scale, GDPR/cross-border data governance, competition-law data-sharing safeguards, and rail domain knowledge. This unicorn role is mission-critical: the p95 <2-second latency and 99.95% uptime SLA across 25+ legacy carriers underpins the 40% through-ticket target and Month 30 (2029-04-08) API mandate. Architects with this specific skill intersection are scarce globally, and recruitment lag directly threatens the Month 9 (2027-07-08) data-layer procurement gate and Month 18 (2028-04-08) standards deadline. No mitigation for chronic talent shortage exists except early market validation.

**Mitigation**: Talent Acquisition Lead: Conduct a targeted talent-market validation for Data Layer/Real-Time Systems Architects with proven GDPR + competition-law + distributed-systems experience within 60 days (by Month 1.5 = 2026-11-23). Contact 5-8 global systems firms (Accenture, Capgemini, Databricks, Confluent) and 3-4 independent European CIOs; report go/no-go hiring probability and recommended procurement timeline to the Steering Committee by Month 2 (2026-12-08).


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not establish a comprehensive legal and regulatory approval pathway. The Commission's proposed Regulation on Digital Booking and Ticketing Services for Rail (May 2026) remains unadopted; Parliament and Council approval is expected Month 6–12 (2027-04-08 to 2027-10-08), with final text still uncertain on liability allocation and data-sharing scope. GDPR consensus from national DPAs is targeted by Month 4 (2027-02-08), yet no formal EDPB guidance or member-state sign-off exists. Competition-law clearance (DG COMP comfort letter) is due Month 6 (2027-04-08), but the shared data-layer architecture is not yet formally submitted for review. Payment-institution accreditation (PSD2 licensing) depends on GDPR resolution and is gated at Month 12 (2027-10-08), leaving 6 months before the Month 18 (2028-04-08) binding standards deadline. No formal Permit/Approval Matrix maps authorities, lead times, escalation paths, or binding no-go thresholds. Absent these legal certainties—especially Regulation final text, DPA consensus, and DG COMP clearance—the programme cannot lock binding standards by Month 18 (2028-04-08) or carrier commitments by Month 3 (2027-01-08). Regulatory adoption slippage (if Regulation adoption moves to Month 10–12 = 2027-08-08 to 2027-10-08) compresses the 9-month standards window to 3–4 months, threatening both the Month 18 (2028-04-08) and Month 30 (2029-04-08) milestones.

**Mitigation**: Programme Director: Publish a formal Permit/Approval Matrix by Month 1 (2026-11-08) specifying Regulation adoption, GDPR/DPA consensus, DG COMP clearance, and national regulator alignment, with authorities, required artifacts, lead times, binding no-go thresholds, and escalation paths. Establish weekly Regulation adoption tracking with TRAN and IMCO rapporteurs by Month 0.5 (2026-10-23); trigger external standards consortium by Month 8.5 (2027-06-23) if adoption probability falls below 70%; invoke hard no-go gate at Month 10 (2027-08-08).


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because post-Month 60 (2031-10-08) operational sustainability depends on three unresolved elements: (1) the €45M/year unfunded recurring cost (reference distributor ~€43M + hub economics gap ~€1.9M, plus unestimated data-layer and regulator capacity costs) has no committed funding source; (2) the decision on the post-Month 60 (2031-10-08) funding model (fee-recovery, member-state co-funding, or sunset) is deferred to Month 48 (2030-10-08), leaving only 12 months to negotiate and implement before the programme budget expires; (3) if the free contingency (€215M) is exhausted by cost overruns before Month 30 (2029-04-08), no bridge funding exists to manage the transition at Month 60 (2031-10-08). Without a locked, sustainable funding model and committed partner contributions by Month 42 (2030-04-08), the programme risks operational collapse: the public distributor may shut down (eliminating a consumer channel), hubs may cease (stranding smaller carriers and fragmenting the network), and the shared data layer may be abandoned.

**Mitigation**: Sustainability Working Group: Establish task force by Month 36 (2029-10-08) to model three fee-recovery, member-state co-funding, and sunset scenarios; secure written political commitment from at least 15 member states for post-Month 60 (2031-10-08) funding (€45M+/year) by Month 48 (2030-10-08); lock and publish the adopted model by Month 54 (2031-04-08).


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies physical locations (Brussels, Cologne/Frankfurt, Vienna, Budapest, Warsaw, Sofia, Bucharest) and facility needs (offices, 24/7 operations centre, data centres, conformance labs) but provides no evidence that zoning, occupancy, egress, fire load, structural limits, noise, or permit constraints are satisfied. No viable alternatives or no-go thresholds are defined. A single permit denial or zoning conflict could delay arbitration panel, operations centre, or hub deployment by 2–6 months, threatening Months 18 and 30 (2028-04-08, 2029-04-08) milestones.

**Mitigation**: Facilities and Compliance Lead: Conduct a fatal-flaw screen of all seven named locations (Brussels, Cologne, Frankfurt, Vienna, Budapest, Warsaw, Sofia, Bucharest) against zoning, occupancy, fire, noise, and permit requirements by Month 3 (2027-01-08); obtain written confirmation from local authorities; define fallback sites and no-go thresholds (e.g., if Brussels permit denied, escalate within 2 weeks).


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies partial redundancy for payment providers (2 accredited firms by Month 12 = 2027-10-08) and API infrastructure (3 data-centre regions with automatic failover <30s), with SLAs specified (99.95% uptime, <2h hub recovery). However, material gaps exist: no secondary hub operator is pre-contracted as fallback if primary hub fails; payment-provider switching ($5-10M) is covered only by contingency draw, not by a pre-signed standby agreement; data-centre failover is untested before Month 18 (2028-04-08) production; carrier IT integration lacks a fallback distributor or corridor-bypass route if a major incumbent (Deutsche Bahn, SNCF) withdraws. Hub-dependent smaller carriers (4-6 per region) face single-point-of-failure risk with no tested recovery procedure documented.

**Mitigation**: Procurement Lead: Secure pre-contracted backup payment-institution commitment by Month 6 (2027-04-08) with signed standby SLA; conduct data-centre failover and carrier-hub-failure disaster-recovery drills by Month 15 (2028-01-08); establish bilateral carrier-to-carrier rerouting fallback paths for each hub region by Month 12 (2027-10-08).


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies two key stakeholder groups with potentially conflicting incentives—Finance (prioritizes budget adherence and cost control) and Operations/Carriers (prioritizes integration speed and system reliability)—but does not articulate their underlying incentive structures or propose a shared measurable objective to align them. The Pragmatic Foundation scenario allocates EUR 1.5 billion with EUR 215 million free contingency and defines Tier 1–3 cost-reduction gates, yet these controls assume Finance and Carriers accept the same trade-off preferences. No OKR or binding joint objective document specifies a common success metric (e.g., "Month 30 = 2029-04-08 API mandate with <5% budget variance and >80% carrier integration") that would make incentive alignment visible and enforceable. Without explicit stakeholder incentive analysis and a shared OKR locked by Month 3 (2027-01-08), Finance may enforce austerity cuts that delay carrier co-funding, while Carriers may resist cost transparency, leaving hidden misalignment until Month 12–18 (2027-10-08 to 2028-04-08) when budget pressure and integration slippage collide.

**Mitigation**: Governance Lead: Commission a Stakeholder Incentive Analysis by Month 1 (2026-11-08) identifying Finance, Operations/Carriers, and Regulators' stated goals and underlying incentives; draft a shared OKR by Month 2 (2026-12-08) specifying joint success (e.g., "Achieve Month 30 = 2029-04-08 API mandate with carrier integration >80% and budget variance <10%"); secure written sign-off from Finance and carrier representatives by Month 3 (2027-01-08); embed OKR review into quarterly steering checks.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan defines three critical operational levers (OSDM Access Terms, Clearing and Settlement Architecture, Funding Allocation and Carrier Incentives) with decision logic and stated trade-offs, yet lacks binding feedback mechanisms. The plan identifies outcome targets (40% through-ticket share by Month 60 = 2031-10-08, halved distributor complaints by Month 60 = 2031-10-08) and proposes quarterly measurement dashboards starting Month 18 (2028-04-08), but does not specify: (1) who owns each KPI and holds decision authority if targets slip; (2) review cadence and escalation rules (e.g., 'if through-ticket share is below 15% at Month 24 = 2028-10-08, trigger Steering Committee decision within 2 weeks'); (3) change-control thresholds that trigger re-planning or programme pause (e.g., 'if budget spend exceeds 115% pro-rata for 2 consecutive quarters, halt new commitments and re-baseline'). The plan mentions 'mid-course reviews at Months 12 and 24 (2027-10-08, 2028-10-08)' and a monthly burn-rate dashboard with Tier 1–3 responses, yet no formal governance gate, decision-owner role, or binding response timeline is locked. Without named KPI owners, time-boxed escalation and explicit re-plan/stop thresholds, the programme risks silent drift: KPIs miss by 10–20%, budget contingency erodes, and corrective decisions are deferred until crisis forces re-planning, jeopardizing the Month 30 (2029-04-08) API mandate.

**Mitigation**: Governance Lead: Establish a formal Feedback Loop Charter by Month 3 (2027-01-08) specifying: (1) KPI owner and decision authority per metric (e.g., Through-Ticket Share owner = Distributor Platform Lead, re-plan trigger if <15% at Month 24 = 2028-10-08); (2) monthly budget-burn dashboard with 115% pro-rata trigger and pre-approved Tier 1–3 responses; (3) quarterly Steering Committee review gate with binding decision authority on corrective actions within 10 working days. Activate the monthly dashboard by Month 3 (2027-01-08) and the first formal steering review by Month 12 (2027-10-08).


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies 15 major decisions and strategic levers (access terms, clearing, funding, governance, data layer, hubs, passenger rights, accessibility, measurement) with stated trade-offs and interdependencies, yet lacks a formal systemic risk analysis. Three material gaps prevent full visibility into multi-node cascades: (1) no bow-tie, FTA, or cross-impact matrix maps how regulation adoption delay cascades to standards compression, then to carrier integration slippage, then to Month 30 (2029-04-08) API mandate failure; (2) no common-mode-failure analysis identifies that a single payment-institution withdrawal, hub outage, or regulator non-enforcement could simultaneously stall clearing settlement, smaller-carrier onboarding, and access-term verification—creating a compound critical-path failure; (3) no integrated risk heat-map shows which of the 9 identified high-risk failure modes interact to amplify each other (e.g., budget overrun forces contingency Tier 3 cuts to conformance testing, which delays carrier compliance and hub readiness, which pushes smaller carriers past Month 30 = 2029-04-08, which fragments the network and kills the 40% target). Without an interdependency map and NO-GO/contingency thresholds that span all 15 decisions, the programme treats risks in silos and cannot trigger holistic course correction when compound cascades emerge.

**Mitigation**: Risk & Governance Lead: Build and publish an interdependency map, bow-tie diagram for the three highest-consequence cascades (Regulation adoption → standards → API mandate; budget overrun → contingency cuts → carrier readiness; payment-provider failure → settlement failure → access verification), and a combined risk heatmap with owner/threshold/NO-GO decision points for each cascade by Month 6 (2027-04-08).