# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: EU Payment Services Regulation and PSD2 Specialist

**Knowledge**: Payment services licensing, PSD2 compliance, settlement architecture, regulated payment institution accreditation

**Why**: The programme's Clearing and Settlement Architecture (Decision 2) proposes accredited payment institutions for split-payment orchestration. This is a novel application of PSD2 licensing in a multi-carrier rail context, requiring expert validation of the accreditation timeline (Month 8 = 2027-06-08), fee caps (0.3-0.5%), and fallback if fewer than 2 providers apply by Month 6 (2027-04-08).

**What**: Review the payment accreditation framework for regulatory feasibility, assess whether the 6-month accreditation window is realistic, identify licensing gaps (e.g. fraud liability, cross-border settlement KYC requirements), and recommend mitigation if the fallback to bilateral settlement is triggered.

**Skills**: PSD2 licensing architecture, payment settlement operations, fraud and compliance frameworks, regulatory liaison with national payment authorities

**Search**: PSD2 payment services specialist, regulated payment institution licensing, settlement orchestration

## 1.1 Primary Actions

- Secure a binding Council Regulation or Delegated Act designating the arbitration panel as a force-of-law dispute-resolution body by Month 1.5 (2026-11-23), with compliance penalties (1% revenue withheld on second non-compliance, Commission enforcement on third); obtain carrier Commitment Letters from carriers >EUR 50M revenue by Month 3 (2027-01-08) with signatures collected at CER roundtables.
- Commission an independent cost-modelling firm by Month 0.5 (2026-10-23) to deliver a detailed activity-based budget forecast by Month 2 (2026-12-08), specifying per-carrier co-funding need, hub opex/fee gaps, distributor retail-vs.-reference cost, and payment-fee exposure; establish monthly burn-rate dashboards by Month 3 (2027-01-08) with 115% spend triggers and pre-agreed Tier 1–3 contingency actions.
- Initiate direct liaison with Parliament TRAN/IMCO rapporteurs and key member-state transport ministers (Germany, France, Belgium, Austria, Spain) by Month 0.5 (2026-10-23) to obtain weekly adoption-probability updates and political signalling; if Regulation adoption slips past Month 8 (2027-06-08), immediately contract an external standards-review consortium (Month 8.5 = 2027-06-23) for accelerated drafting.
- Commission customer-research and willingness-to-pay studies on the four priority corridors by Month 1 (2026-11-08), with results by Month 3 (2027-01-08); define two flagship products (guaranteed-connection through-ticket with 4-hour reroute; air-rail city-pair) and pilot one on Paris–Brussels–Amsterdam–Köln corridor from Month 9 (2027-07-08); measure modal shift and through-ticket share by Month 24 (2028-10-08) and commission a strategic review if results fall below 5% modal shift or 8% share.
- Commission a Data Protection Impact Assessment by Month 1 (2026-11-08) and conduct early engagement with EDPB and 6–8 national DPAs by Month 3 (2027-01-08) to secure consensus on Standard Contractual Clauses, data-residency rules and accessibility-data consent regimes by Month 4 (2027-02-08); escalate any DPA challenge to EDPB for emergency guidance (target 30 days) to avoid 6–12 month engineering rework.
- Establish a monthly Standing Regulators Committee by Month 1.5 (2026-11-23) with binding authority to enforce panel rulings; commit to member-state regulator capacity twinning with training and joint audits (Months 6–12 = 2027-04-08 to 2027-10-08) for weaker regulators (Poland, Bulgaria, Romania, Hungary, Slovakia, Slovenia, Croatia, Malta).
- Issue a Request for Proposals for regional hub operators by Month 0.5 (2026-10-23) specifying at least 4–6 hubs, operational start no later than Month 9 (2027-07-08), and 99.9% uptime SLAs; award contracts by Month 3 (2027-01-08) and schedule pilot tests with 2–3 eligible carriers per hub by Month 15 (2028-01-08).

## 1.2 Secondary Actions

- Conduct a dry-run arbitration case (e.g. access-term dispute between a distributor and a carrier) in Months 6–9 (2027-04-08 to 2027-07-08) to test panel decision speed, compliance enforcement and cross-border recognition; publicize the outcome to signal credibility to incumbents and smaller carriers.
- Hire regional support coordinators (3–5 FTE based in Budapest, Warsaw, Sofia, Bucharest) by Month 4 (2027-02-08) for on-site integration mentoring of smaller carriers; allocate EUR 1–2M over five years for this support team.
- Establish an actuarial study of refund volumes and claim-processing infrastructure by Month 2 (2026-12-08), with results by Month 3 (2027-01-08); define a Passenger-Rights Backstop and Liability Framework specifying reroute decisions <4 hours, refunds <10 days, distributor as single contact, and pooled guarantee fund (EUR 5M per carrier per year); require all operational entities (hubs, payment institutions, distributor, clearing) to carry comprehensive liability insurance (EUR 2–10M limits) by Month 4 (2027-02-08).
- Launch a market-sounding and bilateral outreach with major distributors (Trainline, Omio) by Month 1 (2026-11-08); offer early API access (Months 9–15 = 2027-07-08 to 2028-01-08) in exchange for binding integration commitments and co-marketing support (EUR 5–10M from the EUR 150M consumer-rollout allocation); finalize distributor MOUs by Month 6 (2027-04-08).
- Establish payment-provider accreditation process: issue market sounding Month 0–1 (2026-10-08 to 2026-11-08), call for applicants Month 2 (2026-12-08), decision Month 8 (2027-06-08); target at least 2 accredited providers operational Month 12 (2027-10-08); include contractual guarantees of 99.95% uptime and emergency switching (<EUR 1M per incident, capped EUR 10M from the EUR 120M clearing allocation).
- Draft a 2-week rapid-deployment standards-finalisation sequence (detailed specs, stakeholder validation, formal vote) to be activated immediately post-Regulation adoption (target Months 6–7 = 2027-04-08 to 2027-05-08) to compress the Month 7–18 (2027-05-08 to 2028-04-08) finalisation window if adoption is delayed.
- Initiate supplier RFPs for the shared data layer (API hosting, availability cache, 24/7 operations centre, neutral operator) by Month 2 (2026-12-08); award by Month 6 (2027-04-08); establish technical SLAs (p95 latency <2s, uptime 99.95%, at least 500 req/s per corridor, hub uptime 99.9%, <2h recovery, inventory <5min, disruption <2min).
- Commission an independent evaluator by Month 3 (2027-01-08) to design a counterfactual measurement methodology (using comparison routes outside the rollout corridors) to separate programme effects from fuel prices, aviation taxes and capacity changes; deliver the validated baseline by Month 9 (2027-07-08); mandate carrier and distributor reporting templates monthly from Month 18 (2028-04-08).

## 1.3 Follow Up Consultation

By Month 3 (2027-01-08), review the status of the three critical preconditions: (1) Regulation adoption tracked to Month 8 (2027-06-08) gate with shadow standards pre-work progress; (2) Council delegation secured and Commitment Letters signed; (3) cost model and contingency tiers finalized. Address the killer-application commercial strategy: share customer-research findings and product-design decisions. Review hub procurement, payment accreditation, GDPR/DPA consensus and distributor partnerships. Clarify the post-Month 60 (2031-10-08) funding model decision date (Month 48 = 2030-10-08 target) and any trigger for supplementary budget authority (Month 10 = 2027-08-08 target). Identify any political resistance from incumbents or member states and agree escalation protocols.

## 1.4.A Issue - Killer Application Missing—Competitive Positioning Against Airlines Undefined

The plan lacks a flagship product that makes through-tickets compelling on their own merits. Sum-of-segment fares with no regulated ceilings will rarely beat budget airlines on the competitive short-haul routes (Paris–Brussels–Amsterdam–Köln, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin). The modal-shift planning range (5–15%) is aspirational without proof that travellers prefer a guaranteed connection over separate tickets or flying. This is a core commercial risk: if through-fares do not compete, the 40% target and distributor adoption collapse.

### 1.4.B Tags

- missing-commercial-strategy
- weak-modal-shift-case
- pricing-non-competitive
- airline-undercut-risk

### 1.4.C Mitigation

By Month 3 (2027-01-08), commission customer-research and willingness-to-pay studies on the four priority corridors (Paris–Brussels–Amsterdam–Köln as the lead pilot). Test two flagship products: (1) 'one ticket, guaranteed connection' with 4-hour reroute decision and 10-day refund, plus reduction-card recognition (~10–15% effective discount); (2) air-rail city-pair offer (e.g. Brussels–Barcelona with a connecting flight, priced to beat direct air). Pilot one product on one corridor from Month 9 (2027-07-08) with the consumer app; measure booking intent, completion rate and price sensitivity. If the pilot shows <5% modal shift or <8% through-ticket share by Month 24 (2028-10-08), commission a strategic review (Month 24–27 = 2028-10-08 to 2029-01-08) to consider regulated fare ceilings or subsidised through-fares on competitive routes, accepting antitrust risk or extra budget cost.

### 1.4.D Consequence

Without a compelling product, distributors (Trainline, Omio) lack margin incentive to push through-tickets, smaller carriers see no revenue uplift, and incumbents (DB, SNCF) offer minimal API access. The programme could hit the Month 30 (2029-04-08) API mandate technically but miss the 40% target and halved-complaints goals by Month 60 (2031-10-08), leaving the programme seen as a technical exercise, not a passenger win.

### 1.4.E Root Cause

The plan prioritizes structural delivery (standards, APIs, clearing, governance) over customer value proposition. Commercial strategy, pricing rules and product design are delegated to later phases ('high levers refine...fares') rather than locked in early as the basis for carrier and distributor buy-in. Modal shift is stated as an outcome without evidence-based willingness to pay or customer research anchoring the feasibility.

## 1.5.A Issue - Arbitration Panel Lacks Real Enforcement Power; Incumbent Resistance Not Mitigated

The plan's arbitration panel is described as holding 'binding technical-decision authority' with '60-day cycles' and '14-day compliance deadlines,' yet the governance prerequisite is only 'written Council delegation by Month 2 (2026-12-08).' No mechanism exists to compel compliance from major carriers (Deutsche Bahn, SNCF, ÖBB). The penalty structure (0.5–1% of quarterly through-ticket revenue in escrow) is toothless against a carrier that refuses the Commitment Letter or contests the panel's authority. If DB or SNCF signals non-compliance or seeks exemptions, the panel becomes advisory, the Month 30 (2029-04-08) API mandate becomes unenforceable, and the entire network fragments.

### 1.5.B Tags

- governance-enforcement-gap
- incumbent-resistance-unmitigated
- penalty-insufficient
- authority-not-durable

### 1.5.C Mitigation

By Month 1.5 (2026-11-23), secure an explicit Council Regulation or Delegated Act (not just a letter) that designates the arbitration panel as a binding dispute-resolution body with force-of-law recognition across all member states. Include a compliance-escalation protocol: (1) first non-compliance = written notice + 5-day cure; (2) second = 1% of annual cross-border revenue withheld by paying carriers (held in escrow) until compliance; (3) third = Commission enforcement action (Article 258 TFEU or targeted sanctions). Require all carriers >EUR 50M annual revenue to sign the Commitment Letter by Month 3 (2027-01-08); if a major carrier refuses, escalate to DG MOVE for political intervention (Minister of Transport level) by Month 2.5 (2026-12-23). Conduct a dry-run arbitration case (e.g. access-term dispute) in Months 6–9 (2027-04-08 to 2027-07-08) to test the panel's speed and enforce compliance; publicize the outcome to signal credibility.

### 1.5.D Consequence

Without durable enforcement, large incumbents can contest arbitration rulings, delay or refuse API exposure, and negotiate their own 'special' access terms. Smaller carriers comply and lose competitive position. The network becomes two-tier: fast carriers with good APIs, slow carriers gatekept by non-compliance. The Month 30 (2029-04-08) API mandate becomes a best-effort guideline, and distributor complaints do not fall to the halved target.

### 1.5.E Root Cause

Empty

## 1.6.A Issue - Budget Fragility: 20–30% Overrun Exceeds Contingency; Carrier Co-Funding Demand Not Modelled

The plan allocates EUR 1,500 million (public cap) with a EUR 215 million free contingency (15%), but the budget lines for carrier co-funding (EUR 290 million, ~19% of cap) and reference distributor (EUR 215 million, ~14%) are highly uncertain. Hub operating-cost gaps (~EUR 1.9M/year or EUR 9.5M over 5 years), payment-provider fee subsidies (EUR 15M for Months 0–24 = 2026-10-08 to 2028-10-08), and passenger-rights claims (EUR 10–40M estimate) are buried in allocations. If smaller carriers demand 25% more co-funding than budgeted, or if distributor retail operations expand beyond EUR 215M, a 20–30% overrun (EUR 300–450M) would exceed the EUR 215M free contingency by EUR 85–235M. The plan assumes a supplementary authority of EUR 100–200M, but this is contingent on DG MOVE securing it by Month 12 (2027-10-08), which is not guaranteed.

### 1.6.B Tags

- budget-fragility
- carrier-cofunding-uncertain
- contingency-insufficient
- supplementary-authority-risky

### 1.6.C Mitigation

By Month 2 (2026-12-08), commission an independent cost model specifying: (1) per-carrier integration cost (hub vs. native, legacy age, IT staff size); (2) hub opex and fee-revenue forecast per hub; (3) distributor full-retail vs. reference-implementation cost over Months 0–60 (2026-10-08 to 2031-10-08) and post-Month 60 (2031-10-08) annually; (4) payment-fee exposure and subsidy cliff at Month 24 (2028-10-08); (5) claims-processing infrastructure and passenger-rights insurance. By Month 3 (2027-01-08), establish monthly spend-burn dashboards with automatic escalation when quarterly spend exceeds 115% of pro-rata; define Tier 1 (10–15% overrun), Tier 2 (15–25%), and Tier 3 (>25%) contingency actions and assign budget cuts (e.g. defer consumer-app features, reduce distributor co-marketing, cap hub openings to priority corridors). By Month 1 (2026-11-08), initiate pre-negotiation with DG MOVE and the Commission for a supplementary budget decision by Month 10 (2027-08-08) (not Month 12 = 2027-10-08), requesting EUR 150–250M standby authority if Tier 2+ is triggered. If supplementary authority is not secured by Month 10 (2027-08-08), activate Tier 3 cuts at Month 12 (2027-10-08) to protect conformance testing and Month 30 (2029-04-08).

### 1.6.D Consequence

If carrier co-funding demand peaks at 25–30% of budgeted value and the distributor retail model costs overrun by 20%, the free contingency is exhausted by Month 24 (2028-10-08). Conformance testing (EUR 100M of the EUR 280M standards allocation) must be cut to fund overruns, delaying carrier readiness and pushing the Month 30 (2029-04-08) API mandate to Month 33–36 (2029-07-08 to 2029-10-08). If payment-provider accreditation costs exceed budget or a provider fails and emergency switching is needed (up to EUR 10M), free contingency is fully consumed, and any further shock (hub outage, distributor app failure, claims spike) forces unplanned cuts that fragment the programme.

### 1.6.E Root Cause

Empty

---

# 2 Expert: EU Competition Law and Digital Markets Counsel

**Knowledge**: Articles 101/102 TFEU, Digital Markets Act, block exemptions, joint ventures in infrastructure, data-sharing governance

**Why**: Decision 13 (Competition-Law Firewalls for Shared Fare and Inventory Data) is a critical legal constraint. The programme's shared data layer exposes commercially sensitive fares, load factors and sales volumes among competing carriers. The choice between data minimisation, neutral-operator model, or formal Commission block exemption directly affects feasibility and execution timeline; a block exemption route could delay standards by 6-12 months.

**What**: Assess the antitrust exposure of the three data-sharing options, advise on whether the neutral-operator model or data minimisation suffices, and forecast the timeline and success likelihood of a block-exemption request if the programme seeks formal clearance.

**Skills**: EU competition law, block exemptions for infrastructure, data-governance safeguards, liaison with DG COMP, antitrust risk in multi-operator platforms

**Search**: EU competition law counsel, block exemption specialist, digital infrastructure data sharing, TFEU 101-102

## 2.1 Primary Actions

- Secure written Council/Commission Delegation of Authority for the arbitration panel by Month 2 (2026-12-08)—target Month 1.5 (2026-11-23)—with binding technical-decision authority, 60-day cycles, 14-day compliance deadlines, and force-of-law recognition across all member states. Ensure Non-Compliance Consequences Protocol (graduated penalties from 0.5–1% escrow) is signed by all participating carriers >EUR 50M annual cross-border revenue by Month 3 (2027-01-08).
- Commission a detailed activity-based cost model (EUR 1.5B allocation) by Month 0.5 (2026-10-23); deliver by Month 2 (2026-12-08). Establish monthly burn-rate dashboards with 115% pro-rata trigger by Month 3 (2027-01-08). Define and operationalise Tier 1–3 contingency actions. Secure DG MOVE commitment to seek EUR 100–200M supplementary budget authority by Month 12 (2027-10-08) if Tier 2 is triggered.
- Define and pilot a flagship through-ticket product (guaranteed-connection ticket, air-rail city-pair, or reduction-card bundled offer) on one high-demand corridor by Month 6 (2027-04-08). Commission a willingness-to-pay study (Months 1–3 = 2026-11-08 to 2027-01-08) to confirm fares can undercut budget airlines. If modal shift is <8% at Month 24 (2028-10-08), escalate and prepare a contingency decision (regulated fare ceilings or subsidised through-fares) for Month 30 (2029-04-08).
- Establish direct liaison with the European Parliament TRAN/IMCO rapporteurs and key member-state transport ministers (Germany, France, Belgium, Austria, Spain) by Month 0.5 (2026-10-23). Track Regulation adoption probability weekly. Commission shadow standards pre-work (5–8 FTE, Month 0 = 2026-10-08) to analyse the Commission's proposed text against OSDM v2.1 and draft candidate standards on access terms, settlement and passenger rights. If adoption slips past Month 8 (2027-06-08), contract an external standards consortium by Month 8.5 (2027-06-23) for accelerated standards drafting (6–8 week compression).
- Issue RFP for regional hub operators by Month 0.5 (2026-10-23) specifying 4–6 hubs with 99.9% uptime, <2-second latency, <2-hour recovery, and ≥10,000 bookings/day capacity. Award contracts by Month 3 (2027-01-08); hubs operational by Month 9 (2027-07-08). Conduct joint technical integration workshops (Month 4 = 2027-02-08) with eligible legacy-system carriers; complete pilot testing and resolve mapping errors by Month 18 (2028-04-08).

## 2.2 Secondary Actions

- Commission a comprehensive Data Protection Impact Assessment (DPIA) by Month 1 (2026-11-08); map all PII flows across ≥5 data controllers and identify minimum-necessary PII per transaction type. Engage the EDPB and 6–8 national DPAs by Month 3 (2027-01-08) to achieve written consensus on SCCs, data residency, and consent regimes by Month 4 (2027-02-08). Separate accessibility data governance under GDPR Article 9; define retention as <90 days post-journey (12 months if refund pending).
- Establish a Standing Regulators Committee (Month 1.5 = 2026-11-23) with explicit enforcement authority; meet monthly from Month 2 (2026-12-08). Conduct regulator-capacity audit (Month 2 = 2026-12-08); prioritise 8–12 weaker-capacity member states. Establish twinning partnerships by Month 4 (2027-02-08) pairing strong regulators with weaker ones; run 3–4 week training courses (Months 6–12 = 2027-04-08 to 2027-10-08). Define enforcement SLAs: access disputes resolved ≤30 days (≤60 max), refund claims ≤10 days.
- Launch payment-institution accreditation: market sounding Months 0–1 (2026-10-08 to 2026-11-08); call for applicants Month 2 (2026-12-08); decision Month 8 (2027-06-08). Target ≥2 accredited providers live by Month 12 (2027-10-08). Cap transaction fees at 0.3–0.5% (not exceeding 0.7%); subsidise 60% of fees in Months 0–24 (2026-10-08 to 2028-10-08), capped at EUR 15M.
- Establish passenger-rights backstop and liability framework by Month 3 (2027-01-08): single contact (distributor), reroute decision <4 hours, refund <10 days. Require all operational entities to carry liability insurance (errors-and-omissions EUR 2–10M, cyber EUR 1–5M, business-interruption EUR 0.5–2M) by Month 4 (2027-02-08). Pilot refund process on one corridor by Month 15 (2028-01-08); if claim resolution >15 days or dispute rate >5%, escalate and refine procedures.
- Hire PMO staff (10–15 FTE, Month 2 = 2026-12-08), consumer product team (20–30 FTE, from Month 1 = 2026-11-08), arbitration panel (8–12 FTE), and 5 regional support coordinators based in central/eastern Europe (Month 4 = 2027-02-08). Build and test public consumer app MVP on one corridor (Month 9 = 2027-07-08); launch public app Month 15 (2028-01-08); require satisfaction ≥4.0/5 at Month 18 (2028-04-08) or pause rollout.
- Commission outcome evaluation: hire independent evaluator (Month 3 = 2027-01-08); establish baseline of cross-border sales, complaints and modal split by Month 9 (2027-07-08). Define through-ticket and measurement methodology; implement carrier/distributor reporting templates (monthly from Month 18 = 2028-04-08). Establish interim gate: ≥15% through-ticket share by Month 24 (2028-10-08); if missed, escalate and revise commercial strategy.

## 2.3 Follow Up Consultation

Next meeting should resolve: (1) Which flagship through-ticket product (guaranteed connection, air-rail city-pair, accessibility-focused journey) will drive modal shift, and what willingness-to-pay data supports fares that beat airlines? (2) Has DG MOVE secured commitment from the Council or Commission for written delegation to the arbitration panel by Month 1.5 (2026-11-23), or is this a political risk? (3) Who holds budget reallocation authority if Tier 2–3 contingencies are triggered, and what is the escalation path to secure supplementary funding if the free contingency (EUR 215M) is exhausted? (4) When will the Regulation be adopted, and has shadow standards pre-work begun? (5) What is the realistic cost per carrier for hub integration, and how many of the 12–18 eligible carriers will actually participate given budget constraints?

## 2.4.A Issue - Killer Application Missing—Fares Won't Beat Airlines Without Explicit Competitive Positioning

The plan targets 40% through-ticket share and 5-15% modal shift from air, yet the through-fare rule is 'sum of segment prices with no regulated ceilings.' This means passengers see uncompetitive prices versus budget airlines on short-haul routes—the very corridors where modal shift matters most. Without a flagship product (e.g. guaranteed-connection ticket, air-rail city-pair, or reduction-card bundling), the plan relies on convenience alone, which is insufficient. A 15% modal shift requires fares that beat airlines on 2-3 key corridors, not aspirational convenience.

### 2.4.B Tags

- weak_value_proposition
- modal_shift_unachievable
- through_fare_uncompetitive
- missing_killer_application
- airline_competition

### 2.4.C Mitigation

Define and pilot a flagship through-ticket product on one high-demand corridor (e.g. Paris–Brussels–Amsterdam–Köln) by Month 6 (2027-04-08). Propose: 'One ticket, guaranteed connection' with <4-hour reroute decision, 10-day refund, and reduction-card recognition honoured cross-border (10-15% effective discount). Run a willingness-to-pay study (Months 1-3 = 2026-11-08 to 2027-01-08) to confirm fares can undercut airlines. Pilot the product on one corridor (Month 9 = 2027-07-08) and launch with the public app (Month 15 = 2028-01-08). If modal shift is below 8% at Month 24 (2028-10-08), escalate and consider regulated fare ceilings (pending competition-law review) or subsidised through-fares as a contingency decision by Month 30 (2029-04-08).

### 2.4.D Consequence

Without a competitive through-fare or killer application, passengers default to separate tickets or flying. The 40% target and modal-shift planning range will be missed, eroding programme credibility and downstream funding justification. Distributor interest and consumer-app adoption will plateau below 15% by Month 24 (2028-10-08), requiring budget reallocation and scope cuts (Tier 2-3 contingency). Post-Month 60 (2031-10-08) political support for sustained operation funding (EUR 45M/year unfunded) will evaporate.

### 2.4.E Root Cause

The plan treats through-ticketing as a technical and convenience problem, not a commercial one. The regulatory mandate (non-discriminatory access) and the cargo system (OSDM, clearing, hubs) are sound, but they do not inherently create a product passengers prefer over existing alternatives. Fares are left to carriers' segment pricing, which maximises revenue per leg, not per journey. No explicit analysis of price elasticity, airline response or willingness-to-pay grounds the 40% and 5-15% targets.

## 2.5.A Issue - Arbitration Panel Lacks Binding Enforcement Power Over Major Incumbents—Relies on Unconfirmed Council Delegation

The plan hinges on a time-boxed arbitration panel with binding decision authority by Month 2 (2026-12-08). However, no written Council/Commission delegation has been secured, and large carriers (Deutsche Bahn, SNCF, ÖBB) can contest rulings or demand exemptions. Without formal authority grounded in law, the panel is advisory. Commitment Letters with escrow penalties (0.5–1% of quarterly revenue) are proposed but not yet signed; incumbents can refuse without consequence. If the panel cannot force a major carrier to expose APIs or accept settlement rules by Month 30 (2029-04-08), the through-ticket network fragments, and the 40% target collapses.

### 2.5.B Tags

- governance_authority_gap
- incumbent_resistance
- unconfirmed_delegation
- enforcement_power_absent
- month_2_prerequisite_at_risk

### 2.5.C Mitigation

Secure written Council Delegation of Authority by Month 2 (2026-12-08)—target Month 1.5 (2026-11-23)—specifying binding technical-decision authority with 60-day cycles and 14-day compliance deadlines; include force-of-law language so panel rulings are recognised across all member states without re-litigation. Establish a Non-Compliance Consequences Protocol by Month 2.5 (2026-12-23) with graduated penalties: first violation = notice + 48-hour cure; second = 0.5% of quarterly through-ticket revenue in escrow; third = 1% of annual cross-border revenue withheld. Require all carriers >EUR 50M annual cross-border revenue to sign binding Commitment Letters by Month 3 (2027-01-08); negotiate personally with SNCF, Deutsche Bahn and ÖBB leadership (Month 2–2.5 = 2026-12-08 to 2026-12-23) to achieve buy-in. Establish a Standing Regulators Committee (Month 1.5 = 2026-11-23) with explicit enforcement authority in their jurisdictions.

### 2.5.D Consequence

Without written delegation and penalties, the panel is toothless. Major carriers contest rulings (e.g. on API access terms or settlement apportionment), delaying compliance by 6–12 months past Month 30 (2029-04-08). Smaller carriers and distributors lose confidence. The through-ticket network goes live unevenly; only compliant carriers participate, fragmenting coverage. The 40% target becomes unachievable (realistic: 10–15%). Month 30 (2029-04-08) mandatory API exposure becomes advisory. The programme degenerates into voluntary opt-in, and incumbent carrier control over distribution is reinstated.

### 2.5.E Root Cause

The plan assumes governance authority without securing it. The proposed Regulation (adopted status unclear) and the arbitration panel's legal grounding are prerequisites, not outcomes. The plan cites 'existing EU institutional procedures' and 'advisory working groups' but provides no escalation path when incumbents resist. Commitment Letters are contractual but lack legal remedy if a carrier refuses. The root cause is underestimating the political and legal effort needed to bind large incumbents in a multi-member-state regime.

## 2.6.A Issue - Budget Fragility: 20–30% Overrun Exceeds Free Contingency and Threatens Core Milestones

The EUR 1,500 million cap (user constraint) includes EUR 225 million contingency (15%). Free contingency is EUR 215 million (EUR 225M – EUR 10M earmarked for passenger-rights residual). A realistic 20–30% overrun (EUR 300–450M) exceeds the free contingency by EUR 85–235M. Sources of overrun: (1) Carrier co-funding demand: if 15–18 carriers seek hub assistance, costs could reach EUR 50–80M (vs. EUR 44M budgeted). (2) Distributor operation: if retail scope expands or the public reference distributor runs longer, annual costs could jump 20–30% (EUR 8.6–13M/year × 5 = EUR 43–65M; fits contingency). (3) Payment-institution accreditation and fees: if fewer than 2 providers apply, emergency procurement or fee subsidies could consume EUR 5–10M. (4) GDPR and liability frameworks: unresolved data-protection disputes or insurance gaps could delay core systems by 6–12 months and force rework (estimated EUR 20–40M). Unplanned shortfall of EUR 85–235M has no approved funding route; supplementary budget authority (EUR 100–200M proposed) is outside the cap and not yet secured.

### 2.6.B Tags

- budget_fragility
- contingency_insufficient
- carrier_cofunding_demand_high
- distributor_cost_creep
- payment_provider_risk
- gdpr_rework_risk

### 2.6.C Mitigation

Commission a detailed activity-based cost model by Month 0.5 (2026-10-23); deliver by Month 2 (2026-12-08). Define per-carrier co-funding (EUR 2–8M per SME, EUR 10–15M per mid-size, EUR 0.5–2M per major); hub opex (EUR 5–8M per hub over 5 years); distributor annual cost (EUR 60–100M for retail, EUR 20–30M for reference-only); payment fees (EUR 80–160M over 5 years). Establish monthly burn-rate dashboards (Month 3 = 2027-01-08); trigger at 115% of pro-rata spend with 5-day escalation to DG MOVE. Define Tier 1–3 contingency actions: Tier 1 (10–15% overrun): defer consumer-app polish, cut co-marketing 20%; Tier 2 (15–25%): cut carrier co-funding from 20% to 10%, limit hubs to priority corridors; Tier 3 (>25%): suspend new hub openings, scale capacity building to 3–4 member states only. Hold mid-course reviews at Months 12 and 24 (2027-10-08, 2028-10-08). Secure DG MOVE commitment by Month 3 (2027-01-08) to seek supplementary budget authority (EUR 100–200M) from the Commission by Month 12 (2027-10-08) if Tier 2 is triggered, with pre-agreed escalation language. If a 20–30% overrun occurs and supplementary authority is not granted, trigger Tier 3 and defer TEN-T extension beyond Month 36 (2029-10-08).

### 2.6.D Consequence

Unmanaged budget overrun forces painful mid-course cuts (Tier 2–3): co-funding rates drop, hub coverage fractures, and smaller carriers abandon integration (12–18 carriers estimated eligible; if only 6–8 proceed, 40% target drops to 15–20%). Distributor operations are curtailed, consumer-app launch slips to Month 18–21 (2028-04-08 to 2028-07-08), and advertising budget cuts reduce awareness. Conformance testing and capacity building take the hit first (to protect governance and core data layer), leaving weaker member-state regulators under-resourced and unable to enforce non-discrimination. By Month 30 (2029-04-08), less than 70% of corridor traffic is bookable end-to-end (vs. 90% target), triggering a Commission review and political recrimination. Post-Month 60 (2031-10-08) funding for distributor, hubs and data layer (EUR 45M/year unfunded) remains unresolved, and the system collapses into maintenance mode.

### 2.6.E Root Cause

The plan treats the EUR 1,500M cap as fixed and absolute, yet scopes a multi-billion-euro ecosystem (EUR 0.5–2.0B private carrier IT, plus EUR 45M/year post-Month 60 = 2031-10-08 unfunded). The contingency (EUR 215M free) is 15% of the cap—adequate for a single-workstream project, insufficient for a complex multi-stakeholder programme with unproven cost models. Carrier co-funding, distributor scope and payment-provider fees are estimated but not modelled from real cost data (legislation is still pending, legacy IT maturity is unknown). Budget tiers and contingency responses are defined but not yet tied to specific decision gates; when Tier 2 is triggered, unclear whether programme leadership can enforce cuts without Commission and stakeholder pushback.

---

# 3 Expert: Large Enterprise IT Legacy System Migration Program Director

**Knowledge**: Legacy booking-system modernisation, API gateway design, phased IT integration, carrier IT readiness and change management

**Why**: Decision 4 (Legacy Carrier IT Migration Pathway) selects regional shared hubs as the migration route, with 12-18 carriers (estimated) eligible, hub operational start Month 9 (2027-07-08), and a 2-4 week dual-run pilot in Months 15-18 (2028-01-08 to 2028-04-08). The critical-path risk is high: mapping errors, low API maturity, and weak internal IT capacity among smaller carriers could cause cascading delays. The hub-failure stop threshold (2% booking failure for >1 week) and contingency plan (gateway or bilateral pairing) are underfunded.

**What**: Assess the feasibility of hub onboarding 12-18 carriers in 9-12 months, identify likely technical bottlenecks (network latency, data format mismatches, carrier API maturity), model the dual-run pilot risk, and recommend carrier-specific readiness gates or phased onboarding to protect the Month 30 (2029-04-08) API mandate.

**Skills**: Legacy system API integration, booking-system architecture, phased rollout management, carrier readiness assessment, contingency planning for integration failures

**Search**: legacy IT migration programme director, booking system API integration, carrier IT modernisation, phased rollout management

## 3.1 Primary Actions

- Establish a regulatory adoption task force (Month 0.5 = 2026-10-23) with weekly briefings from Parliament TRAN/IMCO rapporteurs and key member-state ministers; prepare three scenario plans (adoption by Month 9 = 2027-07-08, Month 11–12 = 2027-09-08 to 2027-10-08 with text changes, adoption blocked past Month 12 = 2027-10-08) with pre-drafted standards language for contested areas (liability, data-residency, mandatory API scope) to compress standards-setting if needed.
- Begin parallel Council delegation and carrier negotiations in Month 0 (2026-10-08) (not Month 2–3 = 2026-12-08 to 2027-01-08): draft the Council Delegation of Authority by Month 0.5 (2026-10-23) for pre-clearance, present to member-state legal advisers by Month 1 (2026-11-08), target Council formal adoption by Month 1.5 (2026-11-23); simultaneously conduct bilateral meetings with all carriers above EUR 50M cross-border revenue (Months 0–1 = 2026-10-08 to 2026-11-08) to signal programme seriousness and sketch escrow-penalty regime; escalate immediately to DG MOVE if any major carrier signals non-compliance by Month 2 (2026-12-08).
- Establish a carrier co-funding demand model by Month 1 (2026-11-08) with per-carrier integration costs (hub EUR 2–5M, native EUR 10–20M), programme co-funding rates (propose 50% hubs, 20% native), and a quarterly award cap (EUR 10–15M/quarter); make a binding distributor scope decision by Month 2 (2026-12-08) (retail EUR 43–65M/year vs. reference-only EUR 20–30M/year), cap distributor operating cost, and enforce the Tier 1–3 overrun response strictly at 115% of pro-rata spend with monthly dashboards and escalation to DG MOVE.
- Commission a detailed budget cost model by Month 0.5 (2026-10-23) delivered by Month 2 (2026-12-08), specifying hub operating costs, payment-institution fees, smaller-carrier support costs, and distributor annualised operating cost by line item; establish monthly burn-rate dashboards by Month 3 (2027-01-08) with automatic triggers at 115% of budget line and pre-agreed contingency actions (Tiers 1–3) to protect conformance testing and capacity building if overrun.
- Draft a Non-Compliance Consequences Protocol by Month 0–1 (2026-10-08 to 2026-11-08) specifying carrier penalties (first violation = written notice and 48-hour cure, second = 0.5% quarterly through-ticket revenue in escrow, third = 1% annual revenue withheld, escalated to Commission) and commit to escalation to DG MOVE if any carrier refuses to sign Commitment Letters by Month 3 (2027-01-08); use the protocol to drive carrier buy-in during bilateral negotiations (Months 0–1 = 2026-10-08 to 2026-11-08).
- Secure written Council/Commission Delegation of Authority document by Month 1.5 (2026-11-23) (target) specifying that the arbitration panel holds binding technical-decision authority with 60-day cycles, 14-day compliance deadlines, and escalation to the Commission for non-compliance; have DG MOVE and EU Agency for Railways sign an MOU by Month 2 (2026-12-08) specifying panel staffing, budget (EUR 2–3M over five years), and accountability, so the panel can begin operations by Month 3 (2027-01-08).
- Conduct a shadow standards pre-work gap analysis (Month 0 = 2026-10-08) comparing the Commission's proposed Regulation to OSDM v2.1, and draft candidate standards on access-term templates, settlement message formats, passenger-rights protocols, and accessibility requirements; activate a rapid 2-week standards-finalisation sequence immediately post-adoption (targeted Month 6–7 = 2027-04-08 to 2027-05-08) to compress the Month 7–18 (2027-05-08 to 2028-04-08) window; if regulation adoption slips past Month 8 (2027-06-08), contract an external standards-review consortium by Month 8.5 (2027-06-23) for accelerated drafting and carrier workshops by Month 10 (2027-08-08).
- Establish a Standing Regulators Committee by Month 1.5 (2026-11-23) with explicit authority to enforce panel rulings across all 27 member states; meet monthly from Month 2 (2026-12-08) onwards; include enforcement penalties in the committee's terms of reference (EUR 50,000–EUR 500,000 fines for consistent non-compliance by a regulator); require all national regulators to sign an MOU recognising panel rulings without re-litigation by Month 3 (2027-01-08).

## 3.2 Secondary Actions

- Commission a GDPR Data Protection Impact Assessment by Month 1 (2026-11-08) and achieve EDPB/DPA consensus on Standard Contractual Clauses and data-residency rules by Month 4 (2027-02-08); establish a Dispute Resolution Panel by Month 6 (2027-04-08) to rule on contested passenger-rights claims within 5 days; pilot the refund process on one corridor by Month 15 (2028-01-08) to test procedures and resolve timelines if claim resolution exceeds 15 days or dispute rate exceeds 5%.
- Issue an RFP for regional hub operators by Month 0.5 (2026-10-23) covering 4–6 hubs (four priority corridors + 2–3 TEN-T hubs) with 99.9% uptime SLA, under-2-second latency, under-2-hour incident recovery, and capacity of 10,000+ bookings/day; award contracts by Month 3 (2027-01-08); conduct joint technical integration workshops with legacy-system carriers by Month 4 (2027-02-08); schedule mandatory pilot tests by Month 15 (2028-01-08) and complete testing with all hubs by Month 18 (2028-04-08) before conformance testing.
- Hire 3–5 regional smaller-carrier support coordinators (Budapest, Warsaw, Sofia, Bucharest) by Month 4 (2027-02-08) to provide on-site mentoring and integration troubleshooting; budget EUR 1–2M over five years for this team; conduct quarterly readiness reviews with eligible carriers to track hub integration progress and flag slippage early.
- Establish a monthly budget-burn dashboard by Month 3 (2027-01-08) showing cumulative spend vs. pro-rata forecast with automatic triggers if quarterly spend exceeds 115% of budget line; escalate any trigger to DG MOVE within 5 working days; hold mid-course reviews at Months 12 and 24 (2027-10-08, 2028-10-08), and if free contingency falls below EUR 50M by Month 24 (2028-10-08), trigger Tier 2 contingency actions (reduce co-funding to 10%, limit hubs to priority corridors only).
- Run market sounding for accredited payment institutions (Months 0–1 = 2026-10-08 to 2026-11-08) and issue a call for applicants by Month 2 (2026-12-08); make accreditation decisions by Month 8 (2027-06-08); target at least 2 accredited providers operational by Month 12 (2027-10-08); if fewer than 2 applicants by Month 6 (2027-04-08), trigger fallback procurement or bilateral settlement arrangement; cap payment-provider fees at 0.3–0.5% per transaction (not above 0.7%) and subsidise 60% of fees in Months 0–24 (2026-10-08 to 2028-10-08) (capped at EUR 15M).
- Establish a Passenger-Rights Backstop and Liability Framework by Month 3 (2027-01-08) specifying single point of contact (distributor), reroute decision timelines (under 4 hours), refund timelines (under 10 days), and a pooled guarantee fund for insolvent carriers (EUR 5M per carrier per year estimate); require all operational entities (hubs, payment institutions, public distributor, clearing) to carry liability insurance (EUR 2–10M errors-and-omissions, EUR 1–5M cyber, EUR 0.5–2M business interruption) by Month 4 (2027-02-08).
- Conduct a member-state regulator capacity audit by Month 2 (2026-12-08) and identify 8–12 weaker-capacity regulators (Poland, Bulgaria, Romania, Hungary, Slovakia, Slovenia, Croatia, Malta) for twinning partnerships by Month 4 (2027-02-08); define twinning SOW including 3–4 week joint training courses (Months 6–12 = 2027-04-08 to 2027-10-08), shared inspection checklists (Month 8 = 2027-06-08), and quarterly joint reviews of enforcement decisions (starting Month 12 = 2027-10-08); allocate EUR 10–15M over five years for capacity building.
- Define the through-ticket definition (single booking reference + single payment + continuity-of-journey rights) by Month 2 (2026-12-08) and establish a measurement baseline (baseline survey Months 0–2 = 2026-10-08 to 2026-12-08, independent evaluator hired Month 3 = 2027-01-08, validated baseline Month 9 = 2027-07-08); commission an independent evaluator to build a counterfactual using comparison routes outside rollout corridors by Month 3 (2027-01-08) to separate programme effects from fuel prices and aviation taxes; report monthly on through-ticket share, distributor complaints, and modal shift from Month 18 (2028-04-08) onwards.

## 3.3 Follow Up Consultation

At the Month 3 review (2027-01-08), reassess: (1) Regulation adoption probability and any material text changes flagged by Parliament rapporteurs; activate Scenario B or C contingency if adoption probability is below 80% or text diverges on liability, data-sharing, or API scope. (2) Council delegation status and carrier Commitment Letter signatures; if any major carrier has not signed by Month 3 (2027-01-08), escalate to DG MOVE for political intervention or consider contractual enforcement (e.g., contract amendments, CER leverage). (3) Budget burn-rate trends from the first monthly dashboards (Months 0–2 = 2026-10-08 to 2026-12-08); if free contingency burn exceeds 12% annualised rate (implying USD 180M exhaustion by Month 60 = 2031-10-08), trigger early Tier 1 contingency actions (reduce consumer-app polish, defer distributor co-marketing). (4) Hub procurement progress and integration workshop output; flag any hub operator with integration timelines slipping past Month 9 (2027-07-08) for escalation. (5) GDPR consensus status with EDPB and national DPAs; if consensus is not reached by Month 4 (2027-02-08), commission emergency legal workaround (e.g., anonymisation or aggregation protocols) by Month 3 (2027-01-08) to avoid payment-institution accreditation delay. Prepare a revised Month 18 (2028-04-08) gates checklist.

## 3.4.A Issue - Regulation Adoption Gate Is Underspecified and Lacks Contingency Depth

The plan gates the entire programme on Commission Regulation adoption by Month 9 (2027-07-08), with only a binary pause if adoption slips to Month 10 (2027-08-08). This is brittle. If Parliament or Council amends the final text materially (e.g., on liability allocation, data-sharing scope, or mandatory API timelines), the programme's standards and governance assumptions collapse. The shadow standards pre-work mitigates this partially, but it assumes the final text will not diverge significantly. No scenario plan exists for a 3–6 month adoption delay or material text change.

### 3.4.B Tags

- regulatory-gate-fragility
- adoption-delay-cascade
- standards-rework-risk
- contingency-depth

### 3.4.C Mitigation

Establish a weekly adoption-tracking briefing (Months 0–9 = 2026-10-08 to 2027-07-08) with Parliament TRAN and IMCO rapporteurs and member-state transport ministers; identify blocking amendments by Month 4 (2027-02-08). Commission three scenario plans now: (a) adoption by Month 9 (2027-07-08) (baseline), (b) adoption by Month 11–12 (2027-09-08 to 2027-10-08) with text changes (compress standards to Months 9–17 = 2027-07-08 to 2028-03-08, absorb 1-month slip), (c) adoption blocked or deferred past Month 12 (2027-10-08) (pause programme, re-baseline in Month 12 = 2027-10-08, restart with compressed critical path if green-light given). For each scenario, pre-draft standards language for the most likely contested areas (liability, data-residency, mandatory API scope). Assign a senior DG MOVE liaison to Parliament by Month 1 (2026-11-08).

### 3.4.D Consequence

Without contingency depth, a 2–3 month adoption delay forces compressed standards-setting (3–4 months instead of 9), eliminating stakeholder consensus and risking non-compliant or fragile standards by Month 18 (2028-04-08). A material text change (e.g., stricter liability or narrower data-sharing) could invalidate the clearing and settlement design by Month 12 (2027-10-08), requiring 3–6 month rework that threatens Month 30 (2029-04-08) API mandate. The programme would slip or fail credibility.

### 3.4.E Root Cause

The plan treats regulation adoption as a calendar gate rather than a design assumption with built-in contingencies. The shadow standards pre-work is defensive but does not plan for adoption delay or text divergence. No explicit scenario planning for Parliament or Council amendments. Assumption that final text will track the May 2026 proposal is unvalidated and risky at this programme scale.

## 3.5.A Issue - Arbitration Panel Authority Lacks Explicit Enforcement Mechanism and Carrier Buy-In at Month 0 (2026-10-08)

The plan requires written Council delegation by Month 2 (2026-12-08) and carrier Commitment Letters by Month 3 (2027-01-08) with escrow penalties (0.5–1% of quarterly through-ticket revenue). This is sequential, not parallel. If the delegation is delayed past Month 2 (2026-12-08) or carriers (SNCF, Deutsche Bahn) refuse to sign by Month 3 (2027-01-08), the panel has no enforcement leverage for the Month 18 (2028-04-08) standards deadline. No escalation protocol exists if a major carrier contests a panel ruling. The Standing Regulators Committee is a side mechanism that does not bind carriers directly.

### 3.5.B Tags

- governance-enforcement-gap
- carrier-commitment-risk
- sequential-dependencies
- incumbent-resistance

### 3.5.C Mitigation

Begin parallel delegation and carrier negotiations in Month 0 (2026-10-08), not sequentially at Months 2–3 (2026-12-08 to 2027-01-08). Draft the Council delegation document by Month 0.5 (2026-10-23) and present it to DG MOVE and relevant member-state legal advisers for pre-clearance; target formal Council adoption by Month 1.5 (2026-11-23) (not Month 2 = 2026-12-08). Simultaneously, convene bilateral meetings with each carrier above EUR 50M cross-border revenue (SNCF, DB, ÖBB, Trenitalia, Renfe, NS, SJ) in Months 0–1 (2026-10-08 to 2026-11-08) to signal the programme's seriousness and sketch the escrow-penalty regime. Use CER as a facilitator. If any carrier signals non-compliance by Month 2 (2026-12-08), escalate immediately to DG MOVE for political negotiation (do not wait until Month 3 = 2027-01-08). Draft a Non-Compliance Consequences Protocol now (Months 0–1 = 2026-10-08 to 2026-11-08) specifying escalation to the Commission and potential financial/regulatory sanctions (not just escrow), so carriers understand real jeopardy.

### 3.5.D Consequence

If delegation is delayed past Month 2 (2026-12-08) or carriers do not sign by Month 3 (2027-01-08), the panel's rulings from Month 4 (2027-02-08) onwards are advisory, not binding. Major incumbents can delay or contest standards decisions, fragmenting the network and pushing Month 18 (2028-04-08) past feasibility. If SNCF or DB refuse escrow penalties, the only enforcement is Commission enforcement action (6–12 months), which is too slow for the critical path. The Month 30 (2029-04-08) API mandate becomes unenforceable.

### 3.5.E Root Cause

The plan treats governance delegation and carrier commitment as independent parallel actions, but they are sequentially dependent: carriers will not sign until they see the delegation is real and has teeth. No escalation protocol exists for non-compliance in Months 0–3 (2026-10-08 to 2027-01-08). Assumption that carriers will sign by Month 3 without early political engagement is optimistic.

## 3.6.A Issue - Budget Contingency Framework Is Insufficient for Carrier Co-Funding and Distributor Scope Creep

The plan allocates EUR 290M for carrier co-funding (EUR 234M grants + EUR 44M hubs) and holds EUR 215M free contingency. Carrier co-funding is demand-driven: as smaller carriers request help, the cost could grow. Distributor scope is also underspecified (retail vs. reference-only), and operating cost could vary from EUR 43M/year to EUR 100M/year or more. If carrier co-funding demand reaches 25–30% of the budget (EUR 375–450M) or distributor costs slip to EUR 65M/year, the EUR 215M contingency is exhausted by Month 24 (2028-10-08), forcing cuts to conformance testing, data-layer ops, or capacity building—all critical path items.

### 3.6.B Tags

- budget-fragility
- demand-driven-costs
- distributor-scope-creep
- contingency-exhaustion

### 3.6.C Mitigation

Establish a detailed carrier co-funding demand model by Month 1 (2026-11-08): for each eligible carrier (12–18 estimate), define the IT cost to integrate (hub integration ~EUR 2–5M per carrier, native build ~EUR 10–20M), what the programme will co-fund (propose 50% for hubs, 20% for native builds), and what the carrier must fund privately. Set a quarterly cap on new co-funding awards (propose EUR 10–15M/quarter, adjustable by DG MOVE). For distributor scope, make a binding decision by Month 2 (2026-12-08): retail service (EUR 43–65M/year, ~EUR 215–325M total) or reference-implementation only (EUR 20–30M/year, ~EUR 100–150M total). If retail is chosen, cap operating cost at EUR 50M/year with a sunset review at Month 36 (2029-10-08). Apply the Tier 1–3 overrun response strictly at 115% of pro-rata spend (not 120%), with escalation to DG MOVE for any quarterly overspend above 10%. Hold mid-course reviews at Months 12 and 24 (2027-10-08, 2028-10-08), and if free contingency is below EUR 50M by Month 24 (2028-10-08), trigger Tier 2 cuts (reduce co-funding to 10%, limit hubs to priority corridors only).

### 3.6.D Consequence

Without a capped co-funding model and clear distributor scope, the budget can slip by EUR 100–200M by Month 24 (2028-10-08), forcing cuts to conformance testing (pushes Month 18 = 2028-04-08 standards), data-layer ops (API failures and missed-connection detection), or capacity building (leaves weak regulators unable to enforce). Uncontrolled distributor scope creep (EUR 65–100M/year) consumes EUR 325–500M over five years, exceeding the free contingency by Month 20 (2028-06-08) and eliminating margin for other critical items. The programme would fail to fund core infrastructure.

### 3.6.E Root Cause

Carrier co-funding is demand-driven without a pre-set cap or allocation model. Distributor scope and cost were not resolved in the strategic decisions (Decision 6 lists three options but leaves the choice to the plan). The Tier 1–3 contingency framework is defined but not enforced with monthly dashboards or escalation triggers. Assumption that co-funding will track the EUR 234M estimate and distributor will cost EUR 43M/year is not validated.

---

# 4 Expert: Cross-Border Rail Passenger Rights and Liability Framework Specialist

**Knowledge**: EU rail passenger rights regulations, multi-carrier liability allocation, refund processing, accessibility duties, regulatory enforcement across member states

**Why**: Decision 8 (Passenger-Rights Backstop and Liability Allocation) assigns the selling distributor as the single point of contact for rerouting and refunds, with costs recovered from liable carriers via the clearing mechanism. The passenger-rights backstop relies on timelines (reroute <4 hours, refund <10 days), a claim rate (3-5%, EUR 10-40M over 5 years estimated), and consistency across member states with uneven regulator capacity. The liability insurance framework and dispute-resolution procedures are not fully specified; GDPR and cross-border enforcement ambiguities could delay accreditation and block the data layer.

**What**: Validate the liability-allocation model against the revised EU rail passenger rights rules, advise on insurability and cost sufficiency, map the dispute resolution and enforcement procedures needed to meet the 10-day refund SLA across all 27 member states, and identify GDPR and data-residency obstacles to cross-border refund processing.

**Skills**: EU rail passenger rights law, multi-operator liability allocation, insurance design and actuarial validation, dispute resolution procedures, GDPR in refund processing

**Search**: rail passenger rights specialist, EU liability allocation, cross-border refund processing, accessibility compliance

## 4.1 Primary Actions

- Secure written Council and Commission Delegation of Authority for the arbitration panel's binding decision-making (60-day cycles, 14-day compliance deadlines, 0.5-1% quarterly through-ticket revenue escrow penalties) by Month 1.5 (2026-11-23, 10:00). Include force-of-law language ensuring panel rulings are recognised across all member states without re-litigation. Commission internal legal review by Month 1 (2026-11-08) and finalize the Memorandum of Understanding (MOU) between DG MOVE, EU Agency for Railways and the panel by Month 2 (2026-12-08, 12:00).
- Require all carriers with >EUR 50 million annual cross-border revenue to sign binding Commitment Letters by Month 3 (2027-01-08, 15:00), accepting arbitration outcomes and escrow penalties for non-compliance. Designate DG MOVE as the owner; use CER quarterly meetings (December 2026, February 2027, April 2027) to collect signatures and negotiate with incumbents (SNCF, Deutsche Bahn, ÖBB, Renfe, Trenitalia). Escalate to the Commission if any carrier >EUR 100 million revenue refuses by Month 2.5 (2026-12-23, 12:00).
- Commission an independent cost-modelling firm by Month 0.5 (2026-10-23, 11:00) to produce a detailed activity-based budget forecast by Month 2 (2026-12-08, 17:00), specifying: carrier co-funding per carrier type (EUR 2-8M per SME legacy operator, EUR 10-15M per mid-size, EUR 0.5-2M per major), hub operating cost per hub (EUR 5-8M over five years), public distributor annual operating cost (EUR 60-100M/year for retail, EUR 20-30M/year for reference-implementation only), and payment-institution transaction-fee exposure (EUR 80-160M over five years at baseline 0.5-1.0% per transaction). Establish monthly budget-burn dashboards by Month 3 (2027-01-08, 10:00) with automatic 115% trigger and Tier 1-3 contingency actions pre-approved by DG MOVE.
- Establish direct weekly liaison with the European Parliament's TRAN and IMCO rapporteurs and key member-state transport ministers (Germany, France, Belgium, Austria, Spain) by Month 0.5 (2026-10-23, 09:00) to track Regulation adoption status and political signalling. Commission a shadow standards pre-work team (5-8 FTE, EUR 2-3 million budget) by Month 0 (2026-10-08, 14:00) to conduct gap analysis between the Commission's proposed Regulation text and OSDM v2.1 specifications, and draft candidate standards on access-term templates, settlement message formats and passenger-rights protocols. If adoption probability falls below 60% by Month 6 (2027-04-08, 17:00) or Parliament's amendments conflict materially with OSDM or the clearing model, escalate to the Commission and trigger a Decision Gate to pause carrier onboarding or re-baseline the critical path.
- Engage the 3-4 strictest national DPAs (Austria, Germany, Poland, France) by Month 1 (2026-11-08) with a pre-scoped Data Architecture White Paper specifying PII fields per transaction type, cross-border transfer mechanisms, data residency options and retention periods. Secure written non-objection from at least 4 national DPAs by Month 3.5 (2027-01-23) before standards drafting locks. Request a formal competition-authority comfort letter from DG COMP by Month 2 (2026-12-08, 15:00) specifying permissible data scope (baseline: real-time seat availability, historical load factors, aggregate sales volume; prohibited: individual carrier pricing algorithms). Embed DPA conditions and competition limits in the Month 18 (2028-04-08) binding standards; if a conflict is identified by Month 12 (2027-10-08), trigger a 4-week emergency re-baseline led by the arbitration panel.
- Commission a fault-allocation engineering study by Month 3 (2027-01-08) defining a matrix specifying which carrier pays for missed connections (carrier A late → carrier A pays; carrier B platform miss → carrier B pays; shared delay → proportional split based on timetable adherence). Embed insurance requirements (EUR 2-10M errors-and-omissions per operational entity) in the conformance checklist by Month 4 (2027-02-08) and verify coverage before any hub or distributor goes live. Establish a Dispute Resolution Panel with rotating carrier and distributor representatives, empowered to rule on contested claims within 5 business days; set dispute-rate SLA (target <5% of claims escalated). Clarify by Month 2 (2026-12-08) that the EUR 10 million reserve inside the EUR 225 million contingency covers unrecovered first-level refunds; if claim volume exceeds 3-5% baseline (stress case 8-10%), trigger Tier 2 contingency or request supplementary authority.

## 4.2 Secondary Actions

- Issue a Request for Proposals (RFP) for regional hub operators by Month 0.5 (2026-10-23, 09:00) specifying: 4-6 hubs covering the four priority corridors plus 2-3 additional hubs for TEN-T extension, operational start date no later than Month 9 (2027-07-08, 12:00), SLAs of 99.9% uptime, <2-second latency, <2-hour incident recovery, and capacity ≥10,000 bookings/day per operator. Close RFP and award contracts by Month 3 (2027-01-08, 17:00). Schedule mandatory pilot tests of each hub's integration with 2-3 eligible carriers by Month 15 (2028-01-08, 10:00); complete testing and resolve mapping errors by Month 18 (2028-04-08, 14:00) before conformance testing begins.
- Conduct joint technical integration workshops pairing hub operators and eligible legacy-system carriers (criteria: annual cross-border revenue <EUR 50M, booking-system age >10 years, or IT staff <10 FTE) by Month 4 (2027-02-08, 15:00), identifying network latency, API compatibility and data-format mismatches. Allocate EUR 5-10 million for hub resilience and capacity upgrades (Months 6-18 = 2027-04-08 to 2028-04-08). Hire 3-5 regional support coordinators (based in Budapest, Warsaw, Sofia, Bucharest) by Month 4 (2027-02-08, 12:00) to provide on-site mentoring and integration troubleshooting for smaller carriers; budget EUR 1-2 million over five years.
- Launch the payment-provider accreditation process by Month 2 (2026-12-08): issue market-sounding RFI to identify applicants, specify PSD2 licensing requirements, settlement message standards, fraud prevention and SLA commitments (99.95% uptime, <48-hour settlement). Release the formal call for applicants by Month 2 (2026-12-08) with decision by Month 8 (2027-06-08). Require at least 2 accredited providers operational by Month 12 (2027-10-08). If fewer than 2 providers apply by Month 6 (2027-04-08), activate the fallback: bilateral carrier settlement or emergency procurement; budget EUR 5-10 million for provider-switch or backup capacity in the free contingency.
- Define and pilot a flagship 'one ticket, guaranteed connection' product on a single high-demand corridor (e.g., Paris-Brussels-Amsterdam-Köln) by Month 9 (2027-07-08): one booking, one payment, a 4-hour reroute decision, 10-day refund guarantee, and mutual recognition of reduction cards (10-15% effective discount). Conduct customer research and willingness-to-pay studies by Month 6 (2027-04-08) to validate that the product meets traveller preferences against budget airlines and separate-ticket purchasing. Launch the public consumer app with the flagship product by Month 15 (2028-01-08); target pilot satisfaction ≥4.0/5 by Month 18 (2028-04-08) or pause rollout to other corridors.
- Establish a Standing Regulators Committee by Month 1.5 (2026-11-23, 09:00) with explicit power to enforce arbitration panel rulings consistently across all member states; meet monthly starting Month 2 (2026-12-08). Implement twinning partnerships between strong regulators (France, Germany, Netherlands, Austria, Sweden, Belgium) and weaker-capacity regulators (Poland, Bulgaria, Romania, Hungary, Slovakia, Slovenia, Croatia, Malta) by Month 4 (2027-02-08, 14:00). Define enforcement SLAs (access disputes resolved within 30 days, refund claims within 10 days); if a regulator consistently fails SLAs, escalate to the Commission within 5 working days. Allocate EUR 10-15 million over five years for regulator capacity building.
- Embed GDPR compliance rules, accessibility requirements (WCAG 2.1 AA, 24-hour assistance confirmation, >90% confirmation and >95% delivery rates), and liability insurance checks in the conformance checklist by Month 4 (2027-02-08). Define the through-ticket baseline and validation methodology by Month 2 (2026-12-08); commission an independent evaluator by Month 3 (2027-01-08) to build a counterfactual measurement design; validate the baseline by Month 9 (2027-07-08). Implement monthly carrier and distributor reporting from Month 18 (2028-04-08); conduct mid-course reviews at Months 12 and 24 (2027-10-08, 2028-10-08) to check budget burn and through-ticket share trajectory (interim gate: 15% by Month 24 = 2028-10-08).
- Agree the post-Month 60 (2031-10-08) funding and operating model for the distributor, hubs and data layer by Month 48 (2030-10-08). Current estimate: ~EUR 45 million/year unfunded (distributor ~EUR 43M + hub gap ~EUR 1.9M) plus data-layer and regulator costs. Decide whether to: (a) transition to cost-recovery (fee-based distributor, hub usage fees, carrier/distributor settlements), (b) seek supplementary budget authority from the Commission, or (c) sunset the public distributor and consolidate on commercial platforms by Month 60 (2031-10-08). Establish a post-Month 60 (2031-10-08) transition workstream by Month 30 (2029-04-08) with carriers, distributors and DG MOVE to define operating model and governance.

## 4.3 Follow Up Consultation

"At the next consultation, we must resolve: (1) Passenger-Rights Backstop: Does the plan fund an insolvency guarantee pool and fault-allocation disputes, or does liability rest entirely with distributors and carriers? Without clarity, distributors will demand escrow and fragment the network. (2) GDPR and Competition-Law Gating: Will the project lock binding standards at Month 18 (2028-04-08) even if a national DPA or competition authority has not granted written consensus, or will standards remain draft until all legal conditions are satisfied? This defines the real critical path. (3) Regulation Adoption Contingency: If the Regulation is not adopted by Month 9 (2027-07-08), does the programme proceed with shadow standards and risk a non-compliant outcome, or pause and seek supplementary legal authority? A decision gate by Month 7 (2027-05-08) is essential. (4) Hub Economics: The four-hub model estimates EUR 1.9 million/year opex gap (EUR 1.2M/yr opex vs EUR 0.73M/yr fee revenue). Where does this gap close—through fare-sharing adjustments, volume growth, or a decision to sunset hubs post-Month 48 (2030-10-08)? (5) Distributor Scope: Is the public reference distributor a full retail channel (EUR 60-100M/year), a reference implementation only (EUR 20-30M/year), or a last-resort service? The budget implication is EUR 40-80 million over the programme, which tensions with carrier co-funding. Clarify the mandate and lifespan by Month 2 (2026-12-08)."

## 4.4.A Issue - Passenger-Rights Backstop Lacks Funded Guarantee Mechanism and Fault-Allocation Rules

The passenger-rights backstop (Decision 8) assigns the selling distributor as single contact for rerouting and refund, but the plan lacks: (1) a funded guarantee pool for carrier insolvency or cascade failures; (2) a fault-allocation schedule for missed connections specifying which carrier pays when multiple carriers cause a delay; (3) insurance requirements with verified coverage before operational go-live; (4) a dispute-resolution SLA (<5 business days for routine claims). The actuarial study (Month 2 = 2026-12-08) estimates 3-5% claim rate (EUR 10-40M), but without explicit funding within the EUR 1,500 million cap and enforceable fault rules, distributors will decline risky itineraries or claim disputes will consume 5-10% of through-ticket value, undercutting the 40% target.

### 4.4.B Tags

- passenger-rights-unfunded
- fault-allocation-missing
- distributor-liability-asymmetry
- claim-dispute-bottleneck
- insolvency-pool-absent

### 4.4.C Mitigation

By Month 3 (2027-01-08), commission a fault-allocation engineering study defining a matrix (carrier A late: carrier A pays; carrier B platform miss: carrier B pays; shared delay: proportional split based on timetable adherence). By Month 4 (2027-02-08), embed insurance requirements (EUR 2-10M errors-and-omissions per operational entity) in the conformance checklist and verify coverage before any hub or distributor goes live. Establish a Dispute Resolution Panel with rotating carrier and distributor representatives, empowered to rule on contested claims within 5 business days; set a dispute rate SLA (target <5% of claims escalated). By Month 2 (2026-12-08), clarify that the EUR 10 million reserve inside the EUR 225 million contingency covers unrecovered first-level refunds; if claim volume exceeds projections, trigger Tier 2 contingency (rate cuts) or request supplementary authority.

### 4.4.D Consequence

Without funded guarantees and fault rules, distributors will demand escrow or insurance from carriers before selling through-tickets on weaker segments (e.g., small regional operators), which delays onboarding and fragments the network. Claim disputes will lengthen to 30-60 days, eroding passenger trust and reducing repeat through-ticket purchases by 10-20%. A single catastrophic event (carrier insolvency, hub cascade failure) could exhaust the EUR 10 million reserve and force distributor refunds from free contingency, consuming EUR 50-100 million and triggering Tier 3 cuts (suspension of new hub openings). This undermines the Month 30 (2029-04-08) API mandate and the 40% through-ticket target.

### 4.4.E Root Cause

The decision framework (Decision 8 and supporting project plan) assumes the clearing mechanism and accredited payment providers will reverse costs automatically, but does not specify: how fault is determined when multiple carriers share a delay, what happens when a carrier is insolvent or refuses to pay, who funds the gap if claim volume exceeds the 3-5% estimate (stress case 8-10%), or what distributor margin is needed to absorb claim-processing costs. This leaves the backstop as a design aspiration without an operational or financial anchor.

## 4.5.A Issue - GDPR and Competition-Law Firewall Risks Not Anchored to Binding Legal Consensus Before Standards Lock

The plan commits to binding standards by Month 18 (2028-04-08), but GDPR (Decision on DPIA and DPA consensus by Month 4 = 2027-02-08) and competition-law clearance are downstream dependencies. If a national DPA or the EDPB challenges the cross-border data-flow architecture (e.g., requiring data residency in home state, blocking certain PII fields, or demanding consent mechanisms that slow booking), the remediation will require re-engineering the data layer and settlement message formats. This cannot be fixed within the Month 18 (2028-04-08) standards window without compromising either GDPR compliance or standards completeness. Similarly, if the Commission's competition directorate requires data minimisation more strict than the current plan, real-time seat availability for distributors becomes impossible, weakening search quality and the 40% target.

### 4.5.B Tags

- gdpr-residency-blocking-risk
- dpa-consensus-not-locked
- data-minimisation-vs-usability
- standards-lock-before-legal-consensus
- cross-border-data-flow-vulnerability

### 4.5.C Mitigation

By Month 1 (2026-11-08), directly engage the 3-4 strictest national DPAs (Austria, Germany, Poland, France) with a pre-scoped Data Architecture White Paper, specifying: PII fields per transaction type, cross-border transfer mechanisms (SCCs, model contracts, encryption), data residency options (home-state only vs EU-wide cache), and retention periods. Secure written non-objection from at least 4 national DPAs by Month 3.5 (2027-01-23) before standards drafting locks. By Month 2 (2026-12-08), request a formal competition-authority comfort letter from DG COMP specifying permissible data scope (baseline: real-time seat availability, historical load factors, aggregate sales volume; prohibited: individual carrier pricing algorithms, cross-carrier margin data). Embed DPA conditions and competition limits as binding requirements in the Month 18 (2028-04-08) standards; if a DPA or competition authority identifies a blocking conflict by Month 12 (2027-10-08), trigger a 4-week emergency re-baseline led by the arbitration panel.

### 4.5.D Consequence

If a national DPA ban on cross-border data flows is imposed after Month 18 (2028-04-08) standards are locked, the data layer must be re-architected to federated queries only (no central availability cache), which increases search latency by 3-5 seconds per search and degrades distributor and passenger experience. This reduces through-ticket sales by 15-25% on latency-sensitive corridors and delays the Month 30 (2029-04-08) API mandate by 6-12 months. A competition-authority challenge to shared fare data could require delisting pricing and load-factor fields from the shared layer, which weakens distributor ability to offer competitive fares, undermining the 40% target. Re-engineering standards and compliance frameworks post-Month 18 (2028-04-08) will consume EUR 15-30 million and delay payment-institution accreditation, risking Month 12 (2027-10-08) operational deadlines.

### 4.5.E Root Cause

The project plan (Section on Compliance Requirements) treats DPIA and DPA consensus as a separate Months 0-4 (2026-10-08 to 2027-02-08) workstream with no enforcement gate or escalation trigger if DPA feedback contradicts the data architecture already embedded in the Month 18 (2028-04-08) standards. The plan assumes DPA consensus is achievable by Month 4 (2027-02-08) without identifying which national DPAs present the highest risk (Poland, Hungary, Germany, Austria are known to be strict on data sovereignty) or pre-consulting them on the shared-data-layer scope. Competition-authority comfort (proposed for Month 6 = 2027-04-08) comes too late to re-baseline standards if a significant data-minimisation constraint is imposed.

## 4.6.A Issue - Regulation Adoption Risk Compresses Standards Window; No Viable Accelerated Path if Adoption Slips Beyond Month 8 (2027-06-08)

The plan assumes Regulation adoption by Month 9 (2027-07-08), leaving a 9-month standards window (Months 9-18 = 2027-07-08 to 2028-04-08) for drafting, stakeholder consensus and formal approval. If adoption slips to Month 10 (2027-08-08) or later, the window compresses to 6-7 months, eliminating margin for stakeholder iteration and risking non-compliant or consensus-less standards by Month 18 (2028-04-08). The pre-assessment recommends shadow standards pre-work (Month 0-18 = 2026-10-08 to 2028-04-08) to mitigate this, but the project plan does not budget FTE or governance authority for shadow work, does not specify exit criteria if Commission proposals change materially post-publication (May 2026), and does not name the owner or decision-gate responsible for aborting if adoption is not politically viable by Month 7 (2027-05-08).

### 4.6.B Tags

- regulation-adoption-delay-risk
- standards-window-compression
- shadow-standards-governance-gap
- no-go-gate-undefined
- commission-proposal-misalignment

### 4.6.C Mitigation

By Month 0.5 (2026-10-23, 09:00), establish a weekly adoption tracking task led by a dedicated DG MOVE liaison; contact the Parliament TRAN and IMCO rapporteurs, key member-state transport ministers (Germany, France, Belgium, Austria, Spain) and CER weekly to obtain status, identify blocking amendments and signal political feasibility. By Month 0 (2026-10-08, 14:00), commission a shadow standards pre-work team (5-8 FTE, EUR 2-3 million budget over Months 0-9 = 2026-10-08 to 2027-07-08) to conduct gap analysis between the Commission's proposed Regulation and OSDM v2.1, and draft candidate standards on access-term templates, settlement message formats and passenger-rights protocols, without binding the programme until adoption. By Month 6 (2027-04-08, 17:00), convene a Decision Gate with DG MOVE, the arbitration panel and CER: if adoption probability is below 60% or the Parliament's proposed amendments conflict materially with OSDM or the clearing model, escalate to the Commission and decide whether to pause carrier onboarding commitments and re-baseline the critical path. By Month 8 (2027-06-08, 12:00), if adoption is not imminent, contract an external standards-review consortium (cost EUR 1-2 million) to conduct accelerated standards drafting in parallel (compressed 4-6 week finalisation sequence instead of 9 months), accepting technical-consensus and carrier-buy-in risk.

### 4.6.D Consequence

If Regulation adoption slips beyond Month 10 (2027-08-08), the standards window compresses to 6-7 months, forcing either: (a) standards locked without stakeholder consensus (carriers, distributors, national regulators contest rulings, threatening Month 30 = 2029-04-08 API credibility), or (b) standards cascaded into Month 21-24 (2028-07-08 to 2028-10-08), which delays carrier integration by 3-6 months and pushes the Month 30 (2029-04-08) API mandate to Month 36-39 (2029-10-08 to 2030-01-08). This 6-9 month delay compounds with hub readiness and payment-provider accreditation delays, making the Month 60 (2031-10-08) full-corridor through-ticketing target unachievable and the 40% through-ticket share slipping to 20-25%. A failure to obtain regulation adoption by Month 12 (2027-10-08) should trigger an immediate pause decision and 6-12 month program redesign.

### 4.6.E Root Cause

The project plan delegates regulation tracking to DG MOVE liaison but does not specify: a weekly adoption status update and escalation trigger (e.g., if the European Parliament's TRAN rapporteur signals a >6 month delay by Month 3 = 2027-01-08); a shadow standards team budget and FTE (recommend 5-8 FTE from Month 0 = 2026-10-08); decision authority to pause carrier onboarding if adoption probability drops below 60% by Month 6 (2027-04-08); or a contingency path if Parliament amends the proposed text to conflict with OSDM or the clearing model. The pre-assessment flagged this as critical, but the project plan does not translate the risk into an operational decision gate or governance owner.

---

# 5 Expert: EU Digital Markets and Platform Regulation Specialist

**Knowledge**: Digital Markets Act, proposed digital ticketing regulations, platform governance, interoperability mandates, non-discriminatory access enforcement

**Why**: The programme's legislative foundation is the Commission's proposed Regulation on Digital Booking and Ticketing Services for Rail (adoption gate Month 9 = 2027-07-08). This regulation is still pending Parliament and Council adoption, and its final text will define mandatory API scope, non-discriminatory access duties, and enforcement authority. Any material divergence from the May 2026 proposal could reshape the OSDM Access Terms (Decision 1) and Programme Governance (Decision 5), and compress the Month 18 (2028-04-08) standards deadline if adoption slips.

**What**: Review the Commission's proposed Regulation against OSDM v2.1 and the programme's stated scope (inventory, fares, post-sale, refunds, accessibility), identify gaps or conflicts that could force redesign, forecast likelihood and timing of adoption under current parliamentary dynamics, and advise on shadow standards pre-work and contingency acceleration if adoption passes Month 8 (2027-06-08).

**Skills**: EU legislative drafting and stakeholder negotiation, digital platform regulation, interoperability standards, competition-law alignment in regulatory design, liaison with Parliament TRAN and IMCO rapporteurs

**Search**: EU Digital Markets Act specialist, rail ticketing regulation, interoperability mandates, European Parliament transport committee

## 5.1 Primary Actions

- Secure written Council/Commission Delegation of Authority for the arbitration panel by Month 2 (2026-12-08) specifying binding technical-decision authority, 60-day cycles, 14-day compliance deadlines, and penalties (0.5–1% of quarterly revenue in escrow for non-compliance); if not signed, escalate to DG MOVE and pause carrier commitments.
- Commission customer research on three flagship through-ticket products (guaranteed-connection, air-rail city-pair, assisted-travel) by Month 1 (2026-11-08); validate willingness-to-pay and lock product spec by Month 6 (2027-04-08); pilot one on a single corridor at Month 15 (2028-01-08) with the public app to drive adoption pull.
- Establish direct liaison with Parliament TRAN/IMCO rapporteurs and transport ministers (Germany, France, Belgium, Austria, Spain) by Month 0.5 (2026-10-23) to track Regulation adoption probability weekly; commission shadow standards pre-work Months 0–6 (2026-10-08 to 2027-04-08); if adoption slips past Month 8 (2027-06-08), contract external standards consortium by Month 8.5 (2027-06-23).
- Engage independent cost-modelling firm by Month 0.5 (2026-10-23) to deliver detailed budget forecast by Month 2 (2026-12-08) specifying carrier co-funding per band, hub opex, payment fees and contingency tiers; establish monthly burn dashboards with 115% trigger; request supplementary authority from Commission by Month 12 (2027-10-08) if needed.
- Require carriers >EUR 50 million annual cross-border revenue to sign binding Commitment Letters by Month 3 (2027-01-08) accepting arbitration outcomes and escrow penalties; use CER meetings and bilateral executive engagement to collect signatures and negotiate Deutsche Bahn, SNCF and ÖBB buy-in.

## 5.2 Secondary Actions

- Issue RFP for regional hub operators by Month 0.5 (2026-10-23) with operational start by Month 9 (2027-07-08), SLAs of 99.9% uptime and <2-second latency, capacity 10,000+ bookings/day; award contracts by Month 3 (2027-01-08); conduct joint integration workshops with eligible legacy-system carriers Month 4 (2027-02-08).
- Launch payment-provider accreditation: market sounding Months 0–1 (2026-10-08 to 2026-11-08), call for applicants Month 2 (2026-12-08), decision Month 8 (2027-06-08), with target of at least 2 operational providers by Month 12 (2027-10-08); if fewer than 2 apply by Month 6 (2027-04-08), activate fallback (bilateral settlement or emergency procurement).
- Commission Data Protection Impact Assessment by Month 1 (2026-11-08); engage EDPB and 6–8 national DPAs by Month 3 (2027-01-08) to reach consensus on Standard Contractual Clauses and data-residency rules by Month 4 (2027-02-08); escalate any DPA blocking position to Commission within 10 working days.
- Establish Standing Regulators Committee by Month 1.5 (2026-11-23) with explicit enforcement authority; fund capacity-building partnerships (twinning) pairing strong regulators with weaker ones by Month 4 (2027-02-08); set enforcement SLAs (30-day resolution, escalation to Commission for non-compliance).
- Commission actuarial study of refund volumes and liability exposure by Month 2 (2026-12-08); establish passenger-rights backstop framework and dispute-resolution panel by Month 3 (2027-01-08); require all operational entities to carry liability insurance by Month 4 (2027-02-08) (EUR 2–10M errors-and-omissions, EUR 1–5M cyber).
- Hire 10–15 FTE programme management office by Month 2 (2026-12-08) and 20–30 FTE consumer product team by Month 1 (2026-11-08); engage Trainline and Omio with early API access and co-marketing support (EUR 5–10M budget) by Month 6 (2027-04-08); launch MVP consumer app on one corridor by Month 9 (2027-07-08).

## 5.3 Follow Up Consultation

Next consultation should address: (1) confirmation that the Council Delegation and Commitment Letters are on track for signature (Month 2 = 2026-12-08 and Month 3 = 2027-01-08 deadlines); (2) findings from the customer research and flagship product selection, and first communications/marketing plan; (3) Regulation adoption status and shadow standards pre-work progress; (4) preliminary cost-model results and any budget pressure signals; (5) hub procurement and payment-provider accreditation timelines; (6) GDPR/data-protection consensus from DPA engagement; (7) distributor engagement signals (Trainline, Omio, smaller platforms) and API access roadmap. Timeline: meet by Month 1 (2026-11-08) to review governance and customer research; monthly steering from Month 2 (2026-12-08) onward.

## 5.4.A Issue - Killer Application Missing: Through-Tickets Lack a Compelling Consumer Value Proposition

The plan defines through-tickets as 'single booking reference + single payment + continuity-of-journey rights' but does not articulate why a traveller would choose this over buying two separate tickets or flying. Without a flagship product (e.g., a guaranteed-connection journey with a 4-hour reroute window, competitive pricing versus airlines, or integrated accessibility assistance), the programme risks low adoption. The SWOT analysis identifies this gap but does not resolve it. Success depends on a product that *pulls* travellers, not just removing friction.

### 5.4.B Tags

- missing_value_proposition
- no_killer_product
- weak_pull_against_airlines
- adoption_risk

### 5.4.C Mitigation

By Month 2 (2026-12-08), commission customer research on three candidate flagship products: (1) Paris–Brussels–Amsterdam–Köln guaranteed-connection product with 4-hour reroute and refund <10 days, (2) air-rail city-pair on a high-demand short-haul route with through-fare capped at 70% of equivalent flight, (3) assisted-travel journey for persons with reduced mobility with pre-confirmed platform assistance. Test willingness-to-pay and booking intent via conjoint analysis. Select one for pilot launch at Month 15 (2028-01-08) with the public app; freeze the product spec by Month 6 (2027-04-08) to allow marketing and distributor co-planning.

### 5.4.D Consequence

Without a tangible, differentiated product, through-ticket share may stall at 10–15% (versus the 40% target) because distributors lack margin incentive, carriers resist promotion, and travellers default to existing habits or competing modes. A weak adoption signal at Month 24 (2028-10-08) would trigger budget Tier 2 cuts, leaving smaller carriers unsupported and fragmenting the network.

### 5.4.E Root Cause

Empty

## 5.5.A Issue - Arbitration Panel Enforcement Power Is Unclear: Council Delegation Must Be Explicit and Precede Carrier Commitments

The plan rests on a 'time-boxed arbitration panel with binding technical-decision authority' but does not confirm that written Council delegation will secure force-of-law status. Without explicit Council authorization and documented penalties for non-compliance, major incumbents (Deutsche Bahn, SNCF, ÖBB) can contest rulings, delay implementation and fragment the network. The pre-project assessment flags this as a 'critical condition' by Month 2 (2026-12-08), but the project plan does not mandate it as a gate or escalation trigger.

### 5.5.B Tags

- weak_governance_authority
- incumbent_resistance_risk
- no_escalation_gate
- enforcement_credibility

### 5.5.C Mitigation

By Month 1.5 (2026-11-23), present a draft Council Delegation letter to DG MOVE specifying: (1) panel holds binding authority over technical disputes (access terms, conformance, settlement message standards), (2) 60-day decision cycle, 14-day compliance deadline, (3) penalties: first violation = written notice, second = 0.5% of quarterly through-ticket revenue in escrow, third = 1% of annual cross-border revenue withheld and escalated to Commission. Require carriers >EUR 50M cross-border revenue to sign Commitment Letters by Month 3 (2027-01-08) accepting the protocol. If Council delegation is not signed by Month 2 (2026-12-08), escalate to DG MOVE and pause all carrier onboarding commitments until authority is secured.

### 5.5.D Consequence

If the panel lacks binding enforcement, large carriers will challenge technical decisions, causing 12–24 month delays in standards adoption and API mandate. This would compress the critical path to Month 30 (2029-04-08) from 6 months to near-zero, making the mandate unachievable and forcing a 2-3 year programme rebaselining. Distributor confidence collapses; the through-ticket network fragments across member states.

### 5.5.E Root Cause

Empty

## 5.6.A Issue - Budget Fragility Not Addressed: 20–30% Overrun Exposure Exceeds Free Contingency Without a Credible Top-Up Plan

The EUR 1,500 million cap includes a EUR 225 million (15%) contingency, but only EUR 215 million is freely available (EUR 10 million is earmarked for passenger-rights residuals). A 20–30% overrun (EUR 300–450 million) would exceed free contingency by EUR 85–235 million. The plan proposes seeking 'supplementary authority of EUR 100–200 million' but does not explain the approval path, timeline or fallback if supplementary funds are denied. Without a credible top-up mechanism, budget pressure will force cuts to conformance testing or capacity building, undermining smaller-carrier adoption by Month 30 (2029-04-08).

### 5.6.B Tags

- budget_fragility
- overrun_exposure
- insufficient_contingency
- no_funding_gate

### 5.6.C Mitigation

By Month 2 (2026-12-08), commission an independent cost model specifying: carrier co-funding per size-band (EUR 2–8M for SMEs, EUR 10–15M for mid-size, EUR 0.5–2M for majors), hub opex EUR 1.2M/yr per hub, payment-institution transaction fees EUR 80–160M over five years. Build monthly burn-rate dashboards with 115% pro-rata trigger. Define Tier 1–3 cuts: Tier 1 (10–15% overrun) defer app polish; Tier 2 (15–25%) cut co-funding to 10%, limit hubs to priority corridors; Tier 3 (>25%) suspend new hubs. By Month 12 (2027-10-08), if cumulative spend reaches 115% of pro-rata, immediately request supplementary authority from the Commission with a target of EUR 100–200 million and a 60-day decision gate. If supplementary funds are denied by Month 15 (2028-01-08), apply Tier 3 cuts and extend the through-ticket target to Month 72 (2032-10-08).

### 5.6.D Consequence

Uncontrolled overrun (20–30%) forces cuts to conformance testing or smaller-carrier support mid-programme, leaving 12–18 carriers unable to integrate by Month 30 (2029-04-08). This fragments the through-ticket network into two tiers: major carriers on all corridors, smaller carriers on none. Adoption stalls at 15–20%, distributor complaints remain high, and the modal-shift goal is missed by 50–70%. The programme's credibility is damaged for future phases.

### 5.6.E Root Cause

Empty

---

# 6 Expert: Data Protection Impact Assessment and GDPR Compliance Lead

**Knowledge**: GDPR articles 5, 6, 9, 32-34, Data Protection Impact Assessment methodology, Standard Contractual Clauses, cross-border PII flows, national DPA engagement

**Why**: The programme's shared data layer, clearing mechanism, and multi-carrier passenger-data exchanges raise complex GDPR obligations that are not yet fully specified. The plan calls for a DPIA (Months 0-2 = 2026-10-08 to 2026-12-08) and EDPB/DPA consensus on Standard Contractual Clauses by Month 4 (2027-02-08), but unresolved data-residency, consent, and third-country transfer rules could halt payment-institution accreditation and delay the data layer by 6-12 months. Special-category data (accessibility attributes) adds complexity.

**What**: Lead the Data Protection Impact Assessment, map all passenger PII flows across distributors, carriers, payment institutions, clearing entity and regulators, identify minimum-necessary PII per transaction type, engage early with the EDPB and 6-8 national DPAs (Austria, Poland, Bulgaria, France, Germany, Netherlands, Sweden, Romania) to reach consensus on SCC templates and data-residency rules, and flag any blocking interpretations (e.g. bans on cross-border inventory sharing) that would force architectural redesign.

**Skills**: GDPR compliance architecture, Data Protection Impact Assessment drafting, Standard Contractual Clauses negotiation, national DPA engagement, special-category data handling, cross-border data-transfer risk assessment

**Search**: GDPR Data Protection Impact Assessment specialist, cross-border PII flows, Standard Contractual Clauses, national DPA liaison

## 6.1 Primary Actions

- By Month 0.5 (2026-10-23, 09:00): Establish direct liaison with European Parliament TRAN and IMCO rapporteurs and key member-state transport ministers (Germany, France, Belgium, Austria, Spain) to obtain weekly Regulation adoption tracking; commission a shadow standards pre-work team (5-8 FTE) to conduct gap analysis vs. OSDM v2.1 and draft candidate standards without formal binding until regulation adoption.
- By Month 1 (2026-11-08, 14:00): Hire an EDPB-connected data-protection lead and conduct a Stage 1 DPIA mapping all PII flows by transaction type; simultaneously hire an EU law specialist to draft a 'Delegation of Authority Framework' memo (8-12 pages) specifying the panel's decision scope, binding authority, decision cycles and escalation procedures.
- By Month 1.5 (2026-11-23, 10:00): Submit the Delegation of Authority Framework to DG MOVE, legal services and the Council Presidency for formal adoption review; target Council adoption by Month 3 (2027-01-08) with contingency: if adoption slips past Month 4 (2027-02-08), pause Commitment Letters and shift to bilateral 'Heads of Carriers' Steering Committee' governance until legal delegation is secured.
- By Month 2 (2026-12-08, 17:00): Engage an independent cost-modelling firm to produce a detailed activity-based cost forecast specifying carrier co-funding need per carrier type, hub operating costs, distributor opex by channel (reference vs. full retail), and payment-fee exposure; simultaneously issue RFP for regional hub operators (4-6 hubs, target operational start Month 9 = 2027-07-08, SLAs 99.9% uptime, <2-second latency).
- By Month 2 (2026-12-08, 09:00): Establish a Standing Regulators Committee with explicit authority to enforce arbitration panel rulings; conduct 1-on-1 pre-engagement consultations with 6-8 weaker-capacity DPAs (Bulgaria, Romania, Malta, Hungary) to identify residency or consent concerns before formal DPIA publication.
- By Month 3 (2027-01-08, 17:00): Award hub operator contracts; hire 3-5 regional support coordinators (Budapest, Warsaw, Sofia, Bucharest) for smaller-carrier mentoring; secure DG MOVE pre-commitment that if Tier 2 contingency is triggered, a supplementary funding request will be submitted to the Commission by Month 12 (2027-10-08), targeting award by Month 18 (2028-04-08).
- By Month 3 (2027-01-08, 15:00): Only after Council Delegation of Authority is legally published, require all carriers with >EUR 50M cross-border revenue to sign binding Commitment Letters accepting arbitration outcomes and 0.5-1% quarterly through-ticket revenue escrow penalties; escalate any refusal to the Commission within 5 working days.
- By Month 3 (2027-01-08, 10:00): Establish monthly budget-burn dashboards showing cumulative spend vs. pro-rata forecast, with automatic trigger if quarterly spend exceeds 115% of budget line; define three contingency tiers and escalation thresholds to protect core dependencies (standards, capacity building, conformance testing) if overruns occur.
- By Month 4 (2027-02-08, 15:00): Publish the DPIA and seek EDPB guidance on a single template SCC covering all carrier-to-clearing transfers; conduct joint technical integration workshops pairing hub operators and eligible legacy-system carriers (criteria: cross-border revenue <EUR 50M, booking system >10 years, or IT staff <10 FTE).
- By Month 6 (2027-04-08, 10:00): If EDPB has escalated SCC guidance beyond Month 4 (2027-02-08), commit to emergency ruling by Month 6 (2027-04-08) and reserve EUR 3M from GDPR line for SCC negotiation or re-architecture; establish a Dispute Resolution Panel for refund processing with 5-business-day ruling authority; schedule mandatory hub pilot tests with 2-3 eligible carriers by Month 15 (2028-01-08, 10:00).

## 6.2 Secondary Actions

- By Month 0.5 (2026-10-23, 11:00): Prepare a 2-week rapid-deployment standards-finalisation sequence (detailed specs, stakeholder validation, formal vote) to be activated immediately post-Regulation adoption (targeted Month 6-7 = 2027-04-08 to 2027-05-08); if adoption slips beyond Month 8 (2027-06-08, 12:00), trigger contingency to contract external standards-review consortium for accelerated drafting by Month 8.5 (2027-06-23, 09:00).
- By Month 1 (2026-11-08, 10:00): Issue a market-sounding notice for payment-institution applicants (preliminary qualifications, timeline, SLA expectations); establish a 'Distributor Advisory Council' with Trainline, Omio and public reference distributor representatives to negotiate early API access terms and co-marketing support in return for integration commitments by Month 9 (2027-07-08).
- By Month 2 (2026-12-08, 12:00): Commission an actuarial study of refund volumes and liability exposure (claim rate 3-5%, average cost EUR 50-200, total five-year exposure EUR 10-40M); establish a Passenger-Rights Backstop and Liability Framework with single point of contact, response timelines (<4 hours reroute, <10 days refund), and pooled guarantee fund (up to EUR 5M per carrier per year).
- By Month 2.5 (2026-12-23, 14:00): Draft a 'Non-Compliance Consequences Protocol' specifying penalties for carriers that violate arbitration panel rulings (first violation: written notice + 48-hour cure; second: 0.5% quarterly revenue in escrow; third within 12 months: 1% annual revenue withheld, escalated to Commission).
- By Month 3 (2027-01-08, 13:00): Require all operational entities (hub operators, payment institutions, public distributor, clearing mechanism) to carry comprehensive liability insurance (errors-and-omissions EUR 2-10M, cyber EUR 1-5M, business-interruption EUR 0.5-2M) and contractual liability for misrepresentation of itinerary continuity.
- By Month 4 (2027-02-08, 14:00): Establish twinning partnerships pairing strong regulators (France, Germany, Netherlands, Austria, Sweden, Belgium) with weaker ones; define 3-4 week joint training courses on access-enforcement, data-quality auditing, complaint handling (Months 6-12 = 2027-04-08 to 2027-10-08); develop shared inspection checklists and auditing procedures by Month 8 (2027-06-08).
- By Month 4 (2027-02-08, 11:00): Define enforcement SLAs and penalties: all access-related disputes resolved within 30 days (not exceeding 60 days), all refund claims within 10 days; if a regulator fails SLAs consistently (>60-day resolution in 2+ cases per quarter), escalate to Commission for targeted support or enforcement authority adjustment.
- By Month 6 (2027-04-08, 10:00): If hub procurement shows fewer than 2 qualified bidders, activate fallback: bilateral carrier settlement or emergency procurement with switching cost up to EUR 1M per incident (EUR 5-10M reserve covered by EUR 10M clearing contingent, excess from free contingency).
- By Month 8 (2027-06-08, 09:00): Issue formal call for payment-institution applicants; define accreditation criteria (PSD2 license, SCC compliance verified by DPA, transaction fees capped 0.3-0.5%, uptime 99.95%, <2-second latency); target at least 2 accredited providers operational by Month 12 (2027-10-08).
- By Month 9 (2027-07-08): Launch a minimum-viable consumer app on one priority corridor (MVP pilot); track adoption, booking-failure rate, and user satisfaction; if satisfaction is below 4.0/5 at Month 18 (2028-04-08), pause rollout and conduct UX redesign, compressing into a compressed Month 18-27 (2028-04-08 to 2029-01-08) timeline.

## 6.3 Follow Up Consultation

Next consultation should cover: (1) Regulation adoption tracking and shadow standards pre-work status; has the Commission provided draft regulatory text for gaps analysis? (2) Council Delegation of Authority legal pathway and member-state political signals; is DG MOVE confident in Month 3 (2027-01-08) adoption? (3) GDPR DPIA Stage 1 findings and early DPA feedback (Bulgaria, Romania, Austria identified as highest-risk for residency or consent veto); which DPAs have raised concerns? (4) Hub operator procurement outcomes and bid quality; are 4+ qualified operators available? (5) Payment-institution market sounding results; how many preliminary inquiries have been received? (6) Carrier Commitment Letter readiness and negotiation strategy with Deutsche Bahn, SNCF, ÖBB; what are their pre-conditions for signing? (7) Monthly budget burn-rate data Months 0-3 (2026-10-08 to 2027-01-08) and comparison to pro-rata forecast; any early overrun signals?

## 6.4.A Issue - GDPR Data Protection Impact Assessment is dangerously under-scoped and underestimates cross-border PII liability exposure

The DPIA is scheduled for Months 0-2 (2026-10-08 to 2026-12-08) with DPA consensus by Month 4 (2027-02-08), but the plan conflates GDPR compliance with technical data governance. The real risk: passenger PII flows across 5+ data controllers (distributors, carriers, payment institutions, clearing entity, national regulators, hubs), with special-category data (accessibility attributes, health-related assistance requests) and no clear data controller/processor hierarchy. The £10M allocation is generic; actual exposure includes SCCs negotiation delays (3-6 months per DPA), potential residency bans in 2-3 member states, and EDPB guidance requests that halt clearing accreditation. The plan assumes consensus by Month 4 (2027-02-08); in reality, unanimous EDPB sign-off rarely happens before Month 6-9 (2027-04-08 to 2027-07-08), and a single DPA veto can derail payment-institution licensing.

### 6.4.B Tags

- GDPR_insufficient_scoping
- data_controller_hierarchy_undefined
- special_category_data_underestimated
- SCC_negotiation_timeline_risk
- DPA_veto_risk
- PII_residency_constraints

### 6.4.C Mitigation

Reframe the DPIA as a multi-stage gate: Stage 1 (Month 1 = 2026-11-08, £3-4M): hire an EDPB-connected data protection lead and map all PII flows by transaction type (search, booking, refund, disruption, accessibility), identifying minimum-necessary data per flow and consent triggers. Stage 2 (Month 2.5 = 2026-12-23, pre-engagement): conduct 1-on-1 consultations with the 6-8 weakest-capacity DPAs (Bulgaria, Romania, Malta, Hungary) to identify residency or consent concerns early, before formal DPIA publication. Stage 3 (Month 4 = 2027-02-08, formal gate): publish the DPIA and seek EDPB guidance on a single template SCC covering all carrier-to-clearing transfers; if EDPB escalates, commit to an emergency ruling by Month 6 (2027-04-08). Stage 4 (Month 8 = 2027-06-08, payment-accreditation gate): require each payment-institution applicant to demonstrate SCC coverage for their data flows before license consideration. Reserve £3M from the £10M GDPR line for emergency SCC negotiation or re-architecture if a member state bans residency.

### 6.4.D Consequence

Without early DPA alignment, Month 4 (2027-02-08) consensus will slip to Month 9-12 (2027-07-08 to 2027-10-08), compressing the payment-accreditation window (Month 2 = 2026-12-08 call, Month 8 = 2027-06-08 decision) and delaying provider go-live from Month 12 (2027-10-08) to Month 15-18 (2028-01-08 to 2028-04-08). If a single DPA (e.g. Austria or Germany) refuses to clear SCCs citing residency or special-category handling, the entire clearing mechanism is blocked until redesign, which could consume 6-12 months and push Month 30 (2029-04-08) API mandate past feasibility. Accessibility data consent conflicts (implicit vs. explicit) could exclude persons with reduced mobility from booking automation, fragmenting the network and missing the accessibility target.

### 6.4.E Root Cause

The plan treats GDPR as a compliance checkbox rather than a multi-stakeholder negotiation with asymmetric veto power. EDPB and national DPAs are not monolithic; Bulgaria and Romania have weaker data governance maturity and may demand local processing. The assumption of consensus by Month 4 (2027-02-08) is unrealistic without pre-engagement with weaker regulators, and the £10M allocation does not account for re-architecture costs if a key member state refuses data sharing. Special-category data (accessibility attributes, health conditions) have no explicit governance, and the 90-day PII deletion rule conflicts with refund/complaint timelines (12-month retention), creating a compliance gap that audits will flag.

## 6.5.A Issue - Arbitration panel enforcement authority is illusory without irrevocable Council/Commission legal delegation and escrow-backed carrier penalties; Month 2 (2026-12-08) deadline is at severe risk

The plan requires written Council/Commission delegation by Month 2 (2026-12-08) for the panel to hold binding technical-decision authority, yet the delivery note assumes this occurs 'target Month 1.5 (2026-11-23)' without describing the legal pathway. In EU practice, Council delegations to non-institutional bodies are politically contentious and take 3-6 months of legal drafting, inter-service consultation and formal adoption. The plan offers no contingency if delegation slips to Month 4-6 (2027-02-08 to 2027-04-08) or if the Council insists on advisory rulings only. Major carriers (Deutsche Bahn, SNCF, ÖBB) have signalled they will not accept binding panel rulings until the Regulation is adopted and the delegation text is published; Commitment Letters by Month 3 (2027-01-08) are therefore premature and likely to fail, leaving no enforcement mechanism for standards and access terms. Without legally binding authority and enforced escrow penalties (0.5-1% of quarterly through-ticket revenue), large incumbents can contest rulings and delay the Month 18 (2028-04-08) and Month 30 (2029-04-08) milestones indefinitely.

### 6.5.B Tags

- governance_delegation_at_risk
- carrier_commitment_timing_premature
- panel_advisory_vs_binding_ambiguity
- enforcement_penalty_unspecified
- legal_pathway_undefined
- month_2_deadline_unrealistic

### 6.5.C Mitigation

Replace the Month 2 (2026-12-08) target with a phased governance lock-in: Phase 1 (Month 0.5 = 2026-10-23, by 2026-10-23): hire an EU law specialist and draft a 'Delegation of Authority Framework' memo (8-12 pages) specifying: (a) the panel's decision scope (technical standards, access-term templates, settlement message formats; excluded: commercial pricing, route selection), (b) binding authority text for each scope item, (c) 60-day decision cycles with 14-day compliance deadlines, (d) escalation to the Commission if a carrier misses deadline. Phase 2 (Month 1 = 2026-11-08, by 2026-11-08): circulate the framework to DG MOVE, EU Agency for Railways, and legal services; obtain internal sign-off that this is the intended delegation model. Phase 3 (Month 1.5 = 2026-11-23, by 2026-11-23): submit the framework to the Council Presidency and COREPER for formal legal review; request adoption by Month 3 (2027-01-08) with a contingency gate: if adoption slips past Month 4 (2027-02-08), pause Commitment Letters and re-baseline to use advisory panel rulings + bilateral carrier engagement until legal authority is secured. Phase 4 (Month 3 = 2027-01-08, contingent): only after Council adoption is published, require Commitment Letters with the 0.5-1% escrow penalty linked to specific technical milestones (Month 18 = 2028-04-08 standards, Month 30 = 2029-04-08 API). If delegation is still pending at Month 4 (2027-02-08), shift to a bilateral 'Heads of Carriers' Steering Committee' to govern standards and access terms informally until the legal delegation is granted, reducing the appearance of unilateral panel power.

### 6.5.D Consequence

If Council delegation is not legally adopted by Month 3 (2027-01-08), the Commitment Letters signed in Month 3 (2027-01-08) carry no legal weight. Carriers can refuse to comply with panel rulings, contest standards drafting, and delay access-term agreement through the entire Month 4-18 (2027-02-08 to 2028-04-08) standards window. The arbitration panel becomes advisory, transforming the Pragmatic Foundation scenario into The Consolidator's Compact (incumbent-influenced, slow enforcement). Standards miss the Month 18 (2028-04-08) deadline, the Month 30 (2029-04-08) API mandate becomes non-binding, and the network fragments across member states and carriers. The programme loses credibility with distributors (Trainline, Omio), who will not integrate without clear enforcement of non-discrimination duties.

### 6.5.E Root Cause

The plan underestimates the legal and political lead time for Council delegation to a novel governance body. EU delegations to non-institutional entities (e.g. joint undertakings, regulatory panels) require inter-service legal opinion, consultation with member-state legal experts, and formal Council vote, which typically takes 4-9 months. The plan assumes this can happen by Month 2 (2026-12-08) without any legal drafting, stakeholder pre-engagement or contingency if adoption delays. Carrier buy-in is also premature: large incumbents will not commit to panel rulings until the Regulation is adopted (Month 9 = 2027-07-08 target) and the delegation text is published and legally binding. Month 3 (2027-01-08) Commitment Letters are therefore a bluff, and if carriers refuse to sign, the entire governance model collapses.

## 6.6.A Issue - Budget contingency is exhausted by Month 24 (2028-10-08) under realistic hub, distributor and payment-fee scenarios; no margin left for GDPR re-architecture or regulator capacity building

The plan allocates £1,500M with a £225M contingency (15%), of which £10M is earmarked for passenger-rights residual, leaving £215M free contingency. However, the canonical budget lines include hub economics gaps (~£1.9M/year for 4 hubs, or £9.5M over 5 years), distributor operating cost (£43M/year or £215M over 5 years, estimate), payment-fee subsidy (£15M capped, 60% of fees Months 0-24 = 2026-10-08 to 2028-10-08), and carrier co-funding (£290M including £44M hubs). The plan acknowledges that hub opex exceeds fee revenue by ~£0.47M/year per hub, yet treats this as an unfunded gap. If only 3 of 4 hubs reach cost-recovery by Month 48 (2030-10-08), the gap compounds to £5-7M unplanned spend. The distributor operating cost estimate of £43M/year is unvalidated; a full retail channel with consumer support and multilingual assistance could easily run £50-60M/year, consuming an extra £35-85M from free contingency by Month 48 (2030-10-08). The Tier 1-3 overrun responses assume optional cuts (app polish, co-marketing, capacity building), yet all are core dependencies for the 40% through-ticket target and halved-complaints goal.

### 6.6.B Tags

- hub_economics_unfunded
- distributor_opex_unvalidated
- contingency_exhaustion_by_month24
- tier_responses_cut_core_items
- payment_fee_subsidy_insufficient
- carrier_cofunding_demand_risk

### 6.6.C Mitigation

Establish a bottom-up budget validation and monthly burn-rate dashboard by Month 2 (2026-12-08): (1) Commission a cost-estimation consultant to model hub opex per carrier type (EUR 0.8-1.2M/year per hub baseline, plus EUR 0.2-0.4M for legacy-carrier integration), distributor opex per channel (reference-implementation only £20-30M/year, full retail £50-70M/year), and payment-provider fees (£80-120M total, with subsidy tier: 60% Months 0-24 = 2026-10-08 to 2028-10-08, 30% Months 24-36 = 2028-10-08 to 2029-10-08, 0% post-36). (2) Implement monthly burn-rate reporting by Month 3 (2027-01-08): define pro-rata spend target (£1,500M ÷ 60 months = £25M/month baseline) and trigger escalation if quarterly spend exceeds 115% (i.e. £86.25M in a 3-month quarter vs. £75M pro-rata). (3) Redefine contingency tiers to protect core dependencies: Tier 1 (10-15% overrun): reduce distributor co-marketing from £10M to £5M, defer app analytics upgrade; Tier 2 (15-25% overrun): cut carrier co-funding from 20% to 10% (saving £50M), reduce hub resilience budget by 30% (losing 1-2 weeks recovery time); Tier 3 (>25% overrun): activate supplementary funding escalation to the Commission by Month 18 (2028-04-08), targeting £100-200M. (4) Establish a hub cost-recovery gate at Month 30 (2029-04-08): if fewer than 3 of 4 hubs have signed multi-year contracts with carriers pledging £0.5M+ in annual fees, trigger a hub consolidation review and absorb the £9.5M gap into the remaining hub opex from the free contingency, or pause new hub onboarding and concentrate on the highest-utilisation hubs. (5) Secure a pre-commitment from DG MOVE by Month 3 (2027-01-08) that if Tier 2 contingency is triggered, a supplementary funding request will be submitted to the Commission by Month 12 (2027-10-08), with target award by Month 18 (2028-04-08), before the conformance-testing phase strains capacity-building budget.

### 6.6.D Consequence

Without monthly burn-rate dashboards and cost validation, the programme will discover by Month 12-18 (2027-10-08 to 2028-04-08) that hub opex and distributor costs have consumed 30-40% of free contingency, leaving only £50-80M buffer for the payment-fee subsidy (capped at £15M, but actual demand may reach £25-30M if through-ticket share climbs faster than planned), GDPR re-architecture (estimated £3-5M if DPA veto requires redesign), and regulator capacity building (budgeted at £100M but demand could spike to £120-150M if weaker regulators request accelerated twinning). By Month 24 (2028-10-08), the free contingency will be exhausted at 20-25% overrun, forcing Tier 3 cuts (hub consolidation, capacity-building deferral) at the worst time: just before the Month 30 (2029-04-08) API mandate and the Month 18 (2028-04-08) standards completion. Capacity-building cuts will leave weaker regulators unprepared to enforce access and refund duties, fragmenting enforcement across member states and undermining the non-discrimination goal. The programme loses credibility with stakeholders, and smaller carriers delay integration waiting for clarity on payment-fee subsidy and hub availability.

### 6.6.E Root Cause

The plan allocates budgets to major activities (standards £280M, distributor £215M, clearing £120M, capacity £100M, consumer £150M, co-funding £290M) without bottom-up cost validation or sensitivity analysis. Hub economics are acknowledged as a gap (opex exceeds revenue), yet the plan treats this as a known unfunded item rather than a risk trigger. Distributor opex is estimated at £43M/year without specifying the channel scope (reference-implementation vs. full retail with consumer support), creating a blind spot of £20-40M over the 5-year programme. The Tier responses assume optional items (app, marketing, capacity) can be cut without cascading failures, yet all are dependencies: app delays distributor integration and consumer adoption; marketing cuts reduce through-ticket awareness and miss the 40% target; capacity-building deferral leaves weaker regulators unable to enforce and fragments the network. The contingency is treated as a buffer rather than a hedge against known unknowns (hub adoption rates, distributor operating model, payment-fee volatility), and the 15% reserve is insufficient for a novel, multi-stakeholder programme with asymmetric delivery risk.

---

# 7 Expert: EU Passenger-Rights Enforcement and Multi-Operator Liability Counsel

**Knowledge**: EU Regulation 1371/2007 (rail passenger rights), revised passenger rights rules, multi-carrier liability allocation, refund processing and dispute resolution, accessibility duties under the Accessibility Directive, cross-border enforcement consistency

**Why**: Decision 8 (Passenger-Rights Backstop and Liability Allocation) is a lynchpin of traveller trust and through-ticket viability. The plan assigns the selling distributor as the single point of contact for rerouting and refunds, with costs recovered from liable carriers via the clearing mechanism. However, the backstop's alignment with the revised EU rail passenger rights rules is not confirmed, the 10-day refund SLA may conflict with national insolvency law or carrier bankruptcy procedures, the claim rate (3-5% of tickets = EUR 10-40M over 5 years estimate) and insurance requirements are not fully validated, and cross-border enforcement consistency across 27 member states with uneven regulator capacity is at risk.

**What**: Validate the proposed liability-allocation model (distributor as single contact, cost recovery via clearing) against the final text of the revised EU passenger rights rules, advise on insurability of the distributor and clearing entity under the proposed framework, model the refund SLA against national procedures (e.g. insolvency, bankruptcy), design the dispute-resolution procedures needed to meet the 10-day refund timeline across all member states, and map the GDPR and cross-border data-access rules needed to process refunds consistently.

**Skills**: EU passenger rights law and enforcement, multi-operator liability allocation and insurance, refund processing architecture, accessibility compliance, cross-border dispute resolution, liaison with national rail regulators

**Search**: EU rail passenger rights counsel, multi-operator liability, cross-border refund enforcement, accessibility rights compliance

## 7.1 Primary Actions

- Secure written Council and Commission Delegation of Authority to the arbitration panel by Month 2 (2026-12-08) (target Month 1.5 = 2026-11-23). This must specify binding decision-making power over technical standards, 60-day decision cycles, 14-day compliance deadlines, and escalation-to-Commission penalties for non-compliance. Without this delegation, the panel lacks enforceability against major carriers and the Month 18 (2028-04-08) standards milestone will slip by 6–12 months. Begin preparation of the draft Council decision immediately (Month 0 = 2026-10-08, within 2 weeks). Engage the Council Legal Service, DG MOVE, and the Commission's legal counsel to fast-track review and adoption.
- By Month 4 (2027-02-08), commission a Data Protection Impact Assessment (DPIA) and convene a task force of 7–9 national DPAs (Austria, Germany, France, Netherlands, Poland, Bulgaria, Romania, Spain, Sweden) to resolve GDPR governance for cross-border through-ticketing before the binding standards phase. Critical gaps to close: (1) Which member state's law applies to multi-carrier refund disputes? (2) Are Standard Contractual Clauses (SCCs) sufficient for carrier-to-carrier and carrier-to-clearing data transfers, or do national DPAs require additional safeguards? (3) Accessibility data (special category under GDPR Article 9): is passive opt-in consent lawful, or must consent be explicit and revocable without blocking the booking? (4) Data residency: can carrier inventory and booking data be stored in an EU-wide data centre or must it stay in the carrier's home member state? Obtain written sign-off from at least 8 of 27 member states' DPAs on the framework by Month 4 (2027-02-08). If fewer than 8 sign off, escalate to the EDPB for expedited guidance (target 4 weeks) and commission supplementary legal instruments (e.g., a Commission adequacy decision or a GDPR derogation) to unblock payment-institution accreditation and the data layer. Embed resolved GDPR rules and SCC templates in the binding standards (Month 18 = 2028-04-08).
- Immediately commission an EU passenger-rights specialist to develop a Fault-Allocation and Recovery Protocol for multi-carrier through-tickets (complete by Month 3 = 2027-01-08). This must specify: (1) Who makes the fault decision if a missed connection is caused by a delayed segment run by Carrier B but the passenger claims against the distributor or Carrier A? (2) Timeline for fault determination (24–48 hours). (3) Financial flow: does the distributor advance refund cost or does the responsible carrier pay the passenger directly? (4) Cross-border enforcement: which court or regulator has authority to order a refund if the liable carrier is in another member state and refuses to pay? (5) Appeal protocol: how are carrier disputes over fault determined? Embed this protocol in the binding standards (Month 18 = 2028-04-08). Increase the passenger-rights residual reserve from EUR 10M to EUR 30–40M to cover 8–12% claim rate (not 3–5%). Pilot the refund process on one corridor (Paris–Brussels–Amsterdam) by Month 15 (2028-01-08) with a 5-day refund target and daily claim-resolution metrics; if resolution time exceeds 10 days or dispute rate exceeds 3%, escalate and increase reserve by EUR 10–20M.
- Contract hub operators by Month 3 (2027-01-08) with operational start date no later than Month 9 (2027-07-08). Issue an RFP specifying: at least 4–6 regional hubs covering the four priority corridors plus 2–3 additional hubs for TEN-T extension, SLAs of 99.9% uptime, <2-second latency, <2-hour incident recovery, and capacity of ≥10,000 bookings/day per operator. Establish a stop threshold: if a hub's booking-failure rate exceeds 2% for more than one week, suspend new carrier onboarding and escalate to the Steering Committee. Conduct joint technical integration workshops with hub operators and eligible legacy-system carriers (criterion: annual cross-border revenue <EUR 50M or booking-system age >10 years) by Month 4 (2027-02-08). Hire 3–5 regional support coordinators by Month 4 (2027-02-08) to provide on-site mentoring and integration troubleshooting for smaller carriers; budget EUR 1–2M over five years. Schedule mandatory pilot tests of each hub's integration with 2–3 eligible carriers by Month 15 (2028-01-08); complete testing and resolve mapping errors by Month 18 (2028-04-08) before the conformance-testing phase. Hub readiness is on the critical path; late procurement will compress integration timelines and cause 20–30% readiness slip past Month 30 (2029-04-08), fragmenting the through-ticket network.
- Secure written Commitment Letters from all carriers with annual cross-border revenue above EUR 50M by Month 3 (2027-01-08). Letters must specify: carriers accept arbitration panel authority, agree to comply with technical rulings within 14 days, and accept penalties of 0.5–1% of quarterly through-ticket revenue placed in escrow for non-compliance. Personally negotiate with SNCF, Deutsche Bahn, ÖBB and other major incumbents (Month 2.5 = 2026-12-23) to secure buy-in and handle political pushback. If a carrier refuses to sign by Month 4 (2027-02-08), escalate to DG MOVE and the Commission for enforcement action (threaten suspension of EU funding or antitrust investigation). These letters are essential to signal credible programme authority and prevent incumbents from fragmenting the standards-setting process.

## 7.2 Secondary Actions

- By Month 2 (2026-12-08), commission a detailed cost model from an independent firm specifying carrier co-funding need per carrier (EUR 2–8M per SME legacy operator, EUR 10–15M per mid-size operator, EUR 0.5–2M per major operator), hub operating cost (EUR 5–8M per hub over 5 years), public distributor annual operating cost (EUR 60–100M/year for retail channel, EUR 20–30M/year for reference-implementation only), and payment-institution transaction-fee exposure (baseline 0.5–1.0% per transaction, extrapolated to EUR 80–160M over 5 years). Establish monthly budget-burn dashboards by Month 3 (2027-01-08) with automatic trigger if quarterly spend exceeds 115% of pro-rata forecast; escalate any trigger to DG MOVE within 5 working days. Define three contingency tiers (Tier 1: 10–15% overrun; Tier 2: 15–25%; Tier 3: >25%) and pre-agreed responses (defer consumer-app polish, reduce carrier co-funding rate, suspend new hub openings). Secure DG MOVE commitment by Month 3 (2027-01-08) to seek supplementary budget authority from the Commission by Month 12 (2027-10-08) if Tier 2 is triggered, with a target supplementary allocation of EUR 100–200M.
- Establish direct liaison with European Parliament TRAN and IMCO rapporteurs and key member-state transport ministers (Germany, France, Belgium, Austria, Spain) by Month 0.5 (2026-10-23) to obtain weekly Regulation adoption status updates and political signalling. Track adoption probability and identify blocking amendments. Commission a shadow standards pre-work team (5–8 FTE) in Month 0 (2026-10-08) to conduct gap analysis comparing the Commission's proposed Regulation text to OSDM v2.1 specifications and draft candidate standards on access-term templates, settlement message formats and passenger-rights protocols, without formally binding the programme until regulation adoption. Prepare a 2-week rapid-deployment standards-finalisation sequence (detailed specs, stakeholder validation, formal vote) to be activated immediately post-adoption (target Month 6–7 = 2027-04-08 to 2027-05-08). If regulation adoption slips beyond Month 8 (2027-06-08, 12:00), immediately escalate to DG MOVE and contract an external standards-review consortium by Month 8.5 (2027-06-23, 09:00) to conduct accelerated standards drafting and carrier engagement workshops by Month 10 (2027-08-08, 17:00), accepting 6–8 week standards-finalisation compression risk.
- Establish a Standing Regulators Committee by Month 1.5 (2026-11-23) with explicit power to enforce panel rulings consistently across all member states. The committee should meet monthly starting Month 2 (2026-12-08), escalate any member-state non-enforcement to the Commission within 5 business days, and include enforcement penalties in its terms of reference (EUR 50,000–EUR 500,000 fines for consistent non-compliance by a regulator). Conduct a regulator-capacity audit by Month 2 (2026-12-08) identifying gaps across all 27 member-state regulators; prioritise 8–12 'weaker-capacity' regulators (Poland, Bulgaria, Romania, Hungary, Slovakia, Slovenia, Croatia, Malta) for targeted support. Allocate EUR 10–15M over five years for capacity building. Establish twinning partnerships by Month 4 (2027-02-08) pairing strong regulators (France, Germany, Netherlands, Austria, Sweden, Belgium) with weaker ones. Define twinning scope: (a) 3–4 week joint training courses on access enforcement, data-quality auditing, complaint handling (Months 6–12 = 2027-04-08 to 2027-10-08); (b) shared inspection checklists and auditing procedures (Month 8 = 2027-06-08); (c) quarterly joint reviews of enforcement decisions starting Month 12 (2027-10-08). Define enforcement SLAs: all access-related disputes resolved within 30 days (not exceeding 60 days); all refund claims processed within 10 days. If a regulator fails to meet SLAs (>60-day resolution in 2+ cases per quarter), escalate to Commission for targeted support or authority adjustment.
- Issue a Request for Proposals (RFP) for accredited payment institutions by Month 2 (2026-12-08) with decision target Month 8 (2027-06-08) and at least 2 providers operational by Month 12 (2027-10-08). RFP must specify: PSD2 compliance, capacity for 10,000+ transactions per day per provider, settlement cycle under 48 hours, dispute resolution within 5 business days, and fee cap target 0.3–0.5% per transaction (not above 0.7%). If fewer than 2 providers apply by Month 6 (2027-04-08), escalate and execute emergency procurement by Month 8 (2027-06-08); fallback to bilateral carrier settlement or a temporary central clearing mechanism. Budget up to EUR 1M per incident for switching if a sole provider fails; cover excess from the EUR 10M reserve in the clearing line or free contingency.
- Hire the Programme Management Office (10–15 FTE) by Month 2 (2026-12-08) with clear accountability for milestone adherence, budget control and stakeholder coordination. The PMO should have a direct line to DG MOVE and the Steering Committee for escalation. Establish a consumer product team (20–30 FTE) by Month 1 (2026-11-08) to define the killer application, design the booking flow, and develop the public app. Hire an independent evaluation firm by Month 3 (2027-01-08) to establish a validated baseline of cross-border sales, complaints and modal split by Month 9 (2027-07-08). Measurement is critical: without a consolidated baseline, mid-course corrections and the final 40% through-ticket target are not attributable to the programme.
- Define and pilot the killer application (a flagship guaranteed-connection through-ticket product on one corridor) by Month 9 (2027-07-08). The product should include: one booking reference, one payment, 4-hour reroute decision, 10-day refund guarantee, reduction-card recognition (10–15% effective discount), and a clear single contact for help. Launch it with the public app at Month 15 (2028-01-08). The killer application is the missing piece: without a compelling reason for travellers to prefer a through-ticket over separate tickets or a flight, the 40% target will be missed. Owner: consumer product team with corridor-carrier leadership and the public distributor. Ensure the product is tested with users (5+ focus groups of 8–12 travellers each on each corridor) by Month 12 (2027-10-08) to validate willingness to pay and actual usage.

## 7.3 Follow Up Consultation


At the next consultation, we must address three critical items: (1) **Regulation adoption tracking and escalation protocol**: Confirm that weekly liaison with Parliament and member-state ministers is active, that the shadow standards pre-work team is mobilised, and that a contingency standards-acceleration pathway is ready for deployment if adoption slips past Month 8 (2027-06-08). If the Regulation is not adopted by Month 10 (2027-08-08), the programme should pause carrier onboarding commitments and re-baseline the critical path; no mitigation will recover a 3+ month adoption delay without extending all milestones. (2) **Arbitration panel delegation and carrier buy-in**: Confirm that the Council decision granting binding authority is in legal review (by Month 0.5 = 2026-10-23), that SNCF, Deutsche Bahn and ÖBB leadership have been personally engaged (by Month 2.5 = 2026-12-23), and that all carriers above EUR 50M have signed Commitment Letters (by Month 3 = 2027-01-08). If any major carrier refuses, escalate for Commission enforcement action immediately; do not proceed with standards work until incumbents are bound. (3) **GDPR and passenger-rights backstop resolution**: Confirm that the DPIA task force of 7–9 national DPAs is convened (by Month 1.5 = 2026-11-23), that the Fault-Allocation and Recovery Protocol is drafted (by Month 3 = 2027-01-08), and that at least 8 DPAs have signed off on the data-governance framework (by Month 4 = 2027-02-08). If DPA consensus is not reached by Month 4 (2027-02-08), initiate emergency escalation to the EDPB; a unilateral stop order by any major DPA would fragment the network and delay the Month 30 (2029-04-08) API mandate by 6–12 months. All three items are on the critical path; failure to resolve any one of them by its deadline will cascade into multi-month delays downstream.

## 7.4.A Issue - Passenger-Rights Backstop Is Underfunded and Liability Framework Is Incomplete

The plan estimates claim rates at 3–5% (EUR 10–40M over 5 years), but EU Regulation 1371/2007 and disruption risk under multicarrier through-tickets typically trigger 8–12% claim rates on competitive, dense corridors. The backstop lacks: (1) fault-allocation protocol (who decides which carrier caused the missed connection?); (2) insolvency reserve for a major carrier collapse; (3) distributor indemnification rules if a carrier disputes liability; (4) cross-border enforcement of refund orders (does a French carrier refund a claim filed in Poland?). Without these, the clearing mechanism cannot settle disputes within 10 days, distributor confidence erodes, and through-ticket sales stall. The EUR 10M residual reserve is insufficient for tail-risk scenarios (cascading delays, force-majeure events). The plan assumes refund liability is 'recovered from the responsible carrier via accredited payment providers,' but no enforcement protocol specifies how a refund advance is recovered if the carrier contests fault.

### 7.4.B Tags

- passenger-rights-gap
- liability-allocation-missing
- underfunded-reserve
- fault-protocol-absent
- enforcement-unclear

### 7.4.C Mitigation

By Month 4 (2027-02-08), commission an EU passenger-rights specialist to develop a Fault-Allocation and Recovery Protocol specifying: (1) who makes the fault decision (the distributor, an independent arbiter, or the responsible carrier); (2) timeline for fault determination (24–48 hours); (3) financial flow (does the distributor advance cost or does the responsible carrier pay the passenger directly?); (4) cross-border enforcement (which court or regulator orders a refund if the carrier is in another member state?); (5) appeal and escalation (how is a carrier's fault dispute resolved?). Embed this protocol in the binding standards (Month 18 = 2028-04-08). Increase the residual reserve from EUR 10M to EUR 30–40M to cover 8–12% claim rate. Require all operational entities (distributors, hubs, clearing mechanism) to carry errors-and-omissions insurance with EUR 2–10M limits. By Month 6 (2027-04-08), pilot the refund process on one corridor (Paris–Brussels–Amsterdam) with a 5-day refund target and daily claim-resolution metrics; if resolution time exceeds 10 days or dispute rate exceeds 3%, escalate to Steering Committee and increase the reserve by EUR 10–20M.

### 7.4.D Consequence

Without a clear fault-allocation and recovery protocol, disputed refund claims will accumulate; the 10-day refund SLA will be missed on 20–40% of claims; distributors will lose confidence and reduce through-ticket inventory; and carriers will contest refund advances, leading to 6–12 month collection disputes. The result is a loss of 10–20 percentage points on the 40% through-ticket target (i.e., 20–30% instead of 40%), higher consumer complaints (not 50% reduction but 10–20% reduction), and potential litigation that delays the Month 30 (2029-04-08) API mandate by 3–6 months. If a major carrier becomes insolvent during a peak season, the EUR 10M reserve will be exhausted and the programme will be forced into emergency restructuring or a claim freeze that will severely damage credibility.

### 7.4.E Root Cause

The plan inherits EU Regulation 1371/2007 passenger-rights duties but does not translate them into operational procedures for multi-carrier through-tickets. Fault allocation under the regulation is carrier-specific (the carrier liable for a delay is responsible for rerouting, care, and compensation), yet the plan does not specify how fault is determined when three carriers are involved and the missed connection was caused by a delayed segment run by Carrier B but the distributor sold the ticket and the passenger claims against Distributor A. This design gap—whether fault flows back from distributor to carrier, or whether the distributor must advance cost and later recover—is not resolved. The result is a liability framework that is incomplete and exposes the programme to claims that exceed the reserve by 5–10x.

## 7.5.A Issue - GDPR and Data Governance Risks Are Minimized; Cross-Border PII Flows Are Not Resolved

The plan commits to a DPIA and EDPB consensus by Month 4 (2027-02-08), but it does not address critical unresolved GDPR hazards: (1) which member state's data-protection law governs when a German passenger books a ticket with a French carrier and an Austrian hub, all coordinated through a Brussels clearing mechanism? (2) Standard Contractual Clauses (SCCs) for cross-border carrier-to-carrier data transfers must be pre-approved by national DPAs; the plan assumes DPA buy-in by Month 4 (2027-02-08), but DPA consensus typically takes 6–12 months because each authority interprets GDPR differently (Austria, Germany and France are particularly strict on data minimisation). (3) Accessibility data (mobility restrictions, medical conditions) is special-category data under GDPR Article 9; the plan requires 'explicit consent' at booking time, but if a passenger refuses consent, can the platform complete the booking without accessibility data? If not, consent is a de facto mandatory condition and likely unlawful. (4) Data residency: can carrier data be stored in a EU-wide data centre, or must it stay in the carrier's home member state? No guidance. (5) Cross-border refund disputes will require sharing passenger PII (name, email, payment details) among carriers, distributors, and regulators; no data-sharing protocol is defined. If a national DPA issues a stop order on data transfers (e.g., Bulgaria or Romania due to data-protection policy divergence), the clearing mechanism will be blocked and the Month 30 (2029-04-08) API mandate will be jeopardised.

### 7.5.B Tags

- gdpr-unresolved
- scc-approval-risk
- accessibility-data-consent-unlawful
- data-residency-ambiguous
- cross-border-enforcement-unclear

### 7.5.C Mitigation

By Month 1.5 (2026-11-23), engage the EDPB secretariat and convene a DPA task force (Austria, Germany, France, Netherlands, Poland, Bulgaria, Romania—7–9 authorities) to clarify GDPR governance for cross-border through-ticketing before the DPIA is completed. Commission a specialist data-protection law firm to draft a detailed Cross-Border Data Governance Framework (Month 1 = 2026-11-08 to Month 3 = 2027-01-08) specifying: (1) which member state's law applies (propose: the distributor's home law for booking; the responsible carrier's home law for refund disputes); (2) SCC templates pre-approved by the task force (Month 3 = 2027-01-08); (3) data residency rules (propose: data may be stored in any EU member state if encrypted and access-controlled); (4) accessibility-data consent model (propose: passive opt-in at booking time—if the passenger does not explicitly refuse accessibility data sharing, it is deemed consented; document this model in the booking confirmation). (5) Escalation protocol: if a national DPA issues a unilateral stop order, trigger emergency escalation to the EDPB for expedited guidance (target 4 weeks; if guidance is not issued, the programme may need to pause data transfers until resolution). By Month 4 (2027-02-08), obtain written sign-off from at least 8 of 27 member states' DPAs accepting the framework; if fewer than 8 sign off, escalate to the Commission and agree on a supplementary legal instrument (e.g., a Commission adequacy decision or a GDPR derogation). Embed accessibility-data governance and SCC details in the binding standards (Month 18 = 2028-04-08).

### 7.5.D Consequence

If GDPR governance is not resolved by Month 6 (2027-04-08), a national DPA can issue a stop order on carrier data transfers within its jurisdiction (e.g., Poland or Romania banning cross-border refund-dispute data sharing), which will fragment the network and make consistent refund processing impossible. Payment institutions will refuse accreditation if data flows are uncertain (6–12 month delay in payment-provider onboarding, threatening the Month 12 = 2027-10-08 gate). Accessibility-data consent ambiguity will trigger a formal EDPB opinion (6–9 months) and require redesign of the booking flow, compressing the Month 15 (2028-01-08) consumer-app launch. If a DPA challenge succeeds and the programme is forced to redesign data flows, the critical path will slip by 3–6 months, jeopardising the Month 18 (2028-04-08) binding standards milestone.

### 7.5.E Root Cause

The plan treats GDPR compliance as a box-ticking exercise (complete DPIA, reach DPA consensus by Month 4 = 2027-02-08) but does not recognise that GDPR governance for multicarrier through-tickets is genuinely novel and requires bespoke clarification from the EDPB or national DPAs. EU Regulation 1371/2007 requires passenger data to be retained for dispute resolution, but cross-border through-ticketing creates data flows that are not covered by existing DPA guidance. Accessibility data is particularly fraught: EU Accessibility Directive obligations (passengers with reduced mobility must be able to request assistance) collide with GDPR Article 9 (special-category data requires explicit consent and heightened protection). If consent is mandatory, a passenger who refuses accessibility data disclosure cannot book an accessible ticket; if it is optional, the platform cannot fulfil accessibility obligations. The plan does not resolve this tension. Additionally, DPA consensus at the EDPB level is not the same as national DPA approval; some member states may issue unilateral stop orders if they believe SCCs are insufficient.

## 7.6.A Issue - Arbitration Panel Lacks Enforcement Power; Panel Rulings Against Incumbents Are Not Binding Without Council Delegation

The plan specifies an arbitration panel with '8–12 FTE, binding technical rulings within 60 days, 14 days to comply or escalate to the Commission,' but it does not secure the foundational legal authority. The panel is described as 'layered on top of existing institutions' (DG MOVE, EU Agency for Railways) and lacks direct enforcement power. When Deutsche Bahn, SNCF or ÖBB contest a panel ruling—e.g., rejecting a requirement to expose real-time inventory at <2-second latency or refusing to recognise a third-party distributor's access rights—the plan's escalation route is 'to the Commission.' But the Commission has no standing executive power over a carrier's technical operations; it can only issue an enforcement directive or threaten an antitrust investigation, both of which take 6–12 months. The plan assumes 'written Council/Commission delegation' by Month 2 (2026-12-08), but such delegation is not yet secured and is not binding until formally adopted by Council decision. The Commitment Letters signed by carriers (Month 3 = 2027-01-08) include penalties of '0.5–1% of quarterly through-ticket revenue in escrow,' but those penalties are enforceable only if the panel's ruling is valid under EU law; if a carrier challenges the ruling before an EU court, the escrow can be tied up in litigation for 2–3 years. The result is that the panel has the appearance of authority but lacks the legal force to bind incumbents, and smaller carriers have no confidence that the panel will protect their access rights.

### 7.6.B Tags

- governance-gap
- panel-enforcement-undefined
- delegation-not-secured
- commission-escalation-slow
- litigation-risk-high

### 7.6.C Mitigation

Immediately (Month 0 = 2026-10-08, within 2 weeks of project start), prepare a draft Council Decision delegating binding technical decision-making authority to the arbitration panel. The delegation must specify: (1) panel has authority to issue binding rulings on access-term templates, settlement message standards, data-quality SLAs, and conformance test criteria; (2) rulings are issued within 60 days and are final (not subject to administrative appeal, only judicial review if a carrier claims the ruling violated EU law); (3) compliance deadline is 14 days from notification; (4) non-compliance triggers a penalty (0.5–1% of quarterly through-ticket revenue in escrow, escalated to 1–2% if non-compliance persists beyond 30 days); (5) the Commission or EU Agency for Railways enforces penalties (not the Commission's discretionary choice, but a mandatory enforcement protocol). Submit the draft decision to the Council Legal Service for review by Month 0.5 (2026-10-23) and secure Council adoption by Month 2 (2026-12-08). Obtain a written Commission opinion affirming the panel's authority by Month 1.5 (2026-11-23). Prepare a secondary legal instrument (e.g., an Agency decision or a memorandum of understanding) that clarifies the panel's authority if the Council decision is delayed; this secondary instrument should be sufficient to begin standards work even if full Council delegation is not complete. Require all carriers above EUR 50M cross-border revenue to sign the Commitment Letters (Month 3 = 2027-01-08) with explicit acknowledgment that they accept the panel's authority and agree to penalties; use legal counsel to negotiate with SNCF, Deutsche Bahn and ÖBB leadership (Month 2.5 = 2026-12-23) to secure incumbent buy-in before Month 3 (2027-01-08). If a carrier refuses to sign by Month 4 (2027-02-08), escalate to DG MOVE and the Commission for enforcement action (threaten suspension of EU funding or antitrust investigation).

### 7.6.D Consequence

If the Council delegation is not secured by Month 2 (2026-12-08), the panel will be advisory only, and major incumbents can contest technical rulings without consequence. The standards-setting process (Months 4–18 = 2027-02-08 to 2028-04-08) will be paralysed by disputes over access-term templates and data-quality SLAs; carriers will submit competing proposals and block consensus, extending the standards phase by 6–12 months. The Month 18 (2028-04-08) binding standards milestone will be missed. If the delegation is delayed beyond Month 4 (2027-02-08), the standards work must pause pending legal clarity, and the critical path will slip by 3–6 months. Litigation risk is high: if a carrier challenges a panel ruling in the EU courts and wins on grounds that the panel lacked authority, all subsequent rulings are vulnerable to challenge, and the programme will face a cascading crisis of credibility. The result is likely a 6–18 month delay to the Month 30 (2029-04-08) API mandate and a fragmented through-ticket network on only 1–2 corridors by Month 60 (2031-10-08), missing the 40% target by 30–40 percentage points.

### 7.6.E Root Cause

The plan opts for 'a small independent standards arbitration panel' to avoid the legal set-up time of a dedicated joint undertaking (which would take 12–18 months to establish), but in doing so it sacrifices binding authority. An arbitration panel has authority only if it is: (1) explicitly delegated that authority by a competent legal body (Council, Commission or a member state); (2) empowered to issue enforceable rulings (not advisory opinions); and (3) backed by a clear escalation and penalty mechanism that does not depend on the Commission's discretionary enforcement. The plan assumes these conditions are met by Month 2 (2026-12-08), but the Council decision delegating authority is not in progress and no legal draft has been prepared. The Commitment Letters (Month 3 = 2027-01-08) are a proxy for buy-in, but they are not a substitute for legal authority. If a carrier refuses to comply with a panel ruling and contests it in court (claiming the panel lacked authority), the ensuing litigation will paralyse the programme and delay the Month 18 (2028-04-08) standards milestone.

---

# 8 Expert: Stakeholder Alignment and Carrier Commitment Lead

**Knowledge**: Incumbent rail-operator economics and incentive structures, distributors' margin requirements and API integration capacity, CER and smaller-carrier concerns, consumer and disability-rights advocacy, competitive responses from airlines and bus operators

**Why**: The programme's success depends on binding commitments from 25+ carriers, 2-3 major distributors, at least 2 payment institutions, and consistent enforcement by 27 national regulators. The governance plan calls for Commitment Letters from carriers above EUR 50M cross-border revenue by Month 3 (2027-01-08) with escrow penalties (0.5-1% of quarterly through-ticket revenue), but incumbent resistance (especially Deutsche Bahn, SNCF, ÖBB) is a known threat. Smaller carriers and state-weak operators need tailored incentives (milestone co-funding, hub access, accessible support). Distributors (Trainline, Omio) require early API access and margin support to justify integration investment. Consumer rollout and communications are under-resourced in the plan. The Standing Regulators Committee and twinning partnerships need senior political engagement to be credible.

**What**: Conduct a stakeholder-readiness assessment of the 25+ carriers, major distributors and payment institutions by Month 1.5 (2026-11-23), identifying resistance points (especially among incumbents) and bespoke incentive needs. Develop a carrier engagement and negotiation strategy for securing Commitment Letters by Month 3 (2027-01-08), including political engagement with CER and national transport ministers. Design and test the Standing Regulators Committee's operational model (lead-authority rule, escalation procedures, SLA enforcement) with 6-8 target regulators by Month 2 (2026-12-08). Advise on distributor co-marketing budget allocation and early API access gates to ensure Trainline and Omio prioritise the programme.

**Skills**: Stakeholder negotiation and commitment design, carrier business-model analysis, competitive-response forecasting, distributor margin and incentive structure, consumer communication and advocacy engagement, multi-level political liaison (CER, national ministers, Parliament)

**Search**: rail industry stakeholder engagement, carrier commitment strategy, distributor incentive design, regulatory coordination

## 8.1 Primary Actions

- Secure written Council/Commission Delegation of Authority for the arbitration panel's binding technical-decision authority by Month 1.5 (2026-11-23, 10:00), specifying 60-day decision cycles, 14-day compliance deadlines, force-of-law recognition across all member states, and escalation path to Commission enforcement. Without this, major incumbents can contest rulings and delay the critical path indefinitely.
- Commission customer research by Month 1 (2026-11-08) to validate and pilot a killer application (guaranteed-connection through-ticket, air-rail city-pair, or assisted-travel journey) on one corridor by Month 9 (2027-07-08). Without validated traveller demand, the 40% through-ticket and modal-shift targets are aspirational; distributors and carriers lack incentive to invest.
- Commission an independent cost model by Month 0.5 (2026-10-23, 11:00), due Month 2 (2026-12-08, 17:00), specifying carrier co-funding, hub operating costs, distributor run costs and payment-provider fee exposure. Establish monthly budget-burn dashboards with 115% trigger and Tier 1–3 contingency actions by Month 3 (2027-01-08, 10:00). The EUR 215M free contingency is insufficient against 20–30% overruns; early cost visibility is essential.
- Require all carriers with >EUR 50M annual cross-border revenue to sign binding Commitment Letters accepting arbitration outcomes and penalties (0.5–1% quarterly through-ticket revenue in escrow) by Month 2.5 (2026-12-23, 14:00). Negotiate directly with SNCF, Deutsche Bahn and ÖBB by Month 2.5 (2026-12-23, 11:00) to secure political buy-in; without carrier buy-in, the arbitration panel is toothless.
- Establish direct liaison with European Parliament TRAN and IMCO rapporteurs and key member-state transport ministers (Germany, France, Belgium, Austria, Spain) by Month 0.5 (2026-10-23, 09:00) to obtain weekly Regulation adoption status updates. If adoption slips past Month 8 (2027-06-08, 12:00), commission external standards consortium by Month 8.5 (2027-06-23, 09:00) for accelerated pre-work. Regulation adoption is the critical upstream gate; every month of delay compresses the 9-month standards window and threatens Month 18 (2028-04-08).
- Issue hub operator procurement RFP by Month 0.5 (2026-10-23, 09:00) specifying 4–6 hubs, operational start no later than Month 9 (2027-07-08), 99.9% uptime SLA, <2-second latency, and >10,000 bookings/day capacity. Award contracts by Month 3 (2027-01-08, 17:00) and conduct integration testing pilots by Month 15–18 (2028-01-08 to 2028-04-08). Hub readiness is on the critical path; late procurement cascades delays to Month 30 (2029-04-08) and fragments the network.
- Establish a Standing Regulators Committee by Month 1.5 (2026-11-23, 09:00) with explicit power to enforce arbitration panel rulings across all member states and escalate non-enforcement to the Commission within 5 working days. Without consistent regulator enforcement, access and refund duties remain unenforced, allowing carriers to maintain discriminatory practices.

## 8.2 Secondary Actions

- Commission a comprehensive Data Protection Impact Assessment (DPIA) by Month 1 (2026-11-08, 10:00) and achieve written EDPB/DPA consensus on Standard Contractual Clauses and data-residency rules by Month 4 (2027-02-08, 14:00). Unresolved GDPR governance can halt payment-institution accreditation and delay the data layer by 6–12 months.
- Hire 3–5 regional smaller-carrier support coordinators (based in Budapest, Warsaw, Sofia, Bucharest) by Month 4 (2027-02-08, 12:00) and conduct joint technical integration workshops pairing hub operators and legacy-system carriers by Month 4 (2027-02-08, 15:00). Smaller carriers in central and southeast Europe are disproportionately at risk of missing the Month 30 (2029-04-08) deadline; on-site mentoring and integration troubleshooting are essential.
- Run payment-provider accreditation: market sounding Months 0–1 (2026-10-08 to 2026-11-08); call for applicants Month 2 (2026-12-08); decision Month 8 (2027-06-08); at least 2 accredited providers operational Month 12 (2027-10-08). If fewer than 2 providers apply by Month 6 (2027-04-08), trigger fallback: bilateral carrier settlement or emergency procurement from free contingency.
- Define the through-ticket definition (single booking reference + single payment + continuity-of-journey rights) and validate a measurement baseline by Month 9 (2027-07-08). Commission an independent evaluator by Month 3 (2027-01-08) to build a counterfactual for modal-shift attribution, separating programme effects from fuel prices and aviation taxes.
- Establish a Passenger-Rights Backstop and Liability Framework document by Month 3 (2027-01-08, 13:00) specifying single point of contact, reroute and refund timelines (<4 hours, <10 days), and pooled guarantee fund. Require all operational entities to carry liability insurance (EUR 2–10M errors-and-omissions, EUR 1–5M cyber) by Month 4 (2027-02-08, 15:00).
- Draft a Memorandum of Understanding (MOU) between DG MOVE, EU Agency for Railways and the arbitration panel by Month 1 (2026-11-08, 14:00), specifying staffing (8–12 FTE), operating budget (EUR 2–3M over five years), decision procedures and accountability. Have it signed by all parties by Month 2 (2026-12-08, 12:00).
- Conduct regulator-capacity audit by Month 2 (2026-12-08, 10:00) and establish twinning partnerships between strong and weak regulators by Month 4 (2027-02-08, 14:00), with joint training, shared inspection checklists and quarterly enforcement reviews. Allocate EUR 10–15M over five years for capacity building.
- Design and pilot a public consumer app on one corridor (MVP) by Month 9 (2027-07-08) and launch the public app at Month 15 (2028-01-08). Target satisfaction at least 4.0/5 at Month 18 (2028-04-08) or pause rollout; four-corridor consumer go-live at Month 27 (2029-01-08).
- Establish a task force by Month 36 (2029-10-08) to model sustainability of the distributor, hubs and data layer beyond Month 60 (2031-10-08) on fee recovery, member-state co-funding or carrier contributions. Decide the post-Month 60 (2031-10-08) funding model by Month 48 (2030-10-08) and implement from Month 55 (2031-05-08). Without a post-Month 60 (2031-10-08) model, the programme is at risk of collapse.

## 8.3 Follow Up Consultation

Next review (Month 2 = 2026-12-08): confirm Regulation adoption probability and governance delegation status; review cost model, hub procurement awards and payment-accreditation pipeline. At Month 4 (2027-02-08), validate killer-application pilot design and GDPR DPA consensus. At Months 12 and 24 (2027-10-08, 2028-10-08), assess budget-burn rates, carrier Commitment Letter compliance, hub readiness and through-ticket share versus milestones (target 15% by Month 24 = 2028-10-08). Flag any trigger of Tier 2 or Tier 3 contingency immediately. Discuss competitive responses from airlines, how to signal the killer application to travellers, and post-Month 60 (2031-10-08) funding model assumptions.

## 8.4.A Issue - Killer Application Undefined: Programme Relies on Generic Convenience, Not Compelling Traveller Value

The plan targets 40% through-ticket share and 5-15% modal shift from air, yet no flagship product is defined that makes a traveller choose rail over flying or separate tickets. Through-fares are merely sums of segment prices with no competitive ceiling; reduction-card discounts (~10-15%) do not offset low-cost-airline pricing on short-haul routes. The programme assumes adoption through broad convenience (single booking, single payment) without demonstrating what travellers actually value or will pay for. This is a critical gap: without a clear, testable killer application (e.g., guaranteed-connection product with 4-hour reroute, 10-day refund, and reduction-card recognition), distributor incentive and carrier willingness to invest remain weak.

### 8.4.B Tags

- missing_value_proposition
- modal_shift_assumption_unvalidated
- distributor_margin_incentive_unclear
- carrier_adoption_risk

### 8.4.C Mitigation

Commission customer research by Month 1 (2026-11-08) to validate traveller willingness to pay for three candidate killer applications: (1) guaranteed-connection through-ticket (4-hour reroute, 10-day refund, single contact), (2) air-rail city-pair offer (all-inclusive fare vs. flight competitor), (3) assisted-travel journey (confirmed assistance + priority seating + platform handover). Pilot the winning product on one high-demand corridor (Paris–Brussels–Amsterdam–Köln or Wien–München–Zürich) by Month 9 (2027-07-08) with real traveller bookings and satisfaction tracking. If any product achieves >4.0/5 satisfaction and >15% uptake over separate tickets, scale it to all four corridors by Month 27 (2029-01-08). If none achieves this, escalate to the Steering Committee by Month 12 (2027-10-08) and propose a regulated through-fare ceiling or modal-shift subsidy (decision outside current scope).

### 8.4.D Consequence

Without a validated killer application, the programme risks missing the 40% through-ticket and halved-complaints targets. Distributors (Trainline, Omio) may delay integration if margins are weak. Carriers may comply with the API mandate passively, offering poor through-fare competitiveness or unreliable assistance. Modal shift remains in the 0-5% range instead of the planning range of 5-15%, undermining the environmental case and political credibility. Post-Month 60 (2031-10-08) funding approval becomes harder if outcomes are ambiguous.

### 8.4.E Root Cause

The plan prioritises regulatory and technical architecture over traveller demand validation. It assumes that removing friction (single booking, single payment) is sufficient motivation, yet does not test whether the resulting through-fares or journey experience are actually more attractive than alternative options (flying, separate tickets, or car). The SWOT analysis flagged this as a strength opportunity ('killer application can be developed') but the plan does not resource its development or make it a gated milestone, allowing it to remain unresolved into execution.

## 8.5.A Issue - Arbitration Panel Lacks Binding Enforcement over Major Incumbents Without Explicit Delegation and Penalty Mechanism

The Pragmatic Foundation scenario relies on a lightweight arbitration panel with 60-day decision cycles and 14-day compliance deadlines. However, the plan does not secure the written Council/Commission Delegation of Authority until Month 2 (2026-12-08), and Commitment Letters from major carriers are not due until Month 3 (2027-01-08). Without formal legal authority and documented penalties, large incumbents (Deutsche Bahn, SNCF, ÖBB) can contest technical rulings, demand arbitration review, or simply delay implementation. The proposed escrow penalties (0.5–1% of quarterly through-ticket revenue) are aspirational; no enforcement mechanism or jurisdictional route is specified. If a carrier refuses to comply by Month 3 (2027-01-08) or Month 12 (2027-10-08 or 2027-10-08), the plan has no credible escalation path, risking fragmentation of the network and failure to meet the Month 30 (2029-04-08) API mandate.

### 8.5.B Tags

- governance_authority_not_secured
- incumbent_resistance_risk
- enforcement_mechanism_missing
- critical_path_vulnerability

### 8.5.C Mitigation

Secure written Council/Commission Delegation of Authority by Month 1.5 (2026-11-23, 10:00), not Month 2 (2026-12-08). The delegation must specify: (1) binding decision authority over technical standards, access terms and settlement rules; (2) 60-day decision cycles and 14-day compliance deadlines; (3) force-of-law language so rulings are recognised across all member states; (4) escalation path to the Commission if a carrier does not comply within 14 days, with automatic Commission enforcement action within 5 business days. Require all carriers with >EUR 50M cross-border revenue to sign a binding Commitment Letter by Month 2.5 (2026-12-23, 14:00), accepting arbitration outcomes and penalties (revised: 0.5% of quarterly through-ticket revenue on first violation, 1% on second, withheld until resolution). Establish a Standing Regulators Committee (Month 1.5 = 2026-11-23, 09:00) with explicit power to enforce panel rulings in their jurisdictions and escalate non-enforcement to the Commission within 5 working days. Negotiate directly with SNCF, Deutsche Bahn and ÖBB leadership by Month 2.5 (2026-12-23, 11:00) to secure buy-in; offer them early API-design input in exchange for Commitment Letters.

### 8.5.D Consequence

If the delegation and Commitment Letters are not in place by Month 3 (2027-01-08), major incumbents can delay compliance indefinitely. The Month 18 (2028-04-08) standards deadline will slip if standards cannot be finalized without incumbent consensus. The Month 30 (2029-04-08) API mandate becomes unenforceable if the panel's rulings are not backed by Commission authority. The through-ticket network fragments: early-adopting carriers go live on time, while incumbents remain non-compliant, leaving travellers unable to book consistent end-to-end journeys. The 40% through-ticket target becomes unrealistic if key corridors (Wien–München–Zürich, Madrid–Barcelona–Lyon) are held up by one non-compliant carrier.

### 8.5.E Root Cause

The plan assumes that arbitration panel authority will be formally delegated, but does not resource the political negotiation or legal drafting needed to secure it. It treats the Delegation and Commitment Letters as routine administrative steps, not as critical blockers that require high-level political engagement and legal certainty. The contingency and risk-mitigation sections note governance risk but do not specify the escalation path or who is responsible for securing delegation by the required date.

## 8.6.A Issue - Fixed Budget (EUR 1.5B) Is Fragile Against 20–30% Overrun; Free Contingency (EUR 215M) Is Insufficient; Post-Month 60 (2031-10-08) Funding Cliff Is Unresolved

The plan allocates EUR 1.5 billion across standards (EUR 280M), clearing (EUR 120M), reference distributor (EUR 215M), capacity building (EUR 100M), consumer rollout (EUR 150M), carrier co-funding (EUR 290M), data layer (EUR 60M) and governance (EUR 60M), with EUR 225M contingency held at DG MOVE (EUR 215M free, EUR 10M earmarked for passenger-rights residual). A 20–30% overrun (EUR 300–450M) exceeds the free contingency by EUR 85–235M. Major cost risks are unmitigated: distributor operating costs (budgeted EUR 43M/year, estimate EUR 50–65M/year if extended), hub economics gap (EUR 0.47M/year per hub × 4 hubs = EUR 1.9M/year unfunded), payment-provider fee subsidies (EUR 15M budget, estimate EUR 20–25M if through-ticket adoption is slow), and carrier co-funding demand (budgeted EUR 290M, estimate 12–18 carriers × EUR 20–30M each = EUR 240–540M). Post-Month 60 (2031-10-08), recurring run costs of approximately EUR 45M/year (distributor + hub gap + data layer + regulator costs) are explicitly unfunded. The plan assumes supplementary budget authority of EUR 100–200M from the Commission by Month 12 (2027-10-08), but this is outside the cap and not confirmed. No decision on post-Month 60 (2031-10-08) funding model exists, risking programme collapse after 5 years.

### 8.6.B Tags

- budget_fragility
- cost_overrun_unmitigated
- distributor_cost_underestimated
- unfunded_recurring_costs
- post_programme_cliff_risk

### 8.6.C Mitigation

Commission an independent cost-modelling firm by Month 0.5 (2026-10-23, 11:00) to produce a detailed activity-based cost forecast by Month 2 (2026-12-08, 17:00), specifying: carrier co-funding per carrier (EUR 2–8M per SME, EUR 10–15M per mid-size, EUR 0.5–2M per major), hub operating cost per hub (EUR 1.2M/year vs. EUR 0.73M/year revenue = EUR 0.47M/year gap per hub), public distributor annual operating cost (EUR 50–65M/year for full retail, EUR 20–30M/year for reference implementation), and payment-institution fee exposure (EUR 80–160M over five years at 0.5–1.0% per transaction). Establish monthly budget-burn dashboards by Month 3 (2027-01-08, 10:00) showing cumulative spend vs. pro-rata forecast with automatic trigger if quarterly spend exceeds 115% of budget line; escalate any trigger to DG MOVE within 5 working days. Define three contingency tiers: Tier 1 (10–15% overrun): defer consumer-app polish, reduce distributor co-marketing by 20%; Tier 2 (15–25% overrun): reduce carrier co-funding rate from 20% to 10%, limit hub openings to priority corridors only; Tier 3 (>25% overrun): suspend new hub openings, scale back capacity building to 3–4 priority member states. Secure DG MOVE commitment by Month 3 (2027-01-08, 14:00) to seek supplementary budget authority from the Commission by Month 12 (2027-10-08) if Tier 2 is triggered, with target allocation EUR 100–200M. Establish a post-Month 60 (2031-10-08) funding decision task force by Month 36 (2029-10-08) to model sustainability of distributor, hubs and data layer on fee recovery, member-state co-funding or voluntary carrier contributions. Decide the post-Month 60 (2031-10-08) funding model by Month 48 (2030-10-08), with implementation from Month 55 (2031-05-08).

### 8.6.D Consequence

If cost overruns are not detected and mitigated early, contingency is exhausted by Month 18–24 (2028-04-08 to 2028-10-08). Conformance testing, capacity building and smaller-carrier support are cut, causing 20–30% of carriers to miss the Month 30 (2029-04-08) API deadline. Smaller carriers and weaker-capacity regulators are disproportionately affected, fragmenting the network and reducing through-ticket coverage to 60–70% of potential corridors. Distributor operations are scaled back; app quality and consumer support suffer. Post-Month 60 (2031-10-08), if no sustainable funding model is decided, the distributor shuts down, hubs cease operations, and the data layer is abandoned, reverting cross-border rail to the pre-programme fragmentation. The 40% through-ticket target becomes unrealistic; the investment is stranded.

### 8.6.E Root Cause

The plan aggregates estimated costs (EUR 0.5–2B private carrier IT, EUR 10–40M passenger-rights backstop, EUR 45M/year post-Month 60 (2031-10-08) run costs) as separate from the cap, treating the cap as if it covers only 'core' infrastructure. However, no independent cost audit has validated the EUR 1.5B allocation or the hidden costs in distributor operations, hub subsidies and payment-provider fees. The plan assumes supplementary budget authority without securing it or triggering it at a decision point. Post-Month 60 (2031-10-08) funding is not addressed until Month 48 (2030-10-08), leaving only 12 months for a political and operational redesign if sustainability cannot be assured.