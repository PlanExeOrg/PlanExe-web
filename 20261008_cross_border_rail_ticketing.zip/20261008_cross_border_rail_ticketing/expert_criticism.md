# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: EU Competition Law Counsel

**Knowledge**: Article 101 TFEU, state aid, transport regulation, competition clearance procedures

**Why**: The programme's shared inventory data layer, federated clearing mechanism and commission-band governance create Article 101 coordination risk that could unwind investments post-launch. Decision 14 (Joint Conduct Safe-Harbour) identifies this as critical, requiring pre-notification to DG COMP by Month 2 (2026-12-12) and formal guidance by Month 12 (2027-10-12). Without early clearance, carriers will hesitate to commit inventory, and post-launch challenges could force EUR 50-100M rework.

**What**: Prepare the DG COMP pre-notification memorandum describing the clearing mechanism, data flows and through-fare construction doctrine; identify which design elements (pooled liability, netting, fare apportionment) trigger Article 101 scrutiny and propose a clean-team protocol to mitigate exposure; track stakeholder comments on the binding standards (Month 18 = 2028-04-12) and brief the steering group on legal risk quarterly starting Month 6 (2027-04-12).

**Skills**: EU legal drafting, competition-law risk assessment, cartel-exemption procedures, transport-sector precedent analysis, stakeholder negotiation with regulators

**Search**: EU competition law transport regulation, Article 101 TFEU safe harbour, rail clearing mechanism, state aid transport

## 1.1 Primary Actions

- Commission an external EU competition counsel immediately at Month 0.5 (2026-10-27) to draft a detailed DG COMP pre-notification memorandum (EUR 300-500K); submit to DG COMP by Month 1 (2026-11-12) with request for interim guidance by Month 9 (2027-07-12) and final clearance by Month 12 (2027-10-12). Prepare a fallback bilateral clearing design ready to deploy by Month 15 (2028-01-12) if federated netting is not cleared.
- Scope the actuarial study (EUR 300-400K) to deliver baseline miss-connection rates and loss data for 5+ major carriers by Month 1.5 (2026-11-27); sensitivity analysis and parameter options by Month 2 (2026-12-12); draft liability model with worked examples by Month 2.5 (2026-12-27). Conduct bilateral carrier feedback meetings (Month 2.5 = 2026-12-27 to Month 3.5 = 2027-01-27 to 2027-01-26) and finalize the model with signed letters of intent from at least 8 carriers by Month 4 (2027-02-12).
- Publish a Governance Charter for the federated clearing and availability layer by Month 6 (2027-04-12) specifying composition (large, small, CER, distributor representation), voting rules (supermajority, blocking minority), independent ombudsman, equal technical standards for all tiers, and transparency reporting. Submit the Charter to DG COMP for approval at Month 12 (2027-10-12). Define explicitly whether Tier 2 and Tier 3 carriers are integrated into the main shared layer or separate, and what transition paths exist.
- Establish the steering group by Month 1 (2026-11-12) with biweekly meetings (Mondays 09:00 Brussels time) comprising representatives from DG MOVE, EU Agency for Railways, CER, 4 major carriers, Trainline, Omio, BEUC and one disability-rights body. Publish option papers for Decisions 1-5 by Month 2 (2026-12-12); hold binding votes (75% supermajority) by Month 6 (2027-04-12) with Commission mediation by Month 5 (2027-03-12) if consensus is not reached.
- Execute a pre-programme technical audit of all 25+ carriers by Month 2 (2026-12-12) assessing OSDM API readiness, event-streaming, latency (p95 response time), availability (12-month %), and staffing. Publish tier assignments and timelines (Tier 1 Month 30 = 2029-04-12; Tier 2 Month 36 = 2029-10-12; Tier 3 Month 42 = 2030-04-12) by Month 6 (2027-04-12). Allocate EUR 240M adapter funding in tranches tied to verified API performance (99.5% uptime, <1% stale-seat failures).

## 1.2 Secondary Actions

- Initiate informal soundings with 3-4 smaller carriers (not in the Tier 1 group) at Month 0.5 (2026-10-27) to assess their concerns about governance of the shared layer; incorporate their feedback into the Governance Charter by Month 5 (2027-03-12).
- Retain external competition counsel from Month 6 (2027-04-12) onwards (EUR 2-5M budget over three years) to monitor for Article 101 challenges post-launch and prepare contingency redesigns. Brief the steering group quarterly on legal risk starting Month 9 (2027-07-12).
- Commission an independent legal review of the liability model against EU Regulation 1371/2007 (railway passengers' rights) at Month 1 (2026-11-12), with opinion by Month 6 (2027-04-12). Develop a passenger-rights compliance manual by Month 9 (2027-07-12) and submit to the EU Agency for Railways for approval; require all carriers to certify staff training as a conformance condition.
- Establish quarterly pool-monitoring and liability-model adjustment reviews starting Month 6 (2027-04-12). If actual incident rates exceed forecast by >20% in any quarter, trigger a model review and communicate adjustment options to carriers within 15 business days; publish adjustment impact on per-carrier contributions within 30 days.
- Define the split of the EUR 300M concession envelope (platform set-up vs. service-payment subsidy) and the financing of ticket-validation hardware retrofits by Month 9 (2027-07-12). Publish the business case for the concession tender by Month 9 (2027-07-12) and launch the tender at Month 12 (2027-10-12) to achieve award by Month 18 (2028-04-12).

## 1.3 Follow Up Consultation

At the next consultation, bring: (1) the draft DG COMP pre-notification memorandum and interim response timeline (by Month 1.5 = 2026-11-27); (2) actuarial study baseline data and parameter sensitivity analysis (by Month 2.5 = 2026-12-27); (3) draft Governance Charter with carrier and distributor feedback (by Month 5 = 2027-03-12); (4) technical audit findings and tier assignments (by Month 6 = 2027-04-12); (5) the steering group's voting record and mediation outcomes on Decisions 1-5 (by Month 7 = 2027-05-12). Bring also: clarification on who controls the dispute resolution escalation process in the federated clearing (is it the EU Agency for Railways, an arbitrator, or majority-vote by carriers?); confirmation that the clean-team protocol will be finished by Month 12 (2027-10-12), not Month 14 (2027-12-12); and resolution of the open concession split and validation-hardware financing.</follow_up_consultation>


## 1.4.A Issue - Article 101 TFEU clearance timeline is too tight and insufficiently detailed for federated clearing design

The plan schedules DG COMP pre-notification at Month 2 (2026-12-12) with guidance by Month 12 (2027-10-12), but does not yet describe the federated settlement data layer architecture clearly enough for meaningful competition review. Federated netting across competitors' transactions pooling fares, inventory shadows and dispute reconciliation resembles cartel coordination. The clean-team protocol (Month 14 = 2027-12-12) arrives 4 months after binding standards are due (Month 18 = 2028-04-12), creating legal uncertainty for carriers to sign the liability model. A post-standards challenge could unwind EUR 50-100M of clearing investment. Competitors sharing real-time availability (streamed shadow) and settlement data under one rulebook heightens scrutiny.

### 1.4.B Tags

- Article_101_timing
- competition_law_exposure
- data_pooling_risk
- clean_team_delay

### 1.4.C Mitigation

Immediately commission an external EU competition counsel (EUR 300-500K budget) to draft a detailed pre-notification memorandum at Month 0.5 (2026-10-27) describing: (1) federated netting architecture with named participants, data flows and access control; (2) through-fare construction rules and how they differ from price coordination; (3) access terms for independent distributors and smaller carriers; (4) Article 101 exemption narrative under Regulation 1/2003 or the Digital Markets Act safe-harbour. Submit to DG COMP by Month 1 (2026-11-12), not Month 2 (2026-12-12). Request expedited review with interim guidance by Month 9 (2027-07-12), final by Month 12 (2027-10-12). Anchor the clean-team protocol design in DG COMP's interim feedback so it is ready at Month 12 (2027-10-12), not Month 14 (2027-12-12). If DG COMP's guidance is unfavourable to federated netting, have a fallback design (bilateral clearing with a neutral dispute layer) ready to pivot by Month 15 (2028-01-12).

### 1.4.D Consequence

Without expedited, detailed competition-law comfort before binding standards (Month 18 = 2028-04-12), carriers will not sign the liability model at Month 4 (2027-02-12), because their exposure is legally uncertain. Steering votes at Month 6 (2027-04-12) will stall pending DG COMP clarity. A post-Month 24 (2028-10-12) Article 101 challenge could force redesign of clearing, data layers and through-fare rules, consuming EUR 50-100M and 6-12 months. Smaller distributors and carriers may challenge the federated model as exclusionary, triggering additional review cycles. Binding standards will slip to Month 24-30 (2028-10-12 to 2029-04-12), pushing API exposure past Month 30 (2029-04-12) and risking the 40% through-ticket target.

### 1.4.E Root Cause

The federated clearing and availability designs were finalized without explicit legal scaffolding mapped to DG COMP review cycles. The plan assumes DG COMP guidance is advisory, when it must be binding pre-notification comfort before binding standards. Without a detailed legal memorandum describing data flows, netting rules and access terms submitted at Month 2 (2026-12-12), DG COMP cannot review meaningfully, and the clean-team protocol arrival after standards bind leaves a 4-6 month legal gap.

## 1.5.A Issue - Carrier liability model parameters are indicative, not actuarially validated; caps and co-insurance lack empirical foundation

The plan proposes per-incident caps of EUR 500-1,000 per stranded passenger and co-insurance above EUR 50M annual pool draw, marked as '(proposed threshold)' and '(indicative)'. These figures are not derived from missed-connection rates, rerouting costs, incident clustering or carrier loss data. Without actuarial validation, carriers cannot price their exposure and will refuse to commit to the liability model at Month 4 (2027-02-12). The plan mandates sign-off from at least 8 major carriers and CER by Month 4 (2027-02-12) as a steering gate, but if the liability model is not credible, carriers will withhold commitment. The actuarial study is commissioned at Month 1 (2026-11-12) but interim results are not due until Month 3 (2027-01-12), leaving only 4 weeks before sign-off is required. Quarterly pool monitoring starting Month 6 (2027-04-12) presumes the model is already priced and working, risking corrections mid-programme.

### 1.5.B Tags

- liability_pricing_gap
- actuarial_validation_missing
- carrier_sign_off_risk
- timeline_compression

### 1.5.C Mitigation

Scope the actuarial study (EUR 300-400K) to deliver: (1) 24-month baseline missed-connection rates, rerouting costs and incident clustering for at least 5 major carriers (SNCF, DB, SBB, Renfe, NS or ÖBB) by Month 1.5 (2026-11-27); (2) sensitivity analysis for caps at EUR 250, 500, 1,000 and EUR 2,000 and co-insurance triggers at EUR 20M, 50M and EUR 100M annual draw by Month 2 (2026-12-12); (3) draft weighting formula (tied to on-time performance and booking availability, not forward forecasts) with worked examples for three carrier profiles by Month 2.5 (2026-12-27). Conduct bilateral meetings with at least 8 carriers between Month 2.5 (2026-12-27) and Month 3.5 (2027-01-27) to gather feedback on which parameter combinations trigger participation or refusal. Finalize the model by Month 4 (2027-02-12) with signed letters of intent from at least 8 carriers confirming commitment under the chosen parameters. Publish quarterly pool reports (starting Month 6 = 2027-04-12) showing actual rates versus forecast and any parameter adjustment triggers needed by Month 12 (2027-10-12).

### 1.5.D Consequence

If the liability model remains indicative and unvalidated at Month 4 (2027-02-12), fewer than 5 carriers will sign the letter of intent, failing the Month 6 (2027-04-12) readiness gate. The steering vote will be deferred to Month 12 (2027-10-12), pushing binding standards to Month 24 (2028-10-12) and API exposure to Month 36 (2029-10-12). Carrier participation will drop from 25 targeted to 10-15, fragmenting corridors: the four priority routes will only be complete if all major carriers on each route commit, so a 40% refusal rate leaves at most 1-2 corridors viable. The 40% through-ticket target will fall to 15-20%. Pool overruns in Year 2-3 (Months 24-36 = 2028-10-12 to 2029-10-12) will drain the EUR 150M reserve if actual incident rates exceed forecast, leaving no budget buffer for other overruns.

### 1.5.E Root Cause

The plan conflates the liability model's structural choice (carrier-funded mutual guarantee pool) with the financial parameters (caps, co-insurance, contribution weights) that make carriers willing to participate. The structural choice was made in Month 0 (2026-10-12) without empirical loss data; the financial parameters were set as illustrative thresholds without asking: what missed-connection rates, rerouting costs, or cumulative liability would trigger refusal? The actuarial brief was not scoped to deliver interim results and carrier feedback cycles before Month 4 (2027-02-12), so the timeline is unachievable.

## 1.6.A Issue - Joint Conduct Safe-Harbour does not address supply-side foreclosure: smaller carriers and independent distributors will be excluded if data and clearing governance concentrate power with incumbents

The plan proposes federated clearing and streamed availability as a 'neutral' layer, but the decision on who controls the availability shadow, the shared netting rulebook and the dispute resolution criteria determines whether smaller carriers and independent distributors can participate on equal terms. Article 101 safe-harbouring assumes non-discriminatory access, but the plan does not define: (1) who sets the netting rules and arbitrates disputes (is it majority-vote by large carriers, or an independent body?)? (2) What recourse does a smaller carrier or distributor have if they believe the reconciliation algorithm excludes their transactions?; (3) How are connectivity standards (latency, availability, data format) set so smaller carriers can afford to comply? The plan mandates Tier 1 (Month 30 = 2029-04-12), Tier 2 (Month 36 = 2029-10-12) and Tier 3 (Month 42 = 2030-04-12) API exposure, but does not specify whether the shared availability and clearing layer will apply to Tier 3 carriers with the same rules as Tier 1, or whether they will be siloed. If Tier 3 is siloed, those 8-15 carriers (estimate) will be cut out of the main through-ticketing flow, losing 20-30% (estimate) of cross-border volume.

### 1.6.B Tags

- foreclosure_risk
- governance_concentration
- tier_fragmentation
- small_carrier_exclusion
- safe_harbour_incompleteness

### 1.6.C Mitigation

Publish a detailed Governance Charter for the federated clearing and availability layer by Month 6 (2027-04-12) that specifies: (1) composition of the rules-setting body (minimum 5 large carriers, 2-3 small/regional, CER representative, one independent distributor); (2) voting rule (supermajority 60%, with blocking minority for small carriers on issues affecting them); (3) independent ombudsman (appointed by the EU Agency for Railways) with power to arbitrate disputes over reconciliation or access denial within 20 business days; (4) equal technical standards for all carriers and distributors (same API, latency/availability SLA, data format), with no separate 'fast-track' or 'premium' path for incumbents; (5) quarterly transparency reports (start Month 12 = 2027-10-12) listing all disputes, denials and rule changes, published to all carriers and the Commission. Require DG COMP to review and approve the Charter at Month 12 (2027-10-12) before it becomes binding. Define explicitly: are Tier 2 and Tier 3 carriers integrated into the same availability shadow and clearing netting, or do they use a separate flow? If separate, why is it necessary, and what recourse do they have to migrate to the main flow? If integrated, what cost subsidies or transition support are provided? Include this decision and answer in the Governance Charter.

### 1.6.D Consequence

Without a published Governance Charter and DG COMP approval by Month 12 (2027-10-12), smaller carriers and independent distributors will assume the shared layer is controlled by incumbents and will refuse to commit to the mandatory API exposure, triggering participation collapse. DG COMP may issue a warning in its guidance letter (Month 12 = 2027-10-12) that the federated clearing structure raises exclusionary concerns under Article 102 TFEU (abuse of dominance) if the governance is not transparent. This will force redesign of the clearing and availability layers at Month 15-18 (2028-01-12 to 2028-04-12), delaying binding standards. If redesign is deferred past Month 18 (2028-04-12), binding standards will slip to Month 24 (2028-10-12). A post-launch challenge by a smaller carrier or distributor excluded from the shared layer could unwind the clearing arrangement, forcing transition to bilateral settlement and losing the efficiency of cross-carrier netting: this is estimated to cost EUR 30-50M in rework and lose 8-12 months.

### 1.6.E Root Cause

The plan focuses on Article 101 safety (formal pre-notification, clean-team) without addressing the structural conditions under which the safe-harbour survives scrutiny: equal and non-discriminatory access. The federated clearing design is described generically as 'connect existing bilateral arrangements', but does not specify the governance structure that decides how transactions are nettled, how disputes are resolved, or how the layer treats Tier 2 and Tier 3 carriers. The tiering structure (by API readiness, not by size) accidentally creates leverage for large carriers to define the rules before smaller carriers arrive. DG COMP's Article 101 review will flag supply-side foreclosure if the shared layer's governance is opaque or controlled by a subset of competitors.

---

# 2 Expert: Rail Passenger Rights and Liability Actuary

**Knowledge**: Railway passenger compensation, missed-connection loss rates, rerouting cost models, insurance underwriting, pool design and co-insurance structures

**Why**: The carrier-funded mutual guarantee pool (Decision 1: Through-Ticket Liability and Rights Backstop) is the lynchpin decision that determines whether carriers will expose inventory. Current liability caps (EUR 500-1,000 per passenger) and co-insurance thresholds (EUR 50M) are indicative, not actuarially validated. The pre-assessment feedback specifies that carriers face unpriceable exposure if this model is not delivered by Month 4 (2027-02-12), risking 30-40% carrier refusal and cutting the 40% through-ticket goal to 15-25%.

**What**: Commission and lead the actuarial study due Month 1 (2026-11-12) using 24-month rolling carrier loss data; model per-incident incident caps and annual co-insurance triggers for three carrier profiles (large, regional, small); draft the liability-weighting formula (contributions tied to trailing 12-month on-time performance) by Month 3 (2027-01-12); present to steering group and obtain written sign-off from at least 8 major carriers and CER by Month 4 (2027-02-12); establish quarterly pool-monitoring and reserve-reporting by Month 6 (2027-04-12).

**Skills**: Claims loss modelling, actuarial projection, insurance co-insurance mechanics, transport-sector benchmarking, financial forecasting and variance analysis

**Search**: railway insurance actuarial, passenger compensation claims modelling, missed-connection loss rates, mutual guarantee pool design, transport liability underwriting

## 2.1 Primary Actions

- Commission an independent actuarial firm by end of Month 0 (2026-10-12) to deliver interim missed-connection loss rates and rerouting cost percentiles by Month 1.5 (2026-11-27), and publish a priced carrier liability model (per-incident caps, co-insurance, contribution formula with worked examples) by Month 3 (2027-01-12); obtain written sign-off from at least 8 major carriers and CER confirming willingness to expose inventory under the model's terms by Month 4 (2027-02-12), or escalate to Commission mediation for pool design adjustment by Month 5 (2027-03-12).
- Accelerate the technical audit of all 25+ carriers to Month 1 (2026-11-12) deliverable (interim readiness signals), with full 25-carrier system assessment and draft tier assignment published by Month 3 (2027-01-12); freeze tier assignment and conformance timelines only after steering vote at Month 6 (2027-04-12); if audit reveals >35% of carriers cannot achieve Month 30 (2029-04-12) mandatory API exposure, establish Tier 1.5 (Month 33 = 2029-07-12) cohort or pilot-only Phase 1 commitment for later tiers by Month 2 (2026-12-12) regulatory dialogue with DG MOVE.
- Resolve the validation-hardware financing model and concession budget split by Month 1 (2026-11-12): conduct carrier survey on public-subsidy requirement (EUR 0, EUR 40M, or EUR 80M scenarios), publish concession envelope split (set-up vs. subsidy) by Month 9 (2027-07-12), and carve out explicit TEN-T extension validation budget (EUR 100–150M) by Month 3 (2027-01-12) with impact mapping to concession, adapter and headroom; model and present three scenarios (A, B, C) to steering group by Month 6 (2027-04-12) for binding decision.

## 2.2 Secondary Actions

- Establish a quarterly pool-monitoring process by Month 6 (2027-04-12) that publishes actual carrier incident rates, contribution adjustments, reserve drawdown and cash flows within 15 business days of quarter-end, enabling carriers to model forward exposure and adjust underwriting; tie pool rebalancing to performance signals so that chronic late-running carriers face higher co-insurance thresholds.
- Procure shared adapter modules (EUR 30–50M) for common legacy patterns (mainframe inventory, flat-file settlement) by Month 12 (2027-10-12), reusable across Tier 2 and Tier 3 carriers, reducing per-carrier integration cost by an estimated 20–30% and accelerating readiness for Tier 2 cohort (Month 36 = 2029-10-12).
- Deploy SLA monitoring proxy and public scorecards by Month 12 (2027-10-12) showing each carrier's p50/p95/p99 latency, availability and booking-error rates; attach automatic tranche penalties (5% loss) to carriers missing SLA targets for two consecutive months to create market incentive for compliance and operational discipline.
- Conduct a pre-binding-standards pilot with 2,000–4,000 passengers (500–1,000 per corridor) across the four priority corridors at Months 12–18 (2027-10-12 to 2028-04-12), measuring end-to-end latency, stale-seat booking failures, reroute success rates and passenger satisfaction; publish pilot results by Month 18 (2028-04-12) to validate architecture assumptions before full binding commitment.
- Commission competition-law counsel by Month 2 (2026-12-12) to prepare DG COMP pre-notification filing; file pre-notification by Month 2 (2026-12-12) end of week; obtain guidance letter by Month 12 (2027-10-12) and establish clean-team protocol by Month 14 (2027-12-12); maintain counsel engagement through Month 36 (2029-10-12) to monitor post-launch legal challenges and prepare contingency rework if Article 101 issues emerge.

## 2.3 Follow Up Consultation

In the next consultation, discuss: (1) Carrier loss data: have major carriers provided 24-month rolling missed-connection, rerouting cost and incident-clustering data to the actuarial firm, and are preliminary loss distributions available to validate pool design by Month 2 (2026-12-12)? (2) Audit interim findings: which carriers have self-assessed API readiness and identified legacy-system bottlenecks; are there early signals of Tier 1/2 miss risk? (3) Validation hardware: have carriers responded to the public-subsidy survey, and has the finance lead published scenarios A/B/C with concession and headroom impact? (4) Competition law: has DG COMP acknowledged the pre-notification filing, and are there early signals of Article 101 concern requiring clean-team protocol acceleration? (5) Steering governance: are the 75% voting rule and Commission mediation process in place, and have option papers on Decisions 1–5 been drafted for Month 2 (2026-12-12) circulation?

## 2.4.A Issue - Liability pool contribution weighting is unpriceable without carrier historical loss data; carriers cannot commit until actuarial parameters are published and validated

The draft liability model proposes a carrier-funded guarantee pool weighted by trailing 12-month on-time performance, but no actuarial study has been commissioned to establish baseline missed-connection rates, rerouting cost distributions or incident clustering patterns per carrier. The indicative caps (EUR 500–1,000 per stranded passenger) and co-insurance trigger (EUR 50M annual pool draw) are not grounded in loss data. Carriers face unpriceable exposure: they cannot calculate probability-weighted loss reserves or insurance recourse until loss distributions per carrier are published. This directly blocks Month 4 (2027-02-12) carrier sign-off and Month 6 (2027-04-12) steering vote. Without signed carrier commitment, the programme lacks the baseline participant list needed to set conformance timelines and funding tranches.

### 2.4.B Tags

- actuarial_gap
- carrier_refusal_risk
- liability_unpriced
- month_4_gate_blocker

### 2.4.C Mitigation

Commission an independent actuarial firm by Month 0 (2026-10-12) end of week to deliver interim loss parameters (missed-connection frequencies, rerouting cost percentiles, incident clusters by carrier size) by Month 1.5 (2026-11-27), with carrier-group estimates by Month 2 (2026-12-12). Publish a priced model (caps, co-insurance, contribution formula) by Month 3 (2027-01-12) with worked examples for three carrier profiles. Require CER and at least 8 major carriers to sign off the model with written capacity statements (estimated loss reserve, insurance line capacity) by Month 4 (2027-02-12). If sign-off falls below 6 carriers by Month 5 (2027-03-12), trigger Commission mediation and present a two-tier pool design (core carriers + optional reinsurance for smaller operators) to lower individual exposure.

### 2.4.D Consequence

Without priced parameters by Month 2 (2026-12-12), the Month 4 (2027-02-12) carrier sign-off gate will fail, cascading to Month 6 (2027-04-12) steering deadlock and likely Month 12 (2027-10-12) deferral. Estimated 30–40% of medium and smaller carriers (8–12 operators) will refuse to expose inventory, fragmenting two of the four priority corridors and cutting the 40% through-ticket goal to 15–25% by Month 60 (2031-10-12). Budget risk: emergency bilateral agreements with dissenting carriers could consume EUR 50–75M of adapter funding.

### 2.4.E Root Cause

No independent actuarial study commissioned before legal model design. The pre-project assessment identifies this as a blocking dependency, yet the project plan defers commissioning until Month 1 (2026-11-12) with publication only by Month 3 (2027-01-12). This creates a 3-month delay between project start and publishable loss parameters. Carriers will not expose inventory under unpriceable terms, forcing Month 6 (2027-04-12) gate deferral or redesign.

## 2.5.A Issue - Technical audit sequencing is backwards: conformance tier assignment must precede OSDM binding standards, not follow them, to set realistic API exposure milestones

The plan commits to binding standards by Month 18 (2028-04-12) and mandatory API exposure by Month 30 (2029-04-12) for Tier 1, but the technical audit of all 25+ carriers is scheduled for Month 2 (2026-12-12) with tier publication only at Month 6 (2027-04-12). This creates a 12-month gap: standards are frozen before carrier readiness is known. The pre-project assessment warns that 8–15 smaller operators (40–50% of non-core carriers) risk missing Month 30 (2029-04-12), yet binding standards cannot be adjusted post-Month 18 (2028-04-12). Tier 3 operators (Month 42 = 2030-04-12) will face an 18-month standards shelf-life with no accommodation for late participants, inviting refusal or divergent implementations.

### 2.5.B Tags

- audit_sequencing_error
- tier_timelines_unvalidated
- standards_locked_early
- month_30_miss_risk

### 2.5.C Mitigation

Accelerate the technical audit to Month 0.5 (2026-10-27) working groups (in parallel with liability commissioning) to provide interim readiness signals by Month 1 (2026-11-12). Commission a detailed 25-carrier system assessment by Month 1.5 (2026-11-27) covering API build effort, legacy-system dependencies, staffing availability and vendor commitments. Publish a draft tier assignment and per-carrier roadmap by Month 3 (2027-01-12) and freeze tier assignment only after steering vote at Month 6 (2027-04-12). If the audit reveals >35% of targeted carriers cannot achieve Month 30 (2029-04-12), establish a Tier 1.5 (Month 33 = 2029-07-12) cohort and revise the binding-standards text to allow Phase 1 pilot-only commitment for Tier 2/3, binding commitment for Month 36 (2029-10-12). Consult the EU Agency for Railways and DG MOVE on regulatory flexibility by Month 2 (2026-12-12).

### 2.5.D Consequence

If the audit reveals widespread latency (e.g., 12 of 25 carriers cannot support 99.5% availability by Month 30 = 2029-04-12), the binding standards freeze will force either (a) a watered-down SLA that permits fragmented user experience, or (b) forced exclusion of non-ready carriers, cutting participating operators from 25 to 13–15 and the 40% through-ticket target to 10–20%. Emergency adapter funding of EUR 150–250M will exceed the EUR 85M headroom, requiring Phase 3 TEN-T cancellation or concession subsidy cuts. Estimated 6–12 month schedule slip to Months 36–42 (2029-10-12 to 2030-04-12) if remediation is required post-Month 18 (2028-04-12).

### 2.5.E Root Cause

The binding-standards deadline (Month 18 = 2028-04-12) is regulatory and fixed by the proposed Regulation. The audit was scheduled to fit after steering decisions (Month 6 = 2027-04-12) and before standards lock (Month 18 = 2028-04-12). However, this leaves only 12 months to redesign tier timelines if the audit reveals 50% of Tier 2 and Tier 3 carriers lack API capability by their assigned dates. Conformance tiering should be informed by the audit, not constrained by pre-assigned regulatory milestones.

## 2.6.A Issue - Budget allocation does not account for the cost of ticket-validation hardware retrofits or final concession setup; EUR 85M headroom is insufficient if either carrier-funded or public-funded paths are chosen

The canonical budget allocates EUR 1,415M across nine line items and rings EUR 150M for force-majeure reserve, leaving EUR 85M free headroom (5.7% of the EUR 1,500M cap). However, three major cost categories remain unallocated: (1) ticket-validation credential and barcode retrofits on rolling stock and station gates across four corridors (estimated EUR 30–80M); (2) concession platform set-up and first-wave subsidy (EUR 300M envelope is split between set-up cost and public service-level payments, split undefined); (3) TEN-T extension rollout of validation infrastructure to 40+ additional corridors (Months 48–60 = 2030-10-12 to 2031-10-12). If validation hardware is carrier-funded, they may refuse or delay; if public-funded, the EUR 85M headroom is consumed entirely by one decision, leaving no contingency for adapter, clearing or concession overruns.

### 2.6.B Tags

- budget_gap
- validation_hardware_unallocated
- concession_split_open
- headroom_exhausted

### 2.6.C Mitigation

Resolve the validation-hardware financing model by Month 1 (2026-11-12): conduct a 30-day carrier survey asking whether each carrier will fund its own credential infrastructure or require public subsidy and at what cost per train/station. For carriers requiring public subsidy, establish a separate EUR 50–80M line item (funded from the EUR 85M headroom or by reducing concession subsidy from EUR 60M to EUR 40M). Publish the concession budget split by Month 9 (2027-07-12): e.g., EUR 80M for platform set-up and integration, EUR 220M for operating subsidy. Carve out explicit EUR 100–150M for TEN-T extension validation by Month 3 (2027-01-12), reducing either the concession envelope or freeing up adapter funds through shared infrastructure modules. Model three scenarios: (A) carriers fund validation 100%, (B) public funds 50% (EUR 40M), (C) public funds 100% (EUR 80M), with each mapped to concession and TEN-T headroom impact.

### 2.6.D Consequence

If validation hardware retrofit costs are realized as public-funded in Months 24–30 (2028-10-12 to 2029-04-12) at EUR 60–80M and the concession requires its full EUR 300M envelope, the cumulative variance will hit EUR 200M+ by Month 30 (2029-04-12), triggering the second variance gate (20% concession subsidy cut to EUR 48M, contract term extended 5–7 years). This forces the concessionaire to reduce service quality or scale. If validation is deferred beyond Month 30 (2029-04-12), the four-corridor go-live at Month 48 (2030-10-12) is at risk: conductors and passengers cannot validate tickets. Estimated schedule slip of 3–6 months and budget stress of EUR 200–300M total variance if both validation and concession costs exceed forecasts.

### 2.6.E Root Cause

The budget lines treat validation as a separate decision (Decision 13: Ticket Validation and Onboard Inspection Interoperability) that slides to Month 30 (2029-04-12) rollout. However, hardware procurement and retrofitting follow rolling-stock maintenance schedules that carriers control; public subsidy of retrofits competes directly with funding for concession platform and TEN-T extension. The EUR 300M concession envelope is stated as an envelope but not split between set-up (platform, integration, staffing for launch) and subsidy (public service-level payments over five years). This creates a planning illusion: total committed spend is unclear.

---

# 3 Expert: Rail Booking Systems Integration Engineer

**Knowledge**: OSDM API design, real-time inventory management, legacy mainframe integration, distributed event streaming, latency and availability profiling

**Why**: Decision 5 (Availability Query Topology and Authoritative Booking Source) and Decision 6 (Conformance Gate) require that 8-15 smaller carriers connect legacy booking systems to a federated real-time layer by Month 30 (2029-04-12) at p95 latency <2 seconds and 99.5% availability. The technical audit due Month 2 (2026-12-12) will reveal that many legacy systems cannot meet this SLA without shared adapter modules (EUR 240M investment). This expert must architect the integration patterns and SLA monitoring that enables four-corridor go-live by Month 48 (2030-10-12).

**What**: Conduct the technical audit of all 25+ carriers' booking systems by Month 2 (2026-12-12), assessing OSDM API readiness, event-streaming capability, latency profile and availability; tier carriers for conformance (Months 30/36/42 = 2029-04-12, 2029-10-12, 2030-04-12) based on integration effort; design and procure shared adapter modules for mainframe inventory and flat-file settlement patterns by Month 12 (2027-10-12); architect the SLA monitoring proxy and availability cache that degrades gracefully to scheduled-only offers; validate latency and rerouting through pilots at Months 12-18 (2027-10-12 to 2028-04-12).

**Skills**: Legacy system modernisation, API middleware, real-time event streaming (Kafka, RabbitMQ), distributed cache (Redis), latency profiling, synthetic transaction monitoring, system integration testing

**Search**: OSDM rail API integration, legacy mainframe booking system modernisation, real-time inventory event stream, distributed cache architecture, SLA monitoring rail ticketing

## 3.1 Primary Actions

- Commission an independent actuarial study by Month 1 (2026-11-12) using historical clearing data from RSP, Trenitalia–ÖBB and other EU carriers; deliver interim findings by Month 3 (2027-01-12) and final validated caps and co-insurance thresholds by Month 6 (2027-04-12). Obtain written sign-off from at least 8 major carriers and CER by Month 4 (2027-02-12); if sign-off is not secured, escalate to Commission mediation by Month 5 (2027-03-12) and trigger the Month 12 (2027-10-12) readiness-gate deferral.
- Appoint an independent technical audit firm by Month 1 (2026-11-12) and conduct a detailed assessment of all 25+ participating carriers' booking-system readiness, latency, availability and staffing by Month 2 (2026-12-12). Publish tier assignments and tiered API exposure timelines (Tier 1 Month 30 = 2029-04-12, Tier 2 Month 36 = 2029-10-12, Tier 3 Month 42 = 2030-04-12, 2029-10-12, 2030-04-12) by Month 6 (2027-04-12). Tie adapter funding release to verified SLA achievement (p95 latency <2 seconds, 99.5% availability, <1% stale-seat errors); rebudget Tier 3 adapters to EUR 80–100M (estimate) by reducing concession set-up.
- File DG COMP pre-notification by Month 2 (2026-12-12) with a detailed legal memorandum on the federated clearing, shared availability layer and through-fare construction. Engage external competition counsel from Month 1 (2026-11-12) and target DG COMP guidance delivery by Month 9–10 (2027-07-12 to 2027-08-12), adding 2–3 months of contingency before standards lock at Month 18 (2028-04-12). Develop a shadow OSDM specification for fallback pilots and prepare a rework contingency plan (EUR 50–100M, 6–12 months) in case of post-launch challenges.
- Establish the steering group at Month 1 (2026-11-12) with biweekly meetings and 75% supermajority voting rule (≥7 of 9 core members). Publish option papers on the five critical decisions (liability, clearing, public distributor, funding ladder, availability topology) by Month 2 (2026-12-12); conduct written consultation by Month 3 (2027-01-12) and hold binding votes on Decisions 1–5 by Month 6 (2027-04-12). Invoke Commission mediation if any vote falls short of 75% by Month 5 (2027-03-12); mediation must complete by Month 6 (2027-04-12).
- Ring-fence a EUR 150–200M (estimate) force-majeure reserve and establish quarterly budget variance triggers: at EUR 100M variance, defer TEN-T extension; at EUR 200M, cut concession subsidy and extend term; at EUR 300M, restrict to four priority corridors only. Run monthly cash-flow forecasts starting Month 1 (2026-11-12) and escalate cumulative variance >EUR 50M to DG MOVE; resolve open decisions (concession split, validation-hardware financing) by Month 9 (2027-07-12).

## 3.2 Secondary Actions

- Conduct a pre-programme passenger-rights legal review (Month 1 = 2026-11-12 start, final opinion Month 6 = 2027-04-12) against EU Regulation 1371/2007, covering entitlement, compensation, refunds, information and accessibility. Develop a compliance manual by Month 9 (2027-07-12) and obtain EU Agency for Railways approval by Month 9 (2027-07-12); make the manual a binding operational requirement for all carriers, with annual audits starting Month 36 (2029-10-12).
- Procure shared adapter modules for common legacy patterns (mainframe inventory, flat-file settlement, legacy payment integration) by Month 12 (2027-10-12) at estimated EUR 30–50M. Design these modules to serve Tier 2–3 carriers and smaller operators, reducing bespoke integration cost by 30–40% (estimate). Publish module APIs and integration guides by Month 12 (2027-10-12) so Tier 2 carriers can begin integration planning.
- Deploy an SLA monitoring proxy and public availability scorecard by Month 12 (2027-10-12) that continuously probes each carrier's booking engine (synthetic queries every 5 minutes), logs latency percentiles and uptime, and publishes monthly performance results. Attach escalation triggers: if p95 latency exceeds 3 seconds or availability drops below 99% in any month, notify the carrier within 24 hours; if unresolved in 15 business days, trigger an independent technical audit (estimated EUR 200–500K) and present findings to steering group. Persistent failures (3+ months in 12 months) result in exclusion from new corridor rollouts.
- Establish a settlement data-format standard as part of OSDM by Month 6 (2027-04-12), specifying ISO 20022 XML or equivalent journal entries per through-ticket. Deploy a shared reconciliation platform by Month 24 (2028-10-12) that auto-matches transactions (tolerance rules: <0.50% amount variance, <2 business days timing), flags discrepancies and generates daily reports. Target <0.5% reconciliation error rate by Month 30 (2029-04-12); attach automatic penalties (5% tranche loss for carriers, 2% commission reduction for distributors) for carriers or distributors exceeding 1.0% error in any month.
- Launch live pilots on at least two priority corridors (Months 12–18 = 2027-10-12 to 2028-04-12) with 500–1,000 passengers per corridor, testing latency, rerouting, loss rates and passenger acceptance. Use pilot data to validate SLA targets, identify latency hotspots and validate the liability pool assumptions. Publish pilot findings (anonymised) by Month 18 (2028-04-12) to inform binding-standards final text and adjust architecture if needed.
- Conduct impact assessments with national railway regulators in each member state by Month 3 (2027-01-12), covering liability exposure, API obligations, commission band implications and accessibility requirements. Brief regulators quarterly on progress and escalate any blocker (e.g., national passenger-rights rules conflicting with EU standards) to the steering group immediately.
- Develop a capacity-building curriculum for member-state bodies, smaller carriers and disability-rights organisations by Month 6 (2027-04-12). Deliver training workshops in three hubs (Brussels, Valenciennes, Berlin) starting Month 9 (2027-07-12); allocate EUR 30–50M of the EUR 200M capacity-building budget to external training and ensure language coverage for at least five languages (EN, FR, DE, ES, IT).

## 3.3 Follow Up Consultation

At the next consultation (Month 3 or 4 = 2027-01-12 to 2027-02-12), review the actuarial study interim findings, the independent audit's preliminary tier assignments, and DG COMP pre-notification response. Discuss any carrier hold-out positions on liability and address contingency paths if sign-off is delayed. Confirm the steering group composition, voting schedule and option-paper consultation plan. Review the concession business case (due Month 9 = 2027-07-12) and validate that tender timelines align with the Month 12 (2027-10-12) award target. Agree on SLA targets and pilot scope for Months 12–18 (2027-10-12 to 2028-04-12).

## 3.4.A Issue - Liability Model Remains Actuarially Unvalidated and Carrier Refusal Risk Unmitigated

The plan pins carrier participation on a carrier-funded guarantee pool with indicative caps (EUR 500–1,000 per passenger) and co-insurance thresholds (EUR 50M), but no actuarial study has been commissioned and no carrier has signed off on exposure. Without validated loss data and priced caps, 30–40% of carriers (estimate) will refuse inventory exposure, fragmenting corridors and reducing the 40% through-ticket target to 15–25%. The Month 4 (2027-02-12) sign-off deadline is only 6 months away; actuarial cycles typically consume 3–4 months. If sign-off slips past Month 6 (2027-04-12), the binding-standards pathway (Month 18 = 2028-04-12) compresses by 12 months, forcing parallel work-streams and raising rework risk.

### 3.4.B Tags

- unvalidated-liability-model
- carrier-refusal-risk
- actuarial-gap
- schedule-compression
- budget-protection-failure

### 3.4.C Mitigation

Commission an independent actuarial study immediately (Month 1, 2026-11-12) using historical 24-month missed-connection data from existing EU clearing arrangements (e.g., Rail Settlement Plan, Trenitalia-ÖBB bilateral). Publish indicative caps and co-insurance by Month 3 (2027-01-12); present to CER and 10+ carriers by Month 4 (2027-02-12) for binding feedback. Require written sign-off from at least 8 major carriers and CER by Month 4 (2027-02-12), with escalation to Commission mediation by Month 5 (2027-03-12) if holdouts persist. Establish quarterly pool-monitoring (starting Month 6 = 2027-04-12) publishing actual incident rates and contribution adjustments so carriers can model forward exposure and adjust sign-off if data diverges. If sign-off slips past Month 6 (2027-04-12), trigger the readiness-gate deferral to Month 12 (2027-10-12), pushing binding standards to Month 24 (2028-10-12) and creating 6-month contingency.

### 3.4.D Consequence

If carrier sign-off is not obtained by Month 6 (2027-04-12), 30–40% of targeted carriers will refuse exposure, leaving only 15–17 carriers and fragmenting the four priority corridors. This reduces the through-ticket share to 15–25% by Month 60 (2031-10-12), misses the 40% target, and may trigger a formal programme reset or narrowing to only the largest carriers. Reputational damage and legislative scrutiny will follow. Concession volumes will fall below forecast, triggering subsidy review and cost reductions on smaller corridors.

### 3.4.E Root Cause

The plan treats liability caps as indicative placeholders rather than a critical blocking dependency. The Programme Office has not engaged actuaries or carriers in joint workshops; the governance structure lacks a binding mechanism to convert technical findings into carrier commitments. The Month 6 (2027-04-12) gate is a consequence, not a cause; without front-loaded actuarial work and carrier engagement, the gate will fail.

## 3.5.A Issue - Technical Audit and Tiering Decisions Lack Enforcement Mechanism and Adapter Funding Is Undersized

The plan schedules a technical audit by Month 2 (2026-12-12) and tier assignment by Month 6 (2027-04-12), but does not specify who conducts the audit (internal DG MOVE / Agency, or independent third party), what happens to carriers failing early tiers, or how EUR 240M adapter funding is released against measured outcomes. The budget line for adapters (EUR 80M Tier 1 + EUR 80M Tier 2 + EUR 50M Tier 3 = EUR 240M) assumes a uniform split, but legacy mainframe carriers (likely Tier 3) may require EUR 150–200M alone (estimate). Without independent auditing, enforcement of SLA targets tied to funding tranches, and realistic adapter budgets per carrier, 8–15 smaller operators will miss Month 30 (2029-04-12), fragmenting the mandatory API exposure milestone. This threatens full TEN-T rollout and leaves EUR 150–250M of emergency adapter spend unbudgeted.

### 3.5.B Tags

- audit-authority-undefined
- enforcement-gap
- undersized-adapter-budget
- tier-3-cost-overrun-risk
- api-exposure-milestone-at-risk

### 3.5.C Mitigation

Appoint an independent audit firm (DG MOVE or EU Agency to tender by Month 1 = 2026-11-12) to assess all 25+ carriers on OSDM API readiness, event-streaming capability, latency, availability and staffing. Publish audit results and tiered timelines (Tier 1 Month 30 = 2029-04-12, Tier 2 Month 36 = 2029-10-12, Tier 3 Month 42 = 2030-04-12, 2029-10-12, 2030-04-12) by Month 6 (2027-04-12). Release adapter funds only after carriers achieve verified SLAs: p95 latency <2 seconds, 99.5% availability, <1% stale-seat failures on a test endpoint. Procure shared adapter modules for common legacy patterns (mainframe inventory, flat-file settlement) by Month 12 (2027-10-12) at estimated EUR 30–50M, so Tier 2–3 carriers reuse modules rather than build bespoke. Rebudget adapter lines: increase Tier 3 to EUR 80–100M (estimate) by reducing concession set-up envelope from EUR 300M to EUR 280M (platform set-up + lean operations). Establish monthly adapter-spend tracking and escalation triggers; if a carrier's monthly spend exceeds budget by >20%, freeze further releases and conduct a redesign audit within 15 business days.

### 3.5.D Consequence

Without independent audit authority and SLA enforcement, 8–15 smaller carriers will miss Month 30 (2029-04-12), creating fragmented API exposure at 60–70% coverage instead of the 95%+ needed for four-corridor through-ticketing. This delays API-dependent work (clearing reconciliation, rerouting, validation) and pushes four-corridor go-live from Month 48 (2030-10-12) to Month 54–60 (2031-04-12 to 2031-10-12). Emergency adapter spending of EUR 150–250M will exceed the EUR 85M headroom, forcing budget cuts to consumer rollout or TEN-T extension; alternatively, deferring Tier 3 carriers to a Phase 3b creates two-speed corridors that frustrate passengers and carriers.

### 3.5.E Root Cause

The plan assumes adapters are a uniform cost per tier, but mainframe carriers and those with legacy payment systems have combinatorially higher costs. The governance assumes positive incentives (funding release) will drive compliance, but does not specify penalties or enforcement for carriers that miss SLA targets. There is no independent audit authority named, leaving disputes over 'API-ready' to the Programme Office, which is not credible to all carriers.

## 3.6.A Issue - Competition-Law Clearance Timeline Collides with Binding-Standards Deadline and No Fallback Clearance Path Exists

The plan requires DG COMP guidance by Month 12 (2027-10-12) and a clean-team protocol by Month 14 (2027-12-12), but binding standards are due Month 18 (2028-04-12). This leaves only 4 months between guidance receipt and standards lock. DG COMP guidance cycles on novel data-pooling and clearing arrangements typically consume 6–9 months (estimate); if guidance is delayed, the programme has no fallback (e.g., a shadow OSDM for purely domestic or single-distributor use). If a post-launch Article 101 challenge emerges (likelihood ~20% estimate, given the novel clearing mechanism), the programme faces EUR 50–100M rework cost and 6–12 months delay. The federated clearing design reduces risk versus central clearing, but joint data exposure on fares, inventory and settlement still requires legal certainty that the plan has not fully secured.

### 3.6.B Tags

- competition-law-timeline-collision
- no-fallback-clearance-path
- post-launch-challenge-risk
- rework-cost-unbudgeted
- clean-team-protocol-untested

### 3.6.C Mitigation

File DG COMP pre-notification immediately at Month 2 (2026-12-12), not Month 2 (2026-12-12) as planned, with a comprehensive legal memorandum detailing the federated clearing mechanism, shared availability layer, through-fare construction and carrier-funded pool. Engage external competition counsel from Month 1 (2026-11-12) (budget estimate EUR 2–5M over three years) to advise on high-risk design points and draft DG COMP submissions. Request expedited guidance and set a target for guidance receipt by Month 9–10 (2027-07-12 to 2027-08-12), adding 2–3 months of contingency before standards lock. If DG COMP identifies concerns, pivot immediately to a clean-team arrangement: appoint an independent compliance officer with sole access to commercially sensitive data, implement firewalls between the clearing function and carrier strategy teams, and publish the protocol by Month 14 (2027-12-12). Develop a shadow OSDM specification for domestic or limited-distributor pilots (Months 12–18 = 2027-10-12 to 2028-04-12) that can proceed if DG COMP signals extended review. Retain contingency counsel to monitor for post-launch challenges and prepare a 6–12 month rework option costing EUR 50–100M; brief the steering group quarterly on legal risk.

### 3.6.D Consequence

If DG COMP guidance does not arrive by Month 12 (2027-10-12), binding standards will slip 3–6 months past Month 18 (2028-04-12), cascading to Month 21–24 (2028-07-12 to 2028-10-12) and compressing the Phase 2 API exposure timeline (currently Month 30 = 2029-04-12). If a post-launch Article 101 challenge succeeds (low probability, but high impact), the entire clearing and data-sharing layer must be redesigned, consuming EUR 50–100M and 6–12 months. Affected carriers will demand indemnification or rollback, and the public budget will lack reserves to cover rework. The four-corridor go-live will slip to Month 54–60 (2031-04-12 to 2031-10-12), squeezing the full-network TEN-T wave into a final 12 months.

### 3.6.E Root Cause

The plan underestimates DG COMP cycle time and does not reserve schedule contingency for competition-law feedback. It also assumes a single-pass clearance path; there is no fallback for extended review or for a design revision that requires re-submission. The clean-team protocol is mentioned as a contingency but not resourced or scheduled in advance, so it will be reactive rather than proactive.

---

# 4 Expert: Federated Clearing and Settlement Finance Operations Lead

**Knowledge**: Inter-bank clearing and settlement, netting engines, reconciliation platforms, fund flow controls, settlement cycle design, fraud detection and dispute resolution

**Why**: Decision 2 (Inter-Carrier Clearing and Single-Payment Settlement) requires a federated netting and dispute layer (EUR 220M investment) that can settle EUR 300M+ annual through-ticket revenue across 25+ carriers and independent distributors within a 5-business-day cycle at <0.5% reconciliation error by Month 30 (2029-04-12). This design locks together revenue apportionment (Decision 8), commission band enforcement (Decision 12), and pool contribution netting (Decision 1). Reconciliation errors lengthen settlement cycles and deter distributors, directly threatening the 40% through-ticket target.

**What**: Define the settlement data format and ISO 20022 reconciliation standard as part of OSDM by Month 6 (2027-04-12); fund and deploy a shared reconciliation platform by Month 24 (2028-10-12) that matches transactions within tolerance, flags discrepancies and publishes daily netting results; establish the 5-business-day settlement cycle and automated penalty regime (5% tranche loss for carriers, 2% commission reduction for distributors exceeding 1% monthly error rate); publish monthly error rates and penalty scorecards by Month 30 (2029-04-12); validate settlement cycles through four-corridor pilots and resolve edge cases (delayed refunds, carrier bankruptcy, payment processor failures) before binding standards (Month 18 = 2028-04-12).

**Skills**: Settlement engineering, ISO 20022 messaging, reconciliation algorithms, multilateral netting, dispute adjudication, fund-flow controls, payment-processor integration, operational risk management

**Search**: federated clearing settlement rail, multilateral netting ISO 20022, reconciliation platform error detection, payment settlement cycle design, transport sector clearing

## 4.1 Primary Actions

- Commission an independent actuarial study with interim results by Month 2 (2026-12-12) and final pricing by Month 3 (2027-01-12) that models missed-connection rates, rerouting costs and incident clustering per carrier; derive the per-incident cap and co-insurance threshold from historical data (or proxy RSC data), not indicative thresholds. Require carriers to sign off on the liability model by Month 4 (2027-02-12), with written commitment from at least 8 major carriers and CER to expose inventory under the priced terms, or escalate to Commission mediation by Month 5 (2027-03-12).
- Establish a dedicated Clearing Design Workstream by Month 1 (2026-11-12) reporting to the steering group, with a mandate to publish a binding 'Federated Clearing Rulebook' by Month 6 (2027-04-12) specifying netting model (bilateral/multilateral/hybrid), settlement cycle (5-business-day with daily netting), journal entry standard (ISO 20022 mapping), reconciliation tolerance bands (amount variance <0.50%, timing variance <2 business days), dispute escalation procedure, and payout schedule. Provide worked examples for three-leg through-tickets (Paris-Amsterdam-Berlin, Wien-München-Zürich, Madrid-Barcelona-Lyon) showing journal entries, netting and payout per distributor and carrier.
- Revise the reconciliation error target to a phased approach: Month 30 (2029-04-12) Tier 1 tolerates 2.0% error in the first month, stepping to 1.0% by Month 32 (2029-06-12) and 0.5% by Month 36 (2029-10-12). Replace tranche penalties with remediation requirements: carriers exceeding 1.0% error for two consecutive months must submit a corrective-action plan within 10 business days or face suspension from new corridor enrollments. Publish a detailed settlement data-submission SLA by Month 12 (2027-10-12) specifying submission times (17:00 UTC daily), reconciliation windows (20:00 UTC same-day), and three-tier escalation protocol (variance <0.20% no action; 0.20%-0.50% manual review; >0.50% arbitration by end of T+5).
- Accelerate the DG COMP competition-law pre-notification to Month 2 (2026-12-12)—do not defer to Month 2 (2026-12-12) as currently planned. Submit a comprehensive legal memorandum describing the federated clearing mechanism, data flows, netting rules, the shared availability layer, fare-composition doctrine and commission band; request explicit Article 101 TFEU comfort or formal guidance on required clean-team protocols. If DG COMP raises concerns, establish a clean-team arrangement with an independent compliance officer by Month 6 (2027-04-12), not Month 14 (2027-12-12), to avoid late-stage rework. Have external competition counsel embedded in the Programme Office from Month 6 (2027-04-12) onwards, not as ad-hoc advisory.
- Conduct the pre-programme technical audit of all 25+ carriers and publish tiered conformance timelines by Month 6 (2027-04-12), as planned, but link adapter funding release strictly to verified performance: require each carrier to demonstrate API availability (99.5% uptime, p95 latency <2 seconds) and booking-error rates (<1% stale-seat failures) on a live test environment before funds are disbursed. Create a public SLA scoreboard by Month 12 (2027-10-12) showing each carrier's latency, availability and error rates, updated monthly, to create transparency and market pressure. Suspend funding tranches (not yet disbursed) for carriers missing SLA targets for three consecutive months.

## 4.2 Secondary Actions

- Establish a reinsurance engagement by Month 6 (2027-04-12) with a tier-one carrier (Munich Re, Swiss Re, AXA) to quote pool coverage above the co-insurance threshold (expected cap: EUR 100-200M annual); evaluate whether reinsurance cost (estimated 2-5% of limit) fits in the EUR 150M reserve or requires adjustment to the EUR 220M clearing budget. Document reinsurance as a secondary layer in the liability model to give carriers confidence that tail exposure is hedged.
- Publish option papers for each of the five critical strategic decisions (liability, clearing, public distributor, funding ladder, availability topology) by Month 2 (2026-12-12), laying out trade-offs in plain language (speed vs. coverage, control vs. complexity, budget risk vs. carrier autonomy). Circulate for written comment by Month 3 (2027-01-12) and hold binding steering votes by Month 6 (2027-04-12) with a 75% supermajority rule (≥7 of 9 core members). Document the voting outcomes and any dissenting positions; for dissenting parties, establish fallback interfaces (e.g., bilateral clearing option for carriers refusing pooled liability, sandbox-only sandbox role for distributors refusing mandatory API exposure) to maintain network participation.
- Procure and deploy shared adapter modules for common legacy patterns (mainframe inventory systems, flat-file settlement feeds) by Month 12 (2027-10-12), estimated EUR 30-50M. Conduct a survey of the 8-15 smaller carriers at risk of missing Month 30 (2029-04-12) to identify their specific technology stacks; develop adapters for the top 2-3 patterns and make them open-source or low-cost to reuse across carriers in Tiers 2-3. Publish a 'Carrier Integration Toolkit' by Month 12 (2027-10-12) including test data, API stubs, reconciliation scripts and troubleshooting guides.
- Define formal settlement data formats and reconciliation standards as part of the OSDM specification by Month 6 (2027-04-12), specifying journal entry structure (ISO 20022 XML), settlement currency (EUR), timestamp precision (UTC, millisecond), and required fields (through-ticket ID, booking reference, payment method, failure codes). Require all carriers to submit test data in this format by Month 12 (2027-10-12); audit test submissions for completeness and consistency by Month 15 (2028-01-12). Publish a 'Settlement Data Quality Report' by Month 18 (2028-04-12) identifying data gaps and requiring carriers to remediate by Month 24 (2028-10-12).
- Ring-fence the EUR 150M force-majeure reserve and establish formal governance: the reserve may be drawn only for single-day corridor-wide disruptions affecting >5,000 passengers, with 48-hour incident notification and 5-business-day Commission approval required. Require quarterly budget re-baselining starting Month 6 (2027-04-12); if cumulative project costs exceed EUR 1,415M by EUR 50M or more, escalate to Commission DG MOVE. Implement automatic variance triggers: EUR 100M variance triggers TEN-T extension deferral; EUR 200M variance reduces concession subsidy by 20% and extends term from 5 to 7 years; EUR 300M variance restricts the program to the four priority corridors only.
- Resolve three open decisions by Month 9 (2027-07-12): (1) the split of the EUR 300M concession envelope between platform set-up (estimated 20%, EUR 60M) and operating subsidy (estimated 80%, EUR 240M cap at EUR 60M); (2) who finances ticket-validation hardware retrofits on corridor rolling stock (options: public EUR 50-100M (estimate), carrier self-fund, or mixed); (3) formal approval of the Month 72 (2032-10-12) TEN-T fallback beyond the five-year horizon. Present option papers to the steering group by Month 6 (2027-04-12) and hold binding votes by Month 9 (2027-07-12).
- Establish quarterly pool-monitoring reports starting Month 6 (2027-04-12), published within 15 business days of quarter-end, showing actual missed-connection incident rates, contribution adjustments, reserve drawdown and cash flows per contributing carrier. Make this data available to all carriers in real time so they can model forward exposure and adjust their underwriting. If actual incident rates diverge >20% from the actuarial model within the first 12 months (Month 30-42 = 2029-04-12 to 2030-04-12), trigger an actuarial revalidation and adjust contributions accordingly by Month 45 (2030-07-12).
- Commission independent passenger-rights legal review by Month 1 (2026-11-12) of the Through-Ticket Liability and Rights Backstop design against EU Regulation 1371/2007, in parallel with the actuarial study. Publish the legal opinion and any required design adjustments by Month 6 (2027-04-12). If gaps are identified (e.g., through-ticket compensation is less generous than single-carrier compensation), revise the liability model and present revised terms to DG MOVE and the EU Agency for Railways for sign-off by Month 9 (2027-07-12). Develop a passenger-rights compliance manual by Month 9 (2027-07-12) and submit to the Agency for approval by Month 9 (2027-07-12); once approved, make it a binding operational requirement for all carriers and the clearing entity, with annual audits starting Month 36 (2029-10-12).

## 4.3 Follow Up Consultation

"At the next consultation, we need to review: (1) interim actuarial results and carrier sign-off targets—confirm at least 8 major carriers and CER are willing to participate under the proposed liability caps; (2) clearing workstream progress—the Federated Clearing Rulebook must be publication-ready by Month 6 (2027-04-12), with three worked examples and ISO 20022 mapping signed off by the Agency; (3) reconciliation tolerance and SLA strategy—confirm whether the phased error target (2.0% Month 30 = 2029-04-12 → 0.5% Month 36 = 2029-10-12) and remediation-based penalties (suspension from new corridors vs. tranche loss) align with carrier operational realism; (4) DG COMP pre-notification timing and scope—confirm the memorandum is submitted by Month 2 (2026-12-12) and identify any early signals on Article 101 TFEU exposure; (5) reinsurance and reserve adequacy—confirm whether external pool coverage is feasible within EUR 15M (estimate) and whether the EUR 150M reserve is sufficient if the first-year incident rate exceeds forecast by 50%; (6) open decisions—present option papers and straw-man recommendations for concession structure, validation-hardware financing and Month 72 (2032-10-12) fallback approval. Finally, confirm the steering-group voting schedule and dispute-escalation protocol are documented and accepted by all core members."

## 4.4.A Issue - Federated settlement architecture lacks concrete netting and dispute-resolution rulebook; clearing mechanism design is deferred.

The plan commits to 'federate settlement through a shared netting and dispute-resolution layer' but provides no detail on settlement currency, journal entry format, matching tolerance, dispute adjudication rules, or payout schedule. The canonical decision confirms a reconciliation platform at EUR 20-40M but omits the operational mechanics: which entity receives and nets positions, how bilateral versus multilateral netting is handled, how disputes over carrier shares are escalated, and whether settlement is gross or net per leg per day. Without this specification by Month 6 (2027-04-12), carriers cannot price their exposure, model their cash flow, or commit IT resource to integration. The OSDM specification work and ISO 20022 mapping are mentioned as Month 6 (2027-04-12) deliverables, but no dedicated clearing design workstream exists.

### 4.4.B Tags

- clearing-design-gap
- netting-rulebook-missing
- settlement-mechanics-undefined
- cash-flow-visibility

### 4.4.C Mitigation

Establish a dedicated Clearing Design Workstream by Month 1 (2026-11-12) reporting to the steering group, with a mandate to publish a 'Federated Clearing Rulebook' by Month 6 (2027-04-12) specifying: (1) netting model (bilateral, multilateral, or hybrid per corridor); (2) settlement cycle (5 business days, daily netting per pair/per distributor); (3) journal entry standard (ISO 20022 XML mapping, including reversal codes); (4) dispute thresholds (tolerance band e.g. amount variance <0.50%, timing variance <2 business days); (5) escalation procedure (carrier-to-carrier, with clearing entity as tie-breaker); (6) payout schedule (next-day clearing fund availability). Recruit clearing specialists from existing PSA (Payment Settlement Authority) and RSC (Rail Settlement Centre) precedents. Publish a worked example of a three-leg through-ticket (Paris-Amsterdam-Berlin) showing journal entries, netting and payout per distributor and carrier.

### 4.4.D Consequence

If the clearing rulebook is not published by Month 6 (2027-04-12), three cascading risks emerge: (1) carriers model incompatible netting in their own systems, blocking interoperability post-Month 18 (2028-04-12); (2) distributors cannot price commission accurately without knowing net settlement timing; (3) disputes over carrier share allocation accumulate in Month 30-36 (2029-04-12 to 2029-10-12) and trigger rework of the reconciliation platform. Estimated delay: 3-6 months. Estimated cost: EUR 50-75M (rework scope TBD).

### 4.4.E Root Cause

The plan treats clearing as a technical layer to be built post-standards, rather than a core decision that must inform standards design. Federated clearing is harder to standardize than a central entity; without an explicit netting engine design (bilateral versus multilateral, gross versus net, daily cycle), carriers face undefined operational and credit risk. The EUR 220M line for 'federated netting and dispute layer' may underestimate the complexity if bilateral interfaces proliferate.

## 4.5.A Issue - Carrier-funded guarantee pool lacks actuarial pricing and is untested at scale; public budget exposure remains undefined.

The plan proposes a 'carrier-funded mutual guarantee pool' with 'per-incident caps (EUR 500-1,000 per stranded passenger) and co-insurance above EUR 50M annual pool draw' marked as 'indicative'. No actuarial study is commissioned until Month 1 (2026-11-12), and the final model is not due until Month 6 (2027-04-12)—six months into execution. The plan states 'no public pay-first fund' and 'no pool draw-downs after Month 36 (2029-10-12)', but the force-majeure reserve (EUR 150M escrowed) is never defined as a backstop. Carriers have no way to price their contribution or reserve adequacy. The co-insurance threshold at EUR 50M is untested: if actual missed-connection incidents cluster (e.g., winter disruption, industrial action), the pool could face EUR 100-200M (estimate) draw in a single quarter, leaving no clarity on whether the EUR 150M reserve is sufficient or if it becomes a de facto public bailout.

### 4.5.B Tags

- pool-pricing-unknown
- reserve-adequacy-untested
- actuarial-gap
- contingent-public-liability

### 4.5.C Mitigation

Accelerate the actuarial study to deliver interim results by Month 2 (2026-12-12), not Month 1 (2026-11-12). Commission three parallel actuarial engagements (one for each region—Western EU, Central EU, Scandinavia) to model missed-connection incidence, rerouting cost, and severity clustering by carrier, using RSC (Rail Settlement Centre) historical data as proxy. By Month 3 (2027-01-12), publish a preliminary model with three scenarios (conservative, base, aggressive) showing per-carrier contribution under each. Require carriers to submit to the Month 4 (2027-02-12) sign-off forum with the question: 'At which cap level and co-insurance threshold would you commit inventory?' Revise the co-insurance trigger to a data-backed threshold (e.g., 'two consecutive months exceeding 80th percentile of historical incident costs' rather than EUR 50M). If actuarial consensus is not reached by Month 5 (2027-03-12), invoke a reinsurer (e.g., Munich Re, Swiss Re) to provide a binding quote for pool coverage above the co-insurance threshold, shifting tail risk to the market. Document the reinsurance cost as a line item in the EUR 220M clearing budget or the EUR 150M reserve.

### 4.5.D Consequence

Without actuarial pricing by Month 3 (2027-01-12), at least 2-3 major carriers (DB, SNCF, or RZD equivalent) will refuse sign-off at Month 4 (2027-02-12), triggering Commission mediation and delaying the binding vote to Month 9 (2027-07-12) or deferral to Month 12 (2027-10-12). If 30-40% (estimate) of carriers refuse participation due to undefined exposure, mandatory API exposure at Month 30 (2029-04-12) becomes unenforceable, fragmenting the network and cutting the 40% through-ticket target to 15-25% (estimate). If the pool draws exceed EUR 50M/quarter and no public backstop is invoked, smaller contributors may demand rapid wind-down, further destabilizing the market.

### 4.5.E Root Cause

The guarantee-pool design was chosen to protect the EUR 1,500M cap, but the actuarial foundation was deferred to allow fast governance decisions. This creates a credibility gap: carriers cannot sign the Month 4 (2027-02-12) liability model without knowing their exposure, and the steering vote at Month 6 (2027-04-12) cannot endorse a pool without loss-data validation. The EUR 50M co-insurance threshold appears arbitrary; it was not derived from historical through-ticket incident rates, which do not yet exist for this program.

## 4.6.A Issue - Reconciliation error tolerance of 0.5% by Month 30 (2029-04-12) is ambitious for federated multi-carrier settlement; failure modes and escalation protocol are not defined.

The canonical plan sets a reconciliation target of 'error below 0.5% by Month 30 (2029-04-12)' and proposes a penalty (5% tranche loss) for carriers exceeding 1.0% in a month. For a federated clearing model with each carrier maintaining its own booking system and feeding settlement data asynchronously, a 0.5% error rate is extremely aggressive. Typical multi-party clearing settlements (equities, FX) tolerate 2-5% daily reconciliation variance, resolved within 5 business days. The plan specifies a '5-business-day settlement cycle' but does not define: (1) when each party (carrier, distributor, clearing platform) submits settlement data; (2) which discrepancies block payout versus which are tolerated and reserved; (3) how stale-seat booking failures, refund reversals and commission adjustments are handled in reconciliation; (4) who adjudicates disputes when two carriers report conflicting transaction counts. The EUR 20-40M reconciliation platform budget may be insufficient if it must support real-time matching rather than post-event reconciliation.

### 4.6.B Tags

- reconciliation-tolerance-aggressive
- settlement-data-flow-undefined
- escalation-protocol-missing
- platform-scope-ambiguous

### 4.6.C Mitigation

Revise the reconciliation target to be phased: (1) Month 30 (2029-04-12) Tier 1: tolerate 2.0% error rate in first month, stepping down to 1.0% by Month 32 (2029-06-12) and 0.5% by Month 36 (2029-10-12); (2) publish a detailed settlement data-submission SLA by Month 12 (2027-10-12) specifying: each carrier submits ISO 20022 journal by 17:00 UTC each business day (T+0), clearing platform reconciles by 20:00 UTC and flags discrepancies by 21:00 UTC (T+0), carriers respond to discrepancy notices by 09:00 UTC next day (T+1). (3) Establish a three-tier escalation: (a) variance <0.20%, no action; (b) 0.20%-0.50%, manual review, resolved by end of T+2; (c) >0.50%, disputed transaction held in escrow, carrier and clearing entity have until end of T+5 to agree, then independent arbitrator decides. (4) Exempt refund reversals and stale-seat adjustments from the reconciliation tolerance for the first 6 months (until Month 36 = 2029-10-12), since these are novel transaction types that will require learning. (5) Replace the tranche-penalty with a remediation requirement: if a carrier exceeds 1.0% error for two consecutive months, trigger a technical audit (funded from contingency) and require corrective-action plan submission within 10 business days; suspend that carrier from new corridor enrollments (not funding tranches) until audit is cleared.

### 4.6.D Consequence

If reconciliation errors exceed 0.5% in the first 3-6 months post-go-live (Month 30-36 = 2029-04-12 to 2029-10-12), widespread tranche penalties will be triggered, halting funding to multiple carriers mid-integration. This cascades: (1) Tier 2 carriers (Month 36 = 2029-10-12 deadline) see Tier 1 carriers penalised, lose confidence in the scheme and delay their own implementation; (2) disputed transactions accumulate in escrow, blocking distributor payouts and triggering distributor exit; (3) the clearing platform's backlog grows, pushing resolution from 5 business days to 15-30 days, freezing working capital across the network. Estimated impact: 4-8 week operational disruption, EUR 20-30M (estimate) distributor receivables stranded, and 2-3 month delay to Tier 2 launch.

### 4.6.E Root Cause

The 0.5% target was set as a success metric without analysis of the underlying data quality and operational maturity. Federated clearing requires carriers to submit journal entries in a standard format, but carriers' back-office systems vary widely in version, API completeness and data integrity. The plan does not account for the learning curve: in Month 30 (2029-04-12), the system will have been live for only 6 months (Tier 1 go-live at Month 30 = 2029-04-12), so error rates will be elevated until carriers and the platform learn each other's patterns. The penalty structure (5% tranche loss) is punitive without a clear path to remediation.

---

# 5 Expert: Regulatory Affairs and Stakeholder Alignment Director

**Knowledge**: EU regulatory adoption timelines, transport legislative procedures, member-state stakeholder coordination, institutional change management, regulatory impact assessments

**Why**: The programme's success depends entirely on the Regulation's adoption by Month 18 (2028-04-12), yet the canonical facts confirm this is not verified and a 6-12 month slip is plausible. The go-no-go assessment identifies that if prerequisites are unresolved by Month 9 (2027-07-12), the programme must defer to Month 12 (2027-10-12). This expert must track the Regulation's adoption pathway, orchestrate the steering group's 75% supermajority votes on Decisions 1-5 by Month 6 (2027-04-12), and broker consensus among 25+ national carriers and 9 core steering members when competition law and commercial interests collide.

**What**: Map the Regulation adoption workflow from Commission proposal (May 2026, status not verified) through Parliamentary and Council procedure, identifying the critical path and milestones that unlock binding standards (Month 18 = 2028-04-12); initiate bilateral impact assessments with all 27 member states by Month 3 (2027-01-12) to surface early objections; chair steering group meetings, enforce the 75% supermajority voting rule for Decisions 1-5 by Month 6 (2027-04-12), and escalate any deadlocked decision to Commission mediation by Month 5 (2027-03-12); maintain a stakeholder register tracking carrier, distributor and regulator positions on liability, clearing and commission band, updated monthly starting Month 1 (2026-11-12); brief the Commissioner on adoption risk and fallback scenarios (voluntary phasing, Month 12 = 2027-10-12 deferral) by Month 3 (2027-01-12).

**Skills**: EU legislative procedure, transport policy stakeholder engagement, consensus-building with competing interests, regulatory timeline forecasting, member-state diplomacy, change management and escalation protocols

**Search**: EU rail regulation adoption timeline, transport legislative procedure, stakeholder impact assessment transport, member-state railway coordination, regulatory consensus-building EU

## 5.1 Primary Actions

- Commission independent actuarial study by Month 2 (2026-12-12) modelling 24-month carrier missed-connection rates, rerouting costs and incident clustering. Deliver interim findings Month 3 (2027-01-12), final recommendations (caps, co-insurance, contribution formula) and three carrier-profile worked examples by Month 6 (2027-04-12). Obtain written sign-off from at least 8 major carriers and CER by Month 4 (2027-02-12) confirming they will expose inventory at proposed liability terms, or escalate to Commission mediation by Month 5 (2027-03-12).
- Execute detailed technical audit of all 25+ carriers by Month 2 (2026-12-12) assessing API readiness, event-streaming capability, latency, 12-month availability and available staff FTE. Publish tier assignment (Tier 1/2/3 timelines: Months 30/36/42 = 2029-04-12, 2029-10-12, 2030-04-12) with per-carrier roadmaps by Month 6 (2027-04-12). Procure shared adapter modules for mainframe, flat-file and legacy patterns (EUR 30M) by Month 12 (2027-10-12). Tie every EUR 240M adapter fund release to independent verification of live API performance (99.5% uptime, p95 latency <2 sec, <1% stale-seat failure), not intention.
- Establish formal steering group by Month 1 (2026-11-12) with biweekly meetings (Mondays, 09:00 Brussels time) comprising DG MOVE, EU Agency for Railways, CER, four major carriers, Trainline, Omio, BEUC and disability-rights body. Publish option papers for Decisions 1–5 (liability, clearing, public distributor, funding ladder, availability topology) by Month 2 (2026-12-12) with explicit trade-offs. Hold binding votes (75% supermajority, ≥6 of 9 core members) on all five decisions by Month 6 (2027-04-12); invoke Commission mediation if votes do not reach 75% by Month 5 (2027-03-12).
- Initiate formal pre-notification with DG COMP by Month 2 (2026-12-12) describing inter-carrier clearing (data flows, netting, settlement timing), shared availability layer, through-fare construction, distribution remuneration band and carrier-funded guarantee pool. Obtain written guidance letter from DG COMP by Month 12 (2027-10-12) confirming compatibility with Article 101 TFEU or identifying concerns. If concerns are raised, establish clean-team protocol (independent compliance officer, IT firewalls, data-handling rules) and obtain DG COMP approval by Month 14 (2027-12-12), no later than Month 18 (2028-04-12).
- Rebase the EUR 1,500M budget plan (user constraint) immediately with three sensitivity scenarios (Base, Adapter Slip +EUR 150M, Concession Overrun +EUR 75M). Establish quarterly re-baselining from Month 6 (2027-04-12) with variance triggers at EUR 50M (notify DG MOVE), EUR 100M (defer Phase 3), EUR 200M (cut concession 20%, extend term), EUR 300M (restrict TEN-T to four corridors). Publish monthly cash-flow forecast by 10th of each month (starting Month 1 = 2026-11-12) and present variance to Steering Finance Committee bi-weekly. Resolve open decisions on concession envelope split and ticket-validation retrofit financing by Month 9 (2027-07-12).

## 5.2 Secondary Actions

- Commission independent legal review by Month 1 (2026-11-12) of the Through-Ticket Liability and Rights Backstop design against EU Regulation 1371/2007 (railway passengers' rights) covering entitlement, compensation, refunds, information, complaints and accessibility. Publish opinion and required adjustments by Month 6 (2027-04-12). Develop passenger-rights compliance manual by Month 9 (2027-07-12) specifying procedures per carrier, clearing entity and public distributor. Submit to EU Agency for Railways for approval by Month 9 (2027-07-12); once approved, require all carriers to certify staff training as a conformance condition by Month 30 (2029-04-12).
- Define binding carrier booking-engine SLA targets by Month 3 (2027-01-12): latency p95 <2 seconds, availability ≥99.5% monthly uptime, stale-seat error rate <1%. Publish as binding conformance requirements and attach to Milestone-Conditioned Funding Release Ladder (two consecutive months missed = 5% next tranche loss). Deploy monitored availability proxy by Month 12 (2027-10-12) that probes each carrier every 5 minutes, logs p50/p95/p99 latency and uptime, and publishes monthly public scoreboard visible to distributors, regulators and passengers. Establish escalation: if p95 latency >3 seconds or availability <99%, notify carrier CIO within 24 hours; if not remediated within 15 business days, trigger technical audit and present findings to Steering Group.
- Establish settlement data format standard (ISO 20022 XML or equivalent) as part of OSDM specification by Month 6 (2027-04-12) specifying journal entries per through-ticket, settlement currency (EUR), timestamp precision (UTC milliseconds) and required fields. Require all carriers to submit test data in this format by Month 12 (2027-10-12). Fund and deploy shared reconciliation platform (EUR 20–40M) by Month 24 (2028-10-12) accepting feeds from carriers and distributors, auto-matching transactions (variance tolerance: amount <0.50%, timing <2 business days), and generating daily reconciliation report for all parties. Establish 5-business-day settlement cycle with daily netting from Month 30 (2029-04-12) onwards. Attach automatic penalties to carriers and distributors exceeding 1.0% monthly reconciliation error rate: loss of 5% next funding tranche (carriers) or 2% commission reduction (distributors) for following month.
- Build lightweight distributed caching layer (EUR 15–25M) by Month 18 (2028-04-12) that holds recent search results and itinerary snapshots from each carrier, enabling graceful degradation to cached results if carrier endpoint is unavailable >30 seconds. Degrade search to scheduled-only (no real-time seats, no prices) when caching invoked so passengers understand fallback. Develop fallback technical interfaces (bilateral clearing for dissenting distributors, third-party settlement option for refusing carriers) by Month 6 (2027-04-12) so programme can proceed without universal consensus on all decisions.
- Retain external competition-law counsel from Month 6 (2027-04-12) onwards (budget EUR 2–5M over three years) to monitor for Article 101 legal challenges post-launch and prepare contingency redesign (estimated 6–12 months, EUR 50–100M rework cost if needed). Brief Steering Group quarterly on legal risk exposure starting Month 9 (2027-07-12). Run 2,000–4,000 passenger live pilots at Months 12–18 (2027-10-12 to 2028-04-12) (500–1,000 per corridor) to validate latency, reroute success, loss rates and passenger choice versus stitched itineraries or flights before binding-standards deadline (Month 18 = 2028-04-12). Deploy ticket validation to corridor rolling stock and key stations by Month 40 (2030-02-12); conduct audits at Months 30 and 35 (2029-04-12, 2029-09-12).

## 5.3 Follow Up Consultation

Next review (Month 3 = 2027-01-12): interim actuarial findings, technical audit completion status, Steering Group voting readiness and DG COMP pre-notification acknowledgment. Month 6 (2027-04-12) readiness gate: final actuarial sign-off from 8+ carriers, tier assignment, first variance re-baseline, competition-law guidance status and fallback decision-making authority. Escalation protocol: if actuarial or audit work slips beyond Month 6 (2027-04-12), defer Phase 1 completion to Month 12 (2027-10-12), compressing the Month 18 (2028-04-12) binding-standards milestone. If DG COMP guidance is not received by Month 12 (2027-10-12), initiate contingency standards workstream using clean-team protocols immediately, risking 2–4 month binding-standards slip. Budget variance >EUR 50M requires written variance recovery plan within 10 business days.

## 5.4.A Issue - Liability Model Remains Unpriceable; Carrier Refusal Risk Unmitigated at Project Start

The plan proposes a carrier-funded mutual guarantee pool with indicative caps (EUR 500–1,000 per stranded passenger) and co-insurance above EUR 50M, but no actuarial study has been commissioned to validate whether these caps are economically viable or what actual incident rates and clustering patterns will be. Carriers cannot price unpriceable exposure. Without validated caps, contribution weights and reserve adequacy by Month 4 (2027-02-12), the probability of 30–40% carrier refusal (estimated) rises sharply, fragmenting corridors and collapsing the 40% through-ticket target to 15–25%. The Month 6 (2027-04-12) readiness gate depends on carrier sign-off that cannot yet be obtained.

### 5.4.B Tags

- unpriceable_liability
- carrier_participation_risk
- actuarial_gap
- month_6_gate_jeopardy

### 5.4.C Mitigation

Commission independent actuarial study by Month 2 (2026-12-12) modelling 24-month rolling missed-connection rates, rerouting costs and incident clustering per carrier using existing CER and operator data. Deliver interim findings by Month 3 (2027-01-12) and final recommendations (caps, co-insurance, contribution formula) by Month 6 (2027-04-12). Publish worked examples for three carrier profiles (large, regional, small) and present to CER and 10+ major carriers for binding commercial sign-off by Month 4 (2027-02-12). Escalate design issues to Commission mediation by Month 5 (2027-03-12) if sign-off stalls. Establish quarterly monitoring (starting Month 6 = 2027-04-12) publishing actual incident rates, drawdowns and contributor cash flows within 15 business days of quarter-end so carriers can model forward exposure.

### 5.4.D Consequence

Without validated actuarial model, carriers face unquantified liability exposure and will refuse to expose connections at binding-standards deadline (Month 18 = 2028-04-12). The mandatory API exposure milestone (Month 30 = 2029-04-12) then becomes unachievable for most of the corridor network. Budget allocated to adapters (EUR 240M) and clearing (EUR 220M) are spent on a system no carriers use. Through-ticket share collapses from 40% target to 15–25% (estimate). The entire programme timeline slips 12–24 months or is abandoned.

### 5.4.E Root Cause

Plan assumes carrier participation is guaranteed once standards are published, but connection liability is the pricing blockade. Carriers will not expose multi-leg inventories if they cannot calculate the financial exposure. Actuarial work was deferred post-Month 0 (2026-10-12) (project start) rather than pre-project, leaving a critical dependency unresolved. The Month 6 (2027-04-12) readiness gate cannot proceed without this baseline.

## 5.5.A Issue - Technical Audit Deferred; 8–15 Smaller Carriers at Risk of Missing Month 30 (2029-04-12) Mandatory API Exposure Milestone

The plan targets 25 carriers and expects 15–20 to participate, but 8–15 smaller operators (estimated) are at high risk of missing the Month 30 (2029-04-12) mandatory API exposure deadline. No pre-project technical audit has identified which carriers need adapters, how much integration time they require, or what shared modules could reduce costs. Without this baseline, the EUR 240M adapter budget is allocated without evidence that it reaches the right carriers or solves the bottlenecks. Legacy booking systems on flat-file settlement feeds or mainframe inventory will take 18–24 months to retrofit (estimated); smaller carriers with limited IT staff will struggle to staff integration. Tiering by capability maturity was not done at Month 0 (2026-10-12).

### 5.5.B Tags

- technical_audit_missing
- legacy_system_latency
- smaller_carrier_at_risk
- month_30_milestone_jeopardy
- adapter_budget_misaligned

### 5.5.C Mitigation

Execute detailed technical audit of all 25+ carriers by Month 2 (2026-12-12) assessing: OSDM API readiness (existing or new build), event-streaming capability, transaction consistency across legs, latency (p95 seconds), 12-month availability (%), and staff FTE available. Publish tier assignment (Tier 1: Month 30 = 2029-04-12; Tier 2: Month 36 = 2029-10-12; Tier 3: Month 42 = 2030-04-12) with per-carrier integration roadmaps by Month 6 (2027-04-12). Allocate EUR 240M in verified tranches: Tier 1 EUR 80M (released only after API live at 99.5% uptime, p95 latency <2 sec), Tier 2 EUR 80M (verified Month 9 = 2027-07-12), Tier 3 EUR 50M (verified Month 15 = 2028-01-12). Procure shared adapter modules (EUR 30M) for mainframe, flat-file and legacy patterns by Month 12 (2027-10-12). Tie every fund release to independent audit of live API performance, not intention.

### 5.5.D Consequence

Without baseline audit and tiering, adapters are funded without accountability for delivery. Month 30 (2029-04-12) mandatory exposure milestone becomes unachievable for Tier 2 and Tier 3 carriers (estimated 8–15 operators, ~35–40% of network (estimate)). Corridors fragment: Paris–Brussels–Amsterdam–Köln can go live with Tier 1 carriers, but Wien–München–Zürich cannot without Austrian operators or Trenitalia; Madrid–Barcelona–Lyon cannot without Renfe. Network effect fails; through-ticket share stalls at 20–25% instead of 40% target (estimate). Budget reallocation to emergency adapters (EUR 150–250M (estimate)) exhausts the EUR 85M headroom and forces Phase 3 (TEN-T extension) deferral by 12 months or reduction to four corridors only.

### 5.5.E Root Cause

Plan lacked pre-project technical due diligence. Smaller carriers' legacy systems and staffing constraints were acknowledged in the SWOT analysis but not measured or addressed in the budget plan. Tiering by capability was a secondary decision (Decision 6) rather than a blocking gate. The assumption that EUR 240M allocated evenly across tiers will achieve Month 30 (2029-04-12) conformance is not evidence-backed.

## 5.6.A Issue - EUR 85M Headroom Insufficient Against Fallback Exposures; Budget Sequencing Creates Month 9 (2027-07-12) Cliff

Plan commits EUR 1,415M of the EUR 1,500M cap (user constraint) across standards (EUR 80M), clearing (EUR 220M), adapters (EUR 240M), concession (EUR 300M), capacity building (EUR 200M), consumer rollout (EUR 100M), management (EUR 75M) and force-majeure reserve (EUR 150M). This leaves EUR 85M free headroom (5.7% of cap). Fallback cost exposures are estimated at EUR 150–250M for adapter acceleration (if Tier 2/3 carriers slip), EUR 75–150M for concession overrun, and EUR 50–100M for Article 101 rework. Even one of these scenarios exhausts headroom and forces Phase 3 deferral or corridor reduction. The plan has no sensitivity analysis showing what happens if concession subsidy (capped EUR 60M) runs 20–30% over budget, or if shared adapter modules cost EUR 50M instead of EUR 30M. No variance-triggered contingency actions are actionable within the current budget envelope.

### 5.6.B Tags

- thin_contingency
- budget_cliff_month_9
- fallback_exposure_exceeds_headroom
- variance_triggers_force_scope_cut

### 5.6.C Mitigation

Rebase the budget plan immediately with three sensitivity scenarios: (1) Base (current), (2) Adapter Slip (Tier 2/3 miss Month 36 = 2029-10-12 by 6 months, EUR 150M emergency acceleration), (3) Concession Overrun (operating cost +25%, EUR 75M). Run quarterly re-baselining from Month 6 (2027-04-12) onwards with variance triggers at EUR 50M (notify DG MOVE), EUR 100M (defer TEN-T Phase 3 to Month 60–72 = 2031-10-12 to 2032-10-12), EUR 200M (cut concession funding 20% and extend term 5 to 7 years), EUR 300M (restrict full TEN-T to four priority corridors only). Publish monthly cash-flow forecast by 10th of each month (starting Month 1 = 2026-11-12) projecting spend across all lines and cumulative variance. Establish a Steering Group finance committee (bi-weekly) to review variance and approve trigger actions with 5-business-day decision turnaround. Resolve open decisions on concession envelope split (set-up vs. service) and ticket-validation retrofit financing (who pays) by Month 9 (2027-07-12) to remove ambiguity from budget tracking.

### 5.6.D Consequence

Without active headroom management, the first EUR 100–150M cost variance (estimated 6–10% probability by Month 24 = 2028-10-12) will force unplanned scope cuts or programme deferral. The Month 9 (2027-07-12) steering decision on commission band and concession business case will be made without clarity on whether budget remains to fund them. If both adapters and concession slip by 10–15% (plausible (estimate)), EUR 200M+ variance is incurred by Month 30 (2029-04-12), forcing the EUR 200M trigger (cut concession 20%, extend term) or EUR 300M trigger (restrict TEN-T to four corridors). The 40% through-ticket target becomes unachievable if TEN-T extension is cut; planning range falls to 20–25% (estimate).

### 5.6.E Root Cause

Plan was built with committed line items and a thin reserve without sensitivity analysis or decision rules for variance. The EUR 150M force-majeure reserve is locked away (drawable only for pool top-ups after Month 36 = 2029-10-12), leaving zero flexibility for the first 36 months of spending. Open decisions on concession split and validation hardware financing remain unresolved, creating budget tracking ambiguity. No executive decision-making process exists to authorize scope cuts or deferral if variance appears; variance triggers are stated but actions are not pre-approved.

---

# 6 Expert: Financial Risk and Budget Assurance Manager

**Knowledge**: Programme finance, budget variance tracking, reserve fund governance, contingency and scenario analysis, supply-chain cost inflation, project accounting and audit trail

**Why**: The programme faces a hard cap of EUR 1,500M with only EUR 85M free headroom (5.7%), yet faces fallback cost exposures of EUR 150-250M (adapter acceleration), EUR 75-150M (concession overrun) and EUR 50-100M (competition-law rework). The canonical facts specify variance triggers at EUR 100M, EUR 200M and EUR 300M that force scope cuts. This expert must establish monthly cash-flow forecasts starting Month 1 (2026-11-12), ring-fence the EUR 150M force-majeure reserve, manage the open decision on ticket-validation hardware financing (which could exceed the EUR 100M consumer-rollout budget), and trigger scope-reduction levers if cumulative variance approaches EUR 200M by Month 9 (2027-07-12).

**What**: Establish monthly cash-flow forecasting by Month 1 (2026-11-12) with detailed allocations by budget line (standards EUR 80M, clearing EUR 220M, adapters EUR 240M, concession EUR 300M, capacity-building EUR 200M, consumer-rollout EUR 100M, reserve EUR 150M, headroom EUR 85M) and project spend against quarterly milestones; set up a quarterly rebaselining process starting Month 6 (2027-04-12) that tracks actual commitments, invoices and accruals; establish the variance trigger protocol: at EUR 100M cumulative variance, defer TEN-T extension to Months 60-72 (2031-10-12 to 2032-10-12); at EUR 200M, cut concession subsidy by 20% (to EUR 240M of EUR 300M envelope) and extend its term 5 to 7 years; at EUR 300M, restrict scope to four priority corridors; resolve the open decision on ticket-validation hardware financing by Month 9 (2027-07-12) (estimated EUR 30-80M depending on retrofit scope) and adjust headroom; impose a EUR 60M cap on concession operating subsidy with clawback if volume >20% above forecast, subsidy review if volume <60% forecast; brief the steering group on cash position biweekly, escalate variance >EUR 50M to DG MOVE within 5 business days.

**Skills**: Programme budget management, cash-flow forecasting and variance analysis, reserve fund governance and drawdown controls, contingency scenario modelling, procurement cost estimation, audit trail documentation, escalation triggers and trigger-based scope reduction

**Search**: programme budget management variance tracking, contingency reserve governance, cash-flow forecasting large projects, supply-chain cost inflation tracking, procurement budget assurance

## 6.1 Primary Actions

- Commission the independent actuarial study immediately at Month 1 (2026-11-12), not Month 2 (2026-12-12), with a 90-day completion target; engage the three largest carriers and CER to supply 36-month missed-connection and rerouting-cost data; publish binding cap and co-insurance parameters (not indicative) by Month 3 (2027-01-12) and present worked examples to carriers by Month 4 (2027-02-12) for signature by Month 6 (2027-04-12).
- Rebaseline the EUR 1,500M budget by Month 2 (2026-12-12) with a detailed cost breakdown per line item and per carrier tier; establish monthly cash-flow forecasts and track actual spend against commitment from Month 1 (2026-11-12); negotiate fixed-price contracts for standards (EUR 80M), clearing (EUR 220M) and shared adapters (EUR 30M) by Month 6 (2027-04-12) to cap downside risk on 60% of the program.
- Define and lock the concession business case by Month 9 (2027-07-12), specifying: platform set-up costs (EUR 40M ±20%), operating subsidy as a fixed percentage of through-ticket revenue (not a negotiated subsidy cap), binding cost-overrun escalation rules (steering-group approval for costs >EUR 50M), and penalty/clawback language as contract terms (not proposed thresholds); require a performance bond covering 25% of estimated annual subsidy from the winning concessionaire.
- Establish a variance-containment protocol by Month 3 (2027-01-12) that specifies which programme areas will be cut first if the EUR 100M/200M/300M variance triggers are breached; publish a three-scenario cost-growth analysis (base case, 30% growth, 50% growth) showing the consequences of each variance trigger; reserve a separate EUR 50M adapter-acceleration reserve from the unallocated EUR 85M headroom with drawdown authority limited to the Programme Director.
- Conduct the technical audit of all 25+ carriers by Month 2 (2026-12-12) and publish tier assignment by Month 6 (2027-04-12) with binding timelines for Tier 1 (Month 30 = 2029-04-12), Tier 2 (Month 36 = 2029-10-12), Tier 3 (Month 42 = 2030-04-12); release EUR 240M adapter funding in verified tranches tied to demonstrated API availability (99.5% uptime, p95 latency <2 seconds, <1% stale-seat failures) verified by independent audit at Month 3 (2027-01-12) (Tier 1), Month 9 (2027-07-12) (Tier 2), Month 15 (2028-01-12) (Tier 3) 2027/2028.

## 6.2 Secondary Actions

- Establish a quarterly pool-monitoring process (first report Month 6 = 2027-04-12) that publishes actual missed-connection incident rates, contribution adjustments, reserve drawdown and contributor cash flows within 15 business days of quarter-end; make this data available to all carriers so they can model forward exposure and adjust their participation if needed.
- Deploy an SLA monitoring proxy and public scoreboard by Month 12 (2027-10-12) that publishes each carrier's API latency (p50, p95, p99), availability (monthly uptime %) and stale-seat error rate; attach financial penalties to carriers missing two consecutive months of SLA targets (loss of 5% of next funding tranche); use the scoreboard to create market pressure for sustained performance.
- Develop a reserve-fund governance framework by Month 3 (2027-01-12) that specifies: force-majeure incident definition (single-day corridor-wide disruptions affecting >5,000 passengers), 48-hour incident notification, and formal written Transport Commissioner approval required within 5 business days of drawdown request; prohibit any pool draw-downs after Month 36 (2029-10-12).
- Establish a steering-group decision log and variance-tracking dashboard accessible to all core members (updated fortnightly) showing: (1) status of each critical decision (Decisions 1-5) against sign-off milestones; (2) cumulative budget committed vs. available headroom; (3) actual vs. forecast spend by line item and carrier tier; (4) SLA performance scorecards for each carrier; (5) anticipated variance triggers and recommended scope cuts if variance thresholds are breached.
- Conduct a fixed-price competitive tender for the concession award by Month 12 (2027-10-12) with binding contract terms locked; require bidders to propose fixed platform set-up costs (cap EUR 50M), fixed annual operating subsidy (as % of through-ticket revenue, not a public subsidy cap), and a 5-year term with performance-bond requirements; evaluate bidders on cost, volume risk management and technology maturity, not on subsidy minimisation alone.
- Prepare a contingency redesign scenario by Month 9 (2027-07-12) that documents what the programme would deliver under each variance-cut trigger (EUR 100M: defer TEN-T extension; EUR 200M: reduce concession subsidy; EUR 300M: restrict to four corridors); socialise these contingencies with the steering group and carriers so all parties understand the trade-offs before Month 12 (2027-10-12).
- Retain external audit counsel and finance advisors from Month 1 (2026-11-12) to validate the budget assumptions, track variance against actuals and advise on cost-containment options; brief the steering group monthly on budget health starting Month 3 (2027-01-12) and escalate to DG MOVE if cumulative variance exceeds EUR 50M.

## 6.3 Follow Up Consultation


At the next consultation (Month 3, 2027-01-12), review the draft actuarial study findings and carrier feedback on the liability model; confirm the technical audit tier assignments and carrier roadmaps; present the concession business-case outline and confirm cost-split decisions (platform set-up vs. operating subsidy); review the first monthly cash-flow forecast and variance analysis; discuss any steering-group deadlock on critical decisions (Decisions 1-2) and escalation plan for Month 5-6 (2027-03-12 to 2027-04-12) mediation.

## 6.4.A Issue - Liability model pricing is incomplete; carriers cannot yet commit to inventory exposure

The plan specifies a carrier-funded guarantee pool with indicative caps (EUR 500-1,000 per stranded passenger) and co-insurance above EUR 50M, but these figures are not yet actuarially validated. Until the independent actuarial study (due Month 6 = 2027-04-12) confirms incident rates, rerouting costs and contribution weights, carriers have no basis to price connection liability into their through-ticket offers. This is a blocking risk: the pre-project assessment estimates 30-40% carrier refusal if liability remains unpriceable, cascading into 8-15 smaller operators missing the Month 30 (2029-04-12) mandatory API milestone and reducing the 40% through-ticket goal to 15-25%.

### 6.4.B Tags

- liability-pricing-gap
- carrier-risk-aversion
- scope-delivery-risk

### 6.4.C Mitigation

Execute the actuarial study immediately (Month 1 = 2026-11-12, not Month 2 = 2026-12-12) with a 90-day completion target; engage the three largest carriers (SNCF, Deutsche Bahn, SBB) and CER to supply proprietary 36-month missed-connection and rerouting-cost data; publish worked examples (large, regional, small carrier profiles) by Month 4 (2027-02-12) to enable carriers to model their own contribution range; present the full model to at least 8 major carriers for non-binding feedback by Month 5 (2027-03-12), then binding sign-off by Month 6 (2027-04-12); establish quarterly pool-monitoring reporting starting Month 6 (2027-04-12) so carriers can verify actual incident rates against forecast.

### 6.4.D Consequence

If actuarial validation is not complete by Month 6 (2027-04-12), carrier participation will drop to 60-70% (estimate), fragmenting the four priority corridors and forcing emergency scope reductions (EUR 100-150M, estimate). The Month 30 (2029-04-12) mandatory API milestone will be missed by Tier 2 and Tier 3 carriers entirely, pushing corridor go-live from Month 48 (2030-10-12) to Month 54-60 (2031-04-12 to 2031-10-12) (estimate) and compressing the TEN-T extension wave into the last 12 months, violating the five-year horizon.

### 6.4.E Root Cause

The liability model design was finalized before actuarial loss data was assembled. Carriers cannot price unpredictable, uncapped exposure, and no amount of regulatory mandate forces them to expose inventory at a loss. The Month 4 (2027-02-12) carrier sign-off deadline is unrealistic without months of claims-data analysis and scenario stress-testing completed in parallel.

## 6.5.A Issue - Budget headroom is exhausted by known risks; no flexibility for adapter acceleration or concession overruns

The plan commits EUR 1,415M of the EUR 1,500M cap (leaving EUR 85M free headroom, 5.7%), including a EUR 150M force-majeure reserve that is segregated and non-spending. The fallback exposures identified in the SWOT (adapter acceleration EUR 150-250M, concession overrun EUR 75-150M, Article 101 rework EUR 50-100M) total EUR 275-500M against only EUR 85M unallocated headroom. Any combination of these risks (e.g., 40% of Tier 2 carriers missing Month 36 = 2029-10-12 deadline + concession operating cost exceeding 20% forecast) will force hard scope cuts at Month 36-42 (2029-10-12 to 2030-04-12), precisely when the final-wave TEN-T extension should be ramping.

### 6.5.B Tags

- budget-contingency-gap
- variance-trigger-risk
- scope-reduction-likely

### 6.5.C Mitigation

Rebaseline the budget immediately with a detailed cost breakdown per line item and per carrier tier; conduct a three-scenario variance analysis (base case, 30% cost growth, 50% cost growth) to show which cut triggers apply in each case; establish a monthly cash-flow forecast starting Month 1 (2026-11-12) with actual spend tracked against commitment; negotiate binding fixed-price contracts for standards (EUR 80M), clearing (EUR 220M) and shared adapters (EUR 30M) by Month 6 (2027-04-12), capping downside risk on 60% of the program; reserve the EUR 150M force-majeure fund as a true contingency and establish a separate EUR 50M (estimate) adapter-acceleration reserve carved from the unallocated EUR 85M, with drawdown authority limited to the Programme Director subject to monthly reporting to the steering group.

### 6.5.D Consequence

Without explicit variance containment, the programme will face a budget crisis at Month 36-42 (2029-10-12 to 2030-04-12) when actual spend on adapters and concession becomes clear. The hard variance triggers will force reductions that undermine the 40% through-ticket goal: restricting to four corridors alone cuts the addressable market from ~25% of total EU cross-border journeys to ~8% (estimate), and deferring TEN-T to Month 60-72 (2031-10-12 to 2032-10-12) leaves the programme's political momentum to decay over 2-3 years. A EUR 250M shortfall would consume all remaining headroom and the force-majeure reserve, leaving zero flexibility for any unforeseen claim.

### 6.5.E Root Cause

The budget was baseline-d on aggressive line-item estimates (e.g., EUR 240M adapters for all three tiers, EUR 300M concession envelope) without pricing-in the cost of latent demand: if carriers need more time and support to meet API deadlines, the program must choose between concession cuts (limiting passenger reach), adapter deferrals (extending timelines) or TEN-T phase reductions (cutting coverage). The variance triggers at EUR 100/200/300M are sensible, but they commit to cut outcomes (defer TEN-T, reduce concession, restrict to four corridors) that may politically unacceptable.

## 6.6.A Issue - Concession structure is undefined; subsidy cap is uncommitted and subject to interpretation

The plan carves out EUR 300M for a last-resort distributor concession but leaves critical terms open: (1) the split between platform set-up (capital) and operating subsidy (EUR 0-60M annually); (2) whether the EUR 60M operating subsidy is a floor or a ceiling given uncertainty in passenger volumes; (3) how cost overruns and underperforming volume will be handled contractually (clawback and review triggers are proposed but not legally binding). If the concessionaire's platform costs EUR 100M (vs. the estimated EUR 30-50M set-up cost) or if passenger volumes are 40% lower than forecast, the subsidy could reach EUR 80-100M annually, consuming EUR 400-500M of the EUR 300M envelope (estimate) over five years and triggering the EUR 200M variance-cut scenario.

### 6.6.B Tags

- concession-cost-control-weak
- subsidy-escalation-risk
- fixed-price-absent

### 6.6.C Mitigation

By Month 9 (2027-07-12), publish a detailed concession business case specifying: (1) platform set-up costs broken into software, infrastructure, staffing and integration (target: EUR 40M, with a ±20% contingency); (2) operating subsidy as a fixed percentage of through-ticket revenue (proposed: 15-20% of gross fare revenue on through-tickets sold, capped at EUR 12M annually); (3) cost-overrun escalation: any platform cost >EUR 50M requires steering-group approval; (4) clawback and penalty language as binding contract terms, not proposed thresholds; (5) a fixed contract term of 5 years (not extendable to 7 years except by explicit Commission decision with 12-month notice). Tender the concession by Month 12 (2027-10-12) with these terms locked, and require the winning bidder to maintain a performance bond covering 25% of estimated annual subsidy.

### 6.6.D Consequence

If the concession cost is not capped contractually by Month 12 (2027-10-12), a concessionaire selected at Month 18 (2028-04-12) could demand cost variations worth EUR 50-100M additional subsidy over the five-year term, triggering a budget crisis at Month 24-30 (2028-10-12 to 2029-04-12) when actual spend becomes clear. This would force a hard EUR 200M variance cut (reduce concession funding by 20%, extend term to 7 years, or move to direct public operation at higher cost), destabilizing distributor participation and passenger reach at the critical moment when Tier 1 API exposure is being rolled out and the first corridors are preparing go-live.

### 6.6.E Root Cause

The concession was designed as a strategic lever (avoiding a competitive threat to Trainline and Omio) without detailed financial engineering. The "cap" of EUR 60M is stated as a proposed threshold, not a contractual binding. The open questions (set-up cost split, subsidy floor/ceiling, cost-overrun allocation) were deferred to the business-case phase (Month 9 = 2027-07-12, estimate), but the budget already commits the EUR 300M envelope without knowing the contractual structure. This leaves the Programme Office vulnerable to scope creep once a concessionaire is selected.

---

# 7 Expert: Passenger Experience and Accessibility Requirements Lead

**Knowledge**: Rail passenger rights regulation (1371/2007), accessibility for persons with reduced mobility (PRM), user research and usability testing, complaints handling processes, multilingual information design, bicycle and assistance coordination

**Why**: The programme aims to deliver through-tickets with continuous passenger-rights protection and integrated accessibility (assistance, wheelchair spaces, bicycles) across 25+ carriers with different operational practices. Decision 10 (Assistance and Bicycle Reservation Chaining) identifies that binding capacity to available spaces risks blocking many itineraries. The pre-assessment specifies that a passenger-rights legal review is due Month 1 (2026-11-12) with opinion by Month 6 (2027-04-12) and a compliance manual approved by the Agency by Month 9 (2027-07-12). This expert must ensure through-ticket terms meet or exceed Regulation 1371/2007, coordinate assistance booking across carriers with mismatched notice periods and rolling stock, and validate that the public distributor's concession (EUR 60M subsidy) delivers accessible, multilingual complaint handling that halves distributor complaints by Month 60 (2031-10-12).

**What**: Commission and lead the independent passenger-rights legal review by Month 1 (2026-11-12), comparing through-ticket terms (assistance, rerouting, compensation, refunds, information, disability accommodation) against Regulation 1371/2007; publish the opinion by Month 6 (2027-04-12) and identify any gaps requiring design changes; develop a passenger-rights compliance manual by Month 9 (2027-07-12) specifying step-by-step procedures for each carrier, the clearing entity and the public distributor; submit to the Agency for formal approval by Month 9 (2027-07-12); design the accessibility booking flow (Assistance and Bicycle Reservation Chaining, Decision 10) specifying single notice period across carriers, atomic confirmation (reject the itinerary if any leg lacks capacity), fallback alternatives; validate through pilots with disability-rights organisations at Months 12-18 (2027-10-12 to 2028-04-12) using 500-1,000 test passengers; set accessibility conformance thresholds (proposed: wheelchair access 80% of services, assistance within 4 hours' notice 90% of services) and audit compliance Months 30 and 35 (2029-04-12, 2029-09-12); design the concession's multilingual complaint system (estimate EUR 10-15M of the EUR 100M consumer-rollout budget) to log, route and resolve complaints from distributors and passengers within 15 business days (proposed threshold), and publish monthly complaint trends to track progress toward halving distributor complaints by Month 60 (2031-10-12).

**Skills**: Rail passenger-rights regulatory interpretation, accessibility requirements translation to technical specs, user research and usability testing with diverse populations, multilingual content design and localisation, complaints-handling process design and analytics, disability-rights organisation engagement and co-design

**Search**: EU rail passenger rights regulation 1371/2007, accessibility persons with reduced mobility rail, passenger complaints handling procedures, multilingual travel information design, assistance coordination multiple carriers

## 7.1 Primary Actions

- Commission a dedicated PRM user research workstream (Month 1 = 2026-11-12) led jointly by the Programme Office and ≥2 disability-rights organisations (EBU, EDEF); co-design Decision 10 (atomic assistance confirmation) with 200+ PRM passengers in Months 2-4 (2026-12-12 to 2027-02-12); validate the 80/90% accessibility thresholds by Month 6 (2027-04-12); pilot atomic confirmation on 2 corridors with 200 PRM users at Months 12-18 (2027-10-12 to 2028-04-12); publish accessibility impact statement by Month 9 (2027-07-12) with evidence-based threshold revision.
- Define and staff a dedicated Complaints Handling Operations Centre (Month 3 = 2027-01-12) with EUR 25-40M allocation, 40-60 staff FTE, baseline audit of all four corridors by Month 3 (2027-01-12), target-state workflow by Month 6 (2027-04-12) (single entry point, 48-hour SLA, root-cause triage, carrier escalation), and pilot on one corridor Months 18-24 (2028-04-12 to 2028-10-12) before rollout to all four by Month 30 (2029-04-12).
- Define a mandatory 'Multilingual and Accessibility Conformance Profile' within OSDM by Month 2 (2026-12-12) (minimum 18 EU official languages for public distributor, WCAG 2.1 AA standard, B1 CEFR readability, screen-reader and caption support); conduct moderated usability testing with 50+ passengers (≥15 disabled, ≥15 non-native speakers) on wireframes at Months 4, 8, 14 (2027-02-12, 2027-06-12, 2027-12-12); embed multilingual and accessibility certificates as conformance requirements (Decision 6); make language and accessibility support binding conditions for carrier API and public distributor concession.

## 7.2 Secondary Actions

- Establish a Passenger Rights Oversight Board (Month 1 = 2026-11-12) comprising the EU Agency for Railways, BEUC, ≥2 disability organisations and ≥2 consumer organisations; meet quarterly starting Month 6 (2027-04-12) to review baseline complaints, accessibility audit findings, multilingual usability test results and compliance with Regulation 1371/2007; publish quarterly scorecards showing complaints per corridor, categories and resolution times.
- Integrate PRM and multilingual requirements into the pre-programme technical audit (Month 2 = 2026-12-12): each carrier must demonstrate API support for accessibility metadata (wheelchair, assistance, bicycle), multilingual OSDM payloads (German, French, Spanish, Dutch, Polish minimum) and accessibility-feature availability per service; tier assignment (Month 6 = 2027-04-12) must include accessibility and language readiness as factors.
- Fund and execute a Regulation 1371/2007 impact assessment by Month 3 (2027-01-12) covering: whether through-ticket passengers retain equal or superior rights to single-carrier passengers in assistance, compensation, refunds and complaint handling; identify any gaps and revise the liability model (Decision 1) if compensation rules are inferior; obtain formal sign-off from the EU Agency for Railways by Month 9 (2027-07-12).
- Establish a Complaints Data Working Group (Month 6 = 2027-04-12) comprising the Programme Office, carriers, distributors, BEUC and the Agency to define: complaint taxonomy (root-cause categories for through-ticketing vs. single-carrier), SLA targets per category (target 90% resolution within 30 days), escalation triggers to carrier CIOs (e.g., >10 complaints/week on same root cause) and quarterly public scorecards showing complaint trends and resolution times per corridor and distributor type.
- Commission an independent accessibility audit of all four priority corridors (Month 6 = 2027-04-12) covering: station accessibility (lifts, ramps, accessible toilets), train accessibility (boarding, seating, wheelchair spaces, accessible toilets), and staff training on PRM assistance; map accessibility gaps and develop carrier-specific remediation plans; make accessibility audit results a condition of corridor go-live (Month 48 = 2030-10-12).
- Pilot accessibility and multilingual features on a low-volume corridor (Months 12-18 = 2027-10-12 to 2028-04-12) with 500-1,000 passengers, measuring: success rate by language, satisfaction with multilingual error messages and help, completion rate for PRM passengers (vs. non-PRM), reroute success for assisted passengers and complaint rates by language; publish findings at Month 18 (2028-04-12) and revise designs before rolling out to remaining three corridors.

## 7.3 Follow Up Consultation

"At the next consultation, we should discuss: (1) Who will lead the PRM user research and disability-rights co-design, and which organisations are ready to commit by Month 1 (2026-11-12)? (2) What baseline complaints data is available per corridor, and who will conduct the Month 3 (2027-01-12) audit? (3) How will multilingual and accessibility conformance be enforced at carrier and distributor level—through the concession contract, through OSDM versioning, or through regulatory requirements? (4) Should the EUR 100M consumer-rollout budget be explicitly split (EUR 25-40M complaints, EUR 15-25M multilingual, EUR 20-30M accessibility, remainder communications), and who owns each budget line? (5) Will the EU Agency for Railways commit to a Passenger Rights Oversight Board role, and will BEUC and disability organisations participate from Month 6 (2027-04-12) onwards?"

## 7.4.A Issue - Accessibility and PRM Provisions Are Underspecified and Lack Passenger-Centered Validation

The plan mentions 'accessibility for persons with reduced mobility (PRM)' as a scope item and proposes 'assistance and bicycle reservation chaining' as Decision 10, yet the accessibility strategy is fragmented across budget allocations, accessibility thresholds (80% wheelchair access, 90% assistance within 4 hours) and scattered conformance requirements. There is no integrated accessibility user research or co-design workstream with disability-rights organisations. The proposed thresholds (80/90%) are ambitious but lack evidence of feasibility, baseline data or phased achievability paths. The decision to make assistance 'atomic' (reject itineraries lacking capacity) will visibly reduce through-ticket availability, yet passengers with disabilities are not explicitly included in the Month 12-18 (2027-10-12 to 2028-04-12) pilots. Conformance validation does not mention PRM-specific test scenarios.

### 7.4.B Tags

- accessibility_underspecified
- prm_no_user_research
- atomic_confirmation_risk
- no_disability_pilots
- threshold_evidence_gap

### 7.4.C Mitigation

Commission a dedicated PRM user research workstream by Month 1 (2026-11-12), led jointly by the Programme Office and at least two disability-rights organisations (e.g., EBU, EDF). Run co-design workshops Months 2-4 (2026-12-12 to 2027-02-12) to validate the 80/90% thresholds and explore phased approaches (e.g., best-effort fallback with compensation, tiered assistance notice periods). Pilot Decision 10's atomic confirmation with at least 200 PRM passengers on two corridors at Months 12-18 (2027-10-12 to 2028-04-12), measuring itinerary availability loss, passenger satisfaction and reroute success. Embed PRM test scenarios in the conformance test suite by Month 18 (2028-04-12). Publish an accessibility impact statement by Month 9 (2027-07-12) and revise thresholds if pilots show >15% itinerary loss or <70% passenger satisfaction.

### 7.4.D Consequence

Without user-centred validation, the programme risks implementing accessibility rules that reduce choice for PRM passengers (atomic confirmation rejecting itineraries) without clear evidence that passengers prefer certainty over availability. Atomic confirmation that blocks 10-20% of itineraries (estimate) will create a visible accessibility barrier: a passenger with mobility needs sees fewer options than a non-disabled passenger, reversing the programme's inclusive intent. Disability-rights bodies may withhold endorsement, slowing regulatory approval. Lawsuits under accessibility directives post-launch are plausible if thresholds are unmet or if atomic rejection disproportionately excludes PRM users.

### 7.4.E Root Cause

The programme treats accessibility as a compliance checklist (Regulation 1371/2007, threshold targets) rather than as a core passenger experience dimension. Decision 10 was drafted by transport engineers, not by disability-rights organisations or PRM-experienced travel designers. The decision to atomically confirm assistance and bicycle spaces will create a visible trade-off (fewer itineraries) that passengers will feel immediately, yet no usability testing or co-design with disability organisations has validated whether this trade-off is acceptable or whether phased, best-effort alternatives would deliver better outcomes.

## 7.5.A Issue - Complaint Handling Infrastructure Is Missing; 'Halved Complaints' Target Lacks Causal Chain

The programme targets 'distributor complaints halved' by Month 60 (2031-10-12) as a headline metric, yet the complaint-handling design is essentially absent. Budget allocations include EUR 100M for 'consumer rollout' (multilingual information, complaint handling, communications, accessibility usability testing), but no dedicated complaint-handling budget line, no defined complaints workflow, no staffing, and no integration between the clearing entity, carriers, distributors and passengers. The plan assumes complaints fall because through-ticketing improves, yet no analysis of what complaints actually are (passenger-to-distributor, distributor-to-carrier, passenger-to-carrier) or what root causes generate them. The passenger-rights legal review (Month 1-9 = 2026-11-12 to 2027-07-12) is mentioned but is not connected to complaint-handling design. No data on baseline complaint volume per corridor is cited.

### 7.5.B Tags

- complaints_no_design
- complaints_staffing_missing
- no_baseline_data
- no_workflow_defined
- halved_target_not_causal

### 7.5.C Mitigation

By Month 3 (2027-01-12), conduct a baseline complaints audit on the four priority corridors covering: complaint volume (passenger and distributor), categories (booking, payment, disruption, refund, accessibility, lost luggage), resolution time, repeat-complaint rates and appeal outcomes per carrier. Segment by distributor and passenger type (PRM, non-EU passengers, repeat travellers). Publish findings and design a target-state complaints-handling workflow by Month 6 (2027-04-12) specifying: (1) single point of entry (clearing entity or concession distributor receives all complaints), (2) 48-hour acknowledgement SLA, (3) root-cause triage (booking error, settlement, carrier delay, passenger error), (4) escalation path to carrier CIOs for systematic issues, (5) EU Agency for Railways oversight of complaint data (quarterly scorecards). Allocate EUR 25-40M of the EUR 100M consumer-rollout budget explicitly to complaint-handling staffing (estimate 40-60 staff), IT systems and carrier liaison. Run a pilot complaint workflow on one corridor at Months 18-24 (2028-04-12 to 2028-10-12) and measure reduction in repeat complaints before applying to all four corridors.

### 7.5.D Consequence

Without a designed complaint-handling infrastructure, the programme risks measuring 'complaints halved' without knowing what it means or whether it was caused by through-ticketing improvements or by lower passenger volumes. New clearing and federated systems will generate unprecedented volumes of settlement disputes, latency failures and reconciliation errors (estimate 10-25% of transactions in early months), which will cascade to passenger complaints. If the Programme Office and carriers are not staffed to triage and resolve these systematically, complaints may actually double in the first 12-24 months, contradicting the 40% through-ticket and complaint-reduction targets. Regulators and BEUC will demand proof that the complaints metric is real and causal, not an artefact of measurement or volume reduction.

### 7.5.E Root Cause

The programme inherited 'halved complaints' as a user constraint / headline metric without designing the operational machinery to achieve it. Complaints handling is seen as a 'consumer rollout' administrative task rather than as a core passenger-experience lever. The causal assumption—that complaints fall because through-ticketing improves—is untested. In reality, new systems (clearing, federated settlement, multi-leg queries) generate new complaint categories (reconciliation disputes, latency failures, reroute errors) that may offset reductions in single-operator complaints.

## 7.6.A Issue - Multilingual Information Design and Non-Discriminatory Accessibility Are Underdeveloped; No Evidence of Usability Testing with Diverse Passenger Cohorts

The plan allocates EUR 100M for 'consumer rollout (multilingual information, complaint handling, communications, accessibility usability testing)' and proposes that the public distributor 'operate a full consumer-facing public booking service in all EU languages'. Yet there is no detailed specification of which languages, how many (22, 24+?), how translations are maintained, or what accessibility standards apply. The concession tender (Month 12 = 2027-10-12) will define the scope post-hoc, risking scope creep and budget overruns. No usability testing is planned with linguistically diverse or accessibility-needing passengers before binding standards (Month 18 = 2028-04-12). Conformance testing (Decision 6) does not explicitly require multilingual or accessibility conformance. The plan assumes that neutral search and emissions display will drive modal shift, but offers no evidence that non-native speakers or passengers with disabilities understand the offer or trust it.

### 7.6.B Tags

- multilingual_underspecified
- no_language_scope
- no_usability_testing
- accessibility_not_conformance_requirement
- assumptions_unvalidated

### 7.6.C Mitigation

By Month 2 (2026-12-12), define a mandatory 'Multilingual and Accessibility Conformance Profile' as part of the OSDM specification, specifying: (1) minimum 18 EU official languages (at least all EU member-state languages) for the public distributor, (2) WCAG 2.1 AA accessibility standard minimum for all booking UIs, (3) readability at B1 CEFR level (secondary school reading level) for passenger-facing text, (4) support for screen readers, captions and high-contrast modes. By Month 4 (2027-02-12), conduct moderated usability testing with 50+ passengers (including ≥15 with mobility/sensory disabilities, ≥15 non-native speakers) on wireframes of the public distributor and one commercial distributor, testing: booking flows, price comparisons, error messages, assistance-request clarity, refund procedures and complaint submission. Iterate designs based on testing findings and test again at Months 8 and 14 (2027-06-12, 2027-12-12). Embed multilingual and accessibility conformance testing in the technical audit (Month 2 = 2026-12-12): each carrier must demonstrate API support for multilingual OSDM payloads (German, French, Spanish, Dutch, Polish at minimum) and accessibility metadata (wheelchair, assistance, bicycle spaces). Make multilingual and accessibility certificates conditions of conformance (Decision 6).

### 7.6.D Consequence

Without explicit multilingual and accessibility usability testing, the programme risks deploying a through-ticketing system that is unusable for 15-25% of EU passengers (non-native speakers, elderly, disabled travellers) and for passengers in lower-income member states where English proficiency is lower. Early passengers will encounter booking flows, error messages and refund procedures in poor translations or inaccessible designs, generating high complaint rates and negative word-of-mouth. Disability-rights organisations will publicly oppose launch if accessibility conformance is not demonstrated. The 40% through-ticket and modal-shift targets assume equitable access; discriminatory usability undermines both. Post-launch rework of multilingual and accessibility features across distributed carrier systems could cost EUR 30-50M (estimate) and delay full TEN-T rollout by 6-12 months.

### 7.6.E Root Cause

The programme treats multilingual information and accessibility as budget line items ('EUR 100M consumer rollout') rather than as user-experience requirements that must be validated early and iterated with real passengers. Conformance testing (Decision 6) focuses on technical API metrics (uptime, latency, error rates) and does not include accessibility or multilingual usability. The public distributor concession has not yet been designed (business case Month 9 = 2027-07-12, tender Month 12 = 2027-10-12, award Month 18 = 2028-04-12), so the scope and user experience remain undefined. The plan confuses 'information' (telling passengers the booking is available) with 'usability' (passengers actually being able to use it).

---

# 8 Expert: Data Architecture and Real-Time Systems Assurance Officer

**Knowledge**: Distributed event streaming (Kafka, RabbitMQ), data governance and quality frameworks, real-time availability shadows and caching strategies, disruption event feeds, GDPR and data minimisation in real-time systems, chaos engineering and failure-mode analysis

**Why**: Decision 5 (Availability Query Topology) specifies a streamed availability shadow with carrier booking authority, published event-streamed availability for search and an event feed for disruption rerouting (Decision 9). These components depend critically on data quality, latency consistency and graceful degradation when carrier systems fail. The SWOT analysis identifies that three-leg queries at 95% availability each yield 86% combined, below the proposed 99.5% SLA, and the weaknesses section flags latency and availability shortfalls as risks to through-ticket success. This expert must architect the real-time data pipeline (streamed availability, disruption events, SLA metrics), validate latency and error rates against proposed thresholds, and design contingency caching that gracefully degrades to scheduled-only offers without stranding passengers.

**What**: Design the distributed event-streaming architecture for real-time availability (carriers publish seat availability changes via Kafka or RabbitMQ to a shared event stream) and disruption events (carriers publish delay and cancellation signals to trigger rerouting) by Month 6 (2027-04-12); specify data quality standards (required fields, timestamp precision UTC milliseconds, recovery semantics for lost or duplicate events) and validate against OSDM standards; architect the availability shadow (cached itinerary search results, updated from events, stale after 5 minutes) and the distributed cache (Redis or equivalent, estimated EUR 15-25M) that enables graceful degradation to scheduled-only offers if a carrier endpoint is unavailable >30 seconds; deploy SLA monitoring synthetic probes (queries every 5 minutes, distributed geographically) and publish a monthly public scoreboard showing p50/p95/p99 latency and uptime per carrier by Month 12 (2027-10-12); establish latency and availability thresholds (proposed: p95 <2 seconds, uptime 99.5%, stale-seat errors <1%) and attach them to funding tranches (two consecutive months missed SLA = 5% tranche reduction); design a failover protocol for the disruption event feed so that if the event stream is unavailable, distributors and carriers fall back to bilateral notifications and manual rebooking rather than stranding passengers; conduct chaos-engineering tests (kill carrier endpoints, delay event stream) at Months 18, 30 and 42 (2028-04-12, 2029-04-12, 2030-04-12) to validate rerouting and cache-fallback behaviour; establish GDPR data minimisation rules (no passenger personal data in event streams, event retention <90 days, anonymised analytics only) and publish a data-handling protocol by Month 9 (2027-07-12).

**Skills**: Distributed systems architecture, event-streaming platforms (Kafka, RabbitMQ), real-time caching and data freshness, chaos engineering and failure-mode testing, data quality frameworks and observability, GDPR data minimisation and privacy engineering, SLA monitoring and alerting

**Search**: distributed event streaming Kafka rail booking, real-time availability cache degradation, chaos engineering microservices testing, GDPR data minimisation real-time systems, availability shadow architecture distributed cache

## 8.1 Primary Actions

- Commission a detailed real-time availability-shadow architecture specification by Month 3 (2027-01-12) covering event schema, ordered delivery, stale-data TTL, and fallback thresholds; validate with carrier CIOs and a distributed-systems expert by Month 3.5 (2027-01-27) before integrating into the OSDM binding standards.
- Establish a formal disruption event-feed specification by Month 4 (2027-02-12) detailing Kafka-based broker topology, at-least-once delivery guarantees, deduplication, and recovery lag; conduct chaos-engineering tests by Month 10 (2027-08-12) and assign 24/7 operational ownership starting Month 12 (2027-10-12).
- Commission a GDPR privacy-impact assessment by Month 2 (2026-12-12) and publish findings by Month 3 (2027-01-12); incorporate data-minimisation requirements into the OSDM binding standards (Month 18 = 2028-04-12), establish a Data Governance Board starting Month 6 (2027-04-12), and require DPA sign-off from all carriers by Month 12 (2027-10-12).
- Execute the pre-programme technical audit by Month 2 (2026-12-12) per the pre-project assessment, publish tier assignment by Month 6 (2027-04-12), and add latency and availability validation into Tier 1 conformance criteria (Month 30 = 2029-04-12)—specifically, p95 latency <2 seconds on 3-leg queries and 99.5% combined availability.
- Establish SLA monitoring and availability contingency architecture by Month 12 (2027-10-12) per the pre-project assessment, with live pilots on one priority corridor (2,000-4,000 passengers) at Months 12-18 (2027-10-12 to 2028-04-12) to validate stale-seat failure rates, reroute latency, and settlement reconciliation under realistic load.

## 8.2 Secondary Actions

- Appoint a Chief Data Architect (or Data Systems Lead) reporting to the Programme Office director by Month 1 (2026-11-12) with authority over all real-time layer decisions; this role should chair a technical architecture committee meeting biweekly to resolve event-streaming, caching and failure-mode trade-offs.
- Develop a distributed-systems failure-mode matrix by Month 6 (2027-04-12) documenting: (1) single carrier endpoint down (>2 minutes); (2) network partition between EU hub and carrier; (3) event-feed publisher lag (>60 seconds); (4) settlement netting platform unavailable; (5) clock skew across carriers. For each, specify: observable symptoms, automated detection, alerting, graceful degradation mode, recovery time and RTO/RPO targets. Review quarterly and update based on pilot experience.
- Procure a commercial event-streaming platform (Kafka, Pulsar or equivalent) and shared reconciliation platform as standalone services by Month 6 (2027-04-12), not custom builds; budget EUR 5-10M for licensed SaaS or managed Kafka hosting (subset of the EUR 50M realtime-layer budget). This reduces operational risk and accelerates pilot deployment.
- Establish a Data Quality and Real-Time Observability workstream by Month 3 (2027-01-12) responsible for defining: (1) SLIs (service-level indicators) per data layer—event-feed latency, stale-data percentage, settlement reconciliation error rate, disruption reroute time; (2) alerting rules and escalation (e.g., if stale data exceeds 5%, page the Data Architect and notify carriers within 15 minutes); (3) monthly observability reports to the steering group starting Month 6 (2027-04-12).
- Commission external competition-law and data-protection counsel from Month 1 (2026-11-12) (budget EUR 2-5M over three years) to co-author the DPIA and advise on Article 101 TFEU compliance of shared data flows; ensure both roles are embedded in the Technical Secretariat so feedback loops are tight and binding standards incorporate legal constraints from the start.

## 8.3 Follow Up Consultation

Next consultation should address: (1) Detailed design of the streamed availability shadow—caching strategy, stale-data TTL, fallback degradation thresholds and latency guarantees under carrier outage; (2) Disruption event-feed topology—publish-subscribe guarantees, event ordering and deduplication across carriers, and recovery from feed lag; (3) GDPR data minimisation in real-time booking flows—what booking and location data flows through the shared layer, retention policies, and passenger consent models; (4) Failure-mode testing plan for multi-leg queries at the proposed 99.5% carrier SLA, including chaos-engineering scenarios (carrier endpoint down, network partition, stale inventory); (5) Settlement reconciliation under disruption—how reroute costs and refunds propagate through the federated netting layer when a carrier is offline.

## 8.4.A Issue - Streamed Availability Shadow Architecture Lacks Resilience Specification

The plan states 'publish an event-streamed availability shadow for search' but does not specify: (1) which carrier events feed the shadow (seat inventory only, or fares, restrictions, operational status?); (2) ordering and deduplication guarantees when the same seat update arrives from multiple sources or is retransmitted after network failure; (3) stale-data time-to-live (TTL) per search result—when does a cached result degrade to scheduled-only?; (4) recovery lag when a carrier's event stream falls behind real-time (e.g., 30-second backlog). Without these, the shadow will be operationally unreliable: searches will return conflicting inventory, and stale-seat booking failures will exceed the 1% SLA, frustrating distributors and passengers. This is the foundation of the Availability Query Topology decision (Decision 5) and must be locked before Month 12 (2027-10-12).

### 8.4.B Tags

- event-stream-design
- availability-shadow
- cache-staleness
- operational-resilience
- underspeci-fied

### 8.4.C Mitigation

Commission a detailed real-time architecture specification by Month 3 (2027-01-12) covering: (1) event schema (seat delta, fare delta, operational status, timestamp, source carrier, deduplication ID); (2) ordered, at-least-once delivery guarantees using a Kafka-like topic per carrier or shared topic with per-carrier partitioning; (3) shadow TTL policy (e.g., search results valid 2 minutes, degraded to scheduled if carrier unavailable >30 seconds); (4) recovery from lag: if carrier event stream is >60 seconds behind, pause search queries for that carrier and alert distributors. Run a distributed-systems validation workshop (month 3.5 = 2027-01-27) with carrier CIOs and a Kafka expert to confirm this spec is implementable on legacy backend systems. Integrate the spec into the OSDM binding standards (Month 18 = 2028-04-12) so carriers cannot deviate.

### 8.4.D Consequence

Without clarity now, pilots at Months 12-18 (2027-10-12 to 2028-04-12) will encounter stale-seat failures, cascading reroute failures and distributor complaints about unreliable search. This will delay the Month 18 (2028-04-12) binding-standards vote, push the Month 30 (2029-04-12) API exposure gate, and deter carriers from committing inventory. Estimate 3-6 month slip, 10-20% reduction in carrier participation, and EUR 30-50M in unplanned remediation spend (exceeding the EUR 85M headroom).

### 8.4.E Root Cause

The decision documents outline the topology (federated with cached shadow) but delegate the operational resilience to execution. Real-time event-streaming systems require upfront clarity on consistency models, failure modes and degradation policies, not post-hoc tuning. The absence of this detail now will force expensive rework once pilots expose latency and reconciliation issues at Month 12-18 (2027-10-12 to 2028-04-12).

## 8.5.A Issue - Disruption Event Feed Has No Publish-Subscribe Guarantees or Ordering Semantics

Decision 9 (Disruption Re-accommodation Choreography) calls for 'a shared disruption event feed to which all carriers publish and distributors subscribe,' yet the plan omits: (1) event ordering—if Carrier A delays at 14:30 and Carrier B then reroutes a passenger, will all distributors see the delay event before the reroute? Or will network lag, publisher backlog or subscriber lag cause inconsistent ordering?; (2) deduplication—if a delay is reported by multiple staff, will the feed deduplicate and notify distributors once, or spam them?; (3) at-least-once vs. exactly-once delivery—can a distributor miss a delay notification, leaving a passenger unreboked?; (4) recovery time—if the feed publisher is offline for 2 minutes, how long before subscribers catch up, and do they replay missed events or skip to live?. Without these semantics, automated rebooking will fail: distributors will not see missed connections, passengers will be left stranded, and manual intervention will spike, defeating the credibility of the through-ticket. This is critical to operationalising the liability backstop (Decision 1).

### 8.5.B Tags

- event-ordering
- pub-sub
- disruption-feed
- exactly-once-delivery
- failure-modes

### 8.5.C Mitigation

Establish a formal disruption event-feed specification by Month 4 (2027-02-12) detailing: (1) OSDM disruption event schema (delay event, reroute event, cancellation, station incident, with UTC timestamp and source carrier ID); (2) Kafka-based broker (partition per corridor, ordered by timestamp within a partition, retention 7 days minimum); (3) guarantees: at-least-once delivery to all subscribers (distributors and the rerouting service), deduplication by event ID, subscriber lag monitoring and alerts if lag exceeds 60 seconds; (4) recovery: if publisher is offline, event-feed operator must auto-replay buffered events to catch up subscribers. Conduct a chaos-engineering test (Month 10 = 2027-08-12) simulating carrier unavailability, network partitions and clock skew to validate the feed behaves correctly. Assign 24/7 operational ownership (feed operations team of 4-6 staff) starting Month 12 (2027-10-12); cost estimate EUR 1-2M/year (fits in the realtime-layer EUR 50M budget line). Include feed SLAs in the binding standards: 99.5% availability, <5-second end-to-end latency from carrier publish to distributor subscribe, zero deduplication failures.

### 8.5.D Consequence

If ordering and delivery semantics are not defined and tested before pilots, stranded passengers will be the visible failure: a distributor will receive a reroute event before the delay event, or miss the delay entirely, and the passenger will not be reboked on time. This will generate the complaint spike the programme aims to halve, undermine passenger trust in through-tickets, and trigger regulatory intervention at Month 18 (2028-04-12) or later. Estimate 20-40% of missed-connection rebooking failures (versus the <5% SLA), 5-10% increase in passenger complaints, and potential legislative amendment to mandate a central real-time coordination service, forcing USD 100-200M in emergency investment.

### 8.5.E Root Cause

The decision framing emphasises the operational benefit ('reduced stranded passengers') but treats the event feed as a delivery mechanism, not a distributed system with failure modes. Real-time event brokers (Kafka, RabbitMQ, Pulsar) have well-known ordering and durability challenges, especially across carrier boundaries where network partitions, clock skew and publisher availability differ. The plan assumes a working feed without specifying who builds it, who operates it, and what happens when it fails.

## 8.6.A Issue - GDPR Data Minimisation Not Addressed in Real-Time Booking and Settlement Flows

The plan mandates 'a shared real-time data layer exposed through OSDM-compatible APIs' and 'federate settlement through a shared netting and dispute-resolution layer,' but does not specify what booking and settlement data flows through these shared mechanisms or how GDPR Article 5 (data minimisation) and Article 7 (consent) are satisfied. Specifically: (1) Does the availability shadow retain passenger names, booking references or payment data, or only seat IDs and fares?; (2) How long are these booking records held in the clearing layer?; (3) When a passenger is rerouted via the disruption event feed, does the feed carry the passenger's PNR (passenger name record) across carriers, or only the seat/payment ID?; (4) If a passenger requests a refund, does the netting layer need to see their identity, or only a booking token?; (5) Are there separate data-handling agreements per carrier or a single shared protocol? Without clarity, the programme risks intra-EU data flows that violate GDPR, particularly if reroute data or refund data carries PII across carrier boundaries. This will trigger national data-protection authority investigations, delay API exposure and block carrier participation.

### 8.6.B Tags

- GDPR
- data-minimisation
- PII-flows
- cross-border
- consent-management

### 8.6.C Mitigation

Commission a privacy-impact assessment (DPIA) by Month 2 (2026-12-12) led by an external EU data-protection specialist (budget EUR 200-300K) documenting: (1) data flows through each layer (availability shadow, disruption feed, clearing, refund netting, reroute request); (2) which fields carry PII (name, email, phone, location, booking history) and which do not (seat ID, fare, payment token); (3) retention windows per layer and justification; (4) consent model—does a passenger booking a through-ticket consent separately to GDPR-required processing by each carrier, or one consent per through-ticket?; (5) cross-border data-transfer mechanisms (Standard Contractual Clauses, adequacy decisions, or binding corporate rules if carriers are part of the same group). Publish DPIA findings by Month 3 (2027-01-12) and incorporate data-minimisation requirements into the OSDM binding standards (Month 18 = 2028-04-12): e.g., 'availability shadow shall not retain booking records after 24 hours,' 'disruption feed shall not carry passenger names, only booking tokens,' 'clearing layer shall delete refund details after settlement (5 business days) unless dispute is pending.' Establish a Data Governance Board (sub-committee of steering group) meeting monthly from Month 6 (2027-04-12) to audit compliance and resolve cross-carrier consent disputes. Require all carriers to sign a Data Processing Addendum (DPA) by Month 12 (2027-10-12) specifying roles (controller, processor, joint controller) per layer.

### 8.6.D Consequence

If GDPR compliance is not designed upfront, national DPAs will issue enforcement actions post-launch (likely Months 30-36 = 2029-04-12 to 2029-10-12 during API exposure pilots) requiring system redesign, data deletion and potentially blocking of APIs pending remediation. This will delay TEN-T extension, fragment corridors, and expose the Commission and carriers to fines up to 4% of turnover under GDPR Article 83(6). Estimate 6-12 month remediation cycle, EUR 50-100M rework cost, and 25-50% reduction in through-ticket volume during enforcement period as distributors and carriers pause integration to await legal clarity.

### 8.6.E Root Cause

Data governance and privacy engineering are not listed as core dependencies in the project plan, though GDPR is mentioned as a regulatory requirement. The OSDM standard itself (referenced but not detailed in this plan) may not have formally addressed data minimisation in multi-carrier scenarios. The federated settlement model multiplies the number of data handlers, each with independent GDPR obligations, but the plan does not articulate how they coordinate on consent, retention, and cross-border flows. This is a regulatory risk that will surface after standards are binding, when national DPAs audit the live system.