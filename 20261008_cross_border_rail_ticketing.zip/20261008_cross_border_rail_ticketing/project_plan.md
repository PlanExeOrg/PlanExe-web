**Goal Statement:** Deliver a federated EU cross-border rail through-ticketing programme, aligned with the proposed Regulation on Digital Booking and Ticketing Services for Rail, so that 40% of cross-border journeys are sold as single through-tickets and distributor complaints are halved by Month 60 (2031-10-12), within a EUR 1,500M public budget cap.

## SMART Criteria

- **Specific:** Establish shared standards, a real-time availability layer, federated clearing, a carrier-funded rights backstop and a last-resort distributor so any compliant distributor can sell through-tickets across participating carriers on four priority corridors, then the TEN-T network.
- **Measurable:** 40% of cross-border journeys sold as single through-tickets, distributor complaints halved, binding standards at Month 18 (2028-04-12), Tier 1 API exposure at Month 30 (2029-04-12), four corridors live by Month 48 (2030-10-12), public spend within EUR 1,500M.
- **Achievable:** Builds on OSDM and existing clearing arrangements, layering over legacy carrier systems. Carrier-funded liability pool and milestone tranches protect the budget. Risks: carrier participation, legislative slip; planning range if prerequisites slip is 15-30% (estimate).
- **Relevant:** Removes fragmentation that blocks single-ticket cross-border rail travel, improves passenger rights continuity, distributor access and the competitiveness of rail against short-haul air.
- **Time-bound:** Five years from project start: governance at Month 1 (2026-11-12), binding standards Month 18 (2028-04-12), Tier 1 API exposure Month 30 (2029-04-12), four corridors live Month 48 (2030-10-12), target full network and 40% share by Month 60 (2031-10-12).

## Dependencies

- Adoption of the Regulation, with binding standards and OSDM pinned by Month 18 (2028-04-12)
- Competition-law comfort from DG COMP on shared data and clearing, before standards bind
- Carrier-signed liability model (guarantee pool, caps, co-insurance) before inventory exposure
- Technical audit of carrier booking systems and tier assignment to set conformance timelines
- Steering governance with binding votes on liability, clearing, public distributor and commission band

## Resources Required

- Public coordination budget of EUR 1,500M (user constraint)
- Programme Office (about 80 staff, estimate) and Technical Secretariat (about 50 staff, estimate)
- Carrier IT integration teams, financed privately at EUR 1.5-3.0 billion (estimate)
- Actuarial, competition-law and passenger-rights legal specialists
- Conformance test environments, reconciliation platform and SLA monitoring proxy

## Related Goals

- Air-to-rail modal shift on competitive short-haul corridors (5-10% planning value, estimate)
- Accessible assistance and bicycle reservation across carriers
- Multimodal integration with bus, ferry and short-haul air
- Full TEN-T network through-ticketing

## Tags

- rail
- through-ticketing
- OSDM
- EU regulation
- clearing and settlement

## Risk Assessment and Mitigation Strategies


### Key Risks

- Carriers refuse to expose inventory because connection liability cannot be priced
- Legacy booking systems miss Month 30 (2029-04-12) API exposure; 8-15 smaller operators at risk (estimate)
- Regulation adoption slips 6-12 months beyond Month 18 (2028-04-12) (estimate, not verified)
- Article 101 TFEU challenge forces clearing rework of EUR 50-100M (estimate)
- Pool or concession overruns exceed the EUR 85M free headroom

### Diverse Risks

- Steering deadlock delays binding standards by 2-4 months (estimate)
- Latency and availability shortfalls across multi-leg queries reduce through-ticket success
- Reconciliation errors lengthen settlement cycles and deter distributors
- Ticket validation gaps on corridor vehicles reduce passenger trust
- Low-fare airline response limits modal shift

### Mitigation Plans

- Actuarial study and carrier-signed liability model with caps and co-insurance by Month 4 (2027-02-12); Month 6 (2027-04-12) readiness gate, deferring to Month 12 (2027-10-12) if unresolved
- Technical audit by Month 2 (2026-12-12), tiered conformance (Months 30/36/42 = 2029-04-12, 2029-10-12, 2030-04-12) and EUR 240M adapter funding released on verified performance
- DG COMP pre-notification at Month 2 (2026-12-12), guidance by Month 12 (2027-10-12), clean-team protocol by Month 14 (2027-12-12); shadow standards workstream for legislative slip
- EUR 150M force-majeure reserve, no pool draw-downs after Month 36 (2029-10-12), variance triggers at EUR 100M/200M/300M and concession subsidy cap of EUR 60M
- 75% supermajority steering rule with Commission mediation, SLA scorecards tied to tranches, and live pilots at Months 12-18 (2027-10-12 to 2028-04-12)

## Stakeholder Analysis


### Primary Stakeholders

- DG MOVE (Programme Office)
- EU Agency for Railways (Technical Secretariat)
- National rail operators and CER
- Independent distributors (Trainline, Omio) and the last-resort concessionaire
- Passengers, BEUC and disability-rights bodies

### Secondary Stakeholders

- National railway regulators
- DG COMP
- Member-state governments
- Bus, ferry and short-haul air operators
- Payment service providers and IT vendors

### Engagement Strategies

- Biweekly steering group with binding votes on core decisions by Month 6 (2027-04-12) and Commission mediation for deadlock
- Option papers by Month 2 (2026-12-12) and quarterly briefings to carriers and distributors on pool, SLA and commission-band data
- Regulator observer seats in standards groups plus bilateral impact assessments per member state
- Disability and consumer bodies as observers, with usability testing by Month 18 (2028-04-12)
- Milestone-based reporting to DG COMP, the Court of Auditors and member states

## Regulatory and Compliance Requirements


### Permits and Licenses

- Adoption and Official Journal publication of the Digital Booking and Ticketing Regulation
- Delegated or implementing act pinning the OSDM version
- Payment-services authorisation for the settlement layer participants (where required)
- Concession award under EU public procurement rules

### Compliance Standards

- Article 101 TFEU competition rules
- Existing EU rail passenger-rights regulation as the rights floor
- GDPR for passenger and booking data
- EU accessibility requirements for persons with reduced mobility

### Regulatory Bodies

- European Commission (DG MOVE, DG COMP)
- EU Agency for Railways
- National railway regulators
- European Court of Auditors

### Compliance Actions

- Pre-notify DG COMP at Month 2 (2026-12-12) and obtain guidance by Month 12 (2027-10-12)
- Commission independent passenger-rights review at Month 1 (2026-11-12), opinion by Month 6 (2027-04-12), compliance manual approved by Month 9 (2027-07-12)
- Complete regulator impact assessments per member state by Month 3 (2027-01-12)
- Set up clean-team clearing protocol by Month 14 (2027-12-12)
- Apply accessibility thresholds (80% wheelchair access, 90% assistance within 4 hours' notice) in conformance (proposed threshold)