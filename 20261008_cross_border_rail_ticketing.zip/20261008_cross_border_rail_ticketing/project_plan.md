**Goal Statement:** Deliver the Pragmatic Foundation programme for EU cross-border rail through-ticketing, starting Month 0 (2026-10-08): binding standards by Month 18 (2028-04-08), mandatory OSDM API exposure by Month 30 (2029-04-08), and full through-ticketing on four priority corridors by Month 60 (2031-10-08), within the EUR 1,500 million public cap, reaching 40% through-ticket share.

## SMART Criteria

- **Specific:** Establish technical, commercial and governance arrangements so any compliant distributor can sell multi-carrier through-tickets (single booking reference, single payment, continuity-of-journey rights) on the four priority corridors, with TEN-T extension starting Month 36 (2029-10-08).
- **Measurable:** 40% of cross-border rail journeys sold as through-tickets by Month 60 (2031-10-08); distributor complaints at or below 50% of the Month 9 (2027-07-08) validated baseline; at least 90% of corridor traffic bookable end-to-end at Month 30 (2029-04-08) (proposed threshold); spend within the EUR 1,500 million cap.
- **Achievable:** Uses a realistic scenario: certification-based access, accredited payment institutions, regional hubs and an arbitration panel avoid new legal entities. Limits: pending Regulation, legacy carrier IT, and a fixed budget with EUR 225 million contingency. Modal shift of 5-15% is a planning range only (estimate).
- **Relevant:** Removes the fragmentation that blocks single through-tickets across national operators, supports the proposed EU Regulation on Digital Booking and Ticketing for Rail, and makes rail more attractive than short-haul flying.
- **Time-bound:** Five-year programme from Month 0 (2026-10-08) (project start ASAP). Standards by Month 18 (2028-04-08), API mandate by Month 30 (2029-04-08), TEN-T extension start Month 36 (2029-10-08), full corridor through-ticketing by Month 60 (2031-10-08).

## Dependencies

- Adoption of the Regulation by Parliament and Council by Month 9 (2027-07-08) (proposed gate; pause carrier onboarding commitments if not adopted by Month 10 = 2027-08-08)
- Written Council/Commission delegation of binding technical authority to the arbitration panel by Month 2 (2026-12-08)
- Carrier Commitment Letters signed by carriers above EUR 50M cross-border revenue by Month 3 (2027-01-08) (proposed threshold)
- Accredited payment institutions operational (at least 2 by Month 12 = 2027-10-08)
- Hub operators contracted and operational for carriers with legacy booking systems
- Agreed through-ticket definition and validated measurement baseline

## Resources Required

- EUR 1,500 million public budget incl. EUR 225 million contingency held at DG MOVE
- OSDM standards and conformance testing labs
- Shared data layer: API hosting, availability cache, 24/7 operations centre, neutral operator
- Regional booking hubs (4 at launch, 2 TEN-T hubs reserved)
- Programme management office, arbitration panel and consumer app/support teams

## Related Goals

- Extension of through-ticketing to the full TEN-T network from Month 36 (2029-10-08)
- Multimodal hooks for buses, ferries and short-haul air
- Modal shift from short-haul air to rail (planning range 5-15%)
- Post-Month 60 (2031-10-08) sustainable funding of distributor, hubs and data layer (about EUR 45M/year unfunded, estimate)
- Accessible travel for persons with reduced mobility

## Tags

- rail
- through-ticketing
- OSDM
- EU regulation
- passenger rights

## Risk Assessment and Mitigation Strategies


### Key Risks

- Regulation adoption slips past Month 9 (2027-07-08), compressing the standards window
- Arbitration panel lacks enforcement power over large incumbents
- Budget overrun of 20-30% exceeds the EUR 215 million free contingency
- Hub or legacy-IT delays leave smaller carriers behind at Month 30 (2029-04-08)
- GDPR or competition-law challenge to the shared data layer

### Diverse Risks

- Payment provider accreditation draws fewer than 2 applicants
- Distributors (Trainline, Omio) delay integration or demand preferential access
- Through-fares fail to compete with airlines, so modal shift falls short
- Accessibility assistance confirmed but not delivered on platforms
- Post-Month 60 (2031-10-08) funding cliff for distributor, hubs and data layer

### Mitigation Plans

- Run shadow standards pre-work from Month 0 (2026-10-08); track legislation; hire an external standards consortium if adoption passes Month 8 (2027-06-08)
- Secure written delegation by Month 2 (2026-12-08) and Commitment Letters by Month 3 (2027-01-08) with escrow penalties (proposed threshold)
- Build a cost model by Month 2 (2026-12-08); hold mid-course reviews at Months 12 and 24 (2027-10-08, 2028-10-08); apply Tier 1-3 cuts at 115% of pro-rata spend; seek supplementary authority if needed
- Contract hubs by Month 3 (2027-01-08), run 2-4 week dual-runs, and suspend onboarding if the booking-failure rate exceeds 2% for a week
- Complete the DPIA, reach EDPB/DPA consensus on SCCs by Month 4 (2027-02-08), and consult competition authorities on data-sharing scope
- Use bilateral settlement or emergency procurement as a fallback; fund distributor co-marketing; set accessibility SLAs; decide the post-Month 60 (2031-10-08) funding model by Month 48 (2030-10-08)

## Stakeholder Analysis


### Primary Stakeholders

- DG MOVE (programme owner and budget holder)
- EU Agency for Railways (technical secretariat)
- Programme management office and arbitration panel
- National rail carriers (SNCF, Deutsche Bahn, Trenitalia, Renfe, ÖBB, NS, SJ and others)
- Distributors (Trainline, Omio, public reference distributor)

### Secondary Stakeholders

- CER and smaller carriers
- National regulators
- BEUC and disability-rights bodies
- Payment institutions and hub operators
- EDPB, national data protection authorities and competition authorities

### Engagement Strategies

- Weekly reporting to DG MOVE and the Agency; quarterly Steering Committee
- Quarterly roundtables with major carriers and dedicated slots for smaller carriers
- Distributor advisory council with early API access in return for integration commitments
- Monthly Standing Regulators Committee and twinning for weaker regulators
- Accessibility and consumer working groups; milestone updates to Parliament TRAN committee

## Regulatory and Compliance Requirements


### Permits and Licenses

- Payment institution licences (PSD2) for accredited providers
- Written Council/Commission delegation for the arbitration panel
- Competition authority comfort letter or clearance for data sharing
- Distributor certification under the tiered access scheme
- Non-EU participation agreements (e.g. Swiss SBB) for Wien-Munchen-Zurich

### Compliance Standards

- Proposed Regulation on Digital Booking and Ticketing Services for Rail
- GDPR (DPIA, SCCs, 90-day PII deletion)
- EU rail passenger rights rules
- Articles 101/102 TFEU competition law
- Accessibility requirements (WCAG 2.1 AA, 24 h assistance confirmation)

### Regulatory Bodies

- European Commission (DG MOVE, DG COMP)
- EU Agency for Railways
- National rail regulators
- European Data Protection Board and national DPAs
- National competition authorities

### Compliance Actions

- Complete DPIA Months 0-2 (2026-10-08 to 2026-12-08) and reach DPA consensus by Month 4 (2027-02-08)
- Seek competition-authority consultation on data scope by Month 6 (2027-04-08)
- Run payment accreditation: call Month 2 (2026-12-08), decision Month 8 (2027-06-08)
- Embed GDPR, accessibility and liability insurance checks in the conformance checklist
- Anchor binding standards at Month 18 (2028-04-08) and quarterly compliance reviews