
## Audit - Corruption Risks

- Preferential API access granted to favored distributors in exchange for kickbacks or side agreements, violating non-discrimination duties and certification schemes.
- Hub operators steering smaller carriers toward unnecessary or overpriced services, or manipulating mapping logic to inflate usage fees and transaction volumes.
- Carrier executives accepting co-funding grants in exchange for inflating invoices or falsely certifying API compliance, diverting public money to private benefit.
- Payment-institution staff delaying or misdirecting settlement funds to affiliated entities, exploiting the multi-carrier clearing mechanism for personal gain.
- Regulators accepting informal favors (travel, consulting contracts for family members) from major carriers in exchange for lax enforcement of access-term compliance.
- Programme staff or arbitration-panel members leveraging insider knowledge of technical decisions to advise carriers or distributors on how to circumvent or game the standards.

## Audit - Misallocation Risks

- Co-funding grants to carriers are inflated or allocated to carriers not meeting the eligibility criteria (revenue > EUR 50M or IT staff > 10 FTE), leaving truly disadvantaged carriers unfunded.
- Hub operational budgets (EUR 44M allocated) are misused for non-core activities (marketing, staff perks) instead of integration support and resilience, causing hubs to fail and requiring emergency replacement spending.
- Conformance-testing budget (EUR 280M standards + testing) is front-loaded to early carriers, exhausting resources before smaller or slower operators can be tested, delaying their Month 30 (2029-04-08) readiness.
- Programme staff travel and overhead consume 20–30% of PMO and governance costs without proportional output; inefficient meeting structure and decision-making delay standards work by 2–4 months.
- Public reference distributor budget (EUR 215M over 5 years, ~EUR 43M/year) is used to launch a full retail service with margins and marketing spend that crowds out commercial distributors, rather than being limited to reference implementation and pilot accessibility services.
- Payment-institution accreditation budget and fee-subsidy reserves (EUR 15M in fee subsidy + EUR 5–10M provider-switch contingency) are consumed by single-provider dominance or early provider failure, leaving no resources for genuine competition or failover.

## Audit - Procedures

- Quarterly co-funding recipient audits (starting Month 6 = 2027-04-08): verify that grant recipients meet eligibility criteria, that invoice amounts are reasonable and supported by documentation, and that promised integration milestones (API exposure, data-quality SLAs) are achieved; withhold next disbursement if audit raises red flags.
- Monthly hub operational reviews (starting Month 9 = 2027-07-08): inspect hub operator's incident logs, uptime records, booking-failure rates and mapping-accuracy samples; if booking-failure rate exceeds 2% for >1 week, freeze new carrier onboarding and conduct root-cause audit.
- Conformance-testing capacity and throughput audits (quarterly, Month 12 onward = 2027-10-08 onward): track test-lab utilization, queue times for carriers awaiting slots, and distribution of testing resources across carrier size cohorts; if small carriers face >8-week delays while majors are tested within 2 weeks, reallocate lab capacity.
- Payment-institution performance and fee audits (monthly, Month 12 onward = 2027-10-08 onward): verify settlement cycle compliance (<48 hours), refund-processing SLA (decision <10 days), transaction-fee caps (target 0.3–0.5%, max 0.7%), and absence of preferential treatment of affiliated or large-carrier accounts.
- Carrier co-funding claim audits (quarterly, Month 6 onward = 2027-04-08 onward): sample 5–10% of invoices, interview carrier IT teams about milestone progress, verify that private spend (assumed EUR 0.5–2.0 billion) is actually occurring and is not being substituted by public funding, and reconcile carrier-reported spending against commitments made in Month 3 (2027-01-08) Commitment Letters.
- Post-implementation external compliance audit (Month 42–48 = 2030-04-08 to 2030-10-08): hire independent auditor to verify that all major systems (data layer, clearing, hubs, public distributor, regulator capacity) are operating within SLAs, that access terms are enforced consistently across member states, and that no unbudgeted liabilities have accumulated; use findings to validate Month 60 (2031-10-08) sustainability model.

## Audit - Transparency Measures

- Monthly public dashboard (published on DG MOVE website, starting Month 6 = 2027-04-08) showing: cumulative spend by budget line item vs. plan, carrier compliance status (on-time or delayed) for each corridor, hub operational metrics (uptime %, booking-failure rate), and provisional through-ticket volumes and complaints metrics; dashboard updated within 2 weeks of quarter-end to provide real-time visibility.
- Quarterly Steering Committee meeting minutes published (within 2 weeks of meeting) including: decisions made, dissenting views from any stakeholder, technical disputes that went to arbitration, and budget or schedule changes; confidential commercial data (individual carrier cost, specific carrier IT architecture) redacted; all meetings held in Brussels with open audio/video feed option for observers (non-decision makers).
- Arbitration panel rulings and reasoning documents published (within 5 working days of decision, Month 1 onward = 2026-11-08 onward) showing the technical question, competing positions, evidence considered, and the panel's rationale; dissenting opinions from panel members recorded and published alongside the majority ruling.
- Carrier and distributor certification and access-term audit results published quarterly (aggregate form, Month 18 onward = 2028-04-08 onward): percentage of carriers and distributors meeting OSDM conformance, number and outcome of non-discrimination complaints filed and resolved, average API latency and uptime per corridor, and any enforcement actions or penalties imposed.
- Public reference distributor operational transparency report (quarterly, Month 15 onward = 2028-01-08 onward): through-ticket volumes, revenue, operating cost, accessibility-assisted bookings, complaint types and resolution times, and financial sustainability outlook; identify any subsidy draw above budget or structural deficits requiring mid-course intervention.
- Annual programme evaluation and progress report (first report Month 12 = 2027-10-08, then annually) published by an independent evaluator, comparing baseline (Month 9 = 2027-07-08) to latest outcomes on the three headline targets (40% through-ticket share, complaints halved, modal shift in planning range 5–15%), and disclosing methodology, any data gaps or attribution uncertainty, and recommendations for course corrections.