### 1. Programme Steering Committee (PSC)

**Rationale for Inclusion:** This is a large, multi-stakeholder, regulation-dependent public infrastructure program with a fixed €1.5B budget, distributed execution across four corridors, and critical dependencies on carrier participation, legislative adoption, and competition-law clearance. The programme has multiple high-impact strategic decisions (liability backstop, clearing architecture, public distributor role, funding release conditions) that require binding votes by Month 6 (2027-04-12) to unblock standards work and maintain the Month 18 (2028-04-12) binding-standards milestone. Strategic oversight must operate above operational delivery and hold explicit decision authority over funding tranches, milestone conditions and escalation to the Commission.

**Responsibilities:**

- Approve and enforce critical strategic decisions (Through-Ticket Liability and Rights Backstop, Inter-Carrier Clearing and Single-Payment Settlement, Public Reference Distributor Mandate, Milestone-Conditioned Funding Release Ladder, Availability Query Topology) by binding votes at Month 6 (2027-04-12).
- Set and approve annual programme budgets and funding-tranche release conditions; trigger variance-mitigation actions when cumulative spend reaches thresholds (EUR 100M, EUR 200M, EUR 300M).
- Approve conformance-gate and carrier-tier assignments; escalate conformance failures or missed SLA targets (latency, availability, reconciliation error) to the Programme Office for remedial action or funding tranche withholding.
- Oversee and approve the binding Commission guidance letter from DG COMP on Article 101 TFEU and passenger-rights legal compliance by Month 14 (2027-12-12); escalate unresolved legal or regulatory conflicts to Commission Transport Commissioner.
- Monitor and approve quarterly SLA and financial reports; authorize policy recalibrations (e.g., reserve draws, concession subsidy increases above the EUR 60M cap, TEN-T extension deferrals) if contingencies are triggered.
- Resolve deadlocked steering votes or stakeholder disputes via a formal escalation and mediation process; record all votes and dissents; publish meeting minutes within 15 days (redacting sensitive data).

**Initial Setup Actions:**

- Formally establish the Committee by Commission decision at Month 1 (2026-11-12) with explicit charter, voting rules (75% supermajority for core decisions), and escalation authority to the Transport Commissioner.
- Appoint Chair (DG MOVE Director or equivalent) and Secretary (Technical Secretariat lead) by Month 1 (2026-11-12).
- Confirm membership and secure binding commitment letters from all nine core members (DG MOVE, Agency, CER, 3-4 major carriers, Trainline, Omio, BEUC, disability body) by Month 2 (2026-12-12).
- Publish the option-papers document outlining three variants for each of Decisions 1-5 with explicit trade-offs by Month 2 (2026-12-12) to inform stakeholder positions.
- Establish a published voting and decision-recording process, including dissent documentation and tie-breaker rules, by Month 1 (2026-11-12).
- Schedule biweekly meetings (rotating virtual and in-person) for Months 1-12 (2026-11-12 to 2027-10-12) to maintain momentum on the Month 6 (2027-04-12) readiness gate and Month 18 (2028-04-12) binding-standards milestone.

**Membership:**

- Chair: DG MOVE (Director or Transport Commissioner designate)
- Vice-Chair: EU Agency for Railways (Director)
- CER (Chief Executive)
- Deutsche Bahn (or ÖBB/SBB if DB unavailable)
- SNCF (Chief Commercial Officer)
- Renfe or SJ (second major carrier)
- Trainline (Head of Policy or Chief Executive)
- Omio (Head of Regulatory Affairs or Chief Executive)
- BEUC (Head of Transport Policy)
- European Disability Forum (or equivalent disability-rights representative) (independent observer, non-voting)

**Decision Rights:** Binding strategic decisions over critical programme levers (liability backstop, clearing architecture, public distributor role, funding-tranche conditions, conformance gates, SLA thresholds, regulatory escalations). Decisions above EUR 100M cumulative variance or affecting programme schedule milestones must be approved by the Committee. Decisions below EUR 10M or operational (e.g., monthly reconciliation reviews, individual carrier SLA remediation) are delegated to the Programme Office without Committee approval.

**Decision Mechanism:** Supermajority voting (at least 7 of 9 core members, 75%) required for approval of Decisions 1-5 and for any variance triggers above EUR 100M. Simple majority (5 of 9) for procedural matters (meeting schedule, charter updates) and quarterly financial reports. In the event of a deadlock (vote below 75%), the issue is escalated to the Commission Transport Commissioner with a formal briefing by Month 5 (2027-03-12); mediation is completed by Month 6 (2027-04-12) or the decision defers to a fallback governance path (e.g., bilateral clearing interface for distributors, tiered conformance with mixed gates). Tie-breaker: the Chair (DG MOVE) casts the deciding vote only if the vote is 4.5-4.5 or a member abstains; otherwise, deadlock triggers escalation. All votes and dissents are recorded in minutes published within 15 days.

**Meeting Cadence:** Biweekly during Phase 1 (Months 1-18 = 2026-11-12 to 2028-04-12) to maintain momentum on standards-setting and stakeholder consensus; monthly during Phase 2 (Months 18-48 = 2028-04-12 to 2030-10-12) to oversee API exposure, conformance audits and funding tranches; quarterly during Phase 3 (Months 48-60 = 2030-10-12 to 2031-10-12) for TEN-T extension and final evaluation. Emergency sessions convoked within five business days if a funding variance trigger is hit or a regulatory escalation occurs.

**Typical Agenda Items:**

- Voting on critical decisions (liability model sign-off, clearing architecture, public distributor concession award, funding tranche conditions) by Month 6 (2027-04-12).
- Quarterly SLA and financial reports: conformance-certification results, latency/availability scorecards, settlement reconciliation error rates, pool-contribution and clawback calculations, concession operating costs vs. budget.
- Regulatory and legal updates: DG COMP guidance-letter status, passenger-rights legal-review findings, national regulator impact assessments, clean-team protocol approval.
- Variance-trigger management: review of cumulative spend against budget lines, authorization of contingency draws (reserve, concession subsidy cap), policy recalibrations if thresholds (EUR 100M, EUR 200M, EUR 300M) are crossed.
- Stakeholder escalations: resolution of deadlocked votes, discrimination complaints from distributors, carrier non-participation signals, national regulator conflicts.
- Schedule and milestone tracking: binding-standards progress, API exposure tier readiness, corridor go-live date confirmation, TEN-T extension planning.

**Escalation Path:** Unresolved deadlocks on core decisions (Decisions 1-5) at the Committee escalate to the Commission Transport Commissioner with a formal briefing and mediation request by Month 5 (2027-03-12); mediation completes by Month 6 (2027-04-12) or a fallback governance path is invoked. Funding variances above EUR 300M or programme-scope reductions (deferral of TEN-T extension beyond Month 72 = 2032-10-12, restriction to four corridors only) escalate to the Commission's Financial Controller and the Court of Auditors. Regulatory or competition-law conflicts that block standards adoption escalate to DG COMP and DG MOVE's legal service for resolution by Month 12 (2027-10-12) or standards are deferred. Carrier or distributor disputes unresolved by the Committee after 30 days escalate to the Commission for independent mediation or binding arbitration.
### 2. Programme Office and Operational Management Board (OMB)

**Rationale for Inclusion:** The programme spans four physical locations, 25+ carriers, independent distributors, and five-year delivery horizons with fixed regulatory milestones (Month 18 = 2028-04-12, Month 30 = 2029-04-12, Month 60 = 2031-10-12). Day-to-day programme management, budget execution, milestone tracking, carrier engagement, and operational risk management require a dedicated operational governance body with clear authority below the Steering Committee's strategic thresholds. The OMB must manage EUR 1.5B budget execution, oversee the Programme Office's 80+ staff, coordinate standards-working groups, conduct conformance testing and audits, manage funding tranches, and escalate blockers to the Steering Committee. Separating operational from strategic governance prevents agenda congestion at the Committee level and gives clear accountability for delivery.

**Responsibilities:**

- Execute the Programme Office mandate: manage the 80-person team across DG MOVE, coordinate the Technical Secretariat (50 staff) at the Agency, deploy liaison officers in Brussels, Valenciennes, Berlin and Madrid, and maintain the shared reconciliation platform and SLA proxy.
- Manage EUR 1.5B public budget execution: prepare quarterly financial reports showing cumulative spend per line (standards EUR 80M, clearing EUR 220M, adapters EUR 240M, concession EUR 300M, capacity building EUR 200M, consumer rollout EUR 100M, reserve EUR 150M), track variances against allocations, and recommend contingency triggers (EUR 100M, EUR 200M, EUR 300M) to the Steering Committee.
- Own technical audit and tier assignment: conduct the full audit of all 25+ carriers' booking systems by Month 2 (2026-12-12), assign carriers to tiers (Tier 1: Month 30 = 2029-04-12; Tier 2: Month 36 = 2029-10-12; Tier 3: Month 42 = 2030-04-12), and publish per-operator integration timelines and adapter funding allocations.
- Manage conformance testing and certification: operate test environments, conduct independent audits for OSDM API compliance, latency (p95 <2 seconds), availability (99.5%), stale-seat failures (<1%), and booking-error rates; publish monthly SLA scorecards by carrier; recommend funding tranche withholding for carriers missing SLAs for two consecutive months.
- Manage funding-tranche releases: verify milestone conditions (API exposure, conformance certificates, SLA targets) before authorizing each tranche; track clawback and subsidy-cap conditions for the concession; escalate funding-release delays or remediation needs to the Steering Committee.
- Coordinate standards-working groups: chair the technical working group on OSDM, liability model, clearing architecture, fare construction, disruption re-accommodation and ticket validation; prepare option papers and steering-group briefings; track standards progress against Month 18 (2028-04-12) deadline.
- Manage carrier and distributor engagement: conduct bilateral briefings with carriers on liability model, conformance requirements and funding tranches; mediate commission-rate disputes and discrimination complaints; manage fallback interfaces for distributors rejecting the clearing design.
- Oversee pilots and live validation: conduct live pilots of 500-1,000 passengers per corridor at Months 12-18 (2027-10-12 to 2028-04-12); track reroute response times, passenger satisfaction and re-accommodation success; manage validation deployment to corridor rolling stock and station gates by Month 40 (2030-02-12).
- Manage risk and issues: maintain a register of top risks and issues; track mitigation actions (e.g., DG COMP guidance letter, passenger-rights legal review, national regulator impact assessments); escalate risks reaching their trigger conditions (e.g., legislation delay, carrier participation drop) to the Steering Committee within five business days.

**Initial Setup Actions:**

- Appoint Programme Director and Operations Manager by Month 1 (2026-11-12); establish the Operational Management Board as a sub-committee of the Steering Committee with Chair (Programme Director), Secretary (Operations Manager), and representatives from Programme Office, Technical Secretariat, carrier leads and distributor lead.
- Commission the technical audit of all carriers' booking systems by Month 1 (2026-11-12); complete by Month 2 (2026-12-12).
- Establish the Programme Office (80 staff) and Technical Secretariat (50 staff) by Month 1 (2026-11-12); hire core staff for standards, conformance, clearing, adapters, capacity building and consumer rollout by Month 3 (2027-01-12).
- Procure shared reconciliation platform, SLA proxy and test-environment infrastructure by Month 3 (2027-01-12); deploy by Month 6 (2027-04-12).
- Commission carrier-liability actuarial study and competition-law pre-notification to DG COMP by Month 1 (2026-11-12).
- Establish and publish the quarterly financial reporting and variance-tracking process by Month 2 (2026-12-12).

**Membership:**

- Chair: Programme Director (DG MOVE, appointed by Month 1 = 2026-11-12)
- Secretary: Operations Manager (Programme Office, appointed by Month 1 = 2026-11-12)
- Head of Standards and Conformance (Technical Secretariat lead)
- Head of Clearing and Settlement (Programme Office, clearing function lead)
- Head of Carrier Engagement (Programme Office, liaison to CER and major carriers)
- Head of Distributor and Consumer Affairs (Programme Office, liaison to Trainline, Omio and last-resort concessionaire)
- Head of Compliance and Risk (Programme Office, legal, competition-law and passenger-rights lead)
- Representative from Financial Planning and Control (DG MOVE Finance)

**Decision Rights:** Operational decisions on budget execution below EUR 10M per line, milestone tracking, conformance-certification results, SLA scorecards, funding-tranche conditions (verification of milestone achievement), carrier tier assignment and adapter funding allocation, and pilot results. Decisions on funding tranches up to EUR 50M are delegated to the OMB; larger releases (EUR 80M Tier 1, EUR 80M Tier 2, EUR 50M Tier 3) require Steering Committee approval. Decisions on variance responses below EUR 50M (e.g., accelerating adapter schedules within existing budget, reallocating between standards and testing) are delegated; responses exceeding EUR 50M escalate to the Committee. Conformance-gate remediation (requiring carriers to retest, withholding tranches) is delegated; deferral of entire tiers or carriers from the programme escalates to the Steering Committee.

**Decision Mechanism:** Simple majority (at least 4 of 7 OMB members) for operational decisions. Consensus preferred for budget execution and milestone tracking to maintain transparency; if consensus is not reached, the Chair (Programme Director) decides, with written record to the Steering Committee within five business days. Any decision affecting the Steering Committee's strategic milestones (Month 18 = 2028-04-12, Month 30 = 2029-04-12, Month 48 = 2030-10-12) requires Steering Committee approval, not OMB-only decision. Tie-breaker: Programme Director casts deciding vote.

**Meeting Cadence:** Weekly during Phase 1 (Months 1-18 = 2026-11-12 to 2028-04-12) to maintain momentum on standards and readiness-gate prep; biweekly during Phase 2 (Months 18-48 = 2028-04-12 to 2030-10-12) to track API exposure, conformance and funding tranches; monthly during Phase 3 (Months 48-60 = 2030-10-12 to 2031-10-12) for TEN-T extension. Emergency sessions within two business days if a conformance audit fails, a carrier signals non-participation, or a funding variance reaches a trigger threshold.

**Typical Agenda Items:**

- Technical audit findings and carrier tier assignment (Month 2 = 2026-12-12).
- Standards-working group progress: OSDM specification, liability model, clearing architecture, fare construction, disruption choreography, ticket validation.
- Quarterly financial reports: cumulative spend per budget line, variance tracking, reserve balance, concession operating-cost and subsidy tracking, clawback calculations.
- Conformance audit results: monthly SLA scorecards by carrier, latency/availability/error-rate trends, remediation tracking for carriers missing targets, tranche-withholding recommendations.
- Funding-tranche verification: milestone-completion evidence (API exposure certificates, conformance certificates), conditions for next tranche release.
- Carrier and distributor engagement: feedback from bilateral briefings, commission-rate disputes, discrimination complaints, fallback-interface adoption.
- Pilot results: passenger satisfaction, reroute response times, accessibility issues, validation acceptance rates (by Month 18 = 2028-04-12).
- Risk and issue tracking: top 10 risks, mitigation status, trigger-condition monitoring, escalation flags.

**Escalation Path:** Funding variances above EUR 50M, conformance failures affecting entire tiers, carrier non-participation affecting corridor connectivity, or delays to Month 18/30/48/60 (2028-04-12, 2029-04-12, 2030-10-12, 2031-10-12) milestones escalate to the Steering Committee within two business days. Regulatory or competition-law blockers escalate to the Steering Committee's legal-escalation path (DG COMP, passenger-rights review). Unresolved carrier or distributor disputes escalate to the Steering Committee after 30 days. Budget variances reaching thresholds (EUR 100M, EUR 200M, EUR 300M) trigger automatic escalation to the Committee and a published variance-mitigation plan within ten business days.
### 3. Compliance, Competition Law and Passenger Rights Committee (CCPR)

**Rationale for Inclusion:** This is a regulation-aligned public infrastructure programme operating at the intersection of EU transport regulation (Digital Booking and Ticketing Regulation, passenger-rights regulation 1371/2007), competition law (Article 101 TFEU, data-sharing and clearing arrangements) and accessibility law (Regulation 1371/2007, EU Accessibility Directive). The programme creates several competition-law exposures: shared data exchange through a clearing layer, potential rate-fixing on commissions, and exclusive access to real-time inventory could trigger Article 101 scrutiny. Passenger-rights continuity across carriers, liability allocation, and assistance/bicycle-reservation guarantees must comply with existing law. Accessibility for persons with reduced mobility is a legal requirement with reputational and liability risk. A dedicated specialized body ensures systematic compliance monitoring, early escalation of legal risks, and documented due diligence that protects both the programme and participating carriers. This committee reports to the Steering Committee and the Commission's legal services.

**Responsibilities:**

- Secure and maintain DG COMP Article 101 guidance: manage pre-notification to DG COMP at Month 2 (2026-12-12), obtain formal guidance letter by Month 12 (2027-10-12), establish clean-team protocol for the clearing function by Month 14 (2027-12-12), and publish a compliance certificate by Month 18 (2028-04-12) confirming that data-sharing and clearing arrangements are compatible with competition rules.
- Monitor and ensure passenger-rights compliance: commission independent legal review of the Through-Ticket Liability and Rights Backstop design against EU Regulation 1371/2007 by Month 1 (2026-11-12), obtain opinion by Month 6 (2027-04-12), approve a detailed compliance manual by Month 9 (2027-07-12) covering assistance, rerouting, compensation and refund procedures that meet or exceed existing passenger-rights protections.
- Oversee accessibility compliance: establish accessibility thresholds (wheelchair access on ≥80% of services, assistance within ≤4 hours' notice on ≥90% of services) as a precondition of conformance; conduct usability testing with persons with reduced mobility by Month 18 (2028-04-12); publish annual accessibility audit results; establish fallback procedures for carriers unable to meet thresholds.
- Manage data governance and GDPR compliance: establish rules for handling commercially sensitive data (fares, inventory, settlement flows) within the clearing and data-sharing layers; ensure the shared reconciliation platform and disruption event feed comply with GDPR; publish a data-governance policy by Month 6 (2027-04-12); conduct annual GDPR impact assessments.
- Monitor national regulatory alignment: conduct bilateral regulatory-impact assessments per member state by Month 3 (2027-01-12) to identify conflicts between the programme's design and national railway regulations; escalate conflicts to the Steering Committee and national regulators for resolution by Month 12 (2027-10-12) or defer that member state's participation.
- Oversee discrimination and fair-access monitoring: audit commission-rate data published by the clearing function monthly to detect discrimination between distributor types; investigate complaints from distributors claiming unfair access or pricing; publish a discrimination-monitoring report quarterly; escalate substantive discrimination findings to national regulators.
- Document and audit compliance: maintain a compliance register tracking Article 101 guidance, passenger-rights legal opinions, accessibility certifications, GDPR assessments and discrimination audits; publish a biennial external audit by the Court of Auditors or contracted firm; produce quarterly compliance reports to the Steering Committee.

**Initial Setup Actions:**

- Establish the Committee and appoint Chair (external legal expert with EU competition and transport-law experience) by Month 1 (2026-11-12).
- Commission independent legal reviews: (1) Article 101 TFEU compatibility of data-sharing and clearing by Month 1 (2026-11-12); (2) Passenger-rights compliance against Regulation 1371/2007 by Month 1 (2026-11-12); (3) GDPR and data-governance assessment by Month 2 (2026-12-12); (4) Accessibility and EU Accessibility Directive compliance by Month 2 (2026-12-12).
- File Article 101 pre-notification with DG COMP by Month 2 (2026-12-12); request guidance letter by Month 12 (2027-10-12).
- Publish the compliance roadmap and quarterly compliance reporting schedule by Month 3 (2027-01-12).
- Conduct bilateral regulatory-impact assessments per member state (25+ operators across 5-6 member states) by Month 3 (2027-01-12).
- Establish a discrimination-monitoring protocol and data-audit schedule by Month 6 (2027-04-12) to track commission-rate data from the clearing function.

**Membership:**

- Chair: External EU competition and transport-law expert (appointed by Month 1 = 2026-11-12), independent of DG MOVE and DG COMP
- Legal Counsel from DG MOVE
- Legal Counsel from DG COMP (observer seat)
- Head of Passenger-Rights Compliance (commissioned external specialist)
- Head of Data Governance and GDPR (Programme Office or external specialist)
- Representative from the EU Agency for Railways (regulatory liaison)
- Observer: BEUC (consumer representative) (non-voting)

**Decision Rights:** Authority to approve compliance certifications (Article 101 guidance letter, passenger-rights legal opinion, accessibility audit results, GDPR assessments) before they are released to the Steering Committee and public. Authority to issue compliance warnings to the Steering Committee if Article 101 guidance is not obtained by Month 12 (2027-10-12) or passenger-rights review is not approved by Month 9 (2027-07-12). Authority to block the release of any programme milestone (binding standards, API exposure, corridor go-live) if a material compliance gap is not addressed. Authority to recommend discrimination investigations and escalations to national regulators. Authority to recommend Member-State participation deferrals if regulatory conflicts cannot be resolved by Month 12 (2027-10-12). Decisions on compliance policy (thresholds, audit schedules, reporting formats) are made by simple majority; escalations to the Steering Committee require Committee approval.

**Decision Mechanism:** Consensus preferred on compliance certifications to ensure rigorous review; if consensus is not reached within 10 business days, the Chair (external legal expert) makes the decision and documents dissenting views. Compliance warnings and block decisions require Chair approval only, issued immediately to the Steering Committee. All formal compliance opinions (Article 101, passenger-rights, accessibility, GDPR) must be signed off by the Chair and at least one other member before publication.

**Meeting Cadence:** Monthly during Phase 1 (Months 1-18 = 2026-11-12 to 2028-04-12) to track Article 101 guidance, passenger-rights review and accessibility compliance; quarterly during Phase 2 (Months 18-48 = 2028-04-12 to 2030-10-12) to monitor discrimination audits and national-regulator alignment; biannually during Phase 3 (Months 48-60 = 2030-10-12 to 2031-10-12) for final compliance audit. Emergency sessions within three business days if a compliance gap blocks a milestone or a discrimination complaint is escalated.

**Typical Agenda Items:**

- Article 101 guidance letter status and clean-team protocol approval (Months 2-18 = 2026-12-12 to 2028-04-12).
- Passenger-rights legal review findings and compliance-manual approval (Months 1-9 = 2026-11-12 to 2027-07-12).
- Accessibility audit results and thresholds enforcement (ongoing from Month 6 = 2027-04-12).
- GDPR and data-governance compliance for clearing and disruption event feed.
- National regulator impact assessments and conflict resolution (Months 3-12 = 2027-01-12 to 2027-10-12).
- Quarterly discrimination audits: commission-rate data analysis by distributor type, complaint investigation results, escalations to regulators.
- Compliance register and audit tracking: biennial external audit status, quarterly reporting to Steering Committee.

**Escalation Path:** Unresolved compliance gaps or failed Article 101 guidance by Month 12 (2027-10-12) escalate to the Commission Transport Commissioner and DG COMP for resolution; if unresolved by Month 18 (2028-04-12), binding standards are deferred. Material discrimination findings or national-regulator conflicts unresolved by Month 12 (2027-10-12) escalate to the Steering Committee; the Committee decides whether to defer that Member State or require programme redesign. Any compliance gap that would block a Steering Committee milestone decision (binding standards, API exposure, corridor go-live) is escalated to the Committee with a recommended remediation plan within five business days. Passenger-rights gaps discovered post-deployment (after Month 30 = 2029-04-12) escalate immediately to the Commission and the EU Agency for Railways for emergency remediation and passenger notification.
### 4. Technical Standards and Interoperability Working Group (TSWG)

**Rationale for Inclusion:** The programme depends on binding technical standards (OSDM-compatible APIs, real-time data formats, clearing settlement feeds, ticket validation credentials) by Month 18 (2028-04-12) and mandatory API exposure by Month 30 (2029-04-12). The TSWG must own specification development, conformance test design, reference implementation, carrier-integration support and change-control governance. This is a specialized operational and advisory body that reports to the Operational Management Board and the Steering Committee. Unlike the Steering Committee (which makes binding strategic decisions on liability and clearing architectures), the TSWG makes technical decisions on how those architectures are specified, tested and evolved. Without a dedicated technical body with clear authority over standards and conformance, the programme risks specification drift, inconsistent testing, and missed binding-standards deadlines.

**Responsibilities:**

- Develop and publish the binding OSDM specification: establish a formal change-control process (critical: 2-week review, major: 6-week review, minor: 8-week review) and quarterly release cadence; anchor specification custodianship in the EU Agency for Railways with an escrowed open-source copy; pin the version via delegated or implementing act by Month 18 (2028-04-12).
- Design and operate conformance testing: develop test cases for OSDM API compliance, latency (p95 <2 seconds), availability (99.5%), stale-seat failures (<1%), booking-error rates; establish independent test laboratories; conduct conformance audits for all carriers by Months 24, 30, 36, 42 (2028-10-12, 2029-04-12, 2029-10-12, 2030-04-12); publish certification results on a public registry.
- Maintain and evolve the reference implementation: develop a reference OSDM implementation as a sandbox and technical benchmark; publish it under open-source terms; use it to validate carrier integrations and test distributor client implementations; make it available to carriers for testing by Month 12 (2027-10-12).
- Coordinate carrier-integration support: chair technical working sessions with carrier integration teams monthly; provide guidance on OSDM adoption, API design patterns, and legacy system adaptation; identify common adapter bottlenecks and escalate to the Programme Office for shared-adapter development.
- Define and enforce SLA thresholds: establish and publish SLA targets for API latency, availability, error rates, and settlement-reconciliation accuracy; monitor monthly SLA scorecards; recommend funding-tranche withholding for carriers missing SLAs for two consecutive months.
- Specify ticket validation and credential formats: define the API handshake, barcode, or cryptographic token format for cross-carrier ticket validation; coordinate with conductor handheld and station-gate system upgrades; ensure validation works offline and across all participating carriers by Month 40 (2030-02-12).
- Coordinate disruption and real-time data specs: develop specifications for the shared disruption event feed, availability shadow architecture, and settlement data formats; ensure all are compatible with carrier billing systems and independent distributor platforms.
- Support accessibility and bicycle-reservation integration: work with disability-rights bodies to specify assistance and bicycle-space reservation schemas; ensure these are auditable and cannot be bypassed; validate via usability testing by Month 18 (2028-04-12).

**Initial Setup Actions:**

- Establish the Working Group and appoint Chair (senior OSDM expert) by Month 1 (2026-11-12).
- Publish the formal OSDM change-control process and quarterly release schedule by Month 3 (2027-01-12).
- Develop conformance test cases for OSDM API, latency, availability, error rates by Month 6 (2027-04-12); release test environments to carriers by Month 12 (2027-10-12).
- Commission or develop a reference OSDM implementation (sandbox) by Month 9 (2027-07-12); publish under open-source licence by Month 12 (2027-10-12).
- Establish public conformance-certification registry by Month 12 (2027-10-12); publish first carrier audit results by Month 24 (2028-10-12).
- Coordinate with carrier integration teams to identify and resolve common technical bottlenecks by Month 12 (2027-10-12); recommend shared-adapter development for legacy systems by Month 3 (2027-01-12).

**Membership:**

- Chair: Senior OSDM or rail-API technical expert (appointed by Month 1 = 2026-11-12), from the Technical Secretariat or external contractor
- OSDM specification custodian (EU Agency for Railways or delegated external body)
- Head of Conformance Testing (independent test laboratory or Programme Office)
- Representative from carrier IT (rotating among Tier 1 carriers: DB, SNCF, SBB, ÖBB, Renfe)
- Representative from independent distributor IT (Trainline or Omio)
- Reference-implementation lead (open-source steward or Programme Office)
- Accessibility specialist (disability-rights body or accessibility consultant) (non-voting observer)
- EU Agency for Railways technical liaison (regulatory perspective)

**Decision Rights:** Authority to approve OSDM specifications and versions for binding-standards release by Month 18 (2028-04-12). Authority to set and enforce conformance test cases, SLA thresholds (latency, availability, error rates) and certification requirements. Authority to approve or reject carrier conformance certifications; recommend to the Steering Committee funding-tranche withholding for non-certified carriers. Authority to make technical decisions on specification content (e.g., which OSDM fields are mandatory, how settlement data is formatted) without Steering Committee approval, provided they align with strategic decisions already made (liability model, clearing architecture). Authority to approve change requests to the pinned OSDM specification post-Month 18 (2028-04-12) within the formal change-control process. Decisions on conformance test design, test-case severity, and certification remediation timelines are made by simple majority; SLA threshold changes require Steering Committee approval if they affect milestone or budget assumptions.

**Decision Mechanism:** Consensus preferred on technical specifications to ensure carrier and distributor buy-in; if consensus is not reached within 15 business days, the Chair makes the decision, with documented dissent and escalation to the Operational Management Board within five business days. Conformance certification decisions require unanimous sign-off by the Chair and the independent test-laboratory representative to ensure impartiality. SLA threshold decisions require Steering Committee approval if they change targets or enforcement mechanisms; routine monitoring and reporting are delegated to the Chair without approval.

**Meeting Cadence:** Weekly during Phase 1 (Months 1-18 = 2026-11-12 to 2028-04-12) to develop specifications and test cases; biweekly during Phase 2 (Months 18-48 = 2028-04-12 to 2030-10-12) to oversee conformance audits and carrier integrations; monthly during Phase 3 (Months 48-60 = 2030-10-12 to 2031-10-12) for post-go-live specification evolution. Emergency sessions within two business days if a conformance audit fails or a critical specification gap is discovered that affects binding-standards release.

**Typical Agenda Items:**

- OSDM specification drafting and change-request review (Months 1-18 = 2026-11-12 to 2028-04-12).
- Conformance test-case design and validation (Months 3-12 = 2027-01-12 to 2027-10-12).
- Carrier integration support: common bottlenecks, adapter guidance, legacy-system compatibility.
- SLA monitoring: monthly latency/availability/error-rate scorecards by carrier, remediation tracking.
- Reference implementation development and validation (Months 6-18 = 2027-04-12 to 2028-04-12).
- Accessibility and bicycle-reservation schema design and usability testing (Months 6-18 = 2027-04-12 to 2028-04-12).
- Disruption event feed and settlement data-format specifications.
- Ticket-validation credential design and cross-carrier acceptance testing (Months 12-40 = 2027-10-12 to 2030-02-12).

**Escalation Path:** Unresolved specification disputes (e.g., carrier disagreement on a mandatory OSDM field) that block progress toward Month 18 (2028-04-12) escalate to the Operational Management Board within ten business days; if unresolved by the OMB, they escalate to the Steering Committee for binding decision. Conformance failures affecting ≥5 carriers or ≥1 Tier 1 corridor-critical carrier escalate to the Operational Management Board for remediation planning; if a carrier cannot remediate by their tier deadline (Month 30/36/42 = 2029-04-12, 2029-10-12, 2030-04-12), the OMB recommends deferral of that carrier to a later tier or programme phase. Specification changes post-Month 18 (2028-04-12) that affect binding-standards commitments or require carrier rework escalate to the Steering Committee for approval. SLA threshold violations affecting >20% of carriers or delaying corridor go-live escalate to the OMB and Steering Committee within five business days.