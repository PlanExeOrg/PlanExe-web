### 1. Programme Steering Committee

**Rationale for Inclusion:** This €1.5 billion, five-year, multi-stakeholder EU programme requires strategic oversight across 27 member states, 25+ carriers, and multiple regulatory domains (rail, payment, competition, GDPR). The Steering Committee provides high-level direction on standards priorities, corridor sequencing, funding allocation disputes, and milestone enforcement. It is the ultimate decision-making body for choices that cannot be resolved at operational level and ensures political and institutional alignment with DG MOVE and the Commission.

**Responsibilities:**

- Approve binding standards (Month 18 = 2028-04-08) and API mandate enforcement thresholds (Month 30 = 2029-04-08)
- Allocate and approve deviations from the EUR 1,500 million budget and trigger contingency tiers
- Resolve escalated technical disputes and policy conflicts between carriers, distributors, regulators and member states
- Approve corridor sequencing gates and readiness thresholds (proposed: 90% of traffic bookable end-to-end)
- Monitor milestone adherence and make formal decisions on timeline adjustments or deferrals
- Oversee through-ticket target progress and authorize mid-course strategic pivots

**Initial Setup Actions:**

- Draft and sign a Memorandum of Understanding defining Steering Committee authority, decision rules and escalation triggers (Month 1 = 2026-11-08)
- Elect a steering committee chair and establish a quarterly meeting schedule (Month 1 = 2026-11-08)
- Define binding decision thresholds (e.g., budget deviations >EUR 50M require SC approval; technical rulings >60 days trigger escalation)
- Establish a formal conflict-resolution process for Steering Committee disputes (majority vote with tie-breaker role specified)
- Secure written Council/Commission delegation of final authority over binding standards and milestone enforcement (Month 2 = 2026-12-08)

**Membership:**

- DG MOVE representative (chair or co-chair)
- EU Agency for Railways representative (technical lead)
- Programme director (operations lead)
- Three to four major-carrier representatives (rotating annually; e.g., Deutsche Bahn, SNCF, Trenitalia, ÖBB)
- One SME/smaller-carrier representative (elected by CER members)
- One distributor representative (Trainline, Omio, or public reference distributor; rotating)
- One national regulator representative (elected by Standing Regulators Committee)
- One BEUC or disability-rights representative

**Decision Rights:** Binding authority over standards approval (Months 18 baseline + amendments through Month 30 = 2029-04-08), corridor gates and readiness thresholds, funding allocations above EUR 50 million, milestone deferrals >4 weeks, and escalated technical/commercial disputes. Authority is limited to strategic-level decisions; operational execution (daily carrier onboarding, individual API compliance checks) remains with the PMO and working groups.

**Decision Mechanism:** Quarterly in-person meeting (120 minutes, Brussels) with written agenda and consent agenda for routine approvals. Major decisions require consensus or, if unattainable after 2 weeks of negotiation, a supermajority vote (2/3 of voting members, excluding the chair). Tie-breaker: if votes are evenly split, the chair (DG MOVE) casts the deciding vote. Escalated disputes from working groups are tabled and decided within 4 weeks; if a decision cannot be reached, the issue is escalated to the Commission with a minority-position record.

**Meeting Cadence:** Quarterly (Months 3, 6, 9, 12, 15 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08, 2028-01-08... starting Month 3 = 2027-01-08). Emergency meetings may be convened within 5 working days if a milestone-threatening issue arises (e.g., major carrier non-compliance, budget overrun exceeding Tier 2 threshold, or legal challenge). Written decisions on routine items (budget approvals within threshold, minor timeline adjustments) may be made by written consent between meetings.

**Typical Agenda Items:**

- Progress report on the critical path: standards finalisation, carrier integration, hub readiness, API performance metrics
- Monthly spend report and budget variance analysis; triggering of contingency tiers if needed
- Escalated disputes from working groups or the arbitration panel (technical or governance conflicts)
- Milestone gate reviews (e.g., Month 18 = 2028-04-08 standards approval, Month 30 = 2029-04-08 API readiness assessment)
- Corridor sequencing decisions and readiness-gate outcomes
- Stakeholder engagement and political risk updates

**Escalation Path:** Unresolved Steering Committee disputes escalate to the Commission (DG MOVE, DG COMP if competition concerns are present) for binding decision within 2 weeks. If the Commission cannot decide, the issue is referred to the Council or European Parliament TRAN committee for legislative or policy guidance (estimated escalation cycle: 3–4 weeks). For non-consensus decisions where voting results in 2/3 supermajority, the dissenting minority may request a written Commission review within 10 days.
### 2. Programme Management Office (PMO) and Core Project Team

**Rationale for Inclusion:** Day-to-day execution of a EUR 1,500 million, five-year programme spanning 27 member states and 25+ carriers requires a dedicated, professionally staffed operational hub. The PMO manages carrier onboarding, standards development workstreams, budget tracking, risk escalation and milestone delivery. It is the operational nerve centre that bridges strategic direction from the Steering Committee with execution by technical working groups and external partners.

**Responsibilities:**

- Manage the critical path and monthly milestone tracking; flag slippage >2 weeks within 5 working days
- Oversee standards working groups and ensure consensus on OSDM, data-layer design, clearing and settlement rules, and ticket formats by Month 18 (2028-04-08)
- Coordinate carrier onboarding workflow: assess readiness, allocate co-funding tranches tied to milestones, and track progress toward Month 30 (2029-04-08) API mandate
- Manage the budget and spend tracking; alert the Steering Committee when monthly burn rates exceed plan or when contingency usage is needed
- Coordinate accreditation of payment institutions, hub operators and distributors; maintain a conformance dashboard
- Operate and escalate the risk-management process: identify new risks monthly, track mitigation actions and escalate unmitigated risks to the Steering Committee
- Manage the quarterly measurement and evaluation process; produce the public dashboard of progress metrics

**Initial Setup Actions:**

- Recruit 10–15 core PMO staff (director, deputy, standards lead, technical architect, budget officer, comms lead, risk officer) by Month 2 (2026-12-08)
- Establish a shared project-management tool (e.g., Asana, Monday.com) with visibility to all stakeholders, updated weekly with status, red flags and decisions (Month 1 = 2026-11-08)
- Define PMO operating procedures: decision authority, escalation triggers, meeting schedules for working groups and carrier engagement (Month 1 = 2026-11-08)
- Secure an office in Brussels with meeting facilities and colocation for the core team (Month 1 = 2026-11-08)
- Publish the project charter and kick-off communication to all stakeholders (Month 1 = 2026-11-08)

**Membership:**

- Programme Director (1 FTE, overall accountability)
- Deputy Director / Operations Lead (1 FTE)
- Standards and Technical Lead (1 FTE, OSDM/data-layer architecture)
- Budget and Finance Officer (1 FTE)
- Carrier Onboarding and Conformance Lead (1 FTE)
- Governance and Risk Officer (1 FTE)
- Communication and Stakeholder Lead (1 FTE)
- Data Protection and Legal Specialist (0.5 FTE, GDPR, competition law)
- Evaluation and Measurement Lead (1 FTE)
- Hub and Gateway Coordination (1 FTE)
- Administrative support (2 FTE)

**Decision Rights:** Operational decisions within the PMO's authority: carrier onboarding approvals (subject to co-funding thresholds), weekly working-group facilitation, escalation to the Steering Committee or arbitration panel, risk flag and mitigation tracking, and monthly dashboard publication. The PMO does not have authority to approve major strategy changes, override arbitration panel rulings, or commit budget above EUR 10 million per item; these escalate to the Steering Committee.

**Decision Mechanism:** Daily stand-up (15 min) among PMO leadership; weekly PMO all-hands meeting (60 min) to review status and risks; working-group leads report to the PMO on Wednesday each week with highlight updates (by 14:00 Brussels time) so the PMO can flag issues by EOD. Operational decisions are made by the PMO Director in consultation with relevant leads (e.g., budget decisions with the Finance Officer); decisions affecting the critical path or involving disputes between two stakeholders are escalated to the Steering Committee or arbitration panel within 5 working days.

**Meeting Cadence:** Weekly PMO all-hands and governance review (Thursdays, 10:00–11:00 Brussels time); working-group leads submit written status by Wednesday EOD each week. Monthly PMO deep-dive (last Thursday of each month) reviewing budget, risk, milestone and stakeholder updates. Quarterly reporting to the Steering Committee (aligned with SC meeting calendar). Emergency escalation protocol: any issue that threatens a hard milestone is flagged immediately to the Programme Director and escalated within 24 hours.

**Typical Agenda Items:**

- Milestone tracking: standards workstream progress, carrier integration readiness by corridor, API performance metrics, hub operational status
- Budget and spend tracking: monthly burn rate vs. forecast, contingency-tier triggers, co-funding pipeline
- Carrier onboarding: new carriers requesting integration, co-funding approvals, conformance testing queue
- Risk and issues: new risks identified, mitigation tracking, escalations to Steering Committee or arbitration panel
- Working-group updates: OSDM, data-layer design, clearing/settlement, consumer app, accessibility, regulator capacity building
- Stakeholder engagement: political tracking (Regulation adoption, member-state support), media/reputational issues

**Escalation Path:** Operational issues escalate from working groups to the PMO (48 hours to triage); if unresolved within 1 week, escalate to the arbitration panel (if technical) or Steering Committee (if strategic/budget). Issues requiring inter-member-state coordination escalate to the Standing Regulators Committee or, if involving non-EU partners (Switzerland), to DG MOVE's international affairs team. Issues involving competition-law concerns escalate immediately to DG COMP with a formal request for guidance.
### 3. Technical Standards and Conformance Working Group

**Rationale for Inclusion:** The binding standards (Month 18 = 2028-04-08 deadline) define OSDM-compatible APIs, data-layer architecture, clearing and settlement message formats, ticket formats, passenger-rights rules, accessibility requirements and GDPR compliance boundaries. This working group must deliver consensus-based standards that carriers, distributors, payment institutions and regulators all accept as feasible and enforceable. It is the technical engine of the programme.

**Responsibilities:**

- Define and publish the binding standards document covering OSDM API specifications, data-layer query interfaces, clearing message standards, through-ticket definition, refund and rerouting procedures, accessibility requirements and GDPR/compliance rules
- Conduct iterative technical consultation with carriers, distributors, payment institutions and regulator representatives; manage disputes through working-group consensus or escalation to arbitration panel
- Establish conformance-testing criteria and oversee procurement of independent testing laboratories by Month 3 (2027-01-08)
- Publish conformance checklist and audit procedures for carriers and distributors; manage quarterly conformance reviews
- Advise the Steering Committee on technical feasibility of proposed milestone dates and corridor sequencing; flag readiness risks

**Initial Setup Actions:**

- Establish sub-working groups by Month 2 (2026-12-08): OSDM/API design, data-layer architecture, clearing/settlement, ticket format, passenger rights/accessibility, GDPR compliance
- Conduct a gap analysis (Month 2–3 = 2026-12-08 to 2027-01-08) comparing the Regulation's assumed framework to the Commission's proposal; flag divergences and propose resolutions
- Begin 'shadow standards' pre-work (Month 0–3 = 2026-10-08 to 2027-01-08) on technical issues that do not depend on final Regulation text (e.g., OSDM API latency targets, data-minimisation rules)
- Establish a technical dispute-resolution process: if two sub-groups cannot agree on an issue by Month 12 (2027-10-08), escalate to the arbitration panel for binding ruling
- Publish a draft standards document by Month 12 (2027-10-08) for public consultation; collect feedback by Month 15 (2028-01-08) and incorporate before final approval

**Membership:**

- Chair: Standards Lead from the PMO (1 FTE equivalent)
- OSDM sub-group: 2–3 OSDM experts (external), 2–3 carrier IT leads, 1 distributor technical representative
- Data-Layer sub-group: 1–2 data-architecture specialists, 1 carrier operations lead, 1 EU Agency for Railways representative
- Clearing/Settlement sub-group: 1 payment-systems architect, 1 carrier finance lead, 1 distributor lead, 1 legal/compliance representative
- Ticket Format sub-group: 1 ticket-system expert, 2 carrier representatives, 1 validator-device manufacturer representative
- Passenger Rights/Accessibility sub-group: 1 legal specialist (passenger rights), 1 accessibility expert, 1 carrier operations representative, 1 BEUC/disability-rights representative
- GDPR/Compliance sub-group: 1 DPA specialist, 1 competition-law representative, 1 carrier privacy officer, 1 data-protection specialist

**Decision Rights:** The working group develops consensus standards for Steering Committee approval (Month 18 = 2028-04-08 deadline). Sub-groups can agree on technical specifications within their scope; if consensus is not achievable within a sub-group, the issue escalates to the full working group (2-week resolution target) or to the arbitration panel if still unresolved. The working group has no authority to override regulatory requirements or change the binding-standards deadline; it operates within the constraints set by the Regulation and the Steering Committee.

**Decision Mechanism:** Monthly full working-group meeting (120 min, Brussels or hybrid) with consensus-based decision-making. Each sub-group meets bi-weekly (60 min, hybrid). Technical disputes within a sub-group are escalated to the full working group with a position paper from each side; the full group attempts consensus within 2 weeks. If consensus fails, the arbitration panel is asked for a binding ruling within 60 days. Major technical decisions (e.g., federated vs. central data layer) are made by the full group with supermajority (2/3) consensus if needed.

**Meeting Cadence:** Monthly full working-group meetings (2nd Tuesday of each month, 14:00–16:00 Brussels time); bi-weekly sub-group meetings (staggered schedule so no carrier or distributor is in back-to-back meetings). Emergency technical deep-dives scheduled ad hoc if a dispute arises.

**Typical Agenda Items:**

- OSDM API specification: latency SLAs, throughput targets, error handling, backward compatibility
- Data-layer architecture: federated query performance, central cache design, disruption-event streaming, data-quality rules
- Clearing message standards: revenue apportionment algorithms, settlement cycle, dispute-resolution procedures
- Ticket format and validation: barcode vs. digital wallet, offline vs. online verification, GDPR data minimisation
- Passenger rights and accessibility: assistance confirmation timelines, rerouting procedures, accessibility data requirements
- GDPR and competition law: data-sharing safeguards, Standard Contractual Clauses, confidentiality rules

**Escalation Path:** Unresolved technical disputes escalate from sub-groups to the full working group (2-week deadline); if still unresolved, escalate to the arbitration panel for binding ruling within 60 days. If the arbitration panel ruling is contested (e.g., a major carrier claims it is technically infeasible), the issue escalates to the Steering Committee for a policy decision. Major standards conflicts that cannot be resolved technically (e.g., conflict between GDPR minimisation and detailed disruption reporting) escalate to the Commission for guidance.
### 4. Independent Arbitration Panel for Technical Disputes

**Rationale for Inclusion:** The programme's critical path depends on resolving contested technical decisions (e.g., inventory-parity thresholds, API latency SLAs, settlement message formats) quickly and with binding force. The lightweight arbitration panel avoids the 12–18 month legal setup of a joint undertaking while providing clear, time-boxed dispute resolution. It is essential for keeping standards-setting on track and preventing re-litigation of settled technical issues.

**Responsibilities:**

- Receive escalated technical disputes from working groups or the Steering Committee and conduct independent technical review
- Issue binding rulings on contested technical standards, conformance criteria and SLAs within 60 days of receiving a dispute
- Publish reasoned rulings explaining the technical rationale, evidence considered and any dissenting panel-member positions
- Track compliance with rulings: carriers and entities have 14 days to confirm adoption or request escalation to the Commission
- Provide advisory guidance (non-binding) on emerging technical issues raised by working groups or the PMO

**Initial Setup Actions:**

- Secure written Council/Commission delegation of binding authority by Month 2 (2026-12-08); delegation must specify decision scope (technical standards only, not commercial terms), time limits (60 days to ruling, 14 days to comply) and escalation procedures
- Recruit and appoint 8–12 panel members (Month 1–2 = 2026-11-08 to 2026-12-08): 2–3 OSDM or rail-IT experts, 1–2 data-architecture specialists, 1 payment-systems expert, 1 accessibility expert, 1 legal/compliance specialist, 1–2 independent arbitrators (no carrier/distributor affiliation), and 1 panel secretary (0.5 FTE)
- Establish panel governance: term of office (3–5 years), conflict-of-interest rules (panel members cannot advise carriers or distributors during their tenure), and a tie-breaking or consensus protocol
- Define the dispute-submission process: working groups or Steering Committee submit a written dispute with positions from all parties (limit 5 pages per position); panel has 10 days to declare the dispute admissible
- Publish panel operating procedures and communication protocols by Month 1 (2026-11-08)

**Membership:**

- Panel Chair (1, independent expert, e.g., from an external neutral institution like the EU Agency for Railways or an academic)
- OSDM/API specialists (2–3, external; rotational participation in disputes to avoid bias)
- Data-architecture expert (1, external)
- Payment-systems expert (1, external; may be a payment-institution representative with firewall rules to prevent conflicts)
- Accessibility expert (1, external; e.g., from a disability-rights organisation or accessibility standards body)
- Legal/competition specialist (1, external; for GDPR and antitrust questions)
- Transport regulation specialist (1, may be from the EU Agency for Railways with appropriate independence)
- Panel Secretary (0.5–1 FTE, employed by the programme to manage scheduling, documentation and publication)

**Decision Rights:** Binding authority over technical standards disputes: API latency SLAs, throughput requirements, data-layer architecture choices, message-format specifications, conformance-testing criteria, and allocation of technical liability (e.g., who is responsible for mapping errors in a hub). Authority is limited to technical feasibility and standards alignment; the panel cannot override the Regulation's requirements, approve budget deviations or make commercial decisions (e.g., carrier pricing, fee caps). If a dispute involves both technical and commercial elements (e.g., whether an access term is non-discriminatory), the panel issues a technical ruling and escalates the commercial implications to the Steering Committee.

**Decision Mechanism:** When a dispute is received, the panel's chair convenes a panel roster (5–7 members) with expertise relevant to the dispute. Panel members review written submissions from all parties (5 pages each, plus exhibits). The panel conducts a technical review (10–20 days), may request clarifications from parties (3-day response window) and holds a closed deliberation meeting (day 30–40). The panel issues a written ruling (day 60) with findings, technical rationale and the decision. If panel members disagree, dissenting opinions are published alongside the majority ruling. Tie-breaking: if the panel is evenly split (rare, given odd roster size), the chair casts a deciding vote.

**Meeting Cadence:** Panel roster convenes within 5 working days of a dispute being declared admissible. Panel deliberations are internal (not public). Rulings are published within 5 working days of issuance (day 65 of the cycle). The full panel meets quarterly for governance and to review emerging technical issues; panels for individual disputes meet as needed (estimated 1–3 disputes per quarter during the standards-development phase = Months 4–18 = 2027-02-08 to 2028-04-08).

**Typical Agenda Items:**

- Escalated dispute submissions: technical positions from all parties, feasibility assessments
- Deliberation on the dispute: technical evidence, regulatory constraints, impact on critical path
- Drafting of the ruling and resolution of any dissents
- Quarterly review of panel operations: caseload, decision quality, emerging patterns in disputes

**Escalation Path:** If a party (e.g., a major carrier) contests a panel ruling and claims it is technically infeasible or conflicts with national law, the party may request escalation to the Commission within 10 days of the ruling. The Commission has 14 days to affirm or overturn the ruling (this is rare and only for exceptional cases). If the Commission affirms the ruling and a carrier still refuses to comply, the issue escalates to DG MOVE for enforcement action (co-funding holds, public-channel bypass, or regulatory escalation). For disputes involving competition-law or GDPR questions, the panel's ruling is immediately referred to DG COMP or the EDPB for concurrence; if those bodies disagree, the matter escalates to the Steering Committee and Commission for a final decision.
### 5. Member-State Regulator Coordination Committee and Capacity Building Programme

**Rationale for Inclusion:** National rail regulators across 27 member states must enforce access, refund and accessibility duties consistently for through-tickets to be credible and non-discriminatory. However, regulators vary widely in resources, expertise and enforcement traditions. A dedicated coordination committee and capacity-building programme ensure consistent enforcement, cross-border dispute resolution and alignment with the programme's access-term rules. This is essential for the non-discrimination goal and for the credibility of the Month 30 (2029-04-08) API mandate.

**Responsibilities:**

- Harmonise enforcement procedures across member states for access terms, passenger rights and accessibility compliance; publish common inspection checklists and audit standards by Month 12 (2027-10-08)
- Establish a lead-authority mechanism for cross-border disputes: when a distributor complains that a carrier in another member state is denying API access, designate one national regulator as the lead, with other member states recognising its decision
- Provide capacity building and twinning partnerships for weaker regulators: training on access-enforcement, data-quality auditing, complaint handling and cross-border coordination
- Operate a Standing Regulators Committee (quarterly) to review enforcement outcomes, escalate systemic issues to the Commission, and update procedures
- Track and report on compliance metrics: access-complaint resolution times, non-discrimination audit findings, and consistency of passenger-rights enforcement across member states

**Initial Setup Actions:**

- Conduct a regulator capacity audit in Month 1–2 (2026-11-08 to 2026-12-08) identifying staff, budget and enforcement expertise gaps in each member state
- Establish the Standing Regulators Committee and elect a chair (preferably from a strong-capacity regulator, e.g., Germany, Netherlands, France) by Month 1 (2026-11-08)
- Define a lead-authority framework (Month 2–3 = 2026-12-08 to 2027-01-08): specify which member state's regulator leads for disputes involving carriers in that state; establish mutual recognition of lead-authority decisions
- Fund bilateral twinning partnerships (Month 2–6 = 2026-12-08 to 2027-04-08): pair weak-capacity regulators with strong ones; provide training budgets (EUR 0.5–1M per partnership over 3 years)
- Develop common inspection checklists and audit procedures for access compliance by Month 6 (2027-04-08); publish a regulator toolkit for smaller member states

**Membership:**

- Chair: Head of a major national regulator (e.g., Germany, France, Netherlands, Austria), elected for a 2-year term
- Deputy Chair: Head of a regulator from a smaller or weaker-capacity member state (rotating)
- 27 member-state regulator representatives (one per member state; may be director or deputy director level)
- EU Agency for Railways representative (ex-officio, advisory role on cross-border coordination)
- Programme Director or Deputy (PMO observer, for coordination with programme timelines)
- Technical secretariat: 1 FTE (hosted by the EU Agency for Railways or a volunteering member-state regulator), managing meeting schedules, documentation and capacity-building coordination

**Decision Rights:** Recommends (not binding, absent escalation) common enforcement procedures, regulator training curricula, and audit standards to the Steering Committee. Binding authority: lead-authority decisions on cross-border disputes are final and recognised by all member states (absent Commission override). The committee can escalate systemic enforcement failures (e.g., a member state consistently failing to investigate non-discrimination complaints) to the Commission for investigation and enforcement action. The committee cannot override national regulations or force a regulator to act beyond its legal powers.

**Decision Mechanism:** Quarterly meeting (120 min) with supermajority consensus (2/3 of voting members) on enforcement standards and procedures. Lead-authority decisions on individual cross-border disputes are made by the lead regulator (as designated in the framework) within 30 days; other member-state regulators have 5 days to file a dissent with the committee chair, who then refers the matter to the Standing Regulators Committee for review. If 2+ member states dispute the lead decision, escalate to the EU Agency for Railways or Commission for mediation (14-day resolution target).

**Meeting Cadence:** Quarterly in-person or hybrid meetings (typically aligned with Steering Committee calendar, with 1 week separation). Emergency virtual meetings can be convened within 2 working days if a cross-border dispute requires urgent resolution. Monthly calls (30 min) among the chair, deputy chair, PMO and the EU Agency for Railways to track emerging issues.

**Typical Agenda Items:**

- Enforcement review: number and type of access-discrimination complaints received and resolved; average resolution time per member state
- Cross-border disputes: updates on lead-authority investigations, recognition of decisions, and escalations
- Regulator capacity: twinning partnership progress, training attendance, resource gaps
- Systemic issues: patterns of non-compliance by carriers in particular member states, need for procedural updates
- Coordination with the programme: critical-path tracking, milestone readiness, impact of enforcement on corridor gates

**Escalation Path:** Member-state enforcement failures escalate from the Standing Regulators Committee to the Commission (DG MOVE) for investigation and potential enforcement action under Article 258 TFEU (infringement proceedings). Cross-border disputes that the lead regulator cannot resolve escalate to the EU Agency for Railways for mediation (14-day resolution target); if still unresolved, escalate to DG MOVE for a binding decision. If a member state refuses to recognise a lead-authority decision, the issue escalates to the Commission and potentially to CJEU (Court of Justice of the European Union) for ruling on mutual-recognition obligations.
### 6. Consumer Product and Support Team

**Rationale for Inclusion:** The programme's success depends on passenger uptake of through-tickets via the public reference distributor (and complementary commercial platforms). A dedicated consumer product team builds the multilingual booking app, ensures user experience quality, and operates a 24/7 support centre for passenger complaints and accessibility requests. This team is responsible for the consumer-facing brand and credibility of the through-ticketing system, directly supporting the 40% through-ticket target.

**Responsibilities:**

- Design and build a multilingual EU through-ticketing booking app (launch Month 15 = 2028-01-08; four-corridor rollout by Month 27 = 2029-01-08)
- Implement real-time search, booking and refund flows; integrate accessibility request and confirmation; display through-ticket continuity-of-journey promises and refund guarantees
- Operate a 24/7 multilingual customer support centre (launch Month 15 = 2028-01-08): handle booking errors, refund claims, accessibility requests, and complaints in 24+ languages; target <1-hour response for critical issues
- Monitor app performance, user satisfaction and complaint trends; iterate the app design quarterly based on user feedback and A/B testing
- Coordinate with carriers, distributors and payment institutions to resolve passenger-escalated technical issues (e.g., booking failed at confirmation, refund not received)
- Produce quarterly public reports on customer satisfaction, complaint types, accessibility-assisted bookings and support-queue metrics

**Initial Setup Actions:**

- Recruit the consumer product team (20–30 FTE) by Month 1 (2026-11-08): product manager, engineering lead, UX/design leads, backend engineers, localization specialists, and support-centre manager
- Conduct user research and persona development (Month 2–4 = 2026-12-08 to 2027-02-08); wireframe core flows (search, booking, refund, accessibility request)
- Build an MVP (minimum viable product) for pilot testing on one corridor (Month 5–8 = 2027-03-08 to 2027-06-08); deploy to 100–500 test users
- Iterate based on pilot feedback (Month 9–12 = 2027-07-08 to 2027-10-08); conduct UX refinement and accessibility testing (WCAG 2.1 AA compliance)
- Begin full-scale development and localization in Month 12 (2027-10-08); target production-ready by Month 15 (2028-01-08)
- Establish the support centre infrastructure (call centre, email ticketing, knowledge base, escalation procedures) by Month 14 (2027-12-08)

**Membership:**

- Consumer Product Director (1 FTE, accountability for app and brand)
- Product Manager (1 FTE, feature prioritization and roadmap)
- Engineering Lead (1 FTE, technical architecture and delivery)
- Backend Engineers (3–4 FTE, API integration, data handling)
- Frontend/UX Engineers (2–3 FTE, user interface, accessibility)
- Localization and Content Manager (1 FTE, multilingual support, legal disclaimers)
- Support Centre Manager (1 FTE, team leadership, quality assurance)
- Support Agents (4–6 FTE initially, scaling to 10–15 FTE by Month 24 = 2028-10-08, covering 24/7 coverage in 24+ languages via subcontractors for non-major languages)
- Data Analyst (0.5 FTE, monitoring satisfaction metrics, complaint patterns)

**Decision Rights:** Operational decisions: app feature prioritization, support procedures, multilingual content, and technology stack choices. The team does not have authority to commit budget above EUR 2 million per item (e.g., major infrastructure upgrades), change through-ticket definition or refund policies (set by the Steering Committee), or commit carrier/distributor integration timelines (negotiated with the PMO). User experience decisions and support procedures are made by the team with input from carriers, distributors and passenger advisory representatives.

**Decision Mechanism:** Weekly product prioritization meeting (60 min): product manager, engineering lead and UX lead discuss incoming requirements (from carriers, distributors, support tickets) and update the feature roadmap. Support centre manager and quality-assurance lead review complaint trends and procedural issues in a weekly meeting (30 min). Major decisions (e.g., whether to pivot from a native app to a web-based offering, or whether to integrate a partner payment processor) escalate to the Steering Committee or PMO for approval.

**Meeting Cadence:** Weekly product team meetings (Monday, 10:00–11:00 Brussels time); weekly support-centre operational meeting (Friday, 10:00–10:30); biweekly full team sync (first and third Thursday of each month, 14:00–15:30). Monthly retrospective and planning session (last Friday of each month, 13:00–15:00) reviewing metrics and upcoming iterations.

**Typical Agenda Items:**

- App development progress: feature completion, bug tracking, performance metrics (latency, crash rates, search success rate)
- User satisfaction and feedback: app-store reviews, NPS (Net Promoter Score), user-research findings, accessibility feedback
- Support centre operations: complaint volume by category (booking errors, refund delays, accessibility, technical issues), average resolution time, escalations to carriers or payment institutions
- Multilingual content and localization: translation quality reviews, cultural adaptation for different EU markets
- Integration with carriers, distributors and payment systems: API changes, new data feeds, coordination on messaging to passengers

**Escalation Path:** Technical issues that require carrier or payment-institution intervention escalate from support tickets to the PMO (via the support-centre manager) with a severity rating (critical: <2-hour resolution target; high: <24-hour; medium: <5 days). PMO coordinates carrier/distributor response. If a support issue reveals a systemic problem (e.g., >100 complaints per week about failed refunds), escalate to the Steering Committee for investigation and corrective action. Accessibility issues escalate immediately to the Accessibility Working Group and to BEUC/disability-rights representatives for guidance.
### 7. Ethics, Compliance and Accessibility Oversight Committee

**Rationale for Inclusion:** The programme involves sensitive areas: passenger data (PII, accessibility information, payment details), access-to-essential-transport (persons with reduced mobility), and fair competition among carriers and distributors. A dedicated ethics and compliance committee ensures adherence to GDPR, accessibility standards, disability-rights principles and anti-corruption rules. It provides independent assurance that the programme's governance and operations are credible and inclusive.

**Responsibilities:**

- Oversee GDPR compliance across all programme entities: commissioning and reviewing the DPIA (Months 0–2 = 2026-10-08 to 2026-12-08), securing EDPB/DPA consensus on data-flow safeguards by Month 4 (2027-02-08), and conducting quarterly compliance audits on data-handling practices (starting Month 18 = 2028-04-08)
- Monitor accessibility compliance: ensuring that booking systems, assistance request/confirmation flows and accessibility data meet WCAG 2.1 AA and EU accessibility directives; conducting quarterly accessibility audits of the public app and carrier systems
- Establish and enforce ethics guidelines for programme staff, carrier and distributor representatives, and regulator participants: conflict-of-interest rules, anti-corruption provisions, whistleblower protections
- Oversee passenger-data handling: review data-sharing agreements among carriers, distributors, payment institutions and the clearing mechanism; ensure data minimisation and consent compliance
- Review and approve compliance scorecards for carriers and distributors; report quarterly to the Steering Committee on ethics and compliance status

**Initial Setup Actions:**

- Recruit committee members and establish terms of office (Month 0–1 = 2026-10-08 to 2026-11-08); ensure membership includes external, independent ethics and accessibility experts with no conflicts of interest
- Commission the DPIA and request EDPB consultation (Month 0–2 = 2026-10-08 to 2026-12-08); establish a timeline for DPA consensus by Month 4 (2027-02-08)
- Draft an ethics code and conflict-of-interest policy (Month 1 = 2026-11-08); require all programme staff, carriers and distributors to sign by Month 2 (2026-12-08)
- Establish accessibility requirements and conformance checklist (Month 2–4 = 2026-12-08 to 2027-02-08) aligned with the Accessibility Working Group; define audit procedures
- Create a confidential whistleblower channel (Month 1 = 2026-11-08); communicate it to all stakeholders and protect reporters from retaliation

**Membership:**

- Chair: Independent ethics or compliance expert (external, e.g., from an EU ethics body or academic institution); 3-year term
- Deputy Chair: Independent accessibility expert (external, e.g., from a disability-rights organisation); 3-year term
- GDPR/Data Protection Specialist (external, e.g., from a DPA or data-protection consultancy)
- Accessibility and Inclusive Design Expert (external, e.g., from an accessibility standards organisation)
- Ethics and Compliance Officer (programme staff, 1 FTE, working closely with the committee)
- Finance and Audit Representative (external, independent auditor or audit firm, rotating 2-year terms)
- Passenger Advocacy Representative (e.g., from BEUC or a consumer-protection body)

**Decision Rights:** Advisory authority: the committee makes recommendations to the Steering Committee on GDPR compliance, accessibility standards and ethics enforcement. Binding authority (in consultation with DG MOVE): suspension of a carrier's or distributor's participation in the programme if serious GDPR or ethics violations are found (e.g., mishandling of passenger data, corruption). The committee cannot override the Regulation or change the programme's core objectives; it operates within the legal and policy framework set by the Commission and Steering Committee.

**Decision Mechanism:** Quarterly full committee meeting (120 min, in-person or hybrid). Consensus-based decision-making; if a member dissents on a recommendation to the Steering Committee, the dissent is documented and both positions are submitted to the SC. Emergency meetings (within 5 working days) may be convened if a critical ethics or compliance issue is discovered (e.g., evidence of corruption or a major data breach).

**Meeting Cadence:** Quarterly formal meetings (aligned with Steering Committee calendar); monthly virtual calls (30 min) among the chair, deputy chair and the ethics/compliance officer to review emerging issues. Ad-hoc meetings if urgent escalations arise.

**Typical Agenda Items:**

- GDPR compliance status: data-flow architecture, DPA consensus tracking, carrier/distributor data-handling practices, incidents and remediation
- Accessibility compliance: app and carrier system audits, accessibility-assisted booking metrics, passenger complaints related to accessibility
- Ethics and conflict-of-interest review: new programme staff and stakeholder representatives, potential conflicts, compliance with the ethics code
- Passenger data security and breach response: quarterly review of data-handling incidents, mitigation actions
- Whistleblower cases: confidential review of any reported ethics violations or compliance concerns; recommendation of investigation or corrective action

**Escalation Path:** Recommendations on GDPR, accessibility or ethics compliance escalate to the Steering Committee for decision or action (e.g., co-funding suspension, mandatory corrective action by a carrier). Serious violations (evidence of corruption, major data breaches, severe accessibility failures) escalate immediately to DG MOVE and the Commission for investigation and potential enforcement. GDPR and accessibility issues may also escalate to the relevant national DPA or accessibility authority for guidance or enforcement.