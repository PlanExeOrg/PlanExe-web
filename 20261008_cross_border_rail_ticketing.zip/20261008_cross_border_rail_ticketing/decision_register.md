**8 open decisions: 3 high and 5 medium severity.** The earliest decisions are the force-majeure reserve rule (before the Month 4 = 2027-02-12 liability sign-off), the variance trigger basis and the regulation-slip tolerance (by Month 3 = 2027-01-12), then the headroom funding order and concession envelope split (Months 6-8 = 2027-04-12 to 2027-06-12). Until they are made, the plan can safely run the Month 2 (2026-12-12) audit, DG COMP pre-notification, actuarial study commissioning and steering set-up, but cannot lock budget lines, tranches or the concession tender.

| # | Decision | Severity | Owner | Decide by | Blocks |
|---|---|---|---|---|---|
| 1 | Concession envelope split | 🔴 High | Programme Steering Committee (75% supermajority for concession business case) | Month 8 (2027-06-12), so the Month 9 (2027-07-12) business case and Month 12 (2027-10-12) tender have a defined payment basis. | Month 9 (2027-07-12) concession business case and Month 12 (2027-10-12) tender issue; the concession market-test gate. |
| 2 | Headroom claims and validation hardware financing | 🔴 High | Programme Steering Committee, with Commission Financial Controller for budget lines | Month 6 (2027-04-12), before tier assignment and tranche release set adapter funding. | Month 6 (2027-04-12) tier assignment and tranche structure; Month 40 (2030-02-12) validation deployment. |
| 3 | Force-majeure reserve vs Month 36 (2029-10-12) ban | 🔴 High | Programme Steering Committee (75% supermajority, liability design) | Month 4 (2027-02-12), before carrier sign-off on the liability model. | Month 4 (2027-02-12) carrier sign-off and Month 6 (2027-04-12) liability binding vote. |
| 4 | Variance trigger basis | 🟡 Medium | Programme Steering Committee, with Commission Financial Controller | Month 3 (2027-01-12), before first quarterly variance tracking. | First quarterly variance review; Self-Audit and budget governance baseline. |
| 5 | Regulation-slip tolerance | 🟡 Medium | Programme Steering Committee, with Commission Transport Commissioner | Month 3 (2027-01-12), when the legislative timetable confirmation is due. | Month 3 (2027-01-12) regulatory gate; Tier 1 tranche (EUR 80M) at Month 30 (2029-04-12). |
| 6 | Concession term and subsidy horizon | 🟡 Medium | Programme Steering Committee | Month 9 (2027-07-12), with the concession business case, before tender issue at Month 12 (2027-10-12). | Month 12 (2027-10-12) tender issue; Month 9 (2027-07-12) business case approval. |
| 7 | Scope of Months 12-18 (2027-10-12 to 2028-04-12) pilots | 🟡 Medium | Operational Management Board, escalating to Programme Steering Committee | Month 10 (2027-08-12), before pilot design is frozen for Month 12 (2027-10-12) start. | Month 12 (2027-10-12) pilot start and Month 18 (2028-04-12) Phase 2 readiness. |
| 8 | TEN-T fallback beyond the 60-month horizon | 🟡 Medium | Programme Steering Committee, with Commission Transport Commissioner | Month 42 (2030-04-12), before Phase 3 planning at Month 48 (2030-10-12). | Phase 3 TEN-T extension start (Month 48 = 2030-10-12) and the EUR 100M variance response. |

## 1. Concession envelope split (🔴 High)

**Decision:** How is the EUR 300M concession envelope split between platform set-up, operating subsidy and public service-level payments, and is any unallocated part returned to headroom?

**Why it is open:** Canonical: EUR 300M envelope, subsidy capped at EUR 60M. Review 11.1 calls EUR 250-270M 'operating subsidy'; Review 3.3 says the business case 'locks' the envelope on only about EUR 110M of defined use. About EUR 190-210M has no stated use.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Fix set-up EUR 30-50M (proposed), subsidy EUR 60M, and quantify service-level payments for the remainder. | Keeps EUR 300M line; business case at Month 9 (2027-07-12) can lock a full split; tender at Month 12 (2027-10-12) proceeds on a defined payment basis. | budget_line_concession_eur_m; Reviews 11.1, 1.3, 3.3; concession_controls. |
| B. Reduce the envelope to the defined uses and return the difference to headroom. | Headroom rises above EUR 85M by up to about EUR 190-210M; eases C3 claims and variance triggers; EUR 200M trigger 'cut 20% (EUR 60M)' must be redefined. | budget_line_concession_eur_m; budget_unallocated_headroom_eur_m; budget_variance_triggers. |
| C. Defer the split until the Month 9 (2027-07-12) market sounding. | Tender at Month 12 (2027-10-12) stays feasible but the envelope remains partly unallocated for 9 months; headroom claims cannot be capped. | open_decisions; Review 3.3 wording. |

- **If nobody decides:** Envelope stays at EUR 300M with an unallocated remainder; the Month 9 (2027-07-12) business case cannot be approved by the 75% steering vote.
- **Owner:** Programme Steering Committee (75% supermajority for concession business case)
- **Decide by:** Month 8 (2027-06-12), so the Month 9 (2027-07-12) business case and Month 12 (2027-10-12) tender have a defined payment basis.
- **Blocks:** Month 9 (2027-07-12) concession business case and Month 12 (2027-10-12) tender issue; the concession market-test gate.

## 2. Headroom claims and validation hardware financing (🔴 High)

**Decision:** Which source funds the EUR 50M adapter-acceleration reserve and the ticket-validation hardware retrofits, and in what priority are claims on the EUR 85M headroom met?

**Why it is open:** Named claims on headroom total roughly EUR 130-205M against EUR 85M. The EUR 50M reserve has no canonical line. Review 11.2 funds validation hardware (EUR 30-80M) from headroom; Premortem A8 says it must not draw on headroom.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Carve the reserve from headroom and make carriers finance validation hardware. | Headroom falls to EUR 35M; carrier IT investment rises (outside cap); retrofit pace by Month 40 (2030-02-12) depends on carrier willingness. | budget_unallocated_headroom_eur_m; open_decisions (2); Review 11.2; Premortem A8. |
| B. Fund the reserve within the EUR 240M adapter line and split hardware costs public/carrier. | Headroom stays at EUR 85M but tier tranches shrink or are re-phased; hardware public share must be capped within headroom. | budget_line_adapters_eur_m; tier amounts; Reviews 3.2, 6.1, 11.2. |
| C. Drop the reserve and rely on variance triggers. | Headroom stays EUR 85M, but adapter slips of EUR 150-250M (estimate) hit triggers earlier. | Exec Summary Risks; Reviews 1.2, 2.2, 3.2. |

- **If nobody decides:** Claims remain uncapped against EUR 85M headroom; hardware retrofit has no financer, risking the Month 40 (2030-02-12) validation deployment.
- **Owner:** Programme Steering Committee, with Commission Financial Controller for budget lines
- **Decide by:** Month 6 (2027-04-12), before tier assignment and tranche release set adapter funding.
- **Blocks:** Month 6 (2027-04-12) tier assignment and tranche structure; Month 40 (2030-02-12) validation deployment.

## 3. Force-majeure reserve vs Month 36 (2029-10-12) ban (🔴 High)

**Decision:** Is the EUR 150M force-majeure reserve exempt from the ban on public pool draw-downs after Month 36 (2029-10-12)?

**Why it is open:** Reviews 5.2, 11.3, 14.3 say the reserve is available 'only after Month 36 (2029-10-12)', while canonical pool_draw_policy bans public draw-downs after Month 36 (2029-10-12) and says the reserve is drawable for force-majeure only. Pool stress is expected in Months 30-42 (2029-04-12 to 2030-04-12).

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Exempt: reserve drawable at any time for qualifying force-majeure events; ban covers ordinary deficits. | Reserve covers Months 30-42 (2029-04-12 to 2030-04-12) stress; needs a clear force-majeure definition and CCPR/actuarial test. | pool_draw_policy; Reviews 5.2, 11.3, 14.3. |
| B. Covered by ban: reserve released or re-allocated at Month 36 (2029-10-12). | Up to EUR 150M returns to headroom or other lines; pool unsupported when stressed after Month 36 (2029-10-12). | budget_line_force_majeure_reserve_eur_m; headroom; pool_draw_policy. |
| C. Post-Month 36 (2029-10-12) deficits fall on carriers via recalibrated contributions. | Reserve covers only to Month 36 (2029-10-12); higher carrier contributions may reduce participation. | liability_model_design; pool_draw_policy. |

- **If nobody decides:** Contradiction stands: reserve is unusable when needed or the ban is breached; the actuarial study at Month 6 (2027-04-12) cannot be finalised.
- **Owner:** Programme Steering Committee (75% supermajority, liability design)
- **Decide by:** Month 4 (2027-02-12), before carrier sign-off on the liability model.
- **Blocks:** Month 4 (2027-02-12) carrier sign-off and Month 6 (2027-04-12) liability binding vote.

## 4. Variance trigger basis (🟡 Medium)

**Decision:** Are the EUR 100M / 200M / 300M variance triggers measured gross against committed lines or net of the EUR 85M headroom?

**Why it is open:** Review 2.2 uses a net-of-headroom basis; Reviews 1.2, 3.2 use gross exposures. Self-Audit 18 lists EUR 50M/100M/200M. A hard cap of EUR 1,500M with EUR 85M headroom means a net basis lets spend exceed the cap before the first trigger.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Gross cost growth against committed lines (EUR 1,415M). | First trigger fires at EUR 100M, above headroom; a gap of EUR 15M needs a cut or reserve use before it fires. | budget_variance_triggers; Self-Audit 18; Reviews 1.2, 2.2, 3.2. |
| B. Net of headroom, so triggers fire only after headroom is exhausted. | Triggers fire at EUR 185M/285M/385M gross; cap likely breached before action. | budget_variance_triggers; public_budget_cap_eur_m interpretation. |
| C. Lower first trigger to at or below headroom (e.g. EUR 50M, proposed threshold). | Earlier TEN-T deferral; protects cap; changes canonical values. | budget_variance_triggers; negative consequences in escalation matrix. |

- **If nobody decides:** Triggers stay ambiguous; PSC cannot apply them consistently at quarterly review.
- **Owner:** Programme Steering Committee, with Commission Financial Controller
- **Decide by:** Month 3 (2027-01-12), before first quarterly variance tracking.
- **Blocks:** First quarterly variance review; Self-Audit and budget governance baseline.

## 5. Regulation-slip tolerance (🟡 Medium)

**Decision:** By which month must Regulation adoption be confirmed before Tier 1 funding (Month 30 = 2029-04-12) is released, and what happens if it is not?

**Why it is open:** Premortem A6 sets failure at Month 24 (2028-10-12), FM5 tripwire at Month 21 (2028-07-12), FM5 stop rule at Month 30 (2029-04-12) (same date as Tier 1 exposure and EUR 80M tranche). Canonical assumes adoption about Month 18 (2028-04-12) with a 6-12 month slip plausible.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Stop or convert to voluntary corridor pilots at Month 24 (2028-10-12). | Tier 1 tranche not released unadopted; through-ticket share planning range 15-30% (estimate). | Premortem A6, FM5; regulation_adoption_assumption. |
| B. Accept voluntary Tier 1 exposure and release funding at Month 30 (2029-04-12) regardless. | EUR 80M committed without statute; enforcement weak; carrier take-up uncertain. | mandatory_api_exposure_milestone; Tier 1 conditions. |
| C. Keep Month 30 (2029-04-12) stop but tie tranche release to a Month 27 (2029-01-12) adoption check. | Limits exposure to pre-build spend; needs a staged Tier 1 release. | FM5 stop rule; tranche schedule. |

- **If nobody decides:** Tier 1 funds are released at Month 30 (2029-04-12) on a voluntary basis by default, after the stop point has passed.
- **Owner:** Programme Steering Committee, with Commission Transport Commissioner
- **Decide by:** Month 3 (2027-01-12), when the legislative timetable confirmation is due.
- **Blocks:** Month 3 (2027-01-12) regulatory gate; Tier 1 tranche (EUR 80M) at Month 30 (2029-04-12).

## 6. Concession term and subsidy horizon (🟡 Medium)

**Decision:** When does the five-year concession term start (award or service launch), and who pays subsidy beyond Month 60 (2031-10-12)?

**Why it is open:** Canonical: award about Month 18 (2028-04-12), service live about Month 30 (2029-04-12), subsidy EUR 60M over five years, extension to 7 years at the EUR 200M trigger. Review 14.1 and Self-Audit 15 end the term at Month 60 (2031-10-12); FM7 tripwire puts tender close in Month 12 (2027-10-12), when tender is issued.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Term runs five years from service launch (about Month 30 = 2029-04-12 to Month 90 = 2034-04-12). | Subsidy after Month 60 (2031-10-12) needs a post-programme payer; ties to the Month 72 (2032-10-12) fallback and EUR 30-50M direct operation (estimate). | concession_timeline; Review 14.1; Self-Audit 15. |
| B. Term ends with programme at Month 60 (2031-10-12) (about 2.5-3.5 years from launch). | Bid pricing and subsidy cap per year change; fewer bidders or higher annual subsidy likely. | concession_subsidy_cap_eur_m; budget_variance_triggers (7-year extension). |
| C. Fix a tender-close date after Month 12 (2027-10-12) and leave term length to bidders within the cap. | Keeps flexibility; Month 12 (2027-10-12) tender documents lack term clarity. | FM7 tripwire; concession_timeline. |

- **If nobody decides:** Tender documents issued at Month 12 (2027-10-12) carry an inconsistent term, risking fewer than 3 compliant bids.
- **Owner:** Programme Steering Committee
- **Decide by:** Month 9 (2027-07-12), with the concession business case, before tender issue at Month 12 (2027-10-12).
- **Blocks:** Month 12 (2027-10-12) tender issue; Month 9 (2027-07-12) business case approval.

## 7. Scope of Months 12-18 (2027-10-12 to 2028-04-12) pilots (🟡 Medium)

**Decision:** Which flows are live in the Months 12-18 (2027-10-12 to 2028-04-12) pilots, and is an interim bilateral settlement used before the clearing layer is approved?

**Why it is open:** Pilots with 500-1,000 passengers per corridor are meant to check reconciliation error and settlement, but clearing is conditional on DG COMP guidance (Month 12 = 2027-10-12) and clean-team approval (Month 14 = 2027-12-12), and pilots before Month 14 (2027-12-12) run on non-contested data only.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Pilot non-contested flows only; move reconciliation and settlement criteria to the Months 18-24 (2028-04-12 to 2028-10-12) platform pilot. | Phase 2 readiness at Month 18 (2028-04-12) covers search, booking and rerouting only; settlement risk surfaces later. | pilots_and_validation; Review 15.3; Phase 2 readiness criteria. |
| B. Add interim bilateral settlement before Month 14 (2027-12-12) for pilot corridors. | Pilots test settlement but need legal cover and DG COMP awareness; extra effort within the EUR 220M clearing line. | clearing scope; competition_law_timeline; Reviews 15.3, 16.2. |
| C. Simulate settlement with synthetic transactions. | Cheaper, no Article 101 exposure; weaker evidence of the below-0.5% error target. | pilot test plan; settlement_standards evidence. |

- **If nobody decides:** Pilots run on non-contested flows but are assessed against reconciliation criteria they cannot meet, so Phase 2 readiness is unverifiable.
- **Owner:** Operational Management Board, escalating to Programme Steering Committee
- **Decide by:** Month 10 (2027-08-12), before pilot design is frozen for Month 12 (2027-10-12) start.
- **Blocks:** Month 12 (2027-10-12) pilot start and Month 18 (2028-04-12) Phase 2 readiness.

## 8. TEN-T fallback beyond the 60-month horizon (🟡 Medium)

**Decision:** Is the Month 72 (2032-10-12) TEN-T extension fallback approved, with its funding, given it lies outside the five-year horizon?

**Why it is open:** Canonical: TEN-T extension Months 48-60 (2030-10-12 to 2031-10-12), fallback Month 72 (2032-10-12), outside the five-year horizon. The EUR 100M variance trigger defers TEN-T to Months 60-72 (2031-10-12 to 2032-10-12). The cap is a hard EUR 1,500M and no source is named for post-Month 60 (2031-10-12) spend.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Approve Month 72 (2032-10-12) as a funded fallback within the EUR 1,500M cap. | Needs spend after Month 60 (2031-10-12) within the cap; final share planning 25-30% (estimate) if deferred. | tent_network_extension; open_decisions (3); budget phasing. |
| B. Do not approve; the programme ends at Month 60 (2031-10-12) with the four corridors and partial TEN-T. | Hard stop; unspent amounts return; full-network goal at risk. | tent_network_extension; budget_variance_triggers (EUR 100M). |
| C. Defer decision to the EUR 100M trigger or Month 48 (2030-10-12) review. | Keeps option open; planning for Phase 3 proceeds without a confirmed end date. | Phase 3 plan; trigger text. |

- **If nobody decides:** Fallback remains unapproved; if the EUR 100M trigger fires, deferral to Months 60-72 (2031-10-12 to 2032-10-12) has no authority or funding.
- **Owner:** Programme Steering Committee, with Commission Transport Commissioner
- **Decide by:** Month 42 (2030-04-12), before Phase 3 planning at Month 48 (2030-10-12).
- **Blocks:** Phase 3 TEN-T extension start (Month 48 = 2030-10-12) and the EUR 100M variance response.

## Choices made on your behalf

Set when the scenario was selected, not by you. Confirm or change them.

| Lever | Chosen | Strongest alternative | Why it matters | Revisit by |
|---|---|---|---|---|
| Through-ticket liability and rights backstop | Carrier-funded mutual guarantee pool, no public pay-first fund. | Publicly capitalised rights backstop fund that pays passengers immediately. | Determines carrier participation, public budget exposure and the liability sign-off at Months 4-6 (2027-02-12 to 2027-04-12). | Month 6 (2027-04-12) gate |
| Inter-carrier clearing and single-payment settlement | Federated netting and dispute layer connecting existing clearing arrangements. | Single EU-level clearing entity netting all positions. | Sets the EUR 220M line and the Article 101 exposure. | Month 12 (2027-10-12) (DG COMP guidance) |
| Public reference distributor mandate | Tendered last-resort concession run by a private operator under public service-level terms. | B2B reference sandbox only, with consumer sales left to commercial distributors. | Drives the EUR 300M envelope, subsidy cap and neutrality towards Trainline and Omio. | Month 9 (2027-07-12) business case |
| Milestone-conditioned funding release ladder | Tranches tied to verified technical milestones such as conformance certificates and live API exposure. | Competitive co-financed call ranked by expected through-ticket volume. | Sets compliance leverage and how much the EUR 240M adapter line depends on carrier readiness. | Month 6 (2027-04-12) tier assignment |
| Availability query topology and booking authority | Event-streamed availability shadow, carrier booking engine as sole authority, scheduled-only degradation. | Central inventory exchange, or direct queries to carrier endpoints via a registry. | Sets the EUR 50M real-time layer and whether the p95 below 2 s SLA is achievable. | Month 2 (2026-12-12) technical audit |
