**7 open decisions: 4 high and 3 medium severity.** Most urgent are the demand-threshold definitions (Month 1 = 2026-11-08) and the reference distributor scope (Month 2 = 2026-12-08). The funding source for overruns beyond free contingency follows at Month 3 (2027-01-08), ahead of co-funding awards. Until then, the plan can safely run shadow standards work, the baseline survey, the DPIA, market sounding and the governance set-up, but should not commit co-funding awards or distributor scope.

| # | Decision | Severity | Owner | Decide by | Blocks |
|---|---|---|---|---|---|
| 1 | Who pays beyond the fixed cap | 🔴 High | Programme Steering Committee, escalating to the Commission (DG MOVE). | Month 3 (2027-01-08), before co-funding awards and distributor commitments are made. | Co-funding award commitments, Month 12 mid-course review, and the cost-model gate. |
| 2 | Reference distributor scope | 🔴 High | Programme Steering Committee with DG MOVE as sponsor. | Month 2 (2026-12-08), because the cost model and binding quotes (Months 4-6 = 2027-02-08 to 2027-04-08) depend on it. | Cost-model gate, distributor procurement, and the budget-fit gate. |
| 3 | Meaning and timing of the Month 24 (2028-10-08) share gate | 🔴 High | Programme Steering Committee, advised by the Measurement and Evaluation Lead. | Month 9 (2027-07-08), when the validated baseline is available. The pilot settlement route is needed earlier. | Month 24 (2028-10-08) interim gate, fee-subsidy continuation, and Month 12 (2027-10-08) pilot conversion test. |
| 4 | Demand thresholds | 🔴 High | Programme Steering Committee, with the Measurement and Evaluation Lead. | Month 1 (2026-11-08), so the survey design (Months 1-4 = 2026-11-08 to 2027-02-08) uses the right threshold. | Willingness-to-pay gate at Month 4 (2027-02-08) and the pilot conversion read at Month 12 (2027-10-08). |
| 5 | Carrier co-funding triggers and increase | 🟡 Medium | Programme Steering Committee. | Month 6 (2027-04-08), before the Month 12 (2027-10-08) Tier 2 trigger and award commitments. | Tier 2 trigger at Month 12 (2027-10-08) and the Month 18 (2028-04-08) grant review. |
| 6 | Corridor go-live definitions | 🟡 Medium | Project Sponsor (DG MOVE) with the Programme Steering Committee. | Month 6 (2027-04-08), before the app and hub schedules are baselined. | Consumer rollout plan and the corridor-opening settlement gate. |
| 7 | Hub end state | 🟡 Medium | Programme Steering Committee, with the Commission for the post-Month 60 (2031-10-08) funding. | Month 30 (2029-04-08), alongside the TEN-T hub decision. The funding model decision is due Month 48 (2030-10-08). | TEN-T hub decision at Month 30 (2029-04-08) and the Month 48 (2030-10-08) funding model decision. |

## 1. Who pays beyond the fixed cap (🔴 High)

**Decision:** If overruns exceed the EUR 215M free contingency, who finances the excess: a formal cap increase, Tier 3 cuts, or hard limits on committed exposure?

**Why it is open:** Executive summary, plan and pitch call the EUR 1,500M cap fixed. Risk sections rely on a EUR 100-200M supplementary authority (estimate) that is outside the cap, unsecured, and below the EUR 85-235M exposure in a 20-30% overrun.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Pre-agreed Commission/Council top-up that formally lifts the cap. | Covers up to EUR 85-235M exposure only if sized for the upper case. Needs a political process before awards are committed. | public_budget_cap_eur; fallback_budget_overrun_exceeds_cap; executive summary and pitch wording. |
| B. Pre-size Tier 3 scope cuts to absorb the full EUR 85-235M. | Cap stays fixed. Likely cuts to conformance testing, capacity building or TEN-T extension (Month 36 = 2029-10-08 start). | budget_tiers_and_reviews; allocation lines; tent_extension_start. |
| C. Cap committed co-funding and distributor exposure at the EUR 215M free contingency. | Overrun risk is limited by design. Reduces award headroom and may slow smaller-carrier onboarding. | alloc_carrier_cofunding_eur; alloc_reference_distributor_eur; premortem FM1. |

- **If nobody decides:** The cap is treated as fixed with no funded fallback. Tier 3 triggers an ad hoc Commission escalation after contingency is spent.
- **Owner:** Programme Steering Committee, escalating to the Commission (DG MOVE).
- **Decide by:** Month 3 (2027-01-08), before co-funding awards and distributor commitments are made.
- **Blocks:** Co-funding award commitments, Month 12 mid-course review, and the cost-model gate.

## 2. Reference distributor scope (🔴 High)

**Decision:** Should the public reference distributor be reference-implementation only, hybrid, or full retail?

**Why it is open:** The EUR 215M line (~EUR 43M/year) sits between sizings. The self-audit calls it reference-only. The review sizes reference-only at EUR 20-30M/year and full retail at EUR 60-100M/year (estimates). Overrun figures use different bases.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Reference-implementation only. | Fits the EUR 215M line with headroom. Weaker public competitor to incumbents. | alloc_reference_distributor_eur; post_month60_unfunded_run_cost. |
| B. Hybrid scope. | Uses most of the EUR 215M. Needs a new tripwire base (currently EUR 50M/year). | Reference distributor allocation; tripwire; fallback_extended_distributor_operation. |
| C. Full retail. | Above EUR 215M. Needs a cap decision or cuts elsewhere. Post-Month 60 (2031-10-08) run cost rises. | Budget lines; post_month60_unfunded_run_cost; contingency use. |

- **If nobody decides:** The EUR 215M line is spent with undefined scope. Overruns are drawn from free contingency by default.
- **Owner:** Programme Steering Committee with DG MOVE as sponsor.
- **Decide by:** Month 2 (2026-12-08), because the cost model and binding quotes (Months 4-6 = 2027-02-08 to 2027-04-08) depend on it.
- **Blocks:** Cost-model gate, distributor procurement, and the budget-fit gate.

## 3. Meaning and timing of the Month 24 (2028-10-08) share gate (🔴 High)

**Decision:** What does the Month 24 (2028-10-08) 15% through-ticket share gate measure, and is it kept before corridors go live?

**Why it is open:** The gate (15%, proposed threshold) sits at Month 24 (2028-10-08). Consumer go-live is Month 27 (2029-01-08), the API mandate Month 30 (2029-04-08), and providers operate from Month 12 (2027-10-08). The Month 9 (2027-07-08) pilot settlement route is unstated.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Measure share on live pilot corridors only. | Gate stays at Month 24 (2028-10-08) and is reachable. The sample is small and unrepresentative of the 40% target. | measurement_baseline; payment_fee_subsidy. |
| B. Move the gate after first go-live (e.g. Month 30+). | Measures real capability. Fee subsidy ends at Month 24 (2028-10-08) before the gate reads, so the subsidy end date must be revisited. | measurement_baseline; payment_fee_subsidy; co-funding review timing. |
| C. Keep the all-journeys gate at Month 24 (2028-10-08). | Likely missed by design. Triggers co-funding hold and subsidy end. | No change; premortem FM3 stays. |

- **If nobody decides:** The gate stays as written, is likely missed, and triggers the co-funding hold and subsidy end.
- **Owner:** Programme Steering Committee, advised by the Measurement and Evaluation Lead.
- **Decide by:** Month 9 (2027-07-08), when the validated baseline is available. The pilot settlement route is needed earlier.
- **Blocks:** Month 24 (2028-10-08) interim gate, fee-subsidy continuation, and Month 12 (2027-10-08) pilot conversion test.

## 4. Demand thresholds (🔴 High)

**Decision:** Which separately named demand thresholds (metric, month, owner) replace the reused 8%?

**Why it is open:** 8% is used for stated preference (Month 4 = 2027-02-08), share (Month 24 = 2028-10-08) and modal shift (Month 48 = 2030-10-08). Stated preference at 8% proves little against the 40% target. Pilot conversion (3%) and the 15% gate are proposed thresholds.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Three distinct thresholds: preference at Month 4 (2027-02-08), pilot conversion 3% at Month 12 (2027-10-08), share 15% gate / 8% stop at Month 24 (2028-10-08). | Clear stop rules. The Month 4 (2027-02-08) level must be justified against the 40% target. | measurement_baseline; review and premortem A3/FM3/FM6. |
| B. Raise the stated-preference threshold. | Stricter early stop. Higher chance of stopping marketing beyond the pilot. | Review Critical Assumptions; premortem A3. |
| C. Defer the Month 4 (2027-02-08) threshold and rely on the Month 12 (2027-10-08) pilot. | Less early information. Marketing spend risk before Month 12 (2027-10-08). | Survey window; consumer rollout phasing. |

- **If nobody decides:** The ambiguous 8% remains. The Month 4 (2027-02-08) survey result cannot reliably drive a stop or go.
- **Owner:** Programme Steering Committee, with the Measurement and Evaluation Lead.
- **Decide by:** Month 1 (2026-11-08), so the survey design (Months 1-4 = 2026-11-08 to 2027-02-08) uses the right threshold.
- **Blocks:** Willingness-to-pay gate at Month 4 (2027-02-08) and the pilot conversion read at Month 12 (2027-10-08).

## 5. Carrier co-funding triggers and increase (🟡 Medium)

**Decision:** What single demand metric and early-warning and failure levels apply to co-funding, and is any increase in grants funded?

**Why it is open:** Triggers of EUR 290M, EUR 310M and ~EUR 348M are all in use. Only EUR 234M is grants. A rise from EUR 234M to EUR 280M at Month 18 (2028-04-08) has no source and conflicts with the Tier 2 rate cut.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Grant demand vs EUR 234M with one warning and one failure level; no increase. | Simple control. Under-subscription is handled by milestone rules, not extra money. | alloc_carrier_cofunding_eur; premortem FM1; self-audit. |
| B. Allow the increase to EUR 280M, funded from free contingency. | Uses EUR 46M of the EUR 215M free contingency. Reduces overrun headroom. | contingency_free_eur; co-funding line; Tier 2 text. |
| C. Fund the increase by reallocating from other lines. | Cap neutral. Cuts another line by EUR 46M. | Allocation lines; review. |

- **If nobody decides:** Overlapping triggers stay and the increase is unfunded. Tier 2 timing is disputed at Month 12 (2027-10-08).
- **Owner:** Programme Steering Committee.
- **Decide by:** Month 6 (2027-04-08), before the Month 12 (2027-10-08) Tier 2 trigger and award commitments.
- **Blocks:** Tier 2 trigger at Month 12 (2027-10-08) and the Month 18 (2028-04-08) grant review.

## 6. Corridor go-live definitions (🟡 Medium)

**Decision:** How are consumer go-live, API mandate and full through-ticketing defined, and which corridor goes first?

**Why it is open:** The executive summary has first-corridor go-live at Month 30 (2029-04-08). Canonical facts have four-corridor consumer go-live at Month 27 (2029-01-08), the API mandate at Month 30 (2029-04-08) and full through-ticketing at Month 60 (2031-10-08).

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Three terms: consumer go-live Month 27 (2029-01-08), API mandate Month 30 (2029-04-08) (90% bookable), full through-ticketing Month 60 (2031-10-08) (40%). | Aligns with canonical facts. The 5% first-corridor traffic target needs re-anchoring. | Executive summary deliverables; pitch; review. |
| B. Staggered corridor go-live with a named first corridor. | Lower risk per corridor. Changes the Month 27 (2029-01-08) four-corridor consumer date. | consumer_app_timeline; milestones. |

- **If nobody decides:** The two timelines stay inconsistent. Gate measurement and onboarding plans diverge.
- **Owner:** Project Sponsor (DG MOVE) with the Programme Steering Committee.
- **Decide by:** Month 6 (2027-04-08), before the app and hub schedules are baselined.
- **Blocks:** Consumer rollout plan and the corridor-opening settlement gate.

## 7. Hub end state (🟡 Medium)

**Decision:** At Month 48 (2030-10-08), should hubs be moved to full cost recovery, kept with a subsidy, or sunset with carrier migration?

**Why it is open:** The hub timeline has sunset/cost-recovery at Month 48 (2030-10-08). Fee revenue covers ~61% of opex (gap ~EUR 1.9M/year for 4 hubs, estimate), and TEN-T carriers join via hubs from Month 36 (2029-10-08).

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Raise fees to full cost recovery. | Removes the subsidy gap. Raises costs for smaller carriers and may deter onboarding. | hub_economics_gap; hub_timeline. |
| B. Continue a subsidy in the post-Month 60 (2031-10-08) funding decision. | Adds ~EUR 1.9M/year to the ~EUR 45M/year unfunded run cost. | post_month60_unfunded_run_cost; hub_timeline. |
| C. True sunset with migration to native interfaces. | Conflicts with TEN-T hubs and hubs after Month 60 (2031-10-08). Needs migration support funding. | hub_scope_and_funding; tent_extension_start. |

- **If nobody decides:** Hubs keep running past Month 48 (2030-10-08) with an unfunded gap.
- **Owner:** Programme Steering Committee, with the Commission for the post-Month 60 (2031-10-08) funding.
- **Decide by:** Month 30 (2029-04-08), alongside the TEN-T hub decision. The funding model decision is due Month 48 (2030-10-08).
- **Blocks:** TEN-T hub decision at Month 30 (2029-04-08) and the Month 48 (2030-10-08) funding model decision.

## Choices made on your behalf

Set when the scenario was selected, not by you. Confirm or change them.

| Lever | Chosen | Strongest alternative | Why it matters | Revisit by |
|---|---|---|---|---|
| OSDM access terms and enforcement | Certification-based tiered access with carrier audit rights over distributors. | A regulated reference price and service-level schedule enforced by national regulators. | It avoids fixing a price before the Regulation and real cost data exist, but enforcement is softer. | Month 9 (2027-07-08), at the Regulation adoption gate. |
| Clearing and settlement | Competing accredited payment institutions under common settlement rules. | A single publicly governed clearing entity with a guarantee fund. | It avoids new-entity licensing delay, but depends on at least 2 providers being operational by Month 12 (2027-10-08). | Month 6 (2027-04-08), the applicant-count fallback tripwire. |
| Funding allocation and incentives | Milestone-based co-funding that prioritises smaller and state-weak carriers. | A competitive pool paid on verified through-ticket volume. | It determines who receives the EUR 290M co-funding line and how overrun risk is shaped. | Month 12 mid-course review. |
| Legacy carrier IT migration | Regional shared booking hubs (4 at launch). | A publicly hosted gateway translating legacy systems. | It lets smaller carriers meet the Month 30 (2029-04-08) mandate, but creates a hub operating gap. | Month 30 (2029-04-08), TEN-T hub decision. |
| Governance vehicle | A time-boxed arbitration panel layered on existing institutions. | A joint undertaking with its own budget authority and tie-breaking power. | It avoids a new legal entity, but the panel has no enforcement authority of its own. | Month 2 (2026-12-08), the delegation signature gate. |
