A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Carriers will accept connection liability through a carrier-funded guarantee pool once caps (EUR 500-1,000 per passenger, proposed threshold) and co-insurance (EUR 50M, proposed threshold) are published, even though loss data are not yet collected. | Commission the actuarial study at Month 1 (2026-11-12) and run bilateral sessions with at least 8 major carriers and CER on three cap/co-insurance scenarios, asking at what exposure each would commit inventory. | Fewer than 8 major carriers and CER sign the non-binding letter of intent against the Month 3 (2027-01-12) interim parameters by Month 4 (2027-02-12) (the final Month 6 (2027-04-12) study may only be adjusted within an agreed band; the binding vote follows at Month 6 (2027-04-12)), or any carrier on a priority corridor states the priced exposure is unacceptable. |
| A2 | Legacy booking systems of smaller carriers can be retrofitted with shared adapters to meet p95 latency below 2 seconds and 99.5% availability within the tier dates (Months 30/36/42 = 2029-04-12, 2029-10-12, 2030-04-12), funded by EUR 240M of adapters. | Run the technical audit with synthetic three-leg queries against all 25+ carriers' endpoints by Month 2 (2026-12-12) and have carrier IT leads estimate retrofit effort per system pattern. | More than 35% of carriers cannot demonstrate a credible path to the SLA by their tier date, or shared adapters cover under 60% of observed legacy patterns. |
| A3 | Distributors, independent carriers and DG COMP will accept the federated clearing and commission-band governance as non-discriminatory and Article 101-compatible, so no redesign is needed after investment. | Submit the DG COMP pre-notification memorandum with data flows and governance charter at Month 2 (2026-12-12), and test the draft rulebook with Trainline, Omio and 3-4 smaller carriers. | DG COMP interim feedback or a major distributor signals exclusionary or price-coordination concerns requiring a design change, or a major distributor refuses the clearing design. |
| A4 | The programme office and Technical Secretariat can recruit and retain scarce OSDM, clearing and actuarial specialists on schedule (Programme Office 80 staff, Technical Secretariat 50 staff, estimate) without key-person turnover disrupting the Month 6 (2027-04-12) and Month 18 (2028-04-12) milestones. | Survey the specialist labour market and test offer acceptance for the 10 most critical roles (custodian, clearing architect, actuarial lead, integration manager) at the planned EU grades before Month 1 (2026-11-12). | Fewer than 7 of 10 critical roles are filled by Month 3 (2027-01-12), or offer acceptance is below 50% at planned grades (proposed threshold). |
| A5 | Passengers and independent distributors will choose through-tickets over stitched itineraries and flights, including when atomic accessibility confirmation removes some itineraries and scheduled-only fallback occurs, so the 40% target (user constraint) is reachable. | Run A/B booking-behaviour tests and usability sessions with 50+ passengers (at least 15 with reduced mobility, 15 non-native speakers) and a distributor conversion study on one corridor, using stitched itineraries as control, by Month 4 (2027-02-12). | Through-ticket conversion is not above stitched-itinerary conversion in the test, or more than 15% of itineraries are rejected for accessibility capacity (proposed threshold) with satisfaction below 70% (proposed threshold). |
| A6 | The Regulation will be adopted with amendments by about Month 18 (2028-04-12) and keep a binding OSDM reference and mandatory API exposure, so carriers and national regulators will treat the milestones as legally binding rather than voluntary. | Obtain written confirmation of the legislative timetable from the Commission legislative affairs unit and bilateral positions from national regulators on the four priority corridors by Month 3 (2027-01-12). | The timetable shows adoption later than Month 24 (2028-10-12) (proposed threshold), or any national regulator on a priority corridor signals it will not enforce API exposure. |
| A7 | The EUR 300M concession envelope (operating subsidy capped at EUR 60M over five years, proposed threshold) will attract a credible private concessionaire whose volumes meet forecast, so the last-resort channel needs no extra public funding. | Run a market sounding with 5-8 potential concessionaires and test a draft business case with binding cost quotes before the Month 9 (2027-07-12) business case. | Fewer than 3 credible bidders express interest, or indicative bids need subsidy above EUR 60M over five years (proposed threshold) or volume below 60% of forecast (proposed threshold). |
| A8 | Ticket-validation hardware retrofits on corridor rolling stock and key stations can be completed by Month 40 (2030-02-12) within vehicle maintenance cycles, with financing resolved by carriers or the budget without drawing on the EUR 85M headroom. | Survey the carriers on the four priority corridors by Month 2 (2026-12-12) for depot schedules, unit counts, supplier lead times and willingness to self-fund. | More than 20% of corridor vehicles (proposed threshold) cannot be retrofitted before Month 40 (2030-02-12), or carriers require public funding exceeding the EUR 85M headroom. |
| A9 | Passenger data, fares and inventory can flow through the availability shadow, disruption feed and clearing layer in a way that national data-protection authorities and carriers accept, without redesign or pauses in integration. | Commission a data-protection impact assessment by Month 2 (2026-12-12) mapping every personal-data flow, and test the draft data-processing terms with 5 carriers and 2 national authorities. | The assessment finds personal data in shared layers that cannot be minimised, or any national authority signals it will require suspension or redesign of a shared layer. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Clearing Unwind | Process/Financial | A3 | Competition Law & Regulatory Affairs Counsel | CRITICAL (15/25) |
| FM2 | The Slowest Mainframe | Technical/Logistical | A2 | Carrier Integration & Technical Onboarding Manager | CRITICAL (16/25) |
| FM3 | The Unpriceable Handshake | Market/Human | A1 | Programme Director & Executive Governance Lead | CRITICAL (20/25) |
| FM4 | The Empty Chairs | Process/Financial | A4 | Programme Director & Executive Governance Lead | HIGH (12/25) |
| FM5 | The Standard Without a Statute | Technical/Logistical | A6 | Standards & Technical Specification Custodian | CRITICAL (15/25) |
| FM6 | The Passenger Who Walks Away | Market/Human | A5 | Passenger Rights, Accessibility & Consumer Protection Lead | HIGH (12/25) |
| FM7 | The Concession Cliff | Process/Financial | A7 | Public Reference Distributor Concession Manager & Procurement Lead | HIGH (12/25) |
| FM8 | The Handheld That Never Arrived | Technical/Logistical | A8 | Carrier Integration & Technical Onboarding Manager | HIGH (9/25) |
| FM9 | The Data Backlash | Market/Human | A9 | Data Governance and Privacy Officer | HIGH (12/25) |


### Failure Modes

#### FM1 - The Clearing Unwind

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A3
- **Owner**: Competition Law & Regulatory Affairs Counsel
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- DG COMP guidance arrives late; clean-team protocol is rushed.
- Carriers invest in clearing feeds and adapters before legal comfort is firm.
- A post-investment Article 101 challenge forces redesign (EUR 50-100M, 6-12 months, estimate).
- Rework exceeds the EUR 85M headroom, triggering variance cuts.
- Binding standards and settlement go-live slip.

##### Early Warning Signs
- DG COMP raises written concerns on netting or data pooling at interim feedback
- Clean-team protocol draft not agreed with counsel by Month 9 (2027-07-12)
- Major distributor files objection to the clearing rulebook
- Carriers defer ISO 20022 feed commitments pending legal clarity

##### Tripwires
- DG COMP guidance not received by Month 12 (2027-10-12)
- Clean-team protocol not approved by Month 14 (2027-12-12)
- Cumulative rework variance >= EUR 50M
- Fewer than 6 carriers confirm feed commitments by Month 15 (2028-01-12)

##### Response Playbook
- Contain: Freeze further clearing platform commitments and carrier integration spend tied to contested data flows.
- Assess: Map every shared data flow against DG COMP feedback and quantify rework cost and delay per option.
- Respond: Pivot to bilateral clearing with a neutral dispute layer and re-baseline the budget under the variance triggers.


**STOP RULE:** Cancel the shared clearing layer and revert to bilateral settlement if DG COMP guidance is negative and no compliant design is approved by Month 18 (2028-04-12).

---

#### FM2 - The Slowest Mainframe

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Carrier Integration & Technical Onboarding Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Smaller carriers run mainframe or flat-file systems with 5-15 second queries (estimate).
- Three-leg queries at 95% availability each yield about 86% combined.
- Shared adapters cover fewer patterns than assumed; custom adapters multiply cost.
- 8-15 operators miss Month 30 (2029-04-12); scheduled-only fallback is triggered too often.
- Stale-seat failures and corridor gaps erode through-ticket value.

##### Early Warning Signs
- Audit shows p95 latency above 5 seconds for many Tier 2/3 carriers
- Pilot stale-seat failures above 1%
- Shared adapter patterns cover under 60% of systems
- Carrier integration roadmaps missing milestones

##### Tripwires
- More than 35% of carriers unable to meet SLA by tier date
- Scheduled-only fallback >= 5% of searches in pilots
- Stale-seat failures >= 1% for 2 consecutive months
- Adapter spend variance >= 20% per carrier

##### Response Playbook
- Contain: Suspend further tranche releases to carriers missing SLA for 2 consecutive months and cap per-carrier adapter spend.
- Assess: Re-run audit latency tests and rank carriers by retrofit effort and corridor criticality.
- Respond: Re-tier timelines with a Tier 1.5 cohort, shift to the distributed cache and prioritise corridor-critical carriers.


**STOP RULE:** Restrict scope to corridors whose carriers all meet the SLA if fewer than 15 operators are conformant by Month 36 (2029-10-12).

---

#### FM3 - The Unpriceable Handshake

- **Archetype**: Market/Human
- **Root Cause**: Assumption A1
- **Owner**: Programme Director & Executive Governance Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- Indicative caps and co-insurance are not backed by loss data.
- Large carriers cannot price missed-connection exposure and withhold inventory.
- Distributors see gaps at key junctions and deprioritise through-tickets.
- Participation falls below the 15-20 minimum viable carriers.
- The 40% target falls to the 15-30% planning range (estimate).

##### Early Warning Signs
- Carriers request data confidentiality terms that delay actuarial inputs
- Major carriers decline written commitment at bilateral sessions
- CER signals a preference for bilateral liability
- Distributors report corridor gaps in test searches

##### Tripwires
- Fewer than 8 carriers and CER sign the non-binding letter of intent by Month 4 (2027-02-12)
- Actuarial interim results not delivered by Month 3 (2027-01-12)
- Steering vote on Decision 1 below 75% at Month 6 (2027-04-12)
- Loss data supplied by fewer than 3 major carriers

##### Response Playbook
- Contain: Escalate to Commission mediation by Month 5 (2027-03-12) and pause dependent procurement commitments.
- Assess: Rank refusing carriers by corridor criticality and identify the exposure level that would change each position.
- Respond: Offer a two-tier pool with reinsurance for smaller operators and invoke the Month 12 (2027-10-12) deferral if unresolved.


**STOP RULE:** Pivot to the Prudent Consolidator model if fewer than 6 major carriers commit by Month 12 (2027-10-12).

---

#### FM4 - The Empty Chairs

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Programme Director & Executive Governance Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- OSDM, clearing and actuarial experts are scarce and also sought by carriers (estimate).
- Key roles stay vacant or turn over at the Month 6 (2027-04-12) and Month 18 (2028-04-12) gates.
- Procurement of the EUR 220M clearing layer and the actuarial study slips.
- Extended consultants and delays consume part of the EUR 85M headroom.
- Milestone-conditioned tranches cannot be verified on time.

##### Early Warning Signs
- Critical role vacancies open longer than 60 days
- Offers declined at planned EU grades
- Actuarial or audit contractor start dates slip
- Consultant spend exceeds the EUR 75M programme management line run-rate

##### Tripwires
- Fewer than 7 of 10 critical roles filled by Month 3 (2027-01-12)
- Any critical role vacant >= 60 days
- Programme management spend variance >= 15% in a quarter
- Actuarial firm not contracted by Month 2 (2026-12-12)

##### Response Playbook
- Contain: Freeze non-critical hiring and move critical work to framework-contract integrators and interim specialists.
- Assess: Map each vacancy against its milestone dependency and quantify delay and cost per week.
- Respond: Reset the critical-role plan with retention incentives and deputy cover, and re-baseline milestone dates through the steering group.


**STOP RULE:** Invoke the Month 12 (2027-10-12) readiness-gate deferral if the clearing architect, actuarial lead or integration manager roles remain unfilled at Month 6 (2027-04-12).

---

#### FM5 - The Standard Without a Statute

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A6
- **Owner**: Standards & Technical Specification Custodian
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Regulation adoption slips 6-12 months (estimate, not verified).
- OSDM version is not pinned by delegated or implementing act at Month 18 (2028-04-12).
- Carriers build to differing OSDM profiles and fork versions.
- Conformance tests become ambiguous and rework follows.
- Tier 1 exposure at Month 30 (2029-04-12) is unenforceable.

##### Early Warning Signs
- Council or Parliament amendments weaken API exposure language
- Carriers implement different OSDM profiles in test environments
- Change requests exceed the 8-week minor-turnaround target
- Regulators decline observer seats in standards groups

##### Tripwires
- Regulation not adopted by Month 21 (2028-07-12)
- Pinned OSDM version not published by Month 18 (2028-04-12)
- More than 2 divergent OSDM profiles in conformance tests
- Conformance test coverage < 80% at Month 12 (2027-10-12)

##### Response Playbook
- Contain: Freeze the working OSDM version and issue a voluntary conformance profile to all carriers.
- Assess: Identify which obligations lack a legal basis and which carriers will proceed voluntarily.
- Respond: Launch the shadow standards workstream and pilot authority, and re-sequence tiers to the adoption date.


**STOP RULE:** Convert the programme to a voluntary corridor pilot model if the Regulation is not adopted by Month 30 (2029-04-12).

---

#### FM6 - The Passenger Who Walks Away

- **Archetype**: Market/Human
- **Root Cause**: Assumption A5
- **Owner**: Passenger Rights, Accessibility & Consumer Protection Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Atomic accessibility confirmation hides itineraries for travellers with reduced mobility.
- Scheduled-only fallback and slow search frustrate users.
- Low-fare airlines respond on price and rail through-fares show no advantage under sum-of-legs.
- Passengers revert to stitched itineraries or flights; distributors deprioritise through-tickets.
- Disability bodies withhold endorsement, creating public criticism.

##### Early Warning Signs
- Pilot conversion no better than stitched-itinerary control
- Itinerary rejection for accessibility above planned levels
- Rising complaint volume in pilot corridors
- Disability bodies decline to endorse the booking flow

##### Tripwires
- Through-ticket pilot conversion <= stitched control at Month 18 (2028-04-12)
- Itinerary rejection >= 15% for accessibility
- Scheduled-only fallback >= 5% of searches
- Through-ticket share < 35% at Month 54 (2031-04-12)

##### Response Playbook
- Contain: Switch accessibility confirmation to best-effort booking with transparent notice while data are gathered.
- Assess: Segment pilot drop-off by cause (price, fallback, accessibility, language) with disability bodies as observers.
- Respond: Adjust neutral display, corridor fare products and fallback design, and revise the planning range with the steering group.


**STOP RULE:** Narrow scope to the corridors with proven conversion if through-ticket share is below 15% (planning range floor, estimate) at Month 48 (2030-10-12).

---

#### FM7 - The Concession Cliff

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Public Reference Distributor Concession Manager & Procurement Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- The EUR 300M envelope has no agreed split between set-up and service payments.
- Bids price platform and multilingual accessible service above forecast.
- Volumes lag because carrier participation is partial.
- Subsidy requests exceed the EUR 60M cap (proposed threshold); overrun of EUR 75-150M (estimate) exceeds headroom.
- The EUR 200M variance trigger cuts concession funding and defers other lines.

##### Early Warning Signs
- Fewer than 3 qualified bidders at market sounding
- Indicative platform set-up cost above business case
- Concession envelope split still undecided at Month 9 (2027-07-12)
- Volume forecast revised downward after pilots

##### Tripwires
- Fewer than 3 compliant bids at tender close in Month 12 (2027-10-12)
- Bid subsidy > EUR 60M over five years
- Quarterly cost > 15% above budget
- Forecast volume < 60% of plan

##### Response Playbook
- Contain: Hold tender award and freeze commitments on the unallocated part of the concession envelope.
- Assess: Rebuild the business case with bid data and test direct public operation at EUR 30-50M (estimate) against subsidy overrun.
- Respond: Re-scope to a lean last-resort service or direct operation and re-baseline under the variance triggers.


**STOP RULE:** Withdraw the concession and operate a minimal public last-resort service if no compliant bid is within the EUR 60M subsidy cap by Month 18 (2028-04-12).

---

#### FM8 - The Handheld That Never Arrived

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Carrier Integration & Technical Onboarding Manager
- **Risk Level:** HIGH 9/25 (Likelihood 3/5 × Impact 3/5)

##### Failure Story
- Retrofit schedules follow depot maintenance cycles the programme does not control.
- Financing of validation hardware remains an open decision.
- Supplier lead times and spare units run short.
- Conductors cannot validate other carriers' tickets; manual workarounds return.
- Corridor go-live at Month 48 (2030-10-12) slips and penalty disputes rise.

##### Early Warning Signs
- No financing decision by Month 9 (2027-07-12)
- Depot slots booked beyond Month 40 (2030-02-12)
- Supplier quotes with lead times above plan
- Audit at Month 30 (2029-04-12) shows low device coverage

##### Tripwires
- Financing decision not taken by Month 9 (2027-07-12)
- Less than 50% of corridor vehicles equipped at Month 30 (2029-04-12) (proposed threshold)
- Less than 80% equipped at Month 35 (2029-09-12) (proposed threshold)
- Retrofit cost estimate > EUR 85M

##### Response Playbook
- Contain: Switch affected corridors to the API handshake or signed journey token so validation does not depend on new hardware.
- Assess: Quantify uncovered vehicles by corridor and carrier, with cost and depot dates.
- Respond: Sequence go-live by corridor readiness and agree a carrier cost-sharing model through the steering group.


**STOP RULE:** Defer go-live on any corridor with under 80% validation coverage at Month 42 (2030-04-12) (proposed threshold).

---

#### FM9 - The Data Backlash

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Data Governance and Privacy Officer
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Shared layers carry booking references and rerouting data across carriers.
- Data-processing roles and retention are unclear.
- Authorities or consumer bodies challenge the flows after launch.
- Carriers and distributors pause integration; public trust falls.
- Rework and delay compress the Month 30 (2029-04-12) to Month 48 (2030-10-12) window.

##### Early Warning Signs
- Impact assessment finds unminimised personal data in shared layers
- Carriers refuse data-processing terms
- Consumer bodies publicly question data use
- Authority queries received on shared layers

##### Tripwires
- Impact assessment not published by Month 3 (2027-01-12)
- Fewer than 8 carriers sign data-processing terms by Month 12 (2027-10-12)
- Any authority enforcement notice on a shared layer
- Personal-data fields in event feed > 0

##### Response Playbook
- Contain: Strip personal data from event feeds and replace with booking tokens immediately.
- Assess: Re-map all data flows, retention periods and controller roles with external counsel.
- Respond: Redesign affected layers, agree joint-controller terms and brief authorities and consumer bodies before Tier 1 exposure.


**STOP RULE:** Suspend shared-layer exposure on any corridor under an authority suspension order until a compliant design is approved.
