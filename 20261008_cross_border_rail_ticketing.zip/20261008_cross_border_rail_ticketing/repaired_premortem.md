A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Incumbent carriers (DB, SNCF, ÖBB) will sign Commitment Letters and accept panel rulings once Council/Commission delegation is granted by Month 2 (2026-12-08). | Hold bilateral sessions with the eight largest carriers in Months 0-1 (2026-10-08 to 2026-11-08) and ask for written preconditions to signing; ask Council Legal Service for a delegation timeline opinion. | Any carrier above EUR 100M cross-border revenue states in writing it will not accept binding rulings or escrow penalties, or Council Legal Service estimates delegation takes more than 4 months. |
| A2 | The EUR 1,500 million cap with EUR 215 million free contingency covers carrier co-funding, distributor operations, hub gaps and payment-fee subsidy without a supplementary authority. | Commission an independent bottom-up cost model by Month 2 (2026-12-08) using binding quotes from 8-12 representative carriers and distributor operator candidates. | Modelled base-case total demand (grants, hubs and accessibility) exceeds the EUR 290 million co-funding line by more than 20%, or distributor cost exceeds EUR 50M/year (estimate). |
| A3 | Travellers will choose a sum-of-segment through-ticket with guaranteed connection over budget flights or separate tickets, sustaining the 40% share target. | Run a conjoint willingness-to-pay survey (300-500 respondents per product) on the four corridors by Month 4 (2027-02-08), then a one-corridor pilot from Month 9 (2027-07-08). | Fewer than 8% of respondents prefer the through-ticket at EUR 70-90, or pilot conversion is under 3% (proposed threshold). |
| A4 | The Regulation will be adopted by Month 9 (2027-07-08) with only minor changes to the May 2026 proposal on liability, data-sharing scope and API exemptions, leaving a workable standards window before Month 18 (2028-04-08). | Open weekly contact with TRAN and IMCO rapporteurs and Council Presidency in Month 0-1 (2026-10-08 to 2026-11-08); map pending amendments against shadow standards drafts. | Rapporteurs or Council signal adoption after Month 10 (2027-08-08), or tabled amendments change liability allocation or API scope materially. |
| A5 | National data protection authorities will accept the cross-border PII flows, Standard Contractual Clauses and EU-wide availability cache by Month 4 (2027-02-08), without imposing data-residency or explicit-consent rules that force redesign. | Run one-to-one pre-engagement sessions with Austria, Germany, France, Poland, Bulgaria and Romania DPAs in Months 1-2 (2026-11-08 to 2026-12-08) using a draft DPIA data-flow map. | Fewer than 8 DPAs give written non-objection by Month 4 (2027-02-08), or any DPA signals a residency or explicit-consent requirement for accessibility data. |
| A6 | Trainline, Omio and other commercial distributors will integrate OSDM APIs and actively promote through-tickets by Month 18 (2028-04-08) in exchange for early API access and co-marketing support (EUR 5-10M), without demanding preferential inventory terms. | Hold structured sessions with Trainline, Omio and two smaller platforms in Month 1 (2026-11-08) to obtain written integration timelines, margin requirements and preconditions. | A major distributor states in writing that integration will not complete before Month 24 (2028-10-08), or conditions participation on preferential or advance inventory access. |
| A7 | The 4 regional hubs can be contracted by Month 3 (2027-01-08) and operational by Month 9 (2027-07-08), and their legacy-to-OSDM mapping will keep booking failures below the 2% threshold (proposed threshold). | Run market sounding and issue the hub RFP in Month 0-1 (2026-10-08 to 2026-11-08); count qualified bidders and have an independent consultant test bid SLAs against 99.9% uptime and 2 h recovery. | Fewer than 3 qualified bidders respond, or no bidder credibly commits to operational start by Month 9 (2027-07-08), or sample mapping tests show failure above 2%. |
| A8 | At least 2 regulated payment institutions will apply, be accredited by Month 8 (2027-06-08) and be operational by Month 12 (2027-10-08), at fees capped at 0.3-0.5% per transaction, with settlement under 48 h. | Publish draft accreditation criteria and fee cap in the Month 0-1 (2026-10-08 to 2026-11-08) market sounding; request written indications of interest and indicative fee quotes from licensed PSD2 institutions. | Fewer than 2 written indications of interest, or indicative fees above 0.7% per transaction, or providers refuse the settlement and dispute SLAs. |
| A9 | Confirmed accessibility assistance (24 h confirmation, delivery above 95%) can be delivered on platforms across borders by carriers and station staff the programme funds only indirectly, with a EUR 12M accessibility programme. | Survey the 8 largest carriers and 4 corridor station operators by Month 3 (2027-01-08) on current assistance confirmation windows, staffing and handover records; pilot one cross-border handover with disability-rights bodies. | Baseline delivery on pilot journeys is below 90%, or carriers state in writing they cannot confirm within 24 h without funding beyond the EUR 12M line. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Vanishing Reserve | Process/Financial | A2 | Budget Controller and Financial Manager | CRITICAL (20/25) |
| FM2 | The Toothless Panel and the Brittle Hubs | Technical/Logistical | A1 | Chief Technical Standards Officer | CRITICAL (20/25) |
| FM3 | The Ticket Nobody Wanted | Market/Human | A3 | Consumer Product and App Development Lead | CRITICAL (16/25) |
| FM4 | The Clock That Stopped in Parliament | Process/Financial | A4 | Programme Director | CRITICAL (15/25) |
| FM5 | The Data Layer That Had to Stay Home | Technical/Logistical | A5 | Data Layer and Real-Time Systems Architect | HIGH (12/25) |
| FM6 | The Platforms That Waited | Market/Human | A6 | Consumer Product and App Development Lead | HIGH (12/25) |
| FM7 | The Single Cashier | Process/Financial | A8 | Clearing and Settlement Mechanism Designer | HIGH (12/25) |
| FM8 | The Hub That Double-Sold the Seat | Technical/Logistical | A7 | Smaller Carriers and Regional Integration Lead | HIGH (12/25) |
| FM9 | The Lift That Was Confirmed But Dead | Market/Human | A9 | Consumer Product and App Development Lead | MEDIUM (8/25) |


### Failure Modes

#### FM1 - The Vanishing Reserve

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: Budget Controller and Financial Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- Co-funding requests from 12-18 hub-eligible carriers (EUR 2-15M bands) exceed the EUR 290M line (EUR 234M grants + EUR 44M hubs + EUR 12M accessibility).
- Distributor scope creeps from EUR 43M/year toward full retail.
- Hub gap (~EUR 1.9M/year) and fee subsidy overrun add to the strain.
- A 20-30% overrun (EUR 300-450M) exceeds the EUR 215M free contingency by EUR 85-235M.
- Tier 2-3 cuts hit conformance testing and capacity building, pushing smaller carriers past Month 30 (2029-04-08).

##### Early Warning Signs
- Quarterly spend above 115% of pro-rata for 1 quarter
- Cumulative co-funding demand above EUR 348M (20% over the EUR 290M line; early warning)
- Distributor run-rate above EUR 50M/year annualised
- Free contingency drawn below EUR 150M before Month 18 (2028-04-08)

##### Tripwires
- Quarterly spend >= 115% of pro-rata (EUR 86.25M vs EUR 75M)
- Cumulative total co-funding demand >= EUR 348M (20% over the EUR 290M line) by Month 12 (2027-10-08) (failure level)
- Free contingency <= EUR 100M before Month 24 (2028-10-08)

##### Response Playbook
- Contain: Freeze new co-funding awards and distributor scope changes within 5 working days; protect conformance testing budget.
- Assess: Rerun the cost model with actual invoices and quotes; quantify the gap against EUR 215M free contingency within 10 working days.
- Respond: Apply Tier 2-3 responses and submit a supplementary authority request to DG MOVE; re-sequence hubs to priority corridors.


**STOP RULE:** Pause new commitments and re-baseline the programme if projected overrun exceeds EUR 215M free contingency by Month 24 (2028-10-08) with no approved supplementary authority.

---

#### FM2 - The Toothless Panel and the Brittle Hubs

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A1
- **Owner**: Chief Technical Standards Officer
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- Delegation lands late or advisory; carriers contest rulings on inventory parity and latency.
- Standards slip past Month 18 (2028-04-08) or are issued without consensus.
- Legacy carriers rely on hubs; mapping errors cause 2-5% booking failures.
- Dual-run windows are compressed by late standards.
- Smaller carriers miss Month 30 (2029-04-08); bookable corridor traffic falls below 90%.

##### Early Warning Signs
- Delegation not signed by Month 2 (2026-12-08)
- Major carrier refuses Commitment Letter
- Hub operational start slips past Month 9 (2027-07-08)
- Mapping defects found in dual-run testing

##### Tripwires
- Delegation unsigned at Month 2 (2026-12-08)
- Fewer than 95% of carriers above EUR 50M signed by Month 3 (2027-01-08)
- Hub booking-failure rate > 2% for more than 7 days

##### Response Playbook
- Contain: Suspend onboarding to any hub above the 2% failure threshold and pause carrier commitments if delegation is unsigned.
- Assess: Audit failed mappings and contested rulings; quantify impact on corridor bookability within 2 weeks.
- Respond: Escalate to the Commission with enforcement options; route affected carriers via gateway or bilateral pairing.


**STOP RULE:** Escalate to a Steering Committee re-baseline if any top-5 carrier remains unsigned at Month 4 (2027-02-08) or bookable corridor traffic is projected below 80% at Month 24 (2028-10-08) (projection gate; target 90% at Month 30 (2029-04-08), 80% there is a severe case).

---

#### FM3 - The Ticket Nobody Wanted

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Consumer Product and App Development Lead
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Through-fares of EUR 70-90 (estimate) lose to budget flights at EUR 40-70.
- Distributors lack margin incentive and delay promotion.
- Airlines respond with lower fares and more frequency.
- Share stalls at 15-25% instead of 40%; modal shift stays under 10%.
- Falling volumes raise pressure to fund subsidies not in the cap.

##### Early Warning Signs
- Survey preference below 8%
- Pilot conversion below 3%
- Trainline or Omio integration delays
- Share below 15% at Month 24 (2028-10-08)

##### Tripwires
- Willingness-to-pay preference < 8% at Month 4 (2027-02-08)
- Pilot conversion < 3% at Month 12 (2027-10-08)
- Through-ticket share < 15% at Month 24 (2028-10-08)

##### Response Playbook
- Contain: Stop scaling marketing spend beyond the pilot corridor until demand evidence is in.
- Assess: Segment results by corridor, traveller type and price point; model airline response within 4 weeks.
- Respond: Refocus on corridors with weak air competition and take a decision on fare support or target reset to the Steering Committee.


**STOP RULE:** Re-scope the 40% target or fund fare support via a new decision if share is below 8% at Month 24 (2028-10-08) or modal shift is under 10% at Month 48 (2030-10-08).

---

#### FM4 - The Clock That Stopped in Parliament

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Programme Director
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Parliament and Council amendments delay adoption beyond Month 10 (2027-08-08).
- Adoption at Month 9 (2027-07-08) leaves 9 months to Month 18 (2028-04-08); each month of slip removes one month (Month 12 = 2027-10-08 leaves 6; Months 14-15 = 2027-12-08 to 2028-01-08 leaves 3-4), adding rework risk and lost margin.
- Final text changes liability or data scope, forcing rework of settlement rules and contracts.
- Paid teams, hub and payment contracts idle or re-scoped, burning budget without delivery.
- Month 18 (2028-04-08) and Month 30 (2029-04-08) milestones slip.

##### Early Warning Signs
- Committee vote not scheduled by Month 6 (2027-04-08)
- Tabled amendments on liability or API exemptions
- Council Presidency leaves text unresolved after two meetings
- Shadow standards drafts diverge from amended text

##### Tripwires
- Regulation not adopted by Month 9 (2027-07-08)
- Adoption probability <= 70% at Month 6 (2027-04-08) (proposed threshold)
- Material text divergence in >= 2 of 4 areas: liability, data scope, API scope, access definition

##### Response Playbook
- Contain: Pause new carrier onboarding commitments and hold uncommitted contract awards within 5 working days of the Month 10 (2027-08-08) gate.
- Assess: Compare final or draft text against shadow standards and quantify rework, cost and milestone impact within 3 weeks.
- Respond: Contract the external standards consortium and re-baseline the critical path with the Steering Committee, resequencing Month 18 (2028-04-08) deliverables.


**STOP RULE:** Pause carrier onboarding and re-baseline the critical path if the Regulation is not adopted by Month 10 (2027-08-08); consider programme restructuring if still unadopted at Month 12 (2027-10-08).

---

#### FM5 - The Data Layer That Had to Stay Home

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Data Layer and Real-Time Systems Architect
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- One or more DPAs impose data residency or explicit-consent rules.
- Central availability cache must be re-architected to federated queries, adding search latency.
- p95 latency exceeds the 2 s SLA; timeouts rise.
- Payment accreditation stalls because providers need clear data governance.
- Redesign of API hosting and hub mappings delays Month 30 (2029-04-08) readiness.

##### Early Warning Signs
- DPA requests additional safeguards or local storage
- EDPB escalates SCC question to plenary
- Payment applicants ask for data-governance clarity
- Latency tests on federated prototype above 2 s

##### Tripwires
- < 8 DPA written non-objections at Month 4 (2027-02-08)
- Any DPA stop order or residency demand before Month 12 (2027-10-08)
- Federated prototype p95 latency > 2 s in load tests

##### Response Playbook
- Contain: Freeze cache procurement commitments and cross-border transfers in the affected jurisdiction within 5 working days.
- Assess: Test federated and hybrid architectures against SLAs and quantify redesign cost and delay within 4 weeks.
- Respond: Escalate to EDPB for expedited guidance and adopt hybrid design with minimum-necessary PII, re-plan accreditation gate.


**STOP RULE:** Adopt a federated-only architecture and re-baseline Month 30 (2029-04-08) scope if a major DPA blocks cross-border flows and no EDPB resolution is obtained by Month 8 (2027-06-08).

---

#### FM6 - The Platforms That Waited

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Consumer Product and App Development Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Commercial distributors delay integration to protect margins and own IT backlogs.
- Demands for preferential inventory access are viewed as discriminatory by regulators.
- Low commercial promotion leaves through-ticket share under 15% at Month 24 (2028-10-08).
- Public reference distributor expands beyond EUR 215M plan, drawing on free contingency.
- Airlines gain share while rail visibility stays low.

##### Early Warning Signs
- No signed integration roadmap by Month 6 (2027-04-08)
- Distributors miss conformance test slots
- Co-marketing offers declined or renegotiated
- Preferential access demands raised in working group

##### Tripwires
- < 2 major distributors with signed roadmaps by Month 6 (2027-04-08)
- Distributor integration readiness < 50% at Month 18 (2028-04-08)
- Reference distributor run-rate >= EUR 50M/year annualised

##### Response Playbook
- Contain: Withhold co-marketing funds and early API access from non-committing distributors; cap reference distributor scope at the planned run-rate.
- Assess: Interview each distributor on margin, backlog and blockers; model share impact and public distributor cost within 4 weeks.
- Respond: Offer certified tier incentives or margin support within the non-discrimination rules, and escalate persistent refusals to the arbitration panel and regulators.


**STOP RULE:** Reassess the commercial distribution model if fewer than 2 major distributors are live by Month 24 (2028-10-08) and through-ticket share is below 8%.

---

#### FM7 - The Single Cashier

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A8
- **Owner**: Clearing and Settlement Mechanism Designer
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Accreditation draws 0-1 qualified providers; data-governance ambiguity deters applicants.
- Fallback to bilateral settlement slows payouts and refunds beyond 48 h and 10 days.
- Sole-provider failure costs EUR 5-10M (estimate) to switch.
- Fees above cap shift costs to carriers and distributors.
- Settlement not ready weakens the Month 30 (2029-04-08) mandate.

##### Early Warning Signs
- Fewer than 2 applicants at Month 6 (2027-04-08)
- Indicative fees above 0.7%
- DPIA unresolved when applicants ask for data clarity
- Settlement dry-run misses 48 h target

##### Tripwires
- Fewer than 2 applicants by Month 6 (2027-04-08)
- Fee quotes >= 0.7% per transaction
- Fewer than 2 providers operational at Month 12 (2027-10-08)

##### Response Playbook
- Contain: Freeze the fee subsidy commitment and open bilateral settlement with a common message standard within 10 working days.
- Assess: Interview non-applicants and quantify settlement delay, refund backlog and switching cost within 3 weeks.
- Respond: Run emergency procurement using the EUR 10M clearing reserve and escalate any excess to free contingency via DG MOVE.


**STOP RULE:** Do not open any corridor to through-ticket sales if no accredited or fallback settlement achieves under 48 h in dry-run by Month 18 (2028-04-08).

---

#### FM8 - The Hub That Double-Sold the Seat

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Smaller Carriers and Regional Integration Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Hub procurement slips past Month 3 (2027-01-08), compressing integration.
- Legacy mapping errors (restrictions, seat allocation) oversell inventory.
- Failure rate above 2% forces onboarding suspension.
- Hub outage strands 4-6 dependent carriers for up to 48 h (estimate).
- Smaller carriers miss Month 30 (2029-04-08); bookable traffic falls below 90%.

##### Early Warning Signs
- Hub contracts unsigned at Month 3 (2027-01-08)
- Mapping defects in external validation
- Dual-run failure rate above 0.5%
- Carrier coordinators not hired by Month 4 (2027-02-08)

##### Tripwires
- Fewer than 3 qualified hub bidders
- Hub not operational at Month 9 (2027-07-08)
- Booking-failure rate > 2% for more than 7 days

##### Response Playbook
- Contain: Suspend new carrier onboarding to the failing hub and revert affected carriers to dual-run mode.
- Assess: Replay failed bookings against carrier inventory and size refund exposure and delay per carrier within 2 weeks.
- Respond: Route affected carriers via gateway or bilateral pairing from free contingency and re-contract or consolidate the hub.


**STOP RULE:** Drop a hub from the Month 30 (2029-04-08) plan if its failure rate stays above 2% after two 4-week remediation cycles.

---

#### FM9 - The Lift That Was Confirmed But Dead

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Consumer Product and App Development Lead
- **Risk Level:** MEDIUM 8/25 (Likelihood 2/5 × Impact 4/5)

##### Failure Story
- Assistance is confirmed before payment but not delivered at stations.
- Cross-border handovers fail between carriers and stations.
- Disability-rights bodies and BEUC publicise failures and file complaints.
- Distributors drop accessible itineraries, narrowing options.
- Reputational harm erodes political support and complaint-halving target.

##### Early Warning Signs
- Pilot delivery rate below 90%
- Carriers cannot meet 24 h confirmation
- Accessibility data incomplete at launch
- Formal complaint from a disability-rights body

##### Tripwires
- Assistance delivery < 95% for 2 consecutive months
- Confirmation rate < 90% at Month 18 (2028-04-08)
- Assistance complaint rate >= 2%

##### Response Playbook
- Contain: Suspend assistance bookings on the failing corridor handover and notify affected passengers within 24 h.
- Assess: Audit failed handovers with carriers and disability-rights bodies and classify causes within 3 weeks.
- Respond: Fund staffing or equipment fixes via the accessibility line, withhold co-funding tranches from non-compliant carriers, and publish corrective plan.


**STOP RULE:** Hold corridor go-live for assisted journeys if delivery stays below 90% after a 4-week remediation cycle.
