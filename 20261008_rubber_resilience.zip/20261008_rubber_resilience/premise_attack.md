### Premise Attack 1 — Integrity
_Forensic audit of foundational soundness across axes._

**[STRATEGIC] A single $30 billion, 25-year program bundles a global quarantine treaty, multi-decade tree breeding, and two unrelated alternative crops under gates that can only be passed on paperwork, so it buys the appearance of resilience against a pathogen that has not yet arrived in the main producing regions.**

**Bottom Line:** REJECT: A $30 billion, 25-year bundle whose central gate is an unobservable negative, and whose pieces run on incompatible clocks and serve different farmers, does not deserve to exist as one program.


#### Reasons for Rejection

- The success metric, 'verified containment', is a non-event, so the funding gates at Years 3/7/12/18 (Months 36/84/144/216 = 2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12) can only be cleared on protocol adoption counts, inspections and red-team drills, never on a measured reduction in risk.
- 'Globally adopted' harmonization is a precondition for any scale-up, so one sovereign holdout among rubber-producing states stalls the guayule and dandelion build-out; the alternative-crop workstreams are hostage to quarantine diplomacy they do not depend on technically.
- Hevea breeding for SALB-resistant, yield-parity cultivars runs on tree-crop cycles of decades (estimate), so a Year 7 or Year 12 'cultivar readiness' gate measures lab milestones rather than field-proven clones.
- Designing 'the whole program around smallholder adoption' misfires because guayule is placed in arid zones and Russian dandelion in temperate climates, which are not where tropical Hevea smallholders farm; the alternative crops displace those farmers instead of serving them.
- Public money would underwrite 'colocated processing and OEM offtake' for crops that tire makers already fund privately, so the program socializes the risk of corporate pipelines whose own timelines already target roughly 2030.

#### Second-Order Effects

- 0–6 months: Ministries, tire OEMs and research institutes spend the first half-year negotiating the protocol text and governance seats, while restrictions on moving research materials start to slow existing breeding exchanges before any resistant cultivar exists.
- 1–3 years: The Year 3 (Month 36 = 2029-10-12) gate is passed on documented adoption and drill completion, releasing scale-up money to guayule and dandelion plots that compete with food crops and scarce irrigation water.
- 5–10 years: Either SALB never reaches the main producing regions and the program becomes a permanent, hard-to-sunset insurance premium with entrenched beneficiaries, or it arrives despite the protocol and the containment claim fails publicly while cultivars are still unproven.

#### Evidence

- Case/Incident — Fordlândia and Belterra plantations (1927–1943): SALB destroyed both Ford rubber plantations once the trees matured, which shows the pathogen's damage has always been in-region and crop-specific, not a problem solved by diversifying into other crops.
- Law/Standard — Nagoya Protocol on Access and Benefit-sharing (2014): it makes each germplasm access a benefit-sharing negotiation, which sits uneasily with a program that also needs unrestricted global movement of cultivars.
- Case/Incident — Bridgestone guayule research farm, Eloy, Arizona (2010s–2020s): the company reports spending of more than $100 million and a goal of commercializing guayule rubber by 2030, i.e. private capital is already carrying this pipeline.



### Premise Attack 2 — Accountability
_Rights, oversight, jurisdiction-shopping, enforceability._

**[STRATEGIC] — Quarter-Century Fire Drill: a $30 billion, 25-year program (user constraint) is built to insure against a leaf blight that has not reached the Asian and African plantations producing most of the world's natural rubber, then chains a global treaty, a decades-long breeding effort and two crops that have stayed at pilot scale into one gated bundle, so the bill is certain while the outbreak it insures against is hypothetical.**

**Bottom Line:** REJECT: Quarter-Century Fire Drill commits $30 billion to rehearse an outbreak that has not happened while the substitutes it relies on remain unproven, and the premise rewards the sponsors for risk they would not otherwise carry. A fire drill that costs more than the building and runs for 25 years should not exist.


#### Reasons for Rejection

- Millions of smallholders are cast as adoption targets for replant finance, clean-plant networks and price tools under a 25-year scheme designed by funders and tire makers, while the Brazilian communities and ecosystems behind the bio-prospecting are reduced to inputs whose consent is handled as a compliance checkbox.
- A 'globally adopted' containment protocol has no body that can compel sovereign rubber-producing states to inspect, report or accept drills, and the program's own gates at Years 3/7/12/18 are scored on KPIs that the program itself defines, so nobody outside the project is positioned to say it failed.
- Moving nursery stock and research materials that may carry the pathogen, and converting arid and temperate land to guayule and dandelion, creates new routes for the very disease it targets and for land-use change, and a release of resistant cultivars cannot be recalled if the fungus overcomes the resistance.
- The value case is rotten at the core: it spends public money to buy decades of insurance against an event with no confirmed date, backs substitute crops that have not reached cost parity after more than a decade of corporate pilots, and uses OEM offtake agreements to move tire makers' supply-chain risk onto taxpayers.

#### Second-Order Effects

- **Months 0–12 (2026-10-12 to 2027-10-12) — The Cracks Appear:** Producing countries read the containment protocol as a foreign inspection regime over their germplasm and plantations, and negotiations stall over who inspects whom and who pays when a shipment is held.
- **Months 12–60 (2027-10-12 to 2031-10-12) — Copycats Arrive:** Every commodity with a single-crop exposure (palm oil, cocoa, bananas) gets its own pitch for a multi-decade, multi-billion-dollar 'diversification' program, and subsidy competition replaces actual risk ranking.
- **Months 60–180 (2031-10-12 to 2041-10-12) — Norms Degrade:** Smallholders who replanted into program-backed alternatives and price tools carry the debt and the price risk when the substitute crops miss cost parity, teaching farmers that donor-designed transitions are a trap.
- **Months 180–300 — The Reckoning:** The disease either never arrives and the program is remembered as a quarter-century subsidy for tire makers, or it arrives through a route nobody drilled for and the stockpiled assurance proves worthless.

#### Evidence

- Case/Report — Fordlandia: Ford's Brazilian rubber plantation, founded in the late 1920s, was crippled by leaf blight in dense monoculture and was handed back to Brazil in the 1940s, showing that the disease defeats even well-funded, centrally managed planting schemes.
- Case/Report — FAO documentation on SALB: states that the disease can cut latex yield by as much as 70%, that Asia and Africa remain free of it, and that Asian producers supply more than 90% of natural rubber, which confirms both the stakes and the fact that the outbreak is still hypothetical there.
- Law/Standard — Nagoya Protocol on Access and Benefit-Sharing under the Convention on Biological Diversity: requires prior informed consent and mutually agreed terms for genetic resources and associated traditional knowledge, which a program-level 'compliant' label cannot substitute for on a resource-by-resource, community-by-community basis.
- Case/Report — Continental's Taraxagum project and Bridgestone's guayule pilot farm: both remain research and pilot efforts, with Continental describing serial production as a goal within roughly ten years of its 2016–2020 statements; current commercial scale in 2026 is (not verified).



### Premise Attack 3 — Spectrum
_Enforced breadth: distinct reasons across ethical/feasibility/governance/societal axes._

**[STRATEGIC] A $30 billion, 25-year program fuses a protocol no sponsor can compel with three crop bets no sponsor can time or price, under one gate-driven budget.**

**Bottom Line:** REJECT: A single $30 billion, 25-year wager that depends on sovereign adoption, unproven cultivars and subsidized alternative crops is a promise of managed disappointment, not a defense against leaf blight.


#### Reasons for Rejection

- Governance: the non-negotiable Phase 1 deliverable is a 'globally adopted' containment protocol, yet adoption rests entirely with sovereign plant-protection agencies that the program cannot compel, so the Year 3 gate measures diplomacy rather than containment.
- Scope and budget: one $30 billion envelope (about $1.2 billion a year, recomputed) bundles containment, Hevea breeding, guayule and Russian dandelion, four unrelated bets with different failure modes, so a single stumble can freeze the other three through shared gates.
- Biology and time: delivering SALB-resistant, yield-parity Hevea cultivars means breeding and field-testing a perennial tree whose tapping maturity alone runs roughly 5-7 years (estimate), which collides with the Year 7 cultivar-readiness gate before any clone has proven itself under real disease pressure.
- Market economics: guayule and Russian dandelion must beat plantation Hevea on cost and quality at commodity prices, and OEM offtake agreements plus smallholder 'price-stability tools' obligate the program to subsidize a price gap for the full 25 years.
- Self-inflicted risk: the program must move nursery stock, research materials and contaminated equipment between South America and the producing regions it claims to protect, so its own germplasm exchange and red-team drills become the most plausible introduction pathway for the pathogen.

#### Second-Order Effects

- 0–6 months: Public funders, OEMs and Brazil-led benefit-sharing negotiators spend the opening half-year fighting over control of the $30 billion and authorship of the protocol, while smallholders are promised replant finance that has no mechanism behind it.
- 1–3 years: The Year 3 gate arrives with the protocol signed by some governments and inspected by few, forcing sponsors to declare success on paperwork or freeze funds, and either choice teaches national agencies that signatures, not surveillance, unlock money.
- 5–10 years: Cultivars miss the Year 7 gate, colocated guayule and dandelion processing plants sit underused when Hevea prices fall, and smallholders who replanted on unproven clones absorb the loss while the program's 25-year commitments remain on the books.

#### Evidence

- Case/Incident — Fordlandia and Belterra plantations (1927–1945): Ford's large Brazilian Hevea plantings were crippled by South American leaf blight, showing that concentrated planting of one tree crop invites exactly the disease this program claims to control.
- Case/Incident — U.S. Emergency Rubber Project (guayule) and Soviet kok-saghyz program (1940s): both wartime alternative-rubber efforts worked technically but were abandoned in the late 1940s once Asian Hevea plantations were rebuilt with superior economics.
- Law/Standard — International Plant Protection Convention, revised text (1997): phytosanitary standards are adopted by consensus and implemented through national plant protection organizations, so no program can enforce a single global containment regime.



### Premise Attack 4 — Cascade
_Tracks second/third-order effects and copycat propagation._

**The plan spends a $30 billion (user constraint) sovereign-scale budget to insure against a pathogen that has never left its native range, while making a globally adopted protocol (which no single funder can compel) the gate for everything else. The "alternatives" it funds are grown on different land, by different people, at higher cost than the tropical smallholders it claims to protect, and it ignores the synthetic rubber that already works as the market's hedge. This is a strategic flaw: a coherent-sounding risk narrative wrapped around a program that cannot be governed, measured, or sequenced.**

**Bottom Line:** Abandon the premise: a single protocol-gated, 25-year, $30 billion (user constraint) program cannot govern sovereign quarantine regimes, cannot prove its main KPI, and funds alternative crops that compete with the smallholders it says it serves while overlooking the synthetic-rubber hedge that already exists. The failure is in the premise itself, which treats a remote, unmaterialized pathogen as a funding mandate for building a parallel global industry.


#### Reasons for Rejection

- The Sovereign Veto Ladder: Phase 1's "non-negotiable" deliverable is a protocol adopted globally and harmonized with existing regional phytosanitary regimes. Every producing state (Thailand, Indonesia, Vietnam, Malaysia, India, West and Central African producers, Brazil) holds an effective veto over the gate that releases all downstream money. FAO material already records that Asian producers, which supply over 90% of natural rubber, run their own quarantine regimes and regard SALB as an existential threat. The plan assumes they will subordinate those regimes to a funder-designed document. The most likely outcomes are a lowest-common-denominator text or an indefinite stall, and either outcome makes the Year-3 gate unpassable or meaningless.
- The Pathogen Courier Paradox: The program is built to move Hevea germplasm, nursery stock, research material and scientists between Amazonian SALB hot zones and Asian and African breeding stations, which is the very pathway the protocol is meant to close. Resistance screening requires live Microcyclus ulei isolates, red-team drills require simulated breaches, and bio-prospecting requires wild-collected tissue. The initiative would become the single largest concentrated introduction risk for the disease it exists to prevent, and "verified containment" would depend on a quarantine record that the program itself is stressing.
- The Wrong-Latitude Rescue: Guayule (arid zones) and Russian dandelion (temperate) are grown on different continents' farmland, by mechanized commercial growers, with processing colocated far from tropical rubber belts. The smallholders the plan promises to design around (replant finance, clean-plant networks, price-stability tools) are tropical Hevea growers. Every ton of alternative rubber that reaches OEM offtake displaces a ton of tropical smallholder output. The program thus funds the livelihoods of one population while building the competitor that erodes them, and its smallholder-adoption design cannot apply to the crops it commercializes.
- The Gate-Clock Desync: Funding gates at Years 3, 7, 12 and 18 are tied to cultivar readiness and alternative-rubber cost/quality, but the underlying clocks run on different cycles. Hevea is a perennial tree crop with long selection and field-trial cycles, and resistance must be proven against a variable fungus under multi-site field pressure, so the gate dates are administrative rather than biological. The first real data on yield-parity resistant clones will arrive after the Year-7 gate, forcing the funders to either release money on proxies or terminate on schedule artefacts. "Verified containment" is also a negative-result KPI: no outbreak has occurred outside the Americas in the historical record, so a clean record is non-informative and cannot discriminate between a working protocol and luck.
- The Synthetic Shadow Hedge: The plan treats Hevea as a single-point-of-failure with no existing fallback, but synthetic rubber already supplies roughly half of global elastomer demand (estimate, not verified) and is the actual buffer against a natural-rubber shock. Guayule and dandelion must therefore compete not with a collapsed Hevea market but with petrochemical butadiene rubber and with a Hevea price that, in an outbreak, would spike only briefly before synthetic substitution and surviving plantations adjust. Funding the third-best hedge at $30 billion (user constraint) while excluding the first, and offering no mechanism for OEMs to honour offtake when spot prices fall below alternative-rubber cost, is a basic market-structure error.

#### Second-Order Effects

- Within 6-12 months (Months 0-12 = 2026-10-12 to 2027-10-12): Rushed convening of a multi-state standards body produces competing drafts. Asian producers, which already operate national import controls, treat the program as a Western/Brazilian funder-driven overreach; the "harmonized" protocol is negotiated down to a voluntary guidance note. Clean-plant and surveillance spending begins before any binding text exists.
- Within 1-3 years (Months 12-36 = 2027-10-12 to 2029-10-12): The Year-3 gate (Month 36 = 2029-10-12) forces a choice between certifying a non-binding protocol as "adopted" (hollow gate) or withholding scale-up funds (program freeze). Either way, the breeding and alternative-rubber tracks, which were supposed to be parallel, are pulled into the protocol's political calendar. Germplasm exchanges under the new access-and-benefit-sharing arrangements begin and produce the first quarantine near-misses and documentation disputes.
- Within 3-7 years (Months 36-84 = 2029-10-12 to 2033-10-12): Guayule and dandelion pilots reach commercial-scale plant construction without cost parity (estimate), and OEM offtake agreements, signed at premium prices, become either subsidized purchases or breached contracts when tropical Hevea prices fall. Tropical smallholder organizations, courted for replant finance, discover that the program's offtake is for crops that compete with them; political support in producing countries erodes. The Year-7 gate (Month 84 = 2033-10-12) arrives with partial cultivar data and a spent first-phase budget.
- Within 7-12 years (Months 84-144 = 2033-10-12 to 2038-10-12): Under gate pressure, the program certifies resistant clones on limited-site data. Any clone deployed at scale in Asia or Africa on thin field evidence risks resistance breakdown (as happened with earlier Americas clones) and, worse, creates a new incentive to move live-pathogen material for confirmation trials. A single quarantine failure or a credible-sounding rumour of one triggers rubber-market volatility and export-ban threats that damage the very supply security being built.
- Within 12-25 years (Months 144-300): Surviving components become permanent subsidies: processing plants in arid and temperate regions stay open on policy support, the protocol exists as an under-enforced standard, and Hevea remains the dominant fiber of the market. If SALB ever does arrive, the response will depend on national agencies and existing plantation management, not the program's parallel supply chains, which will be too small to matter. The $30 billion (user constraint) has bought a standing bureaucracy and a few niche specialty-rubber businesses.

#### Evidence

- Fordlândia and Belterra: Henry Ford's Amazonian rubber plantations (1928 onward, abandoned and sold in 1945) were crippled by leaf blight in dense monoculture stands, the canonical demonstration that growing Hevea in the pathogen's home range without durable resistance fails regardless of capital. Source for the underlying pathogen biology: FAO documentation that SALB prevented a viable neotropical rubber industry ([FAO](https://www.fao.org/4/i2157e/i2157e00.htm)). The Ford dates are well documented but were not re-verified in this search.
- FAO and IPPC material shows the Asian rubber-producing countries (over 90% of world natural rubber) already treat SALB as a threat and run national quarantine and surveillance, which is precisely the sovereign authority that a "globally adopted" protocol has to displace or harmonize with ([FAO](https://www.fao.org/4/i2730e/i2730e04.pdf)).
- Guayule and Russian dandelion have been in funded corporate and academic development for well over a decade: Bridgestone's pilot farm and process research centre in the US Southwest, Cooper Tire's guayule work with Yulex and PanAridus from 2012, and the Ohio State PENRA dandelion program with Bridgestone, with "larger-scale testing" planned for 2014 ([Tyrepress](https://www.tyrepress.com/2012/05/bridgestone-says-russian-dandelions-may-be-sustainable-source-of-natural-rubber/)). Despite this long runway, no tire-grade alternative has displaced Hevea at commercial volume (not verified against current production data).
- Wartime precedents: the US Emergency Rubber Project guayule plantings (1942) and the Soviet kok-saghyz (Russian dandelion) campaigns were abandoned once synthetic rubber capacity scaled and became cheaper, showing that alternatives of this type are strategic only until the petrochemical substitute exists (historical record; specifics not verified in this search).



### Premise Attack 5 — Escalation
_Narrative of worsening failure from cracks → amplification → reckoning._

**[STRATEGIC] — Trojan Hedge: A program that must carry Hevea germplasm, nursery stock and research materials across the Amazon-to-Asia boundary to insure against South American Leaf Blight institutionalizes the very pathway of introduction it claims to close, and chains that risk to substitute crops that have stayed pre-commercial for decades.**

**Bottom Line:** REJECT: This is a hedge that moves the hazard, bundles unproven bets under an unfalsifiable success label, and asks smallholders and public funders to underwrite a risk that no one in the structure can be held accountable for. The gate is closed.


#### Reasons for Rejection

- The program turns smallholders, who grow most of the world's natural rubber (share not verified), into the adoption frontline, so they absorb replant debt, cultivar failure and price risk for a hedge whose benefits flow mainly to tire OEMs and importing states; their livelihoods become collateral for a 25-year experiment.
- A 'globally adopted' protocol has no sovereign enforcer, and its gates at Years 3/7/12/18 would score 'containment performance', which is the absence of an event and cannot be falsified; the funders, the protocol's authors and the auditors would effectively judge themselves, with no one answerable when a spore crosses a border.
- Concentrating resistant germplasm, clean-plant networks and live-pathogen red-team drills inside one harmonized, globally funded system creates a single point of failure, and a single resistant cultivar rolled out at scale recreates the monoculture that SALB exploits, while guayule and dandelion fields bring their own new monocultures and pathogens.
- Promising 'yield-parity' resistant cultivars and cost-competitive alternatives inside a 25-year, $30 billion (user constraint) envelope is hubris dressed as de-risking; it bundles four unproven bets under one success label and lets public money subsidize commercial pursuits that corporate balance sheets are already funding.

#### Second-Order Effects

- T+0–6 months — The Cracks Appear: Producer governments in Asia refuse to sign a protocol drafted around a Brazil-led germplasm pipeline, and the 'non-negotiable' Phase 1 deliverable stalls; bio-prospecting and breeding spend begins anyway, so live Hevea material moves before any containment regime binds anyone.
- T+1–3 years — Copycats Arrive: Rival national programs, tire-maker consortia and proprietary clone breeders launch parallel efforts, access-and-benefit-sharing disputes over wild Amazonian accessions multiply, and each bloc builds its own nursery-stock channel outside the harmonized protocol.
- T+5–10 years — Norms Degrade: Gate criteria are quietly redefined so funding can continue, containment metrics collapse into self-reported paperwork, drills become ritual, and smallholders hold debt on clones whose resistance is eroding while guayule acreage idles whenever oil-linked synthetic rubber gets cheap.
- T+10+ years — The Reckoning: Either an outbreak is traced to a program-sanctioned channel with no accountable party, or the pathogen never arrives and the effort is written off as an enormous waste; in both cases trust in international phytosanitary cooperation is the casualty.

#### Evidence

- Law/Standard — Nagoya Protocol on Access and Benefit-Sharing (under the Convention on Biological Diversity) and Brazil's domestic Law 13.123/2015 bind genetic-resource access to prior consent and benefit-sharing terms; a globally harmonized industrial germplasm pipeline collides with these sovereign and community claims.
- Case/Report — FAO's 'Protection against South American leaf blight of rubber in Asia and the Pacific region' records that Asian producers supply over 90 percent of natural rubber and already treat the pathogen as a quarantine concern (Singapore lists Microcyclus ulei as a quarantine pest via IPPC); regional quarantine machinery exists, and a new global protocol adds layers without adding enforcement power.
- Case/Report — Bridgestone has pursued guayule since 2012 (Mesa research center, 281-acre Eloy farm, more than $100 million invested, first guayule tire in 2015) and still targets commercial production only by the end of the decade; Continental has researched Russian dandelion rubber since 2011 and projected industrialization years beyond its 2019 test tires. A decade or more of deep-pocketed private effort has not yet produced commercial scale.
- Case/Report — Ford's Fordlândia and Belterra plantations in the Brazilian Amazon were crippled by South American leaf blight in the 1930s–40s, and later resistance bred into clones was repeatedly overcome as the pathogen's races adapted; resistance is a moving target and not a deliverable that can be gated on a schedule.