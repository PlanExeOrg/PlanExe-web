31 explicit calculations found in the documents were re-computed without an LLM; 1 do not match their stated result.

| Section | Statement | Stated | Computed |
|---|---|---|---|
| Assumptions | the program risks either gate disputes that delay funding (3–6 month latency × $500M–$1B tranches = $250M–$500M cost) | $250M–$500M | 1.5B–6B |
