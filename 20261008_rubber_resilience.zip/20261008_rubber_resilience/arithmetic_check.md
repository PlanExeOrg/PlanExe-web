41 explicit calculations found in the documents re-computed without an LLM; 2 do not match their stated result.

| Section | Statement | Stated | Computed |
|---|---|---|---|
| Canonical Facts | containment 0.6 (adoption support 2% of cap) + 0.125 enforcement + 0.075 surveillance + 0.5 compensation fund = 1.3 | 1.3 | 0.7 |
| Review Plan | Current framework allocates gate tranches through Month 216 (2044-10-12) (Year 3/7/12/18 = USD 7.0B/6.5B/4.5B/4.0B) totalling USD 22.0B | 18 | 5.988e-20 |
