# Governance Audit


## Audit - Corruption Risks

- Protocol enforcement officials at borders and nurseries accepting bribes to permit contaminated material across checkpoints, undermining SALB Containment Protocol credibility and creating undetected incursion pathways. Risk heightened in weak-capacity countries where inspector salaries are low and informal payments common.
- Nepotism in cultivar-release decisions: Technical Panel members with financial interest in competing breeding consortia or seed suppliers recommending advancement of inferior candidates connected to family or institutional allies, causing gate failures and wasted investment.
- Kickbacks to processing hub operators or equipment suppliers: Discretionary spending during alternative-rubber hub construction (capex USD 300M per hub estimate) creates opportunities for inflated invoices, phantom equipment purchases, or diverted materials, with collusive inspectors signing off.
- Germplasm access violations: Researchers or collecting teams bypassing Nagoya Protocol agreements and benefit-sharing commitments to access wild Hevea in protected territories, creating legal liability and potential repatriation claims that halt breeding progress or consume dispute-resolution budgets.
- Smallholder loan diversion: Replanting finance (7–10 year tenor loans) intended for certified clean-plant stock diverted by borrowers or complicit rural lenders to personal consumption or informal lending, reducing clean-plant adoption and breaking surveillance incentive chain.
- Trading favors between funding-gate decision-makers and OEM procurement teams: Secretariat or Technical Panel members pre-announcing gate outcomes to tier-one OEMs before formal decisions, allowing front-running of offtake agreements or competitive advantage in qualification testing.

## Audit - Misallocation Risks

- Double-spending on pilot infrastructure: USD 3–5M high-containment trial stations approved and funded simultaneously at the same geographic sites (e.g., two facilities in Rondônia) without coordination, creating redundant capex and stranded assets post-Month 36 (2029-10-08) gate.
- Budget orphaning in capacity-building: Phytosanitary inspector training funded at USD 20–50M for weak-link countries (Africa, South Asia) but salaries not guaranteed post-Month 36 (2029-10-08); trained inspectors depart for private sector within 12–18 months, wasting training investment and leaving checkpoints unstaffed.
- Germplasm collection scope creep: Nagoya Protocol agreements capping collection at 200 accessions by Month 18 (2028-04-08) (proposed threshold) revised upward mid-program to 400+ without corresponding budget and timeline adjustments, delaying breeding by 6–12 months while budgets intended for other pillars are reallocated.
- Alternative-rubber hub over-capitalization: Processing plant cost per unit escalates from USD 300M (estimate) to USD 400–500M due to site-specific environmental or labor conditions, or unplanned regulatory upgrades, consuming 50–100% more of the USD 7.5B pillar budget (25% of USD 30B cap) than planned, starving smallholder finance pillar.
- Contingency pool misuse for non-emergency spending: USD 4.5B contingency pool (15% of cap, decision) and USD 0.5B outbreak reserve (decision) reallocated ad hoc to cover normal operations cost overruns (e.g., staff inflation, equipment maintenance) rather than held for true crises, leaving reserves depleted before Month 60 (2031-10-08) incursion risk.
- Smallholder premium payments without verification: Surveillance premiums (USD 50–100 per hectare annually, proposed threshold) paid to claiming farmers without spot-check photographic verification or lab-confirmed disease reports, creating moral hazard and fraudulent claims consuming USD 50M+ annually (estimated budget) without proportionate surveillance value.

## Audit - Procedures

- Quarterly external audits of border and nursery inspection records (Month 3, 6, 9, 12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08, etc. through Month 36 = 2029-10-08, 2027-04-08, etc. through 2029-10-08) verifying documented interceptions, sample handling, and inspector sign-offs against photos/logs; identify gaps and sanction falsified records; during Containment Efficacy Review (Months 72–84 = 2032-10-08 to 2033-10-08), audit at least 50 sample chains to laboratory confirmation.
- Annual Technical Panel conflict-of-interest certification: Each Technical Panel member and Technical Gate Charter signatory certifies absence of financial interest in breeding consortia, OEM buyers, or processing operators at each gate (Months 36, 84, 144, 216 = 2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08); independent secretariat counsel reviews interests and publishes panel roster 60 days before gate decision.
- Post-construction audits of alternative-rubber hub capex: Within 6 months of commissioning (expected Month 120–132 = 2036-10-08 to 2037-10-08), engage external quantity-surveyor and engineering auditors to verify that hub capex matches invoices, procured equipment is installed and functional, and actual cost is within ±10% of approved budget; report to board.
- Nagoya Protocol benefit-sharing verification: Annual audits (Months 12, 24, 36 = 2027-10-08, 2028-10-08, 2029-10-08, etc. = 2027-10-08, 2028-10-08, 2029-10-08, etc.) of royalty accruals, community payments, and capacity-building disbursements against signed agreements with Brazilian states and indigenous organizations; engage independent Brazilian auditor; publish annual compliance report.
- Replanting-loan portfolio audits: Semi-annual reviews (Months 12, 24, 36 = 2027-10-08, 2028-10-08, 2029-10-08, etc. = 2027-10-08, 2028-10-08, 2029-10-08, etc.) of loan disbursements, repayment rates, and end-use verification for 5–10% statistical sample of borrower farms; on-site spot checks of clean-plant practices on at least 50 farms per year; flag diversions and recovery actions.
- Post-gate program-level audits: 18–24 months after each funding gate (Months 60, 108, 168, 252 = 2031-10-08, 2035-10-08, 2040-10-08, 2047-10-08), engage independent auditor to verify that gated tranches were deployed against stated pillar allocations (containment 25%, breeding 35%, alternatives 25%, smallholder 15%, decision), funding did not leach to overhead, and KPI baselines for next gate are accurate.

## Audit - Transparency Measures

- Phase 1 Protocol Readiness Dashboard (Months 0–36 = 2026-10-08 to 2029-10-08): Public online portal updated quarterly showing (1) number of countries with enforceable import rules by region, (2) trained and audited inspectors per country, (3) documented suspect detections logged and lab-confirmed, (4) interception rate per checkpoint; linked to gate criteria (proposed threshold: ≥15 countries, ≥500 inspectors, ≥2 lab-cleared detections).
- Technical Gate Charter and Gate Evidence Publication: Signed by all major funders and producer-governments by Month 3 (2027-01-08); before each gate decision (Months 36, 84, 144, 216 = 2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08), publish all evidence, Technical Panel assessment and recommendation 60 days prior; allow 30-day formal review and appeal before board decision; publish dissents and decisions with reasoning.
- Annual Benefit-Sharing and Smallholder Engagement Report: Published by Month 3 (2027-01-08) of each calendar year (March); report on (1) germplasm collection and access-agreement status, (2) royalty and community payments made in prior year, (3) smallholder adoption numbers by region, (4) surveillance-premium payments and verification rates, (5) clean-plant nursery throughput; include community and farmer testimonials (anonymized).
- Alternative-Rubber Pillar Tracking Dashboard (Months 6–84 = 2027-04-08 to 2033-10-08): Public dashboard showing (1) pilot cost per kilogram and trajectory to Month 84 (2033-10-08) gate target (USD 1.62/kg proposed threshold), (2) tire-grade test results against 95% Hevea spec target (decision), (3) OEM offtake commitments (aggregate tonnage, names of signatory OEMs, price formula), (4) environmental monitoring data from pilot sites (soil, water, biodiversity baselines and trends).
- Secretariat Board Meeting Minutes and Decision Records: Published within 30 days of all board meetings (frequency not specified; recommend quarterly); disclose attendance, votes on capital release and major decisions, dissenting members' positions, and follow-up actions; exclude confidential commercial terms but publish gate decisions and pillar reallocation logic.
- Whistleblower Mechanism and Integrity Hotline: Independent, externally managed anonymous reporting line (e.g., Transparency International or similar NGO) for allegations of bribery, misallocation, false claims, or protocol violations; published annual summary of reports received, investigations opened, and corrective actions (without compromising confidentiality of sources); reports escalated to board audit committee within 14 days.

# Internal Governance Bodies

### 1. Program Steering Committee (PSC)

**Rationale for Inclusion:** Strategic oversight body required for a 25-year, $30 billion multi-continent public-private program spanning three interdependent pillars (containment, breeding, alternatives) with stage gates at Months 36, 84, 144, 216 (2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08). PSC provides high-level strategic direction, approves tranches above defined thresholds, ensures funder alignment, and resolves disputes between producer governments, OEMs, development banks, and technical bodies. Program complexity, scale, 25-year horizon, and cross-sovereign coordination require binding strategic authority insulated from annual budget cycles.

**Responsibilities:**

- Approve or reject stage-gate tranche releases (Months 36, 84, 144, 216 = 2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08) on basis of Technical Panel evidence and recommendations, with binding authority over gate decisions
- Set strategic direction for the three pillars (containment, resistance breeding, alternative rubber) in response to biological and market developments, including pillar reallocation within adaptive-tranches framework
- Maintain funder commitment and alignment: convene funders and major producer governments to renew or adjust funding commitments at each gate; handle escalations from contributors regarding capital deployment or governance concerns
- Oversee Technical Gate Charter enforcement and resolve post-gate disputes: if an outcome is contested within 30 days of publication, PSC convenes dispute resolution (arbitration, not litigation) with 6-month resolution timeline
- Review and approve any strategy pivots exceeding 10% reallocation across pillars or deferring major milestones (e.g., hub construction delay >12 months, cultivar-readiness slip >18 months)
- Ensure compliance with ring-fenced funding structures and reserve policies: verify contingency pool (USD 4.5B), outbreak reserve (USD 0.5B-1.0B), and political-risk reserve (USD 0.9B) remain protected and ear-marked

**Initial Setup Actions:**

- Establish PSC board composition and charter by Month 1 (2026-11-08): 6-8 producer-government seats (rotating chairs, no single country holds chair more than 3 years), 3-4 OEM seats, 3-4 development-bank seats, 3-4 independent expert seats; publish roster with biographies and conflict-of-interest certifications
- Negotiate and sign Technical Gate Charter by Month 3 (2027-01-08): binding agreement specifying gate criteria, KPI thresholds, evidence standards, decision rules, partial-achievement tranching, and appeal procedures; obtain signatures from all major funders (≥5-8 sovereigns, ≥2 MLDBs)
- Establish independent Technical Panel (separate from PSC) by Month 3 (2027-01-08): 7-9 conflict-free members (breeding scientists, phytosanitary experts, economist), with selection criteria and term limits; bar PSC members from Panel assessments
- Adopt PSC Standing Rules by Month 2 (2026-12-08): specify meeting cadence (quarterly minimum), decision-making procedures (supermajority or consensus for major decisions), disclosure of conflicts, confidentiality protocols, and escalation paths
- Secure binding multi-year funding commitments from 5-8 sovereigns and ≥2 development banks by Month 3 (2027-01-08): commitments in treaty or binding agreement form (not annual appropriations); ensure no single funder >25% of capital (USD 7.5B cap per funder)

**Membership:**

- 6-8 producer-government representatives (Brazil, Indonesia, Malaysia, Thailand, India, Côte d'Ivoire, Mexico, and one regional rotating seat)
- 3-4 OEM (tire manufacturer and rubber-goods) representatives
- 3-4 multilateral development-bank representatives (World Bank, ADB, IFAD, regional development banks)
- 3-4 independent expert representatives (agronomy, phytosanitary science, economics, nominated by academic or international scientific bodies, independent of funders and producers)

**Decision Rights:** PSC has binding authority to approve or reject stage-gate tranches (Months 36, 84, 144, 216 = 2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08) on basis of Technical Panel recommendations and gate evidence, with major-funder agreement required for release (supermajority, defined as ≥75% of PSC voting members, or consensus for strategic pivots >10% pillar reallocation). PSC decides on tranches up to USD 4.5B (Year 3 envelope); tranches >USD 1.0B also require explicit approval by each development-bank representative present. Contingency pool reallocation (USD 4.5B) requires PSC supermajority. Outbreak reserve (USD 0.5B-1.0B) is pre-authorised for deployment within 2-4 weeks of confirmed SALB detection in a currently free region, bypassing PSC.

**Decision Mechanism:** Supermajority voting (≥75% of PSC members) for gate decisions and tranche release; consensus (all members agree or formally abstain, not dissent) required for strategy pivots exceeding 10% pillar reallocation, formal gate-criteria amendments, or Technical Panel membership changes. Tie-breaker: if voting is tied at 50-50, the PSC chair (rotating annually among producer-government members) casts a deciding vote, with reasoning published. All PSC votes recorded and published within 30 days, including dissents and abstentions. Disputes over gate decisions escalated to independent arbitration (e.g., UNCITRAL rules, 6-month resolution timeline) if not resolved by consensus within 30 days of vote.

**Meeting Cadence:** Quarterly ordinary meetings (Months 3, 6, 9, 12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08 of each calendar year, i.e. monthly during Month 0-1 = 2026-10-08 to 2026-11-08 ramp, then quarterly; adjust to Months 2, 5, 8, 11 = 2026-12-08, 2027-03-08, 2027-06-08, 2027-09-08 if necessary for align with calendar year). Extraordinary meetings within 14 days if called by PSC chair or ≥4 members (e.g., outbreak suspected, funder crisis, gate decision disputes). Stage-gate meetings at Months 36, 84, 144, 216 (2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08), with evidence published 60 days prior and 30-day review/appeal window.

**Typical Agenda Items:**

- Progress reports from Core Project Team and workstream leads (containment, breeding, alternatives, smallholder, governance) against Months 0-X milestones
- Financial and capital deployment status: committed vs. disbursed, funding-gap exposure, levy revenue (from Month 18 = 2028-04-08 onwards), reserve account balances
- Funder alignment: any changes in sovereign or development-bank commitments, political risks, budget pressures; actions to renew commitments approaching end of multi-year tranches
- Stage-gate preparation (quarterly leading into Months 36, 84, 144, 216 = 2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08): evidence compilation, Technical Panel recommendations, gate-criteria satisfaction assessment, dispute anticipation
- Risk escalations: protocol adoption delays, breeding timelines slipping, alternative-rubber cost/quality concerns, smallholder adoption shortfalls, governance disputes, geopolitical friction
- Technical Panel workplan and conflict-of-interest certifications (annual)
- Audit findings (quarterly: external audits of borders, inspections, hub capex, benefit-sharing, loan portfolios) and corrective actions

**Escalation Path:** PSC decisions contested by any funder or producer government within 30 days of publication escalate to independent arbitration (e.g., UNCITRAL, ICC) with 6-month resolution timeline. If arbitration upholds PSC decision, dissenting funder may formally withdraw, triggering contingency funding-gap protocol (fallback cascade: higher bank loan-to-grant ratio, outcome-linked bonds, climate-finance blend). If arbitration overturns PSC decision, gate is re-opened and evidence re-assessed by the Technical Panel within 60 days. PSC disputes that deadlock (e.g., producer governments vs. OEMs on gate criteria interpretation) escalated to a Crisis Steering Group (chair + 2 producers + 2 OEMs + 1 independent expert) for 14-day mediation before arbitration.
### 2. Core Project Team (CPT)

**Rationale for Inclusion:** Operational management body required to execute the program's three pillars and cross-cutting functions. CPT is the secretariat staff and workstream leads responsible for day-to-day decision-making below the strategic threshold (budget <USD 50M per decision, timelines <12 months), risk management, milestone tracking, and coordination across containment protocol negotiation, resistance breeding and field trials, alternative-rubber pilots, smallholder finance deployment, and governance infrastructure. Program complexity across multiple continents, countries, and institutions demands a professional, politically insulated operational team with decision authority and long-term employment security.

**Responsibilities:**

- Execute Phase 1 (Months 0-36, 2026-10-08 to 2029-10-08) containment protocol framework: lead technical drafting, IPPC standard-setting proposal, regional compact negotiations, capacity-building in producer countries; deliver ≥15 countries with enforceable import rules and ≥500 trained inspectors by Month 36 (2029-10-08)
- Manage Brazil-led bio-prospecting and germplasm collection: coordinate Nagoya Protocol access-and-benefit-sharing agreements with Brazilian states and indigenous organizations; deliver ≥200 characterized wild Hevea accessions by Month 18 (2028-04-08); establish pathogen genomics labs (Brazil Month 2 = 2026-12-08, Asia Month 9 = 2027-07-08)
- Oversee resistance breeding pipelines: manage multi-location field trials at ≥4 high-containment stations (Months 0-36 = 2026-10-08 to 2029-10-08); implement Virulence Gates (Months 24, 36, 48, 60 = 2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08); ensure pyramiding of ≥3 resistance genes from ≥2 sources; deliver cultivar candidates for Year 7 and Year 12 gates
- Direct alternative-rubber pilots: manage Guayule and Russian dandelion agronomic trials and cost-tracking; co-fund OEM tire-grade qualification testing; support hub site selection, permitting, and financing; track cost trajectory toward USD 1.62/kg gate (20% premium) by Month 84 (2033-10-08)
- Deploy smallholder finance and surveillance infrastructure: design and pilot replant-loan terms (7-10 year tenor, <5% interest), clean-plant nursery networks, and surveillance-premium mechanisms; pilot in 3-5 zones (Months 6-24 = 2027-04-08 to 2028-10-08); scale if uptake ≥60%
- Manage risk mitigation: coordinate contingency planning (outbreak response playbook, emergency cultivar deployment, funding-gap cascade), monitoring of 16 key risks, quarterly escalation reports to PSC, and corrective-action tracking
- Operate governance infrastructure: maintain Technical Panel secretariat, publish gate evidence 60 days before each decision, manage post-gate appeals and arbitration support, publish annual stakeholder reports and transparency dashboards

**Initial Setup Actions:**

- Recruit Executive Director and core secretariat staff (10-15 FTE) by Month 1 (2026-11-08): Director (external hire, non-national, 5-10 year term contract), Deputy Directors for each pillar (containment, breeding, alternatives), Chief Financial Officer, Risk and Compliance Officer, and administrative support; location in neutral capital (e.g., Geneva or Rome) or rotating regional hubs
- Establish CPT workstream structure by Month 1 (2026-11-08): Containment workstream (protocol negotiation, capacity-building), Breeding & Trials workstream (germplasm, field trials, pathogen genomics), Alternative Rubber workstream (agronomic pilots, processing, offtake), Smallholder Finance & Surveillance workstream, and Governance & Reporting workstream; each led by a subject-matter expert
- Set up financial management systems by Month 1 (2026-11-08): separate bank accounts and ledgers for each pillar (25%, 35%, 25%, 15% allocation), contingency pool (15%), outbreak reserve, and political-risk reserve; establish quarterly financial reporting and external audit protocols
- Launch IPPC/containment protocol drafting and technical working group by Month 0 (2026-10-08): convene Brazil, major producing countries, IPPC Secretariat, and regional plant protection organizations; produce formal IPPC proposal by Month 18 (2028-04-08)
- Commission capacity-building twinning arrangements by Month 1 (2026-11-08): establish partnerships between Brazilian phytosanitary institutes and Southeast Asian, South Asian, and West African agriculture ministries; begin recruiting and training inspectors (target 500 by Month 36 = 2029-10-08)

**Membership:**

- Executive Director (Chief Executive Officer, reporting to PSC chair)
- Deputy Director, Containment & Capacity Building (IPPC harmonization, national protocol adoption, inspector training)
- Deputy Director, Resistance Breeding & Field Trials (germplasm management, breeding pipelines, Virulence Gates, trial operations)
- Deputy Director, Alternative Rubber & Processing (agronomy pilots, cost-tracking, OEM engagement, hub feasibility)
- Deputy Director, Smallholder Finance & Surveillance (replant-loan design, clean-plant networks, surveillance-premium mechanisms, farmer coordination)
- Chief Financial Officer (budget management, capital deployment, financial reporting, audit coordination)
- Chief Risk & Compliance Officer (risk monitoring, mitigation planning, governance audits, ethics/anti-corruption)
- Technical Secretariat Manager (Technical Panel support, gate evidence compilation, publication, appeals administration)
- Program Coordinator/Operations Manager (scheduling, communications, stakeholder coordination, documentation)

**Decision Rights:** CPT has autonomous decision authority for operational spending <USD 50M per decision, milestone timelines <12 months, and routine deployment of pre-approved workstreams (e.g., inspector training, trial-site management, loan disbursement within approved quotas). CPT can approve budget reallocation within pillar allocations up to ±10% (e.g., shifting USD 100M from breeding trials to germplasm collection within the USD 10.5B breeding pillar). Any decision exceeding USD 50M, involving >12 month delays to major milestones, or reallocating >10% across pillars escalates to PSC. CPT approves Technical Panel workplan and conflict-of-interest certifications (annually).

**Decision Mechanism:** CPT operational decisions by consensus among Deputy Directors and CFO/Risk Officer on decisions affecting multiple workstreams; single workstream decisions (e.g., inspector training curriculum) by that Deputy Director with CFO sign-off for >USD 10M. Executive Director holds tie-breaker vote if consensus cannot be reached within 7 business days. All CPT decisions documented with written rationale; decisions >USD 25M require CFO and Risk Officer joint approval. Monthly CPT coordination meetings (Mondays 9am CET, standup format) to synchronize workstream progress and identify cross-cutting risks.

**Meeting Cadence:** Weekly Deputy Director coordination meetings (Mondays); monthly full-CPT meetings with PSC chair and Technical Panel chair (Fridays); quarterly financial and risk reviews (CFO + Risk Officer + Executive Director). Workstream-specific meetings (containment, breeding, alternatives, smallholder, governance) at least bi-weekly. Annual all-hands with PSC and Technical Panel (Month 12 = 2027-10-08 of each year, after Q4 reporting).

**Typical Agenda Items:**

- Workstream milestone tracking: progress vs. Months 0-X schedule; slippage alerts (>4 weeks) and corrective actions
- Financial status: committed and disbursed capital by pillar, burn rate vs. forecast, upcoming tranches, reserve account balances
- Risk escalations from workstream leads: biological delays, capacity-building shortfalls, offtake commitment gaps, smallholder adoption rates, governance disputes
- Funder and producer-government requests or concerns: political pressures, budget realignment, strategy questions
- Technical Panel secretariat workload: gate evidence compilation deadlines, conflict-of-interest certifications, appeals or disputes in queue
- Quarterly audit findings: inspection records, hub capex, benefit-sharing payments, loan portfolio performance, misconduct allegations
- Contingency planning updates: outbreak-response protocol drills, emergency cultivar deployment pathway, funding-gap cascade readiness

**Escalation Path:** CPT decisions or milestones affecting gate schedules or tranches >USD 100M escalate to PSC within 5 business days of discovery. Conflicts between workstreams (e.g., breeding vs. alternatives over resource allocation) escalated to Executive Director for mediation; if unresolved in 7 days, escalated to PSC chair. Misconduct allegations or corruption risks escalated to Chief Risk & Compliance Officer, with potential escalation to PSC Audit Committee (if established) or external law enforcement. External-party complaints (producers, funders, farmers, communities) received through whistleblower hotline (externally managed, reported to CPT Risk Officer and PSC annually).
### 3. Technical Panel

**Rationale for Inclusion:** Specialized independent assurance body required to assess gate evidence and recommend stage-gate decisions (Months 36, 84, 144, 216 = 2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08) on objective, technocratic grounds insulated from political and commercial interests. The program gates USD 4.5B-19.5B tranches on KPI achievement in three interdependent pillars (containment protocol readiness, resistance-cultivar readiness, alternative-rubber cost/quality). Gate decisions must be credible to funders, producer governments, and OEMs; perceived capture by any faction (e.g., breeding institutes over alternatives, producers over OEMs) would undermine funder confidence and trigger early exits. Panel conducts independent technical assessment, publishes reasoning, and participates in appeal processes; PSC retains final authority.

**Responsibilities:**

- Assess evidence for each stage gate (Months 36, 84, 144, 216 = 2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08) against Technical Gate Charter KPI thresholds: scoring gate attainment (% of criteria met), identifying evidence gaps, flagging interpretation disputes, and recommending tranches (full, partial, or withheld)
- Conduct Containment Efficacy Review during Months 72-84 (2032-10-08 to 2033-10-08): audit ≥50 documented suspect detections logged by Month 84 (2033-10-08), verify laboratory confirmations, assess whether protocol is functionally preventing undetected incursions; escalate if <20 detections by Month 72 (2032-10-08) or zero by Month 60 (2031-10-08)
- Monitor and report on Virulence Gates (Months 24, 36, 48, 60 = 2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08): assess whether candidate cultivars are resistant to contemporary SALB isolates under high-containment testing, recommend hold or advance for each candidate, and flag resistance-gene pyramiding gaps
- Review climate-shock stress scenarios at Years 7 and 12 gates: model alternative-rubber cost/quality outcomes under drought (2-in-20-year rainfall) and flood (2-in-50-year event) scenarios; assess whether supply diversification goal remains viable under stress
- Publish gate evidence packages 60 days before each decision: compile all supporting data, trial results, cost analyses, adoption rates, and CPT/workstream assessments into a public document; flag methodological caveats, data gaps, and Panel dissents
- Administer gate appeals process: receive written challenges to Panel recommendations within 30 days of publication; convene appeal review (Panel subset + neutral mediator) within 14 days; produce written appeal decision within 60 days, escalating unresolved disputes to PSC or arbitration
- Provide technical advice to PSC and CPT on scientific and regulatory matters: pathway viability, risk prioritization, timing feasibility, emerging technologies relevant to breeding, containment, or alternatives

**Initial Setup Actions:**

- Establish Panel composition and recruit members by Month 3 (2027-01-08): 7-9 members selected for expertise (plant breeding/genetics, plant pathology, phytosanitary standards, agricultural economics, smallholder finance, supply-chain analysis) and independence from funders, producers, OEMs, and breeding consortia; publish roster with CVs and conflict-of-interest certifications
- Adopt Panel Standing Rules by Month 2 (2026-12-08): specify decision procedures (majority vote on recommendations), confidentiality of deliberations (not final reasoning), publication of recommendations with dissent statements, conflict-of-interest recusal rules, and term limits (5-7 years, no reappointment)
- Establish Panel secretariat and working groups by Month 3 (2027-01-08): hire 2-3 FTE technical staff to compile evidence, coordinate with CPT workstreams, manage documentation, and support appeals; establish working groups for each pillar (containment, breeding, alternatives) or special topics (virulence, climate, finance)
- Commission gate-evidence data architecture by Month 1 (2026-11-08): specify data-submission templates, quality standards, and timelines from CPT workstreams to Panel secretariat (submission by Month 50 = 2030-12-08, Month 80 = 2033-06-08, Month 140 = 2038-06-08, Month 212 = 2044-06-08 for gates at Months 36, 84, 144, 216 = 2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08, allowing 60-day Panel review)
- Draft interpretation guidelines for KPI thresholds by Month 6 (2027-04-08): clarify what constitutes 'verified containment,' 'cultivar readiness,' 'cost parity,' and 'smallholder adoption' so that evidence assessment is transparent and disputes minimized

**Membership:**

- Chair (independent plant scientist, rotation every 2-3 years among Panel members, selected by Panel vote)
- Plant geneticist/breeder (5+ years resistance breeding, independent of commercial breeding consortia)
- Plant pathologist (epidemiology and virulence tracking, independent of supplier interests)
- Phytosanitary regulation expert (IPPC, regional standards, compliance assessment, independent of national governments)
- Agricultural economist (cost-benefit analysis, commodity markets, finance structures, independent of industry)
- Smallholder agriculture specialist (adoption dynamics, rural livelihoods, microfinance, independent of lenders)
- Supply-chain resilience analyst (tire supply, procurement risk, OEM perspectives, independent of manufacturers)
- Optional 8th or 9th member: emerging topics (climate-adaptation specialist, food security, or additional geography/sector expertise)

**Decision Rights:** Panel makes formal recommendations to PSC on gate evidence sufficiency and KPI attainment (full, partial, or withheld tranches). Panel does not hold veto over PSC decisions; PSC may override Panel recommendation with supermajority vote and published reasoning, but such overrides are rare and damage program credibility. Panel has authority to publish dissent statements if members strongly disagree with majority recommendation. Panel can demand data or audits from CPT workstreams within 30 days if evidence quality is questioned. Panel holds authority to declare a gate 'insufficient evidence' and recommend deferral (up to 6 months) if data quality or completeness is inadequate.

**Decision Mechanism:** Majority vote (≥4 of 7-9 members) to recommend gate outcome (full, partial, or withheld). Dissenting members publish short written dissent (500 words max) alongside majority recommendation. If vote is tied (rare, odd number of members preferred), Chair votes; if still tied after Chair vote, Panel convenes emergency meeting and votes again with 2-week deliberation. All Panel deliberations and draft recommendations confidential (not published), but final recommendation and dissents public. No Panel member may have financial interest in outcome (e.g., employment at breeding institute, seat on OEM board, investment in processing hub); conflict-of-interest recusal enforced by Panel secretariat.

**Meeting Cadence:** Monthly standing meetings (first Tuesday of each month) for routine workstream updates and emerging-risk discussion. Intensive gate-assessment meetings 6-8 weeks before each gate decision (i.e., Months 28-32 = 2029-02-08 to 2029-06-08, 76-80, 136-140, 208-212 = 2029-04-08 to 2029-08-08, 2032-06-08 to 2032-10-08, 2037-10-08 to 2038-02-08, 2043-10-08 to 2044-02-08): weekly 4-hour data-review sessions. Final gate-recommendation vote 2 weeks before public evidence release (i.e., Months 34, 82, 142, 214 = 2029-08-08, 2033-08-08, 2038-08-08, 2044-08-08). Ad-hoc meetings if urgent technical questions arise (e.g., pathogen virulence alert, unexpected cost overrun).

**Typical Agenda Items:**

- Workstream progress reports from CPT: containment protocol adoption status, breeding trial results, alternative-rubber cost and quality data, smallholder adoption rates
- Data quality and completeness review: flagging missing data, methodological concerns, outliers; requesting re-analysis or clarification from CPT
- Gate-assessment preparation (during intensive gate-windows): synthesis of evidence against KPI thresholds, preliminary scoring, dissent identification, recommendation drafting
- Virulence Gates (Months 24, 36, 48, 60 = 2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08): quarterly pathogen genomics reports, candidate-cultivar resistance assessments, hold/advance recommendations
- Climate-scenario modeling (Months 60-84, 2031-10-08 to 2033-10-08 for Year 7 gate): stress-testing alternative-rubber economics under drought, flood, temperature-shift scenarios
- Appeals and disputes: review of formal gate-appeal submissions within 30 days of evidence release; preliminary mediation attempts before escalation to PSC
- Panel-governance matters: conflict-of-interest certifications (annual), term-limit tracking, recruitment of new members (as terms expire), Standing Rules updates

**Escalation Path:** Panel recommendations disputed by PSC or funders within 30 days of publication escalate to PSC extraordinary meeting for discussion; if unresolved, disputes go to independent arbitration (UNCITRAL or ICC). If Panel detects evidence fraud or major data quality issues, escalation to PSC Audit Committee or external law enforcement. If Panel believes gate decision should be deferred due to insufficient evidence, formal recommendation to PSC may include deferral proposal; if PSC overrides and approves tranches anyway, Panel may publish formal dissent explaining the risk.
### 4. Compliance and Ethics Committee (CEC)

**Rationale for Inclusion:** Specialized assurance body required to ensure comprehensive compliance oversight of a $30 billion public-private program spanning multiple sovereigns, sensitive genetic-resource access (Nagoya Protocol), phytosanitary enforcement in weak-capacity countries, and smallholder finance vulnerable to diversion. CEC monitors GDPR, Nagoya Protocol, ethical standards (benefit-sharing, indigenous rights, environmental stewardship), anti-corruption (bribery, embezzlement, nepotism), and sanctions/money-laundering risks. Program scale, cross-border operations, and high-profile nature invite scrutiny; weak compliance invites funding withdrawal, legal challenges, and geopolitical backlash. CEC provides independent assurance that the program operates ethically and legally.

**Responsibilities:**

- Oversee Nagoya Protocol and genetic-resource access compliance: verify that Brazil-led bio-prospecting follows access-and-benefit-sharing agreements with Brazilian states and indigenous organizations; audit annual royalty and community-payment disbursements; review new collection authorizations before proceeding; manage dispute resolution with communities claiming inadequate benefits
- Monitor phytosanitary enforcement for corruption and bribery: conduct quarterly unannounced audits of ≥10 border and nursery inspection checkpoints, including record review, personnel interviews, and sample-integrity verification; escalate any evidence of bribe-taking or falsified inspection records to national law enforcement
- Administer smallholder-finance integrity: audit 5-10% statistical sample of replant loans annually, verifying disbursement, end-use, clean-plant purchasing, repayment, and loan-fraud indicators; flag diversions and recovery actions to CPT; assess whether surveillance premiums are paid and verified within 30 days as promised
- Conduct Technical Panel conflict-of-interest oversight: verify annual certifications from all Panel members and PSC members for financial interests in breeding consortia, OEM boards, processing operators, or lenders; maintain recusal register and enforce recusals during gate assessments; publish sanitized roster of interests annually
- Manage whistleblower program and integrity hotline: administer externally managed anonymous reporting channel for allegations of corruption, fraud, misconduct, or ethics violations; log all reports; initiate investigations; publish annual summary of reports received, investigations opened, and outcomes (without compromising confidentiality)
- Ensure GDPR and data-protection compliance: oversee handling of personal data from smallholder loan records, inspector identity, indigenous-community benefit-sharing records, and any genetic sequencing data; ensure data-minimization, consent, and secure storage; conduct annual privacy-impact assessments
- Audit alternative-rubber hub capex and procurement: post-construction audits verify that hub capex matches invoices, procured equipment is installed and functional, and actual cost is within ±10% of budget; flag any inflated invoices, phantom suppliers, or diverted materials

**Initial Setup Actions:**

- Establish CEC membership and hire staff by Month 2 (2026-12-08): 5-7 members including Chair (external hire, not from funders/producers/OEMs), Nagoya Protocol specialist, anti-corruption/investigative expert, data-protection officer, and auditor; hire 4-6 FTE investigation and compliance staff
- Establish externally managed whistleblower hotline by Month 1 (2026-11-08): contract with Transparency International or similar NGO for anonymous reporting, investigation support, and confidentiality protection; publicize hotline widely to inspectors, farmers, communities, and staff
- Adopt Compliance and Ethics Charter by Month 1 (2026-11-08): specify authority, independence, investigation procedures, confidentiality protocols, mandatory reporting to law enforcement for criminal allegations, publication of annual reports
- Develop inspection-checkpoint audit protocol by Month 1 (2026-11-08): define unannounced audit procedures, record-review standards, sample-integrity testing, personnel interviews, and escalation thresholds for suspected fraud
- Commission Nagoya/ABS benefit-sharing audit framework by Month 1 (2026-11-08): specify royalty-tracking mechanisms, community-payment verification, and dispute-resolution procedures; coordinate with Brazil-led benefit-sharing team

**Membership:**

- Chair (independent compliance professional, 10+ years experience in development finance, anti-corruption, or international governance, external to all funders and implementers)
- Nagoya Protocol and Genetic-Resource Specialist (ABS compliance, indigenous-rights law, benefit-sharing auditing)
- Anti-Corruption and Investigative Expert (forensic accounting, fraud detection, law-enforcement liaison)
- Data Protection Officer (GDPR, privacy impact assessment, secure data handling)
- Senior Auditor (financial audit, procurement, capex verification, asset tracking)
- Field Compliance Coordinator (field monitoring, checkpoint audits, smallholder-community liaison, based in or rotating through key regions)

**Decision Rights:** CEC has authority to initiate investigations of suspected misconduct, issue compliance findings and corrective-action orders to CPT and PSC (binding if not overridden within 30 days by PSC supermajority), require CPT to suspend activities pending investigation (e.g., halt inspector payment if bribery suspected, freeze loan disbursements if fraud detected), and recommend removal or recusal of individuals from governance roles or decision-making. CEC does not have authority to override programmatic decisions (gates, funding), but can flag compliance risks to PSC. Criminal allegations are automatically reported to relevant national law enforcement without awaiting PSC approval.

**Decision Mechanism:** CEC issues compliance findings and corrective-action orders by majority vote (≥3-4 of 5-7 members). If CEC Chair believes investigation is urgent (e.g., active bribery, data theft), Chair may act unilaterally with written rationale and CEC ratification within 7 days. All CEC findings published to PSC and CPT within 14 days of investigation close, with sensitive details (ongoing criminal investigation, confidential sources) redacted in public summaries. CEC recommendations for individual removal or recusal published with reasoning. Dissenting CEC members may publish short dissent statement alongside majority findings.

**Meeting Cadence:** Monthly CEC meetings (third Thursday of each month, 2 hours) to review compliance status, investigation progress, and emerging risks. Quarterly intensive compliance-review meetings (Months 3, 6, 9, 12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08 of each year, 1-day workshops) synthesizing quarterly audits and developing annual compliance roadmap. Special meetings called by CEC Chair within 48 hours if urgent misconduct allegation received.

**Typical Agenda Items:**

- Whistleblower hotline summary: number of reports received, categories (corruption, fraud, ethics, misconduct), status of investigations, outcomes published (anonymized)
- Compliance audit findings: quarterly checkpoint/inspection audits, benefit-sharing payment verifications, loan-portfolio reviews, hub capex audits; flagging of non-compliance and corrective actions required
- Investigation status updates: active misconduct cases, law-enforcement liaisons, recovery of diverted funds or stolen assets, personnel actions
- Conflict-of-interest certifications: annual review of PSC and Panel member interests, recusal tracking, and roster updates
- Nagoya Protocol and benefit-sharing compliance: royalty accrual tracking, community payment schedules, dispute resolution with communities or indigenous organizations
- Data-protection compliance: GDPR impact assessments, data-handling incidents, privacy-by-design reviews of new IT systems
- Regulatory and legal updates: changes in anti-corruption law, sanctions regimes, phytosanitary regulations affecting program operations

**Escalation Path:** Suspected criminal conduct (bribery, embezzlement, money laundering, fraud) reported to CEC Chair, who initiates investigation and mandatory reporting to relevant national law enforcement within 30 days unless ongoing investigation by authorities takes precedence. CEC corrective-action orders not complied with by CPT within 30 days escalate to PSC for enforcement; if PSC overrides CEC finding, rationale must be published. Serious compliance failures (e.g., widespread bribery, major data breach, genocide/crimes-against-humanity risk) trigger CEC recommendation for program suspension pending external audit or law-enforcement action. Whistleblower allegations of CEC staff misconduct escalate to external auditor or PSC Audit Committee (if established).
### 5. Producer-Country Coordination Forum (PCCF)

**Rationale for Inclusion:** Specialized advisory body required to ensure producer-country institutional capacity building, technology transfer, and sustained compliance with the SALB Containment Protocol. Producer governments (especially weak-link countries in Africa and South Asia) must build phytosanitary inspection capacity, clean-plant nurseries, and research capability over 25 years, or the program fails at handover (Month 216+, 2044-10-08 onwards). PCCF provides a forum for producer governments to coordinate on protocol adoption, share lessons from capacity-building, resolve cross-border disputes (e.g., quarantine-zone boundaries), and ensure that sovereignty and national ownership are respected. Without PCCF, producer countries risk feeling externally imposed-upon, reducing voluntary compliance.

**Responsibilities:**

- Coordinate protocol adoption into national law across ≥15 producing countries: track each country's legislative and regulatory status, identify bottlenecks (e.g., legal review, parliamentary debate), facilitate peer learning between early adopters and laggards, and advocate for legal adoption timelines aligned with Year 3 gate and beyond
- Oversee capacity-building partnerships: monitor effectiveness of twinning arrangements between Brazilian, Southeast Asian, South Asian, and West African phytosanitary institutes; assess inspector training outcomes (certifications issued, retention rates); identify gaps and recommend corrective actions
- Support establishment of clean-plant nurseries and national propagation hubs: coordinate regional standards for certified planting stock, facilitate technology transfer for tissue-culture or hybrid propagation systems, ensure that at least 50% of production capacity is domestically owned and operated by Year 12
- Manage cross-border quarantine coordination: convene producer governments annually to agree on quarantine-zone boundaries, common inspection standards, material-movement rules, and dispute-resolution procedures for disagreements on suspect detections
- Assess producer-country readiness for post-funding handover (Months 216-300, 2044-10-08 onwards): evaluate whether national agricultural agencies, research institutes, and inspection services have the staffing, funding, technical capability, and political commitment to sustain protocol enforcement and cultivar development after external funding ends; recommend areas needing pre-handover strengthening
- Advise on smallholder adoption and community engagement: liaise with farmer organizations and indigenous communities in each country to understand adoption barriers, cultural factors affecting compliance, and benefit-distribution mechanisms; recommend country-specific adjustments to replant finance and surveillance-premium structures

**Initial Setup Actions:**

- Establish PCCF secretariat and membership by Month 1 (2026-11-08): host secretariat within one of the major producing-country research institutes (CEPLAC/Brazil, IRRDB/Thailand, or rotating host); membership = ministry-of-agriculture representatives or rubber-research-institute directors from ≥15 producing countries, with rotating annual chair
- Establish capacity-building framework and twinning partnerships by Month 2 (2026-12-08): map existing phytosanitary institutes and research infrastructure in each country; identify priority capacity gaps (inspectors, labs, nursery managers); negotiate twinning arrangements between Brazilian institutes and partners in Asia, Africa, Latin America (target: 3-5 twining pairs operational by Month 12 = 2027-10-08)
- Commission baseline assessments of producer-country institutions by Month 3 (2027-01-08): external consultant evaluates current inspection coverage, inspector qualification, laboratory diagnostic capability, nursery capacity, and research staffing in each major-producing country; identifies capacity-building investments required to meet Year 3/7/12 milestones

**Membership:**

- Chair (rotating annually among 4-5 lead producer countries: Brazil, Indonesia, Malaysia, Côte d'Ivoire, one additional)
- Representatives from ≥15 producing countries' agriculture ministries or rubber-research institutes (≥1 per country, may rotate)
- Technical advisors from regional plant-protection organizations (ASEAN, ECOWAS, Mercosur)
- Liaison officer from CPT (Core Project Team) to bridge to multilateral secretariat

**Decision Rights:** PCCF has authority to make non-binding recommendations to PSC on producer-country capacity timelines, protocol-adoption bottlenecks, and readiness assessments. PCCF consensus position (≥12 of 15 members agree) carries weight in PSC deliberations on gate criteria and timelines; if PSC overrides PCCF consensus, rationale must be published. PCCF can propose amendments to protocol implementation schedules (e.g., delaying Year 3 deadline to Year 4 if capacity-building slips in majority of countries) if supported by ≥75% of members and 2-3 major producers.

**Decision Mechanism:** PCCF makes recommendations by majority consensus (≥75% of members agree, or explicit consensus facilitation if dissent exists). Non-binding recommendations published to PSC and CPT within 30 days. Country-specific issues (e.g., one country's legal bottleneck) addressed by PCCF working group of affected producers and technical advisors, with resolution recommendations within 60 days.

**Meeting Cadence:** Annual extraordinary meeting (Month 12 = 2027-10-08 of each calendar year, January February) with all members and CPT leadership; quarterly coordination calls among PCCF chair, deputy, and CPT liaison (Months 2, 5, 8, 11 = 2026-12-08, 2027-03-08, 2027-06-08, 2027-09-08 of each calendar year, January February, April May, July August, October November); ad-hoc working groups convened as needed (e.g., quarantine-zone disputes, capacity-building progress).

**Typical Agenda Items:**

- Protocol adoption status: tracking each country's legislation and regulatory status; identifying bottlenecks (e.g., ministry delays, parliamentary debate); timelines for target achievement
- Capacity-building progress: twinning partnership effectiveness, inspector-training completion, lab diagnostics setup, nursery-network progress
- Cross-border coordination: quarantine-zone boundaries, material-movement rules, inspection standards harmonization, dispute resolution
- Smallholder and community engagement: adoption barriers, cultural factors, benefit-distribution feedback
- Handover readiness (Months 144-216, 2038-10-08 to 2044-10-08): assessments of whether national institutions are ready for post-funding sustainability; identifying pre-handover strengthening needs

**Escalation Path:** PCCF recommendations on protocol adoption or capacity-building timelines disputed by ≥3 producers or PSC escalate to PSC for explicit debate; if PSC overrides consensus, rationale must be published and PCCF may formally dissent. Producer countries deadlocked on quarantine-zone or inspection-standard disputes escalate to PCCF mediation panel (chair + 2 neutral mediators + affected countries) with 30-day resolution timeline; if unresolved, escalates to PSC arbitration. If a major producing country threatens to withdraw from the program or refuses protocol adoption, escalation to political-level dialogue (national heads of state, development-bank presidents) outside PCCF scope.

# Governance Implementation Plan

### 1. Identify and confirm project sponsor, senior champion, and key decision-maker(s) who will authorize the establishment of governance bodies and commit binding multi-year funding. Secure written commitment that sponsor will lead initial formation activities (Months 0–1 = 2026-10-08 to 2026-11-08).

**Responsible Body/Role:** Project Sponsor / Senior Government Leadership

**Suggested Timeframe:** Month 0 (2026-10-08), within 1 week of project kickoff

**Key Outputs/Deliverables:**

- Sponsor commitment letter
- Designation of project champion and interim lead authority
- Authority to proceed with governance establishment signed

**Dependencies:**

- Project approval and go-ahead decision

### 2. Establish a Formation Steering Group (FSG), comprising the project sponsor, senior representatives from 3–5 major producer governments (Brazil, Indonesia, major development banks), and international governance advisors. FSG will oversee the design and formal establishment of the Program Steering Committee, Technical Panel, and secretariat.

**Responsible Body/Role:** Project Sponsor / Senior Government Leadership (convening authority)

**Suggested Timeframe:** Month 0 (2026-10-08), within 1 week

**Key Outputs/Deliverables:**

- Formation Steering Group roster and conflict-of-interest declarations
- FSG Charter and decision procedures
- Meeting schedule (weekly during Months 0–1 = 2026-10-08 to 2026-11-08)

**Dependencies:**

- Project Sponsor Identified

### 3. Draft and circulate governance architecture document for review by FSG and major stakeholders (producer governments, OEMs, development banks). Document specifies PSC structure, Technical Panel independence, secretariat autonomy, decision rights, and financial controls.

**Responsible Body/Role:** Formation Steering Group (lead: Project Sponsor or designated formation lead)

**Suggested Timeframe:** Month 0–1 (2026-10-08 to 2026-11-08), within 2–3 weeks

**Key Outputs/Deliverables:**

- Governance Architecture Document v0.1 (draft)
- Stakeholder feedback summary
- Revised document incorporating critical feedback

**Dependencies:**

- Formation Steering Group Established

### 4. Conduct preliminary multi-stakeholder consultation (virtual or in-person) with representatives from 5–8 sovereign governments, 3–4 major OEMs, 3–4 development banks, and key producer-country institutions (Brazil Embrapa, IRRDB, etc.) to validate governance structure and build consensus on board composition principles, decision rules, and independence safeguards.

**Responsible Body/Role:** Formation Steering Group (Project Sponsor / senior adviser)

**Suggested Timeframe:** Month 1 (2026-11-08), during weeks 2–4

**Key Outputs/Deliverables:**

- Stakeholder Consultation Report (30 participants, summary of concerns and endorsements)
- Revised governance architecture reflecting stakeholder input
- List of potential PSC and Technical Panel candidates identified by stakeholders

**Dependencies:**

- Governance Architecture Document circulated

### 5. Draft and finalize the Technical Gate Charter: binding agreement specifying KPI thresholds for Years 3/7/12/18, evidence standards, gate-decision rules, partial-achievement tranching, dispute-resolution procedures, and appeal timelines. Charter must be negotiated and agreed by major funders (sovereigns, development banks) before signature.

**Responsible Body/Role:** Formation Steering Group (lead: Project Sponsor with legal counsel and technical advisors)

**Suggested Timeframe:** Month 1–2 (2026-11-08 to 2026-12-08), weeks 2–7

**Key Outputs/Deliverables:**

- Technical Gate Charter v0.5 (draft for funder review)
- Funder feedback and redlines
- Technical Gate Charter v1.0 (final, signed by 5–8 sovereigns and 2+ development banks)

**Dependencies:**

- Preliminary multi-stakeholder consultation completed
- Binding funding-commitment discussions initiated with major funders

### 6. Recruit Executive Director of the Core Project Team (CPT) and secretariat. External hire, independent of all funders and producers, with 5–10 year contract term and long-tenure protection clauses. Role is to lead day-to-day program execution and serve as principal staff officer to the PSC.

**Responsible Body/Role:** Project Sponsor / Formation Steering Group (with HR/recruitment support)

**Suggested Timeframe:** Month 1 (2026-11-08), initiate search; hire by Month 3 (2027-01-08)

**Key Outputs/Deliverables:**

- Executive Director job description and recruitment brief
- Recruitment committee (3–5 members, FSG representatives + independent adviser)
- Executive Director contract, signed

**Dependencies:**

- Governance Architecture Document finalized
- Secretariat location and operating budget approved

### 7. Establish PSC Standing Rules: formal procedures governing PSC meetings, voting, decision thresholds (supermajority for gates, consensus for strategy pivots >10%), conflict-of-interest disclosure, confidentiality, and escalation paths. Draft by FSG, review by FSG and legal counsel, finalize within Month 2 (2026-12-08).

**Responsible Body/Role:** Formation Steering Group (lead: Project Sponsor with legal counsel)

**Suggested Timeframe:** Month 1–2 (2026-11-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- PSC Standing Rules v1.0 (adopted by FSG, to be approved by PSC upon formation)

**Dependencies:**

- Governance Architecture Document and Technical Gate Charter substantially agreed

### 8. Identify, nominate, and secure commitment from PSC members: 6–8 producer-government representatives (Brazil, Indonesia, Malaysia, Thailand, India, Côte d'Ivoire, Mexico, 1 rotating), 3–4 OEM representatives, 3–4 development-bank representatives, and 3–4 independent expert representatives. Obtain written conflict-of-interest certifications and CVs.

**Responsible Body/Role:** Formation Steering Group (lead: Project Sponsor, in consultation with major funders and producer governments)

**Suggested Timeframe:** Month 1–2 (2026-11-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- PSC Nomination List with CVs and conflict-of-interest declarations
- Written confirmations of willingness to serve (each nominee)
- Diversity and gender-balance assessment

**Dependencies:**

- Stakeholder consultation completed; funder and producer-government agreement on representation

### 9. Nominate and secure commitment from independent Technical Panel members: 7–9 conflict-free scientists and specialists (plant geneticist, plant pathologist, phytosanitary expert, economist, smallholder specialist, supply-chain analyst, and optional climate/emerging-topics expert). Obtain written conflict-of-interest certifications, CVs, and references. Panel must be independent of funders, producers, OEMs, and breeding consortia.

**Responsible Body/Role:** Formation Steering Group (lead: Project Sponsor in consultation with academic/scientific bodies and peer-review networks)

**Suggested Timeframe:** Month 1–3 (2026-11-08 to 2027-01-08)

**Key Outputs/Deliverables:**

- Technical Panel Nomination List with CVs and conflict-of-interest certifications
- Written confirmations from nominees
- Panel Standing Rules draft (to be adopted by Panel upon first meeting)

**Dependencies:**

- Governance Architecture and Technical Gate Charter agreed; need for technical expertise confirmed

### 10. Secure binding, multi-year funding commitments from 5–8 sovereign governments and at least 2 multilateral development banks, with explicit commitment letters and signed agreements (not annual appropriations). Commitments must total at least USD 21 billion (70% of USD 30 billion cap) and no single funder above 25% (USD 7.5B). Target signature by Month 3 (2027-01-08).

**Responsible Body/Role:** Project Sponsor / Formation Steering Group (senior finance/diplomatic representatives)

**Suggested Timeframe:** Month 1–3 (2026-11-08 to 2027-01-08)

**Key Outputs/Deliverables:**

- Funding Commitment Letters (5–8 sovereigns + 2+ MDBs, specifying amounts and tranches)
- Binding Funding Agreements signed by representatives with authority
- Summary of funding stack: 70% committed by Month 3 (2027-01-08), remainder to be secured during Months 3–12 (2027-01-08 to 2027-10-08)

**Dependencies:**

- Technical Gate Charter finalized
- Governance structure agreed with funders
- Executive Director hired (or interim authority designated)

### 11. Formally establish the Program Steering Committee (PSC) by convening the first PSC kick-off meeting. Activities include: PSC members sign commitments and conflict-of-interest declarations; review and adopt PSC Standing Rules; establish PSC chair (rotating annually among producer-government members), vice-chair, and secretary; set quarterly meeting schedule; assign PSC subcommittees (if needed: Finance, Risk, Governance); brief members on Technical Gate Charter and program KPIs.

**Responsible Body/Role:** Project Sponsor / Formation Steering Group (in transition to PSC chair-elect)

**Suggested Timeframe:** Month 2–3 (2026-12-08 to 2027-01-08)

**Key Outputs/Deliverables:**

- PSC Kick-off Meeting Minutes
- PSC Standing Rules adopted and signed
- PSC roster (members, roles, contact details)
- PSC meeting calendar (quarterly, plus gate-decision extraordinary sessions)
- Technical Gate Charter briefing document for PSC

**Dependencies:**

- PSC members nominated and confirmed
- PSC Standing Rules drafted
- Binding funding commitments secured
- Technical Gate Charter finalized

### 12. Formally establish the independent Technical Panel by convening the first Panel meeting. Activities include: Panel members sign conflict-of-interest certifications; review and adopt Panel Standing Rules; elect Panel chair; establish decision procedures (majority vote, dissent protocols); assign Panel working groups (containment, breeding, alternatives, or pillars); schedule monthly standing meetings and intensive gate-assessment windows (6–8 weeks pre-gate); brief Panel on Technical Gate Charter and gate evidence data architecture.

**Responsible Body/Role:** Formation Steering Group (transitioning to Project Sponsor / PSC chair as Panel governance authority)

**Suggested Timeframe:** Month 2–3 (2026-12-08 to 2027-01-08)

**Key Outputs/Deliverables:**

- Technical Panel Kick-off Meeting Minutes
- Panel Standing Rules adopted and signed
- Panel roster (members, roles, affiliations, contact details)
- Panel meeting calendar (monthly standing, intensive gate-windows Months 28–32 = 2029-02-08 to 2029-06-08, 76–80, 136–140, 208–212)
- Panel working group assignments

**Dependencies:**

- Technical Panel members nominated and confirmed
- Panel Standing Rules drafted
- Technical Gate Charter finalized

### 13. Establish the Compliance and Ethics Committee (CEC), comprising a Chair (external hire, 10+ years compliance/anti-corruption), Nagoya Protocol specialist, anti-corruption investigator, data-protection officer, and senior auditor. Contract externally managed whistleblower hotline by Month 1 (2026-11-08). Adopt CEC Charter and Compliance Framework by Month 2 (2026-12-08). First CEC meeting by Month 3 (2027-01-08).

**Responsible Body/Role:** Project Sponsor / Formation Steering Group (in consultation with PSC once established)

**Suggested Timeframe:** Month 1–3 (2026-11-08 to 2027-01-08)

**Key Outputs/Deliverables:**

- CEC Chair recruited (external hire, contract signed)
- CEC roster (members, roles, conflict-of-interest certifications)
- Whistleblower hotline contracted and operational
- CEC Charter and Compliance Framework adopted
- CEC standing meeting calendar (monthly)

**Dependencies:**

- Governance Architecture Document specifying CEC role
- Budget and authority for CEC operations approved

### 14. Establish the Producer-Country Coordination Forum (PCCF) secretariat and membership, comprising ministry-of-agriculture or rubber-research-institute representatives from 15+ producing countries, with rotating annual chair. Secure host location (within major producing-country research institute, e.g., CEPLAC/Brazil or IRRDB/Thailand). Schedule first PCCF meeting for Month 3–6 (2027-01-08 to 2027-04-08). Agree on producer-country coordination priorities and capacity-building roadmap.

**Responsible Body/Role:** Formation Steering Group (with Brazil/Indonesia/Malaysia representatives leading; producer-country institutions providing host)

**Suggested Timeframe:** Month 1–6 (2026-11-08 to 2027-04-08)

**Key Outputs/Deliverables:**

- PCCF Charter and terms of reference
- PCCF membership roster (15+ producing countries, rotating chair agreement)
- PCCF secretariat location and staffing plan
- PCCF first meeting agenda and outcomes
- Capacity-building roadmap (inspector training, nursery standards, lab diagnostics)

**Dependencies:**

- Producer-country consensus on PCCF role and governance
- Host country and institution selected

### 15. Recruit and onboard Core Project Team (CPT) Executive Director and core secretariat staff: Deputy Director for Containment & Capacity Building, Deputy Director for Resistance Breeding & Trials, Deputy Director for Alternative Rubber & Processing, Deputy Director for Smallholder Finance & Surveillance, Chief Financial Officer, Chief Risk & Compliance Officer, Technical Secretariat Manager, and operations support (10–15 FTE total). Complete recruitment by Month 3 (2027-01-08); staff in place and operational by Month 4 (2027-02-08).

**Responsible Body/Role:** Project Sponsor / PSC (via Executive Director-elect and HR adviser)

**Suggested Timeframe:** Month 1–4 (2026-11-08 to 2027-02-08)

**Key Outputs/Deliverables:**

- CPT staffing plan and organizational chart
- Job descriptions for each CPT role
- Recruitment completed; staff contracts signed
- CPT Kick-off Meeting held by Month 4 (2027-02-08)
- CPT meeting cadence established (weekly Deputy Director meetings, monthly all-hands)

**Dependencies:**

- Budget and authority for CPT operations approved
- Secretariat location and facilities arranged
- Executive Director hired (Month 3 = 2027-01-08)

### 16. Establish secretariat financial management systems: separate bank accounts and ledgers for each pillar (containment 25%, breeding 35%, alternatives 25%, smallholder 15%); contingency pool (15%), outbreak response reserve, and political-risk reserve accounting. Set up quarterly financial reporting, external audit protocols, and funder-reporting templates. Target operational by Month 2 (2026-12-08).

**Responsible Body/Role:** Core Project Team (Chief Financial Officer, with finance adviser support)

**Suggested Timeframe:** Month 1–2 (2026-11-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Bank account setup and authorization documentation
- Financial accounting and ledger system (pillar-based and reserve-based accounts)
- Quarterly financial reporting template
- External audit charter and audit schedule
- Funder reporting dashboard (committed, disbursed, burn rate, forecast)

**Dependencies:**

- Binding funding commitments received
- CFO hired or designated
- Secretariat location and financial infrastructure in place

### 17. Publish governance transparency dashboard and annual reporting framework. Dashboard includes: PSC member roster and affiliations, Technical Panel roster and expertise, CEC member roster, funding commitments (sovereign and MDB, non-confidential summary), capital deployment by pillar and month, reserve account balances, and annual compliance and risk summary. Target first publication by Month 6 (2027-04-08); thereafter annual by Month 12 (2027-10-08) of each calendar year.

**Responsible Body/Role:** Core Project Team (Technical Secretariat Manager and Communications Officer)

**Suggested Timeframe:** Month 3–6 (2027-01-08 to 2027-04-08)

**Key Outputs/Deliverables:**

- Governance Transparency Dashboard (web-based or published report)
- Annual Stakeholder Report template
- First Annual Report (Month 12 = 2027-10-08, covering Months 0–12 = 2026-10-08 to 2027-10-08)

**Dependencies:**

- All governance bodies formally established
- Financial systems operational
- Communications and IT infrastructure in place

### 18. Launch IPPC/containment protocol technical working group at Month 0 (2026-10-08), comprising representatives from Brazil, major producing countries, IPPC Secretariat, regional plant protection organizations (ASEAN, ECOWAS, Mercosur), and CPT Containment Deputy Director. Weekly meetings Months 0–6 (2026-10-08 to 2027-04-08); monthly thereafter. Produce formal IPPC proposal by Month 18 (2028-04-08); negotiate binding regional compacts by Month 24 (2028-10-08); target 15-country commitment letters by Month 24 (2028-10-08).

**Responsible Body/Role:** Core Project Team (Deputy Director, Containment & Capacity Building), with IPPC Secretariat and producer-country partners

**Suggested Timeframe:** Month 0 onwards (2026-10-08 onwards); formal IPPC proposal by Month 18 (2028-04-08)

**Key Outputs/Deliverables:**

- Technical working group roster and meeting schedule
- Draft IPPC standard proposal (Month 12 = 2027-10-08)
- Formal IPPC proposal submitted to IPPC Standards Committee (Month 18 = 2028-04-08)
- Regional compact agreements (Asia, Africa, Americas) signed (by Month 24 = 2028-10-08)
- 15 country commitment letters to adopt protocol into national law (by Month 24 = 2028-10-08)

**Dependencies:**

- CPT Containment Deputy Director onboarded
- Brazil and major producer-country buy-in secured (via PCCF and direct diplomacy)

### 19. Establish Brazil-led bio-prospecting and Nagoya Protocol benefit-sharing team by Month 1 (2026-11-08), led by Brazilian environmental/legal experts and indigenous-rights specialists, in partnership with CEPLAC and Embrapa. Complete Nagoya/ABS framework agreements with Brazilian states and indigenous organizations by Month 6 (2027-04-08). Establish pooled benefit-sharing fund by Month 6 (2027-04-08) to pre-clear access without renegotiation per cultivar. Begin wild-Hevea collection campaigns by Month 8 (2027-06-08); deliver 200 characterized accessions by Month 18 (2028-04-08).

**Responsible Body/Role:** Core Project Team (Deputy Director, Resistance Breeding & Trials), in partnership with Brazil government, CEPLAC, Embrapa, and indigenous-community representatives

**Suggested Timeframe:** Month 1–18 (2026-11-08 to 2028-04-08)

**Key Outputs/Deliverables:**

- Nagoya Protocol team assembled and ToR drafted
- Framework access-and-benefit-sharing agreements signed with Brazilian states (by Month 6 = 2027-04-08)
- Community benefit-sharing fund established and governance agreed (by Month 6 = 2027-04-08)
- Wild Hevea collection campaigns commenced (Month 8 = 2027-06-08)
- 200 characterized wild Hevea accessions with SALB-resistance documentation delivered (by Month 18 = 2028-04-08)

**Dependencies:**

- CPT Breeding Deputy Director onboarded
- Brazil and indigenous-community buy-in and support secured
- Benefit-sharing fund capital allocated (from breeding pillar budget)

### 20. Establish pathogen genomics laboratories: primary lab in Brazil (CEPLAC or Embrapa) by Month 2 (2026-12-08); satellite lab in Asia (Rubber Research Institute of Malaysia or equivalent) by Month 9 (2027-07-08). Labs will sequence and characterize SALB virulence from trial sites and endemic regions annually, feeding results into cultivar-release decisions. Establish initial tissue culture and somatic-embryogenesis hubs in Asia by Month 12 (2027-10-08).

**Responsible Body/Role:** Core Project Team (Deputy Director, Resistance Breeding & Trials), in partnership with Brazil and Asian research institutes

**Suggested Timeframe:** Month 2–12 (2026-12-08 to 2027-10-08)

**Key Outputs/Deliverables:**

- Brazil pathogen genomics lab operational (Month 2 = 2026-12-08)
- Asia satellite lab operational (Month 9 = 2027-07-08)
- Lab staffing and sequencing protocols established
- First annual virulence survey commenced (Month 12 = 2027-10-08)
- Tissue-culture propagation hubs established in Asia (Month 12 = 2027-10-08)

**Dependencies:**

- Breeding budget allocated and approved
- Institutional partnerships with Brazil CEPLAC/Embrapa and Asian institutes formalized

### 21. Establish high-containment trial stations for resistance field trials: establish at least 4 stations (2 live-pathogen endemic sites in Latin America—Rondônia, Peru; 2 clean-zone sites in Asia and Africa) by Month 12 (2027-10-08). Commission trial site designs, biosafety protocols, and inoculation procedures. Begin field trials with candidate germplasm by Month 18 (2028-04-08). Implement Virulence Gates (Month 24, 36, 48, 60 = 2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08) to assess candidate cultivars against contemporary SALB isolates.

**Responsible Body/Role:** Core Project Team (Deputy Director, Resistance Breeding & Trials), in partnership with trial-site host institutions

**Suggested Timeframe:** Month 0–12 (2026-10-08 to 2027-10-08); trials operational by Month 18 (2028-04-08)

**Key Outputs/Deliverables:**

- Trial station designs and biosafety protocols finalized
- 4 trial stations commissioned (by Month 12 = 2027-10-08)
- Initial candidate germplasm planted and inoculation protocols tested (by Month 18 = 2028-04-08)
- Virulence Gate assessment framework established
- First Virulence Gate assessment (Month 24 = 2028-10-08)

**Dependencies:**

- Germplasm collection and characterization underway (Brazil)
- Pathogen genomics labs operational
- Trial-site host institution agreements signed
- Biosafety and quarantine regulatory approvals obtained

### 22. Design and pilot smallholder replanting finance and surveillance mechanisms by Month 6 (2027-04-08). Co-design with farmer organizations and rural banks: 7–10 year loan tenor, <5% interest, repayment tied to latex sales prices, conditional on certified clean-plant purchasing. Pilot income-bridge schemes and surveillance premiums (USD 25–50 per verified SALB report) in 3–5 representative zones (Sumatra, Côte d'Ivoire, northeast India, Rondônia, optional fifth) during Months 6–24 (2027-04-08 to 2028-10-08). Target 60%+ participation in pilot zones; scale to 2–3 million farmers if pilot uptake achieved.

**Responsible Body/Role:** Core Project Team (Deputy Director, Smallholder Finance & Surveillance), in partnership with farmer organizations, rural banks, and pilot-zone governments

**Suggested Timeframe:** Month 6–24 (2027-04-08 to 2028-10-08)

**Key Outputs/Deliverables:**

- Replant finance product design (terms, disbursement protocols, repayment)
- Income-bridge mechanism design (years without income covered)
- Surveillance-premium mechanism design (reporting, verification, payment timeline)
- Farmer-organization consultations and buy-in secured
- Pilot zones selected and baseline assessment completed (Month 6 = 2027-04-08)
- Pilot deployment operational in 3–5 zones (by Month 12 = 2027-10-08)
- Pilot uptake and satisfaction monitoring reports (quarterly Months 12–24 = 2027-10-08 to 2028-10-08)

**Dependencies:**

- Smallholder finance budget allocated (USD 4.5B, 15% of cap)
- Clean-plant nursery network established (parallel track)
- CPT Deputy Director for Smallholder Finance onboarded

### 23. Establish capacity-building twinning arrangements between Brazilian phytosanitary institutes (e.g., CEPLAC/INA) and Southeast Asian, South Asian, and West African agriculture ministries/research institutes by Month 1 (2026-11-08). Each twinning pair produces joint workplan: staff exchanges, joint lab setup, co-authored protocols, inspector training rotations. Target 500 inspectors trained and certified by Month 36 (2029-10-08). Procure inspection equipment (diagnostic kits, pest traps, data-entry tools) for 50 checkpoints by Month 20 (2028-06-08). Establish Digital Reporting Platform (cloud-based, low-bandwidth) by Month 12 (2027-10-08).

**Responsible Body/Role:** Core Project Team (Deputy Director, Containment & Capacity Building), in partnership with Brazil, producer-country institutions, regional plant protection organizations

**Suggested Timeframe:** Month 1–36 (2026-11-08 to 2029-10-08)

**Key Outputs/Deliverables:**

- Twinning partnership agreements signed (3–5 pairs by Month 6 = 2027-04-08)
- Inspector recruitment and training programs launched (Month 3 = 2027-01-08)
- Inspection equipment procured and distributed (by Month 20 = 2028-06-08)
- Digital reporting platform operational (Month 12 = 2027-10-08)
- 100–200 inspectors trained by Month 24 (2028-10-08)
- 500 inspectors certified and operational by Month 36 (2029-10-08)

**Dependencies:**

- Brazil institutional partnership agreements finalized
- Producer-country budget allocations for capacity building approved
- CPT Containment Deputy Director onboarded

### 24. Initiate OEM buyer consortium engagement and offtake negotiation workstream by Month 0 (2026-10-08), in parallel with technology development. Establish OEM buyer consortium (5–8 major tire and rubber-goods manufacturers) by Month 6 (2027-04-08). Negotiate framework for shared tire-grade qualification testing. Secure 2–3 OEM take-or-pay letters of intent by Month 18 (2028-04-08), committing to 500–2,000 tonnes per annum each. Co-fund OEM qualification testing (Months 12–30 = 2027-10-08 to 2029-04-08) using program capex.

**Responsible Body/Role:** Core Project Team (Deputy Director, Alternative Rubber & Processing), in partnership with OEM representatives and processing operators

**Suggested Timeframe:** Month 0–30 (2026-10-08 to 2029-04-08)

**Key Outputs/Deliverables:**

- OEM Buyer Consortium Charter and governance agreed (by Month 6 = 2027-04-08)
- Buyer-consortium workplan for shared qualification testing
- OEM take-or-pay letters of intent signed (2–3 OEMs by Month 18 = 2028-04-08)
- Tire-grade qualification testing programs funded and underway (Months 12–30 = 2027-10-08 to 2029-04-08)
- Offtake commitment tracking dashboard (updated quarterly)

**Dependencies:**

- Alternative-rubber agronomic pilots underway
- CPT Alternative Rubber Deputy Director onboarded

### 25. Commence Guayule and Russian dandelion agronomic pilots in designated arid and temperate zones by Month 1 (2026-11-08). Establish 3–4 small-scale pilot plots (50–200 hectares each) in distinct climate zones per crop (Guayule: Sonora, Coahuila, Arizona, Argentina; Russian dandelion: temperate Europe, northern Americas). Conduct environmental baseline assessments and sustainability monitoring by Month 12 (2027-10-08). Run processing trials on pilot crops (Months 12–30 = 2027-10-08 to 2029-04-08), testing extraction, resin recovery, and tire-grade quality. Track cost per tonne trajectory toward USD 1.62/kg gate.

**Responsible Body/Role:** Core Project Team (Deputy Director, Alternative Rubber & Processing), in partnership with agronomic research institutes and processing operators

**Suggested Timeframe:** Month 1–30 (2026-11-08 to 2029-04-08)

**Key Outputs/Deliverables:**

- Pilot-plot sites selected and land-use agreements signed (by Month 6 = 2027-04-08)
- Environmental baseline assessments completed (by Month 12 = 2027-10-08)
- Agronomic trials underway (planting, pest/disease monitoring, yield tracking)
- Processing trial data: extraction yield, resin recovery, tire-grade test results (Months 12–30 = 2027-10-08 to 2029-04-08)
- Cost-per-tonne tracking report (quarterly, Months 12–30 = 2027-10-08 to 2029-04-08)

**Dependencies:**

- Land-use permits and environmental clearances obtained
- Agronomic and processing expertise contracted
- Alternative-rubber budget allocated (USD 7.5B, 25%)

### 26. Establish Technical Gate Charter Data Architecture by Month 1 (2026-11-08): specify data-submission templates, quality standards, and timelines from CPT workstreams to Technical Panel. Define 'verified containment,' 'cultivar readiness,' 'cost parity,' and 'smallholder adoption' operationally. Publish interpretation guidelines by Month 6 (2027-04-08). First gate-evidence submission window: Months 50–55 (2030-12-08 to 2031-05-08), allowing 60-day Panel review pre-gate at Month 36 (2029-10-08) decision. [Note: month numbering checks this timeframe; gating at Month 36 (2029-10-08) requires evidence by Month 34 (2029-08-08) at latest; revise CPT submission target to Months 32–34 (2029-08-08 to 2029-10-08) for Month 36 (2029-10-08) gate decision.]

**Responsible Body/Role:** Core Project Team (Technical Secretariat Manager and Deputy Directors), with Technical Panel guidance

**Suggested Timeframe:** Month 1–6 (2026-11-08 to 2027-04-08)

**Key Outputs/Deliverables:**

- Gate Evidence Data Architecture document (specifications for each pillar)
- KPI interpretation guidelines and scoring rubric
- CPT data-submission calendar and templates
- Technical Panel briefing on data-quality standards and assessment procedures

**Dependencies:**

- Technical Gate Charter finalized
- Technical Panel established
- CPT workstreams and data sources identified

### 27. Hold PSC Quarterly Meeting 1 (Month 3 = 2027-01-08) to review early-stage progress on protocol negotiations, germplasm collection, trial-station setup, capacity-building, and smallholder pilots. Discuss funder-alignment and any emerging political risks. Review Technical Gate Charter operationalization and gate-evidence data architecture. Confirm meeting cadence (quarterly, Months 3/6/9/12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08 of each calendar year) and extraordinary meeting triggers.

**Responsible Body/Role:** Program Steering Committee (newly established), chaired by producer-government representative

**Suggested Timeframe:** Month 3 (2027-01-08)

**Key Outputs/Deliverables:**

- PSC Quarterly Meeting Minutes (Month 3 = 2027-01-08)
- Progress dashboard (pillar-by-pillar status, funding deployment, risks, milestones)
- Funder and stakeholder briefing memo

**Dependencies:**

- PSC formally established and operating
- CPT workstreams operational and reporting

### 28. Conduct Month 6 (2027-04-08) mid-program checkpoint: comprehensive review of all workstreams against Month 0–6 (2026-10-08 to 2027-04-08) milestones. Assess containment protocol drafting progress, germplasm collection timelines, trial-station commissioning, capacity-building twinning effectiveness, smallholder-finance pilot uptake, and alternative-rubber agronomic results. Publish first 6-month progress report and funder transparency dashboard. Hold PSC Quarterly Meeting 2 and review any emerging risks or strategy adjustments needed.

**Responsible Body/Role:** Core Project Team (Executive Director and Deputy Directors), reporting to PSC

**Suggested Timeframe:** Month 6 (2027-04-08)

**Key Outputs/Deliverables:**

- Six-Month Progress Report (comprehensive, all workstreams)
- Risk dashboard (emerging or escalated risks, mitigation actions)
- Funder transparency dashboard (funding deployed, burn rate, forecast)
- PSC Quarterly Meeting Minutes (Month 6 = 2027-04-08)
- Any recommended strategy pivots or milestone adjustments (if needed)

**Dependencies:**

- CPT workstreams 6 months operational
- Early milestone data collected and analyzed

### 29. Begin formal pilot of per-tonne industry levy during Months 6–12 (2027-04-08 to 2027-10-08) in ASEAN region (Indonesia, Malaysia, Thailand as initial participating countries). Design collection mechanism at major trading ports and via tyre manufacturers. Set compliance-monitoring protocols. Target pilot collection of USD 40M annually by Month 18 (2028-04-08); if pilot compliance exceeds 80%, proceed to global rollout by Month 36 (2029-10-08). Establish independent levy-trust governance and separate bank account.

**Responsible Body/Role:** Core Project Team (Chief Financial Officer) with ASEAN producer-government partners and trade-finance advisers

**Suggested Timeframe:** Month 6–18 (2027-04-08 to 2028-04-08)

**Key Outputs/Deliverables:**

- Levy design framework (per-tonne rate, collection points, exempt categories, appeals process)
- Levy-trust charter and independent governance structure
- ASEAN pilot operating agreement signed by participating countries
- Compliance monitoring protocol and reporting
- Pilot collection revenue tracking (monthly, Months 12–18 = 2027-10-08 to 2028-04-08)
- Pilot-completion assessment (Month 18 = 2028-04-08): compliance rate, revenue, barriers, global-rollout readiness

**Dependencies:**

- Binding funding commitments secured (provides backup if levy delayed)
- CFO onboarded
- ASEAN producer-government political commitment obtained

### 30. Finalize and submit formal IPPC standard proposal for the SALB Containment Protocol to the IPPC Standards Committee by Month 18 (2028-04-08), based on work of the technical working group (launched Month 0 = 2026-10-08). Proposal includes: protocol scope (nursery stock, research materials, contaminated equipment), national implementation requirements (import rules, inspections, diagnostics), audit and compliance mechanisms, and harmonization with existing regional phytosanitary standards (ASEAN, ECOWAS, Mercosur).

**Responsible Body/Role:** Core Project Team (Deputy Director, Containment & Capacity Building), with IPPC technical working group and producer-country partners

**Suggested Timeframe:** Month 18 (2028-04-08)

**Key Outputs/Deliverables:**

- Formal IPPC Protocol Proposal document (submitted to IPPC Standards Committee)
- Summary of stakeholder review and consensus achieved
- Regional-harmonization assessments (ASEAN, ECOWAS, Mercosur alignment)

**Dependencies:**

- IPPC technical working group active and collaborative (since Month 0 = 2026-10-08)
- Producer-country buy-in and support secured

### 31. Deliver 200 characterized wild Hevea accessions with SALB-resistance documentation to breeding pipelines by Month 18 (2028-04-08), as per Brazil-led bio-prospecting and Nagoya Protocol agreement. Accessions come from endemic Amazon region with documented resistance traits (from field observation or early screening). Accessions are transferred to breeding institutes and trial stations for pyramiding studies. Publish first annual benefit-sharing report documenting royalties, community capacity-building investments, and community satisfaction.

**Responsible Body/Role:** Core Project Team (Deputy Director, Resistance Breeding & Trials), in partnership with Brazil CEPLAC/Embrapa and breeding institutes

**Suggested Timeframe:** Month 18 (2028-04-08)

**Key Outputs/Deliverables:**

- 200 characterized wild Hevea accessions transferred to breeding programs
- Accession characterization report (resistance traits, geographic origin, genetic data)
- First annual Nagoya Protocol benefit-sharing report (royalties, capacity-building, community feedback)

**Dependencies:**

- Brazil-led collection campaigns underway since Month 8 (2027-06-08)
- Germplasm characterization facilities operational
- Benefit-sharing agreements and payment mechanisms established

### 32. Hold comprehensive Month 18 (2028-04-08) program review and PSC Quarterly Meeting (Q2 of Year 2): assess progress on all workstreams 18 months into the program. Specific milestones expected: formal IPPC proposal submitted, Brazil germplasm delivery complete, 100–200 inspectors trained, containment working group active, trial stations operational, first Virulence Gate assessment underway (Month 24 = 2028-10-08 imminent), smallholder pilots reaching target zones, alternative-rubber processing trials ongoing, levy pilot results available, and binding funding commitments from 5–8 sovereigns and 2+ MDBs secured by Month 3 (2027-01-08). Review emerging risks and funder concerns.

**Responsible Body/Role:** Program Steering Committee (with Executive Director and CPT team briefing)

**Suggested Timeframe:** Month 18 (2028-04-08)

**Key Outputs/Deliverables:**

- 18-Month Comprehensive Progress Report (all pillars, major milestones)
- Funder report and commitment status (confirm or highlight gaps)
- Risk escalations and mitigation actions
- PSC Quarterly Meeting Minutes

**Dependencies:**

- All major workstreams 18 months active
- CPT data collection and reporting systems operational

### 33. Finalize regional binding compacts on the SALB Containment Protocol and secure 15 country commitment letters to adopt the protocol into national law by Month 24 (2028-10-08). Compacts cover ASEAN, ECOWAS, Mercosur regions and include reciprocal inspection rights, cross-border quarantine zones, common diagnostic standards, and dispute-resolution procedures. Each of the 15 countries publishes formal letter of political commitment to adopt protocol by Year 3 gate (Month 36 = 2029-10-08).

**Responsible Body/Role:** Core Project Team (Deputy Director, Containment & Capacity Building), with producer-country partners, regional plant protection organizations, and IPPC Secretariat

**Suggested Timeframe:** Month 24 (2028-10-08)

**Key Outputs/Deliverables:**

- Regional binding compacts signed (ASEAN, ECOWAS, Mercosur, Americas)
- 15 country commitment letters (signed by each producing country's authorized representative)
- Compact summary and harmonization achievements
- Country-by-country status roadmap toward legislative adoption (Months 24–36 = 2028-10-08 to 2029-10-08)

**Dependencies:**

- IPPC protocol proposal submitted (Month 18 = 2028-04-08)
- Producer-country political engagement and negotiations ongoing since Month 0 (2026-10-08)
- Regional plant protection organization coordination

### 34. Conduct first Virulence Gate assessment (Month 24 = 2028-10-08) via Technical Panel: evaluate resistance of candidate cultivars to contemporary SALB isolates collected from trial sites and endemic regions. For each candidate: test resistance to at least 10 isolates in high-containment assays; score pass (≥80% resistance to ≥80% of isolates) or hold (revise pyramiding, defer release). Publish pass/hold recommendations; continue breeding work on hold candidates.

**Responsible Body/Role:** Technical Panel (with CPT Deputy Director, Resistance Breeding & Trials, providing evidence)

**Suggested Timeframe:** Month 24 (2028-10-08)

**Key Outputs/Deliverables:**

- Virulence Gate Assessment Report (candidate-by-candidate resistance scores, pass/hold recommendations)
- Pathogen genomics data (virulence isolate characterization, geographic diversity)
- Hold-candidate breeding roadmap (revised pyramiding targets, revised timelines)

**Dependencies:**

- Pathogen genomics labs operational (Brazil Month 2 = 2026-12-08, Asia Month 9 = 2027-07-08)
- Trial candidates planted and under inoculation (Month 18 = 2028-04-08)
- Technical Panel assessments of candidate data

### 35. Conduct Month 30 (2029-04-08) comprehensive gate-readiness checkpoint, 6 months before the Month 36 (2029-10-08) Year 3 gate decision. CPT submits gate-evidence packages to Technical Panel (evidence submission window Months 32–34 = 2029-08-08 to 2029-10-08). Technical Panel begins intensive gate assessment in Months 28–32 (2029-02-08 to 2029-06-08), identifying evidence gaps and requesting clarifications. PSC convenes extraordinary meeting to review potential gate bottlenecks and prepare stakeholders for decision logic.

**Responsible Body/Role:** Core Project Team (Executive Director and Deputy Directors) and Technical Panel

**Suggested Timeframe:** Month 30 (2029-04-08) checkpoint; Month 32–34 (2029-08-08 to 2029-10-08) evidence submission; Month 34–36 (2029-08-08 to 2029-10-08) Panel recommendation; Month 36 (2029-10-08) PSC decision

**Key Outputs/Deliverables:**

- Month 30 (2029-04-08) gate-readiness checkpoint report (sufficiency of evidence for each pillar, anticipated gate outcomes)
- Gate-evidence packages submitted to Technical Panel (Months 32–34 = 2029-08-08 to 2029-10-08)
- CPT responses to Panel data-quality questions (within 14 days of Panel request)
- Technical Panel recommendations drafted and sent to PSC (Month 34 = 2029-08-08, allow 2-week review before public release)

**Dependencies:**

- All workstream data collected and validated
- Technical Panel intensive gate-assessment window active (Months 28–32 = 2029-02-08 to 2029-06-08)
- CPT data-submission deadlines met

### 36. Publish Year 3 gate-evidence package publicly by Month 34–35 (2029-08-08 to 2029-09-08), 60 days before PSC decision at Month 36 (2029-10-08). Package includes: containment protocol adoption status (15 country commitment letters, legislative progress), inspector-training data (500 trained, certified, deployed), documented suspect detections (≥2 lab-cleared), cultivar-readiness assessment (candidate resistance scores from Virulence Gates, trial data, yield parity evidence), smallholder pilot results (uptake rate, satisfaction, finance performance), alternative-rubber cost and quality data, and risk assessments. Include Technical Panel recommendations and any Panel dissents. Open 30-day review and appeal window for PSC members, funders, and producer governments.

**Responsible Body/Role:** Technical Panel and Core Project Team (Technical Secretariat Manager, publishing lead)

**Suggested Timeframe:** Month 34–35 (2029-08-08 to 2029-09-08); 60-day public review Months 34–36 (2029-08-08 to 2029-10-08)

**Key Outputs/Deliverables:**

- Year 3 Gate Evidence Package (published online and in print, 200+ pages, technical sections by pillar)
- Technical Panel recommendation summary (2–3 page executive summary with rationale and dissents if any)
- Public notice of 30-day appeal window (opens Month 34 = 2029-08-08, closes Month 37 = 2029-11-08; PSC decision at Month 36 = 2029-10-08 is provisional pending appeal outcome)

**Dependencies:**

- All gate-evidence data compiled and quality-checked
- Technical Panel assessment complete
- Secretariat publishing and distribution infrastructure operational

### 37. Convene PSC extraordinary gate-decision meeting at Month 36 (2029-10-08) (Year 3 gate). PSC reviews Technical Panel recommendation, hears arguments from CPT and interested stakeholders (if invited), and votes on tranche release (full, partial, or withheld) and any conditional releases. Decision rules per Technical Gate Charter: supermajority (≥75% of PSC members) to approve full tranches; consensus required for strategy pivots >10% reallocation. Publish PSC decision (including dissents) within 5 business days. If formal appeals filed within 30 days, refer to arbitration (UNCITRAL rules, 6-month timeline).

**Responsible Body/Role:** Program Steering Committee (PSC chair presiding)

**Suggested Timeframe:** Month 36 (2029-10-08)

**Key Outputs/Deliverables:**

- PSC Year 3 Gate Decision Meeting Minutes
- PSC formal gate decision (tranches released, conditions, timeline for next tranche)
- Published decision rationale and any dissents (within 5 business days)
- Tranche release authorization and payment instructions to CFO

**Dependencies:**

- Year 3 gate-evidence package published and reviewed (Months 34–36 = 2029-08-08 to 2029-10-08)
- Technical Panel recommendation provided
- PSC members briefed and prepared
- Appeal submission deadline passed (Month 37 = 2029-11-08) unless expedited arbitration requested

### 38. Execute Month 36 (2029-10-08) Year 3 gate tranche release based on PSC decision. If full attainment (≥85%), release 100% of Year 3 tranche (USD 4.5B). If partial attainment (70–85%), release proportionally (e.g., 75% if 75% criteria met = USD 3.375B), with remainder reallocated to contingency pool or stronger pillars. If <70% attainment, release 50% (USD 2.25B) and move remainder (USD 2.25B) to contingency pool. Tranches distributed by pillar to CPT workstreams; CPT begins Months 36–84 (2029-10-08 to 2033-10-08) activities (Phase 2).

**Responsible Body/Role:** Program Steering Committee (PSC) and Core Project Team (Chief Financial Officer executing)

**Suggested Timeframe:** Month 36 (2029-10-08), tranches received by CPT by Month 37–38 (2029-11-08 to 2029-12-08)

**Key Outputs/Deliverables:**

- PSC tranche-release authorization
- Wire transfer confirmation from funder accounts to CPT operating and pillar accounts
- Financial ledger update (tranche deployed, reserve balances adjusted)
- CPT Phase 2 workplan activation (breeding trials, protocol enforcement, alternative-rubber scaling begin)

**Dependencies:**

- PSC Year 3 gate decision finalized
- No sustained appeals or arbitration stalling payment
- CFO systems and accounts operational

### 39. Conduct quarterly PSC meetings and annual comprehensive program reviews throughout Months 36–84 (2029-10-08 to 2033-10-08) (Phase 2). PSC meets quarterly (Months 39, 42, 45 = 2030-01-08, 2030-04-08, 2030-07-08, etc. = 2029-12-08, 2030-03-08, 2030-06-08, etc.) to monitor: protocol adoption legislative progress (15 countries aiming for legal adoption by Month 36 = 2029-10-08, formalization by Month 60 = 2031-10-08), resistance-breeding trials (Months 36–60 = 2029-10-08 to 2031-10-08 intermediate Virulence Gate assessments, final candidates emerging Months 60–72 = 2031-10-08 to 2032-10-08), alternative-rubber pilot economics and OEM offtake progress, smallholder-adoption scale-up (replant finance and surveillance-premium expansion), funder alignment and political risks, emerging technical or financial challenges.

**Responsible Body/Role:** Program Steering Committee (PSC chair and members)

**Suggested Timeframe:** Quarterly: Months 39, 42, 45, 48, 51, 54, 57, 60, 63, 66, 69, 72, 75, 78, 81, 84 (2029-12-08, 2030-03-08, 2030-06-08, 2030-09-08, 2030-12-08, 2031-03-08, 2031-06-08, 2031-09-08, 2031-12-08, 2032-03-08, 2032-06-08, 2032-09-08, 2032-12-08, 2033-03-08, 2033-06-08, 2033-09-08); Annual deep-dive reviews at Months 48, 72 (2030-10-08, 2032-10-08)

**Key Outputs/Deliverables:**

- Quarterly PSC meeting minutes (16 meetings over Months 36–84 = 2029-10-08 to 2033-10-08)
- Quarterly progress dashboards (funding, risk, milestone tracking)
- Annual comprehensive program reviews (Months 48, 72 = 2030-10-08, 2032-10-08) with funder and stakeholder briefings

**Dependencies:**

- PSC established and operating
- CPT reporting systems live and quarterly reports delivered on schedule

### 40. Conduct Virulence Gate assessments at Months 36, 48, 60 (2029-10-08, 2030-10-08, 2031-10-08) within Phase 2: Technical Panel evaluates resistance durability of candidate cultivars against evolving SALB pathogen population. At each gate: test candidates against 10+ contemporary isolates, score resistance, recommend hold or advance. Pass candidates move toward multi-location validation; hold candidates remain in breeding pipelines. Document virulence-stability forecasts (5+ years expected durability). By Month 60 (2031-10-08), at least 2 candidates expected to be approaching final-stage trials.

**Responsible Body/Role:** Technical Panel (with CPT Breeding Deputy Director providing evidence)

**Suggested Timeframe:** Month 36 (2029-10-08), Month 48 (2030-10-08), Month 60 (2031-10-08)

**Key Outputs/Deliverables:**

- Virulence Gate assessment reports (Months 36, 48, 60 = 2029-10-08, 2030-10-08, 2031-10-08)
- Candidate-specific pass/hold/advance recommendations
- Virulence-stability forecast data (isolate diversity, evolution trends, predicted resistance durability)
- Breeding roadmap updates (revised timelines for hold candidates)

**Dependencies:**

- Pathogen genomics data collected annually and isolates characterized
- Trial-candidate data available from field sites
- Technical Panel active and assessing

### 41. Conduct Containment Efficacy Review during Months 72–84 (2032-10-08 to 2033-10-08) (Phase 2 end / Year 7 gate preparation): Technical Panel and CPT audit whether SALB-containment protocol is functionally preventing undetected incursions in currently-free regions (Asia, Africa). Minimum threshold: at least 50 documented suspect detections logged and laboratory-confirmed by Month 84 (2033-10-08). If <20 detections by Month 72 (2032-10-08), escalate surveillance sensitivity (increase sampling frequency, testing rates, inspector coverage). If zero detections by Month 60 (2031-10-08), convene emergency review (possible explanations: protocol is 100% effective; no material is moving; inspections are ineffective). Prepare contingency outbreak-response playbook for credible incursion scenario.

**Responsible Body/Role:** Technical Panel and Core Project Team (Deputy Director, Containment & Capacity Building)

**Suggested Timeframe:** Months 72–84 (2032-10-08 to 2033-10-08)

**Key Outputs/Deliverables:**

- Containment Efficacy Review report (Months 72–84 = 2032-10-08 to 2033-10-08)
- Suspect-detection log and laboratory-confirmation data (all 50+ records)
- Surveillance-sensitivity assessment and any recommended adjustments
- Outbreak-response playbook (trigger criteria, compensation rules, funding sources, deployment timelines)

**Dependencies:**

- Inspection checkpoints operational and reporting suspect materials
- Laboratory confirmation systems functional
- Technical Panel oversight and data verification

### 42. Finalize and deploy smallholder-replanting scale-up across 2–3 million eligible farmers in Asia, Africa, and Latin America by Month 72 (2032-10-08), based on pilot results from Months 6–24 (2027-04-08 to 2028-10-08). Extend replant-loan program (7–10 year tenor, <5% interest, income bridge for immature years) to all major rubber zones. Expand clean-plant nursery network to 300–600 regional hubs. Introduce surveillance-premium mechanism scaled to USD 25–50 per verified SALB report, targeting 60%+ farmer participation. Expected outcome: at least 1.5 million smallholders adopting resistant cultivars or alternatives by Month 144 (2038-10-08) (Year 12 gate).

**Responsible Body/Role:** Core Project Team (Deputy Director, Smallholder Finance & Surveillance), in partnership with farmer organizations, rural banks, and clean-plant nursery operators

**Suggested Timeframe:** Months 24–72 (2028-10-08 to 2032-10-08); scale-up completion by Month 72 (2032-10-08)

**Key Outputs/Deliverables:**

- Smallholder finance scale-up plan (credit expansion, nursery network, surveillance premiums)
- Replant-loan portfolio tracking (loans disbursed, repayment rates, uptake by region)
- Clean-plant nursery network operational (300+ hubs, certified stock production)
- Surveillance-premium participation data (farmers reporting SALB suspects, payment tracking)
- Quarterly uptake and satisfaction monitoring (Months 36–72 = 2029-10-08 to 2032-10-08)

**Dependencies:**

- Pilot results show 60%+ uptake and satisfaction (Months 6–24 = 2027-04-08 to 2028-10-08)
- Finance infrastructure and disbursement systems operational
- Resistant cultivars approaching readiness (trial data available for farmer confidence)

### 43. Scale alternative-rubber agronomic trials to commercial-pilot scale (5,000–20,000 tonnes per annum) by Month 60–72 (2031-10-08 to 2032-10-08). Guayule hubs in arid zones and Russian dandelion in temperate zones should be demonstrating cost trajectory toward USD 1.62/kg (20% premium vs. Hevea) and tire-grade quality passing 95% of Hevea specifications by Month 72 (2032-10-08). OEM buyer consortium should have locked in at least 80% of Year-10 planned volumes (1.6 million tonnes target for Year 12 = 160,000 tonnes) via written priced offtake by Month 72 (2032-10-08), enabling hub financing approvals.

**Responsible Body/Role:** Core Project Team (Deputy Director, Alternative Rubber & Processing), in partnership with agronomic research institutes, processing operators, and OEM consortium

**Suggested Timeframe:** Months 36–72 (2029-10-08 to 2032-10-08)

**Key Outputs/Deliverables:**

- Commercial-pilot agronomic data (yield, pest/disease pressure, climate impacts, water use, soil health)
- Processing trial results and cost tracking (USD 1.62/kg or better targeted)
- Tire-grade quality test results (95%+ of Hevea specs achieved)
- OEM offtake commitments summary (signed letters, volumes, price formulas, qualification status)
- Hub financing plan and approval-readiness assessment (Month 72 = 2032-10-08)

**Dependencies:**

- Pilot plots established and managed (since Month 1 = 2026-11-08)
- Processing trials ongoing (Months 12–30 = 2027-10-08 to 2029-04-08), then scaled
- OEM engagement active (since Month 0 = 2026-10-08), buyer consortium formed (Month 6 = 2027-04-08)

### 44. Conduct Month 72 (2032-10-08) comprehensive Phase 2 review and gate-readiness preparation: PSC and CPT assess Months 36–72 (2029-10-08 to 2032-10-08) progress (36-month mid-program point). Specific expectations: 15 countries with protocol adopted into law and operational inspectorates (500+ inspectors certified and deployed); containment-efficacy evidence compiled (50+ suspect detections); resistance-breeding candidates at final-trial stage (2–3 candidates with pass ratings from Virulence Gates, yield data approaching elite-clone parity); alternative-rubber pilots showing cost trajectory to Year 7 gate target and OEM offtake majority-locked; smallholder adoption at 1+ million farmers; funder commitment renewals confirmed for next tranche. Publish 36-month progress report.

**Responsible Body/Role:** Program Steering Committee and Core Project Team

**Suggested Timeframe:** Month 72 (2032-10-08)

**Key Outputs/Deliverables:**

- 36-Month Comprehensive Progress Report (all pillars, major milestones, technical achievements)
- Gate-readiness assessment for Month 84 (2033-10-08) Year 7 gate (anticipate outcomes, evidence gaps)
- Funder commitment renewal status (confirm continued multi-year support or identify gaps)
- Risk dashboard and escalations
- PSC Quarterly Meeting (Month 72 = 2032-10-08) with stakeholder briefing

**Dependencies:**

- All workstreams 3+ years operational and reporting
- Milestone data collected and validated
- CPT and PSC governance fully mature and experienced

### 45. Conduct second Virulence Gate assessment (Month 60 = 2031-10-08) and prepare final cultivar-readiness evidence for Year 7 gate. Technical Panel evaluates resistance candidates against virulence isolates; final-stage trial data reviewed (yield parity evidence, disease-pressure responses across multiple sites). By Month 72 (2032-10-08), CPT has compiled all cultivar-readiness data for gate decision. Expected outcome at Month 84 (2033-10-08) Year 7 gate: at least 2 candidates approved or 1 candidate with strong commercialization pathway, each carrying 3+ pyramided resistance genes.

**Responsible Body/Role:** Technical Panel and Core Project Team (Deputy Director, Resistance Breeding & Trials)

**Suggested Timeframe:** Month 60 (2031-10-08) Virulence Gate; Months 72–82 (2032-10-08 to 2033-08-08) cultivar-readiness data compilation; Month 84 (2033-10-08) Year 7 gate decision

**Key Outputs/Deliverables:**

- Virulence Gate assessment (Month 60 = 2031-10-08): candidate resistance scores and pass/hold recommendations
- Cultivar-readiness evidence package (Months 72–82 = 2032-10-08 to 2033-08-08): multi-site trial data, yield parity evidence, virulence-stability forecasts
- Technical Panel Year 7 gate recommendation (Month 82 = 2033-08-08)

**Dependencies:**

- Multi-location trial sites operational and providing yield and disease-response data
- Pathogen genomics data current and virulence characterization ongoing
- Technical Panel active and assessing

### 46. Publish Year 7 gate-evidence package publicly by Month 82–83 (2033-08-08 to 2033-09-08), 60 days before PSC decision at Month 84 (2033-10-08). Package includes: protocol-adoption status (15 countries expected to have full legislative adoption by now); containment-efficacy data (50+ documented detections, surveillance effectiveness assessment); resistance-cultivar readiness (2+ candidates with ≥90% resistance, ≥85% yield parity, 5+ year virulence-stability forecast); alternative-rubber cost/quality data (USD 1.62/kg or better, tire-grade tests 95%+ parity); smallholder adoption (1+ million farmers, replant-loan performance, surveillance-participation rates); and risk assessments. Include Technical Panel recommendations and any dissents. Open 30-day appeal window.

**Responsible Body/Role:** Technical Panel and Core Project Team (Technical Secretariat Manager)

**Suggested Timeframe:** Month 82–83 (2033-08-08 to 2033-09-08); 60-day public review Months 82–84 (2033-08-08 to 2033-10-08)

**Key Outputs/Deliverables:**

- Year 7 Gate Evidence Package (published online and print, 250+ pages, pillar sections)
- Technical Panel recommendation summary (executive summary with rationale and dissents)
- Public notice of 30-day appeal window

**Dependencies:**

- All gate-evidence data compiled and quality-checked
- Technical Panel assessment complete
- CPT data-submission deadline met

### 47. Convene PSC extraordinary gate-decision meeting at Month 84 (2033-10-08) (Year 7 gate). PSC reviews Technical Panel recommendation and decides on tranche release for Months 84–144 (2033-10-08 to 2038-10-08) (Phase 3). Decision rules: supermajority for tranches, consensus for >10% pillar reallocation. Expected decision: full or partial release of USD 4.5–6.5B (estimate, 2nd-tranche envelope) for scaling breeding, alternatives, and smallholder work. Publish decision within 5 business days. Process any appeals via arbitration.

**Responsible Body/Role:** Program Steering Committee (PSC chair presiding)

**Suggested Timeframe:** Month 84 (2033-10-08)

**Key Outputs/Deliverables:**

- PSC Year 7 Gate Decision Meeting Minutes
- PSC formal gate decision and tranche release authorization
- Published decision rationale and dissents (within 5 business days)

**Dependencies:**

- Year 7 gate-evidence package published and reviewed (Months 82–84 = 2033-08-08 to 2033-10-08)
- Technical Panel recommendation provided
- Appeal deadline passed (Month 85 = 2033-11-08)

### 48. Execute Year 7 gate tranche release (Month 84 = 2033-10-08). If ≥85% attainment: release 100% of tranche. If 70–85%: release proportionally. If <70%: release 50% and hold remainder in contingency. Tranches distributed to CPT pillars; Phase 3 (Months 84–144 = 2033-10-08 to 2038-10-08) activities commence: breeding scale-up, resistance-cultivar commercialization, alternative-rubber hub construction approval (if OEM offtake locked), smallholder adoption continued, protocol enforcement hardened in all 15 countries.

**Responsible Body/Role:** Program Steering Committee (PSC) and Core Project Team (Chief Financial Officer)

**Suggested Timeframe:** Month 84 (2033-10-08), funds received by CPT by Months 85–86 (2033-11-08 to 2033-12-08)

**Key Outputs/Deliverables:**

- PSC tranche-release authorization
- Wire transfer confirmation and ledger updates
- Phase 3 workplan activation (breeding commercialization, hub construction, adoption scale-up)

**Dependencies:**

- PSC Year 7 gate decision finalized
- No sustained appeals stalling payment

### 49. Conduct quarterly PSC meetings throughout Phase 3 (Months 84–144 = 2033-10-08 to 2038-10-08) to monitor: resistance-cultivar commercialization (regulatory approvals, seed multiplication, smallholder distribution), alternative-rubber hub construction and ramp-up (construction progress, cost tracking, commissioning timelines), alternative-rubber production (target 200,000 t/yr by Month 144 = 2038-10-08), smallholder adoption (target 1.5 million by Month 144 = 2038-10-08), protocol enforcement in all 15 countries (inspection quality, suspect-detection logging, cross-border coordination), funder alignment and political risks.

**Responsible Body/Role:** Program Steering Committee (PSC chair and members)

**Suggested Timeframe:** Quarterly: Months 87, 90, 93 (2034-01-08, 2034-04-08, 2034-07-08), ... 144 (2034-01-08, 2034-04-08, 2034-07-08, ... 2038-10-08); Annual deep-dive at Months 96, 120 (2034-10-08, 2036-10-08)

**Key Outputs/Deliverables:**

- Quarterly PSC meeting minutes (16 meetings over Months 84–144 = 2033-10-08 to 2038-10-08)
- Quarterly progress dashboards
- Annual comprehensive reviews (Months 96, 120 = 2034-10-08, 2036-10-08)

**Dependencies:**

- PSC operating and CPT reporting systems live

### 50. Approve commercial alternative-rubber hub construction by Month 96 (2034-10-08) (Phase 3 checkpoint) only if: (1) OEM offtake is at least 80% priced and written (500+ tonnes per annum per OEM, multiple OEMs committing); (2) agronomic pilot cost data shows USD 1.62/kg achievable or below; (3) tire-grade quality specs validated; (4) environmental and permitting approvals secured; (5) debt financing structured (private or development-bank backed). Target hub commissioning by Month 120 (2036-10-08) and ramp to 200,000 t/yr by Month 144 (2038-10-08). If conditions not met by Month 96 (2034-10-08), defer hub construction to Months 108–120 (2036-10-08 to 2036-10-08), pushing production timeline 1–2 years later.

**Responsible Body/Role:** Program Steering Committee (with CPT Deputy Director, Alternative Rubber & Processing, and OEM consortium input)

**Suggested Timeframe:** Month 96 (2034-10-08) approval decision; construction if approved Months 96–120 (2034-10-08 to 2036-10-08); commissioning by Month 120 (2036-10-08)

**Key Outputs/Deliverables:**

- Hub construction approval or deferral decision (Month 96 = 2034-10-08)
- Hub construction timeline and capex plan (if approved)
- Financing structure and debt-agreement signatures
- Environmental compliance and permitting documentation

**Dependencies:**

- OEM offtake majority-locked (by Month 72–96 = 2032-10-08 to 2034-10-08)
- Alternative-rubber pilot data showing cost trajectory (by Month 72 = 2032-10-08)
- Permitting and environmental clearances

### 51. Conduct Month 120 (2036-10-08) mid-Phase 3 review and Year 12 gate-readiness preparation. PSC and CPT assess Months 84–120 (2033-10-08 to 2036-10-08) progress (48-month Phase 3 midpoint). Expectations: resistance cultivars approved for commercial release and seed-multiplication underway; alternative-rubber hubs commissioned or on-track for Month 144 (2038-10-08) target; production ramping toward 200,000 t/yr target; 1.5 million smallholders expected to have adopted resistant cultivars or alternatives by Month 144 (2038-10-08); protocol enforcement operational in 15 countries; contingency reserves assessed. Publish 48-month review report.

**Responsible Body/Role:** Program Steering Committee and Core Project Team

**Suggested Timeframe:** Month 120 (2036-10-08)

**Key Outputs/Deliverables:**

- 48-Month Comprehensive Progress Report (Phase 3 midpoint, Months 84–120 = 2033-10-08 to 2036-10-08)
- Year 12 gate-readiness assessment (what evidence will be needed by Month 144 = 2038-10-08)
- Funder commitment status (confirm or identify gaps for remaining tranches)
- Risk dashboard and escalations
- PSC meeting (Month 120 = 2036-10-08)

**Dependencies:**

- All workstreams 5+ years operational
- Hub construction milestones on track

### 52. Prepare Year 12 gate-evidence package (Months 136–142 = 2038-06-08 to 2038-08-08) and publish by Month 142 (2038-08-08), 60 days before PSC decision at Month 144 (2038-10-08). Package includes: protocol enforcement outcomes (verified containment in 15+ countries, zero undetected SALB incursions); resistant-cultivar adoption (1.5 million smallholders, seed multiplication ramp-up); alternative-rubber production (≥200,000 t/yr operating, cost/quality at gate thresholds); smallholder finance performance (replant-loan repayment, surveillance participation); risk assessments and climate-shock resilience testing. Include Technical Panel recommendations and dissents. Open 30-day appeal window.

**Responsible Body/Role:** Core Project Team (Technical Secretariat Manager) and Technical Panel

**Suggested Timeframe:** Months 136–142 (2038-06-08 to 2038-08-08); 60-day public review Months 142–144 (2038-08-08 to 2038-10-08)

**Key Outputs/Deliverables:**

- Year 12 Gate Evidence Package (published, 300+ pages, pillar sections)
- Technical Panel Year 12 recommendation
- Climate-shock stress-test results (alternative-rubber viability under drought/flood scenarios)

**Dependencies:**

- All gate-evidence data compiled and validated
- Technical Panel assessment complete

### 53. Convene PSC extraordinary gate-decision meeting at Month 144 (2038-10-08) (Year 12 gate). PSC reviews Technical Panel recommendation and decides on tranche release for Months 144–216 (2038-10-08 to 2044-10-08) (Phase 4). Expected decision: full or partial release of remaining tranches (estimate USD 5–7B, final tranche envelope) for continued scaling, smallholder adoption, alternative-rubber expansion to 5% global supply target, and protocol/research sustainability into Phase 5 handover. Publish decision within 5 business days.

**Responsible Body/Role:** Program Steering Committee (PSC chair presiding)

**Suggested Timeframe:** Month 144 (2038-10-08)

**Key Outputs/Deliverables:**

- PSC Year 12 Gate Decision Meeting Minutes
- PSC formal gate decision and Year 12–18 tranche release authorization
- Published decision rationale and dissents

**Dependencies:**

- Year 12 gate-evidence package published and reviewed (Months 142–144 = 2038-08-08 to 2038-10-08)
- Technical Panel recommendation provided
- Appeal deadline passed (Month 145 = 2038-11-08)

### 54. Execute Year 12 gate tranche release (Month 144 = 2038-10-08). Release tranches according to attainment (full, partial, or 50% if <70%). Tranches distributed to CPT pillars; Phase 4 (Months 144–216 = 2038-10-08 to 2044-10-08) activities commence: alternative-rubber scale-up to 5% global supply (USD 700,000 t/yr target by Month 216 = 2044-10-08), resistant-cultivar adoption continuation (targeting full genetic diversity in major plantations by Year 18), smallholder sustainability and price-stability mechanisms hardened, protocol enforcement and surveillance maintained, transition planning for post-funding handover (Phases 5, Months 216–300 = 2044-10-08 to 2050-10-08).

**Responsible Body/Role:** Program Steering Committee (PSC) and Core Project Team (Chief Financial Officer)

**Suggested Timeframe:** Month 144 (2038-10-08)

**Key Outputs/Deliverables:**

- PSC tranche-release authorization
- Wire transfers and ledger updates
- Phase 4 workplan activation (scaling to 5% global supply, handover planning)

**Dependencies:**

- PSC Year 12 gate decision finalized
- No sustained appeals stalling payment

### 55. Conduct quarterly PSC meetings throughout Phase 4 (Months 144–216 = 2038-10-08 to 2044-10-08) to monitor: alternative-rubber production expansion to 5% global demand (700,000 t/yr target by Month 216 = 2044-10-08), resistant-cultivar global adoption and genetic diversity in major regions, smallholder sustainability and price-stability effectiveness, protocol enforcement durability and producer-country institutional ownership (capacity handover preparation), funder commitment for final tranche (Year 18 gate at Month 216 = 2044-10-08) and post-program responsibilities.

**Responsible Body/Role:** Program Steering Committee (PSC chair and members)

**Suggested Timeframe:** Quarterly: Months 147, 150, 153 (2039-01-08, 2039-04-08, 2039-07-08), ... 216 (2039-01-08, 2039-04-08, 2039-07-08, ... 2044-10-08); Annual deep-dive at Months 156, 180, 204 (2039-10-08, 2041-10-08, 2043-10-08)

**Key Outputs/Deliverables:**

- Quarterly PSC meeting minutes (24 meetings over Phase 4)
- Annual comprehensive reviews (Months 156, 180, 204 = 2039-10-08, 2041-10-08, 2043-10-08)

**Dependencies:**

- PSC operating; CPT reporting systems live

### 56. Conduct handover-readiness assessments (Months 180–216 = 2041-10-08 to 2044-10-08) with Producer-Country Coordination Forum (PCCF) to evaluate whether national agricultural agencies, research institutes, and inspection services in 15+ producing countries are ready for post-funding sustainability and protocol enforcement. Assess: staffing and retention, budgeting and institutional funding, technical capability (labs, nurseries, inspectors), political commitment, and ownership of protocols and cultivars. Identify pre-handover capacity-building needs and remedial investments. By Month 216 (2044-10-08), establish transition plan to producer-country leadership and multilateral secretariat closure or reduced role.

**Responsible Body/Role:** Producer-Country Coordination Forum (PCCF) and Core Project Team (CPT Deputy Directors), with Technical Panel input

**Suggested Timeframe:** Months 180–216 (2041-10-08 to 2044-10-08)

**Key Outputs/Deliverables:**

- Handover-readiness assessments (country-by-country evaluations by Month 200 = 2043-06-08)
- Producer-country institutional capacity audit (staffing, funding, ownership)
- Remedial capacity-building plan (if gaps identified)
- Transition and handover plan for Month 216 (2044-10-08) onwards

**Dependencies:**

- PCCF active and engaged (since Month 1 = 2026-11-08)
- Capacity-building twinning and training complete or handed over to national programs

### 57. Prepare Year 18 gate-evidence package (Months 208–212 = 2044-06-08 to 2044-08-08) and publish by Month 212 (2044-06-08), 60 days before PSC decision at Month 216 (2044-10-08). Package includes: protocol enforcement outcomes and handover readiness (15+ countries with operationally independent national capacity); resistant-cultivar adoption and genetic diversity (global adoption across major regions, seed systems operationally independent); alternative-rubber supply at 5%+ global demand (700,000+ t/yr); smallholder sustainability and price-stability mechanisms (farmer income secured, surveillance participation sustained); producer-country readiness for post-funding operation; financial sustainability of national programs and protocol enforcement. Include Technical Panel final assessment and transition recommendations.

**Responsible Body/Role:** Core Project Team and Technical Panel

**Suggested Timeframe:** Months 208–212 (2044-06-08 to 2044-08-08); 60-day public review Months 212–216 (2044-08-08 to 2044-10-08)

**Key Outputs/Deliverables:**

- Year 18 Gate Evidence Package (published, 300+ pages, handover-readiness focus)
- Technical Panel Year 18 final assessment and transition recommendations
- Handover plan for post-program operations (Months 216–300 = 2044-10-08 onwards)

**Dependencies:**

- All gate-evidence data compiled and validated
- Handover-readiness assessments completed
- Technical Panel final assessment complete

### 58. Convene PSC extraordinary gate-decision meeting at Month 216 (2044-10-08) (Year 18 gate). PSC reviews Technical Panel final assessment and decides on final tranche release and program transition. Decision typically: (a) release final tranches (if attainment ≥70%) for Months 216–300 (2044-10-08 onwards) post-program responsibilities; (b) authorize multilateral secretariat transition plan (reduce staff, hand over functions to producer-country institutions and remaining governance bodies, close or downsize if post-program monitoring deemed unnecessary). Publish decision. This is the final programmatic gate; Phase 5 (Months 216–300 = 2044-10-08 to 2050-10-08) is post-program operation and handover.

**Responsible Body/Role:** Program Steering Committee (PSC chair presiding)

**Suggested Timeframe:** Month 216 (2044-10-08)

**Key Outputs/Deliverables:**

- PSC Year 18 Gate Decision Meeting Minutes
- PSC formal final-tranche release authorization and transition decision
- Published decision and program-closeout plan
- Multilateral secretariat transition/closeout workplan

**Dependencies:**

- Year 18 gate-evidence package published and reviewed (Months 212–216 = 2044-08-08 to 2044-10-08)
- Technical Panel final assessment and handover recommendations provided
- Producer-country readiness confirmed

### 59. Execute Year 18 gate tranche release (Month 216 = 2044-10-08) and authorize program closeout plan. Final tranches (if any) distributed for post-program operations (Months 216–300 = 2044-10-08 to 2050-10-08), including: monitoring residual risks (SALB surveillance continuation), smallholder support (phased reduction of subsidies, transition to farmer-led mechanisms), producer-country institutional sustainability (capacity building winding down, national ownership complete), and archival of data and lessons learned. Multilateral secretariat staff transitions to post-program support roles or exits.

**Responsible Body/Role:** Program Steering Committee (PSC) and Core Project Team (Executive Director)

**Suggested Timeframe:** Month 216 (2044-10-08) onwards; program close-out completed by Month 300 (2050-10-08)

**Key Outputs/Deliverables:**

- PSC final tranche-release authorization
- Program closeout and transition plan (Months 216–300 = 2044-10-08 to 2050-10-08)
- Multilateral secretariat transition/closure procedures
- Handover to producer-country institutions and remaining governance bodies

**Dependencies:**

- PSC Year 18 gate decision finalized
- Producer-country capacity and ownership confirmed

### 60. Establish post-program governance continuation mechanism (Phase 5, Months 216–300 = 2044-10-08 to 2050-10-08): if ongoing SALB surveillance and producer-country coordination are deemed necessary, convert PSC to a lighter-weight multilateral oversight body or hand functions to existing regional plant protection organizations (ASEAN, ECOWAS, Mercosur) and IPPC Secretariat. Producer-Country Coordination Forum (PCCF) may continue as primary governance body for producer-country collaboration and protocol enforcement, with reduced external (development-bank) participation. Establish modest residual endowment (if available) for long-term surveillance and emergency response.

**Responsible Body/Role:** Program Steering Committee (PSC) and Producer-Country Coordination Forum (PCCF)

**Suggested Timeframe:** Months 208–216 (2044-06-08 to 2044-10-08) planning; transition to new governance by Month 216 (2044-10-08); Phase 5 continues to Month 300 (2050-10-08)

**Key Outputs/Deliverables:**

- Post-program governance charter (functions, decision rights, funder roles Months 216–300 = 2044-10-08 to 2050-10-08)
- PCCF expanded charter (if becomes primary body for post-program)
- Regional plant protection organization transition agreements (handover of protocol monitoring)
- Residual endowment or contingency fund for long-term surveillance (if established)

**Dependencies:**

- Program closeout plan agreed at Month 216 (2044-10-08) gate
- Producer-country consensus on post-program arrangements
- Regional plant protection organization buy-in

# Decision Escalation Matrix

**Budget Request Exceeding PMO Authority**
Escalation Level: Program Steering Committee (PSC)
Approval Process: PSC supermajority vote (≥75% of members); for tranches >USD 1.0B, explicit approval required from each development-bank representative present. Decision published within 5 business days with rationale.
Rationale: Single-pillar spending >USD 50M or cross-pillar reallocation >10% exceeds CPT autonomous authority and risks unbalanced capital deployment across containment, breeding, alternatives, and smallholder pillars. PSC oversight ensures funder alignment and preserves stage-gate discipline.
Negative Consequences: Unopposed overspending in one pillar starves others, creating cascading delays (e.g., breeding timeline slip if alternatives consume contingency). Funder confidence erodes if capital appears diverted from planned gates. Unilateral reallocation >10% can trigger early funder withdrawal and withholding of subsequent tranches.

**Critical Technical Delay Exceeding 12-Month Milestone Slip**
Escalation Level: Program Steering Committee (PSC) and Technical Panel
Approval Process: CPT alerts PSC and Technical Panel within 5 business days of detecting >12-month slip. Technical Panel assesses whether slip affects gate evidence or cultivar/alternative-rubber readiness. PSC extraordinary meeting within 14 days; decision on timeline adjustment, contingency-pool reallocation, or strategy pivot (>10% pillar reallocation requires consensus). Published decision within 5 business days.
Rationale: Breeding cycles, trial sites, and alternative-rubber pilots have biological and institutional uncertainties. A >12-month slip in resistance-cultivar readiness, alternative-rubber cost trajectory, or protocol-adoption timelines risks gate failure and cascade delays into following phases. Early escalation allows PSC to adjust gate criteria, defer gates, or reallocate funding to mitigate downstream impact.
Negative Consequences: Unescalated slips compound: Year 7 gate delayed by 18 months reduces Phase 2 duration, compressing scaling timelines. Smallholder adoption campaigns delayed if cultivars unavailable. Alternative-rubber hub construction frozen pending evidence, stranding capex and losing OEM confidence. Funder frustration with missed milestones triggers budget-cut pressure and early withdrawal.

**Governance Deadlock: PSC Members Deadlocked on Gate Decision (>50% Dissent)**
Escalation Level: Independent Arbitration (UNCITRAL or ICC Rules) or Crisis Steering Group (Chair + 2 producers + 2 OEMs + 1 independent expert)
Approval Process: If PSC vote ties at 50-50 or dissent reaches >50%, escalate to Crisis Steering Group for 14-day mediation. If mediation fails, refer to independent arbitration with 6-month resolution timeline. Arbitration decision binding; if arbitration upholds PSC majority, dissenting funder may formally withdraw, triggering contingency-funding cascade (higher bank loan-to-grant ratio, outcome-linked bonds). If arbitration overturns PSC, gate reassessed within 60 days.
Rationale: Gates at Months 36, 84, 144, 216 (2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08) release USD 4.5B-19.5B tranches. Disagreement over KPI interpretation (e.g., whether cultivar yield of 88% is 'parity' or 'shortfall') or evidence quality (e.g., sufficiency of 45 vs. 50 documented suspect detections) can paralyze decision-making. A deadlocked gate delays all downstream activities by 3-12 months and signals funder disunity, reducing program credibility.
Negative Consequences: Tranche release delayed 3-6 months pending arbitration; breeding trials lose funding mid-cycle, delaying cultivar delivery by 1-2 years. Smallholder replanting delayed, adoption momentum lost. Alternative-rubber hub construction permits lapse. Funders lose confidence; at least one major contributor may withdraw, reducing available capital by USD 1-3B and triggering contingency cascade (higher-cost debt, outcome-linked bonds, climate-finance blends). Program resilience goal at risk.

**Pathogen Virulence Breakthrough: Discovered Biotype Defeats Candidate Cultivar Resistance**
Escalation Level: Technical Panel (immediate assessment) → Core Project Team (breeding strategy revision) → Program Steering Committee (gate-criteria adjustment or containment-contingency activation)
Approval Process: Technical Panel rapid assessment (within 2 weeks of virulence data): candidate either passes Virulence Gate (pass ≥80% resistance to ≥80% of isolates) or is held for additional pyramiding. If held candidate was nominated for commercial release, CPT breeding workstream revises pyramiding strategy and timeline (adds 2-3 years). If all leading candidates held, PSC may lower Year 7/12 cultivar-readiness gate bar or activate fast-track emergency deployment pathway (partially validated cultivars with liability protection). Decision published with Technical Panel rationale.
Rationale: Resistance durability is the core measure of breeding success. Discovery that a candidate cultivar lacks durable resistance to contemporary pathogen isolates (Virulence Gate failure) requires immediate breeding-strategy revision. Continuing to trial a susceptible candidate wastes 2-3 years and field-site resources. Escalation ensures Technical Panel assesses biotype data independently and PSC is prepared for revised timelines.
Negative Consequences: Unescalated virulence breakthrough discovers after cultivar commercial release (Year 8+) at farm scale: resistance failure within 5-10 years, cascading supply-chain collapse and smallholder losses of USD 2-5B. Delayed escalation (>6 months from detection to PSC action) extends unviable-candidate trials, consuming USD 50-150M in trial capex. Year 7/12 cultivar gates fail; breeding timeline slips 2-3 years, postponing true diversification to Year 14-15; alternative-rubber and smallholder timelines misaligned.

**OEM Offtake Collapse: Major OEM Buyer(s) Withdraw Commitment or Fail Tire-Grade Qualification**
Escalation Level: Core Project Team (Deputy Director, Alternative Rubber) → OEM Buyer Consortium → Program Steering Committee
Approval Process: CPT immediately notifies OEM consortium and PSC if committed volumes fall below 50% of planned Year-10 target. CPT and consortium work 60-day remediation (outreach to other OEMs, price negotiation, quality concessions). If commitment remains <80% of target by Month 60 (2031-10-08) checkpoint, PSC extraordinary meeting to authorize: (a) hub construction deferral to Months 108-120 (2036-10-08 to 2036-10-08), adding 1-2 years; (b) processing-plant capex freeze pending new commitments; (c) alternative-rubber budget reallocation to smallholder or breeding pillars. Decision published.
Rationale: Alternative-rubber hubs are bankable only with committed offtake contracts (take-or-pay). Offtake collapse leaves plants unable to service debt and operate at loss. A <80% offtake commitment by Month 60 (2031-10-08) makes hub financing impossible and plant construction approval unjustifiable. Escalation triggers reallocation and timeline adjustment rather than stranded capex.
Negative Consequences: Unescalated offtake withdrawal: hub construction proceeds on grant funding assumption, capex reaches USD 600-800M, plant commissioned at Month 120-132 (2036-10-08 to 2037-10-08) with no buyer, plant idles at 20-30% capacity, per-tonne cost rises 40-60% above gate target, year 7/12 alternative-rubber cost/quality gate fails, tranches withheld, alternative-rubber pillar permanently stalled. Supply-chain resilience goal unmet; smallholder replanting loses demand signal; Year 12 gate failure triggers 30-50% funder withdrawal.

**Suspected Ethical Violation or Misconduct: Corruption, Fraud, Benefit-Sharing Breach, or Misuse of Funds**
Escalation Level: Compliance and Ethics Committee (CEC) → Law Enforcement (if criminal) or PSC (if program-level governance failure)
Approval Process: Whistleblower hotline (externally managed) receives allegation; CEC initiates investigation within 2 weeks. If allegation involves criminal conduct (bribery, embezzlement, money laundering, fraud), CEC mandates reporting to relevant national law enforcement within 30 days, with exception only for ongoing law-enforcement investigation. If allegation involves program-level ethics breach (e.g., benefit-sharing agreement violated, inspector corruption, loan diversion), CEC investigation includes document review, interviews, field audit; findings issued within 60-90 days. CEC corrective-action order issued to CPT or PSC; if not complied with within 30 days, escalates to PSC for enforcement (suspension of activities, removal of individuals, fund recovery).
Rationale: A USD 30B program spanning 25 years, multiple sovereigns, phytosanitary enforcement in weak-capacity countries, and smallholder finance is vulnerable to corruption. Benefit-sharing agreements with indigenous communities, inspector integrity, loan-portfolio honesty, and hub capex procurement are high-risk areas. Rapid escalation and investigation deter misconduct and preserve funder confidence. Criminal allegations require law-enforcement reporting regardless of program impact.
Negative Consequences: Unescalated misconduct: corruption spreads (inspectors bribed, material smuggled, quarantine zones circumvented), containment protocol collapses, SALB incursion risk rises to USD 2-5B. Benefit-sharing violations trigger community legal action, blocking cultivar releases or germplasm access, delaying breeding by 2-4 years. Loan diversion undermines smallholder replanting, adoption collapses. Public exposure of unaddressed misconduct triggers funder withdrawal, media backlash, geopolitical friction, 50-80% capital loss.

# Monitoring Progress

### 1. Stage-Gate KPI Tracking and Evidence Compilation
**Monitoring Tools/Platforms:**

  - Gate Evidence Data Architecture and submission templates (technical, financial, adoption data by pillar)
  - Quarterly KPI dashboard (containment protocol adoption, inspector deployment, cultivar trial data, alternative-rubber cost/quality, smallholder uptake)
  - CPT workstream progress reports (monthly by pillar; Deputy Director submissions to secretariat)
  - Technical Panel Gate Assessment Documentation (Months 28–32 = 2029-02-08 to 2029-06-08, 76–80, 136–140, 208–212 for gates at Months 36, 84, 144, 216 = 2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08)

**Frequency:** Continuous collection; quarterly synthesis and dashboard publication; intensive monthly review 6–8 weeks before each gate decision (Months 28–32 = 2029-02-08 to 2029-06-08, 76–80, 136–140, 208–212 = 2029-02-08 to 2029-06-08, 2032-06-08 to 2032-10-08, 2037-10-08 to 2038-02-08, 2043-10-08 to 2044-02-08)

**Responsible Role:** Core Project Team (CPT: Executive Director and Deputy Directors for each pillar) with Technical Panel secretariat; reporting to Technical Panel and Program Steering Committee (PSC)

**Adaptation Process:** Month 30 (2029-04-08) checkpoint (Months 30, 78, 138, 210 = 2029-04-08, 2032-10-08, 2038-04-08, 2044-04-08) for each gate window: CPT identifies evidence gaps or unforeseen delays; Technical Panel flags interpretation disputes or data-quality concerns; PSC convenes extraordinary meeting to prepare for gate decision logic and pre-emptively discuss criteria adjustments (e.g., if cultivar candidates ready at 85% vs. 90%, whether partial tranche release is invoked). If major evidence shortfall detected (e.g., cultivar-readiness data unavailable 8 weeks before gate), Technical Panel recommends deferral (up to 6-month delay) rather than forcing premature decision.

**Adaptation Trigger:** KPI attainment projected to fall below 70% by Month 32, 80, 140, 212 (2029-08-08, 2033-08-08, 2038-08-08, 2044-08-08) (i.e., 4 weeks before each gate decision); evidence package incomplete or quality-flagged by Technical Panel; CPT reports >12-month delay to a major milestone; PSC members express >50% dissent on gate criteria interpretation (triggers Crisis Steering Group or arbitration pathway per escalation matrix)

### 2. Containment Protocol Readiness and Adoption Monitoring
**Monitoring Tools/Platforms:**

  - Containment Protocol Adoption Tracker (country-by-country status: technical working group engagement, legislative drafting, parliamentary debate, formal adoption into national law by producing-country agriculture ministries)
  - IPPC Standard-Setting Timeline and Proposal Status (formal proposal submission tracker; IPPC Standards Committee meeting minutes and votes)
  - Binding Regional Compact Log (ASEAN, ECOWAS, Mercosur compact negotiation status; reciprocal inspection-rights agreements; cross-border quarantine-zone maps)
  - Country Commitment Letter Registry (15-target countries' signed letters confirming political commitment to adopt protocol by specified timeline)
  - Inspector Training and Certification Database (inspector names, training completion, certification status, deployment checkpoint assignment, retention tracking)

**Frequency:** Weekly IPPC technical working group meetings (Months 0–18 = 2026-10-08 to 2028-04-08); monthly containment workstream updates to CPT (Months 0–36 = 2026-10-08 to 2029-10-08); quarterly progress reports to PSC (Months 3, 6, 9, 12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08 and beyond); country-by-country status updates at bi-annual producer-country coordination forum meetings

**Responsible Role:** Core Project Team (Deputy Director, Containment & Capacity Building) with IPPC Secretariat and producer-country representatives; Producer-Country Coordination Forum (PCCF) chair and members reviewing progress on their own legislative adoption; regional plant protection organization liaisons (ASEAN, ECOWAS, Mercosur)

**Adaptation Process:** If a major producing country's legislative process stalls (e.g., parliament delays debate, ministry seeks revisions to protocol scope), CPT and PCCF convene bilateral mediation (producer-country representative + CPT + IPPC adviser) within 30 days to identify bottleneck and propose remedial timeline. If a country appears unlikely to adopt by Month 36 (2029-10-08) gate, alternative pathway considered: (1) regional compact alone carries gate (if 12+ of 15 countries in Asia/Africa adopt and are operational); (2) protocol implementation delayed to Month 60 (2031-10-08) with adapted gate criteria (e.g., 'operational regional compacts and 100 documented interceptions' instead of 'protocol in all 15 countries'). If IPPC standard-setting slips past Month 24 (2028-10-08), activate provisional protocol (countries adopt interim protocol pending formal IPPC approval), allowing gate at Month 36 (2029-10-08) to score 'readiness with pending formalization' rather than 'full adoption.'

**Adaptation Trigger:** Legislative adoption by fewer than 12 of 15 target countries by Month 32 (2029-06-08) (i.e., 4 weeks before the Month 36 gate = 2029-10-08); formal IPPC proposal not submitted by Month 20 (2028-06-08) (delayed from Month 18 target = 2028-04-08 by >2 months); fewer than 3 of 5 major regions (Asia, Africa, Latin America, etc.) have signed binding compact agreements by Month 24 (2028-10-08); country commitment letters show >3 conditional or qualified endorsements (e.g., 'adopt if other countries adopt first' or 'adopt subject to funding') rather than firm commitments

### 3. Resistance Breeding Timeline and Virulence Gate Tracking
**Monitoring Tools/Platforms:**

  - Resistance Breeding Pipeline Tracker (candidate-cultivar names, elite clone backgrounds, resistance-gene pyramiding status, field-trial site and stage, trial start/end dates, yield-trial data collection milestones)
  - Pathogen Genomics and Virulence Database (annual SALB isolate sequencing results from trial sites and endemic regions; virulence-scoring sheets for each candidate against test isolates; Virulence Gate pass/hold recommendation history)
  - Multi-Site Trial Status Dashboard (trial-station location, site establishment date, inoculation and assessment protocols, disease-pressure measurements, yield data by candidate and site, environmental conditions log)
  - Germplasm Collection and Characterization Log (Brazil-led wild Hevea accessions; collection dates; Nagoya/ABS authorization status; genetic characterization; resistance-trait screening results; accession transfer to breeding partners)
  - Cultivar Readiness Evidence Compilation (Months 76–82 = 2033-02-08 to 2033-08-08 for Year 7 gate; Months 136–142 = 2038-02-08 to 2038-08-08 for Year 12 gate): multi-site yield summaries, resistance-durability forecasts, regulatory-approval status for commercial release

**Frequency:** Monthly cultivar-progress updates from breeding workstream lead to CPT (germplasm status, trial milestones); quarterly summaries to PSC; Virulence Gate assessments at Months 24, 36, 48, 60 (2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08) by Technical Panel; annual pathogen-genomics reports (Months 12, 24, 36, 48 = 2027-10-08, 2028-10-08, 2029-10-08, 2030-10-08, etc.) detailing isolate diversity and virulence trends

**Responsible Role:** Core Project Team (Deputy Director, Resistance Breeding & Trials) managing field sites, germplasm collection, and trial data; Brazil-led bio-prospecting team (CEPLAC, Embrapa) and pathogen genomics lab (Brazil and Asia satellite); Technical Panel providing independent Virulence Gate assessment and cultivar-readiness scoring

**Adaptation Process:** If a candidate fails a Virulence Gate (resistant to <80% of test isolates), that candidate is held for additional pyramiding; CPT breeding workstream revises strategy and timeline (+2–3 years to develop new pyramids or test additional sources). If all top 2–3 candidates are held by Month 48 (2030-10-08), CPT alerts PSC that Year 7 cultivar-readiness gate (Month 84 = 2033-10-08) is at risk; PSC may authorize: (a) lower gate bar (accept 85% resistance instead of 90%, or 80% yield instead of 85%); (b) activate fast-track emergency pathway (partially validated cultivars approved with liability protection if incursion occurs); (c) delay Year 7 gate to Month 96 (2034-10-08) with compensatory tranches. If germplasm collection slips (fewer than 200 accessions by Month 18 = 2028-04-08), breeding pipeline depth reduced; use contingency accessions from existing CIRAD/Embrapa repositories to avoid complete bottleneck, but may limit genetic diversity.

**Adaptation Trigger:** Virulence Gate score <80% pass rate for all candidates at Months 24, 36, 48 (2028-10-08, 2029-10-08, 2030-10-08); fewer than 200 characterized wild Hevea accessions delivered by Month 20 (2028-06-08) (2-month slip from Month 18 target = 2028-04-08); field-trial site commissioning delays exceeding 6 months (beyond Month 18 = 2028-04-08 baseline); multi-site trial yield data showing elite-clone parity <80% for all candidates by Month 72 (2032-10-08); Nagoya/ABS negotiations not completed by Month 8 (2027-06-08), indicating >2-month slip from Month 6 target (2027-04-08)

### 4. Alternative-Rubber Cost, Quality, and OEM Offtake Commitment Tracking
**Monitoring Tools/Platforms:**

  - Alternative-Rubber Cost Trajectory Dashboard (Guayule and Russian dandelion unit-cost tracking by region and pilot scale, Months 1–144 = 2026-11-08 to 2038-10-08: input costs, extraction/processing yield, per-tonne cost trending toward USD 1.62/kg gate)
  - Tire-Grade Qualification Test Results (OEM tire-testing outcomes, tire-performance benchmarks vs. Hevea specifications, quality-gap identification and remediation tracking)
  - OEM Buyer Consortium Offtake Commitment Tracker (signed letters of intent, take-or-pay contracts, committed volumes, price formulas, tiered purchasing schedules, qualification milestones by OEM)
  - Hub Construction and Financing Status (hub capex budget, permitting approvals, construction progress, debt-financing structure and lender commitment, commissioning timeline)
  - Agronomic Pilot Data Log (Guayule and Russian dandelion trial plots by region: yield per hectare, pest/disease incidence, water use, soil-health indicators, climate-impact observations, processing-trial outputs: extraction efficiency, resin recovery, tire-grade quality test results)

**Frequency:** Monthly agronomic pilot updates (Months 1–72 = 2026-11-08 to 2032-10-08); quarterly cost tracking and processing-trial summaries (Months 3, 6, 9, 12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08 and beyond through Month 144 = 2038-10-08); OEM offtake commitment status reviewed bi-monthly during consortium meetings (Months 0–84 = 2026-10-08 to 2033-10-08); quarterly tire-grade qualification test results to PSC (Months 12–30 = 2027-10-08 to 2029-04-08); hub construction progress tracked weekly during construction phase (Months 96–120 = 2034-10-08 to 2036-10-08)

**Responsible Role:** Core Project Team (Deputy Director, Alternative Rubber & Processing) managing agronomic and processing pilots, OEM engagement, and hub development; OEM Buyer Consortium members providing qualification-test data and commitment status; hub operators and construction contractors providing progress updates

**Adaptation Process:** If pilot-scale cost is tracking above USD 1.80/kg at Month 48 (2030-10-08) (i.e., 11% above the USD 1.62 gate), CPT escalates to PSC for cost-reduction strategy (e.g., scale up pilot plants faster to achieve economies of scale, negotiate co-product revenue to offset rubber cost, or adjust gate threshold to 25% premium = USD 1.69/kg). If OEM offtake commitments fall below 80% of planned volume by Month 60 (2031-10-08), hub construction is deferred from Month 96 (2034-10-08) to Month 108–120 (2036-10-08 to 2036-10-08). If tire-grade tests reveal >5% gap to Hevea specifications (e.g., tire durability test fails at 95,000 km vs. Hevea 100,000 km), processing remediation R&D is triggered (estimated 12–24 month additional work and USD 50–100M capex); Year 7 gate timeline may slip to Month 100 (2035-02-08) pending improved tire-quality data.

**Adaptation Trigger:** Guayule or Russian dandelion unit cost projected above USD 1.80/kg by Month 60 (2031-10-08) (4–8 months before Year 7 gate evidence compilation); <80% of planned Year-10 production volume under written priced offtake by Month 72 (2032-10-08); OEM qualification test results show >5% gap to Hevea tire-grade specs; hub construction permits not secured by Month 90 (2034-04-08) (baseline approval at Month 96 = 2034-10-08); hub capex forecast exceeds budget by >15% (e.g., USD 345M vs. USD 300M per hub baseline)

### 5. Smallholder Adoption, Replanting Finance, and Surveillance Participation Monitoring
**Monitoring Tools/Platforms:**

  - Smallholder Replanting Finance Portfolio (loan disbursement tracking: count of loans issued, amounts, disbursement dates, borrower demographics; repayment tracking: on-time, late, default rates; income-bridge payments; clean-plant stock purchasing by borrower)
  - Clean-Plant Nursery Network Operations Dashboard (nursery locations and ownership, production capacity, certified-planting-stock output, distribution to smallholders, pathogen-free test pass rates)
  - Surveillance Participation and Reporting Database (farmer participation registry: names, plot locations, enrollment in surveillance-premium scheme; monthly/quarterly SALB suspect reports submitted; laboratory confirmations; payment records and timeliness)
  - Adoption Uptake Tracker (region-by-region breakdown: eligible smallholder population, number who adopted resistant cultivars or alternatives, adoption rate %, satisfaction surveys, reasons for non-adoption from declined farmers)
  - Pilot-Zone Performance Reports (Months 6–24 = 2027-04-08 to 2028-10-08 and ongoing): Sumatra, Côte d'Ivoire, northeast India, Rondônia (and optional 5th zone); adoption rate, loan performance, surveillance participation, replication readiness for scale-up

**Frequency:** Pilot-zone monitoring during Months 6–24 (2027-04-08 to 2028-10-08): monthly farmer surveys and lending-data collection; quarterly reports to PSC and smallholder workstream lead. Post-pilot scale-up (Months 24–144 = 2028-10-08 to 2038-10-08): quarterly adoption summaries by region to CPT; semi-annual updates to PSC; annual comprehensive smallholder-performance reports (Months 12, 24, 36 = 2027-10-08, 2028-10-08, 2029-10-08 of each calendar year)

**Responsible Role:** Core Project Team (Deputy Director, Smallholder Finance & Surveillance) managing pilot design and scale-up; rural-bank partners disbursing replant loans and tracking repayment; farmer-organization representatives monitoring adoption and surveillance participation; clean-plant nursery operators providing stock production and distribution data

**Adaptation Process:** If pilot-zone adoption rate is <40% by Month 18 (2028-04-08) (i.e., does not meet 60% target set for Month 24 = 2028-10-08), CPT convenes farmer-organization focus groups and rural-bank staff to diagnose barriers (e.g., credit reluctance, land-title uncertainty, labor constraints, low farmer confidence in cultivar yield). Adaptation options: (1) increase income-bridge subsidy (e.g., 50% of income gap vs. current 30%) to lower household risk; (2) simplify loan application and shortening approval timelines from 6 weeks to 2 weeks; (3) bundle replant loans with price-stability insurance (lower perceived downside); (4) shift from individual loans to group lending via farmer cooperatives (reduce transaction costs). Surveillance-participation barriers (e.g., fear of quarantine penalties, distrust of inspectors, payment delays) addressed by: (1) rural-transparency campaign explaining that surveillance reporting is rewarded, not punished; (2) payment confirmation within 30 days (vs. 60 days initially); (3) inspector rotation (visible to farmers) if corruption suspected. If adoption remains <50% by Month 36 (2029-10-08), PSC may lower Year 12 adoption gate target from 1.5M to 1.0M, reflecting population-level constraints rather than program failure.

**Adaptation Trigger:** Pilot-zone adoption <40% by Month 18 (2028-04-08) (does not meet 60% target by Month 24 = 2028-10-08); smallholder loan default rate >10% by Month 24 (2028-10-08) (indicates unsustainable terms or economic shock); surveillance-participation rate <30% in pilot zones (indicates incentive or trust misalignment); clean-plant nursery production <10,000 plantlets/month per zone by Month 24 (2028-10-08) (insufficient supply for adoption demand); annual smallholder-satisfaction survey scores <6 out of 10 on replanting intent or trust in clean-plant material

### 6. Funding Deployment, Reserve Drawdown, and Financial Risk Monitoring
**Monitoring Tools/Platforms:**

  - Financial Ledger and Pillar Allocation Tracker (committed and disbursed capital by pillar: containment 25%, breeding 35%, alternatives 25%, smallholder 15%; tracking against planned spending schedule by phase)
  - Contingency Pool and Reserve Account Monitoring (contingency pool USD 4.5B balance; outbreak-response reserve USD 0.5–1.0B funding status and authorization; political-risk reserve USD 0.9B allocation)
  - Industry Levy Revenue Tracking (ASEAN pilot levy collection by Month 18 = 2028-04-08; global rollout ramp-up Month 36–48 = 2029-10-08 to 2030-10-08; monthly actual vs. forecast levy revenue; collection-rate and evasion tracking)
  - Funder Commitment Ledger (sovereign governments and development-bank binding commitments: amount, tranche schedule, payment status; any funder withdrawals or reductions; political-risk flags from funder countries)
  - Annual Stakeholder Financial Report (budget execution by phase; reserve drawdowns and rationale; funder performance; any funding gaps and contingency-cascade activation)

**Frequency:** Weekly CPT Chief Financial Officer monitoring (cash-flow status, disbursements, pillar spending pace); monthly ledger reconciliation and funder-payment tracking; quarterly funder-alignment reports to PSC (Months 3, 6, 9, 12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08 and beyond); levy revenue tracked monthly from Month 12 (2027-10-08) (pilot phase) and Month 36 (2029-10-08) onwards (global phase); annual comprehensive financial report by Month 12 (2027-10-08) of each calendar year

**Responsible Role:** Core Project Team (Chief Financial Officer and CFO staff) managing accounts and financial reporting; multinational development banks and sovereign-government treasury representatives monitoring their own commitments; levy-trust independent governance confirming revenue collection and allocation

**Adaptation Process:** If cumulative funding deployed falls >10% below the planned spending schedule by a given month (e.g., USD 180M behind forecast by Month 12 = 2027-10-08), CPT Financial Officer alerts PSC of potential funding-constraint and recommends: (1) acceleration of ready-to-spend activities (e.g., hiring, equipment procurement) to match planned ramp; (2) deferral of discretionary spending (e.g., consultant studies) if funding genuinely unavailable; (3) request for early tranche release from funders if commitments are firm but cash transfers delayed. If industry levy pilot in ASEAN collects <USD 30M annually by Month 18 (2028-04-08) (i.e., falls 25% short of USD 40M forecast), PSC convenes funder discussion (Month 18–24 = 2028-04-08 to 2028-10-08) to: (1) audit levy-collection mechanisms (ports, manufacturers, traders); (2) negotiate compliance improvements (enforcement, audits); (3) if collection remains <60% compliance, activate contingency cascade by Month 36 (2029-10-08): higher development-bank loan-to-grant ratio (shift USD 1B from grants to concessional loans, increasing debt service burden but preserving capital), outcome-linked bonds (USD 0.5B raised from investors, repaid only if cultivar and alternative-rubber milestones met by Years 7–12), or climate-finance-blend mechanism (attempt to redirect climate-adaptation funding from climate-focused funds toward rubber-supply resilience as climate-risk mitigation). If a major funder (e.g., country representing >15% of commitments) announces withdrawal or 20%+ budget cut, PSC immediately convenes Crisis Steering Group to: (1) assess funding gap impact; (2) negotiate accelerated contributions from remaining funders or emergency bridge financing; (3) identify non-critical spending that can be deferred; (4) if gap remains >USD 300M annually, recommend pillar reallocation (e.g., defer alternative-rubber hub construction, focus on containment and breeding with proven cost-effectiveness).

**Adaptation Trigger:** Cumulative funding deployed <90% of planned spending schedule by Months 12, 24, 36 (2027-10-08, 2028-10-08, 2029-10-08); industry levy pilot collection below USD 30M annually by Month 18 (2028-04-08) (i.e., <75% of USD 40M forecast); levy global rollout compliance <60% by Month 48 (2030-10-08), triggering contingency cascade activation; any funder announcing >USD 500M reduction or withdrawal; reserve drawdown >USD 1.0B (contingency pool <USD 3.5B remaining) prior to Month 84 (2033-10-08)

### 7. Risk Register and Critical Issue Escalation Monitoring
**Monitoring Tools/Platforms:**

  - Program Risk Register (16 identified major risks: regulatory/permitting delays, technical delays in breeding/alternatives, virulence breakthrough, smallholder adoption shortfalls, OEM offtake collapse, funding gaps, governance capture, environmental/climate shocks, social/political turnover, institutional capacity bottlenecks, SALB incursion surprise, pathway asynchronicity, regulatory compliance for alternative crops, producer-country capacity, and benefit-sharing disputes)
  - Quarterly Risk Escalation Report (updated risk scores: likelihood and impact severity for each risk; new risks identified; mitigation effectiveness assessment; any risks elevated from Medium to High)
  - Critical Issue Tracking Dashboard (issues requiring PSC or Crisis Steering Group attention: governance deadlocks, major milestone delays, funder concerns, technical setbacks, field incidents)

**Frequency:** Monthly risk review by CPT Chief Risk & Compliance Officer and workstream leads (first Monday of each month); quarterly escalation reports to PSC (Months 3, 6, 9, 12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08 and beyond); ad-hoc escalation to PSC within 5 business days if any risk or issue triggers escalation criteria

**Responsible Role:** Core Project Team (Chief Risk & Compliance Officer) maintaining risk register and conducting quarterly assessment; workstream Deputy Directors reporting risk indicators and mitigation-action status; PSC and Technical Panel reviewing escalations and authorizing risk-response decisions

**Adaptation Process:** If a risk escalates from Medium to High likelihood or impact (e.g., 'regulatory & permitting delay' shifts from 'Low probability, High impact' to 'High probability' as protocol adoption stalls), CPT immediately alerts PSC and proposes mitigation reallocation (e.g., additional diplomatic engagement, interim-protocol activation, gate-criteria flexibility). If a mitigation action is identified as ineffective (e.g., 'capacity-building twinning' shows <50% inspector-retention after 12 months), CPT pivots strategy and escalates to PSC for approval (e.g., shift to permanent inspector hiring with salary increases and career-path support, costing USD 50M additional vs. original twinning model). If a critical issue emerges (e.g., SALB incursion suspected in a 'free' region), activation protocols are triggered: (1) Compliance & Ethics Committee investigates and confirms; (2) outbreak-response reserve (USD 0.5–1.0B) is immediately authorized for deployment without PSC gate delay; (3) emergency cultivar-release pathway is activated; (4) PSC convenes within 48 hours to assess program continuity and communication.

**Adaptation Trigger:** Risk likelihood or impact score increases by ≥2 levels on a 5-point scale (e.g., from 'Medium' to 'High') during quarterly review; new risk identified by workstream leads or Technical Panel with inherent severity >3 out of 5; any mitigation action rated as <60% effective at quarterly review; critical issue (e.g., governance deadlock, major funder withdrawal threat, SALB incursion suspected, major corruption allegation) arises; PSC member, funder, or producer-government representative raises formal concern about risk trajectory or program viability

# Governance Extra

## Governance Validation Checks

1. Completeness Confirmation: All core governance components from Stages 2–5 are present. Stage 2 (internal_governance_bodies) defines PSC, CPT, Technical Panel, CEC, and PCCF with clear roles and decision rights. Stage 3 (implementation_plan) provides 33 detailed steps from Month 0 (2026-10-08) through handover. Stage 4 (decision_escalation_matrix) specifies five major escalation pathways. Stage 5 (monitoring_progress) covers six monitoring approaches. No major governance workstream is missing; however, several details require clarification (see Point 3 below).
2. Internal Consistency Check: Logical alignment across stages is strong. PSC composition (6–8 producer governments, 3–4 OEMs, 3–4 development banks, 3–4 independents) is consistent across governance bodies and implementation steps. Technical Gate Charter (Stage 3, Month 3 = 2027-01-08) is referenced in Stage 2 decision rights and Stage 4 escalation logic. Monitoring pillars (Stage 5) align with CPT workstream structure (Stage 2). Technical Panel independence is enforced across decision rights, conflict-of-interest certification, and escalation procedures. One minor inconsistency: Stage 3 describes PSC vote thresholds as 'supermajority ≥75%' but Stage 2 PSC decision rights state 'supermajority or consensus'—clarify whether consensus is required for all decisions or only >10% reallocations.
3. Clarity of Roles and Authority: Producer-country representation is strong (6–8 seats, rotating chair, PCCF advisory body), but ultimate Project Sponsor's authority at Month 0 (2026-10-08) is underspecified. Stage 3 Step 1 designates 'Project Sponsor' to authorize governance but does not name the entity (national government, development bank, OEM consortium?). Recommend explicit naming at Month 0 (2026-10-08) (e.g., 'Brazil + World Bank co-sponsor'). OEM representatives hold 3–4 PSC seats, but their authority to commit offtake (vs. advisory only) is implicit; clarify whether offtake commitments require OEM board sign-off or are binding at the PSC representative level. CPT Executive Director has clear autonomous authority for <USD 50M/decision, but appeals of CPT decisions to PSC are mentioned in escalation but not formalized in Stage 2 CPT decision rights.
4. Process Depth—Conflict of Interest and Whistleblower: CEC (Stage 2) administers conflict-of-interest certifications and a whistleblower hotline, with mandatory law-enforcement reporting for criminal allegations. However, detailed investigation procedures (investigation timelines, evidence standards, internal vs. external investigation) are mentioned at high level only. Recommend appending a brief 'Investigation Procedures Annex' specifying: (a) initial intake and triage (days 1–5), (b) preliminary assessment (days 6–14), (c) investigation (up to 60 days), (d) finding and corrective action (days 61–90), (e) law-enforcement escalation thresholds (fraud >USD 1M, bribery >USD 100K, etc.).
5. Thresholds and Delegation: Stage 3 specifies CPT autonomous authority for spending <USD 50M and milestones <12 months. However, no granular sub-delegation is defined for individual Deputy Directors (e.g., can Deputy Director, Containment spend up to USD 25M on inspector training without CFO approval?). Recommend a 'CPT Spending Authority Matrix' appended to Stage 3, specifying: (a) Deputy Director autonomy ceilings (e.g., USD 5–10M per pillar per quarter), (b) CFO joint-approval thresholds (USD 10–25M), (c) Executive Director escalation (>USD 25M). Stage 3 gate-evidence submission deadlines are clear (Months 32–34 = 2029-06-08 to 2029-08-08, 80–82, 140–142, 212–214 = 2029-08-08 to 2029-10-08, 2033-08-08 to 2033-10-08, 2038-08-08 to 2038-10-08, 2044-08-08 to 2044-10-08), but contingency rules for late submissions are not stated; clarify: gate deferred if evidence not 60% complete by Month 32 (2029-06-08)? Or acceptance of 'best available evidence'?
6. Integration and Information Flow: Stage 5 monitoring (gate evidence compilation, risk escalation, funder alignment) is well-integrated into Stage 4 escalation procedures. However, integration between CEC (ethics/compliance) and risk monitoring (Stage 5) is implicit. Recommend explicit monthly CEC-Risk Officer coordination meeting (cross-report: integrity hotline summary to risk register; emerging risks flagged to CEC for investigation readiness). Stage 3 implementation steps include quarterly PSC meetings (Months 3, 6, 9, 12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08 and beyond), but Stage 2 PSC meeting cadence is 'quarterly minimum'—confirm locked cadence (first Thursday of Months 2, 5, 8, 11 = 2026-12-08, 2027-03-08, 2027-06-08, 2027-09-08 of each calendar year?) to ensure stakeholder availability and reporting timeliness.

## Tough Questions

1. By Month 6 (2027-04-08), name the five major sovereign-government funders and two development banks committed to the program, with binding funding letters specifying amounts and tranches. If fewer than five sovereigns or one MLDB cannot commit by Month 6 (2027-04-08), what is the fallback funding strategy, and how much contingency-pool capital will be consumed by Month 3 (2027-01-08) to cover the shortfall?
2. What specific evidence—beyond 'at least 2 laboratory-cleared suspect detections' by Month 36 (2029-10-08)—will demonstrate that the SALB Containment Protocol is functionally preventing undetected incursions in Asia and Africa? If zero suspect detections are logged by Month 60 (2031-10-08), does the protocol pass the Year 3 gate retroactively, or must the Containment Efficacy Review (Months 72–84 = 2032-10-08 to 2033-10-08) conclude that surveillance sensitivity was too low and escalate detection protocols before the Year 7 gate (Month 84 = 2033-10-08)?
3. By what date and through what mechanism will at least two major OEM tire manufacturers (naming them) formally commit in writing to purchase 500+ tonnes per annum each of Guayule or Russian dandelion at specified price and quality, making the alternative-rubber hub construction financeable? If signed offtake commitments cover fewer than 80% of the planned 200,000 t/yr by Month 72 (2032-10-08), will PSC formally defer hub construction to Months 96–120 (2034-10-08 to 2036-10-08), and if so, what communication is made to smallholders and infrastructure-site communities?
4. Show the probability-weighted forecast for the cultivar-readiness gate at Month 84 (2033-10-08): what is the likelihood that at least two candidates will pass the Virulence Gate (≥80% resistance to ≥80% of isolates) and achieve ≥85% of elite-clone yield over multi-site trials by that date? If the forecast probability is <60%, what contingency plan is activated (e.g., lower gate bar to 75% yield parity, extend trials to Month 96 = 2034-10-08, emergency deployment pathway), and who authorizes it?
5. Document the current status of Nagoya Protocol benefit-sharing framework agreements with Brazilian states and indigenous communities as of Month 1 (2026-11-08). If framework agreements are not finalized by Month 6 (2027-04-08), what interim access-and-benefit-sharing arrangement allows germplasm collection to proceed without legal liability or community disputes? If a community formally contests a cultivar release (claiming inadequate benefit-sharing), what dispute-resolution mechanism and timeline (e.g., arbitration, 6-month cap) prevents breeding delays >18 months?
6. What is the operational definition of '50% of eligible smallholders adopting resistant cultivars or alternatives by Month 144 (2038-10-08)' in terms of verifiable hectares planted or clean-plant-stock disbursements? If adoption in pilot zones (Months 6–24 = 2027-04-08 to 2028-10-08) reaches only 30–40%, by what Month 36 (2029-10-08) decision point does PSC adjust Year 12 adoption targets downward, and how is this communicated to replanting-finance lenders and clean-plant nursery operators without undermining confidence?

## Summary

This governance framework establishes a multilateral independent secretariat (PSC with rotating producer-government chair, OEM and development-bank representation, and independent Technical Panel) to oversee a 25-year, USD 30 billion stage-gated program across three interdependent pillars: SALB containment via harmonized IPPC protocol, SALB-resistant Hevea breeding via pyramided resistance, and alternative-rubber scale-up (Guayule and Russian dandelion). Funding is anchored in binding 10-year sovereign and development-bank commitments (USD 21B, 70% of cap) plus a per-tonne industry levy (USD 6B). The framework prioritizes early decision-making (Technical Gate Charter by Month 3 = 2027-01-08) and transparent gate evidence (published 60 days before each decision) with partial-tranche release on partial KPI attainment, accommodating biological and institutional unpredictability. Strengths: clear escalation procedures for deadlocks and crises; ring-fenced contingency reserves (USD 4.5B, 15%) for delays and outbreak response; producer-country coordination forum ensures sovereignty and capacity handover by Year 18; independent compliance and ethics oversight deters corruption. Risks requiring front-loading: containment-protocol Year 3 gate conflates 'readiness' with 'proof of efficacy' (incursion may occur Month 60–96 = 2031-10-08 to 2034-10-08 despite gate passage); resistance breeding and alternative-rubber timelines slip predictably, requiring buffer gates and contingency deployment pathways; smallholder adoption depends on fragile incentive alignment (surveillance premium linkage not yet designed); industry levy requires coordination and enforcement risk across competing traders. Core adaptability lever: partial-achievement tranching (70–85% attainment = 70–85% tranche release) preserves funding momentum while maintaining discipline; Virulence Gates and Containment Efficacy Review (embedded at Months 24, 36, 48, 60 = 2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08 and Months 72–84 = 2032-10-08 to 2033-10-08) ensure pathway durability rather than premature cultivar release into supply-chain failure.