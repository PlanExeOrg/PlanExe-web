# Governance Audit


## Audit - Corruption Risks

- Bribery of inspectors or plant-protection officials to certify contaminated nursery stock or forged clean-plant documentation, undermining the SALB Containment Protocol and enabling undetected disease spread.
- Nepotism in extension-corps recruitment and certification of smallholder nurseries, favoring connected farmers while excluding eligible smallholders from replant finance, creating geographic adoption gaps and protocol enforcement failures.
- Conflict of interest in breeding-cultivar selection and trial data reporting, where programme staff or partner breeders have financial stakes in specific resistance sources or proprietary clones, biasing Year 7 gate evidence and delaying open-access cultivar release.
- Kickbacks from alternative-crop processing contractors to programme managers in exchange for favorable cost-KPI interpretations or contract award, inflating offtake valuations and stranding capital in uncompetitive plants.
- Trading favors between OEM tire makers and procurement officials to steer alternative-rubber contracts to preferred suppliers or to suppress quality-variance evidence in favor of early offtake agreements.
- Misuse of benefit-sharing royalty payments intended for Amazonian communities, diverted to programme administration or partner institutions instead of indigenous groupings, violating ABS agreements and creating legal liability.

## Audit - Misallocation Risks

- Double-spending on smallholder replant finance: funds released to eligible farmers for replanting, then unreported replanting failure and repayment defaults create a secondary call on the same capital tranche, depleting resources for other phases.
- Budget misuse for extension-corps salaries and operating costs: planned USD 400M protected stream is consumed by central programme administration, ICT systems and audit overhead instead of reaching field-level delivery to 500+ extension agents and 50–100 nurseries.
- Inefficient allocation of alternative-crop pilot funding: pilot processing plants (Guayule 2,000 t/yr, dandelion 1,000 t/yr) are oversized or poorly sited, generating operating losses and stranded cost without advancing commercial-plant decision-making by Month 60 (2031-10-12) gate.
- Unauthorized use of gate-conditional tranches: early releases or partial disbursements prior to independent audit sign-off, reducing tranche leverage for gate discipline and obscuring whether actual KPI thresholds were met.
- Poor record-keeping of cultivar trial data and yield measurements across four breeding sites (Brazil, Thailand, Malaysia/Indonesia, Côte d'Ivoire), enabling inconsistent data compilation for Year 7 gate audits and masking actual yield penalties versus elite clones.
- Misreporting progress on protocol adoption in producer nations: bilateral MoU completion claimed by Month 6 (2027-04-12) but not independently verified, so IPPC drafting and vote timelines are built on false readiness, causing Month 36 (2029-10-12) gate delay.

## Audit - Procedures

- Independent Gate Evidence Verification: Contract a qualified international auditor by Month 3 (2027-01-12) to verify all four gate KPIs (containment, cultivar, cost, smallholder uptake) using pre-registered scope. Audits weigh field visits (30–40%), database audit (40–50%), and farmer/estate interviews (20–30%); verdicts published within 30 days; budget USD 30–50M over 25 years (proposed).
- Quarterly Protocol-Compliance Audits: Inspect at least 5% of certified nurseries per country (500+ annually targeted across top-5 producers) to verify clean-plant claims, traceability of stock and absence of contaminated movement. Issue compliance certificates; suspend certification for failures. Frequency: quarterly in primary producers, bi-annual in secondary regions. Report findings to national plant-protection agencies and programme steering council.
- Annual Breeding-Trial Data Validation: Independent botanists and pathologists verify cultivar yield, disease ratings and resistance-source documentation at each of the 4 breeding sites. Validate field measurements against laboratory records; cross-check data against raw trial databases to detect missing or altered records. Report by Month 12 (2027-10-12) of each calendar year.
- Semi-Annual Financial-Tranche Reconciliation: Audit all gate-conditional disbursements within 45 days of gate passage to verify: funds released only after auditor sign-off on KPI thresholds, tranches not pre-released, and minimum 80% release rule enforced. Trace capital flows to intended line items (smallholder finance, processing plants, extension). Flag deviations for steering-council review.
- Annual Smallholder-Uptake and Adoption Audits: Survey at least 2,000 smallholders per major country (10,000+ globally) to verify: adoption of resistant clones or alternatives, receipt of replant finance and income-bridging payments, and participation in extension networks. Cross-check survey data against programme registration databases. Report Month 84 (2033-10-12) and Month 144 (2038-10-12) waypoints against 30% and 40% targets.
- Post-Harvest Processing Quality and Cost Verification: Quarterly audits of pilot and commercial processing plants (8 plants total by Month 192 = 2042-10-12) to verify: feedstock costs within KPI thresholds (USD 1.20/kg Guayule, USD 1.00/kg dandelion by Month 48 = 2030-10-12), extraction yields (85% Guayule, 80% dandelion), product quality variance (within ±10%), and delivered cost trending toward 30%-above-Hevea ceiling by Month 144 (2038-10-12).

## Audit - Transparency Measures

- Published Independent Audit Verdicts: All gate-verification reports issued by the independent auditor are published within 30 days of gate closure, with auditor name, scope, methodology and dissenting findings disclosed. Steering Council publishes a 10-page gate summary within 15 days, including KPI achievement, any partial-success rationale for 80%+ tranche release, and actions triggered by unmet KPIs. Archive all verdicts on a public website accessible to funders, producing nations and the research community.
- Protocol-Adoption and Compliance Dashboard: Real-time public dashboard showing status of producer-nation MoU signatures, IPPC working-group progress, national regulatory embedding (target Months 36–48 = 2029-10-12 to 2030-10-12), and nursery-inspection coverage (target 100,000 lots/year). Update monthly; flag delays beyond 30-day thresholds to trigger steering-council review.
- Quarterly Steering-Council Meeting Minutes and Gate-KPI Reporting: Programme Steering Council (sovereign, OEM, research, farmer representatives) meets quarterly from Month 0 (2026-10-12). Meeting minutes, including gate-discipline discussion, funding-release decisions and risk-trigger thresholds, are published within 10 days. Annual consolidated gate-status reports summarize progress toward Year 3, 7, 12 and 18 targets, with auditor commentary on confidence levels and early-warning flags.
- Open-Access Breeding Trial Data Repository: All cultivar yield, disease-rating and multi-site trial records for the four breeding sites (Brazil, Thailand, Malaysia/Indonesia, Côte d'Ivoire) are released into an open data commons 12 months after data collection (or 6 months post-gate if gate-sensitive). Genomic sequences and resistance-discovery metadata are released immediately post-discovery. Data governance rules and benefit-sharing payment ledgers are published annually by Month 6 (2027-04-12).
- Published Access-and-Benefit-Sharing Agreements and Royalty Ledger: All bilateral ABS agreements with Brazil CGen and Amazonian community groupings are published (redacted only for personal identifiers). Annual community-benefit payments (per-hectare royalties, royalty-free smallholder seed, data-trust disbursements) are published with amounts and recipient attribution by Month 12 (2027-10-12) each year, audited by an independent ABS compliance monitor.
- Smallholder Adoption and Finance Audit Summary: Annual summary of replant-finance deployment (total loans disbursed, default rates, farmer satisfaction), extension-corps size and turnover (target 500 agents, turnover <20% annually), and uptake waypoint progress (30% enrollment at Month 84 = 2033-10-12, 40% replanted area by Month 144 = 2038-10-12) is published by Month 6 (2027-04-12). Include disaggregation by country and smallholder-income quartile to show equity of reach. Publish lists of certified nurseries, extension agents and cooperative partners.

# Internal Governance Bodies

### 1. Programme Steering Council

**Rationale for Inclusion:** This is a large, long-horizon, public-private program with diverse funders (sovereigns, multilateral development banks, industry), multiple geographies (Brazil, USA/Mexico, Europe, Southeast Asia, West Africa), and high political and institutional risk. A strategic steering body is essential to maintain alignment across sovereign and private sponsors, oversee stage-gate discipline, resolve strategic conflicts (legitimacy vs. enforceability of the containment protocol, speed vs. durability in breeding, focus vs. hedging in alternative crops), and ensure sustained political commitment over 25 years. The Council provides governance visibility to maintain stakeholder confidence and operational continuity through leadership transitions.

**Responsibilities:**

- Approve programme strategy, 5-year rolling plans, and annual implementation budgets within the USD 30 billion cap
- Oversee stage-gate discipline: review independent auditor verdicts, authorize tranche releases (minimum 80% rule), and enforce KPI thresholds at Months 36/84/144/216 (2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12)
- Resolve strategic conflicts and escalated decisions exceeding programme-director authority (containment protocol authority model, alternative-crop portfolio breadth, capital-stack allocation)
- Monitor political and funding risks; maintain binding 25-year framework agreements with sovereigns and development banks; ensure industry levy commitments hold
- Oversee programme sustainability and institutional continuity; approve leadership succession plans and knowledge-management protocols
- Review quarterly risk reports and approve mitigation actions for risks exceeding defined thresholds; authorize contingency-reserve deployment

**Initial Setup Actions:**

- Convene inaugural Council meeting by Month 1 (2026-11-12); confirm rotating representation from at least 5 sovereign funders, top 2-3 OEMs, 2-3 research institutions, and 1-2 smallholder/farmer representatives
- Publish Terms of Reference (governance scope, decision thresholds, escalation rules, transparency standards) by Month 3 (2027-01-12)
- Establish quarterly meeting schedule and approve Council chair (rotate every 2 years among sovereigns) by Month 1 (2026-11-12)
- Sign binding 25-year framework agreements with all sovereigns and development banks by Month 12 (2027-10-12), with explicit gate-release triggers and minimum-funding floors
- Approve programme-director role, executive team structure, and delegation matrix; recruit Programme Director by Month 3 (2027-01-12)
- Commission independent auditor and finalize audit scope and pre-registered KPI definitions by Month 6 (2027-04-12)

**Membership:**

- Senior representative from each of at least 5 sovereign/multilateral funders (rotating chair)
- Chief executive officer or deputy from at least 2-3 major OEM tire makers
- Lead scientist or director from at least 2-3 major research institutions (breeding, processing, phytosanitary expertise)
- Representative from smallholder organizations or farmer cooperatives (1-2 seats)
- Programme Director (ex officio, non-voting on own performance)

**Decision Rights:** Approve all decisions above USD 50 million (estimate), all strategic direction changes, all gate passage determinations, binding framework agreements, and contingency-reserve deployment. Approve annual budgets and 5-year plans. Can delegate operational decisions below USD 50 million to Programme Director and internal bodies. Cannot override independent auditor verdicts on KPI thresholds without binding adjudication (60-day review); can choose to withhold or release tranches based on auditor findings.

**Decision Mechanism:** Consensus-seeking with supermajority (≥66%) tie-breaker. On gate decisions, independent auditor verdict is binding unless the Council unanimously disputes the auditor's methodology (requires written rationale to auditor and funders within 15 days); if auditor stands by the verdict, tranches are released as recommended. On capital allocation and strategic direction, ≥66% supermajority carries the vote. Chair has no additional casting vote.

**Meeting Cadence:** Quarterly (every 3 months); accelerated to monthly Months 3-6 (2027-01-12 to 2027-04-12) during early governance setup. Special meetings called within 10 days if a gate closure or risk threshold is triggered. Annual in-person meeting in Month 12 (2027-10-12) to review framework agreements and approve rolling 5-year plan refresh.

**Typical Agenda Items:**

- Gate-closure reports and independent auditor verdicts (Month 36/84/144/216 = 2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12 gates)
- Risk register review and mitigation-action updates (quarterly summary, escalations)
- Funding and tranche-release decisions (quarterly dashboard of disbursements and outstanding tranches)
- Strategic conflicts or escalations from operational bodies (Containment Authority model disputes, breeding pathway acceleration, alternative-crop siting)
- Programme-director performance review and leadership succession planning (annual)
- Political or funder-commitment updates; framework-agreement compliance (quarterly summary)

**Escalation Path:** Disputes on independent auditor verdicts are escalated to a neutral third-party Adjudication Panel (independent of Council and auditor), which issues binding judgment within 60 days. Unresolved conflicts between sovereigns and OEMs over capital allocation or strategic direction are escalated to the programme chair and, if still unresolved, referred to the Steering Council for a formal vote (≥66% supermajority rule applies). Institutional-integrity or corruption allegations are escalated to the programme Anti-Corruption Officer and an independent investigator, with Council notification within 15 days.
### 2. Programme Management Office (PMO)

**Rationale for Inclusion:** This is a multi-workstream, multi-geography execution programme with four major pillars (containment protocol, breeding, alternative crops, smallholder adoption) running in parallel, each with distinct technical requirements, timelines and dependencies. A dedicated PMO is essential to manage day-to-day operational execution, coordinate across workstreams, track KPIs and milestones, manage operational-level risk and cost, and ensure that the programme stays on track toward stage gates. The PMO translates strategic decisions from the Steering Council into annual plans and quarterly delivery cycles.

**Responsibilities:**

- Develop and manage detailed workstream delivery plans for each of the five phases (Months 0-36 = 2026-10-12 to 2029-10-12, 36-84, 84-144, 144-216, 216-300); align plans with gate KPIs and stage-gate schedule
- Manage programme budget execution: track spending against USD 30 billion cap and approved allocations; manage tranche disbursements and contingency-reserve deployment within Council authorization
- Coordinate across workstreams (protocol adoption, breeding trials, alternative-crop pilots, extension, smallholder finance); manage inter-workstream dependencies and resolve conflicts below the Steering Council threshold
- Monitor operational KPIs and milestones quarterly; compile gate-readiness reports for independent auditor 6 months before each gate (Month 30, 78, 138, 210 = 2029-04-12, 2033-04-12, 2038-04-12, 2044-04-12)
- Manage operational risk: track risks identified by each workstream; assess likelihood and impact; escalate risks exceeding defined thresholds to the Steering Council
- Manage programme communications, knowledge management, and documentation; publish quarterly progress reports and annual programme reviews to stakeholders

**Initial Setup Actions:**

- Establish PMO office location and staffing by Month 1 (2026-11-12); recruit Programme Director, Deputy Director, Finance Manager, Workstream Coordinators (Containment, Breeding, Alternative Crops, Smallholder Delivery) by Month 3 (2027-01-12)
- Develop detailed Phase 1 (Months 0-36 = 2026-10-12 to 2029-10-12) delivery plan by Month 6 (2027-04-12), including protocol-drafting timeline, producer-nation MoU negotiation, auditor contracting, and surveillance setup
- Establish integrated PMO scheduling and budget-tracking system by Month 3 (2027-01-12); define monthly workstream milestones and monthly financial-burn forecast through Month 36 (2029-10-12)
- Set up quarterly KPI-tracking dashboard linking programme milestones to gate criteria; brief Steering Council on methodology by Month 6 (2027-04-12)
- Recruit or assign lead coordinators for each of the 5 core workstreams (Containment Protocol, Breeding Trials, Alternative Crops, Smallholder Extension, Surveillance); establish cross-workstream coordination forum (monthly) by Month 3 (2027-01-12)

**Membership:**

- Programme Director (head of PMO, hired by Steering Council)
- Deputy Programme Director (operational oversight, hired by Programme Director subject to Council approval)
- Finance Manager (budget tracking, tranche disbursements, contingency reserve management)
- Workstream Coordinator - Containment Protocol Authority (SALB protocol, producer-nation adoption, protocol-compliance auditing)
- Workstream Coordinator - Resistance Breeding (cultivar development, ABS agreements, breeding-trial coordination across 4 sites)
- Workstream Coordinator - Alternative Crops (Guayule/dandelion farming, processing R&D, pilot plants, OEM engagement)
- Workstream Coordinator - Smallholder Delivery (extension corps, nurseries, replant finance, farmer engagement)

**Decision Rights:** Approve all decisions under USD 50 million (estimate); all workstream budgets and monthly spend within approved allocations; all non-strategic operational changes (e.g., hiring, supplier contracts, minor work-plan adjustments). Cannot approve gate passage or strategic direction changes (escalate to Steering Council). Cannot approve risk-mitigation spending above defined thresholds (escalate to Steering Council and Compliance & Ethics Committee). Authority to commit contingency-reserve deployment is limited to USD 25 million per decision; deployments above that threshold require Council approval.

**Decision Mechanism:** Consensus-seeking among the Programme Director and Workstream Coordinators; Programme Director has final say in ties on operational matters. On budget conflicts, Finance Manager's spend forecast is binding unless overridden by the Steering Council. On workstream disputes (e.g., resource allocation conflicts), PMO convenes a cross-workstream review within 5 working days; if unresolved, escalates to Programme Director, who decides; if still contested, escalates to Steering Council.

**Meeting Cadence:** Monthly full-PMO operational review (Programme Director, Deputy, Finance, all Workstream Coordinators); quarterly steering-review with Steering Council to present workstream status, gate-readiness updates and operational-risk summary. Cross-workstream coordination forum meets weekly (Months 0-36 = 2026-10-12 to 2029-10-12) to align dependencies, then bi-weekly thereafter.

**Typical Agenda Items:**

- Monthly milestone tracking: progress against Phase delivery plan, on-time and on-budget status for each workstream
- Budget execution: monthly spend tracking, burn rate, forecast-to-completion, variance analysis against USD 30 billion cap
- Gate-readiness dashboard: quarterly summary of KPI achievement toward Month 36/84/144/216 (2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12) gates; early-warning flags for at-risk KPIs
- Cross-workstream dependencies: coordination of protocol adoption with surveillance deployment, breeding-trial trial site readiness with smallholder training, alternative-crop siting with processing-plant financing
- Operational risk management: review of workstream-level risks, escalation of risks exceeding thresholds to Steering Council, mitigation-action tracking
- Communications and knowledge management: upcoming publications, data-repository updates, stakeholder communication calendar

**Escalation Path:** Operational decisions exceeding USD 50 million or strategic in nature are escalated to the Steering Council within 10 working days of identification. Workstream conflicts unresolved by consensus are escalated to the Programme Director and, if still unresolved, to the Steering Council. Financial variances exceeding 10% of a workstream budget are escalated to the Finance Manager and flagged to the Steering Council within 15 days. Corruption or institutional-integrity allegations are escalated to the Anti-Corruption Officer and Compliance & Ethics Committee within 24 hours.
### 3. SALB Containment Protocol Authority (embedded in IPPC framework)

**Rationale for Inclusion:** The SALB Containment Protocol is the non-negotiable Phase 1 deliverable and a critical dependency for all other programme elements. It must be harmonized with existing IPPC and regional plant-protection standards to gain legitimacy and binding adoption by major producing nations. A dedicated Authority is required to: (1) draft the protocol in alignment with IPPC frameworks; (2) coordinate with producing nations to embed it in their national regulations by Month 36 (2029-10-12); (3) oversee compliance through a network of inspectors and nursery certifications; (4) trigger incursion response playbooks if SALB is detected; and (5) generate the containment-performance evidence needed for gate verification. Without this dedicated focus, the protocol will lack enforcement and the gates will be undermined.

**Responsibilities:**

- Draft the SALB Containment Protocol harmonized with IPPC and regional plant-protection standards; submit draft to IPPC working group by Month 4 (2027-02-12); support IPPC adoption vote by Month 36 (2029-10-12)
- Lead producer-nation MoU negotiations (Brazil, Indonesia, Thailand, Malaysia, Vietnam) to commit binding national regulatory embedding by Months 36-48 (2029-10-12 to 2030-10-12); coordinate with each nation's plant-protection agency
- Establish compliance-inspection framework: hire and train 100+ inspectors across top 5 producers; deploy inspectors to conduct at least 100,000 inspected lots/year (target by Month 12 = 2027-10-12); maintain compliance certificate database; suspend certification for protocol violations
- Set binding penalty schedule for protocol non-compliance (fines equal to 5-10x value of affected material, reputational consequences); enforce uniformly across countries
- Coordinate with Surveillance Sensing Architecture: verify suspicious SALB alerts from surveillance teams within 2 weeks; issue incursion-response triggers to Incursion Response Playbook authority
- Compile quarterly containment-performance reports: share of nurseries under certified inspection, share of material moved under certified chain-of-custody, compliance violations detected and penalties imposed, red-team drill results; verify this evidence is accurate for independent auditor review at gates

**Initial Setup Actions:**

- Establish Protocol Adoption Secretariat at FAO/IPPC by Month 3 (2027-01-12) with dedicated staff reporting to the Containment Authority director; publish hiring plan and organizational chart by Month 1 (2026-11-12)
- Hire Containment Authority Director by Month 1 (2026-11-12); recruit technical staff (phytosanitary specialists, protocol drafters, compliance managers) by Month 3 (2027-01-12)
- Publish draft protocol for stakeholder and IPPC working-group review by Month 4 (2027-02-12); establish a working group comprising representatives from top 5 producers, IPPC Secretariat, regional plant-protection organizations, and OEMs
- Negotiate bilateral MoUs with Brazil, Indonesia, Thailand, Malaysia and Vietnam by Month 6 (2027-04-12); secure written commitment to bind the protocol in national regulation by Month 36 (2029-10-12) (proposed threshold for scale-up gate)
- Develop compliance-inspection standard operating procedures (SOPs) and inspector training curriculum by Month 6 (2027-04-12); begin recruiting and training inspectors by Month 9 (2027-07-12)
- Establish compliance-certificate database and mobile-based lot-tracking system by Month 12 (2027-10-12); publish certified-nursery list and inspection schedule publicly

**Membership:**

- Containment Authority Director (head, hired by Steering Council)
- Deputy Director for Protocol Drafting and IPPC Coordination (IPPC engagement, draft harmonization)
- Deputy Director for Compliance Inspection and Enforcement (inspector network, certification management, penalty enforcement)
- Technical Lead - Phytosanitary Standards (drafting, harmonization with regional standards)
- Compliance and Enforcement Manager (penalty schedule, violation documentation, appeals)
- Representatives (non-voting) from each of the top 5 producing nations' plant-protection agencies (for consultation and coordination)

**Decision Rights:** Approve protocol language and final draft submission to IPPC; approve compliance-inspection SOPs and penalties within defined bounds (fines 5-10x value, as per policy); approve suspension of nursery certification for non-compliance; approve inspector hiring and inspector-network deployment; approve all communications with producing nations regarding regulatory embedding. Cannot override Steering Council direction on protocol authority model (e.g., if Steering Council directs an alternative authority model, the Authority must adapt). Cannot approve strategic changes to the protocol's scope without Council approval (e.g., expanding to cover other pathogens).

**Decision Mechanism:** Consensus-seeking among Deputy Directors and Technical Lead; Director has final say on operational protocol-drafting decisions. On compliance enforcement (penalty decisions), consensus of Director and Compliance Manager; if disputed by a producing nation, escalate to Steering Council for final review within 30 days. On IPPC working-group negotiations, Director chairs and has authority to accept or reject compromise language, subject to Council approval on major revisions.

**Meeting Cadence:** Weekly internal coordination (Months 0-12 = 2026-10-12 to 2027-10-12) for protocol drafting; bi-weekly during IPPC working-group phase (Months 3-6 = 2027-01-12 to 2027-04-12); monthly thereafter during producer-nation embedding phase (Months 6-36 = 2027-04-12 to 2029-10-12). Quarterly updates to Steering Council and PMO. Bi-weekly coordination with Surveillance and Incursion-Response teams once protocol is adopted (Month 36 onwards = 2029-10-12 onwards).

**Typical Agenda Items:**

- Protocol-drafting progress: harmonization with IPPC standards, stakeholder comment resolution, working-group negotiations
- Producer-nation engagement: MoU status, national regulatory-embedding timeline, country-specific compliance requirements
- Compliance monitoring: inspection coverage (target 100,000 lots/year), certification database, compliance violations and penalties imposed
- Red-team drill planning and results (Months 18-36 = 2028-04-12 to 2029-10-12): test protocol enforcement, document detection accuracy and response speed
- Liaison with Surveillance and Incursion Response: alert-verification procedures, response triggers, data-sharing protocols

**Escalation Path:** Disputes with producing nations on protocol compliance or penalty decisions are escalated to the Steering Council within 15 days; Council reviews and issues guidance within 30 days. If a major producer (Brazil, Indonesia or Thailand) threatens not to embed the protocol by Month 36 (2029-10-12), escalate immediately to Steering Council (within 5 days) for strategic response. Legal challenges or ABS-related disputes (e.g., over use of germplasm data in the protocol) are escalated to the Anti-Corruption Officer and Compliance & Ethics Committee.
### 4. Compliance & Ethics Committee

**Rationale for Inclusion:** This is a large, multi-geography programme spanning developing nations with high corruption and governance risk, involving billions in public-private funding, access-and-benefit-sharing obligations, smallholder finance with default risk, and complex multi-country compliance (Nagoya Protocol, phytosanitary regulations, environmental permits, tax rules). Dedicated oversight of compliance, anti-corruption, ethics, and benefit-sharing is essential to: (1) prevent bribery of inspectors, programme staff or plant-protection officials; (2) ensure ABS agreements are honored and benefit-sharing payments reach intended communities; (3) detect and investigate conflicts of interest in cultivar selection, offtake contracts or resource allocation; (4) manage environmental and social-safeguarding risks; and (5) protect the programme's institutional integrity and credibility with funders and stakeholders. Without this body, corruption or ethics breaches could undermine the entire programme.

**Responsibilities:**

- Develop and enforce programme-wide anti-corruption, conflict-of-interest and ethics policies; publish Code of Conduct for all personnel, contractors and partners by Month 3 (2027-01-12)
- Monitor and audit benefit-sharing compliance: verify that ABS royalties and community payments ($1-5/ha, proposed) are calculated correctly, disbursed on schedule (by Month 12 = 2027-10-12 annually), and reach intended Amazonian communities; conduct annual community benefit-sharing audits
- Oversee breeding-trial data integrity: audit cultivar yield, disease-rating and trial records at 4 sites (Brazil, Thailand, Malaysia/Indonesia, Côte d'Ivoire) to detect data manipulation or undisclosed conflicts of interest; annual audits by independent validators
- Investigate and resolve allegations of corruption, conflict of interest or unethical behavior within 30 days of report; maintain confidentiality and whistleblower protections; escalate findings to the Steering Council and, if warranted, to law enforcement
- Audit smallholder-finance deployment and repayment to detect fraud, misuse of replant-finance funds, or false adoption claims; conduct annual audits of at least 2,000 farmers per major country
- Oversee environmental and social safeguards: audit alternative-crop siting to verify no displacement of smallholders, food-crop loss or water-stress violations; document and mitigate any adverse impacts

**Initial Setup Actions:**

- Hire Committee Chair and Anti-Corruption Officer by Month 1 (2026-11-12); recruit Compliance Manager, ABS Specialist, and Field Auditor by Month 3 (2027-01-12)
- Publish programme Code of Conduct, anti-corruption policy, and conflict-of-interest disclosure form by Month 3 (2027-01-12); require all personnel and partners to sign by Month 6 (2027-04-12)
- Establish benefit-sharing audit protocol and community outreach strategy by Month 6 (2027-04-12); conduct baseline community interviews and publish benefit-sharing verification framework
- Set up confidential reporting channels (hotline, email, field-agent channels) for whistleblowing and allegation reporting by Month 3 (2027-01-12); publicize channels to all personnel and communities
- Develop breeding-data audit plan in coordination with the independent auditor and Resistance Breeding Workstream by Month 6 (2027-04-12); schedule annual audits at each of the 4 breeding sites
- Establish smallholder-finance audit framework and fraud-detection protocols by Month 6 (2027-04-12) in coordination with Smallholder Delivery Workstream

**Membership:**

- Committee Chair (independent, external to the programme, appointed by Steering Council for 3-year renewable term)
- Anti-Corruption Officer (full-time, hired by Committee Chair, reports to Chair and Steering Council)
- Compliance Manager (multi-country compliance tracking, audit scheduling)
- ABS Specialist (benefit-sharing verification, community liaison, Nagoya Protocol compliance)
- Environmental and Social Safeguards Officer (alternative-crop siting audits, land-tenure verification, conflict-of-interest reviews)
- External Member (independent expert in developing-country governance or development-programme compliance; serves 2-year term)

**Decision Rights:** Approve and enforce the Code of Conduct, anti-corruption policy and whistleblower-protection procedures; approve benefit-sharing audit schedules and findings; determine consequences for minor ethics violations (censure, remedial training); approve publication of annual compliance audit summaries. Cannot impose legal penalties (refer to law enforcement); cannot override the independent auditor's data-integrity findings. Can recommend to the Steering Council that a Programme Director or key personnel be removed for cause (conflict of interest, corruption); Council makes final determination.

**Decision Mechanism:** Consensus-seeking among Committee members, with Chair having final say on investigation findings and remedial actions. On conflict-of-interest determinations, at least two members must agree before action is taken. On findings that may trigger disciplinary action, Committee issues a written report with opportunity for the accused party to respond within 10 days; final determination by Chair with notice to Steering Council.

**Meeting Cadence:** Monthly internal meetings (Chair, Anti-Corruption Officer, Compliance Manager, ABS Specialist, Safeguards Officer); quarterly meetings with external members and audit partners (independent auditor, data validators); quarterly reports to Steering Council. Annual in-depth audit-findings review with Steering Council (Month 12 = 2027-10-12 onwards).

**Typical Agenda Items:**

- Whistleblower-allegation summaries: new reports, investigation status, closure of resolved cases
- Benefit-sharing audit results: community-payment verification, disbursement status, benefit-sharing disputes or claims
- Breeding-data audit findings: data-integrity reviews, detected anomalies, conflict-of-interest checks at breeding sites
- Smallholder-finance fraud audits: replant-loan defaults, false-adoption claims, finance-misuse cases
- Environmental and social-safeguards audits: alternative-crop siting impacts, land-tenure issues, community-displacement concerns
- Annual compliance and ethics audit summary: publication plan, lessons learned, policy updates

**Escalation Path:** Allegations of corruption by senior personnel (Programme Director, Steering Council members, Workstream Coordinators) are escalated to the Committee Chair and an independent external investigator appointed by the Chair; findings are reported to the Steering Council and, if warranted, to law enforcement. Findings of systemic corruption or ethics violations affecting programme integrity are escalated to all funders within 15 days. Unresolved community benefit-sharing disputes are escalated to the Steering Council for mediation; if still unresolved, referred to binding arbitration by an independent third party.
### 5. Gate Evidence Verification Panel (Independent Auditor + Standing Technical Advisory Group)

**Rationale for Inclusion:** The programme's funding structure depends entirely on stage-gated capital release at Months 36/84/144/216 (2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12). Gate-passage decisions must be credible, evidence-based and independent to justify capital tranches to funders, producing nations and OEMs. However, the gates measure complex, technical outcomes (containment performance, breeding yield and durability, cost competitiveness of alternatives, smallholder uptake) where interpretation is non-trivial. An independent international auditor is needed to verify KPI evidence with fixed, pre-registered methodology; and a standing Technical Advisory Group is needed to provide specialized scientific input to the auditor on breeding, phytosanitary and processing questions. Together, these two bodies ensure that gate verdicts are credible, transparent and not subject to programme-internal pressure or political interference.

**Responsibilities:**

- Independent Auditor: Contract with an external international audit firm (agricultural or supply-chain audit specialist) by Month 3 (2027-01-12); maintain independence from the PMO and Steering Council
- Independent Auditor: Pre-register audit scope and KPI definitions for each of the 4 gates (Month 36/84/144/216 = 2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12) by Month 6 (2027-04-12), including: field-visit plan (30-40% of audit time), database audit (40-50%), stakeholder interviews (20-30%), validation thresholds for each KPI, and dispute-resolution protocol
- Independent Auditor: Conduct unannounced and announced field audits at breeding sites, nurseries, estates, processing plants and surveillance hubs; collect primary data on yield, disease ratings, cost, quality variance, containment compliance and smallholder adoption
- Independent Auditor: Issue gate-closure reports 30 days before gate date, stating KPI achievement (pass/fail/conditional), auditor confidence level, and dissenting findings if applicable; publish verdict within 30 days of gate closure
- Technical Advisory Group: Provide specialized input to auditor on breeding-trial interpretation (interpreting yield penalties, resistance durability, multi-site variability); provide input on surveillance data, processing costs, and smallholder-adoption metrics; meet quarterly and for each gate assessment
- Gate Adjudication: If the Steering Council disputes the auditor's KPI verdict, refer dispute to a neutral third-party Adjudication Panel; Panel reviews auditor methodology and data, hears both sides, and issues binding judgment within 60 days

**Initial Setup Actions:**

- Issue request for proposals (RFP) for independent auditor by Month 2 (2026-12-12); evaluate proposals and contract auditor by Month 3 (2027-01-12)
- Recruit independent Auditor Team Lead (embedded in the auditor firm, dedicated to the programme) by Month 3 (2027-01-12); hire field auditors and data specialists
- Form Technical Advisory Group by Month 3 (2027-01-12): recruit 6-8 members including plant pathologist (SALB specialist), plant breeder (Hevea genetics), processing engineer, agronomist (alternative crops), statistician, and supply-chain economist; each member serves 3-year renewable term
- Pre-register audit methodology, KPI definitions and validation thresholds for Month 36 (2029-10-12) gate by Month 6 (2027-04-12); publish pre-registered scope in a dedicated audit-governance document available to all stakeholders
- Establish gate-data submission protocol: PMO submits gate-readiness report to auditor 6 months before gate closure (Month 30/78/138/210 = 2029-04-12, 2033-04-12, 2038-04-12, 2044-04-12) including all trial databases, surveillance records, cost records and smallholder-adoption data
- Establish Adjudication Panel by Month 6 (2027-04-12) comprising three independent experts (one in international arbitration, one in agriculture, one in supply-chain governance); Panel chair is neutral intermediary

**Membership:**

- Independent Auditor (contract firm, reports to Steering Council, not to PMO or Programme Director)
- Auditor Team Lead (embedded with auditor firm, dedicated, reports to firm management and Steering Council)
- Technical Advisory Group Chair (independent, recruited by Steering Council, reports to auditor and Advisory Group)
- Technical Advisory Group Members (6-8 specialists: SALB pathologist, plant breeder, processing engineer, agronomist, statistician, supply-chain economist, and optionally an OEM representative and a smallholder-agronomy specialist)
- Gate Adjudication Panel Chair (independent arbitrator, neutral, appointed by Steering Council for 5-year term)

**Decision Rights:** Independent Auditor: Sole authority to verify KPI achievement and issue gate-closure verdict; verdict is binding unless Steering Council initiates formal adjudication (within 15 days of auditor report). Technical Advisory Group: Advises auditor; group consensus recommendations carry weight but auditor makes final interpretation call. Adjudication Panel: Sole authority to resolve disputes between Steering Council and Auditor; Panel determination is binding and final. Neither the auditor nor the Advisory Group can approve gate passage or tranche release; only the Steering Council can authorize tranche release (based on auditor verdict, 80% minimum rule).

**Decision Mechanism:** Independent Auditor: Issues final verdict based on pre-registered methodology; no consensus requirement; auditor applies judgment within the pre-registered KPI definitions. Technical Advisory Group: Consensus-seeking on major interpretation questions; if no consensus, minority and majority views are documented for auditor consideration. Adjudication Panel: Chair appoints voting procedures; majority vote (2 of 3 panelists) carries decision; written judgment issued within 60 days.

**Meeting Cadence:** Technical Advisory Group meets quarterly (before each gate, at Month 12, 36, 66, 126, 186, 246 = 2027-10-12, 2029-10-12, 2032-10-12, 2037-10-12, 2041-10-12, 2045-10-12, estimate); more frequently (monthly) from Month 12-36 (2027-10-12 to 2029-10-12) during first gate. Independent Auditor submits monthly progress updates (during field-audit phases); full gate-closure report 30 days before each gate deadline. Adjudication Panel convenes only if formal dispute is filed (within 15 days of auditor report).

**Typical Agenda Items:**

- Pre-registered audit scope and KPI definitions (finalized by Month 6 = 2027-04-12 for each gate)
- Field-audit planning and data-collection protocols (before each gate audit phase)
- Technical interpretation of breeding-trial data: yield penalties, multi-site variability, disease-rating consistency
- Surveillance-data interpretation: incursion detection, protocol compliance, false-alarm rates
- Processing-cost and quality-data validation: extraction yield, product specifications, offtake readiness
- Smallholder-adoption data review: survey methodology, default rates, extension-network quality, income-bridging effectiveness
- Gate-closure verdict: KPI achievement, confidence levels, dissenting findings, recommendations for capital release or withholding

**Escalation Path:** If the auditor identifies data inconsistency, missing records or potential data manipulation at a breeding site or nursery, escalate to Compliance & Ethics Committee within 5 days for investigation. If the auditor's gate verdict is disputed by the Steering Council, escalate to Adjudication Panel within 15 days; Panel's decision is final. If an Advisory Group member has a conflict of interest (e.g., financial stake in a processing plant), the member recuses and the group continues with remaining members.
### 6. Resistance Breeding and Cultivar Deployment Oversight Group

**Rationale for Inclusion:** The Year 7 gate (Month 84 = 2033-10-12) depends critically on SALB-resistant, yield-parity Hevea cultivars being ready for deployment. This is the tightest timeline in the programme: trials must be planted by Month 12 (2027-10-12) at 4 sites (Brazil, Thailand, Malaysia/Indonesia, Côte d'Ivoire) to yield 6-year data by Month 84 (2033-10-12). The breeding path has zero slack. This workstream also has high technical complexity (polygenic resistance, durability testing, cultivar selection criteria) and carries significant risk (yield penalties may exceed 10-15%, durability may fail against new SALB variants, multi-site trial interpretation can be contentious). A dedicated Oversight Group is essential to: (1) set clear breeding objectives and KPI thresholds before trials begin; (2) track breeding progress quarterly and identify early warning signals (yield penalties >10% by Month 48 = 2030-10-12); (3) manage cultivar-selection decisions and multi-site trial coordination; (4) oversee durability monitoring beyond the Year 7 gate; and (5) provide transparent, auditable records for the independent Auditor. Without this specialized group, the Year 7 gate will be missed and the programme's entire schedule will cascade-fail.

**Responsibilities:**

- Establish and publish breeding objectives by Month 6 (2027-04-12): define target yield (≥90% of elite clones), minimum resistance sources (≥3 stacked, independent), lesion-size threshold (≤5 mm), defoliation threshold (≤20%), durability-testing requirements (artificial inoculation at 10x field load, sentinel plantings at 4+ sites)
- Coordinate breeding trials across 4 sites (Brazil, Thailand, Malaysia/Indonesia, Côte d'Ivoire): ensure site readiness by Month 12 (2027-10-12), training of site managers and data recordists, and standardized trial protocols across all sites
- Oversee cultivar selection: compile data from all sites at Month 48 (2030-10-12) and Month 72 (2032-10-12) interim checkpoints; assess yield penalties, resistance stacking progress, and durability signals; make go/no-go decisions on candidate cultivars
- Identify early warning signals: by Month 48 (2030-10-12), if yield penalty exceeds 15% (yield <85% of elite) at any site, trigger a breeding-pathway decision (continue conventional breeding, accelerate fast-track crown-budding, or re-scope cultivar targets)
- Oversee Year 7 gate cultivar-readiness evidence: compile standardized yield, disease-rating and multi-site data; validate data accuracy at each site; prepare evidence package for independent auditor 6 months before gate (Month 78 = 2033-04-12)
- Establish post-release durability monitoring: design sentinel plantings and quarterly pathogen-variant surveillance (Months 84-216 onwards = 2033-10-12 to 2044-10-12); begin breeding next-generation cultivars by Month 60 (2031-10-12) so replacements are available within 7 years if breakdown occurs

**Initial Setup Actions:**

- Hire Breeding Programme Director and breeding coordinator by Month 3 (2027-01-12); recruit breeding specialists at each of the 4 sites by Month 9 (2027-07-12)
- Finalize breeding objectives and pre-register cultivar-selection criteria by Month 6 (2027-04-12); publish in a public document with stakeholder input from the Technical Advisory Group and OEM representatives
- Prepare and plant trials at all 4 sites by Month 12 (2027-10-12); establish standardized data-collection protocols and laboratory confirmation methods (disease rating, yield measurement, molecular confirmation of resistance genes)
- Establish quarterly data-review and progress-tracking schedule; compile interim reports at Months 24, 36, 48, 60, 72 (2028-10-12, 2029-10-12, 2030-10-12, 2031-10-12, 2032-10-12) assessing yield, disease control and resistance stacking
- Establish breeding data repository with redundant backup and version control by Month 12 (2027-10-12); grant access to independent auditor and Compliance & Ethics Committee for audits
- Plan second-generation cultivar breeding (start Month 60 = 2031-10-12) to ensure replacements are available by Month 120 (2036-10-12) if first-generation cultivar durability shows early breakdown

**Membership:**

- Breeding Programme Director (senior breeder, hired by Steering Council, recruited from national research institute or international agricultural research center)
- Deputy Directors for each geographic region: Brazil Lead, Thailand/Southeast Asia Lead, Côte d'Ivoire/West Africa Lead
- Breeding Coordinator (data management, multi-site trial oversight, cultivar-selection documentation)
- Site Managers at each of 4 locations: Brazil, Thailand, Malaysia/Indonesia, Côte d'Ivoire (report to regional Deputy Director and Breeding Coordinator)
- External Advisory: SALB pathologist (durability consultant), statistician (multi-site analysis), molecular biologist (resistance-gene validation)

**Decision Rights:** Approve cultivar-selection criteria and breeding objectives (within Steering Council guidance); make go/no-go decisions on candidate cultivars at Month 48 and 72 (2030-10-12, 2032-10-12) interim gates; approve breeding-pathway changes (e.g., initiating crown-budding fast-track) if yield penalties exceed defined thresholds by Month 48 (2030-10-12). Cannot override the independent auditor's interpretation of trial data; must provide auditor with complete data access and cooperate fully with audits. Can decide to release cultivars to seed producers and nurseries only after obtaining Steering Council authorization (based on auditor gate verdict).

**Decision Mechanism:** Consensus-seeking among Breeding Programme Director, Regional Deputy Directors and Breeding Coordinator on major decisions (cultivar selection, pathway changes). Director has final say on breeding-technical decisions if consensus cannot be reached. On Year 7 gate evidence compilation, Breeding Coordinator ensures data quality and Breeding Programme Director certifies completeness and accuracy for auditor submission.

**Meeting Cadence:** Monthly internal coordination (Breeding Programme Director, Regional Deputies, Coordinator); quarterly data-review meetings with all 4 site managers (Months 12, 24, 36, 48, 60, 72 = 2027-10-12, 2028-10-12, 2029-10-12, 2030-10-12, 2031-10-12, 2032-10-12 and annually thereafter); quarterly updates to PMO and Steering Council. Advisory input from Technical Advisory Group at Month 48 (2030-10-12) and Month 72 (2032-10-12) interim decision points.

**Typical Agenda Items:**

- Monthly site reports: trial progress, data quality, issues or delays at any location
- Quarterly data review: yield measurements, disease ratings, resistance-gene validation, multi-site comparisons
- Breeding-pathway checkpoints: Month 48 (2030-10-12) yield-penalty assessment and decision (continue, accelerate, or re-scope); Month 60 (2031-10-12) decision to initiate second-generation cultivar breeding
- Cultivar-selection process: Month 72 (2032-10-12) final cultivar candidates for Year 7 gate; evidence package assembly for auditor
- Post-Year 7 durability strategy: sentinel plantings, pathogen-variant monitoring, next-generation breeding timeline
- Data-repository management: data quality assurance, backup protocols, auditor access

**Escalation Path:** If yield penalties exceed 15% at any site by Month 48 (2030-10-12), escalate immediately to PMO and Steering Council for pathway decision (within 5 days). If data integrity concerns arise (missing records, inconsistent measurements, apparent manipulation), escalate to Compliance & Ethics Committee within 24 hours for investigation. If multi-site interpretation is contentious (e.g., one site shows poor durability while others show good), escalate to the Technical Advisory Group pathologist for independent expert assessment; if still unresolved, refer to Gate Adjudication Panel for pre-gate mediation.

# Governance Implementation Plan

### 1. Project Sponsor (Senior Funder Representative) identifies and appoints the Steering Council Chair. The Chair is selected from among the sovereign funders and given explicit authority to lead the inaugural Council convening.

**Responsible Body/Role:** Project Sponsor / Lead Sovereign Funder

**Suggested Timeframe:** Month 0 (2026-10-12) (project start: 2026-10-12)

**Key Outputs/Deliverables:**

- Steering Council Chair appointment letter
- Written delegation of authority to Chair for inaugural convening

**Dependencies:**

- Project formally authorized and funding commitment confirmed from at least one sovereign funder

### 2. Steering Council Chair drafts and circulates the initial Terms of Reference (ToR) for the Steering Council, defining governance scope, decision thresholds (e.g., USD 50M spend authority delegation, gate-passage authority), escalation rules, meeting cadence (quarterly), and transparency standards. Circulate for feedback from nominated sovereign, OEM, research institution and smallholder representatives by Month 2 (2026-12-12).

**Responsible Body/Role:** Steering Council Chair (appointed by Sponsor)

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 2 (2026-12-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Steering Council Terms of Reference v0.1
- Stakeholder feedback summary

**Dependencies:**

- Steering Council Chair appointed
- List of nominated Council members (sovereign reps, OEM reps, research institution reps, smallholder reps) confirmed

### 3. Steering Council Chair finalizes the ToR based on stakeholder feedback and formally appoints the initial Council membership (at least 5 sovereign funders, 2-3 OEM representatives, 2-3 research institution representatives, 1-2 smallholder/farmer representatives). Distribute final ToR to all appointed members.

**Responsible Body/Role:** Steering Council Chair

**Suggested Timeframe:** Month 2 (2026-12-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Steering Council Terms of Reference Final
- Council member appointment letters
- Council member contact list and availability calendar

**Dependencies:**

- Steering Council ToR v0.1 feedback resolved
- Candidate pool for Council seats identified and pre-vetted

### 4. Steering Council Chair schedules and holds the inaugural Steering Council kick-off meeting. Council formally confirms its role, approves governance procedures, confirms the quarterly meeting schedule (with accelerated monthly meetings Months 3-6 during early setup), and establishes the escalation hierarchy.

**Responsible Body/Role:** Steering Council (all members present)

**Suggested Timeframe:** Month 1 (2026-11-12) - meeting scheduled; meeting held by Month 3 (2027-01-12)

**Key Outputs/Deliverables:**

- Inaugural Council meeting minutes with decisions recorded
- Approved meeting schedule (quarterly with monthly Months 3-6 = 2027-01-12 to 2027-04-12)
- Confirmed governance procedures and decision-making rules

**Dependencies:**

- Steering Council membership formalized
- Terms of Reference finalized and distributed

### 5. Steering Council authorizes the recruitment of the Programme Director, the chief operational executive. The Council defines the role (reporting to Council Chair and full Council), authority thresholds (USD 50M), and required qualifications (senior programme management, agricultural/supply-chain experience, 25-year strategic stamina).

**Responsible Body/Role:** Steering Council

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Programme Director job description
- Recruitment request to search firm or internal vetting process

**Dependencies:**

- Steering Council formally established and kick-off meeting held
- Budget allocated for Programme Director salary and PMO staffing

### 6. Project Sponsor or Programme Director candidate (if internal recruitment from existing institution) recruits the Compliance & Ethics Committee Chair, an independent external expert in agricultural development-programme governance or anti-corruption. The Chair is not part of PMO but reports directly to the Steering Council.

**Responsible Body/Role:** Project Sponsor / Steering Council Chair (if no Programme Director yet hired)

**Suggested Timeframe:** Month 1 (2026-11-12)

**Key Outputs/Deliverables:**

- Compliance & Ethics Committee Chair recruitment initiated
- Chair job description and independence criteria published

**Dependencies:**

- Steering Council authorized recruitment of Compliance & Ethics infrastructure

### 7. Compliance & Ethics Committee Chair, once appointed (by Month 1-2, 2026-11-12 to 2026-12-12), drafts the programme Code of Conduct and anti-corruption policy. This policy applies to all PMO staff, contractors, partners, and nominated representatives from producing nations and OEMs.

**Responsible Body/Role:** Compliance & Ethics Committee Chair

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Draft Code of Conduct and Anti-Corruption Policy v0.1
- Whistleblower-protection procedures draft

**Dependencies:**

- Compliance & Ethics Committee Chair recruited and appointed

### 8. Compliance & Ethics Committee Chair circulates the Code of Conduct and policy for stakeholder review; collects feedback from Steering Council, research institutions, producer-nation representatives, and OEMs. Incorporate feedback by Month 2-3 (2026-12-12 to 2027-01-12).

**Responsible Body/Role:** Compliance & Ethics Committee Chair

**Suggested Timeframe:** Month 2 (2026-12-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Stakeholder feedback summary on Code of Conduct
- Revised Code of Conduct v0.2

**Dependencies:**

- Code of Conduct draft circulated

### 9. Steering Council formally approves the final Code of Conduct, Anti-Corruption Policy and whistleblower procedures. Publish the policies to all stakeholders.

**Responsible Body/Role:** Steering Council

**Suggested Timeframe:** Month 3 (2027-01-12)

**Key Outputs/Deliverables:**

- Steering Council approval minute on Code of Conduct
- Final Code of Conduct, Anti-Corruption Policy and Whistleblower Procedures (published)

**Dependencies:**

- Code of Conduct v0.2 finalized
- Steering Council inaugural meeting held

### 10. Programme Director, once hired (by Month 3, 2027-01-12), establishes the Programme Management Office (PMO). Recruit Deputy Programme Director, Finance Manager, and Workstream Coordinators for Containment Protocol, Breeding Trials, Alternative Crops, and Smallholder Delivery by Month 3-6 (2027-01-12 to 2027-04-12).

**Responsible Body/Role:** Programme Director (upon hire)

**Suggested Timeframe:** Month 3 (2027-01-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- PMO organizational chart
- Job descriptions for Deputy Director, Finance Manager, Workstream Coordinators
- Recruitment complete; all PMO leadership seated by Month 6 (2027-04-12)

**Dependencies:**

- Programme Director hired by Month 3 (2027-01-12)
- Budget allocated for PMO staffing
- Steering Council approved PMO structure

### 11. Steering Council authorizes the contracting of an independent international auditor to verify gate evidence. Steering Council issues a Request for Proposals (RFP) by Month 2 (2026-12-12).

**Responsible Body/Role:** Steering Council

**Suggested Timeframe:** Month 2 (2026-12-12)

**Key Outputs/Deliverables:**

- RFP for independent auditor issued

**Dependencies:**

- Steering Council formally established
- Budget for auditor identified (USD 30-50M estimate)

### 12. Auditor selection and contract negotiation. Steering Council evaluates RFP responses and selects the independent auditor by Month 3 (2027-01-12). Contract is signed with independence clauses, data-access rights, and gate-closure timeline (reports 30 days before each gate).

**Responsible Body/Role:** Steering Council (with PMO Finance Manager support)

**Suggested Timeframe:** Month 2 (2026-12-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Auditor selection documented
- Auditor contract signed with independence and reporting clauses

**Dependencies:**

- RFP for auditor issued
- Steering Council evaluation process initiated

### 13. Independent Auditor, once contracted (by Month 3, 2027-01-12), recruits its core audit team (Team Lead, field auditors, data specialists). Auditor begins designing pre-registered audit scope and KPI definitions for Month 36 gate (2029-10-12) by Month 4 (2027-02-12).

**Responsible Body/Role:** Independent Auditor (contracted firm)

**Suggested Timeframe:** Month 3 (2027-01-12) to Month 4 (2027-02-12 to 2027-02-12)

**Key Outputs/Deliverables:**

- Auditor Team Lead and core team named
- Audit design framework for Month 36 (2029-10-12) gate initiated

**Dependencies:**

- Auditor contract signed

### 14. Steering Council establishes the Technical Advisory Group to support the independent auditor with specialized scientific advice on breeding, phytosanitary, processing and supply-chain questions. Recruit 6-8 members (plant pathologist, breeder, processing engineer, agronomist, statistician, economist, optionally OEM and smallholder-agronomy specialist) by Month 3 (2027-01-12).

**Responsible Body/Role:** Steering Council

**Suggested Timeframe:** Month 3 (2027-01-12)

**Key Outputs/Deliverables:**

- Technical Advisory Group membership appointed
- Advisory Group ToR finalized

**Dependencies:**

- Steering Council authorized Advisory Group establishment

### 15. Steering Council, jointly with the Independent Auditor and Technical Advisory Group, pre-registers the audit scope, KPI definitions, validation thresholds, and dispute-resolution protocol for all four gates (Months 36, 84, 144, 216 = 2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12). Document includes field-visit plan (30-40%), database audit (40-50%), interviews (20-30%), and clear pass/fail criteria for each KPI.

**Responsible Body/Role:** Independent Auditor (with Technical Advisory Group and Steering Council input)

**Suggested Timeframe:** Month 4 (2027-02-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Pre-Registered Audit Scope and KPI Definitions document (published)
- Gate Evidence Verification Regime operational manual

**Dependencies:**

- Independent Auditor contracted and team recruited
- Technical Advisory Group established
- PMO workstreams defined so KPIs can be aligned with delivery targets

### 16. Steering Council appoints the Gate Adjudication Panel Chair (neutral third party), who will mediate disputes between the Steering Council and Independent Auditor on gate verdicts. Panel is composed of three independent experts (one arbitration specialist, one agriculture specialist, one supply-chain governance specialist). Panel is activated only if formal disputes are filed.

**Responsible Body/Role:** Steering Council

**Suggested Timeframe:** Month 6 (2027-04-12)

**Key Outputs/Deliverables:**

- Gate Adjudication Panel Chair appointed
- Panel members named
- Panel ToR and dispute-resolution procedures published

**Dependencies:**

- Steering Council authorized Panel establishment
- Pre-registered audit scope finalized

### 17. Compliance & Ethics Committee Chair, supported by the Steering Council, completes recruitment of the full Committee: Anti-Corruption Officer, Compliance Manager, ABS Specialist, Environmental & Social Safeguards Officer, and one independent external member. All staff seated by Month 3-6 (2027-01-12 to 2027-04-12).

**Responsible Body/Role:** Compliance & Ethics Committee Chair (with Steering Council support)

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Compliance & Ethics Committee full staffing complete
- Anti-Corruption Officer, Compliance Manager, ABS Specialist and Safeguards Officer seated

**Dependencies:**

- Compliance & Ethics Committee Chair appointed
- Committee ToR finalized
- Budget allocated for Committee staffing

### 18. Compliance & Ethics Committee publishes the final Code of Conduct and requires all PMO staff, contractors, partners, and nominated representatives from producing nations and OEMs to sign by Month 6 (2027-04-12). Maintain signed records.

**Responsible Body/Role:** Compliance & Ethics Committee

**Suggested Timeframe:** Month 3 (2027-01-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Code of Conduct signed by 100% of PMO, contractor, and partner personnel
- Conflict-of-interest disclosure forms completed and archived

**Dependencies:**

- Code of Conduct final version approved by Steering Council
- All PMO and key contractor staff identified

### 19. Compliance & Ethics Committee establishes confidential whistleblower reporting channels (dedicated hotline, email, mobile-based field-agent channel for smallholders and inspectors) and publicizes channels to all programme personnel and communities by Month 3-6 (2027-01-12 to 2027-04-12). Train frontline staff on reporting procedures.

**Responsible Body/Role:** Compliance & Ethics Committee (Anti-Corruption Officer and Compliance Manager)

**Suggested Timeframe:** Month 3 (2027-01-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Whistleblower hotline operational
- Whistleblower-protection procedures published and disseminated to all staff and communities
- Training materials for field staff on reporting procedures

**Dependencies:**

- Whistleblower procedures finalized
- Compliance & Ethics Committee staffed

### 20. Steering Council signs binding 25-year framework agreements with all sovereign and multilateral-development-bank funders. Agreements specify gate-release triggers (minimum 80% of tranche released on partial gate success), disbursement timelines (within 45 days of gate passage), minimum-funding floors (e.g., 80% of planned tranche if gate is partially met), and escalation procedures for funding disputes. Completion target: Month 12 (2027-10-12).

**Responsible Body/Role:** Steering Council (with legal counsel)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Binding 25-year framework agreements signed with each funder
- Master framework agreement document
- Tranche-release trigger matrix

**Dependencies:**

- Steering Council formally established
- Gate KPI definitions finalized
- Budget and tranche allocation approved by Steering Council

### 21. Steering Council negotiates and executes industry resilience levy agreements with the top 10 tire makers and 5 major rubber traders. Levy is set at 0.75% (range 0.5-1.0%, estimate) of covered natural-rubber purchases, yielding approximately USD 150M/year (estimate). Agreements include multi-year binding commitments with penalties for early defection.

**Responsible Body/Role:** Steering Council (OEM members and Programme Director leading negotiation)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Levy agreements signed with at least 10 OEMs and 5 traders
- Levy collection mechanism and schedule established
- First levy payment received by Month 18 (2028-04-12) (estimate)

**Dependencies:**

- Steering Council OEM members authorized to commit companies
- Levy rate and structure decided by Council

### 22. PMO Finance Manager, upon hire (by Month 6, 2027-04-12), establishes an integrated budget-tracking and KPI-monitoring system. System links monthly workstream milestones to gate criteria, tracks spending against the USD 30 billion cap, forecasts burn rate through each phase, and alerts to variances exceeding 10%.

**Responsible Body/Role:** PMO Finance Manager

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 9 (2027-07-12 to 2027-07-12)

**Key Outputs/Deliverables:**

- Integrated budget and KPI tracking dashboard operational
- Monthly financial reporting template
- Quarterly KPI dashboard for Steering Council

**Dependencies:**

- PMO staffing complete
- Budget allocations finalized
- Phase 1 delivery plan drafted

### 23. Programme Director establishes the SALB Containment Protocol Authority, a dedicated body within the FAO/IPPC institutional framework. Recruit Containment Authority Director (senior phytosanitary specialist) and Deputy Directors for Protocol Drafting and Compliance Inspection by Month 1-3 (2026-11-12 to 2027-01-12). Director reports to Programme Director and Steering Council.

**Responsible Body/Role:** Programme Director (with Steering Council oversight)

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Containment Authority Director recruited
- Deputy Director positions filled
- Authority operational charter approved by Steering Council

**Dependencies:**

- Programme Director hired
- Steering Council approved establishment of Containment Authority

### 24. Containment Protocol Authority Director establishes a Protocol Adoption Secretariat at FAO/IPPC (Rome) with dedicated staff reporting to the Director. Secretariat is tasked with coordinating protocol drafting, IPPC working-group engagement, and producer-nation adoption negotiations. Staffing complete by Month 3 (2027-01-12).

**Responsible Body/Role:** Containment Protocol Authority Director

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Protocol Adoption Secretariat established at FAO/IPPC
- Secretariat organizational chart and staff assignments published

**Dependencies:**

- Containment Authority Director recruited
- FAO/IPPC hosting agreement confirmed

### 25. Containment Protocol Authority Director, with the Secretariat, drafts the SALB Containment Protocol harmonized with IPPC and regional plant-protection standards. Draft incorporates movement controls for nursery stock, research materials and equipment, quarantine procedures, inspection criteria, and penalty schedules for non-compliance. Coordinate with phytosanitary specialists from all top 5 producing nations during drafting.

**Responsible Body/Role:** Containment Protocol Authority (Secretariat staff and drafting team)

**Suggested Timeframe:** Month 2 (2026-12-12) to Month 4 (2027-02-12 to 2027-02-12)

**Key Outputs/Deliverables:**

- Draft SALB Containment Protocol v0.1 (circulated for stakeholder feedback)

**Dependencies:**

- Containment Authority Director and Secretariat seated
- Input from phytosanitary experts from top 5 producers secured

### 26. Containment Protocol Authority submits the draft protocol to the IPPC working group for technical comment and harmonization review. IPPC working group is composed of plant-protection agency representatives from major rubber-producing nations, IPPC Secretariat, regional plant-protection organizations, and OEM observers. Working-group meetings held Months 3-4 (2027-01-12 to 2027-02-12); feedback period through Month 4 (2027-02-12).

**Responsible Body/Role:** Containment Protocol Authority (in coordination with IPPC)

**Suggested Timeframe:** Month 3 (2027-01-12) to Month 4 (2027-02-12 to 2027-02-12)

**Key Outputs/Deliverables:**

- IPPC working-group comment summary
- Draft protocol v0.2 incorporating stakeholder feedback

**Dependencies:**

- Draft protocol v0.1 submitted to IPPC
- IPPC working group convened

### 27. Containment Protocol Authority Director leads bilateral MoU negotiations with Brazil, Indonesia, Thailand, Malaysia, and Vietnam (top 5 rubber-producing nations). Each MoU commits the producing nation to embed the SALB protocol in its national plant-protection regulation by Month 36 (2029-10-12) and to maintain at least 20 trained inspectors and compliance-certificate management. Target completion of all 5 MoUs: Month 6 (2027-04-12).

**Responsible Body/Role:** Containment Protocol Authority Director (with PMO and Steering Council support)

**Suggested Timeframe:** Month 3 (2027-01-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Bilateral MoU with Brazil signed
- Bilateral MoU with Indonesia signed
- Bilateral MoU with Thailand signed
- Bilateral MoU with Malaysia signed
- Bilateral MoU with Vietnam signed

**Dependencies:**

- Draft protocol v0.2 ready for country discussion
- Steering Council authorized bilateral negotiation with countries

### 28. Containment Protocol Authority, in coordination with national plant-protection agencies from top 5 producers, develops standardized compliance-inspection standard operating procedures (SOPs) and inspector training curriculum. SOPs specify nursery-inspection protocols, lot-tracking procedures, certificate issuance and revocation rules, and inspection reporting. Curriculum is tailored to each country's institutional capacity.

**Responsible Body/Role:** Containment Protocol Authority (Deputy Director for Compliance Inspection, with input from country plant-protection agencies)

**Suggested Timeframe:** Month 4 (2027-02-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Standardized Compliance-Inspection SOP (published)
- Inspector Training Curriculum (published, country-specific modules)

**Dependencies:**

- Bilateral MoUs with top 5 producers signed
- IPPC protocol harmonization near completion

### 29. Containment Protocol Authority Deputy Director for Compliance Inspection begins recruiting and training 100+ compliance inspectors across the top 5 producing nations (approximately 20 per country). Training uses the standardized curriculum; recruits are drawn from existing national plant-protection agencies and agricultural research institutes. First cohort of 50 inspectors trained by Month 12 (2027-10-12); full complement of 100 by Month 18 (2028-04-12).

**Responsible Body/Role:** Containment Protocol Authority (Deputy Director for Compliance Inspection)

**Suggested Timeframe:** Month 9 (2027-07-12) to Month 18 (2028-04-12 to 2028-04-12)

**Key Outputs/Deliverables:**

- 100+ inspectors recruited and trained by Month 18 (2028-04-12)
- Inspector certification and field-deployment roster
- First 50 inspectors operational by Month 12 (2027-10-12)

**Dependencies:**

- Compliance-inspection SOP and curriculum finalized
- Bilateral MoUs with countries committed inspector staffing
- Budget allocated for inspector salaries and training (estimated USD 100-150M over Months 0-120 = 2026-10-12 to 2036-10-12)

### 30. Containment Protocol Authority establishes a compliance-certificate database and mobile-based lot-tracking system to manage nursery certifications, inspection schedules, and certified material movements. System is deployed to inspectors and participating nurseries by Month 12 (2027-10-12). Database is linked to surveillance and incursion-response systems for alert verification.

**Responsible Body/Role:** Containment Protocol Authority (IT and Compliance teams)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Compliance-certificate database operational
- Mobile lot-tracking system deployed to 100+ inspectors
- Real-time dashboard of nurseries under certification

**Dependencies:**

- Containment Authority IT infrastructure established
- Inspector staffing begun

### 31. Containment Protocol Authority publishes the binding penalty schedule for protocol non-compliance: fines equal to 5-10x (estimate) the value of affected planting material, publication in national gazettes, and reputational consequences (public certificate suspension). Penalties are enforced uniformly across all countries per the bilateral MoUs.

**Responsible Body/Role:** Containment Protocol Authority (Compliance and Enforcement Manager)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 9 (2027-07-12 to 2027-07-12)

**Key Outputs/Deliverables:**

- Binding penalty schedule published
- Penalty enforcement procedures documented

**Dependencies:**

- Bilateral MoUs signed (country commitment to enforce)
- Steering Council approved penalty framework

### 32. Containment Protocol Authority publishes the finalized SALB Containment Protocol for IPPC adoption vote. Protocol incorporates all stakeholder feedback and is harmonized with regional phytosanitary standards. Formal IPPC adoption vote is scheduled for Month 36 (2029-10-12) gate deadline.

**Responsible Body/Role:** Containment Protocol Authority (with IPPC Secretariat)

**Suggested Timeframe:** Month 12 (2027-10-12) to Month 18 (2028-04-12 to 2028-04-12)

**Key Outputs/Deliverables:**

- Final SALB Containment Protocol published
- IPPC adoption vote scheduled for Month 36 (2029-10-12)

**Dependencies:**

- All stakeholder feedback integrated
- Bilateral MoUs confirm country support for protocol
- IPPC working group completes harmonization review

### 33. Programme Director, with Workstream Coordinator for Containment, develops the detailed Phase 1 (Months 0-36, 2026-10-12 to 2029-10-12) delivery plan. Plan includes protocol-adoption timeline (MoUs, IPPC vote, national embedding), surveillance system setup (inspector training, laboratory capacity, detection targets), incursion-response doctrine (eradication-first with prefunded compensation fund USD 0.5B), and red-team drill schedule (Months 18-36 = 2028-04-12 to 2029-10-12).

**Responsible Body/Role:** PMO (Programme Director and Workstream Coordinators)

**Suggested Timeframe:** Month 3 (2027-01-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Phase 1 Delivery Plan (published)
- Workstream milestones and monthly delivery targets

**Dependencies:**

- PMO fully staffed
- Containment Protocol Authority established
- Surveillance and Incursion Response architectural decisions confirmed

### 34. PMO Workstream Coordinator for Surveillance (Surveillance Sensing Architecture) designs the tiered surveillance network to detect SALB incursions: Tier 1 (primary producers: monthly field scouting + monthly laboratory confirmation, detection target <3 months); Tier 2 (secondary regions: quarterly scouting + portable diagnostics, target <6 months); Tier 3 (smallholder sentinels: paid reporting system, regional expert verification within 2 weeks).

**Responsible Body/Role:** PMO (Surveillance Workstream Coordinator, recruited by Month 6 = 2027-04-12)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Surveillance Architecture Design (published)
- Detection protocols and response-trigger criteria documented

**Dependencies:**

- Containment Protocol Authority established (to set compliance inspection context)
- PMO workstreams staffed

### 35. PMO (in coordination with Containment Authority and national plant-protection agencies) establishes and funds regional diagnostic laboratories in at least 10 producing-region locations (sample distribution: 3-4 in Southeast Asia, 2-3 in Brazil, 1-2 in West Africa, 1-2 in USA/Mexico). Labs conduct molecular PCR confirmation of SALB incursions. First labs operational by Month 24 (2028-10-12); full network by Month 36 (2029-10-12).

**Responsible Body/Role:** PMO (Surveillance Workstream Coordinator, with Containment Authority support)

**Suggested Timeframe:** Month 9 (2027-07-12) to Month 24 (2028-10-12 to 2028-10-12)

**Key Outputs/Deliverables:**

- At least 10 regional diagnostic laboratories established
- Lab protocols and capacity documented
- Laboratory network operational by Month 24 (2028-10-12)

**Dependencies:**

- Surveillance Architecture finalized
- Budget allocated for lab establishment and training (estimated USD 50-100M over 10 years)

### 36. PMO establishes the Incursion Response Playbook, pre-agreeing the operational and financial doctrine for responding to confirmed SALB detections. Doctrine is eradication-first: infected plantings are destroyed within a defined buffer zone, and compensation is paid to affected growers from a prefunded USD 0.5 billion compensation fund. Playbook includes roles (who authorizes destruction, who compensates, who communicates), timelines (response within 2 weeks of confirmed detection), and community/farmer notification procedures.

**Responsible Body/Role:** PMO (Programme Director and Surveillance/Incursion Response Coordinators, with Steering Council input)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Incursion Response Playbook (published)
- Eradication protocols and compensation procedures
- Response-trigger decision matrix

**Dependencies:**

- Steering Council approved incursion-response doctrine (eradication-first)
- Compensation fund amount confirmed (USD 0.5B estimate)

### 37. PMO Workstream Coordinator for Breeding (Resistance Breeding Pathway) hires the Breeding Programme Director (senior Hevea breeder from national research institute or CGIAR center) by Month 3 (2027-01-12). Breeding Director establishes breeding objectives: cultivar yield ≥90% of elite clones, ≥3 stacked resistance sources, lesion size ≤5mm, defoliation ≤20%, durability testing at 10x field-typical inoculum load.

**Responsible Body/Role:** PMO (Breeding Workstream Coordinator, with Steering Council approval of Director hire)

**Suggested Timeframe:** Month 3 (2027-01-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Breeding Programme Director hired
- Breeding objectives and cultivar-selection criteria published and pre-registered with Technical Advisory Group

**Dependencies:**

- PMO staffing authorized by Steering Council
- Budget allocated for breeding programme (estimated USD 0.4B for 25 years)

### 38. Breeding Programme Director, with regional Deputy Directors for Brazil, Thailand/Southeast Asia, and Cote d'Ivoire/West Africa (hired by Month 9, 2027-07-12), establishes standardized multi-site trial protocols and prepares 4 breeding stations (Brazil, Thailand, Malaysia/Indonesia, Côte d'Ivoire) for planting. Each site is responsible for independent trials using the same protocol, with identical disease-rating and yield-measurement standards.

**Responsible Body/Role:** Breeding Programme Director (with Regional Deputy Directors)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Breeding trial protocols finalized and published
- 4 breeding stations ready for planting by Month 12 (2027-10-12)
- Site managers and data-collection teams in place

**Dependencies:**

- Breeding Programme Director and Regional Deputies hired
- ABS agreements with Brazil executed (to enable germplasm transfer)
- Trial sites confirmed and prepared

### 39. Breeding Programme Director plants trials at all 4 sites (Brazil, Thailand, Malaysia/Indonesia, Côte d'Ivoire) by Month 12 (2027-10-12). Trials cross multiple Amazonian Hevea resistance sources into high-yield Asian clones, using polygenic marker-assisted and genomic selection. First data (nursery observations) available by Month 24 (2028-10-12); first 3-year field data by Month 48 (2030-10-12); full 6-year data by Month 84 (2033-10-12).

**Responsible Body/Role:** Breeding Programme Director (with site managers at 4 locations)

**Suggested Timeframe:** Month 12 (2027-10-12) - planting target

**Key Outputs/Deliverables:**

- Trials planted at all 4 sites by Month 12 (2027-10-12)
- Nursery data compilation begins Month 24 (2028-10-12)
- First full-cycle field data available by Month 84 (2033-10-12) for Year 7 gate

**Dependencies:**

- Trial sites prepared and staffed
- ABS agreements enable germplasm transfer
- Breeding protocols finalized

### 40. Breeding Programme Director establishes a breeding data repository with redundant backup and version control. Data includes yield measurements, disease ratings, resistance-gene validation (molecular), multi-site comparisons, and cultivar-selection documentation. Repository is accessible to the independent auditor and Compliance & Ethics Committee for audits. Repository operational by Month 12 (2027-10-12).

**Responsible Body/Role:** Breeding Programme Director (with Data Steward support)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Breeding data repository established with 50-year preservation capability
- Access protocols defined for auditors and compliance teams

**Dependencies:**

- PMO data infrastructure established
- Data Steward role assigned (Programme-wide)

### 41. PMO Workstream Coordinator for ABS (led by Compliance & Ethics Committee ABS Specialist) negotiates bilateral access-and-benefit-sharing agreements with Brazil's national competent authority (CGen) and at least 3 major indigenous or traditional-community groupings in the Amazon. Agreements specify: collection protocols for Hevea germplasm, downstream partner transfers, benefit-sharing terms (USD 1-5 per hectare, estimate, paid on commercial cultivar deployment), royalty-free seed for smallholders, and open-access genomic sequences for non-commercial research.

**Responsible Body/Role:** ABS Specialist (Compliance & Ethics Committee) with PMO support

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Bilateral ABS agreement with Brazil CGen executed
- ABS agreements with at least 3 Amazonian community groupings signed
- Benefit-sharing payment schedule established (first payment trigger at cultivar deployment)

**Dependencies:**

- ABS legal counsel hired (by Month 1, 2026-11-12)
- Community consultation completed
- Budget allocated for ABS agreements and benefit-sharing (USD 15M estimate)

### 42. ABS Specialist and Compliance & Ethics Committee establish a community-governed germplasm and data trust, with seats for indigenous and traditional-community representatives. Trust co-owns resistance discoveries and participates in benefit-sharing decisions. Trust bylaws and operational procedures published by Month 12 (2027-10-12).

**Responsible Body/Role:** ABS Specialist (Compliance & Ethics Committee)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Community-Governed Germplasm and Data Trust established
- Trust governance bylaws published
- Community representatives confirmed and trained

**Dependencies:**

- ABS agreements executed
- Community consultation process completed

### 43. PMO Programme Director (with Steering Council approval) hires a Data Steward responsible for all programme data governance across 25 years. Data Steward publishes a programme Data Governance Framework by Month 6 (2027-04-12), clarifying ownership, access, publication timing and IP rules for: pre-competitive data (released openly within 12 months), commercial data (shared under confidentiality agreements, publication 12 months post-gate), and benefit-sharing data (published annually).

**Responsible Body/Role:** Programme Director (recruiting Data Steward by Month 1, 2026-11-12)

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Data Steward position established and filled
- Programme Data Governance Framework published (Month 6, 2027-04-12)

**Dependencies:**

- Steering Council approved data governance as a governance priority

### 44. Data Steward (Programme-wide) implements a secure digital data repository with 50-year preservation capability, version control, redundant backup, and access protocols for auditors and compliance teams. Repository is operational by Month 6-12 (2027-04-12 to 2027-10-12).

**Responsible Body/Role:** Data Steward

**Suggested Timeframe:** Month 3 (2027-01-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Digital data repository operational with 50-year preservation
- Access protocols documented and auditor/compliance-team access granted

**Dependencies:**

- Data Steward hired
- Data Governance Framework published

### 45. PMO Workstream Coordinator for Alternative Crops (Guayule and Russian Dandelion) designs multi-region pilot farms and processing demonstrations. Pilot farms: Guayule 100-500 ha in Arizona/New Mexico/Coahuila, dandelion 100-300 ha in Germany/Netherlands/Belgium. Pilot processing plants: Guayule 2,000-5,000 t/year extraction facility; dandelion 1,000-3,000 t/year facility. Siting studies complete by Month 6-9 (2027-04-12 to 2027-07-12); site preparation and farm planting Months 6-12 (2027-04-12 to 2027-10-12).

**Responsible Body/Role:** PMO (Alternative Crops Workstream Coordinator, recruited by Month 6 = 2027-04-12)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 24 (2028-10-12 to 2028-10-12)

**Key Outputs/Deliverables:**

- Alternative crop siting study completed
- Pilot farm sites prepared and first plantings by Month 12 (2027-10-12)
- Pilot processing plants commissioned by Month 24 (2028-10-12)

**Dependencies:**

- Alternative Crop Portfolio Breadth decision confirmed (Guayule + Russian dandelion)
- Climate-risk siting analysis completed
- Budget allocated for pilots and processing (USD 0.2B estimate)

### 46. PMO Alternative Crops Workstream runs parallel tire-performance qualification trials of Guayule and dandelion rubber at independent test laboratories, Months 12-48 (2027-10-12 to 2030-10-12). Trials evaluate tread wear, durability, grip and other OEM specifications. Results are shared with tire makers to support OEM offtake agreements.

**Responsible Body/Role:** PMO (Alternative Crops Workstream Coordinator, with OEM engagement team)

**Suggested Timeframe:** Month 12 (2027-10-12) to Month 48 (2030-10-12 to 2030-10-12)

**Key Outputs/Deliverables:**

- Tire-qualification trial protocols established
- Test results (tread wear, durability, grip, quality variance) published by Month 48 (2030-10-12)

**Dependencies:**

- Pilot processing plants operational by Month 24 (2028-10-12)
- OEM engagement initiated (Month 3, 2027-01-12)

### 47. PMO Programme Director (with Steering Council authorization) initiates direct engagement with the top 10 tire makers by Month 3 (2027-01-12). Steering Council establishes an OEM Steering Committee that meets quarterly. Goal: secure non-binding letters of intent for offtake trials by Month 12 (2027-10-12).

**Responsible Body/Role:** Programme Director (with Steering Council OEM representatives and OEM Engagement Lead)

**Suggested Timeframe:** Month 3 (2027-01-12) - engagement initiated; Month 12 (2027-10-12) - letters of intent target

**Key Outputs/Deliverables:**

- OEM Steering Committee established and charter published
- Letters of intent from at least 8 of top-10 OEMs for offtake trials (by Month 12, 2027-10-12)

**Dependencies:**

- Steering Council authorized OEM engagement
- Alternative crop portfolio strategy confirmed

### 48. PMO (with OEM Steering Committee input) structures long-term offtake agreements using tiered purchase-option contracts. Tier 1: OEMs pay 1-2% (estimate) annual reservation fee for priority access to alternative-rubber volumes. Tier 2: optional purchase at price formula indexed to Hevea benchmark + 10-15% premium (estimate), with quality-gate thresholds. Tier 3: shared quality-failure risk (50% producer, 50% OEM). Contracts negotiated and signed Months 48-60 (2030-10-12 to 2031-10-12), based on pilot-processing and tire-qualification results.

**Responsible Body/Role:** PMO (OEM Engagement Lead, with Alternative Crops Workstream Coordinator)

**Suggested Timeframe:** Month 48 (2030-10-12) to Month 60 (2031-10-12 to 2031-10-12)

**Key Outputs/Deliverables:**

- Tiered purchase-option contracts drafted
- Contracts signed with at least 8 OEMs by Month 60 (2031-10-12)

**Dependencies:**

- Pilot processing and tire-qualification results available by Month 48 (2030-10-12)
- OEM letters of intent secured

### 49. PMO (Alternative Crops Workstream) monitors alternative-rubber cost and quality performance against pre-registered KPI waypoints: Month 36 (2029-10-12) feedstock yield and extraction efficiency; Month 48 (2030-10-12) feedstock cost (Guayule ≤USD 1.20/kg dry matter, dandelion ≤USD 1.00/kg) and extraction yield (≥85% Guayule, ≥80% dandelion); Month 60 (2031-10-12) processing cost (≤USD 2.50/kg) and quality variance (±10%). If targets are missed by Month 60 (2031-10-12), trigger portfolio decision: increased processing-innovation capital or redirect funds to resistant-Hevea breeding.

**Responsible Body/Role:** PMO (Alternative Crops Workstream Coordinator and Technical Advisory Group)

**Suggested Timeframe:** Months 36, 48, 60 (2029-10-12, 2030-10-12, 2031-10-12) - checkpoint milestones

**Key Outputs/Deliverables:**

- KPI monitoring dashboard (quarterly updates)
- Cost and quality assessment reports at Months 36, 48, 60 (2029-10-12, 2030-10-12, 2031-10-12)
- Portfolio decision (Month 60 = 2031-10-12) to continue or re-scope alternative crops

**Dependencies:**

- Pre-registered KPI definitions finalized
- Pilot plants operational and producing data by Month 24 (2028-10-12)

### 50. PMO Programme Director establishes the Smallholder Transition Finance and Extension Corps as a separate, locally-owned delivery system. Recruits 500 lead extension agents across the 5 major producing countries (100-200 agents per country) by Month 12 (2027-10-12). Each agent serves 200-500 eligible smallholders. Establishes 50-100 certified small-scale nurseries per major country for clean-plant propagation. Creates income-bridging finance programme: concessional replant loans + income-support payments during immature period (6-10 years).

**Responsible Body/Role:** PMO (Smallholder Delivery Workstream Coordinator, recruited by Month 6 = 2027-04-12)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 24 (2028-10-12 to 2028-10-12)

**Key Outputs/Deliverables:**

- 500 lead extension agents trained and deployed by Month 12 (2027-10-12)
- At least 250 certified nurseries established (50+ per major country)
- Smallholder Transition Finance programme design (loans, income support, repayment terms)
- Mobile-based extension platform operational

**Dependencies:**

- PMO staffing complete
- Budget allocated for extension corps (USD 400M protected 25-year stream)
- Replant finance budget available (USD 6.75B for 45% uptake)

### 51. PMO (Smallholder Delivery Workstream) launches clean-plant network certification and inspection programme. Sets standards for nursery lot-size, isolation distance, inspected-planting protocols, and disease-free certification. Coordinates with Containment Protocol Authority to align inspection frequencies (target: 100,000 inspected lots/year by Month 12, 2027-10-12) and compliance certificates.

**Responsible Body/Role:** PMO (Smallholder Delivery Workstream) with Containment Protocol Authority

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 18 (2028-04-12 to 2028-04-12)

**Key Outputs/Deliverables:**

- Clean-plant network certification standards published
- Nursery audit and lot-inspection protocols defined
- 100,000+ inspected lots/year achieved by Month 12 (2027-10-12)

**Dependencies:**

- Containment Protocol Authority compliance-inspection SOP finalized
- 100+ compliance inspectors trained and deployed

### 52. PMO (Smallholder Delivery Workstream) designs and operationalizes the income-bridging finance instrument. Offers concessional replant loans through national agricultural banks at preferential rates, paired with clean-plant nursery vouchers and extension visits. Repayment begins after first tapping (6-10 years post-replanting). For poorest smallholders, income-support payments funded by programme levy or reserve. Default and arrears risks managed through group-guarantee mechanisms and technical-support incentives.

**Responsible Body/Role:** PMO (Smallholder Delivery Workstream and Finance Manager)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 18 (2028-04-12 to 2028-04-12)

**Key Outputs/Deliverables:**

- Smallholder Transition Finance operational manual published
- Loan and income-support disbursement processes live by Month 18 (2028-04-12)
- First tranche of replant finance approved and disbursed to pilot smallholder groups

**Dependencies:**

- National agricultural banks engaged and committed to participate
- Budget for replant finance approved (USD 6.75B for 45% uptake)

### 53. PMO Programme Director establishes quarterly KPI-tracking meetings, beginning Month 12 (2027-10-12). Workstream Coordinators report on milestones, risk status, and gate-readiness against pre-registered KPI definitions. Dashboard is compiled by PMO Finance Manager and presented to Steering Council and Compliance & Ethics Committee.

**Responsible Body/Role:** PMO Finance Manager and Programme Director

**Suggested Timeframe:** Monthly reviews within PMO; quarterly briefings to Steering Council starting Month 12 (2027-10-12)

**Key Outputs/Deliverables:**

- Monthly KPI tracking dashboard (internal PMO)
- Quarterly KPI summary for Steering Council (published)

**Dependencies:**

- PMO staffing complete
- Budget and KPI tracking systems operational

### 54. PMO and Containment Protocol Authority, in coordination with national plant-protection agencies, plan and execute red-team drills to test the SALB protocol's enforcement effectiveness. Red-team drills simulate unauthorized movement of potentially contaminated material through nurseries, borders and ports, testing detection speed and response procedures. Drills conducted Months 18-36 (2028-04-12 to 2029-10-12) in at least 3 producing countries; results published and inform Month 36 (2029-10-12) gate assessment.

**Responsible Body/Role:** Containment Protocol Authority (Compliance Inspection team) with PMO and national agencies

**Suggested Timeframe:** Months 18-36 (2028-04-12 to 2029-10-12) - at least 3 drills, one per major region

**Key Outputs/Deliverables:**

- Red-team drill plans and protocols (published Months 12-18 = 2027-10-12 to 2028-04-12)
- Red-team drill results and compliance findings (Months 18-36 = 2028-04-12 to 2029-10-12)
- Corrective action reports for any detected enforcement gaps

**Dependencies:**

- Compliance-inspection network established and trained
- Nursery certification systems operational
- Surveillance systems ready for detection testing

### 55. Independent Auditor, 6 months before Month 36 (2029-10-12) gate (by Month 30, 2029-04-12), requests gate-readiness submission from PMO. PMO compiles: IPPC adoption vote status, producer-nation binding regulatory embedding status, inspector deployment and inspection data (100,000+ lots), red-team drill results (≥95% detection accuracy), surveillance network operational status, no unmanaged SALB incursions. Auditor conducts field visits and database audits Months 30-36 (2029-04-12 to 2029-10-12).

**Responsible Body/Role:** PMO (with input from all workstreams) and Independent Auditor

**Suggested Timeframe:** Month 30 (2029-04-12) - PMO submits gate-readiness report; Months 30-36 (2029-04-12 to 2029-10-12) - Auditor conducts audits

**Key Outputs/Deliverables:**

- Gate-readiness report submitted to Independent Auditor (Month 30, 2029-04-12)
- Auditor field audits and data verification Months 30-36 (2029-04-12 to 2029-10-12)
- Auditor gate-closure report issued (by Month 35.5, 2029-09-27, estimate)

**Dependencies:**

- Pre-registered audit scope for Month 36 (2029-10-12) gate finalized (by Month 6, 2027-04-12)
- All Phase 1 activities on track and documented

### 56. Independent Auditor issues Month 36 (2029-10-12) gate-closure verdict 30 days before gate date (by Month 35.5, 2029-09-27 estimate). Verdict states: IPPC adoption vote held and passed; binding national embedding in at least 3 of top-5 producers confirmed; 100+ inspectors deployed and active; 100,000+ nursery lots inspected; red-team drills ≥95% detection accuracy; zero unmanaged SALB incursions documented. Verdict is PASS, CONDITIONAL, or FAIL, with confidence level and any dissenting findings.

**Responsible Body/Role:** Independent Auditor

**Suggested Timeframe:** Month 35.5 (2029-09-27) - verdict issued (30 days before gate)

**Key Outputs/Deliverables:**

- Month 36 (2029-10-12) gate-closure verdict (published within 30 days of audit completion)

**Dependencies:**

- Auditor field audits and data verification complete

### 57. Steering Council, upon receipt of Independent Auditor verdict on Month 36 (2029-10-12) gate (by Month 35.5, 2029-09-27), reviews verdict and authorizes Year 3 tranche release (USD 7.0B). If verdict is CONDITIONAL (partial gate achievement), releases minimum 80% of planned tranche (USD 5.6B). If FAIL, withholds and convenes Steering Council emergency meeting to determine remedial action. Tranche is disbursed within 45 days of gate passage (by Month 36.75, 2029-11-04 estimate).

**Responsible Body/Role:** Steering Council

**Suggested Timeframe:** Month 36 (2029-10-12) - gate deadline; tranche released within 45 days (by Month 36.75 = 2029-11-04)

**Key Outputs/Deliverables:**

- Steering Council decision minute on gate passage and tranche release
- Year 3 tranche (USD 7.0B or minimum 80%) disbursed by Month 36.75 (2029-11-04)

**Dependencies:**

- Independent Auditor gate verdict received
- Steering Council meeting convened within 5 days of verdict

### 58. Steering Council, during Phase 2 (Months 36-84, 2029-10-12 to 2033-10-12), oversees continued execution of all four pillars: containment protocol enforcement (quarterly compliance reporting), breeding-trial data compilation (interim reports at Months 48, 72 = 2030-10-12, 2032-10-12), alternative-crop processing pilots and tire qualifications, and smallholder adoption (quarterly extension and nursery metrics). Escalations from PMO are reviewed monthly; risk register is updated quarterly.

**Responsible Body/Role:** Steering Council (with PMO input)

**Suggested Timeframe:** Months 36-84 (2029-10-12 to 2033-10-12) - ongoing governance

**Key Outputs/Deliverables:**

- Quarterly steering updates to Council (protocol, breeding, alternatives, smallholder status)
- Risk register updates and mitigation tracking
- Decision minutes on escalations and strategic adjustments

**Dependencies:**

- Phase 1 successfully completed (Month 36 = 2029-10-12 gate passed)
- Year 3 tranche (USD 7.0B) being deployed

### 59. Breeding Programme Director, at Month 48 (2030-10-12), compiles interim breeding-trial data and conducts a formal yield-penalty assessment. If yield penalty (cultivar yield minus elite-clone yield) exceeds 15% (i.e., cultivar yield <85% of elite), escalate to Steering Council for pathway decision: continue conventional breeding, or initiate crown-budding fast-track (fallback option, USD 0.25B estimate, fits within unallocated budget). Decision made by Month 54 (2031-04-12).

**Responsible Body/Role:** Breeding Programme Director (with Steering Council and Technical Advisory Group consultation)

**Suggested Timeframe:** Month 48 (2030-10-12) - interim data review; Month 54 (2031-04-12) - pathway decision

**Key Outputs/Deliverables:**

- Interim breeding-trial report at Month 48 (2030-10-12)
- Yield-penalty assessment and pathway decision (if needed) by Month 54 (2031-04-12)

**Dependencies:**

- 3-year field trial data available from all 4 sites

### 60. Breeding Programme Director, if pathway decision is to proceed with crown-budding fast-track (triggered by yield penalties >15% at Month 48 = 2030-10-12), initiates a separate, time-compressed crown-budding programme. Crown-budding uses existing elite clones with grafted resistant canopies to deliver field protection years before fully bred cultivars are ready. Crown-budding programme adds USD 0.25B budget (estimate, fits within unallocated balance) and could compress Year 7 cultivar timeline by 2-3 years. Decision and authorization by Steering Council by Month 54 (2031-04-12).

**Responsible Body/Role:** Breeding Programme Director and Steering Council

**Suggested Timeframe:** Month 54 (2031-04-12) - decision point if triggered by Month 48 (2030-10-12) yield-penalty assessment

**Key Outputs/Deliverables:**

- Crown-budding programme design and budget (if initiated)
- Steering Council decision minute authorizing fallback pathway

**Dependencies:**

- Month 48 (2030-10-12) interim yield-penalty assessment shows deficit >15%

### 61. Breeding Programme Director initiates second-generation cultivar breeding by Month 60 (2031-10-12) using different resistance sources than the first-generation cultivars targeted for Year 7 release. Second-generation cultivars will be ready by Month 120 (2036-10-12) if first-generation cultivars show early durability breakdown post-release.

**Responsible Body/Role:** Breeding Programme Director

**Suggested Timeframe:** Month 60 (2031-10-12) - initiation; Month 120 (2036-10-12) - target readiness

**Key Outputs/Deliverables:**

- Second-generation breeding programme launched (separate trial locations, different resistance sources)

**Dependencies:**

- First-generation trials progressing toward Year 7 gate

### 62. PMO (Alternative Crops Workstream), at Month 60 (2031-10-12), makes portfolio decision based on cost and quality KPI assessment: cost targets (feedstock and processing) achieved or only modestly missed → commit wave 1 commercial-plant capex (USD 1.6B, 4 Guayule + 4 dandelion plants). Targets significantly missed → redirect capital to processing-innovation R&D or accelerate resistant-Hevea breeding allocation. Decision documented and approved by Steering Council by Month 66 (2032-04-12).

**Responsible Body/Role:** PMO (Alternative Crops Workstream) with Steering Council

**Suggested Timeframe:** Month 60 (2031-10-12) - assessment; Month 66 (2032-04-12) - decision

**Key Outputs/Deliverables:**

- Alternative-crop cost and quality assessment report (Month 60 = 2031-10-12)
- Portfolio decision documentation and Steering Council approval (by Month 66 = 2032-04-12)

**Dependencies:**

- Pilot processing plants and tire-qualification trials completed and documented

### 63. Breeding Programme Director, at Month 72 (2032-10-12), compiles final cultivar-selection data from all 4 trial sites (6-year field data now available from Month 12 = 2027-10-12 plantings in 2027). Assesses yield against elite clones, resistance stacking, durability signals, and multi-site consistency. Selects final cultivar candidates for Year 7 gate release. Cultivar-selection documentation is submitted to Independent Auditor by Month 78 (2033-04-12) (6 months before Month 84 = 2033-10-12 gate).

**Responsible Body/Role:** Breeding Programme Director (with Technical Advisory Group and Compliance & Ethics Committee data-integrity oversight)

**Suggested Timeframe:** Month 72 (2032-10-12) - cultivar selection completed; Month 78 (2033-04-12) - evidence submitted to auditor

**Key Outputs/Deliverables:**

- Cultivar selection report at Month 72 (2032-10-12)
- Gate-readiness evidence package submitted to auditor (Month 78, 2033-04-12)
- All breeding-trial data validated for auditor review

**Dependencies:**

- 6-year field trial data available from all 4 sites

### 64. Independent Auditor, 6 months before Month 84 (2033-10-12) gate (by Month 78, 2033-04-12), receives gate-readiness submission from PMO. PMO compiles: cultivar yield data (≥90% of elite = pass), ≥3 stacked independent resistance sources confirmed at 5+ trial sites, lesion size and defoliation within thresholds, durability evidence from sentinel plantings and high-inoculum testing. Auditor conducts field audits of all 4 breeding sites and database verification Months 78-84 (2033-04-12 to 2033-10-12).

**Responsible Body/Role:** PMO (Breeding Workstream) and Independent Auditor

**Suggested Timeframe:** Month 78 (2033-04-12) - submission; Months 78-84 (2033-04-12 to 2033-10-12) - audits

**Key Outputs/Deliverables:**

- Year 7 gate-readiness report submitted to auditor (Month 78 = 2033-04-12)
- Auditor field audits and data verification at 4 breeding sites (Months 78-84 = 2033-04-12 to 2033-10-12)
- Auditor gate-closure report issued (by Month 83.5, 2033-09-27 estimate)

**Dependencies:**

- Cultivar selection completed and documented (Month 72 = 2032-10-12)
- Breeding-trial data repository fully documented and accessible

### 65. Independent Auditor issues Month 84 (2033-10-12) gate-closure verdict 30 days before gate date (by Month 83.5, 2033-09-27 estimate). Verdict assesses: cultivar yield ≥90% of elite clones (PASS), 90-95% (CONDITIONAL), <90% (FAIL); ≥3 independent resistance sources stacked and confirmed; lesion size ≤5mm and defoliation ≤20%; durability testing evidence from sentinel plantings. Verdict is PASS, CONDITIONAL, or FAIL.

**Responsible Body/Role:** Independent Auditor

**Suggested Timeframe:** Month 83.5 (2033-09-27) - verdict issued

**Key Outputs/Deliverables:**

- Month 84 (2033-10-12) gate-closure verdict (published)

**Dependencies:**

- Auditor field audits and data verification complete

### 66. Steering Council, upon receipt of Independent Auditor verdict on Month 84 (2033-10-12) gate (by Month 83.5, 2033-09-27), reviews verdict and authorizes Year 7 tranche release (USD 6.5B). If verdict is CONDITIONAL, releases minimum 80% (USD 5.2B). If FAIL, escalates to Adjudication Panel for expert mediation or withhold tranche pending remedial breeding action. Tranche is disbursed within 45 days of gate passage (by Month 84.75, 2033-11-04 estimate).

**Responsible Body/Role:** Steering Council

**Suggested Timeframe:** Month 84 (2033-10-12) - gate deadline; tranche released within 45 days (by Month 84.75 = 2033-11-04)

**Key Outputs/Deliverables:**

- Steering Council decision minute on Year 7 gate passage
- Year 7 tranche (USD 6.5B or minimum 80%) disbursed by Month 84.75 (2033-11-04)

**Dependencies:**

- Independent Auditor gate verdict received
- Steering Council meeting convened and voted on gate passage

### 67. PMO (Smallholder Delivery Workstream), at Month 84 (2033-10-12), assesses smallholder adoption progress against waypoint targets: at least 30% of eligible smallholders enrolled in clean-plant/extension network (proposed threshold). Conduct farmer surveys to confirm uptake rates, clean-plant usage, and income-bridging-finance utilization. If enrollment is below 30%, trigger stop/re-scope decision by Month 90 (2034-04-12): increase extension and finance resources, or reduce Year 7-12 smallholder acreage targets.

**Responsible Body/Role:** PMO (Smallholder Delivery Workstream)

**Suggested Timeframe:** Month 84 (2033-10-12) - assessment; Month 90 (2034-04-12) - decision

**Key Outputs/Deliverables:**

- Smallholder adoption assessment report (Month 84 = 2033-10-12)
- Decision on smallholder uptake targets and resource allocation (by Month 90 = 2034-04-12)

**Dependencies:**

- Extension corps and nurseries operational since Month 12 (2027-10-12)
- Replant finance disbursement ongoing

### 68. PMO and Steering Council, if Month 84 (2033-10-12) breeding gate is PASS or CONDITIONAL, authorize the release of resistant cultivars to seed producers and nurseries. Certified clones are multiplied at licensed nurseries and made available to smallholders through the clean-plant network. Cultivar distribution accelerates Months 90-120 (2034-04-12 to 2036-10-12), targeting 40%+ smallholder-area replanting by Month 144 (2038-10-12).

**Responsible Body/Role:** PMO (Breeding and Smallholder Delivery Workstreams) with Steering Council authorization

**Suggested Timeframe:** Month 84 (2033-10-12) - cultivar release authorized; Months 90-120 (2034-04-12 to 2036-10-12) - multiplication and distribution

**Key Outputs/Deliverables:**

- Certified cultivar clones released to seed producers (Month 90, 2034-04-12)
- Nurseries begin clone multiplication and distribution to smallholders

**Dependencies:**

- Month 84 (2033-10-12) breeding gate passed (PASS or CONDITIONAL)
- Nursery capacity and clean-plant-network infrastructure in place

### 69. PMO (Alternative Crops Workstream), between Months 84-120 (2033-10-12 to 2036-10-12), executes wave 1 commercial-plant construction (if Month 60 = 2031-10-12 portfolio decision was to proceed). Wave 1 includes 4 commercial plants: 2 Guayule + 2 dandelion, each 5,000 t/year nameplate. Final investment decisions (FIDs) at Month 72 (2032-10-12); construction Months 84-108 (2033-10-12 to 2035-10-12); commissioning and ramp-up Months 96-120 (2034-10-12 to 2036-10-12).

**Responsible Body/Role:** PMO (Alternative Crops Workstream) with OEM partners and processing contractors

**Suggested Timeframe:** Month 72 (2032-10-12) - FID; Months 84-108 (2033-10-12 to 2035-10-12) - construction; Months 96-120 (2034-10-12 to 2036-10-12) - commissioning

**Key Outputs/Deliverables:**

- Wave 1 plant FID and financing closed (Month 72 = 2032-10-12)
- Plant construction contracts awarded (Months 72-84 = 2032-10-12 to 2033-10-12)
- First plant commissioned (Month 96-108 = 2034-10-12 to 2035-10-12)
- Wave 1 plants at full capacity by Month 120 (2036-10-12) producing 16,000 t/year

**Dependencies:**

- Month 60 (2031-10-12) portfolio decision to proceed with plants
- OEM offtake agreements signed (Months 48-60 = 2030-10-12 to 2031-10-12)
- Pilot processing results show viable cost and quality

### 70. Compliance & Ethics Committee, throughout Months 0-120 (2026-10-12 to 2036-10-12), conducts quarterly compliance audits and investigations. Audits include: breeding-trial data integrity at all 4 sites (annual external validators), benefit-sharing compliance (community payments tracked and verified), smallholder-finance fraud detection (2,000+ farmer audits annually per major country), alternative-crop environmental safeguards (land-tenure verification, water-stress monitoring), and anti-corruption whistleblower investigations.

**Responsible Body/Role:** Compliance & Ethics Committee (all members)

**Suggested Timeframe:** Ongoing quarterly; annual in-depth audits; investigations triggered by reports

**Key Outputs/Deliverables:**

- Quarterly compliance summary reports to Steering Council
- Annual comprehensive audit report (published)
- Investigation closures and remedial-action tracking

**Dependencies:**

- Compliance & Ethics Committee fully staffed
- Code of Conduct and anti-corruption policies active

### 71. Independent Auditor, 6 months before Month 144 (2038-10-12) gate (by Month 138, 2038-04-12), receives gate-readiness submission from PMO. PMO compiles: alternative-rubber delivered cost (target <30% above Hevea benchmark), processing volumes (16,000 t/year from wave 1 plants), quality consistency, OEM offtake contracts in place, smallholder adoption levels (target ≥40% of eligible area), resistant-cultivar acreage deployed and early durability performance. Auditor conducts field audits Months 138-144 (2038-04-12 to 2038-10-12).

**Responsible Body/Role:** PMO (all workstreams) and Independent Auditor

**Suggested Timeframe:** Month 138 (2038-04-12) - submission; Months 138-144 (2038-04-12 to 2038-10-12) - audits

**Key Outputs/Deliverables:**

- Year 12 gate-readiness report submitted (Month 138 = 2038-04-12)
- Auditor gate-closure report (by Month 143.5, 2038-09-27 estimate)

**Dependencies:**

- All Phase 2 and Phase 3 activities substantially complete

### 72. Independent Auditor issues Month 144 (2038-10-12) gate-closure verdict 30 days before gate date (by Month 143.5, 2038-09-27 estimate). Verdict assesses: alternative-rubber delivered cost <30% above Hevea (PASS), 30-35% (CONDITIONAL), ≥35% (FAIL); wave 1 plants operational and producing at design volumes; OEM offtake active; smallholder adoption ≥40% of eligible area; resistant-cultivar acreage and early durability performance acceptable.

**Responsible Body/Role:** Independent Auditor

**Suggested Timeframe:** Month 143.5 (2038-09-27) - verdict issued

**Key Outputs/Deliverables:**

- Month 144 (2038-10-12) gate-closure verdict (published)

**Dependencies:**

- Auditor field audits complete

### 73. Steering Council, upon receipt of Independent Auditor verdict on Month 144 (2038-10-12) gate (by Month 143.5, 2038-09-27), reviews verdict and authorizes Year 12 tranche release (USD 4.5B). If verdict is CONDITIONAL, releases minimum 80% (USD 3.6B). If FAIL, considers contingent-facility activation or deferred capital reallocation. Tranche is disbursed within 45 days (by Month 144.75, 2038-11-04 estimate).

**Responsible Body/Role:** Steering Council

**Suggested Timeframe:** Month 144 (2038-10-12) - gate deadline; tranche released within 45 days (by Month 144.75 = 2038-11-04)

**Key Outputs/Deliverables:**

- Steering Council decision on Year 12 gate passage
- Year 12 tranche (USD 4.5B or minimum 80%) disbursed by Month 144.75 (2038-11-04)

**Dependencies:**

- Independent Auditor verdict received

### 74. Steering Council, if Month 144 (2038-10-12) gate is PASS or CONDITIONAL, authorizes wave 2 commercial-plant development (Months 156-180, 2039-10-12 to 2041-10-12). Wave 2 adds 4 more plants (2 Guayule, 2 dandelion). FIDs scheduled for Month 144 (2038-10-12); construction Months 156-180 (2039-10-12 to 2041-10-12); commissioning Months 180-192 (2041-10-12 to 2042-10-12); target 32,000 t/year total volume by Month 192 (2042-10-12).

**Responsible Body/Role:** Steering Council and PMO (Alternative Crops Workstream)

**Suggested Timeframe:** Month 144 (2038-10-12) - FID approval; Months 156-180 (2039-10-12 to 2041-10-12) - construction; Months 180-192 (2041-10-12 to 2042-10-12) - commissioning

**Key Outputs/Deliverables:**

- Wave 2 plant FID and financing authorized and closed
- Wave 2 plants commissioned by Month 192 (2042-10-12)
- Total alternative-rubber capacity 32,000 t/year by Month 192 (2042-10-12)

**Dependencies:**

- Month 144 (2038-10-12) gate PASS or CONDITIONAL
- Wave 1 plants operational and profitable (or within acceptable loss tolerance)

### 75. Breeding Programme Director, from Month 84 onward (2033-10-12 onward), establishes and monitors post-release resistance durability. Sentinel plantings of released cultivars are planted in high-SALB-inoculum zones and exposed to natural and artificial pathogen variants. Quarterly durability monitoring from Month 84-216 (2033-10-12 to 2044-10-12) detects early signs of resistance breakdown. If breakdown is detected by Month 120-144 (2036-10-12 to 2038-10-12), trigger breeding of replacement cultivars with alternate resistance sources.

**Responsible Body/Role:** Breeding Programme Director

**Suggested Timeframe:** Month 84 onward (2033-10-12 onward) - monitoring through Month 216 (2044-10-12) and beyond

**Key Outputs/Deliverables:**

- Sentinel plantings established in high-inoculum zones (Month 90-120 = 2034-04-12 to 2036-10-12)
- Quarterly durability monitoring reports (Month 84+)
- Durability-breakdown alerts (if detected) escalated to Steering Council

**Dependencies:**

- Resistant cultivars released and deployed post-Year 7 gate

### 76. Containment Protocol Authority, throughout Months 36-216 (2029-10-12 to 2044-10-12), enforces compliance with the SALB protocol. Quarterly compliance reporting includes: share of nurseries under certified inspection, share of nursery material moved under certified chain-of-custody, compliance violations detected and penalties enforced, protocol amendment tracking. Annual compliance audits verify inspector performance and data quality.

**Responsible Body/Role:** Containment Protocol Authority (Compliance and Enforcement Manager)

**Suggested Timeframe:** Ongoing from Month 36 (2029-10-12) through Month 216 (2044-10-12) and beyond

**Key Outputs/Deliverables:**

- Quarterly compliance reports to Steering Council
- Annual compliance and enforcement audit
- Penalty enforcement documentation

**Dependencies:**

- Protocol adopted by IPPC (Month 36 = 2029-10-12 gate)
- Compliance-inspection network operational

### 77. Independent Auditor, 6 months before Month 216 (2044-10-12) gate (by Month 210, 2044-04-12), receives gate-readiness submission from PMO. PMO compiles: final containment performance (verified incursion-free or contained within tolerance), resistant-cultivar acreage and durability track record (Years 7-18), alternative-rubber supply volumes (32,000 t/year from waves 1-2), long-term cost and quality metrics, smallholder adoption final status, climate-resilience evidence. Auditor conducts final comprehensive assessment Months 210-216 (2044-04-12 to 2044-10-12).

**Responsible Body/Role:** PMO (all workstreams) and Independent Auditor

**Suggested Timeframe:** Month 210 (2044-04-12) - submission; Months 210-216 (2044-04-12 to 2044-10-12) - audits

**Key Outputs/Deliverables:**

- Year 18 gate-readiness report (Month 210 = 2044-04-12)
- Auditor final gate-closure report (by Month 215.5, 2044-09-27 estimate)

**Dependencies:**

- All 25-year programme activities documented and verified

### 78. Independent Auditor issues Month 216 (2044-10-12) gate-closure verdict 30 days before gate date (by Month 215.5, 2044-09-27 estimate). Verdict assesses long-term success: verified SALB containment maintained (no unmanaged spread); diversified parallel supply chains (resistant Hevea + alternative rubber) resilient to pathogen and climate shocks; smallholder livelihoods supported through adoption and price-stability mechanisms; programme institutional continuity sustained over 18 years.

**Responsible Body/Role:** Independent Auditor

**Suggested Timeframe:** Month 215.5 (2044-09-27) - verdict issued

**Key Outputs/Deliverables:**

- Month 216 (2044-10-12) gate-closure verdict (final) (published)

**Dependencies:**

- All 18-year programme period activities documented

### 79. Steering Council, upon receipt of Independent Auditor verdict on Month 216 (2044-10-12) gate (by Month 215.5, 2044-09-27), reviews verdict and authorizes Year 18 tranche release (USD 4.0B). This final tranche supports the programme's remaining 7 years (Months 216-300, 2044-10-12 to 2052-10-12) with continued smallholder support, surveillance, and alternative-crop operations. Tranche is disbursed within 45 days (by Month 216.75, 2044-11-04 estimate).

**Responsible Body/Role:** Steering Council

**Suggested Timeframe:** Month 216 (2044-10-12) - gate deadline; tranche released within 45 days (by Month 216.75 = 2044-11-04)

**Key Outputs/Deliverables:**

- Steering Council decision on Year 18 gate passage
- Year 18 tranche (USD 4.0B or minimum 80%) disbursed by Month 216.75 (2044-11-04)

**Dependencies:**

- Independent Auditor verdict received

### 80. Steering Council and PMO, in Phase 5 (Months 216-300, 2044-10-12 to 2052-10-12), transition the programme toward long-term operational sustainability. Key decisions include: wind-down of programme-dedicated structures (PMO, governance bodies) with transfer of ongoing functions to host institutions (FAO/IPPC for protocol, national research institutes for breeding, processing operators for alternative crops, cooperatives for smallholder networks); final audits and knowledge-transfer documentation; publication of 25-year programme outcomes and lessons-learned report.

**Responsible Body/Role:** Steering Council and Programme Director

**Suggested Timeframe:** Months 216-240 (2044-10-12 to 2046-10-12) - transition planning; Months 240-300 (2046-10-12 to 2052-10-12) - implementation

**Key Outputs/Deliverables:**

- Transition plan for programme wind-down and institutional handoff (published Month 216 = 2044-10-12)
- Knowledge-transfer documentation and archive (Months 216-240 = 2044-10-12 to 2046-10-12)
- Final 25-year programme outcomes report (Month 240 = 2046-10-12)
- Lessons-learned publication (Month 240 = 2046-10-12)

**Dependencies:**

- Month 216 (2044-10-12) gate PASS
- All governance bodies and operational systems mature and documented

# Decision Escalation Matrix

**Producer-Nation Regulatory Adoption Failure or Delay**
Escalation Level: Steering Council
Approval Process: Steering Council convenes within 5 days of notification; reviews the status of MoU commitments and binding national embedding progress. If fewer than 3 of the top-5 rubber-producing nations (Brazil, Indonesia, Thailand, Malaysia, Vietnam) have committed to binding adoption of the SALB Containment Protocol by the proposed Month 54 (2031-04-12) threshold, Council votes on stop/re-scope decision (supermajority ≥66% rule): proceed with partial producer base, extend adoption timeline by 12-24 months, or pivot to alternative protocol authority model. Written rationale and revised programme roadmap published within 30 days.
Rationale: The SALB Containment Protocol is the non-negotiable Phase 1 deliverable and precondition for all scale-up. Fewer than 3 binding producer commitments by Month 54 (2031-04-12) means the Month 36 (2029-10-12) gate's protocol-adoption criterion cannot be met and the entire stage-gate logic collapses. This risk exceeds PMO operational authority (USD 50M threshold); it is a strategic programme continuity decision.
Negative Consequences: If producer-nation adoption does not reach 3 of top-5 by Month 54 (2031-04-12), the Year 3 gate cannot be passed in full; funding tranche is withheld or released at minimum 80% (USD 5.6B instead of USD 7.0B). Phase 2 scale-up stalls; breeding trials and alternative-crop pilots lose containment mandate. Estimated cost: USD 1.5-3 billion in deferred and redirected capital; programme credibility and funder confidence erode; risk of SALB spread increases if protocol is not binding.

**Breeding-Cultivar Yield-Penalty Exceeds Threshold at Interim Checkpoint**
Escalation Level: Steering Council (with Technical Advisory Group and Resistance Breeding Oversight Group consultation)
Approval Process: At Month 48 (2030-10-12), Breeding Programme Director submits interim cultivar-yield data from all 4 trial sites. If cultivar yield is below 85% of elite clones (yield penalty >15%, the proposed threshold), Breeding Coordinator escalates to Steering Council within 5 days. Council convenes by Month 54 (2031-04-12) to decide: (1) continue conventional polygenic breeding and accept lower yield (potentially missing Year 7 gate), (2) initiate crown-budding fast-track fallback (USD 0.25B, fits unallocated balance, compresses timeline by 2-3 years), or (3) re-scope cultivar targets downward. Decision is made by Steering Council supermajority vote (≥66% rule); documented rationale and revised breeding roadmap published within 30 days.
Rationale: The Year 7 gate (Month 84 = 2033-10-12) depends on cultivar yield ≥90% of elite clones. The breeding timeline has zero slack: trials must be planted by Month 12 (2027-10-12) to yield 6-year data by Month 84 (2033-10-12). Detecting yield penalties at Month 48 (2030-10-12) (4-year interim checkpoint) is the last decision point to activate a fallback pathway. This decision involves strategic technology choice (conventional vs. crown-budding) and budget reallocation (USD 0.25B from unallocated balance) that exceeds PMO USD 50M operational threshold.
Negative Consequences: If yield penalty >15% is confirmed and no fallback is triggered, Year 7 gate is missed; cultivar-readiness KPI cannot be achieved by Month 84 (2033-10-12), withholding Year 7 tranche (USD 6.5B, or minimum 80% = USD 5.2B). OEM offtake agreements are unsigned; alternative-crop plants cannot be financed. Estimated impact: USD 2-3 billion in sunk breeding and field-trial investment; smallholder adoption stalls (cultivars unavailable); programme loses supply-diversification objective.

**Alternative-Rubber Cost or Quality KPI Missed by Month 60 (2031-10-12) Checkpoint**
Escalation Level: Steering Council
Approval Process: At Month 60 (2031-10-12), PMO Alternative Crops Workstream submits feedstock and processing-cost assessment against pre-registered Month 60 (2031-10-12) KPI waypoints: feedstock cost ≤USD 1.20/kg dry matter (Guayule), ≤USD 1.00/kg (dandelion); processing cost ≤USD 2.50/kg; quality variance ≤±10%. If targets are significantly missed, PMO escalates to Steering Council by Month 60 (2031-10-12). Council convenes by Month 66 (2032-04-12) to decide: (1) increase processing-innovation R&D capital and defer wave 1 plant commitment, (2) redirect alternative-crop capital to accelerate resistant-Hevea breeding, or (3) narrow portfolio (e.g., dandelion only, Guayule deferred). Decision made by Council supermajority vote; choice documented and resource reallocation approved within 30 days.
Rationale: Alternative-rubber cost competitiveness is critical to Year 12 gate KPI (delivered cost <30% above Hevea benchmark). Pilot processing and tire-qualification trials (Months 12-48 = 2027-10-12 to 2030-10-12) generate cost data by Month 60 (2031-10-12). If cost or quality targets are missed, wave 1 commercial plant capex (USD 1.6B) cannot be committed without loss-absorption risk exceeding programme tolerance. This decision involves capital reallocation (USD 0.5-1.5B from processing plants to R&D or breeding) and portfolio scope that exceeds PMO USD 50M authority.
Negative Consequences: If cost targets are missed by 20-30% and no decision is made by Month 60 (2031-10-12), wave 1 plant commitment proceeds at high risk; plants are built but operate below cost targets, generating large operating losses. Estimated impact: USD 0.8-1.2 billion in stranded plant capital by Month 120 (2036-10-12); OEM offtake agreements are not signed (delivery cost exceeds OEM price tolerance); Year 12 gate cost KPI is missed, withholding Year 12 tranche (USD 4.5B, or minimum 80% = USD 3.6B); alternative-rubber pillar becomes a financial liability rather than a supply-chain hedge.

**Compliance or Data-Integrity Finding Threatens Gate-Verification Credibility**
Escalation Level: Compliance & Ethics Committee (primary investigation) with escalation to Steering Council if systemic or high-impact
Approval Process: Compliance & Ethics Committee investigates allegation within 30 days of report. If investigation uncovers data manipulation, undisclosed conflict of interest, or benefit-sharing non-compliance affecting a critical gate (breeding cultivar data, surveillance incursion reports, smallholder adoption metrics, cost/quality trial results), Committee issues written finding and recommends remedial action or data correction within 30 days. If finding is systemic (affecting >1 workstream or >10% of gate data), Committee escalates to Steering Council and Independent Auditor within 5 days. Steering Council convenes within 10 days to assess gate-closure integrity and decide: (1) proceed with gate verdict as-is with auditor caveat, (2) delay gate closure for 30-60 days pending correction, or (3) commission independent data re-validation. Decision documented and published within 15 days.
Rationale: Gate-passage decisions rest on evidence credibility. The Independent Auditor validates gate evidence but depends on data integrity from the PMO and site-level partners. If Compliance Committee detects significant data issues (corruption, falsification, concealment), the auditor verdict itself becomes questionable and funder confidence erodes. This risk is beyond PMO and Auditor scope; only the Steering Council can authorize a gate re-evaluation or delay.
Negative Consequences: If data-integrity findings are not escalated and corrected before a gate verdict, the auditor's gate closure is later challenged by funders or discovered in post-hoc audit. Reputational damage to the programme: estimated 20-30% funder-confidence loss. If a gate verdict is later overturned due to integrity issues, tranches may be recalled or withheld retroactively (estimated USD 1-2 billion exposure). Legal liability and sanctions risk for programme leadership and involved institutions.

**Critical Risk Materialization or Unforeseeable External Shock**
Escalation Level: Steering Council (emergency session within 10 days)
Approval Process: PMO risk officer identifies risk materialization (e.g., major geopolitical event, catastrophic climate event, pandemic-scale disruption, unexpected SALB incursion in a currently unaffected region, major funder defection) that threatens programme schedule or budget by >USD 500 million or >12 months. Risk officer escalates to Steering Council chair within 5 days with impact assessment. Steering Council convenes emergency session within 10 days. Council assesses: (1) is contingency reserve (USD 4.5B) sufficient to address shock, or (2) does shock require programme re-scoping or re-sequencing? If reserve deployment >USD 250M is needed, Council authorizes use; if >USD 500M, Council seeks funder consultation within 30 days. Decision and revised mitigation roadmap documented and communicated to all stakeholders within 30 days.
Rationale: Risks exceeding defined thresholds (budget >USD 500M impact, timeline >12 months) are beyond PMO operational ability to absorb or mitigate alone. Contingency reserve deployment, funder consultation, and programme re-sequencing are strategic decisions requiring Council authority. External shocks (trade war, climate extreme, pandemic, geopolitical conflict) are inherently unpredictable but must be escalated and managed transparently to maintain funder trust.
Negative Consequences: If critical risks are not escalated and managed centrally, they fragment into localized PMO-level workarounds that may be contradictory or deplete operational budgets without Council visibility. Estimated impact: USD 0.5-1.5 billion in uncoordinated spend; loss of funder confidence and potential funding withdrawal; programme timeline slips by 12-24 months; gate passage is jeopardized. Reputational damage if risk response appears reactive or unplanned.

**Smallholder-Adoption Uptake Falls Below Waypoint Threshold**
Escalation Level: Steering Council (with Smallholder Delivery Oversight and PMO consultation)
Approval Process: At Month 84 (2033-10-12), PMO Smallholder Delivery Workstream conducts farmer surveys and clean-plant-network enrollment audits. If enrollment in the clean-plant network and extension programme is <30% of eligible smallholders (the proposed waypoint threshold), Smallholder Delivery Coordinator escalates to Steering Council by Month 90 (2034-04-12). Council reviews adoption indicators and decides: (1) increase extension-corps funding and income-bridging-finance availability to boost uptake toward 40-50%, (2) accept lower adoption (30-40%) and adjust Year 12-18 smallholder-area targets downward, reducing resistant-cultivar deployment acreage, or (3) reallocate capital from smallholder to estate-scale Hevea trials. Decision is made by Council supermajority vote; revised adoption strategy and resource allocation documented within 30 days.
Rationale: Smallholder adoption is foundational to the programme's equity and supply-chain resilience goals. Planning targets 45% adoption (2.25 million ha by Month 144 = 2038-10-12) but historical uptake in developing-country agricultural programmes averages 20-40%. By Month 84 (2033-10-12), if extension and finance systems are not generating at least 30% enrollment, either systems are broken (requiring remedial investment) or adoption targets are unrealistic (requiring re-scoping). This decision involves capital reallocation (USD 0.3-0.5B between smallholder finance, extension, and alternative crops) that exceeds PMO USD 50M authority.
Negative Consequences: If smallholder uptake remains below 30% and no decision is made, by Month 144 (2038-10-12) resistant-cultivar acreage achieves only 0.75-1.2 million ha (vs. 2.25M target). Regional SALB containment cannot be demonstrated; Year 12 gate smallholder-adoption KPI is missed, contributing to a conditional or failed gate verdict. Estimated impact: USD 1.5-2.5 billion in sunk extension and replant-finance investment yields <50% of planned adoption; alternative-crop supply is undersized due to lack of smallholder participation; programme fails to deliver on equity and livelihood-resilience objectives.

# Monitoring Progress

### 1. Stage-Gate KPI Verification and Funding Release Authorization
**Monitoring Tools/Platforms:**

  - Independent Auditor Gate-Closure Reports (pre-registered methodology, field audits 30-40%, database audits 40-50%, stakeholder interviews 20-30%)
  - Gate Evidence Submission Template (PMO compiles protocol adoption, breeding cultivar data, alternative-rubber cost/quality, smallholder adoption metrics)
  - Pre-Registered KPI Definitions Document (Month 36/84/144/216 = 2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12 gate criteria, pass/fail/conditional thresholds, validated by Technical Advisory Group)
  - Steering Council Gate Decision Minute (authorization to release tranches; minimum 80% rule for partial passes; dispute escalation to Adjudication Panel)

**Frequency:** Four gates at Months 36, 84, 144, 216 (2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12); PMO submission 6 months before each gate; auditor field verification Months 30-36 (2029-04-12 to 2029-10-12), 78-84, 138-144, 210-216; verdict issued 30 days before gate deadline

**Responsible Role:** Independent International Auditor (contracted firm, independent of PMO and Steering Council); Technical Advisory Group (6-8 specialists providing scientific input on breeding, phytosanitary, processing interpretation); Gate Adjudication Panel (neutral arbitration if Steering Council disputes auditor verdict)

**Adaptation Process:** Auditor verdict determines capital tranche release (USD 7.0B/6.5B/4.5B/4.0B at gates). If gate is PASS, full tranche authorized within 45 days. If CONDITIONAL (partial KPI achievement), minimum 80% released (USD 5.6B/5.2B/3.6B/3.2B). If FAIL, Steering Council convenes within 5 days to authorize either adjudication review, remedial action plan, or capital reallocation. PMO adjusts subsequent-phase delivery targets based on gate verdict (e.g., if breeding gate is conditional, reduce small-holder acreage targets; if cost gate fails, redirect to processing R&D or resistant-Hevea allocation).

**Adaptation Trigger:** Gate-closure verdict as defined in pre-registered KPI framework: Month 36 (2029-10-12) protocol adoption (IPPC vote passed, ≥3 of top-5 producers binding, ≥100 inspectors, ≥95% red-team detection); Month 84 (2033-10-12) cultivar yield ≥90% elite clones, ≥3 resistance sources, lesion <5mm, defoliation <20%; Month 144 (2038-10-12) alternative-rubber delivered cost <30% above Hevea, 16,000 t/year capacity, ≥40% smallholder adoption; Month 216 (2044-10-12) verified containment maintained, diversified supply chains operational, climate resilience demonstrated. Auditor verdict is binding unless Steering Council initiates formal adjudication within 15 days.

### 2. SALB Containment Protocol Adoption and Compliance Monitoring
**Monitoring Tools/Platforms:**

  - Bilateral MoU Status Tracker (Brazil, Indonesia, Thailand, Malaysia, Vietnam binding commitment progress, national regulatory embedding timelines)
  - Compliance-Certificate Database and Mobile Lot-Tracking System (100,000+ inspected nursery lots per year, certified chain-of-custody, real-time inspector deployment roster)
  - Red-Team Drill Reports (protocol enforcement effectiveness tests, detection accuracy, response-speed validation, Months 18-36 = 2028-04-12 to 2029-10-12)
  - Quarterly Containment Compliance Dashboard (share of nurseries under inspection, material moved under certified chain-of-custody, violations detected, penalties imposed)
  - Incursion Alert Verification Log (surveillance detections, confirmation timeliness, false-alarm rate, escalation to response playbook)

**Frequency:** Monthly internal monitoring (Containment Authority compliance manager); quarterly compliance reporting to Steering Council and PMO; annual compliance audits (validator team); red-team drills at least 3 events over Months 18-36 (2028-04-12 to 2029-10-12); real-time alert verification (within 2 weeks of surveillance report)

**Responsible Role:** SALB Containment Protocol Authority (Compliance & Enforcement Manager, Deputy Director for Compliance Inspection); 100+ trained compliance inspectors deployed across top 5 producers (20 per country minimum); national plant-protection agency partners; Compliance & Ethics Committee (annual independent audit of inspector performance and data quality)

**Adaptation Process:** Quarterly compliance data is compiled and reviewed by Containment Authority Compliance Manager and escalated to Steering Council. If nursery-inspection coverage drops below 30,000 lots/year (vs. 100,000+ target), trigger inspector recruitment surge or subcontract with certified micro-multiplier networks. If compliance violations exceed 5% of inspected lots, tighten inspection frequency or suspend nursery certifications. If detection latency exceeds 3 months in primary producers or 6 months in secondary regions, escalate to Surveillance Sensing Architecture for detection-method enhancement (add instrumented spore traps, satellite imaging, or lab capacity). Protocol penalty schedule is enforced uniformly (fines 5-10x value of affected material); non-compliance patterns by country trigger diplomatic escalation to Steering Council for bilateral MoU renegotiation. Red-team drill failures (detection accuracy below 95%, response time beyond 2 weeks) trigger protocol enforcement retraining and inspector-network restructuring.

**Adaptation Trigger:** Non-compliance rate ≥5% at any inspection milestone; detection latency >6 months in primary producers or >12 months in secondary regions; nursery-inspection coverage <30,000 lots/year; fewer than 3 of top-5 producers with binding national embedding by Month 54 (2031-04-12) (stop/re-scope trigger); red-team drill detection accuracy <95%; zero containment-protocol adoption by Month 36 (2029-10-12) (Month 36 = 2029-10-12 gate fail).

### 3. Resistance Breeding Pathway Progress and Cultivar-Readiness Tracking
**Monitoring Tools/Platforms:**

  - Breeding-Trial Data Repository (yield measurements, disease ratings at 4 sites, resistance-gene validation, multi-site comparisons, backed up with 50-year preservation)
  - Quarterly Data-Review Reports (Months 12, 24, 36, 48, 60, 72 at 2027-10-12, 2028-10-12, 2029-10-12, 2030-10-12, 2031-10-12, 2032-10-12; interim yield-penalty assessment at Month 48 = 2030-10-12)
  - Cultivar-Selection Documentation (Month 72 = 2032-10-12 final cultivar candidates with multi-site evidence, submitted to Independent Auditor by Month 78 = 2033-04-12)
  - Pre-Registered Breeding Objectives Document (yield ≥90% of elite clones, ≥3 stacked resistance sources, lesion size <5mm, defoliation <20%, 10x-inoculum durability testing)
  - Technical Advisory Group breeding pathology assessment (pathogen-variant surveillance, resistance-durability signals, cross-site variability analysis)

**Frequency:** Monthly site-manager reports to Breeding Programme Director; quarterly multi-site data reviews (Months 12, 24, 36, 48, 60, 72 = 2027-10-12, 2028-10-12, 2029-10-12, 2030-10-12, 2031-10-12, 2032-10-12); annual breeding-progress update to Steering Council; interim yield-penalty checkpoint at Month 48 (2030-10-12); final cultivar selection by Month 72 (2032-10-12); post-release durability monitoring quarterly from Month 84 (2033-10-12) onward

**Responsible Role:** Breeding Programme Director (hired by Month 3, 2027-01-12); Regional Deputy Directors for Brazil, Thailand/Southeast Asia, Côte d'Ivoire (hired by Month 9, 2027-07-12); Breeding Coordinator (data management, multi-site protocol consistency); Site Managers at 4 breeding locations; Technical Advisory Group pathologist (durability consultant); Compliance & Ethics Committee (annual breeding-data integrity audits)

**Adaptation Process:** Quarterly data reviews assess yield penalties, resistance stacking progress, and durability signals. If yield penalty exceeds 15% (cultivar yield <85% of elite) at Month 48 (2030-10-12), Breeding Programme Director escalates to Steering Council within 5 days. Council decides by Month 54 (2031-04-12): (1) continue conventional breeding (accepts potential Year 7 gate delay), (2) initiate crown-budding fast-track fallback (USD 0.25B budget, compresses timeline 2-3 years), or (3) re-scope cultivar yield targets downward. If multi-site interpretation is contentious (one site shows poor durability, others show good), escalate to Technical Advisory Group pathologist for independent assessment. If data integrity concerns arise (missing records, inconsistent measurements), escalate to Compliance & Ethics Committee. By Month 60 (2031-10-12), breeding team initiates second-generation cultivar breeding using different resistance sources, ensuring replacements are available by Month 120 (2036-10-12) if first-generation durability breaks down post-release.

**Adaptation Trigger:** Yield penalty exceeds 15% by Month 48 (2030-10-12) (triggers crown-budding decision); cultivar yield below 90% of elite clones by Month 72 (2032-10-12) (threatens Year 7 gate pass); resistance sources reduce from 3+ to <3 confirmed independent sources; lesion size >5mm or defoliation >20% confirmed at 2+ sites; durability breakdown detected during sentinel-planting monitoring (Months 84-144 = 2033-10-12 to 2038-10-12) (triggers next-generation breeding acceleration); data-integrity allegation affecting trial records (escalates to Compliance & Ethics investigation).

### 4. Alternative-Rubber Cost, Quality and Processing Viability Monitoring
**Monitoring Tools/Platforms:**

  - Pilot-Processing Performance Dashboard (feedstock yield, extraction efficiency, product-quality variance, operating cost per kg, compared to KPI thresholds at Months 36, 48, 60 = 2029-10-12, 2030-10-12, 2031-10-12)
  - Tire-Performance Qualification Trial Results (tread wear, durability, grip data from independent labs, OEM specification compliance, Months 24-48 = 2028-10-12 to 2030-10-12)
  - Cost-Analysis Waypoint Reports (feedstock cost, processing cost, delivered-cost benchmarking vs. Hevea at Months 36, 48, 60, 84, 144 = 2029-10-12, 2030-10-12, 2031-10-12, 2033-10-12, 2038-10-12)
  - Portfolio-Decision Framework (gate decision logic: continue, pivot to processing R&D, or redirect to resistant-Hevea breeding)
  - Wave 1 and Wave 2 Plant FID and Financial Model (capex, opex, DSCR, financing structure, based on pilot performance)

**Frequency:** Monthly pilot-plant operations data (Alternative Crops Workstream); quarterly cost-analysis reviews at Months 36, 48, 60 (2029-10-12, 2030-10-12, 2031-10-12); tire-qualification trial results published as available (target monthly, Months 24-48 = 2028-10-12 to 2030-10-12); semi-annual processing-innovation R&D progress reports; annual alternative-crop update to Steering Council

**Responsible Role:** PMO Alternative Crops Workstream Coordinator (recruited by Month 6, 2027-04-12); pilot-plant operators (Guayule and dandelion sites); processing engineers; OEM Engagement Lead (coordinate tire-qualification trials and offtake negotiations); Finance Manager (cost-analysis and plant-financing models); Technical Advisory Group processing specialist (assess cost and quality KPI achievement)

**Adaptation Process:** At Months 36, 48, and 60 (2029-10-12, 2030-10-12, 2031-10-12), Alternative Crops Workstream compiles feedstock yield, extraction efficiency, feedstock cost (Guayule ≤USD 1.20/kg dry matter, dandelion ≤USD 1.00/kg), extraction yield (Guayule ≥85%, dandelion ≥80%), processing cost (target ≤USD 2.50/kg), and quality variance (±10%). If targets are missed by 10-20%, escalate to PMO and note as risk to Year 12 gate. If targets are missed by >20%, escalate to Steering Council by Month 60 (2031-10-12) for portfolio decision: (1) increase processing-innovation R&D capital (fund advanced extraction or separation technology), (2) redirect alternative-crop capital to resistant-Hevea breeding prioritization, or (3) narrow portfolio (e.g., dandelion only, Guayule deferred). Wave 1 commercial-plant FID (USD 1.6B capex for 8 plants) is authorized only after Month 60 (2031-10-12) decision and conditional on pilot and tire-qualification results. Wave 2 FID only after Month 144 (2038-10-12) gate (if PASS or CONDITIONAL). If processing-cost or quality targets are missed by Month 84 (2033-10-12), trigger alternative-crop operating-shortfall funding (draw from USD 0.6B loss-cover line item or contingency reserve).

**Adaptation Trigger:** Feedstock cost exceeds thresholds (Guayule >USD 1.30/kg, dandelion >USD 1.10/kg, estimate) by Month 48 (2030-10-12); extraction yield below 80% (Guayule) or 75% (dandelion, estimate); processing cost >USD 2.70/kg by Month 60 (2031-10-12); quality variance >±15% by Month 60 (2031-10-12); delivered cost remains ≥30% above Hevea by Month 84 (2033-10-12) (signals Year 12 gate cost-KPI risk); OEM offtake not signed by Month 60 (2031-10-12) (signals demand risk); pilot-plant debt service cannot be covered by operating margins.

### 5. Smallholder Adoption and Income-Bridging Finance Performance Tracking
**Monitoring Tools/Platforms:**

  - Smallholder Enrollment Audit (quarterly survey of extension-agent reach, clean-plant network enrollment, farmer uptake of replant loans, by country and region)
  - Replant-Finance Disbursement and Repayment Dashboard (loans approved, approved farmers, disbursements, defaults, arrears, income-support payments deployed, repayment rates)
  - Extension-Corps Performance Metrics (number of trained agents deployed, farmers served per agent, clean-plant-nursery visit frequency, farmer satisfaction surveys)
  - Adoption-Waypoint Assessment (Month 84 = 2033-10-12: at least 30% enrollment in clean-plant network; Month 144 = 2038-10-12: at least 40% of eligible area replanted with resistant clones)
  - Price-Floor and Market-Linkage Monitoring (smallholder prices for resistant cultivar and alternative-crop output vs. guaranteed price floor, offtake-contract delivery volumes)

**Frequency:** Monthly extension-corps activity reports; quarterly smallholder surveys (at least 500 farmers per major country, Months 12, 24, 36, 48, 60, 72, 84, 120, 144 = 2027-10-12, 2028-10-12, 2029-10-12, 2030-10-12, 2031-10-12, 2032-10-12, 2033-10-12, 2036-10-12, 2038-10-12); annual adoption-progress update to Steering Council; waypoint assessments at Months 84 and 144 (2033-10-12, 2038-10-12); monthly finance disbursement tracking and quarterly default/arrears audit

**Responsible Role:** PMO Smallholder Delivery Workstream Coordinator (recruited by Month 6, 2027-04-12); 500 lead extension agents (target deployed by Month 12, 2027-10-12); smallholder cooperatives and farmer organizations (ownership of nurseries and extension delivery); national agricultural banks (replant-loan disbursement and servicing); Compliance & Ethics Committee (annual smallholder-finance fraud audits, 2,000+ farmer sample per major country, income-support payment verification)

**Adaptation Process:** Quarterly smallholder surveys track enrollment and uptake progress. If enrollment in extension and clean-plant network reaches 30% by Month 84 (2033-10-12), adoption pathway continues unchanged. If enrollment is below 25% (conservative scenario), escalate to Steering Council by Month 90 (2034-04-12): increase extension funding and income-support payments to boost uptake, or accept lower adoption (30-40%) and adjust Year 12-18 smallholder-area targets downward, reducing resistant-cultivar deployment acreage. Monthly finance-disbursement tracking identifies loan approval delays (escalate to national agricultural banks) and default/arrears trends (if >15%, trigger remedial support: additional technical assistance, group-guarantee restructuring). If replant-loan default or early abandonment suggests farmers are reverting to old cultivars, escalate to extension team for farmer re-engagement and mid-course correction. Annual fraud audits by Compliance & Ethics Committee flag misused replant finance or false-adoption claims; confirmed cases are investigated and remedial actions (repayment demands, exclusion from future finance) are enforced.

**Adaptation Trigger:** Smallholder enrollment in clean-plant network and extension <30% by Month 84 (2033-10-12) (stop trigger); enrollment <25% at any waypoint (signals major delivery-system failure); replant-loan default rate >15% (signals farmer distress or program design failure); extension-agent turnover >40% annually in any country (signals retention crisis); replant-finance cumulative disbursement lags budget plan by >20%; smallholder uptake of resistant clones below 40% of enrolled farmers by Month 120 (2036-10-12); price for resistant output falls >10% below guaranteed floor (triggers review of market-linkage viability).

### 6. Compliance, Ethics, and Benefit-Sharing Verification
**Monitoring Tools/Platforms:**

  - Compliance & Ethics Committee Quarterly Investigation Summary (whistleblower reports, investigations in progress, closed cases, remedial actions)
  - Benefit-Sharing Audit Report (ABS royalty calculations, community payments disbursed, verification of payments to Amazonian indigenous and traditional communities, reconciliation with cultivar deployment)
  - Breeding-Data Integrity Audit (independent data validators assess trial records, yield measurements, disease ratings at all 4 sites annually for manipulation or errors)
  - Smallholder-Finance Fraud Audit (2,000+ farmer samples per major country annually, loan document verification, income-support payment verification, default analysis)
  - Code of Conduct Compliance Attestation (annual conflict-of-interest disclosure compliance, training attendance, whistleblower-channel awareness)

**Frequency:** Monthly whistleblower-report intake and triage; quarterly investigation-status summary to Steering Council; annual benefit-sharing audit (by Month 12 = 2027-10-12 and every year thereafter); annual breeding-data integrity audit at each of 4 sites (by Month 6 = 2027-04-12 each year); annual smallholder-finance fraud audit by Month 6 (2027-04-12) each year; annual Code of Conduct compliance reporting by Month 6 (2027-04-12) each year

**Responsible Role:** Compliance & Ethics Committee Chair (independent external expert, reports to Steering Council); Anti-Corruption Officer (investigation lead); ABS Specialist (benefit-sharing tracking, community liaison); Environmental & Social Safeguards Officer (alternative-crop siting audits, land-tenure verification); Breeding Programme Director and site managers (providing trial records and data access for audits); PMO Finance Manager (finance audit cooperation); external independent data validators (breeding-trial data integrity); external fraud-investigation auditor (smallholder-finance sample audits)

**Adaptation Process:** Whistleblower reports are investigated within 30 days. If investigation uncovers data manipulation or conflict of interest affecting a critical gate (e.g., cultivar yield data, surveillance reports, smallholder metrics, cost/quality trial data), Compliance & Ethics Committee escalates to the Independent Auditor within 5 days. Auditor assesses impact on gate-closure integrity and reports to Steering Council. If systemic corruption or significant data errors are found before a gate verdict, Steering Council authorizes gate delay (30-60 days) for data re-validation or correction. Benefit-sharing audits verify that royalty calculations match ABS agreements and that community payments are disbursed on schedule (annual, linked to cultivar deployment); if payments are delayed or miscalculated, ABS Specialist executes corrective payments within 30 days and reports findings to Steering Council. Breeding-data integrity audits verify trial protocols compliance, measurement consistency across sites, and resistance-gene validation accuracy; if errors are detected, independent validators flag impact on KPI assessments for auditor consideration. Smallholder-finance fraud audits identify loan document falsification, income-support payment fraud, or misuse; confirmed fraud is reported to national authorities and remediated through loan recall or exclusion from future finance.

**Adaptation Trigger:** Whistleblower report of corruption, conflict of interest, or data manipulation (escalates to investigation within 24 hours); investigation finding of systemic issue affecting >1 workstream (escalates to Steering Council for response authorization); benefit-sharing payment delay >30 days (escalates to Steering Council and funders); breeding-data anomaly detected (unexplained data variance at one site, measurement inconsistency across sites, missing records) (escalates to auditor); smallholder-finance fraud detected (loan document falsification, income-support payment embezzlement) (escalates to law enforcement and programme remediation); Code of Conduct compliance attestation failure >5% of personnel (triggers retraining and policy reinforcement).

### 7. Risk Register Review and Mitigation-Action Tracking
**Monitoring Tools/Platforms:**

  - Integrated Programme Risk Register (18 documented risks: institutional/regulatory, technical/biological, technical/economic, financial/capital structure, operational/supply chain, ABS/IP, surveillance, gate verification, OEM offtake, climate/environmental, regulatory/trade, political/geopolitical, smallholder adoption, data/knowledge management, processing, protocol enforcement, long-term sustainability, resistance durability)
  - Monthly Risk Scorecard (likelihood and impact assessment of each risk, mitigation-action status, early-warning indicators)
  - Mitigation-Action Tracking Log (action owner, due date, completion status, effectiveness review)
  - Quarterly Risk Summary Report to Steering Council (escalation of risks exceeding defined thresholds; emergency-risk alerts; contingency-reserve deployment requests)

**Frequency:** Monthly internal risk review (PMO risk officer and workstream coordinators); quarterly escalation review and Steering Council briefing; annual comprehensive risk-register update (refresh likelihood and impact estimates, add emerging risks); real-time escalation (within 5 days) of critical-risk materialization (external shocks, major funder defection, unexpected SALB incursion, geopolitical event)

**Responsible Role:** PMO Programme Director (overall risk governance); PMO risk officer (monthly risk scorecard compilation, escalation identification); Workstream Coordinators (identify and report workstream-level risks); Steering Council (approve response strategies for risks exceeding thresholds; authorize contingency-reserve deployment; decide stop/re-scope based on materialized risks); Compliance & Ethics Committee (flag ethics and corruption risks)

**Adaptation Process:** Monthly risk review identifies status of all 18 documented risks and any emerging risks. Risks are scored by likelihood (1-5 scale, annual update) and impact (1-5 scale, annual update); products >8 (high-priority, defined as impact ≥3 and likelihood ≥3, estimate) trigger active mitigation. Mitigation actions are tracked with owner, due date, and completion status. Quarterly risk summary to Steering Council highlights risks exceeding defined thresholds and recommends response: (1) continue current mitigation, (2) increase mitigation investment, (3) trigger contingency plan, (4) re-scope programme scope/timeline. If critical risk materializes (e.g., major geopolitical disruption, unexpected SALB incursion in currently unaffected region, >USD 500M budget impact), risk officer escalates to Steering Council chair within 5 days; Council convenes emergency session within 10 days. Council assesses: is contingency reserve (USD 4.5B) sufficient, or does shock require programme re-sequencing? Decisions are documented and communicated to funders within 30 days. Mitigation-action effectiveness is reviewed quarterly: if mitigations are not reducing risk scores, increase investment or pivot to alternative strategy.

**Adaptation Trigger:** Risk likelihood or impact score increases by >2 points (indicates worsening conditions); risk moves from green (likelihood <2 or impact <3) to yellow (3-8 product) or red (>8 product); three or more mitigation actions for a single risk fall behind schedule; contingency-reserve balance falls below USD 3.0B (after climate re-siting allocation, estimate); external shock (trade war, pandemic, geopolitical conflict, catastrophic climate event) impacts programme budget by >USD 500M or timeline by >12 months; critical risk threshold breached as defined in decision escalation matrix (e.g., <3 of top-5 producers with binding protocol adoption by Month 54 = 2031-04-12, yield penalty >15% by Month 48 = 2030-10-12, alternative-rubber cost >30% above Hevea by Month 84 = 2033-10-12).

# Governance Extra

## Governance Validation Checks

1. Completeness Confirmation: All six core governance components are generated and documented: (1) internal governance bodies (Steering Council, PMO, Containment Protocol Authority, Compliance & Ethics Committee, Gate Evidence Verification Panel, Resistance Breeding Oversight Group), (2) governance implementation plan (64 detailed step-by-step actions Months 0–216 = 2026-10-12 to 2044-10-12), (3) decision escalation matrix (7 escalation scenarios with approval criteria and consequences), (4) monitoring progress framework (5 continuous oversight mechanisms with triggers), and (5) audit procedures and transparency measures. However, the framework lacks explicit clarity on: ultimate project sponsor authority and escalation to external arbitration beyond the Steering Council for systemic governance disputes.
2. Internal Consistency Check: The governance structure is logically aligned across stages. Implementation plan's monthly milestones (e.g., auditor contracting Month 3 = 2027-01-12, bilateral MoUs Month 6 = 2027-04-12, inspector training by Month 12 = 2027-10-12) feed into the pre-registered KPI definitions (Month 6 = 2027-04-12 deadline for finalization). Escalation matrix thresholds (e.g., <3 of top-5 producers with binding adoption by Month 54 = 2031-04-12) trigger Steering Council decisions that link to monitoring checkpoints (quarterly adoption tracking). Gate verdicts from independent auditor flow to Steering Council authorization of tranche release (45-day disbursement timeline). Smallholder adoption waypoints (30% by Month 84 = 2033-10-12, 40% by Month 144 = 2038-10-12) align with extension-corps and nursery-network deployment timelines. Breeding interim checkpoint (Month 48 = 2030-10-12 yield-penalty assessment) connects to fallback pathway decisions (crown-budding fast-track). Minor inconsistency detected: Compliance & Ethics Committee is noted as independent of PMO but reports to Steering Council; however, the committee's authority to investigate breeding-data integrity and escalate to auditor is not explicitly sequenced in the Implementation Plan, creating a 10-day gap between detection and auditor notification that could compress gate timelines.
3. Potential Gap 1 – Clarity of Roles in Sovereign-vs-Program Authority: The Containment Protocol Authority is embedded within IPPC/FAO but funded by the programme and reports operationally to the Programme Director and strategically to the Steering Council. However, the governance documents do not explicitly clarify who has ultimate authority if a producing nation (e.g., Brazil) violates the protocol's penalty schedule or refuses national embedding: does the Containment Authority enforce fines against a sovereign nation, or does this escalate to diplomatic channels outside the programme's control? The Implementation Plan (Step 45) states penalties are 'enforced uniformly across countries per bilateral MoUs,' but provides no mechanism for when a sovereign refuses enforcement. Recommendation: Define a three-tier escalation: (1) Containment Authority compliance manager addresses violation within 30 days; (2) if unresolved, escalates to Steering Council; (3) Steering Council invokes a MoU dispute-resolution clause (e.g., independent arbitration or funding-release suspension) within 60 days. Publish this escalation in the bilateral MoU template.
4. Potential Gap 2 – Insufficiently Detailed Conflict-of-Interest Management in Breeding-Cultivar Selection: The Compliance & Ethics Committee audits breeding-trial data for integrity, and the Steering Council (via Technical Advisory Group) interprets multi-site data for cultivar selection (Month 72 = 2032-10-12). However, the governance framework does not explicitly address conflicts of interest if, for example, a Regional Deputy Director or site manager has a financial stake in a particular resistance source or holds IP on a clone being tested. The Code of Conduct (Step 7) requires conflict-of-interest disclosure, but enforcement authority and remedies (e.g., recusal from cultivar-selection decisions, independent re-validation of that site's data) are not defined. Recommendation: Publish a specific Breeding Conflict-of-Interest Protocol requiring: (a) annual conflict-of-interest declarations from all breeding-team members; (b) automatic recusal from cultivar-selection decisions if a conflict is disclosed; (c) independent third-party review of data from a conflicted site if yield or disease ratings diverge >10% from other sites; (d) Compliance & Ethics Committee escalation if conflict is suspected undisclosed.
5. Potential Gap 3 – Ambiguity in Adaptive Triggers and Go/No-Go Decision Authority for Mid-Course Pathway Changes: The escalation matrix defines triggers (e.g., yield penalty >15% by Month 48 = 2030-10-12, cost target missed by Month 60 = 2031-10-12), but the Implementation Plan and monitoring framework do not explicitly specify who decides whether to invoke a fallback pathway (crown-budding fast-track, processing-innovation pivot, alternative-crop portfolio narrowing) and by what timeline. For example, the breeding trigger at Month 48 (2030-10-12) specifies that the Breeding Coordinator escalates to Steering Council, which then decides by Month 54 (2031-04-12)—a 6-month window. However, if the Steering Council is quarterly-meeting, an escalation filed in early Month 48 (2030-10-12) may not be discussed until Month 51 (2031-01-12), compressing the decision window. Recommendation: Define a 'Fast-Track Steering Council Decision Protocol' for critical pathway decisions: (1) escalation triggers a 20-day Steering Council review (vs. quarterly meeting cycle); (2) if consensus cannot be reached in 20 days, the Programme Director has authority to activate mitigation spending up to USD 250M while Council debate continues (then Council ratifies or reverses within 60 days); (3) all pathway changes are documented and published to funders within 30 days.
6. Potential Gap 4 – Data Governance and IP Posture Disconnection from Gate Verification and Commercialization: The monitoring framework specifies that breeding-trial data is released to an open commons 12 months after collection (or 6 months post-gate if gate-sensitive), but it does not clarify: (a) who owns the data-release decision if a breeding partner or national institution claims proprietary rights, (b) how 'open-access' genomic sequences interact with future IP licensing for commercial cultivar traits (e.g., if a cultivar generated with open-access genomic data is later patented, what benefit-sharing obligations flow back to the commons), or (c) how smallholder royalty-free seed claims are enforced against commercial licensees in countries with weak IP regimes. The Compliance & Ethics Committee's published benefit-sharing ledger (annual transparency) does not include benefit-sharing from proprietary cultivar sales, leaving a gap between ABS royalties (plant-level) and downstream commercial returns. Recommendation: Publish a Data and IP Integration Protocol clarifying: (1) data-release timeline and authority (Technical Advisory Group votes on gate-sensitive delays); (2) IP licensing for cultivars generated with programme-funded genomic data includes a benefit-sharing pass-through (e.g., 1-2% of commercial licence revenue returns to ABS beneficiaries); (3) smallholder royalty-free seed is enforced via nursery-certification compliance (licensed multipliers must offer royalty-free seed on penalty of decertification).

## Tough Questions

1. By Month 54 (2031-04-12), what is the probability-weighted forecast that all 5 of the top-producing nations (Brazil, Indonesia, Thailand, Malaysia, Vietnam) will have binding national regulatory embedding of the SALB Containment Protocol, and what is the contingency plan if only 2–3 commit? The framework specifies a 'stop/re-scope' trigger at <3 commitments, but does this mean the entire Year 3 gate is failed, or is there a partial-pass pathway with a reduced protocol scope (e.g., voluntary regional standards instead of binding national law)?
2. At Month 48 (2030-10-12), if the breeding trials show cultivar yield penalties of 12-15% (within the margin but below the preferred >90% threshold), what specific decision authority does the Steering Council have to authorize crown-budding fast-track acceleration without retreating from the plan's stated commitment to conventional breeding? Is the USD 0.25 billion fallback budget pre-allocated, or must it be justified against unallocated reserves, and what is the timeline for a Steering Council decision (the Implementation Plan specifies Month 54 = 2031-04-12 decision but provides no meeting-acceleration protocol)?
3. Show evidence that the 500 lead extension agents and 50-100 certified nurseries per major country can be sustainably staffed and retained beyond Month 12 (2027-10-12) given that rural agricultural extension historically experiences 30-50% annual turnover in developing countries. What are the specific retention mechanisms (salaries, career pathways, cooperative ownership stakes) and what is the annual budget for extension-workforce replacement and retraining?
4. What is the current status of OEM (tire maker) engagement, and what is the evidence that at least 8 of the top 10 will commit to purchase-option contracts (with 1.5% annual reservation fees) for 16,000 t/year of alternative rubber by Month 60 (2031-10-12)? What happens if only 4-5 OEMs sign, leaving 8,000 t/year uncommitted; does the programme have the authority to reduce wave 1 plant capex from USD 1.6 billion to USD 800 million, or are all 4 plants built regardless of offtake coverage?
5. By Month 84 (2033-10-12), what will be the independent auditor's confidence level in the breeding-trial yield and durability data across 4 geographically dispersed sites (Brazil, Thailand, Malaysia/Indonesia, Côte d'Ivoire), given that each site operates under different national regulations, funding structures, and institutional practices? What is the pre-specified threshold for auditor confidence required to issue a PASS verdict (e.g., ≥3 of 4 sites show consistent >90% yield, or all 4 sites must achieve it)?
6. If the Month 144 (2038-10-12) gate on alternative-rubber cost finds that delivered cost is 35-40% above Hevea (vs. the <30% target), and OEM offtake is still signed but at below-cost prices, how does the programme cover the operating shortfall? Is it drawn from the USD 0.6 billion pilot-loss/operating-shortfall line, or does the loss trigger a Steering Council decision to wind down wave 2 plant commissioning and redirect capital elsewhere? What is the maximum cumulative loss the programme can absorb before this becomes a gate-failure trigger?

## Summary

This 25-year, USD 30 billion programme de-risks global natural-rubber supply from SALB through a harmonized containment protocol, SALB-resistant Hevea cultivars, and commercial Guayule/dandelion supply chains. Governance prioritizes stage-gated capital release (Months 36/84/144/216 = 2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12) with independent auditor verification, multi-stakeholder steering, and decentralized smallholder delivery. Key strengths: binding 25-year framework agreements, pre-registered KPI definitions, transparent gate verdicts, protected extension funding, and tiered compliance enforcement. Critical dependencies remain: producer-nation binding adoption of the protocol by Month 54 (2031-04-12), yield-parity cultivars by Month 84 (2033-10-12), and cost-competitive alternative rubber by Month 60 (2031-10-12). Institutional durability and smallholder adoption uptake are foundation risks.