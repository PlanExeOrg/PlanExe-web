# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** Global, multi-decade, societal-scale program: 25 years and $30 billion (user constraint), spanning three pillars (containment, resistant Hevea, alternative rubbers) plus smallholder delivery across several continents. It requires governments, OEMs and development lenders to act together.

**Risk and Novelty:** Moderate-to-high biological and institutional risk, but built on established components: IPPC-type phytosanitary standards, genomic breeding of Hevea, and guayule and Russian dandelion, which are known crops not yet at commercial scale. Breeding timelines are long and unpredictable, and the cost parity of alternative rubbers is unproven. The plan stresses discipline over experimentation: containment is the non-negotiable first deliverable.

**Complexity and Constraints:** Very high. Constraints: a harmonized protocol aligned with existing regional phytosanitary standards, a Brazil-led access-and-benefit-sharing-compliant effort, and gates at Years 3/7/12/18 on containment, cultivar readiness and cost/quality KPIs. Smallholder adoption is a design requirement. Colocated processing and OEM offtake add industrial complexity. Start is ASAP, but Phase 1 must be funded and verified before scale-up.

**Domain and Tone:** Business and public-private agricultural supply-chain resilience, with a formal, institutional and risk-managed tone. The emphasis is on harmonization, verification, stage-gating and procurement resilience, not on speculative technology.

**Holistic Profile:** A large, institution-heavy, stage-gated resilience program. It needs durable multilateral legitimacy, standards-based containment that is harmonized with existing frameworks, funding stable across political cycles, and gates flexible enough for biological timelines. It does not call for either a minimal-footprint regional approach or a high-risk, financially engineered gamble.

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Pragmatic Foundation
**Strategic Logic:** Anchor containment in the established international plant protection framework, so national authorities adopt and are audited against the protocol. Back this with a multilateral secretariat that has producer-government seats, durable levy funding, conventional pyramided breeding and adaptive tranches that respond to biological timelines. Together these give credible gates and stable money without relying on unproven science or financial engineering. The main risks are slow standard-setting and the cartel-like coordination a levy needs.

**Fit Score:** 9/10

**Why This Path Was Chosen:** Anchors containment in the existing international plant protection framework, matching the harmonization requirement. Adaptive tranches suit unpredictable breeding timelines, a producer-seated secretariat gives legitimacy over 25 years, and a levy gives durable funding aligned with OEM offtake.

**Key Strategic Decisions:**

- **Containment Protocol Legal Architecture:** Negotiate the protocol as a standard under the international plant protection framework, so that national plant protection organizations adopt it into their import rules and are audited against it.
- **Resistance Breeding Strategy:** Pyramid several resistance sources from wild Brazilian accessions into elite Asian high-yield clones using genomic selection, and test them at multiple SALB hotspot sites under the containment protocol.
- **Stage-Gate and Capital Release Design:** Use adaptive tranches that release partial funding on partial KPI attainment, with the remainder reallocated among the three pillars according to which pathway shows the strongest evidence.
- **Program Governance and Decision Rights:** Establish an independent multilateral secretariat with its own board, binding authority over gate decisions, and seats for producer governments, OEMs, and development lenders.
- **Capital Stack and Industry Levy Mechanism:** Create a per-tonne industry levy on natural rubber trade or tyre production that pays into a ring-fenced fund governed jointly by producers and consumers.

**The Decisive Factors:**

- **Fit with the plan's profile:** The plan is a large, stage-gated, institution-heavy program whose Phase 1 deliverable is a *globally adopted* protocol harmonized with existing phytosanitary standards. Only this scenario builds the protocol inside the international plant protection framework, with national authorities adopting and audited against it.
- **Risk match:** Pyramided breeding avoids reliance on regulatory approval for gene editing. Adaptive tranches suit unpredictable biological timelines at the Years 3/7/12/18 gates.
- **Durability:** A producer-seated secretariat and a ring-fenced levy give legitimacy and stable money across political cycles, and reinforce OEM offtake.
- **Pioneer's Gambit:** Outcome-linked bonds, gene editing and a voluntary code add regulatory, financial-design and producer-pushback risk that the plan does not need.
- **Consolidator's Shield:** The regional compact delays global reach, and rigid gates with in-kind industry funding are too thin for a 25-year, $30 billion (user constraint), three-pillar program.

---
## Alternative Paths
### The Pioneer's Gambit
**Strategic Logic:** Maximize speed and leverage by making protocol compliance a condition of money and OEM demand, running gene editing alongside conventional breeding, and funding the program through investor capital that is paid only on results. Capital is concentrated in the best-performing pathway under public scrutiny, and an endowment-backed foundation shields gate decisions from budget politics. The price is higher exposure to regulatory rejection, financial-instrument design risk and producer-state pushback.

**Fit Score:** 4/10

**Assessment of this Path:** Fast and leveraged, but gene editing, outcome-linked bonds and a voluntary certification code add regulatory, financial-design and legitimacy risk. This conflicts with the plan's harmonized-with-existing-standards requirement and its smallholder and procurement-resilience orientation.

**Key Strategic Decisions:**

- **Containment Protocol Legal Architecture:** Launch an industry-and-donor-backed certification code that links access to program funding and OEM procurement to protocol compliance, while formal intergovernmental adoption proceeds in parallel.
- **Resistance Breeding Strategy:** Run a parallel gene-editing track aimed at susceptibility genes in elite clones, and carry it forward only where regulators in the main producing countries have confirmed a viable approval route.
- **Stage-Gate and Capital Release Design:** Create a standing portfolio board that can pre-commit a reserve to the best-performing pathway after each gate, and publishes all gate evidence so that outside parties can challenge decisions.
- **Program Governance and Decision Rights:** Create a purpose-built endowment-backed foundation whose trustees are bound by a charter and independent technical panels, insulating gate decisions from annual political budgeting.
- **Capital Stack and Industry Levy Mechanism:** Issue outcome-linked bonds or insurance-style instruments where investors are repaid from avoided-loss payouts if containment and cultivar milestones are met.

### The Consolidator's Shield
**Strategic Logic:** Protect the SALB-free producing regions first through a tested regional compact. Use proven grafting techniques that do not depend on regulatory approval, fixed pass-or-stop gates that return unspent money, and a lead-nation consortium that delegates to existing research institutions. Funding comes from sovereign and development-bank commitments, with industry contributing in kind. This keeps cost, legal complexity and funder exposure as low as possible, but at the price of slower global reach and weaker adaptability to biological surprises.

**Fit Score:** 4/10

**Assessment of this Path:** Low-cost and low-risk, but a regional Asia/Africa-first compact defers a globally adopted protocol, and grafting adds smallholder cost. Fixed gates and in-kind industry contributions fit poorly with a $30 billion, 25-year, three-pillar program that needs global reach.

**Key Strategic Decisions:**

- **Containment Protocol Legal Architecture:** Build a regional compact among SALB-free producing countries in Asia and Africa first, with reciprocal inspection rights and shared quarantine facilities, and extend it to Latin America only after its inspection regime has been tested.
- **Resistance Breeding Strategy:** Use a crown-and-trunk grafting system that pairs a resistant leaf canopy with a high-latex panel clone, so that resistance and yield are bred in separate lines and combined at the nursery.
- **Stage-Gate and Capital Release Design:** Apply fixed pass-or-stop gates with pre-agreed numeric thresholds, verified by an independent technical panel, with unspent funds returned to contributors if a gate is failed.
- **Program Governance and Decision Rights:** Operate through a lead-nation consortium, with Brazil and two or three major producer states sharing rotating chairs and delegating execution to existing agricultural research institutions.
- **Capital Stack and Industry Levy Mechanism:** Fund the program mainly from sovereign and multilateral development-bank commitments, with industry contributing in-kind through trials, processing capacity and offtake.
