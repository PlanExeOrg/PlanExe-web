# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** Very high: a 25-year, $30 billion (user constraint) global public-private program spanning containment governance, Amazonian bio-prospecting and breeding, and commercial-scale alternative rubber crops on several continents, with smallholder finance and extension. Societal and economic scale, with funding gated at Years 3/7/12/18.

**Risk and Novelty:** Moderate-to-high. SALB is a known, severe threat, and the response relies on partly proven tools: phytosanitary standards, genomic selection and stage gates. Technical uncertainty is concentrated in yield-parity Hevea cultivars (perennial crop, long cycles, durability of resistance) and in cost competitiveness of Guayule and Russian dandelion against Hevea. Institutional risk lies in global adoption of the protocol and in sustaining funding over decades.

**Complexity and Constraints:** Very high. Many parallel workstreams (protocol, breeding, alternative crops, processing plants, OEM offtake, smallholder finance) require multi-country coordination and Access-and-Benefit-Sharing compliance. Explicit constraints: the protocol must be harmonized with existing regional phytosanitary standards; the Phase 1 containment protocol is non-negotiable and precedes scale-up; funding is gated on containment, cultivar readiness and cost/quality KPIs; alternatives are to be commercial-scale with colocated processing and OEM offtake; and the design must support smallholder adoption.

**Domain and Tone:** Business-framed agricultural, infrastructure and supply-chain resilience program; institutional, risk-managed, evidence-gated and stability-oriented rather than a technology moonshot. Physical, multi-site execution.

**Holistic Profile:** A large, long-horizon, institution-heavy resilience program that prizes legitimacy, verified results and durable funding over speed or technological novelty. It commits to a defined set of crops and to commercial-scale processing, relies on harmonization with existing standards, and uses independently measured gates to control capital. The best-fit approach is balanced, deliverable and credible, without an experimental regulatory burden or a purely pilot-scale posture.

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Pragmatic Foundation
**Strategic Logic:** Balances legitimacy, durability and deliverability: the protocol is embedded in the IPPC framework so national agencies adopt it, breeding relies on durable polygenic resistance without gene-edited material, and the alternative-crop investment is concentrated on Guayule and dandelion where OEM offtake is credible. An independent auditor with pre-fixed scope gives gates credibility without stalling decisions, and a ring-fenced industry levy provides stable funding outside government budget cycles.

**Fit Score:** 8/10

**Why This Path Was Chosen:** Matches the plan's explicit design: IPPC-embedded harmonized protocol, genomic breeding on Amazonian germplasm (Brazil-led, ABS-compliant), concentrated Guayule/dandelion with colocated processing and OEM offtake, and independently verified gates. Its main weakness is that an industry-only levy is less 'public-private' and less gate-conditional than the plan implies.

**Key Strategic Decisions:**

- **Containment Protocol Authority:** Embed the protocol within the existing IPPC and regional plant protection organization framework, publishing it as a harmonized international standard that national agencies adopt through their normal regulatory processes.
- **Resistance Breeding Pathway:** Run marker-assisted and genomic selection across a broad Amazonian germplasm base, crossing multiple resistance sources into high-yield Asian clones to build polygenic, durable resistance without gene-edited material.
- **Alternative Rubber Portfolio Breadth:** Concentrate investment on Guayule in arid zones and Russian dandelion in temperate zones, building a few commercial-scale colocated processing plants sized to meet OEM cost and quality specifications.
- **Gate Evidence Verification Regime:** Contract an independent international auditor to verify containment performance, cultivar field data and alternative-rubber cost and quality claims, with audit scope and methods fixed in advance of each gate.
- **Capital Stack and Sponsor Coalition:** Establish an industry resilience levy collected from tire makers and rubber traders into a ring-fenced fund that sits outside annual government budget cycles.

**The Decisive Factors:**

- **Protocol fit:** Embedding the SALB Containment Protocol in the IPPC and regional frameworks directly satisfies the non-negotiable, harmonized Phase 1 deliverable without sovereignty friction.
- **Plan-aligned technical path:** Genomic selection across broad Amazonian germplasm matches the Brazil-led, ABS-compliant breeding effort and builds durable resistance without regulatory exposure.
- **Commercial focus:** Concentrating on Guayule and Russian dandelion with a few colocated plants supports credible OEM offtake and commercial-scale delivery.
- **Gate credibility:** An independent auditor with fixed scope makes the Years 3/7/12/18 gates verifiable without stalling decisions.
- **Durable funding:** A ring-fenced levy protects a 25-year horizon from budget cycles.
- **Why not the others:** The Pioneer's Gambit adds governance friction, regulatory risk and diluted focus. The Prudent Consolidation relies on in-house evidence, off-plan crown-budding and pilot-only scale, which undercut verified containment and commercial offtake.

---
## Alternative Paths
### The Pioneer's Gambit
**Strategic Logic:** Maximizes speed and technological leadership: a program-funded authority with its own inspection powers, gene-edited resistance in parallel with conventional breeding, and a wide alternative-rubber portfolio judged by cost and quality gates. The most demanding evidence regime (audit plus adversarial red team) and outbreak-triggered capital keep the aggressive bets honest and funded, at the price of higher cost, regulatory exposure and governance friction.

**Fit Score:** 3/10

**Assessment of this Path:** A new program-funded authority conflicts with the plan's requirement to harmonize with existing phytosanitary standards and risks sovereignty objections that delay the Phase 1 deliverable. Gene-editing and a broad portfolio dilute the plan's focus on Hevea breeding plus Guayule and dandelion, and add regulatory exposure that smallholder-oriented adoption does not need.

**Key Strategic Decisions:**

- **Containment Protocol Authority:** Create a dedicated SALB Containment Authority funded by the program, with its own inspectors, audit rights over nurseries and research stations, and the power to suspend certification of non-compliant sites.
- **Resistance Breeding Pathway:** Pursue gene-editing and transgenic resistance in elite clones in parallel with conventional breeding, accepting regulatory approval work in exchange for a shorter route to deployable cultivars.
- **Alternative Rubber Portfolio Breadth:** Fund a wider portfolio that adds bio-based isoprene from fermentation and blended rubber formulations, treating Guayule and dandelion as two of several competing pathways judged by cost and quality gates.
- **Gate Evidence Verification Regime:** Combine third-party audit with adversarial review, in which a separately funded red-team group is tasked to find reasons a gate should not be passed and publishes findings alongside the evidence.
- **Capital Stack and Sponsor Coalition:** Structure part of the capital as an outbreak-triggered contingent facility, using catastrophe-bond-style instruments that release funds on confirmed SALB detection in a currently unaffected producing region.

### The Prudent Consolidation
**Strategic Logic:** Prioritizes cost control and proven mechanisms: the protocol rides on the existing IPPC system, crown-budding delivers field protection from existing clone material without regulatory approval work, and alternative crops are staged through pilots so fixed plant capital is committed only after thresholds are met. Evidence is compiled in-house under an advisory panel, and sovereign and development-bank money plus industry matching funds are released only as gates are passed, limiting exposure if early results disappoint.

**Fit Score:** 5/10

**Assessment of this Path:** Gate-conditional sovereign-plus-industry funding and IPPC embedding suit the plan, but crown-budding is not in the plan, internally compiled evidence weakens 'verified containment', and pilot-only staging undercuts the commercial-scale alternatives and the OEM offtake the plan requires.

**Key Strategic Decisions:**

- **Containment Protocol Authority:** Embed the protocol within the existing IPPC and regional plant protection organization framework, publishing it as a harmonized international standard that national agencies adopt through their normal regulatory processes.
- **Resistance Breeding Pathway:** Deploy crown-budding systems that graft a resistant leaf canopy onto high-yield panel clones, using existing clone material to deliver field protection years before fully bred cultivars are ready.
- **Alternative Rubber Portfolio Breadth:** Stage the alternatives through multi-region pilot farms and modular processing units, scaling only the crop-and-region pairs that meet agronomic and cost thresholds before committing fixed plant capital.
- **Gate Evidence Verification Regime:** Rely on program-internal technical teams to compile gate evidence, with a standing scientific advisory panel reviewing the reports and issuing recommendations to the funders' steering committee.
- **Capital Stack and Sponsor Coalition:** Anchor the program on sovereign and multilateral development bank commitments, with tire makers and OEMs adding matched contributions released only as each gate is passed.
