Persuasive elevator pitch.

# South American Leaf Blight (SALB) Global Containment and Resilience Program

## Project Overview

South American Leaf Blight threatens to collapse the global natural rubber supply, putting USD 650+ billion in tire and industrial-product markets at risk and devastating 3+ million smallholder livelihoods across five continents. This **25-year, USD 30 billion public-private program**—gated on verified results at Month 36 (2029-10-12), Month 84 (2033-10-12), Month 144 (2038-10-12), and Month 216 (2044-10-12)—delivers three binding outcomes: a global containment protocol, SALB-resistant Hevea cultivars with yield-parity durability, and commercial-scale alternative rubber (Guayule and Russian dandelion) with OEM offtake.

**Program structure**:

- **Phase 1 (Months 0–36, 2026-10-12 to 2029-10-12)**: Establishes the containment protocol in international law through the IPPC; deploys surveillance and incursion-response infrastructure.
- **Phase 2–5 (Months 36–300, 2029-10-12 to 2035-10-12)**: Deliver breeding, alternatives, smallholder adoption, and competitive supply, with funding gated at Years 3, 7, 12, and 18.

**Funding model**: Durable and gate-conditional. An **industry resilience levy** (USD 3.7 billion, approximately 12% of program total) plus sovereign and development-bank commitments (USD 26.3 billion, approximately 88%) secure the USD 30 billion cap. Tranches are released only when containment, cultivar readiness, and cost KPIs are independently verified. A USD 4.5 billion contingency reserve (15% of cap) is ring-fenced for technical overruns and climate re-siting.

## Target Audience

**Primary stakeholders**: Multilateral development banks, sovereign development ministries (Brazil, Indonesia, Thailand, Malaysia, Vietnam), large institutional investors and pension funds seeking climate and supply-chain resilience exposure. The pitch emphasizes **credibility and risk management**.

**Secondary stakeholders**: Tire makers and OEMs (who supply and verify offtake), national plant protection agencies and the FAO/IPPC (who embed and enforce the protocol), and large rubber traders. Messaging focuses on **compliance and offtake certainty**.

**Tertiary stakeholders**: Smallholder farmer cooperatives, extension research councils, and indigenous and traditional Amazonian communities. Outreach emphasizes **livelihood protection and benefit-sharing**.

## Risks and Mitigation Strategies

**Technical risks**:

- *Resistant Hevea misses yield KPIs by Month 48 (2030-10-12)*: Multi-site trials are pre-registered at 4 sites by Month 12 (2027-10-12). A crown-budding fast-track (about USD 0.25 billion (estimate), unbudgeted and funded from the USD 13.9 billion unallocated balance) is decided if yield penalty exceeds 15% at the Month 48 (2030-10-12) trigger; the steering council approves pre-authorisation by Month 9 (2027-07-12), before the Month 12 (2027-10-12) planting deadline.
- *Alternative rubber costs stay above 30% premium*: A portfolio decision at Month 60 (2031-10-12) determines whether to add processing-innovation capital or redirect funds to resistant-Hevea breeding if cost or process thresholds are missed.

**Institutional risks**:

- *Producer nations delay binding protocol adoption*: Bilateral MoUs are executed by Month 6 (2027-04-12). The program re-scopes if fewer than 3 of the top 5 producers have binding adoption by Month 54 (2031-04-12).

**Financial risks**:

- *Funding commitments erode through budget cycles*: A ring-fenced industry levy (USD 3.7 billion, approximately 12%) and binding 25-year framework agreements (by Month 12, 2027-10-12) with at least 5 institutional funders protect the funding envelope.

**Adoption risks**:

- *Smallholder uptake falls short*: Income-bridging finance (USD 6.75 billion) and a protected USD 400 million extension stream sustain adoption. A **stop trigger** halts expansion if enrollment falls below 30% by Month 84 (2033-10-12).

## Metrics for Success

**Month 36 (2029-10-12) — Year 3 Gate**:

- IPPC adoption vote held.
- Protocol binding in at least 3 of the top 5 producers.
- At least 100 inspectors active.
- Red-team drill detection accuracy at least 95%.
- No unmanaged incursions.

**Month 84 (2033-10-12) — Year 7 Gate**:

- Cultivar yield at least 90% of elite clones.
- At least 3 independent resistance sources stacked and confirmed in field trials.
- At least 30% of eligible smallholders enrolled in clean-plant networks (stop trigger if below 30%).

**Month 144 (2038-10-12) — Year 12 Gate**:

- Alternative rubber delivered cost under 30% above Hevea.
- At least 40% of eligible area replanted with resistant clones.
- Planning uptake target: 45% of eligible area (2.25 million hectares).

**Month 216 (2044-10-12) — Year 18 and Beyond**:

- Containment protocol enforced; resistant supply cascading.
- SALB contained globally.
- Smallholder income stable via price-floor guarantees and price-floor contracts.

**Verification governance**: Success is measured by independent auditor verdicts, not self-reporting. An external auditor is contracted by Month 3 (2027-01-12); scope and KPI definitions are pre-registered by Month 6 (2027-04-12); binding adjudication occurs within 60 days; verdicts are published within 30 days.

## Stakeholder Benefits

**Tire makers and OEMs**: Bankable, diversified supply reducing SALB and climate risk. OEM offtake contracts secure alternative-rubber margins and lock customers into resilience premium.

**Sovereign and development funders**: Proof of large-scale **resilience governance**. Gate-conditional release protects capital; smallholder adoption supports livelihoods in top-5 producers.

**Producing countries and plant protection agencies**: Protocol strengthens quarantine capacity without sovereignty friction (embedded in IPPC). Cultivar pipelines and alternative crops reduce farmer distress if SALB arrives. Trade protection without unilateral barriers.

**Smallholder farmers**: 

- Access to resistant planting material and income-bridging finance lowers replant risk.
- Price-floor guarantees (90% of Hevea benchmark) protect against commodity-price volatility.

**Indigenous and Amazonian communities**: 

- Benefit-sharing from germplasm use (USD 1–5 per hectare and royalty-free seed).
- Community seats in data trusts.
- DNA sequence and cultivar IP governed under Nagoya Protocol.

## Ethical Considerations

The program embeds **equity, consent, and transparency**:

**Access and Benefit-Sharing (ABS) Compliance**: Amazonian germplasm is accessed only under Brazil CGen permits and bilateral community benefit-sharing agreements (executed by Month 6, 2027-04-12). DNA sequences and cultivar traits are shared openly where possible (Research Knowledge Commons) to avoid locking smallholders into proprietary seed royalties.

**Smallholder Protection**: 

- Replanting finance is concessional (income-bridging, 60–70% coverage).
- Price floors are binding (90% of Hevea) to prevent exploitation when alternatives are new.
- Extension is locally owned (cooperatives, not parachuted cadres).

**Verification Independence**: Gate audits are contracted externally, not self-reported. Adverse findings are published. Dispute resolution is binding and impartial.

**Inclusive Governance**: Steering council includes producer-nation, OEM, funder, and farmer-representative voices. Community seats on data trusts. Transparent decision logs.

**Climate Fairness**: Alternative crops are sited on marginal or fallow land (not displacing food crops). Water-use modelling precedes Guayule expansion in arid zones. A climate re-siting reserve (USD 1.0–1.5 billion) is held for yield shocks.

## Collaboration Opportunities

**Rubber research institutes and universities**: IRRDB member institutes (Embrapa, Malaysian Rubber Board, Michelin research) supply germplasm, conduct multi-site trials, and publish breeding results via non-exclusive data-sharing agreements.

**Alternative-crop leaders**: Bridgestone (guayule in Arizona) and Continental/Fraunhofer (dandelion in Germany) are invited as co-investors and technology partners in wave 1 plants. Licensing of agronomy and processing IP.

**Regional plant-protection organizations**: APPPC, NAPPO, and EPPO co-author SALB protocol harmonization and lead national embedding with capacity-building grants.

**Smallholder networks**: Farmer cooperatives, extension research councils, and indigenous-federation seats on governance boards ensure adoption feedback and community benefit accountability.

**Climate and supply-chain initiatives**: Joining the Climate Resilience Initiative, the Global Resilience Initiative, and OEM sustainability consortia amplifies signals and attracts co-investment.

**Offtake and finance**: Banks and development finance institutions structure project finance for plants. OEMs write binding offtake contracts and reservation-fee instruments.

## Long-term Vision

By Month 300 (2035-10-12), the program achieves durable, **global supply-chain resilience**:

**Containment**: SALB containment is proven and enforced globally. Incursions are detected within 3 months, eradicated before spread, and compensated by program funds.

**Smallholder replanting and livelihoods**: Across the top 5 producers, 2.25 million hectares (45% of eligible area) are replanted with SALB-resistant, yield-parity Hevea. Income-bridging and price-floor mechanisms hold livelihoods stable through adoption and commodity cycles.

**Alternative rubber supply chains**: Guayule and Russian dandelion supply chains are commercially viable, delivering 32,000 tonnes per year (approximately 0.2% of global natural rubber) at costs within 15% of Hevea. Eight colocated plants across Arizona/Mexico and Germany/Benelux operate at scale.

**OEM diversification**: Tire makers source 10–20% non-Hevea rubber from alternatives plus resistant-Hevea supply, reducing supply-chain concentration and climate shock exposure.

**Community equity and stewardship**: Smallholder institutions own equity in processing plants and data trusts. Amazonian communities receive ongoing royalties and decision power on genomic resources.

**Institutional legacy**: The program's gate-gated governance and independent audits become the template for large-scale resilience programs in other crops (cacao, coffee, cocoa).

**Program transition**: By Year 25 (Months 300), the program cycles to local institutional ownership and self-financing from levy revenues. Donor capital is repaid or reinvested in Phase 5 scale.

## Call to Action

**Within 120 days**, the following commitments are required:

**Sovereign and development-bank funders**: Sign binding 25-year framework agreements locking at least USD 26.3 billion with gate-release mechanics. Binding agreements are due by Month 12 (2027-10-12).

**Tire makers and OEMs**: Issue letters of intent for alternative-rubber qualification trials and purchase options. At least 8 of the top 10 OEMs must commit by Month 12 (2027-10-12).

**Producer nations (Brazil, Indonesia, Thailand, Malaysia, Vietnam)**: Appoint leads for the SALB Containment Protocol Adoption Secretariat (FAO/IPPC) and execute producer-nation MoUs by Month 6 (2027-04-12).

**Auditor and scientific advisers**: Contract an independent verification regime by Month 3 (2027-01-12).

**Program administration timeline**:

- Steering council convenes at Month 0 (2026-10-12).
- Tranche 1 deploys in Month 1 (2026-11-12).
