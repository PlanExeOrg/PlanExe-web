Persuasive elevator pitch.

# South American Leaf Blight Resilience Program: 25-Year Global Rubber Supply Chain Defense

## Project Overview

**South American Leaf Blight (SALB)** threatens to cripple global tire supply and devastate millions of smallholder rubber farmers. This 25-year, USD 30 billion program deploys three reinforcing defenses anchored in binding international frameworks and verified gates:

- **Containment Protocol**: Enforced by national plant protectors and coordinated through the International Plant Protection Convention (IPPC)
- **SALB-Resistant Hevea Cultivars**: Scaled across 1.5 million smallholders with pyramided, durable resistance
- **Alternative Rubber Supply**: Guayule and Russian dandelion production breaking Hevea's monopoly

Funded through sovereign grants, development banks, and a ring-fenced industry levy, the program stages capital release through four verification gates that protect investment while accommodating biological timelines. Key delivery milestones include **operational, audited containment by Month 36 (2029-10-08)** (2029-10-08), **resistant-clone candidate readiness by Month 84 (2033-10-08)** (2033-10-08), with limited commercial release authorised from Month 84 (2033-10-08) so adoption can run to Month 144 (2038-10-08), and **200,000 tonnes of alternative rubber by Month 144 (2038-10-08)** (2038-10-08).

Unlike speculative alternatives or fragmented regional efforts, this pragmatic path anchors containment in the IPPC international framework, coordinates competing tire makers and producer governments in one secretariat, and embeds **smallholder finance and surveillance incentives from the start**. The result is a resilient, diversified rubber supply chain that survives SALB, protects farm livelihoods, and reduces tire-industry procurement risk for a generation.

## Target Audience

**Primary:** Multilateral development banks and sovereign government funders (5–8 nations committing by Month 3 = 2027-01-08), who need binding commitments and gated capital release. These audiences hear discipline, verified gates, and institutional capacity building.

**Secondary:** OEM tire and rubber-goods manufacturers (5–8 firms forming a buyer consortium), who need supply certainty and quality verification. These audiences hear de-risked supply, co-funded qualification, and sustainability credentials.

**Tertiary:** Producer-country governments and agricultural ministries (Brazil, Indonesia, Malaysia, Thailand, Côte d'Ivoire, Nigeria), who hold decision rights and must adopt the protocol into national law. These audiences hear institutional legitimacy, lasting inspection capacity, and technology-transfer partnerships.

**Quaternary:** Smallholder farmer organizations and cooperatives, who need finance, clean planting stock, and price stability. These audiences hear accessible income bridges, market linkage, and participation in governance.

The pitch avoids technical detail and focuses on what each stakeholder gains, without diluting the core message of **supply chain resilience**.

## Risks and Mitigation Strategies

### Major Risks

**IPPC Standard Adoption Delay**: Target Months 36–60 (2029-10-08 to 2031-10-08) could slip if producer-country consensus is slow.

- *Mitigation:* Run technical IPPC drafting in parallel with binding regional compacts by Month 24 (2028-10-08) as a fallback.

**Unpredictable Hevea Breeding Timelines**: Resistance could break if the pathogen evolves faster than projected.

- *Mitigation:* Pyramid 3+ genes from at least 2 geographic sources; enforce Virulence Gates every 12 months (Months 24, 36, 48, 60 = 2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08) to detect evolution early and trigger re-breeding if needed.

**Industry Levy Under-Collection**: The levy (targeting USD 270M/yr globally by Month 36 = 2029-10-08) faces cartel-coordination risk and may under-collect if trade compliance is below 60%.

- *Mitigation:* Pilot the levy at Month 18 (2028-04-08) in ASEAN and activate a funding cascade if pilot compliance is below 60% by Month 48 (2030-10-08)—higher bank lending, outcome-linked bonds, and climate-finance blend to close the gap.

### Secondary Risks

**Alternative-Rubber Cost-Parity Gate Failure**: The Month 84 (2033-10-08) cost-parity milestone may fail if guayule and dandelion extraction costs do not decline as expected.

- *Mitigation:* Defer hub construction to Months 96–120 (2034-10-08 to 2036-10-08) if committed offtake is under 80% at the Month 60 (2031-10-08) checkpoint; adds 1–3 years but no extra capex.

**Smallholder Adoption Languish**: Replant financing could stall if terms are unaffordable or surveillance incentives are too thin.

- *Mitigation:* Pre-design affordable finance (3–4% interest, 7–10 year tenor) and pilot surveillance premiums in 3–5 zones during Months 6–24 (2027-04-08 to 2028-10-08) with a target of at least 60% participation; scale with a capped budget of about USD 50M/yr (approximately USD 25–33 per participating farmer per year).

### Reserve and Contingency Strategy

- **Pre-fund the USD 0.5B outbreak response reserve by Month 3 (2027-01-08)** (2027-01-08); ceiling USD 1.0B for full SALB establishment response.
- **Hold the USD 4.5B contingency pool outside gating logic** to absorb simultaneous shocks (outbreak residual USD 1.5–4.5B, re-breeding USD 0.4–0.8B, alternative-rubber remediation USD 0.5–1.0B).
- **Adaptive tranches (not fixed pass-or-stop)**: Release 50–100% of each gate tranche based on proportional KPI attainment, buffering biological surprises and allowing proportional progress if targets are partially met.

## Metrics for Success

### Gate 1: Protocol Readiness (Month 36 = 2029-10-08)

- At least 15 producing countries with enforceable SALB import rules in national law
- At least 500 trained and audited inspectors (minimum by region: Asia 8, Africa 4, Americas 3)
- At least 2 laboratory-cleared suspect or near-miss detections in monitored zones
- Zero confirmed incursions in free regions

### Gate 2: Cultivar Readiness (Month 84 = 2033-10-08)

- At least 2 pyramded candidates with at least 90% resistance to contemporary pathogen isolates
- At least 85% of elite-clone yield (gate threshold; 'yield parity' is 90%, required by Month 144 (2038-10-08)), measured over 2+ years of trials
- Virulence-stable through Month 84 (2033-10-08) with a 5+ year stability forecast
- Release 70% of cultivar-phase tranche (50% if only 1 candidate); hold 30% for final trials

### Gate 3: Alternative Rubber Qualification (Month 84 = 2033-10-08)

- Pilot cost within 20% of Hevea reference (USD 1.62/kg, assuming USD 1.35/kg midpoint)
- Tire-grade quality match at 95%+ of Hevea specifications
- Binding priced offtake commitments for at least 80% of planned volume by Month 72 (2032-10-08)

### Gate 4: Supply Diversification and Institutional Durability (Month 216 = 2044-10-08)

- At least 5% of global demand (about 700,000 t/yr) alternative rubber commissioned and profitably operating (200,000 t/yr is the Month 144 (2038-10-08) milestone)
- At least 12 major producing countries maintaining verified, operational containment (floor within the 15–20 country scope)
- Cultivar area 500,000+ hectares
- Producer-country staff retention above 80%
- At least 1,000 certified national inspectors ready for handover
- Independent governance decisions upheld without political reversal

### Smallholder Adoption (Month 144 = 2038-10-08)

- At least 1.5 million smallholders replanted with certified resistant clones (50% of eligible population; stretch 60%)
- Loan repayment above 80%
- 300,000–500,000 farmers in surveillance networks earning quarterly premiums (USD 25–33/yr per participant, about 2–3% of latex income)

## Stakeholder Benefits

**Sovereign Governments and Development Banks** secure a diversified natural rubber supply critical to tire and automotive chains, recover USD 2–5B in avoided-loss value if SALB incursion is prevented, and build long-term agricultural institutional capacity in partner countries.

**Tire and OEM Manufacturers** de-risk supply chains, co-fund quality qualification (reducing private R&D cost), achieve sustainable-sourcing credentials, and reduce procurement volatility. The buyer consortium of 5–8 OEMs forms the commercial anchor for alternative-rubber offtake.

**Producer-Country Governments** gain protocol adoption into national law (institutional legitimacy), 1,000+ trained inspectors and border infrastructure (lasting after program funds end), and **technology-transfer partnerships** with Brazil and global breeding institutes. Lasting capacity outlives external funding.

**Smallholder Farmers** access low-interest replant loans (3–4%), income bridges during replanting years, guaranteed market for resistant clones through OEM offtake, and quarterly surveillance premiums (USD 25–33/yr per participant, about 2–3% of latex income). Finance is accessible and tied to certified clean planting stock.

**Brazilian Research Institutes** (Embrapa, CIRAD) hold germplasm-access rights and royalties, establish a global pathogen genomics lab by Month 2 (2026-12-08) and Asian satellite by Month 9 (2027-07-08), and anchor long-term breeding and monitoring capacity.

**Alternative-Crop Developers and Processors** gain **offtake certainty**, shared qualification testing, and patient hub-scale funding, reducing market risk. Revenue sharing from co-products (resin, inulin, bagasse) improves hub economics.

## Ethical Considerations

**Smallholder Participation as Design Principle**: Finance is accessible (3–4% interest, 7–10 year tenor), surveillance premiums are paid within 30 days, and smallholder voices sit on governance boards. Eligible population of 3 million smallholders is targeted for inclusion, not just large estates.

**Nagoya Protocol Access-and-Benefit-Sharing**: Formal ABS agreements are negotiated with Brazil and indigenous/traditional communities by Month 6 (2027-04-08), with benefit-sharing tied to cultivar royalties and rubber sales. Genetic-resource holders share gains proportionally.

**Distributed Nursery Network**: Clean-plant nurseries are designed for dispersed smallholders, reaching 80% of eligible zones in endemic regions (Sumatra, Côte d'Ivoire, northeast India, Rondônia).

**Pre-Funded Contingent Liabilities**: SALB eradication costs (tree removal, farmer compensation) are pre-funded outside gating logic (USD 0.5B standing reserve, ceiling USD 1.0B), so compensation is not starved if gates delay funding.

**Open Pathogen Science**: Pathogen genomics data and trial protocols are published annually and archived in open repositories post-program, advancing the scientific commons and enabling other crops and regions to benefit.

**Environmental Stewardship**: Guayule and dandelion sites are restricted to water-efficient zones and arid/temperate regions where they displace no food crops. Co-product revenue is valued to improve hub economics rather than treated as waste, enhancing sustainability.

**Governance Safeguards**: No single funder controls board decisions (no entity above 25% of capital). Producer governments hold 6–8 of 15 secretariat board seats, and Technical Panel members are conflict-free, ensuring decisions are not captured by any faction.

## Collaboration Opportunities

**IPPC Secretariat and National Plant Protection Organizations**: Co-develop the standard proposal targeting Month 18 (2028-04-08), embed inspector training into the program, and transition protocol enforcement to national phytosanitary systems by Month 216 (2044-10-08).

**Embrapa and CIRAD**: Lead the Brazil pathogen genomics lab (live-pathogen station by Month 2 = 2026-12-08), supply germplasm accessions and breeding knowhow, establish twinning partnerships with Asian and African research institutes (Asia satellite by Month 9 = 2027-07-08) for sustained capacity.

**CGIAR and International Agricultural Research Centers**: Contribute germplasm screening, agronomy protocols for guayule and dandelion, and long-term monitoring of cultivar performance and pathogen evolution.

**Tire-Maker Buyer Consortium**: Convenes by Month 6 (2027-04-08); co-fund qualification testing for alternative rubber (Months 12–30 = 2027-10-08 to 2029-04-08), sign priced offtake agreements (targeting binding letters of intent by Month 18 = 2028-04-08 and full commitment by Month 72 = 2032-10-08), nominate board representatives, and form the commercial anchor for hub financing.

**Regional Development Banks and Climate-Finance Facilities**: Green Climate Fund, World Bank GRMF, and other concessional lenders blend outcome-linked instruments and climate-linked facilities alongside the core USD 30 billion budget, reducing public burden.

**Smallholder Organizations and Farmer Networks**: ISCO, smallholder networks in Sumatra, Côte d'Ivoire, and India co-design surveillance-premium schemes and replant-finance terms; nominate farmer representatives to governance boards.

**GPSNR and Existing Natural Rubber Platforms**: Host discussions about levy design and OEM coordination, avoiding duplication and leveraging existing stakeholder relationships.

**Academic and Genomics Partners**: Contribute molecular-marker development, pathogen-evolution modeling, and long-term monitoring of virulence and resistance durability.

## Long-term Vision

By Month 216 (2044-10-08), the program establishes a **resilient, diversified natural rubber supply**:

- **At least 5% of global demand (about 700,000 t/yr) from guayule and dandelion rubber** reduces Hevea dependence and breaks the crop monopoly that SALB exploits; 200,000 t/yr is the Month 144 (2038-10-08) milestone.
- **SALB containment operationalized** in 12+ producing countries within national phytosanitary systems, no longer dependent on external funding or expertise; 1,000+ trained inspectors and three regional pathogen-genomics centers ensure early detection and rapid response.
- **Resistant Hevea cultivars occupy 500,000+ hectares**, embedding durable polygenic resistance with a 5+ year virulence-stability forecast that is projected to hold for decades.
- **Multilateral secretariat transitions to light-touch governance or dissolves**, with decision rights vested in national agricultural authorities and a standing IPPC technical body. Long-term governance responsibility returns to national governments.
- **Smallholder replant finance becomes a national credit program or cooperative network**, no longer grant-dependent; loan repayment above 80% enables institution-building.
- **Alternative-rubber hubs are privatized or held under long-term concessions** by producer cooperatives, financially self-sustaining through offtake contracts and co-product revenue.
- **The 25-year program (USD 30 billion hard cap) is resilience insurance, not a payback case**: avoided-loss value (USD 2–5B per prevented incursion) offsets only part of the cost.

**Lasting Legacy**: A governance architecture for agricultural supply-chain resilience that other crops (cocoa, coffee, cassava facing multiple threats) can replicate. Smallholders, producer governments, and research institutes gain permanent institutional capacity; tire makers gain a century of de-risked procurement.

## Call to Action

### Immediate Commitments (Month 3 = 2027-01-08)

Secure your seat at the founding secretariat:

- **Sovereign governments and development banks** commit binding multi-year capital by Month 3 (2027-01-08)
- At least 5–8 sovereign nations and 2+ multilateral development banks formalize commitments; no single funder holds more than 25% of capital (USD 7.5B)
- Technical Gate Charter signed by Month 3 (2027-01-08) to establish conflict-free Technical Panel governance

### Build the Buyer Consortium (Month 6 = 2027-04-08)

- **OEM buyer consortium convenes** by Month 6 (2027-04-08) with 5–8 tire and rubber-goods manufacturers
- OEMs nominate board representatives to the secretariat
- Co-funded qualification testing for alternative rubber begins Months 12–30 (2027-10-08 to 2029-04-08)

### Regional Adoption (Month 24 = 2028-10-08)

- Brazil, Indonesia, Malaysia, and Thailand sign binding regional compacts by Month 24 (2028-10-08)
- At least 15 producing countries commit to enforceable national SALB import rules
- Inspector recruitment and training infrastructure launched

### International Standard (Month 18 = 2028-04-08)

- IPPC formal standard proposal launches at Month 18 (2028-04-08)
- Formal IPPC adoption expected Months 36–60 (2029-10-08 to 2031-10-08)

### First Protocol Enforcement Gate (Month 36 = 2029-10-08)

- First protocol enforcement gate arrives at Month 36 (2029-10-08)
- Verification of 15 producing countries, 500 trained inspectors, and 2+ laboratory-cleared detections

### Urgent 90-Day Priorities

**Funder alignment must close, and a Brazil benefit-sharing framework must be drafted with a negotiating team in place, in the next 90 days** to meet the Phase 1 envelope (USD 6.0B for Months 0–36 = 2026-10-08 to 2029-10-08).

**Contact the program secretariat coordination team immediately** to:

- Nominate board representatives (producer governments, OEMs, development banks, independent experts)
- Confirm multi-year capital commitments
- Secure Brazil's formal germplasm-access agreement (ABS/Nagoya protocol)
- Establish technical working groups for IPPC drafting and trial-station siting

**The window for shaping this 25-year architecture closes by Q1 2027.** Early movers secure board seats, co-design governance, and anchor the secretariat. Late arrivals join as secondary contributors.