## 1. SALB Containment Protocol Legal Architecture and Binding Adoption Verification

The non-negotiable Phase 1 deliverable is a globally adopted SALB Containment Protocol harmonized with IPPC frameworks. Verification of adoption (≥15 countries, enforceable rules, ≥500 inspectors) is the Month 36 (2029-10-08) gate trigger. If countries adopt but do not enforce (zero inspectors, no equipment), the gate is a false positive and USD 4.5B is released on empty infrastructure.

### Data to Collect

- Formal IPPC standard-setting proposal text and adoption timeline from IPPC Secretariat
- Binding commitment letters from ≥15 producing countries confirming national phytosanitary-law amendments within 12 months of IPPC approval
- Regional compact agreements (Asia, Africa) with reciprocal inspection rights and quarantine-zone definitions signed by ≥8 countries per region
- National plant protection organization capacity-baseline assessments (current inspector counts, diagnostic lab throughput, equipment inventory) in all 15+ target countries

### Simulation Steps

- Use IPPC.int standard-setting calendar and FAO/IPPC Implementation Review database to model formal adoption timeline (typically 18–36 months from proposal to Commission decision)
- Map regional phytosanitary frameworks (ASEAN, ECOWAS, Mercosur) in public documents; identify harmonization gaps with proposed protocol language via document comparison (IPPC standards library, regional organization websites)
- Model inspector-ramp trajectories using historical capacity-building data from comparable phytosanitary programs (e.g., CGIAR plant-health initiatives, FAO Technical Assistance projects) to forecast whether ≥500 inspectors are achievable by Month 36 (2029-10-08)
- Simulate tranche-release impact if Year 3 gate is not met: model 70% attainment scenario (12 countries, 400 inspectors, 1 detection) on a 25-year funding stream using NPV and IRR calculators

### Expert Validation Steps

- Consult IPPC Secretariat (Secretariat.IPPC@fao.org, Rome) to confirm topic-submission procedures, standard-setting timeline and likely adoption date
- Engage ≥3 major producing-country plant protection organizations (Brazil MAPA, Indonesia Ministry of Agriculture, Côte d'Ivoire MINADER) to validate commitment-letter achievability and legal harmonization feasibility
- Commission independent legal review by international trade law specialists (e.g., UNCTAD, World Bank Legal) to assess enforceability of protocol language across sovereign jurisdictions
- Convene a technical working group with FAO, regional plant protection organizations (ASEAN Secretariat, ECOWAS) and at least 5 producer governments to draft model regional-compact language

### Responsible Parties

- Phytosanitary Standards and Protocol Lead (primary negotiator with IPPC Secretariat and producing countries)
- Brazil's Ministry of Agriculture (MAPA) and leading rubber-producing countries' plant protection organizations
- Multilateral Secretariat Executive Director (governance coordination)
- Regional plant protection organizations (ASEAN, ECOWAS, Mercosur secretariats)

### Assumptions

- **High:** IPPC formal standard adoption is achievable by Months 36–60 (2029-10-08 to 2031-10-08), matching the protocol-readiness gate window. If adoption slips to Month 72+ (2032-10-08+), the fallback is binding regional compacts by Month 24 (2028-10-08), creating a two-tier containment regime.
- **High:** ≥15 producing countries will embed the protocol into national phytosanitary law within 12 months of IPPC approval, driven by conditionality (program funding tied to adoption). If adoption is voluntary, fewer than 10 countries formalize the protocol and containment effectiveness drops 40–60%.
- **High:** National plant protection organizations can recruit, train and retain ≥500 inspectors by Month 36 (2029-10-08), given USD 3–5B allocated to capacity building. Weak-link countries (West Africa, South Asia) face baseline shortages of <50 inspectors and high staff turnover; achieving targets requires concurrent salary and career-path improvements funded by program.
- **Medium:** Regional compacts (Asia, Africa) can be negotiated and signed by Month 24 (2028-10-08), serving as interim containment layer during formal IPPC adoption. Negotiations depend on political goodwill and perceived SALB threat, both uncertain in free regions.

### SMART Validation Objective

By Month 24 (2028-10-08), collect formal IPPC proposal text, ≥15 country commitment letters, and regional compact drafts. By Month 36 (2029-10-08), verify ≥15 countries have enforceable import rules (confirmed via national gazette publication, plant protection organization directive, or trade regulation amendment), ≥500 audited inspectors are operational (verified by independent third-party inspection audits at ≥20 checkpoints per region), and ≥2 documented interceptions or lab-cleared suspects are logged. Measure gate attainment as (countries_with_rules/15) × (inspectors_operational/500) × (detections/2); pass gate if attainment ≥85%.

### Notes

- IPPC standard adoption may slip 12–24 months beyond initial forecast due to consensus requirements; fallback regional compacts must be signed by Month 24 (2028-10-08) to keep Year 3 gate on track.
- Weak-capacity countries (West Africa, South Asia) are likely to require co-financing of inspector recruitment and equipment; budget increases of USD 1–2B within the containment pillar may be necessary if baseline country commitments are underfunded.
- Digital reporting platform (SMS-based, offline-capable) is essential for remote inspectors in dispersed smallholder zones; technical specifications and pilot deployment by Month 12 (2027-10-08) are prerequisites for scaling inspections.
- Legal harmonization conflicts may arise if producing countries resist binding protocol language; model legislation and technical working group facilitation required early (Months 1–6 = 2026-11-08 to 2027-04-08) to build consensus.
- Post-gate risk: if Month 36 (2029-10-08) gate results in <85% attainment (e.g., 12 countries with rules, 400 inspectors, 1 detection), adaptive-tranche release of 50–75% of the USD 4.5B tranche may under-fund Years 4–7 breeding and alternative-rubber work, cascading delays.


## 2. SALB Pathogen Population Genomics and Virulence Tracking for Resistance-Durability Assurance

Single-gene resistance historically fails within 5–10 years once pathogen virulence evolves (30–50% probability by Year 12–15, estimate). Continuous pathogen genomics and mandatory Virulence Gates at Months 24, 36, 48, 60 (2028-10-08 to 2031-10-08) are the only mechanisms to detect pre-existing or emerging virulent biotypes and prevent deployment of 'time-bomb' cultivars. Without this, Year 7 release results in Year 12–15 breakdown, requiring USD 400–800M re-breeding and forfeiting resilience claims.

### Data to Collect

- Annual SALB isolate collections (≥100–150 per year) from endemic trial sites, traded plant material and surveillance samples, with GPS/collection-date metadata
- Whole-genome sequencing and virulence-gene annotation data for all isolates (Months 12–300 = 2027-10-08 to 2046-10-08, cumulative database ≥1,500–3,000 isolates)
- Virulence-phenotype challenge results (candidate cultivars tested against ≥10 contemporary isolates per Virulence Gate at Months 24, 36, 48, 60 = 2028-10-08 to 2031-10-08) with infection-rate scores and incompatibility ratings
- Virulence-gene frequency trends across geographic regions and time periods; pathogen population structure (phylogenetic relationships, clonal vs. sexual reproduction)

### Simulation Steps

- Use publicly available SALB/Pseudocercospora ulei genomic data (NCBI GenBank, Ensembl Fungi) to build a baseline reference genome and annotate known virulence loci; simulate high-throughput SNP-calling workflows using Illumina short-read data on trial isolates
- Model resistance-breakdown probability over 25 years using Gillespie stochastic-simulation algorithms, parameterized by virulence-gene frequency, mutation rate, and host-population selection pressure; compare single-R-gene vs. multi-gene pyramiding survival curves
- Simulate Virulence Gate decision logic: for each candidate cultivar, generate 10 random isolate samples from the pathogen population distribution; score cultivar as 'pass' if resistant to ≥80% of isolates; iterate 100 times to estimate gate-pass probability under population uncertainty
- Use historical Hevea cultivar-failure data (CIRAD, Embrapa archives) to calibrate baseline breakdown rates (~30–50% for single-R-gene by Year 10–15); validate stochastic model against observed timelines

### Expert Validation Steps

- Engage Brazil-based mycologists and Hevea pathologists (CEPLAC, Embrapa rubber research units) to finalize isolate-collection protocols, DNA-extraction methods and sequencing strategy; establish quality-assurance standards for diagnostic accuracy
- Consult international mycology and plant-pathogen-genomics experts (e.g., BGRI—Borlaug Global Rust Initiative; international committees) to validate SNP-calling, phylogenetic-inference methods and virulence-phenotype scoring against scientific standards
- Coordinate with the Hevea Resistance Breeding Program Director to ensure Virulence Gate protocols integrate seamlessly into breeding-cycle timelines and gate-advancement rules; specify pass/fail thresholds and appeal mechanisms
- Commission independent model validation: external mycology/epidemiology consultant reviews stochastic-simulation code, parameter inputs and outputs; compares model predictions against historical Hevea-SALB epidemiological data

### Responsible Parties

- Pathogen Genomics and Virulence Tracking Scientist (Brazil and Asia lab directors)
- Hevea Resistance Breeding Program Director (integration into breeding decisions)
- Technical Panel members specializing in plant pathology and genomics
- Brazil's CEPLAC and Embrapa, Asian rubber research institutes (Malaysia, Indonesia)

### Assumptions

- **High:** Pathogen genomics lab in Brazil can be operationalized by Month 2 (2026-12-08) with sequencing capacity ≥100–150 isolates/year; Asian satellite by Month 9 (2027-07-08). If lab construction or staff recruitment slips >6 months, first Virulence Gate at Month 24 (2028-10-08) lacks baseline virulence data and cannot be credibly executed.
- **High:** Virulence-gene frequency and geographic differentiation can be inferred from ≥100–150 isolates per year via whole-genome sequencing and SNP-calling; statistical power is sufficient to detect emerging virulent biotypes within 12 months of their appearance in the pathogen population. If virulence evolution is faster or more complex than models predict, gate decisions may be made on incomplete evidence.
- **High:** Virulence Gates at Months 24, 36, 48, 60 (2028-10-08 to 2031-10-08) are binding and enforceable: breeding teams cannot release single-R-gene or weakly pyramided cultivars even if field trials show short-term resistance. This requires Technical Gate Charter language making Virulence Gate evidence a non-negotiable sub-criterion; without binding authority, breeders facing time pressure may rationalize release on field data alone.
- **Medium:** Stochastic-simulation models of resistance durability are calibrated using historical Hevea-SALB data (available from CIRAD, Embrapa); parameters (mutation rate, virulence-gene frequency, selection pressure) are representative of future pathogen evolution. Unknown pathogen drivers or rapid evolution could invalidate model predictions.

### SMART Validation Objective

By Month 12 (2027-10-08), pathogen genomics lab (Brazil) is commissioned and first isolate-sequencing workflow is complete (≥50 isolates sequenced, quality-assured). By Month 18 (2028-04-08), baseline virulence-gene frequencies are published, and 10-year durability forecasts are available for early breeding candidates. By Months 24, 36, 48, 60 (2028-10-08 to 2031-10-08), each Virulence Gate is executed: ≥3 candidate cultivars are challenged against ≥10 contemporary isolates; pass threshold (≥80% incompatible phenotype) is met or not met, with documented rationale. By Month 84 (2033-10-08) Year 7 gate, all released cultivars have passed all prior Virulence Gates and carry ≥5-year virulence-stability forecast with ≤20% breakdown risk.

### Notes

- Pathogen sequencing cost ~USD 50–100 per isolate (whole-genome, high coverage); annual budget USD 500K–1M per lab covers sequencing, staffing and bioinformatics. Budget must be stable and non-contingent on gate funding to maintain continuous virulence tracking through the 25-year horizon.
- Virulence-phenotype testing (inoculation assays, infection scoring) requires high-containment biosafety level 3 facilities in both Brazil and Asia; these are costlier than sequencing alone (USD 2–5M per facility, USD 100K–200K annual operations). Facility construction must begin by Month 0 (2026-10-08).
- Data-sharing agreements among Brazil, Asian partners, and international breeding consortiums are essential to ensure all breeders access virulence data and Virulence Gate evidence. Open-science publication (6-month embargo post-generation) balances competitive breeding interests with collective resistance durability.
- If an incursion occurs and the pathogen is detected in Asia/Africa, isolate characterization from the invasion front is critical to understand virulence profile and inform emergency cultivar deployment; pre-positioned sequencing capacity and trained staff in Asia are prerequisites.
- Post-gate risk: if Month 24 (2028-10-08) or 36 (2029-10-08) Virulence Gates show that top-performing field candidates carry latent virulent-biotype susceptibility, breeding candidates are held back and pyramiding timelines slip 6–12 months; contingency USD 500M–1B should be earmarked for breeding-phase extension and reduced Year 7 cultivar readiness (e.g., 1 candidate vs. 2).


## 3. Smallholder Surveillance Participation and Outcome-Based Premium Incentive Validation

Containment depends on early detection of SALB incursions in smallholder zones; undetected incursion in 2–3 million small-farm hectares escalates to USD 1–3B outbreak response cost. Baseline smallholder surveillance participation is 20–40% without aligned incentives; farmers conceal infections if reporting triggers quarantine without offsetting income. Outcome-based premiums (USD 50–100 per verified report) convert reporting from a compliance burden into an income opportunity, raising participation to ≥60% and enabling early detection at <10,000 hectares, reducing response cost by 80% (estimate).

### Data to Collect

- Baseline farmer-participation rates and incentive sensitivity in 3–5 pilot zones (Sumatra, Côte d'Ivoire, northeast India, Rondônia, optional fifth): enumerative survey of 500–1,000 farmers per zone assessing willingness-to-report, income levels, price sensitivity, prior credit/savings experience
- Premium-payment velocity and accuracy data: timeliness of payment after sample submission (target 30 days), percentage of farmers receiving payment within target window, payment-system costs (mobile transfer fees, logistics)
- Surveillance-sample collection and diagnostic-lab turnaround data: number of verified disease reports per month per zone, laboratory processing time (GPS to result notification), false-positive rate, cost per sample processed
- Adoption of clean-plant networks and replanting finance conditional on premium participation: linkage between surveillance participation and clean-plant-material access, loan uptake rates, repayment timelines

### Simulation Steps

- Model farmer income and incentive using published agricultural-economics data (World Bank rural-income surveys, CGIAR adoption studies); simulate scenario where premium of USD 50/report represents 5–10% of annual smallholder latex income; iterate premium amount to identify breakeven participation rate (target ≥60%)
- Use agent-based modeling software (e.g., NetLogo, AnyLogic, or custom Python) to simulate farmer disease-reporting behavior under alternative incentive structures (income premium, fair-quarantine clause, clean-plant access, price-floor guarantee); vary parameters (risk aversion, income volatility, social-norm adoption) to forecast participation distribution
- Simulate mobile-payment platform performance: model SMS delivery reliability (assume 95% delivery in pilot zones with low-bandwidth constraints), payment-system latency (2–5 day bank processing), and farmer trust-building as a function of payment timeliness (faster payment = higher repeat reporting)
- Forecast early-detection sensitivity by zone: model incursion probability, detection lag (weeks from incursion to farmer report), and incursion-response cost as a function of participation rate; compare USD cost per early detection at 60% participation vs. 30% participation

### Expert Validation Steps

- Engage smallholder farmer cooperatives and community leaders in pilot zones (Sumatra Smallholder Rubber Association, Côte d'Ivoire Agricultural Cooperative Network, northeast India farmer groups, Rondônia rubber-tapper associations) to validate baseline income/incentive assumptions and cultural acceptability of premium structure
- Consult development economists and behavioral specialists (World Bank, CGIAR CCAFS—Climate Change, Agriculture and Food Security program) to review incentive-mechanism design; validation targets include participation elasticity (response to premium-rate changes) and social-norm effects (spillover adoption within farmer networks)
- Partner with mobile-money operators active in rubber zones (e.g., M-Pesa in East Africa, mobile operators in Indonesia) to validate payment-platform feasibility, transaction costs and farmer familiarization with SMS-based transfers
- Commission baseline behavioral survey (participatory workshops, focus-group discussions) with 50–100 farmers per zone (Months 2–3 = 2026-12-08 to 2027-01-08) to validate income assumptions, quarantine-loss estimates, and acceptable premium levels before pilot rollout

### Responsible Parties

- Smallholder Adoption and Surveillance-Incentive Designer (program and pilot lead)
- Farmer organizations and cooperative leaders in pilot zones
- Mobile-money operators and payment-system providers
- Regional diagnostic laboratories and sample-collection networks

### Assumptions

- **High:** Farmers will report disease if compensated USD 50–100 per verified sample and payment is received within 30 days; baseline participation is expected to rise from 20–30% (historical average without premium) to ≥60% (with outcome-based premium). This assumes income is the binding constraint, not social stigma or fear of quarantine.
- **High:** Mobile-payment platforms (SMS-based transfers via mobile money) are operationally reliable in pilot zones (Sumatra, Côte d'Ivoire, northeast India) and payment turnaround is achievable within 30 days. If payment delays exceed 45 days or system failures occur >10% of the time, farmer trust erodes and participation drops to <40%.
- **High:** Fair-quarantine compensation rules (farms reporting disease receive automatic income-bridge payment if quarantined) remove the disincentive for reporting. Without this rule, farmers rationally conceal infection to avoid quarantine, negating the premium mechanism.
- **Medium:** Clean-plant-network access is conditional on ≥90% farm-level clean-plant practices (verified quarterly via mobile GPS-photo verification) and premium participation history. This creates a self-reinforcing adoption cycle: surveillance participation → income premium → access to subsidized material and credit → adoption of resistant cultivars and clean practices.

### SMART Validation Objective

By Month 18 (2028-04-08), complete 3–5 pilot zones with 500–1,000 farmers enrolled per zone. Measure: (1) participation rate (≥60% of enrolled farmers report ≥1 suspected sample during pilot window); (2) payment velocity (≥95% of payments delivered within 30 days); (3) sample diagnostic accuracy (≥95% of reported samples processed and confirmed/rejected by lab within 14 days); (4) clean-plant-network linkage (≥70% of regular reporters access clean-plant nurseries or credit by end of pilot). If these thresholds are met, commit to scaling to 2–3 million farmers by Month 120 (2036-10-08).

### Notes

- Pilot cost is estimated at USD 10–25M (USD 2K–5K per farmer × 1,500–5,000 pilot farmers, including farmer incentive payments, mobile platform, diagnostic lab access, staff, and monitoring). This is budgeted within the USD 4.5B smallholder-finance pillar.
- Contingency: if pilot participation falls below 40% by Month 12 (2027-10-08), trigger incentive redesign (increase premium to USD 100–150/sample, or pivot to income-bridge grants instead of outcome-based premiums), adding USD 5–10M to pilot budget and delaying scale-up decision by 6 months.
- Surveillance premium scaling to 2–3 million farmers costs approximately USD 50M/yr (at USD 100–200 per farmer per year); this is 25–50% of the USD 100–200M annual smallholder-finance allocation and competes with replant-loan capital and price-stability tools. Budget trade-offs must be explicit.
- Post-gate risk: if Year 3 gate (Month 36 = 2029-10-08) passes but smallholder surveillance participation remains <40%, the Year 7 gate (Month 84 = 2033-10-08) and Year 12 gate (Month 144 = 2038-10-08) targets for adopter numbers (1.5 million) may be unachievable, undermining supply-chain resilience narrative.
- Climate and behavioral heterogeneity: farmer participation may be highly skewed by household wealth, education and proximity to extension services. Wealthier 20–30% of smallholders likely achieve 80%+ participation; poorer 40–50% may stabilize at <30% participation even with incentives. Program design must account for this 'adoption tail' and consider complementary income-safety mechanisms for excluded farmers.


## 4. Alternative-Rubber (Guayule and Russian Dandelion) Cost-Parity and Tire-Grade Quality Validation at Commercial Pilot Scale

The Year 7 gate (Month 84 = 2033-10-08) requires alternative-rubber pilot cost ≤USD 1.62/kg (20% premium vs. Hevea USD 1.35/kg reference) and tire-grade quality ≥95% of Hevea specs. Without validated cost-parity and OEM qualification, hub financing fails (coverage <1.0x at 50% program-debt split), and commercial plants cannot be approved. Unvalidated assumptions will cause Month 84 (2033-10-08) gate failure, stranding USD 1–2B in early pilot capex and delaying supply diversification to Years 15–20.

### Data to Collect

- Guayule pilot agronomic data: yield (t/hectare of rubber), latex content (%), water use (ML/hectare), pest/disease incidence, input costs (seeds, fertilizer, pesticides, labor) from 3–4 pilot sites (Sonora, Arizona, Argentina) across growing seasons Months 1–60 (2026-10-08 to 2031-10-08)
- Russian dandelion pilot agronomic data: root yield, root rubber content (%), growing-season length, cold-stress tolerance, herbicide requirements, input costs from 2–3 pilot sites (Russia, northern Europe, temperate South America) across Months 1–60 (2026-10-08 to 2031-10-08)
- Processing opex data: extraction cost per tonne, refining cost, equipment utilization (%), co-product yield (resin %, bagasse %, inulin %), co-product market prices (resin USD/kg, inulin USD/kg) from pilot plants processing 5,000–20,000 t/yr
- Tire-grade quality test results: Mooney viscosity, tensile strength, tear resistance, aging characteristics, hysteresis (heat generation) for rubber and tire prototypes; comparison against Hevea-baseline specifications; number of OEM tires successfully tested with alternative rubber

### Simulation Steps

- Use agronomic-modeling software (APSIM, DSSAT, or crop-model modules for guayule and dandelion) to simulate yield under alternative climate/management scenarios; parameterize models with pilot field data (soil, rainfall, temperature from sites); project 5-year yield stability and sensitivity to climate variability (drought, frost)
- Build cost-accounting spreadsheet models (target USD 1.62/kg opex by Month 84 = 2033-10-08) combining: plant-gate rubber value (USD 1.35–1.55/kg reference, with 15% premium assumption), extraction/processing cost (USD 0.25–0.40/kg, estimate), labor (USD 0.10–0.15/kg), equipment depreciation (USD 0.15–0.20/kg), overhead (USD 0.05–0.10/kg). Stress-test cost model under yield shortfall (−20%, −40% scenarios) and input-price inflation (+10%, +25% scenarios)
- Simulate tire-manufacturing integration: model Hevea vs. alternative-rubber performance in tire compounds (mixing ratios, curing times, processing windows); forecast quality-control rejection rates and processing-cost deltas (alternative rubber may require equipment modifications)
- Use Monte-Carlo simulation (≥1,000 iterations) to estimate probability distribution of commercial-hub opex at Year 10–12 commissioning (Months 120–144 = 2036-10-08 to 2038-10-08), accounting for parameter uncertainties (yield, input cost, co-product price); quantify cost-at-risk (5th/25th/median/75th/95th percentiles)

### Expert Validation Steps

- Engage Bridgestone Americas (Guayule Research Center, Eloy, Arizona) and Continental Taraxagum program (Anklam, Germany) to provide access to pilot-plant data, processing know-how, and tire-testing results; validate cost assumptions and quality-trajectory forecasts against their operational experience
- Commission independent agronomic expert review (USDA NRCS guayule specialists, Julius Kühn Institute Russian dandelion researchers) to validate pilot-site selection (water availability, soil suitability, climate match) and forecast multi-season yield stability
- Engage major tyre manufacturers (5–8 OEMs) to specify tire-grade material requirements (Mooney viscosity range, tensile strength, aging behavior); commission third-party tire-testing labs (Smithers Rapra, Kumho Tire R&D) to validate that pilot-scale rubber meets OEM specs; quantify quality-control cost impact
- Consult commodity-price analysts (Rabobank, Wood Mackenzie) to forecast future natural-rubber, synthetic-rubber and co-product prices; model hub profitability under price scenarios (Hevea at USD 0.80/kg, USD 1.20/kg, USD 1.60/kg by Month 120 = 2036-10-08)

### Responsible Parties

- Alternative Rubber (Guayule and Russian Dandelion) Commercial Lead (pilot sites and processing oversight)
- Bridgestone Americas Guayule Research, Continental Taraxagum program (industry expertise and data sharing)
- OEM buyer consortium (tire-grade specification, qualification testing)
- USDA, Fraunhofer IME, Julius Kühn Institute (agronomic validation)

### Assumptions

- **High:** Guayule and Russian dandelion can be cultivated at commercial yield (8–12 t/hectare Guayule, 6–10 t/hectare dandelion root) with rubber content 10–15% by Year 7 pilots (Months 48–84 = 2030-10-08 to 2033-10-08). If yields are 20–30% lower than pilot projections, opex rises to USD 1.90–2.20/kg, exceeding gate threshold.
- **High:** Processing cost (extraction, refining) can reach USD 0.25–0.40/kg opex by Year 7, down from estimated USD 0.40–0.60/kg at pilot scale, via equipment efficiency gains and scale economies. If processing cost remains >USD 0.50/kg at commercial scale, total opex exceeds gate threshold.
- **Medium:** Co-products (resins, bagasse, inulin) can be monetized and contribute USD 0.05–0.10/kg opex offset by Year 7–12. If co-product markets do not develop (inulin demand is thin; resins and bagasse oversupply existing markets), co-product revenue is zero and hub opex increases by USD 0.05–0.10/kg.
- **High:** Pilot-scale tires manufactured with guayule and dandelion rubber pass OEM specifications with ≥95% of Hevea baseline performance, requiring <20% processing-cost delta (mixing, curing, equipment adjustments). If quality gaps are >20%, OEM acceptance is delayed 2–3 years and take-or-pay offtake commitments are not signed.

### SMART Validation Objective

By Month 30 (2029-04-08), pilot sites in guayule and dandelion zones have completed 2–3 growing seasons; agronomic yield and quality data are compiled and analyzed. By Month 60 (2031-10-08), pilot processing plants (5,000–20,000 t/yr) have operated for 18–24 months, generating cost and co-product data; preliminary cost is forecast ≤USD 1.80/kg (within 11% of gate threshold). By Month 72 (2032-10-08), tire prototypes using pilot-scale rubber are tested by OEMs and pass ≥95% of Hevea specs in ≥80% of test protocols. By Month 84 (2033-10-08) Year 7 gate, cost is within USD 1.47–1.62/kg range and OEM qualification is complete, enabling hub construction approval for commissioning by Month 120 (2036-10-08).

### Notes

- Pilot-plant capex (5,000–20,000 t/yr processing unit, manual labor-intensive) is estimated at USD 30–50M per site; full commercial hubs (200,000 t/yr, 2 Guayule + 2 dandelion) are estimated USD 250–350M total (USD 60–80M per hub). Large capex swing from pilot to commercial demands clear evidence of cost trajectory before approving hub construction.
- Guayule and dandelion cultivation depend on water availability (guayule in semi-arid zones, dandelion in temperate) and climate stability. Drought or extreme frost during pilot years (Months 12–60 = 2027-10-08 to 2031-10-08) could reduce yields 20–40%, invalidating cost assumptions and forcing replanning.
- OEM tire-grade qualification is time-consuming (12–24 months of tire manufacturing, testing, regulatory approval). Early engagement (Month 6 = 2027-04-08) and co-funded testing (program + OEM cost-share) is essential to align qualification timeline with Year 7 gate (Month 84 = 2033-10-08).
- Contingency: if pilot cost is USD 1.80–2.00/kg by Month 72 (2032-10-08) (above the 1.62 gate threshold), activate fallback options: (a) defer hub construction to Months 96–120 (2034-10-08 to 2036-10-08), allowing 3–4 additional years of cost reduction via processing improvements; (b) increase co-product monetization (market development for inulin, resins); (c) reduce hub capacity targets (scale back from 200,000 t/yr to 100,000–150,000 t/yr, reducing fixed-cost burden).
- Post-gate risk: if alternative-rubber cost misses the gate, combined-stress exposure (outbreak + re-breeding + alternative-rubber remediation) exceeds the USD 4.5B contingency pool by USD 1–2B, forcing fallback funding cascade (higher bank lending, outcome-linked bonds, climate-finance blending) or program scope reduction.


## 5. Binding Multilateral Funding Commitments and Capital-Stack Stability Through Political Cycles

A 25-year program is hostage to political cycles, budget shifts and funder turnover. If key sovereigns reduce commitments by 20–50% at Months 60–120 (2031-10-08 to 2036-10-08), the program loses USD 400–1,200M in planned tranches and breeding/alternative-rubber phases collapse. Binding, ring-fenced commitments (not annual re-appropriations) and funder diversification (no source >25%) are essential to institutional durability. The industry levy (expected USD 270M/yr by Month 36 = 2029-10-08) is the most resilient source if collection compliance exceeds 80%; if compliance is <60%, fallback cascades (outcome-linked bonds, climate finance) must be pre-negotiated and pre-positioned.

### Data to Collect

- Binding 10-year funding commitment letters from ≥5–8 sovereign governments (Brazil, Indonesia, development-partner nations) specifying annual tranches, gate-release schedules and political-turnover clauses (binding on successor administrations)
- Multilateral development-bank lending commitments from ≥2 major lenders (World Bank, African Development Bank, Asian Development Bank, or regional development banks) with concessional interest rates (<3% nominal, 20–25 year amortization) totaling USD 7.0B (estimate)
- Legal instruments embedding commitments: treaty language, cabinet resolutions, multilateral board resolutions, loan-disbursement agreements with conditions and enforcement mechanisms
- Funder-composition audit: verification that no single sovereign or MDB holds >25% of total capital (USD 7.5B threshold), and that funding is diversified across ≥7–10 sources to reduce funder-exit risk

### Simulation Steps

- Model funder-attrition risk over 25 years using historical development-program data (World Bank portfolio reviews, bilateral-aid trends); simulate probability that major sovereigns reduce commitments by 20–50% due to political turnover, budget crises, or competing priorities; forecast remaining funding at Months 60, 120, 180 (2031-10-08, 2036-10-08, 2041-10-08)
- Build financial cash-flow models under three scenarios: (a) 100% commitment adherence (baseline), (b) 20–30% withdrawal by one major funder at Month 60 (2031-10-08) or 120 (2036-10-08), (c) 40–60% reduction in annual appropriations for sovereign-grant funders due to budget shifts (e.g., pandemic, climate crisis). Quantify shortfall and trigger fallback funding mechanisms.
- Simulate levy revenue under compliance scenarios: (i) ≥80% compliance, USD 270M/yr steady state; (ii) 60–80% compliance, USD 160–210M/yr (evasion, exemptions); (iii) <60% compliance, USD 80–120M/yr (cartel coordination fails). Model cash-flow impact at each compliance tier.
- Stress-test contingency-pool adequacy: model combined-stress claims (outbreak USD 1.5–4.5B + re-breeding USD 0.4–0.8B + alternative-rubber remediation USD 0.5–1.0B = USD 2.4–6.3B) against USD 4.5B pool; identify gaps and required fallback-funding triggers

### Expert Validation Steps

- Engage development-finance experts (World Bank, regional MDBs, CGIAR finance-facilities teams) to review funder-commitment structures and enforceability; validate that political-turnover clauses are legally binding on successor administrations and that commitment language survives changes in national government
- Consult international law specialists (World Bank Legal, UNCTAD, bilateral trade-agreement attorneys) to draft treaty language protecting the 25-year program against unilateral withdrawal or budget raids by any single funder
- Engage fiscal-policy experts and national-budget analysts in target countries (Brazil, Indonesia, Côte d'Ivoire) to forecast likelihood that domestic agriculture/rural-development budgets remain stable through Months 60–300 (2031-10-08 to 2046-10-08), or face budget crowding-out from competing priorities
- Commission independent audit (Big-4 accounting firm or development-finance audit specialist) to verify funder-composition diversity (no single source >25%), trace committed capital to actual disbursement, and identify any withholding or delay in tranche release due to gate disputes

### Responsible Parties

- Capital Stack and Funding Mechanisms Designer (negotiations and commitment structures)
- Multilateral Secretariat Executive Director (funder relationships and covenant management)
- Sovereign-government finance ministries and development-bank regional desks
- Independent auditors and legal counsel (binding-commitment verification)

### Assumptions

- **High:** ≥5–8 sovereign governments and ≥2 major multilateral development banks will sign binding 10-year commitments by Month 3 (2027-01-08), embedded in treaties or cabinet resolutions that are legally enforceable on successor administrations. If only 3–4 sovereigns and 1 MDB commit by Month 3 (2027-01-08), total capital falls short by USD 2–5B and program must reduce scope.
- **High:** No single funder will hold >25% of total capital (USD 7.5B threshold), reducing concentration risk. If Brazil or Indonesia hold 30–40% of capital (plausible given their leadership roles), program is vulnerable to unilateral withdrawal and funder-exit cascade.
- **High:** Political-turnover clauses are credible: successor administrations are legally bound to honor prior commitments even if new governments have different priorities. This is rare in development programs and depends on treaty language and international peer pressure; if successors refuse to honor commitments, enforcement is limited to funding withholding by other parties.
- **Medium:** The industry levy can be designed, implemented and sustained with >80% compliance by Month 36 (2029-10-08), generating steady-state USD 270M/yr. Levy compliance depends on cartel-like coordination among competitors and government enforcement at major trading hubs (Singapore, Rotterdam, Shanghai); if compliance drops below 60%, revenue falls to USD 80–120M/yr and fallback funding is required.

### SMART Validation Objective

By Month 3 (2027-01-08), collect signed binding commitment letters from ≥5–8 sovereigns and ≥2 MDBs, specifying annual tranches, gate-release schedules, and political-turnover clauses. Verify no single funder holds >25% of capital. By Month 6 (2027-04-08), legal review of commitments confirms enforceability on successor administrations. By Month 12 (2027-10-08), MDB loan-disbursement agreements are signed with concessional terms (USD 7.0B at <3% nominal, 20–25 year tenor). By Month 18 (2028-04-08), levy pilot is operationalized in ASEAN and compliance is tracked; forecast steady-state collection by Month 36 (2029-10-08). By Month 36 (2029-10-08), verify that actual tranches released equal planned Year 3–7 allocation (USD 4.5B), and no funder has withdrawn >10% due to gate results.

### Notes

- Binding political commitments are rare in development programs and require high-level political will. Negotiations must involve heads of state, finance ministers and central banks, not just development agencies; budget-line commitment language is often non-binding and subject to annual re-appropriation.
- Ring-fenced funding (segregated accounts, trust structures) protects tranches from general-budget raids by sovereigns facing fiscal crises. However, sovereign governments may challenge ring-fencing as an unconstitutional constraint on fiscal authority; legal advice is critical.
- MDB concessional lending (below-market interest rates, long tenor) is politically sensitive; recipient countries may face IMF or other pressure to reduce subsidized borrowing. Structuring MDB lending as technical-assistance grants (not loans) or blended finance (grant + loan mix) can improve political sustainability.
- Contingency: if binding commitments from sovereigns are <USD 5B (vs. planned USD 14B), or if MDBs agree only to USD 3–4B (vs. planned USD 7B), total capital shortfall is USD 3–6B; program must either reduce scope (downsize alternative-rubber and smallholder targets) or increase reliance on industry levy (requiring >90% compliance, unlikely).
- Post-gate risk: if Month 36 (2029-10-08) gate results in low attainment (e.g., <70%), and if funder-dispute-resolution mechanisms are weak, contested gate decisions can delay tranche release by 6–18 months. This cascades into breeding-timeline slip and alternative-rubber delay (Months 84–120 = 2033-10-08 to 2036-10-08 compressed for all activities).


## 6. Stage-Gate Technical Panel Independence, Evidence Transparency and Adaptive-Tranche Release Logic

Gate credibility is the linchpin of funder confidence over 25 years. If gates are perceived as captured (favoring certain factions or pathways) or opaque (evidence not published, reasoning unexplained), funders will question gate decisions and threaten tranche withholding, cascading into mid-program crises. Transparent evidence publication (60 days pre-gate), independent Technical Panel, and published dissents reduce perceptions of capture and enable external stakeholders to validate gate logic. Adaptive tranching (partial release based on proportional KPI attainment) accommodates biological delays while maintaining funder discipline.

### Data to Collect

- Technical Panel member rosters and conflict-of-interest disclosures (annual certification of no financial interest in breeding consortiums, OEMs, producer governments, development banks for ≥5 years prior and during service)
- Gate-evidence data packages (Month 36, 84, 144, 216 = 2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08): raw data on protocol adoption, inspector numbers, interceptions, cultivar-trial yields, virulence-gate results, alternative-rubber cost/quality, smallholder adoption counts, financial audit results
- Technical Panel deliberation records (redacted transcripts or meeting summaries) documenting how Panel assessed evidence, deliberated threshold-attainment percentages and recommended gate decisions; recording of dissenting views
- Gate-decision publication: Technical Panel recommendation, board decision (if different from recommendation), gate-attainment scoring, adaptive-tranche release percentages, appeal-window results

### Simulation Steps

- Build a scorecard model for each gate, quantifying attainment of each KPI (e.g., Month 36 = 2029-10-08 gate: countries_with_rules/15, inspectors_operational/500, detections/2, regional_minimums_met/yes, each weighted equally or by importance); compute overall attainment percentage and map to adaptive-tranche release (85–100% attainment = 100% release, 70–85% = proportional, <70% = 50% release)
- Simulate gate-decision disputes: model scenarios where Technical Panel and board disagree on evidence interpretation (e.g., Panel scores cultivar readiness at 75%, board argues 65%); forecast impact on tranche release (USD 50–300M swing depending on dispute magnitude) and funder confidence
- Model funder-exit probability following contested gate decisions: estimate that 10–20% of funders withdraw if gate decision is perceived as unfair or opaque; forecast remaining capital at Month 60, 120, 180 (2031-10-08, 2036-10-08, 2041-10-08) under escalating funder-exit scenarios
- Evaluate transparency mechanisms: simulate effect of 60-day evidence publication and 30-day appeal window on outside stakeholder confidence; model whether transparency reduces gate-dispute escalation

### Expert Validation Steps

- Engage independent governance experts and development-program evaluation specialists (e.g., CGIAR Independent Evaluation Arrangement, World Bank Independent Evaluation Group, DFID Evaluation Services) to review Technical Panel charter design, conflict-of-interest policies and decision-making procedures; benchmark against best-practice multilateral governance
- Consult international public-policy experts and institutional-economics scholars (e.g., research centers on multilateral organizations, development-finance governance) to validate that independent Panel design reduces capture and improves gate-decision credibility
- Engage funders and producer governments in co-design of gate-evidence templates and KPI definitions (Months 0–3 = 2026-10-08 to 2027-01-08) to build buy-in on transparent, quantitative gate criteria before gates are executed
- Commission external review of gate evidence and Technical Panel decision at each gate (Months 36, 84, 144, 216 = 2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08) by an independent evaluator (not program-affiliated) to assess methodological rigor and provide external-credibility stamp

### Responsible Parties

- Technical Panel and Gate Assessment Coordinator (evidence collection, publication, Panel administration)
- Independent Technical Panel members (7–9, conflict-free, external experts)
- Multilateral Secretariat (board decision-making, appeal management)
- External auditors and evaluators (independent gate-evidence review)

### Assumptions

- **High:** Independent Technical Panel members can be recruited and retained (≥7 of 9 members must have no financial interest in breeding consortiums, OEMs, producer governments or development banks for ≥5 years prior and during service). If qualified, independent candidates are unavailable or unwilling to serve, Panel credibility is compromised.
- **Medium:** All gate evidence (raw data, analyses, Panel deliberation summaries) can be published 60 days before gate decisions, permitting 30-day public review and appeal. If proprietary or sensitive data (e.g., cultivar genetic maps, cost-competitiveness trade secrets) cannot be published, transparency is weakened.
- **High:** Adaptive-tranche release logic (70–100% release at 70–100% attainment, proportional scaling) is predefined in the Technical Gate Charter and is binding on all funders and the board. If tranches can be released or withheld at board discretion (overriding Charter language), gate decisions become political and gate credibility collapses.
- **Medium:** Technical Panel appeals are resolved within 30 days, and responses are published. If appeals drag on or are dismissed without reasoning, funder confidence erodes.

### SMART Validation Objective

By Month 3 (2027-01-08), publish and sign the binding Technical Gate Charter, specifying gate-KPI definitions, thresholds, attainment-scoring rules, adaptive-tranche release percentages, Panel-governance procedures, and appeal mechanisms. Recruit and vet ≥7 of 9 Technical Panel members by Month 6 (2027-04-08), confirming conflict-of-interest disclosures. By Month 30 (2029-04-08), publish draft gate-evidence templates for Month 36 (2029-10-08) gate; solicit funder feedback. By Month 36 (2029-10-08), publish full Month 36 (2029-10-08) gate-evidence package (60 days pre-gate) and Technical Panel recommendation; manage 30-day appeal window; publish final decision and adaptive-tranche release percentage. Repeat for Months 84, 144, 216 (2033-10-08, 2038-10-08, 2044-10-08) gates.

### Notes

- Independent governance structures are aspirational but fragile: panels can be undermined by political pressure if program funders or producers dispute gate outcomes. Pre-commitment in a binding charter, published evidence and transparent appeal procedures reduce (but do not eliminate) governance risk.
- Adaptive tranching is operationally complex: if Year 3 gate scores 72% attainment (70–85% band), releasing 72% of USD 4.5B = USD 3.24B, the remaining USD 1.26B is reallocated among pillars or to contingency. Reallocation decisions can be contentious; decision rules (e.g., 'reallocate to lowest-performing pillar' or 'hold in contingency') must be explicit in Charter.
- Technical Panel deliberation transparency faces tension with Panel members' need for candid discussion: if all deliberations are published, Panel members may self-censor or avoid frank debate. Recording of summary rationales (not transcripts) balances transparency and deliberation candor.
- Post-gate risk: if Month 36 (2029-10-08) gate scores <70% attainment on any KPI (e.g., only 12 countries with rules, or <450 inspectors, or no detections), then only 50% of tranches are released, leaving Months 36–84 (2029-10-08 to 2033-10-08) under-funded by USD 2.25B. This cascades into breeding-timeline slip and alternative-rubber delay; funders may perceive the Year 3 gate as a failure and reduce subsequent Year 7/12 commitments.

## Summary

This project data-collection plan identifies the six highest-consequence assumptions about SALB containment, Hevea breeding durability, smallholder surveillance adoption, alternative-rubber cost parity, multilateral funding stability, and gate-decision credibility. Each area specifies: (1) critical data to collect (protocol adoption evidence, pathogen virulence data, farmer participation rates, hub cost and quality metrics, funder commitments, gate-decision records); (2) simulation tools to preliminarily validate data (IPPC process modeling, stochastic resistance-durability forecasts, farmer-incentive behavioral models, cost-accounting and stress-test spreadsheets, funder-attrition scenarios); (3) expert validation by multilateral governance specialists, pathogen genomicists, smallholder-adoption economists, processing engineers, development-finance experts, and independent evaluators. The collection schedule is front-loaded (critical validations Months 1–18 = 2026-11-08 to 2028-04-08) to enable gate decisions at Months 36, 84, 144, 216 (2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08) with credible, peer-reviewed evidence. Sensitivity scores are high for four assumptions (IPPC adoption feasibility, pathogen-lab operationalization, funder binding-commitment achievement, Technical Panel independence) and medium for the remaining two (regional-compact speed, surveillance-premium design flexibility), reflecting the concentration of design and execution risk in governance, institutional and biological-validation domains. Immediate actionable tasks are: (1) By Month 1 (2026-11-08), separate the Year 3 gate into 'Protocol Readiness' (infrastructure) and deferred 'Containment Efficacy Review' (field outcomes); fund USD 500M–1B Outbreak Response Reserve independent of gate logic; (2) By Month 2 (2026-12-08), commission Brazil Pathogen Genomics Lab; establish binding Virulence Gates at Months 24–60 (2028-10-08 to 2031-10-08) as non-negotiable sub-criteria for cultivar release; (3) By Month 3 (2027-01-08), design outcome-based surveillance premiums ($50–100 per report) and secure binding multi-year funding commitments from ≥5 sovereigns and ≥2 MDBs; draft Technical Gate Charter with independent Panel; (4) By Month 6 (2027-04-08), pilot surveillance-premium scheme in 3–5 zones; complete Nagoya/ABS negotiations in Brazil; (5) By Month 12 (2027-10-08), commission ≥4 high-containment trial stations and Pathogen Lab; (6) By Month 18 (2028-04-08), deliver ≥200 wild Hevea accessions, secure 2–3 OEM letters of intent, and run ASEAN levy pilot. These actions directly mitigate the eight highest-impact risks (gate-credibility collapse, resistance breakdown, surveillance-adoption failure, alternative-rubber cost/quality misses, funder exit, governance capture, smallholder-income misalignment, and combined-stress pool exhaustion) and enable credible Month 36, 84, 144 and 216 (2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08) gates.