## 1. SALB Containment Protocol Adoption and Producer-Nation Binding Commitments

The SALB Containment Protocol is the non-negotiable Phase 1 deliverable and a critical gate criterion at Month 36 (2029-10-12). Producer-nation binding commitments and IPPC adoption are necessary to establish the protocol's legitimacy and enforce surveillance, inspection, and incursion response. Without verified adoption in at least 3 of 5 top producers and documented inspector deployment, containment cannot be credibly verified, invalidating all downstream gate logic and smallholder adoption rationale.

### Data to Collect

- Bilateral Memoranda of Understanding or binding Protocol-Adoption Agreements signed by Brazil, Indonesia, Thailand, Malaysia, and Vietnam, each specifying national embedding timeline, inspector hiring targets (minimum 20 per country by Month 12 = 2027-10-12), quarterly compliance reporting, and enforcement penalties
- Evidence of national phytosanitary legislation embedding the IPPC-harmonized SALB Containment Protocol in each producing nation by Month 36 (2029-10-12)
- Quarterly compliance scorecards documenting inspector hiring progress, training completion, and inspection lot volumes per country (proposed target: 100,000+ lots inspected annually across top 5 producers)
- IPPC working-group consultation comments and formal adoption vote outcome at Month 36 (2029-10-12)
- Red-team drill results from at least 3 producing countries (Months 18–36, 2028-04-12 to 2029-10-12) showing detection accuracy of at least 95% (proposed threshold) for contaminated material moved through supply chains

### Simulation Steps

- Use IPPC Secretariat public documentation (ippc.int) to model the working-group comment and adoption-vote timeline based on prior ISPM adoption cycles (average 18–36 months for consensus)
- Interview national plant protection organizations in 2 pilot countries (e.g., Thailand, Indonesia) using structured questionnaires to estimate inspector-hiring capacity, budget allocation feasibility, and timeline for legislative embedding
- Deploy a compliance-monitoring spreadsheet or database with monthly data entry by country liaisons to track inspector hiring, training completion, and inspection lot volumes; calculate cumulative progress against the 100,000 lot/year target
- Model red-team drill scenarios using supply-chain documentation flows (phytosanitary certificate generation, lot tracking, cross-border movement) at pilot nurseries or estates to test inspector detection under time pressure

### Expert Validation Steps

- Engage IPPC Standards Officer (FAO, Rome) to validate the adoption timeline and working-group consensus pathway for the SALB Containment Protocol and confirm realistic Month 36 (2029-10-12) gate feasibility
- Consult phytosanitary policy experts at regional plant protection organizations (APPPC, NAPPO, EPPO) to assess producer-nation willingness to embed the protocol in national law and identify sovereignty or enforcement barriers
- Request independent audit by a third-party phytosanitary compliance assessor (e.g., an international auditor retained for the Gate Evidence Verification Regime by Month 3, 2027-01-12) to verify binding status of MoUs/Protocol-Adoption Agreements and check compliance scorecards
- Convene the Resistance Durability Oversight Panel and independent auditor to review red-team drill protocols and audit the published drill results for methodological rigor and detection-accuracy claims

### Responsible Parties

- SALB Containment Protocol Director (embedded at FAO/IPPC by Month 3, 2027-01-12)
- Protocol Adoption Secretariat (3–4 FTE policy coordinators and IPPC standard-writer)
- National plant protection organization directors in Brazil, Indonesia, Thailand, Malaysia, Vietnam
- Independent Compliance Auditor (contracted by Month 3, 2027-01-12) to verify binding commitment and inspector-hiring progress

### Assumptions

- **High:** Producer-nation MoUs or binding Protocol-Adoption Agreements (not advisory MoUs) can be negotiated and signed by Month 6 (2027-04-12), specifying legal obligations for national embedding, inspector hiring, and financial or trade penalties for non-compliance.
- **Medium:** IPPC working-group consensus and formal adoption vote will complete by Month 36 (2029-10-12), allowing for a 24–30 month drafting and consultation cycle (based on prior ISPM adoption timelines, not verified).
- **High:** At least 3 of 5 top producers will legally embed the protocol in national phytosanitary legislation and hire and train at least 20 inspectors per country by Month 12 (2027-10-12), despite budget constraints and political volatility.
- **Medium:** Red-team drills can reliably detect 95%+ of contaminated material moved through supply chains with falsified or unmarked clean-plant certificates, validating inspector effectiveness and enforcement credibility.
- **Medium:** National agencies will provide accurate and timely compliance data (inspector hiring, training, lot inspections) for quarterly scorecards without political pressure to misreport or delay disclosure.

### SMART Validation Objective

By Month 12 (2027-10-12), validate that binding Protocol-Adoption Agreements are signed by at least 3 of 5 top producers with enforceable legal penalties for non-compliance. By Month 36 (2029-10-12), confirm IPPC adoption vote is held and at least 100 inspectors are active across top producers, documented in published compliance scorecards. By Month 36 (2029-10-12), verify red-team drill results show detection accuracy of at least 95% in all 3 drill countries. If fewer than 3 producers have binding adoption by Month 54 (2031-04-12), trigger program re-scope or defer Year 3 gate to Month 48 (2030-10-12).

### Notes

- Risk: If IPPC adoption stalls beyond Month 36 (2029-10-12) or fewer than 3 producers embed the protocol in national law, the Month 36 (2029-10-12) gate criteria are unmet, withholding Year 3 gate capital (USD 7.0B, estimated) and cascading delays across all downstream phases. Mitigation: lock bilateral MoUs with penalty clauses by Month 6 (2027-04-12) as binding alternatives to IPPC consensus.
- Critical path: ABS agreements (Month 6 = 2027-04-12), binding framework funding agreements (Month 12 = 2027-10-12), and breeding-trial plant-by date (Month 12 = 2027-10-12) must all hit their deadlines to avoid compression of Year 7 gate timeline.
- Data collection must be independent of program management to prevent data manipulation; the independent auditor (contracted Month 3 = 2027-01-12) should have contractual data-access rights and publish all compliance scorecards within 30 days of audit conclusion.
- Compliance monitoring should include smallholder-reporting channels (anonymous SMS/WhatsApp incentive system, EUR 10–50 per confirmed violation report, paid within 30 days) to supplement inspector audits and deter concealment.


## 2. Hevea Resistance Breeding Pathway: Cultivar Readiness and Durability Evidence at Year 7 Gate

The Year 7 gate (Month 84 = 2033-10-12) cultivar-readiness decision gates USD 6.5 billion in program capital and enables smallholder adoption timelines. Hevea perennial-crop biology permits zero slack: trials must be planted by Month 12 (2027-10-12) to yield meaningful durability data by Month 84 (2033-10-12). Without pre-registered KPI targets and independent durability testing, auditors cannot credibly verify gate status, risking contested verdicts, capital withholding, and smallholder adoption collapse. Resistance durability is the critical unknowable: if resistance breaks down in Years 8–18, the program's core supply-chain resilience objective fails.

### Data to Collect

- Pre-registered breeding KPI targets (yield ≥90% of elite clones, ≥3 independent resistance sources stacked, lesion size <5 mm, defoliation ≤20%, artificial inoculation at 10x field-typical load) published in a peer-reviewed protocol document
- Field-trial establishment data from 4 international sites (Brazil Campinas, Thailand, Malaysia/Indonesia, Côte d'Ivoire): baseline soil and inoculum surveys, cultivar planting dates, replicate block counts (at least 3 blocks of 100+ trees per cultivar), and trained site-manager assignments by Month 12 (2027-10-12)
- Quarterly breeding-trial data summaries from Month 12 (2027-10-12) through Month 84 (2033-10-12): yield measurements (kg/tree/year by cultivar and site), lesion size and defoliation scores (by sampling protocol), pathogen isolate virulence profiles, and molecular confirmation of resistance-source independence
- Durability and inoculum-challenge trial results: artificial inoculation at 10x field-typical spore loads conducted at multiple sites under controlled and field conditions, with lesion-size and defoliation responses documented across at least 2 consecutive seasons per site
- Cultivar genotypic and genealogical data: molecular marker confirmation that ≥3 resistance sources are genetically independent (≥75% dissimilarity, proposed threshold) and not derived from shared pedigrees within the past 5 generations

### Simulation Steps

- Use AgriDays or Bridgestone guayule breeding software (or equivalent multi-site trial management systems) to model field-trial protocols, randomization of plots, and power analysis to detect yield differences of ≥10% between resistant and elite-clone controls
- Consult IRRDB Hevea germplasm database (irrdb.com) to identify and virtually model the 4 trial-site agro-climatic conditions (rainfall, temperature, seasonality, soil type) and estimate baseline SALB-pressure zones for inoculum-challenge design
- Use R or JMP statistical software to pre-register data-collection protocols and analysis pipelines (e.g., mixed-model analysis of yield by cultivar, site, and year; lesion-size threshold definition) by Month 6 (2027-04-12), locked before field data are collected
- Model resistance-source independence using allele-frequency data from available Hevea germplasm collections: simulate cross-contamination scenarios and estimate the probability of durability breakthrough under SALB-population evolution

### Expert Validation Steps

- Engage the Resistance Durability Oversight Panel (6 members: 2 perennial-crop breeders, 2 plant pathologists, 1 independent auditor, 1 ABS specialist), established by Month 1 (2026-11-12), to review and approve all breeding-trial protocols and cultivar-advancement criteria before Month 12 (2027-10-12) planting
- Commission IRRDB member institutes (e.g., Embrapa Hevea, Malaysian Rubber Board, Thailand Rubber Research Institute) to conduct quarterly monitoring of field-trial progress and provide independent site-visit reports (1 visit per site per quarter) confirming plot establishment and data-collection fidelity
- Hire a dedicated breeding-program auditor (or use the independent Gate Evidence Verification auditor, contracted Month 3 = 2027-01-12) to conduct unannounced site visits (at least 1 per year per site, starting Month 24 = 2028-10-12) to verify data integrity and trial-management compliance
- Request breeding-data validation from a third-party agronomic lab (e.g., RAPRA, university agronomy department) to independently confirm yield-measurement methodology and lesion-size classification accuracy on a 5% sample of trees across all sites and years

### Responsible Parties

- Hevea Resistance Breeding Program Director (embedded at breeding hubs, reported to Program Governance Manager)
- Resistance Durability Oversight Panel (6 members, chaired by independent breeding expert, established Month 1 = 2026-11-12)
- Brazil-led breeding team (Embrapa Hevea, IAC Campinas, partnering institutes)
- Field-trial site managers at 4 international locations (recruited and trained by Month 12 = 2027-10-12)
- Independent Gate Evidence Verification Auditor (contracted Month 3 = 2027-01-12) with access to all trial data

### Assumptions

- **High:** ABS agreements with Brazil CGen and 3 Amazonian community groupings are executed by Month 6 (2027-04-12), enabling germplasm transfer and trial-site establishment by Month 12 (2027-10-12) with zero slippage.
- **High:** Resistance sources identified in breeding are genetically independent and will not share pathogen virulence-breaking mutations, ensuring durability beyond the 6-year first-cycle field observation (untested in Hevea context; assumption carries residual 10–20% risk of shared susceptibility, estimate).
- **High:** Yield penalties from stacking multiple resistance sources will not exceed 15% (yield ≥85% of elite clones), preserving economic viability for smallholder adoption. If penalties exceed 15% by Month 48 (2030-10-12), crown-budding fast-track is activated (USD 0.25B, estimate).
- **Medium:** Field trials conducted in 4 geographically distributed sites will capture SALB variability and provide durable-resistance evidence applicable across producing regions. Single-site failure or environment-specific resistance will be detected and reported by the Oversight Panel.
- **Medium:** Artificial inoculation protocols using 10x field-typical spore loads reliably simulate natural epidemic pressure and predict multi-decade durability. No alternative rapid-durability-assessment method is assumed available by Month 84 (2033-10-12).

### SMART Validation Objective

By Month 6 (2027-04-12), publish peer-reviewed breeding KPI protocol (yield ≥90% of elite clones, ≥3 independent resistance sources, lesion <5 mm, artificial inoculation 10x field load). By Month 12 (2027-10-12), confirm all 4 field trials are planted on schedule with baseline inoculum and soil surveys completed. Quarterly: Resistance Durability Oversight Panel reviews trial data for contamination, management compliance, and early resistance signals. By Month 48 (2030-10-12), first 5-year data are available; if yield penalty exceeds 15% (yield <85% of elite), immediately approve crown-budding fast-track decision paper. By Month 84 (2033-10-12), independent auditor verifies cultivar yield at ≥90% of elite, ≥3 confirmed independent resistance sources, and lesion size <5 mm across ≥5 replicate trials. If cultivar-readiness criteria are met, release 80%+ of Year 7 gate tranche (USD 6.5B, estimated) within 45 days.

### Notes

- Risk: Any slip in ABS negotiations or germplasm transfer beyond Month 12 (2027-10-12) compresses trial-planting timelines and moves the Year 7 gate to Month 96 (2034-10-12) or later, cascading smallholder adoption delays by 12+ months. Mitigation: pre-commit USD 0.25B crown-budding fast-track by Month 18 (2028-04-12) if primary germplasm transfer is delayed >8 weeks.
- Resistance durability cannot be accelerated: perennial-crop biology dictates 6–10 year field cycles. Auditor must receive 5–6 years of field data by Month 84 (2033-10-12) to assess durability credibly. Pre-registration of KPI thresholds by Month 6 (2027-04-12) prevents post-hoc reinterpretation.
- Quarterly Panel reviews (starting Month 24 = 2028-10-12) provide early warning of trial-management failures, environmental stress, or resistance signals; triggers for contingency decisions (additional sites, accelerated testing, crown-budding activation) must be defined by Month 9 (2027-07-12).
- Molecular and genealogical confirmation of resistance-source independence must be completed by Month 60 (2031-10-12) to allow time for alternative breeding strategies if sources prove to share susceptibility loci.


## 3. Alternative Rubber (Guayule and Russian Dandelion) Agronomic and Processing Viability at Year 12 Gate

Alternative-rubber commercial viability is critical to supply-chain diversification and smallholder income-generation pathways (via contract farming or cooperatives). The Year 12 gate (Month 144 = 2038-10-12) cost/quality KPI ('delivered cost under 30% above Hevea') determines whether eight commercial plants can be financed and whether OEMs will sign binding offtake. Current base-case economics show a USD 9.6M annual shortfall at full operation (USD 70.4M revenue, USD 80M opex); without cost-reduction pathways or OEM premium commitment, plants cannot achieve positive DSCR and will be stranded. Pilot-scale validation of extraction yield, feedstock cost, and tire-performance acceptance is necessary to credibly estimate commercial-plant unit economics by Month 60 (2031-10-12) plant FID decision.

### Data to Collect

- Demonstration-plant feedstock-cost data from Month 24 (2028-10-12) through Month 60 (2031-10-12): Guayule (Arizona/Mexico, 2,000 t/year pilot) and dandelion (Germany/Benelux, 1,000 t/year pilot) actual dry-matter yield (kg/ha/year), feedstock cost per kg dry matter (labor, land prep, harvest, transport), and cost variability by season
- Processing pilot-plant data: extraction yield (%) from plant material to crude rubber, quality variance (±%), contaminant removal efficiency, and all-in processing cost per kg crude rubber (labor, energy, solvent, equipment amortization)
- Agronomic trial results from 5+ candidate sites per crop (Month 6 = 2027-04-12 climate and soil suitability screening through Month 48 = 2030-10-12 multi-season yields): water balance, drought-stress impacts, pest/disease incidence, soil quality pre- and post-harvest
- Tire-performance qualification results from 3 accredited independent test labs (TÜV, RAPRA, Smithers): tread wear (vs. Hevea reference), rolling resistance (variance), wet braking, 500,000 km durability trials, and formulation/blending notes documenting rubber compatibility
- OEM Letters of Intent and price-signal feedback from 8 of 10 tire makers (Month 12 = 2027-10-12 onwards): maximum acceptable premium over Hevea benchmark (ranging 0–30%, estimate), supply-volume minimums, and quality-variance tolerance

### Simulation Steps

- Use AquaCrop or DSSAT crop-simulation models to project Guayule and dandelion yields at 15+ candidate sites under baseline and drought-stress scenarios (RCP 4.5, RCP 8.5), with water-balance and soil-water-stress algorithms calibrated to local precipitation and soil surveys
- Build a cost-down roadmap spreadsheet modeling feedstock cost, extraction yield, and all-in opex under 3 scenarios: baseline (current pilot costs), optimistic (technology improvements, scale economies), and conservative (regulatory pressure, input inflation). Model sensitivity to each cost driver.
- Use tire-formulation simulation software (e.g., Hyperworks or proprietary OEM blending models, accessible through university partnerships) to predict rolling resistance and tread wear of Guayule/dandelion rubber blends at 5%, 10%, and 20% substitution levels in standard tire formulations
- Monte Carlo simulation (1,000 iterations) of project financial returns under cost and price uncertainty, using pilot data on yield, feedstock cost, and OEM premium to estimate breakeven price and sensitivities; model consequence if premium declines 5–10% by Month 144 (2038-10-12)

### Expert Validation Steps

- Commission independent agro-climatic modeling from a university or CGIAR climate-smart agriculture group: water-balance analysis at each candidate Guayule site (Arizona, Mexico, Texas) and dandelion site (Germany, Benelux, Eastern Europe), with drought-probability and aquifer-sustainability projections through 2050
- Engage Bridgestone Americas (guayule program contact via bridgestoneamericas.com) and Fraunhofer IME Münster (dandelion expertise via fraunhofer.de) to share pilot-plant extraction and cost data (non-proprietary summary) and benchmark against program targets (Guayule feedstock USD 1.20/kg by Month 48 = 2030-10-12, dandelion USD 1.00/kg, extraction yield 85%+ and 80%+, respectively)
- Commission independent tire-performance testing at 3 accredited labs by Month 12 (2027-10-12) with pre-registered test protocols (ASTM D2240, D6378, D2304 standards) and publication of results by Month 48 (2030-10-12); auditor (Gate Verification regime) spot-checks lab notebooks and raw data for compliance
- Conduct OEM supply-chain interviews (Bridgestone, Goodyear, Michelin, Continental, Sumitomo, Yokohama, Pirelli, Hankook) by Month 9 (2027-07-12) to validate price-premium tolerance, supply-volume minimums, and formulation-fit constraints; synthesize findings into a consolidated OEM feedback report by Month 12 (2027-10-12)

### Responsible Parties

- Alternative-Rubber Processing & OEM Engagement Lead (full-time, coordinating with agronomy and processing teams)
- Guayule agronomy and processing teams (Arizona/Mexico pilot operations)
- Dandelion agronomy and processing teams (Germany/Benelux pilot operations)
- Processing R&D partners (Fraunhofer IME, university labs, technology innovators)
- OEM Steering Committee members (Bridgestone, Goodyear, Michelin, Continental, Sumitomo, Yokohama, Pirelli, Hankook)
- Independent auditor (Gate Evidence Verification regime) verifying tire-test and cost data

### Assumptions

- **High:** Guayule feedstock cost can be reduced to USD 1.20/kg dry matter and dandelion to USD 1.00/kg by Month 48 (2030-10-12) through agronomic optimization and scale economies, from current pilot estimates of USD 1.40–1.80/kg and USD 1.20–1.60/kg, respectively (not verified).
- **High:** Extraction yields of 85% (Guayule) and 80% (dandelion) are achievable at commercial scale without loss of quality, based on pilot-scale process data. Processing cost of USD 2.50/kg all-in (Months 60–84, 2031-10-12 to 2033-10-12) is achievable, reducing to USD 1.80/kg by Month 144 (2038-10-12) via automation and co-product valorization.
- **High:** OEMs will accept alternative rubber at a 10% premium over Hevea (USD 2.20/kg vs. USD 2.00/kg benchmark) and maintain that premium through Year 12 (Month 144 = 2038-10-12) via binding purchase-option or take-or-pay contracts, declining phased to parity by Year 24 (Month 288 = 2050-04-12, estimate).
- **Medium:** Climate and water availability at candidate sites will support sustained Guayule and dandelion cultivation without 20%+ yield loss due to drought or heat stress through 2050. If modeled yield loss exceeds 25% at primary sites, re-siting to alternative geographies (e.g., Middle East, Patagonia) is feasible by Month 72 (2032-10-12) within the USD 1.0–1.5B climate re-siting reserve.
- **Medium:** Tire-performance qualification trials will confirm that Guayule and dandelion rubber meet OEM specifications (tread wear ≥95% of Hevea, rolling resistance ±5%, wet braking ≥95%, 500,000 km durability) without requiring proprietary formulation changes that would create lock-in or increase OEM switching costs.

### SMART Validation Objective

By Month 6 (2027-04-12), finalize candidate sites (5+ for each crop) after agro-climatic and water-availability screening. By Month 24 (2028-10-12), commission 2,000 t/year Guayule pilot (Arizona/Mexico) and 1,000 t/year dandelion pilot (Germany/Benelux) and collect baseline feedstock-cost data. By Month 36 (2029-10-12), publish pilot agronomic results (yield, cost, variability) and launch tire-performance qualification trials at 3 accredited labs. By Month 48 (2030-10-12), report pilot extraction-yield and processing-cost data; if feedstock cost exceeds USD 1.40/kg (Guayule) or USD 1.20/kg (dandelion), or extraction yield <75%, trigger processing-innovation capital decision or alternative-crop portfolio rebalancing. By Month 60 (2031-10-12), complete tire-qualification results and OEM feedback; decide on wave 1 commercial plant FID (Month 72 = 2032-10-12) only if cost targets are met and 8 of 10 OEMs have signed purchase-option contracts. By Month 84 (2033-10-12), achieve feedstock cost Guayule USD 1.20/kg and dandelion USD 1.00/kg and processing cost USD 2.50/kg. By Month 144 (2038-10-12), validate that delivered cost is under 30% above Hevea benchmark; if cost is ≥30% above, gate is failed or conditional, and wave 2 commercial-plant commitment is deferred or cancelled.

### Notes

- Critical decision point Month 60 (2031-10-12): if cost or quality targets are missed, reallocate wave 1 USD 0.8B capex to resistant-Hevea breeding or defer alternative-crop plants to research hedge with much lower commercial targets.
- Water scarcity risk in arid zones (Guayule) and heat stress in temperate zones (dandelion) are climate-dependent and may degrade yields 20–30% by Year 10 (estimate). Monthly water-balance monitoring and crop-stress surveillance must begin at Month 12 (2027-10-12) to provide early warning for re-siting decisions by Month 54–60 (2031-04-12 to 2031-10-12).
- OEM offtake is conditional on tire-qualification success; if qualification is delayed beyond Month 48 (2030-10-12) or results are poor (tread wear <93% of Hevea, rolling resistance >±8%, wet braking <92%), OEM LoIs become non-binding and plant financing cannot close. Contingency: use purchase-option contracts (lower commitment) instead of firm take-or-pay, reducing OEM risk perception.
- Pilot-plant operating losses (USD 2–5M/year per pilot, estimate) are absorbed by the USD 0.2B pilots budget line; loss tracking and decision triggers for pilot closure (if targets are not met by Month 42 = 2030-04-12) must be documented by Month 12 (2027-10-12).


## 4. Smallholder Adoption Finance, Extension Delivery, and Clean-Plant Nursery Networks

Smallholder adoption is the critical variable determining whether resistant cultivars and alternative crops reach scale and whether risk reduction is achieved across producing regions. The plan targets 45% uptake (2.25 million hectares) by Month 144 (2038-10-12), but historical adoption of improved Hevea clones averages 20–40%. Income-bridging finance and extension are the primary levers to shift behavior, yet their effectiveness is unproven in the proposed design (6–10 year immature-period income coverage at 60–70% replacement, no price-floor guarantee, locally-owned nurseries). Without baseline validation of farmer willingness, pilot testing of finance terms, and transparent tracking of enrollment and retention, the USD 6.75B smallholder-finance line risks becoming a sunk cost with <30% realized uptake and <10% sustained replication.

### Data to Collect

- Baseline smallholder-adoption survey from 2,000–5,000 representative farms per country in top 5 producers (conducted Month 1–6 = 2026-11-12 to 2027-04-12): current Hevea clone adoption rates, willingness-to-replant at different income-bridging terms (60%, 70%, 80% of median farm income during immature period), extension-contact frequency, nursery-access barriers, and default-risk expectations
- Income-bridging finance pilot results from 5,000–10,000 smallholders in Months 12–36 (2027-10-12 to 2029-10-12): uptake rate (% of eligible farmers enrolled), disbursement timeliness (days from application to payment), default rate (% of farmers in arrears >30 days by year 1, 2, 3), and farmer satisfaction scores (mobile survey)
- Extension-agent and nursery-operator recruitment and training records: number of agents hired (target 500 total, 200–500 smallholders per agent), training completion rate (2-week module on SALB symptom ID, clean-plant handling, cultivar agronomy), and staff retention rate (%) at Months 12, 36, 84, 144 (2027-10-12, 2029-10-12, 2033-10-12, 2038-10-12) (proposed thresholds)
- Clean-plant nursery registration and certification records: number of certified nurseries per country (target 50–100 per major country), lot-inspection pass rates (%), and genetic-identity confirmation (DNA barcode, %) for a sample of sold plants
- Smallholder enrollment and replication-area progression: cumulative enrollment in clean-plant/extension networks by country and month (target 30% of eligible smallholders by Month 84 = 2033-10-12); cumulative area replanted with resistant clones by Month 144 (2038-10-12, target 40% of eligible area = 2 million hectares)

### Simulation Steps

- Use standard household-survey questionnaires (CGIAR CIMMYT adoption-survey module or World Bank LSMS-type instruments) to model smallholder income volatility, credit access, and adoption-decision constraints in representative zones of each producing country; administer to 2,000–5,000 farms per country via enumerators or digital (ODK/Kobo) by Month 6 (2027-04-12)
- Build an Excel/R model of income-bridging finance repayment under smallholder yield and price uncertainty (3 scenarios: optimistic 95% yield attainment, baseline 85%, stressed 70%; rubber price +20%, baseline, –20%); simulate default rates and identify farmer sub-populations at highest default risk
- Model extension-agent deployment and retention using prior developing-country agricultural program data (typical annual turnover 30–50% in extension, estimate; rural retention higher with bonuses/career pathways): project agent-population sustainability through 25 years and identify early-intervention triggers to prevent knowledge loss
- Simulate clean-plant nursery supply and demand: model growth in nursery capacity needed to serve 2.25 million hectares (target 45% adoption), accounting for nursery certification timelines (6–12 months, estimate), training lags, and potential capacity constraints (land, labor, water); flag bottlenecks

### Expert Validation Steps

- Engage smallholder-development experts (International Fund for Agricultural Development, CGIAR research programs, academic smallholder-adoption specialists) to review baseline-survey questionnaire design and validate key assumptions on willingness-to-adopt, income-bridging acceptable terms, and historical default rates in rubber and similar perennial-crop smallholder populations
- Commission an independent M&E specialist (or organization with CGIAR/NGO experience in smallholder agricultural programs) to design and pilot the income-bridging finance instrument on 5,000–10,000 smallholders in Months 12–36 (2027-10-12 to 2029-10-12), with randomized or quasi-experimental comparison groups to estimate causal adoption impact
- Conduct quarterly independent audits of extension-agent and nursery-operator data (by program auditor or third-party monitor) starting Month 24 (2028-10-12) to verify staff counts, training completion, retention rates, and farmer-satisfaction surveys; publish aggregate results monthly for transparency
- Engage farmer-association representatives and cooperative-governance experts to co-design the locally-owned extension and nursery-operation model; pilot co-governance structures (cooperatives vs. associations vs. farmer-led) in 2–3 test regions by Month 18 (2028-04-12) and evaluate sustainability and farmer-satisfaction by Month 36 (2029-10-12)

### Responsible Parties

- Smallholder Adoption Finance & Extension Delivery Manager (full-time, established Month 1 = 2026-11-12)
- Smallholder Adoption Working Group (month 1 = 2026-11-12): farmer associations, research institutes, finance specialists, gender/inclusion officer
- Extension agents (500 lead agents recruited and trained by Month 12 = 2027-10-12, locally managed through cooperatives/associations)
- Nursery-operator network (50–100 certified nurseries per major country, locally-owned cooperatives or associations)
- Independent M&E specialist or organization (contracted by Month 9 = 2027-07-12) to monitor baseline survey, pilot finance, and enrollment/retention tracking through Month 300 (2051-10-12)

### Assumptions

- **High:** Baseline willingness-to-replant (from household survey by Month 6 = 2027-04-12) will be at least 35–40% of eligible smallholders at income-bridging terms of 60–70% for 6–10 years, enabling the 45% adoption planning target; if baseline is <30%, adoption scenarios must be revised downward and contingent tranches reallocated.
- **High:** Income-bridging finance default rate will be 10–15% annually in the first 3 years of immature-tree period, manageable within program loss absorption (proposed threshold); if actual default exceeds 20% in pilot (Months 12–36 = 2027-10-12 to 2029-10-12), finance instrument must be redesigned or trigger reallocation of contingent tranches.
- **Medium:** Extension-agent recruitment and 2-week training can be completed by Month 12 (2027-10-12) across 5 producing countries and 500 agents sustained at 60%+ retention through Year 10 (Month 120 = 2036-10-12), supported by performance bonuses, cooperative equity, and professional-development pathways within the protected USD 300–500M extension stream.
- **Medium:** Locally-owned clean-plant nurseries (50–100 per major country) can be certified and scaled to supply 2.25 million hectares of resistant-cultivar planting material without contamination, supported by extension agents and quality-assurance protocols; certification timelines are 6–12 months per nursery, and scaling capacity is not a constraint.
- **Medium:** Smallholder adoption of resistant clones will be sustained through Years 10–25 (fullly-bearing trees), conditional on price-floor guarantees (90% of Hevea benchmark, proposed) and continued extension support; price volatility and commodity-price collapse are mitigated by index insurance or government price supports.

### SMART Validation Objective

By Month 6 (2027-04-12), complete baseline smallholder-adoption survey in 5 countries (2,000–5,000 farms per country) and define 3 adoption scenarios (conservative 30–40%, moderate 40–50%, optimistic 60%+) with contingent tranches. By Month 12 (2027-10-12), recruit and train 500 lead extension agents (2-week module) and register 50–100 certified nurseries per major country. By Month 36 (2029-10-12), pilot income-bridging finance on 10,000 smallholders and track disbursement timeliness, default rate, and farmer satisfaction; publish pilot results. Set enrollment waypoint Month 84 (2033-10-12): ≥30% of eligible smallholders enrolled in clean-plant/extension network (stop trigger <25%, reallocate USD 0.8–1.2B). Quarterly: track extension-agent retention rate and nursery lot-inspection pass rates; if retention falls below 50% by Month 60 (2031-10-12) or inspection pass rate <85%, trigger retraining investment. By Month 144 (2038-10-12), achieve 40% of eligible area replanted (2 million hectares) with resistant clones (waypoint; failure cascades Year 12 gate reductions).

### Notes

- Risk: Historical adoption of improved Hevea clones in Southeast Asia and West Africa is 20–40% over 10+ years (not verified); the plan's 45% target is optimistic. Pilot testing of income-bridging terms (60–70% income replacement) in Months 12–36 (2027-10-12 to 2029-10-12) on 10,000 smallholders is essential to validate real-world uptake and default risk before scaling to 2.25 million hectares.
- Extension-staff turnover of 30–50% annually (typical developing-country agriculture, estimate) will erode knowledge and coverage if retention mechanisms (bonuses, cooperative equity, career pathways) are not budgeted within the USD 300–500M protected extension stream. Recruitment of 500 agents is not enough; replacement pipeline of 100–150 agents/year is needed for sustainability.
- Locally-owned nurseries depend on sustained government certification and market demand; in prior programs (cocoa, coffee), nurseries closed within 2–3 years of public-funding withdrawal. Cooperative business models with farmer equity and revenue-sharing are more durable than state-run nurseries; co-design with farmer associations by Month 18 (2028-04-12).
- Smallholder price volatility is a key adoption risk not fully addressed in the plan: income-bridging covers immature-period losses, but price collapse (e.g., 2008–2009 rubber price –40%, estimate) during tapping can trigger replanting abandonment. Link adoption to price-floor guarantees (90% of Hevea benchmark, proposed) or index insurance by Month 36 (2029-10-12).


## 5. Gate Evidence Verification, Independent Auditing, and Dispute Resolution

Gate evidence verification is the institutional safeguard protecting capital allocation from programme-management bias and ensuring that USD 7–8 billion tranches are released only when credible evidence supports gate passage. Without contractually guaranteed auditor data access, transparent multi-source verification, and binding dispute resolution, programmes routinely withhold unfavorable data or politicize gate decisions. The auditor is the 'honest broker'; independence requires insulation from both programme management (who want gates passed to avoid reputational damage) and funders (who want gates passed to avoid withholding capital). Credible gates protect smallholder and funder confidence; contested or inflated gate verdicts undermine the entire programme.

### Data to Collect

- Auditor-access logs documenting all data requests from the program (databases, inspection records, trial files, benefit-sharing ledgers, smallholder records) and response times in days; target compliance: 5-day response window, with 1–2% auditor-fee penalties (estimate) per 5-day delay for non-compliance
- Multi-source field-visit and database-audit records from independent auditor: at least 30–40% of audit weight is on-site trials and estates (randomly selected by auditor), 40–50% database audits, 20–30% farmer/manager interviews; summary of sites visited, records reviewed, and findings by gate
- Published gate verdicts (one per gate at Months 36, 84, 144, 216 = 2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12) within 30 days of audit conclusion: pass, conditional, or fail status on containment, cultivar readiness, alternative-rubber cost/quality, and smallholder adoption KPIs, with supporting evidence and auditor reasoning
- Dispute-resolution adjudication records: if programme or funder disputes auditor verdict, Dispute-Resolution Panel (3 neutral senior figures) receives request, issues binding judgment within 60 days, and publishes rationale; record of all disputes, panel decisions, and implementation of verdicts
- Tranche-release documentation: recorded date of gate verdict publication, date of Dispute-Resolution Panel decision (if disputed), date of tranche disbursement to programme accounts, and any delays or withholding; target disbursement within 45 days of gate passage (or within 45 days of Panel decision if disputed)

### Simulation Steps

- Model auditor data-access protocols in a project-management platform (e.g., Asana, Monday.com): set up automated requests for databases, inspection records, and trial data to be delivered to auditor within 5 business days; track response times and generate compliance reports monthly
- Design a random-site-selection algorithm to ensure auditor visits are unbiased: use stratified random sampling to select 30–40% of trial sites, 15–20% of smallholder sample for farmer interviews, and 5–10% of nurseries for lot-inspection audits per gate cycle
- Build an Excel template for auditor gate-verdict compilation (containment metrics, cultivar yield/durability, alternative-rubber cost/quality, adoption rates) with pre-defined pass/fail thresholds; simulate verdict outcomes under different trial results (e.g., yield at 88% vs. 92% of elite) to ensure verdict consistency
- Model Dispute-Resolution Panel processes using a decision-tree framework: if Programme claims trial data show cultivar yield at 92% (pass), but auditor reports outliers suggest 88% (fail), Panel receives both parties' evidence summaries and 10 days to deliberate, issuing binding judgment on whether gate is passed at minimum 80% tranche release

### Expert Validation Steps

- Engage an independent auditor (international agricultural audit firm or consortium, contracted by Month 3 = 2027-01-12) with prior experience in multi-site development programs (World Bank, Global Environment Facility) to review and approve auditor data-access protocols and multi-source verification methodology by Month 6 (2027-04-12)
- Recruit the Dispute-Resolution Adjudication Panel (3 neutral senior figures: e.g., retired phytosanitary authority head, independent breeding/agronomy expert, development-finance auditor) by Month 3 (2027-01-12) and publish panel charter specifying binding authority, conflict-of-interest disclosures, and dispute-resolution process
- Commission legal counsel (development-finance expert) to draft the auditor contract (Month 3 = 2027-01-12) with explicit data-access guarantees, response-time penalties, multi-source verification specifications, and publication deadlines (verdicts within 30 days); ensure contract is legally binding and enforceable across jurisdictions
- Request a third-party governance audit of the verification regime (by an independent auditor or governance specialist, Month 6 = 2027-04-12) to validate that auditor independence is not compromised by funder pressure, that dispute-resolution processes are procedurally fair, and that published verdicts are credible to stakeholders

### Responsible Parties

- Gate Evidence Verification & Independent Audit Director (full-time, established Month 1 = 2026-11-12, reports to Steering Council and Dispute-Resolution Panel)
- Independent international auditor (contracted Month 3 = 2027-01-12 for all 4 gates)
- Dispute-Resolution Adjudication Panel (3 neutral senior figures, established Month 3 = 2027-01-12, funded separately from contingency reserve)
- Development-finance legal counsel (contracted Month 3 = 2027-01-12) to draft auditor contract with data-access guarantees and penalties
- Programme data-access coordinator: ensures compliance with auditor requests within 5-day windows and tracks response-time penalties

### Assumptions

- **Medium:** Independent auditor can reliably verify KPI thresholds (yield ≥90% of elite clones, lesion size <5 mm, feedstock cost USD 1.20/kg, adoption ≥30%) using field-visit data (30–40% weight) and database audits (40–50%) and farmer interviews (20–30%), without systematic bias or programme manipulation.
- **Medium:** Programme management will comply with auditor data-access requests within 5 business days (contractually binding); non-compliance triggers financial penalties (1–2% auditor fee withholding per 5-day delay, estimated) enforced by Dispute-Resolution Panel.
- **Medium:** Dispute-Resolution Panel (3 neutral senior figures) can issue binding judgments within 60 days of dispute and that panel decisions will be respected by programme management, funders, and national partners without political override or appeals beyond the panel.
- **Low:** Auditor gate verdicts (pass, conditional, fail) will be published within 30 days of audit conclusion with full supporting evidence, enabling independent verification and preventing post-hoc reinterpretation by programme or funders.
- **Medium:** Tranche disbursement will occur within 45 days of gate passage (or Panel decision if disputed), as specified in binding 25-year framework agreements, without further budget-cycle approval or political delays.

### SMART Validation Objective

By Month 3 (2027-01-12), contract independent auditor with written governance charter and establish Dispute-Resolution Panel (3 members, published charter). By Month 6 (2027-04-12), lock auditor scope and KPI definitions in a peer-reviewed protocol document (published for stakeholder review). By Month 12 (2027-10-12), implement data-access tracking system and document baseline compliance with 5-day auditor-request response window. For each gate (Months 36, 84, 144, 216 = 2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12), measure: (1) auditor field-visit and database-audit completion within 60 days of gate date; (2) multi-source verification weights (field 30–40%, database 40–50%, interviews 20–30%) met per audit plan; (3) gate verdict published within 30 days of audit conclusion; (4) if disputed, Panel issues binding judgment within 60 days; (5) tranche disbursed within 45 days of verdict (or Panel decision). Track data-access compliance: if auditor requests are delayed >5 days, record penalty and escalate to Panel. Publish monthly audit-status dashboard for funder and stakeholder transparency.

### Notes

- Risk: If auditor data access is delayed (e.g., programme withholds trial databases citing 'quality review'), audit timelines slip and gate decisions are deferred by months, cascading capital withholding. Mitigation: contractual penalties (1–2% auditor fee per 5-day delay) and Dispute-Resolution Panel authority to compel data release.
- Auditor independence is vulnerable to funder pressure if the auditor is perceived as 'too conservative' (e.g., failing gates on marginal evidence). Mitigation: publish auditor contract, panel charter, and all verdicts publicly; enable stakeholder commentary; ensure auditor institution is geographically and institutionally separate from programme management.
- Dispute-resolution processes can stall gate decisions by 60–90 days if panel deliberation is slow or if funders appeal panel verdicts. Mitigation: pre-define dispute categories and decision criteria by Month 6 (2027-04-12) to accelerate panel judgment; establish that panel decisions are final with no further appeal.
- Tranche disbursement delays can occur if programme or national partners claim data are 'incomplete' or 'under review.' Mitigation: mandate disbursement within 45 days of gate verdict (or Panel decision) as binding in 25-year framework agreements; any delay >15 days triggers interest penalty or automatic escrow release.

## Summary

This Global Natural Rubber Supply Chain Resilience Initiative ($30 billion, 25 years, Months 0–300) is a foundational, evidence-gated public-private program to de-risk global rubber supply from South American Leaf Blight through an IPPC-embedded containment protocol, SALB-resistant Hevea cultivars via Brazil-led ABS-compliant breeding, and Guayule and Russian dandelion commercialization with OEM offtake. Five critical data-collection areas are prioritized: (1) Producer-nation binding Protocol-Adoption Agreements and IPPC adoption (non-negotiable Phase 1, gate Month 36, 2029-10-12); (2) Hevea breeding-trial establishment and durability testing at 4 international sites (Year 7 cultivar readiness, Month 84, 2033-10-12); (3) Alternative-rubber agronomic and processing validation from pilots toward commercial-scale cost/quality KPIs (Year 12, Month 144, 2038-10-12); (4) Smallholder adoption baseline and finance/extension pilot (45% uptake target, waypoints Months 84 and 144, 2033-10-12 and 2038-10-12); (5) Independent gate-evidence verification and binding dispute resolution (all 4 gates). Most-critical assumptions with high sensitivity: producer-nation binding adoption (if fewer than 3 of 5 embed protocol by Month 54, 2031-04-12, Phase 1 fails); ABS-agreement closure by Month 6 (2027-04-12) (any slip cascades Year 7 gate to Month 96, 2034-10-12 or beyond); smallholder willingness-to-adopt ≥35–40% (if baseline survey reveals <30%, contingent tranches must reallocate); alternative-rubber cost reduction to Guayule USD 1.20/kg and dandelion USD 1.00/kg by Month 48 (2030-10-12) (if missed, wave 1 plants are unfeasible); OEM offtake at 10% premium maintained through Year 12 (if OEM commitment lapses, plant financing collapses). Immediate actionable tasks: (1) Hire SALB Containment Protocol Director and ABS counsel by Month 1 (2026-11-12); (2) Contract independent auditor and establish Dispute-Resolution Panel by Month 3 (2027-01-12); (3) Execute binding producer-nation Protocol-Adoption Agreements by Month 6 (2027-04-12); (4) Launch ABS negotiations and baseline smallholder adoption survey Months 1–6 (2026-11-12 to 2027-04-12); (5) Bind sovereign/MDB funding framework agreements with gate-release mechanics by Month 12 (2027-10-12); (6) Plant multi-site Hevea trials and commission alternative-crop pilots by Month 12 (2027-10-12); (7) Allocate USD 13.9B unallocated balance at Month 6 (2027-04-12) budget baseline.