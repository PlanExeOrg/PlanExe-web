**3 open decisions: 2 high and 1 medium severity.** Urgent: the payer and cap treatment of the USD 7.0B bank lending, which must be settled before the Month 3 (2027-01-08) funder commitments. The trial-station permit route is needed by about Month 2 (2026-12-08), and the hub cost gate by about Month 18 (2028-04-08). Until then the plan can safely start the containment technical working group, inspector capacity building, the ABS framework, and the levy design.

| # | Decision | Severity | Owner | Decide by | Blocks |
|---|---|---|---|---|---|
| 1 | Payer and cap treatment for USD 7.0B bank lending | 🔴 High | Program Steering Committee with each development-bank representative (tranches above USD 1.0B). | Month 3 (2027-01-08): sovereign and bank commitments depend on it; the binding repayment source is due by Month 18 (2028-04-08). | Gate 1 funding commitments (Month 3 = 2027-01-08), the USD 15B binding capital test (Month 12 = 2027-10-08), and the replant-loan source. |
| 2 | Alternative-rubber hub gate and financing | 🔴 High | Program Steering Committee with the OEM Buyer Consortium. | Month 18 (2028-04-08): OEM letters of intent and offtake pricing are set then; before Month 60 (2031-10-08) offtake checkpoint. | Hub construction approval at the Month 84 (2033-10-08) gate and offtake negotiations. |
| 3 | Trial-station permitting route | 🟡 Medium | Core Project Team with Technical Panel; PSC if slip exceeds 12 months. | Month 2 (2026-12-08): permit lead times of 12-24 months require immediate filing. | Station commissioning (Month 12 = 2027-10-08) and the Month 24 (2028-10-08) Virulence Gate. |

## 1. Payer and cap treatment for USD 7.0B bank lending (🔴 High)

**Decision:** Who services the USD 7.0B concessional bank lending, and is debt service inside or outside the USD 30B cap?

**Why it is open:** Canonical facts leave the payer open. Debt service is about USD 449M/yr from about Month 60 (2031-10-08) (about USD 9.0B repaid) (estimate). Reviews propose 40% levy / 40% sovereign / 20% royalties, but 40% of levy is about 67% of USD 270M/yr, breaching the FM7 30% tripwire.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Debt service is a cap-funded cost, paid mainly by sovereign grants plus royalties, with levy share held within the 30% tripwire. | Spendable pillar money falls by about USD 2B. Gate 1 payer test (at least 80% of debt service named by Month 12 = 2027-10-08) can be met. | capital_stack, pillar_allocation, mdb_repayment_open_decision, Debt Service Covenant. |
| B. Debt service sits outside the cap, guaranteed by named sovereigns. | Pillars stay at USD 30B, but sovereign exposure rises by about USD 9.0B (estimate). The 25% funder ceiling may be breached. | total_budget_cap definition, funding_commitments_month3, capital_stack. |
| C. Downsize or drop bank lending and move to a grant- and levy-funded programme. | Removes repayment risk, but USD 7.0B must be replaced or scope cut. This is the Gate 1 fallback. | capital_stack, pillar_allocation, replant_finance_terms. |

- **If nobody decides:** Gate 1 fails at Month 3 (2027-01-08) or Month 12 (2027-10-08). Scale-up is delayed. If no repayment source exists by Month 18 (2028-04-08), bank-financed scope is cancelled.
- **Owner:** Program Steering Committee with each development-bank representative (tranches above USD 1.0B).
- **Decide by:** Month 3 (2027-01-08): sovereign and bank commitments depend on it; the binding repayment source is due by Month 18 (2028-04-08).
- **Blocks:** Gate 1 funding commitments (Month 3 = 2027-01-08), the USD 15B binding capital test (Month 12 = 2027-10-08), and the replant-loan source.

## 2. Alternative-rubber hub gate and financing (🔴 High)

**Decision:** For hub approval at Month 84 (2033-10-08), is the cost gate tightened to at most USD 1.47/kg, or are gate-limit hubs fully programme-financed, or is the offtake cap raised?

**Why it is open:** The gate passes at USD 1.62/kg, but bankability needs at most about USD 1.47/kg. At 1.62 coverage is 0.80 (estimate). The planning split of 50% programme (USD 600M) and 50% offtake-backed debt (USD 600M) fails at the gate limit.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Tighten the hub-approval cost test to at most USD 1.47/kg; keep 50/50 split. | Fewer hubs qualify. Hub debt stays at USD 600M outside the cap. 1.62/kg is described as within 20% of Hevea. | year7_alt_rubber_cost_gate, hub_bankability_threshold, Pitch Gate 3. |
| B. Keep 1.62/kg gate; finance gate-limit hubs 100% by the programme. | USD 1.2B falls against the USD 7.5B pillar, which crowds out pilots and other scope. | hub_financing_split, pillar_allocation. |
| C. Raise the offtake price cap above USD 1,550/t. | Raises OEM cost and may reduce offtake appetite below the 80% threshold. | hub_economic_chain, offtake_milestones. |

- **If nobody decides:** Hubs passing the gate are unbankable; the debt half fails and hub approval at Month 84 (2033-10-08) stalls.
- **Owner:** Program Steering Committee with the OEM Buyer Consortium.
- **Decide by:** Month 18 (2028-04-08): OEM letters of intent and offtake pricing are set then; before Month 60 (2031-10-08) offtake checkpoint.
- **Blocks:** Hub construction approval at the Month 84 (2033-10-08) gate and offtake negotiations.

## 3. Trial-station permitting route (🟡 Medium)

**Decision:** Will the 4 high-containment trial stations use existing permitted facilities (Month 12 = 2027-10-08) or move to Month 18-24 (2028-04-08 to 2028-10-08)?

**Why it is open:** Canonical plan requires at least 4 stations by Month 12 (2027-10-08). Self-audit says permits take 12-24 months and biosafety approval 12-18 months, so Month 12 (2027-10-08) is infeasible unless existing permitted sites are used.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Use existing permitted facilities, keep Month 12 (2027-10-08). | Keeps the Month 24 (2028-10-08) Virulence Gate. Limits site choice, with possible partner dependence. Cost about USD 12-20M (estimate). | trial_station_siting (site list). |
| B. Build new stations and move to Month 18-24 (2028-04-08 to 2028-10-08). | Virulence Gate baseline slips; Month 84 (2033-10-08) cultivar gate is at risk. | trial_station_siting, resistance_architecture, Month 24 (2028-10-08) gate. |
| C. Hybrid: 2 existing sites at Month 12 (2027-10-08), rest by Month 24 (2028-10-08). | Partial data at Month 24 (2028-10-08), with a reduced first Virulence Gate. | trial_station_siting, Virulence Gate design. |

- **If nobody decides:** Permit applications start late; stations slip beyond Month 12 (2027-10-08) and the Month 24 (2028-10-08) Virulence Gate loses its baseline.
- **Owner:** Core Project Team with Technical Panel; PSC if slip exceeds 12 months.
- **Decide by:** Month 2 (2026-12-08): permit lead times of 12-24 months require immediate filing.
- **Blocks:** Station commissioning (Month 12 = 2027-10-08) and the Month 24 (2028-10-08) Virulence Gate.

## Choices made on your behalf

Set when the scenario was selected, not by you. Confirm or change them.

| Lever | Chosen | Strongest alternative | Why it matters | Revisit by |
|---|---|---|---|---|
| Containment Protocol Legal Architecture | Protocol negotiated as a standard under the IPPC framework, adopted by national plant protection organizations. | Regional compact of SALB-free Asian and African countries first (Consolidator's Shield). | Sets protocol reach and speed; IPPC adoption is expected only at Months 36-60 (2029-10-08 to 2031-10-08) (estimate). | Month 24 (2028-10-08) (regional compacts and 15 commitment letters). |
| Resistance Breeding Strategy | Pyramided Hevea resistance from wild Brazilian accessions into elite Asian clones, tested at hotspot sites. | Gene editing of susceptibility genes (Pioneer's Gambit), or crown-and-trunk grafting. | Determines cultivar timing and dependence on ABS access and regulation. | Month 60 (2031-10-08) (last Virulence Gate) and the Month 84 (2033-10-08) gate. |
| Stage-Gate and Capital Release Design | Adaptive tranches with partial release on partial KPI attainment and reallocation among pillars. | Fixed pass-or-stop gates returning unspent funds (Consolidator's Shield). | Controls funder confidence and how much capital is released at each gate. | Month 36 (2029-10-08) gate. |
| Program Governance and Decision Rights | Independent multilateral secretariat with producer, OEM and development-bank seats and binding gate authority. | Lead-nation consortium with rotating chairs (Consolidator's Shield), or an endowment foundation. | Defines who decides gates and whether funders accept binding authority. | Month 3 (2027-01-08) (Technical Gate Charter signing). |
| Capital Stack and Industry Levy Mechanism | Per-tonne industry levy into a ring-fenced trust, alongside sovereign grants and bank lending. | Sovereign and bank funding with in-kind industry contribution, or outcome-linked bonds as the main instrument. | The levy of USD 270M/yr carries stable funding but depends on compliance above 80%. | Month 24 (2028-10-08) pilot audit; Month 48 (2030-10-08) fallback trigger. |
