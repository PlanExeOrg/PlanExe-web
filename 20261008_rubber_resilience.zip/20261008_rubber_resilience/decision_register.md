**4 open decisions: 4 high severity.** Urgent decisions are the plant financing split and price-floor payer (both due at the Month 6 = 2027-04-12 budget baseline), and the definition of 'binding' before auditor scope is pre-registered at Month 6 (2027-04-12). The cost-gate versus offtake-price choice must settle by Month 48 (2030-10-12). Before these are made, the plan can safely proceed with containment work, the IPPC secretariat, ABS agreements, breeding site planting by Month 12 (2027-10-12) and pilots, while holding plant capex and price-floor commitments uncommitted.

| # | Decision | Severity | Owner | Decide by | Blocks |
|---|---|---|---|---|---|
| 1 | Definition of 'binding' at Month 36 (2029-10-12) gate | 🔴 High | Steering Council, with funders' consultation | Month 6 (2027-04-12), when auditor scope and KPI definitions are pre-registered. | Month 36 (2029-10-12) (Year 3) gate and the USD 7.0B tranche; auditor pre-registration at Month 6 (2027-04-12). |
| 2 | Plant financing split and Phase 5 funding | 🔴 High | Steering Council with funders | Month 6 (2027-04-12) (budget baseline); Phase 5 funding by Month 60 (2031-10-12). | Month 6 (2027-04-12) budget baseline; wave 1 FID at Month 72 (2032-10-12). |
| 3 | Cost gate versus offtake price | 🔴 High | Steering Council | Month 48 (2030-10-12), before purchase-option contracts (Months 48-60 = 2030-10-12 to 2031-10-12) are negotiated. | Month 60 (2031-10-12) portfolio decision; wave 1 FID at Month 72 (2032-10-12); Year 12 gate. |
| 4 | Payer for the smallholder price floor | 🔴 High | Steering Council with funders | Month 6 (2027-04-12) budget baseline; legally binding commitments were targeted for Month 18 (2028-04-12). | Month 6 (2027-04-12) budget baseline; Month 18 (2028-04-12) price-floor commitments; smallholder replant uptake. |

## 1. Definition of 'binding' at Month 36 (2029-10-12) gate (🔴 High)

**Decision:** What must 'binding national embedding' mean at the Month 36 (2029-10-12) gate that releases USD 7.0B: signed agreements, or enacted law?

**Why it is open:** Canonical gate requires binding embedding in 3 of 5 producers at Month 36 (2029-10-12), but embedding completes Months 36-48 (2029-10-12 to 2030-10-12) and the stop test is at Month 54 (2031-04-12). Executive Summary and premortem FM1 use different wording.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Signed Protocol-Adoption Agreement plus named agency plus funded inspector posts at Month 36 (2029-10-12); enactment by Month 48 (2030-10-12); Month 54 (2031-04-12) stop test kept as a post-gate condition. | Gate is verifiable at Month 36 (2029-10-12) and the Month 36 (2029-10-12) schedule holds; legal risk is carried to Month 54 (2031-04-12) after tranche release. | phase1_gate_criteria_month36; protocol_milestones; protocol_stop_threshold wording; Executive Summary. |
| B. Keep a signed-agreement test at Month 36 (2029-10-12) and move the enacted-law test into a follow-on tranche condition. | Part of the USD 7.0B is tied to enactment; releases may be staged and the 80% floor interacts. | tranche_release_rules; gate criteria; escalation matrix. |
| C. Require enacted law at Month 36 (2029-10-12) and accept a later gate. | Strongest assurance; the Month 36 (2029-10-12) gate and all later gates slip (estimate 12 months or more), delaying scale-up. | gate_schedule; phase_structure; all downstream milestones. |

- **If nobody decides:** Ambiguity persists; the auditor pre-registers scope by Month 6 (2027-04-12) without a clear test and the Month 36 (2029-10-12) verdict is likely disputed.
- **Owner:** Steering Council, with funders' consultation
- **Decide by:** Month 6 (2027-04-12), when auditor scope and KPI definitions are pre-registered.
- **Blocks:** Month 36 (2029-10-12) (Year 3) gate and the USD 7.0B tranche; auditor pre-registration at Month 6 (2027-04-12).

## 2. Plant financing split and Phase 5 funding (🔴 High)

**Decision:** What share of the USD 1.6B commercial plant capex is financed by the program versus OEM/partner/project finance, and how is the post-Month 216 (2044-10-12) period funded?

**Why it is open:** Budget counts 100% program-financed with senior debt USD 0 and DSCR about -0.1, while the pitch presents co-investment, project finance, binding offtake and levy self-financing as settled.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Program finances 100% in base case; the pitch is corrected to present co-investment as open. | Budget stays at USD 1.6B; no leverage; offtake stays purchase-option (Months 48-60 = 2030-10-12 to 2031-10-12). | Pitch; open_decision_plant_financing_split. |
| B. Seek an OEM/partner co-investment share, set at Month 6 (2027-04-12) and conditional on offtake. | Lowers program capex but needs OEM terms; may delay wave 1 FID at Month 72 (2032-10-12) if not secured. | alt_rubber_unit_definition; commercial_plant_program; budget lines; offtake structure. |
| C. Defer the split to the Month 60 (2031-10-12) portfolio decision and hold plant capex uncommitted. | Keeps flexibility; risks FID slip at Month 72 (2032-10-12); Phase 5 renewal, endowment or government assumption stays unsettled. | portfolio_decision_month60; phase_structure. |

- **If nobody decides:** Budget keeps counting 100% program-financed (USD 1.6B) and the pitch claims remain unsupported.
- **Owner:** Steering Council with funders
- **Decide by:** Month 6 (2027-04-12) (budget baseline); Phase 5 funding by Month 60 (2031-10-12).
- **Blocks:** Month 6 (2027-04-12) budget baseline; wave 1 FID at Month 72 (2032-10-12).

## 3. Cost gate versus offtake price (🔴 High)

**Decision:** Which gives way: the cost KPI, the OEM premium, or a funded operating subsidy?

**Why it is open:** The Year 12 gate allows delivered cost up to 30% above Hevea (about USD 2.60/kg) and the processing KPI is USD 2.50/kg, both above the assumed USD 2.20/kg offtake price; operating gap USD 9.6M/year.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Tighten the cost KPI and FID rule to at or below the offtake price. | Plants are financeable if met, but gates are harder; more likely to fail Month 60/72 (2031-10-12, 2032-10-12) tests. | alt_rubber_cost_kpis; portfolio_decision_month60; escalation matrix. |
| B. Raise the OEM premium target above 10%. | Raises revenue per kg; OEM willingness untested; risk for the 8-of-10 offtake coverage. | hevea_benchmark_and_offtake_price; revenue and gap figures. |
| C. Accept and size an operating subsidy explicitly. | The USD 0.6B line covers only about USD 115M (estimate) at base case; larger subsidy needs new allocation from the USD 13.9B balance. | alt_rubber_operating_gap; documented_budget_lines. |

- **If nobody decides:** Gates stay as written; plants may pass the gate yet remain unfinanceable.
- **Owner:** Steering Council
- **Decide by:** Month 48 (2030-10-12), before purchase-option contracts (Months 48-60 = 2030-10-12 to 2031-10-12) are negotiated.
- **Blocks:** Month 60 (2031-10-12) portfolio decision; wave 1 FID at Month 72 (2032-10-12); Year 12 gate.

## 4. Payer for the smallholder price floor (🔴 High)

**Decision:** Who pays for the proposed 90%-of-Hevea price floor, and is it binding?

**Why it is open:** Pitch calls the floor binding by Month 18 (2028-04-12), but no budget line exists in the USD 16.1B documented lines; exposure USD 50-200M/year (estimate).

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Fund from the USD 13.9B unallocated balance at the Month 6 (2027-04-12) baseline. | Clear payer; reduces balance for other lines and competes with replant or reserve. | documented_budget_lines; unallocated balance; smallholder_price_floor. |
| B. Fund from the industry levy. | Levy of about USD 150M/year (estimate) already has other uses; may need a higher rate (range 0.5-1.0%). | industry_levy_rate_and_yield; funding_mix. |
| C. Sunset or conditional floor (e.g. Months 84-216 = 2033-10-12 to 2044-10-12, tied to cultivar and plant economics). | Caps exposure; weaker adoption incentive. | smallholder_price_floor; pitch; adoption_waypoints. |

- **If nobody decides:** The floor remains unfunded and is described only as proposed.
- **Owner:** Steering Council with funders
- **Decide by:** Month 6 (2027-04-12) budget baseline; legally binding commitments were targeted for Month 18 (2028-04-12).
- **Blocks:** Month 6 (2027-04-12) budget baseline; Month 18 (2028-04-12) price-floor commitments; smallholder replant uptake.

## Choices made on your behalf

Set when the scenario was selected, not by you. Confirm or change them.

| Lever | Chosen | Strongest alternative | Why it matters | Revisit by |
|---|---|---|---|---|
| Containment Protocol Authority | Embed the protocol in the IPPC and regional plant-protection framework; national agencies adopt it. | Dedicated program-funded SALB Containment Authority with its own inspectors. | Sets enforcement strength and the timing of the Month 36 (2029-10-12) gate. | Month 36 (2029-10-12) gate |
| Resistance Breeding Pathway | Conventional marker-assisted and genomic polygenic selection on Amazonian germplasm; no gene-editing. | Crown-budding on existing clones for earlier field protection. | Drives the zero-slack Year 7 timeline and regulatory exposure. | Month 48 (2030-10-12) interim check |
| Alternative Rubber Portfolio Breadth | Concentrate on Guayule and Russian dandelion with a few colocated plants. | Staged pilots and modular units, or a wider portfolio including bio-isoprene. | Determines USD 1.6B plant capex exposure and OEM offtake credibility. | Month 60 (2031-10-12) portfolio decision |
| Gate Evidence Verification Regime | Independent international auditor with pre-registered scope and methods. | Audit plus a separately funded adversarial red-team review. | Determines credibility of releases of the USD 7.0B, 6.5B, 4.5B and 4.0B tranches. | Month 6 (2027-04-12) (scope pre-registration) |
| Capital Stack and Sponsor Coalition | Ring-fenced industry resilience levy outside government budget cycles. | Sovereign and MDB anchor with matched industry contributions released at each gate. | The levy covers only about USD 3.7B of the USD 30B; the remainder relies on sovereign/MDB commitments. | Month 12 (2027-10-12) (binding framework agreements) |
