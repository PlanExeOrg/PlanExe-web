_Consistency: first pass found 3 high / 6 medium / 0 low contradictions. Repair: round 1: 28 edits → 1 high / 6 medium; round 2: 19 edits → 1 high / 8 medium. Published: round 1 (fewest high-severity issues). Shown below: the final check of the repaired documents (1 high / 6 medium / 2 low)._

## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Have 5-8 sovereigns and at least 2 development banks signed binding multi-year commitments (no funder above 25%), with a named payer for the USD 7.0B bank-lending debt service? | At least 5 sovereigns and 2 banks signed, no funder above USD 7.5B, Technical Gate Charter signed by Month 3; committed binding capital of at least USD 15B by Month 12 (proposed threshold); named payer covering at least 80% of debt service by Month 12 (proposed threshold). | Signed commitment letters and Technical Gate Charter (Month 3); written positions from 3 banks and 5 finance ministries on repayment source and escrow (Month 3); Debt Service Covenant (Month 12); binding repayment source for the USD 7.0B lending (Month 18). | Delay scale-up. If binding capital stays below USD 15B at Month 12, or no binding repayment source exists at Month 18, cancel bank-financed scope and resize to a grant- and levy-funded, containment-first programme. |
| 2 | Are the Nagoya/ABS agreements with Brazilian authorities and communities in force, and will at least 200 characterised wild Hevea accessions be delivered on time? | ABS negotiations complete by Month 6 (slip trigger Month 12); collection begins Month 8; at least 6 signed access agreements at Month 6; at least 200 accessions by Month 18, with a binding agreement covering at least 100 as the stop floor. | Signed ABS framework and access agreements (Month 3 framework, Month 6 completion); accession register (Month 18). | Delay the breeding schedule by 6-12 months. If no binding agreement covers at least 100 accessions by Month 18, end new wild collection, rely on repository germplasm (50-80 accessions, estimate), and reset the Month 84 cultivar gate. |
| 3 | Has the ASEAN levy pilot shown at least 80% compliance, so that the global rollout to USD 270M/yr can proceed by Month 36? | Collection running by Month 18; compliance above 80% to roll out globally by Month 36; below 60% (or full levy not operating by Month 48) activates the fallback cascade (proposed threshold). | Pilot receipts and compliance audit by Month 24; rollout decision by Month 30-36; outcome-linked bond framework (USD 0.5-1.0B) pre-negotiated before the fallback trigger. | Activate the cascade (higher bank loan-to-grant ratio, outcome-linked bonds, climate finance). If the fallback is not operating by Month 48, cancel scale-up and pivot to containment-only. |
| 4 | Does the Month 36 Protocol Readiness gate pass: enforceable import rules, trained inspectors and lab-cleared detections? | At least 15 producing countries with enforceable import rules (Asia 8, Africa 4, Americas 3), at least 500 trained and audited inspectors, at least 2 lab-cleared suspect or near-miss detections; 85-100% releases the full USD 4.5B, 70-85% proportional, below 70% releases USD 2.25B. | Country audit, inspector audit and laboratory records at the Month 36 gate; interim checks of at least 100 inspectors and 12-15 commitment letters at Month 24. | Partial release only. If fewer than 10 countries have enforceable rules at Month 48, stop scale-up spending and convert to a regional Asia-Africa compact. |
| 5 | Are at least 2 pyramided Hevea candidates ready at Month 84 (at least 3 resistance genes, at least 90% resistance, at least 85% of elite-clone yield, passing the Virulence Gate)? | At least 2 candidates, at least 85% of elite-clone yield over at least 2 years, at least 80% of at least 10 isolates defeated, 5+ year stability forecast; release 70% of the cultivar-phase tranche (50% if only 1 candidate), hold 30%. | Virulence Gate results at Months 24, 36, 48 and 60; Monte Carlo timeline (Month 6); trial yields and Technical Panel report published 60 days before the Month 84 gate. | Release only 50% of the cultivar-phase tranche and extend trials. If no candidate has 3 genes and passes a Virulence Gate by Month 60, cancel the pyramiding route and shift funds to alternative rubber and containment. |
| 6 | Do alternative-rubber pilots meet the cost and quality gate with at least 80% priced offtake, so that hub construction can be approved at Month 84? | Pilot cost at most USD 1.62/kg (a 20-25% premium is a partial score), tire-grade tests at 95% of Hevea specs, at least 80% of planned Year-10 volume under written priced offtake by Month 72, permits and tire specs validated, and hub debt coverage of at least 1.3x (the USD 1.47/kg bankability test) (proposed threshold). | 2-3 OEM letters of intent (Month 18); qualification test results (Months 12-30); offtake checkpoint (Month 60); binding offtake (Month 72); pilot cost data (Month 84). | Defer hub construction to Months 96-120, re-set the Month 144 target of 200,000 t/yr, and pivot to niche specialty latex (5,000-20,000 t/yr). If cost is above a 25% premium and offtake is below 60%, stop commercial hubs and keep the pillar at pilot scale. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: canonical_facts
    canonical: mdb_repayment_open_decision = Open: who services the USD 7.0B lending; about USD 449M/yr from about Month 60 (about USD 9.0B repaid)
    observed:  Repayment shares (40% levy / 40% sovereign / 20% royalties) proposed without cap treatment; FM7 tripwire 30% of levy
HIGH CF-002  document: executive_summary and pitch Gate 3
    canonical: hub_bankability_threshold = Debt financing only if opex is at most about USD 1.47/kg and coverage is at least 1.3x
    observed:  Gate passes at USD 1.62/kg, described as 'cost parity or better'
HIGH CF-003  document: executive_summary Overall Takeaway; repaired_review_plan Reviews 1, 3, 7
    canonical: reserves_inside_cap = Outbreak response reserve USD 0.5B (ceiling USD 1.0B)
    observed:  Increase Outbreak Response Reserve to USD 1.0-1.5B
MEDIUM CF-004  document: premortem FM1 and self_audit
    canonical: levy_fallback_trigger = Below 60% compliance or full levy not operating by Month 48
    observed:  Tripwire <60% at Month 24; activation by Month 30
MEDIUM CF-005  document: pitch (Smallholder Adoption) and review 12
    canonical: surveillance_premium_scale_cap = About USD 50M/yr at USD 25-33 per farmer per year
    observed:  300,000-500,000 farmers at Month 144; 2-3 million by Month 120
MEDIUM CF-006  document: review 8 and review 14; executive_summary
    canonical: smallholder_target = At least 1.5 million adopters at Month 144
    observed:  500,000 ha at Month 144 (Reviews 8, 14) vs Month 216 (Exec/Pitch)
MEDIUM CF-007  document: pitch and self_audit
    canonical: resistance_architecture = Pathogen genomics lab in Brazil by Month 2; Asian satellite by Month 9
    observed:  Live-pathogen station by Month 2; biosafety approval 12-18 months
MEDIUM CF-008  document: self_audit item 16 / executive_summary
    canonical: trial_station_siting = At least 4 stations by Month 12
    observed:  Permits 12-24 months before construction at Month 6
MEDIUM CF-009  document: review 4 item 1
    canonical: germplasm_milestones = At least 200 characterised wild Hevea accessions by Month 18
    observed:  50-80 existing accessions as fallback 'to ensure' Month 18 delivery
LOW CF-010  document: review 1, review 3, review 14
    canonical: outbreak_cost_vs_reserve_gap = USD 2-5B vs USD 0.5B reserve; residual USD 1.5-4.5B
    observed:  covers only 10-33%; USD 0.3B buffer
LOW CF-011  document: pitch and review 5
    canonical: germplasm_milestones = Nagoya/ABS complete Month 6; framework only at Month 3
    observed:  Secure formal germplasm-access agreement within 90 days
```

### 1. MDB repayment vs hard cap and levy capacity (🔴 High) — needs a project decision

- **Canonical facts (capital_stack, mdb_repayment_open_decision); Executive Summary Feedback item 5:** Capital stack counts USD 7.0B bank lending inside the USD 30B hard cap; repayment is about USD 449M/yr from Month 60 (about USD 9.0B repaid in total).
- **Review 9 / Review 11; Premortem FM7:** The repayment source is only recommended (e.g. 40% levy, 40% sovereign grants, 20% royalties). FM7 tripwire: debt service above 30% of annual levy receipts; the levy is USD 270M/yr.
- **Why it conflicts:** About USD 2B more is repaid than received. The documents do not say whether repayment is inside or outside the cap. Even the 40% levy share (about USD 180M/yr) is about 67% of levy receipts, breaching the 30% tripwire; at full debt service the figure is about 166%.
- **Suggested resolution:** Decide before Month 3 whether debt service is a cap-funded cost (reducing spendable pillar money by about USD 2B) or sits outside the cap, and name the payer. Do not set a levy share that breaches the FM7 tripwire. Keep the item as a showstopper.

### 2. Alternative-rubber gate cost vs offtake price and bankability (🔴 High) — needs a project decision

- **Executive Summary (Purpose and Goals); Pitch Gate 3; Canonical year7_alt_rubber_cost_gate:** Month 84 gate passes at pilot cost up to USD 1.62/kg; the Executive Summary calls this 'USD 1.62/kg cost parity or better'. The Hevea reference is USD 1.35/kg.
- **Canonical hub_economic_chain and hub_bankability_threshold; Review 9; Premortem FM3:** Offtake cap is USD 1,550/t. Debt financing needs opex of at most about USD 1.47/kg. At USD 1.62/kg coverage is 0.80 (gap about USD 12M/yr).
- **Why it conflicts:** A hub that passes the gate has opex above the offtake price and is unbankable by the plan's own test, so the 50/50 financing split (USD 600M offtake-backed debt) fails at the gate limit. USD 1.62/kg is a 20% premium, not parity.
- **Suggested resolution:** Either tighten the gate for hub approval to at most USD 1.47/kg, or decide in advance that gate-limit hubs are financed 100% by the programme (USD 1.2B against the USD 7.5B pillar) or the offtake cap is raised. Describe USD 1.62/kg as 'within 20% of Hevea', not parity.

### 3. Outbreak reserve target vs USD 1.0B ceiling (🔴 High)

- **Canonical reserves_inside_cap; Executive Summary Timeline and Budget; Pitch:** Outbreak reserve is USD 0.5B, funded by Month 3, ceiling USD 1.0B; reserves sit inside the cap.
- **Executive Summary Overall Takeaway; Review 1 item 1; Review 3 item 3; Review 7:** Reserve to be increased to 'USD 1.0-1.5B' by Month 3.
- **Why it conflicts:** USD 1.5B exceeds the USD 1.0B ceiling. Reserves are inside the cap, so any increase comes out of the USD 4.5B contingency pool, which worsens the stated USD 1.8B combined-stress shortfall. The source of the money is not stated.
- **Suggested resolution:** Keep the canonical funded amount of USD 0.5B at Month 3 with a USD 1.0B ceiling. Rewrite the uplift as 'up to USD 1.0B' and show it as a transfer from the contingency pool, with the revised free-pool figure.

### 4. Levy compliance checkpoint and fallback timing (🟡 Medium)

- **Canonical levy_ramp_and_revenue / levy_fallback_trigger; Pitch; Review 2 item 3:** Pilot collecting by Month 18; fallback cascade if compliance is below 60% or the full levy is not operating by Month 48.
- **Premortem FM1; Self Audit items 4, 6, 19; Review 5 item 3:** FM1: compliance under 70% at Month 21 and tripwire below 60% at Month 24. Self-audit: below 60% by Month 30 triggers bond issuance. Review 5: bond authority by Month 30; Review 2: bond framework by Month 36.
- **Why it conflicts:** The same fallback has trigger dates of Month 24, 30 and 48, and the bond-readiness date is Month 30 in some places and Month 36 in others. The documents also leave unclear whether compliance below 60% at Month 24 means 'activate now' or 'wait until Month 48'.
- **Suggested resolution:** Keep the canonical rule: measure at Month 24 (early warning, escalation only); activate the cascade if compliance is below 60% or the levy is not operating by Month 48. Set one date (Month 30) for the pre-negotiated bond framework and align all documents.

### 5. Number of farmers in surveillance schemes vs premium budget (🟡 Medium)

- **Canonical surveillance_premium_scale_cap; Premortem FM4:** Scaled premium budget capped at about USD 50M/yr at about USD 25-33 per farmer per year (implies about 1.5-2.0M farmers).
- **Pitch (Smallholder Adoption); Review 6; Review 12; Executive Summary:** Pitch (Month 144): 300,000-500,000 farmers in surveillance networks. Review 6 KPI 3 (Month 144): at least 1.5M enrolled. Review 12 and Executive Summary Takeaway: scale to 2-3 million farmers by Month 120. Executive Summary puts 300,000-500,000 in Phase 2.
- **Why it conflicts:** 300,000-500,000 farmers cost only about USD 7.5-16.5M/yr against a USD 50M cap, while 1.5-3M farmers cost USD 37-100M/yr. The enrolment figure also varies in timing (Month 84, 120 or 144).
- **Suggested resolution:** Treat 300,000-500,000 as the Phase 2 (by Month 84) level only. Set the Month 144 enrolment at a figure consistent with the cap (up to about 1.5-2.0M), or raise the cap. Make adopters (1.5M) and surveillance participants separate, labelled metrics.

### 6. Cultivar area target: timing and scale (🟡 Medium)

- **Executive Summary Phase 4; Pitch Gate 4 and Long-term Vision:** Cultivar area of at least 500,000 ha is a Month 216 target (Phase 4 and Gate 4).
- **Review 8 item 2; Review 14 item 3:** Review 8 puts cultivar area of at least 500,000 ha at the Month 144 gate; Review 14 triggers bond repayment at 500,000 ha by Month 144. The Month 144 gate also needs 1.5M smallholders adopting.
- **Why it conflicts:** The same milestone has two dates. Smallholder area is estimated at 1.2-2M ha, so 1.5M adopters imply more than 500,000 ha (about 0.4-0.67 ha each); a Month 216 floor of 500,000 ha is therefore below the area implied at Month 144.
- **Suggested resolution:** Fix a single date and reconcile with the adopter count: state the average replanted area per adopter and derive the hectare target (or redefine 'adopter'). Keep Month 216 for the 500,000 ha floor only if the Month 144 adoption metric is relabelled as farmers enrolled or partially replanted.

### 7. Brazil genomics lab: 'established' vs live-pathogen station vs recruitment (🟡 Medium)

- **Canonical resistance_architecture; Executive Summary; Premortem FM5:** Lab established by Month 2 (site, host lab, director named); Asian satellite operating by Month 9; sequencing by Month 12.
- **Pitch (Collaboration); Self Audit items 13 and 16; Reviews 12 and 13:** Pitch: 'live-pathogen station by Month 2'. Self-audit: recruitment takes 4-8 months, biosafety approval 12-18 months. Review 12 says recruit the director by Month 1, Review 13 by Month 2.
- **Why it conflicts:** A live-pathogen station cannot operate at Month 2 if biosafety approval takes 12-18 months and recruitment 4-8 months. The Month 9 'operating' target also precedes the stated biosafety window. The first Virulence Gate at Month 24 depends on these dates.
- **Suggested resolution:** Use the canonical definition of 'established' (site, partner, director named) at Month 2. Remove 'live-pathogen station by Month 2' and set biosafety certification, operating and sequencing dates (Months 9-12) consistent with the permit lead time, or re-time the first Virulence Gate.

### 8. Permit lead times vs trial-station and lab schedule (🟡 Medium) — needs a project decision

- **Canonical trial_station_siting; Self Audit item 16; Executive Summary (Months 6-12):** At least 4 high-containment trial stations by Month 12; biosafety approval is the predecessor to lab commissioning at Month 12.
- **Self Audit item 16 (Workstream 4):** Environmental permits take 12-24 months and are the predecessor to trial-station construction at Month 6; biosafety approval takes 12-18 months.
- **Why it conflicts:** A permit that takes 12-24 months cannot precede construction at Month 6, and a 12-18 month biosafety window starting at Month 0 leaves no slack for Month 12 commissioning. The schedule is internally impossible unless existing permitted sites are used.
- **Suggested resolution:** Decide whether the 4 stations use existing permitted facilities (keeping Month 12) or move to Month 18-24. Re-time the dependent Virulence Gate baseline accordingly.

### 9. Funder-withdrawal size after a post-gate incursion (🟡 Medium)

- **Executive Summary Risk 1 and Feedback (40-60% probability of 50-80% withdrawal):** Incursion at Months 48-60 after gate passage leads to 50-80% retroactive funder withdrawal.
- **Review 1 item 2; Review 15 item 1; Self Audit item 20; Premortem FM1:** Same event: withdrawal of 40-60% of remaining capital (about USD 10-15B). Self-audit item 20 says 20-40%; FM1 (gate dispute) says USD 3-8B.
- **Why it conflicts:** The same trigger carries three different ranges. 50-80% of the remaining USD 24B is USD 12-19B, above the USD 10-15B quoted elsewhere. The scenarios are not labelled as different events.
- **Suggested resolution:** Choose one range for the incursion-after-gate scenario (labelled estimate), keep USD 3-8B only for the gate-dispute scenario, and state the base (remaining capital after Month 36 is USD 24B).

### 10. Germplasm fallback cannot cover the 200-accession target (🟡 Medium)

- **Canonical germplasm_milestones:** At least 200 characterised wild accessions delivered by Month 18.
- **Review 4 item 1; Review 13 item 3; Premortem FM6:** Fallback: 50-80 existing CEPLAC/Embrapa accessions 'to ensure Month 18 delivery'.
- **Why it conflicts:** 50-80 accessions are 25-40% of the target and are described as low-diversity and 50-100 years old, so they cannot ensure delivery of 200. FM6's stop floor of 100 is also above the fallback pool.
- **Suggested resolution:** Say the fallback keeps pipelines running but does not meet the 200 target; re-set the Month 84 expectations if wild collection slips. Keep the 100-accession stop floor as the decision threshold.

### 11. Arithmetic errors in reserve coverage and contingency buffer (⚪ Low)

- **Review 1 item 1; Review 3 item 3:** USD 0.5B reserve covers 10-33% of the USD 2-5B full-establishment cost.
- **Recomputed from canonical outbreak_cost_vs_reserve_gap; Review 14 item 3:** 0.5/5 = 10% and 0.5/2 = 25%. Review 14: free reserve falls to USD 1.5B and 'leaves only USD 0.3B buffer' against claims of USD 2.4-6.3B.
- **Why it conflicts:** Coverage is 10-25%, not 10-33%. A USD 1.5B pool against USD 2.4-6.3B of claims is a shortfall of USD 0.9-4.8B, not a USD 0.3B buffer.
- **Suggested resolution:** Correct to 10-25%; restate the Review 14 outcome as a shortfall of USD 0.9-4.8B (estimate) if the USD 3.0B outcome-linked instruments fail and the pool absorbs them.

### 12. Deadlines in pitch call to action and review timeline (⚪ Low)

- **Canonical germplasm_milestones and protocol_adoption_timeline:** ABS framework by Month 3 (draft), formal agreements by Month 6; regional compacts by Month 24; IPPC proposal by Month 18.
- **Pitch (Call to Action); Review 5 item 1:** Pitch 90-day contact list includes 'Secure Brazil's formal germplasm-access agreement'; Review 5 says commit to regional compacts by Month 18; Pitch lists Month 24 'Regional Adoption' before Month 18 'International Standard'.
- **Why it conflicts:** The formal ABS agreement in a 90-day list reads as a Month 3 deadline, half the canonical time. Compacts are due at Month 24, not Month 18, and the Month 24 item is listed before the Month 18 item.
- **Suggested resolution:** Change the pitch item to 'advance the ABS framework (formal agreements by Month 6)'; use Month 24 for compacts in Review 5; order the pitch milestones chronologically.

## Summary

The plan is largely aligned with the canonical facts: gate schedule, pillar split, reserves (USD 5.9B), the Month 36 gate criteria, the Virulence Gate dates and the offtake milestones now match. The most material remaining problems are economic and unresolved rather than typographical. These are the debt-service payer and cap treatment for the USD 7.0B lending, a cost gate (USD 1.62/kg) that passes hubs the plan itself calls unbankable, and an outbreak-reserve uplift to USD 1.5B above the USD 1.0B ceiling. Smaller inconsistencies remain in levy-fallback dates, surveillance enrolment against the USD 50M/yr cap, the cultivar-area target, lab and permit timing, and a few arithmetic slips. Most are repairable by aligning text to the canonical values, but the first two need explicit project decisions before the Month 3 funder commitments.