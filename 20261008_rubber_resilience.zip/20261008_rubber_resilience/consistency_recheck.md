_Consistency: first pass found 2 high / 5 medium / 1 low contradictions, and the arithmetic check found 1 wrong calculation. Repair: round 1: 23 edits → 1 high / 6 medium; round 2: 17 edits → 1 high / 6 medium. Published: round 1 (fewest high-severity issues). Shown below: the final check of the repaired documents (1 high / 6 medium / 1 low)._

## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Are the ABS agreements with Brazil CGen and at least 3 Amazonian community groupings executed, and is germplasm on track to be planted at all 4 breeding sites by Month 12? | ABS agreements executed by Month 6 (2027-04-12); 4 sites planted by Month 12 (2027-10-12); not planted at 4 sites by Month 18 (2028-04-12) triggers the stop rule. A slip beyond Month 12 moves the Year 7 gate to Month 96 (2034-10-12) or later (estimate). | Executed ABS agreements and written CGen timelines at Month 6; seed lots in quarantine at trial sites by Month 9; planting records at Month 12. | Delay: the Year 7 gate moves to Month 96 (2034-10-12) or later, since the zero-slack timeline cannot be compressed. Options are ex-situ accessions from partner institutes or the crown-budding fast-track (about USD 0.25B (estimate), which needs a new steering-council decision and is funded from the USD 13.9B unallocated balance). Alternatively the gate is formally re-dated and the breeding tranche is held. |
| 2 | Does the baseline smallholder survey (and later the bridging-finance pilot) support the 45% planning uptake, so that the USD 6.75B replant line can be committed at full size? | Stated willingness to replant of at least 30% on a survey of 2,000+ farms (below 30% is the failure trigger; below 35% is an early warning). Pilot bridging-finance default below 20% (FM3 tripwire; the KPI document uses below 15%). Baseline survey due Month 6 (2027-04-12). | Survey report at Month 6; pilot results on 10,000 smallholders from Months 12-36 (2027-10-12 to 2029-10-12), published at Month 36. | Downsize: move to the 30-40% conservative scenario and shrink the USD 6.75B line (2.25M ha at USD 3,000/ha) before tranches are committed. The freed capital is reallocated to estate trials or processing at the Month 6 budget baseline. |
| 3 | Are binding 25-year framework agreements signed with at least 5 funders, none above 20% (USD 6.0B), with the 80% release floor, 45-day disbursement and a multi-year levy commitment? | At least 5 binding agreements by Month 12 (2027-10-12); each funder at most 20% (USD 6.0B); minimum 80% of a tranche released on partial gate success; levy about USD 150M/year (estimate); binding commitments of at least USD 20B (proposed threshold) by Month 18 (2028-04-12). | Signed agreements and term sheets (release floors, force-majeure, withdrawal penalties) at Month 12; levy pledge letters from the top 10 tire makers; commitments reconciled at Month 18. | Delay or downsize: no Phase 2 spending is released, workstreams are re-sequenced toward containment and breeding, and the deployable envelope (USD 25.5B) is cut to what is actually committed. |
| 4 | Has the Month 36 (2029-10-12) gate been passed on auditor-verified evidence of protocol adoption and enforcement? | IPPC adoption vote held; binding national embedding in at least 3 of the top 5 producers; at least 100 inspectors active; red-team drills completed in at least 3 countries with at least 95% detection accuracy; no unmanaged incursion. Early indicators: MoUs signed by Month 6 (2027-04-12), 100 inspectors by Month 12 (2027-10-12), at least 100,000 inspected lots a year (failure below 30,000). | Independent auditor verdict and published evidence at Month 36 (verdict within 30 days, adjudication within 60 days); legal status of embedding at Month 54 (2031-04-12). | Split or stop: scale-up stays frozen. The USD 7.0B tranche is released at a minimum of 80% only on partial success, otherwise withheld. Fewer than 3 binding producers at Month 54 (2031-04-12) triggers Phase 2 cancellation or re-scope to a coalition of compliant producers. |
| 5 | Can wave 1 plants (4 plants, USD 0.8B capex) be committed at Month 72, on verified cost, quality, offtake and financing? | Feedstock at most USD 1.20/kg (Guayule) and USD 1.00/kg (dandelion) at Month 48 (2030-10-12); extraction yield at least 85%/80% and quality variance within +/-10% at Months 36 and 60; delivered-cost forecast under 30% above Hevea (and, see contradictions, at or below the USD 2.20/kg offtake price); purchase-option offtake covering at least 70% of capacity (8 of 10 OEMs); plant financing split decided. | Pilot data at Months 36 and 48 (2029-10-12, 2030-10-12); OEM purchase-option contracts (Months 48-60, 2030-10-12 to 2031-10-12); portfolio decision at Month 60 (2031-10-12); debt-capacity analysis. | Downsize or stop: no wave 1 final investment decision at Month 72 (2032-10-12). Either add processing-innovation capital or redirect USD 0.8-1.2B (estimate) to resistant-Hevea breeding. The alternative-rubber pillar stays at the USD 0.2B pilot scale as a research hedge, and wave 2 is not started. |
| 6 | Has the Month 84 (2033-10-12) cultivar-readiness gate been met, with smallholder enrolment on waypoint? | Yield at least 90% of elite clones (95%+ pass, 90-95% conditional, below 90% fail); at least 3 independent resistance sources confirmed in at least 5 field trials; lesion under 5 mm, defoliation 20% or less under 10x inoculation; at least 30% of eligible smallholders enrolled (stop trigger below 30%). | Multi-site trial data from sites planted at Month 12; Month 48 (2030-10-12) interim check (yield penalty above 15% starts the crown-budding decision); independent auditor verdict at Month 84. | Stop or reduce the Year 7 tranche (USD 6.5B): below 90% fails the gate. A 90-95% result gets a conditional release (minimum 80%, proposed) with extended durability monitoring. Enrolment below 30% halts smallholder expansion and triggers reallocation to estate trials and processing. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: canonical_facts
    canonical: phase1_gate_criteria_month36 = binding national embedding in at least 3 of the top 5 producers at Month 36 (2029-10-12); national embedding completes Months 36-48
    observed:  Gate needs binding embedding at Month 36, yet embedding completes Months 36-48 and is tested at Month 54
HIGH CF-002  document: pitch
    canonical: open_decision_plant_financing_split = Open decision: share of commercial plant capex financed by program vs OEM/partner/project finance (budget counts 100% = USD 1.6B until decided)
    observed:  Co-investors, project finance, binding offtake, margins and levy self-financing presented as facts
HIGH CF-003  document: canonical_facts
    canonical: alt_rubber_cost_kpis = Month 144: delivered cost under 30% above Hevea; Month 84: processing cost at most USD 2.50/kg
    observed:  Gate ceiling about USD 2.60/kg vs offtake USD 2.20/kg
HIGH CF-004  document: pitch
    canonical: smallholder_price_floor = Minimum price guarantee 90% of Hevea benchmark (proposed threshold); no budget line in documented lines
    observed:  "Price floors are binding"; "legally binding price-floor commitments by Month 18"
HIGH CF-005  document: Executive Summary Risks #3 and Goals; premortem FM3
    canonical: adoption_waypoints = Month 84: at least 30% enrolled (stop below 30%); Month 144: at least 40% of eligible area replanted
    observed:  Stop at <25% by Month 54, reduce targets 40%, reallocate USD 0.8-1.2B; 45% by Month 144 as a goal
MEDIUM CF-006  document: Executive Summary Risks #2; Review 4/13; Self-audit
    canonical: fallback_crown_budding = About USD 0.25B (estimate), via the USD 13.9B unallocated balance; needs a new steering-council decision
    observed:  Pre-commit by Month 18 (2028-04-12); funded "within contingency reserve"
MEDIUM CF-007  document: Self-audit item 2; Review 8 and 10
    canonical: breeding_trigger_month48 = Yield penalty above 15% (below 85% of elite) by Month 48 (2030-10-12)
    observed:  <90% of elite at Month 48; 85-90% conditional pass
MEDIUM CF-008  document: Self-audit item 2; Review 2, 9 and 10
    canonical: portfolio_decision_month60 = If cost or process targets are missed by Month 60 (2031-10-12), decide between added processing-innovation capital or redirecting funds to Hevea breeding; no wave 1 commitment before this decision
    observed:  Reallocation/re-scope decided at Month 48; binding contracts due by Month 48
MEDIUM CF-009  document: pitch (Long-term Vision); Review 13; Self-audit item 12
    canonical: alt_rubber_volume_and_land = 16,000 t/year by Month 120; 32,000 t/year by Month 192; about 0.2% of global market
    observed:  10-20% non-Hevea share; 32,000 t/year expected by Month 144; Hevea share 90% to 80%
MEDIUM CF-010  document: Review 5 item 3; Review 8 item 3; Review 10 item 3; Review 14 item 3
    canonical: industry_levy_rate_and_yield = 0.75% of covered purchases = about USD 150M/year (USD 147M recomputed) (estimate)
    observed:  USD 1.5-2.0B shortfall for a 20-30% fall; revenue USD 52.8M and gap USD 27.2M at a 5% premium
MEDIUM CF-011  document: Review 13 item 2
    canonical: protocol_milestones = Draft protocol for IPPC working-group comment Months 3-4; producer-nation MoUs by Month 6
    observed:  MoUs (Month 6) "must precede" the IPPC draft (Months 3-4)
LOW CF-012  document: pitch; Executive Summary
    canonical: program_duration_and_start = 25 years = Months 0-300; Month 0 = 2026-10-12
    observed:  Month 300 = 2035-10-12; 120 days; Phase 2-5 label on Month 12-36 items
```

### 1. Month 36 gate requires binding national embedding that completes after Month 36 (🔴 High) — needs a project decision

- **canonical_facts phase1_gate_criteria_month36; Executive Summary (Key Deliverables, Action Orientation):** Month 36 (2029-10-12) gate: "binding national embedding in at least 3 of the top 5 producers"; Executive Summary: agreements "signed by ≥3 of 5 producers" at Month 36.
- **canonical_facts protocol_milestones and protocol_stop_threshold; Executive Summary (Risks); premortem FM1:** "National embedding completes Months 36-48 (2029-10-12 to 2030-10-12)"; stop test at Month 54 (2031-04-12); Executive Summary Risk 1: fewer than 3 embed by Month 54 "invalidating Year 3 gate".
- **Why it conflicts:** The gate that releases USD 7.0B at Month 36 cannot verify an embedding scheduled to finish up to 12 months later, and the stop test falls 18 months after the gate. "Binding adoption" means signed agreements in some places and enacted law in others.
- **Suggested resolution:** Define the term. Options: (a) at Month 36 "binding" = signed Protocol-Adoption Agreement plus named agency plus funded inspector posts (the A1/FM1 wording), with enactment by Month 48 and the Month 54 stop test as a separate post-gate condition; (b) move the enacted-law test into a follow-on tranche condition; (c) require enacted law at Month 36 and accept a later gate. The canonical facts must state one definition.

### 2. Pitch asserts plant co-investment, project finance, binding offtake, margins and levy self-financing (🔴 High) — needs a project decision

- **Pitch (Stakeholder Benefits, Collaboration Opportunities, Long-term Vision):** Pitch: Bridgestone and Continental "invited as co-investors"; "Banks and DFIs structure project finance for plants. OEMs write binding offtake contracts"; offtake "secure[s] alternative-rubber margins"; by Year 25 the programme "cycles to ... self-financing from levy revenues. Donor capital is repaid or reinvested".
- **canonical_facts (open_decision_plant_financing_split, alt_rubber_debt_and_coverage, oem_offtake_structure, phase_structure); Review 11 and 14:** Plant financing split is an open decision (budget counts 100% = USD 1.6B); base-case senior debt USD 0; illustrative DSCR about -0.1; operating shortfall USD 9.6M/year; offtake is purchase-option contracts (1.5% reservation fee) signed Months 48-60; Phase 5 funding is a decision, and agreements are described as disbursing only through Month 216 (2044-10-12).
- **Why it conflicts:** The pitch states as settled the financing, binding offtake, margins and post-Month 216 self-financing that every other document treats as unresolved, with negative coverage. Levy of about USD 150M/year (estimate) is not shown to cover the surveillance, extension and price-floor costs it would have to carry.
- **Suggested resolution:** Present these as open decisions with dates (financing split by Month 6, purchase-option contracts by Month 60) and remove "binding offtake", "margins" and "repaid" claims. Options for Phase 5: automatic tranche renewal, levy converted to an endowment, or assumption by government budgets. None may be stated as fact until a funding agreement covers Months 216-300.

### 3. Year 12 cost gate permits costs above the assumed offtake price (🔴 High) — needs a project decision

- **canonical_facts alt_rubber_cost_kpis; Review 6 KPI 3; premortem FM2 stop rule:** Month 144 (2038-10-12) gate: delivered cost under 30% above Hevea (fail at 30%+), i.e. up to USD 2.60/kg on the USD 2.00/kg benchmark; Month 84 processing cost at most USD 2.50/kg.
- **canonical_facts hevea_benchmark_and_offtake_price, alt_rubber_annual_opex, alt_rubber_operating_gap:** Offtake price = benchmark + 10% = USD 2.20/kg; opex at USD 2.50/kg gives USD 80.0M against USD 70.4M revenue (USD 9.6M/year gap).
- **Why it conflicts:** A cost that passes the FID rule and the Year 12 gate (up to 30% above Hevea) is still above the price OEMs are assumed to pay. The processing-cost KPI of USD 2.50/kg alone exceeds USD 2.20/kg, and even the Month 216 KPI (15% above Hevea = USD 2.30/kg) is above it. Passing the gates therefore does not make plants financeable.
- **Suggested resolution:** Decide which gives way: (a) tighten the cost KPI and FID rule to at or below the offtake price; (b) raise the OEM premium target above 10%; (c) accept a funded operating subsidy and size it explicitly (the USD 0.6B line covers only about USD 115M (estimate) at the base case). Do not describe the 30% gate as "commercially viable" until one is chosen.

### 4. Binding price floor has no budget line or payer (🔴 High) — needs a project decision

- **Pitch (Ethical Considerations, Stakeholder Benefits); Review 15 item 2:** Price floors "are binding (90% of Hevea)"; "Price-floor guarantees (90% of Hevea benchmark) protect against commodity-price volatility"; "legally binding price-floor commitments by Month 18 (2028-04-12)".
- **canonical_facts documented_budget_lines and smallholder_price_floor; Self-audit item 15:** Documented budget lines (USD 16.1B) contain no price-floor line; the guarantee is a "proposed threshold"; fiscal exposure is USD 50-200M/year (estimate), described as a funder withdrawal incentive.
- **Why it conflicts:** A binding guarantee of USD 50-200M/year (estimate) over roughly 17+ years has no funding source inside the USD 30B cap. It is either unfunded or competes with the USD 6.75B replant line or the contingency reserve.
- **Suggested resolution:** Describe the floor as proposed, not binding, until a payer is chosen. Options: fund from the USD 13.9B unallocated balance at the Month 6 budget baseline; fund from the industry levy; cap with a sunset (e.g. floors only Months 84-216); or make it conditional on cultivar and plant economics.

### 5. Smallholder stop trigger: threshold, date, reallocation amount and 45% vs 40% target (🔴 High)

- **canonical_facts adoption_waypoints; Pitch (Risks, Metrics):** Adoption waypoints: at least 30% enrolled at Month 84 (2033-10-12), stop trigger below 30%; at least 40% of area replanted at Month 144 (2038-10-12). Pitch repeats the Month 84 30% stop trigger.
- **Executive Summary (Purpose and Goals, Risks); premortem FM3; Review 11/12; Review 6 KPI 2:** Executive Summary: stop-trigger reallocation "if enrolment <25% by Month 54"; FM3 stop rule: below 25% at Month 54, "reduce smallholder targets by 40%" and reallocate USD 0.8-1.2B; Goal (4): "45% adoption (2.25M ha) ... by Month 144".
- **Why it conflicts:** One stop trigger appears with two thresholds (25% vs 30%) and two dates (Month 54 vs Month 84). Recomputed: a 40% cut of the USD 6.75B line is about USD 2.7B gross, which matches neither the USD 0.8-1.2B reallocation nor the USD 2-3B "orphaned" figures. The 45% planning figure is stated as a goal although the gate is 40%. Review 6 equates "1.5M+ smallholders" with 30% of 5M ha (a hectare figure), and 500 agents x 200-500 smallholders serve only 100,000-250,000 smallholders.
- **Suggested resolution:** Keep the canonical Month 84 stop trigger (below 30% enrolled). Label Month 54 below 25% explicitly as an interim tripwire that opens a review, not a second stop. State the Month 144 gate as 40% of eligible area, with 45% only as the planning case. Say whether USD 0.8-1.2B is the undisbursed, reallocatable part of a USD 2.7B cut. Use one unit (ha or farmers) throughout.

### 6. Crown-budding hedge: approval date, budget source and trigger (🟡 Medium)

- **Pitch (Technical risks); canonical_facts fallback_crown_budding:** Pitch: steering council approves pre-authorisation "by Month 9 (2027-07-12), before the Month 12 planting deadline"; funded from the USD 13.9B unallocated balance (canonical: needs a new steering-council decision).
- **Executive Summary (Risks #2); Review 4 item 3, Review 13 item 1; Self-audit items 5, 19; Review 11 item 1:** Executive Summary: "pre-commit crown-budding fast-track (USD 0.25B) as trigger-ready hedge by Month 18 (2028-04-12)"; Reviews 4/13 and Self-audit: pre-approve by Month 18 "so a Month 15 slip immediately triggers fallback"; Review 11: draw-down "within contingency reserve".
- **Why it conflicts:** Pre-commitment at Month 18 comes after the Month 12 planting deadline and after the Month 15 (2028-01-12) slip it is meant to cover. Two funding sources are given (unallocated balance vs reserve), and the hedge is described as a pre-committed budget item although it is outside the plan and needs a decision.
- **Suggested resolution:** Keep Month 9 for the steering-council pre-authorisation (before the Month 12 planting deadline). Fund it from the USD 13.9B unallocated balance, allocated at the Month 6 budget baseline. Present it as a decision to be taken, not as budgeted. Use Month 18 only as the stop rule if sites are not planted.

### 7. Year 7 yield bands and Month 48 trigger applied inconsistently (🟡 Medium)

- **canonical_facts year7_cultivar_gate_criteria, breeding_trigger_month48:** Month 84 gate: 95%+ pass, 90-95% conditional, below 90% fail. Month 48 (2030-10-12) trigger: yield penalty above 15% (yield below 85%) starts the crown-budding decision.
- **Self-audit items 2 and 4; Review 8 item 1; Review 10 item 1:** Self-audit item 2: "If breeding yield <90% of elite at Month 48, activate crown-budding fast-track or fail gate" (item 4 uses <85%). Reviews 8 and 10 propose adjusting thresholds to "85-90% conditional pass" and "yield penalties exceed 10-15%" as a gate miss.
- **Why it conflicts:** The gate pass line (90%) is applied as a Month 48 trigger, and the conditional band is shifted down to 85-90%. This changes both the gate decision and the amount of tranche released, and the Self-audit contradicts itself (90% in item 2, 85% in item 4).
- **Suggested resolution:** Use canonical values everywhere: Month 48 trigger below 85% (penalty above 15%), Month 84 fail below 90%, conditional 90-95%. Remove the 85-90% conditional idea unless the pre-registered protocol deliberately changes it before Month 12.

### 8. Alternative-rubber decision point and offtake contract timing vary (Month 48 vs 60) (🟡 Medium)

- **canonical_facts portfolio_decision_month60, oem_offtake_structure; premortem FM2:** No wave 1 commitment before the Month 60 (2031-10-12) portfolio decision; purchase-option contracts Months 48-60 (2030-10-12 to 2031-10-12); FM2: "At the Month 60 decision".
- **Self-audit item 2; Review 2 item 2; Review 9 item 2; Review 10 item 3:** Self-audit: feedstock above USD 1.20/kg at Month 48 means "reallocate wave 1 capex"; Review 2: if missed by Month 48, "immediately approve processing-innovation budget or re-scope"; Reviews 9/10: 8 of 10 binding contracts "by Month 48" (Self-audit: Month 60).
- **Why it conflicts:** The same failure test leads to a decision at Month 48 in some places and at Month 60 in others. The binding-contract deadline is the start of the canonical window in one document and the end of it in another, which changes when plants can be financed ahead of the Month 72 FID.
- **Suggested resolution:** Measure at Month 36 and 48, decide at Month 60. Treat Month 48 as a review and warning point, with the contract window Months 48-60 closing at Month 60.

### 9. Alternative-rubber volume, timing and market share (🟡 Medium)

- **canonical_facts alt_rubber_volume_and_land; Pitch (0.2%):** 16,000 t/year by Month 120 (2036-10-12); 32,000 t/year by Month 192 (2042-10-12); about 0.2% of the roughly 14 Mt/year market; 20-30% offtake share not adopted.
- **Pitch (Long-term Vision); Review 13 item 3; Self-audit item 12:** Pitch: tire makers "source 10-20% non-Hevea rubber from alternatives"; Review 13: "by Month 144 ... alternative supply fails to reach 32,000 t/year target"; Self-audit item 12 example: "reduce ... Hevea from 90% to 80% by Month 216".
- **Why it conflicts:** A 10-20% share (or a 10-point drop in Hevea concentration) is about 50-100 times the 0.2% the pitch itself states. 32,000 t/year is not due at Month 144, because wave 2 starts only after that gate.
- **Suggested resolution:** Use 0.2% and the canonical volumes. State 16,000 t/year (wave 1) as the Month 120-144 expectation, and 32,000 t/year as the Month 192 target. Delete the 10-20% and 90%-to-80% examples.

### 10. Levy-erosion and premium-sensitivity figures do not recompute (🟡 Medium)

- **Review 5 item 3; Review 14 item 3:** Review 5: levy down 20-30% gives USD 105-118M/year and "a USD 1.5-2.0B 25-year shortfall" against USD 3.7B. Review 14: premium falls from 10% to 5%, "revenue drops to USD 52.8M", gap USD 27.2M/year (USD 327M cumulative).
- **canonical_facts industry_levy_rate_and_yield, alt_rubber_annual_revenue, alt_rubber_operating_gap; Review 8 item 3; Review 10 item 3:** Recomputed: 20-30% of USD 147M/year x 25 years is about USD 0.7-1.1B (less if erosion starts in Years 5-10). 10 to 8 makers (20%) is about USD 29M/year, not USD 50-75M, and Review 8 gives USD 0.75-1.5B for the same drop that Review 10 puts at USD 1.5-2.0B. At a 5% premium (USD 2.10/kg x 32,000 t) revenue is USD 67.2M and the gap USD 12.8M/year, about USD 150M cumulative on the base-case scaling (estimate).
- **Why it conflicts:** The shortfall totals and the downside revenue are not reproducible from the canonical levy and revenue figures, and the same scenario carries different totals in different reviews. USD 52.8M corresponds to 24,000 t at USD 2.20/kg, not to a 5% premium. A premium change also does not alter a levy computed on rubber purchases.
- **Suggested resolution:** Replace with recomputed values: levy shortfall about USD 0.7-1.1B (estimate) for a 20-30% fall; gap of about USD 12.8M/year at a 5% premium. Keep the levy-participation and premium-tolerance risks separate. Re-test the adequacy of the USD 0.6B line on the corrected gap.

### 11. MoUs said to precede an IPPC draft that is circulated before them (🟡 Medium)

- **Review 13 item 2; assumptions (Risk 1):** Review 13: "Protocol Adoption MoU Signing (Month 6) Must Precede IPPC Draft Submission (Months 3-4)" and use "MoU evidence in IPPC draft circulation"; Risk 1: bind producers in MoUs "before drafting the IPPC standard".
- **canonical_facts protocol_milestones; Project Plan (Compliance Actions):** Draft protocol for IPPC working-group comment at Months 3-4 (2027-01-12 to 2027-02-12); producer MoUs by Month 6 (2027-04-12).
- **Why it conflicts:** Month 6 comes after Months 3-4, so a dependency is scheduled before its prerequisite and the claimed use of MoU evidence in the circulation cannot occur.
- **Suggested resolution:** Keep the canonical dates. State that Months 3-4 is a working draft for comment, supported by MoU pre-negotiations started at Month 1, and that signed MoUs (Month 6) precede the formal adoption text. If MoU-first is the intent, the MoU deadline must move to Month 3, which is a schedule decision.

### 12. Phase and calendar labels misstated (pitch dates, 120 days, Phase 2-5 labels) (⚪ Low)

- **canonical_facts program_duration_and_start, phase_structure, alt_rubber_pilots:** Canonical: Month 300 = 2051-10-12; Phase 1 (Months 0-36) is containment with no scale-up; breeding trials Month 12, pilots Month 24; Month 12 funding agreements and Month 6 MoUs.
- **Pitch (Program structure, Long-term Vision, Call to Action); Executive Summary (Key Deliverables):** Pitch: "Phase 2-5 (Months 36-300, 2029-10-12 to 2035-10-12)", "By Month 300 (2035-10-12)", "Within 120 days" commitments due by Month 6 and Month 12. Executive Summary lists Month 12/24/36 deliverables under "Phase 2-5 (Months 36-300)".
- **Why it conflicts:** 2035-10-12 is Month 108, not Month 300. 120 days is about Month 4, shorter than the Month 6 and Month 12 deadlines listed under it. Items dated Months 12-36 sit under a label that starts at Month 36.
- **Suggested resolution:** Correct the end date to Month 300 (2051-10-12). Replace "Within 120 days" with the listed month deadlines. Relabel Month 12-36 trials, pilots and finance pilots as non-scale-up preparatory work inside Phase 1.

## Summary

The plan is largely consistent on gate months, tranche arithmetic (USD 22.0B + 3.5B = USD 25.5B, plus USD 4.5B = USD 30B) and plant unit economics, and most earlier arithmetic errors were repaired. The remaining serious problems are definitional or unfunded rather than numeric: what \"binding\" means at the Month 36 gate, who finances plants and the price floor, and a Year 12 cost gate that lets costs exceed the assumed offtake price. The pitch still states open decisions as facts, and the Self-audit and reviews still carry shifted triggers and dates (stop trigger, crown-budding, Month 48 vs 60). Minor unresolved items not listed: extension-retention and bridging-default thresholds differ across documents (40%/50%/60%+/70%+; 15% vs 20%), and ABS-slip impacts range from USD 1.5B to USD 6.75B.