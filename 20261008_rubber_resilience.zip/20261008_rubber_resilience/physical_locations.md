This plan implies one or more physical locations.

## Requirements for physical locations

- Brazilian Amazon access for Hevea germplasm collection under ABS/Nagoya-compliant agreements
- Established rubber research institutions, laboratories, greenhouses and multi-site field-trial capacity
- Guayule sites in arid or semi-arid zones with suitable climate, marginal land and limited water demand
- Russian dandelion sites in temperate climates with existing agricultural infrastructure and logistics
- Colocated rubber processing plants near feedstock, with access to ports, highways and OEM tire makers
- Proximity to major smallholder rubber regions (Southeast Asia, West Africa, Brazil) for nurseries and extension
- Quarantine-capable facilities and inspection capacity at nurseries, borders and ports
- Institutional anchor near IPPC and regional plant protection organization bodies for protocol adoption
- Stable governance, land tenure clarity and political support for 25-year commitments

## Location 1
Brazil

Amazon basin (Acre, Amazonas, Mato Grosso, Para) with breeding hubs in Sao Paulo state

Wild Hevea collection sites in the Amazon; breeding and trial stations at research institutes in Sao Paulo state (e.g., Campinas area) and Manaus

**Rationale**: The plan requires Brazil-led, ABS-compliant bio-prospecting and genomic breeding. The Amazon holds the centre of Hevea diversity and the original resistance sources. Existing agricultural research institutions provide laboratory and field-trial capacity.

## Location 2
USA and Mexico (arid Southwest and northern Mexico)

Arizona, New Mexico and Texas; Coahuila and Chihuahua

Arid-zone farmland in central/southern Arizona and Chihuahuan Desert margins with colocated guayule processing plant sites

**Rationale**: Guayule is native to this region and is already trialled commercially there. Suitable climate, existing growers, tire-industry presence and precedent for processing make it a fit for commercial-scale guayule with colocated processing and OEM offtake.

## Location 3
Europe and temperate Eurasia

Germany, Netherlands, Belgium and Kazakhstan

Temperate farmland near tire-industry clusters in Lower Saxony/Germany and Benelux, with a Kazakh feedstock origin region (Tau-saghyz/Russian dandelion homeland)

**Rationale**: Russian dandelion suits temperate climates. European sites sit near major tire makers and OEM buyers and have existing research on dandelion rubber, supporting colocated processing, offtake and cost/quality KPI testing.

## Location 4
Southeast Asia (Thailand, Indonesia, Malaysia, Vietnam)

Southern Thailand, Sumatra and Peninsular Malaysia rubber belts

Smallholder rubber districts with national rubber research institutes, for clean-plant nurseries, extension, replanting and quarantine/inspection hubs

**Rationale**: These regions produce most of the world's natural rubber and are still free of SALB. Containment protocol enforcement, clean-plant networks and smallholder replant finance matter most here, and trial of resistant clones must occur in the major producing areas.

## Location 5
Italy (Rome) and international

Rome, home of the IPPC Secretariat (FAO)

FAO headquarters, Viale delle Terme di Caracalla, Rome

**Rationale**: The protocol is to be embedded in the IPPC framework and harmonized with regional standards. Programme governance, protocol drafting and gate-audit coordination benefit from proximity to the IPPC Secretariat.

## Location Summary
The programme is global and multi-site, with locations implied by its components: Brazil's Amazon and research hubs for ABS-compliant breeding; arid North American sites for guayule; temperate European/Eurasian sites for Russian dandelion; Southeast Asian rubber belts for containment, nurseries and smallholder adoption; and Rome for IPPC-linked protocol governance.