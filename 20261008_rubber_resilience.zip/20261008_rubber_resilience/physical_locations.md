This plan implies one or more physical locations.

## Requirements for physical locations

- South American rubber-growing regions, particularly Brazil, as center for bio-prospecting and wild Hevea germplasm collection under Nagoya Protocol compliance
- SALB-endemic field trial sites in Latin America with real pathogen pressure for resistance screening
- SALB-free rubber-producing regions in Asia and Africa for containment protocol enforcement, surveillance infrastructure, and clean-zone field trials
- Tropical and arid zones suitable for Guayule cultivation and processing
- Temperate climate zones suitable for Russian dandelion cultivation and processing
- Existing regional plant protection organization hubs and quarantine facilities in major producing countries
- Laboratory and genomics facilities for pathogen sequencing, resistance screening, and genetic analysis
- Tissue-culture and somatic-embryogenesis propagation centers for disease-free planting material multiplication
- Rubber nurseries and budwood gardens distributed across producer regions for clean-plant networks
- Processing and extraction facilities colocated with alternative rubber production sites
- OEM testing and qualification facilities for tire-grade rubber validation
- Smallholder farming communities in rubber-growing regions for adoption, surveillance participation, and replanting
- Multilateral secretariat headquarters with office presence in major producing regions
- Training and capacity-building centers for inspector certification and agricultural extension

## Location 1
Brazil and Amazon Basin (South America)

Hevea-growing states: Amazonas, Rondônia, Acre, and Mato Grosso do Sul

Wild Hevea germplasm collection sites, endemic SALB field trial plots, and Brazil-led breeding research institutes

**Rationale**: Brazil is the center for bio-prospecting under Nagoya Protocol compliance, access-and-benefit-sharing agreements with indigenous communities, and collection of wild Hevea resistance sources. Endemic SALB pressure provides real disease-screening conditions for candidate cultivar testing. Brazil's leadership role in the program and existing rubber research infrastructure make it the geographic anchor.

## Location 2
Southeast Asia and South Asia (Asia)

Indonesia (Sumatra, Kalimantan), Malaysia, Thailand, India, and Vietnam

Existing SALB-free plantation zones, regional plant protection organization headquarters, distributed clean-plant nurseries, surveillance and inspection networks, and tissue-culture propagation hubs

**Rationale**: Asia is the world's largest natural rubber producer (est. 70% of global supply) and is currently free of SALB. Enforcement of the Containment Protocol in these regions is critical to prevent pathogen incursion. Distributed nurseries and propagation centers are needed for rapid multiplication and adoption of resistant cultivars and alternative rubbers. Regional plant protection organization capacity building and surveillance infrastructure must be established in situ.

## Location 3
West and Central Africa

Côte d'Ivoire, Cameroon, Ghana, and Nigeria

Emerging rubber-producing zones, plant health inspection checkpoints, clean-plant distribution networks, and capacity-building training centers

**Rationale**: Africa is an expanding rubber-producing region and is currently SALB-free. Building containment capacity and clean-plant networks here before SALB arrives is more cost-effective than managing an outbreak. Regional inspector training and plant health capacity is needed early to establish durable surveillance. Africa's agricultural labor availability and land suitability also support alternative-rubber pilot sites (Guayule, Russian dandelion testing).

## Location 4
Semi-arid regions (global)

Mexico (Sonora, Coahuila), southwestern United States (Arizona, California), and parts of Argentina

Guayule breeding and cultivation sites with colocated extraction and processing facilities

**Rationale**: Guayule is adapted to arid and semi-arid climates with low rainfall and high temperature variation. These regions have existing agronomic and processing knowledge from historical guayule programs. Colocated processing reduces transport losses and improves economics. OEM proximity in North America and existing industrial infrastructure support pilot commercialization and tire-grade qualification.

## Location 5
Temperate regions (global)

Northern Europe (Russia, Belarus, Baltic states), temperate North America (Canada, northern United States), and temperate South America (southern Brazil, Argentina)

Russian dandelion breeding, cultivation, and colocated extraction/processing pilot sites

**Rationale**: Russian dandelion grows in temperate climates with moderate rainfall and shorter growing seasons. It offers geographic diversification of rubber supply away from tropical zones vulnerable to other diseases and climate shocks. Northern European and Eurasian siting supports testing in cool-season conditions and aligns with existing agricultural research infrastructure. Processing hubs in these regions reduce logistics costs for northern-hemisphere OEMs.

## Location 6
Global (major rubber-consuming regions)

North America (USA, Mexico), Europe, and East Asia (China, Japan, South Korea)

OEM tire-testing and rubber-qualification facilities, and demand commitment negotiation centers

**Rationale**: OEMs and tire manufacturers in consuming regions must validate that alternative rubber and resistant-Hevea output meet tire-grade specifications. Direct access to OEM testing facilities and procurement teams is essential for building take-or-pay offtake agreements and qualifying new rubber sources. Co-location enables rapid feedback on quality issues and supports demand commitments needed to justify processing capex.

## Location 7
International governance hubs (multi-regional)

Rome (IPPC Secretariat, FAO), Geneva (International Convention centers), and regional capital cities (e.g., Bangkok for ASEAN, Nairobi for East Africa)

Multilateral secretariat offices, IPPC standard-setting bodies, regional plant protection organization headquarters, and development finance institution regional desks

**Rationale**: Harmonization of the containment protocol with existing IPPC frameworks and regional phytosanitary standards requires offices in or near IPPC and FAO hubs. Regional secretariat presence in Asia, Africa, and Latin America is needed for governance, gate decisions, protocol enforcement coordination, and producer-government seat representation. Development finance institution alignment on funding gates requires presence near major lenders' regional offices.

## Location Summary
This 25-year, $30 billion program is inherently global and place-dependent. Physical locations span: (1) Brazil's Amazon region for wild Hevea bio-prospecting and endemic SALB field trials; (2) SALB-free Asia (Indonesia, Malaysia, Thailand, India) for containment enforcement, surveillance networks, and clean-plant propagation hubs—critical as the world's largest rubber producer; (3) West/Central Africa for early capacity building and alternative-rubber siting before SALB arrival; (4) arid zones (Mexico, southwestern USA, Argentina) for Guayule cultivation and processing; (5) temperate zones (Russia, northern Europe, temperate Americas) for Russian dandelion pilot scale-up; (6) major consuming regions (North America, Europe, East Asia) for OEM offtake qualification and demand commitments; and (7) international governance hubs (Rome, Geneva, regional capitals) for IPPC harmonization, secretariat operations, and multilateral coordination. No pillar (containment protocol, resistant-Hevea breeding, alternative rubbers, smallholder adoption) can succeed without distributed, place-specific investment in field trials, laboratory infrastructure, nursery networks, surveillance systems, processing plants, and institutional capacity. The plan's design principle of smallholder adoption also requires in-situ presence in rubber-growing communities across multiple continents.