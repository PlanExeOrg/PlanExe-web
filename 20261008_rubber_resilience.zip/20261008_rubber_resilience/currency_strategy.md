This plan involves money.

## Currencies

- **USD:** User-specified budget ($30 billion), primary currency for global capital disbursements, international OEM offtake contracts with tire makers, and multilateral development-bank tranches over 25 years.
- **EUR:** European sovereign and development-bank funding, German and Benelux tire makers, and research institutions in Germany, Netherlands and Belgium for dandelion breeding and processing cost/quality verification.
- **BRL:** Brazil-led ABS-compliant breeding, local research-institute contracts, smallholder replanting finance, extension services and nursery operations in the Amazon and São Paulo state.
- **THB:** Southern Thailand rubber belt: smallholder replanting finance, clean-plant nurseries, extension corps salaries, and containment surveillance in one of the world's largest natural-rubber smallholder regions.
- **IDR:** Sumatra and Indonesia rubber districts: smallholder transition finance, extension services, quarantine and inspection hubs, and trial planting of resistant cultivars in a major SALB-free producing region.
- **MYR:** Peninsular Malaysia rubber belt: smallholder adoption support, nursery operations, clean-plant networks and resistant-cultivar trials in an established rubber-producing region free of SALB.
- **VND:** Vietnam rubber smallholders: replanting finance, extension support, nursery establishment and containment surveillance in a growing natural-rubber producing region with high smallholder density.

**Primary currency:** USD

**Currency strategy:** Budget the $30 billion in USD with gate-contingent tranches at Years 3/7/12/18. Use USD for all international capital disbursements, OEM offtake contracts and multilateral development-bank funding. Conduct smallholder finance, extension and national research contracts in local currencies (BRL, THB, IDR, MYR, VND). Establish EUR-denominated contracts for European research and processing, with development banks providing natural hedges. At each funding gate, rebase cost and quality KPIs to USD to account for exchange-rate drift over the prior period. For long-horizon OEM offtake agreements, specify base prices in USD with currency-adjustment clauses tied to published indices.