**Primary domain:** Plant Pathology

**Secondary domains:** Plant Breeding, Supply Chain Resilience, Phytosanitary Regulation

**Rationale:** Plant Pathology is the top outcome candidate (importance 5 × specificity 5) and owns the SALB containment deliverable, which is the program's non-negotiable gate. Supply Chain Resilience scores lower; Plant Breeding, Phytosanitary Regulation and the others are methods or constraints.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Plant Pathology | 5 | 5 | outcome | SALB containment, surveillance and quarantine protocols are the Phase 1 non-negotiable deliverable. |
| Plant Breeding | 5 | 5 | method | Genomic breeding must deliver SALB-resistant, yield-parity Hevea cultivars. |
| Phytosanitary Regulation | 5 | 5 | constraint | The containment protocol must harmonize with regional plant quarantine standards for nursery stock, materials and equipment. |
| Plant Genomics | 4 | 5 | method | Genomic breeding and bio-prospecting underpin SALB-resistant, yield-parity Hevea cultivar development. |
| Genetic Resources Law | 4 | 5 | constraint | Access-and-benefit-sharing compliance governs Brazil-led bio-prospecting and germplasm use across jurisdictions. |
| Supply Chain Resilience | 4 | 4 | outcome | Success requires diversified parallel rubber supply chains and resilient OEM procurement. |
| Agricultural Finance | 4 | 4 | method | Smallholder replant finance and price-stability tools determine adoption of resistant cultivars and alternatives. |
| Rubber Processing | 4 | 4 | method | Guayule and dandelion rubber need colocated processing meeting OEM cost and quality specifications. |
| Smallholder Agronomy | 4 | 4 | stakeholder | Program adoption depends on smallholder replanting, clean-plant networks, and extension for Hevea, Guayule, and dandelion. |