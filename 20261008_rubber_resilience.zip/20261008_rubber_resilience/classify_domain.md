**Primary domain:** Plant Pathology

**Secondary domains:** Plant Quarantine, Plant Breeding, Supply Chain Resilience

**Rationale:** Plant Pathology and Plant Breeding tie as outcome candidates, so the tiebreak is what the program is about: managing SALB. Plant Pathology covers containment, epidemiology and resistance screening. Plant Breeding covers only the cultivar strand, and the other candidates are constraints, methods or market roles.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Plant Quarantine | 5 | 5 | constraint | Global SALB Containment Protocol harmonized with phytosanitary standards is the non-negotiable Phase 1 deliverable. |
| Plant Breeding | 5 | 5 | outcome | Genomic breeding of SALB-resistant, yield-parity Hevea cultivars is a core success criterion. |
| Plant Pathology | 5 | 5 | outcome | SALB epidemiology, resistance screening, and containment underpin the program's core success criterion. |
| Access Benefit Sharing | 4 | 5 | constraint | Brazil-led bio-prospecting must comply with Nagoya Protocol and national genetic-resource access rules. |
| Supply Chain Resilience | 4 | 4 | method | Diversified parallel rubber supply chains with OEM offtake and resilient procurement define program success. |
| Agricultural Economics | 4 | 4 | market | Smallholder replant finance, price-stability tools, and alternative-rubber cost competitiveness drive adoption. |
| Industrial Biotechnology | 4 | 4 | method | Guayule and Russian dandelion require colocated rubber extraction, processing, and OEM quality qualification. |
| Development Finance | 4 | 4 | method | Smallholder replant finance, price-stability tools, and stage-gated funding require blended-finance design. |
| Genomics | 4 | 4 | method | Genomic selection and bio-prospecting drive SALB-resistant, yield-parity Hevea cultivar development. |