
## Question 1 - How is the $30 billion (user constraint) split across the Year 3/7/12/18 tranches, and what share comes from sovereign, multilateral, and industry levy sources?

**Assumptions:** Assumption: Funding follows the Pragmatic Foundation path: a ring-fenced industry levy plus sovereign and development-bank commitments. Tranches are gate-conditional, with a 15-20% contingency reserve (estimate), consistent with large multilateral programme practice.

**Assessments:** Title: Financial Feasibility Assessment
Description: Durability and gate-conditionality of the capital stack.
Details: Missing the Year 7 gate could withhold roughly $5-8 billion (estimate). Mitigate with binding 25-year framework agreements by Month 12 (2027-10-12), minimum-funding floors (e.g., 80% of a tranche on partial gate success, proposed), and 5+ funding sources. A levy of 25% shortfall equals about $150-250 million per year (estimate). Opportunity: ring-fencing shields the programme from budget cycles.

## Question 2 - What are the critical-path milestones and the target dates for the Phase 1 SALB Containment Protocol before any scale-up?

**Assumptions:** Assumption: Protocol drafting starts at Month 0 (2026-10-12), producer-nation MoUs are signed by Month 6 (2027-04-12), and IPPC adoption is complete by Months 36-48 (2029-10-12 to 2030-10-12). Standard-setting at IPPC typically takes 2-4 years, so this is realistic. Scale-up is held until the Month 36 (2029-10-12) gate.

**Assessments:** Title: Schedule Feasibility Assessment
Description: Sequencing of Phase 1 and the four gates.
Details: Gates fall at Months 36, 84, 144, and 216 (2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12). Protocol adoption delays of 6-18 months (estimate) would hit the Month 36 (2029-10-12) gate. Perennial breeding cycles of 6-10 years cannot be compressed, so the Month 84 (2033-10-12) cultivar KPI is the tightest. Mitigate with early MoUs, Month 12-18 (2027-10-12 to 2028-04-12) drills, and parallel trial launches by Month 12 (2027-10-12).

## Question 3 - What core teams and expertise are needed across breeding, inspection, extension, and processing, and who will staff them?

**Assumptions:** Assumption: Delivery is decentralised, using national rubber research institutes, cooperatives, and certified micro-nurseries. Initial hires include about 100 compliance inspectors and 500 lead extension agents across the top five producers (proposed figures), as scarce skills are met by existing institutions.

**Assessments:** Title: Resource Capacity Assessment
Description: Availability and retention of skilled personnel.
Details: Scarce skills include molecular diagnostics, perennial-crop breeders, and extraction engineers. Turnover of 30-50% a year in extension (estimate risk) would erode quality. Mitigate with local ownership, succession plans by Month 24 (2028-10-12), and a protected extension funding stream. Opportunity: building regional lab capacity of about 10 hubs by Month 24 (2028-10-12) (proposed).

## Question 4 - Which bodies hold legal authority to adopt, certify, and enforce the protocol, and how are ABS/Nagoya and national regulations handled?

**Assumptions:** Assumption: The protocol is embedded in the IPPC framework and adopted through national plant protection organisations. Brazil's CGen-led ABS agreements, with community consent, are completed by about Month 6-18 (2027-04-12 to 2028-04-12). Producer countries retain sovereignty over enforcement.

**Assessments:** Title: Governance and Compliance Assessment
Description: Legitimacy, adoption and ABS compliance.
Details: Consensus standard-setting gives legitimacy but weak enforcement; producers hold effective vetoes. ABS agreements can take 12-36 months (not verified), threatening breeding starts. Mitigate with a FAO adoption secretariat by Month 3, early ABS counsel, published agreements, and a binding penalty schedule. Legal exposure from consent failures: $100-500 million (estimate).

## Question 5 - What are the main biosecurity, safety, and programme risks, and what thresholds trigger a response or reallocation?

**Assumptions:** Assumption: Tiered surveillance targets detection within 3 months in primary producers (proposed threshold), an eradication-first response with prefunded compensation, and quarterly risk reviews. Triggers include yield penalty over 15% by Month 48 (2030-10-12) and cost targets missed by Month 60 (2031-10-12) (proposed).

**Assessments:** Title: Risk Management Assessment
Description: Containment, breeding, and cost-failure risks.
Details: Detection beyond 6 months could expand eradication from under 5 ha to 500+ ha (estimate). Nursery contamination is the key pathway, so inspection capacity must scale with nursery count. Mitigate with red-team drills, concealment-reducing rewards, and decision triggers. Opportunity: early failure signals redirect capital before gate losses.

## Question 6 - What environmental and land-use constraints (water, land displacement, climate shifts, spread of SALB suitability) apply to the crop and trial sites?

**Assumptions:** Assumption: Guayule and dandelion are sited on degraded or marginal land after suitability screening, with water-stress modelling at 1.5, 2, and 3 degrees C scenarios (proposed). Footprint is geographically diversified to avoid single climate shocks.

**Assessments:** Title: Environmental Impact Assessment
Description: Water, land, and climate exposure.
Details: Arid-zone aquifer depletion could cut Guayule yields 20-30% (estimate risk). Marginal siting avoids food competition but raises cost per tonne. Mitigate with climate-informed siting by Month 6 (2027-04-12), alternative sites, and SALB habitat monitoring from Month 12 (2027-10-12). Benefit: reduced deforestation pressure and diversified, climate-resilient supply.

## Question 7 - Which stakeholders (producer governments, OEMs, smallholders, indigenous communities, IPPC) must commit, and how are they engaged?

**Assumptions:** Assumption: A Steering Council with sovereign, OEM, research, and farmer seats meets quarterly from Month 1 (2026-11-12). The top 10 tire makers are engaged by Month 3 (2027-01-12) with letters of intent by Month 12 (2027-10-12) (proposed). Community-governed data trust seats are offered to indigenous groups.

**Assessments:** Title: Stakeholder Alignment Assessment
Description: Commitment and trust across diverse parties.
Details: OEMs resist paying premiums for unproven supply; purchase-option contracts with small reservation fees (estimate 1-2%) lower this barrier. Smallholder uptake historically 20-40% (estimate), so plan for 40-50%. Mitigate with income-bridging finance, mobile extension, and transparent benefit-sharing disclosure. Opportunity: farmer co-ownership in processing.

## Question 8 - What operational systems are needed for clean-plant tracking, surveillance data, gate evidence, processing plants, and offtake logistics?

**Assumptions:** Assumption: A digital lot-tracking and data repository with 50-year preservation, independent audit access, and pilot processing plants (500-5,000 t/year, estimate) precede commercial plants. Mobile attestation serves remote farmers.

**Assessments:** Title: Operational Systems Assessment
Description: Tracking, data, and processing infrastructure.
Details: Lot inspections may need 100,000+ per year versus under 30,000 if under-resourced (estimate). Data loss or withheld trial data could delay gates 6-12 months. Mitigate with a data steward by Month 1 (2026-11-12), tiered data rules, and KPI waypoints at Months 36 and 60 (2029-10-12, 2031-10-12). Plants cost $100-300 million each (estimate), so stage capital after pilots.