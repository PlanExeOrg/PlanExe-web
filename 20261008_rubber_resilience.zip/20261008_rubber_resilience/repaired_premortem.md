A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Producer governments will convert the Containment Protocol into enforceable national import rules, with funded inspectors, in at least 15 countries by Month 36 (2029-10-08) despite no supranational enforcement. | By Month 3 (2027-01-08), obtain written positions from 3 weak-capacity plant protection organizations (Côte d'Ivoire, Indonesia, Nigeria) on legal route, inspector budgets and timeline. | Fewer than 2 of 3 organizations confirm a legal route to enforceable rules within 12 months of IPPC approval, or inspector budgets are unfunded. |
| A2 | Funders and the industry levy will deliver binding, ring-fenced money across 25 years, and funders will accept gate outcomes without withdrawing after a partial or contested gate. | By Month 3 (2027-01-08), circulate a draft Technical Gate Charter and levy term sheet to 8 prospective sovereign and bank funders; ask for signed binding-commitment language and a mock partial-gate decision. | Fewer than 5 sovereigns and 2 banks sign binding terms, any funder insists on discretionary override, or tested levy compliance in the mock pilot is below 60%. |
| A3 | Tire makers will sign priced take-or-pay offtake for alternative rubber, and pilot cost and quality will reach the Month 84 (2033-10-08) gate (at most USD 1.62/kg, 95% of Hevea specs) before hub capital is committed. | By Month 6 (2027-04-08), run structured offtake talks with 5 OEMs and obtain pilot cost and tire-grade data from Bridgestone and Continental programs. | Fewer than 2 OEMs will issue letters of intent at 500 t/yr or more, or credible pilot data show cost above USD 1.80/kg or quality below 90% of Hevea specs. |
| A4 | Brazilian authorities and indigenous communities will complete Nagoya/ABS agreements by Month 6 (2027-04-08) on terms that let collection start at Month 8 (2027-06-08) and stay uncontested after cultivar release. | By Month 3 (2027-01-08), hold structured consultations with 2 Brazilian state authorities and 5 indigenous organizations; obtain written positions on royalty share, governance seats and consent timelines. | Fewer than 3 of 5 organizations accept a framework agreement in principle, or any demands terms that would reopen after cultivar release. |
| A5 | Smallholders will conceal fewer infections and participate in surveillance at 60% or more (proposed threshold) when paid premiums within 30 days, even though reporting may trigger quarantine or tree removal. | By Month 3 (2027-01-08), run baseline surveys and vignette experiments with 50-100 farmers in each of 3 pilot zones (Sumatra, Côte d'Ivoire, northeast India), testing willingness to report under quarantine risk. | Stated willingness to report is below 45% in 2 or more zones, or mobile payment trials exceed 45 days or fail more than 10% of the time. |
| A6 | Pyramided Hevea candidates with at least 3 independent resistance genes can pass Virulence Gates and reach 85% of elite-clone yield by Month 84 (2033-10-08), without pathogen evolution or trial delays pushing candidates past the gate. | By Month 6 (2027-04-08), ask Embrapa and CIRAD breeders for historical cycle times and yield penalties of multi-gene SALB-resistant crosses; run a Monte Carlo timeline with 100 iterations. | Model shows under 50% probability of 2 qualifying candidates by Month 84 (2033-10-08), or historical pyramids show yield below 80% of elite clones. |
| A7 | The USD 7.0B concessional bank lending can be disbursed on schedule and serviced (about USD 449M/yr from about Month 60 = 2031-10-08, estimate) from a named, reliable payer, without diverting money from the pillars. | By Month 3 (2027-01-08), ask 3 development banks and 5 sovereign finance ministries for written positions on lender roles, repayment source and escrow terms. | Fewer than 2 banks commit in writing, or no payer covers at least 80% (proposed threshold) of the debt service by Month 12 (2027-10-08). |
| A8 | The multilateral secretariat will be accepted by sovereign producers and hold binding authority over gate decisions and protocol compliance, without any faction rejecting or capturing it. | By Month 3 (2027-01-08), circulate the draft charter and board composition to 8 producer governments, 3 OEMs and 3 banks, and request signed support for binding gate authority and the appeal route. | Fewer than 6 producer governments sign, or any major producer (Indonesia, Brazil, Thailand) rejects binding gate authority or demands a veto. |
| A9 | SALB will stay out of Asia and Africa, and the climate there will not turn favorable to it, until at least Month 84 (2033-10-08), leaving time for cultivars and alternative rubber to mature. | By Month 6 (2027-04-08), commission climate-suitability and spore-pathway modelling for Southeast Asia and West Africa under +1.5-2 degC warming, and review with 3 plant pathologists. | Models give 30% or more (proposed threshold) probability of climatic suitability or an incursion pathway in a free region before Month 84 (2033-10-08). |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Gate Dispute Spiral | Process/Financial | A2 | Capital Stack and Funding Mechanisms Designer | CRITICAL (20/25) |
| FM2 | The Paper Fence | Technical/Logistical | A1 | Phytosanitary Standards and Protocol Lead | CRITICAL (20/25) |
| FM3 | The Orphaned Rubber Hubs | Market/Human | A3 | Alternative Rubber (Guayule and Russian Dandelion) Commercial Lead | CRITICAL (16/25) |
| FM4 | The Premium Payment Pipeline Jam | Process/Financial | A5 | Smallholder Adoption and Surveillance Incentives Manager | CRITICAL (16/25) |
| FM5 | The Pyramid That Leaned | Technical/Logistical | A6 | Hevea Resistance Breeding Program Director | CRITICAL (20/25) |
| FM6 | The Broken Trust at the Source | Market/Human | A4 | Hevea Resistance Breeding Program Director | HIGH (12/25) |
| FM7 | The Debt Nobody Owned | Process/Financial | A7 | Capital Stack and Funding Mechanisms Designer | CRITICAL (15/25) |
| FM8 | The Spores Beat the Clock | Technical/Logistical | A9 | Phytosanitary Standards and Protocol Lead | HIGH (10/25) |
| FM9 | The Secretariat Nobody Trusted | Market/Human | A8 | Multilateral Secretariat Executive Director and Governance Lead | HIGH (12/25) |


### Failure Modes

#### FM1 - The Gate Dispute Spiral

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: Capital Stack and Funding Mechanisms Designer
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- The Month 36 (2029-10-08) gate scores about 72% attainment; the board and Technical Panel disagree on tranche release.
- Funders read the partial release as moved goalposts.
- Levy compliance runs below 60%; sovereigns trim pledges.
- Bank debt service (about USD 449M/yr, estimate) has no named payer.
- Tranches slip 6-18 months while breeding and trials idle.
- Funder withdrawal of USD 3-8B (estimate).

##### Early Warning Signs
- Fewer than 5 sovereigns have signed binding commitments at Month 3 (2027-01-08)
- ASEAN levy pilot compliance is under 70% at Month 21 (2028-07-08)
- Technical Panel and board scores differ by more than 10 points in a mock gate
- MDB debt-service payer is still undecided at Month 12 (2027-10-08)

##### Tripwires
- Binding sovereign commitments <5 or bank commitments <2 at Month 3 (2027-01-08)
- ASEAN levy compliance <60% at Month 24 (2028-10-08)
- Any single funder >25% of capital (USD 7.5B)
- Tranche release delayed >90 days after a gate

##### Response Playbook
- Contain: Freeze discretionary reallocations, release undisputed gate portions within 30 days, and invoke the charter appeal window.
- Assess: Commission an independent audit of gate scoring, funder positions and levy receipts within 45 days, and size the shortfall against the USD 4.5B contingency pool.
- Respond: Activate the levy fallback cascade (higher bank loan share, outcome-linked bonds, climate-finance blend) and renegotiate binding terms with named debt-service payers.


**STOP RULE:** If committed binding capital is below USD 15B (proposed threshold) by Month 12 (2027-10-08) and the levy fallback is not operating by Month 48 (2030-10-08), cancel scale-up and pivot to a containment-only program.

---

#### FM2 - The Paper Fence

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A1
- **Owner**: Phytosanitary Standards and Protocol Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- Countries adopt rules on paper but weak-link inspectorates have under 50 inspectors each.
- Staff turnover of 30-40% a year (estimate) erodes training.
- Digital reporting platform and checkpoint equipment arrive late.
- Contaminated nursery stock or equipment moves unchecked.
- SALB establishes in a free region before detection capacity exists.
- Outbreak cost USD 2-5B (estimate) against a USD 0.5B reserve.

##### Early Warning Signs
- Inspectors trained lag the plan by more than 30%
- Checkpoint equipment deliveries slip past Month 20 (2028-06-08)
- Zero lab-cleared suspect detections by Month 30 (2029-04-08)
- Regional compacts unsigned at Month 24 (2028-10-08)

##### Tripwires
- Fewer than 100 inspectors trained at Month 24 (2028-10-08)
- Fewer than 12 country commitment letters at Month 24 (2028-10-08)
- Fewer than 50 checkpoints equipped at Month 20 (2028-06-08)
- Inspector annual attrition >=30%

##### Response Playbook
- Contain: Deploy rapid-response teams and temporary international inspectors to the highest-risk ports and nurseries within 30 days.
- Assess: Audit every adopting country for legal force, inspector count and equipment within 60 days, and rank the weak links.
- Respond: Shift funds to salary and career-path support for weak-link inspectorates, tie tranches per country to audited coverage, and fast-track regional compacts.


**STOP RULE:** If fewer than 10 countries have enforceable import rules at Month 48 (2030-10-08), stop scale-up spending and convert to a regional Asia-Africa compact.

---

#### FM3 - The Orphaned Rubber Hubs

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Alternative Rubber (Guayule and Russian Dandelion) Commercial Lead
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- OEMs hedge with synthetic rubber and sign only non-binding letters.
- Pilot cost stays 30-40% above Hevea (estimate); the gate is missed.
- Co-product markets for inulin and resin stay thin.
- Hub coverage is 0.80 at the gate limit, so lenders decline.
- Hub construction slips; the 200,000 t/yr target is missed.
- Stranded capex and lost OEM and farmer credibility.

##### Early Warning Signs
- OEM consortium has fewer than 5 members at Month 6 (2027-04-08)
- No take-or-pay letters of intent at Month 18 (2028-04-08)
- Pilot cost trajectory above USD 1.80/kg at Month 60 (2031-10-08)
- Co-product buyers unconfirmed at Month 18 (2028-04-08)

##### Tripwires
- Fewer than 2 OEM letters of intent at Month 18 (2028-04-08)
- Priced offtake <80% of planned volume at Month 60 (2031-10-08)
- Pilot cost >=USD 2.02/kg (25% premium) at Month 84 (2033-10-08)
- Hub debt coverage <1.0x in the financial model

##### Response Playbook
- Contain: Halt hub site commitments and capex and keep spending to pilot scale.
- Assess: Rerun hub economics under three rubber prices and zero co-product revenue, and survey OEM buying intent within 60 days.
- Respond: Pivot to specialty latex (gloves, hypoallergenic goods) at 5,000-20,000 t/yr, and defer commercial hubs to Months 96-120 (2034-10-08 to 2036-10-08).


**STOP RULE:** If cost exceeds a 25% premium to Hevea at Month 84 (2033-10-08) and offtake is under 60%, stop commercial hub construction and reduce the alternative-rubber pillar to pilot and niche scale.

---

#### FM4 - The Premium Payment Pipeline Jam

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A5
- **Owner**: Smallholder Adoption and Surveillance Incentives Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Mobile payment delays exceed 30 days; farmers lose trust.
- Verification costs consume much of the USD 25-33 per farmer premium (scaled cap about USD 50M/yr).
- Pilot funds of USD 10-25M are spent before redesign.
- Participation stalls near 30% (estimate).
- Scale-up approval is delayed.
- Surveillance gaps leave incursions undetected, raising outbreak cost toward USD 2-5B (estimate).

##### Early Warning Signs
- Median payment time above 35 days at Month 12 (2027-10-08)
- Diagnostic lab turnaround above 14 days
- Pilot enrollment below 70% of 500 farmers per zone
- Premium verification cost above 30% of payout

##### Tripwires
- Participation <40% at Month 12 (2027-10-08)
- Payment delay >45 days in any zone
- Payment failure rate >10%
- Pilot spend >USD 20M before Month 18 (2028-04-08)

##### Response Playbook
- Contain: Pause new enrolment and clear all overdue payments within 14 days using manual mobile-money transfers.
- Assess: Audit payment, lab and verification delays in each zone within 30 days and measure participation against a 60% target.
- Respond: Raise premiums to USD 100-150 per report (proposed threshold), switch to income-bridge grants where needed, and delay scale-up by 6 months.


**STOP RULE:** If pilot participation is below 40% at Month 18 (2028-04-08) after one redesign, stop scale-up of premiums and rely on paid inspector networks.

---

#### FM5 - The Pyramid That Leaned

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A6
- **Owner**: Hevea Resistance Breeding Program Director
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- Trial stations or Brazil lab commissioning slip; the first Virulence Gate at Month 24 (2028-10-08) lacks baseline data.
- Three-gene pyramids show yield drag below 85% of elite clones.
- Inoculation failures stretch trials by 18-24 months (estimate).
- Only 1 candidate qualifies at Month 84 (2033-10-08).
- Tranche release falls to 50%; smallholder replanting stalls.
- Pressure grows to release weakly pyramided clones.

##### Early Warning Signs
- Fewer than 4 trial stations operating at Month 18 (2028-04-08)
- Brazil lab not established by Month 2 (2026-12-08) or not sequencing by Month 12 (2027-10-08)
- Fewer than 3 candidates pass Virulence Gate at Month 36 (2029-10-08)
- Candidate yield under 80% of elite clones at Month 60 (2031-10-08)

##### Tripwires
- Fewer than 4 trial stations at Month 12 (2027-10-08)
- Brazil lab not established (site, partner host lab, director named) at Month 2 (2026-12-08), or not operating at Month 9 (2027-07-08)
- Fewer than 3 candidates pass the Month 36 (2029-10-08) Virulence Gate
- Candidate yield <85% of elite clones at Month 72 (2032-10-08)

##### Response Playbook
- Contain: Freeze any release path for under-pyramided clones and hold current candidates in trials.
- Assess: Rerun the breeding timeline model with actual trial data within 45 days and score each candidate's probability of passing by Month 84 (2033-10-08).
- Respond: Launch fast-track partial-resistance clones for emergency use, add trial capacity in clean-zone sites, and ask the board to reset the cultivar gate.


**STOP RULE:** If no candidate carries 3 independent genes and passes a Virulence Gate by Month 60 (2031-10-08), cancel the pyramiding route and pivot funds to alternative rubber and containment.

---

#### FM6 - The Broken Trust at the Source

- **Archetype**: Market/Human
- **Root Cause**: Assumption A4
- **Owner**: Hevea Resistance Breeding Program Director
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Benefit-sharing talks with Brazilian states and communities stall past Month 12 (2027-10-08).
- Communities see the royalty offer as extractive; public opposition grows.
- Collection starts late; 200 accessions are missed by Month 18 (2028-04-08).
- Fewer resistance sources weaken pyramiding.
- Later community challenges threaten cultivar release.
- Smallholders and OEMs doubt the program's legitimacy.

##### Early Warning Signs
- Fewer than 6 signed access agreements at Month 6 (2027-04-08)
- Community organizations walk out of talks
- Media or NGO campaigns against the program
- Collection not started by Month 10 (2027-08-08)

##### Tripwires
- Fewer than 6 signed agreements at Month 6 (2027-04-08)
- Collection not started by Month 12 (2027-10-08)
- Fewer than 100 accessions delivered at Month 18 (2028-04-08)

##### Response Playbook
- Contain: Halt all collection in disputed territories and keep existing repository accessions (50-80, estimate) in use.
- Assess: Hold independent consultations with each community within 45 days to find the specific objections to the terms.
- Respond: Offer co-ownership of trait data, community governance seats and a pooled benefit fund, and extend the timeline for cultivar gates.


**STOP RULE:** If no binding access agreement covers at least 100 accessions by Month 18 (2028-04-08), end new wild collection and rely only on existing repository germplasm.

---

#### FM7 - The Debt Nobody Owned

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Capital Stack and Funding Mechanisms Designer
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- No payer is named for the USD 7.0B bank lending.
- Banks delay disbursement; tranches stall at Months 36-60 (2029-10-08 to 2031-10-08).
- Debt service of about USD 449M/yr (estimate) starts around Month 60 (2031-10-08) and competes with the levy.
- Replant-loan capital is trapped or unfunded.
- Inspector ramp, trial stations and smallholder finance slip 6-12 months (estimate).
- Funders question program solvency.

##### Early Warning Signs
- No payer named for debt service at Month 6 (2027-04-08)
- Fewer than 2 banks sign term sheets at Month 3 (2027-01-08)
- Loan-capital source for replanting unresolved at Month 12 (2027-10-08)
- Levy receipts cover less than 50% of forecast debt service

##### Tripwires
- Bank commitments <2 at Month 3 (2027-01-08)
- Debt-service payer unnamed at Month 12 (2027-10-08)
- Bank disbursement delayed >=90 days past schedule
- Projected debt service >30% of annual levy receipts

##### Response Playbook
- Contain: Pause new bank-funded commitments and protect ring-fenced reserves from debt-service draws.
- Assess: Model debt-service coverage under levy compliance of 60%, 80% and 100% within 45 days and rank payer options.
- Respond: Restructure part of the lending into grants or blended finance, assign a named payer in the charter, and bring forward the outcome-linked bond fallback.


**STOP RULE:** If no binding repayment source covers the USD 7.0B lending by Month 18 (2028-04-08), cancel bank-financed scope and resize the program to grant and levy funding.

---

#### FM8 - The Spores Beat the Clock

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A9
- **Owner**: Phytosanitary Standards and Protocol Lead
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
- Climate shift or a contaminated-material pathway lets SALB reach a free region before Month 84 (2033-10-08).
- Detection lags in smallholder zones; spread reaches the plantation scale.
- Resistant cultivars are not ready; only partial-resistance clones exist.
- Full establishment costs USD 2-5B (estimate) against a USD 0.5B reserve.
- Residual draw of USD 1.5-4.5B from the USD 4.5B pool starves breeding and hubs.

##### Early Warning Signs
- Climate modelling shows rising suitability in free regions
- Suspect detections near ports or nurseries rise
- Zero lab-cleared suspects by Month 30 (2029-04-08)
- Surveillance participation under 40% in free-region zones

##### Tripwires
- Modelled incursion probability >=30% before Month 84 (2033-10-08)
- Fewer than 20 suspect detections logged at Month 72 (2032-10-08)
- Detection-to-action time >60 days in any drill
- Fewer than 2 fast-track clones available at Month 60 (2031-10-08)

##### Response Playbook
- Contain: Trigger quarantine zones, movement bans and the outbreak reserve within 6 weeks of confirmation.
- Assess: Map the infected area, isolate lineage and cost against the contingency pool within 30 days.
- Respond: Deploy fast-track partially resistant clones, raise surveillance in neighbouring countries and request fallback funding for any residual above the reserve.


**STOP RULE:** If SALB is established in a major free producer before Month 60 (2031-10-08) and the residual cost exceeds the free contingency pool, pivot the program to emergency response and suspend alternative-rubber scale-up.

---

#### FM9 - The Secretariat Nobody Trusted

- **Archetype**: Market/Human
- **Root Cause**: Assumption A8
- **Owner**: Multilateral Secretariat Executive Director and Governance Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Producers see the secretariat as externally imposed control over their rubber sector.
- OEMs and banks suspect board capture.
- A major producer contests a gate decision or refuses protocol enforcement.
- Tranche release stalls 6-12 months (estimate).
- Regional bilateral deals fragment the program.
- Public criticism erodes farmer and funder trust.

##### Early Warning Signs
- Fewer than 6 producer governments sign the charter at Month 3 (2027-01-08)
- Board votes split along producer versus funder lines
- A major producer misses compact signing at Month 24 (2028-10-08)
- Press or NGO criticism of program control

##### Tripwires
- Producer signatories <6 at Month 3 (2027-01-08)
- Any gate decision contested by >=2 board factions
- Decision latency >60 days on a tranche release
- A producer with >10% of global output rejects the protocol

##### Response Playbook
- Contain: Suspend contested decisions, keep funds in escrow and invoke the 30-day appeal route.
- Assess: Interview each faction within 30 days to separate sovereignty concerns from funding disputes.
- Respond: Revise board voting rules and per-country allocations, add producer co-chairs, and publish all rationales to restore legitimacy.


**STOP RULE:** If two or more major producers withdraw from the protocol by Month 36 (2029-10-08), stop global scale-up and reconstitute the program as a regional compact.
