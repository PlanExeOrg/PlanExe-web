### 1. Programme Steering Council

**Rationale for Inclusion:** This is a large, long-horizon, public-private program with diverse funders (sovereigns, multilateral development banks, industry), multiple geographies (Brazil, USA/Mexico, Europe, Southeast Asia, West Africa), and high political and institutional risk. A strategic steering body is essential to maintain alignment across sovereign and private sponsors, oversee stage-gate discipline, resolve strategic conflicts (legitimacy vs. enforceability of the containment protocol, speed vs. durability in breeding, focus vs. hedging in alternative crops), and ensure sustained political commitment over 25 years. The Council provides governance visibility to maintain stakeholder confidence and operational continuity through leadership transitions.

**Responsibilities:**

- Approve programme strategy, 5-year rolling plans, and annual implementation budgets within the USD 30 billion cap
- Oversee stage-gate discipline: review independent auditor verdicts, authorize tranche releases (minimum 80% rule), and enforce KPI thresholds at Months 36/84/144/216 (2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12)
- Resolve strategic conflicts and escalated decisions exceeding programme-director authority (containment protocol authority model, alternative-crop portfolio breadth, capital-stack allocation)
- Monitor political and funding risks; maintain binding 25-year framework agreements with sovereigns and development banks; ensure industry levy commitments hold
- Oversee programme sustainability and institutional continuity; approve leadership succession plans and knowledge-management protocols
- Review quarterly risk reports and approve mitigation actions for risks exceeding defined thresholds; authorize contingency-reserve deployment

**Initial Setup Actions:**

- Convene inaugural Council meeting by Month 1 (2026-11-12); confirm rotating representation from at least 5 sovereign funders, top 2-3 OEMs, 2-3 research institutions, and 1-2 smallholder/farmer representatives
- Publish Terms of Reference (governance scope, decision thresholds, escalation rules, transparency standards) by Month 3 (2027-01-12)
- Establish quarterly meeting schedule and approve Council chair (rotate every 2 years among sovereigns) by Month 1 (2026-11-12)
- Sign binding 25-year framework agreements with all sovereigns and development banks by Month 12 (2027-10-12), with explicit gate-release triggers and minimum-funding floors
- Approve programme-director role, executive team structure, and delegation matrix; recruit Programme Director by Month 3 (2027-01-12)
- Commission independent auditor and finalize audit scope and pre-registered KPI definitions by Month 6 (2027-04-12)

**Membership:**

- Senior representative from each of at least 5 sovereign/multilateral funders (rotating chair)
- Chief executive officer or deputy from at least 2-3 major OEM tire makers
- Lead scientist or director from at least 2-3 major research institutions (breeding, processing, phytosanitary expertise)
- Representative from smallholder organizations or farmer cooperatives (1-2 seats)
- Programme Director (ex officio, non-voting on own performance)

**Decision Rights:** Approve all decisions above USD 50 million (estimate), all strategic direction changes, all gate passage determinations, binding framework agreements, and contingency-reserve deployment. Approve annual budgets and 5-year plans. Can delegate operational decisions below USD 50 million to Programme Director and internal bodies. Cannot override independent auditor verdicts on KPI thresholds without binding adjudication (60-day review); can choose to withhold or release tranches based on auditor findings.

**Decision Mechanism:** Consensus-seeking with supermajority (≥66%) tie-breaker. On gate decisions, independent auditor verdict is binding unless the Council unanimously disputes the auditor's methodology (requires written rationale to auditor and funders within 15 days); if auditor stands by the verdict, tranches are released as recommended. On capital allocation and strategic direction, ≥66% supermajority carries the vote. Chair has no additional casting vote.

**Meeting Cadence:** Quarterly (every 3 months); accelerated to monthly Months 3-6 (2027-01-12 to 2027-04-12) during early governance setup. Special meetings called within 10 days if a gate closure or risk threshold is triggered. Annual in-person meeting in Month 12 (2027-10-12) to review framework agreements and approve rolling 5-year plan refresh.

**Typical Agenda Items:**

- Gate-closure reports and independent auditor verdicts (Month 36/84/144/216 = 2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12 gates)
- Risk register review and mitigation-action updates (quarterly summary, escalations)
- Funding and tranche-release decisions (quarterly dashboard of disbursements and outstanding tranches)
- Strategic conflicts or escalations from operational bodies (Containment Authority model disputes, breeding pathway acceleration, alternative-crop siting)
- Programme-director performance review and leadership succession planning (annual)
- Political or funder-commitment updates; framework-agreement compliance (quarterly summary)

**Escalation Path:** Disputes on independent auditor verdicts are escalated to a neutral third-party Adjudication Panel (independent of Council and auditor), which issues binding judgment within 60 days. Unresolved conflicts between sovereigns and OEMs over capital allocation or strategic direction are escalated to the programme chair and, if still unresolved, referred to the Steering Council for a formal vote (≥66% supermajority rule applies). Institutional-integrity or corruption allegations are escalated to the programme Anti-Corruption Officer and an independent investigator, with Council notification within 15 days.
### 2. Programme Management Office (PMO)

**Rationale for Inclusion:** This is a multi-workstream, multi-geography execution programme with four major pillars (containment protocol, breeding, alternative crops, smallholder adoption) running in parallel, each with distinct technical requirements, timelines and dependencies. A dedicated PMO is essential to manage day-to-day operational execution, coordinate across workstreams, track KPIs and milestones, manage operational-level risk and cost, and ensure that the programme stays on track toward stage gates. The PMO translates strategic decisions from the Steering Council into annual plans and quarterly delivery cycles.

**Responsibilities:**

- Develop and manage detailed workstream delivery plans for each of the five phases (Months 0-36 = 2026-10-12 to 2029-10-12, 36-84, 84-144, 144-216, 216-300); align plans with gate KPIs and stage-gate schedule
- Manage programme budget execution: track spending against USD 30 billion cap and approved allocations; manage tranche disbursements and contingency-reserve deployment within Council authorization
- Coordinate across workstreams (protocol adoption, breeding trials, alternative-crop pilots, extension, smallholder finance); manage inter-workstream dependencies and resolve conflicts below the Steering Council threshold
- Monitor operational KPIs and milestones quarterly; compile gate-readiness reports for independent auditor 6 months before each gate (Month 30, 78, 138, 210 = 2029-04-12, 2033-04-12, 2038-04-12, 2044-04-12)
- Manage operational risk: track risks identified by each workstream; assess likelihood and impact; escalate risks exceeding defined thresholds to the Steering Council
- Manage programme communications, knowledge management, and documentation; publish quarterly progress reports and annual programme reviews to stakeholders

**Initial Setup Actions:**

- Establish PMO office location and staffing by Month 1 (2026-11-12); recruit Programme Director, Deputy Director, Finance Manager, Workstream Coordinators (Containment, Breeding, Alternative Crops, Smallholder Delivery) by Month 3 (2027-01-12)
- Develop detailed Phase 1 (Months 0-36 = 2026-10-12 to 2029-10-12) delivery plan by Month 6 (2027-04-12), including protocol-drafting timeline, producer-nation MoU negotiation, auditor contracting, and surveillance setup
- Establish integrated PMO scheduling and budget-tracking system by Month 3 (2027-01-12); define monthly workstream milestones and monthly financial-burn forecast through Month 36 (2029-10-12)
- Set up quarterly KPI-tracking dashboard linking programme milestones to gate criteria; brief Steering Council on methodology by Month 6 (2027-04-12)
- Recruit or assign lead coordinators for each of the 5 core workstreams (Containment Protocol, Breeding Trials, Alternative Crops, Smallholder Extension, Surveillance); establish cross-workstream coordination forum (monthly) by Month 3 (2027-01-12)

**Membership:**

- Programme Director (head of PMO, hired by Steering Council)
- Deputy Programme Director (operational oversight, hired by Programme Director subject to Council approval)
- Finance Manager (budget tracking, tranche disbursements, contingency reserve management)
- Workstream Coordinator - Containment Protocol Authority (SALB protocol, producer-nation adoption, protocol-compliance auditing)
- Workstream Coordinator - Resistance Breeding (cultivar development, ABS agreements, breeding-trial coordination across 4 sites)
- Workstream Coordinator - Alternative Crops (Guayule/dandelion farming, processing R&D, pilot plants, OEM engagement)
- Workstream Coordinator - Smallholder Delivery (extension corps, nurseries, replant finance, farmer engagement)

**Decision Rights:** Approve all decisions under USD 50 million (estimate); all workstream budgets and monthly spend within approved allocations; all non-strategic operational changes (e.g., hiring, supplier contracts, minor work-plan adjustments). Cannot approve gate passage or strategic direction changes (escalate to Steering Council). Cannot approve risk-mitigation spending above defined thresholds (escalate to Steering Council and Compliance & Ethics Committee). Authority to commit contingency-reserve deployment is limited to USD 25 million per decision; deployments above that threshold require Council approval.

**Decision Mechanism:** Consensus-seeking among the Programme Director and Workstream Coordinators; Programme Director has final say in ties on operational matters. On budget conflicts, Finance Manager's spend forecast is binding unless overridden by the Steering Council. On workstream disputes (e.g., resource allocation conflicts), PMO convenes a cross-workstream review within 5 working days; if unresolved, escalates to Programme Director, who decides; if still contested, escalates to Steering Council.

**Meeting Cadence:** Monthly full-PMO operational review (Programme Director, Deputy, Finance, all Workstream Coordinators); quarterly steering-review with Steering Council to present workstream status, gate-readiness updates and operational-risk summary. Cross-workstream coordination forum meets weekly (Months 0-36 = 2026-10-12 to 2029-10-12) to align dependencies, then bi-weekly thereafter.

**Typical Agenda Items:**

- Monthly milestone tracking: progress against Phase delivery plan, on-time and on-budget status for each workstream
- Budget execution: monthly spend tracking, burn rate, forecast-to-completion, variance analysis against USD 30 billion cap
- Gate-readiness dashboard: quarterly summary of KPI achievement toward Month 36/84/144/216 (2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12) gates; early-warning flags for at-risk KPIs
- Cross-workstream dependencies: coordination of protocol adoption with surveillance deployment, breeding-trial trial site readiness with smallholder training, alternative-crop siting with processing-plant financing
- Operational risk management: review of workstream-level risks, escalation of risks exceeding thresholds to Steering Council, mitigation-action tracking
- Communications and knowledge management: upcoming publications, data-repository updates, stakeholder communication calendar

**Escalation Path:** Operational decisions exceeding USD 50 million or strategic in nature are escalated to the Steering Council within 10 working days of identification. Workstream conflicts unresolved by consensus are escalated to the Programme Director and, if still unresolved, to the Steering Council. Financial variances exceeding 10% of a workstream budget are escalated to the Finance Manager and flagged to the Steering Council within 15 days. Corruption or institutional-integrity allegations are escalated to the Anti-Corruption Officer and Compliance & Ethics Committee within 24 hours.
### 3. SALB Containment Protocol Authority (embedded in IPPC framework)

**Rationale for Inclusion:** The SALB Containment Protocol is the non-negotiable Phase 1 deliverable and a critical dependency for all other programme elements. It must be harmonized with existing IPPC and regional plant-protection standards to gain legitimacy and binding adoption by major producing nations. A dedicated Authority is required to: (1) draft the protocol in alignment with IPPC frameworks; (2) coordinate with producing nations to embed it in their national regulations by Month 36 (2029-10-12); (3) oversee compliance through a network of inspectors and nursery certifications; (4) trigger incursion response playbooks if SALB is detected; and (5) generate the containment-performance evidence needed for gate verification. Without this dedicated focus, the protocol will lack enforcement and the gates will be undermined.

**Responsibilities:**

- Draft the SALB Containment Protocol harmonized with IPPC and regional plant-protection standards; submit draft to IPPC working group by Month 4 (2027-02-12); support IPPC adoption vote by Month 36 (2029-10-12)
- Lead producer-nation MoU negotiations (Brazil, Indonesia, Thailand, Malaysia, Vietnam) to commit binding national regulatory embedding by Months 36-48 (2029-10-12 to 2030-10-12); coordinate with each nation's plant-protection agency
- Establish compliance-inspection framework: hire and train 100+ inspectors across top 5 producers; deploy inspectors to conduct at least 100,000 inspected lots/year (target by Month 12 = 2027-10-12); maintain compliance certificate database; suspend certification for protocol violations
- Set binding penalty schedule for protocol non-compliance (fines equal to 5-10x value of affected material, reputational consequences); enforce uniformly across countries
- Coordinate with Surveillance Sensing Architecture: verify suspicious SALB alerts from surveillance teams within 2 weeks; issue incursion-response triggers to Incursion Response Playbook authority
- Compile quarterly containment-performance reports: share of nurseries under certified inspection, share of material moved under certified chain-of-custody, compliance violations detected and penalties imposed, red-team drill results; verify this evidence is accurate for independent auditor review at gates

**Initial Setup Actions:**

- Establish Protocol Adoption Secretariat at FAO/IPPC by Month 3 (2027-01-12) with dedicated staff reporting to the Containment Authority director; publish hiring plan and organizational chart by Month 1 (2026-11-12)
- Hire Containment Authority Director by Month 1 (2026-11-12); recruit technical staff (phytosanitary specialists, protocol drafters, compliance managers) by Month 3 (2027-01-12)
- Publish draft protocol for stakeholder and IPPC working-group review by Month 4 (2027-02-12); establish a working group comprising representatives from top 5 producers, IPPC Secretariat, regional plant-protection organizations, and OEMs
- Negotiate bilateral MoUs with Brazil, Indonesia, Thailand, Malaysia and Vietnam by Month 6 (2027-04-12); secure written commitment to bind the protocol in national regulation by Month 36 (2029-10-12) (proposed threshold for scale-up gate)
- Develop compliance-inspection standard operating procedures (SOPs) and inspector training curriculum by Month 6 (2027-04-12); begin recruiting and training inspectors by Month 9 (2027-07-12)
- Establish compliance-certificate database and mobile-based lot-tracking system by Month 12 (2027-10-12); publish certified-nursery list and inspection schedule publicly

**Membership:**

- Containment Authority Director (head, hired by Steering Council)
- Deputy Director for Protocol Drafting and IPPC Coordination (IPPC engagement, draft harmonization)
- Deputy Director for Compliance Inspection and Enforcement (inspector network, certification management, penalty enforcement)
- Technical Lead - Phytosanitary Standards (drafting, harmonization with regional standards)
- Compliance and Enforcement Manager (penalty schedule, violation documentation, appeals)
- Representatives (non-voting) from each of the top 5 producing nations' plant-protection agencies (for consultation and coordination)

**Decision Rights:** Approve protocol language and final draft submission to IPPC; approve compliance-inspection SOPs and penalties within defined bounds (fines 5-10x value, as per policy); approve suspension of nursery certification for non-compliance; approve inspector hiring and inspector-network deployment; approve all communications with producing nations regarding regulatory embedding. Cannot override Steering Council direction on protocol authority model (e.g., if Steering Council directs an alternative authority model, the Authority must adapt). Cannot approve strategic changes to the protocol's scope without Council approval (e.g., expanding to cover other pathogens).

**Decision Mechanism:** Consensus-seeking among Deputy Directors and Technical Lead; Director has final say on operational protocol-drafting decisions. On compliance enforcement (penalty decisions), consensus of Director and Compliance Manager; if disputed by a producing nation, escalate to Steering Council for final review within 30 days. On IPPC working-group negotiations, Director chairs and has authority to accept or reject compromise language, subject to Council approval on major revisions.

**Meeting Cadence:** Weekly internal coordination (Months 0-12 = 2026-10-12 to 2027-10-12) for protocol drafting; bi-weekly during IPPC working-group phase (Months 3-6 = 2027-01-12 to 2027-04-12); monthly thereafter during producer-nation embedding phase (Months 6-36 = 2027-04-12 to 2029-10-12). Quarterly updates to Steering Council and PMO. Bi-weekly coordination with Surveillance and Incursion-Response teams once protocol is adopted (Month 36 onwards = 2029-10-12 onwards).

**Typical Agenda Items:**

- Protocol-drafting progress: harmonization with IPPC standards, stakeholder comment resolution, working-group negotiations
- Producer-nation engagement: MoU status, national regulatory-embedding timeline, country-specific compliance requirements
- Compliance monitoring: inspection coverage (target 100,000 lots/year), certification database, compliance violations and penalties imposed
- Red-team drill planning and results (Months 18-36 = 2028-04-12 to 2029-10-12): test protocol enforcement, document detection accuracy and response speed
- Liaison with Surveillance and Incursion Response: alert-verification procedures, response triggers, data-sharing protocols

**Escalation Path:** Disputes with producing nations on protocol compliance or penalty decisions are escalated to the Steering Council within 15 days; Council reviews and issues guidance within 30 days. If a major producer (Brazil, Indonesia or Thailand) threatens not to embed the protocol by Month 36 (2029-10-12), escalate immediately to Steering Council (within 5 days) for strategic response. Legal challenges or ABS-related disputes (e.g., over use of germplasm data in the protocol) are escalated to the Anti-Corruption Officer and Compliance & Ethics Committee.
### 4. Compliance & Ethics Committee

**Rationale for Inclusion:** This is a large, multi-geography programme spanning developing nations with high corruption and governance risk, involving billions in public-private funding, access-and-benefit-sharing obligations, smallholder finance with default risk, and complex multi-country compliance (Nagoya Protocol, phytosanitary regulations, environmental permits, tax rules). Dedicated oversight of compliance, anti-corruption, ethics, and benefit-sharing is essential to: (1) prevent bribery of inspectors, programme staff or plant-protection officials; (2) ensure ABS agreements are honored and benefit-sharing payments reach intended communities; (3) detect and investigate conflicts of interest in cultivar selection, offtake contracts or resource allocation; (4) manage environmental and social-safeguarding risks; and (5) protect the programme's institutional integrity and credibility with funders and stakeholders. Without this body, corruption or ethics breaches could undermine the entire programme.

**Responsibilities:**

- Develop and enforce programme-wide anti-corruption, conflict-of-interest and ethics policies; publish Code of Conduct for all personnel, contractors and partners by Month 3 (2027-01-12)
- Monitor and audit benefit-sharing compliance: verify that ABS royalties and community payments ($1-5/ha, proposed) are calculated correctly, disbursed on schedule (by Month 12 = 2027-10-12 annually), and reach intended Amazonian communities; conduct annual community benefit-sharing audits
- Oversee breeding-trial data integrity: audit cultivar yield, disease-rating and trial records at 4 sites (Brazil, Thailand, Malaysia/Indonesia, Côte d'Ivoire) to detect data manipulation or undisclosed conflicts of interest; annual audits by independent validators
- Investigate and resolve allegations of corruption, conflict of interest or unethical behavior within 30 days of report; maintain confidentiality and whistleblower protections; escalate findings to the Steering Council and, if warranted, to law enforcement
- Audit smallholder-finance deployment and repayment to detect fraud, misuse of replant-finance funds, or false adoption claims; conduct annual audits of at least 2,000 farmers per major country
- Oversee environmental and social safeguards: audit alternative-crop siting to verify no displacement of smallholders, food-crop loss or water-stress violations; document and mitigate any adverse impacts

**Initial Setup Actions:**

- Hire Committee Chair and Anti-Corruption Officer by Month 1 (2026-11-12); recruit Compliance Manager, ABS Specialist, and Field Auditor by Month 3 (2027-01-12)
- Publish programme Code of Conduct, anti-corruption policy, and conflict-of-interest disclosure form by Month 3 (2027-01-12); require all personnel and partners to sign by Month 6 (2027-04-12)
- Establish benefit-sharing audit protocol and community outreach strategy by Month 6 (2027-04-12); conduct baseline community interviews and publish benefit-sharing verification framework
- Set up confidential reporting channels (hotline, email, field-agent channels) for whistleblowing and allegation reporting by Month 3 (2027-01-12); publicize channels to all personnel and communities
- Develop breeding-data audit plan in coordination with the independent auditor and Resistance Breeding Workstream by Month 6 (2027-04-12); schedule annual audits at each of the 4 breeding sites
- Establish smallholder-finance audit framework and fraud-detection protocols by Month 6 (2027-04-12) in coordination with Smallholder Delivery Workstream

**Membership:**

- Committee Chair (independent, external to the programme, appointed by Steering Council for 3-year renewable term)
- Anti-Corruption Officer (full-time, hired by Committee Chair, reports to Chair and Steering Council)
- Compliance Manager (multi-country compliance tracking, audit scheduling)
- ABS Specialist (benefit-sharing verification, community liaison, Nagoya Protocol compliance)
- Environmental and Social Safeguards Officer (alternative-crop siting audits, land-tenure verification, conflict-of-interest reviews)
- External Member (independent expert in developing-country governance or development-programme compliance; serves 2-year term)

**Decision Rights:** Approve and enforce the Code of Conduct, anti-corruption policy and whistleblower-protection procedures; approve benefit-sharing audit schedules and findings; determine consequences for minor ethics violations (censure, remedial training); approve publication of annual compliance audit summaries. Cannot impose legal penalties (refer to law enforcement); cannot override the independent auditor's data-integrity findings. Can recommend to the Steering Council that a Programme Director or key personnel be removed for cause (conflict of interest, corruption); Council makes final determination.

**Decision Mechanism:** Consensus-seeking among Committee members, with Chair having final say on investigation findings and remedial actions. On conflict-of-interest determinations, at least two members must agree before action is taken. On findings that may trigger disciplinary action, Committee issues a written report with opportunity for the accused party to respond within 10 days; final determination by Chair with notice to Steering Council.

**Meeting Cadence:** Monthly internal meetings (Chair, Anti-Corruption Officer, Compliance Manager, ABS Specialist, Safeguards Officer); quarterly meetings with external members and audit partners (independent auditor, data validators); quarterly reports to Steering Council. Annual in-depth audit-findings review with Steering Council (Month 12 = 2027-10-12 onwards).

**Typical Agenda Items:**

- Whistleblower-allegation summaries: new reports, investigation status, closure of resolved cases
- Benefit-sharing audit results: community-payment verification, disbursement status, benefit-sharing disputes or claims
- Breeding-data audit findings: data-integrity reviews, detected anomalies, conflict-of-interest checks at breeding sites
- Smallholder-finance fraud audits: replant-loan defaults, false-adoption claims, finance-misuse cases
- Environmental and social-safeguards audits: alternative-crop siting impacts, land-tenure issues, community-displacement concerns
- Annual compliance and ethics audit summary: publication plan, lessons learned, policy updates

**Escalation Path:** Allegations of corruption by senior personnel (Programme Director, Steering Council members, Workstream Coordinators) are escalated to the Committee Chair and an independent external investigator appointed by the Chair; findings are reported to the Steering Council and, if warranted, to law enforcement. Findings of systemic corruption or ethics violations affecting programme integrity are escalated to all funders within 15 days. Unresolved community benefit-sharing disputes are escalated to the Steering Council for mediation; if still unresolved, referred to binding arbitration by an independent third party.
### 5. Gate Evidence Verification Panel (Independent Auditor + Standing Technical Advisory Group)

**Rationale for Inclusion:** The programme's funding structure depends entirely on stage-gated capital release at Months 36/84/144/216 (2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12). Gate-passage decisions must be credible, evidence-based and independent to justify capital tranches to funders, producing nations and OEMs. However, the gates measure complex, technical outcomes (containment performance, breeding yield and durability, cost competitiveness of alternatives, smallholder uptake) where interpretation is non-trivial. An independent international auditor is needed to verify KPI evidence with fixed, pre-registered methodology; and a standing Technical Advisory Group is needed to provide specialized scientific input to the auditor on breeding, phytosanitary and processing questions. Together, these two bodies ensure that gate verdicts are credible, transparent and not subject to programme-internal pressure or political interference.

**Responsibilities:**

- Independent Auditor: Contract with an external international audit firm (agricultural or supply-chain audit specialist) by Month 3 (2027-01-12); maintain independence from the PMO and Steering Council
- Independent Auditor: Pre-register audit scope and KPI definitions for each of the 4 gates (Month 36/84/144/216 = 2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12) by Month 6 (2027-04-12), including: field-visit plan (30-40% of audit time), database audit (40-50%), stakeholder interviews (20-30%), validation thresholds for each KPI, and dispute-resolution protocol
- Independent Auditor: Conduct unannounced and announced field audits at breeding sites, nurseries, estates, processing plants and surveillance hubs; collect primary data on yield, disease ratings, cost, quality variance, containment compliance and smallholder adoption
- Independent Auditor: Issue gate-closure reports 30 days before gate date, stating KPI achievement (pass/fail/conditional), auditor confidence level, and dissenting findings if applicable; publish verdict within 30 days of gate closure
- Technical Advisory Group: Provide specialized input to auditor on breeding-trial interpretation (interpreting yield penalties, resistance durability, multi-site variability); provide input on surveillance data, processing costs, and smallholder-adoption metrics; meet quarterly and for each gate assessment
- Gate Adjudication: If the Steering Council disputes the auditor's KPI verdict, refer dispute to a neutral third-party Adjudication Panel; Panel reviews auditor methodology and data, hears both sides, and issues binding judgment within 60 days

**Initial Setup Actions:**

- Issue request for proposals (RFP) for independent auditor by Month 2 (2026-12-12); evaluate proposals and contract auditor by Month 3 (2027-01-12)
- Recruit independent Auditor Team Lead (embedded in the auditor firm, dedicated to the programme) by Month 3 (2027-01-12); hire field auditors and data specialists
- Form Technical Advisory Group by Month 3 (2027-01-12): recruit 6-8 members including plant pathologist (SALB specialist), plant breeder (Hevea genetics), processing engineer, agronomist (alternative crops), statistician, and supply-chain economist; each member serves 3-year renewable term
- Pre-register audit methodology, KPI definitions and validation thresholds for Month 36 (2029-10-12) gate by Month 6 (2027-04-12); publish pre-registered scope in a dedicated audit-governance document available to all stakeholders
- Establish gate-data submission protocol: PMO submits gate-readiness report to auditor 6 months before gate closure (Month 30/78/138/210 = 2029-04-12, 2033-04-12, 2038-04-12, 2044-04-12) including all trial databases, surveillance records, cost records and smallholder-adoption data
- Establish Adjudication Panel by Month 6 (2027-04-12) comprising three independent experts (one in international arbitration, one in agriculture, one in supply-chain governance); Panel chair is neutral intermediary

**Membership:**

- Independent Auditor (contract firm, reports to Steering Council, not to PMO or Programme Director)
- Auditor Team Lead (embedded with auditor firm, dedicated, reports to firm management and Steering Council)
- Technical Advisory Group Chair (independent, recruited by Steering Council, reports to auditor and Advisory Group)
- Technical Advisory Group Members (6-8 specialists: SALB pathologist, plant breeder, processing engineer, agronomist, statistician, supply-chain economist, and optionally an OEM representative and a smallholder-agronomy specialist)
- Gate Adjudication Panel Chair (independent arbitrator, neutral, appointed by Steering Council for 5-year term)

**Decision Rights:** Independent Auditor: Sole authority to verify KPI achievement and issue gate-closure verdict; verdict is binding unless Steering Council initiates formal adjudication (within 15 days of auditor report). Technical Advisory Group: Advises auditor; group consensus recommendations carry weight but auditor makes final interpretation call. Adjudication Panel: Sole authority to resolve disputes between Steering Council and Auditor; Panel determination is binding and final. Neither the auditor nor the Advisory Group can approve gate passage or tranche release; only the Steering Council can authorize tranche release (based on auditor verdict, 80% minimum rule).

**Decision Mechanism:** Independent Auditor: Issues final verdict based on pre-registered methodology; no consensus requirement; auditor applies judgment within the pre-registered KPI definitions. Technical Advisory Group: Consensus-seeking on major interpretation questions; if no consensus, minority and majority views are documented for auditor consideration. Adjudication Panel: Chair appoints voting procedures; majority vote (2 of 3 panelists) carries decision; written judgment issued within 60 days.

**Meeting Cadence:** Technical Advisory Group meets quarterly (before each gate, at Month 12, 36, 66, 126, 186, 246 = 2027-10-12, 2029-10-12, 2032-10-12, 2037-10-12, 2041-10-12, 2045-10-12, estimate); more frequently (monthly) from Month 12-36 (2027-10-12 to 2029-10-12) during first gate. Independent Auditor submits monthly progress updates (during field-audit phases); full gate-closure report 30 days before each gate deadline. Adjudication Panel convenes only if formal dispute is filed (within 15 days of auditor report).

**Typical Agenda Items:**

- Pre-registered audit scope and KPI definitions (finalized by Month 6 = 2027-04-12 for each gate)
- Field-audit planning and data-collection protocols (before each gate audit phase)
- Technical interpretation of breeding-trial data: yield penalties, multi-site variability, disease-rating consistency
- Surveillance-data interpretation: incursion detection, protocol compliance, false-alarm rates
- Processing-cost and quality-data validation: extraction yield, product specifications, offtake readiness
- Smallholder-adoption data review: survey methodology, default rates, extension-network quality, income-bridging effectiveness
- Gate-closure verdict: KPI achievement, confidence levels, dissenting findings, recommendations for capital release or withholding

**Escalation Path:** If the auditor identifies data inconsistency, missing records or potential data manipulation at a breeding site or nursery, escalate to Compliance & Ethics Committee within 5 days for investigation. If the auditor's gate verdict is disputed by the Steering Council, escalate to Adjudication Panel within 15 days; Panel's decision is final. If an Advisory Group member has a conflict of interest (e.g., financial stake in a processing plant), the member recuses and the group continues with remaining members.
### 6. Resistance Breeding and Cultivar Deployment Oversight Group

**Rationale for Inclusion:** The Year 7 gate (Month 84 = 2033-10-12) depends critically on SALB-resistant, yield-parity Hevea cultivars being ready for deployment. This is the tightest timeline in the programme: trials must be planted by Month 12 (2027-10-12) at 4 sites (Brazil, Thailand, Malaysia/Indonesia, Côte d'Ivoire) to yield 6-year data by Month 84 (2033-10-12). The breeding path has zero slack. This workstream also has high technical complexity (polygenic resistance, durability testing, cultivar selection criteria) and carries significant risk (yield penalties may exceed 10-15%, durability may fail against new SALB variants, multi-site trial interpretation can be contentious). A dedicated Oversight Group is essential to: (1) set clear breeding objectives and KPI thresholds before trials begin; (2) track breeding progress quarterly and identify early warning signals (yield penalties >10% by Month 48 = 2030-10-12); (3) manage cultivar-selection decisions and multi-site trial coordination; (4) oversee durability monitoring beyond the Year 7 gate; and (5) provide transparent, auditable records for the independent Auditor. Without this specialized group, the Year 7 gate will be missed and the programme's entire schedule will cascade-fail.

**Responsibilities:**

- Establish and publish breeding objectives by Month 6 (2027-04-12): define target yield (≥90% of elite clones), minimum resistance sources (≥3 stacked, independent), lesion-size threshold (≤5 mm), defoliation threshold (≤20%), durability-testing requirements (artificial inoculation at 10x field load, sentinel plantings at 4+ sites)
- Coordinate breeding trials across 4 sites (Brazil, Thailand, Malaysia/Indonesia, Côte d'Ivoire): ensure site readiness by Month 12 (2027-10-12), training of site managers and data recordists, and standardized trial protocols across all sites
- Oversee cultivar selection: compile data from all sites at Month 48 (2030-10-12) and Month 72 (2032-10-12) interim checkpoints; assess yield penalties, resistance stacking progress, and durability signals; make go/no-go decisions on candidate cultivars
- Identify early warning signals: by Month 48 (2030-10-12), if yield penalty exceeds 15% (yield <85% of elite) at any site, trigger a breeding-pathway decision (continue conventional breeding, accelerate fast-track crown-budding, or re-scope cultivar targets)
- Oversee Year 7 gate cultivar-readiness evidence: compile standardized yield, disease-rating and multi-site data; validate data accuracy at each site; prepare evidence package for independent auditor 6 months before gate (Month 78 = 2033-04-12)
- Establish post-release durability monitoring: design sentinel plantings and quarterly pathogen-variant surveillance (Months 84-216 onwards = 2033-10-12 to 2044-10-12); begin breeding next-generation cultivars by Month 60 (2031-10-12) so replacements are available within 7 years if breakdown occurs

**Initial Setup Actions:**

- Hire Breeding Programme Director and breeding coordinator by Month 3 (2027-01-12); recruit breeding specialists at each of the 4 sites by Month 9 (2027-07-12)
- Finalize breeding objectives and pre-register cultivar-selection criteria by Month 6 (2027-04-12); publish in a public document with stakeholder input from the Technical Advisory Group and OEM representatives
- Prepare and plant trials at all 4 sites by Month 12 (2027-10-12); establish standardized data-collection protocols and laboratory confirmation methods (disease rating, yield measurement, molecular confirmation of resistance genes)
- Establish quarterly data-review and progress-tracking schedule; compile interim reports at Months 24, 36, 48, 60, 72 (2028-10-12, 2029-10-12, 2030-10-12, 2031-10-12, 2032-10-12) assessing yield, disease control and resistance stacking
- Establish breeding data repository with redundant backup and version control by Month 12 (2027-10-12); grant access to independent auditor and Compliance & Ethics Committee for audits
- Plan second-generation cultivar breeding (start Month 60 = 2031-10-12) to ensure replacements are available by Month 120 (2036-10-12) if first-generation cultivar durability shows early breakdown

**Membership:**

- Breeding Programme Director (senior breeder, hired by Steering Council, recruited from national research institute or international agricultural research center)
- Deputy Directors for each geographic region: Brazil Lead, Thailand/Southeast Asia Lead, Côte d'Ivoire/West Africa Lead
- Breeding Coordinator (data management, multi-site trial oversight, cultivar-selection documentation)
- Site Managers at each of 4 locations: Brazil, Thailand, Malaysia/Indonesia, Côte d'Ivoire (report to regional Deputy Director and Breeding Coordinator)
- External Advisory: SALB pathologist (durability consultant), statistician (multi-site analysis), molecular biologist (resistance-gene validation)

**Decision Rights:** Approve cultivar-selection criteria and breeding objectives (within Steering Council guidance); make go/no-go decisions on candidate cultivars at Month 48 and 72 (2030-10-12, 2032-10-12) interim gates; approve breeding-pathway changes (e.g., initiating crown-budding fast-track) if yield penalties exceed defined thresholds by Month 48 (2030-10-12). Cannot override the independent auditor's interpretation of trial data; must provide auditor with complete data access and cooperate fully with audits. Can decide to release cultivars to seed producers and nurseries only after obtaining Steering Council authorization (based on auditor gate verdict).

**Decision Mechanism:** Consensus-seeking among Breeding Programme Director, Regional Deputy Directors and Breeding Coordinator on major decisions (cultivar selection, pathway changes). Director has final say on breeding-technical decisions if consensus cannot be reached. On Year 7 gate evidence compilation, Breeding Coordinator ensures data quality and Breeding Programme Director certifies completeness and accuracy for auditor submission.

**Meeting Cadence:** Monthly internal coordination (Breeding Programme Director, Regional Deputies, Coordinator); quarterly data-review meetings with all 4 site managers (Months 12, 24, 36, 48, 60, 72 = 2027-10-12, 2028-10-12, 2029-10-12, 2030-10-12, 2031-10-12, 2032-10-12 and annually thereafter); quarterly updates to PMO and Steering Council. Advisory input from Technical Advisory Group at Month 48 (2030-10-12) and Month 72 (2032-10-12) interim decision points.

**Typical Agenda Items:**

- Monthly site reports: trial progress, data quality, issues or delays at any location
- Quarterly data review: yield measurements, disease ratings, resistance-gene validation, multi-site comparisons
- Breeding-pathway checkpoints: Month 48 (2030-10-12) yield-penalty assessment and decision (continue, accelerate, or re-scope); Month 60 (2031-10-12) decision to initiate second-generation cultivar breeding
- Cultivar-selection process: Month 72 (2032-10-12) final cultivar candidates for Year 7 gate; evidence package assembly for auditor
- Post-Year 7 durability strategy: sentinel plantings, pathogen-variant monitoring, next-generation breeding timeline
- Data-repository management: data quality assurance, backup protocols, auditor access

**Escalation Path:** If yield penalties exceed 15% at any site by Month 48 (2030-10-12), escalate immediately to PMO and Steering Council for pathway decision (within 5 days). If data integrity concerns arise (missing records, inconsistent measurements, apparent manipulation), escalate to Compliance & Ethics Committee within 24 hours for investigation. If multi-site interpretation is contentious (e.g., one site shows poor durability while others show good), escalate to the Technical Advisory Group pathologist for independent expert assessment; if still unresolved, refer to Gate Adjudication Panel for pre-gate mediation.