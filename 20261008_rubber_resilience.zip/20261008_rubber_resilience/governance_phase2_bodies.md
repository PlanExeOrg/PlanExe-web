### 1. Program Steering Committee (PSC)

**Rationale for Inclusion:** Strategic oversight body required for a 25-year, $30 billion multi-continent public-private program spanning three interdependent pillars (containment, breeding, alternatives) with stage gates at Months 36, 84, 144, 216 (2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08). PSC provides high-level strategic direction, approves tranches above defined thresholds, ensures funder alignment, and resolves disputes between producer governments, OEMs, development banks, and technical bodies. Program complexity, scale, 25-year horizon, and cross-sovereign coordination require binding strategic authority insulated from annual budget cycles.

**Responsibilities:**

- Approve or reject stage-gate tranche releases (Months 36, 84, 144, 216 = 2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08) on basis of Technical Panel evidence and recommendations, with binding authority over gate decisions
- Set strategic direction for the three pillars (containment, resistance breeding, alternative rubber) in response to biological and market developments, including pillar reallocation within adaptive-tranches framework
- Maintain funder commitment and alignment: convene funders and major producer governments to renew or adjust funding commitments at each gate; handle escalations from contributors regarding capital deployment or governance concerns
- Oversee Technical Gate Charter enforcement and resolve post-gate disputes: if an outcome is contested within 30 days of publication, PSC convenes dispute resolution (arbitration, not litigation) with 6-month resolution timeline
- Review and approve any strategy pivots exceeding 10% reallocation across pillars or deferring major milestones (e.g., hub construction delay >12 months, cultivar-readiness slip >18 months)
- Ensure compliance with ring-fenced funding structures and reserve policies: verify contingency pool (USD 4.5B), outbreak reserve (USD 0.5B-1.0B), and political-risk reserve (USD 0.9B) remain protected and ear-marked

**Initial Setup Actions:**

- Establish PSC board composition and charter by Month 1 (2026-11-08): 6-8 producer-government seats (rotating chairs, no single country holds chair more than 3 years), 3-4 OEM seats, 3-4 development-bank seats, 3-4 independent expert seats; publish roster with biographies and conflict-of-interest certifications
- Negotiate and sign Technical Gate Charter by Month 3 (2027-01-08): binding agreement specifying gate criteria, KPI thresholds, evidence standards, decision rules, partial-achievement tranching, and appeal procedures; obtain signatures from all major funders (≥5-8 sovereigns, ≥2 MLDBs)
- Establish independent Technical Panel (separate from PSC) by Month 3 (2027-01-08): 7-9 conflict-free members (breeding scientists, phytosanitary experts, economist), with selection criteria and term limits; bar PSC members from Panel assessments
- Adopt PSC Standing Rules by Month 2 (2026-12-08): specify meeting cadence (quarterly minimum), decision-making procedures (supermajority or consensus for major decisions), disclosure of conflicts, confidentiality protocols, and escalation paths
- Secure binding multi-year funding commitments from 5-8 sovereigns and ≥2 development banks by Month 3 (2027-01-08): commitments in treaty or binding agreement form (not annual appropriations); ensure no single funder >25% of capital (USD 7.5B cap per funder)

**Membership:**

- 6-8 producer-government representatives (Brazil, Indonesia, Malaysia, Thailand, India, Côte d'Ivoire, Mexico, and one regional rotating seat)
- 3-4 OEM (tire manufacturer and rubber-goods) representatives
- 3-4 multilateral development-bank representatives (World Bank, ADB, IFAD, regional development banks)
- 3-4 independent expert representatives (agronomy, phytosanitary science, economics, nominated by academic or international scientific bodies, independent of funders and producers)

**Decision Rights:** PSC has binding authority to approve or reject stage-gate tranches (Months 36, 84, 144, 216 = 2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08) on basis of Technical Panel recommendations and gate evidence, with major-funder agreement required for release (supermajority, defined as ≥75% of PSC voting members, or consensus for strategic pivots >10% pillar reallocation). PSC decides on tranches up to USD 4.5B (Year 3 envelope); tranches >USD 1.0B also require explicit approval by each development-bank representative present. Contingency pool reallocation (USD 4.5B) requires PSC supermajority. Outbreak reserve (USD 0.5B-1.0B) is pre-authorised for deployment within 2-4 weeks of confirmed SALB detection in a currently free region, bypassing PSC.

**Decision Mechanism:** Supermajority voting (≥75% of PSC members) for gate decisions and tranche release; consensus (all members agree or formally abstain, not dissent) required for strategy pivots exceeding 10% pillar reallocation, formal gate-criteria amendments, or Technical Panel membership changes. Tie-breaker: if voting is tied at 50-50, the PSC chair (rotating annually among producer-government members) casts a deciding vote, with reasoning published. All PSC votes recorded and published within 30 days, including dissents and abstentions. Disputes over gate decisions escalated to independent arbitration (e.g., UNCITRAL rules, 6-month resolution timeline) if not resolved by consensus within 30 days of vote.

**Meeting Cadence:** Quarterly ordinary meetings (Months 3, 6, 9, 12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08 of each calendar year, i.e. monthly during Month 0-1 = 2026-10-08 to 2026-11-08 ramp, then quarterly; adjust to Months 2, 5, 8, 11 = 2026-12-08, 2027-03-08, 2027-06-08, 2027-09-08 if necessary for align with calendar year). Extraordinary meetings within 14 days if called by PSC chair or ≥4 members (e.g., outbreak suspected, funder crisis, gate decision disputes). Stage-gate meetings at Months 36, 84, 144, 216 (2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08), with evidence published 60 days prior and 30-day review/appeal window.

**Typical Agenda Items:**

- Progress reports from Core Project Team and workstream leads (containment, breeding, alternatives, smallholder, governance) against Months 0-X milestones
- Financial and capital deployment status: committed vs. disbursed, funding-gap exposure, levy revenue (from Month 18 = 2028-04-08 onwards), reserve account balances
- Funder alignment: any changes in sovereign or development-bank commitments, political risks, budget pressures; actions to renew commitments approaching end of multi-year tranches
- Stage-gate preparation (quarterly leading into Months 36, 84, 144, 216 = 2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08): evidence compilation, Technical Panel recommendations, gate-criteria satisfaction assessment, dispute anticipation
- Risk escalations: protocol adoption delays, breeding timelines slipping, alternative-rubber cost/quality concerns, smallholder adoption shortfalls, governance disputes, geopolitical friction
- Technical Panel workplan and conflict-of-interest certifications (annual)
- Audit findings (quarterly: external audits of borders, inspections, hub capex, benefit-sharing, loan portfolios) and corrective actions

**Escalation Path:** PSC decisions contested by any funder or producer government within 30 days of publication escalate to independent arbitration (e.g., UNCITRAL, ICC) with 6-month resolution timeline. If arbitration upholds PSC decision, dissenting funder may formally withdraw, triggering contingency funding-gap protocol (fallback cascade: higher bank loan-to-grant ratio, outcome-linked bonds, climate-finance blend). If arbitration overturns PSC decision, gate is re-opened and evidence re-assessed by the Technical Panel within 60 days. PSC disputes that deadlock (e.g., producer governments vs. OEMs on gate criteria interpretation) escalated to a Crisis Steering Group (chair + 2 producers + 2 OEMs + 1 independent expert) for 14-day mediation before arbitration.
### 2. Core Project Team (CPT)

**Rationale for Inclusion:** Operational management body required to execute the program's three pillars and cross-cutting functions. CPT is the secretariat staff and workstream leads responsible for day-to-day decision-making below the strategic threshold (budget <USD 50M per decision, timelines <12 months), risk management, milestone tracking, and coordination across containment protocol negotiation, resistance breeding and field trials, alternative-rubber pilots, smallholder finance deployment, and governance infrastructure. Program complexity across multiple continents, countries, and institutions demands a professional, politically insulated operational team with decision authority and long-term employment security.

**Responsibilities:**

- Execute Phase 1 (Months 0-36, 2026-10-08 to 2029-10-08) containment protocol framework: lead technical drafting, IPPC standard-setting proposal, regional compact negotiations, capacity-building in producer countries; deliver ≥15 countries with enforceable import rules and ≥500 trained inspectors by Month 36 (2029-10-08)
- Manage Brazil-led bio-prospecting and germplasm collection: coordinate Nagoya Protocol access-and-benefit-sharing agreements with Brazilian states and indigenous organizations; deliver ≥200 characterized wild Hevea accessions by Month 18 (2028-04-08); establish pathogen genomics labs (Brazil Month 2 = 2026-12-08, Asia Month 9 = 2027-07-08)
- Oversee resistance breeding pipelines: manage multi-location field trials at ≥4 high-containment stations (Months 0-36 = 2026-10-08 to 2029-10-08); implement Virulence Gates (Months 24, 36, 48, 60 = 2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08); ensure pyramiding of ≥3 resistance genes from ≥2 sources; deliver cultivar candidates for Year 7 and Year 12 gates
- Direct alternative-rubber pilots: manage Guayule and Russian dandelion agronomic trials and cost-tracking; co-fund OEM tire-grade qualification testing; support hub site selection, permitting, and financing; track cost trajectory toward USD 1.62/kg gate (20% premium) by Month 84 (2033-10-08)
- Deploy smallholder finance and surveillance infrastructure: design and pilot replant-loan terms (7-10 year tenor, <5% interest), clean-plant nursery networks, and surveillance-premium mechanisms; pilot in 3-5 zones (Months 6-24 = 2027-04-08 to 2028-10-08); scale if uptake ≥60%
- Manage risk mitigation: coordinate contingency planning (outbreak response playbook, emergency cultivar deployment, funding-gap cascade), monitoring of 16 key risks, quarterly escalation reports to PSC, and corrective-action tracking
- Operate governance infrastructure: maintain Technical Panel secretariat, publish gate evidence 60 days before each decision, manage post-gate appeals and arbitration support, publish annual stakeholder reports and transparency dashboards

**Initial Setup Actions:**

- Recruit Executive Director and core secretariat staff (10-15 FTE) by Month 1 (2026-11-08): Director (external hire, non-national, 5-10 year term contract), Deputy Directors for each pillar (containment, breeding, alternatives), Chief Financial Officer, Risk and Compliance Officer, and administrative support; location in neutral capital (e.g., Geneva or Rome) or rotating regional hubs
- Establish CPT workstream structure by Month 1 (2026-11-08): Containment workstream (protocol negotiation, capacity-building), Breeding & Trials workstream (germplasm, field trials, pathogen genomics), Alternative Rubber workstream (agronomic pilots, processing, offtake), Smallholder Finance & Surveillance workstream, and Governance & Reporting workstream; each led by a subject-matter expert
- Set up financial management systems by Month 1 (2026-11-08): separate bank accounts and ledgers for each pillar (25%, 35%, 25%, 15% allocation), contingency pool (15%), outbreak reserve, and political-risk reserve; establish quarterly financial reporting and external audit protocols
- Launch IPPC/containment protocol drafting and technical working group by Month 0 (2026-10-08): convene Brazil, major producing countries, IPPC Secretariat, and regional plant protection organizations; produce formal IPPC proposal by Month 18 (2028-04-08)
- Commission capacity-building twinning arrangements by Month 1 (2026-11-08): establish partnerships between Brazilian phytosanitary institutes and Southeast Asian, South Asian, and West African agriculture ministries; begin recruiting and training inspectors (target 500 by Month 36 = 2029-10-08)

**Membership:**

- Executive Director (Chief Executive Officer, reporting to PSC chair)
- Deputy Director, Containment & Capacity Building (IPPC harmonization, national protocol adoption, inspector training)
- Deputy Director, Resistance Breeding & Field Trials (germplasm management, breeding pipelines, Virulence Gates, trial operations)
- Deputy Director, Alternative Rubber & Processing (agronomy pilots, cost-tracking, OEM engagement, hub feasibility)
- Deputy Director, Smallholder Finance & Surveillance (replant-loan design, clean-plant networks, surveillance-premium mechanisms, farmer coordination)
- Chief Financial Officer (budget management, capital deployment, financial reporting, audit coordination)
- Chief Risk & Compliance Officer (risk monitoring, mitigation planning, governance audits, ethics/anti-corruption)
- Technical Secretariat Manager (Technical Panel support, gate evidence compilation, publication, appeals administration)
- Program Coordinator/Operations Manager (scheduling, communications, stakeholder coordination, documentation)

**Decision Rights:** CPT has autonomous decision authority for operational spending <USD 50M per decision, milestone timelines <12 months, and routine deployment of pre-approved workstreams (e.g., inspector training, trial-site management, loan disbursement within approved quotas). CPT can approve budget reallocation within pillar allocations up to ±10% (e.g., shifting USD 100M from breeding trials to germplasm collection within the USD 10.5B breeding pillar). Any decision exceeding USD 50M, involving >12 month delays to major milestones, or reallocating >10% across pillars escalates to PSC. CPT approves Technical Panel workplan and conflict-of-interest certifications (annually).

**Decision Mechanism:** CPT operational decisions by consensus among Deputy Directors and CFO/Risk Officer on decisions affecting multiple workstreams; single workstream decisions (e.g., inspector training curriculum) by that Deputy Director with CFO sign-off for >USD 10M. Executive Director holds tie-breaker vote if consensus cannot be reached within 7 business days. All CPT decisions documented with written rationale; decisions >USD 25M require CFO and Risk Officer joint approval. Monthly CPT coordination meetings (Mondays 9am CET, standup format) to synchronize workstream progress and identify cross-cutting risks.

**Meeting Cadence:** Weekly Deputy Director coordination meetings (Mondays); monthly full-CPT meetings with PSC chair and Technical Panel chair (Fridays); quarterly financial and risk reviews (CFO + Risk Officer + Executive Director). Workstream-specific meetings (containment, breeding, alternatives, smallholder, governance) at least bi-weekly. Annual all-hands with PSC and Technical Panel (Month 12 = 2027-10-08 of each year, after Q4 reporting).

**Typical Agenda Items:**

- Workstream milestone tracking: progress vs. Months 0-X schedule; slippage alerts (>4 weeks) and corrective actions
- Financial status: committed and disbursed capital by pillar, burn rate vs. forecast, upcoming tranches, reserve account balances
- Risk escalations from workstream leads: biological delays, capacity-building shortfalls, offtake commitment gaps, smallholder adoption rates, governance disputes
- Funder and producer-government requests or concerns: political pressures, budget realignment, strategy questions
- Technical Panel secretariat workload: gate evidence compilation deadlines, conflict-of-interest certifications, appeals or disputes in queue
- Quarterly audit findings: inspection records, hub capex, benefit-sharing payments, loan portfolio performance, misconduct allegations
- Contingency planning updates: outbreak-response protocol drills, emergency cultivar deployment pathway, funding-gap cascade readiness

**Escalation Path:** CPT decisions or milestones affecting gate schedules or tranches >USD 100M escalate to PSC within 5 business days of discovery. Conflicts between workstreams (e.g., breeding vs. alternatives over resource allocation) escalated to Executive Director for mediation; if unresolved in 7 days, escalated to PSC chair. Misconduct allegations or corruption risks escalated to Chief Risk & Compliance Officer, with potential escalation to PSC Audit Committee (if established) or external law enforcement. External-party complaints (producers, funders, farmers, communities) received through whistleblower hotline (externally managed, reported to CPT Risk Officer and PSC annually).
### 3. Technical Panel

**Rationale for Inclusion:** Specialized independent assurance body required to assess gate evidence and recommend stage-gate decisions (Months 36, 84, 144, 216 = 2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08) on objective, technocratic grounds insulated from political and commercial interests. The program gates USD 4.5B-19.5B tranches on KPI achievement in three interdependent pillars (containment protocol readiness, resistance-cultivar readiness, alternative-rubber cost/quality). Gate decisions must be credible to funders, producer governments, and OEMs; perceived capture by any faction (e.g., breeding institutes over alternatives, producers over OEMs) would undermine funder confidence and trigger early exits. Panel conducts independent technical assessment, publishes reasoning, and participates in appeal processes; PSC retains final authority.

**Responsibilities:**

- Assess evidence for each stage gate (Months 36, 84, 144, 216 = 2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08) against Technical Gate Charter KPI thresholds: scoring gate attainment (% of criteria met), identifying evidence gaps, flagging interpretation disputes, and recommending tranches (full, partial, or withheld)
- Conduct Containment Efficacy Review during Months 72-84 (2032-10-08 to 2033-10-08): audit ≥50 documented suspect detections logged by Month 84 (2033-10-08), verify laboratory confirmations, assess whether protocol is functionally preventing undetected incursions; escalate if <20 detections by Month 72 (2032-10-08) or zero by Month 60 (2031-10-08)
- Monitor and report on Virulence Gates (Months 24, 36, 48, 60 = 2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08): assess whether candidate cultivars are resistant to contemporary SALB isolates under high-containment testing, recommend hold or advance for each candidate, and flag resistance-gene pyramiding gaps
- Review climate-shock stress scenarios at Years 7 and 12 gates: model alternative-rubber cost/quality outcomes under drought (2-in-20-year rainfall) and flood (2-in-50-year event) scenarios; assess whether supply diversification goal remains viable under stress
- Publish gate evidence packages 60 days before each decision: compile all supporting data, trial results, cost analyses, adoption rates, and CPT/workstream assessments into a public document; flag methodological caveats, data gaps, and Panel dissents
- Administer gate appeals process: receive written challenges to Panel recommendations within 30 days of publication; convene appeal review (Panel subset + neutral mediator) within 14 days; produce written appeal decision within 60 days, escalating unresolved disputes to PSC or arbitration
- Provide technical advice to PSC and CPT on scientific and regulatory matters: pathway viability, risk prioritization, timing feasibility, emerging technologies relevant to breeding, containment, or alternatives

**Initial Setup Actions:**

- Establish Panel composition and recruit members by Month 3 (2027-01-08): 7-9 members selected for expertise (plant breeding/genetics, plant pathology, phytosanitary standards, agricultural economics, smallholder finance, supply-chain analysis) and independence from funders, producers, OEMs, and breeding consortia; publish roster with CVs and conflict-of-interest certifications
- Adopt Panel Standing Rules by Month 2 (2026-12-08): specify decision procedures (majority vote on recommendations), confidentiality of deliberations (not final reasoning), publication of recommendations with dissent statements, conflict-of-interest recusal rules, and term limits (5-7 years, no reappointment)
- Establish Panel secretariat and working groups by Month 3 (2027-01-08): hire 2-3 FTE technical staff to compile evidence, coordinate with CPT workstreams, manage documentation, and support appeals; establish working groups for each pillar (containment, breeding, alternatives) or special topics (virulence, climate, finance)
- Commission gate-evidence data architecture by Month 1 (2026-11-08): specify data-submission templates, quality standards, and timelines from CPT workstreams to Panel secretariat (submission by Month 50 = 2030-12-08, Month 80 = 2033-06-08, Month 140 = 2038-06-08, Month 212 = 2044-06-08 for gates at Months 36, 84, 144, 216 = 2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08, allowing 60-day Panel review)
- Draft interpretation guidelines for KPI thresholds by Month 6 (2027-04-08): clarify what constitutes 'verified containment,' 'cultivar readiness,' 'cost parity,' and 'smallholder adoption' so that evidence assessment is transparent and disputes minimized

**Membership:**

- Chair (independent plant scientist, rotation every 2-3 years among Panel members, selected by Panel vote)
- Plant geneticist/breeder (5+ years resistance breeding, independent of commercial breeding consortia)
- Plant pathologist (epidemiology and virulence tracking, independent of supplier interests)
- Phytosanitary regulation expert (IPPC, regional standards, compliance assessment, independent of national governments)
- Agricultural economist (cost-benefit analysis, commodity markets, finance structures, independent of industry)
- Smallholder agriculture specialist (adoption dynamics, rural livelihoods, microfinance, independent of lenders)
- Supply-chain resilience analyst (tire supply, procurement risk, OEM perspectives, independent of manufacturers)
- Optional 8th or 9th member: emerging topics (climate-adaptation specialist, food security, or additional geography/sector expertise)

**Decision Rights:** Panel makes formal recommendations to PSC on gate evidence sufficiency and KPI attainment (full, partial, or withheld tranches). Panel does not hold veto over PSC decisions; PSC may override Panel recommendation with supermajority vote and published reasoning, but such overrides are rare and damage program credibility. Panel has authority to publish dissent statements if members strongly disagree with majority recommendation. Panel can demand data or audits from CPT workstreams within 30 days if evidence quality is questioned. Panel holds authority to declare a gate 'insufficient evidence' and recommend deferral (up to 6 months) if data quality or completeness is inadequate.

**Decision Mechanism:** Majority vote (≥4 of 7-9 members) to recommend gate outcome (full, partial, or withheld). Dissenting members publish short written dissent (500 words max) alongside majority recommendation. If vote is tied (rare, odd number of members preferred), Chair votes; if still tied after Chair vote, Panel convenes emergency meeting and votes again with 2-week deliberation. All Panel deliberations and draft recommendations confidential (not published), but final recommendation and dissents public. No Panel member may have financial interest in outcome (e.g., employment at breeding institute, seat on OEM board, investment in processing hub); conflict-of-interest recusal enforced by Panel secretariat.

**Meeting Cadence:** Monthly standing meetings (first Tuesday of each month) for routine workstream updates and emerging-risk discussion. Intensive gate-assessment meetings 6-8 weeks before each gate decision (i.e., Months 28-32 = 2029-02-08 to 2029-06-08, 76-80, 136-140, 208-212 = 2029-04-08 to 2029-08-08, 2032-06-08 to 2032-10-08, 2037-10-08 to 2038-02-08, 2043-10-08 to 2044-02-08): weekly 4-hour data-review sessions. Final gate-recommendation vote 2 weeks before public evidence release (i.e., Months 34, 82, 142, 214 = 2029-08-08, 2033-08-08, 2038-08-08, 2044-08-08). Ad-hoc meetings if urgent technical questions arise (e.g., pathogen virulence alert, unexpected cost overrun).

**Typical Agenda Items:**

- Workstream progress reports from CPT: containment protocol adoption status, breeding trial results, alternative-rubber cost and quality data, smallholder adoption rates
- Data quality and completeness review: flagging missing data, methodological concerns, outliers; requesting re-analysis or clarification from CPT
- Gate-assessment preparation (during intensive gate-windows): synthesis of evidence against KPI thresholds, preliminary scoring, dissent identification, recommendation drafting
- Virulence Gates (Months 24, 36, 48, 60 = 2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08): quarterly pathogen genomics reports, candidate-cultivar resistance assessments, hold/advance recommendations
- Climate-scenario modeling (Months 60-84, 2031-10-08 to 2033-10-08 for Year 7 gate): stress-testing alternative-rubber economics under drought, flood, temperature-shift scenarios
- Appeals and disputes: review of formal gate-appeal submissions within 30 days of evidence release; preliminary mediation attempts before escalation to PSC
- Panel-governance matters: conflict-of-interest certifications (annual), term-limit tracking, recruitment of new members (as terms expire), Standing Rules updates

**Escalation Path:** Panel recommendations disputed by PSC or funders within 30 days of publication escalate to PSC extraordinary meeting for discussion; if unresolved, disputes go to independent arbitration (UNCITRAL or ICC). If Panel detects evidence fraud or major data quality issues, escalation to PSC Audit Committee or external law enforcement. If Panel believes gate decision should be deferred due to insufficient evidence, formal recommendation to PSC may include deferral proposal; if PSC overrides and approves tranches anyway, Panel may publish formal dissent explaining the risk.
### 4. Compliance and Ethics Committee (CEC)

**Rationale for Inclusion:** Specialized assurance body required to ensure comprehensive compliance oversight of a $30 billion public-private program spanning multiple sovereigns, sensitive genetic-resource access (Nagoya Protocol), phytosanitary enforcement in weak-capacity countries, and smallholder finance vulnerable to diversion. CEC monitors GDPR, Nagoya Protocol, ethical standards (benefit-sharing, indigenous rights, environmental stewardship), anti-corruption (bribery, embezzlement, nepotism), and sanctions/money-laundering risks. Program scale, cross-border operations, and high-profile nature invite scrutiny; weak compliance invites funding withdrawal, legal challenges, and geopolitical backlash. CEC provides independent assurance that the program operates ethically and legally.

**Responsibilities:**

- Oversee Nagoya Protocol and genetic-resource access compliance: verify that Brazil-led bio-prospecting follows access-and-benefit-sharing agreements with Brazilian states and indigenous organizations; audit annual royalty and community-payment disbursements; review new collection authorizations before proceeding; manage dispute resolution with communities claiming inadequate benefits
- Monitor phytosanitary enforcement for corruption and bribery: conduct quarterly unannounced audits of ≥10 border and nursery inspection checkpoints, including record review, personnel interviews, and sample-integrity verification; escalate any evidence of bribe-taking or falsified inspection records to national law enforcement
- Administer smallholder-finance integrity: audit 5-10% statistical sample of replant loans annually, verifying disbursement, end-use, clean-plant purchasing, repayment, and loan-fraud indicators; flag diversions and recovery actions to CPT; assess whether surveillance premiums are paid and verified within 30 days as promised
- Conduct Technical Panel conflict-of-interest oversight: verify annual certifications from all Panel members and PSC members for financial interests in breeding consortia, OEM boards, processing operators, or lenders; maintain recusal register and enforce recusals during gate assessments; publish sanitized roster of interests annually
- Manage whistleblower program and integrity hotline: administer externally managed anonymous reporting channel for allegations of corruption, fraud, misconduct, or ethics violations; log all reports; initiate investigations; publish annual summary of reports received, investigations opened, and outcomes (without compromising confidentiality)
- Ensure GDPR and data-protection compliance: oversee handling of personal data from smallholder loan records, inspector identity, indigenous-community benefit-sharing records, and any genetic sequencing data; ensure data-minimization, consent, and secure storage; conduct annual privacy-impact assessments
- Audit alternative-rubber hub capex and procurement: post-construction audits verify that hub capex matches invoices, procured equipment is installed and functional, and actual cost is within ±10% of budget; flag any inflated invoices, phantom suppliers, or diverted materials

**Initial Setup Actions:**

- Establish CEC membership and hire staff by Month 2 (2026-12-08): 5-7 members including Chair (external hire, not from funders/producers/OEMs), Nagoya Protocol specialist, anti-corruption/investigative expert, data-protection officer, and auditor; hire 4-6 FTE investigation and compliance staff
- Establish externally managed whistleblower hotline by Month 1 (2026-11-08): contract with Transparency International or similar NGO for anonymous reporting, investigation support, and confidentiality protection; publicize hotline widely to inspectors, farmers, communities, and staff
- Adopt Compliance and Ethics Charter by Month 1 (2026-11-08): specify authority, independence, investigation procedures, confidentiality protocols, mandatory reporting to law enforcement for criminal allegations, publication of annual reports
- Develop inspection-checkpoint audit protocol by Month 1 (2026-11-08): define unannounced audit procedures, record-review standards, sample-integrity testing, personnel interviews, and escalation thresholds for suspected fraud
- Commission Nagoya/ABS benefit-sharing audit framework by Month 1 (2026-11-08): specify royalty-tracking mechanisms, community-payment verification, and dispute-resolution procedures; coordinate with Brazil-led benefit-sharing team

**Membership:**

- Chair (independent compliance professional, 10+ years experience in development finance, anti-corruption, or international governance, external to all funders and implementers)
- Nagoya Protocol and Genetic-Resource Specialist (ABS compliance, indigenous-rights law, benefit-sharing auditing)
- Anti-Corruption and Investigative Expert (forensic accounting, fraud detection, law-enforcement liaison)
- Data Protection Officer (GDPR, privacy impact assessment, secure data handling)
- Senior Auditor (financial audit, procurement, capex verification, asset tracking)
- Field Compliance Coordinator (field monitoring, checkpoint audits, smallholder-community liaison, based in or rotating through key regions)

**Decision Rights:** CEC has authority to initiate investigations of suspected misconduct, issue compliance findings and corrective-action orders to CPT and PSC (binding if not overridden within 30 days by PSC supermajority), require CPT to suspend activities pending investigation (e.g., halt inspector payment if bribery suspected, freeze loan disbursements if fraud detected), and recommend removal or recusal of individuals from governance roles or decision-making. CEC does not have authority to override programmatic decisions (gates, funding), but can flag compliance risks to PSC. Criminal allegations are automatically reported to relevant national law enforcement without awaiting PSC approval.

**Decision Mechanism:** CEC issues compliance findings and corrective-action orders by majority vote (≥3-4 of 5-7 members). If CEC Chair believes investigation is urgent (e.g., active bribery, data theft), Chair may act unilaterally with written rationale and CEC ratification within 7 days. All CEC findings published to PSC and CPT within 14 days of investigation close, with sensitive details (ongoing criminal investigation, confidential sources) redacted in public summaries. CEC recommendations for individual removal or recusal published with reasoning. Dissenting CEC members may publish short dissent statement alongside majority findings.

**Meeting Cadence:** Monthly CEC meetings (third Thursday of each month, 2 hours) to review compliance status, investigation progress, and emerging risks. Quarterly intensive compliance-review meetings (Months 3, 6, 9, 12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08 of each year, 1-day workshops) synthesizing quarterly audits and developing annual compliance roadmap. Special meetings called by CEC Chair within 48 hours if urgent misconduct allegation received.

**Typical Agenda Items:**

- Whistleblower hotline summary: number of reports received, categories (corruption, fraud, ethics, misconduct), status of investigations, outcomes published (anonymized)
- Compliance audit findings: quarterly checkpoint/inspection audits, benefit-sharing payment verifications, loan-portfolio reviews, hub capex audits; flagging of non-compliance and corrective actions required
- Investigation status updates: active misconduct cases, law-enforcement liaisons, recovery of diverted funds or stolen assets, personnel actions
- Conflict-of-interest certifications: annual review of PSC and Panel member interests, recusal tracking, and roster updates
- Nagoya Protocol and benefit-sharing compliance: royalty accrual tracking, community payment schedules, dispute resolution with communities or indigenous organizations
- Data-protection compliance: GDPR impact assessments, data-handling incidents, privacy-by-design reviews of new IT systems
- Regulatory and legal updates: changes in anti-corruption law, sanctions regimes, phytosanitary regulations affecting program operations

**Escalation Path:** Suspected criminal conduct (bribery, embezzlement, money laundering, fraud) reported to CEC Chair, who initiates investigation and mandatory reporting to relevant national law enforcement within 30 days unless ongoing investigation by authorities takes precedence. CEC corrective-action orders not complied with by CPT within 30 days escalate to PSC for enforcement; if PSC overrides CEC finding, rationale must be published. Serious compliance failures (e.g., widespread bribery, major data breach, genocide/crimes-against-humanity risk) trigger CEC recommendation for program suspension pending external audit or law-enforcement action. Whistleblower allegations of CEC staff misconduct escalate to external auditor or PSC Audit Committee (if established).
### 5. Producer-Country Coordination Forum (PCCF)

**Rationale for Inclusion:** Specialized advisory body required to ensure producer-country institutional capacity building, technology transfer, and sustained compliance with the SALB Containment Protocol. Producer governments (especially weak-link countries in Africa and South Asia) must build phytosanitary inspection capacity, clean-plant nurseries, and research capability over 25 years, or the program fails at handover (Month 216+, 2044-10-08 onwards). PCCF provides a forum for producer governments to coordinate on protocol adoption, share lessons from capacity-building, resolve cross-border disputes (e.g., quarantine-zone boundaries), and ensure that sovereignty and national ownership are respected. Without PCCF, producer countries risk feeling externally imposed-upon, reducing voluntary compliance.

**Responsibilities:**

- Coordinate protocol adoption into national law across ≥15 producing countries: track each country's legislative and regulatory status, identify bottlenecks (e.g., legal review, parliamentary debate), facilitate peer learning between early adopters and laggards, and advocate for legal adoption timelines aligned with Year 3 gate and beyond
- Oversee capacity-building partnerships: monitor effectiveness of twinning arrangements between Brazilian, Southeast Asian, South Asian, and West African phytosanitary institutes; assess inspector training outcomes (certifications issued, retention rates); identify gaps and recommend corrective actions
- Support establishment of clean-plant nurseries and national propagation hubs: coordinate regional standards for certified planting stock, facilitate technology transfer for tissue-culture or hybrid propagation systems, ensure that at least 50% of production capacity is domestically owned and operated by Year 12
- Manage cross-border quarantine coordination: convene producer governments annually to agree on quarantine-zone boundaries, common inspection standards, material-movement rules, and dispute-resolution procedures for disagreements on suspect detections
- Assess producer-country readiness for post-funding handover (Months 216-300, 2044-10-08 onwards): evaluate whether national agricultural agencies, research institutes, and inspection services have the staffing, funding, technical capability, and political commitment to sustain protocol enforcement and cultivar development after external funding ends; recommend areas needing pre-handover strengthening
- Advise on smallholder adoption and community engagement: liaise with farmer organizations and indigenous communities in each country to understand adoption barriers, cultural factors affecting compliance, and benefit-distribution mechanisms; recommend country-specific adjustments to replant finance and surveillance-premium structures

**Initial Setup Actions:**

- Establish PCCF secretariat and membership by Month 1 (2026-11-08): host secretariat within one of the major producing-country research institutes (CEPLAC/Brazil, IRRDB/Thailand, or rotating host); membership = ministry-of-agriculture representatives or rubber-research-institute directors from ≥15 producing countries, with rotating annual chair
- Establish capacity-building framework and twinning partnerships by Month 2 (2026-12-08): map existing phytosanitary institutes and research infrastructure in each country; identify priority capacity gaps (inspectors, labs, nursery managers); negotiate twinning arrangements between Brazilian institutes and partners in Asia, Africa, Latin America (target: 3-5 twining pairs operational by Month 12 = 2027-10-08)
- Commission baseline assessments of producer-country institutions by Month 3 (2027-01-08): external consultant evaluates current inspection coverage, inspector qualification, laboratory diagnostic capability, nursery capacity, and research staffing in each major-producing country; identifies capacity-building investments required to meet Year 3/7/12 milestones

**Membership:**

- Chair (rotating annually among 4-5 lead producer countries: Brazil, Indonesia, Malaysia, Côte d'Ivoire, one additional)
- Representatives from ≥15 producing countries' agriculture ministries or rubber-research institutes (≥1 per country, may rotate)
- Technical advisors from regional plant-protection organizations (ASEAN, ECOWAS, Mercosur)
- Liaison officer from CPT (Core Project Team) to bridge to multilateral secretariat

**Decision Rights:** PCCF has authority to make non-binding recommendations to PSC on producer-country capacity timelines, protocol-adoption bottlenecks, and readiness assessments. PCCF consensus position (≥12 of 15 members agree) carries weight in PSC deliberations on gate criteria and timelines; if PSC overrides PCCF consensus, rationale must be published. PCCF can propose amendments to protocol implementation schedules (e.g., delaying Year 3 deadline to Year 4 if capacity-building slips in majority of countries) if supported by ≥75% of members and 2-3 major producers.

**Decision Mechanism:** PCCF makes recommendations by majority consensus (≥75% of members agree, or explicit consensus facilitation if dissent exists). Non-binding recommendations published to PSC and CPT within 30 days. Country-specific issues (e.g., one country's legal bottleneck) addressed by PCCF working group of affected producers and technical advisors, with resolution recommendations within 60 days.

**Meeting Cadence:** Annual extraordinary meeting (Month 12 = 2027-10-08 of each calendar year, January February) with all members and CPT leadership; quarterly coordination calls among PCCF chair, deputy, and CPT liaison (Months 2, 5, 8, 11 = 2026-12-08, 2027-03-08, 2027-06-08, 2027-09-08 of each calendar year, January February, April May, July August, October November); ad-hoc working groups convened as needed (e.g., quarantine-zone disputes, capacity-building progress).

**Typical Agenda Items:**

- Protocol adoption status: tracking each country's legislation and regulatory status; identifying bottlenecks (e.g., ministry delays, parliamentary debate); timelines for target achievement
- Capacity-building progress: twinning partnership effectiveness, inspector-training completion, lab diagnostics setup, nursery-network progress
- Cross-border coordination: quarantine-zone boundaries, material-movement rules, inspection standards harmonization, dispute resolution
- Smallholder and community engagement: adoption barriers, cultural factors, benefit-distribution feedback
- Handover readiness (Months 144-216, 2038-10-08 to 2044-10-08): assessments of whether national institutions are ready for post-funding sustainability; identifying pre-handover strengthening needs

**Escalation Path:** PCCF recommendations on protocol adoption or capacity-building timelines disputed by ≥3 producers or PSC escalate to PSC for explicit debate; if PSC overrides consensus, rationale must be published and PCCF may formally dissent. Producer countries deadlocked on quarantine-zone or inspection-standard disputes escalate to PCCF mediation panel (chair + 2 neutral mediators + affected countries) with 30-day resolution timeline; if unresolved, escalates to PSC arbitration. If a major producing country threatens to withdraw from the program or refuses protocol adoption, escalation to political-level dialogue (national heads of state, development-bank presidents) outside PCCF scope.