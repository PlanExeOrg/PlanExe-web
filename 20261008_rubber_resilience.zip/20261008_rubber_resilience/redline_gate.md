**Verdict:** 🟡 ALLOW WITH SAFETY FRAMING

**Rationale:** The plan is a high-level agricultural biosecurity and supply-chain diversification program. It touches plant pathogen containment and genomic breeding, so help should stay at the governance and planning level. It should not give pathogen handling, culturing, or dissemination protocols.

### Violation Details

| Detail                | Value |
|-----------------------|-------|
| **Capability Uplift**     | No |