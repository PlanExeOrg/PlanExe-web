Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 14 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 4 | Material risk with plausible path. |
| ✅ Low | 2 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is an agricultural supply-chain diversification and crop-breeding program combining phytosanitary governance, conventional genomic selection, alternative-crop commercialization, and smallholder finance. All mechanisms—pathogen surveillance, marker-assisted breeding, crop processing, price-support contracts, and auditor verification—are ordinary physical or institutional practices with no violation of named physics laws or dependence on non-physical causation.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of six interdependent elements—binding IPPC protocol + enforcement + smallholder reporting, conventional breeding with Month-84 cultivar readiness + cost parity, Guayule/dandelion processing + OEM offtake, smallholder adoption at 45% uptake, and 25-year funding durability through sovereign + levy frameworks—none of which have integrated precedent at comparable scale. Breeding alone faces yield-parity uncertainty unvalidated in multi-source Hevea crosses; alternative-rubber cost targets are unproven at commercial scale (Bridgestone and Continental pilots do not report production costs); smallholder adoption targets (45%) exceed historical norms (20–40%, not verified) without baseline validation; and 25-year sovereign funding commitment durability is unproven (precedent shows 60–70% erosion by Year 10, not verified). Core failure modes—ABS slip beyond Month 12 (2027-10-12) moves Year 7 gate to Month 96+; cost failure at Month 60 (2031-10-12) strands USD 1.6B plant capex; adoption below 25% by Month 54 (2031-04-12) triggers USD 0.8–1.2B reallocation; funding defection withholds USD 7B tranches—are plausible (20–40% individual risk) and cascade across the system.

**Mitigation**: Establish four parallel validation tracks with gate-specific deliverables: (1) Protocol/Governance: Binding bilateral MoUs signed with Brazil, Indonesia, Thailand, Malaysia, Vietnam by Month 6 (2027-04-12) with legal embedding timelines and penalty schedules, plus IPPC adoption vote (Month 36 = 2029-10-12). (2) Breeding: Pre-register cultivar-readiness KPIs and durability-test protocols by Month 6 (2027-04-12) in peer-reviewed document; establish Resistance Durability Oversight Panel by Month 1 (2026-11-12); field trials at 4 sites planted by Month 12 (2027-10-12); independent auditor validation of yield ≥90% elite clones with 3+ stacked sources by Month 84 (2033-10-12). (3) Alternative Rubber: Commission independent cost-down roadmap by Month 6 (2027-04-12); pilot Guayule (2,000 t/year) and dandelion (1,000 t/year) by Month 24 (2028-10-12); report pilot costs by Month 48 (2030-10-12); secure 8 of 10 OEM purchase-option contracts by Month 60 (2031-10-12); authorize wave 1 plant FID only after Month 60 (2031-10-12) cost targets verified. (4) Smallholder Adoption: Conduct baseline willingness-to-adopt survey (2,000–5,000 farms per country) by Month 6 (2027-04-12); pilot bridging finance on 10,000 smallholders Months 12–36 (2027-10-12 to 2029-10-12) to measure actual default and repayment rates; set adoption waypoint 30% enrolled by Month 84 (2033-10-12) with stop trigger <25% by Month 54 (2031-04-12); reallocate USD 0.8–1.2B if shortfall confirmed. Define two binding NO-GO gates: (1) Empirical/Engineering Validity: If breeding yield <90% of elite at Month 48 (2030-10-12), activate crown-budding fast-track or fail gate; if alternative-rubber feedstock exceeds USD 1.20/kg (Guayule) or USD 1.00/kg (dandelion) at Month 48 (2030-10-12), or extraction yield is below 85% (Guayule) or 80% (dandelion) at Months 36 and 60 (2029-10-12, 2031-10-12), reallocate wave 1 capex; (2) Legal/Compliance Clearance: If binding framework agreements are not locked by Month 12 (2027-10-12) or fewer than 3 of 5 producers have binding adoption by Month 54 (2031-04-12), defer Phase 2 or re-scope. Owner: Program Governance Manager and independent auditor. Deliverables: (1) Protocol track: executed MoUs + binding embedding timelines + IPPC vote outcome by Month 36 (2029-10-12); (2) Breeding track: peer-reviewed KPI protocol + 4-site trial data + Year 7 auditor verdict by Month 84 (2033-10-12); (3) Alt Rubber: pilot cost data + OEM offtake contracts + wave 1 FID decision by Month 60 (2031-10-12); (4) Adoption: baseline survey + pilot finance results + enrollment status by Month 36 (2029-10-12) + Month 84 (2033-10-12) waypoint. Timeline: all gates gated at Months 6, 12, 36, 48, 60, 84 (2027-04-12 to 2033-10-12) with no-go triggers documented in binding steering-council decision rules by Month 6 (2027-04-12).


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan names 14 strategic decisions with trade-off analysis and gate KPIs, but mechanism-of-action is incomplete. Decisions 1–5 (protocol, breeding, portfolio, gates, capital) define clear inputs→process→value chains and measurable outputs. However, Decisions 6–14 lack explicit owner assignment in the strategic-decisions.md file and do not articulate how each choice (e.g., "IP posture," "surveillance architecture," "extension delivery") causally drives adoption or resilience outcomes. Secondary decisions read as catalogues of options, not as strategies with defined mechanisms and success metrics.

**Mitigation**: Strategy owners: Assign Decision 1–14 accountable owners (named by Month 3 = 2027-01-12) and publish mechanism-of-action one-pagers (3–5 pages each, by Month 6 = 2027-04-12) defining inputs→process→customer value in causal language, KPI thresholds tied to gate outcomes, and decision trigger rules for pathway switches.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan acknowledges 18 named risks (institutional adoption, breeding durability, alternative-crop cost, funding volatility, smallholder uptake, ABS disputes, contaminated supply chains, gate verification independence, incursion detection, climate stress, processing viability, and geopolitical shocks) but lacks concrete, pre-committed cascading controls tied to measurable decision triggers. The risk register is descriptive (e.g., "if breeding yield <90%, activate crown-budding; if adoption <25%, reallocate $800M") but those contingency actions are not locked in advance—they require future steering-council approval, creating delay and political contestation when crises occur. Most critically, second-order cascade risks are named but not quantified or controlled: e.g., "if protocol adoption stalls, surveillance capacity erodes, undetected SALB incursion cascades to failed containment gates and withheld $7B tranches"—yet there is no binding stop-rule pre-deciding what happens if fewer than 3 producers adopt by Month 54 (2031-04-12), nor any pre-committed fallback authority. Similarly, smallholder adoption failure ($800M–$1.2B reallocation trigger) lacks a binding governing rule and depends on discretionary Month 84 (2033-10-12) re-scoping after capital is already committed. Financial cascade risk (e.g., levy erosion → capital shortfall → Phase 2 deferral) has no pre-positioned contingency reserve mechanism or binding gate-closure rule. The plan states "if X, then Y" in narrative form but does not execute binding governance structures (adjudication panels, decision authorities, pre-approved fallback pathways) that would enforce contingency response when uncertain events occur."

**Mitigation**: Establish a Contingency Governance Framework with binding decision rules by Month 6 (2027-04-12): (1) Pre-commit stop rules (e.g., "fewer than 3 binding producer-nation MoUs by Month 54 = 2031-04-12 → defer Phase 2 or re-scope protocol scope to compliant producers alone"; "breeding yield <85% at Month 48 = 2030-10-12 → activate USD 0.25B crown-budding fast-track without further steering approval"). (2) Lock cascading-failure controls: if protocol adoption stalls → immediately trigger surveillance surge in at-risk regions; if breeding gap widens → reallocate $300–500M from alternative crops to breeding by Month 60 (2031-10-12); if smallholder enrollment <25% by Month 54 (2031-04-12) → execute pre-approved $800M–$1.2B reallocation with no further steering-council vote. (3) Bind the Dispute-Resolution Adjudication Panel (Month 3 = 2027-01-12) with explicit authority to invoke contingency funds (draw up to USD 1.5B from the USD 4.5B reserve without annual funder approval) if documented shocks occur. (4) Publish the contingency rulebook and decision trees as binding steering-council charter (Month 6 = 2027-04-12), with named deputy authorities empowered to act if primary decision-makers are unavailable. (5) Quarterly compliance dashboards that flag cascade-trigger proximity (e.g., "protocol adoption at 1.5 of 3; trajectory suggests risk of <3 by Month 50 = 2030-12-12") so corrective action can start 3–6 months before the hard trigger. Owner: Program Governance Manager + Dispute-Resolution Panel + Steering Council Legal Counsel. Timeframe: design by Month 3 (2027-01-12), publish and socialize by Month 6 (2027-04-12), operationalize by Month 12 (2027-10-12)."


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the ABS germplasm-access timeline is compressed by >20% relative to documented Nagoya Protocol negotiation precedent (6 months scheduled vs. 12–36 months typical); a permit/approval matrix is absent, leaving IPPC consensus-building, OEM tire-qualification, national legislative embedding, and environmental-permitting lead times undocumented and unbuffered; and critical predecessors (ABS → germplasm → trial planting → Year 7 gate → adoption rollout) are mapped but have zero slack, so any slip cascades 12–18 months downstream. The plan explicitly acknowledges "zero slack to the Year 7 gate" yet provides no pre-committed contingency authority or timeline-recovery mechanism beyond the non-binding crown-budding option.

**Mitigation**: Program Governance Manager and Legal Counsel: Develop and publish a detailed Permit and Approval Matrix by Month 3 (2027-01-12), documenting lead times for Brazil CGen ABS approval (target 9 months, not verified), IPPC consensus-building and adoption vote (24 months), OEM tire-qualification labs (18–36 months per lab), national legislative embedding (12–24 months per producer), and environmental/processing-plant permits (18–36 months). Lock ABS preliminary-scope agreements with CGen and 3 community groupings by Month 3 (2027-01-12) to reduce negotiation variance. Pre-commit crown-budding fast-track approval authority by Month 18 (2028-04-12) so a germplasm-transfer slip can immediately activate fallback without further steering-council deliberation. Establish a Critical-Path Steering Subcommittee to flag timeline compression signals quarterly from Month 6 (2027-04-12) onward.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because committed funding sources with binding term sheets and disbursement mechanics do not exist as of Month 0 (2026-10-12). Framework agreements are "due" by Month 12 (2027-10-12) but are not signed; the industry levy (USD 3.7B, ~12% of cap) depends on voluntary OEM participation with no binding multi-year commitment documented; sovereign commitments lack contractual minimum-funding floors, 45-day disbursement windows, or force-majeure carve-outs. Gate-conditional tranches (USD 22.0B) are allocation targets, not backed by enforceable release mechanics. Runway is contingent on gate passage (estimated 20–30% gate-dispute risk creates 3–6 month capital-flow delays). No independent commitment letter from any major funder (World Bank, ADB, AFDB, sovereign) is provided.

**Mitigation**: Finance Director: Execute legally binding 25-year framework agreements with at least 5 sovereign/institutional funders (none above 20%) and a binding industry-levy agreement (10-year minimum, 0.75% of natural-rubber purchases) with enforcement penalties (5–10% tranche forfeiture for early withdrawal) by Month 12 (2027-10-12). Agreements must specify gate-release mechanics (minimum 80% tranche on partial gate success), 45-day mandatory disbursement, force-majeure carve-outs (12-month postponement, not cancellation), and binding dispute-resolution adjudication (60-day judgment). Lock commitments in writing before Month 6 (2027-04-12) budget baseline to enable Phase 2 planning.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated alternative-rubber budget conflicts with unit economics: commercial plants face USD 9.6 million annual operating shortfall at full operation (USD 70.4M revenue vs USD 80.0M opex) even at 10% price premium, and processing-cost targets (USD 2.50/kg all-in) remain unvalidated at scale. Pilot data (feedstock, extraction yield, quality variance) are not yet available; cost KPI waypoints at Months 36, 48, 60 (2029-10-12, 2030-10-12, 2031-10-12) show no evidence that targets will be met. OEM offtake is conditional on tire qualification (Months 12–48 = 2027-10-12 to 2030-10-12) with no binding commitment until Month 60 (2031-10-12), leaving demand uncertain. The USD 1.6 billion plant capex assumes 100% program financing with no contingency if commercial viability fails; illustrative debt financing (50%, 6%, 12-year terms) yields negative DSCR (~−0.1, not bankable). No comparable commercial-scale Guayule or dandelion rubber plants with published operating costs exist; Bridgestone and Continental pilots do not report unit economics, so cost credibility is absent.

**Mitigation**: By Month 6 (2027-04-12), commission independent cost-down roadmap from 3 technology partners specifying feedstock, extraction yield and all-in processing targets at Months 36, 48, 60 (2029-10-12, 2030-10-12, 2031-10-12); normalize delivered cost per kg for the 5,000 t/year plant model; report pilot extraction and feedstock-cost data; secure written OEM acceptance of price premium (minimum 8 of 10 OEMs) by Month 48 (2030-10-12); stage plant FID only after Month 60 (2031-10-12) cost-target verification, or reallocate wave 1 USD 0.8 billion capex to breeding or defer plants.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan's eight critical projections (cultivar yield at Year 7, smallholder adoption at 45%, alternative-rubber cost under 30% above Hevea, funding durability over 25 years, producer-nation adoption by Month 36 = 2029-10-12, incursion detection within 3–6 months, breeding timeline at zero slack, and OEM premium at 10% sustained) are presented as single-point targets or binary gate criteria without confidence intervals, sensitivity ranges, or pre-registered alternative scenarios. The main gate structure (Months 36/84/144/216 = 2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12) treats projections as point estimates; contingency scenarios are documented in secondary files (assumptions.md, premortem.md) but are not integrated into binding gate-release rules or pre-committed contingency-capital allocations. This one-sided framing creates two risks: (1) optimism bias—the plan may overcommit capital to a baseline scenario that has 20–40% failure probability (estimated) at each gate; (2) gate contestation—if results fall just short of thresholds (e.g., 85% yield instead of 90%, 32% cost instead of 30%), no pre-agreed pass/fail rule exists, creating 3–6 month capital-delay risk while auditors and funders dispute the verdict.

**Mitigation**: By Month 6 (2027-04-12), develop and publish a Sensitivity and Scenario Analysis document specifying: (1) Three explicit scenarios (conservative 30–40%, baseline/planning 45%, optimistic 60%+) for smallholder adoption with costed contingency tranches attached to each. (2) Monte Carlo sensitivity analysis (1,000 iterations) for the four critical cost projections (cultivar breeding, alternative-rubber feedstock, processing, OEM premium), showing confidence intervals (70%, 90%) and identifying the cost drivers with highest variance. (3) Pre-registered conditional-pass rules for gate thresholds, e.g., "Year 7 cultivar yield 90–95% of elite = conditional pass, release 80% of tranche (minimum, proposed) pending 2-year durability monitoring; 95%+ = full pass; below 90% = fail." (4) Explicit worst-case/stress scenarios tied to each gate (e.g., "Year 3 gate: 2 of 5 producers binding + 2 on delayed track = defer Phase 2 by 12 months; Year 7 gate: breeding yield at 85% + alternative cost at 35% above Hevea = reallocate USD 1.5–2.0B from alternative to breeding and/or extension"). Owner: Program Governance Manager and Risk Lead. Deliverable: published Scenario Analysis Framework (5–10 pages, with decision rules locked in steering-council charter by Month 6 = 2027-04-12). Timeframe: complete analysis and pre-register contingency-capital allocation by Month 12 (2027-10-12).


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because core build-critical components (processing plants, surveillance sensing architecture, clean-plant nurseries, gate-verification infrastructure) lack formal engineering specifications, interface contracts, acceptance tests, and integration plans. Processing plants are specified at the outcome level (5,000 t/year, delivered cost under 30% above Hevea by Month 144 = 2038-10-12) but have no equipment designs, process P&IDs, performance acceptance criteria, or integration test protocols with feedstock and OEM offtake systems. Surveillance architecture identifies tiers (inspectors, labs, sentinels) and detection latency targets (3 months primary, 6 months secondary) but provides no sensor specifications, false-positive thresholds, data-interface standards, or end-to-end integration testing. Breeding trials specify site locations, trial designs, and yield targets but lack formal acceptance criteria for cultivar advancement or resistance-durability test procedures. Finance and extension systems are described operationally (500 agents, 10,000 pilot farmers, USD 3,000/ha replant cost) without formal interface definitions between extension, finance, nursery, and audit systems or acceptance criteria for agent competency or farmer enrollment. Moderate gaps remain in formal engineering depth for field-scale systems.

**Mitigation**: Engineering Depth Lead: Develop formal specifications and interface definitions for each build-critical component by Month 9 (2027-07-12): (1) Processing Plants—produce equipment designs, process flow diagrams, performance acceptance tests (extraction yield 85%+, quality variance <10%), and integration plan with feedstock suppliers and OEM shipping; (2) Surveillance Architecture—define sensor types, detection protocols, data-interface standards, latency and false-positive requirements, laboratory diagnostic SOPs, and end-to-end integration test schedule; (3) Breeding Trials—formalize cultivar-advancement criteria (yield measurement protocols, resistance-test procedures at 10x inoculum), resistance-durability monitoring plan, and site-manager competency standards; (4) Finance and Extension—specify lot-tracking interface (between nurseries, agents, and finance systems), farmer-enrollment data schema, and performance-acceptance criteria for agent certification. Deliverables: technical specifications (10–20 pages per component) with owners and delivery dates locked in steering-council decision rules by Month 9 (2027-07-12).


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes 11 critical legal/contract/operational claims—binding producer-nation MoUs by Month 6 (2027-04-12), 25-year funding framework agreements by Month 12 (2027-10-12), industry-levy commitment, executed ABS agreements, auditor contracts, OEM offtake letters, IPPC protocol draft, governance-panel charters, and baseline smallholder-adoption survey—each a gate prerequisite, yet no verifiable artifacts (executed documents, signed agreements, committed letters) exist. Missing evidence creates cascading gate-failure risk: no MoUs → Month 36 (2029-10-12) phase fails; no framework agreements → capital is withheld; no ABS agreements → breeding trials cannot plant by zero-slack Month 12 (2027-10-12). Plan explicitly states that missing these commitments by stated deadlines triggers re-scoping or gate deferral.

**Mitigation**: By Month 3 (2027-01-12), obtain and publish: (1) Executed bilateral Protocol-Adoption Agreements with Brazil, Indonesia, Thailand with penalty schedules; (2) Draft framework-agreement term sheets from 3+ funders confirming binding minimum-funding floors and 45-day disbursement; (3) Industry-levy participation letters from 4+ OEMs; (4) Executed ABS agreement with Brazil CGen and communities; (5) Auditor engagement letter and governance charter with data-access penalties; (6) Dispute-Resolution Panel charter and member CVs; (7) OEM letters of intent from 5+ makers confirming premium range; (8) IPPC protocol draft for working-group submission; (9) Resistance Durability Oversight Panel charter and member CVs; (10) Baseline smallholder-adoption survey report (2+ countries, 2,000+ farms); (11) Agro-climatic suitability reports for 3+ sites per crop. All due within 90 days. If unsupported by verifiable evidence by Month 12 (2027-10-12), execute formal re-scope reducing affected scope.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan defines four gate-triggered deliverables (Years 3, 7, 12, 18) with mixed specificity. Year 3 and Year 7 gates have quantified KPIs (inspectors, yield, lesion size), but critical operational definitions are missing: "independent" resistance sources lack a genetic threshold; "elite clone" reference sets are unnamed; "Hevea benchmark" is a "placeholder" commodity price undefined at gate time. Year 12 "delivered cost under 30% above Hevea" is ambiguous if the benchmark is unstated; OEM acceptance is named but no formal sign-off (production readiness) is specified. Year 18 "global containment verified," "supply resilience achieved," and "sustained adoption" lack quantified success criteria—zero tolerance for incursions is assumed but not stated; "sustained" adoption has no re-assessment protocol; "resilience" is abstract. These gaps create 3–6 month gate-dispute risk and tranche-withholding exposure of USD 2–3 billion if auditors and funders contest gate verdicts due to ambiguous criteria.

**Mitigation**: Gate Evidence Verification & Independent Audit Director and Program Governance Manager: By Month 3 (2027-01-12), publish a Gate Acceptance Criteria Charter specifying SMART criteria for each of the four gates, including: (1) Year 3: define "binding adoption" as national law plus named agency plus budgeted inspectors, verified by auditor; (2) Year 7: name the elite-clone reference set (4 regional benchmarks) and define "independent" as ≥75% molecular-marker dissimilarity; (3) Year 12: lock the Hevea reference price at Month 84 (2033-10-12) so "30% above" is computed at a defined baseline, and require formal OEM vehicle-production sign-off (not lab data); (4) Year 18: specify zero-incursion tolerance (gate conditional if one unmanaged case occurs), re-assess adoption by farm census, and quantify resilience as two of three metrics (alternative-rubber volume, income stability within ±15%, detection latency <6 months). Attach one quantifiable KPI per deliverable (e.g., cultivar yield ≥90% of elite set, coefficient of variation ≤15% across sites).


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the alternative-rubber pillar (Guayule and dandelion, USD 1.6 billion capex) does not demonstrably support the two core project goals: (1) Verified SALB containment (alternative rubber contributes zero containment; the protocol achieves this alone), and (2) Resilient procurement against shocks (32,000 t/year is 0.2% of the ~14 Mt/year global market, insufficient to offset a 20–30% regional Hevea loss). The investment is framed as a "diversification hedge" and "technology demonstration," but these are post-hoc rationales outside binding project requirements. The capex (USD 1.6B) and complexity (OEM qualification 18–36 months, plant permitting, climate siting, contract-farming ecosystem, negative unit economics USD 9.6M/year shortfall per plant) are significant, and opportunity cost is high: same capital reallocated to breeding durability, adoption contingency, or protocol enforcement would directly strengthen core objectives with documented ROI.

**Mitigation**: Alternative-Rubber Pillar Lead and Finance Director: Produce a one-page benefit case by Month 6 (2027-04-12) justifying the USD 1.6 billion capex against the two core objectives. The case must articulate: (1) A quantified supply-shock scenario (e.g., "30% Hevea loss in [region] by Year 12 is mitigated by X% if alternative rubber reaches Y tonnes/year"), (2) A KPI tied to core objectives (e.g., "reduce global supply concentration Hevea from 90% to 80% by Month 216 = 2044-10-12"), (3) Cost and ownership clarity (program absorbs operating losses, or OEM commits firm offtake at or above breakeven), or else move the alternative-rubber pillar to the project backlog and reallocate USD 1.6B to core containment and breeding priorities.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a Hevea Resistance Breeding Program Director embedded at a Brazil research hub by Month 1 (2026-11-12) who must simultaneously: (1) hold expertise in perennial-crop genomics and multi-site field-trial design; (2) navigate Nagoya Protocol ABS negotiations with Brazil CGen and Amazonian communities; (3) manage 4 international trial sites (Brazil, Thailand, Malaysia/Indonesia, Côte d'Ivoire) with field cycles that do not compress; (4) deliver cultivar-readiness evidence (yield ≥90% of elite clones, ≥3 stacked resistance sources, lesion <5mm) by Month 84 (2033-10-12) with zero slack. This specialization—combining breeding mastery, institutional fluency with ABS law and community governance, and international multi-site leadership—is rare. Supply-side: IRRDB, Embrapa, and university breeding programs have fewer than 50 candidates globally with this profile (not verified). Demand-side: only this program and a handful of perennial-crop resilience initiatives (cocoa, cacao, coffee) seek it. The Resistance Durability Oversight Panel (6 members, including 2 perennial-crop breeders) amplifies the scarcity signal. Recruitment timeline is 3–6 months; failure to hire by Month 3 (2027-01-12) cascades ABS slip and delays trial planting beyond Month 12 (2027-10-12), moving the Year 7 gate to Month 96 (2034-10-12) and orphaning USD 6.5B and smallholder adoption timelines.

**Mitigation**: Program Governance Manager: By Month 1 (2026-11-12), commission a talent-market validation task: survey IRRDB member institutes (Embrapa, Malaysian Rubber Board, Michelin research, university breeding programs) to identify 5–10 candidates with proven Hevea multi-site trial leadership + ABS experience and document their availability, salary expectations, and willingness to commit 7+ years to the program. Obtain written interest commitments or letters from at least 3 candidates by Month 3 (2027-01-12). If fewer than 2 qualified candidates are identified or if interest indicates 6+ month recruitment delay, escalate to the Steering Council by Month 2 (2026-12-12) to decide: (a) co-appoint 2 deputies to share the role, (b) outsource early ABS and trial-design work to a consulting firm while recruiting, or (c) defer Phase 2 breeding until Month 24 (2028-10-12) and rescope the Year 7 gate to Month 108 (2035-10-12). Document the talent market findings in a public report by Month 6 (2027-04-12).


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because a regulatory pathway exists (IPPC embedding in international framework, bilateral producer-nation MoUs, Brazil CGen ABS approvals, national legislative embedding, processing-plant permitting, OEM tire-spec acceptance) and the plan names responsible authorities. However, the roadmap is unmapped in critical detail: IPPC consensus-building timeline lacks a working-group schedule and stall contingency; national legislative embedding pathways are undefined per country; ABS implementation is compressed (Month 6 = 2027-04-12 target vs. 12-36 months historical precedent, not verified); processing-plant permitting lead times across 8 jurisdictions are undocumented; and binding go/no-go decision triggers (e.g., "if IPPC delayed beyond Month 42 = 2030-04-12, defer phase-scale-up or activate fallback") are not pre-committed in governance. These gaps create 6-18 month approval-delay risk that cascades to zero-slack breeding timeline and adoption rollout, withholding USD 7-8 billion in Year 3-7 tranches if major approvals slip or are denied.

**Mitigation**: Legal/Regulatory Coordinator: Publish a detailed Regulatory Approval Matrix by Month 6 (2027-04-12) documenting controlling authorities, lead-time estimates, predecessors, and pre-committed go/no-go decision rules for IPPC adoption (Month 36 = 2029-10-12 vote target; defer phase-scale-up if delayed beyond Month 42 = 2030-04-12), producer-nation law embedding (3+ countries by Month 54 = 2031-04-12; re-scope if fewer), ABS approval (Month 6 = 2027-04-12 target; activate ex-situ fallback if delayed beyond Month 18 = 2028-04-12), processing-plant permits (8 sites by Month 72 = 2032-10-12 FID; defer wave 1 if not initiated by Month 24 = 2028-10-12), and OEM tire-spec acceptance (pre-approval from 2+ OEMs + 3+ importing jurisdictions by Month 60 = 2031-10-12). Establish monthly compliance tracking and escalation protocol for regulatory approvals lagging plan timelines.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan's operational sustainability beyond Year 18 (Month 216 = 2044-10-12) is materially at risk on six fronts: (1) sovereign and industry-levy funding commitments expire at Month 216 (2044-10-12); (2) extension-workforce turnover erodes field capacity (30–50% annual attrition, estimate); (3) price-floor fiscal exposure (USD 50–200M/year if Hevea prices collapse) creates funder withdrawal incentive; (4) processing-plant operating losses (USD 1.2M/year per plant, estimate) perpetuate indefinitely without innovation or margin improvement; (5) OEM offtake price-premium sustainability post-Year-12 is unproven (commodity pressure, margin squeeze); (6) breeding-cultivar durability is monitored only through Year 18, leaving no funded replacement pipeline if resistance breaks.

**Mitigation**: By Month 12 (2027-10-12), lock binding 25-year+ funding commitments specifying: (1) post-Year-18 funding mechanism (renew framework agreements, convert levy to endowment, or secure government budget lines for Months 216–300); (2) extension-staff retention roadmap including career pathways, bonuses, succession planning, and contingency staffing within the USD 400M protected stream; (3) price-floor cap or sunset clause (e.g., floors apply Months 84–216 = 2033-10-12 to 2044-10-12 only, or are phased down 1–2% annually post-Year-12 to reduce fiscal exposure); (4) processing-plant innovation milestones or exit criteria (if operating margin does not reach breakeven by Year 15, divest or refocus on alternative feedstocks); (5) OEM offtake contract renewal triggers (renegotiate prices every 5 years post-Year-12 or include price-floor escalators tied to cost inflation); (6) breed-cultivar durability monitoring plan and funded next-generation resistance breeding pipeline (Months 144–300) funded by contingency reserve or dedicated endowment. Owner: Finance Director, Program Governance Manager. Deliverable: Post-Year-18 Sustainability Plan published by Month 12 (2027-10-12).


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan's physical locations (Amazon, Arizona, Germany, Southeast Asia, Rome) are established agricultural/research zones with known zoning and harmonized phytosanitary frameworks. IPPC embedding eliminates redundant permitting. No occupancy limits, fire-load surprises, or structural constraints are evident. However, agro-climatic (aquifer reserve, drought, frost) and environmental-permitting materialization (Brazil CGen, EU directives, indigenous rights) carry 6–18 month delays if fatal flaws emerge. Mitigation is gated: agro-climatic modeling and permitting readiness by Month 6 (2027-04-12), site confirmation by Month 24 (2028-10-12), no-go thresholds published by Month 12 (2027-10-12), with fallback re-siting (USD 1.0–1.5B climate reserve) or capital reallocation before Month 60 (2031-10-12) portfolio gate.

**Mitigation**: Alternative-Rubber Processing Lead and FAO/IPPC Secretariat: Publish Fatal-Flaw Site Screening by Month 6 (2027-04-12)—agro-climatic modeling, permitting-readiness assessments, land-access letters, no-go thresholds (e.g., groundwater <10 years, yield loss >25%, zoning incompatibility). Confirm all sites by Month 24 (2028-10-12) or activate climate re-siting allocation; reallocate to breeding if 5+ sites fail by Month 18 (2028-04-12).


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the SALB Containment Protocol development and producer-nation binding adoption are non-negotiable Phase 1 deliverables that gate all downstream phases. The critical path compresses multiple sequential dependencies into Months 0–36 (2026-10-12 to 2029-10-12): Protocol Adoption Secretariat recruitment and protocol drafting (Months 0–4, 2026-10-12 to 2027-02-12); bilateral MoU negotiation and signature with Brazil, Indonesia, Thailand, Malaysia, Vietnam (Months 0–6, 2026-10-12 to 2027-04-12); IPPC working-group circulation and consensus-building (Months 3–36, 2027-01-12 to 2029-10-12); formal IPPC adoption vote (Month 36, 2029-10-12). If producer-nation MoU signatures slip beyond Month 6 (2027-04-12), IPPC working-group legitimacy is weakened and adoption vote risk increases. If fewer than 3 of 5 producers sign binding adoption commitments by Month 54 (2031-04-12) (stop threshold), the Phase 1 gate criterion ('binding national embedding in at least 3 of top-5 producers') is unmet, withholding USD 7.0 billion Year 3 tranche. The plan explicitly states zero timeline slack to this gate; re-scope is triggered if adoption lags.

**Mitigation**: Protocol Adoption Secretariat Director (FAO/IPPC, hired by Month 1, 2026-11-12): Execute bilateral Memoranda of Understanding with Brazil, Indonesia, Thailand, Malaysia, Vietnam by Month 6 (2027-04-12), specifying named quarantine agencies, inspector-hiring targets (20+ per country by Month 12, 2027-10-12), quarterly compliance reporting, and enforcement penalties. If fewer than 3 binding MoUs are signed by Month 6 (2027-04-12), activate pre-agreed fallback: regional protocol coalition with compliant producers, with re-scope decision escalated to Steering Council by Month 18 (2028-04-12).


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because Finance and R&D Teams face a plausible unstated incentive conflict: Finance prioritises quarterly budget adherence and near-term gate-release certainty (pressuring Year 7 verdict to Month 72 = 2032-10-12 to lock tranche flow), while R&D requires full 6-year perennial-crop field cycles (Month 84 = 2033-10-12) to prove durability credibly. The conflict is real because tranche release deadlines can conflict with biological maturation timelines; however, it is manageable through a shared OKR pre-committing to a two-step gate (interim Month 72 = 2032-10-12 for funding certainty, final Month 84 = 2033-10-12 for durability proof) and binding framework agreements that de-link annual budgets from 25-year funding commitments. Partial mitigation exists in the current plan's gate structure and binding-agreement intent; material gaps remain in pre-committed OKRs and dispute-resolution procedures for contested verdicts.

**Mitigation**: Program Governance Manager and Finance Director: Co-author and publish a Shared Breeding Readiness and Capital Release OKR (one page) by Month 6 (2027-04-12) that defines: (1) two-step Year 7 gate (interim Month 72 = 2032-10-12; final Month 84 = 2033-10-12); (2) monthly progress dashboard visible to both teams; (3) pre-registered KPI definitions eliminating post-hoc verdict disputes; (4) success tied to both cultivar readiness AND tranche release within 45 days. Lock binding framework agreements with minimum-funding floors by Month 12 (2027-10-12).


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan documents gates, KPIs, and contingency triggers in narrative form but lacks pre-committed, contractually enforceable feedback loops with named owners, binding review cadences, and measurable decision thresholds. Monthly KPI dashboards and quarterly compliance scorecards are proposed (secondary actions) but not locked into a governance charter by Month 6 (2027-04-12). Change-control processes (e.g., "if adoption <25% by Month 54 = 2031-04-12, reallocate $800M") exist as contingency options, not as binding escalation rules. Vague monitoring commitments ("we will monitor") are unacceptable for a $30 billion program with gated tranches; absence of a tight, pre-committed feedback loop creates 3–6 month decision-delay risk and gate-verdict contestation if thresholds breach.

**Mitigation**: Program Governance Manager: Establish and publish a Feedback Loop and Change-Control Charter by Month 3 (2027-01-12) specifying: (1) monthly KPI collection and variance-analysis cadence for each program pillar; (2) named owner (single integrator) for feedback-loop operation; (3) pre-registered decision triggers (e.g., "if breeding yield <85% by Month 48 = 2030-10-12, activate crown-budding by Month 18 = 2028-04-12 without further Steering Council approval"); (4) escalation authority and binding go/no-go decision rules locked in writing; (5) quarterly Steering Council adoption-review meetings starting Month 12 (2027-10-12). Publish the Charter as binding governance by Month 6 (2027-04-12).


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because ≥3 High risks (Protocol Adoption Delay, Smallholder Adoption Shortfall, ABS/Germplasm Access Slip, Alternative-Rubber Cost Failure, Funding Commitment Erosion) are strongly coupled through documented cascading failure modes (9 showstopper scenarios in premortem, 7 rated CRITICAL 15–20/25). Single dependency (ABS execution by Month 12 = 2027-10-12) triggers multi-domain failure: breeding timeline compression (Year 7 gate Month 84 = 2033-10-12→96+), capital withholding (USD 6.5B tranches contested 3–6 months), smallholder adoption stall (Months 36–144 = 2029-10-12 to 2038-10-12 compressed to 48–156), and surveillance erosion (voluntary SALB reporting -20–30%). The plan documents cascades narratively but lacks binding no-go rules, pre-committed contingency authorities, or interdependency bow-tie controls to prevent multi-node failures.

**Mitigation**: Risk Management and Governance Director: Develop and publish Interdependency Map (bow-tie analysis for 5 critical-path clusters: protocol→surveillance→reporting; ABS→breeding→adoption; adoption→enforcement→incursion; cost→offtake→plant capital; funding→gates→phases) with quantified cascade probabilities and pre-committed NO-GO thresholds by Month 6 (2027-04-12). Lock binding Contingency Governance Framework specifying: (1) tripwires (e.g., "if ABS unsigned by Month 9 = 2027-07-12"), (2) response playbooks (e.g., "activate crown-budding fast-track"), (3) stop rules (e.g., "if protocol <3 producers by Month 54 = 2031-04-12, defer Phase 2"). Name contingency owners with pre-delegated decision authority for each cluster. Integrate map into quarterly steering-council dashboard and re-assess cascade risk monthly.