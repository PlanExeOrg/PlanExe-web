
## Documents to Create

### 1. SALB Containment Protocol Authority Charter and Protocol Adoption Roadmap

**ID:** 7b09664a-0397-4530-b582-7693087e772c

**Description:** Formal governance document establishing the institutional home, certification scope, and enforcement authority for the SALB Containment Protocol (non-negotiable Phase 1 deliverable). Defines the Containment Protocol Authority, its harmonization with IPPC/regional standards, inspector hiring and deployment targets (100 inspectors by Month 12 = 2027-10-12), red-team drill protocols, penalty schedule for non-compliance, and producer-nation MoU template with binding adoption timelines (Month 36 = 2029-10-12 gate: binding in 3 of 5 top producers). Primary audience: IPPC Secretariat, producing-nation plant protection agencies, funders.

**Responsible Role Type:** SALB Containment Protocol Director & Phytosanitary Authority Lead

**Primary Template:** IPPC International Standard for Phytosanitary Measures (ISPM) template

**Secondary Template:** Bilateral plant-protection agreement templates (EU-China model, WTO SPS framework)

**Steps:**

- By Month 1 (2026-11-12): Establish Protocol Adoption Secretariat at FAO/IPPC with 3-4 staff; recruit phytosanitary standard-writer
- By Month 3 (2027-01-12): Draft IPPC-harmonized protocol covering nursery stock movement, research-material quarantine, equipment decontamination, red-team protocols
- By Months 3-4 (2027-01-12 to 2027-02-12): Circulate draft to IPPC working groups for formal comment
- By Month 6 (2027-04-12): Finalize MoU template with binding enforcement clauses (inspector hiring, quarterly reporting, penalties); negotiate signatures with Brazil, Indonesia, Thailand, Malaysia, Vietnam
- By Month 36 (2029-10-12): Hold IPPC adoption vote and secure national embedding in at least 3 of top 5 producers

**Approval Authorities:** IPPC Commission on Phytosanitary Measures (CPM) for formal standard adoption; national plant protection organizations of Brazil, Indonesia, Thailand, Malaysia, Vietnam for bilateral MoU signature and legislative embedding

### 2. Hevea Resistance Breeding Strategy and Pre-Registered Durability Protocol

**ID:** e036a7df-a87e-401f-9b96-714af630a224

**Description:** Peer-reviewed technical protocol specifying breeding targets (yield ≥90% of elite clones, ≥3 stacked resistance sources, lesion <5mm, artificial inoculation at 10x field load), multi-site field-trial design (4 sites: Brazil, Thailand, Malaysia/Indonesia, Côte d'Ivoire), durability-testing methodology, and success metrics for Year 7 gate (Month 84 = 2033-10-12). Establishes the Resistance Durability Oversight Panel authority and KPI interpretation rules to prevent post-hoc gate contestation. Primary audience: breeding scientists, independent auditors, funders, smallholder adoption planners.

**Responsible Role Type:** Hevea Resistance Breeding Program Director & Germplasm Lead

**Primary Template:** International Plant Breeding and Durability Testing Standards (IPGRI, CIMMYT protocols for perennial crops)

**Secondary Template:** World Bank Project Appraisal Document (PAD) technical annex for gate KPIs

**Steps:**

- By Month 1 (2026-11-12): Establish Resistance Durability Oversight Panel (6 members: 2 breeders, 2 pathologists, 1 auditor, 1 ABS specialist); convene monthly
- By Month 3 (2027-01-12): Panel drafts durability-testing protocol with inoculum definitions, lesion-measurement standards, yield-comparison baselines
- By Month 6 (2027-04-12): Panel finalizes and publishes peer-reviewed protocol document; pre-register all KPI thresholds with auditor sign-off
- By Month 12 (2027-10-12): Launch multi-site field trials at 4 hubs with baseline soil/inoculum surveys; confirm germplasm transfer from ABS agreements
- By Months 24-84 (2028-10-12 to 2033-10-12): Quarterly Panel reviews of trial data, pathogen virulence tracking, yield-penalty trends; recommend breeding strategy adjustments
- By Month 84 (2033-10-12): Panel compiles Year 7 cultivar-readiness evidence for independent auditor verification

**Approval Authorities:** Resistance Durability Oversight Panel (binding interpretation authority); independent auditor (gate verification); IPPC/regional plant protection authorities (if cultivar release is linked to phytosanitary status)

### 3. Smallholder Adoption Strategy and Contingency Finance Framework

**ID:** 262bb5a7-abeb-4b19-be47-c4eb8326196c

**Description:** Operational plan defining three adoption scenarios (conservative 30-40%, moderate 40-50%, optimistic 60%+) with pre-allocated finance and extension commitments for each; income-bridging finance design (6-10 year immature period at 60-70% of farm income, repayment trigger ≥2 t/ha yield); extension-workforce structure (500 lead agents via locally-owned cooperatives, not central employment); adoption KPI waypoints (Month 84 = 2033-10-12: 30% enrollment; Month 144 = 2038-10-12: 40% area replanted); contingency triggers (below 30% enrollment by Month 84 = 2033-10-12 reallocates USD 0.8-1.2B to estate/processing). Primary audience: smallholder-serving organizations, cooperative leaders, extension-service providers, finance institutions.

**Responsible Role Type:** Smallholder Adoption Finance & Extension Delivery Manager

**Primary Template:** IFAD Rural Finance Programme Design (income-bridging instruments, cooperative governance)

**Secondary Template:** World Bank Smallholder Extension and Adoption Tracking Framework

**Steps:**

- By Month 1 (2026-11-12): Establish Smallholder Adoption Working Group with farmer associations from top 5 producers
- By Month 6 (2027-04-12): Conduct baseline willingness-to-pay survey across 2,000-5,000 smallholders per country; define three scenarios with explicit finance and extension budgets
- By Month 9 (2027-07-12): Develop income-bridging finance instrument design (grace period, repayment schedule, default absorption); establish Extension Corps Workforce Plan with retention incentives
- By Month 12 (2027-10-12): Deploy 500 lead extension agents and establish 50-100 certified nurseries per country; launch mobile attestation system for lot tracking
- By Months 24-36 (2028-10-12 to 2029-10-12): Pilot bridging finance on 5,000-10,000 smallholders; monitor default rates and extension-agent retention
- By Month 84 (2033-10-12): Evaluate adoption performance against waypoints; trigger contingency reallocation if enrollment <30%

**Approval Authorities:** Steering Council (scenario budget allocation approval); national agricultural ministries and farmer associations (extension-agent deployment and cooperative governance); smallholder representatives (income-bridging terms and price-floor guarantees)

### 4. Gate Evidence Verification Regime Charter and Auditor Governance Framework

**ID:** 88b6add6-94be-4953-9250-3853b6ddf4cb

**Description:** Legal governance document establishing independent auditor procurement, scope pre-registration, multi-source verification methodology (field 30-40%, database 40-50%, interviews 20-30%), contractual data-access guarantees (5-business-day response, 1-2% fee penalty per delay), and binding Dispute-Resolution Adjudication Panel authority (3 neutral judges, 60-day binding judgment). Defines KPI interpretation rules for all four gates (Months 36, 84, 144, 216 = 2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12) to prevent auditor-versus-programme contestation and capital withholding. Primary audience: independent auditors, dispute-resolution panelists, funders, programme leadership.

**Responsible Role Type:** Gate Evidence Verification & Independent Audit Director

**Primary Template:** World Bank Disbursement Linked Indicators (DLI) and gate-verification protocol

**Secondary Template:** Green Climate Fund Independent Technical Advisory Panel (ITAP) charter for fund access review

**Steps:**

- By Month 3 (2027-01-12): Establish Dispute-Resolution Adjudication Panel with 3 neutral figures (retired phytosanitary authority, independent agronomist, financial auditor); draft panel charter with binding-judgment authority
- By Month 3 (2027-01-12): Contract independent international auditor (consortium acceptable) with written governance charter specifying data-access guarantees and multi-source verification weighting
- By Month 6 (2027-04-12): Pre-register audit scope and KPI definitions for all four gates in a published, peer-reviewed protocol; lock in before any data collection
- By Months 30-40 (2029-04-12 to 2030-02-12): Conduct Year 3 audit; publish verdict within 30 days with supporting evidence
- By Months 78-92 (2033-04-12 to 2034-04-12), 138-150 (2038-04-12 to 2038-06-12), 210-222 (2043-04-12 to 2044-04-12): Conduct Year 7, 12, 18 audits following same protocol
- Ongoing: Manage auditor data-access disputes; enforce 1-2% fee penalties for non-compliance; support Adjudication Panel arbitration within 60 days of verdict dispute

**Approval Authorities:** Independent auditor (scope and methodology approval from funders and programme leadership by Month 6 = 2027-04-12); Dispute-Resolution Adjudication Panel (binding judgment authority, no appeal)

### 5. Access-and-Benefit-Sharing (ABS) Framework Agreement and Community-Governed Data Trust Charter

**ID:** 10723467-2433-46eb-a305-0e816962b20a

**Description:** Legally binding bilateral ABS agreements with Brazil's CGen and at least 3 Amazonian community groupings (e.g., COIAB, FOIRN), specifying benefit-sharing formula (USD 1-5 per ha of deployed cultivar based on genealogy tracking), royalty-free seed for smallholders, open-access genomic sequence publication within 12 months, community board veto on commercial cultivar licensing, dispute-resolution mechanism (90-day mediation), and quarterly benefit-tracking ledger with public disclosure. Establishes community-governed data trust with 2+ indigenous seats and binding governance authority. Primary audience: Brazil's Ministry of Environment/CGen, indigenous and traditional communities, breeding programme partners, smallholder organizations.

**Responsible Role Type:** Access-and-Benefit-Sharing (ABS) Counsel & Community Governance Lead

**Primary Template:** Nagoya Protocol Standard Material Transfer Agreement (SMTA) template customized for perennial-crop breeding

**Secondary Template:** ITPGRFA Multilateral System Benefit-Sharing Framework (adapted for bilateral ABS)

**Steps:**

- By Month 1 (2026-11-12): Hire specialized ABS legal counsel with Nagoya Protocol track record; initiate preliminary consultations with Brazil CGen and indigenous organizations
- By Months 1-3 (2026-11-12 to 2027-01-12): Map Amazonian germplasm sources and identify community stakeholders for consultation; publish community engagement plan
- By Month 6 (2027-04-12): Negotiate and execute binding bilateral ABS agreements with CGen and 3+ community groupings specifying benefit-sharing structure, data-use rights, dispute resolution
- By Month 6 (2027-04-12): Establish community-governed data trust with indigenous board seats; draft trust governance charter and fiduciary obligations
- By Month 12 (2027-10-12): Publish all executed ABS agreements and benefit-sharing payment ledgers publicly; initiate quarterly benefit-sharing verification cycle
- Ongoing through Month 216 (2044-10-12): Track and disburse benefit-sharing payments within 30 days; manage community-board oversight of commercial cultivar licensing

**Approval Authorities:** Brazil's CGen (national ABS authority); community organizations (indigenous and traditional-community governance groups); breeding programme partners (adoption of ABS terms into research agreements)

### 6. Capital Stack and Sponsor Coalition Framework Agreement

**ID:** 959250e2-7870-4495-a77f-67abce215eea

**Description:** Legally binding 25-year framework agreements (not subject to annual budget cycles) with at least 5 sovereign and multilateral development-bank funders (none above 20%), specifying committed capital tranches by phase (Months 0-36 = 2026-10-12 to 2029-10-12: USD 3.5B; Year 3 gate: USD 7.0B; Year 7: USD 6.5B; Year 12: USD 4.5B; Year 18: USD 4.0B), minimum-funding floors (80% tranche release on partial gate success), 45-day mandatory disbursement, force-majeure carve-outs (12-month postponement, not cancellation), and penalties for early withdrawal (5-10% forfeiture of undisbursed balance). Binding industry-resilience levy agreement with top 10 tire makers and 5 traders (0.75% of purchases = ~USD 150M/year), 10-year minimum commitment, 2-year capital forfeiture penalty. Ring-fenced contingency reserve governance (USD 4.5B, released only for external shocks by Dispute-Resolution Panel). Primary audience: sovereign treasuries, multilateral development banks, OEM procurement heads, programme leadership.

**Responsible Role Type:** Financial Planning, Capital Structuring & Funder Relations Director

**Primary Template:** World Bank/ADB Project Financing Agreement (covenants, disbursement mechanics, remedies)

**Secondary Template:** IFC Risk Management Framework (force-majeure definition, contingency-reserve governance)

**Steps:**

- By Month 3 (2027-01-12): Engage specialized development-finance counsel to draft framework-agreement templates
- By Months 3-6 (2027-01-12 to 2027-04-12): Negotiate framework agreements with World Bank, ADB, AfDB, IADB, IFAD and at least 1 additional sovereign source; lock in gate-release mechanics and minimum-funding floors
- By Month 12 (2027-10-12): Execute legally binding framework agreements with at least 5 funders; publish summary terms (gates, tranches, minimum-funding floors) for stakeholder transparency
- By Months 6-12 (2027-04-12 to 2027-10-12): Negotiate binding industry-levy agreement with top 10 OEMs and 5 traders; establish levy collection and governance mechanism
- By Month 12 (2027-10-12): Establish ring-fenced contingency reserve (USD 4.5B) with Dispute-Resolution Panel governance and explicit release triggers (external shocks only)
- Ongoing: Monitor funding commitments and disbursement; enforce minimum-funding floors at each gate; manage contingency-reserve drawdowns

**Approval Authorities:** Sovereign treasuries and multilateral development banks (framework-agreement signatories); OEM CFO/procurement leadership (levy-agreement signatories); Dispute-Resolution Adjudication Panel (contingency-reserve deployment authority)

### 7. Containment Protocol Implementation and Compliance Monitoring Plan

**ID:** cbc13e2b-1ee0-48e0-b24c-3a29cf7d13d9

**Description:** Operational plan detailing protocol enforcement mechanisms: binding penalty schedule (nursery stock sale without pedigree: EUR 5,000-50,000 + 12-month suspension; SALB concealment: EUR 10,000-100,000 + mandatory destruction without compensation; public listing for 24 months); inspector recruitment, training, and 3-year rotation requirements (4-week initial training, annual certification on 50-lot audit with 95%+ accuracy gate); anonymous mobile-phone reporting system (EUR 10-50 incentive per verified report, 30-day payment); quarterly compliance audits by independent Compliance Secretariat (published scorecards); red-team drills Months 18-36 (2028-04-12 to 2029-10-12) in at least 3 countries with public results. Primary audience: national plant protection agencies, inspectors, smallholder reporting networks, auditors.

**Responsible Role Type:** Surveillance, Detection & Incursion Response Coordinator

**Primary Template:** ISO 17020 Inspection Body Accreditation Standard (inspector competency, impartiality, conflict-of-interest management)

**Secondary Template:** IPPC Phytosanitary Inspection Manual (procedures, documentation, confidentiality)

**Steps:**

- By Month 3 (2027-01-12): Draft published penalty schedule with financial and reputational consequences; establish Compliance Secretariat (separate from programme management) for auditing
- By Month 6 (2027-04-12): Finalize inspector recruitment plan and 4-week training curriculum; establish conflict-of-interest declarations and 3-year rotation policy
- By Month 9 (2027-07-12): Begin inspector training and deployment; recruit mobile-phone reporting coordinators in each producing country
- By Month 12 (2027-10-12): Deploy at least 100 inspectors (20 per top-5 producer); launch anonymous reporting system; begin monthly compliance scorecards
- By Months 18-36 (2028-04-12 to 2029-10-12): Conduct red-team drills in at least 3 countries; publish results transparently; issue remedial training orders to deficient regions
- By Months 36-300 (2029-10-12 to 2051-10-12): Maintain quarterly compliance audits, monthly scorecards, and annual inspector re-certification

**Approval Authorities:** National plant protection organizations (inspector deployment authority); Compliance Secretariat (audit and penalty recommendations); Steering Council (appeals on non-compliance disputes)

### 8. Surveillance, Detection and Incursion Response Architecture

**ID:** ad91db84-0373-4bec-b513-b5030ee02611

**Description:** Multi-tiered surveillance system design: Tier 1 (primary-producing countries) bi-monthly field scouting + monthly lab confirmation in nurseries/estates, target detection <3 months; Tier 2 (secondary regions) quarterly scouting + simplified field diagnostics, target <6 months; Tier 3 paid smallholder sentinels with mobile reporting and 2-week verification. Regional diagnostic labs (10+) by Month 24 (2028-10-12) with PCR, ELISA, inoculum culture capabilities and proficiency testing. Eradication-first incursion response doctrine with pre-positioned rapid-response brigades and USD 0.5B compensation fund (compensation paid within 30 days of confirmed eradication). Primary audience: national quarantine agencies, laboratory directors, rapid-response teams, smallholder sentinel reporters.

**Responsible Role Type:** Surveillance, Detection & Incursion Response Coordinator

**Primary Template:** FAO Plant Protection Officer Training Manual (field inspection, disease recognition, sampling protocols)

**Secondary Template:** CIMMYT/ICRISAT Pest and Disease Surveillance Network protocol

**Steps:**

- By Month 3 (2027-01-12): Design Tier 1/2/3 surveillance protocols with detection timelines and reporting workflows; identify regional lab locations
- By Month 6 (2027-04-12): Establish anonymous mobile-reporting incentive system (EUR 10-50 per confirmed report); recruit sentinel coordinators
- By Month 12 (2027-10-12): Deploy Tier 1 and Tier 2 surveillance infrastructure; train national inspectors on field scouting and sampling
- By Month 24 (2028-10-12): Commission 10+ regional laboratories; conduct quality-assurance ring trials (quarterly, proficiency testing); establish data-sharing protocols
- By Months 18-36 (2028-04-12 to 2029-10-12): Conduct red-team drills testing inspector detection accuracy; publish results; remediate deficiencies
- By Month 60 (2031-10-12): Validate detection latencies against <3 month and <6 month targets; adjust surveillance intensity or lab capacity if needed
- Ongoing through Month 300: Operate surveillance network with quarterly compliance audits; process smallholder reports within 2 weeks

**Approval Authorities:** National plant protection organizations (surveillance deployment); regional lab directors (operational standards); Incursion Response Coordinator (alert escalation and eradication-doctrine activation)

### 9. Alternative Rubber Crops Cost-Down Roadmap and Processing Development Strategy

**ID:** b92a8fec-0287-4eee-b62a-d4f5ce52f1d5

**Description:** 10-year technology and cost-reduction roadmap for Guayule and dandelion, identifying process innovation milestones: feedstock cost USD 1.20/kg (Guayule) and USD 1.00/kg (dandelion) by Month 48 (2030-10-12); extraction yield 85%+ (Guayule) and 80%+ (dandelion) by Month 60 (2031-10-12); all-in processing cost USD 2.50/kg by Month 84 (2033-10-12); delivered cost <30% above Hevea by Month 144 (2038-10-12). Parallel R&D tracks: solvent-extraction yield optimization, dandelion root-to-latex processing, co-product valorization (resin, waxes), processing-waste reduction. Allocation: USD 0.15-0.20B processing R&D (from alternative-rubber budget), pilot plants (USD 0.2B), loss-cover reserve (USD 0.6B). Portfolio decision at Month 60 (2031-10-12): if cost targets missed, reallocate wave 1 USD 0.8B to resistant-Hevea breeding. Primary audience: processing engineers, technology partners, OEM procurement, plant investors.

**Responsible Role Type:** Alternative-Rubber Processing & OEM Engagement Lead

**Primary Template:** UNIDO Technology Assessment and Transfer Framework (processing innovation roadmaps)

**Secondary Template:** Fraunhofer IME Biorefinery Design Templates (dandelion extraction, co-product integration)

**Steps:**

- By Month 3 (2027-01-12): Identify 3 technology-partner institutions (e.g., Fraunhofer IME, academic labs, tire-company R&D); commission parallel cost-down roadmap development
- By Month 6 (2027-04-12): Deliver integrated cost-down roadmap with milestone targets (Months 36, 48, 60, 84, 144 = 2029-10-12, 2030-10-12, 2031-10-12, 2033-10-12, 2038-10-12); allocate USD 0.15-0.20B R&D budget
- By Month 9 (2027-07-12): Launch dedicated processing R&D projects at each technology-partner site; establish quarterly progress reviews
- By Month 24 (2028-10-12): Commission pilot-scale extraction facilities (500 kg/day, 2 sites); baseline cost and yield data collection
- By Month 48 (2030-10-12): Complete pilot phase; assess extraction yield and cost against Month 48 (2030-10-12) targets
- By Month 60 (2031-10-12): Compile cost-down evidence and make portfolio decision (processing innovation vs. breeding redirection); stage wave 1 plant FID decision
- By Month 144 (2038-10-12): Validate Month 144 (2038-10-12) delivered-cost KPI (<30% above Hevea) from commercial plant operations

**Approval Authorities:** Technology partners (R&D execution); Alternative-Rubber Processing Lead (milestone tracking and decision recommendations); Steering Council (Month 60 = 2031-10-12 portfolio decision)

### 10. OEM Steering Committee Engagement Plan and Tire Qualification Protocol

**ID:** 87f5aac8-f752-4fb8-803b-45c4bf30bff9

**Description:** Engagement strategy with top-10 tire makers (Bridgestone, Goodyear, Michelin, Continental, Sumitomo, Yokohama, Pirelli, Hankook, Cooper, Toyo) specifying: monthly steering-committee meetings (VP-level Supply Chain attendance); non-binding Letters of Intent by Month 12 (2027-10-12) committing to 250,000-500,000 tyre/year supply-chain trials; tire-performance qualification trials at 3 independent labs (TÜV, RAPRA, Smithers) covering tread wear (≥95% of Hevea reference), rolling resistance (±5%), wet braking (≥95%), durability (500,000 km); qualification completion by Month 48 (2030-10-12); purchase-option contracts Months 48-60 (2030-10-12 to 2031-10-12) with 1.5% annual reservation fee and phased-down premium (10% Year 12, 5% Year 18, 0% Year 24). Primary audience: OEM VP-level leadership, tire-development teams, independent test labs, commercial plant financing partners.

**Responsible Role Type:** Alternative-Rubber Processing & OEM Engagement Lead

**Primary Template:** OEM Material Qualification Standard (e.g., Michelin or Bridgestone internal spec template, adapted)

**Secondary Template:** ASTM D6370 Tire Performance and Safety Standards

**Steps:**

- By Month 1 (2026-11-12): Establish OEM Steering Committee with recruitment letters to top 10 tire makers; request VP-level Supply Chain attendance
- By Month 3 (2027-01-12): Hold inaugural monthly steering-committee meeting; review programme roadmap and technology pipeline
- By Month 6 (2027-04-12): Develop tire-qualification protocol (test parameters, pass/fail criteria, timeline); secure lab commitments
- By Month 12 (2027-10-12): Secure non-binding Letters of Intent from at least 8 OEMs; launch supply-chain trial tire builds at OEM facilities; contract independent test labs
- By Months 12-48 (2027-10-12 to 2030-10-12): Conduct parallel tire qualification trials; monthly steering-committee updates on results; manage OEM feedback
- By Month 48 (2030-10-12): Publish qualification results (pass/conditional/fail); present to OEMs for purchase-option contract negotiation
- By Months 48-60 (2030-10-12 to 2031-10-12): Structure purchase-option contracts specifying reservation-fee amounts, premium schedules, and volume commitments

**Approval Authorities:** OEM Steering Committee (Letters of Intent and purchase-option contract approval); independent test labs (qualification verdict)

### 11. Program Governance Framework and Institutional Continuity Plan

**ID:** 6c78bf09-d9d9-4b13-b475-c793a91b9c10

**Description:** Governance charter establishing Steering Council (sovereign, OEM, research, farmer representatives) meeting quarterly from Month 1 (2026-11-12); living Strategic Plan updated annually (first 5 years) and every 5 years thereafter; Program Data Governance Framework (tiered: open pre-competitive, confidential commercial, published benefit-sharing); successor-leader recruitment plan (deputy leads by Month 24 = 2028-10-12 with explicit succession protocols); knowledge-management systems (decision logs, trial data, breeding records, benefit-sharing ledgers archived with 50-year preservation); institutional fatigue and staff-turnover risk mitigation through decentralized, locally-owned delivery structures (cooperatives, farmer associations). Primary audience: Steering Council members, programme leadership, institutional partners, long-term stakeholders.

**Responsible Role Type:** Program Governance, Strategic Coordination & Long-Term Sustainability Manager

**Primary Template:** World Bank Project Governance Charter (fiduciary standards, committee composition, decision authority)

**Secondary Template:** CGIAR Governance and Accountability Framework (multi-stakeholder decision-making, transparency)

**Steps:**

- By Month 1 (2026-11-12): Establish Steering Council with representatives from sovereigns, OEMs, research institutions, and farmer organizations; schedule quarterly meetings
- By Month 3 (2027-01-12): Develop Program Data Governance Framework (tiered access rules, publication timelines, IP and benefit-sharing policies); appoint Data Steward
- By Month 6 (2027-04-12): Finalize living Strategic Plan template with annual update protocols (first 5 years) and 5-year review cycles; publish initial plan
- By Month 12 (2027-10-12): Recruit deputy programme leaders with explicit succession protocols; establish knowledge-management systems (decision logs, database archival)
- By Month 24 (2028-10-12): Publish institutional continuity plan covering leadership transition, staff retention, and decentralized governance models for extension and nurseries
- By Months 36-300 (2029-10-12 to 2051-10-12): Hold quarterly Steering Council meetings with published agendas and decision records; conduct annual governance self-assessments

**Approval Authorities:** Steering Council (governance framework approval and periodic charter amendment); Funders (institutional continuity plan acceptance); National partners (decentralized governance model adoption)

### 12. Unallocated Budget Allocation Framework and Contingency Decision Rules

**ID:** 119391d9-47d8-40ff-be2d-12939d67dc77

**Description:** Framework for allocating the USD 13.9 billion unallocated gate-conditional balance and deciding the programme-financed share of commercial plant capex (base case assumes 100% programme financing = USD 1.6B; alternative: co-finance with OEMs or project finance). Specifies allocation priorities: surveillance capacity, breeding expansion, alternative-crop processing R&D, extension surge, smallholder contingency, and contingency for climate re-siting and crown-budding. Decision triggers: if breeding-trial yield penalty exceeds 15% by Month 48 (2030-10-12), allocate USD 0.25B crown-budding fast-track; if alternative-crop cost targets missed by Month 60 (2031-10-12), reallocate wave 1 plant capex (USD 0.8B) to other priorities; if climate modelling shows >25% Guayule yield loss risk, allocate USD 1.0-1.5B re-siting reserve. Primary audience: Finance Director, Steering Council, funders deciding capital allocation priorities.

**Responsible Role Type:** Financial Planning, Capital Structuring & Funder Relations Director

**Primary Template:** World Bank/ADB Project Financing Plan and Disbursement Schedule

**Secondary Template:** IMF Budget Allocation Framework (contingency reserve policies)

**Steps:**

- By Month 3 (2027-01-12): Model allocation scenarios mapping the USD 13.9B balance against priorities (surveillance, breeding, processing R&D, extension, contingency reserves)
- By Month 6 (2027-04-12): Finalize allocation decision and publish budget-line assignments; decide programme-financed share of plant capex
- By Month 6 (2027-04-12): Pre-register decision triggers and reallocation rules (e.g., crown-budding activation, climate re-siting, portfolio pivot) with Steering Council sign-off
- By Months 48-60 (2030-10-12 to 2031-10-12): Evaluate breeding and cost KPIs; execute reallocation decisions if triggers are activated
- Ongoing through Month 216 (2044-10-12): Track unallocated balance; request Steering Council approval for out-of-plan capital calls or reallocation

**Approval Authorities:** Steering Council (allocation framework and decision-trigger approval); Funders (capital-release authorization for reallocated tranches)

### 13. Climate Risk Assessment and Adaptive Management Decision Framework

**ID:** 5a92fead-942d-4206-aa64-2bfb89f2441b

**Description:** Agro-climatic modeling analysis of Guayule and dandelion suitability at candidate sites under climate-change scenarios (RCP 4.5, 8.5), modeling water balance, drought probability, frost risk, and crop yield-stress curves. Delivers baseline climate-risk profiles and revised land-use footprints by Month 6 (2027-04-12), locked into pilot-site selection by Month 24 (2028-10-12). Models SALB-habitat expansion under warming; identifies early-warning indicators for contingency activation (e.g., Guayule yield loss >25% triggers re-siting option). Validates climate-reserve allocation (USD 1.0-1.5B) and recommends contingency sites or crop substitution if primary sites become unsuitable. Primary audience: alternative-crop agronomy teams, site-selection committees, climate-finance authorities, contingency-reserve managers.

**Responsible Role Type:** Climate Risk, Agronomic Shock and Program Resilience Analyst

**Primary Template:** CGIAR Climate Change, Agriculture and Food Security (CCAFS) Climate Risk Assessment Framework

**Secondary Template:** FAO AQUASTAT Water-Use Assessment protocols (arid-zone irrigation)

**Steps:**

- By Month 1 (2026-11-12): Commission agro-climatic modeling task covering water balance, drought probability, frost/heat stress at 15+ candidate sites
- By Month 6 (2027-04-12): Deliver baseline climate-risk profiles and revised land-use footprints; model SALB-habitat expansion under warming
- By Month 12 (2027-10-12): Deliver water-balance assessments for Guayule sites; flag inviable sites with <10-year groundwater reserve at proposed extraction rates
- By Month 18 (2028-04-12): Complete SALB-habitat suitability modeling; identify early-warning indicators for climate-change range expansion
- By Month 24 (2028-10-12): Finalize pilot-site selection based on climate-risk assessment; lock alternative-crop footprints into agronomic planning
- By Months 60-144 (2031-10-12 to 2038-10-12): Monitor climate conditions at operating crop sites; trigger contingency activation (re-siting, crop substitution) if yield-loss thresholds exceeded

**Approval Authorities:** Climate modeling partners (technical findings); Site-Selection Committee (site lock-in approval); Steering Council (climate-contingency reserve activation authority)

### 14. Resistance Breakdown Durability Monitoring and Next-Generation Breeding Pipeline Plan

**ID:** ab5ae2db-b8f7-4fc3-85f3-028257d93527

**Description:** Long-term resistance durability monitoring framework (Months 108-300 = 2035-10-12 to 2051-10-12) with quarterly pathogen virulence surveillance at deployed clone sites, sentinel planting blocks under high-inoculum pressure, and multi-pathotype challenge protocols. Establishes triggers for detecting early-stage resistance breakdown (lesion size increase >2mm vs. baseline, defoliation increase >5%, yield penalty increase 5-10%). Parallel next-generation breeding pipeline (starting Month 60 = 2031-10-12 with different resistance sources) to deploy replacement cultivars within 5-7 years if breakdown occurs. Targets: maintain ≥2 independent resistance sources in landscape mosaics (Decision 10) to limit impact of any single-source breakdown. Primary audience: breeding scientists, Resistance Durability Oversight Panel, gate-verification auditors.

**Responsible Role Type:** Hevea Resistance Breeding Program Director & Germplasm Lead

**Primary Template:** IRRDB Long-Term Hevea Durability Monitoring Protocol (pathogen-virulence tracking, clone rotation)

**Secondary Template:** CIMMYT Genetic Gain Monitoring Framework (breeding pipeline renewal)

**Steps:**

- By Month 1 (2026-11-12): Establish durability-monitoring plan with quarterly virulence surveillance and sentinel-block protocols
- By Month 60 (2031-10-12): Initiate next-generation breeding programme with different resistance sources; begin crossing new sources into elite backgrounds
- By Months 108-216 (2035-10-12 to 2044-10-12): Operate quarterly pathogen-virulence surveillance across deployed clone sites; publish annual virulence reports
- By Month 120 (2036-10-12): Evaluate first 8-9 year durability data; if resistance breakdown detected in any source, activate next-generation cultivar release protocols
- By Month 180-200 (2041-10-12 to 2043-10-12): Begin commercial deployment of next-generation cultivars in regions showing resistance erosion (phased replacement, not simultaneous culling)

**Approval Authorities:** Resistance Durability Oversight Panel (breach detection and next-generation release recommendation); Steering Council (funding for accelerated breeding, if needed)

### 15. Binding Dispute-Resolution Adjudication Panel Charter and Procedures

**ID:** 39fdf8bc-55db-47dc-85d0-1af5cd477cc7

**Description:** Legal charter establishing a 3-member independent Dispute-Resolution Adjudication Panel (neutral senior figures: retired phytosanitary authority, independent agronomist, financial auditor) with explicit binding authority to issue gate verdicts if the programme management and independent auditors dispute gate-readiness evidence. Specifies panel composition, conflict-of-interest rules, voting and decision procedures, timeline (binding judgment within 60 days of dispute notice), appeal mechanisms (none; panel verdict is final), funding (USD 2-5M/year, ring-fenced), and publishing requirements (verdicts published within 30 days of issuance with supporting reasoning). Primary audience: programme leadership, independent auditors, funders, dispute parties.

**Responsible Role Type:** Gate Evidence Verification & Independent Audit Director

**Primary Template:** International Centre for Settlement of Investment Disputes (ICSID) Arbitration Rules (neutral dispute-resolution authority, confidentiality, procedural fairness)

**Secondary Template:** World Bank Inspection Panel Charter (independence, mandate, investigation procedures)

**Steps:**

- By Month 1 (2026-11-12): Recruit 3 neutral senior figures and conduct conflict-of-interest vetting; draft panel charter specifying authority, procedures, and binding-judgment scope
- By Month 3 (2027-01-12): Finalize panel charter with funders and programme leadership sign-off; publish for stakeholder transparency
- By Month 6 (2027-04-12): Establish panel operational protocols (meeting schedule, dispute-notice timelines, evidence-submission procedures); set up secure decision-documentation system
- By Months 30-40 (2029-04-12 to 2030-02-12), 78-92, 138-150, 210-222 (2029-04-12 to 2030-02-12, 2033-04-12 to 2034-04-12, 2038-04-12 to 2038-06-12, 2043-04-12 to 2044-04-12): Activate panel for gate-evidence disputes as needed; issue binding verdicts within 60 days

**Approval Authorities:** Funders and programme leadership (charter approval); panel members (independent judgment authority on disputes)

### 16. Compliance Inspector Training Curriculum and Certification Standard

**ID:** c3b36e84-e3c1-4ff1-ad8e-462590353141

**Description:** Standardized 4-week training curriculum for 100+ compliance inspectors (20 per top-5 producer) covering SALB symptom recognition (leaf lesion morphology, spore production, host susceptibility), phytosanitary inspection protocols (nursery stock documentation, equipment decontamination, quarantine procedures), sampling and specimen handling, laboratory confirmation chain-of-custody, conflict-of-interest management, and penalty-schedule enforcement. Includes annual certification renewal on audit of 50 inspection lots with 95%+ contamination-detection accuracy threshold. Specifies 3-year mandatory rotation to prevent co-optation or favoritism. Primary audience: national quarantine agencies, inspector recruits, training facilitators.

**Responsible Role Type:** Surveillance, Detection & Incursion Response Coordinator

**Primary Template:** FAO Plant Protection Officer Training Manual (field inspection skills, disease identification)

**Secondary Template:** ISO 17020 Inspection Body Accreditation Standard (inspector competency, impartiality, conflict-of-interest management)

**Steps:**

- By Month 3 (2027-01-12): Develop 4-week training curriculum covering SALB biology, symptom recognition, inspection procedures, documentation, and enforcement
- By Month 6 (2027-04-12): Pilot curriculum with 20 inspectors in 1 country; gather feedback and refine content
- By Month 9 (2027-07-12): Begin full-scale training for all 100 inspectors across 5 countries (4 weeks per cohort)
- By Month 12 (2027-10-12): Complete initial training and issue certificates; establish annual re-certification schedule
- By Months 24-36 (2028-10-12 to 2029-10-12): Conduct first annual re-certification audits (50-lot inspections, 95%+ accuracy gate); publish results
- Ongoing through Month 300: Conduct annual re-certification, manage 3-year rotation schedules, and update curriculum based on SALB pathogen changes

**Approval Authorities:** National plant protection organizations (inspector-training authority); independent auditors (certification-audit verification)

### 17. Anonymous Smallholder Violation-Reporting System and Incentive Protocol

**ID:** 65397080-2046-4f3f-855c-b26ecd71819a

**Description:** Mobile-phone-based (SMS/WhatsApp) system enabling smallholders to anonymously report suspected SALB infections, protocol violations (contaminated nursery stock), or equipment violations, with incentives (EUR 10-50 per confirmed report, paid within 30 days). Specifies reporting workflow (farmer submits report via phone to dedicated hotline), verification process (inspector visits within 2 weeks), reward distribution mechanism (verified through independent audit), and confidentiality protections (reporter identity concealed, no retaliation). Includes fraud-prevention measures (site verification, photographic documentation, laboratory confirmation) to prevent false reports. Primary audience: smallholders, extension agents, inspector coordinators.

**Responsible Role Type:** Surveillance, Detection & Incursion Response Coordinator

**Primary Template:** Frontline SMS or USSD mobile-messaging platform (low-bandwidth hotline setup)

**Secondary Template:** USAID Governance Accountability Mechanisms (anonymous reporting, whistleblower protection)

**Steps:**

- By Month 3 (2027-01-12): Design mobile-reporting system workflow and incentive-payment mechanism; establish backend database for report logging
- By Month 6 (2027-04-12): Contract mobile-messaging service provider (e.g., Frontline Systems, local telecom partnerships) in each of 5 producing countries
- By Month 9 (2027-07-12): Launch public awareness campaign promoting the reporting system in smallholder communities (posters, radio, mobile credits)
- By Month 12 (2027-10-12): Go live with reporting hotline in all 5 countries; establish inspector hotline-response protocols (2-week verification target)
- Ongoing through Month 300: Monitor reporting volume and verification success rates; publish monthly anonymized summaries (e.g., 'X reports received, Y verified, Z confirmed incidents')

**Approval Authorities:** National plant protection agencies (hotline deployment approval); programme leadership (incentive-budget administration)

### 18. Producer-Nation Memoranda of Understanding Template and Bilateral Negotiation Roadmap

**ID:** c47e936a-b580-4ff7-b985-722d4456bff0

**Description:** Specimen Memorandum of Understanding (MoU) template for Brazil, Indonesia, Thailand, Malaysia, and Vietnam, specifying: (1) commitment to embed the SALB Containment Protocol in national phytosanitary legislation by Month 36 (2029-10-12); (2) hire and fund at least 20 compliance inspectors per country by Month 12 (2027-10-12); (3) quarterly compliance reporting (inspections conducted, penalties issued, budget expenditure); (4) explicit penalties for non-compliance (loss of phytosanitary-capacity grants, supply-chain scrutiny by OEMs, public listing of violating nation); (5) dispute-resolution mechanism (bilateral consultation within 30 days, escalation to Steering Council if unresolved). Includes negotiation timeline (bilateral drafting Months 3-6 = 2027-01-12 to 2027-04-12, signature by Month 6 = 2027-04-12) and target legislative embedding by Month 48 (2030-10-12). Primary audience: national government ministries (environment, agriculture, commerce), phytosanitary authorities, bilateral negotiators.

**Responsible Role Type:** SALB Containment Protocol Director & Phytosanitary Authority Lead

**Primary Template:** CITES Bilateral Implementation Agreements (specimen enforcement, reporting, penalties)

**Secondary Template:** Regional plant protection organization bilateral protocols (e.g., NAPPO working agreements)

**Steps:**

- By Month 1 (2026-11-12): Hire specialized phytosanitary-governance counsel; draft specimen MoU template with enforcement clauses and penalty schedules
- By Months 1-3 (2026-11-12 to 2027-01-12): Consult IPPC Secretariat on MoU alignment with IPPC adoption roadmap; engage Protocol Adoption Secretariat
- By Months 3-6 (2027-01-12 to 2027-04-12): Conduct bilateral negotiations with Brazil, Indonesia, Thailand, Malaysia, Vietnam on MoU terms; address sovereign objections
- By Month 6 (2027-04-12): Execute signed MoUs with at least 3 of top 5 producers (target: Brazil, Indonesia, Thailand); timeline for remaining signatories (Malaysia, Vietnam) by Month 9 (2027-07-12)
- By Month 12 (2027-10-12): Verify inspector hiring and budget commitment from signatory nations; track progress toward Month 36 (2029-10-12) legislative embedding
- By Month 36 (2029-10-12): Verify that at least 3 signatories have legislatively embedded the protocol; assess compliance with IPPC adoption vote

**Approval Authorities:** National government ministries and legal counsels (MoU signatories); IPPC Secretariat (protocol-adoption coordination)

### 19. Tier 1/2/3 Surveillance Network Operations Manual and Detection-Latency Monitoring Framework

**ID:** 20946c81-c1af-4ac9-8ca3-ae3f36466571

**Description:** Operational procedures for the tiered SALB detection system: Tier 1 (primary-producing countries: bi-monthly field scouting + monthly laboratory confirmation in nurseries/estates, detection target <3 months); Tier 2 (secondary regions: quarterly scouting + simplified field diagnostics, detection target <6 months); Tier 3 (paid smallholder sentinels, mobile reporting, verification within 2 weeks). Specifies inspector visit schedules, sampling protocols, specimen chain-of-custody, laboratory turnaround times, alert-escalation procedures, and monthly detection-latency tracking. Includes contingency protocols for resource constraints (backup laboratory capacity, mobile PCR capacity, cross-border specimen transport). Primary audience: national inspectors, laboratory directors, surveillance coordinators.

**Responsible Role Type:** Surveillance, Detection & Incursion Response Coordinator

**Primary Template:** FAO PPIN Plant Disease Surveillance Manual (field sampling, specimen handling, laboratory protocols)

**Secondary Template:** USDA NASS Crop Surveillance Network protocols (tiered monitoring, data reporting)

**Steps:**

- By Month 3 (2027-01-12): Design Tier 1/2/3 surveillance architecture with inspector visit schedules, laboratory protocols, and alert-escalation workflows
- By Month 6 (2027-04-12): Develop detection-latency tracking dashboard (monthly reporting on time from symptom observation to confirmed detection); set KPI targets (<3 months Tier 1, <6 months Tier 2, <2 weeks Tier 3)
- By Month 9 (2027-07-12): Train national inspectors on tiered-surveillance procedures; establish laboratory chain-of-custody and specimen-handling protocols
- By Month 12 (2027-10-12): Activate Tier 1 and 2 surveillance in all major producers; launch Tier 3 smallholder-sentinel system
- By Months 24-36 (2028-10-12 to 2029-10-12): Conduct quarterly detection-latency audits; if latency exceeds targets, recommend additional inspector deployment or laboratory capacity
- Ongoing through Month 300: Monthly detection-latency reporting; annual surveillance-effectiveness audits

**Approval Authorities:** National plant protection organizations (surveillance deployment and funding); independent auditors (latency-target verification)

### 20. Incursion Response Doctrine and Eradication-Compensation Framework

**ID:** 8bb9d2a4-06a3-4718-b9e3-04d6be6560fa

**Description:** Operational doctrine for SALB incursion response: eradication-first approach (destruction of infected plantings + buffer zone) with pre-committed compensation to affected smallholders and estates (payment within 30 days of confirmed eradication to deter concealment). Specifies compensation structure: per-hectare destroyed (USD X per ha, estimate based on cultivar age/yield), smallholder income-loss bridging for replanting (6-10 year immature period at 60-70% of median farm income), and rapid re-planting with clean material from reserved nurseries. Pre-positions rapid-response brigades (teams, equipment, reserve-nursery stock) in at least 3 high-risk regions (Malaysia, Indonesia, Côte d'Ivoire) by Month 24 (2028-10-12). Includes contingency protocols if eradication scope exceeds USD 0.5B reserve capacity (insurance, phased compensation, economic-impact mitigation). Primary audience: rapid-response team leaders, compensation administrators, smallholder communities.

**Responsible Role Type:** Surveillance, Detection & Incursion Response Coordinator

**Primary Template:** FAO Emergency Response Framework (outbreak containment, compensation mechanisms)

**Secondary Template:** Disaster-Risk-Financing compensation protocols (rapid disbursement, verification procedures)

**Steps:**

- By Month 3 (2027-01-12): Develop incursion-response doctrine document specifying eradication-first approach, compensation structure, and rapid-response timelines
- By Month 6 (2027-04-12): Model compensation costs for realistic outbreak scenarios (1 site, 5 ha infected; multi-site, 100+ ha; multiple regions); validate USD 0.5B reserve adequacy
- By Month 12 (2027-10-12): Establish compensation-calculation tools (hectares destroyed × per-ha rate + income-bridging calculation); pre-authorize rapid-disbursement authority
- By Month 18 (2028-04-12): Recruit and train rapid-response brigades (2-3 teams, 5-10 personnel each) at high-risk regional sites; conduct response drills
- By Month 24 (2028-10-12): Pre-position reserve nurseries (clean planting material of resistant clones) at rapid-response staging areas; establish equipment caches
- By Months 30-40 (2029-04-12 to 2030-02-12): Conduct red-team drills simulating incursion detection and response; test compensation-disbursement timelines
- Ongoing: Maintain rapid-response brigades and reserve inventory; activate eradication response and compensation if SALB is confirmed

**Approval Authorities:** Steering Council (incursion-response doctrine approval, compensation-framework authorization); Dispute-Resolution Panel (oversized-compensation appeals)

### 21. Data Governance Framework and Publication-Timeline Policy

**ID:** 67b3c4c0-a154-40ee-b660-d6e0151488fc

**Description:** Tiered data governance rules specifying: (1) pre-competitive data (genomic sequences, field-trial summary results, surveillance findings) published openly within 12 months of generation, no restrictions; (2) commercial data (proprietary breeding crosses, OEM tire-test results) shared confidentially among programme partners under non-disclosure agreements, publication delayed 12 months post-gate; (3) benefit-sharing and impact data published annually within 30 days of payment, transparent ledger. Data ownership: programme holds pre-competitive data in trust for global research community; commercial data remain with originators (breeding partners, OEMs); benefit-sharing ledgers are jointly held by programme and community-governed trust. Specifies audit rights for independent auditors (mandatory data access within 5 business days) and long-term preservation (50-year archival with version control and format migration). Primary audience: data stewards, publishing coordinators, auditors, partner institutions.

**Responsible Role Type:** Program Governance, Strategic Coordination & Long-Term Sustainability Manager

**Primary Template:** FAIR Data Principles (Findability, Accessibility, Interoperability, Reusability) and OpenAIRE data-governance guidelines

**Secondary Template:** CGIAR Open Data Policy and publication timelines

**Steps:**

- By Month 1 (2026-11-12): Hire Data Steward; begin designing data-governance framework
- By Month 3 (2027-01-12): Draft tiered-access rules and publication-timeline policy; consult with breeding partners, OEMs, and community organizations on IP/benefit-sharing implications
- By Month 6 (2027-04-12): Finalize data-governance framework and publish for stakeholder transparency; establish data repository and version-control systems
- By Month 12 (2027-10-12): Begin data collection with governance tags (tier 1, 2, or 3); launch monthly compliance audits on publication-timeline adherence
- Ongoing through Month 300: Maintain data repository and archival systems; publish pre-competitive data within 12 months of generation; publish benefit-sharing ledgers monthly

**Approval Authorities:** Steering Council (governance framework approval); Data Steward (publication-timeline enforcement)

### 22. Programme Cost-Effectiveness Analysis Framework and Comparative-Alternative Assessment

**ID:** a521774d-beae-45da-a974-9ed890e308c5

**Description:** Cost-effectiveness analysis comparing the USD 30 billion integrated-resilience program against alternative strategies: (A) strategic natural-rubber reserve (physical stock accumulation), (B) insurance and contingency funds (no supply diversification), (C) Hevea breeding alone (no alternative crops). Metrics: cost per hectare protected (from SALB or climate risk), cost per tonne of diversified supply, cost per unit of outcome (e.g., cost per year of supply continuity maintained). Validates that the integrated programme cost (~USD 600-800/hectare across 5 million ha eligible smallholder area, estimate) is justified by the reduced-risk outcomes. Primary audience: funders justifying budget allocation, programme leadership demonstrating value-for-money.

**Responsible Role Type:** Financial Planning, Capital Structuring & Funder Relations Director

**Primary Template:** World Bank Cost-Benefit Analysis Guidelines (project justification, outcome metrics)

**Secondary Template:** FAO Food Security Impact Assessment methodologies

**Steps:**

- By Month 6 (2027-04-12): Model costs and outcomes for integrated programme and three alternatives (reserve-only, insurance-only, breeding-only)
- By Month 12 (2027-10-12): Conduct sensitivity analysis (cost per hectare at 30%, 45%, 60% adoption scenarios; at different SALB incursion probabilities)
- By Month 18 (2028-04-12): Publish cost-effectiveness analysis with comparative findings; use results to justify continued funder support
- By Months 84, 144, 216 (2033-10-12, 2038-10-12, 2044-10-12): Update cost-effectiveness analysis with actual outcomes (hectares protected, supply diversified, cost per unit achieved); report to funders

**Approval Authorities:** Steering Council (cost-effectiveness findings review); funders (budget-justification support)

## Documents to Find

### 1. Existing IPPC International Standards and Regional Plant Protection Organization Harmonized Phytosanitary Standards

**ID:** f753f734-0eb3-474d-843a-640ffc22abb2

**Description:** Published IPPC standards (ISPMs) governing plant-health certification, quarantine procedures, and phytosanitary risk analysis, especially ISPM 36 (Integrated Measures for Plants for Planting) and ISPM 5 (Glossary of Phytosanitary Terms). Includes regional standards from APPPC (Asia-Pacific), NAPPO (North America), CPPC (Caribbean), and African regional organizations. Needed as source material for the Containment Protocol Authority to harmonize the SALB protocol with existing phytosanitary frameworks and avoid regulatory conflicts.

**Recency Requirement:** Current standards as of Month 0 (2026-10-12); supersedes older versions. IPPC adoption vote schedules and working-group timetables are essential.

**Responsible Role Type:** SALB Containment Protocol Director & Phytosanitary Authority Lead

**Access Difficulty:** Easy. IPPC standards are published online (ippc.int); CPM schedules are publicly available. Regional organizations provide standards on their websites.

**Steps:**

- Access IPPC Secretariat portal (ippc.int) to retrieve all published ISPMs and their adoption histories
- Contact regional plant protection organizations (APPPC, NAPPO, CPPC) to obtain current regional standards and harmonization roadmaps
- Request from IPPC Secretariat the CPM (Commission on Phytosanitary Measures) meeting schedule for Months 3-36 (2027-01-12 to 2029-10-12) to time the protocol adoption vote

### 2. Nagoya Protocol and Brazil's Access and Benefit-Sharing (ABS) National System Regulations and Procedures

**ID:** fa53ca7e-a0cc-4070-8e7a-7e3cd2e01b80

**Description:** Brazil's national ABS regulations, CGen (Conselho de Gestão do Patrimônio Genético) operational procedures for accessing Amazonian germplasm, application timelines, and benefit-sharing requirements. Includes Brazil's National Biodiversity Law, community consultation protocols, and international Nagoya Protocol compliance text. Needed to validate the ABS timeline assumption (Month 6 = 2027-04-12 agreement closure) and identify regulatory bottlenecks and delays that cascade the breeding timeline.

**Recency Requirement:** Current as of Month 0 (2026-10-12); Brazil's ABS regulations are updated periodically. Request the most recent CGen decision records and application timelines.

**Responsible Role Type:** Access-and-Benefit-Sharing (ABS) Counsel & Community Governance Lead

**Access Difficulty:** Medium. Brazil's CGen procedures are published but require Portuguese-language navigation and direct inquiry to CGen for current timelines. Indigenous organization contacts require relationship-building; precedent agreements may be confidential.

**Steps:**

- Access Brazil's Ministry of Environment website (mma.gov.br) for ABS regulations and CGen operational procedures
- Request from CGen the current application timeline and average decision period for bilateral ABS agreements (query recent bilateral agreements with research institutions)
- Contact indigenous organizations (COIAB, FOIRN) to obtain precedent agreements and community consultation timelines
- Access the Nagoya Protocol text and implementation guidance (cbd.int) for international compliance framework

### 3. Hevea Breeding Programme Data and Historical Cultivar Yield/Resistance Performance Records

**ID:** 83e43ee8-a199-45bb-ad9c-df5eacdbb49d

**Description:** Historical field-trial data from established rubber-breeding programs (Embrapa, IRRDB member institutes, Malaysian Rubber Board, RRIM, Michelin's trials) showing Hevea cultivar yields (t/ha/year), SALB resistance-source evaluation results (lesion-size measurements, defoliation ratings, durability over 5+ years), and multi-site trial results across agroecologies. Needed to validate breeding KPI targets (yield ≥90% of elite clones, resistance stacking durability) and establish baseline genetic distances between proposed resistance sources.

**Recency Requirement:** Most recent available field data (last 10-15 years preferred); historical durability data on known SALB-resistant clones or crosses.

**Responsible Role Type:** Hevea Resistance Breeding Program Director & Germplasm Lead

**Access Difficulty:** Medium. Embrapa and IRRDB institutions maintain proprietary trial databases; full access may require formal data-sharing agreements. Published literature is openly accessible. Some institutions restrict recent trial data until cultivars are released commercially.

**Steps:**

- Contact Embrapa Rubber Research Unit (Manaus and Campinas) for existing SALB-resistance trial data and germplasm genotype records
- Request from IRRDB member institutes (RRIM Malaysia, Rubber Board Brazil, others) historical cultivar-performance data and multi-site trial protocols
- Access published breeding literature (journal articles from *Journal of Rubber Research*, *Industrial Crops and Products*) for peer-reviewed durability and yield data
- Query the IRRDB germplasm database (if publicly available) for clone parentage and genetic-marker data

### 4. Global and Regional Natural Rubber Supply, Price, and Market Structure Data

**ID:** 17666f9c-d6a7-456d-a430-1283a5740ebd

**Description:** Global rubber production, price, and trade data (FAO, USDA, International Rubber Study Group); regional supply breakdown (Indonesia, Thailand, Vietnam, Malaysia, Brazil, India); price indices and volatility (SICOM, RSS 3, SVR); OEM tire-production volumes and natural-rubber offtake; market-share trends in synthetic vs. natural rubber. Needed to validate market-size assumptions (14 Mt/year global, 0.2% program output), understand OEM procurement constraints, and model price-stability mechanisms for smallholders.

**Recency Requirement:** Most recent 5-year time series (2021-2026); monthly price data preferred for volatility analysis.

**Responsible Role Type:** Financial Planning, Capital Structuring & Funder Relations Director

**Access Difficulty:** Easy. FAO, IRSG, and commodity exchanges publish data openly. OEM reports are publicly available on corporate websites.

**Steps:**

- Access FAO Statistics Division (faostat.fao.org) for global rubber production and trade data
- Contact the International Rubber Study Group (IRSG) for market assessments and supply-chain analysis
- Access SICOM (Singapore Commodity Exchange) and TOCOM (Tokyo Commodity Exchange) historical price data for natural-rubber index pricing
- Request from major OEMs (Bridgestone, Michelin, Continental) publicly available sustainability reports showing natural-rubber consumption and sourcing preferences

### 5. Smallholder Rubber Farm Demographics, Adoption Patterns, and Finance Data from Comparable Programs

**ID:** f6017fab-ded4-4117-92c6-f1c6a0ff4a4c

**Description:** Baseline data on smallholder rubber-farm sizes, income, tenure, extension-contact frequencies, and credit-access rates in top-5 producing countries (Thailand, Indonesia, Vietnam, Malaysia, India); historical adoption rates of improved Hevea clones and other high-value crops (cocoa, coffee); prior program evaluation reports (World Bank, IFAD, CGIAR) measuring replanting uptake, default rates on bridging finance, and extension-staff retention in developing-country agriculture. Needed to validate the 45% smallholder-adoption target against historical uptake and to model income-bridging-finance design (repayment terms, default absorption).

**Recency Requirement:** Most recent available (last 5-10 years); ideally country-specific by province/district.

**Responsible Role Type:** Smallholder Adoption Finance & Extension Delivery Manager

**Access Difficulty:** Medium. World Bank and CGIAR data are openly accessible. National research institutes and extension services may require formal data requests. IFAD reports are published but may require navigating project databases.

**Steps:**

- Access World Bank Open Data (data.worldbank.org) for agricultural demographic and finance data by country
- Request from national agricultural-research institutes and extension services in Thailand, Indonesia, Vietnam, Malaysia, India baseline surveys on smallholder rubber farms
- Search CGIAR evaluation databases (CGIAR.org) for prior-programme evaluations on adoption, default rates, and extension effectiveness
- Contact IFAD project-evaluation teams for reports on rural-credit programs in tropical agroforestry (search IFAD.org project database)
- Access academic literature databases (Google Scholar, ResearchGate) for peer-reviewed studies on adoption of improved tree-crop varieties in Asia, Africa, Latin America

### 6. Guayule and Russian Dandelion Agronomy, Yield, and Processing-Cost Data from Pilot and Demonstration Projects

**ID:** b02feb4f-776a-456b-aa7d-32752ef4b5f7

**Description:** Agronomic trial data on Guayule yields (kg/ha/year), rubber content, extraction processes, and cost-per-kilogram estimates from Bridgestone's Eloy program (Arizona), USDA-ARS trials, and academic research. Russian dandelion (Taraxacum koksaghyz) yield and processing-cost data from Continental's Taraxagum program (Germany), Fraunhofer IME research, and EU-PEARLS consortium reports. Needed to validate the alternative-rubber feedstock-cost KPIs (USD 1.20/kg Guayule, USD 1.00/kg dandelion) and extraction-yield targets (85%+ Guayule, 80%+ dandelion).

**Recency Requirement:** Most recent pilot and trial results (2018-2026); both published reports and company technical reports.

**Responsible Role Type:** Alternative-Rubber Processing & OEM Engagement Lead

**Access Difficulty:** Medium. Bridgestone and Continental maintain proprietary data on pilot operations; company contacts are needed. USDA-ARS publications are open. Fraunhofer and EU-PEARLS reports are published but may be technical/specialized.

**Steps:**

- Contact Bridgestone Americas guayule program via their sustainability office; request agronomic and processing data from the Eloy, Arizona facility
- Access USDA-ARS Arid Land Agricultural Research Center (Maricopa, Arizona) publications and trial reports on Guayule
- Contact Continental's Taraxagum program and request technical reports on dandelion agronomy and processing from German operations
- Access Fraunhofer IME (Münster) research publications on dandelion extraction and processing chemistry
- Request EU-PEARLS final reports (search CORDIS database) for guayule and dandelion pilot cost-down findings

### 7. OEM Tire Performance Specification Standards and Natural Rubber Quality Requirements

**ID:** 21fae4aa-f45c-4e69-852d-df804b75a108

**Description:** Published tire-manufacturing specifications from major OEMs (e.g., Michelin, Bridgestone, Continental material standards) and ISO/ASTM tire-testing standards (ASTM D6370, ISO 4649 abrasion, rolling resistance, wet braking). Needed to define tire-qualification-trial pass/fail criteria for alternative rubber (tread wear ≥95% of Hevea reference, rolling resistance ±5%, wet braking ≥95%, durability 500,000 km) and to assess OEM willingness to accept quality variance.

**Recency Requirement:** Current standards as of Month 0 (2026-10-12); OEM internal specifications may be updated regularly.

**Responsible Role Type:** Alternative-Rubber Processing & OEM Engagement Lead

**Access Difficulty:** Easy. ASTM and ISO standards are published (purchase or library access). Test-lab protocols are standard industry practice. OEM specs may be proprietary but are typically shared during supplier qualification discussions.

**Steps:**

- Access ASTM International (astm.org) for ASTM D6370 (tire performance) and related standards
- Access ISO (iso.org) for ISO 4649 (abrasion resistance) and ISO 26423 (rolling resistance)
- Request from major test laboratories (TÜV, RAPRA, Smithers) their standard tire-qualification test protocols and pass/fail thresholds
- Contact OEM technical teams (Michelin, Bridgestone, Continental) via steering-committee engagement to obtain material specifications and tolerance windows

### 8. Funding Mechanisms and Development-Bank Gate-Conditional Disbursement Precedents

**ID:** 97222ea0-1fb1-478a-b59a-895dc4d3e75e

**Description:** World Bank, ADB, AfDB, and IADB project-financing documents (Project Appraisal Documents, Financing Agreements) that establish gate-conditional disbursement mechanisms, minimum-funding-floor covenants, and binding 25-year commitments. Needed to draft the Capital Stack and Sponsor Coalition framework agreements and to establish precedent language for mandatory disbursement (45 days post-gate), minimum tranches (80% on partial gate success), and penalties for early withdrawal.

**Recency Requirement:** Recent examples (2018-2026) from long-horizon agricultural, infrastructure, or resilience programs.

**Responsible Role Type:** Financial Planning, Capital Structuring & Funder Relations Director

**Access Difficulty:** Medium. World Bank and ADB project documents are publicly available (though some are in archive libraries). Legal covenant templates are proprietary to development banks; specialized counsel access may be required.

**Steps:**

- Access World Bank Open Knowledge Repository (openknowledge.worldbank.org) to search for project documents with gate-conditional disbursement language
- Request from World Bank Legal Vice Presidency model financing-agreement templates specifying minimum-funding floors and binding covenant language
- Access ADB development-finance portal (adb.org) to review project financing agreements with gate mechanisms
- Contact development-finance counsel with experience in multilateral covenants to identify precedent language and enforce mechanisms

### 9. Climate Change Impacts on Crop Suitability: Modelled Temperature, Precipitation, and Water-Stress Projections for Guayule and Dandelion Sites

**ID:** 09cfc6f1-a986-4564-a1a5-dfddf2826feb

**Description:** Climate modeling output (CMIP6 ensemble) for temperature, precipitation, and soil-water stress at candidate Guayule sites (Arizona, New Mexico, Texas) and dandelion sites (Germany, Benelux, Eastern Europe) under RCP 4.5 and RCP 8.5 scenarios; 30-year climate records (baseline) and forward projections to 2050-2070. Groundwater depletion forecasts for Guayule regions. Needed to validate alternative-crop land suitability and to size the USD 1.0-1.5B climate-contingency reserve.

**Recency Requirement:** CMIP6 climate projections (latest ensemble); 30-year baseline records (1990-2020 or similar).

**Responsible Role Type:** Climate Risk, Agronomic Shock and Program Resilience Analyst

**Access Difficulty:** Medium. CGIAR and public climate databases are openly accessible. USGS data are public. National meteorological services provide data, though fine-scale downscaled projections may require specialized request or subscription.

**Steps:**

- Access CGIAR Climate Change, Agriculture and Food Security (CCAFS) climate data portal (ccafs.cgiar.org) for crop-suitability projections by region
- Access WORLDCLIM (worldclim.org) or CHELSA climate databases for historical and projected climate data
- Contact USGS Water Resources Division for groundwater-depletion models and aquifer-sustainability assessments for Southwest U.S. sites
- Request from national meteorological services (NOAA USA, Deutscher Wetterdienst Germany) historical climate data and downscaled projections for candidate sites

### 10. SALB (Fusicladium heveae) Epidemiology, Geographic Distribution, and Pathogen-Virulence Data

**ID:** 30ad70c5-a1c9-4181-ae1c-5beaa6d0129a

**Description:** Published literature on SALB pathogen biology, geographic distribution (South America, Central America, confirmed absences from Asia and Africa), virulence-group variation, resistance-source durability precedents (known resistance breakdowns), and outbreak-probability estimates in currently unaffected regions. Needed to validate the eradication-first incursion-response doctrine and to model the USD 0.5B compensation-fund adequacy against realistic outbreak scenarios.

**Recency Requirement:** Most recent published research (last 10-15 years); historical outbreak records from Brazil and Central America.

**Responsible Role Type:** Surveillance, Detection & Incursion Response Coordinator

**Access Difficulty:** Easy. Published research is accessible via academic databases and Google Scholar. Technical reports from research institutions require direct contact but are often available upon request.

**Steps:**

- Search PubMed, Google Scholar, and Agricultural & Environmental Science Database (AESA) for peer-reviewed literature on SALB epidemiology, resistance durability, and outbreak dynamics
- Request from rubber-research institutions (Embrapa, IRRDB members, Michelin) technical reports on SALB-resistance breeding and documented resistance breakdowns
- Contact plant-pathology experts at universities in rubber-producing regions for interview data on SALB spread rates and outbreak-containment costs
- Access FAO Crop Pest & Disease Information (PPIN) or similar databases for SALB distribution and movement records

### 11. Existing Rubber-Sector Smallholder Finance and Extension Program Evaluation Reports

**ID:** 86a96fa2-071d-4a81-b73d-9558695ccc8b

**Description:** Evaluation reports from World Bank, IFAD, and other development programs that supported rubber smallholders through credit, extension, and technology adoption in Southeast Asia, West Africa, or Brazil (2005-2025). Data on replanting uptake rates, default rates on bridging or term credit, extension-agent retention, and cost-per-farmer-reached. Needed to calibrate the smallholder-adoption target (45% planning uptake vs. 20-40% historical baseline) and to design realistic extension-delivery and finance-repayment mechanisms.

**Recency Requirement:** Programs implemented 2005-2025; most recent evaluations preferred.

**Responsible Role Type:** Smallholder Adoption Finance & Extension Delivery Manager

**Access Difficulty:** Medium. World Bank and IFAD evaluations are published but may be archived. Program-level documentation (training guides, farmer surveys, default data) is often confidential or institution-specific; direct inquiry to program leaders is necessary.

**Steps:**

- Search World Bank Open Knowledge Repository for rubber-sector or tree-crop smallholder-support project evaluations
- Request from IFAD (ifad.org) project evaluation reports on rural credit and extension in rubber-producing countries
- Access CGIAR evaluation databases (CGIAR.org) for smallholder-adoption studies from research programs
- Contact development organizations working in rubber regions (NGOs, FAO country offices) for programme experience and lessons-learned documents

### 12. Existing Producer-Nation Plant Protection Organization Capacity, Inspector Numbers, and Budget Allocations

**ID:** 815cc373-71a4-44b7-b927-2e2f12017d2c

**Description:** Current staffing, budget, and inspector numbers in national plant protection agencies (Brazil, Indonesia, Thailand, Malaysia, Vietnam). Baseline inspector-training standards, certification protocols, and equipment inventories. Budget constraints and political priorities. Needed to validate whether 100 inspectors (20 per top-5 producer) by Month 12 (2027-10-12) is achievable and to identify capacity gaps requiring programme financing.

**Recency Requirement:** Current as of Month 0 (2026-10-12); most recent organizational charts and budget allocations.

**Responsible Role Type:** SALB Containment Protocol Director & Phytosanitary Authority Lead

**Access Difficulty:** Medium to Hard. National agency organizational data are sometimes public, sometimes classified. Direct diplomatic or institutional channels may be required for budget and staffing details.

**Steps:**

- Request from national plant protection agencies (Brazil MAPA, Indonesia KEMENTAN, Thailand PCP, Malaysia DAF, Vietnam QDCN) current organizational structures, staffing numbers, and budget documents
- Contact regional plant protection organizations (APPPC, NAPPO) for member-state capacity assessments and training-standard documents
- Access FAO PPIN or similar capacity-assessment databases for existing phytosanitary capacity in producing countries

### 13. World Bank and Multilateral Development Bank Project Financing Agreements and Gate-Conditional Disbursement Precedents

**ID:** 00831b3e-151d-4273-ae38-ecfa16547262

**Description:** Specimen financing agreements from World Bank, ADB, and other MDBs that document binding 25-year commitments, gate-release mechanics (minimum-funding floors, mandatory disbursement timelines), force-majeure clauses, and penalties for withdrawal. Examples: GCF (Green Climate Fund) outcome-based financing, results-based financing (RBF) from ADB. Needed as legal templates for drafting the Capital Stack and Sponsor Coalition framework agreements.

**Recency Requirement:** Financing agreements from programs implemented 2015-2026; current covenant language and dispute-resolution mechanisms.

**Responsible Role Type:** Financial Planning, Capital Structuring & Funder Relations Director

**Access Difficulty:** Medium. World Bank and ADB documents are published (though some are archived). Legal templates are often confidential; specialist counsel access may be needed.

**Steps:**

- Access World Bank Open Knowledge Repository (openknowledge.worldbank.org) and search for 'financing agreement' or 'disbursement-linked indicators'
- Request from World Bank Legal Vice Presidency sample financing-agreement templates (non-confidential sections)
- Access ADB development-finance documents portal to review ADB financing-agreement precedents
- Contact GCF Secretariat for outcome-based financing templates and gate-release mechanisms

### 14. Historical SALB Outbreak Records, Containment Costs, and Spread Dynamics

**ID:** 1967cd5c-15ce-42ff-b2d0-a68a8c2d5cf6

**Description:** Documented SALB outbreaks in Brazil, Central America, or other regions showing outbreak locations, acreage affected, years to containment, direct costs (eradication, replanting, lost production), indirect costs (market disruption, smallholder displacement), and spread rates under different containment scenarios. Needed to validate the USD 0.5B eradication-compensation reserve and to model containment-response triggers.

**Recency Requirement:** Historical outbreak records from the last 30-50 years; most complete records are from Brazil (1970s-1980s).

**Responsible Role Type:** Surveillance, Detection & Incursion Response Coordinator

**Access Difficulty:** Medium. Published research is accessible. Technical reports from Embrapa require direct inquiry. FAO PPIN records are published but may be in archives.

**Steps:**

- Search PubMed and Google Scholar for peer-reviewed articles on SALB outbreak history and containment costs
- Request from Embrapa and Brazilian rubber-research institutions technical reports on past SALB outbreaks and containment expenditures
- Contact FAO Plant Production and Protection Division (PPIN) for historical outbreak records and epidemiological analyses
- Access academic literature on agricultural epidemiology (plant disease outbreak modeling) for spread-rate and cost data