
## Documents to Create

### 1. Technical Gate Charter and KPI Specification

**ID:** 77f2528b-a6c1-4655-96c6-c3fdbe95d418

**Description:** Binding document defining Month 36, 84, 144, 216 (2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08) gate criteria (numeric KPIs, thresholds, evidence standards), adaptive tranching rules, independent Technical Panel composition, conflict-of-interest policies, evidence publication timelines (60 days pre-gate), public challenge periods (30 days), and appeal mechanisms. Primary audience: all funders, producer governments, OEMs, Technical Panel members. Signed by all parties; enforceable under international treaty law or equivalent governance covenant.

**Responsible Role Type:** Multilateral Secretariat Executive Director and Governance Lead

**Primary Template:** World Bank Development Policy Financing (DPF) Gate Charter; comparable: CGIAR independent assessment frameworks

**Secondary Template:** IPPC standard-setting process governance templates

**Steps:**

- Convene technical working group (Brazil, 5+ producing countries, IPPC Secretariat, FAO) by Month 0 (2026-10-08) to draft gate-criteria framework
- Specify Month 3 (2027-01-08) deliverable: draft Charter with numeric thresholds for all four gates, Technical Panel governance rules, and signature authorities
- Circulate draft to all funders, producer governments, and OEMs for 30-day comment period by Month 2 (2026-12-08)
- Finalize and execute binding signatures by Month 3 (2027-01-08); publish signed Charter within 7 days

**Approval Authorities:** All sovereign funders (5-8 governments), multilateral development banks (≥2), producer-country governments (≥15), OEM buyer consortium (5-8 members), independent Technical Panel (7-9 members)

### 2. Outbreak Response Reserve Charter and Deployment Protocol

**ID:** 231af72c-c6ba-4578-99ef-6b9158b0d5f4

**Description:** Establishes the USD 500M–USD 1B independent Outbreak Response Reserve in escrow; specifies trigger criteria ('confirmed SALB incursion in currently-free region,' defined as 2-step laboratory confirmation: initial positive PCR + confirmatory DNA sequencing or culture isolation), deployment authorization (Secretariat Executive Director, authorization within 24 hours for up to USD 100M, full amount USD 500M–USD 1B within 1 week), compensation schedules (tree-removal payments, fungicide stockpiles, smallholder income bridges, quarantine-zone operations), governance, and separation from gate-tranches logic. Primary audience: Secretariat, funders, producer governments, emergency-response operatives.

**Responsible Role Type:** Contingency-Reserve Architecture and Financial Stress-Testing Expert; Multilateral Secretariat Executive Director

**Primary Template:** World Bank Emergency Response and Contingency Planning framework; comparable: parametric-insurance trigger documentation

**Secondary Template:** FAO emergency fund governance protocols

**Steps:**

- Design reserve architecture and trigger logic by Month 1 (2026-11-08); commission legal review of escrow arrangement
- Specify compensation rules (tree-removal payment formula, fungicide cost-sharing, smallholder income-bridge amounts) by Month 2 (2026-12-08)
- Establish escrow account and fund USD 500M–USD 1B by Month 3 (2027-01-08); publish Charter and trigger protocol to all stakeholders
- Conduct tabletop exercise simulating Month 48–60 (2030-10-08 to 2031-10-08) incursion scenario by Month 12 (2027-10-08) to validate deployment readiness

**Approval Authorities:** Multilateral Secretariat Board, funders (sovereign and development banks), legal counsel (escrow trustee)

### 3. SALB Containment Protocol (IPPC-Framework Standard and Regional Compact Versions)

**ID:** 1bfcb4ce-75c7-4b18-854e-c738a8908a76

**Description:** Two-track containment instrument: (1) Formal IPPC International Standard for Phytosanitary Measures (ISPM), specifying nursery-stock movement rules (≥3-month quarantine, pathogen testing, certification criteria), research-material controls (export permits, import licensing, containment levels), and contaminated-equipment decontamination procedures (chemical/thermal treatments, inspection frequency); (2) Provisional Regional Compacts (Asia 8–10 countries, Africa 4–6 countries) with reciprocal inspection rights and shared quarantine facilities, operationalized by Month 24 (2028-10-08) as interim adoption pending formal IPPC approval. Primary audience: national plant protection organizations, IPPC Secretariat, producer governments, quarantine inspectors.

**Responsible Role Type:** Phytosanitary Standards and Protocol Lead

**Primary Template:** IPPC standards-setting process (ISPM format); FAO technical guidance

**Secondary Template:** Regional phytosanitary agreement templates (ASEAN, ECOWAS, Mercosur models)

**Steps:**

- Commission technical working group (Brazil, 5+ producing countries, IPPC, FAO) at Month 0 (2026-10-08) to draft protocol specifications (≤120 pages with numeric thresholds)
- Deliver formal IPPC proposal to IPPC Secretariat by Month 18 (2028-04-08); anticipated IPPC adoption timeline Months 36–60 (2029-10-08 to 2031-10-08)
- Negotiate bilateral access agreements pre-clearing collection sites and movement rules in all 15+ producing countries by Month 24 (2028-10-08)
- Establish provisional regional compacts (Asia and Africa) by Month 24 (2028-10-08) with binding adoption pledges from ≥15 countries by Month 24 (2028-10-08)

**Approval Authorities:** IPPC Secretariat (formal standard track), national plant protection organizations (≥15 countries), regional plant protection organizations (ASEAN, ECOWAS, Mercosur)

### 4. Resistance Breeding Strategy and Virulence Gate Enforcement Framework

**ID:** 207f21d0-0742-4906-86c0-b257bf820031

**Description:** High-level strategy document specifying the core breeding architecture: pyramiding of ≥3 independent resistance genes from ≥2 geographic sources per cultivar; mandatory Virulence Gates at Months 24, 36, 48, 60 (2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08); pass criteria (resistant to ≥80% of ≥10 contemporary SALB isolates); binding enforcement of gates as sub-criteria in Year 7 and Year 12 cultivar-readiness gates; bar on single-R-gene cultivars from release under any circumstance; annual Pathogen Population Reports forecasting resistance durability. Primary audience: breeding consortiums, Pathogen Genomics Lab, Technical Panel, funders.

**Responsible Role Type:** Hevea Resistance Breeding Program Director

**Primary Template:** CGIAR breeding strategy documents; Embrapa/CIRAD Hevea breeding protocols

**Secondary Template:** Pathogen-management breeding guidelines (similar to CIMMYT maize-breeding durability frameworks)

**Steps:**

- Commission Pathogen Genomics Laboratory in Brazil by Month 2 (2026-12-08); recruit senior mycologist and bioinformatician; design virulence-sequencing and challenge-testing protocols
- Establish Asian satellite facility by Month 9 (2027-07-08); finalize Virulence Gate pass/fail logic and evidence standards by Month 3 (2027-01-08)
- Draft breeding strategy embedding Virulence Gates as binding sub-criteria in Technical Gate Charter (Month 3 = 2027-01-08)
- Deliver first annual Pathogen Population Report by Month 12 (2027-10-08); publish Virulence Gate results at Months 24, 36, 48, 60 (2028-10-08 to 2031-10-08)

**Approval Authorities:** Hevea Resistance Breeding Program Director, Pathogen Genomics Lab leadership, Technical Panel, year 7 and year 12 gate decision-makers

### 5. Smallholder Adoption and Surveillance Incentive Framework

**ID:** c9de572c-b305-4933-bd66-38c180af8301

**Description:** Comprehensive strategy integrating replanting finance (7–10 year loans, 3–4% interest, conditional on certified clean stock), outcome-based surveillance premiums (USD 50–100 per verified disease report, paid within 30 days), clean-plant-network eligibility linkage (only farms with ≥90% clean-plant practices receive loans and premium access), and income-bridge provisions. Specifies pilot design (3–5 zones, 500–1,000 farmers per zone, Months 6–24 = 2027-04-08 to 2028-10-08), participation targets (≥60% by Month 18 = 2028-04-08), payment mechanisms (SMS-based mobile transfer), and scale-up roadmap (2–3 million farmers by Month 120 = 2036-10-08). Primary audience: smallholder cooperatives, rural banks, national agriculture ministries, replanting-finance implementers.

**Responsible Role Type:** Smallholder Adoption and Surveillance Incentives Manager

**Primary Template:** World Bank Conditional Cash Transfer (CCT) and agricultural credit frameworks; CGIAR smallholder-engagement guidelines

**Secondary Template:** FAO outcome-based extension and farmer-payment protocols

**Steps:**

- Design outcome-based surveillance premium scheme by Month 3 (2027-01-08): specify payment amounts (USD 50–100 per verified report), payment speed (30 days), and eligibility conditions (clean-plant maintenance, participation frequency)
- Select 3–5 pilot zones and local partner cooperatives by Month 6 (2027-04-08); draft pilot implementation manual by Month 8 (2027-06-08)
- Deploy digital disease-reporting platform and mobile-payment integration by Month 6 (2027-04-08); establish baseline farmer enrollment by Month 8 (2027-06-08)
- Conduct mid-pilot review at Month 18 (2028-04-08); if participation ≥60%, commit to scaling by Month 120 (2036-10-08); if <40%, redesign premium structure and extend pilot

**Approval Authorities:** Smallholder-engagement lead, rural finance partners, producer-country agricultural ministries, replicating finance implementers

### 6. Alternative Rubber (Guayule and Russian Dandelion) Commercial Strategy and Hub Development Framework

**ID:** 0868b07d-2c0a-480b-9fa3-a877ad7b8d0f

**Description:** Strategy document specifying: pilot-site agronomic trials (3–4 guayule sites in arid zones, 3–4 Russian dandelion sites in temperate zones) to validate yield, water use, and pest tolerance; small-scale processing pilots (Months 12–30 = 2027-10-08 to 2029-04-08) to prove extraction cost and tire-grade quality; hub siting (grower-proximate cooperatives vs. OEM-proximate centralized) and financing split (50% program, 50% offtake-backed debt); OEM buyer consortium engagement and co-funded qualification testing; Year 7 gate criteria (cost within 20% of reference = ≤USD 1.62/kg, tire-grade tests ≥95% of specs); hub construction approval rule (≥80% priced offtake committed before construction). Primary audience: hub developers, OEM procurement, alternative-crop breeders, offtake negotiators.

**Responsible Role Type:** Alternative Rubber (Guayule and Russian Dandelion) Commercial Lead

**Primary Template:** Bridgestone Americas and Continental Taraxagum project technical reports; USDA ARS guayule agronomy guidelines

**Secondary Template:** FAO alternative-crop and agro-processing feasibility frameworks

**Steps:**

- Commission site-selection studies and agronomy feasibility assessments in all target regions (arid for guayule, temperate for dandelion) by Month 3 (2027-01-08)
- Establish pilot agronomic trials at 3–4 sites per crop by Month 12 (2027-10-08); begin small-scale processing trials by Month 12 (2027-10-08), results by Month 30 (2029-04-08)
- Draft hub design specifications (capacity, colocated extraction, processing, co-product separation) and financing roadmap by Month 12 (2027-10-08)
- Engage OEM buyer consortium on tire-grade specifications and co-fund qualification testing by Month 18 (2028-04-08); secure 2–3 OEM offtake intent letters by Month 18 (2028-04-08)
- Prepare cost-parity evidence package for Year 7 gate (Month 84 = 2033-10-08); if cost ≤USD 1.62/kg and specs ≥95%, approve hub construction; otherwise, defer and redirect R&D

**Approval Authorities:** Alternative Rubber Commercial Lead, OEM buyer consortium, hub developers, Year 7 gate decision-makers

### 7. OEM Buyer Consortium Charter and Offtake Framework

**ID:** 83f1ae97-a740-4051-b3b9-1f54edd3c222

**Description:** Establishes consortium governance (5–8 major tyre manufacturers and rubber-goods OEMs); specifies take-or-pay offtake milestones: 2–3 letters of intent (Month 18 = 2028-04-08, 500–2,000 t/yr per OEM), binding priced offtake for ≥80% of planned volume (Month 72 = 2032-10-08); defines co-funded qualification-testing scope (tire-grade validation, cost-competitiveness verification, supply-chain traceability); sets price-formula assumptions (linked to natural-rubber reference, +15–20% premium for alternatives and resistant cultivars); and specifies hub-construction approval gate rule (no construction before ≥80% offtake commitment). Primary audience: OEM procurement teams, hub developers, Secretariat financing negotiators.

**Responsible Role Type:** OEM Supply-Chain Resilience and Procurement Officer

**Primary Template:** GPSNR (Global Platform for Sustainable Natural Rubber) buyer-commitment templates; comparable: multi-stakeholder certification schemes (FSC, RSPO models)

**Secondary Template:** AIFC (African Industrial Fisheries Consortium) take-or-pay contract formats

**Steps:**

- Establish consortium by Month 6 (2027-04-08); recruit 5–8 major OEMs through bilateral outreach and industry associations
- Commission co-funded qualification-testing roadmap by Month 9 (2027-07-08); agree on tire-grade specifications, test protocols, and cost-sharing split by Month 12 (2027-10-08)
- Solicit 2–3 letters of intent (indicating interest in 500–2,000 t/yr conditional on cost and quality validation) by Month 18 (2028-04-08)
- Draft binding offtake framework (price formula, volume commitments, take-or-pay terms, penalty clauses) by Month 48 (2030-10-08); finalize ≥80% volume commitment by Month 72 (2032-10-08)
- Execute co-branded flagship product agreements (specialty guayule latex, hypoallergenic goods, or SALB-proof tire line) to create consumer/brand pull for adoption

**Approval Authorities:** OEM procurement leaders, consortium members, Secretariat, Year 7 gate decision-makers (ifftake insufficient, defer hub construction)

### 8. Brazil Germplasm Bank and Nagoya Protocol Access-and-Benefit-Sharing Agreement Suite

**ID:** 85ca5b64-9377-4c7b-93e5-6e1b249641aa

**Description:** Establishes Brazilian Germplasm Bank (colocated at CEPLAC Manaus or Embrapa station, 500+ m² containment greenhouse, diagnostic laboratory with DNA sequencing capacity ≥20 isolates/month, cold-storage facilities for ≥3,000 accessions) and specifies ≥6 bilateral access-and-benefit-sharing (ABS) agreements with Brazilian states (Amazonas, Rondônia, Acre, Mato Grosso do Sul) and indigenous/traditional-community organizations, pre-clearing ≥200 wild Hevea collection sites and 2–3 annual campaigns per site. Defines royalty distribution (≥3% of cultivar sales to community fund over 10-year post-release life), capacity-building commitments (≥100 community members trained by Month 36 = 2029-10-08), community governance seats (≥2 representatives on breeding steering committee), and dispute-resolution mechanisms (arbitration, 6-month timeline). Primary audience: Brazilian authorities, indigenous organizations, breeding consortiums, Secretariat.

**Responsible Role Type:** Hevea Resistance Breeding Program Director

**Primary Template:** CBD (Convention on Biological Diversity) Nagoya Protocol model clauses; Brazilian SisGen (Sistema Nacional de Gestão do Patrimônio Genético) documentation

**Secondary Template:** CGIAR benefit-sharing policy templates

**Steps:**

- Establish Nagoya Protocol Task Force (Brazil Ministry of Environment, indigenous-affairs ministry, state representatives, community delegates) by Month 2 (2026-12-08)
- Conduct stakeholder-engagement and benefit-sharing framework design by Month 3 (2027-01-08); identify priority collection sites and community partners by Month 4 (2027-02-08)
- Negotiate bilateral agreements with each state and indigenous organization by Month 6 (2027-04-08); target 6 signed agreements by Month 6 (2027-04-08)
- Establish Germplasm Bank facilities (greenhouse, lab, storage) by Month 12 (2027-10-08); begin collection campaigns by Month 8 (2027-06-08)
- Deliver ≥200 characterized accessions (with resistance phenotype, genetic markers, and ABS documentation) to breeding consortiums by Month 18 (2028-04-08)
- Publish annual benefit-sharing report (Month 24, 36, 48 = 2028-10-08, 2029-10-08, 2030-10-08, etc.) showing royalties paid, capacity investments, and community satisfaction

**Approval Authorities:** Brazilian Ministry of Environment, indigenous-affairs ministry, state governments, community organizations, Embrapa/CEPLAC leadership

### 9. Pathogen Genomics and Virulence Tracking Laboratory Operational Framework

**ID:** 0cb7aded-8077-4d79-a1ae-4313736018a4

**Description:** Establishes two Pathogen Genomics Laboratories: Brazil (CEPLAC Manaus, by Month 2 = 2026-12-08) and Asian satellite (Malaysia, Indonesia, or Thailand, by Month 9 = 2027-07-08), each equipped for annual whole-genome sequencing of ≥100–150 SALB isolates, real-time PCR detection, pathogen phylogenetic analysis, virulence-gene mapping, and controlled inoculation-challenge assays. Specifies annual reporting (Pathogen Population Reports analyzing virulence-gene frequency, geographic differentiation, and resistance-breakdown probability forecasts), data-sharing protocols (6-month embargo for generating lab, open publication thereafter), and linkage to Virulence Gate decisions at Months 24, 36, 48, 60 (2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08). Primary audience: Pathogen Genomics Lab staff, breeding consortiums, Technical Panel, Year 7 and Year 12 gate decision-makers.

**Responsible Role Type:** Pathogen Genomics and Virulence Tracking Scientist

**Primary Template:** CEPLAC and Embrapa operational manuals for SALB research; comparable CGIAR pathogen-monitoring frameworks (e.g., IITA for cassava brown streak virus)

**Secondary Template:** FAO plant health diagnostics protocols

**Steps:**

- Identify lab sites (Brazil: CEPLAC Manaus or Embrapa station; Asia: Rubber Research Institute Malaysia or Indonesian Rubber Research Institute) by Month 1 (2026-11-08)
- Design sequencing, bioinformatics, and inoculation-assay protocols by Month 2 (2026-12-08); procure equipment and recruit staff (senior mycologist, bioinformatician, technicians) by Month 2 (2026-12-08)
- Commission Brazil lab by Month 2 (2026-12-08); establish Asian satellite by Month 9 (2027-07-08)
- Conduct annual isolate collection, sequencing, and virulence phenotyping from Month 12 (2027-10-08) onwards; publish first annual Pathogen Population Report by Month 12 (2027-10-08)
- Execute Virulence Gate assessments (challenging candidates against ≥10 isolates) at Months 24, 36, 48, 60 (2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08); feed results into breeding advancement decisions

**Approval Authorities:** Pathogen Genomics Lab directors (Brazil and Asia), Hevea Breeding Program Director, Technical Panel

### 10. Multilateral Secretariat Governance Charter and Institutional Framework

**ID:** 2c16f97d-9159-4968-ba6f-b001db60f3f5

**Description:** Establishes independent multilateral secretariat as autonomous institution with: binding board of 6–8 producer-country representatives, 3–4 OEM representatives, 3–4 development-bank representatives, and 3–4 independent technical experts (no faction holding majority); decision-making rules for capital release (major-funder consensus, supermajority 70%+ for strategy change); Technical Panel independence safeguards (conflict-of-interest policies, 5-year staggered terms, public-interest disclosure); staff recruitment and continuity (professional, long-term employment contracts, succession planning); financial management (ring-fenced tranches, transparent accounting); communications and stakeholder engagement (annual reports, 60-day pre-gate evidence publication, 30-day public challenge, 30-day appeals response). Primary audience: board members, secretariat staff, funders, producers, OEMs, Technical Panel, stakeholders.

**Responsible Role Type:** Multilateral Secretariat Executive Director and Governance Lead

**Primary Template:** World Bank Multilateral Trust Fund governance documents; comparable: CGIAR Consortium governance charter

**Secondary Template:** United Nations agency governance frameworks (UNEP, FAO models)

**Steps:**

- Draft secretariat charter and governance bylaws by Month 1 (2026-11-08); specify board composition, decision rules, Technical Panel structure, and institutional independence
- Conduct stakeholder consultation (funders, producers, OEMs) by Month 2 (2026-12-08); finalize and execute charter signatures by Month 3 (2027-01-08)
- Recruit Executive Director and core secretariat staff by Month 3 (2027-01-08); establish offices in Geneva/Rome (headquarters) and regional hubs (Brasília, Jakarta, Abidjan, etc.) by Month 6 (2027-04-08)
- Recruit independent Technical Panel (7–9 members, conflict-free) by Month 3 (2027-01-08); publish panel roster and conflict-of-interest disclosures by Month 4 (2027-02-08)
- Establish digital transparency infrastructure (evidence repository, public portal, gate-decision tracking) by Month 6 (2027-04-08)

**Approval Authorities:** Founding funders (sovereigns, development banks), producer governments (≥15), OEM consortium, Technical Panel, international legal counsel

### 11. Combined-Stress Financial Scenario and Fallback Cascade Framework

**ID:** fbca08de-b6fd-448e-8e8c-9cb91c900b90

**Description:** Models combined catastrophic-stress scenarios: simultaneous full SALB outbreak residual (USD 1.5–4.5B), resistance-breeding re-cycle (USD 0.4–0.8B), alternative-rubber remediation (USD 0.5–1.0B) claims totaling USD 2.4–6.3B against USD 4.5B contingency pool, revealing a USD 1.8B shortfall gap at high-end stress. Specifies trigger thresholds and fallback-funding cascades: if levy compliance <60% by Month 48 (2030-10-08), activate higher development-bank loan-to-grant ratio (raise from 25% to 40% of capital stack); if combined stress exceeds USD 4.5B, authorize outcome-linked bond issuance (target USD 1–2B), climate-finance blending, and strategic prioritization (e.g., defer non-critical R&D, accelerate cultivar-royalty revenue). Primary audience: Secretariat finance team, funders, risk-management committee.

**Responsible Role Type:** Contingency-Reserve Architecture and Financial Stress-Testing Expert; Multilateral Secretariat Executive Director

**Primary Template:** World Bank financial risk-management frameworks; comparable: catastrophic-risk scenario documents (climate adaptation, pandemic preparedness models)

**Secondary Template:** IMF stress-testing methodologies

**Steps:**

- Commission stochastic financial model incorporating biological-timeline uncertainty (breeding slippage, virulence evolution, alternative-crop cost drift) and market uncertainty (levy collection, price volatility) by Month 6 (2027-04-08)
- Model 10,000+ Monte Carlo iterations covering low, baseline, and high-stress scenarios by Month 9 (2027-07-08); quantify probability distributions for each pillar's costs and timelines
- Identify trigger thresholds (e.g., 'if cultivar-readiness slips beyond Month 100 = 2035-02-08, alternative-rubber pillar absorbs +USD 200M R&D') and fallback cascades by Month 12 (2027-10-08)
- Present scenario findings and fallback options to board and funder risk committees by Month 12 (2027-10-08); obtain pre-authorization for fallback triggers by Month 24 (2028-10-08)
- Update model annually (Months 24, 36, 48 = 2028-10-08, 2029-10-08, 2030-10-08, etc.) as real pilot data emerges; adjust trigger thresholds and cascade options based on updated risk profile

**Approval Authorities:** Multilateral Secretariat Board, major funders (sovereigns, development banks), risk-management committee

### 12. Year 3 Protocol Readiness Gate Evidence Package and Decision Framework

**ID:** ea0420f0-87d1-47ff-b7d6-f2bbfa715514

**Description:** Comprehensive evidence compilation for the Month 36 (2029-10-08) gate assessing: (1) containment-protocol adoption in ≥15 producing countries with binding import rules in national law (document list of countries, legal instruments, implementation dates); (2) inspector training and audit in ≥500 personnel across ≥50 inspection checkpoints, with certification records and competency assessments; (3) laboratory-cleared suspect detections (≥2 documented isolates identified as P. ulei through 2-step confirmation: PCR + sequencing/culture); (4) regional minimum coverage (Asia ≥8 countries, Africa ≥4, Americas ≥3); (5) digital reporting platform operational in all checkpoint zones; (6) Containment Efficacy Review checkpoint status (baseline for Months 72–84 = 2032-10-08 to 2033-10-08 assessment). Specifies partial-achievement release rules (85–100% criteria = 100% tranche USD 4.5B; 70–85% = proportional release; <70% = 50% release USD 2.25B to contingency). Primary audience: Technical Panel, funders, gate-decision makers.

**Responsible Role Type:** Technical Panel and Gate Assessment Coordinator

**Primary Template:** World Bank Development Policy Financing (DPF) gate-assessment documentation format

**Secondary Template:** CGIAR gate-evidence compendium templates

**Steps:**

- Design evidence-collection template and data-submission procedures by Month 30 (2029-04-08)
- Request data from all 15+ producing countries by Month 34 (2029-08-08); compile country-by-country evidence (legal instruments, inspector rosters, checkpoint listings, sample-result spreadsheets) by Month 35 (2029-09-08)
- Conduct third-party audit of ≥30% of inspector credentials and checkpoint operations by Month 35 (2029-09-08) to verify data quality
- Publish complete evidence package (all raw data, analyses, audit findings) on public portal by Month 30 (2029-04-08) (60 days pre-gate); open 30-day public challenge period
- Address stakeholder comments and appeals by Month 35 (2029-09-08); finalize Technical Panel recommendation by Month 35 (2029-09-08)
- Execute gate decision (tranche release authorization) by Month 36 (2029-10-08); publish decision rationale and any partial-release justification within 7 days

**Approval Authorities:** Technical Panel, Multilateral Secretariat Board, major funders (decision authority for tranche release)

### 13. High-Containment SALB Trial Station Commissioning Framework

**ID:** a2d880a2-9315-4b15-959d-4d961b32d9f0

**Description:** Specifies the design, construction, and operational requirements for ≥4 high-containment SALB trial stations (budget USD 3–5M per station, USD 12–20M total capital): ≥2 live-pathogen stations in endemic Latin America (Rondônia and Peru) with screened greenhouse complex (1,000–2,000 m²), open-field trial blocks (10–15 hectares, 50-meter pathogen-free buffer zones), real-time pathogen laboratory (PCR, sequencing, ≥50 samples/week throughput), quarantine equipment (autoclave, chemical decontamination, spore-disposal systems); ≥1 clean-zone station in Asia, ≥1 in Africa (no live SALB, greenhouse trials only, autoclaved inoculum as positive control). Specifies site-selection criteria, environmental permits, biosafety certification, staff recruitment, equipment procurement, and operational timeline (sites approved by Month 12 = 2027-10-08, commissioned by Month 18 = 2028-04-08). Primary audience: trial-station project managers, site-host countries, Hevea breeding consortiums.

**Responsible Role Type:** Hevea Resistance Breeding Program Director; Resistance Field-Trial Geography and Biosafety Siting Expert

**Primary Template:** Embrapa/CEPLAC field-station design standards; comparable: CIMMYT quarantine-breeding facilities

**Secondary Template:** FAO biosafety guidelines for pest/disease research facilities

**Steps:**

- Identify potential host sites and conduct environmental/biosafety assessment by Month 3 (2027-01-08)
- Negotiate bilateral agreements with Brazil (Rondônia and Peru), Asian partner country, and African partner country by Month 6 (2027-04-08); secure land-use commitments and environmental permits by Month 9 (2027-07-08)
- Procure equipment and contract construction by Month 9 (2027-07-08); begin site preparation by Month 10 (2027-08-08)
- Recruit and train site managers, laboratory technicians, and phytosanitary inspectors by Month 12 (2027-10-08)
- Commission all four stations by Month 18 (2028-04-08); conduct baseline pathogen inoculation trials by Month 20 (2028-06-08); ready for candidate-cultivar screening by Month 24 (2028-10-08)

**Approval Authorities:** Host-country governments (Rondônia/Peru, Asia, Africa), environmental authorities, biosafety certification bodies, Hevea Breeding Program Director

### 14. Pathogen Population Genomics Annual Report Template and Publication Schedule

**ID:** 38f30b98-d9c0-42ee-9382-7a3118d14624

**Description:** Specifies annual reporting framework (Months 12, 24, 36, 48, 60, 72, 84, 96 = 2027-10-08, 2028-10-08, etc.) analyzing SALB pathogen population genetics: virulence-gene frequency trends across endemic regions, phylogenetic differentiation, geographic population structure, and forecasts of resistance-breakdown probability for candidate cultivars based on virulence-gene data. Each report estimates time-to-breakdown for single-R-gene vs. multi-R-gene cultivars, informs breeding-strategy pivots, and directly feeds into Virulence Gate assessments. Specifies data-sharing rules (6-month embargo for generating lab, open publication thereafter via peer-reviewed journal and program website). Primary audience: breeding consortiums, Pathogen Genomics Labs, Technical Panel, year-7 and year-12 gate decision-makers.

**Responsible Role Type:** Pathogen Genomics and Virulence Tracking Scientist

**Primary Template:** International Journal of Phytopathology standard structure; comparable: annual pathogen-monitoring reports from CGIAR pathogen-tracking programs

**Secondary Template:** CEPLAC/Embrapa annual research reports

**Steps:**

- Design annual report template (data sections, visualization standards, forecast methodology) by Month 6 (2027-04-08)
- Collect isolate samples from trial sites, endemic regions, and trade channels throughout each year
- Conduct whole-genome sequencing, phylogenetic analysis, and virulence-phenotyping by Month 10 (2027-08-08) of each year (e.g., Month 10 = 2027-08-08 for Year 1)
- Draft annual report (Month 11 = 2027-09-08 target) with virulence trends, geographic differentiation, and resistance-breakdown forecasts; submit to breeding consortiums by Month 12 (2027-10-08)
- Publish open-access version (peer-reviewed journal or program website) 6 months after first circulation to generating labs (Month 18 = 2028-04-08 for Month 12 = 2027-10-08 report)

**Approval Authorities:** Pathogen Genomics Lab directors, Technical Panel (for gate interpretation), breeding consortiums

### 15. Hevea Wild Germplasm Collection and Characterization Protocol

**ID:** 1c8c019c-8019-4da7-ab29-b706a3a0ce29

**Description:** Operational protocol for Brazil-led wild Hevea collection campaigns under Nagoya Protocol compliance: specifies sampling sites (≥200 sites pre-cleared by Month 6 = 2027-04-08 via bilateral ABS agreements), collection teams (indigenous and traditional-community members as 50%+ of team), sample size targets (200–250 accessions per year), sampling methods (healthy whole plants or seeds, GPS-tagged, phenologically diverse), preliminary SALB-resistance screening (incompatibility tests against 2–3 representative fungal strains at CEPLAC Manaus), genetic characterization (molecular markers for Hevea phylogeny and resistance-candidate loci), and passport documentation (accession ID, GPS, collection date, collector names, community benefit-sharing record). Delivery target: ≥200 characterized accessions to breeding consortiums by Month 18 (2028-04-08). Primary audience: Brazilian collection teams, Germplasm Bank, breeding consortiums.

**Responsible Role Type:** Hevea Resistance Breeding Program Director; Germplasm-Collection Coordinator

**Primary Template:** Embrapa gene-bank collection protocols; comparable: CGIAR germplasm-collection standards (CIMMYT, IRRI models)

**Secondary Template:** CBD Nagoya Protocol sampling and documentation guidelines

**Steps:**

- Establish collection team and train samplers on field methods and ABS documentation by Month 6 (2027-04-08)
- Conduct first collection campaign in Rondônia/Amazonas (Months 8–12 = 2027-06-08 to 2027-10-08), target ≥60–80 accessions; second campaign (January–March 2028, Months 15–17 = 2028-01-08 to 2028-03-08), ≥60–80 accessions
- Perform preliminary SALB incompatibility tests at CEPLAC Manaus on all accessions by Month 14 (2027-12-08) for first batch; Month 26 (2028-12-08) for second batch
- Conduct genetic characterization and molecular-marker analysis by Month 16 (2028-02-08) for first batch; by Month 28 (2029-02-08) for second batch
- Deliver ≥200 fully characterized accessions (passport data, resistance phenotype, molecular markers, ABS documentation) to breeding consortiums by Month 18 (2028-04-08)

**Approval Authorities:** Brazilian Ministry of Environment, state governments, indigenous/traditional-community organizations, Embrapa/CEPLAC leadership

### 16. Adaptive Tranching and Contingency-Reallocation Rules Framework

**ID:** c9a06700-3588-401f-8488-446063d3b716

**Description:** Operational framework specifying: (1) how year 3, 7, 12, and 18 gate KPI attainment percentages (70–100% of criteria) translate to tranche-release percentages (70–100% of allocated tranches), (2) how under-attainment (e.g., 75% of criteria met) triggers partial release (75% of tranches, remainder to contingency pool) and reallocation logic (reallocate remainder to strongest-performing pillar based on Technical Panel assessment), (3) contingency-pool governance (10–15% of each phase-gate tranches held in reserve, reallocable post-gate), (4) priority-ranking rules if multiple pillars underperform (e.g., if both breeding and alternative rubber slip, which gets priority reallocation?), (5) appeal and override procedures (supermajority board decision can override reallocation). Ensures adaptive management responds to biological delays without arbitrary gate reversals. Primary audience: Technical Panel, Secretariat finance team, funders, producers.

**Responsible Role Type:** Contingency-Reserve Architecture and Financial Stress-Testing Expert; Multilateral Secretariat Executive Director

**Primary Template:** World Bank Adaptive Program Lending (APL) framework; comparable: CGIAR contingency-fund management guidelines

**Steps:**

- Draft reallocation rules by Month 2 (2026-12-08) specifying how KPI percentages map to tranche releases (e.g., 85–100% criteria = 100% release; 70–85% = proportional; <70% = 50% release)
- Define pillar-priority ranking (e.g., 'containment underperformance has highest priority for reallocation; breeding and alternatives are co-equal') and justification based on program theory
- Specify appeal mechanisms (e.g., 'if a producer government disputes reallocation and demonstrates alternative calculation, Technical Panel has 30 days to reconsider') by Month 3 (2027-01-08)
- Embed reallocation rules into the Technical Gate Charter (signed Month 3 = 2027-01-08) so they are binding on all parties
- Publish reallocation decisions and rationales 30 days after each gate to maintain transparency

**Approval Authorities:** Technical Panel, Multilateral Secretariat Board, major funders (decision on reallocation precedence)

### 17. Climate Adaptation and Climate-Shock Resilience Breeding Strategy

**ID:** 1663d421-c411-4a93-88c5-ab40dcaf5d09

**Description:** Strategy specifying how SALB-resistant Hevea cultivars will also incorporate climate-adaptation traits (drought tolerance, heat stress, shifted growing-season phenology) to hedge against temperature and rainfall changes 2026–2050 in tropical rubber zones. Defines: (1) climate-vulnerability assessment of rubber-growing regions (temperature and rainfall projections at +1.5–2°C warming), (2) secondary traits to breed alongside resistance (drought-tolerance genes, heat-stress tolerance), (3) climate-stress testing protocols for candidate cultivars (inoculation under modeled drought/heat conditions), (4) Year 7 gate climate-viability criterion (candidates remain viable under +1.5°C, +2°C scenarios), (5) climate-adaptation R&D budget (USD 5–15M within breeding pillar). Reduces residual vulnerability if climate shifts make traditional tropical-zone growing marginal, and ensures resistant cultivars are also climate-resilient. Primary audience: breeding consortiums, Technical Panel, climate-risk specialists.

**Responsible Role Type:** Hevea Resistance Breeding Program Director; Climate Risk and Environmental Officer

**Primary Template:** CGIAR climate-adaptation breeding frameworks; comparable: CIMMYT/ICRISAT drought-tolerance breeding strategies

**Steps:**

- Commission climate-risk modeling (Months 3–12 = 2027-01-08 to 2027-10-08) to forecast temperature, rainfall, and growing-season changes in rubber zones by 2050; identify highest-risk regions and adaptation priorities
- Identify available climate-adaptation traits in wild Hevea germplasm or breeding libraries by Month 12 (2027-10-08); prioritize top 2–3 climate traits (e.g., drought tolerance, heat tolerance) for pyramiding with SALB resistance
- Design climate-stress phenotyping protocols by Month 12 (2027-10-08): inoculate candidate cultivars under controlled drought (2-in-20-year rainfall) and heat (+1.5–2°C ambient) conditions; measure yield and resistance stability
- Integrate climate-screening results into Year 7 gate criteria: require candidates to show acceptable performance under modeled climate stress, not just baseline conditions
- Allocate USD 5–15M for climate-adaptation R&D within the breeding budget (Years 0–7)

**Approval Authorities:** Hevea Breeding Program Director, climate-risk specialist, Technical Panel, Year 7 gate decision-makers

### 18. Institutional Handover and Post-Funding Sustainability Plan (Years 18–25 Transition Strategy)

**ID:** e55f66d0-e7ec-4895-b70c-c7eb1f69edbd

**Description:** Roadmap specifying how producer-country institutions (agriculture ministries, research institutes, plant protection organizations) transition from grant and external-funding dependency to self-sufficient, domestically-funded operations by Month 216 (2044-10-08). Defines: (1) institutional-readiness assessments by Month 144 (2038-10-08): staff numbers, training completeness, equipment ownership, domestic budget allocations, (2) sustainability models (national rubber-levy revenue, government budget line-items, cultivar royalties, clean-plant nursery revenue), (3) risk indicators for institutional collapse (staff turnover, budget cuts, political prioritization loss), (4) transition phases (Months 144–180 = 2038-10-08 to 2041-10-08: scale external funding down and domestic funding up; Months 180–216 = 2041-10-08 to 2044-10-08: full transition to domestic funding; Months 216+: post-program monitoring and evaluation), (5) contingency for insufficient readiness (if readiness <60% by Month 144 = 2038-10-08, extend external funding through Month 240 = 2046-10-08 with performance milestones). Addresses the critical risk that program-funded infrastructure collapses within 2–3 years of external funding ending. Primary audience: producer-country governments, development banks, Secretariat.

**Responsible Role Type:** Producer-Country Institutional Capacity and Technology Transfer Expert; Multilateral Secretariat Executive Director

**Primary Template:** World Bank project closure and sustainability frameworks; comparable: CGIARI transition and hand-over protocols

**Steps:**

- Commission institutional-readiness assessment framework by Month 60 (2031-10-08): define metrics for assessment (staff certifications, lab accreditations, equipment functioning, annual budget allocations) for each producer country
- Conduct baseline readiness assessment in all 15+ countries by Month 120 (2036-10-08); identify readiness gaps and design targeted capacity-building to close them by Month 144 (2038-10-08)
- Model sustainability finance for each country by Month 120 (2036-10-08): calculate required domestic budget to sustain inspectorates, clean-plant nurseries, and pathogen labs; estimate realistic revenue from national rubber levy, government budget, or cultivar royalties
- Develop country-by-country transition plans (Months 144–216 = 2038-10-08 to 2044-10-08) specifying domestic funding ramp-up and external funding phase-down; present plans to each country for negotiation by Month 130 (2037-08-08)
- Conduct Sustainability Gate assessment at Month 216 (2044-10-08): score each country's readiness to operate independently; if readiness ≥80%, approve transition to post-program monitoring; if <60%, recommend extended external support through Month 240 (2046-10-08)

**Approval Authorities:** Producer-country governments, development banks, Multilateral Secretariat Board

### 19. Fallback Funding Cascade and Outcome-Linked Financing Framework

**ID:** 2e5c07eb-c75c-4496-b97c-49f5637f95a3

**Description:** Specifies pre-authorized fallback mechanisms if primary funding sources (sovereign grants, levy, development-bank lending) underperform: (1) Tier 1 fallback (if levy compliance 80–60% of target): increase development-bank loan-to-grant ratio from 25% to 35%, extending repayment terms and reducing near-term cash burden; (2) Tier 2 fallback (if levy <60% and need $500M+): issue outcome-linked bonds or results-based financing instruments repaid from cultivar royalties, alternative-rubber sales revenue, or parametric insurance payouts; (3) Tier 3 fallback (if combined stress claims exceed USD 4.5B contingency pool and normal funding insufficient): activate climate-finance blended mechanisms, risk-transfer instruments, or emergency funder-expansion. Specifies trigger dates for each cascade level (Month 48 = 2030-10-08 for Tier 1; Month 60 = 2031-10-08 for Tier 2; Month 80 = 2033-06-08 for Tier 3) and decision authorities. Ensures program does not collapse if single funding source fails; proactively reduces funder exit risk mid-program. Primary audience: Secretariat finance team, funders, investors.

**Responsible Role Type:** Capital Stack and Funding Mechanisms Designer

**Primary Template:** World Bank results-based financing frameworks; comparable: outcome-linked bond structures (climate finance, pandemic bonds)

**Secondary Template:** GFDRR (Global Facility for Disaster Reduction and Recovery) parametric insurance models

**Steps:**

- Design outcome-linked financing instruments by Month 12 (2027-10-08): specify repayment triggers (e.g., 'release USD 100M if Year 7 cultivar-readiness gate passes with ≥2 candidates'), term structures (20-year repayment from royalties), and investor risk-return profiles
- Identify potential bond investors and development-finance institutions willing to provide results-based capital by Month 18 (2028-04-08); preliminary term sheets by Month 24 (2028-10-08)
- Model climate-finance blending mechanisms (co-financing arrangements with Green Climate Fund, bilateral climate programs) by Month 12 (2027-10-08); contact potential climate-finance partners by Month 18 (2028-04-08)
- Establish fallback-trigger decision authority (e.g., 'if levy shortfall detected by Month 48 = 2030-10-08, Secretariat Board has 30 days to vote on Tier 2 activation') in Technical Gate Charter or Board Bylaws by Month 3 (2027-01-08)
- Conduct annual funding-performance reviews (Months 24, 36, 48 = 2028-10-08, 2029-10-08, 2030-10-08, etc.) to monitor whether cascades need activation

**Approval Authorities:** Multilateral Secretariat Board, major funders (decision on cascade activation), investment banks (if bonds issued)

## Documents to Find

### 1. IPPC International Standards for Phytosanitary Measures (ISPMs) Database and Adoption Timeline

**ID:** c7ef9d0c-64ca-4901-846a-1dab91ede02c

**Description:** Existing repository of adopted IPPC standards (currently >40 standards) and the IPPC standard-setting process documentation, including topic-submission procedures, technical-drafting-group timelines, Commission on Phytosanitary Measures (CPM) adoption cycles, and implementation-review timelines. Required to assess realistic standard-adoption windows for a new SALB Containment Protocol standard and align the program's two-tier strategy (formal IPPC route + provisional regional compacts). Source material for protocol-adoption timeline planning.

**Recency Requirement:** Current standards list and 2024–2025 standard-setting calendar; historical ISPM adoption timelines from past 5 years (comparable examples).

**Responsible Role Type:** Phytosanitary Standards and Protocol Lead

**Access Difficulty:** Easy. The IPPC Secretariat is a public body hosted by FAO in Rome, and standards are freely available on the public website. Direct contact with the Standards Unit can accelerate information on custom timelines and regional-strategy feasibility.

**Steps:**

- Access IPPC website (ippc.int): navigate to Standards / ISPMs section
- Download full ISPM compendium (PDF) and review adoption-cycle documentation
- Contact IPPC Secretariat (email: ippc@fao.org) to request: (1) estimated timeline for a new phytosanitary standard on SALB (from topic submission to CPM approval), (2) list of recent standards (past 5 years) and their adoption cycles, (3) guidance on parallel regional-compact strategies
- Review IPPC Implementation Review and Support System (IRSS) reports to identify countries with weak baseline phytosanitary capacity in target regions (Asia, Africa, Americas)

### 2. Current National Phytosanitary Laws and Import Rules in 15+ Rubber-Producing Countries

**ID:** 071d39f7-33a0-4d60-a85b-5a3252dd2aaa

**Description:** Existing national plant protection regulations in target producing countries (Indonesia, Malaysia, Thailand, India, Vietnam, Côte d'Ivoire, Ghana, Cameroon, Brazil, Peru, Ecuador, etc.), specifying nursery-stock movement rules, import-licensing procedures, quarantine requirements, and inspection authority. Required to assess legal gaps and harmonization needs for SALB Containment Protocol adoption, and to identify countries' current capacity for binding implementation. Raw material for the program's two-tier adoption strategy (formal IPPC-based standard + bilateral access agreements).

**Recency Requirement:** Current national regulations as of 2026–2027 (most recent published versions); amendments during 2023–2026 acceptable.

**Responsible Role Type:** Phytosanitary Standards and Protocol Lead

**Access Difficulty:** Medium. Official national regulations are typically public, but completeness and currency vary by country. Bilateral requests to national plant protection organizations may require formal diplomatic channels or development-partner introductions. Some weak-capacity countries (West Africa, South Asia) may have limited English-language documentation.

**Steps:**

- Contact national plant protection organizations in each target country (e.g., Indonesia's KEMENTAN, Malaysia's DAFFM, Thailand's DOA, India's APHIS, Brazil's MAPA) via official government websites or IPPC regional contact lists
- Request: (1) current national legislation on plant protection and nursery stock imports, (2) organizational structure and inspector count for quarantine/inspection, (3) budget allocation for phytosanitary services
- Search regional plant protection organization websites (ASEAN Secretariat, ECOWAS, Mercosur) for harmonized standards or model legislation
- Consult FAO Plant Production and Protection Division (AGPP) for comparative analysis of phytosanitary capacity in target regions

### 3. Hevea Breeding and SALB Resistance Research Data from Embrapa, CIRAD, and Rubber Research Institute of Malaysia

**ID:** 6f8746e9-1f65-4208-8d4c-da5eb6d53a31

**Description:** Existing research records on Hevea genetics, wild germplasm collections, SALB resistance traits, clone performance, and historical resistance failures (e.g., IAC cultivars, 1970s–1990s breakdown). Raw data on: (1) historic wild Hevea accessions held by Embrapa, CIRAD, RRIM, and IRRDB (International Rubber Research and Development Board), (2) resistance QTL mapping and marker data, (3) past cultivar releases and their agronomic performance, (4) documented pathogen virulence evolution. Required to define the breeding-strategy baseline, confirm the availability of existing germplasm as a contingency supply (if new wild collection slips), and validate the historical single-gene-failure risk that motivates the pyramiding requirement.

**Recency Requirement:** Existing germplasm-collection records (decades-old acceptable); recent breeding research publications (2015–2026); CEPLAC/Embrapa annual research reports (most recent 3–5 years).

**Responsible Role Type:** Hevea Resistance Breeding Program Director

**Access Difficulty:** Medium. Embrapa and CIRAD are open-access public research institutions; direct contact and data requests are straightforward. RRIM data is also publicly available but may require formal requests. Proprietary clone information (e.g., elite-line genetic maps) may be sensitive and require confidentiality agreements. Most publications are open-access or available via institutional repositories.

**Steps:**

- Contact Embrapa's rubber research unit (Embrapa Acre, Rondônia) via official website or through MAPA (Brazil Ministry of Agriculture) to request germplasm-collection inventory and resistance-trait data
- Contact CIRAD's agronomic research programs (UMR AGAP, tropical-crop genetics) to access historical Hevea breeding and resistance data, clone descriptions, and trial results
- Contact Rubber Research Institute of Malaysia (RRIM) to obtain clone catalogs, resistance assessments, and regional performance data for Southeast Asia
- Search Google Scholar, Web of Science for peer-reviewed publications on Hevea resistance genetics, SALB virulence evolution, and historic resistance failures (search terms: 'Hevea resistance SALB IAC failure,' 'Pseudocercospora ulei virulence', 'rubber resistance breeding QTL')
- Request IRRDB (International Rubber Research and Development Board) database access (if available) or summary statistics on global Hevea germplasm diversity

### 4. Guayule and Russian Dandelion Agronomic Performance and Processing Cost Data (Bridgestone Americas, Continental Taraxagum, USDA ARS)

**ID:** f32d313a-0aa1-4c55-9c4e-71da6c0cad99

**Description:** Existing technical and economic data on guayule and Russian dandelion cultivation, yield, water use, pest/disease tolerance, and processing costs at pilot scale. Includes: (1) Bridgestone Americas guayule research farm data (Eloy, Arizona), (2) Continental Taraxagum Russian dandelion project data (Anklam, Germany; Fraunhofer IME), (3) USDA ARS guayule agronomy research (Arid-Land Agricultural Research Center, Maricopa, Arizona), (4) historical cost estimates and processing-efficiency benchmarks. Required to validate alternative-rubber economics and set realistic Year 7 cost-parity gate thresholds (USD 1.62/kg cap), and to assess whether co-product revenue (resins, bagasse, inulin) can improve hub bankability.

**Recency Requirement:** Most recent pilot-project reports (2020–2026); agronomic trial results from 2018–2026; Bridgestone and Continental published updates and presentations from 2015–2026.

**Responsible Role Type:** Alternative Rubber (Guayule and Russian Dandelion) Commercial Lead

**Access Difficulty:** Medium. Bridgestone and Continental conduct commercial R&D alongside public outreach; published data (presentations, white papers, patent filings) are available but may be incomplete or delay-published (12–24 months after completion). USDA ARS data is public and accessible. Direct requests to companies may require formal introductions or development-partner sponsorship; public technical presentations and industry-conference papers are easier to access.

**Steps:**

- Contact Bridgestone Americas Guayule Program (Mesa/Eloy, Arizona) via corporate communications or Bridgestone's sustainability website to request: (1) agronomic trial data (yield, water use, pest incidence), (2) processing pilot results (extraction cost, resin recovery, tire-testing outcomes), (3) cost projections for commercial scale
- Contact Fraunhofer IME (Institute for Molecular Biology and Applied Ecology) via their website or the Taraxacum program team to request Russian dandelion agronomy data and processing-cost estimates
- Contact USDA ARS Arid-Land Agricultural Research Center (Maricopa, Arizona) to request guayule breeding and agronomy publications and field-trial datasets
- Search Google Scholar, ResearchGate for peer-reviewed publications on guayule agronomy (search: 'guayule yield water use Southwest'), Russian dandelion rubber extraction (search: 'Taraxacum koksaghyz rubber latex'), and tire-grade specification requirements
- Consult Yulex Corporation (commercial guayule processor) for processing technology and cost benchmarks

### 5. Global Natural Rubber Supply Chain Statistics and Price Data (Commodity Databases, FAO, USDA)

**ID:** f9db026f-65aa-4b59-8724-52c76822ae90

**Description:** Authoritative data on global natural-rubber production (by region, by country, smallholder vs. estate share), trade flows, consumption by end-use (tyre vs. other), price history (5–10 year timeseries), and demand projections. Sources include: (1) USDA Foreign Agricultural Service (FAS) rubber market reports, (2) FAO FAOSTAT agriculture databases, (3) Rubber Trade Association of Singapore (RTAS) trade statistics, (4) International Rubber Study Group (IRSG) market reports, (5) commodity-futures data (CBOT, ICE). Required to validate: (1) the reference Hevea price assumption (USD 1.35/kg), (2) leverage points for the industry levy (global trade volume, concentration of buyers/traders), (3) baseline demand for alternative rubber and resistant-cultivar plantings, (4) price-volatility scenarios for stressed smallholder-finance modeling.

**Recency Requirement:** Most recent annual statistics (2025, 2024); price data through 2026-Q3 (current as of project start); market-outlook reports 2025–2026; historical data (2010–2025) for trend analysis.

**Responsible Role Type:** Capital Stack and Funding Mechanisms Designer; Alternative Rubber (Guayule and Russian Dandelion) Commercial Lead

**Access Difficulty:** Easy. USDA FAS, FAO, and IRSG are public sources with free access. Commodity-futures data are publicly available through financial-data platforms (e.g., Yahoo Finance, Trading Economics). Some detailed IRSG market reports may require member access or purchase, but summary statistics are freely published.

**Steps:**

- Access USDA FAS website (fas.usda.gov) and navigate to 'Commodities' > 'Rubber' to download latest supply/demand reports, price forecasts, and regional production data
- Access FAO FAOSTAT (faostat.fao.org) and query 'Crops' > 'Primary' > 'Rubber' for global production by country (Indonesia, Malaysia, Thailand, India, Vietnam, Brazil, etc.) and time-series (2010–2025)
- Contact International Rubber Study Group (IRSG, based in Singapore) via their website (rubberstudygroup.org) to request annual market reviews, supply/demand balances, and price forecasts
- Search commodity-futures databases (CBOT, ICE, CME) for natural-rubber futures prices (NYBOT contracts) and volatility data (2010–2026)
- Consult Rubber Trade Association of Singapore (RTAS) for trade statistics and port-level price data

### 6. Existing National Plant Protection Organization Capacity and Budget Data (15+ Producing Countries)

**ID:** aa84c994-7451-431c-9578-64bf6fc6eb6f

**Description:** Current staffing, equipment, training levels, and budget allocations for plant protection and quarantine services in target producing countries (Indonesia, Malaysia, Thailand, India, Vietnam, Côte d'Ivoire, Ghana, Cameroon, Brazil, Peru, Ecuador, etc.). Includes inspector counts, checkpoint infrastructure, laboratory diagnostic capacity, equipment inventory, annual operational budgets, and identified capacity gaps. Raw input for: (1) assessing feasibility of Year 3 gate target (≥500 trained inspectors), (2) budgeting capacity-building costs within the containment pillar, (3) identifying weak-link countries requiring intensive twinning support.

**Recency Requirement:** Most recent national surveys (2024–2025) or official government ministry budgets (fiscal year 2025–2026); capacity assessments from development projects (if conducted 2022–2026).

**Responsible Role Type:** Phytosanitary Standards and Protocol Lead; Producer-Country Institutional Capacity and Technology Transfer Expert

**Access Difficulty:** Medium. National ministries have this information but may not proactively publish. Formal bilateral requests (via MAPA as the Brazil anchor or via multilateral development banks) are most effective. FAO reports are publicly available. Regional organization summaries may be in internal documents but can be requested via diplomatic channels.

**Steps:**

- Contact national plant protection organizations (MAPA Brazil, KEMENTAN Indonesia, DAFFM Malaysia, DOA Thailand, APHIS India, MINADER Cameroon, MINAGRI Côte d'Ivoire, etc.) with formal requests for: (1) current inspector roster and qualifications, (2) checkpoint and laboratory infrastructure inventory, (3) annual operational budget and funding sources, (4) strategic capacity plans (5-year outlook)
- Access World Bank project documents (if any recent plant-health projects in target countries) via World Bank's open-knowledge portal (openknowledge.worldbank.org), which often contain capacity assessments
- Consult FAO Plant Production and Protection Division (AGPP) reports on phytosanitary capacity in Asia, Africa, and Latin America (published ~5-yearly, most recent reports 2020–2025)
- Contact ASEAN, ECOWAS, and Mercosur secretariats for regional summaries of member-state phytosanitary capacity

### 7. South American Leaf Blight (SALB / Pseudocercospora ulei) Epidemiology, Geographic Distribution, and Climate Suitability Models

**ID:** d8afdf1c-bb5b-4219-8418-b9932f68033e

**Description:** Scientific literature and modeling data on SALB pathogen epidemiology: endemic distribution (South America: Mato Grosso, Rondônia, Amazonas, Peru, Ecuador), spore-dispersal mechanisms (windborne), infection requirements (temperature, humidity, leaf wetness), and climate suitability (current thermal and rainfall envelopes). Includes historical pandemic data (1910 outbreak, loss of Hevea cultivation in Central America), current endemic-zone dynamics, and climate-change projections (how temperature/rainfall shifts 2026–2050 may expand pathogen suitability in Asia and Africa). Required to: (1) set baseline SALB-incursion risk in Year 3–7 (validate assumption that SALB remains out of Asia/Africa through Month 36 = 2029-10-08), (2) model climate-driven range expansion and recommend surveillance-intensity adjustments if risk escalates, (3) validate alternative-crop site selection (water availability, climate stability in guayule/dandelion zones).

**Recency Requirement:** Foundational epidemiology literature (classic papers from 1950s–2000s, still current for baseline biology); climate-suitability models from 2015–2025; climate-projection models (IPCC AR6 or equivalent, 2020–2025).

**Responsible Role Type:** Environmental and Climate Risk Officer; Pathogen Genomics and Virulence Tracking Scientist

**Access Difficulty:** Easy. Most foundational epidemiology literature is published in peer-reviewed journals (open access via Google Scholar or institutional repositories). Climate-suitability models and IPCC data are open-access. CEPLAC and Embrapa data require direct institutional contact but are typically provided to research partnerships. Some proprietary climate models (e.g., agricultural-industry forecasting) may be fee-based.

**Steps:**

- Search Google Scholar, PubMed, or agricultural databases (CAB Abstracts, AGRIS) for foundational SALB epidemiology papers using terms: 'Pseudocercospora ulei epidemiology,' 'SALB pathogen biology,' 'South American Leaf Blight climate niche,' 'Hevea disease history'
- Access CEPLAC (Comissão Executiva do Plano da Lavoura Cacaueira, Brazil) library or contact Embrapa/CEPLAC researchers for endemic SALB distribution maps and historical epidemic data
- Consult FAO's GIEWS (Global Information and Early Warning System) for pathogen-threat assessments and distribution maps
- Search for climate-suitability modeling papers on SALB (e.g., MaxEnt, niche models) published 2015–2025; contact authors (usually academic institutions) for model outputs and underlying data
- Access IPCC climate-projection databases (WorldClim, CMIP6) for temperature/rainfall forecasts 2026–2050 in target regions (Asia, Africa)

### 8. Nagoya Protocol National Access-and-Benefit-Sharing Legislation and Procedures (Brazil, Relevant South American Countries)

**ID:** 82efecf2-c722-43e5-a93a-063abf3d4bef

**Description:** Brazilian genetic-resource access laws (Lei da Biodiversidade, Lei 13.123/2015, and implementing regulations), SisGen system documentation, state-level regulations (Amazonas, Rondônia, Acre, Mato Grosso do Sul), and agreements with indigenous and traditional-community organizations. Also includes: (1) comparable ABS legislation in other South American rubber-producing countries (Peru, Ecuador, Colombia if applicable), (2) bilateral-agreement templates, (3) benefit-sharing calculation and royalty-distribution procedures. Required to: (1) navigate Nagoya Protocol compliance during wild Hevea collection, (2) design benefit-sharing agreements with Brazilian authorities and communities, (3) establish timeline for Month 6 (2027-04-08) ABS-negotiation target and Month 18 (2028-04-08) accession-delivery target, (4) validate community-governance seat requirements and royalty-payment mechanisms.

**Recency Requirement:** Current Brazilian legislation as of 2026 (Lei 13.123/2015 and amendments); SisGen regulations (most recent versions 2024–2025); community-consultation protocols from recent projects (2020–2026).

**Responsible Role Type:** Hevea Resistance Breeding Program Director; Legal Counsel (ABS and Intellectual Property)

**Access Difficulty:** Medium. Brazil's SisGen system is public and operational. Ministry of Environment documentation is available but may require formal requests or Portuguese-language proficiency. Indigenous-organization contacts are accessible through development-partner networks. Comparable legislation in Peru/Ecuador/Colombia is public but implementation varies by country.

**Steps:**

- Access SisGen portal (sisgen.gov.br, portal of Brazil's National Council for Scientific and Technological Development) to review access-authorization procedures, sample documentation, and publicly available case studies
- Contact Brazil's Ministry of Environment (Ministério do Meio Ambiente e Mudança do Clima) Department of Biodiversity to request: (1) current legal framework documentation, (2) bilateral-agreement templates, (3) guidance on collection campaigns in Amazon and Cerrado regions
- Contact indigenous-rights organizations in Brazil (e.g., COIAB—Coordenação das Organizações Indígenas da Amazônia Brasileira) to understand community-consultation requirements and standard benefit-sharing terms
- Search Google Scholar or legal databases for recent Nagoya Protocol case studies in Brazil (crop genetic resources, wild-plant collection) to understand implementation practice
- If including other South American countries: contact Peru's MINAM (Ministry of Environment), Ecuador's MAE (Ministry of Environment), Colombia's MinAmbiente for comparable ABS legislation

### 9. Global Tire-Grade Rubber Specification Standards and OEM Procurement Requirements

**ID:** d026d370-a7ea-4565-9319-9b4c55cdf29f

**Description:** Technical specifications published by major tire manufacturers (Bridgestone, Continental, Goodyear, Michelin, etc.) and industry standards organizations (ISO, ASTM) for natural-rubber sourcing: required purity, viscosity, color, dirt content, contamination limits, traceability requirements, and cost benchmarks. Also includes: (1) tire-manufacturing process requirements (raw-material handling, processing temperature, blending ratios), (2) finished-product testing protocols (tensile strength, elasticity, aging resistance), (3) supply-chain sustainability and transparency standards (GPSNR, FSC, ISO 14001). Required to: (1) validate cost-parity assumptions for alternative rubber (guayule, Russian dandelion) and resistant-Hevea latex, (2) design OEM qualification-testing roadmap and co-funding mechanisms, (3) set Year 7 cost/quality gate criteria (≤USD 1.62/kg + ≥95% of Hevea specs) with credible benchmarks.

**Recency Requirement:** Current OEM procurement standards (2024–2026); ISO and ASTM standards for natural rubber (ISO 2000 series, ASTM D2226-D2227); tire-manufacturing technical documentation (2020–2026).

**Responsible Role Type:** OEM Supply-Chain Resilience and Procurement Officer; Alternative Rubber (Guayule and Russian Dandelion) Commercial Lead

**Access Difficulty:** Medium to Hard. Major tire manufacturers may not openly publish procurement specifications (proprietary competitive advantage), but some high-level standards are documented in sustainability reports or shared with industry consortiums. ISO and ASTM standards require purchase (though summaries are free). GPSNR standards are open-access. Gaining access to detailed OEM specification documents typically requires formal partnership or buyer-consortium participation.

**Steps:**

- Contact major tire manufacturers directly (Bridgestone, Continental, Goodyear, Michelin) via sustainability or procurement teams with requests for: (1) raw-material specifications and procurement standards, (2) qualification procedures for new rubber sources, (3) cost-competitiveness benchmarks and acceptable premium ranges
- Access ISO standards (ISO 2000 series: natural rubber specifications) via ISO's official website (iso.org) or through a standards library
- Contact the International Standards Organization (ISO) Technical Committee 45 (Rubber and Rubber Products) for guidance on relevant standards for alternative rubbers and resistant-cultivar material
- Review GPSNR (Global Platform for Sustainable Natural Rubber) published standards and member procurement policies via their website (sustainablenaturalrubber.org)
- Search technical literature (Google Scholar, industry-conference proceedings) for tire-manufacturing specifications and alternative-rubber qualification studies (search: 'guayule tire qualification,' 'Russian dandelion rubber tire testing')

### 10. Smallholder Rubber-Farmer Demographics, Land Holdings, and Credit Access in Target Regions (Indonesia, India, West Africa, Brazil)

**ID:** e6b41b6c-eda4-49bd-929d-80335119c452

**Description:** Demographic and economic data on smallholder rubber growers in Asia (Indonesia, Malaysia, Thailand, India), Africa (Côte d'Ivoire, Ghana, Cameroon), and Latin America (Brazil, Peru): farm size distribution, age, gender, education, income levels, access to formal credit (banks, microfinance), informal financing (moneylenders, traders), land-title security, and willingness to participate in surveillance and replanting programs. Sources include: (1) national agricultural census data, (2) World Bank and development-bank rural-finance surveys, (3) academic studies on smallholder rubber adoption and livelihoods, (4) NGO and cooperative data on farm characteristics. Required to: (1) design financially accessible replanting-loan terms and income-bridge amounts, (2) calibrate surveillance-premium rates to align with farmer income and incentive sensitivity, (3) estimate technical capacity for surveillance participation (literacy, technology access), (4) validate smallholder-adoption targets (1.5–3 million farmers by Month 144 = 2038-10-08) against baseline participation rates.

**Recency Requirement:** Most recent national agricultural census data (2020–2025); World Bank and MDB rural-finance surveys (2018–2025); academic studies on smallholder rubber (2015–2026).

**Responsible Role Type:** Smallholder Adoption and Surveillance Incentives Manager

**Access Difficulty:** Easy to Medium. National census data are publicly available (though sometimes in local languages or non-English formats). World Bank data are open-access. Academic literature is accessible via Google Scholar or institutional repositories. Development-organization surveys may require direct contact or FOIA requests, but summaries are often published.

**Steps:**

- Access national agricultural census databases: Indonesia (BPS—Badan Pusat Statistik), India (Ministry of Agriculture & Farmers Welfare), Côte d'Ivoire (INS—Institut National de la Statistique), Brazil (IBGE), etc., to download data on farm size, smallholder population, and land use
- Access World Bank Open Data (data.worldbank.org) and search for 'rural finance,' 'agricultural credit,' 'smallholder access' in target countries
- Search Google Scholar for academic papers on smallholder rubber economics and livelihoods (search terms: 'smallholder rubber Indonesia livelihoods,' 'farm-size distribution natural rubber producing countries,' 'credit access rubber farmers')
- Contact development organizations active in rubber regions (IUCN, WWF, Fair Trade organizations) for smallholder demographic surveys and program-participation data
- Access FAO's Agricultural Development Economics (ESA) publications and CGIAR research on smallholder agriculture in target regions

### 11. International Development Bank Phytosanitary Capacity-Building Project Data (World Bank, Asian Development Bank, African Development Bank)

**ID:** 13fd7aac-bd46-4969-b67b-e09c756f3f84

**Description:** Technical and financial data from past and ongoing multilateral development-bank projects supporting phytosanitary capacity in developing countries: project design documents, implementation reports, cost-benefit analyses, lessons-learned summaries, and identified success factors and challenges. Examples: (1) World Bank plant-health projects in Asia, Africa, Latin America (2010–2025), (2) Asian Development Bank agriculture and food safety initiatives, (3) African Development Bank investments in agricultural infrastructure. Raw inputs for: (1) setting realistic cost estimates for inspector training, laboratory equipment, checkpoint construction, (2) understanding pace of capacity building in weak-capacity countries (typical 3–5 year timeline to operational competence), (3) identifying successful twinning and technology-transfer models (bilateral institutional partnerships), (4) validating bottlenecks in earlier projects to avoid replication.

**Recency Requirement:** Project completion reports (2015–2025); mid-term evaluation reports (2020–2025); cost-estimates and unit-price benchmarks from similar projects (2020–2025).

**Responsible Role Type:** Producer-Country Institutional Capacity and Technology Transfer Expert; Phytosanitary Standards and Protocol Lead

**Access Difficulty:** Easy. Multilateral development banks are required by their charters to make project documents public. Open repositories are fully accessible. Direct contact with bank staff is possible via published email addresses and is often helpful for identifying unpublished or in-progress project insights.

**Steps:**

- Access World Bank's Open Knowledge Repository (openknowledge.worldbank.org) and search for plant-health, phytosanitary, and agricultural projects in Asia, Africa, and Latin America; filter by 'Project Completion Reports' and 'Implementation Status & Results Reports' (2015–2025)
- Access Asian Development Bank's Project Documents database (adb.org/projects) and search for food safety and plant-health projects; download project design documents and evaluation reports
- Access African Development Bank's Project Information Portal (projectsportal.afdb.org) for agricultural and rural-development projects in West and Central Africa with phytosanitary components
- Search Google Scholar for academic evaluations of development-bank agricultural projects (search: 'plant health capacity building development bank,' 'phytosanitary inspection infrastructure project evaluation')
- Contact relevant multilateral development banks directly (World Bank Agriculture Global Practice, ADB Agriculture, Food & Natural Resources Division) to request recommendations for comparable projects and lessons-learned summaries

### 12. Commodity Trade Levy and Industry Sustainability Fund Data (Comparable Models: Coffee, Cocoa, Cotton, Palm Oil)

**ID:** 7f9eedc3-09fe-4fd4-a0f3-d208f18b96ef

**Description:** Existing per-tonne or ad-valorem levy mechanisms and ring-fenced industry funds in comparable commodity value chains (coffee, cocoa, cotton, palm oil, etc.): governance structures, collection mechanisms (tariffs, trade fees), compliance rates, fund administration, stakeholder coordination challenges. Examples: (1) International Coffee Organization (ICO) mechanisms, (2) Rainforest Alliance certification and funding models, (3) Palm-oil levy and sustainability fund proposals, (4) GPSNR (Global Platform for Sustainable Natural Rubber) proposed levy structures. Required to: (1) design a realistic natural-rubber industry levy (1.4% ad valorem, about USD 19/tonne at USD 1,350/t reference), (2) estimate compliance and collection costs, (3) identify critical success factors and failure modes (cartel-like coordination, trader/buyer resistance, price-volatility impacts), (4) set Month 48 (2030-10-08) fallback trigger (if pilot compliance <60%, activate alternative funding sources).

**Recency Requirement:** Current commodity-levy documentation (2020–2025); GPSNR feasibility studies (2020–2025); academic analyses of commodity-levy performance (2015–2026); trade data showing levy-collection infrastructure (ports, trading hubs, 2024–2025).

**Responsible Role Type:** Capital Stack and Funding Mechanisms Designer; Multilateral Secretariat Executive Director

**Access Difficulty:** Easy to Medium. ICO and GPSNR are public organizations. Academic literature is accessible via Google Scholar. Direct contact with trade associations and RTAS is necessary for realistic feasibility assessment; industry may be resistant to publicizing levy concerns, so confidential consultations may be needed. Regulatory and tax guidance typically requires engagement with customs and tax authorities in major trading hubs (Singapore, Rotterdam).

**Steps:**

- Access International Coffee Organization (ico.org) website for information on coffee-sector levies and fund mechanisms; download policy documents and annual reports
- Contact GPSNR (Global Platform for Sustainable Natural Rubber, sustainablenaturalrubber.org) and request preliminary analysis of a potential natural-rubber sustainability levy (they are likely developing this in parallel)
- Search Google Scholar for academic analyses of commodity levies and fund management (search: 'commodity levy design trade compliance,' 'sustainability fund governance agricultural', 'natural rubber levy feasibility')
- Contact the Rubber Trade Association of Singapore (RTAS) and major natural-rubber traders (CONAB Brazil, Indonesia's Association of Natural Rubber Producers, Malaysian Rubber Board) to discuss levy feasibility, likely resistance, and collection-infrastructure requirements
- Access World Bank Policy Research Working Papers (openknowledge.worldbank.org) on commodity-market taxation and fund management

### 13. Existing Hevea Cultivar Performance Data and Elite-Clone Yield/Disease Benchmarks

**ID:** db7a5785-bfec-46c7-ab4f-8523cb5380bb

**Description:** Current agronomic performance data for elite Hevea clones in commercial use across Asia, Africa, and Latin America: yield (dry rubber content, t/hectare), disease susceptibility (to SALB and other pathogens), latex quality, growth characteristics, and adaptation to regional agroclimatic conditions. Data come from: (1) clone evaluation trials at rubber research institutes (RRIM Malaysia, Rubber Research Institute of Indonesia, Embrapa Brazil, etc.), (2) plantation production records from major estate and smallholder zones, (3) literature (clones such as RRIM 600, GT 1, PB 260, PB 217, FX 3864, etc.). Required to set Year 7 and Year 12 cultivar-readiness gate criteria (resistant cultivars must achieve ≥90% of elite-clone yield; this requires knowing baseline elite-clone performance [typically 1.5–2.0 t/ha/yr dry rubber]).

**Recency Requirement:** Current elite-clone performance (2020–2025 plantation records, recent trial results); historical benchmarks (2010–2020) for trend analysis; climate-specific performance data (water stress, temperature extremes, soil conditions).

**Responsible Role Type:** Hevea Resistance Breeding Program Director

**Access Difficulty:** Medium. RRIM, RRII, and Embrapa maintain extensive clone-evaluation data, typically available to research partnerships. Commercial plantation data is proprietary, but industry associations may aggregate and publish summary statistics. Peer-reviewed literature is open-access via Google Scholar. Official clone catalogs and IRRDB data require direct institutional contact.

**Steps:**

- Contact RRIM (Rubber Research Institute of Malaysia), RRII (Rubber Research Institute of Indonesia), and Embrapa's rubber program to request clone-evaluation datasets and benchmarks
- Search Google Scholar for recent papers on Hevea-clone performance and yield (search: 'elite Hevea clone yield performance,' 'RRIM GT RRII clone commercial performance')
- Access the International Rubber Research and Development Board (IRRDB) database (if available) or contact IRRDB for clone-performance summaries
- Request data from major rubber estates and smallholder cooperatives in Indonesia, Malaysia, Thailand, India (via Rubber Manufacturers Association or national rubber boards) on clone yields under regional growing conditions
- Consult Hevea-breeding literature and clone descriptors (RRIM clone catalogs, Embrapa clone descriptions) for official baseline performance data

### 14. Hevea Pathogen Diversity and Virulence Evolution Data (Endemic SALB Isolates from Brazil, Latin America)

**ID:** 94a627ad-0c1b-460f-865f-b67c7623ce0d

**Description:** Existing microbial isolate collections, virulence data, and population-genetic information on Pseudocercospora ulei (SALB) from endemic regions (Brazil, Peru, Ecuador, possibly Colombia). Includes: (1) isolate collections held by CEPLAC, Embrapa, and international mycology repositories, (2) virulence-phenotype data (pathogenicity on known Hevea genotypes/clones), (3) any existing whole-genome sequences or genetic markers if available, (4) geographic population structure (whether different endemic regions harbor distinct virulence populations). Required to: (1) establish baseline virulence knowledge for Pathogen Genomics Lab, (2) identify which pathogenic isolates will be used in Virulence Gate challenge tests, (3) assess whether pre-existing virulent biotypes already overcome candidate-cultivar resistance genes (risk of releasing a 'time-bomb' cultivar).

**Recency Requirement:** Existing isolate collections and characterization data (any vintage acceptable, as baseline); recent virulence studies (2015–2025); any genomic or population-genetic data (2015–2025).

**Responsible Role Type:** Pathogen Genomics and Virulence Tracking Scientist

**Access Difficulty:** Medium to Hard. CEPLAC and Embrapa maintain isolate collections but may have limited capacity to ship or share due to quarantine restrictions. International culture collections may have limited P. ulei strains (SALB is endemic to Americas, so non-endemic countries rarely maintain cultures). Academic publications are open-access but may not be comprehensive. Direct partnerships with endemic-region research institutes are the most effective route.

**Steps:**

- Contact CEPLAC (Comissão Executiva do Plano da Lavoura Cacaueira, Brazil) to request inventory of P. ulei isolate collection, virulence data, and any existing sequence or genetic-marker information
- Contact Embrapa's rubber-pathology group to inquire about SALB isolate collections and virulence assessments
- Search international culture collections (ATCC, CBS—Centraalbureau voor Schimmelcultures, CIMMYT Genetic Resource Center) for P. ulei strains and associated phenotype data
- Search Google Scholar for publications on SALB virulence variation, geographic population structure, and pathogenicity testing (search: 'Pseudocercospora ulei virulence biotypes,' 'SALB pathogen genetic diversity Brazil endemic')
- Contact international mycology societies or fungal repositories (GBIF, Mycobank) for isolate location data and any meta-barcoding studies on P. ulei

### 15. Trade and Movement Data on Hevea Nursery Stock and Planting Material (Southeast Asia, Africa, Brazil)

**ID:** d3c0a09a-8e68-4863-ad18-b46b6d943fa8

**Description:** Current cross-border movement statistics for Hevea budwood, nursery stock, and seeds in Southeast Asia (main trade hub), West Africa, and Brazil. Includes: (1) quantity and value of nursery-stock exports/imports (tonnes, USD value) by country and trading partner, (2) documented movement routes (via Singapore, Rotterdam, and regional ports), (3) supplier concentration (number of active nurseries, market share), (4) current inspection and certification practices. Raw input for: (1) understanding scope of containment protocol (how much plant material moves annually, where inspection must be strengthened), (2) estimating levy collection points (identify major traders and nurseries as levy-collection targets), (3) assessing feasibility of certification requirements (are existing nurseries equipped to obtain certification?).

**Recency Requirement:** Most recent trade statistics (2024–2025); historical trade data (2015–2024) for trend analysis; current nursery registration and certification data (2024–2025).

**Responsible Role Type:** Phytosanitary Standards and Protocol Lead; Capital Stack and Funding Mechanisms Designer

**Access Difficulty:** Easy to Medium. FAO and UN Comtrade data are open-access. National customs and port authorities have trade data but may require formal requests. Industry associations are typically responsive to trade-data inquiries. Internal nursery-certification databases may be proprietary.

**Steps:**

- Access FAO FAOSTAT trade database (faostat.fao.org) and query 'Crops' > 'Trade' > 'Plant-based Products' for Hevea nursery stock and seeds (HS codes 0602.10, 0602.20, 1201.90); download trade matrices by country and year (2015–2025)
- Contact Singapore's Port Authority and customs agencies (Singapore International Chamber of Commerce) for data on Hevea-nursery-stock shipments transiting through Singapore (major regional hub)
- Access national agriculture ministry trade statistics in major producing and importing countries (Indonesia, Malaysia, Thailand, India, Brazil) for domestic nursery-stock movement and certification data
- Contact Rubber Manufacturers Association and national rubber boards for information on active nursery networks, production capacity, and current certification standards
- Search trade-transparency databases (UN Comtrade, World Bank WITS—World Integrated Trade Solution) for HS-code-level trade data on plant propagation materials

### 16. Climate-Projection Data and Rainfall/Temperature Suitability Models for Guayule and Russian Dandelion Growing Zones

**ID:** 0be85d69-5fcf-440c-a161-a0a6e2fae6b0

**Description:** Climate and weather data for proposed guayule cultivation zones (arid regions: Sonora/Coahuila Mexico, southwestern US Arizona/California, Argentina) and Russian dandelion zones (temperate: Russia, northern Europe, temperate South America): current and projected temperature, rainfall, soil moisture, frost dates, and growing-season length for 2026–2050. Includes: (1) historical climate data (30-year normals) for baseline, (2) climate-change projections (IPCC AR6 CMIP6 models, high-and low-warming scenarios), (3) water-availability forecasts (irrigation potential, groundwater sustainability), (4) climate-shock frequency (drought, frost, flood). Required to: (1) site alternative-crop pilots in climatically suitable and climate-resilient zones, (2) stress-test alternative-crop economics under 2-in-20-year drought or equivalent climate-shock scenarios for Year 7 gate, (3) reduce risk of pilot plants failing due to unexpected water stress or climate shift mid-program.

**Recency Requirement:** Current climate data (2024–2025); historical 30-year climate normals (1991–2020); IPCC AR6 CMIP6 projections (released 2021–2023); high-resolution regional climate models for target zones (2020–2025).

**Responsible Role Type:** Alternative Rubber (Guayule and Russian Dandelion) Commercial Lead; Environmental and Climate Risk Officer

**Access Difficulty:** Easy. IPCC CMIP6 and WorldClim are open-access. NOAA and national meteorological data are publicly available. Agricultural climate platforms (CCAFS) are open-access. Direct requests to national meteorological agencies typically result in useful guidance. Academic literature is open-access via Google Scholar.

**Steps:**

- Access IPCC climate-projection databases: ESGF (Earth System Grid Federation, esgf-node.llnl.gov) for CMIP6 model outputs; select high-resolution regional models (CESM2, MRI-ESM, etc.) for target regions and download temperature/rainfall projections (2026–2050)
- Access WorldClim (worldclim.org) and other climate-data platforms (CHELSA, CRU, NOAA) for historical climate normals and current climate data at 1–30 km resolution
- Contact national meteorological agencies in target countries (CONAGUA Mexico, NOAA USA, SMN Argentina, Roshydromet Russia) for long-term climate records and regional climate projections
- Access CGIAR's Climate Change, Agriculture and Food Security (CCAFS) platform (ccafs.cgiar.org) for agricultural climate data and impact projections specific to crop growing
- Search Google Scholar for climate-suitability studies for guayule and Russian dandelion (search: 'guayule climate suitability water use,' 'Taraxacum koksaghyz climate niche modeling')