# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: International Phytosanitary Standards Negotiator

**Knowledge**: IPPC framework, plant protection conventions, international standards harmonization, regional phytosanitary organizations (ASEAN, ECOWAS, Mercosur)

**Why**: Decision 1 (Containment Protocol Legal Architecture) is critical and requires negotiating a binding IPPC-framework standard by Month 18 (2028-04-08). This expert advises on achieving formal international adoption with national enforcement, navigating diplomatic timelines and trade tensions that could delay phase 1.

**What**: Design the two-tier adoption pathway (formal IPPC route + provisional regional compacts), identify negotiation leverage with resistant-free producing countries, and de-risk the Month 24 (2028-10-08) commitment-letter deadline by securing bilateral legal frameworks before formal IPPC approval.

**Skills**: Multilateral diplomacy, treaty negotiation, regulatory harmonization, trade-facilitation frameworks, risk of non-ratification by weak-link countries

**Search**: IPPC standards negotiator, plant protection convention expert, international phytosanitary policy, trade harmonization lawyer

## 1.1 Primary Actions

- By Month 1 (2026-11-08): Establish binary reserve architecture separating 'Protocol Readiness Verification' (Year 3 gate, infrastructure KPIs) from 'Containment Efficacy Review' (Months 72–84 = 2032-10-08 to 2033-10-08, field outcomes). Fund independent Outbreak Response Reserve (USD 500M–1B) in escrow, deployable within 4–6 weeks of confirmed SALB incursion, decoupled from gate logic. Commission a Technical Gate Charter defining distinct readiness and efficacy KPIs to prevent retroactive gate-credibility loss.
- By Month 2 (2026-12-08): Establish Pathogen Genomics Laboratory in Brazil (CEPLAC or Embrapa) with capacity to sequence ≥100–150 SALB isolates annually; satellite facility in Asia (Malaysia, Indonesia) by Month 9 (2027-07-08). Mandate Virulence Gates at Months 24, 36, 48, 60 (2028-10-08 to 2031-10-08) as binding sub-criteria preventing cultivar release; specify pass threshold: ≥80% resistance to ≥10 contemporary isolates; bar single-gene cultivars from any release.
- By Month 3 (2027-01-08): Design outcome-based surveillance premiums ($50–100 per verified disease report, paid within 30 days) and pilot in 3–5 representative smallholder zones during Months 6–24 (2027-04-08 to 2028-10-08), targeting ≥60% farmer participation. Allocate USD 50M/yr (USD 1.25B over 25 years) to premium payouts. Link premium and clean-plant-network access eligibility to invert farmer incentive from concealment to disclosure.

## 1.2 Secondary Actions

- By Month 1 (2026-11-08): Convene IPPC technical working group (Brazil, ≥5 major producing countries, IPPC Secretariat, FAO) and design two-tier containment adoption pathway: Tier 1 (formal IPPC standard, target completion Month 30 = 2029-04-08) and Tier 2 (provisional regional compacts in Asia/Africa, operationalized by Month 18 = 2028-04-08, binding 8–10 countries each). This reduces single-path dependency and allows Year 3 gate assessment in ≥16 countries even if formal IPPC adoption is delayed.
- By Month 3 (2027-01-08): Secure binding multi-year funding commitments from ≥5–8 sovereign governments and ≥2 multilateral development banks (no single funder >25% of capital = USD 7.5B ceiling). Embed political-turnover clause (successor administrations bound, 5–10 year terms, not subject to annual re-approval). Design per-tonne industry levy (about USD 19/t at USD 1,350/t reference, about 1.4% ad valorem) governance structure as an independent ring-fenced trust.
- By Month 6 (2027-04-08): Complete Nagoya Protocol and access-and-benefit-sharing negotiations with Brazilian states (Amazonas, Rondônia, Acre, Mato Grosso do Sul) and ≥5 indigenous/traditional community organizations. Deliver ≥6 signed bilateral access agreements pre-clearing 30–50 wild-collection sites and 2–3 annual campaigns per state, with royalty-share guarantees (minimum 3% of cultivar sales) and community-governance seats.
- By Month 12 (2027-10-08): Procure and build ≥4 high-containment SALB trial stations (≥2 endemic Latin America = Rondônia, Peru; ≥1 Asia = Thailand or Indonesia; ≥1 Africa = Cameroon or Nigeria) with screened greenhouse complex (1,000–2,000 m² each), open-field trial blocks (10–15 hectares, 50-meter buffer zones), pathogen laboratory, and quarantine equipment. Capital allocation ≥USD 15M from Years 0–3 envelope. Pilot OEM buyer consortium (5–8 tyre makers) and commission co-funded qualification-testing protocol for guayule and Russian dandelion.
- By Month 18 (2028-04-08): Deliver ≥200 characterized wild Hevea accessions (with resistance phenotypes and Nagoya documentation) to breeding consortiums. Submit formal IPPC protocol proposal to IPPC Secretariat. Secure 2–3 OEM take-or-pay letters of intent (500–2,000 t/yr each) for alternative rubber. Finalize flagship use-case choice (specialty guayule latex product, co-branded tire line, or farmer-income scheme) based on market signal.
- By Month 24 (2028-10-08): Achieve ≥15 producing-country binding commitment letters (each pledging protocol adoption into national phytosanitary law within 12 months of IPPC approval, with ≥30 inspectors recruited per country minimum). Operate ≥100–200 trained inspectors in field roles; digital reporting platform operational; equipment deployed to ≥50 inspection checkpoints. First Virulence Gate assessment (Month 24 = 2028-10-08) completed; candidates passing ≥80% virulence-challenge threshold identified.

## 1.3 Follow Up Consultation

At Month 6 (2027-04-08) next review: (1) Confirm Outbreak Response Reserve (USD 500M–1B) is funded and legally escrow-protected, separate from gate tranches. (2) Report on Pathogen Genomics Lab progress (Brazil Month 2 target = 2026-12-08, Asia satellite Month 9 = 2027-07-08); confirm Virulence Gate protocols and pass/fail thresholds are operationalized. (3) Present surveillance-premium pilot design and baseline farmer-participation targets (≥60% by Month 18 = 2028-04-08). (4) Resolve open decisions: who services USD 7.0B MDB debt (repayment terms, cash-flow source by Month 60 = 2031-10-08); hub-financing split (50/50 program-to-offtake debt assumed; confirm with OEM consortium); replant-loan capital source (on-lending from MDB or dedicated fund?). (5) Model combined-stress scenarios (simultaneous outbreak residual + re-breeding + alternative-rubber remediation = USD 2.4–6.3B) against USD 4.5B contingency pool to confirm reserve adequacy or trigger revised capital allocation.

## 1.4.A Issue - Year 3 Gate Conflates Readiness with Efficacy—Retroactive Credibility Loss if Incursion Occurs

The Month 36 (2029-10-08) gate measures 'Protocol Readiness' (15 countries with import rules, 500 inspectors, 2 lab detections). This is infrastructure deployment, not proof that containment works. If SALB incurs at Months 48–60 (2030-10-08 to 2031-10-08) despite gate passage, funders will retroactively interpret the gate as failed containment and withdraw 50–70% of capital. The plan lacks an explicit 'Containment Efficacy Review' (deferred to Months 72–84 = 2032-10-08 to 2033-10-08) to distinguish readiness from outcome. Without this separation and a pre-funded outbreak reserve outside gate logic, the program's credibility collapses mid-course.

### 1.4.B Tags

- gate-logic-flaw
- retroactive-credibility-loss
- funder-exit-risk
- readiness-vs-efficacy-confusion

### 1.4.C Mitigation

By Month 1 (2026-11-08): separate Year 3 gate into 'Readiness Verification' (infrastructure KPIs: 15 countries, 500 inspectors) released at Month 36 (2029-10-08), and defer 'Containment Efficacy Review' (field outcomes: ≥50 suspect detections screened) to Months 72–84 (2032-10-08 to 2033-10-08). Establish independent USD 500M–1B Outbreak Response Reserve in escrow by Month 3 (2027-01-08), deployable within 4–6 weeks of confirmed incursion, decoupled from gate logic. This preserves funder confidence through biological uncertainty and avoids retroactive gate invalidation.

### 1.4.D Consequence

Without separation: if incursion occurs Months 48–60 (2030-10-08 to 2031-10-08), funders interpret Month 36 (2029-10-08) gate passage as failed containment, triggering 50–70% capital withdrawal and mid-program collapse. Program loses 10–15 years of progress and USD 10–15B of committed funding. If separation is embedded: incursion triggers pre-funded response (USD 0.5–1B reserve), Year 3 gate credibility is preserved, and Year 7 strategy pivots to accelerated deployment without funder panic.

### 1.4.E Root Cause

The plan treats the Month 36 (2029-10-08) gate as a binary containment proof ('protocol works'). In reality, it measures readiness to detect and respond, not actual prevention. Biological systems are uncertain: an incursion despite infrastructure deployment is a normal risk, not a gate failure. The plan does not pre-position capital or contingency authority to respond, leaving funders to improvise and often exit. Separating readiness from efficacy is standard in risk management, but the plan conflates them.

## 1.5.A Issue - Resistance Durability Not Assured—Single-Gene Release Risk and Virulence Gates Under-Specified

The plan commits to pyramiding ≥3 resistance genes per cultivar and Virulence Gates at Months 24, 36, 48, 60 (2028-10-08 to 2031-10-08), but the operational enforcement is vague. Without mandatory pathogen genomics and explicit pass/fail criteria, breeders may release single-gene or weakly pyramided cultivars under Year 7 gate pressure. Historical SALB cultivar failures (1970s–1990s) show single-gene resistance breaks down in 5–10 years. A 30–50% probability of resistance breakdown by Year 12–15 would require USD 400–800M re-breeding and 5–8 year delay, forfeiting the supply-chain resilience claim.

### 1.5.B Tags

- resistance-durability-unspecified
- virulence-gates-vague
- single-gene-release-risk
- re-breeding-cost-exposure

### 1.5.C Mitigation

By Month 2 (2026-12-08): establish Pathogen Genomics Laboratory (Brazil, satellite in Asia by Month 9 = 2027-07-08) to annually sequence ≥100–150 SALB isolates and track virulence-gene frequencies. Enforce Virulence Gates at Months 24, 36, 48, 60 (2028-10-08 to 2031-10-08) as binding sub-criteria: candidates must show resistance (incompatible phenotype) to ≥80% of ≥10 contemporary isolates; single-gene cultivars barred from release. Mandate ≥3 independent resistance sources per candidate. This shifts proof-of-durability from field trials (5–7 years) to pathogen genomics (continuous), enabling early detection of resistance decay.

### 1.5.D Consequence

Without enforcement: 30–50% probability of single-gene or weakly pyramided cultivar release by Year 7 gate pressure; resistance breaks down by Year 12–15; requires USD 400–800M re-breeding cycle and 5–8 year delay; supply-chain resilience claim retroactively false; funder confidence in breeding pillar erodes. With enforcement: durability window extends to 20–30+ years; Virulence Gates prevent release of 'time bombs'; Year 7 gate credibility restored; breeding pillar is perceived as de-risked.

### 1.5.E Root Cause

The plan acknowledges pyramiding and Virulence Gates but does not fund or operationalize the pathogen genomics lab until after Year 3, and does not specify pass/fail criteria for gates. Breeders face Year 7 gate deadline pressure; without pre-funded pathogen tracking and explicit thresholds, they optimize for gate passage, not durability. The plan treats resistance durability as a desired outcome, not as an enforceable technical requirement. Standard breeding practice requires continuous pathogen monitoring and multi-gene validation; the plan underspecifies both.

## 1.6.A Issue - Smallholder Surveillance Participation Critically Low Without Aligned Incentives—60–80% Non-Reporting Risk

Containment depends on smallholder detection and reporting of suspect SALB symptoms. Typical adoption of disease-surveillance schemes in tropical agriculture is 20–40% participation, and farmers often conceal infections to avoid quarantine and income loss. The plan mentions 'surveillance premiums' but leaves structure and funding vague. Without outcome-based premiums ($50–100 per verified report) integrated into replant finance and paid within 30 days, participation will likely drop below 30%, leaving incursions undetected until advanced stage, costing USD 1–3B additional outbreak response and losing the early-detection value of the USD 7.5B containment pillar.

### 1.6.B Tags

- smallholder-incentive-misalignment
- concealment-risk
- surveillance-participation-low
- detection-sensitivity-loss

### 1.6.C Mitigation

By Month 3 (2027-01-08): design outcome-based surveillance premiums ($50–100 per verified sample, $25–50 per unconfirmed suspect) paid within 30 days, embedded into smallholder replant finance and clean-plant network access. Pilot in 3–5 zones (Sumatra, Côte d'Ivoire, northeast India, Rondônia, +1 optional) during Months 6–24 (2027-04-08 to 2028-10-08), targeting ≥60% farmer participation. Link premium eligibility to clean-plant certification, creating income incentive for both surveillance and adoption. Allocate USD 50M/yr (USD 1.25B over 25 years) to premium payouts and verification costs.

### 1.6.D Consequence

Without aligned incentives: participation <30%; 60–80% of suspect samples unreported; incursions advance to costly quarantine-and-eradication stage (USD 1–3B per incident); early-detection value of USD 7.5B containment pillar is lost; program reverts to reactive expensive containment instead of preventive detection. With outcome-based premiums: participation ≥60%; 80%+ of suspect samples reported within 2–4 weeks; early action on incursions keeps costs under USD 500M per incident; containment pillar delivers resilience value.

### 1.6.E Root Cause

The plan assumes smallholder participation without addressing the economic and psychological barriers. Farmers benefit from containment only as collective risk reduction; individual farmer cost of reporting (quarantine, income loss) outweighs individual benefit (prevention is collective). Standard incentive economics shows farmers must be paid directly and visibly for each act of reporting, with short payment turnaround. The plan mentions premiums but does not fund or operationalize them, leaving them as aspirational.

---

# 2 Expert: Hevea Genomic Breeding Strategist

**Knowledge**: Hevea genetics, quantitative trait loci mapping, marker-assisted selection, pathogen population genomics, resistance durability modeling, cultivar field trials

**Why**: Decision 2 (Resistance Breeding Strategy) and Pathogen Genomics integration (Decision 14) are technical hubs. This expert advises on pyramiding strategy, Virulence Gates at Months 24-60 (2028-10-08 to 2031-10-08), and the year 7 and 12 gate criteria to mitigate the 30-50% historical risk of resistance breakdown by year 15.

**What**: Establish the Brazilian Germplasm Bank and pathogen genomics lab by Month 12 (2027-10-08), finalize the resistance architecture (minimum 3 genes from 2 sources), and enforce Virulence Gate pass/fail logic to prevent release of single-R-gene cultivars that would fail within a decade.

**Skills**: Backcross breeding, genomic selection, pathogen virulence tracking, controlled inoculation assays, genotype-by-environment prediction, regulatory approval strategy for novel cultivars

**Search**: Hevea breeding scientist, quantitative genetics Hevea, SALB resistance genes, pathogen virulence evolution, marker-assisted selection rubber

## 2.1 Primary Actions

- Establish binary gate architecture by Month 1 (2026-11-08): separate 'Protocol Readiness Verification' (Month 36 = 2029-10-08 gate, gates Months 36–84 = 2029-10-08 to 2033-10-08 tranches) from deferred 'Containment Efficacy Review' (Months 72–84 = 2032-10-08 to 2033-10-08, field outcomes). Fund standalone Outbreak Response Reserve (USD 500M–1B) in escrow outside gate logic by Month 3 (2027-01-08), deployable within 4–6 weeks of confirmed incursion, independent of gate decisions. Draft Technical Gate Charter by Month 3 (2027-01-08) explicitly separating readiness from efficacy, signed by all funders and governance board.
- Establish Pathogen Genomics Laboratory (CEPLAC, Manaus) by Month 2 (2026-12-08); Asian satellite (Malaysia or Indonesia) by Month 9 (2027-07-08). Enforce binding rule by Month 3 (2027-01-08): no cultivar eligible for Year 7 or Year 12 gate unless it carries ≥3 independent resistance genes from ≥2 sources, passes Virulence Gates at Months 24, 36, 48, 60 (2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08) (tested against ≥10 contemporary isolates, ≥80% pass required), and passes pathogen-durability forecast. Bar single-R-gene cultivars from release in all circumstances. Embed Virulence-Gate evidence as non-negotiable sub-criterion in Technical Gate Charter.
- Design outcome-based surveillance premium scheme ($50–100 per verified report, paid within 30 days) by Month 3 (2027-01-08). Launch pilot in 3–5 smallholder zones (Sumatra, Côte d'Ivoire, northeast India, Rondônia, ≥1 other) during Months 6–24 (2027-04-08 to 2028-10-08), enrolling ≥1,500 farmers total. Target ≥60% participation and ≥95% diagnostic accuracy by Month 18 (2028-04-08). If achieved, commit to scaling to 2–3 million farmers by Year 10 (Month 120 = 2036-10-08). If pilot <40% participation, trigger redesign (increase premiums to $100–150, link to price stabilization). Include zero-penalty clause: reporting farmers receive compensation regardless of quarantine risk.

## 2.2 Secondary Actions

- Commission 4 high-containment SALB trial stations (≥2 in endemic Latin America, ≥1 each in Asia and Africa) by Month 12 (2027-10-08); capital budget USD 12–20M. Each station must include screened greenhouse complex (1,000–2,000 m²), open-field trial blocks (10–15 hectares, 50-meter buffer), pathogen laboratory (50+ samples/week), quarantine equipment (autoclave, decontamination, spore-disposal). Operationalize by Month 18 (2028-04-08) to support Virulence Gates and field trials.
- Procure binding commitments from ≥5 sovereign governments and ≥2 multilateral development banks by Month 3 (2027-01-08); no single funder >25% (USD 7.5B). Each commitment must specify annual tranches, release schedule tied to gates (30–35% per gate), and political-turnover clause (binding on successors, 5–10 year term). Publish Technical Gate Charter and funder-agreement summaries by Month 6 (2027-04-08).
- Design and pilot ASEAN lever revenue collection by Month 18 (2028-04-08), targeting USD 40M/yr (1.4% ad valorem on natural-rubber trade, ~USD 19/t at USD 1,350/t reference). If pilot compliance >80%, authorize global rollout by Month 36 (2029-10-08); if <60%, trigger fallback cascade (higher bank loan ratio, outcome-linked bonds, climate-finance blend) by Month 48 (2030-10-08).
- Establish OEM buyer consortium of 5–8 tyre manufacturers by Month 6 (2027-04-08). Secure 2–3 take-or-pay letters of intent (500–2,000 t/yr each) for alternative-rubber volume by Month 18 (2028-04-08). Co-fund tire-grade qualification testing (Months 12–30 = 2027-10-08 to 2029-04-08). Commit ≥80% of planned Year-10 volume to binding priced offtake by Month 72 (2032-10-08) before commercial hub approvals.
- Complete Nagoya Protocol and access-and-benefit-sharing negotiations (Brazil environment ministry, indigenous organizations, Amazonian states) by Month 6 (2027-04-08). Secure ≥6 bilateral agreements pre-clearing ≥200 collection sites. Establish Brazilian Germplasm Bank (CEPLAC or Embrapa, 500+ m², containment greenhouse, diagnostic lab, cold storage) by Month 12 (2027-10-08). Deliver ≥200 characterized wild Hevea accessions to breeding consortiums by Month 18 (2028-04-08).
- Publish all gate evidence (raw data, analyses, Virulence Gate results, cost-parity calculations) 60 days before each gate decision. Permit 30-day public challenge/appeal period. Technical Panel publishes decision rationale and addresses substantial appeals within 30 days of gate. Adopt transparency protocol by Month 3 (2027-01-08).
- Model combined-stress scenarios (simultaneous outbreak residual + re-breeding + alternative-rubber remediation) against the USD 4.5B contingency pool by Month 12 (2027-10-08). Assess whether pool is adequate or whether additional reserves must be pre-committed. If combined stress claims exceed USD 4.5B, identify funding sources or prioritization rules for deficit coverage.
- Identify loan-capital source for replant finance (candidate: on-lending of USD 7.0B bank lending) and hub-financing split (planning case 50–50 program/offtake-backed debt) by Month 12 (2027-10-08). Resolve MDB debt-service pathways: specify who services USD 7.0B at ~USD 449M/yr starting Month 60 (2031-10-08).

## 2.3 Follow Up Consultation

Next meeting (Month 1.5 = 2026-11-23): present draft binary gate architecture and Technical Gate Charter framework; confirm Pathogen Genomics Lab site selection and staffing plan; detail surveillance premium pilot design (zones, enrollment, payment mechanics, success metrics). Month 3 (2027-01-08) follow-up: review signed funder commitments and governance board composition; confirm Virulence Gate enforcement rules and breeding strategy revision; pilot results from germplasm negotiations and outbreak-reserve escrow setup. Month 6 (2027-04-08): assess OEM consortium formation, levy pilot readiness, and Nagoya/ABS status; validate Virulence Lab startup at CEPLAC.

## 2.4.A Issue - Year 3 gate conflates readiness with efficacy; retroactive credibility collapse if incursion occurs Months 48–60 (2030-10-08 to 2031-10-08)

The Month 36 (2029-10-08) gate measures protocol infrastructure (15 countries, 500 inspectors, 2 suspect detections), not proven containment efficacy. If SALB enters Asia at Month 54 (2031-04-08) despite gate passage, funders will retroactively invalidate the gate decision and withdraw 40–60% of committed capital, destroying program momentum at the breeding and alternative-rubber stages. The pre-assessment identifies this logic gap explicitly but the plan does not operationalize the mitigation: splitting the gate into separate 'Readiness Verification' (Month 36 = 2029-10-08) and deferred 'Containment Efficacy Review' (Months 72–84 = 2032-10-08 to 2033-10-08), with an independent USD 500M–1B Outbreak Response Reserve decoupled from gate logic.

### 2.4.B Tags

- gate-credibility-risk
- retroactive-invalidation
- funder-exit-trigger
- logic-gap

### 2.4.C Mitigation

Mandatory: By Month 1 (2026-11-08), establish binary reserve architecture. Year 3 gate gates Months 36–84 (2029-10-08 to 2033-10-08) tranches (USD 4.5B) on readiness criteria only; fund standalone Outbreak Response Reserve (USD 500M–1B, inside cap, escrow outside gate logic) by Month 3 (2027-01-08), deployable within 4–6 weeks of confirmed incursion, independent of gate decisions. Publish Technical Gate Charter by Month 3 (2027-01-08) explicitly separating readiness verification from efficacy review. Conduct Containment Efficacy Review during Months 72–84 (2032-10-08 to 2033-10-08) on field outcomes (≥50 suspect detections), not gate validity. This separation preserves gate credibility and funder confidence through biological uncertainty.

### 2.4.D Consequence

Without mitigation: if incursion occurs Months 48–60 (2030-10-08 to 2031-10-08), funder panic and contract termination reduce deployed capital by USD 8–12B (estimate), halting breeding trials and alternative-rubber scale-up. Resistance cultivars incomplete by Year 15, costing USD 400–800M re-breeding and 5–8 year delay. Alternative-rubber hubs stranded with partial capex sunk. Program is retroactively deemed failed, destroying 25-year resilience claim.

### 2.4.E Root Cause

Plan does not operationalize the logic correction identified in the pre-assessment. Year 3 gate is treated as a proof-point (go/no-go containment) rather than as a readiness checkpoint (infrastructure deployed, not pathogen prevented). Reserves are lumped together (contingency USD 4.5B) and subject to gate logic, leaving them unavailable for incursions that occur 'between gates' and thus appear to have failed the prior gate.

## 2.5.A Issue - Resistance durability gates missing; single-R-gene cultivars risk Year 12–15 breakdown; Virulence Gates not binding on cultivar release

The plan specifies ≥3 independent resistance genes from ≥2 sources and Virulence Gates at Months 24, 36, 48, 60 (2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08), but does not enforce them as binding sub-criteria for cultivar advancement or commercial release. Year 7 gate (Month 84 = 2033-10-08) passes candidates that show ≥90% resistance over ≥2 years; historical single-R-gene failures (Hevea 'IAC' series, Brazil 1970s–1990s) broke down at Year 8–12 when pathogen virulence shifted. Without genetic-architecture and Virulence-Gate enforcement, 30–50% probability that Year 12–15 resistance fails, requiring USD 400–800M re-breeding and forfeiting resilience claims.

### 2.5.B Tags

- resistance-durability
- single-gene-failure-risk
- gate-enforcement-gap
- virulence-tracking-underspecified

### 2.5.C Mitigation

Mandatory: By Month 2 (2026-12-08), establish Pathogen Genomics Laboratory (CEPLAC, Manaus; satellite at Malaysia rubber institute by Month 9 = 2027-07-08). By Month 3 (2027-01-08), enforce binding rule: no cultivar is eligible for Year 7 or Year 12 gate release unless (1) it carries ≥3 independent resistance genes from ≥2 geographic sources, confirmed by molecular markers; (2) it passes Virulence Gate at each checkpoint (Months 24, 36, 48, 60 = 2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08), tested against ≥10 contemporary isolates, ≥80% pass rate required; (3) pathogen genomics lab publishes virulence forecast (probability of resistance breakdown by Month 180 = 2041-10-08). Embed Virulence-Gate evidence as non-negotiable sub-criterion in Technical Gate Charter signed Month 3 (2027-01-08). This shifts burden of proof from 'is cultivar resistant?' to 'will resistance remain durable?'

### 2.5.D Consequence

Without mitigation: Year 12–15 probability of single-gene or polygenic failure 30–50% (estimate, based on historical Hevea and other pathosystems). Failure triggers USD 400–800M re-breeding cycles, 5–8 year delay, and 50–70% loss of funder confidence in breeding pillar. Supply-chain resilience claim is forfeited. Alternative-rubber and smallholder adoption pipelines collapse from lack of credible cultivar option.

### 2.5.E Root Cause

Plan states Virulence Gates and genetic architecture but does not make them binding gates on release. Virulence tracking is described as a 'supporting input' (Decision 14), not a hub-level gating criterion. Technical Panel charter is not yet drafted, so enforcement teeth are missing. Plan lacks explicit bar on single-R-gene release.

## 2.6.A Issue - Smallholder surveillance participation <30% baseline without income incentives; adoption and early-detection failure risk not mitigated

Typical smallholder surveillance participation is 20–40% (baseline, from development-program literature), yet the plan assumes 50–60% adoption and early-detection performance. Farmers face quarantine and income-loss risk if they report disease, inverting the incentive sign. Surveillance premiums are mentioned (Decision 8, Smallholder Replanting Finance) but not operationalized: no pilot dates, payment velocity, participation targets, or outcome thresholds are specified. Without aligned incentives, incursions in smallholder zones go undetected until establishment is advanced (Year 4–6 post-entry), costing USD 1–3B additional outbreak response and blinding the containment pillar.

### 2.6.B Tags

- smallholder-incentives-gap
- surveillance-participation-risk
- early-detection-failure
- adoption-baseline-mismatch

### 2.6.C Mitigation

Mandatory: By Month 3 (2027-01-08), design outcome-based surveillance premium scheme ($50–100 per verified disease report, $25–50 for unconfirmed suspects, paid within 30 days). Pilot in 3–5 zones (Sumatra, Côte d'Ivoire, northeast India, Rondônia, ≥1 other) during Months 6–24 (2027-04-08 to 2028-10-08), enrolling 500–1,000 farmers per zone. Set participation target ≥60% of eligible farmers. Embed clean-plant certification as eligibility requirement (reinforces adoption). If pilot achieves ≥60% participation and ≥95% sample diagnostic accuracy by Month 18 (2028-04-08), scale to 2–3 million farmers by Year 10 (Month 120 = 2036-10-08). If pilot <40% participation by Month 18 (2028-04-08), redesign premium rates (increase to $100–150 per sample, link to price-floor stabilization). Include zero-penalty clause: farmers who report receive compensation regardless of quarantine risk, decoupling reporting from income loss.

### 2.6.D Consequence

Without mitigation: Smallholder participation remains 20–30%, leaving 70% of small-farm areas under-surveilled. SALB incursion into monitoring-blind zones (2–5 million smallholder hectares in Sumatra, West Africa, India) goes undetected for 2–4 years post-entry, advancing to 10,000–50,000 hectares by detection. Outbreak response cost escalates to USD 2–5B; contingency pool (USD 4.5B) is insufficient. Funder withdrawal risk 50–70%. Entire containment pillar is invalidated as non-functional.

### 2.6.E Root Cause

Plan treats surveillance premiums as optional design choice in Decision 8, not as foundational to incentive alignment. No pilot is scheduled, so participation risk is not validated or addressed before scaling. Baseline assumption of 50–60% adoption is stated but not evidence-backed or pilot-tested. Farmer income-loss risk (quarantine penalty) is not acknowledged or mitigated.

---

# 3 Expert: Stage-Gate Capital Allocation and Risk Officer

**Knowledge**: Development-program gating, adaptive funding mechanisms, financial resilience under biological uncertainty, contingency-reserve architecture, mid-program funder-exit risk mitigation

**Why**: Decision 3 (Stage-Gate and Capital Release Design) and the combined-stress-versus-contingency-pool tension (pre-assessment finding: USD 2.4-6.3B claims vs USD 4.5B pool) require disciplined evidence-based capital release. This expert advises on adaptive-tranche logic, partial KPI attainment rules, and separation of protocol readiness from containment efficacy to preserve gate credibility if incursion occurs despite Year 3 passage.

**What**: Design the Year 3/7/12/18 gate charter with the Technical Panel by Month 3 (2027-01-08), establish the USD 500M-1B outbreak reserve and USD 4.5B contingency pool as independent tranches, and model combined-stress scenarios to identify the USD 1.8B shortfall gap and fallback capital sources.

**Skills**: Financial gating criteria, adaptive-tranching design, outcome-linked instruments, contingency quantification, funder-turnover risk modeling, resilience-program case studies (comparable 20-25 year development programs)

**Search**: development program gating mechanism, stage-gate capital allocation, biological uncertainty funding, agricultural supply-chain finance, contingency reserve sizing

## 3.1 Primary Actions

- By Month 1 (2026-11-08): Establish Outbreak Response Reserve of $500M–$1B in independent escrow, with pre-authorized deployment rules and compensation schedules. Publish the Outbreak Response Playbook (trigger criteria, funding source, implementation timeline) to funders and producer governments. Separate Year 3 gate logic: Year 3 gate releases operational tranches on readiness KPIs (15 countries, 500 inspectors, 2 detections); Containment Efficacy Review deferred to Months 72–84 (2032-10-08 to 2033-10-08) to assess whether surveillance detected ≥50 suspect incidents.
- By Month 2 (2026-12-08): Commission Pathogen Genomics Laboratory (Brazil, CEPLAC or Embrapa) with ≥$500K annual budget and ≥2 senior staff; establish molecular-typing and virulence-sequencing workflows. Mandate that all SALB isolates from trial plots and endemic field sites are sequenced annually. Draft binding Virulence Gate sub-criteria document specifying: ≥10 isolates per candidate, ≥4 geographic sources, ≥80% incompatible phenotype threshold, non-negotiable entry to Year 7 gate. Circulate for Technical Panel and funder review by Month 6 (2027-04-08).
- By Month 3 (2027-01-08): Finalize Technical Gate Charter with all funders (≥5 sovereigns, ≥2 MDBs), producer governments (≥8 representatives) and OEM buyer consortium (≥3 major tyre makers). Embed explicit Virulence Gate and multi-source resistance requirements into Month 84 (2033-10-08) Year 7 cultivar-readiness criteria. Establish independent Technical Panel (7–9 conflict-free members, staggered 5-year terms) and publish their mandate, conflict-of-interest policies and transparency rules. Sign all commitments and publish charter 60 days before Month 6 (2027-04-08) milestone.
- By Month 6 (2027-04-08): Launch surveillance-premium pilot in ≥3 zones (Sumatra, Côte d'Ivoire, northeast India minimum), with binding incentive design ($50–100 per verified report, paid within 30 days) integrated into replant-finance contracts. Establish fair-quarantine rules (automatic compensation if reporting farm is quarantined, funded from Outbreak Response Reserve). Set mandatory participation target of ≥60% and independent verification mechanism. Conduct mid-pilot review at Month 18 (2028-04-08); if participation <40%, escalate incentive redesign before Month 24 (2028-10-08).
- By Month 12 (2027-10-08): Complete Pathogen Genomics lab commissioning (Brazil); first annual virulence report published. Convene Technical Panel and publish Year 3 gate evidence template (all data, KPI calculations, appeal procedures) to enable 60-day public review before Month 36 (2029-10-08) decision. Conduct combined-stress simulation (outbreak + re-breeding + alternative-rubber remediation) and model USD 4.5B contingency-pool adequacy; publish findings and identify fallback-funding triggers if total claims exceed USD 4.5B (estimate).

## 3.2 Secondary Actions

- By Month 3 (2027-01-08): Establish binding multi-year funding commitments from ≥5 sovereign governments and ≥2 MDBs with no single funder exceeding 25% ($7.5B). Embed ring-fenced minimum-tranche guarantees (≥80% of allocated amount released even if gate underperforms, to avoid funder-driven program termination on a weak gate result). Publish capital-stack composition and MDB debt-service assumptions (≈$449M/yr from Month 60 = 2031-10-08) to enable independent funder review.
- By Month 6 (2027-04-08): Form OEM buyer consortium (≥5–8 major tyre manufacturers); commission flagship-product feasibility study (specialty guayule latex, hypoallergenic gloves, co-branded tire line) with go/no-go decision by Month 18 (2028-04-08). Design co-funded OEM qualification-testing program (Months 12–30 = 2027-10-08 to 2029-04-08) to de-risk tire-grade validation and reduce barriers to offtake commitment.
- By Month 12 (2027-10-08): Secure first binding commitment letters (≥2–3 OEMs) for take-or-pay offtake at 500–2,000 t/yr each. Draft hub-financing-split decision (open at program inception): clarify 50/50 split (program vs. offtake debt) or alternative allocation. Publish hub site-selection criteria (arid zones for guayule, temperate for dandelion) and solicit expressions of interest from regional developers.
- By Month 18 (2028-04-08): Deliver ≥200 characterized wild Hevea accessions to breeding consortiums, with full Nagoya/ABS documentation and community benefit-sharing proof. Pilot ASEAN levy (Months 12–18 = 2027-10-08 to 2028-04-08) targeting $40M/yr collection; audit compliance rate and publish findings to support global rollout decision at Month 24 (2028-10-08). Approve first breeding-candidate advancement into field trials based on Month 12 (2027-10-08) Virulence Gate results.
- By Month 24 (2028-10-08): Deliver formal IPPC protocol proposal to IPPC Secretariat; secure binding commitment letters from ≥15 producing countries to adopt protocol into national law within 12 months of IPPC approval. Commission independent audit of inspector training and checkpoint readiness in ≥5 pilot countries to verify Month 36 (2029-10-08) gate achievement. Finalize hub-financing documentation and sign ≥1 hub development agreement (target commissioning Month 120 = 2036-10-08).
- By Month 36 (2029-10-08): Execute Year 3 Protocol Readiness gate (≥15 countries with enforceable rules, ≥500 inspectors, ≥2 lab-cleared detections); release 70–100% of Month 36–84 (2029-10-08 to 2033-10-08) tranche ($3.15–4.5B of the $4.5B) based on proportional KPI attainment. Publish Technical Panel decision with full evidence appendices and stakeholder-challenge period (30 days). Initiate Containment Efficacy Review plan and re-brief funders on Months 72–84 (2032-10-08 to 2033-10-08) efficacy assessment logic to maintain gate-credibility confidence.
- By Month 60 (2031-10-08): Conduct mid-program strategic review: assess pathogen-genomics trends (are virulence frequencies increasing?), cultivar-trial progress (are candidates on track for Year 7 gate?), smallholder-adoption uptake (are premium pilots achieving ≥60% participation?), and alternative-rubber cost convergence (is cost trajectory toward $1.62/kg Month 84 = 2033-10-08 target?). Publish findings and contingency-plan adjustments (e.g., delay hub approval, accelerate breeding, increase surveillance budget) to maintain funder confidence.
- By Month 72 (2032-10-08): Finalize Pathogen Genomics reports on virulence-frequency trends and resistance-durability forecasting; feed into Month 84 (2033-10-08) cultivar-gate decision. Assess alternative-rubber pilot performance (cost, yield, tire-grade tests) to set Month 84 (2033-10-08) go/no-go on hub construction. Begin site preparation and permitting for ≥2 commercial hubs (target Month 120 = 2036-10-08 commissioning) contingent on Month 84 (2033-10-08) gate pass and ≥80% offtake commitment.
- By Month 84 (2033-10-08): Execute Year 7 cultivar-readiness gate: release ≥2 candidates with ≥90% resistance, ≥85% yield parity, and Virulence Gate pass (≥80% incompatible phenotype to ≥10 isolates). Release 50–70% of cultivar-phase tranche; hold 30–50% for final validation and post-release monitoring. Conduct alternative-rubber cost-gate assessment: if within 20% of reference ($1.62/kg threshold), approve hub construction; if above, defer and re-evaluate co-product revenue and processing-efficiency improvements. Publish Technology Assessment Panel decision and adaptation plan to producers.

## 3.3 Follow Up Consultation

At next review: (1) Confirm Outbreak Response Reserve establishment ($500M–$1B) and signoff on compensation rules by funders; (2) Review draft Virulence Gate sub-criteria and Technical Gate Charter; confirm Technical Panel recruitment timeline; (3) Report on surveillance-premium pilot design and 3–5 zone selection; confirm fair-quarantine rules and compensation funding source; (4) Present ASEAN levy pilot compliance data (target >80% by Month 18 = 2028-04-08) and fallback cascade triggers if <60%; (5) Assess whether any competing demands are preventing simultaneous progress on protocol adoption, germplasm collection, breeding trials and OEM engagement. Identify resource bottlenecks and contingency reallocation. (6) Discuss risk of combined-stress claims ($2.4–6.3B estimate) exceeding USD 4.5B contingency pool and any need for enhanced reserve funding or funder-exit insurance.

## 3.4.A Issue - Year 3 Gate Conflates Readiness with Efficacy, Creating Retroactive Credibility Collapse Risk

The Month 36 (2029-10-08) 'Protocol Readiness' gate measures infrastructure (15 countries with rules, 500 inspectors, 2 suspect detections), not proven containment efficacy. If SALB incursion occurs at Months 48–60 (2030-10-08 to 2031-10-08) despite gate passage, funders will retroactively interpret gate failure as evidence the protocol does not work. This creates 50–70% probability of mid-program funder withdrawal, forfeiting program legitimacy and enabling cascade termination. The gate's binary pass/fail structure leaves no escape: either containment works (no incursions ever) or the gate is invalidated. Biological uncertainty makes the first outcome unrealistic over 25 years.

### 3.4.B Tags

- gate-credibility-risk
- readiness-vs-efficacy-confusion
- funder-exit-trigger
- binary-gate-brittleness

### 3.4.C Mitigation

Separate 'Protocol Readiness Verification' (Month 36 = 2029-10-08 gate: infrastructure KPIs) from 'Containment Efficacy Review' (Months 72–84 = 2032-10-08 to 2033-10-08: ≥50 documented suspect detections, escalate if <20). Fund an independent Outbreak Response Reserve ($500M–$1B) by Month 3 (2027-01-08), deployable within 4–6 weeks of confirmed incursion in a free region, decoupled from gate logic. If incursion occurs pre-Year 7, reserve funds response without gate revision, preserving gate-credibility logic. Publish response decision rationale 30 days post-incursion, showing program adapted rather than failed. This architecture isolates funder confidence from biological uncertainty.

### 3.4.D Consequence

Without separation: retroactive gate invalidation if incursion occurs Months 48–60 (2030-10-08 to 2031-10-08); funder panic and 50–70% withdrawal probability; program loses legitimacy and faces termination even if containment subsequently succeeds. Cascading loss of sovereign and bank commitments ($14B + $7B = $21B of the capital stack) within 12–18 months of incursion, stranding breeding and alternative-rubber phases mid-development and forfeiting supply-chain resilience claims.

### 3.4.E Root Cause

The plan treats the Year 3 gate as a single, definitive 'proof' that containment works, rather than as one checkpoint in a multi-decade adaptive cycle. Biological containment is a probabilistic, ongoing process (reducing incursion probability, not eliminating it), yet the gate's infrastructure KPIs read as if they settle the question conclusively. This mismatch between gate semantics (readiness) and funder expectations (efficacy proof) is a design flaw, not an operational detail.

## 3.5.A Issue - Resistance-Durability Assurance Severely Underspecified; Single-Gene and Rapid-Breakdown Risks Unchecked

The plan specifies pyramiding ≥3 genes from ≥2 sources and Virulence Gates at Months 24, 36, 48, 60 (2028-10-08 to 2031-10-08), but does not mandate enforcement in the cultivar-release gate logic. The Month 84 (2033-10-08) Year 7 gate criteria state 'at least 2 candidates with ≥90% resistance' without explicitly barring single-R-gene cultivars or requiring independent virulence-challenge evidence as a non-negotiable sub-criterion. Historical precedent (SALB cultivar failures, 1970s–1990s) shows single-gene resistance breaks down in 5–10 years once pathogen virulence shifts. Risk: 30–50% probability that a released cultivar fails by Year 12–15, requiring $400–800M re-breeding cycles, 5–8 year delay, and retroactive supply-chain resilience loss. Pathogen Genomics Labs are budgeted but their outputs (Virulence Gate evidence) are not integrated into release-gate criteria.

### 3.5.B Tags

- resistance-architecture-enforcement-gap
- virulence-gate-non-binding
- single-gene-risk
- durability-failure-cascade

### 3.5.C Mitigation

Embed three mandatory sub-criteria into the Month 84 (2033-10-08) Year 7 gate: (1) Each released cultivar carries ≥3 functionally independent resistance genes confirmed by molecular markers and virulence-segregation analysis; (2) Virulence Gate at Month 60 (2031-10-08) is non-negotiable: candidate must show incompatible phenotype to ≥80% of ≥10 contemporary SALB isolates (represent ≥4 geographic sources); (3) Pathogen Genomics report showing virulence-frequency trends and probability of resistance breakdown by Year 15 must forecast ≤20% failure risk. If any criterion is unmet, hold candidate for additional pyramiding (6–12 month delay acceptable). Establish Pathogen Genomics Labs by Month 2 (2026-12-08, Brazil) and Month 9 (2027-07-08, Asia); publish annual virulence reports Months 12–60 (2027-10-08 to 2031-10-08).

### 3.5.D Consequence

Without enforcement: 30–50% probability cultivar released at Year 7 carries latent single-gene or two-gene weakness; pathogen overcomes resistance at Year 12–15 (within program's 25-year horizon); farmer and OEM confidence collapses; $400–800M additional breeding cost, 5–8 year re-development, and loss of supply-chain resilience narrative. Alternative-rubber and smallholder adoption momentum stalls if Hevea pillar appears to fail mid-program. Funder criticism of 'biology-blindness' and gate mismanagement compounds mid-program exit risk.

### 3.5.E Root Cause

The plan describes resistance architecture and Virulence Gates in the strategic-decision documents and pre-project assessment, but does not translate these into binding, specific criteria embedded in the Year 7 gate charter. Pathogen genomics is budgeted as a supporting pillar, not as a decision-making pillar. This leaves the gate criteria vulnerable to pressure to 'release something on time' even if durability evidence is weak or incomplete.

## 3.6.A Issue - Smallholder Surveillance Participation and Adoption Incentives Fragmented; Concealment Risk and Low Uptake Unmitigated

The plan calls for 'smallholder adoption as a design requirement' and specifies replant finance, clean-plant networks and surveillance premiums, but does not integrate these into a coherent incentive architecture. Surveillance premiums are mentioned in the pre-project assessment ($50–100 per verified report), yet no implementation detail addresses the fundamental tension: farmers who report disease risk quarantine, tree removal and income loss, creating strong incentive to conceal infections. Historical evidence shows smallholder reporting rates of 10–30% in comparable containment programs unless income rewards exceed forgone quarantine losses. The pilot (Months 6–24 = 2027-04-08 to 2028-10-08, 3–5 zones, 1,500–5,000 farmers) is too small and late to resolve design flaws before the Month 36 (2029-10-08) readiness gate. No binding rule ties clean-plant access to premium participation; no contractual obligation on countries to enforce quarantine fairly; no specification of who compensates farmers if their trees are removed despite reporting.

### 3.6.B Tags

- surveillance-incentive-misalignment
- concealment-risk-unaddressed
- adoption-fragmentation
- pilot-timing-too-late

### 3.6.C Mitigation

Redesign smallholder engagement as a unified income-and-access package: (1) Embed outcome-based surveillance premiums ($50–100 per verified report, paid within 30 days) into the replant-finance contract, so participation becomes part of loan eligibility and income stream, not optional compliance. (2) Design fair-quarantine rules: if SALB is detected on a reporting farm, compensation ($1,000–2,000 per affected tree, 90–180 day income bridge) is automatic, not discretionary, funded from the Outbreak Response Reserve. (3) Link clean-plant-network access to premium participation: only farms with ≥60% monitoring compliance receive subsidized planting material in the following season. (4) Launch surveillance pilots by Month 6 (2027-04-08) in 3–5 zones, targeting ≥60% farmer participation by Month 12 (2027-10-08), with independent third-party verification of participation and payment velocity. (5) By Month 24 (2028-10-08), pilot must show that surveillance income exceeds forgone quarantine penalties; if <40% participation or >30-day payment delays, escalate incentive design before Month 36 (2029-10-08) gate.

### 3.6.D Consequence

Without coherent incentive alignment: surveillance participation drops to 20–30% (estimate, consistent with historical comparables); SALB incursions in smallholder zones remain undetected until advanced (30–50% lag in detection time); outbreak containment costs increase 2–3× due to delayed response; program loses credibility in farmer communities; adoption of resistant cultivars stalls because farmers perceive risk without reward. By Month 84 (2033-10-08) Year 7 gate, smallholder-adoption floor of 1.5 million farmers is likely missed, failing the Month 144 (2038-10-08) gate minimum and blocking the resilience narrative.

### 3.6.E Root Cause

The plan lists smallholder components (finance, clean-plant, surveillance) as separate sub-programs, not as an integrated incentive architecture. Surveillance premiums are budgeted but not contractually linked to replant finance or clean-plant access. Quarantine-loss compensation is mentioned in the outbreak-response playbook but not integrated into the normal smallholder relationship, leaving farmers uncertain whether reporting is safe. This fragmentation allows trade-offs between pillars without resolving the incentive misalignment that determines whether smallholders will actually participate.

---

# 4 Expert: Smallholder Adoption and Surveillance-Incentive Designer

**Knowledge**: Smallholder credit access, income-bridge finance, behavior-change economics, disease-reporting incentives, clean-plant-material propagation networks, farm-level data systems

**Why**: Decision 8 (Smallholder Replanting Finance and Price Stability) and surveillance-premium design (pre-assessment finding: weak smallholder adoption <30% typical, leaving incursions undetected) are essential for supply-chain resilience and containment verification. This expert advises on embedding outcome-based surveillance premiums into replanting finance to make reporting an income stream rather than a compliance burden.

**What**: Launch surveillance-premium pilots in 3-5 zones (Sumatra, Côte d'Ivoire, northeast India, Rondônia) during Months 6-24 (2027-04-08 to 2028-10-08) targeting ≥60% farmer participation and 30-day payment velocity, and design clean-plant-network eligibility logic to create self-reinforcing adoption cycles.

**Skills**: Smallholder financial inclusion, incentive-compatible mechanism design, mobile payment systems, agricultural extension and farmer cooperatives, pest-surveillance community engagement, behavioral economics for adoption

**Search**: smallholder farmer finance, agricultural insurance design, disease surveillance incentives, rural extension adoption, income-bridge credit, clean agriculture certification

## 4.1 Primary Actions

- Immediately (Month 1 = 2026-11-08): separate Year 3 gate into 'Protocol Readiness Verification' (infrastructure KPIs) and deferred 'Containment Efficacy Review' (Months 72–84 = 2032-10-08 to 2033-10-08, field outcome metrics). Establish binding USD 500M–$1B Outbreak Response Reserve in independent escrow, pre-authorized for rapid deployment (4–6 weeks), decoupled from gate logic. Document separation in Technical Gate Charter by Month 3 (2027-01-08).
- By Month 2 (2026-12-08): commission Pathogen Genomics Laboratory (Brazil, CEPLAC or Embrapa location) with whole-genome sequencing and virulence-genotyping capacity (≥100–150 isolates annually). Establish mandatory Virulence Gates at Months 24, 36, 48, 60 (2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08) as binding sub-criteria preventing cultivar advancement. Enforce genetic architecture: no cultivar with fewer than 3 independent R-genes from ≥2 geographic sources is eligible for gate passage or commercial release.
- By Month 3 (2027-01-08): design outcome-based surveillance-premium scheme ($50–100 per verified disease report) and pilot in 3–5 smallholder zones (Sumatra, Côte d'Ivoire, northeast India, Rondônia, optional fifth) during Months 6–24 (2027-04-08 to 2028-10-08). Target ≥60% farmer participation in pilot; if <40% achieved by Month 18 (2028-04-08), increase premium rates and link to price-floor stabilization. Pre-allocate USD 2–3B (vs. current USD 1.25B) for smallholder income-safety nets if adoption-risk contingency triggers, drawn from USD 4.5B contingency pool.
- By Month 3 (2027-01-08): secure binding, ≥10-year funding commitments from ≥5–8 sovereign governments and ≥2 multilateral development banks, with no single funder >25% of total capital (USD 7.5B cap per funder). Document political-turnover clauses and minimum-floor guarantees (no country's allocation drops >20% if gate underperforms). Execute Technical Gate Charter with all funders, producer governments, OEMs, and Technical Panel members; publish all gate evidence 60 days before decisions, with 30-day public-appeal window.
- By Month 6 (2027-04-08): execute binding Nagoya Protocol and benefit-sharing agreements with Brazilian authorities, indigenous organizations, and state governments (Amazonas, Rondônia, Acre, Mato Grosso do Sul), pre-clearing ≥200 wild Hevea collection sites and 6+ access agreements. Deliver ≥200 characterized wild Hevea accessions (with preliminary SALB-resistance phenotype and legal ABS documentation) by Month 18 (2028-04-08) to breeding consortiums.

## 4.2 Secondary Actions

- By Month 1 (2026-11-08): convene technical working group (Brazil, ≥5 major producing countries, IPPC Secretariat, FAO) to draft binding SALB Containment Protocol standard, specifying nursery-stock movement rules (≥3-month quarantine, pathogen testing, certification criteria), research-material controls, and contaminated-equipment decontamination procedures. Target protocol document <120 pages with numeric thresholds (e.g., zero tolerance for viable spores).
- By Month 2 (2026-12-08): establish Nagoya Protocol Task Force (Brazil's environment ministry, indigenous affairs, state representatives, community delegates) to negotiate master benefit-sharing framework covering ≥200 wild Hevea accessions. Specify royalty distribution (minimum 3% of cultivar sales to community fund), capacity-building commitments (100+ indigenous/traditional-community members trained by Month 36 = 2029-10-08), and governance seat (≥2 community representatives on breeding steering committee).
- By Month 3 (2027-01-08): publish Technical Gate Charter defining Year 3, 7, 12, and 18 gate KPIs with numeric thresholds and evidence standards. Establish independent Technical Panel (7–9 conflict-free members: Hevea breeder, plant pathologist, IPPC expert, alternative-crop agronomist, economist, climate modeler, financial auditor). Terms are staggered, 5-year each, with minimum 4-year overlap.
- By Month 6 (2027-04-08): establish Brazilian Germplasm Bank (CEPLAC Manaus or Embrapa) with containment greenhouse (500+ m² area), diagnostic laboratory (DNA sequencing capacity ≥20 isolates/month throughput), and cold-storage facilities (≥3,000 accession slots). Build or commission ≥4 high-containment SALB trial stations (≥2 endemic Latin America, ≥1 Asia, ≥1 Africa) by Month 12 (2027-10-08), each with screened greenhouse (1,000–2,000 m²), 10–15 hectare field blocks, and on-site pathogen laboratory (real-time PCR, sequencing, ≥50 samples/week throughput).
- By Month 12 (2027-10-08): establish digital reporting and verification system for smallholder disease surveillance (SMS-based, offline-capable, solar-charged devices, distributed to scouts). Design replant-finance terms (7–10 year loans, 3–4% interest, conditional on certified clean planting stock). Resolve open decisions: who services the USD 7.0B MDB lending (~USD 449M/yr debt service); hub capex financing split (program vs. offtake-backed debt); replant-loan capital source (on-lending of bank tranches vs. grant-funded).
- By Month 18 (2028-04-08): submit formal IPPC protocol proposal to IPPC Secretariat as a new international standard. Secure 15 country commitment letters pledging to embed protocol into national phytosanitary law within 12 months of IPPC approval. Establish OEM buyer consortium (5–8 tyre/rubber-goods makers) and secure 2–3 OEM take-or-pay letters of intent (500–2,000 t/yr each alternative rubber). Decide on flagship product (specialty guayule latex line, co-branded tire prototype, or farmer-income product) and commission proof-of-concept by Month 18 (2028-04-08).
- By Month 24 (2028-10-08): complete regional compacts in Asia and Africa (8–10 countries each) with mutual inspection reciprocity and shared quarantine zones. Train and certify 100–200 inspectors; procure equipment for 50 inspection checkpoints. Assess Virulence Gate performance at Month 24 (2028-10-08): challenge ≥3 candidate cultivars against ≥10 contemporary SALB isolates; document pass/fail and implications for breeding timeline. Publish first annual Pathogen Population Report (virulence-gene frequency, geographic differentiation, resistance-breakdown forecasts for Months 180–216 = 2041-10-08 to 2044-10-08).
- By Month 30 (2029-04-08): complete IPPC formal standard adoption route; activate fallback regional compact if formal standard adoption is delayed. Design and operationalize ASEAN levy pilot by Month 18 (2028-04-08), targeting USD 30M–50M annual collection by Month 30 (2029-04-08). Model incursion scenarios (full outbreak residual USD 1.5–4.5B vs. USD 4.5B contingency pool) and publish results to demonstrate to funders that response is pre-positioned.
- By Month 36 (2029-10-08): execute Month 36 (2029-10-08) Protocol Readiness gate decision (≥15 countries with enforceable import rules, ≥500 trained inspectors, ≥2 lab-cleared suspect detections). Release Year 3 tranche (USD 4.5B, scaled by attainment 70–100%). Initiate scaling of trial stations and surveillance networks. Commission alternative-rubber pilot processing (5,000–20,000 t/yr, proof of cost within 25% premium and tire-grade specs) for Month 84 (2033-10-08) gate input.
- Months 36–84 (2029-10-08 to 2033-10-08): scale surveillance infrastructure (at least 500 inspectors → at least 1,000 by Month 84 = 2033-10-08); ramp smallholder replanting (baseline to 0.5–1.0 million by Month 84 = 2033-10-08); advance breeding trials (candidates enter final-stage trials, pass Virulence Gates at Months 36, 48, 60 = 2029-10-08, 2030-10-08, 2031-10-08); secure ≥80% priced offtake for alternative-rubber hubs by Month 72 (2032-10-08).
- By Month 84 (2033-10-08): execute Month 84 (2033-10-08) cultivar-readiness gate (≥2 candidates with ≥90% resistance, ≥85% yield parity, passing Virulence Gates, with ≥5-year virulence-stability forecast). Release 70% of cultivar-phase tranches (50% if only 1 candidate); hold 30% for final trials. Execute alternative-rubber cost-and-quality gate (pilot cost ≤USD 1.62/kg, tire-grade tests ≥95% of Hevea specs). Release alternative-rubber tranches; approve hub construction for commissioning by Month 120 (2036-10-08). Publish Containment Efficacy Review checkpoint: ≥20 documented suspect detections logged by Month 84 (2033-10-08) (not requiring confirmed incursion); escalate surveillance sensitivity if <20.

## 4.3 Follow Up Consultation

At the next consultation (target Month 6 = 2027-04-08): review progress on all Month 1–3 (2026-11-08 to 2027-01-08) actions, especially separation of Year 3 gate logic and Outbreak Response Reserve establishment. Discuss pathogen-genomics lab staffing and Virulence Gate protocol details. Present pilot results from surveillance-premium scheme and smallholder engagement zones (Sumatra, Côte d'Ivoire, northeast India). Validate adoption-participation forecasts against emerging data; adjust income-safety-net budget if <40% participation is confirmed. Confirm funding commitments from sovereigns and MDBs and resolve open decisions on MDB debt servicing and hub financing. Review IPPC proposal timeline and regional compact progress. Assess flagship-product decision and OEM offtake momentum. Model Year 6 incursion scenarios and contingency-pool adequacy. Discuss climate-shock resilience of alternative-crop sites and post-funding institutional handover roadmap.

## 4.4.A Issue - Year 3 gate conflates readiness with efficacy; retroactive credibility collapse if incursion occurs Months 48–60 (2030-10-08 to 2031-10-08)

The Month 36 (2029-10-08) 'Protocol Readiness' gate measures infrastructure deployment (15 countries with binding rules, 500 inspectors, 2 detections logged) but not proven pathogen containment. If SALB incursion occurs Months 48–60 (2030-10-08 to 2031-10-08) despite gate passage, funders retroactively interpret the gate as a false negative and withdraw 50–80% of remaining tranches (historical analogue: CGIAR climate-adaptation program, 2009–2013, suffered ~60% funder exit when adaptation infrastructure did not prevent crop loss). The plan separates 'readiness' logic from 'efficacy' (review at Months 72–84 = 2032-10-08 to 2033-10-08) in the canonical facts but does not fund the outbreak reserve or pre-authorize response separately, leaving the gate's credibility hostage to biological chance.

### 4.4.B Tags

- gate_logic_flaw
- funder_confidence
- outbreak_response_funding
- readiness_vs_efficacy_gap

### 4.4.C Mitigation

Immediate action by Month 1 (2026-11-08): establish independent $500M–$1B Outbreak Response Reserve in separate escrow, pre-funded and pre-authorized for rapid deployment (4–6 weeks) upon confirmed SALB incursion in a currently-free region, decoupled from gate logic. Document this separation in the Technical Gate Charter (Month 3 = 2027-01-08): Year 3 gate gates tranches on readiness KPIs only; outbreak response is guaranteed independently, so gate failure does not invalidate due to incursion timing. Model incursion scenarios at Year 6 planning cycle (Month 72 = 2032-10-08) to demonstrate to funders that response is pre-positioned and program strategy pivots, not terminates. This separation preserves gate credibility and reduces mid-program funder exit from ~40% to ~15% (estimate, based on comparable 20–25 year development programs).

### 4.4.D Consequence

Without separation, an incursion at Month 54 (2031-04-08) will trigger: (1) retroactive reinterpretation of the Month 36 (2029-10-08) gate as failed (despite meeting stated KPIs), (2) funder panic and emergency meetings, (3) 50–80% withdrawal of remaining tranches (~$15–18B), (4) program suspension at the moment scaling is needed most. Residual outbreak cost of $1.5–4.5B against a $4.5B contingency pool is then consumed, and the combined stress (re-breeding, alternative-rubber delay) exhausts reserves by Month 80 (2033-06-08), forcing program termination or massive, unfunded emergency appeal. Estimated outcome: program collapses Months 60–84 (2031-10-08 to 2033-10-08), smallholder investment is lost, and SALB spreads uncontained.

### 4.4.E Root Cause

The plan's gate-design philosophy assumes 'readiness infrastructure = containment risk reduction,' but the causal link is loose: 500 inspectors and binding rules do not guarantee detection or intercept if the pathogen is already present (false negative risk ~10–30%, estimate). The plan does not distinguish between 'institutional readiness' (predictable, gatable) and 'biological outcome' (stochastic, not gatable on infrastructure alone). The combined-stress model (USD 2.4–6.3B claims vs. USD 4.5B pool, estimate) compounds the risk: a simultaneous incursion + re-breeding push exhausts reserves before Year 12, yet the plan does not pre-position capital for high-consequence simultaneous events.

## 4.5.A Issue - Resistance-breeding timelines compressed into binary gates; durability enforcement missing, risking resistance breakdown by Year 12–15

Resistance Breeding Strategy specifies pyramiding of ≥3 genes from ≥2 sources, but the gate architecture is brittle: Year 7 gate (Month 84 = 2033-10-08) passes only if ≥2 candidates show ≥90% resistance and ≥85% yield parity over ≥2 years of trials. This 5–7 year timeline for field trials is optimistic; historical Hevea multi-gene pyramiding takes 8–12 years per cycle (CIRAD, Embrapa records, estimate). Pathogen-virulence tracking is mentioned but not enforced: the plan mandates Virulence Gates at Months 24, 36, 48, 60 (2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08) in canonical facts yet does not link gate passage to cultivar-advancement decisions. Without virulence-durability assurance, cultivars released at Year 12 (Month 144 = 2038-10-08) risk single-gene or polygenic breakdown by Year 15–18 (Months 180–216 = 2041-10-08 to 2044-10-08), requiring USD 400–800M re-breeding and 5–8 year delay (historical precedent: Hevea IAC series, Brazil, 1970s–1990s, single-R-gene failure ~12 years post-release).

### 4.5.B Tags

- breeding_timeline_slippage
- virulence_gate_unenforced
- durability_assurance_gap
- single_gene_risk

### 4.5.C Mitigation

By Month 2 (2026-12-08), establish Pathogen Genomics Laboratory at CEPLAC (Manaus) and co-located satellite at Malaysian or Indonesian rubber research institute (Month 9 = 2027-07-08), each equipped for whole-genome sequencing and virulence genotyping of ≥100–150 SALB isolates annually. Mandate Virulence Gates as binding sub-criteria preventing cultivar advancement: at Months 24, 36, 48, 60 (2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08), challenge top ≥3 candidates against ≥10 contemporary isolates from ≥4 endemic-region sources; pass threshold = resistant to ≥80% of isolates. Enforce genetic architecture: no cultivar with fewer than 3 independent R-genes from ≥2 geographic sources is eligible for any gate advancement. Publish annual Pathogen Population Reports analyzing virulence-gene frequency trends and predicting probability of resistance breakdown by Months 180–216 (2041-10-08 to 2044-10-08). This enforcement framework shifts from 'field-trial success' to 'predicted durability,' reducing Year 15–18 breakdown risk from ~30–50% to ~10% (estimate).

### 4.5.D Consequence

Without virulence-tracking enforcement, the plan releases cultivars on field-trial evidence alone, missing pre-existing or emerging virulent biotypes in the pathogen population. If a cultivar released at Year 12 (Month 144 = 2038-10-08) carries only 1–2 R-genes, and the pathogen population contains isolates overcoming one or both (a ~15–30% risk estimate, undetected by field trials alone), resistance fails by Year 15–18 (Months 180–216 = 2041-10-08 to 2044-10-08). Consequence: (1) USD 400–800M investment in breeding that delivered no durable benefit; (2) 1.5–2 million smallholders with newly planted susceptible cultivars facing epidemic; (3) 5–8 year re-breeding cycle to recover, during which SALB may establish in Asia. Total cost: USD 400–800M + USD 2–5B outbreak response + reputational collapse of the program's core claim (de-risking supply via resistant cultivars).

### 4.5.E Root Cause

The plan treats breeding timelines as deterministic ('5–7 years to cultivar release') when they are inherently stochastic and slippage-prone. Virulence Gates are mentioned as 'binding' in canonical facts but are not connected to gate-release logic: Year 7 and Year 12 gate rules do not require Virulence Gate evidence as a pass/fail criterion. The plan also does not establish a pathogen genomics capability until Month 2 (2026-12-08) post hoc; without baseline virulence data, early Virulence Gates (Months 24–36 = 2028-10-08 to 2029-10-08) cannot function. Historical precedent: CGIAR maize-breeding programs struggled with unpredicted pathogen-resistance breakdown because virulence monitoring was under-resourced relative to breeding cycle speed.

## 4.6.A Issue - Smallholder adoption contingency opaque; surveillance participation target of ≥60% is unvalidated and adoption will fail at <40% participation

The plan requires ≥1.5 million smallholder adopters (50% of eligible 3 million) by Month 144 (2038-10-08) and baseline ≥60% surveillance participation in pilot zones (Months 6–24 = 2027-04-08 to 2028-10-08). Smallholder adoption is a design principle, yet financial and behavioral contingencies are underspecified. Replant-finance terms (7–10 year loans, 3–4% interest) are realistic, but repayment depends on stable latex prices and farmer income, both vulnerable to price shocks. Surveillance-premium scheme ($50–100 per verified report) incentivizes disclosure, but without income stabilization, smallholders face a 'adoption-plus-income-risk' trade-off that typical adoption curves show fails at 20–40% participation (historical analogue: CGIAR conservation-agriculture uptake in Zambia, 2010–2018, stabilized at ~25–35% despite subsidies, due to competing cash-flow pressures). The plan allocates only USD 1.25B to surveillance premiums (estimate, ~USD 25–33 per farmer per year at 2 million scale), yet adoption literature suggests durable behavior change at smallholder scale requires USD 50–100 per farmer per year in safety-net transfers (World Bank rural-development studies, estimate).

### 4.6.B Tags

- smallholder_adoption_risk
- surveillance_incentive_gap
- income_stability_missing
- participation_target_unvalidated

### 4.6.C Mitigation

By Month 3 (2027-01-08), design outcome-based surveillance premiums ($50–100 per verified disease report, $25–50 for unconfirmed suspects) integrated into smallholder replanting finance, with fast-track payment (within 30 days) to build trust and participation velocity. Pilot in 3–5 representative zones (Sumatra, Côte d'Ivoire, northeast India, Rondônia, ≥1 other) during Months 6–24 (2027-04-08 to 2028-10-08), enrolling 500–1,000 farmers per zone. Pilot targets: ≥60% participation rate, ≥$200–400 annual premium per farmer (15–25% of smallholder latex income estimate). Embed clean-plant-network access into premium eligibility: only farms maintaining ≥90% clean-plant practices (verified quarterly via mobile GPS-photo spot checks) remain eligible for subsidized planting material or credit refinancing. If pilot achieves targets, scale to 2–3 million farmers by Month 120 (2036-10-08). If pilot participation falls below 40% by Month 18 (2028-04-08), redesign: increase premium rates to USD 100–150 per sample, link to retail price-floor stabilization, or pivot to income-bridge grants (non-repayable safety net) for adoption-plus-stabilization. Pre-allocate USD 2–3B (vs. current USD 1.25B estimate) for smallholder safety nets if income-risk contingency is triggered, funded from the contingency pool (USD 4.5B reserve).

### 4.6.D Consequence

Without validated adoption mechanisms and income stabilization, pilot participation will likely stabilize at 20–35% by Month 18 (2028-04-08), far below the ≥60% target. Consequence cascade: (1) surveillance participation in smallholder zones drops 60–80%, leaving SALB incursions undetected until advanced establishment (false-negative risk +15–30%, estimate); (2) smallholder replanting with resistant cultivars fails to reach 1.5 million by Month 144 (2038-10-08), likely stabilizing at 0.5–0.8 million (20–30% adoption), undermining the plan's supply-chain resilience claim; (3) if SALB incursion occurs Months 90–120 (2034-10-08 to 2036-10-08) with low smallholder adoption, outbreak-response cost doubles (USD 4–8B estimate vs. USD 2–5B with high adoption), exhausting the outbreak reserve within 6 months and forcing additional emergency funding (~USD 2–3B draw from contingency pool). Reputational and financial outcome: program's core value proposition (smallholder de-risking and resilience) fails, funder confidence collapses, and political pressure to exit intensifies.

### 4.6.E Root Cause

The plan treats smallholder adoption as a 'delivery mechanism' separate from financing and income stability, but adoption literature (World Bank, CGIAR, FAO studies) shows that smallholder technology uptake is driven by income volatility and cash-flow pressure more than by availability of credit. The plan's surveillance-premium budget (USD 1.25B over 25 years, ~USD 25–33 per farmer per year at scale) is half the safety-net transfer level needed for durable behavior change (estimate, ~USD 50–100 per farmer per year). The pilot targets (≥60% participation) are unvalidated baseline estimates; no pilot data from rubber-zone smallholders exists. The plan also does not account for farmer heterogeneity: adopters of new cultivars and surveillance practices are typically the wealthiest 20–30% of smallholders, while the poorest 40–50% remain passive, creating a 'adoption tail' that cannot be closed with incentives alone (income-bridge and price-stabilization mechanisms are prerequisite, not optional).

---

# 5 Expert: Alternative Rubber Crop Economics and Processing-Hub Viability Analyst

**Knowledge**: Guayule and Russian dandelion agronomy, extraction and processing technology, co-product revenue modeling, hub capital and operating-cost estimation, tire-grade specification and cost-competitiveness benchmarking

**Why**: Decision 7 (Alternative Rubber Portfolio and Processing Siting) and the hub-bankability bottleneck (canonical fact: opex at USD 1.62/kg covers debt at only 0.80x, shortfall USD 12M/yr) expose the Year 7 cost-parity gate as the program's highest financial risk. This expert advises on whether processing economics can meet the Month 84 (2033-10-08) gate threshold of USD 1.62/kg maximum and validates co-product revenue assumptions (rubber, resin, bagasse, inulin) that may be overstated.

**What**: Conduct engineering cost reviews at pilot scale (Months 12-36 = 2027-10-08 to 2029-10-08) to de-risk the hub-bankability threshold of USD 1.47/kg, identify co-product markets and pricing, stress-test the hub financing split (50% program, 50% offtake-backed debt) if offtake lags, and recommend hub siting (grower-proximate cooperatives vs. OEM-proximate centralized hubs) that optimize both economics and smallholder participation.

**Skills**: Process engineering for crop extraction, variable-cost budgeting, capital intensity and scale trade-offs, commodity price forecasting, financial-modeling of agro-processing ventures, supply-chain logistics, co-product market analysis

**Search**: guayule extraction economics, Russian dandelion processing technology, natural rubber alternative crop cost analysis, agro-processing hub finance, tire-grade latex specification

## 5.1 Primary Actions

- By Month 1 (2026-11-08), establish binary contingency-reserve architecture separating 'Protocol Readiness Verification' (Year 3 gate, infrastructure metrics) from 'Containment Efficacy Review' (Months 72–84 = 2032-10-08 to 2033-10-08, outcome metrics: ≥50 suspect detections). Fund independent Outbreak Response Reserve (USD 0.5B–$1.0B) in escrow, deployable within 4–6 weeks of confirmed SALB incursion in currently-free regions, independent of Year 3 gate logic. Publish charter defining both gates before Month 3 (2027-01-08).
- By Month 2 (2026-12-08), establish Pathogen Genomics Laboratory in Brazil (CEPLAC or Embrapa) with sequencing, inoculation assay and bioinformatics capacity (budget USD 1.0–1.5M, ≥1 senior mycologist, 1 bioinformatician, 2 technicians). Establish Asian satellite facility by Month 9 (2027-07-08). Mandate Virulence Gates at Months 24, 36, 48, 60 (2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08) as binding sub-criteria preventing cultivar advancement. Prohibit single-R-gene cultivars from release.
- By Month 3 (2027-01-08), design outcome-based surveillance premiums (USD 50–100 per verified disease report) and pilot in 3–5 representative smallholder zones (Sumatra, Côte d'Ivoire, northeast India, Rondônia, ≥1 other) during Months 6–24 (2027-04-08 to 2028-10-08), targeting ≥60% farmer participation, ≤30-day payment, ≥95% diagnostic accuracy. Embed clean-plant-network eligibility into premium structure. If pilot participation <40% by Month 18 (2028-04-08), redesign payment structure or increase rates to USD 100–150/sample.

## 5.2 Secondary Actions

- By Month 3 (2027-01-08), establish Technical Gate Charter and Independent Technical Panel (7–9 conflict-free members: Hevea breeder, plant pathologist, phytosanitary expert, alternative-crop agronomist, development economist, climate modeler, financial auditor). Charter defines Year 3, 7, 12, 18 gate KPIs, adaptive tranching rules (70–85% attainment releases 70–85% of tranches), partial-release threshold, and appeal processes. Publish gate evidence 60 days before each decision.
- By Month 6 (2027-04-08), complete Nagoya Protocol access-and-benefit-sharing negotiations with Brazilian states (Amazonas, Rondônia, Acre, Mato Grosso do Sul) and ≥5 indigenous/traditional community organizations. Secure signed agreements pre-clearing ≥30–50 wild collection sites per state, 2–3 campaigns/year (Months 6–12 and January–March), 40–60 accessions per campaign. Benefit-sharing terms: ≥3% of cultivar sales to community fund (10-year life post-release), ≥100 community members trained, ≥2 community representatives on breeding steering committee.
- By Month 12 (2027-10-08), procure and begin construction of ≥4 high-containment SALB trial stations (≥2 in endemic Latin America [Rondônia, Peru], ≥1 in Asia, ≥1 in Africa). Each: 1,000–2,000 m² screened greenhouse, 10–15 hectares open-field trials with 50-meter buffer zones, pathogen laboratory (real-time PCR, sequencing, ≥50 samples/week). Capital cost USD 3–5M per station; funding allocation USD 12–20M from Years 0–3 budget. Begin pathogen genomics lab operations (Brazil: Month 2 = 2026-12-08; Asia: Month 9 = 2027-07-08).
- By Month 18 (2028-04-08), deliver ≥200 characterized wild Hevea accessions with documented SALB-resistance phenotype (compatible/incompatible reaction to ≥2–3 representative strains) and legal passport data (GPS, collection date, community benefit-sharing documentation). Sign 2–3 OEM take-or-pay letters of intent (500–2,000 t/yr each). Publish formal IPPC protocol proposal to IPPC Secretariat (formal route) in parallel with binding regional Asia and Africa compacts.
- By Month 24 (2028-10-08), secure binding multi-year funding commitments from ≥5–8 sovereign governments and ≥2 multilateral development banks (no single funder >25% of capital). Obtain binding commitment letters from ≥15 producing countries (Indonesia, Malaysia, Thailand, India, Vietnam, Côte d'Ivoire, Ghana, Cameroon, Brazil, Peru, Ecuador, ≥4 others) pledging to embed protocol into national phytosanitary law within 12 months of IPPC approval. Begin ASEAN levy pilot (target collection by Month 18 = 2028-04-08), achieving ≥80% compliance by Month 36 (2029-10-08).
- By Month 36 (2029-10-08), reach Year 3 Protocol Readiness gate: ≥15 producing countries with enforceable import rules, ≥500 trained/audited inspectors, ≥2 lab-cleared suspect detections (regional minimums Asia 8, Africa 4, Americas 3). Establish three-layer financial resilience: contingency pool (USD 4.5B, 15%), outbreak reserve (USD 0.5B–$1.0B), political-risk reserve (USD 0.9B, 3%). Release Year 3–7 tranches (USD 4.5B) under adaptive rules (70–100% attainment → 70–100% release; <70% → 50% release).
- Monitor Virulence Gate results at Months 24, 36, 48, 60 (2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08). If any candidate fails (resistant to <80% of ≥10 isolates), hold that candidate, extend pyramiding timeline, and redesign before re-testing at next gate (6 months later).
- By Month 72 (2032-10-08), target checkpoint for Containment Efficacy Review: ≥20–30 documented suspect detections logged; if <20, escalate surveillance sensitivity (increase inspector sampling, add environmental DNA monitoring). Publish annual Pathogen Population Reports (virulence-gene frequency, geographic structure, 10-year durability forecast) by Months 12, 24, 36, 48, 60, 72, 84, 96 (2027-10-08, 2028-10-08, etc.), informing cultivar-selection decisions.

## 5.3 Follow Up Consultation

Next meeting focus: (1) Gate-logic separation and Outbreak Response Reserve funding mechanism—who holds reserve, deployment trigger, accountability; (2) Pathogen Genomics Lab staffing, bioinformatics pipeline and annual cost—coordinate with Brazil; (3) Surveillance premium pilot design for 3–5 zones—partner identification, farmer enrollment, payment logistics, success metrics at Month 18 (2028-04-08); (4) Virulence Gate integration into cultivar-advancement rules and Year 7/12 gate checklists; (5) Hub bankability assumptions and debt-service modeling—who refinances the USD 7.0B concessional lending post-Year 5, and how are cashflows linked to cultivar and alternative-rubber revenue; (6) Levy pilot compliance and fallback cascade trigger (Month 48 = 2030-10-08) if compliance <60%; (7) OEM buyer consortium recruitment (Month 6 = 2027-04-08) and co-funded qualification testing roadmap.

## 5.4.A Issue - Month 36 (2029-10-08) Gate Conflates 'Protocol Readiness' with 'Containment Efficacy'—Retroactive Credibility Risk

The Year 3 gate (Month 36 = 2029-10-08) releases USD 4.5B based on infrastructure metrics: 15 countries with binding rules, 500 trained inspectors, 2 lab-cleared detections. This measures institutional deployment, not proven pathogen prevention. If an incursion occurs at Months 48–60 (2030-10-08 to 2031-10-08) despite gate passage, funders will interpret gate failure retroactively, triggering 40–60% withdrawal. The plan lacks a separate, deferred Containment Efficacy Review that measures whether surveillance actually detected infections. Months 72–84 (2032-10-08 to 2033-10-08) should assess at least 50 documented suspect detections; zero detections are ambiguous (success or detection failure?).

### 5.4.B Tags

- gate-logic-gap
- funder-credibility-risk
- outcome-vs-process-metrics
- retroactive-invalidation

### 5.4.C Mitigation

Separate Year 3 gate into two components: (1) 'Protocol Readiness Verification' (Month 36 = 2029-10-08, process metrics) gates Year 3–7 tranches (USD 4.5B); (2) 'Containment Efficacy Review' (Months 72–84 = 2032-10-08 to 2033-10-08, outcome metrics: ≥50 suspect detections) informs Years 13–18 strategy without retroactively invalidating Year 3. Concurrently establish independent Outbreak Response Reserve (USD 0.5B–$1.0B, deployable within 4–6 weeks of confirmed incursion) outside gate logic. If incursion occurs post-Year-3 gate, reserve funds response without gate revision, preserving gate logic and funder confidence. Publish Containment Efficacy Review evidence 60 days before Month 84 (2033-10-08) assessment.

### 5.4.D Consequence

If gate logic is not separated, an incursion at Years 4–5 retroactively damages Year 3 gate credibility, triggering funder panic and 40–60% capital withdrawal. Program loses momentum mid-stream, alternative-rubber and cultivar tracks stall. Remaining funders demand renegotiation of tranches and governance. Estimated cost: USD 1.5–3.0B in delayed investments and funder exit losses.

### 5.4.E Root Cause

The plan frames Year 3 gate as 'verification of containment' when it can only verify 'protocol deployment.' Containment is an outcome that can only be proven over years through surveillance data. The gap reflects confusion between leading indicators (infrastructure readiness) and lagging indicators (actual pathogen prevention). Without splitting gates logically, the program is hostage to biological luck in Months 48–60 (2030-10-08 to 2031-10-08).

## 5.5.A Issue - Resistance Durability Enforcement Weak—Single-Gene Cultivars Risk Failure by Year 12–15

The plan mandates ≥3 resistance genes from ≥2 sources and Virulence Gates at Months 24, 36, 48, 60 (2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08), but implementation details are missing. No pathogen genomics lab is funded or sited until Month 2 (2026-12-08), 2 months from project start—a late trigger for critical infrastructure. Virulence Gates are mentioned but not integrated into cultivar-advancement rules: what prevents a single-R-gene candidate from advancing if field trials show 90% resistance? Historical precedent (SALB resistant Hevea cultivars, 1970s–1990s) shows single-gene deployments fail 5–10 years post-release when pathogen virulence shifts. Genetic durability—the core value proposition over 25 years—is underspecified.

### 5.5.B Tags

- resistance-durability-risk
- virulence-tracking-underfunded
- genetic-architecture-enforcement-gap
- field-trial-to-release-logic-undefined

### 5.5.C Mitigation

By Month 2 (2026-12-08), establish Pathogen Genomics Laboratory in Brazil (CEPLAC, Manaus) with sequencing, inoculation assay and bioinformatics capacity. Establish Asian satellite by Month 9 (2027-07-08). Mandate Virulence Gates at Months 24, 36, 48, 60 (2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08): challenge top ≥3 candidates against ≥10 contemporary SALB isolates (≥4 geographic sources). Pass = resistant to ≥80% of isolates; fail = hold candidate, extend pyramiding, do not advance. Embed into Year 7 and Year 12 cultivar-readiness gates as non-negotiable sub-criteria. Publish annual Pathogen Population Report (virulence-gene frequency, geographic structure, 10-year durability forecast). Prohibit single-R-gene cultivars from release, regardless of field performance.

### 5.5.D Consequence

Without enforced Virulence Gates, a single-R-gene candidate (faster to develop, easier to validate) may be released at Year 7 to meet gate timelines and funder pressure. Pathogen virulence shifts by Year 12–15, resistance breaks down, crop loss follows. Re-breeding and redeployment of pyramided cultivars requires 5–8 years and USD 400M–$800M (estimate). Program's supply-chain resilience claims are forfeit. Estimated probability: 30–50% if enforcement is weak.

### 5.5.E Root Cause

Field-trial success (yield, disease suppression under trial conditions) does not predict genetic durability (resistance stability against pathogen evolution). The plan confuses 'candidate shows resistance in trials' with 'candidate will hold resistance for 20+ years.' Pathogen genomics and virulence tracking are mentioned but not tied to hard gates; they remain optional background work rather than binding advancement criteria.

## 5.6.A Issue - Smallholder Surveillance Participation Likely <30% Without Aligned Incentives—Incursions Undetected

The plan assumes 50–60% smallholder adoption and implies farmers will report disease. Historical adoption data for conservation or surveillance schemes shows 15–30% participation without aligned incentives; with subsidized inputs (replant loans, clean material) but no direct income for reporting, participation typically stays 20–40%. Current plan offers replant finance and income-bridge loans but does not specify outcome-based surveillance premiums. If farmers fear quarantine and income loss from reporting, they conceal infections. This is a fatal flaw: undetected SALB in a smallholder zone spreads for 12–24 months before epidemic scale detection, costing USD 1–3B additional outbreak response. The plan mentions 'farmers participate in surveillance' as a design requirement but does not engineer aligned incentives.

### 5.6.B Tags

- farmer-incentive-misalignment
- surveillance-participation-low
- undetected-incursion-cost
- smallholder-adoption-contingency

### 5.6.C Mitigation

Design outcome-based surveillance premiums (USD 50–100 per verified disease report, USD 25–50 for unconfirmed suspects) integrated into replant finance at Months 6–24 (2027-04-08 to 2028-10-08). Pilot in 3–5 zones (Sumatra, Côte d'Ivoire, northeast India, Rondônia, ≥1 other) targeting ≥60% farmer participation. Payment turnaround ≤30 days via mobile reporting and SMS confirmation. Embed clean-plant-network access into premium eligibility: farms with ≥90% clean-plant practices receive +USD 20–30/hectare/year. Early-detection bonus (USD 500–1,000) if a farm's sample triggers first regional confirmation. Surveillance participation becomes income-generating rather than compliance burden. Estimated pilot cost USD 10–25M; scaled cost USD 1.25B over 25 years. Monitor pilot results at Month 18 (2028-04-08); if participation <40%, redesign payment structure.

### 5.6.D Consequence

If smallholder surveillance incentives are not aligned, participation stays 15–30%, leaving 70–85% of smallholder zones poorly monitored. An incursion in a smallholder zone spreads undetected for 12–24 months before reaching plantation scale. Outbreak-response cost climbs from USD 2–5B (early detection at plantation scale) to USD 3–8B (late detection at endemic scale), consuming the USD 0.5B standing reserve and USD 1.5–3.5B of the USD 4.5B contingency pool. Remaining funders see USD 6–8B+ total outbreak cost and lose confidence in program durability. Estimated probability of low participation: 60–70% without explicit incentive design.

### 5.6.E Root Cause

The plan treats 'smallholder adoption' and 'surveillance participation' as outcomes of subsidized inputs (loans, clean material), not as economic behaviors requiring aligned incentives. Farmers rationally conceal disease to avoid quarantine and income loss. Without outcome-based rewards for reporting (premiums), farmers remain in a prisoner's dilemma: reporting carries personal risk, concealment carries shared (but delayed, distributed) risk. The plan has not modeled farmer behavior or tested incentive alignment in pilot zones.

---

# 6 Expert: OEM Supply-Chain Resilience and Procurement Officer

**Knowledge**: Tyre-manufacturer procurement strategy, natural rubber supply-chain risk, tire-grade material qualification and cost-competitiveness standards, take-or-pay contracting, alternative-material hedging strategy, supply-chain visibility and sustainability commitments (GPSNR, corporate ESG)

**Why**: Decision 9 (OEM Offtake and Demand Commitments) is the linchpin converting alternative-rubber plants from grant-dependent to bankable. Weak offtake (canonical fact: less than 80% of volume committed by Month 60 = 2031-10-08 triggers a 1-3 year delay, likely missing Month 144 = 2038-10-08 targets) is the second-highest financial risk. This expert advises on building a buyer consortium, structuring take-or-pay terms that survive cost pressure, and creating a 'killer application' (flagship product) that pulls OEM engagement before an outbreak triggers urgency.

**What**: Assemble the OEM buyer consortium (5-8 major tyre manufacturers) by Month 6 (2027-04-08), co-fund tire-grade qualification testing (Months 12-30 = 2027-10-08 to 2029-04-08), broker 2-3 letters of intent by Month 18 (2028-04-08), and negotiate binding priced offtake for at least 80% of planned volumes by Month 72 (2032-10-08). Identify or develop a flagship co-branded product (SALB-proof tire, hypoallergenic medical goods) with visible consumer and brand value to create demand pull and reduce OEM risk aversion.

**Skills**: Tyre-industry procurement, supply-contract negotiation, materials qualification and testing standards, cost-competitiveness benchmarking, supply-chain risk modeling, corporate sustainability strategy, buyer-consortium coordination

**Search**: tire manufacturer procurement, natural rubber supply chain management, material qualification testing, OEM take-or-pay contracting, alternative elastomer adoption, supply-chain resilience strategy

## 6.1 Primary Actions

- By Month 1 (2026-11-08), establish independent USD 500M–USD 1B Outbreak Response Reserve in escrow, with binding compensation rules (tree-removal payments, fungicide stockpiles, smallholder income bridges, quarantine-zone operations) deployable within 4–6 weeks of confirmed SALB incursion in free regions. Separate reserve logically and financially from gate decisions, so Year 3 gate credibility is not retroactively damaged by an incursion at Months 48–60 (2030-10-08 to 2031-10-08). Publish reserve policy and trigger criteria to all funders.
- By Month 2 (2026-12-08), fund and establish Pathogen Genomics Laboratory at CEPLAC (Manaus) or Embrapa field station in Brazil, equipped for annual whole-genome sequencing of ≥100–150 SALB isolates and virulence-gene identification. Simultaneously, commission Asian satellite facility (Malaysia, Indonesia, or Thailand) to begin operation by Month 9 (2027-07-08). Budget USD 500K–USD 1M per facility annually (USD 25–50M over 25 years, <1% of breeding-phase allocation).
- By Month 3 (2027-01-08), establish Technical Gate Charter (binding on all funders, producers, OEMs, experts), defining Year 3/7/12/18 gate KPIs with numeric thresholds and independent verification. Enforce mandatory Virulence Gates at Months 24, 36, 48, 60 (2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08) as binding sub-criteria preventing cultivar advancement if resistance is <80% against ≥10 contemporary isolates. Bar single-R-gene cultivars from release entirely. Publish Technical Panel membership and 60-day evidence transparency rule.
- By Month 3 (2027-01-08), design outcome-based surveillance-premium scheme (USD 50–100 per verified disease report, USD 25–50 for negative suspects, USD 20–30/hectare for clean-plant maintenance) and pilot in 3–5 representative smallholder zones (Sumatra, Côte d'Ivoire, northeast India, Rondônia, optional fifth) at Months 6–24 (2027-04-08 to 2028-10-08). Target ≥60% farmer participation and 30-day payment velocity. Embed clean-plant-network access into premium eligibility, converting surveillance from compliance to income stream.
- By Month 3 (2027-01-08), secure binding, ≥10-year funding commitments from 5–8 sovereign governments and ≥2 multilateral development banks, formalized via treaties or cabinet resolutions (not voluntary pledges). Ensure no single funder holds >25% of capital. Structure release tied to stage-gate performance (30% Year 3 contingent, 35% Year 7, 35% Years 12–18), with minimum-floor guarantee (no allocation drops >20% even if gate underperforms). Publish commitment letters and funder list.
- By Month 6 (2027-04-08), complete Nagoya Protocol and access-and-benefit-sharing (ABS) negotiations with Brazil (Ministry of Environment, indigenous-affairs ministry, Amazonas/Rondônia state governments, ≥2 indigenous/traditional-community representatives). Secure ≥6 bilateral access agreements pre-clearing wild-collection sites and stipulating royalty distribution (≥3% of cultivar sales to community fund), capacity-building commitments (100+ community members trained by Month 36 = 2029-10-08), and ≥2 governance seats for communities. Begin wild Hevea accession collection by Month 8 (2027-06-08).
- By Month 12 (2027-10-08), procure and build ≥4 high-containment SALB trial stations (capex USD 3–5M each, USD 12–20M total): ≥2 live-pathogen stations in endemic Latin America (Rondônia, Peru), ≥1 clean-zone station in Asia, ≥1 in Africa. Each station must include screened greenhouse (1,000–2,000 m²), open-field trial blocks (10–15 hectares with 50m buffer zones), pathogen lab (real-time PCR, sequencing, ≥50 samples/week throughput), quarantine equipment (autoclave, chemical treatment, spore disposal). Baseline inspection by Month 15 (2028-01-08).
- By Month 18 (2028-04-08), deliver ≥200 characterized wild Hevea accessions from Brazil (with documented SALB-resistance potential via preliminary screening, passport data, and legal Nagoya/ABS documentation) to international breeding consortiums. Submit formal SALB Containment Protocol proposal to IPPC Secretariat as a new international standard. Secure ≥2–3 OEM take-or-pay letters of intent (500–2,000 t/yr each alternative rubber or resistant-cultivar offtake). Resolve hub-financing split decision (recommend 50% program-financed, 50% offtake-backed debt).

## 6.2 Secondary Actions

- By Month 0 (2026-10-08), convene technical working group (Brazil, ≥5 major producing countries, IPPC Secretariat, FAO) to draft binding SALB Containment Protocol specifying nursery stock movement rules (≥3-month quarantine, pathogen testing, certification), research-material controls (export permits, import licensing, containment levels), and equipment decontamination procedures (chemical/thermal treatments, inspection frequency). Produce 120-page technical specification with numeric thresholds.
- By Month 6 (2027-04-08), establish OEM buyer consortium of 5–8 major tyre manufacturers and rubber-goods OEMs. Commit to co-funded tire-grade qualification testing (Months 12–30 = 2027-10-08 to 2029-04-08) for alternative rubber and resistant-cultivar latex. Agree on offtake milestones: 2–3 letters of intent (Month 18 = 2028-04-08), binding priced offtake for ≥80% of planned volume (Month 72 = 2032-10-08).
- By Month 9 (2027-07-08), establish Asian Pathogen Genomics satellite facility (Malaysia, Indonesia, or Thailand), co-located with rubber research institute. Equip for annual isolate sequencing (≥50 isolates/year from endemic and traded material). Design data-sharing protocol with Brazilian lab and breeding consortiums. Recruit senior mycologist and bioinformatician.
- By Month 12 (2027-10-08), deploy digital disease-reporting platform (SMS-based, offline-capable, GPS-embedded) to smallholder pilots. Establish regional diagnostic-laboratory network (≥3 labs serving pilot zones) capable of sample processing and result notification within 7–14 days. Pilot cost USD 10–20M (included in smallholder finance allocation).
- By Month 12 (2027-10-08), establish independent Technical Panel (7–9 conflict-free members including Hevea breeder, plant pathologist, phytosanitary expert, alternative-crop agronomist, development economist, climate specialist, financial auditor). Stagger 5-year terms (4-year overlap minimum). Publish deliberation records and 30-day public comment period before gate decisions.
- By Month 18 (2028-04-08), design adaptive tranching rule: Year 3 gate releases funding proportional to KPI attainment (85–100% criteria = 100% tranche; 70–85% = proportional release; <70% = 50% release, remainder to contingency pool). Establish reallocable reserve (10–15% of Year 3–7 tranches) to shift capital among pillars based on strongest evidence.
- By Month 18 (2028-04-08), pilot ASEAN levy (1.4% ad valorem on natural-rubber trade, approximately USD 19/tonne at USD 1,350/t reference price) collection at major trading ports (Singapore, Rotterdam). Target ≥USD 30–50M annually; operational by Month 24 (2028-10-08). Trigger fallback cascade (higher development-bank lending, outcome-linked bonds) if pilot compliance is <60% by Month 48 (2030-10-08).
- By Month 24 (2028-10-08), secure binding commitment letters from ≥15 producing countries (Indonesia, Malaysia, Thailand, India, Vietnam, Côte d'Ivoire, Ghana, Cameroon, Brazil, Peru, Ecuador, ≥4 others), each pledging to embed SALB Containment Protocol into national phytosanitary law within 12 months of IPPC approval. Letters must specify national lead agency, inspector-recruitment targets (≥30 inspectors per country), and domestic budget allocation.
- By Month 30 (2029-04-08), commission final-stage cultivar trials for ≥2 pyramided SALB-resistant candidates (≥3 independent resistance genes per candidate, ≥2 geographic sources). Ensure candidates carry markers for all resistance genes and have passed Virulence Gates at Months 24 and 36 (2028-10-08, 2029-10-08). Plan for 4–6 year multi-site field validation (Months 30–60 = 2029-04-08 to 2031-10-08).
- By Month 36 (2029-10-08), complete formal IPPC standard adoption process or activate provisional regional compacts in Asia (8–10 countries) and Africa (6–8 countries) with reciprocal inspection rights and shared quarantine zones. Operationalize Month 36 (2029-10-08) gate: assess ≥15 countries with enforceable import rules, ≥500 trained/audited inspectors, ≥2 lab-cleared suspect detections; if 85–100% of criteria met, release 100% of Year 3–7 tranche (USD 4.5B); if 70–85%, release proportionally; if <70%, release 50% (USD 2.25B) to contingency.
- By Month 60 (2031-10-08), achieve ≥80% binding priced offtake commitment from OEM buyer consortium for alternative-rubber volume (500–2,000 t/yr per OEM, ≥5–8 OEMs = 2,500–16,000 t/yr total). Validate tire-grade specifications and co-products revenue streams. Approve first commercial hub construction only if this threshold is met; defer hub construction if offtake is <80%, adding 12–36 months to timeline.
- By Month 72 (2032-10-08), model combined-stress scenarios (simultaneous full outbreak residual USD 1.5–4.5B + re-breeding USD 0.4–0.8B + alternative-rubber remediation USD 0.5–1.0B = USD 2.4–6.3B vs USD 4.5B contingency pool). Identify shortfall of up to USD 1.8B and pre-authorize capital reallocation (e.g., defer non-critical complementary R&D, accelerate cultivation-phase sales revenue).
- By Month 84 (2033-10-08), release Year 7 gate tranches based on: ≥2 pyramided SALB-resistant candidates with ≥90% resistance and ≥85% elite-clone yield over ≥2 years, passing Virulence Gates; alternative-rubber pilot cost within 20% of Hevea reference (≤USD 1.62/kg) with tire-grade tests at ≥95% specs; ≥2 OEM take-or-pay offtake letters signed. If criteria 85–100% met, release 100%; if 70–85%, release proportionally; if <70%, release 50% and reserve remainder.

## 6.3 Follow Up Consultation

Next consultation to address: (1) Killer application strategy—which single OEM-branded use-case (specialty guayule latex, co-branded SALB-proof tire, or farmer-income surveillance product) would move OEMs and funders before an outbreak? Commission market research and co-brand proof-of-concept by Month 18 (2028-04-08). (2) Hub bankability—resolve capex-financing split (program vs. offtake-backed debt), MDB debt-service assumptions (USD 449M/yr repayment from Month 60 = 2031-10-08), and co-product revenue validation. (3) Smallholder-credit access—validate loan capital source (on-lending of USD 7.0B bank tranches vs. dedicated microfinance mechanism) and land-title data by producing region. (4) Climate-pivot contingency—SALB suitability modeling for Asia/Africa at +1.5–2°C warming; if models show heightened risk Months 60–84 (2031-10-08 to 2033-10-08), accelerate surveillance investment and alternative-crop breeding. (5) Funder coordination—resolve multi-year commitment binding mechanics and fallback triggers for levy underperformance. Consult IPPC Secretariat, FAO, and leading rubber research institutes monthly; validate germplasm and trial milestones quarterly.

## 6.4.A Issue - Month 36 (2029-10-08) Gate Conflates Readiness with Efficacy—Retroactive Credibility Loss if Incursion Occurs

The Year 3 gate (Month 36 = 2029-10-08) measures 'Protocol Readiness' (15 countries with binding rules, 500 inspectors, 2 suspect detections), not proven containment efficacy. If SALB incurs in Asia/Africa at Months 48–60 (2030-10-08 to 2031-10-08) despite gate passage, funders will retroactively perceive the gate as failed and withdraw 50–70% of capital. The plan acknowledges this risk but does not separate the gate logically or financially from outbreak response. Result: credibility loss, mid-program funder panic, and loss of USD 2–5B in contingency buffer to emergency response.

### 6.4.B Tags

- gate-credibility-gap
- outcome-vs-infrastructure-metrics
- funder-exit-risk
- retroactive-invalidation
- readiness-not-efficacy

### 6.4.C Mitigation

Separate 'Protocol Readiness Verification' (Month 36 = 2029-10-08 gate, infrastructure KPIs) from 'Containment Efficacy Review' (Months 72–84 = 2032-10-08 to 2033-10-08, field outcomes: ≥50 suspect detections logged). Establish independent USD 500M–USD 1B Outbreak Response Reserve by Month 3 (2027-01-08), deployable within 4–6 weeks if SALB is confirmed in free regions, decoupled from gate logic. If incursion occurs Months 48–60 (2030-10-08 to 2031-10-08), reserve funds response without retroactively damaging Year 3 gate credibility. Publish evidence 60 days before gate decision; explicitly frame Month 36 (2029-10-08) gate as 'infrastructure readiness,' not 'pathogen prevention proven.'

### 6.4.D Consequence

Without separation, a single incursion Months 48–60 (2030-10-08 to 2031-10-08) erodes funder confidence in gate discipline, triggering voluntary withdrawal of USD 1.5–3B in discretionary tranches (40–50% of remaining capital). Program loses political momentum, producer-country engagement declines, and remaining funders demand alternative financing mechanisms or exit. Containment and breeding timelines slip 18–36 months as capital reallocates to emergency outbreak response, forfeiting cultivar and hub readiness milestones.

### 6.4.E Root Cause

The plan's Phase 1 gate (Month 36 = 2029-10-08) is framed as a 'readiness checkpoint' yet interpreted by stakeholders as proof of efficacy. Biological systems do not guarantee outcomes by a specified date, yet the gate's language ('verified containment') invites the false inference that passage proves the pathogen is contained. No separate funding reserve exists for high-consequence events, so an incursion is treated as gate failure rather than as an external shock absorbed by reserves. Funder psychology: multi-year programs depend on perceived progress; a single incursion retroactively invalidates progress perceived at the gate.

## 6.5.A Issue - Resistance Breeding Durability Risk Unmitigated—Single-Gene Release and Pathogen Evolution Underspecified

The plan requires ≥3 independent resistance genes per cultivar and Virulence Gates at Months 24, 36, 48, 60 (2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08), but does not enforce these as binding sub-criteria that prevent cultivar advancement. Historical SALB resistance failures (1970s–1990s Brazil) were single-gene deployments that broke down within 5–10 years. Without continuous pathogen-virulence tracking and mandatory challenge testing, the plan risks releasing cultivars that appear durable at Year 7 but fail by Year 12–15, requiring USD 400–800M re-breeding cycles. No dedicated pathogen genomics laboratory is funded until Month 2 (2026-12-08), creating a 2-month launch gap.

### 6.5.B Tags

- resistance-durability-gap
- single-gene-time-bomb
- pathogen-virulence-tracking-absent
- cultivar-release-no-virulence-gate
- re-breeding-contingency-gap

### 6.5.C Mitigation

Fund Pathogen Genomics Lab (Brazil) by Month 2 (2026-12-08) and Asian satellite by Month 9 (2027-07-08), sequencing ≥100–150 SALB isolates annually. Enforce mandatory Virulence Gates at Months 24, 36, 48, 60 (2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08) as binding sub-criteria: candidates must resist ≥10 contemporary isolates at ≥80% efficacy or be held from advancement. Mandate ≥3 functionally independent resistance genes per cultivar, confirmed by molecular markers and pathogen segregation testing. Bar single-R-gene cultivars from release entirely. Publish annual Pathogen Population Reports (Months 12, 24, 36 = 2027-10-08, 2028-10-08, 2029-10-08, etc.) forecasting virulence evolution and informing cultivar selection.

### 6.5.D Consequence

Without virulence-gate enforcement, 30–50% probability of resistance breakdown by Year 12–15 (historical precedent). A single-gene cultivar released at Year 7 fails operationally by Year 13–16, forcing expensive re-breeding (USD 400–800M over 5–8 years) and recovering only in Year 20–23. This forfeits the program's core resilience claim: resistant Hevea becomes unreliable as an alternative to SALB risk, and OEMs and funders lose confidence in the cultivar pillar. Smallholder adopters of failed cultivars lose income during re-breeding delay, triggering reversion to susceptible clones and undermining surveillance adoption.

### 6.5.E Root Cause

The plan specifies multi-gene pyramiding as a 'decision' (Resistance Breeding Strategy) but does not link it to gate-passage criteria as an enforcement mechanism. Virulence Gates are mentioned as 'sub-criteria' but not explicitly made binding; a breeding team facing a delayed candidate could rationalize release on partial evidence. Pathogen Genomics Lab is mentioned as needed but not funded until Month 2 (2026-12-08) and not co-located with trial sites, creating coordination delays. The plan conflates 'resistant to laboratory test strains' (field-trial result at Year 5–7) with 'resistant to the full pathogen population's virulence diversity' (requires continuous genomic tracking). Without continuous virulence surveillance integrated into breeding decisions, the plan defaults to historical single-gene paradigms.

## 6.6.A Issue - Smallholder Adoption and Surveillance Participation at 20–40% Default Risk—Incentive Misalignment Unresolved

Smallholder adoption of replant finance and surveillance participation are design requirements (1.5–1.8 million adopters by Month 144 = 2038-10-08), yet the plan lacks outcome-based incentives aligned with farmer self-interest. Typical adoption rates for smallholder credit and disease reporting are 20–40% without aligned incentives; farmers conceal infections if reporting triggers quarantine and income loss. No surveillance-premium pilot is budgeted, and premium structure is underspecified (amount, payment speed, eligibility conditions). Without credible, rapid (30-day) payment for disease reports, surveillance sensitivity in smallholder zones drops 60–80%, leaving SALB incursions undetected until advanced establishment, costing USD 1–3B additional outbreak response.

### 6.6.B Tags

- smallholder-adoption-gap
- surveillance-participation-weak
- incentive-misalignment
- conceal-infection-risk
- detection-sensitivity-loss

### 6.6.C Mitigation

Design outcome-based surveillance premiums (USD 50–100 per verified disease report, USD 25–50 for negative suspects, USD 20–30/hectare for clean-plant maintenance) integrated into replant-finance eligibility by Month 3 (2027-01-08). Pilot in 3–5 representative zones (Sumatra, Côte d'Ivoire, northeast India, Rondônia, optional fifth) at Months 6–24 (2027-04-08 to 2028-10-08), enrolling 500–1,000 farmers per zone, targeting ≥60% participation and 30-day payment velocity. Embed clean-plant network access into premium eligibility, so surveillance participation becomes income-generating rather than compliance-burden. Budget pilot cost USD 10–25M and scale to USD 50M/yr (USD 1.25B over 25 years, within smallholder pillar).

### 6.6.D Consequence

Without aligned surveillance incentives, participation remains 20–40%, leaving 60–80% of smallholder zones poorly covered. An incursion in a low-surveillance area goes undetected for 6–18 months until symptomatic spread is advanced, doubling outbreak-response cost to USD 2–5B and exhausting contingency reserves. Smallholder adopters of new cultivars lose confidence if disease spread is undetected near them, triggering reversion to susceptible clones. Funder investment in clean-plant networks and replant finance is underutilized if only 20–40% of eligible farmers participate, wasting USD 600M–USD 900M in allocation intended for 50–60% uptake.

### 6.6.E Root Cause

The plan treats smallholder participation as a 'design principle' but does not fund the incentive structures that convert principles into behavior change. Replant-finance terms (7–10 year loans, 3–4% interest) improve farmer cash flow but do not reward surveillance participation. Surveillance is framed as 'disease reporting' (implying compliance) rather than 'early-detection marketing' (implying income opportunity). No pilot is specified to test premium levels and payment speed before scale-up, leaving the program vulnerable to adoption shortfalls. The plan assumes that clean-plant access and income bridge alone motivate reporting, ignoring historical evidence that farmers conceal disease if reporting triggers quarantine and income loss.

---

# 7 Expert: Multilateral Secretariat Governance and Funder Coordination Lead

**Knowledge**: Multilateral development-bank governance, donor coordination in long-term programs, institutional durability across political cycles and funder turnover, decision-making authority and delegation frameworks, transparency and accountability mechanisms, multi-stakeholder boards (producer governments, private sector, development lenders, technical experts)

**Why**: Decision 4 (Program Governance and Decision Rights) and the funding-stability threat (canonical fact: annual shortfall exposure USD 120-360M/yr; MDB debt service of USD 449M/yr is an open decision; 25-year horizon spans multiple election cycles and funder budget pressures) require a governance structure that is both decisive and resilient to political change. This expert advises on establishing an independent secretariat charter, securing binding multi-year commitments by Month 3 (2027-01-08), and designing a Technical Gate Charter that makes gate decisions credible and binding despite funder turnover.

**What**: Draft and negotiate the binding Technical Gate Charter by Month 3 (2027-01-08) specifying gate KPIs, partial-release rules, appeal mechanisms and Technical Panel independence. Establish the secretariat's legal status, board composition (6-8 producer governments, 3-4 OEMs, 3-4 MDBs, 3-4 technical experts, no faction a majority), and decision rules for capital release and strategy change. Design the communication and stakeholder-engagement cadence (annual reports, 60-day pre-gate evidence publication, 30-day challenge period) to maintain legitimacy and reduce mid-program funder exit risk from political turnover.

**Skills**: Multilateral-institution design and charter-drafting, donor coordination and alignment, governance de-risking, board dynamics and conflict management, transparency and public reporting mechanisms, institutional continuity across leadership transitions, funder commitment leverage

**Search**: multilateral development bank governance, donor coordination mechanisms, stage-gate institutional design, public-private partnership governance, long-term program continuity, institutional resilience framework

## 7.1 Primary Actions

- By Month 1 (2026-11-08), establish the binary contingency-reserve architecture: separate the Month 36 (2029-10-08) 'Protocol Readiness Verification' gate (infrastructure metrics) from the deferred 'Containment Efficacy Review' (Months 72–84 = 2032-10-08 to 2033-10-08, field outcomes); fund a dedicated Outbreak Response Reserve (USD 500M–1B, independent of gate logic) deployable within 4–6 weeks of confirmed SALB incursion in free regions.
- By Month 2 (2026-12-08), commission the Brazil-based Pathogen Genomics Lab with annual virulence tracking of ≥100–150 SALB isolates; establish satellite facility in Asia by Month 9 (2027-07-08); enforce mandatory Virulence Gates at Months 24, 36, 48, 60 (2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08) as binding sub-criteria for cultivar advancement; bar single-R-gene cultivars from release.
- By Month 3 (2027-01-08), design and fund outcome-based surveillance premiums (USD 50–100 per verified disease report, paid within 30 days) embedded in smallholder replanting finance; pilot in 3–5 zones (Months 6–24 = 2027-04-08 to 2028-10-08) targeting ≥60% farmer participation; scale to 2 million farmers by Month 120 (2036-10-08).
- By Month 3 (2027-01-08), establish the independent Technical Panel (7–9 conflict-free members including Hevea breeder, plant pathologist, IPPC expert, economist) and publish the binding Technical Gate Charter signed by all funders, producers and OEMs; define Month 36, 84, 144, 216 (2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08) gate criteria, thresholds, KPI attainment rules and adaptive-tranche release percentages.
- By Month 3 (2027-01-08), secure binding multi-year funding commitments from 5–8 sovereign governments and ≥2 multilateral development banks (no single funder >25% of USD 7.5B); specify annual tranches, gate-release schedules and political-turnover clauses binding successor administrations.
- By Month 6 (2027-04-08), complete Nagoya Protocol access-and-benefit-sharing negotiations with Brazil (≥6 signed state/community agreements); approve collection site permits; establish Brazilian Germplasm Bank (CEPLAC or Embrapa) with containment greenhouse, diagnostic laboratory and cold storage by Month 12 (2027-10-08).
- By Month 12 (2027-10-08), procure and construct ≥4 high-containment SALB trial stations (≥2 endemic Latin America with live pathogen; ≥1 Asia, ≥1 Africa, clean-zone only); establish digital phytosanitary reporting platform; train 100–200 inspectors.
- By Month 18 (2028-04-08), deliver ≥200 characterized wild Hevea accessions to breeding consortiums with passport data and legal ABS compliance; secure 2–3 OEM take-or-pay letters of intent (500–2,000 t/yr each); designate flagship product (specialty guayule latex or co-branded tire); submit formal IPPC protocol proposal to IPPC Secretariat.

## 7.2 Secondary Actions

- By Month 6 (2027-04-08), form OEM buyer consortium (5–8 major tyre manufacturers); commission co-funded tire-grade qualification testing (Months 12–30 = 2027-10-08 to 2029-04-08) for Guayule and Russian dandelion.
- By Month 12 (2027-10-08), map national phytosanitary legal gaps in all 15+ target producing countries; draft model legislation for protocol adoption; initiate bilateral engagement with plant protection organizations; resolve open decisions on MDB repayment (who services USD 7.0B lending, debt-service timing) and replant-loan capital source.
- By Month 18 (2028-04-08), pilot the ASEAN industry levy in Southeast Asia (target USD 40M/yr collection); achieve ≥80% compliance threshold; design fallback cascade (higher bank-loan ratios, outcome-linked bonds, climate-finance blend) if compliance <60%.
- By Month 24 (2028-10-08), secure binding commitment letters from ≥15 producing countries pledging to embed SALB Containment Protocol into national phytosanitary law within 12 months of IPPC approval; establish Tier 2 regional compacts (Asia 8–10 countries, Africa 4–6) with reciprocal inspection rights and shared quarantine facilities.
- By Month 30 (2029-04-08), complete OEM tire-grade qualification testing; update cost-parity assumptions for Guayule and Russian dandelion; assess hub-financing split (program 50% vs. offtake-backed debt 50%); stress-test hub bankability at USD 1.47–1.62/kg opex range.
- By Month 36 (2029-10-08), finalize Month 36 (2029-10-08) gate evidence package (15 countries, 500 inspectors, ≥2 suspect detections, regional minimums met); publish gate decision and adaptive-tranche release percentages (70–100% of USD 4.5B based on KPI attainment); reallocate contingency if needed; confirm no commercial hub construction approval before Month 84 (2033-10-08).
- By Month 60 (2031-10-08), checkpoint on alternative-rubber offtake: if committed volume <80% of planned capacity, defer hub construction to Months 96–120 (2034-10-08 to 2036-10-08); confirm cultivar-readiness trajectory and Virulence Gate evidence for Year 7 gate (Month 84 = 2033-10-08).
- By Month 72 (2032-10-08), initiate Containment Efficacy Review (Months 72–84 = 2032-10-08 to 2033-10-08) assessing ≥50 documented suspect detections; escalate surveillance sensitivity if <20 suspects logged; model incursion scenarios and outbreak-response execution to demonstrate funder confidence in risk mitigation.

## 7.3 Follow Up Consultation

Next consultation (Month 3–4 = 2027-01-08 to 2027-02-08) should address: (1) Technical Gate Charter finalization and Technical Panel member recruitment; (2) Sovereign and MDB commitment negotiations (who are primary signatories?); (3) Nagoya/ABS negotiation status and germplasm-bank readiness; (4) Trial-station siting and containment-facility procurement timelines; (5) Surveillance-premium pilot zone selection and payment infrastructure; (6) Levee pilot compliance trajectory and fallback trigger assessment by Month 18 (2028-04-08); (7) OEM engagement status and flagship-product market research; (8) Funder risk-tolerance and gate-failure contingency appetite. Quantitative focus: reduce the USD 2.4–6.3B combined-stress gap against the USD 4.5B pool; confirm assumptions on levy compliance (>80%), smallholder participation (>60%), and breeding timeline slippage risk.

## 7.4.A Issue - Year 3 gate conflates institutional readiness with containment efficacy, creating retroactive credibility loss if incursion occurs before Year 7

The Month 36 (2029-10-08) gate measures protocol adoption (15 countries, 500 inspectors, 2 detections logged), not proven pathogen prevention. If SALB incursion occurs Months 48–60 (2030-10-08 to 2031-10-08) despite gate passage, the gate's credibility is retroactively invalidated: funders interpret the gate as 'containment is working,' not 'infrastructure is ready.' Historical development programs show 40–50% funder withdrawal mid-program after such gate failures. Separation is needed: readiness gate (Year 3) and deferred efficacy review (Years 6–7, field outcomes).

### 7.4.B Tags

- gate_logic_gap
- funder_confidence_risk
- retroactive_invalidation
- binary_outcome_ambiguity

### 7.4.C Mitigation

Reframe Month 36 (2029-10-08) gate as 'Protocol Readiness Verification' (infrastructure only: 15 countries with binding rules, 500 audited inspectors, 2 suspect detections—threshold for vigilance, not proof). Defer 'Containment Efficacy Review' to Months 72–84 (2032-10-08 to 2033-10-08), assessing whether surveillance detected ≥50 suspects by Month 84 (2033-10-08). Establish independent USD 500M–1B Outbreak Response Reserve by Month 3 (2027-01-08), deployable within 4–6 weeks of confirmed incursion, decoupled from gate logic. Incursion at Month 48–60 (2030-10-08 to 2031-10-08) triggers reserve without retroactively damaging Year 3 gate.

### 7.4.D Consequence

Without separation: incursion at Years 4–5 retroactively invalidates gate as 'proof of failure,' causing 50–80% funder withdrawal mid-program. Program's 25-year institutional durability is forfeit. With separation: Year 3 gate credibility survives biological uncertainty; outbreak response is pre-funded and swift, preserving funder confidence. Risk reduction: ~40–60% decrease in mid-program funder exit probability.

### 7.4.E Root Cause

The plan treats the Month 36 (2029-10-08) gate as a binary proof of efficacy when it measures institutional deployment. Biological timelines (pathogen incursion probability) and bureaucratic timelines (protocol adoption) are decoupled; the gate conflates both. Insurance-style value proposition (benefits materialize only if outbreak occurs) weakens the gate's signaling power unless separated from efficacy.

## 7.5.A Issue - Resistance breeding lacks virulence-tracking enforcement; single-R-gene cultivars risk failure by Year 12–15, requiring USD 400–800M re-breeding and supply-chain collapse

The plan specifies at least 3 resistance genes from 2 sources, but enforcement mechanism is absent. No mandatory Virulence Gates prevent release of cultivars carrying unvalidated resistance. Historical Hevea failures (IAC series, 1970s–1990s) were single-R-gene deployments that broke down 5–10 years post-release when pathogen virulence evolved. Probability of single-gene breakdown by Year 12–15: 30–50% (estimated from fungal-pathogen literature). This triggers catastrophic re-breeding (USD 400–800M, 5–8 year delay) and forfeits supply-chain resilience claims. Pathogen genomics lab is underfunded and sub-criteria for gates are missing.

### 7.5.B Tags

- resistance_durability_gap
- single_gene_risk
- enforcement_absence
- pathogen_tracking_underfunded

### 7.5.C Mitigation

Establish Pathogen Genomics Lab (Brazil by Month 2 = 2026-12-08, Asia by Month 9 = 2027-07-08, 2027-07-08) with annual virulence tracking of ≥100–150 SALB isolates. Mandate Virulence Gates at Months 24, 36, 48, 60 (2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08) as binding sub-criteria: test top ≥3 candidates against ≥10 contemporary isolates; pass = resistant to ≥80% of isolates; fail = hold candidate, extend pyramiding, re-test in 6 months. Bar single-R-gene cultivars from release. Cost: USD 25–50M over 25 years (<1% of breeding budget). Reduces resistance-breakdown probability to ≤10% by Year 15.

### 7.5.D Consequence

Without virulence enforcement: 30–50% probability of cultivar failure by Year 12–15, triggering USD 400–800M re-breeding, 5–8 year supply delay, and 50–70% loss of program credibility. With enforcement: resistance durability modeled and validated; breakdown risk <10%. Funders retain confidence in breeding pillar.

### 7.5.E Root Cause

Plan mentions pyramiding requirement but lacks operational gatekeeping. Pathogen-side monitoring (virulence tracking) is treated as optional; it should be mandatory. Breeding timelines are compressed into binary Year 7, 12 gates without intermediate virulence checkpoints. Separation of host-side resistance testing (field trials) from pathogen-side validation (genomics) leaves a critical evidence gap.

## 7.6.A Issue - Smallholder adoption contingent on fragile incentive alignment; surveillance participation <30% without outcome premiums, leaving incursions undetected until advanced stage, costing USD 1–3B in outbreak response

The plan targets 1.5 million smallholder adopters (50% of 3 million eligible) by Month 144 (2038-10-08), critical for supply-chain resilience. But adoption depends on farmers reporting disease despite risk of quarantine and income loss—a disincentive structure. Typical smallholder surveillance participation is 20–40% without aligned financial incentives. Undetected incursion in smallholder zones (80% of Asian production) escalates from early-stage (1,000–5,000 hectares, USD 200–500M response) to advanced establishment (100,000+ hectares, USD 1–3B response). Plan mentions surveillance premiums but does not specify payment amounts, frequency, or pilot validation. Without proof-of-concept, the incentive mechanism is speculative.

### 7.6.B Tags

- incentive_misalignment
- smallholder_adoption_risk
- surveillance_sensitivity_gap
- unproven_premium_mechanism

### 7.6.C Mitigation

Design outcome-based surveillance premiums by Month 3 (2027-01-08): USD 50–100 per verified disease report, paid within 30 days, non-punitive (reporting does not trigger quarantine against reporter). Embed clean-plant-network access into premium eligibility: farms maintaining ≥90% clean-plant status (verified quarterly) retain access to subsidized material and refinanced credit. Pilot in 3–5 representative zones (Sumatra, Côte d'Ivoire, northeast India, Rondônia, optional fifth) during Months 6–24 (2027-04-08 to 2028-10-08) with 500–1,000 farmers per zone, targeting ≥60% participation. Scale to 2 million farmers by Month 120 (2036-10-08) if pilot succeeds. Cost: USD 10–25M pilot; USD 15–20B scaled (within 50% of USD 4.5B smallholder pillar).

### 7.6.D Consequence

Without outcome premiums: surveillance participation 20–40%, incursion undetected until 100,000+ hectares, response cost USD 1–3B. With premiums: participation ≥60%, early detection <10,000 hectares, response cost USD 200–500M (80% savings). Incursion at Month 60–84 (2031-10-08 to 2033-10-08) becomes manageable; without premiums, catastrophic to program budget.

### 7.6.E Root Cause

Plan emphasizes smallholder 'participation' and 'adoption' as design principles but treats incentive mechanics as implementation detail. Surveillance premium structure (amounts, frequency, penalty vs. reward framing) directly determines detection speed and outbreak cost. The gap between conceptual importance and operational specification is the root cause.

---

# 8 Expert: Contingency-Reserve Architecture and Financial Stress-Testing Expert

**Knowledge**: Catastrophic-risk quantification and reserve-sizing, outbreak-response playbooks, combined-stress scenarios, capital-flow resilience under biological uncertainty, development-program attrition and mid-program funder-exit modeling, parametric insurance and outcome-linked instruments, fallback funding cascades

**Why**: The canonical fact 'combined_stress_vs_contingency_pool' reveals a structural gap: simultaneous full outbreak (USD 1.5-4.5B residual), resistance-breeding re-cycle (USD 0.4-0.8B), and alternative-rubber remediation (USD 0.5-1.0B) claims total USD 2.4-6.3B against a USD 4.5B contingency pool, leaving a shortfall of up to USD 1.8B. This expert advises on separating the outbreak reserve (USD 0.5-1.0B, independent of gates) from the contingency pool and designing fallback cascades (higher bank loan-to-grant ratios, outcome-linked bonds, climate-finance blending) if the levy underperforms or multiple shocks compound.

**What**: Establish the three-layer reserve architecture (USD 0.5-1.0B outbreak reserve, USD 4.5B contingency pool, USD 0.9B political-risk reserve, total USD 5.9B inside the USD 30B cap) by Month 3 (2027-01-08) with independent governance and deployment rules. Model combined-stress scenarios (outbreak + breeding delay + hub cost overage) to identify the USD 1.8B shortfall gap and pre-position fallback triggers (levy compliance below 60% by Month 48 = 2030-10-08 activates higher bank lending; outbreak at Months 48-60 = 2030-10-08 to 2031-10-08 draws from outbreak reserve without gate disruption). Design outcome-linked and parametric instruments (catastrophe bonds, results-based financing) to expand capital sources if primary funding (levy, grants, MDB loans) underperforms.

**Skills**: Catastrophic risk quantification, reserve-sizing for stochastic biological timelines, parametric and outcome-linked instrument design, financial-stress-test modeling, fallback-cascade logic and trigger-point definition, development-program attrition analysis, climate-risk blending and insurance structures

**Search**: catastrophic risk reserves, agricultural program contingency sizing, outcome-linked financing, parametric insurance natural disasters, development program financial resilience, stress-test modeling agriculture

## 8.1 Primary Actions

- Execute binding contingency-reserve architecture by Month 1 (2026-11-08): separate Month 36 (2029-10-08) 'Protocol Readiness' gate (infrastructure metrics: ≥15 countries, ≥500 inspectors, ≥2 lab detections) from deferred Containment Efficacy Review (Months 72–84 = 2032-10-08 to 2033-10-08, detection-volume proxy: ≥50 documented suspect detections). Establish independent Outbreak Response Reserve ($500M–$1B escrow, funded by Month 3 = 2027-01-08), deployable for confirmed SALB incursions independent of gate logic, preventing retroactive gate-credibility damage.
- Establish Pathogen Genomics Laboratory (Brazil, Month 2 = 2026-12-08) and Asian satellite (Month 9 = 2027-07-08) with binding Virulence Gates (Months 24, 36, 48, 60 = 2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08) embedded in Technical Gate Charter by Month 3 (2027-01-08). Mandate ≥3 independent resistance genes per released cultivar, ≥2 geographic sources, pass ≥80% challenge against ≥10 contemporary SALB isolates. Bar all single-R-gene cultivars from release. This enforces durability architecture as binding gate sub-criterion, not guidance.
- Design and pilot outcome-based surveillance premiums ($50–100 per verified report) by Month 3 (2027-01-08), with 30-day payment and clean-plant-network linkage. Deploy pilot in 3–5 zones (Sumatra, Côte d'Ivoire, northeast India, Rondônia, +1) Months 6–24 (2027-04-08 to 2028-10-08), targeting ≥60% participation (500–1,000 farmers per zone, 1,500–5,000 total). If pilot reaches ≥60% by Month 18 (2028-04-08), commit to scale to 2–3 million farmers by Month 120 (2036-10-08).
- Secure binding multi-year funding commitments from ≥5 sovereigns and ≥2 multilateral development banks by Month 3 (2027-01-08), with no single funder >25% of capital (USD 7.5B threshold). Commit to binding Technical Gate Charter (signed by all funders and producer governments) specifying gate KPIs, Technical Panel composition, evidence publication, and appeal procedures, making gate decisions credible and reversible only via formal amendment.
- Commission all four high-containment trial stations by Month 12 (2027-10-08): ≥2 live-pathogen stations in endemic Latin America (Rondônia, Peru); ≥1 clean-zone station in Asia; ≥1 in Africa. Budget: USD 3–5M per station (USD 12–20M total). Each station must include pathogen laboratory, screening greenhouse, open-field trial blocks with containment, and quarantine facilities. This provides the biosafety infrastructure to support Virulence Gates and field trials without delay.

## 8.2 Secondary Actions

- Complete Nagoya Protocol and ABS agreements with Brazilian authorities and ≥5 indigenous/traditional community organizations by Month 6 (2027-04-08), pre-clearing ≥200 wild Hevea collection sites with 2–3 annual campaigns per site. Establish Brazilian Germplasm Bank by Month 12 (2027-10-08), delivering ≥200 characterized wild accessions to breeding consortiums by Month 18 (2028-04-08), supported by contingency of 50–80 historical CEPLAC/Embrapa accessions if field collection slips >20%.
- Convene OEM buyer consortium (5–8 major tyre makers) by Month 6 (2027-04-08) and secure 2–3 take-or-pay letters of intent (500–2,000 t/yr each per OEM) by Month 18 (2028-04-08). Establish co-funded tire-grade qualification testing (OEM + program cost-share, Months 12–30 = 2027-10-08 to 2029-04-08). If take-or-pay commitment is <80% of planned volume by Month 60 (2031-10-08), defer hub construction to Months 96–120 (2034-10-08 to 2036-10-08) and reset Year 12 volume targets.
- Establish Technical Gate Charter and independent Technical Panel (7–9 members, conflict-free) by Month 3 (2027-01-08). Publish binding Year 3, 7, 12, 18 gate KPIs with numeric thresholds and evidence standards. Mandate 60-day pre-gate publication of all evidence (raw data, analyses, virulence results, cost-parity claims), 30-day public challenge period, and 30-day Technical Panel response to appeals. This transparency reduces post-hoc contestation and funder exit risk.
- Model combined-stress scenarios (simultaneous full outbreak + re-breeding + alternative-rubber cost slip) against USD 4.5B contingency pool by Month 12 (2027-10-08). Identify residual gap (estimated USD 1.8B, high-end scenario: USD 2.4–6.3B stress claims vs. USD 4.5B pool). Pre-negotiate fallback funding sources (e.g., climate-finance blend, outcome-linked bond issuance pathway) to fill gap if triggered. Document decision rules for activating fallback.
- Pilot ASEAN industry levy collection (about USD 40M/yr from ASEAN region, ~USD 0.15–0.25 per tonne traded) by Month 18 (2028-04-08). If compliance exceeds 80%, proceed to global rollout by Month 36 (2029-10-08). If compliance <60%, activate fallback cascade (higher bank loan-to-grant ratio, outcome-linked bonds, climate-finance) by Month 48 (2030-10-08). This reduces funding shortfall exposure and tests cartel-like coordination feasibility.
- Establish mobile disease-reporting platform (SMS, offline-capable apps, GPS-embedded) and diagnostic sample-kit logistics by Month 6 (2027-04-08), ready for pilot deployment at Month 6 (2027-04-08). Ensure 7–14 day sample turnaround and 30-day payment to farmers via mobile transfer. Test platform with 100–200 farmers in one pilot zone (Month 8 = 2027-06-08), scaling to full pilot (1,500–5,000 farmers) by Month 12 (2027-10-08).

## 8.3 Follow Up Consultation


At Month 12 (2027-10-08), convene a 2-day Contingency and Risk Review: (1) Report on Pathogen Lab commissioning, Virulence Gate design, and first annual isolate-sequencing results (to inform breeding candidate selection by Month 18 = 2028-04-08). (2) Present smallholder pilot participation rates, average farmer premium earnings, and 30-day payment performance; if <50% participation, propose payment-rate increase or alternative incentive structure. (3) Review Outbreak Response Reserve deployment scenarios and pre-authorized response protocols; validate time-to-deployment (target 4–6 weeks) and coordination with national plant protection organizations. (4) Assess funding-commitment letters and binding Charter signatures from funders/producers; if gaps exist, identify blockers and remediation timeline. (5) Evaluate ASEAN levy pilot compliance rates; if >80%, confirm global rollout timeline (Month 36 = 2029-10-08). (6) Commission combined-stress modeling and fallback-funding sources. At Month 18 (2028-04-08), hold Redesign Gate: assess whether germplasm, OEM offtake, surveillance premiums, and funding have achieved critical milestones (≥200 accessions, ≥2 OEM intent letters, ≥60% pilot participation, binding commitments signed). If any pillar is significantly behind, propose re-sequencing (e.g., defer hub site selection, extend germplasm collection, redesign premium structure) rather than proceeding with Year 3 gate unchanged. At Month 36 (2029-10-08), hold the Month 36 (2029-10-08) Protocol Readiness Gate according to the binary architecture: pass/fail on ≥15 countries, ≥500 inspectors, ≥2 lab detections, minimum regional footprints. Do not interpret gate as proof of containment; frame as infrastructure readiness. Simultaneously, activate the Containment Efficacy Review countdown (Months 72–84 = 2032-10-08 to 2033-10-08) and affirm that Outbreak Response Reserve (now tested) is available for deployment. These consultations maintain funder confidence through biological uncertainty and enable program redesign if frontline pilots signal emerging gaps.

## 8.4.A Issue - Year 3 gate conflates readiness with efficacy, creating retroactive credibility collapse if incursion occurs Months 48–60 (2030-10-08 to 2031-10-08)

The Month 36 (2029-10-08) 'Protocol Readiness' gate measures infrastructure deployment (15 countries, 500 inspectors, 2 lab detections), not proven containment. If SALB incursions occur Months 48–60 (2030-10-08 to 2031-10-08) despite gate passage, funders will retroactively interpret gate failure as program failure, triggering 50–80% funder withdrawal. This logic gap undermines the entire 25-year commitment structure. The current design holds no independent outbreak reserve, so response funding must compete with tranches, forcing gate revision mid-crisis.

### 8.4.B Tags

- gate-credibility
- outcome-liability
- funding-collapse-risk
- reserve-architecture

### 8.4.C Mitigation

Immediately (by Month 1 = 2026-11-08): establish binary contingency-reserve architecture separating 'Protocol Readiness Verification' (Month 36 = 2029-10-08 gate, infrastructure metrics) from deferred 'Containment Efficacy Review' (Months 72–84 = 2032-10-08 to 2033-10-08, field outcomes). Fund independent Outbreak Response Reserve ($500M–$1B, in escrow by Month 3 = 2027-01-08) deployable within 4–6 weeks of confirmed incursion, decoupled from gate logic. Efficacy review assesses whether ≥50 documented suspect detections were logged (detection sensitivity proxy), not zero incursions (impossible standard). This preserves gate credibility through biological uncertainty.

### 8.4.D Consequence

Without separation: if incursion occurs Months 48–60 (2030-10-08 to 2031-10-08) despite Year 3 gate passage, 50–70% of funders withdraw (based on comparable 20–25 year development-program attrition), cascading to funder exit, smallholder-credit freeze, and inability to fund Year 7/12 tranches. Combined with resistance-breeding delays, program faces 18–24 month halt. Residual outbreak costs ($2–5B estimate) exhaust USD 4.5B contingency pool immediately, forcing program termination or USD 2–3B emergency re-financing at penalty rates.

### 8.4.E Root Cause

Year 3 gate is framed as 'containment efficacy' when it only measures readiness. No separate contingency mechanism exists for high-consequence outbreak response independent of gate logic. Efficacy cannot be proven in 36 months under containment protocols (detection lag is inherently uncertain); measuring it creates impossible standard.

## 8.5.A Issue - Resistance breeding lacks binding virulence gates; single-gene cultivars face 30–50% breakdown probability by Year 12–15

The plan calls for pyramided resistance (≥3 genes, ≥2 sources) but contains no enforcement mechanism. Virulence Gates are mentioned in the pre-assessment but are not binding sub-criteria in the actual Year 7 and Year 12 gate KPIs. Pathogen genomics lab is mandated for Month 2 (2026-12-08), yet no institutional tie-in exists to gate logic. Historical SALB failures (IAC series, 1970s–90s) were single-R-gene releases that failed when virulence shifted. Without mandatory pathogen tracking and virulence-challenge data informing gate decisions, 30–50% probability that released cultivar carries time-bomb resistance that breaks down Year 10–15, requiring USD 0.4–0.8B re-breeding and 5–8 year delay.

### 8.5.B Tags

- resistance-durability
- virulence-tracking-gap
- breeding-gate-weakness
- time-bomb-risk

### 8.5.C Mitigation

By Month 12 (2027-10-08): establish Brazil Pathogen Genomics Lab and Asian satellite (Month 9 = 2027-07-08); mandate annual virulence characterization of ≥100–150 SALB isolates per facility. Enforce binding Virulence Gates at Months 24, 36, 48, 60 (2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08) as non-negotiable sub-criteria in Technical Gate Charter: candidates must pass challenge against ≥10 contemporary isolates (≥80% incompatible phenotype) before field advancement. Bar all single-R-gene cultivars from release regardless of field yield. Require ≥3 independent resistance sources per released cultivar, validated by molecular markers. This raises time-to-breakdown to 20–30+ years.

### 8.5.D Consequence

Without virulence-gate enforcement: cultivar released at Year 7 (Month 84 = 2033-10-08) appears resistant in 2-year trials but carries pre-existing virulent biotypes in pathogen population. Breakdown occurs Year 10–15, requiring emergency re-breeding cycle of 5–8 years and USD 0.4–0.8B capital. Supply-chain resilience claims collapse; SALB penetration during re-breeding period costs USD 1–3B additional containment. Funder confidence in breeding program evaporates; 40–60% probability of breeding-phase defunding at Year 12 gate, stranding USD 2–3B in cultivar advancement.

### 8.5.E Root Cause

Virulence Gates exist as a risk-mitigation concept (pre-assessment) but are not embedded in the binding Technical Gate Charter or Year 7/12 KPI definitions. Breeding team is not contractually obligated to submit candidates to pathogen-challenge testing before advancement. Pathogen lab and breeding program lack formal decision-rights linkage.

## 8.6.A Issue - Smallholder surveillance participation unspecified; no outcome-linked incentive mechanism; 30–50% participation expected (vs. ≥60% design requirement)

The plan mandates smallholder participation in disease reporting and clean-plant networks as essential for containment verification, yet provides no concrete incentive mechanism or participation targets. Surveillance is framed as a compliance obligation (farmers must report) without offsetting income stream. Historical adoption studies show 20–40% baseline participation in phytosanitary schemes without financial incentive; the plan assumes ≥50% adoption for supply-chain resilience. Without aligned incentives, farmers face asymmetric risk: reporting SALB triggers quarantine (income loss) without compensating benefit. Result: detection sensitivity drops 60–80% in smallholder zones, leaving incursions undetected until establishment is advanced (3–6 months, vs. target detection lag of 4–8 weeks).

### 8.6.B Tags

- smallholder-incentives
- surveillance-participation-gap
- adoption-risk
- detection-sensitivity

### 8.6.C Mitigation

By Month 3 (2027-01-08): design outcome-based surveillance premium (USD 50–100 per verified disease report) integrated into smallholder replanting finance. Pilot in 3–5 representative zones (Sumatra, Côte d'Ivoire, northeast India, Rondônia, +1 other) during Months 6–24 (2027-04-08 to 2028-10-08), enrolling 500–1,000 farmers per zone, targeting ≥60% participation. Embed clean-plant-network access into premium eligibility (only farms maintaining ≥90% clean-plant status receive loans and premium access next year). Mandate 30-day payment turnaround (SMS notification + mobile transfer) to build trust. If pilot achieves ≥60% participation by Month 18 (2028-04-08), scale to 2–3 million by Month 120 (2036-10-08).

### 8.6.D Consequence

Without outcome-linked premiums and pilot validation: smallholder reporting participation remains at 20–40% baseline, leaving 60–80% of smallholder zones with no active surveillance. SALB incursion in smallholder area goes undetected for 3–6 months until visible canopy symptoms trigger large-area detection (10,000+ hectares affected). Containment costs spike to USD 1–3B (full zone quarantine, fungicide suppression, large-scale tree removal). Alternative: small early-detection sample (Month 12 = 2027-10-08 pilot shows low participation) forces program to defer smallholder engagement, shrinking effective containment zone and invalidating Year 3 gate targets of ≥500 trained inspectors and ≥15 countries. Credibility gap opens between gate numbers and real surveillance sensitivity.

### 8.6.E Root Cause

Plan specifies surveillance premium concept (pre-assessment, Month 3 = 2027-01-08 design target) but contains no binding payment structure, amounts, or deployment timeline. Replant finance and income-bridge loans are separate instruments, not linked to surveillance participation. No pilot phase to test participation rates or payment velocity before scaling to 2–3 million farmers.