# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Global Phytosanitary Policy and IPPC Standards Expert

**Knowledge**: IPPC governance, harmonized international phytosanitary standards, regional plant protection organization frameworks, trade facilitation, quarantine architecture

**Why**: The plan's Phase 1 non-negotiable deliverable—embedding the SALB Containment Protocol in the IPPC framework—depends entirely on this expert's domain. They can assess whether the proposed IPPC-harmonized route is genuinely achievable by Month 36 (2029-10-12), identify producer-nation sovereignty friction points, and validate the producer-nation MoU structure needed by Month 6 (2027-04-12).

**What**: Review the Containment Protocol Authority decision and the IPPC adoption pathway; assess realistic timelines for working-group consensus and formal adoption; identify legal gaps in the MoU template for Brazil, Indonesia, Thailand, Malaysia, Vietnam; recommend adjudication mechanisms for protocol interpretation disputes.

**Skills**: IPPC standard-setting process design, multilateral consensus-building, phytosanitary regulation harmonization, quarantine policy, experience negotiating trade-related plant protection agreements

**Search**: IPPC standards officer, phytosanitary policy harmonization, plant protection organization trade, quarantine regulation expert

## 1.1 Primary Actions

- Recruit a Protocol Adoption Secretariat at FAO/IPPC by Month 3 (2027-01-12) with 3 full-time policy coordinators; publish the IPPC-harmonized SALB Containment Protocol draft by Month 3 (2027-01-12); negotiate and sign bilateral MoUs with Brazil, Indonesia, Thailand, Malaysia, Vietnam by Month 6 (2027-04-12), each specifying national embedding by Month 36 (2029-10-12), 20+ inspectors by Month 12 (2027-10-12), and penalties for non-compliance.
- Establish a Resistance Durability Oversight Panel by Month 1 (2026-11-12) with 6 independent members (2 perennial-crop breeders, 2 plant pathologists, 1 auditor, 1 ABS specialist); publish peer-reviewed breeding KPI protocol by Month 6 (2027-04-12) specifying yield ≥90% of elite clones, ≥3 stacked resistance sources, lesion <5 mm, durability under 10× inoculum; launch 4-site field trials (Campinas, Serdang, Cote d'Ivoire, southern Thailand) by Month 12 (2027-10-12).
- Negotiate legally binding 25-year framework agreements with 5+ sovereign/MDB funders (none above 20%) and industry-levy agreements with top 10 OEMs and 5 traders by Month 12 (2027-10-12); specify minimum 80% partial-release tranches on gate success, disbursement within 45 days, force-majeure clause, and penalties for early withdrawal; establish ring-fenced USD 4.5 billion contingency reserve governed by Dispute-Resolution Panel.
- Contract an independent international auditor by Month 3 (2027-01-12); establish Dispute-Resolution Adjudication Panel (3 neutral senior figures) by Month 3 (2027-01-12); pre-register audit scope, KPI definitions, and multi-source verification methods (field 30–40%, database 40–50%, interviews 20–30%) by Month 6 (2027-04-12); guarantee auditor data access within 5 business days with 1–2% fee penalties for non-compliance.
- Hire ABS legal counsel by Month 1 (2026-11-12) with Nagoya Protocol track record; negotiate and execute ABS agreements with Brazil CGen and 3 Amazonian community groupings by Month 6 (2027-04-12), specifying benefit-sharing (USD 1–5 per ha), royalty-free seed for smallholders, open-access genomic publication; establish community-governed data trust with community representatives by Month 6 (2027-04-12).
- Establish a Smallholder Adoption Working Group by Month 1 (2026-11-12) with farmer associations and cooperatives from top 5 producers; define 3 adoption scenarios (conservative 30–40%, moderate 40–50%, optimistic 60%+) with explicit finance and extension commitments by Month 6 (2027-04-12); recruit 500 lead extension agents and deploy locally-owned (not centralized) nurseries by Month 12 (2027-10-12); establish protected USD 300–500 million 25-year income-bridging finance stream outside central program management.

## 1.2 Secondary Actions

- Convene monthly OEM Steering Committee by Month 3 (2027-01-12) with top 10 tire makers (executive-level attendance); secure non-binding Letters of Intent from 8 of 10 OEMs by Month 12 (2027-10-12) committing to 500,000-tyre/year supply-chain trials and access to tire-testing facilities; launch parallel tire-performance qualification trials at 3 independent labs by Month 12 (2027-10-12); target qualification completion by Month 48 (2030-10-12).
- Prepare crown-budding fast-track decision paper by Month 48 (2030-10-12) with USD 0.25 billion allocated; if breeding shows >15% yield penalty by this date, activate fast-track to deliver field protection before Year 7 gate and compress alternative-crop breeding risk.
- Establish anonymous mobile-phone reporting system for protocol violations and SALB suspicions by Month 6 (2027-04-12); pay smallholders EUR 10–50 per confirmed report; conduct protocol-compliance red-team drills in 3 producing countries Months 18–36 (2028-04-12 to 2029-10-12) with 95%+ detection accuracy threshold and transparent publication of results.
- Publish all ABS agreements, benefit-sharing payment records, and OEM Letters of Intent publicly by Month 12 (2027-10-12) to demonstrate transparency and build stakeholder confidence; establish quarterly compliance-reporting cadence for all producer nations and funders.
- Allocate the USD 13.9 billion unassigned balance and decide plant financing split (program versus OEM/partner/project finance) at Month 6 (2027-04-12) budget baseline; stage plant capex after pilots and Month 60 (2031-10-12) cost/quality decision; set adoption KPI waypoints at Months 36, 84, 144 (2029-10-12, 2033-10-12, 2038-10-12) with decision triggers (if adoption <30% by Month 84 = 2033-10-12, reallocate USD 0.8–1.2 billion from smallholder to estate-scale trials).
- Define incursion response doctrine (eradication-first or managed coexistence) and pre-position USD 0.5 billion compensation fund by Month 12 (2027-10-12); recruit 100 compliance inspectors (20 per top-5 producer) and establish 10+ regional laboratories by Month 24 (2028-10-12); deploy surveillance network to detect SALB within 3 months in primary producers and 6 months in secondary regions by Month 12 (2027-10-12).

## 1.3 Follow Up Consultation

In the next consultation (Month 3 = 2027-01-12 or Month 6, 2027-04-12 or 2027-04-12), discuss: (1) MoU negotiation progress and any delays in producer-nation adoption timelines; (2) Resistance Durability Panel's trial-site readiness and any ABS slip that pushes trial planting beyond Month 12 (2027-10-12); (3) framework agreement signatures and funder commitment durability (penalty enforcement mechanism acceptance); (4) auditor contract finalization and dispute-panel composition; (5) OEM engagement feedback and offtake price signals; (6) smallholder adoption scenario modeling and default-rate assumptions; (7) decision on crown-budding fast-track trigger and allocation within the unassigned USD 13.9 billion balance. Flag any Month 6 (2027-04-12) milestone misses as early warning of Phase 1 gate risk.

## 1.4.A Issue - Producer-Nation Protocol Adoption Lacks Binding Enforcement and Political Commitment Pathway

The plan embeds the SALB Containment Protocol in the IPPC framework, which is strategically sound for legitimacy but operationally risky. IPPC adoption requires consensus across 180+ member nations and typically takes 3–5 years; the plan targets Month 36 (2029-10-12). Critically, embedding in IPPC does not guarantee national adoption: nations vote to endorse standards but retain sovereignty to delay or weaken implementation. The plan has no binding MoU pathway specifying penalties for non-adoption, inspector hiring timelines, or escalation triggers. Without bilateral enforcement agreements by Month 6 (2027-04-12), the Phase 1 deliverable remains aspirational, and the Year 3 gate criteria (protocol binding in 3 of 5 top producers) becomes unverifiable.

### 1.4.B Tags

- producer_adoption_risk
- ippc_consensus_delay
- enforcement_gap
- phase1_deliverable_at_risk

### 1.4.C Mitigation

Secure binding bilateral Memoranda of Understanding with Brazil, Indonesia, Thailand, Malaysia, and Vietnam by Month 6 (2027-04-12), each MoU specifying: (i) national embedding of protocol provisions in phytosanitary law by Month 36 (2029-10-12); (ii) named responsible quarantine agency and 20+ inspectors per country by Month 12 (2027-10-12); (iii) quarterly compliance reporting tied to financial disbursement (withhold 5–10% of bilateral aid if reporting lapses); (iv) published penalty schedule for non-compliance (nursery suspension, trading bans). Establish a dedicated Protocol Adoption Secretariat at FAO/IPPC by Month 3 (2027-01-12) with 3 policy coordinators. Publish the IPPC-harmonized draft by Month 3 (2027-01-12) and circulate for working-group comment by Month 4 (2027-02-12) to front-load consensus. Use the bilateral MoUs as evidence of national will, strengthening IPPC vote odds at Month 36 (2029-10-12). If fewer than 3 of 5 top producers have binding adoption by Month 54 (2031-04-12), re-scope the Phase 1 gate and extend timelines.

### 1.4.D Consequence

Without binding MoUs by Month 6 (2027-04-12), IPPC adoption will drift to Month 48–60 (2030-10-12 to 2031-10-12) or later, delaying national embedding 12–24 months. The Year 3 gate (Month 36 = 2029-10-12) becomes uncredible: auditors cannot verify that the protocol is binding in 3 of 5 producers, and funders withhold tranches on gate failure. Surveillance and inspection capacity (100 inspectors, 100,000+ lots/year) cannot mobilize without legal mandate, leaving SALB containment voluntary and unenforceable. A single unmanaged incursion in a region with lax protocol compliance undermines the entire program's credibility and cascades funding denial across Years 3–7.

### 1.4.E Root Cause

The plan assumes IPPC embedding automatically triggers national adoption; it does not account for the IPPC's inherent consensus-building slowness or the sovereign choice to delay implementation. No bilateral enforcement pathway is defined, and no financial or reputational penalty for non-adoption exists. The Phase 1 gate criteria (binding in 3 of 5 producers by Month 36 = 2029-10-12) is aspirational without a roadmap to lock commitments before Month 12 (2027-10-12).

## 1.5.A Issue - Year 7 Cultivar-Readiness Gate Faces Zero Timeline Slack and Unregistered Success Metrics

The plan requires SALB-resistant Hevea cultivars to reach Year 7 (Month 84 = 2033-10-12) with yield parity (≥90% of elite clones) and 3 stacked resistance sources. Perennial rubber trees have 6–10 year breeding cycles with no compression; trials must be planted by Month 12 (2027-10-12) to yield first meaningful data by Month 84 (2033-10-12). Any slip in ABS negotiations (beyond Month 12 = 2027-10-12), germplasm collection, or trial establishment cascades the gate to Month 96 (2034-10-12) or later. Additionally, breeding success metrics (yield threshold, resistance durability, lesion size) are not pre-registered in a peer-reviewed protocol; Year 7 gate credibility depends on post-hoc auditor interpretation of ambiguous criteria. Without independent Resistance Durability Oversight Panel by Month 1 (2026-11-12), breeding program managers will control the narrative of 'success'.

### 1.5.B Tags

- zero_timeline_slack
- unregistered_metrics
- breeding_cycle_inflexibility
- year7_gate_credibility

### 1.5.C Mitigation

By Month 6 (2027-04-12), publish a peer-reviewed protocol document specifying breeding KPI targets: (i) yield ≥90% of elite clones (RRIM 928, PB 217) across 4 trial sites; (ii) ≥3 independent, molecularly confirmed resistance sources stacked by Month 84 (2033-10-12); (iii) lesion size <5 mm and defoliation ≤20% after inoculation at 10× field-typical spore load; (iv) durability confirmed in at least 5 replicate blocks per site. Establish a Resistance Durability Oversight Panel by Month 1 (2026-11-12) with 6 members (2 breeders, 2 pathologists, 1 auditor, 1 ABS specialist); panel meets monthly Months 1–24 (2026-11-12 to 2028-10-12), then quarterly thereafter. Panel pre-approves trial protocols, interprets durability data, and advises gate decisions; all interpretations are published. Launch 4-site field trials by Month 12 (2027-10-12) at Campinas (Brazil), Serdang (Malaysia), Cote d'Ivoire, southern Thailand. Prepare a crown-budding fast-track decision by Month 48 (2030-10-12) with USD 0.25 billion allocated; if breeding shows >15% yield penalty by Month 48 (2030-10-12), activate fast-track to deliver field protection earlier.

### 1.5.D Consequence

Without pre-registered metrics and oversight panel, Year 7 gate credibility collapses: program managers can claim 85% yield ('conditionally acceptable') while auditors flag it as failure, triggering withheld tranches and funder dispute. Ambiguous metrics also make smallholder adoption confidence fragile; if released cultivars underperform in farmers' fields by 15–20%, adoption rates plummet and the 45% uptake target is orphaned. Breeding timeline inflexibility means any ABS slip beyond Month 12 (2027-10-12) moves the gate 12 months later, compressing Phase 3 (Months 84–144 = 2033-10-12 to 2038-10-12) and delaying resistance deployment until Year 8–9, when SALB containment window may be closed.

### 1.5.E Root Cause

The plan assumes breeding success is self-evident and does not establish pre-registered, independent criteria. Perennial-crop cycles cannot be accelerated, creating rigid timeline dependency; any process slip cascades uncontrollably. The plan mentions a Resistance Durability Oversight Panel only implicitly (in secondary actions) and does not assign it authority over gate interpretation.

## 1.6.A Issue - Sovereign and Development-Bank Funding Commitments Lack Legal Binding and Are Exposed to Budget-Cycle Volatility

The plan allocates USD 25.5 billion in deployable capital across 25 years (Months 0–300) with 4 gate releases at Months 36, 84, 144, 216 (2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12). The funding mix is about 88% sovereign/MDB (26.3B) and 12% industry levy (3.7B). However, the plan does not specify legally binding 25-year framework agreements or gate-release mechanics. Sovereign budgets operate on annual cycles; development banks face competing priorities and political repriorization. If the Year 7 gate (Month 84 = 2033-10-12) shows partial success (e.g., cultivar yield at 92% instead of 95%), the 80% partial-release rule (proposed) is not contractually guaranteed. A funder can withhold tranches citing internal budget pressures, leaving cultivar deployment unfunded and smallholder replanting infrastructure stranded with USD 5–8 billion unallocated.

### 1.6.B Tags

- funding_volatility
- non_binding_commitments
- budget_cycle_risk
- gate_release_enforcement_gap

### 1.6.C Mitigation

By Month 12 (2027-10-12), negotiate and execute legally binding 25-year framework agreements with at least 5 sovereign/MDB funders (none above 20% = USD 6.0 billion), specifying: (i) committed capital tranches for Months 0–36 (2026-10-12 to 2029-10-12), 36–84, 84–144, 144–216 with minimum-funding floors (no less than 80% of planned tranche if gate is partially met with auditor sign-off); (ii) mandatory disbursement within 45 days of gate passage, not subject to annual budget cycles or repriorization; (iii) force-majeure clause (pandemic, war, natural disaster) permitting 12-month postponement but not cancellation; (iv) penalty for early withdrawal: funder forfeits 5–10% of undisbursed tranche as contribution to continuation reserve if withdrawing before Month 120 (2036-10-12) without documented external force majeure. Simultaneously, establish an industry-resilience levy agreement with top 10 tire makers and 5 rubber traders (0.75% of natural-rubber purchases = ~USD 150 million/year, estimated), collected into a ring-fenced fund outside annual government budget cycles, with 10-year minimum commitment and 2-year capital forfeiture penalty for early defection. Ring-fence the USD 4.5 billion contingency reserve separately, released only for documented external shocks, governed by the Dispute-Resolution Panel.

### 1.6.D Consequence

Without legally binding commitments by Month 12 (2027-10-12), sovereign budgets will default to annual appropriation cycles and competing priorities. A missed or partial Year 7 gate (Month 84 = 2033-10-12) could trigger funder withholding of USD 5–8 billion, compressing cultivar deployment timelines and orphaning smallholder adoption infrastructure built during Months 0–84 (2026-10-12 to 2033-10-12). Industry levy defection (if OEMs face profitability pressure) could cut program revenue by 20–40%, cascading underfunding across alternative-crop plants and extension networks. The program becomes vulnerable to the very budget-cycle volatility it was designed to protect against; credible long-horizon funding evaporates, and investment confidence in cultivar and alternative-crop development collapses.

### 1.6.E Root Cause

The plan assumes sovereign and development-bank commitments are durable without contractual force; it does not establish gate-release mechanics or penalties for non-compliance. The industry levy is mentioned as an option but not as a binding, multi-year commitment. The USD 4.5 billion reserve is identified but not legally protected from reallocation or offset against annual budgets.

---

# 2 Expert: Perennial-Crop Breeding and Durability-Testing Specialist

**Knowledge**: Hevea breeding cycles, polygenic resistance durability, pathogen evolution and resistance breakdown, multi-site field-trial design for perennial crops, germplasm-evaluation protocols

**Why**: The plan has zero slack to the Month 84 (2033-10-12) cultivar readiness gate: 6–10 year perennial cycles mean trials planted by Month 12 (2027-10-12) yield first data at Month 84 (2033-10-12), and any ABS slip beyond Month 12 (2027-10-12) pushes the gate to Month 96 (2034-10-12) or later. This expert validates the pre-registered KPI metrics (90% yield of elite clones, 3 stacked resistance sources, <5mm lesion size) and confirms whether the 4-site trial design is sufficient to detect resistance breakdown before deployment.

**What**: Review and validate the breeding KPI targets (yield, resistance sources, lesion thresholds, inoculum loads); assess the 4-site trial design (Brazil, Malaysia/Indonesia, Thailand, Côte d'Ivoire) for statistical power to detect yield penalties and durability failure; recommend monitoring protocols for Years 5–10 to catch early resistance breakdown.

**Skills**: Multi-site trial statistics, durability testing design, pathogen evolution modeling, Hevea agronomy, marker-assisted selection validation, perennial-crop breeding timelines

**Search**: Hevea breeding durability, perennial crop pathology, polygenic resistance testing, rubber germplasm field trials, resistance breakdown detection

## 2.1 Primary Actions

- Recruit dedicated Protocol Adoption Secretariat (3 FTE policy coordinators + 1 IPPC standard-writer) within FAO/IPPC by Month 3 (2027-01-12); publish draft SALB Containment Protocol for IPPC working-group comment by Month 4 (2027-02-12); negotiate binding bilateral MoUs with Brazil, Indonesia, Thailand, Malaysia, Vietnam by Month 6 (2027-04-12), each specifying national embedding timeline, inspector hiring (20+ per country), and quarterly reporting. Re-scope program if fewer than 3 of top-5 producers sign by Month 54 (2031-04-12).
- Hire specialized ABS legal counsel by Month 1 (2026-11-12); execute bilateral ABS agreements with Brazil CGen and 3+ Amazonian community groupings by Month 6 (2027-04-12), with published benefit-sharing terms (USD 1–5/ha, royalty-free seed for smallholders) and community-governed data trust. Establish Resistance Durability Oversight Panel (6 members: 2 breeders, 2 pathologists, 1 auditor, 1 germplasm specialist) by Month 1 (2026-11-12) to pre-register breeding KPIs and durability thresholds (yield ≥90% elite clone, ≥3 resistance sources, lesion <5mm) by Month 6 (2027-04-12).
- Contract independent international auditor (or auditor consortium) by Month 3 (2027-01-12) with written governance charter; pre-register audit scope and KPI definitions for all four gates by Month 6 (2027-04-12); establish binding Dispute-Resolution Adjudication Panel (3 neutral senior figures) to issue binding verdicts within 60 days if program and auditors dispute gate status. Require contractual data-access guarantees (auditors must access all trial, inspection, and benefit-sharing records within 5 business days) with financial penalties for non-compliance.
- Negotiate binding 25-year framework agreements with 5+ sovereign/MDB funders and the industry resilience levy agreement by Month 12 (2027-10-12); each agreement must specify committed capital tranches for Months 0–36 (2026-10-12 to 2029-10-12), 36–84, 84–144, 144–216, with minimum-funding floors (80% of planned tranche if gate is partially met), 45-day disbursement upon gate passage, and penalties for early funder withdrawal (5–10% forfeiture of undisbursed tranche). Ring-fence USD 4.5B reserve outside annual budget cycles.
- Establish Smallholder Adoption Working Group (Month 1, 2026-11-12) and define three explicit adoption scenarios (conservative 30–40%, moderate 40–50%, optimistic 60%+) with attached finance and extension commitments by Month 6 (2027-04-12). Deploy 500 lead extension agents and 100 locally-owned nurseries across top-5 producers by Month 12 (2027-10-12), with quarterly performance reviews. Set adoption waypoints at Months 36, 84, 144 (2029-10-12, 2033-10-12, 2038-10-12): if enrollment falls below 30% by Month 84 (2033-10-12), trigger reallocation of USD 800M–1.2B from smallholder to estate/alternative-crop investment.
- Launch multi-site Hevea field trials at 4 breeding hubs (Brazil, Malaysia, Thailand, Côte d'Ivoire) by Month 12 (2027-10-12), with 2 ha per cultivar, 3 replicate blocks of 100+ trees each, baseline inoculum surveys, and trained site managers. Pre-register durability protocol and success metrics (yield ≥90% of elite clones, ≥3 independent resistance sources, lesion <5mm) in peer-reviewed document by Month 6 (2027-04-12) to enable independent Year 7 auditor verification and prevent gate contestation.

## 2.2 Secondary Actions

- Establish published penalty schedule for protocol violations (nursery stock sale without certified pedigree = €5,000–50,000 + 12-month ban; SALB concealment = €10,000–100,000 + mandatory eradication without compensation) by Month 6 (2027-04-12). Implement anonymous mobile-based reporting system (SMS/WhatsApp) with €10–50 incentive per verified report, payable within 30 days. Conduct red-team drills every 18 months (Months 18–36 = 2028-04-12 to 2029-10-12, 54–72, 90–108) with external auditor verification and published results.
- Secure non-binding Letters of Intent from at least 8 of top-10 tire OEMs by Month 12 (2027-10-12), each committing to 500,000 tyres/year pilot supply and OEM test-facility access. Launch parallel tire-performance qualification trials at 3 accredited independent labs (TÜV, RAPRA, Smithers) by Month 12 (2027-10-12), covering tread wear (≥95% Hevea reference), rolling resistance (±5%), wet braking (≥95% Hevea), durability (500,000 km). Target qualification completion by Month 48 (2030-10-12); use purchase-option contracts (1.5% annual reservation fee) Months 48–60 (2030-10-12 to 2031-10-12).
- Allocate the USD 13.9B unallocated gate-conditional balance and decide the program-financed share of commercial plant capex (base case assumes 100% = USD 1.6B; alternative: co-finance 50% with OEMs or project finance) by Month 6 (2027-04-12) in the budget baseline. If processing-cost or quality targets are missed by Month 60 (2031-10-12), decide between added processing-innovation capital or redirecting funds to resistant-Hevea breeding. Prepare crown-budding fast-track decision paper (USD 0.25B estimate) for Month 48 (2030-10-12) trigger if yield penalty exceeds 15% (yield <85% of elite clones).
- Commission Guayule (2,000 t/year, Arizona/Mexico) and dandelion (1,000 t/year, Germany/Benelux) demonstration pilots by Month 24 (2028-10-12) within the USD 0.2B pilots budget. Establish cost KPI targets: by Month 48 (2030-10-12), feedstock at most USD 1.20/kg dry matter (Guayule), USD 1.00/kg (dandelion); by Month 84 (2033-10-12), processing cost at most USD 2.50/kg; by Month 144 (2038-10-12), delivered cost <30% above Hevea benchmark (USD 2.00/kg); by Month 216 (2044-10-12), at most 15% above Hevea.
- Hire compliance inspectors and train 100 total (20 per top-5 producer) by Month 12 (2027-10-12); each inspector requires 4-week initial training, conflict-of-interest rotation every 3 years, annual certification (50 inspection lots, ≥95% accuracy gate). Establish 10+ regional laboratories for surveillance, diagnostics, and breeding support by Month 24 (2028-10-12). Conduct quarterly compliance audits and monitor 100,000+ inspected lots/year; failure threshold below 30,000 lots/year triggers re-scoping.
- Publish all executed ABS agreements and benefit-sharing payment ledgers publicly by Month 12 (2027-10-12); set up community-governed data trust with 2+ indigenous/traditional-community seats overseeing quarterly benefit-sharing verification and annual open reporting. Establish contingency reserve (USD 4.5B, 15% of cap) separately managed by Dispute-Resolution Panel; define climate re-siting allocation (USD 1.0–1.5B estimate) if Guayule modelled yield loss exceeds 25% by Month 60 (2031-10-12).
- Pre-position eradication-response reserves (USD 0.5B compensation fund) for rapid payout within 30 days of confirmed incursion and mandatory eradication; design compensation schedule by Month 6 (2027-04-12) to remove farmer incentive to conceal SALB. Establish incursion response doctrine (eradication-first) with pre-positioned regional rapid-response brigades and reserve nurseries of pre-multiplied clean planting material by Month 24 (2028-10-12).

## 2.3 Follow Up Consultation

At Month 3 (2027-01-12) checkpoint: (1) report on ABS counsel engagement and preliminary CGen/community stakeholder mapping; (2) confirm auditor contract status and dispute-resolution panel recruitment; (3) brief on MoU negotiation progress with Brazil, Indonesia, Thailand; (4) present sensitivity analysis on ABS timeline slip (if negotiations slip to Month 12 = 2027-10-12 vs. Month 18 = 2028-04-12, what is the Year 7 gate impact?). At Month 6 (2027-04-12): present finalized adoption scenarios, penalty schedule, and breeding KPI thresholds for funder approval. At Month 12 (2027-10-12): report on MoU signatures, inspector hiring, trial-planting completion, OEM LoI status, and framework-agreement execution. Establish quarterly gate-readiness reviews starting Month 24 (2028-10-12) to detect timeline compression early.

## 2.4.A Issue - Zero Slack to Year 7 Gate: Perennial-Crop Biology Incompatible with ABS/MOU Delays

The plan assumes trials planted by Month 12 (2027-10-12) will yield 6-year durability and yield data by Month 84 (2033-10-12). Any ABS slip beyond Month 12 (2027-10-12) moves the gate to Month 96+ or invalidates Year 7 cultivar readiness. Yet ABS negotiations with CGen and three Amazonian communities routinely require 12–36 months; producer-nation MoU signing by Month 6 (2027-04-12) is aggressive and unproven. If either slips 6 months, the entire breeding pipeline compresses, forcing rushed field decisions with insufficient durability evidence. This cascades to smallholder adoption confidence collapse if deployed clones show yield penalties >10% in Year 8–10.

### 2.4.B Tags

- timeline_compression
- perennial_crop_biology
- ABS_negotiation_risk
- durability_testing_insufficiency
- gate_credibility_erosion

### 2.4.C Mitigation

Start ABS counsel and bilateral negotiations immediately (Month 1, 2026-11-12). Establish a parallel fast-track pathway: if CGen/community MoUs slip beyond Month 9 (2027-07-12), pivot to a curated subset of existing IRRDB/Embrapa germplasm accessions already in long-term storage (no new collection required, reducing ABS friction by ~6 months). Pre-register a modified durability protocol accepting 4-year field data (Month 72 = 2032-10-12) as a conditional gate pass if resistance sources are genetically distant (>75% dissimilarity, assessed by molecular markers). Establish a Resistance Durability Oversight Panel (Month 1 = 2026-11-12) to de-risk interpretation disputes. Brief funders by Month 3 (2027-01-12) on the timeline risk and contingency triggers.

### 2.4.D Consequence

Without mitigation: Year 7 gate slips to Month 96–108 (2034-10-12 to 2035-10-12), compressing cultivar deployment to Years 8–12 and orphaning smallholder adoption finance ($6.75B line becomes stranded sunk cost). Competing suppliers (Indonesia, Vietnam) advance non-gated breeding with unknown durability; OEM offtake signals fade; alternative-crop plants become unfeasible without a synchronized Hevea supply-chain recovery. Estimated $2–3 billion capital reallocated to damage control.

### 2.4.E Root Cause

The plan treats ABS and phytosanitary-MOU negotiation as fixed-duration administrative tasks, not as endogenous variables with high variance (12–36 month uncertainty documented). Perennial-crop breeding cannot be accelerated (6–10 year cycles are biological); thus the plan front-loads institutional risk onto compressed Months 1–12 (2026-11-12 to 2027-10-12) without contingency nursery material or durability thresholds.

## 2.5.A Issue - Containment Protocol Enforcement Rests on Producer-Country Sovereignty: IPPC Consensus Model Has Weak Sanctions

The plan embeds the SALB Containment Protocol in the IPPC framework, prioritizing legitimacy over enforceability. However, IPPC adoption requires consensus and relies on voluntary national adoption without binding sanctions. History of phytosanitary standards shows that enforcement is inconsistent: informal nurseries, cross-border smuggling, and misreporting of SALB symptoms are common in weak-governance zones (Cote d'Ivoire, Myanmar, parts of Indonesia). The plan assumes 100+ inspectors by Month 12 (2027-10-12) and red-team drill accuracy >95%, but inspector hiring and training depend on national budget commitments that face political volatility. A single undetected incursion in a secondary producer (e.g., Vietnam, Côte d'Ivoire) spreads to 5–20 million ha within 3–5 years, undermining the Year 3 gate credibility and cascading smallholder adoption collapse.

### 2.5.B Tags

- protocol_enforceability
- sovereign_compliance_risk
- inspector_capacity_fragility
- weak_sanctions_regime
- incursion_detection_gaps

### 2.5.C Mitigation

Establish a published, legally binding penalty schedule by Month 6 (2027-04-12) with financial and reputational consequences: nursery stock sale without certified pedigree = €5,000–50,000 fine + 12-month trading ban; concealment of SALB = €10,000–100,000 + mandatory eradication without compensation. Create an anonymous mobile-based reporting system (SMS/WhatsApp) with €10–50 incentives per verified report, payable within 30 days. Hire dedicated inspectors as program employees (not national agency staff) under 3-year rotating assignments, with conflict-of-interest rotation and annual certification based on audit of 50 inspection lots (95%+ accuracy gate). Conduct red-team drills every 18 months in Months 18–36 (2028-04-12 to 2029-10-12) and Months 54–72 (2031-04-12 to 2032-10-12), with external auditor verification and published results. Pre-position compensation reserves (USD 0.5B) to enable rapid payout within 30 days of confirmed eradication, removing the smallholder incentive to conceal.

### 2.5.D Consequence

Without mitigation: enforcement erodes from 95% (Year 1) to 60–70% (Year 5) as operators perceive non-compliance as low-risk. A single undetected nursery outbreak infects 10,000–20,000 ha, costing USD 50–100 million in destroyed plantings and deferring regional containment 2–5 years. Year 3 gate audit verdict becomes contested if surveillance data are self-reported; funders withhold Year 3 tranche (USD 7.0B) pending independent investigation, cascading a 12–18 month capital freeze.

### 2.5.E Root Cause

The plan assumes IPPC legitimacy automatically translates to compliance, but IPPC is a consensus body with no enforcement authority. Perennial-crop SALB containment requires credible, swift punishment for violations and trusted inspectors; the plan defers these to national agencies without binding program control or financial incentives for detection.

## 2.6.A Issue - Smallholder Uptake Planning (45%) Is Untested and Finance Exposure (USD 6.75B) Lacks Contingency Scenarios

The plan targets 45% uptake of 5 million ha eligible smallholder area (2.25 million ha) by Month 144 (2038-10-12), but historical adoption of improved Hevea clones in smallholder networks shows 20–40% uptake rates even with extension and finance in place. The plan allocates USD 6.75B (about 23% of the USD 30B cap) to replant and income-bridging finance without published sensitivity analysis for 30%, 35%, 40%, or 50% scenarios. If uptake falls to 30% by Month 84 (2033-10-12), the program reallocates USD 800M–1.2B from smallholder infrastructure to estate trials, stranding extension agents and cooperatives and undermining the entire 'smallholder-centered' design narrative. The USD 400M protected extension stream is undersized for decentralized local-ownership delivery; 500 lead agents at 200–500 smallholders each = 100,000–250,000 farmers, but eligible area is 5 million ha ÷ ~1.5 ha/farm = 3.3+ million farms. Thus 3% coverage at best, requiring 5,000+ agents to reach 15% (estimate).

### 2.6.B Tags

- adoption_uptake_risk
- finance_exposure_concentration
- extension_workforce_undersizing
- contingency_scenario_absence
- smallholder_design_credibility

### 2.6.C Mitigation

Establish a Smallholder Adoption Working Group by Month 1 (2026-11-12) and define three explicit scenarios by Month 6 (2027-04-12): conservative 30–40%, moderate 40–50%, optimistic 60%+, each with distinct finance and extension commitments. Model sensitivity: each 10% shortfall below 60% reduces resistant-cultivar acreage 5–7% and defers regional risk reduction 2–3 years. Separately fund extension at USD 400–600M (not USD 400M alone) and deploy 500 lead agents + 100 locally-owned nurseries by Month 12 (2027-10-12), with quarterly performance reviews tied to smallholder enrollment, retention (12-month), and income continuity. Structure income-bridging as a 25-year protected stream managed locally through cooperatives, not central program, with repayment triggered only if first-tapping yield exceeds 2 tonnes/year dry rubber. Set adoption waypoints at Months 36, 84, 144 (2029-10-12, 2033-10-12, 2038-10-12): if enrollment falls below 30% by Month 84 (2033-10-12), trigger a decision to reallocate USD 800M–1.2B from smallholder to estate/alternative-crop investment and reduce Year 12 smallholder acreage target by 30–40%.

### 2.6.D Consequence

Without mitigation: by Month 84 (2033-10-12), uptake data reveal 25–30% actual enrollment versus 45% plan, leaving USD 1.5–2.5B in extension and cooperative capital without customer base. Cooperatives fold or pivot to higher-margin crops; trained extension agents quit (30–50% turnover estimated by Year 10); clean-plant nurseries close. Year 12 gate assessment of 'smallholder adoption' becomes a contested audit verdict, with funders questioning whether resilience claims are delivered to farmers or merely to estates. Political pressure mounts in producing countries to redirect freed capital domestically, risking the program's public-private balance.

### 2.6.E Root Cause

The plan treats smallholder uptake as a dependent variable that flows from finance and extension supply, but adoption is driven by farmer preference, agronomic confidence (yield, risk), and income certainty. Without scenario-based contingency finance, and without explicit stop triggers, the program is over-committed to a single adoption pathway with insufficient flexibility or local accountability.

---

# 3 Expert: Long-Horizon Public Finance and Development-Bank Funding Structures Expert

**Knowledge**: Multilateral development bank instruments, sovereign commitments across budget cycles, gate-conditional capital release mechanisms, ring-fenced funds, contingent financing, levy and resilience instruments, 25-year funding durability

**Why**: The plan's $30 billion cap with $4.5 billion reserve depends on binding 25-year commitments by Month 12 (2027-10-12), yet producer nations face budget cycles, OEM levy defection risk (USD 150M/year), and geopolitical volatility. This expert audits the Capital Stack and Sponsor Coalition decision, validates the minimum-funding-floor language (80% partial release), and ensures the USD 4.5B reserve and levy agreements are legally enforceable.

**What**: Review the proposed framework agreements for World Bank, ADB, AfDB, IADB, IFAD and the OEM levy structure; identify gaps in force-majeure and early-withdrawal penalty clauses; recommend dispute-resolution language for gate-release hold-ups; assess feasibility of a 0.75% levy (USD 150M/year) and enforcement mechanisms for 25 years.

**Skills**: Development-bank covenant design, legal drafting of long-term commitments, budget-cycle risk mitigation, gate-release and tranche mechanics, sovereign-commitment durability, public-private co-financing structures

**Search**: MDB funding mechanisms, sovereign commitment durability, gate-conditional capital release, resilience levy design, 25-year infrastructure finance

## 3.1 Primary Actions

- By Month 1 (2026-11-12), contract specialized long-horizon development-finance counsel and phytosanitary-governance counsel to draft binding framework agreement templates and specimen Protocol-Adoption Agreements (not MoUs) for the capital stack and producer-nation commitments; establish the Dispute-Resolution Adjudication Panel (3 neutral senior figures) and write its charter by Month 3 (2027-01-12).
- By Month 12 (2027-10-12), execute legally binding 25-year framework agreements with at least 5 sovereign/MDB funders (none above 20%) specifying: minimum-funding floors (80% of gate tranches released on partial-gate success), 45-day mandatory disbursement, ringfenced capital outside annual budgets, force-majeure carve-outs (12-month postponement, not cancellation), and withdrawal penalties (5–10% forfeiture of undisbursed tranche).
- By Month 12 (2027-10-12), contract an independent auditor and lock in a written audit governance charter specifying: mandatory data access within 5 business days (with 1–2% fee penalties per 5-day delay for non-compliance), random site selection (30–40% of auditor-chosen sites, not programme-designated), multi-source verification (field 30–40%, database 40–50%, interviews 20–30%), binding adjudication by the Dispute-Resolution Panel if verdicts are disputed, and publication of all gate verdicts within 30 days.
- By Month 6 (2027-04-12), execute legally binding Protocol-Adoption Agreements (not MoUs) with at least 3 of 5 top producers (Brazil, Indonesia, Thailand priority) specifying: national embedding by Month 36 (2029-10-12), inspector hiring and funding (20 per major producer by Month 12 = 2027-10-12) with auditor verification, penalties for non-compliance (ineligibility for capacity grants, supply-chain scrutiny by OEMs), and a fallback Regional Protocol-Adoption Accord (binding on all 5 producers, enforceable via OEM supply-chain demands) if IPPC consensus stalls beyond Month 30 (2029-04-12).
- By Month 6 (2027-04-12), allocate the USD 13.9 billion unallocated gate-conditional balance and decide the plant financing split (share of USD 1.6 billion commercial plant capex financed by programme vs. OEMs/partners/project finance); establish a Steering Council decision-gate at Month 12 (2027-10-12) to approve or defer wave 1 plant final investment decision to Month 72 (2032-10-12).
- By Month 3 (2027-01-12), pre-register breeding KPI success metrics (yield ≥90% of elite clones, ≥3 independent resistance sources stacked, lesion size <5mm, artificial inoculation at 10x field-typical load) in a published, peer-reviewed breeding protocol; establish the Resistance Durability Oversight Panel (6 members: 2 perennial-crop breeders, 2 plant pathologists, 1 independent auditor, 1 germplasm-access specialist) and convene monthly through Month 24 (2028-10-12), then quarterly through Month 120 (2036-10-12).

## 3.2 Secondary Actions

- By Month 3 (2027-01-12), recruit a Protocol Adoption Secretariat within FAO/IPPC (at least 3 full-time policy coordinators, 1 phytosanitary standard-writer) and publish the draft SALB Containment Protocol for IPPC working-group comment by Months 3–4 (2027-01-12 to 2027-02-12); target IPPC adoption vote by Month 36 (2029-10-12).
- By Month 3 (2027-01-12), hire specialized Access-and-Benefit-Sharing (ABS) legal counsel and negotiate bilateral ABS agreements with Brazil CGen and at least 3 Amazonian community groupings (e.g., COIAB, FOIRN); execute binding ABS agreements by Month 6 (2027-04-12) specifying benefit-sharing structure (USD 1–5 per ha deployed cultivar), royalty-free seed for smallholders, open-access genomic publication within 12 months, and community-governed data trust with 2+ indigenous seats.
- By Month 12 (2027-10-12), secure Letters of Intent from at least 8 of 10 top tire makers (Bridgestone, Goodyear, Michelin, Continental, Sumitomo, Yokohama, Pirelli, Hankook, Cooper, Toyo) committing to: supply-chain trials of Guayule and dandelion in 500,000 tyres/year for 24 months (pilot qualification scale), access to OEM test facilities, price-signal feedback (maximum acceptable premium over Hevea benchmark), and binding offtake negotiation start by Month 48 (2030-10-12); convene monthly OEM Steering Committee by Month 3 (2027-01-12) with VP-level attendance.
- By Month 6 (2027-04-12), establish a Smallholder Adoption Working Group with representatives from top-5 producing countries' farmer associations and research institutes; define three adoption scenarios (conservative 30–40%, moderate 40–50%, optimistic 60%+) with explicit finance and extension commitments; set adoption KPI waypoints at Months 36 (2029-10-12), 84 (2033-10-12), and 144 (2038-10-12) with decision triggers (if adoption <30% by Month 84 = 2033-10-12, reallocate USD 800M–$1.2B from smallholder replanting to estate-scale Hevea trials and alternative-crop processing).
- By Month 12 (2027-10-12), recruit and deploy 500 lead extension agents (each serving 200–500 smallholders) and launch multi-site Hevea breeding trials at 4 established hubs (Brazil, Thailand, Malaysia/Indonesia, Cote d'Ivoire); establish at least 50–100 certified micro-nurseries per major country and at least 10 regional diagnostic labs by Month 24 (2028-10-12).
- By Month 6 (2027-04-12), establish a published, legally binding penalty schedule for containment protocol violations (nursery stock sale without certified pedigree: €5,000–€50,000 fine + 12-month suspension; concealment of SALB infection: €10,000–€100,000 fine + mandatory destruction without compensation; public listing of violators on programme website for 24 months); hire 100 dedicated protocol-compliance inspectors (20 per top-5 producer) and conduct protocol-compliance red-team drills in Months 18–36 (2028-04-12 to 2029-10-12) in at least 3 countries with at least 95% detection accuracy (proposed threshold).
- By Month 12 (2027-10-12), negotiate binding 25-year commitment from top 10 tire makers and 5 natural-rubber traders for industry resilience levy (0.75% of annual purchases = USD 147M/year, estimate) collected into ring-fenced fund outside government budget cycles; levy agreements include 10-year minimum commitment, 2-year capital forfeiture penalty for early withdrawal before Month 120 (2036-10-12), and governance representation (2 levy-contributor seats on Steering Council).
- By Month 12 (2027-10-12), launch parallel tire-performance qualification trials at 3 accredited independent test labs (TÜV, RAPRA, Smithers) for Guayule and dandelion crude rubber and blended-tread formulations; qualification targets completion by Month 48 (2030-10-12) with acceptance thresholds: tread-wear 95% of Hevea reference, rolling resistance within ±5%, wet braking ≥95% of Hevea, durability ≥500,000 km road trial.

## 3.3 Follow Up Consultation


"At the next consultation (Month 3 = 2027-01-12 or Month 6 = 2027-04-12), address five unresolved execution risks: (1) Verify that the binding framework agreements are legally enforceable, not rhetorical (engage development-finance counsel to review terms for enforceability, ringfencing, and force-majeure carve-outs); (2) Confirm auditor independence and data-access guarantees (request auditor contract excerpts showing 5-day data-access response times, random site-selection protocols, and binding dispute-resolution authority); (3) Report on producer-nation binding Protocol-Adoption Agreement signatures and inspector-hiring funding commitments (provide evidence that binding agreements are signed by Month 6 = 2027-04-12, not merely MoUs); (4) Validate ABS agreement execution and community co-governance structures (publish signed ABS agreements and data-trust charter by Month 6 = 2027-04-12); (5) Confirm allocation of the USD 13.9 billion unallocated balance and plant financing split decision (provide budget line-item reallocation by Month 6 = 2027-04-12 and a steering-council memo authorizing or deferring wave 1 final investment decision). If any of these five items are not completed by Month 12 (2027-10-12), the institutional foundation for the gate logic remains incomplete, and a formal risk-escalation review should trigger a 6–12 month execution defer pending clarity on funding durability, producer adoption, and auditor independence."


## 3.4.A Issue - Capital Stack Durability Framework Lacks Binding Long-Horizon Commitment Structures and Force-Majeure Carve-Outs Critical to 25-Year Execution

The plan asserts a 'binding 25-year framework agreement by Month 12 (2027-10-12)' but provides no covenant language, minimum-funding-floor formulas, or force-majeure definitions that development banks require. Specifically: no articulation of how gate-conditional tranches survive missed gates (the 80% partial-release rule exists, but enforcement mechanisms are absent); no explicit constraint on budget-cycle repriorization (which has orphaned 40-60% of intended long-horizon agricultural programs globally); and no carve-out protocol for external shocks (pandemic, war, climate catastrophe) that triggers 12-month postponement without cancellation. Without these covenant mechanics locked in the legal agreements by Month 12 (2027-10-12), sovereign and MDB funders will default to annual appropriation cycles when Year 7 or Year 12 gates face credible or actual miss, cascading $5–8 billion in capital withholding.

### 3.4.B Tags

- covenant-design
- funding-durability
- tranche-enforcement
- budget-cycle-risk
- force-majeure-definition

### 3.4.C Mitigation

By Month 3 (2027-01-12), engage specialized long-horizon development-finance counsel (legal experts in World Bank/ADB framework agreements, multilateral guarantee instruments) to draft binding framework templates. By Month 12 (2027-10-12), execute signed framework agreements with at least 5 sovereign/MDB funders (none above 20%) that include: (i) legally binding minimum-funding floors (e.g., 80% of each gate tranche released automatically on auditor sign-off, not subject to annual appropriation); (ii) 45-day mandatory disbursement windows post-gate with penalties for delay; (iii) ringfenced capital held in a special-purpose vehicle or escrow account outside annual government budgets; (iv) explicit force-majeure carve-outs (pandemic, war, major climate catastrophe defined ex-ante) permitting 12-month postponement of capital, not cancellation; (v) penalty for early withdrawal (e.g., forfeit 5–10% of undisbursed tranche) to deter budget-cycle defection. Consult: World Bank Long-Term Development Finance Unit, ADB Legal Department, FAO Capital Mobilization team. Read: World Bank Project Appraisal Documents for 20+ year agriculture programs; ADB safeguards and covenant frameworks; multilateral guarantee instrument case studies (e.g., MIGA guarantees).

### 3.4.D Consequence

Without enforceable covenant language and ringfenced capital by Month 12 (2027-10-12), the plan faces $5–8 billion in capital withholding if Year 7 or Year 12 gates are partially missed or delayed. Historical precedent: 60–70% of intended long-horizon agricultural programs globally experience 12–36 month budget delays when gates are contested. If $5–8 billion is withheld in Year 7 (when cultivar deployment capital is due), resistant-cultivar release scales 2–3 years late, smallholder adoption timelines slip, and Phase 3 (Months 84–144 = 2033-10-12 to 2038-10-12) containment confidence erodes. This cascade risks $500 million–$1.2 billion in smallholder replant finance becoming stranded and unrecoverable, with reputational damage to global public-private financing models.

### 3.4.E Root Cause

The plan conflates rhetorical commitment ('binding 25-year framework') with enforceable covenant language. Development banks operate from annual budget cycles and require explicit legal mechanisms that override yearly repriorization: (i) minimum-funding floors (e.g., no less than 80% of planned Year 7 tranche even if gate is partially met), (ii) mandatory disbursement within 45 days of gate passage (not subject to funder annual review), (iii) ringfenced capital held in escrow or special-purpose vehicle outside funder balance sheets, and (iv) force-majeure carve-outs with automatic 12-month postponement of capital, not cancellation. The current plan assumes goodwill continuity, which is not credible across 25 years of budget cycles, political transitions, and competing global priorities.

## 3.5.A Issue - Gate Evidence Verification Regime Lacks Contractually Guaranteed Data-Access Rights and Dispute-Resolution Binding Judgments, Leaving Auditor Independence Partial and Gates Contestable

The plan calls for an 'independent international auditor' contracted by Month 3 (2027-01-12) and scope 'pre-registered by Month 6 (2027-04-12),' but provides no contractual language guaranteeing auditor access to data held by programme managers, national agencies, or breeding teams. Auditor independence is only theoretical if the same programme managers who stand to lose credibility when gates are missed can withhold or delay data release without contractual penalty. Specifically: (i) no contractual right for auditors to demand data within 5 business days, with escalation to a dispute-resolution panel if access is delayed; (ii) no binding adjudication mechanism (the plan mentions a 60-day panel decision, but does not specify who appoints the panel, how they are independent, or what enforcement mechanism exists if the programme or a funder disputes the panel's verdict); (iii) no multi-source verification protocol that prevents data-collection bias (e.g., programme staff could cherry-pick 'best' trial sites for auditor visits, leaving underperforming sites unexamined). Without these contractual guarantees, auditors depend on goodwill data-sharing, which erodes under pressure if breeding trials show yield penalties >10% or if smallholder adoption falls below 30%.

### 3.5.B Tags

- auditor-independence
- data-access-rights
- gate-contestability
- dispute-resolution
- verification-bias

### 3.5.C Mitigation

By Month 3 (2027-01-12), contract the auditor and establish a Dispute-Resolution Adjudication Panel (3 neutral, senior figures from non-programme institutions, e.g., retired phytosanitary authority, independent agronomist, financial auditor). By Month 6 (2027-04-12), lock in a written audit contract specifying: (i) auditor access rights: programme and national partners must provide all data (trial databases, inspection records, benefit-sharing ledgers) within 5 business days of auditor request, with financial penalties (1–2% of auditor fee per 5-day delay, estimated) for non-compliance; (ii) multi-source verification: auditor randomly selects 30–40% of trial sites and 50–100 smallholder samples per gate (not programme-designated sites), with auditor authority to add unscheduled site visits if data shows outliers; (iii) binding adjudication: if programme or funder disputes auditor verdict, the Dispute-Resolution Panel issues binding judgment within 60 days, with no further appeal; (iv) publication requirement: all gate verdicts (pass, conditional, fail) and supporting evidence published within 30 days of audit conclusion, with auditor free to issue minority or dissenting opinion if gate verdict is overridden by politics. Budget: USD 30–50 million (estimate) over 25 years for auditor and panel operations.

### 3.5.D Consequence

Without contractually guaranteed data-access rights and binding dispute resolution, auditors become advisory rather than authoritative. If breeding trials show yield penalties of 10–15% or smallholder adoption falls below 30% by Month 84 (2033-10-12), programme managers facing reputational pressure can withhold or delay data release, claiming 'confidentiality' or 'methodological review pending.' Auditors cannot override this without contractual authority. The Year 7 gate then becomes politicized: if auditors report partial miss (e.g., 'cultivars at 85% yield, conditional pass'), funders and programme leadership may dispute the verdict and withhold tranches pending re-audit. This cascade cascades: $2–3 billion in Year 7 capital is frozen for 6–12 months, cultivar deployment is delayed 2–3 years, smallholder adoption confidence collapses (farmers see inconsistent messaging about cultivar readiness), and the entire gate logic—which is the plan's core institutional safeguard—loses credibility. Historical precedent: 40–50% of gated infrastructure programmes globally face tranche-release disputes when auditor verdicts are non-binding.

### 3.5.E Root Cause

The plan separates the governance concept (independent auditor) from the legal mechanism (contractual data-access rights and binding dispute resolution). Development-bank gate logic depends on credible third-party verification that is institutionally and financially independent from programme management and national partners. The root cause is the absence of: (i) contractual data-access rights with time-bound responses (5 business days) and financial penalties for non-compliance (e.g., auditor fee withholding if access is delayed); (ii) adversarial dispute-resolution mechanism with binding authority (a neutral three-person panel with authority to override programme and funder disagreement); (iii) structured audit methodology that prevents site-selection bias (e.g., auditor randomly selects 30–50% of trial sites and smallholder samples, not programme-designated showcase sites). Without these, the auditor's verdict is advisory, not binding, and $2–3 billion in Year 7 tranche capital becomes contestable if auditors report unfavourable results.

## 3.6.A Issue - Producer-Nation Protocol Adoption Roadmap Lacks Binding Legal Commitments, Inspector-Hiring Enforcement Clauses, and Penalty Schedules, Leaving Phase 1 Non-Negotiable Deliverable Dependent on Voluntary Compliance

The plan names 'bilateral Memoranda of Understanding (MoUs)' with Brazil, Indonesia, Thailand, Malaysia, and Vietnam by Month 6 (2027-04-12) as the critical path to embedding the SALB Containment Protocol in national phytosanitary legislation by Month 36 (2029-10-12). However, the plan provides no specimen MoU language, no enforcement mechanism for national commitment (e.g., if a nation signs an MoU but does not fund 20 inspectors, who enforces compliance?), and no consequence if producer nations delay national embedding beyond Month 48 (2030-10-12) (the plan mentions a re-scope trigger at Month 54 = 2031-04-12 if fewer than 3 of 5 have binding adoption, but by then 12–18 months have been lost in the critical path, cascading delays to the Month 36 = 2029-10-12 gate). Specifically: (i) MoUs are typically non-binding diplomatic instruments; (ii) no articulation of what 'binding adoption' means legally (ratification? legislative passage? budget allocation?); (iii) no penalty schedule if a nation signs an MoU but fails to hire inspectors (estimated 20 per major producer by Month 12 = 2027-10-12); (iv) no escalation mechanism if a nation blocks IPPC adoption at the formal vote (Month 36 = 2029-10-12 gate depends on an IPPC adoption vote, but any single IPPC member can delay or veto consensus).

### 3.6.B Tags

- mou-enforceability
- producer-commitment
- protocol-adoption
- inspector-capacity
- ippc-consensus-risk

### 3.6.C Mitigation

By Month 1 (2026-11-12), hire specialized phytosanitary-governance counsel with experience in bilateral plant-protection agreements (e.g., IPPC member-state negotiators, plant-health treaty drafters). By Month 3 (2027-01-12), draft specimen binding Protocol-Adoption Agreements (not MoUs) for each of the top five producers, specifying: (i) each nation commits to embed the protocol in national phytosanitary legislation by Month 36 (2029-10-12) (with defined 'embedding' = legislative passage + budget allocation + formal notification to IPPC); (ii) each nation commits to hire and fund at least 20 inspectors per major producer by Month 12 (2027-10-12), with auditor verification; (iii) penalty for non-compliance: if a nation fails to hire inspectors by Month 12 (2027-10-12), that nation becomes ineligible for phytosanitary-capacity grants (estimated USD 2–5 million per country) and its commercial exports face scrutiny; (iv) alternative pathway for IPPC adoption: if IPPC consensus stalls beyond Month 30 (2029-04-12), the programme activates a parallel producer-country coalition (Brazil, Indonesia, Thailand, Malaysia, Vietnam) that ratifies a Regional Protocol-Adoption Accord binding on all five, enforceable via OEM supply-chain demands (tire makers refuse to source from non-protocol nations). By Month 6 (2027-04-12), execute binding Protocol-Adoption Agreements with at least 3 of 5 top producers (targeting Brazil, Indonesia, Thailand first). Consult: IPPC Secretariat (FAO), regional plant protection organizations, phytosanitary treaty experts at WTO or UPOV. Read: bilateral plant-protection agreements (e.g., EU-China plant-health protocol), IPPC consensus-building procedures, case studies of stalled consensus and fallback mechanisms.

### 3.6.D Consequence

Without binding legal commitments and inspector-hiring enforcement, Phase 1 depends on voluntary national compliance, which erodes under budget pressure. Historical precedent: 50–60% of phytosanitary capacity-building commitments globally are signed but not funded; nations sign MoUs but do not allocate budget to inspectors within 12 months. If only 1–2 of the top 5 producers fund inspectors by Month 12 (2027-10-12), the protocol enforcement capacity falls to 20–40 inspectors instead of the targeted 100, leaving 60–80% of nurseries and estates unsupervised. A single missed inspector-hiring target cascades: (i) surveillance capability is halved (100,000+ lots/year inspection capacity requires 100 inspectors; 20–40 inspectors cover only 20,000–40,000 lots/year, proposed threshold is 30,000); (ii) if SALB incursion occurs in an unsurveilled nursery, the protocol fails to detect it before spread (detection target is under 3 months, but sparse inspection coverage extends detection to 6–9 months, estimate); (iii) the Month 36 (2029-10-12) gate criterion ('at least 100 inspectors active') becomes unmet, triggering conditional or failed gate and $7 billion Year 3 tranche withholding. If IPPC adoption vote stalls and the plan lacks a fallback regional coalition, the Phase 1 containment protocol becomes a shelf document, invalidating the entire gate logic and risking uncontrolled SALB spread.

### 3.6.E Root Cause

The plan conflates diplomatic signaling (MoU signature) with legal obligation (binding commitment enforceable in case of breach). MoUs are understood in international law as non-binding statements of intent; they do not create enforceable obligations unless explicitly framed as 'intended to be binding' or paired with ancillary binding instruments (e.g., a bilateral agreement on inspector standards and funding). The plan also underestimates consensus-building risk at the IPPC level: IPPC adoption requires consensus or supermajority vote, and a single major producing nation can delay indefinitely. The root causes are: (i) no specimen binding protocol-adoption agreement (not an MoU, but a formal bilateral agreement with legal consequences for non-compliance); (ii) no explicit inspector-hiring and funding obligations (e.g., each nation commits to fund 20 inspectors by Month 12 = 2027-10-12, or faces penalty); (iii) no alternative pathway if IPPC consensus stalls (the plan assumes IPPC adoption by Month 36 = 2029-10-12, but consensus-building can take 12–24 months; no fallback to regional adoption or a parallel producer-country coalition is articulated).

---

# 4 Expert: Access-and-Benefit-Sharing and Indigenous-Community Governance Specialist

**Knowledge**: Nagoya Protocol compliance, Brazil CGen system, community co-governance models, benefit-sharing payment tracking, ABS dispute resolution, indigenous land rights, germplasm trusts

**Why**: The plan's Brazil-led breeding and $0.4 billion Hevea improvement line depend on ABS agreements with Brazil's CGen and at least 3 Amazonian community groupings by Month 6 (2027-04-12). Any slip beyond Month 12 (2027-10-12) moves the Year 7 gate to Month 96 (2034-10-12) or later. This expert assesses the realism of a Month 6 (2027-04-12) close, validates the benefit-sharing structure (USD 1–5/ha royalty-free seed for smallholders), and identifies legal-dispute risks (USD 100–500M exposure noted in the plan).

**What**: Review the proposed bilateral ABS agreement template with CGen and three community groupings; assess compliance with Nagoya Protocol and Brazil's constitutional rights framework; validate the community-governed data-trust structure; recommend dispute-resolution and benefit-tracking mechanisms; identify regulatory blockers to timely cultivar release.

**Skills**: Nagoya Protocol negotiation, Brazil CGen process, community co-governance design, benefit-sharing ledgers and transparency reporting, indigenous-rights law, germplasm-access timelines

**Search**: Nagoya Protocol ABS negotiations, Brazil CGen access agreements, indigenous community benefit-sharing, germplasm trusts, biodiversity benefit tracking

## 4.1 Primary Actions

- By Month 1 (2026-11-12 14:00): Hire specialised Nagoya Protocol access-and-benefit-sharing counsel (proven track record: 15+ negotiated bilateral ABS agreements) to lead Brazil CGen negotiations and establish a legally binding community-co-governed benefit-sharing trust with veto authority over cultivar licensing. Establish a Dispute-Resolution Adjudication Panel with published legal charter and binding gate-verdict authority (composition: 3 neutral senior figures; funding: USD 2–5 million/year ring-fenced). Recruit a Resistance Durability Oversight Panel (6 members: 2 perennial-crop breeders, 2 pathologists, 1 independent auditor, 1 germplasm-access specialist) to pre-approve all breeding trials and interpret Year 7 gate evidence.
- By Month 3 (2027-01-12 14:00): Contract independent international auditor (or auditor consortium) with explicit governance charter specifying multi-source verification (field 30–40%, database 40–50%, interviews 20–30%), mandatory publication of verdicts within 30 days, and guaranteed data access (5-business-day response window, penalties 1–2% of auditor fee per delay). Pre-register auditor scope and KPI definitions in a peer-reviewed protocol document, published and locked before data collection. Recruit Protocol Adoption Secretariat within FAO/IPPC (3 full-time policy coordinators, 1 IPPC standard-writer) and begin bilateral negotiations with Brazil, Indonesia, Thailand, Malaysia, Vietnam.
- By Month 6 (2027-04-12 14:00): Execute legally binding ABS agreements with Brazil's CGen and at least 3 Amazonian community groupings, specifying: benefit-sharing formula (USD 2–5/hectare of deployed cultivar based on genealogy tracking), community board veto on licensing, quarterly benefit-verification and public ledger publication, royalty-free seed guarantee for smallholders. Publish all ABS agreements and payment records publicly. Sign producer-nation Memoranda of Understanding (Brazil, Indonesia, Thailand, Malaysia, Vietnam) committing each to IPPC-embedded protocol adoption by Month 36 (2029-10-12), inspector hiring targets (20+ per country by Month 12 = 2027-10-12), and quarterly compliance reporting. Establish Smallholder Adoption Working Group defining three explicit scenarios (conservative 30–40%, moderate 40–50%, optimistic 60%+) with costed finance and extension commitments, contingency reallocation triggers, and local cooperative co-governance of finance decisions.
- By Month 12 (2027-10-12 14:00): Lock sovereign and multilateral development-bank funding into legally binding 25-year framework agreements with gate-release mechanisms (45-day disbursement after gate passage, not subject to annual budget cycles), minimum-funding floors (80% of tranche on partial gate success), force-majeure definition, and withdrawal penalties (5–10% of undisbursed tranche forfeit). Negotiate binding industry-levy agreements (0.75% of covered natural-rubber purchases, 10-year minimum commitment, penalties for early defection). Deploy 100+ compliance inspectors (20 per top-5 producer), 500 lead extension agents (locally-owned nurseries, not central programme employment), establish 50–100 certified nurseries per major producing country, and launch 10 regional diagnostic laboratories. Secure non-binding Letters of Intent from at least 8 of 10 OEMs for offtake, including supply-chain qualification trials and price-signal feedback. Launch multi-site field trials at 4 breeding hubs (Brazil, Malaysia/Indonesia, Thailand, Côte d'Ivoire) with baseline soil and inoculum surveys.
- By Month 36 (2029-10-12 14:00): Hold IPPC adoption vote on the SALB Containment Protocol and secure binding national embedding in at least 3 of the top 5 producers. Complete red-team drills in at least 3 countries with 95%+ detection accuracy. Establish smallholder adoption monitoring: enrolment tracking, extension-agent performance audits (quarterly), default rates by country (stop trigger at 20%+ default rate). Publish independent auditor's Month 36 (2029-10-12) gate verdict with full supporting evidence.

## 4.2 Secondary Actions

- By Month 3 (2027-01-12): Publish draft IPPC-harmonized SALB Containment Protocol (covering nursery stock movement, research-material quarantine, equipment decontamination, red-team protocols) for circulation to IPPC working groups.
- By Month 4 (2027-02-12): Circulate protocol draft to IPPC working groups and solicit formal comments; target formal IPPC adoption vote by Month 36 (2029-10-12).
- By Month 6 (2027-04-12): Pre-register breeding KPI targets in a published, peer-reviewed protocol (yield ≥90% of elite clones, ≥2 independent resistance sources stacked by Month 60 = 2031-10-12, ≥3 by Month 84 = 2033-10-12, lesion size <5 mm, artificial inoculation at 10× field-typical load). Establish monthly payment-tracking ledger for benefit-sharing verification (community benefit-sharing trust governance responsibility). Allocate the USD 13.9 billion unallocated balance at the Month 6 (2027-04-12) budget baseline and decide plant financing split (share financed by programme vs. OEM/partner/project finance).
- By Month 9 (2027-07-12): Complete in-person training for 500 extension agents (2 weeks each) on SALB symptom identification, clean-plant handling, resistant-cultivar agronomy. Establish mobile-phone attestation system for lot tracking and smallholder reporting. Launch baseline SALB surveillance network (spore traps, canopy imaging partnerships, laboratory confirmation hubs).
- By Month 12 (2027-10-12): Publish all executed ABS agreements and benefit-sharing payment records; establish community-data trust board and schedule quarterly meetings. Set extension-agent retention targets and performance metrics (smallholder enrolment, lot-inspection pass rates). Recruit and train 100 compliance inspectors with conflict-of-interest declarations and 3-year rotation requirements. Publish anonymous smallholder-reporting incentive system (EUR 10–50 per confirmed report, 30-day payment window).
- By Month 18–36 (2028-04-12 to 2029-10-12): Conduct protocol-compliance red-team drills in 3 producing countries (attempt to move contaminated material through supply chain, test inspector detection, documentation scrutiny, response speed). Publish drill results transparently; remedial training for deficient regions by Month 42 (2030-04-12). Track field-trial progress at 4 breeding sites with quarterly Resistance Durability Oversight Panel reviews.
- By Month 24 (2028-10-12): Commission Guayule demonstration pilot (2,000 t/year, Arizona/Mexico) and dandelion pilot (1,000 t/year, Germany/Benelux). Establish 10 regional diagnostic laboratories serving surveillance, diagnostics and breeding for all producers. Launch monthly OEM Steering Committee with top-10 tire makers; collect tire-performance feedback and cost-premium thresholds. Launch parallel tire-performance qualification trials at 3 independent labs (tread wear, rolling resistance, wet braking, durability).
- By Month 36 (2029-10-12): Publish independent auditor's Month 36 (2029-10-12) gate verdict with full supporting evidence (containment protocol adoption, inspection capacity, red-team results). Set Month 84 (2033-10-12) adoption waypoint (30% smallholder enrolment target); if below 30%, trigger contingency reallocation of USD 0.8–1.2 billion. Re-scope if fewer than 3 of top-5 producers have binding protocol adoption; if so, defer Year 7 gate to Month 96 (2034-10-12) or beyond.
- By Month 48 (2030-10-12): If yield penalty in breeding trials exceeds 15% (yield <85% of elite clones), initiate crown-budding fast-track decision and steering-council approval (USD 0.25 billion, fits cap via unallocated balance). Complete tire-performance qualification trials and collect OEM feedback on cost-premium acceptability (maximum acceptable premium over Hevea benchmark).
- By Month 60 (2031-10-12): If alternative-rubber cost or processing targets are missed, decide between added processing-innovation capital or redirecting funds to resistant-Hevea breeding. No wave-1 commercial plant commitment before this decision. Finalize OEM purchase-option contracts (1.5% annual reservation fee, ~USD 1.06 million/year on full 8-plant operation).
- By Month 84 (2033-10-12): Publish independent auditor's Year 7 gate verdict (cultivar yield KPI, resistance-source stacking, field durability). Set Month 144 (2038-10-12) adoption waypoint (40% of eligible area replanted). Decide on wave-1 commercial plant commitment if cost and OEM signals are credible; target final investment decision at Month 72 (2032-10-12) and commissioning Months 96–108 (2034-10-12 to 2035-10-12).
- Months 36, 84, 144, 216 (2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12): Publish independent auditor verdicts on containment, cultivar readiness, alternative-rubber cost/quality and smallholder adoption KPIs; release tranches within 45 days if gates are passed (minimum 80% on partial success).

## 4.3 Follow Up Consultation


At Month 6 (2027-04-12), the next consultation should address: (1) **ABS Dispute Outcomes and Contingency**: publish executed ABS agreements and assess community-trust board effectiveness; if disputes arise over benefit-sharing interpretation or cultivar licensing, discuss arbitration costs and timeline impacts on breeding trials. (2) **Smallholder Adoption Uptake Realization**: report enrolment figures against the three scenarios (conservative, moderate, optimistic); if uptake is on track, confirm finance sufficiency; if shortfall, model reallocation to estate Hevea or alternative crops. (3) **Gate-Evidence Transparency and Auditor Independence**: review auditor access and any withheld data incidents; assess Dispute-Resolution Panel readiness for contested verdicts. (4) **Producer-Nation Protocol Adoption Progress**: report MoU signatures and inspector-hiring plans by producing countries; highlight any sovereignty objections or implementation delays and re-scope Phase 1 timeline if necessary. (5) **OEM Offtake Signals and Plant Finance**: present tire-qualification progress and cost-premium thresholds; discuss plant financing split (programme vs. OEM/project finance) and wave-1 plant decision readiness for Month 72 (2032-10-12).


## 4.4.A Issue - ABS and Community Benefit-Sharing Framework Lacks Enforceability and Durability Guarantees

The plan mandates Nagoya Protocol compliance and bilateral agreements with Brazil's CGen and three community groupings by Month 6 (2027-04-12), but provides no enforcement mechanism if promised benefit payments are withheld or if downstream cultivar commercialization bypasses community co-ownership. The proposal allocates only USD 15 million for ABS legal work (a single Month 6 = 2027-04-12 negotiation sprint), yet Nagoya-era precedent shows ABS disputes routinely extend 12–36 months and legal challenges cost USD 50–500 million. The community-governed data trust is mentioned but lacks binding legal seats, governance quorum rules, or veto power over cultivar commercialization. If benefit payments are delayed or communities perceive unfair terms, they can block germplasm export, cascading the breeding timeline from Month 84 (2033-10-12) to Month 96+ and stranding USD 5–8 billion in Year 7 gate capital.

### 4.4.B Tags

- ABS_enforceability
- community_governance_gaps
- benefit_tracking_weak
- legal_liability_unmanaged
- indigenous_rights_at_risk

### 4.4.C Mitigation

Hire specialized Nagoya Protocol counsel (track record: 15+ negotiated bilateral ABS agreements) by Month 1 (2026-11-12). Establish a community-co-governed benefit-sharing trust with binding legal seats (minimum 2 indigenous representatives with full governance veto on cultivar licensing), quarterly payment verification, and public ledger publication within 30 days of disbursement. Pre-register benefit-sharing formula by Month 6 (2027-04-12) (e.g., USD 2–5/hectare of deployed cultivar based on genealogy tracking) and lock into breeding partnership agreements. Allocate USD 20–30 million for ABS legal work, not USD 15 million. Require all breeding partners to guarantee royalty-free seed for smallholder adoption, enforceable via penalty (e.g., USD 2–5 million per violation) if commercialization circumvents community consent.

### 4.4.D Consequence

Without enforceability, ABS agreements become shelf documents. Communities can block germplasm export at Month 18–24 (2028-04-12 to 2028-10-12) (well into field trials), moving the Year 7 cultivar gate to Month 96–108 (2034-10-12 to 2035-10-12) and forcing Year 12 gate failure. Legal challenges to cultivar patents could cost USD 100–500 million in defense and settlement. Benefit-sharing disputes undermine the program's legitimacy with Amazonian communities and could trigger legislative action by Brazil or Peru to restrict future rubber-germplasm commercialization globally.

### 4.4.E Root Cause

The plan treats ABS as a Month 6 (2027-04-12) transaction (bilateral agreements signed) rather than a durable institutional framework requiring ongoing benefit verification, community board authority and legal recourse. The Nagoya Protocol allows communities to withdraw consent or challenge commercialization years after material transfer, but the plan does not budget for legal defense or establish a binding benefit-sharing ledger. No mechanism exists to prove payments are actually made to communities or tracked transparently, and the data trust is advisory rather than veto-holding.

## 4.5.A Issue - Smallholder Adoption Finance Design Conflates Income Bridging with Price-Floor Guarantees and Lacks Contingency for Uptake Shortfall

The plan allocates USD 6.75 billion for 'replant finance and income bridging' under a 45% adoption target (2.25 million hectares), but the design conflates three distinct instruments: (1) concessional credit for replanting, (2) income-bridging payments during 6–10 year immature periods, and (3) long-term price-floor guarantees. The plan specifies income bridging at 60–70% of median farm income over full immature periods (6–10 years), which on a 5 million hectare eligible base costs USD 9.0 billion (planning budget), yet the USD 6.75 billion line assumes 45% uptake. If uptake falls to the historical 20–40% baseline, the program either underfunds adoption support (creating 100,000+ farms in default) or reallocates USD 2.25–3.25 billion from other priorities. The plan lacks explicit contingency finance or decision triggers for uptake shortfall below 30% at Month 84 (2033-10-12).

### 4.5.B Tags

- smallholder_finance_design_conflates_instruments
- income_bridging_duration_unclear
- uptake_planning_optimistic
- default_risk_unmanaged
- adoption_waypoint_lacks_contingency

### 4.5.C Mitigation

By Month 6 (2027-04-12), publish three explicit adoption scenarios: conservative (30–40%, USD 4.5–6.0 billion finance required), moderate (40–50%, USD 6.0–7.5 billion), optimistic (60%+, USD 9.0 billion). For each scenario, specify: (a) concessional replant credit terms (repayment window, trigger: first-tapping yield over 2 t/ha dry rubber), (b) income-bridging duration (6–10 years post-replanting) at 60–70% of median local farm income, repaid only if yield targets are met, (c) price-floor guarantee (minimum 90% of Hevea benchmark for 10 years post-tapping), funded by a separate, protected USD 400 million line. Establish monthly default tracking and by Month 36 (2029-10-12), if default exceeds 20% in any country, trigger a review of extension quality and finance instrument redesign. Set Month 84 (2033-10-12) contingency: if enrolment falls below 30%, reallocate USD 0.8–1.2 billion from smallholder bridging to resistant-Hevea estate-scale trials and alternative-crop processing plants. Require cooperative and farmer association co-ownership of finance decisions (not top-down central management).

### 4.5.D Consequence

If the plan underfunds adoption support (USD 6.75 billion versus USD 9.0 billion actual need at 45% uptake), default rates will climb to 30–50% by Month 60 (2031-10-12), creating social backlash and abandonment of clean-plant programs. Conversely, if uptake reaches only 30%, the USD 6.75 billion line is oversized and locks capital that should redirect to breeding or processing. Without explicit contingency triggers, the program will face a Month 84 (2033-10-12) gate with either underfunded smallholders or misallocated capital, forcing a painful repriorization that damages credibility with funders and participating communities.

### 4.5.E Root Cause

The plan assumes 45% uptake without historical evidence and without separating the financial mechanics of (a) one-time replant credit, (b) multi-year income bridging, and (c) permanent price-floor guarantees. The USD 6.75 billion is a budget line, not a consequence of explicit financing terms, default assumptions, or contingency scenarios. The Month 84 (2033-10-12) adoption waypoint (30% target) mentions a 'stop trigger' below 30% but does not specify what reallocation, timeline compression or abandonment scenario follows.

## 4.6.A Issue - Independent Auditor Authority and Gate Verification Lack Binding Dispute-Resolution Mechanism for Contested Evidence

The plan specifies an independent auditor contracted by Month 3 (2027-01-12) with pre-registered scope by Month 6 (2027-04-12), but does not establish what happens if programme managers withhold unfavourable data (e.g., breeding-trial yield data showing >10% penalty) or if the auditor and programme leadership dispute gate readiness. The auditor's findings are published within 30 days, but there is no binding arbiter empowered to override programme management if they claim data access was incomplete or auditor scope was too narrow. Precedent from World Bank and Green Climate Fund gate mechanisms shows that disputed gate evidence routinely stalls capital release by 3–6 months (not verified), and if the dispute cannot be resolved, funding can be withheld indefinitely, creating USD 2–3 billion capital-flow delays. The plan mentions a 'Dispute-Resolution Adjudication Panel' but provides no legal charter, panel composition, funding or explicit binding authority over gate decisions.

### 4.6.B Tags

- auditor_independence_incomplete
- dispute_resolution_undefined
- gate_evidence_contestable
- capital_release_jeopardy
- programme_manager_data_withholding_risk

### 4.6.C Mitigation

By Month 1 (2026-11-12), establish an independent Dispute-Resolution Adjudication Panel with a published legal charter specifying: (a) composition (3 senior neutral figures: e.g., retired phytosanitary authority head, independent agronomist, financial auditor with no programme funding relationship); (b) binding authority: panel verdicts on gate status are final and override programme management or auditor disagreement; (c) process: either party (auditor or programme) may request adjudication within 14 days of audit conclusion; panel issues binding judgment within 60 days; (d) funding: USD 2–5 million annually, ring-fenced from programme budget. Include in auditor contract (by Month 3 = 2027-01-12) explicit data-access guarantees: programme must provide all trial databases, inspection records, benefit-sharing ledgers and smallholder records within 5 business days of request, or face penalties (1–2% of auditor fee per 5-day delay). Pre-register auditor scope and KPI definitions (Months 3–6 = 2027-01-12 to 2027-04-12) in a peer-reviewed protocol document, published and locked before any data collection. Require auditors to conduct multi-source verification (field 30–40%, database 40–50%, interviews 20–30%) to prevent single-source manipulation.

### 4.6.D Consequence

Without binding dispute resolution, contested gate evidence (e.g., breeding-trial yield data disputed between programme and auditor) stalls capital release by 3–6 months or longer. A delayed Year 7 gate moves cultivar deployment timelines by 12–18 months (estimate), compressing smallholder adoption windows and risking a cascading Year 12 gate failure. Alternatively, if programme management suppresses unfavourable data and auditors cannot appeal disputed verdicts, funders lose confidence in gate credibility, triggering sovereign or industry levy defections and withholding of USD 2–3 billion (estimated) in Year 7 tranches, stranding cultivar and adoption infrastructure.

### 4.6.E Root Cause

The plan assumes that independent auditors can compel data access and that gate evidence will be uncontested, but auditors depend on programme-supplied data sources and have no contractual recourse if access is delayed or partial. The proposed Dispute-Resolution Adjudication Panel is mentioned descriptively but has no legal charter, no funding, no defined composition, and no explicit binding power to override programme or auditor disagreements. Without this enforcement structure, gate decisions become subject to political pressure and data disputes rather than objective verification.

---

# 5 Expert: Alternative-Crop Agronomy and Processing Innovation Specialist

**Knowledge**: Guayule and Russian dandelion crop production, extraction chemistry, rubber processing, yield optimization, water management in arid zones, agronomic trial design, processing cost reduction

**Why**: The program's alternative-rubber pillar (USD 1.6 billion capex, 32,000 t/year by Month 192 = 2042-10-12, 0.2% market share) faces critical technical and cost gates. Month 48 (2030-10-12) feedstock-cost KPIs (Guayule USD 1.20/kg, dandelion USD 1.00/kg) and Month 60 (2031-10-12) go/no-go decision on wave 1 plant commitment depend on validated agronomic and processing data. Current base case shows operating shortfall of USD 9.6M/year even at a 10% premium; this expert validates cost KPIs, identifies processing innovations needed to close the gap, and assesses whether the pilot-loss/operating-shortfall line of USD 0.6B is sufficient.

**What**: Review the feedstock-cost projections for Guayule (Arizona/Mexico) and dandelion (Germany/Benelux) and validate against pilot data; assess extraction yield targets (85% Guayule, 80% dandelion) and quality-variance tolerance (±10%); identify cost-reduction levers in processing, transport or land prep; recommend whether wave 1 plant FID should be conditioned on Month 60 (2031-10-12) cost verification or whether an accelerated processing-R&D track is needed by Month 48 (2030-10-12).

**Skills**: Crop agronomics, pilot-scale extraction, industrial processing scale-up, cost engineering, water-use optimization, quality control, supply-chain logistics, risk assessment for crop and processing technology

**Search**: guayule processing innovation, dandelion rubber extraction, crop yield optimization, alternative rubber agronomy, processing cost reduction

## 5.1 Primary Actions

- By Month 3 (2027-01-12): Establish an independent Resistance Durability Oversight Panel (6 members: 2 perennial-crop breeders, 2 plant pathologists, 1 independent auditor, 1 ABS specialist) to pre-register breeding KPI definitions (yield ≥90% of elite clones, ≥3 independent resistance sources, lesion size <5mm) in a peer-reviewed protocol. Without pre-registered, unambiguous metrics, Year 7 cultivar readiness becomes auditor-contestable and smallholder adoption confidence collapses.
- By Month 6 (2027-04-12): Commission independent pilot-scale engineering assessments of Guayule and dandelion extraction (500 kg/day scale, 2 research facilities) to validate extraction yield, quality variance and cost assumptions. If extraction yield <75% or opex >USD 3.00/kg, commit USD 100–200M processing-innovation capital or reduce wave-2 plant targets by 50% (reallocate USD 0.8B to resistant-Hevea or containment).
- By Month 6 (2027-04-12): Conduct smallholder adoption willingness-to-pay and constraint analysis across 500–1,000 representative farms in top 5 producers. Calibrate three adoption scenarios (30%, 40%, 50%) with pre-allocated contingent tranches (USD 4.0B for 30%, USD 2.5B conditional on 40%, USD 0.25B fast-track). Define Month 84 (2033-10-12) stop-gate: if enrolment <25%, reallocate USD 1.5–2.0B from smallholder to estate-breeding or alternative-crop capacity.

## 5.2 Secondary Actions

- By Month 3 (2027-01-12): Establish ABS negotiation team (2 FTE) with monthly CGen and community-consultation milestone tracking; negotiate non-binding preliminary agreements to lock scope and benefit-sharing structure before formal application, reducing negotiation slippage risk from 12–24 months to <9 months.
- By Month 9 (2027-07-12): Develop Breeding Contingency Decision Paper pre-approving crown-budding as alternative if trials not planted by Month 15 (2028-01-12); identify backup germplasm sources (ex-situ collections) for parallel multiplication outside Brazil; establish Breeding Contingency Steering Group to accelerate decision-making if primary ABS pathway slips.
- By Month 9 (2027-07-12): Develop Extension Corps Workforce Plan specifying recruitment partnerships, 2-week training module, retention incentives (performance bonus, crop insurance, cooperative equity) and 15% turnover-replacement budget; commit USD 60–100M within the USD 400M extension stream for training infrastructure and staff-replacement pipeline.
- By Month 12 (2027-10-12): Finalize OEM Letters of Intent from ≥8 of top-10 tire makers; specify tire-qualification trial scope (tread wear ≥95% of Hevea, rolling resistance ±5%, wet braking ≥95%, 500,000 km road trial); assign 3 accredited independent test labs (TÜV, RAPRA, Smithers) with 36-month completion target (Months 12–48 = 2027-10-12 to 2030-10-12) to reduce OEM offtake uncertainty.
- By Month 12 (2027-10-12): Lock binding 25-year framework agreements with 5+ sovereign/MDB funders specifying gate-release mechanics (minimum 80% tranche on partial gate success, disbursement within 45 days), binding minimum-funding floors (no less than 80% of planned tranche), and penalties for early withdrawal before Month 120 (2036-10-12) to protect capital durability and reduce budget-cycle volatility risk.

## 5.3 Follow Up Consultation

At Month 6 (2027-04-12), reconvene to assess: (1) ABS negotiation trajectory and germplasm-transfer timeline impact on breeding-trial plant-by dates; (2) results of Guayule and dandelion extraction pilot assessments and revised unit-economics model; (3) smallholder adoption scenario calibration and contingent-tranche allocation decisions; (4) OEM feedback from Letters of Intent and tire-qualification trial readiness. Discuss crown-budding contingency trigger (if trials not planted by Month 15 = 2028-01-12) and processing-innovation capital commitment (if extraction KPIs missed). Reassess capital reallocation priorities within the USD 13.9B unallocated balance. At Month 12 (2027-10-12), review compliance with all three primary-action deadlines and adjust Phase 2 (Months 36–84 = 2029-10-12 to 2033-10-12) workstreams accordingly.

## 5.4.A Issue - Alternative-Rubber Processing Pathway Remains Technically Unvalidated and Economically Unviable

The plan commits USD 1.6 billion to eight commercial plants (8 × USD 200M capex) with a 32,000 t/year target by Month 192 (2042-10-12), yet processing is under-specified. Guayule and dandelion extraction chemistry differ fundamentally from Hevea latex; yields and cost targets (USD 1.20/kg feedstock, 85%+ extraction, USD 2.50/kg all-in opex) lack pilot-scale validation. The plan assumes USD 70.4M annual revenue at full operation versus USD 80M opex—a structural USD 9.6M annual shortfall—with no mechanism to close it. Tire-qualification trials (Months 12–48 = 2027-10-12 to 2030-10-12) are underspecified; OEM offtake at 10% premium is assumed without testing formulation compatibility or blending behaviour. No processing R&D budget is ringfenced; pilot-scale loss absorption is buried in a USD 0.6B line.

### 5.4.B Tags

- processing-tech-unvalidated
- unit-economics-unviable
- capital-stranded-risk
- oem-offtake-fragile

### 5.4.C Mitigation

By Month 9 (2027-07-12), commission independent engineering assessments of Guayule and dandelion extraction at 500 kg/day pilot scale at two certified research facilities (e.g., Fraunhofer IME for dandelion in Germany, AgriDias or Bridgestone Guayule Group for Guayule in Arizona). Report on extraction yield, quality variance, processing cost per kilogram and cost sensitivity to feedstock moisture and composition. Use pilot data to recompute the feedstock cost, extraction efficiency and opex KPIs in the Month 36 (2029-10-12) budget baseline. If extraction yield falls below 75% or opex exceeds USD 3.00/kg, trigger a re-scope decision at Month 48 (2030-10-12): either commit additional R&D capital (USD 100–200M) for processing innovation, or reduce the alternative-rubber target to 16,000 t/year (wave 1 only) and reallocate the USD 0.8B wave-2 capex to resistant-Hevea breeding or containment capacity.

### 5.4.D Consequence

Without validated processing chemistry and pilot-scale cost evidence, the eight-plant program remains a budgeting fiction. If Guayule extraction yields 75% instead of 85% and dandelion yields 70% instead of 80%, all-in opex rises to USD 3.10–3.30/kg, deepening the annual shortfall to USD 20–30M per plant. OEMs will not sign binding offtake without proof of tire-grade quality and formulation fit; Letters of Intent by Month 12 (2027-10-12) then become non-binding sales collateral, not commitments. Committed capital (USD 1.6B for plants plus USD 0.2B for pilots = USD 1.8B) cannot be recovered, stranding smallholder linkage finance and creating a Year 12 gate failure if alternative-rubber cost KPIs are missed.

### 5.4.E Root Cause

The plan inherited alternative-rubber as a portfolio hedge (Decision 3: Alternative Rubber Portfolio Breadth), but converted it to a commercial-scale deliverable (eight plants) without establishing pilot-scale proof of extraction chemistry, yield and cost. The budgeting assumes extraction yield at 85% (Guayule) and 80% (dandelion), but no operating plant data supports these figures for commercial scale. The economic model inverts backwards from a desired revenue to cost assumptions, not forwards from validated process data.

## 5.5.A Issue - Hevea Breeding Timeline Has No Margin for ABS Delays or Trial-Startup Friction; Year 7 Gate Is Jeopardised

The plan's critical path runs: ABS agreements concluded by Month 6 (2027-04-12) → seed-lot multiplication and quarantine clearance by Month 9 (2027-07-12) → field trials planted by Month 12 (2027-10-12) → first data harvest at Month 84 (2033-10-12) for the Year 7 cultivar-readiness gate. This assumes zero slippage across ABS negotiation, germplasm transfer, regulatory approval, nursery establishment and trial startup. Historical ABS negotiations in Nagoya-Protocol jurisdictions take 12–24 months; Brazil's CGen process alone averages 9–15 months per proposal. If germplasm transfer slips beyond Month 12 (2027-10-12), trials cannot be planted until Month 15–18 (2028-01-12 to 2028-04-12), moving the first 6-year data point to Month 90–96 (2034-10-12 to 2034-10-12), past the Year 7 gate deadline.

### 5.5.B Tags

- zero-schedule-slack
- abs-delay-cascade
- trial-startup-risk
- gate-readiness-threatened

### 5.5.C Mitigation

By Month 3 (2027-01-12), establish a dedicated ABS negotiation team (2 FTE) reporting to the Brazil breeding lead, with monthly milestone tracking against a published CGen submission calendar and community consultation schedule. Negotiate non-binding preliminary agreements with Brazil CGen and three community groups by Month 3 (2027-01-12), locking the scope and benefit-sharing structure before formal application. Identify and secure backup germplasm sources (e.g., ex-situ collections at Embrapa, IRRDB partners) that can be multiplied in parallel if primary germplasm transfer is delayed. By Month 9 (2027-07-12), have seed lots of primary and backup germplasm in quarantine at trial sites, cleared for field planting by Month 11 (2027-09-12). Establish a Breeding Contingency Steering Group (Decision 2 dependency) by Month 1 (2026-11-12), pre-approving crown-budding as an alternative if trials are not planted by Month 15 (2028-01-12), with a decision paper on the trade-off (reduced durability, lower yield confidence) ready by Month 18 (2028-04-12).

### 5.5.D Consequence

If ABS negotiations slip 6–12 months (plausible, not exceptional), the Year 7 gate moves from Month 84 (2033-10-12) to Month 90–96 (2034-10-12 to 2034-10-12), compressing the Phase 3 execution window (Months 84–144 = 2033-10-12 to 2038-10-12) from 60 months to 48–54 months. This pressure forces a choice: release cultivars with only 4–5 years of field durability data (gate-KPI threshold is 5+ field trials; proposal shows 5 as minimum), reducing Year 12 and Year 18 confidence; or miss the Year 7 gate entirely, withholding USD 6.5B (Year 7 gate tranche) and delaying smallholder adoption rollout from Month 84 (2033-10-12) to Month 96 (2034-10-12) or later. Smallholder adoption finance (USD 6.75B planned for Months 84–144 = 2033-10-12 to 2038-10-12) cannot start until cultivars are released, cascading delays across the entire Phase 3 timeline.

### 5.5.E Root Cause

The plan treats ABS agreements (Decision 6) as a technical checkbox but underestimates negotiation duration and regulatory friction. The 25-year program structure, gating at predictable intervals (Months 36, 84, 144, 216 = 2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12), creates a hard deadline that a perennial crop cannot recover from once missed. Breeding timelines are non-compressible; no amount of funding accelerates the 6–10 year cycle from planting to first significant disease-challenge data. The plan lacks contingency pathways (e.g., parallel fast-track via crown-budding, or advance germplasm multiplication outside Brazil) and has not pre-negotiated backup trial sites.

## 5.6.A Issue - Smallholder Adoption Finance and Extension Delivery Model Lacks Contingency for Low Uptake; 45% Target Rests on Unvalidated Adoption Economics

The plan budgets USD 6.75B for replanting and income-bridging finance, assuming 45% uptake across 5 million ha of eligible smallholder area (2.25 million ha adopted, USD 3,000/ha). However, historical uptake in similar contexts (improved Hevea clones, intercrop adoption in Indonesia, India, Nigeria) averages 20–40% over 10 years, not 45% over 12 years (Months 84–144 = 2033-10-12 to 2038-10-12). The plan specifies three scenarios (30–40% conservative, 40–50% moderate, 60%+ optimistic) but does not pre-commit finance or extension resources to each, nor does it define stop-triggers. If uptake falls to 30% by Month 84 (2033-10-12), the plan has no pre-agreed contingency: USD 2.0B of the USD 6.75B line becomes unneeded, but the plan does not specify whether capital is reallocated or withheld. Extension delivery is planned as 500 lead agents (200–500 smallholders each) plus 50–100 nurseries per country, yet no costing, recruitment plan or retention strategy is detailed. Turnover of 30–50% over 10 years (typical for rural extension in developing countries) is not budgeted.

### 5.6.B Tags

- adoption-target-optimistic
- finance-contingency-missing
- extension-delivery-unspecified
- capital-allocation-unclear

### 5.6.C Mitigation

By Month 6 (2027-04-12), conduct a structured smallholder adoption willingness-to-pay and constraint analysis across 500–1,000 representative farms in the top 5 producing countries, testing: (i) price premium accepted for resistant clones (target 0–30% above current); (ii) income-bridging repayment terms acceptable (e.g., 6-year grace, 10-year amortisation); (iii) key adoption barriers (access to credit, extension support, market certainty, disease risk perception). Use findings to calibrate the three adoption scenarios (conservative 30%, moderate 40%, optimistic 50%) with explicit contingency tranches: allocate USD 4.0B to conservative scenario (1.5M ha), USD 2.5B as contingent on moderate uptake reaching 2.0M ha by Month 108 (2035-10-12), and USD 0.25B as fast-track for zones showing >50% early adoption. By Month 9 (2027-07-12), establish an Extension Corps Workforce Plan specifying: (i) recruitment strategy and partner institutions (cooperatives, national research institutes) by country; (ii) 2-week training module on SALB symptoms, clean-plant handling and resistant-cultivar agronomy, delivered quarterly Months 12–84 (2027-10-12 to 2033-10-12); (iii) retention incentives (performance bonus, crop-insurance tie-in, cooperative equity) and turnover-replacement budget (assume 30% annual turnover, cost 15% of extension salary line). By Month 84 (2033-10-12), trigger an adoption stop-gate: if enrolment is below 25% of eligible smallholders, reduce Phase 4 (Months 144–216 = 2038-10-12 to 2044-10-12) adoption targets by 50%, reallocate USD 1.5–2.0B to resistant-Hevea breeding estate trials or alternative-crop processing capacity, and contract the extension corps by 30%.

### 5.6.D Consequence

Without validated adoption economics and contingency tranches, capital allocation becomes incoherent. If actual uptake is 30% by Month 84 (2033-10-12), the plan has USD 2.0B unspent and no clear reallocation path, while the extension corps continues operating at full cost (USD 400M over Months 84–144 = 2033-10-12 to 2038-10-12). Alternatively, if contingency tranches are not pre-allocated and uptake exceeds 50%, the plan lacks capital to finance adoption beyond Month 100 (2035-02-12), leaving smallholders without income bridging for years 8–10 of immature trees and forcing program visibility failures or emergency budget appeals. Extension turnover will reach 30–50% by Month 120 (2036-10-12), creating knowledge loss and regional coverage gaps; without explicit retention budgeting and training pipelines, new agents will not be trained in time, and uptake will collapse in underserved regions after Month 84 (2033-10-12).

### 5.6.E Root Cause

The plan establishes adoption as a pillar (Decision 7: Smallholder Transition Finance, Decision 14: Extension Corps) but treats it as execution detail rather than a strategic parameter that should gate capital allocation. The 45% target is not grounded in smallholder willingness-to-pay analysis, adoption-curve modelling or comparative case studies. The adoption-finance instrument (income bridging during immature period) is designed theoretically but lacks operational pilots or partner engagement to test grower acceptance, default risk and administrative cost. Extension delivery is modular (local cooperatives rather than centralised program employment) in principle, but the transition from current local capacity to 500 trained agents is not sequenced or resourced.

---

# 6 Expert: Smallholder Adoption and Rural Extension Program Design Specialist

**Knowledge**: Smallholder agriculture finance, extension-service delivery models, farmer behavior change, cooperative development, income-bridging instruments, adoption tracking, rural institutional sustainability, developing-country credit systems

**Why**: The plan's smallholder pillar is the largest cost (USD 6.75B for replant finance at 45% target uptake) and hinges on a 30-40% historical baseline. The pre-assessment flags adoption waypoints (Month 84 = 2033-10-12: 30% enrollment, Month 144 = 2038-10-12: 40% of area replanted) with stop triggers, but the extension/nursery stream (USD 400M over 25 years) and income-bridging design lack validated delivery models. This expert assesses the feasibility of 500 lead extension agents (200-500 smallholders each) and locally-owned nurseries, validates the income-bridging-finance structure (60-70% income replacement during immature period), and identifies institutional and financial risks to achieving the planning targets.

**What**: Review the proposed extension-delivery model (decentralized through cooperatives vs. centralized employment) and validate staffing targets and cost per farmer; assess income-bridging-finance design (duration, repayment triggers, default absorption) against comparable programs in Indonesia, Thailand, India; recommend scenario-based contingencies if adoption falls below 30% by Month 84 (2033-10-12), including fallback to estate-scale deployment; identify institutional risks to 25-year extension continuity and long-term cost.

**Skills**: Rural extension program design, smallholder credit and bridging-finance instruments, farmer-adoption dynamics, cooperative governance, monitoring and evaluation of adoption programs, rural institutional development, agricultural extension scaling

**Search**: smallholder extension programs, adoption finance, income-bridging agricultural credit, cooperative extension models, rural adoption monitoring

## 6.1 Primary Actions

- By Month 1 (2026-11-12): Hire specialized Access-and-Benefit-Sharing legal counsel (proven track record on 15+ Nagoya Protocol agreements) and recruit a dedicated Protocol Adoption Secretariat within FAO/IPPC with 3+ full-time policy coordinators. These two teams are the critical path for ABS and protocol execution.
- By Month 3 (2027-01-12): Contract an independent international auditor (consortium acceptable) with a written governance charter guaranteeing contractual data access within 5 business days and defining penalties (1-2% of fee per 5-day delay, estimated) for non-compliance. Simultaneously, establish an independent Dispute-Resolution Adjudication Panel (3 neutral figures, funded separately from contingency reserve) to issue binding judgment within 60 days if gates are contested.
- By Month 6 (2027-04-12): Execute bilateral Memoranda of Understanding with Brazil, Indonesia, Thailand, Malaysia, Vietnam, each committing to embed the SALB Containment Protocol in national phytosanitary legislation by Month 36 (2029-10-12), with named quarantine agencies, minimum 20 inspectors per country by Month 12 (2027-10-12), quarterly compliance reporting, and explicit penalties for non-adoption. Publish all MoU terms publicly. Simultaneously, execute ABS agreements with Brazil CGen and at least 3 Amazonian community groupings, with published benefit-sharing terms (USD 1-5 per ha, estimate) and community co-governance of data trust.
- By Month 12 (2027-10-12): Finalize legally binding 25-year framework agreements with sovereign and development-bank funders and the industry resilience levy agreement with tire makers and traders. Each agreement must specify gate-release tranches with minimum-funding floors (80% of planned amount on partial gate success, estimated), disbursement within 45 days of gate passage, and penalty for early withdrawal (5-10% of undisbursed tranche, estimated). Ring-fence the USD 4.5B contingency reserve with explicit governance rules.
- By Month 12 (2027-10-12): Plant multi-site field trials at 4 breeding hubs (Campinas, Serdang, Cote d'Ivoire, southern Thailand) with at least 2 hectares per cultivar, 3 replicates of 100+ trees, and pre-registered breeding KPI targets (yield ≥90% of elite, ≥2-3 stacked resistance sources, lesion <5mm). Establish Resistance Durability Oversight Panel (6 members: 2 breeders, 2 pathologists, 1 auditor, 1 ABS specialist) to oversee durability data and advise gate decisions.
- By Month 6 (2027-04-12): Define three explicit smallholder adoption scenarios (conservative 30-40%, moderate 40-50%, optimistic 60%+) with contingency finance attached to each. Set adoption waypoints at Months 36, 84, 144 (2029-10-12, 2033-10-12, 2038-10-12) with decision triggers: if enrollment falls below 30% by Month 84 (2033-10-12), reduce smallholder acreage targets by 30-40% and reallocate USD 800M-$1.2B to estate-scale trials and processing plants. Recruit 500 lead extension agents by Month 12 (2027-10-12), each serving 200-500 smallholders via locally owned nurseries (cooperatives, associations).

## 6.2 Secondary Actions

- By Month 3 (2027-01-12): Publish the IPPC-harmonized SALB Containment Protocol draft (nursery stock movement, research-material quarantine, equipment decontamination, red-team drill protocols) for IPPC working-group comment by Month 4 (2027-02-12), with formal IPPC adoption vote targeted for Month 36 (2029-10-12). Establish the monthly OEM Steering Committee with top 10 tire makers to align technology roadmap, offtake signals, and quality-specification feedback.
- By Month 6 (2027-04-12): Secure non-binding Letters of Intent from at least 8 of 10 OEMs, each committing to supply-chain trials of Guayule and dandelion rubber in 500,000+ tyres per year for 24 months, access to tire-testing facilities, price-signal feedback, and binding offtake negotiation start by Month 48 (2030-10-12). Launch parallel tire-performance qualification trials at 3 accredited labs (TÜV, RAPRA, Smithers) covering tread-wear, rolling resistance, wet braking, and durability.
- By Month 12 (2027-10-12): Establish 100 compliance inspectors (20 per top-5 producer) with 4-week training on phytosanitary inspection, SALB symptom recognition, and documentation; conflict-of-interest declarations; and mandatory 3-year rotation. Set up a mobile-phone-based anonymous reporting system enabling smallholders to report suspected violations with financial incentives (USD 10-50 per confirmed report, estimated), logged in a confidential database.
- By Month 24 (2028-10-12): Commission demonstration pilots of Guayule (2,000 t/year in Arizona/Mexico) and Russian dandelion (1,000 t/year in Germany/Benelux) with colocated processing. Establish at least 10 regional laboratories serving surveillance, diagnostics, and breeding for all major producers. Conduct first round of protocol-compliance red-team drills in 3 producing countries, testing inspector detection rates and response speed.
- By Month 48 (2030-10-12): Complete tire-performance qualification trials and compile results for OEM review. If breeding-trial yield penalty exceeds 15% (yield below 85% of elite clones), immediately approve a USD 0.25B crown-budding fast-track decision to deliver field protection via grafting resistant canopies onto elite clones by Month 54-60 (2031-04-12 to 2031-10-12), independent of multi-year breeding cycles.
- By Month 60 (2031-10-12): Decide between added processing-innovation capital or redirecting funds to resistant-Hevea breeding. Hold wave 1 commercial plant commitment only after this decision. Secure qualification-trial results from OEMs and finalize purchase-option contracts (1.5% annual reservation fee, estimated) for Month 84 (2033-10-12) offtake.
- By Month 84 (2033-10-12): Gate 2 (Year 7). Verify cultivar yield at 90%+ of elite clones with 3 stacked resistance sources across 4+ field trial sites. Verify alternative-rubber feedstock costs at or below Guayule USD 1.20/kg, dandelion USD 1.00/kg, with extraction yield 85%+ and quality variance within ±10%. Evaluate smallholder enrollment: if below 30% of eligible farmers, trigger contingency reallocation of USD 800M-$1.2B. Release Month 84 (2033-10-12) gate tranche (USD 6.5B deployable, minimum 80% on partial success, estimated).

## 6.3 Follow Up Consultation

Next session (Month 3, 2027-01-12): Review auditor governance charter, dispute-resolution panel charter, and data-access contract templates before Month 3 (2027-01-12) signing. Confirm IPPC draft is ready for working-group comment and MoU negotiation timelines with producing countries are on track. Validate OEM steering committee membership and tire-test lab contracts. Month 6 (2027-04-12): Confirm all bilateral MoUs and ABS agreements are executed with published terms; review breeding KPI targets and trial-site readiness; confirm extension-agent recruitment and smallholder adoption scenarios are finalized. Month 12 (2027-10-12): Verify framework funding agreements are legally binding with gate-release mechanics and minimum-funding floors; confirm trial planting is complete and Resistance Durability Oversight Panel is active; review inspector hiring and laboratory commissioning progress. Discuss any critical-path delays (ABS, MoUs, auditor independence) and contingency triggers for Month 18-24 (2028-04-12 to 2028-10-12) re-phasing or crown-budding activation.

## 6.4.A Issue - Producer-Nation Protocol Adoption Remains Unforced and Gate-Critical

The plan embeds the SALB Containment Protocol in the IPPC framework to gain legitimacy, but IPPC adoption is consensus-based with weak enforcement. Producer nations can delay or refuse binding national adoption indefinitely without jeopardizing their IPPC standing. The Month 36 (2029-10-12) gate criterion requires 'binding national embedding in at least 3 of top 5 producers,' but no enforcement mechanism or penalty is defined if fewer than 3 commit by Month 54 (2031-04-12). Without binding MoUs signed by Month 6 (2027-04-12) with explicit penalties for non-adoption, the protocol remains a shelf document. The Month 3 (2027-01-12) gate logic collapses if the protocol is not legally binding in the major producing countries.

### 6.4.B Tags

- protocol_legitimacy_vs_enforceability
- sovereign_delay_risk
- gate_logic_failure
- producer_commitment_gap

### 6.4.C Mitigation

Recruit a dedicated Protocol Adoption Secretariat within FAO/IPPC by Month 1 (2026-11-12) with 3+ full-time coordinators. Negotiate bilateral MoUs with Brazil, Indonesia, Thailand, Malaysia, Vietnam by Month 6 (2027-04-12), each specifying exact protocol provisions, named quarantine agencies, quarterly reporting, and minimum 20 inspectors per country by Month 12 (2027-10-12). Include explicit penalties for non-adoption. Publish the IPPC-harmonized draft by Month 3 (2027-01-12) for working-group comment; target formal IPPC vote by Month 36 (2029-10-12). Set a hard stop-trigger: if fewer than 3 of top 5 have binding adoption by Month 54 (2031-04-12), re-scope Phase 2 or defer to Month 96 (2034-10-12). Publish all MoU terms and compliance metrics publicly to deter backsliding.

### 6.4.D Consequence

Without binding producer commitments, the containment protocol is unenforceable, making the Month 36 (2029-10-12) gate meaningless. SALB spread via contaminated nursery stock cannot be contained. Smallholder adoption confidence collapses if the protocol is not credible. The entire gate logic—which allocates USD 25.5B deployable capital based on verified containment—fails, orphaning USD 7.0B+ at the Year 3 gate and cascading delays to breeding and alternative-crop gates. Estimated loss: 6-18 month delays, cascading $2-3 billion in stranded capital.

### 6.4.E Root Cause

The plan assumes producer nations will adopt the protocol through IPPC consensus without explicit bilateral commitment or enforcement mechanisms. It treats legitimacy (IPPC embedding) as sufficient without addressing the enforceability gap. No contingency is defined if fewer than 3 of top 5 commit on time. The Pragmatic Foundation scenario chooses IPPC legitimacy over a purpose-built authority with inspection powers, but does not foreclose the enforceability risk if producers do not follow through.

## 6.5.A Issue - Breeding Timeline Has Zero Slack to the Year 7 Gate; ABS Delays Cascade Irreversibly

The plan requires cultivars at 90%+ of elite-clone yield with 3 stacked resistance sources by Month 84 (2033-10-12). Field trials must be planted by Month 12 (2027-10-12) to yield the first 6-year cycle data by Month 84 (2033-10-12). Any slip in ABS agreement execution beyond Month 12 (2027-10-12) moves the trial planting from Month 12 (2027-10-12) to Month 18-24 (2028-04-12 to 2028-10-12), which compresses first-cycle data to Month 90-96 (May-October 2034). This pushes the Year 7 gate to Month 96 (2034-10-12) or later. The plan acknowledges 'zero slack,' but has no contingency if ABS negotiations with Brazil CGen and Amazonian communities slip beyond Month 6 (2027-04-12). The canonical fact states the ABS line is USD 0.4B, yet detailed ABS consulting and community-benefit costs are not itemized, and the risk of legal challenges is capped at USD 100-500M with no mitigation plan.

### 6.5.B Tags

- breeding_timeline_slack_zero
- abs_delay_cascade
- legal_challenge_unmitigated
- perennial_crop_biology_constraint

### 6.5.C Mitigation

Hire specialized ABS legal counsel by Month 1 (2026-11-12) with proven track record on 15+ Nagoya Protocol agreements. Begin bilateral negotiations with Brazil CGen and 3 Amazonian community groupings in parallel, not sequentially, by Month 1 (2026-11-12). Execute agreements by Month 6 (2027-04-12), or trigger a contingency: if Month 6 (2027-04-12) is missed, immediately approve a USD 0.25B crown-budding fast-track (grafting resistant canopies onto elite clones using existing material) to deliver field protection by Month 54-60 (2031-04-12 to 2031-10-12), independent of breeding cycle delays. Publish all ABS terms and benefit-sharing ledgers publicly by Month 12 (2027-10-12) to pre-empt legal challenges. Establish a community-governed data trust with indigenous seats to share governance of sequence-data use and commercial benefit-sharing. Set aside USD 20-30M for contingent dispute resolution. If ABS slips beyond Month 12 (2027-10-12), re-phase the Year 7 gate to Month 96 (2034-10-12) or activate the crown-budding pathway.

### 6.5.D Consequence

If ABS agreements slip beyond Month 12 (2027-10-12), trial planting is compressed from Month 12 (2027-10-12) to Month 18-24 (2028-04-12 to 2028-10-12), moving the first 6-year data from Month 84 (2033-10-12) to Month 90-96 (2034-04-12 to 2034-10-12). The Year 7 gate is missed. Cultivar readiness evidence is unavailable for the Month 84 (2033-10-12) gate decision, which triggers 80% minimum-release of Year 7 tranches (USD 5.2B estimated) based on incomplete data, or funders withhold capital pending clarity. Smallholder adoption confidence collapses without cultivar readiness. Breeding capital becomes stranded ($0.4B), and the alternative-rubber timeline accelerates to compensate, overloading processing-plant startup risk. Legal challenge risk (USD 100-500M estimated) is realized if communities or Brazil perceive benefit-sharing as unfair and block cultivar commercialization.

### 6.5.E Root Cause

The plan prioritizes IPPC-embedded protocol legitimacy and conventional breeding to avoid regulatory exposure, but commits to a 6-month ABS negotiation window (Month 1-6 = 2026-11-12 to 2027-04-12) with no parallel or contingent path. Perennial crop biology permits no compression: 6-year field cycles are inviolable. The plan acknowledges zero slack but does not operationalize contingency triggers or allocate crown-budding capital in advance. The canonical budget line of USD 0.4B for breeding/ABS is underbaked relative to the legal and consulting costs required to close ABS disputes in real time.

## 6.6.A Issue - Gate Verification Regime Depends on Auditor Data Access That Is Not Contractually Guaranteed; Gate Credibility Is Contestable

The plan specifies an independent auditor contracted by Month 3 (2027-01-12), with pre-registered scope by Month 6 (2027-04-12), and binding 60-day adjudication if gates are disputed. However, the auditor's access to data is conditional on compliance from the same program managers and national agencies being audited. No contract clause guarantees data access within a fixed timeframe or defines penalties for non-disclosure. Historical precedent from agricultural monitoring systems shows that programme teams withhold unfavourable breeding or surveillance data to avoid gate delays, and auditors have no recourse. The plan allocates USD 30-50M for verification (estimate) but does not specify auditor independence from funder and national-agency influence, nor does it define how the Dispute-Resolution Adjudication Panel is funded or insulated from funder pressure. Without contractually guaranteed data access and clear penalties for non-compliance, the Month 84 (2033-10-12) gate (cultivar readiness, alternative-rubber cost) becomes auditor-contestable, risking $2-3 billion in capital allocation disputes.

### 6.6.B Tags

- auditor_data_access_unforced
- gate_verification_credibility_gap
- programme_team_incentive_misalignment
- adjudication_panel_independence_undefined

### 6.6.C Mitigation

By Month 3 (2027-01-12), contract the independent auditor with a written governance charter specifying: (i) all data—trial databases, inspection records, benefit-sharing ledgers, smallholder adoption records—must be provided within 5 business days of audit request, with penalties (1-2% of auditor fee per 5-day delay, estimated) for non-compliance by programme management or national partners; (ii) auditor scope and KPI definitions for all four gates pre-approved by funders and programme leadership by Month 6 (2027-04-12) in a published peer-reviewed protocol; (iii) multi-source verification: field visits (30-40% weight), database audits (40-50%), independent farmer/estate interviews (20-30%) per gate; (iv) verdicts published within 30 days of audit conclusion, with supporting evidence and auditor reasoning; (v) auditor institution geographically and institutionally separate from programme management and national agencies. Establish the Dispute-Resolution Adjudication Panel (Month 3 = 2027-01-12) as a binding third party: 3 neutral figures (retired phytosanitary authority, independent agronomist, financial auditor), issuing judgment within 60 days if programme and auditors dispute gate status. Fund the Panel separately (USD 2-5M per gate, estimate) from contingency reserve, not from programme operating budget. Publish all auditor data-access penalties and dispute-resolution decisions publicly.

### 6.6.D Consequence

Without contractual data-access guarantees, programme managers can delay or withhold unfavourable breeding-trial results (e.g., yield penalties >10%, resistance breakdown) to avoid gate delays. The auditor cannot independently verify claims and issues conditional gate verdicts. At Month 84 (2033-10-12), if breeding data show yield penalties of 5-10% (marginal pass) or cost KPIs miss targets, the Dispute-Resolution Panel must arbitrate whether 80% of Year 7 tranches (USD 5.2B estimated) are released. Political pressure from funders and programme leadership influences Panel judgment. Smallholder adoption strategy depends on cultivar readiness; if gates are contested, finance is withheld, and adoption momentum stalls. Estimated consequence: 3-6 month gate decision delays, $1-2 billion in contentious capital allocation, and loss of funder and grower confidence in programme credibility.

### 6.6.E Root Cause

The plan assumes auditor independence and data availability without contractual enforcement. It treats auditor integrity and programme transparency as voluntary rather than mandatory. The Pragmatic Foundation chooses independent auditing to strengthen gate credibility, but does not operationalize penalties for data non-compliance or insulate the adjudication panel from funder influence. The governance charter and data-access contract are not in scope as of Month 0 (2026-10-12); they are deferred to Month 3-6 (2027-01-12 to 2027-04-12) without contingency. The plan allocates USD 30-50M for auditing (estimate) but does not clarify whether this covers independent data-audit infrastructure, panel funding, or dispute-resolution processes.

---

# 7 Expert: OEM Supply-Chain Resilience and Tire-Performance Qualification Expert

**Knowledge**: Tire manufacturing, natural rubber specifications, supply-chain procurement, alternative rubber qualification, OEM sourcing strategy, tire-performance testing, risk management in supply chains

**Why**: Alternative rubber and resistant-Hevea commercial viability depend on firm OEM offtake. The plan targets letters of intent from 8 of 10 OEMs by Month 12 (2027-10-12) and purchase-option contracts by Month 48-60 (2030-10-12 to 2031-10-12), but the tire-performance qualification trials (Month 12-48 = 2027-10-12 to 2030-10-12) and price-signal feedback are undocumented. The expert assesses OEM appetite for premium offtake, validates tire-performance thresholds (tread wear 95% of Hevea, rolling resistance ±5%, wet braking ≥95%), and identifies commercial barriers to procurement commitments that could strand processing plants.

**What**: Engage top-10 OEMs (Bridgestone, Goodyear, Michelin, Continental, Sumitomo, Yokohama, Pirelli, Hankook, Cooper, Toyo) to validate supply-chain procurement criteria for Guayule and dandelion rubber; design tire-performance qualification protocol (test labs, duration, pass/fail criteria); assess realistic maximum acceptable premium above Hevea benchmark at each gate (Year 3, 7, 12, 18); recommend binding offtake framework for Month 48-60 (2030-10-12 to 2031-10-12) decision.

**Skills**: OEM procurement and supply-chain strategy, tire formulation and testing, natural rubber specifications and quality control, alternative material qualification, supply-chain risk and resilience, commercial negotiation and contracting

**Search**: OEM natural rubber procurement, tire qualification standards, alternative rubber supply chain, procurement resilience, rubber material specifications

## 7.1 Primary Actions

- Execute binding bilateral MoUs with Brazil, Indonesia, Thailand, Malaysia, and Vietnam by Month 6 (2027-04-12), each specifying: (i) named national quarantine agency responsible for protocol embedding; (ii) minimum 20 inspectors hired by Month 12 (2027-10-12); (iii) quarterly compliance reporting; (iv) financial penalties for non-adoption (loss of gate tranches, public listing). Establish an independent Compliance Secretariat (separate from programme management) to audit national embedding and publish monthly compliance scorecards. If fewer than 3 of top 5 have binding adoption by Month 54 (2031-04-12), trigger re-scoping: shrink protocol scope to compliant nations or defer Year 3 gate to Month 48 (2030-10-12).
- Secure ABS agreements with Brazil CGen and at least 3 Amazonian community groupings, and germplasm transfer, completed by Month 6 (2027-04-12). Pre-commit to crown-budding fast-track (USD 0.25B, fits within unallocated USD 13.9B balance) as a trigger-ready hedge if Month 12 (2027-10-12) trial-planting misses. Establish a Resistance Durability Oversight Panel by Month 1 (2026-11-12); panel monitors trial establishment and recommends Month 48 (2030-10-12) go/no-go on crown-budding activation. Document baseline timeline: ABS 4 weeks, germplasm shipment 8 weeks, trial setup 4 weeks; any slip >8 weeks triggers fast-track decision.
- Commission independent cost-down roadmap from 3 technology partners by Month 6 (2027-04-12) with milestone targets: feedstock cost USD 1.00/kg (dandelion) and USD 1.20/kg (guayule) by Month 48 (2030-10-12); extraction yield 85%+ by Month 60 (2031-10-12); all-in processing USD 1.80/kg by Month 144 (2038-10-12). Allocate USD 0.15–0.20B processing R&D within the USD 2.4B alternative-rubber line. Stage wave 1 plant FID to Month 60 (2031-10-12) only after cost targets are verified met. If targets are missed, reallocate wave 1 USD 0.8B to resistant-Hevea breeding and defer commercial plants as a lower-priority hedge.
- Secure non-binding Letters of Intent from at least 8 of 10 OEMs by Month 12 (2027-10-12), each committing to supply-chain trials of 250,000–500,000 tyres/year of Guayule or dandelion rubber for 24 months with phased premium decline: 10% Year 12, 5% Year 18, 0% Year 24. Launch tire-performance qualification trials at 3 independent labs by Month 12 (2027-10-12); target completion by Month 48 (2030-10-12). Publish qualification results by Month 60 (2031-10-12) to support plant financing decisions.
- Establish binding 25-year framework agreements with sovereign and multilateral development-bank funders by Month 12 (2027-10-12), specifying: (i) committed capital tranches with binding minimum-funding floors (at least 80% of planned tranche if gate is partially met); (ii) capital disbursement within 45 days of gate passage, independent of annual budget cycles; (iii) force-majeure clause limited to documented external shocks; (iv) 5–10% penalty for funder withdrawal before Month 120 (2036-10-12) without documented force majeure. Establish industry-levy agreement (0.75% of natural-rubber purchases) with ring-fenced governance outside annual budget cycles. Secure at least 5 sovereign or institutional funders, none above 20% (USD 6.0B each).
- Contract independent international auditor by Month 3 (2027-01-12) and establish a Dispute-Resolution Adjudication Panel (3 neutral senior figures) by Month 3 (2027-01-12). Pre-register audit scope and KPI definitions for all four gates by Month 6 (2027-04-12), published for funder and stakeholder review. Require contractual data access within 5 business days of audit request, with penalties (financial withholding of 1–2% of auditor fee per 5-day delay) for non-compliance by programme management or national partners. Ensure auditor independence: geographically and institutionally separate from programme management; multi-source verification weighting field 30–40%, database 40–50%, interviews 20–30%; all gate verdicts published within 30 days with supporting evidence.

## 7.2 Secondary Actions

- By Month 6 (2027-04-12), establish a Smallholder Adoption Working Group and define three adoption scenarios (conservative 30–40%, moderate 40–50%, optimistic 60%+) with explicit finance and extension commitments attached. Model scenario sensitivity: each 10% shortfall below 60% reduces cultivar acreage by 5–7% and defers risk reduction 2–3 years. Set adoption KPI waypoints at Months 36, 84, 144 (2029-10-12, 2033-10-12, 2038-10-12); if adoption falls below 30% by Month 84 (2033-10-12), reallocate USD 800M–1.2B from smallholder replanting to estate-scale Hevea trials and alternative-crop processing.
- Recruit and deploy 500 lead extension agents across the top five producers by Month 12 (2027-10-12), paired with locally owned nurseries (cooperatives, farmer associations). Require 2-week in-person training on SALB symptom identification and clean-plant handling by Month 9 (2027-07-12); mobile-phone attestation system for lot tracking; quarterly performance reviews tied to smallholder enrollment. Establish income-bridging finance as a protected 25-year stream (USD 300–500M), locally managed through cooperatives. Define: (i) duration covering full immature period (6–10 years) at 60–70% of median farm income; (ii) conditions tied to extension participation and clean-plant uptake; (iii) repayment triggered only if first-tapping yield exceeds 2 tonnes/year; (iv) programme absorbs first 10–15% annual default rate per country.
- By Month 3 (2027-01-12), staff a dedicated Protocol Adoption Secretariat within FAO/IPPC with at least 3 full-time policy coordinators and 1 phytosanitary standard-writer. Publish IPPC-harmonized SALB Containment Protocol draft by Month 3 (2027-01-12); circulate for IPPC working-group comment Months 3–4 (2027-01-12 to 2027-02-12); target formal IPPC adoption vote by Month 36 (2029-10-12). Protocol scope: nursery stock movement, research-material quarantine, equipment decontamination, red-team drill protocols, penalty schedule for violations (nursery fine EUR 5,000–50,000, equipment fine EUR 2,000–10,000, infection concealment EUR 10,000–100,000, public listing for 24 months).
- By Month 6 (2027-04-12), hire specialised Access-and-Benefit-Sharing legal counsel with proven Nagoya Protocol negotiation track record. Execute bilateral ABS agreements with Brazil CGen and 3+ Amazonian community groupings specifying: (i) genealogy-tracked benefit-sharing (USD 1–5/ha of commercial cultivar); (ii) open-access sequence-data publication within 12 months; (iii) royalty-free seed for smallholders, royalty-bearing only for industrial users; (iv) independent mediator for dispute resolution (90-day resolution timeline). Establish community-governed data trust with 2+ indigenous or traditional-community seats overseeing quarterly benefit-sharing verification and annual transparent reporting.
- By Month 12 (2027-10-12), establish 100 compliance inspectors (20 per top-5 producer) and deploy 500 lead extension agents. Require 4-week initial training on phytosanitary inspection, SALB symptom recognition, documentation standards; mandatory rotation every 3 years; annual certification renewal on audit of 50 inspection lots (≥95% contamination-detection accuracy). Launch anonymous mobile reporting system (EUR 10–50 per confirmed report, paid within 30 days) enabling smallholders to report protocol violations; at least 2 reports/month per country trigger surprise inspection within 14 days.
- By Month 24 (2028-10-12), commission at least 10 regional laboratories serving surveillance, diagnostics, and breeding across all producing regions. Each lab requires: SALB PCR capability (24-hour turnaround), inoculum culture for resistance testing, basic genomic sequencing (SNP genotyping for cultivar tracking). Establish quality-assurance ring trials across labs (proficiency testing quarterly, published results). Cost: estimated USD 1–2M per lab per year (consumables, staffing, maintenance).
- Conduct protocol-compliance red-team drills in at least 3 producing countries in Months 18–36 (2028-04-12 to 2029-10-12), in which external security or auditor teams attempt to move potentially contaminated material through supply chains with unmarked or falsified clean-plant certificates. Test inspector detection rates, documentation scrutiny, response speed. Publish results transparently; deficient regions receive remedial inspector training by Month 42 (2030-04-12). Target: ≥95% detection accuracy across all drills.
- Allocate the USD 13.9B unallocated gate-conditional balance by Month 6 (2027-04-12), with priority to: surveillance capacity (USD 0.5B), breeding and trial expansion (USD 0.3–0.5B), alternative-crop processing R&D (USD 0.15–0.20B), extension-nursery surge (USD 0.2–0.3B), smallholder adoption contingency (USD 1.0–1.5B). Hold USD 3–4B for contingency capital calls and late-stage alternative-crop investments. Publish budget-allocation decision and spending plan by Month 12 (2027-10-12).
- Establish monthly OEM Steering Committee by Month 3 (2027-01-12) with representatives from top 10 tire makers (Bridgestone, Goodyear, Michelin, Continental, Sumitomo, Yokohama, Pirelli, Hankook, Cooper, Toyo) at executive level (VP Supply Chain or equivalent). Committee scope: technology roadmap alignment, supply-chain trial results, quality-specification feedback, price-signal refinement. Publish OEM engagement milestones monthly; tie programme messaging to demonstrated industry commitment.

## 7.3 Follow Up Consultation

At Month 6 (2027-04-12), review MoU execution status with all producers (signature, penalty language, inspector hire commitments); ABS agreement signatures and germplasm-transfer timelines; OEM letters of intent and qualification trial launch status; funding framework agreement negotiation progress (especially multilateral development banks and India/Indonesia sovereign pledges); alternative-rubber cost-down roadmap completion and technology-partner selection; and auditor contract terms and data-access guarantees. Confirm crown-budding fast-track pre-decision status: if Month 6 (2027-04-12) trial-establishment status is green (on-time germplasm arrival, site prep complete), defer fast-track activation; if amber (8+ week slip), prepare Month 18 (2028-04-12) fast-track decision paper. At Month 12 (2027-10-12), hold a full portfolio gate to confirm: (i) binding framework agreements signed with minimum-funding floors locked; (ii) at least 3 MoU signatories with legislated embedding timelines and inspector-hire progress on schedule; (iii) ABS agreements executed and germplasm in field trials; (iv) at least 8 OEM LoIs signed with qualification trials underway; (v) independent auditor fully contracted with scope published; (vi) USD 13.9B allocation decided and communicated; (vii) 500 extension agents and 100 inspectors recruited or in-pipeline. If any element is misaligned, activate contingency: defer Year 3 gate to Month 48 (2030-10-12), activate crown-budding by Month 18 (2028-04-12), or shrink protocol scope to 3-nation pilot.

## 7.4.A Issue - Critical Timeline Compression: Zero Breeding-Cycle Slack to Year 7 Gate Invalidates Perennial-Crop Biology

The plan schedules field trials planted by Month 12 (2027-10-12) to yield cultivar-readiness evidence at Month 84 (2033-10-12)—exactly 6 years, matching the minimum Hevea productive cycle but allowing zero margin for ABS delays, trial-site establishment lag, or pathogen variability. Any slip beyond Month 12 (2027-10-12) in ABS agreement closure or germplasm transfer cascades the Year 7 gate to Month 96 (2034-10-12) or later, compressing cultivar deployment and stranding smallholder adoption. The plan acknowledges zero slack but does not pre-commit to fast-track alternatives if the baseline slips. Perennial breeding cannot be accelerated; this is a fundamental constraint, not a risk to manage.

### 7.4.B Tags

- timeline_compression
- zero_margin_error
- perennial_crop_biology
- cascade_failure_risk

### 7.4.C Mitigation

By Month 6 (2027-04-12), execute ABS agreements and germplasm-transfer protocols with named Brazil CGen and community contacts; pre-commit to crown-budding fast-track (USD 0.25B) as a trigger-ready hedge if Month 12 (2027-10-12) trial-planting misses. Establish a Resistance Durability Oversight Panel by Month 1 (2026-11-12) to monitor trial establishment and recommend Month 48 (2030-10-12) go/no-go on crown-budding. Document baseline assumptions: 4-week ABS negotiation, 8-week germplasm shipment, 4-week trial establishment = 16 weeks pre-planting; any slip >8 weeks triggers hedge-decision activation.

### 7.4.D Consequence

Without fast-track alternatives locked in advance, a 6-month ABS slip moves the Year 7 gate to Month 96 (2034-10-12), leaving only 48 months for cultivar deployment before Year 12 gate (Month 144 = 2038-10-12). This compresses smallholder replanting to 2–3 years at hectares/year, pushing adoption below 30% and invalidating the 45% planning target. Funding cascades compress: Year 7 tranche (USD 6.5B) is withheld pending delayed cultivar evidence, stranding nursery and extension infrastructure and risking staff attrition.

### 7.4.E Root Cause

The plan conflates 'non-negotiable Phase 1 protocol' (Months 0–36 = 2026-10-12 to 2029-10-12, achievable) with 'fast cultivar readiness' (Month 84 = 2033-10-12, perennial-crop biology). Breeding cycles cannot be accelerated. ABS negotiation timelines are historically 12–24 months in similar cases; the 6-month assumption is optimistic. No explicit fallback decision criterion (e.g., 'if Month 12 = 2027-10-12 planting misses, activate crown-budding by Month 18 = 2028-04-12') exists to protect the gate logic.

## 7.5.A Issue - Unresolved Institutional Risk: Producer-Nation Protocol Adoption MoUs Are Not Binding Commitments to Enforce

The plan embeds the SALB Containment Protocol in the IPPC framework and requires producer-nation MoUs by Month 6 (2027-04-12), yet the MoU structure conflates signing with enforcement. IPPC standards are consensus-based and advisory; embedding does not guarantee national legislation or inspector hire. The plan specifies 'binding MoU' but does not define penalty for non-adoption or non-compliance. Indonesia, Thailand, and Malaysia have delayed phytosanitary regulation adoption for years. Without contractual penalties (e.g., loss of gate-conditional funding, trade sanctions) or third-party audit of compliance, the Month 36 (2029-10-12) gate criterion 'binding national embedding in at least 3 of top 5 producers' becomes unverifiable and politically contestable. The protocol may be published but not enforced, leaving surveillance and incursion response toothless.

### 7.5.B Tags

- institutional_legitimacy
- enforcement_gap
- sovereign_sovereignty
- unverifiable_gate_criterion

### 7.5.C Mitigation

By Month 6 (2027-04-12), structure bilateral MoUs with explicit penalty schedules: (i) signatory nation commits to legislate the protocol within 36 months; (ii) named national quarantine agency hires 20+ inspectors per country by Month 12 (2027-10-12); (iii) quarterly compliance reports on inspections, penalty enforcement, and budget allocation due within 30 days; (iv) non-compliance penalties include loss of gate-conditional funding tranches (1–2% per quarter of delay) and public listing of violating nation. Establish an independent Compliance Secretariat (separate from programme management) to audit national embedding; publish compliance scorecard monthly. If fewer than 3 of top 5 have binding adoption by Month 54 (2031-04-12), trigger re-scoping: shrink protocol scope to the 3 nations that adopted, or postpone Year 3 gate to Month 48 (2030-10-12) to allow later adopters 12+ months grace.

### 7.5.D Consequence

Without enforced MoU penalties, protocol adoption stalls at signature (2027–2028) without legislation or inspector hire. By Month 36 (2029-10-12) gate, only 1–2 nations have embedded the protocol in law; gate criterion is unmet. Containment authority is undefined; surveillance has no mandate to act on findings. SALB incursion in a partially-compliant region spreads uncontained; isolation of Phase 1 (Months 0–36 = 2026-10-12 to 2029-10-12) from scaling fails. Funding gate becomes contentious; auditors cannot verify containment performance against the unmet criterion, and funders withhold tranches pending 'clarification.' Year 3 gate is deferred to Month 48 (2030-10-12) or later, compressing Phases 2–4.

### 7.5.E Root Cause

The plan assumes IPPC embedding is sufficient legitimacy for national adoption, but IPPC is advisory; nations do not ratify IPPC standards as domestic law without separate legislative action. The plan does not specify who audits compliance or what penalty deters non-adoption. 'Binding MoU' is stated but not legally defined (penalty for breach? arbitration venue? enforcement agency?). No fallback to smaller coalitions (e.g., Brazil + Indonesia + Thailand as a 3-nation pilot) exists if larger adoption stalls.

## 7.6.A Issue - Alternative-Rubber Economics Remain Fundamentally Unviable; 32,000 t/year Output Is De Minimis (0.2% of Market) and Operating Shortfall Cannot Close by Year 18

The plan commits USD 1.6B plant capex to deliver 32,000 t/year of alternative rubber (Guayule + dandelion) by Month 192 (2042-10-12)—about 0.2% of the ~14 Mt/year global market. At the planned 10% premium over Hevea (USD 2.20/kg vs. USD 2.00/kg), revenue is USD 70.4M/year; operating cost is USD 80.0M/year (USD 2.50/kg all-in), yielding a USD 9.6M annual shortfall. Processing innovation could narrow this gap, but the plan does not commit capital to it or define cost-reduction milestones beyond the Month 48 (2030-10-12) feedstock-cost KPI. Without resolved unit economics, plant financing cannot close; senior lenders see negative DSCR even at 50% debt. The plan counts the full USD 1.6B as programme-financed, yet the budget line for loss cover is only USD 0.6B (cumulative to Month 300), creating a USD 1.0B+ shortfall if plants operate for their full 20+ year life. OEM offtake is conditional on qualification (Months 12–48, 2027-10-12 to 2030-10-12), but tire makers have shown limited premium tolerance in practice.

### 7.6.B Tags

- unit_economics_unviable
- cost_structure_misalignment
- financing_gap
- volume_de_minimis
- premium_unproven

### 7.6.C Mitigation

By Month 6 (2027-04-12), commission an independent cost-down roadmap from 3 competing technology partners (e.g., Fraunhofer IME dandelion, Bridgestone guayule, academic lab partnership) with milestone-based targets: feedstock cost USD 1.00/kg (dandelion) and USD 1.20/kg (guayule) by Month 48 (2030-10-12), extraction yield 85%+ by Month 60 (2031-10-12), all-in processing cost USD 1.80/kg by Month 144 (2038-10-12). Fund USD 0.15–0.20B in processing R&D (e.g., enzymatic extraction, continuous reactors) as a dedicated line within the USD 2.4B alternative-rubber allocation. Secure OEM tier commitments (not just LoIs) by Month 24 (2028-10-12): each OEM pre-commits to qualifying 250,000–500,000 tyres/year of dandelion or guayule rubber at a phased-down premium (10% Year 12, 5% Year 18, 0% Year 24). Stage plant capex: wave 1 FID only after Month 60 (2031-10-12) cost targets are met; if they are missed, reallocate wave 1 USD 0.8B to resistant-Hevea breeding and defer commercial plants to Month 192 (2042-10-12) as a lower-priority hedge.

### 7.6.D Consequence

Without resolved unit economics and locked OEM offtake, plants cannot secure project finance; the programme absorbs USD 1.6B capex and USD 10M/year operating shortfalls indefinitely. If OEM premium commitment falls below 8% or volume below 80% of nameplate, plants run at losses; the programme's loss-cover line (USD 0.6B) is exhausted by Year 8 (Month 96, 2034-10-12), triggering further capital calls outside the USD 30B cap. By Month 144 (2038-10-12) Year 12 gate, the cost/quality KPI ('delivered cost under 30% above Hevea') is unmet; gate is failed or conditional, withholding Year 12 tranche (USD 4.5B). Smallholder adoption of alternative crops stalls (planned volume is only 10,000–15,000 ha of the 5M ha eligible area); the diversification narrative collapses, and $2–3B in alternative-crop acreage and supply-chain infrastructure is written off.

### 7.6.E Root Cause

The plan separates economics from capacity planning: it commits USD 1.6B to plants without a prior commitment to cost reduction or OEM offtake credibility. The Hevea benchmark (USD 2.00/kg) may be outdated (2022–2026 range USD 1.50–2.50/kg); premium tolerance is assumed at 10% without market testing. Alternative-rubber scale (32,000 t/year) is driven by land availability and pilot learning curves, not by market demand or offtake readiness. No decision rule exists for when to stop funding plants if cost targets are missed (e.g., 'if Month 60 = 2031-10-12 feedstock cost exceeds USD 1.40/kg, activate fallback to Hevea-only with alternative crops as a research hedge'). The plan treats plant capex as sunken by Month 60 (2031-10-12) when FID is taken, making Year 12 gate recovery impossible.

---

# 8 Expert: Climate Risk, Agronomic Shock and Program Resilience Analyst

**Knowledge**: Climate modeling and crop impacts, arid-zone water availability, weather-driven commodity volatility, program-level shock response, contingency reserve management, climate finance and adaptation policy

**Why**: The plan assumes Guayule siting in the arid Southwest and dandelion in temperate zones, but faces climate volatility (20-30% Guayule yield loss in drought, estimated) and SALB-habitat expansion under warming. The USD 4.5B reserve includes USD 1.0-1.5B for climate re-siting, but validation of arid-zone water availability, feasibility of switching to dandelion or other crops, and adequacy of the reserve for realistic multi-shock scenarios are not documented. The expert assesses program resilience to climate shocks, validates reserve adequacy, and recommends climate-contingency triggers for the Month 60 (2031-10-12) and Month 144 (2038-10-12) gates.

**What**: Model water availability and drought risk at candidate Guayule sites (Arizona, Mexico, other arid zones); assess SALB-habitat expansion under climate change scenarios (RCP 4.5, RCP 8.5) and implications for producer-nation protocol adoption; validate the USD 1.0-1.5B climate re-siting allocation as sufficient for crop relocation or diversification; recommend climate-contingency decision triggers for Month 60 (2031-10-12) and Month 144 (2038-10-12) gates; assess whether the USD 3.0-3.5B remaining reserve (after climate draw) is adequate for incursion and other shocks.

**Skills**: Climate modeling and crop-impact projection, water-resource analysis, commodity-volatility modeling, contingency-reserve sizing, climate-adaptation program design, resilience metrics and monitoring

**Search**: climate change crop resilience, arid zone water scarcity, SALB habitat expansion, agricultural contingency planning, drought risk modeling rubber

## 8.1 Primary Actions

- Commission agro-climatic modeling task by Month 1 (2026-11-12) covering water balance, drought probability, frost risk, and yield-stress curves at 15+ candidate sites (Guayule in Arizona/Mexico/Texas; dandelion in Germany/Benelux/Eastern Europe). Deliver baseline climate-risk profiles and revised land-use footprints by Month 6 (2027-04-12), locked into pilot-site selection by Month 24 (2028-10-12). Failure to complete this task blocks credible alternative-crop cost KPI gates (Month 60 = 2031-10-12, Month 144 = 2038-10-12).
- Shift the Hevea breeding Year 7 gate from Month 84 (2033-10-12) to Month 96 (2034-10-12) to allow 8-9 years of field observation, or establish a two-step gate (Month 84 = 2033-10-12 interim on cultivar readiness; Month 108 = 2035-10-12 durability gate on multi-pathotype inoculum challenge results). Deploy crown-budding parallel fast-track (USD 0.25B estimate) from Month 48 (2030-10-12) decision to hedge breeding delays. Establish Resistance Durability Oversight Panel by Month 1 (2026-11-12) with independent pathologists tasked to design multi-region, multi-pathotype inoculum protocols. Failure blocks Year 7 gate credibility and cascades smallholder adoption delays to Years 15-20.
- Launch smallholder-adoption baseline survey by Month 1 (2026-11-12) across 5 countries, sampling 2,000-5,000 farmers per country on willingness-to-replant, income-bridging sensitivity, extension satisfaction, and default expectations. Deliver findings by Month 6 (2027-04-12). Revise the 45% uptake target based on empirical willingness data; if baseline is 30%, reallocate USD 1.5-2.0B from smallholder finance to extension retention and nursery capital. Define binding re-scope triggers: enrollment below 25% by Month 54 (2031-04-12) triggers 40% reduction in Year 7 smallholder targets and reallocation to estate-led deployment. Pilot bridging finance on 5,000-10,000 smallholders in Months 12-36 (2027-10-12 to 2029-10-12). Failure orphans USD 6.75B investment line and undercuts smallholder legitimacy.
- Lock sovereign and development-bank funding into legally binding 25-year framework agreements by Month 12 (2027-10-12) with explicit gate-release mechanics, minimum-funding floors (80% tranche release on partial gate success, no annual budget-cycle re-approval), and binding dispute-resolution adjudication. Without binding commitments, a missed Year 7 gate withholds USD 5-8B (estimate), compressing cultivation timelines and cascading protocol and smallholder infrastructure failures.
- Establish independent auditor authority and dispute-resolution mechanism by Month 3 (2027-01-12) with contractually guaranteed multi-source data access (on-site trials, databases, farmer interviews), mandatory transparency (verdicts published within 30 days), and binding 60-day adjudication for disputes. Auditor independence protects against programme managers withholding unfavorable breeding or surveillance data, which could inflate gate assessments and misallocate USD 2-3B (estimate) to failed cultivars.
- Secure binding producer-nation protocol adoption commitments (MoUs with Brazil, Indonesia, Thailand, Malaysia, Vietnam) by Month 6 (2027-04-12), specifying national embedding of the IPPC-harmonized SALB Containment Protocol, inspector hiring (minimum 20 per major country by Month 12 = 2027-10-12), quarterly reporting, and enforcement penalties. Failure cascades the non-negotiable Phase 1 deliverable and invalidates all four funding gates, risking uncontrolled SALB spread.

## 8.2 Secondary Actions

- Develop explicit climate-scenario analysis (RCP 4.5, 8.5) for Guayule and dandelion at each candidate site, modeling yield loss and water-stress probability in Years 3-10 and 10-25. Incorporate drought-yield sensitivity and groundwater depletion trajectories. Use findings to validate or revise the USD 1.0-1.5B climate re-siting reserve allocation by Month 18 (2028-04-12).
- Model smallholder income volatility and price-shock scenarios (rubber price -30% to -50% during replanting window) to stress-test the bridging-finance design. If volatility exceeds income-replacement rate, shift from fixed-term bridging to trigger-based payments (tied to commodity price indices). Deliver revised finance design by Month 12 (2027-10-12).
- Design extension-staff retention strategy including career pathways, performance bonuses, and professional development, targeting 70%+ retention by Year 5 and 60%+ by Year 10. Build retention costs into the USD 400M protected extension stream and allocate contingency for staff-turnover volatility.
- Commission independent water-balance assessment of Guayule contract-farmland candidates in Arizona, Mexico, and Texas, including groundwater sustainability, surface-water competition, and indigenous-water-rights conflicts. Flag sites with <10-year groundwater reserve at proposed extraction rates. Deliver assessment by Month 12 (2027-10-12); exclude inviable sites from pilot selection by Month 24 (2028-10-12).
- Establish price-stability mechanism for smallholder resistant-cultivar and alternative-crop output (index insurance or price floor at 90% of Hevea benchmark, estimate) by Month 18 (2028-04-12). Pilot on 10,000 hectares in Months 24-36 (2028-10-12 to 2029-10-12); if farmer retention improves >20%, expand to full smallholder cohort by Month 60 (2031-10-12). Link price stability to adoption-gate progression.
- Design SALB incursion scenarios (single-site, multi-site, multiple-region) and validate the USD 0.5B eradication-compensation fund against realistic destruction tonnage and opportunity-cost impacts on smallholders. If single-site incursion (e.g., 5,000 ha infected estates, 20,000 smallholders affected) exceeds fund capacity, model phased compensation schedules or insurance alternatives. Deliver scenario analysis by Month 12 (2027-10-12).
- Pre-register all gate KPIs (cultivar yield, resistance sources, lesion size, containment metrics, adoption rates) in a peer-reviewed protocol document published before Month 6 (2027-04-12) so auditors cannot re-interpret success criteria at the time of gate assessment. Submit for publication in a journal such as *Global Food Security* or *Agricultural Systems*.
- Establish quarterly funder dashboard reporting on progress against all 6 primary actions above, with visible red-flag alerts if any milestone is missed by >2 months. Publish simplified version for smallholder and producer-nation stakeholders to build transparency and trust.
- Model the cost-effectiveness of the entire program (USD 30B for 25 years) against alternatives: (A) strategic natural-rubber reserve (physical stock), (B) insurance and contingency funds without supply diversification, (C) Hevea breeding alone (no alternative crops). Deliver cost-per-hectare-protected and cost-per-tonne-diversified-supply comparisons by Month 18 (2028-04-12) to justify the full portfolio to skeptical funders.
- Commission a governance-risk assessment of the 25-year program, modeling the probability of funding erosion, political re-prioritization, and producer-nation withdrawal in Years 5, 10, 15, and 20. Identify early-warning indicators (e.g., shift in government priorities, commodity price collapse, competing crisis) and pre-agree contingency protocols (e.g., minimum-funder coalition, trigger for program simplification). Deliver assessment by Month 12 (2027-10-12).

## 8.3 Follow Up Consultation

"In the next consultation (Month 3 = 2027-01-12), present: (1) Draft agro-climatic modeling findings and preliminary land-use footprint revisions; (2) Resistance Durability Oversight Panel charter and multi-site inoculum-challenge protocols; (3) Smallholder baseline-survey design and first results from pilot-country field work; (4) Independent auditor procurement status and dispute-resolution adjudication panel membership; (5) Status of bilateral MoU negotiations with Brazil, Indonesia, Thailand, Malaysia, Vietnam and expected signature dates; (6) Binding framework-agreement templates for sovereign and development-bank funders with gate-release mechanics. Prioritize: climate modeling, durability testing, and adoption baselines, as these three directly constrain gate credibility and capital allocation decisions at Months 6, 18, and 36 (2027-04-12, 2028-04-12, 2029-10-12)."

## 8.4.A Issue - Climate Shock Resilience Framework Absent—Alternative Crop Siting and Water Vulnerability Unmodeled

The plan commits USD 1.0-1.5 billion for climate re-siting of Guayule and dandelion but assumes no baseline climate stress model or water-availability forecast. Guayule in arid U.S. Southwest faces 20-30% yield loss (estimate) under sustained drought; dandelion in Europe faces spring frost and summer heat stress. Without explicit agro-climatic modeling at candidate sites (soil water balance, precipitation volatility, temperature extremes), the plan cannot validate that land-use footprints are climate-resilient or that reserve capital is sized correctly. Risk: Month 60 (2031-10-12) processing KPI gate may be missed for climate reasons unrelated to agronomic technology, collapsing the supply-diversification narrative.

### 8.4.B Tags

- climate-water-gap
- alternative-crop-risk
- arid-zone-hydrology
- agro-climatic-modeling

### 8.4.C Mitigation

Commission a dedicated agro-climatic modeling task by Month 1 (2026-11-12) covering: (1) water balance and drought probability at 10+ candidate Guayule sites (Arizona, Mexico, Texas); (2) spring frost and summer heat stress at 5+ dandelion sites (Germany, Benelux, Eastern Europe); (3) monthly precipitation, temperature, and soil-water stress using 30-year climate records and CMIP6 projection ensemble; (4) crop water demand, critical growth stages and yield-loss curves; (5) suitability maps with confidence intervals. Deliver baseline climate-risk profiles and revised land-use footprints by Month 6 (2027-04-12). Incorporate findings into the Month 24 (2028-10-12) pilot-site selection decision. Consult: CGIAR climate-smart agriculture networks, national meteorological services, university agronomy departments with perennial-crop experience. Data to provide: 30-year station records, soil surveys, groundwater assessments from proposed sites.

### 8.4.D Consequence

Without climate modeling, the Month 60 (2031-10-12) cost-KPI gate will likely fail for Guayule in drought years, triggering the plan's fallback (redirect to Hevea breeding), which sacrifices supply diversification. If pilots are sited on high-risk land, replanting at Month 72 (2032-10-12) for wave 1 (commercial plants) will be too late to recover; the Month 144 (2038-10-12) gate assumes 16,000 t/year wave 1 production, but drought-stressed sites may deliver 12,000 t/year or less. This cascades a USD 0.4-0.6 billion capital loss and strands smallholder adoption infrastructure if Guayule-focused regions face water stress.

### 8.4.E Root Cause

The plan treats climate as a re-siting cost line (USD 1.0-1.5B reserve drawdown) rather than a baseline geophysical constraint. Guayule and dandelion are perennial crops with 3-5 year establishment lags; siting decisions locked at Month 24 (2028-10-12) cannot be re-scoped after Month 60 (2031-10-12) without 3-year delays. Climate variability is not quantified; only a 20-30% yield-loss range is mentioned. Without water-balance and frost-risk modeling at each candidate site, the gates assume false certainty.

## 8.5.A Issue - Hevea Breeding Timeline Has Zero Slack to Year 7 Gate—Resistance Durability Testing Compressed and Durability Claims Unverifiable

The plan locks field trials at 4 sites beginning Month 12 (2027-10-12) and demands Year 7 gate readiness (Month 84 = 2033-10-12) with cultivars yielding ≥90% of elite clones and ≥3 stacked resistance sources. Perennial crops require 6-10 years of field data to evaluate durability under natural pathogen pressure. A cultivar planted in Month 12 (2027-10-12) yields first meaningful durability data (symptom expression, lesion size, defoliation) at Month 72 (2032-10-12), leaving only 12 months (Month 72-84 = 2032-10-12 to 2033-10-12) for auditors to verify that the cultivar is durable. If resistance breaks under field pressure or yield penalties emerge in Years 5-6, there is no time to switch breeding strategies before the gate decision. Risk: Year 7 gate readiness cannot be credibly verified without multi-year durability evidence; auditors will flag 'conditional' passage, stranding capital.

### 8.5.B Tags

- perennial-crop-cycles
- resistance-durability-gap
- breeding-timeline-risk
- gate-verification-lag

### 8.5.C Mitigation

Shift the breeding gate to Month 96 (2034-10-12) (Year 8) to allow 8-9 years of field observation. If Month 84 (2033-10-12) re-sequencing is unacceptable, establish a two-step gate: (1) Month 84 (2033-10-12) interim gate gates ~USD 1-2 billion on cultivar-release readiness (yield ≥90%, 2+ sources stacked, no lesions >10mm in first 6 years); (2) Month 108 (2035-10-12) durability gate gates further USD 2-3 billion only after 8-9 years of field exposure. Alternatively, deploy crown-budding as a parallel fast-track (USD 0.25B estimate) from Month 48 (2030-10-12) decision point to deliver field protection earlier while breeding matures. Establish a Resistance Durability Oversight Panel by Month 1 (2026-11-12) with independent pathologists tasked to design multi-pathotype and multi-region inoculum challenges at each breeding site, mimicking natural epidemic conditions. Consult: breeders from IRRDB, Embrapa, RRIM; plant pathologists from universities with Hevea disease experience; historical SALB resistance-breakdown records from Brazil and Central America. Data to provide: genotypes of all 3+ resistance sources, inoculum provenance and virulence profiles, lesion-size time series, yield data by site-season-block.

### 8.5.D Consequence

If durability claims are not verifiable at Month 84 (2033-10-12), the auditor will issue a 'conditional' or 'fail' verdict, withholding the Year 7 gate tranche (USD 6.5 billion, estimate). This cascades a Year 1-2 delay in smallholder replanting (smallholders will not adopt unverified cultivars), orphaning the USD 6.75 billion smallholder-finance line and deferring risk reduction to Years 15-20 (too late to contain SALB if an incursion occurs in Years 10-12). Alternatively, if the gate is passed despite weak durability evidence, a resistance breakdown in Years 12-18 will vindicate skeptics and undermine funding for the entire program.

### 8.5.E Root Cause

The plan assumes that 6-year field data (Month 12 = 2027-10-12 to Month 72 = 2032-10-12) is sufficient to claim durability at the Month 84 (2033-10-12) gate. In reality, SALB resistance durability is contested terrain: Hevea was thought resistant to SALB 50 years ago; resistance broke within 10-20 years in some clones. With only a single 6-year growing cycle and no multi-pathotype or multi-region inoculum challenge, auditors cannot distinguish durable resistance from lag-phase resistance breakdown. The plan's breeding KPI (≥3 independent sources stacked) assumes that stacking delays breakdown, but this is untested in the perennial-crop context.

## 8.6.A Issue - Smallholder Adoption Baseline Unvalidated Against Historical Records—45% Uptake Target Likely Unachievable Without Explicit Trigger for Demand Shift

The plan targets 45% of 5 million hectares (2.25 million ha) smallholder replanting by Month 144 (2038-10-12), with contingency scenarios at 30-40% (conservative) and 60%+ (optimistic). Historical adoption of improved rubber clones in Southeast Asia averages 20-40% (not verified) despite decades of extension and favorable economics. The plan allocates USD 6.75 billion to smallholder replanting and bridging finance—the largest single cost line—yet does not model what drives uptake: smallholder income volatility, extension staff retention, clean-plant nursery reliability, or price stability. The three scenarios (30/40/60%) are defined as decision waypoints but lack explicit triggers or demand-shift mechanisms. Risk: If adoption falls to 30-40% by Month 84 (2033-10-12), the plan reallocates USD 0.8-1.2 billion from smallholder to estate/processing, but this re-scope is only 'proposed,' not binding. Without binding re-scope rules, a shortfall becomes a sunk-cost trap.

### 8.6.B Tags

- smallholder-adoption-risk
- historical-uptake-gap
- extension-delivery-fatigue
- contingency-trigger-missing

### 8.6.C Mitigation

Launch a dedicated smallholder-adoption baseline study by Month 1 (2026-11-12) in each of the top 5 producing countries, surveying 2,000-5,000 smallholders across income, land-tenure, extension-access, and price-expectation strata. Establish: (1) current Hevea-clone adoption rates by region (not global average); (2) willingness-to-replant under bridging-finance scenarios (income-replacement rates 50%, 60%, 70%); (3) extension-contact frequency and farmer satisfaction in existing programs; (4) nursery availability and quality in smallholder-serving regions; (5) default expectations under income-bridging finance (baseline: 10-15% annual default, estimate). Deliver findings by Month 6 (2027-04-12). Use data to revise the 45% target and allocation: if baseline willingness is 30%, shift USD 1.5-2.0 billion from smallholder-finance to extension-staff retention bonuses, nursery-capital grants, and price-stability mechanisms (e.g., index insurance or price floors). Define binding re-scope triggers: if enrollment falls below 25% by Month 54 (2031-04-12), reduce Year 7 smallholder targets by 40%, reallocate freed capital, and pivot to estate-led resistance deployment. Pilot bridging-finance instruments on 5,000-10,000 smallholders in Months 12-36 (2027-10-12 to 2029-10-12) to validate repayment behavior and default rates before scaling to the full 2.25 million ha. Consult: smallholder-livelihood researchers, farmer associations in each country, prior program evaluations (Worldbank, CGIAR). Data to provide: household income, land holdings, credit history, extension-contact logs, nursery transaction records.

### 8.6.D Consequence

If smallholder adoption targets are not achievable, the program faces either (A) sunk cost: allocate USD 6.75 billion expecting 45% uptake, realizing 30%, and leaving USD 2-3 billion in smallholder infrastructure (extension, nurseries) undersized and under-utilized, or (B) re-scope: reallocate to estate-led deployment, which widens the income-inequality gap and undercuts the plan's smallholder-equity narrative. Either outcome reduces the plan's legitimacy with producing-country governments and smallholder organizations, potentially undermining protocol adoption and the non-negotiable Phase 1 deliverable. If extension staff turnover exceeds 40% annually and clean-plant nurseries fail (e.g., due to certification lapse or input supply shock), adoption will collapse in Years 8-12, stranding 500+ trained agents and 50-100+ nurseries with no market, creating political backlash and reputational damage.

### 8.6.E Root Cause

The plan treats the 45% uptake target as a planning figure but does not validate it against regional rubber-adoption histories or model the behavioral, institutional, and economic drivers of smallholder decisions. Extension agents (500 target, 200-500 smallholders each) must operate for 25 years; retention in developing-country agriculture is typically 30-50% annually (estimate), implying 70-80% churn by Year 10. Clean-plant nurseries (50-100 per country) depend on government certification, secure input supply, and market access; in prior programs (e.g., cocoa, coffee), nursery reliability collapsed when public funding ended. Replanting requires 6-10 years with no tapping income; bridging finance is estimated but not piloted. Income volatility and price shocks (e.g., 2008-2009 rubber price collapse, -40% estimate) can eliminate the economics of adoption mid-cycle.