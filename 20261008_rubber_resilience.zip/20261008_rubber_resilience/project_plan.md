**Goal Statement:** Deliver a 25-year (Months 0-300), USD 30 billion (user constraint) public-private program that secures global natural rubber supply against South American Leaf Blight (SALB) through a globally adopted containment protocol, SALB-resistant Hevea cultivars, and commercial Guayule and Russian dandelion supply chains, with funding gated at Months 36/84/144/216 (2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12).

## SMART Criteria

- **Specific:** Achieve verified SALB containment, diversified parallel rubber supply chains, and resilient procurement against pathogen and climate shocks, with smallholder adoption designed in and a harmonized containment protocol delivered first.
- **Measurable:** Gate KPIs: Month 36 (2029-10-12) protocol adopted by IPPC vote, binding in at least 3 of top 5 producers, 100+ inspectors, no unmanaged incursion (proposed threshold); Month 84 (2033-10-12) cultivar yield at least 90% of elite clones with 3 stacked resistance sources; Month 144 (2038-10-12) alternative-rubber delivered cost under 30% above Hevea; 45% smallholder uptake planning target (proposed threshold).
- **Achievable:** Builds on existing IPPC frameworks, Amazonian germplasm, and established guayule and dandelion research. Constraints: 6-10 year perennial breeding cycles with zero slack to the Month 84 (2033-10-12) gate, and alternative-rubber costs above Hevea. The USD 4.5B reserve and gate-conditional tranches limit exposure.
- **Relevant:** Natural rubber supply depends on a single crop vulnerable to SALB. Diversifying supply protects tire and industrial manufacturers, and the livelihoods of smallholder producers.
- **Time-bound:** Project starts ASAP at Month 0 (2026-10-12) and runs 25 years (Months 0-300). Gates at Months 36, 84, 144 and 216 (2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12); Phase 1 containment protocol precedes any scale-up.

## Dependencies

- Funding commitments secured from sovereign, development-bank and industry sources
- Producer-nation agreements to adopt the containment protocol
- Access-and-benefit-sharing agreements for Amazonian Hevea germplasm
- OEM engagement and offtake framework for alternative rubber
- Independent gate verification regime established

## Resources Required

- Gate-conditional capital: USD 25.5B deployable plus USD 4.5B reserve
- Inspectors, extension agents, nurseries and regional laboratories
- Breeding stations, field trial sites and genomic facilities
- Pilot and commercial colocated processing plants
- Contract farmland for Guayule and dandelion

## Related Goals

- Global phytosanitary standard harmonization
- Smallholder livelihood resilience
- Climate-resilient agricultural supply chains
- Alternative biobased rubber commercialization
- Open genomic resources for rubber breeding

## Tags

- SALB
- Natural Rubber
- Plant Pathology
- Supply Chain Resilience
- Guayule

## Risk Assessment and Mitigation Strategies


### Key Risks

- Producer nations delay or refuse binding protocol adoption
- Resistant Hevea misses yield or durability criteria by the Month 84 (2033-10-12) gate
- Alternative-rubber costs stay 30% or more above Hevea, leaving plants unbankable
- Funding commitments erode through budget cycles or levy defection
- Smallholder uptake falls below the 45% planning target

### Diverse Risks

- ABS disputes delay germplasm transfer and breeding starts
- Contaminated nursery stock or late detection spreads SALB
- Gate evidence is withheld or contested
- Climate stress cuts Guayule or dandelion yields
- Extension staff turnover and institutional fatigue over 25 years

### Mitigation Plans

- Sign producer MoUs by Month 6 (2027-04-12) and re-scope if fewer than 3 of top 5 have binding adoption by Month 54 (2031-04-12) (proposed threshold)
- Pre-register breeding KPIs, run 4-site trials by Month 12 (2027-10-12), and decide crown-budding fast-track if yield penalty exceeds 15% by Month 48 (2030-10-12) (proposed threshold)
- Build pilots first, set cost KPIs, and decide at Month 60 (2031-10-12) between processing innovation and Hevea breeding before wave 1 plants
- Bind 25-year framework agreements by Month 12 (2027-10-12), hold a USD 4.5B ring-fenced reserve, and use at least 5 funders
- Fund a protected USD 400M extension stream, locally owned nurseries, and set adoption waypoints with stop triggers

## Stakeholder Analysis


### Primary Stakeholders

- Programme Steering Council
- Containment Protocol Adoption Secretariat (FAO/IPPC)
- Brazil-led breeding and ABS team
- Alternative-rubber processing and agronomy teams
- Extension corps and nursery network

### Secondary Stakeholders

- Producing-country plant protection agencies
- Tire makers and OEMs
- Sovereign and development-bank funders
- Indigenous and traditional Amazonian communities
- Smallholder farmers and cooperatives

### Engagement Strategies

- Steering Council: quarterly meetings with gate-discipline reporting
- Producer nations: bilateral MoUs and quarterly compliance reporting
- OEMs: steering committee, letters of intent, qualification trial results shared
- Funders: milestone reports and published independent audit verdicts
- Communities and smallholders: published benefit-sharing, data trust seats, mobile extension and cooperative governance

## Regulatory and Compliance Requirements


### Permits and Licenses

- Brazil CGen access and benefit-sharing authorizations
- Plant import/export phytosanitary certificates
- Nursery certification and clean-plant licenses
- Processing plant construction and environmental permits
- Land-use and water-use permits for alternative crop sites

### Compliance Standards

- IPPC international standards for phytosanitary measures
- Nagoya Protocol on access and benefit-sharing
- Regional plant protection organization standards
- Environmental and water-use regulations at plant sites
- Tire industry quality specifications

### Regulatory Bodies

- IPPC Secretariat (FAO)
- National plant protection organizations
- Brazil CGen
- Regional plant protection organizations
- Environmental and permitting authorities at plant sites

### Compliance Actions

- Sign producer-nation MoUs by Month 6 (2027-04-12)
- Submit protocol draft to IPPC working group at Months 3-4 (2027-01-12 to 2027-02-12) and hold adoption vote by Month 36 (2029-10-12)
- Execute ABS agreements with CGen and 3 community groupings by Month 6 (2027-04-12)
- Contract independent auditor by Month 3 (2027-01-12) and pre-register scope by Month 6 (2027-04-12)
- Apply for plant and site permits before wave 1 final investment decision