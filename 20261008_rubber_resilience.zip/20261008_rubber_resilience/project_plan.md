**Goal Statement:** Over Months 0-300, deliver a USD 30 billion (user constraint) stage-gated public-private program that secures global natural rubber supply against South American Leaf Blight (SALB) via an IPPC-framework Containment Protocol, SALB-resistant Hevea cultivars, and commercial guayule and Russian dandelion supply, with smallholder adoption and funding gates at Months 36, 84, 144 and 216 (2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08).

## SMART Criteria

- **Specific:** Establish a globally adopted SALB Containment Protocol harmonized with regional phytosanitary standards, deliver pyramided SALB-resistant, yield-parity Hevea cultivars, and stand up diversified alternative-rubber supply with OEM offtake, designed around smallholder adoption.
- **Measurable:** Month 36 (2029-10-08) Protocol Readiness gate: at least 15 countries with enforceable import rules, 500 trained inspectors, 2 lab-cleared suspect detections (proposed threshold). Month 144 (2038-10-08): containment in at least 12 countries, 1.5 million smallholder adopters, at least 200,000 t/yr alternative rubber (proposed thresholds). Month 216 (2044-10-08): at least 5% of global demand.
- **Achievable:** Builds on established components: IPPC standard-setting, genomic Hevea breeding, and known guayule and dandelion crops. A USD 30 billion cap, adaptive tranches and USD 5.9B of reserves absorb biological delays. Risks: unproven alternative-rubber cost parity, slow standard adoption and levy coordination.
- **Relevant:** Natural rubber depends on one crop vulnerable to SALB, with Asia as the main SALB-free supplier. Containment, resistant cultivars and alternatives give redundant protection for tyre supply chains and smallholder livelihoods.
- **Time-bound:** 25 years starting immediately (Months 0-300). Phase 1 Months 0-36 (2026-10-08 to 2029-10-08) (containment first, no scale-up before gate); gates at Months 36, 84, 144 and 216 (2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08); Phase 5 Months 216-300 covers handover.

## Dependencies

- Binding funding commitments from sovereign governments and multilateral development banks
- Independent multilateral secretariat and Technical Gate Charter established
- Producer-country agreement to adopt the Containment Protocol into national law
- Nagoya Protocol access-and-benefit-sharing agreements with Brazilian authorities and communities
- OEM buyer consortium and offtake agreements before commercial processing hubs are approved

## Resources Required

- Phytosanitary inspectors, diagnostic equipment and digital reporting platform
- High-containment trial stations, pathogen genomics laboratories and germplasm bank
- Guayule and Russian dandelion pilot land, plus colocated processing hubs
- Replant finance, clean-plant nurseries and surveillance premium funds
- Reserves: contingency pool, outbreak response reserve, political-risk reserve

## Related Goals

- Protect smallholder livelihoods in rubber-producing regions
- Build producer-country phytosanitary and research capacity
- Diversify natural rubber supply to temperate and arid regions
- Establish durable multilateral funding including a ring-fenced industry levy

## Tags

- SALB
- Natural rubber
- Hevea breeding
- Phytosanitary containment
- Guayule

## Risk Assessment and Mitigation Strategies


### Key Risks

- Containment Protocol not binding or adopted by the Month 36 (2029-10-08) gate
- Resistance breeding delays or resistance breakdown from pathogen evolution
- Funding shortfall of USD 120-360M per year (estimate) and levy under-collection
- Alternative-rubber cost or quality misses gates and OEM offtake is weak
- Undetected SALB incursion costing USD 2-5B (estimate) against a USD 0.5B standing reserve

### Diverse Risks

- Low smallholder adoption and concealment of infections
- Nagoya/ABS negotiation delays or community disputes
- Governance capture or producer-country rejection of secretariat
- Climate shocks and environmental limits on alternative-crop sites
- Combined stress claims of USD 2.4-6.3B (estimate) exceeding the USD 4.5B contingency pool

### Mitigation Plans

- Run technical drafting and IPPC proposal in parallel with binding regional compacts by Month 24 (2028-10-08); use a Month 36 (2029-10-08) readiness gate with partial release and a later Containment Efficacy Review
- Pyramid at least 3 genes from 2 sources, enforce Virulence Gates, start the Brazil genomics lab by Month 2 (2026-12-08), and use existing repository accessions as backup
- Secure binding multi-year commitments by Month 3 (2027-01-08) with no funder above 25%, pilot the levy by Month 18 (2028-04-08), and use the fallback cascade if compliance is below 60%
- Approve no commercial hubs before the Month 84 (2033-10-08) gate and 80% priced offtake; co-fund OEM qualification testing and use co-product revenue
- Fund the outbreak reserve by Month 3 (2027-01-08), pre-agree response and compensation rules, pay surveillance premiums within 30 days, and keep reserves outside gate logic

## Stakeholder Analysis


### Primary Stakeholders

- Multilateral secretariat and board
- Technical Panel
- Brazil-led breeding and germplasm institutes
- Producer-country plant protection and rubber research agencies
- Alternative-rubber hub developers and OEM buyer consortium

### Secondary Stakeholders

- Sovereign funders and multilateral development banks
- Smallholder farmers and cooperatives
- Indigenous and traditional communities
- IPPC Secretariat, FAO and regional plant protection organizations
- Environmental groups and local communities near crop sites

### Engagement Strategies

- Secretariat, Technical Panel and institutes: regular progress reports, published gate evidence 60 days before each decision, prompt responses to information requests
- Funders and banks: milestone reports, binding commitments tied to gates, annual stakeholder reports
- Producer governments: board seats, per-country allocations, capacity-building and twinning support
- Smallholders and communities: co-designed finance, surveillance premiums, community seats and benefit-sharing reports
- OEMs, regulators and NGOs: buyer consortium, shared qualification testing, early environmental and permit consultation

## Regulatory and Compliance Requirements


### Permits and Licenses

- National agricultural and environmental permits for guayule and dandelion pilot and commercial sites
- Nagoya Protocol and Brazilian genetic-resource access authorizations
- Import and export permits for research material and plant stock
- Biosafety approvals for high-containment pathogen laboratories and trial stations
- Processing plant construction and operating permits

### Compliance Standards

- IPPC International Standards for Phytosanitary Measures
- Nagoya Protocol on access and benefit-sharing
- Regional phytosanitary frameworks (ASEAN, ECOWAS, Mercosur)
- Tyre and automotive material standards in EU, USA and Japan
- Biosafety level requirements for pathogen handling

### Regulatory Bodies

- IPPC Secretariat and FAO
- National plant protection organizations
- Brazilian environmental and genetic-resource authorities
- Regional plant protection organizations
- Environmental and agricultural regulators in crop-site countries

### Compliance Actions

- Submit formal IPPC protocol proposal by Month 18 (2028-04-08)
- Obtain 15 country commitment letters and regional compacts by Month 24 (2028-10-08)
- Complete Nagoya/ABS agreements by Month 6 (2027-04-08) and publish annual benefit-sharing reports
- Map permits and start pilot-site applications in the first year, before any plant construction
- Audit inspectors and checkpoints against the protocol and publish gate evidence