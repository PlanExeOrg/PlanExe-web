
## Strengths 👍💪🦾
- Clear three-pillar design (containment, resistant Hevea, alternative rubbers) gives redundant protection against a single-crop failure.
- Large, defined budget: USD 30B (user constraint) with USD 5.9B of reserves inside the cap (contingency USD 4.5B, outbreak USD 0.5B, political-risk USD 0.9B).
- Containment-first sequencing: no scale-up before the Month 36 (2029-10-08) Protocol Readiness gate, harmonized with IPPC rather than a parallel regime.
- Adaptive tranches and independent Technical Panel give credible, evidence-based gating that tolerates biological delay.
- Durability safeguards: at least 3 independent resistance genes from 2 sources, Virulence Gates at Months 24-60 (2028-10-08 to 2031-10-08), and a Brazil pathogen genomics lab by Month 2 (2026-12-08).
- Smallholder-centred design: replant finance, 300-600 clean-plant nurseries and surveillance premiums that make reporting an income stream.
- Balanced governance (producers, OEMs, banks, experts; no faction a majority) and strong existing partners: Embrapa, CIRAD, Bridgestone, Continental.

## Weaknesses 👎😱🪫⚠️
- KILLER APPLICATION MISSING: no single compelling use-case yet pulls OEMs, farmers and funders in. Guayule and dandelion rubber are unproven at tire-grade cost, and resistant Hevea only pays off after an outbreak.
- Insurance-style value proposition: benefits materialize only if SALB threatens or arrives, which weakens urgency and funder commitment.
- Hub economics fail at the gate-limit: coverage 0.80 at USD 1.62/kg opex; bankable only at about USD 1.47/kg or less (estimate).
- Month 36 (2029-10-08) gate measures readiness, not proven efficacy; zero interceptions are ambiguous.
- Weak-link countries have thin inspector capacity, and the 25-year plan depends on a levy that is untested.
- Open decisions: who services the USD 7.0B bank lending (about USD 449M/yr), hub financing split, replant loan capital source.
- Reserves can be outrun: combined stress claims of USD 2.4-6.3B (estimate) versus a USD 4.5B pool.

## Opportunities 🌈🌐
- KILLER APPLICATION (developable): a flagship, OEM-branded SALB-proof tire line. Start with premium or specialty guayule latex (hypoallergenic gloves, medical goods) and a co-branded guayule or dandelion tire, to create visible demand and prove tire-grade quality before hubs.
- Second flagship candidate: a 'clean-plant + surveillance premium' farmer product that raises income, so adoption does not rely on subsidy.
- Buyer consortium of 5-8 OEMs can pool qualification costs, with co-products (resin, bagasse, inulin) improving economics.
- Existing IPPC process and regional compacts offer a two-tier route to binding adoption.
- Pooled benefit-sharing could unlock germplasm from other South American countries.
- Drought-tolerance and climate traits can be bred alongside resistance.
- Growing OEM supply-chain and sustainability pressure (GPSNR members) supports levy and offtake talks.
- Outcome-linked and royalty instruments (USD 3.0B) can grow with cultivar and alternative-rubber sales.

## Threats ☠️🛑🚨☢︎💩☣︎
- Protocol not binding or adopted by Month 36 (2029-10-08); IPPC standard adoption expected only Months 36-60 (2029-10-08 to 2031-10-08) (estimate).
- Undetected SALB incursion costing USD 2-5B (estimate) against a USD 0.5B standing reserve; climate may widen suitable zones.
- Resistance breeding slippage of 18-36 months or resistance breakdown from pathogen evolution.
- Levy evasion or buyer resistance; funding shortfall of USD 120-360M/yr (estimate); funder turnover over 25 years.
- OEMs hedge with synthetic rubber instead of signing take-or-pay offtake.
- Nagoya/ABS delays or community disputes; producer-state rejection of secretariat authority.
- Smallholder concealment of infections and low uptake (typical 20-40%).
- Climate and water limits at alternative-crop sites; tightening tire and automotive standards.

## Recommendations 💡✅
- Appoint a flagship-product lead at the OEM buyer consortium by Month 6 (2027-04-08); commission a specialty guayule latex line and a co-branded prototype tire programme, with a go/no-go on the killer-application choice by Month 18 (2028-04-08). Owner: Secretariat with OEM board seats.
- Run the IPPC proposal (Month 18 = 2028-04-08) in parallel with binding Asia and Africa compacts and 15 commitment letters by Month 24 (2028-10-08); third-party audits from Month 12 (2027-10-08). Owner: Secretariat protocol team with national plant protection organizations.
- Sign binding multi-year commitments from 5-8 sovereigns and at least 2 MDBs by Month 3 (2027-01-08), with no funder above 25%; pilot ASEAN levy by Month 18 (2028-04-08); trigger fallback cascade if compliance is under 60%. Owner: Secretariat finance lead.
- Fund the USD 0.5B outbreak reserve by Month 3 (2027-01-08), with pre-agreed compensation rules; model a combined-stress plan against the USD 4.5B pool by Month 12 (2027-10-08). Owner: Board and Technical Panel.
- Start the Brazil pathogen genomics lab by Month 2 (2026-12-08) and Asian satellite by Month 9 (2027-07-08); enforce Virulence Gates at Months 24-60 (2028-10-08 to 2031-10-08); complete Nagoya/ABS agreements by Month 6 (2027-04-08). Owner: Brazil-led breeding consortium.
- Launch surveillance-premium pilots in 3-5 zones during Months 6-24 (2027-04-08 to 2028-10-08), with 30-day payment and at least 60% participation; resolve MDB debt-service and hub-financing decisions by Month 12 (2027-10-08). Owner: Smallholder finance lead.

## Strategic Objectives 🎯🔭⛳🏅
- By Month 36 (2029-10-08), at least 15 producing countries have enforceable SALB import rules, at least 500 audited inspectors and 2 lab-cleared detections, meeting regional minimums (Asia 8, Africa 4, Americas 3) (proposed threshold).
- By Month 18 (2028-04-08), deliver at least 200 characterised wild Hevea accessions and have 2-3 OEM take-or-pay letters of intent, and select the flagship product (proposed threshold).
- By Month 84 (2033-10-08), at least 2 pyramided candidates with at least 90% resistance and at least 85% of elite-clone yield pass the Virulence Gate, and alternative-rubber pilot cost is at most USD 1.62/kg (proposed threshold).
- By Month 144 (2038-10-08), at least 12 countries with verified containment, 1.5 million smallholder adopters and at least 200,000 t/yr alternative rubber (proposed threshold).
- By Month 36 (2029-10-08), a ring-fenced levy collects about USD 270M/yr at over 80% compliance, or the fallback cascade is active by Month 48 (2030-10-08) (estimate).

## Assumptions 🤔🧠🔍
- Pragmatic Foundation path is adopted: IPPC-framework protocol, multilateral secretariat, levy, pyramided breeding, adaptive tranches.
- The USD 30B cap, 25-year duration and gates at Months 36/84/144/216 (2029-10-08, 2033-10-08, 2038-10-08, 2044-10-08) are fixed.
- SALB stays out of Asia and Africa through Month 36 (2029-10-08).
- OEMs engage if quality qualification is credible and co-funded.
- A flagship use-case can be proven at pilot scale before hubs are approved.
- Reference Hevea price of USD 1,350/t holds; figures marked estimate or proposed threshold are unvalidated.

## Missing Information 🧩🤷‍♂️🤷‍♀️
- Evidence on which use-case OEMs and consumers would pay a premium for (flagship demand study).
- Who services the USD 7.0B MDB lending and how hub capex is split.
- Current inspector counts and legal gaps in each producing country.
- Actual guayule and dandelion pilot cost and tire-grade test data.
- Levy legal basis and willingness of traders and tire makers to pay.
- Brazilian community and state positions on benefit-sharing terms.
- SALB climate-suitability modelling for Asia and Africa.
- Smallholder credit access and land-title data by region.

## Questions 🙋❓💬📌
- Which single use-case (specialty latex, a co-branded tire, a farmer income product) would make OEMs and funders act before an outbreak, and what evidence would prove it by Month 18 (2028-04-08)?
- Is the Month 36 (2029-10-08) readiness gate a convincing proof for funders, and what would they accept as evidence that containment works?
- If a major producer refuses the protocol, which funding and political levers are credible, and who applies them?
- How would the program respond if the combined stress claims of USD 2.4-6.3B exceed the USD 4.5B pool?
- Which assumptions about levy compliance, OEM offtake and smallholder uptake are least validated, and what early tests would reduce that uncertainty?