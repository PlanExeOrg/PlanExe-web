## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Have 5-8 sovereigns and at least 2 development banks signed binding multi-year commitments (no funder above 25%), with the Technical Gate Charter signed and a named payer for the USD 7.0B bank lending? | By Month 3 (2027-01-08): at least 5 sovereigns and 2 banks signed, no funder above USD 7.5B (25%), Charter signed, outbreak reserve (USD 0.5B) in escrow. By Month 12 (2027-10-08): at least USD 15B binding capital (proposed threshold) and a payer covering at least 80% of the ~USD 449M/yr debt service (proposed threshold). | Signed commitment letters and Charter at Month 3 (2027-01-08). Debt-service covenant and escrow terms by Month 12 (2027-10-08). Stop-rule check on binding capital at Month 12 (2027-10-08) and repayment source at Month 18 (2028-04-08). | Below 5 sovereigns or 2 banks at Month 3 (2027-01-08): delay Phase 1 spending beyond capacity-building and re-run funder talks. Below USD 15B at Month 12 (2027-10-08), or no repayment source by Month 18 (2028-04-08): stop scale-up, cancel bank-financed scope and downsize to a containment-only programme funded by grants and levy. |
| 2 | Are the Nagoya/ABS access agreements signed and has wild Hevea collection produced at least 200 characterised accessions by Month 18 (2028-04-08)? | At least 6 signed access agreements by Month 6 (2027-04-08); collection starts Month 8 (2027-06-08); at least 200 characterised accessions by Month 18 (2028-04-08). Floor: at least 100 accessions covered by a binding agreement at Month 18 (2028-04-08) (stop rule). | Signed ABS agreements (Month 6 = 2027-04-08), collection log (Month 8 = 2027-06-08 onward), accession register (Month 18 = 2028-04-08). | Slip to Month 12 (2027-10-08): delay collection, lean on 50-80 existing repository accessions (estimate) and extend the cultivar timeline. Below 100 accessions at Month 18 (2028-04-08): end new wild collection, use repository germplasm only, and reset the Month 84 (2033-10-08) cultivar gate. |
| 3 | Do the Month 18 (2028-04-08) pilots show that the ASEAN levy and the smallholder surveillance premium work? | Levy: compliance above 80% to proceed to global rollout; below 60% triggers the fallback cascade (outcome-linked bonds, higher bank loan share, climate finance). Premium: at least 60% participation, payment within 30 days; stop if below 40% after one redesign. | ASEAN levy collection data once collection starts (canonical: by Month 18 = 2028-04-08). Premium pilot dashboards for the 3-5 zones, Months 6-24 (2027-04-08 to 2028-10-08), with a check at Month 18 (2028-04-08). | Levy 60-80%: pre-authorise bonds and delay global rollout. Levy below 60%: activate the cascade and resize funding. Premium below 40%: stop premium scale-up and rely on paid inspector networks. |
| 4 | Is containment ready at the Month 36 (2029-10-08) gate (and on track at Month 24 = 2028-10-08)? | Month 24 (2028-10-08): 100-200 inspectors trained, at least 12 country commitment letters (15 targeted), regional compacts signed, 50 checkpoints equipped by Month 20 (2028-06-08). Month 36 (2029-10-08): at least 15 countries with enforceable rules in national law (Asia 8, Africa 4, Americas 3), at least 500 audited inspectors, at least 2 lab-cleared suspect detections. Release: 85-100% attainment gives 100% of the USD 4.5B tranche; 70-85% gives a proportional release; below 70% gives 50% (USD 2.25B). | Country legal audits, inspector audit records and lab confirmations (Month 24 = 2028-10-08 and Month 36 = 2029-10-08). Containment Efficacy Review in Months 72-84 (2032-10-08 to 2033-10-08) (at least 50 suspect detections). | Partial attainment: proportional tranche release, remainder to contingency. Fewer than 10 countries with enforceable rules at Month 48 (2030-10-08): stop scale-up and convert to a regional Asia-Africa compact. |
| 5 | Do at least 2 pyramided Hevea candidates pass the Month 84 (2033-10-08) cultivar gate, and does at least 1 reach commercial approval with adoption by 1.5 million smallholders by Month 144 (2038-10-08)? | Month 84 (2033-10-08): at least 2 candidates with at least 3 independent resistance genes from at least 2 sources, at least 90% resistance, at least 85% of elite-clone yield over 2+ years, Virulence Gate passed (80% of at least 10 isolates), 5+ year stability forecast. Month 144 (2038-10-08): at least 1 cultivar approved at 90% yield or better, and at least 1.5 million adopters. | Virulence Gate scorecards (Months 24, 36, 48, 60 = 2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08), Monte Carlo timeline (Month 6 = 2027-04-08), trial data to Month 84 (2033-10-08), adoption registry to Month 144 (2038-10-08). | One candidate: release 50% of the cultivar tranche and extend trials. No candidate with 3 genes passing a Virulence Gate by Month 60 (2031-10-08): cancel the pyramiding route and move funds to alternative rubber and containment. Emergency path: fast-track partial-resistance clones. |
| 6 | Is offtake secured and is alternative-rubber cost within the gate before any commercial hub is approved? | At least 2-3 OEM take-or-pay letters of intent (500-2,000 t/yr each) by Month 18 (2028-04-08). Priced offtake of at least 80% of planned volume checked at Month 60 (2031-10-08) and binding by Month 72 (2032-10-08). At Month 84 (2033-10-08): pilot cost at most USD 1.62/kg with tire-grade tests at 95% of Hevea specs; 20-25% premium is a partial score; above 25% stops scaling. Bankability needs at most about USD 1.47/kg and coverage of at least 1.3x. | Signed letters (Month 18 = 2028-04-08), offtake register (Months 60 and 72 = 2031-10-08, 2032-10-08), co-funded qualification tests (Months 12-30 = 2027-10-08 to 2029-04-08), pilot cost audit (Month 84 = 2033-10-08), permits and tire-grade specs validated. | Offtake below 80% at Month 60 (2031-10-08): defer hubs to Months 96-120 (2034-10-08 to 2036-10-08) (200,000 t/yr target at Month 144 = 2038-10-08 likely missed and re-set). Cost above 25% premium and offtake below 60%: stop commercial hubs and reduce the pillar to pilot and niche scale (5,000-20,000 t/yr). |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: premortem FM7 / review_plan Review 9 (open decision)
    canonical: mdb_repayment_open_decision = Open: who services the USD 7.0B concessional bank lending; about USD 449M/yr from about Month 60 (2031-10-08) (about USD 9.0B repaid in total) (estimate)
    observed:  Levy covers 40% of debt service (Review 9) vs tripwire of debt service above 30% of levy receipts (FM7); levy is USD 270M/yr vs USD 449M/yr debt service
HIGH CF-002  document: canonical_facts (hub_economic_chain vs year7_alt_rubber_cost_gate)
    canonical: hub_bankability_threshold = Debt financing only if opex is at most about USD 1.47/kg and coverage is at least 1.3x
    observed:  Gate limit USD 1.62/kg gives coverage 0.80 and exceeds the USD 1.55/kg offtake price cap
HIGH CF-003  document: review_plan Reviews 6, 8, 15
    canonical: year3_tranche = USD 4.5B tranche for Months 36-84 (2029-10-08 to 2033-10-08); remaining USD 19.5B released at Months 84, 144, 216 (2033-10-08, 2038-10-08, 2044-10-08) gates (split not set)
    observed:  70% of USD 10.5B breeding tranche; 50% = USD 5.25B; or USD 2.25B of USD 4.5B at the Year 7 gate
HIGH CF-004  document: pitch (Long-term Vision)
    canonical: total_budget_cap = USD 30 billion over Months 0-300 (hard cap, public-private) (user constraint)
    observed:  USD 30 billion recouped through avoided-loss savings
HIGH CF-005  document: executive_summary (Overall Takeaway) / review_plan
    canonical: reserves_inside_cap = Outbreak response reserve USD 0.5B (funded by Month 3 = 2027-01-08, ceiling USD 1.0B); total reserves USD 5.9B
    observed:  Increase Outbreak Response Reserve to USD 1.0-1.5 billion
HIGH CF-006  document: pitch (Gate 4, Long-term Vision)
    canonical: alt_rubber_volume_targets = Month 144 (2038-10-08): at least 200,000 t/yr (about 1.4%); Month 216 (2044-10-08): at least 5% of global demand (about 700,000 t/yr)
    observed:  200,000 t/yr at Month 216 (2044-10-08); Hevea dependence reduced to 85-90%
MEDIUM CF-007  document: review_plan / self_audit / premortem FM1
    canonical: levy_ramp_and_revenue = Design Months 6-12 (2027-04-08 to 2027-10-08); ASEAN pilot collecting by Month 18 (2028-04-08)
    observed:  Pilot by Month 12 (2027-10-08); compliance validated by Month 15 (2028-01-08)
MEDIUM CF-008  document: self_audit (#5, #14)
    canonical: protocol_adoption_timeline = Formal IPPC proposal by Month 18 (2028-04-08); formal adoption expected Months 36-60 (2029-10-08 to 2031-10-08); regional compacts and 15 letters by Month 24 (2028-10-08)
    observed:  NO-GO if formal IPPC adoption exceeds Month 42 (2030-04-08); plan 'assumes IPPC adoption in 18 months'
MEDIUM CF-009  document: executive_summary (Action Orientation) and premortem FM5
    canonical: resistance_architecture = Pathogen genomics lab in Brazil by Month 2 (2026-12-08), Asian satellite by Month 9 (2027-07-08)
    observed:  Operationalize labs in Months 6-12 (2027-04-08 to 2027-10-08); Brazil lab tripwire at Month 9 (2027-07-08)
MEDIUM CF-010  document: executive_summary / pitch
    canonical: year12_cultivar_gate = Month 144 (2038-10-08): at least 1 pyramided cultivar approved for commercial release with yield at least 90% of elite clones; adoption by at least 1.5 million smallholders
    observed:  Yield-parity cultivars released by Month 84 (2033-10-08); 85% described as yield parity
MEDIUM CF-011  document: executive_summary (Action Orientation)
    canonical: inspector_and_checkpoint_ramp = 100-200 inspectors trained by Month 24 (2028-10-08); at least 500 by Month 36 (2029-10-08); platform by Month 12 (2027-10-08)
    observed:  100-200 inspectors by Month 12 (2027-10-08); platform in Month 12-18 (2027-10-08 to 2028-04-08)
MEDIUM CF-012  document: pitch (Urgent 90-Day Priorities)
    canonical: germplasm_milestones = Nagoya/ABS negotiations complete Month 6 (2027-04-08) (slip trigger Month 12 = 2027-10-08); collection begins Month 8 (2027-06-08)
    observed:  Brazil germplasm access agreements must close in the next 90 days
```

### 1. Bank lending vs hard cap and levy capacity (🔴 High) — needs a project decision

- **Canonical facts: capital_stack, mdb_repayment_open_decision:** Capital stack counts USD 7.0B concessional lending inside the USD 30B hard cap; serviced at about USD 449M/yr from about Month 60 (2031-10-08), about USD 9.0B repaid in total (estimate).
- **Premortem FM7; Review Plan Reviews 9 and 11; Executive Summary feedback item 5:** Levy steady state is USD 270M/yr (below the debt service); FM1 and FM7 flag debt service above 30% of levy receipts as a tripwire, while Review 9 proposes 40% of repayment from levy (~USD 180M/yr, about 67% of levy).
- **Why it conflicts:** The levy cannot be the main payer without breaching the premortem tripwire. If repayments come out of cap-funded money, the USD 30B is not a hard cap on spendable programme funds (about USD 2B more is repaid than received). The documents never say whether repayment is inside or outside the cap.
- **Suggested resolution:** Decide before Month 3 (2027-01-08) who services the debt and whether repayments sit inside or outside the cap. Options: (a) sovereign grants as named payer; (b) blend of levy, royalties and hub revenue with the 30% tripwire revised; (c) convert part of the lending to grants or blended finance. Restate the net spendable budget under the chosen option.

### 2. Alternative-rubber gate cost vs offtake price and bankability (🔴 High) — needs a project decision

- **Canonical facts: year7_alt_rubber_cost_gate, hub_economic_chain; Pitch Gate 3:** Month 84 (2033-10-08) gate passes at pilot cost of at most USD 1.62/kg (20% over the USD 1.35/kg reference); offtake price is capped at USD 1,550/t (USD 1.55/kg).
- **Canonical facts: hub_bankability_threshold; Premortem FM3; Review Plan Review 9:** Debt financing needs opex of at most about USD 1.47/kg and coverage of at least 1.3x; at the gate limit coverage is 0.80 with a gap of about USD 12M/yr, so lenders decline (FM3).
- **Why it conflicts:** A hub that passes the gate has opex above the offtake price per kg and is unbankable by the plan's own test. The 50/50 financing split (USD 600M offtake-backed debt outside the cap) therefore fails at the gate limit, and the plan does not say what happens then.
- **Suggested resolution:** Decide one of: (a) tighten the gate to about USD 1.47/kg for debt-financed hubs; (b) raise the offtake cap above USD 1.55/kg; (c) program-finance 100% of capex (USD 1.2B inside the USD 7.5B pillar) with the dependent trade-offs stated. Record the choice in the Technical Gate Charter.

### 3. Gate tranche sizes at Month 84 (2033-10-08) (🔴 High)

- **Canonical facts: year3_tranche; Executive Summary Timeline and Budget:** USD 4.5B is the tranche for Months 36-84 (2029-10-08 to 2033-10-08), released under Month 36 (2029-10-08) gate rules; the remaining USD 19.5B is released at the Months 84, 144 and 216 (2033-10-08, 2038-10-08, 2044-10-08) gates, with the split not set.
- **Review Plan Review 6 KPI 2, Review 15 item 2, Review 8 item 2:** Month 84 (2033-10-08) cultivar gate releases 70% of 'USD 10.5B breeding tranche' (50% = USD 5.25B); elsewhere the Year 7 gate gives '50% tranche release (USD 2.25B of USD 4.5B)'.
- **Why it conflicts:** USD 10.5B is the 25-year breeding pillar, not a Month 84 (2033-10-08) tranche. USD 2.25B of USD 4.5B is the Month 36 (2029-10-08) below-70% rule, not the Month 84 (2033-10-08) gate. The Month 84 (2033-10-08) release amounts are not defined by any consistent figure.
- **Suggested resolution:** Express the Month 84 (2033-10-08) release as a percentage (70% / 50%) of the cultivar-phase share of the Month 84 (2033-10-08) allocation. Set that allocation as an explicit decision, since the USD 19.5B split is unset. Remove the USD 5.25B and USD 2.25B figures from the Year 7 context.

### 4. Programme cost 'recouped' by avoided losses (🔴 High)

- **Pitch, Long-term Vision:** 'The 25-year programme cost (USD 30 billion) is recouped through avoided-loss savings (USD 2-5B per prevented incursion, amortized over 25 years)'.
- **Review Plan Review 2 item 1; Review 8 item 1:** Review 2 puts total avoided-loss value across the horizon at USD 2-5B net benefit, discounted for a 10-30% incursion probability (estimate).
- **Why it conflicts:** A USD 2-5B benefit cannot recoup USD 30B. Recoupment would need about 6-15 prevented incursions, against an assumed 10-30% chance of one incursion per window.
- **Suggested resolution:** Delete the recoupment claim. Describe avoided loss as a partial offset, and present the case as resilience insurance, not payback.

### 5. Outbreak reserve size vs ceiling and reserve total (🔴 High) — needs a project decision

- **Canonical facts: reserves_inside_cap; Pitch; Project Plan:** Outbreak response reserve is USD 0.5B (ceiling USD 1.0B); reserves total USD 5.9B inside the cap.
- **Executive Summary Overall Takeaway; Review Plan Review 1 and Review 3 item 3:** Reserve must be raised to USD 1.0-1.5B by Month 3 (2027-01-08) to close the combined-stress gap.
- **Why it conflicts:** USD 1.5B exceeds the USD 1.0B ceiling. Reserves sit inside the cap, so the extra USD 0.5-1.0B must come out of the USD 4.5B contingency pool, which makes the stated USD 1.8B shortfall worse. The documents do not say where the money comes from.
- **Suggested resolution:** Keep USD 0.5B (ceiling USD 1.0B) until a decision is taken. Choose between: (a) raise the ceiling and fund the increase from the contingency pool, with the pool's pillar-level effect stated; (b) keep reserves unchanged and pre-position the outcome-linked bond fallback by Month 30 (2029-04-08). State the new reserve total either way.

### 6. Alternative-rubber target at Month 216 (2044-10-08) (🔴 High)

- **Canonical facts: alt_rubber_volume_targets; Executive Summary Phase 4:** Month 144 (2038-10-08): at least 200,000 t/yr (about 1.4% of demand). Month 216 (2044-10-08): at least 5% of global demand (about 700,000 t/yr).
- **Pitch, Metrics Gate 4 and Long-term Vision:** Gate 4 at Month 216 (2044-10-08): '200,000 t/yr alternative rubber commissioned'. Vision at Month 216 (2044-10-08): '200,000+ tonnes... reduce Hevea dependence to 85-90% of global supply'.
- **Why it conflicts:** 200,000 t/yr is the Month 144 (2038-10-08) target, about 1.4% of demand, and leaves Hevea near 98.6%. The Month 216 (2044-10-08) target is about 700,000 t/yr, and even that gives roughly 95%, not 85-90%.
- **Suggested resolution:** Set Gate 4 to at least 5% (about 700,000 t/yr). Keep 200,000 t/yr as the Month 144 (2038-10-08) milestone. Drop or recompute the 85-90% Hevea share.

### 7. Levy pilot start and compliance checkpoints (🟡 Medium)

- **Canonical facts: levy_ramp_and_revenue; Pitch:** Levy design Months 6-12 (2027-04-08 to 2027-10-08); ASEAN pilot collecting by Month 18 (2028-04-08) (about USD 40M/yr); global rollout at Month 36 (2029-10-08) if compliance exceeds 80%.
- **Review Plan Reviews 2, 5, 8; Self Audit #6; Premortem FM1:** Pilot operating by Month 12 (2027-10-08) ('six months early'), compliance validated by Month 15 (2028-01-08); FM1 early warning at Month 15 (2028-01-08) and tripwire at Month 18 (2028-04-08) for compliance below 60%.
- **Why it conflicts:** Month 12 (2027-10-08) is when design ends, not when collection begins. Compliance cannot be measured at Month 15-18 (2028-01-08 to 2028-04-08) if collection only starts by Month 18 (2028-04-08). The review also treats the 'pilot at Month 12 (2027-10-08)' as the plan.
- **Suggested resolution:** Keep the canonical Month 18 (2028-04-08) collection start (design Months 6-12 = 2027-04-08 to 2027-10-08). Move the compliance checkpoints and tripwires to a date after collection begins, or make acceleration an explicit decision with a pull-forward of the design phase.

### 8. IPPC adoption window vs cancel trigger (🟡 Medium)

- **Canonical facts: protocol_adoption_timeline; Pitch; Self Audit #5:** Formal IPPC proposal by Month 18 (2028-04-08); formal standard adoption expected Months 36-60 (2029-10-08 to 2031-10-08).
- **Self Audit #14 and #5:** Cancel the IPPC track if formal adoption exceeds Month 42 (2030-04-08) (or is delayed more than 24 months post-submission by Month 42 = 2030-04-08); the self-audit also describes the plan as allocating 18 months for IPPC adoption.
- **Why it conflicts:** A Month 42 (2030-04-08) cancel trigger falls inside the planned 36-60 window and would stop the track while it is still on schedule. The '18-month' description confuses the Month 18 (2028-04-08) submission date with the adoption date. Separately, the user's Phase 1 deliverable is a 'globally adopted' protocol, but formal adoption may come after Phase 1 ends.
- **Suggested resolution:** Align the trigger with the canonical window, for example cancel only if no adoption decision by Month 60 (2031-10-08), or define Month 42 (2030-04-08) as an escalation trigger only. State that Phase 1 delivers regional compacts and national rules, with formal IPPC adoption following.

### 9. Brazil genomics lab timing (🟡 Medium)

- **Canonical facts: resistance_architecture; Executive Summary Risk 2; Pitch:** Pathogen genomics lab in Brazil by Month 2 (2026-12-08); Asian satellite by Month 9 (2027-07-08).
- **Executive Summary Action Orientation; Premortem FM5; Self Audit #5, #13, #16:** Lab site selection in Months 0-3 (2026-10-08 to 2027-01-08) and 'operationalize pathogen genomics labs' in Months 6-12 (2027-04-08 to 2027-10-08) (Executive Summary); FM5 tripwire 'Brazil lab not operating at Month 9 (2027-07-08)' and early warning 'not sequencing by Month 12 (2027-10-08)'; biosafety approval takes 12-18 months and director recruitment 4-8 months.
- **Why it conflicts:** The lab cannot be both established by Month 2 (2026-12-08) and still in site selection or awaiting biosafety approval through Month 9-12 (2027-07-08 to 2027-10-08). The first Virulence Gate at Month 24 (2028-10-08) depends on this date.
- **Suggested resolution:** Define the milestones separately: Month 2 (2026-12-08) = lab established (site, partner host lab such as Embrapa or CEPLAC, director named); Month 9-12 (2027-07-08 to 2027-10-08) = operating and sequencing. Align the Executive Summary actions and FM5 tripwires, and flag whether biosafety approval can fit.

### 10. Cultivar release timing and 'yield parity' definition (🟡 Medium)

- **Canonical facts: year7_cultivar_gate, year12_cultivar_gate:** Month 84 (2033-10-08) gate: at least 2 candidates at 85% of elite yield. Month 144 (2038-10-08) gate: at least 1 cultivar approved for commercial release at 90% of elite yield ('yield parity') and 1.5 million adopters.
- **Executive Summary Purpose; Pitch Overview and Gate 2:** Cultivars 'released by Month 84 (2033-10-08)'; 'yield-parity resistant clones by Month 84 (2033-10-08)'; Pitch Gate 2 labels 85% as 'yield parity'.
- **Why it conflicts:** Month 84 (2033-10-08) is candidate readiness, with commercial approval at Month 144 (2038-10-08). Adoption by 1.5 million smallholders by Month 144 (2038-10-08) also needs planting material long before an approval at Month 144 (2038-10-08). Yield parity is 85% in one place and 90% in another.
- **Suggested resolution:** Rename the Month 84 (2033-10-08) milestone 'candidate readiness'. State whether limited commercial release is authorised from Month 84 (2033-10-08) so that adoption can run to Month 144 (2038-10-08). Use 90% for 'yield parity' and 85% as the Month 84 (2033-10-08) gate threshold.

### 11. Inspector ramp and platform timing (🟡 Medium)

- **Canonical facts: inspector_and_checkpoint_ramp; Premortem FM2 tripwire:** 100-200 inspectors trained by Month 24 (2028-10-08), at least 500 by Month 36 (2029-10-08); digital reporting platform by Month 12 (2027-10-08).
- **Executive Summary Action Orientation:** 'Recruit and train inspectors (100-200 by Month 12 = 2027-10-08)'; digital reporting platform listed in the Month 12-18 (2027-10-08 to 2028-04-08) block.
- **Why it conflicts:** The Executive Summary pulls the first inspector milestone 12 months earlier than the canonical value and the FM2 tripwire. It also schedules the platform after the inspectors it supports.
- **Suggested resolution:** Use Month 24 (2028-10-08) for 100-200 inspectors. Place the platform at or before Month 12 (2027-10-08). Fix the Executive Summary action list.

### 12. Brazil ABS agreement deadline in the pitch (🟡 Medium)

- **Canonical facts: germplasm_milestones; Pitch Ethical Considerations; Project Plan:** Nagoya/ABS negotiations complete by Month 6 (2027-04-08); collection begins Month 8 (2027-06-08); slip trigger Month 12 (2027-10-08).
- **Pitch, Urgent 90-Day Priorities:** 'Brazil's germplasm access agreements must close in the next 90 days' and 'Secure Brazil's formal germplasm-access agreement' as a 90-day priority.
- **Why it conflicts:** 90 days is Month 3 (2027-01-08), half the canonical time. Only framework agreements are planned for that point (Assumptions: framework by Month 3 = 2027-01-08). The pitch also calls Month 6 (2027-04-08) the deadline for the same item.
- **Suggested resolution:** Change the 90-day item to 'benefit-sharing framework drafted and negotiating team in place'. Keep Month 6 (2027-04-08) for completed agreements.

## Summary

The plan is mostly consistent on its core architecture: the gate months (36, 84, 144, 216), the pillar split, the USD 6.0B and USD 4.5B tranches, the reserves and the Month 36 (2029-10-08) criteria agree across documents. The serious problems are financial and economic. The bank-debt repayment, the hub gate versus offtake price and bankability, the Month 84 (2033-10-08) tranche amounts, the proposed reserve increase beyond its ceiling, and the pitch's 'cost recouped' claim do not reconcile. Several early-timeline items in the Executive Summary, pitch and review (inspectors, levy pilot, Brazil lab, ABS deadline) follow older assumptions and need correcting to the canonical values. The Month 216 (2044-10-08) target of 200,000 t/yr in the pitch should be at least 5% of demand. The go/no-go decisions in the first 18 months depend on binding funding, a named debt payer, and the germplasm, surveillance and offtake evidence.