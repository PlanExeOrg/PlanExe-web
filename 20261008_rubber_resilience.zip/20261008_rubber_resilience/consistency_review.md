## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Have at least 3 of the 5 top producers (Brazil, Indonesia, Thailand, Malaysia, Vietnam) signed binding Protocol-Adoption MoUs that name the quarantine agency and fund 20 inspector posts each? | At least 3 of 5 binding MoUs with penalty clauses by Month 6 (2027-04-12); at least 100 inspectors (20 per producer) active by Month 12 (2027-10-12). Premortem tripwire: fewer than 3 binding MoUs by Month 6 (2027-04-12). | Signed MoUs, written budget confirmations and named agencies from producer plant-protection agencies (Month 3-6 = 2027-01-12 to 2027-04-12); inspector headcount reports (Month 12 = 2027-10-12). | Freeze scale-up spending and withhold producer capacity grants. Re-scope Phase 1 to the compliant producers through a regional accord. Hard stop/re-scope if fewer than 3 have binding adoption by Month 54 (2031-04-12). The 7.0B Year 3 tranche is at risk. |
| 2 | Are the ABS agreements with Brazil CGen and at least 3 Amazonian community groupings executed in time to plant breeding trials at all 4 sites by Month 12 (2027-10-12)? | ABS agreements executed by Month 6 (2027-04-12); germplasm planted at 4 sites (Brazil, Thailand, Malaysia/Indonesia, Cote d'Ivoire) by Month 12 (2027-10-12). Zero slack: a slip beyond Month 12 (2027-10-12) moves the Year 7 gate to Month 96 (2034-10-12) or later. | Executed ABS agreements and CGen written processing timeline (Month 6 = 2027-04-12); site planting records and quarantine clearances (Month 9-12 = 2027-07-12 to 2027-10-12). | Delay: redirect planting to ex-situ accessions already held by partner institutes, and take a steering-council decision on the crown-budding fast-track (about USD 0.25B, outside the current plan). Otherwise formally move the Year 7 gate to Month 96 (2034-10-12). Do not leave the Month 84 (2033-10-12) gate in the plan with trials unplanted. |
| 3 | Are binding 25-year framework funding agreements signed with at least 5 sovereign/institutional funders, none above 20% (USD 6.0B), with an 80% minimum release floor and 45-day disbursement? | At least 5 binding agreements by Month 12 (2027-10-12); sovereign/MDB commitments about USD 26.3B plus levy about USD 3.7B; industry levy at about USD 150M/year (not below USD 120M/year). Premortem stop rule: binding commitments below USD 20B (proposed threshold) by Month 18 (2028-04-12) means no Phase 2 spending. | Executed framework agreements and levy commitment letters from the top 10 tire makers (Month 9-12 = 2027-07-12 to 2027-10-12); funder written positions on release floors and withdrawal penalties. | Downsize: do not release Phase 2 spending, re-sequence to containment and breeding only, and renegotiate floors. The 4.5B reserve must not be treated as substitute funding. |
| 4 | Does the Month 36 (2029-10-12) gate evidence show the Phase 1 containment deliverable is verified and the agreed gate definition of 'binding adoption' met? | IPPC adoption vote held; binding adoption in at least 3 of 5 producers; at least 100 inspectors active; red-team drills in at least 3 countries with at least 95% detection accuracy; no unmanaged incursion; at least 100,000 inspected lots/year (failure below 30,000). | Independent auditor verdict (auditor contracted Month 3 = 2027-01-12, scope pre-registered Month 6 = 2027-04-12), published within 30 days; adjudication within 60 days if contested (Month 36 = 2029-10-12). | Release only the partial-success floor (minimum 80% of USD 7.0B, proposed) or withhold; defer Phase 2 scale-up; re-scope at Month 54 (2031-04-12) if fewer than 3 producers have binding adoption. No scale-up before this gate. |
| 5 | Is the wave 1 plant investment bankable: are cost and process KPIs met, offtake secured at 70% or more of capacity, and the plant financing split decided? | Month 48 (2030-10-12): feedstock at most USD 1.20/kg (Guayule) and USD 1.00/kg (dandelion); extraction yield at least 85% / 80% and quality variance within +/-10% (Months 36 and 60 = 2029-10-12, 2031-10-12); delivered-cost forecast under 30% above Hevea (USD 2.60/kg at the USD 2.00/kg placeholder); purchase-option offtake at least 70% of capacity; 8 of 10 OEM letters of intent (Month 12 = 2027-10-12) converted to purchase options (Months 48-60 = 2030-10-12 to 2031-10-12). | Pilot extraction and feedstock data (Months 36-48 = 2029-10-12 to 2030-10-12), tire qualification results (Months 12-48 = 2027-10-12 to 2030-10-12), signed purchase-option contracts (Months 48-60 = 2030-10-12 to 2031-10-12), debt-capacity analysis and financing-split decision (Month 6 = 2027-04-12); portfolio decision at Month 60 (2031-10-12). | No wave 1 final investment decision (about Month 72 = 2032-10-12). Choose between added processing-innovation capital and redirecting wave 1 capex (USD 0.8-1.2B, estimate) to resistant-Hevea breeding, or defer plants beyond Year 12. The alternative-rubber pillar becomes a research hedge. |
| 6 | Do the Month 84 (2033-10-12) trials show cultivar readiness and smallholder enrolment sufficient to release the Year 7 tranche and scale replanting? | Yield at least 90% of elite clones (95%+ pass, 90-95% conditional, below 90% fail); at least 3 independent resistance sources confirmed in at least 5 field trials; lesion under 5 mm and defoliation 20% or less under 10x inoculation; at least 30% of eligible smallholders enrolled (stop trigger below 30%). | Independent auditor verdict on multi-site trial data (Month 84 = 2033-10-12); enrolment records against the Month 6 (2027-04-12) baseline willingness survey (stop-trigger scenarios below 30% willingness) and the 10,000-farm bridging pilot default rates (Month 36 = 2029-10-12). | Withhold or release only the conditional share of the USD 6.5B Year 7 tranche; activate the crown-budding hedge or move the gate to Month 96 (2034-10-12). If enrolment is under the trigger, cut smallholder targets 40% and reallocate to estate trials or processing. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: canonical_facts
    canonical: phase1_gate_criteria_month36 = binding national embedding in at least 3 of the top 5 producers at Month 36 (2029-10-12)
    observed:  national embedding completes Months 36-48 (2029-10-12 to 2030-10-12); stop threshold Month 54 (2031-04-12)
HIGH CF-002  document: pitch
    canonical: open_decision_plant_financing_split = Open decision: program vs OEM/partner/project finance; budget counts 100% = USD 1.6B until decided
    observed:  co-investors, project finance, binding offtake contracts, secured margins, self-financing
HIGH CF-003  document: canonical_facts
    canonical: alt_rubber_cost_kpis = delivered cost under 30% above Hevea at Month 144 (2038-10-12); at most 15% at Month 216 (2044-10-12)
    observed:  offtake price USD 2.20/kg (10% premium) with opex USD 2.50/kg
HIGH CF-004  document: pitch Risks and Mitigation (Adoption risks); review_plan KPI 2
    canonical: adoption_waypoints = Month 84 (2033-10-12): at least 30% enrolled (stop trigger below 30%); Month 144 (2038-10-12): at least 40% of eligible area replanted
    observed:  stop trigger below 25% by Month 84 (2033-10-12); reallocation USD 1.5-2.0B vs USD 0.8-1.2B
HIGH CF-005  document: pitch
    canonical: smallholder_price_floor = Minimum price guarantee 90% of Hevea benchmark (proposed threshold)
    observed:  "Price floors are binding" with no funded line
HIGH CF-006  document: self_audit
    canonical: year7_cultivar_gate_criteria = 95%+ pass, 90-95% conditional, below 90% fail; Month 48 (2030-10-12) trigger below 85%
    observed:  85-90% conditional pass with 50% release; Month 48 (2030-10-12) trigger at below 90%
MEDIUM CF-007  document: pitch Risks and Mitigation
    canonical: fallback_crown_budding = about USD 0.25B (estimate); needs new steering-council decision; funded from USD 13.9B unallocated balance
    observed:  "already in budget"; no further council approval; pre-commit by Month 18 (2028-04-12)
MEDIUM CF-008  document: review_plan Review 14
    canonical: gate_tranche_allocation = USD 3.5B Months 0-36 (2026-10-12 to 2029-10-12); 7.0B; 6.5B; 4.5B; 4.0B (sum USD 25.5B)
    observed:  USD 21.5B tranches; remaining USD 4.0B covers Phase 5
MEDIUM CF-009  document: executive_summary Key Deliverables
    canonical: alt_rubber_volume_and_land = 16,000 t/year by Month 120 (2036-10-12) (wave 1); 32,000 t/year by Month 192 (2042-10-12); about 0.2% of the market
    observed:  8,000 t/year wave 1; 32,000 t/year by Month 144 (2038-10-12); 10-20% OEM share
MEDIUM CF-010  document: premortem FM2/FM8; review_plan Reviews 2 and 13; self_audit
    canonical: alt_rubber_cost_kpis = feedstock at most USD 1.20/kg and 1.00/kg at Month 48 (2030-10-12); yield at least 85%/80% at Months 36 and 60 (2029-10-12, 2031-10-12)
    observed:  feedstock >= USD 1.40/kg or yield <= 75% as trigger
MEDIUM CF-011  document: premortem FM1 and FM9
    canonical: delivery_workforce_targets = at least 100 compliance inspectors (20 per top-5 producer) by Month 12 (2027-10-12)
    observed:  fewer than 60 inspectors at Month 12 (2027-10-12) (FM1); fewer than 60 at Month 24 (2028-10-12) (FM9 stop rule)
LOW CF-012  document: pitch
    canonical: program_duration_and_start = 25 years = Months 0-300; start Month 0 (2026-10-12)
    observed:  Months 36-300 = 2029-10-12 to 2035-10-12; Month 300 = 2035-10-12; within 120 days
```

### 1. Month 36 (2029-10-12) gate requires national embedding that completes after Month 36 (2029-10-12) (🔴 High) — needs a project decision

- **Canonical phase1_gate_criteria_month36; project_plan SMART/Measurable; pitch Month 36 (2029-10-12) gate:** Month 36 (2029-10-12) gate: IPPC vote held and "binding national embedding in at least 3 of the top 5 producers" (the project plan repeats this in its Measurable criteria).
- **Canonical protocol_milestones and protocol_stop_threshold; executive_summary Risks (1); premortem FM1:** "National embedding completes Months 36-48 (2029-10-12 to 2030-10-12)"; stop/re-scope only if fewer than 3 have binding adoption by Month 54 (2031-04-12); executive summary says missing embedding by Month 54 (2031-04-12) "invalidat[es] Year 3 gate".
- **Why it conflicts:** The gate that releases USD 7.0B at Month 36 (2029-10-12) cannot verify an embedding that is scheduled to finish up to 12 months later, and the stop test sits 18 months after the gate. The documents use "binding adoption" to mean signed agreements in some places and enacted national law in others.
- **Suggested resolution:** Decision needed on what the Month 36 (2029-10-12) gate actually tests. Options: (a) gate on signed binding Protocol-Adoption Agreements, budgeted inspector posts and named agencies, with law-level embedding verified at Month 48/54 (2030-10-12, 2031-04-12) as a holdback condition on part of the tranche; (b) require enacted embedding before Month 36 (2029-10-12) and re-plan the embedding schedule; (c) move the embedding test and the stop threshold to a single date. Define 'binding' in the auditor's pre-registered scope.

### 2. Plant financing: pitch asserts co-investment, project finance and margins that the financing split and unit economics do not support (🔴 High) — needs a project decision

- **pitch: Collaboration Opportunities, Stakeholder Benefits, Long-term Vision:** Pitch: Bridgestone and Continental "invited as co-investors... in wave 1 plants"; "banks and DFIs structure project finance"; "OEMs write binding offtake contracts"; "OEM offtake contracts secure alternative-rubber margins"; programme becomes "self-financing from levy revenues".
- **Canonical open_decision_plant_financing_split, alt_rubber_debt_and_coverage, alt_rubber_operating_gap, oem_offtake_structure; executive_summary Feedback (1); review_plan Review 11/14:** Plant financing split is an open decision (budget counts 100% program-financed, USD 1.6B); base-case senior debt USD 0; at 50% debt DSCR about -0.1 (not bankable); operating shortfall USD 9.6M/year; offtake is purchase-option contracts with a 1.5% reservation fee, not firm take-or-pay.
- **Why it conflicts:** The pitch presents unresolved financing, binding offtake and positive margins as facts, while the other documents show them as open decisions with negative coverage. The pitch also counts on levy-funded self-financing although funding terms beyond Month 216 (2044-10-12) are not documented.
- **Suggested resolution:** Decision needed: who finances the plant capex (program 100%, OEM/partner co-financing, or project finance) and who absorbs the operating gap and any debt service. Until decided, the pitch should say purchase-option contracts, program-financed base case, and co-investment 'sought'. Resolve at the Month 6 (2027-04-12) budget baseline, before the Month 60 (2031-10-12) portfolio decision.

### 3. Year 12 cost gate permits costs above the assumed offtake price (🔴 High) — needs a project decision

- **Canonical alt_rubber_cost_kpis; premortem FM2 stop rule; project_plan Measurable:** Gate passes at delivered cost under 30% above Hevea (below USD 2.60/kg on the USD 2.00/kg placeholder); final KPI is at most 15% above (USD 2.30/kg); FM2 stop rule allows FID on a forecast under 30% above Hevea.
- **Canonical hevea_benchmark_and_offtake_price, alt_rubber_annual_opex, alt_rubber_operating_gap:** Offtake price is benchmark +10% = USD 2.20/kg; all-in operating cost USD 2.50/kg already gives a USD 9.6M/year shortfall (recomputed: at USD 2.60/kg and 32,000 t/year the gap would be about USD 12.8M/year).
- **Why it conflicts:** A cost that passes both the FID rule and the Year 12/Year 18 gates is still above the price OEMs are assumed to pay, so passing the gates does not make plants financeable.
- **Suggested resolution:** Decision needed: either tighten the cost KPI and FID rule so the forecast cost is at or below the assumed offtake price (or break-even including the reservation fee), negotiate a higher premium, or name the party that absorbs the structural gap and size the loss line accordingly (the USD 0.6B line only covers about USD 115M at USD 2.50/kg).

### 4. Smallholder stop trigger: threshold, date and reallocation amount differ (🔴 High)

- **Canonical adoption_waypoints and smallholder_uptake_target; review_plan Review 2 item 3 ("below the 30% stop-gate threshold"):** Month 84 (2033-10-12): at least 30% of eligible smallholders enrolled, stop trigger below 30%; Month 144 (2038-10-12): at least 40% of area replanted; planning uptake 45%.
- **pitch Adoption risks; review_plan KPI 2, Review 1/5; executive_summary Goals; project_plan Measurable:** Pitch: "stop trigger halts expansion if enrollment falls below 25% by Month 84 (2033-10-12)"; review KPI 2: "30% by Month 84 (2033-10-12) (Stop Trigger <25%)"; other documents use <25% at Month 54 (2031-04-12), with reallocation USD 0.8-1.2B (premortem, executive summary) or USD 1.5-2.0B (Review 1 item 3, Review 5 item 2); executive summary lists 45% as a goal and gate KPI.
- **Why it conflicts:** The same stop trigger is stated with different thresholds (25% vs 30%), dates (Month 54 = 2031-04-12 vs Month 84 = 2033-10-12) and reallocation sizes. Recomputed: a 40% cut of the USD 6.75B line is about USD 2.7B gross, matching neither range. The 45% planning figure is also presented as a gate target although the gate is 40%.
- **Suggested resolution:** Keep the canonical waypoints: stop trigger below 30% at Month 84 (2033-10-12), 40% area at Month 144 (2038-10-12), 45% as planning case only. If a Month 54 early-warning level of 25% is retained, label it as an interim tripwire. State a single reallocation amount recomputed from the undisbursed share of the USD 6.75B line.

### 5. Price-floor guarantee is binding but has no budget line or payer (🔴 High) — needs a project decision

- **pitch Ethical Considerations/Stakeholder Benefits; canonical smallholder_price_floor:** Price floors are "binding (90% of Hevea)" for resistant-cultivar and alternative-crop output; guaranteed to smallholders.
- **Canonical documented_budget_lines and replant_finance_cost; self_audit item 15:** Documented budget lines have no price-floor line; the smallholder line (USD 6.75B) equals exactly 2.25M ha x USD 3,000 for replant/bridging. Self-audit puts price-floor fiscal exposure at USD 50-200M/year (estimate) and notes it creates a funder-withdrawal incentive.
- **Why it conflicts:** A binding guarantee of up to USD 50-200M/year (estimate) over roughly 17+ years has no funding source inside the USD 30B cap, so it is either unfunded or competes with the replant line.
- **Suggested resolution:** Decision needed on who pays the floor: fund from the USD 13.9B unallocated balance at the Month 6 (2027-04-12) baseline, from the levy, cap and sunset the guarantee (e.g., limited years, volume cap), or make it non-binding. Add the line to the budget either way.

### 6. Year 7 yield pass bands and Month 48 (2030-10-12) trigger (🔴 High)

- **Canonical year7_cultivar_gate_criteria and breeding_trigger_month48:** Year 7: 95%+ pass, 90-95% conditional, below 90% fail; Month 48 (2030-10-12) crown-budding decision starts if yield penalty exceeds 15% (below 85% of elite).
- **self_audit items 2 and 8; review_plan Reviews 8 and 10:** Self-audit: "85-90% = conditional pass, release 50% of tranche; 90%+ = full pass"; and "if breeding yield <90% of elite at Month 48 (2030-10-12), activate crown-budding fast-track or fail gate". Review 8/10 propose lowering the threshold to 85-90%.
- **Why it conflicts:** The conditional band, pass line and Month 48 (2030-10-12) trigger are all shifted, and the Month 84 (2033-10-12) gate pass line is applied as a Month 48 (2030-10-12) trigger. This changes the gate decision and the amount of tranche released.
- **Suggested resolution:** Keep the canonical bands (95%+/90-95%/below 90%) and the 85% Month 48 (2030-10-12) trigger, locked in the pre-registered protocol by Month 6 (2027-04-12). Treat any change as a formal amendment, not a recommendation.

### 7. Crown-budding hedge: budget status, approval route and date (🟡 Medium)

- **Canonical fallback_crown_budding, year7_timeline_slack:** Fast-track is about USD 0.25B (estimate), outside the plan, needs a new steering-council decision, funded from the USD 13.9B unallocated balance; the planting deadline it hedges is Month 12 (2027-10-12).
- **pitch Technical risks; self_audit items 4 and 19; executive_summary Risks (2); review_plan Reviews 4, 11, 13:** Pitch: "USD 0.25 billion, already in budget" and "activated if yield penalty exceeds 15%"; self-audit: activate "without further Steering Council approval"; executive summary and review pre-commit it only "by Month 18 (2028-04-12)" (to handle a slip at Month 12-15 = 2027-10-12 to 2028-01-12), while Review 11 says Month 9 (2027-07-12).
- **Why it conflicts:** The hedge is described as budgeted and auto-activated, but it is not a documented budget line and requires a decision. Pre-committing at Month 18 (2028-04-12) comes after the Month 12 (2027-10-12) planting deadline and the Month 15 (2028-01-12) slip it is meant to cover.
- **Suggested resolution:** State that the hedge is unbudgeted and funded from the unallocated balance. Have the steering council approve pre-authorisation by Month 9 (2027-07-12) (before the Month 12 = 2027-10-12 planting deadline), with the Month 48 (2030-10-12) trigger as the start of the decision.

### 8. Gate tranche arithmetic and Phase 5 funding (🟡 Medium)

- **Canonical gate_tranche_allocation, tranche_release_rules; self_audit item 6 (USD 22.0B):** Gate tranches USD 7.0B + 6.5B + 4.5B + 4.0B = USD 22.0B; the remaining USD 3.5B of the USD 25.5B is the Months 0-36 (2026-10-12 to 2029-10-12) allocation; binding 25-year framework agreements by Month 12 (2027-10-12).
- **review_plan Review 14 item 2; executive_summary Feedback (5):** Review 14: tranches "totalling USD 21.5B of deployable USD 25.5B. Remaining USD 4.0B covers Phase 5"; framework agreements "specify disbursement only through Month 216 (2044-10-12)".
- **Why it conflicts:** The sum is USD 22.0B, not 21.5B, and the remainder is 3.5B already assigned to Months 0-36 (2026-10-12 to 2029-10-12), so it cannot also fund Phase 5. 'Disbursement through Month 216 (2044-10-12)' also conflicts with '25-year framework agreements'.
- **Suggested resolution:** Correct to USD 22.0B and USD 3.5B. Treat the Year 18 tranche (USD 4.0B) as the Phase 5 (Months 216-300) funding and state in the framework agreements what covers Months 216-300.

### 9. Alternative-rubber volumes and share (🟡 Medium)

- **Canonical alt_rubber_unit_definition, commercial_plant_program, alt_rubber_volume_and_land:** Wave 1 (4 plants x 4,000 t/year sold) = 16,000 t/year by Month 120 (2036-10-12); 32,000 t/year only by Month 192 (2042-10-12) after wave 2; 32,000 t/year is about 0.2% of the market and the 20-30% offtake share is not a KPI.
- **executive_summary Key Deliverables; review_plan Review 13 item 3; pitch Long-term Vision (OEM diversification):** Executive summary: wave 1 "4 plants, 8,000 t/year"; Review 13: alternative supply "fails to reach 32,000 t/year target" by Month 144 (2038-10-12); pitch: tire makers "source 10-20% non-Hevea rubber from alternatives".
- **Why it conflicts:** 8,000 t/year is half the canonical wave 1 volume; 32,000 t/year is not due at Month 144 (2038-10-12) (wave 2 follows that gate); and a 10-20% share contradicts the pitch's own 0.2% figure.
- **Suggested resolution:** Use 16,000 t/year at Month 120 and 32,000 (2036-10-12, 2029-06-12, 2026-10-12) t/year by Month 192 (2042-10-12); remove the 10-20% OEM share claim or state it as 0.2% of global natural rubber.

### 10. Alternative-rubber failure triggers differ from the KPI targets (🟡 Medium)

- **Canonical alt_rubber_cost_kpis, portfolio_decision_month60; review_plan Review 1 item 2:** Month 48 (2030-10-12) feedstock at most USD 1.20/kg (Guayule) / 1.00 (dandelion); extraction yield at least 85% / 80% at Months 36 and 60 (2029-10-12, 2031-10-12); if targets are missed by Month 60 (2031-10-12), portfolio decision (no wave 1 commitment before it).
- **premortem FM2 and FM8 tripwires; review_plan Review 2 item 2, Review 13 item 3; self_audit item 2:** Tripwires use feedstock >= USD 1.40/kg at Month 48 (2030-10-12) and Guayule extraction yield <= 75% at Month 36 (2029-10-12); Review 13 and self-audit trigger reallocation at feedstock >= 1.40 or yield < 75% at Month 48 (2030-10-12).
- **Why it conflicts:** Results between the target and the tripwire (e.g., feedstock USD 1.30/kg, yield 80%) are a KPI miss but not a trigger, so it is unclear whether the Month 60 (2031-10-12) decision rule applies. The Month 48 (2030-10-12) vs Month 60 (2031-10-12) decision point also varies.
- **Suggested resolution:** Use the canonical targets as the pass/fail test for the Month 60 (2031-10-12) decision. If 1.40/kg and 75% are retained, label them as early-warning levels that start the cost-down audit, not as the decision rule.

### 11. Inspector headcount thresholds (🟡 Medium)

- **Canonical delivery_workforce_targets and phase1_gate_criteria_month36; premortem FM9:** At least 100 inspectors (20 per producer) by Month 12 (2027-10-12); Month 36 (2029-10-12) gate requires at least 100 inspectors active; FM9 tripwire: fewer than 100 at Month 12 (2027-10-12).
- **premortem FM1 tripwires and early warnings; premortem FM9 stop rule:** FM1 tripwire: "fewer than 60 inspectors active at Month 12 (2027-10-12)"; FM9 stop rule: defer the Month 36 (2029-10-12) gate if fewer than 60 inspectors at Month 24 (2028-10-12).
- **Why it conflicts:** A Month 12 (2027-10-12) shortfall of 40 posts does not trip FM1, and the Month 24 (2028-10-12) stop rule accepts 60 although the gate needs 100 at Month 36 (2029-10-12). The two failure modes use different alarm levels for the same measure.
- **Suggested resolution:** Set a single ladder: 100 at Month 12 (2027-10-12) (canonical), with a stated interim tripwire and a Month 24 (2028-10-12) level consistent with reaching 100 by Month 36 (2029-10-12); mark any lower level as a proposed threshold.

### 12. Pitch end-date and urgency errors (⚪ Low)

- **Canonical program_duration_and_start; pitch Call to Action deadlines:** Programme is Months 0-300 and ends at Month 300 (2051-10-12); binding funding agreements due Month 12 (2027-10-12), producer MoUs Month 6 (2027-04-12), auditor Month 3 (2027-01-12).
- **pitch Project Overview, Long-term Vision, Call to Action:** Pitch: "Phase 2-5 (Months 36-300, 2029-10-12 to 2035-10-12)"; "By Month 300 (2035-10-12)"; and "Within 120 days, the following commitments are required" while listing Month 6 (2027-04-12) and Month 12 (2027-10-12) deadlines.
- **Why it conflicts:** Month 300 is 2051-10-12, not 2035-10-12 (that is about Month 108 = 2035-10-12). '120 days' is about Month 4 (2027-02-12), shorter than the Month 6 (2027-04-12) and Month 12 (2027-10-12) deadlines listed under it.
- **Suggested resolution:** Correct both dates to Month 300 (2051-10-12), and replace '120 days' with the stated Month 3/6/12 (2027-01-12, 2027-04-12, 2027-10-12) deadlines (or state what is due within 120 days).

## Summary

The plan is consistent on its headline structure: 25 years, USD 30B cap, USD 25.5B deployable plus USD 4.5B reserve, gates at Months 36/84/144/216 (2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12) and the plant unit economics (USD 70.4M revenue, USD 80.0M opex, USD 9.6M gap, DSCR about -0.1) reconcile arithmetically. Weaknesses cluster in three places: (1) structural design gaps that no value settles, namely the Month 36 (2029-10-12) gate testing an embedding scheduled for Months 36-48 (2029-10-12 to 2030-10-12), a cost gate that passes above the assumed offtake price, an open plant-financing split, and an unbudgeted binding price floor; (2) the pitch and self-audit drifting from canonical thresholds, dates and claims (stop trigger, yield bands, crown-budding status, volumes, Month 300 date); and (3) a few arithmetic slips (tranche total, wave 1 volume). The repairable items are quick to fix; the needs_decision items should be settled at the Month 6 (2027-04-12) budget baseline, before capital is released.