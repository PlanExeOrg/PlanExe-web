A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Producer nations (Brazil, Indonesia, Thailand, Malaysia, Vietnam) will convert MoUs into funded inspectors and binding national law, though IPPC embedding leaves enforcement sovereignty with them. | Request written budget confirmations and draft legal pathways from the national plant protection agencies of three producers, including named agency and inspector funding lines. | Fewer than 3 of 5 producers confirm funded inspector posts (20 each) or a legislative embedding route, or any refuses penalty clauses. |
| A2 | Alternative rubber can reach delivered cost under 30% above Hevea and OEMs will pay a 10% premium (estimate) sufficient to finance commercial plants. | Interview the top 10 OEMs on maximum acceptable premium and qualification thresholds; have two technology partners cost pilot extraction against the USD 2.50/kg target. | Fewer than 8 OEMs accept a premium of 5% or more, or independent pilot cost estimates exceed USD 3.00/kg (estimate). |
| A3 | Smallholders will enrol and replant at about 45% planning uptake (historical 20-40%, not verified) under income-bridging finance, and extension staff can be retained for decades. | Run the baseline willingness survey on 2,000 farms in two countries with 60-70% income-bridging terms, and benchmark extension turnover in existing rubber programs. | Stated willingness to replant is below 30%, or observed extension turnover exceeds 40% a year in benchmark programs. |
| A4 | Sovereign and development-bank funders will sign legally binding 25-year framework agreements by Month 12 (2027-10-12) with 80% minimum release (proposed threshold) and 45-day disbursement, and the industry levy (about USD 150M/year, estimate) will hold at full participation. | Circulate a term sheet to five candidate funders and the top 10 tire makers, requesting written positions on release floors, force-majeure language, withdrawal penalties and levy commitment length. | Fewer than 5 funders accept binding minimum-funding floors, or tire makers representing under 80% of covered purchases decline a multi-year levy commitment. |
| A5 | ABS agreements with Brazil CGen and at least 3 Amazonian community groupings can close by Month 6 (2027-04-12), and germplasm can be planted at 4 sites by Month 12 (2027-10-12) with zero slack to the Year 7 gate. | Have ABS counsel obtain written CGen processing timelines and hold exploratory consultations with 3 community groupings on consent terms and co-governance expectations. | CGen or any community grouping indicates a timeline beyond Month 12 (2027-10-12), or demands veto rights over cultivar licensing that exceed the proposed benefit-sharing terms. |
| A6 | The independent auditor will obtain timely, unfiltered data from national agencies, breeding partners and estates, so gate verdicts will be accepted by funders and producers without extended dispute. | Draft the audit contract and data-access schedule, then ask national agencies and breeding partners to sign data-sharing undertakings with a 5-business-day response window. | Fewer than 4 of 5 producer agencies or any of the 4 breeding-trial hosts refuse binding data-access clauses or penalties for delay. |
| A7 | Eradication-first doctrine with the USD 0.5 billion prefunded compensation fund will be accepted by growers, who will report suspected SALB infections rather than conceal them. | Hold structured focus groups with growers in 3 districts of 2 producers, presenting the compensation schedule and destruction rules, and record stated reporting intent. | Fewer than 60% (proposed threshold) of participating growers say they would report and accept destruction, or the fund is sized below modelled single-site compensation. |
| A8 | Guayule and dandelion sites will have enough water, land tenure and stable yields through 2050 to supply 16,000 t/year by Month 120 (2036-10-12) without more than 25% yield loss. | Commission water-balance and tenure screening for at least 5 candidate sites per crop under 1.5, 2 and 3 degrees C scenarios, with groundwater reserve checks. | Modelled yield loss exceeds 25% at 3 or more candidate sites per crop, or groundwater reserve is under 10 years (proposed threshold) at proposed extraction rates. |
| A9 | Skilled personnel (molecular diagnosticians, perennial-crop breeders, extraction engineers, inspectors) can be hired and retained at planned numbers by Month 12 (2027-10-12) and sustained across 25 years. | Survey national institutes and labs in 5 producers on available qualified staff, salary gaps and attrition history; test recruitment for 10 key posts. | Fewer than 70% (proposed threshold) of the 10 key posts are filled within 90 days, or benchmark annual attrition exceeds 30% (estimate). |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Signed-but-Hollow Protocol | Process/Financial | A1 | SALB Containment Protocol Director | CRITICAL (20/25) |
| FM2 | The Stranded Extraction Plants | Technical/Logistical | A2 | Alternative-Rubber Processing & OEM Engagement Lead | CRITICAL (16/25) |
| FM3 | The Orchard Nobody Planted | Market/Human | A3 | Smallholder Adoption Finance & Extension Delivery Manager | CRITICAL (16/25) |
| FM4 | The Handshake Funding Cliff | Process/Financial | A4 | Financial Planning, Capital Structuring & Funder Relations Director | CRITICAL (15/25) |
| FM5 | The Seedlings That Never Left Quarantine | Technical/Logistical | A5 | Hevea Resistance Breeding Program Director & Germplasm Lead | CRITICAL (20/25) |
| FM6 | The Verdict Nobody Believed | Market/Human | A6 | Gate Evidence Verification & Independent Audit Director | HIGH (12/25) |
| FM7 | The Compensation Fund That Ran Dry | Process/Financial | A7 | Surveillance, Detection & Incursion Response Coordinator | CRITICAL (15/25) |
| FM8 | The Thirsty Fields | Technical/Logistical | A8 | Alternative-Rubber Processing & OEM Engagement Lead | HIGH (12/25) |
| FM9 | The Empty Laboratory Benches | Market/Human | A9 | Program Governance, Strategic Coordination & Long-Term Sustainability Manager | CRITICAL (16/25) |


### Failure Modes

#### FM1 - The Signed-but-Hollow Protocol

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: SALB Containment Protocol Director
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- Months 0-6 (2026-10-12 to 2027-04-12): MoUs signed as diplomatic statements, not budgeted law.
- Inspector funding never enters national budgets; fewer than 100 inspectors active.
- Month 36 (2029-10-12) gate criteria unverifiable; USD 7.0B Year 3 tranche withheld.
- Funders invoke annual budget cycles; levy partners pause contributions.
- Re-scope at Month 54 (2031-04-12) forces program restructuring.

##### Early Warning Signs
- Fewer than 3 MoUs signed with penalty clauses by Month 6 (2027-04-12)
- Inspector hiring below 60 by Month 12 (2027-10-12)
- Quarterly compliance scorecards late by more than 30 days

##### Tripwires
- Fewer than 3 of 5 binding MoUs signed by Month 6 (2027-04-12)
- Fewer than 60 inspectors active at Month 12 (2027-10-12)
- Annual inspected lots below 30,000 at Month 24 (2028-10-12)

##### Response Playbook
- Contain: Freeze scale-up spending and withhold producer capacity grants where funded inspector posts are missing.
- Assess: Commission an independent audit of each producer's legal status, budget lines and inspector headcount within 30 days.
- Respond: Trigger the regional fallback accord with the compliant producers and re-sequence the Month 36 (2029-10-12) gate with funder consent.


**STOP RULE:** Cancel or re-scope Phase 2 if fewer than 3 of top-5 producers have binding adoption by Month 54 (2031-04-12).

---

#### FM2 - The Stranded Extraction Plants

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Alternative-Rubber Processing & OEM Engagement Lead
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Pilot extraction yields land at 75-80%, below the 85% Guayule target.
- Feedstock stays above USD 1.40/kg; contaminants cause quality variance beyond +/-10%.
- Operating gap of USD 9.6M/year (estimate) per program, DSCR negative.
- Tire qualification fails on tread wear or rolling resistance.
- Plant capex of up to USD 1.6B is exposed if committed before cost proof.

##### Early Warning Signs
- Pilot extraction yield under 80% at Month 36 (2029-10-12)
- Feedstock cost above USD 1.40/kg at Month 48 (2030-10-12)
- Tire test tread wear below 93% of Hevea

##### Tripwires
- Guayule extraction yield <= 75% at Month 36 (2029-10-12)
- Feedstock cost >= USD 1.40/kg at Month 48 (2030-10-12)
- Fewer than 8 of 10 OEM letters of intent at Month 12 (2027-10-12)

##### Response Playbook
- Contain: Halt wave 1 site works and procurement; keep pilots operating only.
- Assess: Run independent cost-down audit with three technology partners and re-model unit economics within 60 days.
- Respond: At the Month 60 (2031-10-12) decision, fund processing innovation or redirect wave 1 capital to resistant-Hevea breeding.


**STOP RULE:** No wave 1 final investment decision unless delivered-cost forecast is under 30% above Hevea and offtake covers at least 70% of capacity.

---

#### FM3 - The Orchard Nobody Planted

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Smallholder Adoption Finance & Extension Delivery Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Smallholders distrust unproven clones and bridging terms.
- Extension turnover of 30-50% (estimate) erodes agent trust.
- Enrolment lags; price shocks prompt abandonment of replanted plots.
- Extension and nurseries become under-used; USD 2-3B (estimate) stranded.
- Fewer farmer reports weaken surveillance.

##### Early Warning Signs
- Baseline willingness survey under 35%
- Pilot default rate above 20%
- Monthly enrolment under 5,000 farmers for 2 months

##### Tripwires
- Enrolment below 25% of eligible at Month 54 (2031-04-12)
- Extension agent retention below 50% at Month 60 (2031-10-12)
- Bridging-finance default above 20% in pilot by Month 36 (2029-10-12)

##### Response Playbook
- Contain: Pause new nursery and agent hiring and hold undisbursed replant finance.
- Assess: Survey 1,000 enrolled and lapsed farmers on barriers within 45 days.
- Respond: Redesign finance terms and price floor, retrain agents, and reallocate USD 0.8-1.2B to estate trials if still short.


**STOP RULE:** Reduce smallholder targets by 40% and reallocate funds if enrolment is below 25% of eligible smallholders at Month 54 (2031-04-12).

---

#### FM4 - The Handshake Funding Cliff

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Financial Planning, Capital Structuring & Funder Relations Director
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Framework agreements are signed as statements of intent without enforceable release floors.
- Sovereign budget cycles and a levy shortfall reduce deployable capital below USD 25.5B.
- A partial Year 3 gate triggers tranche disputes; disbursement exceeds 45 days.
- The USD 4.5B reserve is drawn to cover operating gaps, leaving less for shocks.
- Extension and nursery commitments stall.

##### Early Warning Signs
- Fewer than 5 funders signed by Month 9 (2027-07-12)
- Levy pledges cover under 80% of covered purchases
- Funder legal review exceeds 90 days

##### Tripwires
- Fewer than 5 binding framework agreements by Month 12 (2027-10-12)
- Any single funder above 20% of commitments (USD 6.0B)
- Levy receipts below USD 120M/year at Month 60 (2031-10-12) (proposed threshold)

##### Response Playbook
- Contain: Freeze new multi-year contracts and non-essential disbursements until committed capital is reconciled.
- Assess: Stress-test the capital stack under loss of 2 funders and 30% levy erosion within 45 days.
- Respond: Re-sequence workstreams toward containment and breeding, and renegotiate floors with funders or draw the ring-fenced reserve under adjudication.


**STOP RULE:** Do not release Phase 2 spending if binding commitments cover less than USD 20 billion (proposed threshold) by Month 18 (2028-04-12).

---

#### FM5 - The Seedlings That Never Left Quarantine

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Hevea Resistance Breeding Program Director & Germplasm Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- ABS consent negotiations run beyond Month 12 (2027-10-12).
- Germplasm transfer and quarantine clearance miss the planting window at 4 sites.
- First 6-year data arrives after Month 84 (2033-10-12); the gate moves to Month 96 (2034-10-12) or later.
- Compressed trials weaken evidence of 3 independent resistance sources.
- Smallholder rollout and the Year 7 tranche slip.

##### Early Warning Signs
- No executed ABS agreement by Month 6 (2027-04-12)
- Seed lots not in quarantine at trial sites by Month 9 (2027-07-12)
- Site preparation incomplete at 2 or more of 4 sites

##### Tripwires
- ABS agreements unsigned at Month 6 (2027-04-12)
- Fewer than 4 sites planted by Month 12 (2027-10-12)
- Germplasm transfer delay of 8 weeks or more (proposed threshold)

##### Response Playbook
- Contain: Redirect planting effort to ex-situ accessions already held by partner institutes that need no new collection.
- Assess: Recompute the Year 7 evidence window and yield-penalty exposure within 30 days with the Oversight Panel.
- Respond: Seek steering-council approval of the crown-budding fast-track (about USD 0.25B, estimate) or formally move the gate to Month 96 (2034-10-12).


**STOP RULE:** Move the Year 7 gate or activate the fast-track if trials are not planted at 4 sites by Month 18 (2028-04-12).

---

#### FM6 - The Verdict Nobody Believed

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Gate Evidence Verification & Independent Audit Director
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Agencies and partners delay or filter data; the auditor relies on supplied records.
- A marginal Year 7 or Year 3 verdict is challenged by programme staff or funders.
- Producers and growers see gate results as political; confidence falls.
- Adjudication exceeds 60 days; tranche disbursement slips.
- OEMs and smallholders delay commitments pending clarity.

##### Early Warning Signs
- Auditor data requests unanswered beyond 5 business days
- Auditor site selections replaced by programme-nominated sites
- Public challenge to a scorecard from a producer agency

##### Tripwires
- More than 10% of auditor data requests exceed 5 business days in a quarter (proposed threshold)
- Adjudication runs beyond 60 days
- Verdict publication later than 30 days after audit conclusion

##### Response Playbook
- Contain: Invoke contractual penalties and freeze programme-side editing of datasets pending auditor review.
- Assess: Commission an independent review of the disputed evidence chain and sampling within 30 days.
- Respond: Publish findings with the adjudication panel's ruling and restructure data-access clauses with each agency and partner.


**STOP RULE:** Suspend tranche release requests if two consecutive gate verdicts are overridden or unpublished beyond 60 days (proposed threshold).

---

#### FM7 - The Compensation Fund That Ran Dry

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Surveillance, Detection & Incursion Response Coordinator
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- First confirmed incursion triggers destruction of a buffer larger than modelled.
- Claims exceed the USD 0.5B prefunded fund; payments slip beyond 30 days.
- Growers see slow payouts and conceal later infections.
- Reserve drawdown needs adjudication, delaying response.
- Draws on the USD 4.5B reserve reduce cover for other shocks.

##### Early Warning Signs
- Compensation claims paid later than 30 days
- Modelled buffer area above fund capacity
- Anonymous reports below 2 per country per month

##### Tripwires
- Compensation payment delay >= 30 days on any confirmed case
- Single-incursion claims >= 25% of the USD 0.5B fund
- Detection latency >= 6 months in any new region

##### Response Playbook
- Contain: Release emergency compensation advances to affected growers within 14 days and halt movement of planting stock in the buffer.
- Assess: Recompute fund adequacy against multi-site scenarios and audit claim backlog within 30 days.
- Respond: Seek reserve drawdown approval from the adjudication panel and restructure the compensation schedule to restore reporting.


**STOP RULE:** Suspend eradication-first doctrine and re-decide response model if payouts exceed 60 days on two cases.

---

#### FM8 - The Thirsty Fields

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Alternative-Rubber Processing & OEM Engagement Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Aquifer depletion and drought cut Guayule yields beyond 25%.
- Dandelion sites face heat stress and shifted seasons.
- Feedstock volume falls short of pilot and wave 1 plant needs.
- Re-siting after Month 60 (2031-10-12) is slow given multi-year crop establishment.
- Cost KPIs are missed for reasons unrelated to genetics.

##### Early Warning Signs
- Pilot water use above modelled values
- Yield below 80% of plan in a drought season
- Site groundwater reserve flagged under 10 years

##### Tripwires
- Modelled or observed yield loss >= 25% at a primary site
- Feedstock cost >= USD 1.40/kg at Month 48 (2030-10-12)
- Pilot feedstock delivery below 80% of nameplate for 2 quarters

##### Response Playbook
- Contain: Stop new land contracts and plant site works at affected sites.
- Assess: Run independent water-balance and yield review of all pilot sites within 60 days.
- Respond: Re-site or shift crop mix using the USD 1.0-1.5B (estimate) climate allocation before wave 1 commitment.


**STOP RULE:** No wave 1 final investment decision at any site with modelled yield loss above 25% or groundwater reserve under 10 years.

---

#### FM9 - The Empty Laboratory Benches

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Program Governance, Strategic Coordination & Long-Term Sustainability Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Scarce molecular, breeding and engineering talent is poached or unavailable.
- Inspector and lab posts stay vacant; lots inspected fall short of 100,000/year.
- Trial sites lose managers; data quality drops.
- Turnover erodes producer trust in the programme.
- Gate evidence becomes thin and contestable.

##### Early Warning Signs
- Key posts unfilled after 90 days
- Lab throughput under plan for 2 quarters
- Staff attrition above 30% annualised

##### Tripwires
- Fewer than 100 inspectors active at Month 12 (2027-10-12)
- Fewer than 10 regional labs operating at Month 24 (2028-10-12)
- Annual inspected lots below 30,000

##### Response Playbook
- Contain: Freeze expansion of new sites and reassign existing staff to critical trial and surveillance posts.
- Assess: Audit vacancies, pay gaps and exit reasons by role within 45 days.
- Respond: Fund retention packages and secondments from partner institutes, and sequence labs to staff available.


**STOP RULE:** Defer the Month 36 (2029-10-12) gate and re-scope Phase 1 if fewer than 60 inspectors are active at Month 24 (2028-10-12).
