# Purpose
and

# Domain
# Primary Domain
Plant Pathology

# Secondary Domains

- Plant Quarantine
- Plant Breeding
- Supply Chain Resilience

## Rationale
Plant Pathology and Plant Breeding tie as outcome candidates; tiebreak favors Plant Pathology as the program centers on managing SALB. Plant Pathology covers containment, epidemiology, and resistance screening. Plant Breeding covers only the cultivar strand; other candidates are constraints, methods, or market roles.

# Disciplines

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Plant Quarantine | 5 | 5 | constraint | Global SALB Containment Protocol harmonized with phytosanitary standards is the non-negotiable Phase 1 deliverable. |
| Plant Breeding | 5 | 5 | outcome | Genomic breeding of SALB-resistant, yield-parity Hevea cultivars is a core success criterion. |
| Plant Pathology | 5 | 5 | outcome | SALB epidemiology, resistance screening, and containment underpin core success. |
| Access Benefit Sharing | 4 | 5 | constraint | Brazil-led bio-prospecting must comply with Nagoya Protocol and national genetic-resource access rules. |
| Supply Chain Resilience | 4 | 4 | method | Diversified parallel rubber supply chains with OEM offtake and resilient procurement define success. |
| Agricultural Economics | 4 | 4 | market | Smallholder replant finance, price-stability tools, and alternative-rubber cost competitiveness drive adoption. |
| Industrial Biotechnology | 4 | 4 | method | Guayule and Russian dandelion require colocated extraction, processing, and OEM quality qualification. |
| Development Finance | 4 | 4 | method | Smallholder replant finance, price-stability tools, and stage-gated funding require blended-finance design. |
| Genomics | 4 | 4 | method | Genomic selection and bio-prospecting drive SALB-resistant, yield-parity cultivar development. |

# Plan Type
# Physical Locations Required

This plan cannot be executed digitally. It is a 25-year, $30 billion public-private program to protect the global natural rubber supply from South American Leaf Blight (SALB), and nearly every workstream requires real-world, on-the-ground activity.

## Containment Protocol

The SALB Containment Protocol covers movement of nursery stock, research materials and contaminated equipment. It depends on funded surveillance, physical inspections at plantations, nurseries and borders, and red-team drills. These activities require people, facilities and field sites. A written protocol alone cannot verify containment.

## Breeding and Bio-prospecting

The Brazil-led bio-prospecting and genomic breeding effort requires field collection of Hevea germplasm in South America, along with laboratories, greenhouses, nurseries and multi-location field trials to test SALB resistance and yield parity. Access-and-benefit-sharing compliance involves agreements with physical stakeholders and territories. Genomic analysis is partly computational but cannot replace physical sampling and trials.

## Alternative Crops

Guayule in arid zones and Russian dandelion in temperate climates must be planted, grown and harvested on land. Colocated processing plants must be built and operated. OEM offtake agreements require physical product qualification, such as testing rubber quality in tyres and other products.

## Smallholder Adoption

Replant finance, clean-plant networks and price-stability tools are delivered to farmers in rubber-growing regions. Clean-plant networks are physical nurseries and distribution systems. Replanting is physical agricultural work.

## Governance and Gating

Funding gates at Years 3, 7, 12 and 18 rely on containment performance, cultivar readiness and alternative-rubber cost and quality KPIs. These are measured through field data, trials and processing outputs. Negotiating a global protocol involves in-person meetings between governments, regulators, industry and development finance institutions.

## Summary

The plan requires land, laboratories, plants, travel, inspections and field trials. It cannot be completed exclusively online. Digital tools such as genomics, data platforms and finance modelling support but do not replace the physical work.

# Physical Locations
# Physical Locations

## Location 1
Brazil and Amazon Basin (South America)

Hevea-growing states: Amazonas, Rondônia, Acre, and Mato Grosso do Sul

Wild Hevea germplasm collection sites, endemic SALB field trial plots, and Brazil-led breeding research institutes

## Rationale
Brazil is the center for bio-prospecting under Nagoya Protocol compliance and access-and-benefit-sharing agreements with indigenous communities. Endemic SALB pressure provides real disease-screening conditions. Brazil's leadership role and existing rubber research infrastructure make it the geographic anchor.

## Location 2
Southeast Asia and South Asia (Asia)

Indonesia (Sumatra, Kalimantan), Malaysia, Thailand, India, and Vietnam

Existing SALB-free plantation zones, regional plant protection organization headquarters, distributed clean-plant nurseries, surveillance and inspection networks, and tissue-culture propagation hubs

## Rationale
Asia is the world's largest natural rubber producer (est. 70% of global supply) and currently SALB-free. Enforcement of the Containment Protocol in these regions is critical to prevent pathogen incursion. Distributed nurseries and propagation centers enable rapid multiplication and adoption of resistant cultivars and alternative rubbers. Regional plant protection organization capacity building and surveillance infrastructure must be established in situ.

## Location 3
West and Central Africa

Côte d'Ivoire, Cameroon, Ghana, and Nigeria

Emerging rubber-producing zones, plant health inspection checkpoints, clean-plant distribution networks, and capacity-building training centers

## Rationale
Africa is an expanding rubber-producing region and currently SALB-free. Building containment capacity and clean-plant networks before SALB arrival is more cost-effective than managing an outbreak. Regional inspector training and plant health capacity is needed early. Africa's agricultural labor availability and land suitability also support alternative-rubber pilot sites.

## Location 4
Semi-arid Regions (Global)

Mexico (Sonora, Coahuila), southwestern United States (Arizona, California), and parts of Argentina

Guayule breeding and cultivation sites with colocated extraction and processing facilities

## Rationale
Guayule is adapted to arid and semi-arid climates with low rainfall and high temperature variation. These regions have existing agronomic and processing knowledge from historical guayule programs. Colocated processing reduces transport losses and improves economics. OEM proximity in North America and existing industrial infrastructure support pilot commercialization and tire-grade qualification.

## Location 5
Temperate Regions (Global)

Northern Europe (Russia, Belarus, Baltic states), temperate North America (Canada, northern United States), and temperate South America (southern Brazil, Argentina)

Russian dandelion breeding, cultivation, and colocated extraction/processing pilot sites

## Rationale
Russian dandelion grows in temperate climates with moderate rainfall and shorter growing seasons. It offers geographic diversification of rubber supply away from tropical zones vulnerable to other diseases and climate shocks. Northern European and Eurasian siting supports testing in cool-season conditions and aligns with existing agricultural research infrastructure.

## Location 6
Global (Major Rubber-Consuming Regions)

North America (USA, Mexico), Europe, and East Asia (China, Japan, South Korea)

OEM tire-testing and rubber-qualification facilities, and demand commitment negotiation centers

## Rationale
OEMs and tire manufacturers must validate that alternative rubber and resistant-Hevea output meet tire-grade specifications. Direct access to OEM testing facilities and procurement teams is essential for building take-or-pay offtake agreements and qualifying new rubber sources. Co-location enables rapid feedback on quality issues and supports demand commitments.

## Location 7
International Governance Hubs (Multi-Regional)

Rome (IPPC Secretariat, FAO), Geneva (International Convention centers), and regional capital cities (e.g., Bangkok for ASEAN, Nairobi for East Africa)

Multilateral secretariat offices, IPPC standard-setting bodies, regional plant protection organization headquarters, and development finance institution regional desks

## Rationale
Harmonization of the containment protocol with existing IPPC frameworks and regional phytosanitary standards requires offices in or near IPPC and FAO hubs. Regional secretariat presence is needed for governance, protocol enforcement coordination, and producer-government seat representation. Development finance institution alignment requires presence near major lenders' regional offices.

## Location Summary
This 25-year, $30 billion program spans: (1) Brazil's Amazon region for wild Hevea bio-prospecting and endemic SALB field trials; (2) SALB-free Asia (Indonesia, Malaysia, Thailand, India) for containment enforcement, surveillance networks, and clean-plant propagation—critical as the world's largest rubber producer; (3) West/Central Africa for early capacity building and alternative-rubber siting before SALB arrival; (4) arid zones (Mexico, southwestern USA, Argentina) for Guayule cultivation and processing; (5) temperate zones (Russia, northern Europe, temperate Americas) for Russian dandelion pilot scale-up; (6) major consuming regions (North America, Europe, East Asia) for OEM qualification and demand commitments; and (7) international governance hubs (Rome, Geneva, regional capitals) for IPPC harmonization and multilateral coordination. All pillars require distributed, place-specific investment in field trials, laboratory infrastructure, nursery networks, surveillance systems, processing plants, and institutional capacity.

# Currency Strategy
and

# Identify Risks
# Risk 1 - Regulatory & Permitting

## Rationale

The SALB Containment Protocol must be adopted as binding standard by national plant-protection organizations in 15–20 producing countries and harmonized with regional phytosanitary frameworks (IPPC, ASEAN, ECOWAS, Mercosur). Harmonization typically takes 3–5 years and requires consensus among competing producers, governments with weak quarantine capacity, and Brazil. Formal adoption slipping past Year 3 gate or remaining voluntary would prevent verified containment and risk tranche withholding, delaying breeding and smallholder work.

## Impact

Failure to achieve binding, globally adopted protocol by Year 3 would: (1) violate non-negotiable Phase 1 deliverable; (2) trigger withholding of tranches allocated to Years 3, 7, and 12; (3) delay alternative-rubber and breeding scaling by 2–4 years; (4) create legal uncertainty for cross-border material movement, stalling field trials; (5) reduce funder confidence, risking early exit by development banks; (6) deferred breeding and smallholder investments: $500 million–$1.2 billion. Geopolitical friction could derail harmonization entirely.

Likelihood: Medium
Severity: High

## Action

Begin diplomatic engagement on protocol framework at Month 0 (2026-10-08), in parallel with technical drafting, targeting formal IPPC proposal by Month 18 (2028-04-08). Establish technical working group with Brazil, major producing countries, and IPPC Secretariat to co-draft standard. Build coalition of OEM buyers and multilateral development banks with funding explicitly conditioned on protocol adoption. If consensus stalls, pursue two-tier approach: secure binding regional compacts (Asia, Africa) by Month 24 (2028-10-08) while formal IPPC standard-setting continues. Create provisional protocol that countries can adopt pending formal approval, with interim verification audits by trusted third party.

# Risk 2 - Technical

## Rationale

Hevea resistance breeding through pyramiding wild-germplasm sources into elite high-yield clones is long and unpredictable. Genomic selection reduces back-crossing cycles, but field trials under endemic SALB pressure typically require 5–8 years per candidate, plus cross-site validation in clean zones (2–3 years additional). Year 7 and Year 12 gates expect cultivar candidates and commercial clones, but delays in trial site establishment, pathogen inoculation failure, genotype-by-environment gaps, or lower yield parity could slip candidates past gates and withhold tranches.

## Impact

Slippage in cultivar readiness by 18–36 months would: (1) postpone Year 7 gate and tranche release by 1.5–3 years; (2) leave smallholder replanting finance budgets unspent or repurposed, undermining adoption momentum; (3) delay commercial alternative-rubber plant commissioning, since OEMs demand resistant-Hevea availability; (4) risk funder withdrawal or reallocation; (5) create 2–4 year window in which SALB could establish in Asia, inflicting $2–5 billion plantation losses. Stranded breeding capex and lost smallholder productivity: $300–700 million.

Likelihood: High
Severity: High

## Action

Front-load breeding investment at Months 0–36 (2026-10-08 to 2029-10-08) to establish multiple candidate pipelines in parallel. Begin trial site preparation and quarantine-station commissioning immediately (Months 1–12 = 2026-11-08 to 2027-10-08) to avoid facility delays. Use high-containment inoculation and detached-leaf assays (Months 3–24 = 2027-01-08 to 2028-10-08) to screen early candidates before costly open-field tests. Establish 12–18 month buffer in cultivar-readiness timelines at Year 7 gate; if only intermediate candidates ready, score gate on portfolio progress and release 70% of tranches while reserving 30% for final-stage trials. Identify 2–3 elite clones with partial resistance or lower yield penalty as 'fast-track' cultivars for emergency deployment if incursion occurs.

# Risk 3 - Technical

## Rationale

SALB fungal populations display high genetic diversity and virulence variation across endemic regions. Single-resistance-source cultivars have historically failed within 5–10 years as virulent pathogen strains emerge. Program plans to pyramid multiple resistance sources, but if pathogen monitoring is weak, released cultivars could carry resistance genes to which emerging virulent biotypes already exist. This would undermine supply-chain resilience and require re-breeding cycles starting Years 12–18, consuming $400–800 million.

## Impact

Resistance breakdown in released cultivars within 5–10 years would: (1) negate Year 7/12 gates, as cultivars would fail durability tests; (2) strand smallholder replanting investments; (3) force emergency re-breeding cycle (Years 15–25) with additional $400–800 million capex, delaying true diversification to Year 20–25; (4) if re-breeding cannot complete before new incursion, supply chain remains vulnerable. Failed cultivar release and re-breeding: $800 million–$1.5 billion.

Likelihood: Medium
Severity: High

## Action

Establish Pathogen Genomics Lab at Month 2 (2026-12-08) in Brazil (partnered with CEPLAC or Embrapa) and satellite location in Asia (e.g., Rubber Research Institute of Malaysia) to sequence and characterize SALB virulence from trial sites and endemic regions annually. Embed virulence assessments into all resistance field trials as routine output. Run parallel high-containment inoculation program deliberately challenging finalists with virulent isolates from multiple geographic origins. Require cultivar-readiness gate evidence to include 3–5 year virulence-stability forecast based on pathogen genomic trends. If virulent biotypes capable of overcoming candidate resistance are detected before release, hold candidate back and extend pyramiding.

# Risk 4 - Technical

## Rationale

Guayule and Russian dandelion have not been grown at commercial scale for several decades. Guayule in Sonora/Coahuila/Arizona faces irrigation-cost uncertainty, pest/disease pressures, and soil-salinity issues under climate change. Russian dandelion in temperate Europe faces weed-management complexity, machinery adaptation, and cold-season latency. Processing cost and tire-grade quality have not been proven at commercial volumes (5,000–20,000 tonnes per annum by Year 12). If processing plants encounter unexpected technical problems, cost per tonne could remain 30–50% above Hevea and quality could miss specifications, failing Year 7 gates and stranding $800 million–$2 billion.

## Impact

Processing failures or cost/quality misses at Year 7 would: (1) fail alternative-rubber KPI gate, withholding Years 7–12 tranches; (2) strand early-stage plants with high fixed costs and no viable output, creating write-offs of $800 million–$2 billion; (3) reduce tire-maker confidence and weaken OEM commitment, increasing perceived execution risk; (4) force technology pivot adding 3–5 years and $500 million–$1 billion in R&D, delaying supply resilience; (5) create political friction in producing regions. Stranded capex plus remediation R&D: $1.3–3.2 billion.

Likelihood: Medium
Severity: High

## Action

Begin intensive agronomic and processing pilot work at Months 1–6 (2026-11-08 to 2027-04-08) in all target regions, not single sites. Establish 3–4 small-scale Guayule plots (50–200 hectares each) in distinct arid zones to test yield, pest/disease tolerance, water use before building commercial plant. Run processing trials at Months 12–30 (2027-10-08 to 2029-04-08) on pilot crops, testing extraction, resin recovery, and tire-grade quality. Set conservative assumptions for Year 7 gate: require processing cost within 20% of Hevea (not parity) and tire-grade tests passing with 95% yield of current Hevea specs. If pilot results show wider gaps, delay commercial plant construction and extend R&D until Year 10–12. Secure offtake agreements with at least two major OEMs by Year 6 contingent on specified cost/quality performance.

# Risk 5 - Financial

## Rationale

The $30 billion budget over 25 years is to be funded through sovereign grants, multilateral lending, and industry levy on natural rubber trade or tire production. Creating and enforcing an industry levy requires coordination among competing traders, manufacturers, and producer governments—rarely achieved in commodity chains. If levy cannot be negotiated or revenue falls short due to price fluctuations, trade evasion, or political resistance, program would rely on grants and appropriations, inherently fragile across 25 years. Funding gaps of 10–30% are typical in long-term development programs.

## Impact

Funding shortfalls of 10–30% (i.e., $150–900 million per year) would cascade across all three pillars: (1) breeding programs lose 1–2 years of trials due to delayed site preparation; (2) smallholder replanting rationed, reducing adoption to 20–30% of target (2–3 million farmers), leaving global rubber belt uninsured; (3) alternative-rubber plants scaled more slowly or abandoned; (4) surveillance and inspection in weak-link countries underfunded; (5) deferred investments with commensurate delays in readiness: $800 million–$2.5 billion. Political crises could redirect funds mid-program.

Likelihood: High
Severity: High

## Action

Secure binding funding commitments from multilateral development banks and 5–8 sovereign governments at Month 3 (2027-01-08), with ring-fenced tranches tied to stage-gate framework, not subject to annual re-appropriation. Design industry levy as dedicated per-tonne mechanism on natural rubber trade (e.g., $0.15–0.25 per tonne), governed by independent trust and collectable at major trading ports. Establish pilot levy in single region (e.g., ASEAN) by Year 2 to demonstrate viability, then scale globally. If full levy cannot be achieved by Year 4, activate contingency cascade: increase development-bank loan-to-grant ratio, create outcome-linked bonds repaid from cultivar royalties or alternative-rubber sales, establish climate-finance blended mechanism. Hold 10–15% of annual tranches in reserve to buffer shocks.

# Risk 6 - Financial

## Rationale

Program gates funding at Years 3, 7, 12, and 18 based on KPIs: containment performance, cultivar readiness, and alternative-rubber cost/quality. However, biological systems produce uncertain timelines and KPIs may be partially met (e.g., 50% protocol adoption, some candidates without full yield parity). Gate-decision framework must decide full tranches, partial tranches, reallocation, or withholding. Rigid gates may terminate prematurely, wasting prior investment. Overly adaptive gates lose discipline. Real risk is either arbitrary gates eroding funder trust or overly lenient gates wasting money on failing pathways.

## Impact

Disputed or inconsistent gate decisions at Years 3, 7, or 12 would: (1) undermine multilateral funder confidence; (2) trigger early exit by sovereign governments or development banks if gate criteria perceived as moved post-hoc; (3) create litigation or renegotiation over tranches, delaying capital by 6–18 months; (4) if gates perceived as too loose, capital wasted on underperforming pathways; (5) if gates too rigid, program abandoned prematurely when delays are normal and recoverable. Gate disputes plus potential funder withdrawal: $300–600 million in delayed tranches and lost credibility, plus $3–8 billion funder withdrawal.

Likelihood: Medium
Severity: High

## Action

Define gate criteria and KPI thresholds at Month 3 (2027-01-08) in binding Technical Gate Charter, negotiated and signed by all funders, producer governments, and OEMs. Make criteria specific and quantitative (e.g., 'containment gate requires >80% of producing countries with enforceable import rules and >100 documented interceptions'; 'cultivar gate requires at least 2 SALB-resistant candidates with yield ≥90% of elite clone and virulence stability forecast 5+ years'). Establish independent Technical Panel (breeding scientists, phytosanitary experts, economist—none with financial interest) to assess evidence and recommend decisions. Publish all gate evidence and Technical Panel reasoning 60 days before decision, permitting outside review and 30-day appeal. Design adaptive tranches: if gate shows 70–85% attainment, release 70–85% of tranche and reallocate remainder to stronger pillar(s). Reserve 15% of total funding ($4.5 billion) in contingency pool for Technical Panel-recommended releases.

# Risk 7 - Operational

## Rationale

Adopting SALB Containment Protocol and enforcing it across 15–20 producing countries requires: national plant-protection organizations adopting protocol into binding import rules; trained and audited phytosanitary inspectors at borders, ports, nurseries; funded inspection capacity in weak-link countries (parts of Africa, Latin America); cross-border quarantine coordination; real-time data sharing. Many producer countries lack baseline capacity: West Africa and South Asia have <50 trained inspectors per nation, equipment shortages, minimal laboratory diagnostics. Building capacity requires 3–5 years, but Year 3 gate expects verification. If capacity not ready by Year 3, verified containment cannot be scored, gates fail.

## Impact

Weak producer-country inspectorate capacity by Year 3 would: (1) make containment verification impossible, failing Year 3 gate and withholding Years 3–7 tranches; (2) leave SALB-free regions at high risk of undetected incursions via contaminated material; (3) delay breeding and smallholder work by 2–3 years; (4) erode producer-state trust if perceived as external funders setting gates weak-capacity countries cannot meet; (5) create openings for informal workarounds (bribery, mislabeling) undermining protocol. Deferred smallholder and alternative-rubber investments: $400–800 million; emergency SALB response if undetected incursion: $200–500 million.

Likelihood: High
Severity: Medium

## Action

Begin capacity-building at Month 1 (2026-11-08), before Year 3 gate: establish twinning partnerships between Brazilian and Southeast Asian phytosanitary institutes and West African agriculture ministries. Recruit and train 100–200 inspectors in Asia and Africa by Month 24 (2028-10-08) using intensive residential programs and OJT rotations. Procure inspection equipment (diagnostic kits, pest traps, data-entry tools) for 50 inspection checkpoints by Month 20 (2028-06-08). Establish Digital Reporting Platform (cloud-based, low-bandwidth) by Month 12 (2027-10-08) for remote inspectors to submit suspect samples with GPS and images, enabling rapid central laboratory confirmation. Fund capacity investments from Years 0–3 separately from gate-contingent tranches. Set Year 3 gate to score 'partial achievement': require 60–70% of target inspection capacity operational and >50 documented interceptions, rather than 100% capacity, allowing gate to pass while capacity remains in progress.

# Risk 8 - Operational

## Rationale

Smallholder replanting requires farmers to: (1) access replanting loans or income bridges for 3–5 years; (2) buy certified disease-free material from clean-plant network; (3) adopt clean-plant and sanitation practices; (4) participate in surveillance reporting. Target: 2–3 million farmers across Asia, Africa, Latin America. However, smallholders operate with thin margins, high price sensitivity, limited formal credit access. Uptake of replanting programs rarely exceeds 20–40% even with subsidized credit, due to credit risk aversion, labor constraints, land-title uncertainty, weak extension trust. If adoption remains below 50% by Year 7–12, alternatives and resistant cultivars will lack demand, prices will fall, and resilience goal not met.

## Impact

Low smallholder adoption (<50% of 2–3 million target) would: (1) strand resistant-cultivar plantings at maturity without sufficient acreage to credibly reduce SALB vulnerability; (2) leave alternative-rubber plants underutilized (30–50% capacity instead of 80–100%), raising per-tonne costs and missing Year 7 KPI, failing gate; (3) reduce supply-chain resilience benefit to boutique improvement; (4) waste $500 million–$1 billion in replanting finance and clean-plant capex; (5) create political criticism that program benefited research institutes and estates but not smallholders. Stranded finance and unmet resilience: $700 million–$1.5 billion.

Likelihood: High
Severity: Medium

## Action

Co-design replanting finance and clean-plant delivery mechanisms with farmer organizations and rural banks at Months 0–6 (2026-10-08 to 2027-04-08), ensuring credit terms compatible with smallholder cash flows (e.g., 7–10 year tenor, repayment tied to latex sales prices). Pilot income-bridge schemes and price-stability tools in 3–5 regions (Indonesia, Côte d'Ivoire, Brazil) at Months 6–18 (2027-04-08 to 2028-04-08) on samples of 5,000–10,000 farmers, testing uptake, repayment, satisfaction before scaling. Link replanting credit to verified clean-plant practices via mobile verification (photos, GPS), so income premiums triggered by observed hygiene. Establish farmer-led surveillance networks where participating farmers paid outcome-based premiums ($10–50 per confirmed SALB report) for monitoring and sample submission. If pilot adoption remains below 50% by Month 18 (2028-04-08), reallocate replanting capital to larger estates and commercial farms and adjust program's resilience goal accordingly.

# Risk 9 - Supply Chain

## Rationale

Tire manufacturers and OEMs are end demand for natural rubber and alternative rubber. They must commit to purchasing alternative rubber and resistant-Hevea at comparable cost and quality levels. However, OEMs are price-sensitive and risk-averse: will sign take-or-pay offtake only if quality qualification is credible and cost proven. Program proposes building colocated processing plants at Years 3–6, but OEM qualification typically requires 12–24 months of tire-testing, supply-chain trials, regulatory approval. If plants built before OEM demand locked in, they will operate at low utilization, fail cost targets, and create stranded assets.

## Impact

Weak OEM offtake commitments by Year 6 would: (1) cause alternative-rubber plants to operate at 30–50% capacity, raising per-tonne cost 25–40% and missing Year 7 KPI, failing gate; (2) leave plants unable to achieve economies of scale, requiring continued grant subsidies or write-offs; (3) reduce tire-maker interest, causing hedges against SALB risk (synthetic rubber, higher Hevea prices) instead of alternative commitment; (4) waste $800 million–$1.5 billion in processing capex; (5) create political friction with producing countries. Stranded processing capex and foregone diversification: $1–2 billion.

Likelihood: Medium
Severity: High

## Action

Initiate OEM engagement at Month 0 (2026-10-08) as separate workstream, parallel to technology development. Establish buyer consortium (5–8 major OEMs) by Month 6 (2027-04-08) and negotiate framework for shared tire-grade qualification, cost assumptions, volume commitments. Require 2–3 OEMs to sign take-or-pay letters of intent by Month 18 (2028-04-08), committing to purchase 500–2,000 tonnes per annum each from Guayule and Russian dandelion plants by Year 10–12, contingent on cost within 15% of Hevea and tire-grade quality. Co-fund OEM qualification testing (Months 12–30 = 2027-10-08 to 2029-04-08) using program capex, reducing OEM financial risk. Do not approve processing plant construction until 80% of Year 10 production volume is under written offtake commitment, priced and tiered. If full offtake cannot be achieved by Year 5, delay plant construction to Year 8–10.

# Risk 10 - Supply Chain

## Rationale

Program depends on Brazil's leadership in Hevea wild-germplasm collection and access-and-benefit-sharing (ABS) compliance under Nagoya Protocol. Brazilian authorities, indigenous communities, and traditional peoples hold rights to wild germplasm and require compensation and consultation. Program calls for Brazil-led bio-prospecting, but bilateral negotiations with communities, state governments, indigenous organizations can be slow (18–36 months per cycle), and benefit-sharing agreements can be reopened if communities perceive inadequate benefits. If negotiations delay collection or if communities challenge cultivar releases later, breeding timelines slip, patent filings contested, and cultivar adoption faces legal uncertainty.

## Impact

Delays or disputes in Nagoya Protocol ABS negotiations would: (1) postpone wild Hevea collection by 12–24 months, slipping resistance-breeding timeline and Year 7 gate by 1–2 years; (2) create legal challenges to cultivar releases if communities later claim insufficient benefit-sharing, requiring renegotiation and restricting use in some countries; (3) reduce diversity of resistance sources if access to certain territories denied, weakening durability; (4) erode cultivar adoption if smallholders distrust due to perceived inadequate community benefit; (5) establish high benefit-sharing precedent for future genetic-resource access, hard to sustain. Delayed breeding timelines: $150–300 million; legal disputes and renegotiation: $50–100 million.

Likelihood: Medium
Severity: Medium

## Action

Establish dedicated Nagoya Protocol and benefit-sharing team at Month 0 (2026-10-08), led by Brazilian environmental/legal experts and indigenous-rights specialists, to map access requirements and negotiate framework agreements with Brazilian states and indigenous organizations before collection plans finalized. Create pooled benefit-sharing fund (financed by program capital or cultivar royalties) by Month 6 (2027-04-08) that pre-allocates benefits without requiring renegotiation per cultivar, speeding permits. Include indigenous community representatives on Technical Panel and governance bodies, giving decision-making voice and regular benefit accounting. Publish annual benefit-sharing report (Months 24, 36, 48 = 2028-10-08, 2029-10-08, 2030-10-08, etc.) showing royalties, capacity-building investments, community satisfaction, creating accountability and reducing later disputes. Establish dispute-resolution mechanism (arbitration, not litigation) with 6-month resolution timeline.

# Risk 11 - Environmental

## Rationale

Guayule and Russian dandelion cultivation at scale (5,000–20,000 hectares by Year 12) requires land conversion, water use, pest management, processing emissions. Guayule in arid Mexico/Arizona faces irrigation-water availability under climate change, soil salinity build-up, pesticide use. Russian dandelion in temperate Europe faces herbicide-dependency, soil compaction, displacement of existing land use. If large-scale pilots create water stress, soil degradation, biodiversity loss, environmental regulators or NGOs may restrict expansion, and producing countries may withdraw land access or impose stricter terms. Climate shocks (drought, flood) during Years 5–15 could reduce yields and push cost/quality KPIs into failure.

## Impact

Environmental degradation or climate shocks to alternative-crop zones would: (1) trigger regulatory restrictions or land-access withdrawal by Year 8–12, reducing available area by 30–50%, eliminating economies of scale; (2) cause yields to fall 20–40% below projections due to water stress or climate effects, pushing per-tonne cost 25–50% above Hevea; (3) miss Year 7/12 cost/quality gates, withholding tranches and stalling scaling; (4) create political friction in producing countries if environmental groups or water-stressed communities block expansion; (5) reduce tire-maker interest if alternative-rubber supply unreliable and cost above Hevea. Foregone alternative-rubber production and diversification: $400–900 million; remediation/mitigation: $100–300 million.

Likelihood: Medium
Severity: Medium

## Action

Conduct environmental impact assessments and water-availability studies in all proposed Guayule (Sonora, Arizona, Argentina) and Russian dandelion regions (temperate Europe) before pilot site selection, engaging environmental regulators and NGOs at Months 1–6 (2026-11-08 to 2027-04-08). Restrict Guayule to non-irrigated arid zones with existing water-efficient farming, avoiding irrigation-dependent regions or groundwater-stressed areas. For Russian dandelion, prioritize marginal or degraded agricultural land, not prime zones or biodiversity reserves. Build climate-adaptation measures into pilots: drought-tolerant varieties, reduced-till cultivation, water-harvesting systems. Establish baseline environmental monitoring (soil, water, biodiversity) at all sites by Month 12 (2027-10-08), with ongoing sampling through Year 15 to detect early degradation. Include climate-shock stress tests in Year 7 gate: model cost/quality outcomes under projected drought (2-in-20-year rainfall) and flood (2-in-50-year event) scenarios; if alternatives remain unviable under stress, do not scale; if viable, proceed with confidence.

# Risk 12 - Social & Political

## Rationale

A 25-year, $30 billion program requires sustained buy-in from multiple governments (Brazil, Indonesia, Malaysia, Thailand, India, Côte d'Ivoire, Mexico, etc.), multilateral development banks, and private OEMs. However, political cycles, competing priorities (pandemic response, climate adaptation, domestic agriculture), and budget constraints can shift government priorities. Funder turnover—new administrations, new bank leadership—can interrupt commitments. In producing countries, rubber sectors sometimes aligned with political factions or ethnic groups, and program decisions can become politically contentious.

## Impact

Political shifts or funder turnover at Years 5–12 would: (1) cause major funders or producer governments to withdraw or reduce commitments by 20–50%, creating funding gaps of $200–600 million; (2) stall stage-gate decisions if new administrations contest prior commitments; (3) erode multilateral coordination if producer governments lose confidence in program neutrality; (4) trigger early program termination if political risk perceived as too high, wasting prior investments; (5) create opportunities for competing initiatives undermining containment and adoption goals. Funding shortfalls and foregone resilience: $500 million–$2 billion.

Likelihood: High
Severity: Medium

## Action

Establish ring-fenced, legally binding funding architecture at Month 3 (2027-01-08) insulating program from annual budget cycles: pursue long-term grant commitments (5–10 years), not annual appropriations; create endowment or trust fund with independent governance so funder turnover does not interrupt flows. Formalize commitments in binding treaties or multilateral agreements (not voluntary), with clear dispute-resolution. Establish producer-government steering committee (rotating leadership, term limits) giving producer countries collective voice in strategy and gate decisions. Ensure 'funder diversity': no single funder provides >25% of capital. Publish annual stakeholder reports showing progress, gate achievements, investment returns, building confidence and reducing political attacks. Establish 'political risk reserve' (3–5% of annual budget) for advocacy, stakeholder engagement, and conflict resolution.

# Risk 13 - Institutional & Governance

## Rationale

Program requires multilateral secretariat with decision-making authority over stage gates, funding release, and strategy across 25 years and multiple continents. Establishing such a body faces tensions: producer governments expect sovereignty; OEMs expect business-friendly decisions; development banks expect financial discipline. Secretariat must navigate competing interests while maintaining credibility as neutral arbiter. If governance perceived as captured by any faction, others will withdraw or undermine decisions.

## Impact

Governance failure or perceived capture would: (1) trigger early exit by producer governments or OEMs if confidence in neutrality lost; (2) create disputes over gate decisions, stalling tranche release 6–12 months, delaying investments; (3) reduce compliance with containment protocol if perceived as externally imposed; (4) fragment program into regional or bilateral initiatives, losing global coordination and creating loopholes; (5) allow parallel initiatives (country-specific breeding, informal trade) undermining program coherence. Lost coordination value and increased transaction costs: $300–700 million; reduced supply-chain resilience benefits.

Likelihood: Medium
Severity: Medium

## Action

Design multilateral secretariat with balanced governance: establish independent board with seats for producer governments (6–8 members, rotating), OEM representatives (3–4), development-bank representatives (3–4), independent technical experts (3–4), with no single faction holding majority. Specify board decision-making rules in founding charter: require supermajority or consensus for gate decisions and major strategy changes, giving all factions veto power. Hire professional, politically insulated secretariat staff with long-term employment contracts, creating institutional continuity. Establish Technical Panel (separate from board) for assessing gate evidence and recommending decisions, with members selected for expertise and independence, not political representation; bar board members from Panel assessments, creating checks-and-balances. Publish all board decisions, dissents, and Technical Panel rationales within 30 days of each gate.

# Risk 14 - Technical

## Rationale

SALB fungus is endemic in South America and has not established in Asia or Africa, likely due to environmental factors (humidity, temperature seasonality) or absent spore pathways. However, climate change is shifting temperature and rainfall patterns globally, potentially making Asian and African climates more conducive to SALB establishment. Additionally, if incursion occurs via contaminated plant material, fungus may establish faster than current models predict, overwhelming surveillance and response capacity even if protocol is in place. This creates 'surprise risk' where containment strategy proves insufficient.

## Impact

Unexpected SALB establishment in Asia or Africa despite protocol compliance would: (1) trigger emergency outbreak response requiring $2–5 billion in tree removal compensation, quarantine enforcement, containment efforts; (2) demonstrate containment strategy was insufficient, eroding funder confidence and triggering massive funding withdrawal; (3) cause cascading supply-chain disruption, global rubber prices spiking 50–150%, destabilizing tire manufacturing and vehicle production; (4) create massive smallholder losses, potentially displacing 100,000–500,000 farming families; (5) necessitate emergency deployment of partially-validated cultivars, risking failure and repeat cycles. Direct outbreak response, economic losses, program recovery: $2–10 billion.

Likelihood: Low
Severity: High

## Action

Establish High-Consequence Outbreak Response Contingency at Month 3 (2027-01-08): pre-fund standing $500 million reserve (held by multilateral secretariat or insurance mechanism) immediately available for emergency containment and compensation if SALB confirmed in currently-free region, without requiring gate decisions. Design response protocol in advance (pre-agreed tree-removal criteria, compensation schedules, quarantine-zone definitions, funding triggers) for crisis decisions. Commission climate-risk modeling at Months 3–12 (2027-01-08 to 2027-10-08) to forecast how changing temperature and rainfall patterns in Asia/Africa may shift SALB risk and adjust surveillance and breeding strategies. Establish 'fast-track' emergency cultivar release pathway deploying partially-validated resistant cultivars within 12–18 months of confirmed incursion, bypassing normal gates. Train rapid-response teams (phytosanitary, logistics, social) at 3–5 strategic locations (Indonesia, Thailand, Côte d'Ivoire, Mexico) for response beginning within 2–4 weeks of detection.

# Risk 15 - Technical

## Rationale

Program success depends on three technical pillars working in concert: containment prevents SALB reaching Asia/Africa; resistant Hevea deployed if containment fails or as redundancy; alternative rubber provides diversification. These three pathways have different timelines and dependencies. Containment takes 3 years to verify but carries binary risk. Breeding takes 7–12 years to deliver cultivars. Alternative rubber takes 8–12 years to reach commercial scale, depending on OEM offtake and cost parity. If one pillar fails or delays, others cannot compensate immediately. If incursion occurs at Year 6 when only one pillar is mature, program faces supply crisis despite passing Year 3 gates.

## Impact

Asynchronous pillar development (e.g., late-stage incursion when only one pillar mature) would: (1) leave supply chain vulnerable during transition years; (2) force emergency deployment of partially-ready alternatives that may fail or create new problems; (3) if incursion at Year 6–8 before resistant cultivars commercially available, response options limited to tree removal, fungicide, imported containment—expensive and incomplete; (4) reduce supply-chain resilience benefit, since goal is three redundant pathways, not sequential dependencies; (5) create opportunity for critics to claim program insufficient. Emergency response and foregone resilience: $1–3 billion.

Likelihood: Medium
Severity: Medium

## Action

Design program operating three pathways in parallel, not sequence. Fund all three pillars equally at Years 0–3, not defunding breeding/alternatives if containment looks promising at Year 2–3. Establish 'staging gates' within each pillar at Years 2, 4, 6 (not only Years 3, 7, 12, 18) to assess progress and reallocate funds if one is lagging. Create 'contingency deployment plan' by Month 18 (2028-04-08) specifying: if SALB detected in Asia at any point, resistant cultivar candidates at any validation stage can be emergency-deployed with liability protection; if incursion occurs before any cultivars ready, emergency fungicide stockpiles and toolkits pre-positioned in high-risk countries by Year 4. Model 'resilience scenarios' at Years 3, 7, 12 assuming each pillar partially or fully fails and assess whether program still meets resilience goals; if not, redirect strategy before further capital is locked into failing pathways.

# Risk 16 - Regulatory & Permitting

## Rationale

Guayule and Russian dandelion cultivation and processing require permits from national agriculture, environmental, and labor authorities in producing countries (Mexico, Argentina, Europe). Additionally, tire manufacturers importing alternative-rubber products must meet automotive and tire regulatory standards in consuming regions (EU, USA, Japan) specifying composition limits, performance thresholds, supply-chain traceability. If alternative-rubber material does not meet automotive specifications, OEMs cannot use it and plants cannot operate. Regulatory approval typically takes 12–24 months per country per crop; standards may tighten during program.

## Impact

Regulatory delays or failure to meet automotive standards would: (1) prevent commercial cultivation until Years 10–12, missing Year 7 KPI and withholding tranches; (2) strand processing plants if built before regulatory approval; (3) require costly reformulation or processing changes if tire standards tightened, pushing KPIs into failure; (4) reduce OEM confidence in supply viability, weakening offtake commitments; (5) create competitive advantage for synthetic rubber or incumbent Hevea. Delayed regulatory approvals and lost alternative-rubber production: $200–500 million.

Likelihood: Medium
Severity: Medium

## Action

Initiate regulatory engagement in parallel with technology development at Month 1 (2026-11-08), not after plant built. Establish Regulatory Affairs workstream mapping all permitting and standards requirements for Guayule and Russian dandelion in target producing countries and consuming markets (EU, USA, Japan) by Month 6 (2027-04-08). Engage national agricultural and environmental authorities at Months 2–6 (2026-12-08 to 2027-04-08); begin permit applications for pilot sites by Month 9 (2027-07-08), aiming to secure agricultural permits by Month 18 (2028-04-08). Engage ISO, automotive standards bodies, and major tire manufacturers at Months 3–6 (2027-01-08 to 2027-04-08) to understand tire-grade specifications; commission tire-testing trials with prototype alternative-rubber samples by Months 12–24 (2027-10-08 to 2028-10-08), before commercial plants built. If automotive standards tightened, include 'standards adjustment clause' in OEM offtake agreements allowing cost adjustments and timeline slippage. Do not approve processing plant construction until agricultural permits confirmed and tire-grade specifications validated.

# Risk summary

This is large-scale, stage-gated, institution-heavy agricultural supply-chain resilience program spanning three interdependent pillars (phytosanitary containment, Hevea resistance breeding, alternative rubber crops) over 25 years across multiple continents. Program success depends on harmonizing global SALB Containment Protocol with existing regional standards, delivering SALB-resistant Hevea cultivars with yield parity, scaling Guayule and Russian dandelion to commercial cost/quality parity, financing and mobilizing smallholder adoption across Asia, Africa, Latin America, and sustaining multilateral governance and funding through political cycles and biological uncertainties.

Three most critical risks are: (1) Regulatory and coordination failure to achieve binding, globally adopted containment protocol by Year 3 gate, undermining non-negotiable Phase 1 deliverable and all downstream funding; (2) Biological delays in resistance breeding and cultivar readiness slipping past Year 7 and Year 12 gates while smallholder adoption capital remains trapped, reducing program credibility and triggering funder exits; (3) Failure of alternative-rubber processing plants to achieve cost/quality parity by Year 7, combined with weak OEM offtake commitments, leaving supply diversification unproven and processing assets stranded.

Additional hazards include pathogen adaptation to resistant cultivars, smallholder adoption bottlenecks due to finance or trust deficits, funder turnover and budget cuts mid-program, and climate shocks to alternative-crop pilots in arid and temperate zones.

Effective mitigation requires: early, binding legal instruments for protocol; conservative cultivar-readiness timelines with buffers; secured, take-or-pay OEM demand before processing capex; robust smallholder finance backed by price-stability tools; durable multilateral funding mechanisms insulated from annual budget cycles.

# Make Assumptions
# Rubber Programme: Questions and Assessments

## Question 1 - Capital Allocation Across Pillars and Front-Loading Strategy

Approximate distribution of $30 billion across pillars:

- 25% to containment protocol negotiation and capacity-building
- 35% to resistance breeding and field trials
- 25% to alternative-rubber pilot plants and processing
- 15% to smallholder finance and governance overhead

Years 0–3 allocate 20% of total budget to establish protocol framework, field trial sites, and breeding pipelines. Only containment protocol is expected to yield verification evidence by Year 3; breeding candidates and alternative-rubber pilots remain in early stages.

## Capital Allocation Assessment

Pillar-specific front-loading creates sequencing risk: if Year 3 gate passes containment but fails breeding/alternatives KPIs, funders may question capital committed to lagging pathways. Mitigation: design tranches as pillar-specific, not pooled, so Year 3 gate assesses containment only, with Years 7 and 12 gates independently assessing breeding and alternatives. Allocate 25–30% of Years 0–3 capital to containment, 25–30% to breeding groundwork, and 20–25% to alternative-crop pilots, with 15–20% reserved as contingency.

Risk: if early pilots show poor economics (e.g., Guayule pilot costs 40% above Hevea), reallocation pressure may reduce alternative-crop funding mid-program.

Opportunity: front-loading allows data-driven reallocation at Months 24–30 (2028-10-08 to 2029-04-08) if certain pathways show clear advantage, improving long-term ROI.

---

## Question 2 - Year 3 Gate Containment Verification Criteria

Verified containment at Year 3 gate is defined as:

- ≥15 producing countries with enforceable SALB import rules in national law
- ≥500 trained and audited inspectors operational at borders, ports, and nurseries
- ≥25 documented interceptions or suspect detections confirmed by laboratory testing

Year 3 verification allows partial achievement: if 12 countries adopt rules, 400 inspectors are trained, and 15 interceptions are documented, the gate scores 60–75% attainment, releasing 60–75% of Year 3–7 tranches with remainder reallocated to lagging sub-pillars. Formal protocol adoption without operational verification does not satisfy the gate; operational capability is the gating criterion.

## Year 3 Gate Assessment

Numeric KPI clarity is essential for credible gate decisions and reduces post-hoc disputes. However, adoption and operational capacity may not correlate—if 18 countries adopt rules but training in weak-capacity nations lags, thresholds risk false positives. Mitigation: define sub-metrics by region (e.g., Asia ≥8 countries with operational inspectors; Africa ≥4 countries; Americas ≥3 countries) to ensure minimum coverage in critical zones.

Risk: if interception numbers are low, interpreting whether containment is working or merely undetected is ambiguous. Clarification needed: does the gate require documented positive interceptions to prove protocol is active, or does absence of incursions count as verification?

Opportunity: partial-achievement framework allows biological and institutional timelines to slip without complete gate failure, improving durability.

---

## Question 3 - Brazil-Led Germplasm Collection Timeline

Brazil commits to deliver ≥200 wild Hevea accessions with documented SALB-resistance potential to breeding pipelines by Month 18 (2028-04-08). Nagoya Protocol negotiations with Brazilian states and indigenous organizations are assumed to be completed by Month 6 (2027-04-08), with pilot collection campaigns beginning Month 8 (2027-06-08). If negotiations slip to Month 12 (2027-10-08) or later, collection campaigns are delayed by 6–12 months, slipping cultivar development timeline by 1–2 years and risking Year 7 cultivar-readiness gate.

Contingency: maintain parallel accession supply from existing germplasm repositories (CIRAD, Embrapa collections) to avoid dependence on new wild collection.

## Brazil Germplasm Collection Assessment

Nagoya Protocol ABS negotiations are notoriously slow; 18–36 months per bilateral is common. A 6-month slip in collection directly delays cultivar selection and field trials by 6–12 months, with cascading impact on Year 7 readiness gate. Mitigation: (1) establish benefit-sharing framework agreements by Month 3 (2027-01-08) before detailed collection plans, to pre-clear access for multiple campaigns; (2) include indigenous representatives on the program's breeding steering committee; (3) maintain contingency accession supply from existing repositories (estimated 50–100 accessions available without fresh collection).

Risk: if wild-collected accessions carry lower resistance diversity than hoped, pyramiding strategies may require extending field trials by 2–3 years.

Opportunity: well-managed ABS engagement may unlock additional germplasm sharing from other South American countries if Brazil's model is successful.

---

## Question 4 - Smallholder Adoption Target and Uptake Rate

The program targets 2–3 million smallholder farmers across Asia, Africa, and Latin America for replanting or conversion (proposed threshold). Global rubber supply is approximately 4–5 million hectares; smallholders account for ~30–40% (1.2–2 million hectares). Realistic adoption rate is 50–60% of eligible smallholders by Year 12 if replanting finance, clean-plant networks, and price-stability tools are fully deployed. Lower adoption (<40%) would leave large areas uninsured against SALB incursion.

This assumes smallholders have access to credit with 7–10 year tenor, extension services, and price-floor mechanisms to buffer income during immature years.

## Smallholder Adoption Assessment

Typical agricultural adoption programs achieve 20–40% uptake; 50–60% is ambitious and requires exceptional credit access, extension reach, and farmer trust. Required assumptions: (1) replanting finance available in all major rubber regions at <5% interest and 7–10 year tenor; (2) clean-plant nurseries reach 80% of smallholder zones (estimated 50–100 nurseries distributed across Asia, Africa, Americas); (3) price-stability tools are credible and affordable, funded by levy or grants.

Risk: if credit access remains <30% due to weak rural banking or land-title uncertainty, adoption will plateau at 20–30%.

Mitigation: embed replanting finance into existing microfinance networks and village savings groups, leveraging existing trust structures.

Opportunity: if clean-plant and price-stability tools are linked to surveillance participation, adoption becomes income-generating for participating farmers, shifting incentive from subsidy-dependent to income-based.

---

## Question 5 - Multilateral Secretariat Governance and Enforcement

The multilateral secretariat is established as an independent body with seats for ≥6–8 producer governments, ≥3–4 OEM representatives, ≥3–4 development-bank representatives, and ≥3–4 independent technical experts. It is given binding authority to recommend gate decisions, with major funder agreement required to release tranches.

If a producer government contests a gate decision or refuses protocol implementation, enforcement options are: (1) withhold funding tranches allocated to that country; (2) escalate to development banks for political negotiation; (3) adjust gate criteria to reflect partial adoption by willing countries. No military or border-enforcement mechanism is assumed.

## Multilateral Secretariat Assessment

An independent secretariat improves legitimacy over a donor-led body but may weaken enforcement if producer governments block decisions disadvantaging their interests. Enforcement relies on funding conditionality and political leverage, not legal authority over sovereign states. If a major producer refuses protocol enforcement, the program cannot compel compliance and containment is broken.

Mitigation: (1) structure funding as per-country allocations, so non-compliant countries lose tranches but compliant countries benefit; (2) use regional peer pressure (ASEAN, ECOWAS forums) to discourage defection; (3) negotiate binding treaty language embedding protocol obligations as national law.

Risk: if contestation and disputes become frequent, decision latency will delay capital deployment and undermine smallholder and alternative-rubber timelines.

Opportunity: clear, technocratic gate criteria and independent Technical Panel recommendations reduce contestation and create external accountability.

---

## Question 6 - Alternative-Rubber Cost-Parity Target

Year 7 cost/quality KPI gate requires alternative-rubber production cost to reach within 15–20% of Hevea parity and tire-grade quality to pass 95% of current Hevea specifications (not full parity).

Guayule cost is expected to be $1.50–2.00 per kg in pilot plants by Year 7, compared to Hevea at ~$1.20–1.50 per kg. Russian dandelion is assumed to reach $1.60–2.20 per kg. Regional variation is acceptable: Guayule in Arizona targets $1.50/kg; Guayule in Mexico targets $1.80/kg. If actual costs exceed $2.40/kg by Year 7, the gate fails and processing scaling is delayed.

## Alternative-Rubber Cost Assessment

A 15–20% premium is optimistic; pilot projects typically take 8–12 years to reach cost targets. Guayule and Russian dandelion are entering commercial production after ~40–50 year gap, so historical cost data are outdated and technology must be rebuilt.

Risk: if by Year 6 pilot plants achieve only 30–40% premium to Hevea, realizing 15–20% by Year 7 requires 15% cost reduction in 12 months—unlikely without major breakthrough.

Mitigation: (1) set Year 7 gate to score 'partial achievement' if cost reaches 20–25% premium; (2) model processing economics including co-product revenue (resins, bagasse, inulin) so rubber price does not carry 100% of plant profitability; (3) allow regional flexibility, with gate averaging regional results.

Opportunity: if Year 5–6 pilot data show stronger cost trajectory, accelerate processing plant construction; if weak, delay and extend R&D before committing capex.

---

## Question 7 - Long-Term Funding Sustainability

Funding is sustained through: (1) binding 10-year grant commitments from ≥5–8 sovereign governments (Brazil, Indonesia, development partners) covering ~40–50% of capital; (2) multilateral development-bank concessional lending ($5–8 billion across 25 years) covering ~20–25% of capital; (3) per-tonne industry levy on natural-rubber trade or tyre production, expected to raise $150–300 million per annum (~40–50% of program); (4) outcome-linked bonds or contingent revenue instruments (royalties, alternative-rubber sales) covering remaining 5–10%.

Secretariat operations are funded from a ring-fenced endowment or trust, not annual appropriations. Political turnover does not interrupt commitments because they are embodied in treaties.

## Funding Sustainability Assessment

Binding 10-year grants and development-bank lending can be negotiated at program start, but extending beyond Year 10 requires renewal vulnerable to shifting political priorities. An industry levy is theoretically stable but requires agreement among competitors and compliance from diffuse actors, making it subject to evasion and political pressure if commodity prices fall.

Risk: if by Year 15 the levy erodes due to evasion or political withdrawal by key buyer countries, the program loses $150–250 million per annum and must either reduce scope or seek emergency replenishment.

Mitigation: (1) begin levy design and pilot implementation at Months 6–12 (2027-04-08 to 2027-10-08) before full commitment; (2) structure the levy as a variable percentage of trade value (not fixed per-tonne), so collection scales with commodity prices; (3) create a dedicated escrow or trust account for levy revenue, governed independently from annual budgets.

Opportunity: outcome-linked instruments (repaid from cultivar royalties or alternative-rubber sales) create revenue streams improving over time as cultivars and alternatives scale, providing self-sustaining capital source for Years 12–25.

---

## Question 8 - Climate-Shock Stress Scenarios and Resilience Threshold

Climate-shock scenarios applied at Year 7 gate include: (1) drought (2-in-20-year rainfall) reducing Guayule yields 20–30% and raising irrigation costs 25%; (2) flood (2-in-50-year event) reducing Russian dandelion germination; (3) temperature shift of +1.5–2°C in tropical zones making some trial sites unsuitable for Hevea.

Minimum resilience threshold by Year 12:

- Verified containment in ≥12 major producing countries
- Resistant-cultivar adoption by ≥1.5 million smallholders (50% of target)
- Alternative rubber (Guayule + Russian dandelion) supplying ≥200,000 tonnes per annum (~5% of global natural-rubber demand by Year 12, proposed threshold)

If any pillar falls below its minimum by Year 12, the program's resilience goal is not met and strategy pivots to emergency response.

## Climate-Shock Stress-Testing Assessment

Climate-shock stress-testing is essential because the program's 25-year horizon spans predicted shifts in rainfall and temperature. If alternative-crop pilots in arid zones are sensitive to water stress or cold snaps, and those shocks are not tested before Year 12, processing plants may fail to meet cost/quality KPIs and face forced closure or write-offs.

Risk: if climate projections worsen during the program, mid-program strategy pivots may consume $200–500 million in remediation R&D.

Minimum thresholds represent a lower bound for acceptable resilience; if all three are met, supply-chain risk is materially reduced. However, if only 1–2 pillars meet thresholds, residual vulnerability remains high.

Mitigation: (1) embed climate-scenario modeling into Year 7 and Year 12 gate assessments; (2) fund climate-adaptation research in parallel with main breeding pipeline; (3) maintain strategic rubber reserves as complement to supply diversification.

Opportunity: if climate models improve during the program, they can be incorporated into cultivar breeding targets (e.g., drought tolerance as secondary trait alongside SALB resistance).

# Distill Assumptions
# Sustainable Alternative Latex and Rubber (SALB) Program

## Overview

- Program duration: 25 years
- Total budget: $30 billion
- Phase 1 non-negotiable deliverable: globally adopted SALB Containment Protocol harmonized with existing phytosanitary standards
- Stage-gated funding with partial tranches released on KPI attainment, reallocated across pillars

## Funding Structure

- Sovereign grants: 40–50%
- Development-bank lending: 20–25%
- Per-tonne industry levy: 40–50%

## Gate Schedule and Requirements

- Month 18 (2028-04-08): Brazil delivers ≥200 wild Hevea accessions with SALB-resistance potential
- Year 3: Containment protocol gates funding; verified containment requires ≥15 producing countries with enforceable import rules and ≥500 trained inspectors
- Year 7: Cultivar readiness and cost/quality gates; guayule and Russian dandelion alternatives aim for 15–20% cost premium vs. Hevea parity; climate-shock scenarios tested
- Year 12: Cultivar adoption gate; smallholder uptake target 50–60% of eligible population (2–3 million farmers); alternative rubber must supply ≥200,000 tonnes annually (~5% global demand); minimum resilience threshold includes containment in ≥12 countries, ≥1.5M smallholders adopted, alternatives supply ≥200K tonnes; climate-shock scenarios tested
- Year 18: Final gate
- Years 25+: Post-funding handover with producer-country institutional capacity and technology transfer

## Hevea Breeding and Resistance Strategy

- Brazil leads access-and-benefit-sharing-compliant bio-prospecting and genomic breeding
- Resistance breeding uses pyramiding of multiple resistance sources tested at multiple endemic sites
- Targets delivery of SALB-resistant cultivars meeting performance and cost benchmarks

## Smallholder Adoption

- Program targets 2–3 million smallholder farmers for resistant-cultivar adoption or conversion by Year 12
- Adoption requires: replanting finance (7–10 year tenor), clean-plant networks, price-stability mechanisms
- Target: 50–60% adoption of eligible smallholder population by Year 12

## Alternative Rubber (Guayule and Russian Dandelion)

- Cost target: 15–20% cost premium vs. Hevea parity by Year 7
- Production target: ≥200,000 tonnes annually (~5% global demand) by Year 12
- Colocated processing and OEM procurement drive economic case and reduce logistics cost

## Containment Protocol

- Year 3 gate: ≥15 producing countries with enforceable import rules and ≥500 trained inspectors required
- Minimum resilience threshold by Year 12: containment in ≥12 countries

## OEM Engagement

- Offtake agreements are take-or-pay contracts conditional on material meeting agreed qualification tests

## Governance

- Multilateral secretariat has binding authority over gate decisions
- Includes seats for producer-government, OEM, and development-bank representatives


# Review Assumptions
# Domain of the Expert Reviewer
Large-scale public-private agricultural supply-chain resilience and phytosanitary infrastructure spanning 25-year stage-gated programs, global protocol harmonization, multi-continent field trials, smallholder finance, and commodity trade mechanisms.

## Domain-Specific Considerations

- Harmonization of phytosanitary standards across sovereign national regulatory systems and regional frameworks (IPPC, ASEAN, ECOWAS, Mercosur) with no supranational enforcement authority
- Breeding timeline unpredictability (5–12 years per cultivar cycle) in tension with binary stage-gate funding (Years 3, 7, 12, 18) and smallholder adoption windows
- Smallholder credit access and adoption risk in developing regions with weak rural banking, land-title uncertainty, and endemic price volatility
- Commercial-scale alternative-crop technology (Guayule, Russian dandelion) with 40–50 year production gap and unproven cost parity vs. incumbent Hevea
- Pathogen population genomics and resistance durability over multi-decade timelines, with risk of single-gene breakdown requiring re-breeding cycles
- Multilateral governance durability across political cycles and funder turnover with no binding enforcement mechanism over sovereign producers

# Issue 1 – Critical Missing Assumption: SALB Incursion Risk Model and Year 3 Gate Logic Under Uncertainty

## Problem
The plan assumes containment protocol verification ('≥15 countries with enforceable rules, ≥500 inspectors, ≥25 interceptions') proves the protocol works by Year 3. This conflates regulatory adoption with operational efficacy: a protocol is adopted before it is tested under field challenge. If SALB has not reached Asia/Africa by Year 3 (likely, given endemic-only presence), zero interceptions do not prove the protocol works—they prove absence, not prevention. The Year 3 gate gates money on bureaucratic readiness, not demonstrated containment performance. If a surprise incursion occurs at Year 4–5 despite gate passage, the gate loses credibility retroactively.

## Recommendation
Reframe the Year 3 gate as 'Protocol Readiness,' not 'Verified Containment.' Score the gate on: (1) ≥15 countries adopt binding import rules; (2) ≥500 inspectors trained and operational; (3) ≥2 documented 'near-miss' interceptions or suspect detections cleared by laboratory (lower bar than confirmed incursions). Establish a separate 'Containment Efficacy Review' at Months 72–84 (2032-10-08 to 2033-10-08) to assess whether inspections have detected and logged suspect material. If zero suspects are identified by Month 72 (2032-10-08), escalate surveillance sensitivity (testing protocols, inspector frequency, sampling rates). Hold a contingency $500M–$1B reserve fund (separate from gate tranches) for emergency outbreak response if an incursion occurs Months 48–96 (2030-10-08 to 2034-10-08), regardless of gate performance. This separates governance readiness from biological outcome.

## Sensitivity
If Year 3 gate is interpreted as 'containment is proven to work,' a surprise incursion at Month 60 (2031-10-08) would cost $2–5B in outbreak response and cause 50–80% funder withdrawal, delaying alternative-rubber and breeding timelines by 3–4 years. Reframing Year 3 gate to 'readiness' rather than 'proof' reduces this damage: funders exit less drastically because gate criteria were explicit about what was being tested (infrastructure), and contingency funding is pre-positioned.

# Issue 2 – Critical Missing Assumption: Resistance Durability Feedback Loop and Virulence Tracking Integration into Breeding Cycles

## Problem
The program assumes pyramiding multiple Hevea resistance sources from wild germplasm will deliver durable resistance. However, the mechanism linking pathogen-side virulence data (from Pathogen Population Genomics and Virulence Tracking) into breeding decisions is not specified. If virulence tracking detects emerging biotypes capable of overcoming a candidate cultivar's resistance genes before release, the breeding program must pivot—holding that candidate and selecting an alternative. This creates a feedback loop: breeding progress is conditional on pathogen surveillance data, which may show resistance vulnerability late in the trial cycle, forcing expensive delays. Without explicit commitment to 'halt release if virulence data shows risk,' cultivars may be deployed prematurely where they fail 5–10 years later, repeating the historical single-gene-breakdown cycle.

## Recommendation
Establish mandatory 'Virulence Gates' at Months 24, 36, 48, and 60 (2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08): before any cultivar enters final-stage trials or production scaling, sequence virulent SALB isolates from endemic trial sites and test their ability to overcome that cultivar's resistance genes in high-containment assays. If virulent biotypes matching or overcoming the candidate's resistance are detected, that candidate is held back, additional pyramiding is required, and release is delayed. Embed this assessment into the Year 7 and Year 12 cultivar-readiness gates as a non-negotiable sub-criterion. Fund pathogen sequencing continuously (Months 0–240 = 2026-10-08 to 2046-10-08), not as an afterthought. Include genetic diversity of resistance sources in pyramiding strategy: require each released cultivar to carry ≥3 independent, functionally distinct resistance genes from ≥2 geographic sources, reducing single-point-of-failure risk.

## Sensitivity
If virulence tracking is weak or absent, cultivars released at Months 84–144 (2033-10-08 to 2038-10-08) risk breakdown by Months 180–300 (2041-10-08 to 2051-10-08) (baseline: 30–50% probability of single-gene failure by Month 120 = 2036-10-08 for historical single-source cultivars). Discovery of breakdown at Months 180–240 (2041-10-08 to 2046-10-08) would trigger emergency re-breeding (cost: $400–800M, timeline: 5–8 years), delaying true supply diversification to Months 240–336 (2046-10-08 to 2054-10-08) and creating stranded smallholder investments. Robust virulence tracking reduces this risk to <10% by ensuring cultivars are released only if virulent biotypes cannot overcome them within 5-year forecast. Cost of continuous virulence tracking (estimated $20–40M over 25 years) is <1% of breeding budget but prevents $400–800M re-breeding cycle.

# Issue 3 – Critical Missing Assumption: Smallholder Adoption Sequencing and Incentive Alignment with Surveillance Participation

## Problem
The program assumes smallholders will adopt resistant cultivars or alternative crops if offered replanting finance, clean-plant material, and price-stability tools. However, the incentive structure linking adoption to surveillance participation is underspecified. Smallholders have no inherent incentive to report disease if reporting triggers quarantine, movement restrictions, or tree-removal orders that damage their income. Voluntary surveillance has historically failed in crop-protection programs: farmers conceal infections to avoid penalties. The program's success depends on early detection of SALB incursions in Asia/Africa (via surveillance), yet smallholder participation in surveillance is assumed without explicit incentive design. If participation remains low (<20% of target population), surveillance coverage of smallholder areas is weak, and incursions may establish undetected until too large to eradicate.

## Recommendation
Integrate surveillance incentives into smallholder replanting and price-stability mechanisms. Design tiered income premiums: farmers who participate in quarterly field monitoring and submit suspect-sample submissions are eligible for enhanced price floors or income-bridge premiums (+$50–100 per hectare per year, estimated cost: $30–50M annually for 2–3M farmers participating, offset against alternative-rubber plant profits). Create mobile-enabled verification systems (photo-based GPS reporting, laboratory-confirmed results) so that farmers receive payment confirmation within 2–4 weeks of sample submission, building trust and repeat participation. Link clean-plant-network access to surveillance participation: only farms demonstrating 90%+ clean-plant practices (verified via spot checks) can access subsidized planting material or credit refinancing. This transforms surveillance from a 'compliance burden' into an 'income opportunity,' shifting incentive sign. Pilot this model in 3–5 representative smallholder zones (Sumatra, Côte d'Ivoire, northeast India) at Months 6–24 (2027-04-08 to 2028-10-08), with participation targets of 60%+ before scaling to 2M farmers.

## Sensitivity
If smallholder surveillance participation remains <30% due to weak incentives or trust deficits, surveillance sensitivity in smallholder zones drops 60–80%, leaving SALB incursions undetected until establishment is advanced. Cost of late detection and response (Months 60–96 = 2031-10-08 to 2034-10-08 incursion vs. Months 12–24 = 2027-10-08 to 2028-10-08 incursion, or 2031-10-08 to 2034-10-08 vs. 2027-11-08 to 2028-10-08) is estimated at $1–3B additional outbreak cost plus 5–10 year delay in supply diversification. By contrast, $50–100 per-hectare annual surveillance premium (total $100–300M over 25 years) achieves 60%+ participation, early detection, and substantial cost-benefit reduction.

# Review Conclusion

This 25-year, $30 billion multi-continent program rests on three interdependent, misaligned pillars with different timelines, verification logic, and risk profiles. The containment protocol must be verified by Year 3 through bureaucratic adoption metrics (≥15 countries with rules, ≥500 inspectors), but this measures readiness, not proven efficacy—a critical conflation that leaves the Year 3 gate logically vulnerable to later incursions that invalidate its credibility retroactively. Resistance breeding and alternative-rubber cost/quality targets depend on biological timelines and market conditions that slip unpredictably; the stage-gate framework must accommodate these delays without losing funder confidence, requiring explicit partial-achievement tranching and contingency reserves (15% of budget, $4.5B, estimate) held outside gate logic. Smallholder adoption at 50–60% (2–3 million farmers) is essential for supply-chain resilience but depends on fragile incentive alignment—farmers must report disease (early detection) despite risk of quarantine and income loss, requiring embedded surveillance-premium mechanisms (+$50–100/hectare) that are not specified in the current plan. The three highest-priority actions are: (1) reframe Year 3 gate to 'Protocol Readiness' (bureaucratic/capacity metrics) separate from 'Containment Efficacy Review' (Months 72–84, 2032-10-08 to 2033-10-08, based on field detection data); establish dedicated contingency outbreak-response reserves ($500M–$1B) outside gate tranches; (2) mandate continuous pathogen virulence tracking (Months 0–240 = 2026-10-08 to 2046-10-08) with mandatory Virulence Gates (Months 24, 36, 48, 60 = 2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08) that halt cultivar release if emerging biotypes overcome resistance, preventing premature deployment into supply-chain failure; (3) design tiered surveillance incentives (income premiums, clean-plant access) integrated into smallholder replanting finance, piloting in 3–5 representative zones (Months 6–24, 2027-04-08 to 2028-10-08) before scaling, to achieve 60%+ participation in early-detection networks. Without these corrections, the program risks either gate disputes that delay funding (3–6 month latency × $500M–$1B tranches = $250M–$500M cost) or premature cultivar release that fails by Months 180–240 (2041-10-08 to 2046-10-08), requiring $400–800M re-breeding cycles and forfeiting supply-chain resilience claims.