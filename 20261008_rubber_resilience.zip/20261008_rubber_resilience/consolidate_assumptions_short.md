# Purpose
# Global Natural Rubber Supply Chain Resilience Initiative

## Overview

25-year, $30 billion public-private program to de-risk global natural rubber supply from South American Leaf Blight (SALB) through:

- Globally adopted SALB Containment Protocol harmonized with phytosanitary standards
- SALB-resistant yield-parity Hevea cultivars via Brazil-led access-and-benefit-sharing-compliant bio-prospecting and genomic breeding
- Commercialization of alternative rubber crops (Guayule, Russian dandelion) with colocated processing and OEM offtake agreements

## Objectives

- Verified containment of SALB
- Diversified supply chains
- Resilient procurement against pathogen and climate shocks

## Implementation Model

- Stage-gated funding at Months 36/84/144/216 (2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12) tied to containment, cultivar readiness, and cost/quality KPIs
- Smallholder adoption through replant finance, clean-plant networks, and price-stability tools
- Agricultural, infrastructure, and supply-chain resilience at societal and economic scale


# Domain
# Primary domain: Plant Pathology

Secondary domains: Plant Breeding, Supply Chain Resilience, Phytosanitary Regulation

## Rationale

Plant Pathology is the top outcome candidate (importance 5 × specificity 5) and owns the SALB containment deliverable, which is the program's non-negotiable gate. Supply Chain Resilience scores lower; Plant Breeding, Phytosanitary Regulation and the others are methods or constraints.

# Disciplines

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Plant Pathology | 5 | 5 | outcome | SALB containment, surveillance and quarantine protocols are the Phase 1 non-negotiable deliverable. |
| Plant Breeding | 5 | 5 | method | Genomic breeding must deliver SALB-resistant, yield-parity Hevea cultivars. |
| Phytosanitary Regulation | 5 | 5 | constraint | The containment protocol must harmonize with regional plant quarantine standards for nursery stock, materials and equipment. |
| Plant Genomics | 4 | 5 | method | Genomic breeding and bio-prospecting underpin SALB-resistant, yield-parity Hevea cultivar development. |
| Genetic Resources Law | 4 | 5 | constraint | Access-and-benefit-sharing compliance governs Brazil-led bio-prospecting and germplasm use across jurisdictions. |
| Supply Chain Resilience | 4 | 4 | outcome | Success requires diversified parallel rubber supply chains and resilient OEM procurement. |
| Agricultural Finance | 4 | 4 | method | Smallholder replant finance and price-stability tools determine adoption of resistant cultivars and alternatives. |
| Rubber Processing | 4 | 4 | method | Guayule and dandelion rubber need colocated processing meeting OEM cost and quality specifications. |
| Smallholder Agronomy | 4 | 4 | stakeholder | Program adoption depends on smallholder replanting, clean-plant networks, and extension for Hevea, Guayule, and dandelion. |

# Plan Type
# Plan Overview

This is a 25-year, $30 billion public-private program to protect the global natural rubber supply from South American Leaf Blight (SALB).

## Physical Requirements

This plan requires one or more physical locations and cannot be executed digitally.

The program's core components all require real-world locations, resources and activity:

- SALB Containment Protocol: physical surveillance, field inspections, quarantine facilities, and red-team drills at plantations, borders, ports and nurseries
- Brazil-led bio-prospecting and genomic breeding: field collection of Hevea germplasm in the Amazon basin, laboratories, greenhouses, breeding stations, and multi-location field trials to confirm SALB resistance and yield parity
- Alternative crops: Guayule in arid zones and Russian dandelion in temperate climates require land, agronomic trials, farming, harvesting, and colocated rubber processing plants built and operated at physical sites, plus OEM offtake agreements tied to physical product shipments and quality testing
- Smallholder adoption: physical nurseries, on-farm replanting and in-person farmer engagement
- Stage gates at Years 3/7/12/18: depend on field-measured containment performance, cultivar readiness and alternative-rubber cost/quality KPIs, verified through physical testing and inspection

Some parts, such as protocol drafting, genomic data analysis, financial structuring and KPI reporting, can be done digitally. The program as a whole has direct and unavoidable physical requirements (land, facilities, equipment, travel, field work, and in-person coordination).

# Physical Locations
# Physical Locations

## Requirements

- Brazilian Amazon access for Hevea germplasm collection under ABS/Nagoya-compliant agreements
- Established rubber research institutions, laboratories, greenhouses and multi-site field-trial capacity
- Guayule sites in arid or semi-arid zones with suitable climate, marginal land and limited water demand
- Russian dandelion sites in temperate climates with existing agricultural infrastructure and logistics
- Colocated rubber processing plants near feedstock, with access to ports, highways and OEM tire makers
- Proximity to major smallholder rubber regions (Southeast Asia, West Africa, Brazil) for nurseries and extension
- Quarantine-capable facilities and inspection capacity at nurseries, borders and ports
- Institutional anchor near IPPC and regional plant protection organization bodies for protocol adoption
- Stable governance, land tenure clarity and political support for 25-year commitments

## Brazil

Amazon basin (Acre, Amazonas, Mato Grosso, Para) with breeding hubs in Sao Paulo state. Wild Hevea collection sites in the Amazon; breeding and trial stations at research institutes in Sao Paulo state (e.g., Campinas area) and Manaus.

## Rationale

Brazil-led, ABS-compliant bio-prospecting and genomic breeding requires Amazon's centre of Hevea diversity and original resistance sources. Existing agricultural research institutions provide laboratory and field-trial capacity.

## USA and Mexico

Arizona, New Mexico, Texas, Coahuila and Chihuahua. Arid-zone farmland in central/southern Arizona and Chihuahuan Desert margins with colocated guayule processing plant sites.

## Rationale

Guayule is native to this region with established commercial trials. Suitable climate, existing growers, tire-industry presence and processing precedent support commercial-scale guayule with colocated processing and OEM offtake.

## Europe and Temperate Eurasia

Germany, Netherlands, Belgium and Kazakhstan. Temperate farmland near tire-industry clusters in Lower Saxony/Germany and Benelux, with Kazakh feedstock origin region (Tau-saghyz/Russian dandelion homeland).

## Rationale

Russian dandelion suits temperate climates. European sites sit near major tire makers and OEM buyers with existing dandelion rubber research, supporting colocated processing, offtake and cost/quality KPI testing.

## Southeast Asia

Southern Thailand, Sumatra and Peninsular Malaysia rubber belts. Smallholder rubber districts with national rubber research institutes, for clean-plant nurseries, extension, replanting and quarantine/inspection hubs.

## Rationale

These regions produce most of the world's natural rubber and remain free of SALB. Containment protocol enforcement, clean-plant networks and smallholder replant finance matter most here; trial of resistant clones must occur in major producing areas.

## Italy and International

Rome, home of the IPPC Secretariat (FAO). FAO headquarters, Viale delle Terme di Caracalla, Rome.

## Rationale

The protocol is to be embedded in the IPPC framework and harmonized with regional standards. Programme governance, protocol drafting and gate-audit coordination benefit from proximity to the IPPC Secretariat.

# Currency Strategy
and

# Identify Risks
# Risk 1 - Institutional & Regulatory

The SALB Containment Protocol, designated as non-negotiable Phase 1 deliverable, must be harmonized with existing IPPC and regional phytosanitary standards and adopted by producing nations. Embedding it within the IPPC framework provides legitimacy but depends on consensus-driven international standard-setting where major rubber-producing nations (Brazil, Indonesia, Thailand, Malaysia, Vietnam) retain veto power. Sovereign nations may view the protocol as enforcement overreach, particularly if compliance requires intrusive inspections or quarantine costs borne by smallholders. Delays in national regulatory adoption or non-implementation by key producers will block Phase 1 completion and cascade failures in gate logic.

Impact: If adoption is delayed, Phase 2 scale-up cannot begin; stage gates at Years 3, 7, 12, 18 lose their containment-verification mandate; risk of uncontrolled SALB spread increases; sovereign delays of 6–18 months are plausible. Financial impact: reputational damage and inability to trigger gate funding tranches, estimated at $500 million–$2 billion in deferred capital.

Likelihood: Medium

Severity: High

Action: Secure pre-commitment from the top five producing nations by Month 6 (2027-04-12), embedding protocol adoption in bilateral memoranda of understanding before drafting the IPPC standard. Establish a dedicated protocol-adoption secretariat at FAO (or IPPC) by Month 3 (2027-01-12) with dedicated staff and a 24-month adoption target. Use pilot SALB-response drills in Months 12–18 (2027-10-12 to 2028-04-12) to prove protocol value. Reserve 2–4% of capital for national adoption support.

# Risk 2 - Technical & Biological

The Resistance Breeding Pathway relies on polygenic selection of multiple Hevea resistance sources crossed into high-yield Asian clones. Hevea is a perennial tree crop with 6–10 year field cycles, so durability and yield testing cannot be accelerated. Field trials across multiple sites may show that resistance stacks are not durable, yield penalties exceed 10–15%, or cross-compatibility delays cultivar release beyond Month 84 (2033-10-12) (Year 7 gate deadline).

Impact: Failure to meet Year 7 gate KPI (cultivar readiness: yield ≥90% of current elite clones, ≥3 independent resistance sources stacked) delays cultivar deployment by 3–5 years. Year 7 gate funding ($5–8 billion, estimate) is withheld, creating a capital shortfall. OEM offtake contracts cannot be signed. Estimated cost of delaying deployment across 1 million smallholder hectares: $2–4 billion in lost adoption finance.

Likelihood: Medium

Severity: High

Action: Initiate multi-site field trials by Month 12 (2027-10-12) at established breeding stations in Brazil, Thailand, Indonesia and Côte d'Ivoire. Pre-register breeding targets by Month 6 (2027-04-12): yield ≥90% of elite clone set, ≥2 confirmed resistance sources by Month 60 (2031-10-12), ≥3 stacked sources by Month 84 (2033-10-12). Establish an independent breeding advisory board by Month 3 (2027-01-12) to track progress quarterly; if yield penalties exceed 15% by Month 48 (2030-10-12), trigger a decision to parallel fast-track crown-budding systems. Allocate $200–300 million to multi-site trials and cultivar validation.

# Risk 3 - Technical & Economic

Alternative rubber crops (Guayule, Russian dandelion) face persistent cost and quality gaps against Hevea. Guayule yields 600–1,200 kg/ha/year; rubber extraction requires energy-intensive processing with costs 20–50% higher than Hevea latex processing. Russian dandelion yields 400–800 kg/ha/year; rubber extraction is less developed at commercial scale. Processing plant capital costs ($100–300 million per plant, estimate) are recovered only if feedstock cost and tire-quality performance hit tight KPI targets by Years 12–18.

Impact: If alternative-rubber delivered costs stay ≥30% above Hevea benchmarks by Month 144 (2038-10-12) (Year 12 gate), offtake agreements are unsigned and plants are underutilised. Financial consequences: $3–6 billion in processing-plant capital is stranded; alternative-crop acreage stalls at pilot scale; Year 12 gate funding ($4–6 billion, estimate) is withheld; supply-diversification goal is not met.

Likelihood: Medium

Severity: High

Action: Launch pilot processing plants (Months 6–24 = 2027-04-12 to 2028-10-12) in both geographies: a 2,000–5,000 tonne/year Guayule extraction facility in Arizona/Mexico and a 1,000–3,000 tonne/year dandelion processing pilot in Germany/Benelux. Run tire-performance qualification trials (Months 24–48 = 2028-10-12 to 2030-10-12) in parallel. Set clear cost KPI waypoints: Month 48 (2030-10-12) (Guayule feedstock cost ≤$1.20/kg dry matter, dandelion ≤$1.00/kg, estimate), Month 84 (2033-10-12) (processing cost ≤$2.50/kg crude rubber for both, estimate). If targets are missed by Month 60 (2031-10-12), trigger a portfolio decision: either commit increased capital to processing innovation or redirect capital to resistant-Hevea breeding. Reserve $500–800 million for processing R&D and pilot-scale losses.

# Risk 4 - Financial & Capital Structure

The 25-year, $30 billion program depends on stage-gated funding: capital tranches released only if Years 3/7/12/18 gates are passed. Ring-fenced industry levy funding is stable but politically sensitive and dependent on industry participation; defection by key OEMs reduces available capital. Sovereign and multilateral development-bank funding may fluctuate with budget cycles or competing priorities. If major gates are not passed, the capital shortfall for the subsequent phase cascades.

Impact: Scenario 1: If Year 7 gate is missed, Year 7–12 phase capital ($5–8 billion, estimate) is withheld, creating a shortfall with no recovery path. Scenario 2: If industry-levy contributions fall by 25% due to OEM defections, annual recurring capital drops by $150–250 million (estimate), stretching the program beyond 25 years. Scenario 3: A major geopolitical event destabilises funding or forces reprioritization. Estimated impact: program cost overrun of $3–6 billion or multi-year delays.

Likelihood: Medium

Severity: High

Action: Lock in sovereign and development-bank commitments through legally binding 25-year framework agreements by Month 12 (2027-10-12), with explicit gate-release mechanisms and minimum-funding floors (e.g., 80% of planned tranche if gate is partially met). Establish an industry resilience levy agreement (Months 6–12 = 2027-04-12 to 2027-10-12) with binding multi-year commitments from top 10 tire makers and 5 major traders, with penalties for early defection. Create a contingency reserve equal to 15–20% of the capital stack ($4.5–6 billion, estimate), ring-fenced from annual disbursal and released only if gates are missed due to external shocks rather than program performance. Diversify funding sources: pursue impact investment, catastrophe bonds, and export-credit-agency backing.

# Risk 5 - Operational & Supply Chain

Smallholder adoption of resistant clones and alternative crops requires replanting finance, clean-plant nurseries, extension services and price-stability guarantees. The clean-plant network depends on trained nursery operators and inspection capacity. If nurseries are inadequately staffed or inspected, contaminated stock can circulate, undermining containment and breeding objectives. Smallholder replanting decisions lag availability of finance and clean plants; adoption rates historically run 20–40% of eligible farmers. If uptake is only 20–30% instead of 50–70%, resistance gains are geographically fragmented and provide no region-wide protection.

Impact: Scenario 1: If nursery inspection capacity is insufficient (<30,000 inspected lots per year across Southeast Asia instead of 100,000+), contaminated stock circulates and SALB reaches smallholder plantings. This undermines containment proof at gates and creates regional isolation zones. Scenario 2: If smallholder adoption is 30–40% instead of 60%+, resistant-cultivar acreage covers only 10–15% of productive zones by Year 12. Risk remains concentrated on susceptible clones. Scenario 3: If extension corps are cut after Year 10, adoption stalls. Estimated financial impact: $1–2 billion in sunk smallholder finance and extension costs yielding <50% of planned adoption.

Likelihood: High

Severity: Medium

Action: Establish the Extension Corps and Nursery Workforce Pipeline as a separate, protected funding stream ($300–500 million over 25 years, estimate) with decentralised, locally-owned management structures (cooperative nurseries, farmer-led extension scouts) rather than centralised program employment. By Month 12 (2027-10-12), recruit and train at least 500 lead extension agents across the five major producing countries, each serving 200–500 smallholders. Establish 50–100 certified small-scale nurseries per major country. Tie replant-finance disbursement to verified participation in extension and clean-plant uptake. Build in a contingency adoption buffer: design targets for 40–50% actual uptake, not 60–70%.

# Risk 6 - Access, Benefit-Sharing & IP

The program is built on Brazil-led, Nagoya Protocol–compliant bio-prospecting using Amazonian Hevea germplasm. Access and benefit-sharing (ABS) agreements between the program, Brazil's national biodiversity authority, and indigenous/traditional communities are required before material can be transferred. Negotiating ABS agreements is slow (12–36 months per agreement, not verified); disputes over benefit-sharing obligations, data use rights and downstream cultivar royalties can block material transfer and delay breeding cycles.

Impact: Scenario 1: Bilateral ABS negotiations delay material transfer by 12–18 months, pushing the start of resistance selection trials from Month 6 (2027-04-12) to Month 18–24 (2028-04-12 to 2028-10-12), compressing the timeline for Year 7 gate readiness. Scenario 2: Communities or Brazil insist on royalty payments on all commercial cultivars, adding 2–5% to downstream smallholder seed costs and reducing adoption incentives. Scenario 3: A legal challenge to ABS compliance blocks cultivar release or creates liability, estimated at $100–500 million.

Likelihood: Medium

Severity: Medium

Action: Negotiate bilateral ABS agreements with Brazil's CGen and at least three major indigenous/traditional-community groupings in the Amazon by Month 6 (2027-04-12), setting clear benefit-sharing terms: fixed per-hectare payments on commercial cultivar deployment, royalty-free seed for smallholders, open access to genomic sequences for non-commercial research. Use a tiered benefit-sharing model with high-value payments ($1–5 per hectare, estimate) for cultivars deployed at scale. Hire specialised ABS legal counsel by Month 1 (2026-11-12) and allocate $10–20 million (estimate) for consultation, agreements and benefit-sharing disbursements. Establish a community-governed data trust with seats for indigenous representatives. Publish all ABS agreements and benefit-sharing payments publicly.

# Risk 7 - Technical & Surveillance

The Surveillance Sensing Architecture must detect SALB incursions early (target: <3 months from first infection to confirmed detection) to enable containment response. Detection methods include inspector-led field scouting, instrumented spore traps and molecular diagnostics, or smallholder sentinels. If detection latency exceeds 6 months in a new region, SALB is likely already spreading beyond initial site, and the containment doctrine becomes harder to execute credibly. Laboratory diagnostic capacity is bottlenecked in resource-limited countries.

Impact: Scenario 1: A SALB incursion in Southeast Asia is first detected >6 months after initial infection, affecting 50+ hectares instead of <5 hectares. Eradication-first containment requires destroying 500+ hectares of surrounding plantings, affecting 1,000–2,000 smallholders. Compensation and replanting costs balloon to $50–100 million (estimate). Scenario 2: False-positive alerts trigger unnecessary quarantines, reducing farmer willingness to report actual symptoms. Scenario 3: A developing-country government lacks laboratory capacity to confirm SALB, leading to diagnostic delays of 2–3 months. Estimated impact: uncontrolled SALB spread reduces productive area by 20–40% before resistance deployment.

Likelihood: Medium

Severity: Medium

Action: Establish a networked, tiered surveillance system by Month 12 (2027-10-12): (1) Tier 1 (primary producing countries): funded, trained national inspector networks with bi-monthly field scouting in high-risk nurseries and estates, supported by monthly regional laboratory confirmation (molecular PCR for SALB). Target: detection <3 months. (2) Tier 2 (secondary producing regions and borders): quarterly scouting plus simplified field diagnostics (visual symptom guides, portable ELISA or loop-mediated isothermal amplification). Target: detection <6 months. (3) Smallholder sentinel programme: pay verified reporters $5–20 per confirmed SALB alert, with a regional expert team confirming within 2 weeks. Build laboratory diagnostic capacity: fund at least 10 regional labs across producing countries by Month 24 (2028-10-12). Allocate $50–100 million over 10 years for surveillance operation and labs.

# Risk 8 - Institutional & Governance

The Gate Evidence Verification Regime determines the credibility of Year 3/7/12/18 funding decisions. Independent auditing depends on auditors having reliable access to field data, breeding-trial records and cost/quality test results. Auditors depend on the same data sources that programme managers use, so independence is partial. If programme managers withhold unfavourable data or if national partners under-report poor results, auditors may issue inflated assessments. Conversely, if auditors are overly conservative, legitimate progress may be stalled by procedural disputes. The pre-fixed audit scope may miss emerging risks that materialise later.

Impact: Scenario 1: A Year 7 breeding gate is passed based on trial data that understates yield penalties. Cultivars are released to farmers and prove less durable in full-scale plantings. By Year 10, grower confidence collapses and replanting stalls. Estimated impact: $2–3 billion in sunk breeding and nursery investment yields <20% of adoption. Scenario 2: Auditors dispute the Year 3 gate, claiming that surveillance data are insufficient to prove zero incursions. Gates are delayed by 6–12 months while audit scope is renegotiated. Scenario 3: Auditor teams lack expertise in tropical phytosanitary surveillance or perennial-crop breeding.

Likelihood: Medium

Severity: Medium

Action: Establish the Gate Evidence Verification Regime framework by Month 3 (2027-01-12): contract an independent international auditor (e.g., a consortium of agricultural audit firms or a multilateral audit entity) for all four gates. Pre-register the audit scope, methodology and KPI definitions for each gate in legally binding documents by Month 6 (2027-04-12), with stakeholder sign-off from funders and programme leadership. Require auditors to use a multi-source verification approach: on-site field visits (30–40% of audit), database audits (40–50%), and interviews with independent estate and smallholder samples (20–30%). Build in a dispute-resolution mechanism: if programme and auditors disagree on gate status, a neutral third-party adjudication panel issues binding judgment within 60 days. Allocate $30–50 million over 25 years for independent audits and adjudication.

# Risk 9 - Supply Chain & OEM Offtake

The Offtake and Strategic Reserve Design depends on tire makers and industrial OEMs signing long-term purchase agreements for alternative-rubber and resistant-Hevea output. OEMs are hesitant to commit large offtake volumes to unproven feedstocks without demonstrated quality, supply reliability and price stability. Alternative-rubber feedstocks have not been used at scale in modern tires; qualifications take 18–24 months and may reveal unexpected performance gaps. If OEMs do not sign offtake agreements, processing plants cannot be financed, and alternative crops are stuck at pilot scale.

Impact: Scenario 1: By Month 60 (2031-10-12), tire-performance qualifications for Guayule and dandelion rubber are incomplete, and OEMs delay offtake commitments pending full tread-wear and durability data. Processing plants planned for Month 72 (2032-10-12) construction cannot be financed. Scenario 2: Alternative rubber meets OEM specifications but at a quality variance (±10% vs. Hevea standard) or cost premium (15–20% above Hevea) that OEMs judge unacceptable. Offtake is signed only for specialty/premium products (5–10% of tire production), instead of 20–30% target. Estimated impact: $2–4 billion in processing-plant capital is underutilised.

Likelihood: Medium

Severity: Medium

Action: Launch OEM engagement by Month 3 (2027-01-12) with the top 10 tire makers, securing non-binding letters of intent for offtake trials by Month 12 (2027-10-12). Run tire-performance qualification trials in parallel with crop and processing trials (Months 12–48 = 2027-10-12 to 2030-10-12), using accredited testing labs and publishing results transparently. Structure offtake agreements (Months 48–60 = 2030-10-12 to 2031-10-12) as purchase-option contracts rather than firm take-or-pay commitments: OEMs pay a small annual reservation fee (1–2% of planned volume value, estimate) for priority access, converting to firm purchases only after quality specifications are confirmed. Reserve $100–150 million (estimate) for tire-performance qualification and OEM engagement. Establish an OEM steering committee by Month 6 (2027-04-12) that meets quarterly.

# Risk 10 - Climate & Environmental

The programme is positioned as enhancing global natural-rubber supply resilience to pathogen and climate shocks. However, climate change poses risks: Guayule in the North American arid southwest may face increasing drought stress and water scarcity. Russian dandelion in temperate Europe may face heat stress and shifted growing seasons if temperature increases exceed 2°C above baseline. Climate warming may expand SALB suitable habitat into currently disease-free zones. Hevea cultivar testing sites may experience atypical rainfall, heat waves or flooding during critical growth phases, invalidating yield and durability estimates.

Impact: Scenario 1: Guayule yields in Arizona/New Mexico fall by 20–30% due to accelerated aquifer depletion and drought (Years 10–25), making processing plants uneconomical. By Year 18, Guayule supply is insufficient to meet offtake agreements. Estimated impact: $1–1.5 billion in stranded processing-plant capital. Scenario 2: SALB suitable habitat expands into East Africa or Southern Africa due to warming, introducing the pathogen to regions currently free. Estimated impact: productive area loss of 5–15%, estimated $1–2 billion in lost output. Scenario 3: Hevea field trials experience unexpected climate stress during critical trial phase (Months 24–60 = 2028-10-12 to 2031-10-12), invalidating yield and durability estimates.

Likelihood: Medium

Severity: Medium

Action: Integrate climate-risk assessment into trial site selection and alternative-crop siting (Months 3–6 = 2027-01-12 to 2027-04-12). For Guayule, model aquifer depletion and water-stress scenarios under multiple climate futures (1.5°C, 2°C, 3°C warming); if yields drop >25% in high-risk scenarios, consider alternative arid sites (e.g., northern Patagonia, southern Spain, Middle East) or shift some Guayule investment to Russian dandelion. For dandelion, model temperature and growing-season shift impacts; if European sites become unsuitable, develop alternative temperate-zone sites (southern Canada, Russia, Central Asia). Diversify alternative-crop footprint geographically. Establish SALB habitat suitability monitoring by Month 12 (2027-10-12) onward using climate and biotic data to predict range expansion; if expansion is detected, trigger early protocol deployment and surveillance surge in at-risk regions. Build climate-adaptation capacity into smallholder support: recommend crop and cultivar choices that are resilient to local climate trends. Allocate $50–100 million (estimate) to climate-risk monitoring and adaptive-management decision-support systems.

# Risk 11 - Regulatory & Trade

Gene-edited or transgenic rubber cultivars (if pursued in an alternative pathway) face regulatory approval uncertainty in major importing markets (EU, some Asian countries). Import regulations for gene-edited crops vary widely: the EU applies precautionary, slow-approval processes; Japan and China have different regulatory frameworks. If the programme pursues gene-edited resistance (not in the Pragmatic Foundation scenario but plausible in emergent strategy), cultivars may be approved in some markets (Brazil, USA, India) but not in others (EU, Japan), fragmenting the cultivar supply base.

Impact: Scenario 1 (if gene-editing is pursued): A gene-edited, SALB-resistant Hevea clone is approved in Brazil and USA by Month 72 (2032-10-12), but EU regulatory approval is delayed to Month 120 (2036-10-12) due to precautionary review. If cultivar is planted in Brazil/India/Americas by Month 84 (2033-10-12), but EU/Japan prohibit imports of rubber from gene-edited sources, European tire makers lose access to a significant supply. Trade disputes disrupt OEM offtake agreements. Scenario 2: Strict adherence to conventional breeding is slow, and Year 7 gate readiness is questionable. Pressure mounts to accelerate using crown-budding or alternative pathways. Scenario 3: If Guayule or dandelion processing uses synthetic additives or novel processing chemicals, import regulations in destination markets may restrict use.

Likelihood: Low

Severity: Medium

Action: Clarify the programme's technology stance by Month 6 (2027-04-12): the Pragmatic Foundation scenario uses conventional polygenic breeding (no gene-editing), which avoids regulatory complexity but commits to slower timelines. If faster molecular routes are considered in future, initiate early regulatory dialogue with EU, Japanese and Chinese authorities (Months 12–24 = 2027-10-12 to 2028-10-12) to understand approval pathways and timelines. For alternative crops, conduct early regulatory engagement with importing countries on processing additives and novel-rubber properties, securing pre-approval or regulatory pathways by Month 48 (2030-10-12). Do not pursue gene-edited cultivars without securing a regulatory approval pathway for at least two major importing markets (EU + 1 other) first; if approval timelines exceed 36 months, defer gene-editing in favour of conventional or crown-budding approaches. Allocate $20–30 million (estimate) for regulatory consulting and engagement.

# Risk 12 - Political & Geopolitical

The programme operates across five continents (Brazil, USA/Mexico, Europe, Southeast Asia, West Africa) and depends on multi-year political commitments from sovereign nations and private-sector sponsors. Trade tensions, sanctions, geopolitical conflicts or shifts in government priorities can disrupt funding, interrupt supply chains, delay technology transfer or block cross-border movement of breeding material and processed rubber.

Impact: Scenario 1: Political instability in Brazil (Months 18–36 = 2028-04-12 to 2029-10-12) delays access to Amazon germplasm or slows breeding-programme coordination. Breeding timeline slips by 6–12 months, and Year 7 gate readiness is jeopardised. Scenario 2: Escalating trade tensions between USA and China reduce tire-maker participation in the OEM offtake programme. Offtake is signed only by non-Chinese manufacturers (incomplete market coverage). Scenario 3: A major sovereign funder faces budget constraints and reduces development-bank contributions by 20–30%, creating a $400–600 million capital shortfall in Years 8–12 (estimate).

Likelihood: Medium

Severity: Medium

Action: Build political resilience into the programme structure by Month 6 (2027-04-12): (1) Diversify sovereign and institutional funding across at least 5 major sources (e.g., Brazil, USA, EU, World Bank, Asian Development Bank) so that no single funder's withdrawal triggers a shortfall >20%. (2) Secure multi-year or 10-year funding commitments (not annual budget-dependent appropriations) where possible. (3) Establish independent governance bodies (Containment Protocol Authority, Gate Verification panel) that operate above short-term political changes; embed these in international organisations (IPPC/FAO, CGIAR, international agricultural research networks) for institutional durability. (4) Design the smallholder and extension system to work with decentralised, locally-owned delivery mechanisms (cooperatives, farmer organisations) rather than centralised government agencies. (5) Maintain strategic redundancy in breeding locations: if Brazil becomes disrupted, alternative breeding capacity in Southeast Asia or West Africa can continue. Allocate $10–20 million (estimate) for governance and risk-management institutional design.

# Risk 13 - Smallholder Adoption & Social

Smallholder adoption of resistant clones and alternative crops depends on economic incentives, access to clean-plant nurseries, extension services and income-bridging finance during the immature period (6–10 years before first tapping). Smallholders are risk-averse and often prefer proven cultivars over new ones. If replanting finance is delayed, conditional on compliance, or if clean-plant nurseries are distant or expensive, adoption is low (20–30% instead of target 60%+). Alternative crops are unfamiliar to smallholders in traditional rubber zones; uptake requires 3–5 years of on-farm trials.

Impact: Scenario 1: Smallholder replanting uptake is 30–40% of eligible farmers by Year 12, instead of 60%+. Resistant-cultivar acreage covers only 10–12 million hectares (estimate) of the 20 million potential hectares. Risk remains geographically fragmented, and regional SALB containment cannot be demonstrated at Year 12 gate. Scenario 2: Alternative-crop (dandelion, Guayule) adoption by smallholders is <5,000 hectares in traditional rubber zones by Year 12. Processing plants designed to source from smallholders are under-capacity. Scenario 3: Smallholders adopt resistant cultivars but abandon price-floor contracts when spot prices for rubber rise, breaking offtake agreements.

Likelihood: High

Severity: Medium

Action: Design the Smallholder Transition Finance and Extension Corps to maximize uptake and reduce farmer risk: (1) Offer income-bridging payments during the immature period (Months 0–72 = 2026-10-12 to 2032-10-12 post-replanting), funded by the programme or a levy, not conditional on price-floor compliance in early years. (2) Establish locally-owned nurseries and extension corps (cooperatives, farmer groups) rather than centralised state agencies. (3) Use mobile-phone-based extension and farmer-to-farmer peer learning. (4) Guarantee minimum prices for resistant cultivar and alternative-crop output at 90–95% of historical Hevea benchmarks. (5) Front-load adoption support in Years 1–6: establish nurseries, train extension agents and launch finance disbursement by Month 24 (2028-10-12), so farmers see tangible availability and income support before they decide to replant. Plan for 30–40% uptake by Year 8, not 60%+.

# Risk 14 - Data & Knowledge Management

The Research Knowledge Commons and IP Posture decision requires managing proprietary data, open-access data and benefit-sharing obligations across multiple partner institutions. If data governance is unclear or disputed, partners may withhold breeding data, genomic sequences or cost/quality trial results, fragmenting the evidence base needed for gate verification. Long-term data stewardship is challenging: trial databases, laboratory records and genomic datasets need to be maintained, curated and accessible for 25+ years across institutional and technological transitions.

Impact: Scenario 1: A partner breeding programme withholds trial data on yield penalties due to IP disputes, so independent auditors cannot verify Year 7 gate KPI claims. Gate verification is delayed or rejected, withholding funding tranches. Estimated impact: $2–3 billion in Year 7 gate capital is delayed 6–12 months. Scenario 2: Benefit-sharing data is inadequately tracked or disclosed, triggering disputes and reputational damage. Legal challenges could result in fines ($50–200 million, estimate). Scenario 3: Trial databases are lost due to computer failure, and critical yield/resistance data cannot be reconstructed.

Likelihood: Medium

Severity: Low

Action: Establish a Programme Data Governance Framework by Month 3 (2027-01-12), clarifying ownership, access, publication timing and IP rules for all data types (genomic sequences, trial records, cost/quality results, benefit-sharing payments). Use a tiered model: (1) Pre-competitive data released openly to the global research community within 12 months of generation; (2) Commercial data shared among programme partners under confidentiality agreements, with publication allowed 12 months post-gate; (3) Benefit-sharing and impact data published annually. Assign a dedicated Data Steward role by Month 1 (2026-11-12). Implement a secure, redundant digital data repository by Month 6 (2027-04-12) with version control, backup and 50-year preservation capability. Publish the data-governance framework and all benefit-sharing payment records publicly by Month 12 (2027-10-12). Allocate $20–30 million (estimate) for data infrastructure and stewardship over 25 years.

# Risk 15 - Technical & Processing

Colocated rubber processing plants for Guayule and Russian dandelion must extract and process rubber to OEM quality specifications at competitive cost. Guayule and dandelion rubber extraction processes are less developed than Hevea latex processing; extraction yield (rubber recovery from plant material) varies and contaminants require sophisticated separation. Processing plants at scale (3,000–10,000 tonnes/year, estimate) require significant capital, skilled technicians, and supply-chain integration. If processing yield is <85% (vs. ~90% for Hevea), or if product quality variance exceeds OEM tolerance, plants become uneconomical.

Impact: Scenario 1: A pilot Guayule processing plant (1,000–2,000 tonnes/year, estimate) commissioned by Month 60 (2031-10-12) achieves only 75–80% rubber recovery and product quality variance of ±15% vs. OEM spec. Scaling is deferred, and OEMs decline offtake commitments. Plant capital ($50–100 million, estimate) is underutilised. Scenario 2: Dandelion processing plant incurs higher energy and water costs than projected due to carbon pricing and local water restrictions. Operating costs rise by 20–30%, pushing delivered cost above Hevea benchmarks. Offtake contracts are not signed due to uncompetitive price. Estimated impact: $1.5–2.5 billion in plant capital is stranded.

Likelihood: Medium

Severity: Medium

Action: Launch dedicated processing R&D and pilot-scale demonstration by Month 6 (2027-04-12), parallel to crop agronomic trials. Fund small-scale pilot extraction facilities (500–1,000 tonnes/year capacity, estimate) in both Guayule (Arizona/Mexico) and dandelion (Germany/Benelux) regions, run by dedicated teams focused on optimising extraction yield, quality consistency and cost. Set clear process KPI targets for Month 36 (2029-10-12) and Month 60 (2031-10-12): extraction yield ≥85% (Guayule), ≥80% (dandelion, estimate), product quality variance ≤±10%, operating cost ≤$2.50/kg crude rubber (Guayule), ≤$2.20/kg (dandelion). If targets are not met by Month 60 (2031-10-12), commission an external technology-development programme or bring in private-sector processing expertise. For siting, conduct detailed water and energy-cost analysis (Months 3–12 = 2027-01-12 to 2027-10-12); if regional costs are high, identify alternative sites or develop water-recycling/renewable-energy strategies. Allocate $150–250 million (estimate) over Months 0–120 (2026-10-12 to 2036-10-12) for processing R&D, pilot plants and technology development.

# Risk 16 - Containment Protocol Enforcement

The SALB Containment Protocol requires harmonized movement controls, quarantine protocols and penalties for non-compliance across multiple countries with varying governance capacity and corruption risk. If nurseries or estates can violate the protocol without significant penalty, contaminated material enters supply chains and the protocol becomes unenforceable. Enforcement depends on inspection capacity, detection capability and willingness of governments and private operators to impose quarantine or destruction orders even at economic cost.

Impact: Scenario 1: A nursery in Indonesia violates clean-plant protocols by selling inadequately tested stock in Month 18 (2028-04-12). Within 6 months, SALB is detected in smallholder plantings across three provinces. Instead of a contained quarantine zone affecting <1,000 hectares, SALB affects 10,000–20,000 hectares. Economic losses: $50–100 million in destroyed plantings; reputation damage to the protocol; Year 3 gate verification is undermined. Scenario 2: Penalties for protocol violation are weak or unevenly enforced, creating a perception that non-compliance is low-risk. Protocol compliance erodes from 95% (Year 1) to 60–70% (Year 5).

Likelihood: Medium

Severity: High

Action: Build enforcement capacity into the Containment Protocol Authority by Month 6 (2027-04-12): (1) Establish clear, binding penalty schedules for protocol violation, published in advance and enforced uniformly across countries. Penalties should include economic cost (fines equal to 5–10x the value of infected stock destroyed, estimate) and reputational consequences. (2) Fund dedicated protocol-compliance inspectors in all major producing countries (at least 100 inspectors across top 5 countries, estimate) by Month 12 (2027-10-12), with training on inspection protocols and conflict-of-interest management. (3) Use mobile-phone-based reporting systems to enable smallholders to report suspected violations or infections anonymously, with rewards ($10–50, estimate) for confirmed reports. (4) Conduct red-team drills (Months 18–36 = 2028-04-12 to 2029-10-12) in which external teams attempt to move potentially contaminated material through the supply chain, testing enforcement effectiveness; publicise drill results. (5) Establish an independent ombudsman or dispute-resolution mechanism by Month 6 (2027-04-12) for appeals against compliance decisions. Allocate $100–150 million (estimate) over Months 0–120 (2026-10-12 to 2036-10-12) for inspector salaries, training, equipment and smallholder incentive programs.

# Risk 17 - Long-Term Sustainability & Fatigue

A 25-year programme with complex multi-workstream coordination is vulnerable to institutional fatigue, staff turnover and loss of sustained attention. Key project leadership, programme coordinators and breeding-team researchers may transition after 5–10 years. Funding may be secure, but programme stakeholders may lose engagement if milestones are not clearly communicated or if perceived progress is slow. Without deliberate knowledge-management and stakeholder-engagement systems, the programme can drift from its gate discipline.

Impact: Scenario 1: By Year 10–12, original programme leadership has transitioned and new management reduces monitoring of gate KPIs or de-prioritises breeding trials. Breeding timelines slip, and Year 12 gate readiness is ambiguous. Stakeholder confidence erodes. Scenario 2: Smallholder extension corps and nursery networks are scaled rapidly (Months 24–60 = 2028-10-12 to 2031-10-12) but without systems for retaining trained staff or ensuring quality standards beyond Year 10. Staff turnover reaches 30–50% annually, extension quality degrades and smallholder adoption stalls.

Likelihood: Medium

Severity: Medium

Action: Establish governance and institutional continuity mechanisms by Month 3 (2027-01-12): (1) Create a Programme Steering Council by Month 1 (2026-11-12) with rotating representation from sovereigns, OEMs, research institutions and farmer organisations, meeting quarterly to oversee strategy and monitor gate discipline. (2) Develop a living Strategic Plan document by Month 6 (2027-04-12), with annual updates for the first 5 years and reviews every 5 years thereafter. (3) Establish a knowledge-management protocol by Month 6 (2027-04-12): all key decision records, trial data and breeding-programme results are documented and archived in a shared repository; knowledge-transfer is built into staff handover processes. (4) Design the extension and nursery workforce to have local, decentralised ownership and management (cooperatives, farmer associations, research institutes) rather than centralised programme employment. (5) Plan for leadership transitions: recruit deputy programme leaders by Month 24 (2028-10-12) with explicit succession plans. Allocate $15–25 million (estimate) for governance, knowledge management and institutional-continuity systems over 25 years.

# Risk 18 - Resistance Durability

Even if SALB-resistant Hevea cultivars are successfully bred and deployed at scale, the durability of resistance over decades is uncertain. SALB is a fungal pathogen with historical precedent for overcoming single-source resistance. Polygenic resistance (multiple stacked sources) is intended to be more durable, but durability can only be proven in long-term field trials lasting 10–20 years. If resistance begins to break down during Years 12–20, the cultivars may no longer meet Year 18 gate KPIs and may not deliver the supply stability promised.

Impact: Scenario 1: By Year 12–15, field trials of deployed resistant cultivars show early signs of resistance breakdown in high-inoculum sites or under specific climate/season conditions. Cultivar yield or disease control falls to 85–90% of Year 7 gate standards. The Year 18 gate is questioned. Gate funding is withheld, and breeding investment is redirected to developing next-generation cultivars, further delaying supply stability. Estimated impact: $1–2 billion in cultivar-deployment capital is partially stranded; smallholder confidence erodes. Scenario 2: Resistance breakdown occurs only in specific regions or under specific management practices, creating a patchwork and triggering disputes over which regions are still 'protected'.

Likelihood: Low

Severity: High

Action: Design the breeding and deployment strategy with resistance durability as an explicit long-term objective: (1) Conduct durability trials at multiple sites with high SALB-inoculum pressure (Months 24–120 = 2028-10-12 to 2036-10-12+), using sentinel plantings where resistant clones are grown at high density, and aggressive SALB populations are introduced annually to test resistance stability. (2) Implement the Clonal Mosaic Deployment Rules from the start: require planting of at least 2–3 genetically distinct resistant cultivars in commercial blocks, so if one source breaks down, others provide continued protection. (3) Maintain a resistance-pipeline strategy in parallel to deployed cultivars: as each cultivar is released, begin breeding next-generation cultivars with different resistance sources, so if durability issues arise, replacements are ready within 5–7 years. (4) Build in long-term monitoring beyond the Year 18 gate: set up a sustained SALB-virulence monitoring network (Months 120+) to detect early signs of resistance erosion and trigger breeding responses years in advance. Allocate $100–150 million (estimate) for durability trials, monitoring and next-generation breeding beyond the Year 18 gate.

# Risk summary

This program faces a complex, multi-decade risk landscape shaped by its unprecedented scale, global coordination requirements, and dependence on biological outcomes that remain uncertain despite phase-gated funding controls.

The three most critical risks are: (1) Institutional fragmentation and sovereign objections to the SALB Containment Protocol Authority model—if the IPPC-embedded protocol fails to gain binding adoption across major producing nations, the non-negotiable Phase 1 deliverable cannot be completed, invalidating the entire gating logic; (2) Yield-parity failure in SALB-resistant Hevea breeding—polygenic selection across diverse Amazonian germplasm is durability-optimized but slow in a perennial crop, and if field trials show <90% yield of current elite clones by Month 84 (2033-10-12), the Year 7 gate will be missed and smallholder adoption will stall; (3) Cost competitiveness collapse in alternative crops—Guayule and Russian dandelion face sustained yield and processing-cost gaps against Hevea, and if delivered costs remain 30–50% above Hevea benchmarks beyond the Year 12 gate, OEM offtake contracts will be unsigned and processing-plant capital will be stranded.

Secondary risks cluster around access-and-benefit-sharing disputes, funding horizon brittleness, smallholder adoption friction, and climate and political shocks that outpace biological timelines. Mitigation depends on early clarity of breeding and cost KPIs, rapid protocol adoption in top five producing nations, and contingent reserve funding to cushion missed gates.

# Make Assumptions
# Financial Feasibility

## Assumption
Funding follows the Pragmatic Foundation path: a ring-fenced industry levy plus sovereign and development-bank commitments. Tranches are gate-conditional, with a 15-20% contingency reserve (estimate), consistent with large multilateral programme practice.

## Assessment
Durability and gate-conditionality of the capital stack. Missing the Year 7 gate could withhold roughly $5-8 billion (estimate). Mitigate with binding 25-year framework agreements by Month 12 (2027-10-12), minimum-funding floors (e.g., 80% of a tranche on partial gate success, proposed), and 5+ funding sources. A levy of 25% shortfall equals about $150-250 million per year (estimate). Ring-fencing shields the programme from budget cycles.

# Schedule Feasibility

## Assumption
Protocol drafting starts at Month 0 (2026-10-12), producer-nation MoUs are signed by Month 6 (2027-04-12), and IPPC adoption is complete by Months 36-48 (2029-10-12 to 2030-10-12). Standard-setting at IPPC typically takes 2-4 years.

## Assessment
Phase 1 and four gates. Gates fall at Months 36, 84, 144, and 216 (2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12). Protocol adoption delays of 6-18 months (estimate) would hit the Month 36 (2029-10-12) gate. Perennial breeding cycles of 6-10 years cannot be compressed, so the Month 84 (2033-10-12) cultivar KPI is the tightest. Mitigate with early MoUs, Month 12-18 (2027-10-12 to 2028-04-12) drills, and parallel trial launches by Month 12 (2027-10-12).

# Resource Capacity

## Assumption
Delivery is decentralised, using national rubber research institutes, cooperatives, and certified micro-nurseries. Initial hires include about 100 compliance inspectors and 500 lead extension agents across the top five producers (proposed figures), as scarce skills are met by existing institutions.

## Assessment
Availability and retention of skilled personnel. Scarce skills include molecular diagnostics, perennial-crop breeders, and extraction engineers. Turnover of 30-50% a year in extension (estimate risk) would erode quality. Mitigate with local ownership, succession plans by Month 24 (2028-10-12), and a protected extension funding stream. Building regional lab capacity of about 10 hubs by Month 24 (2028-10-12) (proposed) is an opportunity.

# Governance and Compliance

## Assumption
The protocol is embedded in the IPPC framework and adopted through national plant protection organisations. Brazil's CGen-led ABS agreements, with community consent, are completed by about Month 6-18 (2027-04-12 to 2028-04-12). Producer countries retain sovereignty over enforcement.

## Assessment
Legitimacy, adoption and ABS compliance. Consensus standard-setting gives legitimacy but weak enforcement; producers hold effective vetoes. ABS agreements can take 12-36 months (not verified), threatening breeding starts. Mitigate with a FAO adoption secretariat by Month 3, early ABS counsel, published agreements, and a binding penalty schedule. Legal exposure from consent failures: $100-500 million (estimate).

# Risk Management

## Assumption
Tiered surveillance targets detection within 3 months in primary producers (proposed threshold), an eradication-first response with prefunded compensation, and quarterly risk reviews. Triggers include yield penalty over 15% by Month 48 (2030-10-12) and cost targets missed by Month 60 (2031-10-12) (proposed).

## Assessment
Containment, breeding, and cost-failure risks. Detection beyond 6 months could expand eradication from under 5 ha to 500+ ha (estimate). Nursery contamination is the key pathway, so inspection capacity must scale with nursery count. Mitigate with red-team drills, concealment-reducing rewards, and decision triggers. Early failure signals redirect capital before gate losses.

# Environmental Impact

## Assumption
Guayule and dandelion are sited on degraded or marginal land after suitability screening, with water-stress modelling at 1.5, 2, and 3 degrees C scenarios (proposed). Footprint is geographically diversified to avoid single climate shocks.

## Assessment
Water, land, and climate exposure. Arid-zone aquifer depletion could cut Guayule yields 20-30% (estimate risk). Marginal siting avoids food competition but raises cost per tonne. Mitigate with climate-informed siting by Month 6 (2027-04-12), alternative sites, and SALB habitat monitoring from Month 12 (2027-10-12). Reduced deforestation pressure and diversified, climate-resilient supply are benefits.

# Stakeholder Alignment

## Assumption
A Steering Council with sovereign, OEM, research, and farmer seats meets quarterly from Month 1 (2026-11-12). The top 10 tire makers are engaged by Month 3 (2027-01-12) with letters of intent by Month 12 (2027-10-12) (proposed). Community-governed data trust seats are offered to indigenous groups.

## Assessment
Commitment and trust across diverse parties. OEMs resist paying premiums for unproven supply; purchase-option contracts with small reservation fees (estimate 1-2%) lower this barrier. Smallholder uptake historically 20-40% (estimate), so plan for 40-50%. Mitigate with income-bridging finance, mobile extension, and transparent benefit-sharing disclosure. Farmer co-ownership in processing is an opportunity.

# Operational Systems

## Assumption
A digital lot-tracking and data repository with 50-year preservation, independent audit access, and pilot processing plants (500-5,000 t/year, estimate) precede commercial plants. Mobile attestation serves remote farmers.

## Assessment
Tracking, data, and processing infrastructure. Lot inspections may need 100,000+ per year versus under 30,000 if under-resourced (estimate). Data loss or withheld trial data could delay gates 6-12 months. Mitigate with a data steward by Month 1 (2026-11-12), tiered data rules, and KPI waypoints at Months 36 and 60 (2029-10-12, 2031-10-12). Plants cost $100-300 million each (estimate), so stage capital after pilots.

# Distill Assumptions
# Project Overview

- 25-year program with $30 billion (user constraint) public-private funding
- Funding gates at Months 36, 84, 144, and 216 (2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12)
- Capital stack combines ring-fenced industry levy with sovereign and development-bank commitments
- Contingency reserve of 15-20% (estimate)
- Binding framework agreements targeted by Month 12 (2027-10-12)

# Phase 1: SALB Containment Protocol

- Protocol drafting starts Month 0 (2026-10-12)
- Producer-nation MoUs signed by Month 6 (2027-04-12)
- Protocol embedded in IPPC framework; producer countries retain enforcement sovereignty
- Non-negotiable precursor to any scale-up

# IPPC Adoption and Gate

- IPPC adoption completes Months 36-48 (2029-10-12 to 2030-10-12)
- Scale-up held until Month 36 (2029-10-12) gate
- Independent international auditor verifies gate evidence with scope fixed in advance

# Germplasm and Breeding

- Brazil-led, ABS-compliant breeding uses genomic selection of Amazonian germplasm without gene-editing
- ABS agreements complete by Months 6-18 (2027-04-12 to 2028-04-12), though may take 12-36 months (not verified)
- Perennial breeding cycles of 6-10 years cannot be compressed
- Month 84 (2033-10-12) cultivar KPI is tightest

# Crop Investment and Processing

- Investment concentrates on Guayule (arid) and Russian dandelion (temperate)
- Pilot plants of 500-5,000 t/year (estimate) precede commercial plants costing $100-300 million each (estimate)
- Alternative crops sited on degraded or marginal land after suitability screening
- Colocated processing plants required

# OEM Engagement

- Top 10 tire makers engaged by Month 3 (2027-01-12)
- Offtake uses purchase-option contracts with 1-2% reservation fees (estimate)

# Governance

- Steering Council with sovereign, OEM, research, and farmer seats meets quarterly from Month 1 (2026-11-12)

# Delivery

- Decentralised via research institutes, cooperatives, and certified micro-nurseries
- Initial hires: about 100 inspectors and 500 extension agents in top five producers (proposed)
- Smallholder adoption planned at 40-50% versus historical 20-40% (estimate), enabled by replant finance

# Outbreak Response

- Eradication-first response with prefunded compensation
- Detection within 3 months (proposed threshold)
- Response triggers: yield penalty over 15% by Month 48 (2030-10-12), cost targets missed by Month 60 (2031-10-12) (proposed)

# Digital Infrastructure and Verification

- Digital lot-tracking and data repository with 50-year preservation
- Independent audit access
- Success means verified containment, diversified supply chains, and resilient procurement against pathogen and climate shocks


# Review Assumptions
# Critical Missing Assumptions: Global Natural-Rubber Security Programme

## Issue 1 - Smallholder Adoption Success Rate and Income-Bridging Durability

The plan targets 60%+ smallholder adoption of resistant cultivars and alternative crops, but historical uptake in developing-country programmes averages 20-40%. The plan does not specify:

- What proportion of smallholders receive income-bridging finance
- Whether bridging payments continue through full immature periods (6-10 years) or taper
- Who bears cost if repayment defaults exceed 10-15%
- How adoption is sustained after Year 15 if extension staff turnover reaches 30-50% annually

Without clarity, the smallholder pillar becomes a fiscal liability.

## Recommendation

By Month 6 (2027-04-12), define smallholder adoption targets with three scenarios: conservative (30-40% uptake), moderate (40-50%), and optimistic (60%+). Tie each scenario to explicit finance and extension commitments. Set adoption KPI waypoints at Months 36, 84, 144 (2029-10-12, 2033-10-12, 2038-10-12) with decision triggers: if uptake falls below 30% by Month 84 (2033-10-12), reduce Year 7-12 smallholder acreage targets by 30-40% and reallocate funds to estate-scale Hevea trials and alternative-crop processing plants. Establish income-bridging as a separate, protected 25-year funding stream ($300-500 million, estimate) managed locally through cooperatives. Require quarterly smallholder satisfaction surveys and annual extension-staff retention audits; if turnover exceeds 40% in any year, trigger retraining and peer-mentoring investment.

## Sensitivity

Baseline assumption: 60% adoption across 5 million smallholder hectares by Year 12. Conservative scenario (30% uptake): reduces adopted hectares to 2.5 million, cutting resistant-cultivar-driven containment verification and stranding $500-800 million in replant-finance commitments. Each 10% shortfall below 60% reduces projected supply diversity by 5-7% and delays regional risk reduction by 2-3 years. If income-bridging is cut after Year 10, uptake reversal is plausible (20-30% of farmers abandoning replanted clones), estimated cost: $200-400 million in stranded extension and nursery infrastructure.

## Issue 2 - SALB Pathogen Resistance Durability Testing Timeline and Threshold Definition

The plan assumes polygenic resistance will be durable, yet durability can only be proven through 10-20 year field trials under high pathogen pressure. The plan does not specify:

- Which resistance sources are independent and durable
- At what inoculum pressure and number of pathogen encounters cultivars are declared 'durable'
- What yield or disease-control decline triggers cultivar retirement
- How durability is verified by independent auditors across different sites, seasons and SALB variants

Without these definitions, Year 7 'cultivar readiness' and Year 18 'resistance durability' gates become ambiguous.

## Recommendation

By Month 6 (2027-04-12), publish a detailed breeding-durability protocol specifying:

- Minimum number of independent resistance sources in released cultivars (proposed: ≥3 stacked, confirmed in ≥5 independent field trials)
- Minimum inoculum-pressure testing (proposed: exposure to natural high-inoculum zones and artificial inoculation at 10x field-typical levels)
- Clear failure thresholds for yield (proposed: <90% of elite clone = failure; 90-95% = conditional; >95% = pass) and disease control (proposed: lesion size >5mm or defoliation >20% = failure)
- Post-release monitoring over Months 84-216 (2033-10-12 to 2044-10-12)+ with sentinel plantings and quarterly pathogen-variant surveillance

Establish an independent Resistance Durability Oversight Panel by Month 3 (2027-01-12) with breeding, pathology, and auditor members; panel pre-approves trial protocols and interprets results. Include a 'resistance pipeline' commitment: begin breeding next-generation cultivars by Month 60 (2031-10-12) using different resistance sources, so replacements are available within 7 years if early breakdown occurs.

## Sensitivity

Baseline assumption: Year 7 gate releases cultivar with ≥3 stacked resistance sources and ≥90% yield. If durability testing reveals one source breaks down by Year 12 (estimated risk 10-20% based on SALB history), Year 18 gate KPI becomes uncertain. Scenario 1: Breakdown occurs at Year 14 in high-inoculum zones (5-10% of planting area, estimate), requiring partial quarantine and cultivar substitution; estimated cost: $500-1,000 million. Scenario 2: Breakdown is mild (yield drops to 85-88%) but triggers gate auditor disputes, withholding Year 18 capital ($4-6 billion, estimate) for 6-12 months. Scenario 3: No breakdown by Year 18, but next-generation breeding is delayed; by Year 25, deployed cultivars show progressive durability loss, eroding smallholder confidence.

## Issue 3 - OEM Offtake Commitment Bankability and Price-Risk Allocation

The plan's viability depends on OEM tire makers signing long-term offtake agreements for alternative rubber, yet the plan does not specify:

- Whether OEM commitments are legally binding take-or-pay contracts or optional purchase agreements
- At what price premium OEMs will agree (cost gap of 15-50% above Hevea is plausible, estimate)
- Who bears cost if rubber quality fails tire tests
- How contracts adapt if feedstock becomes cheaper
- Whether processing plants can be financed without firm offtake

Without binding, bankable offtake, processing plants cannot be capitalized.

## Recommendation

By Month 12 (2027-10-12), initiate direct negotiations with the top 10 tire makers to secure non-binding letters of intent for offtake trials. By Month 24 (2028-10-12), launch parallel tire-performance qualification trials (18-24 months, estimate) at independent test facilities. By Month 60 (2031-10-12), structure offtake agreements using tiered purchase-option contracts:

- Tier 1: OEMs pay a 1-2% (estimate) annual reservation fee on planned volumes for priority access
- Tier 2: Optional purchase at a quality-indexed price formula with a price floor 10-15% above Hevea benchmark (estimate) and ceiling at producer cost plus 20% margin (estimate)
- Tier 3: Shared quality-failure risk, with producer and processor absorbing 50% of loss if rubber fails OEM specs, OEM covering 50%

Link plant financing to proof of offtake: pilot plants (500-5,000 t/year, estimate) by Month 60 (2031-10-12) with offtake pilots, full commercial plants ($100-300 million capital, estimate) only after Tier 1 offtake represents ≥70% of planned capacity and tire qualifications are complete. Reserve $100-150 million (estimate) for offtake negotiation, tire testing, and contract support.

## Sensitivity

Baseline assumption: OEMs sign take-or-pay offtake at 5-15% price premium over Hevea by Month 60 (2031-10-12), enabling $1.5-2.5 billion in processing-plant capital. Scenario 1 (offtake delayed to Month 72-84 = 2032-10-12 to 2033-10-12, estimated risk 30-40%): plant capital commitment is deferred, construction is compressed, and plant cost inflates by 10-15%; estimated impact: $150-375 million additional capital and 12-24 month delay. Scenario 2 (offtake signed but tire tests fail, estimated risk 15-25%): OEMs trigger force-majeure or renegotiate prices downward by 20-30%; alternative-rubber delivered cost remains 30-40% above Hevea, plant ROI is negative, and $1-2 billion in plant capital is stranded. Scenario 3 (price premium declines faster than expected, e.g., Guayule cost drops 15% by Year 12, estimate optimistic): OEMs renegotiate prices lower under market competition; producer margin is squeezed and processing-plant operators cannot service debt, risking plant closures by Year 15-18.

## Review Conclusion

The programme faces three critical missing assumptions that, if not addressed by Months 6-12 (2027-04-12 to 2027-10-12), will cascade failure across the gate logic and capital structure. First, smallholder adoption rates are assumed at 60%+ but lack explicit targets, finance-durability commitments, and contingency scenarios; conservative 30-40% uptake would reduce resistant-cultivar acreage by 50-70% and orphan $500-800 million in replant investment. Second, SALB resistance durability is untested at scale and timescale, yet the plan lacks a published durability-testing protocol, failure thresholds, or independent Oversight Panel; ambiguous durability gates risk capital withholding and smallholder confidence collapse. Third, OEM offtake is critical to processing-plant bankability, yet the plan does not specify binding contract terms, price-risk allocation, or tire-performance qualification timelines; without firm offtake by Month 60 (2031-10-12), plants cannot be financed and alternative supply diversification fails. The programme's strength lies in stage-gated, evidence-based capital release and decentralised smallholder-led delivery, but success depends on locking down these three assumptions in the next 6-12 months via bilateral commitments, published durability protocols, and OEM offtake frameworks. Climate uncertainty, SALB pathogen evolution, and political volatility over 25 years remain embedded risks, but mitigation is feasible through contingency reserves (15-20%), climate-informed siting, and diversified funding sources.