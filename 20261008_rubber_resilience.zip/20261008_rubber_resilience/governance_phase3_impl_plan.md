### 1. Identify and confirm project sponsor, senior champion, and key decision-maker(s) who will authorize the establishment of governance bodies and commit binding multi-year funding. Secure written commitment that sponsor will lead initial formation activities (Months 0–1 = 2026-10-08 to 2026-11-08).

**Responsible Body/Role:** Project Sponsor / Senior Government Leadership

**Suggested Timeframe:** Month 0 (2026-10-08), within 1 week of project kickoff

**Key Outputs/Deliverables:**

- Sponsor commitment letter
- Designation of project champion and interim lead authority
- Authority to proceed with governance establishment signed

**Dependencies:**

- Project approval and go-ahead decision

### 2. Establish a Formation Steering Group (FSG), comprising the project sponsor, senior representatives from 3–5 major producer governments (Brazil, Indonesia, major development banks), and international governance advisors. FSG will oversee the design and formal establishment of the Program Steering Committee, Technical Panel, and secretariat.

**Responsible Body/Role:** Project Sponsor / Senior Government Leadership (convening authority)

**Suggested Timeframe:** Month 0 (2026-10-08), within 1 week

**Key Outputs/Deliverables:**

- Formation Steering Group roster and conflict-of-interest declarations
- FSG Charter and decision procedures
- Meeting schedule (weekly during Months 0–1 = 2026-10-08 to 2026-11-08)

**Dependencies:**

- Project Sponsor Identified

### 3. Draft and circulate governance architecture document for review by FSG and major stakeholders (producer governments, OEMs, development banks). Document specifies PSC structure, Technical Panel independence, secretariat autonomy, decision rights, and financial controls.

**Responsible Body/Role:** Formation Steering Group (lead: Project Sponsor or designated formation lead)

**Suggested Timeframe:** Month 0–1 (2026-10-08 to 2026-11-08), within 2–3 weeks

**Key Outputs/Deliverables:**

- Governance Architecture Document v0.1 (draft)
- Stakeholder feedback summary
- Revised document incorporating critical feedback

**Dependencies:**

- Formation Steering Group Established

### 4. Conduct preliminary multi-stakeholder consultation (virtual or in-person) with representatives from 5–8 sovereign governments, 3–4 major OEMs, 3–4 development banks, and key producer-country institutions (Brazil Embrapa, IRRDB, etc.) to validate governance structure and build consensus on board composition principles, decision rules, and independence safeguards.

**Responsible Body/Role:** Formation Steering Group (Project Sponsor / senior adviser)

**Suggested Timeframe:** Month 1 (2026-11-08), during weeks 2–4

**Key Outputs/Deliverables:**

- Stakeholder Consultation Report (30 participants, summary of concerns and endorsements)
- Revised governance architecture reflecting stakeholder input
- List of potential PSC and Technical Panel candidates identified by stakeholders

**Dependencies:**

- Governance Architecture Document circulated

### 5. Draft and finalize the Technical Gate Charter: binding agreement specifying KPI thresholds for Years 3/7/12/18, evidence standards, gate-decision rules, partial-achievement tranching, dispute-resolution procedures, and appeal timelines. Charter must be negotiated and agreed by major funders (sovereigns, development banks) before signature.

**Responsible Body/Role:** Formation Steering Group (lead: Project Sponsor with legal counsel and technical advisors)

**Suggested Timeframe:** Month 1–2 (2026-11-08 to 2026-12-08), weeks 2–7

**Key Outputs/Deliverables:**

- Technical Gate Charter v0.5 (draft for funder review)
- Funder feedback and redlines
- Technical Gate Charter v1.0 (final, signed by 5–8 sovereigns and 2+ development banks)

**Dependencies:**

- Preliminary multi-stakeholder consultation completed
- Binding funding-commitment discussions initiated with major funders

### 6. Recruit Executive Director of the Core Project Team (CPT) and secretariat. External hire, independent of all funders and producers, with 5–10 year contract term and long-tenure protection clauses. Role is to lead day-to-day program execution and serve as principal staff officer to the PSC.

**Responsible Body/Role:** Project Sponsor / Formation Steering Group (with HR/recruitment support)

**Suggested Timeframe:** Month 1 (2026-11-08), initiate search; hire by Month 3 (2027-01-08)

**Key Outputs/Deliverables:**

- Executive Director job description and recruitment brief
- Recruitment committee (3–5 members, FSG representatives + independent adviser)
- Executive Director contract, signed

**Dependencies:**

- Governance Architecture Document finalized
- Secretariat location and operating budget approved

### 7. Establish PSC Standing Rules: formal procedures governing PSC meetings, voting, decision thresholds (supermajority for gates, consensus for strategy pivots >10%), conflict-of-interest disclosure, confidentiality, and escalation paths. Draft by FSG, review by FSG and legal counsel, finalize within Month 2 (2026-12-08).

**Responsible Body/Role:** Formation Steering Group (lead: Project Sponsor with legal counsel)

**Suggested Timeframe:** Month 1–2 (2026-11-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- PSC Standing Rules v1.0 (adopted by FSG, to be approved by PSC upon formation)

**Dependencies:**

- Governance Architecture Document and Technical Gate Charter substantially agreed

### 8. Identify, nominate, and secure commitment from PSC members: 6–8 producer-government representatives (Brazil, Indonesia, Malaysia, Thailand, India, Côte d'Ivoire, Mexico, 1 rotating), 3–4 OEM representatives, 3–4 development-bank representatives, and 3–4 independent expert representatives. Obtain written conflict-of-interest certifications and CVs.

**Responsible Body/Role:** Formation Steering Group (lead: Project Sponsor, in consultation with major funders and producer governments)

**Suggested Timeframe:** Month 1–2 (2026-11-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- PSC Nomination List with CVs and conflict-of-interest declarations
- Written confirmations of willingness to serve (each nominee)
- Diversity and gender-balance assessment

**Dependencies:**

- Stakeholder consultation completed; funder and producer-government agreement on representation

### 9. Nominate and secure commitment from independent Technical Panel members: 7–9 conflict-free scientists and specialists (plant geneticist, plant pathologist, phytosanitary expert, economist, smallholder specialist, supply-chain analyst, and optional climate/emerging-topics expert). Obtain written conflict-of-interest certifications, CVs, and references. Panel must be independent of funders, producers, OEMs, and breeding consortia.

**Responsible Body/Role:** Formation Steering Group (lead: Project Sponsor in consultation with academic/scientific bodies and peer-review networks)

**Suggested Timeframe:** Month 1–3 (2026-11-08 to 2027-01-08)

**Key Outputs/Deliverables:**

- Technical Panel Nomination List with CVs and conflict-of-interest certifications
- Written confirmations from nominees
- Panel Standing Rules draft (to be adopted by Panel upon first meeting)

**Dependencies:**

- Governance Architecture and Technical Gate Charter agreed; need for technical expertise confirmed

### 10. Secure binding, multi-year funding commitments from 5–8 sovereign governments and at least 2 multilateral development banks, with explicit commitment letters and signed agreements (not annual appropriations). Commitments must total at least USD 21 billion (70% of USD 30 billion cap) and no single funder above 25% (USD 7.5B). Target signature by Month 3 (2027-01-08).

**Responsible Body/Role:** Project Sponsor / Formation Steering Group (senior finance/diplomatic representatives)

**Suggested Timeframe:** Month 1–3 (2026-11-08 to 2027-01-08)

**Key Outputs/Deliverables:**

- Funding Commitment Letters (5–8 sovereigns + 2+ MDBs, specifying amounts and tranches)
- Binding Funding Agreements signed by representatives with authority
- Summary of funding stack: 70% committed by Month 3 (2027-01-08), remainder to be secured during Months 3–12 (2027-01-08 to 2027-10-08)

**Dependencies:**

- Technical Gate Charter finalized
- Governance structure agreed with funders
- Executive Director hired (or interim authority designated)

### 11. Formally establish the Program Steering Committee (PSC) by convening the first PSC kick-off meeting. Activities include: PSC members sign commitments and conflict-of-interest declarations; review and adopt PSC Standing Rules; establish PSC chair (rotating annually among producer-government members), vice-chair, and secretary; set quarterly meeting schedule; assign PSC subcommittees (if needed: Finance, Risk, Governance); brief members on Technical Gate Charter and program KPIs.

**Responsible Body/Role:** Project Sponsor / Formation Steering Group (in transition to PSC chair-elect)

**Suggested Timeframe:** Month 2–3 (2026-12-08 to 2027-01-08)

**Key Outputs/Deliverables:**

- PSC Kick-off Meeting Minutes
- PSC Standing Rules adopted and signed
- PSC roster (members, roles, contact details)
- PSC meeting calendar (quarterly, plus gate-decision extraordinary sessions)
- Technical Gate Charter briefing document for PSC

**Dependencies:**

- PSC members nominated and confirmed
- PSC Standing Rules drafted
- Binding funding commitments secured
- Technical Gate Charter finalized

### 12. Formally establish the independent Technical Panel by convening the first Panel meeting. Activities include: Panel members sign conflict-of-interest certifications; review and adopt Panel Standing Rules; elect Panel chair; establish decision procedures (majority vote, dissent protocols); assign Panel working groups (containment, breeding, alternatives, or pillars); schedule monthly standing meetings and intensive gate-assessment windows (6–8 weeks pre-gate); brief Panel on Technical Gate Charter and gate evidence data architecture.

**Responsible Body/Role:** Formation Steering Group (transitioning to Project Sponsor / PSC chair as Panel governance authority)

**Suggested Timeframe:** Month 2–3 (2026-12-08 to 2027-01-08)

**Key Outputs/Deliverables:**

- Technical Panel Kick-off Meeting Minutes
- Panel Standing Rules adopted and signed
- Panel roster (members, roles, affiliations, contact details)
- Panel meeting calendar (monthly standing, intensive gate-windows Months 28–32 = 2029-02-08 to 2029-06-08, 76–80, 136–140, 208–212)
- Panel working group assignments

**Dependencies:**

- Technical Panel members nominated and confirmed
- Panel Standing Rules drafted
- Technical Gate Charter finalized

### 13. Establish the Compliance and Ethics Committee (CEC), comprising a Chair (external hire, 10+ years compliance/anti-corruption), Nagoya Protocol specialist, anti-corruption investigator, data-protection officer, and senior auditor. Contract externally managed whistleblower hotline by Month 1 (2026-11-08). Adopt CEC Charter and Compliance Framework by Month 2 (2026-12-08). First CEC meeting by Month 3 (2027-01-08).

**Responsible Body/Role:** Project Sponsor / Formation Steering Group (in consultation with PSC once established)

**Suggested Timeframe:** Month 1–3 (2026-11-08 to 2027-01-08)

**Key Outputs/Deliverables:**

- CEC Chair recruited (external hire, contract signed)
- CEC roster (members, roles, conflict-of-interest certifications)
- Whistleblower hotline contracted and operational
- CEC Charter and Compliance Framework adopted
- CEC standing meeting calendar (monthly)

**Dependencies:**

- Governance Architecture Document specifying CEC role
- Budget and authority for CEC operations approved

### 14. Establish the Producer-Country Coordination Forum (PCCF) secretariat and membership, comprising ministry-of-agriculture or rubber-research-institute representatives from 15+ producing countries, with rotating annual chair. Secure host location (within major producing-country research institute, e.g., CEPLAC/Brazil or IRRDB/Thailand). Schedule first PCCF meeting for Month 3–6 (2027-01-08 to 2027-04-08). Agree on producer-country coordination priorities and capacity-building roadmap.

**Responsible Body/Role:** Formation Steering Group (with Brazil/Indonesia/Malaysia representatives leading; producer-country institutions providing host)

**Suggested Timeframe:** Month 1–6 (2026-11-08 to 2027-04-08)

**Key Outputs/Deliverables:**

- PCCF Charter and terms of reference
- PCCF membership roster (15+ producing countries, rotating chair agreement)
- PCCF secretariat location and staffing plan
- PCCF first meeting agenda and outcomes
- Capacity-building roadmap (inspector training, nursery standards, lab diagnostics)

**Dependencies:**

- Producer-country consensus on PCCF role and governance
- Host country and institution selected

### 15. Recruit and onboard Core Project Team (CPT) Executive Director and core secretariat staff: Deputy Director for Containment & Capacity Building, Deputy Director for Resistance Breeding & Trials, Deputy Director for Alternative Rubber & Processing, Deputy Director for Smallholder Finance & Surveillance, Chief Financial Officer, Chief Risk & Compliance Officer, Technical Secretariat Manager, and operations support (10–15 FTE total). Complete recruitment by Month 3 (2027-01-08); staff in place and operational by Month 4 (2027-02-08).

**Responsible Body/Role:** Project Sponsor / PSC (via Executive Director-elect and HR adviser)

**Suggested Timeframe:** Month 1–4 (2026-11-08 to 2027-02-08)

**Key Outputs/Deliverables:**

- CPT staffing plan and organizational chart
- Job descriptions for each CPT role
- Recruitment completed; staff contracts signed
- CPT Kick-off Meeting held by Month 4 (2027-02-08)
- CPT meeting cadence established (weekly Deputy Director meetings, monthly all-hands)

**Dependencies:**

- Budget and authority for CPT operations approved
- Secretariat location and facilities arranged
- Executive Director hired (Month 3 = 2027-01-08)

### 16. Establish secretariat financial management systems: separate bank accounts and ledgers for each pillar (containment 25%, breeding 35%, alternatives 25%, smallholder 15%); contingency pool (15%), outbreak response reserve, and political-risk reserve accounting. Set up quarterly financial reporting, external audit protocols, and funder-reporting templates. Target operational by Month 2 (2026-12-08).

**Responsible Body/Role:** Core Project Team (Chief Financial Officer, with finance adviser support)

**Suggested Timeframe:** Month 1–2 (2026-11-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Bank account setup and authorization documentation
- Financial accounting and ledger system (pillar-based and reserve-based accounts)
- Quarterly financial reporting template
- External audit charter and audit schedule
- Funder reporting dashboard (committed, disbursed, burn rate, forecast)

**Dependencies:**

- Binding funding commitments received
- CFO hired or designated
- Secretariat location and financial infrastructure in place

### 17. Publish governance transparency dashboard and annual reporting framework. Dashboard includes: PSC member roster and affiliations, Technical Panel roster and expertise, CEC member roster, funding commitments (sovereign and MDB, non-confidential summary), capital deployment by pillar and month, reserve account balances, and annual compliance and risk summary. Target first publication by Month 6 (2027-04-08); thereafter annual by Month 12 (2027-10-08) of each calendar year.

**Responsible Body/Role:** Core Project Team (Technical Secretariat Manager and Communications Officer)

**Suggested Timeframe:** Month 3–6 (2027-01-08 to 2027-04-08)

**Key Outputs/Deliverables:**

- Governance Transparency Dashboard (web-based or published report)
- Annual Stakeholder Report template
- First Annual Report (Month 12 = 2027-10-08, covering Months 0–12 = 2026-10-08 to 2027-10-08)

**Dependencies:**

- All governance bodies formally established
- Financial systems operational
- Communications and IT infrastructure in place

### 18. Launch IPPC/containment protocol technical working group at Month 0 (2026-10-08), comprising representatives from Brazil, major producing countries, IPPC Secretariat, regional plant protection organizations (ASEAN, ECOWAS, Mercosur), and CPT Containment Deputy Director. Weekly meetings Months 0–6 (2026-10-08 to 2027-04-08); monthly thereafter. Produce formal IPPC proposal by Month 18 (2028-04-08); negotiate binding regional compacts by Month 24 (2028-10-08); target 15-country commitment letters by Month 24 (2028-10-08).

**Responsible Body/Role:** Core Project Team (Deputy Director, Containment & Capacity Building), with IPPC Secretariat and producer-country partners

**Suggested Timeframe:** Month 0 onwards (2026-10-08 onwards); formal IPPC proposal by Month 18 (2028-04-08)

**Key Outputs/Deliverables:**

- Technical working group roster and meeting schedule
- Draft IPPC standard proposal (Month 12 = 2027-10-08)
- Formal IPPC proposal submitted to IPPC Standards Committee (Month 18 = 2028-04-08)
- Regional compact agreements (Asia, Africa, Americas) signed (by Month 24 = 2028-10-08)
- 15 country commitment letters to adopt protocol into national law (by Month 24 = 2028-10-08)

**Dependencies:**

- CPT Containment Deputy Director onboarded
- Brazil and major producer-country buy-in secured (via PCCF and direct diplomacy)

### 19. Establish Brazil-led bio-prospecting and Nagoya Protocol benefit-sharing team by Month 1 (2026-11-08), led by Brazilian environmental/legal experts and indigenous-rights specialists, in partnership with CEPLAC and Embrapa. Complete Nagoya/ABS framework agreements with Brazilian states and indigenous organizations by Month 6 (2027-04-08). Establish pooled benefit-sharing fund by Month 6 (2027-04-08) to pre-clear access without renegotiation per cultivar. Begin wild-Hevea collection campaigns by Month 8 (2027-06-08); deliver 200 characterized accessions by Month 18 (2028-04-08).

**Responsible Body/Role:** Core Project Team (Deputy Director, Resistance Breeding & Trials), in partnership with Brazil government, CEPLAC, Embrapa, and indigenous-community representatives

**Suggested Timeframe:** Month 1–18 (2026-11-08 to 2028-04-08)

**Key Outputs/Deliverables:**

- Nagoya Protocol team assembled and ToR drafted
- Framework access-and-benefit-sharing agreements signed with Brazilian states (by Month 6 = 2027-04-08)
- Community benefit-sharing fund established and governance agreed (by Month 6 = 2027-04-08)
- Wild Hevea collection campaigns commenced (Month 8 = 2027-06-08)
- 200 characterized wild Hevea accessions with SALB-resistance documentation delivered (by Month 18 = 2028-04-08)

**Dependencies:**

- CPT Breeding Deputy Director onboarded
- Brazil and indigenous-community buy-in and support secured
- Benefit-sharing fund capital allocated (from breeding pillar budget)

### 20. Establish pathogen genomics laboratories: primary lab in Brazil (CEPLAC or Embrapa) by Month 2 (2026-12-08); satellite lab in Asia (Rubber Research Institute of Malaysia or equivalent) by Month 9 (2027-07-08). Labs will sequence and characterize SALB virulence from trial sites and endemic regions annually, feeding results into cultivar-release decisions. Establish initial tissue culture and somatic-embryogenesis hubs in Asia by Month 12 (2027-10-08).

**Responsible Body/Role:** Core Project Team (Deputy Director, Resistance Breeding & Trials), in partnership with Brazil and Asian research institutes

**Suggested Timeframe:** Month 2–12 (2026-12-08 to 2027-10-08)

**Key Outputs/Deliverables:**

- Brazil pathogen genomics lab operational (Month 2 = 2026-12-08)
- Asia satellite lab operational (Month 9 = 2027-07-08)
- Lab staffing and sequencing protocols established
- First annual virulence survey commenced (Month 12 = 2027-10-08)
- Tissue-culture propagation hubs established in Asia (Month 12 = 2027-10-08)

**Dependencies:**

- Breeding budget allocated and approved
- Institutional partnerships with Brazil CEPLAC/Embrapa and Asian institutes formalized

### 21. Establish high-containment trial stations for resistance field trials: establish at least 4 stations (2 live-pathogen endemic sites in Latin America—Rondônia, Peru; 2 clean-zone sites in Asia and Africa) by Month 12 (2027-10-08). Commission trial site designs, biosafety protocols, and inoculation procedures. Begin field trials with candidate germplasm by Month 18 (2028-04-08). Implement Virulence Gates (Month 24, 36, 48, 60 = 2028-10-08, 2029-10-08, 2030-10-08, 2031-10-08) to assess candidate cultivars against contemporary SALB isolates.

**Responsible Body/Role:** Core Project Team (Deputy Director, Resistance Breeding & Trials), in partnership with trial-site host institutions

**Suggested Timeframe:** Month 0–12 (2026-10-08 to 2027-10-08); trials operational by Month 18 (2028-04-08)

**Key Outputs/Deliverables:**

- Trial station designs and biosafety protocols finalized
- 4 trial stations commissioned (by Month 12 = 2027-10-08)
- Initial candidate germplasm planted and inoculation protocols tested (by Month 18 = 2028-04-08)
- Virulence Gate assessment framework established
- First Virulence Gate assessment (Month 24 = 2028-10-08)

**Dependencies:**

- Germplasm collection and characterization underway (Brazil)
- Pathogen genomics labs operational
- Trial-site host institution agreements signed
- Biosafety and quarantine regulatory approvals obtained

### 22. Design and pilot smallholder replanting finance and surveillance mechanisms by Month 6 (2027-04-08). Co-design with farmer organizations and rural banks: 7–10 year loan tenor, <5% interest, repayment tied to latex sales prices, conditional on certified clean-plant purchasing. Pilot income-bridge schemes and surveillance premiums (USD 25–50 per verified SALB report) in 3–5 representative zones (Sumatra, Côte d'Ivoire, northeast India, Rondônia, optional fifth) during Months 6–24 (2027-04-08 to 2028-10-08). Target 60%+ participation in pilot zones; scale to 2–3 million farmers if pilot uptake achieved.

**Responsible Body/Role:** Core Project Team (Deputy Director, Smallholder Finance & Surveillance), in partnership with farmer organizations, rural banks, and pilot-zone governments

**Suggested Timeframe:** Month 6–24 (2027-04-08 to 2028-10-08)

**Key Outputs/Deliverables:**

- Replant finance product design (terms, disbursement protocols, repayment)
- Income-bridge mechanism design (years without income covered)
- Surveillance-premium mechanism design (reporting, verification, payment timeline)
- Farmer-organization consultations and buy-in secured
- Pilot zones selected and baseline assessment completed (Month 6 = 2027-04-08)
- Pilot deployment operational in 3–5 zones (by Month 12 = 2027-10-08)
- Pilot uptake and satisfaction monitoring reports (quarterly Months 12–24 = 2027-10-08 to 2028-10-08)

**Dependencies:**

- Smallholder finance budget allocated (USD 4.5B, 15% of cap)
- Clean-plant nursery network established (parallel track)
- CPT Deputy Director for Smallholder Finance onboarded

### 23. Establish capacity-building twinning arrangements between Brazilian phytosanitary institutes (e.g., CEPLAC/INA) and Southeast Asian, South Asian, and West African agriculture ministries/research institutes by Month 1 (2026-11-08). Each twinning pair produces joint workplan: staff exchanges, joint lab setup, co-authored protocols, inspector training rotations. Target 500 inspectors trained and certified by Month 36 (2029-10-08). Procure inspection equipment (diagnostic kits, pest traps, data-entry tools) for 50 checkpoints by Month 20 (2028-06-08). Establish Digital Reporting Platform (cloud-based, low-bandwidth) by Month 12 (2027-10-08).

**Responsible Body/Role:** Core Project Team (Deputy Director, Containment & Capacity Building), in partnership with Brazil, producer-country institutions, regional plant protection organizations

**Suggested Timeframe:** Month 1–36 (2026-11-08 to 2029-10-08)

**Key Outputs/Deliverables:**

- Twinning partnership agreements signed (3–5 pairs by Month 6 = 2027-04-08)
- Inspector recruitment and training programs launched (Month 3 = 2027-01-08)
- Inspection equipment procured and distributed (by Month 20 = 2028-06-08)
- Digital reporting platform operational (Month 12 = 2027-10-08)
- 100–200 inspectors trained by Month 24 (2028-10-08)
- 500 inspectors certified and operational by Month 36 (2029-10-08)

**Dependencies:**

- Brazil institutional partnership agreements finalized
- Producer-country budget allocations for capacity building approved
- CPT Containment Deputy Director onboarded

### 24. Initiate OEM buyer consortium engagement and offtake negotiation workstream by Month 0 (2026-10-08), in parallel with technology development. Establish OEM buyer consortium (5–8 major tire and rubber-goods manufacturers) by Month 6 (2027-04-08). Negotiate framework for shared tire-grade qualification testing. Secure 2–3 OEM take-or-pay letters of intent by Month 18 (2028-04-08), committing to 500–2,000 tonnes per annum each. Co-fund OEM qualification testing (Months 12–30 = 2027-10-08 to 2029-04-08) using program capex.

**Responsible Body/Role:** Core Project Team (Deputy Director, Alternative Rubber & Processing), in partnership with OEM representatives and processing operators

**Suggested Timeframe:** Month 0–30 (2026-10-08 to 2029-04-08)

**Key Outputs/Deliverables:**

- OEM Buyer Consortium Charter and governance agreed (by Month 6 = 2027-04-08)
- Buyer-consortium workplan for shared qualification testing
- OEM take-or-pay letters of intent signed (2–3 OEMs by Month 18 = 2028-04-08)
- Tire-grade qualification testing programs funded and underway (Months 12–30 = 2027-10-08 to 2029-04-08)
- Offtake commitment tracking dashboard (updated quarterly)

**Dependencies:**

- Alternative-rubber agronomic pilots underway
- CPT Alternative Rubber Deputy Director onboarded

### 25. Commence Guayule and Russian dandelion agronomic pilots in designated arid and temperate zones by Month 1 (2026-11-08). Establish 3–4 small-scale pilot plots (50–200 hectares each) in distinct climate zones per crop (Guayule: Sonora, Coahuila, Arizona, Argentina; Russian dandelion: temperate Europe, northern Americas). Conduct environmental baseline assessments and sustainability monitoring by Month 12 (2027-10-08). Run processing trials on pilot crops (Months 12–30 = 2027-10-08 to 2029-04-08), testing extraction, resin recovery, and tire-grade quality. Track cost per tonne trajectory toward USD 1.62/kg gate.

**Responsible Body/Role:** Core Project Team (Deputy Director, Alternative Rubber & Processing), in partnership with agronomic research institutes and processing operators

**Suggested Timeframe:** Month 1–30 (2026-11-08 to 2029-04-08)

**Key Outputs/Deliverables:**

- Pilot-plot sites selected and land-use agreements signed (by Month 6 = 2027-04-08)
- Environmental baseline assessments completed (by Month 12 = 2027-10-08)
- Agronomic trials underway (planting, pest/disease monitoring, yield tracking)
- Processing trial data: extraction yield, resin recovery, tire-grade test results (Months 12–30 = 2027-10-08 to 2029-04-08)
- Cost-per-tonne tracking report (quarterly, Months 12–30 = 2027-10-08 to 2029-04-08)

**Dependencies:**

- Land-use permits and environmental clearances obtained
- Agronomic and processing expertise contracted
- Alternative-rubber budget allocated (USD 7.5B, 25%)

### 26. Establish Technical Gate Charter Data Architecture by Month 1 (2026-11-08): specify data-submission templates, quality standards, and timelines from CPT workstreams to Technical Panel. Define 'verified containment,' 'cultivar readiness,' 'cost parity,' and 'smallholder adoption' operationally. Publish interpretation guidelines by Month 6 (2027-04-08). First gate-evidence submission window: Months 50–55 (2030-12-08 to 2031-05-08), allowing 60-day Panel review pre-gate at Month 36 (2029-10-08) decision. [Note: month numbering checks this timeframe; gating at Month 36 (2029-10-08) requires evidence by Month 34 (2029-08-08) at latest; revise CPT submission target to Months 32–34 (2029-08-08 to 2029-10-08) for Month 36 (2029-10-08) gate decision.]

**Responsible Body/Role:** Core Project Team (Technical Secretariat Manager and Deputy Directors), with Technical Panel guidance

**Suggested Timeframe:** Month 1–6 (2026-11-08 to 2027-04-08)

**Key Outputs/Deliverables:**

- Gate Evidence Data Architecture document (specifications for each pillar)
- KPI interpretation guidelines and scoring rubric
- CPT data-submission calendar and templates
- Technical Panel briefing on data-quality standards and assessment procedures

**Dependencies:**

- Technical Gate Charter finalized
- Technical Panel established
- CPT workstreams and data sources identified

### 27. Hold PSC Quarterly Meeting 1 (Month 3 = 2027-01-08) to review early-stage progress on protocol negotiations, germplasm collection, trial-station setup, capacity-building, and smallholder pilots. Discuss funder-alignment and any emerging political risks. Review Technical Gate Charter operationalization and gate-evidence data architecture. Confirm meeting cadence (quarterly, Months 3/6/9/12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08 of each calendar year) and extraordinary meeting triggers.

**Responsible Body/Role:** Program Steering Committee (newly established), chaired by producer-government representative

**Suggested Timeframe:** Month 3 (2027-01-08)

**Key Outputs/Deliverables:**

- PSC Quarterly Meeting Minutes (Month 3 = 2027-01-08)
- Progress dashboard (pillar-by-pillar status, funding deployment, risks, milestones)
- Funder and stakeholder briefing memo

**Dependencies:**

- PSC formally established and operating
- CPT workstreams operational and reporting

### 28. Conduct Month 6 (2027-04-08) mid-program checkpoint: comprehensive review of all workstreams against Month 0–6 (2026-10-08 to 2027-04-08) milestones. Assess containment protocol drafting progress, germplasm collection timelines, trial-station commissioning, capacity-building twinning effectiveness, smallholder-finance pilot uptake, and alternative-rubber agronomic results. Publish first 6-month progress report and funder transparency dashboard. Hold PSC Quarterly Meeting 2 and review any emerging risks or strategy adjustments needed.

**Responsible Body/Role:** Core Project Team (Executive Director and Deputy Directors), reporting to PSC

**Suggested Timeframe:** Month 6 (2027-04-08)

**Key Outputs/Deliverables:**

- Six-Month Progress Report (comprehensive, all workstreams)
- Risk dashboard (emerging or escalated risks, mitigation actions)
- Funder transparency dashboard (funding deployed, burn rate, forecast)
- PSC Quarterly Meeting Minutes (Month 6 = 2027-04-08)
- Any recommended strategy pivots or milestone adjustments (if needed)

**Dependencies:**

- CPT workstreams 6 months operational
- Early milestone data collected and analyzed

### 29. Begin formal pilot of per-tonne industry levy during Months 6–12 (2027-04-08 to 2027-10-08) in ASEAN region (Indonesia, Malaysia, Thailand as initial participating countries). Design collection mechanism at major trading ports and via tyre manufacturers. Set compliance-monitoring protocols. Target pilot collection of USD 40M annually by Month 18 (2028-04-08); if pilot compliance exceeds 80%, proceed to global rollout by Month 36 (2029-10-08). Establish independent levy-trust governance and separate bank account.

**Responsible Body/Role:** Core Project Team (Chief Financial Officer) with ASEAN producer-government partners and trade-finance advisers

**Suggested Timeframe:** Month 6–18 (2027-04-08 to 2028-04-08)

**Key Outputs/Deliverables:**

- Levy design framework (per-tonne rate, collection points, exempt categories, appeals process)
- Levy-trust charter and independent governance structure
- ASEAN pilot operating agreement signed by participating countries
- Compliance monitoring protocol and reporting
- Pilot collection revenue tracking (monthly, Months 12–18 = 2027-10-08 to 2028-04-08)
- Pilot-completion assessment (Month 18 = 2028-04-08): compliance rate, revenue, barriers, global-rollout readiness

**Dependencies:**

- Binding funding commitments secured (provides backup if levy delayed)
- CFO onboarded
- ASEAN producer-government political commitment obtained

### 30. Finalize and submit formal IPPC standard proposal for the SALB Containment Protocol to the IPPC Standards Committee by Month 18 (2028-04-08), based on work of the technical working group (launched Month 0 = 2026-10-08). Proposal includes: protocol scope (nursery stock, research materials, contaminated equipment), national implementation requirements (import rules, inspections, diagnostics), audit and compliance mechanisms, and harmonization with existing regional phytosanitary standards (ASEAN, ECOWAS, Mercosur).

**Responsible Body/Role:** Core Project Team (Deputy Director, Containment & Capacity Building), with IPPC technical working group and producer-country partners

**Suggested Timeframe:** Month 18 (2028-04-08)

**Key Outputs/Deliverables:**

- Formal IPPC Protocol Proposal document (submitted to IPPC Standards Committee)
- Summary of stakeholder review and consensus achieved
- Regional-harmonization assessments (ASEAN, ECOWAS, Mercosur alignment)

**Dependencies:**

- IPPC technical working group active and collaborative (since Month 0 = 2026-10-08)
- Producer-country buy-in and support secured

### 31. Deliver 200 characterized wild Hevea accessions with SALB-resistance documentation to breeding pipelines by Month 18 (2028-04-08), as per Brazil-led bio-prospecting and Nagoya Protocol agreement. Accessions come from endemic Amazon region with documented resistance traits (from field observation or early screening). Accessions are transferred to breeding institutes and trial stations for pyramiding studies. Publish first annual benefit-sharing report documenting royalties, community capacity-building investments, and community satisfaction.

**Responsible Body/Role:** Core Project Team (Deputy Director, Resistance Breeding & Trials), in partnership with Brazil CEPLAC/Embrapa and breeding institutes

**Suggested Timeframe:** Month 18 (2028-04-08)

**Key Outputs/Deliverables:**

- 200 characterized wild Hevea accessions transferred to breeding programs
- Accession characterization report (resistance traits, geographic origin, genetic data)
- First annual Nagoya Protocol benefit-sharing report (royalties, capacity-building, community feedback)

**Dependencies:**

- Brazil-led collection campaigns underway since Month 8 (2027-06-08)
- Germplasm characterization facilities operational
- Benefit-sharing agreements and payment mechanisms established

### 32. Hold comprehensive Month 18 (2028-04-08) program review and PSC Quarterly Meeting (Q2 of Year 2): assess progress on all workstreams 18 months into the program. Specific milestones expected: formal IPPC proposal submitted, Brazil germplasm delivery complete, 100–200 inspectors trained, containment working group active, trial stations operational, first Virulence Gate assessment underway (Month 24 = 2028-10-08 imminent), smallholder pilots reaching target zones, alternative-rubber processing trials ongoing, levy pilot results available, and binding funding commitments from 5–8 sovereigns and 2+ MDBs secured by Month 3 (2027-01-08). Review emerging risks and funder concerns.

**Responsible Body/Role:** Program Steering Committee (with Executive Director and CPT team briefing)

**Suggested Timeframe:** Month 18 (2028-04-08)

**Key Outputs/Deliverables:**

- 18-Month Comprehensive Progress Report (all pillars, major milestones)
- Funder report and commitment status (confirm or highlight gaps)
- Risk escalations and mitigation actions
- PSC Quarterly Meeting Minutes

**Dependencies:**

- All major workstreams 18 months active
- CPT data collection and reporting systems operational

### 33. Finalize regional binding compacts on the SALB Containment Protocol and secure 15 country commitment letters to adopt the protocol into national law by Month 24 (2028-10-08). Compacts cover ASEAN, ECOWAS, Mercosur regions and include reciprocal inspection rights, cross-border quarantine zones, common diagnostic standards, and dispute-resolution procedures. Each of the 15 countries publishes formal letter of political commitment to adopt protocol by Year 3 gate (Month 36 = 2029-10-08).

**Responsible Body/Role:** Core Project Team (Deputy Director, Containment & Capacity Building), with producer-country partners, regional plant protection organizations, and IPPC Secretariat

**Suggested Timeframe:** Month 24 (2028-10-08)

**Key Outputs/Deliverables:**

- Regional binding compacts signed (ASEAN, ECOWAS, Mercosur, Americas)
- 15 country commitment letters (signed by each producing country's authorized representative)
- Compact summary and harmonization achievements
- Country-by-country status roadmap toward legislative adoption (Months 24–36 = 2028-10-08 to 2029-10-08)

**Dependencies:**

- IPPC protocol proposal submitted (Month 18 = 2028-04-08)
- Producer-country political engagement and negotiations ongoing since Month 0 (2026-10-08)
- Regional plant protection organization coordination

### 34. Conduct first Virulence Gate assessment (Month 24 = 2028-10-08) via Technical Panel: evaluate resistance of candidate cultivars to contemporary SALB isolates collected from trial sites and endemic regions. For each candidate: test resistance to at least 10 isolates in high-containment assays; score pass (≥80% resistance to ≥80% of isolates) or hold (revise pyramiding, defer release). Publish pass/hold recommendations; continue breeding work on hold candidates.

**Responsible Body/Role:** Technical Panel (with CPT Deputy Director, Resistance Breeding & Trials, providing evidence)

**Suggested Timeframe:** Month 24 (2028-10-08)

**Key Outputs/Deliverables:**

- Virulence Gate Assessment Report (candidate-by-candidate resistance scores, pass/hold recommendations)
- Pathogen genomics data (virulence isolate characterization, geographic diversity)
- Hold-candidate breeding roadmap (revised pyramiding targets, revised timelines)

**Dependencies:**

- Pathogen genomics labs operational (Brazil Month 2 = 2026-12-08, Asia Month 9 = 2027-07-08)
- Trial candidates planted and under inoculation (Month 18 = 2028-04-08)
- Technical Panel assessments of candidate data

### 35. Conduct Month 30 (2029-04-08) comprehensive gate-readiness checkpoint, 6 months before the Month 36 (2029-10-08) Year 3 gate decision. CPT submits gate-evidence packages to Technical Panel (evidence submission window Months 32–34 = 2029-08-08 to 2029-10-08). Technical Panel begins intensive gate assessment in Months 28–32 (2029-02-08 to 2029-06-08), identifying evidence gaps and requesting clarifications. PSC convenes extraordinary meeting to review potential gate bottlenecks and prepare stakeholders for decision logic.

**Responsible Body/Role:** Core Project Team (Executive Director and Deputy Directors) and Technical Panel

**Suggested Timeframe:** Month 30 (2029-04-08) checkpoint; Month 32–34 (2029-08-08 to 2029-10-08) evidence submission; Month 34–36 (2029-08-08 to 2029-10-08) Panel recommendation; Month 36 (2029-10-08) PSC decision

**Key Outputs/Deliverables:**

- Month 30 (2029-04-08) gate-readiness checkpoint report (sufficiency of evidence for each pillar, anticipated gate outcomes)
- Gate-evidence packages submitted to Technical Panel (Months 32–34 = 2029-08-08 to 2029-10-08)
- CPT responses to Panel data-quality questions (within 14 days of Panel request)
- Technical Panel recommendations drafted and sent to PSC (Month 34 = 2029-08-08, allow 2-week review before public release)

**Dependencies:**

- All workstream data collected and validated
- Technical Panel intensive gate-assessment window active (Months 28–32 = 2029-02-08 to 2029-06-08)
- CPT data-submission deadlines met

### 36. Publish Year 3 gate-evidence package publicly by Month 34–35 (2029-08-08 to 2029-09-08), 60 days before PSC decision at Month 36 (2029-10-08). Package includes: containment protocol adoption status (15 country commitment letters, legislative progress), inspector-training data (500 trained, certified, deployed), documented suspect detections (≥2 lab-cleared), cultivar-readiness assessment (candidate resistance scores from Virulence Gates, trial data, yield parity evidence), smallholder pilot results (uptake rate, satisfaction, finance performance), alternative-rubber cost and quality data, and risk assessments. Include Technical Panel recommendations and any Panel dissents. Open 30-day review and appeal window for PSC members, funders, and producer governments.

**Responsible Body/Role:** Technical Panel and Core Project Team (Technical Secretariat Manager, publishing lead)

**Suggested Timeframe:** Month 34–35 (2029-08-08 to 2029-09-08); 60-day public review Months 34–36 (2029-08-08 to 2029-10-08)

**Key Outputs/Deliverables:**

- Year 3 Gate Evidence Package (published online and in print, 200+ pages, technical sections by pillar)
- Technical Panel recommendation summary (2–3 page executive summary with rationale and dissents if any)
- Public notice of 30-day appeal window (opens Month 34 = 2029-08-08, closes Month 37 = 2029-11-08; PSC decision at Month 36 = 2029-10-08 is provisional pending appeal outcome)

**Dependencies:**

- All gate-evidence data compiled and quality-checked
- Technical Panel assessment complete
- Secretariat publishing and distribution infrastructure operational

### 37. Convene PSC extraordinary gate-decision meeting at Month 36 (2029-10-08) (Year 3 gate). PSC reviews Technical Panel recommendation, hears arguments from CPT and interested stakeholders (if invited), and votes on tranche release (full, partial, or withheld) and any conditional releases. Decision rules per Technical Gate Charter: supermajority (≥75% of PSC members) to approve full tranches; consensus required for strategy pivots >10% reallocation. Publish PSC decision (including dissents) within 5 business days. If formal appeals filed within 30 days, refer to arbitration (UNCITRAL rules, 6-month timeline).

**Responsible Body/Role:** Program Steering Committee (PSC chair presiding)

**Suggested Timeframe:** Month 36 (2029-10-08)

**Key Outputs/Deliverables:**

- PSC Year 3 Gate Decision Meeting Minutes
- PSC formal gate decision (tranches released, conditions, timeline for next tranche)
- Published decision rationale and any dissents (within 5 business days)
- Tranche release authorization and payment instructions to CFO

**Dependencies:**

- Year 3 gate-evidence package published and reviewed (Months 34–36 = 2029-08-08 to 2029-10-08)
- Technical Panel recommendation provided
- PSC members briefed and prepared
- Appeal submission deadline passed (Month 37 = 2029-11-08) unless expedited arbitration requested

### 38. Execute Month 36 (2029-10-08) Year 3 gate tranche release based on PSC decision. If full attainment (≥85%), release 100% of Year 3 tranche (USD 4.5B). If partial attainment (70–85%), release proportionally (e.g., 75% if 75% criteria met = USD 3.375B), with remainder reallocated to contingency pool or stronger pillars. If <70% attainment, release 50% (USD 2.25B) and move remainder (USD 2.25B) to contingency pool. Tranches distributed by pillar to CPT workstreams; CPT begins Months 36–84 (2029-10-08 to 2033-10-08) activities (Phase 2).

**Responsible Body/Role:** Program Steering Committee (PSC) and Core Project Team (Chief Financial Officer executing)

**Suggested Timeframe:** Month 36 (2029-10-08), tranches received by CPT by Month 37–38 (2029-11-08 to 2029-12-08)

**Key Outputs/Deliverables:**

- PSC tranche-release authorization
- Wire transfer confirmation from funder accounts to CPT operating and pillar accounts
- Financial ledger update (tranche deployed, reserve balances adjusted)
- CPT Phase 2 workplan activation (breeding trials, protocol enforcement, alternative-rubber scaling begin)

**Dependencies:**

- PSC Year 3 gate decision finalized
- No sustained appeals or arbitration stalling payment
- CFO systems and accounts operational

### 39. Conduct quarterly PSC meetings and annual comprehensive program reviews throughout Months 36–84 (2029-10-08 to 2033-10-08) (Phase 2). PSC meets quarterly (Months 39, 42, 45 = 2030-01-08, 2030-04-08, 2030-07-08, etc. = 2029-12-08, 2030-03-08, 2030-06-08, etc.) to monitor: protocol adoption legislative progress (15 countries aiming for legal adoption by Month 36 = 2029-10-08, formalization by Month 60 = 2031-10-08), resistance-breeding trials (Months 36–60 = 2029-10-08 to 2031-10-08 intermediate Virulence Gate assessments, final candidates emerging Months 60–72 = 2031-10-08 to 2032-10-08), alternative-rubber pilot economics and OEM offtake progress, smallholder-adoption scale-up (replant finance and surveillance-premium expansion), funder alignment and political risks, emerging technical or financial challenges.

**Responsible Body/Role:** Program Steering Committee (PSC chair and members)

**Suggested Timeframe:** Quarterly: Months 39, 42, 45, 48, 51, 54, 57, 60, 63, 66, 69, 72, 75, 78, 81, 84 (2029-12-08, 2030-03-08, 2030-06-08, 2030-09-08, 2030-12-08, 2031-03-08, 2031-06-08, 2031-09-08, 2031-12-08, 2032-03-08, 2032-06-08, 2032-09-08, 2032-12-08, 2033-03-08, 2033-06-08, 2033-09-08); Annual deep-dive reviews at Months 48, 72 (2030-10-08, 2032-10-08)

**Key Outputs/Deliverables:**

- Quarterly PSC meeting minutes (16 meetings over Months 36–84 = 2029-10-08 to 2033-10-08)
- Quarterly progress dashboards (funding, risk, milestone tracking)
- Annual comprehensive program reviews (Months 48, 72 = 2030-10-08, 2032-10-08) with funder and stakeholder briefings

**Dependencies:**

- PSC established and operating
- CPT reporting systems live and quarterly reports delivered on schedule

### 40. Conduct Virulence Gate assessments at Months 36, 48, 60 (2029-10-08, 2030-10-08, 2031-10-08) within Phase 2: Technical Panel evaluates resistance durability of candidate cultivars against evolving SALB pathogen population. At each gate: test candidates against 10+ contemporary isolates, score resistance, recommend hold or advance. Pass candidates move toward multi-location validation; hold candidates remain in breeding pipelines. Document virulence-stability forecasts (5+ years expected durability). By Month 60 (2031-10-08), at least 2 candidates expected to be approaching final-stage trials.

**Responsible Body/Role:** Technical Panel (with CPT Breeding Deputy Director providing evidence)

**Suggested Timeframe:** Month 36 (2029-10-08), Month 48 (2030-10-08), Month 60 (2031-10-08)

**Key Outputs/Deliverables:**

- Virulence Gate assessment reports (Months 36, 48, 60 = 2029-10-08, 2030-10-08, 2031-10-08)
- Candidate-specific pass/hold/advance recommendations
- Virulence-stability forecast data (isolate diversity, evolution trends, predicted resistance durability)
- Breeding roadmap updates (revised timelines for hold candidates)

**Dependencies:**

- Pathogen genomics data collected annually and isolates characterized
- Trial-candidate data available from field sites
- Technical Panel active and assessing

### 41. Conduct Containment Efficacy Review during Months 72–84 (2032-10-08 to 2033-10-08) (Phase 2 end / Year 7 gate preparation): Technical Panel and CPT audit whether SALB-containment protocol is functionally preventing undetected incursions in currently-free regions (Asia, Africa). Minimum threshold: at least 50 documented suspect detections logged and laboratory-confirmed by Month 84 (2033-10-08). If <20 detections by Month 72 (2032-10-08), escalate surveillance sensitivity (increase sampling frequency, testing rates, inspector coverage). If zero detections by Month 60 (2031-10-08), convene emergency review (possible explanations: protocol is 100% effective; no material is moving; inspections are ineffective). Prepare contingency outbreak-response playbook for credible incursion scenario.

**Responsible Body/Role:** Technical Panel and Core Project Team (Deputy Director, Containment & Capacity Building)

**Suggested Timeframe:** Months 72–84 (2032-10-08 to 2033-10-08)

**Key Outputs/Deliverables:**

- Containment Efficacy Review report (Months 72–84 = 2032-10-08 to 2033-10-08)
- Suspect-detection log and laboratory-confirmation data (all 50+ records)
- Surveillance-sensitivity assessment and any recommended adjustments
- Outbreak-response playbook (trigger criteria, compensation rules, funding sources, deployment timelines)

**Dependencies:**

- Inspection checkpoints operational and reporting suspect materials
- Laboratory confirmation systems functional
- Technical Panel oversight and data verification

### 42. Finalize and deploy smallholder-replanting scale-up across 2–3 million eligible farmers in Asia, Africa, and Latin America by Month 72 (2032-10-08), based on pilot results from Months 6–24 (2027-04-08 to 2028-10-08). Extend replant-loan program (7–10 year tenor, <5% interest, income bridge for immature years) to all major rubber zones. Expand clean-plant nursery network to 300–600 regional hubs. Introduce surveillance-premium mechanism scaled to USD 25–50 per verified SALB report, targeting 60%+ farmer participation. Expected outcome: at least 1.5 million smallholders adopting resistant cultivars or alternatives by Month 144 (2038-10-08) (Year 12 gate).

**Responsible Body/Role:** Core Project Team (Deputy Director, Smallholder Finance & Surveillance), in partnership with farmer organizations, rural banks, and clean-plant nursery operators

**Suggested Timeframe:** Months 24–72 (2028-10-08 to 2032-10-08); scale-up completion by Month 72 (2032-10-08)

**Key Outputs/Deliverables:**

- Smallholder finance scale-up plan (credit expansion, nursery network, surveillance premiums)
- Replant-loan portfolio tracking (loans disbursed, repayment rates, uptake by region)
- Clean-plant nursery network operational (300+ hubs, certified stock production)
- Surveillance-premium participation data (farmers reporting SALB suspects, payment tracking)
- Quarterly uptake and satisfaction monitoring (Months 36–72 = 2029-10-08 to 2032-10-08)

**Dependencies:**

- Pilot results show 60%+ uptake and satisfaction (Months 6–24 = 2027-04-08 to 2028-10-08)
- Finance infrastructure and disbursement systems operational
- Resistant cultivars approaching readiness (trial data available for farmer confidence)

### 43. Scale alternative-rubber agronomic trials to commercial-pilot scale (5,000–20,000 tonnes per annum) by Month 60–72 (2031-10-08 to 2032-10-08). Guayule hubs in arid zones and Russian dandelion in temperate zones should be demonstrating cost trajectory toward USD 1.62/kg (20% premium vs. Hevea) and tire-grade quality passing 95% of Hevea specifications by Month 72 (2032-10-08). OEM buyer consortium should have locked in at least 80% of Year-10 planned volumes (1.6 million tonnes target for Year 12 = 160,000 tonnes) via written priced offtake by Month 72 (2032-10-08), enabling hub financing approvals.

**Responsible Body/Role:** Core Project Team (Deputy Director, Alternative Rubber & Processing), in partnership with agronomic research institutes, processing operators, and OEM consortium

**Suggested Timeframe:** Months 36–72 (2029-10-08 to 2032-10-08)

**Key Outputs/Deliverables:**

- Commercial-pilot agronomic data (yield, pest/disease pressure, climate impacts, water use, soil health)
- Processing trial results and cost tracking (USD 1.62/kg or better targeted)
- Tire-grade quality test results (95%+ of Hevea specs achieved)
- OEM offtake commitments summary (signed letters, volumes, price formulas, qualification status)
- Hub financing plan and approval-readiness assessment (Month 72 = 2032-10-08)

**Dependencies:**

- Pilot plots established and managed (since Month 1 = 2026-11-08)
- Processing trials ongoing (Months 12–30 = 2027-10-08 to 2029-04-08), then scaled
- OEM engagement active (since Month 0 = 2026-10-08), buyer consortium formed (Month 6 = 2027-04-08)

### 44. Conduct Month 72 (2032-10-08) comprehensive Phase 2 review and gate-readiness preparation: PSC and CPT assess Months 36–72 (2029-10-08 to 2032-10-08) progress (36-month mid-program point). Specific expectations: 15 countries with protocol adopted into law and operational inspectorates (500+ inspectors certified and deployed); containment-efficacy evidence compiled (50+ suspect detections); resistance-breeding candidates at final-trial stage (2–3 candidates with pass ratings from Virulence Gates, yield data approaching elite-clone parity); alternative-rubber pilots showing cost trajectory to Year 7 gate target and OEM offtake majority-locked; smallholder adoption at 1+ million farmers; funder commitment renewals confirmed for next tranche. Publish 36-month progress report.

**Responsible Body/Role:** Program Steering Committee and Core Project Team

**Suggested Timeframe:** Month 72 (2032-10-08)

**Key Outputs/Deliverables:**

- 36-Month Comprehensive Progress Report (all pillars, major milestones, technical achievements)
- Gate-readiness assessment for Month 84 (2033-10-08) Year 7 gate (anticipate outcomes, evidence gaps)
- Funder commitment renewal status (confirm continued multi-year support or identify gaps)
- Risk dashboard and escalations
- PSC Quarterly Meeting (Month 72 = 2032-10-08) with stakeholder briefing

**Dependencies:**

- All workstreams 3+ years operational and reporting
- Milestone data collected and validated
- CPT and PSC governance fully mature and experienced

### 45. Conduct second Virulence Gate assessment (Month 60 = 2031-10-08) and prepare final cultivar-readiness evidence for Year 7 gate. Technical Panel evaluates resistance candidates against virulence isolates; final-stage trial data reviewed (yield parity evidence, disease-pressure responses across multiple sites). By Month 72 (2032-10-08), CPT has compiled all cultivar-readiness data for gate decision. Expected outcome at Month 84 (2033-10-08) Year 7 gate: at least 2 candidates approved or 1 candidate with strong commercialization pathway, each carrying 3+ pyramided resistance genes.

**Responsible Body/Role:** Technical Panel and Core Project Team (Deputy Director, Resistance Breeding & Trials)

**Suggested Timeframe:** Month 60 (2031-10-08) Virulence Gate; Months 72–82 (2032-10-08 to 2033-08-08) cultivar-readiness data compilation; Month 84 (2033-10-08) Year 7 gate decision

**Key Outputs/Deliverables:**

- Virulence Gate assessment (Month 60 = 2031-10-08): candidate resistance scores and pass/hold recommendations
- Cultivar-readiness evidence package (Months 72–82 = 2032-10-08 to 2033-08-08): multi-site trial data, yield parity evidence, virulence-stability forecasts
- Technical Panel Year 7 gate recommendation (Month 82 = 2033-08-08)

**Dependencies:**

- Multi-location trial sites operational and providing yield and disease-response data
- Pathogen genomics data current and virulence characterization ongoing
- Technical Panel active and assessing

### 46. Publish Year 7 gate-evidence package publicly by Month 82–83 (2033-08-08 to 2033-09-08), 60 days before PSC decision at Month 84 (2033-10-08). Package includes: protocol-adoption status (15 countries expected to have full legislative adoption by now); containment-efficacy data (50+ documented detections, surveillance effectiveness assessment); resistance-cultivar readiness (2+ candidates with ≥90% resistance, ≥85% yield parity, 5+ year virulence-stability forecast); alternative-rubber cost/quality data (USD 1.62/kg or better, tire-grade tests 95%+ parity); smallholder adoption (1+ million farmers, replant-loan performance, surveillance-participation rates); and risk assessments. Include Technical Panel recommendations and any dissents. Open 30-day appeal window.

**Responsible Body/Role:** Technical Panel and Core Project Team (Technical Secretariat Manager)

**Suggested Timeframe:** Month 82–83 (2033-08-08 to 2033-09-08); 60-day public review Months 82–84 (2033-08-08 to 2033-10-08)

**Key Outputs/Deliverables:**

- Year 7 Gate Evidence Package (published online and print, 250+ pages, pillar sections)
- Technical Panel recommendation summary (executive summary with rationale and dissents)
- Public notice of 30-day appeal window

**Dependencies:**

- All gate-evidence data compiled and quality-checked
- Technical Panel assessment complete
- CPT data-submission deadline met

### 47. Convene PSC extraordinary gate-decision meeting at Month 84 (2033-10-08) (Year 7 gate). PSC reviews Technical Panel recommendation and decides on tranche release for Months 84–144 (2033-10-08 to 2038-10-08) (Phase 3). Decision rules: supermajority for tranches, consensus for >10% pillar reallocation. Expected decision: full or partial release of USD 4.5–6.5B (estimate, 2nd-tranche envelope) for scaling breeding, alternatives, and smallholder work. Publish decision within 5 business days. Process any appeals via arbitration.

**Responsible Body/Role:** Program Steering Committee (PSC chair presiding)

**Suggested Timeframe:** Month 84 (2033-10-08)

**Key Outputs/Deliverables:**

- PSC Year 7 Gate Decision Meeting Minutes
- PSC formal gate decision and tranche release authorization
- Published decision rationale and dissents (within 5 business days)

**Dependencies:**

- Year 7 gate-evidence package published and reviewed (Months 82–84 = 2033-08-08 to 2033-10-08)
- Technical Panel recommendation provided
- Appeal deadline passed (Month 85 = 2033-11-08)

### 48. Execute Year 7 gate tranche release (Month 84 = 2033-10-08). If ≥85% attainment: release 100% of tranche. If 70–85%: release proportionally. If <70%: release 50% and hold remainder in contingency. Tranches distributed to CPT pillars; Phase 3 (Months 84–144 = 2033-10-08 to 2038-10-08) activities commence: breeding scale-up, resistance-cultivar commercialization, alternative-rubber hub construction approval (if OEM offtake locked), smallholder adoption continued, protocol enforcement hardened in all 15 countries.

**Responsible Body/Role:** Program Steering Committee (PSC) and Core Project Team (Chief Financial Officer)

**Suggested Timeframe:** Month 84 (2033-10-08), funds received by CPT by Months 85–86 (2033-11-08 to 2033-12-08)

**Key Outputs/Deliverables:**

- PSC tranche-release authorization
- Wire transfer confirmation and ledger updates
- Phase 3 workplan activation (breeding commercialization, hub construction, adoption scale-up)

**Dependencies:**

- PSC Year 7 gate decision finalized
- No sustained appeals stalling payment

### 49. Conduct quarterly PSC meetings throughout Phase 3 (Months 84–144 = 2033-10-08 to 2038-10-08) to monitor: resistance-cultivar commercialization (regulatory approvals, seed multiplication, smallholder distribution), alternative-rubber hub construction and ramp-up (construction progress, cost tracking, commissioning timelines), alternative-rubber production (target 200,000 t/yr by Month 144 = 2038-10-08), smallholder adoption (target 1.5 million by Month 144 = 2038-10-08), protocol enforcement in all 15 countries (inspection quality, suspect-detection logging, cross-border coordination), funder alignment and political risks.

**Responsible Body/Role:** Program Steering Committee (PSC chair and members)

**Suggested Timeframe:** Quarterly: Months 87, 90, 93 (2034-01-08, 2034-04-08, 2034-07-08), ... 144 (2034-01-08, 2034-04-08, 2034-07-08, ... 2038-10-08); Annual deep-dive at Months 96, 120 (2034-10-08, 2036-10-08)

**Key Outputs/Deliverables:**

- Quarterly PSC meeting minutes (16 meetings over Months 84–144 = 2033-10-08 to 2038-10-08)
- Quarterly progress dashboards
- Annual comprehensive reviews (Months 96, 120 = 2034-10-08, 2036-10-08)

**Dependencies:**

- PSC operating and CPT reporting systems live

### 50. Approve commercial alternative-rubber hub construction by Month 96 (2034-10-08) (Phase 3 checkpoint) only if: (1) OEM offtake is at least 80% priced and written (500+ tonnes per annum per OEM, multiple OEMs committing); (2) agronomic pilot cost data shows USD 1.62/kg achievable or below; (3) tire-grade quality specs validated; (4) environmental and permitting approvals secured; (5) debt financing structured (private or development-bank backed). Target hub commissioning by Month 120 (2036-10-08) and ramp to 200,000 t/yr by Month 144 (2038-10-08). If conditions not met by Month 96 (2034-10-08), defer hub construction to Months 108–120 (2036-10-08 to 2036-10-08), pushing production timeline 1–2 years later.

**Responsible Body/Role:** Program Steering Committee (with CPT Deputy Director, Alternative Rubber & Processing, and OEM consortium input)

**Suggested Timeframe:** Month 96 (2034-10-08) approval decision; construction if approved Months 96–120 (2034-10-08 to 2036-10-08); commissioning by Month 120 (2036-10-08)

**Key Outputs/Deliverables:**

- Hub construction approval or deferral decision (Month 96 = 2034-10-08)
- Hub construction timeline and capex plan (if approved)
- Financing structure and debt-agreement signatures
- Environmental compliance and permitting documentation

**Dependencies:**

- OEM offtake majority-locked (by Month 72–96 = 2032-10-08 to 2034-10-08)
- Alternative-rubber pilot data showing cost trajectory (by Month 72 = 2032-10-08)
- Permitting and environmental clearances

### 51. Conduct Month 120 (2036-10-08) mid-Phase 3 review and Year 12 gate-readiness preparation. PSC and CPT assess Months 84–120 (2033-10-08 to 2036-10-08) progress (48-month Phase 3 midpoint). Expectations: resistance cultivars approved for commercial release and seed-multiplication underway; alternative-rubber hubs commissioned or on-track for Month 144 (2038-10-08) target; production ramping toward 200,000 t/yr target; 1.5 million smallholders expected to have adopted resistant cultivars or alternatives by Month 144 (2038-10-08); protocol enforcement operational in 15 countries; contingency reserves assessed. Publish 48-month review report.

**Responsible Body/Role:** Program Steering Committee and Core Project Team

**Suggested Timeframe:** Month 120 (2036-10-08)

**Key Outputs/Deliverables:**

- 48-Month Comprehensive Progress Report (Phase 3 midpoint, Months 84–120 = 2033-10-08 to 2036-10-08)
- Year 12 gate-readiness assessment (what evidence will be needed by Month 144 = 2038-10-08)
- Funder commitment status (confirm or identify gaps for remaining tranches)
- Risk dashboard and escalations
- PSC meeting (Month 120 = 2036-10-08)

**Dependencies:**

- All workstreams 5+ years operational
- Hub construction milestones on track

### 52. Prepare Year 12 gate-evidence package (Months 136–142 = 2038-06-08 to 2038-08-08) and publish by Month 142 (2038-08-08), 60 days before PSC decision at Month 144 (2038-10-08). Package includes: protocol enforcement outcomes (verified containment in 15+ countries, zero undetected SALB incursions); resistant-cultivar adoption (1.5 million smallholders, seed multiplication ramp-up); alternative-rubber production (≥200,000 t/yr operating, cost/quality at gate thresholds); smallholder finance performance (replant-loan repayment, surveillance participation); risk assessments and climate-shock resilience testing. Include Technical Panel recommendations and dissents. Open 30-day appeal window.

**Responsible Body/Role:** Core Project Team (Technical Secretariat Manager) and Technical Panel

**Suggested Timeframe:** Months 136–142 (2038-06-08 to 2038-08-08); 60-day public review Months 142–144 (2038-08-08 to 2038-10-08)

**Key Outputs/Deliverables:**

- Year 12 Gate Evidence Package (published, 300+ pages, pillar sections)
- Technical Panel Year 12 recommendation
- Climate-shock stress-test results (alternative-rubber viability under drought/flood scenarios)

**Dependencies:**

- All gate-evidence data compiled and validated
- Technical Panel assessment complete

### 53. Convene PSC extraordinary gate-decision meeting at Month 144 (2038-10-08) (Year 12 gate). PSC reviews Technical Panel recommendation and decides on tranche release for Months 144–216 (2038-10-08 to 2044-10-08) (Phase 4). Expected decision: full or partial release of remaining tranches (estimate USD 5–7B, final tranche envelope) for continued scaling, smallholder adoption, alternative-rubber expansion to 5% global supply target, and protocol/research sustainability into Phase 5 handover. Publish decision within 5 business days.

**Responsible Body/Role:** Program Steering Committee (PSC chair presiding)

**Suggested Timeframe:** Month 144 (2038-10-08)

**Key Outputs/Deliverables:**

- PSC Year 12 Gate Decision Meeting Minutes
- PSC formal gate decision and Year 12–18 tranche release authorization
- Published decision rationale and dissents

**Dependencies:**

- Year 12 gate-evidence package published and reviewed (Months 142–144 = 2038-08-08 to 2038-10-08)
- Technical Panel recommendation provided
- Appeal deadline passed (Month 145 = 2038-11-08)

### 54. Execute Year 12 gate tranche release (Month 144 = 2038-10-08). Release tranches according to attainment (full, partial, or 50% if <70%). Tranches distributed to CPT pillars; Phase 4 (Months 144–216 = 2038-10-08 to 2044-10-08) activities commence: alternative-rubber scale-up to 5% global supply (USD 700,000 t/yr target by Month 216 = 2044-10-08), resistant-cultivar adoption continuation (targeting full genetic diversity in major plantations by Year 18), smallholder sustainability and price-stability mechanisms hardened, protocol enforcement and surveillance maintained, transition planning for post-funding handover (Phases 5, Months 216–300 = 2044-10-08 to 2050-10-08).

**Responsible Body/Role:** Program Steering Committee (PSC) and Core Project Team (Chief Financial Officer)

**Suggested Timeframe:** Month 144 (2038-10-08)

**Key Outputs/Deliverables:**

- PSC tranche-release authorization
- Wire transfers and ledger updates
- Phase 4 workplan activation (scaling to 5% global supply, handover planning)

**Dependencies:**

- PSC Year 12 gate decision finalized
- No sustained appeals stalling payment

### 55. Conduct quarterly PSC meetings throughout Phase 4 (Months 144–216 = 2038-10-08 to 2044-10-08) to monitor: alternative-rubber production expansion to 5% global demand (700,000 t/yr target by Month 216 = 2044-10-08), resistant-cultivar global adoption and genetic diversity in major regions, smallholder sustainability and price-stability effectiveness, protocol enforcement durability and producer-country institutional ownership (capacity handover preparation), funder commitment for final tranche (Year 18 gate at Month 216 = 2044-10-08) and post-program responsibilities.

**Responsible Body/Role:** Program Steering Committee (PSC chair and members)

**Suggested Timeframe:** Quarterly: Months 147, 150, 153 (2039-01-08, 2039-04-08, 2039-07-08), ... 216 (2039-01-08, 2039-04-08, 2039-07-08, ... 2044-10-08); Annual deep-dive at Months 156, 180, 204 (2039-10-08, 2041-10-08, 2043-10-08)

**Key Outputs/Deliverables:**

- Quarterly PSC meeting minutes (24 meetings over Phase 4)
- Annual comprehensive reviews (Months 156, 180, 204 = 2039-10-08, 2041-10-08, 2043-10-08)

**Dependencies:**

- PSC operating; CPT reporting systems live

### 56. Conduct handover-readiness assessments (Months 180–216 = 2041-10-08 to 2044-10-08) with Producer-Country Coordination Forum (PCCF) to evaluate whether national agricultural agencies, research institutes, and inspection services in 15+ producing countries are ready for post-funding sustainability and protocol enforcement. Assess: staffing and retention, budgeting and institutional funding, technical capability (labs, nurseries, inspectors), political commitment, and ownership of protocols and cultivars. Identify pre-handover capacity-building needs and remedial investments. By Month 216 (2044-10-08), establish transition plan to producer-country leadership and multilateral secretariat closure or reduced role.

**Responsible Body/Role:** Producer-Country Coordination Forum (PCCF) and Core Project Team (CPT Deputy Directors), with Technical Panel input

**Suggested Timeframe:** Months 180–216 (2041-10-08 to 2044-10-08)

**Key Outputs/Deliverables:**

- Handover-readiness assessments (country-by-country evaluations by Month 200 = 2043-06-08)
- Producer-country institutional capacity audit (staffing, funding, ownership)
- Remedial capacity-building plan (if gaps identified)
- Transition and handover plan for Month 216 (2044-10-08) onwards

**Dependencies:**

- PCCF active and engaged (since Month 1 = 2026-11-08)
- Capacity-building twinning and training complete or handed over to national programs

### 57. Prepare Year 18 gate-evidence package (Months 208–212 = 2044-06-08 to 2044-08-08) and publish by Month 212 (2044-06-08), 60 days before PSC decision at Month 216 (2044-10-08). Package includes: protocol enforcement outcomes and handover readiness (15+ countries with operationally independent national capacity); resistant-cultivar adoption and genetic diversity (global adoption across major regions, seed systems operationally independent); alternative-rubber supply at 5%+ global demand (700,000+ t/yr); smallholder sustainability and price-stability mechanisms (farmer income secured, surveillance participation sustained); producer-country readiness for post-funding operation; financial sustainability of national programs and protocol enforcement. Include Technical Panel final assessment and transition recommendations.

**Responsible Body/Role:** Core Project Team and Technical Panel

**Suggested Timeframe:** Months 208–212 (2044-06-08 to 2044-08-08); 60-day public review Months 212–216 (2044-08-08 to 2044-10-08)

**Key Outputs/Deliverables:**

- Year 18 Gate Evidence Package (published, 300+ pages, handover-readiness focus)
- Technical Panel Year 18 final assessment and transition recommendations
- Handover plan for post-program operations (Months 216–300 = 2044-10-08 onwards)

**Dependencies:**

- All gate-evidence data compiled and validated
- Handover-readiness assessments completed
- Technical Panel final assessment complete

### 58. Convene PSC extraordinary gate-decision meeting at Month 216 (2044-10-08) (Year 18 gate). PSC reviews Technical Panel final assessment and decides on final tranche release and program transition. Decision typically: (a) release final tranches (if attainment ≥70%) for Months 216–300 (2044-10-08 onwards) post-program responsibilities; (b) authorize multilateral secretariat transition plan (reduce staff, hand over functions to producer-country institutions and remaining governance bodies, close or downsize if post-program monitoring deemed unnecessary). Publish decision. This is the final programmatic gate; Phase 5 (Months 216–300 = 2044-10-08 to 2050-10-08) is post-program operation and handover.

**Responsible Body/Role:** Program Steering Committee (PSC chair presiding)

**Suggested Timeframe:** Month 216 (2044-10-08)

**Key Outputs/Deliverables:**

- PSC Year 18 Gate Decision Meeting Minutes
- PSC formal final-tranche release authorization and transition decision
- Published decision and program-closeout plan
- Multilateral secretariat transition/closeout workplan

**Dependencies:**

- Year 18 gate-evidence package published and reviewed (Months 212–216 = 2044-08-08 to 2044-10-08)
- Technical Panel final assessment and handover recommendations provided
- Producer-country readiness confirmed

### 59. Execute Year 18 gate tranche release (Month 216 = 2044-10-08) and authorize program closeout plan. Final tranches (if any) distributed for post-program operations (Months 216–300 = 2044-10-08 to 2050-10-08), including: monitoring residual risks (SALB surveillance continuation), smallholder support (phased reduction of subsidies, transition to farmer-led mechanisms), producer-country institutional sustainability (capacity building winding down, national ownership complete), and archival of data and lessons learned. Multilateral secretariat staff transitions to post-program support roles or exits.

**Responsible Body/Role:** Program Steering Committee (PSC) and Core Project Team (Executive Director)

**Suggested Timeframe:** Month 216 (2044-10-08) onwards; program close-out completed by Month 300 (2050-10-08)

**Key Outputs/Deliverables:**

- PSC final tranche-release authorization
- Program closeout and transition plan (Months 216–300 = 2044-10-08 to 2050-10-08)
- Multilateral secretariat transition/closure procedures
- Handover to producer-country institutions and remaining governance bodies

**Dependencies:**

- PSC Year 18 gate decision finalized
- Producer-country capacity and ownership confirmed

### 60. Establish post-program governance continuation mechanism (Phase 5, Months 216–300 = 2044-10-08 to 2050-10-08): if ongoing SALB surveillance and producer-country coordination are deemed necessary, convert PSC to a lighter-weight multilateral oversight body or hand functions to existing regional plant protection organizations (ASEAN, ECOWAS, Mercosur) and IPPC Secretariat. Producer-Country Coordination Forum (PCCF) may continue as primary governance body for producer-country collaboration and protocol enforcement, with reduced external (development-bank) participation. Establish modest residual endowment (if available) for long-term surveillance and emergency response.

**Responsible Body/Role:** Program Steering Committee (PSC) and Producer-Country Coordination Forum (PCCF)

**Suggested Timeframe:** Months 208–216 (2044-06-08 to 2044-10-08) planning; transition to new governance by Month 216 (2044-10-08); Phase 5 continues to Month 300 (2050-10-08)

**Key Outputs/Deliverables:**

- Post-program governance charter (functions, decision rights, funder roles Months 216–300 = 2044-10-08 to 2050-10-08)
- PCCF expanded charter (if becomes primary body for post-program)
- Regional plant protection organization transition agreements (handover of protocol monitoring)
- Residual endowment or contingency fund for long-term surveillance (if established)

**Dependencies:**

- Program closeout plan agreed at Month 216 (2044-10-08) gate
- Producer-country consensus on post-program arrangements
- Regional plant protection organization buy-in