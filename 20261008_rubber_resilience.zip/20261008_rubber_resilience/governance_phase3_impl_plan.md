### 1. Project Sponsor (Senior Funder Representative) identifies and appoints the Steering Council Chair. The Chair is selected from among the sovereign funders and given explicit authority to lead the inaugural Council convening.

**Responsible Body/Role:** Project Sponsor / Lead Sovereign Funder

**Suggested Timeframe:** Month 0 (2026-10-12) (project start: 2026-10-12)

**Key Outputs/Deliverables:**

- Steering Council Chair appointment letter
- Written delegation of authority to Chair for inaugural convening

**Dependencies:**

- Project formally authorized and funding commitment confirmed from at least one sovereign funder

### 2. Steering Council Chair drafts and circulates the initial Terms of Reference (ToR) for the Steering Council, defining governance scope, decision thresholds (e.g., USD 50M spend authority delegation, gate-passage authority), escalation rules, meeting cadence (quarterly), and transparency standards. Circulate for feedback from nominated sovereign, OEM, research institution and smallholder representatives by Month 2 (2026-12-12).

**Responsible Body/Role:** Steering Council Chair (appointed by Sponsor)

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 2 (2026-12-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Steering Council Terms of Reference v0.1
- Stakeholder feedback summary

**Dependencies:**

- Steering Council Chair appointed
- List of nominated Council members (sovereign reps, OEM reps, research institution reps, smallholder reps) confirmed

### 3. Steering Council Chair finalizes the ToR based on stakeholder feedback and formally appoints the initial Council membership (at least 5 sovereign funders, 2-3 OEM representatives, 2-3 research institution representatives, 1-2 smallholder/farmer representatives). Distribute final ToR to all appointed members.

**Responsible Body/Role:** Steering Council Chair

**Suggested Timeframe:** Month 2 (2026-12-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Steering Council Terms of Reference Final
- Council member appointment letters
- Council member contact list and availability calendar

**Dependencies:**

- Steering Council ToR v0.1 feedback resolved
- Candidate pool for Council seats identified and pre-vetted

### 4. Steering Council Chair schedules and holds the inaugural Steering Council kick-off meeting. Council formally confirms its role, approves governance procedures, confirms the quarterly meeting schedule (with accelerated monthly meetings Months 3-6 during early setup), and establishes the escalation hierarchy.

**Responsible Body/Role:** Steering Council (all members present)

**Suggested Timeframe:** Month 1 (2026-11-12) - meeting scheduled; meeting held by Month 3 (2027-01-12)

**Key Outputs/Deliverables:**

- Inaugural Council meeting minutes with decisions recorded
- Approved meeting schedule (quarterly with monthly Months 3-6 = 2027-01-12 to 2027-04-12)
- Confirmed governance procedures and decision-making rules

**Dependencies:**

- Steering Council membership formalized
- Terms of Reference finalized and distributed

### 5. Steering Council authorizes the recruitment of the Programme Director, the chief operational executive. The Council defines the role (reporting to Council Chair and full Council), authority thresholds (USD 50M), and required qualifications (senior programme management, agricultural/supply-chain experience, 25-year strategic stamina).

**Responsible Body/Role:** Steering Council

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Programme Director job description
- Recruitment request to search firm or internal vetting process

**Dependencies:**

- Steering Council formally established and kick-off meeting held
- Budget allocated for Programme Director salary and PMO staffing

### 6. Project Sponsor or Programme Director candidate (if internal recruitment from existing institution) recruits the Compliance & Ethics Committee Chair, an independent external expert in agricultural development-programme governance or anti-corruption. The Chair is not part of PMO but reports directly to the Steering Council.

**Responsible Body/Role:** Project Sponsor / Steering Council Chair (if no Programme Director yet hired)

**Suggested Timeframe:** Month 1 (2026-11-12)

**Key Outputs/Deliverables:**

- Compliance & Ethics Committee Chair recruitment initiated
- Chair job description and independence criteria published

**Dependencies:**

- Steering Council authorized recruitment of Compliance & Ethics infrastructure

### 7. Compliance & Ethics Committee Chair, once appointed (by Month 1-2, 2026-11-12 to 2026-12-12), drafts the programme Code of Conduct and anti-corruption policy. This policy applies to all PMO staff, contractors, partners, and nominated representatives from producing nations and OEMs.

**Responsible Body/Role:** Compliance & Ethics Committee Chair

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Draft Code of Conduct and Anti-Corruption Policy v0.1
- Whistleblower-protection procedures draft

**Dependencies:**

- Compliance & Ethics Committee Chair recruited and appointed

### 8. Compliance & Ethics Committee Chair circulates the Code of Conduct and policy for stakeholder review; collects feedback from Steering Council, research institutions, producer-nation representatives, and OEMs. Incorporate feedback by Month 2-3 (2026-12-12 to 2027-01-12).

**Responsible Body/Role:** Compliance & Ethics Committee Chair

**Suggested Timeframe:** Month 2 (2026-12-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Stakeholder feedback summary on Code of Conduct
- Revised Code of Conduct v0.2

**Dependencies:**

- Code of Conduct draft circulated

### 9. Steering Council formally approves the final Code of Conduct, Anti-Corruption Policy and whistleblower procedures. Publish the policies to all stakeholders.

**Responsible Body/Role:** Steering Council

**Suggested Timeframe:** Month 3 (2027-01-12)

**Key Outputs/Deliverables:**

- Steering Council approval minute on Code of Conduct
- Final Code of Conduct, Anti-Corruption Policy and Whistleblower Procedures (published)

**Dependencies:**

- Code of Conduct v0.2 finalized
- Steering Council inaugural meeting held

### 10. Programme Director, once hired (by Month 3, 2027-01-12), establishes the Programme Management Office (PMO). Recruit Deputy Programme Director, Finance Manager, and Workstream Coordinators for Containment Protocol, Breeding Trials, Alternative Crops, and Smallholder Delivery by Month 3-6 (2027-01-12 to 2027-04-12).

**Responsible Body/Role:** Programme Director (upon hire)

**Suggested Timeframe:** Month 3 (2027-01-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- PMO organizational chart
- Job descriptions for Deputy Director, Finance Manager, Workstream Coordinators
- Recruitment complete; all PMO leadership seated by Month 6 (2027-04-12)

**Dependencies:**

- Programme Director hired by Month 3 (2027-01-12)
- Budget allocated for PMO staffing
- Steering Council approved PMO structure

### 11. Steering Council authorizes the contracting of an independent international auditor to verify gate evidence. Steering Council issues a Request for Proposals (RFP) by Month 2 (2026-12-12).

**Responsible Body/Role:** Steering Council

**Suggested Timeframe:** Month 2 (2026-12-12)

**Key Outputs/Deliverables:**

- RFP for independent auditor issued

**Dependencies:**

- Steering Council formally established
- Budget for auditor identified (USD 30-50M estimate)

### 12. Auditor selection and contract negotiation. Steering Council evaluates RFP responses and selects the independent auditor by Month 3 (2027-01-12). Contract is signed with independence clauses, data-access rights, and gate-closure timeline (reports 30 days before each gate).

**Responsible Body/Role:** Steering Council (with PMO Finance Manager support)

**Suggested Timeframe:** Month 2 (2026-12-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Auditor selection documented
- Auditor contract signed with independence and reporting clauses

**Dependencies:**

- RFP for auditor issued
- Steering Council evaluation process initiated

### 13. Independent Auditor, once contracted (by Month 3, 2027-01-12), recruits its core audit team (Team Lead, field auditors, data specialists). Auditor begins designing pre-registered audit scope and KPI definitions for Month 36 gate (2029-10-12) by Month 4 (2027-02-12).

**Responsible Body/Role:** Independent Auditor (contracted firm)

**Suggested Timeframe:** Month 3 (2027-01-12) to Month 4 (2027-02-12 to 2027-02-12)

**Key Outputs/Deliverables:**

- Auditor Team Lead and core team named
- Audit design framework for Month 36 (2029-10-12) gate initiated

**Dependencies:**

- Auditor contract signed

### 14. Steering Council establishes the Technical Advisory Group to support the independent auditor with specialized scientific advice on breeding, phytosanitary, processing and supply-chain questions. Recruit 6-8 members (plant pathologist, breeder, processing engineer, agronomist, statistician, economist, optionally OEM and smallholder-agronomy specialist) by Month 3 (2027-01-12).

**Responsible Body/Role:** Steering Council

**Suggested Timeframe:** Month 3 (2027-01-12)

**Key Outputs/Deliverables:**

- Technical Advisory Group membership appointed
- Advisory Group ToR finalized

**Dependencies:**

- Steering Council authorized Advisory Group establishment

### 15. Steering Council, jointly with the Independent Auditor and Technical Advisory Group, pre-registers the audit scope, KPI definitions, validation thresholds, and dispute-resolution protocol for all four gates (Months 36, 84, 144, 216 = 2029-10-12, 2033-10-12, 2038-10-12, 2044-10-12). Document includes field-visit plan (30-40%), database audit (40-50%), interviews (20-30%), and clear pass/fail criteria for each KPI.

**Responsible Body/Role:** Independent Auditor (with Technical Advisory Group and Steering Council input)

**Suggested Timeframe:** Month 4 (2027-02-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Pre-Registered Audit Scope and KPI Definitions document (published)
- Gate Evidence Verification Regime operational manual

**Dependencies:**

- Independent Auditor contracted and team recruited
- Technical Advisory Group established
- PMO workstreams defined so KPIs can be aligned with delivery targets

### 16. Steering Council appoints the Gate Adjudication Panel Chair (neutral third party), who will mediate disputes between the Steering Council and Independent Auditor on gate verdicts. Panel is composed of three independent experts (one arbitration specialist, one agriculture specialist, one supply-chain governance specialist). Panel is activated only if formal disputes are filed.

**Responsible Body/Role:** Steering Council

**Suggested Timeframe:** Month 6 (2027-04-12)

**Key Outputs/Deliverables:**

- Gate Adjudication Panel Chair appointed
- Panel members named
- Panel ToR and dispute-resolution procedures published

**Dependencies:**

- Steering Council authorized Panel establishment
- Pre-registered audit scope finalized

### 17. Compliance & Ethics Committee Chair, supported by the Steering Council, completes recruitment of the full Committee: Anti-Corruption Officer, Compliance Manager, ABS Specialist, Environmental & Social Safeguards Officer, and one independent external member. All staff seated by Month 3-6 (2027-01-12 to 2027-04-12).

**Responsible Body/Role:** Compliance & Ethics Committee Chair (with Steering Council support)

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Compliance & Ethics Committee full staffing complete
- Anti-Corruption Officer, Compliance Manager, ABS Specialist and Safeguards Officer seated

**Dependencies:**

- Compliance & Ethics Committee Chair appointed
- Committee ToR finalized
- Budget allocated for Committee staffing

### 18. Compliance & Ethics Committee publishes the final Code of Conduct and requires all PMO staff, contractors, partners, and nominated representatives from producing nations and OEMs to sign by Month 6 (2027-04-12). Maintain signed records.

**Responsible Body/Role:** Compliance & Ethics Committee

**Suggested Timeframe:** Month 3 (2027-01-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Code of Conduct signed by 100% of PMO, contractor, and partner personnel
- Conflict-of-interest disclosure forms completed and archived

**Dependencies:**

- Code of Conduct final version approved by Steering Council
- All PMO and key contractor staff identified

### 19. Compliance & Ethics Committee establishes confidential whistleblower reporting channels (dedicated hotline, email, mobile-based field-agent channel for smallholders and inspectors) and publicizes channels to all programme personnel and communities by Month 3-6 (2027-01-12 to 2027-04-12). Train frontline staff on reporting procedures.

**Responsible Body/Role:** Compliance & Ethics Committee (Anti-Corruption Officer and Compliance Manager)

**Suggested Timeframe:** Month 3 (2027-01-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Whistleblower hotline operational
- Whistleblower-protection procedures published and disseminated to all staff and communities
- Training materials for field staff on reporting procedures

**Dependencies:**

- Whistleblower procedures finalized
- Compliance & Ethics Committee staffed

### 20. Steering Council signs binding 25-year framework agreements with all sovereign and multilateral-development-bank funders. Agreements specify gate-release triggers (minimum 80% of tranche released on partial gate success), disbursement timelines (within 45 days of gate passage), minimum-funding floors (e.g., 80% of planned tranche if gate is partially met), and escalation procedures for funding disputes. Completion target: Month 12 (2027-10-12).

**Responsible Body/Role:** Steering Council (with legal counsel)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Binding 25-year framework agreements signed with each funder
- Master framework agreement document
- Tranche-release trigger matrix

**Dependencies:**

- Steering Council formally established
- Gate KPI definitions finalized
- Budget and tranche allocation approved by Steering Council

### 21. Steering Council negotiates and executes industry resilience levy agreements with the top 10 tire makers and 5 major rubber traders. Levy is set at 0.75% (range 0.5-1.0%, estimate) of covered natural-rubber purchases, yielding approximately USD 150M/year (estimate). Agreements include multi-year binding commitments with penalties for early defection.

**Responsible Body/Role:** Steering Council (OEM members and Programme Director leading negotiation)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Levy agreements signed with at least 10 OEMs and 5 traders
- Levy collection mechanism and schedule established
- First levy payment received by Month 18 (2028-04-12) (estimate)

**Dependencies:**

- Steering Council OEM members authorized to commit companies
- Levy rate and structure decided by Council

### 22. PMO Finance Manager, upon hire (by Month 6, 2027-04-12), establishes an integrated budget-tracking and KPI-monitoring system. System links monthly workstream milestones to gate criteria, tracks spending against the USD 30 billion cap, forecasts burn rate through each phase, and alerts to variances exceeding 10%.

**Responsible Body/Role:** PMO Finance Manager

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 9 (2027-07-12 to 2027-07-12)

**Key Outputs/Deliverables:**

- Integrated budget and KPI tracking dashboard operational
- Monthly financial reporting template
- Quarterly KPI dashboard for Steering Council

**Dependencies:**

- PMO staffing complete
- Budget allocations finalized
- Phase 1 delivery plan drafted

### 23. Programme Director establishes the SALB Containment Protocol Authority, a dedicated body within the FAO/IPPC institutional framework. Recruit Containment Authority Director (senior phytosanitary specialist) and Deputy Directors for Protocol Drafting and Compliance Inspection by Month 1-3 (2026-11-12 to 2027-01-12). Director reports to Programme Director and Steering Council.

**Responsible Body/Role:** Programme Director (with Steering Council oversight)

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Containment Authority Director recruited
- Deputy Director positions filled
- Authority operational charter approved by Steering Council

**Dependencies:**

- Programme Director hired
- Steering Council approved establishment of Containment Authority

### 24. Containment Protocol Authority Director establishes a Protocol Adoption Secretariat at FAO/IPPC (Rome) with dedicated staff reporting to the Director. Secretariat is tasked with coordinating protocol drafting, IPPC working-group engagement, and producer-nation adoption negotiations. Staffing complete by Month 3 (2027-01-12).

**Responsible Body/Role:** Containment Protocol Authority Director

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Protocol Adoption Secretariat established at FAO/IPPC
- Secretariat organizational chart and staff assignments published

**Dependencies:**

- Containment Authority Director recruited
- FAO/IPPC hosting agreement confirmed

### 25. Containment Protocol Authority Director, with the Secretariat, drafts the SALB Containment Protocol harmonized with IPPC and regional plant-protection standards. Draft incorporates movement controls for nursery stock, research materials and equipment, quarantine procedures, inspection criteria, and penalty schedules for non-compliance. Coordinate with phytosanitary specialists from all top 5 producing nations during drafting.

**Responsible Body/Role:** Containment Protocol Authority (Secretariat staff and drafting team)

**Suggested Timeframe:** Month 2 (2026-12-12) to Month 4 (2027-02-12 to 2027-02-12)

**Key Outputs/Deliverables:**

- Draft SALB Containment Protocol v0.1 (circulated for stakeholder feedback)

**Dependencies:**

- Containment Authority Director and Secretariat seated
- Input from phytosanitary experts from top 5 producers secured

### 26. Containment Protocol Authority submits the draft protocol to the IPPC working group for technical comment and harmonization review. IPPC working group is composed of plant-protection agency representatives from major rubber-producing nations, IPPC Secretariat, regional plant-protection organizations, and OEM observers. Working-group meetings held Months 3-4 (2027-01-12 to 2027-02-12); feedback period through Month 4 (2027-02-12).

**Responsible Body/Role:** Containment Protocol Authority (in coordination with IPPC)

**Suggested Timeframe:** Month 3 (2027-01-12) to Month 4 (2027-02-12 to 2027-02-12)

**Key Outputs/Deliverables:**

- IPPC working-group comment summary
- Draft protocol v0.2 incorporating stakeholder feedback

**Dependencies:**

- Draft protocol v0.1 submitted to IPPC
- IPPC working group convened

### 27. Containment Protocol Authority Director leads bilateral MoU negotiations with Brazil, Indonesia, Thailand, Malaysia, and Vietnam (top 5 rubber-producing nations). Each MoU commits the producing nation to embed the SALB protocol in its national plant-protection regulation by Month 36 (2029-10-12) and to maintain at least 20 trained inspectors and compliance-certificate management. Target completion of all 5 MoUs: Month 6 (2027-04-12).

**Responsible Body/Role:** Containment Protocol Authority Director (with PMO and Steering Council support)

**Suggested Timeframe:** Month 3 (2027-01-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Bilateral MoU with Brazil signed
- Bilateral MoU with Indonesia signed
- Bilateral MoU with Thailand signed
- Bilateral MoU with Malaysia signed
- Bilateral MoU with Vietnam signed

**Dependencies:**

- Draft protocol v0.2 ready for country discussion
- Steering Council authorized bilateral negotiation with countries

### 28. Containment Protocol Authority, in coordination with national plant-protection agencies from top 5 producers, develops standardized compliance-inspection standard operating procedures (SOPs) and inspector training curriculum. SOPs specify nursery-inspection protocols, lot-tracking procedures, certificate issuance and revocation rules, and inspection reporting. Curriculum is tailored to each country's institutional capacity.

**Responsible Body/Role:** Containment Protocol Authority (Deputy Director for Compliance Inspection, with input from country plant-protection agencies)

**Suggested Timeframe:** Month 4 (2027-02-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Standardized Compliance-Inspection SOP (published)
- Inspector Training Curriculum (published, country-specific modules)

**Dependencies:**

- Bilateral MoUs with top 5 producers signed
- IPPC protocol harmonization near completion

### 29. Containment Protocol Authority Deputy Director for Compliance Inspection begins recruiting and training 100+ compliance inspectors across the top 5 producing nations (approximately 20 per country). Training uses the standardized curriculum; recruits are drawn from existing national plant-protection agencies and agricultural research institutes. First cohort of 50 inspectors trained by Month 12 (2027-10-12); full complement of 100 by Month 18 (2028-04-12).

**Responsible Body/Role:** Containment Protocol Authority (Deputy Director for Compliance Inspection)

**Suggested Timeframe:** Month 9 (2027-07-12) to Month 18 (2028-04-12 to 2028-04-12)

**Key Outputs/Deliverables:**

- 100+ inspectors recruited and trained by Month 18 (2028-04-12)
- Inspector certification and field-deployment roster
- First 50 inspectors operational by Month 12 (2027-10-12)

**Dependencies:**

- Compliance-inspection SOP and curriculum finalized
- Bilateral MoUs with countries committed inspector staffing
- Budget allocated for inspector salaries and training (estimated USD 100-150M over Months 0-120 = 2026-10-12 to 2036-10-12)

### 30. Containment Protocol Authority establishes a compliance-certificate database and mobile-based lot-tracking system to manage nursery certifications, inspection schedules, and certified material movements. System is deployed to inspectors and participating nurseries by Month 12 (2027-10-12). Database is linked to surveillance and incursion-response systems for alert verification.

**Responsible Body/Role:** Containment Protocol Authority (IT and Compliance teams)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Compliance-certificate database operational
- Mobile lot-tracking system deployed to 100+ inspectors
- Real-time dashboard of nurseries under certification

**Dependencies:**

- Containment Authority IT infrastructure established
- Inspector staffing begun

### 31. Containment Protocol Authority publishes the binding penalty schedule for protocol non-compliance: fines equal to 5-10x (estimate) the value of affected planting material, publication in national gazettes, and reputational consequences (public certificate suspension). Penalties are enforced uniformly across all countries per the bilateral MoUs.

**Responsible Body/Role:** Containment Protocol Authority (Compliance and Enforcement Manager)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 9 (2027-07-12 to 2027-07-12)

**Key Outputs/Deliverables:**

- Binding penalty schedule published
- Penalty enforcement procedures documented

**Dependencies:**

- Bilateral MoUs signed (country commitment to enforce)
- Steering Council approved penalty framework

### 32. Containment Protocol Authority publishes the finalized SALB Containment Protocol for IPPC adoption vote. Protocol incorporates all stakeholder feedback and is harmonized with regional phytosanitary standards. Formal IPPC adoption vote is scheduled for Month 36 (2029-10-12) gate deadline.

**Responsible Body/Role:** Containment Protocol Authority (with IPPC Secretariat)

**Suggested Timeframe:** Month 12 (2027-10-12) to Month 18 (2028-04-12 to 2028-04-12)

**Key Outputs/Deliverables:**

- Final SALB Containment Protocol published
- IPPC adoption vote scheduled for Month 36 (2029-10-12)

**Dependencies:**

- All stakeholder feedback integrated
- Bilateral MoUs confirm country support for protocol
- IPPC working group completes harmonization review

### 33. Programme Director, with Workstream Coordinator for Containment, develops the detailed Phase 1 (Months 0-36, 2026-10-12 to 2029-10-12) delivery plan. Plan includes protocol-adoption timeline (MoUs, IPPC vote, national embedding), surveillance system setup (inspector training, laboratory capacity, detection targets), incursion-response doctrine (eradication-first with prefunded compensation fund USD 0.5B), and red-team drill schedule (Months 18-36 = 2028-04-12 to 2029-10-12).

**Responsible Body/Role:** PMO (Programme Director and Workstream Coordinators)

**Suggested Timeframe:** Month 3 (2027-01-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Phase 1 Delivery Plan (published)
- Workstream milestones and monthly delivery targets

**Dependencies:**

- PMO fully staffed
- Containment Protocol Authority established
- Surveillance and Incursion Response architectural decisions confirmed

### 34. PMO Workstream Coordinator for Surveillance (Surveillance Sensing Architecture) designs the tiered surveillance network to detect SALB incursions: Tier 1 (primary producers: monthly field scouting + monthly laboratory confirmation, detection target <3 months); Tier 2 (secondary regions: quarterly scouting + portable diagnostics, target <6 months); Tier 3 (smallholder sentinels: paid reporting system, regional expert verification within 2 weeks).

**Responsible Body/Role:** PMO (Surveillance Workstream Coordinator, recruited by Month 6 = 2027-04-12)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Surveillance Architecture Design (published)
- Detection protocols and response-trigger criteria documented

**Dependencies:**

- Containment Protocol Authority established (to set compliance inspection context)
- PMO workstreams staffed

### 35. PMO (in coordination with Containment Authority and national plant-protection agencies) establishes and funds regional diagnostic laboratories in at least 10 producing-region locations (sample distribution: 3-4 in Southeast Asia, 2-3 in Brazil, 1-2 in West Africa, 1-2 in USA/Mexico). Labs conduct molecular PCR confirmation of SALB incursions. First labs operational by Month 24 (2028-10-12); full network by Month 36 (2029-10-12).

**Responsible Body/Role:** PMO (Surveillance Workstream Coordinator, with Containment Authority support)

**Suggested Timeframe:** Month 9 (2027-07-12) to Month 24 (2028-10-12 to 2028-10-12)

**Key Outputs/Deliverables:**

- At least 10 regional diagnostic laboratories established
- Lab protocols and capacity documented
- Laboratory network operational by Month 24 (2028-10-12)

**Dependencies:**

- Surveillance Architecture finalized
- Budget allocated for lab establishment and training (estimated USD 50-100M over 10 years)

### 36. PMO establishes the Incursion Response Playbook, pre-agreeing the operational and financial doctrine for responding to confirmed SALB detections. Doctrine is eradication-first: infected plantings are destroyed within a defined buffer zone, and compensation is paid to affected growers from a prefunded USD 0.5 billion compensation fund. Playbook includes roles (who authorizes destruction, who compensates, who communicates), timelines (response within 2 weeks of confirmed detection), and community/farmer notification procedures.

**Responsible Body/Role:** PMO (Programme Director and Surveillance/Incursion Response Coordinators, with Steering Council input)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Incursion Response Playbook (published)
- Eradication protocols and compensation procedures
- Response-trigger decision matrix

**Dependencies:**

- Steering Council approved incursion-response doctrine (eradication-first)
- Compensation fund amount confirmed (USD 0.5B estimate)

### 37. PMO Workstream Coordinator for Breeding (Resistance Breeding Pathway) hires the Breeding Programme Director (senior Hevea breeder from national research institute or CGIAR center) by Month 3 (2027-01-12). Breeding Director establishes breeding objectives: cultivar yield ≥90% of elite clones, ≥3 stacked resistance sources, lesion size ≤5mm, defoliation ≤20%, durability testing at 10x field-typical inoculum load.

**Responsible Body/Role:** PMO (Breeding Workstream Coordinator, with Steering Council approval of Director hire)

**Suggested Timeframe:** Month 3 (2027-01-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Breeding Programme Director hired
- Breeding objectives and cultivar-selection criteria published and pre-registered with Technical Advisory Group

**Dependencies:**

- PMO staffing authorized by Steering Council
- Budget allocated for breeding programme (estimated USD 0.4B for 25 years)

### 38. Breeding Programme Director, with regional Deputy Directors for Brazil, Thailand/Southeast Asia, and Cote d'Ivoire/West Africa (hired by Month 9, 2027-07-12), establishes standardized multi-site trial protocols and prepares 4 breeding stations (Brazil, Thailand, Malaysia/Indonesia, Côte d'Ivoire) for planting. Each site is responsible for independent trials using the same protocol, with identical disease-rating and yield-measurement standards.

**Responsible Body/Role:** Breeding Programme Director (with Regional Deputy Directors)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Breeding trial protocols finalized and published
- 4 breeding stations ready for planting by Month 12 (2027-10-12)
- Site managers and data-collection teams in place

**Dependencies:**

- Breeding Programme Director and Regional Deputies hired
- ABS agreements with Brazil executed (to enable germplasm transfer)
- Trial sites confirmed and prepared

### 39. Breeding Programme Director plants trials at all 4 sites (Brazil, Thailand, Malaysia/Indonesia, Côte d'Ivoire) by Month 12 (2027-10-12). Trials cross multiple Amazonian Hevea resistance sources into high-yield Asian clones, using polygenic marker-assisted and genomic selection. First data (nursery observations) available by Month 24 (2028-10-12); first 3-year field data by Month 48 (2030-10-12); full 6-year data by Month 84 (2033-10-12).

**Responsible Body/Role:** Breeding Programme Director (with site managers at 4 locations)

**Suggested Timeframe:** Month 12 (2027-10-12) - planting target

**Key Outputs/Deliverables:**

- Trials planted at all 4 sites by Month 12 (2027-10-12)
- Nursery data compilation begins Month 24 (2028-10-12)
- First full-cycle field data available by Month 84 (2033-10-12) for Year 7 gate

**Dependencies:**

- Trial sites prepared and staffed
- ABS agreements enable germplasm transfer
- Breeding protocols finalized

### 40. Breeding Programme Director establishes a breeding data repository with redundant backup and version control. Data includes yield measurements, disease ratings, resistance-gene validation (molecular), multi-site comparisons, and cultivar-selection documentation. Repository is accessible to the independent auditor and Compliance & Ethics Committee for audits. Repository operational by Month 12 (2027-10-12).

**Responsible Body/Role:** Breeding Programme Director (with Data Steward support)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Breeding data repository established with 50-year preservation capability
- Access protocols defined for auditors and compliance teams

**Dependencies:**

- PMO data infrastructure established
- Data Steward role assigned (Programme-wide)

### 41. PMO Workstream Coordinator for ABS (led by Compliance & Ethics Committee ABS Specialist) negotiates bilateral access-and-benefit-sharing agreements with Brazil's national competent authority (CGen) and at least 3 major indigenous or traditional-community groupings in the Amazon. Agreements specify: collection protocols for Hevea germplasm, downstream partner transfers, benefit-sharing terms (USD 1-5 per hectare, estimate, paid on commercial cultivar deployment), royalty-free seed for smallholders, and open-access genomic sequences for non-commercial research.

**Responsible Body/Role:** ABS Specialist (Compliance & Ethics Committee) with PMO support

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Bilateral ABS agreement with Brazil CGen executed
- ABS agreements with at least 3 Amazonian community groupings signed
- Benefit-sharing payment schedule established (first payment trigger at cultivar deployment)

**Dependencies:**

- ABS legal counsel hired (by Month 1, 2026-11-12)
- Community consultation completed
- Budget allocated for ABS agreements and benefit-sharing (USD 15M estimate)

### 42. ABS Specialist and Compliance & Ethics Committee establish a community-governed germplasm and data trust, with seats for indigenous and traditional-community representatives. Trust co-owns resistance discoveries and participates in benefit-sharing decisions. Trust bylaws and operational procedures published by Month 12 (2027-10-12).

**Responsible Body/Role:** ABS Specialist (Compliance & Ethics Committee)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Community-Governed Germplasm and Data Trust established
- Trust governance bylaws published
- Community representatives confirmed and trained

**Dependencies:**

- ABS agreements executed
- Community consultation process completed

### 43. PMO Programme Director (with Steering Council approval) hires a Data Steward responsible for all programme data governance across 25 years. Data Steward publishes a programme Data Governance Framework by Month 6 (2027-04-12), clarifying ownership, access, publication timing and IP rules for: pre-competitive data (released openly within 12 months), commercial data (shared under confidentiality agreements, publication 12 months post-gate), and benefit-sharing data (published annually).

**Responsible Body/Role:** Programme Director (recruiting Data Steward by Month 1, 2026-11-12)

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Data Steward position established and filled
- Programme Data Governance Framework published (Month 6, 2027-04-12)

**Dependencies:**

- Steering Council approved data governance as a governance priority

### 44. Data Steward (Programme-wide) implements a secure digital data repository with 50-year preservation capability, version control, redundant backup, and access protocols for auditors and compliance teams. Repository is operational by Month 6-12 (2027-04-12 to 2027-10-12).

**Responsible Body/Role:** Data Steward

**Suggested Timeframe:** Month 3 (2027-01-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Digital data repository operational with 50-year preservation
- Access protocols documented and auditor/compliance-team access granted

**Dependencies:**

- Data Steward hired
- Data Governance Framework published

### 45. PMO Workstream Coordinator for Alternative Crops (Guayule and Russian Dandelion) designs multi-region pilot farms and processing demonstrations. Pilot farms: Guayule 100-500 ha in Arizona/New Mexico/Coahuila, dandelion 100-300 ha in Germany/Netherlands/Belgium. Pilot processing plants: Guayule 2,000-5,000 t/year extraction facility; dandelion 1,000-3,000 t/year facility. Siting studies complete by Month 6-9 (2027-04-12 to 2027-07-12); site preparation and farm planting Months 6-12 (2027-04-12 to 2027-10-12).

**Responsible Body/Role:** PMO (Alternative Crops Workstream Coordinator, recruited by Month 6 = 2027-04-12)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 24 (2028-10-12 to 2028-10-12)

**Key Outputs/Deliverables:**

- Alternative crop siting study completed
- Pilot farm sites prepared and first plantings by Month 12 (2027-10-12)
- Pilot processing plants commissioned by Month 24 (2028-10-12)

**Dependencies:**

- Alternative Crop Portfolio Breadth decision confirmed (Guayule + Russian dandelion)
- Climate-risk siting analysis completed
- Budget allocated for pilots and processing (USD 0.2B estimate)

### 46. PMO Alternative Crops Workstream runs parallel tire-performance qualification trials of Guayule and dandelion rubber at independent test laboratories, Months 12-48 (2027-10-12 to 2030-10-12). Trials evaluate tread wear, durability, grip and other OEM specifications. Results are shared with tire makers to support OEM offtake agreements.

**Responsible Body/Role:** PMO (Alternative Crops Workstream Coordinator, with OEM engagement team)

**Suggested Timeframe:** Month 12 (2027-10-12) to Month 48 (2030-10-12 to 2030-10-12)

**Key Outputs/Deliverables:**

- Tire-qualification trial protocols established
- Test results (tread wear, durability, grip, quality variance) published by Month 48 (2030-10-12)

**Dependencies:**

- Pilot processing plants operational by Month 24 (2028-10-12)
- OEM engagement initiated (Month 3, 2027-01-12)

### 47. PMO Programme Director (with Steering Council authorization) initiates direct engagement with the top 10 tire makers by Month 3 (2027-01-12). Steering Council establishes an OEM Steering Committee that meets quarterly. Goal: secure non-binding letters of intent for offtake trials by Month 12 (2027-10-12).

**Responsible Body/Role:** Programme Director (with Steering Council OEM representatives and OEM Engagement Lead)

**Suggested Timeframe:** Month 3 (2027-01-12) - engagement initiated; Month 12 (2027-10-12) - letters of intent target

**Key Outputs/Deliverables:**

- OEM Steering Committee established and charter published
- Letters of intent from at least 8 of top-10 OEMs for offtake trials (by Month 12, 2027-10-12)

**Dependencies:**

- Steering Council authorized OEM engagement
- Alternative crop portfolio strategy confirmed

### 48. PMO (with OEM Steering Committee input) structures long-term offtake agreements using tiered purchase-option contracts. Tier 1: OEMs pay 1-2% (estimate) annual reservation fee for priority access to alternative-rubber volumes. Tier 2: optional purchase at price formula indexed to Hevea benchmark + 10-15% premium (estimate), with quality-gate thresholds. Tier 3: shared quality-failure risk (50% producer, 50% OEM). Contracts negotiated and signed Months 48-60 (2030-10-12 to 2031-10-12), based on pilot-processing and tire-qualification results.

**Responsible Body/Role:** PMO (OEM Engagement Lead, with Alternative Crops Workstream Coordinator)

**Suggested Timeframe:** Month 48 (2030-10-12) to Month 60 (2031-10-12 to 2031-10-12)

**Key Outputs/Deliverables:**

- Tiered purchase-option contracts drafted
- Contracts signed with at least 8 OEMs by Month 60 (2031-10-12)

**Dependencies:**

- Pilot processing and tire-qualification results available by Month 48 (2030-10-12)
- OEM letters of intent secured

### 49. PMO (Alternative Crops Workstream) monitors alternative-rubber cost and quality performance against pre-registered KPI waypoints: Month 36 (2029-10-12) feedstock yield and extraction efficiency; Month 48 (2030-10-12) feedstock cost (Guayule ≤USD 1.20/kg dry matter, dandelion ≤USD 1.00/kg) and extraction yield (≥85% Guayule, ≥80% dandelion); Month 60 (2031-10-12) processing cost (≤USD 2.50/kg) and quality variance (±10%). If targets are missed by Month 60 (2031-10-12), trigger portfolio decision: increased processing-innovation capital or redirect funds to resistant-Hevea breeding.

**Responsible Body/Role:** PMO (Alternative Crops Workstream Coordinator and Technical Advisory Group)

**Suggested Timeframe:** Months 36, 48, 60 (2029-10-12, 2030-10-12, 2031-10-12) - checkpoint milestones

**Key Outputs/Deliverables:**

- KPI monitoring dashboard (quarterly updates)
- Cost and quality assessment reports at Months 36, 48, 60 (2029-10-12, 2030-10-12, 2031-10-12)
- Portfolio decision (Month 60 = 2031-10-12) to continue or re-scope alternative crops

**Dependencies:**

- Pre-registered KPI definitions finalized
- Pilot plants operational and producing data by Month 24 (2028-10-12)

### 50. PMO Programme Director establishes the Smallholder Transition Finance and Extension Corps as a separate, locally-owned delivery system. Recruits 500 lead extension agents across the 5 major producing countries (100-200 agents per country) by Month 12 (2027-10-12). Each agent serves 200-500 eligible smallholders. Establishes 50-100 certified small-scale nurseries per major country for clean-plant propagation. Creates income-bridging finance programme: concessional replant loans + income-support payments during immature period (6-10 years).

**Responsible Body/Role:** PMO (Smallholder Delivery Workstream Coordinator, recruited by Month 6 = 2027-04-12)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 24 (2028-10-12 to 2028-10-12)

**Key Outputs/Deliverables:**

- 500 lead extension agents trained and deployed by Month 12 (2027-10-12)
- At least 250 certified nurseries established (50+ per major country)
- Smallholder Transition Finance programme design (loans, income support, repayment terms)
- Mobile-based extension platform operational

**Dependencies:**

- PMO staffing complete
- Budget allocated for extension corps (USD 400M protected 25-year stream)
- Replant finance budget available (USD 6.75B for 45% uptake)

### 51. PMO (Smallholder Delivery Workstream) launches clean-plant network certification and inspection programme. Sets standards for nursery lot-size, isolation distance, inspected-planting protocols, and disease-free certification. Coordinates with Containment Protocol Authority to align inspection frequencies (target: 100,000 inspected lots/year by Month 12, 2027-10-12) and compliance certificates.

**Responsible Body/Role:** PMO (Smallholder Delivery Workstream) with Containment Protocol Authority

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 18 (2028-04-12 to 2028-04-12)

**Key Outputs/Deliverables:**

- Clean-plant network certification standards published
- Nursery audit and lot-inspection protocols defined
- 100,000+ inspected lots/year achieved by Month 12 (2027-10-12)

**Dependencies:**

- Containment Protocol Authority compliance-inspection SOP finalized
- 100+ compliance inspectors trained and deployed

### 52. PMO (Smallholder Delivery Workstream) designs and operationalizes the income-bridging finance instrument. Offers concessional replant loans through national agricultural banks at preferential rates, paired with clean-plant nursery vouchers and extension visits. Repayment begins after first tapping (6-10 years post-replanting). For poorest smallholders, income-support payments funded by programme levy or reserve. Default and arrears risks managed through group-guarantee mechanisms and technical-support incentives.

**Responsible Body/Role:** PMO (Smallholder Delivery Workstream and Finance Manager)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 18 (2028-04-12 to 2028-04-12)

**Key Outputs/Deliverables:**

- Smallholder Transition Finance operational manual published
- Loan and income-support disbursement processes live by Month 18 (2028-04-12)
- First tranche of replant finance approved and disbursed to pilot smallholder groups

**Dependencies:**

- National agricultural banks engaged and committed to participate
- Budget for replant finance approved (USD 6.75B for 45% uptake)

### 53. PMO Programme Director establishes quarterly KPI-tracking meetings, beginning Month 12 (2027-10-12). Workstream Coordinators report on milestones, risk status, and gate-readiness against pre-registered KPI definitions. Dashboard is compiled by PMO Finance Manager and presented to Steering Council and Compliance & Ethics Committee.

**Responsible Body/Role:** PMO Finance Manager and Programme Director

**Suggested Timeframe:** Monthly reviews within PMO; quarterly briefings to Steering Council starting Month 12 (2027-10-12)

**Key Outputs/Deliverables:**

- Monthly KPI tracking dashboard (internal PMO)
- Quarterly KPI summary for Steering Council (published)

**Dependencies:**

- PMO staffing complete
- Budget and KPI tracking systems operational

### 54. PMO and Containment Protocol Authority, in coordination with national plant-protection agencies, plan and execute red-team drills to test the SALB protocol's enforcement effectiveness. Red-team drills simulate unauthorized movement of potentially contaminated material through nurseries, borders and ports, testing detection speed and response procedures. Drills conducted Months 18-36 (2028-04-12 to 2029-10-12) in at least 3 producing countries; results published and inform Month 36 (2029-10-12) gate assessment.

**Responsible Body/Role:** Containment Protocol Authority (Compliance Inspection team) with PMO and national agencies

**Suggested Timeframe:** Months 18-36 (2028-04-12 to 2029-10-12) - at least 3 drills, one per major region

**Key Outputs/Deliverables:**

- Red-team drill plans and protocols (published Months 12-18 = 2027-10-12 to 2028-04-12)
- Red-team drill results and compliance findings (Months 18-36 = 2028-04-12 to 2029-10-12)
- Corrective action reports for any detected enforcement gaps

**Dependencies:**

- Compliance-inspection network established and trained
- Nursery certification systems operational
- Surveillance systems ready for detection testing

### 55. Independent Auditor, 6 months before Month 36 (2029-10-12) gate (by Month 30, 2029-04-12), requests gate-readiness submission from PMO. PMO compiles: IPPC adoption vote status, producer-nation binding regulatory embedding status, inspector deployment and inspection data (100,000+ lots), red-team drill results (≥95% detection accuracy), surveillance network operational status, no unmanaged SALB incursions. Auditor conducts field visits and database audits Months 30-36 (2029-04-12 to 2029-10-12).

**Responsible Body/Role:** PMO (with input from all workstreams) and Independent Auditor

**Suggested Timeframe:** Month 30 (2029-04-12) - PMO submits gate-readiness report; Months 30-36 (2029-04-12 to 2029-10-12) - Auditor conducts audits

**Key Outputs/Deliverables:**

- Gate-readiness report submitted to Independent Auditor (Month 30, 2029-04-12)
- Auditor field audits and data verification Months 30-36 (2029-04-12 to 2029-10-12)
- Auditor gate-closure report issued (by Month 35.5, 2029-09-27, estimate)

**Dependencies:**

- Pre-registered audit scope for Month 36 (2029-10-12) gate finalized (by Month 6, 2027-04-12)
- All Phase 1 activities on track and documented

### 56. Independent Auditor issues Month 36 (2029-10-12) gate-closure verdict 30 days before gate date (by Month 35.5, 2029-09-27 estimate). Verdict states: IPPC adoption vote held and passed; binding national embedding in at least 3 of top-5 producers confirmed; 100+ inspectors deployed and active; 100,000+ nursery lots inspected; red-team drills ≥95% detection accuracy; zero unmanaged SALB incursions documented. Verdict is PASS, CONDITIONAL, or FAIL, with confidence level and any dissenting findings.

**Responsible Body/Role:** Independent Auditor

**Suggested Timeframe:** Month 35.5 (2029-09-27) - verdict issued (30 days before gate)

**Key Outputs/Deliverables:**

- Month 36 (2029-10-12) gate-closure verdict (published within 30 days of audit completion)

**Dependencies:**

- Auditor field audits and data verification complete

### 57. Steering Council, upon receipt of Independent Auditor verdict on Month 36 (2029-10-12) gate (by Month 35.5, 2029-09-27), reviews verdict and authorizes Year 3 tranche release (USD 7.0B). If verdict is CONDITIONAL (partial gate achievement), releases minimum 80% of planned tranche (USD 5.6B). If FAIL, withholds and convenes Steering Council emergency meeting to determine remedial action. Tranche is disbursed within 45 days of gate passage (by Month 36.75, 2029-11-04 estimate).

**Responsible Body/Role:** Steering Council

**Suggested Timeframe:** Month 36 (2029-10-12) - gate deadline; tranche released within 45 days (by Month 36.75 = 2029-11-04)

**Key Outputs/Deliverables:**

- Steering Council decision minute on gate passage and tranche release
- Year 3 tranche (USD 7.0B or minimum 80%) disbursed by Month 36.75 (2029-11-04)

**Dependencies:**

- Independent Auditor gate verdict received
- Steering Council meeting convened within 5 days of verdict

### 58. Steering Council, during Phase 2 (Months 36-84, 2029-10-12 to 2033-10-12), oversees continued execution of all four pillars: containment protocol enforcement (quarterly compliance reporting), breeding-trial data compilation (interim reports at Months 48, 72 = 2030-10-12, 2032-10-12), alternative-crop processing pilots and tire qualifications, and smallholder adoption (quarterly extension and nursery metrics). Escalations from PMO are reviewed monthly; risk register is updated quarterly.

**Responsible Body/Role:** Steering Council (with PMO input)

**Suggested Timeframe:** Months 36-84 (2029-10-12 to 2033-10-12) - ongoing governance

**Key Outputs/Deliverables:**

- Quarterly steering updates to Council (protocol, breeding, alternatives, smallholder status)
- Risk register updates and mitigation tracking
- Decision minutes on escalations and strategic adjustments

**Dependencies:**

- Phase 1 successfully completed (Month 36 = 2029-10-12 gate passed)
- Year 3 tranche (USD 7.0B) being deployed

### 59. Breeding Programme Director, at Month 48 (2030-10-12), compiles interim breeding-trial data and conducts a formal yield-penalty assessment. If yield penalty (cultivar yield minus elite-clone yield) exceeds 15% (i.e., cultivar yield <85% of elite), escalate to Steering Council for pathway decision: continue conventional breeding, or initiate crown-budding fast-track (fallback option, USD 0.25B estimate, fits within unallocated budget). Decision made by Month 54 (2031-04-12).

**Responsible Body/Role:** Breeding Programme Director (with Steering Council and Technical Advisory Group consultation)

**Suggested Timeframe:** Month 48 (2030-10-12) - interim data review; Month 54 (2031-04-12) - pathway decision

**Key Outputs/Deliverables:**

- Interim breeding-trial report at Month 48 (2030-10-12)
- Yield-penalty assessment and pathway decision (if needed) by Month 54 (2031-04-12)

**Dependencies:**

- 3-year field trial data available from all 4 sites

### 60. Breeding Programme Director, if pathway decision is to proceed with crown-budding fast-track (triggered by yield penalties >15% at Month 48 = 2030-10-12), initiates a separate, time-compressed crown-budding programme. Crown-budding uses existing elite clones with grafted resistant canopies to deliver field protection years before fully bred cultivars are ready. Crown-budding programme adds USD 0.25B budget (estimate, fits within unallocated balance) and could compress Year 7 cultivar timeline by 2-3 years. Decision and authorization by Steering Council by Month 54 (2031-04-12).

**Responsible Body/Role:** Breeding Programme Director and Steering Council

**Suggested Timeframe:** Month 54 (2031-04-12) - decision point if triggered by Month 48 (2030-10-12) yield-penalty assessment

**Key Outputs/Deliverables:**

- Crown-budding programme design and budget (if initiated)
- Steering Council decision minute authorizing fallback pathway

**Dependencies:**

- Month 48 (2030-10-12) interim yield-penalty assessment shows deficit >15%

### 61. Breeding Programme Director initiates second-generation cultivar breeding by Month 60 (2031-10-12) using different resistance sources than the first-generation cultivars targeted for Year 7 release. Second-generation cultivars will be ready by Month 120 (2036-10-12) if first-generation cultivars show early durability breakdown post-release.

**Responsible Body/Role:** Breeding Programme Director

**Suggested Timeframe:** Month 60 (2031-10-12) - initiation; Month 120 (2036-10-12) - target readiness

**Key Outputs/Deliverables:**

- Second-generation breeding programme launched (separate trial locations, different resistance sources)

**Dependencies:**

- First-generation trials progressing toward Year 7 gate

### 62. PMO (Alternative Crops Workstream), at Month 60 (2031-10-12), makes portfolio decision based on cost and quality KPI assessment: cost targets (feedstock and processing) achieved or only modestly missed → commit wave 1 commercial-plant capex (USD 1.6B, 4 Guayule + 4 dandelion plants). Targets significantly missed → redirect capital to processing-innovation R&D or accelerate resistant-Hevea breeding allocation. Decision documented and approved by Steering Council by Month 66 (2032-04-12).

**Responsible Body/Role:** PMO (Alternative Crops Workstream) with Steering Council

**Suggested Timeframe:** Month 60 (2031-10-12) - assessment; Month 66 (2032-04-12) - decision

**Key Outputs/Deliverables:**

- Alternative-crop cost and quality assessment report (Month 60 = 2031-10-12)
- Portfolio decision documentation and Steering Council approval (by Month 66 = 2032-04-12)

**Dependencies:**

- Pilot processing plants and tire-qualification trials completed and documented

### 63. Breeding Programme Director, at Month 72 (2032-10-12), compiles final cultivar-selection data from all 4 trial sites (6-year field data now available from Month 12 = 2027-10-12 plantings in 2027). Assesses yield against elite clones, resistance stacking, durability signals, and multi-site consistency. Selects final cultivar candidates for Year 7 gate release. Cultivar-selection documentation is submitted to Independent Auditor by Month 78 (2033-04-12) (6 months before Month 84 = 2033-10-12 gate).

**Responsible Body/Role:** Breeding Programme Director (with Technical Advisory Group and Compliance & Ethics Committee data-integrity oversight)

**Suggested Timeframe:** Month 72 (2032-10-12) - cultivar selection completed; Month 78 (2033-04-12) - evidence submitted to auditor

**Key Outputs/Deliverables:**

- Cultivar selection report at Month 72 (2032-10-12)
- Gate-readiness evidence package submitted to auditor (Month 78, 2033-04-12)
- All breeding-trial data validated for auditor review

**Dependencies:**

- 6-year field trial data available from all 4 sites

### 64. Independent Auditor, 6 months before Month 84 (2033-10-12) gate (by Month 78, 2033-04-12), receives gate-readiness submission from PMO. PMO compiles: cultivar yield data (≥90% of elite = pass), ≥3 stacked independent resistance sources confirmed at 5+ trial sites, lesion size and defoliation within thresholds, durability evidence from sentinel plantings and high-inoculum testing. Auditor conducts field audits of all 4 breeding sites and database verification Months 78-84 (2033-04-12 to 2033-10-12).

**Responsible Body/Role:** PMO (Breeding Workstream) and Independent Auditor

**Suggested Timeframe:** Month 78 (2033-04-12) - submission; Months 78-84 (2033-04-12 to 2033-10-12) - audits

**Key Outputs/Deliverables:**

- Year 7 gate-readiness report submitted to auditor (Month 78 = 2033-04-12)
- Auditor field audits and data verification at 4 breeding sites (Months 78-84 = 2033-04-12 to 2033-10-12)
- Auditor gate-closure report issued (by Month 83.5, 2033-09-27 estimate)

**Dependencies:**

- Cultivar selection completed and documented (Month 72 = 2032-10-12)
- Breeding-trial data repository fully documented and accessible

### 65. Independent Auditor issues Month 84 (2033-10-12) gate-closure verdict 30 days before gate date (by Month 83.5, 2033-09-27 estimate). Verdict assesses: cultivar yield ≥90% of elite clones (PASS), 90-95% (CONDITIONAL), <90% (FAIL); ≥3 independent resistance sources stacked and confirmed; lesion size ≤5mm and defoliation ≤20%; durability testing evidence from sentinel plantings. Verdict is PASS, CONDITIONAL, or FAIL.

**Responsible Body/Role:** Independent Auditor

**Suggested Timeframe:** Month 83.5 (2033-09-27) - verdict issued

**Key Outputs/Deliverables:**

- Month 84 (2033-10-12) gate-closure verdict (published)

**Dependencies:**

- Auditor field audits and data verification complete

### 66. Steering Council, upon receipt of Independent Auditor verdict on Month 84 (2033-10-12) gate (by Month 83.5, 2033-09-27), reviews verdict and authorizes Year 7 tranche release (USD 6.5B). If verdict is CONDITIONAL, releases minimum 80% (USD 5.2B). If FAIL, escalates to Adjudication Panel for expert mediation or withhold tranche pending remedial breeding action. Tranche is disbursed within 45 days of gate passage (by Month 84.75, 2033-11-04 estimate).

**Responsible Body/Role:** Steering Council

**Suggested Timeframe:** Month 84 (2033-10-12) - gate deadline; tranche released within 45 days (by Month 84.75 = 2033-11-04)

**Key Outputs/Deliverables:**

- Steering Council decision minute on Year 7 gate passage
- Year 7 tranche (USD 6.5B or minimum 80%) disbursed by Month 84.75 (2033-11-04)

**Dependencies:**

- Independent Auditor gate verdict received
- Steering Council meeting convened and voted on gate passage

### 67. PMO (Smallholder Delivery Workstream), at Month 84 (2033-10-12), assesses smallholder adoption progress against waypoint targets: at least 30% of eligible smallholders enrolled in clean-plant/extension network (proposed threshold). Conduct farmer surveys to confirm uptake rates, clean-plant usage, and income-bridging-finance utilization. If enrollment is below 30%, trigger stop/re-scope decision by Month 90 (2034-04-12): increase extension and finance resources, or reduce Year 7-12 smallholder acreage targets.

**Responsible Body/Role:** PMO (Smallholder Delivery Workstream)

**Suggested Timeframe:** Month 84 (2033-10-12) - assessment; Month 90 (2034-04-12) - decision

**Key Outputs/Deliverables:**

- Smallholder adoption assessment report (Month 84 = 2033-10-12)
- Decision on smallholder uptake targets and resource allocation (by Month 90 = 2034-04-12)

**Dependencies:**

- Extension corps and nurseries operational since Month 12 (2027-10-12)
- Replant finance disbursement ongoing

### 68. PMO and Steering Council, if Month 84 (2033-10-12) breeding gate is PASS or CONDITIONAL, authorize the release of resistant cultivars to seed producers and nurseries. Certified clones are multiplied at licensed nurseries and made available to smallholders through the clean-plant network. Cultivar distribution accelerates Months 90-120 (2034-04-12 to 2036-10-12), targeting 40%+ smallholder-area replanting by Month 144 (2038-10-12).

**Responsible Body/Role:** PMO (Breeding and Smallholder Delivery Workstreams) with Steering Council authorization

**Suggested Timeframe:** Month 84 (2033-10-12) - cultivar release authorized; Months 90-120 (2034-04-12 to 2036-10-12) - multiplication and distribution

**Key Outputs/Deliverables:**

- Certified cultivar clones released to seed producers (Month 90, 2034-04-12)
- Nurseries begin clone multiplication and distribution to smallholders

**Dependencies:**

- Month 84 (2033-10-12) breeding gate passed (PASS or CONDITIONAL)
- Nursery capacity and clean-plant-network infrastructure in place

### 69. PMO (Alternative Crops Workstream), between Months 84-120 (2033-10-12 to 2036-10-12), executes wave 1 commercial-plant construction (if Month 60 = 2031-10-12 portfolio decision was to proceed). Wave 1 includes 4 commercial plants: 2 Guayule + 2 dandelion, each 5,000 t/year nameplate. Final investment decisions (FIDs) at Month 72 (2032-10-12); construction Months 84-108 (2033-10-12 to 2035-10-12); commissioning and ramp-up Months 96-120 (2034-10-12 to 2036-10-12).

**Responsible Body/Role:** PMO (Alternative Crops Workstream) with OEM partners and processing contractors

**Suggested Timeframe:** Month 72 (2032-10-12) - FID; Months 84-108 (2033-10-12 to 2035-10-12) - construction; Months 96-120 (2034-10-12 to 2036-10-12) - commissioning

**Key Outputs/Deliverables:**

- Wave 1 plant FID and financing closed (Month 72 = 2032-10-12)
- Plant construction contracts awarded (Months 72-84 = 2032-10-12 to 2033-10-12)
- First plant commissioned (Month 96-108 = 2034-10-12 to 2035-10-12)
- Wave 1 plants at full capacity by Month 120 (2036-10-12) producing 16,000 t/year

**Dependencies:**

- Month 60 (2031-10-12) portfolio decision to proceed with plants
- OEM offtake agreements signed (Months 48-60 = 2030-10-12 to 2031-10-12)
- Pilot processing results show viable cost and quality

### 70. Compliance & Ethics Committee, throughout Months 0-120 (2026-10-12 to 2036-10-12), conducts quarterly compliance audits and investigations. Audits include: breeding-trial data integrity at all 4 sites (annual external validators), benefit-sharing compliance (community payments tracked and verified), smallholder-finance fraud detection (2,000+ farmer audits annually per major country), alternative-crop environmental safeguards (land-tenure verification, water-stress monitoring), and anti-corruption whistleblower investigations.

**Responsible Body/Role:** Compliance & Ethics Committee (all members)

**Suggested Timeframe:** Ongoing quarterly; annual in-depth audits; investigations triggered by reports

**Key Outputs/Deliverables:**

- Quarterly compliance summary reports to Steering Council
- Annual comprehensive audit report (published)
- Investigation closures and remedial-action tracking

**Dependencies:**

- Compliance & Ethics Committee fully staffed
- Code of Conduct and anti-corruption policies active

### 71. Independent Auditor, 6 months before Month 144 (2038-10-12) gate (by Month 138, 2038-04-12), receives gate-readiness submission from PMO. PMO compiles: alternative-rubber delivered cost (target <30% above Hevea benchmark), processing volumes (16,000 t/year from wave 1 plants), quality consistency, OEM offtake contracts in place, smallholder adoption levels (target ≥40% of eligible area), resistant-cultivar acreage deployed and early durability performance. Auditor conducts field audits Months 138-144 (2038-04-12 to 2038-10-12).

**Responsible Body/Role:** PMO (all workstreams) and Independent Auditor

**Suggested Timeframe:** Month 138 (2038-04-12) - submission; Months 138-144 (2038-04-12 to 2038-10-12) - audits

**Key Outputs/Deliverables:**

- Year 12 gate-readiness report submitted (Month 138 = 2038-04-12)
- Auditor gate-closure report (by Month 143.5, 2038-09-27 estimate)

**Dependencies:**

- All Phase 2 and Phase 3 activities substantially complete

### 72. Independent Auditor issues Month 144 (2038-10-12) gate-closure verdict 30 days before gate date (by Month 143.5, 2038-09-27 estimate). Verdict assesses: alternative-rubber delivered cost <30% above Hevea (PASS), 30-35% (CONDITIONAL), ≥35% (FAIL); wave 1 plants operational and producing at design volumes; OEM offtake active; smallholder adoption ≥40% of eligible area; resistant-cultivar acreage and early durability performance acceptable.

**Responsible Body/Role:** Independent Auditor

**Suggested Timeframe:** Month 143.5 (2038-09-27) - verdict issued

**Key Outputs/Deliverables:**

- Month 144 (2038-10-12) gate-closure verdict (published)

**Dependencies:**

- Auditor field audits complete

### 73. Steering Council, upon receipt of Independent Auditor verdict on Month 144 (2038-10-12) gate (by Month 143.5, 2038-09-27), reviews verdict and authorizes Year 12 tranche release (USD 4.5B). If verdict is CONDITIONAL, releases minimum 80% (USD 3.6B). If FAIL, considers contingent-facility activation or deferred capital reallocation. Tranche is disbursed within 45 days (by Month 144.75, 2038-11-04 estimate).

**Responsible Body/Role:** Steering Council

**Suggested Timeframe:** Month 144 (2038-10-12) - gate deadline; tranche released within 45 days (by Month 144.75 = 2038-11-04)

**Key Outputs/Deliverables:**

- Steering Council decision on Year 12 gate passage
- Year 12 tranche (USD 4.5B or minimum 80%) disbursed by Month 144.75 (2038-11-04)

**Dependencies:**

- Independent Auditor verdict received

### 74. Steering Council, if Month 144 (2038-10-12) gate is PASS or CONDITIONAL, authorizes wave 2 commercial-plant development (Months 156-180, 2039-10-12 to 2041-10-12). Wave 2 adds 4 more plants (2 Guayule, 2 dandelion). FIDs scheduled for Month 144 (2038-10-12); construction Months 156-180 (2039-10-12 to 2041-10-12); commissioning Months 180-192 (2041-10-12 to 2042-10-12); target 32,000 t/year total volume by Month 192 (2042-10-12).

**Responsible Body/Role:** Steering Council and PMO (Alternative Crops Workstream)

**Suggested Timeframe:** Month 144 (2038-10-12) - FID approval; Months 156-180 (2039-10-12 to 2041-10-12) - construction; Months 180-192 (2041-10-12 to 2042-10-12) - commissioning

**Key Outputs/Deliverables:**

- Wave 2 plant FID and financing authorized and closed
- Wave 2 plants commissioned by Month 192 (2042-10-12)
- Total alternative-rubber capacity 32,000 t/year by Month 192 (2042-10-12)

**Dependencies:**

- Month 144 (2038-10-12) gate PASS or CONDITIONAL
- Wave 1 plants operational and profitable (or within acceptable loss tolerance)

### 75. Breeding Programme Director, from Month 84 onward (2033-10-12 onward), establishes and monitors post-release resistance durability. Sentinel plantings of released cultivars are planted in high-SALB-inoculum zones and exposed to natural and artificial pathogen variants. Quarterly durability monitoring from Month 84-216 (2033-10-12 to 2044-10-12) detects early signs of resistance breakdown. If breakdown is detected by Month 120-144 (2036-10-12 to 2038-10-12), trigger breeding of replacement cultivars with alternate resistance sources.

**Responsible Body/Role:** Breeding Programme Director

**Suggested Timeframe:** Month 84 onward (2033-10-12 onward) - monitoring through Month 216 (2044-10-12) and beyond

**Key Outputs/Deliverables:**

- Sentinel plantings established in high-inoculum zones (Month 90-120 = 2034-04-12 to 2036-10-12)
- Quarterly durability monitoring reports (Month 84+)
- Durability-breakdown alerts (if detected) escalated to Steering Council

**Dependencies:**

- Resistant cultivars released and deployed post-Year 7 gate

### 76. Containment Protocol Authority, throughout Months 36-216 (2029-10-12 to 2044-10-12), enforces compliance with the SALB protocol. Quarterly compliance reporting includes: share of nurseries under certified inspection, share of nursery material moved under certified chain-of-custody, compliance violations detected and penalties enforced, protocol amendment tracking. Annual compliance audits verify inspector performance and data quality.

**Responsible Body/Role:** Containment Protocol Authority (Compliance and Enforcement Manager)

**Suggested Timeframe:** Ongoing from Month 36 (2029-10-12) through Month 216 (2044-10-12) and beyond

**Key Outputs/Deliverables:**

- Quarterly compliance reports to Steering Council
- Annual compliance and enforcement audit
- Penalty enforcement documentation

**Dependencies:**

- Protocol adopted by IPPC (Month 36 = 2029-10-12 gate)
- Compliance-inspection network operational

### 77. Independent Auditor, 6 months before Month 216 (2044-10-12) gate (by Month 210, 2044-04-12), receives gate-readiness submission from PMO. PMO compiles: final containment performance (verified incursion-free or contained within tolerance), resistant-cultivar acreage and durability track record (Years 7-18), alternative-rubber supply volumes (32,000 t/year from waves 1-2), long-term cost and quality metrics, smallholder adoption final status, climate-resilience evidence. Auditor conducts final comprehensive assessment Months 210-216 (2044-04-12 to 2044-10-12).

**Responsible Body/Role:** PMO (all workstreams) and Independent Auditor

**Suggested Timeframe:** Month 210 (2044-04-12) - submission; Months 210-216 (2044-04-12 to 2044-10-12) - audits

**Key Outputs/Deliverables:**

- Year 18 gate-readiness report (Month 210 = 2044-04-12)
- Auditor final gate-closure report (by Month 215.5, 2044-09-27 estimate)

**Dependencies:**

- All 25-year programme activities documented and verified

### 78. Independent Auditor issues Month 216 (2044-10-12) gate-closure verdict 30 days before gate date (by Month 215.5, 2044-09-27 estimate). Verdict assesses long-term success: verified SALB containment maintained (no unmanaged spread); diversified parallel supply chains (resistant Hevea + alternative rubber) resilient to pathogen and climate shocks; smallholder livelihoods supported through adoption and price-stability mechanisms; programme institutional continuity sustained over 18 years.

**Responsible Body/Role:** Independent Auditor

**Suggested Timeframe:** Month 215.5 (2044-09-27) - verdict issued

**Key Outputs/Deliverables:**

- Month 216 (2044-10-12) gate-closure verdict (final) (published)

**Dependencies:**

- All 18-year programme period activities documented

### 79. Steering Council, upon receipt of Independent Auditor verdict on Month 216 (2044-10-12) gate (by Month 215.5, 2044-09-27), reviews verdict and authorizes Year 18 tranche release (USD 4.0B). This final tranche supports the programme's remaining 7 years (Months 216-300, 2044-10-12 to 2052-10-12) with continued smallholder support, surveillance, and alternative-crop operations. Tranche is disbursed within 45 days (by Month 216.75, 2044-11-04 estimate).

**Responsible Body/Role:** Steering Council

**Suggested Timeframe:** Month 216 (2044-10-12) - gate deadline; tranche released within 45 days (by Month 216.75 = 2044-11-04)

**Key Outputs/Deliverables:**

- Steering Council decision on Year 18 gate passage
- Year 18 tranche (USD 4.0B or minimum 80%) disbursed by Month 216.75 (2044-11-04)

**Dependencies:**

- Independent Auditor verdict received

### 80. Steering Council and PMO, in Phase 5 (Months 216-300, 2044-10-12 to 2052-10-12), transition the programme toward long-term operational sustainability. Key decisions include: wind-down of programme-dedicated structures (PMO, governance bodies) with transfer of ongoing functions to host institutions (FAO/IPPC for protocol, national research institutes for breeding, processing operators for alternative crops, cooperatives for smallholder networks); final audits and knowledge-transfer documentation; publication of 25-year programme outcomes and lessons-learned report.

**Responsible Body/Role:** Steering Council and Programme Director

**Suggested Timeframe:** Months 216-240 (2044-10-12 to 2046-10-12) - transition planning; Months 240-300 (2046-10-12 to 2052-10-12) - implementation

**Key Outputs/Deliverables:**

- Transition plan for programme wind-down and institutional handoff (published Month 216 = 2044-10-12)
- Knowledge-transfer documentation and archive (Months 216-240 = 2044-10-12 to 2046-10-12)
- Final 25-year programme outcomes report (Month 240 = 2046-10-12)
- Lessons-learned publication (Month 240 = 2046-10-12)

**Dependencies:**

- Month 216 (2044-10-12) gate PASS
- All governance bodies and operational systems mature and documented