## Suggestion 1 - IPPC International Standards for Phytosanitary Measures (ISPM) standard-setting process, FAO Rome

The IPPC Secretariat, hosted by FAO, runs the standard-setting process that produces ISPMs, adopted by the Commission on Phytosanitary Measures. Its Implementation Review and Support System and capacity-development work help national plant protection organizations apply standards. Topic-specific standards typically take several years from proposal to adoption (approximate). The process is the route for the program's IPPC-framework Containment Protocol.

### Success Metrics

Number of ISPMs adopted by the Commission (over 40 standards; approximate, not verified)
Adoption timelines from topic submission to adoption, usually multi-year
Number of contracting parties (over 180; approximate)
Implementation uptake in national import rules, measured through IPPC review and support surveys

### Risks and Challenges Faced

Slow consensus among sovereign parties: addressed through technical drafting groups and staged consultation, which the program should start at Month 0 (2026-10-08).
Weak national capacity to implement: addressed through IPPC capacity-development and donor-funded projects, matching the program's inspector ramp.
No supranational enforcement: standards rely on national adoption, so the program should pair the standard with funding conditionality and regional compacts.

### Where to Find More Information

https://www.ippc.int
https://www.fao.org/plant-health

### Actionable Steps

Contact the IPPC Secretariat standard-setting unit via the contact page on ippc.int to ask about the topic-submission calendar and call for topics.
Ask the IPPC Capacity Development team about co-financed implementation projects.
Approach the national plant protection organizations of Brazil (MAPA), Indonesia, Malaysia and Thailand to nominate technical working group members.

### Rationale for Suggestion

The program's non-negotiable deliverable is a protocol harmonized with IPPC frameworks. This is the only real standard-setting process that can give the protocol formal international standing. It is geographically neutral and based in Rome, one of the program's governance hubs. Its multi-year timeline supports the plan's two-tier fallback of regional compacts while the standard proceeds.
## Suggestion 2 - Embrapa and CIRAD Hevea genetic improvement and SALB resistance research (Brazil, France)

Embrapa (Brazil) and CIRAD (France) have long maintained Hevea germplasm collections and run breeding and disease research on South American Leaf Blight (Pseudocercospora ulei). The Brazilian Rubber Research network, together with the Instituto Agronômico de Campinas (IAC), tests clones in SALB-escape areas of São Paulo and the Amazon. Work includes wild-accession use, clone screening and molecular studies of resistance. Historic Hevea breeding has shown single-source resistance breaking down, which is the failure the program's pyramiding strategy targets.

### Success Metrics

Clones released or recommended for planting in Brazilian rubber regions (counts to be confirmed with institutions)
Germplasm accessions conserved and characterized (CIRAD and Embrapa collections; counts not verified)
Peer-reviewed resistance mapping and genomic studies
Documented historic resistance breakdowns that inform durability testing

### Risks and Challenges Faced

Resistance breakdown from pathogen variation: addressed through multi-isolate testing and resistance from several sources, as the program's Virulence Gates require.
Long breeding cycles: shortened with molecular markers and genomic selection.
Access and benefit-sharing compliance: managed under Brazilian genetic-heritage law (SisGen), a template for the program's Nagoya team.

### Where to Find More Information

https://www.embrapa.br
https://www.cirad.fr/en
Search Google Scholar for 'Hevea Pseudocercospora ulei resistance genomic selection'

### Actionable Steps

Contact Embrapa's Rubber/Hevea research units through the Embrapa 'Fale Conosco' channel to request a meeting with the rubber breeding lead.
Contact CIRAD's UMR AGAP Institut or Hevea research team via the CIRAD contact form about accession sharing and the Asian satellite lab.
Ask CEPLAC about collaboration on trial sites.

### Rationale for Suggestion

Brazil is the program's geographic anchor and these institutions hold the repositories that serve as the plan's contingency accession supply. Their SALB work directly informs the pyramiding strategy, pathogen genomics lab and trial design. Few other organizations hold comparable SALB-specific expertise, so no closer equivalent exists elsewhere.
## Suggestion 3 - Bridgestone guayule commercialization program (Eloy, Arizona, USA)

Bridgestone Americas runs a guayule research and processing center in Mesa and a research farm in Eloy, Arizona, building on USDA-funded and Yulex-related work. It has developed agronomy, extraction and processing, and has produced prototype tires with guayule rubber, including a public demonstration (reported 2015 and later). The effort links crop breeding, colocated processing and OEM-style tire testing in a semi-arid zone, as the program's arid-zone pillar requires.

### Success Metrics

Prototype tires built with guayule rubber and tested (publicly reported)
Agronomic yield and rubber-content improvements through breeding (figures should be confirmed with Bridgestone)
Establishment of a research farm and processing facility in Arizona
Federal and partner funding secured for development (amounts not verified)

### Risks and Challenges Faced

Cost competitiveness against Hevea: addressed by pursuing co-products (resin, bagasse) and breeding for higher rubber content.
Irrigation and water use: addressed by agronomy trials on water efficiency, supporting the program's restriction to water-efficient zones.
Slow commercial scale-up: the effort stays at pilot scale, supporting the program's rule of no hub construction before offtake and gate evidence.

### Where to Find More Information

https://www.bridgestoneamericas.com (search 'guayule')
USDA ARS guayule research publications: https://www.ars.usda.gov
https://www.yulex.com

### Actionable Steps

Contact Bridgestone Americas Corporate Communications or the Guayule Research Center manager (via the company website) to request a technical briefing.
Contact USDA ARS Arid-Land Agricultural Research Center (Maricopa, Arizona) about breeding collaboration.
Reach Yulex through its website about commercial processing experience.

### Rationale for Suggestion

This is the closest real guayule project with colocated processing and tire-grade testing in a target arid zone (southwestern USA). It also shows an OEM taking part directly, which suits the program's buyer consortium. The Mexican and Argentine sites lack comparable public records, so this US example is the nearest documented case.
## Suggestion 4 - Continental Taraxagum Russian dandelion tire program (Germany, with Fraunhofer IME and partners)

Continental runs the Taraxagum project, developing Russian dandelion (Taraxacum koksaghyz) rubber for tires. It has a research lab in Anklam, Germany, and a pilot cultivation and processing site, working with Fraunhofer IME, the Julius Kühn Institute and other partners. Continental has publicly shown tires with dandelion rubber (a 2018 prototype and later series-style tests). The work spans breeding, field cultivation, extraction and tire testing in a temperate zone.

### Success Metrics

Prototype and test tires produced with dandelion rubber (publicly reported)
Establishment of a pilot extraction and research facility in Anklam
Breeding progress on root rubber content and yield (figures to be confirmed with partners)
Peer-reviewed publications on extraction and agronomy

### Risks and Challenges Faced

Low root yield and weed management: addressed through breeding and mechanization trials.
Processing cost: addressed through pilot processing and co-product (inulin) valuation, matching the program's co-product assumption.
Long timeline to commercial scale: Continental has kept the effort at pilot scale, supporting the program's staged approach.

### Where to Find More Information

https://www.continental-tires.com (search 'Taraxagum')
https://www.ime.fraunhofer.de/en
Search the Fraunhofer IME bioeconomy pages for 'Taraxacum koksaghyz'

### Actionable Steps

Contact Continental Reifen Deutschland, Research & Development (Taraxagum team) through the corporate contact page.
Contact Fraunhofer IME Bioresources department via the Institute's contact page about breeding and extraction.
Contact the Julius Kühn Institute about agronomy collaboration.

### Rationale for Suggestion

It is the leading documented OEM-backed Russian dandelion effort, set in a temperate zone like the program's pilot sites in northern Europe. It combines breeding, cultivation, extraction and tire testing, and shows how an OEM can co-fund qualification. Eastern European pilot sites have fewer public records, so this German case is the nearest documented reference.
## Suggestion 5 - Global Platform for Sustainable Natural Rubber (GPSNR) (SECONDARY SUGGESTION)

GPSNR is a multi-stakeholder platform launched in 2019 that brings together tire makers, automotive firms, rubber processors, traders, smallholder groups and NGOs to set sustainability policy for natural rubber. It is based in Singapore. It shows how competing buyers and producers can agree shared rules and governance with seats for different constituencies. It does not address SALB itself.

### Success Metrics

Membership across the natural rubber value chain (reported in the hundreds; approximate)
Adoption of a shared sustainability policy framework and assessment framework
Member reporting against platform requirements

### Risks and Challenges Faced

Competitor coordination: handled through a balanced governance structure by constituency.
Smallholder inclusion: addressed through dedicated smallholder membership and committees.

### Where to Find More Information

https://sustainablenaturalrubber.org

### Actionable Steps

Contact the GPSNR Secretariat in Singapore via the website to ask about governance design and about member OEMs willing to join a buyer consortium.

### Rationale for Suggestion

Secondary suggestion. It is a real example of tire makers, traders and smallholder bodies governing together, which is useful for the program's board design, OEM consortium and levy negotiations. It has no levy or SALB mandate, so fewer details are given.

## Summary

The SALB program combines phytosanitary containment, resistant Hevea breeding and alternative rubbers, all gated and aimed at smallholder adoption. No past project matches the whole scope. The references below each cover one component. They are the IPPC standard-setting process, the Brazil-based Embrapa/CIRAD Hevea breeding and SALB work, the USA guayule commercialization effort (Bridgestone, Arizona), and the EU dandelion rubber effort (Continental Taraxagum). Examples nearest to Brazil and the Asian and African rubber belts are limited, so US and European cases are included for the alternative-rubber pillar. All figures not verified are labeled approximate. Contacts are given as organizations or roles. Details should be confirmed directly with each body. A secondary suggestion covers the Global Platform for Sustainable Natural Rubber (GPSNR) as an industry-coordination model for the levy and OEM consortium.