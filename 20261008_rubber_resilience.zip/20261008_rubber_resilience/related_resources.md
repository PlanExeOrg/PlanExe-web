## Suggestion 1 - Bridgestone Americas Guayule Natural Rubber Program (Eloy, Arizona)

Bridgestone developed guayule as a domestic natural rubber source, with a Process Research Center and a research farm in Eloy, Arizona, opened in the mid-2010s. Work spans agronomy, breeding, extraction and tire prototypes. Bridgestone has publicly shown tires built with guayule rubber. The program is an integrated crop-to-tire pilot in the same arid zone the plan targets.

### Success Metrics

Operating pilot extraction facility and research farm in Eloy
Guayule-containing tire prototypes publicly demonstrated
Agronomic yield and rubber-content improvements reported in company and academic publications (figures not verified here)

### Risks and Challenges Faced

Cost gap against Hevea: addressed through breeding and process R&D rather than early commercial plant build.
Water demand in arid zones: addressed via irrigation research and drought-tolerant selection.
Extraction yield and resin co-products: addressed by process research and co-product valorization.

### Where to Find More Information

Bridgestone Americas newsroom (bridgestoneamericas.com), guayule section
USDA-ARS Arid Land Agricultural Research Center, Maricopa, Arizona publications
Industrial Crops and Products journal guayule papers

### Actionable Steps

Contact Bridgestone Americas' guayule program lead via the corporate media/research contact form on bridgestoneamericas.com.
Approach USDA-ARS Arid Land Agricultural Research Center for agronomy data and trial protocols.
Request a site visit to the Eloy research farm through Bridgestone's sustainability office.

### Rationale for Suggestion

Direct match for the plan's Guayule pillar in Arizona: colocated agronomy, extraction pilot and OEM tire qualification under one owner. Shows realistic pilot scales and cost gaps against Hevea, informing the Month 48 (2030-10-12) and Month 84 (2033-10-12) cost KPIs and the Month 60 (2031-10-12) portfolio decision.
## Suggestion 2 - Continental Taraxagum Russian Dandelion Program with Fraunhofer IME and EU-PEARLS

Continental developed Taraxagum, tires made with rubber from Taraxacum koksaghyz (Russian dandelion), with a pilot facility in Anklam, Mecklenburg-Vorpommern, Germany, and research partners including Fraunhofer IME and the Julius Kühn Institute. The EU-PEARLS consortium earlier advanced guayule and dandelion crops. Continental has tested dandelion-rubber tires on public roads.

### Success Metrics

Pilot lab and processing facility operating in Anklam
Road-tested dandelion-rubber tire prototypes
Published breeding progress on yield and rubber content (specific values not verified here)

### Risks and Challenges Faced

Low yield per hectare: addressed through breeding selection and agronomic trials.
Root harvesting and extraction cost: addressed with process research at Fraunhofer IME.
Commercial scale uncertainty: handled by staying at pilot scale pending cost evidence.

### Where to Find More Information

Continental press releases on Taraxagum (continental.com)
Fraunhofer IME Münster publications on Taraxacum koksaghyz
EU-PEARLS project reports (CORDIS)

### Actionable Steps

Contact Continental's Tire Research/Sustainability communications office via continental.com.
Approach Fraunhofer IME Münster's bioresources group for breeding and extraction data.
Request EU-PEARLS final reports through CORDIS to reuse cost and agronomy findings.

### Rationale for Suggestion

Closest operating precedent for the dandelion pillar in the plan's Germany/Benelux zone: OEM-led, colocated pilot processing, breeding and tire testing. Informs the 1,000 t/year demonstration pilot, offtake qualification and cost trajectory. European location is near the plan's proposed sites.
## Suggestion 3 - IPPC International Standards for Phytosanitary Measures (ISPM) process, FAO Rome

The IPPC Secretariat at FAO Rome runs the Standards Committee and Commission on Phytosanitary Measures, which draft, consult on and adopt ISPMs, including ISPM 36 on integrated measures for plants for planting and ISPM 5 glossary. Adoption normally takes several years through member consultation.

### Success Metrics

Adopted ISPMs implemented by national plant protection organizations
Consultation periods and adoption votes recorded annually at the CPM
Implementation Review and Support System data on national uptake

### Risks and Challenges Faced

Slow consensus: mitigated by early drafting with technical panels and pre-consultation.
Weak enforcement: IPPC relies on national implementation; capacity development programs partly address it.
Resource limits of developing members: addressed through the IPPC Implementation and Capacity Development Committee.

### Where to Find More Information

IPPC portal (ippc.int), standard setting section
ISPM 36 text on ippc.int
CPM session reports on ippc.int

### Actionable Steps

Contact the IPPC Secretariat Standard Setting Unit through the contacts page on ippc.int.
Ask about submitting a topic via the Call for Topics for Standards.
Engage regional organizations such as APPPC and NAPPO for regional alignment.

### Rationale for Suggestion

The plan embeds the SALB Containment Protocol in the IPPC framework. This is the actual pathway, with real timelines, consultation steps and adoption mechanics. Examining ISPM 36 shows how nursery stock controls are harmonized and what enforcement gaps remain.
## Suggestion 4 - IRRDB Hevea breeding and SALB-resistance collaboration, with Embrapa and rubber research institutes

The International Rubber Research and Development Board (IRRDB) coordinates member rubber research institutes in Asia, Africa and Latin America, including the 1981 Hevea germplasm collection from Amazonia held by member countries. Embrapa and the Instituto Agronômico (IAC) in Brazil conduct SALB-resistance breeding and clone trials; SALB research is also supported by the Rubber Research Institute of Malaysia and Michelin's Brazilian plantations.

### Success Metrics

Germplasm accessions maintained and exchanged among member institutes (counts not verified here)
Released clones with partial SALB tolerance in Brazil
Multi-country clone trial networks operating

### Risks and Challenges Faced

Resistance breakdown in single-source tolerance: addressed by seeking multiple resistance sources.
Long perennial cycles: partly mitigated through early selection markers.
Brazilian access rules: handled under national ABS law with institutional agreements.

### Where to Find More Information

IRRDB website (irrdb.com)
Embrapa Hevea and rubber research pages (embrapa.br)
Malaysian Rubber Board research publications (lgm.gov.my)

### Actionable Steps

Contact the IRRDB Secretariat through irrdb.com to propose joint trials.
Approach Embrapa's rubber research team via the Embrapa contact portal.
Ask the Malaysian Rubber Board's research division about clone trials and quarantine practice.

### Rationale for Suggestion

Provides the existing Hevea germplasm network, clone exchange protocols and SALB expertise that the plan's four-site breeding trials would build on. Brazil and Asian programs are the plan's named partners, so contacts and ABS history are directly applicable.
## Suggestion 5 - Secondary: ITPGRFA Multilateral System of Access and Benefit-Sharing

The International Treaty on Plant Genetic Resources for Food and Agriculture, administered by FAO, runs a multilateral system with a Standard Material Transfer Agreement and a Benefit-sharing Fund. Rubber is not an Annex 1 crop, so it is not covered directly.

### Success Metrics

Number of SMTA transfers recorded by the Treaty Secretariat
Benefit-sharing Fund projects funded

### Risks and Challenges Faced

Limited crop coverage: handled by bilateral arrangements for non-Annex crops.
Weak monetary benefit flows: a known challenge in treaty reviews.

### Where to Find More Information

FAO Plant Treaty website (fao.org/plant-treaty)

### Actionable Steps

Contact the Plant Treaty Secretariat at FAO Rome via the website contact page.

### Rationale for Suggestion

Secondary suggestion: a documented template for pooled germplasm exchange and benefit sharing, useful as a design reference for the plan's ABS arrangements with Brazil's CGen. Hevea is outside Annex 1, so legal applicability is limited.

## Summary

The program combines a harmonized phytosanitary protocol, Brazil-led ABS-compliant Hevea breeding, and commercial Guayule and dandelion rubber with smallholder delivery. Verifiable precedents exist for each pillar but none for the whole. Primary references: Bridgestone's Guayule program in Arizona (Eloy), the EU-PEARLS / Continental Taraxagum dandelion program, and the IPPC standard-setting process with the Rubber Research Institute-led Hevea breeding networks (IRRDB). Secondary: the Plant Treaty multilateral system. Geographic proximity holds for Arizona guayule and German dandelion; the Hevea and SALB precedents are drawn from Asia and Latin America. Figures not confirmed are not stated; approach the named organizations for current data.