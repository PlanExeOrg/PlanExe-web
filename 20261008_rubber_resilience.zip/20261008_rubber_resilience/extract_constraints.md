## Positive Constraints

- Launch a 25-year public-private program to de-risk global natural rubber supply from South American Leaf Blight (SALB)
- Total budget of $30 billion
- Project start ASAP
- Aim to end the industry's dependence on a single vulnerable crop
- Phase 1 non-negotiable deliverable: a globally adopted SALB Containment Protocol
- SALB Containment Protocol must be harmonized with existing regional phytosanitary standards
- SALB Containment Protocol must cover movement of nursery stock, research materials, and contaminated equipment
- Fund surveillance, inspections, and red-team drills before any scale-up
- Run a Brazil-led bio-prospecting and genomic breeding effort
- Bio-prospecting must be access-and-benefit-sharing compliant
- Deliver SALB-resistant, yield-parity Hevea cultivars
- Stand up commercial-scale alternative rubbers: Guayule in arid zones
- Stand up commercial-scale alternative rubbers: Russian dandelion in temperate climates
- Alternative rubbers with colocated processing and OEM offtake agreements
- Design the whole program around smallholder adoption
- Include replant finance for smallholders
- Include clean-plant networks
- Include price-stability tools
- Gate funding at Years 3, 7, 12, and 18
- Funding gates based on containment performance, cultivar readiness, and alternative-rubber cost/quality KPIs
- Success = verified containment, diversified parallel supply chains, and resilient procurement across pathogen and climate shocks
- Use month offsets from project start (e.g., Month 3 = 2027-01-08) for time references; do not write calendar dates
- Write in the impersonal voice of a planning document
- Mark figures that are not user constraints or established benchmarks as proposed thresholds or estimates

## Negative Constraints

- Do not scale up before containment surveillance, inspections, and red-team drills are funded
- Do not present invented numbers as facts
- Do not turn example values from input documents ("e.g. ...") into requirements
- Do not write calendar dates
- Do not refer to oneself or one's own process (no "I", "my knowledge", "I could not verify")
