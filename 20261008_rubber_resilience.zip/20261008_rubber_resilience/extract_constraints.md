## Positive Constraints

- Program duration: 25 years
- Budget: $30 billion
- Public-private program structure
- Goal: de-risk the global natural rubber supply from South American Leaf Blight (SALB) by ending dependence on a single vulnerable crop
- Phase 1 non-negotiable deliverable: a globally adopted SALB Containment Protocol
- SALB Containment Protocol must be harmonized with existing regional phytosanitary standards
- SALB Containment Protocol must cover movement of nursery stock, research materials, and contaminated equipment
- Fund surveillance, inspections, and red-team drills before any scale-up
- Run in parallel a Brazil-led bio-prospecting and genomic breeding effort that is access-and-benefit-sharing compliant
- Deliver SALB-resistant, yield-parity Hevea cultivars
- Stand up commercial-scale alternative rubber: Guayule in arid zones
- Stand up commercial-scale alternative rubber: Russian dandelion in temperate climates
- Colocated processing and OEM offtake agreements for alternative rubber
- Design the whole program around smallholder adoption
- Include replant finance for smallholders
- Include clean-plant networks
- Include price-stability tools
- Gate funding at Years 3, 7, 12, and 18
- Funding gates based on containment performance, cultivar readiness, and alternative-rubber cost/quality KPIs
- Success criteria: verified containment, diversified parallel supply chains, and resilient procurement across pathogen and climate shocks
- Project start: ASAP

## Negative Constraints

- Do not scale up before containment protocol with funded surveillance, inspections, and red-team drills is in place
