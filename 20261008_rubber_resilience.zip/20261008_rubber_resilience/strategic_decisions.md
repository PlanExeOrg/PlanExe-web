## Primary Decisions
The vital few decisions that have the most impact.


The Critical and High levers address the program's core tensions: legitimacy versus enforceability (Containment Protocol Authority), speed versus durability (Resistance Breeding Pathway), focus versus hedging (Alternative Rubber Portfolio Breadth), and long-horizon funding versus control (Capital Stack). High levers cover gate credibility, smallholder adoption, bankable demand, germplasm access and field delivery. No major dimension appears missing, though climate-shock resilience and cross-border political governance are only implicit.

### Decision 1: Containment Protocol Authority
**Lever ID:** `90a0aedc-0b17-4bd1-b386-78e3ef93be2b`

**The Core Decision:** Defines the institutional home, certification mechanism and sanctioning power of the SALB Containment Protocol, the non-negotiable Phase 1 deliverable. Scope covers who audits nurseries, research stations and equipment movements, and how non-compliance is penalized. Success metrics: share of producing countries embedding the protocol in national regulation, proportion of nursery stock moved under certified chain-of-custody, and red-team drill performance before the Year 3 gate.

**Why It Matters:** Choosing who writes, certifies and enforces the SALB Containment Protocol decides whether it becomes binding practice or a shelf document. A body anchored in existing phytosanitary institutions gains legitimacy and faster uptake, but inherits slow consensus and weak enforcement. A purpose-built authority can inspect and sanction more directly, at the cost of sovereignty objections from producing countries that may delay the Phase 1 deliverable.

**Strategic Choices:**

1. Embed the protocol within the existing IPPC and regional plant protection organization framework, publishing it as a harmonized international standard that national agencies adopt through their normal regulatory processes.
2. Create a dedicated SALB Containment Authority funded by the program, with its own inspectors, audit rights over nurseries and research stations, and the power to suspend certification of non-compliant sites.
3. Build a producer-and-buyer compliance club in which OEMs and tire makers contractually require protocol-certified nursery stock and equipment from suppliers, making market access rather than treaty law the enforcement mechanism.

**Trade-Off / Risk:** Legitimacy and enforceability pull in opposite directions: the standard-setting route is credible but toothless, while a private compliance club enforces quickly yet may exclude smallholders and lack recognition from national quarantine services.

**Strategic Connections:**

**Synergy:** Gives Surveillance Sensing Architecture and Incursion Response Playbook a binding mandate to act on findings, and supplies Gate Evidence Verification Regime with auditable containment data for releasing funding at Years 3/7/12/18.

**Conflict:** Strong enforcement or a dedicated authority raises sovereignty objections and can burden poor farmers, pulling against Smallholder Transition Finance and Extension Corps and Nursery Workforce Pipeline, which need low-friction access to certified clean plants.

**Justification:** *Critical*, Controls the non-negotiable Phase 1 deliverable and the legitimacy-versus-enforceability trade-off. It is a hub: it gives Surveillance, Incursion Response and Gate Verification a binding mandate, while conflicting with smallholder access to clean plants and with sovereignty concerns.

### Decision 2: Resistance Breeding Pathway
**Lever ID:** `c0831704-835a-4316-aa5f-d3d9371b1be9`

**The Core Decision:** Selects the technical route to SALB-resistant, yield-parity Hevea: genomic selection of polygenic resistance, gene-edited or transgenic clones, or crown-budding with resistant canopies. Scope includes durability testing across multiple sites, regulatory acceptance in importing markets, and clone supply to nurseries. Key metrics: number of independent resistance sources stacked, field yield relative to current elite clones, and cultivar-readiness evidence available at the Year 7 gate.

**Why It Matters:** The breeding route determines how quickly SALB-resistant, yield-parity Hevea reaches farmers and how durable the resistance proves against a pathogen that has historically overcome single-source resistance. Conventional selection is accepted by regulators and growers but is slow in a perennial tree crop. Faster molecular routes shorten cycles yet raise regulatory and consumer-acceptance questions in importing markets.

**Strategic Choices:**

1. Run marker-assisted and genomic selection across a broad Amazonian germplasm base, crossing multiple resistance sources into high-yield Asian clones to build polygenic, durable resistance without gene-edited material.
2. Pursue gene-editing and transgenic resistance in elite clones in parallel with conventional breeding, accepting regulatory approval work in exchange for a shorter route to deployable cultivars.
3. Deploy crown-budding systems that graft a resistant leaf canopy onto high-yield panel clones, using existing clone material to deliver field protection years before fully bred cultivars are ready.

**Trade-Off / Risk:** Faster molecular and grafting routes shorten the timeline but concentrate risk on a few resistance sources or labor-heavy practices, while slow polygenic breeding may not deliver before the Year 7 gate demands cultivar readiness evidence.

**Strategic Connections:**

**Synergy:** Draws resistance sources from Germplasm Access and Benefit-Sharing Model and feeds Clonal Mosaic Deployment Rules with diverse genotypes, so durable resistance can be spread across landscapes instead of resting on one clone.

**Conflict:** Faster molecular or crown-budding routes demand regulatory work and skilled labor, competing with Alternative Rubber Portfolio Breadth for capital, and proprietary edited traits can restrict openness under Research Knowledge Commons and IP Posture.

**Justification:** *Critical*, Sets the speed-versus-durability trade-off for delivering SALB-resistant, yield-parity Hevea and determines Year 7 gate readiness. Connects germplasm access, clonal deployment, IP posture and capital competition with alternative crops; the core long-term technical bet.

### Decision 3: Alternative Rubber Portfolio Breadth
**Lever ID:** `ac331099-1dda-4a37-9e6c-d966075f0d8c`

**The Core Decision:** Decides how widely program capital is spread across non-Hevea rubber: Guayule, Russian dandelion, fermentation-derived isoprene, blends, or staged pilots. It shapes processing-plant sizing, flexibility and OEM confidence. Success metrics: cost and quality versus Hevea specifications, tonnage reaching commercial offtake, and the share of capital held back until crop-region pairs clear agronomic and cost thresholds at the stage gates.

**Why It Matters:** Concentrating on Guayule and Russian dandelion gives a focused commercialization path, but both crops face cost, yield and processing gaps against Hevea latex. Broadening to other feedstocks hedges against agronomic or economic failure and spreads investment across technologies. The choice also sets whether colocated processing plants are sized for one crop or flexible across several.

**Strategic Choices:**

1. Concentrate investment on Guayule in arid zones and Russian dandelion in temperate zones, building a few commercial-scale colocated processing plants sized to meet OEM cost and quality specifications.
2. Fund a wider portfolio that adds bio-based isoprene from fermentation and blended rubber formulations, treating Guayule and dandelion as two of several competing pathways judged by cost and quality gates.
3. Stage the alternatives through multi-region pilot farms and modular processing units, scaling only the crop-and-region pairs that meet agronomic and cost thresholds before committing fixed plant capital.

**Trade-Off / Risk:** Narrow focus risks locking billions into crops that may stay uncompetitive with Hevea, while broad portfolios and modular pilots dilute scale economies and delay the colocated processing volumes OEMs need to sign meaningful offtake.

**Strategic Connections:**

**Synergy:** Determines the crop and volume mix that Offtake and Strategic Reserve Design contracts against, and informs Alternative Crop Land-Use Footprint by showing which regions and acreages warrant scale-up.

**Conflict:** Wider portfolios and modular pilots dilute scale economies and delay processing volumes, straining Offtake and Strategic Reserve Design, while also competing with Resistance Breeding Pathway for limited funds within Capital Stack and Sponsor Coalition.

**Justification:** *Critical*, Governs the concentration-versus-hedging trade-off for the entire non-Hevea pillar, fixing plant sizing, OEM confidence and capital competition with breeding. Drives offtake design and land-use footprint, so it is the strategic choice representing the alternative-crop pillar.

### Decision 4: Gate Evidence Verification Regime
**Lever ID:** `73fdb0ef-e55f-4faf-9cd9-2556e335575f`

**The Core Decision:** Determines who produces and certifies the evidence behind the Year 3, 7, 12 and 18 funding gates, and how independent and adversarial that review is. Scope covers audit mandate, method pre-registration, access to national agency data and handling of adverse findings. Success metrics: gate decisions accepted by funders without dispute, audit timeliness, and findings later borne out in the field.

**Why It Matters:** This defines who generates and certifies the evidence used at the Year 3, 7, 12 and 18 funding gates. Verification independence determines whether gate decisions are credible to funders, governments and OEMs, and whether containment performance is genuinely proven rather than self-reported. Stricter independent verification adds cost and time to each gate and may expose bad news that program managers prefer to handle internally.

**Strategic Choices:**

1. Rely on program-internal technical teams to compile gate evidence, with a standing scientific advisory panel reviewing the reports and issuing recommendations to the funders' steering committee.
2. Contract an independent international auditor to verify containment performance, cultivar field data and alternative-rubber cost and quality claims, with audit scope and methods fixed in advance of each gate.
3. Combine third-party audit with adversarial review, in which a separately funded red-team group is tasked to find reasons a gate should not be passed and publishes findings alongside the evidence.

**Trade-Off / Risk:** Independent auditing strengthens gate credibility, but auditors depend on data from the same national agencies and estates being assessed, and an adversarial review group can stall decisions if its mandate is not bounded.

**Strategic Connections:**

**Synergy:** Credible verification strengthens Capital Stack and Sponsor Coalition by reassuring funders that tranche releases are earned, and makes Containment Protocol Authority performance claims believable to OEMs and phytosanitary bodies.

**Conflict:** Independent or adversarial review adds cost and delay that pressure Surveillance Sensing Architecture and Resistance Breeding Pathway timelines, and auditors depend on data from the very agencies and estates that Containment Protocol Authority oversees.

**Justification:** *High*, Underpins the credibility of the Year 3/7/12/18 gates, linking funder confidence, containment claims and cultivar and cost KPIs. Manages the rigor-versus-speed trade-off, but is a mechanism serving the funding and containment hubs rather than a foundational pillar itself.

### Decision 5: Capital Stack and Sponsor Coalition
**Lever ID:** `9827edba-0d61-4cd1-8739-0b9257037400`

**The Core Decision:** Defines who funds the $30 billion over 25 years, on what release conditions, and who gains governance influence. Its quality is judged by commitment durability through budget cycles, share of capital that is actually gate-conditional, speed of disbursement when needed, and balance between sovereign, multilateral and industry voices in setting program priorities.

**Why It Matters:** Determines who carries the $30 billion over 25 years and how long the commitments hold. A sovereign-heavy stack gives durability but exposes the program to budget cycles, while industry-heavy funding aligns incentives but concentrates influence over priorities. The structure also sets how tightly gate-released tranches can be enforced.

**Strategic Choices:**

1. Anchor the program on sovereign and multilateral development bank commitments, with tire makers and OEMs adding matched contributions released only as each gate is passed.
2. Establish an industry resilience levy collected from tire makers and rubber traders into a ring-fenced fund that sits outside annual government budget cycles.
3. Structure part of the capital as an outbreak-triggered contingent facility, using catastrophe-bond-style instruments that release funds on confirmed SALB detection in a currently unaffected producing region.

**Trade-Off / Risk:** A levy or contingent facility looks elegant on paper, but contributors with direct commercial exposure will push for priority control, and contingent instruments are hard to price without outbreak-probability data the program itself must generate.

**Strategic Connections:**

**Synergy:** Funds and enforces Gate Evidence Verification Regime by tying tranche release to verified results, and underwrites Smallholder Transition Finance and Incursion Response Playbook compensation with predictable, ring-fenced or contingent liquidity.

**Conflict:** Industry-heavy or levy funding can pull against Research Knowledge Commons and IP Posture, as paying sponsors seek proprietary advantage, and against Offtake and Strategic Reserve Design, where sponsors may favor their own procurement terms.

**Justification:** *Critical*, Central funding hub that decides who carries the $30 billion and how gate tranches are enforced. It underwrites smallholder finance and incursion compensation, and its conflicts with IP posture and offtake show it governs the project's main power and incentive trade-offs.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Germplasm Access and Benefit-Sharing Model
**Lever ID:** `bb7afee7-4957-4521-96fa-891040d911eb`

**The Core Decision:** Sets the legal and commercial terms under which Amazonian Hevea material and associated sequence data can be collected, transferred and commercialized, and how value returns to Brazil and local communities. Scope spans Brazil's national ABS system, Nagoya Protocol compliance and downstream partner transfers. Metrics: time from collection request to transfer, share of breeding partners under valid agreements, and benefit payments actually delivered to communities.

**Why It Matters:** The ABS structure sets who can legally use Amazonian Hevea material and how value flows back to Brazil and local communities. Bilateral, case-by-case agreements give clear legal title but slow every transfer of material to partner breeding programs. A pooled or multilateral model speeds sharing but requires governments and communities to accept shared governance over resources they treat as sovereign assets.

**Strategic Choices:**

1. Negotiate bilateral access agreements through Brazil's national access and benefit-sharing system for each collection and each downstream partner, keeping title and royalty terms specific to the material and user.
2. Establish a multilateral germplasm pool with standard material-transfer terms and a fixed benefit-sharing contribution from commercial cultivar sales and sequence-data use, similar in logic to the plant treaty system.
3. Create a community-governed data and germplasm trust in which indigenous and traditional communities hold seats and co-ownership of resistance discoveries, with benefit payments tied to downstream cultivar royalties.

**Trade-Off / Risk:** Legal certainty and speed trade against each other: bilateral deals protect claims but slow breeding exchange, while pooled models accelerate access yet require benefit-sharing consensus that Nagoya-era negotiations have often struggled to reach.

**Strategic Connections:**

**Synergy:** Provides legally clean resistance sources to Resistance Breeding Pathway and, together with Research Knowledge Commons and IP Posture, sets consistent terms for data and cultivar sharing so partners trust the exchange.

**Conflict:** Benefit-sharing obligations and community co-ownership can slow transfers and add royalty burdens, constraining Resistance Breeding Pathway timelines and the open exchange of sequence data favored by Research Knowledge Commons and IP Posture.

**Justification:** *High*, Gatekeeps legally clean resistance sources for Brazil-led breeding; legal certainty versus speed of exchange directly constrains breeding timelines and data openness. Important dependency, but narrower in scope than the breeding pathway it feeds.

### Decision 7: Smallholder Transition Finance
**Lever ID:** `bff15d75-e0c1-4df9-ae7b-76e273e55704`

**The Core Decision:** Provides the financial bridge that lets smallholders replant with resistant clones or enter alternative crops despite income loss during the immature period. Scope covers instrument choice, eligibility tied to clean-plant use, and long-run fiscal or levy exposure. Metrics: replanting uptake among eligible smallholders, default or arrears rates, share of the poorest households reached, and income continuity before first tapping.

**Why It Matters:** Replanting a rubber tree takes years before tapping begins, so smallholders bear an income gap that standard credit rarely covers. The finance design determines whether farmers adopt resistant cultivars and alternative crops or hold out on existing trees. Subsidized instruments boost uptake but create ongoing fiscal exposure and moral-hazard risk across the 25-year horizon.

**Strategic Choices:**

1. Offer concessional replant loans through national agricultural banks, paired with clean-plant nursery vouchers and extension visits, repaid from future latex income once new trees come into production.
2. Provide income-bridging payments during the immature period, funded by a levy on participating OEMs and linked to verified clean-plant use and protocol compliance on the farm.
3. Organize farmers into cooperatives that hold equity in colocated processing plants and receive price-floor contracts, so adoption finance is tied to shared ownership of downstream value.

**Trade-Off / Risk:** Adoption depends on bridging years of lost income, yet each bridging instrument creates long fiscal or levy obligations, and cooperative equity models can concentrate benefits in better-organized farmers while leaving the poorest smallholders outside.

**Strategic Connections:**

**Synergy:** Amplifies Extension Corps and Nursery Workforce Pipeline by giving trained advisers and clean-plant nurseries a funded customer base, and pairs with Offtake and Strategic Reserve Design to deliver price-floor stability.

**Conflict:** Bridging payments and subsidies create long-term obligations competing for resources in Capital Stack and Sponsor Coalition, and compliance-linked conditions can clash with Containment Protocol Authority enforcement, penalizing the poorest farmers.

**Justification:** *High*, Determines whether smallholders actually adopt resistant clones and alternatives, which the plan is built around. Interacts with extension, offtake price floors, capital stack and containment enforcement; fiscal exposure versus uptake is the key trade-off.

### Decision 8: Offtake and Strategic Reserve Design
**Lever ID:** `b63e33ad-10fa-49ab-8102-1cac9b3ae5fb`

**The Core Decision:** Defines the contractual and physical mechanisms that convert alternative-rubber and resistant-Hevea output into bankable demand. Scope covers take-or-pay offtake, reservation-fee options and a jointly held reserve, including who bears price and quality risk. Success metrics: share of processing-plant capacity under contract, premium level versus Hevea benchmarks over time, reserve days-of-cover, and rotation losses.

**Why It Matters:** OEM offtake agreements underpin the bankability of alternative-rubber plants and resistant-cultivar planting, but buyers typically resist paying premiums for unproven supply. The contract form decides who carries price and quality risk. A physical reserve adds shock protection that offtake alone cannot, though storage and rotation costs persist regardless of whether a blight event occurs.

**Strategic Choices:**

1. Sign long-term take-or-pay offtake agreements with tire and industrial OEMs at a price formula indexed to Hevea benchmarks, with a modest premium that declines as alternative crop costs fall.
2. Establish a jointly funded strategic natural rubber reserve held by OEMs and governments, released during pathogen or climate shocks, reducing the need for guaranteed premium purchases.
3. Use a purchase-option structure in which OEMs pay a small annual reservation fee for priority access to alternative or resistant-Hevea volumes, converting to firm purchases only when specified quality benchmarks are met.

**Trade-Off / Risk:** Firm premium contracts make plants financeable but force buyers to pay for unproven material, whereas reserves and options shift risk toward the program and may not convince lenders that demand is real.

**Strategic Connections:**

**Synergy:** Firm offtake strengthens Capital Stack and Sponsor Coalition by giving lenders predictable revenue, and anchors Alternative Rubber Portfolio Breadth decisions by signalling which crops and processing sites buyers will actually take.

**Conflict:** Premium-bearing contracts and reserve funding compete for the same sponsor money as Smallholder Transition Finance, and rigid contract specifications may constrain Alternative Crop Land-Use Footprint choices before cost and quality evidence matures.

**Justification:** *High*, Converts alternative and resistant output into bankable demand and allocates price and quality risk between OEMs and the program. Strongly linked to capital stack, portfolio breadth, land use and smallholder price floors, with sponsor-money competition.

### Decision 9: Surveillance Sensing Architecture
**Lever ID:** `28da14ef-afcf-4d57-bfba-4837d4e31829`

**The Core Decision:** Selects how SALB incursions are found: inspector scouting, instrumented sensing with laboratory confirmation, or paid community sentinels. Scope includes detection latency, false-alarm rate, diagnostic confirmation capacity and data-sharing terms with host governments. Success metrics: median time from first infection to confirmed detection, share of nurseries and estates covered, and proportion of alerts verified within a set window (target to be defined).

**Why It Matters:** This sets how SALB incursions are detected: by inspector-led field scouting, by instrumented networks, or by a hybrid. Detection speed and false-alarm rates determine whether the containment protocol can trigger a response before spores spread beyond a nursery or estate. Heavier instrumentation raises up-front and maintenance costs and creates data-sharing questions with host governments.

**Strategic Choices:**

1. Fund a workforce-centered model in which trained national inspectors and estate scouts carry out scheduled field and nursery inspections, supported by standardized symptom-recognition training and portable diagnostic kits.
2. Deploy an instrumented network combining spore traps, drone or satellite canopy imaging, and laboratory molecular confirmation at regional hubs, with inspectors reserved for alert verification and response.
3. Build a participatory sentinel network in which smallholders, tappers and nursery operators are paid to report suspect symptoms through a simple channel, with a small expert team verifying and ranking reports.

**Trade-Off / Risk:** Instrumented detection promises earlier warning, but sensor networks and imaging pipelines are only as good as the ground-truth confirmation capacity behind them, and remote smallholder regions may lack the laboratories and connectivity to act on alerts.

**Strategic Connections:**

**Synergy:** Fast, trusted detection feeds Incursion Response Playbook triggers and supplies the field data that Gate Evidence Verification Regime needs to prove containment performance rather than rely on self-reporting.

**Conflict:** Heavy instrumentation consumes budget and laboratory capacity that Extension Corps and Nursery Workforce Pipeline also needs, and data-sharing demands may clash with the open-access aims of Research Knowledge Commons and IP Posture or host-government sovereignty.

**Justification:** *Medium*, Supplies detection and field evidence that trigger incursion response and gate verification. Important for the protocol, but largely an implementation choice under Containment Protocol Authority, with cost competition against extension and lab capacity.

### Decision 10: Clonal Mosaic Deployment Rules
**Lever ID:** `a707b612-246e-4d7c-ba40-584182145f67`

**The Core Decision:** Sets planting rules for released resistant cultivars to manage resistance durability against an evolving pathogen. Scope spans monoclonal freedom, mandated multi-clone blocks and staged sentinel-zone release, plus the monitoring that enforces them. Success metrics: number of distinct resistance sources per landscape, time to first observed resistance breakdown, grower compliance rates, and yield penalty relative to best-clone planting.

**Why It Matters:** This governs how released resistant cultivars are planted across landscapes: monoclonal blocks of the best performer, mandated multi-clone mosaics, or staged rotation of resistance sources. The choice shapes how long resistance lasts against a pathogen that can evolve, and what yield and uniformity growers give up in exchange. Mandating diversity also adds complexity to nursery planning and to the clean-plant networks that supply planting material.

**Strategic Choices:**

1. Allow growers to plant the highest-yielding resistant clone at scale, relying on the breeding pipeline to supply replacement cultivars quickly if resistance breaks down.
2. Require registered nurseries and funded replanting schemes to supply a minimum number of genetically distinct resistant clones per planting block or landscape, with deployment monitored by the program.
3. Stage release so that each resistant clone is first planted in a limited sentinel zone under heavy monitoring, with broad deployment authorized only after observed field durability across pathogen variants.

**Trade-Off / Risk:** A diversity mandate protects durability on paper, but smallholders choose clones for yield and tapping convenience, so compliance depends on nursery supply that may not stock enough distinct resistant material in the first decade.

**Strategic Connections:**

**Synergy:** Mosaic rules give Resistance Breeding Pathway a durable-deployment target and stagger demand on clean-plant nurseries, helping Extension Corps and Nursery Workforce Pipeline plan multi-clone supply and grower guidance.

**Conflict:** Diversity mandates limit grower yield choice and reduce uniformity, straining Smallholder Transition Finance uptake, and require more distinct released cultivars than Resistance Breeding Pathway may deliver in the early years.

**Justification:** *Low*, Tactical deployment rules that matter only after resistant cultivars are released (post-Year 7 timeframe). Largely dependent on breeding output and nursery supply, with limited influence on early-phase strategic trade-offs.

### Decision 11: Research Knowledge Commons and IP Posture
**Lever ID:** `51ba045c-6820-4d80-a001-ad70e5467a51`

**The Core Decision:** Establishes ownership, access and licensing rules for genomic data, diagnostics, protocols and elite cultivar traits created with program funds. Scope covers open commons, tiered licensing and producer-country data trusts, including royalty treatment for smallholders. Success metrics: number of national programs and breeders using shared data, private co-investment attracted, royalty burden on smallholders, and absence of benefit-sharing disputes.

**Why It Matters:** This determines how genomic data, diagnostics, protocols and cultivar traits generated by public-private funding are owned and shared. Open release speeds adoption and trust among rubber-producing nations but weakens the commercial incentive for private breeders and processors to co-invest. Restricted IP attracts industry capital but risks fragmenting the response and leaving smallholders paying royalties on planting material.

**Strategic Choices:**

1. Release genomic datasets, diagnostics and non-commercial protocols into an open commons with immediate access, reserving patent protection only for narrowly defined commercial processing innovations.
2. Adopt a tiered licensing model in which pre-competitive data is shared openly, while elite cultivars and extraction methods are licensed with royalty-free terms for smallholders and paid terms for large estates and OEMs.
3. Create a jointly governed data trust held by producer-country institutions, with access, publication timing and commercial use decided by a board that includes growers' representatives and funders.

**Trade-Off / Risk:** Open data builds trust and speeds the response, but it also gives competitors and non-participating states free access to program-funded results, which can weaken private co-investment and complicate benefit-sharing commitments elsewhere in the plan.

**Strategic Connections:**

**Synergy:** Open or governed data sharing supports Germplasm Access and Benefit-Sharing Model by giving provider countries visible returns, and accelerates Resistance Breeding Pathway by letting multiple national programs build on shared genomic results.

**Conflict:** Open release weakens the private incentive that Capital Stack and Sponsor Coalition and Offtake and Strategic Reserve Design rely on, while restricted licensing risks undermining trust with germplasm provider countries and smallholder adoption.

**Justification:** *Medium*, Balances open-data speed and trust against private co-investment incentives. Touches breeding, benefit-sharing and sponsor motivation, but is an optimization of data governance rather than a driver of the core containment or supply outcomes.

### Decision 12: Alternative Crop Land-Use Footprint
**Lever ID:** `074e8965-5504-4928-acbd-a03bf44001fc`

**The Core Decision:** Decides where guayule and Russian dandelion are planted and which land uses they displace, fixing feedstock cost per tonne, water demand and food-security optics. Success metrics include hectares sited through documented suitability screening, delivered feedstock cost and rubber quality at each gate, water use per tonne, and absence of tenure or food-price disputes near processing sites.

**Why It Matters:** This sets where guayule and Russian dandelion are grown and what land they displace. Siting on marginal or fallow land protects food supply and local acceptance but may limit yields and logistics, while competing for better farmland raises output but triggers conflicts with food crops and tenure disputes. The choice also shapes water demand in arid zones and the credibility of the program's climate-resilience claims.

**Strategic Choices:**

1. Restrict alternative crop expansion to degraded, fallow or marginal land identified through a land-suitability screening process, accepting lower initial yields and slower acreage growth.
2. Integrate alternative crops into existing farm rotations and cover-crop systems on smallholdings, using the rubber crop as a cash complement rather than a replacement for staple production.
3. Establish contiguous contract-farming blocks near processing plants on land leased from public agencies or large landholders, prioritizing logistics efficiency and consistent feedstock over dispersed smallholder planting.

**Trade-Off / Risk:** Restricting crops to marginal land avoids food competition, but low-yield sites inflate feedstock cost per tonne, and the cost and quality KPIs at the gates may then be missed for reasons unrelated to crop genetics.

**Strategic Connections:**

**Synergy:** Pairs with Alternative Rubber Portfolio Breadth, since siting rules determine which crop fits which agro-ecology, and with Offtake and Strategic Reserve Design, because contiguous or predictable acreage gives OEMs credible, quality-consistent supply volumes.

**Conflict:** Restricting planting to marginal land tensions with Gate Evidence Verification Regime, because low yields can miss cost KPIs, and with Smallholder Transition Finance, since dispersed or leased-block models shift who captures income.

**Justification:** *Medium*, Fixes feedstock cost, water demand and food-security optics for Guayule and dandelion. Important to cost KPIs, but largely derivative of portfolio breadth and offtake decisions, so it is a secondary siting choice.

### Decision 13: Incursion Response Playbook
**Lever ID:** `0e1b59d2-79d2-4fb7-85d4-7a0d876f06f0`

**The Core Decision:** Pre-agrees the operational and financial doctrine for responding when SALB appears in a currently unaffected region: who destroys, compensates, replants and communicates, and how quickly. Key metrics are time from confirmed detection to action, share of suspected infections voluntarily reported, compensation paid within agreed timeframes, and spread radius after the first confirmed case.

**Why It Matters:** Defines in advance what happens when SALB is detected in a region where it is absent. A pre-agreed response avoids delay and dispute at the moment speed matters most, but each response model assigns very different costs to growers and governments. The choice also affects whether growers report suspected infections or conceal them.

**Strategic Choices:**

1. Adopt an eradication-first doctrine that destroys infected plantings and a surrounding buffer, with compensation to affected growers pre-committed from the program.
2. Adopt a managed-coexistence doctrine that accepts local establishment and moves quickly to replanting with tolerant clones and protective spray regimes.
3. Pre-position regional rapid-response brigades together with reserve nurseries of pre-multiplied clean planting material, so either doctrine can be executed within days of confirmed detection.

**Trade-Off / Risk:** Eradication-first protects uninfected regions but only works if compensation is paid fast enough to deter concealment, while coexistence quietly concedes that containment has failed and may undermine the gate logic itself.

**Strategic Connections:**

**Synergy:** Depends on and strengthens Surveillance Sensing Architecture, where early detection triggers action, and Extension Corps and Nursery Workforce Pipeline, whose field staff supply trusted reporting and execute replanting with clean stock.

**Conflict:** Eradication-first compensation commitments strain Capital Stack and Sponsor Coalition liquidity, while coexistence doctrine conflicts with Containment Protocol Authority, whose protocol assumes exclusion and could be undermined by accepted establishment.

**Justification:** *Medium*, Pre-agrees doctrine for responding to outbreaks and shapes grower reporting behavior. Valuable for resilience, but depends on surveillance and the protocol for its triggers and mandate, and its funding draws on the capital stack.

### Decision 14: Extension Corps and Nursery Workforce Pipeline
**Lever ID:** `d24ce39b-2da1-42bc-8d96-a8ae27a59ef8`

**The Core Decision:** Chooses the human delivery system that carries clean planting material, replanting guidance and alternative-crop agronomy to smallholders over decades. Performance is measured by trained agents and nurseries per smallholder served, share of lots passing inspection, farmer retention and adoption rates, cost per farmer reached, and the ability to scale before cultivars and alternative crops mature.

**Why It Matters:** Sets who physically delivers clean-plant networks, replanting support and crop-specific agronomy to smallholders. The program's adoption targets depend on trained people in the field long before cultivars or alternatives are ready. Each delivery model trades control over quality against speed of coverage and long-term local ownership.

**Strategic Choices:**

1. Recruit and train a dedicated program-employed cadre of extension agents and nursery technicians, accepting higher fixed cost in exchange for consistent standards and direct accountability.
2. Subcontract delivery to national rubber research institutes and farmer cooperatives through capacity grants, relying on existing trusted relationships and local institutional continuity.
3. License smallholder-run nurseries as certified micro-multipliers of clean planting material, paying peer stewards per verified plant lot and inspection passed.

**Trade-Off / Risk:** Licensed micro-multipliers widen coverage cheaply, but every additional nursery is another potential pathway for contaminated stock, so inspection capacity must grow in step or the clean-plant network becomes a containment liability.

**Strategic Connections:**

**Synergy:** Operationalizes Smallholder Transition Finance, since farmers need advisory support to use replant credit, and gives Resistance Breeding Pathway and Clonal Mosaic Deployment Rules a trusted channel to get new clones planted correctly.

**Conflict:** Wide, low-cost nursery networks strain Containment Protocol Authority and Surveillance Sensing Architecture, because each added multiplier needs inspection capacity, and larger employed cadres compete with Capital Stack and Sponsor Coalition budgets.

**Justification:** *High*, Physical delivery channel for clean plants, replanting and agronomy; operationalizes finance, breeding and clonal deployment. Coverage-versus-containment-risk trade-off ties it to inspection capacity and budgets, making it a key execution hub.
