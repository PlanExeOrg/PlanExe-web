## Primary Decisions
The vital few decisions that have the most impact.


The Critical levers (Containment Protocol Legal Architecture, Resistance Breeding Strategy, Stage-Gate and Capital Release Design, Program Governance, Capital Stack) address the core tensions: binding enforcement versus adoption speed, durable resistance versus gate timelines, funder discipline versus biological uncertainty, and central authority versus sovereign ownership. High levers cover adoption, demand and handover. No major strategic dimension appears missing, though climate-shock resilience is thinly covered.

### Decision 1: Containment Protocol Legal Architecture
**Lever ID:** `e9a70833-c815-4a8c-9875-f7f313f9d7fd`

**The Core Decision:** Defines the legal force, scope and audit mechanism of the SALB Containment Protocol covering nursery stock, research material and equipment. Success metrics include the number of producing countries with enforceable import rules, the share of national inspectorates trained and audited, and documented interceptions. The design must produce verifiable evidence that the Year 3 gate can score, rather than stated intent.

**Why It Matters:** This lever sets how binding the SALB Containment Protocol is on nursery stock, research material and equipment movement. A binding instrument raises compliance but takes longer to negotiate, while a voluntary code is quick to adopt but leaves gaps at the weakest border. The choice determines whether Phase 1 can gate Year 3 funding on verified containment rather than on stated intent.

**Strategic Choices:**

1. Negotiate the protocol as a standard under the international plant protection framework, so that national plant protection organizations adopt it into their import rules and are audited against it.
2. Launch an industry-and-donor-backed certification code that links access to program funding and OEM procurement to protocol compliance, while formal intergovernmental adoption proceeds in parallel.
3. Build a regional compact among SALB-free producing countries in Asia and Africa first, with reciprocal inspection rights and shared quarantine facilities, and extend it to Latin America only after its inspection regime has been tested.

**Trade-Off / Risk:** A treaty-grade protocol is slow, and a voluntary one is easy to evade, so the real risk is that the Year 3 gate arrives before the weakest-link countries have enforceable obligations or inspectors.

**Strategic Connections:**

**Synergy:** Amplifies Early-Detection Surveillance Technology Mix and Outbreak Response and Eradication Contingency Doctrine by giving inspections and response actions legal standing. It also strengthens Stage-Gate and Capital Release Design by making containment performance measurable and auditable.

**Conflict:** Binding obligations slow adoption and strain Producer-Country Institutional Capacity and Technology Transfer, since weak-link countries lack inspectors. They can also delay Resistance Field-Trial Geography and Biosafety Siting, because material movement rules tighten before trials begin.

**Justification:** *Critical*, Critical because it underpins the non-negotiable Phase 1 deliverable and the Year 3 gate. It is a hub that gives legal standing to surveillance and response, makes gating auditable, and trades off against producer capacity and trial timing.

### Decision 2: Resistance Breeding Strategy
**Lever ID:** `e7c241d4-6a63-4be2-a3b6-425a9814c3fd`

**The Core Decision:** Chooses the technical route to SALB-resistant, yield-parity Hevea: gene pyramiding, grafted canopy-panel systems, or gene editing. It governs resistance durability against pathogen evolution, time to yield parity and nursery practicality. Success metrics include the number of independent resistance sources per cultivar, multi-site trial yield relative to elite clones, and stability of resistance over time.

**Why It Matters:** This lever sets how SALB-resistant, yield-parity Hevea is produced and how durable the resistance will be. Rapid single-source resistance risks pathogen adaptation. Broader polygenic strategies take longer to reach yield parity and need long field trials in SALB-endemic sites. The choice shapes the Year 7 and Year 12 cultivar-readiness gates.

**Strategic Choices:**

1. Pyramid several resistance sources from wild Brazilian accessions into elite Asian high-yield clones using genomic selection, and test them at multiple SALB hotspot sites under the containment protocol.
2. Use a crown-and-trunk grafting system that pairs a resistant leaf canopy with a high-latex panel clone, so that resistance and yield are bred in separate lines and combined at the nursery.
3. Run a parallel gene-editing track aimed at susceptibility genes in elite clones, and carry it forward only where regulators in the main producing countries have confirmed a viable approval route.

**Trade-Off / Risk:** Pyramiding is the most durable route but the slowest, and grafting adds nursery cost and labor for smallholders. Gene editing could skip decades of back-crossing but may meet regulatory or market resistance that delays adoption.

**Strategic Connections:**

**Synergy:** Depends on and amplifies Pathogen Population Genomics and Virulence Tracking, which shows which resistance genes the pathogen can overcome, and on Clean Planting-Material Propagation Technology, which multiplies the resulting clones quickly and disease-free.

**Conflict:** Slow, durable pyramiding strains Stage-Gate and Capital Release Design, since Year 7 and Year 12 cultivar-readiness gates may arrive early. Grafting adds nursery cost that works against Smallholder Replanting Finance and Price Stability affordability.

**Justification:** *Critical*, Critical because it defines the core technical route to durable, yield-parity resistant Hevea. It links genomics, trials, propagation, finance and the Year 7/12 gates, and controls the speed-versus-durability trade-off for the whole program.

### Decision 3: Stage-Gate and Capital Release Design
**Lever ID:** `c68c4cec-ab5f-43ee-ac7f-911eff4e3ff5`

**The Core Decision:** Defines the rules, evidence standards and verification machinery by which funding is released or withheld at Years 3, 7, 12 and 18. Scope includes KPI definitions, threshold setting, panel independence, treatment of unspent capital, and appeal routes. Success is measured by gate decisions that funders, producer states and OEMs accept as credible, and by avoiding both wasted tranches and premature termination.

**Why It Matters:** This lever sets how funding at Years 3, 7, 12 and 18 is tied to containment, cultivar readiness and alternative-rubber KPIs. Rigid gates protect public money but can stop a program just before a delayed breakthrough. Flexible gates keep momentum but weaken the discipline that gives funders confidence over 25 years.

**Strategic Choices:**

1. Apply fixed pass-or-stop gates with pre-agreed numeric thresholds, verified by an independent technical panel, with unspent funds returned to contributors if a gate is failed.
2. Use adaptive tranches that release partial funding on partial KPI attainment, with the remainder reallocated among the three pillars according to which pathway shows the strongest evidence.
3. Create a standing portfolio board that can pre-commit a reserve to the best-performing pathway after each gate, and publishes all gate evidence so that outside parties can challenge decisions.

**Trade-Off / Risk:** Fixed gates give funders certainty but treat biological timelines as if they were predictable. Adaptive reallocation handles this better, though it opens discretion that members may use to protect favored pillars.

**Strategic Connections:**

**Synergy:** Reinforces Program Governance and Decision Rights by giving the governing body enforceable, evidence-based decisions, and strengthens Capital Stack and Industry Levy Mechanism by giving contributors confidence that money is released only against verified containment, cultivar and cost/quality results.

**Conflict:** Strict gating conflicts with Resistance Breeding Strategy, whose multi-year biological timelines slip unpredictably, and with OEM Offtake and Demand Commitments, since plant finance needs revenue certainty that a possible gate failure undermines.

**Justification:** *Critical*, Critical because it is the central hub for the Year 3/7/12/18 funding gates. It controls the discipline-versus-flexibility trade-off and conflicts with breeding timelines, offtake certainty and capacity building, while reinforcing governance and funding.

### Decision 4: Program Governance and Decision Rights
**Lever ID:** `70d94c4e-e870-43ef-817f-f3ae44c6fabb`

**The Core Decision:** Allocates authority across a 25-year horizon among funders, producer governments, OEMs and technical bodies for budget release, protocol enforcement and strategy change. It determines institutional durability through funder turnover and election cycles. Success metrics include producer-state participation, decision latency, continuity of staff and mandate, and the share of gate decisions upheld without political reversal.

**Why It Matters:** This lever sets who holds authority over budget release, protocol enforcement, and strategy changes across a 25-year horizon. A tightly centralized body can act quickly on gate decisions but risks losing buy-in from producer countries, while a distributed model improves legitimacy but slows responses. The choice also shapes how resilient the program is to funder turnover and political cycles.

**Strategic Choices:**

1. Establish an independent multilateral secretariat with its own board, binding authority over gate decisions, and seats for producer governments, OEMs, and development lenders.
2. Operate through a lead-nation consortium, with Brazil and two or three major producer states sharing rotating chairs and delegating execution to existing agricultural research institutions.
3. Create a purpose-built endowment-backed foundation whose trustees are bound by a charter and independent technical panels, insulating gate decisions from annual political budgeting.

**Trade-Off / Risk:** Governance form determines whether gate decisions at Years 3/7/12/18 are credible, yet a powerful secretariat may be rejected by sovereign producers who see it as externally imposed control over their rubber sector.

**Strategic Connections:**

**Synergy:** Provides the legitimacy and enforcement base that Containment Protocol Legal Architecture needs for cross-border compliance, and gives Stage-Gate and Capital Release Design a decision-maker whose gate calls are credible and binding.

**Conflict:** Strong central authority trades off against Producer-Country Institutional Capacity and Technology Transfer, since sovereign producers resist externally imposed control, and against Germplasm Access and Benefit-Sharing Model, where Brazil and others expect decision rights over genetic resources.

**Justification:** *Critical*, Critical because it determines who enforces the protocol and makes gate decisions over 25 years. It is a hub for legitimacy and durability, and holds the tension between central authority and sovereign producer and Brazilian rights.

### Decision 5: Capital Stack and Industry Levy Mechanism
**Lever ID:** `8d912592-bc0b-4d43-b3e9-e3123b4bda27`

**The Core Decision:** Determines the funding architecture for the $30 billion (user constraint) over 25 years: the mix of sovereign grants, development-bank lending, industry levy, in-kind contributions and outcome-linked instruments. Success metrics include share of commitments that are legally binding, resilience of cash flows to political turnover, and alignment of obligations with stage-gate releases. It also shapes who holds governance leverage.

**Why It Matters:** Decides where the $30 billion comes from and how obligations are shared among governments, development banks, tyre makers and rubber traders. A dedicated levy gives predictable money but needs agreement from competitors and producers. Reliance on grants and appropriations exposes the 25-year horizon to political cycles and budget shifts.

**Strategic Choices:**

1. Fund the program mainly from sovereign and multilateral development-bank commitments, with industry contributing in-kind through trials, processing capacity and offtake.
2. Create a per-tonne industry levy on natural rubber trade or tyre production that pays into a ring-fenced fund governed jointly by producers and consumers.
3. Issue outcome-linked bonds or insurance-style instruments where investors are repaid from avoided-loss payouts if containment and cultivar milestones are met.

**Trade-Off / Risk:** A levy yields stable multi-decade money but requires cartel-like coordination and may be resisted by price-sensitive buyers, whereas grant-led funding is easier to launch yet most vulnerable to political turnover mid-program.

**Strategic Connections:**

**Synergy:** Enables Stage-Gate and Capital Release Design by supplying predictable, ring-fenced money to release at gates. Reinforces OEM Offtake and Demand Commitments, since tyre makers that contribute financially have stronger reasons to commit to purchasing.

**Conflict:** A levy or industry-heavy stack conflicts with Program Governance and Decision Rights, as payers will demand control. It may also pull against OEM Offtake and Demand Commitments if buyers resist both levy costs and premium alternative-rubber prices.

**Justification:** *Critical*, Critical because it determines how the $30 billion (user constraint) is sourced and sustained over 25 years. It enables gated releases, shapes governance leverage and OEM alignment, and competes with response and smallholder spending.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Germplasm Access and Benefit-Sharing Model
**Lever ID:** `55230c77-3383-468a-a738-d9ee734aef01`

**The Core Decision:** Sets the legal and ethical basis for collecting wild Hevea germplasm in Brazil under the Nagoya Protocol and national access rules. It decides who holds title, who shares benefits and how fast accessions reach breeders. Success metrics include the number of accessions cleared per year, the absence of legal challenges, and community-reported trust and benefit delivery.

**Why It Matters:** This lever determines how Brazil-led collection of wild Hevea germplasm complies with the Nagoya Protocol and national access rules. Case-by-case bilateral agreements give clear legal title but are slow to negotiate. Pooled models speed up breeding but depend on trust from Brazil and from the communities in whose territories the material is found.

**Strategic Choices:**

1. Negotiate individual access agreements with Brazilian authorities and local communities for each collection campaign, with benefits tied to the specific accessions used in released cultivars.
2. Establish a standing multilateral benefit-sharing fund, financed by a levy on cultivar royalties and rubber sales, that pre-clears pooled access for member breeding programs under common terms.
3. Give indigenous and traditional communities co-ownership of resistance-trait data and royalty rights, with community-run sampling and a governance seat in the breeding consortium.

**Trade-Off / Risk:** Community co-ownership strengthens legitimacy and legal durability, but it adds negotiation parties and may slow collection. A pooled fund is faster but invites challenges that benefits did not reach those who hold the genetic resources.

**Strategic Connections:**

**Synergy:** Enables Resistance Breeding Strategy by securing cleared, durable access to diverse resistance sources. It also pairs with Capital Stack and Industry Levy Mechanism, which could fund a benefit-sharing pool from royalties and rubber sales.

**Conflict:** Community co-ownership and per-campaign negotiation slow collection, which pressures the cultivar-readiness timeline in Resistance Breeding Strategy and Stage-Gate and Capital Release Design. Royalty-sharing claims may also complicate Program Governance and Decision Rights over who decides.

**Justification:** *High*, High because it gates access to the wild Hevea resistance sources that breeding depends on. It carries legal and legitimacy risk and conflicts with governance decision rights and cultivar-readiness timelines, but it is mainly a single-pillar enabler.

### Decision 7: Alternative Rubber Portfolio and Processing Siting
**Lever ID:** `a918de32-a470-4cde-b956-ad7ab9fafdc0`

**The Core Decision:** Determines the pace, crop mix and location of Guayule and Russian dandelion scale-up and colocated processing. It balances capital lock-in against the value of a real fallback supply. Success metrics include cost per tonne and tire-grade quality against Hevea, hub utilization, co-product revenue share, and the number of farmers participating in each region.

**Why It Matters:** This lever decides how aggressively Guayule and Russian dandelion are scaled, and where processing is colocated. Early commercial plants lock in capital before cost and quality are proven. Slower pilots protect capital but delay a real supply fallback. Siting near OEMs or near growers changes logistics cost and which farmers benefit.

**Strategic Choices:**

1. Build one or two integrated commercial hubs per crop in the best-suited regions, with colocated extraction, and expand only after the Year 7 cost and quality KPIs are met.
2. Fund distributed small-scale processing units close to growers, owned by cooperatives, accepting higher unit costs in exchange for broader farmer participation and lower transport losses.
3. Treat the two crops as a co-product play, valuing resins, bagasse, and inulin streams alongside rubber so that processing economics do not depend on matching Hevea prices.

**Trade-Off / Risk:** Large hubs move faster toward tire-grade volumes but concentrate capital and agronomic risk in a few sites. Co-product revenue improves economics on paper, yet it depends on markets for those by-products that may stay thin.

**Strategic Connections:**

**Synergy:** Works with OEM Offtake and Demand Commitments, because committed buyers de-risk processing capital and drive quality qualification. It also benefits from Capital Stack and Industry Levy Mechanism for patient funding of early hubs.

**Conflict:** Large early hubs compete for the same capital as Resistance Breeding Strategy and Clean Planting-Material Propagation Technology. Hub-centric siting also conflicts with Smallholder Replanting Finance and Price Stability goals of broad farmer participation.

**Justification:** *High*, High because it governs the second supply pillar and the capital lock-in versus fallback-supply trade-off. It connects to offtake, funding and smallholder participation, but depends on those levers to be bankable.

### Decision 8: Smallholder Replanting Finance and Price Stability
**Lever ID:** `0f1da053-2072-4118-86dd-3ac4e4ef6fbb`

**The Core Decision:** Provides the financial means for smallholders to replant with resistant clones or switch crops, bridging years without income and buffering price swings. Its scope covers loans, income bridges, price-stabilization facilities and outcome premiums. Success metrics include replanting uptake, repayment rates, fiscal exposure under low-price scenarios, and the share of farmers in surveillance and clean-plant schemes.

**Why It Matters:** This lever determines whether smallholders can afford to replant with resistant clones or switch crops, given the years without income that replanting involves. Subsidized loans and price floors raise adoption but create fiscal exposure that grows if rubber prices fall. Weak adoption would leave the new cultivars unplanted when they are ready.

**Strategic Choices:**

1. Provide long-tenor replant loans with an income-bridge during immature years, repaid from future latex sales and conditional on buying certified clean planting material from the program's nursery network.
2. Offer a farmer-cooperative price-stabilization facility using forward contracts and a reserve fund, with payouts triggered by a published price index and not by individual farm assessment.
3. Pay farmers outcome-based premiums for verified clean-plant practices and disease reporting, so that surveillance participation is rewarded and becomes part of farm income.

**Trade-Off / Risk:** Bridge loans solve the cash-flow gap but add debt to farmers who already face price volatility. Outcome premiums align incentives with surveillance, but verification costs can consume much of the payment at smallholder scale.

**Strategic Connections:**

**Synergy:** Amplifies Clean Planting-Material Propagation Technology by guaranteeing demand for certified planting stock, and strengthens Early-Detection Surveillance Technology Mix by rewarding farmers who report disease and follow clean-plant practices.

**Conflict:** Subsidized loans and price floors create fiscal exposure that competes with Capital Stack and Industry Levy Mechanism funding for breeding and alternatives. Debt-heavy bridge loans may also undermine adoption if the Stage-Gate and Capital Release Design pauses funding.

**Justification:** *High*, High because smallholder adoption is a design principle and determines whether cultivars are planted. It creates fiscal exposure that competes with other funding, and links to propagation, surveillance incentives and gating.

### Decision 9: OEM Offtake and Demand Commitments
**Lever ID:** `ad6f3ca0-f476-45ef-ace3-91ae5c5e22d5`

**The Core Decision:** Determines how tire and rubber-goods manufacturers translate interest into binding purchase volumes, price formulas and shared qualification protocols. It sets the demand signal for Guayule, Russian dandelion and resistant-Hevea output. Key metrics are contracted tonnage, share of tire-grade versus niche volume, qualification pass rates, and the proportion of processing capex financed by offtake-backed debt rather than grants.

**Why It Matters:** This lever decides how tire and rubber-goods manufacturers commit to buying alternative rubber and resistant-Hevea output. Firm commitments give processors bankable revenue and justify capital, but manufacturers will only sign if quality qualification is credible. Weak commitments leave plants reliant on grants.

**Strategic Choices:**

1. Sign take-or-pay offtake contracts with a group of OEMs for staged volumes at a price formula linked to natural rubber benchmarks, conditional on material meeting agreed qualification tests.
2. Form a buyer consortium that pools demand and funds shared tire-grade qualification testing, so that no single OEM carries the validation cost or gains exclusive access.
3. Start with niche, high-value uses such as medical gloves, hypoallergenic goods and specialty products, where latex purity commands a premium, and use that revenue to fund the move toward tire-grade volumes.

**Trade-Off / Risk:** Take-or-pay contracts underpin plant finance but are hard to obtain before quality is proven. Niche markets pay well, yet they are small and may not demonstrate that tire-scale supply is achievable.

**Strategic Connections:**

**Synergy:** Amplifies Alternative Rubber Portfolio and Processing Siting by making colocated plants bankable, and supports Capital Stack and Industry Levy Mechanism by letting private and lender capital replace grants once contracts exist.

**Conflict:** Firm take-or-pay terms strain Stage-Gate and Capital Release Design, because OEMs want volume certainty while gates may halt funding; they also compete with Smallholder Replanting Finance and Price Stability over price-formula and risk allocation.

**Justification:** *High*, High because bankable demand turns alternative-rubber plants from grant-dependent into financeable. It links processing, capital stack and gating, with tension over take-or-pay certainty versus gate risk.

### Decision 10: Early-Detection Surveillance Technology Mix
**Lever ID:** `11b1aa1e-54a0-42fe-bd0a-634d105319e7`

**The Core Decision:** Chooses the sensing mix used to find SALB incursions in Asia and Africa before establishment, spanning remote sensing, community scouting and spore or eDNA sampling. It governs detection lead time, coverage of smallholder areas, false-alarm rates, and sample-to-laboratory turnaround. Value depends on a pre-authorized response path, so success is measured as time from incursion to confirmed action.

**Why It Matters:** This lever decides how SALB incursions are detected before they establish in the Asian and African rubber belt. Heavier investment in remote sensing and molecular diagnostics shortens detection time but adds equipment, training, and data-sharing burdens. Reliance on human field scouting is cheaper per site but leaves large smallholder areas poorly covered.

**Strategic Choices:**

1. Deploy satellite and drone canopy-monitoring across major plantation zones, triggering targeted ground sampling and laboratory confirmation when anomalies appear.
2. Fund a dense network of trained smallholder-community scouts using mobile reporting tools and low-cost field diagnostic kits, with regional laboratories confirming suspect samples.
3. Install airborne spore traps and environmental DNA sampling at ports, nurseries, and wind-corridor sentinel plots, treating spore detection as the primary early-warning signal rather than visible symptoms.

**Trade-Off / Risk:** Sophisticated sensing looks decisive on paper, but detection without a funded, pre-authorized response capacity only produces earlier knowledge of an outbreak that cannot be stopped, and false alarms may erode farmer cooperation.

**Strategic Connections:**

**Synergy:** Feeds Outbreak Response and Eradication Contingency Doctrine with timely triggers, and pairs with Pathogen Population Genomics and Virulence Tracking, since detected samples supply isolates for strain characterization and pathway attribution.

**Conflict:** Heavy sensing and data-sharing burdens compete for budget and staff with Producer-Country Institutional Capacity and Technology Transfer, and high false-alarm rates can undermine farmer cooperation needed by Smallholder Replanting Finance and Price Stability.

**Justification:** *Medium*, Medium because it is important for verifying containment, but its value depends on response capacity and legal standing set by other levers. The technology choice is largely an optimization within the containment pillar.

### Decision 11: Resistance Field-Trial Geography and Biosafety Siting
**Lever ID:** `b9245e75-a609-4ec1-9b15-710afd696c03`

**The Core Decision:** Decides where resistant candidates face real or simulated pathogen pressure and how trial sites are isolated to prevent escape. It sets the evidence base for cultivar readiness at the gates, including genotype-by-environment transfer to Asia and Africa. Metrics include disease-pressure realism, containment incident count, cross-continent result correlation, and time from screening to finalist selection.

**Why It Matters:** This lever determines where candidate cultivars are exposed to the pathogen and how trial sites are isolated. Trialing only in endemic Latin American sites gives real disease pressure but poorly represents Asian and African growing conditions. Moving trials to new regions would test performance locally but risks introducing the pathogen to uninfected areas.

**Strategic Choices:**

1. Concentrate all disease-pressure trials in endemic Latin American sites, then evaluate agronomic performance of survivors separately in Asian and African clean-zone plots without the pathogen.
2. Build a small number of high-containment trial stations in endemic regions with paired clean-zone sites elsewhere, using shared protocols so results transfer between continents.
3. Use controlled-environment inoculation facilities and detached-leaf assays at scale to screen early, reserving costly open-field trials for a narrow set of finalists.

**Trade-Off / Risk:** Trial siting balances realism against biosecurity, but screening in contained facilities may fail to predict field durability, and conducting the final tests only in Latin America may miss genotype-by-environment effects in Asian plantations.

**Strategic Connections:**

**Synergy:** Strengthens Resistance Breeding Strategy by providing validated selection data, and works with Pathogen Population Genomics and Virulence Tracking so trial strains represent the virulence diversity cultivars will meet in the field.

**Conflict:** Biosafety restrictions on moving material conflict with Containment Protocol Legal Architecture if trials require cross-border transfers, and costly high-containment stations compete with Germplasm Access and Benefit-Sharing Model and breeding budgets for limited funds.

**Justification:** *Medium*, Medium because it shapes the evidence for cultivar readiness and balances realism against biosecurity. It is subordinate to the breeding strategy and largely an execution-level choice, with moderate conflicts with protocol and budget.

### Decision 12: Outbreak Response and Eradication Contingency Doctrine
**Lever ID:** `7271877a-e1d5-4b39-872d-d86ebf61f8d7`

**The Core Decision:** Sets the pre-agreed playbook for a SALB incursion into a currently free region (notably Asia and Africa): trigger criteria, legal authority for tree removal, compensation rules, funding source and deployment timelines. Success metrics include time from confirmed detection to action, share of infections reported voluntarily, and drill performance. It turns the Containment Protocol from a document into an operational capability.

**Why It Matters:** This lever defines what happens if SALB is detected in a currently free region, including who pays, who can order destruction of plantings, and how quickly. Pre-agreed rules and funding enable fast action, but compulsory removal of farmers' trees without compensation can provoke concealment of infections. Weak doctrine leaves the containment protocol as paperwork when a real incursion occurs.

**Strategic Choices:**

1. Pre-fund a standing rapid-response facility with compensation schedules for farmers, legal authority for targeted tree removal, and mobile teams deployable within agreed timelines (proposed target).
2. Adopt a containment-and-suppression approach that relies on fungicide programs, tolerant clone substitution, and movement restrictions rather than mandatory eradication, accepting that the pathogen may persist at low levels.
3. Negotiate regional mutual-aid pacts in which neighboring producer states pre-commit personnel, equipment, and quarantine zones, with costs shared through a parametric insurance trigger tied to confirmed detection.

**Trade-Off / Risk:** A compensation-backed eradication doctrine rewards honest reporting, but it creates a large contingent liability that is hard to size in advance, and fungicide-led suppression may merely delay a wider epidemic.

**Strategic Connections:**

**Synergy:** Amplifies Early-Detection Surveillance Technology Mix, since fast detection only has value if a funded response follows. Also strengthened by Containment Protocol Legal Architecture, which supplies the legal authority for removal and cross-border quarantine zones.

**Conflict:** Competes with Capital Stack and Industry Levy Mechanism, because a compensation-backed standing facility creates a contingent liability that is hard to size. Compensation also strains Smallholder Replanting Finance and Price Stability budgets.

**Justification:** *High*, High because it turns the protocol into operational capability and sets the contingent-liability trade-off. It determines whether surveillance has value and competes with funding and smallholder budgets.

### Decision 13: Producer-Country Institutional Capacity and Technology Transfer
**Lever ID:** `507840ad-eb56-4f5c-9d39-545b2e878edd`

**The Core Decision:** Builds the long-term ability of producer-country agriculture ministries, quarantine services and rubber research institutes to enforce the protocol, run clean nurseries and adopt new cultivars after external funding ends. Success metrics include certified inspector numbers, inspection coverage, staff retention, and national ownership of protocols and labs at each stage-gate. It addresses the handover risk of the 25-year horizon.

**Why It Matters:** This lever determines whether national agricultural agencies, quarantine services, and rubber research institutes in Asia and Africa can implement the protocol and adopt new cultivars after external funding ends. Strong capacity investment improves long-term compliance and local ownership but delays visible technical results. Neglecting it leaves the program dependent on foreign experts and fragile at handover.

**Strategic Choices:**

1. Fund multi-year twinning arrangements between Brazilian and producer-country institutes, embedding staff exchanges, joint laboratories, and co-authored protocols that stay in national hands.
2. Create regional training academies for plant-health inspectors, nursery managers, and breeders, certifying skills against the containment protocol and linking certification to funding eligibility.
3. Pay national agencies performance-based grants that reward verified inspection coverage and clean-nursery output, leaving each country to choose how to build its own workforce.

**Trade-Off / Risk:** Capacity building underpins sustained compliance, yet training outcomes are slow to measure, staff often leave for private employers, and performance-based grants can favor better-resourced countries over those most exposed to SALB risk.

**Strategic Connections:**

**Synergy:** Enables Early-Detection Surveillance Technology Mix and Clean Planting-Material Propagation Technology, because trained inspectors and nursery managers are needed to run them. Also supports Program Governance and Decision Rights through credible local ownership.

**Conflict:** Slow, hard-to-measure capacity outcomes conflict with Stage-Gate and Capital Release Design, whose Year 3/7/12/18 gates favor quick KPIs. Competes with Resistance Breeding Strategy for scarce funds and early technical results.

**Justification:** *High*, High because weak-link countries' inspection and nursery capacity determines real containment and post-funding handover. It enables surveillance and propagation but conflicts with quick-KPI gating and breeding funding.

### Decision 14: Pathogen Population Genomics and Virulence Tracking
**Lever ID:** `6846e3e4-7a6e-4cb3-b88b-61599a7c861e`

**The Core Decision:** Tracks the genetic diversity, population structure and virulence of the SALB fungus (Pseudocercospora ulei, formerly Microcyclus ulei) to forecast whether resistant Hevea cultivars will hold up. Success metrics include isolate coverage across regions, time-series continuity, share of cultivar release decisions informed by virulence data, and open data-sharing compliance. It also provides lineage evidence for tracing incursions.

**Why It Matters:** Determines how closely the program monitors genetic diversity and virulence of the SALB fungus itself, rather than only the host. Richer tracking shows whether resistant cultivars will hold up against new pathogen variants. It also adds sequencing, sample logistics and data-sharing obligations that cannot be paused without losing time-series value.

**Strategic Choices:**

1. Establish a small reference laboratory network that sequences pathogen isolates from outbreak sites and trial plots annually, feeding results into cultivar release decisions.
2. Embed pathogen sampling and sequencing into every resistance field trial and surveillance visit, treating virulence data as a routine by-product of existing fieldwork.
3. Fund an adversarial pathogen-evolution programme that deliberately challenges candidate cultivars with the most virulent isolates under high-containment conditions to forecast resistance breakdown before release.

**Trade-Off / Risk:** Pathogen-side monitoring guards against releasing cultivars that fail within a decade, but the strongest option requires high-containment facilities that conflict with the containment mandate and demand scarce biosafety expertise in producer countries.

**Strategic Connections:**

**Synergy:** Directly strengthens Resistance Breeding Strategy by informing which resistance genes to deploy, and supports Resistance Field-Trial Geography and Biosafety Siting by showing where virulent variants should be tested.

**Conflict:** The adversarial high-containment option conflicts with Containment Protocol Legal Architecture and Resistance Field-Trial Geography and Biosafety Siting, since handling virulent isolates raises escape risk and needs scarce biosafety expertise. Data-sharing duties may also clash with Germplasm Access and Benefit-Sharing Model.

**Justification:** *Medium*, Medium because it supports durability decisions in breeding and trial design and provides lineage evidence. It is a supporting input to the breeding hub, and its adversarial option carries containment conflicts.

### Decision 15: Clean Planting-Material Propagation Technology
**Lever ID:** `02d00d45-d148-4f58-a102-d8c5b5bc73f3`

**The Core Decision:** Chooses how certified disease-free planting material is multiplied and distributed: conventional budwood gardens, tissue-culture or somatic-embryogenesis hubs, or a hybrid. Success metrics include plantlets delivered per year, pathogen-free test rates, traceability of batches to mother material, unit cost per plant, and delivery reach to dispersed smallholders. It is the main channel by which new cultivars physically reach growers.

**Why It Matters:** Selects how disease-free, high-yield planting stock is multiplied and delivered at scale. Conventional budded stumps are familiar to growers but need large nursery areas and carry contamination risk. Tissue-culture or somatic-embryo systems are cleaner and faster to scale but demand laboratory capacity, technical staff and tolerance of higher unit costs.

**Strategic Choices:**

1. Scale conventional budwood gardens and nurseries with strict hygiene certification, using existing grower know-how and distribution channels.
2. Build regional somatic-embryogenesis and tissue-culture hubs that supply certified clonal plantlets to licensed nurseries, concentrating biosecurity control in a few sites.
3. Adopt a hybrid model where hubs produce elite mother material under containment and local nurseries multiply it, with periodic pathogen testing and traceable batch labelling.

**Trade-Off / Risk:** Centralized propagation improves biosecurity and traceability, but it creates single points of failure and may not be affordable or timely for dispersed smallholders unless nursery networks are also subsidized and trained.

**Strategic Connections:**

**Synergy:** Amplifies Resistance Breeding Strategy by rapidly multiplying new resistant clones, and enables Smallholder Replanting Finance and Price Stability by providing certified stock for financed replanting.

**Conflict:** Centralized hubs trade off against Producer-Country Institutional Capacity and Technology Transfer, since lab-heavy systems need scarce skilled staff, and against Smallholder Replanting Finance and Price Stability, because higher unit costs and distance may exclude dispersed growers.

**Justification:** *Medium*, Medium because it is the delivery channel for new cultivars and supports smallholder replanting. It is largely an implementation choice that follows breeding and finance decisions, with trade-offs on cost and capacity.
