This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** The plan is classified as physical. It is a 25-year, $30 billion public-private program to protect the global natural rubber supply from South American Leaf Blight (SALB), and almost every workstream needs real-world, on-the-ground activity.

1. Containment protocol. The SALB Containment Protocol covers the movement of nursery stock, research materials and contaminated equipment. It depends on funded surveillance, physical inspections at plantations, nurseries and borders, and red-team drills. These activities need people, facilities and field sites. A written protocol alone cannot verify containment.

2. Breeding and bio-prospecting. The Brazil-led bio-prospecting and genomic breeding effort needs field collection of Hevea germplasm in South America. It also needs laboratories, greenhouses, nurseries and multi-location field trials to test SALB resistance and yield parity. Access-and-benefit-sharing compliance involves agreements with physical stakeholders and territories. Genomic analysis is partly computational, but it cannot replace physical sampling and trials.

3. Alternative crops. Guayule in arid zones and Russian dandelion in temperate climates must be planted, grown and harvested on land. Colocated processing plants must be built and operated. OEM offtake agreements require physical product qualification, such as testing rubber quality in tyres and other products.

4. Smallholder adoption. Replant finance, clean-plant networks and price-stability tools are delivered to farmers in rubber-growing regions. Clean-plant networks are physical nurseries and distribution systems. Replanting is physical agricultural work.

5. Governance and gating. Funding gates at Years 3, 7, 12 and 18 rely on containment performance, cultivar readiness and alternative-rubber cost and quality KPIs. These are measured through field data, trials and processing outputs. Negotiating a global protocol also involves in-person meetings between governments, regulators, industry and development finance institutions.

Because the plan needs land, laboratories, plants, travel, inspections and field trials, it cannot be completed exclusively online. Digital tools such as genomics, data platforms and finance modelling would support it but do not replace the physical work.