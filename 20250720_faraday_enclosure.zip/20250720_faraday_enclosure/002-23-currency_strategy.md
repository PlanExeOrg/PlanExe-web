This plan involves money.

## Currencies

- **EUR:** The project is funded in EUR and anchored in Estonia, a Eurozone country. The product will be pre-sold to European networks.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting and reporting. Local transactions within Estonia will also be in EUR. No additional international risk management is needed.