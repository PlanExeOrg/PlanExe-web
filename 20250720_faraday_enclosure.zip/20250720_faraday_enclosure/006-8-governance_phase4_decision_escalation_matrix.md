**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic review and approval at a higher level.
Negative Consequences: Potential budget overrun and project delays if not addressed promptly.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Action Plan Approval
Rationale: The PMO cannot handle the risk with existing resources or mitigation strategies, requiring strategic intervention.
Negative Consequences: Project failure or significant delays if the risk is not effectively managed.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: The PMO cannot agree on a key operational decision, requiring a higher authority to break the tie and ensure project progress.
Negative Consequences: Project delays and potential cost increases if the vendor selection is not resolved.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval
Rationale: A major change to the project scope requires strategic review and approval to ensure alignment with overall business objectives.
Negative Consequences: Project failure or misalignment with business goals if the scope change is not properly evaluated.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to CEO/Sponsor
Rationale: Requires independent review and investigation to ensure ethical conduct and compliance with regulations.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust if ethical concerns are not addressed.

**Technical Design Impasse**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Decision
Rationale: The Technical Advisory Group cannot reach a consensus on a critical design element, requiring strategic guidance.
Negative Consequences: Technical flaws, performance issues, or certification failures if the design impasse is not resolved.