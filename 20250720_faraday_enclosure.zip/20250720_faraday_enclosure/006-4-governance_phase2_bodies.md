### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and guidance for the project, ensuring alignment with overall business objectives and managing strategic risks. Given the €750k budget and conditional funding, high-level oversight is crucial.

**Responsibilities:**

- Provide strategic direction and guidance to the project team.
- Approve major project milestones and deliverables.
- Approve budget revisions exceeding €25,000.
- Monitor and manage strategic risks.
- Resolve escalated issues from the Project Management Office.
- Ensure alignment with overall business strategy.

**Initial Setup Actions:**

- Finalize Terms of Reference and operating procedures.
- Appoint a chairperson.
- Establish a communication protocol with the PMO.
- Review and approve the initial project plan.

**Membership:**

- CEO/Sponsor
- Head of Engineering
- Head of Marketing
- Independent External Advisor (Supply Chain/Manufacturing)
- Project Manager (ex-officio, non-voting)

**Decision Rights:** Strategic decisions related to project scope, budget (above €25,000 revisions), timeline, and key strategic risks.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the CEO/Sponsor has the deciding vote.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of project progress against milestones.
- Discussion and approval of budget revisions.
- Review and mitigation of strategic risks.
- Review of market conditions and competitive landscape.
- Escalated issues from the PMO.

**Escalation Path:** CEO/Sponsor
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages the day-to-day execution of the project, ensuring adherence to the project plan and budget. Given the project's complexity and reliance on external partners, a dedicated PMO is essential.

**Responsibilities:**

- Develop and maintain the project plan.
- Manage the project budget (within approved thresholds).
- Track project progress and identify potential issues.
- Coordinate activities of the project team.
- Manage operational risks.
- Report project status to the Steering Committee.
- Manage communication within the project team.

**Initial Setup Actions:**

- Establish project management processes and tools.
- Define roles and responsibilities for project team members.
- Set up a project communication plan.
- Develop a risk management plan.

**Membership:**

- Project Manager
- Design Engineer
- Certification Specialist
- Manufacturing Liaison
- Marketing Representative

**Decision Rights:** Operational decisions related to project execution, budget management (within approved thresholds), and resource allocation.

**Decision Mechanism:** Decisions made by the Project Manager, in consultation with the project team. Unresolved disagreements are escalated to the Steering Committee.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of current issues and risks.
- Coordination of team activities.
- Budget tracking and variance analysis.
- Action item review.

**Escalation Path:** Project Steering Committee
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and guidance on the design, certification, and manufacturing of the Faraday enclosure. Given the technical complexity of the project, expert advice is crucial.

**Responsibilities:**

- Provide technical guidance on the design of the Faraday enclosure.
- Advise on the selection of materials and components.
- Review and approve technical specifications.
- Provide support during the certification process.
- Troubleshoot technical issues.
- Ensure compliance with relevant technical standards.

**Initial Setup Actions:**

- Identify and recruit qualified technical experts.
- Define the scope of the Technical Advisory Group's responsibilities.
- Establish a communication protocol with the PMO.
- Review the initial design specifications.

**Membership:**

- EMC Engineer
- Materials Scientist
- Manufacturing Expert
- Independent External EMC Testing Consultant

**Decision Rights:** Technical decisions related to the design, materials, and manufacturing of the Faraday enclosure.

**Decision Mechanism:** Decisions made by consensus. If consensus cannot be reached, the Project Manager makes the final decision, considering the input from the Technical Advisory Group.

**Meeting Cadence:** Bi-weekly during design and certification phases, monthly thereafter.

**Typical Agenda Items:**

- Review of design specifications.
- Discussion of material selection.
- Review of certification progress.
- Troubleshooting of technical issues.
- Updates on relevant technical standards.

**Escalation Path:** Project Steering Committee
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures ethical conduct and compliance with all relevant regulations, including GDPR, anti-corruption laws, and environmental regulations. Given the project's international scope and reliance on external partners, a dedicated compliance body is essential.

**Responsibilities:**

- Develop and implement a compliance program.
- Ensure compliance with GDPR and other data privacy regulations.
- Ensure compliance with anti-corruption laws.
- Ensure compliance with environmental regulations.
- Investigate and resolve compliance violations.
- Provide training on ethical conduct and compliance.
- Oversee the whistleblower mechanism.

**Initial Setup Actions:**

- Develop a code of conduct.
- Establish a compliance reporting mechanism.
- Conduct a risk assessment to identify potential compliance violations.
- Develop a training program on ethical conduct and compliance.

**Membership:**

- Legal Counsel
- Compliance Officer
- Independent External Ethics Consultant
- Project Manager (ex-officio, non-voting)

**Decision Rights:** Decisions related to ethical conduct, compliance with regulations, and investigation of compliance violations.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Legal Counsel has the deciding vote.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of compliance program.
- Discussion of potential compliance violations.
- Review of compliance training materials.
- Updates on relevant regulations.
- Review of whistleblower reports.

**Escalation Path:** CEO/Sponsor