Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 14 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 5 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The project focuses on designing and manufacturing Faraday enclosures, which are based on well-established principles of electromagnetism. No quotes needed.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (Faraday enclosure for phones/laptops) + market (preppers and critical infrastructure) + tech/process (Tallinn manufacturing) + policy (EU compliance) without independent evidence at comparable scale. There is no mention of prior success in this specific combination.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Each track must produce one authoritative source or a supervised pilot showing results vs a baseline. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Owner: Project Manager / Deliverable: Validation Report / Date: Within 90 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because no business‑level mechanism‑of‑action (inputs→process→customer value), owner, and measurable outcomes are defined for the buzzwords. A key strategic dimension missing is a detailed risk mitigation plan for supply chain disruptions.

**Mitigation**: Project Manager: Create one-pagers for each buzzword, detailing the mechanism-of-action, owner, measurable outcomes, and decision hooks. Include a detailed risk mitigation plan for supply chain disruptions. Due Date: Within 60 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because a major hazard class (supply chain) is minimized. The plan mentions supply chain risk, but the mitigation plan is insufficient. The SWOT analysis acknowledges this weakness, but the mitigation plan is insufficient.

**Mitigation**: Supply Chain Coordinator: Expand the risk register to include detailed supply chain risks, map cascades, add controls, and establish a dated review cadence. Due date: Within 90 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions EMC Certification, RoHS Compliance, REACH Compliance, and Manufacturing permits in Estonia, but does not include a matrix showing the lead times for each.

**Mitigation**: Certification Specialist: Create a permit/approval matrix with authoritative lead times for each required approval in the relevant jurisdictions. Due date: Within 60 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions funding requirements but lacks specifics on sources, draw schedule, covenants, and runway. The plan mentions €750k funding but does not specify the source or terms.

**Mitigation**: Financial Officer: Develop a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO‑GO on missed financing gates. Due Date: Within 30 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget of €750k lacks sufficient substantiation via benchmarks or vendor quotes normalized by area. The plan mentions the budget but provides no per-area cost analysis or comparable project data.

**Mitigation**: Financial Officer: Obtain ≥3 vendor quotes for materials and manufacturing, normalize costs per m²/ft² for the enclosure, and adjust the budget or de-scope accordingly. Due Date: Within 60 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., revenue, user adoption, completion dates) as single numbers without providing a range, confidence interval, or discussing alternative scenarios. The plan lacks sensitivity analysis.

**Mitigation**: Financial Officer: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the most critical projection (e.g., revenue). Due Date: Within 60 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because build‑critical components lack engineering artifacts. The plan mentions design and prototyping but lacks details on technical specs, interface definitions, test plans, and an integration map with owners/dates.

**Mitigation**: Product Development Engineer: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components. Due Date: Within 90 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes several claims without providing verifiable evidence. For example, it states, "ISO-certified precision-metal ecosystem" in Tallinn, but lacks a link to a list of such certified manufacturers or evidence of their capacity.

**Mitigation**: Project Manager: Compile a list of ISO-certified precision-metal manufacturers in Tallinn, including links to their certifications and capacity data, by 2026-Q3.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the deliverable is abstract. The plan mentions "Faraday enclosure product" without specific, verifiable qualities or acceptance criteria.

**Mitigation**: Product Manager: Define SMART criteria for the Faraday enclosure, including a KPI for shielding effectiveness (e.g., dB attenuation at specific frequencies). Due Date: Within 30 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes a dual-track approach, targeting both preppers and critical infrastructure, which may dilute marketing efforts and require different product features. This does not directly support the core goal of creating a commercially viable product.

**Mitigation**: Marketing & Sales Team: Produce a one-page benefit case justifying the dual-track approach, complete with a KPI, owner, and estimated cost, or move one target to the project backlog. Due Date: Within 30 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a "Certification Specialist" to navigate complex regulations, but the plan does not include a validation of the talent market for this role. The plan does not include a validation of the talent market for this role.

**Mitigation**: HR: Conduct a talent market survey for a Certification Specialist with EMC and EU regulatory experience, including salary benchmarks and availability. Due Date: Within 60 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies regulatory feasibility as a risk, but lacks a regulatory matrix mapping authorities, artifacts, lead times, and predecessors. The plan mentions EMC Certification, RoHS Compliance, REACH Compliance, and Manufacturing permits in Estonia, but does not include a matrix showing the lead times for each.

**Mitigation**: Certification Specialist: Create a regulatory matrix identifying all required permits/licenses, governing authorities, required artifacts, lead times, and predecessors. Include a NO-GO decision point for adverse findings. Due Date: Within 60 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions a goal of commercialization and financial sustainability, but lacks a detailed operational sustainability plan. There is no discussion of long-term maintenance, technology obsolescence, or personnel dependency. The plan does not include a clear funding/resource strategy.

**Mitigation**: Project Manager: Develop an operational sustainability plan including a funding/resource strategy, maintenance schedule, succession plan, technology roadmap, and adaptation mechanisms. Due Date: Within 90 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions EMC Certification, RoHS Compliance, REACH Compliance, and Manufacturing permits in Estonia, but does not include a matrix showing the lead times for each.

**Mitigation**: Certification Specialist: Create a permit/approval matrix with authoritative lead times for each required approval in the relevant jurisdictions. Due date: Within 60 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies reliance on a single manufacturer as a risk, but lacks evidence of SLAs or tested failover plans. The plan mentions a contingency plan, alternative suppliers, strong relationships, monitor conditions in Estonia, diversify sourcing.

**Mitigation**: Supply Chain Coordinator: Secure SLAs with the Tallinn manufacturer, identify a secondary manufacturer, and test a failover scenario by Q4 2026.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the stated goals of the Marketing and Sales Team (maximize revenue) and the Manufacturing Liaison (minimize manufacturing costs) create a conflict. Aggressive sales targets may pressure manufacturing to cut corners on quality.

**Mitigation**: Project Manager: Establish a shared OKR for both teams focused on 'Achieving X% customer satisfaction while maintaining Y% gross margin' to align incentives. Due Date: Within 30 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board. Define thresholds for when to re-plan or stop. Due Date: Within 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan has ≥3 High risks (supply chain, budget, regulatory) that are strongly coupled. A disruption in the Tallinn supply chain could trigger budget overruns and certification delays, leading to project failure.

**Mitigation**: Project Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Due Date: Within 90 days.