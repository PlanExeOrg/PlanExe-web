### 1. Project Strategic Direction Board (PSDB)

**Rationale for Inclusion:** Given the high-risk, high-novelty 'Pioneer's Gambit' strategy, an executive oversight body is required to manage the selection of the Critical Levers (Architecture, Risk Posture, Performance Trade-offs) and provide financial stewardship over the $300M budget. This body ensures alignment with the 7-year invention mandate.

**Responsibilities:**

- Approve revisions to the Core Electrochemical Architecture path (Decision 1).
- Authorize cumulative R&D spending exceeding $25 million or any single CapEx purchase over $5 million.
- Review and approve results from all major Technical Gate Reviews (kill/evaluate gates) every six months.
- Act as the final internal escalation point for major conflict resolution between operational/technical leadership.
- Approve the annual utilization plan against the $300M budget timeline.

**Initial Setup Actions:**

- Finalize and ratify the Project Charter and Terms of Reference (ToR).
- Appoint an independent Chair (external to the direct project execution team).
- Establish baseline financial thresholds for strategic approval ($5M CapEx, $25M total spend reviews).

**Membership:**

- Executive Sponsor (Chair, Internal Executive Management)
- Project Director (Executive Lead)
- Chief Financial Officer (Budget & Financial Oversight)
- Lead Electrochemist (Technical Advisor)
- External Independent Board Member (Ensuring impartial strategic oversight)

**Decision Rights:** All decisions impacting the overall technical direction, budget contingency release, or major shifts in strategy (e.g., pivoting from Li-Air) exceeding $5M in funding or 90-day schedule impacts.

**Decision Mechanism:** Consensus-based decision-making. If consensus cannot be reached, a simple majority vote of members present is taken. The External Independent Board Member casts the tie-breaking vote.

**Meeting Cadence:** Monthly, transitioning to Quarterly after the first two years (post-critical architecture selection).

**Typical Agenda Items:**

- Review of Technical Gate 1/2 Status vs. 350 Wh/kg Milestone.
- Financial Status vs. 7-Year Burn Rate Projection.
- Strategic Risk Exposure Report (Top 3 Risks rated by PSDB criteria).
- Approval of major procurement/hiring requests.

**Escalation Path:** Issues requiring ethical clarification, major non-compliance findings, or unresolved risks that threaten the 7-year timeline are escalated to the Organization's Executive Committee.
### 2. Project Execution and Technical Alignment Group (PET-AG)

**Rationale for Inclusion:** This body manages the high-velocity execution required by the 'Pioneer's Gambit' strategy (rapid prototyping, aggressive cadence, internal synthesis). It bridges the gap between strategic goals and the daily R&D work, ensuring all technical tracks support the dual density targets (Decision 4).

**Responsibilities:**

- Oversee the daily execution of the Electrochemical Validation Cadence (Decision 8).
- Approve minor scope changes or resource re-allocations within the approved budget envelope ($5M threshold).
- Resolve technical conflicts between Chemistry and Engineering workstreams (Decision 9).
- Monitor and report on the progress of Novel Active Material Morphology Control (Decision 11) and Prototype Fabrication Scale (Decision 2).
- Review all failure analysis reports before escalation, focusing on data integrity (Decision 10 synergy).

**Initial Setup Actions:**

- Establish standardized reporting templates for material input vs. output validation data.
- Define the clear process for material handoffs between Synthesis and Device Assembly teams.
- Finalize procedures for managing the 10 Ah prototype build schedule (per Issue 1).

**Membership:**

- Project Director (Chair)
- Lead Electrochemist
- Materials Engineering Lead
- Chemical Engineering Lead (Expert in Synthesis)
- Lead Data Scientist (Modeling Liaison)

**Decision Rights:** Operational decisions; scope changes < $5M; technical sequence decisions for prototype builds; resolution of technical deviations within the <5% performance threshold (per Decision 4).

**Decision Mechanism:** Simple majority vote among mandatory functional leads (Chair, Electrochemist, Materials Lead). Tie-breaker goes to the Project Director, informed by immediate data evidence.

**Meeting Cadence:** Twice weekly during primary R&D phases (Years 1-4); Weekly thereafter.

**Typical Agenda Items:**

- Review of High-Throughput Test Results and Go/No-Go recommendations.
- Precursor Supply Health Check (raw material inventory vs. synthesis utilization).
- Dependency alignment between modeling predictions and physical build schedules.
- Review of Safety Integration checkpoints (per Risk 7).

**Escalation Path:** If the PET-AG cannot achieve consensus on budget re-allocation (>10% of quarterly operational budget) or if a technical issue threatens the 6-month Kill-Gate schedule, the matter is escalated immediately to the Project Strategic Direction Board (PSDB).
### 3. Compliance, Ethics, and Assurance Panel (CEAP)

**Rationale for Inclusion:** Given the high-risk environment (highly reactive electrolytes, novel materials) and the specific audit risks identified (precursor integrity, waste handling, talent hiring), a dedicated, independent assurance body is critical for ensuring regulatory adherence (OSHA, EPA) and mitigating corruption risks related to external contracting and vendor selection.

**Responsibilities:**

- Serve as the primary internal body responsible for comprehensive compliance oversight (GDPR, OSHA, EPA, hazardous waste management).
- Provide independent assurance on the integrity of procurement processes, especially for Novel Precursors (Decision 3) and external modeling contracts (Assumption 7).
- Investigate and report on potential conflicts of interest or corruption risks identified during hiring (Risk 6/Issue 3) or vendor selection.
- Review and approve all documentation related to environmental reporting and specialized hazardous waste disposal ($500K budget oversight, per Assumption 6).
- Audit adherence to safety criteria integration protocols (Decision 13).

**Initial Setup Actions:**

- Establish the secure Whistleblower Channel managed by an external fiduciary.
- Develop detailed compliance checklist covering all material handling protocols specific to anticipated novel electrolytes.
- Formalize bi-annual audit schedule in coordination with the PSDB and external auditors.

**Membership:**

- Chief Compliance Officer (Chair, Internal)
- Independent Legal Counsel (External Assurance Member)
- Director of HSE (Health, Safety, and Environment)
- Internal Auditor (or delegated oversight function)

**Decision Rights:** Capacity to issue mandatory corrective actions or 'Stop Work' orders pending immediate remediation of regulatory or severe safety violations. Authority to freeze payments to vendors associated with ongoing corruption investigations.

**Decision Mechanism:** Unanimous vote required for issuing a 'Stop Work' order or formal compliance violation report to the PSDB. All other recommendations are advisory based on majority rule.

**Meeting Cadence:** Quarterly for standard review; on-demand (within 48 hours) following any serious cell failure, lab incident, or whistleblower report.

**Typical Agenda Items:**

- Review of Hazardous Waste Manifests and Disposal Contracts.
- Audit Findings Report (Internal/External Audit Status).
- Review of Personnel Hiring Deviations/Talent Buffer utilization (Issue 3 alignment).
- Assessment of Electrolyte Risk Posture compliance.

**Escalation Path:** Any non-negotiable finding that results in immediate OSHA/EPA intervention or confirms a major corruption event must be immediately escalated to the PSDB Chair and the Organization's Executive Committee for external reporting and immediate remediation actions.