**Architectural Pivot from Initial High-Risk Chemistry (e.g., mandated revision of Decision 1)**
Escalation Level: Project Strategic Direction Board (PSDB)
Approval Process: Consensus-based decision-making, potentially requiring a majority vote with the External Independent Board Member casting the tie-breaker.
Rationale: Changing the Core Electrochemical Architecture dictates the entire 7-year technical path and resource allocation for years, impacting fundamental feasibility against the 500 Wh/kg target.
Negative Consequences: Loss of momentum ($25M+ in sunk costs), potential project delay exceeding 90 days, and mandatory re-baselining of the entire $300M budget forecast.

**Budget Re-allocation Requiring >10% Quarterly OpEx Shift or >$5M CapEx**
Escalation Level: Project Strategic Direction Board (PSDB)
Approval Process: Formal review of the Financial Status vs. 7-Year Burn Rate Projection followed by majority vote.
Rationale: PET-AG decision authority limits budget changes to within approved envelopes. Major shifts impact financial stewardship and the ability to fund necessary forward-looking investments (like precursor scale-up).
Negative Consequences: Imbalance in resource allocation (e.g., starving science for engineering), jeopardizing compliance funding (Risk 2 mitigation), or inability to fund critical mitigation actions for major risks.

**Technical Disagreement within PET-AG impacting Critical Gate Schedule (e.g., 6-month Kill-Gate at risk)**
Escalation Level: Project Strategic Direction Board (PSDB)
Approval Process: Immediate submission of the conflict and available data to the PSDB Chair for resolution during ad-hoc review.
Rationale: PET-AG deadlocks regarding technical sequencing or interpretation of results that might trigger an early 'kill' or require a fundamental strategy shift (as stipulated in the PET-AG escalation path).
Negative Consequences: Schedule slippage exceeding 90 days, forcing the project to miss key validation milestones and potentially violating the 7-year constraint.

**Discovery of Severe Safety Violation or Regulatory Non-Compliance (e.g., unapproved hazardous waste stream)**
Escalation Level: Compliance, Ethics, and Assurance Panel (CEAP)
Approval Process: On-demand meeting (within 48 hours) requiring Unanimous vote to issue a 'Stop Work' order pending immediate remediation.
Rationale: Immediate threat to personnel, facility integrity (Risk 7), or adherence to mandatory local/federal compliance standards (OSHA/EPA) supersedes all project schedule goals.
Negative Consequences: Mandatory shutdown by external regulatory bodies (OSHA/EPA), severe legal penalties, loss of insurance coverage, and irreparable reputational damage.

**Need to Deviate from Precursor Synthesis Buy vs. Build Mandate (Decision 3 violation/reversal)**
Escalation Level: Project Strategic Direction Board (PSDB)
Approval Process: Review of the rationale, cost impact analysis (Risk 2/Issue 3), and impact on IP strategy, followed by majority vote.
Rationale: Reversing the 'Pioneer's Gambit' mandate to internalize precursor synthesis requires significant unplanned CapEx and shifts the IP exploitation strategy, demanding the highest level of financial and long-term strategic authority.
Negative Consequences: Significant upfront budget exhaustion (Risk 2), potential delay in securing precursor supply chain stability, and potential conflict with IP protection timelines.

**Conflict with Supplier Integrity or Corruption Allegation (Vendor Selection Issue)**
Escalation Level: Compliance, Ethics, and Assurance Panel (CEAP)
Approval Process: Immediate investigation utilizing the external fiduciary/whistleblower channel. Unanimous vote required to freeze payments pending investigation completion.
Rationale: Integrity failures in procurement, especially concerning specialty chemicals (Decision 3) or external modelers (Assumption 7), undermine all subsequent project data integrity and expose the organization to legal/fiduciary risk.
Negative Consequences: Legal investigation, contract termination costs, immediate halt of R&D relying on the compromised supplier, and potential public disclosure of internal ethical breaches.