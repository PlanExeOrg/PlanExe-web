**Purpose:** business

**Purpose Detailed:** Scientific and engineering objective focused on invention and technical performance achievement (battery chemistry/design) within a significant research and development budget, likely leading to intellectual property creation or licensing, rather than immediate market dominance.

**Topic:** Next-generation rechargeable battery invention with high energy density targets