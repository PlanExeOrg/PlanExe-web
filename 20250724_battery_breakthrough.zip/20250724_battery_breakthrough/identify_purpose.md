**Purpose:** business

**Purpose Detailed:** Invention of a high-performance battery with specific energy density targets, research and development.

**Topic:** Next-generation rechargeable battery invention