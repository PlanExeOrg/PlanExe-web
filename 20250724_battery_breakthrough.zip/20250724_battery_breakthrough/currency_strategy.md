This plan involves money.

## Currencies

- **USD:** The project budget is explicitly set in USD ($300M), and the location is Austin, Texas, USA.

**Primary currency:** USD

**Currency strategy:** As the project is entirely located in the United States with a fixed budget denominated in USD, the USD will be used for all budgeting, payroll, and capital expenditures. No foreign exchange risk management is required.