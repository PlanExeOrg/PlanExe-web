### 1. Project Sponsor approves the Project Charter, confirming the 7-year mandate, $300M budget, and the selection of the 'Pioneer's Gambit' strategic path.

**Responsible Body/Role:** Executive Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Signed Project Charter
- Confirmation of 'Pioneer's Gambit' validity
- Initial Budget Baseline ($300M)

**Dependencies:**

- Strategic Decisions Finalized (Gov-Phase 1 complete)

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Project Strategic Direction Board (PSDB), including initial baseline spending thresholds ($5M CapEx, $25M cumulative R&D review).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1 - 2

**Key Outputs/Deliverables:**

- Draft PSDB ToR v0.1
- Proposed list of nominated PSDB members

**Dependencies:**

- Signed Project Charter

### 3. Executive Sponsor formally appoints the Chair and external Independent Board Member for the PSDB, and confirms all other initial members.

**Responsible Body/Role:** Executive Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Formal Appointment Letters for PSDB Chair and Members
- Confirmation of PSDB decision mechanism (Consensus/Majority/Tie-break)

**Dependencies:**

- Draft PSDB ToR v0.1

### 4. PSDB holds its inaugural kick-off meeting to ratify its ToR, establish the baseline financial thresholds for future strategic approval, and confirm Year 1 performance kill-gate criteria (350 Wh/kg by M12).

**Responsible Body/Role:** Project Strategic Direction Board (PSDB)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Ratified PSDB Terms of Reference
- Approved initial financial thresholds
- PSDB Meeting Minutes 1

**Dependencies:**

- Formal Appointment Letters for PSDB Chair and Members

### 5. Project Manager drafts initial ToR for the Project Execution and Technical Alignment Group (PET-AG), focusing on defining operational decision rights ($5M threshold) and establishing standardized technical reporting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2 - 4

**Key Outputs/Deliverables:**

- Draft PET-AG ToR v0.1
- Standardized Technical Data Handoff Template

**Dependencies:**

- Signed Project Charter

### 6. Project Director confirms PET-AG membership (functional leads) and ratifies the draft PET-AG ToR, securing agreement on the twice-weekly meeting cadence.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Finalized PET-AG ToR
- Confirmed PET-AG Regular Meeting Schedule

**Dependencies:**

- Draft PET-AG ToR v0.1

### 7. PET-AG conducts its first meeting to define operational conflict resolution (material handoffs) and finalize the schedule for commissioning the 10 Ah prototype line (milestone target: 50% capacity by M18).

**Responsible Body/Role:** Project Execution and Technical Alignment Group (PET-AG)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- PET-AG Kick-off Minutes
- Initial 10 Ah Fabrication Commissioning Schedule
- Agreement on Conflict Resolution SOPs

**Dependencies:**

- Finalized PET-AG ToR
- Review Issue 1 (10 Ah scale-up dependency)

### 8. Chief Compliance Officer (CCO) drafts initial ToR for the Compliance, Ethics, and Assurance Panel (CEAP), focusing on immediate regulatory needs (OSHA/EPA permits) and establishing the external Whistleblower Channel.

**Responsible Body/Role:** Chief Compliance Officer (CCO)

**Suggested Timeframe:** Project Week 4 - 7

**Key Outputs/Deliverables:**

- Draft CEAP ToR v0.1
- External Fiduciary Selection for Whistleblower Channel

**Dependencies:**

- Review of Regulatory/Compliance Requirements (Assumptions 4 & 6)

### 9. Independent Legal Counsel and Director of HSE review and finalize the CEAP ToR, specifically mandating audit schedules for precursor integrity (Decision 3) and waste disposal protocols (Assumption 6).

**Responsible Body/Role:** Independent Legal Counsel / Director of HSE

**Suggested Timeframe:** Project Week 8 - 9

**Key Outputs/Deliverables:**

- Ratified CEAP Terms of Reference
- Initial Hazardous Material Compliance Checklist

**Dependencies:**

- Draft CEAP ToR v0.1

### 10. PSDB formally establishes and constitutes the CEAP, confirming the CCO as Chair and authorizing its power to issue 'Stop Work' orders pending immediate remediation of severe safety/compliance violations.

**Responsible Body/Role:** Project Strategic Direction Board (PSDB)

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Formal Constitution of CEAP
- Approved CEAP Escalation Protocol to PSDB

**Dependencies:**

- Ratified CEAP Terms of Reference

### 11. CEAP holds its inaugural meeting to review the startup hiring plan (addressing Issue 3 risk) and establish procedures for monitoring the specialized $500K environmental waste budget.

**Responsible Body/Role:** Compliance, Ethics, and Assurance Panel (CEAP)

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- CEAP Kick-off Minutes
- Initial Compliance Monitoring Schedule aligned with R&D milestones

**Dependencies:**

- Formal Constitution of CEAP
- Review Issue 3 (Talent Buffer utilization)

### 12. Project Director, in collaboration with functional leads, finalizes the initial R&D resource split per Decision 9 (Chemistry vs. Engineering allocation) and submits for PSDB review.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Draft Annual Budget Allocation Plan reflecting Decision 9 priorities
- Recommendation on leveraging the $10M Talent Buffer

**Dependencies:**

- PSDB established
- PET-AG operational

### 13. PSDB reviews and approves the initial Q1/Q2 R&D Budget Allocation Plan, ensuring alignment with the 350 Wh/kg Year 1 milestone expectations and funding necessary in-situ diagnostic tools (per Assumption 5).

**Responsible Body/Role:** Project Strategic Direction Board (PSDB)

**Suggested Timeframe:** Project Month 3

**Key Outputs/Deliverables:**

- Approved Q1/Q2 Funding Release
- Formal endorsement of initial tool procurement list (In-situ/Impedance rigs)

**Dependencies:**

- Draft Annual Budget Allocation Plan
- PSDB Quarterly Meeting Cycle established