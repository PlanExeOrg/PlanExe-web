### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 2. Project Manager circulates Draft PSC ToR v0.1 for review by proposed PSC members (CTO, CFO, VP of R&D, Independent Battery Technology Expert, Project Manager).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Circulation Email
- Review Feedback from Proposed Members

**Dependencies:**

- Draft PSC ToR v0.1

### 3. Project Manager consolidates feedback and revises the PSC ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- PSC ToR v0.2
- Feedback Summary

**Dependencies:**

- Review Feedback from Proposed Members

### 4. VP of Research and Development formally approves the PSC ToR.

**Responsible Body/Role:** VP of Research and Development

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved PSC ToR v1.0

**Dependencies:**

- PSC ToR v0.2

### 5. VP of Research and Development formally appoints the Chair of the Project Steering Committee (PSC).

**Responsible Body/Role:** VP of Research and Development

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved PSC ToR v1.0

### 6. Project Manager formally confirms membership of the Project Steering Committee (PSC) with all members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Appointment of PSC Chair

### 7. Project Manager schedules the initial kick-off meeting for the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation Emails

### 8. Hold the initial kick-off meeting for the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Initial Risk Register Approved

**Dependencies:**

- Meeting Invitation
- Agenda

### 9. Project Manager defines roles and responsibilities for the Core Project Team (CPT).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- CPT Roles and Responsibilities Document

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 10. Project Manager establishes communication protocols for the Core Project Team (CPT).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- CPT Communication Protocols Document

**Dependencies:**

- CPT Roles and Responsibilities Document

### 11. Project Manager sets up project management tools for the Core Project Team (CPT).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Management Tool Configuration
- Access Granted to CPT Members

**Dependencies:**

- CPT Communication Protocols Document

### 12. Project Manager develops a detailed work breakdown structure (WBS) for the Core Project Team (CPT).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- CPT Work Breakdown Structure (WBS)

**Dependencies:**

- Project Management Tool Configuration

### 13. Project Manager establishes operational risk management procedures for the Core Project Team (CPT).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- CPT Operational Risk Management Procedures

**Dependencies:**

- CPT Work Breakdown Structure (WBS)

### 14. Project Manager formally confirms membership of the Core Project Team (CPT) with all members (Project Manager, Lead Researcher, Lead Engineer, Compliance Officer, Procurement Manager, Lab Manager).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- CPT Operational Risk Management Procedures

### 15. Project Manager schedules the initial kick-off meeting for the Core Project Team (CPT).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation Emails

### 16. Hold the initial kick-off meeting for the Core Project Team (CPT).

**Responsible Body/Role:** Core Project Team (CPT)

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 17. Project Manager defines the scope of expertise for the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- TAG Scope of Expertise Document

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 18. Project Manager establishes communication channels for the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- TAG Communication Channels Document

**Dependencies:**

- TAG Scope of Expertise Document

### 19. Project Manager develops review protocols for the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- TAG Review Protocols Document

**Dependencies:**

- TAG Communication Channels Document

### 20. Project Manager identifies key technical areas for focus for the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- TAG Key Technical Areas Document

**Dependencies:**

- TAG Review Protocols Document

### 21. Project Manager establishes criteria for technical assessments for the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- TAG Technical Assessment Criteria Document

**Dependencies:**

- TAG Key Technical Areas Document

### 22. Project Manager formally confirms membership of the Technical Advisory Group (TAG) with all members (Senior Materials Scientist, Senior Chemical Engineer, Battery Technology Consultant, Electrochemical Engineer, Solid-State Electrolyte Expert).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- TAG Technical Assessment Criteria Document

### 23. Project Manager schedules the initial kick-off meeting for the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation Emails

### 24. Hold the initial kick-off meeting for the Technical Advisory Group (TAG).

**Responsible Body/Role:** Technical Advisory Group (TAG)

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 25. Compliance Officer develops a compliance plan for the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Compliance Officer

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- ECC Compliance Plan v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 26. Compliance Officer establishes reporting channels for compliance violations for the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Compliance Officer

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- ECC Reporting Channels Document

**Dependencies:**

- ECC Compliance Plan v0.1

### 27. Legal Counsel creates a code of conduct for the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- ECC Code of Conduct v0.1

**Dependencies:**

- ECC Reporting Channels Document

### 28. Compliance Officer identifies key regulatory requirements for the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Compliance Officer

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- ECC Key Regulatory Requirements Document

**Dependencies:**

- ECC Code of Conduct v0.1

### 29. Data Protection Officer establishes data privacy and security protocols for the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Data Protection Officer

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- ECC Data Privacy and Security Protocols Document

**Dependencies:**

- ECC Key Regulatory Requirements Document

### 30. Project Manager formally confirms membership of the Ethics & Compliance Committee (ECC) with all members (Compliance Officer, Legal Counsel, HR Representative, Independent Ethics Advisor, Data Protection Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- ECC Data Privacy and Security Protocols Document

### 31. Project Manager schedules the initial kick-off meeting for the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation Emails

### 32. Hold the initial kick-off meeting for the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Ethics & Compliance Committee (ECC)

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Approved Compliance Plan v1.0

**Dependencies:**

- Meeting Invitation
- Agenda