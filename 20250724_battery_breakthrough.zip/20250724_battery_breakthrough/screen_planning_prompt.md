**Verdict:** 🟢 USABLE

**Rationale:** The prompt describes a concrete project with specific goals (battery performance), budget, timeline, and location. It provides enough detail to generate a multi-step plan for battery research and development.