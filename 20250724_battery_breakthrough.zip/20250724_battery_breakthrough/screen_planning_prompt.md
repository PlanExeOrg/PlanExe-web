**Verdict:** 🟢 USABLE

**Rationale:** This prompt describes a concrete, highly specialized R&D project—inventing a next-generation battery—with specific technical metrics, budget, and location provided.