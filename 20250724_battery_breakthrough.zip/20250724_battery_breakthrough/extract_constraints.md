## Positive Constraints

- Gravimetric ≥ 500 Wh/kg
- Volumetric ≥ 1000 Wh/L
- Budget: USD 300 M
- Timeline: 7 years
- Location is near Tesla in Austin, Texas
- Project start ASAP

## Negative Constraints

- The goal is NOT to become a major market-dominant industrial player
