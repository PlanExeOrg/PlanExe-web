## Positive Constraints

- Invent a next-generation rechargeable battery
- Gravimetric energy density goal ≥ 500 Wh/kg
- Volumetric energy density goal ≥ 1000 Wh/L
- Budget: USD 300 M
- Timeline: 7 years
- Location near Tesla in Austin, Texas
- Project start ASAP

## Negative Constraints

- Do not become a major market-dominant industrial player
