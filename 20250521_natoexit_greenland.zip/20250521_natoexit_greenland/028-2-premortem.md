A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The Greenlandic population will passively accept US occupation. | Conduct a public opinion survey in Nuuk regarding attitudes towards a hypothetical US military presence. | Survey results indicate that more than 30% of the population would actively resist a US occupation. |
| A2 | Article 51 provides a sufficient legal basis for the intervention. | Solicit a legal opinion from three independent international law experts on the applicability of Article 51 to the planned operation. | Two or more legal experts conclude that Article 51 is an insufficient legal basis for the intervention. |
| A3 | Phase 1 can be completed within 48 hours. | Conduct a military simulation of Phase 1, incorporating realistic variables such as weather, equipment failure rates, and varying levels of resistance. | The simulation results indicate that Phase 1 cannot be reliably completed within 48 hours under realistic conditions. |
| A4 | Existing infrastructure in Nuuk is sufficient to support initial military operations. | Conduct a detailed assessment of the capacity and condition of Nuuk's airport, port, and communication networks. | The assessment reveals that the airport runway cannot accommodate large transport aircraft, the port lacks sufficient docking capacity, or the communication networks are unreliable. |
| A5 | The Greenlandic government's assets can be easily seized and repurposed. | Conduct a thorough audit of the Greenlandic government's assets, including buildings, vehicles, and equipment, to determine their suitability for US military use. | The audit reveals that the assets are in poor condition, require extensive modifications, or are subject to legal restrictions that prevent their seizure. |
| A6 | The US military has sufficient cold-weather gear and training for Arctic operations. | Assess the readiness of US military units designated for the Greenland operation, focusing on their cold-weather gear, training, and experience in Arctic environments. | The assessment reveals that the units lack adequate cold-weather gear, have not received sufficient training in Arctic survival and combat, or lack experience operating in similar environments. |
| A7 | The US can effectively control the narrative within Greenlandic social media. | Monitor Greenlandic social media platforms for sentiment analysis regarding US presence and messaging. | Analysis reveals that US-sponsored content is consistently drowned out by negative or dissenting voices, with limited organic engagement. |
| A8 | Denmark will not actively seek support from other nations to counter the US operation. | Monitor diplomatic communications and public statements from Denmark and other nations regarding the US operation. | Denmark formally requests military or economic assistance from other nations (e.g., EU, NATO members) to pressure the US to withdraw. |
| A9 | There are sufficient English-speaking Greenlanders to fill essential administrative roles. | Assess the English language proficiency of the Greenlandic workforce through standardized testing and interviews. | Testing reveals a significant shortage of Greenlanders with the required English proficiency to effectively perform essential administrative tasks. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Sanction Spiral | Process/Financial | A2 | State Department Legal Advisor | CRITICAL (20/25) |
| FM2 | The Arctic Quagmire | Technical/Logistical | A3 | Head of Engineering | HIGH (12/25) |
| FM3 | The Hearts and Minds Meltdown | Market/Human | A1 | Permitting Lead | CRITICAL (25/25) |
| FM4 | The Frostbite Fiasco | Process/Financial | A6 | Head of Engineering | CRITICAL (20/25) |
| FM5 | The Asset Impasse | Technical/Logistical | A5 | Head of Engineering | HIGH (12/25) |
| FM6 | The Infrastructure Inferno | Market/Human | A4 | Permitting Lead | CRITICAL (25/25) |
| FM7 | The Echo Chamber Effect | Market/Human | A7 | Permitting Lead | CRITICAL (25/25) |
| FM8 | The Babel Blockade | Technical/Logistical | A9 | Head of Engineering | CRITICAL (16/25) |
| FM9 | The Diplomatic Domino Effect | Process/Financial | A8 | State Department Legal Advisor | CRITICAL (15/25) |


### Failure Modes

#### FM1 - The Sanction Spiral

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: State Department Legal Advisor
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The US proceeds with the Nuuk operation based solely on a tenuous claim of self-defense under Article 51. International legal scholars and key allies immediately denounce the action as a violation of international law. 

*   The UN Security Council passes a resolution condemning the intervention, leading to escalating economic sanctions from the EU, Canada, and other nations.
*   These sanctions cripple the US economy, particularly impacting companies involved in Arctic resource extraction and trade.
*   The Greenland & Strategic Realignment Task Force budget is slashed due to domestic economic pressures, halting infrastructure development and civilian assistance programs.
*   Without a credible legal basis, the US faces mounting legal challenges in international courts, incurring significant legal fees and potential financial penalties.
*   The operation becomes a financial black hole, draining resources and undermining US credibility on the global stage.

##### Early Warning Signs
- Key NATO allies publicly express reservations about the legal justification within 72 hours of the operation's commencement.
- The UN Security Council schedules an emergency session to discuss the intervention within 48 hours.
- Major international financial institutions downgrade the US credit rating within one week.

##### Tripwires
- UN Security Council passes a resolution condemning the intervention = True
- EU imposes economic sanctions on US Arctic resource companies = True
- US credit rating downgraded by two or more major agencies = True

##### Response Playbook
- Contain: Immediately engage in high-level diplomatic negotiations with key allies to address their concerns and seek a compromise.
- Assess: Commission an independent legal review to identify alternative legal justifications and assess the potential for mitigating international legal challenges.
- Respond: Prepare a contingency plan for withdrawing US forces from Greenland if diplomatic and legal efforts fail to alleviate international pressure.


**STOP RULE:** If sanctions are imposed by more than 3 of the G7 nations, the project is cancelled.

---

#### FM2 - The Arctic Quagmire

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A3
- **Owner**: Head of Engineering
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The initial assault on Nuuk is predicated on a rapid 48-hour takeover. However, unforeseen logistical challenges and fierce Greenlandic resistance quickly derail the timeline.

*   Unexpectedly severe weather conditions ground air transport, delaying troop deployments and equipment deliveries.
*   Special forces encounter unexpectedly well-organized and motivated resistance from local militias, equipped with cold-weather gear and intimate knowledge of the terrain.
*   Critical equipment malfunctions due to the extreme cold, including communication systems and armored vehicles.
*   Supply lines become stretched and vulnerable, leading to shortages of essential supplies and ammunition.
*   The operation bogs down into a protracted and costly quagmire, with US forces struggling to maintain control and facing mounting casualties.

##### Early Warning Signs
- Air transport delays due to weather exceed 24 hours within the first 48 hours of the operation.
- Equipment failure rates in the field exceed 15% within the first week.
- Casualty rates among US forces exceed 5% within the first month.

##### Tripwires
- Air transport grounded for >= 36 hours due to weather
- Equipment failure rate >= 20% in first week
- Casualties >= 10% in first month

##### Response Playbook
- Contain: Immediately reinforce the perimeter around Nuuk and prioritize securing essential supply routes.
- Assess: Conduct a comprehensive reassessment of logistical capabilities and identify alternative supply routes and equipment options.
- Respond: Request additional resources and personnel with Arctic warfare expertise and adjust operational tactics to account for the challenging environment and determined resistance.


**STOP RULE:** If the operation fails to secure Nuuk International Airport within 72 hours, the project is cancelled.

---

#### FM3 - The Hearts and Minds Meltdown

- **Archetype**: Market/Human
- **Root Cause**: Assumption A1
- **Owner**: Permitting Lead
- **Risk Level:** CRITICAL 25/25 (Likelihood 5/5 × Impact 5/5)

##### Failure Story
The US assumes the Greenlandic population will passively accept the intervention. Instead, a wave of resentment and resistance sweeps across the island.

*   The lack of cultural sensitivity and the imposition of strict information control protocols alienate the local population.
*   A grassroots resistance movement emerges, employing tactics such as civil disobedience, sabotage, and non-cooperation.
*   International media outlets highlight human rights abuses and the suppression of Greenlandic culture, further damaging the US's reputation.
*   The absence of a compelling 'killer application' leaves the Greenlandic population feeling exploited and disregarded.
*   The operation becomes a public relations disaster, undermining US credibility and fueling anti-American sentiment worldwide.

##### Early Warning Signs
- Participation in protests and acts of civil disobedience exceeds 10% of the population within the first month.
- Local media outlets refuse to cooperate with US information control protocols within the first week.
- Approval ratings for the US presence in Greenland fall below 20% within the first two months.

##### Tripwires
- Protest participation >= 15% of population
- Local media cooperation <= 25%
- Approval rating <= 10% after 2 months

##### Response Playbook
- Contain: Immediately suspend all information control protocols and prioritize open communication with the Greenlandic population.
- Assess: Conduct a comprehensive review of cultural sensitivity training programs and community engagement strategies.
- Respond: Develop and implement a compelling 'killer application' that directly addresses the needs and concerns of the Greenlandic population and fosters a sense of partnership and mutual benefit.


**STOP RULE:** If approval ratings fall below 5% after 3 months, the project is cancelled.

---

#### FM4 - The Frostbite Fiasco

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A6
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The US military assumes it's adequately prepared for Arctic conditions. However, the reality on the ground proves drastically different.

*   Troops arrive in Nuuk with insufficient cold-weather gear, leading to widespread cases of frostbite and hypothermia.
*   Equipment malfunctions at an alarming rate due to the extreme cold, requiring costly repairs and replacements.
*   Medical facilities are overwhelmed with cold-weather casualties, straining resources and diverting personnel from other critical tasks.
*   The operation grinds to a halt as troops struggle to cope with the harsh environment, leading to significant delays and cost overruns.
*   Public outrage erupts back home as images of suffering soldiers circulate online, further undermining support for the intervention.

##### Early Warning Signs
- Medical supply requests for cold-weather injuries exceed projected levels by 50% within the first week.
- Equipment failure rates due to cold weather exceed 25% within the first two weeks.
- Troop morale surveys indicate a significant decline in confidence and motivation within the first month.

##### Tripwires
- Cold weather injury reports >= 50% projected
- Equipment failure rate >= 25%
- Troop morale <= 2 (out of 5)

##### Response Playbook
- Contain: Immediately procure and distribute additional cold-weather gear to all personnel.
- Assess: Conduct a thorough review of cold-weather training programs and identify areas for improvement.
- Respond: Implement mandatory cold-weather survival training for all personnel and adjust operational tactics to minimize exposure to the elements.


**STOP RULE:** If cold-weather injuries incapacitate more than 20% of the deployed force, the project is cancelled.

---

#### FM5 - The Asset Impasse

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Head of Engineering
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The US military assumes it can easily seize and repurpose Greenlandic government assets. However, this proves to be a major obstacle.

*   Key government buildings are found to be structurally unsound or unsuitable for military use, requiring extensive and costly renovations.
*   Vehicles and equipment are in disrepair or lack the necessary modifications for military operations, leading to delays and logistical bottlenecks.
*   Legal challenges arise regarding the seizure of assets, further complicating the process and incurring legal fees.
*   The operation is hampered by a lack of suitable facilities and equipment, hindering its ability to establish control and provide essential services.
*   The Greenlandic population views the seizure of assets as an act of aggression, fueling resentment and resistance.

##### Early Warning Signs
- Renovation costs for government buildings exceed initial estimates by 75% within the first month.
- Equipment failure rates for seized vehicles and equipment exceed 30% within the first two weeks.
- Legal challenges regarding asset seizure are filed in international courts within the first month.

##### Tripwires
- Renovation costs >= 75% initial estimate
- Equipment failure rate >= 30%
- International legal challenges = True

##### Response Playbook
- Contain: Immediately halt all further asset seizures and prioritize securing existing US military facilities.
- Assess: Conduct a comprehensive reassessment of asset needs and identify alternative sources of equipment and facilities.
- Respond: Procure additional equipment and facilities from external sources and adjust operational tactics to minimize reliance on seized assets.


**STOP RULE:** If the operation cannot secure adequate facilities and equipment within 60 days, the project is cancelled.

---

#### FM6 - The Infrastructure Inferno

- **Archetype**: Market/Human
- **Root Cause**: Assumption A4
- **Owner**: Permitting Lead
- **Risk Level:** CRITICAL 25/25 (Likelihood 5/5 × Impact 5/5)

##### Failure Story
The US assumes that existing infrastructure in Nuuk is sufficient to support initial military operations. This proves disastrously wrong.

*   The airport runway is too short to accommodate large transport aircraft, forcing troops and equipment to be offloaded at a distant and ill-equipped airfield.
*   The port lacks sufficient docking capacity, creating a massive backlog of ships waiting to unload supplies.
*   Communication networks are unreliable and easily disrupted, hindering coordination and command and control.
*   The operation is crippled by a lack of essential infrastructure, leading to delays, cost overruns, and a decline in troop morale.
*   The Greenlandic population suffers from disruptions to essential services, further fueling resentment and resistance.

##### Early Warning Signs
- Air transport delays due to inadequate runway capacity exceed 48 hours within the first week.
- Shipping delays due to insufficient docking capacity exceed 72 hours within the first two weeks.
- Communication outages disrupt military operations for more than 24 hours within the first month.

##### Tripwires
- Air transport delay >= 48 hours
- Shipping delay >= 72 hours
- Communication outage >= 24 hours

##### Response Playbook
- Contain: Immediately prioritize upgrading the airport runway and port facilities.
- Assess: Conduct a comprehensive assessment of infrastructure needs and identify alternative solutions for transportation and communication.
- Respond: Request additional resources and personnel to expedite infrastructure upgrades and implement backup communication systems.


**STOP RULE:** If essential infrastructure upgrades cannot be completed within 90 days, the project is cancelled.

---

#### FM7 - The Echo Chamber Effect

- **Archetype**: Market/Human
- **Root Cause**: Assumption A7
- **Owner**: Permitting Lead
- **Risk Level:** CRITICAL 25/25 (Likelihood 5/5 × Impact 5/5)

##### Failure Story
The US assumes it can dominate the narrative on Greenlandic social media. Instead, it creates an echo chamber that amplifies dissent.

*   US-sponsored content is perceived as propaganda and is widely ignored or ridiculed by Greenlandic users.
*   Authentic Greenlandic voices are drowned out by coordinated disinformation campaigns, further alienating the local population.
*   Social media platforms become a breeding ground for anti-US sentiment and organized resistance.
*   The US loses control of the narrative, allowing misinformation and conspiracy theories to spread unchecked.
*   The operation suffers a major public relations setback, undermining its legitimacy and fueling international condemnation.

##### Early Warning Signs
- Engagement rates (likes, shares, comments) on US-sponsored social media content fall below 1% within the first week.
- Negative sentiment towards the US on Greenlandic social media platforms exceeds 75% within the first month.
- Reports of organized disinformation campaigns targeting US messaging increase by 50% within the first two weeks.

##### Tripwires
- Engagement rate <= 1%
- Negative sentiment >= 75%
- Disinformation reports >= 50% increase

##### Response Playbook
- Contain: Immediately suspend all US-sponsored social media campaigns and conduct a thorough review of messaging strategies.
- Assess: Conduct a focus group with Greenlandic social media users to understand their concerns and preferences.
- Respond: Develop a new communication strategy that prioritizes authentic Greenlandic voices and promotes open dialogue and transparency.


**STOP RULE:** If negative sentiment exceeds 90% after 3 months, the project is cancelled.

---

#### FM8 - The Babel Blockade

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A9
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The US assumes there are enough English-speaking Greenlanders to fill essential administrative roles. This proves to be a critical bottleneck.

*   A shortage of qualified translators and interpreters hinders communication between US administrators and the Greenlandic population.
*   Essential administrative tasks are delayed or mishandled due to language barriers, leading to inefficiencies and errors.
*   The Greenlandic population feels excluded and marginalized, further fueling resentment and resistance.
*   The operation struggles to establish a functioning government, undermining its legitimacy and long-term sustainability.
*   Recruiting and training local personnel becomes a costly and time-consuming endeavor, straining resources and delaying progress.

##### Early Warning Signs
- Administrative task completion rates fall below 50% within the first month.
- Requests for translation services exceed available capacity by 100% within the first two weeks.
- Surveys indicate that more than 60% of Greenlanders feel excluded from the administrative process due to language barriers.

##### Tripwires
- Admin task completion <= 50%
- Translation requests >= 100% capacity
- Greenlanders feeling excluded >= 60%

##### Response Playbook
- Contain: Immediately prioritize recruiting and training additional translators and interpreters.
- Assess: Conduct a comprehensive assessment of language proficiency needs and identify alternative communication strategies.
- Respond: Implement mandatory language training for US administrators and develop user-friendly translation tools and resources.


**STOP RULE:** If essential administrative functions remain significantly impaired due to language barriers after 6 months, the project is cancelled.

---

#### FM9 - The Diplomatic Domino Effect

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A8
- **Owner**: State Department Legal Advisor
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The US assumes Denmark will not actively seek support from other nations. This proves to be a fatal miscalculation.

*   Denmark formally requests assistance from the EU, triggering a coordinated diplomatic and economic response.
*   The EU imposes sanctions on the US, crippling trade and investment in Greenland.
*   NATO members express concerns about the US's unilateral action, undermining alliance cohesion.
*   International financial institutions downgrade Greenland's credit rating, making it difficult to secure funding for development projects.
*   The operation becomes a financial and diplomatic disaster, isolating the US and jeopardizing its long-term strategic goals.

##### Early Warning Signs
- Denmark formally requests assistance from the EU within the first week.
- The EU announces sanctions on the US within the first month.
- Key NATO members publicly express concerns about the US operation within the first two weeks.

##### Tripwires
- EU assistance request = True
- EU sanctions = True
- NATO concerns = True

##### Response Playbook
- Contain: Immediately engage in high-level diplomatic negotiations with Denmark and the EU to address their concerns and seek a compromise.
- Assess: Conduct a comprehensive assessment of the potential economic and diplomatic consequences of EU sanctions.
- Respond: Prepare a contingency plan for withdrawing US forces from Greenland if diplomatic efforts fail to alleviate international pressure.


**STOP RULE:** If the EU imposes sanctions that significantly impact US economic interests, the project is cancelled.
