### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** Provides strategic oversight and direction for this high-risk, high-impact geopolitical project. Ensures alignment with overall US strategic objectives and manages key strategic risks.

**Responsibilities:**

- Approve project scope, budget, and schedule.
- Provide strategic guidance and direction.
- Monitor project progress against strategic objectives.
- Approve major changes to project scope, budget, or schedule (>$50M).
- Oversee strategic risk management and mitigation.
- Resolve strategic conflicts and escalate issues as needed.
- Approve key strategic decisions (e.g., Resistance Mitigation approach, NATO Perception Management strategy).
- Ensure compliance with international law and US policy.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define escalation paths.
- Approve initial risk register.

**Membership:**

- Senior Representative from the National Security Council (Chair)
- Representative from the Department of Defense
- Representative from the Department of State
- Representative from the Intelligence Community
- Independent Legal Counsel (External)
- Independent Ethics Advisor (External)

**Decision Rights:** Strategic decisions related to project scope, budget (>$50M), schedule, and strategic risks. Approval of key strategic decisions as defined in the strategic decisions document.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Chair (Senior Representative from the National Security Council) has the deciding vote. Dissenting opinions are formally recorded.

**Meeting Cadence:** Monthly, or more frequently as needed during critical phases.

**Typical Agenda Items:**

- Review of project progress against strategic objectives.
- Review of key strategic risks and mitigation plans.
- Discussion and approval of major changes to project scope, budget, or schedule.
- Review of compliance with international law and US policy.
- Decision on key strategic issues (e.g., Resistance Mitigation approach, NATO Perception Management strategy).

**Escalation Path:** National Security Advisor
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages day-to-day execution of the project, ensuring efficient resource allocation, risk management, and adherence to project plans. Provides operational support to the Project Steering Committee.

**Responsibilities:**

- Develop and maintain project plans, schedules, and budgets.
- Manage project resources and track expenditures.
- Monitor project progress and identify potential issues.
- Implement risk management plans and escalate issues as needed.
- Coordinate communication between project teams and stakeholders.
- Prepare reports for the Project Steering Committee.
- Manage operational decisions (e.g., resource allocation within budget, schedule adjustments within approved timelines).
- Ensure compliance with project standards and procedures.

**Initial Setup Actions:**

- Establish PMO structure and staffing.
- Develop project management templates and tools.
- Define project reporting requirements.
- Establish communication protocols.

**Membership:**

- Project Manager (PMO Lead)
- Project Controller
- Risk Manager
- Communications Manager
- Representatives from key project teams (e.g., Special Forces Liaison, PAA Liaison)

**Decision Rights:** Operational decisions related to project execution, resource allocation within approved budgets, and schedule adjustments within approved timelines. Decisions below $50M.

**Decision Mechanism:** Decisions made by the Project Manager, in consultation with the PMO team. Disagreements escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of potential issues and risks.
- Review of resource allocation and expenditures.
- Update on communication with stakeholders.
- Action item tracking.

**Escalation Path:** Project Steering Committee
### 3. Ethics & Compliance Committee (ECC)

**Rationale for Inclusion:** Ensures the project adheres to the highest ethical standards and complies with all applicable laws and regulations, including international law, human rights standards, and GDPR. Provides independent oversight and guidance on ethical considerations.

**Responsibilities:**

- Develop and maintain a code of ethics for the project.
- Provide guidance on ethical issues and dilemmas.
- Monitor compliance with international law, human rights standards, and GDPR.
- Investigate allegations of ethical misconduct or non-compliance.
- Recommend corrective actions to address ethical or compliance violations.
- Conduct regular audits of project activities to ensure compliance.
- Provide training on ethical and compliance issues to project personnel.
- Oversee data protection and privacy measures.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Develop code of ethics.
- Establish reporting mechanisms for ethical concerns.

**Membership:**

- Independent Legal Counsel (Chair, External)
- Independent Ethics Advisor (External)
- Representative from the Department of Justice
- Representative from the Department of State (Human Rights Desk)
- Data Protection Officer
- Representative from the Intelligence Community (Compliance Officer)

**Decision Rights:** Decisions related to ethical conduct, compliance with laws and regulations, and data protection. Authority to halt project activities that violate ethical standards or legal requirements.

**Decision Mechanism:** Decisions made by majority vote. The Independent Legal Counsel (Chair) has the deciding vote in case of a tie.

**Meeting Cadence:** Bi-weekly, or more frequently as needed to address urgent ethical or compliance issues.

**Typical Agenda Items:**

- Review of ethical concerns and dilemmas.
- Review of compliance with international law, human rights standards, and GDPR.
- Discussion of potential ethical or compliance risks.
- Review of audit findings.
- Update on training activities.
- Review of data protection measures.

**Escalation Path:** Project Steering Committee, National Security Advisor
### 4. Technical Advisory Group (TAG)

**Rationale for Inclusion:** Provides expert technical advice on all aspects of the project, ensuring the use of best practices and minimizing technical risks. Offers independent assessment of technical feasibility and potential challenges.

**Responsibilities:**

- Review and assess technical plans and designs.
- Provide expert advice on technical issues and challenges.
- Identify potential technical risks and recommend mitigation strategies.
- Evaluate the feasibility of proposed technical solutions.
- Monitor the implementation of technical plans and designs.
- Conduct independent technical audits.
- Advise on the selection of technology vendors and partners.
- Ensure interoperability of systems and technologies.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Identify and recruit technical experts.
- Establish meeting schedule.
- Define communication protocols.

**Membership:**

- Chief Technology Officer (Chair)
- Senior Engineer (DoD)
- Cybersecurity Expert (Intelligence Community)
- Logistics Specialist (DoD)
- Infrastructure Expert (External)
- Communications Technology Expert (External)

**Decision Rights:** Provides recommendations on technical matters. Has the authority to flag critical technical risks to the Project Steering Committee.

**Decision Mechanism:** Decisions made by consensus. Dissenting opinions are formally recorded and escalated to the Project Steering Committee.

**Meeting Cadence:** Bi-weekly, or more frequently as needed to address urgent technical issues.

**Typical Agenda Items:**

- Review of technical plans and designs.
- Discussion of technical issues and challenges.
- Identification of potential technical risks.
- Evaluation of proposed technical solutions.
- Review of technical audit findings.
- Update on technology vendor selection.

**Escalation Path:** Project Steering Committee
### 5. Stakeholder Engagement Group (SEG)

**Rationale for Inclusion:** Manages communication and engagement with key stakeholders, including the Greenlandic population, the Danish government, NATO members, and international organizations. Ensures that stakeholder concerns are addressed and that the project is perceived as legitimate and beneficial.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Conduct regular consultations with key stakeholders.
- Address stakeholder concerns and grievances.
- Manage communication with the public and the media.
- Monitor public opinion and identify potential issues.
- Provide cultural sensitivity training to project personnel.
- Facilitate dialogue between stakeholders.
- Promote transparency and accountability.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Identify key stakeholders.
- Develop stakeholder engagement plan.
- Establish communication protocols.

**Membership:**

- Communications Manager (Chair)
- Public Affairs Officer (DoD)
- Diplomatic Liaison (Department of State)
- Cultural Advisor (External)
- Greenlandic Representative (External)
- NATO Liaison (Department of State)

**Decision Rights:** Decisions related to stakeholder engagement strategies and communication plans. Authority to recommend changes to project activities to address stakeholder concerns.

**Decision Mechanism:** Decisions made by consensus. Dissenting opinions are formally recorded and escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly, or more frequently as needed to address urgent stakeholder concerns.

**Typical Agenda Items:**

- Review of stakeholder engagement activities.
- Discussion of stakeholder concerns and grievances.
- Review of public opinion and media coverage.
- Update on communication with stakeholders.
- Planning for upcoming stakeholder events.

**Escalation Path:** Project Steering Committee