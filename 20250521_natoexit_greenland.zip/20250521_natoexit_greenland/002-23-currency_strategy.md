This plan involves money.

## Currencies

- **USD:** Primary currency for budgeting and large-scale operations.
- **DKK:** Local currency of Greenland for local transactions and expenses.

**Primary currency:** USD

**Currency strategy:** USD will be used for budgeting and reporting. DKK will be used for local transactions. Given the scale and geopolitical nature of the project, hedging against DKK exchange rate fluctuations may be necessary.