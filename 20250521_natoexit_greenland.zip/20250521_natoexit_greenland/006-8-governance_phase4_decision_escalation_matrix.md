**Budget Request Exceeding PMO Authority ($50M)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Vote
Rationale: Exceeds financial limit of PMO's decision rights and requires strategic oversight.
Negative Consequences: Potential budget overrun and misalignment with strategic objectives.

**Critical Risk Materialization (e.g., Danish Military Intervention)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Discussion and Recommendation to National Security Advisor
Rationale: Strategic impact requires higher-level assessment and potential course correction.
Negative Consequences: Project failure, international conflict, and significant geopolitical damage.

**PMO Deadlock on Resource Allocation**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Decision
Rationale: Requires strategic guidance to resolve conflicting priorities and ensure efficient resource utilization.
Negative Consequences: Project delays, inefficient resource allocation, and potential failure to meet objectives.

**Proposed Major Scope Change (e.g., Expanding Area of Control)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Vote
Rationale: Significant impact on project objectives, budget, and timeline requires strategic approval.
Negative Consequences: Project scope creep, budget overruns, and failure to achieve strategic goals.

**Reported Ethical Concern (e.g., Violation of Human Rights)**
Escalation Level: Ethics & Compliance Committee (ECC)
Approval Process: Ethics Committee Investigation & Recommendation to Project Steering Committee
Rationale: Requires independent review and potential corrective action to ensure ethical conduct and compliance with laws.
Negative Consequences: Legal penalties, reputational damage, and undermining of project legitimacy.

**Technical Design Flaw Endangering Operational Success**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review of TAG Recommendation and Decision
Rationale: Critical technical risks require strategic oversight and potential resource reallocation.
Negative Consequences: Operational failure, increased security risks, and project delays.

**Stakeholder Grievance Causing Significant Reputational Damage**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review of SEG Recommendation and Decision
Rationale: Requires strategic intervention to mitigate reputational damage and maintain stakeholder support.
Negative Consequences: Increased resistance, international condemnation, and undermining of project legitimacy.