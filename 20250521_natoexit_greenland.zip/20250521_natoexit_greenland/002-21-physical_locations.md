This plan implies one or more physical locations.

## Requirements for physical locations

- Control of Nuuk International Airport
- Seizure of police HQ
- Control of Nuuk harbor
- Ability to rapidly deploy special forces and light armor

## Location 1
Greenland

Nuuk

Nuuk International Airport

**Rationale**: Essential for initial insertion of forces and equipment. Securing the airport is the first step in the plan.

## Location 2
Greenland

Nuuk

Nuuk Police Headquarters

**Rationale**: Critical for neutralizing local security forces and establishing control over law enforcement.

## Location 3
Greenland

Nuuk

Port of Nuuk

**Rationale**: Necessary for controlling access to the city and facilitating the deployment of follow-on forces and supplies.

## Location Summary
The plan requires seizing and controlling key locations in Nuuk, Greenland, including the international airport, police headquarters, and harbor, to establish US control and project power.