Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 17 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 2 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The plan focuses on geopolitical strategy, resource control, and military operations, which are all within the realm of possibility according to current understanding of physics. No quotes apply.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of military seizure, geopolitical signaling, and resource control in Greenland, without independent evidence at comparable scale. There is no precedent for the US seizing territory from a self-governing region within a NATO member state to signal autonomy.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Each track must produce one authoritative source or a supervised pilot showing results vs a baseline. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Owner: Project Lead / Deliverable: Validation Report / Date: 2025-05-29.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks definitions of key strategic concepts like "signaling US autonomy to NATO." The plan states the "Goal Statement: Seize and control Nuuk, Greenland, to signal US autonomy to NATO" but does not define how this signaling works or how success is measured.

**Mitigation**: Strategy Team: Develop one-pagers defining "signaling US autonomy to NATO" with a mechanism-of-action, owner, and measurable outcomes. Deliverable: One-pagers / Date: 2025-05-27.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan minimizes or omits major hazard classes. The plan mentions "Environmental impact" as a risk, but lacks explicit analysis of legal, safety, financial, and reputational cascades. The plan does not analyze cascades explicitly.

**Mitigation**: Risk Management: Expand the risk register to include legal, safety, financial, and reputational risks, map cascades, and add controls with a dated review cadence. Deliverable: Updated risk register / Date: 2025-06-07.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions "Authorization for military operations in foreign territory. Exemption from international laws regarding sovereignty. Permits for operating infrastructure in Greenland" but does not include lead times.

**Mitigation**: Legal Team: Create a permit/approval matrix with authoritative lead times for each required approval, including a NO-GO threshold on slip. Deliverable: Permit Matrix / Date: 2025-05-30.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the funding sources are not fully committed and do not cover the required runway. The plan states "Funding from Classified Presidential directive (Phase 1). Funding from inter-agency Greenland & Strategic Realignment Task Force budget (Phase 2)." The status, draw schedule, and covenants are undefined.

**Mitigation**: CFO: Develop a dated financing plan listing funding sources, status, draw schedule, covenants, and a NO-GO on missed financing gates. Deliverable: Financing Plan / Date: 2025-05-30.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget lacks scale-appropriate benchmarks or vendor quotes. The plan states "Phase 1: $500 million (classified presidential directive). Phase 2: $1 billion (inter-agency Greenland Task Force)." but provides no cost per area or justification.

**Mitigation**: CFO: Benchmark costs (≥3) for similar Arctic operations, normalize per area (m²/ft²), obtain vendor quotes, and adjust budget or de-scope. Deliverable: Cost Justification Report / Date: 2025-06-07.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections as single numbers without ranges or alternative scenarios. For example, the plan aims to establish a Provisional Administrative Authority (PAA) within 30 days, but does not discuss alternative timelines.

**Mitigation**: Project Management: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the PAA establishment timeline. Deliverable: Scenario Analysis Report / Date: 2025-05-31.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because build‑critical components lack engineering artifacts. The plan mentions "Elite US special forces. Civilian-patterned air transport. Light armor. US administrators. Public order specialists" but lacks technical specs, interface definitions, test plans, and an integration map.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components. Deliverable: Engineering Artifacts / Date: 2025-06-14.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes critical legal and operational claims without verifiable artifacts. For example, the plan states it will "Develop legal justification based on Article 51 of the UN Charter" but lacks a draft legal opinion or analysis.

**Mitigation**: Legal Team: Draft a legal opinion analyzing the applicability of Article 51 to the Greenland operation, including potential challenges. Deliverable: Legal Opinion / Date: 2025-05-30.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the deliverable "Provisional Administrative Authority (PAA)" is mentioned without specific, verifiable qualities. The plan states: "Establish a Provisional Administrative Authority (PAA) within 30 days" but does not define its structure, powers, or acceptance criteria.

**Mitigation**: Governance Team: Define SMART criteria for the PAA, including a KPI for local participation (e.g., % of Greenlanders in PAA leadership) by 2025-05-30.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'Information Control Protocols' that implement 'strict censorship and propaganda measures.' This feature does not directly support the core project goals of securing Nuuk or establishing a US military presence. The core goals are geopolitical strategy and resource control.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of 'strict censorship and propaganda measures,' complete with a KPI, owner, and estimated cost, or move the feature to the project backlog. Owner: Project Lead / Deliverable: Benefit Case / Date: 2025-05-27.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a 'Cultural Liaison' with deep understanding of Greenlandic culture, social dynamics, and political landscape, which is critical and likely difficult to find. The plan states, "crucial for minimizing resistance and fostering cooperation."

**Mitigation**: HR: Validate the talent market for a Greenlandic Cultural Liaison with relevant experience and language skills as an early go/no-go check. Deliverable: Talent Market Assessment / Date: 2025-05-27.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a regulatory matrix mapping authorities, required artifacts, lead times, and predecessors. The plan mentions "Authorization for military operations in foreign territory" but does not specify the authority or artifact.

**Mitigation**: Legal Team: Develop a regulatory matrix identifying all required permits/licenses, governing authorities, required artifacts, lead times, and predecessors. Deliverable: Regulatory Matrix / Date: 2025-05-30.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan lacks a comprehensive operational sustainability plan. The plan mentions "Long-term infrastructure investment and economic opportunities" but does not detail funding, maintenance, succession, or technology adaptation. The plan does not discuss personnel dependency or technology obsolescence.

**Mitigation**: Project Team: Develop an operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, and technology roadmap. Deliverable: Sustainability Plan / Date: 2025-06-14.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks evidence of zoning or land-use analysis for the proposed military infrastructure. The plan requires "Control of Nuuk International Airport," but does not address noise limits or fire load. The plan does not mention fallback sites.

**Mitigation**: Engineering Team: Conduct a fatal-flaw screen with authorities/experts regarding zoning, land-use, and structural limits. Define fallback designs/sites and NO-GO thresholds. Deliverable: Fatal-Flaw Screen Report / Date: 2025-06-07.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan lacks tested failovers for external dependencies. The plan mentions "Secure supply lines" but does not include SLAs with vendors or tested failover plans. The plan does not include secondary suppliers or paths.

**Mitigation**: Logistics Coordinator: Secure SLAs with key vendors, add a secondary supplier/path for critical resources, and test failover procedures by 2025-06-14.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'US Special Forces' are incentivized by mission success (swift control), while the 'Greenlandic Population' is incentivized by self-determination. This creates a conflict over governance and resource control. The plan does not address this conflict.

**Mitigation**: Project Lead: Define a shared OKR (Objective and Key Results) that aligns US Special Forces and the Greenlandic Population on a common outcome, such as 'Improved Quality of Life'. Deliverable: Shared OKR / Date: 2025-05-30.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient. No quotes apply.

**Mitigation**: Project Management: Add a monthly review with KPI dashboard, owners, and a lightweight change board with thresholds for re-planning/stopping. Deliverable: Review Cadence / Date: 2025-05-30.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan couples ≥3 High risks: (1) Military & Security (potential war crimes), (2) NATO Relations (alliance breakdown), and (3) Danish Sovereignty (diplomatic crisis). A weak legal justification can trigger all three, leading to project failure.

**Mitigation**: Risk Management: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Owner: Risk Management Specialist / Deliverable: Risk Assessment / Date: 2025-06-14.