### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1

**Dependencies:**

- Project Start
- Project Plan Approved

### 2. Circulate Draft PSC ToR v0.1 for review by Senior Representative from the National Security Council, Representative from the Department of Defense, Representative from the Department of State, Representative from the Intelligence Community.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft PSC ToR v0.1

### 3. Project Manager incorporates feedback and finalizes the PSC ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Final PSC ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Senior Representative from the National Security Council formally appointed as the Chair of the Project Steering Committee (PSC).

**Responsible Body/Role:** National Security Advisor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final PSC ToR v1.0

### 5. Project Manager coordinates with Department of Defense, Department of State, and the Intelligence Community to confirm representatives for the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Confirmed Membership List

**Dependencies:**

- Appointment of PSC Chair

### 6. Project Sponsor formally appoints Independent Legal Counsel and Independent Ethics Advisor to the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Letters

**Dependencies:**

- Confirmed Membership List

### 7. Project Manager schedules and facilitates the initial kick-off meeting for the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Appointment of PSC Chair
- Confirmed Membership List

### 8. Project Steering Committee (PSC) approves initial risk register.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved Initial Risk Register

**Dependencies:**

- Meeting Minutes with Action Items

### 9. Project Manager establishes the Project Management Office (PMO) structure and staffing.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- PMO Structure Chart
- Staffing Plan

**Dependencies:**

- Project Start

### 10. Project Manager develops project management templates and tools for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Management Templates
- Project Management Tools

**Dependencies:**

- PMO Structure Chart

### 11. Project Manager defines project reporting requirements for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Reporting Requirements Document

**Dependencies:**

- Project Management Templates

### 12. Project Manager establishes communication protocols for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Communication Protocols Document

**Dependencies:**

- Project Reporting Requirements Document

### 13. Project Manager schedules and holds the initial PMO kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Communication Protocols Document

### 14. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.1

**Dependencies:**

- Project Start

### 15. Circulate Draft ECC ToR v0.1 for review by Department of Justice and Department of State (Human Rights Desk).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft ECC ToR v0.1

### 16. Project Manager incorporates feedback and finalizes the ECC ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final ECC ToR v1.0

**Dependencies:**

- Feedback Summary

### 17. Project Sponsor formally appoints Independent Legal Counsel as Chair of the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final ECC ToR v1.0

### 18. Project Sponsor formally appoints Independent Ethics Advisor to the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Appointment of ECC Chair

### 19. Project Manager coordinates with Department of Justice, Department of State (Human Rights Desk), and the Intelligence Community to confirm representatives and Data Protection Officer for the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Confirmed Membership List

**Dependencies:**

- Appointment of ECC Chair
- Appointment of Independent Ethics Advisor

### 20. Project Manager schedules and facilitates the initial kick-off meeting for the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Confirmed Membership List

### 21. Ethics & Compliance Committee (ECC) develops code of ethics.

**Responsible Body/Role:** Ethics & Compliance Committee (ECC)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Code of Ethics

**Dependencies:**

- Meeting Minutes with Action Items

### 22. Ethics & Compliance Committee (ECC) establishes reporting mechanisms for ethical concerns.

**Responsible Body/Role:** Ethics & Compliance Committee (ECC)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Reporting Mechanisms Document

**Dependencies:**

- Code of Ethics

### 23. Chief Technology Officer (CTO) drafts initial Terms of Reference (ToR) for the Technical Advisory Group (TAG).

**Responsible Body/Role:** Chief Technology Officer

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**

- Project Start

### 24. Circulate Draft TAG ToR v0.1 for review by Senior Engineer (DoD), Cybersecurity Expert (Intelligence Community), and Logistics Specialist (DoD).

**Responsible Body/Role:** Chief Technology Officer

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft TAG ToR v0.1

### 25. Chief Technology Officer incorporates feedback and finalizes the TAG ToR.

**Responsible Body/Role:** Chief Technology Officer

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final TAG ToR v1.0

**Dependencies:**

- Feedback Summary

### 26. Chief Technology Officer formally appointed as the Chair of the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final TAG ToR v1.0

### 27. Chief Technology Officer identifies and recruits technical experts (Infrastructure Expert, Communications Technology Expert) for the Technical Advisory Group (TAG).

**Responsible Body/Role:** Chief Technology Officer

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Recruitment Plan
- Candidate List

**Dependencies:**

- Appointment of TAG Chair

### 28. Project Sponsor formally appoints Senior Engineer (DoD), Cybersecurity Expert (Intelligence Community), Logistics Specialist (DoD), Infrastructure Expert, and Communications Technology Expert to the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Letters

**Dependencies:**

- Recruitment Plan
- Candidate List

### 29. Chief Technology Officer schedules and facilitates the initial kick-off meeting for the Technical Advisory Group (TAG).

**Responsible Body/Role:** Chief Technology Officer

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Letters

### 30. Communications Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Communications Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft SEG ToR v0.1

**Dependencies:**

- Project Start

### 31. Circulate Draft SEG ToR v0.1 for review by Public Affairs Officer (DoD) and Diplomatic Liaison (Department of State).

**Responsible Body/Role:** Communications Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SEG ToR v0.1

### 32. Communications Manager incorporates feedback and finalizes the SEG ToR.

**Responsible Body/Role:** Communications Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SEG ToR v1.0

**Dependencies:**

- Feedback Summary

### 33. Communications Manager formally appointed as the Chair of the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SEG ToR v1.0

### 34. Communications Manager identifies key stakeholders (Greenlandic Representative, NATO Liaison, Cultural Advisor) for the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Communications Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Stakeholder List

**Dependencies:**

- Appointment of SEG Chair

### 35. Project Sponsor formally appoints Public Affairs Officer (DoD), Diplomatic Liaison (Department of State), Cultural Advisor, Greenlandic Representative, and NATO Liaison to the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Letters

**Dependencies:**

- Stakeholder List

### 36. Communications Manager develops stakeholder engagement plan.

**Responsible Body/Role:** Communications Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Stakeholder Engagement Plan

**Dependencies:**

- Appointment Confirmation Letters

### 37. Communications Manager establishes communication protocols for the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Communications Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Communication Protocols Document

**Dependencies:**

- Stakeholder Engagement Plan

### 38. Communications Manager schedules and facilitates the initial kick-off meeting for the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Communications Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Communication Protocols Document