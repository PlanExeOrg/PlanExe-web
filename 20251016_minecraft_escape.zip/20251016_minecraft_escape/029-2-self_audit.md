Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 14 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 5 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The project is an escape room, which operates within the bounds of known physics.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of Minecraft + escape rooms in Shanghai without evidence at comparable scale. There is no mention of precedent for this specific combination. 

**Mitigation**: Run parallel validation tracks for Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Owner: Project Lead / Deliverable: Validation Report / Date: 2026-04-30


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a clear definition of the "Minecraft-themed" concept, its business-level mechanism-of-action, an owner, and measurable outcomes. The plan mentions "immersive experience" but lacks specifics.

**Mitigation**: Creative Director: Produce a one-pager defining the Minecraft-themed experience, including value hypotheses, success metrics, and decision hooks by 2026-04-30.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies risks (regulatory, financial, technical, operational, social, supply chain, security, brand licensing, partnership, market, environmental) but lacks explicit cascade analysis. "Impact: 2-6 month delay, lost revenue, increased expenses, fines (¥50,000-¥200,000)."

**Mitigation**: Risk & Compliance Officer: Map risk cascades (e.g., permit delay → missed peak season → revenue shortfall) and add controls with a dated review cadence by 2026-05-30.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions permits but lacks a comprehensive list with typical lead times. "Assumption: Business license, fire safety, entertainment, cultural affairs permit. Process: Applications, inspections, fees."

**Mitigation**: Risk & Compliance Officer: Create a permit/approval matrix with lead times from Shanghai authorities and a NO-GO threshold on slip by 2026-04-30.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because committed sources/term sheets do not cover the required runway. The plan mentions a budget of ~¥6M but lacks details on funding sources, draw schedule, covenants, and runway length.

**Mitigation**: CFO: Develop a dated financing plan listing sources/status, draw schedule, covenants, and a NO‑GO on missed financing gates by 2026-04-30.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget lacks vendor quotes or scale-appropriate benchmarks. There is no per-area math. The plan mentions a budget of ~¥6M but lacks detailed cost breakdowns.

**Mitigation**: CFO: Obtain ≥3 vendor quotes for construction, licensing, and marketing, normalize costs per m², and adjust the budget or de-scope by 2026-04-30.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., revenue, user adoption, completion dates) as a single number without providing a range, confidence interval, or discussing alternative scenarios. The plan lacks sensitivity analysis.

**Mitigation**: CFO: Conduct a sensitivity analysis on the most critical projection (e.g., revenue) with best/worst/base-case scenarios by 2026-04-30.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks engineering artifacts for build-critical components. There are no specs, interface contracts, acceptance tests, integration plan, or non-functional requirements mentioned.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components by 2026-05-30.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks evidence for critical claims regarding licenses and partnerships. The partnership with NetEase is crucial, but no formal agreement or terms are provided.

**Mitigation**: Partnership Liaison: Finalize the partnership agreement with NetEase, clearly defining revenue-sharing terms and marketing responsibilities by 2026-04-30.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the deliverable "a new system" is mentioned without specific, verifiable qualities. The plan mentions "Implement Booking and CRM Systems" but lacks specific acceptance criteria.

**Mitigation**: IT Manager: Define SMART criteria for the booking/CRM system, including a KPI for system uptime (e.g., 99.9% availability) by 2026-04-30.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes the feature of 'Room Design Complexity', which adds significant cost without demonstrably supporting core goals like profitability and throughput.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of Room Design Complexity, complete with a KPI, owner, and estimated cost, or move it to the backlog by 2026-04-30.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a 'Lead Room Designer' with expertise in both Minecraft and escape room design. This role is critical for creating an immersive experience, and talent is likely rare.

**Mitigation**: HR: Validate the talent market for a 'Lead Room Designer' with Minecraft and escape room experience by surveying potential candidates by 2026-04-30.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because legality is unclear and required approvals are unmapped. The plan mentions permits (Business License, Fire Safety Permit, Entertainment Permit, Cultural Affairs Permit) but lacks a regulatory matrix.

**Mitigation**: Risk & Compliance Officer: Create a regulatory matrix (authority, artifact, lead time, predecessors) and a **NO‑GO** on adverse findings by 2026-04-30.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions operational costs and revenue but lacks a detailed sustainability plan. There is no discussion of long-term maintenance, technology obsolescence, or environmental impact. "The plan aims to establish a commercially viable Minecraft-themed escape room business in Shanghai..."

**Mitigation**: Operations Manager: Develop an operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms by 2026-05-30.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions zoning and permits but lacks specifics. It states, "Requires a physical location in Shanghai" but doesn't address zoning restrictions or specific permit requirements.

**Mitigation**: Risk & Compliance Officer: Conduct a fatal-flaw screen with Shanghai authorities to confirm zoning and permit feasibility by 2026-04-30.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions vendors but lacks details on SLAs, failover, or secondary suppliers. The plan mentions "Disruptions in supply chain for materials/props. Overseas suppliers." but lacks mitigation for single points of failure.

**Mitigation**: Supply Chain Manager: Secure SLAs with key vendors, identify a secondary supplier for critical materials, and test failover procedures by 2026-05-30.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the stated goals of the Marketing Team (maximize bookings) and the Operations Team (minimize costs) are in conflict. The plan states, "Develop and execute marketing campaigns to attract the target demographic..." and "Oversee the day-to-day operations of the escape room business..."

**Mitigation**: Project Lead: Define a shared OKR for Marketing and Operations focused on 'Achieving X% occupancy at Y average ticket price' by 2026-04-30.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Lead: Establish a monthly project review with a KPI dashboard and a lightweight change board with escalation thresholds by 2026-04-30.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies three critical risks (Regulatory & Permitting, Financial, Brand Licensing) but lacks a cross-impact analysis. A delay in permits could trigger financial strain and brand licensing issues. 

**Mitigation**: Risk & Compliance Officer: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by 2026-05-30.