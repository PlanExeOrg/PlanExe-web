
## Audit - Corruption Risks

- Bribery of local officials to expedite permits and licenses.
- Kickbacks from construction companies or suppliers in exchange for contracts.
- Conflicts of interest if staff members have undisclosed financial ties to vendors.
- Misuse of inside information regarding competitor strategies or pricing.
- Trading favors with NetEase employees for preferential treatment in partnership negotiations.

## Audit - Misallocation Risks

- Inflated invoices from suppliers or contractors.
- Use of project funds for personal expenses disguised as business travel or entertainment.
- Double-billing for services rendered.
- Inefficient allocation of marketing budget, with funds directed to ineffective channels.
- Misreporting of project progress to mask delays or cost overruns.

## Audit - Procedures

- Conduct quarterly internal audits of financial records, focusing on vendor payments and expense reports.
- Implement a multi-level approval workflow for all invoices exceeding ¥50,000.
- Perform background checks on key personnel involved in procurement and contract management.
- Conduct surprise audits of inventory and cash on hand.
- Engage an external auditor to review project financials and compliance with licensing agreements upon project completion.

## Audit - Transparency Measures

- Establish a project dashboard accessible to key stakeholders, displaying budget vs. actual spending and progress against milestones.
- Publish minutes of key project meetings (e.g., steering committee meetings) on a shared internal platform.
- Implement a whistleblower mechanism for reporting suspected fraud or misconduct.
- Document and publish the selection criteria for all major vendors and contractors.
- Make the Minecraft brand license agreement and related compliance reports available for internal review.