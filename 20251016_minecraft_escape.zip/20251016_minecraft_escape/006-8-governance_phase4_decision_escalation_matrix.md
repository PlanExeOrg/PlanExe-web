**Budget Request Exceeding Core Project Team Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the Core Project Team's delegated financial authority (above ¥200,000) and requires strategic review.
Negative Consequences: Potential budget overrun, project delays, reduced scope.

**Critical Risk Materialization Requiring Additional Resources**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval
Rationale: Materialization of a critical risk (e.g., regulatory delay, brand license violation) demands immediate attention and potentially significant resource reallocation.
Negative Consequences: Project failure, legal penalties, reputational damage.

**Technical Advisory Group Deadlock on Key Design Decision**
Escalation Level: Project Steering Committee
Approval Process: Project Steering Committee Review and Decision
Rationale: Inability of the Technical Advisory Group to reach consensus on a critical technical design element necessitates higher-level arbitration to avoid project delays.
Negative Consequences: Compromised design integrity, increased costs, project delays.

**Proposed Major Scope Change Impacting Project Timeline or Budget**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval
Rationale: Significant changes to the project scope (e.g., adding a new escape room, altering the target demographic) require strategic reassessment and approval.
Negative Consequences: Project delays, budget overruns, misalignment with strategic objectives.

**Reported Ethical Concern or Compliance Violation**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Senior Management
Rationale: Allegations of ethical misconduct or non-compliance (e.g., data privacy breach, violation of brand license) necessitate independent investigation and corrective action.
Negative Consequences: Legal penalties, reputational damage, termination of brand license.

**Disagreement between Core Project Team and Technical Advisory Group that cannot be resolved**
Escalation Level: Project Steering Committee
Approval Process: Project Steering Committee Review and Decision
Rationale: When the Core Project Team and Technical Advisory Group cannot agree on a technical issue, the Project Steering Committee must make the final decision to keep the project moving forward.
Negative Consequences: Project delays, increased costs, compromised design integrity.