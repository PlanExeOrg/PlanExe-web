### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Core Team ToR v0.1

**Dependencies:**

- Project Plan Approved

### 3. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**

- Project Plan Approved

### 4. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.1

**Dependencies:**

- Project Plan Approved

### 5. Circulate Draft SteerCo ToR for review by Senior Management Representative, Finance Director, Marketing Director, and Operations Director.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1

### 6. Circulate Draft Core Team ToR for review by Construction Manager, Marketing Manager, Operations Manager, and Technical Lead.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Core Team ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft Core Team ToR v0.1

### 7. Circulate Draft TAG ToR for review by Electrical Engineer, Mechanical Engineer, Software Developer, Escape Room Design Consultant, and Safety Inspector.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft TAG ToR v0.1

### 8. Circulate Draft ECC ToR for review by Legal Counsel, Compliance Officer, Data Protection Officer, Representative from Microsoft/Mojang, and Internal Audit Representative.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft ECC ToR v0.1

### 9. Project Manager finalizes the Project Steering Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft SteerCo ToR v0.2

### 10. Project Manager finalizes the Core Project Team Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Core Team ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Core Team ToR v0.2

### 11. Project Manager finalizes the Technical Advisory Group Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final TAG ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft TAG ToR v0.2

### 12. Project Manager finalizes the Ethics & Compliance Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final ECC ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft ECC ToR v0.2

### 13. Senior Management formally appoints the Chair of the Project Steering Committee.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 14. Project Manager formally appoints members of the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final Core Team ToR v1.0

### 15. Project Manager formally appoints members of the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final TAG ToR v1.0

### 16. Senior Management formally appoints members of the Ethics & Compliance Committee.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final ECC ToR v1.0

### 17. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Appointment Confirmation Email
- Final SteerCo ToR v1.0

### 18. Project Manager schedules the initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Appointment Confirmation Emails
- Final Core Team ToR v1.0

### 19. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Appointment Confirmation Emails
- Final TAG ToR v1.0

### 20. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Appointment Confirmation Emails
- Final ECC ToR v1.0

### 21. Hold initial Project Steering Committee kick-off meeting. Review ToR, project goals, and initial priorities.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Final SteerCo ToR v1.0

### 22. Hold initial Core Project Team kick-off meeting. Review ToR, project goals, and initial tasks.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Final Core Team ToR v1.0

### 23. Hold initial Technical Advisory Group kick-off meeting. Review ToR, project goals, and technical requirements.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Final TAG ToR v1.0

### 24. Hold initial Ethics & Compliance Committee kick-off meeting. Review ToR, project goals, and compliance requirements.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Final ECC ToR v1.0

### 25. Core Project Team begins weekly meetings to manage day-to-day project execution.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Weekly Meeting Minutes
- Updated Project Schedule

**Dependencies:**

- Meeting Minutes with Action Items from Core Project Team Kick-off

### 26. Technical Advisory Group begins bi-weekly meetings to provide technical expertise and guidance.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Bi-weekly Meeting Minutes
- Technical Recommendations

**Dependencies:**

- Meeting Minutes with Action Items from Technical Advisory Group Kick-off

### 27. Project Steering Committee holds monthly meetings to provide strategic oversight and guidance.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Month 2

**Key Outputs/Deliverables:**

- Monthly Meeting Minutes
- Strategic Decisions

**Dependencies:**

- Meeting Minutes with Action Items from Project Steering Committee Kick-off

### 28. Ethics & Compliance Committee holds quarterly meetings to ensure compliance with regulations and ethical standards.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Quarter 3

**Key Outputs/Deliverables:**

- Quarterly Meeting Minutes
- Compliance Reports

**Dependencies:**

- Meeting Minutes with Action Items from Ethics & Compliance Committee Kick-off