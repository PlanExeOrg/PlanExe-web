### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and guidance for the project, ensuring alignment with overall business objectives and managing strategic risks. Given the ¥6M budget and brand licensing agreement, high-level oversight is crucial.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic direction and guidance.
- Monitor project progress against key milestones.
- Approve major changes to project scope, budget, or timeline (above ¥200,000).
- Oversee strategic risk management and mitigation.
- Resolve high-level conflicts and escalate issues as needed.

**Initial Setup Actions:**

- Define Terms of Reference and operating procedures.
- Appoint a chairperson.
- Establish a communication plan.
- Review and approve the initial project plan.

**Membership:**

- Senior Management Representative (Chair)
- Finance Director
- Marketing Director
- Operations Director
- Project Manager

**Decision Rights:** Strategic decisions related to project scope, budget (above ¥200,000), timeline, and strategic risks. Approval of major changes to the project plan.

**Decision Mechanism:** Decisions are made by majority vote. In the event of a tie, the Senior Management Representative (Chair) has the deciding vote.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of project progress against milestones.
- Discussion of key risks and issues.
- Approval of budget changes or scope modifications (above ¥200,000).
- Review of stakeholder engagement activities.
- Update from the Project Manager.

**Escalation Path:** Senior Management (CEO/Executive Team)
### 2. Core Project Team

**Rationale for Inclusion:** Manages the day-to-day execution of the project, ensuring tasks are completed on time and within budget. Essential for operational efficiency and effective communication.

**Responsibilities:**

- Develop and maintain the project schedule.
- Manage project resources and budget (below ¥200,000).
- Coordinate project activities and tasks.
- Monitor project risks and issues.
- Report project progress to the Project Steering Committee.
- Implement the project plan.

**Initial Setup Actions:**

- Define roles and responsibilities.
- Establish communication protocols.
- Set up project management tools and systems.
- Develop a detailed project schedule.

**Membership:**

- Project Manager (Lead)
- Construction Manager
- Marketing Manager
- Operations Manager
- Technical Lead

**Decision Rights:** Operational decisions related to day-to-day project execution, resource allocation (below ¥200,000), and task management.

**Decision Mechanism:** Decisions are made by the Project Manager in consultation with the relevant team members. Unresolved issues are escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of progress against the project schedule.
- Discussion of current risks and issues.
- Allocation of resources to tasks.
- Coordination of project activities.
- Update on stakeholder engagement.

**Escalation Path:** Project Steering Committee
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and guidance on the design, construction, and operation of the escape rooms. Ensures technical feasibility and compliance with safety standards.

**Responsibilities:**

- Review and approve technical designs and specifications.
- Provide guidance on the selection of materials and equipment.
- Ensure compliance with building codes and safety standards.
- Troubleshoot technical issues and provide solutions.
- Advise on the integration of technology into the escape rooms.
- Ensure the puzzles are solvable and fun.

**Initial Setup Actions:**

- Define scope of technical expertise required.
- Identify and recruit qualified technical experts.
- Establish communication channels with the Core Project Team.
- Review project plans and specifications.

**Membership:**

- Electrical Engineer
- Mechanical Engineer
- Software Developer
- Escape Room Design Consultant
- Safety Inspector (Independent/External)

**Decision Rights:** Technical decisions related to the design, construction, and operation of the escape rooms. Approval of technical specifications and safety standards.

**Decision Mechanism:** Decisions are made by consensus among the technical experts. In the event of a disagreement, the Project Manager makes the final decision, considering the advice of the Technical Advisory Group.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of technical designs and specifications.
- Discussion of technical issues and solutions.
- Assessment of compliance with building codes and safety standards.
- Update on the integration of technology into the escape rooms.
- Review of puzzle designs and gameplay.

**Escalation Path:** Project Steering Committee
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures compliance with all relevant regulations, ethical standards, and the Minecraft brand license agreement. Given the brand license and potential partnership with NetEase, dedicated compliance oversight is essential.

**Responsibilities:**

- Oversee compliance with all relevant regulations, including data privacy (GDPR), fire safety, and building codes.
- Ensure adherence to ethical standards in all project activities.
- Monitor compliance with the Minecraft brand license agreement.
- Develop and implement a data privacy and security policy.
- Investigate and resolve any compliance violations.
- Ensure cultural sensitivity.

**Initial Setup Actions:**

- Define scope of compliance requirements.
- Identify and recruit qualified compliance experts.
- Establish communication channels with the Core Project Team.
- Review project plans and agreements.

**Membership:**

- Legal Counsel (Independent/External)
- Compliance Officer
- Data Protection Officer
- Representative from Microsoft/Mojang (Brand Licensor)
- Internal Audit Representative

**Decision Rights:** Decisions related to compliance with regulations, ethical standards, and the Minecraft brand license agreement. Approval of compliance policies and procedures.

**Decision Mechanism:** Decisions are made by majority vote. In the event of a tie, the Legal Counsel has the deciding vote.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of compliance with regulations and ethical standards.
- Discussion of data privacy and security issues.
- Assessment of compliance with the Minecraft brand license agreement.
- Update on compliance training activities.
- Review of any compliance violations.

**Escalation Path:** Senior Management (CEO/Executive Team)