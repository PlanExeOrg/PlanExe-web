This plan involves money.

## Currencies

- **CNY:** Local currency for expenses, salaries, rent, and ticket sales in Shanghai.

**Primary currency:** CNY

**Currency strategy:** The local currency will be used for all transactions with no additional international risk management needed.