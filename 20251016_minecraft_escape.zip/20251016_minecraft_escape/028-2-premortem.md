A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The target demographic (15-21 year olds) in Shanghai has sufficient disposable income to support the projected ticket prices. | Conduct a survey within Shanghai high schools and universities to gauge willingness to pay for the escape room experience at various price points. | Survey results indicate that less than 50% of the target demographic is willing to pay the projected average ticket price of ¥200. |
| A2 | Durable, easily replaceable props can be sourced locally at a cost that does not significantly impact the budget. | Obtain quotes from at least three local suppliers for the key props and materials needed for one escape room, ensuring they meet durability and aesthetic requirements. | The average cost of sourcing durable, easily replaceable props locally exceeds 15% of the allocated budget for props and materials. |
| A3 | The Minecraft theme will resonate strongly with the target demographic in Shanghai, leading to high initial demand and positive word-of-mouth. | Organize focus groups with the target demographic in Shanghai to gauge their interest in a Minecraft-themed escape room and gather feedback on proposed themes and puzzle mechanics. | Focus group participants express limited interest in a Minecraft-themed escape room or provide negative feedback on the proposed themes and puzzle mechanics. |
| A4 | The local Shanghai labor market will provide a sufficient pool of qualified and affordable staff (game masters, reset crew, front desk). | Contact local staffing agencies and post job advertisements to gauge the availability and wage expectations of potential employees. | Staffing agencies report a shortage of qualified candidates or wage expectations exceed the budgeted labor costs by more than 10%. |
| A5 | The chosen location will not require significant unforeseen renovations beyond the initial construction budget. | Conduct a thorough inspection of the chosen location with a qualified contractor to identify any potential structural or code-related issues. | The contractor identifies necessary renovations that exceed 10% of the initial construction budget. |
| A6 | The booking and CRM systems will integrate seamlessly and function reliably with minimal technical issues. | Conduct thorough testing of the integrated booking and CRM systems with simulated user data and high traffic loads. | The integrated systems experience frequent errors, slow response times, or data synchronization issues that disrupt the booking process or customer management. |
| A7 | The local Shanghai community will embrace the escape room and not perceive it as a nuisance (noise, traffic, parking). | Conduct a survey of residents and businesses within a 500-meter radius of the chosen location to gauge their attitudes towards the proposed escape room. | Survey results indicate that more than 25% of local residents or businesses perceive the escape room as a potential nuisance. |
| A8 | The cost of electricity and water will remain stable and within the projected budget. | Obtain historical utility bills for similar commercial spaces in the chosen location and project future costs based on anticipated usage and current utility rates. | Projected utility costs exceed the budgeted amount by more than 10%. |
| A9 | The escape room design will be adaptable to changing customer preferences and market trends without requiring major renovations. | Develop a modular design concept that allows for easy swapping of puzzle elements and thematic components without significant structural changes. | Implementing a minor theme change or puzzle update requires more than 5 days of downtime or exceeds 5% of the initial construction budget. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Empty Pockets Paradox | Process/Financial | A1 | CFO | CRITICAL (20/25) |
| FM2 | The Crumbling Kingdom Catastrophe | Technical/Logistical | A2 | Head of Engineering | HIGH (12/25) |
| FM3 | The Minecraft Mirage Meltdown | Market/Human | A3 | Marketing Lead | HIGH (10/25) |
| FM4 | The Staffing Shortfall Scrimmage | Process/Financial | A4 | Operations Manager | CRITICAL (20/25) |
| FM5 | The Renovation Ruin | Technical/Logistical | A5 | Construction Supervisor | HIGH (12/25) |
| FM6 | The System Shutdown Scare | Market/Human | A6 | IT Manager | HIGH (10/25) |
| FM7 | The Neighborhood Nightmare | Market/Human | A7 | Community Engagement Specialist | CRITICAL (15/25) |
| FM8 | The Utility Bill Black Hole | Process/Financial | A8 | Operations Manager | MEDIUM (8/25) |
| FM9 | The Rigidity Ruin | Technical/Logistical | A9 | Lead Room Designer | CRITICAL (20/25) |


### Failure Modes

#### FM1 - The Empty Pockets Paradox

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: CFO
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The core assumption that the target demographic possesses sufficient disposable income proves false. Ticket sales plummet as the projected price point is unaffordable for the majority of the intended audience. This leads to a cascade of financial problems:

*   Low occupancy rates result in significantly reduced revenue.
*   Inability to cover fixed costs (rent, utilities, salaries).
*   Depletion of contingency funds to sustain operations.
*   Inability to invest in marketing or improvements.
*   Eventual closure due to insolvency.

##### Early Warning Signs
- Initial booking rates are 30% lower than projected for the first month.
- Customer feedback indicates that ticket prices are too high.
- Website traffic from the target demographic is low compared to other age groups.

##### Tripwires
- Average occupancy rate is <= 40% after the first 3 months.
- Customer satisfaction scores related to value for money are <= 3 out of 5.
- Monthly revenue is <= ¥500,000 for two consecutive months.

##### Response Playbook
- Contain: Immediately implement a promotional campaign offering discounted tickets and bundled packages.
- Assess: Conduct a thorough review of pricing strategy and target demographic's financial capacity.
- Respond: Adjust pricing strategy to align with the target demographic's affordability, potentially offering tiered pricing or value-added options.


**STOP RULE:** After 6 months, the project fails to achieve a positive cash flow and requires additional funding exceeding 20% of the initial budget.

---

#### FM2 - The Crumbling Kingdom Catastrophe

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Engineering
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The assumption that durable, easily replaceable props can be sourced locally at a reasonable cost proves incorrect. The escape rooms are initially built with cheaper, less durable materials to stay within budget. This leads to a series of technical and logistical nightmares:

*   Props break frequently, leading to downtime and customer dissatisfaction.
*   Reset times increase as staff struggle to repair or replace broken items.
*   Maintenance costs skyrocket, exceeding the allocated budget.
*   The immersive experience is compromised as the rooms appear worn and poorly maintained.
*   Supply chain disruptions occur as sourcing durable replacements becomes difficult and expensive.

##### Early Warning Signs
- Prop breakage rate exceeds 10% per week.
- Reset times increase by an average of 5 minutes per session.
- Maintenance costs exceed ¥10,000 per month.

##### Tripwires
- Prop breakage rate >= 15% per week for 2 consecutive weeks.
- Average reset time >= 25 minutes.
- Maintenance costs exceed 12% of monthly revenue.

##### Response Playbook
- Contain: Immediately implement a temporary repair program to fix broken props and minimize downtime.
- Assess: Conduct a thorough assessment of prop durability and identify alternative sourcing options.
- Respond: Invest in higher-quality, more durable props and materials, even if it requires adjusting the budget or seeking additional funding.


**STOP RULE:** The cost of replacing or repairing props exceeds 30% of the initial construction budget within the first year of operation.

---

#### FM3 - The Minecraft Mirage Meltdown

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Marketing Lead
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The assumption that the Minecraft theme will resonate strongly with the target demographic in Shanghai proves false. The escape room opens to lukewarm reception, failing to attract the expected crowds. This leads to a downward spiral:

*   Initial bookings are significantly lower than projected.
*   Word-of-mouth is negative as players find the theme uninspired or poorly executed.
*   Marketing efforts fail to generate sufficient buzz or interest.
*   The escape room struggles to differentiate itself from competitors.
*   The business faces closure due to lack of demand.

##### Early Warning Signs
- Social media engagement is low compared to competitor benchmarks.
- Customer reviews indicate that the Minecraft theme is not well-integrated or engaging.
- Website conversion rates are below 2%.

##### Tripwires
- Average customer rating for thematic integration is <= 3.5 out of 5 stars.
- Social media shares of promotional content are <= 50 per week.
- Website conversion rate (bookings/visits) is <= 1.5%.

##### Response Playbook
- Contain: Immediately launch a targeted marketing campaign emphasizing the unique aspects of the escape room experience.
- Assess: Conduct a thorough review of customer feedback and market research to identify the root cause of the lack of interest.
- Respond: Pivot the theme or puzzle design to better align with the target demographic's preferences, potentially incorporating other popular games or entertainment properties.


**STOP RULE:** After 9 months, the escape room fails to achieve an average occupancy rate of 50% despite significant marketing efforts and theme adjustments.

---

#### FM4 - The Staffing Shortfall Scrimmage

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Operations Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The assumption of an ample, affordable local labor pool proves false. The escape room struggles to find qualified staff willing to work for the offered wages. This triggers a chain of operational and financial setbacks:

*   Understaffing leads to longer wait times and reduced throughput.
*   Existing staff are overworked, resulting in burnout and decreased customer service quality.
*   Emergency hires are made at higher wages, exceeding the labor budget.
*   Training is rushed, leading to errors and safety concerns.
*   The business suffers from negative reviews and reduced repeat bookings.

##### Early Warning Signs
- Application rates are 50% lower than projected.
- Employee turnover rate exceeds 10% per month.
- Customer complaints related to staff performance increase by 20%.

##### Tripwires
- Staff turnover rate >= 15% per month for 2 consecutive months.
- Average customer rating for staff performance is <= 3.5 out of 5 stars.
- Number of unfilled staff positions remains >= 3 for more than 4 weeks.

##### Response Playbook
- Contain: Immediately offer overtime pay to existing staff and implement a referral bonus program to attract new applicants.
- Assess: Conduct a thorough review of compensation and benefits packages compared to competitor offerings.
- Respond: Increase wages and benefits to attract and retain qualified staff, potentially adjusting pricing or seeking additional funding to cover the increased labor costs.


**STOP RULE:** The business is unable to maintain adequate staffing levels for more than 3 consecutive months, resulting in a significant decline in customer satisfaction and revenue.

---

#### FM5 - The Renovation Ruin

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Construction Supervisor
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The assumption that the chosen location requires minimal unforeseen renovations proves incorrect. After signing the lease, significant structural or code-related issues are discovered. This leads to a cascade of technical and logistical problems:

*   Renovation costs skyrocket, exceeding the allocated budget.
*   Construction is delayed as unexpected repairs are required.
*   The escape room design must be modified to accommodate the location's limitations.
*   The opening date is pushed back, resulting in lost revenue and marketing momentum.
*   The business struggles to recover from the financial setback and operational delays.

##### Early Warning Signs
- Contractor identifies unforeseen structural issues during the initial site inspection.
- Permitting process is delayed due to code violations.
- Renovation costs exceed the initial budget estimate by 15%.

##### Tripwires
- Renovation costs exceed the initial budget by >= 20%.
- Construction is delayed by >= 6 weeks.
- The opening date is pushed back by >= 2 months.

##### Response Playbook
- Contain: Immediately halt all non-essential renovations and negotiate with the landlord to share the cost of necessary repairs.
- Assess: Conduct a thorough review of the renovation plan and identify cost-saving measures.
- Respond: Seek additional funding to cover the increased renovation costs, potentially adjusting the budget or seeking a loan. If costs are prohibitive, consider terminating the lease and finding a more suitable location.


**STOP RULE:** The cost of necessary renovations exceeds 40% of the initial construction budget, making the project financially unviable.

---

#### FM6 - The System Shutdown Scare

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: IT Manager
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The assumption that the booking and CRM systems will integrate seamlessly and function reliably proves false. The integrated systems experience frequent technical issues, disrupting the booking process and customer management. This leads to a loss of customers and a damaged reputation:

*   Customers are unable to book rooms online, leading to lost revenue.
*   Staff struggle to manage bookings and customer data manually.
*   Customer service is compromised due to inaccurate or incomplete information.
*   The business suffers from negative reviews and reduced repeat bookings.
*   The lack of reliable data hinders marketing efforts and operational improvements.

##### Early Warning Signs
- Customers report frequent errors or slow response times when booking online.
- Staff spend excessive time troubleshooting system issues.
- Customer data is frequently lost or corrupted.

##### Tripwires
- Online booking conversion rate drops below 1%.
- Customer complaints related to booking issues exceed 10% of all complaints.
- System downtime exceeds 5 hours per week.

##### Response Playbook
- Contain: Immediately implement a manual booking process and provide additional training to staff on troubleshooting system issues.
- Assess: Conduct a thorough review of the system integration and identify the root cause of the technical problems.
- Respond: Work with the system vendors to resolve the technical issues, potentially switching to a more reliable system or developing a custom solution. If the system is irreparable, revert to a manual system and seek compensation from the vendor.


**STOP RULE:** The booking and CRM systems remain unreliable for more than 2 months, resulting in a significant loss of revenue and customer dissatisfaction.

---

#### FM7 - The Neighborhood Nightmare

- **Archetype**: Market/Human
- **Root Cause**: Assumption A7
- **Owner**: Community Engagement Specialist
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The assumption that the local Shanghai community will embrace the escape room proves false. Residents and businesses perceive the escape room as a nuisance, leading to community backlash and operational challenges:

*   Noise complaints disrupt operations and lead to fines.
*   Increased traffic and parking congestion anger local residents.
*   Negative publicity damages the escape room's reputation.
*   Local businesses refuse to partner or promote the escape room.
*   The business faces closure due to community opposition and regulatory pressure.

##### Early Warning Signs
- Local residents file noise complaints with the authorities.
- Local businesses express concerns about increased traffic and parking congestion.
- Negative comments about the escape room appear on local online forums.

##### Tripwires
- Number of noise complaints exceeds 5 per month.
- Local businesses withdraw from partnership agreements.
- Negative sentiment score on local online forums is <= 2 out of 5.

##### Response Playbook
- Contain: Immediately implement noise reduction measures and work with local authorities to address traffic and parking concerns.
- Assess: Conduct a community outreach program to understand the root cause of the opposition and identify potential solutions.
- Respond: Modify operations to minimize the impact on the community, potentially adjusting operating hours, offering discounts to local residents, or investing in community improvement projects.


**STOP RULE:** The business is unable to resolve community opposition within 6 months, resulting in ongoing operational disruptions and a significant decline in customer satisfaction.

---

#### FM8 - The Utility Bill Black Hole

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A8
- **Owner**: Operations Manager
- **Risk Level:** MEDIUM 8/25 (Likelihood 2/5 × Impact 4/5)

##### Failure Story
The assumption that the cost of electricity and water will remain stable proves false. Utility costs unexpectedly surge, exceeding the projected budget and impacting profitability:

*   High energy consumption from lighting, air conditioning, and electronic puzzles drives up electricity bills.
*   Water usage for restrooms and cleaning exceeds expectations, leading to higher water bills.
*   The business struggles to cover the increased utility costs, impacting other operational areas.
*   Profit margins shrink, making it difficult to achieve a positive ROI.
*   The business faces closure due to unsustainable operating expenses.

##### Early Warning Signs
- Monthly utility bills exceed the budgeted amount by 15%.
- Energy consumption is higher than projected based on usage data.
- Water leaks or inefficiencies are detected in the plumbing system.

##### Tripwires
- Monthly electricity bill exceeds ¥20,000 for 2 consecutive months.
- Monthly water bill exceeds ¥5,000 for 2 consecutive months.
- Total utility costs exceed 10% of monthly revenue.

##### Response Playbook
- Contain: Immediately implement energy and water conservation measures, such as installing energy-efficient lighting and fixing leaks.
- Assess: Conduct an energy audit to identify areas of high consumption and potential inefficiencies.
- Respond: Invest in energy-efficient equipment and water-saving fixtures, potentially adjusting pricing or seeking additional funding to cover the upfront costs. Negotiate with utility providers for better rates or payment plans.


**STOP RULE:** The business is unable to reduce utility costs to within 10% of the budgeted amount within 6 months, resulting in unsustainable operating expenses.

---

#### FM9 - The Rigidity Ruin

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A9
- **Owner**: Lead Room Designer
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The assumption that the escape room design will be adaptable to changing customer preferences proves false. The initial design is too rigid and difficult to modify, hindering the business's ability to adapt to evolving market trends:

*   Customer preferences shift, rendering the existing themes and puzzles outdated.
*   Competitors introduce new and innovative escape room concepts.
*   The business struggles to attract new customers and retain existing ones.
*   Major renovations are required to update the escape room design, incurring significant costs and downtime.
*   The business faces closure due to its inability to remain competitive and relevant.

##### Early Warning Signs
- Customer feedback indicates that the escape room themes and puzzles are becoming stale.
- Competitors launch new escape rooms with more innovative designs.
- Booking rates decline despite ongoing marketing efforts.

##### Tripwires
- Customer satisfaction scores for theme and puzzle design are <= 3.5 out of 5 stars.
- Booking rates decline by >= 20% compared to the previous quarter.
- Cost of implementing a minor theme change exceeds 7% of the initial construction budget.

##### Response Playbook
- Contain: Immediately implement minor updates and improvements to the existing themes and puzzles to address customer feedback.
- Assess: Conduct market research to identify emerging trends and customer preferences in the escape room market.
- Respond: Develop a modular design concept that allows for easy swapping of puzzle elements and thematic components without significant structural changes. Allocate a budget for regular updates and improvements to keep the escape room fresh and engaging.


**STOP RULE:** The business is unable to adapt to changing customer preferences and market trends, resulting in a sustained decline in booking rates and a loss of market share.
