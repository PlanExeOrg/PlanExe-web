## Positive Constraints

- Minecraft themed escape-room
- Must know Minecraft rules to escape
- Location: Shanghai
- Target age range 15-21
- Ticket price: ¥188–¥238
- Session duration: 60–90 min
- 4 rooms
- Footprint: ~280–350 m²
- Budget: ~¥6M
- Low risk scenario
- Realistic scenario
- Pilot project
- Keep it practical
- Project start ASAP

## Negative Constraints

- Avoid aggressive scenarios
- Do not use AR
- Do not use VR
- Do not use NFT
- Do not use blockchain
