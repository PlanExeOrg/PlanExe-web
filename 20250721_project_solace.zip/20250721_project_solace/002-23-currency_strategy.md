This plan involves money.

## Currencies

- **USD:** The project budget is defined in USD, and it is an international project.
- **CHF:** Switzerland (Geneva) is a key location for international governance discussions.
- **AUD:** Australia (Canberra) is a key location for research and development.

**Primary currency:** USD

**Currency strategy:** USD will be used for consolidated budgeting and reporting. CHF and AUD may be used for local transactions in Switzerland and Australia, respectively. Currency exchange rates should be monitored and hedging strategies considered to mitigate risks from exchange rate fluctuations.