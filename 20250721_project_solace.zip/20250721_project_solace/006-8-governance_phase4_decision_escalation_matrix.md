**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority and requires strategic oversight.
Negative Consequences: Potential budget overruns, project delays, or scope reductions.

**Critical Technical Risk Materialization**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Approval of Revised Mitigation Strategy
Rationale: Represents a significant threat to project success and requires high-level strategic decision-making.
Negative Consequences: Project failure, significant delays, or inability to meet project goals.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: Inability to reach consensus within the PMO necessitates a higher-level decision to avoid project delays.
Negative Consequences: Project delays, increased costs, or selection of a suboptimal vendor.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Approval Based on Impact Assessment
Rationale: Significantly alters the project's objectives and requires strategic alignment and budget adjustments.
Negative Consequences: Project delays, budget overruns, failure to meet original objectives, or stakeholder dissatisfaction.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee (ECC)
Approval Process: Ethics Committee Investigation and Recommendation to Project Steering Committee
Rationale: Requires independent review and assessment to ensure ethical conduct and compliance with regulations.
Negative Consequences: Legal penalties, reputational damage, loss of public trust, or project halt.

**Technical Advisory Group (TAG) identifies a critical technical risk that could jeopardize the project's success.**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Approval of Mitigation Strategy
Rationale: Critical technical risks require high-level strategic decision-making.
Negative Consequences: Project failure, significant delays, or inability to meet project goals.

**Stakeholder Engagement Group (SEG) identifies stakeholder engagement issues that cannot be resolved by the SEG.**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Approval of Revised Engagement Strategy
Rationale: Stakeholder engagement issues require high-level strategic decision-making.
Negative Consequences: Project delays, budget overruns, failure to meet original objectives, or stakeholder dissatisfaction.