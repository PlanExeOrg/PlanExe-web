### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1

**Dependencies:**

- Project Plan Approved
- Project Sponsor Identified

### 2. Project Manager circulates Draft PSC ToR v0.1 for review by Senior Management and Legal Counsel.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Circulation List
- Review Comments

**Dependencies:**

- Draft PSC ToR v0.1

### 3. Project Manager incorporates feedback and finalizes the Project Steering Committee's Terms of Reference (ToR).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final PSC ToR v1.0

**Dependencies:**

- Review Comments Received
- Circulation List

### 4. Senior Management formally appoints the Chair of the Project Steering Committee (PSC).

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email
- Public Announcement

**Dependencies:**

- Final PSC ToR v1.0

### 5. Project Manager, in consultation with the PSC Chair, identifies and invites nominated members from each G20 nation, plus independent experts, to join the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Nominated Members List
- Invitation Letters

**Dependencies:**

- Appointment Confirmation Email
- Final PSC ToR v1.0

### 6. Project Manager receives confirmation of membership from nominated members of the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Confirmed Members List

**Dependencies:**

- Invitation Letters Sent

### 7. Project Manager schedules and facilitates the initial kick-off meeting for the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda
- Meeting Minutes with Action Items

**Dependencies:**

- Confirmed Members List
- PSC Chair Appointed

### 8. Project Steering Committee (PSC) approves the initial risk register and mitigation strategies.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Approved Risk Register v1.0
- Mitigation Strategies Document

**Dependencies:**

- Meeting Minutes with Action Items

### 9. Chief Project Officer (CPO) establishes the PMO structure and staffing.

**Responsible Body/Role:** Chief Project Officer (CPO)

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- PMO Structure Chart
- Staffing Plan

**Dependencies:**

- Project Plan Approved

### 10. Chief Project Officer (CPO) develops project management templates and tools for the Project Management Office (PMO).

**Responsible Body/Role:** Chief Project Officer (CPO)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Management Templates
- Project Management Tools

**Dependencies:**

- PMO Structure Chart

### 11. Chief Project Officer (CPO) defines project reporting requirements and frequency for the Project Management Office (PMO).

**Responsible Body/Role:** Chief Project Officer (CPO)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Project Reporting Requirements Document

**Dependencies:**

- Project Management Templates

### 12. Chief Project Officer (CPO) establishes communication protocols and channels for the Project Management Office (PMO).

**Responsible Body/Role:** Chief Project Officer (CPO)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Communication Protocols Document

**Dependencies:**

- Project Reporting Requirements Document

### 13. Chief Project Officer (CPO) develops a risk management framework for the Project Management Office (PMO).

**Responsible Body/Role:** Chief Project Officer (CPO)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Risk Management Framework Document

**Dependencies:**

- Communication Protocols Document

### 14. Project Manager schedules and facilitates the initial kick-off meeting for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda
- Meeting Minutes with Action Items

**Dependencies:**

- Risk Management Framework Document
- PMO Structure Chart

### 15. Project Management Office (PMO) develops and maintains the project management plan.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Project Management Plan v1.0

**Dependencies:**

- Meeting Minutes with Action Items

### 16. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**

- Project Management Plan v1.0

### 17. Project Manager circulates Draft TAG ToR v0.1 for review by Chief Technology Officer (CTO) and Legal Counsel.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Circulation List
- Review Comments

**Dependencies:**

- Draft TAG ToR v0.1

### 18. Project Manager incorporates feedback and finalizes the Technical Advisory Group's Terms of Reference (ToR).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Final TAG ToR v1.0

**Dependencies:**

- Review Comments Received
- Circulation List

### 19. Chief Technology Officer (CTO) identifies and recruits leading experts in relevant technical fields to join the Technical Advisory Group (TAG).

**Responsible Body/Role:** Chief Technology Officer (CTO)

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Nominated Experts List
- Invitation Letters

**Dependencies:**

- Final TAG ToR v1.0

### 20. Chief Technology Officer (CTO) receives confirmation of membership from nominated experts of the Technical Advisory Group (TAG).

**Responsible Body/Role:** Chief Technology Officer (CTO)

**Suggested Timeframe:** Project Week 14

**Key Outputs/Deliverables:**

- Confirmed Experts List

**Dependencies:**

- Invitation Letters Sent

### 21. Chief Technology Officer (CTO) schedules and facilitates the initial kick-off meeting for the Technical Advisory Group (TAG).

**Responsible Body/Role:** Chief Technology Officer (CTO)

**Suggested Timeframe:** Project Week 15

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda
- Meeting Minutes with Action Items

**Dependencies:**

- Confirmed Experts List

### 22. Technical Advisory Group (TAG) develops a process for reviewing and assessing technical designs.

**Responsible Body/Role:** Technical Advisory Group (TAG)

**Suggested Timeframe:** Project Week 16

**Key Outputs/Deliverables:**

- Technical Design Review Process Document

**Dependencies:**

- Meeting Minutes with Action Items

### 23. Chief Legal Officer (CLO) drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Chief Legal Officer (CLO)

**Suggested Timeframe:** Project Week 17

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.1

**Dependencies:**

- Technical Design Review Process Document

### 24. Chief Legal Officer (CLO) circulates Draft ECC ToR v0.1 for review by Senior Management and Data Protection Officer (DPO).

**Responsible Body/Role:** Chief Legal Officer (CLO)

**Suggested Timeframe:** Project Week 18

**Key Outputs/Deliverables:**

- Circulation List
- Review Comments

**Dependencies:**

- Draft ECC ToR v0.1

### 25. Chief Legal Officer (CLO) incorporates feedback and finalizes the Ethics & Compliance Committee's Terms of Reference (ToR).

**Responsible Body/Role:** Chief Legal Officer (CLO)

**Suggested Timeframe:** Project Week 19

**Key Outputs/Deliverables:**

- Final ECC ToR v1.0

**Dependencies:**

- Review Comments Received
- Circulation List

### 26. Chief Legal Officer (CLO) identifies and recruits independent experts and representatives to join the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Chief Legal Officer (CLO)

**Suggested Timeframe:** Project Week 20

**Key Outputs/Deliverables:**

- Nominated Members List
- Invitation Letters

**Dependencies:**

- Final ECC ToR v1.0

### 27. Chief Legal Officer (CLO) receives confirmation of membership from nominated members of the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Chief Legal Officer (CLO)

**Suggested Timeframe:** Project Week 22

**Key Outputs/Deliverables:**

- Confirmed Members List

**Dependencies:**

- Invitation Letters Sent

### 28. Chief Legal Officer (CLO) schedules and facilitates the initial kick-off meeting for the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Chief Legal Officer (CLO)

**Suggested Timeframe:** Project Week 23

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda
- Meeting Minutes with Action Items

**Dependencies:**

- Confirmed Members List

### 29. Ethics & Compliance Committee (ECC) develops a code of ethics for the project.

**Responsible Body/Role:** Ethics & Compliance Committee (ECC)

**Suggested Timeframe:** Project Week 24

**Key Outputs/Deliverables:**

- Project Code of Ethics v1.0

**Dependencies:**

- Meeting Minutes with Action Items

### 30. Stakeholder Engagement Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Stakeholder Engagement Manager

**Suggested Timeframe:** Project Week 25

**Key Outputs/Deliverables:**

- Draft SEG ToR v0.1

**Dependencies:**

- Project Code of Ethics v1.0

### 31. Stakeholder Engagement Manager circulates Draft SEG ToR v0.1 for review by Communications Manager and Public Relations Officer.

**Responsible Body/Role:** Stakeholder Engagement Manager

**Suggested Timeframe:** Project Week 26

**Key Outputs/Deliverables:**

- Circulation List
- Review Comments

**Dependencies:**

- Draft SEG ToR v0.1

### 32. Stakeholder Engagement Manager incorporates feedback and finalizes the Stakeholder Engagement Group's Terms of Reference (ToR).

**Responsible Body/Role:** Stakeholder Engagement Manager

**Suggested Timeframe:** Project Week 27

**Key Outputs/Deliverables:**

- Final SEG ToR v1.0

**Dependencies:**

- Review Comments Received
- Circulation List

### 33. Stakeholder Engagement Manager identifies and recruits representatives to join the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Stakeholder Engagement Manager

**Suggested Timeframe:** Project Week 28

**Key Outputs/Deliverables:**

- Nominated Members List
- Invitation Letters

**Dependencies:**

- Final SEG ToR v1.0

### 34. Stakeholder Engagement Manager receives confirmation of membership from nominated members of the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Stakeholder Engagement Manager

**Suggested Timeframe:** Project Week 30

**Key Outputs/Deliverables:**

- Confirmed Members List

**Dependencies:**

- Invitation Letters Sent

### 35. Stakeholder Engagement Manager schedules and facilitates the initial kick-off meeting for the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Stakeholder Engagement Manager

**Suggested Timeframe:** Project Week 31

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda
- Meeting Minutes with Action Items

**Dependencies:**

- Confirmed Members List

### 36. Stakeholder Engagement Group (SEG) develops a stakeholder engagement plan.

**Responsible Body/Role:** Stakeholder Engagement Group (SEG)

**Suggested Timeframe:** Project Week 32

**Key Outputs/Deliverables:**

- Stakeholder Engagement Plan v1.0

**Dependencies:**

- Meeting Minutes with Action Items