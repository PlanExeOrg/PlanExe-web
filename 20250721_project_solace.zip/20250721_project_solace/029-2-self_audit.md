Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 15 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 4 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because success does not require breaking physical laws. The plan aims to reduce global mean temperatures by deploying a solar sunshade at the Earth-Sun L1 Lagrange point, which is consistent with known physics.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (solar sunshade) + market (global climate mitigation) + tech/process (in-space manufacturing, autonomous maintenance) + policy (international governance protocol) without independent evidence at comparable scale. There is no precedent for a project of this scope and complexity.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Project Leadership: Authoritative Source / 180 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions a 'Global Thermostat Governance Protocol' but lacks a business-level mechanism-of-action (inputs→process→customer value), an owner, and measurable outcomes. The plan states, "It dictates the areas where consensus is required among participating nations," but omits how this translates to value.

**Mitigation**: G20 Legal Working Group: Produce a one-pager defining the Governance Protocol's mechanism-of-action, value hypothesis, success metrics, and decision hooks. Due: 90 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the risk register identifies several second-order risks (regulatory, technical, financial, environmental, social, operational, supply chain, security, integration). However, explicit cascade analysis is absent. For example, the plan mentions "Conflicting national interests may delay the 'Global Thermostat Governance Protocol'," but does not map the consequences.

**Mitigation**: Risk Management Team: Expand the risk register to include explicit cascade analysis for each identified risk, mapping potential consequences and dependencies. Due: 60 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a permit/approval matrix. The plan mentions "Space Launch Permits", "Environmental Impact Permits", and "International Agreements for Geoengineering" but does not map these to specific jurisdictions or timelines. Without this, timeline realism cannot be assessed.

**Mitigation**: Legal Team: Create a permit/approval matrix mapping required permits to jurisdictions and timelines, including typical lead times. Due: 90 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "Secure funding commitments from the G20 nations" and a "$5 trillion budget" but lacks detail on funding sources, draw schedule, and covenants. The plan does not name each funding source and its status (e.g., LOI/term sheet/closed).

**Mitigation**: Finance Team: Develop a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO‑GO on missed financing gates. Due: 60 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions a "$5 trillion budget" but lacks scale-appropriate benchmarks. Benchmarking capex/opex per area (m²/ft²) is absent. Without normalization, cost realism cannot be assessed. The plan does not cite vendor quotes or comparables.

**Mitigation**: Finance Team: Benchmark (≥3), obtain quotes, normalize per-area, and adjust budget or de-scope by a set date. Due: 90 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents a single target of "reducing global mean temperatures by 1.5°C within 30 years" without providing a range, confidence interval, or discussing alternative scenarios. There is no discussion of contingency planning.

**Mitigation**: Climate Modeling Team: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the 1.5°C temperature reduction projection. Due: 60 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks engineering artifacts for build-critical components. The plan mentions "Advanced materials for sunshade construction" but lacks technical specs, interface definitions, test plans, and an integration map with owners/dates.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components. Due: 90 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "Secure funding commitments from the G20 nations" but lacks verifiable evidence of these commitments. There are no links to signed agreements or official statements of support from G20 members.

**Mitigation**: Project Manager: Obtain and document verifiable commitments (signed agreements, official statements) from G20 nations regarding funding. Due: 90 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "Global Thermostat Governance Protocol" as a deliverable, but lacks SMART acceptance criteria. There are no specific, verifiable qualities defined for the protocol, such as the number of participating nations or specific clauses.

**Mitigation**: G20 Legal Working Group: Define SMART criteria for the Governance Protocol, including a KPI for the number of ratifying nations (e.g., all G20 members). Due: 90 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'Autonomous Swarm Maintenance' without a clear benefit case. The plan aims to "reduce global mean temperatures by 1.5°C" and "establish a binding 'Global Thermostat Governance Protocol'". It's unclear how this feature directly supports these goals.

**Mitigation**: Project Team: Produce a one-page benefit case for 'Autonomous Swarm Maintenance', including a KPI, owner, and estimated cost, or move the feature to the project backlog. Due: 30 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a 'Dual-Use Mitigation & Security Strategist' to prevent weaponization. This role is critical due to the inherent risks and requires specialized expertise that is likely difficult to find.

**Mitigation**: HR Team: Conduct a talent market analysis for 'Dual-Use Mitigation & Security Strategist' to assess availability and competitiveness. Due: 60 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a permit/approval matrix. The plan mentions "Space Launch Permits", "Environmental Impact Permits", and "International Agreements for Geoengineering" but does not map these to specific jurisdictions or timelines.

**Mitigation**: Legal Team: Create a permit/approval matrix mapping required permits to jurisdictions and timelines, including typical lead times. Due: 90 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan lacks a detailed operational sustainability plan. The plan mentions "Secure funding commitments from the G20 nations" but does not address long-term maintenance costs, decommissioning, or technology obsolescence.

**Mitigation**: Project Team: Develop an operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms. Due: 120 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks evidence that the project satisfies hard constraints. The plan requires locations with space launch capabilities, international governance infrastructure, and advanced research facilities, but does not address zoning, noise, or structural limits.

**Mitigation**: Facilities Team: Perform a fatal-flaw screen with authorities/experts for each physical location (Kennedy Space Center, Geneva, CSIRO Canberra). Seek written confirmation where feasible. Due: 90 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions redundancy but lacks evidence of tested failovers. The plan mentions "Diversify launch providers" but does not include SLAs or tested failover procedures. The plan does not include evidence of tested failover plans.

**Mitigation**: Launch Operations Team: Secure SLAs with diversified launch providers and conduct/document failover tests by a set date. Due: 120 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the 'International Consortium Project Manager' is incentivized by on-time delivery, while the 'Governance Protocol Legal Team' is incentivized by thoroughness, creating a conflict over protocol scope. The plan does not address this conflict.

**Mitigation**: Project Leadership: Define a shared OKR for both teams focused on 'Protocol Adoption' (e.g., G20 ratification by 2027) to align incentives. Due: 30 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Leadership: Add a monthly review with KPI dashboard and a lightweight change board. Define thresholds for re-planning/stopping. Due: 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies several high risks (regulatory, technical, financial, environmental, social) but lacks a cross-impact analysis. A single failure in 'Global Thermostat Governance Protocol' could trigger financial, social, and environmental failures.

**Mitigation**: Risk Management Team: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Due: 90 days.