
## Audit - Corruption Risks

- Bribery of officials at the Danish Environmental Protection Agency to expedite permit approvals for insecticide use or waste disposal.
- Kickbacks from waste disposal companies in exchange for awarding them the contract for nest incineration.
- Conflicts of interest where project personnel have undisclosed financial ties to suppliers of biopesticides or equipment.
- Nepotism in hiring field technicians or community liaisons, potentially leading to unqualified personnel being selected.
- Misuse of confidential information regarding nest locations to benefit private landscaping companies or property developers.

## Audit - Misallocation Risks

- Inflated invoices from suppliers of biopesticides or protective gear, with the excess funds being diverted for personal use.
- Double billing for personnel costs, claiming payment for staff who are not actively working on the project.
- Inefficient allocation of resources, such as overspending on aerial surveys while neglecting ground-based inspections.
- Unauthorized use of project equipment, such as drones, for personal or commercial purposes.
- Misreporting of treatment progress to justify continued funding, even if eradication efforts are not effective.

## Audit - Procedures

- Conduct quarterly internal audits of all financial transactions, including invoices, receipts, and payment records, to identify any irregularities or discrepancies.
- Implement a robust contract review process for all major procurements, with independent legal and technical experts assessing the fairness and competitiveness of bids.
- Perform unannounced spot checks of field operations to verify that treatment protocols are being followed correctly and that protective gear is being used appropriately.
- Conduct regular compliance checks to ensure that all permits and licenses are up-to-date and that the project is adhering to environmental and safety regulations.
- Implement a whistleblower mechanism that allows employees and stakeholders to report suspected fraud or corruption anonymously, with clear procedures for investigating and addressing such reports.

## Audit - Transparency Measures

- Establish a public dashboard displaying key project metrics, such as nest counts, treatment progress, and budget expenditures, updated on a monthly basis.
- Publish minutes of all meetings of the centralized task force, including decisions related to resource allocation, treatment strategies, and stakeholder engagement.
- Develop and disseminate a clear and accessible policy on conflicts of interest, requiring all project personnel to disclose any potential conflicts and recuse themselves from related decisions.
- Establish a publicly accessible register of all contracts awarded for the project, including the names of the contractors, the value of the contracts, and the selection criteria used.
- Implement a system for tracking and responding to public inquiries and complaints, ensuring that all concerns are addressed promptly and transparently.