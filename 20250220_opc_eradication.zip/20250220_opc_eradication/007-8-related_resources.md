## Suggestion 1 - LIFE Project: LIFE OAK

LIFE OAK was a European Union LIFE+ project implemented in Belgium (Flanders) from 2010 to 2014. The project aimed to develop and demonstrate sustainable strategies for managing the Oak Processionary Moth (Thaumetopoea processionea) in urban and peri-urban environments. It focused on integrated pest management techniques, including biological control, nest removal, and public awareness campaigns, to minimize the use of chemical insecticides.

### Success Metrics

Reduction in Oak Processionary Moth populations in treated areas.
Increased public awareness and acceptance of sustainable management strategies.
Development and dissemination of best practice guidelines for Oak Processionary Moth management.
Reduced reliance on chemical insecticides.

### Risks and Challenges Faced

Public resistance to certain management techniques (e.g., nest removal). This was overcome through extensive public communication and engagement.
Variability in the effectiveness of biological control agents due to environmental factors. This was mitigated by using a combination of different control methods.
Coordination between different stakeholders (municipalities, researchers, and contractors). This was addressed through regular meetings and clear communication channels.

### Where to Find More Information

https://www.vlinderstichting.nl/actueel/nieuws/life-oak-project-successful-control-of-oak-processionary-caterpillar/
https://www.researchgate.net/project/LIFE-OAK-Sustainable-strategies-for-the-management-of-the-Oak-Processionary-Moth-Thaumetopoea-processionea-in-urban-and-peri-urban-environments

### Actionable Steps

Contact the project coordinator at the Flemish Institute for Nature and Forest Research (INBO) to obtain detailed information on the project's methodology and results. (Email addresses can be found on the INBO website).
Review the project's final report and best practice guidelines, which are available online.
Connect with municipalities in Flanders that participated in the project to learn about their experiences with implementing sustainable management strategies.

### Rationale for Suggestion

LIFE OAK is highly relevant because it directly addresses the management of Oak Processionary Moths in a European context. It shares similar objectives, including reducing the caterpillar population, minimizing environmental impact, and raising public awareness. The project's focus on integrated pest management and biological control aligns with the user's stated preference for environmentally friendly treatment options. Although geographically distant, the project provides valuable insights into the challenges and successes of managing this pest in a similar climate and cultural context.
## Suggestion 2 - Oak Processionary Moth Control Program in the Netherlands

The Netherlands has been dealing with Oak Processionary Moths for several years and has implemented a comprehensive control program. This program involves a combination of monitoring, nest removal, biological control (using Bacillus thuringiensis), and public awareness campaigns. The program is managed by municipalities and provinces, with support from national research institutions.

### Success Metrics

Reduction in the number of reported cases of skin irritation and allergic reactions caused by the caterpillars.
Decrease in the defoliation of oak trees in affected areas.
Increased public awareness and reporting of Oak Processionary Moth nests.
Cost-effective management of the pest.

### Risks and Challenges Faced

Rapid spread of the Oak Processionary Moth to new areas. This was addressed through proactive monitoring and early intervention.
Development of resistance to Bacillus thuringiensis. This was mitigated by using different strains of Bt and rotating treatment methods.
Public concerns about the use of insecticides, even biological ones. This was addressed through transparent communication and public education.

### Where to Find More Information

https://www.naturetoday.com/nl/natuurbericht/id/27001/eikenprocessierups-overlast-neemt-toe-wat-kun-je-zelf-doen
Search for reports and publications from Dutch research institutions such as Wageningen University & Research (WUR) on Oak Processionary Moth management.

### Actionable Steps

Contact municipalities in the Netherlands that have experience with Oak Processionary Moth control to learn about their specific strategies and challenges. (Contact information can be found on municipal websites).
Review the guidelines and recommendations published by the Dutch government on Oak Processionary Moth management.
Connect with researchers at Wageningen University & Research (WUR) to obtain the latest scientific information on Oak Processionary Moth biology and control.

### Rationale for Suggestion

The Dutch Oak Processionary Moth Control Program is highly relevant due to its scale and long-term experience in managing this pest. The Netherlands has faced similar challenges to those anticipated in Denmark, including rapid spread, public concerns, and the need for cost-effective solutions. The program's integrated approach, combining monitoring, nest removal, biological control, and public awareness, provides a valuable model for the user's project. The geographical proximity and similar climate make this project particularly relevant.
## Suggestion 3 - Forest Health Protection Program - US Forest Service

The US Forest Service's Forest Health Protection program addresses various forest pests and diseases across the United States. While not specifically focused on Oak Processionary Moths (which are not a major pest in the US), the program provides a framework for managing invasive species and protecting forest ecosystems. It includes monitoring, risk assessment, treatment, and restoration components.

### Success Metrics

Acres of forest protected from pest and disease damage.
Reduction in the spread of invasive species.
Improved forest health and resilience.
Cost-effective management of forest pests and diseases.

### Risks and Challenges Faced

Large-scale infestations covering vast areas. This was addressed through prioritization of high-value areas and targeted treatments.
Limited resources for managing all forest health threats. This was mitigated by leveraging partnerships with other agencies and organizations.
Public opposition to certain management techniques (e.g., prescribed burning). This was addressed through public education and engagement.

### Where to Find More Information

https://www.fs.usda.gov/managing-land/forest-health
Search for publications and reports from the US Forest Service on forest pest and disease management.

### Actionable Steps

Review the US Forest Service's guidelines and best practices for managing forest pests and diseases.
Contact forest health specialists at the US Forest Service to learn about their experiences with managing invasive species.
Explore opportunities for adapting the US Forest Service's framework to the specific context of Oak Processionary Moth management in Denmark.

### Rationale for Suggestion

While geographically distant and not directly focused on Oak Processionary Moths, the US Forest Service's Forest Health Protection program offers valuable insights into managing invasive species and protecting ecosystems. The program's comprehensive approach, including monitoring, risk assessment, treatment, and restoration, provides a useful framework for the user's project. The program's experience in dealing with large-scale infestations and limited resources is also relevant to the challenges anticipated in Denmark. This suggestion is included because of the limited number of directly relevant projects in geographically and culturally similar regions.

## Summary

The user is planning a project to eradicate Oak Processionary Caterpillars (OPC) in Denmark, specifically in Odense, Funen, and Zealand. The project aims for rapid response and containment, balancing urgency with environmental and logistical constraints. The strategic approach chosen is 'The Pioneer's Blitz,' prioritizing speed and aggressive action. The following recommendations provide reference projects with similar characteristics and challenges.