Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 15 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 4 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan focuses on pest eradication, not on breaking any laws of physics. The goal is to eliminate Oak Processionary Caterpillars, which is a biological problem, not a physics one.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (biopesticide) + market (Denmark) + tech/process (drone spraying) + policy (environmental regulations) without independent evidence at comparable scale. The plan lacks proof that this system works.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: Task Force Coordinator / Deliverable: Validation Report / Date: 2025-03-15


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan uses terms like "Pioneer's Blitz" without defining their mechanism-of-action (inputs→process→customer value), owner, or measurable outcomes. The plan states "We're employing a **'Pioneer's Blitz'** strategy" but does not define it.

**Mitigation**: Task Force Coordinator: Create a one-pager defining "Pioneer's Blitz" with a value hypothesis, success metrics, and decision hooks. Due Date: 2025-03-15


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because a major hazard class (ecological) is minimized. The plan focuses on rapid eradication, potentially at the expense of the broader ecosystem health. There's a lack of concrete plans for ecological monitoring post-treatment.

**Mitigation**: Environmental Compliance Officer: Commission an ecological impact assessment and develop a detailed ecological restoration plan by 2025-04-30, including specific metrics and timelines.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan states, "Necessary permits and approvals are obtained," but does not list them or their lead times.

**Mitigation**: Task Force Coordinator: Create a permit/approval matrix with lead times and dependencies. Due Date: 2025-03-15


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because committed sources/term sheets do not cover the required runway or financing gates/covenants are undefined. The plan assumes a "500,000 DKK budget based on typical municipal funding" but lacks evidence of commitment.

**Mitigation**: Task Force Coordinator: Develop a dated financing plan listing funding sources/status, draw schedule, and covenants. Include a NO-GO on missed financing gates. Due Date: 2025-03-15


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget of 11,000 DKK for personnel, equipment, materials, and monitoring is not scale-appropriate for eradicating a pest across multiple locations. There are no vendor quotes or per-area cost estimates.

**Mitigation**: Task Force Coordinator: Obtain vendor quotes for equipment, materials, and services. Normalize costs per area (m²) and adjust the budget or de-scope. Due Date: 2025-03-15


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., completion dates) as single numbers without providing a range or discussing alternative scenarios. For example, the goal is to "prevent further spread to Funen and Zealand by August 2025."

**Mitigation**: Project Manager: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the project's completion date. Due Date: 2025-03-15


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because build-critical components lack engineering artifacts. The plan mentions using drones with thermal imaging, but lacks specifications, interface contracts, acceptance tests, integration plan, and non-functional requirements.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for the drone-based thermal imaging system. Due Date: 2025-04-30


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan states, "Necessary permits and approvals are obtained" but does not list them or their lead times. The permit/approval matrix is absent.

**Mitigation**: Task Force Coordinator: Create a permit/approval matrix with lead times and dependencies. Due Date: 2025-03-15


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because a major deliverable, 'a sustainable model for pest eradication,' is mentioned without specific, verifiable qualities. The plan states, "Our long-term vision is to create a **sustainable** model for pest eradication."

**Mitigation**: Task Force Coordinator: Define SMART criteria for 'a sustainable model,' including a KPI for reduced pesticide use (e.g., 20% reduction YoY). Due Date: 2025-03-30


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes a 'green' certification program for oak trees treated with environmentally friendly methods. This feature does not directly support the core goals of eradication or public safety.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the 'green' certification program, complete with a KPI, owner, and estimated cost, or move the feature to the project backlog. Due Date: 2025-03-30


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies the Task Force Coordinator as crucial for aligning stakeholders and ensuring efficiency, but the role requires rare skills in emergency response, public administration, and local knowledge.

**Mitigation**: Task Force Coordinator: Validate the availability of qualified candidates for the Task Force Coordinator role within the required timeframe. Due Date: 2025-03-15


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan states, "Necessary permits and approvals are obtained" but does not list them or their lead times. The permit/approval matrix is absent.

**Mitigation**: Task Force Coordinator: Create a permit/approval matrix with lead times and dependencies. Due Date: 2025-03-15


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan lacks a detailed operational sustainability plan. The plan mentions long-term monitoring but lacks specifics on funding, maintenance, succession planning, or technology roadmaps. The plan states, "Implement a long-term monitoring program."

**Mitigation**: Project Manager: Develop an operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, and technology roadmap. Due Date: 2025-04-30


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "necessary permits and approvals are obtained" but does not list them or their lead times. The plan lacks a fatal-flaw screen with authorities.

**Mitigation**: Task Force Coordinator: Create a permit/approval matrix with lead times and dependencies. Include NO-GO thresholds tied to constraint outcomes. Due Date: 2025-03-15


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions contracts with waste disposal companies but lacks details on SLAs, redundancy, or tested failover plans. The plan states, "Establish contracts with waste disposal companies for the safe incineration of nests."

**Mitigation**: Procurement Officer: Secure SLAs with waste disposal vendors, add a secondary disposal path, and test failover by 2025-04-30 to ensure resilience.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the Finance Department is incentivized by budget adherence, while the Pest Control Specialists are incentivized by complete eradication, creating a conflict over resource allocation. The plan does not address this conflict.

**Mitigation**: Project Manager: Create a shared OKR that aligns Finance and Pest Control on a common outcome, such as 'Eradicate OPC within budget'. Due Date: 2025-03-30


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board. Owner: Project Manager. Deliverable: Review Cadence. Date: 2025-03-30


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan has ≥3 High risks (FM1, FM3, FM4, FM5) that are strongly coupled. Public resistance (FM1) can delay treatment (FM4), leading to resistance (FM3) and data loss (FM5).

**Mitigation**: Project Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Due Date: 2025-04-30