A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The public will readily accept and comply with the chosen eradication methods, including insecticide spraying, without significant resistance or protest. | Conduct a survey in the affected areas to gauge public opinion on insecticide spraying and other proposed eradication methods. | More than 30% of respondents express strong opposition to insecticide spraying or indicate they will actively resist the eradication efforts. |
| A2 | The specialized equipment (drones, sprayers, protective gear) required for the eradication effort will be readily available and delivered on schedule without significant supply chain disruptions. | Contact potential suppliers and request quotes and delivery timelines for all critical equipment and materials. | Any supplier is unable to guarantee delivery of critical equipment within the required timeframe (<= 2 weeks) or quotes prices exceeding the budgeted amount by more than 15%. |
| A3 | The chosen biopesticide (Bacillus thuringiensis) will remain effective throughout the eradication period, and the Oak Processionary Caterpillars will not develop significant resistance. | Collect caterpillar samples from the affected areas and conduct laboratory tests to determine their current susceptibility to Bacillus thuringiensis. | Laboratory tests reveal that the caterpillar population exhibits a 20% or greater reduction in susceptibility to the chosen Bacillus thuringiensis strain compared to baseline data from previous studies. |
| A4 | Local weather conditions during the treatment period will be consistently favorable (minimal rainfall, moderate temperatures, low wind) to allow for effective and safe application of the chosen treatment methods. | Analyze historical weather data for the treatment area during the planned application period (May-June) to assess the frequency of unfavorable weather conditions. | Historical data reveals that unfavorable weather conditions (excessive rainfall, high winds) occur for more than 40% of the days during the planned treatment period. |
| A5 | The GIS system used for mapping nest locations and tracking treatment progress will function reliably and accurately, providing real-time data for effective decision-making. | Conduct a stress test of the GIS system using simulated data to assess its capacity to handle a large volume of data and user traffic. | The GIS system experiences significant performance issues (slow response times, data errors, system crashes) during the stress test, indicating it cannot reliably handle the expected workload. |
| A6 | Sufficient and qualified personnel (field technicians, supervisors, drone operators) will be readily available and willing to participate in the eradication effort throughout the entire project duration. | Contact local pest control companies, environmental organizations, and employment agencies to assess the availability of qualified personnel and their willingness to participate in the project. | Fewer than 75% of the required personnel positions can be filled with qualified candidates within the project's timeframe, or the cost of hiring qualified personnel exceeds the budgeted amount by more than 20%. |
| A7 | The local community will accurately identify and report Oak Processionary Caterpillar nests, providing reliable data for monitoring and treatment efforts. | Conduct a pilot study in a small area to assess the accuracy of community-reported nest sightings compared to professional surveys. | The pilot study reveals that >= 40% of community-reported nest sightings are either false positives or significantly misidentified, rendering the data unreliable. |
| A8 | The chosen waste disposal method (incineration) will be consistently available and compliant with all relevant environmental regulations throughout the project duration. | Obtain written confirmation from the waste disposal company guaranteeing their capacity to handle the project's waste volume and their compliance with all environmental regulations. | The waste disposal company is unable to guarantee their capacity or compliance, or their fees exceed the budgeted amount by more than 10%. |
| A9 | The project team will effectively collaborate and communicate, ensuring seamless coordination and efficient execution of all eradication activities. | Conduct a team-building exercise and assess communication effectiveness through surveys and observation. | Surveys reveal that >= 30% of team members report significant communication breakdowns or lack of clarity regarding roles and responsibilities, hindering effective collaboration. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Public Backlash Bomb | Market/Human | A1 | Community Liaison | CRITICAL (20/25) |
| FM2 | The Supply Chain Snarl | Technical/Logistical | A2 | Logistics Coordinator | HIGH (12/25) |
| FM3 | The Resistance Racket | Process/Financial | A3 | Pest Control Specialist | CRITICAL (15/25) |
| FM4 | The Weather Whiplash | Process/Financial | A4 | Logistics Coordinator | CRITICAL (20/25) |
| FM5 | The Data Deluge Disaster | Technical/Logistical | A5 | GIS and Data Analyst | CRITICAL (15/25) |
| FM6 | The Talent Tumble | Market/Human | A6 | Task Force Coordinator | HIGH (12/25) |
| FM7 | The Citizen Science Snafu | Market/Human | A7 | Community Liaison | HIGH (12/25) |
| FM8 | The Incineration Inferno | Technical/Logistical | A8 | Waste Disposal Manager | HIGH (10/25) |
| FM9 | The Communication Cascade Catastrophe | Process/Financial | A9 | Task Force Coordinator | HIGH (12/25) |


### Failure Modes

#### FM1 - The Public Backlash Bomb

- **Archetype**: Market/Human
- **Root Cause**: Assumption A1
- **Owner**: Community Liaison
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's public awareness campaign fails to adequately address public concerns about insecticide spraying. Misinformation spreads rapidly through social media, fueled by activist groups. Local residents organize protests and block access to treatment areas. The media portrays the project as an environmental hazard, leading to widespread public outcry. Key stakeholders, including local politicians, withdraw their support due to the negative publicity. The project faces legal challenges and is forced to halt operations.

##### Early Warning Signs
- Social media sentiment analysis shows a >= 20% increase in negative comments related to the project within the last week.
- Petition against insecticide spraying gains >= 500 signatures within 48 hours.
- Local news outlets publish >= 3 articles critical of the project in a single week.

##### Tripwires
- Protests block access to >= 20% of treatment areas for >= 2 days.
- Public survey reveals >= 40% disapproval of insecticide spraying.
- Key stakeholder (e.g., local politician) publicly withdraws support.

##### Response Playbook
- Contain: Immediately suspend insecticide spraying operations.
- Assess: Conduct an emergency public opinion poll and stakeholder consultation to understand the root causes of the backlash.
- Respond: Revise the public awareness campaign to address specific concerns, offer alternative treatment options, and engage in transparent dialogue with the community.


**STOP RULE:** Public resistance makes it impossible to access >= 50% of treatment areas for >= 14 consecutive days, rendering effective eradication impossible.

---

#### FM2 - The Supply Chain Snarl

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Logistics Coordinator
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
A major disruption in the global supply chain delays the delivery of critical equipment, including drones and specialized sprayers. The project's reliance on a single supplier for protective gear leads to shortages, compromising worker safety. The lack of readily available replacement parts for the drones causes extended downtime. The project is unable to conduct aerial surveys or implement the treatment modality on schedule. The caterpillar population spreads rapidly, exceeding the initial containment zone. The project faces significant delays and increased costs.

##### Early Warning Signs
- Supplier notifies the project of a >= 7-day delay in the delivery of critical equipment.
- Inventory of protective gear falls below >= 50% of the required level.
- Drone downtime exceeds >= 3 days due to lack of replacement parts.

##### Tripwires
- Delivery of drones delayed by >= 14 days.
- Protective gear inventory falls below >= 25% of required levels.
- More than >= 25% of drones are inoperable simultaneously.

##### Response Playbook
- Contain: Immediately activate backup suppliers and explore alternative equipment options.
- Assess: Conduct a thorough inventory assessment and identify critical equipment shortages.
- Respond: Expedite shipping, negotiate with suppliers, and prioritize the procurement of essential equipment to minimize delays.


**STOP RULE:** Critical equipment (drones or sprayers) are unavailable for >= 30 days, making it impossible to treat the infested areas before the caterpillar dispersal season begins.

---

#### FM3 - The Resistance Racket

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A3
- **Owner**: Pest Control Specialist
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The Oak Processionary Caterpillars rapidly develop resistance to Bacillus thuringiensis due to overuse or improper application. The biopesticide becomes ineffective, and the caterpillar population rebounds. The project is forced to switch to a more expensive and potentially harmful alternative treatment. The increased costs strain the budget, forcing cuts in monitoring and community engagement activities. The project fails to achieve its eradication goals and faces significant financial losses.

##### Early Warning Signs
- Post-treatment monitoring shows a <= 20% reduction in caterpillar population compared to pre-treatment levels.
- Laboratory tests reveal a >= 10% decrease in caterpillar susceptibility to Bacillus thuringiensis.
- Field observations indicate increased caterpillar survival rates after treatment.

##### Tripwires
- Post-treatment monitoring shows <= 10% reduction in caterpillar population.
- Lab tests confirm >= 20% reduction in caterpillar susceptibility to Bt.
- Treatment costs exceed budget by >= 25% due to alternative treatments.

##### Response Playbook
- Contain: Immediately halt Bacillus thuringiensis applications and implement alternative treatment methods.
- Assess: Conduct a thorough resistance assessment and identify the underlying causes of treatment failure.
- Respond: Revise the treatment strategy, implement resistance management protocols, and secure additional funding to cover the increased costs.


**STOP RULE:** Alternative treatment methods prove ineffective, and the project budget is exhausted, making it impossible to continue eradication efforts.

---

#### FM4 - The Weather Whiplash

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Logistics Coordinator
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Unusually heavy rainfall and strong winds plague the treatment period, severely limiting the number of days suitable for aerial spraying. The project is unable to apply the biopesticide effectively, and the caterpillar population continues to thrive. The delays force the project to extend its timeline, incurring additional labor and equipment rental costs. The extended timeline also increases the risk of public resistance and regulatory challenges. The project exceeds its budget and fails to achieve its eradication goals.

##### Early Warning Signs
- Weather forecasts predict >= 7 consecutive days of heavy rainfall or strong winds during the treatment period.
- The number of days suitable for aerial spraying falls below >= 50% of the planned schedule.
- Equipment rental costs exceed the budgeted amount by >= 15% due to extended rental periods.

##### Tripwires
- Suitable spraying days <= 3 days per week for >= 2 consecutive weeks.
- Project timeline extended by >= 3 weeks due to weather delays.
- Total project costs exceed budget by >= 10%.

##### Response Playbook
- Contain: Immediately explore alternative treatment methods that are less weather-dependent.
- Assess: Conduct a thorough weather risk assessment and revise the project schedule accordingly.
- Respond: Negotiate with equipment rental companies to reduce costs, secure additional funding, and implement a more flexible treatment strategy.


**STOP RULE:** Unfavorable weather conditions persist for >= 6 weeks, making it impossible to complete the treatment before the caterpillar dispersal season begins, and the project budget is exhausted.

---

#### FM5 - The Data Deluge Disaster

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: GIS and Data Analyst
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The GIS system crashes under the weight of the data generated by the aerial surveys and field operations. Critical data on nest locations, treatment progress, and resource allocation is lost or corrupted. The project team is unable to effectively track the eradication effort or make informed decisions. The lack of reliable data leads to inefficient resource allocation, missed treatment targets, and increased caterpillar spread. The project descends into chaos and ultimately fails to achieve its goals.

##### Early Warning Signs
- The GIS system experiences frequent crashes or slowdowns during peak usage periods.
- Data entry errors increase by >= 20% compared to baseline levels.
- The project team reports difficulty accessing or retrieving critical data from the GIS system.

##### Tripwires
- GIS system downtime exceeds >= 24 hours.
- Critical data on >= 10% of nest locations is lost or corrupted.
- Project team reports significant delays in accessing or retrieving data for >= 3 consecutive days.

##### Response Playbook
- Contain: Immediately implement data backup and recovery procedures.
- Assess: Conduct a thorough system audit to identify the root causes of the GIS system failure.
- Respond: Upgrade the GIS system infrastructure, implement data validation protocols, and provide additional training to the project team on data management best practices.


**STOP RULE:** The GIS system remains unreliable for >= 2 weeks, making it impossible to effectively track the eradication effort and allocate resources, and the project budget is insufficient to implement a reliable alternative data management system.

---

#### FM6 - The Talent Tumble

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Task Force Coordinator
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
A shortage of qualified personnel plagues the eradication effort. Field technicians quit due to the demanding work conditions and exposure to toxic caterpillar hairs. Drone operators are poached by higher-paying companies. The project is unable to fill critical positions, leading to delays in aerial surveys, treatment application, and nest removal. The lack of qualified personnel also compromises worker safety and increases the risk of accidents. The project struggles to maintain momentum and ultimately fails to achieve its eradication goals.

##### Early Warning Signs
- The project experiences a >= 20% turnover rate among field technicians within the first month.
- The number of qualified applicants for open positions falls below >= 50% of the expected level.
- The project receives complaints from workers regarding inadequate safety equipment or training.

##### Tripwires
- More than >= 3 critical personnel positions remain unfilled for >= 2 weeks.
- Worker absenteeism due to illness or injury exceeds >= 10%.
- Project experiences a significant safety incident (e.g., worker exposure to toxic hairs requiring medical attention).

##### Response Playbook
- Contain: Immediately implement retention strategies, such as increasing pay, improving working conditions, and providing additional training and support.
- Assess: Conduct a thorough workforce assessment to identify the root causes of the personnel shortage.
- Respond: Recruit additional personnel, partner with local training institutions, and offer incentives to attract and retain qualified workers.


**STOP RULE:** The project is unable to fill >= 50% of critical personnel positions for >= 4 weeks, making it impossible to conduct effective eradication operations, and the cost of attracting and retaining qualified personnel exceeds the available budget.

---

#### FM7 - The Citizen Science Snafu

- **Archetype**: Market/Human
- **Root Cause**: Assumption A7
- **Owner**: Community Liaison
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The community, despite initial enthusiasm, proves unreliable in identifying and reporting Oak Processionary Caterpillar nests. Misinformation spreads, leading to numerous false alarms and wasted resources. The project team spends valuable time investigating inaccurate reports, diverting attention from actual infestations. The lack of reliable data undermines the monitoring efforts and hinders the effectiveness of the treatment strategy. Public trust erodes as residents become frustrated with the inaccurate information and the project's perceived inefficiency.

##### Early Warning Signs
- The number of community-reported nest sightings declines by >= 50% within the first two weeks of the project.
- The percentage of false positive reports exceeds >= 50% of all community-reported sightings.
- The project team spends >= 25% of their time investigating inaccurate reports.

##### Tripwires
- False positive reports >= 60% of all community reports.
- Response time to verified nests >= 7 days due to false leads.
- Public participation in reporting declines >= 75% after initial launch.

##### Response Playbook
- Contain: Immediately suspend reliance on community-reported data for treatment decisions.
- Assess: Conduct a thorough analysis of the reasons for the inaccurate reporting and declining participation.
- Respond: Revise the public awareness campaign to provide clearer identification guidelines, implement a verification process for community reports, and focus on professional surveys for accurate data collection.


**STOP RULE:** Community-reported data proves consistently unreliable for >= 4 weeks, making it impossible to effectively monitor the infestation and allocate resources, and the cost of professional surveys exceeds the available budget.

---

#### FM8 - The Incineration Inferno

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Waste Disposal Manager
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The waste disposal company unexpectedly shuts down its incineration facility due to regulatory violations or equipment malfunctions. The project is left without a viable method for disposing of the removed caterpillar nests, leading to a backlog of hazardous waste. The lack of proper disposal poses a significant environmental and public health risk. The project faces legal challenges and is forced to halt nest removal operations. The caterpillar population continues to spread unchecked, and the project's credibility is severely damaged.

##### Early Warning Signs
- The waste disposal company notifies the project of a potential disruption in their services.
- The waste disposal company fails to meet its contractual obligations for waste removal.
- The project receives complaints from local residents regarding improper waste storage or handling.

##### Tripwires
- Waste disposal company suspends operations for >= 7 days.
- Backlog of removed nests exceeds >= 50% of storage capacity.
- Regulatory agency issues a warning or fine related to waste disposal practices.

##### Response Playbook
- Contain: Immediately secure temporary storage for the removed nests in a secure and environmentally safe location.
- Assess: Conduct a thorough assessment of alternative waste disposal options, including other incineration facilities or approved landfill sites.
- Respond: Negotiate with alternative waste disposal providers, secure necessary permits, and implement a revised waste disposal protocol.


**STOP RULE:** A viable waste disposal method cannot be secured within >= 3 weeks, leading to a critical backlog of hazardous waste and posing an imminent threat to public health and the environment, and the project budget is insufficient to cover the costs of alternative disposal options.

---

#### FM9 - The Communication Cascade Catastrophe

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Task Force Coordinator
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
Internal communication breakdowns and lack of coordination plague the project team. Field technicians fail to report critical data on treatment progress. The GIS and Data Analyst is unaware of changes in the treatment strategy. The Community Liaison provides conflicting information to the public. The Task Force Coordinator is unable to effectively manage the project due to the lack of reliable information. The project descends into chaos, leading to inefficient resource allocation, missed treatment targets, and increased caterpillar spread. The lack of teamwork undermines the entire eradication effort.

##### Early Warning Signs
- The project team reports frequent communication breakdowns and misunderstandings.
- Data discrepancies are identified between different project components.
- The project team fails to meet deadlines or achieve milestones due to lack of coordination.

##### Tripwires
- Critical data is missing or inaccurate for >= 20% of treatment areas.
- Significant disagreements or conflicts arise between team members during project meetings.
- Project milestones are missed by >= 1 week due to lack of coordination.

##### Response Playbook
- Contain: Immediately implement mandatory team-building exercises and communication training.
- Assess: Conduct a thorough assessment of the communication channels and protocols to identify the root causes of the breakdowns.
- Respond: Revise the communication plan, establish clear roles and responsibilities, and implement regular team meetings to improve coordination and collaboration.


**STOP RULE:** Communication breakdowns persist for >= 4 weeks, making it impossible to effectively coordinate the eradication effort and allocate resources, and the project team loses confidence in the project's leadership and ability to achieve its goals.
