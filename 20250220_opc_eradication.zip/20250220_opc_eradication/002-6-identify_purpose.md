**Purpose:** business

**Purpose Detailed:** Public welfare and environmental protection through pest control.

**Topic:** Eradication of Oak Processionary Caterpillars