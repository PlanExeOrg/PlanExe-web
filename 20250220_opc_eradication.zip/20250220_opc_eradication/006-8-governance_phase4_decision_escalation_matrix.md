**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic oversight and approval at a higher level.
Negative Consequences: Potential for budget overruns, project scope reduction, or project delays.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: The risk has a significant impact on project objectives and requires strategic decisions and resource allocation beyond the PMO's capacity.
Negative Consequences: Project failure, significant delays, increased costs, or harm to public health and environment.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: Inability to reach consensus within the PMO necessitates a higher-level decision to ensure project progress and avoid delays.
Negative Consequences: Project delays, increased costs, or selection of a suboptimal vendor.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Impact Assessment
Rationale: Significant changes to the project scope require strategic alignment and approval from the Steering Committee to ensure continued relevance and feasibility.
Negative Consequences: Project misalignment with strategic objectives, budget overruns, or project delays.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Senior Management Team
Rationale: Requires independent review and investigation to ensure ethical conduct and compliance with regulations.
Negative Consequences: Legal penalties, reputational damage, loss of public trust, or project disruption.

**Technical Advisory Group disagreement on Treatment Modality**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review of the TAG recommendations and final decision.
Rationale: Disagreement among technical experts requires strategic decision-making to ensure effective and environmentally sound practices.
Negative Consequences: Ineffective treatment, environmental damage, or project delays.