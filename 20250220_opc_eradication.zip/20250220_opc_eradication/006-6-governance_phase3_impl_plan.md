### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**


### 2. Circulate Draft SteerCo ToR for review by Senior Management Representative, Head of Pest Control Department, Head of Environmental Protection Agency (or delegate), Head of Public Health Department (or delegate), and Independent Environmental Expert.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1 circulated for review
- Review Feedback

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager incorporates feedback and finalizes the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Review Feedback

### 4. Senior Management Representative formally appoints the Chair of the Project Steering Committee.

**Responsible Body/Role:** Senior Management Representative

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Manager, in consultation with the appointed SteerCo Chair, schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Email

### 6. Hold the initial Project Steering Committee kick-off meeting to review the project plan, budget, and governance structure.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 7. Project Manager establishes project management processes and procedures for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Documented PMO processes and procedures

**Dependencies:**


### 8. Project Manager develops the initial project plan and budget for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Initial Project Plan
- Initial Project Budget

**Dependencies:**


### 9. Project Manager sets up project tracking and reporting systems for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Project Tracking System
- Reporting Templates

**Dependencies:**


### 10. Project Manager defines roles and responsibilities of project team members within the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Roles and Responsibilities Matrix

**Dependencies:**


### 11. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Documented PMO processes and procedures
- Initial Project Plan
- Initial Project Budget
- Project Tracking System
- Reporting Templates
- Roles and Responsibilities Matrix

### 12. Legal Counsel drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**


### 13. Circulate Draft Ethics & Compliance Committee ToR for review by Compliance Officer, Internal Auditor, Independent Ethics Expert, and Community Representative.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1 circulated for review
- Review Feedback

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 14. Legal Counsel incorporates feedback and finalizes the Ethics & Compliance Committee Terms of Reference.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Review Feedback

### 15. Senior Management Representative formally appoints the Chair (Legal Counsel) of the Ethics & Compliance Committee.

**Responsible Body/Role:** Senior Management Representative

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 16. Legal Counsel, in consultation with the appointed members, schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Email

### 17. Hold the initial Ethics & Compliance Committee kick-off meeting to review the project plan, code of ethics, and compliance requirements.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Code of Ethics

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 18. Entomologist drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Entomologist

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**


### 19. Circulate Draft Technical Advisory Group ToR for review by Environmental Scientist, Pest Control Specialist, GIS Specialist, and Independent Arborist.

**Responsible Body/Role:** Entomologist

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1 circulated for review
- Review Feedback

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1

### 20. Entomologist incorporates feedback and finalizes the Technical Advisory Group Terms of Reference.

**Responsible Body/Role:** Entomologist

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Technical Advisory Group ToR v1.0

**Dependencies:**

- Review Feedback

### 21. Senior Management Representative formally appoints the Chair (Entomologist) of the Technical Advisory Group.

**Responsible Body/Role:** Senior Management Representative

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Technical Advisory Group ToR v1.0

### 22. Entomologist, in consultation with the appointed members, schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Entomologist

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Email

### 23. Hold the initial Technical Advisory Group kick-off meeting to review the project plan, treatment methods, and monitoring strategies.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda