### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and ensures alignment with organizational goals, given the project's high impact on public health and the environment, and the need for significant resource allocation.

**Responsibilities:**

- Provide strategic direction and guidance to the project team.
- Approve project scope, budget, and timeline.
- Monitor project progress against strategic objectives.
- Approve major changes to project scope, budget, or timeline (>$50,000 DKK).
- Oversee risk management and mitigation strategies.
- Ensure alignment with organizational policies and regulatory requirements.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define reporting requirements from the Project Management Office.

**Membership:**

- Senior Management Representative (Chair)
- Head of Pest Control Department
- Head of Environmental Protection Agency (or delegate)
- Head of Public Health Department (or delegate)
- Independent Environmental Expert

**Decision Rights:** Strategic decisions related to project scope, budget (>$50,000 DKK), timeline, and risk management. Approval of major deviations from the project plan.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Senior Management Representative (Chair) has the deciding vote. Dissenting opinions are formally recorded.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of project progress against strategic objectives.
- Review of project budget and expenditures.
- Review of risk register and mitigation strategies.
- Discussion of any major issues or challenges.
- Approval of change requests (>$50,000 DKK).

**Escalation Path:** Senior Management Team
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Ensures efficient project execution, manages day-to-day operations, and provides support to the project team, given the project's complexity and the need for coordinated action.

**Responsibilities:**

- Develop and maintain the project plan.
- Manage project budget and track expenditures.
- Coordinate project activities and resources.
- Monitor project progress and identify potential issues.
- Implement risk management and mitigation strategies.
- Prepare regular project status reports.
- Manage change requests ( <$50,000 DKK).
- Ensure compliance with project governance framework.

**Initial Setup Actions:**

- Establish project management processes and procedures.
- Develop project plan and budget.
- Set up project tracking and reporting systems.
- Define roles and responsibilities of project team members.

**Membership:**

- Project Manager (Head of PMO)
- Project Coordinator
- Finance Officer
- Risk Manager
- Communications Officer

**Decision Rights:** Operational decisions related to project execution, resource allocation (within approved budget), and risk management (below strategic thresholds).

**Decision Mechanism:** Decisions made by the Project Manager in consultation with the PMO team. Issues requiring strategic decisions are escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of any issues or challenges.
- Review of project budget and expenditures.
- Review of risk register and mitigation strategies.
- Planning of upcoming activities.

**Escalation Path:** Project Steering Committee
### 3. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures ethical conduct, regulatory compliance, and transparency throughout the project, given the potential for corruption risks and the need to maintain public trust.

**Responsibilities:**

- Develop and implement a code of ethics for the project.
- Ensure compliance with all applicable laws and regulations, including GDPR and environmental regulations.
- Investigate any allegations of ethical misconduct or regulatory violations.
- Provide guidance on ethical issues and compliance requirements.
- Oversee the whistleblower mechanism.
- Review and approve all contracts and procurement activities.
- Monitor project activities for potential corruption risks.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Develop code of ethics.
- Establish whistleblower mechanism.

**Membership:**

- Legal Counsel (Chair)
- Compliance Officer
- Internal Auditor
- Independent Ethics Expert
- Community Representative

**Decision Rights:** Decisions related to ethical conduct, regulatory compliance, and transparency. Authority to investigate allegations of misconduct and recommend corrective actions.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Legal Counsel (Chair) has the deciding vote. Dissenting opinions are formally recorded.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of compliance with laws and regulations.
- Discussion of any ethical issues or concerns.
- Review of whistleblower reports.
- Review of contracts and procurement activities.
- Review of project transparency measures.

**Escalation Path:** Senior Management Team
### 4. Technical Advisory Group

**Rationale for Inclusion:** Provides expert technical advice on treatment methods, monitoring strategies, and environmental impact assessments, given the project's reliance on specialized knowledge and the need to ensure effective and environmentally sound practices.

**Responsibilities:**

- Advise on the selection of appropriate treatment methods.
- Review and approve monitoring strategies.
- Assess the environmental impact of project activities.
- Provide technical guidance on risk management and mitigation strategies.
- Evaluate the effectiveness of treatment methods.
- Recommend improvements to project processes and procedures.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Identify and recruit technical experts.
- Establish meeting schedule.
- Define reporting requirements to the Project Steering Committee.

**Membership:**

- Entomologist (Chair)
- Environmental Scientist
- Pest Control Specialist
- GIS Specialist
- Independent Arborist

**Decision Rights:** Recommendations on technical aspects of the project, including treatment methods, monitoring strategies, and environmental impact assessments. Recommendations are submitted to the Project Steering Committee for approval.

**Decision Mechanism:** Decisions made by consensus. In case of disagreement, the Entomologist (Chair) facilitates discussion to reach a mutually acceptable solution. Unresolved issues are escalated to the Project Steering Committee.

**Meeting Cadence:** Bi-monthly

**Typical Agenda Items:**

- Review of treatment methods and effectiveness.
- Review of monitoring data and trends.
- Discussion of environmental impact assessments.
- Discussion of technical challenges and potential solutions.
- Recommendations for improvements to project processes and procedures.

**Escalation Path:** Project Steering Committee