**Purpose:** business

**Purpose Detailed:** Large-scale environmental monitoring and remediation initiative addressing a significant public and ecological resource concern, involving resource management and public welfare infrastructure.

**Topic:** Environmental monitoring program for Roskilde Fjord