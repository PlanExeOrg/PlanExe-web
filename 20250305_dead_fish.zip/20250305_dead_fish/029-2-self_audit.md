Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 14 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 5 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The project focuses on environmental monitoring and remediation, which are within the bounds of known physics. No perpetual motion, FTL, reactionless/anti-gravity, or time travel is involved.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (pollution monitoring) + market (Roskilde Fjord) + tech/process (AI-driven remediation) + policy (data monetization) without independent evidence at comparable scale. There is no mention of precedent for this specific combination.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Each track must produce one authoritative source or a supervised pilot showing results vs a baseline. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Owner: Project Manager / Deliverable: Validation Report / Date: 2027-03-13


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (pollution monitoring) + market (Roskilde Fjord) + tech/process (AI-driven remediation) + policy (data monetization) without independent evidence at comparable scale. There is no mention of precedent for this specific combination.

**Mitigation**: Project Manager: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Each track must produce one authoritative source or a supervised pilot showing results vs a baseline. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. / Deliverable: Validation Report / Date: 2027-03-13


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies several risks (regulatory, technical, financial, environmental, social, etc.) and includes mitigation plans. However, it lacks explicit analysis of risk cascades. For example, "Regulatory & Permitting Delays" could lead to "Financial" issues.

**Mitigation**: Risk Management Consultant: Develop a risk cascade map illustrating how individual risks can trigger secondary risks, and update the risk register with controls and a review cadence. / Deliverable: Risk Cascade Map / Date: 2026-05-31


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions securing permits from Roskilde Municipality and the Danish EPA, with permitting taking 1-2 months, but lacks a detailed breakdown of required permits and their typical lead times.

**Mitigation**: Regulatory Compliance Specialist: Create a permit/approval matrix detailing each required permit, the issuing authority, typical lead time, and status. Rebuild the critical path with this data. / Deliverable: Permit Matrix / Date: 2026-05-31


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the funding plan is not defined. The plan mentions a budget of 5 million DKK but lacks details on funding sources, draw schedule, covenants, and runway length. There is no dated financing plan listing sources/status.

**Mitigation**: Financial Sustainability Planner: Develop a dated financing plan listing funding sources and their status (e.g., LOI/term sheet/closed), draw schedule, covenants, and a NO-GO on missed financing gates. / Deliverable: Financing Plan / Date: 2026-04-30


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget of $110,000 (DKK 760,000) conflicts with the scope. There are no vendor quotes or benchmarks. The budget is not normalized by area. The plan lacks evidence that the budget is scale-appropriate.

**Mitigation**: Financial Sustainability Planner: Obtain ≥3 vendor quotes for sensor deployment, lab analysis, and personnel costs. Normalize costs per area (fjord area). Adjust budget or de-scope. / Deliverable: Budget Justification / Date: 2026-04-30


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the timeline lacks sensitivity analysis. The plan presents a timeline with specific durations (e.g., "3 months sensor deployment") without providing a range, confidence interval, or discussing alternative scenarios.

**Mitigation**: Project Manager: Conduct a sensitivity analysis on the timeline, providing best-case, worst-case, and base-case scenarios for sensor deployment and data analysis setup. / Deliverable: Timeline Sensitivity Analysis / Date: 2026-04-30


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks essential engineering artifacts such as specifications, interface contracts, acceptance tests, and an integration plan for critical components. Their absence creates a significant risk of failure.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners and dates within 60 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "necessary permits from Roskilde Municipality and the Danish EPA" but lacks verifiable artifacts such as permit applications, approvals, or even a list of required permits.

**Mitigation**: Regulatory Compliance Specialist: Compile a list of all required permits and licenses, and include links to submitted applications and approval documents. / Deliverable: Permit Log / Date: 2026-04-30


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the abstract deliverable is "a pollution monitoring program". The plan lacks SMART acceptance criteria, including a KPI for data accuracy (e.g., 95% accuracy in pollutant measurements).

**Mitigation**: Project Manager: Define SMART criteria for the pollution monitoring program, including a KPI for data accuracy. / Deliverable: SMART Criteria / Date: 2026-04-30


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes a "killer application" dashboard with gamification. This feature does not directly support the core goals of establishing baseline data or identifying pollution sources. It adds complexity without clear benefit.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of the "killer application" dashboard, complete with a KPI, owner, and estimated cost, or move the feature to the project backlog. / Deliverable: Benefit Case / Date: 2026-04-30


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a Financial Sustainability Planner with expertise in carbon credits, data monetization, and impact investing. This role is critical for long-term funding and likely difficult to fill.

**Mitigation**: Project Manager: Validate the talent market for a Financial Sustainability Planner with expertise in carbon credits, data monetization, and impact investing. / Deliverable: Talent Market Assessment / Date: 2026-04-30


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions securing permits from Roskilde Municipality and the Danish EPA but lacks a regulatory matrix (authority, artifact, lead time, predecessors). Legality is unclear and required approvals are unmapped.

**Mitigation**: Regulatory Compliance Specialist: Develop a regulatory matrix detailing required permits, issuing authority, artifacts, lead times, and predecessors. Conduct a Fatal-Flaw Analysis. / Deliverable: Regulatory Matrix / Date: 2026-04-30


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions a "Funding and Sustainability Strategy" but lacks detail on long-term operational costs (sensor maintenance, data storage, personnel, software, replacements). This is a sustainability gap that can be addressed with planning.

**Mitigation**: Financial Sustainability Planner: Develop a detailed 5-10 year operational budget, including sensor maintenance, data storage, personnel, and software costs. / Deliverable: Operational Budget / Date: 2026-06-30


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan does not explicitly address zoning/land-use restrictions, occupancy/egress, fire load, structural limits, or noise constraints for sensor deployment and laboratory facilities. The plan mentions "access to sampling locations" but lacks detail.

**Mitigation**: Engineering Team: Conduct a fatal-flaw screen with local authorities to identify zoning/land-use, occupancy/egress, fire load, structural limits, and noise constraints for sensor deployment and lab facilities. / Deliverable: Constraint Report / Date: 2026-05-31


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions redundancy in sensor deployment but lacks evidence of contracts/SLAs with vendors or tested failover procedures. The "Trade-Off / Risk" section of the Sensor Deployment Strategy mentions "sensor malfunction and the need for redundancy," but there are no details.

**Mitigation**: Engineering Team: Secure SLAs with sensor vendors guaranteeing uptime and replacement timelines. Develop and test a failover plan for sensor malfunctions, including backup sensors and data recovery procedures. / Deliverable: SLA documentation and Failover Test Report / Date: 2026-06-30


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the Finance Department is incentivized by budget adherence, while the Environmental Project Manager is incentivized by comprehensive monitoring, creating a conflict over sensor deployment density. The plan does not address this conflict.

**Mitigation**: Project Manager and Finance Department: Create a shared OKR focused on maximizing data insights per DKK spent, aligning both stakeholders on efficient resource utilization. / Deliverable: Shared OKR / Date: 2026-04-30


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board. Define thresholds for re-planning or stopping the project. / Deliverable: Review Cadence and Change Control Process / Date: 2026-04-30


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies risks but lacks a cross-impact analysis. For example, "Regulatory & Permitting Delays" could trigger "Financial" issues, leading to "Lack of Long-Term Funding," creating a multi-domain failure.

**Mitigation**: Risk Management Consultant: Develop a risk interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. / Deliverable: Risk Assessment / Date: 2026-05-31