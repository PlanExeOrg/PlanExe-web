## Positive Constraints

- Launch a pollution monitoring program
- Location: Roskilde Fjord in Roskilde, Denmark
- Respond to alarming fish die-offs
- Track oxygen levels in real time
- Track nutrients in real time
- Track microplastics in real time
- Track pH in real time
- Track nitrates in real time
- Track phosphates in real time
- Project start ASAP
