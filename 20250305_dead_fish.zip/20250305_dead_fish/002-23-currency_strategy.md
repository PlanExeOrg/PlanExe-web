This plan involves money.

## Currencies

- **DKK:** Local currency for expenses related to the pollution monitoring program in Roskilde, Denmark.
- **EUR:** For potential international transactions, collaboration with European research institutions, or procurement of equipment from European suppliers.

**Primary currency:** DKK

**Currency strategy:** The Danish Krone (DKK) will be used for all local transactions. For international transactions, monitor exchange rates and consider hedging strategies if significant fluctuations occur. Using cards with no foreign transaction fees can also help manage costs.