**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds financial limit of 500,000 DKK for Core Project Team, requiring strategic oversight.
Negative Consequences: Potential budget overrun and project delays.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Mitigation Plan
Rationale: Strategic impact on project objectives and timeline, requiring higher-level intervention.
Negative Consequences: Project failure, environmental damage, or legal liabilities.

**PMO Deadlock on Sensor Deployment Strategy**
Escalation Level: Technical Advisory Group
Approval Process: Technical Advisory Group provides a recommendation to the Project Steering Committee, which makes the final decision.
Rationale: Requires independent technical expertise to resolve conflicting opinions and ensure optimal sensor deployment.
Negative Consequences: Inefficient data collection and inaccurate pollution assessment.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval
Rationale: Significant impact on project objectives, budget, and timeline, requiring strategic alignment.
Negative Consequences: Project delays, budget overruns, and failure to meet original objectives.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Senior Management / Executive Leadership
Rationale: Needs independent review and potential corrective action to maintain ethical standards and regulatory compliance.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust.

**Conflict between Stakeholder Engagement Group and Core Project Team**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee mediation and decision based on project goals and stakeholder needs.
Rationale: Ensures alignment between community expectations and project execution.
Negative Consequences: Reduced community support, project delays, and potential protests.