### 1. Tracking Critical Success Factor: Sensor Deployment and Data Acquisition Uptime
**Monitoring Tools/Platforms:**

  - Project Management Software Dashboard (Tracking Milestone adherence)
  - Telemetry System Health Logs (Uptime percentage per node)
  - CPET Weekly Progress Reports

**Frequency:** Daily (Uptime); Weekly (Summary)

**Responsible Role:** Core Project Execution Team (CPET)

**Adaptation Process:** CPET resolves operational downtimes immediately via internal protocols (Risk 2 mitigation). If continuous uptime for the central uplink drops below 90% over a week, the Project Manager escalates for immediate PSC review to authorize contingency activation (e.g., activating secondary cellular backup/re-routing).

**Adaptation Trigger:** Overall system uptime falls below 95% for 48 consecutive hours, OR the first instance of a central uplink outage lasting longer than 12 hours (Risk 2).

### 2. Monitoring Critical Lever: Internalized Calibration Fidelity (Risk 3 Mitigation)
**Monitoring Tools/Platforms:**

  - Bi-weekly Calibration Log Sheets (signed by Lead Field Technician)
  - CDIAG Quarterly Audit Reports
  - Shadow Validation Correlation Reports (comparing internal vs. external labs)

**Frequency:** Bi-weekly (Data Collection); Quarterly (Audit/Validation)

**Responsible Role:** Compliance and Data Integrity Assurance Group (CDIAG)

**Adaptation Process:** If the CDIAG audit finds correlation less than 95% with reference labs for two consecutive quarters, the CDIAG immediately halts data submission for adjudication suitability and triggers CPET to initiate the contractor services fallback (Risk 3 mitigation plan).

**Adaptation Trigger:** CDIAG audit reveals internal calibration correlation dropping below 95% against external benchmarks for two consecutive quarters, OR Lead Field Technician reports inability to fill a vacancy within 14 days.

### 3. Tracking Critical Lever: Dynamic Deployment Execution (Risk 4 Management)
**Monitoring Tools/Platforms:**

  - Vessel Charter Logs and GPS Tracking
  - CPET Relocation Checklist Status
  - Monthly Sensor Location Metadata Updates

**Frequency:** Monthly (Post-relocation completion)

**Responsible Role:** Core Project Execution Team (CPET)

**Adaptation Process:** If the relocation schedule slips by more than 7 days past the scheduled date, the Project Manager assesses the cause. If due to external resource delays (vessel charter), they authorize incentive payment or escalate to PSC to approve activating contingency budget for ad-hoc chartering.

**Adaptation Trigger:** Failure to complete the planned monthly dynamic sensor relocation within the first 10 days of the subsequent month, OR receiving notice of excessive wear-and-tear requiring unplanned maintenance exceeding 20,000 DKK.

### 4. Monitoring Critical Lever: Regulatory Engagement & Data Acceptance Roadmap Progress (Risk 5 Mitigation)
**Monitoring Tools/Platforms:**

  - Regulatory Engagement Tracker (Miljøstyrelsen contact log)
  - CDIAG Regulatory Acceptance Roadmap Status Report
  - SEC Meeting Minutes (Workshop outcomes)

**Frequency:** Monthly

**Responsible Role:** Stakeholder Engagement & Communication Board (SECB) / CDIAG

**Adaptation Process:** If the Regulatory Engagement Liaison reports resistance from authorities delaying provisional acceptance of O2/Nutrient data, the SECB and PSC convene an emergency session to redirect messaging strategy (Risk 5 mitigation), focusing future engagement solely on data defensibility metrics.

**Adaptation Trigger:** Regulatory body fails to confirm acceptance pathway for O2/Nutrient data within 3 months of the first workshop, OR external stakeholders attempt to mandate microplastics inclusion prior to planned Phase Two introduction.

### 5. Monitoring Strategic Constraint: Data Integrity vs. Operational Cost (Risk 7 Monitoring)
**Monitoring Tools/Platforms:**

  - Quarterly Budget Reconciliations (DKK comparison vs. Baseline Opex)
  - Staff Utilization Reports (tracking time allocation for specialized staff)
  - PSC Financial Review Decks

**Frequency:** Quarterly

**Responsible Role:** Project Steering Committee (PSC)

**Adaptation Process:** If Opex consistently tracks 15% or more over the projected rate for two consecutive quarters (Risk 7 threshold), the PSC initiates the pre-defined Staff Burn-Down Schedule, immediately reducing specialized staff requirements and transitioning calibration to a modified monthly cadence, despite the fidelity trade-off.

**Adaptation Trigger:** Quarterly operational expenditure tracking shows a sustained 15% variance above the baseline operating budget projections.

### 6. Monitoring Stakeholder Trust & Communication Alignment (Risk 8 Management)
**Monitoring Tools/Platforms:**

  - Public Sentiment Tracking Dashboard (Tracking sentiment trends)
  - SECB Advisory Committee Input Log (48h fulfillment check)
  - CDIAG Data Provenance Tags (Checking unvalidated data release vs. security hold)

**Frequency:** Weekly

**Responsible Role:** Stakeholder Engagement & Communication Board (SECB)

**Adaptation Process:** If public sentiment deteriorates (negative score threshold breach) or if the 48-hour input log compliance fails, the SECB immediately adjusts public messaging priority, emphasizing the 'Acute Emergency Response' focus and communicating the roadmap for microplastic inclusion.

**Adaptation Trigger:** Public sentiment score dips below threshold X for two consecutive weeks, OR the SECB fails to log 48-hour processing of fishing sector feedback for three consecutive weeks.