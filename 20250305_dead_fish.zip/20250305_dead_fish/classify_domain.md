**Primary domain:** Environmental Monitoring

**Secondary domains:** Water Quality Analysis, Marine Biology, Hydrology

**Rationale:** Environmental Monitoring is the primary outcome, as the project's main success criterion is launching and operating this program. Ecotoxicology is a strong secondary factor related to the cause (fish die-offs) but the *program itself* defines success here.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Environmental Monitoring | 5 | 5 | outcome | The core goal is launching and operating an environmental monitoring program. |
| Ecotoxicology | 5 | 4 | outcome | Understanding toxic effects on aquatic organisms is key due to the fish die-offs. |
| Data Telemetry | 4 | 5 | method | Real-time tracking requires expertise in collecting and transmitting sensor data. |
| Sensor Technology | 4 | 5 | method | Real-time tracking requires selecting and deploying appropriate sensing instruments. |
| Water Quality Analysis | 4 | 4 | method | Tracking specific metrics like oxygen, pH, nitrates, and phosphates requires analytical methods. |
| Hydrology | 4 | 4 | method | Hydrology informs the water body dynamics critical for interpreting pollution transport. |
| Environmental Regulation | 4 | 4 | constraint | Compliance with Danish environmental laws will constrain monitoring design and reporting. |
| Marine Biology | 4 | 3 | stakeholder | Fish die-offs indicate a critical ecological failure necessitating biological expertise. |
| Risk Communication | 3 | 4 | market | Communicating findings about fish die-offs impacts public and governmental stakeholders. |