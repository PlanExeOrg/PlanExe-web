**Request for Capital Expenditure Exceeding 250,000 DKK for Hardware or SLA Renewal**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Simple majority vote (Chair's vote counts as 1.5); Chair is Project Director.
Rationale: Exceeds the established financial limit for operational decisions handled by the CPET (250,000 DKK). Such spending affects the overall capital budget allocated for the 'Pioneer's Edge' technology.
Negative Consequences: Budget overrun in contingency or Opex, potentially leading to degraded telemetry SLA or delayed acquisition of specialized calibration equipment needed for data fidelity.

**Technical Deadlock within CPET on Priority of Sensor vs. Telemetry Maintenance (e.g., high demand on one technician covering both sensor maintenance and redundant radio troubleshooting)**
Escalation Level: Core Project Execution Team (CPET)
Approval Process: Default adoption of the Lead Sensor Engineer's recommendation.
Rationale: The CPET charter specifies that in case of technical deadlock, the Lead Sensor Engineer's recommendation is adopted by default. This requires formal team acknowledgement rather than immediate escalation if the tradeoff is purely technical.
Negative Consequences: Sub-optimal resource allocation leading to increased operational downtime in the neglected area, potentially breaching the 24-month telemetry SLA or missing calibration windows.

**External Regulator (Miljøstyrelsen) Demands Immediate Submission of Microplastics Data (Conflict with Phased Roadmap)**
Escalation Level: Compliance and Data Integrity Assurance Group (CDIAG)
Approval Process: Unanimous agreement required for regulatory submission sign-off by CDIAG; if deadlock occurs, escalate to PSC Chair for arbitration.
Rationale: This concerns the core integrity of the Regulatory Acceptance Roadmap and data provenance tagging (Decision 12). The CDIAG must ensure any submitted data is appropriately qualified, regardless of external pressure.
Negative Consequences: Submitting unvalidated microplastics data risks damaging long-term credibility (Risk 8) or triggering punitive, non-optimal mandates from regulators based on incomplete insights (Risk 5).

**Proposed Change to Sensor Suite Strategy Requiring Adoption of Commercial Off-the-Shelf Sensors (Downgrade from Custom Prototyping)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Consensus preferred; if not achievable, simple majority vote (Chair's vote counts as 1.5).
Rationale: This constitutes a major scope change impacting the Sensor Suite Selection Strategy, which is a 'Key Strategic Decision.' It fundamentally alters the 'Pioneer's Edge' definition of data fidelity.
Negative Consequences: Loss of data fidelity required for adjudication, failure to meet primary goal criteria, and potential long-term project failure if remediation advice is insufficient.

**Conflict in Stakeholder Engagement Regarding Public Dashboard Content (e.g., SECB wants to immediately show raw O2 dips, but CDIAG insists on a 24-hour QA hold)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Escalation to PSC Chair for final organizational decree, as conflicts involving messaging that contradicts PSC strategic direction require high-level mediation.
Rationale: This conflict directly pits the high-priority goal of aggressive public risk communication (SECB) against mandatory data integrity checks (CDIAG), requiring PSC intervention to align with strategic priorities outlined in Decision 3 and Decision 12.
Negative Consequences: If SECB overrules CDIAG, erroneous data could be published, eroding trust. If CDIAG imposes delay, political friction increases, risking stakeholder buy-in (Risk 8).