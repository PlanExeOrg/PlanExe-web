**Verdict:** 🟡 ALLOW WITH SAFETY FRAMING

**Rationale:** Planning an environmental monitoring program is generally safe, but advice must remain conceptual and avoid specific operational instructions related to data collection or regulatory compliance.

### Violation Details

| Detail                | Value |
|-----------------------|-------|
| **Capability Uplift**     | No |