This plan implies one or more physical locations.

## Requirements for physical locations

- Access to Roskilde Fjord
- Proximity to water for sensor deployment
- Laboratory facilities for water sample analysis
- Accessibility for monitoring and maintenance

## Location 1
Denmark

Roskilde Fjord, Roskilde

Specific locations along Roskilde Fjord will be determined based on sensor deployment strategy.

**Rationale**: The plan explicitly focuses on monitoring pollution in Roskilde Fjord, making it the primary location.

## Location 2
Denmark

Roskilde

Roskilde Harbor

**Rationale**: Roskilde Harbor provides direct access to the fjord and can serve as a base for monitoring activities and sample collection.

## Location 3
Denmark

Roskilde

A local laboratory in Roskilde

**Rationale**: A local laboratory in Roskilde would be ideal for analyzing water samples collected from the fjord, ensuring timely results.

## Location 4
Denmark

Copenhagen

University of Copenhagen or similar research institution

**Rationale**: Leveraging the expertise and resources of a major research institution in Copenhagen can provide advanced analytical capabilities and support for the monitoring program.

## Location Summary
The primary location is Roskilde Fjord, supplemented by Roskilde Harbor for access, a local laboratory in Roskilde for sample analysis, and the University of Copenhagen for advanced research support.