### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** Given the 'Pioneer's Edge' strategy, high complexity, critical public outcome (fish die-offs), and management of high-stakes strategic trade-offs (Data Integrity vs. Cost/Coverage), a high-level oversight body is mandatory to maintain strategic alignment and manage external political interfaces.

**Responsibilities:**

- Approve major scope changes, especially those impacting the five 'Key Strategic Decisions' (e.g., Sensor Suite, Telemetry Architecture).
- Review and approve expenditure exceeding 250,000 DKK per decision/quarter.
- Oversee management of Critical Risks 1, 2, and 3 (Sensor Failure, Uplink SPOF, Staffing).
- Sign-off on the formal Regulatory Acceptance Roadmap progression.
- Resolve major conflicts escalated from the Operational Management Team.

**Initial Setup Actions:**

- Finalize and approve the PSC Charter, defining member accountability and decision thresholds.
- Establish baseline thresholds for financial approval (e.g., >250,000 DKK capital or >500,000 DKK Opex variance).
- Meet with key external regulators (Miljøstyrelsen) to establish initial engagement expectations.

**Membership:**

- Project Director (Chair)
- Senior Executive Sponsor (Organization Head Equivalent)
- Head of Legal/Compliance (Internal Assurance)
- Lead Scientist/Technical Architect (Non-voting advisory)
- Designated Finance Liaison (For budget review)

**Decision Rights:** All strategic directional changes, all budget approvals exceeding 250,000 DKK, and all material risk acceptance decisions affecting long-term data fidelity or project timeline > 1 month.

**Decision Mechanism:** Consensus preferred. If consensus cannot be reached, a simple majority vote (Chair's vote counts as 1.5) is used. Conflict resolution on policy: Escalation to Executive Sponsor.

**Meeting Cadence:** Bi-weekly for the first 3 months, then Monthly.

**Typical Agenda Items:**

- Review of overall Project Health (RAG status)
- Approval of Capital Expenditure Requests (>250k DKK)
- Status of Regulatory Acceptance Roadmap progression
- Review of strategic risk profile and escalation approvals

**Escalation Path:** Unresolved issues are escalated directly to the Executive Sponsor for final organizational decree, especially conflicts involving budget overruns exceeding 20% of the allocated reserve.
### 2. Core Project Execution Team (CPET)

**Rationale for Inclusion:** This body manages the high operational complexity inherent in the 'Pioneer's Edge' strategy: dynamic mobile deployment, complex sensor integration, and internalized, high-frequency calibration ($1.5M budget, Risk 4, Risk 3). It bridges technical execution with strategic mandates.

**Responsibilities:**

- Day-to-day management of hardware integration (Sensor Suite Selection) and infrastructure build-out (Telemetry Mandate).
- Execution and scheduling of dynamic monthly sensor relocations (Spatial Density Mgmt).
- Management of the internal calibration program and competency tracking (Decision 5 execution).
- Operational risk management (Risks 1, 4, and 6 implementation oversight).
- Preparing all technical documentation for PSC review and regulatory submission.

**Initial Setup Actions:**

- Finalize the detailed hardware procurement schedule aligned with Day 90 competency target for calibration staff.
- Establish operational checklists for dynamic relocation (vessel charter integration).
- Define the precise data flow pipeline from sensor to cloud ingestion system.

**Membership:**

- Project Manager (Chair)
- Lead Sensor Engineer (Technical Head)
- Data Telemetry Specialist
- Lead Field Technician (Rep. Internal Calibration Team)
- Vessel Charter/Logistics Coordinator

**Decision Rights:** All operational decisions below the 250,000 DKK spend threshold. Decisions concerning day-to-day scheduling, minor technical adjustments to telemetry configuration, and prioritization of maintenance tasks.

**Decision Mechanism:** Simple majority vote among core members. In case of technical deadlock, the Lead Sensor Engineer's recommendation is adopted by default.

**Meeting Cadence:** Daily stand-ups (initial 6 weeks); Weekly operational review thereafter.

**Typical Agenda Items:**

- Completion status of prototype validation gates (Risk 1 tracking)
- Status of sensor calibration logs and technician competency verification
- Review of telemetry link stability and resolution of localization failures (Risk 2 tactical monitoring)
- Planning and scheduling for the next dynamic sensor relocation (Risk 4 management)

**Escalation Path:** Unresolved technical blockages or budget variance requests exceeding 50,000 DKK are escalated immediately to the Project Steering Committee (PSC).
### 3. Compliance and Data Integrity Assurance Group (CDIAG)

**Rationale for Inclusion:** The project heavily relies on 'adjudication-ready' data and involves proactive engagement with regulatory bodies (Decision 3), requiring strict oversight of calibration quality, data provenance, and adherence to Danish regulations like GDPR. This body provides the necessary dedicated assurance function separate from project execution.

**Responsibilities:**

- Independent validation of the Regulatory Acceptance Roadmap fidelity requirements.
- Quarterly audit of internalized calibration procedures and wet chemistry logs (Risk 3 mitigation).
- Ensuring compliance with the 30-day reporting mandate for O2/Nutrient breaches.
- Oversight of data provenance tagging to legally support differential data release statuses (Decision 12).
- Conflict resolution concerning data release formats for public entities.

**Initial Setup Actions:**

- Formalize the process flow for pre-submission data verification checks (Assumption 4).
- Establish the precise cadence and format for auditing consumables usage against calibration logs.
- Confirm external lab readiness for shadow validation/reconciliation exercises.

**Membership:**

- Internal Audit Manager (Chair, Independent)
- Lead Compliance Officer (Legal/Regulatory Expert)
- External Quality Assurance Consultant (Independent/External)
- Data Telemetry Specialist (Ex-officio, for data provenance verification)

**Decision Rights:** Ability to halt the submission of any data package to regulatory bodies if fidelity standards are not demonstrably met. Authority to mandate non-critical data releases based on the Regulatory Engagement Timeline.

**Decision Mechanism:** Unanimous agreement required for regulatory submission sign-off. If deadlock occurs, the matter is immediately escalated to the PSC Chair for arbitration.

**Meeting Cadence:** Monthly, or on-demand if a regulatory threshold breach incident occurs.

**Typical Agenda Items:**

- Review of latest Regulatory Acceptance Roadmap progress report
- Audit findings from internalized calibration process logs
- Verification of data provenance tagging across live telemetry
- Assessment of recent compliance metrics vs. 30-day reporting targets

**Escalation Path:** Failure to agree on official data submission timelines or data integrity status is escalated directly to the Project Steering Committee (PSC) for immediate mediation with external regulatory bodies.
### 4. Stakeholder Engagement & Communication Board (SECB)

**Rationale for Inclusion:** Given the High justification for early and continuous stakeholder engagement (Decision 3) and the need to manage political friction from deferring microplastics tracking (Risk 8), a dedicated governance body is needed to align the proactive communication strategy with operational realities.

**Responsibilities:**

- Coordinate the 'Public Risk Communication Cadence' (Decision 6) and manage the public dashboard integrity (tagging data status correctly).
- Manage the input/output for the joint advisory committee, ensuring fishing sector anecdotal data is processed within the 48-hour mandate (Assumption 7).
- Develop and approve messaging regarding the phased data roadmap (Risk 5 & 8 mitigation).
- Liaise outputs between the PSC (strategic position) and CPET (operational reality).

**Initial Setup Actions:**

- Establish the Terms of Reference for the joint advisory committee, including the 48-hour input logging mechanism.
- Finalize the template and dissemination schedule for the initial informal workshop series (Decision 3, Choice 1).
- Define the content governance for the public dashboard, ensuring visual data status tags are clear.

**Membership:**

- Project Communication Lead (Chair)
- Regulatory Liaison Officer
- Lead Scientist/Technical Architect (Advisory)
- Representative from Roskilde Municipal Authorities (Stakeholder Link)
- Representative from Commercial Fishing Sector (Advisory/User input)

**Decision Rights:** Final approval on all public messaging, dashboard visualizations, and the content/timing of regulatory engagement workshops. Authority over the speed of public data release (Decision 12 criteria).

**Decision Mechanism:** Majority vote, but any decision impacting the messaging vetted by the Regulatory Liaison requires absolute consensus among the three internal project roles (Chair, Regulatory Liaison, Tech Lead).

**Meeting Cadence:** Weekly.

**Typical Agenda Items:**

- Review of recent public sentiment and media analysis
- Triage and prioritization of anecdotal feedback received from fishing sector (Assumption 7)
- Review of data presentation alignment with current regulatory status (CDIAG certification)
- Planning for next Regulatory Engagement Workshop

**Escalation Path:** Conflict over messaging that directly contradicts PSC strategic direction or that threatens to violate the 30-day formal reporting window (Assumption 4) is escalated immediately to the Project Steering Committee (PSC).