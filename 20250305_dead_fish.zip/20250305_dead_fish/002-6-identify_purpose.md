**Purpose:** business

**Purpose Detailed:** Environmental monitoring and management to address fish die-offs and improve water quality.

**Topic:** Pollution monitoring program for Roskilde Fjord