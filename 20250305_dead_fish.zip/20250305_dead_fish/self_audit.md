Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 19 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 0 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This plan outlines a standard environmental monitoring program that relies on established chemical and physical sensing technologies, which do not contradict any known laws of physics. It is an environmental data collection and analysis project.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan embraces the 'Pioneer's Edge' strategy, which hinges on a novel, high-stakes combination of customized sensor prototyping, internalized high-fidelity calibration, and dynamic mobile deployment, all lacking independent, comparable evidence.

**Mitigation**: Project Management: Initiate parallel validation tracks immediately for hardware fidelity, telemetry resilience, and regulatory acceptance, defining NO-GO gates within 90 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because several strategic concepts ('Pioneer's Edge', 'adjudication-ready data', dynamic deployment) are driving the plan but lack defined MoAs, owners, or measurable outcomes as required by the prompt's rubric.

**Mitigation**: Project Management: Assign owners to produce one-pagers defining MoA, success metrics, and decision hooks for 'Pioneer's Edge' and 'Adjudication-Ready Data' within 45 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the analysis reveals the chosen 'Pioneer's Edge' strategy inherently exposes the project to multiple high-severity second-order risks, including critical hardware failure (Risk 1), catastrophic single point of failure in telemetry (Risk 2), and staffing collapse for essential calibration (Risk 3). The plan acknowledges these risks but their explicit cascade consequences (e.g., staff failure → loss of fidelity → regulatory challenge) are not systematically mapped with associated control dates.

**Mitigation**: Risk Management Team: Compile the documented critical failure modes (FM1-FM9) into a master risk register, assigning cross-functional owners and mandatory, dated mitigation confirmation targets by Day 60.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the chosen 'Pioneer's Edge' strategy explicitly selects decentralized RF mesh/satellite uplink (Decision 2) and dynamic relocation (Decision 4), which expert review identified as creating a critical SPOF (Risk 2) and unknown power demands (Missing Assumption 2); these untested high-risk architectural choices violate basic resilience standards, irrespective of generic 'buffer.'

**Mitigation**: Telemetry & Network Architect: Immediately redesign the network to ensure dual-path backhaul (Satellite/Cellular). Execute the 75,000 DKK procurement for backup hardware by Day 30.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not provide any committed funding sources, required runway calculation, or defined financing gates/covenants, instead opting for high-risk technological superiority ('Pioneer's Edge').

**Mitigation**: Project & Financial Control Steward: Deliver a dated financing plan listing secured sources, draw schedules, and covenants, establishing NO-GO gates for missed financing deadlines within 60 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan commits to a 'Pioneer's Edge' strategy, which implies high capital expenditure but provides no supporting numerical normalization or benchmark comparison to substantiate the feasibility of the 1,500,000 DKK hardware budget against the scale required.

**Mitigation**: Project & Financial Control Steward: Benchmark the 1.5M DKK CapEx against 3 comparable fjord monitoring systems, normalize the cost per sensor ($75,000 DKK/unit) against procurement quotes, and adjust scope if external bids exceed 90,000 DKK/unit within 60 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies exclusively on single-point projections for key success metrics, exemplified by the goal: 'achieving formal regulatory sign-off... within 9 months' (Review 6 KPI 1) and 'initial deployment... within 4 months' (Goal Statement), without providing any scenario analysis for these critical timeframes.

**Mitigation**: Project Sponsor: Direct the Regulatory Liaison & Financial Steward to deliver a full Best/Worst/Base-case projection analysis for the Month 9 fidelity sign-off milestone within 60 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Pioneer's Edge' strategy requires custom hardware, internalized calibration specialization, and dynamic deployment, yet the plan document omits critical artifacts like technical engineering specs, interface contracts, and integration plans for these build-critical components.

**Mitigation**: Marine Systems Engineer & Telemetry Architect: Deliver preliminary interface contracts and integration maps for the custom sensor-to-RF mesh hardware bridge within 60 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because critical claims regarding regulatory acceptance of novel data are missing. The plan omits the formal audit pathway from Miljøstyrelsen needed for 'adjudication-ready' status for custom sensors (Missing Assumption 1).

**Mitigation**: Regulatory Liaison & Engagement Manager: Schedule initial meeting with Miljøstyrelsen by 2026-07-05 to initiate the 'Regulatory Acceptance Roadmap' and define audit criteria.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because Decision 11, Operational Handover Model, is abstract. It lacks specific, verifiable qualities for a long-term stewardship strategy beyond 'rapidly transition' or 'retain control.'

**Mitigation**: Project & Financial Control Steward: Define SMART criteria for handover, including a KPI for local agency competency score (e.g., 85% on technical audit) within 90 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because Decision 9 prioritizes easy-to-measure variables (O2/Nutrients) by consciously deferring complex microplastic tracking, creating an immediate scientific knowledge gap that conflicts with the project's stated relevance to ecological collapse.

**Mitigation**: Regulatory Liaison & Engagement Manager: Formally document and secure provisional approval for the microplastics deferral roadmap with Miljøstyrelsen within 60 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Pioneer's Edge' necessitates the **Environmental Calibration Specialist (Wet Chemistry)** role (Decision 5) to internalize bi-weekly validation, which is mission-critical for 'adjudication-ready' data. This role demands scarce, specialized expertise, making recruitment difficult (Risk 3).

**Mitigation**: Environmental Calibration Specialist (Lead): Secure a binding 'Shadow Contract' with an external lab defining service availability starting Day 30, irrespective of internal hiring success, within 30 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on adherence to Danish environmental law (Miljøstyrelsen) but Missing Assumption 1 reveals the formal audit pathway for novel custom sensor data acceptance is unmapped, creating a showstopper.

**Mitigation**: Regulatory Liaison & Engagement Manager: Schedule initial meeting with Miljøstyrelsen by 2026-07-05 to initiate the 'Regulatory Acceptance Roadmap' and define audit criteria.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the analysis identified critical failure modes (FM2, FM7) directly tied to the high fixed operational costs of the 'Pioneer's Edge' path: high staff salaries and redundant telemetry services that risk a 20–30% Opex overrun post-Year 2.

**Mitigation**: Project & Financial Control Steward: Finalize the 'Staff Burn-Down Schedule' policy that defines data stability triggers for reducing FTE calibration staff to retainer status by Month 18.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the chosen 'Pioneer's Edge' strategy mandates mobile deployment using decentralized nodes (Decision 4) which depends on power sufficiency that is explicitly unverified under biofouling conditions (Missing Assumption 2).

**Mitigation**: Telemetry & Network Architect: Deliver a validated power budget model factoring in biofouling degradation, confirming >45 days operational life for mobile nodes by Day 60.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the chosen centralized telemetry architecture, utilizing a single solar-powered satellite uplink hub, represents a critical single point of failure (FM2), directly contradicting the required resilience standard for high-stakes data.

**Mitigation**: Telemetry & Network Architect: Redesign the network to include a geographically diverse, secondary cellular backhaul link and procure necessary hardware by Day 30.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because Finance (budget adherence) conflicts with R&D (long-term innovation/custom sensor development) over experimental spending headroom, as shown by Risk 7 concerning high Opex from the Pioneer's Edge strategy.

**Mitigation**: Project & Financial Control Steward: Develop and finalize a Staff Burn-Down Schedule policy defining criteria to transition specialized calibration FTEs to retainer status post-stabilization within 90 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks explicit mechanisms for ongoing performance review: KPIs are mentioned conceptually ('public sentiment scores,' 'analyst time allocation') but are not defined with threshold values or ownership for review cadence.

**Mitigation**: Project & Financial Control Steward: Define and document KPI thresholds (e.g., 95% NAU, R-squared > 0.95) and establish a Change Control Board chaired monthly by the Project Sponsor within 45 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because multiple Critical risks (e.g., FM3 Staffing Failure, FM7 Opex Overrun) are coupled to the high fixed cost of internal calibration, which is an untested assumption/staffing commitment.

**Mitigation**: Environmental Calibration Specialist (Lead): Secure a binding 'Shadow Contract' with an external lab defining service availability starting Day 30, irrespective of internal hiring success, within 30 days.