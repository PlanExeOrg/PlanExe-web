### 1. Project Kickoff, securing core mandates, and confirming the foundational architecture (based on Pioneer's Edge strategy).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Project Charter Finalized
- Initial Capital Approval for 1.5M DKK and 75k DKK redundancy fund released
- Nomination of Project Director

**Dependencies:**

- Strategic Decisions Finalized (Pioneer's Edge Selected)

### 2. Project Director drafts initial Terms of Reference (ToR) for Project Steering Committee (PSC) based on approved template.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- PSC Draft ToR v0.1
- Initial Membership Invitation List Drafted

**Dependencies:**

- Project Kickoff Complete

### 3. Project Manager drafts initial Terms of Reference (ToR) and operational checklists for Core Project Execution Team (CPET).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- CPET Draft ToR v0.1
- Initial hardware procurement schedule v1.0 (aligned with Sensor Suite Strategy)

**Dependencies:**

- Project Kickoff Complete

### 4. Internal Legal/Compliance drafts initial ToR for Compliance and Data Integrity Assurance Group (CDIAG) and Stakeholder Engagement & Communication Board (SECB).

**Responsible Body/Role:** Head of Legal/Compliance

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- CDIAG Draft ToR v0.1
- SECB Draft ToR v0.1
- Draft Regulatory Liaison Plan

**Dependencies:**

- Project Kickoff Complete

### 5. Project Sponsor formally approves all Draft Governance Body ToRs and issues formal appointment letters for all defined committee memberships (PSC, CPET, CDIAG, SECB).

**Responsible Body/Role:** Senior Executive Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Formal PSC Charter Approved
- All Committee Members Officially Appointed
- Final Governance Structure Documentation

**Dependencies:**

- PSC Draft ToR v0.1
- CPET Draft ToR v0.1
- CDIAG Draft ToR v0.1
- SECB Draft ToR v0.1

### 6. CPET finalizes procurement contracts for custom sensor hardware (20 modules) and secures 24-month Telemetry SLA, prioritizing Risk 2 mitigation (backup modem/battery).

**Responsible Body/Role:** CPET (Chaired by Project Manager)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Signed Sensor Procurement Contract
- Signed 24-Month Telemetry SLA
- Redundancy hardware (75k DKK value) confirmed on order

**Dependencies:**

- Official Budget Approval (Step 1)
- PSC Appointment Confirmation

### 7. CPET initiates aggressive recruitment of two specialized calibration staff, targeting Day 90 competency milestone.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4 - Ongoing

**Key Outputs/Deliverables:**

- Recruitment Campaign Launched
- Interview Schedule Established

**Dependencies:**

- PSC Appointment Confirmation

### 8. Project Team engages Danish environmental authorities to schedule the first informal data-sharing workshop (per Decision 3).

**Responsible Body/Role:** Regulatory Liaison Officer (via SECB)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Formal request sent to Miljøstyrelsen
- Initial workshop agenda drafted focusing on O2/Nutrient trends

**Dependencies:**

- PSC Appointment Confirmation

### 9. CDIAG finalizes the Regulatory Acceptance Roadmap, defining shadow validation criteria for custom sensor fidelity against external benchmarks.

**Responsible Body/Role:** CDIAG

**Suggested Timeframe:** Project Month 1

**Key Outputs/Deliverables:**

- Regulatory Acceptance Roadmap v1.0 Approved by CDIAG
- Schedule for external lab shadow testing initiated

**Dependencies:**

- Signed Sensor Procurement Contract
- PSC Appointment Confirmation

### 10. CPET finalizes dynamic deployment plan, including securing long-term vessel charter logistics (Risk 4 mitigation).

**Responsible Body/Role:** CPET

**Suggested Timeframe:** Project Month 2

**Key Outputs/Deliverables:**

- Vessel Charter Agreement Signed (12 Months)
- Initial Site Survey and CTD Profiling Completed (Input to Density Strategy)

**Dependencies:**

- Initial Capital Approval

### 11. Hold initial mandatory kick-off meeting for the Project Steering Committee (PSC) to review budget burn rate and confirm alignment on initial CPET actions.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Month 1

**Key Outputs/Deliverables:**

- PSC Meeting Minutes 001
- Conflict resolution policy confirmed by majority vote

**Dependencies:**

- PSC ToR Approved and Members Confirmed

### 12. Hold initial mandatory kick-off meeting for the Core Project Execution Team (CPET) to assign hardware integration tasks and finalize operational checklists.

**Responsible Body/Role:** Core Project Execution Team (CPET)

**Suggested Timeframe:** Project Month 1

**Key Outputs/Deliverables:**

- CPET Meeting Minutes 001
- Go/No-Go decision point established for procurement milestones

**Dependencies:**

- CPET ToR Approved and Members Confirmed

### 13. Hold initial mandatory kick-off meeting for the Compliance and Data Integrity Assurance Group (CDIAG) to ratify the data provenance tagging standard.

**Responsible Body/Role:** Compliance and Data Integrity Assurance Group (CDIAG)

**Suggested Timeframe:** Project Month 1

**Key Outputs/Deliverables:**

- CDIAG Meeting Minutes 001
- Data Provenance Tagging Standard Document

**Dependencies:**

- CDIAG ToR Approved and Members Confirmed

### 14. Hold initial mandatory kick-off meeting for the Stakeholder Engagement & Communication Board (SECB) to define public messaging guardrails based on phased data roadmap (Risk 8 mitigation).

**Responsible Body/Role:** Stakeholder Engagement & Communication Board (SEC),

**Suggested Timeframe:** Project Month 1

**Key Outputs/Deliverables:**

- SECB Meeting Minutes 001
- Public Messaging Guardrails Document
- Advisory Committee Input/Output protocol finalized

**Dependencies:**

- SECB ToR Approved and Members Confirmed

### 15. CPET verifies competency of recruited calibration staff meets Day 90 validation target; if missed, CPET immediately contracts external lab backup per staffing risk mitigation plan.

**Responsible Body/Role:** CPET / Lead Field Technician

**Suggested Timeframe:** Project Day 90

**Key Outputs/Deliverables:**

- Internal Calibration Competency Sign-off (or External Contract Initiation Notice)
- Updated Operational Cost forecast

**Dependencies:**

- Recruitment Completed (Step 6)

### 16. CPET executes first batch of dynamic sensor relocation based on preliminary CTD profiles, marking operational readiness for spatial density management.

**Responsible Body/Role:** CPET

**Suggested Timeframe:** Month 4 Post-Initial Deployment

**Key Outputs/Deliverables:**

- Sensor Deployment Confirmation Report (20 modules active)
- Log of initial mobile performance vs. power budget models

**Dependencies:**

- Vessel Charter Agreement Signed
- CTD Profiling Completed

### 17. PSC reviews initial deployment success against GOAL scope, approves initiation of the formal Regulatory Acceptance Roadmap track, and authorizes first release of validated O2/Nutrient data for external workshop use.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Month 4

**Key Outputs/Deliverables:**

- PSC Go-Forward Approval for Monitoring Phase
- Formal data package released to Regulatory Engagement Liaison

**Dependencies:**

- Sensor Deployment Confirmation (Step 15)
- Regulatory Acceptance Roadmap v1.0