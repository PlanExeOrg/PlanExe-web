*Roles Needed & Example People*

# Roles

## 1. Marine Systems Engineer & Prototyping Lead

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Responsible for custom hardware prototyping (Decision 1). This specialized, project-specific development work involving local engineering firms suggests a contracted, deliverable-based relationship rather than permanent employment.

**Explanation**:
Responsible for realizing the 'Pioneer's Edge' hardware goals: overseeing the customization, development, and integration of the bespoke sensor housings and anti-fouling mechanisms (Decision 1). This role bridges software/firmware needs with physical deployment realities.

**Consequences**:
Failure of custom hardware to function reliably (Risk 1), leading to data gaps, reliance on lower-fidelity backup sensors, and jeopardizing the 'adjudication-ready' data goal.

**People Count**:
min 1, max 2, depending on immediate prototyping load

**Equipment Needs**:
Rapid-prototyping workbench, specialized sensor housing/anti-fouling component stock, customized firmware loading stations, standardized calibration/test jig for hybrid sensors.

**Facility Needs**:
Dedicated, secure workshop space near Roskilde Fjord for customized sensor fabrication, assembly, and environmental testing prior to deployment.

## 2. Telemetry & Network Architect

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Owns the complex, specialized design and implementation of the RF mesh/satellite uplink (Decision 2 & 10). Network architecture requires specialized expertise often sourced externally for critical infrastructure build-out.

**Explanation**:
Owns the success of the decentralized communication strategy (Decision 2 & 10). Designs, implements, and maintains the complex RF mesh network and the central satellite uplink hub, ensuring failover redundancy against the single point of failure risk (Risk 2).

**Consequences**:
Catastrophic, widespread data blackouts if the central hub fails, immediately halting all real-time monitoring and undermining public trust.

**People Count**:
1

**Equipment Needs**:
RF Mesh networking hardware (routers, repeaters, specialized modems), Solar-powered satellite uplink station components, high-gain antennas, dual-path (cellular/satellite) communication hardware, ruggedized servers for data aggregation hub.

**Facility Needs**:
Secure, centralized facility near an accessible island/coastal area for housing and maintaining the primary satellite uplink telemetry hub, including reliable power access for charging backup systems.

## 3. Environmental Calibration Specialist (Wet Chemistry)

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The strategy (Decision 5) explicitly requires internalizing calibration and training two dedicated staff for bi-weekly, high-fidelity wet chemistry validation. This necessity for year-round, proprietary, high-skill execution warrants a fixed, full-time commitment to maintain data integrity.

**Explanation**:
The core function ensuring data integrity. This role is responsible for internalizing bi-weekly calibration (Decision 5), possessing the necessary expertise in wet chemistry on-site to validate nutrient and O2 sensors against high accuracy standards.

**Consequences**:
Data accuracy degrades rapidly (drift), rendering the data unsuitable for regulatory adjudication, which is a core project requirement. High risk if recruitment (Risk 3) fails unexpectedly.

**People Count**:
2

**Equipment Needs**:
High-precision wet chemistry titration equipment (for O2/Nutrients), certified pH reference standards, consumables for bi-weekly chemical validation, specialized laboratory workspace for sample handling/storage.

**Facility Needs**:
A dedicated, controlled-environment laboratory space (with required ventilation/safety standards) accessible to the deployment zone for performing rigorous bi-weekly wet chemistry calibrations on retrieved sensor components.

## 4. Environmental Field Operations & Logistics Coordinator

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Manages complex, dynamic logistics (monthly relocation) and securing vessel charters (Risk 4). This often utilizes specialized maritime service providers on a contractual basis rather than employing permanent, dedicated vessel crews for a project of this scope.

**Explanation**:
Manages all physical deployment logistics, specifically the challenging monthly, dynamic relocation of sensor nodes (Decision 4 & Risk 4). Secures and manages vessel charters and ensures mobility protocols are executed within the tight synchronization window.

**Consequences**:
Deployment schedule collapses; sensors become stranded or repositioned too slowly, invalidating the dynamic sampling strategy and increasing wear-and-tear related downtime.

**People Count**:
1

**Equipment Needs**:
Secured contract for specialized marine vessel charter (for dynamic relocation and CTD profiling), winches/deployment systems compatible with mobile sensor nodes, portable GPS/tracking systems for rapid deployment mapping.

**Facility Needs**:
Logistics staging area with immediate access to Roskilde Fjord for rapid vessel mobilization, sensor storage, and management of deployment/retrieval checklists.

## 5. Regulatory Liaison & Engagement Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Manages ongoing, proactive, and sensitive Regulatory Engagement (Decision 3) and secures acceptance for novel technologies (Missing Assumption 1). This ongoing liaison role requires continuous integration with Danish authorities, best served by a dedicated internal employee.

**Explanation**:
Manages the political and compliance landscape (Decision 3). Responsible for proactive, informal engagement with Danish authorities and crafting the communication strategy to manage data phasing (e.g., deferral of microplastics) and secure acceptance for custom hardware (Missing Assumption 1).

**Consequences**:
Project could face regulatory stoppage orders or be forced into costly, premature scope additions (Risk 5) due to relationship mismanagement or failure to secure provisional compliance pathways.

**People Count**:
1

**Equipment Needs**:
Secure, encrypted communications hardware for confidential liaison meetings, presentation equipment for workshops, record-keeping software compliant with Danish environmental reporting standards.

**Facility Needs**:
A private, accessible meeting room/office in close proximity to Roskilde municipal/regulatory offices for conducting proactive, informal data-sharing workshops.

## 6. Data Pipeline & QA/QC Analyst

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Responsible for real-time data pipeline, anomaly detection, and provenance tagging (Decision 12). As this is the core method for ensuring data quality and usability throughout the project's lifespan, this is best handled by permanent project staff.

**Explanation**:
Responsible for processing incoming telemetry, establishing data provenance tagging (Decision 12), implementing anomaly detection, and preparing validated datasets for regulatory submission or public dashboards. This role supports the Data Utility Policy.

**Consequences**:
Data bottlenecks occur; raw, poor-quality data floods the system, straining analytical resources and potentially leading to the public release of inaccurate information (eroding trust).

**People Count**:
min 1, max 3, depending on real-time data volume and post-processing complexity

**Equipment Needs**:
High-performance server infrastructure for cloud ingestion pipeline, data validation software incorporating anomaly detection algorithms, metadata management system for provenance tagging, tools for generating public dashboard visualizations.

**Facility Needs**:
Secure data center or dedicated facility with robust power and cooling for housing the primary data ingestion and processing pipeline, ensuring 24/7 up-time resilience.

## 7. Stakeholder & Communication Coordinator

**Contract Type**: `part_time_employee`

**Contract Type Justification**: Coordinates the Stakeholder Feedback Loop (Decision 8), managing weekly advisory committee input. This is a crucial, but often part-time, liaison role balancing inputs from external groups (fishermen/municipality) against core project schedules.

**Explanation**:
Manages the complexity of external feedback loops (Decision 8), particularly integrating inputs from the fishing cooperative within the 48-hour window, which directly informs the dynamic deployment strategy. Also filters external inquiries from the Regulatory Liaison.

**Consequences**:
Rapid loss of political capital and stakeholder trust (Risk 8) due to slow response times or failure to integrate crucial local knowledge into operational planning.

**People Count**:
1

**Equipment Needs**:
Meeting management software for advisory committees, tools for rapid digitization and mapping of anecdotal input (GPS logs, location notes) from fishermen, standardized reporting templates for external groups.

**Facility Needs**:
Regularly scheduled meeting space suitable for hosting diverse cross-functional groups (regulators, fishermen) for the weekly advisory committee meetings.

## 8. Project & Financial Control Steward

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Oversees the long-term financial control and burn-down strategy related to the high fixed costs (internal staff, telemetry SLAs). This fiduciary and strategic management role requires consistent, dedicated internal oversight throughout the monitoring period.

**Explanation**:
Oversees the complex resource allocation dictated by the 'Pioneer's Edge,' specifically tracking high fixed operational expenses (internal staff salary, telemetry SLAs) against the capital budget. Focuses on burn-down schedules to manage long-term financial viability (Missing Assumption 3).

**Consequences**:
Risk 7 (Opex overrun) becomes a near certainty; the project runs out of funds before remediation efforts are complete or is forced into an immediate, unplanned transition to a lower-fidelity, outsourced model.

**People Count**:
1

**Equipment Needs**:
Financial modeling software for Opex/Capex tracking, specialized budgeting tools to monitor high fixed costs (staff salaries, telemetry SLAs), contract management system for securing 24-month SLAs.

**Facility Needs**:
Standard project management and financial control office space, independent from the physical field operations hub to ensure objective oversight of spending against burn-down schedules.

---

# Omissions

## 1. Missing Role: Dedicated Vessel/Maritime Operations Support

The project relies on the 'Pioneer's Edge' dynamic mobile deployment strategy (moving sensors monthly) and requires CTD profiling for stratification data (Assumption Q6). This necessitates specialized, reliable maritime support (vessel charter), managed by the Field Operations Coordinator (Team Member 4). However, there is no explicit role dedicated to securing, managing, and operating this essential, recurring, high-risk physical resource separate from general logistics coordination.

**Recommendation**:
Ensure the scope of the Environmental Field Operations & Logistics Coordinator (Team Member 4) explicitly includes securing a dedicated, long-term maritime contract that provides immediate response capability, or mandate the addition of a specialized 'Vessel Operations Lead' if charter management complexity proves too high for the existing coordinator.

## 2. Missing Role: Specialized Microplastics Analysis Integration

The project explicitly commits to monitoring microplastics, but the chosen strategy consciously defers full quantification (Decision 9), focusing only on O2/Nutrients initially. The existing roles (Analyst, Calibration Specialist) focus on wet chemistry for nutrients/O2 or general QA/QC. Integrating or validating microplastic proxy/quantification methods requires specialized expertise that is not explicitly filled or budgeted.

**Recommendation**:
As the project is highly technical, assign the analytical/QA/QC responsibility (Team Member 6) the explicit sub-task of establishing the validation roadmap for microplastic proxy data, even if quantification is phased. If full quantification is eventually needed, a part-time specialist in environmental polymer chemistry should be budgeted for Phase Two, or the Data Pipeline Analyst must be scaled up (max 3 people) to handle the imaging/proxy analysis in the interim.

## 3. Missing Step: Dedicated Regulatory Acceptance Roadmap Execution

The project *assumes* regulatory acceptance for novel sensors is possible but acknowledges the risk that formal validation could take 12-18 months (Missing Assumption 1). While the Regulatory Liaison (Team Member 5) exists to manage engagement, there is no explicitly defined *execution team* responsible for performing the necessary shadow validation/inter-laboratory comparison against external labs required to meet this roadmap.

**Recommendation**:
The Data Pipeline & QA/QC Analyst (Team Member 6), in collaboration with the Calibration Specialists (Team Member 3), must be formally tasked with managing the comparison data streams against external reference labs. This task needs dedicated time allocation, as it supports the highest-priority legal/regulatory compliance requirements.

---

# Potential Improvements

## 1. Clarification of Dynamic Deployment Accountability and Power Constraint Management

The dynamic deployment strategy (monthly moves) creates constant stress on telemetry power budgets (Missing Assumption 2) and increases wear-and-tear (Risk 4). The Logistics Coordinator (Team Member 4) manages the move, and the Network Architect (Team Member 2) manages the hub, but who is responsible for real-time power validation *at the mobile node level* before/after movement?

**Recommendation**:
Update the role description for the Telemetry & Network Architect (Team Member 2) to explicitly include developing and enforcing the automated power efficiency checks (Minimum 45-day predicted operational life) that must be satisfied *before* the Field Operations Coordinator (Team Member 4) can execute a relocation check-out.

## 2. Reduce Overhead Friction between Internal Calibration and External Reporting

The highly specialized, internalized calibration (Decision 5) imposes high fixed costs and creates direct conflict with Communication Cadence (Decision 6) due to analyst time diversion. The Project Steward (Team Member 8) is tasked with monitoring the Opex burn-down, but the roles performing the work do not have clear thresholds for when they can offload tasks.

**Recommendation**:
Formalize the 'Staff Burn-Down Schedule' (suggested in Missing Assumption 3) as a clear operational guideline. The Project Steward should mandate that once Oxygen/Nutrient data stability meets criteria X for three consecutive months, the Calibration Specialists (Team Member 3) transition from bi-weekly to monthly calibration efforts, allowing the Data Analyst team (Team Member 6) to decrease communication support time proportionally.

## 3. Clarifying Data Provenance Tagging Ownership vs. Review

Data Sharing Protocol (Decision 12) requires provenance tagging to denote quality assurance level. The Data Pipeline Analyst (Team Member 6) is responsible for implementing this, but the Regulatory Liaison (Team Member 5) must ensure the *correct* tags are visible to authorities. Clarity is needed on who signs off on the tag structure.

**Recommendation**:
Establish a mandatory weekly synchronization meeting between the Data Pipeline & QA/QC Analyst (Team Member 6) and the Regulatory Liaison & Engagement Manager (Team Member 5). This meeting formally approves the output of the provenance tagging schema being applied to the outgoing data streams before publishing to stakeholders or regulatory bodies.