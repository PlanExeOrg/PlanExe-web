This plan implies one or more physical locations.

## Requirements for physical locations

- Must cover the Roskilde Fjord geographically
- Requires locations suitable for deploying fixed or mobile sensor buoys
- Locations near established electrical/municipal infrastructure for potential fixed hubs (per strategic choice 2 conflict)
- Locations in northern fjord sections where cellular coverage may be weak (per strategic choice 1 conflict)
- Requires accessible island/central location for potential satellite uplink station

## Location 1
Denmark

Roskilde Fjord (General Area)

Entire spatial extent of Roskilde Fjord, Zealand

**Rationale**: This represents the entire operational zone mandated by the monitoring program.

## Location 2
Denmark

Central Roskilde Fjord / Accessible Island Location

Near Hesselø or an equivalent central, accessible island structure

**Rationale**: Ideal location for the primary, solar-powered satellite uplink station, fulfilling the 'Pioneer's Edge' telemetry strategy (Decision 2, Choice 3) and supporting a decentralized RF mesh network.

## Location 3
Denmark

Roskilde Fjord Inflow and Outflow Zones

Near the mouth of the fjord (towards the Kattegat) and areas near known river/wastewater inflows

**Rationale**: Critical anchor points for cross-section monitoring (Decision 4, Choice 1/2) to sample pollutant sources and dispersal toward the sea, crucial for high-integrity baseline sampling.

## Location 4
Denmark

Area near Roskilde City Infrastructure

Coastal area of Roskilde near existing port or municipal utility connections

**Rationale**: Serves as an initial deployment/maintenance hub, close proximity to stakeholder partners (Decision 3), and potential source for fixed, cable-backed telemetry infrastructure if needed for reference stations (Decision 2, Choice 2 synergy).

## Location Summary
The plan is centered entirely on the Roskilde Fjord in Denmark, which requires a comprehensive array of deployed physical monitoring stations. Suggestions include the entire fjord extent, a dedicated central uplink location (for satellite telemetry optimization), critical anchor points near known inputs/outputs for baseline stability, and an area near Roskilde City for logistical, political, and potential reference station siting.