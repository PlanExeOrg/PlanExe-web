A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The customized, rapid-prototyped sensor housings and anti-fouling mechanisms will maintain functionality and data fidelity across the full operational period without requiring immediate, unplanned redesigns or specialized maintenance access. | Immediately activate the 30-day accelerated prototype validation gate for the custom sensor modules, comparing failure rates and data drift against the pre-qualified ruggedized commercial backup modules. | Dissolved Oxygen or Nitrate readings from custom prototype sensors exhibit an R-squared correlation below 0.90 with external lab references within the first 30 days, or biofouling necessitates a hardware cleaning cycle faster than every 45 days. |
| A2 | The decentralized RF mesh network nodes can sustain their required transmission duty cycles—even when accounting for 20% biofouling signal attenuation—sufficiently long to guarantee a 45-day operational window between mobile relocation cycles. | The Telemetry & Network Architect must finalize and approve the power budget model factoring in biofouling degradation, verifying the resulting predicted operational life for a full deployment cycle against the 45-day minimum requirement. | The validated power budget simulation shows that 15% or more of the deployed mobile nodes would fail due to energy exhaustion before the scheduled 45-day mark, particularly in geolocations with predicted lower solar irradiance. |
| A3 | The high-cost, mission-critical internal calibration expertise (two FTE specialists) can be successfully recruited, onboarded, and certified competent in wet chemistry validation protocols by Project Day 90. | Activate the Shadow Contract with the external environmental laboratory by Day 30 to guarantee immediate coverage if the internal recruitment/training effort fails, and conduct an independent third-party audit of the internal training efficacy at Day 75. | The competency certification for both specialists is not finalized by Day 90, forcing immediate reliance on the Shadow Contract and resulting in a measured data fidelity reduction (e.g., calibration frequency drops from bi-weekly to quarterly) during the first acute reporting window. |
| A4 | The preliminary 3D water column model derived from the initial CTD profiling campaign will be accurate enough to guide the first four dynamic sensor relocation cycles effectively, correctly identifying stratified zones and leading plume edges. | The Marine Hydrodynamic Modeler must present the simulation results and confidence metrics for the first four planned relocations derived solely from the CTD data, comparing modeled results against consensus literature on Roskilde Fjord dynamics. | The actual relocation outcomes (measured by data improvement/anomaly detection) after the first cycle show that less than 60% of the shifted sensors landed in zones identified by the model as having the highest predicted rate of change in pollution concentration. |
| A5 | The chosen high-frequency communication protocol (RF Mesh/Satellite Uplink) is robust against interference from pre-existing Danish maritime/municipal telemetry systems operating within the Roskilde Fjord area. | The Telemetry & Network Architect must conduct a spectrum analysis survey across the primary and secondary communication channels (relevant RF bands and satellite uplink frequency) during peak local maritime activity (verified by Maritime Logistics Coordinator). | The spectrum analysis reveals significant, persistent, and unmitigable signal overlap (EMI) with known municipal or shipping navigation systems, leading to data packet loss rates exceeding 5% during evening peak hours in the two densest deployment zones. |
| A6 | The Public Risk Communication Cadence strategy (proactive, informal workshops and public dashboards) will effectively manage public perception regarding the explicit, intentional deferral of microplastics monitoring (Decision 9) without triggering immediate political demands to circumvent the planned Phase Two rollout. | The Regulatory Liaison and Stakeholder Coordinator must conduct a simulated 'stress test' briefing with a small subset of the Joint Advisory Committee, focusing solely on the phased tracking roadmap (O2/Nutrients first, microplastics later). | The advisory committee subset unanimously rejects the rationale for deferring microplastics and issues an explicit, written demand for immediate inclusion of microplastics monitoring within the next 30 days. |
| A7 | The project's commitment to an aggressive, daily Public Risk Communication Cadence (Decision 6) will generate public trust and political momentum sufficient to offset the internal strain it places on scarce analytical resources. | The Stakeholder & Communication Coordinator must run a controlled diffusion test on the initial O2/Nutrient dashboard visualizations with a representative sample of political stakeholders and measure engagement versus analyst time spent on communication tasks. | Analyst time dedicated to communication tasks (data visualization, Q&A prep) exceeds 30% of the Data Pipeline & QA/QC Analyst's total capacity for three consecutive weeks, leading to documented delays in anomaly detection processing. |
| A8 | The long-term retention policy (Decision 7), archiving all high-frequency raw data indefinitely, will remain financially viable within the expected operational budget structure beyond the initial 24-month SLA commitment, without unforeseen escalation in cold storage costs. | The Project & Financial Control Steward must secure binding, escalation-proof quotes for the 3rd and 4th year of cold storage services, based on the projected Year 2 end-of-storage volume. | Secure 3-year storage quotes show an estimated annual cost escalation rate exceeding 25% year-over-year, or the estimated 24-month data volume calculation proves to be underestimated by a factor greater than 1.5x. |
| A9 | The decision to concentrate nutrient tracking initially on Nitrate and Phosphate (Decision 9) is sufficient to capture the full spectrum of acute ecological risk necessary to satisfy the 30-day formal reporting mandate (Assumption Q4) for regulatory compliance. | The Regulatory Liaison must obtain a written agreement from Miljøstyrelsen confirming that Nitrate and Phosphate data alone are sufficient to define 'threshold breaches' for the acute die-off events, temporarily exempting pH and trace metals from the mandatory 30-day trigger. | Miljøstyrelsen confirms that pH excursions or documented trace element spikes (even without exceeding threshold limits for N/P) are legally classified as a 'major environmental shift' triggering the 30-day formal reporting clock. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Adjudication Deadlock: Custom Hardware Rejection | Technical/Logistical | A1 | Marine Systems Engineer & Prototyping Lead | CRITICAL (20/25) |
| FM2 | The Silent Network Collapse: Power Budget Failure at Mobile Nodes | Process/Financial | A2 | Project & Financial Control Steward | CRITICAL (20/25) |
| FM3 | The Credibility Vacuum: Expertise Failure Leading to Data Drift | Market/Human | A3 | Environmental Calibration Specialist (Lead) | CRITICAL (25/25) |
| FM4 | The Trust Implosion: Political Backlash over Phased Data Release | Market/Human | A6 | Regulatory Liaison & Engagement Manager | CRITICAL (20/25) |
| FM5 | The Misguided Mover: Dynamic Deployment Based on Flawed Hydrodynamics | Technical/Logistical | A4 | Environmental Field Operations & Logistics Coordinator | CRITICAL (16/25) |
| FM6 | The Frequency Crowding: RF Interference Cripples Real-Time Flow | Process/Financial | A5 | Telemetry & Network Architect | HIGH (12/25) |
| FM7 | The Archive Abyss: Opex Overrun from Eternal Data Tithing | Process/Financial | A8 | Project & Financial Control Steward | CRITICAL (20/25) |
| FM8 | The Acute Blind Spot: Ignoring Proxy Variables for Immediate Risk | Technical/Logistical | A9 | Data Pipeline & QA/QC Analyst | CRITICAL (16/25) |
| FM9 | The Analyst Burnout: Communication Cadence Overwhelms Validation Capacity | Market/Human | A7 | Stakeholder & Communication Coordinator | CRITICAL (20/25) |


### Failure Modes

#### FM1 - The Adjudication Deadlock: Custom Hardware Rejection

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A1
- **Owner**: Marine Systems Engineer & Prototyping Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's 'Pioneer's Edge' relies on the Danish Environmental Protection Agency (Miljøstyrelsen) accepting the novel O2/Nutrient data streams from custom sensors as 'adjudication-ready.' If the internal validation team (A3) achieves competency, but the regulatory body requires an extended 18-month inter-laboratory comparison study before granting provisional approval, the project's primary legal defense data stream is nullified.
Failure to meet the 95% correlation target (or rejection by the regulator) forces the use of traceable, but lower-fidelity, commercial backup hardware data, undermining the justification for the high capital investment in prototyping and specialized maintenance salaries.

##### Early Warning Signs
- Initial 30-day prototype validation gate shows R-squared correlation < 0.95 against reference lab data.
- Regulatory Liaison reports difficulty scheduling the 'Regulatory Acceptance Roadmap' meeting beyond the first projected consultation slot (Month 1).
- Procurement for commercial off-the-shelf (COTS) emergency sensor replacements is not finalized by Month 2.

##### Tripwires
- R-squared correlation drops below 0.90 for either O2 or Nutrients at the 60-day assessment point.
- Regulatory Liaison confirms need for 12+ months of external comparative testing before data can be used in any official submission.

##### Response Playbook
- Contain: Immediately lock down the Data Pipeline QA/QC Analyst to prioritize preparing a transparent presentation detailing the current data lineage and the reason for any discrepancy.
- Assess: Freeze all further custom sensor deployment and immediately deploy the pre-qualified COTS backup modules for the affected channels (O2/Nutrients) under the existing calibration regime.
- Respond: The Project Sponsor must engage the highest level of political support to immediately request a fast-tracked 6-month provisional acceptance for the most acute emergency metrics (O2 only) to satisfy immediate compliance triggers.


**STOP RULE:** Formal denial of provisional regulatory acceptance status for O2/Nutrient data streams after the first scheduled quarterly review (Month 3).

---

#### FM2 - The Silent Network Collapse: Power Budget Failure at Mobile Nodes

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: Project & Financial Control Steward
- **Risk Level:** CRITICAL 20/25 (Likelihood 5/5 × Impact 4/5)

##### Failure Story
The core premise of dynamic deployment (Decision 4) coupled with low-power RF mesh (Decision 2) is undermined if the power budget proves insufficient under real-world conditions, exacerbated by biofouling. If nodes deplete power prematurely, the network effectively shrinks, creating significant, unpredictable data gaps across the fjord. This data loss compounds the operational complexity, forcing repeated, costly vessel deployments for emergency retrieval/recharging before the scheduled relocation cycle, leading to immediate Opex overrun (Risk 4/7). The Financial Steward lacks the accurate recurring cost projections necessary for Year 3 budgeting if reactive maintenance consumes the contingency.

##### Early Warning Signs
- Telemetry/Network Architect reports more than 5% of mobile nodes failing to check-in during any 7-day period outside of adverse weather.
- Vessel charter utilization for reactive maintenance exceeds 15 days per month in the first quarter post-deployment.
- Monthly review by Financial Steward shows operational expenditure for vessel charters approaching 10,000 DKK above baseline allocation.

##### Tripwires
- More than 10% of active mobile nodes fail to report for 5 consecutive days due to confirmed power/RF issues, not planned maintenance.
- Vessel charter utilization for emergency response exceeds 25 days tracked in a single calendar month.

##### Response Playbook
- Contain: Immediately institute a temporary 'Static Mode' for all mobile sensors, forcing them to remain at their last validated, high-yield locations, thus reducing RF transmission duty cycles until power sufficiency is verified.
- Assess: Re-run the RF propagation and power budget model, requiring empirical data logs from failed nodes to update the biofouling attenuation factor and inform a mandatory hardware specification review.
- Respond: The Financial Steward must immediately freeze non-essential procurement funded by Opex and allocate the necessary reserves to charter a supplementary technical response vessel dedicated solely to node recovery/power assessment.


**STOP RULE:** Failure to restore the predicted operational life (45 days minimum) to 90% of the mobile node fleet within 60 days of the first major power-related failure event.

---

#### FM3 - The Credibility Vacuum: Expertise Failure Leading to Data Drift

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Environmental Calibration Specialist (Lead)
- **Risk Level:** CRITICAL 25/25 (Likelihood 5/5 × Impact 5/5)

##### Failure Story
The project's entire fidelity strategy rests on the internalized, bi-weekly wet chemistry calibration (Decision 5). Assumption A3 failed: specialized recruitment lagged, and required staff competency was not achieved by Day 90. This forces immediate activation of the external Shadow Contract, which was designed for short-term backup, not sustained primary calibration. The external lab's service schedule (e.g., quarterly visits) cannot match the required bi-weekly pace, leading to unchecked sensor drift across the entire network. This results in data accuracy collapsing below the 95% correlation threshold, directly jeopardizing the regulatory acceptance timeline (addressed in Failure Mode 1) and instantly eroding public trust, as the high upfront investment in expert personnel proves worthless.

##### Early Warning Signs
- Internal recruitment drive reports zero concrete offers secured by Day 60.
- The Shadow Contract calibration rate/schedule proves inadequate to cover the bi-weekly workload when activated post-Day 90.
- Data QA/QC Analyst flags an increasing number of data points requiring manual correction due to uncalibrated sensor drift.

##### Tripwires
- Internal calibration staff competency certification is not achieved by Day 90.
- External Shadow Contract usage exceeds 30% of the total calibration workload in any 30-day period during Months 4-6.

##### Response Playbook
- Contain: Immediately downgrade the expected data quality for regulatory reports to 'Provisional Status,' explicitly notifying the Regulatory Liaison to prepare communication framing this as a temporary fidelity setback.
- Assess: The Environmental Economics Analyst must immediately re-model the long-term Opex based on full reliance on the (more expensive) external lab retainer contract to determine the new financial runway.
- Respond: The Project Sponsor must authorize an immediate, significant salary premium injection into the recruitment budget for the two specialist roles, concurrently delegating ownership of the *training program* to the external Shadow Lab manager for high-speed enablement.


**STOP RULE:** If external lab services are required to cover more than 75% of all calibration events for a continuous 6-month period, the project must immediately pivot to the 'Builder's Standard' maintenance cadence (quarterly external calibration), sacrificing high-fidelity adjudication capabilities.

---

#### FM4 - The Trust Implosion: Political Backlash over Phased Data Release

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Regulatory Liaison & Engagement Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Failure to secure political alignment on the de-scoping of microplastics tracking leads directly to an early mandate reversal. Public distrust, amplified by the early, aggressive communication cadence (Decision 6), interprets the phased approach as an attempt to conceal long-term toxicological drivers. This results in the Danish EPA imposing non-optimal remediation directives based on incomplete acute data, while simultaneously forcing the project to pivot resources immediately to procure, integrate, and validate microplastics monitoring hardware far ahead of schedule. This diversion drains the Opex/contingency planned for the ongoing calibration and telemetry SLA upkeep.

##### Early Warning Signs
- Advisory Committee review results in >50% negative sentiment score on the microplastics deferral roadmap (Decision 9).
- Regulatory Liaison reports that Miljøstyrelsen is no longer engaging constructively on O2/Nutrient acceptance, shifting focus exclusively to microplastics justification.
- Media sentiment analysis tracker shows negative framing dominating 'microplastics' and 'transparency' keywords over three consecutive weeks.

##### Tripwires
- The Joint Advisory Committee votes to table a motion formally requesting immediate inclusion of microplastic tracking in Phase One baseline. (Requires formal vote transcription)
- The Project Sponsor receives a formal written directive from a national-level authority demanding microplastic data streams by Month 6.

##### Response Playbook
- Contain: Immediately pause all public dashboard updates related to data fidelity uncertainty; issue a single, highly controlled statement reaffirming commitment to comprehensive monitoring in Phase Two.
- Assess: The Economics Analyst must model the capital impact of an emergency pivot to microplastics procurement (estimated cost escalation) against the current contingency budget.
- Respond: The Project Sponsor must escalate engagement immediately, proposing a legally binding, escrowed budget commitment for Phase Two Microplastics Monitoring launch by Month 12, contingent on successful stabilization of acute metrics.


**STOP RULE:** Any formal regulatory order mandating the procurement or integration of microplastic monitoring capabilities before the Month 9 O2/Nutrient fidelity sign-off.

---

#### FM5 - The Misguided Mover: Dynamic Deployment Based on Flawed Hydrodynamics

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A4
- **Owner**: Environmental Field Operations & Logistics Coordinator
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The 'Pioneer's Edge' utilizes a dynamic relocation strategy guided entirely by preliminary CTD profiling (Assumption A4). If this initial 3D model is inaccurate regarding complex fjord stratification or transient plume behavior, monthly sensor relocations will systematically place sensors in areas of low pollutant variability or insufficient stratification for useful modeling. This leads to wasted vessel charter costs (Risk 4 overrun), but more critically, it causes a spatial data bias that results in significant blind spots during genuine, localized pollution surges. The system appears operational but collects irrelevant data, leading to a 3-6 month delay in accurately identifying remediation targets.

##### Early Warning Signs
- The first post-relocation data QA report shows that transferred nodes recorded significantly lower average variance in targeted parameters than neighboring stable nodes.
- Maritime Logistics Coordinator reports that vessel time allocated for relocation exceeds the budgeted baseline by 20% in Month 5, as initial high-value sites are missed.
- The Data Pipeline Analyst flags spatial data clustering around initial deployment points, with sparse coverage in newly predicted high-value zones.

##### Tripwires
- The anomaly detection rate in the first re-deployed sector is less than 50% of the historical rate observed at the initial deployment site.
- The cumulative vessel charter cost exceeds 30,000 DKK by Month 6 due to increased relocation frequency.

##### Response Playbook
- Contain: Immediately suspend all further dynamic relocations; revert the entire mobile fleet to the initial, high-value deployment coordinates until a manual validation sweep can be conducted.
- Assess: Request an emergency, accelerated simulation run from the Marine Hydrodynamic Modeler, specifically testing the initial CTD model against known historical high-variability data sets (if available), aiming to pinpoint the model error source.
- Respond: Re-allocate the vessel charter budget from relocation tasks to conducting intensive, focused CTD profiling campaigns in the 3 poorest-performing sectors to generate a high-certainty 'Model Correction Patch.'


**STOP RULE:** If three consecutive monthly relocation cycles (Months 5, 6, and 7) fail to result in a net improvement in captured data variance compared to the previous month's deployment location, the dynamic strategy is deemed unviable and must pivot to a fixed-grid deployment model.

---

#### FM6 - The Frequency Crowding: RF Interference Cripples Real-Time Flow

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A5
- **Owner**: Telemetry & Network Architect
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The assumption of RF compatibility (A5) proves false when high-frequency municipal or shipping telemetry systems cause significant interference in the chosen LoRa/RF mesh band (Risk 2/Decision 2). Because the network is designed to be low-power and decentralized, high packet loss occurs, even if the central hub's power backup (Failure Mode 2 mitigation) is functional. This introduces systemic measurement latency, degrading data timeliness to less than real-time archival mode. The Financial Steward faces an immediate crisis as the expensive 24-month SLA (Assumption Q8) for performance uptime becomes invalid, threatening massive future cost escalations if immediate (expensive) frequency switching or hardware replacement is required, potentially diverting capital from the calibration specialization budget.

##### Early Warning Signs
- The Data Pipeline Architect reports a sustained average data packet retransmission count increase of 400% across the mesh network nodes.
- The Network Architect confirms that secondary (cellular) backhaul utilization spikes to >80% capacity consistently, indicating primary RF link failure.
- Telecommunication contracts (SLA Q8) are triggered for performance penalties/renegotiation discussions before Month 6.

##### Tripwires
- Sustained average RF packet loss rate exceeds 10% for more than 5 consecutive days, directly violating SLA performance metrics.
- The cost model shows that maintaining the required 95% Network Availability Uptime (NAU KPI) requires utilizing the secondary cellular backup channel, resulting in an estimated 50% increase in the monthly telemetry operational cost.

##### Response Playbook
- Contain: Immediately instruct all mobile nodes to reduce their transmission duty cycle by 50% to minimize current packet collisions, accepting temporary latency to preserve battery life.
- Assess: The Network Architect must immediately engage the maritime coordination team (using input from Logistics Coordinator) to map the discovered interference sources and determine if frequency/channel hopping is technically feasible within the existing hardware.
- Respond: If frequency hopping is not immediately viable, the Financial Steward must use contingency funds to procure and rapidly deploy a small number of high-power UHF relays in the worst-affected sectors to bypass the interfered frequency band entirely.


**STOP RULE:** If expert consultation confirms that mitigating the identified RF interference requires a complete, non-trivial redesign of the node firmware or gateway hardware, necessitating a recall/re-flash of 50% or more of the deployed sensor units.

---

#### FM7 - The Archive Abyss: Opex Overrun from Eternal Data Tithing

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A8
- **Owner**: Project & Financial Control Steward
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The commitment to indefinite raw data retention (Decision 7), while theoretically valuable for forensics, generates crippling long-term financial liability. The assumption of maintaining viability beyond the initial 24-month SLA fails when cold storage costs escalate rapidly due to unpredictable growth in the high-frequency retention stream. This continuous, escalating drain on Opex starves the operational budget, forcing the Project Steward to choose between maintaining critical resources like the internalized calibration FTEs (Decision 5) or funding necessary telemetry repairs. The project survives the initial deployment but collapses financially in Year 3 due to unfunded legacy data liability.

##### Early Warning Signs
- Year 3 cold storage service quotes show annual cost escalation exceeding 25% baseline projection.
- The Financial Control Steward reports that the contingency fund is depleted by Q4 of Year 1 due to unplanned maintenance (e.g., telemetry failures).
- The 'Staff Burn-Down Schedule' trigger (for reducing FTE calibration staff) is missed due to instability in the acute phase.

##### Tripwires
- Annualized cold storage costs exceed 60,000 DKK for the first time during the Year 2 budget review.
- The Project Steward must unilaterally redirect funds from the hardware replacement contingency to cover the telemetry SLA deficit.

##### Response Playbook
- Contain: Immediately suspend all high-frequency data ingestion for *new* data streams into the long-term archive, retaining only hourly aggregates, effectively downgrading the data utility policy post-facto.
- Assess: The Economics Analyst must generate a clear 'Cost of Retention vs. Cost of Pruning' model, defining the exact break-even point where retention costs outweigh the forensic utility advantage.
- Respond: The Project Sponsor must initiate emergency negotiations with the regulatory liaison (Decision 3) to formally amend the Data Utility and Retention Policy, seeking authorization to delete raw data older than 36 months, contingent on successful navigation of the initial regulatory acceptance period.


**STOP RULE:** If long-term cold storage projections require more than 15% of the annual operational budget in Year 3, all raw data retention is immediately pruned to 12 months, regardless of stakeholder input or future forensic needs.

---

#### FM8 - The Acute Blind Spot: Ignoring Proxy Variables for Immediate Risk

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A9
- **Owner**: Data Pipeline & QA/QC Analyst
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The initial monitoring scope (Decision 9) hinges on the assumption that Nitrate/Phosphate data alone are sufficient to trigger the 30-day regulatory reporting mandate during acute die-offs. If Miljøstyrelsen's framework also mandates reporting based on pH excursions or unmonitored trace contaminants that correlate with the die-off event, the project immediately becomes non-compliant. This forces the Technical team to retroactively implement instrumentation for unbudgeted parameters (e.g., pH sensor integration on mobile platforms), which invalidates the power budget (A2) and strains the already delayed prototyping cycle (A1), as engineering time is diverted from fixing known issues to solving uncovered compliance gaps.

##### Early Warning Signs
- Regulatory Liaison reports that official submission guidelines explicitly mention pH thresholds as mandatory reporting triggers for acute events.
- Field Operations reports that deployed sensors are recording highly anomalous pH spikes (e.g., >0.5 unit shift) during major O2 depletion events, but this data cannot be formally submitted.
- Procurement delays are flagged for pH sensors needed for the next batch of custom module builds.

##### Tripwires
- Regulatory body issues a formal notification stating that O2/Nutrient data only are insufficient to qualify for the provisional regulatory acceptance period.
- The Data Pipeline Analyst calculates that 20% or more of recorded acute events (O2 < X) also coincided with unmonitored parameter breaches.

##### Response Playbook
- Contain: Immediately initiate an emergency firmware update for all 20 modules to enable standard pH logging (if sensors have unused capacity) by routing data through the existing O2/Nutrient provenance tag pathway, labeling it 'Provisional Proxy.'
- Assess: The Prototyping Lead must immediately halt all work on the next batch of custom modules and task the team with designing a new, low-power, easy-to-integrate pH sensor package that can be retrofitted within 30 days.
- Respond: The Regulatory Liaison must engage authorities immediately, submitting the provisional pH proxy data while simultaneously providing the formal justification for deferring full validation of the new parameter until Month 6, requesting an extension based on the acute O2 crisis.


**STOP RULE:** If regulatory non-compliance penalties are issued due to data omission related to pH or any other unbudgeted parameter, forcing a full halt on mobile deployment for 90 days to integrate the missing sensor capability.

---

#### FM9 - The Analyst Burnout: Communication Cadence Overwhelms Validation Capacity

- **Archetype**: Market/Human
- **Root Cause**: Assumption A7
- **Owner**: Stakeholder & Communication Coordinator
- **Risk Level:** CRITICAL 20/25 (Likelihood 5/5 × Impact 4/5)

##### Failure Story
The aggressive, high-cadence public engagement strategy (Decision 6) proves unsustainable. While politically beneficial, it consumes an estimated 30%+ of the Data Analyst's time, drawing critical support away from the rigorous QA/QC and Regulatory Acceptance Roadmap tasks (Data Set 1). When combined with the technical instability of early deployment (A1, A2), the analyst team cannot simultaneously troubleshoot sensor drift, prepare shadow validation reports, *and* feed the public dashboard daily. This resource overload causes errors in data provenance tagging (Decision 12) or delays in correlation analysis, threatening the credibility of the entire data set, regardless of the sensors' physical performance.

##### Early Warning Signs
- Data Pipeline Analyst reports working >60 hours/week for four consecutive weeks, citing dashboard updates as the primary time drain.
- The Regulatory Liaison reports that official submission packages are delayed past internal deadlines due to slow validation certificate generation by the QA/QC team.
- Public sentiment regarding the *accuracy* of the dashboard ticks down, even while engagement remains high.

##### Tripwires
- Data QA/QC Analyst self-reports time allocation for communication tasks exceeding 30% of total capacity for two consecutive reporting cycles.
- The time taken to process raw data into a 'validated for submission' state increases by 50% compared to the baseline established in Month 1.

##### Response Playbook
- Contain: Immediately revoke the default 'hourly' dashboard update mandate (Decision 6, Choice 2); revert public communication to a fixed, twice-weekly schedule tied to the internal QA/QC review cycle for data provenance sign-off.
- Assess: The Project Steward must immediately approve a budget spike to temporarily retain one contract analyst specifically dedicated to dashboard updates and public inquiry management for a 90-day stabilization period.
- Respond: The Stakeholder Coordinator must renegotiate the communication frequency with the Project Sponsor and relevant Political Stakeholders, framing the reduction as necessary to safeguard the data integrity required for legally defensible remediation plans.


**STOP RULE:** If the delay between raw data collection and its entry into the formal validation queue exceeds 72 hours for three consecutive days, mandatory public dashboard updates must cease until the backlog is cleared.
