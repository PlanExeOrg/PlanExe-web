**Verdict:** 🟢 USABLE

**Rationale:** The prompt describes a concrete, actionable project (launching a pollution monitoring program) with a specific location (Roskilde Fjord, Denmark) and clear objectives (tracking specific pollutants).