# Purpose
# Environmental Monitoring Program - Roskilde Fjord

## Purpose

- Business
- Large-scale environmental monitoring and remediation initiative addressing a significant public and ecological resource concern, involving resource management and public welfare infrastructure.

## Topic

- Environmental monitoring program for Roskilde Fjord


# Domain
# Project Planning Summary

## Domains

- Primary: Environmental Monitoring
- Secondary: Water Quality Analysis, Marine Biology, Hydrology

## Disciplines Involved

- Environmental Monitoring: Importance 5, Specificity 5, Role outcome, Reason Core goal is launching and operating an environmental monitoring program.
- Ecotoxicology: Importance 5, Specificity 4, Role outcome, Reason Understanding toxic effects on aquatic organisms is key due to the fish die-offs.
- Data Telemetry: Importance 4, Specificity 5, Role method, Reason Real-time tracking requires expertise in collecting and transmitting sensor data.
- Sensor Technology: Importance 4, Specificity 5, Role method, Reason Real-time tracking requires selecting and deploying appropriate sensing instruments.
- Water Quality Analysis: Importance 4, Specificity 4, Role method, Reason Tracking specific metrics like oxygen, pH, nitrates, and phosphates requires analytical methods.
- Hydrology: Importance 4, Specificity 4, Role method, Reason Hydrology informs the water body dynamics critical for interpreting pollution transport.
- Environmental Regulation: Importance 4, Specificity 4, Role constraint, Reason Compliance with Danish environmental laws will constrain monitoring design and reporting.
- Marine Biology: Importance 4, Specificity 3, Role stakeholder, Reason Fish die-offs indicate a critical ecological failure necessitating biological expertise.
- Risk Communication: Importance 3, Specificity 4, Role market, Reason Communicating findings about fish die-offs impacts public and governmental stakeholders.


# Plan Type
# Location Requirements

- Requires one or more physical locations.
- Cannot be executed digitally.

## Explanation

- Launching a pollution monitoring program for a specific physical location (Roskilde Fjord) is inherently physical.
- Requires physical deployment of sensors.
- Requires physical travel for installation, maintenance, and data retrieval.
- Requires physical collection/validation of water samples.
- Cannot be executed entirely online.


# Physical Locations
# Project Plan Shortening

## Requirements for physical locations

- Must cover Roskilde Fjord geographically
- Requires locations suitable for deploying fixed or mobile sensor buoys
- Locations near established electrical/municipal infrastructure
- Locations in northern fjord sections where cellular coverage may be weak
- Requires accessible island/central location for potential satellite uplink station

## Location 1

- Denmark
- Roskilde Fjord (General Area)
- Rationale: Entire operational zone.

## Location 2

- Denmark
- Central Roskilde Fjord / Accessible Island Location (Near Hesselø or equivalent)
- Rationale: Ideal for primary, solar-powered satellite uplink station ('Pioneer's Edge' telemetry strategy) and supporting decentralized RF mesh network.

## Location 3

- Denmark
- Roskilde Fjord Inflow and Outflow Zones (Near Kattegat mouth and known river/wastewater inflows)
- Rationale: Critical anchor points for cross-section monitoring; sample pollutant sources/dispersal; crucial for high-integrity baseline sampling.

## Location 4

- Denmark
- Area near Roskilde City Infrastructure (Coastal area near port/utilities)
- Rationale: Initial deployment/maintenance hub; close proximity to stakeholders; potential for fixed, cable-backed telemetry infrastructure (reference stations).

## Location Summary

- Centered entirely on the Roskilde Fjord, Denmark.
- Requires stations covering: entire fjord extent, central uplink location, critical input/output anchor points, and area near Roskilde City for logistics/reference siting.


# Currency Strategy
## Currencies

- DKK: Primary currency for local operational costs, sensor procurement in Denmark, local salaries, and Roskilde maintenance.
- EUR: Relevant for specialized imported monitoring equipment/services from Eurozone vendors.
- USD: Useful for budgeting large capital expenditures (custom hardware, satellite service contracts).

Currency strategy: DKK is primary for localized operations. EUR/USD used for budgeting large capital purchases from abroad to mitigate fluctuations.

# Identify Risks
## Risk 1 - Technical / Sensor Suite Selection
Risk: Rapid-prototyping partnerships for custom sensor housings and anti-fouling mechanisms might fail for the Roskilde Fjord environment, causing biofouling or sensor drift.
Impact: Critical data gaps (20-40% downtime). 3–6 month delay for re-procurement. Cost: 75,000–150,000 DKK.
Likelihood: Medium
Severity: High
Action: Define phased prototype validation gates (30/90-day tests). Contractual penalty for anti-fouling failure. Pre-qualify secondary supplier of ruggedized commercial modules.

## Risk 2 - Technical / Infrastructure & Telemetry
Risk: Reliance on a single, solar-powered satellite uplink station for the decentralized RF mesh network. Single point of failure vulnerability (weather, component failure, security).
Impact: Complete loss of real-time data (1–3 weeks blackout). Major reputation impact.
Likelihood: Medium
Severity: High
Action: Implement backup infrastructure: 7-day secondary battery bank for the hub. Secondary low-frequency encrypted cellular connection to coastal support.

## Risk 3 - Operational / Maintenance Complexity
Risk: Internalizing bi-weekly calibration requires specialized technicians, difficult to recruit/retain in Denmark.
Impact: Reversion to outsourced quarterly calibration (Builder's Standard). Data integrity drop, up to 10 weeks latency, compromising regulatory adjudication suitability.
Likelihood: High
Severity: Medium
Action: Aggressive recruitment with salary premiums. Mandate outsourced lab (Decision 5, Choice 2) to train substitute personnel during site visits.

## Risk 4 - Operational / Dynamic Deployment Logistics
Risk: Dynamic mobile deployment (monthly repositioning) increases wear-and-tear, requires specialized vessel support, and causes navigational issues.
Impact: Increased maintenance downtime and relocation costs (10,000–20,000 DKK/month for vessel charter). 1–2 week delay in deployments, missing peak plume movements.
Likelihood: High
Severity: Medium
Action: Pre-secure long-term charter with local maritime service provider for 12 months. Develop strict mobilization checklists.

## Risk 5 - Regulatory & Permitting
Risk: Early, informal data-sharing workshops risk premature regulatory directives based on preliminary findings (e.g., demanding microplastics tracking upfront).
Impact: Mandated scope additions (microplastic tracking) forcing deviation or scope reduction. Budget overrun of 50,000 DKK.
Likelihood: Medium
Severity: High
Action: Consistent communication framework in workshops, focusing initially only on Oxygen/Nutrient trends. Proactively document rationale for deferring microplastic tracking to Phase Two (hardware complexity).

## Risk 6 - Supply Chain / Procurement
Risk: Custom development makes the project susceptible to specialized defects or delays from the local engineering firm(s).
Impact: Vendor bankruptcy or supply issues could delay specialized component procurement by 4–6 months, stalling deployment.
Likelihood: Medium
Severity: High
Action: Implement dual-sourcing or cross-training for critical parts. Require escrow of anti-fouling IP with a neutral third party upon contract signing.

## Risk 7 - Financial / Operational Cost Overrun
Risk: 'Pioneer's Edge' commits to high fixed operational costs (bi-weekly staff, high recurring telemetry).
Impact: If monitoring extends past 2 years, operational costs could exceed annual budget by 20–30%.
Likelihood: High
Severity: Medium
Action: Establish trigger points tied to remediation success (sustained O2 > X for 3 months) to transition staff to on-call retainer and scale down telemetry intensity.

## Risk 8 - Social / Public Trust
Risk: Not tracking microplastics immediately (Decision 9) creates a public 'knowledge gap' interpreted as obfuscation, eroding political support.
Impact: Negative public sentiment leading to imposed non-optimal remediation regulations before core data (O2/Nutrients) is established.
Likelihood: Medium
Severity: Medium
Action: Proactively use Decision 3 (Early Engagement) to communicate a phased roadmap. Frame initial focus on O2/Nutrients as 'Acute Emergency Response' transitioning to 'Chronic Contaminant Investigation' (microplastics) in Phase Two.

## Risk summary
Profile shows aggressive, high-tech implementation ('Pioneer's Edge') with high inherent technical/operational risks. Three critical risks threaten timely, high-integrity data:
1. Sensor Customization Failure (Risk 1): Hardware failure risks major delays/costs.
2. Telemetry SPOF (Risk 2): Single uplink vulnerability causes systemic blackout risk.
3. Calibration Staffing (Risk 3): Staff shortages prevent high data fidelity required by the strategy.
Mitigation requires parallel solutions: commercial failover for hardware (R1), infrastructure redundancy for telemetry (R2), and over-investing/fast-tracking specialized recruitment (R3).

# Make Assumptions
# Project Planning Summary

## Question 1 - Initial Capital Budget

- Allocated initial capital budget for sensor hardware procurement and testing: 1,500,000 DKK.
- Budget covers procurement of 20 sensor modules and associated prototyping/testing infrastructure.
- Assessment: If insufficient, the S5 strategy fails, necessitating downgrade to lower-fidelity sensors. 20% accessible for emergency off-the-shelf replacements if prototyping milestones (Risk 1) fail.

## Question 2 - Critical Milestone for First Relocation

- Critical milestone for first full relocation/re-establishment: Month 4 post-initial deployment.
- Allows 3 months for baseline stabilization and mapping (Risk 4).
- Assessment: Month 4 is aggressive; risks 10-20k DKK/month operational costs. Slippage past Month 5 compromises Regulatory Engagement Timeline (Decision 3).

## Question 3 - Internal Hiring & Calibration Competency

- Recruitment mandated completion: within 60 days of project commencement.
- Competency validation start date (training confirmation): Day 90.
- Assessment: High likelihood of staffing failure (Risk 3). If Day 90 target missed, immediately contract external lab for quarterly servicing (degrading fidelity). Premium salaries required.

## Question 4 - Reporting Regulations for Microplastics and pH

- Governing statutes (Miljøstyrelsen) require reporting exceeding thresholds: within 30 days.
- Process for provisional exceptions/extensions: Must frame microplastics omission via official documentation (Risk 5 mitigation) during early engagement (Decision 3).
- Assessment: Non-compliance on O2/Nutrients reporting risks immediate cessation orders.

## Question 5 - Redundancy Standard for Satellite Uplink

- Budgeted redundancy standard (above cellular): 7-day self-sustaining secondary battery bank and low-power encrypted cellular modem backup.
- Cost: Approx. 75,000 DKK.
- Assessment: Eliminates single point of failure (Risk 2). 75k DKK must be prioritized; failure leads to catastrophic data loss during adverse weather.

## Question 6 - Spatial Mapping Depth Sampling Strategy

- Mechanism for accounting for pollutant stratification: Towed CTD profiles at 5 major cross-section points.
- Goal: Generate preliminary 3D water column model to guide sensor placement.
- Requirement: At least 50% of deployed nodes must have 3-level depth sampling capability.
- Assessment: Lack of stratification data impacts remediation effectiveness; initial CTD profiling is indispensable.

## Question 7 - Integrating Fishing Sector Input into Relocation

- Mechanism for integration: Weekly cross-functional advisory committee (Decision 8, Choice 1) includes standing item for anecdotal evidence review.
- Required timeline for digitization/cross-referencing: within 48 hours of receipt.
- Assessment: Delays beyond 48 hours diminish input value and risk stakeholder friction (Risk 8).

## Question 8 - SLA Duration and Scope for Telemetry

- Provisional SLA duration: Minimum initial operational period of 24 months.
- Scope: Cloud ingestion pipeline, LoRaWAN/RF hardware monitoring, satellite subscription costs.
- Budgeted Cost: 350,000 DKK annually (exclusive of localized power maintenance).
- Assessment: Failure to secure 24-month SLA risks network fragmentation within the first year, compromising regulatory reports and public dashboards.


# Distill Assumptions
# Project Plan Summary

## Budget & Resources

- Hardware capital budget: 1,500,000 DKK (20 custom sensor modules).
- Secondary battery bank/cellular backup modem: 75,000 DKK.
- Staff recruitment: Two specialized staff; competency by Day 90.

## Timeline & Milestones

- First sensor network relocation: Month 4 post-initial deployment.

## Technical & Operational Details

- Initial surveys: CTD profiles across five sections for placement depth.
- Telemetry SLA: 24 months.
- Annual network service cost: 350,000 DKK.
- Advisory committee integration: Fishing sector feedback within 48 hours for relocation planning.

## Compliance & Reporting

- Danish law: 30-day formal reporting for threshold breaches.


# Review Assumptions
## Domain of the expert reviewer
Critical Project Risk Analysis and Strategic Planning

## Domain-specific considerations

- Integration of novel sensor technology (custom prototyping) with physical logistics (dynamic deployment)
- Management of high-stakes regulatory engagement based on potentially incomplete or rapidly evolving data sets
- Balancing high operational overhead (internalized calibration) against data integrity requirements

## Issue 1 - Missing Assumption: Long-term Regulatory Acceptance of Custom Hardware Fidelity
The project assumes custom sensors achieve 'adjudication-ready' status for official regulatory use (Decision 1). Missing assumption: formal, pre-agreed audit and acceptance pathway from Danish environmental authorities for novel sensor readings over time. Delay if acceptance requires 12-18 months of inter-laboratory comparison.

Recommendation: Immediately initiate a 'Regulatory Acceptance Roadmap' track. Define a shadow validation period (Months 3-15) comparing custom sensor data (O2/Nutrients) against external reference labs. Success criteria: >95% correlation for two consecutive quarters secures provisional 'adjudication-ready' status.

Sensitivity: If regulatory acceptance is delayed by 9 months, ROI trigger could be delayed by 9-15 months. External validation costs increase Opex by 150,000–250,000 DKK annually.

## Issue 2 - Missing Assumption: Power Sufficiency for High-Tempo Dynamic Deployment
The 'Pioneer's Edge' strategy mandates dynamic, mobile sensor deployment (monthly repositioning) using decentralized RF mesh nodes (Decision 2). Missing assumption: guaranteed energy yield for mobile nodes, considering biofouling and RF transmission drain at new sites. Node failure between cycles is likely if power is insufficient.

Recommendation: Integrate power budget modeling into deployment protocol. Each new site must confirm solar irradiance/battery efficiency (factoring 20% fouling degradation) supports required transmission for 45 days. If insufficient, mobility must be constrained to high-yield energy sites.

Sensitivity: If power fails 15% of the time for mobile nodes, Spatial Sampling Density (Decision 4) drops by 10-15%. This data deficiency could delay remediation timeline sign-off by 3-6 months, reducing ROI benefit by 5-8%.

## Issue 3 - Under-Explored Assumption: Financial Viability of Internalized Expertise vs. Operational Scale
The plan uses highly specialized, internalized bi-weekly calibration staff (Decision 5), incurring high fixed costs. Risk 3 (High Likelihood to fail) is securing these staff in 60 days. Long-term financial viability beyond the initial 2-year monitoring baseline is undefined, risking 20-30% Opex overrun (Risk 7).

Recommendation: Formalize a 'Staff Burn-Down Schedule': Define criteria (e.g., 12 consecutive months of stabilized O2/Nutrient readings) to downgrade bi-weekly calibration to monthly (50% staff time reduction). Secure a 'Retainer Contract' for specialized staff post-stabilization instead of relying on full-time salaries beyond Year 2.

Sensitivity: Maintaining full-time staff for the projected 4-year period (instead of transitioning in Year 3) increases personnel cost by 400,000–600,000 DKK. This reduces contingency buffer, potentially cutting NPV by 10-15%.

## Review conclusion
The project uses an aggressive 'Pioneer's Edge' strategy with significant operational and fidelity risks. Critical weaknesses include unassured regulatory acceptance for novel data, unverified power stability for dynamic deployment, and poor long-term planning for high-cost internalized expertise. Immediate action is needed for formal acceptance pathways and securing operational redundancy/efficiency metrics for power and personnel.