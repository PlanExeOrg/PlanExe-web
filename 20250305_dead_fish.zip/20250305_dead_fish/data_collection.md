## 1. Regulatory Acceptance Roadmap Metrics (O2/Nutrients)

This data directly validates the core assumption about custom hardware acceptability. Without confirmed regulatory acceptance for O2/Nutrient data (the 'Acute Response' metrics), the entire project's credibility for adjudication fails.

### Data to Collect

- Quarterly correlation statistics (custom vs. external lab) for Dissolved Oxygen.
- Quarterly correlation statistics (custom vs. external lab) for Nitrate and Phosphate readings.
- Formal audit checklist progress milestones provided by Miljøstyrelsen.
- Documentation of any required modifications to calibration procedures based on 30/90-day gate reviews.

### Simulation Steps

- Use R or Python (Pandas/SciPy) to simulate 10 quarters of comparative data sets, introducing controlled error margins (5-15%) reflective of anticipated sensor drift.
- Generate preliminary correlation reports (R-squared) for O2 and nutrients under simulated error to pre-test the '95% correlation' SMART objective compliance.

### Expert Validation Steps

- Consult Environmental Data Quality Assurance Lead (Expert 7) to finalize comparison testing protocols and metrology requirements.
- Consult Environmental Policy & Regulatory Affairs Consultant (Expert 1) to review simulated correlation reports against known Miljøstyrelsen defensibility thresholds.

### Responsible Parties

- Data Pipeline & QA/QC Analyst (Team Member 6)
- Regulatory Liaison & Engagement Manager (Team Member 5)

### Assumptions

- **High:** External reference labs used for comparison will provide measurements traceable back to national Danish standards.
- **Medium:** The project can secure necessary approvals to conduct the 15-month comparison testing against certified labs.

### SMART Validation Objective

Achieve and formally document a minimum 95% correlation (R-squared) between custom sensor readings (O2 & Nutrients) and external certified laboratory reference readings for two consecutive quarters by Month 9 (2027-03-26).

### Notes

- This addresses Missing Info 1 (Regulatory Acceptance Pathway).
- Initial focus must be on O2/Nutrients as per the narrative strategy.


## 2. Central Telemetry Hub Resilience and Power Budget

The central hub is a Single Point of Failure (SPOF) (Risk 2). If power fails or the hub goes offline, the entire real-time monitoring capability ceases. Validating resilience is critical to maintaining the high uptime required.

### Data to Collect

- Verified power budget calculations for mobile nodes factoring in 20% biofouling attenuation across all required RF transmission duty cycles.
- Procurement receipts and installation confirmation for the secondary 7-day backup battery bank and the secondary, geographically diverse cellular modem on the central hub.
- Redundant network topology map detailing dual-path (Satellite/Cellular) backhaul configuration for the central uplink.
- Delivery date and sign-off for the long-term (24-month) Telemetry SLA.

### Simulation Steps

- Use network simulation software (e.g., NS-3 or specialized LoRaWAN simulators) to model data packet loss rates given the simulated power degradation (20% biofouling) and geographic siting parameters for mobile nodes.
- Model the expected battery self-sustainability duration under peak transmission load using the new dual-path architecture.

### Expert Validation Steps

- Consult IoT Sensor Network Architect (Expert 2) to validate the feasibility of the dual-path backhaul redesign against the existing RF mesh.
- Consult Maritime Logistics Coordinator (Expert 8) to verify practical power harvesting limitations at typical mobile deployment sites in Roskilde Fjord.

### Responsible Parties

- Telemetry & Network Architect (Team Member 2)
- Project & Financial Control Steward (Team Member 8)

### Assumptions

- **High:** The immediate 75,000 DKK procurement for battery/cellular backup is successfully completed, and the network architect confirms the secondary cellular link viability given fjord topography.
- **Medium:** Biofouling attenuation factor of 20% for RF signal strength is an accurate upper-bound estimate for power consumption modeling.

### SMART Validation Objective

Finalize and approve a dual-path (Satellite Primary, Cellular Secondary) network topology ensuring the central hub maintains self-sustaining power for 7 days during outages, validated before Month 1 deployment staging (2026-08-15).

### Notes

- This requires immediate revision of Decision 2, mitigating the SPOF identified by Expert 2.


## 3. Specialized Calibration Staffing Security and Contingency

Internalized calibration (Decision 5) is critical for data fidelity, but staffing supply is rated 'High Likelihood' to fail (Risk 3). Having a pre-negotiated operational backstop (Shadow Contract) is essential to avoid data collapse from Day 30.

### Data to Collect

- Signed employment contracts for two Environmental Calibration Specialists (Team Member 3 staff).
- Validated competency certification documentation for new staff, dated by Day 90.
- Signed Shadow Contract with an external environmental laboratory detailing rates and service availability for calibration backup (starting Day 30).
- Draft 'Staff Burn-Down Schedule' policy detailing criteria for reducing FTE calibration commitment post-stabilization.

### Simulation Steps

- Model staffing delay scenarios (e.g., 30-day, 60-day delay) against the data quality decay curve to quantify the latency if the external shadow lab must take over.
- Analyze the cost differential between immediate shadow contract activation versus emergency, un-negotiated outsourced call-out fees.

### Expert Validation Steps

- Consult Environmental Policy & Regulatory Affairs Consultant (Expert 1) on the regulatory implications of using backup/shadow lab data during early monitoring phases.
- Consult Environmental Economics Analyst (Expert 3 - *via document review*) on the long-term financial modelling backing the proposed 'Staff Burn-Down Schedule'.

### Responsible Parties

- Environmental Calibration Specialist (Lead for staff onboarding)
- Project & Financial Control Steward (Team Member 8)
- Regulatory Liaison & Engagement Manager (Team Member 5)

### Assumptions

- **High:** Two specialized staff can attain functional competency in wet chemistry validation standards within 90 days using internal resources and initial vendor training.
- **High:** The external laboratory identified as a shadow resource is capable of immediately meeting the required wet chemistry accuracy standards upon contract activation.

### SMART Validation Objective

Secure signed contracts for two FTE Calibration Specialists and activate a fully costed Shadow Contract with an external lab by Day 30, ensuring zero interruption to calibration standards post-deployment.

### Notes

- Mitigates Risk 3 and supports the high-fidelity requirement of Decision 5.


## 4. Dynamic Deployment Logistics & Power Validation

The dynamic deployment strategy is core to the 'Pioneer's Edge' but introduces high logistical risk (Risk 4) and requires verified power sustainability for transmitters in new, potentially worse, locations (Missing Assumption 2).

### Data to Collect

- Executed 12-month vessel charter contract with established maritime service provider with defined response times for relocation (Risk 4 mitigation).
- Checklist verification confirming vessel charter contract explicitly covers deployment/retrieval for dynamic sensor moves and CTD profiling missions (Assumption Q6).
- Preliminary mapping data derived from initial CTD sweeps used to define safe/high-value relocation zones.
- Documentation of the specific power budget validation process integrated into the pre-relocation sign-off (Missing Assumption 2).

### Simulation Steps

- Simulate a 6-week relocation cycle using modeled vessel charter costs augmented by 20% for unexpected weather delays, comparing against the budgeted operational cost.
- Map initial CTD profile data points onto the fjord map using GIS software (e.g., QGIS) to visualize stratified zones corresponding to planned mobile deployment areas.

### Expert Validation Steps

- Consult Maritime Logistics Coordinator (Expert 8) to verify the vessel support contract scope and scheduling feasibility.
- Consult IoT Sensor Network Architect (Expert 2) to ensure the power validation step is integrated into the relocation checklist managed by logistics, fulfilling Missing Assumption 2.

### Responsible Parties

- Environmental Field Operations & Logistics Coordinator (Team Member 4)
- Telemetry & Network Architect (Team Member 2)

### Assumptions

- **Medium:** A local maritime service provider can be secured for a 12-month commitment with response/mobilization times adequate to support monthly relocations (Month 4 target).
- **Medium:** Initial CTD profiling provides sufficient 3D cross-section data to guide four high-value sensor relocation cycles effectively.

### SMART Validation Objective

Finalize and execute the 12-month vessel charter contract and complete the first full mobile sensor relocation cycle (4 moves) by Month 4, with all mobile nodes demonstrating >45 days of predicted power life post-deployment.

### Notes

- The vessel charter must support both sensor moves and the initial CTD profiling missions.

## Summary

Immediate action must focus on validating the technical foundations and mitigating the highest sensitivity risks identified: regulatory acceptance of custom hardware (Data Set 1), network resilience against failure (Data Set 2), and securing the operational chain for data fidelity through staffing contingency (Data Set 3). The project must pivot quickly to secure dual-path telemetry redundancy and lock in a shadow calibration contract before physical deployment staging begins. Success in these areas dictates the viability of the 'Pioneer's Edge' strategy.

**Immediate Actionable Tasks:**
1. **Procure Dual-Path Telemetry Redundancy:** Immediately allocate the 75,000 DKK contingency funds to procure and install the secondary cellular modem and 7-day battery bank for the central hub, validated by 2026-08-15 (Data Set 2).
2. **Secure Calibration Contingency:** Sign the Shadow Contract with an external lab detailing calibration services available from Day 30 onward, regardless of internal hiring success (Data Set 3).
3. **Initiate Regulatory Dialogue:** Schedule the initial meeting with Miljøstyrelsen by 2026-07-05 to begin defining the 'Regulatory Acceptance Roadmap' for O2/Nutrient data (Data Set 1).