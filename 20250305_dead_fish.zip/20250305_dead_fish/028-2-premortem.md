A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The local community will uniformly support the project's remediation strategies. | Conduct a survey of local residents to gauge their opinions on different remediation options (e.g., dredging, chemical treatment). | More than 25% of respondents express strong opposition to one or more proposed remediation methods. |
| A2 | The chosen sensor technology will consistently provide accurate and reliable data under all weather conditions. | Deploy a small number of sensors in diverse locations within the fjord and compare their readings against manual water samples taken at the same time and location during varying weather conditions (rain, wind, sunshine). | Sensor readings deviate by more than 15% from manual sample results in more than 20% of tests. |
| A3 | Securing diverse funding sources (private donations, corporate sponsorships, carbon credits) will be readily achievable within the first year. | Actively solicit funding from at least 10 potential private donors, 5 corporate sponsors, and explore carbon credit opportunities with a qualified broker. | Less than 25% of solicited donors/sponsors express interest, or carbon credit broker deems the project ineligible within 3 months. |
| A4 | The existing infrastructure (roads, ports, power grid) will adequately support the logistical demands of sensor deployment and maintenance. | Conduct a detailed assessment of the accessibility of all planned sensor locations, including road conditions, port capacity, and power availability, during peak and off-peak seasons. | More than 20% of sensor locations are deemed inaccessible or require significant infrastructure upgrades (e.g., road repairs, power line extensions) to support sensor deployment and maintenance. |
| A5 | The project team possesses sufficient expertise in all necessary areas (environmental science, data analysis, community engagement) to execute the project successfully without significant external support. | Conduct a skills gap analysis of the project team, comparing their expertise against the project's requirements, and assess the availability of internal resources to address any identified gaps. | The skills gap analysis reveals significant deficiencies in one or more critical areas (e.g., advanced data analysis techniques, specialized environmental modeling, conflict resolution) that cannot be adequately addressed with existing internal resources. |
| A6 | The collected data will be readily compatible with existing environmental monitoring databases and reporting systems used by local and national authorities. | Conduct a pilot data integration exercise, attempting to import and analyze data from the project's sensors into the existing databases and reporting systems used by Roskilde Municipality and the Danish EPA. | The pilot data integration exercise reveals significant compatibility issues requiring extensive data transformation or system modifications to integrate the project's data with existing databases and reporting systems. |
| A7 | The public will consistently trust the data presented on the public data portal, regardless of their pre-existing beliefs about environmental issues. | Conduct a survey before and after the launch of the public data portal, assessing public trust in the data and their perception of the fjord's health, comparing results between individuals with varying pre-existing beliefs about environmental issues. | Post-launch survey reveals that individuals with strong pre-existing skepticism towards environmental monitoring data show no significant increase in trust, or express increased distrust, in the data presented on the portal. |
| A8 | Environmentally-friendly remediation technologies will be readily available and scalable to address the specific pollution challenges of Roskilde Fjord. | Conduct a market analysis of available environmentally-friendly remediation technologies, assessing their effectiveness, cost, and scalability for the specific pollutants and conditions present in Roskilde Fjord, consulting with remediation technology vendors and environmental experts. | The market analysis reveals a lack of readily available and scalable environmentally-friendly remediation technologies that can effectively address the specific pollution challenges of Roskilde Fjord within the project's budget and timeline. |
| A9 | The project's success will not be significantly impacted by external economic factors, such as fluctuations in currency exchange rates or changes in government environmental policies. | Conduct a sensitivity analysis of the project's budget and timeline, assessing the potential impact of various economic scenarios (e.g., a 10% increase in currency exchange rates, a 20% reduction in government environmental funding) on the project's key performance indicators. | The sensitivity analysis reveals that one or more plausible economic scenarios would significantly jeopardize the project's financial viability or timeline, rendering it unable to achieve its objectives. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Empty Coffers Catastrophe | Process/Financial | A3 | Financial Sustainability Planner | CRITICAL (20/25) |
| FM2 | The Data Deluge Disaster | Technical/Logistical | A2 | Head of Engineering | HIGH (12/25) |
| FM3 | The Community Backlash Breakdown | Market/Human | A1 | Community Liaison | HIGH (10/25) |
| FM4 | The Data Silo Stalemate | Process/Financial | A6 | Data Analyst | HIGH (12/25) |
| FM5 | The Expertise Erosion Event | Technical/Logistical | A5 | Project Manager | HIGH (10/25) |
| FM6 | The Logistical Lockdown | Market/Human | A4 | Head of Engineering | HIGH (12/25) |
| FM7 | The Economic Earthquake | Process/Financial | A9 | Financial Sustainability Planner | HIGH (10/25) |
| FM8 | The Green Tech Mirage | Technical/Logistical | A8 | Head of Engineering | HIGH (12/25) |
| FM9 | The Trust Tsunami | Market/Human | A7 | Community Liaison | HIGH (10/25) |


### Failure Modes

#### FM1 - The Empty Coffers Catastrophe

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A3
- **Owner**: Financial Sustainability Planner
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's funding model relies heavily on diversifying income streams beyond government grants. If private donations, corporate sponsorships, and carbon credit initiatives fail to materialize as projected, the project will face severe budget shortfalls. This will lead to a cascade of negative consequences:

*   Reduced sensor deployment: Fewer sensors deployed means less comprehensive data coverage.
*   Delayed remediation efforts: Lack of funds will postpone or cancel critical remediation activities.
*   Loss of key personnel: Budget cuts will force layoffs, impacting expertise and continuity.
*   Erosion of stakeholder trust: Failure to deliver on promises will damage the project's reputation and future funding prospects.

##### Early Warning Signs
- Private donation pledges fall below 50% of target by end of Q1.
- Corporate sponsorship agreements fail to materialize after 6 months of outreach.
- Carbon credit eligibility is denied by the certifying body.

##### Tripwires
- Total secured funding <= 25% of projected annual budget by Month 6.
- Carbon credit application rejected after final appeal.
- Major sponsor withdraws commitment, reducing funding by >= 15%.

##### Response Playbook
- Contain: Immediately freeze all non-essential spending and renegotiate existing contracts.
- Assess: Conduct a thorough review of the budget and identify areas for cost reduction and alternative funding sources.
- Respond: Implement a revised project plan with a reduced scope, focusing on the most critical monitoring and remediation activities.


**STOP RULE:** Total secured funding remains below 50% of the required annual budget after 9 months, rendering the project unsustainable.

---

#### FM2 - The Data Deluge Disaster

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Engineering
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project hinges on the assumption that the chosen sensor technology will provide accurate and reliable data under all weather conditions. However, if the sensors prove unreliable, the project will be inundated with inaccurate or missing data, leading to:

*   Flawed analysis: Inaccurate data will lead to incorrect conclusions about pollution levels and trends.
*   Ineffective remediation: Remediation efforts will be based on faulty data, potentially exacerbating the problem.
*   Delayed response: Missing data will delay the detection of pollution events, hindering timely intervention.
*   Loss of credibility: The project's reputation will be damaged if the data is deemed unreliable.

##### Early Warning Signs
- Sensor readings consistently deviate from manual samples by more than 10%.
- Sensor uptime falls below 85% due to weather-related malfunctions.
- Data transmission errors exceed 5% of total data volume.

##### Tripwires
- Sensor accuracy falls below 80% based on regular calibration checks.
- Sensor network uptime drops below 75% for more than 7 consecutive days.
- Data loss exceeds 10% of expected volume within a given month.

##### Response Playbook
- Contain: Immediately halt all data analysis and remediation efforts based on sensor data.
- Assess: Conduct a comprehensive review of the sensor network, including calibration, maintenance, and deployment procedures.
- Respond: Replace unreliable sensors with more robust alternatives, implement redundancy measures, and revise data analysis protocols to account for data inaccuracies.


**STOP RULE:** Sensor accuracy cannot be improved to above 85% after two rounds of sensor replacements and recalibration, rendering the data unreliable and the project unviable.

---

#### FM3 - The Community Backlash Breakdown

- **Archetype**: Market/Human
- **Root Cause**: Assumption A1
- **Owner**: Community Liaison
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The project assumes uniform community support for its remediation strategies. However, if the local community opposes the chosen methods (e.g., due to concerns about environmental impact, disruption of local activities, or lack of transparency), the project will face significant resistance, leading to:

*   Project delays: Protests and legal challenges will stall remediation efforts.
*   Increased costs: Addressing community concerns and implementing alternative solutions will increase expenses.
*   Reputational damage: Negative publicity will harm the project's credibility and future funding prospects.
*   Loss of social license: The project will lose the support of the community, making it difficult to achieve its goals.

##### Early Warning Signs
- Public meetings are sparsely attended, and feedback is overwhelmingly negative.
- Local media outlets publish critical articles about the project's remediation plans.
- A petition opposing the project's remediation strategies gains significant signatures (over 500).
- Community advisory board members resign in protest.

##### Tripwires
- Formal legal challenge filed by community group against remediation plan.
- Community support for the project, measured by survey, drops below 40%.
- Key community leaders publicly withdraw their support for the project.

##### Response Playbook
- Contain: Immediately suspend all remediation activities and initiate a dialogue with community leaders.
- Assess: Conduct a thorough review of the remediation plan, addressing community concerns and exploring alternative solutions.
- Respond: Revise the remediation plan based on community feedback, implement enhanced communication strategies, and build stronger relationships with local stakeholders.


**STOP RULE:** Irreconcilable community opposition persists after 6 months of mediation and revised remediation plans, making it impossible to proceed without significant social disruption.

---

#### FM4 - The Data Silo Stalemate

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A6
- **Owner**: Data Analyst
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project assumes seamless integration of collected data with existing environmental monitoring systems. However, if compatibility issues arise, the project will face significant hurdles:

*   Data silos: Inability to integrate data will create isolated datasets, hindering comprehensive analysis and decision-making.
*   Increased costs: Extensive data transformation and system modifications will require additional resources and budget.
*   Delayed reporting: Manual data transfer and formatting will delay the generation of timely reports for stakeholders.
*   Reduced impact: The project's findings will not be readily accessible to authorities, limiting its influence on policy and management decisions.

##### Early Warning Signs
- Pilot data integration exercise reveals significant data format inconsistencies.
- Existing databases lack the capacity to store the project's data volume.
- Data transfer protocols are incompatible with existing reporting systems.

##### Tripwires
- Data integration requires more than 40 hours per month of manual data manipulation.
- Data integration costs exceed 10% of the total data analysis budget.
- Key regulatory agencies refuse to accept the project's data due to compatibility issues.

##### Response Playbook
- Contain: Immediately halt all data integration efforts and focus on resolving compatibility issues.
- Assess: Conduct a thorough review of data formats, transfer protocols, and system requirements.
- Respond: Develop a data transformation strategy, implement necessary system modifications, and establish data sharing agreements with relevant authorities.


**STOP RULE:** Data integration remains unachievable after 6 months of troubleshooting and system modifications, rendering the project's data inaccessible to key stakeholders.

---

#### FM5 - The Expertise Erosion Event

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Project Manager
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The project assumes sufficient internal expertise to execute all aspects of the project. However, if critical skills gaps emerge, the project will suffer:

*   Compromised data quality: Lack of expertise in advanced data analysis techniques will lead to inaccurate or incomplete analysis.
*   Ineffective remediation: Insufficient knowledge of specialized environmental modeling will result in poorly designed remediation strategies.
*   Strained community relations: Inadequate skills in conflict resolution will damage relationships with local stakeholders.
*   Project delays: Reliance on external consultants will slow down decision-making and implementation.

##### Early Warning Signs
- Project team members struggle to implement advanced data analysis techniques.
- Remediation strategies are deemed inadequate by external environmental experts.
- Community engagement efforts are met with resistance and mistrust.

##### Tripwires
- Skills gap analysis reveals critical deficiencies in more than two key areas.
- External consultants are required for more than 20 hours per week to address skills gaps.
- Stakeholder satisfaction scores fall below 70% due to communication or conflict resolution issues.

##### Response Playbook
- Contain: Immediately identify and address critical skills gaps through targeted training or external support.
- Assess: Conduct a thorough review of the project's skills requirements and available resources.
- Respond: Recruit additional team members with specialized expertise, provide intensive training to existing staff, or engage external consultants on a long-term basis.


**STOP RULE:** Critical skills gaps persist after 3 months of training and external support efforts, jeopardizing the project's ability to achieve its objectives.

---

#### FM6 - The Logistical Lockdown

- **Archetype**: Market/Human
- **Root Cause**: Assumption A4
- **Owner**: Head of Engineering
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project assumes adequate existing infrastructure to support sensor deployment and maintenance. However, if logistical challenges arise due to infrastructure limitations, the project will face:

*   Deployment delays: Inaccessible sensor locations will postpone or complicate sensor installation.
*   Increased costs: Infrastructure upgrades (e.g., road repairs, power line extensions) will strain the budget.
*   Maintenance difficulties: Remote or inaccessible sensor locations will hinder regular maintenance and repairs.
*   Data gaps: Sensors in inaccessible locations will be prone to data loss due to power outages or communication failures.

##### Early Warning Signs
- Accessibility assessments reveal that more than 15% of sensor locations require significant infrastructure upgrades.
- Sensor deployment is delayed by more than 2 weeks due to logistical challenges.
- Maintenance crews experience difficulties accessing sensor locations due to road closures or port limitations.

##### Tripwires
- Infrastructure upgrades require more than 10% of the total project budget.
- Sensor deployment is delayed by more than 4 weeks due to logistical constraints.
- Sensor maintenance frequency is reduced by more than 20% due to accessibility issues.

##### Response Playbook
- Contain: Immediately reassess sensor locations and prioritize accessible sites.
- Assess: Conduct a thorough review of logistical challenges and infrastructure limitations.
- Respond: Revise the sensor deployment strategy, explore alternative transportation methods (e.g., drones, boats), and negotiate infrastructure upgrades with local authorities.


**STOP RULE:** More than 25% of sensor locations remain inaccessible after 3 months of logistical adjustments, rendering the sensor network incomplete and the project unviable.

---

#### FM7 - The Economic Earthquake

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Financial Sustainability Planner
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The project assumes stability in external economic factors. However, if significant economic shifts occur, the project will face:

*   Budget shortfalls: Currency fluctuations or reduced government funding will deplete the project's financial resources.
*   Project delays: Procurement delays due to increased costs will postpone sensor deployment and remediation efforts.
*   Reduced scope: The project will be forced to scale back its monitoring and remediation activities.
*   Loss of stakeholder support: Financial instability will erode trust and jeopardize future funding prospects.

##### Early Warning Signs
- The Danish Krone depreciates by more than 5% against the Euro.
- Government environmental funding is reduced by more than 10% in the annual budget.
- Inflation rates exceed projected levels, increasing project costs by more than 5%.

##### Tripwires
- The project budget is reduced by more than 15% due to external economic factors.
- Key performance indicators are projected to fall below target due to economic constraints.
- The project is deemed ineligible for government funding due to policy changes.

##### Response Playbook
- Contain: Immediately implement cost-cutting measures and renegotiate contracts.
- Assess: Conduct a thorough review of the budget and identify areas for cost reduction and alternative funding sources.
- Respond: Revise the project plan to prioritize essential activities, explore alternative funding models, and seek government assistance.


**STOP RULE:** The project budget is reduced by more than 25% due to external economic factors, rendering it unable to achieve its core objectives.

---

#### FM8 - The Green Tech Mirage

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Head of Engineering
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project assumes readily available and scalable environmentally-friendly remediation technologies. However, if these technologies prove inadequate or unavailable, the project will face:

*   Remediation delays: Lack of suitable technologies will postpone or complicate remediation efforts.
*   Increased costs: Reliance on less effective or more expensive technologies will strain the budget.
*   Environmental damage: Inadequate technologies will fail to effectively address pollution, potentially causing further harm.
*   Reputational damage: The project will be criticized for failing to use environmentally sound practices.

##### Early Warning Signs
- Market analysis reveals a limited number of environmentally-friendly remediation technologies suitable for Roskilde Fjord.
- Remediation technology vendors are unable to guarantee the effectiveness or scalability of their solutions.
- Environmental experts express concerns about the potential side effects of available technologies.

##### Tripwires
- No environmentally-friendly remediation technology can achieve a 50% reduction in key pollutants within a reasonable timeframe.
- The cost of environmentally-friendly remediation technologies exceeds the allocated budget by more than 20%.
- Environmental impact assessments reveal significant potential side effects from available technologies.

##### Response Playbook
- Contain: Immediately reassess remediation technology options and explore alternative approaches.
- Assess: Conduct a thorough review of the project's remediation goals and available resources.
- Respond: Revise the remediation strategy, prioritize less aggressive but more environmentally sound technologies, and seek expert advice on minimizing environmental impact.


**STOP RULE:** No environmentally-friendly remediation technology can be identified that meets the project's environmental and performance criteria, rendering the remediation component unviable.

---

#### FM9 - The Trust Tsunami

- **Archetype**: Market/Human
- **Root Cause**: Assumption A7
- **Owner**: Community Liaison
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The project assumes that the public will trust the data presented on the public data portal. However, if the public distrusts the data, the project will face:

*   Reduced engagement: Community members will be less likely to participate in citizen science initiatives or support the project's goals.
*   Increased opposition: Skeptical individuals will actively oppose the project, spreading misinformation and undermining its credibility.
*   Policy resistance: Policymakers will be less likely to act on the project's findings if the data is not widely trusted.
*   Project failure: Lack of public support will jeopardize the project's long-term viability and impact.

##### Early Warning Signs
- Social media sentiment analysis reveals a growing distrust of the project's data.
- Public data portal usage is low, and feedback is overwhelmingly negative.
- Community leaders express concerns about the accuracy or bias of the data.

##### Tripwires
- Survey data reveals that less than 50% of the public trusts the data presented on the public data portal.
- The public data portal receives more negative than positive feedback.
- Key community leaders publicly express distrust in the project's data.

##### Response Playbook
- Contain: Immediately launch a public awareness campaign to address concerns and build trust.
- Assess: Conduct a thorough review of the data collection, analysis, and presentation methods.
- Respond: Implement enhanced transparency measures, engage with skeptical individuals, and revise data communication strategies to address concerns and build trust.


**STOP RULE:** Public trust in the project's data remains below 40% after 6 months of intensive communication and transparency efforts, rendering the project unable to achieve its community engagement goals.
