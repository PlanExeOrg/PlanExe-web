### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Structure Defined

### 2. Project Manager circulates Draft SteerCo ToR v0.1 for review by Senior Management Representative, Technical Lead, Financial Officer, and potential Community and Environmental Agency Representatives.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager incorporates feedback and finalizes the Project Steering Committee Terms of Reference (ToR).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Senior Management formally appoints the Chair of the Project Steering Committee (Senior Management Representative).

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Manager, in consultation with the Steering Committee Chair, identifies and nominates potential members for the Project Steering Committee (Technical Lead, Financial Officer, Community Representative, Environmental Agency Representative).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Nominated Members List

**Dependencies:**

- Appointment of SteerCo Chair

### 6. Senior Management formally appoints the members of the Project Steering Committee.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Nominated Members List

### 7. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Emails

### 8. Hold the initial Project Steering Committee kick-off meeting to review the project plan, finalize governance processes, and assign initial tasks.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda
- Appointment Confirmation Emails

### 9. Project Manager defines roles and responsibilities of Core Project Team members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Roles and Responsibilities Matrix

**Dependencies:**

- Project Plan Approved

### 10. Project Manager establishes communication protocols and reporting procedures for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Communication Plan
- Reporting Templates

**Dependencies:**

- Roles and Responsibilities Matrix

### 11. Project Manager sets up project management tools and systems for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Management System Access
- Training Materials

**Dependencies:**

- Communication Plan

### 12. Project Manager develops a detailed work plan and schedule for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Detailed Work Plan
- Project Schedule

**Dependencies:**

- Project Management System Access

### 13. Project Manager identifies and documents key project assumptions and dependencies for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Assumptions Log
- Dependencies Log

**Dependencies:**

- Detailed Work Plan

### 14. Project Manager schedules the initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Assumptions Log
- Dependencies Log

### 15. Hold the initial Core Project Team kick-off meeting to review the project plan, finalize operational processes, and assign initial tasks.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda
- Assumptions Log
- Dependencies Log

### 16. Project Manager identifies and recruits independent technical experts for the Technical Advisory Group (Sensor Technology Expert, Data Analysis Expert, Remediation Technology Expert).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- List of Potential Experts
- Recruitment Plan

**Dependencies:**

- Project Plan Approved

### 17. Project Manager formally appoints the independent technical experts and the Environmental Scientist to the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Recruitment Plan

### 18. Project Manager defines the scope of the Technical Advisory Group's advisory role.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Scope Document

**Dependencies:**

- Appointment Confirmation Emails

### 19. Project Manager establishes communication protocols and reporting procedures for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Communication Plan
- Reporting Templates

**Dependencies:**

- Scope Document

### 20. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Communication Plan

### 21. Hold the initial Technical Advisory Group kick-off meeting to review the project plan, finalize advisory processes, and assign initial tasks.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 22. Project Manager develops a code of ethics for the project.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Code of Ethics

**Dependencies:**

- Project Plan Approved

### 23. Project Manager establishes a data privacy policy.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft Data Privacy Policy

**Dependencies:**

- Draft Code of Ethics

### 24. Project Manager identifies all relevant regulations and compliance requirements.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Compliance Requirements Document

**Dependencies:**

- Draft Data Privacy Policy

### 25. Project Manager identifies and recruits independent experts in ethics, law, and data privacy for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- List of Potential Experts
- Recruitment Plan

**Dependencies:**

- Compliance Requirements Document

### 26. Project Manager formally appoints the independent experts, the Community Representative, and themselves to the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Recruitment Plan

### 27. Project Manager establishes reporting procedures for ethical violations.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Reporting Procedures Document

**Dependencies:**

- Appointment Confirmation Emails

### 28. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Reporting Procedures Document

### 29. Hold the initial Ethics & Compliance Committee kick-off meeting to review the project plan, finalize compliance processes, and assign initial tasks.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 30. Project Manager identifies key stakeholders for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Stakeholder List

**Dependencies:**

- Project Plan Approved

### 31. Project Manager develops a communication plan for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Communication Plan

**Dependencies:**

- Stakeholder List

### 32. Project Manager establishes a community advisory board for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Community Advisory Board Members List

**Dependencies:**

- Communication Plan

### 33. Project Manager sets up channels for stakeholder feedback for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Feedback Channels Document

**Dependencies:**

- Community Advisory Board Members List

### 34. Project Manager defines metrics for measuring stakeholder satisfaction for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Stakeholder Satisfaction Metrics Document

**Dependencies:**

- Feedback Channels Document

### 35. Project Manager identifies and recruits the Community Representative (Chair), Communications Officer, Representatives from Local Municipality and Environmental Agency, Fishermen Representative, and Local Residents Representative for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- List of Potential Members
- Recruitment Plan

**Dependencies:**

- Stakeholder Satisfaction Metrics Document

### 36. Project Manager formally appoints the members of the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Recruitment Plan

### 37. Project Manager schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Emails

### 38. Hold the initial Stakeholder Engagement Group kick-off meeting to review the project plan, finalize engagement processes, and assign initial tasks.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda