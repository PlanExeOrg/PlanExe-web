**Verdict:** 🟢 ALLOW

**Rationale:** The prompt describes a pollution monitoring program, which is generally a safe topic.

### Violation Details

| Detail                | Value |
|-----------------------|-------|
| **Capability Uplift**     | No |