
## Audit - Corruption Risks

- Kickbacks or bribes paid to local engineering firms (Decision 1) in exchange for awarding the rapid-prototyping partnership contract or providing inflated invoices for custom sensor housing development.
- Nepotism or favoritism in the hiring of the two specialized staff required for internalized bi-weekly wet chemistry calibration (Decision 5), leading to the hiring of less competent personnel whose subsequent calibration errors distort monitoring results.
- Misuse of vessel charter contracts (Risk 4 mitigation) where the local maritime service provider inflates hourly rates or invoices for standby time not used during mobile sensor relocation, potentially disguised as legitimate operational costs.
- Improper influence or trading of favors with the Danish Environmental Protection Agency (Regulatory Engagement Timeline) to prematurely validate insufficient data quality (e.g., accepting preliminary O2/Nutrient readings as 'adjudication-ready' prematurely) in exchange for favorable future regulatory treatment.
- Misuse of project funds intended for expensive, specialized internal calibration equipment/consumables by diverting purchases through a preferred local supplier who inflates prices or substitutes substandard materials.

## Audit - Misallocation Risks

- Misallocation of capital budget (1.5M DKK) towards complex custom hardware prototyping that ultimately fails (Risk 1), necessitating a pivot to purchasing more expensive off-the-shelf modules late in the timeline, diverting funds from essential telemetry resiliency components (Risk 2 mitigation).
- Overstaffing or failure to implement the Staff Burn-Down Schedule (Missing Assumption 3), leading to unnecessary, high fixed personnel costs for the two calibration technicians long after the initial acute phase stabilizes, draining Opex budgeted for long-term data archival.
- Excessive spending on vessel charter services (Risk 4) driven by logistical failures or poor planning in the dynamic monthly relocations, resulting in operational costs exceeding the budgeted 10,000–20,000 DKK/month range, thereby reducing funds available for data SLA renewals (24-month SLA dependency).
- Inefficient allocation of specialized analyst time towards excessive daily public risk communication (Decision 6, Choice 2), drawing staff away from critical sensor troubleshooting and the 48-hour requirement for processing fishing sector feedback (Assumption 7).
- Double-spending on data storage infrastructure where high-cost indefinite raw data retention (Decision 7, Choice 1) is budgeted alongside necessary upfront investment in the 7-day battery/cellular backup for the central satellite hub (Assumption 5).

## Audit - Procedures

- Quarterly comprehensive review of all procurement contracts exceeding 25,000 DKK related to custom hardware development (Sensor Suite Selection Strategy), verifying that invoicing aligns with phased prototype validation milestones (30/90-day tests).
- Bi-weekly audit of the internalized calibration team's logs, including reconciliation of consumables usage against official wet chemistry validation records and cross-checking staff certifications (Instrument Calibration Cadence). Responsibility: Internal Audit function.
- Semi-annual physical verification audit of the central solar-powered satellite uplink station (Risk 2), inspecting battery health and confirming the functionality of the secondary encrypted cellular modem backup system.
- Monthly review of vessel charter invoices against documented sensor relocation logs (Risk 4) to ensure charges align precisely with the mileage/time required for the dynamic deployment methodology, checking against the local maritime service provider contract.
- Pre-submission compliance check (prior to 30-day regulatory reporting deadline per Assumption 4) on all Oxygen and Nutrient data sets forwarded to the Danish Environmental Protection Agency, verifying the data provenance tag indicates at least provisional acceptance status achieved via the Regulatory Acceptance Roadmap.

## Audit - Transparency Measures

- Establish a public-facing project dashboard updated at least daily, visualizing processed Oxygen and Nutrient levels for the fjord, explicitly tagging microplastics and pH data as 'Under Validation/Preliminary' based on the phased roadmap communicated to regulators (Decision 3).
- Publish the initial set of minutes or structured summaries from the informal data-sharing workshops held with municipal and national environmental agencies beginning one month post-deployment (Regulatory Engagement Timeline).
- Maintain a public, auditable registry detailing the criteria and results for the monthly sensor relocation decisions (Spatial Sampling Density Strategy), showing the movement rationale informed by preliminary environmental mapping.
- Implement a dedicated, managed whistleblower channel accessible by all external stakeholders (especially engineering partners and hired technicians) specifically covering concerns related to procurement fraud or calibration procedure deviations.
- Publish the formal 'Regulatory Acceptance Roadmap' documentation detailing the parallel validation process for custom sensor data fidelity versus external reference labs for the first 15 months of operation.