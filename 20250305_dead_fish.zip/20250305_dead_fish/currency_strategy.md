This plan involves money.

## Currencies

- **DKK:** The primary local currency for on-the-ground operational costs, sensor procurement within Denmark, local salaries, and maintenance within Roskilde.
- **EUR:** Relevant for purchasing specialized imported monitoring equipment or services from Eurozone manufacturers/vendors, given Denmark's proximity and trade ties.
- **USD:** Useful for budgeting large capital expenditures (like custom hardware development or satellite service contracts) which are often quoted internationally in USD.

**Primary currency:** DKK

**Currency strategy:** As the project is entirely localized to Denmark, the Danish Krone (DKK) will be the primary currency for daily operations and local transactions. Stable international currencies (EUR/USD) should be used for budgeting large capital purchases (e.g., customized sensors, satellite uplink hardware) to mitigate minor fluctuations against DKK when procuring materials from abroad.