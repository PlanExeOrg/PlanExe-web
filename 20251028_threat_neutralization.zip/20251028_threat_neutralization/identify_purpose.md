**Purpose:** personal

**Purpose Detailed:** A small-scale, goal-oriented plan involving a group of individuals with the intent to physically eliminate a perceived dangerous entity using weaponry.

**Topic:** Neutralizing a perceived threat (Superintelligence)