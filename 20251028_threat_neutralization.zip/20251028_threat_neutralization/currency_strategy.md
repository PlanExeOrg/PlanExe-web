This plan involves money.

## Currencies

- **USD:** The primary operational location inferred from the location list is the USA, making USD the default local transaction currency. USD is also the standard for international budgeting and potential weapon/equipment procurement.

**Primary currency:** USD

**Currency strategy:** Since the operational locations heavily involve the USA (Ashburn, National Labs), USD is the primary currency. Given the international scope of the potential targets (London, Singapore, Frankfurt), USD is maintained as the budget standard to handle potential cross-border logistics and procurement, mitigating risks associated with fluctuating local European or Asian currencies.