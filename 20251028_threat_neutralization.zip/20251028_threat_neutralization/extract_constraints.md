## Positive Constraints

- Involve me and 3 friends (4 people total)
- Goal: Shoot and neutralize a Superintelligence so it can no longer harm humans
- Assume access to powerful weapons
- Project start ASAP

## Negative Constraints

- Do not reference 'Superintelligence my ass'
