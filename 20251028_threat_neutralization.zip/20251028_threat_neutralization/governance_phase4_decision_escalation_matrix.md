**Budget Allocation Exceeding Authority for Ordnance Acquisition ($25,000+)**
Escalation Level: Kinetic Strategy Council (KSC)
Approval Process: Consensus among the three internal KSC members.
Rationale: Procurement of specialized, high-penetration ordnance exceeding the OET's $10,000 tactical limit, particularly if required for the 'Fallback Strike Protocol' contingency ($22,500 needed).
Negative Consequences: Procurement delays, reduced kinetic certainty, or immediate operational insolvency regarding primary ordnance.

**Inability to Achieve Required Synchronization Cadence (Lever 3 Failure)**
Escalation Level: Kinetic Strategy Council (KSC)
Approval Process: KSC reviews rehearsal reports and issues a mandatory directive (e.g., downgrade cadence or halt execution if rehearsal failure is critical).
Rationale: The core operational success hinges on 'near-perfect rehearsal' for simultaneous execution. Failure indicates a structural flaw in command or training execution.
Negative Consequences: High risk of coordinated kinetic failure during engagement, leading to operator death/capture or mission failure due to fragmented application of force.

**Conflict over Engagement Duration Constraint (Lever 4 Decision)**
Escalation Level: Kinetic Strategy Council (KSC)
Approval Process: KSC votes on the final end-criteria (10-minute override vs. physical confirmation metric).
Rationale: This decision defines the acceptable risk threshold for operator survival versus mission success, requiring strategic oversight that supersedes OET tactical preference.
Negative Consequences: Exposure beyond acceptable safety limits, leading to high probability of capture or attrition if the target resists the kinetic force longer than predicted.

**Disagreement on Target Manifestation Assessment (Lever 1)**
Escalation Level: Kinetic Strategy Council (KSC)
Approval Process: Mandatory 24-hour cooling-off period followed by an internal KSC vote.
Rationale: This is the foundational decision defining the mission reality; disagreement cannot be resolved tactically and risks committing resources to a non-existent or irrelevant target.
Negative Consequences: Total mission failure (attacking a phantom target) resulting in wasted resources, operational exposure, and failure to neutralize the actual threat.

**Unresolved Discrepancy in Forensic Material Staging (Lever 13)**
Escalation Level: Compliance & Forensic Audit Panel (CFAP)
Approval Process: Unanimous CFAP vote required to issue a 'Hold Execution' order; if blocked, escalated to KSC External Legal Counsel for advisory ruling.
Rationale: Failure to verify the staging of forensic countermeasures 12 hours prior to launch seriously jeopardizes the entire legal mitigation strategy (Risk 1/7), threatening the team post-operation.
Negative Consequences: Increased forensic traceability leading to immediate apprehension upon egress, rendering rapid exit strategy ineffective and triggering severe legal consequences.

**Need for Preemptive Budget Freeze due to Suspicious Ordnance Purchase**
Escalation Level: Compliance & Forensic Audit Panel (CFAP)
Approval Process: Unanimous CFAP agreement required to freeze funds over $5,000 USD.
Rationale: CFAP has direct authority to pause procurement funds if suspicious financial activity (Risk 4) suggests elevated security risk or budget circumvention before strategic oversight reviews it.
Negative Consequences: Inability to procure specialized kinetic assets on time, leading to timeline failure (Risk 4 mitigation failure) or masking illicit activity.