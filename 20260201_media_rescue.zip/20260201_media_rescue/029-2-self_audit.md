Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 16 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 3 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The project focuses on digitization and preservation, which are engineering and logistical challenges, not physics-defying feats.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (containerized digitization units) + market (global archives) + tech/process (AI, robotics, vintage equipment) + policy (cross-border data transfer) without independent evidence at comparable scale. No single project has combined all these elements.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Project Manager / Validation Report / 2025-Q4


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan uses terms like "AI-Driven Review Optimization" and "Data-as-a-Service Platform" without defining their business-level mechanism-of-action (inputs→process→customer value), owner, and measurable outcomes. The plan lacks one-pagers defining these strategic concepts.

**Mitigation**: Project Manager: Create one-pagers for each strategic concept, defining the value hypothesis, success metrics, and decision hooks. Due: 2025-Q4


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies regulatory, financial, and technical risks, but lacks explicit cascade analysis. For example, Risk 5 mentions "Cross-border data transfer regulations" but doesn't map the cascade: GDPR non-compliance → fines → budget shortfall. The plan also lacks a register.

**Mitigation**: Risk Manager: Create a risk register with owners/controls and map risk cascades (e.g., permit delay → missed peak season → revenue shortfall). Due: 2025-Q4


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a permit/approval matrix. The "Regulatory and Compliance Requirements" section lists permits but omits lead times. The "Secure Permits and Licenses" task in the WBS lacks dated predecessors or dependencies.

**Mitigation**: Project Manager: Create a permit/approval matrix with authoritative lead times, predecessors, and a NO-GO threshold on slip. Due: 2025-Q4


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not name funding sources, their status (e.g., LOI/term sheet/closed), the draw schedule, or runway length. The plan mentions a "realistic $250M budget" but lacks evidence of committed funding to support it.

**Mitigation**: CFO: Create a dated financing plan listing funding sources, their status, draw schedule, covenants, and a NO-GO on missed financing gates. Due: 2025-Q4


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget of $250M lacks substantiation via benchmarks or vendor quotes normalized by area. The plan mentions "reusable units, no facility construction, and lower overhead costs" but provides no per-area cost analysis to justify the figure.

**Mitigation**: CFO: Obtain ≥3 vendor quotes for MIU construction and operation, normalize costs per m²/ft², benchmark against comparable digitization projects, and adjust budget or de-scope. Due: 2025-Q4


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., "3.6+ million items over 10 years", "200+ petabytes") as single numbers without ranges or scenarios. The "Contingency Plan for Budget Insufficiency" only mentions a 10% contingency fund.

**Mitigation**: Project Manager: Conduct a sensitivity analysis or create best/worst/base-case scenarios for the most critical projection (items digitized). Due: 2025-Q4


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks engineering artifacts for build-critical components. There are no specs, interface contracts, acceptance tests, integration plan, or non-functional requirements. The plan mentions "robotic loading systems" but lacks interface definitions.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components. Due: 2025-Q4


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes claims like "Implement AI pre-screening to reduce review load by 80%" without providing evidence (e.g., pilot data, performance reports) to support this claim. The plan lacks a verifiable artifact.

**Mitigation**: AI Team: Conduct a pilot study to validate the AI pre-screening accuracy and efficiency, and produce a report with performance metrics. Due: 2025-Q4


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions abstract deliverables like "a new system" without specific, verifiable qualities. The plan refers to "AI-Driven Review Optimization and Human-in-the-Loop Governance" without defining acceptance criteria.

**Mitigation**: Project Manager: Define SMART criteria for "AI-Driven Review Optimization and Human-in-the-Loop Governance", including a KPI for review throughput (e.g., items reviewed per hour). Due: 2025-Q4


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes "3D printing equipment" and "CNC machining equipment" within the MIUs. These add cost/complexity but do not directly support the core goals of preserving at-risk media and enabling access to digitized content.

**Mitigation**: Engineering Team: Produce a one-page benefit case justifying the inclusion of 3D printing and CNC machining equipment, complete with a KPI, owner, and estimated cost, or move the feature to the project backlog. Due: 2025-Q4


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies the unicorn role as 'Vintage Equipment Maintenance Specialist', critical for maintaining aging equipment. This expertise is rare and essential for project success.

**Mitigation**: Project Manager: Conduct a market analysis to validate the availability of qualified technicians for vintage equipment roles within 60 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lists permits (Building, Electrical, Data Transfer, Hazardous Materials) but lacks a regulatory matrix mapping authority, artifact, lead time, and predecessors. The plan also lacks a fatal-flaw analysis.

**Mitigation**: Legal Team: Create a regulatory matrix (authority, artifact, lead time, predecessors) and a fatal-flaw analysis for permits. Due: 2025-Q4


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "long-term preservation" but lacks a funding plan beyond initial grants. The "Financial Strategy" section in the review plan asks, "What is the long-term funding strategy beyond initial grants?"

**Mitigation**: CFO: Develop a long-term financial model including revenue projections, operating costs, and funding sources to ensure sustainability beyond initial grants. Due: 2026-Q2


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks evidence of zoning or land-use approvals for MIU deployment at archive/university parking lots globally. The plan mentions "parking/loading dock for 40-foot containers" but lacks evidence of feasibility.

**Mitigation**: MIU Deployment Lead: Perform a fatal-flaw screen with authorities/experts; seek written confirmation where feasible; define fallback designs/sites and dated NO-GO thresholds tied to constraint outcomes. Due: 2025-Q4


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks evidence of redundancy or tested failover for critical external dependencies. The plan mentions "satellite and fiber connectivity" but lacks evidence of SLAs or tested failover plans.

**Mitigation**: IT Team: Secure SLAs with primary vendors, add a secondary supplier/path for connectivity, and test failover by 2026-Q1.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan pits 'MIU Crew' (incentivized by throughput) against 'Archive Staff' (incentivized by care/preservation). This creates conflict over handling speed vs. media safety. The plan lacks a shared objective.

**Mitigation**: Project Manager: Create a shared OKR for MIU Crew and Archive Staff focused on 'Items Digitized Without Damage' to align incentives. Due: 2025-Q4


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board. Due: 2025-Q4


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies several high risks (equipment failure, AI accuracy, regulatory compliance, funding) but lacks a cross-impact analysis. A single dependency (e.g., permit delay) could trigger a multi-domain failure (deployment delays, budget overruns).

**Mitigation**: Risk Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Due: 2025-Q4