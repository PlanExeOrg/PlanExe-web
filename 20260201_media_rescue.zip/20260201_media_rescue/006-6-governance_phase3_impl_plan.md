### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project start

### 2. Circulate Draft SteerCo ToR for review by Senior Management Representative, Project Director, Chief Technology Officer, Chief Financial Officer, Legal Counsel, and the Independent External Advisor (Archival Science).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1 circulated for review
- Review feedback from nominated members

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager incorporates feedback and finalizes the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Review feedback received
- Draft SteerCo ToR v0.1 circulated for review

### 4. Senior Management formally appoints the Project Steering Committee Chair.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Steering Committee Chair confirms membership of the Project Steering Committee.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Confirmed Membership List
- Acceptance confirmations from members

**Dependencies:**

- Appointment of Chair
- Final SteerCo ToR v1.0

### 6. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Confirmed Membership List

### 7. Hold initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation sent
- Confirmed Membership List

### 8. Project Manager drafts initial Terms of Reference (ToR) for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1

**Dependencies:**

- Project start

### 9. Circulate Draft PMO ToR for review by Technical Lead, Operations Lead, Finance Officer, Data Security Officer, and Compliance Officer.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1 circulated for review
- Review feedback from nominated members

**Dependencies:**

- Draft PMO ToR v0.1

### 10. Project Manager incorporates feedback and finalizes the Project Management Office (PMO) Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final PMO ToR v1.0

**Dependencies:**

- Review feedback received
- Draft PMO ToR v0.1 circulated for review

### 11. Project Manager confirms membership of the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Confirmed PMO Membership List
- Acceptance confirmations from members

**Dependencies:**

- Final PMO ToR v1.0

### 12. Project Manager schedules the initial Project Management Office (PMO) kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Confirmed PMO Membership List

### 13. Hold initial Project Management Office (PMO) kick-off meeting & assign initial tasks.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation sent
- Confirmed PMO Membership List

### 14. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project start

### 15. Circulate Draft Technical Advisory Group ToR for review by Lead Engineer, AI Specialist, Data Security Expert, Retired Engineer (Vintage Equipment), Robotics Specialist, and External Consultant (Data Storage).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1 circulated for review
- Review feedback from nominated members

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1

### 16. Project Manager incorporates feedback and finalizes the Technical Advisory Group Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Final Technical Advisory Group ToR v1.0

**Dependencies:**

- Review feedback received
- Draft Technical Advisory Group ToR v0.1 circulated for review

### 17. Project Manager identifies and recruits technical experts for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Nominated Members List

**Dependencies:**

- Final Technical Advisory Group ToR v1.0

### 18. Project Manager confirms membership of the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Confirmed Technical Advisory Group Membership List
- Acceptance confirmations from members

**Dependencies:**

- Nominated Members List

### 19. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Confirmed Technical Advisory Group Membership List

### 20. Hold initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation sent
- Confirmed Technical Advisory Group Membership List

### 21. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project start

### 22. Circulate Draft Ethics & Compliance Committee ToR for review by Legal Counsel, Data Protection Officer, Ethics Officer, Compliance Officer, Independent External Advisor (Ethics), and Stakeholder Representative (Archive).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1 circulated for review
- Review feedback from nominated members

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 23. Project Manager incorporates feedback and finalizes the Ethics & Compliance Committee Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Review feedback received
- Draft Ethics & Compliance Committee ToR v0.1 circulated for review

### 24. Legal Counsel formally appointed as Chair of the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 25. Ethics & Compliance Committee Chair confirms membership of the Ethics & Compliance Committee.

**Responsible Body/Role:** Ethics & Compliance Committee Chair

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Confirmed Ethics & Compliance Committee Membership List
- Acceptance confirmations from members

**Dependencies:**

- Appointment of Chair
- Final Ethics & Compliance Committee ToR v1.0

### 26. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Confirmed Ethics & Compliance Committee Membership List

### 27. Hold initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation sent
- Confirmed Ethics & Compliance Committee Membership List