*Roles Needed & Example People*

# Roles

## 1. Mobile Ingest Unit (MIU) Deployment Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: MIU Deployment Lead requires consistent availability and project-specific knowledge to manage the complex logistics of moving and setting up the containerized units.

**Explanation**:
Oversees the logistical deployment, setup, and relocation of the MIUs, ensuring smooth transitions between archive locations.

**Consequences**:
Deployment delays, increased transportation costs, and potential damage to the MIUs during transit.

**People Count**:
min 1, max 3, depending on the number of active MIUs

**Typical Activities**:
Planning and executing the transportation and setup of MIUs at archive locations. Coordinating with trucking companies, customs officials, and archive staff. Troubleshooting logistical issues and ensuring smooth transitions between sites. Managing deployment schedules and budgets.

**Background Story**:
Aisha Hassan grew up in Nairobi, Kenya, witnessing firsthand the challenges of preserving historical documents in a resource-constrained environment. She earned a degree in Logistics and Supply Chain Management from the University of Nairobi, followed by a Master's in International Transportation from MIT. Aisha has extensive experience in coordinating complex logistical operations across diverse terrains and regulatory landscapes. Her familiarity with containerized shipping and mobile deployment strategies, coupled with her passion for cultural preservation, makes her ideally suited to lead the MIU deployment efforts.

**Equipment Needs**:
Laptop with project management software, mobile phone, GPS navigation system, communication equipment (satellite phone or hotspot), ruggedized tablet for on-site documentation, and a vehicle suitable for accessing archive locations.

**Facility Needs**:
Office space for planning and coordination, access to archive locations (parking/loading docks), and secure storage for sensitive documents and equipment.

## 2. Vintage Equipment Maintenance Specialist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Vintage Equipment Maintenance Specialist needs specialized skills and consistent availability to maintain the aging equipment, making full-time employment the most reliable option.

**Explanation**:
Responsible for the repair, maintenance, and refurbishment of vintage tape decks, film scanners, and card readers, ensuring optimal equipment uptime.

**Consequences**:
Equipment downtime, digitization delays, and potential loss of irreplaceable media due to equipment malfunction.

**People Count**:
min 4, max 8, depending on the number of active MIUs and the complexity of the equipment

**Typical Activities**:
Diagnosing and repairing vintage tape decks, film scanners, and card readers. Sourcing replacement parts and fabricating custom components. Training junior technicians in vintage equipment maintenance techniques. Maintaining a detailed inventory of spare parts and equipment.

**Background Story**:
Elias Petrocelli, a native of Detroit, Michigan, practically grew up inside his grandfather's vintage radio repair shop. He possesses an encyclopedic knowledge of obsolete electronics, from vacuum tubes to reel-to-reel tape decks. Elias holds a degree in Electrical Engineering from Wayne State University and spent several years working as a field technician for a broadcast equipment company before striking out on his own as a vintage equipment restorer. His hands-on experience, combined with his deep understanding of the inner workings of these machines, makes him an invaluable asset for maintaining the CDDIN's fleet of vintage equipment.

**Equipment Needs**:
Specialized tools for vintage equipment repair (oscilloscopes, multimeters, soldering stations, calibration equipment), diagnostic software, parts inventory management system, 3D printer and CNC machine, and a comprehensive set of hand tools.

**Facility Needs**:
Workshop equipped with workbenches, ventilation, climate control, secure storage for parts and equipment, and access to a reference library of vintage equipment manuals.

## 3. AI Signal Processing and Metadata Extraction Specialist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: AI Signal Processing and Metadata Extraction Specialist requires in-depth knowledge of the project's AI systems and consistent availability for development and maintenance.

**Explanation**:
Develops, trains, and maintains the AI algorithms for signal reconstruction, error correction, and metadata extraction, optimizing the quality and efficiency of the digitization process.

**Consequences**:
Reduced signal reconstruction accuracy, increased human review load, and potential loss of valuable metadata.

**People Count**:
min 2, max 4, depending on the complexity of the AI algorithms and the volume of data processed

**Typical Activities**:
Developing and training AI algorithms for signal reconstruction, error correction, and metadata extraction. Optimizing AI performance and accuracy. Troubleshooting AI-related issues. Staying up-to-date on the latest advances in AI technology.

**Background Story**:
Mei Tanaka, born and raised in Tokyo, Japan, developed a fascination with signal processing and machine learning during her undergraduate studies at the University of Tokyo. She pursued a PhD in Computer Science at Stanford, specializing in AI-powered image and audio restoration. Mei has worked on projects ranging from enhancing historical photographs to cleaning up noisy audio recordings. Her expertise in AI algorithms, combined with her passion for preserving cultural heritage, makes her the perfect candidate to lead the CDDIN's AI signal processing efforts.

**Equipment Needs**:
High-performance workstation with GPU, AI development software (TensorFlow, PyTorch), access to cloud computing resources, large data storage, and specialized audio/video processing tools.

**Facility Needs**:
Office space with a quiet environment, access to a data center for AI model training, and a secure network connection for data transfer.

## 4. Data Governance and Compliance Officer

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Data Governance and Compliance Officer needs to be consistently available to ensure adherence to complex and evolving data privacy regulations.

**Explanation**:
Ensures compliance with data privacy regulations (GDPR, CCPA), manages data security protocols, and oversees data transfer agreements.

**Consequences**:
Legal challenges, fines, reputational damage, and potential loss of trust with archive partners.

**People Count**:
min 1, max 2, depending on the number of active MIUs and the complexity of the regulatory landscape

**Typical Activities**:
Ensuring compliance with data privacy regulations (GDPR, CCPA, etc.). Developing and implementing data security protocols. Managing data transfer agreements. Conducting data privacy audits. Staying up-to-date on the latest changes in data privacy law.

**Background Story**:
Jean-Pierre Dubois, originally from Strasbourg, France, has dedicated his career to navigating the complex world of data privacy and compliance. He holds a law degree from the University of Strasbourg and a Master's in Data Protection Law from the University of Oxford. Jean-Pierre has worked for multinational corporations, advising them on GDPR compliance and data security protocols. His deep understanding of international data privacy regulations, combined with his meticulous attention to detail, makes him ideally suited to oversee the CDDIN's data governance and compliance efforts.

**Equipment Needs**:
Laptop with data security software, access to legal databases, secure communication tools, and auditing software.

**Facility Needs**:
Secure office space with restricted access, access to legal counsel, and a secure network connection.

## 5. Archival Liaison and Collection Intake Coordinator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Archival Liaison and Collection Intake Coordinator requires consistent availability and project-specific knowledge to coordinate with archive staff and handle fragile media.

**Explanation**:
Works directly with archive staff to coordinate collection intake, perform initial sorting, and ensure proper handling of fragile media.

**Consequences**:
Inefficient collection intake, potential damage to fragile media, and strained relationships with archive partners.

**People Count**:
min 2, max 6, depending on the size of the archive collections and the number of active MIUs

**Typical Activities**:
Coordinating collection intake with archive staff. Performing initial sorting of media by format and condition. Ensuring proper handling of fragile media. Maintaining accurate records of collection inventory. Building strong relationships with archive partners.

**Background Story**:
Isabella Rodriguez grew up in Mexico City, where she volunteered at the National Archives, assisting with the preservation of historical documents. She earned a degree in Archival Studies from the National Autonomous University of Mexico and has worked as an archival assistant for several years. Isabella's experience in handling fragile media, combined with her strong communication skills and her passion for preserving cultural heritage, makes her the perfect candidate to serve as the Archival Liaison and Collection Intake Coordinator.

**Equipment Needs**:
Laptop with inventory management software, mobile phone, documentation tools, and specialized handling equipment for fragile media (gloves, archival boxes).

**Facility Needs**:
Access to archive locations, workspace for sorting and documenting media, and secure storage for fragile materials.

## 6. Human Review and Quality Assurance Specialist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Human Review and Quality Assurance Specialist requires consistent availability and project-specific knowledge to review flagged items and ensure data quality.

**Explanation**:
Reviews flagged items, verifies AI-generated metadata, and ensures the quality and accuracy of the digitized content.

**Consequences**:
Compromised data quality, legal and privacy incidents, and potential loss of valuable information due to errors in the digitization process.

**People Count**:
min 12, max 15, per active MIU

**Typical Activities**:
Reviewing flagged items for copyright, privacy, and classification issues. Verifying AI-generated metadata. Ensuring the quality and accuracy of digitized content. Identifying and correcting errors in the digitization process. Maintaining detailed records of review findings.

**Background Story**:
David Chen, a first-generation American whose parents immigrated from Hong Kong, developed a keen eye for detail while working in his family's antique shop. He holds a degree in History from UCLA and has worked as a fact-checker for a major news organization. David's meticulous nature, combined with his strong research skills and his commitment to accuracy, makes him an ideal candidate for the role of Human Review and Quality Assurance Specialist.

**Equipment Needs**:
High-resolution monitors, specialized review software, headphones, and access to a secure network for data transfer.

**Facility Needs**:
Quiet workspace with good lighting, ergonomic workstation, and access to a secure network.

## 7. Engineering Training Program Coordinator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Engineering Training Program Coordinator requires consistent availability and project-specific knowledge to manage the knowledge transfer program.

**Explanation**:
Manages the knowledge transfer program, coordinating training sessions with retired engineers and developing training materials for younger engineers.

**Consequences**:
Loss of critical knowledge and expertise in vintage equipment maintenance, leading to increased downtime and digitization delays.

**People Count**:
min 1, max 2, depending on the number of trainees and the scope of the training program

**Typical Activities**:
Coordinating training sessions with retired engineers. Developing training materials for younger engineers. Managing the training program budget. Tracking trainee progress. Evaluating the effectiveness of the training program.

**Background Story**:
Ingrid Schmidt, born in Berlin, Germany, witnessed the rapid technological advancements of the late 20th century. She earned a degree in Education from Humboldt University of Berlin and has spent her career developing and implementing training programs for various organizations. Ingrid's experience in curriculum development, combined with her passion for knowledge transfer and her organizational skills, makes her the perfect candidate to manage the CDDIN's Engineering Training Program.

**Equipment Needs**:
Laptop with training development software, presentation equipment, and access to retired engineers.

**Facility Needs**:
Training room with presentation equipment, access to workshop facilities, and office space for curriculum development.

## 8. Parts Acquisition and Inventory Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Parts Acquisition and Inventory Manager requires consistent availability and project-specific knowledge to manage the inventory of vintage equipment parts.

**Explanation**:
Responsible for sourcing, purchasing, and managing the inventory of vintage equipment parts, ensuring a steady supply of components for maintenance and repair.

**Consequences**:
Equipment downtime, digitization delays, and increased costs due to parts scarcity.

**People Count**:
min 2, max 4, depending on the scale of the parts inventory and the complexity of the supply chain

**Typical Activities**:
Sourcing and purchasing vintage equipment parts. Negotiating contracts with suppliers. Managing the parts inventory. Tracking parts usage. Ensuring a steady supply of components for maintenance and repair.

**Background Story**:
Raj Patel, hailing from Mumbai, India, has a knack for finding rare and hard-to-find items. He holds a degree in Business Administration from the University of Mumbai and has worked as a procurement specialist for several years. Raj's experience in sourcing and purchasing materials, combined with his negotiation skills and his resourcefulness, makes him an ideal candidate to manage the CDDIN's parts acquisition and inventory.

**Equipment Needs**:
Laptop with inventory management software, access to online parts databases, communication tools for contacting suppliers, and a vehicle for visiting suppliers.

**Facility Needs**:
Office space for managing inventory, access to a secure storage facility for parts, and a loading dock for receiving shipments.

---

# Omissions

## 1. Dedicated Cybersecurity Personnel

While cybersecurity threats are identified as a risk, there isn't a dedicated role focused solely on proactive security measures, continuous monitoring, and incident response. Given the sensitivity of archival data and the distributed nature of the MIUs, this is a critical omission.

**Recommendation**:
Add a 'Cybersecurity Specialist' role (either full-time or contracted) responsible for implementing security protocols, conducting regular audits, and responding to security incidents. This role should work closely with the Data Governance and Compliance Officer.

## 2. Environmental Impact Officer

The plan acknowledges the environmental impact of equipment but lacks a dedicated role to minimize the project's carbon footprint and ensure responsible disposal of hazardous materials. This is increasingly important for public perception and regulatory compliance.

**Recommendation**:
Assign an 'Environmental Impact Officer' (can be a part-time role or an additional responsibility for an existing team member) to develop and implement sustainable practices, manage waste disposal, and ensure compliance with environmental regulations.

## 3. Community Engagement Coordinator

While stakeholder engagement is mentioned, there isn't a specific role focused on building relationships with local communities and addressing their concerns. This is crucial for gaining community support and avoiding potential conflicts.

**Recommendation**:
Designate a 'Community Engagement Coordinator' (can be a part-time role or an additional responsibility for the Archival Liaison) to communicate the project's benefits, address community concerns, and foster positive relationships with local stakeholders.

---

# Potential Improvements

## 1. Clarify Responsibilities between MIU Deployment Lead and Archival Liaison

There's potential overlap between the MIU Deployment Lead (logistical deployment) and the Archival Liaison (collection intake). Clearer delineation of responsibilities will prevent confusion and ensure efficient operations.

**Recommendation**:
Define specific responsibilities for each role. The MIU Deployment Lead focuses on the physical movement and setup of the container, while the Archival Liaison focuses on the interaction with the archive and the intake of media. Create a RACI matrix to clarify who is Responsible, Accountable, Consulted, and Informed for each task.

## 2. Formalize Knowledge Transfer from Retired Engineers

The Engineering Training Program Coordinator role is good, but the plan should formalize the knowledge transfer process to ensure consistent and effective training.

**Recommendation**:
Develop a structured curriculum for the training program, including specific learning objectives, training materials, and assessment methods. Create a mentorship program pairing retired engineers with younger engineers for hands-on training.

## 3. Enhance Performance Metrics for Human Review Specialists

The plan mentions performance evaluation but lacks specific metrics for Human Review Specialists. Clear metrics will ensure quality and efficiency in the review process.

**Recommendation**:
Define specific performance metrics for Human Review Specialists, such as review speed, accuracy rate (identifying copyright/privacy issues), and consistency in applying review guidelines. Implement a system for tracking and monitoring these metrics.