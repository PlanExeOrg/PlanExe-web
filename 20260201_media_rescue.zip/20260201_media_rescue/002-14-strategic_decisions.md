## Primary Decisions
The vital few decisions that have the most impact.


The 'Critical' and 'High' impact levers address the fundamental project tensions of **Equipment Sustainability vs. Cost**, **Automation vs. Human Oversight**, **Deployment Speed vs. Reliability**, and **Centralization vs. Decentralization**. These levers collectively determine the project's operational efficiency, financial viability, and long-term impact. A key strategic dimension that could be strengthened is a more explicit focus on cross-border regulatory compliance, especially regarding data sovereignty and privacy.

### Decision 1: On-site Standardization and Phased Scaling
**Lever ID:** `3bb675aa-cd19-401e-b483-d0aa816243a7`

**The Core Decision:** This lever focuses on establishing standardized operational procedures and a phased approach to scaling the CDDIN project. It controls the rate of MIU deployment, the consistency of digitization workflows across sites, and the level of centralized oversight. The objective is to minimize disruption, ensure quality, and manage risks during the initial phases. Success is measured by adherence to standards, successful pilot operations, and smooth transitions between phases.

**Why It Matters:** Immediate: Standardizes intake and calibration across pilot sites, reducing setup time by ~40%. → Systemic: 25% faster scaling due to repeatable workflows and shared parts inventory across MIUs. → Strategic: Improves predictability and risk management, but increases governance overhead and reduces local improvisation.

**Strategic Choices:**

1. Standardize operations through phased on-site deployment with centralized governance and strict pilot controls to minimize disruption.
2. Modularize expansion by deploying mixed-location MIUs with autonomous AI orchestration and diversified partnerships to increase throughput.
3. Platformize digitization as a data service: on-demand MIU marketplace with licensing, blockchain provenance, and external revenue streams.

**Trade-Off / Risk:** Trade-off: Controls speed vs. quality/consistency. Weakness: The options fail to consider cross-border regulatory variance and staff retention dynamics that affect standardization.

**Strategic Connections:**

**Synergy:** This lever strongly synergizes with `On-site Mobility Deployment Strategy` by ensuring that each MIU deployment adheres to established standards. It also enhances `Vintage Equipment Ecosystem Resilience` by providing a controlled environment for testing and refining maintenance procedures.

**Conflict:** This lever can conflict with `Modular Fleet Orchestration and Decentralized Deployment` if standardization becomes too rigid, hindering the flexibility needed for diverse archive environments. It may also constrain `Data-as-a-Service Platform and Revenue Model` by delaying the rollout of advanced platform features.

**Justification:** *High*, High because it balances speed and quality, impacting the project's risk profile. Its synergy with deployment and equipment resilience, and conflict with modularity, highlight its central role in operational strategy.

### Decision 2: Vintage Equipment Ecosystem Resilience
**Lever ID:** `26c31715-8df2-4014-8122-eaae4d00aef2`

**The Core Decision:** This lever addresses the challenge of maintaining vintage equipment essential for the CDDIN project. It controls the approach to parts management, repair strategies, and the integration of predictive maintenance technologies. The objective is to ensure equipment uptime, minimize downtime, and preserve the knowledge required to maintain these obsolete systems. Success is measured by equipment uptime, the availability of spare parts, and the effectiveness of predictive maintenance.

**Why It Matters:** Immediate: Builds a large parts inventory and cannibalization capability to speed repairs. → Systemic: 40% faster repair cycles and 25% higher MIU uptime across the network. → Strategic: Lowers operational costs but increases long-term reliance on legacy hardware and environmental footprint.

**Strategic Choices:**

1. Consolidate vintage equipment into a centralized spare-parts warehouse, with strict cannibalization protocols and visible equipment aging.
2. Enable distributed, on-site local repairs using mobile toolkits and remote expert support, reducing shipping of parts.
3. Integrate advanced predictive maintenance using IoT sensors and AI to forecast failures and automate 3D-printed part production.

**Trade-Off / Risk:** Trade-off: Speed of repairs vs. long-term asset sustainability. Weakness: The options insufficiently address environmental impact and lifecycle replacement strategies for aging hardware.

**Strategic Connections:**

**Synergy:** This lever strongly synergizes with `Engineering training program` within `Vintage Equipment Ecosystem Resilience` by ensuring that trained personnel are available to perform repairs. It also enhances `On-site Mobility Deployment Strategy` by enabling on-site repairs, reducing the need to transport equipment for maintenance.

**Conflict:** This lever can conflict with `On-site Standardization and Phased Scaling` if a focus on local repairs leads to inconsistent maintenance practices across MIUs. It may also constrain `AI-Driven Review Optimization and Human-in-the-Loop Governance` if equipment failures disrupt digitization workflows and increase the need for human intervention.

**Justification:** *Critical*, Critical because it directly addresses the core hardware risk. Its synergy with training and conflict with standardization demonstrate its central role in ensuring the project's long-term viability given the vintage equipment.

### Decision 3: AI-Driven Review Optimization and Human-in-the-Loop Governance
**Lever ID:** `80d267bf-dfd5-4e54-b911-e9e27a287761`

**The Core Decision:** This lever focuses on optimizing the review process of digitized media using AI and human oversight. It controls the balance between AI pre-screening and human review, aiming to minimize the review bottleneck while maintaining accuracy and compliance. Key objectives include reducing the percentage of content requiring human review and ensuring zero legal/privacy incidents. Success is measured by the efficiency of AI pre-screening, the speed and accuracy of human reviewers, and the overall throughput of the digitization process.

**Why It Matters:** Immediate: 20% more items flagged for human review; Systemic: 40% faster feedback loop through continuous learning; Strategic: Improves accuracy but raises personnel costs and potential variable quality across multiple sites.

**Strategic Choices:**

1. Increase on-site human QA to maintain accuracy, keeping AI pre-screening at current levels without changes.
2. Sustain AI pre-screening at ~80% and expand full-time reviewers by 50% to improve coverage and quality control.
3. Create remote crowdsourced validation marketplace with micro-payments and continuous active learning, leveraging distributed workers and blockchain-based provenance for audit trails.

**Trade-Off / Risk:** Trade-off: Automation efficiency vs. human oversight. Weakness: The options fail to consider data privacy in crowdsourcing and risk of misinformation.

**Strategic Connections:**

**Synergy:** This lever strongly synergizes with `d45948e8-5eb5-45d4-874e-616a6a85b67f` (Metadata Standardization and Provenance Governance). Standardized metadata schemas enable more effective AI pre-screening, improving the accuracy of flagged items and reducing the human review load. This also enhances the overall quality and searchability of the digitized content.

**Conflict:** This lever has a potential conflict with `73dd49a1-eef0-4054-a9f7-a39b28093bf6` (Funding and Risk-Sharing Architecture). Increasing the scope of human review, especially with a crowdsourced marketplace, can significantly increase operational costs, requiring adjustments to the funding model and potentially impacting the project's financial sustainability.

**Justification:** *Critical*, Critical because it directly addresses the review bottleneck, a key project risk. Its synergy with metadata and conflict with funding highlight its central role in balancing efficiency and compliance.

### Decision 4: On-site Mobility Deployment Strategy
**Lever ID:** `4bb54f3a-9fbd-4a4e-bab3-f9dce89b1f41`

**The Core Decision:** This lever defines the strategy for deploying the mobile ingest units (MIUs) to various archive locations. It controls the scheduling, routing, and maintenance of the MIU fleet, aiming to maximize throughput while minimizing risks and costs. Key objectives include ensuring efficient utilization of MIUs, minimizing downtime, and adapting to diverse site conditions. Success is measured by the number of items digitized, the speed of deployment, and the overall operational efficiency of the MIU fleet.

**Why It Matters:** Immediate: On-site MIUs cut transport costs and shipping risk. Systemic: 25% faster scaling via parallel deployments across 6-12 sites; Strategic: broad coverage but heightened need for field technicians and capability.

**Strategic Choices:**

1. Leverage a fixed-schedule deployment plan prioritizing core archives with long-term commitments, emphasizing reliability, regulatory compliance, and proven hardware.
2. Scale to additional archives with diversified site types and enhanced remote diagnostics, introducing modular upgrades and standby MIUs to balance risk and throughput.
3. Operate a distributed, autonomous fleet using edge AI-driven routing, real-time reconfiguration, and drone-assisted logistics under a platform-as-a-service governance model.

**Trade-Off / Risk:** Trade-off: Controls Deployment Speed vs Reliability. Weakness: The options fail to consider regulatory variability across jurisdictions and parking-access constraints at certain sites.

**Strategic Connections:**

**Synergy:** This lever strongly synergizes with `8aee8736-9d4c-418a-950e-d25ab16df5a8` (Modular Fleet Orchestration and Decentralized Deployment). A well-orchestrated fleet, with modular upgrades and standby MIUs, allows for more flexible and efficient deployment, adapting to the specific needs of each archive and maximizing overall throughput. This ensures optimal resource utilization.

**Conflict:** This lever has a potential conflict with `3bb675aa-cd19-401e-b483-d0aa816243a7` (On-site Standardization and Phased Scaling). A highly standardized and phased approach might limit the flexibility of the deployment strategy, making it difficult to adapt to unexpected challenges or opportunities at different archive locations. This could slow down the overall digitization process.

**Justification:** *Critical*, Critical because it defines how the MIUs reach archives, directly impacting throughput and cost. Its synergy with fleet orchestration and conflict with standardization make it a central operational lever.

### Decision 5: Metadata Ecosystem & Knowledge Management Strategy
**Lever ID:** `ae5e345c-0f00-4899-b87a-b7786c05da89`

**The Core Decision:** This lever focuses on the creation, management, and governance of metadata associated with the digitized media. It controls the metadata schemas, access protocols, and provenance tracking mechanisms. The objectives are to ensure interoperability, facilitate search and discovery, and protect intellectual property rights. Success is measured by the completeness, accuracy, and accessibility of the metadata, as well as its ability to support downstream applications and research.

**Why It Matters:** Immediate: AI-generated metadata accelerates cataloging; Systemic: 40% more searchable items via standardized schemas; Strategic: elevates discovery potential but requires governance to avoid fragmentation and interoperability burdens, and ownership governance alignment.

**Strategic Choices:**

1. Standardize schemas and centralized metadata governance to ensure interoperability across archives and vendors.
2. Develop collaborative metadata schemas with open licenses and distributed catalogs, enabling cross-archive search and community curation.
3. Launch a decentralized metadata layer with tokenized access, smart contracts, and on-chain provenance to incentivize contributions and enforce rights.

**Trade-Off / Risk:** Trade-off: Controls Discoverability vs Rights/Governance. Weakness: The options fail to consider licensing complexities for public access across archives.

**Strategic Connections:**

**Synergy:** This lever strongly synergizes with `80d267bf-dfd5-4e54-b911-e9e27a287761` (AI-Driven Review Optimization and Human-in-the-Loop Governance). High-quality, standardized metadata enables more effective AI pre-screening, improving the accuracy of flagged items and reducing the human review load. This also enhances the overall quality and searchability of the digitized content.

**Conflict:** This lever has a potential conflict with `04f18b79-3708-489f-aa68-de5cf878a97b` (Data-as-a-Service Platform and Revenue Model). A decentralized metadata layer with tokenized access might create complexities in managing rights and revenue sharing, potentially hindering the development of a viable data-as-a-service platform. This requires careful balancing of incentives and governance.

**Justification:** *Critical*, Critical because it governs data discoverability and long-term value. Its synergy with AI review and conflict with data-as-a-service highlight its role in balancing access and rights.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Modular Fleet Orchestration and Decentralized Deployment
**Lever ID:** `8aee8736-9d4c-418a-950e-d25ab16df5a8`

**The Core Decision:** This lever governs the deployment and coordination of the MIU fleet. It controls the level of centralization in deployment decisions, the use of AI for orchestration, and the degree of autonomy granted to individual units. The objective is to optimize efficiency, responsiveness, and scalability while balancing logistical risks and governance requirements. Key success metrics include fleet utilization rates, processing throughput, and adherence to compliance standards.

**Why It Matters:** Immediate: Deploys autonomous AI-driven orchestration to allocate MIUs to sites with the greatest backlog. → Systemic: 40% reduction in downtime and idle capacity due to dynamic reallocation. → Strategic: Boosts resilience and scalability but raises cybersecurity exposure and governance complexity.

**Strategic Choices:**

1. Centralize deployment through manual allocation and strict site-by-site approvals to minimize logistical risk.
2. Hybrid orchestration using AI-guided allocation with human-in-the-loop oversight to balance efficiency and governance.
3. Open-platform fleet with autonomous AI orchestration across borders and third-party operators funded by a shared risk pool.

**Trade-Off / Risk:** Trade-off: Controls autonomy vs. visibility. Weakness: The options do not sufficiently address cross-border data sovereignty and security monitoring requirements.

**Strategic Connections:**

**Synergy:** This lever synergizes with `AI-Driven Review Optimization and Human-in-the-Loop Governance` by leveraging AI to optimize MIU allocation and workflow. It also enhances `On-site Mobility Deployment Strategy` by enabling dynamic adjustments to deployment plans based on real-time data and archive needs.

**Conflict:** This lever can conflict with `On-site Standardization and Phased Scaling` if a highly decentralized approach undermines the consistency of digitization processes. It may also constrain `Funding and Risk-Sharing Architecture` if autonomous deployment decisions increase operational risks without proper oversight.

**Justification:** *High*, High because it governs fleet efficiency and responsiveness. Its synergy with AI-driven review and conflict with standardization show it's a key decision point for balancing autonomy and control.

### Decision 7: Data-as-a-Service Platform and Revenue Model
**Lever ID:** `04f18b79-3708-489f-aa68-de5cf878a97b`

**The Core Decision:** This lever defines the revenue model and platform strategy for the digitized data produced by the CDDIN project. It controls the licensing terms, access models, and revenue-sharing arrangements for the data. The objective is to generate sustainable revenue streams, incentivize participation, and ensure broad access to the preserved content. Success is measured by revenue generated, user adoption rates, and the impact of the data on research and education.

**Why It Matters:** Immediate: Introduces data licensing and external revenue streams from digitized assets. → Systemic: 20-30% uplift in total project funding through licensing deals and collaborations. → Strategic: Transforms the initiative into a platform with external incentives but risks mission drift and privacy concerns.

**Strategic Choices:**

1. Licensing: Fixed-term licenses for metadata and digital outputs to researchers and educators.
2. Licensing: Dynamic, tiered access for institutions with royalty-based revenue sharing.
3. Platformize digitization as a data service with cross-border licensing, provenance, and external revenue streams.

**Trade-Off / Risk:** Trade-off: External monetization vs mission focus. Weakness: Fails to specify governance controls for data licensing across multiple jurisdictions and partners.

**Strategic Connections:**

**Synergy:** This lever synergizes with `Metadata Standardization and Provenance Governance` by ensuring that data is properly tagged and tracked for licensing and revenue sharing. It also enhances `AI-Driven Review Optimization and Human-in-the-Loop Governance` by providing a mechanism for funding ongoing review and curation efforts.

**Conflict:** This lever can conflict with `On-site Standardization and Phased Scaling` if a focus on revenue generation leads to premature platformization before standards are fully established. It may also constrain `Funding and Risk-Sharing Architecture` if overly restrictive licensing terms limit access and reduce the overall impact of the project.

**Justification:** *Medium*, Medium because it impacts funding and sustainability, but its conflict with standardization suggests it's secondary to core operational concerns. It's more about monetization than core project execution.

### Decision 8: Metadata Standardization and Provenance Governance
**Lever ID:** `d45948e8-5eb5-45d4-874e-616a6a85b67f`

**The Core Decision:** This lever governs the creation, management, and governance of metadata associated with the digitized media. It controls the metadata schema, access policies, and provenance tracking mechanisms. The objective is to ensure data discoverability, interoperability, and trustworthiness. Success is measured by metadata completeness, accuracy, and the extent to which it facilitates data access and reuse.

**Why It Matters:** Immediate: Establishes common metadata schema; Systemic: 25% reduction in post-processing errors due to consistent tagging; Strategic: Enables cross-institution sharing, but may slow initial onboarding and require governance overhead and compliance.

**Strategic Choices:**

1. Maintain internal, standardized metadata schema aligned with existing national standards, controlled by a central governance team.
2. Adopt cross-institution metadata federation with shared vocabularies and API-based access, enabling interoperability across partners.
3. Leverage blockchain-based provenance, smart-contract IP rights, and tokenized access to digitized assets within an open data marketplace.

**Trade-Off / Risk:** Trade-off: Data interoperability vs. governance overhead and potential bottlenecks. Weakness: The options fail to consider privacy constraints for sensitive archives and compatibility with legacy, non-standard formats.

**Strategic Connections:**

**Synergy:** This lever strongly synergizes with `AI-Driven Review Optimization and Human-in-the-Loop Governance` by leveraging AI to extract and validate metadata. It also enhances `Data-as-a-Service Platform and Revenue Model` by providing the foundation for licensing and access control.

**Conflict:** This lever can conflict with `On-site Standardization and Phased Scaling` if a rigid metadata schema hinders the ability to adapt to diverse archive collections. It may also constrain `Modular Fleet Orchestration and Decentralized Deployment` if centralized governance limits the flexibility of individual MIUs to customize metadata workflows.

**Justification:** *Medium*, Medium because while important for data quality, its impact is less direct than equipment resilience or deployment strategy. Its synergy with AI review is notable, but not decisive.

### Decision 9: Funding and Risk-Sharing Architecture
**Lever ID:** `73dd49a1-eef0-4054-a9f7-a39b28093bf6`

**The Core Decision:** This lever governs the financial structure of the CDDIN project, determining how it is funded and how risks are shared among stakeholders. It controls the sources of funding, the allocation of costs, and the incentives for participation. The objectives are to secure sufficient funding to support the project's ambitious goals, mitigate financial risks, and align the interests of all parties involved. Success is measured by the project's financial stability, its ability to attract funding, and its cost-effectiveness.

**Why It Matters:** Immediate: Aligns cash flow with milestones; Systemic: 25% risk transfer to private partners via milestone-based contracts; Strategic: Accelerates scale but may complicate governance and accountability and data sharing complexities risks.

**Strategic Choices:**

1. Maintain current phased funding with government grants and strict cost controls.
2. Implement multi-source funding, cost-sharing with partners, and performance milestones.
3. Launch a platform finance model: tokenized fundraising, revenue-sharing, data-as-a-service marketplaces; archives pay-per-item, with securitization of petabytes.

**Trade-Off / Risk:** Trade-off: Public funding stability vs. private capital-driven speed. Weakness: The options fail to consider long-term governance and accountability across multiple partners.

**Strategic Connections:**

**Synergy:** This lever strongly synergizes with `04f18b79-3708-489f-aa68-de5cf878a97b` (Data-as-a-Service Platform and Revenue Model). A successful data-as-a-service platform can generate revenue streams that supplement traditional funding sources, improving the project's financial sustainability and attracting private investment. This creates a virtuous cycle of growth and innovation.

**Conflict:** This lever has a potential conflict with `80d267bf-dfd5-4e54-b911-e9e27a287761` (AI-Driven Review Optimization and Human-in-the-Loop Governance). A more conservative funding approach might limit the resources available for AI development and human review, potentially compromising the accuracy and compliance of the digitization process. This could lead to legal or privacy incidents.

**Justification:** *High*, High because it governs the project's financial stability and risk mitigation. Its synergy with data-as-a-service and conflict with AI review show it's a key trade-off between public and private funding.
