## Suggestion 1 - The Crowley Program for Modern Conflict Archives

The Crowley Program for Modern Conflict Archives at Stanford University aims to preserve and make accessible endangered archives related to modern conflict. This includes digitizing materials such as audio recordings, video footage, photographs, and documents from various conflicts around the world. The program focuses on providing access to these materials for researchers, policymakers, and the public.

### Success Metrics

Number of archival collections digitized.
Number of digitized items made available online.
Number of researchers and users accessing the digital archives.
Successful implementation of metadata standards for discoverability.
Preservation of fragile and at-risk materials.

### Risks and Challenges Faced

Securing funding for digitization and preservation.
Obtaining permissions and rights clearances for digitized materials.
Managing the technical challenges of digitizing diverse media formats.
Ensuring the long-term preservation of digital assets.
Addressing the ethical considerations of making conflict-related materials accessible.

### Where to Find More Information

https://library.stanford.edu/projects/crowley-program-modern-conflict-archives

### Actionable Steps

Contact: Crowley Program staff via the Stanford University Libraries website.
Role: Inquire about their digitization workflows, metadata standards, and preservation strategies.
Communication Channel: Email or phone call through the contact information provided on the website.

### Rationale for Suggestion

The Crowley Program shares the objective of digitizing and preserving at-risk media. While not containerized, it deals with similar challenges of diverse media formats, rights clearances, and long-term preservation. Their experience in managing a large-scale digitization project and making it accessible online is highly relevant. The Crowley Program also deals with the ethical considerations of sensitive materials, which is relevant to the legal and review framework of the CDDIN project.
## Suggestion 2 - Internet Archive's Mass Book Digitization

The Internet Archive operates a large-scale book digitization program, scanning millions of books from libraries and archives worldwide. This project involves setting up digitization centers, developing automated scanning workflows, and creating digital copies of books that are made available online. The project aims to preserve and provide access to a vast collection of books, including many that are rare or out of print.

### Success Metrics

Number of books digitized.
Number of books made available online.
Number of users accessing the digital books.
Cost per book digitized.
Efficiency of the digitization workflow.

### Risks and Challenges Faced

Managing the logistics of transporting and scanning large volumes of books.
Developing efficient and automated scanning workflows.
Ensuring the quality of the digital scans.
Addressing copyright issues and obtaining permissions.
Securing funding for the ongoing digitization effort.

### Where to Find More Information

https://archive.org/details/scanning
https://blog.archive.org/2020/07/24/the-internet-archives-book-scanning-operations-a-behind-the-scenes-look/

### Actionable Steps

Contact: Internet Archive staff through their website.
Role: Inquire about their digitization workflows, equipment, and quality control processes.
Communication Channel: Email or online contact form.

### Rationale for Suggestion

The Internet Archive's book digitization project is relevant due to its scale and focus on automation. While it deals with books rather than tapes or films, the challenges of developing efficient scanning workflows, ensuring quality, and managing copyright issues are similar. Their experience in setting up digitization centers and managing a large-scale digitization effort can provide valuable insights. The Internet Archive's focus on open access is also relevant to the CDDIN project's goal of enabling access to digitized content.
## Suggestion 3 - National Film and Sound Archive of Australia (NFSA) Digitisation Program

The NFSA is undertaking a large-scale digitisation program to preserve Australia's audiovisual heritage. This involves digitising film, audio, and video recordings from their collection, which includes a wide range of formats and materials. The program aims to ensure the long-term preservation of these materials and make them accessible to the public.

### Success Metrics

Number of film, audio, and video recordings digitized.
Percentage of the collection digitized.
Number of digitized items made available online.
Quality of the digital copies.
Adherence to preservation standards.

### Risks and Challenges Faced

Managing the technical challenges of digitising diverse media formats.
Ensuring the quality of the digital copies.
Addressing copyright issues and obtaining permissions.
Securing funding for the ongoing digitization effort.
Managing the logistics of handling and digitising fragile materials.

### Where to Find More Information

https://www.nfsa.gov.au/collection/about-collection/digitisation

### Actionable Steps

Contact: NFSA staff through their website.
Role: Inquire about their digitization workflows, equipment, and preservation strategies.
Communication Channel: Email or online contact form.

### Rationale for Suggestion

The NFSA's digitisation program is highly relevant due to its focus on audiovisual materials and its commitment to preservation standards. Their experience in managing the technical challenges of digitising diverse media formats, ensuring quality, and addressing copyright issues is directly applicable to the CDDIN project. The NFSA's focus on making the digitized materials accessible to the public is also relevant to the CDDIN project's goals. While geographically distant, the NFSA's expertise in audiovisual preservation makes it a valuable reference.

## Summary

The suggested projects provide relevant insights into large-scale digitization efforts, addressing challenges related to diverse media formats, automation, quality control, copyright issues, and long-term preservation. The Crowley Program offers insights into managing conflict archives, the Internet Archive into mass book digitization, and the NFSA into audiovisual preservation. These projects collectively provide a comprehensive understanding of the challenges and best practices in the field of digital preservation.