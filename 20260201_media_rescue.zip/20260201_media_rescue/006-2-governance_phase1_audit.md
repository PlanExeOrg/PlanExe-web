
## Audit - Corruption Risks

- Bribery of archive staff to prioritize certain collections for digitization, potentially based on personal relationships or financial incentives.
- Kickbacks from vintage equipment suppliers in exchange for inflated prices or overlooking equipment defects.
- Conflicts of interest in the selection of AI processing vendors, where project personnel have undisclosed financial ties.
- Misuse of confidential information regarding archive collections for personal gain, such as identifying valuable items for private acquisition.
- Nepotism in hiring MIU crew or reviewers, leading to unqualified personnel and compromised quality control.

## Audit - Misallocation Risks

- Inflated expenses for MIU maintenance and repairs, with falsified invoices or unnecessary work orders.
- Double-spending on equipment acquisition, purchasing the same items from multiple sources without proper reconciliation.
- Inefficient allocation of reviewer time, focusing on low-priority content while neglecting critical items flagged by AI.
- Unauthorized use of MIU resources for personal projects or commercial activities unrelated to the project's goals.
- Misreporting of digitization progress to secure continued funding, exaggerating the number of items processed or the amount of data recovered.

## Audit - Procedures

- Conduct quarterly internal audits of MIU expenses, focusing on maintenance, repairs, and travel reimbursements.
- Implement a post-project external audit to assess the overall financial management and compliance of the CDDIN project.
- Establish contract review thresholds for equipment purchases and vendor selection, requiring independent verification for contracts exceeding a specified amount.
- Implement a detailed expense workflow for all project-related expenditures, requiring multiple levels of approval and supporting documentation.
- Perform annual compliance checks to ensure adherence to data privacy regulations (GDPR, CCPA) and data transfer agreements.

## Audit - Transparency Measures

- Create a public progress dashboard displaying the number of items digitized, the amount of data recovered, and the project's financial status.
- Publish minutes of key project governance meetings, including decisions related to equipment acquisition, vendor selection, and deployment strategy.
- Establish a confidential whistleblower mechanism for reporting suspected fraud, corruption, or ethical violations within the project.
- Provide public access to relevant project policies and reports, including the data privacy policy, the equipment maintenance plan, and the stakeholder engagement strategy.
- Document and publish the selection criteria for major decisions, such as the choice of archive partners, AI processing vendors, and MIU deployment locations.