This plan involves money.

## Currencies

- **USD:** Primary currency for budgeting, reporting, and international transactions.
- **EUR:** Relevant for operations and potential acquisitions in Europe.

**Primary currency:** USD

**Currency strategy:** USD is recommended for budgeting and reporting to mitigate risks from currency fluctuations. EUR may be used for local transactions in Europe. Hedging strategies should be considered to manage exchange rate risks.