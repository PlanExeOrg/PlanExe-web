This plan implies one or more physical locations.

## Requirements for physical locations

- Parking lot or loading dock access for 40-foot shipping containers
- Power connectivity (or generator operation)
- Data transmission capabilities (satellite or fiber)
- Climate control (temperature and humidity)
- Secure location for media storage and processing

## Location 1
Global

Archive and University Parking Lots/Loading Docks

Specific archive and university addresses to be determined based on partnerships

**Rationale**: These locations provide direct access to the media collections, eliminating shipping risks and satisfying insurance requirements. They also offer the necessary infrastructure for power and data connectivity.

## Location 2
USA

Decommissioned TV/Radio Stations

Various locations across the USA

**Rationale**: These facilities can serve as central hubs for equipment acquisition, cannibalization, and engineering training. They often have existing infrastructure for handling media and technical equipment.

## Location 3
Europe

Former Industrial Sites

Various locations across Europe

**Rationale**: These sites can be repurposed as secure storage and processing facilities for digitized content. They often offer ample space and robust infrastructure.

## Location 4
Global

Data Centers with Archival Storage

Various locations worldwide

**Rationale**: These locations provide secure and reliable storage for the digitized data, with robust infrastructure for data transmission and access control.

## Location Summary
The plan requires mobile ingest units to be deployed at archive and university parking lots/loading docks globally. Decommissioned TV/radio stations in the USA can serve as equipment hubs. Former industrial sites in Europe can be repurposed for storage. Data centers worldwide will provide secure archival storage.