**Purpose:** business

**Purpose Detailed:** Large-scale, distributed archival digitization project to preserve at-risk historical media by deploying a fleet of modular, 40-foot container units that travel to archives and facilities to digitize media on-site using robotic handling and AI-powered processing; includes vintage equipment acquisition, training, maintenance, and a phased deployment plan funded by government, cultural, and private partners, with objectives to digitize hundreds of thousands of items and recover petabytes of data over a decade while eliminating shipping and minimizing legal/privacy risks.

**Topic:** Containerized Mobile Ingest Units for On-site Media Digitization (CDDIN)