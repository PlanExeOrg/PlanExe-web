# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** Societal-scale, multi-state civil-protection operation: evacuation of about 35,000 visitors and 800 staff (user constraint) within T+6 hours, expansion to a 100 km Zone One with several gateway towns, and a contingency to 500 km. Involves NPS, FEMA Regions 8 and 10, Montana, Wyoming and Idaho, the National Guard and the FAA.

**Risk and Novelty:** Very high stakes with a hard 72-hour window and a stated 40% probability of a VEI-6+ eruption (user constraint). Few operational precedents exist for a Yellowstone-scale event. The main risks are single-point road chokepoints (landslide-blocked South Entrance, two-lane mountain corridors), ash-degraded communications and power, and a Scenario Beta that exceeds shelter and road capacity. The plan is about executing proven emergency-management methods (contraflow, IPAWS, Unified Command) under extreme time pressure, not about innovation.

**Complexity and Constraints:** High operational complexity: contraflow on US-191, US-20 and US-89 to I-90, cross-jurisdiction authority transfer, FEMA Region 8/10 and state mutual-aid seams, aviation grounding in ZLC and ZSE, comms failure planning, water convoys within 12 hours, N95 pre-staging for 100,000 people (user constraint) and grid-failure fuel priorities. Constraints are fixed: a UC in Denver, Bozeman and Idaho Falls shelters, an explicit NPS-to-governor handoff, and a trigger point for the 500 km expansion.

**Domain and Tone:** Government public-safety and emergency-management planning. Tone is operational, directive and specific (routes, agencies, hourly Gantt chart, risk register, resource matrix), with an emphasis on life preservation and continuity of operations.

**Holistic Profile:** A high-stakes, time-compressed, physically executed government evacuation plan. It needs reliable, pre-authorized decision rules, higher exit capacity, clear command and robust public alerting. It calls for a balanced, execution-credible posture with explicit escalation triggers, not an experimental or minimalist one.

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Pragmatic Foundation
**Strategic Logic:** Add the East Entrance gate to spread load across three exits, pre-authorize a written trigger matrix so the VEI-7 decision does not wait on meetings, and place a forward command element near the corridors while Denver handles federal resource requests. Shelter sites are chosen at T+6 hours from the actual wind and plume forecast, which balances preparedness against the cost of staging everything in advance.

**Fit Score:** 8/10

**Why This Path Was Chosen:** A pre-authorized trigger matrix directly answers the requirement for a Scenario Beta trigger point and an immediate 500 km expansion, and IPAWS plus National Guard signal bridging is the comms approach the plan names. A third exit adds capacity, and the forward command element complements Denver, though the boundary handoff and the East Entrance's role in the Cody evacuation need explicit definition.

**Key Strategic Decisions:**

- **Egress Corridor Allocation and Contraflow Architecture:** Split outbound flow across three gates by adding the East Entrance toward Cody on US-14/16/20, assigning each park district to a fixed exit so no vehicle crosses the interior to reach another gate.
- **Escalation Trigger and Evacuation Release Doctrine:** Pre-authorize a written, threshold-based trigger matrix tying specific USGS indicators to automatic zone expansion, with the VEI-7 500 km order issued by the Unified Command without further approval.
- **Command Structure and Jurisdictional Handoff Model:** Place a forward Unified Command element in Bozeman or Livingston alongside the Denver RRCC, giving the incident commander direct sight of the corridors while Denver handles federal resource requests.
- **Communications Continuity Stack Under Ash and Tremor:** Rely on IPAWS, Wireless Emergency Alerts and NOAA Weather Radio as the primary public channel, with National Guard signal units bridging responder radios between agencies at the gateway towns.
- **Refugee Intake and Shelter Siting Strategy:** Select final shelter locations at T+6 hours from the forecast wind and plume model, keeping a ranked list of pre-surveyed schools and arenas on every side of the park.

**The Decisive Factors:**

- **Matches the plan's risk posture:** a 72-hour window with a 40% eruption probability (user constraint) and an "immediate" 500 km expansion need a pre-authorized, threshold-based trigger matrix. Scenario Beta is then ordered by the Unified Command without waiting on meetings.
- **Addresses the bottleneck risk:** adding the East Entrance toward Cody spreads load beyond two chokepoints. The fixed district-to-gate assignment also prevents interior crossings, while the plan's named routes stay in force.
- **Fits the comms and command requirements:** IPAWS, WEA and Guard signal bridging are what the plan specifies, and the forward element in Bozeman or Livingston complements the Denver RRCC. It must still document the NPS-to-governor handoff and the Region 8/10 seams.
- **Why not the others:**
  - *Pioneer's Gambit* depends on buses, drivers and a joint command that cannot be assembled within T+6 hours, so execution risk is too high.
  - *Consolidator's Anchor* is robust but its discretionary decision cell delays the Beta order and keeps the corridor chokepoints.

---
## Alternative Paths
### The Pioneer's Gambit
**Strategic Logic:** Move early and move more people per vehicle: buses replace private-vehicle exit lanes, vulnerable groups leave the outer ring before any VEI-7 indicator appears, and evacuees are pushed onward to hubs outside the ash footprint. This accepts higher cost and coordination risk (bus availability, drivers, a joint command that must function from the first hour) in exchange for the most headroom if the eruption escalates to Scenario Beta.

**Fit Score:** 3/10

**Assessment of this Path:** Its bus-based lane suspension and quiet pre-emptive outer-ring evacuation need transport, drivers and a fully functioning joint command from hour one, which is not credible within a T+6 window for 35,000 people. It also gives the Denver RRCC and the explicit NPS-to-governor handoff little role. It offers the most Scenario Beta headroom but is the least executable and its comms layer is hardware-heavy.

**Key Strategic Decisions:**

- **Egress Corridor Allocation and Contraflow Architecture:** Suspend private-vehicle exit lanes at the Madison and Mammoth staging lots and load visitors onto concessioner buses and park fleet vehicles, so one contraflow lane carries more people per vehicle.
- **Escalation Trigger and Evacuation Release Doctrine:** Begin a quiet precautionary outer-ring evacuation of vulnerable groups, such as hospitals, care homes and families with children, beyond 100 km before any VEI-7 indicator appears, so a later order has fewer people to move.
- **Command Structure and Jurisdictional Handoff Model:** Run a single Unified Command with a rotating deputy from each state and NPS, so authority over the roadway is joint from the interior through the first gateway town.
- **Communications Continuity Stack Under Ash and Tremor:** Deploy portable repeaters and satellite terminals at every contraflow control point and shelter, and broadcast route instructions over highway advisory radio and variable message signs along US-191 and I-90.
- **Refugee Intake and Shelter Siting Strategy:** Treat Bozeman and Idaho Falls as short-stay processing points and move evacuees onward by bus and rail to distant hubs such as Billings, Boise or Salt Lake City outside the modeled ash footprint.

### The Consolidator's Anchor
**Strategic Logic:** Concentrate on what can be executed reliably within the 72-hour window: two contraflow corridors to I-90, a written handoff of authority at the park boundary, low-tech redundant communications and fixed, pre-stocked reception centers. Escalation to a 500 km order stays with a standing volcanologist-and-governor cell, which keeps human judgment and cost low but accepts delay and leaves Scenario Beta capacity as the main residual risk.

**Fit Score:** 6/10

**Assessment of this Path:** It is reliable and closely matches the named corridors, the explicit boundary handoff and the fixed Bozeman and Idaho Falls centers. However, a periodic decision cell delays a Scenario Beta order that the plan requires "immediately", and the two-corridor funnel and the lack of IPAWS and Guard comms bridging leave the main bottlenecks and ash-driven comms failures under-addressed.

**Key Strategic Decisions:**

- **Egress Corridor Allocation and Contraflow Architecture:** Funnel all outbound traffic through two contraflow corridors, US-20/US-191 from West Yellowstone and US-89 from Gardiner to I-90 at Livingston, with ranger-staffed traffic control points at every junction.
- **Escalation Trigger and Evacuation Release Doctrine:** Keep a standing volcanologist-and-governor decision cell that meets at fixed intervals and recommends expansion, retaining human judgment but accepting added delay at each decision point.
- **Command Structure and Jurisdictional Handoff Model:** Transfer authority at the park boundary under a written protocol, with the NPS incident commander handing traffic and care responsibility to each state's designated commander at defined checkpoints.
- **Communications Continuity Stack Under Ash and Tremor:** Hand out pre-programmed battery radios and printed route cards at park entrances and visitor centers, so visitors can still follow instructions after the digital network has collapsed.
- **Refugee Intake and Shelter Siting Strategy:** Operate Bozeman and Idaho Falls as fixed reception centers, each with medical triage, registration and family reunification, and stock them ahead of the first arrivals.
