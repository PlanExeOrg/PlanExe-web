## Positive Constraints

- Create a comprehensive strategic response plan for a 'Red Warning' volcanic event at the Yellowstone Caldera
- Scenario Alpha: VEI-6 or higher eruption modeled at 40% probability within the next 72 hours
- Primary objective: preservation of life via immediate evacuation of Zone Zero (Park Interior) and Zone One (100 km radius)
- Follow evacuation with continuity of operations for regional infrastructure under heavy ashfall conditions
- Phase 1 (T+0 to T+6 hours): evacuate approximately 35,000 tourists and 800 park staff from inside park boundaries
- Account for South Entrance road (US-89/191/287) blocked by landslide; reroute traffic north and west
- Detail traffic control plan using contraflow (all lanes outbound) on US-191 and US-20 toward West Yellowstone and US-89 toward Gardiner
- Deploy National Park Service LE Rangers and request immediate Wyoming Highway Patrol assistance to clear bottlenecks
- Phase 2 (T+6 to T+24 hours): expand evacuation to Zone One communities West Yellowstone (MT), Gardiner (MT), and Cody (WY)
- Immediate indefinite grounding of all commercial and private aviation in FAA sectors ZLC (Salt Lake) and ZSE (Seattle) due to ash ingestion risk
- Establish mass casualty and refugee intake centers at Bozeman, MT (Field Report) and Idaho Falls, ID (Bonneville HS)
- Establish Unified Command at the FEMA Region VIII Regional Response Coordination Center (RRCC) in Denver
- Explicitly define transfer of authority from NPS (Federal Land) to State Governors once evacuees cross park boundaries to avoid turf wars
- Plan for failure of local cell towers due to ash/tremors
- Activate FEMA IPAWS for emergency broadcasting
- Deploy National Guard signal corps for comms bridging
- Mobilize bottled water convoys from Salt Lake City within 12 hours due to reservoir contamination from ashfall
- Pre-stage respiratory protection (N95 minimum) for 100,000 people
- Prepare for mass respiratory distress cases at regional hospitals
- Deploy National Guard to enforce exclusion zone perimeter and prevent looting in evacuated towns
- Scenario Beta: if eruption escalates to VEI-7, expand evacuation zone to 500 km immediately, including a trigger point for this decision
- Grid failure contingency: plan for widespread power outages from ash-induced flashovers on transmission lines
- Prioritize generator fuel for hospitals and comms centers
- Output must include an Executive Summary
- Output must include a Phased Gantt Chart, hourly for the first 24 hours
- Output must include a Risk Register focusing on logistical bottlenecks
- Output must include a Resource Allocation Matrix
- Be specific about routes (US-191, I-90), towns, and agencies (USGS, FEMA, NPS)
- Project start ASAP (Month 0 = 2026-10-14)
- Mark non-user, non-benchmark figures as '(proposed threshold)' or '(estimate)'
- Write in impersonal planning-document voice

## Negative Constraints

- Avoid generic advice
- Do not present invented numbers as facts
- Do not turn example values ('e.g. ...') from input documents into requirements
- Do not refer to oneself or one's own process (no 'I', 'my knowledge', 'I could not verify')
- Do not write calendar dates; use month offsets from project start (e.g., 'Month 3 = 2027-01-14')
