**Primary domain:** Emergency Management

**Secondary domains:** Volcanology, Traffic Management, Mass Evacuation Planning

**Rationale:** Emergency Management owns the whole multi-agency response: unified command, jurisdiction transfer, shelter intake, logistics, and continuity of operations. Mass Evacuation Planning ties on score but covers only one phase. Volcanology, Traffic Management, and Public Health are subordinate.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Emergency Management | 5 | 5 | outcome | Owns mass evacuation, unified command, shelter intake, and continuity-of-operations planning for the disaster response. |
| Mass Evacuation Planning | 5 | 5 | outcome | Core success criterion is evacuating 35,000 tourists and regional communities within hours. |
| Volcanology | 4 | 5 | constraint | Eruption modeling, VEI escalation triggers, and ashfall forecasts drive evacuation zones and timing. |
| Traffic Management | 4 | 4 | method | Contraflow operations on US-191, US-20, and US-89 are central to evacuating 35,000 people. |
| Emergency Logistics | 4 | 4 | method | Water convoys, N95 pre-staging, generator fuel, and shelter intake require supply chain coordination. |
| Emergency Communications | 4 | 4 | method | IPAWS alerts and signal corps bridging address cell tower failure under ashfall. |
| Public Health Preparedness | 4 | 4 | outcome | Respiratory protection, mass casualty intake, and hospital surge for ashfall exposure. |
| Critical Infrastructure Resilience | 4 | 4 | method | Ash-induced grid flashovers, water contamination, and continuity of regional infrastructure operations. |
| Aviation Safety | 3 | 4 | constraint | Ash ingestion risk drives indefinite FAA grounding across ZLC and ZSE sectors. |