Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 13 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 6 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is a disaster-response logistics and operations plan grounded entirely in conventional engineering: traffic management, evacuation, shelter operations, supply dispatch, communications, and command-and-control. All causal mechanisms are physical—human decision and action directing material resources (vehicles, supplies, personnel, infrastructure) and information (alerts, orders, sensor data). The plan does not require breaking any law of physics or depend on non-physical causation for success.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of contraflow under ashfall, real-time dynamic shelter relocation, and pre-authorized 500 km escalation without confirmed second-stage destinations. No comparable North American precedent exists for this system under a VEI-6 ashfall event. Gallatin Canyon clearance feasibility, ashfall forecast reliability for shelter-relocation decisions, and Scenario Beta destination verification are all unvalidated; failure in any critical track cascades into 4–8 hour evacuation delay and 5,000–20,000 stranded evacuees.

**Mitigation**: Run three parallel validation tracks by Month -1 (2026-09-14): (1) Geotechnical/Engineering: confirm Gallatin Canyon single-lane clearance feasibility within 4 hours and secondary-slide risk via USGS survey; conduct a tow-team mobilization drill to validate 15-minute reach time. (2) Technical/Environmental: validate NOAA ashfall forecast skill and PM10 sensor accuracy; conduct a shelter-relocation exercise moving 1,000 evacuees to backup sites within 4 hours under simulated 50 km forecast divergence. (3) Logistical/Legal: execute signed MOUs from at least 5 hubs outside the 500 km ring with capacity commitments and pre-positioning timelines; conduct a multi-state Beta hub activation tabletop. Define two NO-GO gates: (A) If Gallatin Canyon clearance exceeds 4 hours or secondary-slide risk exceeds 20%, write off that corridor and restrict plan to two exits. (B) If fewer than 5 hubs are validated and signed by Month 1 (2026-11-14), suspend pre-authorized Scenario Beta and revert to a discretionary decision cell. Stop rule: if any critical track fails, the cascade-risk management protocol requires plan revision before T+0 activation.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because two critical strategic concepts—Scenario Beta second-stage hub destinations and Responder Exposure Limits—lack defined owners, quantified success metrics, and operational mechanisms. The Escalation Trigger defers USGS indicator values to T+3h, leaving pre-authorization hollow. Core evacuation mechanics (contraflow, command, comms) are well-defined with owners and measurable gates (G1 T+6h ≥98%, G2 T+24h ≥95%), but secondary strategies lack this rigor.

**Mitigation**: Draft one-pagers for Scenario Beta hubs (verify Denver/Cheyenne distances, confirm capacity and acceptance by Month 0 = 2026-10-14), Escalation Trigger (finalize USGS values by T+3h), and Responder Exposure Limits (name the Safety Officer by T+0 with explicit withdrawal authority) specifying owner, mechanism-of-action, and quantified success metrics. Publish Strategy Reference Guide to all stakeholders by Month 1 (2026-11-14).


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan pre-authorizes a Scenario Beta 500 km evacuation order without defining executable second-stage destinations, host-community capacity, or interim hub list before T+0. If the trigger fires (likely T+12–24 h), millions of outer-zone residents will lack published shelter addresses, causing uncontrolled shadow evacuation on I-15/I-80/I-90 that saturates the same corridors needed for organized Zone Zero evacuation, adding an estimated 4–8 hours delay and stranding 5,000–20,000 people in ashfall. Interim hub list is due T+12 h (post-event deliverable), written plan due Month 1 (2026-11-14), and signed MOUs due Month 2 (2026-12-14)—all blocking dependencies exist only after the trigger fires and cascades begin.

**Mitigation**: Scenario Beta Secondary-Stage Destination Planner: by Month 1 (2026-11-14), deliver written second-stage evacuation plan naming 5–10 ranked hubs outside the 500 km ring with signed host MOUs confirming capacity and pre-positioning timelines; validate distances, model ashfall survivability at each hub, and pre-authorize tiered messaging. Conduct a full multi-state Beta hub activation and shelter-intake exercise by Month 3 (2027-01-14) to expose real relocation latency and confirm execute-ability before T+0.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan pre-authorizes a Scenario Beta VEI-7 trigger ordering immediate 500 km evacuation affecting millions of people without a defined, executable second-stage destination plan. The interim hub list is due T+12 hours (post-event, during active evacuation), written plan due Month 1 (2026-11-14), and signed host MOUs due Month 2 (2026-12-14)—all after the trigger fires. Without published shelter destinations by T+12 h, evacuees will lack assigned refuge addresses, triggering uncontrolled shadow evacuation of 50,000–200,000+ outer-zone residents onto I-15, I-80 and I-90 that saturates the same corridors needed to clear 35,800 Zone Zero evacuees. This cascade-failure coupling creates a critical single-point vulnerability: pre-authorization without pre-positioned capacity.

**Mitigation**: Scenario Beta Secondary-Stage Destination Planner: Execute written Scenario Beta Secondary-Stage Evacuation Plan by Month 1 (2026-11-14) naming five or more ranked shelter hubs outside the 500 km ring with signed host-community MOUs confirming capacity and 48-hour resource availability; validate Denver and Cheyenne distances from Yellowstone center and ashfall survivability under USGS ensemble forecast scenarios; pre-position 20,000–30,000 person equivalent food, water and N95 supplies at each hub; issue interim ranked hub list (at least five outside ring) by T+12 hours; conduct full-scale multi-state Beta hub activation exercise by Month 3 (2027-01-14).


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because committed funding sources for the USD 200 million planning envelope are not documented. The plan names "a federal emergency declaration (Stafford Act) plus pre-event contract vehicles" as the assumed funding source with "USD 150–250 million surge envelope" (estimate), but provides no signed appropriation, FEMA pre-award authority, or congressional allocation. No financing gates, covenants, or draw schedule are specified. The readiness package (USD 47.5–87 million estimate) lacks assigned funding owners (federal vs. state/local/host-community cost-share unresolved). Critical Scenario Beta second-stage hub pre-positioning (USD 20–40 million estimate) and shelter relocation contingency (USD 5–10 million estimate) have no secured funding. The "free contingency" of USD 30–35 million (estimate) is a theoretical buffer, not committed. Without signed appropriations, FEMA advance authorization, or explicit cost-allocation MOUs, the plan cannot execute beyond T+0 without financial bottlenecks cascading into supply delays, hub non-activation, and responder shortfalls.

**Mitigation**: FEMA Region VIII Finance Lead: By Month 0 (2026-10-14) (T+0), secure written FEMA pre-authorization for USD 200 million Stafford Act emergency declaration and verbal activation of all pre-awarded FEMA contract vehicles for water, fuel, N95 and bus supply. Obtain written federal vs. state/local/host-community cost-allocation confirmation from FEMA and governors specifying reimbursement percentages for shelters, hubs, and interstate support within 30 days; embed allocations in signed MOUs by Month 1 (2026-11-14). Define no-go financing gate: if USD 160 million base appropriation is not confirmed in writing by Month 0 (2026-10-14) T+12h, halt all non-critical hardening and escalate to Congressional emergency session.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the USD 200 million budget (USD 160M base + USD 40M contingency at 20%) is stated without vendor quotes, cost-per-evacuee benchmarks, or scale-appropriate comparables. Plan scope is multi-state evacuation of 35,800 Zone Zero + unquantified Zone One + millions in Scenario Beta. No three quotes substantiate major costs (water convoys T+12–24 h, N95 procurement, shelter operations, fuel reserves). No per-area normalization (cost per person-day, shelter bed, convoy ton-mile) provided. Hurricane Rita and Camp Fire case studies cited but not analyzed for comparable costs. Financing split (federal vs. state/local/host-community) unresolved, risking USD 20–40M exposure if states decline cost-share. Contingency adequacy depends on Zone One population census (unquantified) and Scenario Beta activation (probability triggers may be hollow without second-stage hub execution confirmed). 20% contingency meets the 10–20% rule by stated value, not validated necessity.

**Mitigation**: Emergency Logistics and Supply-Chain Director: Obtain three vendor quotes each for bottled-water convoys (Salt Lake City to Bozeman/Idaho Falls, T+12–24h delivery), N95 bulk purchase and resupply, diesel fuel pre-positioning and convoy, and shelter operational costs (food, water, medical, staff per person-day) from regional suppliers by Month 0 (2026-10-14). Normalize all costs per evacuee-day and per shelter bed; benchmark against Hurricane Rita (2005) and Camp Fire (2018) cost-per-evacuee data from FEMA HAZUS or state emergency management reports. Reconcile line-item readiness package (USD 47.5–87M) against quotes; revise contingency from assumed 20% to actual variance (±15–30% estimated) based on market data. Resolve federal vs. state/local cost-share allocation by written MOU with governors and FEMA by Month 1 (2026-11-14); quantify federal obligation ceiling and cost-shock threshold for contingency drawdown. Conduct a cost-sensitivity analysis showing whether USD 200M envelope survives Zone One population +20% variance, Scenario Beta hub pre-positioning acceleration, and shelter-relocation surge (USD 20–50M estimated). Document all benchmarks and quotes in a Cost Realism Validation Report due Month 1 (2026-11-14).


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan states key projections (water arrival T+12 h dispatch/T+24 h target, 660 veh/h throughput per exit, 45-min blockage threshold, 4-h shelter relocation, 98% evacuation by T+6 h) as single numbers or fixed thresholds without ranges, confidence intervals or alternative scenarios. Canonical facts acknowledge "T+18–30 h realistic arrival" but do not integrate this into a sensitivity analysis or best/worst-case envelope. No best-case, base-case, or worst-case scenario table exists for the three critical projections (throughput, water arrival, responder availability). The plan lacks contingency logic tied to projection variance; contingency is financial (20% budget buffer) not operational (throughput/timing scenarios).

**Mitigation**: Emergency Logistics and Supply-Chain Director and Contraflow Operations Manager: By Month 1 (2026-11-14), deliver a Sensitivity Analysis Report for the three most critical projections: (1) Water convoy dispatch and arrival time under ashfall and evacuation-traffic congestion (base T+24 h, conservative T+36 h, optimistic T+18 h); (2) Contraflow throughput per exit (base 660 veh/h, best-case 800 veh/h if ashfall remains light, worst-case 400 veh/h if visibility <50 m); (3) Blockage clearance and diversion (base 45 min, conservative 120 min requiring full diversion, optimistic 20 min for minor debris). For each scenario, quantify the cascading impact on Gate G1 (T+6 h clearance) and Gate G2 (T+24 h Zone One clearance) attainment and document trigger points for contingency activation (e.g., if cumulative throughput delay exceeds 2 h by T+4 h, activate standby responder reserve).


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan pre-authorizes a VEI-7 trigger that orders a 500 km evacuation affecting millions of people without confirmed second-stage shelter hubs, host-community MOUs, or interim destination lists prior to T+0. If the trigger fires during or immediately after Zone Zero evacuation (T+12–24 h range), evacuees will lack published shelter addresses, causing uncontrolled shadow evacuation of 50,000–200,000 outer-zone residents onto I-15, I-80 and I-90 that saturates the same corridors required for organized Zone Zero clearance. This cascades an estimated 4–8 hours of additional delay, stranding 5,000–20,000 evacuees in ashfall exposure zones. Interim hub list is a post-event deliverable (T+12 h), written plan is due Month 1 (2026-11-14), and signed host MOUs are due Month 2 (2026-12-14)—all blocking dependencies exist only after cascade effects begin.

**Mitigation**: Scenario Beta Secondary-Stage Destination Planner: By Month 1 (2026-11-14), execute a written Scenario Beta Secondary-Stage Evacuation Plan naming at least five ranked shelter hubs outside the 500 km ring (e.g., Denver, Cheyenne, candidate secondaries) with signed host-community MOUs confirming capacity and pre-positioning logistics. Validate distance from Yellowstone center to each hub and ashfall survivability under USGS ensemble forecast scenarios. Issue interim ranked hub list by T+12 hours; execute full multi-state Beta hub activation exercise by Month 3 (2027-01-14).


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan pre-authorizes a Scenario Beta 500 km evacuation order affecting millions of people without naming specific second-stage shelter hubs, confirming their distance outside the 500 km ring, obtaining signed host-community MOUs, or publishing an interim destination list prior to the 72-hour window. The interim hub list is due T+12 hours (post-event, during active evacuation), the written plan is due Month 1 (2026-11-14), and signed MOUs are due Month 2 (2026-12-14)—all blocking dependencies exist only after the trigger fires. Without executable destinations confirmed by T+0, a pre-authorized trigger is operationally reckless and creates cascade-failure risk.

**Mitigation**: Scenario Beta Secondary-Stage Destination Planner: By Month 1 (2026-11-14), execute a written Scenario Beta Secondary-Stage Evacuation Plan naming at least five ranked shelter hubs outside the 500 km ring with signed host-community MOUs confirming capacity, pre-positioning supplies, and 48-hour activation readiness. Validate distances from Yellowstone center and ashfall survivability under USGS ensemble forecasts by Month 0 (2026-10-14).


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because major strategic deliverables (Scenario Beta Secondary-Stage Evacuation Plan, Responder Exposure Protocol, Ashfall Monitoring Relocation Protocols) are named but lack specific, measurable, verifiable acceptance criteria. Success metrics are absent: the Beta plan has no defined hub count, capacity threshold, or distance-from-ring criteria; responder protocol has no quantified relief depth or rotation timing; shelter relocation has no triggers or occupancy limits. These deliverables are critical for mitigating cascade risks (uncontrolled shadow evacuation, staff exhaustion, evacuees sheltered in heavy ash), yet their completion cannot be verified objectively. Absence of SMART criteria creates ambiguity about when readiness is achieved, preventing stakeholders from assessing whether the plan will actually execute.

**Mitigation**: Scenario Beta Secondary-Stage Destination Planner: By Month 0 (2026-10-14), draft SMART acceptance criteria for all three unclear deliverables specifying measurable KPIs (e.g., Beta plan success = ≥5 hubs outside 500 km with signed MOUs and ≥250,000 confirmed beds); publish criteria to all stakeholders; track compliance monthly (Months 1-3, 2026-11-14 to 2027-01-14) against documented gates.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Escorted-Return Program (Decision 10, option 3) adds USD 2–3 million in cost and diverts Guard and responder personnel from traffic control, logistics and shelter security during Phase 2 (T+6 to T+24 h), yet does not directly support the core project objectives of evacuating ≥98% of Zone Zero by T+6 h (Gate G1) or ≥95% of Zone One by T+24 h (Gate G2). The feature is Phase 3 (post-event re-entry) and is not binding under any legal or contractual requirement; anti-looting and perimeter security are managed via the fixed-checkpoint protocol (Decision 10, option 1). Responder hours consumed by escorted-return logistics directly compete with responder relief rotation needed to maintain 50%+ coverage at traffic-control checkpoints during peak evacuation (T+2 to T+8 h), where staffing is already at critical minimum. Mitigation is straightforward: eliminate the escorted-return program during Phases 1–2 and defer it to Phase 3 (post-ashfall) or cancel it entirely if responder depth remains inadequate.

**Mitigation**: Project Leadership: Conduct a Benefit Case Review within 7 days specifying: (1) whether escorted returns during Phase 2 (T+6 to T+24 h) are required by any state law, governor order, or legal precedent; (2) estimated responder hours diverted from traffic control, logistics or relief rotation; (3) quantified benefit (reduced looting incidents, resident complaints, post-event litigation risk) and assigned owner; (4) cost estimate including escort vehicles, drivers, request-processing staff and coordination overhead. If no binding requirement or demonstrated benefit justifies the cost during Phase 2, move escorted-return program to Phase 3 (post-ashfall, after ashfall onset is declared over) or cancel entirely; reallocate freed responder hours to traffic-control coverage and shelter-relocation support.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Ashfall Forecasting & Dynamic Shelter-Siting Officer is mission-critical (decision authority over real-time PM10 monitoring and 4-hour shelter relocation triggers) yet requires rare, combined expertise in volcanology, air-quality science, emergency operations, logistics, and real-time data systems. No single professional discipline typically carries all five competencies. Lead-time to recruit and integrate a qualified officer by Month 0 (2026-10-14) is short; talent is concentrated in USGS and NOAA with limited availability.

**Mitigation**: FEMA Region VIII and UC Incident Commander: By Month 0 (2026-10-14) T-24h, identify and pre-authorize a named Ashfall Officer from USGS Volcano Disaster Assistance Program or a university volcanologist with ashfall-dispersion and emergency-operations experience. Execute a pre-event Interagency Agreement (IAA) granting the officer direct authority over PM10 sensor data, NOAA VAFT forecast integration, and relocation-trigger decisions. Confirm 24/7 availability and seat officer at forward element by T-12h.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because legal pathways exist (Stafford Act, FEMA authority, FAA airspace procedures, state emergency powers, EMAC), but the plan lacks a regulatory matrix, fatal-flaw analysis, pre-event legal memoranda, signed MOUs with counsel review, or documented Stafford Act/FAA protocols. Controlling regimes: Stafford Act (42 U.S.C. § 5121), FAR Part 91 (airspace closure), State Emergency Management Acts, OSHA (respiratory protection), NIMS/ICS compliance. No unmapped showstoppers identified, but substantial documentation and pre-negotiation gaps remain.

**Mitigation**: FEMA Region VIII Legal Counsel and UC Incident Commander: By Month 0 (2026-10-14) T+0, execute a Fatal-Flaw Analysis reviewing Stafford Act emergency-declaration authority, FAA airspace-closure procedures, state governor activation requirements (MT, WY, ID statutes), and EMAC enforceability. Deliver a signed Regulatory Matrix (authority, artifact, lead time, predecessors) documenting Stafford Act declaration trigger, FAA NOTAM issuance protocol, governor pre-authorization letter template, and state mutual-aid legal enforceability. Obtain pre-event legal opinions on Scenario Beta trigger authority, Boundary Coordination Officer delegation validity, and government liability for unnecessary/unexecutable evacuation. Brief all state attorneys general and FAA counsel by Month 1 (2026-11-14).


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan prioritizes the 72-hour evacuation window (T+0 to T+72) but explicitly defers all post-event operations to "Phase 3 re-entry and recovery planning" with no defined funding, personnel, infrastructure maintenance, or long-term continuity mechanisms. Operational sustainability assessment reveals: (1) ongoing costs for responder reserves, equipment maintenance, and supply rotation through Month 60+ (estimated USD 2–5 million/year) lack annual appropriation authority; (2) specialized skills (USGS volcanology liaison, Guard signal operations, shelter management) required for sustained readiness have no retention or succession planning; (3) pre-positioned assets (sensors, tow equipment, generator fuel reserves) degrade without replacement cycles; (4) inter-agency MOUs expire unless renewed every 2 years; (5) no explicit plan for transitioning from emergency operations back to baseline readiness or for maintaining the forward UC element and Boundary Coordination Officer role beyond Month 3 (2027-01-14). The plan is designed as a 72-hour surge operation, not as a sustainable standby posture.

**Mitigation**: FEMA Region VIII and UC Director: Establish a Yellowstone Evacuation Readiness Sustainability Plan by Month 3 (2027-01-14) documenting: (1) annual operating budget (USD 2–5 million/year estimated) for asset maintenance, supply rotation, personnel retainer, and MOU renewal (every 2 years); (2) named sustainment owner (FEMA Region VIII Chief, or delegated permanent position) with 24/7 authority to activate the readiness posture if USGS eruption probability triggers above 10% in any 12-month window; (3) personnel succession and cross-training protocols for critical roles (USGS volcanologist liaison, Boundary Coordination Officer, Ashfall Forecasting Officer); (4) equipment lifecycle and replacement schedule (sensors every 3 years, tow assets every 5 years, generator fuel reserves refreshed annually); (5) annual tabletop exercise (Months 12, 24, 36 = 2027-10-14, 2028-10-14, 2029-10-14, etc.) to maintain multi-agency coordination and validate MOUs. Secure Congressional pre-appropriation authority for the annual sustainment budget by Month 6 (2027-04-14 + 3 months estimated) to avoid annual battle for funding and ensure continuity beyond Month 3 (2027-01-14).


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because hard constraints (zoning, occupancy/egress, fire code, permits, structural limits) are acknowledged but treated as operational decisions (T+0 to T+6h shelter site selection) rather than pre-event validation tasks. Shelter sites Bozeman and Idaho Falls are named but no pre-event zoning confirmation, occupancy-permit application, or fire-egress compliance survey exists. Backup shelter sites are identified only as ranked upwind lists without structural-capacity or fire-code pre-surveying. Contraflow permits for temporary road closure/reversal are not documented as pre-authorized from state DOTs or NPS. If hard constraints are not cleared before T+0, shelter activation and relocation face 2–6 hour delays or site loss due to zoning/code violations. Viable alternatives exist (multiple candidate shelter locations, secondary routes), but feasibility is unvalidated.

**Mitigation**: Shelter Operations Coordinator (or designated Site Feasibility Lead): By Month -1 (2026-09-14 simulated / apply at Month 0 = 2026-10-14 T+0), conduct a fatal-flaw screen with local planning and fire-marshal authorities at Bozeman, Idaho Falls, and each backup-site candidate. Obtain written confirmation that zoning permits emergency congregate shelter, occupancy is unbounded by code, fire egress meets or exceeds 35,000-person capacity, and temporary-use or emergency-occupancy permits can be expedited within 2 hours of activation request. Secure pre-signed occupancy authorizations from facility managers at Bozeman and Idaho Falls by Month 0 (2026-10-14) T-24 h. Define and document NO-GO thresholds: if zoning audit shows <2 sites (of Bozeman, Idaho Falls, third) are compliant, suspend shelter activation and activate Scenario Beta secondary-hub occupancy immediately. Coordinate with state DOTs (MT, WY, ID) to pre-authorize temporary contraflow permits and provide written delegation of activation authority to the UC by Month 0 (2026-10-14) T+0.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan names pre-positioned tow and rockfall teams, forward water depots at Bozeman and Idaho Falls, Guard signal repeaters at control points, and fuel reserves at receiving hospitals as fallback assets, but lacks: (1) explicit single-point-of-failure analysis (e.g., what if Bozeman depot is ash-blocked and cannot resupply); (2) tested failover procedures (no documented exercise validating 4-hour water-resupply activation or tow-team diversion if primary supplier fails); (3) second-source vendor commitments for all critical supplies (water contracts from Salt Lake City only; no signed Pocatello/Butte backup pre-authorized for 6-hour dispatch). The plan specifies forward depots and Guard repeaters but does not confirm they are staged by T-12 h or that backup activation is pre-authorized. Regional utility grid resilience (transmission flashovers, cascading blackout) is identified as a risk but no load-shedding topology or substation pre-authorization exists to prevent it. Tested failover protocols for the three most critical single-point dependencies (water convoy, fuel delivery, communications) are absent.

**Mitigation**: Emergency Logistics and Supply-Chain Director and Critical Infrastructure Lead: (1) By Month 0 (2026-10-14) T-12 h, execute written pre-authorization agreements with Pocatello (Idaho) and Butte (Montana) water and fuel suppliers for 6-hour emergency dispatch at fixed surge rates, naming them as primary and secondary sources in the water and fuel contracts. (2) By Month 0 (2026-10-14) T-12 h, stage 200,000–300,000 liters bottled water at Bozeman and Idaho Falls forward depots with confirmed tank capacity and resupply trigger (50% depletion = resupply order). (3) By Month -0.5 (2026-09-29), coordinate with Montana-Dakota Utilities, Pacific Power and Idaho Power to pre-authorize emergency transmission load-shedding and identify critical-path islands (hospitals, comms centers, shelters) that stay energized during regional blackout; test load-shedding topology at one substation. (4) Within 30 days before T+0, execute a supply-chain failover exercise: simulate primary water-convoy delay, activate Pocatello backup within 6 hours, and validate secondary delivery timing to shelters.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because two key stakeholder groups hold conflicting incentives that are unaddressed: (1) FEMA and governors are incentivized to authorize pre-positioned spending (USD 47.5–87 million estimate readiness package) now, accepting cascade-failure risk if Scenario Beta destinations fail; (2) host communities (Denver, Cheyenne, secondary hubs) are incentivized to minimize cost-share and pre-positioning commitments, preferring post-event federal coverage, creating latency if Beta triggers before MOUs are signed. The plan acknowledges the NPS-to-state authority handoff but does not resolve the underlying tension: federal speed (pre-authorize Scenario Beta immediately) versus state burden (absorb unquantified evacuees and costs). No shared OKR aligns both sides on a measurable success metric that balances evacuation speed against financial equity.

**Mitigation**: Unified Command Director: Within 14 days, convene a tri-party workshop (FEMA, governors MT/WY/ID, host emergency managers) to draft a signed Interagency Success Agreement specifying one shared OKR: "Evacuate 98% of 35,800 Zone Zero by T+6 h and 95% of Zone One by T+24 h with zero unplaced Scenario Beta evacuees if trigger fires before Month 2 (2026-12-14)." Embed cost-share tiers (federal covers pre-positioning; states match 10–20% ongoing costs) and tie federal reimbursement to on-time MOU signature and hub activation readiness by Month 1 (2026-11-14). Monthly scorecards track progress against the OKR; bonded incentives reward early MOU completion.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan pre-authorizes a Scenario Beta VEI-7 trigger and names critical Phase 1 and Phase 2 gates (G1 T+6 h ≥98%, G2 T+24 h ≥95%) but provides no standing feedback loop: no KPI dashboard, no hourly review cadence, no named change-control decision owners, and no re-plan/stop thresholds that automatically trigger corrective authority. The Unified Command exists as a structure but no formal review schedule, escalation protocol, or real-time monitoring rules exist to detect when gates slip (e.g., if Gate G1 clearance falls to 95% by T+5 h) and execute corrective responses within the decision window. The plan states "hourly updates" for ashfall but does not define who owns the update decision, what measurement triggers a relocation order, or what authority can halt a phase if conditions diverge. This gap is critical because the three most time-sensitive decisions (Scenario Beta trigger at T+12–24 h, shelter relocation within 4 h of ashfall exceedance, loss-of-exit rule at 45 min blockage) depend on real-time feedback and pre-authorized decision authority that the plan does not document.

**Mitigation**: Unified Command Director: Establish and publish a Feedback Loop and Change-Control Framework within 7 days, specifying: (1) KPI Dashboard updated hourly from T+0 to T+72 h tracking Gate G1 (exit counts vs. 98%), Gate G2 (Zone One vs. 95%), shelter intake vs. 5,000 person/h, convoy status vs. delivery targets; (2) Standing review cadence at T+0, T+6, T+12, T+18, T+24, T+36, T+48, T+60, T+72 h with named UC officers, state commanders, Boundary Coordinator and Ashfall Officer; (3) Pre-authorized change-control thresholds: blockage >45 min triggers diversion (Boundary Officer authority), Gate G1 <95% by T+5 h triggers 6 h extension, ashfall PM10 exceeds forecast 50% triggers 2 h relocation (Ashfall Officer authority), free contingency <USD 15M triggers spending freeze; (4) Re-plan and stop rules: re-plan if evacuation delay >2 h by T+8 h or responder coverage <50% for >60 min; stop if three convoys delayed >6 h or shelters reach <24 h reserves at T+20 h.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan pre-authorizes a Scenario Beta 500 km evacuation order affecting millions of people without confirmed second-stage shelter hubs, host-community MOUs, or interim destination lists prior to T+0. If the trigger fires during Zone Zero or Zone One evacuation (T+12–24 h range), outer-zone residents will lack published shelter addresses, triggering uncontrolled shadow evacuation of 50,000–200,000+ people onto I-15, I-80 and I-90 that saturates the same corridors needed for organized Zone Zero clearance. This cascade couples with three additional high-risk nodes: (1) responder staffing exhaustion—all 67–100 concurrent positions consumed during T+2–T+8 h peak, zero relief depth, so a single traffic incident halts one corridor 2–4 hours, stranding 500–2,000 vehicles in ash; (2) ashfall forecast error—shelter sites chosen at T+6 h using a forecast with ±50 km uncertainty, so if actual ashfall diverges, 10,000–15,000 evacuees are sheltered in heavy ash and must relocate within 4 hours (infeasible without pre-staged buses); (3) water convoy delay—realistic arrival T+18–30 h versus target T+24 h, forcing 18–24 hour water rationing at shelters. These four risks are tightly coupled: Beta trigger → shadow evacuation → corridor congestion → responder fatigue failure → stranded vehicles in ashfall overlap. The plan lacks a bow-tie or interdependency map showing these failure modes and no NO-GO thresholds exist to halt escalation if conditions diverge.

**Mitigation**: Owner: Unified Command Director. Deliverable: Execute an Interdependency Map and Bow-Tie/FTA Analysis within 14 days (before Month 0 = 2026-10-14 planning concludes) identifying four primary failure cascades: (1) Scenario Beta trigger → uncontrolled shadow evacuation → corridor saturation → Zone Zero delay; (2) responder staffing gap → coverage failure at one checkpoint → blockage halt → cascading delay; (3) ashfall forecast error → shelter in heavy ash → relocation impossible → 4–8 hour evacuation delay; (4) water convoy delay → shelter rationing → secondary health crisis → hospital overflow. For each cascade, define NO-GO thresholds triggering plan halt or re-escalation: e.g., if fewer than 5 hubs are validated by Month 1 (2026-11-14), suspend automatic Scenario Beta; if responder coverage <50% for >60 min, activate standby reserve; if blockage persists >45 min, execute loss-of-exit rule; if ashfall PM10 exceeds forecast 50%, trigger 2-hour relocation. Include a combined heatmap showing coupling strength (high/medium/low) and interdependency criticality. Assign owners to each threshold trigger (Boundary Officer, Ashfall Officer, Logistics Director, Command) with pre-authorized authority to execute mitigation within the decision window. Conduct a tabletop exercise testing all four cascades by Month 3 (2027-01-14).