### 1. Evacuation Progress Tracking Against Phase Gates and Time Deadlines
**Monitoring Tools/Platforms:**

  - Shared Common Operating Picture (COP) Digital Dashboard (updated hourly with gate counts from state checkpoints)
  - Real-time Exit Counting System (at West, North, East Entrance; integrated with COP)
  - UC Decision Log (documenting all strategic decisions and their timing)
  - Phase 1 and Phase 2 Gate Assessment Templates (98% clearance by T+6h; 95% Zone One clearance by T+24h)

**Frequency:** Continuous real-time monitoring; formal gate assessments at T+6h (Phase 1) and T+24h (Phase 2); hourly executive briefings to the Unified Command at T+0, T+2, T+6, T+12, T+24, T+36, T+48, T+60, T+72h

**Responsible Role:** Forward Unified Command Element (FUCE) Operations Section Chief, with real-time vehicle counting by state checkpoints (MT/WY/ID highway patrol, NPS rangers); reporting consolidated by FUCE Planning Chief to the UC

**Adaptation Process:** If cumulative exit counts at T+6h fall short of 98% (about 35,084 of 35,800), FUCE Operations Chief convenes emergency reroute review with Authority Cell and FUCE to redirect remaining vehicles and accelerate backcountry sweeps. If T+24h Zone One clearance falls short of 95%, UC issues Scenario Beta interim destination list early and activates secondary-stage contingencies. Mid-course adjustments include tow-team redeployment to persistent blockages and Guard staffing surge at under-performing corridors.

**Adaptation Trigger:** Gate shortfall >2% at Phase 1 (T+6h) or >5% at Phase 2 (T+24h); any single corridor throughput falling >20% below planned 660 vehicles/hour (proposed threshold); blockage persisting >45 minutes triggering diversion rule

### 2. USGS Eruption Indicator Monitoring and Scenario Beta Trigger Detection
**Monitoring Tools/Platforms:**

  - Real-time USGS seismic, GPS and gas monitoring feeds (integrated at FUCE and UC)
  - Escalation & Scenario Beta Decision Cell indicator-status dashboard (hourly updates of uplift rate, seismic magnitude, magma-depth model relative to finalized trigger thresholds)
  - USGS Eruption Indicator Log (documenting each indicator value, timestamp, and margin from trigger threshold)
  - Automated threshold-alert system (armed at T+0; alerts when indicator approaches 80% of trigger threshold and again at 100%)

**Frequency:** Continuous real-time monitoring from T+0 onwards; formal Escalation Readiness Assessments issued by Decision Cell every 6 hours (T+0, T+6, T+12, T+18, T+24, T+30, T+36, T+42, T+48, T+54, T+60, T+66, T+72h); warning alerts if any indicator crosses 80% of trigger threshold; trigger declaration within 15 minutes of any threshold crossing

**Responsible Role:** Escalation & Scenario Beta Decision Cell (led by USGS Volcano Disaster Assistance Program lead), with real-time data feeds from USGS seismic, GPS and gas networks; UC Liaison reports cell decisions to the Unified Command

**Adaptation Process:** If any USGS eruption indicator crosses the pre-authorized threshold (finalized by T+3h), the Decision Cell issues a Trigger Crossing Declaration within 15 minutes. The Unified Command automatically issues the Scenario Beta 500 km Evacuation Order within 30 minutes without further deliberation. Secondary-stage hubs, bus fleets and rail corridors are immediately activated. Interim messaging switches from shelter-in-place (outer ring) to evacuation orders for the 100–500 km rings. If an indicator crosses 80% of threshold (warning level), the UC pre-briefs and begins activating contingencies (Beta hub notification, secondary convoy preparation).

**Adaptation Trigger:** Any USGS indicator (uplift rate, seismic magnitude, gas flux, magma-depth estimate) crosses the pre-written trigger threshold as defined in the finalized matrix by T+3h; estimated time-to-trigger calculation shows remaining window <6 hours (proposed threshold); or 80% threshold-warning triggers pre-activation of secondary contingencies

### 3. Real-Time Ashfall and Air-Quality Monitoring with Dynamic Shelter-Siting and Relocation Triggers
**Monitoring Tools/Platforms:**

  - PM10 and ashfall-depth sensors deployed at forward element (Livingston/Bozeman) and all active shelter sites; readings updated hourly to the Shelter Siting Panel and COP dashboard
  - NOAA 72-hour ashfall and wind-direction forecast (updated every 6 hours from T+0 onwards)
  - Shelter Suitability Assessment Log (documenting PM10 readings, ashfall depth, forecast updates and any suitability threshold exceedances)
  - Backup Shelter Site Readiness Checklist (8–10 pre-surveyed candidates ranked by upwind distance; transport agreements and capacity confirmed)

**Frequency:** Continuous hourly PM10 monitoring at all sites from T-12h through T+72h; NOAA forecast updates every 6 hours; formal Shelter Siting Panel suitability assessments at T+6h (initial siting decision), T+24h, T+36h, T+48h, T+60h and T+72h; immediate convening if PM10 exceeds 50 ug/m³ (forecast-update trigger) or 100 ug/m³ (suitability-review trigger)

**Responsible Role:** Shelter Siting & Air-Quality Assurance Panel (led by NOAA ashfall/air-quality forecast lead), with real-time PM10 data collection from sensor networks and NOAA forecast updates; FUCE Operations Chief issues relocation orders based on panel recommendations

**Adaptation Process:** At T+6h, panel recommends final shelter sites based on latest plume forecast; FUCE Operations Chief approves and directs buses and intake staff to assigned sites. If PM10 at any primary shelter exceeds 100 ug/m³ during operations (T+24h or later), panel conducts rapid relocation analysis (within 30 minutes) and recommends an upwind backup site. FUCE Operations Chief issues relocation order within 1 hour; buses are redirected to the backup shelter and occupant transfer is completed within 4 hours (proposed threshold). If multiple shelters are threatened simultaneously or backup sites are also unsuitable, escalation to UC for split-occupancy or supplemental N95 reserve activation.

**Adaptation Trigger:** PM10 reading at any shelter exceeds 50 ug/m³ (triggers forecast-update review) or 100 ug/m³ (triggers suitability assessment and potential relocation); forecast wind shift of >30 degrees from current model; actual ashfall depth exceeds modeled expectation by >50% (measured visually or by sensor); NOAA forecast indicates ash concentration will exceed 200 ug/m³ at a primary shelter within 12 hours (proposed threshold)

### 4. Water, N95 Respirator and Generator Fuel Supply-Chain Monitoring with Convoy Tracking and Contingency Activation
**Monitoring Tools/Platforms:**

  - Water-convoy GPS tracking and real-time location updates (from Salt Lake City dispatch through arrival at Bozeman and Idaho Falls shelters)
  - Supply Inventory Tracking Spreadsheet (N95 stock at each checkpoint and shelter, fuel inventory at receiving hospitals and comms centers, updated every 4 hours)
  - FUCE Logistics Log (documenting all supply requests, dispatch confirmations, and delivery status)
  - Forward-Depot Readiness Report (confirming pre-positioned water, N95 and fuel at Bozeman, Billings, Idaho Falls by T-48h and available for emergency deployment)
  - Contingency Activation Checklist (supplemental N95 reserve at Billings/Salt Lake City, additional fuel convoys from regional vendors)

**Frequency:** Continuous GPS tracking of water convoys from T+12h (dispatch) through arrival at shelters (target T+24h). Inventory spot-checks every 4 hours during peak operations (T+0 to T+36h), then every 6 hours through T+72h. Fuel status at receiving hospitals (Bozeman, Livingston, Idaho Falls) checked every 8 hours. Emergency convoy dispatch triggers immediate (within 30 minutes) FUCE Logistics notification and UC brief.

**Responsible Role:** FUCE Logistics Section Chief, with real-time convoy tracking via GPS and coordination with Salt Lake City suppliers; fuel pre-positioning and hospital liaison coordination with the three receiving hospitals. Responder Health & Fatigue Management Board monitors responder N95 consumption and triggers supplemental-reserve activation if usage exceeds 20% of available stock per day (proposed threshold)

**Adaptation Process:** If water convoy ETA exceeds T+24h (Phase 2 gate), Logistics Chief immediately alerts FUCE Operations Chief and activates forward-depot supplemental water release (pre-staged at Bozeman, Billings, Idaho Falls) within 2 hours. If ashfall is heavier than modeled and N95 consumption exceeds 20% of stock per day, supplemental reserve at Billings/Salt Lake City is activated for daily air or ground transport to shelters. If a receiving hospital reports fuel reserves below 48-hour supply, a dedicated priority fuel convoy is requested from regional vendors with 2-hour ETA guarantee. If total supply delay cascades and threatens shelter operations, escalation to UC for federal resource request (additional Guard logistics support, military airlift).

**Adaptation Trigger:** Water convoy ETA forecast to exceed T+24h by >2 hours; N95 consumption at any shelter or checkpoint exceeds 25% of daily stock (20% threshold plus 5% buffer); hospital fuel inventory falls below 36-hour supply; any forecast delay >6 hours from planned delivery (T+12h for water dispatch, T+24h for arrival)

### 5. Authority Transfer and Jurisdictional Coordination Monitoring with Boundary-Handoff Execution Tracking
**Monitoring Tools/Platforms:**

  - Authority-Transfer Log (maintained by Boundary Coordination Officer; hourly entries tracking vehicle and responder crossings from NPS to state control at each gate: West, North, East Entrance)
  - Reroute Authority Execution Record (documenting all reroutes issued by state on-scene commanders under pre-authorized standing orders; any disputes with NPS recorded and resolution tracked)
  - Region 8/10 Mutual-Aid Request Log (Idaho-specific resource requests to Boise and Pocatello; dispatch confirmations and arrival tracking)
  - FAA Airspace Coordination Log (aviation-grounding confirmations, medevac-exception requests and FAA responses)

**Frequency:** Continuous real-time authority-transfer tracking at all checkpoints from T+0 through T+24h (peak boundary crossing). Formal Authority Cell briefings to the FUCE every 6 hours (T+0, T+6, T+12, T+18, T+24h). Rapid escalation (within 30 minutes) if any reroute authority dispute arises or if a Region 8/10 mutual-aid request is delayed.

**Responsible Role:** Authority & Jurisdictional Coordination Cell (led by Boundary Coordination Officer at FUCE), with on-scene commanders at each park gate (NPS at West/North/East Entrances; MT/WY/ID highway patrol at corresponding corridor exits); FEMA Region 10 liaison at UC (Denver) coordinating Idaho mutual-aid requests

**Adaptation Process:** If a state on-scene commander and NPS incident commander dispute a reroute or shelter assignment, the Boundary Coordination Officer mediates within 30 minutes via conference call. If consensus is not reached, the matter escalates to FUCE Operations Chief (1-hour decision window); if still unresolved, escalates to UC for binding decision. Pre-authorized reroute authority allows state commanders to issue traffic control orders within pre-written limits without waiting for park approval, reducing decision latency. If Idaho mutual-aid requests (Boise, Pocatello resources) are delayed >1 hour, Region 10 liaison at UC immediately contacts FEMA Region 10 (Seattle) for expedited activation.

**Adaptation Trigger:** Any reroute authority dispute requiring escalation beyond the Boundary Coordination Officer; state commander reroute issued without proper notification (out-of-sequence); Region 8/10 mutual-aid request delayed >1 hour beyond submission; any vehicle or responder not properly accounted for in the authority-transfer log at a checkpoint; conflicting evacuation orders or shelter assignments from NPS and a state

### 6. Responder Health, Fatigue and Exposure-Limit Compliance Monitoring with Staffing-Continuity Risk Assessment
**Monitoring Tools/Platforms:**

  - Shift-Log Tracking System (documenting hours worked, post location, exposure conditions and N95 usage for every deployed responder at traffic checkpoints and perimeters)
  - Responder Fatigue-Risk Assessment Report (issued at T+12h, T+24h, T+36h, T+48h, T+60h, T+72h; documenting cumulative hours and identifying responders approaching or exceeding 18-hour withdrawal threshold)
  - N95 Inventory and Replacement-Cycle Tracking (stock at each checkpoint, replacement intervals as masks clog, consumption rate compared to model)
  - Standby-Reserve Readiness Confirmation (30–50 out-of-region responders pre-positioned outside the ash zone; deployment status and availability)
  - Responder-Fatigue Hotline Log (confidential reports from responders requesting relief or reporting exposure symptoms; tracked for medical evaluation and rotation decisions)

**Frequency:** Real-time shift-log tracking throughout the 72-hour window. Formal fatigue-risk assessments every 6 hours (concurrent with UC briefing schedule: T+6h, T+12h, T+18h, T+24h, T+30h, T+36h, T+42h, T+48h, T+54h, T+60h, T+66h, T+72h). N95 inventory spot-checks every 4 hours during peak operations (T+0 to T+36h). Emergency responder-health incidents reported immediately (within 15 minutes) to the Responder Health Board and medical officer.

**Responsible Role:** Responder Health & Fatigue Management Board (led by NPS Chief Ranger), with shift-log data collection from all deployed responders and state/Guard commanders; medical officer from the nearest receiving hospital evaluates any responders with respiratory symptoms or heat stress

**Adaptation Process:** If any checkpoint's staffing falls below 50% of required positions due to exposure-limit rotations or responder withdrawal, the Responder Health Board immediately (within 15 minutes) authorizes activation of the standby reserve for deployment within 4 hours. If responders show acute respiratory distress or heat-related symptoms, they are immediately withdrawn from ash-exposed duty and referred to medical evaluation at the nearest hospital. If N95 consumption exceeds modeled expectations (clogging faster than forecast), supplemental responder N95 reserves are activated for distribution. If cumulative responder fatigue is assessed as critical (multiple personnel approaching 18-hour limits simultaneously), the board recommends to FUCE Operations Chief that lower-priority checkpoints be consolidated or temporarily closed to preserve relief depth at critical posts.

**Adaptation Trigger:** Any checkpoint staffing falling below 50% coverage due to exposure limits or responder withdrawal; any responder exceeding the 18-hour withdrawal threshold without rotation; two or more responders at the same post reporting acute respiratory symptoms within 2 hours (proposed threshold); N95 consumption rate >20% of stock per day (proposed threshold); cumulative responder fatigue assessed as 'critical' at more than 10% of deployed responders by formal fatigue-risk assessment

### 7. Communications System Resilience and Message-Delivery Effectiveness Monitoring Under Ashfall and Network Degradation
**Monitoring Tools/Platforms:**

  - IPAWS/WEA Broadcast Confirmation Log (timestamp, language versions, carrier delivery confirmation, estimated population reached)
  - Guard Signal-Team Deployment and Coverage Map (real-time location of signal units at control points and shelters; radio-network interoperability test results; any coverage gaps or outage events)
  - Highway Advisory Radio (HAR) and Variable Message Sign (VMS) Message Log (pre-recorded messages deployed on US-191, US-20, US-89, I-90; hourly updates from forward command; any message failures recorded)
  - Printed Route Card Distribution Tracker (distribution of English and five-language cards at park entrances, lodges and visitor centers; hand-out counts during evacuation)
  - Communications Outage and Restoration Log (any detected IPAWS failures, cell-tower outages, radio interference or ash-induced equipment failures; time-to-restoration tracked)

**Frequency:** Continuous communication-system monitoring from T-12h through T+72h. IPAWS/WEA broadcast confirmations logged within 30 minutes of each alert. Signal-team coverage status checked every 2 hours during peak operations (T+0 to T+36h), then every 4 hours through T+72h. HAR/VMS message updates issued hourly from forward command during evacuation (T+0 to T+24h). Any outage detected immediately (within 5 minutes) triggers escalation and restoration effort.

**Responsible Role:** Guard Signal Officer (FUCE comms section) coordinates signal-team deployment and radio-network operations; IPAWS administrator (FEMA or NPS communications) confirms broadcast delivery and documents message content; forward-command public affairs officer oversees HAR/VMS updates and route-card distribution tracking

**Adaptation Process:** If IPAWS or WEA broadcasts fail or reach <80% of target population (proposed threshold), Guard signal bridging and HAR broadcasts immediately increase messaging frequency and add satellite-phone alerts to state emergency operations centers. If a Guard signal-team's radio repeater fails due to ash clogging or power loss, the backup portable unit is immediately deployed (within 1 hour) and the outage is logged. If cell-tower failure degrades IPAWS delivery, printed route cards and HAR become the primary public channel; multilingual volunteers are activated at lodges to hand-deliver route instructions to non-English speakers. If communication restoration exceeds 2 hours at any critical post (traffic control or shelter), escalation to FUCE Operations Chief for tactical rerouting (redirecting traffic to maintain flow despite comms outage).

**Adaptation Trigger:** Any IPAWS/WEA broadcast fails or is delayed >15 minutes; estimated population reached by IPAWS <80% of target (proposed threshold); any Guard signal-team loses radio coverage at a checkpoint or shelter; cell-network outage lasting >30 minutes at any critical location; HAR or VMS message failing to display correctly or updating with delay >1 hour from forward command; printed route cards exhausted at any park entrance or lodge

### 8. Scenario Beta Interim Hub Readiness and Secondary-Stage Evacuation-Plan Execution Monitoring
**Monitoring Tools/Platforms:**

  - Interim Scenario Beta Hub List (ranked list of 5–10 hubs outside the 500 km ring: Denver, Cheyenne, etc.; capacity estimates, host-community contact confirmations)
  - Secondary-Stage Bus-Fleet and Rail-Corridor Readiness Confirmation (operators and carriers pre-contracted; standing activation clauses; vehicle count and availability confirmed)
  - Scenario Beta Second-Stage Evacuation Plan Document (written plan by Month 1 = 2026-11-14; detailing tiered execution rings, hub assignments, transport routing)
  - Host-Community MOU Signature Tracking (signed agreements with secondary hubs by Month 2 = 2026-12-14; mutual-aid commitments documented)
  - Scenario Beta Response-Cell Activation Log (upon UC issuance of Scenario Beta order, expanded cell convenes and documents ring-by-ring evacuation orders, hub-destination assignments, and contingency activations)

**Frequency:** Interim hub list issued by T+12h (Month 0 = 2026-10-14). Written secondary-stage plan completed by Month 1 (2026-11-14). MOU signatures targeted by Month 2 (2026-12-14). If Scenario Beta triggers during the 72-hour window, the expanded Response Cell holds continuous briefings (every 2 hours) documenting ring-by-ring execution and hub-occupancy status. Post-event: full-scale Scenario Beta exercise (Exercise-2 'Ring Dispersal') conducted in Month 2.5 (2026-12-29).

**Responsible Role:** FUCE Planning Chief develops interim hub list and secondary-stage plan (working with state emergency managers and FEMA Region coordinators); UC chair or designee negotiates and signs host MOUs; Scenario Beta Response Cell (expanded UC) executes ring-by-ring evacuation upon trigger; secondary hub emergency managers confirm receipt of evacuees and completion of intake and registration

**Adaptation Process:** If Scenario Beta trigger is detected at any point during the 72-hour window, the UC issues the 500 km Evacuation Order within 30 minutes. The expanded Scenario Beta Response Cell immediately activates: ring-by-ring evacuation orders are issued (0–100 km organized, 100–250 km time-banded, 250–500 km staged); buses and rail are dispatched from Bozeman and Idaho Falls primary shelters to secondary hubs; populations are assigned to specific hubs based on location and hub capacity. If a secondary hub is unable to receive assigned evacuees (e.g., due to local capacity constraints), the Response Cell reassigns the population to an alternate hub within 1 hour. If bus fleets or rail corridors are delayed, additional Guard logistics support is requested.

**Adaptation Trigger:** Interim hub list not issued by T+12h (escalates to UC for expedited planning or alternative contingency); written secondary-stage plan not completed by Month 1 (2026-11-14); any host-community MOU not signed by Month 2 (2026-12-14) (signals governance gap and extends Scenario Beta readiness risk); upon Scenario Beta trigger, any secondary hub reports inability to receive assigned population within 2 hours of the evacuation order; bus-fleet or rail-corridor dispatch delayed >2 hours from the evacuation order

### 9. Multi-State Governance Formalization and Post-Event Hardening Monitoring (Months 1–3 = 2026-11-14 to 2027-01-14)
**Monitoring Tools/Platforms:**

  - MOU Signature Tracker (dates and status of signed agreements with MT, WY, ID governors; FEMA Region 10; regional utilities; Scenario Beta secondary hubs)
  - After-Action Report Development Schedule (AAR-1 at Month 1 = 2026-11-14; AAR-2 at Month 2 = 2026-12-14; AAR-3 at Month 3 = 2027-01-14; drafts tracked through review and distribution)
  - Full-Scale Exercise Calendar (Exercise-1 'Cascade Boundary' Month 2 = 2026-12-14; Exercise-2 'Ring Dispersal' Month 2.5 = 2026-12-29; Exercise-3 'Integrated Response' Month 3 = 2027-01-14; plus six smaller operational exercises)
  - UC Weekly Coordination Call Schedule (Months 1–3 = 2026-11-14 to 2027-01-14; attendance and agenda topics documented)
  - Governance Improvements Tracking (recommendations from 72-hour response and exercises; implementation status and completion dates)

**Frequency:** Weekly UC coordination calls during Months 1–3 (2026-11-14 to 2027-01-14). MOU signature targets: Month 1 (2026-11-14) for governors and Region 10; Month 2 (2026-12-14) for utilities and secondary hubs. AAR publication schedule: AAR-1 by end of Month 1 (2026-11-14); AAR-2 by end of Month 2 (2026-12-14); AAR-3 (comprehensive) by end of Month 3 (2027-01-14). Full-scale exercises scheduled in Weeks 1, 3 and 4 of Months 2, 2.5 and 3 (2026-12-14, 2026-12-29, 2027-01-14).

**Responsible Role:** FEMA Region VIII IC (UC chair) or designee coordinates MOU negotiations and signature scheduling; FEMA and NPS designate AAR working groups and publication leads; FUCE Operations Chief serves as exercise director for all three full-scale exercises; Hardening & Post-Event Review steering committee (established at Month 1 = 2026-11-14 Week 1) oversees improvements and exercise planning

**Adaptation Process:** If any MOU signature target is missed (Month 1 or 2 = 2026-11-14 or 2026-12-14), UC escalates to state governors, FEMA Region 10 or utility leadership for expedited signing; any persistent gap beyond 2 weeks flags a governance risk that is documented in AAR for future planning. If AAR development is delayed, interim field-observer summaries are published to maintain transparency; final reports are published even if late, with explanation of delays. If a full-scale exercise reveals critical governance gaps (e.g., Authority Cell unable to mediate boundary disputes, Scenario Beta hub unable to receive populations), the UC convenes an emergency remediation meeting and adjusts governance protocols before the next exercise. All improvements identified are tracked in the Governance Improvements Log with completion target dates (typically within 30 days of identification).

**Adaptation Trigger:** Any MOU not signed by 2 weeks past target deadline (Month 1 = 2026-11-14 Week 2 for governors/Region 10; Month 2 = 2026-12-14 Week 2 for utilities/hubs); AAR publication delayed >2 weeks past target; any full-scale exercise revealing a 'critical' governance gap (inability to execute a core function); any UC weekly call attendance falling below 50% of required members (signals disengagement); post-event recommendations not assigned to a responsible party within 10 days of identification