# Purpose
and

# Domain
# Primary Domain: Emergency Management

Secondary domains: Volcanology, Traffic Management, Mass Evacuation Planning

## Rationale

Emergency Management owns the whole multi-agency response: unified command, jurisdiction transfer, shelter intake, logistics, and continuity of operations. Mass Evacuation Planning ties on score but covers only one phase. Volcanology, Traffic Management, and Public Health are subordinate.

## Disciplines

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Emergency Management | 5 | 5 | outcome | Owns mass evacuation, unified command, shelter intake, and continuity-of-operations planning for the disaster response. |
| Mass Evacuation Planning | 5 | 5 | outcome | Core success criterion is evacuating 35,000 tourists and regional communities within hours. |
| Volcanology | 4 | 5 | constraint | Eruption modeling, VEI escalation triggers, and ashfall forecasts drive evacuation zones and timing. |
| Traffic Management | 4 | 4 | method | Contraflow operations on US-191, US-20, and US-89 are central to evacuating 35,000 people. |
| Emergency Logistics | 4 | 4 | method | Water convoys, N95 pre-staging, generator fuel, and shelter intake require supply chain coordination. |
| Emergency Communications | 4 | 4 | method | IPAWS alerts and signal corps bridging address cell tower failure under ashfall. |
| Public Health Preparedness | 4 | 4 | outcome | Respiratory protection, mass casualty intake, and hospital surge for ashfall exposure. |
| Critical Infrastructure Resilience | 4 | 4 | method | Ash-induced grid flashovers, water contamination, and continuity of regional infrastructure operations. |
| Aviation Safety | 3 | 4 | constraint | Ash ingestion risk drives indefinite FAA grounding across ZLC and ZSE sectors. |

# Plan Type
I'm ready to process your Markdown document. Please provide the project planning document you'd like me to shorten, and I'll convert it into a condensed version while preserving all topics, structure, and key details.

# Physical Locations
# Physical Location Requirements

- Command site with federal resource-request capability and resilient communications (FEMA Region VIII RRCC, Denver)
- Forward command element with direct sight of US-191, US-89 and I-90 corridors, outside immediate ash and tremor hazard
- Reception and shelter sites with medical triage, registration, reunification and large-capacity buildings, outside modeled ash footprint
- Exit corridors with contraflow capability: US-191/US-20 to West Yellowstone, US-89 to Gardiner, US-14/16/20 to Cody
- Pre-positioned tow, rescue and traffic-control assets at chokepoints such as Gallatin Canyon and Gardiner
- Staging depots for water, N95 respirators and generator fuel with road access (Salt Lake City, I-15, I-90)
- Receiving hospitals with generator fuel priority and helipad or ground-ambulance access
- Second-stage destinations for a 500 km Scenario Beta evacuation (not yet defined)

## Location 1: Yellowstone National Park and Gateway Towns

USA, Wyoming/Montana/Idaho

Yellowstone National Park (Zone Zero) and gateway towns West Yellowstone, Gardiner and Cody (Zone One). Includes Norris Geyser Basin, Grand Loop Road, South Entrance (US-89/191/287), West Entrance (US-20/191), North Entrance (US-89), East Entrance (US-14/16/20).

## Rationale

Evacuation of approximately 35,000 visitors and 800 staff occurs here, with landslide-blocked South Entrance and contraflow on named routes.

## Location 2: Denver, Colorado

FEMA Region VIII Regional Response Coordination Center, Denver Federal Center, Lakewood/Denver.

## Rationale

Named Unified Command site for federal resource requests. Region 10 (Idaho) coordination must be added to this site.

## Location 3: Bozeman or Livingston, Montana

Forward Unified Command element near I-90 at Livingston, or Bozeman (Gallatin County).

## Rationale

Direct sight of US-89 and US-191 corridors and I-90 junction, with base for Bozeman reception center. Both sites near Zone One edge; wind-driven relocation option needed.

## Location 4: Idaho Falls, Idaho

Bonneville High School and pre-surveyed schools/arenas in Idaho Falls.

## Rationale

Named western reception center on US-20 corridor. Final shelter selection should follow T+6 wind and plume forecast, with second-stage move planned.

## Location 5: Salt Lake City, Utah

Regional distribution centers and staging areas along I-15.

## Rationale

Source of bottled water convoys within 12 hours and N95 and fuel stocks. Candidate receiving hub for patient transfers, outside modeled ash footprint (not verified).

## Location Summary

Plan tied to Yellowstone National Park and Zone One gateway towns (West Yellowstone, Gardiner, Cody). Command at FEMA RRCC in Denver, with forward element at Bozeman or Livingston. Evacuees received at Bozeman and Idaho Falls. Supplies staged from Salt Lake City. Each site covers defined function: evacuation, command, forward control, reception or logistics.

# Currency Strategy
and

# Identify Risks
# Risk 1 - Operational / Traffic & Egress

Single-point failure on US-191/US-20 Gallatin Canyon corridor during peak contraflow evacuation. The canyon is a narrow, two-lane mountain pass with minimal shoulders, no recovery space, and documented rockfall hazard. A breakdown, rockslide, or secondary tremor-induced slide could block the entire northbound contraflow lane(s) and strand queued traffic. The South Entrance is landslide-blocked, making this corridor the primary egress for central park visitors. Rescue and debris-clearance crews cannot quickly reach a mid-canyon incident during ashfall and seismic swarm.

Impact: Complete blockage of the primary outbound corridor for 30 minutes to several hours, trapping 500–2,000 vehicles in the canyon and preventing Phase 1 evacuation of ~5,000–8,000 visitors from reaching safe zones by T+6 hours. Each hour of delay increases overlap between evacuation peak and ashfall onset, raising respiratory injury and vehicle-accident rates. Secondary estimate (estimate): 2–4 hours to clear blockage and resume traffic flow.

Likelihood: High

Severity: High

Action: Pre-position a mobile tow and rockfall-clearing team (1–2 heavy wreckers, debris chippers, spotters) at Mammoth or Spanish Creek with 72-hour supplies, tasked to reach any blockage within 15 minutes. Establish live geotechnical monitoring along the canyon with motion sensors or drones at identified slide-prone zones to detect incipient movement and trigger temporary traffic halts before collapse. Mark a short bypass track or one-lane re-route 48 hours before evacuation window and establish a hard decision rule: if blockage persists beyond 45 minutes, divert overflow to US-89 Gardiner corridor or US-14/16/20 Cody corridor (adding 2–4 hours to transit time for some evacuees).

# Risk 2 - Technical / Communications

Catastrophic failure of cell-tower network under ashfall and tremor, leaving IPAWS, WEA and standard radio links non-functional or severely degraded. The plan relies on IPAWS and Wireless Emergency Alerts as the primary public channel and assumes National Guard signal bridging can restore responder radios between agencies at gateway towns. Ash-induced flashovers on transmission lines, tremor damage to cell towers, and silicate-ash clogging of air filters on repeater fans could collapse the local network faster than signal units can deploy.

Impact: Loss of real-time route guidance, traffic-status updates, and shelter-assignment messages to drivers in vehicles for 1–6 hours. Drivers revert to visual traffic cues, rumor and cellular networks they try repeatedly, leading to missed turns, congestion at wrong exits, and uncontrolled shadow evacuation to un-assigned shelters. Regional hospitals and emergency operations centers lose two-way coordination with ambulances and field teams for 30 minutes to 2 hours, delaying patient transfers. Estimated impact: 10–20% of drivers take unintended routes, adding 1–3 hours to transit times; 5–10% of ambulance-patient transports face routing delays or miss handoff coordination.

Likelihood: High

Severity: High

Action: Deploy National Guard signal corps teams with satellite phones, portable repeaters and generator fuel to each contraflow control point and the forward command element (Bozeman/Livingston) at T-12 hours. Pre-stage printed route cards and windshield placards at all park entrance stations and in visitor lodges with simple instructions (e.g., 'North Exit: Follow US-89 to Gardiner, then I-90 to Livingston') and shelter addresses and phone numbers. Activate all available highway advisory radio (HAR) stations and variable message signs (VMS) along US-191, US-20, US-89 and I-90 with pre-recorded messages in English and key visitor languages, updated hourly from the forward command. Test satellite and portable-repeater systems in ash-simulation exercises 30 days before the eruption window.

# Risk 3 - Operational / Command & Authority

Authority gaps and delays at the NPS-to-state boundary handoff during evacuation peak. The plan specifies transfer of authority from NPS (federal land) to state governors at the park boundary, but contraflow traffic does not stop at the line: drivers cross from NPS rangers' jurisdiction to state highway patrol control while in congested queues mid-route. The boundary transfer of care (shelter placement, medical routing, security perimeter) is not clearly linked to the road crossing, creating a window where no single authority owns decisions. Idaho (Region 10) and Montana/Wyoming (Region 8) fall under different FEMA regions, leaving Region 10 mutual aid unclear.

Impact: A 15–45 minute delay in ordering traffic reroutes, issuing revised shelter assignments, or escalating unplanned congestion because the boundary coordinator and state on-scene commanders are not collocated and must reach agreement. One instance of delayed reroute could cascade into a backup affecting 500–1,000 vehicles. Jurisdictional confusion over perimeter enforcement (federal NPS rangers versus state National Guard) delays anti-looting operations and re-entry control in evacuated towns by 30 minutes to 2 hours. Region 10 mutual aid requests to Idaho resource centers go unrecognized at the Denver RRCC initially, delaying water and fuel convoys from Boise or Idaho Falls by 1–2 hours.

Likelihood: Medium

Severity: High

Action: Establish a dedicated Boundary Coordination Officer role, co-located at the forward command element (Bozeman or Livingston), with real-time voice and data links to the NPS on-scene incident commander and the designated state highway patrol and National Guard commanders on both sides of the boundary. Issue a written protocol specifying that the boundary officer controls traffic reroutes and initial shelter assignments during the crossing, and that NPS care ends at a specific roadside checkpoint where state custody begins. Pre-authorize the state on-scene commanders to issue temporary reroutes without requesting park ranger approval. Add an explicit call to FEMA Region 10 (Seattle) at T+0 hours from the Denver RRCC with a standing liaison and pre-agreed mutual aid arrangements (e.g., Boise and Pocatello fuel and water resources), documented in a signed MOU 60 days before the window.

# Risk 4 - Operational / Escalation & Scenario Beta

Pre-authorized escalation trigger to Scenario Beta (500 km radius evacuation) lacks a defined secondary-stage plan, shelters or road capacity. The plan specifies that a VEI-7 order will be issued 'immediately' under a written threshold-based trigger matrix, expanding evacuation from Zone One (100 km) to 500 km. However, no second-stage shelter destinations, host-community acceptance, bus and ambulance routing, or supply convoys for millions of additional evacuees are described. The existing Bozeman and Idaho Falls shelters (described as 'short-stay processing points' or 'fixed reception centers') would be overwhelmed; the plan does not specify whether existing shelter stock (100,000 N95 masks, bottled water from Salt Lake City) would be stretched or restocked.

Impact: Once a Scenario Beta trigger fires, evacuees and residents in the 100–500 km ring (tens of thousands to low hundreds of thousands of people) have no clear destination or reception plan. This vacuum leads to uncontrolled, chaotic shadow evacuation on all routes leading away from Yellowstone, saturating interstates (I-15, I-80, I-90) and local roads with private vehicles, blocking the organized evacuation of Zone One tourists and park staff, and stranding residents outside pre-planned shelters. Estimated impact: 50,000–500,000 unplanned evacuees on roads within 6–12 hours, creating gridlock that delays Zone One evacuation by 4–8 hours and medical response by 2–6 hours.

Likelihood: High

Severity: High

Action: Develop and pre-authorize a written Scenario Beta Secondary-Stage Evacuation Plan, including: (1) a ranked list of 5–10 secondary shelter hubs (e.g., Salt Lake City metro, Billings, Boise, Cheyenne, Denver) with estimated capacity, host-community coordination, and pre-signed MOUs; (2) a tiered public messaging strategy that differentiates between shelter-in-place zones (250–500 km radius, with self-supplied residents), time-banded evacuation zones (100–250 km, with shelters pre-assigned by county), and organized evacuation (Zone One, same as current plan); (3) pre-deployed bus fleets and rail corridors linking secondary shelters so evacuees are moved out of congested I-90 and onto lateral routes; (4) a supply-estimation model accounting for 100,000–500,000 additional people and pre-positioning food, water, and medical supplies at secondary hubs before the eruption window. Brief this plan to FEMA Region 10, state governors of Idaho, Montana, Wyoming, and Colorado, and the National Guard Joint Task Force at Fort Carson 60 days before T+0. Test a Scenario Beta messaging and routing exercise 30 days before T+0, involving dispatch of sample secondary-hub bus fleets and shelter registration systems.

# Risk 5 - Supply Chain / Life Support & Logistics

Water convoy from Salt Lake City cannot guarantee 'within 12 hours' delivery under ashfall and congested evacuation traffic. The plan states that bottled water convoys will be 'mobilized within 12 hours,' but the I-15 northbound route from Salt Lake to the shelters at Bozeman and Idaho Falls is the same corridor that out-of-state evacuees are likely to use if Scenario Beta triggers. Ashfall will degrade road surfaces, reduce visibility, increase accident rates, and slow all traffic. The 12-hour delivery window assumes roads stay clear and convoys can navigate around evacuation traffic; a realistic estimate is 18–30 hours if ashfall is heavy or evacuation-related blockages occur.

Impact: If water convoys arrive at Bozeman and Idaho Falls 18–24 hours after the first evacuees (many arriving by T+8 hours), the shelters must sustain 10,000–20,000 people for 1–2 days on existing, likely inadequate supplies. Ashfall will also contaminate open water supplies and require bottled water for all drinking, cooking and medical use. A shortage of 50,000–100,000 liters could affect medical care, respiratory treatment (which consumes water for steam inhalation and cooling), and public health sanitation. Estimated impact: 10–20% of evacuees remain without adequate water for 12–24 hours, increasing risk of heat stress, medication non-compliance, and secondary health incidents.

Likelihood: High

Severity: Medium

Action: Pre-stage bottled water, N95 respirators, and generator fuel at forward depots in Bozeman, Billings and Idaho Falls at T-48 hours, with a minimum of 10 days' supply for the planned shelter capacity (assume 15,000 people at Bozeman, 10,000 at Idaho Falls, plus field treatment sites). Establish a dedicated 'supply-surge' lane on I-15 northbound, reserved exclusively for water and fuel convoys during hours T+0 to T+24, enforced by National Guard escorts and traffic control. Pre-authorize the forward command to halt non-essential evacuation traffic on I-15 for up to 30 minutes to allow a high-priority water convoy to pass if the main route becomes gridlocked. Coordinate with Utah and Wyoming departments of transportation and water authorities to identify additional water sources (municipal tanks, bottling plants) within 200 miles of the shelters and pre-arrange 24-hour access and trucking. Test a water-convoy exercise from Salt Lake City to Bozeman under simulated ashfall and congested-traffic conditions 30 days before T+0, measuring actual travel time and identifying chokepoints.

# Risk 6 - Technical / Medical & Hospital Systems

Hospital and medical-facility power grid failure due to ash-induced transmission-line flashovers could occur faster than generator fuel reaches critical facilities. The plan identifies grid failure as a contingency and directs fuel prioritization to hospitals and communications centers, but does not specify fuel pre-positioning, delivery schedule, or the number of hospitals that will lose power simultaneously. Regional hospitals in Montana and Wyoming are typical 100–500-bed facilities with 24–48-hour on-site generator fuel reserves. An ashfall event could trigger widespread, simultaneous power loss across the region within 4–8 hours, and fuel convoys from distant depots (e.g., Rock Springs, WY) would require 6–12 hours to reach all facilities.

Impact: If a major hospital loses power for 4–6 hours before fuel arrives, backup generators may fail to start (routine maintenance oversight), fuel-transfer equipment may jam with ash particles, or the facility may have only one fueling port, creating a bottleneck. Loss of power would affect surgical suites, HVAC systems, negative-pressure isolation rooms for respiratory patients, and refrigeration for biologics. A 4-hour outage could force cancellation of 10–20 surgeries, loss of 1–2 hours' worth of ventilator support if manual bagging fails, and potential patient deaths. Estimated impact: 5–15 preventable hospital patient deaths and 50–100 surgeries cancelled or delayed.

Likelihood: Medium

Severity: High

Action: Pre-position 72-hour fuel reserves (diesel, propane) at the three largest receiving hospitals (Bozeman Deaconess Medical Center, Livingston HealthCare, Eastern Idaho Regional Medical Center in Idaho Falls) at T-48 hours. Establish fuel-delivery contracts with local vendors (e.g., Yellowstone Energy, Basin Fuel) that include priority dispatch during the event and require arrival at hospital sites within 2 hours of a fuel request. Conduct a hospital-power-failure exercise with each facility 30 days before T+0, testing manual generator startup, fuel-transfer protocols and backup surgical protocols under ash-simulation conditions. Coordinate with the FAA and military to pre-authorize helicopter fuel deliveries to hospital helipads if ground routes are blocked, with fuel cached at forward airfield staging areas (e.g., Gallatin County Airport near Bozeman) at T-24 hours.

# Risk 7 - Operational / Visitor Accountability & Backcountry Hazard

Backcountry hikers, campers and thermal-basin researchers cannot be reliably located or evacuated within the T+6 hour window. The plan lists a 'Visitor Headcount Reconciliation and Backcountry Sweep Protocol' but does not specify the number of backcountry permits issued, the typical dispersal of permit holders, or how many ranger-hours and helicopter sorties are required to sweep all thermal basins, trailheads and camps within 6 hours. Yellowstone issues ~500–1,000 backcountry permits daily during peak season; locating and evacuating 300–500 scattered backcountry parties across ~3,500 square miles of park requires coordination with multiple ranger districts, helicopter support (which may be unavailable if ashfall has grounded all flights), and secondary evacuation routes.

Impact: If 50–100 backcountry parties (200–400 people) cannot reach main roads within T+6 hours, they may become trapped as ashfall intensifies and roads become impassable. Secondary evacuation by helicopter during ashfall is not feasible (engine damage risk); on-foot evacuation to safety could require 12–24 additional hours and expose hikers to respiratory distress and dehydration in ash. Estimated impact: 50–200 backcountry evacuees stranded at wilderness shelters or en route, with 5–20 hospitalized for respiratory distress or hypothermia after delayed extraction.

Likelihood: Medium

Severity: High

Action: At T-24 hours, issue an emergency permit cancellation and mandatory evacuation order to all outstanding backcountry permits, instructing permit-holders to exit via designated ranger-escorted routes or designated trail corridors. Pre-position ranger teams at key backcountry junctions (e.g., Norris-to-Canyon trail, Lamar Valley research stations) by T-12 hours, with satellite phones and emergency shelter supplies. Establish a dynamic backcountry tracking net using permit-holder check-ins via satellite messenger devices; at T+0, initiate hourly check-ins with all outstanding permit-holders and redirect non-responding parties to ranger-escort meeting points. Designate 2–3 'last-resort' wilderness shelters (pre-stocked with food, water, first aid and N95 respirators) in areas outside the modeled ashfall footprint (e.g., South Entrance/Thorofare region) so that any unplanned backcountry straggler has a signed shelter within 6–12 hours of evacuation start. Coordinate with the Wyoming-based Search and Rescue teams to stand by for ground-based extraction of stranded parties on foot after the main evacuation window closes at T+6 hours.

# Risk 8 - Regulatory & Jurisdictional / Multi-State Authority

Conflicting evacuation and shelter-in-place orders from adjacent state governors and the NPS could create public confusion and non-compliance. The plan specifies a Unified Command in Denver and explicit authority transfer at the park boundary, but does not document pre-authorization letters or MOUs from the governors of Montana, Wyoming and Idaho confirming that they will cede initial command authority to the NPS and accept the Unified Command's decision to evacuate Zone One communities. If a governor perceives the NPS and FEMA as over-reaching, or if local communities lobby for a 'shelter in place' option, a competing evacuation order could emerge.

Impact: A competing shelter-in-place order from a state governor could lead 10–20% of Zone One residents to defy evacuation instructions, stay in their homes, or delay departure. This 'shadow evacuation' of those who do leave could saturate the main corridors with unplanned traffic, reducing throughput for the 35,000 park visitors by 20–40% and causing an additional 2–4 hour delay in peak evacuation. Media coverage of the conflict could further reduce public trust in official messaging.

Likelihood: Medium

Severity: Medium

Action: Obtain written pre-event confirmation from the governors of Montana, Wyoming and Idaho that they authorize and will enforce the Unified Command's evacuation orders for Zone One (100 km radius) and any Scenario Beta expansion, and that they cede operational authority over park-boundary traffic and initial shelter placement to the NPS incident commander until the Unified Command issues a formal handoff order. Include these confirmations in a signed MOU 30 days before T+0, and brief state emergency management officials and National Guard commanders on the authority structure at a joint multi-state exercise 60 days before T+0. Establish a 24/7 governor-to-FEMA hotline and a weekly pre-event coordination call so that state leadership remains informed of the escalation triggers and can preemptively explain the authority structure to media and public.

# Risk 9 - Environmental / Ashfall & Air Quality

Ashfall composition, volume and dispersion are highly uncertain; modeled ash footprint and respiratory risk projections could be wrong by 50–200%, leading to incorrect shelter siting and underestimated N95 respirator demand. The plan specifies that final shelter locations will be selected at T+6 hours from the forecast wind and plume model, assuming the forecast is accurate. However, ashfall from a VEI-6 eruption has never been directly observed in North America, and volcanic ash grain-size distribution, settling rate, and regional wind variability could shift the predicted footprint by 100+ km or concentrate ash at higher than modeled levels. Pre-staged respirator stock of 100,000 N95 masks is based on a model estimate; if ashfall is heavier or more persistent than modeled, the stock could be exhausted within 24–48 hours.

Impact: If the actual ashfall footprint extends 20–50 km further than forecast, shelters selected at T+6 hours could be in areas of moderate to heavy ashfall, exposing evacuees to respiratory distress and requiring emergency relocation. A relocation of 10,000–15,000 evacuees from one shelter to another would require 3–6 hours of transport, additional buses, and a second intake and triage process, effectively delaying shelter operations by 6–12 hours. If ashfall is 2–3 times heavier than modeled, the 100,000 N95 masks would last only 12–24 hours instead of 72 hours, requiring urgent resupply. Estimated impact: 500–2,000 evacuees in unplanned ashfall zones develop respiratory distress within 6–24 hours; 5–10 die if medical care is delayed.

Likelihood: Medium

Severity: High

Action: Maintain continuous ashfall and air-quality monitoring at the forward command element and all three shelter sites using real-time PM10 and PM2.5 sensors and visual ash-depth markers. At T+6 hours, when final shelter locations are selected, update the selection based on the latest wind and plume forecast from NOAA and USGS, not the forecast used at T+0. Maintain a ranked second and third shelter backup for each primary site, located 50+ km upwind of the primary (to be confirmed daily from the latest wind forecast) so that if ashfall exceeds model predictions, a rapid (within 4 hours) relocation order can be issued. Pre-stage a supplemental 100,000 N95 masks at a secondary distribution hub (e.g., Billings or Salt Lake City) with a standing agreement for daily air or ground transport to the primary shelters if ash consumption exceeds 20% of stock per day. Conduct an air-quality monitoring exercise with NOAA and USGS 30 days before T+0, testing real-time forecast updates and relocation-decision protocols.

# Risk 10 - Operational / Responder Fatigue & Rotation

Responder exposure limits and relief rotation regime are not specified with concrete numbers. The plan lists 'Responder Exposure Limits and Relief Rotation Regime' as a secondary decision, but does not define shift lengths, withdrawal thresholds, or how many relief personnel are available for rangers, highway patrol, and National Guard personnel staffing contraflow checkpoints and perimeter gates. If rangers work 8-hour shifts with 16-hour rest, approximately 1.5 responders are needed per position to maintain continuous coverage, but the plan assumes roughly 100–150 rangers can staff 5–10 contraflow and perimeter checkpoints plus backcountry sweeps. At peak evacuation (T+2 to T+8 hours), all ranger hours are consumed, leaving no relief depth.

Impact: If a key traffic-control checkpoint or perimeter gate loses its staffing because responders reach fatigue limits and no relief is available, traffic flow could halt for 30–60 minutes or looting could occur undetected. Additionally, exhausted responders are more prone to errors (miscommunication of reroute instructions, failure to detect vehicles crossing the perimeter), increasing the risk of public-safety incidents. Estimated impact: 1–2 additional hours of evacuation delay due to checkpoint staffing gaps; 2–4 looting or unauthorized-entry incidents in evacuated towns.

Likelihood: Medium

Severity: Medium

Action: Define concrete exposure limits: rangers and highway patrol shall work maximum 6-hour shifts at ash-exposed locations (traffic checkpoints, perimeters) before mandatory 2-hour rest with N95 replacement, and all responders shall withdraw completely from ash zones after 18 consecutive hours of duty. Pre-authorize the forward command to request additional National Guard personnel from Fort Carson, Colorado (FEMA Region VIII) and other states if relief coverage falls below 50% at any checkpoint. Pre-stage a stand-by reserve of 30–50 trained traffic-control responders from other regions (e.g., Colorado Parks and Wildlife, Wyoming Game and Fish) at a staging depot outside the ash zone, ready to deploy within 4 hours if additional coverage is needed. Conduct a shift-rotation and fatigue-management exercise at a key control point 30 days before T+0, testing relief logistics and N95 replacement cycles under simulated ashfall.

# Risk 11 - Technical / Communications & Language Access

International visitors and non-English-speaking visitors may not receive evacuation instructions in time. The plan lists 'International Visitor, Language, and Access-Needs Notification Pathways' as a low-priority secondary decision, but does not specify what translations are prepared, which media outlets carry multilingual broadcasts, or how concession-operator networks will disseminate instructions. Yellowstone hosted ~4 million visitors in 2023, with ~40% from outside the USA. During peak season, non-English speakers could comprise 30–40% of the ~35,000 visitors in the park at any given time.

Impact: If 10,000–15,000 non-English-speaking visitors do not clearly understand evacuation instructions, they may delay departure, take wrong routes, or cluster at wrong shelters, wasting 1–2 hours and reducing overall corridor throughput. Additionally, visitors without vehicles (tour groups, those using park shuttles) may not understand reroute instructions and could become stranded at secondary destinations or held in queues longer than English-speakers. Estimated impact: 2,000–5,000 evacuees experience 2–4 hour delays due to language or transportation barriers; 10–20 left behind.

Likelihood: Medium

Severity: Low

Action: Pre-produce IPAWS messages and radio broadcasts in the five most-common visitor languages (Spanish, Japanese, German, Mandarin, French) by T-30 days, with simple, phased messages (e.g., 'Evacuate now,' 'Follow US-89 North,' 'Go to Shelter at [address]'). Coordinate with concessioner partners (Xanterra Parks and Resorts) to disseminate multilingual instructions to all guest rooms, tour buses and visitor centers at T-0. Pre-identify multilingual volunteers from each major tour operator and pre-position them at major lodges and campgrounds to translate instructions and assist non-vehicle-owning groups onto designated shuttle buses. Establish a dedicated shuttle-bus evacuation plan for tour groups and lodge-based visitors, with pre-assigned buses and drivers briefed 48 hours before the event window.

# Risk 12 - Operational / Public Compliance & Messaging Credibility

Public non-compliance with evacuation orders could increase if shelter-in-place messaging is used early (to prevent shadow evacuation) but then contradicted by a Scenario Beta escalation. The plan specifies that outer-zone residents in Bozeman, Billings and Idaho Falls should be told to shelter in place or follow time-banded departure schedules, but if a Scenario Beta trigger fires (VEI-7 indicators, 500 km evacuation order), the same populations must then evacuate immediately. This reversal could be perceived as government deception or incompetence, eroding trust in official channels and causing a chaotic, uncontrolled flight.

Impact: If public trust collapses due to a shelter-in-place reversal, uncontrolled evacuation of 50,000–200,000 outer-zone residents could begin within 2–4 hours of a Scenario Beta order, creating gridlock on I-15, I-90 and US-191 that prevents the organized Zone One evacuation of the 35,000 park visitors and strands medical transport. Additionally, reduced compliance with time-banded departure instructions or shelter assignments would increase the unplanned vehicle load on evacuation corridors by 20–40%, consuming an additional 4–6 hours of corridor throughput.

Likelihood: Medium

Severity: High

Action: Develop and pre-authorize an 'Adaptive Messaging Protocol' that explains the rationale for phased evacuation orders: initial shelter-in-place is based on current (low) eruption probability; Scenario Beta escalation will be triggered by specific USGS indicators (published in advance); outer-zone residents should monitor official channels daily and expect possible reversal if indicators cross thresholds. Deliver this protocol to media outlets, emergency management offices, and community leaders in Zone One communities (Bozeman, Gardiner, West Yellowstone, Cody) 60 days before T+0, so that the public understands the escalation logic. At T+0 hours, rebroadcast the protocol on IPAWS, local radio and TV to reinforce the message. If a Scenario Beta trigger fires, issue a separate messaging campaign explaining the new indicator values and stating that the previous shelter-in-place order is superseded, effective immediately. Conduct a messaging credibility exercise with local government and media 60 days before T+0 to test message clarity and anticipate public-response scenarios.

# Risk 13 - Financial / Procurement & Contracting

Procurement and contracting lead times for emergency supplies (bottled water, N95 respirators, generator fuel, buses, tents) are not addressed. The plan assumes water convoys can be 'mobilized within 12 hours,' but sourcing, loading and dispatching a convoy of 20–40 water trucks requires coordination with suppliers, transportation contractors, and state agencies. If contracts are not pre-positioned or suppliers are not pre-authorized, delays of 24–48 hours are typical for emergency procurements.

Impact: A 24-hour delay in water-convoy dispatch means the convoy does not arrive at Bozeman or Idaho Falls until T+36 hours (instead of T+12 hours), during which shelter occupancy could reach 15,000–20,000 people. Water shortages affecting thousands of evacuees for 24+ hours increase risk of dehydration, medication non-compliance, and secondary health emergencies. Similar delays in N95 respirator resupply could leave shelters and hospitals without adequate stock within 48 hours. Estimated impact: 1,000–3,000 evacuees experience 12–24 hours without adequate water; additional 20–50 respiratory distress cases.

Likelihood: Medium

Severity: Medium

Action: Execute pre-event contracts with bottled-water suppliers, N95 respirator manufacturers, generator-fuel wholesalers, and charter-bus operators 60 days before T+0, with explicit 'surge-mobilization' clauses requiring 12-hour dispatch of supplies upon verbal activation by the forward command. Identify alternative suppliers (e.g., water distributors in Pocatello, ID and Butte, MT; N95 suppliers in Salt Lake City and Denver) and list them in a standby-supplier roster. Pre-authorize payment via emergency FEMA contract vehicles so that suppliers can charge supplies immediately without normal competitive-bidding delays. Establish a procurement checkpoint at the forward command element tasked with tracking all inbound supply shipments and alerting the incident commander if any convoy is delayed >4 hours beyond dispatch.

# Risk 14 - Technical / Electric Grid Resilience

The plan identifies grid failure due to ash-induced flashovers as a contingency and directs generator fuel to hospitals and communications centers, but does not specify which transmission lines are at highest risk, which substations have single points of failure, or how voltage regulation and protective relays will behave under ashfall. Regional power utilities (Montana-Dakota Utilities, Pacific Power, Idaho Power) operate interconnected transmission networks that could experience cascading failures if multiple substations are hit by ash-induced flashovers simultaneously.

Impact: If a major transmission line fails and backup protection systems malfunction due to ash, a regional blackout affecting 100,000+ people could occur within 2–4 hours of ashfall onset, well before generator fuel can reach all facilities. A multi-hour regional blackout would affect water pumping and treatment, fuel convoys' refrigeration and communication equipment, ambulance dispatch centers, and shelter HVAC systems. Estimated impact: 4–8 hour regional blackout affecting 50,000–100,000+ people; 5–10 additional deaths in hospitals and care facilities due to loss of ventilator and life-support power.

Likelihood: Low

Severity: High

Action: Coordinate with Montana-Dakota Utilities, Pacific Power and Idaho Power 60 days before T+0 to identify critical transmission lines, substations and protective relays in the evacuation-corridor and shelter-area zones. Request pre-deployment of mobile generator units and voltage-regulation equipment at the two largest substations serving Bozeman and Idaho Falls. Establish a 24/7 utility-operations hotline from the forward command to the regional dispatch centers so that the incident commander can track grid status and request emergency load shedding or localized de-energization to prevent cascading failures. Conduct a grid-failure scenario exercise with utility operators 30 days before T+0, testing manual switchover procedures and the adequacy of generator fuel at critical facilities.

# Risk 15 - Operational / Landslide & Road Engineering

The South Entrance (US-89/191/287) is currently landslide-blocked, and the plan does not specify the debris volume, ground conditions or timeline for a single-lane clearance or bypass. Engineering assessment of the slide is not described. Secondary slides and hydrothermal explosions could further damage the North Entrance (US-89) and the Grand Loop Road during the evacuation window, adding to the blockage load.

Impact: If the South Entrance clearance attempt fails or takes >12 hours, the plan loses a potential third exit route and relies entirely on US-191/US-20 (west) and US-89 (north). This concentration adds 20–40% additional load to the two surviving corridors, extending evacuation time from 6 hours to 8–10 hours and increasing the overlap with ashfall onset. If a secondary explosion damages the North Entrance during the evacuation peak, that corridor could be reduced to one lane for 2–4 hours, creating a bottleneck that delays 2,000–4,000 vehicles.

Likelihood: Medium

Severity: High

Action: Conduct a pre-event geotechnical survey of the South Entrance landslide and the Grand Loop Road 60 days before T+0, using ground-penetrating radar and aerial drones to assess debris volume, slope stability and secondary slide risk. Develop a time-boxed single-lane clearance plan (max 4-hour work window) and a longer-term bypass-route plan, with pre-positioned heavy equipment and a clear abort trigger (e.g., renewed seismic activity M>4.0). Deploy a geotechnical monitoring team at the North Entrance and Grand Loop Road sections starting at T-12 hours to detect incipient slope movement and trigger temporary traffic closures before collapse. Establish a 'loss-of-exit' contingency: if the South Entrance or North Entrance becomes impassable and cannot be restored within 6 hours, the forward command will issue a shelter-in-place order for any vehicles still in the south or north sections of the park and redirect them to the nearest surviving exit (US-191/US-20 west or US-89 north) via the safest park roads available.

# Risk 16 - Operational / Visitor Transport & Special Needs

The plan does not specify transport arrangements for disabled visitors, elderly visitors in lodges, or families with children who may have mobility or medical constraints. A mandatory private-vehicle evacuation assumes all visitors have access to a functioning vehicle; the ~5–10% of visitors who arrived via tour bus, without a personal vehicle, or with mobility aids may face delays in accessing contraflow lanes or may be left behind if buses are not pre-allocated and staffed.

Impact: If 1,500–3,500 mobility-constrained or vehicle-less visitors cannot board evacuation shuttles within the first 2 hours, they may become trapped in lodges or at trailheads. Emergency extraction of such populations by helicopter is not feasible if airspace is closed or ashfall is heavy. These visitors could become casualties or stranded, requiring secondary rescue operations after the main evacuation window. Estimated impact: 200–500 stranded or delayed evacuees; 5–20 requiring rescue or hospital care due to exertion or medical decompensation.

Likelihood: Medium

Severity: Medium

Action: Coordinate with Xanterra Parks and Resorts and other concessioners 60 days before T+0 to identify all mobility-constrained guests and pre-arrange dedicated evacuation buses (1–2 buses per major lodge) staffed with attendants trained in mobility assistance. At T-12 hours, confirm occupancy of all lodges and tour groups via concessioner manifests, and designate a 'priority-transport' staging area at each lodge where mobility-constrained guests gather first, ahead of general traffic. Pre-authorize a secondary evacuation protocol: if any lodge or group cannot evacuate within the first 3 hours, notify the forward command, which will dispatch helicopter support (if available) or a ground-based rescue team from the National Guard. Pre-stage medical supplies and attendants at the priority-staging areas to manage any acute medical events during the evacuation wait.

# Risk 17 - Regulatory & Inter-agency Coordination

FAA authority over airspace grounding (ZLC and ZSE) is not explicitly coordinated with the Unified Command's decision-making. The plan states that a VEI-6 eruption will trigger grounding of ZLC and ZSE airspace, but the FAA operates independently and may not immediately coordinate grounding with the incident commander's needs for medevac, surveillance or emergency airlift. Conversely, the incident commander may want exceptions for medevac that the FAA blocks due to ash-concentration forecasts.

Impact: Delays in grounding coordination could result in one or more aircraft encountering ash and suffering engine damage within the first 2–4 hours of ashfall, adding a secondary emergency response load and reducing public trust in the warning system. Alternatively, rigid FAA grounding without any medevac exceptions could deny hospitals access to helicopter transport for critical patients, delaying some transfers by 4–6 hours and causing preventable deaths. Estimated impact: 1–3 aircraft-ash encounters; 2–5 critical patients unable to access helicopter medevac within the first 24 hours.

Likelihood: Low

Severity: High

Action: Establish a pre-event coordination protocol with the FAA Regional Flight Service Stations (Salt Lake City and Seattle centers) and the air-operations offices at mountain airports (Gallatin County, Jackson Hole, Billings) at least 60 days before T+0. Define an explicit trigger for airspace grounding (e.g., USGS detection of VEI-6 magma signatures, NOAA forecast of ash concentration >100 µg/m³ in flight corridors) and pre-authorize a narrow set of medevac and survey flight corridors below ash-concentration thresholds. Establish a 24/7 aviation-operations liaison at the forward command element with direct phone lines to the FAA regional desk and the military (Malmstrom AFB, Montana) to coordinate real-time flight requests and ash-model updates. Pre-authorize helicopter fuel caches at forward airfields (Gallatin County, Jackson Hole, Billings) to enable rapid deployment of medevac sorties if airspace restrictions are lifted temporarily.

# Risk Summary

This is a high-stakes, multi-state government evacuation plan for a VEI-6+ volcanic event at Yellowstone Caldera with a 72-hour decision window and (estimate) 40% eruption probability. The plan aims to evacuate ~35,000 tourists and 800 staff from the park interior (Zone Zero) within 6 hours and expand to 100 km radius communities (Zone One) within 24 hours. The three most critical risks are: (1) single-point road chokepoints on narrow, ash-exposed mountain corridors (US-191, US-89) with no bypass capacity if a breakdown, rockfall, or secondary slide occurs during peak evacuation; (2) cascading communications and command failures as cell towers collapse from ash and tremors, leaving drivers and responders unable to receive route updates, and the cross-jurisdiction authority transfer between NPS and three state governors creating command gaps; (3) shelter and hospital capacity collapse under Scenario Beta (VEI-7) expansion to 500 km radius, which would exceed all pre-staged supplies, road throughput and facility capacity, yet the trigger is pre-authorized without a defined secondary-stage evacuation plan. These three risks are tightly coupled: communication failure undermines the contraflow operation, command gaps delay the escalation decision, and inadequate shelter capacity forces uncontrolled shadow evacuation that saturates the very corridors the plan depends on. Mitigation relies on execution discipline, real-time asset positioning, and a credible second-stage plan for Scenario Beta that does not yet exist.

# Make Assumptions
# Question 1 - Funding Source and Budget Ceiling

## Assumptions

Funding comes from a federal emergency declaration (Stafford Act) plus pre-event contract vehicles, with an initial surge envelope of about USD 150–250 million (estimate), reimbursed through FEMA procedures. Large multi-state responses typically draw on declaration-based cost-sharing.

## Financial Feasibility Assessment

Evaluates funding availability and speed of access.

Risk: procurement delays of 24–48 hours (estimate) without pre-awarded contracts. Mitigation: pre-event surge contracts for water, N95, fuel and buses, with verbal activation. Opportunity: FEMA contract vehicles remove competitive-bidding delay. Track burn rate in USD hourly at the forward command; hold a 20% contingency (proposed) for Scenario Beta.

# Question 2 - Milestones and Decision Gates (72-Hour Window)

## Assumptions

Project starts at Month 0 (2026-10-14) with preparation as the first activity. Zone Zero cleared by T+6 hours, Zone One by T+24 hours, water convoys dispatched by T+12 hours, and shelter selection at T+6 from the plume forecast.

## Timeline Feasibility Assessment

Tests whether phase deadlines are achievable.

Risk: ashfall and gridlock may stretch the 12-hour convoy to 18–30 hours (estimate). Mitigation: pre-stage depots before T+0, reserved convoy lane, hourly gate reviews. Opportunity: a three-exit design shortens clearance. Hard abort triggers for southern clearance work keep the schedule from slipping.

# Question 3 - Personnel Availability

## Assumptions

About 100–150 NPS rangers (estimate), supplemented by Montana, Wyoming and Idaho highway patrol and Guard units, staff control points; relief depth is 1.5 responders per post (proposed). 8-hour shifts need that ratio for continuous coverage.

## Resource Adequacy Assessment

Compares staffing demand with likely availability.

Risk: all ranger hours consumed during T+2 to T+8, leaving no relief. Mitigation: request out-of-region Guard and a 30–50 person standby reserve (proposed), tier posts by criticality. Count responder N95s separately from the 100,000 civilian stock (user constraint). Opportunity: concessioner buses raise people per vehicle.

# Question 4 - Legal Authorities and Agreements

## Assumptions

Authority transfers at defined roadside checkpoints under a written protocol, backed by governor MOUs and EMAC mutual aid; Idaho coordination runs through a FEMA Region 10 liaison at the Denver RRCC. Standard Unified Command practice applies.

## Governance Assessment

Reviews command clarity and legal basis.

Risk: authority gaps mid-corridor delay reroutes by 15–45 minutes (estimate). Mitigation: Boundary Coordination Officer at the forward element, pre-signed MOUs, pre-authorized state reroute powers. FAA grounding needs a liaison at the Unified Command. Benefit: pre-agreed authority removes turf disputes and speeds the pre-authorized Scenario Beta order.

# Question 5 - Principal Life-Safety Hazards and Abort Criteria

## Assumptions

Principal hazards are corridor blockage in Gallatin Canyon, secondary slides at the South Entrance, backcountry stragglers, and hospital power loss. Abort criteria are seismic-based (e.g. renewed M4.0+ activity, proposed threshold) and blockage lasting over 45 minutes (proposed) triggers diversion.

## Safety and Risk Assessment

Prioritizes hazards by severity and likelihood.

Highest: single-point corridor failure (high/high). Mitigation: pre-placed tow and rockfall teams at chokepoints, geotechnical monitoring, diversion rule. Crew safety: time-boxed clearance with abort triggers. Medical: 72-hour fuel reserves at receiving hospitals. Maintain a risk register with owners and review each shift.

# Question 6 - Ashfall, Water Contamination and Air Quality

## Assumptions

Ash footprint forecasts are uncertain by tens of kilometers (estimate), so shelters are chosen at T+6 with ranked upwind backups, open reservoirs are isolated before ash, and N95 demand may exceed 100,000 (user constraint) within days.

## Environmental Impact Assessment

Evaluates ash, water and air-quality effects on operations.

Risk: shelters in heavier ash require relocating 10,000+ people (estimate). Mitigation: real-time PM10/PM2.5 sensors, backup sites 50+ km upwind (proposed), supplemental N95 stock at Billings or Salt Lake City, reservoir isolation. N95s clog quickly in heavy ash, so replacement cycles must be planned. Opportunity: USGS/NOAA plume updates refine siting.

# Question 7 - Stakeholder Engagement

## Assumptions

Engagement runs through the Unified Command liaison cell: governors via MOUs, concessioners such as Xanterra for lodge manifests and buses, utilities for grid coordination, and consular and multilingual channels for foreign visitors.

## Stakeholder Engagement Assessment

Maps who must be aligned and the risk of non-compliance.

Risk: conflicting shelter-in-place and evacuation orders cut corridor throughput 20–40% (estimate). Mitigation: unified messaging protocol, published USGS triggers, joint exercises. Non-English visitors may be a large share of the 35,000, so pre-produced multilingual alerts are needed. Opportunity: trusted local radio sustains credibility if escalation reverses earlier guidance.

# Question 8 - Communications, Traffic Management, Logistics and Power

## Assumptions

Layers are IPAWS/WEA/NOAA Weather Radio, Guard signal bridging, satellite terminals, highway advisory radio, variable message signs and printed route cards; priority generator fuel goes to hospitals and comms centers.

## Operational Systems Assessment

Tests resilience of comms, power and logistics tracking.

Risk: cell network failure leaves 10–20% of drivers on unintended routes (estimate). Mitigation: deploy repeaters and satellite phones to control points before ash, pre-recorded HAR messages, printed cards. Fuel tiering protects hospitals, comms and shelter kitchens. Test systems in ash-simulation exercises before the window. Use one shared common operating picture across NPS, states and Guard.

# Distill Assumptions
# Yellowstone Eruption Response Plan

## Overview

- Funding from Stafford Act declaration with USD 150-250 million surge envelope (estimate).
- Pre-awarded surge contracts for water, N95, fuel and buses avoid 24-48 hour procurement delays (estimate).
- Project starts Month 0 (2026-10-14) with preparation; Zone Zero cleared by T+6 hours, Zone One by T+24.
- Water convoys dispatch from Salt Lake City by T+12 hours; shelters selected at T+6 from plume forecast.
- 72-hour window carries 40% probability of VEI-6+ eruption (user constraint).
- Approximately 35,000 tourists and 800 staff exit via contraflow on US-191, US-20, US-89 to I-90.
- East Entrance toward Cody on US-14/16/20 provides third exit with fixed district-to-gate assignments.

## Staffing

- 100-150 NPS rangers (estimate) plus state patrol and Guard.
- 1.5 relief per post (proposed).
- 30-50 person standby reserve and out-of-region Guard requested.
- Responder N95s counted separately.

## Command and Control

- Authority transfers at roadside checkpoints under written protocol, governor MOUs and EMAC mutual aid.
- Unified Command sits at Denver RRCC with forward element in Bozeman or Livingston, plus Region 10 liaison.
- Pre-authorized USGS trigger matrix lets Unified Command order VEI-7 500 km expansion without further approval.

## Operational Triggers

- Corridor blockage over 45 minutes (proposed) or renewed M4.0+ activity (proposed) triggers diversion or abort.

## Communications

- IPAWS/WEA, NOAA Weather Radio, Guard signal bridging, satellites, highway advisory radio and printed cards.
- Multilingual alerts reach foreign visitors.

## Airspace

- ZLC and ZSE airspace grounded indefinitely.
- FAA liaison sits at Unified Command.

## Shelter Operations

- Bozeman and Idaho Falls shelters not safe from ash; ranked backups 50+ km upwind (proposed).
- N95 pre-staging covers 100,000 people (user constraint); demand may exceed it and masks clog quickly.

## Resource Management

- Open reservoirs isolated before ashfall.
- Fuel priority goes to hospitals, comms centers and shelter kitchens.
- Concessioners such as Xanterra supply lodge manifests and buses.

## Security and Support

- National Guard enforces exclusion perimeter and prevents looting while supporting logistics.

## Risk

- Shelter-in-place and evacuation orders conflict risk cutting corridor throughput 20-40% (estimate).


# Review Assumptions
# Domain of the expert reviewer
Government emergency management and disaster response planning, with focus on multi-jurisdiction civil protection operations, evacuation logistics, and life-safety decision-making under extreme time pressure and uncertainty.

## Domain-specific considerations

- Evacuation throughput and contraflow engineering under cascading hazards (ash, tremor, secondary slides) with hard time constraints and single-point failures
- Cross-jurisdiction command authority and decision-making speed during rapid escalation from 100 km to 500 km radius with conflicting state and federal mandates
- Communications resilience and public trust messaging when digital networks fail and escalation orders reverse earlier guidance
- Resource sustainability and responder protection across 72-96 hour continuous operations with fatigue, respiratory exposure and equipment degradation under ashfall
- Shelter capacity and life-support logistics for dynamic population (35,000 to potentially millions) with uncertain ash footprint and supply-chain fragility
- Scenario Beta secondary-stage planning: absent defined second-stage shelters, host-community coordination, and capacity for 500 km radius evacuation creates cascade-failure risk if trigger fires

# Issue 1 - Missing Scenario Beta Secondary-Stage Destination Plan and Capacity Analysis

The plan pre-authorizes a VEI-7 trigger ordering immediate 500 km radius evacuation, potentially affecting 100,000 to 500,000+ people across Montana, Wyoming, Idaho and Colorado. No second-stage shelter hubs, host-community coordination, onward transport routes, or supply-staging depots are defined. The stated shelter-siting strategy applies only to Bozeman and Idaho Falls (100 km radius), becoming overwhelmed within hours if Scenario Beta expands the evacuation, creating a vacuum where evacuees have no published destinations and triggering chaotic, uncontrolled flight on all routes away from Yellowstone.

## Recommendation

Develop and pre-authorize a written Scenario Beta Secondary-Stage Evacuation Plan by Month -2, specifying: (1) five to ten ranked secondary shelter hubs (Salt Lake City metro, Billings, Denver, Cheyenne, Boise) with capacity estimates and pre-signed MOUs with host communities; (2) tiered public messaging differentiating shelter-in-place zones (250–500 km, self-supplied residents), time-banded zones (100–250 km, shelters pre-assigned by county), and organized evacuation (Zone One); (3) bus fleets and rail corridors moving evacuees from primary shelters to secondary hubs using lateral routes away from I-90; (4) supply-estimation models for 100,000–500,000 additional people, with food, water, medical stock pre-positioned at secondary hubs before Month 0 (2026-10-14). Conduct a joint multi-state Scenario Beta exercise 30 days before the eruption window, testing messaging, routing and secondary-hub readiness. Assign ownership of each secondary hub to a named state/county emergency manager, with quarterly coordination calls before the event.

## Sensitivity

Baseline assumption: Scenario Beta affects 50,000–100,000 additional evacuees outside the 100 km radius (estimate). If no secondary plan exists and uncontrolled evacuation saturates I-15, I-80 and I-90, the delay to organized Zone One evacuation is estimated at 4–8 hours, reducing overall corridor throughput by 30–50% and extending the overlap between peak evacuation and ashfall arrival. Cost of secondary-hub pre-positioning and planning (estimated USD 20–40 million) is a fraction of the surge envelope (USD 150–250 million estimate); failure to execute costs an additional USD 100–200 million in emergency response and 5–20 preventable deaths in stranded populations.

# Issue 2 - Responder Exposure Limits and Relief Rotation Regime Undefined: Staffing Depth Insufficient for 72-Hour Operations

The plan lists responder exposure limits and relief rotation regime as a secondary decision but does not specify shift lengths, withdrawal thresholds, or relief-personnel count. Assumption of 100–150 NPS rangers (estimate), 1.5 relief per post (proposed), and no explicit responder N95 count creates a staffing gap: at peak evacuation (T+2 to T+8 hours), all ranger hours are consumed with zero relief depth. If strict exposure limits are applied (6-hour shifts with 2-hour rest before 18-hour withdrawal), coverage available at traffic-control and perimeter checkpoints during the evacuation peak may fall below 50%, causing throughput loss and enabling unauthorized entries or looting. Conversely, loose limits expose rangers to respiratory injury and entrapment, degrading the force when ashfall intensifies.

## Recommendation

Define concrete responder exposure limits in writing by Month -1: rangers and highway patrol work maximum 6-hour shifts at ash-exposed locations (contraflow points, perimeters, comms sites) before mandatory 2-hour rest with N95 replacement; all responders withdraw completely after 18 consecutive hours of duty. Count responder N95 respirators separately from the civilian stock (100,000 user constraint), with a minimum 50% surge buffer for replacement cycles (estimated 150,000–200,000 total responder+civilian stock). Pre-stage a 30–50 person standby reserve from outside the region (Colorado Parks and Wildlife, Wyoming Game and Fish, Idaho Department of Lands) at a logistics depot outside the ash zone, ready to deploy within 4 hours if coverage falls below 50% at any checkpoint. Pre-authorize the forward command to request additional National Guard from Fort Carson without needing supervisory approval. Conduct a shift-rotation exercise at a control point 30 days before the window, testing relief logistics, N95 replacement cycles and fatigue protocols under simulated ashfall.

## Sensitivity

Baseline staffing: 100–150 rangers at 1.5 relief ratio covers 100–150 positions with continuous staffing (estimate). If exposure limits reduce effective working time to 50% (6-hour shifts with 12-hour rest), available staffing drops to 50–75 people, creating gaps at 30–50% of positions. Each uncovered checkpoint reduces corridor throughput by ~5–10% (estimate), so understaffing adds 2–4 hours to total evacuation time and strands 500–2,000 vehicles in ash exposure. Cost of a 30–50 person standby reserve (estimated USD 3–5 million over 72 hours) prevents a 2–4 hour evacuation delay worth USD 50–100 million in indirect costs and 5–10 additional respiratory-distress casualties.

# Issue 3 - Ashfall Footprint Uncertainty and Dynamic Shelter-Siting Strategy Lack Real-Time Monitoring and Relocation Protocols

The plan states shelters will be selected at T+6 hours from the forecast wind and plume model, assuming forecast accuracy. Ashfall from a VEI-6 eruption has never been directly observed in North America; volcanic ash grain-size distribution, settling rates and regional wind variability could shift the modeled footprint by 100+ km. The plan pre-stages 100,000 N95 masks (user constraint) based on a model estimate; if ashfall is 2–3 times heavier than forecast, this stock lasts only 12–24 hours instead of 72 hours. The plan does not specify real-time ash and air-quality monitoring at shelter sites or a trigger to relocate evacuees if actual ashfall exceeds forecast, creating a scenario in which 10,000–15,000 evacuees are sheltered in zones of moderate to heavy ashfall, requiring emergency relocation within 6–12 hours.

## Recommendation

Establish continuous ashfall and air-quality monitoring at the forward command and all three shelter sites using real-time PM10/PM2.5 sensors and visual ash-depth markers, updated hourly starting at T-12 hours. At T+6 hours when final shelter locations are selected, update the selection based on the latest wind and plume forecast from NOAA and USGS, not the T+0 forecast. Maintain a ranked second and third shelter backup for each primary site, located 50+ km upwind (confirmed daily from the latest wind forecast) so a rapid relocation order can be issued within 4 hours if ashfall exceeds model predictions. Pre-stage a supplemental 100,000 N95 masks at a secondary distribution hub (Billings or Salt Lake City) with a standing agreement for daily air or ground transport to primary shelters if ash consumption exceeds 20% of stock per day. Conduct an air-quality monitoring exercise with NOAA and USGS 30 days before the window, testing real-time forecast updates, sensor accuracy and relocation-decision protocols.

## Sensitivity

Baseline model assumption: ashfall matches forecast within a 20 km margin, stock lasts 72 hours (estimate). If actual ashfall shifts 50+ km from forecast or doubles in intensity, shelter relocation is needed within 6–12 hours. Cost of relocating 10,000–15,000 evacuees (estimated USD 5–10 million in additional buses, intake processing and medical) is high, but failure to relocate results in 500–2,000 evacuees developing respiratory distress within 24 hours, with 5–10 preventable deaths. Pre-positioned backup shelters and supplemental N95 stock (estimated USD 10–15 million) avoid both costs.

# Issue 4 - Egress Corridor Chokepoint Vulnerability: Gallatin Canyon and Gardiner Single-Point Failures Lack Viable Bypass and Rapid-Clearance Capacity

The plan's three egress corridors (US-191/US-20 via Gallatin Canyon, US-89 via Gardiner, US-14/16/20 via Cody) depend on narrow, two-lane mountain passes with minimal shoulders, documented rockfall and secondary-slide hazard, and no pre-surveyed bypass routes. Gallatin Canyon is especially critical: a single breakdown, rockslide, or tremor-induced slide could block the entire contraflow and strand 500–2,000 vehicles within 30 minutes. The plan lists pre-positioned tow and rescue assets at chokepoints but does not specify the number of crews, equipment staging, or hard decision rules for diversion if clearance exceeds 45 minutes. The South Entrance remains landslide-blocked, eliminating a potential third southern exit.

## Recommendation

Pre-position at least two mobile heavy-equipment teams (wreckers, debris chippers, spotters) at Mammoth or Spanish Creek by Month -1, with 72-hour fuel and supplies, tasked to reach any Gallatin Canyon blockage within 15 minutes of dispatch. Establish live geotechnical monitoring along Gallatin Canyon, US-89 near Gardiner and Grand Loop Road using motion sensors or drones at identified slide-prone zones, with automatic alerts to the forward command if incipient movement is detected. Conduct a geotechnical survey of the South Entrance landslide 60 days before the window; develop a time-boxed (4-hour maximum proposed threshold) single-lane clearance plan and a longer-term bypass-route plan, with hard abort triggers tied to seismic activity (M>4.0 renewed swarm proposed threshold). Issue a written loss-of-exit contingency: if any primary corridor becomes impassable for more than 45 minutes (proposed threshold) and cannot be restored, the forward command will trigger overflow diversion to the nearest surviving exit and issue a shelter-in-place order for vehicles still in that sector. Test the tow-team mobilization and diversion protocol during a full-scale exercise 30 days before the window.

## Sensitivity

Baseline assumption: corridors remain passable with only routine debris clearing, or blockages are resolved within 30–45 minutes (estimate). If a major blockage occurs and persists for 2–4 hours, estimated impact is 5,000–8,000 stranded vehicles in one corridor, adding 2–4 hours to peak evacuation time and increasing the overlap with ashfall onset by 20–30%. Cost of pre-positioned tow equipment and crews (estimated USD 2–3 million) prevents a cascading 4-hour delay worth USD 50–100 million in indirect emergency response costs and 10–20 additional respiratory-distress casualties.

# Issue 5 - Cross-Jurisdiction Authority Transfer and Command Gaps: NPS-to-State Handoff and FEMA Region 8/10 Seams Lack Explicit Protocols and Real-Time Coordination

The plan specifies authority transfer at the park boundary under written protocol, with NPS incident commander handing responsibility to state governors at defined checkpoints. Contraflow traffic does not stop at jurisdictional lines; drivers cross from NPS to state control mid-queue, creating a window where no single authority owns traffic-reroute or shelter-assignment decisions. Idaho falls under FEMA Region 10 (Seattle) while Montana and Wyoming fall under Region 8 (Denver). The plan names only the Denver RRCC, leaving Region 10 mutual aid (Boise and Pocatello resources) uncoordinated and potentially delayed by 1–2 hours. The plan does not specify written MOUs with the three governors confirming their acceptance of NPS incident command authority or their agreement to enforce unified messaging.

## Recommendation

Establish a dedicated Boundary Coordination Officer role, co-located at the forward command element (Bozeman or Livingston), with real-time voice and data links to the NPS incident commander and the designated state highway patrol and National Guard commanders on both sides of the boundary. Issue a written protocol specifying that the boundary officer controls traffic reroutes and initial shelter assignments during the corridor crossing, and that NPS care ends at a specific roadside checkpoint (Mammoth Checkpoint or Gallatin County line) where state custody formally begins. Pre-authorize state on-scene commanders to issue temporary reroutes without requesting park ranger approval. Add an explicit FEMA Region 10 liaison call at T+0 hours from the Denver RRCC, with pre-agreed mutual aid arrangements (Boise and Pocatello fuel, water and medical resources) documented in a signed MOU 60 days before the window. Obtain written pre-event confirmation from the governors of Montana, Wyoming and Idaho confirming their authorization of the Unified Command's evacuation orders for Zone One and any Scenario Beta expansion, and their commitment to enforce unified public messaging. Conduct a multi-state command-authority exercise 60 days before the window, testing the boundary handoff, Region 8/10 coordination and governor-to-FEMA hotline under simulated escalation scenarios.

## Sensitivity

Baseline assumption: authority transfer occurs smoothly with no decision latency or jurisdictional conflict (estimate). If authority gaps delay reroutes or shelter assignments by 15–45 minutes, one instance cascades into a backup affecting 500–1,000 vehicles, adding 1–2 hours to peak evacuation. If FEMA Region 10 mutual aid is not pre-authorized, water and fuel convoys from Boise or Pocatello are delayed 1–2 hours, leaving shelters 12–24 hours without adequate supply. Cost of pre-event MOUs and one multi-state exercise (estimated USD 0.5–1 million) prevents a 1–2 hour evacuation delay and supply shortage worth USD 50–100 million in indirect costs.

# Issue 6 - Communications Layer Fragility Under Cascading Failures: Ash-Induced Cell-Network Collapse and Tremor Damage Leave IPAWS and Bridge Systems Untested Under Actual Conditions

The plan relies on IPAWS and Wireless Emergency Alerts as the primary public channel, with National Guard signal bridging as the fallback for responder coordination at gateway towns. Ash-induced flashovers on transmission lines, tremor damage to cell towers, and silicate-ash clogging of repeater fans could collapse the local network faster than signal units can deploy. The plan does not specify the number of Guard signal units available, their staging locations, fuel and equipment pre-positioning, or testing protocols under simulated ashfall. Printed route cards and highway advisory radio (HAR) are mentioned as fallbacks but are not pre-produced or validated for clarity and multilingual comprehension. The plan assumes Guard signal bridging restores responder radios at gateway towns but does not specify which towns, how many radio channels are needed, or how interoperability among NPS, state patrol and Guard nets is verified before the event.

## Recommendation

Deploy National Guard signal corps teams with satellite phones, portable repeaters, and generator fuel to each contraflow control point and the forward command element (Bozeman/Livingston) at T-12 hours, before ashfall onset. Pre-stage printed route cards and windshield placards at all park entrance stations and lodges by Month -1, with simple instructions in English and the five most common visitor languages (Spanish, Japanese, German, Mandarin, French), including shelter addresses and contact numbers. Activate all available highway advisory radio stations and variable message signs along US-191, US-20, US-89 and I-90 with pre-recorded messages updated hourly from the forward command. Specify that Guard signal teams will establish redundant radio nets at West Yellowstone, Gardiner, Cody, Bozeman, Idaho Falls and Livingston, with formal interoperability testing 30 days before the window (on-air checks across all agencies, frequency coordination, call signs and protocol). Test satellite and portable-repeater systems in ash-simulation exercises at each control point 30 days before the window, measuring ashfall effects on radio propagation, equipment overheating and operator visibility.

## Sensitivity

Baseline assumption: IPAWS and WEA function for the first 4–6 hours, giving drivers time to depart; Guard signal bridging restores responder coordination within 2–4 hours of deployment (estimate). If cell network fails within 1–2 hours and Guard signal units are delayed in deployment, an estimated 10–20% of drivers take unintended routes, adding 1–3 hours to some transit times. Loss of responder-coordination for 30 minutes to 2 hours delays 5–10% of ambulance and hospital patient transfers. Cost of signal units, satellites, repeaters and fuel (estimated USD 5–10 million) prevents a 1–3 hour evacuation delay and routing chaos worth USD 100–200 million in indirect costs and 10–20 additional casualties.

# Issue 7 - International and Non-English-Speaking Visitor Notification: Language Access and Mobility-Assistance Gaps Leave 10,000–15,000 Vulnerable Visitors Unaccounted For

The plan lists international visitor, language, and access-needs notification pathways as a low-priority decision, stating only that concessioner and consular networks should carry instructions. Yellowstone hosted ~4 million visitors in 2023, with approximately 40% from outside the USA. During peak season, non-English speakers could comprise 30–40% of the 35,000 visitors in the park at any time (estimate), meaning 10,000–15,000 evacuees may not understand English-language IPAWS alerts or ranger announcements. The plan does not specify how visitors arriving via tour buses, without personal vehicles, or with mobility aids will access contraflow lanes or priority evacuation shuttles. Visitors without vehicles and unclear evacuation instructions could delay departure, cluster at wrong shelters, or become stranded if buses are not pre-allocated and staffed.

## Recommendation

Pre-produce IPAWS messages, radio broadcasts and digital alerts in the five most common visitor languages (Spanish, Japanese, German, Mandarin, French) by Month -1, with simple, phased messages. Coordinate with concessioner Xanterra Parks and Resorts to pre-arrange multilingual briefings for all guest rooms, tour buses and visitor centers at T-0 hours. Pre-identify 20–50 multilingual volunteers from major tour operators and position them at major lodges and campgrounds by T-0, with translation materials and communication devices. Establish a dedicated shuttle-bus evacuation plan for tour groups and lodge-based visitors by Month -1, pre-assigning 4–6 buses per major lodge (estimated 20–30 buses total) with pre-briefed drivers and attendants trained in mobility assistance. At T-12 hours, confirm lodge occupancy via concessioner manifests and create priority-transport staging areas at each lodge for mobility-constrained guests, with medical supplies and attendants pre-positioned to manage acute events. Pre-authorize a secondary protocol: if any lodge cannot evacuate within 3 hours, notify the forward command, which will dispatch helicopter support (if available) or ground rescue teams from the National Guard.

## Sensitivity

Baseline assumption: English-language alerts and visual traffic cues reach 90% of visitors; 10% (3,500 people estimate) experience 1–2 hour delays due to language or mobility barriers. If multilingual alerts are absent and mobility assistance is not pre-arranged, this proportion could rise to 30–40% (10,000–15,000 people), adding 2–4 hours to some evacuee transit times and stranding 50–200 people. Cost of pre-produced multilingual materials, volunteer coordination and dedicated shuttle buses (estimated USD 2–3 million) prevents a 2–4 hour evacuation delay and 5–15 preventable stranding incidents.

# Issue 8 - Hospital and Utility Power Grid Failure: No Explicit Fuel Pre-Positioning Timeline, Multi-Hour Generator Startup Failures, and Cascade-Failure Risk Under Simultaneous Ashfall on Multiple Substations

The plan identifies grid failure as a contingency and directs fuel priority to hospitals and communications centers, but does not specify which hospitals are critical receivers, fuel pre-positioning timeline, or how many hospitals have adequate on-site reserves. Regional hospitals typically have 24–48-hour generator fuel on hand; simultaneous power loss across multiple substations due to ash-induced flashovers could occur within 4–8 hours of ashfall, faster than fuel convoys can deliver from distant depots (Rock Springs, WY is 200+ miles away estimate). Hospitals often have single fueling ports and outdated generators with startup failures during high-stress events; a 4-hour outage before generator fuel arrives could force cancellation of 10–20 surgeries and loss of ventilator support if manual bagging fails. The plan does not coordinate with regional power utilities to identify critical transmission lines, substations with single-point failures, or protective relay behavior under ashfall.

## Recommendation

Pre-position 72-hour diesel and propane fuel reserves at the three largest receiving hospitals (Bozeman Deaconess Medical Center, Livingston HealthCare, Eastern Idaho Regional Medical Center) by Month -1, confirming tank capacity and fueling-port adequacy with each facility. Establish fuel-delivery contracts with local vendors (Yellowstone Energy, Basin Fuel) requiring priority dispatch and arrival within 2 hours of a fuel request during the event. Conduct a hospital-power-failure and generator-startup exercise at each facility 30 days before the window, testing manual generator startup procedures, fuel-transfer protocols, load-shedding protocols and backup surgical equipment under simulated ashfall. Coordinate with Montana-Dakota Utilities, Pacific Power and Idaho Power 60 days before the window to identify critical transmission lines, substations and protective relays in the evacuation and shelter zones. Request pre-deployment of mobile generator units and voltage-regulation equipment at the two largest substations serving Bozeman and Idaho Falls. Establish a 24/7 utility-operations hotline from the forward command to each regional dispatch center so the incident commander can track grid status and request emergency load shedding or localized de-energization to prevent cascading failures. Pre-authorize helicopter fuel caches at forward airfields (Gallatin County, Jackson Hole, Billings) to enable rapid delivery of fuel or emergency medical supplies to isolated hospitals if ground routes are blocked.

## Sensitivity

Baseline assumption: power is lost at 1–2 hospitals within 4–6 hours of ashfall; fuel convoys arrive within 6–8 hours (estimate). If simultaneous flashovers damage multiple substations and fuel is delayed 12+ hours, an estimated 4–6 hour outage could prevent 10–20 surgeries and cause 5–10 preventable patient deaths due to ventilator support loss. Cost of pre-positioned fuel reserves and utility coordination (estimated USD 5–10 million) prevents a multi-hospital crisis worth USD 50–100 million in emergency response and patient casualties.

# Review conclusion

This plan addresses core evacuation logistics (corridors, command, communications) effectively. Three critical gaps threaten success: (1) the pre-authorized Scenario Beta VEI-7 trigger lacks a defined secondary-stage plan, leaving 100,000–500,000 additional evacuees without destinations and risking chaotic shadow evacuation that strands Zone One visitors; (2) responder staffing for 72-hour operations is underspecified (no concrete shift limits, relief depth or separate N95 count), risking coverage gaps at traffic and perimeter checkpoints during the evacuation peak; (3) ashfall forecasts and shelter siting are static, lacking real-time monitoring and relocation protocols when actual ashfall diverges from model predictions. These three issues are tightly coupled: inadequate Scenario Beta planning drives uncontrolled shadow evacuation that saturates corridors already threatened by single-point chokepoints; responder fatigue degrades traffic control during that chaos; and incorrect shelter siting forces emergency relocations during the same peak period.

## Immediate actions

(1) Develop and pre-authorize Scenario Beta secondary-stage destinations and messaging by Month -2; (2) define responder exposure limits, relief staffing (30–50 person standby reserve) and separate N95 counts by Month -1; (3) establish continuous ashfall monitoring at shelters and pre-authorize 4-hour relocation protocols by Month -1. These actions cost an estimated USD 30–60 million but prevent a cascading 4–8 hour evacuation delay and 20–50 preventable deaths, with benefit-cost ratio >10:1.