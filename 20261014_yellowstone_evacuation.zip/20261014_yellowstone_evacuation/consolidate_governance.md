# Governance Audit


## Audit - Corruption Risks

- Vendor collusion on bottled-water and N95 respirator supply contracts: suppliers inflate prices during the surge, or coordinate bids to exclude competitors, knowing FEMA contract vehicles bypass competitive bidding. Mitigation: pre-audit all surge-contract pricing against historical benchmarks; rotate vendors across regional hubs; require transparent cost breakdowns in invoices.
- Diversion of pre-positioned fuel and N95 stocks at forward depots (Bozeman, Billings, Idaho Falls): staff or contractors resell critical supplies on the black market instead of routing them to hospitals and shelters, motivated by scarcity pricing during the event. Mitigation: weekly inventory audits at each depot starting T-48 hours; chain-of-custody tags on all pallets; surprise physical counts at T+6 and T+24 hours.
- Favoritism in shelter-site selection and contract awards: forward-command staff steer shelter locations to facilities or contractors with personal or financial ties, reducing suitability and increasing cost. Mitigation: document the T+6 shelter-siting decision with NOAA/USGS wind-forecast data and PM10 sensor readings; disclose declared conflicts of interest for all siting committee members; third-party review of site selection rationale by Month 2 (2026-12-14).
- Kickbacks or side deals in bus and ambulance dispatch contracts: contractors assign vehicles to private evacuees or commercial operations not authorized by the Unified Command, delaying public transportation and diverting fuel. Mitigation: GPS tracking and log audit of all contracted vehicles; reconcile vehicle-hours invoiced against dispatch logs; spot-check random routes to confirm actual evacuee transport.
- Abuse of authority in perimeter and re-entry control: National Guard personnel or contractors allow unauthorized entries into the exclusion zone in exchange for bribes or favors, enabling looting or unauthorized resource extraction. Mitigation: checkpoint video surveillance; roster verification of all personnel at perimeter gates; weekly independent audits of entry logs versus authorized-access lists.
- Misuse of FEMA contract vehicles for non-emergency purposes: personnel use pre-positioned water trucks, buses or fuel tankers for unauthorized tasks (personal transport, commercial operations) before or after the event window, reducing availability and integrity. Mitigation: pre-event equipment inventory with photos; GPS tracking active from T-0 to T+72; post-event mileage and fuel-consumption audits; certification of only-evacuation-related use.

## Audit - Misallocation Risks

- Budget misuse in pre-event readiness spending: USD 47.5–87 million (estimate) allocated to responder reserves, N95 stocks, tow teams and MOUs is not tracked against actual deliverables; some funds are spent on lower-priority items (e.g., office supplies, training tangential to evacuation) instead of critical capabilities (e.g., backup shelter facilities, supplemental water). Mitigation: detailed line-item budget tracking; monthly burn-rate reviews from Month -2 through Month 0 (2026-10-14); earned-value audits linking spending to deliverable completion (e.g., signed MOUs, trained responders).
- Double-spending on shelter facilities: both federal funds and state/local contributions are committed to the same shelter site (Bozeman, Idaho Falls) without coordination, creating duplicate costs or inadequate cost-sharing agreements. The plan does not clarify federal vs. state funding responsibility. Mitigation: written cost-sharing agreements by Month 1 (2026-11-14); monthly reconciliation of all facility invoices across funding sources; audit trail showing which entity paid for each service.
- Inefficient allocation of responder hours: traffic-control rangers are deployed to low-priority checkpoint positions while backcountry sweeps and perimeter patrols remain under-staffed, consuming 100–150 ranger hours on non-critical tasks during the T+2 to T+8 peak when all hours are scarce. Mitigation: pre-event staffing plan assigning rangers to positions by priority (evacuation corridors tier 1, backcountry sweeps tier 2, perimeters tier 3); shift logs audited weekly to verify adherence.
- Procurement delays and emergency cost overruns: surge contracts lack binding 12-hour dispatch clauses, leading to 24–48 hour (estimate) delays and forcing emergency procurement at premium pricing (estimated additional USD 10–20 million for expedited water and fuel). Mitigation: contract language audits by legal counsel 60 days before Month 0 (2026-10-14); written dispatch timelines with liquidated-damages clauses; daily burn-rate tracking against the USD 40 million contingency reserve.
- Misallocation of communication equipment and operator hours: Guard signal teams are deployed to all 6 gateway towns (Livingston, Bozeman, West Yellowstone, Gardiner, Cody, Idaho Falls) without prioritization, consuming fuel and operator fatigue on secondary locations while primary contraflow points (Gallatin Canyon, North Entrance) lack continuous coverage. Mitigation: priority-ranking of signal-team locations by traffic volume and ashfall exposure; weekly operator fatigue audits; real-time signal-quality metrics recorded at each site.
- Unauthorized use of pre-positioned supplies for non-evacuation purposes: N95 masks or water pre-staged at shelters are used for other medical or municipal operations before T+0, reducing the available stock for evacuees. Mitigation: seal all pre-positioned supplies at T-48 hours; custody logs with daily verification signatures; forensic inventory counts at T+0 and T+24 to detect depletion.

## Audit - Procedures

- Pre-event readiness audit (Months 1–0): quarterly reviews of all pre-positioned supplies (water, N95, fuel, tow equipment) at forward depots and receiving hospitals, including inventory counts, expiration dates, equipment functionality tests and cost reconciliation against budgets. Document deviations and corrective actions in a readiness log reviewed by the Unified Command.
- Real-time operational audit of surge contracts and procurement (T+0 to T+72 hours): daily burn-rate tracking against the USD 200 million envelope; invoice audits confirming unit prices, quantities and delivery timelines match contract terms; spot-check 10% of supply deliveries for quality and quantity. Assign a dedicated procurement-compliance officer at the forward command.
- Post-event contract and vendor reconciliation audit (Month 1 = 2026-11-14): audit all surge contracts within 30 days of closeout, verifying actual deliveries, pricing compliance, dispatch-time adherence and any change-order justifications; identify and recover any overbillings or unauthorized extras; publish summary findings to the Unified Command.
- Asset tracking and custody audit (T+0 to T+72 hours and Month 1 = 2026-11-14 after-action): GPS tracking on all FEMA contract vehicles and fuel tankers; weekly vehicle-hours reconciliation against dispatch logs; mileage and fuel-consumption audits post-event to certify evacuation-only use; investigate any discrepancies >5% of expected usage.
- Responder staffing and exposure audit (T+0 to T+72 hours): daily shift logs for all traffic-control, perimeter and backcountry-sweep personnel, recording hours worked, location, exposure conditions and relief cycles; monthly analysis comparing actual deployment to priority staffing plan; audit for compliance with 6-hour shift and 18-hour withdrawal limits.
- Shelter capacity and relocation audit (T+6 to T+72 hours): daily census counts at Bozeman, Idaho Falls and any third/backup shelters; reconciliation of arrivals, departures and on-site population against expected inflow; if relocation is triggered, document decision drivers (PM10 readings, wind forecast), execution timeline and outcomes. Post-event review of shelter-siting effectiveness.

## Audit - Transparency Measures

- Unified Command common operating picture (T+0 to T+72 hours): a shared digital dashboard accessible to all primary stakeholders (NPS, states, FEMA Regions 8 and 10, Guard commands) displaying real-time status of evacuation progress (cumulative exit counts by gate and time), shelter occupancy, supply deliveries (water, fuel, N95), responder status (staffed vs. uncovered positions), and communications outages. Updated hourly and published daily to state emergency management offices.
- Published USGS eruption-trigger matrix and escalation decision log (Month -1 and T+0 to T+72): explicit, written threshold values for USGS indicators (uplift rate, seismic magnitude, gas flux) that trigger Scenario Beta expansion to 500 km radius; posted to the Unified Command website and distributed to media, governors' offices and Zone One communities. Document each decision to issue or withhold the 500 km order, with the date, trigger values at that moment, and the Unified Command authorized signature.
- Post-event after-action report and audited financial summary (Month 2 = 2026-12-14): detailed summary of phase-by-phase execution, including actual vs. planned throughput, supply deliveries, responder hours and any corrective actions; full accounting of all expenditures by line item, identifying budget variances >10% with explanations; lessons learned and recommendations for future events. Distribute to FEMA, governors and the public.
- Shelter-siting decision documentation and public notice (T+6 hours): written record of the shelter-site selection process, including the wind and plume forecasts used, PM10 sensor readings at candidate sites, and the rationale for each primary and backup choice; published to Zone One residents and evacuees upon notification of their assigned shelter.
- Responder exposure and fatigue logs, summarized monthly (Months 0–1 = 2026-10-14 to 2026-11-14): aggregate analysis of all shift logs showing median and maximum hours worked, relief-cycle compliance rates and any exposure-limit violations; identify any personnel who worked beyond 18 consecutive hours and require post-event health screening. Publish summary compliance rate (e.g., '98% of all shifts compliant with 6-hour limit') in the after-action report.
- Incident-specific audit reports for high-value decisions (Months 1–2 = 2026-11-14 to 2026-12-14): independent audits of the three most-critical cost and outcome drivers—shelter relocations (if any), Scenario Beta secondary-hub designation (if triggered), and hospital/utility power and supply contingencies. Each audit published with findings and recommendations accessible to the Unified Command and state officials.

# Internal Governance Bodies

### 1. Unified Command (UC) – Strategic Oversight Board

**Rationale for Inclusion:** A 72-hour window with 40% eruption probability (user constraint) and multi-state jurisdiction requires a single, pre-authorized strategic authority over zone expansion, escalation triggers, and inter-agency resource requests. The UC sits at FEMA Region VIII RRCC Denver and must coordinate Regions 8 and 10, three state governors, NPS, and the FAA to avoid authority gaps and command paralysis. Its primary role is authorizing the pre-written Scenario Beta VEI-7 trigger and issuing the 500 km evacuation order within 30 minutes of detection.

**Responsibilities:**

- Activate the Unified Command at T+0 and authorize contraflow and initial evacuation orders
- Monitor USGS eruption indicators and authorize Scenario Beta 500 km expansion under the pre-written trigger matrix within 30 min of threshold crossing
- Authorize authority transfer at park boundaries and resolve any NPS-to-governor jurisdiction disputes in real time
- Approve shelter-siting decisions at T+6 h based on NOAA/USGS plume forecast and PM10 sensor data
- Allocate emergency resources across multi-state response and approve any critical supply-chain reroutes
- Issue and maintain public messaging on evacuation zones, shelter assignments and escalation triggers to sustain credibility

**Initial Setup Actions:**

- Seat the Unified Command with federal, state and NPS representatives at FEMA Region VIII RRCC Denver by T+0
- Activate FEMA Region 10 liaison and confirm region-to-region communication links
- Publish the pre-authorized USGS trigger matrix to media and Zone One communities at T+0
- Establish a 24/7 shared common operating picture (digital dashboard) tracking evacuation progress, supply deliveries and responder status, updated hourly
- Conduct verbal pre-authorization calls with MT, WY and ID governors confirming Zone One and Scenario Beta orders by T+6 h

**Membership:**

- FEMA Region VIII Incident Commander (chair)
- FEMA Region 10 liaison (Region 10 authority, Idaho coordination)
- NPS Incident Commander or delegated senior NPS official
- Montana State Emergency Manager and Governor's designee
- Wyoming State Emergency Manager and Governor's designee
- Idaho State Emergency Manager and Governor's designee
- USGS lead volcanologist (ex officio, eruption monitoring and trigger authority)
- NOAA forecast lead (ex officio, ashfall and air-quality authority)

**Decision Rights:** The UC authorizes all strategic decisions with multi-state or federal implications: (1) evacuation zone expansion (Zone Zero to One to Beta); (2) authority transfer and boundary handoffs; (3) shelter-siting and relocation orders; (4) resource allocation above the operational management threshold (USD 10 million per decision, proposed); (5) any messaging reversal or escalation signal to the public. Decisions requiring consensus; in the event of tie or disagreement, the FEMA Region VIII IC has final authority, with a documented dissent from the disagreeing state recorded for accountability.

**Decision Mechanism:** The UC meets in continuous session (at least hourly briefings) during the 72-hour window and stands up as needed thereafter. Decisions on evacuation expansion and shelter siting are made by real-time consensus on the shared common operating picture, with decision triggers defined in the pre-written matrix (USGS indicators and PM10 thresholds). Tie-breaker: FEMA Region VIII IC, with one veto override right per state governor (may be used once to block a decision; once used, majority rule prevails thereafter). All decisions documented in real time in the shared log.

**Meeting Cadence:** Continuous operation during the 72-hour window (Month 0 = 2026-10-14, T+0 to T+72 h); hourly formal briefings at T+0, T+2, T+6, T+12, T+24, T+36, T+48, T+60, T+72 h, plus ad hoc calls on trigger events (Scenario Beta, shelter relocation, authority disputes). Post-window: weekly calls from Month 1 (2026-11-14) through Month 3 (2027-01-14 to 2027-01-14) to finalize MOUs, plan exercises and review after-action items.

**Typical Agenda Items:**

- Current evacuation progress: cumulative exit counts by gate and time, zone-clearance status against T+6 and T+24 h gates
- USGS eruption indicators and proximity to Scenario Beta trigger thresholds; ashfall forecast and PM10 readings at all shelter sites
- Supply deliveries: water convoy status, N95 distribution, fuel inventory at hospitals and comms centers
- Authority and jurisdictional issues: boundary handoff execution, state reroute compliance, any NPS-governor conflicts
- Responder status: staffed vs. uncovered posts, fatigue reports, any exposure-limit breaches or relief shortfalls
- Communications status: IPAWS/WEA delivery, Guard signal bridging coverage, any digital-network degradation

**Escalation Path:** The UC is the apex strategic authority for the evacuation response. Disagreements among members (states vs. federal, or state vs. state) are resolved by UC consensus; if consensus fails, the FEMA Region VIII IC decision prevails with documented dissent. Constitutional or legal challenges to the evacuation order (e.g., governor refuses to enforce a UC-issued relocation directive) are escalated to the U.S. Attorney's Office (Colorado District) and the White House Chief of Staff via the FEMA Regional Administrator. Resource allocation disputes exceeding the USD 10 million threshold or requiring supplemental declaration authority are escalated to the FEMA Deputy Administrator in Washington.
### 2. Forward Unified Command Element (FUCE) – Operational Management & Incident Control

**Rationale for Inclusion:** The Denver RRCC is 250+ km from the evacuation corridors (US-191, US-89, I-90), creating a decision latency of 2-4 hours for reroute orders and real-time resource dispatch. The FUCE co-locates the incident command team at Livingston or Bozeman, MT, within sight of the contraflow corridors and shelter sites, enabling rapid reroute directives, supply-chain troubleshooting and real-time response to corridor blockages or ashfall shifts. The FUCE operates under authority delegated by the UC and reports status hourly to the UC dashboard.

**Responsibilities:**

- Execute contraflow traffic management on US-191, US-20, US-89 and I-90, authorize reroutes and diversion rules within the T+6 h clearance window
- Dispatch tow and rockfall-clearance teams to corridor chokepoints, enforce the 45-minute blockage-diversion threshold (proposed), and manage loss-of-exit contingencies
- Activate Guard signal teams and communications infrastructure at each control point; maintain hourly updates to the UC common operating picture
- Monitor real-time PM10 and ashfall depth at all shelter sites; trigger shelter-relocation decisions within 4 h if exceedance is detected (proposed threshold)
- Manage water convoy dispatch from Salt Lake City, authorize priority-lane allocation and track arrival times against the T+12 h and T+24 h targets
- Coordinate with state highway patrol and National Guard commanders at each state boundary to enforce the authority-transfer protocol and prevent jurisdictional disputes

**Initial Setup Actions:**

- Establish the FUCE at Livingston, MT (or alternate Bozeman) by T+0, with direct communication links to the UC in Denver and to all state EOCs
- Deploy Guard signal teams, satellite phones and repeaters to all control points and shelters by T+1 h (proposed threshold)
- Position tow and rockfall-clearance teams at Mammoth and Spanish Creek by T+0
- Activate real-time PM10 monitoring at the forward element and every shelter site by T+0
- Confirm concessioner lodge manifests and bus availability for priority evacuation at each facility by T+0
- Brief state on-scene commanders at West Yellowstone, Gardiner and Cody on authority-transfer protocols and pre-authorized reroute powers by T+0

**Membership:**

- Operations Section Chief (FUCE incident commander, delegates from FEMA and NPS, chair)
- Logistics Section Chief (water, fuel, N95 supply tracking)
- Planning Section Chief (common operating picture, USGS indicator tracking, Scenario Beta readiness)
- Safety Officer (responder exposure limits, N95 replacement cycles, fatigue monitoring)
- Boundary Coordination Officer (NPS-to-state authority transfer, reroute approvals at each gate)
- Guard Signal Officer (communications status and redundancy management)
- NOAA/USGS liaison (real-time plume forecast and PM10 sensor updates)

**Decision Rights:** The FUCE makes all operational decisions within the pre-authorized rules: (1) reroute orders and traffic-control post assignments (within total of 100-150 rangers and Guard personnel, proposed); (2) tow-team dispatch and the 45-minute blockage-diversion trigger; (3) water convoy priority and reserved-lane allocation on I-15; (4) shelter-relocation orders if PM10 exceeds thresholds (proposed); (5) responder shift assignments and relief activation. Decisions below the USD 10 million threshold do not require UC approval. Any decision that conflicts with an active UC order or requires deviation from the pre-written trigger matrix must escalate to the UC within 15 minutes.

**Decision Mechanism:** The FUCE operates on a continuous real-time basis, making decisions as conditions change (blockages, ashfall, supply delays). Standing orders and pre-authorized thresholds guide decisions without waiting for UC approval. Example: if Gallatin Canyon blockage lasts >45 minutes, overflow is automatically diverted to US-89 without FUCE debate. If PM10 exceeds 100 ug/m3 at Bozeman shelter, a backup-site relocation analysis is triggered within 30 minutes and a relocation order (if suitability threshold is met) is issued within 4 h. Tie-breaker: Operations Section Chief, with a dissent flag to the UC if the decision creates new risk.

**Meeting Cadence:** Continuous operation and real-time decision-making during the 72-hour window (T+0 to T+72 h). Formal briefing calls to the UC at T+0, T+2, T+6, T+12, T+24, T+36, T+48, T+60, T+72 h. Internal FUCE section briefings every 2 hours during peak evacuation (T+2 to T+8 h) to synchronize logistics, planning and communications. After-action reviews during Months 1-3 (2026-11-14 to 2027-01-14).

**Typical Agenda Items:**

- Real-time evacuation status: cumulative vehicle counts at each gate, queue length and flow rate (vehicles/h), ETA for 98% clearance
- Corridor blockage and tow status: any incidents detected, clearance time estimates, overflow-diversion decisions and their impact on other gates
- Water and supply convoy tracking: departure time from Salt Lake City, current location, ETA at shelters, any delays or route changes
- Ashfall and PM10 readings: real-time sensor data at each shelter, forecast updates from NOAA, any triggers for relocation analysis
- Responder status: staffed positions, uncovered posts, fatigue and exposure-limit breaches, relief-team deployment status
- Communications: signal-team coverage, any outages, IPAWS delivery success rate, driver feedback on message clarity

**Escalation Path:** Operational decisions stay within the FUCE unless they violate pre-authorized thresholds or conflict with UC orders. Any request for additional Guard personnel, change to the pre-written trigger matrix, or decision to revise public messaging escalates to the UC. Resource requests exceeding available stock (e.g., need for additional N95 from the supplemental reserve at Billings) escalate to the Unified Command Logistics Officer. Responder casualties or critical incidents escalate immediately to the UC and to the responsible state's emergency manager.
### 3. Escalation & Scenario Beta Decision Cell – Specialized Advisory (Volcanology & Triggering Authority)

**Rationale for Inclusion:** The 72-hour window carries a 40% VEI-6+ eruption probability and a pre-authorized VEI-7 trigger matrix that authorizes the UC to order a 500 km radius evacuation immediately without further deliberation. However, the scientific indicators (USGS uplift rate, seismic magnitude, gas flux) that define the trigger must be continuously monitored and interpreted in real time, requiring dedicated expert authority separate from operational command. This cell owns the trigger-matrix refinement, indicator interpretation, and the real-time decision to declare that the threshold has been crossed. The cell's recommendation is binding on the UC unless the UC explicitly overrides it (a rare event, since the matrix is pre-authorized).

**Responsibilities:**

- Refine the USGS trigger-matrix indicator thresholds (uplift rate, seismic magnitude, gas flux, magma-depth models) by T+3 h using pre-event USGS data and the latest volcano-monitoring techniques
- Monitor USGS real-time feeds (seismic networks, GPS, gas sensors) continuously during the 72-hour window and maintain a live status of each indicator relative to the trigger threshold
- Issue a formal Escalation Readiness Assessment every 6 hours during the 72-hour window, stating the current distance from the Scenario Beta trigger and the estimated time to trigger if current trends continue
- Declare the trigger crossed (or not) within 15 min of any indicator crossing the pre-written threshold, with a written statement of which indicator crossed and by how much
- Provide technical guidance to the UC on any ambiguous or marginal trigger events (e.g., an indicator that crosses threshold but then retreats) and recommend whether to order Scenario Beta or hold status
- Coordinate with NOAA on ashfall dispersion forecasts and provide updated wind-direction and ash-extent estimates every 6 hours to support shelter-siting and Scenario Beta planning

**Initial Setup Actions:**

- Convene the Decision Cell at T+0, with USGS and NOAA leads, to review the pre-written trigger matrix and agree on final indicator thresholds by T+3 h
- Establish real-time data feeds from USGS seismic, GPS and gas networks to the cell's monitoring station at the FUCE (Livingston or Bozeman) by T+1 h
- Brief the UC on the refined trigger matrix and the cell's readiness to monitor at T+3 h
- Create a visual status dashboard (displayed at the FUCE) showing current values of each indicator, the trigger threshold, and the distance from the threshold in real time
- Prepare a written decision template and a dissent log so that any trigger-crossing declaration is documented with full traceability and any disagreement among cell members is recorded

**Membership:**

- USGS Volcano Disaster Assistance Program lead (chair, eruption monitoring and indicator interpretation)
- USGS Cascades Volcano Observatory seismologist (seismic swarm interpretation)
- USGS Hawaiian Volcano Observatory modeler (magma ascent and VEI estimation)
- NOAA Forecast lead (ashfall dispersion, wind shifts)
- UC Liaison (FEMA or NPS representative to relay cell decisions to the UC)

**Decision Rights:** The cell's role is scientific interpretation and trigger declaration, not policy or resource decisions. The cell declares whether the pre-written trigger threshold has been crossed. This declaration is binding on the UC (the UC does not second-guess the scientific finding), unless the UC explicitly overrides it on policy grounds (e.g., national-security concerns). The cell does not have authority to modify the trigger matrix after T+3 h; any matrix changes must be approved by the UC. The cell's recommendation on marginal triggers is advisory; the UC makes the final call to order Scenario Beta.

**Decision Mechanism:** Real-time monitoring of USGS feeds and automated alerts when an indicator approaches the threshold (within 20% of the trigger value). When any indicator crosses the threshold, the cell convenes immediately (within 5 min) to verify the data and declare the crossing. If data are ambiguous or disputed among cell members, a simple majority vote determines the declaration (two out of three USGS leads vote); if still disputed, the USGS Disaster Assistance Program lead has final authority. The UC is notified within 15 min of any threshold crossing or declaration.

**Meeting Cadence:** Continuous real-time monitoring during the 72-hour window. Formal briefings to the UC every 6 hours (T+0, T+6, T+12, T+18, T+24, T+30, T+36, T+42, T+48, T+54, T+60, T+66, T+72). Ad hoc calls whenever an indicator crosses 80% of the trigger threshold (a warning). Post-window: joint after-action review with the UC and state emergency managers by Month 2 (2026-12-14).

**Typical Agenda Items:**

- Current status of each USGS indicator: uplift rate (cm/h), seismic magnitude and frequency, gas flux (SO2, CO2), and magma-depth estimates relative to the trigger thresholds
- Ashfall forecast: NOAA 72-hour wind and plume model; projected ash concentration (ug/m3) at each shelter site and Zone One community
- Indicator trends: are current values stable, accelerating, or retreating; estimated time to trigger if acceleration continues
- Any data anomalies or instrument failures affecting indicator reliability; recommendations for data-quality assurance
- Scenario Beta readiness: are the secondary hubs (Denver, Cheyenne) pre-authorized and ready; are bus fleets and rail corridors confirmed

**Escalation Path:** The cell's trigger declaration goes directly to the UC via the UC Liaison and the shared common operating picture. If the cell declares trigger crossing and the UC does not order Scenario Beta within 30 min, the cell has the right to escalate the non-response to the White House Situation Room via the FEMA Regional Administrator. Conversely, if the UC orders Scenario Beta without a cell trigger declaration, this is logged as a policy override and reported in the post-event after-action review.
### 4. Responder Health & Fatigue Management Board – Specialized Advisory (Occupational Safety & Exposure Limits)

**Rationale for Inclusion:** The 72-hour evacuation window requires continuous staffing of traffic-control checkpoints, perimeter gates and backcountry sweeps by rangers, highway patrol and Guard personnel exposed to ashfall, tremor hazards and heat stress. A formal board with authority to enforce exposure limits and manage relief cycles protects responders from entrapment and respiratory injury while maintaining staffing continuity. The board monitors shift logs, triggers relief rotation, and has the power to withdraw responders from ash-exposed posts if limits are breached, directly affecting traffic throughput and evacuation speed. This board is necessary to balance responder safety against the evacuation deadline.

**Responsibilities:**

- Define and enforce responder exposure limits: max 6-hour shifts at ash-exposed posts, mandatory 2-hour rest with N95 replacement, full withdrawal after 18 consecutive hours (proposed thresholds); document all shift assignments and monitor compliance in real time
- Monitor responder health status: track N95 mask inventory and replacement, manage respiratory-exposure symptoms (coughing, shortness of breath) and refer affected personnel for medical evaluation; maintain a confidential responder-health log
- Activate relief rotation and standby reserves: when staffing at any checkpoint falls below 50% (proposed threshold) due to exposure limits or fatigue, trigger deployment of the 30–50 person out-of-region standby reserve within 4 h
- Request additional Guard personnel from Fort Carson, Colorado or other regions if staffing demands exceed available personnel; prepare the request for UC approval if out-of-state Guard cross-deputization is needed
- Conduct fatigue-risk assessments at T+24, T+48 and T+72 h, analyzing cumulative hours worked and recommending mandatory relief or withdrawal of personnel showing signs of critical fatigue
- Coordinate with the three receiving hospitals (Bozeman, Livingston, Idaho Falls) to pre-stage medical support at traffic checkpoints and shelters for responder health emergencies

**Initial Setup Actions:**

- Convene the board at T+0 with representatives from NPS LE, state patrol, Guard and the forward-command Safety Officer to finalize shift schedules and relief protocols
- Count and allocate responder N95 respirators separately from the 100,000 civilian stock; confirm at least 150,000 responder+civilian N95s are available (estimate), with a 50% surge buffer for replacement cycles
- Brief all assigned responders on exposure limits, N95 replacement protocols and mandatory withdrawal thresholds by T+0
- Establish a 24/7 responder-fatigue hotline where personnel can report exposure symptoms, request relief, or raise concerns about unsustainable workloads
- Confirm that the 30–50 person standby reserve is fully briefed, equipped with N95s and generator fuel, and stationed outside the ash zone and ready to deploy within 4 h

**Membership:**

- NPS Chief Ranger or delegated senior safety officer (chair)
- Forward Command Safety Officer
- Montana Highway Patrol Incident Commander or delegated representative
- Wyoming Highway Patrol Incident Commander or delegated representative
- Idaho State Police Incident Commander or delegated representative
- National Guard unit commander (regional or Fort Carson, as deployed)
- Medical officer from the nearest receiving hospital (occupational health and emergency medicine expertise)

**Decision Rights:** The board has binding authority to: (1) approve or modify shift schedules and rest cycles; (2) declare any post as 'understaffed' if coverage falls below 50% due to exposure limits (proposed threshold); (3) trigger activation of the standby reserve for deployment within 4 h; (4) withdraw any individual responder from ash-exposed duty if exposure limits are breached or fatigue risk is critical; (5) recommend to the FUCE that a checkpoint be temporarily closed or consolidated with another if staffing cannot be sustained. The board does not have authority to extend exposure limits beyond the pre-written thresholds (6 h shift, 18 h withdrawal) without UC approval.

**Decision Mechanism:** The board meets every 6 hours during the 72-hour window (at T+0, T+6, T+12, T+18, T+24, T+30, T+36, T+42, T+48, T+54, T+60, T+66, T+72 h) to review shift logs, assess staffing adequacy and approve the next day's schedule. Decisions are made by consensus among the NPS, state and Guard commanders; if consensus fails (e.g., a state patrol commander refuses to remove an exhausted trooper from duty), the NPS Chief Ranger has final authority, with a dissent recorded for the UC. Emergency decisions (e.g., immediate withdrawal of a responder showing acute respiratory distress) are made by the board chair within 5 min and reported to the FUCE.

**Meeting Cadence:** Continuous 24/7 operation during the 72-hour window with formal board meetings every 6 hours (T+0, T+6, T+12 h, etc.). Ad hoc calls when a checkpoint reports staffing below 50% or a responder requests emergency relief. Daily fatigue-risk assessments at T+24, T+48 and T+72 h. Post-event responder health screening and evaluation by Month 2 (2026-12-14).

**Typical Agenda Items:**

- Shift-log review: which responders worked in the past 6 h, duration, location, exposure conditions; any exposure-limit breaches; any symptomatic responders (respiratory symptoms, heat stress, confusion)
- Staffing adequacy: current staffing vs. required staffing at each checkpoint; any posts currently unstaffed or below 50% (proposed threshold)
- Relief rotation: which responders are due for mandatory rest; approval of next 6-hour shift schedule for all posts
- Standby reserve deployment: current readiness status; any activation requests from the FUCE
- N95 inventory and replacement: current stock at each checkpoint; replacement cycles (clogging rate, expected duration per mask); any shortages
- Responder health incidents: any acute symptoms, hospital referrals or medical complications; medical follow-up recommendations

**Escalation Path:** Decisions about responder withdrawal or staffing shortages escalate to the FUCE Operations Section Chief, who adjusts traffic-control post assignments or consolidates posts if necessary. If staffing demands consistently exceed the available responder pool and cannot be met by the standby reserve, the board chair escalates a request for out-of-state Guard to the UC. Critical responder health emergencies (respiratory distress requiring hospitalization, heat-related collapse) are reported immediately to the nearest receiving hospital and to the UC. Any responder casualty during the event is reported to the UC and to the respective state emergency manager within 1 hour.
### 5. Authority & Jurisdictional Coordination Cell – Specialized Advisory (Command Clarity & Multi-State Protocol)

**Rationale for Inclusion:** The evacuation crosses jurisdictional boundaries between NPS (federal land), Montana, Wyoming and Idaho (state highways and communities), and FEMA Regions 8 (Denver) and 10 (Seattle), creating authority gaps and decision latency. The authority transfer is specified in writing (park boundary at each gate; NPS to state handoff), but contraflow traffic does not stop at boundaries, so vehicles and responders cross jurisdictions mid-evacuation without a clear point of responsibility handoff. A dedicated cell, co-located at the forward element with real-time links to each state's on-scene commander, owns the boundary coordination, pre-authorized reroute authority, and resolution of any NPS-state or Region 8/10 disputes. This cell prevents the 15–45 minute delays in reroute decisions that could cascade into a 500–1,000 vehicle backup.

**Responsibilities:**

- Execute the written NPS-to-state authority transfer protocol at each park exit gate (West, North, East Entrance), defining the exact roadside checkpoint where NPS care ends and state custody begins; ensure both sides formally acknowledge the handoff at T+0 and throughout the evacuation
- Authorize state on-scene commanders to issue temporary reroutes without requesting park ranger approval, pre-authorizing them at T+0 with a standing order that reroutes are valid until revoked by the FUCE
- Manage the FEMA Region 8/10 seam: seat an explicit Region 10 liaison at the UC (Denver) by T+0 and maintain a standing mutual-aid agreement with Boise and Pocatello resource centers so that Idaho water and fuel convoys are dispatched without delay
- Resolve any dispute between NPS and a state on-scene commander (e.g., over shelter placement, checkpoint closure or perimeter enforcement) within 30 min by convening both parties on a dedicated conference line with the Boundary Coordination Officer as mediator
- Maintain a shared authority-transfer log (updated hourly) showing which vehicles and responders have crossed from NPS to state control at each gate, and which state now owns care for those evacuees
- Coordinate with the FAA on airspace grounding and medevac exceptions, ensuring the Unified Command has real-time visibility into aviation restrictions and can request emergency exceptions for helicopter transport

**Initial Setup Actions:**

- Brief the designated on-scene commanders for each state (Montana highway patrol at Livingston, Wyoming patrol at Cody, Idaho at Idaho Falls) on the pre-authorized reroute authority and the boundary-handoff protocol at T-6 h (before the evacuation order)
- Establish pre-signed MOUs with Montana, Wyoming and Idaho confirming their acceptance of the UC's authority to issue Zone One and Scenario Beta evacuation orders by Month 1 (2026-11-14)
- Issue written standing orders at T+0 granting state on-scene commanders authority to issue reroutes without seeking park ranger approval, with a dissent-reporting requirement if the commander believes a reroute violates the pre-written matrix
- Activate the Region 10 liaison seat at the Denver RRCC by T+0 and confirm a direct phone line between the liaison and the Boise emergency management office
- Convene a pre-event multi-state coordination exercise 60 days before the window (Month -2) to test boundary handoff, reroute decisions and mutual-aid requests under simulated congestion and ashfall scenarios

**Membership:**

- Boundary Coordination Officer (forward element, chair; FEMA, NPS or Guard officer with authority to speak for the UC)
- NPS Incident Commander or delegated zone incident commander
- Montana Highway Patrol on-scene commander (West Yellowstone and Gardiner exits)
- Wyoming Highway Patrol on-scene commander (Cody and East Entrance exit)
- Idaho State Police liaison (Idaho Falls shelter coordination)
- FEMA Region 10 liaison (seated at Denver UC or on standing conference call)
- FAA representative or liaison (aviation grounding and medevac exceptions)

**Decision Rights:** The cell has binding authority to: (1) authorize state reroutes at any time without UC approval (pre-authorized standing order); (2) resolve NPS-state disputes on the fly within 30 min (Boundary Coordination Officer decision); (3) activate the Region 10 liaison's mutual-aid requests for Idaho resources without waiting for UC approval if request is below USD 5 million (proposed threshold); (4) approve helicopter medevac exceptions within the pre-authorized criteria set by the UC and FAA. The cell may not modify the written authority-transfer protocol after T+0 or unilaterally revoke a pre-authorized reroute; any such changes must escalate to the UC.

**Decision Mechanism:** Standing orders and pre-written authority transfers define the default decision rules, so most situations are handled without deliberation. Real-time problem-solving through a dedicated conference line: if a reroute is needed, the state commander requests it, the Boundary Coordination Officer verifies it against the pre-written matrix and authorizes it within 5 min. If an NPS ranger disputes the reroute, the matter is elevated to the Boundary Coordination Officer and the forward-element Operations Chief within 30 min for quick resolution. Tie-breaker: Boundary Coordination Officer, with escalation to the FUCE Operations Chief if the dispute creates conflicting orders.

**Meeting Cadence:** Continuous operation and real-time coordination during the 72-hour window via a standing conference line connecting all members. Formal briefings to the UC every 6 hours as part of the UC briefing schedule. Post-event: multi-state debrief by Month 2 (2026-12-14) with Montana, Wyoming and Idaho emergency managers to review authority handoff execution and identify improvements for future events.

**Typical Agenda Items:**

- Boundary-crossing status: cumulative vehicle counts crossing from NPS to state control at each gate (West, North, East); any delays or congestion at handoff points
- Active reroutes: which reroutes are currently in effect, which state issued them, any NPS objections or disputes, expected resolution time
- Authority disputes: any NPS-state conflicts over shelter placement, checkpoint staffing, perimeter enforcement or other coordination issues; status of resolution efforts
- Region 10 mutual aid: any pending requests from Idaho emergency managers for water, fuel or medical resources; dispatch status of approved requests
- FAA coordination: any medevac exception requests, current ashfall-related airspace restrictions, anticipated exceptions for emergency helicopter transport

**Escalation Path:** Real-time disputes between NPS and a state are mediated by the Boundary Coordination Officer (on the standing conference line) within 30 min. If the Boundary Coordination Officer and state/NPS commanders cannot reach agreement, the matter escalates to the FUCE Operations Chief, who makes a binding decision and notifies the UC. If a state refuses to comply with a UC-authorized evacuation order, the matter escalates to the UC, which may seek legal counsel and White House involvement. Any FAA denial of a medevac exception request escalates to the UC, which may request White House or Department of Defense intervention.
### 6. Shelter Siting & Air-Quality Assurance Panel – Specialized Advisory (Environmental Monitoring & Dynamic Relocation Authority)

**Rationale for Inclusion:** The plan designates Bozeman and Idaho Falls as reception centers but acknowledges that ashfall forecasts are uncertain by 100+ km, so final shelter locations are selected at T+6 h based on the latest NOAA/USGS plume forecast. Actual ashfall may exceed model predictions by 2–3x, rendering the selected sites unsuitable and requiring emergency relocation of 10,000–15,000 evacuees within 4 h. This specialized panel owns real-time PM10 and ashfall monitoring at all shelter sites, the suitability assessment for shelter relocations, and the authority to order a relocation if thresholds are exceeded. The panel prevents the scenario in which evacuees are sheltered in heavy ash, developing respiratory distress and requiring a chaotic secondary move.

**Responsibilities:**

- Maintain continuous real-time PM10 and ashfall-depth monitoring at the forward element (Livingston or Bozeman) and at all three primary shelter sites, with sensor readings updated at least hourly starting at T-12 h
- At T+6 h, analyze the latest NOAA/USGS plume forecast (wind direction, ashfall extent, ash concentration) and recommend final shelter-site selections from the pre-surveyed candidate list; coordinate with the FUCE Operations Chief to finalize the assignments
- Conduct ongoing suitability assessments at T+12, T+24, T+36, T+48, T+60 and T+72 h: compare current PM10 readings and ashfall forecast to the occupancy and air-filtration capacity of each primary shelter; flag any site exceeding PM10 thresholds (proposed: 50 ug/m3 for forecast update, 100 ug/m3 for suitability review)
- If a primary shelter exceeds PM10 thresholds, initiate a rapid relocation analysis (decision within 30 min): assess ranked backup shelter sites (50+ km upwind) for suitability; prepare a relocation order and transport plan for FUCE approval
- Issue a relocation order (within 4 h of threshold exceedance, proposed threshold) specifying the new shelter site, transport routing, and pickup schedule for the affected evacuees; track relocation logistics and confirm arrival at the new site
- Coordinate with the supplemental N95 reserve hub (Billings or Salt Lake City) to increase N95 distribution to shelters if average daily consumption exceeds 20% of stock (proposed threshold), indicating heavier-than-modeled ashfall

**Initial Setup Actions:**

- Conduct a pre-event air-quality monitoring exercise with NOAA and USGS 30 days before the window, testing real-time sensor deployment, data transmission, forecast-update protocols and relocation-decision latency
- Pre-survey and document 8–10 candidate shelter sites across Montana, Wyoming and Idaho (Bozeman, Livingston, Billings, Idaho Falls, Sun Valley, Missoula, Cheyenne, etc.), with capacity, HVAC and filtration specs for each; rank them by distance from Yellowstone and upwind position relative to forecast wind patterns
- Establish PM10 monitoring equipment at the forward element and at all three primary shelter sites by T-48 h, with backup sensors and battery/generator power; test satellite data transmission to ensure hourly updates are received
- Brief shelter operators and the FUCE Operations Chief on the PM10 thresholds (50 ug/m3 for forecast update, 100 ug/m3 for suitability review) and on the relocation trigger and timeline by T-12 h
- Confirm transport agreements (buses, drivers) for 10,000–15,000 evacuee relocation within 4 h; pre-position the buses at primary shelter sites or within 30 min drive time by T+6 h

**Membership:**

- NOAA Ashfall & Air-Quality Forecast Lead (chair, real-time plume modeling and PM10 prediction)
- USGS Geochemist or volcanologist (ashfall composition and settling-rate estimates)
- EPA air-quality specialist (PM10 sensor calibration and air-quality standards interpretation)
- Forward-Element Planning Chief or designee (FUCE liaison, logistical feasibility assessment for relocation)
- Shelter Operations Coordinator (primary and backup shelter capacity and readiness)

**Decision Rights:** The panel has advisory authority on shelter suitability (recommendation to FUCE) and binding authority to: (1) declare that PM10 thresholds have been exceeded at a shelter site; (2) trigger the start of a relocation analysis; (3) confirm that a ranked backup shelter is suitable for occupancy and relocation can proceed; (4) recommend an increase in N95 distribution from the supplemental reserve. The final relocation order is issued by the FUCE Operations Chief, not the panel, but the panel's threshold declaration is binding and cannot be overridden by the FUCE without UC approval.

**Decision Mechanism:** Automated threshold alerts: when hourly PM10 readings exceed the 50 ug/m3 forecast-update threshold, an alert is triggered and the panel convenes to update the plume forecast and assess suitability. When PM10 exceeds the 100 ug/m3 suitability-review threshold (proposed), a rapid relocation analysis is triggered. The panel (NOAA, USGS and EPA members) votes on whether the current site is still safe for occupancy; a 2-out-of-3 vote determines the recommendation. The FUCE Operations Chief then decides within 1 h whether to order relocation. If the FUCE Operations Chief overrides a panel suitability finding, this override is escalated to the UC.

**Meeting Cadence:** Continuous real-time monitoring with automated alerts when thresholds are approached. Formal briefings to the FUCE Operations Chief every 6 hours (at the standard FUCE briefing times: T+0, T+6, T+12, T+18, T+24, etc.). Ad hoc emergency meetings when PM10 exceeds the forecast-update threshold (50 ug/m3 proposed). Post-event: joint evaluation with USGS, NOAA and EPA by Month 2 (2026-12-14) to assess forecast accuracy and identify sensor improvements.

**Typical Agenda Items:**

- Hourly PM10 and ashfall-depth readings at all shelter sites and the forward element; comparison to modeled expectations
- NOAA 72-hour plume forecast update: wind direction, ashfall extent, estimated PM10 concentrations at candidate shelter sites
- Suitability assessment: is each primary shelter still suitable for occupancy given current and forecast ashfall; any backup sites requiring activation
- Relocation logistics: if relocation is triggered, which backup site is recommended; transport plan and ETA for evacuee pickup and arrival
- N95 consumption and reserve status: actual daily consumption vs. modeled expectation; any triggers for supplemental-reserve activation

**Escalation Path:** Suitability assessments and PM10 threshold declarations go directly to the FUCE Operations Chief, who has 1 h to decide on relocation. If the FUCE Operations Chief does not order relocation within 1 h of a panel finding that PM10 exceeds the 100 ug/m3 threshold (proposed), the panel has the right to escalate the non-response to the UC. Disputes among panel members (e.g., NOAA and USGS disagree on the forecast) are resolved by majority vote; if 2-out-of-3 cannot agree, the matter escalates to the UC with both positions documented. Critical relocation logistics failures (buses unavailable, transport gridlock) escalate to the FUCE Logistics Chief and then to the UC.

# Governance Implementation Plan

### 1. Project Sponsor (FEMA Regional Administrator, Region VIII) and NPS Director jointly issue a written decision memo designating the Yellowstone Caldera eruption response as a 'pre-event emergency planning initiative' and authorizing the formation of a Unified Command structure. The memo names the FEMA Region VIII IC as the Unified Command chair and directs all agencies to cooperate on governance setup by Month 0 (2026-10-14). This memo serves as the legal authority to form all downstream governance bodies.

**Responsible Body/Role:** FEMA Regional Administrator (Region VIII) and NPS Director (joint decision authority)

**Suggested Timeframe:** Month -1

**Key Outputs/Deliverables:**

- Signed decision memo authorizing Unified Command formation and inter-agency cooperation
- Named chair of the Unified Command (FEMA Region VIII IC)
- Distribution list of required attendees and their home agencies

**Dependencies:**

- Yellowstone eruption scenario and 72-hour window identified by USGS
- Strategic decision on command structure (Unified Command at Denver RRCC with forward element at Livingston/Bozeman) approved by FEMA and NPS
- Initial internal governance bodies list provided (4-6 bodies defined in prior phase)

### 2. FEMA Region VIII Incident Commander (designated UC Chair) or designee drafts a written Terms of Reference (ToR) for the Unified Command, defining its strategic authority, decision rights (zone expansion, escalation triggers, resource allocation >USD 10M), meeting cadence (continuous during 72-hour window, hourly briefings at T+0/2/6/12/24/36/48/60/72h), membership (FEMA Region VIII IC, Region 10 liaison, NPS IC, three state emergency managers/governors' designees, USGS volcanologist, NOAA forecast lead) and escalation path (tie-breaker: FEMA Region VIII IC; constitutional/legal disputes to U.S. Attorney and White House). The draft establishes the UC as a standing body that activates at T+0 and operates continuously through T+72h.

**Responsible Body/Role:** FEMA Region VIII Incident Commander (future UC Chair) with input from NPS, state emergency management offices and FEMA Region 10

**Suggested Timeframe:** Month -1, Week 2

**Key Outputs/Deliverables:**

- Draft Unified Command Terms of Reference v0.1 (15-20 pages)
- Defined strategic decision rights and escalation paths
- Preliminary membership list with agency confirmations

**Dependencies:**

- Decision memo from FEMA RA and NPS Director issued
- Strategic choices finalized (UC at Denver with forward element at Livingston/Bozeman)
- FEMA Region 10 (Seattle) director identified and notified of expected liaison role

### 3. FEMA Region VIII Incident Commander circulates the draft UC Terms of Reference to all nominated members (NPS Director, three state emergency managers, FEMA Region 10 liaison, USGS and NOAA leads) for review and feedback. A 1-week review window is provided. Feedback is consolidated into a summary document and shared back to all reviewers, along with a revision tracker.

**Responsible Body/Role:** FEMA Region VIII Incident Commander (document circulation and feedback consolidation)

**Suggested Timeframe:** Month -1, Week 3

**Key Outputs/Deliverables:**

- UC ToR v0.1 distributed to 9-12 stakeholders via email and secure portal
- Individual feedback submissions from each reviewer (consolidated into a Feedback Summary)
- Revision tracker showing which comments have been incorporated

**Dependencies:**

- Draft UC ToR v0.1 completed
- Contact list of all nominated members with email addresses and office secure-portal access confirmed

### 4. FEMA Region VIII Incident Commander revises the UC ToR based on consolidated feedback and issues UC ToR v1.0 (final). Key revisions may include: (1) clarification of Region 10 liaison's voting rights on Idaho-specific decisions; (2) formalizing the 'veto override' protocol (each state governor has one veto; majority rule after override used); (3) defining the shared common operating picture (COP) digital dashboard and update frequency (hourly). The final ToR is signed by the FEMA Region VIII IC and submitted to the FEMA Regional Administrator for official approval.

**Responsible Body/Role:** FEMA Region VIII Incident Commander with final sign-off from FEMA Regional Administrator

**Suggested Timeframe:** Month -1, Week 4

**Key Outputs/Deliverables:**

- Unified Command Terms of Reference v1.0 (final, signed)
- FEMA Regional Administrator approval letter
- Decision log documenting which feedback was incorporated and why

**Dependencies:**

- UC ToR v0.1 and consolidated Feedback Summary completed
- Revisions approved by FEMA Region VIII IC

### 5. FEMA Region VIII Incident Commander issues formal written appointment letters to each nominated member of the Unified Command, confirming their role, decision rights and the time commitment (continuous operation from T+0 to T+72h, then ongoing Months 1-3 = 2026-11-14 to 2027-01-14 for MOUs and exercises). Letters are sent to the home agencies (NPS, three states, FEMA Region 10, USGS, NOAA) with a request for verbal confirmation of acceptance within 48 hours. Any rejections or substitute nominees are flagged for resolution by the FEMA Regional Administrator.

**Responsible Body/Role:** FEMA Region VIII Incident Commander (letter issuance)

**Suggested Timeframe:** Month 0 (2026-10-14), Week 1 (Days -7 to 0 before T+0 on 2026-10-14)

**Key Outputs/Deliverables:**

- Formal appointment letters to 9-12 UC members (signed by FEMA Region VIII IC)
- Confirmation of acceptance from each member's home agency (email or memo)
- Roster of confirmed UC membership with titles and contact information

**Dependencies:**

- UC ToR v1.0 final and approved
- Contact information for all nominated members and their supervisors

### 6. FEMA Region VIII Incident Commander or designee holds a pre-event UC 'Orientation and Authority Briefing' meeting (in-person or virtual hybrid) for all confirmed UC members. The briefing covers: (1) the pre-authorized USGS trigger matrix for Scenario Beta (VEI-7 indicators, thresholds to be finalized by T+3h); (2) the three-exit contraflow plan and the 45-minute blockage-diversion rule (proposed threshold); (3) the Authority & Jurisdictional Cell's role in the NPS-to-state handoff; (4) the COP digital dashboard demo and how to access it; (5) the continuous briefing schedule (T+0, T+2, T+6, T+12, T+24, etc.). A Q&A session addresses any ambiguities in decision rights or escalation paths. All attendees sign an acknowledgment of understanding.

**Responsible Body/Role:** FEMA Region VIII Incident Commander (host and facilitator) with support from NPS IC and state emergency managers

**Suggested Timeframe:** Month 0 (2026-10-14), Week 2 (Days -7 to -1 before T+0)

**Key Outputs/Deliverables:**

- UC Orientation briefing agenda and slides
- Pre-authorized USGS trigger-matrix summary (preliminary; final thresholds by T+3h)
- COP dashboard access credentials for all UC members
- Signed attendance roster and acknowledgment-of-understanding forms

**Dependencies:**

- UC ToR v1.0 final and all members confirmed
- USGS preliminary trigger-matrix indicators (uplift rate, seismic magnitude, magma depth) identified
- COP digital platform and dashboard deployed and tested

### 7. FEMA Region VIII Incident Commander formally activates the Unified Command at T+0 (2026-10-14, coinciding with the eruption alert and evacuation order from the project sponsor). All UC members report to their designated seats at the FEMA Region VIII RRCC in Denver (remote participation accepted for state emergency managers if in-person travel is not feasible). The UC chair convenes the first formal briefing, reviews the COP dashboard status (expected: ~0 evacuees out at T+0, all exit corridors open, ashfall not yet detected), and confirms that all five specialized advisory bodies (Escalation Cell, FUCE, Responder Health Board, Authority Cell, Shelter Siting Panel) are standing by and ready to accept delegated authority from the UC.

**Responsible Body/Role:** Unified Command (led by FEMA Region VIII IC)

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 0 (2026-10-14, T+0)

**Key Outputs/Deliverables:**

- UC formally activated memo (signed by FEMA Region VIII IC)
- First UC briefing held; meeting minutes documenting status of evacuation corridors, supply convoys, responder deployment, and advisory-body readiness
- COP dashboard populated with baseline data (evacuation gates open, no blockages, no ashfall yet, all exit corridors confirmed passable)

**Dependencies:**

- Evacuation order issued by project sponsor (NPS and FEMA)
- All UC members confirmed ready and in position at T+0
- FUCE, Escalation Cell and advisory bodies staffed and standing by

### 8. Forward Unified Command Element (FUCE) senior staff (Operations Chief, Logistics Chief, Planning Chief, Safety Officer, Boundary Coordination Officer, Guard Signal Officer and USGS/NOAA liaisons) meet at the forward command element location (Livingston, MT, or alternate Bozeman) by T+1 hour to formally establish the FUCE as an operational entity under the UC. The Operations Chief briefs the team on the delegated authority (traffic management, tow dispatch, water convoy routing, shelter relocation triggers within pre-authorized rules) and confirms that communication links to the UC in Denver are live and tested. All FUCE members acknowledge their roles and confirm readiness to execute continuous operations until T+72h.

**Responsible Body/Role:** FUCE Operations Section Chief (incident commander for forward operations)

**Suggested Timeframe:** Month 0 (2026-10-14), Hours 0–1 (T+0 to T+1)

**Key Outputs/Deliverables:**

- FUCE formally established at Livingston (or Bozeman) location
- FUCE organization chart and role assignments (Operations, Logistics, Planning, Safety, Boundary Coordination, Signal, liaisons)
- Communication test between FUCE and UC Denver (voice, data, COP dashboard access confirmed)
- FUCE initial briefing minutes documenting status of control points, tow teams, water convoy readiness

**Dependencies:**

- UC formally activated
- Livingston command facility (or Bozeman backup) prepared with communications equipment, desks, COP displays and generator backup
- All FUCE section chiefs confirmed in position

### 9. Escalation & Scenario Beta Decision Cell (USGS Volcano Disaster Assistance Program lead, USGS seismologist, USGS magma modeler, NOAA forecast lead, and UC liaison) convene at T+0 at either the FUCE location (Livingston) or the UC location (Denver RRCC), as coordinated. The cell chair (USGS Disaster Assistance Program lead) reviews the pre-authorized USGS trigger matrix (preliminary, to be finalized by T+3h using real-time USGS data) and establishes live monitoring of USGS seismic, GPS and gas networks. The cell confirms that data feeds are arriving in real time and that automated threshold alerts are armed. The cell also briefs the UC liaison on the status of each eruption indicator relative to the Scenario Beta trigger threshold.

**Responsible Body/Role:** Escalation & Scenario Beta Decision Cell (led by USGS Volcano Disaster Assistance Program lead)

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 0 (T+0)

**Key Outputs/Deliverables:**

- Escalation Cell formally established and operational
- Live USGS data feeds (seismic, GPS, gas) confirmed arriving at monitoring station (FUCE or UC)
- Preliminary trigger-matrix thresholds defined (uplift rate, seismic magnitude, magma depth); final thresholds to be confirmed by T+3h
- Automated threshold-alert system armed; decision log created for documenting indicator values hourly
- Initial briefing to UC: current status of each indicator relative to the Scenario Beta trigger

**Dependencies:**

- UC formally activated
- USGS real-time monitoring network operational (seismic, GPS, gas)
- Live data-feed connections to the FUCE or UC command center confirmed

### 10. Responder Health & Fatigue Management Board (NPS Chief Ranger, Forward Command Safety Officer, state highway patrol commanders for MT/WY/ID, National Guard unit commander, and medical officer from the nearest receiving hospital) convene at T+0 at the FUCE or a nearby regional coordination center. The board chair (NPS Chief Ranger) reviews the pre-written exposure limits (6-hour shifts at ash-exposed posts, 2-hour rest with N95 replacement, 18-hour withdrawal threshold) and confirms that all assigned responders have been briefed on these limits and on the fatigue-hotline contact information. The board also confirms that the 30–50 person standby reserve is stationed outside the ash zone and ready to deploy within 4 hours if staffing falls below 50% at any checkpoint.

**Responsible Body/Role:** Responder Health & Fatigue Management Board (led by NPS Chief Ranger)

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 0 (T+0)

**Key Outputs/Deliverables:**

- Responder Health Board formally established and operational
- Exposure limits briefing memo issued to all assigned responders (rangers, patrol officers, Guard)
- Responder N95 inventory confirmed (counted separately from 100,000 civilian stock); total estimated 150,000–200,000 with 50% surge buffer
- Fatigue-hotline contact information distributed to all responders
- Standby reserve roster confirmed (30–50 personnel stationed outside ash zone, ready to deploy)
- Initial board briefing minutes documenting responder deployment status and shift assignments for the first 6 hours

**Dependencies:**

- FUCE formally established
- All responder positions (rangers, patrol, Guard) assigned and confirmed
- Standby reserve personnel identified, briefed and pre-positioned outside the ash zone

### 11. Authority & Jurisdictional Coordination Cell (Boundary Coordination Officer at the FUCE, NPS IC or delegated zone commander, MT/WY/ID highway patrol and state police on-scene commanders, FEMA Region 10 liaison, and FAA representative) convene at T+0 to formally establish the cell and activate the authority-transfer protocols. The Boundary Coordination Officer briefs all members on the pre-written NPS-to-state handoff protocol at each park exit gate (West, North, East Entrance), confirming that state on-scene commanders have been pre-authorized to issue reroutes without park ranger approval (standing order, pre-signed by the UC chair). The Region 10 liaison confirms that FEMA Region 10 mutual-aid arrangements with Boise and Pocatello emergency management offices are documented in a standing MOU to be finalized by Month 1 (2026-11-14).

**Responsible Body/Role:** Authority & Jurisdictional Coordination Cell (led by Boundary Coordination Officer at FUCE)

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 0 (T+0)

**Key Outputs/Deliverables:**

- Authority Cell formally established and operational at FUCE
- NPS-to-state authority-transfer protocol memo re-issued to all members (West, North, East Entrance gates; roadside checkpoints defined)
- Standing order authorizing state on-scene reroutes without park approval (signed by UC chair, signed by each state emergency manager)
- Authority-transfer log template created (hourly updates tracking vehicle and responder crossings at each gate)
- Region 10 liaison confirmed in position at Denver UC; preliminary mutual-aid contacts from Boise and Pocatello confirmed
- FAA liaison confirmed in position; aviation-grounding procedure and medevac-exception criteria reviewed

**Dependencies:**

- UC formally activated
- FUCE established with Boundary Coordination Officer in position
- Written NPS-to-state handoff protocol drafted and pre-reviewed by all states
- Region 10 liaison identified and contact information confirmed

### 12. Shelter Siting & Air-Quality Assurance Panel (NOAA ashfall/air-quality forecast lead, USGS geochemist, EPA air-quality specialist, FUCE Planning Chief, and Shelter Operations Coordinator) convene at T+0 at the FUCE location. The panel chair (NOAA lead) confirms that real-time PM10 and ashfall-depth monitoring sensors are deployed at the forward element (Livingston) and at the three primary shelter candidates (Bozeman, Idaho Falls, and a third site to be determined based on the T+6 forecast). The panel reviews the pre-surveyed list of 8–10 backup candidate shelters (ranked by distance and upwind position) and confirms that transport agreements (buses, drivers) are in place for emergency relocation of 10,000–15,000 evacuees within 4 hours.

**Responsible Body/Role:** Shelter Siting & Air-Quality Assurance Panel (led by NOAA ashfall/air-quality forecast lead)

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 0 (T+0)

**Key Outputs/Deliverables:**

- Shelter Siting Panel formally established and operational at FUCE
- Real-time PM10 and ashfall-depth monitoring confirmed at forward element and all primary shelter sites; automated alerts armed (thresholds: 50 ug/m³ forecast-update trigger, 100 ug/m³ suitability-review trigger)
- Pre-surveyed backup shelter sites list (8–10 candidates) with capacity, HVAC and filtration specs for each
- Transport agreements for rapid relocation (buses, drivers confirmed) within 4 hours of relocation order
- Initial briefing to UC: current ashfall forecast and modeled ash extent for the 72-hour window

**Dependencies:**

- FUCE formally established
- PM10 monitoring sensors deployed and tested at forward element and shelter sites
- NOAA plume model and forecast data feeding into real-time dashboard
- Backup shelter sites pre-surveyed by Month -1

### 13. UC holds the formal first Unified Command briefing at T+0, with participation by all six UC members (or their confirmed delegates) and representatives from all five specialized advisory bodies (Escalation Cell, FUCE, Responder Health Board, Authority Cell, Shelter Siting Panel). The agenda includes: (1) status of evacuation corridors and gate operations (target 0 departures at T+0, ramping to flow rate of ~2,000 vehicles/hour by T+1); (2) summary of USGS eruption indicators and distance from the Scenario Beta trigger (provided by Escalation Cell); (3) current ashfall forecast and PM10 readings (provided by Shelter Siting Panel); (4) readiness status of water convoys (target dispatch from Salt Lake City by T+12h) and supply logistics (provided by FUCE Logistics Chief); (5) responder staffing and exposure-limit compliance (provided by Responder Health Board); (6) authority-transfer protocols and any initial boundary-coordination issues (provided by Authority Cell). A shared common operating picture (COP) digital dashboard is displayed and updated continuously during the briefing, showing all metrics hourly.

**Responsible Body/Role:** Unified Command (led by FEMA Region VIII IC, chair)

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 0–2 (T+0 to T+2)

**Key Outputs/Deliverables:**

- UC First Briefing agenda and slide deck
- Briefing minutes documenting: evacuation gate status, USGS indicator status, ashfall forecast, supply convoy readiness, responder deployment, and authority-transfer protocol execution
- COP digital dashboard snapshot (baseline T+0 data)
- UC decision log initiated (documenting any real-time decisions, tie-breakers or escalations)
- Attendee roster (UC members and advisors confirmed present or remote)

**Dependencies:**

- UC formally activated
- All five specialized advisory bodies established and operational
- COP digital dashboard live and populated with baseline data
- USGS, NOAA, FUCE, Responder Health Board and Authority Cell ready to brief

### 14. USGS Volcano Disaster Assistance Program lead (Escalation Cell chair) completes the refinement of the pre-authorized USGS trigger matrix using the latest real-time eruption-monitoring data (seismic swarm, GPS uplift, gas emissions, magma-depth models) available at T+3h. The cell finalizes the specific numerical thresholds for: (1) uplift rate (cm/h or cm/6h intervals); (2) seismic-swarm magnitude and frequency triggers; (3) gas-flux thresholds (SO2, CO2); (4) estimated magma depth and ascent rate indicating VEI-7 probability ≥20% in the remaining window (placeholder; USGS to provide exact formula). The finalized matrix is issued in writing and distributed to the UC, FUCE, and all state emergency managers. A dashboard showing the current status of each indicator relative to the finalized trigger thresholds is published and made available to the media and the public to ensure credibility and transparency.

**Responsible Body/Role:** Escalation & Scenario Beta Decision Cell (led by USGS Volcano Disaster Assistance Program lead)

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 3 (T+3h)

**Key Outputs/Deliverables:**

- Finalized USGS trigger-matrix document (signed by USGS Disaster Assistance Program lead)
- Specific numerical thresholds for uplift rate, seismic magnitude, gas flux and magma-depth estimates
- Decision-dashboard snapshot showing current indicator values relative to finalized thresholds
- Trigger-matrix distribution memo to UC, FUCE, states and media
- Public-facing summary of the trigger matrix explaining how Scenario Beta escalation works

**Dependencies:**

- Escalation Cell established at T+0
- Real-time USGS data feeds live and streaming continuously
- Preliminary matrix indicators identified at T+0

### 15. FUCE Operations Chief and FEMA logistics coordinator confirm that contraflow traffic-control operations are active on all three exit corridors (US-20/US-191 via Gallatin Canyon to West Yellowstone, US-89 via Gardiner, US-14/16/20 toward Cody) by T+1 hour. Traffic-control posts are staffed at each corridor (rangers, highway patrol, and National Guard at key junctions and bottlenecks). At least two tow and rockfall-clearance teams are deployed to pre-positioned stations (Mammoth and Spanish Creek area) and confirmed ready to reach any Gallatin Canyon blockage within 15 minutes of dispatch. Guard signal teams with satellite phones, portable repeaters and generator fuel are deployed to each control point and the forward element by T+1 hour. IPAWS (Integrated Public Alert and Warning System) messages in English and five languages (Spanish, Japanese, German, Mandarin, French) are issued to the public, instructing drivers to use designated exit corridors and to follow ranger/patrol instructions.

**Responsible Body/Role:** FUCE Operations Section Chief and Logistics Chief

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 1 (T+1h)

**Key Outputs/Deliverables:**

- Confirmation that contraflow is active on all three corridors (signed statement from each state DOT or National Guard unit)
- Traffic-control post staffing roster (rangers, patrol, Guard) for each corridor and checkpoint
- Tow and rockfall-clearance team deployment confirmation (2+ teams at Mammoth/Spanish Creek area, ready for 15-minute response)
- Guard signal-team deployment confirmation at all control points and forward element
- IPAWS message distribution log (English and five languages; timestamp of broadcast and carrier confirmation)

**Dependencies:**

- UC formally activated and evacuation order issued by project sponsor
- FUCE Operations Chief in position at Livingston
- Tow teams and Guard signal teams pre-positioned or nearby and ready to deploy

### 16. Shelter Siting Panel conducts the formal selection of final shelter sites at T+6 hours, using the latest NOAA/USGS plume forecast and real-time PM10 monitoring data. The panel reviews the ashfall-extent forecast, wind direction and ash-concentration projections for the next 72 hours. Based on this forecast, the panel recommends primary and backup shelter sites that lie outside or upwind of the modeled ash footprint. The FUCE Operations Chief formally approves the shelter-site selections and issues assignments to the Bozeman and Idaho Falls shelters (or alternates if the forecast indicates those sites are unsuitable). Buses and intake staff are dispatched to the selected sites to prepare for receiving the first evacuees (expected arrival T+6 to T+12h).

**Responsible Body/Role:** Shelter Siting & Air-Quality Assurance Panel (led by NOAA forecast lead) with final approval by FUCE Operations Chief

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 6 (T+6h)

**Key Outputs/Deliverables:**

- Final shelter-site selection recommendation from the Shelter Siting Panel (with ashfall-forecast justification)
- PM10 and ashfall-depth readings at all candidate sites at T+6h
- FUCE approval memo for final shelter assignments
- Shelter intake and operations teams dispatched and confirmation of arrival at selected sites
- Briefing to UC documenting the shelter-siting decision and any deviations from the pre-planned Bozeman/Idaho Falls locations

**Dependencies:**

- Shelter Siting Panel established and monitoring active at T+0
- Real-time PM10 sensors at all candidate sites
- NOAA plume forecast updated at T+6h

### 17. UC issues a milestone assessment at T+6 hours, checking against the Phase 1 'go/no-go' gate: at least 98% of the 35,800 Zone Zero evacuees (about 35,084) have been counted as having exited through the three corridors (West, North, East gates). Real-time exit counts from each state patrol and NPS checkpoint are consolidated in the COP dashboard. If the gate is met, the UC documents clearance and advises that Zone Zero is essentially cleared, with remaining stragglers (estimated 200–400 backcountry hikers and permit holders) under active ranger sweep and accounting. If the gate is not met (e.g., due to a blockage that delayed departures), the UC convenes an emergency reroute decision with the FUCE and Authority Cell to redirect any remaining vehicles and assess whether the 72-hour window timeline needs adjustment.

**Responsible Body/Role:** Unified Command (led by FEMA Region VIII IC) with real-time data from FUCE and state checkpoints

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 6 (T+6h)

**Key Outputs/Deliverables:**

- Phase 1 Gate G1 assessment document (yes/no decision: at least 98% of 35,800 confirmed out)
- Cumulative exit counts by corridor (West, North, East) at T+6h
- List of any remaining unaccounted-for parties (backcountry, lodges, permit holders); status of ranger sweeps
- UC briefing documenting gate results and any reroute or staffing adjustments triggered by shortfalls
- COP dashboard snapshot at T+6h showing gate status, ashfall conditions and shelter readiness

**Dependencies:**

- Contraflow operations active on all three corridors from T+0 to T+6
- Real-time exit counting and reporting from state checkpoints and NPS
- FUCE and Authority Cell coordinating reroutes and gate-status reporting

### 18. UC issues a formal public statement and IPAWS alert at T+6 hours, confirming that Zone Zero (park interior) has been cleared or is nearly cleared, and that the evacuation is transitioning to Phase 2: expansion of Zone One (100 km radius including West Yellowstone, Gardiner and Cody communities). The statement reiterates the pre-authorized USGS trigger matrix and explains that if the triggers for Scenario Beta (VEI-7) are detected, a 500 km evacuation order will be issued immediately without further deliberation. The statement also confirms current shelter locations (Bozeman, Idaho Falls and any third site), water convoy dispatch status (target T+12h from Salt Lake City), and the N95 pre-staging locations. This public statement is critical for sustaining public trust and explaining the escalation logic before Scenario Beta messaging may become necessary.

**Responsible Body/Role:** Unified Command (FEMA Region VIII IC) in coordination with NOAA Public Affairs and NPS Communications

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 6 (T+6h)

**Key Outputs/Deliverables:**

- UC public statement confirming Phase 1 clearance and Zone One expansion (signed by FEMA Region VIII IC)
- IPAWS alert in English and five languages explaining Scenario Beta trigger logic and shelter locations
- Media briefing slides and talking points for state and federal public affairs
- Confirmation of broadcast on local radio, TV and social-media channels

**Dependencies:**

- Phase 1 Gate G1 assessment complete
- Shelter siting decisions finalized
- USGS trigger matrix finalized and published

### 19. FEMA Region VIII IC (UC chair) or designee issues written pre-authorization letters to each of the three state governors (Montana, Wyoming, Idaho), requesting verbal confirmation of their authorization of the UC's Zone One and Scenario Beta (500 km) evacuation orders. The letters explain: (1) the current status of the evacuation (Phase 1 complete, Zone One now being evacuated); (2) the pre-written USGS trigger matrix and how Scenario Beta will be triggered if thresholds are crossed; (3) the request for each governor to confirm that they accept the UC's authority to issue and enforce these orders on state highways and in state communities; (4) the expectation that formal Memoranda of Understanding (MOUs) and EMAC mutual-aid agreements will be signed by Month 1 (2026-11-14). Verbal confirmations are recorded and documented in the UC decision log.

**Responsible Body/Role:** FEMA Region VIII IC (UC chair) on behalf of the Unified Command

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 6 (T+6h)

**Key Outputs/Deliverables:**

- Pre-authorization letters issued to MT, WY and ID governors (transmitted via secure fax and secure email)
- Verbal confirmations recorded and transcribed (audio or written summary)
- UC decision-log entries documenting each governor's confirmation (or any objections/conditions)
- Schedule confirmed for signing formal MOUs by Month 1 (2026-11-14)

**Dependencies:**

- Zone One evacuation order issued by project sponsor (NPS and FEMA)
- Phase 1 Gate G1 assessment complete
- USGS trigger matrix finalized

### 20. FUCE Logistics Chief confirms that bottled-water convoys from Salt Lake City distribution centers have been dispatched by T+12 hours (per the T+12h target), using National Guard escorts and reserved lanes on I-15 northbound (proposed dedicated 'supply-surge' lane). The Logistics Chief tracks the real-time location of each convoy via GPS and reports arrival estimates at Bozeman and Idaho Falls shelters. If the forecast arrival time exceeds T+24h (the Phase 2 gate deadline), the Logistics Chief alerts the FUCE Operations Chief and the UC, triggering contingency actions: (1) advance dispatch of supplemental water from forward depots in Bozeman, Billings and Idaho Falls (pre-positioned at T-48 hours before the event); (2) activation of the supplemental N95 reserve at Billings or Salt Lake City if ashfall is heavier than modeled.

**Responsible Body/Role:** FUCE Logistics Section Chief

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 12 (T+12h)

**Key Outputs/Deliverables:**

- Water-convoy dispatch confirmation from Salt Lake City (signed order, timestamp, carrier confirmation)
- Convoy tracking (GPS coordinates, real-time location updates, ETA at Bozeman and Idaho Falls)
- Contingency activation decision (if ETA >T+24h): order for forward-depot supplemental water and supplemental N95 deployment
- Briefing to FUCE and UC documenting water-supply status and any logistics adjustments

**Dependencies:**

- FUCE Logistics Chief in position
- Water-supply contracts with pre-authorized 12-hour dispatch clauses in place (signed before Month 0 = 2026-10-14)
- Forward depots at Bozeman, Billings and Idaho Falls pre-stocked with water and N95 by T-48h

### 21. Authority Cell conducts a formal review of authority-transfer and jurisdictional-coordination execution at T+12 hours. The Boundary Coordination Officer consolidates reports from all three state on-scene commanders (MT at West/Gardiner, WY at Cody, ID at Idaho Falls) documenting: (1) cumulative vehicle and evacuee counts that have crossed from NPS to state control at each boundary checkpoint; (2) any reroutes or traffic-control adjustments issued by state commanders (all within pre-authorized standing orders); (3) any disputes or coordination gaps that required escalation to the FUCE or UC. The cell issues a brief status report to the UC confirming that the authority transfer is executing smoothly or flagging any issues requiring UC decision-making.

**Responsible Body/Role:** Authority & Jurisdictional Coordination Cell (led by Boundary Coordination Officer)

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 12 (T+12h)

**Key Outputs/Deliverables:**

- Authority-transfer execution report from Boundary Coordination Officer
- Cumulative authority-transfer log (vehicles and responders crossing from NPS to state control at each gate)
- Summary of reroutes issued by state on-scene commanders (all within standing authorization)
- Any disputes or escalations identified and the resolution
- Briefing to FUCE and UC documenting jurisdictional-coordination status

**Dependencies:**

- Authority Cell established at T+0
- Standing orders authorizing state reroutes issued at T+0
- State on-scene commanders in position at their respective gates and checkpoints

### 22. Responder Health Board conducts a mandatory 6-hour fatigue-risk assessment at T+12 hours, analyzing cumulative hours worked by all assigned responders (rangers, patrol, Guard at traffic-control and perimeter posts) since T+0. The board reviews shift logs and identifies any responders approaching or exceeding the 18-hour withdrawal threshold (proposed threshold). Any responders exceeding 6 hours at ash-exposed posts without a 2-hour rest break are flagged for immediate rotation. The board also tallies N95 mask usage and confirms that inventory is adequate for the next 12 hours. If usage is exceeding expectations (e.g., heavy ashfall causing faster mask clogging), the board signals the FUCE Logistics Chief to activate supplemental responder N95 reserves.

**Responsible Body/Role:** Responder Health & Fatigue Management Board (led by NPS Chief Ranger)

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 12 (T+12h)

**Key Outputs/Deliverables:**

- Responder fatigue-risk assessment report documenting cumulative hours worked by all deployed responders
- List of responders exceeding exposure limits or requiring immediate rotation
- N95 inventory and consumption summary (actual vs. modeled expected usage)
- Contingency activation decision (if usage exceeding expectations)
- Briefing to FUCE and UC with staffing-continuity recommendations

**Dependencies:**

- Responder Health Board established at T+0
- Shift logs maintained at all traffic-control posts and forwarded to the board every 2 hours
- N95 inventory tracked in real time at each post

### 23. Escalation Cell issues an Escalation Readiness Assessment at T+12 hours, reporting the current status of each USGS eruption indicator (uplift rate, seismic magnitude, gas flux, magma depth) relative to the finalized Scenario Beta trigger thresholds. The cell states how far (percentage or margin) each indicator is from the trigger and estimates the time to trigger if current trends continue. The cell also reviews the current ashfall forecast and PM10 readings, noting any changes from the T+6h forecast. This briefing is delivered to the UC and published in a summary format suitable for media and public consumption, maintaining transparency about the eruption state and the likelihood of Scenario Beta escalation.

**Responsible Body/Role:** Escalation & Scenario Beta Decision Cell (led by USGS Volcano Disaster Assistance Program lead)

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 12 (T+12h)

**Key Outputs/Deliverables:**

- Escalation Readiness Assessment document (1-2 pages, signed by USGS lead)
- Current indicator-status dashboard (snapshot of each indicator relative to finalized thresholds)
- Estimated time-to-trigger calculation if current trends continue
- Updated ashfall forecast and PM10 readings
- Public-facing summary explaining the escalation status in non-technical language

**Dependencies:**

- Escalation Cell established at T+0
- USGS trigger matrix finalized by T+3h
- Real-time USGS monitoring data streaming continuously

### 24. UC holds the T+12 hour formal briefing, consolidating status reports from the FUCE, all five specialized advisory bodies, and state on-scene commanders. The agenda includes: (1) Zone One evacuation progress (target: evacuees flowing into Bozeman, Idaho Falls and third shelter site; intake and registration ongoing); (2) USGS indicator status and Scenario Beta readiness; (3) ashfall forecast and shelter-suitability status (PM10 readings, any triggers for relocation analysis); (4) water convoy ETA and supply-logistics status; (5) responder fatigue and staffing continuity; (6) authority-transfer execution and any jurisdictional disputes. The UC documents any mid-course corrections needed (e.g., reroutes, shelter relocation preparations, additional Guard deployment) and issues updated orders to the FUCE and state commanders.

**Responsible Body/Role:** Unified Command (led by FEMA Region VIII IC, chair)

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 12 (T+12h)

**Key Outputs/Deliverables:**

- UC T+12h Briefing agenda and briefing minutes
- Status summaries from FUCE, advisory bodies and states (consolidated into one briefing package)
- COP dashboard snapshot at T+12h
- UC decision log documenting any mid-course orders or escalations
- Updated UC daily orders (if needed) to FUCE and state commanders

**Dependencies:**

- FUCE status report prepared and submitted on time
- All five advisory bodies prepared to brief at T+12h

### 25. FEMA Region VIII IC (UC chair), on behalf of the Unified Command, issues a written request to the three state governors (MT, WY, ID) and to FEMA Region 10 (Seattle) requesting formal signing of Memoranda of Understanding (MOUs) and EMAC mutual-aid agreements by Month 1 (2026-11-14). The request includes draft MOU language covering: (1) each state's acceptance of the UC's authority to issue Zone One and Scenario Beta evacuation orders; (2) commitment to enforce unified evacuation messaging and shelter assignments on state roads and in state communities; (3) provision of state resources (highway patrol, National Guard) to support contraflow and perimeter operations; (4) mutual-aid resource sharing (water, fuel, medical) among the three states and with FEMA Regions 8 and 10; (5) post-event after-action-report and exercise planning for Months 1–3 (2026-11-14 to 2027-01-14). This request initiates a formal negotiation period that culminates in signed agreements by Month 1 (2026-11-14).

**Responsible Body/Role:** FEMA Region VIII IC (UC chair) on behalf of the Unified Command

**Suggested Timeframe:** Month 0 (2026-10-14), Hours 24–36 (T+24h to T+36h)

**Key Outputs/Deliverables:**

- MOU and EMAC agreement request letters issued to MT, WY and ID governors and FEMA Region 10
- Draft MOU and EMAC language (attached to request letters)
- Schedule for MOU-signature meetings (targeted completion by Month 1, 2026-11-14)
- UC decision-log entry documenting issuance of MOU requests

**Dependencies:**

- Verbal governor authorizations obtained at T+6h
- Unified Command operations progressing smoothly
- No major disputes or coordination gaps between NPS and states

### 26. UC issues a milestone assessment at T+24 hours, checking against the Phase 2 'go/no-go' gate: at least 95% of registered Zone One residents (West Yellowstone, Gardiner, Cody communities) have evacuated or sheltered in place, perimeters around evacuated towns are staffed and secured by National Guard to prevent looting, and a preliminary Scenario Beta interim-destination list (ranked hub list outside the 500 km ring) has been issued. The UC consolidates reports from the FUCE, state on-scene commanders and the Shelter Siting Panel, documenting evacuation completeness, perimeter-staffing status and shelter-intake progress. If the gate is met, the UC documents successful completion of Phase 2 and advises that the response has transitioned to the 'sustained operations' phase (T+24h to T+72h), during which the focus shifts to supply continuity, ashfall management and Scenario Beta readiness.

**Responsible Body/Role:** Unified Command (led by FEMA Region VIII IC) with data from FUCE, state commanders and advisory bodies

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 24 (T+24h)

**Key Outputs/Deliverables:**

- Phase 2 Gate G2 assessment document (yes/no decision: at least 95% of Zone One residents out; perimeters staffed; interim hub list issued)
- Zone One evacuation completion report by community (West Yellowstone, Gardiner, Cody)
- Perimeter-staffing and anti-looting operational status
- Interim Scenario Beta hub-destination list (ranked candidates outside the 500 km ring)
- UC briefing documenting gate results and transition to sustained-operations phase
- COP dashboard snapshot at T+24h

**Dependencies:**

- Zone One evacuation proceeding as planned from T+6h to T+24h
- Perimeter enforcement and National Guard deployment completed
- Scenario Beta hub preliminary list researched and drafted by planning staff

### 27. Shelter Siting Panel conducts formal suitability assessments at T+24, T+36, T+48, T+60 and T+72 hours, comparing real-time PM10 readings and ashfall forecasts at all active shelter sites against the established thresholds (50 ug/m³ for forecast-update trigger, 100 ug/m³ for suitability-review trigger). If any site exceeds the suitability threshold, the panel initiates a rapid relocation analysis (decision within 30 minutes proposed threshold) and recommends a backup site. A relocation order (issued by FUCE Operations Chief within 4 hours of threshold exceedance proposed threshold) specifies the new shelter site, transport routing and pickup schedule. The panel tracks all relocation logistics and confirms arrival of evacuees at the new site. This continuous monitoring and rapid-response protocol prevents evacuees from being sheltered in heavy ashfall and developing respiratory distress.

**Responsible Body/Role:** Shelter Siting & Air-Quality Assurance Panel (led by NOAA forecast lead) with execution by FUCE Operations Chief

**Suggested Timeframe:** Month 0 (2026-10-14), Hours 24, 36, 48, 60, 72 (T+24h, T+36h, T+48h, T+60h, T+72h)

**Key Outputs/Deliverables:**

- Shelter-suitability assessment reports at each time interval (T+24h, T+36h, T+48h, T+60h, T+72h)
- PM10 and ashfall-depth readings at all active and backup shelter sites
- Any relocation analyses and recommendations
- Relocation orders issued by FUCE Operations Chief (if suitability thresholds exceeded)
- Transport and logistics confirmation for any relocation (buses, pickup schedule, arrival confirmation)

**Dependencies:**

- Shelter Siting Panel established at T+0 with continuous PM10 monitoring
- Real-time PM10 data streaming to the panel and FUCE
- Backup shelter sites pre-surveyed and transport agreements in place

### 28. UC holds continuous hourly briefings (in addition to the scheduled T+0, T+2, T+6, T+12, T+24, T+36, T+48, T+60, T+72h formal briefings) during the 72-hour window, with rapid-update reports from the FUCE on any critical changes: corridor blockages, major weather shifts, ashfall intensity changes, supply delays or any USGS eruption-indicator changes approaching the Scenario Beta trigger threshold. These rapid-update calls (conducted via secure conference line) allow the UC to make real-time tactical decisions (reroutes, shelter relocations, supply contingencies) without waiting for the formal scheduled briefing. All UC decisions made between scheduled briefings are logged in the UC decision log with full documentation and time stamps.

**Responsible Body/Role:** Unified Command (led by FEMA Region VIII IC, chair) with participation by FUCE Operations Chief and key advisory-body leads as needed

**Suggested Timeframe:** Month 0 (2026-10-14), Hours 0–72 (T+0 to T+72h), continuous as needed between scheduled briefings

**Key Outputs/Deliverables:**

- Rapid-update call logs (time, participants, issue discussed, decision made)
- UC decision log entries for all decisions made on rapid-update calls
- COP dashboard updated in real time following each rapid-update call
- Notification memos to affected parties (states, FUCE, advisory bodies) documenting new UC orders or directives

**Dependencies:**

- UC continuously staffed at the FEMA Region VIII RRCC Denver
- FUCE Operations Chief available for rapid escalation calls 24/7
- Secure conference-line infrastructure and communications tested

### 29. Escalation Cell continuously monitors real-time USGS eruption indicators throughout the 72-hour window and immediately alerts the UC if any indicator crosses 80% of the Scenario Beta trigger threshold (a warning threshold), triggering a pre-brief for the UC. If any indicator crosses the full trigger threshold, the Escalation Cell convenes an immediate 5-minute verification meeting, confirms the threshold crossing, and issues a formal Trigger Crossing Declaration to the UC within 15 minutes. The UC, upon receiving this declaration, has a standing order to issue the Scenario Beta 500 km evacuation order within 30 minutes without requiring further deliberation or approval.

**Responsible Body/Role:** Escalation & Scenario Beta Decision Cell (led by USGS Volcano Disaster Assistance Program lead) with immediate notification to UC

**Suggested Timeframe:** Month 0 (2026-10-14), Hours 0–72 (T+0 to T+72h), continuous real-time monitoring

**Key Outputs/Deliverables:**

- Real-time indicator monitoring and hourly status briefings to UC (scheduled briefings at T+0, T+6, T+12, T+18, T+24, T+30, T+36, T+42, T+48, T+54, T+60, T+66, T+72h)
- Warning-threshold alerts (80% of trigger threshold) sent to UC and FUCE
- Trigger Crossing Declaration (if full threshold crossed), signed by USGS lead and issued within 15 minutes of detection
- UC decision log entry documenting Trigger Crossing Declaration and the Scenario Beta order issued within 30 minutes (if triggered)

**Dependencies:**

- Escalation Cell established at T+0
- Real-time USGS data feeds live and streaming continuously
- USGS trigger matrix finalized by T+3h
- UC standing order to issue Scenario Beta order within 30 minutes of Trigger Crossing Declaration

### 30. UC, upon receiving a Scenario Beta Trigger Crossing Declaration from the Escalation Cell, issues a formal Scenario Beta 500 km Evacuation Order within 30 minutes. The order specifies: (1) the eruption indicators that crossed the trigger threshold; (2) the 500 km radius evacuation boundary; (3) the tiered execution rings (0–100 km organized evacuation, 100–250 km time-banded evacuation, 250–500 km staged departures); (4) the interim Scenario Beta hub destinations (ranked list outside the 500 km ring); (5) the activation of the secondary-stage shelter and logistics plans (pre-authorized buses, rail corridors, secondary hubs with pre-signed host MOUs); (6) instructions to states, National Guard and FEMA to immediately activate all Scenario Beta contingency plans. This order is broadcast via IPAWS, WEA, NOAA Weather Radio, Guard signal bridging and media in English and five languages.

**Responsible Body/Role:** Unified Command (led by FEMA Region VIII IC, chair)

**Suggested Timeframe:** Month 0 (2026-10-14), within 30 minutes of Scenario Beta Trigger Crossing Declaration (exact time depends on trigger occurrence)

**Key Outputs/Deliverables:**

- Formal Scenario Beta 500 km Evacuation Order (signed by FEMA Region VIII IC on behalf of UC)
- Tiered-execution guidance for the three evacuation rings (0–100 km organized, 100–250 km time-banded, 250–500 km staged)
- Interim hub-destination list and assignments (which populations to which secondary hubs)
- Activation orders for secondary-stage shelter, logistics and transport contingencies
- Broadcast confirmation (IPAWS, WEA, NOAA, Guard signal, media in multiple languages)
- UC briefing documenting the Scenario Beta escalation and all decisions made in the 30-minute window

**Dependencies:**

- Scenario Beta Trigger Crossing Declaration received from Escalation Cell
- Interim hub-destination list prepared by FUCE Planning Chief before T+24h (Month 0 = 2026-10-14 Hour 24)
- Secondary-stage shelter, logistics and transport plans pre-authorized and ready for immediate activation
- Pre-signed MOUs with secondary hub host communities available (MOUs to be finalized by Month 1 = 2026-11-14, but interim working agreements pre-authorized for T+0 startup)

### 31. Upon issuance of a Scenario Beta 500 km Evacuation Order, the Unified Command immediately convenes an expanded UC Scenario Beta Response Cell, adding representatives from: (1) the secondary hub communities (Denver, Cheyenne, Billings) or their designees; (2) the National Guard regional commanders for out-of-state Guard deployment; (3) the U.S. Army Corps of Engineers (if emergency logistics support is needed); (4) representatives from the Department of Transportation (federal coordination of I-15, I-80, I-90 usage and emergency lane closures). This expanded cell meets continuously (at least every 2 hours) to coordinate the execution of the three evacuation rings, the routing of populations to secondary hubs, the activation of bus fleets and rail corridors, and the pre-positioning of supplies at secondary hubs.

**Responsible Body/Role:** Unified Command (led by FEMA Region VIII IC) expanded with secondary hub representatives, National Guard, USACE and DOT

**Suggested Timeframe:** Month 0 (2026-10-14), immediately upon Scenario Beta Evacuation Order issuance

**Key Outputs/Deliverables:**

- Expanded Scenario Beta Response Cell established (charter, membership, communication protocols)
- Activation of ring-by-ring evacuation and routing guidance (which populations to which secondary hubs, which roads and routes to use)
- Bus-fleet and rail-corridor deployment confirmation from National Guard and commercial carriers
- Supply pre-positioning confirmation at secondary hubs (water, N95, fuel, medical supplies shipped to Denver, Cheyenne, Billings)
- Briefing to expanded cell documenting Scenario Beta response execution and contingency plans

**Dependencies:**

- Scenario Beta 500 km Evacuation Order issued by UC
- Secondary hub list and interim MOUs pre-authorized (MOUs to be finalized by Month 2 = 2026-12-14, but interim working agreements in place)
- Bus fleets and rail carriers pre-contracted with standing activation clauses (signed before Month 0 = 2026-10-14)
- National Guard commanders briefed on Scenario Beta contingency plans and ready to receive orders

### 32. At T+72 hours (end of the 72-hour decision window), the UC holds a formal status briefing documenting: (1) total evacuees received and sheltered (Zone Zero and Zone One); (2) final status of the Scenario Beta escalation (if triggered or if indicators remained below threshold); (3) cumulative supply deliveries (water, N95, fuel) and any shortages or contingency activations; (4) responder casualties or exposure-limit violations; (5) post-event safety assessment for any re-entry or infrastructure restoration activities. The UC transitions governance from 72-hour crisis operations to Months 1–3 (2026-11-14 to 2027-01-14) hardening and post-event review mode, with daily (instead of hourly) briefings and a focus on documentation, MOUs, exercises and after-action planning.

**Responsible Body/Role:** Unified Command (led by FEMA Region VIII IC, chair)

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 72 (T+72h)

**Key Outputs/Deliverables:**

- UC T+72h Final Status Briefing agenda and briefing minutes
- Cumulative evacuation statistics and shelter occupancy by site
- Scenario Beta status (triggered or not; if triggered, execution summary)
- Supply-delivery summary (water, N95, fuel actual vs. target, any shortages)
- Responder incident summary (casualties, exposure violations, fatigue-related incidents)
- Post-event safety assessment and re-entry/infrastructure restoration preliminary guidance
- UC decision log final entries and closure
- Transition briefing to Phase 3 (Months 1–3 = 2026-11-14 to 2027-01-14 hardening and post-event review)

**Dependencies:**

- Continuous 72-hour UC operations from T+0 to T+72h
- All formal and rapid-update briefings completed on schedule
- All specialist advisory bodies operational and reporting throughout

### 33. FEMA Region VIII IC (UC chair) or designee convenes the first Months 1–3 (2026-11-14 to 2027-01-14) Hardening & Post-Event Review meeting with UC members, specialized advisory-body leads, state emergency managers, USGS, NOAA and NPS representatives. The meeting covers: (1) what went well and what could be improved in the 72-hour response (based on preliminary field observations and responder interviews); (2) a schedule for signed MOUs with the three governors, FEMA Region 10, utilities and Scenario Beta hub communities (target Month 1 = 2026-11-14 completion); (3) a schedule for three after-action reports (one at Month 1 = 2026-11-14 for the 72-hour response, one at Month 2 = 2026-12-14 for MOU and exercise readiness, one at Month 3 = 2027-01-14 for full post-event review); (4) a calendar for three full-scale multi-state exercises (one at Month 2 = 2026-12-14 covering boundary authority transfer and reroutes, one at Month 2.5 = 2026-12-29 covering Scenario Beta evacuation and hub coordination, one at Month 3 = 2027-01-14 covering integrated response) and six smaller operational exercises (shift-rotation, water-convoy, grid-failure recovery, multilingual alert testing, shelter relocation and post-event re-entry).

**Responsible Body/Role:** FEMA Region VIII IC (UC chair) or designee, with participation from all UC and advisory-body leads

**Suggested Timeframe:** Month 1 (2026-11-14), Week 1 (first week after T+72h)

**Key Outputs/Deliverables:**

- Hardening & Post-Event Review meeting agenda and minutes
- Preliminary improvements list (based on 72-hour response observations)
- MOU signature schedule (target dates for governors, Region 10, utilities, hub communities)
- After-action-report schedule (Month 1 = 2026-11-14, Month 2 = 2026-12-14, Month 3 = 2027-01-14 reports, with interim field-observer summaries)
- Full-scale exercise calendar (three multi-state exercises in Months 2–3 = 2026-12-14 to 2027-01-14) and six smaller operational exercises (Months 1–3 = 2026-11-14 to 2027-01-14)
- Resource allocation for hardening activities and exercise execution (cost estimates, personnel assignments)

**Dependencies:**

- 72-hour response completed at T+72h
- Preliminary field observations and responder feedback collected from all regions
- All UC and advisory-body records and decision logs from the 72-hour window accessible for review

### 34. FEMA Region VIII IC (UC chair) and state emergency managers (MT, WY, ID governors or their designees) sign formal Memoranda of Understanding (MOUs) confirming: (1) each state's acceptance of the UC's authority to issue Zone One and Scenario Beta evacuation orders; (2) commitment to enforce unified evacuation messaging and shelter assignments on state roads and communities; (3) provision of state resources (highway patrol, National Guard) to support contraflow and perimeter operations; (4) mutual-aid resource sharing (water, fuel, medical supplies) among the three states and FEMA Regions 8 and 10; (5) commitment to participate in post-event exercises and after-action-report development. Simultaneous MOUs are signed with FEMA Region 10 (Seattle), regional utilities (Montana-Dakota Utilities, Pacific Power, Idaho Power) and Scenario Beta secondary hub communities (Denver, Cheyenne, Billings or others outside the 500 km ring). All MOUs are signed by the deadline of Month 1 (2026-11-14).

**Responsible Body/Role:** FEMA Region VIII IC (UC chair) for the federal side; state governors for their respective states; utilities and hub-community representatives for their organizations

**Suggested Timeframe:** Month 1 (2026-11-14) by end of month

**Key Outputs/Deliverables:**

- Signed MOUs with MT, WY and ID governors (three documents, signed and countersigned)
- Signed MOU with FEMA Region 10 (Seattle)
- Signed MOUs with regional utilities (Montana-Dakota Utilities, Pacific Power, Idaho Power)
- Signed MOUs with Scenario Beta secondary hub communities (Denver, Cheyenne, Billings, etc.)
- EMAC mutual-aid agreements activation confirmations (among MT, WY, ID and with FEMA Regions 8 and 10)
- Distribution of all signed MOUs to UC members and advisory-body leads

**Dependencies:**

- Draft MOU language circulated to all parties by Month 0 (2026-10-14) Hour 36
- Hardening & Post-Event Review meeting held at Month 1 (2026-11-14) Week 1
- Legal review of MOU language by each party's legal counsel completed

### 35. FEMA Region VIII IC (UC chair) or designee publishes the first After-Action Report (AAR-1: 72-Hour Response) by Month 1 (2026-11-14), documenting: (1) a timeline and narrative of the 72-hour evacuation response (T+0 to T+72h); (2) quantitative outcomes (total evacuees sheltered, supply deliveries, responder incidents, gateway clearance rates); (3) comparison of actual outcomes to pre-planned targets (98% Zone Zero clearance by T+6h, 95% Zone One clearance by T+24h, etc.); (4) critical decisions made and their rationale (recorded from UC decision log); (5) responder feedback and preliminary observations (lessons learned); (6) recommendations for improvements to the governance structure, command protocols, supply logistics or communications. The AAR-1 is distributed to all UC members, state emergency managers, USGS, NOAA, NPS and is published as a public document to maintain transparency.

**Responsible Body/Role:** FEMA Region VIII IC (UC chair) or designee, with input from FUCE, advisory bodies and state representatives

**Suggested Timeframe:** Month 1 (2026-11-14)

**Key Outputs/Deliverables:**

- After-Action Report-1 (AAR-1: 72-Hour Response, 20–30 pages)
- Quantitative outcomes summary table (evacuation statistics, supply metrics, incidents)
- Comparison of actual vs. planned outcomes
- Critical decisions narrative (from UC decision log)
- Responder feedback and field observations summary
- Recommendations for improvements (tagged as short-term, medium-term, or long-term actions)
- Distribution memo and public-release summary

**Dependencies:**

- 72-hour response completed at T+72h
- UC decision log and all briefing minutes consolidated and reviewed
- Field observations and responder feedback collected from all regions by Month 1 (2026-11-14) Week 1

### 36. FEMA Region VIII IC (UC chair) or designee convenes the first full-scale multi-state exercise (Exercise-1: 'Cascade Boundary') in Month 2 (2026-12-14), testing the authority-transfer protocols and reroute decision-making across the NPS-to-state boundaries at all three exit gates (West, North, East Entrance). The exercise simulates a Gallatin Canyon blockage at T+3h that requires a 45-minute clearance attempt (proposed threshold) followed by automatic diversion of overflow traffic to the US-89 Gardiner corridor. The exercise tests: (1) whether the Boundary Coordination Officer and state on-scene commanders can issue reroutes within 5 minutes of the blockage detection; (2) whether the COP dashboard is updated in real time with traffic redirects; (3) whether drivers receive updated route guidance via IPAWS, HAR, VMS or printed route cards; (4) whether the diversion adds only the planned 2–4 hours to transit times for affected vehicles, not more. Exercise participants include the FUCE, state traffic-control personnel at each gate, the Authority Cell, the Shelter Siting Panel and a sample of drivers (simulated evacuees in vehicles with communications staff).

**Responsible Body/Role:** FEMA Region VIII IC (UC chair) or designee, with FUCE Operations Chief as exercise director

**Suggested Timeframe:** Month 2 (2026-12-14), Week 1 (2026-12-14, within first week of month)

**Key Outputs/Deliverables:**

- Exercise-1 planning memo and scenario description
- Exercise-1 'Cascade Boundary' simulation (2-4 hours duration, in-person or hybrid)
- Post-exercise hot wash (immediate feedback from participants on what worked and what didn't)
- Exercise-1 After-Action Report (preliminary, by Month 2 = 2026-12-14 Week 2)

**Dependencies:**

- Hardening & Post-Event Review meeting held at Month 1 (2026-11-14) Week 1
- AAR-1 (72-Hour Response) published by Month 1 (2026-11-14)
- All three states and FUCE committed to exercise participation

### 37. FEMA Region VIII IC (UC chair) or designee convenes the second full-scale multi-state exercise (Exercise-2: 'Ring Dispersal') in Month 2.5 (2026-12-29), testing Scenario Beta execution: the Escalation Cell simulates a USGS Trigger Crossing Declaration at a notional T+36h, triggering the UC to issue a 500 km Evacuation Order. The exercise tests: (1) whether the UC issues the order within 30 minutes of trigger declaration; (2) whether the expanded Scenario Beta Response Cell activates and coordinates ring-by-ring evacuation (0–100 km organized, 100–250 km time-banded, 250–500 km staged); (3) whether secondary hub communities (Denver, Cheyenne) receive and begin processing evacuees within their assigned rings; (4) whether bus fleets and rail corridors are deployed to move evacuees from primary shelters (Bozeman, Idaho Falls) to secondary hubs within the planned timelines; (5) whether supply pre-positioning at secondary hubs is confirmed and adequate. Exercise participants include the UC, FUCE, secondary hub emergency managers, National Guard, bus and rail operators, and simulated evacuee populations.

**Responsible Body/Role:** FEMA Region VIII IC (UC chair) or designee, with FUCE Operations Chief as exercise director

**Suggested Timeframe:** Month 2.5 (2026-12-29, between Months 2 and 3 = 2026-12-14, 2027-01-14)

**Key Outputs/Deliverables:**

- Exercise-2 planning memo and Scenario Beta scenario description
- Exercise-2 'Ring Dispersal' simulation (4-6 hours duration, multi-state, in-person or hybrid)
- Post-exercise hot wash (feedback on Scenario Beta coordination, ring execution, hub readiness)
- Exercise-2 After-Action Report (preliminary, by Month 3 = 2027-01-14 Week 1)

**Dependencies:**

- Hardening & Post-Event Review meeting held at Month 1 (2026-11-14) Week 1
- AAR-1 (72-Hour Response) published by Month 1 (2026-11-14)
- Signed MOUs with secondary hub communities by Month 1 (2026-11-14) end
- Secondary hub emergency managers and National Guard committed to exercise participation

### 38. FEMA Region VIII IC (UC chair) or designee convenes the third full-scale multi-state exercise (Exercise-3: 'Yellowstone Integrated Response') in Month 3 (2027-01-14), integrating all elements of the response: the Escalation Cell simulates real-time eruption indicators during a 12-hour compressed exercise timeline, the Unified Command makes strategic decisions (zone expansion, Scenario Beta triggers), the FUCE executes tactical operations (contraflow, tow dispatch, water convoy routing), the Responder Health Board manages shift rotation and fatigue, the Authority Cell coordinates boundary transfers, the Shelter Siting Panel monitors PM10 and triggers relocations, and the Scenario Beta Response Cell (if triggered) activates ring-by-ring evacuation. The exercise tests the integrated governance structure under conditions approaching the actual 72-hour response complexity. Exercise participants include all UC and advisory-body members, state emergency managers, FUCE staff, utilities, hospitals, shelter operators, bus and rail carriers, and secondary hub representatives.

**Responsible Body/Role:** FEMA Region VIII IC (UC chair) or designee, with FUCE Operations Chief as exercise director

**Suggested Timeframe:** Month 3 (2027-01-14), Week 2 (2027-01-14, within second or third week of month)

**Key Outputs/Deliverables:**

- Exercise-3 planning memo and integrated-response scenario description
- Exercise-3 'Yellowstone Integrated Response' simulation (8-12 hours duration, 12-hour compressed timeline, multi-state, in-person at FEMA RRCC and FUCE forward element)
- Real-time COP dashboard and decision-log documentation during exercise
- Post-exercise hot wash with all participants
- Exercise-3 After-Action Report (detailed, by Month 3 = 2027-01-14 Week 3 or 4)

**Dependencies:**

- Hardening & Post-Event Review meeting held at Month 1 (2026-11-14) Week 1
- AAR-1 (72-Hour Response) and Exercise-1/2 reports completed and reviewed by Month 2 (2026-12-14)
- Signed MOUs with all states, Region 10, utilities and secondary hubs by Month 1 (2026-11-14) end
- All UC and advisory-body members, state commanders and federal partners confirmed for participation

### 39. FEMA Region VIII IC (UC chair) or designee publishes the final comprehensive After-Action Report (AAR-3: 72-Hour Response + Months 1–3 = 2026-11-14 to 2027-01-14 Hardening & Exercises) by the end of Month 3 (2027-01-14), consolidating lessons learned from: (1) the actual 72-hour response (T+0 to T+72h); (2) the Months 1–3 (2026-11-14 to 2027-01-14) MOU negotiations and governance formalization; (3) the three full-scale exercises (Exercise-1 Boundary, Exercise-2 Scenario Beta, Exercise-3 Integrated Response) and six smaller operational exercises. The report documents: (1) what the governance structure achieved during the 72-hour crisis (strengths and weaknesses); (2) what improvements have been made to governance, command protocols, communications, supply logistics and authority clarification during Months 1–3 (2026-11-14 to 2027-01-14); (3) what gaps or risks remain and recommendations for future planning cycles; (4) updated governance best practices and lessons learned to inform planning for future Yellowstone eruption events or similar multi-state volcanic evacuations. AAR-3 is published as an official FEMA and NPS document and distributed to all stakeholders and to the National Incident Management System (NIMS) community for use in national emergency management planning.

**Responsible Body/Role:** FEMA Region VIII IC (UC chair) or designee, with input from all UC members, advisory-body leads, state emergency managers, exercise after-action reports and responder feedback

**Suggested Timeframe:** End of Month 3 (2027-01-14)

**Key Outputs/Deliverables:**

- After-Action Report-3 (AAR-3: Comprehensive 72-Hour + Months 1–3 = 2026-11-14 to 2027-01-14 Report, 40–60 pages)
- Integrated lessons-learned summary (governance, command, communications, logistics, authority)
- Comparison of planned vs. actual outcomes across all phases (72-hour response, MOUs, exercises)
- Updated governance best practices and recommendations for future volcanic evacuation planning
- Appendices: AAR-1 (72-hour response), Exercise-1/2/3 and operational-exercise reports, signed MOUs, UC decision log, COP dashboard snapshots
- Public-release summary and distribution memo
- Briefing to FEMA Administrator, NPS Director and White House National Security Council

**Dependencies:**

- AAR-1 (72-Hour Response) published by Month 1 (2026-11-14)
- Signed MOUs with all parties by Month 1 (2026-11-14) end
- Exercise-1, Exercise-2 and Exercise-3 After-Action Reports completed by end of Month 3 (2027-01-14) Week 3
- All operational exercises (shift-rotation, water-convoy, grid-failure, multilingual alert, shelter relocation, re-entry) completed and documented by Month 3 (2027-01-14)

# Decision Escalation Matrix

**Scenario Beta Trigger Verification: USGS Eruption Indicators Cross Pre-Authorized VEI-7 Thresholds**
Escalation Level: Unified Command (Strategic Oversight Board)
Approval Process: Escalation & Scenario Beta Decision Cell declares threshold crossing (within 15 minutes of detection); UC issues 500 km Evacuation Order within 30 minutes without further approval. Tie-breaker: FEMA Region VIII IC. Documented in UC decision log.
Rationale: The pre-authorized USGS trigger matrix (uplift rate, seismic magnitude, gas flux, magma depth) determines whether Scenario Beta escalates from 100 km to 500 km radius evacuation, affecting millions of people across four states and two FEMA regions. Crossing the threshold is a scientific determination by the Decision Cell but legally and operationally binding on the UC. Delay beyond 30 minutes risks uncontrolled shadow evacuation.
Negative Consequences: Failure to escalate promptly leaves 100,000–500,000 additional evacuees without published shelter destinations or transport plans, triggering chaotic, uncontrolled flight on I-15, I-80, I-90 that saturates the Zone One evacuation corridors and strands the original 35,800 park evacuees in traffic. Estimated impact: 4–8 hour evacuation delay, 20–50 preventable respiratory or transport-related casualties.

**Corridor Blockage Exceeding Rapid-Clearance Capacity: Gallatin Canyon or Gardiner Single-Point Failure Cannot Be Cleared Within 45 Minutes**
Escalation Level: Forward Unified Command Element (FUCE) Operations Section Chief with mandatory UC notification
Approval Process: Pre-authorized loss-of-exit rule: if blockage persists >45 minutes (proposed threshold) and tow/rockfall teams cannot clear, FUCE Operations Chief triggers overflow diversion to the nearest surviving exit within 15 minutes of the decision. No UC approval required. If a second exit is simultaneously disabled (unlikely), shelter-in-place order issued for remaining queued vehicles and UC is notified immediately.
Rationale: The three exit corridors are the sole throughput path for 35,800 evacuees within a T+6 hour deadline. Gallatin Canyon (US-191/US-20) is a two-lane mountain pass with no shoulder; a single blockage (breakdown, rockslide, secondary tremor-induced slide) lasting 45+ minutes exceeds the diversion capacity and forces either a shelter-in-place contingency or a 2–4 hour delay to the overall evacuation. Pre-authorized reroute thresholds enable immediate action without command deliberation.
Negative Consequences: A 2–4 hour evacuation delay due to a single-corridor blockage overlaps peak evacuation (T+2 to T+8) with ashfall arrival, exposing 5,000–8,000 stranded vehicles to respiratory hazard. Uncontrolled rerouting (without FUCE coordination) could block secondary exits and cascade into gridlock. Estimated impact: 500–2,000 vehicle occupants stranded in ash; 5–15 respiratory-distress casualties if medical response is delayed.

**NPS-to-State Authority Handoff Dispute: Conflicting Orders or Jurisdiction Gaps at Park Boundary During Peak Evacuation Traffic Crossing**
Escalation Level: Authority & Jurisdictional Coordination Cell with Boundary Coordination Officer, escalating unresolved disputes to FUCE Operations Chief, then to Unified Command
Approval Process: Boundary Coordination Officer (co-located at FUCE) mediates disputes between NPS on-scene commander and state on-scene commander within 30 minutes. State commanders are pre-authorized to issue reroutes within pre-written matrix without NPS approval. If state and NPS disagree on reroute validity or shelter assignment, matter escalates to FUCE Operations Chief (1 hour decision window). If still unresolved, escalates to UC for binding decision. Documented in Authority Cell log.
Rationale: Contraflow traffic crosses from NPS federal land to state highways mid-corridor, without a hard boundary where both sides can formally hand off responsibility. A dispute over shelter placement, checkpoint staffing or perimeter enforcement creates a 15–45 minute decision latency during the evacuation peak, cascading into a 500–1,000 vehicle backup. Pre-authorized reroute authority and rapid mediation limit escalation.
Negative Consequences: A 15–45 minute authority gap (no agreed reroute or conflicting shelter assignment) causes 500–1,000 vehicles to queue improperly or take wrong exits. One unresolved dispute at a single checkpoint cascades into a 1–2 hour evacuation delay for downstream traffic. Additionally, Region 8/10 seams leave Idaho mutual-aid requests (Boise, Pocatello resources) uncoordinated, delaying water/fuel convoys by 1–2 hours.

**Shelter Suitability Failure: Real-Time PM10 Exceeds 100 ug/m³ Threshold at Primary Shelter, Requiring Emergency Relocation of 10,000–15,000 Occupants**
Escalation Level: Shelter Siting & Air-Quality Assurance Panel with binding escalation to FUCE Operations Chief (shelter relocation order) and secondary escalation to Unified Command if relocation cannot be completed within 4 hours
Approval Process: Panel detects PM10 >100 ug/m³ at primary shelter (hourly monitoring); convenes within 30 minutes to assess suitability; recommends backup site (ranked, 50+ km upwind). FUCE Operations Chief approves relocation and issues order within 1 hour of panel finding. Buses and intake staff are redirected to backup shelter; relocation is tracked and completion confirmed. If relocation cannot be completed within 4 hours (proposed threshold) due to transport or logistics failure, escalates to UC for contingency (e.g., split occupancy across multiple backup sites, supplemental N95 distribution).
Rationale: Ashfall forecasts are uncertain by 100+ km; actual ashfall may exceed model predictions by 2–3x, rendering selected sites unsuitable within 12–24 hours of occupation. Real-time PM10 monitoring allows rapid detection and relocation before respiratory distress develops. A 10,000–15,000 person relocation requires 3–6 hours of transport and intake, consuming significant bus/driver and shelter resources during the evacuation peak. If executed without UC awareness and contingency planning, it cascades into secondary shortages.
Negative Consequences: If actual ashfall is 2–3x heavier than forecast and shelters are not relocated, 500–2,000 occupants develop respiratory distress within 6–24 hours; 5–10 may die if medical care is delayed. A relocation ordered without transport readiness causes 2–4 hour delay and potential stranding of occupants mid-transit. If the only backup shelters are also inside the heavy ashfall zone, a second relocation becomes necessary, consuming additional resources and compounding delays.

**Responder Exposure Limit Breached: Staffing at Traffic-Control Checkpoints Falls Below 50% Due to Fatigue or Respiratory Symptoms, Threatening Evacuation Throughput and Checkpoint Closure**
Escalation Level: Responder Health & Fatigue Management Board with authority to trigger standby-reserve deployment, escalating resource-shortage decisions to FUCE Operations Chief and then to Unified Command
Approval Process: Board identifies any checkpoint with coverage <50% (proposed threshold) due to exposure limits (6-hour shifts, 2-hour rest) or responder withdrawal for respiratory symptoms. Board convenes within 15 minutes and authorizes activation of the 30–50 person standby reserve to deploy within 4 hours (proposed threshold). If standby reserve cannot close the gap or is already depleted, escalates to FUCE Operations Chief for checkpoint consolidation decisions (combining two posts to maintain coverage) or to UC for out-of-state Guard request. Documented in fatigue-management log.
Rationale: The 72-hour continuous response requires 1.5 relief responders per position to maintain 24/7 coverage; strict exposure limits (6-hour shifts, 18-hour withdrawal) are essential to prevent entrapment and respiratory injury but reduce concurrent staffing. If coverage at any checkpoint falls below 50%, traffic-control effectiveness collapses and vehicle throughput drops by 5–10%, extending evacuation by 1–2 hours. Standby reserves and consolidated posts prevent this degradation.
Negative Consequences: An uncovered traffic checkpoint allows uncontrolled vehicle movement, wrong-exit usage, and loss of real-time reroute capability. A 2–4 hour evacuation delay due to staffing gaps extends the overlap between peak traffic and ashfall onset, exposing 2,000–5,000 additional vehicle occupants to respiratory hazard. Additionally, uncontrolled perimeter breaks at evacuated towns enable looting and re-entry of unauthorized persons, creating secondary safety and security incidents.

**Water Convoy or Critical Supply Delivery Delayed: Arrival at Shelters Pushed Beyond T+24 Hours (Phase 2 Gate), Threatening Shelter Operations and Forcing Supplemental-Reserve or Contingency Activation**
Escalation Level: FUCE Logistics Section Chief with escalation to FUCE Operations Chief (contingency activation) and Unified Command (additional Guard escort or additional convoy request)
Approval Process: Logistics Chief tracks real-time GPS location of water convoys. If ETA exceeds T+24 h (Phase 2 gate deadline), Logistics Chief alerts FUCE Operations Chief within 30 minutes of the forecast delay. Contingency actions are pre-authorized: (1) advance deployment of forward-depot supplemental water (pre-staged at Bozeman, Billings, Idaho Falls at T-48 h); (2) activation of supplemental N95 reserve at Billings or Salt Lake City if ashfall is heavier than modeled and mask consumption exceeds 20% of stock per day (proposed threshold); (3) request for additional Guard escort or ground-transport priority from the UC if convoy is delayed by traffic or road damage. If convoy is delayed >12 hours beyond target, escalates to UC for supplemental federal resource request.
Rationale: Water convoys from Salt Lake City are required to arrive at shelters by T+24 h to sustain 15,000 evacuees at Bozeman and 10,000 at Idaho Falls (estimate) for the next 48 hours (T+24 to T+72). Ashfall and evacuation-traffic gridlock can delay convoys from the T+12 h dispatch to arrival as late as T+30 h (estimate), forcing shelters to ration supplies or activate forward depots. Forward depots and supplemental reserves are the contingency; if both are exhausted, additional convoys or federal water mobilization is required.
Negative Consequences: A 24-hour delay in water arrival (T+36 h instead of T+24 h) leaves 15,000–25,000 shelter occupants without adequate water for drinking, cooking and medical use for 12+ hours. Water shortage increases risk of dehydration, medication non-compliance and secondary health emergencies. If forward-depot supplemental reserves are also depleted (unusual but possible if initial intake was larger than planned), water shortages could affect medical care (cooling for heat-stressed patients, steam for respiratory treatment) and sanitation, risking disease outbreaks.

# Monitoring Progress

### 1. Evacuation Progress Tracking Against Phase Gates and Time Deadlines
**Monitoring Tools/Platforms:**

  - Shared Common Operating Picture (COP) Digital Dashboard (updated hourly with gate counts from state checkpoints)
  - Real-time Exit Counting System (at West, North, East Entrance; integrated with COP)
  - UC Decision Log (documenting all strategic decisions and their timing)
  - Phase 1 and Phase 2 Gate Assessment Templates (98% clearance by T+6h; 95% Zone One clearance by T+24h)

**Frequency:** Continuous real-time monitoring; formal gate assessments at T+6h (Phase 1) and T+24h (Phase 2); hourly executive briefings to the Unified Command at T+0, T+2, T+6, T+12, T+24, T+36, T+48, T+60, T+72h

**Responsible Role:** Forward Unified Command Element (FUCE) Operations Section Chief, with real-time vehicle counting by state checkpoints (MT/WY/ID highway patrol, NPS rangers); reporting consolidated by FUCE Planning Chief to the UC

**Adaptation Process:** If cumulative exit counts at T+6h fall short of 98% (about 35,084 of 35,800), FUCE Operations Chief convenes emergency reroute review with Authority Cell and FUCE to redirect remaining vehicles and accelerate backcountry sweeps. If T+24h Zone One clearance falls short of 95%, UC issues Scenario Beta interim destination list early and activates secondary-stage contingencies. Mid-course adjustments include tow-team redeployment to persistent blockages and Guard staffing surge at under-performing corridors.

**Adaptation Trigger:** Gate shortfall >2% at Phase 1 (T+6h) or >5% at Phase 2 (T+24h); any single corridor throughput falling >20% below planned 660 vehicles/hour (proposed threshold); blockage persisting >45 minutes triggering diversion rule

### 2. USGS Eruption Indicator Monitoring and Scenario Beta Trigger Detection
**Monitoring Tools/Platforms:**

  - Real-time USGS seismic, GPS and gas monitoring feeds (integrated at FUCE and UC)
  - Escalation & Scenario Beta Decision Cell indicator-status dashboard (hourly updates of uplift rate, seismic magnitude, magma-depth model relative to finalized trigger thresholds)
  - USGS Eruption Indicator Log (documenting each indicator value, timestamp, and margin from trigger threshold)
  - Automated threshold-alert system (armed at T+0; alerts when indicator approaches 80% of trigger threshold and again at 100%)

**Frequency:** Continuous real-time monitoring from T+0 onwards; formal Escalation Readiness Assessments issued by Decision Cell every 6 hours (T+0, T+6, T+12, T+18, T+24, T+30, T+36, T+42, T+48, T+54, T+60, T+66, T+72h); warning alerts if any indicator crosses 80% of trigger threshold; trigger declaration within 15 minutes of any threshold crossing

**Responsible Role:** Escalation & Scenario Beta Decision Cell (led by USGS Volcano Disaster Assistance Program lead), with real-time data feeds from USGS seismic, GPS and gas networks; UC Liaison reports cell decisions to the Unified Command

**Adaptation Process:** If any USGS eruption indicator crosses the pre-authorized threshold (finalized by T+3h), the Decision Cell issues a Trigger Crossing Declaration within 15 minutes. The Unified Command automatically issues the Scenario Beta 500 km Evacuation Order within 30 minutes without further deliberation. Secondary-stage hubs, bus fleets and rail corridors are immediately activated. Interim messaging switches from shelter-in-place (outer ring) to evacuation orders for the 100–500 km rings. If an indicator crosses 80% of threshold (warning level), the UC pre-briefs and begins activating contingencies (Beta hub notification, secondary convoy preparation).

**Adaptation Trigger:** Any USGS indicator (uplift rate, seismic magnitude, gas flux, magma-depth estimate) crosses the pre-written trigger threshold as defined in the finalized matrix by T+3h; estimated time-to-trigger calculation shows remaining window <6 hours (proposed threshold); or 80% threshold-warning triggers pre-activation of secondary contingencies

### 3. Real-Time Ashfall and Air-Quality Monitoring with Dynamic Shelter-Siting and Relocation Triggers
**Monitoring Tools/Platforms:**

  - PM10 and ashfall-depth sensors deployed at forward element (Livingston/Bozeman) and all active shelter sites; readings updated hourly to the Shelter Siting Panel and COP dashboard
  - NOAA 72-hour ashfall and wind-direction forecast (updated every 6 hours from T+0 onwards)
  - Shelter Suitability Assessment Log (documenting PM10 readings, ashfall depth, forecast updates and any suitability threshold exceedances)
  - Backup Shelter Site Readiness Checklist (8–10 pre-surveyed candidates ranked by upwind distance; transport agreements and capacity confirmed)

**Frequency:** Continuous hourly PM10 monitoring at all sites from T-12h through T+72h; NOAA forecast updates every 6 hours; formal Shelter Siting Panel suitability assessments at T+6h (initial siting decision), T+24h, T+36h, T+48h, T+60h and T+72h; immediate convening if PM10 exceeds 50 ug/m³ (forecast-update trigger) or 100 ug/m³ (suitability-review trigger)

**Responsible Role:** Shelter Siting & Air-Quality Assurance Panel (led by NOAA ashfall/air-quality forecast lead), with real-time PM10 data collection from sensor networks and NOAA forecast updates; FUCE Operations Chief issues relocation orders based on panel recommendations

**Adaptation Process:** At T+6h, panel recommends final shelter sites based on latest plume forecast; FUCE Operations Chief approves and directs buses and intake staff to assigned sites. If PM10 at any primary shelter exceeds 100 ug/m³ during operations (T+24h or later), panel conducts rapid relocation analysis (within 30 minutes) and recommends an upwind backup site. FUCE Operations Chief issues relocation order within 1 hour; buses are redirected to the backup shelter and occupant transfer is completed within 4 hours (proposed threshold). If multiple shelters are threatened simultaneously or backup sites are also unsuitable, escalation to UC for split-occupancy or supplemental N95 reserve activation.

**Adaptation Trigger:** PM10 reading at any shelter exceeds 50 ug/m³ (triggers forecast-update review) or 100 ug/m³ (triggers suitability assessment and potential relocation); forecast wind shift of >30 degrees from current model; actual ashfall depth exceeds modeled expectation by >50% (measured visually or by sensor); NOAA forecast indicates ash concentration will exceed 200 ug/m³ at a primary shelter within 12 hours (proposed threshold)

### 4. Water, N95 Respirator and Generator Fuel Supply-Chain Monitoring with Convoy Tracking and Contingency Activation
**Monitoring Tools/Platforms:**

  - Water-convoy GPS tracking and real-time location updates (from Salt Lake City dispatch through arrival at Bozeman and Idaho Falls shelters)
  - Supply Inventory Tracking Spreadsheet (N95 stock at each checkpoint and shelter, fuel inventory at receiving hospitals and comms centers, updated every 4 hours)
  - FUCE Logistics Log (documenting all supply requests, dispatch confirmations, and delivery status)
  - Forward-Depot Readiness Report (confirming pre-positioned water, N95 and fuel at Bozeman, Billings, Idaho Falls by T-48h and available for emergency deployment)
  - Contingency Activation Checklist (supplemental N95 reserve at Billings/Salt Lake City, additional fuel convoys from regional vendors)

**Frequency:** Continuous GPS tracking of water convoys from T+12h (dispatch) through arrival at shelters (target T+24h). Inventory spot-checks every 4 hours during peak operations (T+0 to T+36h), then every 6 hours through T+72h. Fuel status at receiving hospitals (Bozeman, Livingston, Idaho Falls) checked every 8 hours. Emergency convoy dispatch triggers immediate (within 30 minutes) FUCE Logistics notification and UC brief.

**Responsible Role:** FUCE Logistics Section Chief, with real-time convoy tracking via GPS and coordination with Salt Lake City suppliers; fuel pre-positioning and hospital liaison coordination with the three receiving hospitals. Responder Health & Fatigue Management Board monitors responder N95 consumption and triggers supplemental-reserve activation if usage exceeds 20% of available stock per day (proposed threshold)

**Adaptation Process:** If water convoy ETA exceeds T+24h (Phase 2 gate), Logistics Chief immediately alerts FUCE Operations Chief and activates forward-depot supplemental water release (pre-staged at Bozeman, Billings, Idaho Falls) within 2 hours. If ashfall is heavier than modeled and N95 consumption exceeds 20% of stock per day, supplemental reserve at Billings/Salt Lake City is activated for daily air or ground transport to shelters. If a receiving hospital reports fuel reserves below 48-hour supply, a dedicated priority fuel convoy is requested from regional vendors with 2-hour ETA guarantee. If total supply delay cascades and threatens shelter operations, escalation to UC for federal resource request (additional Guard logistics support, military airlift).

**Adaptation Trigger:** Water convoy ETA forecast to exceed T+24h by >2 hours; N95 consumption at any shelter or checkpoint exceeds 25% of daily stock (20% threshold plus 5% buffer); hospital fuel inventory falls below 36-hour supply; any forecast delay >6 hours from planned delivery (T+12h for water dispatch, T+24h for arrival)

### 5. Authority Transfer and Jurisdictional Coordination Monitoring with Boundary-Handoff Execution Tracking
**Monitoring Tools/Platforms:**

  - Authority-Transfer Log (maintained by Boundary Coordination Officer; hourly entries tracking vehicle and responder crossings from NPS to state control at each gate: West, North, East Entrance)
  - Reroute Authority Execution Record (documenting all reroutes issued by state on-scene commanders under pre-authorized standing orders; any disputes with NPS recorded and resolution tracked)
  - Region 8/10 Mutual-Aid Request Log (Idaho-specific resource requests to Boise and Pocatello; dispatch confirmations and arrival tracking)
  - FAA Airspace Coordination Log (aviation-grounding confirmations, medevac-exception requests and FAA responses)

**Frequency:** Continuous real-time authority-transfer tracking at all checkpoints from T+0 through T+24h (peak boundary crossing). Formal Authority Cell briefings to the FUCE every 6 hours (T+0, T+6, T+12, T+18, T+24h). Rapid escalation (within 30 minutes) if any reroute authority dispute arises or if a Region 8/10 mutual-aid request is delayed.

**Responsible Role:** Authority & Jurisdictional Coordination Cell (led by Boundary Coordination Officer at FUCE), with on-scene commanders at each park gate (NPS at West/North/East Entrances; MT/WY/ID highway patrol at corresponding corridor exits); FEMA Region 10 liaison at UC (Denver) coordinating Idaho mutual-aid requests

**Adaptation Process:** If a state on-scene commander and NPS incident commander dispute a reroute or shelter assignment, the Boundary Coordination Officer mediates within 30 minutes via conference call. If consensus is not reached, the matter escalates to FUCE Operations Chief (1-hour decision window); if still unresolved, escalates to UC for binding decision. Pre-authorized reroute authority allows state commanders to issue traffic control orders within pre-written limits without waiting for park approval, reducing decision latency. If Idaho mutual-aid requests (Boise, Pocatello resources) are delayed >1 hour, Region 10 liaison at UC immediately contacts FEMA Region 10 (Seattle) for expedited activation.

**Adaptation Trigger:** Any reroute authority dispute requiring escalation beyond the Boundary Coordination Officer; state commander reroute issued without proper notification (out-of-sequence); Region 8/10 mutual-aid request delayed >1 hour beyond submission; any vehicle or responder not properly accounted for in the authority-transfer log at a checkpoint; conflicting evacuation orders or shelter assignments from NPS and a state

### 6. Responder Health, Fatigue and Exposure-Limit Compliance Monitoring with Staffing-Continuity Risk Assessment
**Monitoring Tools/Platforms:**

  - Shift-Log Tracking System (documenting hours worked, post location, exposure conditions and N95 usage for every deployed responder at traffic checkpoints and perimeters)
  - Responder Fatigue-Risk Assessment Report (issued at T+12h, T+24h, T+36h, T+48h, T+60h, T+72h; documenting cumulative hours and identifying responders approaching or exceeding 18-hour withdrawal threshold)
  - N95 Inventory and Replacement-Cycle Tracking (stock at each checkpoint, replacement intervals as masks clog, consumption rate compared to model)
  - Standby-Reserve Readiness Confirmation (30–50 out-of-region responders pre-positioned outside the ash zone; deployment status and availability)
  - Responder-Fatigue Hotline Log (confidential reports from responders requesting relief or reporting exposure symptoms; tracked for medical evaluation and rotation decisions)

**Frequency:** Real-time shift-log tracking throughout the 72-hour window. Formal fatigue-risk assessments every 6 hours (concurrent with UC briefing schedule: T+6h, T+12h, T+18h, T+24h, T+30h, T+36h, T+42h, T+48h, T+54h, T+60h, T+66h, T+72h). N95 inventory spot-checks every 4 hours during peak operations (T+0 to T+36h). Emergency responder-health incidents reported immediately (within 15 minutes) to the Responder Health Board and medical officer.

**Responsible Role:** Responder Health & Fatigue Management Board (led by NPS Chief Ranger), with shift-log data collection from all deployed responders and state/Guard commanders; medical officer from the nearest receiving hospital evaluates any responders with respiratory symptoms or heat stress

**Adaptation Process:** If any checkpoint's staffing falls below 50% of required positions due to exposure-limit rotations or responder withdrawal, the Responder Health Board immediately (within 15 minutes) authorizes activation of the standby reserve for deployment within 4 hours. If responders show acute respiratory distress or heat-related symptoms, they are immediately withdrawn from ash-exposed duty and referred to medical evaluation at the nearest hospital. If N95 consumption exceeds modeled expectations (clogging faster than forecast), supplemental responder N95 reserves are activated for distribution. If cumulative responder fatigue is assessed as critical (multiple personnel approaching 18-hour limits simultaneously), the board recommends to FUCE Operations Chief that lower-priority checkpoints be consolidated or temporarily closed to preserve relief depth at critical posts.

**Adaptation Trigger:** Any checkpoint staffing falling below 50% coverage due to exposure limits or responder withdrawal; any responder exceeding the 18-hour withdrawal threshold without rotation; two or more responders at the same post reporting acute respiratory symptoms within 2 hours (proposed threshold); N95 consumption rate >20% of stock per day (proposed threshold); cumulative responder fatigue assessed as 'critical' at more than 10% of deployed responders by formal fatigue-risk assessment

### 7. Communications System Resilience and Message-Delivery Effectiveness Monitoring Under Ashfall and Network Degradation
**Monitoring Tools/Platforms:**

  - IPAWS/WEA Broadcast Confirmation Log (timestamp, language versions, carrier delivery confirmation, estimated population reached)
  - Guard Signal-Team Deployment and Coverage Map (real-time location of signal units at control points and shelters; radio-network interoperability test results; any coverage gaps or outage events)
  - Highway Advisory Radio (HAR) and Variable Message Sign (VMS) Message Log (pre-recorded messages deployed on US-191, US-20, US-89, I-90; hourly updates from forward command; any message failures recorded)
  - Printed Route Card Distribution Tracker (distribution of English and five-language cards at park entrances, lodges and visitor centers; hand-out counts during evacuation)
  - Communications Outage and Restoration Log (any detected IPAWS failures, cell-tower outages, radio interference or ash-induced equipment failures; time-to-restoration tracked)

**Frequency:** Continuous communication-system monitoring from T-12h through T+72h. IPAWS/WEA broadcast confirmations logged within 30 minutes of each alert. Signal-team coverage status checked every 2 hours during peak operations (T+0 to T+36h), then every 4 hours through T+72h. HAR/VMS message updates issued hourly from forward command during evacuation (T+0 to T+24h). Any outage detected immediately (within 5 minutes) triggers escalation and restoration effort.

**Responsible Role:** Guard Signal Officer (FUCE comms section) coordinates signal-team deployment and radio-network operations; IPAWS administrator (FEMA or NPS communications) confirms broadcast delivery and documents message content; forward-command public affairs officer oversees HAR/VMS updates and route-card distribution tracking

**Adaptation Process:** If IPAWS or WEA broadcasts fail or reach <80% of target population (proposed threshold), Guard signal bridging and HAR broadcasts immediately increase messaging frequency and add satellite-phone alerts to state emergency operations centers. If a Guard signal-team's radio repeater fails due to ash clogging or power loss, the backup portable unit is immediately deployed (within 1 hour) and the outage is logged. If cell-tower failure degrades IPAWS delivery, printed route cards and HAR become the primary public channel; multilingual volunteers are activated at lodges to hand-deliver route instructions to non-English speakers. If communication restoration exceeds 2 hours at any critical post (traffic control or shelter), escalation to FUCE Operations Chief for tactical rerouting (redirecting traffic to maintain flow despite comms outage).

**Adaptation Trigger:** Any IPAWS/WEA broadcast fails or is delayed >15 minutes; estimated population reached by IPAWS <80% of target (proposed threshold); any Guard signal-team loses radio coverage at a checkpoint or shelter; cell-network outage lasting >30 minutes at any critical location; HAR or VMS message failing to display correctly or updating with delay >1 hour from forward command; printed route cards exhausted at any park entrance or lodge

### 8. Scenario Beta Interim Hub Readiness and Secondary-Stage Evacuation-Plan Execution Monitoring
**Monitoring Tools/Platforms:**

  - Interim Scenario Beta Hub List (ranked list of 5–10 hubs outside the 500 km ring: Denver, Cheyenne, etc.; capacity estimates, host-community contact confirmations)
  - Secondary-Stage Bus-Fleet and Rail-Corridor Readiness Confirmation (operators and carriers pre-contracted; standing activation clauses; vehicle count and availability confirmed)
  - Scenario Beta Second-Stage Evacuation Plan Document (written plan by Month 1 = 2026-11-14; detailing tiered execution rings, hub assignments, transport routing)
  - Host-Community MOU Signature Tracking (signed agreements with secondary hubs by Month 2 = 2026-12-14; mutual-aid commitments documented)
  - Scenario Beta Response-Cell Activation Log (upon UC issuance of Scenario Beta order, expanded cell convenes and documents ring-by-ring evacuation orders, hub-destination assignments, and contingency activations)

**Frequency:** Interim hub list issued by T+12h (Month 0 = 2026-10-14). Written secondary-stage plan completed by Month 1 (2026-11-14). MOU signatures targeted by Month 2 (2026-12-14). If Scenario Beta triggers during the 72-hour window, the expanded Response Cell holds continuous briefings (every 2 hours) documenting ring-by-ring execution and hub-occupancy status. Post-event: full-scale Scenario Beta exercise (Exercise-2 'Ring Dispersal') conducted in Month 2.5 (2026-12-29).

**Responsible Role:** FUCE Planning Chief develops interim hub list and secondary-stage plan (working with state emergency managers and FEMA Region coordinators); UC chair or designee negotiates and signs host MOUs; Scenario Beta Response Cell (expanded UC) executes ring-by-ring evacuation upon trigger; secondary hub emergency managers confirm receipt of evacuees and completion of intake and registration

**Adaptation Process:** If Scenario Beta trigger is detected at any point during the 72-hour window, the UC issues the 500 km Evacuation Order within 30 minutes. The expanded Scenario Beta Response Cell immediately activates: ring-by-ring evacuation orders are issued (0–100 km organized, 100–250 km time-banded, 250–500 km staged); buses and rail are dispatched from Bozeman and Idaho Falls primary shelters to secondary hubs; populations are assigned to specific hubs based on location and hub capacity. If a secondary hub is unable to receive assigned evacuees (e.g., due to local capacity constraints), the Response Cell reassigns the population to an alternate hub within 1 hour. If bus fleets or rail corridors are delayed, additional Guard logistics support is requested.

**Adaptation Trigger:** Interim hub list not issued by T+12h (escalates to UC for expedited planning or alternative contingency); written secondary-stage plan not completed by Month 1 (2026-11-14); any host-community MOU not signed by Month 2 (2026-12-14) (signals governance gap and extends Scenario Beta readiness risk); upon Scenario Beta trigger, any secondary hub reports inability to receive assigned population within 2 hours of the evacuation order; bus-fleet or rail-corridor dispatch delayed >2 hours from the evacuation order

### 9. Multi-State Governance Formalization and Post-Event Hardening Monitoring (Months 1–3 = 2026-11-14 to 2027-01-14)
**Monitoring Tools/Platforms:**

  - MOU Signature Tracker (dates and status of signed agreements with MT, WY, ID governors; FEMA Region 10; regional utilities; Scenario Beta secondary hubs)
  - After-Action Report Development Schedule (AAR-1 at Month 1 = 2026-11-14; AAR-2 at Month 2 = 2026-12-14; AAR-3 at Month 3 = 2027-01-14; drafts tracked through review and distribution)
  - Full-Scale Exercise Calendar (Exercise-1 'Cascade Boundary' Month 2 = 2026-12-14; Exercise-2 'Ring Dispersal' Month 2.5 = 2026-12-29; Exercise-3 'Integrated Response' Month 3 = 2027-01-14; plus six smaller operational exercises)
  - UC Weekly Coordination Call Schedule (Months 1–3 = 2026-11-14 to 2027-01-14; attendance and agenda topics documented)
  - Governance Improvements Tracking (recommendations from 72-hour response and exercises; implementation status and completion dates)

**Frequency:** Weekly UC coordination calls during Months 1–3 (2026-11-14 to 2027-01-14). MOU signature targets: Month 1 (2026-11-14) for governors and Region 10; Month 2 (2026-12-14) for utilities and secondary hubs. AAR publication schedule: AAR-1 by end of Month 1 (2026-11-14); AAR-2 by end of Month 2 (2026-12-14); AAR-3 (comprehensive) by end of Month 3 (2027-01-14). Full-scale exercises scheduled in Weeks 1, 3 and 4 of Months 2, 2.5 and 3 (2026-12-14, 2026-12-29, 2027-01-14).

**Responsible Role:** FEMA Region VIII IC (UC chair) or designee coordinates MOU negotiations and signature scheduling; FEMA and NPS designate AAR working groups and publication leads; FUCE Operations Chief serves as exercise director for all three full-scale exercises; Hardening & Post-Event Review steering committee (established at Month 1 = 2026-11-14 Week 1) oversees improvements and exercise planning

**Adaptation Process:** If any MOU signature target is missed (Month 1 or 2 = 2026-11-14 or 2026-12-14), UC escalates to state governors, FEMA Region 10 or utility leadership for expedited signing; any persistent gap beyond 2 weeks flags a governance risk that is documented in AAR for future planning. If AAR development is delayed, interim field-observer summaries are published to maintain transparency; final reports are published even if late, with explanation of delays. If a full-scale exercise reveals critical governance gaps (e.g., Authority Cell unable to mediate boundary disputes, Scenario Beta hub unable to receive populations), the UC convenes an emergency remediation meeting and adjusts governance protocols before the next exercise. All improvements identified are tracked in the Governance Improvements Log with completion target dates (typically within 30 days of identification).

**Adaptation Trigger:** Any MOU not signed by 2 weeks past target deadline (Month 1 = 2026-11-14 Week 2 for governors/Region 10; Month 2 = 2026-12-14 Week 2 for utilities/hubs); AAR publication delayed >2 weeks past target; any full-scale exercise revealing a 'critical' governance gap (inability to execute a core function); any UC weekly call attendance falling below 50% of required members (signals disengagement); post-event recommendations not assigned to a responsible party within 10 days of identification

# Governance Extra

## Governance Validation Checks

1. Completeness Confirmation: All six core governance components are generated and present: (1) internal governance bodies (4 standing bodies + 5 specialized advisory cells) established; (2) implementation plan with 24 sequential steps from pre-event through Month 3 (2027-01-14) hardening; (3) decision-escalation matrix with explicit approval processes and tie-breakers for 5 critical decisions; (4) monitoring-progress plan with 6 continuous monitoring approaches and adaptation triggers; (5) audit framework and transparency measures defined in Phase 1 context; (6) project sponsor authority and legal basis (FEMA RA and NPS Director joint decision memo). No major component is missing.
2. Internal Consistency Check: The four-body standing governance (UC at Denver, FUCE at Livingston, Responder Health Board, Authority Cell) nests correctly into the implementation plan's T+0 activation sequence (Steps 8–12 establish each body in order). Decision escalation aligns with body authority: UC issues strategic orders (Scenario Beta, zone expansion), FUCE executes operational reroutes within pre-authorized thresholds, advisory bodies (Escalation, Shelter, Authority) provide binding or advisory recommendations to appropriate levels. The monitoring-progress plan's adaptation triggers feed back into decision escalation (e.g., PM10 >100 ug/m³ escalates from Shelter Panel to FUCE Operations Chief to UC within defined timelines). Cadence alignment is consistent: UC hourly briefings at T+0, T+2, T+6, T+12, T+24, T+36, T+48, T+60, T+72 match the Phase 1 and Phase 2 gate assessments at T+6 and T+24. No logical conflicts detected between body authorities or decision timelines.
3. Clarity of Roles and Conflict-of-Interest Gaps: Responsibilities of the six standing bodies and five advisory cells are clearly defined in Phase 2. However, one significant role ambiguity exists: the Project Sponsor (FEMA Regional Administrator and NPS Director) roles are mentioned in the implementation plan (Steps 1–2) as issuing the foundational decision memo, but their ongoing authority, veto rights, or escalation role during the 72-hour window is not explicitly stated. Are they voting members of the UC, or do they only set pre-event policy? Additionally, the Boundary Coordination Officer role is critical but under-staffed: the documents specify one BCO at the forward element coordinating three state on-scene commanders and the NPS IC, with potential for three simultaneous boundary disputes (West, North, East gates) that one officer cannot mediate within 30 minutes (proposed threshold). Recommendation: explicitly define Project Sponsor escalation authority (e.g., constitutional/legal challenges to evacuation orders); clarify whether BCO should be supported by two deputies (one per state region) or whether a standing three-way conference line protocol allows parallel mediation.
4. Process Depth and Operational Clarity Gaps: (a) Conflict-of-interest and corruption prevention: Phase 1 audit details identify 6 corruption risks and 13 audit procedures, but the governance bodies (especially UC and FUCE) have no explicit conflict-of-interest disclosure requirement or recusal protocol. Recommendation: require all UC and FUCE members to disclose financial interests in shelter vendors, water/N95 suppliers, or secondary-hub communities at T+0 and to recuse themselves from decisions affecting those vendors. (b) Whistleblower and incident-report protocols: the monitoring-progress plan references fatigue hotlines and responder-health logs but does not define a formal whistleblower or ethics hotline for reporting abuse, vendor fraud, or governance failures during the 72-hour window. Recommendation: establish a confidential hotline (staffed 24/7 during the response) for reporting responder exposure violations, supply-diversion, unauthorized entries or other compliance breaches; results escalate to a designated compliance officer outside the incident command chain. (c) Threshold clarity: the decision-escalation matrix and monitoring plan reference numerous quantitative thresholds (45-minute blockage trigger, 50/100 ug/m³ PM10 triggers, 20% N95 consumption rate, <50% checkpoint staffing) but several thresholds lack justification or sensitivity analysis. Recommendation: document the derivation of each threshold (e.g., 45 minutes = time to attempt tow clearance + time to divert overflow without saturation) and conduct pre-event sensitivity analysis (what happens if the threshold is ±20%?) to ensure thresholds are operationally defensible under stress.
5. Specific Gaps Requiring Further Detail: (a) Scenario Beta Secondary-Stage Plan Maturity: The implementation plan (Steps 31–32) references an interim ranked hub list issued by T+12 hours and a written secondary-stage plan completed by Month 1 (2026-11-14), but no details exist on how a 5–10 hub list is generated, evaluated or prioritized during the T+0 to T+12 timeframe. The plan names Denver and Cheyenne as Beta hubs but does not verify their distance from the 500 km radius or their shelter/transportation/supply capacity. Recommendation: pre-develop a detailed Scenario Beta Secondary-Stage Evacuation Plan (before Month 0 = 2026-10-14) listing 8–12 candidate hubs outside the 500 km ring (with verified distance, shelter capacity, bus-fleet access, and host-community preliminary agreement); publish this plan to the UC, states and media at T+0 so the T+12 interim list is merely a formal endorsement, not a crash generation. (b) Responder N95 and Staffing Depth Specification: The governance documents assume 100–150 NPS rangers (estimate) and a 1.5 relief ratio, yielding approximately 67–100 concurrent traffic-control positions. However, no detailed staffing plan exists mapping specific rangers and Guard units to each of the 5–10 traffic-control checkpoints, nor is there a pre-calculated responder N95 requirement (separate from the 100,000 civilian stock) documented. Recommendation: before Month 0 (2026-10-14), pre-identify each assigned ranger and state patrol officer by name and post; calculate responder N95 requirement (estimated 2–3 masks per person per shift; 100–150 responders × 12–18 hours average shift ÷ 6-hour work limit = ~200–250 masks per day × 3 days = 600–750 total responder masks minimum); confirm separate pre-staging of this stock outside the civilian 100,000 allotment. (c) Ashfall Forecasting and Shelter Backup Site Adequacy: The plan specifies ranked backup shelter sites 50+ km upwind (proposed threshold) of each primary site, but does not verify that 8–10 suitable backup sites exist with adequate capacity, HVAC, registration infrastructure and accessibility to buses. Recommendation: conduct a pre-event survey (by Month -1, before October 2026) of all candidate backup sites in Montana, Wyoming and Idaho (schools, arenas, fairgrounds with 500+ capacity) and rank them by distance/direction from each primary shelter; document HVAC specifications, generator/fuel access and bus-arrival infrastructure; confirm owners/operators are briefed and pre-authorize emergency occupancy. (d) Water and Fuel Convoy Logistics Detail: The plan targets water dispatch from Salt Lake City by T+12 h and arrival by T+24 h (or use forward depots as fallback), but does not specify the number of trucks, loading logistics at Salt Lake City, route selection (I-15 northbound only, or alternates via US-89 or US-191?), fuel for the convoy itself, or communication protocols if the convoy encounters ashfall and must divert. Recommendation: execute pre-event detailed water-logistics operations plan (before Month 0 = 2026-10-14): identify 2–3 water-supplier sites in Salt Lake City with bulk-truck loading capacity; confirm 20–30 water trucks (holding ~50,000 liters each) can be assembled and fueled within 12 hours; map primary and alternate routes (I-15, US-89/US-191) with fuel stops; establish convoy-escort communication protocol (National Guard liaison in the lead and trail vehicles, satellite phone link to forward command).
6. Integration and Decision-Flow Alignment Gaps: (a) Real-Time COP Dashboard Specification: The implementation plan repeatedly references a 'shared common operating picture' digital dashboard that is 'updated hourly' and displayed at the UC and FUCE, but no specification exists for what data fields must be displayed, data-update frequency for each field, or system reliability/backup (what happens if the COP server crashes?). Recommendation: develop a detailed COP Data Dictionary (by Month -1) specifying: cumulative exit counts (by gate and time), queue lengths (at each checkpoint), ashfall PM10 (at each shelter, updated hourly), water/fuel/N95 inventory (at each shelter, updated every 4 hours), responder staffing (by post, updated every 2 hours), USGS eruption indicators (updated hourly with margin-to-trigger visualization), communication outages (real-time log), any active reroutes or shelter relocations (current status). Implement redundant data feeds (primary database + satellite backup; manual entry fallback if network fails). (b) Authority Transfer Checkpoint Definition: The implementation plan states NPS authority transfers 'at the park boundary' (West, North, East Entrances), but does not define the exact roadside location (e.g., mile marker X on US-89 north of Gardiner vs. the ranger station vs. the county line). Recommendation: before Month 0 (2026-10-14), conduct field surveys with MT, WY and ID highway patrols to identify a specific transferpoint at each of the three exit corridors (with GPS coordinates, landmark description and signage location); document the exact point in the written Authority Transfer Protocol so state and NPS on-scene commanders both understand where NPS care ends and state custody begins. (c) Escalation Path Endpoints Ambiguity: The decision-escalation matrix specifies that 'constitutional or legal challenges to evacuation orders' escalate to 'the U.S. Attorney's Office (Colorado District) and White House Chief of Staff,' but does not identify who makes the call to White House (FEMA Regional Administrator? UC Chair?), what the expected response time is, or who has authority to override the UC's order if legal counsel says it is unconstitutional. Recommendation: clarify the escalation chain: UC Chair notifies FEMA Regional Administrator of any legal challenge; Regional Administrator consults FEMA Office of General Counsel and White House Legal Counsel (via Situation Room); White House National Security Advisor or Chief of Staff makes final authority determination and notifies the FEMA Administrator (not the UC directly) to issue revised orders or stand down.

## Tough Questions

1. What is the current scientific confidence interval (±km) for the modeled ashfall footprint under a VEI-6 eruption scenario at Yellowstone, given the lack of direct observational data on historic Yellowstone ashfall composition and settling rates? If the actual ashfall extent exceeds the modeled 100 km radius by 20–50 km, will the three pre-staged backup shelter sites remain outside the ashfall zone, or will all primary and backup shelters be threatened simultaneously, forcing a third-stage relocation without known destinations?
2. Have the 100–150 NPS rangers and state patrol officers assigned to traffic-control checkpoints been explicitly identified by name and post, and does a pre-event dry-run or tabletop exercise confirm that each officer understands his or her assigned checkpoint, shift length (6 hours, proposed threshold), relief rotation protocol and the 18-hour withdrawal trigger (proposed threshold)? If not, how will responder confusion or failure to understand exposure limits during the T+0 activation cascade be prevented?
3. What is the pre-authorized response time and decision process if the Boundary Coordination Officer at Livingston receives simultaneous reroute-authority disputes from the MT, WY and ID state on-scene commanders at T+3 hours (peak evacuation), and the three disputes cannot be mediated within the 30-minute window (proposed threshold)? Does the BCO have authority to unilaterally decide all three, or does escalation to the FUCE Operations Chief introduce a 1–2 hour delay that compounds the blockage-diversion decision latency?
4. If Scenario Beta is triggered at T+36 hours (halfway through the 72-hour window) and the UC issues a 500 km evacuation order, how many additional evacuees are estimated to be in that expanded ring (100–250 km time-banded, 250–500 km staged)? Have the 5–10 secondary hub communities (Denver, Cheyenne, etc.) provided pre-signed capacity commitments and committed bus-fleet and medical resources, or is their participation still contingent on Month 1 (2026-11-14) MOU negotiation? If commitments are contingent, what is the fallback if a secondary hub refuses to accept evacuees?
5. The plan pre-stages 100,000 N95 respirators (user constraint) for civilians and assumes separate responder N95 stocks, but has the actual responder N95 requirement been calculated by role (100–150 rangers × 3 masks/person/shift × how many shifts each works) and confirmed to be available and pre-positioned at T-48 hours? If responder mask consumption exceeds expectations due to heavier ashfall (masks clog faster), what is the resupply protocol, and where is the supplemental responder N95 reserve staged?
6. The Authority & Jurisdictional Coordination Cell resolves NPS-to-state disputes at the park boundary, but if a state emergency manager or governor refuses to enforce a UC-issued evacuation order or issues a conflicting shelter-in-place instruction, what is the enforcement mechanism? Does the UC have authority to federalize the state National Guard under Stafford Act emergency declaration, and has that authority been pre-coordinated with the three governors and documented in the signed MOUs (due Month 1 = 2026-11-14)?
7. Has a full-scale integrated-response exercise (Exercise-3, scheduled Month 3 = 2027-01-14) actually been completed and published as post-event proof that the governance structure functions under realistic 72-hour-compression conditions, or is this exercise still planned and contingent on pre-event preparation and funding? If the exercise has not been completed by the time the eruption probability window activates (Month 0 = 2026-10-14), the governance structure remains untested and operationally at risk.

## Summary

The governance framework establishes a pre-authorized, time-compressed multi-state evacuation response centered on a Unified Command at FEMA Region VIII RRCC Denver with a forward operational element at Livingston, MT. Five specialized advisory bodies (Escalation Cell, Forward Element, Responder Health Board, Authority Cell, and Shelter Siting Panel) execute real-time decisions on contraflow traffic, eruption escalation, ashfall monitoring, and supply logistics within concrete trigger matrices and decision thresholds. The implementation plan sequences governance activation from T+0 through T+72 hours of continuous operations, transitioning to hardening and post-event review during Months 1–3 (2026-11-14 to 2027-01-14). Core strengths include explicit pre-authorized decision rules, rapid escalation protocols, and real-time monitoring dashboards that reduce command latency. Three critical unresolved gaps—the absence of a detailed Scenario Beta secondary-stage shelter and logistics plan, undefined responder staffing reserves and N95 protection counts, and static (rather than adaptive) ashfall shelter siting—create cascading failure risks if triggered during the 72-hour window. The governance structure is execution-credible for the 35,800 Zone Zero evacuation but depends heavily on pre-event hardening during Months 1–3 (2026-11-14 to 2027-01-14) to close Scenario Beta and supply-chain readiness gaps before the eruption probability window activates.