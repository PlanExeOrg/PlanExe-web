This plan involves money.

## Currencies

- **USD:** All financial transactions occur within the United States across Montana, Wyoming, Idaho and Colorado. Federal agencies (FEMA, NPS, USGS), state governments, National Guard, hospitals, utilities and private contractors conduct all procurement, fuel convoys, personnel deployment and shelter operations in US dollars. No currency exchange or international transactions are involved.

**Primary currency:** USD

**Currency strategy:** All transactions use USD with no currency exchange or foreign exchange risk. Budgeting and reporting occur in USD across federal (FEMA Region VIII and X), state (Montana, Wyoming, Idaho) and local agencies. Cost tracking for evacuation logistics, fuel convoys, medical supplies, communications equipment, generator fuel, shelter operations and personnel reimbursement is conducted in USD through standard US government accounting and reimbursement procedures.