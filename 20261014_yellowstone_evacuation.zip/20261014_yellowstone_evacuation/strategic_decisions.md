## Primary Decisions
The vital few decisions that have the most impact.


Critical levers (egress corridors, escalation trigger, command handoff) govern the central tensions: throughput versus staffing, speed versus over-evacuation, and unified authority versus fixed boundaries. High levers (communications, shelter siting, life-support supply, responder limits) set the capacity and endurance that these decisions depend on. Missing dimensions: explicit second-stage destinations for a 500 km Scenario Beta evacuation, and responder respirator and personnel counts.

### Decision 1: Egress Corridor Allocation and Contraflow Architecture
**Lever ID:** `9aa4c682-17a1-42d8-a2af-8f62ac4d54b2`

**The Core Decision:** Defines which park exits carry the roughly 35,000 visitors and 800 staff, how contraflow is staged, and where traffic control, tow and rescue assets sit. Success metrics are corridor throughput in vehicles per hour, clearance of the interior within the T+6 window, minimum blockage duration at chokepoints, and no vehicle crossing the interior to reach another gate.

**Why It Matters:** Determines how the roughly 35,000 visitors and 800 staff are split across the surviving exits once the South Entrance is landslide-blocked. Concentrating flow on US-191/US-20 at West Yellowstone and US-89 at Gardiner is simple to run, but it loads a few two-lane chokepoints; opening additional exits spreads load but adds ranger and signage demand.

**Strategic Choices:**

1. Funnel all outbound traffic through two contraflow corridors, US-20/US-191 from West Yellowstone and US-89 from Gardiner to I-90 at Livingston, with ranger-staffed traffic control points at every junction.
2. Split outbound flow across three gates by adding the East Entrance toward Cody on US-14/16/20, assigning each park district to a fixed exit so no vehicle crosses the interior to reach another gate.
3. Suspend private-vehicle exit lanes at the Madison and Mammoth staging lots and load visitors onto concessioner buses and park fleet vehicles, so one contraflow lane carries more people per vehicle.

**Trade-Off / Risk:** Contraflow on mountain two-lane roads has no shoulder or recovery margin, so a single breakdown or rockfall near Gallatin Canyon or Gardiner can halt the entire corridor; the plan needs tow and rescue assets pre-placed at each chokepoint.

**Strategic Connections:**

**Synergy:** Amplifies Landslide Clearance and Hydrothermal Hazard Road Engineering by telling crews which road segments matter most, and relies on Communications Continuity Stack Under Ash and Tremor to deliver route assignments consistently to drivers at each junction.

**Conflict:** Competes with Responder Exposure Limits and Relief Rotation Regime for ranger and patrol staffing at control points, and with Visitor Headcount Reconciliation and Backcountry Sweep Protocol, which pulls rangers from traffic duty into interior sweeps.

**Justification:** *Critical*, Central hub: it governs the Phase 1 T+6 clearance of roughly 35,000 visitors and conflicts with or feeds nearly every other lever (staffing, sweeps, convoys, hospital transport, road engineering). It controls the core throughput versus staffing trade-off.

### Decision 2: Escalation Trigger and Evacuation Release Doctrine
**Lever ID:** `bd25cabe-83c3-4a75-a57b-fda21488eb09`

**The Core Decision:** Fixes which USGS indicators, such as uplift rate, tremor magnitude and gas flux, trigger zone expansion and who may issue the order. It governs the timing of Zone One and Scenario Beta decisions during the 72-hour window. Success metrics are decision latency, false-trigger rate, and the time from trigger to the first outbound movement.

**Why It Matters:** Sets which USGS signals, such as uplift rate, tremor magnitude and gas flux, automatically push the evacuation from Zone Zero to Zone One and, in Scenario Beta, to a 500 km radius. A pre-authorized trigger removes debate during the 72-hour window, but it risks costly over-evacuation if the signals mislead; a discretionary one is slower and exposes decision makers to hindsight blame.

**Strategic Choices:**

1. Pre-authorize a written, threshold-based trigger matrix tying specific USGS indicators to automatic zone expansion, with the VEI-7 500 km order issued by the Unified Command without further approval.
2. Keep a standing volcanologist-and-governor decision cell that meets at fixed intervals and recommends expansion, retaining human judgment but accepting added delay at each decision point.
3. Begin a quiet precautionary outer-ring evacuation of vulnerable groups, such as hospitals, care homes and families with children, beyond 100 km before any VEI-7 indicator appears, so a later order has fewer people to move.

**Trade-Off / Risk:** A 500 km radius would reach multiple states and millions of people, far beyond the shelter and road capacity in this plan, so the trigger is meaningless without a stated plan for where those evacuees actually go.

**Strategic Connections:**

**Synergy:** Enables Refugee Intake and Shelter Siting Strategy and Exclusion Perimeter Posture and Re-Entry Access Control by giving them an advance signal to stage sites and perimeters, and supports Command Structure and Jurisdictional Handoff Model with pre-agreed authority.

**Conflict:** Early or automatic expansion strains Refugee Intake and Shelter Siting Strategy and Hospital Surge Dispersal and Respiratory Patient Routing, which lack capacity for a 500 km radius, and may fuel Shadow Evacuation Suppression and Public Compliance Dynamics if triggers prove false.

**Justification:** *Critical*, Controls the speed versus over-evacuation trade-off across the 72-hour window and the Scenario Beta 500 km decision. It drives staging for shelters, perimeters and command authority, and strains shelter and hospital capacity if triggered.

### Decision 3: Command Structure and Jurisdictional Handoff Model
**Lever ID:** `c5f01e05-5b98-45c5-a1e2-b13bf9b7e0be`

**The Core Decision:** Sets who commands the roadway, shelters and resource requests as evacuees move from NPS land into Montana, Wyoming and Idaho, and how the Denver RRCC relates to any forward element. Success is judged by the absence of authority gaps at the boundary, clear single-point accountability, and fast resolution of cross-state mutual aid and FEMA Region 8/10 coordination.

**Why It Matters:** Decides where authority sits as evacuees cross from NPS-managed federal land into Montana, Wyoming and Idaho. A fixed boundary handoff is easy to explain, but traffic does not stop at the line, so gaps appear where the road is still moving; shared command avoids gaps but blurs accountability.

**Strategic Choices:**

1. Transfer authority at the park boundary under a written protocol, with the NPS incident commander handing traffic and care responsibility to each state's designated commander at defined checkpoints.
2. Run a single Unified Command with a rotating deputy from each state and NPS, so authority over the roadway is joint from the interior through the first gateway town.
3. Place a forward Unified Command element in Bozeman or Livingston alongside the Denver RRCC, giving the incident commander direct sight of the corridors while Denver handles federal resource requests.

**Trade-Off / Risk:** Denver RRCC serves FEMA Region VIII, which covers Montana and Wyoming, but Idaho falls under Region 10, and Wyoming Highway Patrol working on Montana roads needs state-to-state mutual aid, so the structure must resolve that early.

**Strategic Connections:**

**Synergy:** Provides the authority base for Escalation Trigger and Evacuation Release Doctrine and Exclusion Perimeter Posture and Re-Entry Access Control, since clear command lets zone expansions and perimeter enforcement be ordered without jurisdictional dispute.

**Conflict:** A rigid boundary handoff clashes with Egress Corridor Allocation and Contraflow Architecture, since moving traffic crosses the line mid-corridor; shared command can slow the decisions Escalation Trigger and Evacuation Release Doctrine tries to speed up.

**Justification:** *Critical*, Foundational authority base for zone expansion, perimeter enforcement and corridor operations. It resolves NPS-to-state handoff, Denver RRCC Region 8/10 gaps and mutual aid, and directly conflicts with moving traffic and fast trigger decisions.

### Decision 4: Communications Continuity Stack Under Ash and Tremor
**Lever ID:** `14959fd9-8062-4934-9362-569f3e381a10`

**The Core Decision:** Establishes the layered channels that carry alerts, route instructions and responder coordination when cell towers fail: IPAWS, radio, satellite, signs and printed materials. Success metrics include the share of drivers reached with consistent instructions, responder interoperability across NPS, state and Guard nets, and recovery time for degraded links under ashfall and tremor.

**Why It Matters:** Determines how warnings and commands reach drivers, responders and shelters once cell towers fail. IPAWS reaches phones and broadcasters only while those networks stay up, so radio and satellite layers carry the load; each added layer needs equipment, trained operators and frequency coordination before the event.

**Strategic Choices:**

1. Rely on IPAWS, Wireless Emergency Alerts and NOAA Weather Radio as the primary public channel, with National Guard signal units bridging responder radios between agencies at the gateway towns.
2. Deploy portable repeaters and satellite terminals at every contraflow control point and shelter, and broadcast route instructions over highway advisory radio and variable message signs along US-191 and I-90.
3. Hand out pre-programmed battery radios and printed route cards at park entrances and visitor centers, so visitors can still follow instructions after the digital network has collapsed.

**Trade-Off / Risk:** Ash degrades radio propagation and clogs equipment, and a warning that arrives after a driver has committed to the wrong route is worse than none, so message discipline matters as much as redundant hardware.

**Strategic Connections:**

**Synergy:** Amplifies International Visitor, Language, and Access-Needs Notification Pathways by supplying the channels for multilingual alerts, and Shadow Evacuation Suppression and Public Compliance Dynamics by enabling consistent, credible messages that reduce uncontrolled departures.

**Conflict:** Heavy hardware layers compete with Ashfall Life-Support Supply and Priority Allocation for transport and generator fuel, and with Responder Exposure Limits and Relief Rotation Regime because more equipment needs trained operators in ash-exposed locations.

**Justification:** *High*, Enabling layer that delivers route assignments, multilingual alerts and consistent messaging, linking egress, compliance and notification levers. Competes with life-support supply and responder staffing for fuel and operators, so a major trade-off.

### Decision 5: Refugee Intake and Shelter Siting Strategy
**Lever ID:** `57ab47b3-f2b2-42be-b584-9312a07de587`

**The Core Decision:** Chooses where evacuees are received, registered and sheltered, and whether sites are destinations or transit hubs given uncertain wind and plume direction. Success metrics are intake capacity per hour, share of evacuees outside the modeled ash footprint, reunification time, and readiness of second-stage transport if Scenario Beta occurs.

**Why It Matters:** Decides where evacuees are received and whether reception sites are final destinations or transit hubs. Fixed sites at Bozeman and Idaho Falls are known and can be stocked, but both could fall in an ash plume depending on wind, and ashfall would trap people there; wind-adaptive siting protects them but complicates prior stocking and public messaging.

**Strategic Choices:**

1. Operate Bozeman and Idaho Falls as fixed reception centers, each with medical triage, registration and family reunification, and stock them ahead of the first arrivals.
2. Treat Bozeman and Idaho Falls as short-stay processing points and move evacuees onward by bus and rail to distant hubs such as Billings, Boise or Salt Lake City outside the modeled ash footprint.
3. Select final shelter locations at T+6 hours from the forecast wind and plume model, keeping a ranked list of pre-surveyed schools and arenas on every side of the park.

**Trade-Off / Risk:** Idaho Falls and Bozeman sit near the Zone One boundary, so treating them as safe is an assumption that Scenario Beta would break; any plan that keeps evacuees there needs a second-stage move ready.

**Strategic Connections:**

**Synergy:** Works with Hospital Surge Dispersal and Respiratory Patient Routing to colocate triage and route respiratory cases, and with Ashfall Life-Support Supply and Priority Allocation by concentrating water and N95 stocks at known intake sites.

**Conflict:** Wind-adaptive or onward-move siting conflicts with Ashfall Life-Support Supply and Priority Allocation, which prefers prestocked fixed sites, and strains Escalation Trigger and Evacuation Release Doctrine, whose 500 km radius exceeds any shelter capacity.

**Justification:** *High*, Determines where evacuees end up and whether sites survive an ash plume or Scenario Beta. Connects hospital routing, supply stocking and escalation triggers, with a fixed-versus-adaptive siting trade-off.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Ashfall Life-Support Supply and Priority Allocation
**Lever ID:** `3fc1002b-3f87-4cda-bfe8-3b180e0e3945`

**The Core Decision:** Defines the sourcing, staging and tiered rationing of water, respirators and generator fuel so critical facilities stay functional through ashfall. Success metrics include hours-to-delivery at hospitals and shelters, tier-one fuel days of supply, respirator replacement cycles beyond the initial 100,000 (user constraint), and the share of open reservoirs isolated before ash arrives.

**Why It Matters:** Controls how water, N95 respirators and generator fuel reach hospitals, shelters and communications centers while roads are congested or ash-covered. Pulling stock from Salt Lake City works only while the I-15 and US-20 routes stay open; forward staging shortens delivery time but ties up supplies inside areas that may be lost.

**Strategic Choices:**

1. Dispatch bottled-water, respirator and fuel convoys from Salt Lake City distribution centers on a fixed schedule, using National Guard escorts and reserved lanes alongside the evacuation.
2. Pre-position water, respirators and fuel tankers at forward depots in Bozeman, Billings and Idaho Falls before the eruption window, accepting that some stock may be stranded if the plume shifts.
3. Rank facilities into priority tiers, giving fuel and water first to hospitals, communications centers and shelter kitchens, and have utilities and water districts isolate open reservoirs ahead of ashfall.

**Trade-Off / Risk:** A 100,000-respirator requirement (user constraint) is small compared with the population a VEI-6 plume could affect, and N95 masks clog quickly in heavy ash, so quantities and replacement cycles need explicit planning.

**Strategic Connections:**

**Synergy:** Amplifies Hospital Surge Dispersal and Respiratory Patient Routing by keeping receiving hospitals fueled and supplied, and strengthens Communications Continuity Stack Under Ash and Tremor by guaranteeing generator fuel to comms centers.

**Conflict:** Competes with Egress Corridor Allocation and Contraflow Architecture for road capacity, since inbound convoys need lanes during outbound evacuation; forward depots also compete with Refugee Intake and Shelter Siting Strategy for warehouse and site space.

**Justification:** *High*, Sustains hospitals, shelters and comms centers through ashfall via water, respirators and fuel. It is a hub supporting hospital routing and communications, but competes with evacuation traffic for road capacity.

### Decision 7: Visitor Headcount Reconciliation and Backcountry Sweep Protocol
**Lever ID:** `a69bd951-1e7e-4b32-8e39-b35abc2acba6`

**The Core Decision:** Establishes the method for estimating who remains inside Zone Zero and certifying sectors as cleared. It combines gate, lodging and permit data with physical sweeps of trailheads and thermal basins. Success is measured by the gap between estimated and confirmed occupants, sector-clearance time, and the number of missing-person reports resolved before the clearance declaration.

**Why It Matters:** Determines how the response knows who is still inside the park and when Zone Zero can be declared clear. A rigorous accountability method slows the final evacuation hours and ties up rangers, while a loose one risks leaving backcountry hikers, campers and concession staff unaccounted for when the eruption escalates.

**Strategic Choices:**

1. Run a gate-and-lodging manifest reconciliation that compares entrance counts, lodge registers and campground permits against checkpoint exit counts to produce a running estimate of remaining occupants.
2. Deploy ranger-led sweep teams with helicopter support along trailheads, backcountry permit sites and thermal basins, clearing them sector by sector and marking cleared areas on a shared common operating picture.
3. Issue every exiting vehicle a dated windshield tag and collect phone-based check-ins at the exit checkpoints, so that reunification data and exit counts are produced together and missing-person reports can be matched directly.

**Trade-Off / Risk:** Accountability data drawn from permits and gate counts is only as good as the walk-in, day-use and staff population it can see; the sweep effort competes directly with evacuation traffic control for the same ranger hours.

**Strategic Connections:**

**Synergy:** Feeds Escalation Trigger and Evacuation Release Doctrine with a defensible clearance status, and supports Command Structure and Jurisdictional Handoff Model by providing a shared common operating picture at the boundary transfer.

**Conflict:** Draws on the same ranger hours as Egress Corridor Allocation and Contraflow Architecture, and prolonged sweeps conflict with Responder Exposure Limits and Relief Rotation Regime by keeping teams in the hazard zone as eruption odds climb.

**Justification:** *Medium*, Governs clearance certification and the last-person-out risk, competing for ranger hours with egress. Valuable but operational; its trade-offs sit mostly within the egress and exposure levers.

### Decision 8: Shadow Evacuation Suppression and Public Compliance Dynamics
**Lever ID:** `e930bb1a-302c-4f76-b378-fe305c262ac2`

**The Core Decision:** Manages the behavior of unordered residents in Bozeman, Billings, Idaho Falls and similar outer communities so spontaneous flight does not saturate evacuation corridors, fuel supplies and lodging. Success is judged by measured corridor throughput, the share of outer-zone residents following shelter or time-band instructions, and the stability of public trust in official messaging.

**Why It Matters:** Shapes how people outside the ordered zones behave, because large numbers of unordered residents in Bozeman, Billings and Idaho Falls are likely to flee on their own and fill the same routes. Discouraging them protects corridor capacity but may erode trust, while tolerating them raises the load on fuel, lodging and roads.

**Strategic Choices:**

1. Issue geographically targeted IPAWS messages that tell outer-zone residents to shelter in place, supported by local officials who repeat the same instruction on trusted radio channels.
2. Stage outer-zone residents with a scheduled, time-banded departure plan that assigns each community a release window, spreading the load on the corridors instead of forbidding departure.
3. Open a visible voluntary-departure route on secondary roads such as state highways away from the main contraflow corridors, deliberately channeling shadow evacuees away from the primary evacuation routes.

**Trade-Off / Risk:** Shelter-in-place messaging works only if residents believe the modeled ash risk is low; time-banded departures need disciplined enforcement, and secondary routes may lack the shoulders and fuel stops to handle the surge.

**Strategic Connections:**

**Synergy:** Protects Egress Corridor Allocation and Contraflow Architecture by keeping the corridors usable for ordered evacuees, and relies on International Visitor, Language, and Access-Needs Notification Pathways to deliver consistent instructions to all audiences.

**Conflict:** Tension with Escalation Trigger and Evacuation Release Doctrine: shelter-in-place messaging can lose credibility if the zone later expands to 500km, and it may strain Refugee Intake and Shelter Siting Strategy if compliance collapses.

**Justification:** *Medium*, Protects corridor capacity from unordered flight and is tied to messaging credibility and escalation. Important for optimization, but largely depends on the communications and trigger levers rather than setting core strategy.

### Decision 9: Hospital Surge Dispersal and Respiratory Patient Routing
**Lever ID:** `977c56ab-38a5-4aa2-8b2c-5b99bef4edc1`

**The Core Decision:** Allocates mass respiratory, trauma and chronic-care patients across the regional hospital network and field sites so that no facility fails under load. It covers receiving-hospital designation, tracking, early transfers of fragile patients and on-site treatment. Success is measured by bed occupancy balance, transport times, ambulance availability and avoidance of preventable respiratory deaths.

**Why It Matters:** Decides where mass respiratory distress, trauma and chronic-disease patients are sent so that no single facility is overwhelmed. Distributing patients widely protects the closest hospitals, but extends transport times and strains ambulance supply, and ash may restrict the very ground routes that dispersal relies upon.

**Strategic Choices:**

1. Designate a primary receiving hospital per corridor and use a central patient-tracking desk at the RRCC to direct ambulance traffic, keeping loads balanced across facilities in real time.
2. Pre-position field treatment tents and rotating clinician teams at the shelter sites so that mild and moderate respiratory cases are managed on site, reserving hospital beds for the severe cases.
3. Arrange early transfer of hospitalized and dialysis-dependent patients out of Zone One facilities before ashfall to hospitals in Salt Lake City and Billings, using ground ambulances and military airlift windows.

**Trade-Off / Risk:** Pre-emptive patient transfers free beds but expose fragile patients to long transport during chaos; field treatment sites depend on clinician availability that the same regional hospitals will be competing to retain.

**Strategic Connections:**

**Synergy:** Works with Refugee Intake and Shelter Siting Strategy, since treatment tents at shelters offload hospitals, and depends on Ashfall Life-Support Supply and Priority Allocation to keep receiving facilities supplied with fuel, water and respirators.

**Conflict:** Patient transport competes with Egress Corridor Allocation and Contraflow Architecture for road space and ambulances, and field clinician teams compete with Responder Exposure Limits and Relief Rotation Regime for scarce medical staff and rest cycles.

**Justification:** *Medium*, Handles the downstream medical load and depends on supply and shelter siting upstream. Meaningful for outcomes, but it is a consumer of other levers' decisions rather than a hub shaping them.

### Decision 10: Exclusion Perimeter Posture and Re-Entry Access Control
**Lever ID:** `531c990c-0693-4b04-aa06-db58fde56eba`

**The Core Decision:** Sets how tightly the evacuated area is sealed and who may enter, balancing anti-looting protection and responder safety against personnel demands and public resistance. It covers checkpoint design, credentialing, patrol methods and any escorted-return windows. Success includes zero unauthorized entries into the hazard area, looting incidents, personnel hours consumed, and avoidance of exposure-related casualties during returns.

**Why It Matters:** Sets how strictly the evacuated zone is sealed, who is allowed back inside, and how looting is deterred across empty towns. A hard perimeter reduces theft and protects returning responders, but diverts National Guard personnel from logistics and may provoke confrontations with residents seeking to retrieve family, pets or livestock.

**Strategic Choices:**

1. Hold a fixed checkpoint perimeter on all roads out of the zone, admitting only credentialed responders, utility crews and critical-infrastructure staff against a published access list.
2. Run roving mobile patrols and drone surveillance of evacuated communities instead of static checkpoints, keeping a smaller footprint and concentrating Guard personnel on logistics and shelter security.
3. Create a supervised escorted-return program in which residents receive short, scheduled access windows with a responder escort to collect medications, documents and animals while ash conditions allow.

**Trade-Off / Risk:** Escorted-return programs reduce public resistance but expose both residents and escorts to unforecast ashfall and renewed eruption risk; static checkpoints are simpler to defend yet absorb personnel the response may need elsewhere.

**Strategic Connections:**

**Synergy:** Reinforces Command Structure and Jurisdictional Handoff Model by giving state and federal authorities a clear, enforceable boundary, and supports Visitor Headcount Reconciliation and Backcountry Sweep Protocol by controlling re-entry into cleared sectors.

**Conflict:** Static checkpoints draw National Guard personnel away from Ashfall Life-Support Supply and Priority Allocation convoy escorts, and escorted returns conflict with Responder Exposure Limits and Relief Rotation Regime by adding exposed escort hours.

**Justification:** *Medium*, Balances anti-looting enforcement against Guard availability for logistics. Matters after the life-safety phases and mainly reinforces command clarity; it is not a driver of the core evacuation outcome.

### Decision 11: Ash-Cloud Airspace Closure Scope and Humanitarian Flight Exceptions
**Lever ID:** `36521150-e40b-4032-84ae-23a417727bca`

**The Core Decision:** Sets the geographic and temporal rigidity of the ZLC/ZSE ash grounding and the criteria for any exceptions. Success is measured by zero aircraft ash encounters, time-to-clearance for medevac or survey sorties, and clarity of authority between FAA and Unified Command. Defines whether helicopters and cargo flights from unaffected airfields supplement ground logistics when roads saturate.

**Why It Matters:** Defines how wide and how rigid the ZLC and ZSE grounding is, and whether any controlled flights are allowed inside it. A blanket closure removes ash-ingestion risk but also removes air evacuation, medevac, and reconnaissance options. Exceptions restore some capability but raise the chance of an engine encounter and complicate FAA and military coordination.

**Strategic Choices:**

1. Impose a blanket indefinite grounding across ZLC and ZSE with no exceptions, relying entirely on ground transport for evacuation, medevac, and supply.
2. Maintain the blanket grounding but pre-authorize a narrow set of ash-model-cleared rotary-wing medevac and survey flights below defined ash-concentration limits, approved by the Unified Command.
3. Establish a dynamic airspace tiering system, driven by hourly ash-dispersion forecasts, that opens and closes corridors for cargo and evacuation flights from airfields outside the plume, such as those in the southern ZLC area.

**Trade-Off / Risk:** A total ban is simple to enforce but strands medevac and surveillance capability, while rolling exceptions depend on ash-concentration forecasts whose reliability during an unprecedented event is unproven, risking aircraft and crews.

**Strategic Connections:**

**Synergy:** Exceptions strengthen Hospital Surge Dispersal and Respiratory Patient Routing through rotary-wing medevac, and give Landslide Clearance and Hydrothermal Hazard Road Engineering aerial survey data to certify bypasses and abort triggers.

**Conflict:** Flight exceptions expose crews to ash and compete for forecast and coordination capacity with Command Structure and Jurisdictional Handoff Model; a blanket ban instead pushes all load onto Egress Corridor Allocation and Contraflow Architecture.

**Justification:** *Medium*, The grounding itself is a fixed requirement; the exception scope marginally adds medevac and survey capability. Its relief on ground corridors is secondary and depends on unproven ash forecasts.

### Decision 12: Landslide Clearance and Hydrothermal Hazard Road Engineering
**Lever ID:** `07d0a2da-0240-4130-80d3-197fd7d4666f`

**The Core Decision:** Allocates scarce heavy-equipment and geotechnical capacity between reopening the South Entrance, repairing the Grand Loop Road, or protecting the northern and western routes. Success is measured by added outbound capacity gained per crew-hour, zero crew casualties from secondary slides or steam explosions, and debris-free US-191, US-20 and US-89 throughout Phase 1.

**Why It Matters:** Decides whether engineering effort goes into reopening the landslide-blocked South Entrance road, repairing the explosion-damaged Grand Loop Road, or writing them off. Reopening adds an outbound route and relieves the north and west corridors, but exposes equipment crews to secondary slides and further steam explosions. Writing the routes off concentrates all traffic on fewer roads that are already near capacity.

**Strategic Choices:**

1. Write off the South Entrance and damaged Grand Loop sections, directing all engineering resources to keeping the northern and western routes passable and free of debris.
2. Deploy pre-positioned heavy equipment from Wyoming and Idaho transportation departments to attempt a time-boxed single-lane clearance of the South Entrance slide, with hard abort triggers tied to seismic readings.
3. Use drones and ground-penetrating geotechnical scouting to certify a few short bypass or temporary-track segments around the slide and damage, reserved for emergency vehicles and outbound overflow only.

**Trade-Off / Risk:** Reopening a southern route could relieve pressure on the corridors, but crews working on unstable ground during an active swarm may become casualties themselves, and the time spent could be better applied to keeping the open routes clear.

**Strategic Connections:**

**Synergy:** A certified southern or bypass route adds capacity that Egress Corridor Allocation and Contraflow Architecture can use, and supports Visitor Headcount Reconciliation and Backcountry Sweep Protocol by opening access to southern park areas.

**Conflict:** Crews on unstable ground consume equipment and operators that Responder Exposure Limits and Relief Rotation Regime seeks to protect, and effort spent on the south competes with keeping the northern and western routes clear.

**Justification:** *Medium*, Can add outbound capacity or keep the northern and western routes clear, but benefits are uncertain and exposure risk is high. It serves the egress lever rather than defining the strategy.

### Decision 13: Responder Exposure Limits and Relief Rotation Regime
**Lever ID:** `305647d0-e94d-41f5-9822-c932a96c85a6`

**The Core Decision:** Governs the sustainable endurance of the response workforce by setting shift lengths, withdrawal thresholds and relief cycles for rangers, highway patrol, National Guard and utility crews. Success is measured by responder illness and entrapment rates, staffing continuity at traffic points and gates, and an explicit count of respirators and relief personnel reserved for responders rather than civilians.

**Why It Matters:** Sets how long rangers, highway patrol, National Guard, and utility crews may work in ash, gas, and tremor conditions before mandatory withdrawal. Strict limits protect the response workforce from respiratory injury and entrapment, but reduce the number of people on traffic points and perimeters at the peak of the evacuation. Loose limits maximize short-term coverage but risk degrading the force just as ashfall intensifies.

**Strategic Choices:**

1. Apply fixed, conservative exposure and shift-length limits to all responders from the first hour, accepting thinner coverage at traffic control points and re-entry gates.
2. Use real-time ash and gas monitoring at each post, with responders rotating or withdrawing only when sensor readings cross agency-set thresholds, so limits flex with actual conditions.
3. Tier responders by mission criticality, giving evacuation traffic control and hospital power crews fuller protective equipment and priority relief, while lower-priority posts are withdrawn early to preserve the force.

**Trade-Off / Risk:** Protective limits assume enough relief personnel and respirators exist, but the plan pre-stages protection mainly for 100,000 civilians, so responder rotation may be limited by equipment and staffing that has not been counted.

**Strategic Connections:**

**Synergy:** Sustained, protected staffing keeps Exclusion Perimeter Posture and Re-Entry Access Control and Egress Corridor Allocation and Contraflow Architecture manned through peak ashfall, and supports Communications Continuity Stack Under Ash and Tremor maintenance crews.

**Conflict:** Strict limits thin coverage at contraflow points and perimeters at the evacuation peak, trading against Egress Corridor Allocation and Contraflow Architecture and Visitor Headcount Reconciliation and Backcountry Sweep Protocol, which need maximum personnel hours early.

**Justification:** *High*, Constrains the workforce that staffs traffic points, perimeters, sweeps and comms. Conflicts with many levers over personnel hours, controlling the coverage versus responder-safety trade-off at peak evacuation.

### Decision 14: International Visitor, Language, and Access-Needs Notification Pathways
**Lever ID:** `f13fe63b-ce28-4fd2-b0dc-ddb19ca9b9c7`

**The Core Decision:** Ensures evacuation orders and transport reach visitors that general broadcasts miss: non-English speakers, foreign nationals, people with mobility or medical needs, and those without vehicles. Success is measured by the share of at-risk visitors confirmed out of the park by T+6 hours, translation coverage of key languages, and the accuracy of needs estimates drawn from concessioner and reservation data.

**Why It Matters:** Shapes how evacuation orders reach non-English speakers, foreign nationals, people with mobility or medical needs, and visitors without vehicles who make up part of the 35,000 tourists. Targeted pathways reduce the chance that the least mobile or least informed people become the last to leave. They require consular, concession-operator, and translation resources that general IPAWS broadcasts do not provide.

**Strategic Choices:**

1. Rely on IPAWS and standard ranger announcements in English with basic multilingual signage, and assume visitors will follow traffic and crowd cues.
2. Activate concessioner and tour-operator networks, plus consular liaisons, to carry multilingual instructions and organize transport for visitors without vehicles or with access needs.
3. Create dedicated assisted-evacuation pickup points inside the park, staffed by rangers and volunteer interpreters, with shuttle buses sequenced ahead of general traffic to remove high-need visitors first.

**Trade-Off / Risk:** Assisted pickup protects the most vulnerable but takes buses and staff away from the general outflow during the critical first hours, and the plan has no visitor-needs data to size it.

**Strategic Connections:**

**Synergy:** Targeted notification feeds Visitor Headcount Reconciliation and Backcountry Sweep Protocol with who is unaccounted for, and reduces demand on Shadow Evacuation Suppression and Public Compliance Dynamics by cutting confusion-driven uncoordinated movement.

**Conflict:** Assisted pickup shuttles and staff compete with Egress Corridor Allocation and Contraflow Architecture for road space and buses, and draw ranger time away from Responder Exposure Limits and Relief Rotation Regime-constrained traffic posts.

**Justification:** *Low*, Largely a targeted extension of the communications stack and egress transport, serving a subset of visitors. Its needs data is thin, and its shuttle and staff demands are tactical trade-offs against egress.
