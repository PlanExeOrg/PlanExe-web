
## Documents to Create

### 1. Yellowstone Evacuation Project Charter

**ID:** 6abed7ce-09df-466a-92a3-0d27f1c87a5a

**Description:** Foundational project authorization document defining scope (35,800 Zone Zero + Zone One evacuation), objectives (T+6h clearance, T+24h Zone One completion, pre-authorized Scenario Beta), timeline (72-hour window, Month 0 start = 2026-10-14), resource envelope (USD 200M estimate), constraints (40% VEI-6+ probability, three-exit contraflow, Unified Command at Denver RRCC), and high-level success criteria (Gate G1: 98% of 35,800 out by T+6h; Gate G2: 95% of Zone One residents out by T+24h). Signed by UC Incident Commander, NPS leadership, and FEMA Region VIII Director.

**Responsible Role Type:** Project Manager / Unified Command Incident Commander

**Primary Template:** PMI Project Charter Template

**Secondary Template:** FEMA Emergency Operations Plan Charter

**Steps:**

- Convene UC Incident Commander, NPS incident commander, and state representatives to confirm scope and constraints from canonical facts.
- Define Phase 1 (T+0 to T+6h), Phase 2 (T+6 to T+24h), and Phase 3 (T+24 to T+72h) milestones.
- Specify decision gates (G1 at T+6h, G2 at T+24h) with measurable success criteria (exit counts, resident census confirmation).
- Document resource envelope (USD 200M) and identify financing owner (federal vs. state cost-share).
- List constraints: 72-hour window, 40% eruption probability, three exits only, no pre-event lead time for contracts/MOUs.
- Identify key dependencies: governor authorization by T+6h, Scenario Beta secondary-stage plan by Month 1 (2026-11-14), responder relief depth by T+0.
- Obtain signatures from UC Incident Commander, NPS, FEMA Region VIII and FEMA Region 10 liaison.

**Approval Authorities:** UC Incident Commander (Denver RRCC), NPS Regional Director, FEMA Region VIII Regional Administrator, Governors of Montana, Wyoming, and Idaho (verbal by T+6h, signed by Month 1 = 2026-11-14)

### 2. Scenario Beta Secondary-Stage Evacuation Plan

**ID:** 37178d26-46c9-488f-b917-a716bc5fc0c3

**Description:** Written plan specifying five to ten ranked shelter hubs outside the 500 km ring (Denver, Cheyenne prioritized; distance verification required), signed capacity MOUs from host counties, tiered public messaging (shelter-in-place 250–500 km, time-banded 100–250 km, organized Zone One), bus-fleet and rail-corridor routing to secondary hubs, and supply pre-positioning (food, water, N95s, medical supplies) by Months 1–2 (2026-11-14 to 2026-12-14). Operationalizes the pre-authorized VEI-7 trigger so that a 500 km evacuation order issued at T+12h has published destinations and messaging ready to deploy, preventing uncontrolled shadow evacuation that would strand Zone Zero evacuees.

**Responsible Role Type:** Scenario Beta Secondary-Stage Destination Planner

**Primary Template:** Multi-State Evacuation and Sheltering Plan Template (FEMA, Texas Division of Emergency Management)

**Secondary Template:** Tier System and Time-Banded Departure Schedule (Hurricane Rita, Texas A&M Transportation Institute model)

**Steps:**

- By Month -2 (2026-08-14), contact emergency management directors in Denver, Cheyenne, Albuquerque, Las Vegas, and one backup hub; confirm written acceptance of evacuees, estimate bed capacity, verify distance from Yellowstone center (must be >500 km).
- By Month -1 (2026-09-14), obtain signed MOUs from each host county specifying shelter beds, medical-staff deployment, water/fuel availability, and 48-hour resource-mobilization commitment.
- Define three evacuation rings: 0–100 km (Zone One, organized, pre-assigned routes); 100–250 km (time-banded, assigned departure windows by county on published schedule); 250–500 km (staged departure, self-supplied, no shelter assignment).
- Develop public-facing tier-system map showing hub locations, zone assignments by zip code, and time-banded evacuation schedule.
- Calculate food, water (50,000–100,000 additional gallons estimated), N95 (50,000 additional estimated), fuel and medical supplies for each ring and hub; arrange pre-positioning by Month 2 (2026-12-14).
- Design message sequence: publish tier system by Month 0 (2026-10-14); if Beta triggers at T+12h, issue assignment messages to each zone within 1 hour.
- Plan multi-state Scenario Beta execution exercise involving all hubs, sample bus dispatch, and shelter intake by Month 3 (2027-01-14).

**Approval Authorities:** UC Incident Commander, Governors of Montana, Wyoming, Idaho, Colorado, and Utah (host states), Emergency Managers and Commissioners of all participating hub counties

### 3. Responder Exposure Limits and Relief Rotation Regime Protocol

**ID:** 2b6dd88c-ebdf-4b8d-b673-886d38a53ff6

**Description:** Written operational protocol specifying maximum 6-hour shifts at ash-exposed traffic-control and perimeter-gate posts, mandatory 2-hour rest with N95 replacement, and full withdrawal after 18 consecutive hours of duty. Defines responder N95 respirator count (150,000–200,000 estimated total, separate from 100,000 civilian stock) and pre-authorizes deployment of a 30–50 person out-of-region standby reserve (Colorado Parks and Wildlife, Wyoming Game and Fish, Idaho Department of Lands) positioned at a Billings or Cheyenne depot with 4-hour dispatch authority if checkpoint coverage falls below 50%. Ensures that the 100–150 NPS ranger pool is not exhausted during peak evacuation (T+2 to T+8h).

**Responsible Role Type:** Responder Safety and Fatigue-Management Officer

**Primary Template:** OSHA Emergency Response Worker Safety Protocol

**Secondary Template:** National Guard Fatigue and Relief Rotation Standard Operating Procedure

**Steps:**

- Determine total responder headcount (rangers, highway patrol, Guard, utility crews) across all three corridors, perimeter, comms, and sweep teams (estimated 300–500 total).
- Size responder N95 inventory from confirmed headcount; assume 2–3 masks per responder over 72 hours; total 150,000–200,000 units (proposed threshold).
- Draft shift-limit protocols: 6-hour maximum at ash-exposed posts, 2-hour rest with N95 replacement, 18-hour complete withdrawal.
- Define fatigue-assessment checklist triggers for on-site withdrawal (reaction-time degradation, cognitive impairment, acute respiratory distress).
- Identify out-of-region agencies willing to provide 30–50 relief personnel; secure written pre-event commitments from each by Month -0.5 (2026-09-29).
- Specify 4-hour deployment authority: forward command can request relief personnel and approve their dispatch without state-adjutant-general approval.
- Conduct a 6-hour shift-rotation exercise at Mammoth or Gardiner checkpoint by Month -0.5 (2026-09-29), testing relief handoff, N95 replacement cycles, and fatigue checklists under simulated ashfall.
- Obtain signatures from NPS incident commander, state highway patrol directors, National Guard commanders, and out-of-region agency heads.

**Approval Authorities:** UC Incident Commander, NPS LE Incident Commander, Montana, Wyoming and Idaho Highway Patrol Directors, National Guard Adjutants General, Colorado Parks and Wildlife Director, Wyoming Game and Fish Director, Idaho Department of Lands Director

### 4. Ashfall Monitoring and Dynamic Shelter-Relocation Protocol

**ID:** dc4f29b2-c6fe-4836-8913-7947e1bcd59b

**Description:** Protocol establishing continuous PM10/PM2.5 air-quality monitoring at forward command and all three shelter sites (Bozeman, Idaho Falls, third site TBD at T+6h) from T-12h through T+72h, with automated hourly data feeds to the forward command and USGS/NOAA. Sets alert thresholds: PM10 >50 µg/m³ triggers immediate forecast update; >100 µg/m³ triggers shelter-suitability review. Pre-identifies ranked second and third backup shelter locations 50+ km upwind of each primary site, confirmed daily from 00:00 UTC wind forecast. Authorizes 2-hour decision-to-notification shelter-relocation procedures and pre-positions supplemental 100,000 N95 masks at Billings or Salt Lake City hub with 8-hour ground-convoy or helicopter delivery agreement if primary-shelter N95 consumption exceeds 20% of stock per day.

**Responsible Role Type:** Ashfall Forecasting and Dynamic Shelter-Siting Officer

**Primary Template:** USGS Volcanic Ash Impact Mitigation Monitoring Protocol

**Secondary Template:** Air Quality Early Warning and Shelter Relocation SOP (wildfire smoke evacuation model)

**Steps:**

- Deploy PM10/PM2.5 sensors with automated data logging and satellite/cellular transmission at forward command, Bozeman, and Idaho Falls by Month -0.5 (2026-09-29, 14:00 UTC).
- Install visual ash-depth measurement stations (graduated scales, photographic markers) at each shelter for independent confirmation.
- Establish real-time data feeds to the forward-command common operating picture and to USGS/NOAA liaison with one-hour update frequency.
- Pre-survey and document three backup shelter locations for each primary site, located 50+ km upwind based on climatological wind patterns; confirm wind-forecast-updated positioning daily at 00:00 UTC.
- Draft shelter-relocation decision rule: if measured PM10 at a primary shelter exceeds forecast by >50% or exceeds 100 µg/m³, trigger relocation to backup within 2 hours (proposed threshold).
- Pre-authorize buses (estimate 20–30 total) for rapid relocation capacity; identify drivers and pre-brief relocation procedures.
- Pre-position supplemental 100,000 N95 respirators at Billings Regional Medical Center or Salt Lake City hub with standing 8-hour transport agreement (ground or helicopter).
- Conduct shelter-siting and relocation exercise 30 days before eruption window (Month -0.5, 2026-09-29), simulating ashfall 50 km south of forecast and doubling of intensity; test relocation decision triggers and bus deployment for 5,000–10,000 evacuees.

**Approval Authorities:** UC Incident Commander, USGS Yellowstone Volcano Observatory Director, NOAA National Weather Service Forecast Office Director (Billings/Riverton, WY), shelter facility operators at all three primary sites

### 5. Command Structure and Jurisdictional Authority Framework

**ID:** 768e57ad-399c-491a-845f-3a9c2e011f60

**Description:** Defines organizational structure of the Unified Command with FEMA Region VIII RRCC (Denver) as primary, FEMA Region 10 liaison seated from T+0, and forward UC element at Livingston, MT (alternate Bozeman). Specifies authority transfer from NPS to state governors at park boundary via written protocol; establishes Boundary Coordination Officer position with pre-authorized reroute and shelter-assignment authority during the crossing. Documents NPS-to-state handoff checkpoints (Mammoth on US-89, Gallatin County line on US-191, Cody limits on US-14/16/20) and clarifies when state custody begins. Includes decision authority for trigger matrix (UC issues Scenario Beta 500 km order within 30 min of trigger without further approval) and governs inter-agency communication protocols (primary: hourly UC briefings; secondary: Boundary Coordinator voice/data links).

**Responsible Role Type:** Regional Emergency Management & Multi-Jurisdiction Coordination Director

**Primary Template:** NIMS/ICS Unified Command Organization Chart and Authority Matrix

**Secondary Template:** Interstate Mutual Aid Agreement (EMAC) Authority Framework Template

**Steps:**

- Map the UC organizational structure: UC Incident Commander at Denver; three main branches (Evacuation/Traffic, Shelter/Logistics, Communications); sub-units for each state (MT, WY, ID).
- Establish FEMA Region 10 liaison role with direct seat at UC briefings and pre-authorized mutual-aid request authority (no approval delays >2 hours for Idaho resources).
- Define forward UC element at Livingston: co-locate NPS incident commander, Boundary Coordination Officer, Contraflow Operations Manager, and Logistics Director.
- Draft written NPS-to-state authority-transfer protocol: specify that NPS care ends at defined roadside checkpoint; state on-scene commander assumes custody; state highway patrol assumes traffic management on state roads.
- Pre-authorize state on-scene commanders to issue temporary reroutes (max 30 min without supervisory approval) during congestion at the boundary crossing.
- Document pre-authorized Scenario Beta trigger authority: UC Incident Commander approves and announces the 500 km order within 30 min of USGS trigger confirmation (final trigger values due by T+3h).
- Obtain written pre-event confirmation from MT, WY and ID governors authorizing the Unified Command orders by Month -1 (2026-09-14); sign full MOUs (EMAC mutual aid, resource requests, authority transfer) by Month 1 (2026-11-14).
- Schedule multi-state command-authority exercise 60 days before window (Month -1.5, 2026-08-29) testing boundary handoff and escalation under Zone One and Scenario Beta scenarios; document and resolve any jurisdictional conflicts by Month -1 (2026-09-14).

**Approval Authorities:** UC Incident Commander (FEMA Region VIII), Governors of Montana, Wyoming, Idaho, and Colorado (for forward command resources), NPS Regional Director, State Emergency Management Directors

### 6. Escalation Trigger Matrix and Scenario Beta Pre-Authorization

**ID:** 82e68eba-a1aa-4f56-8f97-1f3f5e9ede57

**Description:** Written, pre-authorized threshold-based trigger matrix specifying USGS indicators (uplift rate, seismic magnitude, gas flux, modeled VEI probability in remaining window) that automatically activate Zone One expansion and authorize the Scenario Beta 500 km evacuation order. Final indicator values to be set by USGS by T+3h (placeholders: VEI-7 probability ≥20% in remaining window; other thresholds TBD). UC Incident Commander is pre-authorized to issue the 500 km order within 30 minutes of trigger confirmation without requiring further approval from governors or FEMA. Document clarifies that trigger is pre-authorized decision authority, not a decision that requires meetings or additional debate during the 72-hour window.

**Responsible Role Type:** Volcanologist & USGS Hazard Forecaster

**Primary Template:** USGS Volcano Monitoring and Eruption Forecast Protocol Template

**Secondary Template:** Incident Command Decision Authority and Pre-Authorization Document

**Steps:**

- Coordinate with USGS Yellowstone Volcano Observatory to establish final indicator thresholds by T+3h: specifics include uplift rate (mm/day), seismic magnitude and frequency, gas-emission rates, and modeled VEI-7 eruption probability within the remaining 72-hour window.
- Define the trigger logic: if ANY single indicator crosses its threshold, the entire 500 km Scenario Beta order is activated (no requirement for multiple indicators to trigger simultaneously).
- Establish communication protocol: USGS provides hourly indicator updates to the UC from T-12h through T+72h; when an indicator crosses a threshold, USGS notifies the UC Incident Commander directly via satellite phone within 15 minutes.
- Draft pre-authorization language: 'The UC Incident Commander is authorized to issue and announce the Scenario Beta 500 km evacuation order within 30 minutes of USGS trigger confirmation, without seeking further approval from governors, FEMA, or any other authority.'
- Document the interim Scenario Beta plan (destinations, time-banded schedule, messaging) that will be activated simultaneously with the 500 km order (or this trigger matrix cannot be executed operationally).
- Obtain written signature from USGS Yellowstone Volcano Observatory Director confirming availability of real-time indicator updates and communication protocol.
- Obtain written pre-authorization from governors of MT, WY and ID confirming their acceptance of the pre-authorized 500 km order mechanism (verbal by T+6h, signed by Month 1 = 2026-11-14).

**Approval Authorities:** USGS Yellowstone Volcano Observatory Director, UC Incident Commander (FEMA Region VIII), Governors of Montana, Wyoming, and Idaho (verbal authorization by T+6h, signed by Month 1 = 2026-11-14)

### 7. Egress Corridor Allocation and Contraflow Operations Plan

**ID:** e7aec916-0370-49a6-8b0c-a78a86e82a23

**Description:** Specifies three-exit contraflow strategy allocating zone-zero evacuees (35,800 people) to US-20/US-191 West (50%, ~17,900 to Bozeman/I-90), US-89 North (30%, ~10,740 to Gardiner/Livingston/I-90), and US-14/16/20 East (20%, ~7,160 to Cody/East Entrance). Documents fixed district-to-gate assignment preventing interior vehicle crossings, traffic-control staffing at each checkpoint, tow and rockfall-clearing teams pre-positioned at chokepoints, and contraflow-termini design (staging-lot capacity, turn-pocket geometry, queue-storage). Specifies traffic throughput targets (660 vehicles/hour per exit, 2,000 vehicles/hour total estimated), lane-reversal procedures, and blockage-diversion rules (>45 minutes blockage triggers overflow to next-nearest exit; >6 hours unstorable blockage triggers loss-of-exit contingency and shelter-in-place).

**Responsible Role Type:** Transportation Operations & Contraflow Specialist / Contraflow Operations and Traffic Control Manager

**Primary Template:** FHWA Contraflow Operations and Evacuation Planning Guidance (Texas DOT Hurricane Rita model)

**Secondary Template:** Mountain Pass Traffic Management Plan (CDOT, mountain-corridor protocols)

**Steps:**

- Commission a geotechnical survey of Gallatin Canyon and the South Entrance landslide (Month -1.5, 2026-08-29) quantifying debris volume, secondary-slide risk, and clearance feasibility; develop time-boxed single-lane clearance plan (max 4 hours, abort on M4.0+ seismic or >2 cm slope displacement).
- Conduct a site survey at all three contraflow termini (Month -0.5, 2026-09-29) measuring staging-lot capacity, turn-pocket geometry, queue-storage length, and validating 660 vehicles/hour throughput; adjust exit split or add overflow staging if lot saturation occurs before road saturation.
- Draft lane-reversal procedures for all three corridors, specifying trigger point (T+1h), responsible agency (NPS LE Rangers, state DOT), and staging-lot queue-management protocols.
- Design traffic-control checkpoint layout at each terminus (Mammoth, Gardiner/West Yellowstone area, Cody): specify number of rangers, signage placement, electronic message signs, radio frequencies, and checkpoint-to-checkpoint communication protocols.
- Pre-position at least two mobile heavy-equipment teams (wreckers, debris chippers, geotechnical drones, 72-hour fuel) at Mammoth or Spanish Creek depots (Month -0.5, 2026-09-29, 06:00 UTC) with 15-minute dispatch authority to any Gallatin Canyon blockage.
- Establish live geotechnical monitoring (motion sensors or slope-displacement drones) along Gallatin Canyon and US-89 near Gardiner (Month -0.5, 2026-09-29, 12:00 UTC) with automatic alerts to forward command if displacement exceeds 2 cm/hour; pre-authorize 15-minute temporary traffic halts if alerts trigger.
- Draft Loss-of-Exit Contingency Protocol (Month -1, 2026-09-14): blockage >45 minutes triggers diversion; blockage >6 hours triggers shelter-in-place for queued vehicles and IPAWS notification within 5 minutes.
- Create a Corridor Capacity Operations Center design (forward command element) with real-time traffic-camera feeds, queue-length monitoring, blockage alerts, and automated reroute dispatch authority.

**Approval Authorities:** UC Incident Commander, NPS Incident Commander, Montana DOT Director, Wyoming DOT Director, State Highway Patrol Commanders (MT, WY, ID), USGS Geotechnical Hazards Specialist

### 8. Refugee Intake and Shelter Siting Strategy

**ID:** cdd4e61e-62a2-4c83-8d45-731244810d96

**Description:** Multi-phase shelter-siting and operations plan. Phase 1 (T+0 to T+6h): identifies rapid-intake sites at Bozeman and Idaho Falls as provisional shelters. Phase 2 (T+6 to T+24h): finalizes primary shelter locations based on latest USGS/NOAA ashfall forecast; identifies ranked backup sites 50+ km upwind. Phase 3 (T+24 to T+72h): sustains shelter operations with water, medical triage, family reunification and N95 replacement cycles. Specifies intake-processing capacity (estimate: 5,000 people per shelter per 4-hour cycle), medical triage protocols, and onward-transport triggers for Scenario Beta (if Beta is activated, evacuees move from primary to secondary hubs in Scenario Beta destination plan).

**Responsible Role Type:** Public Health & Mass-Casualty Medical Logistics Director

**Primary Template:** FEMA Disaster Shelter Operations and Mass Care Plan

**Secondary Template:** Mass Casualty Reception and Reunification Protocol (Red Cross)

**Steps:**

- Confirm facility capacity at Bozeman and Idaho Falls shelters (estimate 15,000 and 10,000 respectively); specify bed arrangement, kitchen facilities, medical triage space, and reunification desk.
- Identify a third shelter site in consultation with state emergency managers; target 10,800 capacity (total 35,800 for Zone Zero + buffer for Zone One early arrivals).
- Develop intake-processing checklist: registration, language assessment, medical screening, special-needs identification (mobility, medical dependencies, children), reunification contact info, shelter-assignment to final destination.
- Draft triage protocols: separate respiratory-distress cases for hospital referral; identify mobility-limited or medical-dependent individuals for priority water and N95 supply.
- Design family reunification desk: secure communication with hospitals and Zone One shelters; database of evacuee locations for public inquiry.
- Specify N95 replacement and respiratory-support protocols: assume 2.8 masks per person over 10 days, clogging rate in heavy ash (3–5x higher consumption), supplemental-reserve activation threshold (20% per day).
- Plan onward-transport for Scenario Beta: if Beta triggers, arrange buses and rail transport to secondary hubs (Denver, Cheyenne); coordinate with secondary-hub shelter operators.
- Conduct full-scale shelter intake exercise at Bozeman and Idaho Falls 30 days before eruption window (Month -0.5, 2026-09-29), processing 5,000–10,000 sample evacuees through intake, triage, and reunification; measure actual processing time and identify bottlenecks.

**Approval Authorities:** UC Incident Commander, Public Health Officer (state health departments), Bozeman and Idaho Falls Emergency Managers, Hospital Administrators at receiving facilities, American Red Cross Regional Director

### 9. Communications Continuity Stack Under Ash and Tremor

**ID:** c486a1f8-11d8-47b8-bf29-b0cd88903560

**Description:** Layered communications infrastructure plan specifying: (1) Primary layer—IPAWS/WEA for rapid public alerting; (2) Secondary layer—National Guard signal teams with satellite phones and portable repeaters at each contraflow control point and the forward command, providing responder-radio bridging between agencies (NPS, state patrol, Guard, FEMA) when cell towers fail; (3) Tertiary layer—highway advisory radio (HAR) and variable message signs (VMS) on US-191, US-20, US-89 and I-90 with pre-recorded messages updated hourly from forward command; (4) Quaternary layer—printed route cards in English and five primary visitor languages distributed at park entrances and lodges. Specifies satellite-phone backup, message authentication protocols, and real-time coordination with USGS/NOAA for ashfall and trigger-matrix updates.

**Responsible Role Type:** Communications and Public Alerting Coordinator

**Primary Template:** FEMA Emergency Communications Plan and IPAWS Message Development Template

**Secondary Template:** National Guard Signal Corps Satellite Phone and Repeater Deployment SOP

**Steps:**

- Secure pre-event access to IPAWS and WEA distribution systems; coordinate with NWS and FAA for message scheduling and validation.
- Pre-produce all evacuation messages in English and five primary visitor languages (Spanish, Japanese, German, Mandarin, French) by Month -1 (2026-09-14); conduct native-speaker cognitive testing (3–5 per language by Month -1.5, 2026-08-29) to ensure comprehension.
- Validate message clarity for phased evacuation: (a) initial alert (T+0 hours), (b) route assignments by exit, (c) shelter locations (if T+6h update differs from earlier guidance, explain why), (d) Scenario Beta escalation (if triggered).
- Order Guard signal equipment: satellite phones, portable VHF/UHF repeaters, generator fuel, equipment cases, deployment toolkits. Stage at forward command and request pre-positioning at each of three contraflow control points (Mammoth, Gardiner, Cody) by Month -0.5 (2026-09-29, 14:00 UTC).
- Coordinate frequency allocation with FCC and state communications agencies; conduct formal radio interoperability testing across NPS, state patrol, National Guard and FEMA 30 days before eruption window (Month -0.5, 2026-09-29) confirming all agencies can communicate on shared frequencies and backup channels.
- Test satellite and portable-repeater systems under simulated ashfall (fog machines or ash simulation) 30 days before eruption window, measuring radio propagation through ash, equipment overheating, and operator visibility; validate 72-hour fuel adequacy.
- Draft pre-recorded HAR and VMS messages with 1-hour update authority: assign update drafting to Communications Coordinator from forward command, with approval from UC Incident Commander for shelter-location or escalation changes.
- Arrange with park concessioners (Xanterra) to include multilingual route instructions in all guest-room materials, tour-bus briefings, and visitor-center displays by Month -0.5 (2026-09-29).

**Approval Authorities:** UC Incident Commander, FCC Regional Director, National Guard Signal Officer, IPAWS Regional Coordinator, State Emergency Management Directors (MT, WY, ID)

### 10. Ashfall Life-Support Supply and Priority Allocation Framework

**ID:** 2667bfaf-1add-4700-bda7-154195ba871e

**Description:** Multi-faceted supply-chain plan for water, N95 respirators, generator fuel and medical supplies. Specifies tiered fuel allocation: Tier 1 (hospitals, comms centers), Tier 2 (shelter kitchens, water-treatment systems), Tier 3 (vehicle fueling for convoys). Details water procurement and delivery: forward-depot pre-staging at Bozeman and Idaho Falls (200,000–300,000 liters by T+0); dispatch of convoys from Salt Lake City by T+12h with realistic arrival window of T+18–30h (not T+12h dispatch). Specifies N95 inventory (100,000 civilian + 100,000 supplemental + responder stock separate) with consumption-monitoring and resupply triggers. Includes contracts with vendors for 12-hour dispatch clauses and FEMA contract-vehicle activation procedures.

**Responsible Role Type:** Supply Chain & Logistical Resilience Strategist / Emergency Logistics and Supply-Chain Director

**Primary Template:** FEMA Disaster Logistics Coordination Plan

**Secondary Template:** Federal Emergency Management Procurement and Contract Activation (Stafford Act procedures)

**Steps:**

- By Month -1 (2026-09-14), establish written surge-mobilization contracts with bottled-water suppliers, N95 manufacturers, diesel-fuel wholesalers and generator-service vendors specifying 12-hour dispatch on verbal activation by forward command.
- Identify backup suppliers: water distributors in Pocatello, ID and Butte, MT; N95 suppliers in Salt Lake City and Denver; fuel sources in Rock Springs, WY and Billings, MT.
- Calculate water requirement: 35,800 people × 4 L/person/day × 10 days = ~1.43 million liters. Stage initial 200,000–300,000 liters at forward depots (Bozeman, Idaho Falls) by Month -0.5 (2026-09-29, 18:00 UTC); contract for convoy arrival at shelters by T+18–24h via Salt Lake City route (I-15 northbound, reserved surge lane).
- Test supply-convoy exercise: from Salt Lake City to Bozeman under simulated ashfall (visibility 50–100 meters, 10 mph safe speed, evacuation-traffic saturation 25–40% on I-15 by Hour 8–12) by Month -0.5 (2026-09-29); measure actual travel time and identify chokepoints.
- Draft fuel-consumption model: hospital generators consume 20–30 gal/hour at full load; calculate tank sizes for 12–48 hour power-loss scenarios (estimate 300–600 gallons per facility). Pre-position 72-hour reserves at three receiving hospitals by Month -0.5 (2026-09-29, 18:00 UTC); arrange two backup tankers on-call at each hospital.
- Establish fuel-delivery contracts with local vendors (Yellowstone Energy, Basin Fuel) requiring priority dispatch within 2 hours of request during the event.
- Size N95 inventory: 100,000 civilian + 100,000 supplemental + responder stock (150,000–200,000 estimated separate from civilian); stage supplemental reserve at Billings Regional Medical Center or Salt Lake City hub by Month -0.5 (2026-09-29) with 8-hour delivery agreement.
- Set N95 consumption monitoring: track stock at each shelter daily; if consumption exceeds 20% of on-hand per day, trigger helicopter or ground resupply of supplemental reserve within 8 hours.
- Establish procurement checkpoint at forward command with dedicated logistics officer tracking all inbound shipments hourly and alerting UC Incident Commander if any convoy is delayed >4 hours beyond dispatch.

**Approval Authorities:** UC Incident Commander, FEMA Logistics Officer, State Emergency Management Directors, Hospital Administrators, Utility Directors (Montana-Dakota Utilities, Pacific Power, Idaho Power)

### 11. Hospital Surge Dispersal and Respiratory Patient Routing Protocol

**ID:** 18797575-3803-4950-b4d9-2187b1b9614b

**Description:** Emergency medical protocol designating three receiving hospitals (Bozeman Deaconess Medical Center, Livingston HealthCare, Eastern Idaho Regional Medical Center) with pre-authorized bed-capacity expansion and respiratory-protection measures. Specifies early transfer of dialysis-dependent and fragile patients to distant facilities (Salt Lake City, Denver) before ashfall onset to free surge capacity. Details field triage for mild/moderate respiratory cases at shelters (managed on-site with field clinicians), reserving hospital beds for severe cases. Includes ambulance dispatch procedures, inter-hospital patient-transfer protocols and helicopter medevac coordination under FAA airspace restrictions. Specifies hospital fuel, water and power-resilience measures.

**Responsible Role Type:** Public Health & Mass-Casualty Medical Logistics Director / Hospital Administrator

**Primary Template:** FEMA Hospital Surge Capacity and Mass Casualty Plan

**Secondary Template:** EMS Patient Routing and Destination Hospital Assignment Protocol

**Steps:**

- Confirm baseline bed capacity at three receiving hospitals; estimate ashfall-related respiratory-distress volume (5,000–10,000 cases estimate in Zone One); calculate surge-bed requirement per facility.
- Draft pre-event patient-transfer protocol: identify dialysis-dependent, ventilator-bound, and frail-elderly patients at hospitals in Zone One (Gardiner, West Yellowstone area clinics) and schedule ground-ambulance transfers to Salt Lake City or Denver 48 hours before eruption window. Pre-arrange receiving-hospital bed commitments.
- Design field-triage algorithm for shelter intake: assess respiratory status, O2 saturation, breathing difficulty; route severe cases (O2 sat <90%, respiratory distress) to hospitals; manage mild/moderate cases (O2 sat >90%, mild symptoms) in field-treatment tents at shelters with rotating clinician teams.
- Pre-position field-treatment tents and rotating medical staff at each primary shelter (Bozeman, Idaho Falls, third site); specify clinician rotation schedule to prevent responder fatigue.
- Establish ambulance-dispatch procedure: central patient-tracking desk at forward command receives field triage reports and assigns patients to receiving hospitals based on real-time bed availability.
- Draft hospital generator and fuel protocols: pre-position 72-hour reserves; establish fuel-delivery contracts with 2-hour dispatch; conduct generator-startup and load-shedding exercises at each hospital.
- Negotiate helicopter medevac agreements with Wyoming National Guard aviation unit (Cheyenne) and U.S. Air Force (Malmstrom AFB); pre-authorize lift within 4 hours of request if ground ambulance transport is blocked by ashfall.
- Conduct multi-hospital surge-capacity exercise 30 days before eruption window, simulating early patient transfers, field-triage processing and inter-hospital coordination.

**Approval Authorities:** UC Incident Commander, State Health Officers (MT, WY, ID), Hospital Administrators and Medical Directors at three receiving hospitals, State EMS Coordinators, Wyoming National Guard Aviation Commander, U.S. Air Force 341st Missile Wing Commander (Malmstrom AFB)

### 12. Exclusion Perimeter Posture and Re-Entry Access Control Plan

**ID:** 8286eeb0-d02f-4658-a04f-bf922f9aacd3

**Description:** Security and access-control plan for evacuated communities (Gardiner, West Yellowstone, Cody areas and park interior). Specifies checkpoint and patrol methods to prevent looting and unauthorized entries; defines credentialing for responders, utility crews and critical-infrastructure staff; documents escorted-return program (if authorized in Phase 3) allowing residents short windows to retrieve documents, medications and animals with responder escorts under ashfall-condition approval.

**Responsible Role Type:** National Guard Perimeter Security Commander

**Primary Template:** National Guard Perimeter Control and Access-Management SOP

**Secondary Template:** Disaster Area Re-Entry Authorization and Escorted-Access Protocol

**Steps:**

- During Phase 1 (T+0 to T+6h) and Phase 2 (T+6 to T+24h), prioritize roving patrols and drone surveillance over static checkpoints to preserve Guard personnel for logistics and shelter security.
- Define core perimeter checkpoint locations (main roads out of evacuated areas): exact siting deferred to forward command based on confirmed evacuation progress.
- Specify credentialing for authorized entry: active-duty responders (NPS LE, state patrol, Guard), utility-restoration crews with company ID, hospital staff with medical credentials, designated government officials.
- Draft escorted-return protocol for Phase 3 (T+24 to T+72h): residents apply for return access; forward command schedules short windows (30–60 minutes); responders escort residents to homes to retrieve specified items (medications, documents, pet carriers); residents return to shelter.
- Set ashfall-condition threshold for escorted returns: discontinue if PM10 exceeds 200 µg/m³ at entry point (estimated hazardous level for unprotected civilians on foot).
- Coordinate with local law-enforcement (Park County, Gallatin County sheriffs) on looting-prevention patrols and stolen-property recovery after perimeter closure.
- Conduct perimeter-operations exercise 30 days before eruption window, testing mobile patrols, drone deployment, credentialing procedures and escorted-return logistics.

**Approval Authorities:** UC Incident Commander, National Guard Commander, State Highway Patrol Directors, Park and County Sheriff Offices

### 13. Ash-Cloud Airspace Closure Scope and Humanitarian Flight Exceptions Protocol

**ID:** c03f4283-f466-4826-8d2e-bd0fa1123607

**Description:** Defines FAA airspace restriction strategy: indefinite grounding of commercial and private aviation in ZLC (Salt Lake Air Route Traffic Control Center) and ZSE (Seattle ARTCC) volcanic-ash-restricted airspace, with narrow pre-authorized exceptions for government rotary-wing medevac and reconnaissance flights. Specifies ash-concentration thresholds (<200 µg/m³ PM10 at rotor altitude estimated) below which medevac flights are authorized; documents flight-request procedures and 30-minute approval authority for UC Incident Commander. Pre-authorizes military helicopter pre-positioning (Army MEDEVAC from Fort Carson, Wyoming National Guard aviation from Cheyenne) with 4-hour dispatch commitments.

**Responsible Role Type:** Aviation Safety & Airspace Management Liaison

**Primary Template:** FAA Notice to Airmen (NOTAM) and Volcanic-Ash Airspace Closure Template

**Secondary Template:** Military Joint Task Force and Emergency Airlift Coordination Agreement

**Steps:**

- By Month -1 (2026-09-14), execute a written Rotary-Wing Medevac Exception Protocol specifying: (a) ash-concentration thresholds from USGS forecasts and VAAC updates (recommend <200 µg/m³ PM10 at rotor altitude), (b) approved flight corridors below the ash cloud, (c) aircraft-type restrictions (twin-engine, ash-tolerant airframes only), (d) pre-authorization for UC to issue medevac approvals without 24-hour FAA Section 91.3 waiver turnaround.
- Coordinate with FAA Hazmat Division, USGS Volcano Disaster Assistance Program, and aircraft manufacturers (Bell, Sikorsky) to align ash-concentration limits with helicopter engine-inlet specifications.
- Execute MOA with Wyoming National Guard, U.S. Air Force (Malmstrom AFB), and Department of Defense: pre-position 2–4 Army MEDEVAC helicopters at Gallatin County Airport (Bozeman) by Month -0.5 (2026-09-29, 12:00 UTC), staffed for continuous 72-hour operations.
- Establish 24/7 FAA-Military-UC coordination channel (secure video teleconference or satellite phone) between FAA Seattle ARTCC, Malmstrom AFB command post and forward UC element, operational from T-12h through T+72h to approve medevac requests within 30 minutes.
- Draft fallback ground-ambulance medevac plan: if rotary-wing assets become unavailable (weather, mechanical), ground ambulances transport critical patients to Salt Lake City (8–12 hour transit) with portable ventilators and oxygen supply.
- Conduct Joint Task Force activation and medevac-dispatch exercise at a Zone One hospital 30 days before eruption window, simulating critical-care patient transfer under ashfall conditions; measure aircraft launch-to-landing times and confirm 4-hour dispatch capability end-to-end.

**Approval Authorities:** FAA Administrator (or delegated FAA Regional Administrator), UC Incident Commander, USGS Volcano Disaster Assistance Program Director, Military Joint Task Force Commander, NOAA Volcanic Ash Forecast Transport Coordinator

### 14. Visitor Headcount Reconciliation and Backcountry Sweep Protocol

**ID:** 477d2478-9778-4ce8-bbdd-801e7903fe7e

**Description:** Accountability system combining gate-count manifests, lodging registrations, and backcountry permit data to estimate remaining occupants; deploying ranger-led sweep teams with helicopter support to clear trailheads and thermal basins sector-by-sector. Establishes 'clearance certification' at T+6h declaring Zone Zero safe, with gap-estimate between manifest and confirmed evacuees. Specifies last-resort wilderness shelters (pre-stocked with food, water, N95, first aid) in areas outside the modeled ashfall footprint for any stranded backcountry parties.

**Responsible Role Type:** NPS LE Rangers / Incident Commander

**Primary Template:** Missing Persons Search and Rescue Protocol (NPS / SAR agencies)

**Secondary Template:** Post-Disaster Accountability and Family Reunification Plan

**Steps:**

- By T-12h (Month 0, 2026-10-14, 02:00 UTC), activate permit-reconciliation system: compare entrance-gate counts, lodge registrations (via Xanterra) and campground permits against real-time checkpoint exit counts to produce hourly estimate of remaining occupants.
- Issue permit cancellation and mandatory evacuation order to all outstanding backcountry permits at T-24h (Month 0, 2026-10-14); instruct permit-holders to exit via designated ranger-escorted routes.
- Pre-position ranger sweep teams at key backcountry junctions (Norris-to-Canyon trail, Lamar Valley research stations, geyser basins) by T-12h with satellite phones and emergency shelter supplies.
- Establish dynamic backcountry tracking: at T+0, initiate hourly check-ins with all outstanding permit-holders via satellite messenger devices; redirect non-responding parties to ranger-escort meeting points.
- Designate 2–3 last-resort wilderness shelters in areas outside modeled ashfall footprint (South Entrance/Thorofare region estimated) pre-stocked with food, water, first aid and N95 for unplanned backcountry stragglers.
- Produce clearance status at T+6h: manifest reconciliation + sweep results + backcountry check-in data → estimated number remaining. If <2% remain or are actively sheltered (backcountry or field), declare Zone Zero 'clear' and report to Boundary Coordination Officer.
- Coordinate Wyoming-based Search and Rescue teams for ground-based extraction of stranded backcountry parties after T+6h evacuation window closes.
- Conduct backcountry sweep exercise 30 days before eruption window, testing permit cancellation, ranger dispatch and backcountry check-in logistics.

**Approval Authorities:** NPS Incident Commander, Park Superintendent, State Emergency Management Directors, SAR Coordinator

### 15. Shadow Evacuation Suppression and Public Compliance Dynamics Strategy

**ID:** 47d60c44-c3af-4bdc-b873-d4f66f277e50

**Description:** Public-messaging and behavioral-management strategy to prevent unordered flight from outer-zone communities (Bozeman, Billings, Idaho Falls) that would saturate primary evacuation corridors. Specifies shelter-in-place messaging for outer-zone residents if Scenario Beta is not triggered, supported by published USGS trigger matrix so residents understand the escalation logic. Includes time-banded evacuation schedules (if Beta is triggered) assigning departure windows by county/community to spread traffic load. Addresses message-credibility risk if shelter-in-place instructions are later reversed by Scenario Beta order; proposes pre-published 'Adaptive Messaging Protocol' explaining the escalation logic.

**Responsible Role Type:** Visitor Communication & Behavioral Compliance Strategist / Communications and Public Alerting Coordinator

**Primary Template:** Emergency Public Messaging and Behavioral Compliance Plan

**Secondary Template:** Escalation Messaging Protocol and Message Credibility Maintenance Strategy

**Steps:**

- By Month 0 (2026-10-14) start (T+0), issue shelter-in-place messaging to outer-zone residents (Bozeman, Billings, Idaho Falls areas and surrounding 100–250 km radius) via IPAWS, local radio, local TV and social media, stating: 'Remain in your home; do not flee; local officials will announce evacuation if required.'
- Publish the USGS Escalation Trigger Matrix (final indicator thresholds by T+3h) to all media outlets and community leaders in outer zones, explaining: 'If [specific USGS indicator] is detected, evacuation will be ordered.' This transparency builds trust in the shelter-in-place order.
- Develop 'Adaptive Messaging Protocol' document explaining: shelter-in-place is based on current (low) eruption probability; if Scenario Beta indicators appear, evacuation will be triggered immediately; residents should monitor official channels for updates.
- Pre-produce time-banded evacuation schedule (if Beta is triggered): assign outer-zone communities to departure windows (e.g., Bozeman 1–2 hour window, Billings 3–4 hour, Idaho Falls 5–6 hour) to spread road load and prevent simultaneous mass departure.
- Pre-authorize Scenario Beta messaging transition: when trigger fires, issue immediate WEA/IPAWS alert stating 'Previous shelter-in-place order is superseded; begin evacuation per your assigned time window; report to [hub address].'
- Conduct message-credibility exercise with sample outer-zone residents 30 days before eruption window, testing comprehension of escalation logic and measuring compliance rates under shelter-in-place and time-banded messaging variants.
- Establish media-coordination hotline and briefing schedule to answer journalist questions and maintain institutional credibility throughout the 72-hour window.

**Approval Authorities:** UC Incident Commander, State Emergency Management Directors (MT, WY, ID), County Emergency Managers in outer zones, IPAWS Regional Coordinator, Local Media Representatives

### 16. International Visitor, Language, and Access-Needs Notification Pathways

**ID:** 5c05456e-a753-4af7-a87b-8318e6d25b4d

**Description:** Multi-channel strategy to reach non-English-speaking visitors, foreign nationals, vehicle-less travelers and mobility-limited evacuees. Pre-produces IPAWS alerts and route-instruction broadcasts in five primary visitor languages (Spanish, Japanese, German, Mandarin, French); activates concessioner networks and consular liaisons to deliver multilingual instructions and organize transport; establishes assisted-evacuation pickup points for visitors without vehicles and mobility-aid requirements; ensures shuttles (4–6 buses per major lodge estimated) are pre-allocated and pre-briefed. Specifies visitor-needs data collection at lodges and permit stations (language, vehicle, mobility-need, contact info) from T-48h onward.

**Responsible Role Type:** Visitor Communication & Behavioral Compliance Strategist / Communications and Public Alerting Coordinator

**Primary Template:** Multilingual Emergency Alert Content Development and Testing (DHS FEMA)

**Secondary Template:** Special-Needs Evacuation and Assisted-Transport Protocol (ADA and accessibility focus)

**Steps:**

- By Month -1 (2026-09-14), pre-produce IPAWS/WEA messages and radio broadcasts in English and five visitor languages (Spanish, Japanese, German, Mandarin, French); include simple, phased instructions (e.g., 'Evacuate now,' 'Follow US-89 North,' 'Go to shelter at [address]').
- Conduct native-speaker cognitive testing (3–5 per language) by Month -1.5 (2026-08-29) to ensure comprehension; revise any unclear terms.
- Coordinate with Xanterra Parks and Resorts to disseminate multilingual instructions to all guest rooms, tour buses and visitor centers by Month -0.5 (2026-09-29); brief hotel staff on multilingual evacuation procedures.
- Pre-identify 20–50 multilingual volunteers from major tour operators and lodge staff; position them at major lodges by T+0 with translation materials and communication devices (radios, satellite phones).
- Establish assisted-evacuation shuttle system: pre-assign 4–6 buses per major lodge (estimated 20–30 buses total) with pre-briefed drivers and mobility-assistance attendants; at T-12h confirm lodge occupancy via concessioner manifests; create priority-transport staging areas.
- At T-12h, confirm visitor-needs registry (language, vehicle status, mobility/medical needs) from lodges and backcountry permits; use registry to prioritize shuttle allocation and multilingual assistance.
- Pre-authorize secondary protocol: if any lodge cannot evacuate within 3 hours, notify forward command, which will dispatch helicopter support or ground rescue teams from the National Guard.
- Conduct language-access and mobility-assistance exercise at a major lodge 30 days before eruption window, testing shuttle capacity, multilingual instruction delivery and mobility-aid handling for sample evacuees.

**Approval Authorities:** UC Incident Commander, Xanterra Parks and Resorts General Manager, State Emergency Management Directors, ADA Coordinator (federal/state), Tour Operator Representatives

### 17. Landslide Clearance and Hydrothermal Hazard Road Engineering Plan

**ID:** 42327580-24d2-434d-ad00-a02a89bca251

**Description:** Engineering strategy addressing road hazards and blockages. South Entrance landslide (currently blocked, written off as baseline) is subject to time-boxed (max 4 hours) single-lane clearance attempt with hard abort triggers (M>4.0 seismic swarm, >2 cm slope displacement, equipment breakdown >30 minutes). Gallatin Canyon and US-89 near Gardiner are monitored for incipient slope failure via geotechnical sensors; secondary slides during evacuation could trigger blockages requiring rapid clearance by pre-positioned tow and rockfall-clearing teams (15-minute dispatch target). Grand Loop Road explosion damage is assessed; if impassable, that route is written off.

**Responsible Role Type:** Transportation Operations & Contraflow Specialist / Geotechnical Engineer

**Primary Template:** Highway Geotechnical Hazard Assessment and Emergency Slope Stabilization SOP

**Secondary Template:** Post-Disaster Road Clearance and Debris-Removal Operations Plan

**Steps:**

- By Month -1.5 (2026-08-29), commission geotechnical survey of South Entrance landslide using GPR and aerial drones: quantify debris volume, assess slope stability under seismic swarm, estimate secondary-slide probability during clearance work.
- Develop time-boxed (max 4 hours) single-lane clearance plan with identified safe staging areas and equipment-placement zones; include abort decision tree: if M>4.0 seismic event occurs or slope displacement >2 cm/hour is detected, halt work immediately and write off the route.
- Survey Gallatin Canyon and US-89 near Gardiner for incipient-failure zones; mark monitoring points for motion sensors or drone-based slope-displacement detection.
- Install live geotechnical monitoring (motion sensors or drones) at high-risk zones by Month -0.5 (2026-09-29, 12:00 UTC); set automatic alerts if displacement exceeds 2 cm/hour.
- Pre-position two mobile heavy-equipment teams (wreckers, debris chippers, geotechnical spotters) at Mammoth or Spanish Creek with 72-hour fuel and 15-minute dispatch authority.
- Assess Grand Loop Road damage from hydrothermal explosions; if rendered impassable, confirm that no evacuation traffic depends on this route and allocate clearing effort to maintaining the three primary exits (US-20/US-191, US-89, US-14/16/20).
- Conduct geotechnical monitoring and equipment-deployment exercise 30 days before eruption window, simulating equipment arrival at a blockage and testing clearance protocols.

**Approval Authorities:** UC Incident Commander, Wyoming and Montana DOT Directors, USGS Geotechnical Hazards Specialist, State Highway Patrol

### 18. Risk Register and Mitigation Strategy Matrix

**ID:** 20d2ed80-5adc-40f2-81c1-f4531db3acd8

**Description:** Comprehensive risk register documenting the 16 identified threats (corridor blockages, comms failure, authority gaps, Scenario Beta capacity, supply delays, hospital power loss, backcountry stragglers, multi-state authority conflicts, ashfall forecast error, responder fatigue, language/mobility access, public-message credibility, procurement delays, grid failure, landslide hazards, visitor accountability) with likelihood, severity, impact estimates, mitigation actions and residual-risk assessment. Updated continuously through Months 1–3 (2026-11-14 to 2027-01-14) as pre-event hardening actions are completed.

**Responsible Role Type:** Project Manager / Risk Manager

**Primary Template:** PMI Risk Register and Mitigation Plan Template

**Secondary Template:** FEMA Disaster Response Risk Assessment Framework

**Steps:**

- Compile 16 identified risks from the canonical facts and expert-review sections; for each, document: (1) description and threat vector, (2) likelihood (Low/Medium/High), (3) severity (Low/Medium/High), (4) impact estimate (personnel, time, cost, lives), (5) mitigation actions with owner and deadline, (6) residual risk after mitigation.
- Prioritize risks by product (likelihood × severity): highest = Scenario Beta secondary-stage plan gap, responder staffing exhaustion, ashfall forecast error placing shelters in plume.
- For each mitigation action, assign responsible role, specify deadline (pre-event Month -X or in-event T+Yh), and establish completion verification criteria (e.g., 'signed MOU obtained,' 'sensor deployed,' 'exercise report completed').
- Conduct risk-review meetings at Month 0 (2026-10-14) (T+0 to T+6h) and Month 1 (2026-11-14) to assess progress on pre-event actions and identify emerging risks.
- Document residual risks that cannot be fully mitigated: e.g., ashfall forecast uncertainty of ±50 km cannot be eliminated, only monitored and adapted to; 72-hour responder duration is intense by definition.
- Prepare contingency funding: reserve 20% of USD 200M envelope (USD 40M) for unexpected mitigation costs; identify triggers for contingency drawdown.

**Approval Authorities:** UC Incident Commander, Project Manager, FEMA Risk Officer

### 19. Funding Agreement Structure and Stafford Act Cost-Allocation Framework

**ID:** bf766ce9-30e5-4d8f-bdb6-3de6ebec769c

**Description:** Specifies federal cost-sharing mechanism under the Stafford Act emergency declaration. Outlines initial USD 200 million planning envelope (estimate, range USD 150–250 million), broken down as USD 160 million base operations and USD 40 million contingency (20% reserve). Details readiness-package costs (USD 47.5–87 million estimate): Scenario Beta hub pre-positioning (USD 20–40M), responder relief reserves (USD 3–5M), N95 and backup shelters (USD 10–15M), equipment and exercises (USD 5–15M). Identifies open decision: state vs. federal cost-share for shelter sites and secondary hubs; defers financing detail (cost-share %, reimbursement procedures) to Month 1 (2026-11-14) MOU negotiations.

**Responsible Role Type:** Financial Manager / FEMA Grants and Finance Officer

**Primary Template:** Stafford Act Emergency Funding and Cost-Allocation Procedures

**Secondary Template:** FEMA Public Assistance Program (PA) Eligible Costs and Reimbursement Rules

**Steps:**

- Obtain presidential emergency declaration under the Stafford Act by T+0, authorizing full federal cost reimbursement (100% federal share for emergency response).
- Establish baseline budget: USD 160 million operational envelope covers evacuations, sheltering, supply convoys, communications, Guard deployment and post-event recovery for Months 0–1 (2026-10-14 to 2026-11-14).
- Reserve USD 40 million contingency (20% of total) for unplanned shelter relocations, supply-convoy delays and emergency Guard reinforcement.
- Detail readiness-package costs (pre-event, Months -2 to -1 reframed as pre-T+0 actions): Scenario Beta hub pre-positioning 20–40M, responder reserves 3–5M, backup shelters and monitoring 10–15M, geotechnical surveys and exercises 5–15M.
- Specify that direct emergency-response costs (evacuation, sheltering, supply delivery, responder deployment) are 100% federally reimbursable under Stafford Act; identify which pre-event hardening costs (MOUs, exercises, monitoring equipment) are eligible for 75% federal match or full emergency funding.
- Document open decision: are secondary-hub shelter facilities and supply pre-positioning funded federally or cost-shared with host states? Resolve by Month 1 (2026-11-14).
- Establish payment procedures: FEMA Emergency Support Function (ESF-6 Mass Care & Sheltering) processes shelter and supply claims; ESF-5 (Emergency Management) processes responder and equipment claims; monthly reconciliation and reimbursement.
- Prepare for post-event audit: document all expenditures with detailed receipts and incident documentation; submit final accounting to FEMA Region VIII within 90 days of recovery period end.

**Approval Authorities:** FEMA Regional Administrator (Region VIII), Office of the Comptroller (FEMA), State Emergency Management Directors (cost-share negotiation), OMB (budget clearance for emergency spending >USD 100M)

### 20. Initial High-Level Schedule and Milestone Timeline

**ID:** 921f3f24-d7c7-470d-8cfc-53e4d0d70f5d

**Description:** Gantt-chart-format project timeline from Month 0 (2026-10-14, T+0 = project start and evacuation order) through Month 3 (2027-01-14). Phase 1 (T+0 to T+6h): Zone Zero evacuation via three contraflow exits; target Gate G1 = 98% of 35,800 out. Phase 2 (T+6 to T+24h): Zone One evacuation and shelter operations begin; target Gate G2 = 95% of Zone One residents out. Phase 3 (T+24 to T+72h): sustained shelter operations, supply convoys, responder relief rotation. Hardening Phase (Months 1–3, 2026-11-14 to 2027-01-14): signed MOUs, full-scale exercises, after-action report. Key dependencies: governor authorization by T+6h, Scenario Beta interim hub list by T+12h, written secondary-stage plan by Month 1 (2026-11-14).

**Responsible Role Type:** Project Manager

**Primary Template:** PMI Project Schedule and Gantt Chart Template

**Secondary Template:** FEMA Incident Action Plan Daily Schedule

**Steps:**

- Create high-level Phase 1 (T+0 to T+6h) critical path: Unified Command activation, governor authorization request (parallel), contraflow activation (T+1h), backcountry permit cancellation, ranger sweep deployment, checkpoint staffing, water-convoy dispatch.
- Create Phase 2 (T+6 to T+24h) activities: shelter intake and triage, Zone One resident evacuation and population census, Scenario Beta interim hub list publication, shelter relocation decision (if needed), responder relief rotation.
- Create Phase 3 (T+24 to T+72h) activities: sustained shelter operations, daily N95 consumption monitoring and resupply, hospital surge management, responder fatigue monitoring, perimeter enforcement transition from mobile to static, re-entry planning.
- Create Hardening Phase milestones: Month 1 (2026-11-14) = signed governor MOUs, FEMA Region 10 arrangements, written Scenario Beta secondary-stage plan. Month 2 (2026-12-14) = hub pre-positioning complete, all pre-event exercises completed. Month 3 (2027-01-14) = after-action report final, lessons-learned workshop.
- Identify critical dependencies: any delay in governor authorization delays shelter finalization; any delay in hub MOUs delays Scenario Beta plan; any delay in supply-chain contracts delays delivery schedules.
- Specify go/no-go gates: Gate G1 at T+6h (98% of 35,800 out, backcountry sweeps complete); Gate G2 at T+24h (95% of Zone One out, shelters staffed and supplied). If gates are missed, escalate to UC Incident Commander for contingency decisions.

**Approval Authorities:** UC Incident Commander, Project Manager

### 21. Monitoring and Evaluation (M&E) Framework and Success Metrics

**ID:** 7f9db310-8db5-4f8a-934f-ed8a69573f05

**Description:** Performance-measurement framework defining success metrics for each phase and post-event evaluation criteria. Phase 1 success: ≥98% of 35,800 confirmed out by T+6h (measured via exit checkpoint counts and permits reconciliation); <500 backcountry stragglers remaining (measured via permit check-ins); zero fatalities due to evacuation congestion. Phase 2 success: ≥95% of registered Zone One residents out by T+24h; shelters operational with <4 hours intake lag; water and N95 supplies available at all sites; 0% looting in evacuated towns. Phase 3 success: zero preventable respiratory or medical deaths attributable to delayed hospital transfer; 90% responder completion of assigned shifts without injury. Cost-effectiveness: total cost per person evacuated; cost per prevented death; comparison with pre-plan estimates.

**Responsible Role Type:** Project Manager / Monitoring & Evaluation Officer

**Primary Template:** PMI Project Performance Measurement Framework

**Secondary Template:** FEMA Disaster Response Effectiveness Metrics and After-Action Review

**Steps:**

- Define Phase 1 (T+0 to T+6h) key metrics: (1) cumulative exit counts (target 98% of 35,800 = ~35,084 by T+6h); (2) average corridor throughput (target 660 vehicles/hour per exit); (3) blockage incidents and resolution time (target zero >45 minute blockages); (4) backcountry permit check-in rate (target 95%+ of outstanding permits responding hourly); (5) deaths or serious injuries during evacuation (target zero).
- Define Phase 2 (T+6 to T+24h) metrics: (1) Zone One evacuation % (target ≥95%); (2) shelter intake lag (target <4 hours from exit to shelter arrival); (3) N95 and water per-capita availability at shelters (target 2.8 masks per person, 4 L/person/day); (4) medical triage processing time (target <30 min per evacuee); (5) looting incidents (target zero).
- Define Phase 3 (T+24 to T+72h) metrics: (1) hospital patient-transfer completion for critical cases (target 100% transferred within 6 hours of request); (2) respiratory-distress case volume and mortality (target <0.1% mortality among treated cases); (3) responder injury and illness rate (target <2%); (4) supply-convoy on-time delivery (target 100% by stated arrival window).
- Define cost-effectiveness metrics: (1) total cost per person evacuated (compare actual to USD 200M estimate); (2) cost per prevented death (estimate using epidemiologic baseline); (3) cost per responder shift-completed (evaluate relief depth adequacy).
- Establish real-time data collection: checkpoint staff record exit counts hourly; shelter managers log intake volume, N95 use and water consumption daily; UC maintains incident log of all major events, decisions and resource requests.
- Schedule post-event evaluation: Month 2 (2026-12-14) preliminary after-action report with preliminary metrics; Month 3 (2027-01-14) final report with complete data analysis and lessons-learned workshop.
- Compare actual metrics against pre-plan estimates; document any variances and root causes (forecast errors, supply delays, staffing shortfalls, gate overruns).

**Approval Authorities:** UC Incident Commander, Project Manager, FEMA Regional Administrator

### 22. Detailed Operational Playbook (Decision Matrix, Trigger Points, Contingency Procedures)

**ID:** 5e3596fb-452d-44da-b445-6ff9eeb3086e

**Description:** Hour-by-hour operational playbook covering T+0 through T+72h, specifying: (1) UC briefing cadence and decision points (e.g., at T+3h, confirm Scenario Beta trigger thresholds; at T+6h, report on Gate G1 compliance and obtain governor authorization), (2) traffic-management operations (contraflow lane reversals, checkpoint staffing, blockage diversion), (3) shelter intake and triage procedures (arrival rate, processing lag, N95 and water distribution), (4) supply-convoy dispatch and delivery monitoring, (5) medical-patient routing and hospital surge activation, (6) responder shift-rotation and fatigue-management checks, (7) communications message updates and public announcements. Specifies contingency procedures for missed gates (if <98% clear by T+6h, activate secondary plans), authority gaps (Boundary Coordination Officer escalation procedures), and failure scenarios (blockage >6h, grid failure, communications loss).

**Responsible Role Type:** Project Manager / Unified Command Incident Commander

**Primary Template:** NIMS/ICS Incident Action Plan (IAP) with detailed decision matrix

**Secondary Template:** Tactical Operations Playbook Template (military or emergency-response precedent)

**Steps:**

- Compile the 14 pre-authorized decisions (Egress, Escalation, Command, Communications, Shelter, Supply, Hospital, Perimeter, Airspace, Accountability, Shadow Evacuation, Language Access, Landslide, Responder Limits) into a single decision matrix specifying: decision point (T+Xh), decision owner (UC Incident Commander or delegated), success criteria (yes/no or quantified threshold), and go/no-go contingency actions.
- Define UC briefing schedule: T+0 (activation), T+1h, T+3h (Scenario Beta trigger confirmation), T+6h (Gate G1 assessment), T+12h (interim Scenario Beta hub list if Beta triggered, Gate G1 final), T+18h (supply convoy status), T+24h (Gate G2 assessment), then every 6 hours through T+72h.
- For each major operation (contraflow, shelter intake, supply delivery), specify hourly status updates, bottleneck-detection triggers (e.g., if checkout lag exceeds 30 min, activate secondary staging), and diversion/contingency authority (who decides, by what rule).
- Build in redundancy: specify which decisions can be delegated to Boundary Coordinator or logistics officer if UC communication is lost >5 minutes; specify satellite-phone backup procedures.
- Document missed-gate contingencies: if <98% out by T+8h (instead of T+6h), declare Gate G1 failure and activate shelter-in-place for remaining vehicles; if <95% Zone One out by T+30h (instead of T+24h), activate long-term shelter operations and medical surge protocols.
- Test the playbook in a tabletop exercise with the full UC by Month 3 (2027-01-14).

**Approval Authorities:** UC Incident Commander, Project Manager

### 23. Multi-State Memoranda of Understanding (MOUs) and Mutual-Aid Agreements

**ID:** 997285db-b65a-4c9b-8bfc-1f8f7b37667c

**Description:** Collection of signed MOUs covering: (1) governor authorization of Unified Command Zone One and Scenario Beta orders (MT, WY, ID governors); (2) NPS-to-state boundary-authority transfer and mutual-aid resource requests (state DOTs, highway patrol, Guard); (3) FEMA Region 8/10 coordination and inter-regional mutual aid; (4) hospital mutual aid and patient-transfer agreements; (5) utility-system coordination (power, water, fuel); (6) secondary-hub acceptance and capacity commitments (Denver, Cheyenne, and backup hubs outside the 500 km ring). Each MOU specifies resource commitments, cost-sharing, activation procedures and dispute-resolution. Target completion: Months 1–2 (2026-11-14 to 2026-12-14).

**Responsible Role Type:** Regional Emergency Management & Multi-Jurisdiction Coordination Director

**Primary Template:** Standard EMAC (Emergency Management Assistance Compact) and Multi-State MOU Templates

**Secondary Template:** Interagency Cooperation Agreement (mutual-aid precedent from hurricane response)

**Steps:**

- Draft governor MOU template: specifies UC authority, cost-sharing (100% federal under Stafford Act or cost-share %), and automatic mutual-aid activation language. Obtain signatures from MT, WY, ID governors (or designees) by Month 1 (2026-11-14).
- Draft state DOT/highway patrol boundary-handoff protocol: specifies exact transfer checkpoints (Mammoth, Gallatin County line, Cody limits), defines state authority scope (traffic management on state roads), and pre-authorizes reroutes without NPS approval.
- Draft hospital mutual-aid agreement: specifies patient-transfer procedures, receiving-hospital bed pre-commitments and inter-hospital communication protocols.
- Draft Scenario Beta hub MOUs with Denver, Cheyenne and backup hubs: specifies shelter-bed capacity, medical-staff deployment, 48-hour mobilization commitment, pre-positioned supply quantities and cost-reimbursement procedures.
- Draft FEMA Region 8/10 coordination MOU: specifies mutual-aid resource lists (Guard units, supply depots, logistics support), pre-authorized 6-hour dispatch procedures and cost-sharing.
- Consolidate all MOUs into a binding multi-party agreement with contingency-dispute procedures.

**Approval Authorities:** Governors of Montana, Wyoming, Idaho, Colorado, Utah; State Emergency Management Directors; FEMA Regional Administrators (Region 8, Region 10); Hospital Administrators; County Commissioners (hub host communities)

### 24. Pre-Event Training and Exercise Schedule with After-Action Report Framework

**ID:** c2e0121b-d127-4d3b-9f02-c6a9573961db

**Description:** Comprehensive training and exercise schedule from Month -2 (2026-08-14) through Month 3 (2027-01-14). Includes: (1) technical training for UC staff on NIMS/ICS, decision matrices and communications protocols (Month -1.5, 2026-08-29); (2) multi-state command-authority exercise testing boundary handoff and escalation (Month -1.5, 2026-08-29); (3) full-scale contraflow terminus and equipment-deployment exercise (Month -0.5, 2026-09-29); (4) shift-rotation and responder-fatigue exercise (Month -0.5, 2026-09-29); (5) shelter intake and triage exercise (Month -0.5, 2026-09-29); (6) water-convoy and supply-chain exercise under simulated ashfall (Month -0.5, 2026-09-29); (7) Scenario Beta multi-state routing and hub-intake exercise (Month -0.5, 2026-09-29); (8) post-event after-action report (Month 2, 2026-12-14 preliminary; Month 3, 2027-01-14 final). Each exercise includes participant list, objectives, performance metrics and documented findings.

**Responsible Role Type:** Project Manager

**Primary Template:** FEMA Exercise Design and Evaluation Guide (HSEEP)

**Secondary Template:** After-Action Report Framework and Lessons-Learned Format

**Steps:**

- Develop exercise objectives for each event: e.g., 'Multi-state command exercise validates authority handoff procedures, tests UC briefing protocols and identifies any jurisdictional gaps.'
- Specify exercise participants: full UC at Month -1.5 (2026-08-29); functional exercises (traffic control, shelter intake, supply delivery) at specific locations (Mammoth for traffic, Bozeman for shelter, Salt Lake City for convoy) on Month -0.5 (2026-09-29) on different dates to avoid responder overload.
- Define performance metrics for each exercise: e.g., 'Evacuation terminus survey measures queue storage and throughput; target 660 veh/h per exit.' 'Shift-rotation exercise measures relief-handoff time; target 15 min.'
- Schedule full-scale Scenario Beta exercise (Month -0.5, 2026-09-29) involving all states and hubs, processing sample evacuees through intake and onward routing; measure end-to-end processing time.
- Prepare after-action report (AAR) framework: template specifies findings by operation (traffic, shelter, supply, command), recommendations for improvement, residual risks not mitigated, and lessons for future response. Month 2 (2026-12-14) AAR covers exercises and pre-event hardening actions. Month 3 (2027-01-14) AAR covers actual evacuation performance (if event occurs) or captures readiness status.
- Establish lessons-learned workshop (Month 3, 2027-01-14) with all stakeholders to synthesize findings and institutionalize improvements for future volcanic-hazard planning.

**Approval Authorities:** UC Incident Commander, Project Manager, State Emergency Management Directors, FEMA Regional Administrators

### 25. Public Information and Media Strategy Plan

**ID:** d31185d2-3b34-498c-8b67-f617d9e607a2

**Description:** Pre-event public-information strategy specifying: (1) pre-event media briefing schedule explaining Yellowstone volcanic hazard, evacuation zones, escalation triggers (USGS indicators) and shelter-in-place messaging logic; (2) 24/7 media hotline and briefing schedule during the 72-hour window; (3) press-release templates for key milestones (Zone Zero clearance at T+6h, Zone One clearance at T+24h, Scenario Beta activation if triggered); (4) social-media updates via official channels (NPS, state emergency management, UC public information officer); (5) website with real-time evacuation status, shelter locations, registration information and family-reunification tools; (6) multilingual messaging strategy (five visitor languages); (7) message consistency protocols across agencies to prevent conflicting instructions. Specifies public information officer roles and 24/7 staffing.

**Responsible Role Type:** Communications and Public Alerting Coordinator / Public Information Officer

**Primary Template:** FEMA Public Affairs and Public Information Operations Plan

**Secondary Template:** Crisis Communications and Message-Consistency Framework

**Steps:**

- Develop pre-event media briefing calendar (Months -1 through Month 0 = 2026-10-14): monthly briefings to regional media (AP, Reuters, local TV/radio) explaining volcanic-hazard context, evacuation plans and escalation triggers. Goal: build media understanding and trust before the event begins.
- Draft press-release templates for key milestones and pre-authorize their release by the UC Public Information Officer (PIO). Examples: 'Zone Zero declared clear at T+6h: 98% of 35,800 evacuees confirmed out,' 'Zone One evacuation underway; residents assigned to [shelter location],' 'Scenario Beta activated due to [trigger condition]; additional ring evacuation orders issued.'
- Establish 24/7 media hotline and briefing schedule: UC PIO conducts briefings at T+0, T+3h, T+6h, T+12h, T+24h and then every 6 hours through T+72h. Briefings provide status updates, decision announcements and address journalist questions.
- Create evacuation-status website: real-time map showing Zone Zero/One boundaries, confirmed-clear areas, shelter locations, registration portals and family-reunification information. Accessible in English and five visitor languages.
- Draft social-media update strategy: specify which agencies post to official accounts (NPS, state emergency management, UC); coordinate messaging to avoid contradictions; use consistent hashtags and terminology.
- Pre-produce multilingual messaging in partnership with concessioners, tour operators and consular liaisons.
- Establish message-consistency protocols: UC PIO approves all media releases and public announcements before they are issued; agencies must use approved terminology and avoid improvised messaging.

**Approval Authorities:** UC Incident Commander, Public Information Officer, State Emergency Management Public Affairs Directors, NPS Public Affairs Office

## Documents to Find

### 1. USGS Yellowstone Volcano Observatory Monitoring Data and Eruption Probability Assessments

**ID:** fef7b2b0-b693-4184-9ba5-820cd32d7d41

**Description:** Real-time USGS seismic, GPS, gas-emission and thermal data from Yellowstone Caldera monitoring network, including current uplift rates (mm/year), seismic magnitude and frequency distributions, SO2 flux measurements and any published eruption-probability or VEI forecasts. Serves as the scientific input for the Escalation Trigger Matrix and the pre-authorized Scenario Beta decision rule. Intended audience: UC Incident Commander, USGS liaison officer, volcanologist advisor. Context: the plan requires final trigger indicator values by T+3h; this data is the baseline and must be collected and analyzed before the 72-hour window begins.

**Recency Requirement:** Current real-time data required from T-12 hours onward; historical baseline data (2020-present) useful for establishing normal variability and defining anomaly thresholds.

**Responsible Role Type:** Volcanologist & USGS Hazard Forecaster

**Access Difficulty:** Easy. USGS YVO maintains public real-time seismic and GPS dashboards; scientists are typically available for direct consultation and pre-event coordination calls. Data is non-classified and freely available.

**Steps:**

- Contact USGS Yellowstone Volcano Observatory (Vancouver, WA office or online portal: https://volcanoes.usgs.gov/observatories/yellowstone/) and request access to real-time monitoring dashboards and weekly eruption-probability briefings.
- Download monthly USGS Yellowstone monitoring report (published by YVO) covering uplift, seismicity and gas measurements; identify baseline variability and recent deviations.
- Request any available eruption-scenario modeling or VEI-probability assessments from USGS; clarify which indicators (if any) are established as 'eruption precursors' at Yellowstone vs. other volcanoes.
- Establish Standing data-sharing agreement with YVO to receive real-time alerts if monitoring parameters exceed established thresholds or if scientists issue any formal eruption forecast.

### 2. NOAA Volcanic Ash Forecast Transport (VAFT) Model Outputs and Wind Forecast Data

**ID:** 7c60f88d-38a4-4f23-a83c-d28f45f81bfa

**Description:** Current and historical ashfall-dispersion model output from NOAA's Volcanic Ash Forecast Transport system, showing predicted PM10 concentrations at multiple altitudes and distances from Yellowstone Caldera under various eruption scenarios and wind profiles. Includes 12-hour wind forecasts from Global Forecast System (GFS) and high-resolution local models. Serves as the input for the Shelter Siting Decision Rule (T+6h) and dynamic relocation protocols. Intended audience: Ashfall Forecasting Officer, shelter managers, air-quality specialists. Context: forecast uncertainty is estimated at ±50 km; pre-event access and testing of model output is essential to validating shelter-siting thresholds.

**Recency Requirement:** Current wind forecasts and VAFT model updates required every 3-6 hours from T-24h through T+72h. Historical ashfall-plume scenarios (e.g., Mount St. Helens 1980, Eyjafjallajökull 2010) useful for model validation and sensitivity analysis.

**Responsible Role Type:** Ashfall Forecasting and Dynamic Shelter-Siting Officer / Volcanologist & USGS Hazard Forecaster

**Access Difficulty:** Medium. VAFT model output is available through NOAA, but requires pre-event data-sharing agreements and specific request for Yellowstone-scenario initialization. Wind forecasts are freely available from NCEP.

**Steps:**

- Contact NOAA's Hazardous Weather Testbed (Norman, OK) and National Weather Service Forecast Office (Billings or Riverton, WY) to request VAFT model documentation and access to model output.
- Download high-resolution GFS wind forecasts for the Yellowstone region from NOAA's National Centers for Environmental Prediction (NCEP) website or via direct data request.
- Request any archived ashfall-plume simulations for Yellowstone eruption scenarios (if available) or equivalent documentation from USGS/NOAA describing plume heights, ashfall patterns and concentration profiles for VEI-6 eruptions.
- Establish pre-event agreement with NOAA to provide 3-hourly VAFT updates and 12-hour wind-forecast products to the forward UC element from T-24h through T+72h, with direct communication to the Ashfall Forecasting Officer.

### 3. Current Yellowstone National Park Visitor and Staff Census Data

**ID:** 5bada706-5efa-40fe-848c-e249d21d9790

**Description:** Current visitor census data for Yellowstone National Park: estimated daily visitor counts by season, lodging occupancy (via Xanterra concession records), campground registrations, backcountry permit issuance rates, and staff employment counts. Provides baseline for the 35,000 tourists and 800 staff estimate in the canonical facts, and enables refinement of shelter-capacity requirements if actual occupancy differs from assumption. Intended audience: Project Manager, shelter planners, population-estimators. Context: the plan assumes 35,800 evacuees for Zone Zero; if actual peak-season occupancy is higher or lower, shelter and corridor capacity calculations must be adjusted.

**Recency Requirement:** Most recent available year (2024–2025 season data preferred); monthly breakdowns to identify peak occupancy periods and seasonal variation.

**Responsible Role Type:** Project Manager / Shelter Planner

**Access Difficulty:** Easy. NPS maintains public visitor-use statistics on its website; Xanterra occupancy data can be requested through official channels (pre-event coordination).

**Steps:**

- Contact Yellowstone National Park Public Affairs office (Mammoth Hot Springs, WY, or online at nps.gov/yell) and request current visitor-use statistics and seasonal occupancy forecasts.
- Obtain lodging occupancy data from Xanterra Parks and Resorts (concessioner operating all park hotels and campgrounds); request monthly bed-occupancy rates and typical staff counts.
- Request NPS backcountry permit data: typical number of active permits (by date), geographic distribution of permit holders and average party size.
- Cross-reference with NPS entrance-fee statistics and vehicle-count data at each of the three main entrances to validate visitor-population estimates.

### 4. Zone One Registered Resident Population Census (West Yellowstone, Gardiner, Cody and Surrounding 100 km Radius)

**ID:** 773771a1-c3cc-4223-9215-45c3086368c1

**Description:** Registered resident population data for communities within 100 km of Yellowstone Caldera center: West Yellowstone (Madison County, MT), Gardiner (Park County, MT), Cody (Park County, WY) and surrounding unincorporated areas. Includes baseline population (permanent residents), seasonal residents, and transient populations (hotels, RVs). Serves as the denominator for Zone One evacuation success metrics (Gate G2: 95% of registered residents out by T+24h). Intended audience: Project Manager, Zone One evacuation coordinator, shelter capacity planner. Context: the canonical facts list Zone One as 'not quantified'; a census is required by T+6h to confirm shelter capacity is adequate.

**Recency Requirement:** Most recent decennial Census (2020 Census data from U.S. Census Bureau); supplemented with county population estimates for 2024–2025.

**Responsible Role Type:** Project Manager / Emergency Manager (MT, WY counties)

**Access Difficulty:** Easy. U.S. Census data is freely available; county population data can be requested from county emergency managers. Seasonal-occupancy estimates require chamber-of-commerce coordination but are typically available.

**Steps:**

- Contact Madison County, Park County (Montana) and Park County (Wyoming) County Clerk / Emergency Management offices and request current registered resident counts and voter-registration data as proxy for residential population.
- Download 2020 U.S. Census Bureau data for West Yellowstone city (Madison County, MT), Gardiner census-designated place (Park County, MT) and Cody city (Park County, WY) from census.gov.
- Request seasonal/transient population estimates from local chambers of commerce (West Yellowstone Chamber, Gardiner Chamber, Cody Chamber) based on hotel and RV-park occupancy data.
- Coordinate with Montana and Wyoming emergency management to develop a rapid census-update protocol (online survey or phone canvassing) for T+6h status confirmation during the evacuation window.

### 5. Existing Regional Hospital Bed Capacity, Emergency Department Surge Plans and Current Staffing Rosters

**ID:** 5107aec8-e81d-4dd8-91f0-21ce7950c3f6

**Description:** Current bed-capacity inventories, emergency-department surge protocols and staffing rosters for the three designated receiving hospitals (Bozeman Deaconess Medical Center, Livingston HealthCare, Eastern Idaho Regional Medical Center, Idaho Falls). Includes baseline bed counts (ICU, trauma, respiratory), current staffing (emergency physicians, respiratory therapists, nurses), and any existing mass-casualty or disaster-surge expansion plans. Serves as input for hospital-surge dispersal planning and identification of pre-emptive patient transfers. Intended audience: Hospital Surge Dispersal Officer, hospital administrators, public health officer. Context: the plan assumes base surge capacity at three hospitals; this data enables real capacity validation and identification of staffing gaps.

**Recency Requirement:** Current (2024–2025) hospital census data, bed-capacity inventories and staffing rosters.

**Responsible Role Type:** Public Health & Mass-Casualty Medical Logistics Director / Hospital Administrator

**Access Difficulty:** Medium. Hospital bed-capacity and staffing data are sensitive (federal reporting required for Medicare facilities); access requires pre-event formal coordination and confidentiality agreements. State health departments may have aggregate data available.

**Steps:**

- Contact administrative offices of Bozeman Deaconess Medical Center, Livingston HealthCare and Eastern Idaho Regional Medical Center directly and request current bed-capacity inventories, ED surge plans and staffing rosters (may require formal data-sharing agreement and confidentiality assurance).
- Request any existing hospital emergency operations plans or disaster-response protocols that address mass-casualty surge or infectious-disease isolation.
- Obtain Ambulance Services and EMS routing data from county EMS coordinators to understand current patient-transport capacity and hospital destination protocols.
- Coordinate with state health departments (Montana, Wyoming, Idaho) to obtain aggregate hospital-capacity data and mutual-aid surge-capacity estimates from other hospitals in the region.

### 6. Existing Yellowstone National Park Concessioner Operational Data (Lodging Occupancy, Staff Rosters, Transportation Fleet)

**ID:** d57f35c4-4e32-43dd-a64b-a8b280ab4b13

**Description:** Operational data from Xanterra Parks and Resorts (primary NPS concessioner): current guest-room inventory and occupancy forecasts, staff employment rosters (count and job functions), shuttle-bus fleet capacity and scheduling, and visitor-transportation logistics. Serves as input for visitor-needs assessment (language, mobility, vehicle-less populations) and assisted-evacuation planning. Intended audience: Communications Coordinator, visitor-needs planner, transportation logistics officer. Context: concessioners manage ~90% of visitor accommodation and some visitor transport; pre-event data access enables targeted multilingual outreach and transport pre-positioning.

**Recency Requirement:** Current (2024–2025 season) occupancy forecasts, staff rosters and fleet inventory.

**Responsible Role Type:** Communications and Public Alerting Coordinator / Shelter Planner

**Access Difficulty:** Medium. Concessioner operational data is sensitive (commercially confidential for occupancy and forecasts); requires signed data-sharing agreement with Xanterra and NPS. Pre-event coordination is expected and typically feasible.

**Steps:**

- Contact Xanterra Parks and Resorts operational headquarters (located near Mammoth or in Denver) and request operational data-sharing agreement covering lodging occupancy, staff rosters, guest-contact information and transportation capacity.
- Request manifests of current guests at each lodge (rooms occupied, check-in/check-out dates, nationality/language preferences if available from reservation systems).
- Obtain shuttle-bus inventory and capacity: number of buses, typical routes, seating capacity, and driver availability during peak operations.
- Request any existing concessioner emergency plans or disaster-response protocols.

### 7. Existing Evacuation Plans and Contraflow Operations Documentation (Texas, Louisiana, Florida Precedents and DOT Guidance)

**ID:** b5ef0bd5-a5b7-4fad-a7a8-a76dc3d93f03

**Description:** Existing evacuation and contraflow-operations documentation from prior hurricane evacuations (Hurricane Rita, Texas, 2005; Hurricane Katrina, Louisiana, 2005; Hurricane Irma, Florida, 2017) and FHWA/USDOT guidance on contraflow setup, termini design, and bottleneck mitigation. Provides comparative context and best-practice templates for the three-exit contraflow design. Intended audience: Contraflow Operations Manager, traffic engineer. Context: Yellowstone evacuation is unique, but contraflow logistics can leverage lessons from large hurricane evacuations.

**Recency Requirement:** Published after-action reports and case studies from 2005 onward; FHWA guidance updated within the last 5 years.

**Responsible Role Type:** Transportation Operations & Contraflow Specialist

**Access Difficulty:** Easy. FHWA and state DOT guidance is publicly available online; academic research (Texas A&M) is available through university repositories or direct request.

**Steps:**

- Contact Federal Highway Administration (FHWA) Office of Operations (1200 New Jersey Ave SE, Washington, DC 20590, or ops.fhwa.dot.gov) and request evacuation planning and contraflow guidance documents.
- Search for Texas A&M Transportation Institute (TTI) Hurricane Rita evacuation study and lessons-learned reports (https://tti.tamu.edu); request case-study data on contraflow timing, throughput and shadow evacuation.
- Contact Texas Department of Transportation (TxDOT) Traffic Operations Division and request contraflow-operations planning manuals and implementation procedures.
- Search for California Highway Patrol and Cal OES Camp Fire evacuation after-action reviews (2018) covering contraflow and mountain-road evacuation logistics.
- Contact FHWA Regional Offices for any existing Yellowstone evacuation studies or emergency-response plans.

### 8. Current Stafford Act Procedures and FEMA Emergency Declaration Templates

**ID:** 2ea1e103-7081-4515-ae47-b09a8246765b

**Description:** Current Stafford Act regulatory procedures, emergency-declaration eligibility criteria, cost-sharing rules and reimbursement processes. Includes FEMA Emergency Support Function (ESF-5 Emergency Management, ESF-6 Mass Care and Sheltering) operational procedures and eligible-cost definitions. Serves as the framework for the Funding Agreement Structure and financial feasibility assessment. Intended audience: FEMA Financial Manager, UC Incident Commander. Context: the plan assumes Stafford Act declaration authority; this documentation enables detailed cost-allocation and reimbursement-procedure planning.

**Recency Requirement:** Current (2024–2025) Stafford Act regulations and FEMA guidance; any recent updates to cost-sharing or emergency-declaration procedures.

**Responsible Role Type:** Financial Manager / FEMA Grants and Finance Officer

**Access Difficulty:** Easy. FEMA regulations and ESF plans are publicly available on FEMA.gov and in the Code of Federal Regulations (CFR Title 44).

**Steps:**

- Contact FEMA Headquarters (Public Affairs or Office of Response and Recovery) and request current Stafford Act procedures manual and emergency-declaration templates.
- Download FEMA Emergency Support Function (ESF) operational plans (ESF-5, ESF-6) from fema.gov/emergency-support-function.
- Request guidance on eligible costs for emergency evacuation, mass shelter operations and disaster-supply procurement under Stafford Act authority.
- Coordinate with FEMA Region VIII and Region 10 to clarify cost-sharing arrangements and reimbursement timelines for a multi-state disaster response.

### 9. Bottled Water, N95 Respirator, Generator Fuel and Emergency Supply Industry Capacity and Pricing Data

**ID:** a333ea0c-28d1-45b6-9a43-4b13f85482c9

**Description:** Current industry capacity and pricing for emergency supplies: bottled-water production and distribution capacity in the Mountain West (estimated liters per day from major suppliers), N95 respirator stock and manufacturing capacity (units available for emergency order), diesel generator fuel distribution networks and regional storage capacity, and medical/shelter equipment availability (cots, blankets, food, hygiene kits). Serves as input for supply-chain feasibility assessment and contract-negotiation planning. Intended audience: Emergency Logistics and Supply-Chain Director, procurement officer. Context: the plan assumes 1.43 million liters water, 100,000+ N95 masks, 72-hour generator fuel at hospitals; this data validates supply-chain feasibility and lead times.

**Recency Requirement:** Current (2024–2025) industry capacity estimates, lead times and pricing; supply-chain disruption data post-COVID.

**Responsible Role Type:** Supply Chain & Logistical Resilience Strategist

**Access Difficulty:** Medium. Industry data is commercially sensitive; requires direct corporate inquiry and pre-event negotiations. State emergency management agencies may have supplier contact rosters from prior disaster agreements.

**Steps:**

- Contact major bottled-water distributors (Coca-Cola, Nestlé, regional distributors) in the Mountain West (Salt Lake City, Denver, Pocatello, Billings areas) and request capacity, lead-time and pricing for bulk emergency orders.
- Contact N95 respirator manufacturers (3M, Honeywell) and medical-supply distributors and request emergency-order lead times and maximum-available inventory.
- Contact diesel-fuel wholesalers and regional fuel-distribution networks (Yellowstone Energy, Basin Fuel, regional refineries) and request capacity for emergency tanker dispatch.
- Contact medical-supply rental companies (emergency shelter equipment, cots, generators) and request rapid-deployment inventory and pricing.
- Consult Federal Emergency Management documentation on FEMA contract vehicle activation and pre-positioned supply strategies for disasters.

### 10. FEMA Region 8 and Region 10 Mutual Aid and Emergency Support Function (ESF) Resource Inventories

**ID:** 425089ab-8957-4fc5-8b04-e28ea2697075

**Description:** Current mutual-aid rosters and Emergency Support Function resource inventories for FEMA Regions 8 (Denver, covering Colorado, Montana, North Dakota, South Dakota, Utah, Wyoming) and Region 10 (Seattle, covering Alaska, Idaho, Oregon, Washington). Includes Guard unit locations and availability, pre-positioned supply stocks, medical-surge resources and transportation capacity. Serves as input for responder relief depth, supply-chain and military-asset pre-positioning planning. Intended audience: UC Incident Commander, Region 10 Liaison Officer, logistics directors. Context: the plan assumes access to Guard units and mutual-aid resources; this documentation enables specific asset identification and pre-event commitments.

**Recency Requirement:** Current (2024–2025) mutual-aid rosters and ESF inventories; any recent updates to unit locations or resource availability.

**Responsible Role Type:** Regional Emergency Management & Multi-Jurisdiction Coordination Director / FEMA Region 10 Liaison Officer

**Access Difficulty:** Medium. FEMA regional resource data is partially restricted (Guard unit locations may be sensitive); requires pre-event formal coordination with FEMA regional administrators. State emergency management agencies maintain public mutual-aid rosters.

**Steps:**

- Contact FEMA Regional Administrators (Region 8, Denver office and Region 10, Seattle office) and request current mutual-aid rosters and ESF resource inventories.
- Request National Guard unit rosters and availability: location of Guard units in Colorado, Montana, Wyoming and Idaho; air assets (helicopters, cargo planes) in the region; personnel available for emergency deployment.
- Request state emergency management agency contact lists for mutual-aid coordination (each state's Emergency Management Division).
- Obtain EMAC (Emergency Management Assistance Compact) resource lists for the relevant states and neighboring states.

### 11. FAA Airspace Restrictions and Volcanic-Ash Grounding Procedures (NOTAM, Section 91.3 Emergency Authority)

**ID:** 1b2c1a6a-cc5a-4ed9-bb1b-18673ee5b3d6

**Description:** FAA procedures for Notice to Airmen (NOTAM) airspace closure and volcanic-ash emergency operations: FAA Section 91.3 emergency authority procedures, pre-authorization of government flights under emergency conditions, and coordination between FAA regional offices and incident commanders. Includes precedent from Mount St. Helens (1980) and Eyjafjallajökull (2010) airspace closures. Serves as input for the Ash-Cloud Airspace Closure and Humanitarian Flight Exceptions Protocol. Intended audience: Aviation Safety Liaison, UC Incident Commander, FAA Regional Coordinator. Context: the plan assumes FAA grounding and narrow exceptions; this documentation clarifies pre-event coordination steps and authorization procedures.

**Recency Requirement:** Current FAA regulations (Title 14 CFR Part 91); Section 91.3 emergency authority; any FAA volcanic-ash operational guidance updated within the last 10 years.

**Responsible Role Type:** Aviation Safety & Airspace Management Liaison

**Access Difficulty:** Easy. FAA regulations are publicly available in CFR and on FAA.gov; direct coordination with FAA regional offices may require formal advance notice but is standard for emergency-response planning.

**Steps:**

- Contact FAA Headquarters (Aircraft Operations Division or Emergency Response Coordination Center) and request FAA Section 91.3 emergency-authority procedures and NOTAM airspace-closure templates.
- Request FAA guidance on volcanic-ash airspace operations and rotary-wing medevac exceptions under emergency conditions.
- Contact FAA Salt Lake City Air Route Traffic Control Center (ZLC ARTCC) and FAA Seattle ARTCC (ZSE ARTCC) and request coordination procedures for Yellowstone eruption scenario airspace closure.
- Download Code of Federal Regulations Title 14 CFR Part 91 (General Operating and Flight Rules) from ecfr.gov and review Section 91.3 emergency authority.
- Contact ICAO (International Civil Aviation Organization) and request any volcanic-ash airspace closure best practices or guidance from international precedents.

### 12. Montana, Wyoming and Idaho Governor Emergency Declaration Authorities and State Emergency Management Plans

**ID:** 95aae559-8fd0-460b-a695-9a7e484c887e

**Description:** Current state emergency-management plans, governor emergency-declaration authorities and automatic mutual-aid activation procedures for Montana, Wyoming and Idaho. Includes state-specific evacuation protocols, National Guard mobilization procedures and cost-sharing rules for emergency response. Serves as input for Command Structure and Authority Framework and Stafford Act cost-allocation negotiations. Intended audience: UC Incident Commander, governors' representatives, emergency managers. Context: the plan requires governor pre-authorization (verbal by T+6h, signed by Month 1 = 2026-11-14); this documentation clarifies state-level procedures and legal authorities.

**Recency Requirement:** Current (2024–2025) state emergency-management plans and governor executive orders governing emergency declarations.

**Responsible Role Type:** Regional Emergency Management & Multi-Jurisdiction Coordination Director

**Access Difficulty:** Easy. State emergency-management plans are typically public documents or available through formal request. Governor offices maintain public lists of emergency contacts.

**Steps:**

- Contact State Emergency Management Divisions (Montana Disaster and Emergency Services, Wyoming Emergency Management Agency, Idaho Office of Emergency Management) and request copies of current state emergency-management plans and governor emergency-declaration procedures.
- Request state-specific evacuation and shelter-operations guidelines.
- Obtain contact information for each governor's emergency-operations liaison and chief legal counsel (for authority-transfer negotiations).
- Review state constitutions and statutes governing governor emergency powers and mutual-aid activation (typically available on state legislature websites).

### 13. Current Yellowstone National Park Infrastructure and Facility Rosters (Lodging, Utilities, Medical Facilities, Communications Systems)

**ID:** 467e105d-8fea-408e-9671-921c8fc786c9

**Description:** Current NPS facility inventories: all lodging properties within and adjacent to Yellowstone (Mammoth Hot Springs Hotel, Old Faithful Inn, Lake Yellowstone Hotel, Canyon Village Lodge, Grant Village, etc.), water and sanitation systems, electrical distribution, backup power systems, communications infrastructure (cell towers, radio repeaters) and park medical facilities (clinics at Mammoth, Old Faithful, Grant). Serves as baseline for understanding park evacuation logistics, utility vulnerabilities and communications pre-positioning requirements. Intended audience: Project Manager, facilities coordinator, communications officer. Context: evacuation success depends on understanding park infrastructure constraints (e.g., capacity of staging lots, backup-power availability, water-system vulnerability to ashfall).

**Recency Requirement:** Current (2024–2025) facility inventories and infrastructure status.

**Responsible Role Type:** Project Manager / NPS Facilities Manager

**Access Difficulty:** Easy. NPS maintains public facility information; facility details and infrastructure status can be requested through park administration (Superintendent's office).

**Steps:**

- Contact Yellowstone National Park Facilities Management Division (Mammoth, WY) and request current facility rosters, capacity inventories and infrastructure system diagrams.
- Request utilities data: water distribution (reservoir capacity, treatment capacity, distribution network), electrical power supply (substations, backup generators, fuel reserves), communications infrastructure (cell towers, radio repeaters, satellite systems).
- Obtain facility occupancy data: typical bed count at each lodge (Mammoth, Old Faithful, Lake, Canyon, Grant, etc.) and staff housing capacity.
- Request any existing park disaster-response or emergency-operations plans that may address evacuation or facility management during emergencies.

### 14. Mount St. Helens 1980 Eruption Ashfall Response Data and Yakima, Spokane Regional Impact Documentation

**ID:** d62d6c41-e939-4ed9-88ea-7dca80593dd8

**Description:** Historical ashfall-impact data from the May 18, 1980 Mount St. Helens eruption: ashfall extent, concentration profiles, duration, and observed health and infrastructure impacts in Spokane and Yakima, Washington and downstream areas. Includes respiratory-disease case counts, air-quality measurements, power-system failures, water-system contamination events and cleanup logistics. Serves as a comparative case study for estimating Yellowstone ashfall impacts and validating supply-chain requirements (N95 consumption, water contamination protocols, power-system resilience). Intended audience: Volcanologist, public health officer, logistics planner. Context: St. Helens ashfall is the only North American precedent; data from that event (scaled for VEI-6 vs. VEI-5) provides empirical estimates for ashfall health impacts and supply needs.

**Recency Requirement:** Published historical data (1980–1981) on ashfall impacts; USGS post-event reports.

**Responsible Role Type:** Volcanologist & USGS Hazard Forecaster / Public Health Officer

**Access Difficulty:** Easy. USGS reports are publicly available; historical emergency response documentation can be requested from Washington State agencies.

**Steps:**

- Contact USGS Cascades Volcano Observatory (Vancouver, WA) and request published reports on the 1980 Mount St. Helens ashfall impacts.
- Download USGS Professional Paper 1250 (The 1980 Eruptions of Mount St. Helens) from the USGS website; review chapters on ashfall and ash impacts.
- Contact Washington State Department of Emergency Management and Department of Health for historical data on 1980 ashfall health impacts, respiratory case counts and water-system contamination events.
- Search academic literature (e.g., Journal of Geophysical Research, Bulletin of Volcanology) for peer-reviewed studies on St. Helens ashfall impacts.

### 15. Eyjafjallajökull 2010 Eruption European Airspace Closure and Ash-Contingency Operations Documentation

**ID:** f36f2cb5-03b0-4f6c-a418-468ae658eada

**Description:** Documentation of the April 2010 Eyjafjallajökull eruption ash-induced airspace closure in Europe: grounding duration, economic impacts, ash-concentration forecast models and tiered airspace reopening criteria. Includes EASA (European Aviation Safety Agency) and ICAO guidance on ash-concentration limits for flight operations and aircraft engine-ingestion risk assessments. Serves as a comparative case study for defining ash-concentration thresholds for rotary-wing medevac exceptions in the Yellowstone response. Intended audience: Aviation Safety Liaison, FAA coordinator. Context: Eyjafjallajökull is the most recent large ashfall over developed airspace; it provides empirical data on ash-flight interaction and regulatory approaches to resuming flight operations under ashfall uncertainty.

**Recency Requirement:** Published reports from 2010–2011 on airspace closure and ash-contingency operations; regulatory guidance from EASA and ICAO.

**Responsible Role Type:** Aviation Safety & Airspace Management Liaison

**Access Difficulty:** Medium. ICAO and EASA publications are available through their websites or direct request. Academic literature can be accessed through university repositories or research databases.

**Steps:**

- Contact ICAO (International Civil Aviation Organization, Montreal office) and request documentation on the Eyjafjallajökull airspace closure and ash-contingency response.
- Search for EASA (European Aviation Safety Agency) guidance on volcanic-ash concentration limits and aircraft operations during ashfall.
- Contact Met Office London Volcanic Ash Advisory Centre (VAAC) and request any published guidance on ashfall forecasting and aviation decision thresholds.
- Search academic literature (journals of aviation safety, volcanology) for peer-reviewed analyses of the Eyjafjallajökull airspace closure and lessons learned.

### 16. Current and Historical Seismic and Hydrothermal Hazard Maps for Yellowstone Caldera Region (USGS HazMaps, Slope-Stability Assessments)

**ID:** f42ce734-7f7e-479a-b1be-9546a9a1567b

**Description:** Existing USGS hazard maps showing seismic epicenter distributions, slope-stability assessments and hydrothermal-explosion zones within Yellowstone National Park. Includes Gallatin Canyon and US-89 corridor geotechnical surveys (if available) and any documented secondary-slide or hydrothermal-explosion events. Serves as input for Landslide Clearance and Hydrothermal Hazard Road Engineering planning. Intended audience: Geotechnical engineer, transportation planner. Context: the plan assumes Gallatin Canyon and US-89 have secondary-slide risk and the South Entrance has current blockage; this documentation enables specific hazard-zone mapping and equipment pre-positioning.

**Recency Requirement:** Current (2010–2025) USGS hazard maps and geotechnical assessments for the Yellowstone region.

**Responsible Role Type:** Transportation Operations & Contraflow Specialist / Geotechnical Engineer

**Access Difficulty:** Easy. USGS hazard maps are publicly available online. State geological surveys maintain geotechnical databases; access may require formal request but is typically available to emergency planners.

**Steps:**

- Contact USGS Yellowstone Volcano Observatory and Cascades Volcano Observatory and request existing hazard maps for the Yellowstone region (seismic, slope stability, hydrothermal hazards).
- Download USGS Scientific Investigations Map series (SIM) for Yellowstone region (available on USGS website).
- Contact Wyoming, Montana and Idaho state geological surveys and request slope-stability assessments or landslide-hazard maps for the Gallatin Canyon and US-89 corridors.
- Request any NPS maintenance or incident reports documenting prior rockfalls, landslides or hydrothermal explosions on park roads.

### 17. Regional Ground Transportation Network Capacity Data (I-15, I-80, I-90, US-20, US-89, US-14/16/20 Lane Counts, Capacity Analysis)

**ID:** 20ac35b9-2dc9-4dbb-871c-eeac47d3a083

**Description:** Detailed highway-capacity data for the primary evacuation routes: Interstate 15 northbound from Salt Lake City to Idaho Falls, Interstate 90 from West Yellowstone/Bozeman to the Livingston area, US-89 from Gardiner to Livingston and I-90, and US-14/16/20 from Cody to Billings and I-90. Includes lane counts, current average daily traffic (ADT), estimated maximum capacity (vehicles per hour per lane), known bottleneck locations (e.g., Gallatin Canyon, mountain passes) and any current or planned construction. Serves as input for contraflow design, throughput validation and evacuation-time estimation. Intended audience: Contraflow Operations Manager, transportation planner. Context: the plan assumes 2,000 vehicles/hour total outbound (660 per exit average), but this must be validated against actual corridor capacity, especially if roads degrade under ashfall or evacuation traffic congestion.

**Recency Requirement:** Current (2024–2025) highway data: lane counts, construction status, average daily traffic; historical capacity studies from the last 5 years.

**Responsible Role Type:** Transportation Operations & Contraflow Specialist

**Access Difficulty:** Easy. State DOT traffic data is publicly available; historical ADT and capacity analyses can be requested from state DOT planning divisions.

**Steps:**

- Contact state DOT traffic-data offices: Montana DOT (Helena), Wyoming DOT (Cheyenne), Idaho DOT (Boise) and request current ADT data, lane counts and capacity-analysis reports for I-15, I-80, I-90, US-20, US-89 and US-14/16/20.
- Download highway-capacity manual (HCM) level-of-service analysis from the Transportation Research Board or academic sources; apply to Yellowstone corridor routes to estimate actual evacuation throughput.
- Request any existing evacuation-routing studies or traffic-modeling reports from state DOT or FHWA for the Yellowstone region.
- Contact FHWA regional offices and request any regional traffic-capacity data or bottleneck assessments for mountain corridors.

### 18. Residential and Transient Population Data for Secondary-Hub Communities (Denver, Cheyenne, Billings, Boise, Salt Lake City, Rapid City)

**ID:** e9feecf9-33d2-46e8-b74c-33e98fb07815

**Description:** Current residential population, hotel/lodging capacity, campground capacity and available emergency-shelter facility inventory for candidate Scenario Beta secondary-hub communities outside the 500 km ring (Denver, Cheyenne, Billings, Boise, Salt Lake City, Rapid City). Includes gym/arena availability, school facility capacity and organizational capacity (Red Cross, Salvation Army) to operate shelters. Serves as input for Scenario Beta secondary-stage hub selection and signed capacity MOUs. Intended audience: Scenario Beta Destination Planner, shelter planners. Context: the plan names Denver and Cheyenne as candidate hubs but has not verified distance or capacity; this data enables validation and ranking of backup hubs.

**Recency Requirement:** Current (2024–2025) facility inventories, hotel/RV-park capacity and community emergency-management resource listings.

**Responsible Role Type:** Scenario Beta Secondary-Stage Destination Planner

**Access Difficulty:** Easy. City emergency management agencies maintain public shelter-facility rosters; chamber-of-commerce lodging data is publicly available.

**Steps:**

- Contact city and county emergency management agencies in Denver, Cheyenne, Billings, Boise, Salt Lake City and Rapid City; request current shelter-facility inventories (gymnasiums, arenas, schools, community centers with capacity for 1,000+ people).
- Request hotel, RV park and lodging-facility capacity data from local chambers of commerce or convention and visitors bureaus.
- Contact Red Cross and Salvation Army regional chapters and request emergency-sheltering capacity and pre-event coordination contacts.
- Verify distance from Yellowstone Caldera center to each hub: confirm that hubs lie outside the 500 km ring (not affected by modeled ashfall or Scenario Beta evacuation zone).

### 19. Utility System Infrastructure and Power-Grid Topology for Montana, Wyoming and Idaho (Transmission Lines, Substations, Ash-Flashover Risk Assessment)

**ID:** 3c23d3db-0621-4b02-9e8f-0775fc3c6de5

**Description:** Electrical transmission-system maps and substation locations for Montana-Dakota Utilities, Pacific Power and Idaho Power service territories covering the Yellowstone region and evacuation routes. Includes transmission-line voltages (115–500 kV), substation locations, backup-generator capacity at critical facilities and any existing ash-flashover or secondary-failure risk assessments. Serves as input for grid-resilience planning and load-shedding procedures. Intended audience: Grid Resilience Engineer, utilities coordinators. Context: the plan assumes grid failure from ash flashovers; this data enables specific vulnerability identification and pre-event protective-relay coordination.

**Recency Requirement:** Current (2024–2025) transmission-system maps, substation listings and protective-relay settings.

**Responsible Role Type:** Critical Infrastructure & Grid Resilience Engineer

**Access Difficulty:** Medium. Transmission-system maps are commercially sensitive; require formal data-sharing agreements with utilities. Critical-infrastructure protection considerations may limit public disclosure; pre-event coordination with utilities is standard for emergency planning.

**Steps:**

- Contact Montana-Dakota Utilities, Pacific Power and Idaho Power operations/planning divisions and request transmission-system maps, substation locations and load-serving areas.
- Request any existing volcanic-ash risk assessments or secondary-failure analyses from the utilities.
- Contact WECC (Western Electricity Coordinating Council) and request grid-resilience data or interconnection studies relevant to the Yellowstone region.
- Request protective-relay coordination diagrams and settings from each utility for substations serving the Yellowstone evacuation region.

### 20. Water-System Infrastructure and Contamination-Treatment Protocols for Bozeman and Idaho Falls Municipal Water Authorities

**ID:** 5c7c919f-7b22-4bb3-a86e-647cb50c78c9

**Description:** Water-system infrastructure data for Bozeman (Three Forks Public Utilities or local water district) and Idaho Falls (Idaho Falls Power/Water) municipal systems: source-water locations (reservoirs, groundwater wells), treatment-plant capacity, distribution-network maps, backup-supply capacity and any existing ashfall or volcanic-ash contamination-response plans. Includes turbidity thresholds for treatment and any pre-planned supply cutoffs if contamination exceeds threshold. Serves as input for water-supply resilience planning and shelf-water pre-positioning requirements. Intended audience: Supply Chain Director, water-utility coordinators. Context: the plan assumes open reservoirs will be contaminated and municipal water may be non-potable for 1–2 days; this data enables specification of bottled-water pre-positioning and treatment protocols.

**Recency Requirement:** Current (2024–2025) water-system capacity data, treatment-plant operations and any existing disaster-response plans.

**Responsible Role Type:** Supply Chain & Logistical Resilience Strategist

**Access Difficulty:** Medium. Municipal water-system data is partly public (capacity, source locations) and partly sensitive (treatment protocols, backup procedures). Coordination with water-utility managers is standard for emergency planning.

**Steps:**

- Contact Bozeman water authority (Three Forks Public Utilities or City of Bozeman Public Works) and Idaho Falls water authority (Idaho Falls Power/Water) and request water-system capacity, source-water locations and treatment protocols.
- Request any existing ashfall or volcanic-ash contamination response plans.
- Contact each water authority's operations center and arrange for pre-event water-system monitoring during the 72-hour window.
- Request turbidity-threshold data for continued-use determination during ashfall.

### 21. Concessioner and Private-Sector Business Continuity Plans and Emergency Contacts for Xanterra Parks and Resorts and Other Yellowstone Service Providers

**ID:** 142c7bea-5f46-46c4-968d-65804275b5f9

**Description:** Business continuity plans, emergency-contact rosters and operational procedures from Xanterra Parks and Resorts (main NPS concessioner operating hotels, campgrounds and food service) and any other major service providers (tour operators, outfitters, thermal-feature guides). Includes emergency procedures for lodging evacuation, guest tracking, staff deployment and asset protection. Serves as input for visitor-needs assessment, assisted-evacuation planning and coordination with concessioners for multilingual outreach and shuttle buses. Intended audience: Communications Coordinator, visitor-needs planner. Context: concessioners operate ~90% of visitor accommodation; pre-event coordination is essential to ensure consistent messaging and transport pre-positioning.

**Recency Requirement:** Current (2024–2025) concessioner emergency plans and contact information.

**Responsible Role Type:** Communications and Public Alerting Coordinator / Visitor Communication Strategist

**Access Difficulty:** Medium. Concessioner business-continuity plans are commercially sensitive; require formal coordination and confidentiality agreements. However, emergency planning is routine and concessioners typically cooperate with disaster-response planning.

**Steps:**

- Contact Xanterra Parks and Resorts Emergency Management or Security Department (Denver headquarters or park operations office) and request business-continuity plans and emergency-contact information.
- Request current guest manifests and staff rosters (to be updated hourly during evacuation).
- Contact other major tour operators and service providers in the region and request emergency plans and availability for evacuation support.
- Establish pre-event data-sharing agreements specifying guest-tracking procedures and shelter-assignment coordination.