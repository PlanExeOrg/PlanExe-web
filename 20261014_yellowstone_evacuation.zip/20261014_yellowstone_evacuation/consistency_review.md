## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Are contraflow and interoperable radio nets confirmed active at all three gates (West, North, East) by T+1 h? | Contraflow active on all three corridors by T+1 h; two-way nets confirmed between NPS, state patrol and Guard at each gate; at least 4 Guard signal teams on site; message receipt in drills at or above 90%. | Gate-by-gate net checks and contraflow status reports at T+1 h; the interoperability and ash-degradation test and signal-team headcount confirmation (premortem A5). | Delay contraflow release and run staged departures by printed route card (FM6 stop rule). If an exit cannot be restored within 6 h, apply the loss-of-exit rule (shelter-in-place for queued vehicles, redirect to the nearest surviving exit). Note that a two-exit fallback cannot meet T+6 at 660 veh/h per exit, so the gate must be re-planned. |
| 2 | Is Gate G1 met at T+6 h: at least 98% of the 35,800 Zone Zero occupants confirmed out? | At least 35,084 confirmed through exit counts; at most about 716 (including 200-400 backcountry stragglers) under active sweep; every lodge cleared; gate load within 10% of the 50/30/20 split. | Exit counts reconciled against concessioner manifests and backcountry permit check-ins at the T+5 h checkpoint and the T+6 h gate review (Month 0 = 2026-10-14). | Hold the Zone One phase start until a sweep plan is set and re-balance gates. Do not proceed to Zone One clearance with unaccounted visitors at the looser 1,000 level quoted in FM9; use the 716 ceiling. Escalate responder reserve and Guard reinforcement. |
| 3 | Are final shelter sites chosen at T+6 h and able to hold at least 35,800 people outside the plume, with a backup able to take at least 10,000 within the relocation window? | Bozeman 15,000 + Idaho Falls 10,000 + third site 10,800 (estimate); PM10 sensors at the forward element and every shelter; PM10 above 100 ug/m3 triggers shelter-suitability review; relocation ordered within 4 h of exceedance; backup 50+ km upwind able to accept at least 10,000 within 8 h; at least 20 buses held in reserve. | T+6 h NOAA/USGS plume run, live PM10 feeds, relocation drill results and bus and driver counts (Month 0 = 2026-10-14, T+6 h to T+12 h). | Halt new intake at the affected shelter and divert arrivals (FM8 stop rule); shelter-in-place with N95 distribution while buses are marshalled; draw on the relocation reserve (USD 5-10 million estimate). |
| 4 | Is the Scenario Beta interim hub list issued by T+12 h with at least 5 hubs outside the 500 km ring that have written capacity and acceptance? | At least 5 hubs published at T+12 h; distance verified for Denver and Cheyenne (not yet verified); written capacity statements (the documents disagree: 50,000 beds in A1 vs 250,000 beds in FM2; a decision is required); interstate saturation below 40% by T+10 h. | Distance measurement and written acceptance from hub emergency managers (premortem A1, within 7 days) and the T+12 h hub list issuance (Month 0 = 2026-10-14). | Hold the outer rings of the 500 km order in later time bands, publish the list at once and add hubs (FM2 contain step); revert to a staged decision cell instead of automatic 500 km authority. |
| 5 | Do water, fuel and N95 convoys reach shelters by T+24 h, with at least 24 h of water stock on hand at T+18 h? | Convoys dispatched from Salt Lake City by T+12 h; arrival target T+24 h via forward depots, realistic range T+18 to T+30 h (estimate); 100,000 civilian N95 plus a separate responder stock; N95 use at or below 20% of stock per day. | Dry-run verbal activation with three vendors and the convoy exercise (premortem A2); convoy tracking at the forward element (T+12 h dispatch, T+18 h stock check, T+24 h arrival). | Activate backup vendors (Pocatello, Butte), release forward-depot stock (200,000-300,000 L, estimate) and shift to helicopter and tanker resupply. If no signed surge-dispatch contract exists by Month 1 (2026-11-14), halt shelter activation planning and escalate. |
| 6 | By Month 1 (2026-11-14) to Month 2 (2026-12-14), are the financing split and signed hub MOUs in place so the pre-authorized Scenario Beta order is executable? | Written federal/state/host cost-share by Month 1 (2026-11-14) (at least 3 states signed); at least 5 hubs outside the 500 km ring with signed MOUs by Month 2 (2026-12-14); free contingency at or above USD 20 million (estimate); written Beta plan by Month 1 (2026-11-14); full multi-state exercise by Month 3 (2027-01-14). | Signed MOUs and EMAC arrangements (Month 1 = 2026-11-14), signed host MOUs (Month 2 = 2026-12-14), exercise reports (Month 3 = 2027-01-14), contingency ledger. | Suspend automatic 500 km authority and revert to a staged decision cell (FM2 and FM7 stop rules); if financing is unresolved, freeze non-critical commitments and ring-fence the contingency for relocation and water resupply. Decide first how this gate works if an event occurs before Month 2 (2026-12-14). |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: executive summary; premortem FM2; pitch
    canonical: decision_window = 72 hours (T+0 to T+72, within Month 0 = 2026-10-14); hardening in Months 1-3 (2026-11-14 to 2027-01-14)
    observed:  Beta executable only after Month 2 (2026-12-14) MOUs; trigger 'before Month 3 (2027-01-14)'
HIGH CF-002  document: canonical_facts
    canonical: required_outbound_throughput = about 660 vehicles/hour per exit at an even three-way split; West 50% = 17,900
    observed:  660 veh/h per exit applied to a 50/30/20 split; West tripwire 500 veh/h; two-exit fallback
HIGH CF-003  document: self-audit; review plan; executive summary
    canonical: pre_event_lead_times_rebased = T+0 to T+12 h actions and Months 1-3 (2026-11-14 to 2027-01-14) hardening
    observed:  Month -2/-1/-0.5, T-12 h, T-48 h, 30/60 days before T+0
HIGH CF-004  document: premortem A1
    canonical: scenario_beta_population = Millions of people (not quantified)
    observed:  50,000 beds (A1) vs 250,000 beds (FM2, self-audit)
HIGH CF-005  document: review plan Review 4, 11, 14
    canonical: fallback_budget_fit = Beta hub pre-positioning is inside the readiness package and not counted again; free contingency USD 30-35 million
    observed:  Free contingency USD 10-15 million; federal outlay USD 240-280 million
MEDIUM CF-006  document: executive summary Action Orientation
    canonical: scenario_beta_plan_milestones = Interim ranked hub list by T+12 h; governor authorization by T+6 h; contraflow by T+1 h
    observed:  hub list by T+6 h; governor authorization and contraflow by T+0
MEDIUM CF-007  document: self-audit
    canonical: scenario_beta_plan_milestones = written plan Month 1 (2026-11-14); signed host MOUs Month 2 (2026-12-14)
    observed:  signed MOUs by Month 1 (2026-11-14)
MEDIUM CF-008  document: executive summary; pitch
    canonical: water_dispatch_vs_arrival = dispatch by T+12 h; arrival T+18-30 h (estimate); target T+24 h via forward depots
    observed:  convoys arrive by T+24 h (as deliverable/metric)
MEDIUM CF-009  document: review plan Reviews 4 and 8; executive summary Feedback
    canonical: zone_one_resident_population = Not quantified; census by T+6 h (estimate)
    observed:  35,800 baseline for Zone One; census at T-48 h / T-6 h
MEDIUM CF-010  document: review plan KPI 2; self-audit item 19; premortem FM8
    canonical: ash_monitoring_thresholds = 50 ug/m3 forecast update; 100 ug/m3 suitability review; relocation within 4 h
    observed:  100 ug/m3 relocation; 200 ug/m3 tripwire; 2 h relocation
MEDIUM CF-011  document: premortem FM9
    canonical: phase1_go_gate = at least 98% of 35,800 (about 35,084); at most about 716 under sweep
    observed:  more than 1,000 unaccounted triggers stop
MEDIUM CF-012  document: premortem FM2
    canonical: scenario_beta_second_stage_hubs = hubs must lie outside the 500 km ring; Denver and Cheyenne qualify (distance not verified)
    observed:  Fort Collins and Casper added as hubs
```

### 1. Scenario Beta is called executable in the 72 h window, but its dependencies close after the window (🔴 High) — needs a project decision

- **Canonical facts (decision_window, scenario_beta_trigger); executive summary; pitch Call to Action:** Beta is 'pre-authorized' and the UC issues the 500 km order within 30 min of trigger inside the 72-hour window starting T+0; the pitch also says 'if USGS confirms a 20% VEI-7 probability before Month 3 (2027-01-14), transition immediately to operational Scenario Beta'.
- **Executive summary Overall Takeaway; premortem FM2 stop rule; self-audit items 4, 5, 9:** Hubs are 'named, validated and committed by Month 2 (2026-12-14)' and 'executable only if' MOUs are signed; the stop rule suspends automatic 500 km authority if fewer than 5 hubs have signed MOUs by Month 2 (2026-12-14).
- **Why it conflicts:** With a 40% eruption probability inside 72 h from today, the Month 1-3 (2026-11-14 to 2027-01-14) deliverables arrive after the event. The stop rule can only fire after the window it is meant to protect, and the pitch trigger ('before Month 3 = 2027-01-14') uses a different window from the 72-hour decision window.
- **Suggested resolution:** Decide how Beta operates if the eruption occurs before Month 2 (2026-12-14). Options: (a) rely on the unsigned T+12 h interim hub list and a staged decision cell; (b) keep automatic authority only with interim written capacity confirmations; (c) treat Months 1-3 (2026-11-14 to 2027-01-14) as a re-baselined readiness phase with its own trigger window. Align the pitch trigger to the stated window.

### 2. Per-exit throughput vs required load at the West gate (🔴 High) — needs a project decision

- **Canonical facts (required_outbound_throughput); premortem A4; review KPI 1:** About 660 vehicles/hour per exit at an even three-way split (about 2,000 veh/h total); premortem treats 660 veh/h per exit as the design value.
- **Canonical facts (gate_load_split); premortem A4, FM4 and FM5; self-audit item 2:** Gate split is West 50% = 17,900, North 30%, East 20%; failure tripwire is 'West exit throughput below 500 vehicles/hour'; fallback is 'restrict the plan to two exits'.
- **Why it conflicts:** Recomputed at 3.0 persons/vehicle: West needs about 994 veh/h over 6 h (about 1,190 veh/h if contraflow starts at T+1), North about 600 and East about 400. A 660 veh/h or 500 veh/h West exit cannot clear 17,900 people by T+6. Two exits at 660 veh/h need about 9 h for 11,900 vehicles, so the two-exit fallback cannot meet Gate G1.
- **Suggested resolution:** Replace the uniform 660 veh/h figure with per-gate requirements (West about 1,000, North about 600, East about 400 veh/h, estimate) or change the split to an even one. Set tripwires per gate. State openly that a two-exit fallback implies missing G1 and needs a revised gate.

### 3. Pre-event actions scheduled before Month 0 (2026-10-14) or T+0 (🔴 High)

- **Canonical facts (pre_event_lead_times_rebased):** Pre-event items set at 'Month -2', 'Month -1', '60/30 days before T+0' or 'T-48 h' are not achievable; they are replaced by T+0 to T+12 h actions and Months 1-3 (2026-11-14 to 2027-01-14) hardening.
- **Self-audit items 2, 13, 16, 17; review plan Reviews 2, 3, 4, 5, 13, 16; executive summary Risk 2 and Feedback:** No-go validation tracks 'by Month -1 (2026-09-14)'; 'Month -0.5 (2026-09-29)'; census at 'T-48 h'; reserve 'deployed by T-12 h'; tow teams 'by T-12 h'; hospital fuel 'by T-12 h'; geotechnical survey 'Month -1.5'; exercises '30 days before T+0'; Region 10 MOU 'by Month 0 (2026-10-14) T+0' with a drill at Month 0 (2026-10-14).
- **Why it conflicts:** Today is Month 0 (2026-10-14) = T+0. Deadlines at Month -2 to Month -0.5 or T-12 h/T-48 h are already in the past, so the go/no-go gates and validation steps that depend on them cannot be met or evidenced.
- **Suggested resolution:** Re-base every such item to T+0 to T+12 h (for example standby reserve, tow teams, sensors, census) or to Months 1-3 (2026-11-14 to 2027-01-14). Replace '30/60 days before T+0' exercises with Month 1-3 (2026-11-14 to 2027-01-14) exercises. Remove no-go gates dated before Month 0 (2026-10-14).

### 4. Required hub capacity: 50,000 vs 250,000 beds vs millions in the ring (🔴 High) — needs a project decision

- **Premortem A1:** Failure trigger for A1: 'combined confirmed capacity is below 50,000 beds'.
- **Premortem FM2; self-audit item 11; canonical facts (scenario_beta_population):** Tripwire 'Confirmed hub capacity below 250,000 beds'; Beta plan success = '5 hubs with signed MOUs and at least 250,000 confirmed beds'; canonical says the Beta population is 'millions (not quantified)' and 100,000-500,000 'understates the ring'.
- **Why it conflicts:** The go/no-go capacity threshold differs by a factor of five between two parts of the same premortem, and neither is tied to a population figure. The ring holds millions, so even 250,000 beds do not cover the 250-500 km zone unless that zone shelters in place.
- **Suggested resolution:** Decide what share of the ring needs a bed (organized evacuation 0-100 km, time-banded 100-250 km, shelter-in-place or staged departure 250-500 km) and set one capacity threshold derived from it. Until then use 250,000 beds as the interim minimum and mark A1 as superseded.

### 5. Beta hub cost counted again against contingency; arithmetic errors (🔴 High)

- **Canonical facts (fallback_budget_fit, free_contingency_after_draws); executive summary:** Beta hub pre-positioning (USD 20-40 million) is already inside the readiness package and not counted again; free contingency is USD 30-35 million.
- **Review plan Review 4 item 1, Review 11 item 3, Review 14 item 1:** If states decline cost-sharing, the envelope absorbs USD 20-40 million 'leaving USD 10-15 million free contingency'; 'total federal outlay could reach USD 240-280 million, exceeding the USD 200 million envelope by USD 40-80 million'; USD 40 million contingency used for Beta hub supplies.
- **Why it conflicts:** Hubs are inside the USD 160 million base, so they do not reduce contingency. Even on the reviews' own logic, 30-35 minus 20-40 gives -10 to +15, not 10-15, and 200 plus 20-40 gives 220-240, not 240-280. The cost-share example also moves cost to states, which would lower federal outlay.
- **Suggested resolution:** Keep the canonical split: readiness package USD 47.5-87 million inside the USD 160 million base; contingency USD 40 million with a USD 5-10 million relocation reserve. Treat the cost-share dispute as who finances items, not as a second draw. Correct or delete the USD 10-15 million and USD 240-280 million statements.

### 6. Executive summary action timing differs from canonical timing (🟡 Medium)

- **Canonical facts; executive summary Key Deliverables; project plan; pitch:** Interim ranked hub list by T+12 h (executive summary Key Deliverables); verbal governor authorization by T+6 h; contraflow active on all three corridors by T+1 h.
- **Executive summary Action Orientation:** 'By T+0: ... obtain verbal governor authorization, activate contraflow on all three exits'; 'By T+6h: ... issue Scenario Beta interim hub list'.
- **Why it conflicts:** The same milestones carry different times inside the executive summary and against the canonical facts (hub list T+6 vs T+12; governor authorization T+0 vs T+6; contraflow T+0 vs T+1).
- **Suggested resolution:** Use the canonical values: hub list T+12 h, verbal governor authorization by T+6 h, contraflow active by T+1 h.

### 7. Signed hub MOUs due Month 1 (2026-11-14) or Month 2 (2026-12-14) (🟡 Medium)

- **Canonical facts (scenario_beta_plan_milestones); executive summary; premortem FM2:** Written second-stage plan by Month 1 (2026-11-14); signed host MOUs by Month 2 (2026-12-14).
- **Self-audit items 2, 4, 5, 9, 10:** 'Written plan by Month 1 (2026-11-14) naming 5-10 hubs with signed host MOUs'; no-go gate 'fewer than 5 hubs validated and signed by Month 1 (2026-11-14)'.
- **Why it conflicts:** Two different dates exist for the same milestone, so the self-audit no-go gate would fire a month before the signing deadline.
- **Suggested resolution:** Keep Month 1 (2026-11-14) for the written plan and Month 2 (2026-12-14) for signed MOUs; move the no-go check to Month 2 (2026-12-14).

### 8. Water arrival stated as a target met vs realistic T+18-30 h (🟡 Medium)

- **Executive summary Key Deliverables; pitch Metrics for Success:** 'Water/N95/fuel convoys arrive shelters by T+24h' as a deliverable; 'convoys arrive by T+24 hours' as a Phase 2 success metric.
- **Canonical facts; executive summary Feedback; project plan Key Risks; review Reviews 8, 10:** Arrival expected T+18 to T+30 h (estimate); T+24 h is a target only via forward depots; shelters face 18-24 h gap if convoys are delayed.
- **Why it conflicts:** A target is presented as a deliverable and a success metric while the same documents estimate arrival up to T+30 h, past Gate G2 time.
- **Suggested resolution:** Phrase as 'target T+24 h via forward depots (realistic T+18-30 h, estimate)'. Make forward-depot pre-staging (200,000-300,000 L, estimate; documents give 300,000 in one place and 200,000-300,000 in another) the success criterion.

### 9. Zone One population baseline and census timing (🟡 Medium)

- **Canonical facts (zone_one_resident_population):** Zone One resident population is not quantified; census of registered residents required by T+6 h (estimate).
- **Review plan Reviews 4 and 8; executive summary Feedback:** 'If Zone One population exceeds the 35,800 estimate by 20-30%'; census 'by T-48 h' (Review 4) / 'T-6 hours (not T+6 h)' (Review 8 and executive summary Feedback); pre-stage 'census +20% (42,000-44,000)'.
- **Why it conflicts:** 35,800 is the Zone Zero (park) figure, not Zone One residents. The census is given three different times, two of them before T+0. Shelter capacity (35,800) is sized to Zone Zero, so Zone One sheltering demand is unplanned.
- **Suggested resolution:** Treat Zone One population as unquantified; census by T+6 h. Remove the 35,800 baseline for Zone One and decide whether shelters must also house Zone One residents (see financing and capacity decisions).

### 10. PM10 and relocation triggers differ (🟡 Medium)

- **Canonical facts (ash_monitoring_thresholds, shelter_siting_rule):** PM10 above 50 ug/m3 triggers forecast update; above 100 ug/m3 triggers shelter-suitability review; relocation order within 4 h of exceedance.
- **Review plan KPI 2; premortem FM8; self-audit item 19:** Relocation 'executed within 4 hours if ashfall exceeds 100 ug/m3' (KPI 2); tripwire 'PM10 above 200 ug/m3 at a primary site' (FM8); '2 h relocation' when PM10 exceeds forecast by 50% (self-audit item 19).
- **Why it conflicts:** The threshold that forces relocation is 100 ug/m3 in one place (which the canonical value defines as a review trigger), 200 in another, and the time limit is 2 h or 4 h.
- **Suggested resolution:** Use canonical: 50 = forecast update, 100 = suitability review; set one relocation-order exceedance (for example 200 ug/m3 or a failed review, proposed threshold) and one 4 h limit.

### 11. Gate G1 stop rule looser than the 98% gate (🟡 Medium)

- **Canonical facts (phase1_go_gate); project plan; pitch:** Gate G1 at T+6: at least 98% of 35,800 confirmed; at most about 716 remain under active sweep.
- **Premortem FM9 stop rule:** 'If more than 1,000 visitors remain unaccounted for at T+6 h, suspend Zone One phase start'.
- **Why it conflicts:** 1,000 unaccounted is 97.2% cleared, below the 98% gate, yet the stop rule allows Zone One to start. The two thresholds disagree on what a pass is.
- **Suggested resolution:** Set the stop rule to the Gate G1 ceiling of about 716 unaccounted (including backcountry), or state that G1 is a go/no-go for the Zone One start.

### 12. Casper proposed as a Beta hub but lies inside the 500 km ring (🟡 Medium)

- **Canonical facts (scenario_beta_second_stage_hubs); premortem A1:** Hubs must lie outside the 500 km ring: Denver and Cheyenne qualify (distance not verified); other regional cities are inside.
- **Premortem FM2 Response Playbook:** 'Add hubs at Fort Collins and Casper, pre-position supplies and run bus shuttles on lateral routes'.
- **Why it conflicts:** Casper, WY lies roughly 400 km from the caldera (approximate, not verified), so it is probably inside the 500 km ring and cannot be a Beta destination. Fort Collins is unverified.
- **Suggested resolution:** Remove Casper (and any other unverified city) from the hub list until distance and ash exposure are verified; keep only hubs verified outside 500 km.

## Summary

The core numbers (35,800 people, G1 98% at T+6 h, G2 95% at T+24 h, USD 200 million envelope, USD 47.5-87 million readiness package) are consistent across the executive summary, project plan and pitch, and the package arithmetic reconciles. The inconsistencies are structural. Scenario Beta is described as pre-authorized and executable inside a 72-hour window while its enabling hubs and MOUs are dated Months 1-3 (2026-11-14 to 2027-01-14), and the review plan and self-audit still use pre-T+0 lead times that the canonical facts have removed. The throughput design (660 veh/h per exit) does not fit the 50/30/20 gate split, and several thresholds (hub capacity, PM10 relocation, G1 stop rule, MOU dates) vary between documents. Most are repairable by adopting the canonical values; hub capacity and Beta operation within the window need a project decision.