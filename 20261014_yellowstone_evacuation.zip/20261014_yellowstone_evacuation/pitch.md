Persuasive elevator pitch.

# Yellowstone Volcanic Evacuation Readiness Plan

## Project Overview

**When a volcano wakes, 35,800 people must move in six hours.** Yellowstone sits above one of Earth's most volatile caldera systems. A VEI-6 eruption has a 40% probability within the next 72 hours. This project hardens the evacuation of Zone Zero (the park) and a 100 km ring of gateway towns, ensuring that when the alarm sounds, three contraflow corridors, a unified command chain, and pre-positioned shelter and supply networks activate within minutes—not days. Without it, gridlock, communication failure, or ash-stranded responders cascade into a multi-state catastrophe. With it, 35,800 people walk away, and regional hospitals and utilities stay online under ashfall. This is **operational readiness at scale**.

The plan moves from immediate evacuation (Phases 1 and 2, T+0 to T+24 hours) to pre-authorized escalation (Scenario Beta, 500 km ring) if eruption probability rises. All actions at T+0 onward are executable from existing authority; pre-event hardening occurs in Months 1–3 (2026-11-14 to 2027-01-14), with signed interstate Memoranda of Understanding (MOUs), validated shelter hubs, and full-scale exercises cementing the framework before any eruption occurs.

## Target Audience

- **FEMA Regional Administrators** (Regions VIII and X)
- **State governors** (Montana, Wyoming, Idaho)
- **NPS Incident Management community**
- **Hospital and utility executives** in gateway towns
- **Multi-state Unified Command stakeholders** authorized to activate the plan, pre-stage resources, and execute it if the volcano awakens
- **Secondary audience:** Congress and state legislatures funding the USD 200 million planning envelope

## Project Overview: Operational Framework

**Zone Zero** (the park) contains approximately 35,800 people: 35,000 tourists and 800 park staff. They must clear three designated exits—West (via West Yellowstone), North (via Gardiner), and East (toward Cody)—by T+6 hours.

**Zone One** extends 100 km and includes West Yellowstone (MT), Gardiner (MT), and Cody (WY). Registered residents (count not yet quantified) must evacuate by T+24 hours.

**Scenario Beta** activates a pre-authorized order for a 500 km ring (millions of residents) if USGS modeling indicates a 20% or higher VEI-7 probability. This order is issued within 30 minutes of the trigger; execution proceeds in rings: 0–100 km organized evacuation, 100–250 km time-banded evacuation, 250–500 km staged departure.

**Core operational elements:**

- Three contraflow corridors active by T+1 hour
- Unified Command seated at FEMA Region VIII RRCC Denver, with FEMA Region 10 liaison from T+0 and a forward element at Livingston, MT
- Authority handoff at park boundaries managed by a Boundary Coordination Officer
- Pre-positioned water, N95 respirators, shelter capacity, and tow/rockfall teams
- Multi-layered communications (IPAWS/WEA, NOAA Weather Radio, Guard satellite/radio repeaters, printed route cards in five languages)
- Responder exposure limits: 6-hour shifts with 2-hour rest and N95 replacement; full withdrawal after 18 consecutive hours

## Risks and Mitigation Strategies

- **Single-point corridor blockage:** Gallatin Canyon or South Entrance closure halts outbound traffic. *Mitigation:* Pre-position two tow/rockfall teams with 15-minute reach; divert overflow after 45 minutes to the nearest surviving exit; abandon South Entrance after 4 hours if blockage persists.

- **Communications failure under ashfall:** Cell towers fail; drivers and responders lose route guidance. *Mitigation:* IPAWS/WEA/NOAA Weather Radio plus National Guard satellite and radio repeaters at every control point; printed route cards in English and five additional languages (Spanish, Japanese, German, Mandarin, French).

- **Authority gaps at state boundaries:** Zone expansion or reroutes stall at NPS-to-governor handoff. *Mitigation:* Boundary Coordination Officer at the forward Unified Command element with pre-authorized reroute protocols in signed MOUs.

- **Scenario Beta exceeds shelter capacity:** The 500 km ring reaches millions of people; current plan shelters approximately 35,800. *Mitigation:* Ranked hub list outside the ring by T+12 hours; written plan by Month 1 (2026-11-14); signed host MOUs by Month 2 (2026-12-14).

## Metrics for Success

**Phase 1 (T+6 hours):** At least 98% of Zone Zero evacuees (≥35,084 people) confirmed through exit counts; fewer than 716 remain under active sweep.

**Phase 2 (T+24 hours):**

- At least 95% of registered Zone One residents evacuated
- Shelters staffed and water convoys dispatched by T+12 hours; convoys arrive by T+24 hours
- Scenario Beta interim destination list issued to all evacuees

**Responder continuity:**

- Zero responder casualties from ash or exhaustion
- 6-hour shift limits and relief rotation maintained through T+72 hours

**Communications:**

- 90%+ of drivers confirmed receipt of route instructions
- 100% responder interoperability across NPS, state, and Guard networks

**Post-event:** After-action report and full-scale exercise completed by Month 3 (2027-01-14); MOUs signed by Month 2 (2026-12-14).

## Stakeholder Benefits

**FEMA:** Pre-positioned incident command, mutual-aid framework, and supply-chain protocols reduce activation time and post-event cost claims; Region 8/10 seam resolved before the event.

**Governors:** Clear authority transfer at park boundary, pre-authorized escalation to 500 km without jurisdictional disputes; **life-safety and business-continuity assurance** to constituents.

**NPS:** Operational command at T+0, ranger exposure limits enforced, backcountry accountability transparent; federal incident-management credibility enhanced.

**Gateway towns and hospitals:** Shelter and supply staging in advance, patient-dispersal protocols, fuel and water priority tiers guarantee **continuity during ashfall**.

**Regional utilities:** Grid-power priorities and backup-generation contracts in place.

**The public:** Transparent trigger criteria, multilingual alerts, escorted-return programs restore trust and reduce chaos-driven shadow evacuation.

## Ethical Considerations

The plan prioritizes **life preservation and equity**:

- Responder exposure limits protect the workforce from respiratory injury
- Pre-authorized escalation removes hindsight blame on decision makers
- Multilingual alerts and assisted transport for mobility-limited visitors ensure no person is left behind by language or disability
- Separate responder N95 inventory protects those enabling the evacuation
- The plan acknowledges uncertainty: a pre-authorized trigger matrix is published in advance so governors, utilities, and the public understand the threshold
- The plan does not promise zero casualties (eruption magnitude is uncontrollable) but commits to **minimizing preventable deaths** through execution discipline, supply continuity, and transparent command

## Collaboration Opportunities

**Inter-agency:**

- Integrate the plan with USGS Yellowstone Volcano Observatory's hazard monitoring and trigger-matrix science
- Collaborate with FAA on ZLC/ZSE exceptions and rotary-wing medevac corridors

**Regional:**

- Engage Montana, Wyoming, and Idaho emergency managers and governors to refine MOUs, authority handoffs, and mutual-aid triggers by Month 1 (2026-11-14)
- Host tristate tabletop and full-scale exercises at Months 2 and 3 (2026-12-14, 2027-01-14)

**Hospital and utility networks:**

- Partner with regional hospital systems for surge-dispersal protocols and patient-transport drills
- Coordinate with utilities for fuel-priority tiers and backup-generation contracts

**Community and concessioner:**

- Activate Xanterra and tour operators as notification channels for foreign visitors
- Engage Bozeman, Livingston, and Idaho Falls chambers of commerce and host-community leaders on shelter siting and second-stage hub pre-positioning

**Academic:**

- Collaborate with University of Montana and University of Wyoming on ashfall-modeling validation and responder fatigue protocols

## Long-term Vision

This plan establishes the first operational, pre-authorized **evacuation framework for a Yellowstone-scale volcanic event**, serving as the model for other caldera systems (Long Valley, Campi Flegrei) and ash-hazard zones worldwide. By Month 3 (2027-01-14), the framework matures into signed MOUs, validated second-stage hubs, and a rehearsed Scenario Beta operation, making it the standard of readiness for societal-scale hazards. Over the following years, the plan feeds into National Incident Management System doctrine, FEMA Regional training, and state emergency-management curricula, extending its influence to wildfire evacuation, hurricane contraflow, and other large-scale life-safety operations. The USD 200 million investment protects 35,800 lives immediately and builds institutional capacity for the next 40 years of Yellowstone's activity window, anchoring **regional resilience in science-based decision rules** and executed, not theoretical, logistics.

## Call to Action

**Activate the readiness package by Month 1 (2026-11-14):**

- Sign the tristate MOUs and EMAC (Emergency Management Assistance Compact) arrangements
- Seat the FEMA Region 10 liaison and forward Unified Command element
- Pre-award water and convoy contracts
- Validate the USGS trigger matrix

**Request appropriations for the USD 47.5–87 million readiness base:**

- Shelter validation and Beta hubs
- Responder reserve and N95 staging
- Communications equipment
- Full-scale Scenario Beta exercise by Month 3 (2027-01-14)

**Escalation trigger:** If the USGS confirms a 20% VEI-7 probability before Month 3 (2027-01-14), transition immediately to operational Scenario Beta zones and second-stage hub pre-positioning.