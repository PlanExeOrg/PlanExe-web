### Premise Attack 1 — Integrity
_Forensic audit of foundational soundness across axes._

**[STRATEGIC] A 24-hour, radius-based evacuation plan keyed to an invented "40% in 72 hours" VEI-6 probability treats a wind-driven, multi-state, months-long ash disaster as a 100 km circle that can be emptied in a day, so the document would project precision that the hazard, the road network and the agencies cannot supply.**

**Bottom Line:** REJECT: A single-day, circle-based evacuation and continuity plan built on an invented eruption probability, with shelters and supply depots that fall inside its own worst case, should not be written as an operational plan.


#### Reasons for Rejection

- The trigger for everything (VEI-6 or higher, 40% within 72 hours) is a number no monitoring agency issues in that form, while the USGS Yellowstone Volcano Observatory's published baseline is roughly 1 in 730,000 per year at Normal alert, so indefinite grounding of ZLC and ZSE airspace and a 35,800-person evacuation would hang on false precision.
- The plan's own safe sites sit inside its own contingency: Bozeman (about 140 km) and Idaho Falls (about 150 km) are only slightly outside the 100 km Zone One, and Salt Lake City, the bottled-water source, is about 420 km from the caldera (recomputed straight-line estimate), all within the 500 km Scenario Beta radius that must be vacated "immediately".
- Evacuees would be moved once to refugee centers and then be candidates for a second forced move if the eruption reaches VEI-7, so the shelter and 12-hour water-convoy logic is built to be abandoned by the plan's own escalation trigger.
- The command structure is split across seams that the plan claims to close: the Denver RRCC covers Montana, Wyoming and Utah, but Idaho Falls sits in FEMA Region X, and "Wyoming Highway Patrol" is tasked to clear bottlenecks on US-191, US-20 and US-89 corridors that run through Montana, where it has no road authority.
- Pre-staging N95 masks for 100,000 people (user constraint) is smaller than the population of Gallatin and Bonneville counties alone (not verified), and the hourly 24-hour schedule ignores that roof collapse, water contamination and respiratory illness from ashfall peak over days to weeks after the window it plans for.

#### Second-Order Effects

- 0–6 months: The plan hardens into a reference document that officials in Montana, Wyoming and Idaho cite for contraflow, shelter sites and aviation shutdowns, while its invented 40%/72-hour trigger and 100 km/500 km radii are quietly treated as established thresholds.
- 1–3 years: Real unrest at Yellowstone, which is far more likely to be hydrothermal explosions or swarms than an eruption, triggers pressure to execute pieces of the plan (West Yellowstone and Gardiner closures, ZLC/ZSE restrictions), producing costly false-alarm evacuations and eroding public trust in later warnings.
- 5–10 years: Shelter and supply infrastructure is sited and funded around Bozeman, Idaho Falls and Salt Lake City, locking in a footprint that sits inside the zone the plan itself says would be lost in a larger eruption, so the investment protects nobody in the scenario that most needs it.

#### Evidence

- Case/Incident — Mount St. Helens eruption (1980): 57 people died, with the lateral blast reaching beyond the restricted zone boundaries, showing that radius-drawn exclusion zones misjudged the hazard geometry.
- Case/Incident — Mount Pinatubo eruption (1991): large-scale evacuations saved many lives, but most deaths came from ash-laden roofs collapsing during Typhoon Yunya, outside the neat evacuation-radius logic.
- Case/Incident — Eyjafjallajökull eruption (2010): a modest eruption led to the cancellation of about 108,000 flights and roughly 10.5 million disrupted passengers across Europe, illustrating how an ash-driven aviation shutdown cascades far beyond any planned zone.



### Premise Attack 2 — Accountability
_Rights, oversight, jurisdiction-shopping, enforceability._

**[STRATEGIC] — Counterfeit Countdown: the plan is built on a "40% within 72 hours" VEI-6 clock that no volcano observatory can issue, so every hour-by-hour task, contraflow lane and shelter assignment is choreography for a forecast that does not exist.**

**Bottom Line:** REJECT: This plan is a Counterfeit Countdown, a detailed machine for acting on a probability that no scientist can honestly provide and a command structure that does not match the map. A premise that begins with an invented clock should not exist.


#### Reasons for Rejection

- It decides who gets a head start and who gets left behind (tourists first, "Zone One" townspeople second, Cody last) without the consent of the residents of West Yellowstone, Gardiner and Cody, who are told to leave their homes behind armed National Guard perimeters on the strength of a number that cannot be defended.
- It assigns Wyoming Highway Patrol to clear bottlenecks on Montana and Idaho roads and places an Idaho Falls intake center under a Denver-based Region VIII command, even though Idaho sits in FEMA Region 10, so the plan's own unified command has no clear authority over the places it sends people.
- A 100 km evacuation ring with a 500 km "Scenario Beta" trigger forces tens of thousands of people onto a handful of two-lane roads, so one false alarm teaches the public to ignore the next real warning, and one real eruption turns a funnel of cars into a trap.
- The central input is a scenario probability rather than a measured fact, while the shelter list still carries placeholder residue ("Boseman", "Field Report"), which shows the plan is staged for effect rather than grounded in what Yellowstone is known to do.

#### Second-Order Effects

- **T+0–6 months — The Cracks Appear:** Publishing a fixed "72-hour, 40%" scenario hands local officials, tour operators and insurers a number to argue over, and it contradicts the USGS Yellowstone Volcano Observatory's own alert language, which is why the plan's authority is questioned before it is ever used.
- **T+1–3 years — Copycats Arrive:** Other caldera and hazard regions draft their own invented-probability evacuation plans, and the numbers in those plans start circulating as if they were forecasts.
- **T+5–10 years — Norms Degrade:** After repeated drills and alerts built on speculative odds, gateway towns and park visitors discount official warnings, so the next genuine hydrothermal or seismic event meets shrugs instead of compliance.
- **T+10+ years — The Reckoning:** If an evacuation is ever ordered under this template, the crowded roads and a command with no real authority over the destination states become the death toll, and the blame lands on a forecast that was never real.

#### Evidence

- Case/Report — USGS Yellowstone Volcano Observatory annual reporting lists the volcano alert level as Normal and the aviation color code as Green, and describes the annual probability of a supereruption as roughly 1 in 730,000 (as reported by secondary sources; exact figure not verified against the primary report).
- Case/Report — The Biscuit Basin hydrothermal explosion of 23 July 2024 destroyed a boardwalk and threw rocks hundreds of feet with no injuries, and USGS stated that such explosions are not caused by rising magma and are not a sign of an impending eruption, which separates a phreatic blast from the magmatic escalation this plan assumes.
- Law/Standard — FEMA regional structure: Region 8 covers Colorado, Montana, North Dakota, South Dakota, Utah and Wyoming, while Idaho belongs to Region 10 (Alaska, Idaho, Oregon, Washington), so a Denver RRCC command does not own the Idaho Falls reception site.
- Narrative — Front-Page Test: "Officials order 100,000 people onto two-lane mountain roads on a 40% guess; no eruption comes, and three towns remain sealed behind National Guard checkpoints."



### Premise Attack 3 — Spectrum
_Enforced breadth: distinct reasons across ethical/feasibility/governance/societal axes._

**[STRATEGIC] A six-hour, road-bound evacuation of 35,000 people through a blocked, two-lane network is fantasy dressed as doctrine, and its own safe havens sit inside its worst-case zone.**

**Bottom Line:** REJECT: A plan that promises to empty a caldera in six hours down two-lane roads and shelters its evacuees inside its own 500 km kill radius must not be adopted.


#### Reasons for Rejection

- Contraflow on US-191 and US-20 is specified for park and gateway roads that are two-lane, so reversing them buys capacity only by sacrificing the sole inbound lane that responders need, while the phreatic blast has already broken the Grand Loop Road and the landslide has sealed the South Entrance.
- The 6-hour clearance target for 35,000 tourists and 800 staff is a number with no precedent behind it: the largest comparable U.S. road evacuation, Hurricane Rita, produced 12–36 hour travel times even with days of warning.
- Authority is handed from NPS to State Governors at the park boundary, which is exactly where the bottleneck forms, while Wyoming Highway Patrol is summoned to clear traffic on Montana pavement at West Yellowstone and Gardiner and a Unified Command in Denver sits hundreds of kilometres from the roadside decisions.
- Scenario Beta's 500 km radius swallows Bozeman, Idaho Falls (Bonneville HS) and Salt Lake City, so the shelters and the water-convoy origin the plan relies on in Phases 1–2 are inside the evacuation zone the plan itself orders emptied in the contingency.
- The entire machine is triggered by a modeled 40% chance within 72 hours, a figure treated as fact, which means a 60% non-eruption outcome still empties a 100 km radius, strands people on mountain roads, and sends the Guard to defend vacant storefronts from looters.

#### Second-Order Effects

- 0–6 months: The first tabletop exercise exposes that Montana, Wyoming and Idaho cannot agree on who commands, funds and secures the Bozeman and Idaho Falls intake sites, so the plan's authority chain exists only on paper while officials quarrel over jurisdiction.
- 1–3 years: Gateway towns and insurers treat the plan as proof that clearance is solved, so seasonal tourist peaks, lodging and development in West Yellowstone and Gardiner continue unchecked, raising the number of people the two-lane exits must someday carry.
- 5–10 years: One false alarm that kills evacuees in traffic and strands thousands for a day or more teaches the public that orders are worse than the volcano, so compliance collapses when a real escalation comes.

#### Evidence

- Case/Incident — Hurricane Rita evacuation (2005): 2.5–3.7 million people fled Houston-area roads, unplanned contraflow on I-10 and I-45 required barricading more than 100 ramps mid-evacuation, travel took 12–36 hours, and 73 of the state's 139 linked deaths occurred before the storm reached Texas.
- Case/Incident — Nevado del Ruiz eruption and Armero (1985): warnings of an impending eruption were largely ignored and more than 25,000 people were killed, showing that the failure point is the chain from scientific signal to authority to action.



### Premise Attack 4 — Cascade
_Tracks second/third-order effects and copycat propagation._

**The plan treats a supereruption as a schedulable, circular, road-evacuable event with a known 72-hour clock, when the physics, the road network, and the jurisdictional map make that assumption false. It is a compliance document for a disaster that does not behave the way the document requires.**

**Bottom Line:** Reject the premise of an evacuation plan driven by a short, probabilistic eruption clock, a circular zone and flipped lanes on two-lane roads. The flaw is the premise itself: it assumes certainty, road capacity and unified authority that do not exist, so no amount of Gantt-chart detail will fix it.


#### Reasons for Rejection

- The Seventy-Two-Hour Oracle: the entire timeline hangs on a '40% within 72 hours' figure and a VEI-6/VEI-7 fork that no monitoring agency can issue in real time. USGS describes the annual supereruption probability as roughly 1 in 730,000 and does not publish short-window eruption odds. VEI is assigned after the fact from erupted volume, so the Scenario Beta 'trigger point' cannot be a measurable pre-eruption threshold.
- The Phantom Lane Fallacy: 'contraflow using all lanes' presumes lanes to flip. US-191, US-89 and US-20 through the park approaches are largely two-lane mountain roads, so contraflow yields at most the shoulder. Even at an assumed 3 people per vehicle (estimate), 35,000 tourists is about 12,000 vehicles, against a single outbound lane moving roughly 1,000-1,500 vehicles/hour (estimate). That is 8-12 hours of throughput on each exit, not 6, before any landslide, wreck or breakdown. The East and Northeast entrances (toward Cody and Cooke City) are ignored as exits.
- The Borrowed Badge Paradox: Wyoming Highway Patrol is asked to clear bottlenecks on roads that lie almost entirely in Montana and Idaho, where its authority does not run. Idaho Falls sits in FEMA Region 10, not Region VIII, so the Denver Unified Command spans two FEMA regions and three states while claiming single authority. Declaring authority 'transfers at the park boundary' creates a handoff exactly where gridlock will form, which is the opposite of turf-war avoidance.
- The Concentric Circle Illusion: 'Zone One' is a 100 km circle, but VEI-6+ hazards are not radial. Pyroclastic flows follow terrain and ashfall follows the wind, spreading hundreds of kilometres downwind. A 500 km Scenario Beta radius (approximately) swallows the plan's own supply base, since Salt Lake City sits roughly 400-450 km away (estimate), along with the Bozeman and Idaho Falls shelters. The bottled-water source and the refuge sites are inside the zone that later has to be evacuated.
- The Paper Convoy Doctrine: water convoys 'within 12 hours', N95s for '100,000 people' and priority generator fuel assume passable roads, working engines and functioning hubs under ashfall. Even thin ash degrades traction and visibility and clogs air filters, which stalls convoys. 100,000 respirators bear no stated relation to the population actually exposed, which across Zone One and an ash plume plausibly runs into the millions (estimate). Guard troops guarding empty towns against looting compete for the same personnel as traffic control and rescue.

#### Second-Order Effects

- Month 0 (2026-10-14) (Hours 0-6): The plan's single-lane outflow chokes at West Yellowstone and Gardiner. Visitors abandon vehicles and walk, blocking the very road the Guard and rangers need. Rangers diverted to 'LE' bottleneck duty leave Zone Zero thermal areas and the South Entrance landslide unmonitored.
- Month 0 (2026-10-14) (Hours 6-24): Evacuees reach Bozeman and Idaho Falls to find intake centres sized for a fraction of the flow, under two different FEMA regions, three state emergency agencies and no shared registry. Family reunification and medical triage fragment. Cell and IPAWS messaging conflicts between states.
- Months 0-1 (2026-10-14 to 2026-11-14): If Scenario Beta is declared, the first evacuation has not cleared and a second 500 km order lands on the shelters and the logistics hub. Evacuees are ordered to move again with no fuel, no transport and no destination.
- Months 1-12 (2026-11-14 to 2027-10-14): Regardless of eruption outcome, the response triggers mass-casualty exposure in the evacuation itself (road crashes, medical-dependent deaths in transit, exposure). If no eruption follows, the false alarm destroys the regional economy of the three gateway towns and the credibility of the next USGS alert.
- Years 1-10: Litigation over cross-state command failures, mandatory insurance and tourism withdrawal from the greater Yellowstone region, and a politicized 'evacuate or stay' dispute that makes the next real unrest episode harder to act on.

#### Evidence

- Hurricane Rita, 2005 (Houston): an evacuation of roughly 2.5 million people produced gridlock stretching across many miles, with fuel exhaustion and deaths en route, including 23 nursing-home evacuees killed in a bus fire near Dallas. Contraflow was started late and improvised, and the evacuation killed people the storm itself did not.
- Mount St. Helens, 1980: 57 people died, including some outside the officially drawn restricted 'red zone', because the lateral blast overran a circular boundary drawn from past experience. This is the direct precedent against treating a hazard map as a circle.
- Nevado del Ruiz / Armero, 1985: authorities held hazard maps and warnings but had no clear, practiced decision chain. Lahars killed roughly 23,000 people, and the warning-to-action chain is the failure, not the lack of data.
- Yellowstone floods, June 2022: flooding closed the entire park and washed out roads at the North Entrance, forcing a stranded-visitor evacuation. It showed that one washed-out road in a park with few arterials strands visitors, and that was a slow-moving hazard with days of lead time rather than a volcanic event (https://www.bozemandailychronicle.com/news/yellowstone_national_park/yellowstone-national-park-closes-as-floodwaters-wash-away-parts-of-roads-officials-working-to-evacuate/article_bf2b562d-f580-557e-a9d3-ead6ef997887.html).
- USGS Yellowstone Volcano Observatory currently reports alert level NORMAL/GREEN and an annual supereruption probability of about 1 in 730,000, so the scenario is a fictional exercise; USGS does not issue a '40% in 72 hours' figure (https://www.usgs.gov/observatories/yvo/news/so-when-will-next-eruption-yellowstone-happen). The FAA ZSE (Seattle) coverage of the Yellowstone area is not verified.



### Premise Attack 5 — Escalation
_Narrative of worsening failure from cracks → amplification → reckoning._

**[STRATEGIC] — The Scripted Apocalypse Fallacy: the plan stakes 35,000 lives on a precisely timed hourly choreography for an event whose precursors, probabilities and hazard footprint no scientific body can state with the confidence the script assumes, so it would manufacture false certainty and send crowds down two-lane mountain roads on a schedule the volcano never agreed to.**

**Bottom Line:** REJECT: A choreographed, hour-by-hour, probability-stamped evacuation of a caldera is a fantasy of control that would convert uncertainty into false confidence and a bottleneck into a death trap; the gate is closed.


#### Reasons for Rejection

- Rights and dignity: the plan treats tens of thousands of visitors, park staff and the residents of Gardiner, West Yellowstone and Cody as freight to be metered through contraflow lanes and exclusion perimeters, with armed enforcement against 'looting' of abandoned homes, while remaining silent on those who cannot self-evacuate (the elderly, the disabled, the carless, non-English-speaking tourists).
- Accountability and oversight: authority is divided across NPS, the Montana, Wyoming and Idaho governors, FEMA Region VIII in Denver, the FAA and the National Guard, and the plan 'resolves' this with a handoff at the park boundary that does not exist on a road where evacuees, rangers and ash cross three state lines in motion; the request for Wyoming Highway Patrol to clear bottlenecks on Montana roads (US-191 and US-89 north of the park) presumes a jurisdiction that does not exist without separate state-level agreements.
- Systemic risk and scale: the premise concentrates the entire survival logic on a handful of two-lane corridors (US-191, US-20, US-89, I-90 via Bozeman) that are single points of failure; one stalled bus, a rockfall or an ash-slick wreck converts a 6-hour evacuation into a standing mass of vehicles inside the hazard zone, and the 6-hour window is itself an unsupported assumption (the June 2022 flood evacuation of the park took roughly a day under far milder conditions).
- Value-proposition rot: the plan's headline numbers (a 40% chance of a VEI-6+ eruption within 72 hours, 100 km and 500 km zones, 100,000 respirators) project a rigor that is not there; USGS states that precursors to a major Yellowstone eruption would be detectable over weeks to months or longer, and that the long-run annual supereruption chance is about 1 in 730,000, so a 72-hour, probability-stamped countdown is hubris dressed as readiness (the 40% figure is a user-supplied scenario value, not an established forecast).

#### Second-Order Effects

- T+0–6 months (Months 0-6 = 2026-10-14 to 2027-04-14) — The Cracks Appear: the first drill or alert built on the scripted timeline collapses on contact with reality; the gridlock, dead cell coverage and conflicting orders from three states expose that every hourly milestone was fiction, and officials begin quietly editing the schedule instead of the premise.
- T+1–3 years (Months 12-36 = 2027-10-14 to 2029-10-14) — Copycats Arrive: neighbouring agencies and other caldera and volcano regions clone the template of single-number probability triggers and tidy contraflow Gantt charts, producing a family of plans that are internally consistent, externally untested and identically brittle.
- T+5–10 years (Months 60-120 = 2031-10-14 to 2036-10-14) — Norms Degrade: repeated false alarms and unverifiable 'trigger points' train the public to treat evacuation orders as theatre; compliance falls, tourism and property markets in Gardiner, West Yellowstone and Cody price in permanent doom, and responders learn to defend the plan rather than question it.
- T+10+ years (Months 120 and beyond) — The Reckoning: when a real unrest episode finally arrives, an exhausted and sceptical population ignores an order issued by a system whose certainty was always counterfeit, and the dead are counted among the people who stayed because the last warning had cried wolf.

#### Evidence

- Principle/Analogue — Volcanology: eruption forecasting is probabilistic and relies on precursors that unfold over days to months; USGS Yellowstone Volcano Observatory states that a large eruption would be preceded by intense, multi-site unrest detectable weeks to months or longer ahead, which contradicts a clean '40% within 72 hours' countdown with a script built on it.
- Case/Report — Nevado del Ruiz, Colombia, 1985: scientific hazard warnings existed, but fragmented responsibility and a failure to order timely evacuation left the town of Armero buried by lahars with roughly 23,000 deaths (figure from widely cited accounts, not re-verified here); precisely the failure mode of split authority and trust in a procedure over the physical hazard.
- Case/Report — Yellowstone flood of June 2022: all park entrances were closed and visitors were evacuated over roughly 24 hours after floods destroyed road sections in the north of the park; this was one flooding hazard, no ashfall, and a fraction of the 29,000-per-day peak-season summer average, and it still took about a day.
- Narrative — Front-Page Test: 'Thousands Trapped on US-191 as Ash Falls; Plan Promised Everyone Out in Six Hours.' The headline writes itself the moment a rockfall, a stalled RV or a cell outage meets an hourly Gantt chart.