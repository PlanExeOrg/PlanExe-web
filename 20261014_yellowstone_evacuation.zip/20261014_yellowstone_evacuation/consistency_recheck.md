_Consistency: first pass found 2 high / 7 medium / 0 low contradictions. Repair: round 1: 58 edits → 3 high / 6 medium; round 2: 36 edits → 2 high / 6 medium; round 3: 42 edits → 1 high / 4 medium. Published: round 3 (fewest high-severity issues). Shown below: the final check of the repaired documents (1 high / 4 medium / 2 low)._

## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Are all three contraflow exits live with interoperable Guard/agency radio nets by T+1 h? | Contraflow active on West, North and East exits by T+1 h; two-way nets confirmed at all three gates; at least 4 Guard signal teams on hand; gate load within 10% of the 50/30/20 split. | Control-point reports and interoperability check at T+1 h; hourly vehicle counts from T+1 h. | Delay contraflow release and run staged departures by printed route card (premortem FM6 stop rule); divert the overflow to the nearest surviving exit. Gate G1 timing is then at risk and must be re-planned at T+2 h. |
| 2 | Do the UC have a published USGS trigger matrix and verbal authorization from the MT, WY and ID governors for Zone One and Scenario Beta orders? | USGS final indicator values (placeholder: modeled VEI-7 probability of 20% or more in the remaining window) published by T+3 h; verbal authorization from all three governors by T+6 h; FEMA Region 10 liaison seated at T+0. | USGS trigger-matrix release at T+3 h; governor confirmation calls logged by T+6 h; liaison seated at the Denver RRCC at T+0. | Scenario Beta and Zone One orders cannot be called pre-authorized. Use a staged decision cell, with each governor issuing orders individually, and record the loss of the 30-minute order time. Do not start Zone One expansion on a single state's authority without a UC decision. |
| 3 | Is Gate G1 met at T+6 h? | At least 98% of 35,800 (about 35,084) confirmed out by exit counts; no more than about 716 (incl. backcountry) under active sweep; responder coverage at least 50% at every post (at least 67 concurrent positions confirmed). | Exit counts reconciled against lodging manifests and permits at the T+5 h checkpoint and at T+6 h; staffed-position count; backcountry sweep status. | Treat G1 as slipped. Seat the standby reserve and request out-of-region Guard, apply the loss-of-exit rule (exit not restorable within 6 h: shelter in place and redirect), and hold the Zone One phase start until a sweep plan is set. Nothing downstream is downsized, but Zone One timing is re-planned. |
| 4 | Is an interim ranked hub list of at least 5 hubs outside the 500 km ring issued with written capacity confirmation by T+12 h? | At least 5 hubs verified outside 500 km (Denver and Cheyenne are the only qualifying hubs named so far; distances not verified) with written capacity. The documents give 50,000 and 250,000 beds as the minimum; 250,000 is the more defensible floor, and the millions in the ring are not covered. | Desktop distance and ash-exposure check and capacity statements from host emergency managers, reported at T+12 h. | Hold the outer rings (100-250 km and 250-500 km) in later time bands and publish only the verified list. Run Beta as a staged decision cell instead of automatic authority, and add only hubs verified outside the ring. |
| 5 | Is Gate G2 met at T+24 h with shelters safe and supplied? | At least 95% of registered Zone One residents out; perimeter staffed; interim destination list issued; shelters sited for at least 35,800 (15,000 Bozeman, 10,000 Idaho Falls, 10,800 third site); water at shelters by T+24 h (realistic T+18-30 h); PM10 below 100 ug/m3, or a relocation order within 4 h of exceedance. | Zone One census and exit counts (census by T+6 h); shelter occupancy dashboard; convoy arrival times; hourly PM10 sensor feeds. | Halt new intake at the affected shelter and divert arrivals; move to ranked 50+ km upwind backups (must accept 10,000 within 8 h); draw on the USD 5-10 million relocation reserve only; release the forward-depot water and the 100,000 N95 reserve. |
| 6 | By Month 2, are signed host MOUs from at least 5 hubs outside the 500 km ring and a written cost-share for shelters and hubs in place? | At least 5 hubs with signed MOUs by Month 2; written federal vs state/local/host cost-share by Month 1 (fewer than 3 states signed by Month 1 is the FM7 tripwire); governor MOUs and EMAC signed by Month 1; full multi-state exercise by Month 3. | Signed MOUs and cost-share letters (Month 1 and Month 2); exercise results (Month 3). | Suspend automatic 500 km authority and revert to a staged decision cell (premortem FM2/FM7 stop rules). Keep the Zone Zero and Zone One response at its current scope, and scale back the Beta pre-positioning of USD 20-40 million until funding is settled. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: Executive Summary / Review 2 / Self-Audit 2
    canonical: scenario_beta_plan_milestones = Interim ranked hub list (at least 5 hubs outside the ring) by T+12 h; written plan Month 1; signed host MOUs Month 2; full multi-state exercise Month 3
    observed:  Beta described as pre-authorized and executable within 72 h while its dependencies close in Months 1-3
HIGH CF-002  document: Premortem A1 / Review 12.3 / Self-Audit 11
    canonical: scenario_beta_second_stage_hubs = Hubs must lie outside the 500 km ring: Denver and Cheyenne qualify (distance not verified); Salt Lake City, Billings, Bozeman, Idaho Falls and probably Boise are inside
    observed:  50,000 beds (A1) vs 250,000 beds (FM2, Self-Audit); hubs 'across Colorado, Wyoming, Idaho and Utah' (Review 12.3)
HIGH CF-003  document: Pitch / Review 2 / Review 3.2
    canonical: governor_authorization = Verbal pre-authorization of UC Zone One and Scenario Beta orders from MT, WY and ID governors by T+6 h; signed MOUs and EMAC by Month 1
    observed:  "Pre-authorized" / "published in advance" / "written authorization letters by T+6 h (verbal)"
HIGH CF-004  document: Reviews 5, 8, 9, 10, 11, 12, 13, 15, 16; Premortem A1, A3, A5, A8; Self-Audit 3
    canonical: pre_event_lead_times_rebased = Pre-event items set at Month -2, Month -1, 60/30 days before T+0 or T-48 h are not achievable; replaced by T+0 to T+12 h actions and Months 1-3 hardening
    observed:  Validation and agreements due "by Month 0", "by T+0", "within 7 days"
MEDIUM CF-005  document: Review 11 / Self-Audit 6 / Self-Audit 18 / Premortem FM7
    canonical: financing_open_decision = OPEN: who finances shelter sites, secondary hubs and state costs (federal share vs state/local/host) is not stated
    observed:  Deadlines at Month 0, T+12 h, Month 1 and Month 2; a 10-20% state match shown as settled
MEDIUM CF-006  document: Review 4.3 / Review 8.1
    canonical: zone_one_resident_population = Not quantified in any document (open item); census of registered residents required by T+6 h (estimate)
    observed:  Shortfall of 5,000-10,000 against an unquantified baseline; shelters sized to 35,800
MEDIUM CF-007  document: Review 13.2 / Review 3.3 / Review 12.3
    canonical: standby_reserve = 30-50 out-of-region traffic-control responders deployable within 4 h; request out-of-region Guard if coverage falls below 50% at any post
    observed:  Reserve and tow teams pre-positioned by T+12 h; Hub Activator by Month 1
MEDIUM CF-008  document: Review 10.3 / Review 13.3 / Review 4.2
    canonical: water_dispatch_vs_arrival = Convoys dispatched from Salt Lake City by T+12 h; arrival at shelters expected T+18 to T+30 h (estimate); target arrival by T+24 h via forward depots
    observed:  Depots pre-staged and contracts signed 'by T+0' (Review 10.3, 13.3); contracts finalized Month 1
MEDIUM CF-009  document: Review 14.3 / Review 15.3 / Self-Audit 6
    canonical: readiness_package_cost = USD 47.5-87 million (estimate), charged to the USD 160 million base
    observed:  USD 200 million pre-event investment / pre-appropriation by Month 0
MEDIUM CF-010  document: Self-Audit 5, 9, 10
    canonical: scenario_beta_plan_milestones = Written second-stage plan by Month 1; signed host MOUs by Month 2
    observed:  Written plan with signed host-community MOUs by Month 1
LOW CF-011  document: Review 5.2 / Review 6 KPI 3
    canonical: fuel_priority_and_hospital_reserve = 72-hour reserves at three receiving hospitals (Bozeman, Livingston, Idaho Falls) (proposed threshold)
    observed:  72 h assumed on-site; to be pre-positioned by T+12 h; KPI floor above 24 h
LOW CF-012  document: Premortem A4
    canonical: gate_load_split = West 50% = 17,900; North 30% = 10,740; East 20% = 7,160 people
    observed:  East below about 400 vehicles/hour (no T+1 value)
```

### 1. Scenario Beta described as pre-authorized and executable, but hubs, MOUs and the no-go gate close after the 72 h window (🔴 High) — needs a project decision

- **Executive Summary Overall Takeaway; Review 2.1; Pitch:** The 500 km expansion is "executable - not hollow - only if second-stage hubs are named, validated and committed by Month 2"; pre-authorized trigger gives a 500 km order within 30 minutes (Executive Summary; Review 2.1; Pitch).
- **Self-Audit 2, 4, 5; Premortem FM2 stop rule; Review 13.1:** The interim list is due T+12 h, the written plan Month 1, signed MOUs Month 2, the exercise Month 3; the no-go gate suspends Beta only "if fewer than 5 hubs are signed by Month 2" (Self-Audit 2; premortem FM2 stop rule).
- **Why it conflicts:** The trigger can fire inside the 72 h window (Month 0), when only an unsigned interim list can exist. The Month 2 gate cannot govern an event decided within hours, and no document says what the UC does in the window if the trigger fires before the MOUs are signed.
- **Suggested resolution:** State explicitly what the UC does if the trigger fires before signed MOUs: issue the order in rings with the interim list only (0-100 km first, outer rings in later time bands) or hold in a staged decision cell. Relabel the Month 2 gate as a hardening gate for any later event. Options and consequences must be set by the project owner.

### 2. Hub count and capacity thresholds are not reconcilable with each other or with the ring population (🔴 High) — needs a project decision

- **Premortem A1; Executive Summary; Review 13.1:** At least 5 hubs outside the 500 km ring are required; combined confirmed capacity below 50,000 beds is the failure trigger (A1).
- **Premortem FM2 tripwire; Self-Audit 11; Review 5.3; Review 12.3; Review 10.2 (Albuquerque, Las Vegas):** Confirmed hub capacity below 250,000 beds is the tripwire (FM2); Self-Audit asks for 250,000 beds; Review 5 assumes 100,000-500,000; canonical Beta population is millions. Only Denver and Cheyenne qualify as outside the ring; Review 12.3 coordinates hubs across Utah and Idaho, which are inside it.
- **Why it conflicts:** The capacity floor differs by a factor of 5 within one document and is tied to no population. The named qualifying hubs number two, so the T+12 h count of 5 may fail by design, and Utah/Idaho hubs conflict with the "inside the ring" decision.
- **Suggested resolution:** Use one capacity floor sized to a stated share of the ring population (250,000 is more defensible than 50,000, and still understates millions), and name at least 3 more candidates outside 500 km after a distance check. Remove Utah/Idaho from hub roles.

### 3. "Pre-authorized" orders versus authority and trigger values that exist only at T+3 h and T+6 h (🔴 High) — needs a project decision

- **Review 2.1; Review 7.1; Pitch Overview and Stakeholder Benefits:** Pre-authorized Scenario Beta; "written trigger matrix published in advance (due T+3 h)"; pre-authorized escalation "without jurisdictional disputes"; actions from T+0 "proceed under verbal governor authorization by T+6 hours".
- **Executive Summary Action Orientation; Review 3.2; Self-Audit 3; canonical governor_authorization:** Verbal governor authorization is obtained only by T+6 h; USGS indicator values are set only by T+3 h; Review 3.2 is titled "written authorization letters ... by T+6 h (verbal)"; Self-Audit 3 says deferring values to T+3 h "leaves pre-authorization hollow".
- **Why it conflicts:** A pre-authorization that is obtained at T+6 h, using trigger values that exist at T+3 h, is not in force during T+0 to T+6 h, when the peak Zone Zero evacuation runs. "Written" and "verbal" are used for the same T+6 h item.
- **Suggested resolution:** Replace "pre-authorized" with "authorized verbally by T+6 h" in the pitch and reviews. Say who may order Zone One or Beta between T+0 and T+6 h (options: governor-by-governor orders, or a UC order under federal authority) because the documents settle this nowhere.

### 4. Pre-event validation and go/no-go inputs dated at or before T+0, or after the window (🔴 High)

- **Review 5.2, 9.2, 10.1, 10.2, 11.1, 12.2, 13.1, 13.3, 15.3, 16.2; Self-Audit 3; Premortem A1:** Validation is required "by Month 0 (2026-10-14)", "by T+0" or "within 7 days": hub capacity and ash-survivability runs, native-speaker validation, activation drill, cross-training, cost allocation, pre-appropriation, and contract sign-off (Reviews 5, 8, 9, 10, 11, 12, 13, 15, 16; Self-Audit 3; Premortem A1).
- **Canonical pre_event_lead_times_rebased; Premortem A3, A5, A8; Review 3.3:** Month 0 is today and T+0 is the evacuation order; the premortem validations (pilot of 1,000 residents, relocation drill, interoperability test) and the geotechnical survey ("within Month 1") have no date before T+0, and pre-event lead times are "not achievable".
- **Why it conflicts:** A task due at Month 0 or "before T+0" cannot be done before the order that starts the clock, and a Month 1 result cannot gate a T+0 to T+12 h decision. The same item (hub distances) carries three dates (T+0, T+12 h, Month 1).
- **Suggested resolution:** Rebase each item to T+0 to T+12 h actions (desktop checks, verbal activation, interim lists) or to Months 1-3 hardening, and mark Month 1-3 results as inputs to the next cycle, not to the T+0 decision. Remove "Month 0" and "by T+0" validation deadlines.

### 5. Date, owner and content of the federal vs state/local/host cost-share decision (🟡 Medium) — needs a project decision

- **Review 11.1; Review 11.3; Self-Audit 6 financing gate:** Cost allocation is required "by Month 0 (2026-10-14) to unlock spending authority"; the USD 160 million base must be confirmed in writing "by T+12 h".
- **Review 4.1; Review 14.1; Premortem FM7; Self-Audit 18:** The same decision is due by Month 1 (Review 4.1, 14.1, 15.3; Self-Audit 7, 18) and Month 2 (Premortem FM7 stop rule); Self-Audit 18 proposes "federal covers pre-positioning; states match 10-20%", although canonical says who finances is OPEN.
- **Why it conflicts:** One decision carries four deadlines (T+0, T+12 h, Month 1, Month 2), so no tripwire can be defended, and a split is written down as if it had been agreed.
- **Suggested resolution:** Treat the split as an open decision with a single owner (FEMA Region VIII finance lead) and one date (Month 1, as in the signed-MOU milestone). Present options (federal 100% of pre-positioning; federal plus state match; host in-kind) without choosing. Align FM7 and the financing gate to that date.

### 6. Zone One shelter and water demand is unplanned while Gate G2 depends on the unquantified count (🟡 Medium) — needs a project decision

- **Review 4.3, 8.1; Project Plan Resources; canonical shelter_capacity_plan:** Shelters (15,000 + 10,000 + 10,800 = 35,800) and water (1.43 million L at 35,800 occupants) are sized for Zone Zero only; "pre-stage to the canonical 35,800".
- **Review 4.3; Review 8.1; Executive Summary Feedback (2); canonical zone_one_resident_population:** Gate G2 requires 95% of registered Zone One residents out by T+24 h; the shortfall is put at "5,000-10,000" if the population is "20-30%" above "the census estimate", although no estimate exists and the census is due only at T+6 h.
- **Why it conflicts:** Zone One evacuees need shelter, water and N95s too, yet no capacity is planned for them and the shortfall cannot be derived from an unquantified base. Capacity cannot be pre-staged to a census taken at T+6 h.
- **Suggested resolution:** State whether Zone One residents are inside the 35,800 shelter capacity or additional to it, and take a proxy figure from county and lodging data at T+0 to T+3 h. Remove the 5,000-10,000 shortfall figure until a base exists. Options: add overflow capacity, or an outer-zone self-supply message.

### 7. Standby reserve, tow teams and key officers seated after the peak they cover (🟡 Medium)

- **Executive Summary Risk 2 and Action Orientation; Review 2.3; Review 7.2; Project Plan Mitigation:** The 30-50 reserve is deployable within 4 h and "seated at T+0"; tow teams are positioned "by T+0".
- **Review 13.2; Review 3.3; Review 12.3:** The reserve is "pre-positioned at designated depots by T+12 h" with Guard commitments only by Month 1; tow teams are pre-positioned "by T+12 h"; the Hub Activator is named by Month 1.
- **Why it conflicts:** Contraflow starts at T+1 h and the peak is T+2 to T+8 h, so assets seated at T+12 h or roles named in Month 1 cannot cover an incident at T+3-6 h, and Review 13.2 concedes this. The documents give different times for the same assets.
- **Suggested resolution:** Use T+0 seating with 4 h deployability for the reserve and T+0 positioning for tow teams (canonical), and bring the Hub Activator and Boundary Officer designation to T+0 under verbal activation. Month 1 should only hold the signed letters.

### 8. Contract, depot and water timing disagree between documents (🟡 Medium)

- **Review 10.3; Review 13.3:** Forward depots are pre-staged with 200,000-300,000 L "by T+0" and water contracts signed "by T+0".
- **Review 8.3; Review 3.1; Review 11.2; Review 4.2; Self-Audit 17:** Depots are stocked "by T+12 h" (Review 8.3; Self-Audit 17); contract terms and vendor sign-off are finalized in Month 1 and the RFP for gaps is a separate Month 1 item (Review 3.1, 11.2); the Idaho backup route is given as "US-89 south via Arizona, 36-48 h" for Salt Lake City to Idaho Falls (Review 4.2), against I-15 elsewhere.
- **Why it conflicts:** The same stock and contracts have three dates (T+0, T+12 h, Month 1); pre-staging "by T+0" is impossible when T+0 is the order, and a Month 1 contract cannot support a T+12 h dispatch clause. The Arizona route contradicts the I-15 corridor used elsewhere.
- **Suggested resolution:** Keep canonical timing: existing FEMA vehicles activated verbally at T+0 with 12 h dispatch; depots stocked by T+12 h; contract hardening Month 1. Drop "pre-stage by T+0", and replace the backup route with the I-15 corridor or a named alternative.

### 9. USD 200 million treated as pre-event investment and as an appropriation to secure at Month 0 (🟡 Medium)

- **Executive Summary Timeline and Budget; Pitch Call to Action; canonical readiness_package_cost:** The readiness package is USD 47.5-87 million, charged to the USD 160 million base; the USD 200 million is a planning envelope, largely Stafford Act response funding.
- **Review 14.3; Review 15.3; Self-Audit 6:** "Full readiness plan (USD 200 million pre-event) vs baseline response (USD 500-800 million)"; "Congressional pre-appropriation of the USD 200 million envelope by Month 0"; "written FEMA pre-authorization for USD 200 million Stafford Act emergency declaration".
- **Why it conflicts:** The benefit-cost baseline counts at least USD 113 million (200 less 87) of event-response funding as pre-event spend, and a Stafford Act declaration does not carry a pre-authorized dollar figure.
- **Suggested resolution:** Run the cost-benefit on the readiness package (USD 47.5-87 million) and show the envelope separately as response funding. Request the readiness package for appropriation, and drop the pre-appropriation of the envelope.

### 10. Signed hub MOUs attached to the Month 1 written plan (🟡 Medium)

- **Canonical scenario_beta_plan_milestones; Executive Summary; Review 9.2; Self-Audit 4:** Written plan by Month 1, signed host MOUs by Month 2.
- **Self-Audit 5, 9, 10:** "By Month 1 ... execute a written Scenario Beta plan naming five or more hubs ... with signed host-community MOUs".
- **Why it conflicts:** The same milestone is given two months (Month 1 vs Month 2) within the Self-Audit; a Month 1 signature requirement is stricter than the Month 2 stop rule.
- **Suggested resolution:** Keep Month 2 for signed host MOUs (as in canonical and the stop rules) and limit Month 1 to the written plan and capacity confirmations.

### 11. Hospital generator fuel stated as existing, as a task, and as a 24 h floor (⚪ Low)

- **Review 5.2:** Assumption: the three receiving hospitals "have adequate generator fuel reserves (72 hours on-site)".
- **Review 5.2 recommendation; Review 6 KPI 3:** The same item recommends "pre-position 72-hour fuel reserves ... by T+12 h"; the KPI success metric is fuel "> 24 hours on-site".
- **Why it conflicts:** The 72 h reserve is presented as present, as a task not yet done (T+12 h), and as a 24 h threshold; with 4-8 h outages and 6-12 h fuel convoys the three readings give different risk.
- **Suggested resolution:** Treat 72 h reserves as the target created by T+12 h (canonical), mark current stock as unverified, and set the KPI floor against that target.

### 12. East exit throughput threshold below its load-split requirement (⚪ Low)

- **Premortem A4:** Failure trigger: East below about 400 vehicles/hour (West and North are given with a from-T+1 value: 994/1,190 and 600/716).
- **Canonical gate_load_split and required_outbound_throughput (recomputed):** East 20% = 7,160 people = about 2,387 vehicles; contraflow starts at T+1, so about 5 h are available: about 477 vehicles/hour (about 398 only if averaged over 6 h).
- **Why it conflicts:** The East threshold passes a flow that would not clear East by T+6 h, the same flaw that was corrected for West and North.
- **Suggested resolution:** Set the East trigger to about 477 vehicles/hour from T+1 (about 398 averaged over 6 h) to match the West and North treatment.

## Summary

The plan is much more consistent than before. The Zone Zero numbers (35,800; G1 98% / about 35,084; G2 95%), the gate load split and throughput, the readiness-package arithmetic (47.5-87 million), the contingency treatment, the pitch trigger window and the water arrival range are now aligned with the canonical facts. The remaining problems are structural. The plan treats the 72 h window as the event but dates most of its validation, financing and commitment items before T+0 or after T+72 h, so Scenario Beta is called "pre-authorized" and "executable" while its authority, hubs, capacity and funding do not exist inside the window. Two decisions are still missing: what the UC does if Beta fires before the hubs are signed, and who finances shelters and hubs. The other remaining items are timing and threshold mismatches between documents that can be repaired by text edits.