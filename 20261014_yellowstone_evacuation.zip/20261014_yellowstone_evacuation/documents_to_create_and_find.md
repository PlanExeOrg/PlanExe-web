# Documents to Create

## Create Document 1: Yellowstone Evacuation Project Charter

**ID**: 6abed7ce-09df-466a-92a3-0d27f1c87a5a

**Description**: Foundational project authorization document defining scope (35,800 Zone Zero + Zone One evacuation), objectives (T+6h clearance, T+24h Zone One completion, pre-authorized Scenario Beta), timeline (72-hour window, Month 0 start = 2026-10-14), resource envelope (USD 200M estimate), constraints (40% VEI-6+ probability, three-exit contraflow, Unified Command at Denver RRCC), and high-level success criteria (Gate G1: 98% of 35,800 out by T+6h; Gate G2: 95% of Zone One residents out by T+24h). Signed by UC Incident Commander, NPS leadership, and FEMA Region VIII Director.

**Responsible Role Type**: Project Manager / Unified Command Incident Commander

**Primary Template**: PMI Project Charter Template

**Secondary Template**: FEMA Emergency Operations Plan Charter

**Steps to Create**:

- Convene UC Incident Commander, NPS incident commander, and state representatives to confirm scope and constraints from canonical facts.
- Define Phase 1 (T+0 to T+6h), Phase 2 (T+6 to T+24h), and Phase 3 (T+24 to T+72h) milestones.
- Specify decision gates (G1 at T+6h, G2 at T+24h) with measurable success criteria (exit counts, resident census confirmation).
- Document resource envelope (USD 200M) and identify financing owner (federal vs. state cost-share).
- List constraints: 72-hour window, 40% eruption probability, three exits only, no pre-event lead time for contracts/MOUs.
- Identify key dependencies: governor authorization by T+6h, Scenario Beta secondary-stage plan by Month 1 (2026-11-14), responder relief depth by T+0.
- Obtain signatures from UC Incident Commander, NPS, FEMA Region VIII and FEMA Region 10 liaison.

**Approval Authorities**: UC Incident Commander (Denver RRCC), NPS Regional Director, FEMA Region VIII Regional Administrator, Governors of Montana, Wyoming, and Idaho (verbal by T+6h, signed by Month 1 = 2026-11-14)

**Essential Information**:

- Define the pre-authorized USGS trigger matrix: specify which volcanic indicators (uplift rate in mm/day, tremor magnitude range, SO2 flux in tonnes/day, combined metrics) automatically escalate from Zone One to Scenario Beta (500 km), with threshold values established by USGS by Month 0 (2026-10-14) T+3 hours.
- Identify the decision authority and trigger-release protocol: confirm which official (Unified Command incident commander, FEMA Region VIII director, NPS incident commander) has unilateral authority to issue the 500 km evacuation order upon trigger confirmation, and the communication sequence to governors and FEMA for situational awareness (notification only, not approval).
- Specify trigger-confirmation procedures: define who verifies that USGS sensor data has crossed the threshold (real-time USGS liaison at the forward UC element or Denver RRCC), how confirmation is documented (written log entry, timestamp, observer names), and the maximum decision latency from threshold breach to order issue (proposed: 30 minutes).
- Determine interim Scenario Beta escalation messaging: draft the phased public alert sequence (IPAWS message 1: 'Escalation indicators detected; Zone One evacuation continues; prepare for possible expanded orders'; message 2: 'Scenario Beta trigger confirmed; 500 km evacuation order issued; follow published tier assignments by county'), in English and the five priority visitor languages (Spanish, Japanese, German, Mandarin, French).
- Establish fallback and false-trigger procedures: define abort or stand-down rules if the initial trigger is later revealed to be a sensor malfunction or natural variation (e.g., USGS confirms false positive within 2 hours of issue), and the message to rescind or clarify previous alerts without eroding public trust.
- List prerequisites and input dependencies: USGS agrees to seat a real-time volcanologist at the forward UC or Denver RRCC from T+0 onwards; NOAA plume forecasts are updated hourly and fed to the decision-maker; Unified Command incident commander has been briefed on the trigger matrix logic and has pre-signed authority delegations from NPS and FEMA; communications staff have tested IPAWS message dissemination (latency, delivery confirmation) by Month 0 (2026-10-14) T-12 hours.

**Risks of Poor Quality**:

- A trigger matrix without explicit numerical thresholds or undefined decision authority creates ambiguity during a high-stress 72-hour window: the Unified Command may hesitate or convene a meeting to reach consensus, delaying the 500 km order by 1–3 hours while evacuees and unordered residents in the 100–500 km ring lack guidance, leading to uncontrolled flight and corridor gridlock that strands Zone Zero tourists.
- Absence of a written false-trigger procedure leaves the decision-maker exposed to irreversible commitment: if a 500 km order is issued and later revealed to be based on instrument error, the reversal message loses credibility with the public and media, undercutting compliance with future warnings and eroding trust in USGS and FEMA authority.
- Lack of multilingual trigger messaging means non-English-speaking evacuees and outer-ring residents (10,000–15,000 people estimate) do not understand the escalation logic, leading to either delayed flight or non-compliance with tier assignments, adding 2–4 hours to evacuation times and stranding 100–500 people.
- No defined trigger-confirmation protocol or decision latency standard allows confirmation delays of 45 minutes to 2 hours, during which evacuees lack direction and shadow evacuation begins uncontrolled; each hour of delay increases corridor saturation and reduces organized evacuation efficiency by 15–20%.
- Failure to pre-test IPAWS dissemination latency and delivery confirmation leaves uncertainty about whether 10–15% of targeted audiences actually receive the alert; messages may be blocked by network congestion, carrier filtering or device settings, reducing effective reach and creating pockets of uninformed evacuees.

**Worst Case Scenario**: Scenario Beta trigger fires, but the pre-authorized USGS trigger matrix is absent or ambiguous, and decision authority is unclear. The Unified Command convenes a conference call to discuss the indicators, delaying the 500 km order by 2–4 hours. During that delay, unordered residents in towns 150–300 km from the park (Billings, Bozeman, Idaho Falls, Driggs) observe ashfall intensifying and begin spontaneous mass evacuation without guidance, flooding I-15, I-90 and US-191 with 100,000–200,000 uncoordinated vehicles. The organized Zone Zero evacuation (35,000 tourists) and Zone One residents (5,000–10,000 estimate) become trapped in the chaotic traffic, adding 6–12 hours to their transit times. Ashfall peaks before the majority of evacuees reach safety; respiratory distress cases overwhelm hospitals in Salt Lake City, Denver and Billings, which are already short of N95 masks and generator fuel. An estimated 50–200 preventable deaths occur due to delayed hospital admission, loss of ventilator support, and respiratory injury. Post-event analysis concludes that 2–4 hours of decision delay cost more lives than any benefit from waiting for additional information. Public trust in government eruption-response authority collapses, undermining compliance in future volcanic-risk zones.

**Best Case Scenario**: The Escalation Trigger and Evacuation Release Doctrine document pre-authorizes a written USGS trigger matrix with explicit numerical thresholds (e.g., combined ULP >5 mm/day + tremor swarms M≥3.5 + SO2 flux ≥10,000 t/day = VEI-7 probable; Unified Command decision authority confirmed in writing). When indicators cross thresholds at Month 0 (2026-10-14) T+48 hours, a USGS volcanologist at the forward UC element confirms the reading within 15 minutes, and the incident commander issues the 500 km Scenario Beta order within 30 minutes. IPAWS disseminates a pre-tested phased message (in English and five languages) reaching 90%+ of target audiences within 15 minutes of issue. Outer-ring residents (100–500 km) understand the tier assignments (shelter-in-place, time-banded, or organized evacuation) and follow published departure windows, avoiding gridlock. The Zone Zero evacuation (35,000) completes within T+8 hours (2 hours better than nominal) because the early Beta order allows forward deployment of secondary-stage buses to Bozeman and Idaho Falls, moving evacuees onward before the shelters reach capacity. Ashfall arrives at T+20 hours, by which time 95%+ of Zone Zero and Zone One populations are in safe, sheltered locations outside the modeled ashfall footprint. Hospital systems receive sufficient notice to relocate fragile patients and pre-stage generator fuel. Scenario Beta secondary-stage hubs are activated on schedule, with pre-arranged shelter capacity, food and water supplies ready. Public trust in government remains high, enabling voluntary cooperation with tier assignments and reducing the unordered evacuation load. Estimated 5–10 lives saved by the 2–4 hour acceleration, and zero authority-confusion incidents.

**Fallback Alternative Approaches**:

- If a full numerical trigger matrix cannot be finalized by Month 0 (2026-10-14) T+3 hours due to USGS data gaps or model uncertainty, pre-authorize a 'provisional trigger' that names one or two high-confidence indicators (e.g., sustained ULP >8 mm/day alone, or tremor swarms M≥4.5 alone) sufficient to issue the 500 km order, with the understanding that a formal comprehensive analysis will follow within 2 hours of the order and may refine or rescind it if early data prove incorrect.
- Establish a 'trigger-confirmation checkpoint' at T+3 hours where USGS and the Unified Command jointly review available data and issue a written statement: either 'Trigger thresholds pre-authorized as follows [list]' or 'Current data insufficient; provisional single-indicator thresholds active: [list].' Commit to a full review and update by T+6 hours.
- If real-time USGS personnel cannot be seated at the forward UC element, use a pre-positioned satellite hotline linking the USGS Yellowstone Volcano Observatory in Vancouver, WA to the UC incident commander, with a protocol requiring a USGS-signed email or voice confirmation within 15 minutes of any escalation question.
- Draft trigger-matrix alternatives (conservative, moderate, aggressive) and pre-authorize one as the baseline; clearly label the others so that if conditions warrant a revision during the event, the incident commander can issue a written amendment citing the new rationale and authority (e.g., 'Based on updated USGS briefing at T+36h, Unified Command adopts the 'moderate' trigger matrix effective immediately, superseding the baseline matrix from T+0').
- If multilingual message production is not complete by Month 0 (2026-10-14) T-12 hours, pre-authorize a simple, tested bilingual (English + Spanish) message series and delay the remaining languages (Japanese, German, Mandarin, French) to T+12 hours, when updated IPAWS templates can be disseminated to regional broadcasters; ensure the delayed-language alert carries a timestamp and priority flag so that non-Spanish-speaking audiences understand the message source and freshness.

## Create Document 2: Scenario Beta Secondary-Stage Evacuation Plan

**ID**: 37178d26-46c9-488f-b917-a716bc5fc0c3

**Description**: Written plan specifying five to ten ranked shelter hubs outside the 500 km ring (Denver, Cheyenne prioritized; distance verification required), signed capacity MOUs from host counties, tiered public messaging (shelter-in-place 250–500 km, time-banded 100–250 km, organized Zone One), bus-fleet and rail-corridor routing to secondary hubs, and supply pre-positioning (food, water, N95s, medical supplies) by Months 1–2 (2026-11-14 to 2026-12-14). Operationalizes the pre-authorized VEI-7 trigger so that a 500 km evacuation order issued at T+12h has published destinations and messaging ready to deploy, preventing uncontrolled shadow evacuation that would strand Zone Zero evacuees.

**Responsible Role Type**: Scenario Beta Secondary-Stage Destination Planner

**Primary Template**: Multi-State Evacuation and Sheltering Plan Template (FEMA, Texas Division of Emergency Management)

**Secondary Template**: Tier System and Time-Banded Departure Schedule (Hurricane Rita, Texas A&M Transportation Institute model)

**Steps to Create**:

- By Month -2 (2026-08-14), contact emergency management directors in Denver, Cheyenne, Albuquerque, Las Vegas, and one backup hub; confirm written acceptance of evacuees, estimate bed capacity, verify distance from Yellowstone center (must be >500 km).
- By Month -1 (2026-09-14), obtain signed MOUs from each host county specifying shelter beds, medical-staff deployment, water/fuel availability, and 48-hour resource-mobilization commitment.
- Define three evacuation rings: 0–100 km (Zone One, organized, pre-assigned routes); 100–250 km (time-banded, assigned departure windows by county on published schedule); 250–500 km (staged departure, self-supplied, no shelter assignment).
- Develop public-facing tier-system map showing hub locations, zone assignments by zip code, and time-banded evacuation schedule.
- Calculate food, water (50,000–100,000 additional gallons estimated), N95 (50,000 additional estimated), fuel and medical supplies for each ring and hub; arrange pre-positioning by Month 2 (2026-12-14).
- Design message sequence: publish tier system by Month 0 (2026-10-14); if Beta triggers at T+12h, issue assignment messages to each zone within 1 hour.
- Plan multi-state Scenario Beta execution exercise involving all hubs, sample bus dispatch, and shelter intake by Month 3 (2027-01-14).

**Approval Authorities**: UC Incident Commander, Governors of Montana, Wyoming, Idaho, Colorado, and Utah (host states), Emergency Managers and Commissioners of all participating hub counties

**Essential Information**:

- Define five to ten ranked shelter hubs outside the 500 km radius (minimum distance >500 km from Yellowstone center) with verified capacity, location, and host-community commitment; prioritize Denver and Cheyenne; exclude Billings, Bozeman, Idaho Falls and Salt Lake City as they fall inside the ring.
- Obtain signed MOUs from each hub county specifying shelter bed capacity, medical-staff deployment, water and fuel availability, and 48-hour resource-mobilization commitment, completed by Month 2 (2026-12-14).
- Design and map three tiered evacuation rings (0–100 km organized, 100–250 km time-banded, 250–500 km staged departure) with zone-to-hub assignments by zip code and published time-banded departure windows to guide public behavior and prevent uncontrolled flight.
- Quantify additional supply requirements for 100,000–500,000 evacuees (actual population inside the 500 km ring not yet defined): food, water (50,000–100,000 additional gallons estimated), N95 respirators (50,000 additional estimated), generator fuel and medical supplies; pre-position at hubs by Month 2 (2026-12-14).
- Develop tiered public messaging sequence: publish tier-system map and evacuation schedule by Month 0 (2026-10-14); design trigger message for Scenario Beta activation, to be issued within 1 hour of UC order at T+12 h (estimate), in English and five visitor languages.
- Design bus-fleet and rail-corridor routing from primary shelters (Bozeman, Idaho Falls) to secondary hubs, specifying fleet size, pickup schedules and intermediate staging points to move evacuees out of congested I-90.
- Plan a multi-state Scenario Beta execution exercise by Month 3 (2027-01-14), involving all hubs, sample bus dispatch and shelter intake under the published time-banded schedule.
- Specify criteria for shelter-hub suitability in Scenario Beta context: distance verification (>500 km), ashfall-footprint exclusion (modeled plume at any forecast wind must not reach the hub), and infrastructure resilience (power, water, medical access).

**Risks of Poor Quality**:

- Without defined secondary-stage hubs and destinations, a VEI-7 trigger at T+12 h results in immediate evacuation of 100,000–500,000 people with no published shelter assignments, causing uncontrolled, chaotic flight on all routes away from Yellowstone within 2–4 hours; this shadow evacuation saturates I-15, I-80, I-90 and local highways, gridlocking organized Zone Zero evacuations (35,800 people) and delaying their clearance by 4–8 hours, increasing respiratory-injury and vehicle-accident rates.
- Missing tiered messaging and time-banded schedules cause public confusion about which residents must evacuate immediately (0–100 km) versus those allowed to depart later (100–250 km) versus self-supplied residents (250–500 km), leading to 20–40% non-compliance with evacuation orders and simultaneous departure of millions of people rather than staged waves, compounding gridlock.
- Unsigned host-community MOUs leave hub capacity, medical staffing and resource availability unconfirmed, so if a Beta trigger fires, the incident commander has no validated destinations to assign to evacuees and cannot credibly execute the tiered schedule, forcing evacuees to self-select shelters or remain unhoused.
- Unquantified supply requirements (food, water, medical, fuel) for the 500 km ring mean supplies staged at hubs may be inadequate within 24–48 hours, leading to shortages of water and medical care affecting 10,000–50,000 evacuees and preventable secondary-health emergencies.
- A messaging sequence not finalized in advance means when the Beta trigger fires at T+12 h, the UC must improvise tier-system communications under time pressure, causing message delays, inconsistencies across states and media channels, and public mistrust that further erodes evacuation compliance.
- Missing bus-fleet routing and intermediate staging points mean secondary-hub movement of evacuees from primary shelters (Bozeman, Idaho Falls) is uncoordinated, causing bottlenecks at pickup sites and longer shelter occupancy, straining primary-shelter capacity and life-support systems beyond their 10–15 day design.

**Worst Case Scenario**: A VEI-7 indicator is detected at T+12 hours, triggering the pre-authorized Scenario Beta 500 km evacuation order. No second-stage hub destinations, capacity confirmations or tiered-messaging plan exist. The Unified Command issues an immediate 500 km evacuation order with no published destinations or time-banded schedule. Within 2–4 hours, uncontrolled evacuation of 100,000–500,000 people begins spontaneously across all roads leading away from Yellowstone. I-15, I-80 and I-90 become gridlocked with private vehicles searching for shelters. This shadow evacuation blocks organized Zone One evacuation corridors, stranding the initial 35,800 Zone Zero evacuees who had cleared by T+6 hours. Ashfall onset at estimated T+8 hours coincides with peak chaos: visibility drops, respiratory distress spikes, and ambulance traffic cannot navigate gridlocked interstates. Hospitals become overwhelmed with unrouted patients arriving from uncoordinated shelters. Estimated cascading outcome: 10–20 hour evacuation delay for Zone Zero compared to plan, 5,000–15,000 people hospitalized for respiratory distress outside planned medical networks, 50–200 preventable deaths due to stranded populations, unmanaged medical transfer delays and secondary health emergencies, plus USD 200–500 million in unplanned emergency response costs.

**Best Case Scenario**: By Month 2 (2026-12-14), the plan identifies and obtains signed MOUs from five to eight hubs outside the 500 km ring (Denver, Cheyenne, Albuquerque, Las Vegas and backups), each confirming 5,000–50,000 bed capacity and 48-hour resource mobilization. Tiered messaging with zone-to-hub assignments and time-banded departure schedules is published by Month 0 (2026-10-14). Supply pre-positioning (food, water, N95, fuel, medical) for 100,000–500,000 evacuees is completed at each hub by Month 2 (2026-12-14). A full multi-state Scenario Beta exercise in Month 3 (2027-01-14) validates bus routing, shelter intake and time-banded dispatch. At T+12 hours, the VEI-7 trigger fires. The Unified Command issues the 500 km order; within 1 hour, evacuation assignments (zone to hub, time window, bus pickup points) are broadcast via IPAWS, HAR and multilingual channels to all 100,000–500,000 residents. Organized time-banded departures proceed: 0–100 km Zone One residents depart first (T+12 to T+36 h), using primary shelters and onward bus transport to hubs; 100–250 km residents depart in later windows (T+24 to T+72 h); 250–500 km residents self-organize by published schedule. No uncontrolled shadow evacuation occurs; corridor throughput remains sufficient for Zone One clearance by T+48 h. Secondary hubs receive evacuees in scheduled waves, with pre-staged supplies sustaining shelter operations for 10+ days without resupply. Hospital networks are not overwhelmed; patient routing follows pre-planned medical-dispersal protocols. Outcome: Scenario Beta evacuation completes within 72 hours with <5% unplanned shelter movement, <100 respiratory-distress cases in excess of planned capacity, zero preventable deaths due to cascade-failure, and public trust in escalation messaging preserved for future warnings.

**Fallback Alternative Approaches**:

- If obtaining five to eight signed host-community MOUs outside the 500 km ring proves infeasible by Month 2 (2026-12-14) due to state or local political resistance, develop an interim 'Scenario Beta Interim Shelter-Surge Plan' by Month 1 (2026-11-14) specifying: (1) a minimum of three confirmed hubs (e.g., Denver, Cheyenne, plus one backup); (2) staged demand-forecasting by county, so that time-banded messages direct residents to the nearest confirmed hub (even if in an adjacent state) rather than attempting universal assignment; (3) a public pre-event statement explaining that Scenario Beta sheltering will be 'directed to available capacity on a first-come, first-served basis within announced time windows,' managing expectations and reducing pressure for pre-signed commitments.
- If multi-state bus-fleet and rail-corridor routing cannot be pre-contracted by Month 1 (2026-11-14), implement a 'Secondary-Hub Self-Transport Directive' as part of Scenario Beta messaging: tier-system maps and time-banded schedules direct each zone to a hub, but allow private-vehicle self-evacuation and self-sheltering at any hub with available capacity, supported by a published hub-contact registry (phone, web) issued in real-time at T+12 h. This trades away the logistics efficiency of coordinated bus transport but requires no pre-event contracting and speeds deployment if transport contracts are delayed.
- If supply pre-positioning at all secondary hubs by Month 2 (2026-12-14) exceeds the available budget (estimated USD 20–40 million), prioritize hubs by ranked probability: (1) Denver and Cheyenne (most likely destinations given proximity); (2) backup hubs identified but not pre-stocked, with verbal agreements for 24–48-hour resupply from regional distribution centers. Stage a 'core reserve' of food, water, and N95 (estimated 50,000–100,000 liters and 50,000 masks) at the two primary hubs, and at T+12 h dispatch secondary convoys to other hubs as demand patterns emerge. This reduces pre-event cost but increases resupply risk during the Scenario Beta window; mitigate by contracting 24-hour emergency-dispatch agreements with Salt Lake City and regional food distributors at Month 0 (2026-10-14).
- If a full multi-state Scenario Beta execution exercise cannot be scheduled by Month 3 (2027-01-14) due to state budget or schedule constraints, substitute a 'Tabletop Scenario Beta Simulation' in Month 3 (2027-01-14) involving state emergency managers, hub coordinators and UC leadership, walking through the trigger, messaging sequence, time-banded dispatch waves and hub intake under simulated conditions. While less comprehensive than a full-scale exercise, a tabletop clarifies decision roles, messaging timing and resource-request protocols, and costs a fraction of a full exercise (estimated USD 0.1–0.3 million vs. USD 0.5–1 million).
- If the 500 km ring population cannot be quantified with sufficient accuracy to estimate supply needs, use a proxy model: assume that the 100–250 km band contains about 50,000–150,000 people (estimate) and the 250–500 km band contains about 100,000–350,000 (estimate), for a total Scenario Beta evacuation of 150,000–500,000 people. Stage supplies proportional to the 100–250 km band (the tier most likely to shelter at pre-designated hubs), and assume the 250–500 km band self-supplies or departs on a delayed schedule. This conservative approach avoids under-staging but requires hubs to accept a modular supply system that can scale up as actual demand is observed in the first 24–48 hours of Scenario Beta execution.

## Create Document 3: Command Structure and Jurisdictional Authority Framework

**ID**: 768e57ad-399c-491a-845f-3a9c2e011f60

**Description**: Defines organizational structure of the Unified Command with FEMA Region VIII RRCC (Denver) as primary, FEMA Region 10 liaison seated from T+0, and forward UC element at Livingston, MT (alternate Bozeman). Specifies authority transfer from NPS to state governors at park boundary via written protocol; establishes Boundary Coordination Officer position with pre-authorized reroute and shelter-assignment authority during the crossing. Documents NPS-to-state handoff checkpoints (Mammoth on US-89, Gallatin County line on US-191, Cody limits on US-14/16/20) and clarifies when state custody begins. Includes decision authority for trigger matrix (UC issues Scenario Beta 500 km order within 30 min of trigger without further approval) and governs inter-agency communication protocols (primary: hourly UC briefings; secondary: Boundary Coordinator voice/data links).

**Responsible Role Type**: Regional Emergency Management & Multi-Jurisdiction Coordination Director

**Primary Template**: NIMS/ICS Unified Command Organization Chart and Authority Matrix

**Secondary Template**: Interstate Mutual Aid Agreement (EMAC) Authority Framework Template

**Steps to Create**:

- Map the UC organizational structure: UC Incident Commander at Denver; three main branches (Evacuation/Traffic, Shelter/Logistics, Communications); sub-units for each state (MT, WY, ID).
- Establish FEMA Region 10 liaison role with direct seat at UC briefings and pre-authorized mutual-aid request authority (no approval delays >2 hours for Idaho resources).
- Define forward UC element at Livingston: co-locate NPS incident commander, Boundary Coordination Officer, Contraflow Operations Manager, and Logistics Director.
- Draft written NPS-to-state authority-transfer protocol: specify that NPS care ends at defined roadside checkpoint; state on-scene commander assumes custody; state highway patrol assumes traffic management on state roads.
- Pre-authorize state on-scene commanders to issue temporary reroutes (max 30 min without supervisory approval) during congestion at the boundary crossing.
- Document pre-authorized Scenario Beta trigger authority: UC Incident Commander approves and announces the 500 km order within 30 min of USGS trigger confirmation (final trigger values due by T+3h).
- Obtain written pre-event confirmation from MT, WY and ID governors authorizing the Unified Command orders by Month -1 (2026-09-14); sign full MOUs (EMAC mutual aid, resource requests, authority transfer) by Month 1 (2026-11-14).
- Schedule multi-state command-authority exercise 60 days before window (Month -1.5, 2026-08-29) testing boundary handoff and escalation under Zone One and Scenario Beta scenarios; document and resolve any jurisdictional conflicts by Month -1 (2026-09-14).

**Approval Authorities**: UC Incident Commander (FEMA Region VIII), Governors of Montana, Wyoming, Idaho, and Colorado (for forward command resources), NPS Regional Director, State Emergency Management Directors

**Essential Information**:

- Define the Unified Command organizational structure: primary seat at FEMA Region VIII RRCC Denver; FEMA Region 10 liaison with direct access to mutual-aid authorities for Idaho resources; forward UC element at Livingston, MT (alternate Bozeman) with NPS incident commander, Boundary Coordination Officer, Contraflow Operations Manager, and Logistics Director co-located.
- Establish authority transfer protocol at park boundary: NPS incident command authority ends at defined roadside checkpoints (Mammoth on US-89, Gallatin County line on US-191, Cody limits on US-14/16/20); state on-scene commander assumes custody and traffic management on state roads; document which state agency (highway patrol or National Guard) holds primary authority on each corridor.
- Specify the Boundary Coordination Officer role: real-time voice and data links to NPS incident commander and state on-scene commanders; authority to issue traffic reroutes and initial shelter assignments during the boundary crossing without supervisory approval (max 30 min authority windows); escalation path for decisions exceeding scope.
- Pre-authorize state on-scene commanders to issue temporary traffic reroutes up to 30 minutes without seeking further approval from NPS or federal supervisors; define reroute scope (lane closures, exit redirections, contraflow reversals) and communication protocol.
- Document Scenario Beta trigger authority: UC Incident Commander approves and announces the 500 km order within 30 minutes of USGS trigger confirmation; specify that no further approval from governors or federal entities is required once the written trigger matrix thresholds are met.
- Identify decision authority for resource requests across FEMA Regions VIII and 10: Region 10 liaison owns Idaho mutual-aid requests (fuel, water, medical, personnel); Denver RRCC owns federal asset deployment; define approval latency targets (no approval delays >2 hours for routine requests) and escalation paths for competing demands.
- Define hourly briefing structure and attendee list for the UC: primary attendees (NPS IC, state on-scene commanders, USGS volcanologist liaison, Boundary Coordination Officer); secondary participants (hospital surge lead, supply chain manager, communications director); cascade briefings to control points at 30-min intervals.
- Specify inter-agency communication protocols: primary (hourly UC video or voice briefings with shared screen common operating picture); secondary (Boundary Coordinator voice/data links to NPS and state); tertiary (radio nets bridged by Guard signal teams across NPS, state patrol and Guard frequencies); define net discipline (call signs, check-in intervals, traffic priority).
- Obtain written pre-event confirmation from Montana, Wyoming and Idaho governors authorizing the UC's evacuation orders for Zone One (100 km) and Scenario Beta (500 km); confirm that governors will enforce unified public messaging and will not issue competing shelter-in-place orders.
- Execute full MOUs covering EMAC mutual aid, authority transfer, resource requests and cost-sharing between the NPS, FEMA Regions VIII and 10, and the three state governments by Month 1 (2026-11-14); include dispute-resolution mechanisms and escalation paths to the governors if authority conflicts emerge.

**Risks of Poor Quality**:

- Authority gaps at the NPS-to-state boundary delay traffic reroutes by 15–45 minutes (estimate), cascading into queues that block 500–1,000 vehicles and extending evacuation by 1–2 hours during peak egress.
- Conflicting orders from NPS incident command and state on-scene commanders create confusion at traffic checkpoints, causing drivers to ignore guidance, reduce compliance with shelter assignments by 10–20% (estimate), and saturate unplanned routes.
- Unclear FEMA Region 10 authority leaves Idaho mutual-aid resource requests (fuel, water, medical) unprocessed for 1–2 hours, delaying shelter supply convoys and creating bottlenecks in the east-corridor evacuation.
- Undefined Scenario Beta trigger authority leaves the 500 km order pending governors' verbal approval or volcanologist consensus, delaying escalation by 2–4 hours past the trigger point and allowing uncontrolled shadow evacuation to begin before official messaging.
- No pre-authorized reroute authority at the boundary means each traffic decision must bubble up to the UC, adding 30–60 min latency per decision and leaving drivers without real-time guidance during congestion.
- Absence of written authority-transfer protocol creates turf disputes between NPS rangers and state highway patrol over who owns traffic control on roads crossing the boundary, resulting in fragmented enforcement and reduced throughput.

**Worst Case Scenario**: Scenario Beta trigger fires at T+36 hours (late Phase 2), but the UC Incident Commander lacks pre-authorized decision authority and must convene the governors and FEMA for verbal approval. The approval loop takes 3–4 hours, during which unconfirmed rumors of a larger eruption spread via media and social networks, triggering uncontrolled shadow evacuation of 100,000+ people in the 100–250 km ring onto I-15, I-80 and I-90. By the time the official 500 km order is announced, these routes are gridlocked with private vehicles, blocking the organized Zone One evacuation of the remaining park visitors and stranding medical transport. The Boundary Coordination Officer at Livingston has no authority to reroute traffic onto secondary roads without state permission, and the state on-scene commanders are overwhelmed by the uncontrolled traffic and unable to respond to real-time requests. Region 10 mutual-aid for Idaho resources is still uncoordinated with the Denver RRCC, and fuel and water convoys from Boise and Pocatello do not arrive for 4–6 hours beyond the target. Hospital patient transfers are delayed 6–8 hours due to gridlock, resulting in 5–10 preventable respiratory-distress deaths and 20–30 cancellations of critical surgeries.

**Best Case Scenario**: The Unified Command organizational structure is formally activated at T+0 with the UC Incident Commander seated in Denver, FEMA Region 10 liaison already present with pre-authorized access to Idaho mutual-aid authorities, and the forward UC element (NPS IC, Boundary Coordination Officer, Contraflow Operations Manager and Logistics Director) co-located in Livingston, MT. At T+6 hours, the Boundary Coordination Officer executes a pre-authorized reroute within 15 minutes, directing overflow traffic from a Gallatin Canyon bottleneck to the East Entrance, and this decision is implemented at the traffic checkpoint before congestion builds. When Scenario Beta trigger fires at T+45 hours, the pre-authorized trigger matrix allows the UC Incident Commander to announce the 500 km order within 30 minutes without waiting for governor approval, and state on-scene commanders immediately disseminate the order via IPAWS and Guard signal nets. The Region 10 liaison activates pre-signed mutual-aid agreements with Boise and Pocatello, and fuel and water convoys dispatch within 2 hours. The unified, coordinated authority structure enables 98% compliance with the evacuation order and prevents uncontrolled shadow evacuation. Hospital patient transfers proceed on schedule, and no preventable deaths occur due to command delays.

**Fallback Alternative Approaches**:

- If pre-event MOUs with the three governors cannot be finalized by Month 1 (2026-11-14), activate a standing governor-to-FEMA hotline at T+0 with verbal pre-authorization of the Zone One and Scenario Beta orders, documented in a call log and signed by each governor within 6 hours; this preserves decision authority even if formal MOUs are still in draft.
- If the Boundary Coordination Officer role cannot be staffed from NPS or state personnel, request a senior National Guard liaison officer assigned to the forward UC element from T+0, pre-authorized to issue reroutes on behalf of both the NPS and state commanders under a jointly-signed delegation of authority.
- If FEMA Region 10 liaison cannot be seated at the Denver RRCC from T+0 due to staff availability, establish a dedicated voice and data link from the Denver RRCC to the Boise FEMA Region 10 office, with a standing 15-minute call schedule and pre-authorized resource-request authority (no approval delays >30 min for routine mutual aid).
- If a full multi-state MOU cannot be negotiated by Month 1 (2026-11-14), substitute a simplified 'Emergency Authority Agreement' signed by each governor at T+0, limited to evacuation-phase authority transfer only, and schedule full MOU negotiations for post-event by Month 6 (2027-04-14).
- If Scenario Beta trigger-matrix thresholds cannot be jointly agreed with USGS by T+3 hours, use a default conservative placeholder (VEI-7 probability at or above 20% in the remaining window, assessed by USGS every 6 hours), with pre-authorized UC authority to order the 500 km expansion if the placeholder is met; refine the final thresholds during Months 1-3 (2026-11-14 to 2027-01-14) for use in subsequent years.
- If the forward UC element cannot be physically located at Livingston, MT due to facility constraints, operate it virtually from Bozeman or Gardner with redundant video/voice links and a rotating daily on-site liaison at each control point to maintain real-time situational awareness of boundary crossing conditions.

## Create Document 4: Escalation Trigger Matrix and Scenario Beta Pre-Authorization

**ID**: 82e68eba-a1aa-4f56-8f97-1f3f5e9ede57

**Description**: Written, pre-authorized threshold-based trigger matrix specifying USGS indicators (uplift rate, seismic magnitude, gas flux, modeled VEI probability in remaining window) that automatically activate Zone One expansion and authorize the Scenario Beta 500 km evacuation order. Final indicator values to be set by USGS by T+3h (placeholders: VEI-7 probability ≥20% in remaining window; other thresholds TBD). UC Incident Commander is pre-authorized to issue the 500 km order within 30 minutes of trigger confirmation without requiring further approval from governors or FEMA. Document clarifies that trigger is pre-authorized decision authority, not a decision that requires meetings or additional debate during the 72-hour window.

**Responsible Role Type**: Volcanologist & USGS Hazard Forecaster

**Primary Template**: USGS Volcano Monitoring and Eruption Forecast Protocol Template

**Secondary Template**: Incident Command Decision Authority and Pre-Authorization Document

**Steps to Create**:

- Coordinate with USGS Yellowstone Volcano Observatory to establish final indicator thresholds by T+3h: specifics include uplift rate (mm/day), seismic magnitude and frequency, gas-emission rates, and modeled VEI-7 eruption probability within the remaining 72-hour window.
- Define the trigger logic: if ANY single indicator crosses its threshold, the entire 500 km Scenario Beta order is activated (no requirement for multiple indicators to trigger simultaneously).
- Establish communication protocol: USGS provides hourly indicator updates to the UC from T-12h through T+72h; when an indicator crosses a threshold, USGS notifies the UC Incident Commander directly via satellite phone within 15 minutes.
- Draft pre-authorization language: 'The UC Incident Commander is authorized to issue and announce the Scenario Beta 500 km evacuation order within 30 minutes of USGS trigger confirmation, without seeking further approval from governors, FEMA, or any other authority.'
- Document the interim Scenario Beta plan (destinations, time-banded schedule, messaging) that will be activated simultaneously with the 500 km order (or this trigger matrix cannot be executed operationally).
- Obtain written signature from USGS Yellowstone Volcano Observatory Director confirming availability of real-time indicator updates and communication protocol.
- Obtain written pre-authorization from governors of MT, WY and ID confirming their acceptance of the pre-authorized 500 km order mechanism (verbal by T+6h, signed by Month 1 = 2026-11-14).

**Approval Authorities**: USGS Yellowstone Volcano Observatory Director, UC Incident Commander (FEMA Region VIII), Governors of Montana, Wyoming, and Idaho (verbal authorization by T+6h, signed by Month 1 = 2026-11-14)

**Essential Information**:

- Define the specific USGS indicators (uplift rate in mm/day, seismic magnitude and frequency thresholds, gas-emission rates, modeled VEI-7 eruption probability within remaining 72-hour window) that will trigger Zone One expansion and Scenario Beta 500 km evacuation order.
- Establish final indicator threshold values by T+3 hours (placeholders to be confirmed by USGS Yellowstone Volcano Observatory; currently undefined).
- Specify trigger logic: clarify whether ANY single indicator crossing its threshold activates the full 500 km order, or whether multiple indicators must cross simultaneously.
- Document the pre-authorization mechanism: write the decision authority granting the UC Incident Commander the power to issue the 500 km evacuation order within 30 minutes of trigger confirmation, without requiring further approval from governors, FEMA, or any other authority.
- Define the communication protocol for hourly indicator updates from USGS to UC from T-12 hours through T+72 hours, including the 15-minute notification window when an indicator crosses a threshold.
- Quantify the interim Scenario Beta execution plan (destinations, time-banded rings, messaging strategy) that will be activated simultaneously with the 500 km order; clarify that this trigger matrix cannot be operationally executed without a defined second-stage plan in place.
- Obtain written confirmation from USGS Yellowstone Volcano Observatory Director confirming real-time indicator availability, update frequency, communication redundancy (satellite and radio backup) and forecast confidence intervals.
- Establish the signature and pre-authorization process: signatures from USGS Director, UC Incident Commander (FEMA Region VIII), and verbal authorization from governors of Montana, Wyoming and Idaho by T+6 hours, with signed MOUs by Month 1 (2026-11-14).

**Risks of Poor Quality**:

- A trigger matrix that lacks specific numerical thresholds or clear trigger logic (e.g., 'ANY indicator' vs. 'ALL indicators') will cause confusion at the moment of decision, delaying the 500 km order by 30 minutes to 2 hours during the critical T+12 to T+36 hour window, leaving millions of outer-ring residents without timely evacuation notice.
- If the matrix is pre-authorized without a documented interim Scenario Beta second-stage plan and destinations, the UC Incident Commander will issue a 500 km order into a vacuum, triggering chaotic uncontrolled shadow evacuation that saturates I-15, I-90 and US-191, blocking the organized Zone Zero and Zone One evacuations and stranding 5,000–20,000 people in traffic.
- Vague or undefined communication protocols between USGS and UC (no satellite backup, no redundancy, no 15-minute notification window specified) risk the UC not receiving trigger confirmation promptly, causing decision delays of 1–6 hours and eroding the credibility of the pre-authorization mechanism.
- Missing written confirmation from USGS on indicator-update frequency, confidence intervals and forecast limitations leaves the UC relying on unvalidated forecasts during the event, risking a trigger that fires on data the USGS later acknowledges as uncertain or incorrect, undermining public trust in the evacuation order.
- Without signed governor authorization of the pre-authorized trigger and 500 km order, a governor may contest the UC's decision after it is issued, creating jurisdictional conflict and media confusion that reverses public compliance and causes 10,000–50,000 outer-ring residents to ignore or delay evacuation.
- A trigger matrix that does not specify the communication protocol for disseminating the 500 km order to state governors, the public, and shelter operators will result in some recipients learning of the order via media rather than official channels, causing uncontrolled evacuation movement before the ring-based execution plan can be activated.

**Worst Case Scenario**: Without a written, clearly specified trigger matrix and pre-authorization mechanism, the UC Incident Commander faces a 15–45 minute delay at the moment of the VEI-7 decision (estimated T+12 to T+24 hours), requiring phone calls to governors, FEMA leadership, and USGS to confirm the indicator values and seek approval for the 500 km order. During this delay, tens of thousands of residents outside the 100 km zone begin uncoordinated evacuation on their own, saturating I-15, I-90 and US-191 with unplanned traffic within 2–4 hours. When the 500 km order is finally issued, it arrives after the shadow evacuation has already jammed the corridors, preventing the organized Zone One and Zone Zero evacuees (35,800 people plus gateway-town residents) from reaching safe zones by T+24 hours. Gridlocked evacuation traffic, amplified by conflicting state-level guidance, results in an estimated 10,000–50,000 people stranded in or near ashfall zones within T+24 to T+48 hours, with 20–100 preventable respiratory-distress and trauma casualties. The cascading failure of the evacuation plan, visible in real-time media coverage, erodes public trust in the Unified Command and triggers a formal inter-state jurisdictional dispute that delays Phase 2 hand-off and second-stage shelter operations by 6–12 additional hours.

**Best Case Scenario**: A written, pre-authorized trigger matrix with specific USGS thresholds, clear trigger logic (ANY or ALL), and a documented communication protocol enables the UC Incident Commander to issue the Scenario Beta 500 km order within 30 minutes of USGS trigger confirmation, with no delays, disputes, or additional meetings. The order is simultaneously communicated to state governors, FEMA Region 10, the forward element, and public-alert channels (IPAWS, local media) within 45 minutes of confirmation. The pre-positioned interim second-stage plan (ranked hub list, time-banded rings, messaging strategy) activates immediately, directing outer-ring residents to published destinations and time-band windows, preventing uncontrolled shadow evacuation. Well-coordinated ring-based execution (0–100 km organized, 100–250 km time-banded, 250–500 km staged departure) keeps I-15, I-90 and US-191 passable for Zone One and Zone Zero organized evacuations. Signed governor MOUs and EMAC arrangements ensure state-level coordination and messaging discipline. By T+36 hours, the entire 500 km ring is executing with 80–90% public compliance, shelters and hubs are receiving evacuees in an orderly sequence, supply convoys are moving, and secondary-stage medical and logistics operations are activated. The Unified Command maintains credibility and authority throughout, with no jurisdictional reversals or media-driven confusion; estimated cascading-failure risk is reduced from 20–100 casualties to <5.

**Fallback Alternative Approaches**:

- If USGS cannot confirm final indicator thresholds by T+3 hours due to technical or forecasting-model constraints, substitute a discretionary decision-cell approach: establish a standing volcanologist-and-governor cell that meets at fixed 6-hour intervals (T+0, T+6, T+12, T+18, T+24) with USGS observations presented in real-time, retaining UC authority to issue the 500 km order without additional approval but accepting 6-hour decision latency at each interval. Document this approach in an alternate protocol signed by governors and USGS by Month 1 (2026-11-14).
- If pre-authorization by governors proves politically infeasible, establish a 'verbal pre-delegation' protocol: governors grant verbal pre-authorization to the UC Incident Commander at T+0 to issue the 500 km order within 30 minutes of a confirmed USGS trigger, documented in a recorded call and confirmed in writing within 24 hours, with the understanding that governors retain the right to dispute the decision after the fact (not ideal, but operationally faster than seeking approval during the event).
- If USGS forecasting confidence in VEI-7 probability is too low to define a single numerical threshold, use a composite trigger: a combination of at least two indicators (e.g., uplift rate >X mm/day AND gas-emission rate >Y tonnes/day AND seismic magnitude M>5.0 in previous 6 hours) crossing thresholds within a 12-hour window, reducing false-trigger risk while maintaining a defensible, pre-authorized decision rule.
- If the Scenario Beta second-stage plan cannot be fully developed by T+0, issue an 'Interim Scenario Beta Destinations List' by T+12 hours specifying at least 5 ranked shelter hubs and a time-banded ring-execution schedule, with the full second-stage plan (MOUs, capacity, messaging) to follow by Month 1 (2026-11-14). The interim list is sufficient to activate the pre-authorized 500 km order and prevent vacuum-driven shadow evacuation.
- If real-time USGS indicator updates cannot be delivered every hour due to satellite or communication failure, establish a 'best-available-data' protocol: the UC proceeds with the most recent USGS observation available (even if >1 hour old) and a stated confidence interval; USGS provides written confirmation of data age and uncertainty at each briefing interval, so UC decisions are made with transparent awareness of data staleness.

## Create Document 5: Egress Corridor Allocation and Contraflow Operations Plan

**ID**: e7aec916-0370-49a6-8b0c-a78a86e82a23

**Description**: Specifies three-exit contraflow strategy allocating zone-zero evacuees (35,800 people) to US-20/US-191 West (50%, ~17,900 to Bozeman/I-90), US-89 North (30%, ~10,740 to Gardiner/Livingston/I-90), and US-14/16/20 East (20%, ~7,160 to Cody/East Entrance). Documents fixed district-to-gate assignment preventing interior vehicle crossings, traffic-control staffing at each checkpoint, tow and rockfall-clearing teams pre-positioned at chokepoints, and contraflow-termini design (staging-lot capacity, turn-pocket geometry, queue-storage). Specifies traffic throughput targets (660 vehicles/hour per exit, 2,000 vehicles/hour total estimated), lane-reversal procedures, and blockage-diversion rules (>45 minutes blockage triggers overflow to next-nearest exit; >6 hours unstorable blockage triggers loss-of-exit contingency and shelter-in-place).

**Responsible Role Type**: Transportation Operations & Contraflow Specialist / Contraflow Operations and Traffic Control Manager

**Primary Template**: FHWA Contraflow Operations and Evacuation Planning Guidance (Texas DOT Hurricane Rita model)

**Secondary Template**: Mountain Pass Traffic Management Plan (CDOT, mountain-corridor protocols)

**Steps to Create**:

- Commission a geotechnical survey of Gallatin Canyon and the South Entrance landslide (Month -1.5, 2026-08-29) quantifying debris volume, secondary-slide risk, and clearance feasibility; develop time-boxed single-lane clearance plan (max 4 hours, abort on M4.0+ seismic or >2 cm slope displacement).
- Conduct a site survey at all three contraflow termini (Month -0.5, 2026-09-29) measuring staging-lot capacity, turn-pocket geometry, queue-storage length, and validating 660 vehicles/hour throughput; adjust exit split or add overflow staging if lot saturation occurs before road saturation.
- Draft lane-reversal procedures for all three corridors, specifying trigger point (T+1h), responsible agency (NPS LE Rangers, state DOT), and staging-lot queue-management protocols.
- Design traffic-control checkpoint layout at each terminus (Mammoth, Gardiner/West Yellowstone area, Cody): specify number of rangers, signage placement, electronic message signs, radio frequencies, and checkpoint-to-checkpoint communication protocols.
- Pre-position at least two mobile heavy-equipment teams (wreckers, debris chippers, geotechnical drones, 72-hour fuel) at Mammoth or Spanish Creek depots (Month -0.5, 2026-09-29, 06:00 UTC) with 15-minute dispatch authority to any Gallatin Canyon blockage.
- Establish live geotechnical monitoring (motion sensors or slope-displacement drones) along Gallatin Canyon and US-89 near Gardiner (Month -0.5, 2026-09-29, 12:00 UTC) with automatic alerts to forward command if displacement exceeds 2 cm/hour; pre-authorize 15-minute temporary traffic halts if alerts trigger.
- Draft Loss-of-Exit Contingency Protocol (Month -1, 2026-09-14): blockage >45 minutes triggers diversion; blockage >6 hours triggers shelter-in-place for queued vehicles and IPAWS notification within 5 minutes.
- Create a Corridor Capacity Operations Center design (forward command element) with real-time traffic-camera feeds, queue-length monitoring, blockage alerts, and automated reroute dispatch authority.

**Approval Authorities**: UC Incident Commander, NPS Incident Commander, Montana DOT Director, Wyoming DOT Director, State Highway Patrol Commanders (MT, WY, ID), USGS Geotechnical Hazards Specialist

**Essential Information**:

- Specify the three-exit contraflow strategy allocating 35,800 Zone Zero evacuees across US-20/US-191 West (17,900 people, ~50%), US-89 North (10,740 people, ~30%), and US-14/16/20 East (7,160 people, ~20%), with fixed district-to-gate assignment preventing interior vehicle crossings.
- Define traffic-control staffing at each of the three contraflow termini (West Yellowstone, Gardiner, Cody area) specifying ranger and state patrol posts, communication protocols, IPAWS/radio relay locations, and real-time queue monitoring.
- Document tow and rockfall-clearing team pre-positioning at chokepoints (Gallatin Canyon, Gardiner area): at least 2 mobile crews with 72-hour fuel reserves, 15-minute dispatch authority, and geotechnical monitoring (motion sensors or drones) to detect incipient slope movement.
- Specify blockage-diversion thresholds and loss-of-exit contingency: blockage >45 minutes (proposed threshold) triggers overflow diversion to nearest surviving exit; blockage >6 hours (proposed threshold) triggers shelter-in-place order for queued vehicles and IPAWS notification.
- Quantify contraflow staging-lot capacity at each terminus, turn-pocket geometry, queue-storage length and validate 660 vehicles/hour throughput per exit (about 2,000 vehicles/hour total estimate); adjust exit split if saturation occurs before road saturation.
- Detail lane-reversal procedures for all three corridors: trigger point (T+1 hour proposed threshold), responsible agencies (NPS LE Rangers, state DOT), and queue-management protocols at staging lots.
- Define success metrics: at least 98% of 35,800 confirmed through exit counts by T+6 hours (Phase 1 Go Gate); average throughput of 2,000 vehicles/hour; zero vehicle crossings of the interior to reach another gate; clearance of Zone Zero within 6 hours.
- Specify geotechnical survey results for Gallatin Canyon and South Entrance landslide (debris volume, secondary-slide risk, clearance feasibility) and decision criteria for a time-boxed single-lane clearance attempt (max 4 hours, abort on M4.0+ event during work proposed threshold).
- Document real-time monitoring and command integration: traffic-camera feeds, queue-length tracking, blockage alerts, automated reroute dispatch authority at forward command element with authority to issue diversion orders within 5 minutes of threshold breach.

**Risks of Poor Quality**:

- Inadequate staging-lot capacity or turn-pocket geometry causes queue backup into the interior park roads within 2-3 hours, blocking the contraflow itself and trapping thousands of vehicles in cascading congestion that extends evacuation time by 2-4 hours.
- Missing or unclear blockage-diversion rules and lack of authority to issue reroutes without multi-agency approval delays diversion decisions by 15-45 minutes, during which a single blockage cascades into a backup affecting 500-1,000 vehicles and adding 1-2 hours to peak evacuation.
- Insufficient tow and rockfall-clearing capacity or delayed dispatch (>15 minutes to reach a Gallatin Canyon blockage) leaves a corridor blocked for 2-4 hours, stranding 500-2,000 vehicles and preventing 5,000-8,000 evacuees from reaching safe zones by T+6 hours.
- Undefined or untested lane-reversal procedures at one or more exits cause traffic-control confusion, incorrect lane marking or signage, and 10-20% of drivers misrouting, adding 1-3 hours to some transit times and reducing overall corridor throughput by 15-25%.
- Lack of real-time queue monitoring and automated reroute authority forces the forward command to rely on phone calls between agencies to issue diversion orders, adding 15-30 minutes to response time during critical blockage events.
- Failure to specify district-to-gate assignment or enforce it allows interior vehicle crossings, creating uncontrolled flow, secondary congestion at unexpected exits and collisions at access points, adding 1-2 hours to evacuation and stranding high-need visitors.

**Worst Case Scenario**: A major rockfall or secondary tremor-induced slide blocks Gallatin Canyon during peak evacuation (T+3 to T+5 hours) when 5,000-8,000 vehicles are queued in the corridor. Tow teams deployed from Mammoth take 20-30 minutes to reach the blockage due to ash or seismic uncertainty. Debris volume exceeds single-lane clearance capacity, and geotechnical assessment takes 45 minutes to 2 hours. With no pre-authorized diversion rule and unclear authority to order reroutes, the forward command delays issuing a diversion order by 30-45 minutes while seeking approval from three agencies. By the time overflow is redirected to US-89 North and US-14/16/20 East, those corridors are already at capacity, creating a bottleneck cascade that extends evacuation by 4-6 hours. An estimated 2,000-4,000 vehicles remain trapped in Gallatin Canyon during ashfall onset (T+6 to T+8 hours), exposing evacuees to 4-8 hours of unforecast heavy ashfall. Respiratory distress among the stranded rises from zero to 50-100 cases, with 5-10 deaths preventable by timely evacuation.

**Best Case Scenario**: Contraflow is fully operational on all three exits by T+1 hour with clear lane markings, traffic-control posts manned and monitored in real-time. The three-way load split (50/30/20%) evenly distributes traffic, achieving an average throughput of 2,000 vehicles/hour. Geotechnical monitoring detects no incipient slides, and tow teams remain on standby with no blockages requiring deployment. Pre-authorized diversion rules and reroute authority enable the forward command to respond to any minor debris within 5-10 minutes. Zone Zero is declared clear at T+5.5 hours with 98% of 35,800 people confirmed through exit counts, and a final cohort of 200-400 backcountry stragglers under active ranger escort or in designated last-resort shelters. Evacuation peak ends before significant ashfall arrival, limiting respiratory distress to a handful of cases. The plan's success enables confidence in Phase 2 Zone One evacuation by T+24 hours and credibility for the pre-authorized Scenario Beta trigger if escalation indicators cross thresholds.

**Fallback Alternative Approaches**:

- If geotechnical survey of Gallatin Canyon reveals blockage risk too high to manage with pre-positioned tow crews, pre-emptively reduce traffic load on US-191/US-20 by increasing the US-89 North and US-14/16/20 East splits to 40% and 25% respectively, accepting longer transit times to Gardiner and Cody but distributing risk across three smaller corridors.
- If staging-lot capacity at West Yellowstone or Gardiner proves insufficient to absorb 660 vehicles/hour without overflow into the interior, stage additional queue-storage on secondary park roads (e.g., Grand Loop Road segments or service roads) within 2-3 km of the exit, with directional signage and ranger escorts to move vehicles forward as primary lots clear.
- If the South Entrance single-lane clearance attempt is aborted due to seismic activity or slide complexity within the first 2 hours, immediately reclassify it as a loss-of-exit scenario and activate the overflow diversion rule: any remaining southern-sector evacuees shelter in place or are routed northward via Grand Loop Road to Norris, then to the West or North exits—accepting longer interior transit and increased ash exposure for that cohort.
- If tow and rockfall teams cannot reach a Gallatin Canyon blockage within 15 minutes due to ashfall visibility or tremor-induced road damage, activate an automated 45-minute blockage timer and reroute all arriving traffic immediately to the nearest alternate exit (US-89 North or US-14/16/20 East) without waiting for on-site assessment, trading some efficiency loss for speed and certainty.
- If real-time queue monitoring and automated reroute authority cannot be established at the forward command by T+0, designate a traffic-control liaison officer at each of the three exits with pre-authorized radio authority to order lane closures or reroutes, reporting status every 15 minutes to the forward command rather than waiting on multistep approval—accepting reduced centralized coordination in exchange for faster local response.
- If the Boundary Coordination Officer role cannot be filled or cannot communicate reliably with both NPS and state commanders at the corridor crossings, establish a redundant decision protocol: each state highway-patrol on-scene commander is pre-authorized to issue reroutes unilaterally if blockage persists beyond 30 minutes and the UC is unreachable, with a standing order to 'assume control and move traffic' rather than delay for approval.


# Documents to Find

## Find Document 1: USGS Yellowstone Volcano Observatory Monitoring Data and Eruption Probability Assessments

**ID**: fef7b2b0-b693-4184-9ba5-820cd32d7d41

**Description**: Real-time USGS seismic, GPS, gas-emission and thermal data from Yellowstone Caldera monitoring network, including current uplift rates (mm/year), seismic magnitude and frequency distributions, SO2 flux measurements and any published eruption-probability or VEI forecasts. Serves as the scientific input for the Escalation Trigger Matrix and the pre-authorized Scenario Beta decision rule. Intended audience: UC Incident Commander, USGS liaison officer, volcanologist advisor. Context: the plan requires final trigger indicator values by T+3h; this data is the baseline and must be collected and analyzed before the 72-hour window begins.

**Recency Requirement**: Current real-time data required from T-12 hours onward; historical baseline data (2020-present) useful for establishing normal variability and defining anomaly thresholds.

**Responsible Role Type**: Volcanologist & USGS Hazard Forecaster

**Steps to Find**:

- Contact USGS Yellowstone Volcano Observatory (Vancouver, WA office or online portal: https://volcanoes.usgs.gov/observatories/yellowstone/) and request access to real-time monitoring dashboards and weekly eruption-probability briefings.
- Download monthly USGS Yellowstone monitoring report (published by YVO) covering uplift, seismicity and gas measurements; identify baseline variability and recent deviations.
- Request any available eruption-scenario modeling or VEI-probability assessments from USGS; clarify which indicators (if any) are established as 'eruption precursors' at Yellowstone vs. other volcanoes.
- Establish Standing data-sharing agreement with YVO to receive real-time alerts if monitoring parameters exceed established thresholds or if scientists issue any formal eruption forecast.

**Access Difficulty**: Easy. USGS YVO maintains public real-time seismic and GPS dashboards; scientists are typically available for direct consultation and pre-event coordination calls. Data is non-classified and freely available.

**Essential Information**:

- Identify the specific USGS seismic, GPS, gas-emission and thermal monitoring indicators (uplift rate in mm/year, seismic magnitude thresholds, SO2 flux levels, temperature anomalies) that trigger the pre-authorized escalation from Zone One (100 km) to Scenario Beta (500 km) expansion.
- Define the baseline normal-range values for each indicator (2020–present historical data) and the threshold values that constitute eruption precursors or VEI-6+ warning signals at Yellowstone Caldera.
- Quantify the eruption-probability assessment method: how USGS computes or estimates the probability of VEI-6+ eruption within the remaining window (placeholder: VEI-7 probability ≥20%), and what confidence intervals or uncertainty ranges apply.
- Specify real-time data availability: which monitoring parameters are transmitted to the Unified Command in near-real-time (every 1–6 hours proposed threshold) and which are issued as weekly or formal scientific briefings.
- List the contact protocols and escalation points: designated USGS liaison officer, YVO scientist on-call during the 72-hour window, and the standing data-sharing agreement that feeds data to the forward command element at Livingston or Bozeman.
- Document any published USGS Yellowstone eruption-scenario modeling (VEI magnitude distributions, plume height, ashfall footprints, duration estimates) that underpins the shelter-siting strategy and air-quality thresholds in the plan.

**Risks of Poor Quality**:

- Vague or absent trigger thresholds delay the pre-authorized Scenario Beta order: if USGS indicators lack numerical boundaries, the UC cannot issue the 500 km decision within 30 minutes of the trigger event, slipping decision latency from 30 minutes to 2–4 hours and losing the window for orderly outer-ring evacuation.
- Baseline-to-anomaly thresholds not established: without historical normal-range data, the UC cannot distinguish between routine monitoring noise and genuine precursor signals, risking either false triggers (premature 500 km expansion straining shelter and road capacity) or missed true precursors (delayed evacuation if a real VEI-6+ sequence begins unrecognized).
- Eruption-probability methodology not quantified: if USGS cannot express eruption likelihood as a numerical probability or confidence interval, decision-makers cannot calibrate risk thresholds and may anchor on worst-case or dismiss warnings as speculative.
- Real-time data delivery not specified: if monitoring data is issued only weekly or via email, the UC will lack hourly updates needed to detect rapid escalation and will be forced to make Scenario Beta decisions on stale information, degrading decision quality.
- USGS liaison role undefined: without a named scientist seated at the forward command or on-call within 15 minutes, gaps in data interpretation could occur during peak decision-making, and conflicting scientific assessments from different USGS offices could confuse the UC.
- Eruption scenarios not linked to plan triggers: if USGS modeling of ashfall extent, plume height or duration differs from the assumptions in the shelter-siting and air-quality protocols, the plan's protection levels may be inadequate or overstated, affecting shelter placement and supply decisions.

**Worst Case Scenario**: 
USGS monitoring data cannot be accessed or interpreted in real-time during the critical first 24 hours of the eruption window. Seismic swarms and uplift accelerate faster than weekly reporting cycles can track; the UC lacks numerical trigger thresholds and cannot authorize the Scenario Beta 500 km order, leaving outer-ring residents (tens of thousands to potentially low hundreds of thousands) without evacuation instructions. Uncontrolled, unguided shadow evacuation begins within 6–12 hours, saturating I-15, I-80 and I-90 with hundreds of thousands of private vehicles. The resulting gridlock prevents the organized evacuation of Zone One (35,800 park evacuees), strands ambulances and hospital transport in traffic, and delays water and fuel convoys beyond 48 hours. An estimated 50–200 preventable deaths result from heat stress, dehydration, respiratory distress and untreated medical emergencies in stalled vehicles. The USGS data gap is the single-point failure that cascades through command, shelter, medical and logistics levers, rendering the entire evacuation plan inoperable.


**Best Case Scenario**: 
USGS provides real-time seismic, GPS and gas-emission data to the Unified Command every 1–4 hours, with a named volcanologist seated at the forward element and weekly formal briefings. Trigger thresholds—baseline normal ranges, precursor criteria and the VEI-6+ probability metric—are pre-authorized and embedded in the UC's decision protocol by Month 1 (2026-11-14). When magma signatures cross thresholds at T+3–T+12 hours (within the 72-hour window), the UC issues the Scenario Beta order within 30 minutes, activating the pre-authorized 500 km evacuation rings and secondary-hub destination list. Outer-ring residents receive consistent, credible messages explaining the escalation logic, follow time-banded departure instructions and reach pre-designated secondary hubs (Denver, Cheyenne) via lateral routes. Zone One evacuation completes by T+24 hours; Zone Zero by T+6 hours. Water and fuel convoys arrive on schedule. An estimated 100,000–500,000 additional evacuees beyond Zone One are sheltered safely, ashfall is tracked in real-time and shelter relocations (if needed) occur within 4 hours. Zero preventable deaths attributable to evacuation delays or Scenario Beta decision latency.


**Fallback Alternative Approaches**:

- If USGS real-time data access is unavailable, establish a standing on-call volcanologist rotation (USGS, university or contracted geophysicist) seated at the forward command 24/7 from T-12 hours onward, with authority to interpret monitoring station data, issue hourly alerts and recommend escalation without waiting for formal USGS briefings.
- If numerical trigger thresholds cannot be pre-authorized by USGS, use a published precursor framework from a comparable volcano (e.g., Mount St. Helens 1980, Sakurajima, Merapi) to define proxy thresholds—e.g., seismic rate >100 events/day for M>3.0, uplift >10 mm/month, SO2 flux doubling—and apply them as interim decision rules pending USGS endorsement.
- If real-time data delivery is slow, deploy redundant monitoring equipment (portable seismometers, GPS units, gas samplers) at key locations (Norris, Old Faithful, Mammoth) managed by NPS and National Guard personnel; hourly readings are radioed to the forward command, creating a parallel monitoring net independent of USGS systems.
- If no USGS liaison is available, designate a UC science advisor (state geologist or academic volcanologist) who is briefed on all monitoring data and authorized to interpret technical assessments, mediate conflicting scientific opinions and advise the UC on escalation decisions in near-real-time.
- If eruption-scenario modeling is not available from USGS, request the latest peer-reviewed VEI-6 ashfall simulations from academic sources (University of Wyoming, USGS publications) and use them as interim shelter-siting and air-quality assumptions, with explicit disclaimer that actual ashfall may differ.
- If weekly USGS reporting is the only option, compress it to daily briefings by standing request at T+0, prioritize the specific indicators embedded in the trigger matrix and accept that escalation decisions will be 12–24 hours slower, reducing evacuation lead-time for Scenario Beta.

## Find Document 2: NOAA Volcanic Ash Forecast Transport (VAFT) Model Outputs and Wind Forecast Data

**ID**: 7c60f88d-38a4-4f23-a83c-d28f45f81bfa

**Description**: Current and historical ashfall-dispersion model output from NOAA's Volcanic Ash Forecast Transport system, showing predicted PM10 concentrations at multiple altitudes and distances from Yellowstone Caldera under various eruption scenarios and wind profiles. Includes 12-hour wind forecasts from Global Forecast System (GFS) and high-resolution local models. Serves as the input for the Shelter Siting Decision Rule (T+6h) and dynamic relocation protocols. Intended audience: Ashfall Forecasting Officer, shelter managers, air-quality specialists. Context: forecast uncertainty is estimated at ±50 km; pre-event access and testing of model output is essential to validating shelter-siting thresholds.

**Recency Requirement**: Current wind forecasts and VAFT model updates required every 3-6 hours from T-24h through T+72h. Historical ashfall-plume scenarios (e.g., Mount St. Helens 1980, Eyjafjallajökull 2010) useful for model validation and sensitivity analysis.

**Responsible Role Type**: Ashfall Forecasting and Dynamic Shelter-Siting Officer / Volcanologist & USGS Hazard Forecaster

**Steps to Find**:

- Contact NOAA's Hazardous Weather Testbed (Norman, OK) and National Weather Service Forecast Office (Billings or Riverton, WY) to request VAFT model documentation and access to model output.
- Download high-resolution GFS wind forecasts for the Yellowstone region from NOAA's National Centers for Environmental Prediction (NCEP) website or via direct data request.
- Request any archived ashfall-plume simulations for Yellowstone eruption scenarios (if available) or equivalent documentation from USGS/NOAA describing plume heights, ashfall patterns and concentration profiles for VEI-6 eruptions.
- Establish pre-event agreement with NOAA to provide 3-hourly VAFT updates and 12-hour wind-forecast products to the forward UC element from T-24h through T+72h, with direct communication to the Ashfall Forecasting Officer.

**Access Difficulty**: Medium. VAFT model output is available through NOAA, but requires pre-event data-sharing agreements and specific request for Yellowstone-scenario initialization. Wind forecasts are freely available from NCEP.

**Essential Information**:

- Identify the specific ashfall-dispersion thresholds (PM10 concentrations in µg/m³) at which shelter siting becomes untenable and automatic relocation must be triggered at each of the three nominated shelter sites (Bozeman, Idaho Falls, and the third site to be selected at T+6 hours).
- List the hourly VAFT model output products required from T-24 hours through T+72 hours, including: grid resolution, forecast lead times, PM10/PM2.5 concentration outputs at multiple altitudes, and vertical ash-column height projections.
- Detail the wind-forecast data inputs that feed the NOAA VAFT model, including GFS grid resolution, update frequency, and any high-resolution local model (NAM, HRRR) data available for Yellowstone-region refinement.
- Quantify the forecast uncertainty range (currently stated as ±50 km shelter-siting margin) by eruption scenario (VEI-6 vs. VEI-7) and wind-profile class (e.g., winter westerlies, summer ridge circulation).
- Specify the decision rule linking VAFT model output at T+6 hours to the three ranked shelter sites: which PM10 threshold at each site triggers rejection and escalation to the backup site?
- Define how historical ashfall case studies (Mount St. Helens 1980, Eyjafjallajökull 2010) inform model validation and sensitivity analysis for Yellowstone-scenario applicability, and list any caveats about model performance under extreme-eruption conditions.
- Establish the refresh schedule and real-time data handoff: which NWS forecast office (Billings or Riverton) is the primary VAFT output source, what is the communication protocol to the forward UC element Ashfall Forecasting Officer, and what is the fallback if NOAA systems fail?
- Confirm current access status: can VAFT model output, GFS wind data, and any Yellowstone scenario simulations be downloaded and displayed at a field command post during Month 1–3 (2026-11-14 to 2027-01-14) hardening and the actual event, and what pre-event data-sharing agreement must be executed by Month 1 (2026-11-14)?

**Risks of Poor Quality**:

- Shelter selection at T+6 hours based on inaccurate or outdated ashfall forecasts places 15,000–25,000 evacuees in zones of moderate to heavy ashfall, forcing emergency relocation within 6–12 hours and consuming 3–6 hours of transport, buses and intake capacity during peak operations.
- VAFT model initialization errors or wind-forecast inconsistencies between GFS and local models lead to conflicting shelter-siting recommendations, causing decision paralysis at the forward UC and delaying shelter assignment by 1–2 hours.
- Missing or incomplete documentation of forecast uncertainty ranges by eruption scenario and wind profile prevents the Ashfall Forecasting Officer from defending shelter-siting decisions to the UC when actual ashfall diverges from forecast, eroding command credibility.
- Real-time VAFT output unable to be displayed or updated at the forward UC element due to unclear data-handoff protocols or missing pre-event agreements results in the Ashfall Forecasting Officer relying on manual updates from NOAA via voice-only communication, adding 30–60 minute latency to shelter-siting updates.
- Forecast model limitations during an unprecedented VEI-7 eruption (ashfall duration, PM10 concentrations, and settling rates potentially far outside historical ranges) not documented in advance leads to public loss of confidence in shelter assignments and triggers unplanned evacuation of shelters.
- Absence of a fallback ashfall-forecasting method if NOAA systems are ash-contaminated or grid-power-dependent (NCEP, NWS servers) during the event leaves the UC without objective ashfall data for relocation decisions after T+24 hours.

**Worst Case Scenario**: Pre-event VAFT model access is not established, model output format is unclear, and no data-sharing agreement is in place when Month 0 (2026-10-14) begins. At T+6 hours, the Ashfall Forecasting Officer requests the latest model output but encounters a 2–4 hour NOAA data-processing delay or network outage, forcing shelter-siting decisions to be made on a 12-hour-old forecast. Actual ashfall at T+12 hours diverges sharply from the obsolete forecast, placing 20,000 evacuees in heavy ash (PM10 >200 µg/m³). By T+18 hours, respiratory distress cases at the primary shelter exceed hospital capacity, and the UC orders emergency relocation. The chaotic 6-hour relocation consumes half the available buses, doubles the shelter intake processing time, and strands 500–1,000 evacuees awaiting transport. An estimated 10–20 preventable respiratory-distress hospitalizations and 1–3 deaths occur during the relocation window and its aftermath. Simultaneously, loss of VAFT output after T+24 hours (due to NCEP server failure or ash contamination of local NWS equipment) leaves the UC without an objective basis for further shelter adjustments, forcing decisions based on visual ash depth and evacuation reports alone.

**Best Case Scenario**: NOAA VAFT model output and GFS wind forecasts are pre-tested and integrated into the forward UC common operating picture by Month 2 (2026-12-14). A signed data-sharing agreement ensures 3-hourly VAFT updates and 12-hour wind-forecast products flow directly to the Ashfall Forecasting Officer from T-24 hours through T+72 hours. At T+6 hours, shelter-siting decisions are made on a current forecast with clearly documented uncertainty bounds (±40 km for VEI-6 scenario under typical wind patterns). Real-time PM10 sensors at each shelter validate forecast accuracy within ±15 µg/m³. When actual ashfall at T+12 hours closely matches the T+6 forecast, evacuee confidence in shelter locations remains high, reducing unplanned departures. A ranked backup shelter 50+ km upwind remains available but is not needed. By T+24 hours, the UC confirms that all three shelters remain suitable under the latest VAFT forecast, eliminating relocation overhead and preserving bus and medical-response capacity for actual emergencies. The Ashfall Forecasting Officer's timely, accurate briefings sustain UC and public trust through the full 72-hour window and any Scenario Beta extension.

**Fallback Alternative Approaches**:

- If NOAA VAFT model output cannot be accessed in real time during the event, establish a pre-event arrangement with USGS Cascades Volcano Observatory (Vancouver, WA) to provide alternative ashfall-transport calculations (e.g., using ASHFALL or similar operational models) with 1–2 hour update latency via satellite phone to the forward UC.
- Designate an Ashfall Forecasting Officer with formal training in volcanic ash physics and plume modeling by Month 1 (2026-11-14), who can interpret GFS wind-forecast products directly and make manual ashfall-siting estimates if digital VAFT output is unavailable; pre-produce printed ashfall-scenario lookup tables (plume-height vs. wind-speed vs. PM10 footprint) as hardcopy reference.
- Establish a 24/7 direct hotline from the forward UC to the NWS Billings (or Riverton) Forecast Office beginning T-24 hours, with a named NWS meteorologist committed to providing 30-minute VAFT briefings by voice even if digital data cannot be transmitted; record briefings for shared-operating-picture documentation.
- Pre-position a portable weather-radar unit and air-quality monitoring van (equipped with lidar and PM10/PM2.5 sensors) at the forward UC element, capable of observing actual ashfall arrival and fallout patterns in real time; use observed ash depth, visibility and air-quality readings to validate or override VAFT forecasts at T+12, T+18 and T+24 hours.
- If all external ashfall-forecasting resources are unavailable, activate a conservative fallback rule: at T+6 hours, select shelter sites at the maximum distance (150–200 km) from Yellowstone in all directions (regardless of wind forecast), assume worst-case ashfall footprint extends to all selected sites, and pre-authorize Scenario Beta secondary-hub capacity activation by T+12 hours to begin onward movement of evacuees to sites outside 300 km.
- Execute an ink-on-paper ashfall-scenario reference manual by Month 1 (2026-11-14), documenting historical case studies (Mount St. Helens, Eyjafjallajökull, Piton de la Fournaise) with ashfall patterns, PM10 concentrations and time-to-arrival charts, cross-referenced to wind-pattern types; print copies for each shelter site and the forward UC so the Ashfall Forecasting Officer can select shelter locations by historical analogy if real-time modeling fails.

## Find Document 3: Current Yellowstone National Park Visitor and Staff Census Data

**ID**: 5bada706-5efa-40fe-848c-e249d21d9790

**Description**: Current visitor census data for Yellowstone National Park: estimated daily visitor counts by season, lodging occupancy (via Xanterra concession records), campground registrations, backcountry permit issuance rates, and staff employment counts. Provides baseline for the 35,000 tourists and 800 staff estimate in the canonical facts, and enables refinement of shelter-capacity requirements if actual occupancy differs from assumption. Intended audience: Project Manager, shelter planners, population-estimators. Context: the plan assumes 35,800 evacuees for Zone Zero; if actual peak-season occupancy is higher or lower, shelter and corridor capacity calculations must be adjusted.

**Recency Requirement**: Most recent available year (2024–2025 season data preferred); monthly breakdowns to identify peak occupancy periods and seasonal variation.

**Responsible Role Type**: Project Manager / Shelter Planner

**Steps to Find**:

- Contact Yellowstone National Park Public Affairs office (Mammoth Hot Springs, WY, or online at nps.gov/yell) and request current visitor-use statistics and seasonal occupancy forecasts.
- Obtain lodging occupancy data from Xanterra Parks and Resorts (concessioner operating all park hotels and campgrounds); request monthly bed-occupancy rates and typical staff counts.
- Request NPS backcountry permit data: typical number of active permits (by date), geographic distribution of permit holders and average party size.
- Cross-reference with NPS entrance-fee statistics and vehicle-count data at each of the three main entrances to validate visitor-population estimates.

**Access Difficulty**: Easy. NPS maintains public visitor-use statistics on its website; Xanterra occupancy data can be requested through official channels (pre-event coordination).

**Essential Information**:

- Current visitor census data for Yellowstone National Park: daily visitor counts by season, lodging occupancy rates (Xanterra records), campground registrations, backcountry permit issuance and geographic distribution, and staff employment counts for the most recent full season (2024–2025 preferred).
- Refinement of the 35,000 tourist + 800 staff baseline: if actual peak-season occupancy differs significantly from 35,800, shelter-capacity and corridor-throughput calculations must be adjusted within the Zone Zero clearance deadline of T+6 hours.
- Monthly and seasonal occupancy patterns to identify the window of highest concurrent visitor population and determine whether the 35,800 figure represents a reasonable worst-case or a typical peak.
- Breakdown of visitor origin (domestic vs. international) and estimated share of non-English speakers and mobility-limited visitors to validate the multilingual-alert and assisted-evacuation plans.
- Lodging and campground distributions across the park (Mammoth, Norris, Canyon, Lake, Old Faithful, West Yellowstone gateway) to tie evacuation corridors to actual visitor clusters and assess whether the three-exit split (West 50%, North 30%, East 20%) matches occupancy distribution.
- Backcountry permit data: typical number of active permits per day during peak season, geographic spread and average party size, to confirm the 50–100 parties (200–400 people) estimate for the sweep protocol.

**Risks of Poor Quality**:

- Shelter capacity is sized to 35,800 people; if actual peak occupancy is 40,000–50,000, the plan underestimates by 4,000–14,000 evacuees, forcing overcrowding or secondary relocation during the T+6 to T+24 phase and straining water, N95 and fuel supplies by 10–40%.
- If visitor origin data shows >50% international visitors (vs. the plan's ~40% assumption), multilingual alerts and consular coordination become even more critical, but the plan's five-language coverage may be insufficient for low-incidence populations (e.g., Mandarin, Arabic-speaking visitors).
- Backcountry permit data uncertainties (actual dispersal, party sizes, compliance with mandatory evacuation orders) directly affect the 'last-person-out' risk; an underestimate of active permits could leave 100–200 unaccounted hikers stranded, requiring secondary extraction during ashfall.
- If lodging occupancy is concentrated at one gateway (e.g., Old Faithful with 60% of visitors) rather than distributed, the district-to-gate assignment and three-way traffic split become unbalanced, overloading one exit and underutilizing another, extending Zone Zero clearance time.
- Seasonal variation not captured: if the 72-hour eruption window falls during a low-occupancy season (e.g., late October), the shelter and convoy plans are over-resourced; if during peak summer, they are under-resourced by 20–40%.

**Worst Case Scenario**: If census data is unavailable or significantly underestimates peak occupancy, the plan may have sized shelters for 35,800 people when actual evacuation demand is 45,000–55,000. A 15,000–20,000 person shortfall in shelter capacity forces either overcrowding with 50–100 additional deaths from dehydration, respiratory distress or medical decompensation, or secondary emergency shelter activation requiring 6–12 additional hours and USD 10–20 million unplanned expenditure. Simultaneously, an underestimate of backcountry permits could leave 200–300 unaccounted hikers, triggering a large-scale SAR operation during ashfall and exposing rescuers to life-threatening conditions. The plan's credibility with public, governors and media collapses if the initial shelter capacity proves demonstrably inadequate within 12 hours of activation.

**Best Case Scenario**: Current, validated census data confirms the 35,800 baseline as accurate or conservatively high, allowing the plan to size shelters with high confidence and allocate the three-exit split (West 50%, North 30%, East 20%) proportionally to actual lodging and visitor distributions. Backcountry permit data enables a precise sweep strategy and reduces the unaccounted population to <50 people, eliminating last-person-out risk. Visitor-origin and language data refine multilingual alerts to match actual populations, reducing non-compliance and evacuation delays among non-English speakers. Seasonal occupancy patterns identify the time of year when the plan's capacity margins are tightest, enabling prioritized readiness exercises and supply checks for that season.

**Fallback Alternative Approaches**:

- If current season census data (2024–2025) is unavailable, obtain the most recent complete year available (2023–2024) and adjust upward by 2–5% (estimated trend) to account for growth, then conduct a rapid survey of Xanterra lodging managers and NPS entrance rangers during the Month 0 (2026-10-14) preparation phase (T-12 to T-6 hours) to confirm whether occupancy patterns have shifted.
- If backcountry permit data cannot be obtained from the NPS permit system in time, request Yellowstone ranger district supervisors to provide rapid verbal estimates of active permits during the peak season window and typical party distributions, and increase the sweep reserve from 2–3 last-resort shelters to 4–5 to account for higher uncertainty.
- If lodging-distribution data is incomplete, assume uniform distribution across gateways and apply a conservative 10% buffer to the smallest exit (East at 7,160 people) to handle route-choice variance and last-minute changes, bringing the East Entrance flow to 7,876 people and reducing the West Entrance from 17,900 to 17,484.
- If international-visitor origin data shows a significantly higher share (>60%) than the ~40% assumption, engage consular liaison officers 30 days before Month 0 (2026-10-14) to identify additional languages for translation and pre-arrange cultural-liaison volunteers from embassy or community networks in Denver and Salt Lake City.
- If the eruption window is confirmed to fall outside peak-season months, conduct a sensitivity analysis of the shelter and supply plan under low-occupancy assumptions (e.g., 15,000–20,000 evacuees instead of 35,800) and adjust contingency reserves accordingly, reducing unnecessary pre-positioning cost by USD 5–10 million.

## Find Document 4: Zone One Registered Resident Population Census (West Yellowstone, Gardiner, Cody and Surrounding 100 km Radius)

**ID**: 773771a1-c3cc-4223-9215-45c3086368c1

**Description**: Registered resident population data for communities within 100 km of Yellowstone Caldera center: West Yellowstone (Madison County, MT), Gardiner (Park County, MT), Cody (Park County, WY) and surrounding unincorporated areas. Includes baseline population (permanent residents), seasonal residents, and transient populations (hotels, RVs). Serves as the denominator for Zone One evacuation success metrics (Gate G2: 95% of registered residents out by T+24h). Intended audience: Project Manager, Zone One evacuation coordinator, shelter capacity planner. Context: the canonical facts list Zone One as 'not quantified'; a census is required by T+6h to confirm shelter capacity is adequate.

**Recency Requirement**: Most recent decennial Census (2020 Census data from U.S. Census Bureau); supplemented with county population estimates for 2024–2025.

**Responsible Role Type**: Project Manager / Emergency Manager (MT, WY counties)

**Steps to Find**:

- Contact Madison County, Park County (Montana) and Park County (Wyoming) County Clerk / Emergency Management offices and request current registered resident counts and voter-registration data as proxy for residential population.
- Download 2020 U.S. Census Bureau data for West Yellowstone city (Madison County, MT), Gardiner census-designated place (Park County, MT) and Cody city (Park County, WY) from census.gov.
- Request seasonal/transient population estimates from local chambers of commerce (West Yellowstone Chamber, Gardiner Chamber, Cody Chamber) based on hotel and RV-park occupancy data.
- Coordinate with Montana and Wyoming emergency management to develop a rapid census-update protocol (online survey or phone canvassing) for T+6h status confirmation during the evacuation window.

**Access Difficulty**: Easy. U.S. Census data is freely available; county population data can be requested from county emergency managers. Seasonal-occupancy estimates require chamber-of-commerce coordination but are typically available.

**Essential Information**:

- Registered resident population count for West Yellowstone (Madison County, MT), Gardiner (Park County, MT), Cody (Park County, WY) and the surrounding 100 km radius Zone One area, broken down by permanent residents, seasonal residents, and transient occupants (hotels, RVs, campgrounds).
- Baseline population figures from the 2020 U.S. Census and 2024–2025 county estimates to serve as the denominator for Zone One evacuation success metric (Gate G2: 95% of registered residents evacuated by T+24 hours).
- Current hotel, motel, RV park and campground occupancy rates and typical maximum capacity during peak season to estimate transient population at the time of the eruption window.
- Seasonal resident population counts and arrival/departure patterns to estimate occupancy during the 72-hour decision window (Month 0, October 2026).
- Census tract-level or neighborhood-scale resident distribution across the three gateway communities to support shelter-capacity allocation and evacuation-traffic routing by district.
- A rapid census-update protocol or survey mechanism (online form, phone canvassing script, concessioner coordination) that can be executed at T+6 hours to confirm current occupancy and account for visitors who may have left the zone or arrived between the last Census update and the event.

**Risks of Poor Quality**:

- Underestimated Zone One resident population results in undersized shelter capacity, forcing evacuees into overflow sites that lack water, medical triage or reunification services, increasing respiratory distress and missed-reunification incidents by an estimated 10–20%.
- Outdated or incomplete seasonal-resident counts leave 500–2,000 transient occupants (hotel guests, RV campers) unaccounted for in shelter planning, creating a gap between assumed and actual shelter demand and delaying intake by 2–4 hours.
- Absence of a T+6 hour census-update protocol means Gate G2 success metric (95% of registered residents out) cannot be verified or defended; incident commander lacks defensible clearance status to begin Zone One Phase 2 closure and perimeter enforcement.
- Inaccurate district-scale population distribution across West Yellowstone, Gardiner and Cody leads to misallocation of evacuation traffic to the three exits (West, North, East), causing overload at one corridor and underutilization of others, extending peak evacuation time by 1–2 hours.
- Missing occupancy data for peak-season hotels and RV parks in October 2026 forces shelter-capacity planning to use worst-case estimates (100% occupancy assumed), over-committing shelter space and straining supply convoys, or under-estimates (50% occupancy assumed), leaving 1,000–3,000 evacuees unsheltered.

**Worst Case Scenario**: Zone One resident population is unquantified at T+0 hours. Shelter capacity planning assumes 25,000–35,000 occupants based on the 2020 Census plus estimates of seasonal residents and tourists. At T+6 hours, when Gate G2 requires confirmation that 95% of registered residents are out, the incident commander cannot verify this metric because no authoritative current census exists. Meanwhile, actual occupancy at gateway communities may be 40,000–45,000 (peak season, 50% above estimate), overwhelming pre-staged shelters designed for 35,800. Unaccounted-for evacuees (5,000–10,000 people) cluster at secondary shelters and lodging outside the plan, creating shadow evacuation that saturates roads to Billings and Salt Lake City and delays organized medical evacuation by 4–6 hours. Two to five preventable deaths occur due to delayed shelter intake and respiratory care.

**Best Case Scenario**: A current census of West Yellowstone, Gardiner, Cody and surrounding 100 km radius is obtained from county emergency-management offices and the 2020 Census by T+0 hours. Seasonal-occupancy data from chambers of commerce confirm that peak-season (October 2026) transient population adds 3,000–5,000 to the baseline resident count, yielding a Zone One total of 12,000–18,000 registered residents and estimated 17,000–23,000 actual occupants including tourists. Shelter capacity planning is right-sized to 35,800 (Bozeman 15,000, Idaho Falls 10,000, third site 10,800), with no excess or shortage. A T+6 hour census-update protocol (rapid phone survey or online form) confirms that 95% of registered residents have exited, supporting Gate G2 approval. Perimeter enforcement and Scenario Beta escalation proceed without delay. No shelter relocations are needed; all evacuees reach adequate intake and medical triage within 4 hours.

**Fallback Alternative Approaches**:

- Request emergency Census Bureau recount or American Community Survey extraction for the three gateway towns from the U.S. Census Bureau's emergency-data hotline within 6 hours of declaration, using 2024–2025 population estimates and decay models to project October 2026 occupancy.
- Engage Montana and Wyoming emergency-management officials to request that county voter-registration offices and property-tax assessor records be searched for registered resident counts at the Zone One addresses within 4 hours of T+0.
- Coordinate with Xanterra Parks and Resorts (park concessioner) to extract lodge and campground guest manifests from their reservation system at T+0, providing a real-time snapshot of transient occupancy at that moment.
- Activate local chambers of commerce in West Yellowstone, Gardiner and Cody to conduct a rapid telephone or email survey of major hotels, motels and RV parks at T+0, asking for current occupancy rates and capacity during the peak season.
- Develop and pre-authorize a simple SMS or online form survey that can be deployed at shelters at T+6 hours (via IPAWS or local radio), asking evacuees to confirm their pre-event residence (Zone One or elsewhere) and provide a count of persons in their household, generating a real-time tally of actual occupancy.
- Designate a fallback shelter-capacity assumption (worst-case: 50,000 occupants including unplanned shadow evacuees) and pre-authorize activation of 1–2 additional tertiary shelters (e.g., university dormitories or fairground facilities) in Billings or Boise if the T+6 census shows occupancy above 40,000.

## Find Document 5: Existing Regional Hospital Bed Capacity, Emergency Department Surge Plans and Current Staffing Rosters

**ID**: 5107aec8-e81d-4dd8-91f0-21ce7950c3f6

**Description**: Current bed-capacity inventories, emergency-department surge protocols and staffing rosters for the three designated receiving hospitals (Bozeman Deaconess Medical Center, Livingston HealthCare, Eastern Idaho Regional Medical Center, Idaho Falls). Includes baseline bed counts (ICU, trauma, respiratory), current staffing (emergency physicians, respiratory therapists, nurses), and any existing mass-casualty or disaster-surge expansion plans. Serves as input for hospital-surge dispersal planning and identification of pre-emptive patient transfers. Intended audience: Hospital Surge Dispersal Officer, hospital administrators, public health officer. Context: the plan assumes base surge capacity at three hospitals; this data enables real capacity validation and identification of staffing gaps.

**Recency Requirement**: Current (2024–2025) hospital census data, bed-capacity inventories and staffing rosters.

**Responsible Role Type**: Public Health & Mass-Casualty Medical Logistics Director / Hospital Administrator

**Steps to Find**:

- Contact administrative offices of Bozeman Deaconess Medical Center, Livingston HealthCare and Eastern Idaho Regional Medical Center directly and request current bed-capacity inventories, ED surge plans and staffing rosters (may require formal data-sharing agreement and confidentiality assurance).
- Request any existing hospital emergency operations plans or disaster-response protocols that address mass-casualty surge or infectious-disease isolation.
- Obtain Ambulance Services and EMS routing data from county EMS coordinators to understand current patient-transport capacity and hospital destination protocols.
- Coordinate with state health departments (Montana, Wyoming, Idaho) to obtain aggregate hospital-capacity data and mutual-aid surge-capacity estimates from other hospitals in the region.

**Access Difficulty**: Medium. Hospital bed-capacity and staffing data are sensitive (federal reporting required for Medicare facilities); access requires pre-event formal coordination and confidentiality agreements. State health departments may have aggregate data available.

**Essential Information**:

- Obtain current (2024–2025) bed-capacity inventories (ICU, trauma, respiratory beds) from each of the three designated receiving hospitals (Bozeman Deaconess Medical Center, Livingston HealthCare, Eastern Idaho Regional Medical Center, Idaho Falls).
- Document baseline staffing rosters: emergency physicians, respiratory therapists, nurses, and any mass-casualty/disaster-surge expansion protocols currently in place at each facility.
- Quantify existing emergency-department surge-capacity protocols: maximum additional beds that can be opened, estimated time to activate each surge level, and staffing assumptions for each level.
- Identify any pre-existing disaster-response plans or pandemic-surge protocols that address respiratory care, isolation capabilities, or mass-casualty triage at each hospital.
- Confirm current ambulance transport capacity and EMS routing protocols to the three hospitals, including any mutual-aid arrangements with other regional facilities.
- Identify staffing gaps specific to respiratory-care surge: respiratory therapist availability, ventilator inventory, and any existing agreements for surge staffing from other facilities or traveling providers.
- Obtain state-level aggregate hospital-capacity data from Montana, Wyoming, and Idaho health departments to identify backup surge hospitals beyond the three named facilities.
- List any existing memoranda of understanding (MOUs) or mutual-aid agreements between the three hospitals and other regional facilities for patient transfers, staffing, or resource sharing during emergencies.

**Risks of Poor Quality**:

- Inaccurate bed-capacity data leads to over-estimation of receiving-hospital surge capability, causing dispersal officers to assign more patients to facilities than can realistically be accommodated, resulting in overcrowding, delayed care and preventable patient deterioration.
- Outdated or incomplete staffing rosters mask actual physician, nurse and respiratory-therapist shortages, leading to assignment of patient loads that exceed available clinical staff and causing care-quality collapse and mortality increases during peak ashfall.
- Missing existing surge protocols means the plan duplicates or conflicts with hospital internal operations, reducing coordination during the event and delaying activation of additional beds or staff.
- Lack of clarity on EMS routing and ambulance capacity creates bottlenecks at hospital entrances, backing up emergency transports and leaving patients on stretchers outside overflowing emergency departments for hours.
- Absence of pre-existing respiratory-therapist or ventilator surge agreements leaves hospitals unable to meet the modeled respiratory-distress surge (estimate: 500–2,000 patients over 72 hours), forcing rationing of ventilators and withholding of care from patients who could otherwise survive.
- Failure to identify backup hospitals outside the three named facilities leaves the plan with no fallback if one facility loses power, becomes damaged, or is overwhelmed beyond its surge capacity, concentrating all load on the remaining two hospitals.
- Gaps in state-level mutual-aid arrangements mean hospitals cannot rapidly access surge staffing or equipment from neighboring states, extending patient-care delays and cascading failures across the regional system.

**Worst Case Scenario**: ">A hospital surge plan based on inaccurate or outdated bed-capacity and staffing data could result in one or more receiving hospitals reaching functional capacity by T+12 to T+18 hours (during peak ashfall), after which new emergency patients cannot be admitted. Ambulances divert to distant facilities 100+ km away, extending transport times to 2–4 hours and leaving severe respiratory-distress and trauma patients untreated for critical periods. If respiratory-therapist shortages prevent full ventilator deployment, 10–20 patients with salvageable acute respiratory distress die due to lack of available mechanical ventilation. A power loss at one hospital coupled with delayed fuel-convoy arrival (due to inaccurate logistics assumptions) extends the outage to 4–6 hours, forcing manual ventilation and cancellation of surgeries, with an additional 5–10 preventable deaths. The cascade of hospital failures erodes public confidence in the medical response, increases uncontrolled flight from shelter to distant hospitals and reduces compliance with evacuation orders, adding 2–4 hours to overall evacuation time. Estimated worst-case: 20–50 preventable hospital deaths, 1,000–3,000 patients in delayed or degraded care, regional medical system destabilization lasting weeks.

**Best Case Scenario**: ">With accurate, current hospital bed-capacity and staffing data, the Hospital Surge Dispersal Officer can validate and right-size patient-distribution assignments, ensuring each of the three receiving hospitals is loaded to realistic surge capacity without overcrowding. Pre-existing surge protocols and staffing agreements are identified and integrated into the response plan, enabling smooth activation of additional beds and staff within the first 2–4 hours of patient arrival. Backup hospitals outside the three named facilities are confirmed and pre-briefed, providing a fallback if one facility faces capacity or power constraints. Respiratory-therapist and ventilator surge agreements are formalized by Month 1 (2026-11-14), eliminating uncertainty and enabling rapid deployment of travel staff or shared equipment during peak demand. EMS routing is optimized so ambulances reach appropriate receiving hospitals within 45–60 minutes, reducing out-of-hospital time and enabling early intervention. All 500–2,000 modeled respiratory-distress cases receive timely admission and mechanical ventilation; trauma and chronic-disease patients are distributed evenly across the network. Hospital power and life-support systems remain operational throughout the 72-hour event due to pre-positioned fuel reserves and proven generator startup protocols. Estimated best case: zero preventable hospital deaths, all acutely ill patients receive appropriate care within the modeled system capacity, regional medical system maintains public confidence and operational continuity.

**Fallback Alternative Approaches**:

- Contact hospital chief medical officers and chief nursing officers at each of the three receiving facilities directly by T+6 hours (within the response window) to request immediate bed-capacity and staffing confirmations verbally or via secure email; document in real time rather than rely on pre-event data if current documentation cannot be obtained before Month 0 (2026-10-14).
- Request aggregate hospital-capacity data from state health departments (Montana, Wyoming, Idaho) and the CMS/Medicare hospital database to estimate surge capacity if individual hospital data-sharing agreements cannot be executed pre-event.
- Engage a health-system consultant or hospital-capacity modeling firm in Month 1 (2026-11-14) to conduct a rapid audit of the three receiving hospitals and surrounding regional facilities, prioritizing respiratory-care and ICU surge analysis.
- Establish a standing daily coordination call with hospital administrators at each facility from T+0 through T+72, using real-time occupancy and staffing reports to dynamically adjust patient-distribution assignments and identify bottlenecks in real time.
- Pre-authorize mutual-aid requests to non-designated regional hospitals (Billings, Bozeman, Salt Lake City) and identify them as secondary dispersal destinations if the three named facilities approach capacity; include telephone and data-exchange pre-agreements.
- Conduct a Hospital Surge Exercise with the three receiving hospitals and their EMS partners by Month 2 (2026-12-14), simulating a mass-casualty arrival and testing bed-activation, patient-triage and staffing-deployment protocols, with results fed into the final operational plan.
- Arrange for rotating respiratory-therapy and nursing surge staffing from adjacent health systems or traveling healthcare-provider agencies (e.g., American Red Cross Disaster Health Services, state-level medical reserve corps) with verbal agreements by T+0 and signed contracts by Month 1 (2026-11-14).

## Find Document 6: Existing Yellowstone National Park Concessioner Operational Data (Lodging Occupancy, Staff Rosters, Transportation Fleet)

**ID**: d57f35c4-4e32-43dd-a64b-a8b280ab4b13

**Description**: Operational data from Xanterra Parks and Resorts (primary NPS concessioner): current guest-room inventory and occupancy forecasts, staff employment rosters (count and job functions), shuttle-bus fleet capacity and scheduling, and visitor-transportation logistics. Serves as input for visitor-needs assessment (language, mobility, vehicle-less populations) and assisted-evacuation planning. Intended audience: Communications Coordinator, visitor-needs planner, transportation logistics officer. Context: concessioners manage ~90% of visitor accommodation and some visitor transport; pre-event data access enables targeted multilingual outreach and transport pre-positioning.

**Recency Requirement**: Current (2024–2025 season) occupancy forecasts, staff rosters and fleet inventory.

**Responsible Role Type**: Communications and Public Alerting Coordinator / Shelter Planner

**Steps to Find**:

- Contact Xanterra Parks and Resorts operational headquarters (located near Mammoth or in Denver) and request operational data-sharing agreement covering lodging occupancy, staff rosters, guest-contact information and transportation capacity.
- Request manifests of current guests at each lodge (rooms occupied, check-in/check-out dates, nationality/language preferences if available from reservation systems).
- Obtain shuttle-bus inventory and capacity: number of buses, typical routes, seating capacity, and driver availability during peak operations.
- Request any existing concessioner emergency plans or disaster-response protocols.

**Access Difficulty**: Medium. Concessioner operational data is sensitive (commercially confidential for occupancy and forecasts); requires signed data-sharing agreement with Xanterra and NPS. Pre-event coordination is expected and typically feasible.

**Essential Information**:

- Specify the operational data fields required from Xanterra Parks and Resorts: current guest-room occupancy by lodge, staff employment count by job function (drivers, kitchen, housekeeping, management), shuttle-bus fleet inventory (number of buses, seating capacity, current deployment schedule), and any existing concessioner emergency-response protocols or evacuation procedures.
- Quantify visitor-composition data: percentage of non-English-speaking guests by language group, percentage of guests arriving via tour operator (vehicle-less), percentage with mobility or medical-assistance needs, and typical length of stay by guest type (day-use vs. overnight).
- Confirm date ranges for occupancy forecasts: peak-season occupancy rates for the months of August–October (the eruption-window months), including weekday versus weekend variation and holiday or event effects that might drive occupancy higher or lower.
- Obtain staff rosters: employee names, contact information, job titles, shift schedules and languages spoken, so that multilingual volunteers and evacuation-assistance personnel can be pre-identified and pre-briefed before T+0.
- Detail shuttle-bus operational schedules: typical daily routes (lodge to park attractions, inter-lodge transport, visitor center loops), number of scheduled departures per route, current driver availability and willingness to participate in emergency evacuation, and fuel-consumption rates to estimate contingency fuel needs.
- Identify any concessioner facilities outside the park that could serve as auxiliary shelter or staging areas (e.g., maintenance yards, storage depots, administrative offices), with capacity and utility-service capability (water, power, sanitation).
- Request any existing data-sharing agreements or emergency-coordination protocols between Xanterra and NPS, so that data access procedures and approval chains are pre-established by Month 0 (2026-10-14).

**Risks of Poor Quality**:

- Inaccurate or outdated occupancy data leads to overestimation or underestimation of the 35,000-person evacuation load; if actual occupancy is 20–30% higher or lower than planned, contraflow throughput and shelter capacity calculations are invalidated, forcing real-time capacity revisions during the evacuation peak.
- Missing or incomplete staff rosters prevent pre-identification of multilingual staff or experienced drivers needed for evacuation shuttles and language support; last-minute staffing recruitment during T+0 to T+12 h is unreliable and leaves non-English-speaking guests without clear guidance.
- Underestimated non-English-speaking visitor population (if concessioner data shows only 10–15% instead of actual 30–40%) leaves 5,000–10,000 evacuees without multilingual alerts, causing 1–3 hour delays and increased non-compliance with shelter-assignment instructions.
- Inaccurate shuttle-bus capacity or availability data (if fleet is smaller or less flexible than assumed) strands 500–2,000 vehicle-less guests and forces unplanned secondary-evacuation logistics during peak contraflow congestion.
- Lack of pre-established data-sharing protocol with Xanterra results in 6–12 hour delays in obtaining operational manifests at T+0, missing the window to pre-brief staff and confirm guest-contact information for targeted multilingual outreach.

**Worst Case Scenario**: Concessioner operational data is unavailable until T+6 hours or is incomplete (missing staff lists, guest languages, vehicle-less population), forcing real-time guest identification via manual lodge surveys during the evacuation peak. As a result, up to 10,000–15,000 non-English-speaking or vehicle-less guests receive no pre-evacuation briefing, experience delays of 2–4 hours in understanding route instructions or boarding evacuation shuttles, and some become separated from their transportation groups. Approximately 200–500 guests are stranded at lodges or trailheads when shuttles depart without confirmation of occupancy, requiring secondary rescue operations after T+6 h. This gap also prevents pre-identification of multilingual staff and experienced drivers, forcing ad-hoc recruitment of volunteers during the evacuation, reducing the reliability and speed of assisted-evacuation shuttles and multilingual outreach. The combination results in an estimated 2–4 hour delay in Zone Zero clearance and 5–10 preventable casualties among elderly, mobility-limited or medically fragile guests.

**Best Case Scenario**: Concessioner operational data is obtained by Month 0 (2026-10-14) via a pre-signed data-sharing agreement, providing current occupancy forecasts, complete staff rosters, shuttle-bus schedules and guest-language preferences. This enables pre-production of multilingual briefing materials, pre-identification of 20–50 multilingual staff and experienced drivers, pre-assignment of shuttle buses to lodges, and advance preparation of priority-evacuation staging areas for mobility-limited guests. At T+0, lodge staff can immediately brief guests in their preferred languages using pre-produced materials, and evacuations begin with confirmed transportation arrangements. Vehicle-less guests and those with mobility or medical needs are staged for priority-evacuation shuttles before general traffic departs, reducing bottlenecks. Evacuation of non-English-speaking guests is accelerated to 30–45 minutes per lodge, and Zone Zero clearance is achieved within 5.5 hours, providing a safety margin before ashfall intensity increases. Approximately 99% of 35,800 evacuees depart with clear instructions and assigned transportation, avoiding stranding incidents.

**Fallback Alternative Approaches**:

- If Xanterra data-sharing agreement is not finalized by Month 0 (2026-10-14), request that NPS issue an emergency administrative order for concessioner data access under the Stafford Act declaration at T+0, citing public-safety necessity. Legal authority exists; execution may take 2–4 hours but avoids weeks of negotiation.
- If current occupancy forecasts are unavailable, use historical occupancy records (prior 2–3 years) for the eruption-window months (August–October) to estimate a probability range (high/medium/low occupancy scenario) and plan shelters for the high-occupancy case (35,000 is the user constraint, so assume peak load).
- If staff rosters are not provided, establish a concessioner hotline at T+0 with lodging managers at each property, request same-day employee lists by phone, and use volunteer-sign-up forms at each lodge to identify multilingual and evacuation-trained staff in real time.
- If shuttle-bus capacity is lower than assumed, requisition additional charter buses from regional operators (contract with Greyhound, tour operators) using FEMA emergency-contract vehicles, with 4-hour mobilization clauses in pre-awarded agreements.
- If guest-language data is absent, produce multilingual briefing materials in the five most common visitor languages (Spanish, Japanese, German, Mandarin, French) at Month 0 (2026-10-14) based on national visitor-pattern benchmarks, and distribute them to all lodges at T-12 hours; follow up with live interpretation at check-in desks if real-time language identification is possible.
- If concessioner facilities cannot be accessed for secondary staging, designate parks, schools and fairgrounds in West Yellowstone, Gardiner and Cody as auxiliary shelters by Month 0 (2026-10-14), with pre-arranged utility and security access.

## Find Document 7: Bottled Water, N95 Respirator, Generator Fuel and Emergency Supply Industry Capacity and Pricing Data

**ID**: a333ea0c-28d1-45b6-9a43-4b13f85482c9

**Description**: Current industry capacity and pricing for emergency supplies: bottled-water production and distribution capacity in the Mountain West (estimated liters per day from major suppliers), N95 respirator stock and manufacturing capacity (units available for emergency order), diesel generator fuel distribution networks and regional storage capacity, and medical/shelter equipment availability (cots, blankets, food, hygiene kits). Serves as input for supply-chain feasibility assessment and contract-negotiation planning. Intended audience: Emergency Logistics and Supply-Chain Director, procurement officer. Context: the plan assumes 1.43 million liters water, 100,000+ N95 masks, 72-hour generator fuel at hospitals; this data validates supply-chain feasibility and lead times.

**Recency Requirement**: Current (2024–2025) industry capacity estimates, lead times and pricing; supply-chain disruption data post-COVID.

**Responsible Role Type**: Supply Chain & Logistical Resilience Strategist

**Steps to Find**:

- Contact major bottled-water distributors (Coca-Cola, Nestlé, regional distributors) in the Mountain West (Salt Lake City, Denver, Pocatello, Billings areas) and request capacity, lead-time and pricing for bulk emergency orders.
- Contact N95 respirator manufacturers (3M, Honeywell) and medical-supply distributors and request emergency-order lead times and maximum-available inventory.
- Contact diesel-fuel wholesalers and regional fuel-distribution networks (Yellowstone Energy, Basin Fuel, regional refineries) and request capacity for emergency tanker dispatch.
- Contact medical-supply rental companies (emergency shelter equipment, cots, generators) and request rapid-deployment inventory and pricing.
- Consult Federal Emergency Management documentation on FEMA contract vehicle activation and pre-positioned supply strategies for disasters.

**Access Difficulty**: Medium. Industry data is commercially sensitive; requires direct corporate inquiry and pre-event negotiations. State emergency management agencies may have supplier contact rosters from prior disaster agreements.

**Essential Information**:

- Identify the current industry capacity (liters per day, units per month) for bottled-water production and emergency distribution in the Mountain West (Utah, Colorado, Wyoming, Montana, Idaho) from major suppliers (Coca-Cola, Nestlé, regional distributors).
- List maximum emergency-order capacity and lead times (hours to dispatch, days to delivery) for N95 respirators from 3M, Honeywell and medical-supply distributors, specifying stock available for immediate allocation versus manufacturing-lead inventory.
- Quantify diesel generator fuel distribution capacity across the region: regional storage, tanker-truck availability, wholesale pricing and surge-mobilization timelines from major fuel distributors (Yellowstone Energy, Basin Fuel, regional refineries).
- Detail medical and shelter equipment availability and rapid-deployment capacity: emergency cots, blankets, food rations, hygiene kits, generators and rental-company lead times for bulk orders.
- Specify FEMA pre-positioned contract vehicles, surge-activation procedures, vendor rosters and cost-share mechanisms for emergency water, fuel and supply procurement.
- Compare post-COVID supply-chain disruption recovery status and current pricing against 2024–2025 market benchmarks for each supply category.

**Risks of Poor Quality**:

- Inaccurate or outdated industry-capacity data leads to overestimation of water-convoy dispatch speed, causing T+12 h dispatch target to become unachievable and convoys arriving T+24–T+36 h instead, leaving shelters with 12–24 hours of inadequate water supply.
- Underestimated N95 respirator lead times or stock cause initial 100,000-unit allocation to prove insufficient, forcing emergency resupply that arrives too late, leaving shelters and responders without masks during peak ashfall.
- Inaccurate fuel-distribution capacity or pricing overstates the feasibility of 72-hour generator reserves at three hospitals, risking grid-failure scenarios in which fuel does not arrive within the 4–6 hour window needed to prevent surgical cancellations and ventilator failures.
- Missing or incomplete FEMA contract-vehicle details prevent verbal activation and 12-hour dispatch, reverting to standard 24–48 hour procurement, delaying all supply arrival by 1–2 days.
- Omission of regional supplier contact rosters and pre-event pricing locks the plan into worst-case commercial terms at emergency rates, consuming budget contingency without improving actual delivery timelines.

**Worst Case Scenario**: Industry data is unavailable, severely outdated or commercially withheld, forcing the plan to assume worst-case lead times and capacity constraints at Month 0 (2026-10-14) (T+0). Convoys dispatch 12–24 hours late due to unknowable supplier constraints; N95 stock proves insufficient by T+48 h and cannot be rapidly resupplied; hospital fuel reserves fall short of 72-hour needs. Shelters experience water shortages from T+24 to T+36 h affecting 15,000–20,000 evacuees, and respiratory-protection gaps leave thousands unmasked during peak ashfall. These shortfalls force emergency procurement at 2–3x normal cost, consuming the USD 40 million contingency within 24 hours and leaving no reserve for shelter relocation, Scenario Beta hub staging or additional responder calls. The plan's credibility with shelter operators and host communities collapses, reducing voluntary compliance with evacuation and shelter-placement orders by 15–20%.

**Best Case Scenario**: Current industry capacity and pre-event pricing data are obtained from all major suppliers by Month 1 (2026-11-14), confirming that water convoys can be mobilized within 12 hours from Salt Lake City and arrive at shelters by T+18–T+24 h (within acceptable bounds). N95 manufacturers confirm 200,000–300,000 units available for emergency order, doubling the civilian stock. FEMA contract vehicles include 15–20 pre-authorized fuel and water vendors, enabling verbal activation and guaranteed 12-hour dispatch. Pricing for all supplies is locked in advance at 2024–2025 commercial rates. These confirmations allow the plan's supply-chain milestones to proceed on schedule: forward depots stocked by T-12 h (within the 72-hour window), no bottleneck delays, and USD 15–25 million of the USD 40 million contingency freed for Scenario Beta hub pre-positioning and shelter-relocation reserves.

**Fallback Alternative Approaches**:

- If industry data cannot be obtained directly due to corporate confidentiality, request aggregate capacity summaries from state emergency management agencies (Montana, Wyoming, Idaho, Utah emergency management offices) who maintain standing vendor rosters and post-disaster supplier agreements.
- If lead-time data is incomplete or dated, conduct a 72-hour pilot water-convoy mobilization from Salt Lake City to Bozeman during Month 2 (2026-12-14) to measure actual dispatch and transit time under realistic ashfall and traffic conditions, using this empirical result instead of industry estimates.
- If FEMA contract-vehicle details are sparse, escalate to the FEMA Region VIII supply chain coordinator (Denver RRCC) at Month 1 (2026-11-14) to obtain current vendor lists, surge-activation authorities and pre-positioned equipment rosters that already exist in FEMA systems.
- If hospital fuel and generator capacity cannot be confirmed with precision, conduct a 24-hour power-outage simulation at each receiving hospital (Bozeman, Livingston, Idaho Falls) during Month 2 (2026-12-14), testing actual generator startup, fuel consumption and load-shedding under stress to measure realistic endurance.
- If commercial pricing is unavailable, use GSA Federal Supply Schedule rates as a floor estimate and confirm with FEMA whether Stafford Act declaration authority allows emergency price adjustments, ensuring budget contingency is sized appropriately.

## Find Document 8: FEMA Region 8 and Region 10 Mutual Aid and Emergency Support Function (ESF) Resource Inventories

**ID**: 425089ab-8957-4fc5-8b04-e28ea2697075

**Description**: Current mutual-aid rosters and Emergency Support Function resource inventories for FEMA Regions 8 (Denver, covering Colorado, Montana, North Dakota, South Dakota, Utah, Wyoming) and Region 10 (Seattle, covering Alaska, Idaho, Oregon, Washington). Includes Guard unit locations and availability, pre-positioned supply stocks, medical-surge resources and transportation capacity. Serves as input for responder relief depth, supply-chain and military-asset pre-positioning planning. Intended audience: UC Incident Commander, Region 10 Liaison Officer, logistics directors. Context: the plan assumes access to Guard units and mutual-aid resources; this documentation enables specific asset identification and pre-event commitments.

**Recency Requirement**: Current (2024–2025) mutual-aid rosters and ESF inventories; any recent updates to unit locations or resource availability.

**Responsible Role Type**: Regional Emergency Management & Multi-Jurisdiction Coordination Director / FEMA Region 10 Liaison Officer

**Steps to Find**:

- Contact FEMA Regional Administrators (Region 8, Denver office and Region 10, Seattle office) and request current mutual-aid rosters and ESF resource inventories.
- Request National Guard unit rosters and availability: location of Guard units in Colorado, Montana, Wyoming and Idaho; air assets (helicopters, cargo planes) in the region; personnel available for emergency deployment.
- Request state emergency management agency contact lists for mutual-aid coordination (each state's Emergency Management Division).
- Obtain EMAC (Emergency Management Assistance Compact) resource lists for the relevant states and neighboring states.

**Access Difficulty**: Medium. FEMA regional resource data is partially restricted (Guard unit locations may be sensitive); requires pre-event formal coordination with FEMA regional administrators. State emergency management agencies maintain public mutual-aid rosters.

**Essential Information**:

- Identify current (2024–2025) mutual-aid rosters and Emergency Support Function resource inventories for FEMA Region 8 (Denver: Colorado, Montana, North Dakota, South Dakota, Utah, Wyoming) and Region 10 (Seattle: Alaska, Idaho, Oregon, Washington), including specific resource counts and deployment availability.
- List all National Guard unit locations and personnel availability in Colorado, Montana, Wyoming and Idaho, including active-duty and reserve strength by unit type (infantry, logistics, medical, signal corps, aviation).
- Quantify air assets available in Region 8 and Region 10: helicopter count and type by location, cargo-aircraft availability, medevac-capable platforms and crew readiness.
- Detail Emergency Support Function (ESF) resource inventories by function: transportation (buses, trucks), water and sanitation supplies, medical surge capacity (field hospitals, ambulances, personnel), generator fuel and power restoration equipment, communications equipment and personnel.
- Specify pre-positioned supply stocks in Region 8 and Region 10: bottled water reserves, medical consumables, fuel depots, tents and sheltering materials, and locations where stocks are held.
- Document mutual-aid activation procedures: which state agencies hold mutual-aid agreements with federal and neighboring-state partners, contact information for duty officers and resource request chains, and response-time estimates for deploying personnel and equipment across state lines.
- Confirm EMAC (Emergency Management Assistance Compact) participation and current resource commitments by Montana, Wyoming, Idaho, Colorado and neighboring states; list any standing requests or conflicts.
- Identify specific ESF coordinators (primary and backup) for each function in Region 8 and Region 10, with contact information and authority to commit resources during emergency declaration.
- Provide current assessment of medical-surge capacity: number of field hospital sets deployable, ambulance and transport availability, medical personnel (doctors, nurses, paramedics) and respiratory-support equipment (ventilators, oxygen, CPAP units) not committed to permanent assignments.
- Specify the Authority and Limitation Statement for FEMA Region 10: under what conditions does a Region 8 incident commander hold authority to request Region 10 resources without separate regional director approval, and what cost-sharing rules apply?

**Risks of Poor Quality**:

- Resource counts are overstated or unavailable: UC incident commander cannot pre-authorize specific Guard units or mutual-aid assets at T+0, forcing real-time requests that incur 2–4 hour delays and leave the plan dependent on whatever happens to be available rather than committed reserves.
- Regional mutual-aid procedures are out of date: pre-event coordination calls with state emergency management directors discover that mutual-aid rosters list units since relocated, merged or deactivated, requiring verification and re-coordination during the crisis window.
- FEMA Region 10 liaison seat at the Unified Command cannot be filled because Seattle regional office has no standing delegation to support Region 8 decisions, forcing ad hoc coordination that delays Idaho-side requests (water convoys, fuel, ambulances) by 1–2 hours.
- Medical-surge capacity is overstated because field hospitals and ambulance resources are committed to existing state readiness exercises or permanent assignments, leaving the actual available surge much smaller than the inventory lists.
- Air-asset availability is unclear: Guard helicopter schedules, maintenance status and pilot availability are not documented, so a request for medevac sorties during ashfall meets resistance or discovers assets are unavailable due to competing demands.
- Fuel depot locations and volumes are not confirmed: convoys dispatched from listed depots in Salt Lake City or Denver discover stocks have been drawn down for other emergencies or depots lack the trucking equipment to load quickly, adding 6–12 hours to delivery.
- Incomplete contact lists and duty-officer rosters: after-hours mutual-aid requests cannot reach authorized decision-makers, forcing escalation through political channels and consuming 1–2 hours of decision latency at critical moments.
- Generator fuel pre-positioning agreements with utilities are verbal or expired: hospitals and shelters receive fuel promises that are not honored when the supplier's own grid restoration consumes available stock.
- Communications equipment (radios, satellites, repeaters) inventories are not interoperable across federal, state and Guard systems, forcing signal-corps teams to spend hours on frequency coordination during the event rather than having it pre-tested.
- Cost-sharing and reimbursement rules between FEMA regions are ambiguous: disputes over who pays for Region 10 resources requested by Region 8 UC delay reimbursement and discourage mutual aid, reducing the pool of available assets.

**Worst Case Scenario**: Without current, verified mutual-aid rosters and ESF inventories, the Unified Command cannot pre-authorize specific Guard units, helicopters, medical surge or fuel convoys at T+0, forcing real-time scavenging of resources during the 72-hour evacuation window. A discovery that assumed assets are unavailable, committed elsewhere or incompatible cascades into delays: medical patients are held at shelters 2–4 hours waiting for ambulances that must be summoned ad hoc; water convoys discover depots lack trucking and loading equipment, delaying arrival from T+12 h to T+24+ h; National Guard signal teams discover radios are on incompatible frequencies, forcing 2–4 hours of field coordination when digital comms fail. These delays—multiplied across 35,800 evacuees, 15,000 at shelters, 5–10 hospitals and 10+ control points—extend the evacuation peak by 4–8 hours, overlapping ashfall onset and increasing respiratory casualties by 50–100+ people and stranding 1,000–3,000 evacuees without shelter or water. A regional mutual-aid freeze due to cost-sharing disputes could reduce available personnel and fuel by 30–50%, making the plan execution-impossible. Estimated total impact: failed evacuation, estimated 50–200+ preventable deaths, multi-state incident escalation and international attention on a catastrophic response failure.

**Best Case Scenario**: Current, verified mutual-aid rosters and ESF inventories enable the Unified Command to seat a FEMA Region 10 liaison at T+0 and pre-authorize specific Guard units (e.g., Colorado 10th Special Forces Group signal platoons, Wyoming Army Guard transportation company, Idaho National Guard medical team) with confirmed personnel counts, equipment and deployment times. Pre-coordinated cost-sharing and mutual-aid agreements remove the need for approval chains, allowing verbal resource requests to move from the forward command to regional duty officers with 30-minute response times. Helicopters, ambulances and fuel convoys are committed in writing 60 days before the event, so requests trigger pre-authorized dispatch rather than ad hoc searches. Medical surge and field hospital availability is confirmed, allowing the plan to size evacuation-shelter medical staffing with confidence. Interoperable communications equipment (radios on pre-coordinated frequencies, satellite terminals tested) is pre-positioned, so signal teams activate systems quickly rather than troubleshooting compatibility. Water and fuel convoys depart on schedule from verified depots with confirmed trucking and loading, arriving at shelters within the T+24 h target. The effect: the plan executes with predictability, responders know their resources are committed, decision latency drops from ad hoc hours to minutes, and the evacuation completes by T+6 h without stranded evacuees or supply shortfalls. Estimated total impact: evacuations complete, water and medical resources sustain shelters, fewer than 10 preventable casualties, confidence in the response and international recognition of effective disaster coordination.

**Fallback Alternative Approaches**:

- If FEMA Region 8 and Region 10 current rosters cannot be obtained in time: convene an emergency coordination call with the FEMA Regional Administrators and the state Emergency Management Directors (Colorado, Montana, Wyoming, Idaho) at Month 0 (2026-10-14) + 1 week (around 2026-10-21) to collect current unit locations, personnel counts and mutual-aid status verbally; document the call and have each director sign a confirmation memo of their commitments within 48 hours. Use the signed memos as the binding mutual-aid agreement for the plan.
- If pre-positioned supply-stock locations and volumes cannot be verified: conduct a site survey of all candidate depots (Salt Lake City water distribution centers, Denver fuel terminals, Colorado and Montana Guard armories) by Month 0 (2026-10-14) + 2 weeks (around 2026-10-28), physically verifying inventory on hand, equipment condition and loading capacity; base the plan on observed stocks, not on roster claims.
- If Region 10 liaison authority and cost-sharing are unclear: request a written legal opinion from FEMA Office of General Counsel by Month 0 (2026-10-14) + 1 week (around 2026-10-21) confirming whether Region 8 UC can unilaterally request Region 10 resources under Stafford Act declaration and what cost-sharing applies; if written opinion is not available, have FEMA Regional Administrators issue a joint memo committing to cost-sharing and mutual aid as of T+0.
- If National Guard air assets and pilot availability cannot be confirmed: contact the adjutant generals of Colorado, Montana, Wyoming and Idaho by Month 0 (2026-10-14) + 1 week (around 2026-10-21) and request a signed 'Statement of Force Readiness' confirming number of helicopters, pilots and hours available for emergency dispatch; if the statement shows insufficient capacity, request activated federal mobilization (National Guard under Title 10 federal orders) by Month 0 (2026-10-14) + 2 weeks (around 2026-10-28).
- If ESF medical-surge capacity is overstated or committed: work with state health officers (CO, MT, WY, ID) and the American Hospital Association (Region 8/10 chapters) starting at Month 0 (2026-10-14) + 1 week (around 2026-10-21) to obtain a certified inventory of field hospital sets, ambulances and medical personnel available for emergency deployment; certify that named resources are not committed to other drills or operations until Month 4 (2027-02-14) (after the eruption window).
- If communications equipment is not interoperable: request that FEMA Region 8 and the National Communications System (NCS) conduct a pre-event frequency-coordination and radio-compatibility exercise at Month 0 (2026-10-14) + 4 weeks (around 2026-11-11), testing all federal, state and Guard radio systems on the named ESF-2 (Communications) channels; document the tested frequencies and create a 'Comms Compatibility Matrix' binding for the event.
- If mutual-aid activation procedures are unclear or outdated: have the UC Incident Commander request that each state (MT, WY, ID, CO) issue a Governor-signed mutual-aid authorization letter by Month 1 (2026-11-14), pre-authorizing specific resource requests and waiving normal approval chains during the Stafford Act declaration; attach the signed letters to the Unified Command plan as binding commitments.
- If cost-sharing disputes risk freezing mutual aid: escalate the issue to FEMA Regional Directors (Region 8 and 10) and the Office of the Federal Coordinator for Alaska (responsible for Region 10 disaster response) by Month 0 (2026-10-14) + 2 weeks (around 2026-10-28), and request a written Federal Disaster Cost-Sharing Memorandum of Agreement specifying that all mutual-aid resources requested by the UC are eligible for 100% federal reimbursement under the declaration; have OMB or the White House Counsel sign the MOA if necessary to remove state/federal budget disputes.

## Find Document 9: Montana, Wyoming and Idaho Governor Emergency Declaration Authorities and State Emergency Management Plans

**ID**: 95aae559-8fd0-460b-a695-9a7e484c887e

**Description**: Current state emergency-management plans, governor emergency-declaration authorities and automatic mutual-aid activation procedures for Montana, Wyoming and Idaho. Includes state-specific evacuation protocols, National Guard mobilization procedures and cost-sharing rules for emergency response. Serves as input for Command Structure and Authority Framework and Stafford Act cost-allocation negotiations. Intended audience: UC Incident Commander, governors' representatives, emergency managers. Context: the plan requires governor pre-authorization (verbal by T+6h, signed by Month 1 = 2026-11-14); this documentation clarifies state-level procedures and legal authorities.

**Recency Requirement**: Current (2024–2025) state emergency-management plans and governor executive orders governing emergency declarations.

**Responsible Role Type**: Regional Emergency Management & Multi-Jurisdiction Coordination Director

**Steps to Find**:

- Contact State Emergency Management Divisions (Montana Disaster and Emergency Services, Wyoming Emergency Management Agency, Idaho Office of Emergency Management) and request copies of current state emergency-management plans and governor emergency-declaration procedures.
- Request state-specific evacuation and shelter-operations guidelines.
- Obtain contact information for each governor's emergency-operations liaison and chief legal counsel (for authority-transfer negotiations).
- Review state constitutions and statutes governing governor emergency powers and mutual-aid activation (typically available on state legislature websites).

**Access Difficulty**: Easy. State emergency-management plans are typically public documents or available through formal request. Governor offices maintain public lists of emergency contacts.

**Essential Information**:

- Identify each of the three states' (Montana, Wyoming, Idaho) current governor emergency-declaration authorities, including: the legal threshold for declaration, who may issue it, required legislative notification, duration limits, and automatic mutual-aid (EMAC) activation procedures.
- Detail state-specific evacuation protocols and mandatory procedures for each state: required notification timelines to counties and communities, traffic-control authority delegation (who controls contraflow), shelter-operations responsibility assignment, and cost-sharing rules during declared emergencies.
- Document National Guard mobilization procedures for each state: who authorizes activation, how many personnel are typically available, restrictions on out-of-state deployment, and cost-reimbursement eligibility under Stafford Act.
- Specify state-level hazardous-materials and fuel-handling regulations applicable to water convoys and generator fuel delivery during emergency operations.
- Clarify state authority over evacuation messaging, shelter siting and re-entry perimeter enforcement, and identify any state-imposed constraints on federal NPS incident commander authority at the boundary.
- List current state emergency-management organizational structure: title and contact information for the emergency-management director, chief legal counsel, and governor's operations liaison for each state.
- Confirm each state's cost-sharing percentage and reimbursement procedures under the Stafford Act and FEMA regional disaster declarations for evacuation, shelter operations and logistics.
- Identify any state-level agreements or MOUs already in place with FEMA, neighboring states or federal agencies that may affect mutual-aid activation or resource requests.

**Risks of Poor Quality**:

- Misunderstood or outdated governor emergency-declaration authority leads to delays (15–45 minutes estimated) in issuing formal evacuation orders, as the Unified Command may lack clarity on whether verbal pre-authorization by T+6h is sufficient or if additional state-level approvals are required.
- Unclear state evacuation protocols and traffic-control authority assignment cause disputes over who controls contraflow checkpoints and reroute decisions during the evacuation peak, resulting in 500–1,000 vehicle delays and reduced corridor throughput.
- Incomplete or inaccurate National Guard mobilization procedures lead to delays in requesting out-of-region Guard reinforcements if responder staffing falls below 50% at critical checkpoints, extending the gap in coverage by 2–4 hours.
- Missing state hazmat and fuel-handling regulations force the UC to conduct legal research during the response window, delaying water and fuel convoy dispatch by 6–12 hours and leaving shelters without adequate supply for the first 24 hours.
- Ambiguity over state authority at the evacuation boundary creates a command gap: unclear who approves shelter assignments and reroutes in the 'transition zone' where traffic crosses from NPS to state control, delaying decisions by 15–45 minutes per reroute.
- Absent or outdated contact information for state emergency managers and governors' liaisons prevents timely escalation of requests for mutual aid or cost-sharing decisions, stalling resource mobilization by 2–4 hours during the critical T+6 to T+24 window.
- Unconfirmed cost-sharing percentages and reimbursement procedures lead to disputes over which costs are reimbursable under the Stafford Act, potentially leaving the UC uncertain about budget authority and delaying procurement of critical supplies.
- Unknown pre-existing state MOUs or agreements may conflict with the UC's planned authority structure, forcing last-minute legal negotiations and creating authority ambiguity at T+0 when the response activates.

**Worst Case Scenario**: 
At T+0 hours, the Unified Command activates at the Denver RRCC and issues the verbal evacuation order for Zone One, assuming governors' pre-authorization is already in place. However, upon contact, the governors or their legal counsel challenge the NPS incident commander's authority to direct traffic control and shelter placement in their states, citing state constitutional limits on federal authority or existing state laws that require governor approval for contraflow operations. This dispute delays the issuance of formal evacuation orders by 2–4 hours. Simultaneously, unclear National Guard mobilization procedures prevent rapid deployment of additional traffic-control personnel; the UC cannot confirm whether out-of-state Guard can be deployed without explicit additional authorization from each state adjutant general. By T+6 hours, the West Yellowstone corridor experiences a gridlock backup affecting 5,000–8,000 vehicles, and no Guard reinforcements are available to expand traffic-control coverage. Evacuation time slips to T+8 to T+10 hours, and ashfall onset within this window increases respiratory distress cases by 10–20. Additionally, disputes over cost-sharing and fuel-handling regulations delay water and fuel convoy dispatch from Salt Lake City by 12+ hours, leaving shelters without adequate supply when evacuees arrive by T+8 to T+12 hours. Overall estimated impact: 2–4 hour evacuation delay, 10–20 additional respiratory distress casualties, 1–3 critical supply shortages at shelters, and erosion of public trust due to visible command confusion and inter-state conflict.


**Best Case Scenario**: 
The current state emergency-management plans clearly specify that governors' verbal authorization of evacuation orders is valid under each state's declaration authority, and pre-authorized MOUs are already in place confirming federal NPS incident commander authority over contraflow and initial shelter placement until a formal handoff order is issued. National Guard mobilization is streamlined and can proceed with out-of-state deployment via EMAC with a single phone call to each state adjutant general, removing any delay. Cost-sharing is explicitly documented (e.g., 75% federal/25% state), making budget authority clear and allowing the UC to confidently authorize procurement within the USD 200 million envelope. Contact information for state emergency managers and governors' liaisons is current, enabling real-time coordination without research delays. By T+0 hours, the UC confirms verbal authorization with all three governors, activates contraflow without legal disputes, and requests Guard reinforcements immediately; all three state emergency managers are actively coordinated into the response and provide rapid approvals for fuel, water and shelter logistics. Water and fuel convoys dispatch from Salt Lake City by T+12 hours as planned, and shelters are fully staffed and prepared by T+24 hours. The boundary authority transfer occurs smoothly at defined checkpoints, with no command gaps or reroute delays. Evacuation proceeds at planned pace: 98% of Zone Zero cleared by T+6h, 95% of Zone One by T+24h, and Scenario Beta interim destination list issued on schedule.


**Fallback Alternative Approaches**:

- If current state emergency-management plans cannot be obtained or are outdated: Conduct emergency legal briefings with each state's attorney general's office and emergency management director during the first 4 hours of the response (T+0 to T+4h) to clarify authority and cost-sharing verbally and on the record, document the findings in a memo from each governor to the UC, and rely on those memos as the operational authority base for the subsequent 68 hours.
- If National Guard mobilization procedures are unclear or non-standard: Pre-establish a direct phone line and written standby agreement with each state adjutant general (Army and Air National Guard commanders) before Month 0 (2026-10-14), specifying that out-of-state deployment is pre-authorized under EMAC and requires only a phone request from the UC; test this agreement in a coordination exercise 30 days before T+0.
- If state cost-sharing percentages are not formally documented: Use the standard Stafford Act cost-share (75% federal/25% state) as the assumed baseline and confirm in writing via each governor's representative at T+6h; if disputes arise later, escalate to FEMA regional administrator for arbitration rather than delay the response.
- If state emergency-management contact information is incomplete or outdated: Request updated contact rosters from FEMA Region VIII and Region 10 regional liaisons at T-48h before the eruption window; maintain a shared contact list on the UC common operating picture with backup phone, email and satellite phone for each state director.
- If state traffic-control or hazmat-handling regulations impose constraints that conflict with the UC evacuation plan: Escalate to each governor's legal counsel by T+3h, request a written waiver or emergency order authorizing the necessary contraflow and fuel-handling operations, and proceed under the waiver while the formal legal process continues in parallel.
- If pre-existing state MOUs are found to conflict with the planned UC authority structure: Convene an emergency legal coordination call with all three governors' representatives and the UC legal counsel at T+0 to T+2h, identify the specific conflicts, and issue a joint written clarification signed by the governors confirming that the UC evacuation plan supersedes any prior conflicting arrangements for the duration of the emergency.
- If mutual-aid (EMAC) procedures are non-standard or require pre-authorization that is not in place: Use the EMAC duty officer hotline (available 24/7) to request immediate mutual-aid activation for each state, providing verbal authorization from each governor if needed, and follow up with written confirmation within 4 hours; EMAC procedures are designed for this scenario and should not be a bottleneck.

## Find Document 10: Current and Historical Seismic and Hydrothermal Hazard Maps for Yellowstone Caldera Region (USGS HazMaps, Slope-Stability Assessments)

**ID**: f42ce734-7f7e-479a-b1be-9546a9a1567b

**Description**: Existing USGS hazard maps showing seismic epicenter distributions, slope-stability assessments and hydrothermal-explosion zones within Yellowstone National Park. Includes Gallatin Canyon and US-89 corridor geotechnical surveys (if available) and any documented secondary-slide or hydrothermal-explosion events. Serves as input for Landslide Clearance and Hydrothermal Hazard Road Engineering planning. Intended audience: Geotechnical engineer, transportation planner. Context: the plan assumes Gallatin Canyon and US-89 have secondary-slide risk and the South Entrance has current blockage; this documentation enables specific hazard-zone mapping and equipment pre-positioning.

**Recency Requirement**: Current (2010–2025) USGS hazard maps and geotechnical assessments for the Yellowstone region.

**Responsible Role Type**: Transportation Operations & Contraflow Specialist / Geotechnical Engineer

**Steps to Find**:

- Contact USGS Yellowstone Volcano Observatory and Cascades Volcano Observatory and request existing hazard maps for the Yellowstone region (seismic, slope stability, hydrothermal hazards).
- Download USGS Scientific Investigations Map series (SIM) for Yellowstone region (available on USGS website).
- Contact Wyoming, Montana and Idaho state geological surveys and request slope-stability assessments or landslide-hazard maps for the Gallatin Canyon and US-89 corridors.
- Request any NPS maintenance or incident reports documenting prior rockfalls, landslides or hydrothermal explosions on park roads.

**Access Difficulty**: Easy. USGS hazard maps are publicly available online. State geological surveys maintain geotechnical databases; access may require formal request but is typically available to emergency planners.

**Essential Information**:

- Identify the specific USGS seismic, gas-flux, and uplift-rate thresholds that trigger automatic escalation from Zone Zero to Zone One and from Zone One to the 500 km Scenario Beta radius, with decision latency target (e.g., 'order issued within 30 minutes of threshold crossing').
- Detail the written trigger-matrix protocol: which agency (USGS, Unified Command, governor) measures each indicator, at what frequency (hourly, continuous), and who has authority to halt or reverse the order if a false positive is detected.
- List all pre-authorized decision makers and their roles: NPS incident commander, Unified Command at Denver RRCC, FEMA Region 10 liaison, and state governors; specify the chain of command if the primary decision maker is unreachable.
- Quantify the 'remaining window' reference in the Scenario Beta trigger (e.g., 'probability of VEI-7 within the remaining 48 hours of the 72-hour window'); define how this probability is computed from USGS data in real time.
- Specify the messaging that accompanies the trigger: what public alert (IPAWS, radio, print) is issued to evacuees and outer-ring residents at the moment the order is given, and in what languages.
- Define abort and reversal criteria: under what conditions may the Unified Command pause or cancel the Scenario Beta order if indicators drop below thresholds after the order is issued, and who decides.
- Confirm whether the trigger matrix is finalized and approved by USGS, FEMA, and state governors, or whether it remains a placeholder awaiting technical input by T+3 hours into the event.

**Risks of Poor Quality**:

- Ambiguous or missing thresholds cause 30–90 minute delays in ordering Scenario Beta (estimate), during which uncontrolled shadow evacuation saturates corridors and strands Zone One evacuees.
- Unclear chain of command or lack of pre-authorization allows one agency to dispute or block the order, splitting evacuation messaging and reducing public compliance by 10–20% (estimate).
- Triggers based on single indicators (e.g., tremor magnitude alone) may fire on false alarms unrelated to eruption likelihood, eroding public trust and creating a 'boy who cried wolf' scenario that reduces compliance on subsequent escalations.
- Absence of abort criteria leaves an escalated Scenario Beta order in force indefinitely, keeping millions of people in chaotic evacuation even if USGS downgrades the eruption probability, increasing humanitarian cost and stranding medical response.
- Multilingual messaging not finalized means non-English speakers do not understand the trigger has fired, missing evacuation windows by 1–4 hours (estimate).
- Delay in confirming the trigger matrix means the UC operates on a placeholder during the actual event, risking disagreement with USGS volcanologists over indicator interpretation at the moment the order must be issued.

**Worst Case Scenario**: The Scenario Beta trigger fires (VEI-7 probability crosses a threshold), but the written trigger matrix has not been finalized or pre-authorized. The Unified Command must convene an emergency decision cell to interpret the USGS data and vote on the 500 km order. This process takes 2–4 hours (estimate), during which uncontrolled outer-ring evacuation from Bozeman, Billings and Idaho Falls saturates I-15 and I-90. By the time the order is issued, 50,000–200,000 unplanned evacuees are already on the roads (estimate), gridlock prevents the organized Zone One evacuation of the 35,000 park visitors from reaching the primary shelters by T+24 hours, and secondary rescue of stranded evacuees and medical patients becomes necessary. The absence of second-stage hub destinations compounds the chaos: evacuees fleeing the 500 km ring have no published shelter, driving further uncontrolled dispersal. Final outcome: 4–8 hour evacuation delay, 500–2,000 stranded or injured evacuees, 5–15 preventable deaths in hospital transport delays, and erosion of public trust that undermines future emergency messaging.

**Best Case Scenario**: The trigger matrix is finalized and pre-authorized by T+0 hours, with USGS committed to hourly updates of the nominated indicators (e.g., uplift rate, gas flux, tremor magnitude) transmitted to the Unified Command. A VEI-7 probability crosses the threshold at T+18 hours. The Unified Command confirms receipt of the USGS data within 10 minutes, issues the 500 km order within 30 minutes (proposed threshold), and IPAWS broadcasts the order in English and five languages within 45 minutes. State governors issue immediate downstream enforcement orders, and the ranked second-stage hub list (Denver, Cheyenne, and three backups outside the 500 km ring) is already pre-authorized, allowing the UC to direct outer-ring evacuees to named destinations. Corridor overflow is diverted to secondary routes before gridlock forms, Zone One evacuees reach primary shelters by T+24 hours, and secondary hubs are staffed and receiving outer-ring evacuees by T+36 hours. Public trust remains intact because the messaging was credible and pre-announced. Outcome: all 35,000 Zone One tourists and 100,000–500,000 additional Beta-ring evacuees reach shelter without major casualties or stranding.

**Fallback Alternative Approaches**:

- If USGS cannot finalize a quantitative threshold matrix by T+3 hours into the event, adopt a qualitative decision framework: UC meets a standing volcanologist-and-governor cell every 6 hours (at T+6, T+12, T+18, T+24), reviews the latest USGS narrative assessment and gas/seismic plots, and votes on escalation. This delays the order by up to 6 hours but avoids false triggers; couple it with pre-staged second-stage hub messaging so outer-ring residents know what to do when the order comes.
- Deploy a USGS liaison officer with satellite communication and real-time data-feed equipment to the forward UC element (Livingston) as an alternative to remote indicator transmission; this collocates the volcanologist with the decision maker, reducing latency and interpretation disagreement.
- Pre-authorize a phased Scenario Beta order: Ring 1 (100–250 km, time-banded evacuation, no new cascade) by T+12 h based on interim thresholds; Ring 2 (250–500 km, staged departure, second-stage hubs activated) by T+24 h only if additional VEI-7 probability increases. This reduces false-alarm risk and buys time to stage second-stage hubs.
- If public trust erodes after a false escalation, shift messaging from thresholds to scenarios: 'If USGS detects X, the UC will activate pre-authorized evacuation Plan A for Ring 2; residents will have 4 hours' notice.' This frames the order as a pre-planned contingency, not a surprise, and reduces blame on the UC.

## Find Document 11: Regional Ground Transportation Network Capacity Data (I-15, I-80, I-90, US-20, US-89, US-14/16/20 Lane Counts, Capacity Analysis)

**ID**: 20ac35b9-2dc9-4dbb-871c-eeac47d3a083

**Description**: Detailed highway-capacity data for the primary evacuation routes: Interstate 15 northbound from Salt Lake City to Idaho Falls, Interstate 90 from West Yellowstone/Bozeman to the Livingston area, US-89 from Gardiner to Livingston and I-90, and US-14/16/20 from Cody to Billings and I-90. Includes lane counts, current average daily traffic (ADT), estimated maximum capacity (vehicles per hour per lane), known bottleneck locations (e.g., Gallatin Canyon, mountain passes) and any current or planned construction. Serves as input for contraflow design, throughput validation and evacuation-time estimation. Intended audience: Contraflow Operations Manager, transportation planner. Context: the plan assumes 2,000 vehicles/hour total outbound (660 per exit average), but this must be validated against actual corridor capacity, especially if roads degrade under ashfall or evacuation traffic congestion.

**Recency Requirement**: Current (2024–2025) highway data: lane counts, construction status, average daily traffic; historical capacity studies from the last 5 years.

**Responsible Role Type**: Transportation Operations & Contraflow Specialist

**Steps to Find**:

- Contact state DOT traffic-data offices: Montana DOT (Helena), Wyoming DOT (Cheyenne), Idaho DOT (Boise) and request current ADT data, lane counts and capacity-analysis reports for I-15, I-80, I-90, US-20, US-89 and US-14/16/20.
- Download highway-capacity manual (HCM) level-of-service analysis from the Transportation Research Board or academic sources; apply to Yellowstone corridor routes to estimate actual evacuation throughput.
- Request any existing evacuation-routing studies or traffic-modeling reports from state DOT or FHWA for the Yellowstone region.
- Contact FHWA regional offices and request any regional traffic-capacity data or bottleneck assessments for mountain corridors.

**Access Difficulty**: Easy. State DOT traffic data is publicly available; historical ADT and capacity analyses can be requested from state DOT planning divisions.

**Essential Information**:

- Detailed current lane counts, average daily traffic (ADT) and maximum capacity (vehicles/hour/lane) for I-15 northbound (Salt Lake City to Idaho Falls), I-90 (West Yellowstone/Bozeman to Livingston), US-89 (Gardiner to Livingstone and I-90), and US-14/16/20 (Cody to Billings and I-90).
- Identification and location of all known bottlenecks: Gallatin Canyon on US-191, Gardiner canyon on US-89, mountain passes on US-14/16/20, and any other choke points with single-lane or reduced-capacity sections.
- Current construction status, lane closures, or planned maintenance on all three corridors through Month 1 (2026-11-14).
- Highway-capacity manual (HCM) level-of-service analysis for each corridor at the estimated 2,000 vehicles/hour outbound load (660 vehicles/hour per exit at three-way split) and validated time-to-clearance for the 11,900-vehicle total outbound demand at 3.0 persons/vehicle.
- Ashfall-degradation impact estimates: how reduced visibility, ash-slicked surfaces, and ash accumulation on shoulders will reduce safe capacity and increase accident rates on each corridor.
- Historical data on how mountain passes (Gallatin Canyon, Gardiner canyon) have responded to blockages, secondary slides or debris clearance in past events; typical clearance time and equipment requirements.

**Risks of Poor Quality**:

- Corridor capacity overestimated: if actual capacity is 1,500 vehicles/hour instead of 2,000 vehicles/hour, evacuation time extends from 6 hours to 8+ hours, increasing ashfall exposure by 30–50% and stranding 2,000–4,000 vehicles in ash.
- Bottleneck risk unquantified: if Gallatin Canyon or Gardiner canyon cannot handle the planned load even without blockage, a single-lane cascade under evacuation traffic is certain, not hypothetical.
- Ashfall-degraded capacity not modeled: if ashfall reduces safe capacity by 30–50% (no data available) and the plan assumes full capacity, peak evacuation will fail to clear Zone Zero by T+6 hours.
- Clearance timelines not validated: if debris clearance actually requires 6–8 hours instead of the proposed 45-minute diversion threshold, a loss-of-exit event will strand 5,000–10,000 vehicles mid-corridor.
- Routing decisions made without baseline data: the plan's proposed West 50%, North 30%, East 20% gate-load split has no capacity basis and may exceed one corridor's maximum throughput, forcing traffic onto uncongested lanes.

**Worst Case Scenario**: Actual corridor capacity is 1,500 vehicles/hour (not validated), and ashfall reduces it by 40% to 900 vehicles/hour. The plan's 11,900-vehicle total load at 2,000 vehicles/hour takes 6 hours under ideal conditions; under realistic ashfall-degraded capacity, it requires 13+ hours. Evacuation extends from the planned T+6 hours to T+13+ hours, with peak outbound traffic occurring at T+6 to T+13, exactly when ashfall intensity is rising. Simultaneous failure of one corridor (blockage in Gallatin Canyon) reduces throughput to 1,200 vehicles/hour across two exits, extending evacuation to 10+ hours and stranding 3,000–5,000 vehicles in moderate to heavy ashfall. Result: 500–1,500 additional respiratory-distress incidents and 10–30 preventable deaths.

**Best Case Scenario**: Detailed capacity data confirms that all three corridors can sustain 2,000+ vehicles/hour even under ashfall-degraded conditions, and that Gallatin Canyon and Gardiner canyon have sufficient width for rapid debris clearance (15–30 minutes typical). The planned three-way gate split (West 50%, North 30%, East 20%) aligns with each corridor's actual capacity, ensuring balanced load distribution. Evacuation proceeds on schedule, Zone Zero is cleared by T+6 hours with fewer than 500 stranded or delayed evacuees, and the three-exit design proves to be the decisive factor in achieving the T+6 clearance deadline. Credible capacity data also enables the forward command to adjust the gate-load split in real time if one corridor experiences congestion, preventing a bottleneck cascade.

**Fallback Alternative Approaches**:

- If detailed current capacity data cannot be obtained from state DOTs within T+0 to T+6 hours, request historical evacuation or emergency-response traffic studies from FHWA or academic researchers covering mountain corridors in the western US, and apply those data as proxies for Yellowstone corridors, with a 20% conservative downward adjustment for ashfall.
- Conduct a rapid (3–5 day) traffic-simulation study using VISSIM or similar software at Month 0 (2026-10-14) based on available ADT data, assuming ashfall reduces visibility to 100 meters and safe speed to 25 mph; iterate the gate-load split until simulated evacuation time reaches T+6 hours or the model identifies the first bottleneck.
- Activate a dynamic gate-adjustment protocol: measure queue length and exit throughput every 15 minutes from T+0 onward; if one corridor's queue exceeds 500 vehicles or throughput drops below 600 vehicles/hour for >15 minutes, reroute overflow to the least-congested exit within 10 minutes.
- Request real-time capacity monitoring from state DOTs: ask Montana DOT, Wyoming DOT and Idaho DOT to provide live traffic-speed data from Gallatin Canyon and Gardiner canyon (via road sensors or traffic cameras) during the evacuation window, so the forward command can detect bottlenecks and blockages within 5 minutes and trigger immediate reroutes.

## Find Document 12: Residential and Transient Population Data for Secondary-Hub Communities (Denver, Cheyenne, Billings, Boise, Salt Lake City, Rapid City)

**ID**: e9feecf9-33d2-46e8-b74c-33e98fb07815

**Description**: Current residential population, hotel/lodging capacity, campground capacity and available emergency-shelter facility inventory for candidate Scenario Beta secondary-hub communities outside the 500 km ring (Denver, Cheyenne, Billings, Boise, Salt Lake City, Rapid City). Includes gym/arena availability, school facility capacity and organizational capacity (Red Cross, Salvation Army) to operate shelters. Serves as input for Scenario Beta secondary-stage hub selection and signed capacity MOUs. Intended audience: Scenario Beta Destination Planner, shelter planners. Context: the plan names Denver and Cheyenne as candidate hubs but has not verified distance or capacity; this data enables validation and ranking of backup hubs.

**Recency Requirement**: Current (2024–2025) facility inventories, hotel/RV-park capacity and community emergency-management resource listings.

**Responsible Role Type**: Scenario Beta Secondary-Stage Destination Planner

**Steps to Find**:

- Contact city and county emergency management agencies in Denver, Cheyenne, Billings, Boise, Salt Lake City and Rapid City; request current shelter-facility inventories (gymnasiums, arenas, schools, community centers with capacity for 1,000+ people).
- Request hotel, RV park and lodging-facility capacity data from local chambers of commerce or convention and visitors bureaus.
- Contact Red Cross and Salvation Army regional chapters and request emergency-sheltering capacity and pre-event coordination contacts.
- Verify distance from Yellowstone Caldera center to each hub: confirm that hubs lie outside the 500 km ring (not affected by modeled ashfall or Scenario Beta evacuation zone).

**Access Difficulty**: Easy. City emergency management agencies maintain public shelter-facility rosters; chamber-of-commerce lodging data is publicly available.

**Essential Information**:

- Identify the current residential population, hotel/RV lodging capacity, and emergency-shelter facility inventory (gymnasiums, arenas, schools, community centers) for at least five candidate secondary-hub communities outside the 500 km Scenario Beta evacuation ring.
- Confirm distance from Yellowstone Caldera center to each candidate hub; verify that proposed hubs (Denver, Cheyenne, Billings, Boise, Salt Lake City, Rapid City) lie outside the 500 km ring and are not affected by modeled ashfall or the Scenario Beta evacuation zone.
- Quantify total available emergency-shelter capacity per hub (facilities with capacity for 1,000+ people) and estimate how many evacuees each hub can accommodate for 7–14 days.
- List Red Cross and Salvation Army regional chapters and emergency-sheltering capacity in each hub; identify pre-event coordination contacts and capacity-commitment timelines.
- Rank the candidate hubs by distance from Yellowstone, shelter capacity per capita, accessibility via lateral routes (avoiding saturated I-90 and I-15), and community emergency-management readiness.
- For each hub, detail the operational constraints: does the hub have adequate water treatment, fuel supply, medical facilities (hospital beds, clinics), and ground-transportation capacity (buses, staging areas) to receive and process 10,000–50,000 evacuees within 12–24 hours?

**Risks of Poor Quality**:

- If candidate hubs are inside the 500 km ring or in modeled ashfall zones, Scenario Beta evacuees arriving at those hubs would face unforecast ash exposure, respiratory distress and secondary relocation within 6–12 hours, stranding 10,000–30,000 people and consuming 4–6 additional hours of transport and intake time.
- If hub shelter capacity is overstated (e.g., listed facilities are unavailable, outdated or inaccessible), the plan cannot absorb the estimated 100,000–500,000 additional Scenario Beta evacuees, forcing uncontrolled camping and overflow into unsafe conditions, increasing respiratory and disease-related casualties by an estimated 20–50 per hub.
- If Red Cross and Salvation Army coordination is not pre-established, shelters lack trained staff, and intake processing delays by 4–8 hours, evacuees queue at hubs without registration, food or water distribution, increasing dehydration and medical emergencies by 30–50% during the intake window.
- If hubs lack adequate fuel supply contracts, water treatment and medical-facility bed capacity, the plan's assumptions that evacuees can be moved 'onward' from initial hubs to secondary destinations becomes infeasible, trapping evacuees at overloaded initial sites for 24–48 hours longer than planned.
- If hub accessibility via lateral routes is poor (e.g., narrow secondary highways, limited fuel stops), transport convoys moving evacuees from primary shelters to secondary hubs face delays of 4–8 hours, reducing throughput and leaving primary shelters saturated beyond design occupancy.

**Worst Case Scenario**: Scenario Beta trigger fires at T+12 hours. The plan has no verified secondary-hub list: candidate hubs (Denver, Cheyenne, Billings) have not been confirmed as outside the 500 km ring or evaluated for capacity and accessibility. Over the next 12–24 hours, 50,000–200,000 unplanned evacuees from the 100–500 km ring converge on the nearest major towns (Billings, Bozeman, Idaho Falls, Salt Lake City), all of which are inside the Scenario Beta zone or have been overtaxed by primary-stage evacuees. No pre-arranged hub coordination or capacity commitment exists. Evacuees cluster in parking lots, schools and fairgrounds without registration, food service or medical triage. Regional hospitals face a secondary surge of 1,000–3,000 patients with respiratory distress and heat-stress casualties. Without onward-movement routes and host-hub agreements, primary shelters cannot release evacuees to secondary hubs, leaving tens of thousands stranded in ash-exposed zones for 24–48 hours. Estimated casualties: 50–200 preventable respiratory and heat-stress deaths; estimated cost of emergency response: USD 200–500 million in unplanned shelter operations, medical response and evacuation rerouting.

**Best Case Scenario**: The Residential and Transient Population Data document provides verified current (2024–2025) shelter-facility inventories, lodging capacity and organizational capacity for at least five candidate secondary hubs (Denver, Cheyenne, Billings, Boise, Salt Lake City). Each hub is confirmed outside the 500 km ring with measured distance from Yellowstone. Red Cross and Salvation Army chapters are contacted; pre-event capacity commitments are signed by Month 2 (2026-12-14). A ranking of hubs by distance, capacity and accessibility is published, enabling the Scenario Beta Secondary-Stage Destination Planner to assign evacuation rings (100–250 km, 250–500 km) to specific hubs and pre-position buses and logistical staff. When a Scenario Beta trigger fires, evacuees are directed to named hubs with published shelter addresses, expected arrival times and intake processes. Onward-movement routes via lateral highways are confirmed passable and fuel-stocked. Secondary hubs absorb 100,000–500,000 evacuees over 24–48 hours with minimal additional casualties. Evacuee confidence in the plan increases, reducing shadow evacuation and corridor saturation. Estimated outcome: <10 preventable deaths in secondary-hub operations, USD 50–100 million in planned sheltering costs, and reduced emergency contingency draws.

**Fallback Alternative Approaches**:

- Contact all state emergency management agencies in Montana, Wyoming, Idaho, Colorado and Utah directly; request that each state identify its top three candidate secondary-hub communities and verify their distance from Yellowstone and existing emergency-shelter inventories, then consolidate the state lists into a unified ranked document by T+0 hours.
- Engage FEMA Regions VIII and X directly to request their existing American Evacuation Preparedness community-shelter databases and regional resource lists; cross-reference those inventories against the candidate hubs to avoid redundant surveying.
- If facility inventories are incomplete or outdated, conduct rapid phone surveys of city emergency management offices, chambers of commerce and Red Cross chapters in the 3–5 most likely candidate hubs (Billings, Boise, Salt Lake City, Denver, Cheyenne), collecting current-year capacity estimates for gymnasiums, schools and arenas, then publish an interim ranked list by T+12 hours and full details by Month 1 (2026-11-14).
- If distance verification from Yellowstone Caldera center is uncertain, use USGS geospatial tools and NOAA ashfall-dispersion models to confirm which candidate hubs lie outside the 500 km ring for a representative VEI-7 wind scenario; publish confidence intervals on ashfall risk for each hub.
- If Red Cross and Salvation Army regional capacity is unavailable, substitute state and local Salvation Army area commanders, county emergency managers and volunteer fire departments as coordination contacts; request mutual-aid letters of intent from each community by Month 1 (2026-11-14), specifying maximum evacuee intake and available facilities.
- If hub fuel supply or water-treatment capacity is unknown, request pre-event supply audits from the city water authority, municipal utilities and local fuel vendors in each hub, then pre-authorize emergency procurement and delivery contracts with those vendors for the event window, executed by Month 2 (2026-12-14).

## Find Document 13: Utility System Infrastructure and Power-Grid Topology for Montana, Wyoming and Idaho (Transmission Lines, Substations, Ash-Flashover Risk Assessment)

**ID**: 3c23d3db-0621-4b02-9e8f-0775fc3c6de5

**Description**: Electrical transmission-system maps and substation locations for Montana-Dakota Utilities, Pacific Power and Idaho Power service territories covering the Yellowstone region and evacuation routes. Includes transmission-line voltages (115–500 kV), substation locations, backup-generator capacity at critical facilities and any existing ash-flashover or secondary-failure risk assessments. Serves as input for grid-resilience planning and load-shedding procedures. Intended audience: Grid Resilience Engineer, utilities coordinators. Context: the plan assumes grid failure from ash flashovers; this data enables specific vulnerability identification and pre-event protective-relay coordination.

**Recency Requirement**: Current (2024–2025) transmission-system maps, substation listings and protective-relay settings.

**Responsible Role Type**: Critical Infrastructure & Grid Resilience Engineer

**Steps to Find**:

- Contact Montana-Dakota Utilities, Pacific Power and Idaho Power operations/planning divisions and request transmission-system maps, substation locations and load-serving areas.
- Request any existing volcanic-ash risk assessments or secondary-failure analyses from the utilities.
- Contact WECC (Western Electricity Coordinating Council) and request grid-resilience data or interconnection studies relevant to the Yellowstone region.
- Request protective-relay coordination diagrams and settings from each utility for substations serving the Yellowstone evacuation region.

**Access Difficulty**: Medium. Transmission-system maps are commercially sensitive; require formal data-sharing agreements with utilities. Critical-infrastructure protection considerations may limit public disclosure; pre-event coordination with utilities is standard for emergency planning.

**Essential Information**:

- Identify the three receiving hospitals (Bozeman Deaconess Medical Center, Livingston HealthCare, Eastern Idaho Regional Medical Center) and their current generator fuel capacity, on-site reserves (hours/days) and fuel-port configuration, including number of fueling stations per facility.
- Quantify the transmission-line voltages, substation locations and load-serving capacity for Montana-Dakota Utilities, Pacific Power and Idaho Power in the evacuation-corridor and shelter zones (West Yellowstone, Gardiner, Bozeman, Idaho Falls).
- Detail the existing ash-flashover risk assessments or secondary-failure analyses (if any) conducted by regional utilities; identify any transmission lines or substations with single-point-failure exposure in the Yellowstone region.
- Specify the protective-relay settings and automatic load-shedding procedures at the two largest substations serving Bozeman and Idaho Falls, including switching timelines and coordination gaps between utilities.
- Confirm the current status of backup power capacity (mobile generators, voltage regulators, fuel caches) at critical facilities in the shelter zones and estimate pre-event deployment timelines.
- List the FAA ZLC and ZSE airfield locations with current fuel capacity and helicopter-fuel-cache availability for emergency medevac or supply missions.
- Document mutual-aid agreements and resource-sharing arrangements between Montana-Dakota Utilities, Pacific Power and Idaho Power regarding emergency fuel delivery, load shedding and grid restoration.
- Specify WECC (Western Electricity Coordinating Council) grid-resilience data relevant to the Yellowstone region, including any modeled cascading-failure scenarios or recommendations for protective-relay coordination.

**Risks of Poor Quality**:

- Incomplete transmission-system maps or substation data delay identification of critical vulnerabilities, leaving protective-relay coordination unverified and increasing the risk of cascading multi-hospital power loss during ashfall.
- Absence of ash-flashover risk assessments means utilities have no pre-event load-shedding strategy and cannot stage protective actions (relay adjustments, line de-energization) before failure occurs, resulting in uncontrolled blackouts.
- Lack of clarity on hospital generator fuel capacity and fueling-port configuration prevents realistic assessment of 4–6 hour outage duration and the need for emergency fuel delivery; overestimating on-site reserves leads to inadequate fuel pre-positioning.
- Missing utility mutual-aid and emergency-response procedures mean fuel convoys and load-shedding orders cannot be coordinated across utility boundaries, leaving some facilities without power during peak demand.
- Incomplete airfield fuel-cache data prevents pre-positioning of helicopter fuel for emergency medevac or supply runs, stranding critical patient transfers and shelter resupply if ground routes fail.
- Failure to coordinate protective relays and control systems across utilities increases the likelihood of malfunction under ashfall stress, accelerating cascading failure timelines.

**Worst Case Scenario**: A widespread transmission-line flashover event triggered by ashfall ash deposits on insulators occurs within 4 hours of ashfall onset, affecting multiple substations serving Bozeman and Idaho Falls simultaneously. Protective relays malfunction or fail to isolate faulted sections due to ash-clogging or secondary tremor damage, initiating a cascade of failures that blacks out the entire region within 8–12 hours. Hospitals lose grid power before fuel convoys can arrive; generator startup procedures fail due to outdated equipment or maintenance oversights. Three major hospitals operate for 2–4 hours on backup before fuel runs out, forcing cancellation of 15–25 surgeries, loss of ventilator support for 10–15 patients and 5–10 preventable deaths. Shelters lose water pumping and treatment capability, affecting 35,000+ evacuees. The incident commander lacks real-time visibility into grid status and cannot issue load-shedding orders, leaving repair crews without situational awareness. Total impact: regional crisis compounding medical surge and threatening regional continuity of operations.

**Best Case Scenario**: Utilities provide current transmission-system maps and confirm substation locations, protective-relay settings and mutual-aid procedures. Pre-event coordination identifies two critical substations serving the shelter zones and confirms mobile generator and voltage-regulation equipment can be pre-deployed 48 hours before the eruption window. Each receiving hospital confirms 72-hour on-site fuel reserves and agrees to emergency fuel contracts with local vendors (arrival within 2 hours of request). A 24/7 utility-operations hotline is established with the forward command element, enabling real-time grid monitoring and load-shedding authorization during ashfall. Hospital generator-startup exercises test manual procedures and identify any mechanical failures in advance. Ashfall does cause transmission-line stress, but pre-positioned mobile generators and load shedding prevent cascading failure; hospitals maintain power and medical surge capacity throughout the 72-hour window. Shelf-life and resupply of fuel, water and medical supplies remain uninterrupted. Regional infrastructure resilience is maintained and no preventable deaths occur due to grid failure.

**Fallback Alternative Approaches**:

- If current utility transmission maps are not available due to critical-infrastructure security restrictions, request a summarized vulnerability briefing (substations at highest risk, relay-coordination gaps, single-point failures) from the responsible utility operators rather than full technical documents, then coordinate directly with operations staff during the 72-hour window for real-time load-shedding decisions.
- If pre-event ash-flashover risk assessments do not exist, commission a rapid ( 30-day) desktop analysis using USGS ash-dispersion models and published literature on volcanic-ash electrical effects, focusing on the two largest substations serving Bozeman and Idaho Falls; use results to justify emergency mobile-generator pre-positioning.
- If hospital fuel reserves are insufficient (less than 48 hours on-site), establish a fuel-delivery contract with local vendors and pre-stage bottled fuel at each hospital 60 days before the window, then assign a fuel-shortage responder to monitor consumption during the event and trigger emergency dispatch if reserves fall below 24 hours.
- If utility mutual-aid agreements do not address ash-driven emergencies, draft a simple one-page emergency protocol with the utilities specifying load-shedding triggers (ashfall onset + grid stress indicators), command authority (forward command element voice request triggers action without committee approval) and fuel-convoy priority lanes during evacuation.
- If airfield fuel caches are not available, pre-authorize helicopter fuel delivery from military sources (Fort Harrison, Helena or Malmstrom AFB, Montana) or civilian aviation fuel suppliers in Billings and pre-position fuel at the nearest forward airfield (Gallatin County or Jackson Hole) 48 hours before the window, then brief medevac units on the fuel location and authorization procedures.