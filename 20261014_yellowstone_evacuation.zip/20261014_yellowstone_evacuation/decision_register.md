**5 open decisions: 3 high and 2 medium severity.** Urgent before or at T+0: who may order Zone One and Beta during T+0-T+6 h, what the UC does if Beta fires before hubs are signed, and the hub capacity floor, due by T+12 h. The plan can safely run the Zone Zero evacuation, contraflow, communications and aviation grounding meanwhile. Financing and Zone One shelter demand can wait until Month 1 (2026-11-14) and T+6 h respectively.

| # | Decision | Severity | Owner | Decide by | Blocks |
|---|---|---|---|---|---|
| 1 | Scenario Beta before MOUs are signed | 🔴 High | Unified Command Strategic Oversight Board with FEMA Region VIII, on the governors' advice | Month 0 (2026-10-14), before T+3 h: the trigger can fire inside the 72 h window and the matrix is published at T+3 h. | Scenario Beta order; T+12 h interim hub list; Month 2 (2026-12-14) no-go gate. |
| 2 | Who may order Zone One or Beta during T+0 to T+6 h | 🔴 High | Unified Command with the MT, WY and ID governors | Month 0 (2026-10-14), before T+0: needed during the peak evacuation. | Zone One expansion start (T+6 h); Scenario Beta orders; Gate G1. |
| 3 | Hub capacity floor and qualifying hubs | 🔴 High | FEMA Region VIII Regional Administrator with the UC | Month 0 (2026-10-14), before T+12 h interim hub list. | T+12 h interim hub list; Month 1 (2026-11-14) written plan; Month 2 (2026-12-14) MOUs. |
| 4 | Financing of shelters, hubs and state costs | 🟡 Medium | FEMA Region VIII finance lead with the governors | Month 1 (2026-11-14): the signed-MOU milestone. | Governor MOUs and EMAC (Month 1 = 2026-11-14); host MOUs (Month 2 = 2026-12-14); Beta pre-positioning. |
| 5 | Zone One shelter demand | 🟡 Medium | Unified Command, Shelter Siting & Air-Quality Assurance Panel | Month 0 (2026-10-14), T+6 h: shelter sites are chosen then. | Gate G2 at T+24 h; shelter siting at T+6 h. |

## 1. Scenario Beta before MOUs are signed (🔴 High)

**Decision:** If the Beta trigger fires inside the 72 h window before hubs and MOUs exist, does the UC issue the 500 km order in rings on the interim list, or hold in a staged decision cell?

**Why it is open:** Executive Summary, Review 2.1 and Pitch call Beta pre-authorized and executable; the hub list is due T+12 h, MOUs Month 2 (2026-12-14), exercise Month 3 (2027-01-14). No document says what happens before then.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Issue the 500 km order in rings on the interim list only (0-100 km first, outer rings later). | Keeps the 30-minute order time; outer rings depend on unverified hubs and may lack capacity. | scenario_beta_trigger, scenario_beta_execution_rings; relabel Month 2 (2026-12-14) gate as hardening. |
| B. Hold in a staged decision cell until hubs are verified. | Loses the 30-minute order time and risks uncontrolled shadow evacuation; safer on destination capacity. | scenario_beta_trigger, governance matrix, Executive Summary, Pitch. |
| C. Order only 0-100 km immediately; release outer rings once at least 5 hubs are confirmed. | Hybrid; delays the outer rings by hours. | scenario_beta_execution_rings, scenario_beta_plan_milestones. |

- **If nobody decides:** The plan keeps the 'pre-authorized' claim with no valid basis; the UC improvises when the trigger fires.
- **Owner:** Unified Command Strategic Oversight Board with FEMA Region VIII, on the governors' advice
- **Decide by:** Month 0 (2026-10-14), before T+3 h: the trigger can fire inside the 72 h window and the matrix is published at T+3 h.
- **Blocks:** Scenario Beta order; T+12 h interim hub list; Month 2 (2026-12-14) no-go gate.

## 2. Who may order Zone One or Beta during T+0 to T+6 h (🔴 High)

**Decision:** Who has authority to order Zone One expansion or Beta before verbal governor authorization is obtained at T+6 h?

**Why it is open:** The pitch and reviews say pre-authorized; canonical governor_authorization is only verbal by T+6 h and USGS values exist only at T+3 h.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Each governor issues orders individually until T+6 h. | State authority is clear but orders are not synchronized; 30-minute order time is lost. | governor_authorization, Pitch, Review 2, Review 3.2. |
| B. The UC orders under federal authority from T+0. | Fast and unified; legal basis and governor consent must be confirmed. | governor_authorization, command_structure, authority_handoff_point. |
| C. Obtain governor pre-authorization before T+0 by standing agreement. | Not achievable given the rebased lead times; would need an earlier project phase. | pre_event_lead_times_rebased. |

- **If nobody decides:** No one holds clear authority T+0 to T+6 h; Zone One start waits on calls, risking delay at the G1 peak.
- **Owner:** Unified Command with the MT, WY and ID governors
- **Decide by:** Month 0 (2026-10-14), before T+0: needed during the peak evacuation.
- **Blocks:** Zone One expansion start (T+6 h); Scenario Beta orders; Gate G1.

## 3. Hub capacity floor and qualifying hubs (🔴 High)

**Decision:** What single capacity floor and which hubs outside the 500 km ring will be used for Beta?

**Why it is open:** A1 uses 50,000 beds; FM2 and Self-Audit use 250,000; the ring holds millions. Only Denver and Cheyenne qualify; Review 12.3 uses Utah/Idaho, which are inside the ring.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Floor 250,000 beds across at least 5 verified hubs outside 500 km. | More defensible; needs 3+ more named hubs after a distance check; still below the ring population. | Premortem A1/FM2, Self-Audit 11, Review 12.3, scenario_beta_second_stage_hubs. |
| B. Keep 50,000 beds as the minimum. | Easier to meet at T+12 h; far under-sized for the ring. | Premortem FM2, Self-Audit. |
| C. Size the floor to a stated share of the ring population once estimated. | Most rigorous; needs a population figure (not quantified); delays the number. | scenario_beta_population, hub thresholds. |

- **If nobody decides:** Conflicting thresholds persist; the T+12 h list of 5 hubs may fail by design.
- **Owner:** FEMA Region VIII Regional Administrator with the UC
- **Decide by:** Month 0 (2026-10-14), before T+12 h interim hub list.
- **Blocks:** T+12 h interim hub list; Month 1 (2026-11-14) written plan; Month 2 (2026-12-14) MOUs.

## 4. Financing of shelters, hubs and state costs (🟡 Medium)

**Decision:** What is the federal vs state/local/host split for shelter sites, secondary hubs and state costs, and what counts against the USD 200 million envelope?

**Why it is open:** Canonical says OPEN. Reviews 11/Self-Audit 6 date it Month 0 (2026-10-14) and T+12 h, others Month 1 or 2 (2026-11-14, 2026-12-14); Self-Audit 18 shows a 10-20% state match as if settled.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Federal funds 100% of pre-positioning. | Fast MOU signing; raises federal draw within the USD 160 million base. | financing_open_decision, readiness_package_cost, FM7. |
| B. Federal plus state match (e.g. 10-20%). | Lowers federal cost; slows MOUs and risks the FM7 tripwire (fewer than 3 states by Month 1 = 2026-11-14). | financing_open_decision, Self-Audit 18, governor MOUs. |
| C. Host-community in-kind contribution. | Least federal cost; hubs may decline, reducing capacity. | financing_open_decision, hub MOUs. |

- **If nobody decides:** MOUs stall; Beta pre-positioning (USD 20-40 million) scaled back; FM7 stop rule triggers.
- **Owner:** FEMA Region VIII finance lead with the governors
- **Decide by:** Month 1 (2026-11-14): the signed-MOU milestone.
- **Blocks:** Governor MOUs and EMAC (Month 1 = 2026-11-14); host MOUs (Month 2 = 2026-12-14); Beta pre-positioning.

## 5. Zone One shelter demand (🟡 Medium)

**Decision:** Are Zone One residents inside the 35,800 shelter capacity or additional, and what overflow or self-supply approach applies?

**Why it is open:** Shelters and water are sized for Zone Zero only; Gate G2 needs 95% of Zone One out, and the base is not quantified (census due T+6 h).

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Count Zone One within 35,800 using a county/lodging proxy at T+0-T+3 h. | No added capacity; likely overrun. | shelter_capacity_plan, zone_one_resident_population. |
| B. Add overflow capacity beyond 35,800. | Raises cost and water/N95 needs; the site list needs a larger ranking. | shelter_capacity_plan, water_supply_target, budget. |
| C. Outer-zone self-supply message with limited shelter. | Lower cost; relies on residents' own means. | communications_stack, phase2_go_gate. |

- **If nobody decides:** Zone One residents have no planned shelter; G2 cannot be assessed.
- **Owner:** Unified Command, Shelter Siting & Air-Quality Assurance Panel
- **Decide by:** Month 0 (2026-10-14), T+6 h: shelter sites are chosen then.
- **Blocks:** Gate G2 at T+24 h; shelter siting at T+6 h.

## Choices made on your behalf

Set when the scenario was selected, not by you. Confirm or change them.

| Lever | Chosen | Strongest alternative | Why it matters | Revisit by |
|---|---|---|---|---|
| Egress corridor allocation | Three gates (West, North, East toward Cody) with fixed district-to-gate assignment. | Two corridors to I-90 (Consolidator) or bus-based loading (Pioneer). | Sets throughput and the G1 load split of 50/30/20. | Gate G1 (T+6 h) |
| Escalation trigger doctrine | Written USGS trigger matrix, UC issues the 500 km order without further approval. | Standing volcanologist-and-governor decision cell. | Speed against authority and hub readiness. | T+3 h matrix publication; Month 2 (2026-12-14) |
| Command structure | Denver RRCC with forward UC element at Livingston (alt. Bozeman). | Single UC with rotating state deputies. | Determines handoff clarity across Region 8/10. | Month 1 (2026-11-14) MOUs |
| Communications stack | IPAWS/WEA/NOAA radio primary, Guard signal bridging. | Printed route cards and battery radios. | Tower failure would cut the primary public channel. | Gate G1 |
| Shelter siting | Final sites at T+6 h from plume forecast, ranked backups. | Fixed pre-stocked reception centers. | Flexibility against supply readiness and water arrival. | T+6 h |
