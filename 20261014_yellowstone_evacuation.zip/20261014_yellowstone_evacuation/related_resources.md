## Suggestion 1 - Hurricane Rita Evacuation, Houston-Galveston (2005)

One of the largest US evacuations: an estimated 2-3 million people left the Houston area ahead of Hurricane Rita in September 2005 (approximate, not verified). Texas used contraflow on I-45, US-290 and I-10 after severe gridlock and fuel shortages. The event produced widely cited lessons on contraflow staging, fuel and shadow evacuation.

### Success Metrics

Contraflow implemented on several freeways; reported throughput gains after activation (figures approximate)
Post-event reforms: Texas contraflow plans, evacuation zone and phased departure rules
Documented deaths during evacuation (heat, bus fire) used as lessons

### Risks and Challenges Faced

Shadow evacuation overloaded roads: later plans used zone-based, time-phased departures
Fuel shortages along routes: fuel supply pre-arrangements and stations on evacuation routes
Slow contraflow activation: termination points and staffing were pre-planned afterward
Special-needs evacuees: dedicated transport and registry created

### Where to Find More Information

Texas Department of Transportation evacuation and contraflow guidance (txdot.gov)
Texas A&M Transportation Institute post-Rita evacuation studies
FHWA Contraflow Operations / Evacuation Planning guidance (ops.fhwa.dot.gov)
Texas Governor's Task Force on Evacuation, Transportation and Logistics report (2006)

### Actionable Steps

Contact TxDOT Traffic Operations Division for contraflow plan owners
Approach Texas A&M Transportation Institute researchers on evacuation modelling
Request FHWA Office of Operations emergency transportation operations staff for guidance
Consult Texas Division of Emergency Management for zone-based phasing lessons

### Rationale for Suggestion

Closest US example of contraflow on major corridors, shadow evacuation saturating roads, fuel shortages and the need for pre-planned termini. These map directly to Gallatin Canyon/US-89 contraflow and the Scenario Beta ring design. Geographically distant and flat-terrain; mountain two-lane constraints must be added.
## Suggestion 2 - Camp Fire Evacuation of Paradise, California (2018)

The November 2018 Camp Fire forced a rapid evacuation of Paradise (about 26,000 residents, approximate) via a handful of mountain roads. Contraflow on Skyway and other roads was improvised, roads gridlocked and fire overran some vehicles. Post-event reviews by NIST, Butte County and Cal OES examined alerting, routes and command.

### Success Metrics

Most residents escaped despite gridlock; 85 fatalities (approximate, not verified)
Post-event: Butte County adopted Genasys zone-based evacuation and alert reforms
Findings: alert reach gaps, roadway blockages, contraflow timing

### Risks and Challenges Faced

Alerting gaps (WEA/Code Red limited): later layered alerts and zone codes
Improvised contraflow delayed: pre-planned contraflow and staffed control points recommended
Power and cell failure: redundant comms and sirens
Road blockage by abandoned vehicles: tow/clearance pre-positioning

### Where to Find More Information

NIST Technical Note 2252 on Camp Fire (nist.gov)
California Attorney General Camp Fire after-action review
Butte County Sheriff / OES after-action reports
Cal Fire and CHP evacuation reports

### Actionable Steps

Contact Butte County Office of Emergency Management for after-action authors
Approach NIST Fire Research Division staff for the Camp Fire study team
Request CHP Office of Emergency Services briefing on contraflow and tow staging
Reach Cal OES alerting unit for WEA/IPAWS lessons

### Rationale for Suggestion

Western US mountain community with few exit roads and a hazard faster than the plan; reveals how alert failures, blocked chokepoints and improvised contraflow behave. Directly informs Gardiner/West Yellowstone/Gallatin Canyon risks, tow-team staging and alerting under failing cell networks.
## Suggestion 3 - Mount St. Helens 1980 Eruption Response and USGS Cascades Volcano Observatory Hazard Planning

The May 18, 1980 eruption produced widespread ashfall across Washington, Idaho and Montana, closing roads, airports and water systems for days, with about 57 deaths (approximate). Spokane, Yakima and Montana towns coped with ash cleanup, respirator distribution and water issues. The USGS Cascades Volcano Observatory and Washington Emergency Management have since built ash and lahar hazard plans.

### Success Metrics

Ash fell over several states; airports and roads closed for days, reopened after cleanup
Public respirator distribution and cleanup logistics documented
Informed ash-fall hazard maps and ash impact guidance

### Risks and Challenges Faced

Ash-clogged vehicles and roads: closure and cleanup guidance developed
Water and sewer treatment overload: operational advice for utilities
Respiratory protection scarcity: later pre-stocking guidance
Prolonged cleanup disposal: designated disposal sites

### Where to Find More Information

USGS Volcano Hazards Program ashfall impact pages (usgs.gov/volcanoes)
USGS Professional Paper 1250: The 1980 Eruptions of Mount St. Helens
Washington Military Department Emergency Management Division volcano planning
Volcanic Ash Impacts and Mitigation (volcanoes.usgs.gov/volcanic_ash)

### Actionable Steps

Contact USGS Cascades Volcano Observatory (Vancouver, WA) for ash impact specialists
Approach USGS Yellowstone Volcano Observatory scientist-in-charge on trigger matrix
Reach Washington EMD for volcano plan owners
Consult Spokane and Yakima county emergency managers for 1980 cleanup lessons

### Rationale for Suggestion

Only North American precedent for large ashfall over the same Montana/Idaho region and multi-state response. Provides evidence on ash on roads, N95/respirator needs, water systems, power and aviation closures. Eruption was far smaller than VEI-6, so quantities must be scaled up.
## Suggestion 4 - Eyjafjallajökull Eruption Airspace Closure and Ash Management (Europe, 2010) - SECONDARY

The April 2010 eruption closed much of European airspace for about a week, grounding over 100,000 flights (approximate). Regulators then introduced ash-concentration thresholds and zones, letting flights resume under tiered limits.

### Success Metrics

Airspace reopened under tiered ash-concentration limits within days (approximate)
EASA/ICAO ash contingency frameworks adopted

### Risks and Challenges Faced

Blanket closure cost: replaced by concentration-based zones
Uncertain ash forecasts: improved VAAC modelling and sampling

### Where to Find More Information

ICAO International Airways Volcano Watch documentation
EASA volcanic ash guidance
Met Office London VAAC publications

### Actionable Steps

Contact Met Office London VAAC and Anchorage/Washington VAAC (NOAA) for ash model procedures
Approach FAA Air Traffic Organization Northwest Mountain Region for exception protocol

### Rationale for Suggestion

Secondary suggestion. Informs ZLC/ZSE grounding and the narrow medevac/survey exception framework. Geographically distant and an aviation-only case; no ground evacuation lessons.

## Summary

Reference projects for a Yellowstone Zone Zero/Zone One evacuation under Scenario Alpha and Beta. No Yellowstone eruption precedent exists, so the picks cover the four hardest elements: mass evacuation with contraflow (Hurricane Rita), multi-day mountain-corridor evacuation under hazard (Camp Fire/Paradise), volcanic ashfall response and ash-safe aviation (Mount St. Helens 1980, Eyjafjallajökull 2010), and pre-planned volcanic evacuation (Cascades/Rainier lahar planning). Figures below are approximate and not verified; contact the named organizations for authoritative data. Geographic proximity is strongest for Mount St. Helens (Pacific Northwest, same FEMA Region 10 seam) and Camp Fire (US western mountain roads). Rita is geographically distant but is the main US contraflow reference. Eyjafjallajökull is secondary and covers airspace closure.