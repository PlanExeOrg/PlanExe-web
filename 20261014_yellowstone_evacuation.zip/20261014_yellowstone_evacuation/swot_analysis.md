
## Strengths 👍💪🦾
- Clear life-safety mission with hard gates: G1 at T+6 h (at least 98% of 35,800 confirmed out) and G2 at T+24 h (at least 95% of registered Zone One residents out).
- Three-exit contraflow (West US-20/US-191, North US-89, East US-14/16/20) with fixed district-to-gate split of 50/30/20%, so no vehicle crosses the interior.
- Unified Command at Denver RRCC with Region 10 liaison from T+0 and a forward element at Livingston, giving corridor visibility and federal resource access.
- Pre-authorized USGS trigger matrix lets the UC order the 500 km Beta expansion within 30 min without further approval.
- Layered communications (IPAWS/WEA, Guard signal teams, HAR/VMS, multilingual route cards) and a tiered fuel priority for hospitals, comms and shelter kitchens.
- Established tools: NIMS/ICS, FEMA contract vehicles, Stafford Act funding with a USD 200 million planning envelope (estimate) and USD 40 million contingency.

## Weaknesses 👎😱🪫⚠️
- No second-stage destinations are confirmed for Scenario Beta; the ring covers millions of people, not quantified, and hubs must lie outside 500 km (Denver, Cheyenne candidates, distance not verified).
- No pre-event lead time: pre-awarded contracts, MOUs and exercises cannot precede T+0, so readiness actions compress into T+0 to T+12 h and hardening in Months 1-3 (2026-11-14 to 2027-01-14).
- Thin responder depth: 100-150 rangers (estimate) give about 67-100 concurrent positions, all consumed during T+2 to T+8; responder N95 count is unsized.
- Water arrival at shelters expected T+18 to T+30 h (estimate) versus the T+24 h target; 12 h dispatch is not delivery.
- Zone One resident population is unquantified; a census is needed by T+6 h.
- Shelter sites are chosen only at T+6 h, and Bozeman and Idaho Falls sit near the ash risk; the 100,000 civilian N95 stock may be too small and masks clog quickly.
- Language and mobility needs have no sizing data; financing split for shelters and hubs is open.

## Opportunities 🌈🌐
- Interim ranked hub list (at least 5 hubs outside the ring) by T+12 h, then written plan by Month 1 (2026-11-14), MOUs by Month 2 (2026-12-14) and exercise by Month 3 (2027-01-14), to turn the Beta trigger into an executable order.
- Ring-based Beta execution (0-100 km organized, 100-250 km time-banded, 250-500 km staged) spreads road load and limits shadow evacuation.
- Concessioner (Xanterra) buses and manifests raise persons per vehicle and reach vehicle-less and mobility-limited visitors.
- Lessons from Hurricane Rita, Camp Fire, Mount St. Helens and Eyjafjallajökull on contraflow termini, alert layering, ash logistics and tiered airspace exceptions.
- Forward depots at Bozeman, Billings and Idaho Falls plus FEMA surge clauses can bring water arrival toward T+24 h.
- Real-time PM10 sensing and USGS/NOAA plume updates can steer shelter siting and relocation within 4 h.

## Threats ☠️🛑🚨☢︎💩☣︎
- Gallatin Canyon or Gardiner blockage (rockfall, breakdown, secondary slide) halting a corridor; more than 45 min triggers diversion adding 2-4 h for some.
- Ash and tremor collapsing cell towers and power, leaving drivers and responders without route guidance.
- Eruption onset overlapping with the evacuation peak, before Zone Zero is cleared at T+6 h.
- Authority gaps at the NPS-to-state handoff and FEMA Region 8/10 seam; governors' verbal authorization not yet secured, with a competing shelter-in-place order possible.
- Shadow evacuation and message reversal (shelter-in-place then Beta) eroding trust and saturating I-90, I-15 and US-191.
- Ash footprint forecast error placing shelters in heavy ash; hospital and grid failure before fuel arrives.
- Procurement delays of 24-48 h (estimate) if FEMA verbal activation fails; ash grounding removes medevac unless exceptions are approved.

## Recommendations 💡✅
- Month 0 (2026-10-14) (T+0 to T+12 h): UC seats the Region 10 liaison, obtains verbal governor authorization by T+6 h, and issues the interim ranked hub list (at least 5 outside the ring) by T+12 h. Owner: UC Director, Denver RRCC.
- T+0 to T+1 h: activate contraflow on all three exits; position at least 2 tow/rockfall teams to reach Gallatin Canyon within 15 min; apply the 45 min diversion rule. Owners: NPS incident commander, MT/WY highway patrol, state DOTs.
- T+0 to T+12 h: deploy Guard signal teams, HAR/VMS and route cards in English plus 5 languages at every control point and the forward element. Owner: Guard signal lead with FEMA IPAWS.
- T+0 to T+6 h: activate the 6 h shift and 18 h withdrawal limits, request the 30-50 standby reserve and out-of-region Guard, and size a separate responder N95 stock. Owner: Forward UC logistics chief.
- By T+12 h: dispatch convoys from forward depots using FEMA surge clauses and a reserved I-15 lane; install PM10 sensors at shelters and set the 4 h relocation rule. Owners: FEMA logistics, Guard, NOAA/USGS liaison.
- Months 1-3 (2026-11-14 to 2027-01-14): sign MOUs (governors, Region 10, utilities, hubs), finish the written Beta plan, and run full-scale Beta, shift-rotation and water-convoy exercises. Owner: FEMA Region VIII with state emergency managers.

## Strategic Objectives 🎯🔭⛳🏅
- Confirm at least 98% of 35,800 people (about 35,084) out through exit counts by T+6 h, with contraflow active on all three corridors by T+1 h.
- Evacuate at least 95% of registered Zone One residents by T+24 h with the perimeter staffed and the Beta interim hub list issued.
- Issue an interim list of at least 5 ranked hubs outside the 500 km ring by T+12 h, a written second-stage plan by Month 1 (2026-11-14), signed MOUs by Month 2 (2026-12-14) and a full exercise by Month 3 (2027-01-14).
- Deliver water to all shelters by T+24 h, targeting about 1.43 million liters for 10 days (estimate), with convoys dispatched by T+12 h.
- Keep at least 50% responder coverage at every post through T+72 h and relocate any shelter within 4 h of exceedance.

## Assumptions 🤔🧠🔍
- Scenario Alpha has a 40% probability within 72 h and T+0 coincides with project start (user constraint).
- Pre-event contracts and exercises are unavailable; existing FEMA contract vehicles can be activated verbally.
- The 50/30/20% gate split and 3.0 persons per vehicle hold (estimates).
- Salt Lake City, Billings, Bozeman, Idaho Falls and probably Boise lie inside the 500 km ring.
- The cost is fully public; the USD 200 million envelope (estimate) is adequate for the readiness package.

## Missing Information 🧩🤷‍♂️🤷‍♀️
- Zone One resident population and special-needs registry.
- Population inside the 500 km ring and capacity of Denver and Cheyenne (distances not verified).
- Final USGS trigger indicator values (due by T+3 h).
- Number of Guard signal units, buses, drivers and tow assets available by T+1 h.
- Responder headcount for N95 sizing and relief depth beyond the rangers.
- Who finances shelters, hubs and state costs (federal versus state/local).
- Hourly ash dispersion data and geotechnical status of Gallatin Canyon and the South Entrance slide.
- Visitor language, mobility and vehicle-less shares.

## Questions 🙋❓💬📌
- If the Beta order is issued at T+12 h, where does each ring go, and who owns each destination?
- What happens to corridor throughput if Gallatin Canyon is blocked for more than 2 h at T+3 h?
- Which responder posts can be thinned first without breaking the T+6 h gate?
- How will the public be told that a shelter-in-place instruction is superseded, and through which channel when cell service fails?
- Which decisions cannot wait for governor MOUs, and what authority covers T+0 to Month 1 (2026-11-14)?