# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Volcanologist & USGS Hazard Forecaster

**Knowledge**: volcanic hazard assessment, eruption-probability modeling, VEI classifications, ashfall forecasting, USGS monitoring networks

**Why**: The Scenario Alpha/Beta trigger matrix (Section: Escalation Trigger decision, canonical facts) references a 40% VEI-6+ probability and pre-authorized threshold-based indicators, but the final USGS trigger values are listed as 'due by T+3h' with only a placeholder. This expert must harden the trigger matrix, validate the modeled ashfall footprint upon which shelter siting (T+6h) depends, and confirm the 500 km Scenario Beta ring adequacy.

**What**: Review and finalize the USGS trigger indicator thresholds (uplift rate, seismic magnitude, gas flux) that activate Zone One and Scenario Beta expansion by T+3h; validate the ashfall dispersion model confidence bounds (currently ±50 km) to certify the shelter-siting rule and real-time monitoring thresholds (50/100 µg/m³ PM10).

**Skills**: eruption probability estimation, ashfall transport modeling, seismic-swarm interpretation, real-time USGS data integration, multi-agency forecasting protocols

**Search**: USGS volcanologist eruption forecasting, Yellowstone hazard monitoring, ashfall dispersion modeling, VEI probability assessment

## 1.1 Primary Actions

- Halt the plan at its current scope and insert a mandatory pre-authorization gate: do not activate Zone Zero evacuation operations (T+0 onward) until three conditions are met: (1) a written Scenario Beta Secondary-Stage Evacuation Plan with at least five ranked hubs, signed host MOUs and supply pre-positioning schedules is finalized; (2) a Responder Exposure and Relief Protocol with explicit shift limits, a 30–50 person standby reserve and pre-event Guard reinforcement commitments is signed; (3) real-time ashfall monitoring with 4-hour relocation protocols and a supplemental N95 reserve is deployed. These three actions are tightly coupled cascade-failure risks; all must be completed before T+0 or residual risk remains unacceptable.
- Execute the Scenario Beta Secondary-Stage Evacuation Plan immediately by Month -2 (2026-08-14 18:00): name five to ten ranked shelter hubs outside the 500 km ring (e.g., Denver, Cheyenne, western Kansas, Oklahoma, northern Texas); obtain signed MOUs from each host county or state confirming bed capacity, water/food/medical supply pre-positioning, and integration with their own emergency operations centers; calculate the population in each ring (0–100 km organized, 100–250 km time-banded, 250–500 km staged) and assign evacuees to hubs by geographic proximity; pre-authorize tiered public messaging (shelter-in-place zones, time-banded zones, organized evacuation) and conduct a full-scale routing exercise by Month -0.5 (2026-09-29 09:00–18:00) to measure actual bus-convoy transit times and identify bottlenecks.
- Define and operationalize the Responder Exposure and Relief Protocol by Month -1 (2026-09-14 18:00): issue a written protocol specifying 6-hour maximum shifts at ash-exposed posts (contraflow checkpoints, perimeter gates, comms sites), mandatory 2-hour rest with N95 replacement, and full withdrawal after 18 consecutive hours; explicitly count separate N95 respirators for responders (estimated 150,000–200,000 total, not drawn from the 100,000 civilian stock); pre-position a 30–50 person standby reserve from out-of-region agencies (Colorado Parks and Wildlife, Wyoming Game and Fish, Idaho Department of Lands) at a logistics depot (Billings or Cheyenne) by Month -0.5 (2026-09-29 12:00); secure pre-event written commitments from Fort Carson (Colorado National Guard) and Wyoming/Montana Guard Joint Task Force for out-of-region reinforcement without state-level approval delays; conduct a 6-hour shift-rotation exercise at Mammoth or Gardiner checkpoint 30 days before the window (Month -0.5, 2026-09-29 08:00–14:00) to test relief handoff, N95 replacement and fatigue-assessment procedures.
- Deploy real-time ashfall monitoring and dynamic shelter-relocation protocols by Month -0.5 (2026-09-29 14:00): install continuous PM10/PM2.5 sensors and visual ash-depth measurement stations at Bozeman, Idaho Falls and the forward command element (Livingston or Bozeman) with automated hourly data feeds to USGS/NOAA liaisons and alert thresholds (PM10 >50 µg/m³ triggers forecast update; >100 µg/m³ triggers shelter-suitability review); develop a ranked three-shelter backup system for each primary site by Month -1 (2026-09-14 18:00), identifying second and third locations 50+ km upwind with written agreements for rapid occupancy transfer within 4 hours; pre-stage a supplemental 100,000 N95 masks at a secondary distribution hub (Billings Regional Medical Center or Salt Lake City) by Month -0.5 (2026-09-29 18:00) with standing 24-hour delivery agreements (ground convoy or helicopter) ensuring delivery within 8 hours if primary stock usage exceeds 20% per day; conduct a shelter-siting and relocation exercise with NOAA, USGS and all shelter facility managers 30 days before the window (Month -0.5, 2026-09-29 10:00–16:00) simulating ashfall exceeding forecast by 50 km or doubling in intensity, testing real-time forecast updates, relocation-trigger points and 4-hour bus-dispatch logistics.
- Secure multi-state authority MOUs and boundary-coordination protocols by Month -1 (2026-09-14 18:00): obtain written authorization letters from the governors of Montana, Wyoming and Idaho explicitly confirming their authorization of the Unified Command's Zone One and Scenario Beta orders, their commitment to unified public messaging and their agreement to cede operational authority over park-boundary traffic to the NPS incident commander until a formal handoff order is issued; execute written MOUs with Montana DOT, Wyoming Highway Patrol and Idaho Transportation Department specifying exact boundary-transfer checkpoints (Mammoth on US-89, Gallatin County line on US-191, Cody city limits on US-14/16/20), defining operational custody (shelter assignment, medical routing, vehicle documentation) and pre-authorizing state on-scene commanders to issue temporary reroutes without park ranger approval (maximum 30-minute reroute window without FEMA approval); establish a Boundary Coordination Officer position at the forward command by Month -0.5 (2026-09-29 09:00) with 24/7 voice, data and satellite-communication links to the NPS incident commander, three state on-scene commanders and the Denver RRCC, operating a dedicated interagency channel with authority to make traffic and initial-shelter decisions without supervisory approval if higher-authority communication is lost >5 minutes; schedule a multi-state command-authority exercise 60 days before the window (Month -1.5, 2026-08-29 09:00–16:00) testing the boundary handoff under escalation scenarios and documenting any jurisdictional conflicts or communication gaps for resolution by Month -1 (2026-09-14 18:00).

## 1.2 Secondary Actions

- Pre-position corridor-clearing equipment and issue hard-abort diversion rules: deploy two mobile heavy-equipment teams (heavy wreckers, debris chippers, spotters, geotechnical monitoring drones, 72-hour fuel) to Mammoth or Spanish Creek by Month -0.5 (2026-09-29 06:00) with standing 15-minute dispatch authority to any Gallatin Canyon blockage; establish live geotechnical monitoring (motion sensors or drone-based slope-displacement monitoring) along Gallatin Canyon and US-89 near Gardiner by Month -0.5 (2026-09-29 12:00) with automatic alerts if displacement exceeds 2 cm/hour; conduct a South Entrance geotechnical survey 60 days before the window (Month -1.5, 2026-08-29 08:00–17:00) to quantify debris volume and develop a time-boxed (maximum 4 hours) single-lane clearance plan with hard abort triggers (M>4.0 seismic event, >2 cm slope displacement, equipment breakdown >30 minutes); issue a written Loss-of-Exit Contingency Protocol by Month -1 (2026-09-14 18:00) specifying that if any corridor blockage persists >45 minutes (proposed threshold), diversion to the nearest surviving exit is triggered and shelter-in-place orders are issued within 5 minutes via IPAWS/WEA.
- Activate FEMA Region 10 mutual-aid coordination and pre-authorize fuel and water convoys: schedule a formal FEMA Region 10 (Seattle) coordination call at T+0 and 12-hour intervals thereafter through Month 1 (2026-11-14), with a standing Idaho State Emergency Management Agency liaison and representatives from Boise and Pocatello water and fuel distribution authorities; pre-authorize water and fuel convoys from Salt Lake City (I-15 northbound) and secondary sources (Pocatello, Butte) by Month -1 (2026-09-14 18:00) with written surge-mobilization contracts requiring 12-hour dispatch on verbal activation by the forward command; establish a procurement checkpoint at the forward command by Month -0.5 (2026-09-29 12:00) staffed by a logistics officer with real-time tracking of all inbound supply shipments and pre-authorized authority to request helicopter resupply if ground routes are blocked due to ashfall or congestion (estimated 6-hour ground transit = diversion trigger threshold); conduct a supply-convoy exercise from Salt Lake City to Bozeman 30 days before the window (Month -0.5, 2026-09-29 08:00–18:00) under simulated ashfall and congested-traffic conditions, measuring actual travel times and identifying I-15/I-80/I-90 chokepoints.
- Coordinate hospital power resilience and pre-position generator fuel reserves: establish a 24/7 utility-operations coordination hotline from the forward command to Montana-Dakota Utilities, Pacific Power and Idaho Power dispatch centers by Month -1 (2026-09-14 18:00) with a named utility liaison available from T-12 hours through T+72 hours; pre-deploy mobile generator units and voltage-regulation equipment at the two largest substations (serving Bozeman and Idaho Falls) by Month -0.5 (2026-09-29 06:00); pre-position 72-hour diesel and propane fuel reserves at the three largest receiving hospitals (Bozeman Deaconess, Livingston HealthCare, Eastern Idaho Regional Medical Center) by Month -0.5 (2026-09-29 18:00) with written confirmation of tank capacity and fueling-port adequacy; establish written fuel-delivery contracts with local vendors (Yellowstone Energy, Basin Fuel) requiring priority dispatch within 2 hours during the event (activate at T+0); conduct hospital-power-failure exercises at each receiving hospital 30 days before the window (Month -0.5, 2026-09-29 at different times) testing generator startup, fuel-transfer mechanics, backup surgical protocols and manual ventilation under 4+ hour outage scenarios; pre-authorize helicopter fuel caches at airfields (Gallatin County Airport near Bozeman, Jackson Hole Airport, Billings Logan) by Month -0.5 (2026-09-29 12:00) with 72-hour diesel reserves and standing airlift protocols with Wyoming National Guard (Cheyenne aviation) and U.S. Air Force (Malmstrom AFB) for priority dispatch within 4 hours from T+0 to T+72 hours.
- Establish communications redundancy and pre-authorize Guard signal deployment: deploy National Guard signal corps teams with satellite phones, portable radio repeaters, generator fuel and equipment caches to each contraflow control point (Mammoth, Gallatin County, Cody) and the forward command by Month -0.5 (2026-09-29 14:00), confirming each site has satellite-communication capability (minimum one satellite phone or Iridium terminal), a portable VHF/UHF repeater with 72-hour fuel reserve and automatic fuel replenishment; pre-produce IPAWS, WEA, NOAA Weather Radio and highway advisory radio content in English and five primary visitor languages (Spanish, Japanese, German, Mandarin, French) by Month -1 (2026-09-14 18:00), with simple phased instructions validated for comprehension by native speakers (cognitive testing 3–5 per language by Month -1.5 (2026-08-29 18:00)); conduct formal radio interoperability testing across all agencies (NPS, state highway patrols, National Guard, FEMA) 30 days before the window (Month -0.5, 2026-09-29 08:00–16:00) confirming frequency coordination, call signs, encryption protocols and on-air checks from every checkpoint; test satellite and portable-repeater systems under simulated ashfall conditions 30 days before the window (Month -0.5, 2026-09-29 14:00–17:00 on different dates), measuring radio propagation, equipment overheating and operator visibility, with at least 4 consecutive hours of simulated ashfall testing.
- Quantify Zone One resident population and refine shelter-siting criteria: conduct a rapid census of registered residents in West Yellowstone (MT), Gardiner (MT) and Cody (WY) by Month 0 (2026-10-14 12:00), coordinating with local emergency management and chambers of commerce to obtain baseline evacuation-zone population estimates; cross-reference with hotel occupancy (concessioner manifests), campground registrations and permit databases to estimate transient populations; establish a tiered resident registry (critical infrastructure, medical-dependent, mobility-limited) to prioritize early evacuation and pre-position accessible transport; integrate the census with the shelter-siting algorithm to pre-stage capacity and supplies at Bozeman, Idaho Falls and a third site based on geographic distribution and wind-forecast upwind positioning.
- Pre-authorize helicopter rotary-wing medevac and survey exceptions: request written FAA authorization by Month -1 (2026-09-14 18:00) for narrow government rotary-wing medevac flights below defined ash-concentration limits (recommend <500 µg/m³ PM10), approved by the Unified Command and coordinated with NOAA/USGS plume forecasts; establish a dynamic airspace-tiering system driven by 4-hourly ash-dispersion forecasts that opens and closes corridors for cargo and evacuation flights from airfields outside the plume (southern ZLC area candidates); coordinate with the Wyoming National Guard aviation unit and U.S. Air Force to pre-authorize priority dispatch protocols for medevac and survey sorties within 2 hours of UC request from T+0 through T+72 hours.

## 1.3 Follow Up Consultation

At Month 1 (2026-11-14) review the three completed pre-authorization actions: Scenario Beta Secondary-Stage Plan (signed MOUs, hub capacity verified), Responder Exposure Protocol (relief reserve positioned, Guard reinforcement letters on file) and Ashfall Monitoring (sensor deployment confirmed, relocation protocols tested). Assess whether the plan's core bottlenecks (Gallatin Canyon, cell-tower failures, shelter siting) have been mitigated and whether hidden dependencies have emerged from exercises. Confirm that responder staffing depth is credible, that second-stage evacuation destinations are named and ready, and that the Unified Command's authority chain is unbroken from the forward element through Denver to governors. Prepare the after-action report framework and schedule the full-scale Beta exercise for Month 3 (2027-01-14). Flag any unresolved financing decisions (federal vs. state cost-share for hubs and shelter sites) for immediate senior-leadership escalation.

## 1.4.A Issue - Scenario Beta secondary-stage plan is a hollow pre-authorization with no executable destinations

The plan mandates a pre-authorized VEI-7 trigger that activates a 500 km evacuation order for millions of people, but names no destinations, capacity, or second-stage logistics. Denver and Cheyenne are candidates, but distances are unverified and host-community MOUs do not exist. Without a written, signed plan naming five to ten ranked hubs with bed counts and supply pre-positioning, issuing the 500 km order will trigger uncontrolled flight saturating I-15, I-80 and I-90, stranding the primary 35,800-person Zone Zero evacuation for 4–8 additional hours. This is the single largest residual risk.

### 1.4.B Tags

- scenario-beta-hollow-trigger
- no-second-stage-destinations
- cascade-failure-coupling

### 1.4.C Mitigation

Execute a written Scenario Beta Secondary-Stage Evacuation Plan by Month -2 (2026-08-14), naming at least five ranked shelter hubs outside the 500 km ring with signed host MOUs, bed counts, supply pre-positioning schedules and tiered public-messaging templates. Conduct a full-scale Beta routing and intake exercise by Month -0.5 (2026-09-29), testing bus dispatch, shelter registration and lateral-route traffic flow from each primary shelter to its secondary hub. Pre-authorize the UC to issue the 500 km order via a written trigger matrix by T+0, with the interim hub list published to the public by T+12 hours.

### 1.4.D Consequence

Without the secondary-stage plan, a VEI-7 trigger will activate an evacuation order for which evacuees have no published destinations. Shadow evacuation and panic will saturate the same corridors needed to clear Zone Zero, adding 4–8 hours of delay and enabling 5–20 preventable deaths. Shelters in Denver and Cheyenne will be overwhelmed without advance capacity planning, forcing emergency relocations and stranding 200–500 evacuees mid-operation.

### 1.4.E Root Cause

The plan was written under the constraint that pre-event lead times are unavailable and execution must begin at T+0. The decision to pre-authorize the 500 km trigger (user constraint) was made before a destination plan existed, creating a temporal mismatch: the trigger is ready to fire, but the execution plan does not exist. This is a process gap, not an operational oversight.

## 1.5.A Issue - Responder staffing is exhausted during peak evacuation with zero relief depth and no contingency for attrition

The plan budgets 100–150 NPS rangers at a 1.5 relief ratio, yielding 67–100 concurrent positions across three exits, perimeter gates, and comms posts during the T+2 to T+8 evacuation peak. A single injury, equipment failure, or traffic incident at a critical checkpoint (e.g., Mammoth or Gallatin Canyon) could remove 5–10 responders, leaving that post below safe staffing and halting traffic for 2–4 hours. The plan does not pre-position a standby reserve or define responder exposure limits (shift length, rest cycles, N95 allocation). Without explicit protection, responder illness from ash exposure will degrade the force just as the evacuation peaks.

### 1.5.B Tags

- responder-staffing-exhaustion
- zero-relief-depth
- no-exposure-limits

### 1.5.C Mitigation

Define a written Responder Exposure and Relief Protocol by Month -1 (2026-09-14) specifying 6-hour shifts at ash-exposed posts, mandatory 2-hour rest with N95 replacement, and full withdrawal after 18 consecutive hours. Pre-position a 30–50 person standby reserve from out-of-region agencies (Colorado Parks and Wildlife, Wyoming Game and Fish) at a logistics depot outside the ash zone by Month -0.5 (2026-09-29). Secure pre-event commitments from Fort Carson and state Guard Joint Task Force for reinforcement without state-level approval delays. Conduct a 6-hour shift-rotation exercise at a checkpoint 30 days before the window to test relief handoff and fatigue-assessment protocols.

### 1.5.D Consequence

All 100–150 rangers will be consumed during the T+2 to T+8 peak with no coverage cushion. A single traffic incident (vehicle breakdown, secondary slide) could halt one checkpoint for 2–4 hours, stranding 500–2,000 vehicles in ash and cascading 1–2 hours of delay to the entire evacuation. Responder respiratory illness will degrade the force at the peak moment, reducing traffic throughput by 20–40% and extending clearance by 2–4 additional hours.

### 1.5.E Root Cause

Responder staffing levels were estimated at 100–150 rangers based on park baseline. The plan does not account for the additional posts needed for a three-exit contraflow operation or for the fatigue and illness effects of working in ashfall. The 1.5 relief ratio is a standard assumption, but it is inadequate for a 72-hour sustained operation with zero pre-event lead time for recruiting or training reinforcements.

## 1.6.A Issue - Shelter siting based on a single T+6 forecast update ignores ashfall forecast uncertainty of ±50 km and masks clog rate

The plan selects final shelter sites at T+6 hours from the latest NOAA/USGS plume forecast. Ashfall modeling uncertainty is typically ±50 km or larger, and volcanic-ash forecasts from an unprecedented VEI-6 event have no ground-truth calibration. If actual ashfall diverges from the forecast by 50 km southward or doubles in intensity, shelter sites (e.g., Bozeman, Idaho Falls) could be placed in moderate-to-heavy ash within 4–6 hours of occupancy. The plan pre-stages only 100,000 N95 masks for 35,800 evacuees; assuming a 70% occupancy rate (25,060 people), masks clog after 6–8 hours in heavy ashfall and require replacement cycles not detailed in the plan. No real-time monitoring or relocation protocol exists.

### 1.6.B Tags

- ashfall-forecast-uncertainty
- shelter-siting-single-update
- n95-clog-rate-unplanned

### 1.6.C Mitigation

Deploy continuous PM10/PM2.5 sensors and visual ash-depth stations at Bozeman, Idaho Falls and the forward command by Month -0.5 (2026-09-29), with automated hourly updates to USGS/NOAA liaisons and alert thresholds (PM10 >50 µg/m³ triggers forecast update; >100 µg/m³ triggers shelter-suitability review). Develop a ranked three-shelter backup system for each primary site by Month -1 (2026-09-14), identifying second and third locations 50+ km upwind with pre-authorized 4-hour relocation protocols. Pre-stage a supplemental 100,000 N95 masks at Billings or Salt Lake City hub by Month -0.5 (2026-09-29) with standing 8-hour ground-convoy or helicopter delivery agreements. Conduct a full shelter-siting and relocation exercise 30 days before the window (Month -0.5, 2026-09-29).

### 1.6.D Consequence

Ashfall diverging 50 km from forecast or doubling in intensity will place 10,000–15,000 evacuees in moderate-to-heavy ash within 4–6 hours, forcing emergency relocation mid-operation. Without relocation protocols and standby facilities, 200–500 people will be stranded or delayed by 4–8 hours. Mask clogging without replacement logistics will leave evacuees unprotected for 6–12 hours, causing respiratory distress in 500–1,000 people and forcing 100–200 hospital transfers, overwhelming receiving facilities.

### 1.6.E Root Cause

Ashfall forecasting for a VEI-6 event is unprecedented; model uncertainty ranges widely and is often not disclosed. The plan assumes a single forecast update at T+6 hours is sufficient for a 24-hour shelter occupancy. N95 clog rates in heavy ash (6–8 hours) are documented in industrial and wildfire contexts, but the plan does not specify replacement cycles or a supplemental reserve, treating the 100,000 stock as static.

---

# 2 Expert: Regional Emergency Management & Multi-Jurisdiction Coordination Director

**Knowledge**: NIMS/ICS, Unified Command structure, FEMA Region operations, cross-state EMAC mutual aid, governor authority transfer, incident command handoff protocols

**Why**: The Command Structure decision and canonical facts specify a forward UC element at Livingston, Region 10 liaison from T+0, and NPS-to-governor authority transfer at park boundaries, yet the implementation pathway from verbal authorization (T+6h) to signed MOUs (Month 1 = 2026-11-14) remains incomplete. This expert must operationalize the Unified Command, resolve the FEMA Region 8/10 seam, and certify that the Boundary Coordination Officer's delegated authority survives legal and jurisdictional challenge.

**What**: Design the Unified Command organizational chart, communication protocols and decision-authority matrix from T+0 through T+72h; produce a template NPS-to-governor handoff protocol and written EMAC mutual-aid activation language for Montana, Wyoming and Idaho by Month 0.5 (2026-10-29); confirm that the Boundary Coordination Officer's unilateral reroute and shelter-assignment authority (5-minute comms loss tolerance) is legally defensible under Stafford Act and state emergency powers.

**Skills**: incident command system operations, multi-state coordination, FEMA grant/reimbursement rules, emergency declarations and legal authority, interagency communications protocols

**Search**: FEMA Region 8 incident commander, Unified Command multi-state evacuation, EMAC mutual aid coordinator, emergency management legal authority

## 2.1 Primary Actions

- Execute written Scenario Beta Secondary-Stage Evacuation Plan by Month 1 (2026-11-14) naming five or more ranked shelter hubs outside the 500 km ring with signed MOUs from host counties confirming capacity and 48-hour resource availability, paired with tiered ring-based public messaging and a full-scale exercise by Month 3 (2027-01-14).
- Issue written Responder Exposure and Relief Protocol by Month 0 (2026-10-14) T+0 specifying 6-hour shift limits, 18-hour withdrawal thresholds, separate responder N95 sizing (150,000–200,000 total), and pre-position a 30–50 person out-of-region relief reserve by Month 0 (2026-10-14) T-12 h with 4-hour dispatch authority.
- Deploy real-time PM10/PM2.5 sensors at all shelters and forward command by Month 0 (2026-10-14) T+0, pre-identify ranked backup shelter sites 50+ km upwind by Month 0 (2026-10-14) T-12 h, and issue a written 4-hour relocation protocol with pre-authorized shelter-transfer authority and pre-positioned buses for 10,000 evacuees by Month 0 (2026-10-14) T-12 h.
- Obtain written verbal pre-authorization of Zone One and Scenario Beta orders from Montana, Wyoming and Idaho governors by Month 0 (2026-10-14) T+6 h, and secure signed MOUs and EMAC arrangements confirming mutual-aid resource commitments (responders, fuel, water, shelter sites) by Month 1 (2026-11-14).
- Deploy National Guard signal teams with satellite phones, repeaters and 72-hour fuel at each contraflow control point and the forward command by Month 0 (2026-10-14) T+0, and activate IPAWS/WEA messaging in English plus five languages (Spanish, Japanese, German, Mandarin, French) with published USGS trigger logic to protect operational credibility.
- Establish a Boundary Coordination Officer at the forward command element (Livingston or Bozeman) by Month 0 (2026-10-14) T+0 with real-time voice and satellite links to NPS incident commander, three state on-scene commanders and Denver RRCC, and pre-authorized reroute and shelter-assignment authority during the NPS-to-state boundary crossing to close authority gaps.

## 2.2 Secondary Actions

- Pre-position at least two mobile heavy-equipment tow and rockfall-clearing teams to reach any Gallatin Canyon blockage within 15 minutes by Month 0 (2026-10-14) T-12 h, with surveyed single-lane bypass routes marked and a 45-minute blockage diversion rule tied to the nearest surviving exit.
- Establish written Loss-of-Exit Contingency Protocol by Month 0 (2026-10-14) T-12 h specifying hard abort triggers (M>4.0 seismic event, >2 cm slope displacement, 30-minute equipment breakdown) and mandatory diversion-to-next-exit procedures with shelter-in-place and IPAWS notification within 5 minutes.
- Activate supply-convoy surge protocols from Salt Lake City, Pocatello and Butte with 12-hour dispatch-to-first-delivery targets for bottled water (1.43 million liters for 10 days), N95 respirators (100,000 civilian + 100,000 reserve), diesel fuel (for generators and ambulances) and medical supplies, using existing FEMA contracts with pre-authorized verbal activation.
- Pre-position 72-hour diesel and propane reserves at three receiving hospitals (Bozeman, Livingston, Eastern Idaho Regional Medical Center) by Month 0 (2026-10-14) T-12 h, establish 24/7 utility-operations coordination hotlines with Montana-Dakota Utilities, Pacific Power and Idaho Power by Month 0 (2026-10-14) T+0, and conduct hospital power-failure exercises at each facility Month 0 (2026-10-14) T-12 h.
- Develop and pre-authorize a Scenario Beta trigger matrix (e.g., modeled VEI-7 probability ≥20% in remaining window) with final USGS indicator values by Month 0 (2026-10-14) T+3 h, and issue written pre-authorization to the Unified Command to activate the 500 km order within 30 minutes of trigger without further approval.
- Conduct multi-state command-authority exercises involving NPS, governors' representatives, highway patrol and National Guard commanders Month 0 (2026-10-14) T-12 h, testing boundary handoff under escalation scenarios (Zone One, then Scenario Beta expansion), and document jurisdictional conflicts or communication gaps in an after-action report by Month 0 (2026-10-14) T-12 h.
- Census Zone One registered residents (West Yellowstone, Gardiner, Cody and surrounding counties) by Month 0 (2026-10-14) T+0 to establish baseline evacuation population, identify special-needs registrants (mobility, medical, non-English), and size assisted-evacuation shuttles and multilingual messaging.
- Establish real-time interagency communication channel (dedicated radio frequency, encrypted satellite line or collaborative voice platform) linking forward UC element, three state on-scene commanders, Denver RRCC and USGS/NOAA liaison from Month 0 (2026-10-14) T-12 h through T+72 h with defined call cadence (recommended hourly at peak hours T+0 to T+24 h).

## 2.3 Follow Up Consultation

At the next meeting, confirm: (1) Which federal agency (FEMA Region VIII, NPS or Denver RRCC) owns the Scenario Beta hub-site search, MOU signature authority and hub pre-positioning budget? (2) What is the written authority chain for the governors to approve the Unified Command's Zone One and Beta orders if pre-event MOUs are not signed? (3) Does the responder relief reserve (30–50 out-of-region staff) come from National Guard, state wildlife agencies or FEMA contracts, and who authorizes their deployment? (4) Will the plan include a written decision rule for whether shelter relocation (if ashfall exceeds forecast) triggers a shelter-in-place order for delayed evacuees or an extension of the T+24 h Phase 2 deadline? (5) Are water-convoy dispatch contracts with Salt Lake City distributors already in place for 12-hour verbal activation, or must they be negotiated in Months 1–3 (2026-11-14 to 2027-01-14)? (6) Who owns the ashfall forecast updates (NOAA, USGS, forward command?) and what is the decision cadence for triggering shelter suitability reviews and relocations?

## 2.4.A Issue - Scenario Beta destination plan is a placeholder, not an executable strategy

The plan mandates a pre-authorized VEI-7 order at T+0 that triggers a 500 km evacuation affecting millions of people, but names no specific secondary-stage hubs, no capacity commitments, and no signed MOUs from host counties. Denver and Cheyenne are candidates but distances are unverified; Salt Lake City, Billings and Bozeman are inside the ring and cannot serve. Without a written Beta destination plan by Month 1 (2026-11-14), the trigger is hollow—it activates an evacuation order for which evacuees have no published shelter addresses, causing chaotic uncontrolled flight that saturates I-15 and I-90, delays the primary Zone Zero evacuation by 4–8 hours, and strands 5,000–10,000 people in ash-exposed areas.

### 2.4.B Tags

- scenario_beta_destinations_undefined
- cascade_failure_risk
- authority_vs_capacity_mismatch
- uncontrolled_shadow_evacuation

### 2.4.C Mitigation

Execute a written Scenario Beta Secondary-Stage Evacuation Plan by Month 1 (2026-11-14) naming at least five ranked shelter hubs outside the 500 km ring (Denver, Cheyenne, Salida CO, Laramie WY, Ogden UT recommended; verify distances). Secure signed MOUs from each host county confirming bed capacity, medical staff, water and fuel availability for 100,000–500,000 evacuees on 48-hour notice. Publish tiered ring-based messaging (0–100 km organized, 100–250 km time-banded, 250–500 km staged) and conduct a full-scale Beta evacuation exercise with all states and hubs by Month 3 (2027-01-14).

### 2.4.D Consequence

Pre-authorized Beta order issued at T+12–24 h without destination clarity triggers tens of thousands of unordered departures from outer zones; I-15, I-90 and US-191 saturate within 4–6 hours; primary Zone Zero evacuation stalls as unordered traffic blocks exits; evacuation delay cascades by 4–8 hours; 5,000–10,000 people remain in ash-exposed areas when Scenario Alpha transitions to Beta; 20–50 preventable respiratory and trauma deaths; total cascade cost USD 200–500 million in additional response and recovery.

### 2.4.E Root Cause

Empty

## 2.5.A Issue - Responder staffing has zero relief depth during the T+2 to T+8 peak evacuation window

The plan budgets 100–150 NPS rangers at a 1.5 relief ratio, yielding only 67–100 concurrent positions across three exits, perimeters, comms sites and backcountry sweeps during the T+2 to T+8 evacuation peak when load is highest. A single traffic incident, equipment breakdown or injury at a critical checkpoint (Gallatin Canyon, Gardiner) will halt one corridor for 2–4 hours, stranding 500–2,000 vehicles in ash-heavy zones. Responder N95 stock is unsized and may be drawn from the 100,000 civilian reserve, eroding civilian protection. No written exposure limits or pre-positioned relief reserve exist.

### 2.5.B Tags

- responder_staffing_shortage
- relief_ratio_inadequate
- no_surge_capacity
- n95_sizing_gap

### 2.5.C Mitigation

Issue a written Responder Exposure and Relief Protocol by Month -1 (2026-09-14, simulated date; apply at Month 0 = 2026-10-14 T+0) specifying max 6-hour shifts at ash-exposed posts, 2-hour rest with N95 replacement, withdrawal after 18 consecutive hours. Pre-position a 30–50 person standby reserve from Colorado Parks and Wildlife, Wyoming Game and Fish, and Idaho Lands at a logistics depot in Billings by Month 0 (2026-10-14) T-12 h, trained and pre-authorized for 4-hour deployment dispatch. Size responder N95 respirators separately from the 100,000 civilian stock (recommend 150,000–200,000 total responder stock). Conduct a 6-hour shift-rotation exercise at Mammoth or Gardiner checkpoint Month 0 (2026-10-14) T-12 h.

### 2.5.D Consequence

Without relief depth, all responders are consumed during T+2 to T+8; a single 30-minute incident at Gallatin Canyon creates a 45-minute halt, stranding 500–2,000 vehicles; diversion adds 2–4 hours to their transit; total evacuation delay cascades by 1–3 hours; 10–20% of drivers take unintended routes; 200–500 evacuees remain in ash-exposed zones; 5–15 preventable respiratory injuries; evacuation cost increases by USD 50–100 million due to extended responder and shelter operations.

### 2.5.E Root Cause

Empty

## 2.6.A Issue - Shelter siting chosen only at T+6 hours leaves no margin for ashfall forecast error and relocation logistics

The plan defers final shelter-site selection to T+6 hours based on a single NOAA/USGS plume forecast update. Ashfall model uncertainty of ±50 km is documented in comparable eruptions; a 50 km southward shift or 2–3x intensity increase could place Bozeman or Idaho Falls directly in moderate-to-heavy ash at T+6–12 hours when 10,000–15,000 evacuees are already sheltered there. Relocation protocols and backup-site activation procedures do not exist. The 100,000 civilian N95 stock has no sizing basis and masks clog rapidly in heavy ash. If shelters must be evacuated mid-operation, transport buses and responders will be diverted from the primary evacuation.

### 2.6.B Tags

- shelter_siting_timing_inadequate
- ashfall_forecast_uncertainty
- n95_stock_unsized
- relocation_protocol_missing

### 2.6.C Mitigation

Deploy real-time PM10 and PM2.5 sensors at each shelter and the forward command by Month 0 (2026-10-14) T+0, with automated hourly feeds to the forward command and USGS/NOAA liaison. Pre-identify and pre-survey ranked backup shelter locations 50+ km upwind of each primary site by Month 0 (2026-10-14) T-12 h. Issue a written 4-hour relocation protocol by Month 0 (2026-10-14) T-12 h with pre-authorized shelter-transfer authority, notification procedures via IPAWS/WEA, and pre-positioned buses for up to 10,000 evacuees. Pre-stage a supplemental 100,000 N95 respirators at Billings or Salt Lake City by Month 0 (2026-10-14) T-12 h with 8-hour ground-convoy delivery commitment. Conduct a shelter-siting and relocation exercise with NOAA, USGS and all three shelter operators Month 0 (2026-10-14) T-12 h.

### 2.6.D Consequence

Ashfall forecast error of ±50 km or 2–3x intensity error leaves shelters in moderate-to-heavy ash by T+12–18 hours; 10,000–15,000 evacuees require emergency relocation; buses and responders diverted from primary evacuation; relocation logistics consume 4–8 hours; 200–500 evacuees stranded during transfer; shelter-in-place order issued for delayed residents; 50–100 respiratory injuries; evacuee confidence in the response collapses; compliance with subsequent orders drops by 20–40%; cost of emergency relocation USD 20–50 million.

### 2.6.E Root Cause

Empty

---

# 3 Expert: Transportation Operations & Contraflow Specialist

**Knowledge**: contraflow operations, highway traffic engineering, capacity analysis, bottleneck mitigation, incident response routing, geotechnical road hazards

**Why**: The Egress Corridor decision specifies a 50/30/20% split across three exits and a 45-minute blockage diversion threshold, yet the plan names only a 2-team tow/rockfall asset and lacks quantified corridor capacity under ash (visibility, road surface degradation). This expert must validate the throughput model, size the pre-placed equipment and standby capacity, and certify that the diversion protocol avoids cascading secondary blockages.

**What**: Audit the 660 vehicles/hour per-exit throughput estimate against observed contraflow capacity on US-191, US-20 and US-89 under ashfall conditions; quantify the minimum tow/rockfall asset count needed to clear a typical Gallatin Canyon blockage within 15 minutes; design a Loss-of-Exit Contingency protocol that diverts overflow without overloading surviving corridors and specifies hard abort criteria for South Entrance clearance attempts (currently M4.0+ tremor).

**Skills**: contraflow setup and termini design, highway-capacity modeling, bottleneck analysis, equipment pre-positioning, ashfall-road interaction, incident traffic management

**Search**: contraflow traffic operations highway, Gallatin Canyon geotechnical hazards, mountain-pass evacuation routing, volcanic ashfall road impact, I-90 capacity analysis

## 3.1 Primary Actions

- Commission a geotechnical survey of Gallatin Canyon (10 km highest-risk sections) and the South Entrance slide by Month -1.5 (2026-08-29): measure slope stability under seismic swarm, estimate debris-removal time per 10 m blockage, quantify secondary-slide probability during clearance, and deliver empirical basis for the 15-minute arrival and 45-minute diversion thresholds. If secondary-slide risk exceeds 20%, write off Gallatin Canyon clearance and allocate all load to northern and eastern exits.
- Conduct a rapid census and capacity study before Month 0 (2026-10-14) start (by 2026-10-14): quantify the population in the 0–100 km, 100–250 km and 250–500 km rings down to county level; verify hub distances (Denver, Cheyenne, Billings); obtain written capacity commitments from each hub's emergency management and shelter operators; and develop a signed-MOU Scenario Beta execution plan with three ring-based time-banded phases and published tier-assignment map.
- Execute a one-day site survey at each of the three contraflow termini (Mammoth, Gardiner, West Yellowstone, Cody entrance) by Month -0.5 (2026-09-29): measure staging-lot capacity, turn-pocket geometry, queue-storage length and the distance from lot exit to contraflow begin line. Calculate queue-duration at 660 veh/h inflow. If lot saturation occurs before road-capacity saturation, revise the exit split or add temporary overflow staging (nearby parking or school lots). Validate that 660 veh/h per exit is achievable, or revise the throughput target.
- Issue a public-facing Scenario Beta Tier System document by Month 0 start (2026-10-14) naming the hubs, specifying which zip codes are in each tier (organized, time-banded, staged), and explaining the published time-banded evacuation schedule. Distribute via all state emergency management websites, local radio and print media by Month 0 (2026-10-14) to reduce uncontrolled shadow evacuation.
- Pre-position a 20,000-person emergency supply cache (water, food, N95, fuel, medical) at an intermediate location on I-80 or I-90 outside the modeled ashfall footprint by Month -0.5 (2026-09-29), accessible to stranded outer-zone evacuees. Ensure 24/7 staffing and resupply logistics from T+0 through T+72 h.

## 3.2 Secondary Actions

- Establish real-time geotechnical monitoring along Gallatin Canyon and US-89 near Gardiner by Month -0.5 (2026-09-29) using motion sensors or drone-based slope-displacement monitoring at identified slide-prone zones. Set automatic alerts to the forward command if displacement exceeds incipient-failure thresholds (>2 cm/hour, proposed). Pre-authorize a temporary 15-minute traffic halt protocol if alerts trigger, with vehicles evacuated from exposed zones.
- Develop a written Scenario Beta execution plan with explicit time-banded schedules (release windows by county, 2-hour intervals, starting at T+12 h) and pre-authorize the Boundary Coordination Officer to issue time-band assignments via IPAWS/WEA without supervisory approval if communications with higher authority are lost for >5 minutes.
- Conduct a rapid-deployment exercise at the three contraflow termini (Mammoth, Gardiner, West Yellowstone) by Month -0.5 (2026-09-29) under simulated congestion, testing queue management, turn-pocket utilization and the staging-lot queuing rules. Measure actual throughput in vehicles per hour and identify any queue-storage deficits.
- Pre-position two additional heavy-equipment teams (beyond the two already planned) at Mammoth and Spanish Creek staging depots by Month -0.5 (2026-09-29), bringing the total mobile heavy-equipment force to 4 units, with standing dispatch authority to reach any corridor blockage within 15 minutes. Include geotechnical spotters and secondary-slide risk monitors on each team.
- Issue a written Loss-of-Exit Contingency Protocol by Month -1 (2026-09-14) specifying automatic diversion rules and temporary shelter-in-place procedures for queued vehicles if any primary corridor blockage persists >45 minutes. Pre-authorize the forward command to issue emergency reroutes via IPAWS within 5 minutes of diversion order.
- Establish a Corridor Capacity Operations Center at the forward command element (Bozeman or Livingston) staffed from T-12 hours through T+72 hours, with real-time traffic-camera feeds, queue-length monitoring, blockage alerts and automated reroute dispatch. Integrate with state highway-patrol and DOT traffic management to track actual versus planned throughput at each exit.
- Request a USGS hazards update on Scenario Beta population estimates and alternative evacuation-ring geometries (e.g., elliptical instead of circular, weighted by population density) by Month -1 (2026-09-14). Use the updated geometry to refine hub siting and time-banded scheduling.
- Secure written pre-event authorization from regional hospitals and utilities to prioritize backup power and water supply for evacuation-staging areas (parking lots, shelters, medical triage points) if the grid fails due to ash flashovers. Develop hospital isolation protocols to ensure continued surgical and intensive-care operations if grid power is lost for 4+ hours.

## 3.3 Follow Up Consultation

"In the next consultation, address: (1) the empirical contraflow termini design, including measured staging-lot capacity, turn-pocket geometry and validated throughput; (2) the Scenario Beta population census by ring and hub capacity commitments, with a published tier-assignment map and time-banded schedule; (3) the geotechnical findings on Gallatin Canyon clearance feasibility and secondary-slide risk, with revised thresholds for the 15-minute arrival and 45-minute diversion rules; (4) results of the contraflow terminus and supply-convoy exercises, with any required revisions to the exit split or routing strategy; (5) draft MOUs from hub emergency managers and utility operators confirming resource and logistics commitments; (6) the Corridor Capacity Operations Center design and integration with state traffic management; (7) updates from USGS on Scenario Beta population estimates and revised evacuation-ring geometry if applicable. Schedule a multi-state command-authority exercise by Month -1.5 (2026-08-29) testing the boundary handoff under escalation scenarios, and document any jurisdictional conflicts or communication gaps to be resolved by Month -1 (2026-09-14)."

## 3.4.A Issue - Contraflow Termini and Gateway Bottleneck Design Lacks Concrete Staging Geometry

The plan specifies three exits (West US-20/US-191, North US-89, East US-14/16/20) and a 50/30/20% split but provides no termini design: where do contraflow lanes end? How many turn pockets at Mammoth, Gardiner, West Yellowstone? What is the queuing buffer at each gate before vehicles are staged? Gallatin Canyon is cited as a blockage risk, but no capacity analysis shows whether the canyon itself is the bottleneck or the staging lot upstream. Without termini geometry, you cannot verify that 660 vehicles/hour per exit is achievable, and you risk gridlock at the staging lot rather than the road.

### 3.4.B Tags

- contraflow-termini
- capacity-analysis
- staging-geometry
- bottleneck-unverified

### 3.4.C Mitigation

Commission a rapid-deployment engineer from USGS or state DOT to conduct a one-day site survey at each terminus (Mammoth, Gardiner staging, West Yellowstone staging, Cody entrance area) by Month -0.5 (2026-09-29). Measure: parking-lot footprint and current capacity; distance from lot exit to the contraflow begin line; turn-pocket dimensions; queue-storage length in vehicles; and the available staging buffer. Calculate: queue-storage duration at 660 veh/h inflow; bottleneck location (lot saturation vs. road capacity). If lot-saturation occurs before road-capacity saturation, revise the split or add temporary staging overflow (parking-lot chaining, nearby school parking). If the canyon itself is the bottleneck, model bypass or single-lane recovery protocols.

### 3.4.D Consequence

Without termini geometry validation, the plan assumes 660 veh/h is possible but may discover at T+2 h that the staging lot holds only 400 vehicles, causing queues to back up into the park interior, preventing the T+6 h clearance gate and stranding 2,000–5,000 vehicles inside the park when ash arrives. Gridlock at a terminus costs 3–6 hours of delay and invalidates the entire evacuation schedule.

### 3.4.E Root Cause

The plan adopts the three-exit split as a strategic decision but skips the tactical engineering step: measuring existing lot capacity, turn-radius constraints and queue storage. Contraflow design cannot proceed without this baseline. The 660 vehicles/hour throughput is stated as an average (estimate) but not validated against the physical termini.

## 3.5.A Issue - Geotechnical Road Hazard Clearance Strategy Assumes Optimistic Single-Team Timelines Without Empirical Basis

The plan pre-positions 'at least 2 tow/rockfall teams' to reach Gallatin Canyon within 15 minutes and sets a 45-minute blockage threshold before diversion. But the plan provides no geotechnical reconnaissance data: How unstable is Gallatin Canyon during a seismic swarm? What is the probability of a secondary slide during clearance? How long does single-lane debris removal actually take under ashfall conditions? The South Entrance landslide is ''written off'' with a 4-hour time-box, but no survey exists to quantify the debris volume or confirm that a bypass is feasible. Without empirical data, the 15-minute arrival and 45-minute diversion thresholds are guesses that may be impossible to meet.

### 3.5.B Tags

- geotechnical-hazard
- road-blockage-timeline
- secondary-slide-risk
- South-Entrance-writeoff

### 3.5.C Mitigation

Assign a structural geotechnical engineer from the USGS Volcano Disaster Assistance Program to conduct a rapid survey of Gallatin Canyon (10 km of highest-risk sections) and the South Entrance slide 60 days before T+0 (Month -1.5, 2026-08-29). Deliverables: (1) geotechnical log and slope-stability assessment under seismic-swarm conditions; (2) estimated debris-removal time per 10 m of blockage in wet and dry conditions; (3) secondary-slide probability during clearance; (4) a ranked list of safe turn-out and crew-staging zones; (5) South Entrance bypass feasibility or single-lane clearance volumetric estimate. Based on the survey, revise the 15-minute arrival and 45-minute diversion thresholds to match actual conditions. If secondary-slide risk exceeds 20% during work, write off Gallatin Canyon clearance and commit all load to the northern and eastern exits. Pre-position monitoring drones and motion sensors at incipient-failure zones with real-time alerts to crews.

### 3.5.D Consequence

If a rockfall clears in 30 minutes under ideal conditions but the plan assumes 45 minutes, the real throughput is higher and the diversion threshold is wasted conservatism. Conversely, if debris removal takes 90 minutes in ashfall with reduced visibility and equipment clogging, the 45-minute threshold fires too early, diverting traffic unnecessarily. Worse, if crews clear the first blockage but a secondary slide occurs during clearance, crews and equipment are lost, and the corridor remains closed for 6–12 hours while recovery machinery is mobilized. The plan's diversion rule then cascades 3,000–6,000 vehicles to the remaining exits, triggering the 2–4 hour delay that breaks the T+6 h gate.

### 3.5.E Root Cause

The plan specifies response actions (pre-position teams, 45-min threshold, tow assets) but does not ground them in geotechnical data. Contraflow under active seismic conditions is hazardous; crews working on unstable slopes during a magma-ascent swarm face a cumulative risk of entrapment or secondary slides that is not quantified. The plan treats Gallatin Canyon and the South Entrance as static blockage scenarios, not as dynamic hazard zones where the ground may fail again during clearance work.

## 3.6.A Issue - Scenario Beta 500 km Ring Capacity Gap and Unquantified External Population Create Cascade-Failure Risk at T+12 h Decision Point

The plan pre-authorizes a 500 km Scenario Beta evacuation order but names only two provisional hubs (Denver, Cheyenne) without verifying distances or capacities. The canonical facts note that ''millions of people'' lie in the 500 km ring, not quantified. When the Beta trigger fires at T+12 h (proposed), the UC will issue an evacuation order for an unquantified population with no published destinations, causing uncontrolled shadow evacuation from outer-zone residents (Bozeman, Billings, Idaho Falls) who will flee without waiting for assignments. This uncontrolled flight saturates I-15, I-80 and I-90 before the primary 35,800 Zone Zero evacuees clear, adding 4–8 hours to their transit and stranding them in ash for extended periods. The plan offers no queue-management strategy, no pre-positioned supply caches on the I-15/I-80/I-90 corridor outside the ash zone, and no time-banded execution that separates organized from shadow evacuation.

### 3.6.B Tags

- Scenario-Beta-capacity
- shadow-evacuation
- population-unquantified
- hub-distance-unverified
- cascade-failure

### 3.6.C Mitigation

Before Month 0 (2026-10-14) (by 2026-10-14), commission a rapid census and capacity study: (1) quantify the population in each ring (0–100 km, 100–250 km, 250–500 km) down to county or community level, breaking out families, vehicle-less, and special-needs; (2) verify distances from the Yellowstone center to Denver, Cheyenne, Billings and any other candidate hub; (3) contact each hub's emergency management and shelter operators, obtaining written capacity estimates for 24-hour occupancy and 10-day sustained operations. (4) Develop a written Scenario Beta execution plan with three ring-based phases: immediate organized evacuation for Zone One (0–100 km, managed like Phase 2); time-banded evacuation for 100–250 km (assigned departure windows by county, released on published schedule); and staged departure for 250–500 km (self-evacuated, self-supplied, no shelter assignment). (5) Obtain signed MOUs from hub counties and facility operators confirming bed capacity and supply commitment. (6) Issue a public-facing ''Scenario Beta Tier System'' document (pre-event, published by Month 0 = 2026-10-14 start date) that names the hubs, specifies which zip codes are in each tier, and explains the time-banded schedule, so outer-zone residents know not to flee at T+12 h but to wait for their assigned window. (7) Pre-position 30 days before T+0 a 20,000-person emergency supply cache (water, food, N95, fuel, medical) at an intermediate location on I-80 or I-90 outside the ash footprint, accessible to any stranded outer-zone evacuees who do flee early.

### 3.6.D Consequence

If the Scenario Beta trigger fires at T+12 h with no hub destinations or time-banded schedule published, uncontrolled outer-zone evacuation begins immediately. An estimated 50,000–200,000 additional people (estimate) begin driving toward Salt Lake City, Denver and Cheyenne without assignments, saturating I-15 northbound and I-80 eastbound by T+14 h. The concurrent Zone Zero evacuees, still exiting through US-191 and I-90 toward Bozeman and Livingston, are forced to queue behind outer-zone traffic. Zone One residents (Gardiner, West Yellowstone, Cody) exit at T+6–T+24 h, finding I-90 and I-15 clogged with unmanaged outer-zone vehicles. The net effect: Zone Zero clearance slips from T+6 h target to T+10–T+12 h, Zone One clearance slips from T+24 h to T+30–T+36 h. Up to 5,000–10,000 Zone Zero and Zone One evacuees remain sheltered in areas expecting ashfall at T+8–T+16 h, and respiratory-injury rates spike by 20–50% due to extended exposure.

### 3.6.E Root Cause

The plan treats Scenario Beta as a binary decision (trigger fires, UC orders 500 km evacuation) but defers all second-stage execution planning to Month 1 (2026-11-14), after T+0 has begun. At T+12 h, when the trigger is expected to fire, the plan has no specific destinations, no capacity commitments, and no time-banded evacuation schedule published to the public. Uncontrolled flight is then inevitable, and the primary Zone Zero clearance fails because the corridors are clogged by unmanaged outer-zone residents.

---

# 4 Expert: Supply Chain & Logistical Resilience Strategist

**Knowledge**: supply-chain mapping, procurement lead times, fuel and water logistics, forward-depot siting, ashfall supply-chain disruption, FEMA contract vehicle activation

**Why**: The Ashfall Life-Support Supply decision and canonical facts require water delivery to shelters by T+24h but cite T+18–30h arrival time as an estimate, with forward depots and FEMA surge clauses as mitigation. The responder exposure limits assume a 30–50 person standby reserve by T+0.5, and the 100,000 civilian N95 stock lacks a replacement-cycle plan if consumption exceeds 20% per day. This expert must close the procurement timeline and size the pre-positioned supplies to make the T+24h water delivery and responder relief credible.

**What**: Map the complete water, fuel and N95 supply chain from T+0 to T+72h (source → forward depot → shelter), quantifying dispatch-to-arrival time under ashfall road congestion; size forward depots at Bozeman, Billings and Idaho Falls to deliver the 1.43 million liter water target by T+24h; develop a tiered responder N95 replacement protocol (consumption threshold, backup source, 48-hour resupply cycle) and secure written 12-hour dispatch commitments from Salt Lake City and regional distributors by Month 0 (2026-10-14).

**Skills**: supply-chain mapping and lead-time analysis, logistics network optimization, ashfall supply-chain contingency, FEMA contract vehicle leverage, forward-depot operations, fuel/water distribution

**Search**: FEMA logistics coordinator disaster supply chain, water convoys emergency operations, forward depot siting N95 PPE, Stafford Act procurement acceleration

## 4.1 Primary Actions

- By Month -2 (2026-08-14): Complete a written Scenario Beta Secondary-Stage Evacuation Plan naming five to ten ranked hubs outside the 500 km ring, with signed MOUs from host counties confirming capacity and pre-positioned supplies for 100,000–500,000 additional evacuees. Issue interim ranked hub list by T+12 hours.
- By Month -1 (2026-09-14): Issue a written Responder Exposure and Relief Protocol specifying 6-hour shifts, 2-hour rest cycles, and full withdrawal after 18 hours. Pre-position a 30–50 person standby reserve at Billings or Cheyenne. Secure pre-event Guard reinforcement commitments. Size and pre-stage separate responder N95 inventory (150,000–200,000 additional).
- By Month -0.5 (2026-09-29): Deploy PM10/PM2.5 sensors at Bozeman, Idaho Falls and the forward command. Develop and pre-authorize three-shelter backup system for each primary site with 4-hour activation protocols. Pre-stage supplemental 100,000 N95 masks at Billings or Salt Lake City.
- By T+6 hours: Confirm verbal authorization from MT, WY and ID governors for Zone One and Scenario Beta orders. Perform a backcountry sweep and issue the T+6 hour gate assessment (at least 98% of 35,800 confirmed out).
- By T+12 hours: Issue interim Scenario Beta ranked hub list. Dispatch water and N95 convoys from Salt Lake City. Activate PM10 monitoring at all shelters and the forward command. Install real-time ashfall forecast update protocols.

## 4.2 Secondary Actions

- Conduct a full-scale Scenario Beta messaging and routing exercise by Month 3 (2027-01-14), testing bus-fleet dispatch, shelter intake, and lateral-route traffic under congestion from secondary hubs.
- Conduct a responder shift-rotation exercise at Mammoth or Gardiner checkpoint 30 days before the window (Month -0.5, 2026-09-29 08:00–14:00), validating relief handoff protocols, N95 replacement and fatigue-assessment checklists.
- Conduct an air-quality monitoring and shelter-relocation exercise 30 days before the window (Month -0.5, 2026-09-29 10:00–16:00), simulating 50 km ashfall divergence and doubling of intensity, testing forecast-update and relocation-decision triggers.
- Secure written pre-event commitments from Fort Carson (Colorado National Guard) and Wyoming/Montana Guard Joint Task Force for out-of-region personnel reinforcement by Month -1 (2026-09-14), allowing forward command to request additional Guard units without state adjutant-general approval if checkpoint coverage falls below 50%.
- Execute a South Entrance geotechnical survey 60 days before the window (Month -1.5, 2026-08-29), quantifying debris volume, slope stability and secondary-slide probability, and develop a time-boxed 4-hour single-lane clearance plan with hard abort triggers (M>4.0 seismic, >2 cm slope displacement, or 30-minute equipment breakdown).
- Issue a Loss-of-Exit Contingency Protocol by Month -1 (2026-09-14), specifying that if any corridor blockage persists >45 minutes and clearance cannot be completed, the forward command will trigger diversion to the nearest surviving exit and issue IPAWS notification within 5 minutes.
- Obtain written pre-event authorization letters from the governors of Montana, Wyoming and Idaho by Month -1 (2026-09-14), confirming explicit authorization of Zone One and Scenario Beta orders and agreement to cede operational authority over park-boundary traffic to the NPS incident commander until the Unified Command issues a handoff order.

## 4.3 Follow Up Consultation

At Month 1 (2026-11-14): review completion of the written Scenario Beta plan, responder relief protocols, and ashfall monitoring infrastructure. Validate that governor MOUs and FEMA Region 10 liaison arrangements are in place. Confirm that at least 5 ranked hubs outside the 500 km ring have signed capacity commitments and pre-positioned supplies. Identify any gaps in responder standby-reserve activation authority or ashfall forecast accuracy that were not discovered during the pre-window exercises. Finalize the after-action report framework and schedule the post-Month 3 (2027-01-14) lessons-learned workshop.

## 4.4.A Issue - Scenario Beta Second-Stage Hub Plan Is Hollow Without Quantified Population and Destination Capacity

The plan pre-authorizes a Scenario Beta 500 km evacuation order but names no confirmed hubs, population estimates, or capacity commitments. Documents state millions of people at risk, but Denver and Cheyenne distances remain unverified. Without a written destination plan by T+12 hours, issuing the 500 km order will trigger uncontrolled flight saturating I-15, I-80 and I-90, adding 4–8 hours of delay to the primary Zone Zero evacuation and stranding 5,000–20,000 people in ashfall zones.

### 4.4.B Tags

- scenario-beta-planning-gap
- destination-capacity-undefined
- cascade-failure-risk
- uncontrolled-evacuation

### 4.4.C Mitigation

Execute a written Scenario Beta Secondary-Stage Evacuation Plan by Month -2 (2026-08-14), naming five to ten ranked hubs outside the 500 km ring with signed MOUs from host counties confirming bed and medical-staff capacity for 100,000–500,000 evacuees. Pre-stage water, N95 and food supplies at secondary hubs by Month -1 (2026-09-14). Issue interim ranked hub list by T+12 hours. Conduct a full-scale Scenario Beta exercise by Month 3 (2027-01-14), testing messaging, routing and shelter intake under congestion.

### 4.4.D Consequence

Without a destination plan, a pre-authorized Scenario Beta order will activate evacuation for millions of people with no published shelter addresses. Drivers will flee on their own to wherever maps suggest safety, saturating I-15 northbound and I-80 eastbound. The primary Zone Zero evacuation (35,000 park visitors) will be delayed 4–8 hours by shadow evacuation congestion. An estimated 5,000–20,000 evacuees will be stranded in moderate ashfall, increasing respiratory-injury hospitalizations by 30–50% and preventable deaths by 5–20.

### 4.4.E Root Cause

The plan conflates a pre-authorized trigger (issuing the 500 km order quickly) with an executable plan (telling evacuees where to go). The decision to pre-authorize the trigger was sound, but it was decoupled from the downstream logistics. No second-stage hub MOUs, population estimates or destination messaging were developed before Month 0 (2026-10-14), so execution is now blocked until Months 1–3 (2026-11-14 to 2027-01-14). The project start (Month 0 = 2026-10-14) was set without pre-event lead time for hub planning, forcing all hardening into post-event operations when no time remains.

## 4.5.A Issue - Responder Staffing Has Zero Relief Depth During the T+2 to T+8 Peak Evacuation

The plan budgets 100–150 NPS rangers with 1.5 relief ratio, yielding 67–100 concurrent positions across three contraflow checkpoints, perimeter gates and sweep teams during the T+2 to T+8 peak. A single traffic incident (vehicle breakdown, rockfall closure lasting 30+ minutes) at a checkpoint will consume all available coverage, halting one corridor for 2–4 hours. No separate responder N95 inventory is defined, so civilian mask depletion will deplete responder protection. No standby reserve is pre-positioned, so reinforcement will take 6–12 hours to arrive.

### 4.5.B Tags

- responder-capacity-overload
- zero-relief-depth
- single-point-failure
- staffing-bottleneck

### 4.5.C Mitigation

Issue a written Responder Exposure and Relief Protocol by Month -1 (2026-09-14), specifying max 6-hour shifts, 2-hour rest with N95 replacement, and full withdrawal after 18 hours. Pre-position a 30–50 person standby reserve from out-of-region agencies (Colorado Parks and Wildlife, Wyoming Game and Fish, Idaho Department of Lands) at a Billings or Cheyenne logistics depot by Month -0.5 (2026-09-29). Secure pre-event Guard reinforcement commitments. Size and pre-stage separate responder N95 inventory (estimated 150,000–200,000 additional to the 100,000 civilian stock). Conduct a shift-rotation exercise 30 days before the window.

### 4.5.D Consequence

Without explicit relief depth and standby reserves, all rangers will be at or beyond fatigue threshold by T+6 hours. A single 30-minute vehicle breakdown at a checkpoint during peak outflow will halt 500–2,000 vehicles because no relief operator can replace the post holder. Traffic will queue backward into the park interior or upstream highways, delaying evacuees 2–4 hours and trapping 500–2,000 people in ash-exposure zones during peak ashfall hours (T+8 to T+16 estimated). Respiratory injuries among delayed evacuees will increase 40–60%; preventable deaths from entrapment in heavy ashfall estimated 3–8.

### 4.5.E Root Cause

The responder staffing estimate was drawn from a generic evacuation baseline without accounting for the extreme conditions (ash, tremor, roadblocks, sweeps) and the compressed T+6 hour deadline. The plan did not size a separate responder N95 inventory or pre-position relief personnel outside the affected region, assuming that rangers could sustain 18–24 consecutive hours on a single shift. No relief-rotation exercise was planned before Month 0 (2026-10-14) to validate the 6-hour shift limit or discover equipment gaps.

## 4.6.A Issue - Ashfall Forecast Uncertainty of ±50 km and T+6 Hour Shelter Siting Creates Relocation Risk Mid-Operation

The plan selects final shelter sites at T+6 hours using a single NOAA/USGS plume forecast. Ashfall from a VEI-6 event has never been directly observed in North America; forecast uncertainty is estimated at ±50 km or more. A 50 km southward shift or doubling of ashfall intensity could place Bozeman or Idaho Falls shelters in moderate-to-heavy ash (>100 µg/m³ PM10). No real-time PM10 monitoring is planned at shelters; no relocation protocols exist. At T+24 hours or later, 10,000–15,000 evacuees would require emergency relocation, consuming responder hours needed to sustain shelter operations or prevent looting.

### 4.6.B Tags

- ashfall-forecast-uncertainty
- shelter-relocation-risk
- mid-operation-cascading-failure
- monitoring-gap

### 4.6.C Mitigation

Deploy continuous PM10/PM2.5 sensors and ash-depth measurement at Bozeman, Idaho Falls and the forward command by Month -0.5 (2026-09-29), with hourly data feeds and alert thresholds (>50 µg/m³ triggers forecast update; >100 µg/m³ triggers shelter-suitability review). Develop and pre-authorize a ranked three-shelter backup system for each primary site by Month -1 (2026-09-14), with locations 50+ km upwind and 4-hour activation protocols. Pre-stage supplemental 100,000 N95 masks at Billings or Salt Lake City. Conduct an air-quality and shelter-relocation exercise 30 days before the window.

### 4.6.D Consequence

If actual ashfall differs from forecast by 50 km or exceeds intensity estimates by 2–3x, shelters will accumulate heavy ash after T+12 hours. At T+18–24 hours, evacuees will experience respiratory distress and demand relocation. Without pre-authorized backup sites and relocation protocols, shelter operators will face uncontrolled departures and uncoordinated movement to uncertain destinations. An estimated 200–500 evacuees will be stranded in moderate-to-heavy ash during relocation (48–72 hour exposure), increasing hospitalization for respiratory distress by 50–100% and preventable deaths by 5–15.

### 4.6.E Root Cause

The plan assumes that a T+6 hour forecast is reliable enough to siting decisions that will hold for 96+ hours of evacuation and shelter operations. Volcanic ashfall is a low-probability, high-uncertainty phenomenon; no North American precedent exists for VEI-6 ashfall plume forecasting accuracy. The plan did not allocate real-time PM10 monitoring or relocation protocols, treating shelter sites as fixed once selected. This underestimates both forecast error and the need for adaptive management during the operation.

---

# 5 Expert: Public Health & Mass-Casualty Medical Logistics Director

**Knowledge**: respiratory disease epidemiology, field triage systems, mass-casualty shelter protocols, hospital surge capacity, ashfall health impacts, emergency medical supply chain

**Why**: The Hospital Surge Dispersal decision and canonical facts cite respiratory distress cases and pre-staging N95s for 100,000 civilians, yet the plan names only three receiving hospitals and lacks a clinical surge protocol for the 10,000–20,000 additional respiratory cases (estimate) expected by T+24h. This expert must size hospital surge, validate the N95 consumption model, and certify that field triage and transfer protocols prevent hospital collapse during peak ashfall.

**What**: Design a hospital surge-capacity matrix for Bozeman, Livingston and Idaho Falls, quantifying bed availability by acuity tier and respiratory-case routing; validate the 100,000 N95 replacement-cycle plan against observed ashfall respiratory-case loads; produce a field-triage algorithm for shelter intake that identifies cases requiring hospital transport within 2 hours of arrival, and establish a mutual-aid protocol for transferring overflowing respiratory patients to Denver and Salt Lake City facilities by helicopter or ground ambulance.

**Skills**: epidemiologic modeling of ashfall health impacts, emergency-department surge protocols, respiratory-protection effectiveness validation, field-triage algorithm design, medical-supply consumption forecasting, inter-hospital patient-transfer logistics

**Search**: mass casualty surge capacity hospital, ashfall respiratory disease outbreak response, emergency medical triage field protocol, volcanic ash health impact epidemiology

## 5.1 Primary Actions

- Immediately contact Denver, Cheyenne, Rapid City and Casper emergency management directors to confirm written acceptance of Beta-phase evacuees, obtain capacity estimates, and request signed MOUs by Month 1 (2026-11-14) specifying shelter beds, medical staffing and supply pre-positioning.
- Define a separate responder N95 inventory (recommend 150,000–200,000 units) and execute a written Responder Exposure and Relief Protocol by Month -1 (2026-09-14) specifying 6-hour shift limits, 2-hour rest with N95 replacement, full withdrawal after 18 hours, and relief-rotation checklists.
- Pre-position a 30–50 person out-of-region responder reserve at Billings or Cheyenne by Month -0.5 (2026-09-29) with pre-authorized 4-hour deployment authority if any checkpoint coverage falls below 50%; secure written commitments from Colorado Parks and Wildlife, Wyoming Game and Fish and Idaho Department of Lands.
- Deploy real-time PM10/PM2.5 sensors and visual ash-depth stations at the forward command, Bozeman and Idaho Falls by Month -0.5 (2026-09-29), with automated hourly feeds to USGS/NOAA and alert thresholds (50 µg/m³ = forecast update; 100 µg/m³ = shelter-suitability review).
- Identify and pre-authorize ranked backup shelter sites 50+ km upwind of each primary site by Month -1 (2026-09-14), confirmed daily from wind forecast, with written 4-hour relocation protocols and bus-dispatch procedures for moving up to 15,000 evacuees per shelter.
- Stage a 100,000-unit supplemental N95 reserve at Billings Regional Medical Center or Salt Lake City hub by Month -0.5 (2026-09-29), with standing 24-hour transport agreement (ground convoy or helicopter) ensuring delivery within 8 hours if primary-shelter consumption exceeds 20% of stock per day.
- Conduct three full-scale exercises by Month 3 (2027-01-14): (a) Beta scenario routing and hub intake with sample bus dispatch from Bozeman/Idaho Falls to Denver/Cheyenne (Month -0.5 2026-09-29); (b) responder shift rotation and N95 replacement at Mammoth checkpoint under ash simulation (Month -0.5 2026-09-29); (c) shelter-relocation decision and execution simulating 50 km ashfall forecast error (Month -0.5 2026-09-29).

## 5.2 Secondary Actions

- Conduct a geotechnical survey of Gallatin Canyon and US-89 near Gardiner (Month -1.5 2026-08-29) to map slide-prone zones and develop time-boxed (maximum 4-hour) single-lane clearance plans with hard abort triggers (M>4.0 seismic event, >2 cm slope displacement, or 30-minute equipment breakdown).
- Establish a Boundary Coordination Officer position at the forward element (Livingston or Bozeman) with 24/7 voice and satellite links to NPS incident commander, three state on-scene commanders and Denver RRCC by Month -0.5 (2026-09-29); issue a written protocol authorizing reroute and shelter-assignment decisions without supervisory approval if communication is lost >5 minutes.
- Deploy Guard signal teams with satellite phones, portable repeaters and generator fuel to each traffic-control point and the forward element by Month -0.5 (2026-09-29); conduct radio interoperability testing across all agencies (NPS, highway patrol, National Guard, FEMA) on Month -0.5 (2026-09-29) to confirm frequency coordination and call signs.
- Pre-produce IPAWS, WEA, NOAA Weather Radio and HAR broadcasts in English and five visitor languages (Spanish, Japanese, German, Mandarin, French) by Month -1 (2026-09-14), with cognitive testing by native speakers (3–5 per language by Month -1.5 2026-08-29) and immediate activation authority at T+0.
- Obtain written pre-event authorization letters from Montana, Wyoming and Idaho governors confirming their approval of Unified Command Zone One and Scenario Beta orders by Month -1 (2026-09-14); execute MOUs with state DOTs and highway patrol defining authority transfer checkpoints and mutual-aid protocols by Month -1 (2026-09-14).
- Establish a 24/7 utility-operations coordination hotline from the forward command to Montana-Dakota Utilities, Pacific Power and Idaho Power by Month -1 (2026-09-14); pre-position mobile generator units and voltage-regulation equipment at the two largest substations (Bozeman and Idaho Falls area) by Month -0.5 (2026-09-29).
- Pre-position 72-hour diesel and propane reserves at Bozeman Deaconess, Livingston HealthCare and Eastern Idaho Regional Medical Center (Idaho Falls) by Month -0.5 (2026-09-29); establish written fuel-delivery contracts with local vendors requiring priority dispatch within 2 hours of request during the event.
- Conduct hospital-power-failure exercises at each of the three receiving hospitals on Month -0.5 (2026-09-29) testing manual generator startup, fuel-transfer mechanics under ash contamination, backup surgical protocols for 4+ hour loss, and staff fatigue management during power outage.

## 5.3 Follow Up Consultation

In the next consultation, confirm: (1) signed acceptance letters and capacity commitments from Denver, Cheyenne and backup hubs by Month 1 (2026-11-14); (2) completion of responder staffing, N95 sizing and relief-reserve pre-positioning by Month -0.5 (2026-09-29); (3) real-time ash monitoring installation and backup-shelter identification by Month -0.5 (2026-09-29); (4) results of three full-scale exercises (Beta routing, shift rotation, shelter relocation) conducted by Month -0.5 (2026-09-29). Discuss any shortfalls in hub validation, responder depth or monitoring deployment as blockers to T+0 activation. Review after-action reports from exercises to identify operational gaps in boundary coordination, fuel logistics and shelter-intake protocols. Establish metrics for Months 1–3 (2026-11-14 to 2027-01-14) to track MOU completion, final Beta plan signing and multi-state command-authority exercise results.

## 5.4.A Issue - Scenario Beta second-stage hub destinations are named but unvalidated; no capacity, distance or survivability data exists.

The plan states Denver and Cheyenne as Beta destinations outside the 500 km ring, but provides no written confirmation that these cities accept evacuees, have shelter capacity for 100,000–500,000 additional people, or lie outside the ashfall footprint. Distance to both hubs from Yellowstone is not verified. Without signed MOUs and pre-positioned supplies at each hub, a pre-authorized VEI-7 trigger that activates a 500 km order will release hundreds of thousands of people onto I-15, I-80 and I-90 with published destinations that may not have accepted them. This invalidates the trigger itself.

### 5.4.B Tags

- scenario_beta_execution_gap
- hub_validation_missing
- mou_unsigned
- unquantified_population

### 5.4.C Mitigation

By Month -0.5 (2026-09-29): confirm written acceptance letters from Denver and Cheyenne city and county governments; measure distances; model ashfall at each hub using the USGS plume forecast. By Month 1 (2026-11-14): execute signed MOUs with each hub naming shelter capacity, medical-staff commitments and supply pre-positioning. Identify at least one additional ranked hub outside the ring (e.g., Rapid City, SD or Casper, WY) as backup. Conduct a tabletop exercise with all hubs to confirm routing and intake protocols.

### 5.4.D Consequence

Without validated hubs, the pre-authorized Beta trigger becomes an unfulfillable order. Evacuees will be directed to destinations that do not expect them, creating bottlenecks at interstates and exposing 100,000–500,000 people to unmanaged ashfall. Shadow evacuation will saturate I-90 and I-15, stranding the primary 35,800 Zone Zero evacuees for 4–8 additional hours and preventing hospital patient transfers. 5–20 preventable deaths will result from respiratory distress and delayed medical care.

### 5.4.E Root Cause

The documents name Beta hubs as examples ('e.g., Denver, Cheyenne') without conducting the validation work (distance, capacity, acceptance, ashfall risk) needed to turn naming into authorization. The plan assumes that pre-authorization of the trigger is independent of destination readiness, when in fact they are tightly coupled: a trigger without destinations is operationally meaningless.

## 5.5.A Issue - Responder staffing depth is inadequate and N95 inventory for responders is unsized; a single injury or checkpoint failure cascades into 2–4 hour evacuation delays.

The plan budgets 100–150 NPS rangers with a 1.5 relief ratio, yielding 67–100 concurrent positions across three corridors. During the T+2 to T+8 evacuation peak (when traffic is heaviest), all positions are consumed; no contingency exists if a ranger is injured, exposed to respiratory hazard or overwhelmed at a single checkpoint. Responder N95 respirators are not counted separately from the 100,000 civilian stock, so replacement protocols during the 6-hour shift limit are undefined. A vehicle breakdown or rockfall at Gallatin Canyon during peak flow—which would normally be managed by rotating a fresh team—instead halts traffic for 2–4 hours.

### 5.5.B Tags

- responder_staffing_gap
- n95_inventory_unsized
- relief_depth_zero
- single_point_failure

### 5.5.C Mitigation

By Month -1 (2026-09-14): count responder N95 needs separately (recommend 150,000–200,000 total for responders alone based on typical use rates). Define a 6-hour shift limit with 2-hour rest and N95 replacement. By Month -0.5 (2026-09-29): pre-position a 30–50 person standby reserve from Colorado Parks and Wildlife, Wyoming Game and Fish and Idaho Department of Lands at a Billings or Cheyenne depot. Issue pre-authorization for the forward command to deploy this reserve within 4 hours if any primary checkpoint coverage falls below 50%. Conduct a shift-rotation exercise at Mammoth 30 days before the window.

### 5.5.D Consequence

Without relief depth, a single injury, respiratory exposure or equipment failure at a critical checkpoint halts traffic for 2–4 hours, stranding 500–2,000 vehicles in ash-exposed zones. Cumulative delay cascades: a 2-hour halt at Gallatin Canyon at T+3 hour pushes the T+6 gate closure back to T+8–10 hours, leaving 500–1,000 vehicles in the park during peak ashfall. Respiratory injury rates among responders rise 30–50%, and 5–10 preventable deaths occur due to delayed medical care for evacuees.

### 5.5.E Root Cause

The documents estimate responder headcount but do not model coverage loss from injury, exposure or fatigue during peak operations. They assume 100–150 rangers can staff three corridors simultaneously at 2,000 vehicles/hour without discussing what happens when a checkpoint is unmanned. Responder N95 sizing is conflated with the civilian 100,000-unit requirement, obscuring the true supply need.

## 5.6.A Issue - Ashfall forecast uncertainty of ±50 km and shelter sites chosen at T+6 hours with no real-time monitoring create risk of placing 10,000–15,000 evacuees in heavy ash; relocation protocols are absent.

The plan selects final shelter locations at T+6 hours based on a single NOAA/USGS plume forecast update. Ashfall forecasts for a VEI-6 eruption carry uncertainty of ±50 km or more; a wind-shift or forecast error could place Bozeman or Idaho Falls directly in the ashfall plume despite being selected as 'safe' sites. The plan stocks 100,000 N95 respirators for 35,800 people (2.8 masks per person for ~10 days); masks clog in heavy ash and require frequent replacement. No real-time ash-depth monitoring is mentioned, and relocation procedures for 10,000–15,000 evacuees mid-operation are not detailed. If shelter sites are rendered untenable by ashfall, evacuees cannot be relocated within the time window without consuming all available buses and adding 6–12 hours to transit.

### 5.6.B Tags

- forecast_uncertainty
- shelter_siting_risk
- n95_adequacy_unknown
- relocation_protocol_missing

### 5.6.C Mitigation

By Month -0.5 (2026-09-29): deploy PM10/PM2.5 sensors at the forward command, Bozeman and Idaho Falls, with automated hourly feeds to USGS/NOAA. Set alert thresholds: >50 µg/m³ PM10 triggers forecast update; >100 µg/m³ triggers shelter-suitability review. Identify ranked backup shelter sites 50+ km upwind of each primary site, confirmed daily from the 00:00 UTC wind forecast. Pre-authorize 4-hour relocation procedures with bus and registration protocols. Stage a 100,000-unit supplemental N95 reserve at Billings. Conduct a shelter-relocation exercise 30 days before the window simulating a 50 km forecast error.

### 5.6.D Consequence

If actual ashfall diverges from forecast by 50+ km or doubles in intensity, primary shelters at Bozeman or Idaho Falls will become untenable within 12–24 hours of occupancy. Evacuees will experience respiratory distress, requiring medical intervention. Relocation of 10,000–15,000 people without pre-authorized backup sites and protocols will consume 8–12 hours and require diverting buses from other tasks, stranding 200–500 evacuees who cannot be moved. 10–30 preventable respiratory deaths will result from prolonged ash exposure during the gap.

### 5.6.E Root Cause

The documents assume ashfall forecasts are accurate enough for shelter siting but do not quantify forecast uncertainty or assign responsibility for monitoring actual conditions post-occupancy. They treat shelter selection as a one-time decision at T+6 hours rather than an ongoing adaptive process. The 100,000 N95 stock is pre-staged without calculating replacement cycles under different ashfall intensities.

---

# 6 Expert: Critical Infrastructure & Grid Resilience Engineer

**Knowledge**: electrical transmission systems, cascading blackout prevention, generator fuel logistics, emergency load shedding, telecommunications tower ash contamination, water-system contamination protocols

**Why**: The Ashfall Life-Support Supply decision and canonical facts specify 72-hour fuel reserves at hospitals and comms centers and a utility-operations coordination hotline, yet the plan does not quantify transmission-line flashover risk, backup-generator fuel consumption under continuous operation, or the cascading grid failure that could isolate shelters and hospitals from water and power within 4–8 hours if ash-induced outages occur faster than convoys arrive. This expert must harden the grid and utility plan to keep hospitals and comms functional through T+72h.

**What**: Model the transmission-line flashover probability under ashfall ash-conductivity conditions on the four critical substations serving Bozeman, Livingston and Idaho Falls; calculate 72-hour generator fuel consumption at continuous operation and recommend pre-positioned fuel tank sizes and resupply frequency; design an emergency load-shedding protocol for each utility that prioritizes hospitals and comms centers and specifies which neighborhoods or districts will be de-energized if cascading failure threatens a regional blackout; certify that each receiving hospital's backup-water supply (stored or on-site well) survives a simultaneous loss of grid power and incoming municipal water pressure for 8 hours.

**Skills**: power-systems modeling and cascading-failure analysis, generator fuel-consumption engineering, electrical transmission-line ashfall interaction, emergency load-shedding protocols, water-system backup design, utility coordination under emergency operations

**Search**: volcanic ashfall power grid transmission line flashover, cascading blackout prevention emergency, generator fuel consumption continuous operation, hospital water supply backup power loss

## 6.1 Primary Actions

- Engage a power-systems engineer (WECC or regional utility) by Month -1.5 (2026-08-29) to model transmission-line flashover probability vs. ashfall conductivity (100–500 µm/kg on 115–500 kV lines), identify critical load-shedding 'islands' preserving comms/hospitals/shelters, and pre-authorize emergency brownout procedures at Hour 4–6 of ashfall; test load-shedding sequences at a Bozeman or Livingston substation 30 days before T+0 under ash-simulation conditions.
- Develop a hospital fuel-consumption model by Month -1 (2026-09-14): calculate generator full-load consumption (20–30 gal/hour per facility), verify tank sizing for expected ashfall-duration outages (12–48 hours power loss), and pre-position two tankers (500 gallons each minimum) at each of the three receiving hospitals by T+0, with 4-hour dispatch agreements from three backup suppliers and ashfall-dust filter protocols documented.
- Validate water-supply chains by Month -1 (2026-09-14): (1) assess municipal-water contamination response (settling, filtration, turbidity thresholds) at Bozeman and Idaho Falls water districts, (2) pre-stage 200,000–300,000 liters bottled water at forward depots (Bozeman, Idaho Falls) by T+0 (not dispatch from Salt Lake City), (3) model realistic convoy travel time under ashfall conditions (18–30 hours, not 12 hours) and contract for Hour 18–24 arrival, (4) arrange groundwater tanker-fill backup at Bozeman and Livingston with pre-tested interfaces, (5) test convoy timing under simulated ashfall 30 days before T+0.
- Secure pre-event authorization letters from Montana, Wyoming and Idaho governors by Month -1.5 (2026-08-29) explicitly naming UC authority over Zone One and Scenario Beta orders, state enforcement of unified messaging, and NPS operational command at park boundaries; obtain written MOUs confirming state mutual-aid and resource-request protocols with 4-hour dispatch commitments for fuel, water and Guard reinforcement.
- Define responder exposure limits and pre-position relief depth by Month -1 (2026-09-14): issue a written protocol specifying 6-hour maximum shifts at ash-exposed posts, 2-hour rest with N95 replacement, 18-hour full withdrawal; pre-position 30–50 out-of-region traffic-control responders and request standby Guard units; size responder N95 stock separately from the 100,000-unit civilian constraint; test shift-rotation protocols 30 days before T+0.

## 6.2 Secondary Actions

- By Month -1.5 (2026-08-29), conduct a South Entrance geotechnical survey using ground-penetrating radar and aerial drones to quantify debris volume and secondary-slide probability; develop a time-boxed (≤4 hour) single-lane clearance plan with hard abort triggers (M>4.0 seismic swarm, >2 cm slope displacement, or 30-minute equipment breakdown).
- Pre-stage two mobile heavy-equipment teams (wreckers, debris chippers, geotechnical drones, 72-hour fuel) at Mammoth or Spanish Creek by Month -0.5 (2026-09-29 06:00), with pre-authorized dispatch authority reaching any Gallatin Canyon blockage within 15 minutes; survey and mark temporary bypass routes by Month -1 (2026-09-14).
- Install live geotechnical monitoring (motion sensors or slope-displacement drones) along Gallatin Canyon and US-89 near Gardiner by Month -0.5 (2026-09-29 12:00), with automatic alerts to forward command if displacement exceeds 2 cm/hour, and pre-authorize 15-minute temporary traffic halts to evacuate vehicles if alerts trigger.
- Deploy PM10/PM2.5 sensors and visual ash-depth measurement stations at Bozeman, Idaho Falls and the forward command element by Month -0.5 (2026-09-29 14:00), with hourly data feeds and alert thresholds (>50 µg/m³ PM10 triggers forecast update; >100 µg/m³ triggers shelter-suitability review); develop ranked three-shelter backup system for each primary site with 50+ km upwind locations.
- Execute a 6-hour shift-rotation exercise at Mammoth or Gardiner checkpoint 30 days before T+0, testing relief handoff protocols, N95 replacement, fatigue-assessment checklists and radio continuity under simulated ashfall; test hospital-power-failure scenarios at receiving hospitals (manual generator startup, fuel-transfer mechanics, backup surgical protocols).
- Arrange formal FEMA Region 10 coordination by Month -1.5 (2026-08-29), with Idaho mutual-aid MOUs pre-authorized for 100,000+ gallons bottled water, 50,000 gallons diesel fuel and 50 portable generators on 6-hour notice; contract with suppliers (Basin Fuel, Yellowstone Energy) for 4-hour dispatch commitments and pre-position fuel tankers at hospitals by T+0.
- Develop and pre-authorize a Scenario Beta secondary-stage evacuation plan by Month -1 (2026-09-14): name five to ten ranked shelter hubs (Denver, Cheyenne, outside the 500 km ring) with capacity estimates and signed MOUs; pre-stage food, water and medical supplies (50,000–100,000 additional meals, 500,000–1,000,000 liters bottled water, 50,000 additional N95 masks) at each hub by Month -1 (2026-09-14); conduct full-scale Scenario Beta exercise 30 days before T+0.

## 6.3 Follow Up Consultation

"In the next consultation, address: (1) transmission-system load-shedding topology and critical-path sequence to preserve grid coherency during ashfall (relay-coordination and protective-device settings); (2) hospital fuel-consumption engineering and generator-load profiles under sustained ashfall conditions, including refrigeration, HVAC and surgical-suite demand curves; (3) water-system contamination response timelines, turbidity thresholds and backup groundwater activation protocols for Bozeman and Idaho Falls municipal systems; (4) realistic convoy routing and travel-time modeling under ashfall visibility reduction (50–100 meter sight distance) and evacuation-traffic saturation (25–40% I-15 congestion by Hour 8–12); (5) responder respiratory-protection protocols and separate N95 stock sizing from civilian allocation; (6) Scenario Beta secondary-stage destination capacity and financing ownership (federal vs. state/local/host); (7) escalation triggers for grid emergency load shedding and hospital backup-generator activation timelines relative to ashfall-onset modeling."


## 6.4.A Issue - Generator Fuel Logistics Absence Masks Cascading Power-Failure Risk

The plan names fuel as a 'tier-one priority' for hospitals and comms centers but provides no fuel-consumption model, pre-positioning schedule or tanker-dispatch protocol. A VEI-6 ashfall will trigger simultaneous transmission-line flashovers and equipment damage at multiple substations within 4–8 hours, faster than fuel convoys from Rock Springs, WY (200+ miles) can deliver. Hospital generators consume 20–30 gallons per hour at full load; a 4-hour outage drains 80–120 gallons per facility. The plan pre-stages '72-hour reserves' but does not specify tank capacity, refill frequency, ashfall-dust contamination protocols or backup-supplier naming. Without explicit fuel-consumption engineering and a tanker-positioned-at-dock commitment by T+0, hospitals will exhaust reserves by Hour 20–28, forcing critical-care evacuation or preventable deaths.

### 6.4.B Tags

- generator-fuel-logistics
- hospital-power-resilience
- cascading-blackout-prevention
- supply-chain-engineering

### 6.4.C Mitigation

By Month -1 (2026-09-14): (1) Model hospital generator full-load consumption (20–30 gal/h), calculate ashfall-duration scenarios (12–48 h power loss), and size tank capacity as (peak consumption) × (expected outage hours) + 20% safety margin. (2) Contract with three suppliers (basin, billings, rock springs) with pre-authorized 4-hour dispatch and backup naming. (3) Arrange two pre-positioned tankers at each hospital by T+0, with refill triggers at 50% tank capacity and ashfall-dust filter protocols documented. (4) Pre-stage 500-gallon backup generator at Livingston hospital (estimate) as the forward-command lifeline. Test refueling under ash contamination 30 days before T+0.

### 6.4.D Consequence

Without fuel-consumption engineering and tanker pre-positioning, hospital generators fail at Hour 20–28, forcing: (1) critical-care evacuation under ashfall (5–20 preventable deaths estimated), (2) surgical-suite shutdown (10–20 cancelled procedures), (3) ventilator-dependent patient loss during manual-bagging transition (2–5 deaths), (4) forward-command comms loss if Livingston generator fails. Cascade: responder fatigue increases 40% without comms; reroute delays spike to 2–4 hours per incident; total evacuation delay: +4–8 hours, stranding 500–2,000 vehicles in ash.

### 6.4.E Root Cause

The plan treats fuel as a supply item rather than an engineering-constrained resource with load profiles, consumption curves and pre-positioned tanker commitments. It names '72-hour reserves' without verifying tank sizing, refill protocols or ashfall-contamination procedures. Fuel-logistics engineering was not integrated into the hospitalization surge and generator-load planning.

## 6.5.A Issue - Electrical Transmission-Line Ashfall Interaction Unquantified; Flashover Probability and Cascading Blackout Triggers Missing

The plan assumes 'ash-induced flashovers on transmission lines' will cause power loss but provides no model of ashfall silicate conductivity, voltage-threshold interactions, or timing. Electrical transmission lines (115–500 kV) in the region (Montana-Dakota Utilities, Pacific Power, Idaho Power) serve 2–4 million people. A VEI-6 ashfall (100–500 µm/kg) deposits conductive silicate particles on ceramic insulators, reducing surface resistance to 1–10 MΩ within hours. Flashover occurs when voltage exceeds approximately 100 kV per insulator stack; a simultaneous 3–5 phase-to-ground faults cascade to load-shedding protocols and blackout propagation. The plan names 'protective relays' and 'emergency load shedding' but lacks a transmission-specific failure model, substation-specific topologies or the critical-path sequence that preserves grid coherency during the 4–8 hour ashfall peak.

### 6.5.B Tags

- cascading-blackout-prevention
- transmission-line-ashfall
- grid-resilience-engineering
- protective-relay-coordination

### 6.5.C Mitigation

By Month -1 (2026-09-14): (1) Engage a transmission-systems engineer from WECC (Western Electricity Coordinating Council) or a regional utility to model ashfall conductivity (100–500 µm/kg) vs. insulator stack voltage (115–500 kV lines), calculate flashover probability and timing. (2) Map the critical transmission corridors (substations within 100 km of the evacuation routes) and identify 3–5 load-shedding 'islands' that preserve comms, hospitals and shelters while sacrificing non-essential load. (3) Pre-authorize emergency-voltage reduction (brownout) on non-critical substations at Hour 4–6 of ashfall to reduce flashover risk before peak ash accumulation. (4) Test load-shedding sequences at Bozeman or Livingston substation 30 days before T+0 under simulated ash conditions (recommend using ash-simulation powder on test insulators). Document relay-coordination changes required to prevent nuisance trips.

### 6.5.D Consequence

Without transmission ashfall modeling and load-shedding coordination: (1) simultaneous 3–5 substation flashovers at Hour 4–8 trigger cascading blackout across Montana, Wyoming and Idaho (2–4 million people affected), (2) loss of comms infrastructure (cell towers lose power; backhaul lines fail) within 4–6 hours, (3) hospital generator failure propagation (loss of cooling, HVAC, surgical-suite lighting) cascades across the region within 8–12 hours, (4) responder coordination collapses; estimated delay: +6–12 hours to evacuation and 10–30 preventable deaths from hospital failures and responder entrapment in ash-covered areas without navigation or comms.

### 6.5.E Root Cause

The plan addresses ashfall as a water-and-respiratory hazard but not as an electrical hazard to the transmission network. Transmission-line flashover thresholds, insulator silicate-conductivity interactions and cascading-failure topology were not analyzed. The utility-liaison requirement (Decision 6) names 'protective relays' and 'load shedding' without transmission-system expertise or relay-coordination analysis.

## 6.6.A Issue - Water-System Contamination Protocols for Ashfall Missing; Bottled-Water Convoy Realistic Arrival Estimate Unverified

The plan targets water arrival at shelters by T+24 h and names a '1.43 million liter' requirement but provides no water-system contamination assessment or convoy-routing validation under ashfall conditions. Municipal water systems serving Bozeman and Idaho Falls draw from surface reservoirs or groundwater that will be ash-contaminated within 4–6 hours of eruption; the plan names 'ashfall will contaminate open reservoirs' but does not specify: (1) treatment timelines for ash removal (settling, filtration, chlorination), (2) which water sources (municipal, well, potable-water tankers) are accessible at each shelter, (3) realistic convoy travel time from Salt Lake City under ashfall-reduced visibility (I-15 ashfall is worst-case 50+ km north) and evacuee-traffic congestion (estimate: 18–30 h, not 12 h dispatch). Without a validated water-supply chain from source to shelter and explicit contamination-response protocols, shelters risk 1–3 days of water rationing or non-potable water use, creating gastroenteritis outbreak risk in close-quarters shelter conditions.

### 6.6.B Tags

- water-system-contamination
- ashfall-life-support-logistics
- convoy-routing-under-ashfall
- supply-chain-validation

### 6.6.C Mitigation

By Month -1 (2026-09-14): (1) Engage a water-utility engineer to assess Bozeman and Idaho Falls municipal-supply sources (reservoirs, treatment plants, distribution) and specify ash-contamination response (settle time, filter requirements, turbidity thresholds for continued use). (2) Calculate convoy travel time under realistic ashfall conditions: assume I-15 ashfall visibility 50–100 meters, safe speed 10 mph (not 60 mph), evacuee traffic at 25–40% congestion by Hour 8–12, resulting in 18–30 hour travel time (not 12 h dispatch). (3) Pre-stage 200,000–300,000 liters of bottled water at Bozeman and Idaho Falls forward depots by T+0 (not dispatch from Salt Lake City), with 72-hour refill contracts pre-positioned for convoys arriving at Hour 18–24. (4) Arrange for groundwater tanker-fill stations at Bozeman and Livingston (if municipal sources are offline) as backup, with pre-tested pump and hose interfaces. (5) Test convoy timing from Salt Lake City to Bozeman under simulated ashfall (use fog machines or ash-simulation powder to reduce visibility, measure actual speeds and traffic interaction) 30 days before T+0.

### 6.6.D Consequence

Without validated water-supply chains and contamination protocols: (1) municipal water sources become non-potable at Hour 4–8, (2) bottled-water convoy realistically arrives Hour 20–30 (not Hour 12–24), leaving shelters with 18–30 hour water-rationing window, (3) improvised use of contaminated municipal water (if treatment fails or ash exceeds filter capacity) triggers gastroenteritis in 500–1,500 shelter residents (5–15% attack rate in close quarters estimated), (4) medical response overloads field-clinic and hospital diarrhea/dehydration wards, cascading to loss of surge capacity for respiratory cases, (5) estimated consequence: 10–30 preventable deaths from dehydration, electrolyte imbalance and secondary infection in weakened populations.

### 6.6.E Root Cause

The plan treats water as a generic '1.43 million liter' number without upstream source assessment or contamination-response protocols. Water-system backup design and contamination thresholds (turbidity, ash-particle concentration) were not analyzed. Convoy routing was assumed to deliver within 12 hours from Salt Lake City, but ashfall conditions (visibility <100 meters, 10 mph safe speeds on ash-covered I-15, evacuee traffic saturation) were not reflected in travel-time modeling.

---

# 7 Expert: Aviation Safety & Airspace Management Liaison

**Knowledge**: FAA airspace restrictions, rotary-wing medevac protocols, ash-ingestion engine risk, aircraft emergency procedures, volcanic-ash-dispersion forecast integration, military-civilian airlift coordination

**Why**: The Ash-Cloud Airspace Closure decision specifies indefinite grounding of ZLC/ZSE with narrow government rotary-wing exceptions, yet the plan lacks the FAA authority procedure, aircraft ash-encounter risk assessment, and the operational parameters for the exception window (e.g., maximum ashfall concentration, flight altitude, aircraft type). This expert must operationalize the airspace closure and define when medevac, supply and survey flights can operate safely without exposing crews and aircraft to catastrophic engine damage.

**What**: Develop a written FAA Section 29 Notice to Airmen (NOTAM) template authorizing the blanket ZLC/ZSE grounding at T+0 and specifying rollback criteria tied to USGS ashfall concentration forecasts; design a narrow rotary-wing medevac/survey flight corridor (time windows, altitude, aircraft type, ashfall concentration triggers) that the Unified Command can request from the FAA without requiring a full rule change; establish a coordination protocol between the forward UC element, USGS/NOAA ash forecasters and helicopter operators (Wyoming Guard, USCG, civilian medevac services) ensuring that flight-request decisions are made within 30 minutes of a medical or reconnaissance need, with ashfall data updated hourly.

**Skills**: FAA airspace regulation and NOTAM procedures, aircraft engine ash-ingestion vulnerability, rotary-wing medevac mission planning, volcanic-ash-concentration forecasting integration, military-civilian aircraft coordination, emergency flight operations under hazardous-weather restrictions

**Search**: FAA airspace closure volcanic ash NOTAM, helicopter medevac ash concentration limits, aircraft engine ash ingestion risk assessment, military-civilian emergency airlift coordination

## 7.1 Primary Actions

- Execute a written Rotary-Wing Medevac Exception Protocol by Month -1 (2026-09-14 18:00) specifying ash-concentration thresholds (<200 µg/m³ PM10 at rotor altitude), approved flight corridors, aircraft-type restrictions, and pre-authorization for the UC to approve medevac flights under FAA Section 91.3 emergency authority without per-flight waiver delays; coordinate with FAA Alaskan Region, USGS Volcano Disaster Assistance Program, and aircraft OEMs (Bell, Sikorsky) to align thresholds with engine specifications; sign a Memorandum of Agreement with FAA and UC by T+0 (2026-10-14).
- Establish a Shelter Siting Decision Rule by Month -1 (2026-09-14 18:00) that selects primary shelter at T+6 h based on USGS/NOAA Volcanic Ash Forecast Transport 12-hour predictions (<50 µg/m³ PM10 threshold); pre-position PM10 sensors and automated alert systems at all three primary shelters and forward command by Month -0.5 (2026-09-29 14:00); pre-stage three ranked backup shelters 50-80 km upwind of each primary, updated daily from the 00:00 UTC wind forecast; revise shelter-relocation threshold from 4 hours to 2 hours if measured ashfall exceeds forecast by >50%.
- Execute a signed Memorandum of Agreement (MOA) with Wyoming, Montana and Idaho Army National Guard, U.S. Air Force (Malmstrom AFB), and Department of Defense by Month -1 (2026-09-14 18:00) pre-positioning 2-4 Army MEDEVAC helicopters at Gallatin County Airport (Bozeman) by Month -0.5 (2026-09-29 12:00), staffed for continuous 72-hour operations; integrate a Military Liaison Officer (O-4 rank) into the forward Unified Command at Livingston or Bozeman from T-24 h onward with direct authority over military asset dispatch (not request-response through state adjutants general).
- Coordinate with USGS Volcano Disaster Assistance Program and NOAA National Weather Service (Billings/Riverton, WY forecast offices) by Month -1 (2026-09-14 18:00) to confirm that Volcanic Ash Forecast Transport (VAFT) model updates will issue every 3 hours from T-24 h through T+72 h with explicit PM10 concentration outputs at 1,000 ft, 5,000 ft and 10,000 ft above each shelter location; embed this commitment in a signed interagency service-level agreement before T+0.
- Define and pre-authorize a Loss-of-Medevac-Capability Contingency by Month -1 (2026-09-14 18:00) specifying: if military rotary-wing assets become unavailable (weather, mechanical, no flying clearance), the forward UC will trigger ground ambulance transport to distant hospitals (Salt Lake City, Billings) using the reserved supply-lane convoy corridor, with estimated 8-12 hour transit time and contingency oxygen/ventilator supply in ambulances; pre-stage portable ventilators and 72-hour oxygen supplies at West Yellowstone, Gardiner and Cody clinics by Month -0.5 (2026-09-29).

## 7.2 Secondary Actions

- Schedule a technical coordination meeting with FAA Hazmat Division, USGS Ash-Forecast Validation Team, and aircraft manufacturers (Bell Helicopter, Sikorsky Aircraft) by Month -1.5 (2026-08-29) to establish ash-concentration limits that align with helicopter engine-inlet design specifications and operational safety standards; document engine particulate-ingestion tolerances (recommend consulting FAA AC 20-73, Airworthiness Certification of Ash Ingestion-Resistant Engines).
- Conduct a Joint Task Force activation and medevac-dispatch exercise at Livingston HealthCare or Eastern Idaho Regional Medical Center 30 days before the window (Month -0.5, 2026-09-29 08:00 to 16:00), simulating a critical-care patient transfer under simulated ashfall conditions; measure actual time from patient-release order to landing at receiving hospital (target <4 hours); document any bottlenecks in aircraft dispatch, patient loading, or inter-hospital coordination.
- Develop a detailed Rotary-Wing Supply-Resupply Protocol for isolated hospitals and shelters by Month -1 (2026-09-14), specifying: helicopter cargo-load capacity for water, fuel, medical supplies and N95 respirators; dispatch authority (forward UC vs. hospital request); frequency (every 12 hours if ground convoys are delayed); and cost-sharing (Stafford Act reimbursement or host-state funding).
- Establish a dedicated FAA-Military-UC coordination channel by Month -0.5 (2026-09-29 12:00), using secure video teleconference or dedicated satellite phone between FAA Seattle ARTCC (air traffic control), Malmstrom AFB command post, and the forward UC element, operational 24/7 from T-12 h through T+72 h to approve medevac flight requests within 30 minutes (versus 24-hour waiver turnaround).
- Create a Fallback Ground-Ambulance Medevac Plan for isolated patients by Month -1 (2026-09-14) specifying: ground-ambulance routes out of West Yellowstone, Gardiner and Cody to Idaho Falls and Salt Lake City under ashfall; estimated 8-12 hour transit times; portable ventilator and oxygen supply chains in ambulances; and hospital receiving-bed pre-commitment from large trauma centers (University of Utah Hospital, Salt Lake City; Idaho Falls Hospital).
- Brief hospital administrators and emergency physicians in West Yellowstone, Gardiner and Cody on ash-exposure protocols (respiration protection, patient triage for air-vs-ground evacuation) by Month -1 (2026-09-14); include tabletop exercise on loss-of-medevac scenarios and manual-ventilation surge capacity.
- Establish a pre-event liaison between the UC and the FAA's Volcanic Ash Forecast Transport working group by Month -2 (2026-08-14), requesting real-time forecast skill assessments and any known model biases for the Yellowstone region (e.g., if the VAFT model tends to overestimate or underestimate southward ash transport).

## 7.3 Follow Up Consultation

"At the next consultation, we will address: (1) finalization of ash-concentration thresholds from USGS and FAA technical working groups; (2) confirmation of military assets pre-positioning and Joint Task Force command authority; (3) integration of real-time air-quality monitoring into the Unified Command's common operating picture (COP); (4) FAA's approval process for rotary-wing flight corridors and medevac exceptions under Section 91.3 emergency authority; (5) inter-hospital patient-transfer protocols and backup ventilator supply for ground evacuation; and (6) post-event review of forecast accuracy and shelter-siting rule performance. We will also discuss whether civilian medical helicopters (air ambulances from Helena, Billings) should be pre-contracted as backup to military MEDEVAC, and how to manage volunteer or contracted rotary-wing assets that may arrive from outside the region without pre-authorization."

## 7.4.A Issue - FAA Airspace Grounding Lacks Medevac Exception Architecture and Ash-Concentration Decision Thresholds

The plan mandates 'indefinite grounding' of ZLC and ZSE but provides no operational criteria for rotary-wing medevac or survey flights. The statement 'narrow government rotary-wing medevac/survey exceptions requested by UC and authorized by FAA' is procedurally hollow: it does not specify ash-concentration limits, aircraft type restrictions, flight corridors, real-time monitoring triggers, or the operational timeline for FAA approval. A 'rotary-wing exception' without ash-concentration thresholds (e.g., <200 µg/m³ PM10 at 5,000 ft) risks engine ingestion and crew loss. The plan also conflates medevac (moving critical patients from hospitals) with evacuation flights (moving evacuees), which have different risk profiles and demand different approval paths.

### 7.4.B Tags

- ash-ingestion-risk
- airspace-restriction-criteria
- medevac-authorization-gap
- faa-approval-process

### 7.4.C Mitigation

By Month -1 (2026-09-14), execute a written Rotary-Wing Medevac Exception Protocol specifying: (1) ash-concentration thresholds from USGS forecasts and real-time VAAC updates (recommend <200 µg/m³ PM10 at rotor altitude); (2) approved flight corridors below the ash cloud (e.g., east or west bypass routes); (3) aircraft-type restrictions (single-engine helicopters prohibited; twin-engine, ash-tolerant airframes only); (4) real-time monitoring via air-quality sensors at staging airfields and hospitals; (5) FAA pre-authorization for UC to issue medevac flight approvals directly without 24-hour Section 91.3 waiver turnaround. Coordinate with FAA Alaskan Region (volcanic-ash experience) and Army Aeromedical Center. Schedule a 4-hour technical meeting with FAA Hazmat, USGS Volcano Disaster Assistance Program, and airframe OEMs (Bell, Sikorsky) to align ash-concentration limits with engine-inlet design specifications. Document in a Memorandum of Agreement (MOA) signed by FAA and UC by T+0.

### 7.4.D Consequence

Without ash-concentration thresholds and pre-authorized FAA approval, medevac flights will be grounded or delayed 2-4 hours per request during the 72-hour window. This will strand 5-10 critical-care patients at Zone One hospitals during ashfall, forcing manual ventilation by exhausted staff and increasing respiratory-death risk by 30-50% for dialysis-dependent or ventilator-bound patients. In Scenario Beta, the grounding persists longer, adding 20-30 preventable deaths across the multi-state evacuation zone. A single helicopter engine encounter with high-concentration ash could disable the aircraft and kill 3-4 crew members, triggering FAA investigation and a de facto total grounding for weeks.

### 7.4.E Root Cause

The plan treats aviation as a secondary concern and defers ash-concentration thresholds to 'USGS/NOAA liaison' without embedding those thresholds into the UC decision framework or the FAA Section 91.3 emergency authority process. The FAA requires explicit ash-concentration limits and flight-corridor definitions before authorizing any flight into a volcanic-ash environment. Without pre-negotiated thresholds (Module 1-2 weeks of technical coordination with FAA Hazmat Division, USGS, and aircraft OEMs), the UC will face 2-4 hour delays requesting approval for each medevac flight during the 72-hour window, or will fly without approval and risk catastrophic engine damage.

## 7.5.A Issue - Ash-Concentration Forecast Integration Absent; Shelter Siting Rule Depends on Unvalidated Dispersal Models

The plan states 'Select final shelter locations at T+6 hours from the forecast wind and plume model' and later 'ashfall forecast uncertainty of ±50 km' as a baseline risk, but it provides no mechanism for integrating real-time ash-concentration forecasts from USGS-operated volcano-ash transport (VAAT) or NOAA's Volcanic Ash Forecast Transport (VAFT) models into shelter-siting decisions. The canonical facts mention PM10 thresholds (50, 100 µg/m³) but do not specify which model provides those predictions, how often forecasts are updated, or which concentration level triggers shelter relocation. The plan also lacks an air-quality sensor network tied to the shelter-siting rule, so the '4-hour relocation' protocol cannot be executed: you cannot know whether to relocate until ash actually arrives, by which time 30 minutes to 2 hours have already passed without action.

### 7.5.B Tags

- volcanic-ash-dispersion-model
- forecast-uncertainty
- shelter-relocation-trigger
- air-quality-monitoring-gap

### 7.5.C Mitigation

By Month -1 (2026-09-14): (1) establish a written agreement with USGS Volcano Disaster Assistance Program and NOAA's National Weather Service Forecast Office (Billings or Riverton, WY) specifying that the Volcanic Ash Forecast Transport model will issue updates every 3 hours from T-24 h through T+72 h, with explicit concentration outputs at 1,000 ft, 5,000 ft and 10,000 ft above each shelter location (Bozeman, Idaho Falls, third site); (2) define a Shelter Siting Decision Rule: at T+6 h, choose primary shelter from among three ranked candidates based on which site has <50 µg/m³ PM10 at T+12 h (12-hour forecast lead time). If the latest VAFT update (every 3 h) predicts >100 µg/m³ at the primary site within 6 hours, trigger relocation to backup within 2 hours (revised from 4 hours); (3) deploy PM10 sensors and LIDAR backscatter systems at all three primary shelter sites and the forward command by Month -0.5 (2026-09-29 14:00), with automated alerts if measured PM10 exceeds forecast by >50% (indicating model error or plume intensification); (4) pre-position backup shelters 50-80 km upwind of each primary (not merely 50+ km), confirmed daily from the 00:00 UTC GFS wind forecast, with 2-hour occupancy-transfer capacity. Consult USGS Ash-Forecast Validation Team (Denver) on model skill for Yellowstone plume heights.

### 7.5.D Consequence

Without forecast integration and real-time air-quality sensors, the shelter-siting decision at T+6 h is blind: it relies on a forecast whose uncertainty exceeds the distance between Bozeman and the primary ashfall zone (roughly 80-120 km). If the actual ashfall arrives 30-50 km south of forecast (within ±50 km error bounds), Bozeman's shelter population of 15,000-20,000 will be exposed to 200-500 µg/m³ PM10, overwhelming respiratory capacity and forcing emergency relocation after occupants have already arrived. A 2-4 hour relocation of 15,000 people under ashfall requires buses, drivers and logistics that the evacuation phase will have already consumed. Failure to relocate results in 200-500 shelter residents with acute respiratory distress, requiring hospital transport during peak ashfall when roads are ash-clogged and visibility is <100 meters (estimate).

### 7.5.E Root Cause

The plan assumes USGS/NOAA forecasts will provide reliable ash-concentration predictions in real-time during an unprecedented event. In reality, the VAFT model (the operational tool) has a ±50 km spatial uncertainty at 24 hours and larger uncertainty in concentration magnitude. A VEI-6 eruption at Yellowstone has never been directly observed; the model ensemble's range is wide (e.g., 10 µg/m³ to 1,000 µg/m³ at Bozeman depending on plume height and wind). The plan conflates forecast availability (VAFT updates every 3 hours) with forecast reliability (±50 km error), and it does not name which forecast product drives the shelter-siting decision or specify decision rules for forecast mismatches (e.g., if the latest forecast shows ashfall shifting 50 km north of the previous forecast).

## 7.6.A Issue - Military-Civilian Airlift Coordination Absent; Rotary-Wing Medevac and Supply Chains Lack Pre-Event Authority Agreements

The plan names 'Army Aeromedical Center' and references 'military airlift windows' and 'helicopter resupply' but provides no operational agreements with Wyoming National Guard (Cheyenne), U.S. Air Force (Malmstrom AFB, Great Falls, MT) or Army Medical Evacuation (MEDEVAC) units. The canonical facts mention 'a standing airlift protocol with the Wyoming National Guard (Cheyenne-based aviation) and U.S. Air Force (Malmstrom AFB, Montana) for priority dispatch of fuel or medical supplies to isolated hospitals within 4 hours of request from T+0 to T+72 hours,' but this protocol is not defined in any document and there is no Military Liaison Officer (MLO) listed in the Unified Command structure. Without pre-signed Interagency Agreements (MOAs) with the National Guard Bureau and Air Force Pacific Air Forces, a request for military rotary-wing or cargo support will generate 24-48 hour approval delays through state adjutants general (MT, WY, ID) and NORTHCOM, not the promised 4-hour dispatch.

### 7.6.B Tags

- military-civilian-coordination
- medevac-dispatch-authority
- air-force-liaison-gap
- rotary-wing-pre-positioning

### 7.6.C Mitigation

By Month -1 (2026-09-14): (1) Execute a signed Memorandum of Agreement (MOA) between FEMA Region VIII, the Wyoming, Montana and Idaho Army National Guard, the U.S. Air Force (21st Space Wing and 341st Missile Wing, Malmstrom AFB), and the Department of Defense specifying: (a) pre-positioned Army MEDEVAC helicopters (2-4 UH-60s with hoist and litter capability) stationed at Gallatin County Airport (Bozeman) or Jackson Hole Airport by T-48 h (Month -0.5, 2026-09-29 12:00 UTC), staffed and fueled for continuous 72-hour operations; (b) pre-cleared flight corridors into ZLC and ZSE airspace that bypass the ash cloud (negotiated with FAA beforehand, not ad-hoc); (c) four-hour dispatch of additional rotary-wing assets from Fort Carson (Colorado National Guard) or Malmstrom AFB if the pre-positioned asset is engaged >2 hours without recovery; (d) a Joint Task Force commander (active-duty Army or Guard colonel) integrated into the Unified Command structure from T-24 h through T+72 h with direct authority over military asset allocation, not request-response hierarchy through state adjutants general. (2) Assign a permanent Military Liaison Officer (O-4 rank) to the forward UC element (Livingston or Bozeman) by Month -0.5 (2026-09-29 06:00), with secure communication to NORTHCOM and 9th Medical Battalion. (3) Conduct a Joint Task Force activation and medevac-dispatch exercise at a Zone One hospital (e.g., Livingston HealthCare) 30 days before the window (Month -0.5, 2026-09-29 08:00 to 16:00), simulating a critical-care patient transfer under ashfall conditions, testing aircraft launch-to-landing times from Bozeman to a receiving hospital in Idaho Falls or Salt Lake City, and confirming that 'four-hour dispatch' includes actual patient loading and transport (not just aircraft wheels-up).

### 7.6.D Consequence

Without pre-positioned military assets and signed MOAs, medevac of critical-care patients will face 12-24 hour delays or will not occur. During the T+2 to T+8 evacuation peak, hospitals in Gardiner, West Yellowstone and Cody will have 5-10 dialysis-dependent or ventilator-bound patients who cannot be evacuated by ground ambulance if ashfall reduces visibility to <100 meters. Without rotary-wing medevac, these patients will be sheltered in hospitals that are ash-exposed and under-supplied with generator fuel for mechanical ventilation. A 6-12 hour loss of ventilator support due to power or fuel shortage will cause 2-5 preventable deaths. In Scenario Beta, the multi-state operation will have 50-100 similar patients trapped without air-evacuation capability, adding 20-50 preventable deaths.

### 7.6.E Root Cause

The plan assumes that military airlift will be available on-demand during a civilian disaster, but the National Guard requires gubernatorial request through the Adjutant General and federal activation requires Presidential authorization (Stafford Act) or Secretary of Defense/NORTHCOM approval. A 'standing airlift protocol' without a signed MOA is not a commitment; it is a hope. The Unified Command structure does not list a dedicated Military Liaison Officer or Joint Task Force commander, so there is no single point of authority to request military resources during the evacuation. Army MEDEVAC (9th Medical Battalion out of Fort Carson, CO or 111th Aviation Battalion, Montana Army National Guard) requires 12-24 hour notice for asset deployment and aircraft pre-positioning, not 0-hour notice for 'priority dispatch within 4 hours.'

---

# 8 Expert: Visitor Communication & Behavioral Compliance Strategist

**Knowledge**: emergency public messaging design, visitor notification systems, international-visitor language access, shadow-evacuation dynamics, message credibility and trust repair, multilingual alert distribution

**Why**: The Shadow Evacuation Suppression and International Visitor decisions and canonical facts require multilingual messaging in five languages and a published USGS trigger matrix to protect credibility, yet the plan lacks the specific message content, distribution testing, and the behavioral model for how unordered outer-zone residents will respond to shelter-in-place orders versus time-banded releases. This expert must design the complete messaging strategy, validate comprehension with foreign-language speakers, and certify that the trigger matrix and escalation messaging can be deployed without eroding public trust if Scenario Beta is later ordered.

**What**: Produce final IPAWS/WEA/HAR message content in English and the five specified languages (Spanish, Japanese, German, Mandarin, French) with comprehension-level validation testing by native speakers; design a Scenario Beta message sequence that transitions from shelter-in-place (if Beta is not triggered) to time-banded evacuation (if Beta is triggered at T+12h or later) without appearing to reverse a prior order, using consistent terminology and a published risk explanation; establish a visitor-needs data collection protocol at lodges and permit stations (language, vehicle, mobility-need, contact-info capture) from T-48h to T+0, enabling targeted notification of high-need visitors; conduct a message-credibility and behavior-response exercise with sample visitor and Zone One resident populations 30 days before the eruption window, documenting compliance rates under each message variant and identifying any cultural or language-specific communication barriers.

**Skills**: emergency-message design and testing, multilingual content development and validation, behavioral-response modeling in evacuation scenarios, public-trust restoration and credibility maintenance, visitor-needs population estimation, alert-distribution-channel effectiveness analysis

**Search**: emergency evacuation messaging design visitor compliance, multilingual IPAWS alert content testing, shadow evacuation suppression communication strategy, volcanic disaster public messaging credibility

## 8.1 Primary Actions

- Execute written Scenario Beta Second-Stage Evacuation Plan by Month 1 (2026-11-14), naming five to ten ranked shelter hubs outside the 500 km ring (Denver, Cheyenne, Albuquerque, Las Vegas), with capacity MOUs confirming bed and medical-staff availability for 100,000–500,000 additional evacuees, and pre-stage 20,000–30,000 person food, water and N95 supplies at each hub by Month 2 (2026-12-14). Without this, a pre-authorized VEI-7 trigger will order millions to evacuate with no published destinations, causing uncontrolled flight that blocks Zone Zero corridors and adds 4–8 hours delay.
- Secure written pre-event mutual-aid commitments from out-of-region agencies (Colorado Parks and Wildlife, Wyoming Game and Fish, Idaho Department of Lands, Fort Carson National Guard) by Month -0.5 (2026-09-29) for 50–100 deployable traffic-control personnel pre-positioned at Billings or Cheyenne with 4-hour dispatch authority. Size separate responder N95 stocks (600–1,500 estimated) from confirmed responder headcount and pre-stage at forward command. Test shift-rotation and relief handoff at Gardiner checkpoint before T+0. Without this, all 67–100 ranger positions are consumed during peak evacuation with zero cushion; one traffic incident or injury will halt a checkpoint for 2–4 hours, stranding 500–2,000 vehicles in ash.
- Deploy continuous PM10/PM2.5 sensors at Bozeman, Idaho Falls and forward command by Month -0.5 (2026-09-29, 12:00 hours), with automated hourly feeds to forward command and USGS/NOAA. Develop ranked three-shelter backups 50+ km upwind for each primary site, confirmed daily from wind forecast. Pre-authorize rapid relocation protocols (4-hour decision-to-notification) and pre-stage supplemental 100,000 N95s at Billings hub with 8-hour transport agreement. Conduct air-quality and shelter-siting exercise 30 days before eruption window simulating ashfall 50 km south of forecast. Without this, shelters could be placed in heavy ashfall; N95 consumption 3–5x exceeds model estimates; 200–500 evacuees become stranded.

## 8.2 Secondary Actions

- Issue written Responder Exposure and Relief Protocol by Month -0.5 (2026-09-29) specifying maximum 6-hour shifts at ash-exposed posts, 2-hour rest with N95 replacement, and full withdrawal after 18 consecutive hours. Pre-authorize automatic request for out-of-region Guard reinforcement if any checkpoint coverage falls below 50%.
- Obtain written pre-event governor authorization letters from Montana, Wyoming and Idaho by Month -0.5 (2026-09-29), confirming their authorization of Unified Command evacuation orders for Zone One and Scenario Beta, and their agreement to cede operational authority over park-boundary traffic to the NPS incident commander until formal handoff. Execute written MOUs with state DOTs specifying exact boundary-transfer checkpoints and state authority scope.
- Establish Boundary Coordination Officer position at forward command element (Livingston or Bozeman) by Month 0 (2026-10-14) (T+0) with real-time voice, data and satellite links to NPS incident commander, three state on-scene commanders and Denver RRCC, operating 24/7 from T-12 to T+72 hours with authority to make traffic and shelter decisions without supervisory approval if higher communication is lost >5 minutes.
- Deploy National Guard signal corps teams with satellite phones, portable repeaters, 72-hour fuel and equipment caches to each contraflow control point and forward command by Month -0.5 (2026-09-29, 14:00 hours). Pre-produce IPAWS, WEA, NOAA Weather Radio and HAR content in English and five primary visitor languages by Month -0.5 (2026-09-29), validated for comprehension. Conduct formal radio interoperability testing across all agencies 30 days before eruption window.
- Pre-position at least two mobile heavy-equipment teams (wreckers, debris chippers, geotechnical monitoring drones, 72-hour fuel) at Mammoth or Spanish Creek depots by Month -0.5 (2026-09-29, 06:00) with 15-minute dispatch authority to Gallatin Canyon blockages. Conduct South Entrance geotechnical survey 60 days before eruption window (Month -1.5, 2026-08-29) quantifying debris volume and secondary-slide probability; develop time-boxed (maximum 4 hours) single-lane clearance plan with hard abort triggers (M>4.0 seismic event, >2 cm slope displacement, or >30-minute equipment breakdown).
- Schedule formal FEMA Region 10 (Seattle) coordination call from Denver RRCC at T+0 and 12-hour intervals through Month 1 (2026-11-14), documented in signed MOU by Month -0.5 (2026-09-29) specifying pre-authorized mutual-aid requests (minimum 100,000 gallons bottled water, 50,000 gallons diesel fuel, 50 portable generators, shelter supplies for 10,000 people) on 6-hour notice. Pre-authorize water and fuel convoys from Salt Lake City, Pocatello and Butte with 12-hour dispatch contracts by Month -0.5 (2026-09-29).
- Establish 24/7 utility-operations coordination hotline from forward command to Montana-Dakota Utilities, Pacific Power and Idaho Power by Month -0.5 (2026-09-29, 18:00). Pre-position 72-hour diesel and propane reserves at three receiving hospitals (Bozeman Deaconess, Livingston HealthCare, Eastern Idaho Regional Medical Center) by Month -0.5 (2026-09-29, 18:00). Conduct hospital power-failure exercise at each facility 30 days before eruption window testing generator startup, fuel transfer, backup surgical protocols and manual bagging under 6–8 hour power loss.

## 8.3 Follow Up Consultation

Next meeting should address: (1) Final Scenario Beta hub nominations and distance verification to confirm Denver and Cheyenne lie outside 500 km and capacity commitments; (2) responder mutual-aid MOUs with named personnel, pre-positioning depot and deployment authorization by Month -0.5; (3) sensor deployment authority and real-time data-feed protocols linking forward command to NOAA/USGS for continuous shelter-suitability monitoring; (4) governor pre-authorization pathway (verbal by T+6 h, signed MOUs by Month 1 = 2026-11-14); (5) Boundary Coordination Officer job description and interagency radio frequency allocation; (6) full-scale exercise schedule for Months 1–3 (2026-11-14 to 2027-01-14) including Beta multi-state routing, shift-rotation relief handoff, and water-convoy deployment under congestion. Financial responsibility split (federal vs. state/local) for shelters and secondary hubs must be resolved before Month 1 (2026-11-14).

## 8.4.A Issue - Scenario Beta second-stage hub plan is a hollow pre-authorization with no executable destinations

The plan pre-authorizes a UC order to evacuate 500 km with a 30-minute decision window, but names no specific hubs, capacity commitments, or supply staging. The canonical facts state 'Denver and Cheyenne qualify (distance not verified)' and 'millions of people (not quantified).' A 500 km radius from Yellowstone reaches ~8–12 million people. Issuing an evacuation order without published shelter addresses, registration sites, or supply depots will trigger chaotic uncontrolled flight that saturates I-15, I-80 and I-90, delays the primary 35,800-person Zone Zero evacuation by 4–8 hours, and strands vehicles in ash plumes. The order is pre-authorized but not pre-planned, making it operationally reckless.

### 8.4.B Tags

- Scenario-Beta-destinations-unspecified
- cascade-failure-risk
- shadow-evacuation-undefined
- operational-authority-vs-capacity-mismatch

### 8.4.C Mitigation

By Month 1 (2026-11-14), name five to ten ranked Beta hubs outside 500 km: Denver, Cheyenne, and secondary sites (Albuquerque, Las Vegas candidates); confirm capacity MOUs from each host county for 100,000–500,000 additional beds, kitchens and medical triage. Stage a 20,000–30,000-person supply surge (water, N95s, food, fuel) at each hub by Month 2 (2026-12-14). Issue tiered public messaging specifying shelter-in-place zones (250–500 km, self-supplied), time-banded evacuation (100–250 km, assigned by county), and organized departure (Zone One). Execute a full multi-state exercise moving 5,000 vehicles from the Zone One boundary to beta hubs by Month 3 (2027-01-14).

### 8.4.D Consequence

Without executable Beta destinations, the pre-authorization becomes a hollow mandate that orders millions to flee with no published safe shelter. Uncontrolled flight cascades into I-15/I-80/I-90 gridlock, blocking the Zone Zero corridor. Delays to primary evacuees compound 4–8 hours, stranding vehicles in ash. Hospital and shelter intake systems overflow within 12 hours. 10,000–20,000 people cannot reach published shelters and become stranded. Preventable deaths from respiratory distress increase 20–50% over the baseline plan.

### 8.4.E Root Cause

Pre-authorization of Scenario Beta was treated as a decision isolated from downstream capacity and messaging planning. No host-hub engagement occurred before Month 0 (2026-10-14); no interstate MOUs bind hubs to accept millions of people. The plan conflates 'who decides to order evacuation' (UC authority) with 'where evacuees actually go' (second-stage capacity), leaving the latter undefined. The canonical facts acknowledge distance to Denver and Cheyenne are 'not verified,' suggesting the hubs were named without validation.

## 8.5.A Issue - Responder staffing depth is insufficient and responder N95 stocks are unsized and separate from civilian supply

The plan estimates 100–150 NPS rangers at a 1.5 relief ratio, yielding ~67–100 concurrent positions. Canonical facts propose 6-hour shifts, 2-hour rest, and 18-hour withdrawal limits, plus a 30–50 'standby reserve' from out-of-region. However: (1) all 67–100 ranger positions are consumed during T+2 to T+8 peak evacuation with zero cushion for injury, equipment failure, or scope creep; (2) responder N95s are 'counted separately, not drawn from the 100,000 civilian stock' (proposed threshold), but no responder headcount exists to size this separate stock; (3) a single traffic incident at Gallatin Canyon or a ranger injury during peak hours cannot be absorbed without halting one checkpoint, stranding 500–2,000 vehicles and cascading 2–4 hours delay. The 30–50 reserve exists only if it can be deployed within 4 hours; no mutual-aid agreement or pre-positioning is documented.

### 8.5.B Tags

- responder-capacity-thinness
- N95-sizing-opaque
- single-point-staff-failure
- relief-availability-unconfirmed

### 8.5.C Mitigation

By Month -0.5 (2026-09-29, before T+0), secure written pre-event mutual-aid commitments from Colorado Parks and Wildlife, Wyoming Game and Fish, Idaho Department of Lands and Fort Carson (Colorado National Guard) for 50–100 out-of-region traffic-control and patrol personnel, pre-positioned at Billings or Cheyenne with 4-hour deployment authorization. Size responder N95s from confirmed responder headcount (rangers, highway patrol, Guard, utility crews estimated 300–500 total); estimate 2–3 respirators per responder over 72 hours = 600–1,500 total responder N95s. Pre-stage this stock separately at the forward command depot with dedicated replacement logistics. By Month 0 (2026-10-14) (T+6 hours), assess actual ranger availability and request additional Guard personnel if coverage at any checkpoint drops below 50%. Test shift-rotation and relief handoff at Gardiner checkpoint (Month -0.5, 6-hour exercise) to confirm 4-hour reserve-deployment time.

### 8.5.D Consequence

If responder depth is not increased and confirmed, peak-hour traffic control will fail. A single breakdown at Gallatin Canyon or ranger injury at T+4 hours cannot be absorbed. One checkpoint halts for 2–4 hours, queuing 500–2,000 vehicles in ash, adding 2–4 hours to their exit time and increasing respiratory-distress cases by 30%. Stranded vehicles may attempt uncontrolled departures on secondary roads, risking 5–10 additional collisions. Responder N95 supply exhaustion at T+36–48 hours forces withdrawal of traffic-control staff, leaving checkpoints unmanned and allowing looting in evacuated towns. Preventable respiratory deaths among responders increase 10–15%.

### 8.5.E Root Cause

Responder staffing was dimensioned against the 35,800-person Zone Zero evacuation in isolation, without modeling peak concurrent demand across traffic control, perimeter patrols, backcountry sweeps, medical transport, and comms maintenance. The 1.5 relief ratio is typical for planned operations, not crisis response with ash exposure and injury risk. Responder N95 sizing was deferred ('counted separately') without defining the responder population. No pre-event mutual-aid agreements or forward pre-positioning exist; the standby reserve is aspirational and depends on T+0 decisions and verbal authorization.

## 8.6.A Issue - Shelter siting at T+6 hours based on a single plume forecast with ±50 km uncertainty and inadequate real-time monitoring enables shelter placement in heavy ashfall

The plan chooses final shelter sites at T+6 hours using the latest NOAA/USGS plume forecast and proposes a 4-hour relocation rule if conditions worsen. However: (1) ashfall forecast uncertainty for a VEI-6 event is ±50 km or greater (unvalidated, never directly observed in North America); (2) PM10 sensors are 'at forward element and every shelter' (proposed threshold) but no sensor deployment timeline or communication protocol is documented; (3) a single forecast update at T+6 hours provides one snapshot; no continuous 4-hourly updates are guaranteed; (4) if actual ashfall exceeds forecast by 50 km or doubles in intensity, 10,000–15,000 evacuees sheltered at Bozeman or Idaho Falls sit in moderate-to-heavy ash (PM10 > 500 µg/m³ estimate), consuming N95s 3–5x faster than model estimates. A 4-hour relocation of 10,000 people requires ~20–30 buses and 4–6 hours actual transport time, not 4 hours decision-to-arrival. Shelters could be placed in the plume.

### 8.6.B Tags

- forecast-uncertainty-underestimated
- shelter-siting-brittle
- real-time-monitoring-sparse
- N95-consumption-underestimated
- relocation-latency-optimistic

### 8.6.C Mitigation

By Month 0 (2026-10-14) (T+0), deploy continuous PM10/PM2.5 sensors at Bozeman, Idaho Falls and the forward command with automated hourly data feeds to the forward command and USGS/NOAA. Set thresholds: >50 µg/m³ triggers immediate forecast update; >100 µg/m³ triggers shelter-suitability review. By Month -0.5 (2026-09-29), develop ranked three-shelter backup system for each primary site, identifying second and third locations 50+ km upwind of each primary, confirmed daily from 00:00 UTC wind forecast. Pre-authorize rapid occupancy-transfer protocols (4-hour decision-to-notification maximum). By Month 0 (2026-10-14) (T+6 hours), stage a supplemental 100,000 N95s at Billings or Salt Lake City hub with 8-hour ground-convoy or helicopter-transport agreement. Conduct an air-quality and shelter-siting exercise 30 days before eruption window (Month -0.5, 2026-09-29) simulating ashfall 50 km south of forecast, testing relocation decision and bus dispatch for 5,000–10,000 evacuees within 4 hours.

### 8.6.D Consequence

If shelter sites are placed 50 km downwind of forecast and ashfall exceeds model predictions, 10,000–15,000 evacuees shelter in moderate-to-heavy ash (PM10 > 500 µg/m³ estimate) with inadequate N95 supplies. Daily N95 consumption 3–5x exceeds model; stock depletes within 12–24 hours instead of 10 days. Respiratory distress cases increase 50–100% at receiving hospitals. A 4-hour relocation decision-to-movement window is unachievable; actual bus dispatch and transport require 6–12 hours, stranding evacuees in ash. 200–500 people cannot reach a second shelter before N95 supply fails. Pneumonia and acute respiratory failure cases increase 20–30%; preventable deaths increase 5–10 over baseline.

### 8.6.E Root Cause

Shelter siting was treated as a T+6-hour tactical decision, not a strategic design. The plan inherited plume-forecast uncertainty from NOAA/USGS without quantifying forecast error (±50 km is a reasonable estimate but unvalidated). PM10 sensors and continuous monitoring were specified as 'proposed thresholds' but no deployment authority, cost or timeline was documented. Real-time relocation was assumed to fit within 4 hours; actual bus dispatch and transit (6–12 hours estimated) makes this infeasible. The 100,000 N95 civilian stock was not stress-tested against 3–5x consumption in heavy ashfall. Backups and upwind sites were mentioned but not pre-surveyed or pre-authorized for rapid occupancy.