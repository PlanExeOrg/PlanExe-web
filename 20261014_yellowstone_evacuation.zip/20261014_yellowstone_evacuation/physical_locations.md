This plan implies one or more physical locations.

## Requirements for physical locations

- Command site with federal resource-request capability and resilient communications (FEMA Region VIII RRCC, Denver)
- Forward command element with direct sight of the US-191, US-89 and I-90 corridors, outside the immediate ash and tremor hazard
- Reception and shelter sites with medical triage, registration, reunification and large-capacity buildings, outside the modeled ash footprint
- Exit corridors with contraflow capability: US-191/US-20 to West Yellowstone, US-89 to Gardiner, US-14/16/20 to Cody
- Pre-positioned tow, rescue and traffic-control assets at chokepoints such as Gallatin Canyon and Gardiner
- Staging depots for water, N95 respirators and generator fuel with road access (Salt Lake City, I-15, I-90)
- Receiving hospitals with generator fuel priority and helipad or ground-ambulance access
- Second-stage destinations for a 500 km Scenario Beta evacuation (not yet defined in the plan)

## Location 1
USA, Wyoming/Montana/Idaho

Yellowstone National Park (Zone Zero) and gateway towns West Yellowstone, Gardiner and Cody (Zone One)

Norris Geyser Basin, Grand Loop Road, South Entrance (US-89/191/287), West Entrance (US-20/191), North Entrance (US-89), East Entrance (US-14/16/20)

**Rationale**: The evacuation of about 35,000 visitors and 800 staff (user constraint) takes place here, with the landslide-blocked South Entrance and contraflow on the named routes.

## Location 2
USA, Colorado

Denver

FEMA Region VIII Regional Response Coordination Center, Denver Federal Center, Lakewood/Denver

**Rationale**: Named Unified Command site for federal resource requests. Region 10 (Idaho) coordination must be added to this site.

## Location 3
USA, Montana

Bozeman or Livingston

Forward Unified Command element near I-90 at Livingston, or Bozeman (Gallatin County)

**Rationale**: Gives the incident commander direct sight of the US-89 and US-191 corridors and the I-90 junction, and a base for the Bozeman reception center. Both sites are near the Zone One edge, so a wind-driven relocation option is needed.

## Location 4
USA, Idaho

Idaho Falls

Bonneville High School and pre-surveyed schools/arenas in Idaho Falls

**Rationale**: Named western reception center on the US-20 corridor. Final shelter selection should follow the T+6 wind and plume forecast, with a second-stage move planned.

## Location 5
USA, Utah

Salt Lake City

Regional distribution centers and staging areas along I-15

**Rationale**: Source of bottled water convoys within 12 hours and of N95 and fuel stocks. Also a candidate receiving hub for patient transfers, outside the modeled ash footprint (not verified).

## Location Summary
The plan is tied to Yellowstone National Park and its Zone One gateway towns (West Yellowstone, Gardiner, Cody). Command sits at the FEMA RRCC in Denver, with a proposed forward element at Bozeman or Livingston. Evacuees are received at Bozeman and Idaho Falls, and supplies are staged from Salt Lake City. Each listed site covers a defined function: evacuation, command, forward control, reception or logistics.