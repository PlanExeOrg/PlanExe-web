
## Question 1 - What funding source and budget ceiling cover pre-positioned supplies, contracts and surge operations across FEMA, NPS and the three states?

**Assumptions:** Assumption: Funding comes from a federal emergency declaration (Stafford Act) plus pre-event contract vehicles, with an initial surge envelope of about USD 150-250 million (estimate), reimbursed through FEMA procedures. Justification: large multi-state responses typically draw on declaration-based cost-sharing.

**Assessments:** Title: Financial Feasibility Assessment
Description: Evaluates funding availability and speed of access.
Details: Risk: procurement delays of 24-48 hours (estimate) without pre-awarded contracts. Mitigation: pre-event surge contracts for water, N95, fuel and buses, with verbal activation. Opportunity: FEMA contract vehicles remove competitive-bidding delay. Track burn rate in USD hourly at the forward command; hold a 20% contingency (proposed) for Scenario Beta.

## Question 2 - Which milestones and decision gates must be met within the 72-hour window, including the T+6 evacuation and the T+12 water convoy deadlines?

**Assumptions:** Assumption: Project starts at Month 0 (2026-10-14) with preparation as the first activity. Milestones: Zone Zero cleared by T+6 hours, Zone One by T+24 hours, water convoys dispatched by T+12 hours (user constraints), and shelter selection at T+6 from the plume forecast. Justification: matches the phased structure of the plan.

**Assessments:** Title: Timeline Feasibility Assessment
Description: Tests whether phase deadlines are achievable.
Details: Risk: ashfall and gridlock may stretch the 12-hour convoy to 18-30 hours (estimate). Mitigation: pre-stage depots before T+0, reserved convoy lane, hourly gate reviews. Opportunity: a three-exit design (including East Entrance) shortens clearance. Hard abort triggers for southern clearance work keep the schedule from slipping.

## Question 3 - What numbers of rangers, highway patrol, National Guard, tow crews, buses and medical staff are available for traffic control, sweeps and perimeters?

**Assumptions:** Assumption: About 100-150 NPS rangers (estimate), supplemented by Montana, Wyoming and Idaho highway patrol and Guard units, staff the control points; relief depth is 1.5 responders per post (proposed). Justification: 8-hour shifts need that ratio for continuous coverage.

**Assessments:** Title: Resource Adequacy Assessment
Description: Compares staffing demand with likely availability.
Details: Risk: all ranger hours consumed during T+2 to T+8, leaving no relief. Mitigation: request out-of-region Guard and a 30-50 person standby reserve (proposed), tier posts by criticality. Count responder N95s separately from the 100,000 civilian stock (user constraint). Opportunity: concessioner buses raise people per vehicle.

## Question 4 - What legal authorities and agreements govern the NPS-to-state handoff, FEMA Region 8/10 coordination, FAA grounding and interstate mutual aid?

**Assumptions:** Assumption: Authority transfers at defined roadside checkpoints under a written protocol, backed by governor MOUs and EMAC mutual aid; Idaho coordination runs through a FEMA Region 10 liaison at the Denver RRCC. Justification: standard Unified Command practice.

**Assessments:** Title: Governance Assessment
Description: Reviews command clarity and legal basis.
Details: Risk: authority gaps mid-corridor delay reroutes by 15-45 minutes (estimate). Mitigation: Boundary Coordination Officer at the forward element, pre-signed MOUs, pre-authorized state reroute powers. FAA grounding needs a liaison at the Unified Command. Benefit: pre-agreed authority removes turf disputes and speeds the pre-authorized Scenario Beta order.

## Question 5 - What are the principal life-safety hazards (chokepoint failure, secondary slides, ash exposure, hospital power loss, stranded backcountry visitors) and the abort criteria for each?

**Assumptions:** Assumption: Principal hazards are corridor blockage in Gallatin Canyon, secondary slides at the South Entrance, backcountry stragglers, and hospital power loss. Abort criteria are seismic-based (e.g. renewed M4.0+ activity, proposed threshold) and blockage lasting over 45 minutes (proposed) triggers diversion.

**Assessments:** Title: Safety and Risk Assessment
Description: Prioritizes hazards by severity and likelihood.
Details: Highest: single-point corridor failure (high/high). Mitigation: pre-placed tow and rockfall teams at chokepoints, geotechnical monitoring, diversion rule. Crew safety: time-boxed clearance with abort triggers. Medical: 72-hour fuel reserves at receiving hospitals. Maintain a risk register with owners and review each shift.

## Question 6 - How will ashfall, contaminated reservoirs and air quality affect shelter siting, water supply and respirator demand?

**Assumptions:** Assumption: Ash footprint forecasts are uncertain by tens of kilometers (estimate), so shelters are chosen at T+6 with ranked upwind backups, open reservoirs are isolated before ash, and N95 demand may exceed 100,000 (user constraint) within days.

**Assessments:** Title: Environmental Impact Assessment
Description: Evaluates ash, water and air-quality effects on operations.
Details: Risk: shelters in heavier ash require relocating 10,000+ people (estimate). Mitigation: real-time PM10/PM2.5 sensors, backup sites 50+ km upwind (proposed), supplemental N95 stock at Billings or Salt Lake City, reservoir isolation. Note N95s clog quickly in heavy ash, so replacement cycles must be planned. Opportunity: USGS/NOAA plume updates refine siting.

## Question 7 - Which stakeholders (governors, local officials, concessioners, utilities, hospitals, international visitors, outer-zone residents) must be engaged, and how?

**Assumptions:** Assumption: Engagement runs through the Unified Command liaison cell: governors via MOUs, concessioners such as Xanterra for lodge manifests and buses, utilities for grid coordination, and consular and multilingual channels for foreign visitors.

**Assessments:** Title: Stakeholder Engagement Assessment
Description: Maps who must be aligned and the risk of non-compliance.
Details: Risk: conflicting shelter-in-place and evacuation orders cut corridor throughput 20-40% (estimate). Mitigation: unified messaging protocol, published USGS triggers, joint exercises. Non-English visitors may be a large share of the 35,000, so pre-produced multilingual alerts are needed. Opportunity: trusted local radio sustains credibility if escalation reverses earlier guidance.

## Question 8 - What communications, traffic management, logistics tracking and power systems must keep working under ash and tremor, and what are the fallbacks?

**Assumptions:** Assumption: Layers are IPAWS/WEA/NOAA Weather Radio, Guard signal bridging, satellite terminals, highway advisory radio, variable message signs and printed route cards; priority generator fuel goes to hospitals and comms centers.

**Assessments:** Title: Operational Systems Assessment
Description: Tests resilience of comms, power and logistics tracking.
Details: Risk: cell network failure leaves 10-20% of drivers on unintended routes (estimate). Mitigation: deploy repeaters and satellite phones to control points before ash, pre-recorded HAR messages, printed cards. Fuel tiering protects hospitals, comms and shelter kitchens. Test systems in ash-simulation exercises before the window. Use one shared common operating picture across NPS, states and Guard.