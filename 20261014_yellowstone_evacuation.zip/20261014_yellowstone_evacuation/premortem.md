A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Hubs outside the 500 km ring (Denver, Cheyenne) exist with enough verified capacity and will accept evacuees on short notice; distances and capacity are not verified. | Measure distances from the caldera to Denver and Cheyenne, and request written capacity and acceptance statements from both emergency managers within 7 days. | Either hub lies inside 500 km, or combined confirmed capacity is below 50,000 beds, or neither commits to accept evacuees without legislative approval. |
| A2 | Contracts, vendors and convoys can be activated verbally at T+0 and deliver water, fuel and N95 stock within the 12 h dispatch and T+24 h arrival targets without pre-awarded contracts. | Audit existing FEMA contract vehicles for surge clauses and run a dry-run verbal activation with three vendors, timing dispatch. | Any vendor needs more than 12 h to dispatch, or existing vehicles lack surge capacity, or Salt Lake City to Bozeman transit exceeds 30 h in the dry run (estimate). |
| A3 | The public and outer-zone residents will follow staged instructions, and trust holds if shelter-in-place guidance is superseded by a 500 km order, so shadow evacuation stays manageable. | Run a message-comprehension and compliance-intent pilot with 1,000 residents in Bozeman, Gardiner and Cody, using the reversal message sequence. | Stated compliance with time-banded departure is below 70%, or recall of assignment logic is below 80%. |
| A4 | Gallatin Canyon and Gardiner corridors can sustain about 660 vehicles/hour per exit (estimate) under ashfall and tremor, and blockages clear within the 45-minute diversion threshold (proposed threshold). | Commission a rapid geotechnical and staging-lot survey of Gallatin Canyon, Mammoth and West Yellowstone, and time a tow-team dispatch drill to the canyon. | Measured throughput is below 500 vehicles/hour per exit (estimate), tow reach time exceeds 15 minutes (proposed threshold), or clearance of a typical blockage exceeds 4 hours. |
| A5 | Guard signal teams, IPAWS/WEA, HAR/VMS and satellite links will keep drivers and responders connected through ashfall and tremor from T+0, with interoperable radio nets across NPS, state patrol and Guard. | Run an interoperability and ash-degradation test of Guard repeaters, satellite phones and HAR/VMS at three control points, confirming Guard signal unit count. | Any agency pair cannot hold a two-way net at a control point, fewer than 4 signal teams are available by T+1 h, or message delivery to test drivers falls below 90%. |
| A6 | Responder staffing of 100-150 NPS rangers (estimate) plus patrol and Guard, with a 30-50 person standby reserve deployable within 4 h (proposed threshold), can hold 6 h shift limits at every post through T+72 h. | Obtain written headcounts by unit from NPS, state patrol and Guard, and obtain written commitments and mobilization times from the standby reserve agencies. | Confirmed concurrent positions fall below 67, reserve commitments cover fewer than 30 people, or reserve mobilization time exceeds 4 h. |
| A7 | The USD 200 million planning envelope (estimate) and USD 30-35 million free contingency (estimate) cover shelters, hubs and state costs, and the federal versus state/local/host split gets settled before spending is needed. | Obtain written cost-share positions from FEMA and the MT, WY and ID emergency management agencies, and reconcile the readiness package (USD 47.5-87 million, estimate) against the base. | Any state or host community declines cost-sharing, or unfunded items push committed draws above the USD 40 million contingency. |
| A8 | Bozeman, Idaho Falls and the third site can be stocked, staffed and shifted within 4 h (proposed threshold) of a PM10 exceedance, with buses, drivers and backups 50+ km upwind available when needed. | Run a relocation drill of 1,000 volunteers from one shelter to a surveyed backup, timing decision, notification, bus dispatch and intake, and confirm bus and driver counts. | Detection-to-notification exceeds 4 h, majority occupancy at the backup exceeds 8 h (estimate), or fewer than 20 buses are confirmed for relocation. |
| A9 | Visitors, including non-English speakers, vehicle-less and mobility-limited guests, will reach the three exits and follow fixed district-to-gate assignments so that 98% of 35,800 are confirmed out by T+6 h. | Obtain concessioner manifests and run a lodge-level sampling of language, vehicle and mobility shares, plus a gate-assignment comprehension test using route cards in six languages. | Vehicle-less or mobility-limited visitors exceed the confirmed bus and shuttle capacity, or gate-assignment comprehension in the test is below 90%. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Verbal Order That Never Rolled | Process/Financial | A2 | Emergency Logistics and Supply-Chain Director | CRITICAL (16/25) |
| FM2 | The Ring With No Landing | Technical/Logistical | A1 | Scenario Beta Secondary-Stage Destination Planner | CRITICAL (20/25) |
| FM3 | The Reversal That Broke Trust | Market/Human | A3 | Communications and Public Alerting Coordinator | HIGH (12/25) |
| FM4 | The Roster That Ran Dry | Process/Financial | A6 | Responder Safety and Fatigue-Management Officer | CRITICAL (16/25) |
| FM5 | The Canyon That Closed | Technical/Logistical | A4 | Contraflow Operations and Traffic Control Manager | CRITICAL (15/25) |
| FM6 | The Silent Drivers | Market/Human | A5 | Communications and Public Alerting Coordinator | CRITICAL (16/25) |
| FM7 | The Envelope That Split Three Ways | Process/Financial | A7 | FEMA Region VIII Finance and Grants Lead | HIGH (12/25) |
| FM8 | The Shelter Under the Plume | Technical/Logistical | A8 | Ashfall Forecasting and Dynamic Shelter-Siting Officer | CRITICAL (15/25) |
| FM9 | The Guests Who Stayed Behind | Market/Human | A9 | Communications and Public Alerting Coordinator | HIGH (12/25) |


### Failure Modes

#### FM1 - The Verbal Order That Never Rolled

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: Emergency Logistics and Supply-Chain Director
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Plan relies on verbal FEMA activation and 12 h dispatch clauses with no pre-awarded contracts.
- Procurement runs 24-48 h (estimate) and vendors lack surge capacity.
- Convoys leave after T+36 h; shelters ration water for 12-24 h.
- Hub and shelter financing split is unresolved, freezing spending.
- Contingency drained by relocation and resupply.

##### Early Warning Signs
- Any vendor quotes dispatch lead time above 12 h
- FEMA contract audit finds no surge clause for water, fuel or N95
- Federal versus state cost-share unresolved at Month 1 (2026-11-14)

##### Tripwires
- Convoy not dispatched by T+12 h
- Shelter water stock below 24 h of supply at T+18 h
- Vendor dispatch quote above 12 h

##### Response Playbook
- Contain: Activate backup vendors in Pocatello and Butte and release forward-depot water to shelters immediately.
- Assess: Audit inventory, consumption rate and convoy positions at each shelter within 2 hours.
- Respond: Shift to helicopter resupply and tanker fills, and renegotiate contracts with fixed dispatch penalties.


**STOP RULE:** If no signed surge-dispatch contract covers water and fuel by Month 1 (2026-11-14), halt shelter activation planning and escalate to a federal pre-positioning mandate.

---

#### FM2 - The Ring With No Landing

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A1
- **Owner**: Scenario Beta Secondary-Stage Destination Planner
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- Beta order is pre-authorized but second-stage hubs are unverified.
- Denver or Cheyenne distance or capacity falls short.
- Bus, rail and supply routing to hubs undefined.
- Evacuees saturate I-15, I-80 and I-90, blocking Zone Zero exits.
- Delay of 4-8 h (estimate) overlaps ashfall.

##### Early Warning Signs
- Hub distance check places a candidate inside 500 km
- Fewer than 5 hubs with written capacity by T+12 h
- Interstate traffic above 25% saturation before Beta order

##### Tripwires
- Fewer than 5 hubs confirmed at T+12 h
- Confirmed hub capacity below 250,000 beds
- Interstate saturation at or above 40% by T+10 h

##### Response Playbook
- Contain: Hold the 500 km order's outer rings in later time bands and publish the interim hub list at once.
- Assess: Verify hub distances, capacity and ash exposure and count evacuees already moving on interstates.
- Respond: Add hubs at Fort Collins and Casper, pre-position supplies and run bus shuttles on lateral routes.


**STOP RULE:** If fewer than 5 verified hubs with signed MOUs exist by Month 2 (2026-12-14), suspend automatic 500 km authority and revert to a staged decision cell.

---

#### FM3 - The Reversal That Broke Trust

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Communications and Public Alerting Coordinator
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Outer-zone residents told to shelter in place, then ordered out under Beta.
- Reversal read as deception; compliance falls 20-40% (estimate).
- 50,000-200,000 (estimate) residents flee unassigned.
- Corridors clog; governors' competing orders amplify confusion.
- Cell failure removes the corrective channel.

##### Early Warning Signs
- Pilot stated compliance below 70%
- Radio call-in complaints on shelter-in-place messaging rising
- Governor offices issue differing statements

##### Tripwires
- Stated compliance below 70% in pilot
- Corridor traffic exceeds plan by 20% within 2 h of order
- Message recall below 80%

##### Response Playbook
- Contain: Issue one unified superseding message across IPAWS, HAR and trusted radio with governor co-signatures.
- Assess: Measure traffic counts and call volume against time-band targets within 1 hour.
- Respond: Release time bands by county, use secondary routes and publish the indicator values that triggered escalation.


**STOP RULE:** If pilot compliance stays below 70% after two message revisions, abandon shelter-in-place messaging and use time-banded departures only.

---

#### FM4 - The Roster That Ran Dry

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A6
- **Owner**: Responder Safety and Fatigue-Management Officer
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Rangers and patrol fill every post during T+2 to T+8 with no relief depth.
- Reserve commitments are unsigned; Guard activation waits on state approvals.
- Shift limits force post withdrawals; a checkpoint goes dark.
- Overtime and reserve call-ups draw on the contingency.
- Gate G1 slips past T+6 h.

##### Early Warning Signs
- Confirmed headcount below 67 concurrent positions
- Reserve commitment letters cover fewer than 30 people
- Any post under 50% coverage for 30 minutes

##### Tripwires
- Coverage below 50% at any post for 30 minutes
- Reserve not on site within 4 h of request
- More than 3 responders withdrawn for exposure in one shift

##### Response Playbook
- Contain: Consolidate thin posts and request out-of-region Guard immediately.
- Assess: Count staffed positions, hours on shift and N95 stock per post within 1 hour.
- Respond: Rotate the standby reserve in and re-tier posts by mission criticality.


**STOP RULE:** If confirmed responder headcount is below 67 concurrent positions at T+0, restrict the plan to two exits until reserves are seated.

---

#### FM5 - The Canyon That Closed

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A4
- **Owner**: Contraflow Operations and Traffic Control Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- A rockfall or breakdown in Gallatin Canyon blocks the West exit at peak.
- Tow teams cannot reach the site through queued vehicles in ash.
- Secondary slide endangers crews; clearance exceeds 4 hours.
- Diversion overloads US-89 and US-14/16/20, adding 2-4 h transit.
- Zone Zero clearance misses T+6 h.

##### Early Warning Signs
- Slope displacement alerts on canyon sensors
- Tow dispatch drill exceeds 15 minutes
- Queue length at West gate above staging capacity

##### Tripwires
- Blockage lasts more than 45 minutes
- Any M4.0+ event during clearance work
- West exit throughput below 500 vehicles/hour for 60 minutes

##### Response Playbook
- Contain: Halt inbound queueing and divert overflow to the nearest surviving exit.
- Assess: Survey blockage, slope movement and queue length with drones within 30 minutes.
- Respond: Apply the 6 h loss-of-exit rule, rebalance gate split and open bypass track if certified.


**STOP RULE:** If the West exit is not restorable within 6 hours, shelter in place queued vehicles and cancel single-lane clearance attempts.

---

#### FM6 - The Silent Drivers

- **Archetype**: Market/Human
- **Root Cause**: Assumption A5
- **Owner**: Communications and Public Alerting Coordinator
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Cell towers and power fail; WEA and IPAWS stop reaching drivers.
- Guard nets do not interoperate; reroute orders stall at boundaries.
- Drivers and visitors without English rely on rumor and crowd cues.
- Wrong-exit choices unbalance the gate split and fuel shadow flight.
- Public trust in official channels drops.

##### Early Warning Signs
- Interoperability test fails for any agency pair
- Fewer than 4 Guard signal teams confirmed
- Test driver message receipt below 90%

##### Tripwires
- Message receipt below 90% in drill
- Gate load deviates more than 10% from split
- Control point out of contact for 15 minutes

##### Response Playbook
- Contain: Switch to printed route cards, HAR and runners at every control point.
- Assess: Check link status, driver receipt and gate counts within 1 hour.
- Respond: Redeploy signal teams, restore nets and reissue consistent multilingual instructions.


**STOP RULE:** If interoperable nets are not confirmed at all three gates by T+1 h, delay contraflow release and run staged departures by printed card.

---

#### FM7 - The Envelope That Split Three Ways

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: FEMA Region VIII Finance and Grants Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Cost-share for shelters, hubs and state costs stays open.
- States and hosts withhold commitments pending reimbursement terms.
- Hub pre-positioning and shelter stocking stall.
- Relocation and resupply draws consume the USD 40 million contingency (estimate).
- Plan runs short of money at the Scenario Beta trigger.

##### Early Warning Signs
- No written cost-share by Month 1 (2026-11-14)
- Host MOU drafts returned with reimbursement conditions
- Committed draws above 50% of contingency before T+24 h

##### Tripwires
- Free contingency below USD 20 million (estimate)
- Fewer than 3 states signed on cost-share by Month 1 (2026-11-14)
- Any hub MOU unsigned at Month 2 (2026-12-14)

##### Response Playbook
- Contain: Freeze non-critical commitments and ring-fence contingency for relocation and water resupply.
- Assess: Reconcile committed, obligated and unfunded items by line within 24 hours.
- Respond: Seek a federal cost-share declaration and re-sequence hub pre-positioning by ring priority.


**STOP RULE:** If no cost-share agreement covers Beta hubs by Month 2 (2026-12-14), cancel hub-dependent automatic Beta authority and pivot to a staged decision cell.

---

#### FM8 - The Shelter Under the Plume

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Ashfall Forecasting and Dynamic Shelter-Siting Officer
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Ash arrives heavier or farther south than the T+6 h forecast.
- PM10 exceedance detected late; decision slips.
- Buses and drivers already consumed by the evacuation.
- Backup sites lack water, power or registration capacity.
- N95 stock clogs faster than planned.

##### Early Warning Signs
- PM10 above 100 ug/m3 at a shelter
- Sensor feed latency above 2 h (estimate)
- Fewer than 20 buses held in reserve

##### Tripwires
- PM10 above 200 ug/m3 at a primary site
- Relocation not ordered within 4 h of exceedance
- N95 use above 20% of stock per day

##### Response Playbook
- Contain: Issue shelter-in-place with N95 distribution and sealed rooms while buses are marshalled.
- Assess: Compare sensor data with the latest plume run and check backup site readiness within 1 hour.
- Respond: Order staged relocation to ranked upwind backups and release the 100,000 N95 reserve.


**STOP RULE:** If no backup site can accept at least 10,000 people within 8 h of an exceedance, halt new intake at the affected shelter and divert arrivals.

---

#### FM9 - The Guests Who Stayed Behind

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Communications and Public Alerting Coordinator
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Non-English speakers, tour groups and mobility-limited guests miss or misread instructions.
- Vehicle-less visitors wait for transport that is undersized.
- Visitors cross to wrong gates, unbalancing the split.
- Lodge clusters delay Gate G1 beyond T+6 h.
- Stranded groups raise rescue demands in ash.

##### Early Warning Signs
- Concessioner manifests show vehicle-less guests above shuttle capacity
- Gate load deviates over 10% from split
- Route-card comprehension under 90% in test

##### Tripwires
- Fewer than 98% confirmed out at T+6 h
- Any lodge not cleared at T+3 h
- Gate load deviates more than 10% from split for 30 minutes

##### Response Playbook
- Contain: Send concessioner buses and interpreters to uncleared lodges and pause new gate releases.
- Assess: Reconcile manifests against exit counts and map uncleared groups within 1 hour.
- Respond: Reassign gates, run priority shuttles and extend sweeps with relief teams.


**STOP RULE:** If more than 1,000 visitors remain unaccounted for at T+6 h, suspend Zone One phase start until a sweep plan is set.
