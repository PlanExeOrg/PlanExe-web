## 1. Scenario Beta Secondary-Stage Evacuation Plan and Hub Capacity Validation

The plan pre-authorizes a Scenario Beta VEI-7 trigger ordering immediate 500 km evacuation affecting millions, but no second-stage destinations, hub capacity or tiered messaging exist. Without this data, issuing the trigger order will cause uncontrolled shadow evacuation saturating I-15, I-80 and I-90, adding 4–8 hours delay to the primary Zone Zero evacuation and stranding 5,000–20,000 people in ashfall zones. This is the single largest residual cascade-failure risk.

### Data to Collect

- Named ranked shelter hubs (5–10) outside the 500 km ring with verified distances from Yellowstone center
- Shelter capacity (beds, kitchen throughput, medical-staff availability) for 100,000–500,000 additional evacuees per hub
- Signed host-community MOUs confirming bed and medical-staff commitments for 48-hour deployment notice
- Pre-positioned supply estimates (water, N95, food, fuel, medical) at each hub and pre-staging schedule
- Tiered ring-based public messaging (0–100 km organized, 100–250 km time-banded, 250–500 km staged) and published assignment logic

### Simulation Steps

- Use ArcGIS or Google Earth to measure distances from Yellowstone to Denver, Cheyenne, Albuquerque, Las Vegas, Billings, Salt Lake City; confirm which lie outside the 500 km circle
- Contact each hub's emergency management director and large shelter facilities (convention centers, school districts, universities) to request current capacity estimates; cross-reference with FEMA Region VIII and FEMA Region X databases
- Model multi-state evacuation routing using CORSIM or SimTraffic; simulate I-15, I-80, I-90 traffic under 50,000–200,000 unordered evacuees to estimate arrival times at each hub and identify bottlenecks
- Develop a time-banded public-messaging template in Google Docs or Word; test message comprehension with 10–15 volunteer readers (local emergency managers, community leaders) using a 5-point clarity scale
- Estimate food, water and N95 consumption at 100,000–500,000 occupancy over 10 days using FEMA mass-care guidelines; request supply pre-positioning quotes from bottled-water distributors, MRE vendors and N95 suppliers

### Expert Validation Steps

- Request FEMA Region VIII Regional Administrator and FEMA Region X (Seattle) administrator to co-sign the hub feasibility assessment and confirm each hub's willingness to accept the population and supply-surge commitment
- Brief state emergency management directors (Colorado, Wyoming, Utah, Idaho, Montana) on the tiered-message strategy and obtain their approval of the ring-assignment logic and time-banded release schedule
- Invite governors' representatives to a tabletop exercise simulating a Scenario Beta trigger at T+12 h, testing message deployment, hub activation and inter-state coordination; document any jurisdictional conflicts or approval delays
- Consult USGS volcanologist on whether the 500 km ring is geographically defensible given ashfall modeling uncertainty and whether any current hub candidates lie in the modeled plume under different wind scenarios
- Obtain written capacity and supply-commitment MOUs from each hub county or city emergency manager by Month 2 (2026-12-14), signed and legally binding

### Responsible Parties

- FEMA Region VIII Regional Administrator (hub feasibility lead)
- FEMA Region X (Seattle) coordinator for Idaho resources
- UC Incident Commander (decision authority for interim hub list by T+12 h)
- State emergency management directors (MT, WY, ID, CO, UT) for tiered-message approval
- Governor representatives for legal authority confirmation

### Assumptions

- **High:** Denver and Cheyenne lie outside the 500 km ring and have sufficient shelter capacity (beds and kitchens) for at least 50,000 evacuees each within 48-hour notice.
- **High:** Host communities (Denver, Cheyenne, etc.) will formally accept 100,000–500,000 additional people and pre-stage supplies before the eruption window.
- **Medium:** Tiered public messaging (shelter-in-place, then time-banded, then organized) can be executed without eroding public trust if escalation reverses earlier guidance.
- **Medium:** Supply convoys from secondary hubs (Billings, Salt Lake City, Boise) can reach stranded Zone Beta evacuees within 24–48 hours under ashfall and road congestion.
- **Medium:** Scenario Beta ring boundaries and time-banded release windows can be communicated clearly enough to reduce uncontrolled evacuation to <10% of the affected population.

### SMART Validation Objective

By Month 1 (2026-11-14), validate that at least five ranked hubs outside the 500 km ring have signed MOUs confirming combined capacity for 250,000+ additional beds and water/N95 pre-positioning schedules. By Month 2 (2026-12-14), execute tiered-message pilot with 1,000+ residents in Zone One communities (Bozeman, Gardiner, Cody) and measure message comprehension (target: ≥80% recall of assignment logic) and stated compliance intent (target: ≥70% stated willingness to follow time-banded schedule).

### Notes

- If distance verification shows Denver or Cheyenne are actually inside the 500 km ring due to Yellowstone's geographic offset from assumed center, substitute Albuquerque, Las Vegas or Denver metropolitan secondary hubs (e.g., Fort Collins, Greeley).
- Supply pre-positioning at secondary hubs is a USD 20–40 million line item; confirm federal vs. state/local/host-community funding split before Month 1 (2026-11-14) to avoid budgetary disputes.
- Tiered-message testing must include foreign-language cohorts (Spanish, Japanese) to confirm that escalation messaging does not appear contradictory in translation.
- The interim ranked hub list is due by T+12 h (within the 72-hour window); this data must be finalized by Month 1 (2026-11-14) so it can be published to the public pre-event.
- Scenario Beta pre-authorization is meaningless without an executable second-stage plan; treat this as a blocking dependency for UC authority.


## 2. Responder Exposure Limits, Relief Depth and Separate N95 Inventory Sizing

The plan budgets 100–150 NPS rangers at a 1.5 relief ratio, yielding 67–100 concurrent positions across three exits and perimeters during the T+2 to T+8 peak evacuation. A single traffic incident or responder injury will halt one checkpoint for 2–4 hours, stranding 500–2,000 vehicles in ashfall and cascading 2–4 hours delay to the entire evacuation. Relief depth must be confirmed, standby reserves pre-positioned and responder N95s sized separately to prevent this single-point failure.

### Data to Collect

- Confirmed headcount of NPS rangers, state highway patrol, National Guard and utility responders who will staff traffic checkpoints, perimeters and comms sites
- Responder role-to-asset mapping (e.g., which positions require continuous 24/7 coverage and which can operate on a 6-hour-on, 12-hour-off rotation)
- Named 30–50 out-of-region responder reserve (Colorado Parks and Wildlife, Wyoming Game and Fish, Idaho Department of Lands) with written pre-event commitments and staging depot location
- Fort Carson (Colorado National Guard) and state Guard Joint Task Force pre-authorization for rapid personnel reinforcement without state adjutant-general approval delays
- Responder N95 consumption rate (masks per responder per 6-hour shift in light vs. heavy ashfall) and total separate responder N95 inventory requirement (estimate: 150,000–200,000 units)

### Simulation Steps

- Survey NPS LE Rangers, Montana/Wyoming/Idaho highway patrol and National Guard units via questionnaire to estimate available personnel by unit/district and their pre-event training status (contraflow, hazmat, hand signals under noise/ash).
- Map each traffic checkpoint (Mammoth, Gardiner, West Yellowstone, Cody) to required personnel: assume 2 rangers per checkpoint (one outbound direction, one inbound/return), 2 state patrol (traffic direction), 1 National Guard (supplies/comms) = 5 people per checkpoint. Three checkpoints × 5 people = 15 base staff. Multiply by 4 shifts (24 hours ÷ 6 hours per shift) = 60 people needed for continuous coverage. Compare against available rangers (100–150 estimate); if shortfall exists, that is relief-depth deficit.
- Model responder N95 consumption: assume 2 masks per responder per 6-hour shift in light ashfall (PM10 <100 µg/m³, normal clogging rate). Heavy ashfall (>300 µg/m³) may consume 4–6 masks per shift due to faster clogging. Over 72 hours at 4 shifts, one responder needs 8 masks (light) to 24 masks (heavy). At 300–500 responders, total = 2,400–12,000 masks. This is conservative; add 50% safety margin = 3,600–18,000. Round to 150,000–200,000 as a precaution across all response scenarios.
- Use an online shift-scheduling tool (e.g., When I Work or Deputy) to simulate 6-hour shifts with 2-hour rest and 18-hour withdrawal limits for 100–150 rangers across four checkpoints over 72 hours. Calculate the minimum relief depth (how many additional staff are needed to maintain 50% coverage at each post during peak T+2 to T+8 hours).
- Request written quotes from Fort Carson personnel office and Wyoming/Montana Guard Joint Task Force for the cost of pre-positioning 50–100 responders at Billings or Cheyenne and the time needed for deployment authorization.

### Expert Validation Steps

- Brief the NPS Incident Commander and state highway-patrol commanding officers on the relief-depth analysis and request written confirmation of actual available personnel by unit/district by Month 0 (2026-10-14).
- Request a written pre-event commitment letter from Fort Carson (Colorado National Guard) and the Wyoming and Montana Guard adjutants general confirming authority for the forward UC to request personnel reinforcement without waiting for state-by-state approval (via FEMA authority); target signature by Month -0.5 (2026-09-29).
- Schedule a 6-hour shift-rotation exercise at a key checkpoint (Mammoth or Gardiner) by Month -0.5 (2026-09-29), involving actual ranger and highway-patrol personnel, testing the 6-hour shift limit, 2-hour rest protocol, N95 replacement procedures and fatigue-assessment checklists under simulated ashfall conditions (use fog machines or ash-simulation powder).
- Consult the CDC or OSHA occupational-health specialist on responder N95 clogging rates under volcanic ashfall (grain-size 10–100 µm) and recommend validated replacement cycles per ashfall intensity level.
- Coordinate with the UC Logistics Chief to confirm that separate responder N95 stock (150,000–200,000 units) is pre-staged at a dedicated responder supply depot (not co-mingled with the 100,000 civilian stock) and that replacement logistics are contracted for 4-hour resupply cycles if consumption exceeds 20% of stock per day.

### Responsible Parties

- NPS Incident Commander (responder headcount and availability confirmation)
- Montana, Wyoming and Idaho highway patrol commanding officers (personnel contributions and relief protocols)
- Fort Carson Colorado National Guard (reinforcement pre-authorization and 4-hour deployment capability)
- UC Logistics Chief (separate responder N95 inventory staging and resupply contracting)
- Colorado Parks and Wildlife, Wyoming Game and Fish, Idaho Department of Lands (standby reserve recruitment and staging)

### Assumptions

- **High:** 100–150 NPS rangers at 1.5 relief ratio provides at least 67–100 concurrent positions for three checkpoints and perimeter patrol; actual availability matches this estimate.
- **High:** A 30–50 person standby reserve from Colorado Parks and Wildlife, Wyoming Game and Fish and Idaho Department of Lands can be deployed within 4 hours if any checkpoint coverage falls below 50%.
- **Medium:** Fort Carson and state Guard Joint Task Force will pre-authorize forward UC authority to request reinforcement without state adjutant-general approval delays (Stafford Act emergency authority).
- **Medium:** Responder N95 consumption can be estimated at 2–4 masks per 6-hour shift depending on ashfall intensity; total separate responder stock requirement is 150,000–200,000 units (estimate).
- **Medium:** A 6-hour shift limit with 2-hour rest cycles and 18-hour withdrawal is operationally achievable and does not introduce unacceptable coverage gaps at critical checkpoints.

### SMART Validation Objective

By Month 0 (2026-10-14) (T+6 h), obtain written confirmation from NPS Incident Commander and state highway patrol of actual available responder headcount by unit/district. By Month -0.5 (2026-09-29), execute a 6-hour shift-rotation exercise at Mammoth or Gardiner checkpoint with actual ranger and patrol personnel, validating shift limits, N95 replacement, fatigue-assessment accuracy and radio continuity. By Month 0 (2026-10-14) (T+0), stage separate responder N95 inventory (150,000–200,000 units) at a dedicated depot with 4-hour resupply agreement and confirm Fort Carson pre-authorization for rapid Guard reinforcement.

### Notes

- If shift-rotation exercise reveals that 6-hour limits consume staffing too aggressively, revise to 8-hour shifts with 4-hour rest, recalculating relief ratio and standby-reserve size.
- Responder N95 mask type (FFP2, N95 or KN95) must be specified by the UC based on OSHA standards; different mask types have different clogging rates and replacement cycles.
- The 30–50 standby reserve is a contingency; if the exercise shows relief depth is adequate without it, the reserve can be stood down post-exercise. However, do not stand down until actual shift-rotation data confirms adequate coverage.
- Responder fatigue-assessment checklists must be simple enough for on-site checkpoint leaders to administer without training (e.g., reaction-time test, recall of a 3-digit number, difficulty maintaining concentration). Pre-test the checklist with 5–10 rangers before the exercise.


## 3. Real-Time Ashfall Monitoring and Dynamic Shelter-Relocation Protocols

The plan selects shelter sites at T+6 h based on a single NOAA/USGS forecast with documented ±50 km uncertainty. If actual ashfall diverges from forecast or doubles in intensity, 10,000–15,000 evacuees will be sheltered in moderate-to-heavy ash within 12–24 hours, requiring emergency relocation. Without real-time PM10 monitoring, backup-site pre-authorization and relocation protocols, shelters will be rendered untenable mid-operation, stranding 200–500 evacuees and overwhelming hospitals with respiratory-distress cases.

### Data to Collect

- PM10 and PM2.5 concentration data feeds from continuous sensors at Bozeman, Idaho Falls and the forward command element (Livingston or Bozeman), updated hourly from T-12 h through T+72 h
- Visual ash-depth measurement stations at each shelter and forward command (physical ash-depth markers, photographs or LIDAR backscatter for automated detection)
- USGS Volcanic Ash Forecast Transport (VAFT) and NOAA plume updates issued every 3 hours with concentration outputs at 1,000 ft, 5,000 ft and 10,000 ft above each shelter location
- Named ranked backup shelter locations 50+ km upwind of each primary site (Bozeman, Idaho Falls, third site), surveyed and pre-authorized for rapid 4-hour occupancy transfer
- Shelter-relocation decision rule: thresholds for updating shelter site selection (PM10 >50 µg/m³ triggers forecast update; >100 µg/m³ triggers shelter-suitability review) and automatic relocation trigger (measured ashfall exceeds forecast by >50%, or PM10 >200 µg/m³ at primary site within 6 hours)

### Simulation Steps

- Obtain a USGS Volcanic Ash Forecast Transport model or access NOAA's Volcanic Ash Advisory Center (VAAC) system via NOAA's website. Input Yellowstone as the source and generate 12-hour forecasts for multiple wind scenarios (northerly, southerly, easterly) to model ashfall paths to Bozeman, Idaho Falls and alternate sites. Document concentration contours (50, 100, 200 µg/m³) for each scenario.
- Use an online ashfall dispersion tool (e.g., Ash3d simulator from USGS or the HYSPLIT model from NOAA) to quantify ashfall uncertainty under different emission assumptions (plume height, VEI magnitude). Generate 10–20 ensemble forecasts and measure the spatial spread (95% confidence interval) of the PM10 plume at 6, 12 and 24 hours.
- Survey potential backup shelter locations in Montana and Idaho (schools, convention centers, National Guard armories) 50+ km upwind of Bozeman and Idaho Falls using Google Earth or ArcGIS. Estimate occupancy capacity and water/power/sanitation infrastructure for 5,000–15,000 people. Record GPS coordinates and contact information for facility managers.
- Simulate a shelter-relocation exercise: assume actual ashfall at T+12 h measures 150 µg/m³ at Bozeman (primary site) while the latest VAFT forecast (T+9 h update) predicted 50 µg/m³. This is a 3x exceedance and a 100 km southward shift (primary site now in moderate ash). Document the time required for the shelter manager and forward UC to: (1) detect the exceedance (arrival of real PM10 data), (2) decide on relocation, (3) notify occupants via IPAWS/WEA, (4) mobilize buses and drivers, (5) complete occupancy transfer to a backup site. Target: <4 hours from detection to notification; <8 hours to majority occupancy at backup site.
- Model N95 consumption under different ashfall intensities using FEMA guidelines: assume 1 mask per person per 6 hours in light ashfall (PM10 <100 µg/m³), 2–3 masks per person per 6 hours in moderate ashfall (100–300 µg/m³), 4–6 masks per person per 6 hours in heavy ashfall (>300 µg/m³). At 25,000 occupancy and 10 days, calculate total mask requirement for each scenario and compare against 100,000 civilian + 100,000 reserve stock.

### Expert Validation Steps

- Invite a USGS volcanologist (Yellowstone Volcano Observatory) to validate the ashfall forecast model accuracy for Yellowstone, discuss known model biases (e.g., southward bias in wind transport), and recommend forecast-update frequency and concentration thresholds for shelter-siting decisions.
- Request NOAA National Weather Service (Billings or Riverton, WY forecast office) to commit in writing to issuing Volcanic Ash Forecast Transport updates every 3 hours from T-24 h through T+72 h with explicit PM10 concentration outputs at 1,000 ft, 5,000 ft and 10,000 ft above Bozeman, Idaho Falls and the third shelter site.
- Consult a PM10 sensor manufacturer (e.g., Plantower, Alphasense or Teledyne Technologies) to confirm sensor accuracy under ashfall conditions, clogging rates and data-transmission reliability over satellite links. Obtain a 72-hour field-deployment agreement and spare-parts/battery support.
- Brief shelter facility managers (Bozeman and Idaho Falls) on shelter-relocation protocols, including rapid occupancy-transfer decision timelines, bus dispatch procedures, re-triage and re-registration procedures at backup sites, and supply-chain continuity (water, food, N95) during transition.
- Conduct a tabletop shelter-relocation exercise with USGS, NOAA, the forward UC, shelter managers and Guard logistics 30 days before the eruption window (Month -0.5, 2026-09-29), simulating ashfall at T+12 h that exceeds forecast by 50 km or doubles in intensity. Measure decision latency and identify any coordination gaps between ashfall data, UC decision authority and bus dispatch.

### Responsible Parties

- USGS Yellowstone Volcano Observatory scientist-in-charge (forecast validation and uncertainty quantification)
- NOAA National Weather Service Volcanic Ash Forecast Transport coordinator (3-hourly forecast updates and concentration outputs)
- UC Ashfall Forecasting and Dynamic Shelter-Siting Officer (real-time sensor monitoring and relocation-decision authority)
- Bozeman and Idaho Falls shelter facility managers (occupancy-transfer logistics and re-triage protocols)
- National Guard logistics chief (bus dispatch and supply-chain continuity during relocation)

### Assumptions

- **Medium:** PM10 sensors can be deployed at three sites with hourly data transmission via satellite or cellular backup, with <2-hour latency from sensor reading to forward UC dashboard.
- **Medium:** NOAA VAFT model updates every 3 hours will be available and transmitted to the forward UC within 1 hour of issuance, enabling near-real-time concentration forecasts for shelter-siting decisions.
- **Medium:** Ranked backup shelter locations 50+ km upwind can be identified before Month 0 (2026-10-14) and pre-authorized for rapid 4-hour occupancy transfer with no additional staffing or licensing delays.
- **High:** A 4-hour shelter-relocation decision-to-notification timeline is achievable; actual bus dispatch and occupancy transfer may require 6–12 hours (estimate), stranding evacuees temporarily.
- **Medium:** N95 consumption under heavy ashfall (>300 µg/m³) can be modeled reliably using FEMA guidelines; actual consumption may exceed estimates by 2–3x if masks clog faster than anticipated (estimate).

### SMART Validation Objective

By Month -0.5 (2026-09-29), deploy PM10/PM2.5 sensors at Bozeman, Idaho Falls and forward command with confirmed 4-hour data-transmission capability. By Month -0.5 (2026-09-29), obtain signed NOAA commitment for 3-hourly VAFT updates with concentration outputs at three shelter elevations. By Month 1 (2026-11-14), complete survey and pre-authorization of at least three ranked backup shelter locations per primary site. By Month -0.5 (2026-09-29), execute a tabletop shelter-relocation exercise and measure decision latency from PM10 exceedance detection to UC relocation order (<2 h target).

### Notes

- PM10 sensor accuracy under ashfall is critical; if sensors show >20% variance vs. official NOAA/USGS estimates, the relocation-decision credibility will be questioned. Include sensor cross-calibration with USGS equipment in the deployment protocol.
- Ashfall forecast uncertainty of ±50 km means shelter siting is inherently probabilistic. Consider a ranking system: primary site (50–70% confidence), backup 1 (20–30% confidence), backup 2 (<10% confidence) based on ensemble forecast spread.
- The 4-hour relocation decision rule assumes buses, drivers and pre-authorization are ready at T+0. If buses are consumed in primary evacuation, relocation will be delayed 6–12 hours. Pre-stage additional buses (estimate: 20–30 buses reserved for relocation) at forward command.
- Backup shelter occupancy-transfer logistics (re-triage, re-registration, food service startup) are complex and time-intensive. Conduct a dry-run relocation with 500–1,000 volunteer evacuees 30 days before the eruption window to validate 8-hour transfer timelines.


## 4. Water Supply Chain Validation: Dispatch Timeline, Forward-Depot Pre-Positioning and Ashfall-Impact Testing

The plan targets water arrival at shelters by T+24 h, but estimates realistic delivery time as T+18–30 h. Without forward-depot pre-positioning, shelters must ration water for the first 18–24 hours, risking dehydration in 10,000–20,000 evacuees. Municipal water sources become ash-contaminated within 4–6 hours and are unsafe without treatment. This data collection validates the water supply chain from source through shelter intake and identifies contingency backup sources (groundwater, tanker fills) to ensure T+24 h water availability without relying solely on distant convoys.

### Data to Collect

- Realistic convoy travel time from Salt Lake City to Bozeman and Idaho Falls shelters under ashfall visibility reduction (estimate: 18–30 hours, not 12 hours) and evacuation-traffic congestion (estimate: 25–40% I-15 saturation by Hour 8–12)
- Forward-depot water pre-positioning schedule and capacity: 200,000–300,000 liters at Bozeman and 100,000–150,000 liters at Idaho Falls by T+0, with 4-hour resupply contracts from three backup suppliers (Salt Lake City, Pocatello, Butte)
- Identified water sources and treatment timelines for municipal contamination response: settling time, filtration requirements, turbidity thresholds for continued use at Bozeman and Idaho Falls water districts
- Backup groundwater or tanker-fill stations (e.g., wells, springs, potable-water storage tanks) at Bozeman and Livingston with pre-tested pump/hose interfaces and 24-hour operator availability
- Validated water-consumption model: 1.43 million liters for 35,800 shelter occupants at 4 L/person/day over 10 days; breakdown by category (drinking, cooking, hygiene, medical) and contingency for increased demand under stress or medical surge

### Simulation Steps

- Conduct a realistic convoy-routing exercise from Salt Lake City (3 distribution centers: Culligan, USA Water, Nestlé Waters) to Bozeman and Idaho Falls under simulated ashfall and evacuation traffic. Assume: (1) ashfall reduces I-15 visibility to 50–100 meters, safe speed 10 mph (not 60 mph); (2) evacuation traffic saturation at 25–40% on I-15 northbound by Hour 8–12, delaying non-priority traffic; (3) ashfall-dust contaminates vehicle windows and air filters, requiring frequent stops for cleaning. Measure actual travel times using a Google Maps simulation with traffic-layer data and manual speed reductions. Expected outcome: 18–30 hours (not 12 hours).
- Contact Bozeman and Idaho Falls water districts (Gallatin County, Bonneville County public utilities) to request water-system emergency-response plans: settlement basins, filtration capacity, turbidity thresholds for ash-contaminated municipal water. Simulate 500–1,000 µm/kg ashfall ash-particle concentration at 100 µm grain size and model settling time (estimate 24–48 hours for 90% particle removal). Quantify how long municipal water is non-potable and at what ashfall level.
- Identify and survey groundwater or alternative-water sources within 50 miles of shelters (wells, storage tanks, potable-water distribution depots). Use USGS water-resource databases and contact local water-district operators. Measure depth to water table, pump capacity, power requirements and hose/interface compatibility with shelter filling systems.
- Obtain operational quotes from three water-supply vendors (e.g., basin Water, Great Lakes Water, United Water) for 12-hour and 24-hour dispatch of bottled-water convoys (2,000–3,000 gallons per truck × 10–15 trucks = 20,000–45,000 gallons per trip) from Salt Lake City, Pocatello and Butte. Document lead-time, cost, minimum order size and surge-rate pricing.
- Model water consumption at 35,800 shelter occupants under baseline and stress scenarios: baseline 4 L/person/day (drinking 1.5, cooking 1, hygiene 1, laundry 0.5) = 143,200 L/day. Stress scenario (diarrheal disease, heavy ash contamination requiring frequent handwashing): 6 L/person/day = 214,800 L/day. Over 10 days: 1.43–2.15 million liters. Cross-check with FEMA mass-care guidelines (typically 5 gallons/person/day = 19 L/person/day for all uses, higher than the baseline estimate). Adjust upward to 2 million liters as contingency.

### Expert Validation Steps

- Request Montana-Dakota Utilities, Idaho Power and Bozeman/Idaho Falls water-district general managers to brief the UC on water-system ashfall impact and emergency-isolation protocols (e.g., intake isolation, bypass to standby storage) during volcanic ashfall.
- Consult a water-treatment engineer (EPA or state water-resource specialist) on ash-particle concentration thresholds that render municipal water non-potable and on acceptable settling/filtration timelines and costs to restore potability.
- Contact USGS National Water-Quality Assessment Program or a regional hydrogeologist to validate groundwater survival likelihood (ashfall does not typically contaminate groundwater aquifers, though surface intakes may be affected; confirm for Bozeman and Idaho Falls hydrologic settings).
- Arrange a site visit with Bozeman and Idaho Falls public-works departments to verify water-system infrastructure drawings, intake locations, treatment-plant capacity and emergency-isolation capability. Confirm that emergency shutdown and bypass-to-storage procedures are feasible within 2–4 hours of ashfall onset.
- Execute a water-convoy exercise from Salt Lake City to Bozeman 30 days before the eruption window, driving under fog-machine ashfall simulation (visibility reduced to 50–100 meters, require safety vest fluorescence and headlight clarity checks), measuring actual travel time and driver fatigue effects. Target: 18–30 hour arrival time, document any mechanical or fueling delays.

### Responsible Parties

- Emergency Logistics and Supply-Chain Director (forward-depot pre-positioning and resupply contracts)
- Bozeman and Idaho Falls public-works directors (water-system emergency protocols and municipal-water contamination response)
- Montana-Dakota Utilities, Pacific Power and Idaho Power operations managers (grid-failure planning and emergency load shedding if water-pumping loses power)
- USGS National Water-Quality Assessment Program or state hydrogeologist (groundwater vulnerability assessment)
- Water-supply vendors (Salt Lake City, Pocatello, Butte bottled-water distributors for surge-rate and 12-hour dispatch contracts)

### Assumptions

- **High:** Realistic convoy travel time from Salt Lake City to Bozeman/Idaho Falls under ashfall and evacuation traffic is 18–30 hours (not 12 hours), requiring forward-depot pre-positioning to meet T+24 h shelter-supply targets.
- **High:** Forward-depot pre-positioning of 200,000–300,000 liters at Bozeman and 100,000–150,000 liters at Idaho Falls by T+0 is feasible and contracts for 4-hour resupply from backup suppliers (Pocatello, Butte) are executable.
- **Medium:** Municipal water systems at Bozeman and Idaho Falls can be isolated or shut down within 2–4 hours of ashfall onset and diverted to alternative sources (groundwater, storage tanks, bottled water) without extended outage.
- **Medium:** Groundwater sources (wells, aquifers) near Bozeman and Idaho Falls are protected from ashfall surface contamination and can supply 10,000–20,000 L/day per location as emergency backup.
- **Low:** Water-consumption baseline of 4 L/person/day is adequate for drinking, cooking and hygiene under ashfall conditions. Stress scenarios may exceed 6 L/person/day due to disease or contamination concerns.

### SMART Validation Objective

By Month -0.5 (2026-09-29), execute a water-convoy exercise from Salt Lake City to Bozeman under ashfall simulation, documenting realistic travel time (target: 18–30 hours). By Month 0 (2026-10-14) (T+0), stage 200,000–300,000 liters at Bozeman and 100,000–150,000 liters at Idaho Falls forward depots, with signed 4-hour resupply contracts from Pocatello and Butte suppliers. By Month 1 (2026-11-14), validate that Bozeman and Idaho Falls water systems have documented emergency-isolation and backup-source protocols, and that groundwater or alternative-water sources can supply ≥10,000 L/day as emergency backup.

### Notes

- If ashfall visibility reduction drops below 50 meters and I-15 becomes impassable, ground convoy may be diverted to I-80 (further east) or I-70 (further south), extending travel time to 24–36 hours. Pre-identify alternate routes and test them in the exercise.
- Forward-depot pre-positioning of water at Bozeman and Idaho Falls (USD 50,000–100,000 initial stocking + 4-hour resupply logistics) is a contingency cost; confirm federal vs. state/local funding split before Month 0 (2026-10-14).
- Water-contamination risk from ashfall is primarily a turbidity/filtration issue (ash particles block water-treatment filters, not toxicity from ash itself unless heavy metals are present in the ash deposit). Confirm with USGS that Yellowstone ashfall is expected to be basaltic (low metal content) rather than rhyolitic (higher metal and fluorine content).
- If municipal water intakes are contaminated and groundwater is unavailable, bottled-water shelters will require 2–5 million liters over 10 days (stress scenario). Pre-contract additional supplying capacity (ice-cream trucks, tanker trucks, bulk distributor shipments) as backup to the 12-hour convoy.
- Power loss at water-pumping and treatment facilities is a secondary risk; coordinate with utility operators to ensure backup generator fuel and UPS systems are in place to keep water flowing during grid outages.


## 5. Geotechnical Road Hazard Assessment: Gallatin Canyon Single-Lane Clearance Feasibility and South Entrance Bypass Viability

The plan pre-positions two tow/rockfall teams to reach Gallatin Canyon within 15 minutes and sets a 45-minute blockage threshold before diversion. However, no geotechnical data exists to validate clearance feasibility, secondary-slide risk or the time estimates. If Gallatin Canyon clearance actually requires 6–12 hours (as documented in similar volcanic or seismic events), the 15-minute arrival and 45-minute threshold are infeasible. Proceeding without this data risks either (1) committing equipment to a clearance attempt that cannot succeed and exposes crews to secondary-slide hazard, or (2) abandoning the corridor prematurely and overloading surviving exits. This data collection informs the go/no-go decision for single-lane clearance and the loss-of-exit contingency trigger.

### Data to Collect

- Gallatin Canyon slope-stability survey: identification of slide-prone zones, debris-accumulation potential, secondary-slide probability during clearance work, and safe turn-out locations for equipment staging
- South Entrance landslide-debris quantification: debris volume, slope gradient, ground-water seepage status and secondary-slide triggering mechanisms under continued seismic swarm
- Time-to-clearance estimates for single-lane opening through Gallatin Canyon blockage under ashfall conditions (reduced visibility, ashfall-dust contamination of equipment, personnel fatigue)
- Bypass-route options: temporary single-lane track routing around the South Entrance slide, with load-bearing capacity for light-duty vehicles (estimate 500–1,000 vehicles/day max throughput)
- Seismic-activity triggering criteria for abort: pre-authorized hard thresholds (e.g., M4.0+ event during clearance work, >2 cm slope displacement on incipient-failure zones) that halt work and trigger diversion

### Simulation Steps

- Request a USGS geotechnical field team (Volcano Disaster Assistance Program or Cascades Volcano Observatory) to conduct a rapid survey of Gallatin Canyon (10 km highest-risk section) and the South Entrance landslide 60 days before the eruption window. Deliverables: (1) geotechnical log with slope angles, failure modes and rockfall-size estimates; (2) ground-water seepage assessment; (3) secondary-slide probability if clearance work destabilizes upper slopes; (4) sketches of safe crew-staging areas and equipment-deployment zones.
- Model debris-removal time using historical slide-clearance data: typical wet-weather debris removal from a 10 m blockage on a two-lane mountain road requires 2–4 hours (estimate) with a mobile wrecker and debris chipper. Under ashfall (visibility <100 meters, ash-coated equipment), add 50% time penalty (3–6 hours estimate per 10 m). If the South Entrance slide or a Gallatin Canyon blockage is >50 m in debris, clearance time exceeds 10–20 hours, violating the 4-hour time-box and 45-minute diversion threshold.
- Conduct a photogrammetry and ground-penetrating-radar survey of the South Entrance slide to quantify debris volume (estimate: 10,000–100,000 cubic meters, order-of-magnitude), slope stability under seismic swarm loading, and probability of secondary failure if heavy equipment disturbs the slide mass. Compare the debris volume to available clearing equipment capacity (typical debris chipper: 50–200 cubic meters/day); if debris exceeds equipment capacity, single-lane clearance is infeasible.
- Identify and sketch potential bypass routes around the South Entrance slide or Gallatin Canyon blockage using satellite imagery (Google Earth, USGS topography) and field survey. Design temporary single-lane track segments with grade, turn radius and load-bearing capacity for evacuation vehicles (assume 2,000–3,000 lb single-axle load). Estimate construction/grading time (4–8 hours for a 2–3 mile temporary track) and equipment needed (bulldozer, roller, grader).
- Model the loss-of-exit scenario: if Gallatin Canyon blockage requires 10+ hours to clear, it exceeds the 4-hour time-box and triggers the 45-minute diversion rule. Divert all traffic to US-89 (North) and US-14/16/20 (East) exits, increasing load on those corridors from 30% and 20% to 50% and 40% (estimate), adding 2–4 hours to transit time for the diverted 50% cohort. Simulate this in a traffic-flow model (CORSIM, SimTraffic) to quantify the cascading delay.

### Expert Validation Steps

- Brief the USGS Yellowstone Volcano Observatory scientist-in-charge and the USGS Volcano Disaster Assistance Program on the clearance-feasibility question and obtain a written assessment of whether the Gallatin Canyon or South Entrance blockage is clearable within 4 hours given ashfall conditions.
- Request a professional geotechnical engineer (registered PE in Montana or Wyoming, specializing in slope stability) to review the USGS survey and provide a written opinion on secondary-slide probability during clearance work and the viability of the abort triggers (M4.0+ seismic event, >2 cm slope displacement).
- Coordinate with the Wyoming and Montana departments of transportation to confirm availability of heavy-equipment crews (dozers, graders, debris chippers) for a 4-hour mobilization and the pre-positioning location (Mammoth, Spanish Creek) that guarantees 15-minute reach to Gallatin Canyon.
- Consult the FAA (if helicopters will be used for debris removal or surveying) and the Forest Service (if the bypass route crosses National Forest land) to confirm permits and environmental-clearance requirements for emergency access.
- Execute a site survey and equipment-positioning exercise at Mammoth and Spanish Creek 30 days before the eruption window to confirm 15-minute reach time to Gallatin Canyon under ashfall simulation (fog machines, visibility reduction to 50–100 meters, require spotters and manual communication).

### Responsible Parties

- USGS Volcano Disaster Assistance Program or Cascades Volcano Observatory geotechnician (slope-stability survey and secondary-slide risk assessment)
- Professional geotechnical engineer (registered PE) (secondary opinion on clearance feasibility and abort triggers)
- Montana and Wyoming departments of transportation (equipment pre-positioning and heavy-equipment crew availability)
- NPS Incident Commander or UC Contraflow Operations Manager (go/no-go decision authority for clearance attempts)

### Assumptions

- **High:** Gallatin Canyon blockage can be cleared to single-lane within 4 hours under ashfall conditions; if clearance requires >6 hours, the 45-minute diversion threshold is infeasible and the corridor should be written off.
- **High:** Pre-positioned tow and rockfall teams can reach Gallatin Canyon within 15 minutes from Mammoth or Spanish Creek under ashfall visibility reduction (50–100 meters); if actual reach time is >30 minutes, the threshold should be revised.
- **Medium:** Secondary-slide probability during clearance work is <10% if the slope is stable and clearance crews follow geotechnical-spotting protocols; if probability exceeds 20%, clearance should be abandoned as too hazardous to crews.
- **Medium:** A temporary bypass route around the South Entrance slide is feasible and can be constructed/graded in 4–8 hours, providing an alternate single-lane exit for light-duty vehicles and emergency traffic.
- **Medium:** Hard abort triggers (M4.0+ seismic event, >2 cm slope displacement) are detectable in real time using pre-positioned motion sensors or drone-based monitoring, enabling immediate halt of clearance work before crew entrapment.

### SMART Validation Objective

By Month -1.5 (2026-08-29, assuming month-length recalculation for pre-event planning), conduct a full geotechnical survey of Gallatin Canyon (10 km highest-risk section) and the South Entrance slide, documenting debris volume, slope stability and secondary-slide probability. By Month -1 (2026-09-14), obtain written feasibility assessment from professional geotechnical engineer on single-lane clearance time (target: ≤4 hours) and abort triggers. By Month -0.5 (2026-09-29), execute a site survey and equipment-positioning exercise at Mammoth and Spanish Creek, validating 15-minute reach time to Gallatin Canyon under ashfall simulation.

### Notes

- If geotechnical survey concludes that clearance is infeasible or exceeds the 4-hour time-box, the plan should explicitly write off Gallatin Canyon as an exit option and reallocate all traffic to US-89 (North, 50%) and US-14/16/20 (East, 50%), abandoning the 50/30/20 three-exit split. This requires revision of the contraflow-operation plan.
- Secondary-slide risk to crews is the highest safety concern; abort triggers should be conservative and non-negotiable. If M4.0+ seismic activity occurs during work, crews must withdraw immediately and the corridor must be abandoned.
- The 15-minute reach-time assumption is optimistic for ashfall conditions (visibility <100 meters, ashfall-clogged engine air filters, personnel fatigue). Field-test under ashfall simulation and revise reach-time expectation to 20–30 minutes if data supports it.
- If bypass routes are identified around Gallatin Canyon or South Entrance, they should be surveyed and graded (within the 4-hour time-box) during the pre-event mobilization phase (T-24 to T+0), not during the evacuation crisis. This reduces the real-time demand on heavy equipment and crew.
- Environmental permitting for bypass construction on Forest Service or state land must be negotiated and pre-authorized before the eruption window to avoid 48+ hour delays during the 72-hour evacuation.


## 6. Multi-State Authority Structure and Boundary Coordination Officer Decision Authority Validation

The plan specifies a Boundary Coordination Officer with pre-authorized decision authority, but the Officer's position is not formally created, authority is not delegated by governors in writing and the three state on-scene commanders' acceptance of reduced approval authority is not documented. Without this validation, the Boundary Coordination Officer's reroute decisions will face jurisdictional challenge or delay when implemented during the crisis, potentially halting traffic for 15–45 minutes while approvals cascade through state adjutants general or emergency management chains. This data collection formalizes authority, documents pre-event delegation and validates that multi-state coordination can function under time pressure.

### Data to Collect

- Written pre-event authorization letters from the governors of Montana, Wyoming and Idaho explicitly confirming authorization of Unified Command Zone One and Scenario Beta evacuation orders
- Signed MOUs among NPS, FEMA, Montana DOT, Wyoming Highway Patrol and Idaho Transportation Department specifying exact boundary-transfer checkpoints (Mammoth on US-89, Gallatin County line on US-191, Cody city limits on US-14/16/20)
- Written delegation protocol defining that state on-scene commanders (highway patrol, National Guard) have pre-authorized authority to issue temporary reroutes without requesting NPS ranger approval (5-minute reroute window without higher approval)
- Boundary Coordination Officer position description, decision authority matrix and communications protocol (secure satellite phone/radio links to NPS incident commander, three state commanders, Denver RRCC) with 24/7 availability T-12 h through T+72 h
- FEMA Region 10 (Seattle) liaison seated at Denver RRCC with documented mutual-aid resource commitments (water, fuel, medical staff, shelter, National Guard personnel) from Idaho State Emergency Management and Pocatello/Boise distribution centers

### Simulation Steps

- Draft a Unified Command authority-delegation document defining: (1) NPS incident commander authority over Zone Zero (park interior) operations until the first park boundary; (2) state on-scene commander authority over post-boundary traffic, shelter assignment and resource requests until formal handoff; (3) Boundary Coordination Officer authority over reroute and shelter decisions at the boundary crossing (specifically, authority to make a traffic-control decision without waiting for higher approval if phone/radio communication is lost >5 minutes). Circulate this draft to NPS headquarters, Montana/Wyoming/Idaho governors' offices, FEMA Region VIII and state emergency management for comment and revision.
- Develop a multi-state tabletop exercise scenario: at T+3 h, a rockfall blocks Gallatin Canyon, and the Boundary Coordination Officer must decide whether to (1) attempt 15-minute tow-team clearance (per protocol), or (2) divert all traffic to US-89 (North exit) immediately (per loss-of-exit contingency). The diversion decision will increase load on US-89 from 30% to 40%, and the Boundary Coordination Officer must notify MT highway patrol and the state on-scene commander within 5 minutes. Simulate the decision-communication sequence and identify any state-to-federal approval loops that cause delays.
- Use a Gantt chart or project-management software (Asana, Monday.com) to map out the MOU-signature path: NPS headquarters approval by Week 1, MT/WY/ID governors' offices by Week 2, state DOT legal reviews by Week 3, final signature by Month 1 (2026-11-14). Identify any blocking dependencies (e.g., state attorney-general review) and resolve them early.
- Conduct a radio-interoperability check among all agencies (NPS, MT/WY/ID highway patrol, National Guard, FEMA, forwad UC): confirm that a single encrypted frequency or secure radio net can link the Boundary Coordination Officer to all three state on-scene commanders and the Denver RRCC simultaneously. Test voice quality, latency and the ability to conference 5+ parties on a single call.
- Model the FEMA Region 8/10 coordination flow: at T+0, the Boundary Coordination Officer and UC Incident Commander at Denver RRCC activate a call with the FEMA Region 10 (Seattle) administrator and Idaho State Emergency Management Agency. Resource requests from shelters (e.g., 'we need 50,000 gallons of water by Hour 8') should be processed by the Region 10 liaison in <30 minutes and be dispatched to Pocatello or Boise suppliers within 4 hours of the request. Simulate a high-demand scenario (multiple simultaneous water, fuel and personnel requests at Hour 6–8) to test coordination speed.

### Expert Validation Steps

- Request the NPS Incident Commander (or designate) and the governors of Montana, Wyoming and Idaho to formally authorize the Unified Command structure by signing a pre-event Memorandum of Understanding confirming (1) NPS operational authority in Zone Zero, (2) state authority post-boundary, (3) Boundary Coordination Officer pre-authorized decision authority at the boundary crossing.
- Invite a FEMA regional administrator (Region VIII) and state emergency management directors to review the authority-delegation document and confirm that it does not conflict with Stafford Act procedures, EMAC mutual-aid processes or state emergency-powers laws.
- Request the Boundary Coordination Officer (named individual or position designation) to conduct a dry-run radio-communication test with all state on-scene commanders and the Denver RRCC 30 days before the eruption window, confirming that the officer can reach all parties simultaneously and that encrypted frequencies are synchronized.
- Brief the Montana and Wyoming highway-patrol command centers on the pre-authorized reroute protocol, including the 5-minute decision window for traffic-control changes without requesting NPS approval, and confirm that their on-scene commanders understand and accept this delegation.
- Coordinate a multi-state command-authority exercise involving NPS, FEMA, all three state emergency management agencies and the governors' representatives 60 days before the eruption window (Month -1.5, 2026-08-29), simulating a Scenario Beta trigger at T+12 h and testing the cross-state decision chain (Zone One clearance gate G1 at T+6 h, Zone One evacuation gate G2 at T+24 h, Scenario Beta expansion order).

### Responsible Parties

- NPS Incident Commander (Zone Zero operational authority delegation)
- Governors of Montana, Wyoming and Idaho (state authority post-boundary and Boundary Coordination Officer pre-authorization)
- FEMA Region VIII and Region X administrators (Unified Command structure validation)
- State emergency management directors and highway-patrol commanding officers (on-scene commander authority and reroute protocol acceptance)
- Boundary Coordination Officer (designated individual with communications validation)

### Assumptions

- **High:** Governors of Montana, Wyoming and Idaho will sign pre-event MOUs confirming authorization of Unified Command Zone One and Scenario Beta orders by Month 1 (2026-11-14).
- **High:** A single Boundary Coordination Officer at the forward UC element can make reroute and shelter-assignment decisions without supervisory approval if higher-authority communication is lost >5 minutes, under pre-authorized Stafford Act emergency delegation.
- **Medium:** FEMA Region 10 (Seattle) liaison can be seated at the Denver RRCC from T+0 and coordinate with Idaho resource centers (Boise, Pocatello) with 30-minute response time to mutual-aid requests.
- **Medium:** All agencies (NPS, MT/WY/ID highway patrol, National Guard, FEMA) share a common encrypted radio net that allows simultaneous 5+ party conferencing and maintains voice quality under ashfall conditions.
- **Medium:** State on-scene commanders (highway patrol, National Guard) will accept pre-authorized decision authority for temporary reroutes issued by the Boundary Coordination Officer without state-level approval delays.

### SMART Validation Objective

By Month -0.5 (2026-09-29), obtain written pre-event authorization letters from Montana, Wyoming and Idaho governors confirming Unified Command and Boundary Coordination Officer authority. By Month -1 (2026-09-14), execute signed MOUs with state DOTs and highway patrol specifying boundary-transfer checkpoints and pre-authorized reroute protocols. By Month -0.5 (2026-09-29), conduct a radio-interoperability test confirming that the Boundary Coordination Officer can reach all three state on-scene commanders and Denver RRCC simultaneously on a secure net. By Month -1.5 (2026-08-29), execute a multi-state command-authority tabletop exercise testing cross-state decision chains and documenting any approval delays or jurisdictional conflicts.

### Notes

- Pre-event MOU signature timelines often exceed 30–60 days due to state attorney-general review, budget office sign-off and legislative coordination requirements. Begin the signature campaign by Month -2 (2026-08-14) or earlier to meet the Month 1 (2026-11-14) hardening deadline.
- If governors are unwilling to cede operational authority to NPS at the boundary, an alternative structure might be joint NPS-state command at the boundary itself, with a co-located incident commander and state on-scene commander sharing authority. This will slow decisions by ~10–15 minutes per coordination loop; model this delay into the evacuation timeline.
- Encrypted radio-net sharing (such as P25 digital conventional or trunked systems) requires pre-event frequency coordination through the FCC or state authorities. Request this coordination by Month -2 (2026-08-14) to avoid 30-day delays.
- The Boundary Coordination Officer's authority to act without supervisory approval if higher communication is lost >5 minutes is an emergency delegation that may require Stafford Act waivers or state governor orders. Confirm legal basis with FEMA counsel by Month -1 (2026-09-14).
- Multi-state exercises often reveal unforeseen friction between agencies (e.g., state police reluctance to take orders from federal incident commanders, Guard reluctance to operate under NPS authority). Use the Month -1.5 (2026-08-29) tabletop to surface and resolve these cultural or legal conflicts before the 72-hour window.

## Summary

The plan aims to evacuate ~35,800 tourists and staff from Yellowstone Zone Zero by T+6 hours and expand to a 100 km Zone One by T+24 hours under a 72-hour, 40% VEI-6+ eruption probability window (Month 0 = 2026-10-14). The six critical data-collection areas focus on: (1) Scenario Beta secondary-stage hub destinations and tiered messaging (resolves the hollow pre-authorization of a 500 km order lacking destinations), (2) Responder relief depth and separate N95 inventory (addresses zero-cushion staffing during peak evacuation), (3) Real-time ashfall monitoring and shelter-relocation protocols (manages forecast uncertainty and mid-operation shelter viability), (4) Water supply-chain validation including forward depots and realistic convoy timelines (closes the T+18–30 h arrival gap), (5) Geotechnical feasibility of single-lane corridor clearance (tests whether Gallatin Canyon and South Entrance are viable exits), and (6) Multi-state authority structure and Boundary Coordination Officer delegation (formalizes NPS-to-governor handoff and pre-authorized decision authority). Each collection area includes simulation steps using standard tools (GIS mapping, traffic models, tabletop exercises, field surveys) and expert validation with USGS, FEMA, state emergency management and professional engineers. Simulation results must be completed by Month 1 (2026-11-14) hardening deadline, with signed MOUs and full-scale exercises by Month 3 (2027-01-14). The priority is validating the three tightest coupling risks: (A) Scenario Beta destinations prevent uncontrolled shadow evacuation that would delay Zone Zero clearing, (B) responder relief depth prevents single-checkpoint failures from cascading, and (C) ashfall monitoring prevents mid-operation shelter placement in heavy ash. Immediate actionable tasks: activate USGS and FEMA hub-feasibility assessments (target Month -1.5 = 2026-08-29 for survey completion), secure governor pre-authorization letters (target Month -0.5 = 2026-09-29 for signature), and deploy PM10 sensors and water-supply contracts (target T+0 = 2026-10-14). All data collection, simulation and expert validation must complete by Month 1 (2026-11-14) to inform Months 2–3 (2026-12-14 to 2027-01-14) multi-state exercises and contingency planning.