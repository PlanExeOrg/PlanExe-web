### 1. Unified Command (UC) – Strategic Oversight Board

**Rationale for Inclusion:** A 72-hour window with 40% eruption probability (user constraint) and multi-state jurisdiction requires a single, pre-authorized strategic authority over zone expansion, escalation triggers, and inter-agency resource requests. The UC sits at FEMA Region VIII RRCC Denver and must coordinate Regions 8 and 10, three state governors, NPS, and the FAA to avoid authority gaps and command paralysis. Its primary role is authorizing the pre-written Scenario Beta VEI-7 trigger and issuing the 500 km evacuation order within 30 minutes of detection.

**Responsibilities:**

- Activate the Unified Command at T+0 and authorize contraflow and initial evacuation orders
- Monitor USGS eruption indicators and authorize Scenario Beta 500 km expansion under the pre-written trigger matrix within 30 min of threshold crossing
- Authorize authority transfer at park boundaries and resolve any NPS-to-governor jurisdiction disputes in real time
- Approve shelter-siting decisions at T+6 h based on NOAA/USGS plume forecast and PM10 sensor data
- Allocate emergency resources across multi-state response and approve any critical supply-chain reroutes
- Issue and maintain public messaging on evacuation zones, shelter assignments and escalation triggers to sustain credibility

**Initial Setup Actions:**

- Seat the Unified Command with federal, state and NPS representatives at FEMA Region VIII RRCC Denver by T+0
- Activate FEMA Region 10 liaison and confirm region-to-region communication links
- Publish the pre-authorized USGS trigger matrix to media and Zone One communities at T+0
- Establish a 24/7 shared common operating picture (digital dashboard) tracking evacuation progress, supply deliveries and responder status, updated hourly
- Conduct verbal pre-authorization calls with MT, WY and ID governors confirming Zone One and Scenario Beta orders by T+6 h

**Membership:**

- FEMA Region VIII Incident Commander (chair)
- FEMA Region 10 liaison (Region 10 authority, Idaho coordination)
- NPS Incident Commander or delegated senior NPS official
- Montana State Emergency Manager and Governor's designee
- Wyoming State Emergency Manager and Governor's designee
- Idaho State Emergency Manager and Governor's designee
- USGS lead volcanologist (ex officio, eruption monitoring and trigger authority)
- NOAA forecast lead (ex officio, ashfall and air-quality authority)

**Decision Rights:** The UC authorizes all strategic decisions with multi-state or federal implications: (1) evacuation zone expansion (Zone Zero to One to Beta); (2) authority transfer and boundary handoffs; (3) shelter-siting and relocation orders; (4) resource allocation above the operational management threshold (USD 10 million per decision, proposed); (5) any messaging reversal or escalation signal to the public. Decisions requiring consensus; in the event of tie or disagreement, the FEMA Region VIII IC has final authority, with a documented dissent from the disagreeing state recorded for accountability.

**Decision Mechanism:** The UC meets in continuous session (at least hourly briefings) during the 72-hour window and stands up as needed thereafter. Decisions on evacuation expansion and shelter siting are made by real-time consensus on the shared common operating picture, with decision triggers defined in the pre-written matrix (USGS indicators and PM10 thresholds). Tie-breaker: FEMA Region VIII IC, with one veto override right per state governor (may be used once to block a decision; once used, majority rule prevails thereafter). All decisions documented in real time in the shared log.

**Meeting Cadence:** Continuous operation during the 72-hour window (Month 0 = 2026-10-14, T+0 to T+72 h); hourly formal briefings at T+0, T+2, T+6, T+12, T+24, T+36, T+48, T+60, T+72 h, plus ad hoc calls on trigger events (Scenario Beta, shelter relocation, authority disputes). Post-window: weekly calls from Month 1 (2026-11-14) through Month 3 (2027-01-14 to 2027-01-14) to finalize MOUs, plan exercises and review after-action items.

**Typical Agenda Items:**

- Current evacuation progress: cumulative exit counts by gate and time, zone-clearance status against T+6 and T+24 h gates
- USGS eruption indicators and proximity to Scenario Beta trigger thresholds; ashfall forecast and PM10 readings at all shelter sites
- Supply deliveries: water convoy status, N95 distribution, fuel inventory at hospitals and comms centers
- Authority and jurisdictional issues: boundary handoff execution, state reroute compliance, any NPS-governor conflicts
- Responder status: staffed vs. uncovered posts, fatigue reports, any exposure-limit breaches or relief shortfalls
- Communications status: IPAWS/WEA delivery, Guard signal bridging coverage, any digital-network degradation

**Escalation Path:** The UC is the apex strategic authority for the evacuation response. Disagreements among members (states vs. federal, or state vs. state) are resolved by UC consensus; if consensus fails, the FEMA Region VIII IC decision prevails with documented dissent. Constitutional or legal challenges to the evacuation order (e.g., governor refuses to enforce a UC-issued relocation directive) are escalated to the U.S. Attorney's Office (Colorado District) and the White House Chief of Staff via the FEMA Regional Administrator. Resource allocation disputes exceeding the USD 10 million threshold or requiring supplemental declaration authority are escalated to the FEMA Deputy Administrator in Washington.
### 2. Forward Unified Command Element (FUCE) – Operational Management & Incident Control

**Rationale for Inclusion:** The Denver RRCC is 250+ km from the evacuation corridors (US-191, US-89, I-90), creating a decision latency of 2-4 hours for reroute orders and real-time resource dispatch. The FUCE co-locates the incident command team at Livingston or Bozeman, MT, within sight of the contraflow corridors and shelter sites, enabling rapid reroute directives, supply-chain troubleshooting and real-time response to corridor blockages or ashfall shifts. The FUCE operates under authority delegated by the UC and reports status hourly to the UC dashboard.

**Responsibilities:**

- Execute contraflow traffic management on US-191, US-20, US-89 and I-90, authorize reroutes and diversion rules within the T+6 h clearance window
- Dispatch tow and rockfall-clearance teams to corridor chokepoints, enforce the 45-minute blockage-diversion threshold (proposed), and manage loss-of-exit contingencies
- Activate Guard signal teams and communications infrastructure at each control point; maintain hourly updates to the UC common operating picture
- Monitor real-time PM10 and ashfall depth at all shelter sites; trigger shelter-relocation decisions within 4 h if exceedance is detected (proposed threshold)
- Manage water convoy dispatch from Salt Lake City, authorize priority-lane allocation and track arrival times against the T+12 h and T+24 h targets
- Coordinate with state highway patrol and National Guard commanders at each state boundary to enforce the authority-transfer protocol and prevent jurisdictional disputes

**Initial Setup Actions:**

- Establish the FUCE at Livingston, MT (or alternate Bozeman) by T+0, with direct communication links to the UC in Denver and to all state EOCs
- Deploy Guard signal teams, satellite phones and repeaters to all control points and shelters by T+1 h (proposed threshold)
- Position tow and rockfall-clearance teams at Mammoth and Spanish Creek by T+0
- Activate real-time PM10 monitoring at the forward element and every shelter site by T+0
- Confirm concessioner lodge manifests and bus availability for priority evacuation at each facility by T+0
- Brief state on-scene commanders at West Yellowstone, Gardiner and Cody on authority-transfer protocols and pre-authorized reroute powers by T+0

**Membership:**

- Operations Section Chief (FUCE incident commander, delegates from FEMA and NPS, chair)
- Logistics Section Chief (water, fuel, N95 supply tracking)
- Planning Section Chief (common operating picture, USGS indicator tracking, Scenario Beta readiness)
- Safety Officer (responder exposure limits, N95 replacement cycles, fatigue monitoring)
- Boundary Coordination Officer (NPS-to-state authority transfer, reroute approvals at each gate)
- Guard Signal Officer (communications status and redundancy management)
- NOAA/USGS liaison (real-time plume forecast and PM10 sensor updates)

**Decision Rights:** The FUCE makes all operational decisions within the pre-authorized rules: (1) reroute orders and traffic-control post assignments (within total of 100-150 rangers and Guard personnel, proposed); (2) tow-team dispatch and the 45-minute blockage-diversion trigger; (3) water convoy priority and reserved-lane allocation on I-15; (4) shelter-relocation orders if PM10 exceeds thresholds (proposed); (5) responder shift assignments and relief activation. Decisions below the USD 10 million threshold do not require UC approval. Any decision that conflicts with an active UC order or requires deviation from the pre-written trigger matrix must escalate to the UC within 15 minutes.

**Decision Mechanism:** The FUCE operates on a continuous real-time basis, making decisions as conditions change (blockages, ashfall, supply delays). Standing orders and pre-authorized thresholds guide decisions without waiting for UC approval. Example: if Gallatin Canyon blockage lasts >45 minutes, overflow is automatically diverted to US-89 without FUCE debate. If PM10 exceeds 100 ug/m3 at Bozeman shelter, a backup-site relocation analysis is triggered within 30 minutes and a relocation order (if suitability threshold is met) is issued within 4 h. Tie-breaker: Operations Section Chief, with a dissent flag to the UC if the decision creates new risk.

**Meeting Cadence:** Continuous operation and real-time decision-making during the 72-hour window (T+0 to T+72 h). Formal briefing calls to the UC at T+0, T+2, T+6, T+12, T+24, T+36, T+48, T+60, T+72 h. Internal FUCE section briefings every 2 hours during peak evacuation (T+2 to T+8 h) to synchronize logistics, planning and communications. After-action reviews during Months 1-3 (2026-11-14 to 2027-01-14).

**Typical Agenda Items:**

- Real-time evacuation status: cumulative vehicle counts at each gate, queue length and flow rate (vehicles/h), ETA for 98% clearance
- Corridor blockage and tow status: any incidents detected, clearance time estimates, overflow-diversion decisions and their impact on other gates
- Water and supply convoy tracking: departure time from Salt Lake City, current location, ETA at shelters, any delays or route changes
- Ashfall and PM10 readings: real-time sensor data at each shelter, forecast updates from NOAA, any triggers for relocation analysis
- Responder status: staffed positions, uncovered posts, fatigue and exposure-limit breaches, relief-team deployment status
- Communications: signal-team coverage, any outages, IPAWS delivery success rate, driver feedback on message clarity

**Escalation Path:** Operational decisions stay within the FUCE unless they violate pre-authorized thresholds or conflict with UC orders. Any request for additional Guard personnel, change to the pre-written trigger matrix, or decision to revise public messaging escalates to the UC. Resource requests exceeding available stock (e.g., need for additional N95 from the supplemental reserve at Billings) escalate to the Unified Command Logistics Officer. Responder casualties or critical incidents escalate immediately to the UC and to the responsible state's emergency manager.
### 3. Escalation & Scenario Beta Decision Cell – Specialized Advisory (Volcanology & Triggering Authority)

**Rationale for Inclusion:** The 72-hour window carries a 40% VEI-6+ eruption probability and a pre-authorized VEI-7 trigger matrix that authorizes the UC to order a 500 km radius evacuation immediately without further deliberation. However, the scientific indicators (USGS uplift rate, seismic magnitude, gas flux) that define the trigger must be continuously monitored and interpreted in real time, requiring dedicated expert authority separate from operational command. This cell owns the trigger-matrix refinement, indicator interpretation, and the real-time decision to declare that the threshold has been crossed. The cell's recommendation is binding on the UC unless the UC explicitly overrides it (a rare event, since the matrix is pre-authorized).

**Responsibilities:**

- Refine the USGS trigger-matrix indicator thresholds (uplift rate, seismic magnitude, gas flux, magma-depth models) by T+3 h using pre-event USGS data and the latest volcano-monitoring techniques
- Monitor USGS real-time feeds (seismic networks, GPS, gas sensors) continuously during the 72-hour window and maintain a live status of each indicator relative to the trigger threshold
- Issue a formal Escalation Readiness Assessment every 6 hours during the 72-hour window, stating the current distance from the Scenario Beta trigger and the estimated time to trigger if current trends continue
- Declare the trigger crossed (or not) within 15 min of any indicator crossing the pre-written threshold, with a written statement of which indicator crossed and by how much
- Provide technical guidance to the UC on any ambiguous or marginal trigger events (e.g., an indicator that crosses threshold but then retreats) and recommend whether to order Scenario Beta or hold status
- Coordinate with NOAA on ashfall dispersion forecasts and provide updated wind-direction and ash-extent estimates every 6 hours to support shelter-siting and Scenario Beta planning

**Initial Setup Actions:**

- Convene the Decision Cell at T+0, with USGS and NOAA leads, to review the pre-written trigger matrix and agree on final indicator thresholds by T+3 h
- Establish real-time data feeds from USGS seismic, GPS and gas networks to the cell's monitoring station at the FUCE (Livingston or Bozeman) by T+1 h
- Brief the UC on the refined trigger matrix and the cell's readiness to monitor at T+3 h
- Create a visual status dashboard (displayed at the FUCE) showing current values of each indicator, the trigger threshold, and the distance from the threshold in real time
- Prepare a written decision template and a dissent log so that any trigger-crossing declaration is documented with full traceability and any disagreement among cell members is recorded

**Membership:**

- USGS Volcano Disaster Assistance Program lead (chair, eruption monitoring and indicator interpretation)
- USGS Cascades Volcano Observatory seismologist (seismic swarm interpretation)
- USGS Hawaiian Volcano Observatory modeler (magma ascent and VEI estimation)
- NOAA Forecast lead (ashfall dispersion, wind shifts)
- UC Liaison (FEMA or NPS representative to relay cell decisions to the UC)

**Decision Rights:** The cell's role is scientific interpretation and trigger declaration, not policy or resource decisions. The cell declares whether the pre-written trigger threshold has been crossed. This declaration is binding on the UC (the UC does not second-guess the scientific finding), unless the UC explicitly overrides it on policy grounds (e.g., national-security concerns). The cell does not have authority to modify the trigger matrix after T+3 h; any matrix changes must be approved by the UC. The cell's recommendation on marginal triggers is advisory; the UC makes the final call to order Scenario Beta.

**Decision Mechanism:** Real-time monitoring of USGS feeds and automated alerts when an indicator approaches the threshold (within 20% of the trigger value). When any indicator crosses the threshold, the cell convenes immediately (within 5 min) to verify the data and declare the crossing. If data are ambiguous or disputed among cell members, a simple majority vote determines the declaration (two out of three USGS leads vote); if still disputed, the USGS Disaster Assistance Program lead has final authority. The UC is notified within 15 min of any threshold crossing or declaration.

**Meeting Cadence:** Continuous real-time monitoring during the 72-hour window. Formal briefings to the UC every 6 hours (T+0, T+6, T+12, T+18, T+24, T+30, T+36, T+42, T+48, T+54, T+60, T+66, T+72). Ad hoc calls whenever an indicator crosses 80% of the trigger threshold (a warning). Post-window: joint after-action review with the UC and state emergency managers by Month 2 (2026-12-14).

**Typical Agenda Items:**

- Current status of each USGS indicator: uplift rate (cm/h), seismic magnitude and frequency, gas flux (SO2, CO2), and magma-depth estimates relative to the trigger thresholds
- Ashfall forecast: NOAA 72-hour wind and plume model; projected ash concentration (ug/m3) at each shelter site and Zone One community
- Indicator trends: are current values stable, accelerating, or retreating; estimated time to trigger if acceleration continues
- Any data anomalies or instrument failures affecting indicator reliability; recommendations for data-quality assurance
- Scenario Beta readiness: are the secondary hubs (Denver, Cheyenne) pre-authorized and ready; are bus fleets and rail corridors confirmed

**Escalation Path:** The cell's trigger declaration goes directly to the UC via the UC Liaison and the shared common operating picture. If the cell declares trigger crossing and the UC does not order Scenario Beta within 30 min, the cell has the right to escalate the non-response to the White House Situation Room via the FEMA Regional Administrator. Conversely, if the UC orders Scenario Beta without a cell trigger declaration, this is logged as a policy override and reported in the post-event after-action review.
### 4. Responder Health & Fatigue Management Board – Specialized Advisory (Occupational Safety & Exposure Limits)

**Rationale for Inclusion:** The 72-hour evacuation window requires continuous staffing of traffic-control checkpoints, perimeter gates and backcountry sweeps by rangers, highway patrol and Guard personnel exposed to ashfall, tremor hazards and heat stress. A formal board with authority to enforce exposure limits and manage relief cycles protects responders from entrapment and respiratory injury while maintaining staffing continuity. The board monitors shift logs, triggers relief rotation, and has the power to withdraw responders from ash-exposed posts if limits are breached, directly affecting traffic throughput and evacuation speed. This board is necessary to balance responder safety against the evacuation deadline.

**Responsibilities:**

- Define and enforce responder exposure limits: max 6-hour shifts at ash-exposed posts, mandatory 2-hour rest with N95 replacement, full withdrawal after 18 consecutive hours (proposed thresholds); document all shift assignments and monitor compliance in real time
- Monitor responder health status: track N95 mask inventory and replacement, manage respiratory-exposure symptoms (coughing, shortness of breath) and refer affected personnel for medical evaluation; maintain a confidential responder-health log
- Activate relief rotation and standby reserves: when staffing at any checkpoint falls below 50% (proposed threshold) due to exposure limits or fatigue, trigger deployment of the 30–50 person out-of-region standby reserve within 4 h
- Request additional Guard personnel from Fort Carson, Colorado or other regions if staffing demands exceed available personnel; prepare the request for UC approval if out-of-state Guard cross-deputization is needed
- Conduct fatigue-risk assessments at T+24, T+48 and T+72 h, analyzing cumulative hours worked and recommending mandatory relief or withdrawal of personnel showing signs of critical fatigue
- Coordinate with the three receiving hospitals (Bozeman, Livingston, Idaho Falls) to pre-stage medical support at traffic checkpoints and shelters for responder health emergencies

**Initial Setup Actions:**

- Convene the board at T+0 with representatives from NPS LE, state patrol, Guard and the forward-command Safety Officer to finalize shift schedules and relief protocols
- Count and allocate responder N95 respirators separately from the 100,000 civilian stock; confirm at least 150,000 responder+civilian N95s are available (estimate), with a 50% surge buffer for replacement cycles
- Brief all assigned responders on exposure limits, N95 replacement protocols and mandatory withdrawal thresholds by T+0
- Establish a 24/7 responder-fatigue hotline where personnel can report exposure symptoms, request relief, or raise concerns about unsustainable workloads
- Confirm that the 30–50 person standby reserve is fully briefed, equipped with N95s and generator fuel, and stationed outside the ash zone and ready to deploy within 4 h

**Membership:**

- NPS Chief Ranger or delegated senior safety officer (chair)
- Forward Command Safety Officer
- Montana Highway Patrol Incident Commander or delegated representative
- Wyoming Highway Patrol Incident Commander or delegated representative
- Idaho State Police Incident Commander or delegated representative
- National Guard unit commander (regional or Fort Carson, as deployed)
- Medical officer from the nearest receiving hospital (occupational health and emergency medicine expertise)

**Decision Rights:** The board has binding authority to: (1) approve or modify shift schedules and rest cycles; (2) declare any post as 'understaffed' if coverage falls below 50% due to exposure limits (proposed threshold); (3) trigger activation of the standby reserve for deployment within 4 h; (4) withdraw any individual responder from ash-exposed duty if exposure limits are breached or fatigue risk is critical; (5) recommend to the FUCE that a checkpoint be temporarily closed or consolidated with another if staffing cannot be sustained. The board does not have authority to extend exposure limits beyond the pre-written thresholds (6 h shift, 18 h withdrawal) without UC approval.

**Decision Mechanism:** The board meets every 6 hours during the 72-hour window (at T+0, T+6, T+12, T+18, T+24, T+30, T+36, T+42, T+48, T+54, T+60, T+66, T+72 h) to review shift logs, assess staffing adequacy and approve the next day's schedule. Decisions are made by consensus among the NPS, state and Guard commanders; if consensus fails (e.g., a state patrol commander refuses to remove an exhausted trooper from duty), the NPS Chief Ranger has final authority, with a dissent recorded for the UC. Emergency decisions (e.g., immediate withdrawal of a responder showing acute respiratory distress) are made by the board chair within 5 min and reported to the FUCE.

**Meeting Cadence:** Continuous 24/7 operation during the 72-hour window with formal board meetings every 6 hours (T+0, T+6, T+12 h, etc.). Ad hoc calls when a checkpoint reports staffing below 50% or a responder requests emergency relief. Daily fatigue-risk assessments at T+24, T+48 and T+72 h. Post-event responder health screening and evaluation by Month 2 (2026-12-14).

**Typical Agenda Items:**

- Shift-log review: which responders worked in the past 6 h, duration, location, exposure conditions; any exposure-limit breaches; any symptomatic responders (respiratory symptoms, heat stress, confusion)
- Staffing adequacy: current staffing vs. required staffing at each checkpoint; any posts currently unstaffed or below 50% (proposed threshold)
- Relief rotation: which responders are due for mandatory rest; approval of next 6-hour shift schedule for all posts
- Standby reserve deployment: current readiness status; any activation requests from the FUCE
- N95 inventory and replacement: current stock at each checkpoint; replacement cycles (clogging rate, expected duration per mask); any shortages
- Responder health incidents: any acute symptoms, hospital referrals or medical complications; medical follow-up recommendations

**Escalation Path:** Decisions about responder withdrawal or staffing shortages escalate to the FUCE Operations Section Chief, who adjusts traffic-control post assignments or consolidates posts if necessary. If staffing demands consistently exceed the available responder pool and cannot be met by the standby reserve, the board chair escalates a request for out-of-state Guard to the UC. Critical responder health emergencies (respiratory distress requiring hospitalization, heat-related collapse) are reported immediately to the nearest receiving hospital and to the UC. Any responder casualty during the event is reported to the UC and to the respective state emergency manager within 1 hour.
### 5. Authority & Jurisdictional Coordination Cell – Specialized Advisory (Command Clarity & Multi-State Protocol)

**Rationale for Inclusion:** The evacuation crosses jurisdictional boundaries between NPS (federal land), Montana, Wyoming and Idaho (state highways and communities), and FEMA Regions 8 (Denver) and 10 (Seattle), creating authority gaps and decision latency. The authority transfer is specified in writing (park boundary at each gate; NPS to state handoff), but contraflow traffic does not stop at boundaries, so vehicles and responders cross jurisdictions mid-evacuation without a clear point of responsibility handoff. A dedicated cell, co-located at the forward element with real-time links to each state's on-scene commander, owns the boundary coordination, pre-authorized reroute authority, and resolution of any NPS-state or Region 8/10 disputes. This cell prevents the 15–45 minute delays in reroute decisions that could cascade into a 500–1,000 vehicle backup.

**Responsibilities:**

- Execute the written NPS-to-state authority transfer protocol at each park exit gate (West, North, East Entrance), defining the exact roadside checkpoint where NPS care ends and state custody begins; ensure both sides formally acknowledge the handoff at T+0 and throughout the evacuation
- Authorize state on-scene commanders to issue temporary reroutes without requesting park ranger approval, pre-authorizing them at T+0 with a standing order that reroutes are valid until revoked by the FUCE
- Manage the FEMA Region 8/10 seam: seat an explicit Region 10 liaison at the UC (Denver) by T+0 and maintain a standing mutual-aid agreement with Boise and Pocatello resource centers so that Idaho water and fuel convoys are dispatched without delay
- Resolve any dispute between NPS and a state on-scene commander (e.g., over shelter placement, checkpoint closure or perimeter enforcement) within 30 min by convening both parties on a dedicated conference line with the Boundary Coordination Officer as mediator
- Maintain a shared authority-transfer log (updated hourly) showing which vehicles and responders have crossed from NPS to state control at each gate, and which state now owns care for those evacuees
- Coordinate with the FAA on airspace grounding and medevac exceptions, ensuring the Unified Command has real-time visibility into aviation restrictions and can request emergency exceptions for helicopter transport

**Initial Setup Actions:**

- Brief the designated on-scene commanders for each state (Montana highway patrol at Livingston, Wyoming patrol at Cody, Idaho at Idaho Falls) on the pre-authorized reroute authority and the boundary-handoff protocol at T-6 h (before the evacuation order)
- Establish pre-signed MOUs with Montana, Wyoming and Idaho confirming their acceptance of the UC's authority to issue Zone One and Scenario Beta evacuation orders by Month 1 (2026-11-14)
- Issue written standing orders at T+0 granting state on-scene commanders authority to issue reroutes without seeking park ranger approval, with a dissent-reporting requirement if the commander believes a reroute violates the pre-written matrix
- Activate the Region 10 liaison seat at the Denver RRCC by T+0 and confirm a direct phone line between the liaison and the Boise emergency management office
- Convene a pre-event multi-state coordination exercise 60 days before the window (Month -2) to test boundary handoff, reroute decisions and mutual-aid requests under simulated congestion and ashfall scenarios

**Membership:**

- Boundary Coordination Officer (forward element, chair; FEMA, NPS or Guard officer with authority to speak for the UC)
- NPS Incident Commander or delegated zone incident commander
- Montana Highway Patrol on-scene commander (West Yellowstone and Gardiner exits)
- Wyoming Highway Patrol on-scene commander (Cody and East Entrance exit)
- Idaho State Police liaison (Idaho Falls shelter coordination)
- FEMA Region 10 liaison (seated at Denver UC or on standing conference call)
- FAA representative or liaison (aviation grounding and medevac exceptions)

**Decision Rights:** The cell has binding authority to: (1) authorize state reroutes at any time without UC approval (pre-authorized standing order); (2) resolve NPS-state disputes on the fly within 30 min (Boundary Coordination Officer decision); (3) activate the Region 10 liaison's mutual-aid requests for Idaho resources without waiting for UC approval if request is below USD 5 million (proposed threshold); (4) approve helicopter medevac exceptions within the pre-authorized criteria set by the UC and FAA. The cell may not modify the written authority-transfer protocol after T+0 or unilaterally revoke a pre-authorized reroute; any such changes must escalate to the UC.

**Decision Mechanism:** Standing orders and pre-written authority transfers define the default decision rules, so most situations are handled without deliberation. Real-time problem-solving through a dedicated conference line: if a reroute is needed, the state commander requests it, the Boundary Coordination Officer verifies it against the pre-written matrix and authorizes it within 5 min. If an NPS ranger disputes the reroute, the matter is elevated to the Boundary Coordination Officer and the forward-element Operations Chief within 30 min for quick resolution. Tie-breaker: Boundary Coordination Officer, with escalation to the FUCE Operations Chief if the dispute creates conflicting orders.

**Meeting Cadence:** Continuous operation and real-time coordination during the 72-hour window via a standing conference line connecting all members. Formal briefings to the UC every 6 hours as part of the UC briefing schedule. Post-event: multi-state debrief by Month 2 (2026-12-14) with Montana, Wyoming and Idaho emergency managers to review authority handoff execution and identify improvements for future events.

**Typical Agenda Items:**

- Boundary-crossing status: cumulative vehicle counts crossing from NPS to state control at each gate (West, North, East); any delays or congestion at handoff points
- Active reroutes: which reroutes are currently in effect, which state issued them, any NPS objections or disputes, expected resolution time
- Authority disputes: any NPS-state conflicts over shelter placement, checkpoint staffing, perimeter enforcement or other coordination issues; status of resolution efforts
- Region 10 mutual aid: any pending requests from Idaho emergency managers for water, fuel or medical resources; dispatch status of approved requests
- FAA coordination: any medevac exception requests, current ashfall-related airspace restrictions, anticipated exceptions for emergency helicopter transport

**Escalation Path:** Real-time disputes between NPS and a state are mediated by the Boundary Coordination Officer (on the standing conference line) within 30 min. If the Boundary Coordination Officer and state/NPS commanders cannot reach agreement, the matter escalates to the FUCE Operations Chief, who makes a binding decision and notifies the UC. If a state refuses to comply with a UC-authorized evacuation order, the matter escalates to the UC, which may seek legal counsel and White House involvement. Any FAA denial of a medevac exception request escalates to the UC, which may request White House or Department of Defense intervention.
### 6. Shelter Siting & Air-Quality Assurance Panel – Specialized Advisory (Environmental Monitoring & Dynamic Relocation Authority)

**Rationale for Inclusion:** The plan designates Bozeman and Idaho Falls as reception centers but acknowledges that ashfall forecasts are uncertain by 100+ km, so final shelter locations are selected at T+6 h based on the latest NOAA/USGS plume forecast. Actual ashfall may exceed model predictions by 2–3x, rendering the selected sites unsuitable and requiring emergency relocation of 10,000–15,000 evacuees within 4 h. This specialized panel owns real-time PM10 and ashfall monitoring at all shelter sites, the suitability assessment for shelter relocations, and the authority to order a relocation if thresholds are exceeded. The panel prevents the scenario in which evacuees are sheltered in heavy ash, developing respiratory distress and requiring a chaotic secondary move.

**Responsibilities:**

- Maintain continuous real-time PM10 and ashfall-depth monitoring at the forward element (Livingston or Bozeman) and at all three primary shelter sites, with sensor readings updated at least hourly starting at T-12 h
- At T+6 h, analyze the latest NOAA/USGS plume forecast (wind direction, ashfall extent, ash concentration) and recommend final shelter-site selections from the pre-surveyed candidate list; coordinate with the FUCE Operations Chief to finalize the assignments
- Conduct ongoing suitability assessments at T+12, T+24, T+36, T+48, T+60 and T+72 h: compare current PM10 readings and ashfall forecast to the occupancy and air-filtration capacity of each primary shelter; flag any site exceeding PM10 thresholds (proposed: 50 ug/m3 for forecast update, 100 ug/m3 for suitability review)
- If a primary shelter exceeds PM10 thresholds, initiate a rapid relocation analysis (decision within 30 min): assess ranked backup shelter sites (50+ km upwind) for suitability; prepare a relocation order and transport plan for FUCE approval
- Issue a relocation order (within 4 h of threshold exceedance, proposed threshold) specifying the new shelter site, transport routing, and pickup schedule for the affected evacuees; track relocation logistics and confirm arrival at the new site
- Coordinate with the supplemental N95 reserve hub (Billings or Salt Lake City) to increase N95 distribution to shelters if average daily consumption exceeds 20% of stock (proposed threshold), indicating heavier-than-modeled ashfall

**Initial Setup Actions:**

- Conduct a pre-event air-quality monitoring exercise with NOAA and USGS 30 days before the window, testing real-time sensor deployment, data transmission, forecast-update protocols and relocation-decision latency
- Pre-survey and document 8–10 candidate shelter sites across Montana, Wyoming and Idaho (Bozeman, Livingston, Billings, Idaho Falls, Sun Valley, Missoula, Cheyenne, etc.), with capacity, HVAC and filtration specs for each; rank them by distance from Yellowstone and upwind position relative to forecast wind patterns
- Establish PM10 monitoring equipment at the forward element and at all three primary shelter sites by T-48 h, with backup sensors and battery/generator power; test satellite data transmission to ensure hourly updates are received
- Brief shelter operators and the FUCE Operations Chief on the PM10 thresholds (50 ug/m3 for forecast update, 100 ug/m3 for suitability review) and on the relocation trigger and timeline by T-12 h
- Confirm transport agreements (buses, drivers) for 10,000–15,000 evacuee relocation within 4 h; pre-position the buses at primary shelter sites or within 30 min drive time by T+6 h

**Membership:**

- NOAA Ashfall & Air-Quality Forecast Lead (chair, real-time plume modeling and PM10 prediction)
- USGS Geochemist or volcanologist (ashfall composition and settling-rate estimates)
- EPA air-quality specialist (PM10 sensor calibration and air-quality standards interpretation)
- Forward-Element Planning Chief or designee (FUCE liaison, logistical feasibility assessment for relocation)
- Shelter Operations Coordinator (primary and backup shelter capacity and readiness)

**Decision Rights:** The panel has advisory authority on shelter suitability (recommendation to FUCE) and binding authority to: (1) declare that PM10 thresholds have been exceeded at a shelter site; (2) trigger the start of a relocation analysis; (3) confirm that a ranked backup shelter is suitable for occupancy and relocation can proceed; (4) recommend an increase in N95 distribution from the supplemental reserve. The final relocation order is issued by the FUCE Operations Chief, not the panel, but the panel's threshold declaration is binding and cannot be overridden by the FUCE without UC approval.

**Decision Mechanism:** Automated threshold alerts: when hourly PM10 readings exceed the 50 ug/m3 forecast-update threshold, an alert is triggered and the panel convenes to update the plume forecast and assess suitability. When PM10 exceeds the 100 ug/m3 suitability-review threshold (proposed), a rapid relocation analysis is triggered. The panel (NOAA, USGS and EPA members) votes on whether the current site is still safe for occupancy; a 2-out-of-3 vote determines the recommendation. The FUCE Operations Chief then decides within 1 h whether to order relocation. If the FUCE Operations Chief overrides a panel suitability finding, this override is escalated to the UC.

**Meeting Cadence:** Continuous real-time monitoring with automated alerts when thresholds are approached. Formal briefings to the FUCE Operations Chief every 6 hours (at the standard FUCE briefing times: T+0, T+6, T+12, T+18, T+24, etc.). Ad hoc emergency meetings when PM10 exceeds the forecast-update threshold (50 ug/m3 proposed). Post-event: joint evaluation with USGS, NOAA and EPA by Month 2 (2026-12-14) to assess forecast accuracy and identify sensor improvements.

**Typical Agenda Items:**

- Hourly PM10 and ashfall-depth readings at all shelter sites and the forward element; comparison to modeled expectations
- NOAA 72-hour plume forecast update: wind direction, ashfall extent, estimated PM10 concentrations at candidate shelter sites
- Suitability assessment: is each primary shelter still suitable for occupancy given current and forecast ashfall; any backup sites requiring activation
- Relocation logistics: if relocation is triggered, which backup site is recommended; transport plan and ETA for evacuee pickup and arrival
- N95 consumption and reserve status: actual daily consumption vs. modeled expectation; any triggers for supplemental-reserve activation

**Escalation Path:** Suitability assessments and PM10 threshold declarations go directly to the FUCE Operations Chief, who has 1 h to decide on relocation. If the FUCE Operations Chief does not order relocation within 1 h of a panel finding that PM10 exceeds the 100 ug/m3 threshold (proposed), the panel has the right to escalate the non-response to the UC. Disputes among panel members (e.g., NOAA and USGS disagree on the forecast) are resolved by majority vote; if 2-out-of-3 cannot agree, the matter escalates to the UC with both positions documented. Critical relocation logistics failures (buses unavailable, transport gridlock) escalate to the FUCE Logistics Chief and then to the UC.