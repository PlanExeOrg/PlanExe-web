### 1. Project Sponsor (FEMA Regional Administrator, Region VIII) and NPS Director jointly issue a written decision memo designating the Yellowstone Caldera eruption response as a 'pre-event emergency planning initiative' and authorizing the formation of a Unified Command structure. The memo names the FEMA Region VIII IC as the Unified Command chair and directs all agencies to cooperate on governance setup by Month 0 (2026-10-14). This memo serves as the legal authority to form all downstream governance bodies.

**Responsible Body/Role:** FEMA Regional Administrator (Region VIII) and NPS Director (joint decision authority)

**Suggested Timeframe:** Month -1

**Key Outputs/Deliverables:**

- Signed decision memo authorizing Unified Command formation and inter-agency cooperation
- Named chair of the Unified Command (FEMA Region VIII IC)
- Distribution list of required attendees and their home agencies

**Dependencies:**

- Yellowstone eruption scenario and 72-hour window identified by USGS
- Strategic decision on command structure (Unified Command at Denver RRCC with forward element at Livingston/Bozeman) approved by FEMA and NPS
- Initial internal governance bodies list provided (4-6 bodies defined in prior phase)

### 2. FEMA Region VIII Incident Commander (designated UC Chair) or designee drafts a written Terms of Reference (ToR) for the Unified Command, defining its strategic authority, decision rights (zone expansion, escalation triggers, resource allocation >USD 10M), meeting cadence (continuous during 72-hour window, hourly briefings at T+0/2/6/12/24/36/48/60/72h), membership (FEMA Region VIII IC, Region 10 liaison, NPS IC, three state emergency managers/governors' designees, USGS volcanologist, NOAA forecast lead) and escalation path (tie-breaker: FEMA Region VIII IC; constitutional/legal disputes to U.S. Attorney and White House). The draft establishes the UC as a standing body that activates at T+0 and operates continuously through T+72h.

**Responsible Body/Role:** FEMA Region VIII Incident Commander (future UC Chair) with input from NPS, state emergency management offices and FEMA Region 10

**Suggested Timeframe:** Month -1, Week 2

**Key Outputs/Deliverables:**

- Draft Unified Command Terms of Reference v0.1 (15-20 pages)
- Defined strategic decision rights and escalation paths
- Preliminary membership list with agency confirmations

**Dependencies:**

- Decision memo from FEMA RA and NPS Director issued
- Strategic choices finalized (UC at Denver with forward element at Livingston/Bozeman)
- FEMA Region 10 (Seattle) director identified and notified of expected liaison role

### 3. FEMA Region VIII Incident Commander circulates the draft UC Terms of Reference to all nominated members (NPS Director, three state emergency managers, FEMA Region 10 liaison, USGS and NOAA leads) for review and feedback. A 1-week review window is provided. Feedback is consolidated into a summary document and shared back to all reviewers, along with a revision tracker.

**Responsible Body/Role:** FEMA Region VIII Incident Commander (document circulation and feedback consolidation)

**Suggested Timeframe:** Month -1, Week 3

**Key Outputs/Deliverables:**

- UC ToR v0.1 distributed to 9-12 stakeholders via email and secure portal
- Individual feedback submissions from each reviewer (consolidated into a Feedback Summary)
- Revision tracker showing which comments have been incorporated

**Dependencies:**

- Draft UC ToR v0.1 completed
- Contact list of all nominated members with email addresses and office secure-portal access confirmed

### 4. FEMA Region VIII Incident Commander revises the UC ToR based on consolidated feedback and issues UC ToR v1.0 (final). Key revisions may include: (1) clarification of Region 10 liaison's voting rights on Idaho-specific decisions; (2) formalizing the 'veto override' protocol (each state governor has one veto; majority rule after override used); (3) defining the shared common operating picture (COP) digital dashboard and update frequency (hourly). The final ToR is signed by the FEMA Region VIII IC and submitted to the FEMA Regional Administrator for official approval.

**Responsible Body/Role:** FEMA Region VIII Incident Commander with final sign-off from FEMA Regional Administrator

**Suggested Timeframe:** Month -1, Week 4

**Key Outputs/Deliverables:**

- Unified Command Terms of Reference v1.0 (final, signed)
- FEMA Regional Administrator approval letter
- Decision log documenting which feedback was incorporated and why

**Dependencies:**

- UC ToR v0.1 and consolidated Feedback Summary completed
- Revisions approved by FEMA Region VIII IC

### 5. FEMA Region VIII Incident Commander issues formal written appointment letters to each nominated member of the Unified Command, confirming their role, decision rights and the time commitment (continuous operation from T+0 to T+72h, then ongoing Months 1-3 = 2026-11-14 to 2027-01-14 for MOUs and exercises). Letters are sent to the home agencies (NPS, three states, FEMA Region 10, USGS, NOAA) with a request for verbal confirmation of acceptance within 48 hours. Any rejections or substitute nominees are flagged for resolution by the FEMA Regional Administrator.

**Responsible Body/Role:** FEMA Region VIII Incident Commander (letter issuance)

**Suggested Timeframe:** Month 0 (2026-10-14), Week 1 (Days -7 to 0 before T+0 on 2026-10-14)

**Key Outputs/Deliverables:**

- Formal appointment letters to 9-12 UC members (signed by FEMA Region VIII IC)
- Confirmation of acceptance from each member's home agency (email or memo)
- Roster of confirmed UC membership with titles and contact information

**Dependencies:**

- UC ToR v1.0 final and approved
- Contact information for all nominated members and their supervisors

### 6. FEMA Region VIII Incident Commander or designee holds a pre-event UC 'Orientation and Authority Briefing' meeting (in-person or virtual hybrid) for all confirmed UC members. The briefing covers: (1) the pre-authorized USGS trigger matrix for Scenario Beta (VEI-7 indicators, thresholds to be finalized by T+3h); (2) the three-exit contraflow plan and the 45-minute blockage-diversion rule (proposed threshold); (3) the Authority & Jurisdictional Cell's role in the NPS-to-state handoff; (4) the COP digital dashboard demo and how to access it; (5) the continuous briefing schedule (T+0, T+2, T+6, T+12, T+24, etc.). A Q&A session addresses any ambiguities in decision rights or escalation paths. All attendees sign an acknowledgment of understanding.

**Responsible Body/Role:** FEMA Region VIII Incident Commander (host and facilitator) with support from NPS IC and state emergency managers

**Suggested Timeframe:** Month 0 (2026-10-14), Week 2 (Days -7 to -1 before T+0)

**Key Outputs/Deliverables:**

- UC Orientation briefing agenda and slides
- Pre-authorized USGS trigger-matrix summary (preliminary; final thresholds by T+3h)
- COP dashboard access credentials for all UC members
- Signed attendance roster and acknowledgment-of-understanding forms

**Dependencies:**

- UC ToR v1.0 final and all members confirmed
- USGS preliminary trigger-matrix indicators (uplift rate, seismic magnitude, magma depth) identified
- COP digital platform and dashboard deployed and tested

### 7. FEMA Region VIII Incident Commander formally activates the Unified Command at T+0 (2026-10-14, coinciding with the eruption alert and evacuation order from the project sponsor). All UC members report to their designated seats at the FEMA Region VIII RRCC in Denver (remote participation accepted for state emergency managers if in-person travel is not feasible). The UC chair convenes the first formal briefing, reviews the COP dashboard status (expected: ~0 evacuees out at T+0, all exit corridors open, ashfall not yet detected), and confirms that all five specialized advisory bodies (Escalation Cell, FUCE, Responder Health Board, Authority Cell, Shelter Siting Panel) are standing by and ready to accept delegated authority from the UC.

**Responsible Body/Role:** Unified Command (led by FEMA Region VIII IC)

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 0 (2026-10-14, T+0)

**Key Outputs/Deliverables:**

- UC formally activated memo (signed by FEMA Region VIII IC)
- First UC briefing held; meeting minutes documenting status of evacuation corridors, supply convoys, responder deployment, and advisory-body readiness
- COP dashboard populated with baseline data (evacuation gates open, no blockages, no ashfall yet, all exit corridors confirmed passable)

**Dependencies:**

- Evacuation order issued by project sponsor (NPS and FEMA)
- All UC members confirmed ready and in position at T+0
- FUCE, Escalation Cell and advisory bodies staffed and standing by

### 8. Forward Unified Command Element (FUCE) senior staff (Operations Chief, Logistics Chief, Planning Chief, Safety Officer, Boundary Coordination Officer, Guard Signal Officer and USGS/NOAA liaisons) meet at the forward command element location (Livingston, MT, or alternate Bozeman) by T+1 hour to formally establish the FUCE as an operational entity under the UC. The Operations Chief briefs the team on the delegated authority (traffic management, tow dispatch, water convoy routing, shelter relocation triggers within pre-authorized rules) and confirms that communication links to the UC in Denver are live and tested. All FUCE members acknowledge their roles and confirm readiness to execute continuous operations until T+72h.

**Responsible Body/Role:** FUCE Operations Section Chief (incident commander for forward operations)

**Suggested Timeframe:** Month 0 (2026-10-14), Hours 0–1 (T+0 to T+1)

**Key Outputs/Deliverables:**

- FUCE formally established at Livingston (or Bozeman) location
- FUCE organization chart and role assignments (Operations, Logistics, Planning, Safety, Boundary Coordination, Signal, liaisons)
- Communication test between FUCE and UC Denver (voice, data, COP dashboard access confirmed)
- FUCE initial briefing minutes documenting status of control points, tow teams, water convoy readiness

**Dependencies:**

- UC formally activated
- Livingston command facility (or Bozeman backup) prepared with communications equipment, desks, COP displays and generator backup
- All FUCE section chiefs confirmed in position

### 9. Escalation & Scenario Beta Decision Cell (USGS Volcano Disaster Assistance Program lead, USGS seismologist, USGS magma modeler, NOAA forecast lead, and UC liaison) convene at T+0 at either the FUCE location (Livingston) or the UC location (Denver RRCC), as coordinated. The cell chair (USGS Disaster Assistance Program lead) reviews the pre-authorized USGS trigger matrix (preliminary, to be finalized by T+3h using real-time USGS data) and establishes live monitoring of USGS seismic, GPS and gas networks. The cell confirms that data feeds are arriving in real time and that automated threshold alerts are armed. The cell also briefs the UC liaison on the status of each eruption indicator relative to the Scenario Beta trigger threshold.

**Responsible Body/Role:** Escalation & Scenario Beta Decision Cell (led by USGS Volcano Disaster Assistance Program lead)

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 0 (T+0)

**Key Outputs/Deliverables:**

- Escalation Cell formally established and operational
- Live USGS data feeds (seismic, GPS, gas) confirmed arriving at monitoring station (FUCE or UC)
- Preliminary trigger-matrix thresholds defined (uplift rate, seismic magnitude, magma depth); final thresholds to be confirmed by T+3h
- Automated threshold-alert system armed; decision log created for documenting indicator values hourly
- Initial briefing to UC: current status of each indicator relative to the Scenario Beta trigger

**Dependencies:**

- UC formally activated
- USGS real-time monitoring network operational (seismic, GPS, gas)
- Live data-feed connections to the FUCE or UC command center confirmed

### 10. Responder Health & Fatigue Management Board (NPS Chief Ranger, Forward Command Safety Officer, state highway patrol commanders for MT/WY/ID, National Guard unit commander, and medical officer from the nearest receiving hospital) convene at T+0 at the FUCE or a nearby regional coordination center. The board chair (NPS Chief Ranger) reviews the pre-written exposure limits (6-hour shifts at ash-exposed posts, 2-hour rest with N95 replacement, 18-hour withdrawal threshold) and confirms that all assigned responders have been briefed on these limits and on the fatigue-hotline contact information. The board also confirms that the 30–50 person standby reserve is stationed outside the ash zone and ready to deploy within 4 hours if staffing falls below 50% at any checkpoint.

**Responsible Body/Role:** Responder Health & Fatigue Management Board (led by NPS Chief Ranger)

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 0 (T+0)

**Key Outputs/Deliverables:**

- Responder Health Board formally established and operational
- Exposure limits briefing memo issued to all assigned responders (rangers, patrol officers, Guard)
- Responder N95 inventory confirmed (counted separately from 100,000 civilian stock); total estimated 150,000–200,000 with 50% surge buffer
- Fatigue-hotline contact information distributed to all responders
- Standby reserve roster confirmed (30–50 personnel stationed outside ash zone, ready to deploy)
- Initial board briefing minutes documenting responder deployment status and shift assignments for the first 6 hours

**Dependencies:**

- FUCE formally established
- All responder positions (rangers, patrol, Guard) assigned and confirmed
- Standby reserve personnel identified, briefed and pre-positioned outside the ash zone

### 11. Authority & Jurisdictional Coordination Cell (Boundary Coordination Officer at the FUCE, NPS IC or delegated zone commander, MT/WY/ID highway patrol and state police on-scene commanders, FEMA Region 10 liaison, and FAA representative) convene at T+0 to formally establish the cell and activate the authority-transfer protocols. The Boundary Coordination Officer briefs all members on the pre-written NPS-to-state handoff protocol at each park exit gate (West, North, East Entrance), confirming that state on-scene commanders have been pre-authorized to issue reroutes without park ranger approval (standing order, pre-signed by the UC chair). The Region 10 liaison confirms that FEMA Region 10 mutual-aid arrangements with Boise and Pocatello emergency management offices are documented in a standing MOU to be finalized by Month 1 (2026-11-14).

**Responsible Body/Role:** Authority & Jurisdictional Coordination Cell (led by Boundary Coordination Officer at FUCE)

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 0 (T+0)

**Key Outputs/Deliverables:**

- Authority Cell formally established and operational at FUCE
- NPS-to-state authority-transfer protocol memo re-issued to all members (West, North, East Entrance gates; roadside checkpoints defined)
- Standing order authorizing state on-scene reroutes without park approval (signed by UC chair, signed by each state emergency manager)
- Authority-transfer log template created (hourly updates tracking vehicle and responder crossings at each gate)
- Region 10 liaison confirmed in position at Denver UC; preliminary mutual-aid contacts from Boise and Pocatello confirmed
- FAA liaison confirmed in position; aviation-grounding procedure and medevac-exception criteria reviewed

**Dependencies:**

- UC formally activated
- FUCE established with Boundary Coordination Officer in position
- Written NPS-to-state handoff protocol drafted and pre-reviewed by all states
- Region 10 liaison identified and contact information confirmed

### 12. Shelter Siting & Air-Quality Assurance Panel (NOAA ashfall/air-quality forecast lead, USGS geochemist, EPA air-quality specialist, FUCE Planning Chief, and Shelter Operations Coordinator) convene at T+0 at the FUCE location. The panel chair (NOAA lead) confirms that real-time PM10 and ashfall-depth monitoring sensors are deployed at the forward element (Livingston) and at the three primary shelter candidates (Bozeman, Idaho Falls, and a third site to be determined based on the T+6 forecast). The panel reviews the pre-surveyed list of 8–10 backup candidate shelters (ranked by distance and upwind position) and confirms that transport agreements (buses, drivers) are in place for emergency relocation of 10,000–15,000 evacuees within 4 hours.

**Responsible Body/Role:** Shelter Siting & Air-Quality Assurance Panel (led by NOAA ashfall/air-quality forecast lead)

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 0 (T+0)

**Key Outputs/Deliverables:**

- Shelter Siting Panel formally established and operational at FUCE
- Real-time PM10 and ashfall-depth monitoring confirmed at forward element and all primary shelter sites; automated alerts armed (thresholds: 50 ug/m³ forecast-update trigger, 100 ug/m³ suitability-review trigger)
- Pre-surveyed backup shelter sites list (8–10 candidates) with capacity, HVAC and filtration specs for each
- Transport agreements for rapid relocation (buses, drivers confirmed) within 4 hours of relocation order
- Initial briefing to UC: current ashfall forecast and modeled ash extent for the 72-hour window

**Dependencies:**

- FUCE formally established
- PM10 monitoring sensors deployed and tested at forward element and shelter sites
- NOAA plume model and forecast data feeding into real-time dashboard
- Backup shelter sites pre-surveyed by Month -1

### 13. UC holds the formal first Unified Command briefing at T+0, with participation by all six UC members (or their confirmed delegates) and representatives from all five specialized advisory bodies (Escalation Cell, FUCE, Responder Health Board, Authority Cell, Shelter Siting Panel). The agenda includes: (1) status of evacuation corridors and gate operations (target 0 departures at T+0, ramping to flow rate of ~2,000 vehicles/hour by T+1); (2) summary of USGS eruption indicators and distance from the Scenario Beta trigger (provided by Escalation Cell); (3) current ashfall forecast and PM10 readings (provided by Shelter Siting Panel); (4) readiness status of water convoys (target dispatch from Salt Lake City by T+12h) and supply logistics (provided by FUCE Logistics Chief); (5) responder staffing and exposure-limit compliance (provided by Responder Health Board); (6) authority-transfer protocols and any initial boundary-coordination issues (provided by Authority Cell). A shared common operating picture (COP) digital dashboard is displayed and updated continuously during the briefing, showing all metrics hourly.

**Responsible Body/Role:** Unified Command (led by FEMA Region VIII IC, chair)

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 0–2 (T+0 to T+2)

**Key Outputs/Deliverables:**

- UC First Briefing agenda and slide deck
- Briefing minutes documenting: evacuation gate status, USGS indicator status, ashfall forecast, supply convoy readiness, responder deployment, and authority-transfer protocol execution
- COP digital dashboard snapshot (baseline T+0 data)
- UC decision log initiated (documenting any real-time decisions, tie-breakers or escalations)
- Attendee roster (UC members and advisors confirmed present or remote)

**Dependencies:**

- UC formally activated
- All five specialized advisory bodies established and operational
- COP digital dashboard live and populated with baseline data
- USGS, NOAA, FUCE, Responder Health Board and Authority Cell ready to brief

### 14. USGS Volcano Disaster Assistance Program lead (Escalation Cell chair) completes the refinement of the pre-authorized USGS trigger matrix using the latest real-time eruption-monitoring data (seismic swarm, GPS uplift, gas emissions, magma-depth models) available at T+3h. The cell finalizes the specific numerical thresholds for: (1) uplift rate (cm/h or cm/6h intervals); (2) seismic-swarm magnitude and frequency triggers; (3) gas-flux thresholds (SO2, CO2); (4) estimated magma depth and ascent rate indicating VEI-7 probability ≥20% in the remaining window (placeholder; USGS to provide exact formula). The finalized matrix is issued in writing and distributed to the UC, FUCE, and all state emergency managers. A dashboard showing the current status of each indicator relative to the finalized trigger thresholds is published and made available to the media and the public to ensure credibility and transparency.

**Responsible Body/Role:** Escalation & Scenario Beta Decision Cell (led by USGS Volcano Disaster Assistance Program lead)

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 3 (T+3h)

**Key Outputs/Deliverables:**

- Finalized USGS trigger-matrix document (signed by USGS Disaster Assistance Program lead)
- Specific numerical thresholds for uplift rate, seismic magnitude, gas flux and magma-depth estimates
- Decision-dashboard snapshot showing current indicator values relative to finalized thresholds
- Trigger-matrix distribution memo to UC, FUCE, states and media
- Public-facing summary of the trigger matrix explaining how Scenario Beta escalation works

**Dependencies:**

- Escalation Cell established at T+0
- Real-time USGS data feeds live and streaming continuously
- Preliminary matrix indicators identified at T+0

### 15. FUCE Operations Chief and FEMA logistics coordinator confirm that contraflow traffic-control operations are active on all three exit corridors (US-20/US-191 via Gallatin Canyon to West Yellowstone, US-89 via Gardiner, US-14/16/20 toward Cody) by T+1 hour. Traffic-control posts are staffed at each corridor (rangers, highway patrol, and National Guard at key junctions and bottlenecks). At least two tow and rockfall-clearance teams are deployed to pre-positioned stations (Mammoth and Spanish Creek area) and confirmed ready to reach any Gallatin Canyon blockage within 15 minutes of dispatch. Guard signal teams with satellite phones, portable repeaters and generator fuel are deployed to each control point and the forward element by T+1 hour. IPAWS (Integrated Public Alert and Warning System) messages in English and five languages (Spanish, Japanese, German, Mandarin, French) are issued to the public, instructing drivers to use designated exit corridors and to follow ranger/patrol instructions.

**Responsible Body/Role:** FUCE Operations Section Chief and Logistics Chief

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 1 (T+1h)

**Key Outputs/Deliverables:**

- Confirmation that contraflow is active on all three corridors (signed statement from each state DOT or National Guard unit)
- Traffic-control post staffing roster (rangers, patrol, Guard) for each corridor and checkpoint
- Tow and rockfall-clearance team deployment confirmation (2+ teams at Mammoth/Spanish Creek area, ready for 15-minute response)
- Guard signal-team deployment confirmation at all control points and forward element
- IPAWS message distribution log (English and five languages; timestamp of broadcast and carrier confirmation)

**Dependencies:**

- UC formally activated and evacuation order issued by project sponsor
- FUCE Operations Chief in position at Livingston
- Tow teams and Guard signal teams pre-positioned or nearby and ready to deploy

### 16. Shelter Siting Panel conducts the formal selection of final shelter sites at T+6 hours, using the latest NOAA/USGS plume forecast and real-time PM10 monitoring data. The panel reviews the ashfall-extent forecast, wind direction and ash-concentration projections for the next 72 hours. Based on this forecast, the panel recommends primary and backup shelter sites that lie outside or upwind of the modeled ash footprint. The FUCE Operations Chief formally approves the shelter-site selections and issues assignments to the Bozeman and Idaho Falls shelters (or alternates if the forecast indicates those sites are unsuitable). Buses and intake staff are dispatched to the selected sites to prepare for receiving the first evacuees (expected arrival T+6 to T+12h).

**Responsible Body/Role:** Shelter Siting & Air-Quality Assurance Panel (led by NOAA forecast lead) with final approval by FUCE Operations Chief

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 6 (T+6h)

**Key Outputs/Deliverables:**

- Final shelter-site selection recommendation from the Shelter Siting Panel (with ashfall-forecast justification)
- PM10 and ashfall-depth readings at all candidate sites at T+6h
- FUCE approval memo for final shelter assignments
- Shelter intake and operations teams dispatched and confirmation of arrival at selected sites
- Briefing to UC documenting the shelter-siting decision and any deviations from the pre-planned Bozeman/Idaho Falls locations

**Dependencies:**

- Shelter Siting Panel established and monitoring active at T+0
- Real-time PM10 sensors at all candidate sites
- NOAA plume forecast updated at T+6h

### 17. UC issues a milestone assessment at T+6 hours, checking against the Phase 1 'go/no-go' gate: at least 98% of the 35,800 Zone Zero evacuees (about 35,084) have been counted as having exited through the three corridors (West, North, East gates). Real-time exit counts from each state patrol and NPS checkpoint are consolidated in the COP dashboard. If the gate is met, the UC documents clearance and advises that Zone Zero is essentially cleared, with remaining stragglers (estimated 200–400 backcountry hikers and permit holders) under active ranger sweep and accounting. If the gate is not met (e.g., due to a blockage that delayed departures), the UC convenes an emergency reroute decision with the FUCE and Authority Cell to redirect any remaining vehicles and assess whether the 72-hour window timeline needs adjustment.

**Responsible Body/Role:** Unified Command (led by FEMA Region VIII IC) with real-time data from FUCE and state checkpoints

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 6 (T+6h)

**Key Outputs/Deliverables:**

- Phase 1 Gate G1 assessment document (yes/no decision: at least 98% of 35,800 confirmed out)
- Cumulative exit counts by corridor (West, North, East) at T+6h
- List of any remaining unaccounted-for parties (backcountry, lodges, permit holders); status of ranger sweeps
- UC briefing documenting gate results and any reroute or staffing adjustments triggered by shortfalls
- COP dashboard snapshot at T+6h showing gate status, ashfall conditions and shelter readiness

**Dependencies:**

- Contraflow operations active on all three corridors from T+0 to T+6
- Real-time exit counting and reporting from state checkpoints and NPS
- FUCE and Authority Cell coordinating reroutes and gate-status reporting

### 18. UC issues a formal public statement and IPAWS alert at T+6 hours, confirming that Zone Zero (park interior) has been cleared or is nearly cleared, and that the evacuation is transitioning to Phase 2: expansion of Zone One (100 km radius including West Yellowstone, Gardiner and Cody communities). The statement reiterates the pre-authorized USGS trigger matrix and explains that if the triggers for Scenario Beta (VEI-7) are detected, a 500 km evacuation order will be issued immediately without further deliberation. The statement also confirms current shelter locations (Bozeman, Idaho Falls and any third site), water convoy dispatch status (target T+12h from Salt Lake City), and the N95 pre-staging locations. This public statement is critical for sustaining public trust and explaining the escalation logic before Scenario Beta messaging may become necessary.

**Responsible Body/Role:** Unified Command (FEMA Region VIII IC) in coordination with NOAA Public Affairs and NPS Communications

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 6 (T+6h)

**Key Outputs/Deliverables:**

- UC public statement confirming Phase 1 clearance and Zone One expansion (signed by FEMA Region VIII IC)
- IPAWS alert in English and five languages explaining Scenario Beta trigger logic and shelter locations
- Media briefing slides and talking points for state and federal public affairs
- Confirmation of broadcast on local radio, TV and social-media channels

**Dependencies:**

- Phase 1 Gate G1 assessment complete
- Shelter siting decisions finalized
- USGS trigger matrix finalized and published

### 19. FEMA Region VIII IC (UC chair) or designee issues written pre-authorization letters to each of the three state governors (Montana, Wyoming, Idaho), requesting verbal confirmation of their authorization of the UC's Zone One and Scenario Beta (500 km) evacuation orders. The letters explain: (1) the current status of the evacuation (Phase 1 complete, Zone One now being evacuated); (2) the pre-written USGS trigger matrix and how Scenario Beta will be triggered if thresholds are crossed; (3) the request for each governor to confirm that they accept the UC's authority to issue and enforce these orders on state highways and in state communities; (4) the expectation that formal Memoranda of Understanding (MOUs) and EMAC mutual-aid agreements will be signed by Month 1 (2026-11-14). Verbal confirmations are recorded and documented in the UC decision log.

**Responsible Body/Role:** FEMA Region VIII IC (UC chair) on behalf of the Unified Command

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 6 (T+6h)

**Key Outputs/Deliverables:**

- Pre-authorization letters issued to MT, WY and ID governors (transmitted via secure fax and secure email)
- Verbal confirmations recorded and transcribed (audio or written summary)
- UC decision-log entries documenting each governor's confirmation (or any objections/conditions)
- Schedule confirmed for signing formal MOUs by Month 1 (2026-11-14)

**Dependencies:**

- Zone One evacuation order issued by project sponsor (NPS and FEMA)
- Phase 1 Gate G1 assessment complete
- USGS trigger matrix finalized

### 20. FUCE Logistics Chief confirms that bottled-water convoys from Salt Lake City distribution centers have been dispatched by T+12 hours (per the T+12h target), using National Guard escorts and reserved lanes on I-15 northbound (proposed dedicated 'supply-surge' lane). The Logistics Chief tracks the real-time location of each convoy via GPS and reports arrival estimates at Bozeman and Idaho Falls shelters. If the forecast arrival time exceeds T+24h (the Phase 2 gate deadline), the Logistics Chief alerts the FUCE Operations Chief and the UC, triggering contingency actions: (1) advance dispatch of supplemental water from forward depots in Bozeman, Billings and Idaho Falls (pre-positioned at T-48 hours before the event); (2) activation of the supplemental N95 reserve at Billings or Salt Lake City if ashfall is heavier than modeled.

**Responsible Body/Role:** FUCE Logistics Section Chief

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 12 (T+12h)

**Key Outputs/Deliverables:**

- Water-convoy dispatch confirmation from Salt Lake City (signed order, timestamp, carrier confirmation)
- Convoy tracking (GPS coordinates, real-time location updates, ETA at Bozeman and Idaho Falls)
- Contingency activation decision (if ETA >T+24h): order for forward-depot supplemental water and supplemental N95 deployment
- Briefing to FUCE and UC documenting water-supply status and any logistics adjustments

**Dependencies:**

- FUCE Logistics Chief in position
- Water-supply contracts with pre-authorized 12-hour dispatch clauses in place (signed before Month 0 = 2026-10-14)
- Forward depots at Bozeman, Billings and Idaho Falls pre-stocked with water and N95 by T-48h

### 21. Authority Cell conducts a formal review of authority-transfer and jurisdictional-coordination execution at T+12 hours. The Boundary Coordination Officer consolidates reports from all three state on-scene commanders (MT at West/Gardiner, WY at Cody, ID at Idaho Falls) documenting: (1) cumulative vehicle and evacuee counts that have crossed from NPS to state control at each boundary checkpoint; (2) any reroutes or traffic-control adjustments issued by state commanders (all within pre-authorized standing orders); (3) any disputes or coordination gaps that required escalation to the FUCE or UC. The cell issues a brief status report to the UC confirming that the authority transfer is executing smoothly or flagging any issues requiring UC decision-making.

**Responsible Body/Role:** Authority & Jurisdictional Coordination Cell (led by Boundary Coordination Officer)

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 12 (T+12h)

**Key Outputs/Deliverables:**

- Authority-transfer execution report from Boundary Coordination Officer
- Cumulative authority-transfer log (vehicles and responders crossing from NPS to state control at each gate)
- Summary of reroutes issued by state on-scene commanders (all within standing authorization)
- Any disputes or escalations identified and the resolution
- Briefing to FUCE and UC documenting jurisdictional-coordination status

**Dependencies:**

- Authority Cell established at T+0
- Standing orders authorizing state reroutes issued at T+0
- State on-scene commanders in position at their respective gates and checkpoints

### 22. Responder Health Board conducts a mandatory 6-hour fatigue-risk assessment at T+12 hours, analyzing cumulative hours worked by all assigned responders (rangers, patrol, Guard at traffic-control and perimeter posts) since T+0. The board reviews shift logs and identifies any responders approaching or exceeding the 18-hour withdrawal threshold (proposed threshold). Any responders exceeding 6 hours at ash-exposed posts without a 2-hour rest break are flagged for immediate rotation. The board also tallies N95 mask usage and confirms that inventory is adequate for the next 12 hours. If usage is exceeding expectations (e.g., heavy ashfall causing faster mask clogging), the board signals the FUCE Logistics Chief to activate supplemental responder N95 reserves.

**Responsible Body/Role:** Responder Health & Fatigue Management Board (led by NPS Chief Ranger)

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 12 (T+12h)

**Key Outputs/Deliverables:**

- Responder fatigue-risk assessment report documenting cumulative hours worked by all deployed responders
- List of responders exceeding exposure limits or requiring immediate rotation
- N95 inventory and consumption summary (actual vs. modeled expected usage)
- Contingency activation decision (if usage exceeding expectations)
- Briefing to FUCE and UC with staffing-continuity recommendations

**Dependencies:**

- Responder Health Board established at T+0
- Shift logs maintained at all traffic-control posts and forwarded to the board every 2 hours
- N95 inventory tracked in real time at each post

### 23. Escalation Cell issues an Escalation Readiness Assessment at T+12 hours, reporting the current status of each USGS eruption indicator (uplift rate, seismic magnitude, gas flux, magma depth) relative to the finalized Scenario Beta trigger thresholds. The cell states how far (percentage or margin) each indicator is from the trigger and estimates the time to trigger if current trends continue. The cell also reviews the current ashfall forecast and PM10 readings, noting any changes from the T+6h forecast. This briefing is delivered to the UC and published in a summary format suitable for media and public consumption, maintaining transparency about the eruption state and the likelihood of Scenario Beta escalation.

**Responsible Body/Role:** Escalation & Scenario Beta Decision Cell (led by USGS Volcano Disaster Assistance Program lead)

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 12 (T+12h)

**Key Outputs/Deliverables:**

- Escalation Readiness Assessment document (1-2 pages, signed by USGS lead)
- Current indicator-status dashboard (snapshot of each indicator relative to finalized thresholds)
- Estimated time-to-trigger calculation if current trends continue
- Updated ashfall forecast and PM10 readings
- Public-facing summary explaining the escalation status in non-technical language

**Dependencies:**

- Escalation Cell established at T+0
- USGS trigger matrix finalized by T+3h
- Real-time USGS monitoring data streaming continuously

### 24. UC holds the T+12 hour formal briefing, consolidating status reports from the FUCE, all five specialized advisory bodies, and state on-scene commanders. The agenda includes: (1) Zone One evacuation progress (target: evacuees flowing into Bozeman, Idaho Falls and third shelter site; intake and registration ongoing); (2) USGS indicator status and Scenario Beta readiness; (3) ashfall forecast and shelter-suitability status (PM10 readings, any triggers for relocation analysis); (4) water convoy ETA and supply-logistics status; (5) responder fatigue and staffing continuity; (6) authority-transfer execution and any jurisdictional disputes. The UC documents any mid-course corrections needed (e.g., reroutes, shelter relocation preparations, additional Guard deployment) and issues updated orders to the FUCE and state commanders.

**Responsible Body/Role:** Unified Command (led by FEMA Region VIII IC, chair)

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 12 (T+12h)

**Key Outputs/Deliverables:**

- UC T+12h Briefing agenda and briefing minutes
- Status summaries from FUCE, advisory bodies and states (consolidated into one briefing package)
- COP dashboard snapshot at T+12h
- UC decision log documenting any mid-course orders or escalations
- Updated UC daily orders (if needed) to FUCE and state commanders

**Dependencies:**

- FUCE status report prepared and submitted on time
- All five advisory bodies prepared to brief at T+12h

### 25. FEMA Region VIII IC (UC chair), on behalf of the Unified Command, issues a written request to the three state governors (MT, WY, ID) and to FEMA Region 10 (Seattle) requesting formal signing of Memoranda of Understanding (MOUs) and EMAC mutual-aid agreements by Month 1 (2026-11-14). The request includes draft MOU language covering: (1) each state's acceptance of the UC's authority to issue Zone One and Scenario Beta evacuation orders; (2) commitment to enforce unified evacuation messaging and shelter assignments on state roads and in state communities; (3) provision of state resources (highway patrol, National Guard) to support contraflow and perimeter operations; (4) mutual-aid resource sharing (water, fuel, medical) among the three states and with FEMA Regions 8 and 10; (5) post-event after-action-report and exercise planning for Months 1–3 (2026-11-14 to 2027-01-14). This request initiates a formal negotiation period that culminates in signed agreements by Month 1 (2026-11-14).

**Responsible Body/Role:** FEMA Region VIII IC (UC chair) on behalf of the Unified Command

**Suggested Timeframe:** Month 0 (2026-10-14), Hours 24–36 (T+24h to T+36h)

**Key Outputs/Deliverables:**

- MOU and EMAC agreement request letters issued to MT, WY and ID governors and FEMA Region 10
- Draft MOU and EMAC language (attached to request letters)
- Schedule for MOU-signature meetings (targeted completion by Month 1, 2026-11-14)
- UC decision-log entry documenting issuance of MOU requests

**Dependencies:**

- Verbal governor authorizations obtained at T+6h
- Unified Command operations progressing smoothly
- No major disputes or coordination gaps between NPS and states

### 26. UC issues a milestone assessment at T+24 hours, checking against the Phase 2 'go/no-go' gate: at least 95% of registered Zone One residents (West Yellowstone, Gardiner, Cody communities) have evacuated or sheltered in place, perimeters around evacuated towns are staffed and secured by National Guard to prevent looting, and a preliminary Scenario Beta interim-destination list (ranked hub list outside the 500 km ring) has been issued. The UC consolidates reports from the FUCE, state on-scene commanders and the Shelter Siting Panel, documenting evacuation completeness, perimeter-staffing status and shelter-intake progress. If the gate is met, the UC documents successful completion of Phase 2 and advises that the response has transitioned to the 'sustained operations' phase (T+24h to T+72h), during which the focus shifts to supply continuity, ashfall management and Scenario Beta readiness.

**Responsible Body/Role:** Unified Command (led by FEMA Region VIII IC) with data from FUCE, state commanders and advisory bodies

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 24 (T+24h)

**Key Outputs/Deliverables:**

- Phase 2 Gate G2 assessment document (yes/no decision: at least 95% of Zone One residents out; perimeters staffed; interim hub list issued)
- Zone One evacuation completion report by community (West Yellowstone, Gardiner, Cody)
- Perimeter-staffing and anti-looting operational status
- Interim Scenario Beta hub-destination list (ranked candidates outside the 500 km ring)
- UC briefing documenting gate results and transition to sustained-operations phase
- COP dashboard snapshot at T+24h

**Dependencies:**

- Zone One evacuation proceeding as planned from T+6h to T+24h
- Perimeter enforcement and National Guard deployment completed
- Scenario Beta hub preliminary list researched and drafted by planning staff

### 27. Shelter Siting Panel conducts formal suitability assessments at T+24, T+36, T+48, T+60 and T+72 hours, comparing real-time PM10 readings and ashfall forecasts at all active shelter sites against the established thresholds (50 ug/m³ for forecast-update trigger, 100 ug/m³ for suitability-review trigger). If any site exceeds the suitability threshold, the panel initiates a rapid relocation analysis (decision within 30 minutes proposed threshold) and recommends a backup site. A relocation order (issued by FUCE Operations Chief within 4 hours of threshold exceedance proposed threshold) specifies the new shelter site, transport routing and pickup schedule. The panel tracks all relocation logistics and confirms arrival of evacuees at the new site. This continuous monitoring and rapid-response protocol prevents evacuees from being sheltered in heavy ashfall and developing respiratory distress.

**Responsible Body/Role:** Shelter Siting & Air-Quality Assurance Panel (led by NOAA forecast lead) with execution by FUCE Operations Chief

**Suggested Timeframe:** Month 0 (2026-10-14), Hours 24, 36, 48, 60, 72 (T+24h, T+36h, T+48h, T+60h, T+72h)

**Key Outputs/Deliverables:**

- Shelter-suitability assessment reports at each time interval (T+24h, T+36h, T+48h, T+60h, T+72h)
- PM10 and ashfall-depth readings at all active and backup shelter sites
- Any relocation analyses and recommendations
- Relocation orders issued by FUCE Operations Chief (if suitability thresholds exceeded)
- Transport and logistics confirmation for any relocation (buses, pickup schedule, arrival confirmation)

**Dependencies:**

- Shelter Siting Panel established at T+0 with continuous PM10 monitoring
- Real-time PM10 data streaming to the panel and FUCE
- Backup shelter sites pre-surveyed and transport agreements in place

### 28. UC holds continuous hourly briefings (in addition to the scheduled T+0, T+2, T+6, T+12, T+24, T+36, T+48, T+60, T+72h formal briefings) during the 72-hour window, with rapid-update reports from the FUCE on any critical changes: corridor blockages, major weather shifts, ashfall intensity changes, supply delays or any USGS eruption-indicator changes approaching the Scenario Beta trigger threshold. These rapid-update calls (conducted via secure conference line) allow the UC to make real-time tactical decisions (reroutes, shelter relocations, supply contingencies) without waiting for the formal scheduled briefing. All UC decisions made between scheduled briefings are logged in the UC decision log with full documentation and time stamps.

**Responsible Body/Role:** Unified Command (led by FEMA Region VIII IC, chair) with participation by FUCE Operations Chief and key advisory-body leads as needed

**Suggested Timeframe:** Month 0 (2026-10-14), Hours 0–72 (T+0 to T+72h), continuous as needed between scheduled briefings

**Key Outputs/Deliverables:**

- Rapid-update call logs (time, participants, issue discussed, decision made)
- UC decision log entries for all decisions made on rapid-update calls
- COP dashboard updated in real time following each rapid-update call
- Notification memos to affected parties (states, FUCE, advisory bodies) documenting new UC orders or directives

**Dependencies:**

- UC continuously staffed at the FEMA Region VIII RRCC Denver
- FUCE Operations Chief available for rapid escalation calls 24/7
- Secure conference-line infrastructure and communications tested

### 29. Escalation Cell continuously monitors real-time USGS eruption indicators throughout the 72-hour window and immediately alerts the UC if any indicator crosses 80% of the Scenario Beta trigger threshold (a warning threshold), triggering a pre-brief for the UC. If any indicator crosses the full trigger threshold, the Escalation Cell convenes an immediate 5-minute verification meeting, confirms the threshold crossing, and issues a formal Trigger Crossing Declaration to the UC within 15 minutes. The UC, upon receiving this declaration, has a standing order to issue the Scenario Beta 500 km evacuation order within 30 minutes without requiring further deliberation or approval.

**Responsible Body/Role:** Escalation & Scenario Beta Decision Cell (led by USGS Volcano Disaster Assistance Program lead) with immediate notification to UC

**Suggested Timeframe:** Month 0 (2026-10-14), Hours 0–72 (T+0 to T+72h), continuous real-time monitoring

**Key Outputs/Deliverables:**

- Real-time indicator monitoring and hourly status briefings to UC (scheduled briefings at T+0, T+6, T+12, T+18, T+24, T+30, T+36, T+42, T+48, T+54, T+60, T+66, T+72h)
- Warning-threshold alerts (80% of trigger threshold) sent to UC and FUCE
- Trigger Crossing Declaration (if full threshold crossed), signed by USGS lead and issued within 15 minutes of detection
- UC decision log entry documenting Trigger Crossing Declaration and the Scenario Beta order issued within 30 minutes (if triggered)

**Dependencies:**

- Escalation Cell established at T+0
- Real-time USGS data feeds live and streaming continuously
- USGS trigger matrix finalized by T+3h
- UC standing order to issue Scenario Beta order within 30 minutes of Trigger Crossing Declaration

### 30. UC, upon receiving a Scenario Beta Trigger Crossing Declaration from the Escalation Cell, issues a formal Scenario Beta 500 km Evacuation Order within 30 minutes. The order specifies: (1) the eruption indicators that crossed the trigger threshold; (2) the 500 km radius evacuation boundary; (3) the tiered execution rings (0–100 km organized evacuation, 100–250 km time-banded evacuation, 250–500 km staged departures); (4) the interim Scenario Beta hub destinations (ranked list outside the 500 km ring); (5) the activation of the secondary-stage shelter and logistics plans (pre-authorized buses, rail corridors, secondary hubs with pre-signed host MOUs); (6) instructions to states, National Guard and FEMA to immediately activate all Scenario Beta contingency plans. This order is broadcast via IPAWS, WEA, NOAA Weather Radio, Guard signal bridging and media in English and five languages.

**Responsible Body/Role:** Unified Command (led by FEMA Region VIII IC, chair)

**Suggested Timeframe:** Month 0 (2026-10-14), within 30 minutes of Scenario Beta Trigger Crossing Declaration (exact time depends on trigger occurrence)

**Key Outputs/Deliverables:**

- Formal Scenario Beta 500 km Evacuation Order (signed by FEMA Region VIII IC on behalf of UC)
- Tiered-execution guidance for the three evacuation rings (0–100 km organized, 100–250 km time-banded, 250–500 km staged)
- Interim hub-destination list and assignments (which populations to which secondary hubs)
- Activation orders for secondary-stage shelter, logistics and transport contingencies
- Broadcast confirmation (IPAWS, WEA, NOAA, Guard signal, media in multiple languages)
- UC briefing documenting the Scenario Beta escalation and all decisions made in the 30-minute window

**Dependencies:**

- Scenario Beta Trigger Crossing Declaration received from Escalation Cell
- Interim hub-destination list prepared by FUCE Planning Chief before T+24h (Month 0 = 2026-10-14 Hour 24)
- Secondary-stage shelter, logistics and transport plans pre-authorized and ready for immediate activation
- Pre-signed MOUs with secondary hub host communities available (MOUs to be finalized by Month 1 = 2026-11-14, but interim working agreements pre-authorized for T+0 startup)

### 31. Upon issuance of a Scenario Beta 500 km Evacuation Order, the Unified Command immediately convenes an expanded UC Scenario Beta Response Cell, adding representatives from: (1) the secondary hub communities (Denver, Cheyenne, Billings) or their designees; (2) the National Guard regional commanders for out-of-state Guard deployment; (3) the U.S. Army Corps of Engineers (if emergency logistics support is needed); (4) representatives from the Department of Transportation (federal coordination of I-15, I-80, I-90 usage and emergency lane closures). This expanded cell meets continuously (at least every 2 hours) to coordinate the execution of the three evacuation rings, the routing of populations to secondary hubs, the activation of bus fleets and rail corridors, and the pre-positioning of supplies at secondary hubs.

**Responsible Body/Role:** Unified Command (led by FEMA Region VIII IC) expanded with secondary hub representatives, National Guard, USACE and DOT

**Suggested Timeframe:** Month 0 (2026-10-14), immediately upon Scenario Beta Evacuation Order issuance

**Key Outputs/Deliverables:**

- Expanded Scenario Beta Response Cell established (charter, membership, communication protocols)
- Activation of ring-by-ring evacuation and routing guidance (which populations to which secondary hubs, which roads and routes to use)
- Bus-fleet and rail-corridor deployment confirmation from National Guard and commercial carriers
- Supply pre-positioning confirmation at secondary hubs (water, N95, fuel, medical supplies shipped to Denver, Cheyenne, Billings)
- Briefing to expanded cell documenting Scenario Beta response execution and contingency plans

**Dependencies:**

- Scenario Beta 500 km Evacuation Order issued by UC
- Secondary hub list and interim MOUs pre-authorized (MOUs to be finalized by Month 2 = 2026-12-14, but interim working agreements in place)
- Bus fleets and rail carriers pre-contracted with standing activation clauses (signed before Month 0 = 2026-10-14)
- National Guard commanders briefed on Scenario Beta contingency plans and ready to receive orders

### 32. At T+72 hours (end of the 72-hour decision window), the UC holds a formal status briefing documenting: (1) total evacuees received and sheltered (Zone Zero and Zone One); (2) final status of the Scenario Beta escalation (if triggered or if indicators remained below threshold); (3) cumulative supply deliveries (water, N95, fuel) and any shortages or contingency activations; (4) responder casualties or exposure-limit violations; (5) post-event safety assessment for any re-entry or infrastructure restoration activities. The UC transitions governance from 72-hour crisis operations to Months 1–3 (2026-11-14 to 2027-01-14) hardening and post-event review mode, with daily (instead of hourly) briefings and a focus on documentation, MOUs, exercises and after-action planning.

**Responsible Body/Role:** Unified Command (led by FEMA Region VIII IC, chair)

**Suggested Timeframe:** Month 0 (2026-10-14), Hour 72 (T+72h)

**Key Outputs/Deliverables:**

- UC T+72h Final Status Briefing agenda and briefing minutes
- Cumulative evacuation statistics and shelter occupancy by site
- Scenario Beta status (triggered or not; if triggered, execution summary)
- Supply-delivery summary (water, N95, fuel actual vs. target, any shortages)
- Responder incident summary (casualties, exposure violations, fatigue-related incidents)
- Post-event safety assessment and re-entry/infrastructure restoration preliminary guidance
- UC decision log final entries and closure
- Transition briefing to Phase 3 (Months 1–3 = 2026-11-14 to 2027-01-14 hardening and post-event review)

**Dependencies:**

- Continuous 72-hour UC operations from T+0 to T+72h
- All formal and rapid-update briefings completed on schedule
- All specialist advisory bodies operational and reporting throughout

### 33. FEMA Region VIII IC (UC chair) or designee convenes the first Months 1–3 (2026-11-14 to 2027-01-14) Hardening & Post-Event Review meeting with UC members, specialized advisory-body leads, state emergency managers, USGS, NOAA and NPS representatives. The meeting covers: (1) what went well and what could be improved in the 72-hour response (based on preliminary field observations and responder interviews); (2) a schedule for signed MOUs with the three governors, FEMA Region 10, utilities and Scenario Beta hub communities (target Month 1 = 2026-11-14 completion); (3) a schedule for three after-action reports (one at Month 1 = 2026-11-14 for the 72-hour response, one at Month 2 = 2026-12-14 for MOU and exercise readiness, one at Month 3 = 2027-01-14 for full post-event review); (4) a calendar for three full-scale multi-state exercises (one at Month 2 = 2026-12-14 covering boundary authority transfer and reroutes, one at Month 2.5 = 2026-12-29 covering Scenario Beta evacuation and hub coordination, one at Month 3 = 2027-01-14 covering integrated response) and six smaller operational exercises (shift-rotation, water-convoy, grid-failure recovery, multilingual alert testing, shelter relocation and post-event re-entry).

**Responsible Body/Role:** FEMA Region VIII IC (UC chair) or designee, with participation from all UC and advisory-body leads

**Suggested Timeframe:** Month 1 (2026-11-14), Week 1 (first week after T+72h)

**Key Outputs/Deliverables:**

- Hardening & Post-Event Review meeting agenda and minutes
- Preliminary improvements list (based on 72-hour response observations)
- MOU signature schedule (target dates for governors, Region 10, utilities, hub communities)
- After-action-report schedule (Month 1 = 2026-11-14, Month 2 = 2026-12-14, Month 3 = 2027-01-14 reports, with interim field-observer summaries)
- Full-scale exercise calendar (three multi-state exercises in Months 2–3 = 2026-12-14 to 2027-01-14) and six smaller operational exercises (Months 1–3 = 2026-11-14 to 2027-01-14)
- Resource allocation for hardening activities and exercise execution (cost estimates, personnel assignments)

**Dependencies:**

- 72-hour response completed at T+72h
- Preliminary field observations and responder feedback collected from all regions
- All UC and advisory-body records and decision logs from the 72-hour window accessible for review

### 34. FEMA Region VIII IC (UC chair) and state emergency managers (MT, WY, ID governors or their designees) sign formal Memoranda of Understanding (MOUs) confirming: (1) each state's acceptance of the UC's authority to issue Zone One and Scenario Beta evacuation orders; (2) commitment to enforce unified evacuation messaging and shelter assignments on state roads and communities; (3) provision of state resources (highway patrol, National Guard) to support contraflow and perimeter operations; (4) mutual-aid resource sharing (water, fuel, medical supplies) among the three states and FEMA Regions 8 and 10; (5) commitment to participate in post-event exercises and after-action-report development. Simultaneous MOUs are signed with FEMA Region 10 (Seattle), regional utilities (Montana-Dakota Utilities, Pacific Power, Idaho Power) and Scenario Beta secondary hub communities (Denver, Cheyenne, Billings or others outside the 500 km ring). All MOUs are signed by the deadline of Month 1 (2026-11-14).

**Responsible Body/Role:** FEMA Region VIII IC (UC chair) for the federal side; state governors for their respective states; utilities and hub-community representatives for their organizations

**Suggested Timeframe:** Month 1 (2026-11-14) by end of month

**Key Outputs/Deliverables:**

- Signed MOUs with MT, WY and ID governors (three documents, signed and countersigned)
- Signed MOU with FEMA Region 10 (Seattle)
- Signed MOUs with regional utilities (Montana-Dakota Utilities, Pacific Power, Idaho Power)
- Signed MOUs with Scenario Beta secondary hub communities (Denver, Cheyenne, Billings, etc.)
- EMAC mutual-aid agreements activation confirmations (among MT, WY, ID and with FEMA Regions 8 and 10)
- Distribution of all signed MOUs to UC members and advisory-body leads

**Dependencies:**

- Draft MOU language circulated to all parties by Month 0 (2026-10-14) Hour 36
- Hardening & Post-Event Review meeting held at Month 1 (2026-11-14) Week 1
- Legal review of MOU language by each party's legal counsel completed

### 35. FEMA Region VIII IC (UC chair) or designee publishes the first After-Action Report (AAR-1: 72-Hour Response) by Month 1 (2026-11-14), documenting: (1) a timeline and narrative of the 72-hour evacuation response (T+0 to T+72h); (2) quantitative outcomes (total evacuees sheltered, supply deliveries, responder incidents, gateway clearance rates); (3) comparison of actual outcomes to pre-planned targets (98% Zone Zero clearance by T+6h, 95% Zone One clearance by T+24h, etc.); (4) critical decisions made and their rationale (recorded from UC decision log); (5) responder feedback and preliminary observations (lessons learned); (6) recommendations for improvements to the governance structure, command protocols, supply logistics or communications. The AAR-1 is distributed to all UC members, state emergency managers, USGS, NOAA, NPS and is published as a public document to maintain transparency.

**Responsible Body/Role:** FEMA Region VIII IC (UC chair) or designee, with input from FUCE, advisory bodies and state representatives

**Suggested Timeframe:** Month 1 (2026-11-14)

**Key Outputs/Deliverables:**

- After-Action Report-1 (AAR-1: 72-Hour Response, 20–30 pages)
- Quantitative outcomes summary table (evacuation statistics, supply metrics, incidents)
- Comparison of actual vs. planned outcomes
- Critical decisions narrative (from UC decision log)
- Responder feedback and field observations summary
- Recommendations for improvements (tagged as short-term, medium-term, or long-term actions)
- Distribution memo and public-release summary

**Dependencies:**

- 72-hour response completed at T+72h
- UC decision log and all briefing minutes consolidated and reviewed
- Field observations and responder feedback collected from all regions by Month 1 (2026-11-14) Week 1

### 36. FEMA Region VIII IC (UC chair) or designee convenes the first full-scale multi-state exercise (Exercise-1: 'Cascade Boundary') in Month 2 (2026-12-14), testing the authority-transfer protocols and reroute decision-making across the NPS-to-state boundaries at all three exit gates (West, North, East Entrance). The exercise simulates a Gallatin Canyon blockage at T+3h that requires a 45-minute clearance attempt (proposed threshold) followed by automatic diversion of overflow traffic to the US-89 Gardiner corridor. The exercise tests: (1) whether the Boundary Coordination Officer and state on-scene commanders can issue reroutes within 5 minutes of the blockage detection; (2) whether the COP dashboard is updated in real time with traffic redirects; (3) whether drivers receive updated route guidance via IPAWS, HAR, VMS or printed route cards; (4) whether the diversion adds only the planned 2–4 hours to transit times for affected vehicles, not more. Exercise participants include the FUCE, state traffic-control personnel at each gate, the Authority Cell, the Shelter Siting Panel and a sample of drivers (simulated evacuees in vehicles with communications staff).

**Responsible Body/Role:** FEMA Region VIII IC (UC chair) or designee, with FUCE Operations Chief as exercise director

**Suggested Timeframe:** Month 2 (2026-12-14), Week 1 (2026-12-14, within first week of month)

**Key Outputs/Deliverables:**

- Exercise-1 planning memo and scenario description
- Exercise-1 'Cascade Boundary' simulation (2-4 hours duration, in-person or hybrid)
- Post-exercise hot wash (immediate feedback from participants on what worked and what didn't)
- Exercise-1 After-Action Report (preliminary, by Month 2 = 2026-12-14 Week 2)

**Dependencies:**

- Hardening & Post-Event Review meeting held at Month 1 (2026-11-14) Week 1
- AAR-1 (72-Hour Response) published by Month 1 (2026-11-14)
- All three states and FUCE committed to exercise participation

### 37. FEMA Region VIII IC (UC chair) or designee convenes the second full-scale multi-state exercise (Exercise-2: 'Ring Dispersal') in Month 2.5 (2026-12-29), testing Scenario Beta execution: the Escalation Cell simulates a USGS Trigger Crossing Declaration at a notional T+36h, triggering the UC to issue a 500 km Evacuation Order. The exercise tests: (1) whether the UC issues the order within 30 minutes of trigger declaration; (2) whether the expanded Scenario Beta Response Cell activates and coordinates ring-by-ring evacuation (0–100 km organized, 100–250 km time-banded, 250–500 km staged); (3) whether secondary hub communities (Denver, Cheyenne) receive and begin processing evacuees within their assigned rings; (4) whether bus fleets and rail corridors are deployed to move evacuees from primary shelters (Bozeman, Idaho Falls) to secondary hubs within the planned timelines; (5) whether supply pre-positioning at secondary hubs is confirmed and adequate. Exercise participants include the UC, FUCE, secondary hub emergency managers, National Guard, bus and rail operators, and simulated evacuee populations.

**Responsible Body/Role:** FEMA Region VIII IC (UC chair) or designee, with FUCE Operations Chief as exercise director

**Suggested Timeframe:** Month 2.5 (2026-12-29, between Months 2 and 3 = 2026-12-14, 2027-01-14)

**Key Outputs/Deliverables:**

- Exercise-2 planning memo and Scenario Beta scenario description
- Exercise-2 'Ring Dispersal' simulation (4-6 hours duration, multi-state, in-person or hybrid)
- Post-exercise hot wash (feedback on Scenario Beta coordination, ring execution, hub readiness)
- Exercise-2 After-Action Report (preliminary, by Month 3 = 2027-01-14 Week 1)

**Dependencies:**

- Hardening & Post-Event Review meeting held at Month 1 (2026-11-14) Week 1
- AAR-1 (72-Hour Response) published by Month 1 (2026-11-14)
- Signed MOUs with secondary hub communities by Month 1 (2026-11-14) end
- Secondary hub emergency managers and National Guard committed to exercise participation

### 38. FEMA Region VIII IC (UC chair) or designee convenes the third full-scale multi-state exercise (Exercise-3: 'Yellowstone Integrated Response') in Month 3 (2027-01-14), integrating all elements of the response: the Escalation Cell simulates real-time eruption indicators during a 12-hour compressed exercise timeline, the Unified Command makes strategic decisions (zone expansion, Scenario Beta triggers), the FUCE executes tactical operations (contraflow, tow dispatch, water convoy routing), the Responder Health Board manages shift rotation and fatigue, the Authority Cell coordinates boundary transfers, the Shelter Siting Panel monitors PM10 and triggers relocations, and the Scenario Beta Response Cell (if triggered) activates ring-by-ring evacuation. The exercise tests the integrated governance structure under conditions approaching the actual 72-hour response complexity. Exercise participants include all UC and advisory-body members, state emergency managers, FUCE staff, utilities, hospitals, shelter operators, bus and rail carriers, and secondary hub representatives.

**Responsible Body/Role:** FEMA Region VIII IC (UC chair) or designee, with FUCE Operations Chief as exercise director

**Suggested Timeframe:** Month 3 (2027-01-14), Week 2 (2027-01-14, within second or third week of month)

**Key Outputs/Deliverables:**

- Exercise-3 planning memo and integrated-response scenario description
- Exercise-3 'Yellowstone Integrated Response' simulation (8-12 hours duration, 12-hour compressed timeline, multi-state, in-person at FEMA RRCC and FUCE forward element)
- Real-time COP dashboard and decision-log documentation during exercise
- Post-exercise hot wash with all participants
- Exercise-3 After-Action Report (detailed, by Month 3 = 2027-01-14 Week 3 or 4)

**Dependencies:**

- Hardening & Post-Event Review meeting held at Month 1 (2026-11-14) Week 1
- AAR-1 (72-Hour Response) and Exercise-1/2 reports completed and reviewed by Month 2 (2026-12-14)
- Signed MOUs with all states, Region 10, utilities and secondary hubs by Month 1 (2026-11-14) end
- All UC and advisory-body members, state commanders and federal partners confirmed for participation

### 39. FEMA Region VIII IC (UC chair) or designee publishes the final comprehensive After-Action Report (AAR-3: 72-Hour Response + Months 1–3 = 2026-11-14 to 2027-01-14 Hardening & Exercises) by the end of Month 3 (2027-01-14), consolidating lessons learned from: (1) the actual 72-hour response (T+0 to T+72h); (2) the Months 1–3 (2026-11-14 to 2027-01-14) MOU negotiations and governance formalization; (3) the three full-scale exercises (Exercise-1 Boundary, Exercise-2 Scenario Beta, Exercise-3 Integrated Response) and six smaller operational exercises. The report documents: (1) what the governance structure achieved during the 72-hour crisis (strengths and weaknesses); (2) what improvements have been made to governance, command protocols, communications, supply logistics and authority clarification during Months 1–3 (2026-11-14 to 2027-01-14); (3) what gaps or risks remain and recommendations for future planning cycles; (4) updated governance best practices and lessons learned to inform planning for future Yellowstone eruption events or similar multi-state volcanic evacuations. AAR-3 is published as an official FEMA and NPS document and distributed to all stakeholders and to the National Incident Management System (NIMS) community for use in national emergency management planning.

**Responsible Body/Role:** FEMA Region VIII IC (UC chair) or designee, with input from all UC members, advisory-body leads, state emergency managers, exercise after-action reports and responder feedback

**Suggested Timeframe:** End of Month 3 (2027-01-14)

**Key Outputs/Deliverables:**

- After-Action Report-3 (AAR-3: Comprehensive 72-Hour + Months 1–3 = 2026-11-14 to 2027-01-14 Report, 40–60 pages)
- Integrated lessons-learned summary (governance, command, communications, logistics, authority)
- Comparison of planned vs. actual outcomes across all phases (72-hour response, MOUs, exercises)
- Updated governance best practices and recommendations for future volcanic evacuation planning
- Appendices: AAR-1 (72-hour response), Exercise-1/2/3 and operational-exercise reports, signed MOUs, UC decision log, COP dashboard snapshots
- Public-release summary and distribution memo
- Briefing to FEMA Administrator, NPS Director and White House National Security Council

**Dependencies:**

- AAR-1 (72-Hour Response) published by Month 1 (2026-11-14)
- Signed MOUs with all parties by Month 1 (2026-11-14) end
- Exercise-1, Exercise-2 and Exercise-3 After-Action Reports completed by end of Month 3 (2027-01-14) Week 3
- All operational exercises (shift-rotation, water-convoy, grid-failure, multilingual alert, shelter relocation, re-entry) completed and documented by Month 3 (2027-01-14)