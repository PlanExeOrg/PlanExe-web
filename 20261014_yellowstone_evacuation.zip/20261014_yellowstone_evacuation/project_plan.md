**Goal Statement:** Evacuate about 35,800 people (35,000 tourists and 800 staff) from Yellowstone Zone Zero by T+6 hours and the 100 km Zone One by T+24 hours, then sustain regional life support under ashfall, with a pre-authorized 500 km Scenario Beta order and second-stage hub plan hardened by Month 3 (2027-01-14).

## SMART Criteria

- **Specific:** Clear Zone Zero (35,800 people) via three contraflow exits by T+6 hours, evacuate Zone One (West Yellowstone, Gardiner, Cody) by T+24 hours, and provide shelter, water, respiratory protection and command continuity under a Unified Command in Denver.
- **Measurable:** Gate G1 at T+6: at least 98% of 35,800 confirmed through exit counts. Gate G2 at T+24: at least 95% of registered Zone One residents out, perimeter staffed, Scenario Beta interim destination list issued. Water at shelters by T+24 (target).
- **Achievable:** Three exits, a Unified Command with Region 10 liaison, existing FEMA contract vehicles and Guard assets make this feasible. Pre-event lead times are not available, so readiness actions run at T+0 to T+12 hours and hardening in Months 1-3 (2026-11-14 to 2027-01-14).
- **Relevant:** Preserves life during a 72-hour window with a 40% chance of a VEI-6+ eruption (user constraint) and keeps regional infrastructure operating.
- **Time-bound:** Operational response from Month 0 (2026-10-14) (T+0) through T+72 hours; Zone Zero by T+6 h, Zone One by T+24 h. Scenario Beta plan, MOUs and exercises completed by Months 1-3 (2026-11-14 to 2027-01-14).

## Dependencies

- Unified Command activated at FEMA Region VIII RRCC Denver with Region 10 liaison and forward element at Livingston (alternate Bozeman)
- Governor authorization of Zone One and Scenario Beta orders from Montana, Wyoming and Idaho, then signed MOUs and EMAC arrangements by Month 1 (2026-11-14)
- Contraflow, tow/rockfall teams and Guard signal teams in place on US-191/US-20, US-89 and US-14/16/20
- Shelter sites selected at T+6 h from the NOAA/USGS plume forecast, with water, N95 and fuel convoys dispatched from Salt Lake City by T+12 h
- FAA grounding of ZLC and ZSE and a USGS trigger matrix for the Scenario Beta 500 km order

## Resources Required

- Contraflow traffic-control staff, signage, tow and rockfall-clearing equipment
- Guard signal teams, satellite phones, repeaters, HAR/VMS, IPAWS access
- 100,000 civilian N95 respirators, supplemental reserve, separate responder N95 stock
- About 1.43 million liters of bottled water (estimate) and tiered generator fuel
- Shelter facilities at Bozeman, Idaho Falls and a third site, buses, USD 200 million planning envelope (estimate)

## Related Goals

- Define Scenario Beta second-stage hubs outside the 500 km ring (Denver, Cheyenne candidates)
- Regional hospital surge and power resilience
- Post-event re-entry and recovery planning
- Multi-state MOUs, after-action report and full-scale exercises by Month 3 (2027-01-14)
- Public alerting and multilingual visitor notification

## Tags

- Yellowstone
- volcanic evacuation
- emergency management
- contraflow
- Scenario Beta

## Risk Assessment and Mitigation Strategies


### Key Risks

- Single-point blockage in Gallatin Canyon or near Gardiner halts a primary corridor
- Ash and tremor collapse cell networks, leaving drivers and responders without route guidance
- Authority gaps at the NPS-to-state handoff and Region 8/10 seam delay reroutes
- Scenario Beta (millions of people, not quantified) exceeds shelter, road and supply capacity with no second-stage destinations
- Water convoys arrive T+18 to T+30 h (estimate), later than the T+12 h dispatch target

### Diverse Risks

- Responder fatigue: 100-150 rangers (estimate) leave no relief depth in the T+2 to T+8 peak
- Ash footprint forecast error places shelters in heavy ash, forcing relocation
- Procurement delays of 24-48 h (estimate) without pre-awarded contracts
- Hospital and grid power loss from ash flashovers before fuel arrives
- Conflicting shelter-in-place and evacuation messages reduce compliance and corridor throughput

### Mitigation Plans

- Pre-place at least 2 tow/rockfall teams to reach blockages within 15 min; divert overflow after 45 min (proposed threshold); loss-of-exit rule after 6 h
- Deploy Guard signal teams, HAR/VMS and printed route cards in English plus 5 languages from T+0
- Boundary Coordination Officer at forward element, pre-authorized state reroutes, Region 10 liaison seated at T+0
- Interim ranked hub list outside the ring by T+12 h, tiered ring execution, written plan by Month 1 (2026-11-14), MOUs by Month 2 (2026-12-14), exercise by Month 3 (2027-01-14)
- Forward depots, reserved convoy lane, FEMA contract vehicles with 12 h dispatch clauses; 6 h shift limits, 30-50 standby reserve, PM10 sensors and 4 h relocation rule

## Stakeholder Analysis


### Primary Stakeholders

- Unified Command (FEMA Region VIII RRCC, Region 10 liaison)
- NPS Incident Commander and LE Rangers
- State governors, highway patrol and National Guard (MT, WY, ID)
- USGS volcanologists and NOAA forecasters
- Hospitals and shelter operators in Bozeman, Livingston and Idaho Falls

### Secondary Stakeholders

- Visitors and Zone One residents
- Concessioners (e.g. Xanterra)
- Utilities and water districts
- FAA and aviation operators
- Host communities for second-stage hubs

### Engagement Strategies

- Hourly UC briefings and a shared common operating picture for primary stakeholders
- Governor verbal pre-authorization by T+6 h, signed MOUs by Month 1 (2026-11-14)
- IPAWS/WEA, HAR and multilingual messages with published USGS trigger logic to protect credibility
- Concessioner manifests and buses for lodge and mobility-limited visitors
- Milestone updates to utilities, FAA and host hubs; after-action reports in Months 1-3 (2026-11-14 to 2027-01-14)

## Regulatory and Compliance Requirements


### Permits and Licenses

- Presidential emergency declaration under the Stafford Act
- Governor emergency declarations and EMAC mutual-aid activation
- FAA airspace restriction orders for ZLC and ZSE
- State temporary traffic-control and contraflow authorizations
- Emergency contract activation under existing FEMA contract vehicles

### Compliance Standards

- National Incident Management System and Incident Command System
- Stafford Act cost documentation and reimbursement rules
- Worker respiratory protection and exposure standards (OSHA)
- Emergency transportation and hazardous-materials fuel handling rules
- Accessibility and language-access requirements for emergency alerts

### Regulatory Bodies

- FEMA Regions VIII and 10
- National Park Service
- FAA
- USGS and NOAA
- State emergency management agencies (MT, WY, ID)

### Compliance Actions

- Seat Unified Command and Region 10 liaison at T+0
- Obtain verbal governor authorization by T+6 h; sign MOUs and EMAC by Month 1 (2026-11-14)
- Request FAA grounding and rotary-wing medevac exceptions at T+0
- Apply responder exposure limits (6 h shift, 18 h withdrawal) and track N95 use
- Complete after-action report and exercises by Month 3 (2027-01-14)