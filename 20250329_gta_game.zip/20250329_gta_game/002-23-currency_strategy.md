This plan involves money.

## Currencies

- **USD:** Primary location in Los Angeles, California.
- **CAD:** Secondary location in Montreal, Quebec.
- **GBP:** Tertiary location in London, UK.

**Primary currency:** USD

**Currency strategy:** USD will be used for consolidated budgeting and reporting. CAD and GBP may be used for local transactions in Montreal and London, respectively. Hedging against exchange rate fluctuations between USD, CAD, and GBP should be considered.