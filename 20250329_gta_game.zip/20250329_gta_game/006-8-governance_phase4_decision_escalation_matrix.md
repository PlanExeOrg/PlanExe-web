**Budget Request Exceeding Core Project Team Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the Core Project Team's approved financial limit of $1 million USD, requiring strategic oversight.
Negative Consequences: Potential budget overrun and misalignment with strategic financial goals.

**Critical Technical Risk Materialization**
Escalation Level: CTO
Approval Process: CTO Review and Recommendation
Rationale: Technical Advisory Group cannot resolve a critical technical risk, requiring executive-level intervention and resource allocation.
Negative Consequences: Significant project delays, technical debt, and potential project failure.

**Ethics & Compliance Committee Deadlock on Content Moderation**
Escalation Level: CEO
Approval Process: CEO Review and Final Decision
Rationale: The Ethics & Compliance Committee is unable to reach a consensus on a content moderation issue with potential legal or reputational ramifications.
Negative Consequences: Legal penalties, reputational damage, and potential boycotts.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: A significant change to the project scope is proposed, requiring strategic alignment and budget reallocation.
Negative Consequences: Project delays, budget overruns, and misalignment with strategic objectives.

**Reported Ethical Violation by Senior Team Member**
Escalation Level: Board of Directors
Approval Process: Ethics Committee Investigation & Recommendation to the Board
Rationale: An ethical violation involving a senior team member requires independent review and potential disciplinary action.
Negative Consequences: Legal penalties, reputational damage, and loss of investor confidence.

**Stakeholder Engagement Group Unable to Resolve Major Community Concern**
Escalation Level: Head of Marketing
Approval Process: Head of Marketing Review and Action Plan
Rationale: The Stakeholder Engagement Group cannot address a significant community concern, requiring executive-level intervention and communication strategy.
Negative Consequences: Negative publicity, loss of player trust, and reduced sales.