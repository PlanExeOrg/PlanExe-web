This plan involves money.

## Currencies

- **USD:** Primary currency for budgeting and reporting, as explicitly stated in the project description.
- **VEF:** Potentially needed for local transactions within Venezuela, although USD is preferred due to currency instability.
- **COP:** Potentially needed for operations in Colombia.

**Primary currency:** USD

**Currency strategy:** USD is recommended for budgeting and reporting to mitigate risks from hyperinflation in Venezuela. Local currencies (VEF, COP) may be used for local transactions. Hedging strategies may be necessary to manage exchange rate fluctuations.