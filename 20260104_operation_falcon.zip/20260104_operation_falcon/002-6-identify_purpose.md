**Purpose:** business

**Purpose Detailed:** Governmental initiative involving military and intelligence operations with the objective of capturing a foreign leader and gaining access to resources.

**Topic:** Surveillance and potential capture of Venezuelan President Nicolás Maduro