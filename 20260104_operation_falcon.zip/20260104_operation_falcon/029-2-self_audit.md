Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 19 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 0 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The goal is to capture a foreign head of state, which does not violate physics.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (capture), market (Venezuela), tech/process (military intervention), and policy (bypassing ethics boards) without independent evidence at comparable scale. There is no precedent for this specific combination.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: Project Manager / Deliverable: Validation Report / Date: 2026-01-31


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan omits definitions for strategic concepts like 'Operational Footprint Strategy', 'Risk Tolerance Threshold', and 'Intelligence Collection Strategy'. Without these, the plan lacks a clear mechanism-of-action. The plan states, "A potential missing strategic dimension is a legal strategy."

**Mitigation**: Strategy Team: Produce one-pagers defining each strategic concept with inputs→process→customer value, owners, measurable outcomes, and decision hooks. Due: 2026-02-07.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because a major hazard class (legal) is absent or minimized. The plan states, "A potential missing strategic dimension is a legal strategy to justify the intervention." The plan does not analyze cascades explicitly.

**Mitigation**: Legal Team: Expand the risk register to include legal risks, map legal risk cascades, add controls, and schedule a review cadence by 2026-02-15.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a permit/approval matrix and authoritative permit lead times. The plan does not include a timeline with dated predecessors. Therefore, it is impossible to assess timeline realism. 

**Mitigation**: Project Manager: Create a permit/approval matrix with authoritative lead times and dated predecessors by 2026-02-15. Include a NO-GO threshold on slip.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because committed sources/term sheets are not mentioned. The plan states a $500M budget, but does not name the funding source, draw schedule, covenants, or runway length. The plan does not mention any financing gates.

**Mitigation**: CFO: Create a dated financing plan listing sources/status, draw schedule, covenants, and a NO‑GO on missed financing gates by 2026-02-15.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget of $500M conflicts with the scale of the operation (capture of a head of state, military intervention) without normalization. There are no benchmarks or vendor quotes. The plan omits contingency.

**Mitigation**: Finance Team: Obtain ≥3 relevant cost benchmarks for comparable operations, normalize per-area (e.g., cost per sq ft of operational footprint), and adjust budget or de-scope by 2026-03-01.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., 30% better data, 15% higher risk of detection, 40% quicker intel) as single numbers without ranges or scenarios. This indicates optimism and a lack of contingency planning.

**Mitigation**: Analysis Team: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the most critical projection (e.g., intel gathering speed) by 2026-02-15.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because build‑critical components lack engineering artifacts. The plan mentions surveillance equipment, secure communication networks, and naval vessels, but lacks technical specifications, interface definitions, test plans, and integration maps.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components by 2026-03-01.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes critical claims without verifiable artifacts. For example, the plan states, "The Resource Allocation Strategy determines how the $500 million budget is distributed..." but lacks evidence of budget allocation.

**Mitigation**: CFO: Provide a detailed budget allocation document with specific line items and justifications, including links to supporting documentation, by 2026-02-15.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the "Operational Footprint Strategy" is abstract. The plan states, "The Operational Footprint Strategy defines the physical presence and visibility of US forces within Venezuela" without specific, verifiable qualities.

**Mitigation**: Project Manager: Define SMART criteria for the Operational Footprint Strategy, including a KPI for the number of personnel deployed (e.g., ≤50 US personnel) by 2026-02-15.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'access to Venezuelan oil' as a goal, which does not directly support the core project goal of capturing Maduro. The core project goals are capturing Nicolás Maduro and gathering intelligence.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of 'access to Venezuelan oil' as a project goal, complete with a KPI, owner, and estimated cost, or else move the feature to the project backlog. Due: 2026-02-15.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a 'Security and Counterintelligence Specialist' to protect sensitive information and personnel. This role is critical given the high-risk nature of the operation and the potential for leaks.

**Mitigation**: HR: Conduct a talent market analysis for Security and Counterintelligence Specialists with relevant experience and security clearances by 2026-02-15.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a regulatory matrix mapping authorities, artifacts, lead times, and predecessors. The plan mentions "International Law" and "US National Security Regulations" but does not map them to specific actions.

**Mitigation**: Legal Team: Create a regulatory matrix mapping authorities, artifacts, lead times, and predecessors, including a NO-GO on adverse findings, by 2026-03-01.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a funding/resource strategy, maintenance schedule, succession planning, technology roadmap, or adaptation mechanisms. The plan does not address long-term operational costs exceeding sustainable funding or technology obsolescence.

**Mitigation**: Project Manager: Develop an operational sustainability plan including funding strategy, maintenance schedule, succession plan, technology roadmap, and adaptation mechanisms by 2026-03-01.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks evidence of zoning/land-use compliance, occupancy/egress adherence, fire load management, structural limit adherence, noise mitigation, or permit acquisition. The plan requires physical locations but does not address these constraints.

**Mitigation**: Facilities Team: Perform a fatal-flaw screen with authorities/experts, seek written confirmation where feasible, and define fallback designs/sites with dated NO-GO thresholds by 2026-03-01.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks evidence of tested failovers or secondary suppliers. The plan mentions "secure communication networks" but does not describe redundancy or tested failover plans. The plan mentions "regional allies" but does not describe SLAs.

**Mitigation**: Engineering Team: Secure SLAs with vendors, add a secondary supplier/path for critical services, and test failover by 2026-03-01.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Army' is incentivized by mission success (capturing Maduro), while the 'Legal Team' is incentivized by minimizing legal and ethical risks, creating a conflict over acceptable tactics.

**Mitigation**: Project Director: Establish a shared OKR between the Army and Legal Team focused on 'compliant mission success' by 2026-02-15.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board with decision thresholds (when to re-plan/stop) by 2026-02-15.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a cross-impact analysis, bow-tie diagram, or FTA to surface multi-node cascades and common-mode failures. The plan states, "A potential missing strategic dimension is a legal strategy to justify the intervention."

**Mitigation**: Risk Team: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by 2026-03-01.