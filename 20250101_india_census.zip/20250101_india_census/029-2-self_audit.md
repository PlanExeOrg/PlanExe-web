Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 17 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 2 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The project focuses on data collection and analysis, which are not physics-dependent in the way the prompt describes.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan combines a digital census with caste enumeration at an unprecedented scale, lacking independent evidence of success. The plan states, "The plan carries significant risks due to its scale, the sensitivity of caste data, and the reliance on technology..."

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: Project Manager / Deliverable: Validation Report / Date: 2025-Q2


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions buzzwords like "Builder's Foundation" without defining a clear mechanism-of-action or measurable outcomes. The plan states, "The plan is extremely ambitious in scale, aiming to enumerate over 1.4 billion people..."

**Mitigation**: Project Lead: Create one-pagers for each strategic concept, defining inputs, processes, customer value, owners, measurable outcomes, and decision hooks. Date: Within 60 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the risk register focuses on direct risks (regulatory delays, app glitches, budget overruns) but lacks analysis of second-order effects or risk cascades. There is no evidence of mapping cascades.

**Mitigation**: Risk Manager: Expand the risk register to include second-order risks and map potential risk cascades, adding controls and a dated review cadence. Due Date: Within 90 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a permit/approval matrix. The plan mentions "Regulatory and Permitting delays" as a risk, but does not include a comprehensive list of required permits, their lead times, or their dependencies.

**Mitigation**: Project Manager: Create a permit/approval matrix with required permits, lead times, dependencies, and NO-GO thresholds on slip. Due Date: Within 60 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not include a dated financing plan listing sources/status, draw schedule, covenants, and a NO‑GO on missed financing gates. The plan mentions "Secure Funding and Resources" but lacks specifics.

**Mitigation**: CFO: Create a dated financing plan listing sources/status, draw schedule, covenants, and a NO‑GO on missed financing gates. Due Date: Within 30 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks scale-appropriate benchmarks or vendor quotes to substantiate the budget. There is no per-area cost normalization. The plan mentions "Detailed Budget Breakdown Creation" but provides no figures.

**Mitigation**: CFO: Benchmark (≥3), obtain quotes, normalize per-area (m²/ft²), and adjust budget or de-scope by a set date. Due Date: Within 90 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., household enumeration rate) as single numbers without providing a range or discussing alternative scenarios. For example, "Achieve 99%+ household enumeration rate by April 1, 2027..."

**Mitigation**: Project Manager: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the household enumeration rate projection. Due Date: Within 60 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks engineering artifacts for build-critical components. There are no technical specifications for the smartphone app, data storage, or security protocols. The plan mentions "Define App Requirements and Specifications" but lacks details.

**Mitigation**: Engineering Lead: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for the smartphone app and data storage. Due Date: Within 90 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes critical claims without verifiable artifacts. For example, it states, "The census is achievable with the allocated budget..." but provides no budget document or financial model to support this claim.

**Mitigation**: CFO: Produce a detailed budget document with a financial model, including assumptions, sources, and uses of funds, by a set date. Due Date: Within 30 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "a new system" (the census) without specific, verifiable qualities. The goal is to "execute India's decennial population census, covering over 1.4 billion people...by April 1, 2027."

**Mitigation**: Project Manager: Define SMART criteria for census completion, including a KPI for enumeration rate (e.g., 99% of households enumerated) by a set date. Due Date: Within 30 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'Caste Category Aggregation' as a decision, which adds complexity and political risk without clear support for the core goal of basic enumeration. The plan states, "The Core Decision: Caste Data Handling governs the collection..."

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of 'Caste Category Aggregation', complete with a KPI, owner, and estimated cost, or move the feature to the project backlog. Date: Within 30 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires 3 million enumerators, a novel role at this scale, and the plan lacks evidence that this workforce can be readily assembled and trained. The plan states, "Deploying 3 million government workers across India."

**Mitigation**: HR Lead: Conduct a talent market analysis for enumerators, assessing availability, skills, and training capacity, and report on feasibility by a set date. Due Date: Within 60 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a regulatory matrix mapping required approvals, lead times, and responsible parties. The plan mentions "Regulatory and Permitting delays" as a risk, but lacks specifics.

**Mitigation**: Legal Team: Create a regulatory matrix (authority, artifact, lead time, predecessors), conduct a Fatal-Flaw Analysis, and report NO-GO findings. Due Date: Within 90 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions a "long-term plan for technology" but lacks details on funding, maintenance, and obsolescence. The plan states, "Lack of long-term plan for technology. Impact: Difficulty in future censuses."

**Mitigation**: Technology Lead: Develop an operational sustainability plan including a funding/resource strategy, maintenance schedule, technology roadmap, and adaptation mechanisms. Due Date: Within 90 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not address zoning, occupancy, fire load, structural limits, or noise constraints. The plan focuses on data collection and technology deployment, but omits any discussion of physical infrastructure requirements or compliance.

**Mitigation**: Facilities Team: Perform a fatal-flaw screen with authorities/experts regarding zoning, occupancy, fire load, structural limits, and noise. Define fallback designs/sites and NO-GO thresholds. Due Date: Within 90 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "Satellite internet access" and "Connectivity Contingency Planning" but lacks details on SLAs, failover testing, or secondary suppliers. The plan states, "Establish mobile support teams equipped with satellite internet access..."

**Mitigation**: IT Team: Secure SLAs with vendors, add a secondary supplier/path for satellite internet, and test failover by a set date. Due Date: Within 90 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Enumerator Performance Incentives' goal (completion rates) of the Field Operations Director conflicts with the 'Data Quality Assurance Protocols' goal (data accuracy) of the Data Quality & Integrity Manager. The plan states, "Incentivizing enumerators can boost completion rates and data accuracy..."

**Mitigation**: Project Management: Create a shared OKR (Objective and Key Results) that aligns both stakeholders on a common outcome, such as 'Improve data quality while maintaining high enumeration coverage'. Due Date: Within 30 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board with decision thresholds (when to re-plan/stop). Due Date: Within 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan has ≥3 High risks (Political Interference, Data Quality & Fraud, Technical Failures) that are strongly coupled. Political interference can undermine data quality, and technical failures can exacerbate both. There is no cross-impact analysis.

**Mitigation**: Risk Team: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Due Date: Within 90 days.