This plan involves money.

## Currencies

- **INR:** Indian Rupee, the local currency for all operations within India.
- **USD:** United States Dollar, for budgeting and reporting to international bodies, and for managing potential currency fluctuations.

**Primary currency:** USD

**Currency strategy:** USD is recommended for budgeting and reporting to mitigate risks from currency fluctuations. INR will be used for local transactions. Hedging strategies may be considered to manage exchange rate risks.