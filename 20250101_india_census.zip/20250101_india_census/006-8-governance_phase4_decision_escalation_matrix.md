**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds financial limit of PMO's delegated authority (above ₹50 crore).
Negative Consequences: Potential budget overrun and project delays if not approved.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: Strategic impact on project objectives and requires high-level decision-making.
Negative Consequences: Project failure or significant delays if risk is not addressed effectively.

**PMO Deadlock on Vendor Selection**
Escalation Level: Registrar General and Census Commissioner
Approval Process: Registrar General's Decision based on PMO recommendations and justifications
Rationale: Requires higher authority to resolve disagreements and ensure timely procurement.
Negative Consequences: Procurement delays and potential impact on project timeline.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval based on impact assessment
Rationale: Significant impact on project objectives, budget, and timeline.
Negative Consequences: Project scope creep and potential project failure if not properly managed.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Steering Committee
Rationale: Needs independent review and assessment to ensure ethical conduct and compliance.
Negative Consequences: Legal penalties, reputational damage, and loss of public trust if not addressed.

**Technical Design Change impacting Data Security**
Escalation Level: Technical Advisory Group
Approval Process: Technical Advisory Group Review and Approval based on security impact assessment
Rationale: Requires expert technical review to ensure data security and privacy are maintained.
Negative Consequences: Data breach, loss of public trust, and legal penalties if security is compromised.