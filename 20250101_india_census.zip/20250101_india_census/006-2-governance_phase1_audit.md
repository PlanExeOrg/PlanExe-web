
## Audit - Corruption Risks

- Bribery of local officials to expedite permits or gain access to restricted areas, potentially compromising data collection in those areas.
- Nepotism or favoritism in the selection of enumerators, leading to unqualified personnel and compromised data quality.
- Conflicts of interest involving census officials with financial ties to technology vendors or suppliers, influencing procurement decisions.
- Kickbacks from technology vendors in exchange for favorable contract terms or inflated pricing, resulting in budget overruns and potentially substandard equipment.
- Misuse of confidential census data for political gain or personal enrichment, such as leaking caste data to influence elections or target specific communities.
- Trading favors with influential community leaders to ensure cooperation, potentially leading to biased enumeration in those communities.

## Audit - Misallocation Risks

- Budget misuse for personal gain by census officials, such as inflating travel expenses or diverting funds to personal accounts.
- Double spending on technology procurement, such as ordering duplicate smartphones or paying for unnecessary software licenses.
- Inefficient allocation of resources, such as overspending on training in some regions while neglecting others, leading to uneven data quality.
- Unauthorized use of census assets, such as using government vehicles for personal travel or diverting smartphones for non-census purposes.
- Poor record keeping of expenses, making it difficult to track spending and identify potential fraud or waste.
- Misreporting progress or results to secure continued funding or political support, potentially masking enumeration gaps or data quality issues.

## Audit - Procedures

- Periodic internal reviews of procurement processes, focusing on technology contracts and vendor selection, conducted quarterly by an internal audit team.
- Post-project external audit of all financial transactions, including expense reports and vendor payments, conducted by an independent auditing firm within 6 months of project completion.
- Contract review thresholds for technology procurement, requiring independent legal review for contracts exceeding ₽5 crore, to ensure compliance and prevent conflicts of interest.
- Expense workflows for enumerator reimbursements, requiring supervisor approval and supporting documentation for all claims, with random audits of expense reports.
- Compliance checks on data handling procedures, ensuring adherence to data privacy laws and ethical guidelines, conducted annually by an independent ethics review board.
- Regular audits of data entry and validation processes to identify and correct errors, conducted monthly by a data quality assurance team.

## Audit - Transparency Measures

- Progress/budget dashboards displaying key milestones, budget expenditures, and enumeration rates, updated weekly and accessible to the public.
- Published minutes of the multi-party parliamentary oversight committee meetings, detailing discussions on methodology, data collection, and data release, published monthly.
- Whistleblower mechanisms for reporting suspected fraud or corruption, with guaranteed anonymity and protection from retaliation, managed by an independent ombudsman.
- Public access to relevant policies and reports, including the census methodology, data quality assurance protocols, and risk assessment reports, published on the census website.
- Documented selection criteria for major decisions and vendors, including technology providers and training partners, published on the census website.
- Regular press briefings to proactively address public concerns and counter misinformation campaigns, conducted by the Registrar General and Census Commissioner.