### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** The scale, critical national importance (delimitation/reservations), budget size (up to ₹15,000 Cr), and high political sensitivity necessitate a senior body for strategic direction, political risk management, and high-level resource authorization, distinct from operational execution.

**Responsibilities:**

- Approve major funding releases (e.g., major hardware procurement tranches, contingency use > ₹500 Cr).
- Resolve inter-ministerial conflicts regarding data access or state cooperation (especially concerns related to Decision 4 and Decision 6).
- Provide strategic direction on the sequencing of data releases (Population vs. Caste data) to manage political timelines.
- Receive and approve recommendations for major strategic lever changes (as per 'Pioneer's Gambit' decisions).
- Provide final endorsement for methodological acceptance criteria reviewed by the Advisory Board.

**Initial Setup Actions:**

- Finalize and ratify the Project Charter and Terms of Reference (ToR).
- Establish the threshold for financial decisions requiring PSC review (set at ₹500 Crore).
- Appoint Chairperson and establish voting/conflict resolution protocol.

**Membership:**

- Secretary, Ministry of Home Affairs (Chair)
- Registrar General and Census Commissioner (Executive Lead)
- Senior Representative, Election Commission of India (Primary Data Consumer)
- Chief Financial Officer/Budget Head, Ministry of Finance
- Designated Independent Governance Advisor (External/Non-Governmental)

**Decision Rights:** Approves strategic shifts, budget tolerance adjustments, final data release strategy (Decision 4), and escalation resolutions from the Operational Management Board.

**Decision Mechanism:** Majority vote (5 out of 6 members). Tie broken by the Chairperson's casting vote, unless the issue involves direct financial liability exceeding ₹1,000 Cr, in which case it is escalated immediately to the Cabinet Secretary.

**Meeting Cadence:** Monthly during preparatory phases (Q1 2025 - Q1 2026); Bi-monthly during active enumeration (Phase 1 & 2); Quarterly post-census archive/reporting.

**Typical Agenda Items:**

- Review of adherence to data release sequencing milestones (Decision 4).
- High-level political friction reports from Federal Liaisons (Decision 6).
- Approval of Contingency Fund utilization (Risk 7 mitigation).
- Review of methodology lock-in fidelity (Assumption Issue 1 status).

**Escalation Path:** Issues requiring national policy mandates or budget breaches > ₹1,000 Cr are escalated directly to the Cabinet Secretary/Union Cabinet for final directive.
### 2. Core Project Management & Operations Board (CPMOB)

**Rationale for Inclusion:** Given the massive logistical complexity (3M personnel, mobile technology), centralized daily operational oversight is essential to manage performance incentives, supply chain, and technical troubleshooting, separating these detailed controls from strategic oversight.

**Responsibilities:**

- Oversee day-to-day execution of Phase 1 and Phase 2 timelines.
- Manage hardware lifecycle (Decision 7) and software deployment/updates (Decision 8).
- Execute the Enumerator Performance Calibration system (Decision 5), including authorizing performance payouts based on validation results.
- Manage the Real-Time Data Monitoring System (Decision 9), ensuring anomaly detection triggers timely field remediation and supervisor response.
- Coordinate the deployment and operation of satellite communication hubs (Decision 1).

**Initial Setup Actions:**

- Establish the central Digital Operations Center (DOC) structure.
- Finalize the specific financial/validation thresholds for performance bonuses (Decision 5).
- Develop the immediate response protocol for major hardware/app failures (Risk 1, Risk 5).

**Membership:**

- Chief Census Officer / Project Director (Chair)
- Head of IT & Digital Infrastructure
- Logistics and Field Operations Manager (Responsible for 3M personnel deployment)
- Data Quality Assurance Lead
- Head of Training and Capacity Building

**Decision Rights:** All operational decisions, including subcontractor management, training module updates, performance bonus sign-off (below PSC threshold), and field procedural adjustments (non-methodological). Decisions affecting budget tracking under ₹500 Cr.

**Decision Mechanism:** Consensus required. If consensus fails on operational conflicts, the Project Director's decision stands, subject to immediate review by the PSC for high-consequence actions.

**Meeting Cadence:** Daily during Phase 1 & 2 (Stand-up/Briefing); Weekly for governance review.

**Typical Agenda Items:**

- Synchronization Backlog Status (MTTR check, Assumption Issue 3).
- Review of performance validation rejection rates (Risk 3).
- Review of device failure rates and replacement rates (Risk 5).
- Field feedback loop analysis for Dynamic Training Modules (Decision 8).

**Escalation Path:** Disputes over significant data methodological deviations (Decision 2), major budgetary shifts, or state-level political deadlock are escalated immediately to the Project Steering Committee.
### 3. Data Integrity and Compliance Assurance Group (DICAG)

**Rationale for Inclusion:** The dual sensitivity of the census (political delimitation data AND comprehensive caste data) requires an independent body dedicated solely to ensuring methodological rigor, ethical compliance (GDPR/Privacy not explicitly mentioned but assumed standards apply to personal data), and preventing data fabrication/misallocation (Risks 2, 3). This group provides crucial assurance independently of the operational team.

**Responsibilities:**

- Conduct mandatory methodology compliance reviews, particularly on the two-stage caste collection (Decision 2 and Assumption Issue 1).
- Oversee the independent verification surveys and paper audit reconciliation (Decision 1).
- Serve as the primary review body for the Real-Time Data Monitoring System (Decision 9) outputs.
- Ensure secure data handling, archival protocols, and disposal/decommissioning compliance (Assumption Issue 2).
- Review all regional procedural variances granted under Decision 6 for statistical objectivity.

**Initial Setup Actions:**

- Establish audit sampling frames, including independent verification protocols.
- Formally adopt the ratified 'Gold Standard' caste methodology documentation (Assumption Issue 1) as the compliance baseline.
- Define acceptable variance thresholds for GPS/time stamps in the collected data.

**Membership:**

- Chief Statistical Officer (Internal Chair)
- External Statistical Auditor/Methodologist (Independent Member)
- Chief Technical Auditor/Security Specialist
- Lead Legal Counsel (for compliance/privacy oversight)
- Representative from the Registrar General’s Quality Unit

**Decision Rights:** Authority to issue formal findings ('Compliance Flags') to the CPMOB requiring mandatory remedial action concerning data quality, methodology deviation, or asset disposal (Trustee for data credibility). Cannot halt operations, but findings require PSC review if remediation costs exceed a defined threshold.

**Decision Mechanism:** Consensus among the External Auditor, Legal Counsel, and Chair is required for issuing a 'Critical Compliance Flag.' Decisions based on majority vote for minor procedural findings.

**Meeting Cadence:** Bi-weekly during data collection/synchronization peaks; Monthly post-census for archival assurance.

**Typical Agenda Items:**

- Review of anomaly clustering patterns flagged by RTM system.
- Audit Findings: Paper vs. Digital reconciliation rates (Decision 1 effectiveness).
- Assessment of caste methodology adherence in complex regions (Decision 2).
- Review of data asset decommissioning plan status (Assumption Issue 2).

**Escalation Path:** Critical Compliance Flags that the CPMOB fails to address within 14 days, or findings indicating systemic political interference (Risk 2), are escalated directly to the Project Steering Committee and, if necessary, the Judicial Review Board (Decision 4).