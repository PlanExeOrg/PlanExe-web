### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1

**Dependencies:**

- Project Plan Approved

### 3. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**

- Project Plan Approved

### 4. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.1

**Dependencies:**

- Project Plan Approved

### 5. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SEG ToR v0.1

**Dependencies:**

- Project Plan Approved

### 6. Circulate Draft SteerCo ToR for review by nominated members (Secretary, Ministry of Home Affairs; Registrar General and Census Commissioner; Chief Statistician of India; Secretary, Ministry of Electronics and Information Technology; Representative from NITI Aayog; Two independent experts).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on SteerCo ToR

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 7. Circulate Draft PMO ToR for review by Registrar General and Census Commissioner.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on PMO ToR

**Dependencies:**

- Draft PMO ToR v0.1

### 8. Circulate Draft TAG ToR for review by Chief Technology Officer, Ministry of Electronics and Information Technology.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on TAG ToR

**Dependencies:**

- Draft TAG ToR v0.1

### 9. Circulate Draft ECC ToR for review by Legal Counsel.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on ECC ToR

**Dependencies:**

- Draft ECC ToR v0.1

### 10. Circulate Draft SEG ToR for review by Communications Manager.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on SEG ToR

**Dependencies:**

- Draft SEG ToR v0.1

### 11. Project Manager finalizes the Project Steering Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary on SteerCo ToR

### 12. Project Manager finalizes the Project Management Office (PMO) Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final PMO ToR v1.0

**Dependencies:**

- Feedback Summary on PMO ToR

### 13. Project Manager finalizes the Technical Advisory Group Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final TAG ToR v1.0

**Dependencies:**

- Feedback Summary on TAG ToR

### 14. Project Manager finalizes the Ethics & Compliance Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final ECC ToR v1.0

**Dependencies:**

- Feedback Summary on ECC ToR

### 15. Project Manager finalizes the Stakeholder Engagement Group Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SEG ToR v1.0

**Dependencies:**

- Feedback Summary on SEG ToR

### 16. Senior Sponsor (Secretary, Ministry of Home Affairs) formally appoints the Chair of the Project Steering Committee.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 17. Project Steering Committee Chair, in consultation with the Registrar General and Census Commissioner, confirms the remaining members of the Project Steering Committee.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Confirmed SteerCo Membership List

**Dependencies:**

- Appointment Confirmation Email
- Final SteerCo ToR v1.0

### 18. Registrar General and Census Commissioner appoints the Director, Census Operations as the PMO Head.

**Responsible Body/Role:** Registrar General and Census Commissioner

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final PMO ToR v1.0

### 19. Chief Technology Officer, Ministry of Electronics and Information Technology, confirms the remaining members of the Technical Advisory Group.

**Responsible Body/Role:** Chief Technology Officer, Ministry of Electronics and Information Technology

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Confirmed TAG Membership List

**Dependencies:**

- Final TAG ToR v1.0

### 20. Legal Counsel identifies and recruits a Retired Judge to serve as the Chair of the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Chair Identified for Ethics & Compliance Committee

**Dependencies:**

- Final ECC ToR v1.0

### 21. Retired Judge (Chair), in consultation with Legal Counsel, confirms the remaining members of the Ethics & Compliance Committee.

**Responsible Body/Role:** Retired Judge

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Confirmed ECC Membership List

**Dependencies:**

- Chair Identified for Ethics & Compliance Committee
- Final ECC ToR v1.0

### 22. Communications Manager identifies and confirms representatives from each state government, major caste organizations, and local community groups to form the Stakeholder Engagement Group.

**Responsible Body/Role:** Communications Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Confirmed SEG Membership List

**Dependencies:**

- Final SEG ToR v1.0

### 23. Hold initial Project Steering Committee Kick-off Meeting.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Confirmed SteerCo Membership List
- Final SteerCo ToR v1.0

### 24. Hold initial Project Management Office (PMO) Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Email
- Final PMO ToR v1.0

### 25. Hold initial Technical Advisory Group Kick-off Meeting.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Confirmed TAG Membership List
- Final TAG ToR v1.0

### 26. Hold initial Ethics & Compliance Committee Kick-off Meeting.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Confirmed ECC Membership List
- Final ECC ToR v1.0

### 27. Hold initial Stakeholder Engagement Group Kick-off Meeting.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Confirmed SEG Membership List
- Final SEG ToR v1.0