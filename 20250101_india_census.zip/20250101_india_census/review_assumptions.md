## Domain of the expert reviewer
Mega-Scale National Project Management & Governance Risk

## Domain-specific considerations

- Political Credibility and Data Sequencing
- Logistical Resilience in Heterogeneous Infrastructure
- Management of 3 Million Personnel Incentives and Quality
- Handling Highly Sensitive Sociological Data (Caste)

## Issue 1 - Missing Assumption: Finalization of Caste Methodology Before Technology Deployment
The 'Pioneer's Gambit' selects a two-stage caste data collection (provisional/review), but there is no stated assumption that the *final, acceptable* questionnaire design, linkage rules, and acceptable political review criteria are finalized before enumerators are trained and devices are mass-deployed. The complexity (Decision 2) suggests modifications might occur late. Training 3 million people on a moving target methodology is disastrous.

**Recommendation:** Assume and mandate that a 'Gold Standard' data dictionary, linkage logic (between provisional/final caste data), and statistical acceptance thresholds must be signed off by the Election Commission and relevant ministries by Q4 2025, *before* mass device deployment. This moves the methodological design lock-in milestone ahead of the physical logistics timeline.

**Sensitivity:** If the caste data collection methodology shifts by more than 15% (e.g., changing definition of OBC categories) after enumerator training baseline: The cost of reprinting training manuals and conducting emergency refresher training for 3 million personnel could exceed ₹50–100 crore. Furthermore, if the methodology shift invalidates earlier field data capture efforts, the quality validation success criterion (tied to 50% of pay) might see initial error rates spike from a baseline of 5% to 15-20%, delaying payouts and potentially reducing ROI by 3-5% due to distrust.

## Issue 2 - Missing Assumption: Sustainability and Disposal of 3 Million Digital Assets Post-Census
The assumptions heavily focus on procurement (leased/purchased, Decision 7) and field reliability, but entirely omit the multi-year post-census operational and financial liabilities related to the 3 million devices, data servers, and mandated data retention/destruction protocols. This impacts long-term project cost visibility and environmental/data security compliance.

**Recommendation:** Assume a dedicated 'Decommissioning and Asset Management Fund' (DAMF) equivalent to 8% of the initial hardware expenditure (estimated at 40% of the total budget based on Q1 assumption) is ring-fenced during Q1 2026. This fund must cover secure data erasure, physical asset disposition (recycling/selling leased assets), and long-term archival storage migration for mandatory retention periods (e.g., 10 years).

**Sensitivity:** Failure to plan for asset disposal (baseline cost estimate ignored): If devices are purchased outright (not leased), disposal costs or residual value realization could vary widely. If 30% of devices require secure destruction instead of resale due to data sensitivity, the cost overrun for asset management could be ₹200–400 crore above baseline projections, reducing overall project ROI by 1.5-3%.

## Issue 3 - Under-Explored Assumption: Scalability and Stability of Cloud Infrastructure Under Peak Asynchronous Load
Assumption 8 posits distributed edge servers for batch processing. However, 'high/very high' risk factors (data security, political friction) mean data upload synchronization will be highly erratic—massive spikes when a region resolves a political issue, followed by lulls. The assumption does not quantify the required ingestion burst capacity or the Mean Time to Recovery (MTTR) for the core ingestion pipeline. A failure here stops performance incentives (Decision 5) and renders real-time monitoring void.

**Recommendation:** Assume the cloud infrastructure must successfully handle a peak ingestion rate 3x the average expected daily volume (to cover synchronization backlogs from remote areas) with a maximum MTTR of 4 hours for system-wide failure. Benchmark readiness against a major national digital transaction system (e.g., tax filing portal) peak load metrics.

**Sensitivity:** If the system fails to handle peak load (baseline: 4-hour MTTR), data backlog causes a 10-day delay in supervisor data review. This triggers a 2-week delay in paying 50% of enumerator salaries for that cycle. This delay significantly increases the risk of attrition or work slowdown, potentially translating to a 2-4 week overall project timeline slip and an associated 0.5% drop in final data integrity quality (due to rushed subsequent cycles).

## Review conclusion
The project plan is robust in anticipating technological and acute political hurdles (digital failure, caste sequencing). However, it critically misses forward-looking assumptions regarding the governance closure of the most volatile component—the **Caste Methodology Lock-in**—which risks late-stage methodological changes crippling early training. Furthermore, the massive procurement of digital assets lacks a quantifiable **Decommissioning/Sustainability Plan**, creating open-ended long-term liabilities. Finally, the pressure on the **Asynchronous Data Pipeline** is underestimated; success hinges not just on having edge servers, but on their resilience to extreme, politically driven load spikes.