### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start

### 2. Project Manager circulates Draft SteerCo ToR v0.1 for review by the Registrar General and Census Commissioner, Secretary of Ministry of Home Affairs, Secretary of Ministry of Statistics and Programme Implementation, Chief Statistician of India, and Representative from NITI Aayog.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1 circulated for review

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager consolidates feedback on the SteerCo ToR and revises the document.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Consolidated Feedback Summary
- Draft SteerCo ToR v0.2

**Dependencies:**

- Draft SteerCo ToR v0.1 circulated for review
- Feedback from nominated members

### 4. Registrar General and Census Commissioner (or delegate) approves the final Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Registrar General and Census Commissioner

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0

**Dependencies:**

- Draft SteerCo ToR v0.2
- Consolidated Feedback Summary

### 5. Registrar General and Census Commissioner formally appoints the Project Steering Committee Chair (Registrar General and Census Commissioner) and members (Secretary, Ministry of Home Affairs, Secretary, Ministry of Statistics and Programme Implementation, Chief Statistician of India, Independent Expert (Statistician/Demographer), Representative from NITI Aayog).

**Responsible Body/Role:** Registrar General and Census Commissioner

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails
- Project Steering Committee Membership List

**Dependencies:**

- Approved SteerCo ToR v1.0

### 6. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- SteerCo Kick-off Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Project Steering Committee Membership List

### 7. Hold the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- SteerCo Kick-off Meeting Invitation

### 8. Project Director (or delegate) establishes the PMO structure and staffing.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- PMO Structure Chart
- PMO Staffing Plan

**Dependencies:**

- Project Start

### 9. Project Director (or delegate) develops project management templates and tools.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Management Templates
- Project Management Tools

**Dependencies:**

- PMO Structure Chart

### 10. Project Director (or delegate) defines project reporting procedures and communication protocols.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Project Reporting Procedures
- Communication Protocols

**Dependencies:**

- Project Management Templates

### 11. Project Director schedules the initial PMO kick-off meeting.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- PMO Kick-off Meeting Invitation
- Meeting Agenda

**Dependencies:**

- PMO Staffing Plan

### 12. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- PMO Kick-off Meeting Invitation

### 13. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Steering Committee established

### 14. Project Manager circulates Draft Technical Advisory Group ToR v0.1 for review by potential members (Chief Technology Officer (CTO), Senior Software Architect, Data Security Expert, Network Engineer, Mobile App Development Expert, Independent IT Consultant).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1 circulated for review

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1

### 15. Project Manager consolidates feedback on the Technical Advisory Group ToR and revises the document.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Consolidated Feedback Summary
- Draft Technical Advisory Group ToR v0.2

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1 circulated for review
- Feedback from nominated members

### 16. Project Steering Committee approves the final Terms of Reference for the Technical Advisory Group.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Approved Technical Advisory Group ToR v1.0

**Dependencies:**

- Draft Technical Advisory Group ToR v0.2
- Consolidated Feedback Summary

### 17. Project Steering Committee formally appoints the Technical Advisory Group Chair (Chief Technology Officer (CTO)) and members (Senior Software Architect, Data Security Expert, Network Engineer, Mobile App Development Expert, Independent IT Consultant).

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails
- Technical Advisory Group Membership List

**Dependencies:**

- Approved Technical Advisory Group ToR v1.0

### 18. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- Technical Advisory Group Kick-off Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Technical Advisory Group Membership List

### 19. Hold the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 14

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Technical Advisory Group Kick-off Meeting Invitation

### 20. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Steering Committee established

### 21. Project Manager circulates Draft Ethics & Compliance Committee ToR v0.1 for review by potential members (Legal Counsel, Data Protection Officer, Ethics Officer, Representative from the Ministry of Social Justice, Independent Ethics Consultant, Representative from a Civil Society Organization focused on data privacy).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1 circulated for review

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 22. Project Manager consolidates feedback on the Ethics & Compliance Committee ToR and revises the document.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Consolidated Feedback Summary
- Draft Ethics & Compliance Committee ToR v0.2

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1 circulated for review
- Feedback from nominated members

### 23. Project Steering Committee approves the final Terms of Reference for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Approved Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.2
- Consolidated Feedback Summary

### 24. Project Steering Committee formally appoints the Ethics & Compliance Committee Chair (Legal Counsel) and members (Data Protection Officer, Ethics Officer, Representative from the Ministry of Social Justice, Independent Ethics Consultant, Representative from a Civil Society Organization focused on data privacy).

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails
- Ethics & Compliance Committee Membership List

**Dependencies:**

- Approved Ethics & Compliance Committee ToR v1.0

### 25. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Kick-off Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Ethics & Compliance Committee Membership List

### 26. Hold the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 14

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Ethics & Compliance Committee Kick-off Meeting Invitation

### 27. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Project Steering Committee established

### 28. Project Manager circulates Draft Stakeholder Engagement Group ToR v0.1 for review by potential members (Communications Director, Public Relations Officer, Community Liaison Officer, Representative from the Ministry of Information and Broadcasting, Representative from a Civil Society Organization, Independent Communications Consultant).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1 circulated for review

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1

### 29. Project Manager consolidates feedback on the Stakeholder Engagement Group ToR and revises the document.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Consolidated Feedback Summary
- Draft Stakeholder Engagement Group ToR v0.2

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1 circulated for review
- Feedback from nominated members

### 30. Project Steering Committee approves the final Terms of Reference for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Approved Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.2
- Consolidated Feedback Summary

### 31. Project Steering Committee formally appoints the Stakeholder Engagement Group Chair (Communications Director) and members (Public Relations Officer, Community Liaison Officer, Representative from the Ministry of Information and Broadcasting, Representative from a Civil Society Organization, Independent Communications Consultant).

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails
- Stakeholder Engagement Group Membership List

**Dependencies:**

- Approved Stakeholder Engagement Group ToR v1.0

### 32. Project Manager schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Kick-off Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Stakeholder Engagement Group Membership List

### 33. Hold the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 14

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Stakeholder Engagement Group Kick-off Meeting Invitation