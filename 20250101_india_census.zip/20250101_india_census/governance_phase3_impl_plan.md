### 1. Project Sponsor (Cabinet Secretary/Minister) formally designates the Registrar General and Census Commissioner as the Executive Lead for project initiation and establishes the Judicial Review Board structure and authority (by Q3 2025, per strategy).

**Responsible Body/Role:** Project Sponsor / Cabinet Secretary

**Suggested Timeframe:** Project Week 1 (Pre-Launch - 2025 Q3)

**Key Outputs/Deliverables:**

- Official Mandate letter designating Executive Lead
- Statutory authorization document for Judicial Review Board (per Decision 4)
- Nomination list for Judicial Review Board members

**Dependencies:**

- Political mandate to proceed with the 2026 Census timeline finalized

### 2. Project Executive Lead (Registrar General) drafts initial Terms of Reference (ToR) for the Project Steering Committee (PSC), including financial threshold for review (₹500 Cr).

**Responsible Body/Role:** Registrar General and Census Commissioner

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1
- Draft financial approval matrix

**Dependencies:**

- Step 1: Official mandate received

### 3. Executive Lead drafts initial ToR for the Core Project Management & Operations Board (CPMOB) and Data Integrity and Compliance Assurance Group (DICAG), defining representation and operational escalation paths.

**Responsible Body/Role:** Registrar General and Census Commissioner

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft CPMOB ToR v0.1
- Draft DICAG ToR v0.1

**Dependencies:**

- Step 2: PSC ToR framework established

### 4. Executive Lead finalizes the 'Gold Standard' methodology and questionnaire design for the comprehensive caste data collection (Addressing Assumption Issue 1), locking in alignment with Decision 2.

**Responsible Body/Role:** Registrar General and Census Commissioner (with consultation from Methodology Experts)

**Suggested Timeframe:** Project Week 4 (Deadline: Q4 2025)

**Key Outputs/Deliverables:**

- Finalized Census Questionnaire (V1)
- Caste Methodology Lock-in Sign-off Document

**Dependencies:**

- Political agreement on Decision 2 choice (Two-Stage Provisional Collection)

### 5. Nominated Senior Stakeholders (MHA, ECI, Finance) review and formally ratify the PSC, CPMOB, and DICAG Terms of Reference (ToR) and confirm membership nominations.

**Responsible Body/Role:** Project Steering Committee (PSC) Nominated Members

**Suggested Timeframe:** Project Week 5 & 6

**Key Outputs/Deliverables:**

- Approved PSC ToR v1.0
- Approved CPMOB ToR v1.0
- Approved DICAG ToR v1.0
- Official list of confirmed PSC, CPMOB, DICAG members

**Dependencies:**

- Step 2, 3, 4: Draft ToRs and Nomination Lists available

### 6. Project Steering Committee (PSC) holds its inaugural setup meeting: formally ratifies ToRs, confirms Chair (Secretary, MHA), and approves the initial budget tranches for Q1/Q2 2026 (e.g., hardware tender initiation).

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Inaugural PSC Meeting Minutes
- Formal written charter for the PSC
- Initial Budget release authorization

**Dependencies:**

- Step 5: Ratified ToRs and Confirmed Membership

### 7. CPMOB establishes the central Digital Operations Center (DOC) infrastructure and finalizes the specific financial validation metrics tied to 50% performance pay contingent (Decision 5 thresholds).

**Responsible Body/Role:** Core Project Management & Operations Board (CPMOB)

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- DOC operational
- Finalized performance incentive structure for enumerators (Decision 5)

**Dependencies:**

- Step 6: PSC budget approval
- Step 4: Finalized Caste Methodology for App Integration

### 8. DICAG establishes audit sampling frames, formally adopts the ratified methodology (Step 4) as the compliance baseline, and designs initial reconciliation protocols (Decision 1).

**Responsible Body/Role:** Data Integrity and Compliance Assurance Group (DICAG)

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Audit Sampling Plan v1.0
- Compliance Baseline Document referencing Step 4
- Draft Protocol for Paper Audit Reconciliation

**Dependencies:**

- Step 4: Finalized methodology lock-in

### 9. CPMOB initiates the primary technology procurement cycle (Decision 7) based on PSC-approved budget, focusing on securing supply contracts with three vendors for redundancy.

**Responsible Body/Role:** Logistics and Field Operations Manager (under CPMOB oversight)

**Suggested Timeframe:** Project Week 10 - Week 18 (Procurement Cycle)

**Key Outputs/Deliverables:**

- Signed hardware leasing/procurement contracts (multi-vendor)

**Dependencies:**

- Step 6: Budget authorization for hardware funding

### 10. DICAG briefs CPMOB on the required data ingestion and anomaly detection capacity for the Real-Time Data Monitoring System (Decision 9), ensuring provisioning exceeds required burst load factor (Assumption Issue 3).

**Responsible Body/Role:** Data Integrity and Compliance Assurance Group (DICAG)

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- RTM System Capacity Requirements Document
- Signed SLA with Cloud/Infrastructure Provider

**Dependencies:**

- Step 7: DOC established
- Step 9: DICAG formalized

### 11. CPMOB oversees mass enrollment and deployment of Digital Literacy Certification prerequisite training for all 3 million Enumerators (Decision 5 eligibility criteria).

**Responsible Body/Role:** Head of Training and Capacity Building (under CPMOB oversight)

**Suggested Timeframe:** Project Week 13 - 24 (Leading up to Phase 1 Start)

**Key Outputs/Deliverables:**

- Certification completion log for 3M Enumerators
- Pilot testing sign-off for online training platform (Decision 8 readiness)

**Dependencies:**

- Step 4: Final questionnaire ready for training content creation
- Step 10: Cloud/RTM infrastructure established

### 12. CPMOB holds the primary Logistics Readiness Review, confirming hardware distribution schedules and the establishment plan for satellite communication hubs (Decision 1 implementation).

**Responsible Body/Role:** Logistics and Field Operations Manager (under CPMOB oversight)

**Suggested Timeframe:** Project Week 25

**Key Outputs/Deliverables:**

- Logistics Readiness Report for Phase 1 deployment
- Satellite Hub Deployment Plan

**Dependencies:**

- Step 9: Hardware procurement completion

### 13. PSC holds Mid-Preparation Review: Confirms readiness for April 1st launch, reviews political Deconfliction status (Decision 6 Liasons appointed), and endorses the data release sequencing strategy (Decision 4).

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 28 (March 2026)

**Key Outputs/Deliverables:**

- Go/No-Go Decision for Phase 1 Launch
- Review of Judicial Review Board readiness (per Assumption Q4)

**Dependencies:**

- Step 12: Logistics Readiness Confirmed
- Step 1: Judicial Review Board established

### 14. Phase 1 Enumeration Commences (April 1, 2026). CPMOB activates Daily Stand-ups and DICAG activates Real-Time Monitoring and initial paper audit readiness checks (Decision 1).

**Responsible Body/Role:** CPMOB / DICAG

**Suggested Timeframe:** Project Week 29 (April 1, 2026)

**Key Outputs/Deliverables:**

- Phase 1 Official Start Notification
- First Daily RTM Dashboard Report

**Dependencies:**

- Step 13: Phase 1 Go Decision

### 15. DICAG initiates the first formal review of mobile team data against required geo-tagging standards for Nomadic/Migrant enumeration (Decision 3 compliance).

**Responsible Body/Role:** Data Integrity and Compliance Assurance Group (DICAG)

**Suggested Timeframe:** Project Week 33 (End of May 2026)

**Key Outputs/Deliverables:**

- Initial Field Data Quality assessment focusing on Decision 3 compliance

**Dependencies:**

- Step 14: Phase 1 data collection active

### 16. PSC reviews initial data synchronization backlog and performance validation rejection rates (Risk 1, Risk 3 status) and authorizes contingency release if validation failure rate exceeds 10% threshold.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 37 (September 2026 - End of Phase 1)

**Key Outputs/Deliverables:**

- Phase 1 Review Report
- Decision on Contingency Fund utilization (per Risk 7 mitigation)

**Dependencies:**

- 3 Months of active Phase 1 data submitted

### 17. CPMOB executes transition plan: Finalizes disbursement of 50% contingent pay based on Phase 1 validation results (Decision 5) and conducts mandatory, localized refresher workshops (Decision 8) for Phase 2 specifics (Caste Data Collection focus).

**Responsible Body/Role:** CPMOB / Head of Training and Capacity Building

**Suggested Timeframe:** Project Week 38 - 40 (October 2026)

**Key Outputs/Deliverables:**

- Phase 1 Enumerator Payment Confirmation
- Phase 2 Training Completion Logos

**Dependencies:**

- Step 15: Phase 1 validation completed
- Step 4: Final Methodology Lock-in

### 18. Phase 2 Enumeration Commences. CPMOB prioritizes data flow management to ensure sufficient time buffer exists for Judicial Review Board arbitration related to Decision 4 (Population Data Release).

**Responsible Body/Role:** Core Project Management & Operations Board (CPMOB)

**Suggested Timeframe:** Project Week 41 (September 2026 Start)

**Key Outputs/Deliverables:**

- Phase 2 Data Collection Commencement

**Dependencies:**

- Step 16: Phase 1 complete and training finalized

### 19. DICAG conducts review of primary data collection to confirm if the provisional caste data aligns sufficiently with the established 1931 baseline (Decision 2 compliance check for the two-stage process).

**Responsible Body/Role:** Data Integrity and Compliance Assurance Group (DICAG)

**Suggested Timeframe:** Project Week 45 (January 2027)

**Key Outputs/Deliverables:**

- Mid-Phase 2 Provisional Caste Quality Report

**Dependencies:**

- Step 17: Phase 2 data actively flowing

### 20. Phase 2 Enumeration Concludes (April 1, 2027). All personnel transition immediately to final data synchronization, cleanup, and system validation readiness for Provisional Population Totals (PPT) release preparation.

**Responsible Body/Role:** CPMOB

**Suggested Timeframe:** Project Week 52 (April 1, 2027)

**Key Outputs/Deliverables:**

- Official Phase 2 Completion Declaration
- Data Freeze Notification for PPT Generation

**Dependencies:**

- Completion of all field operations

### 21. PSC reviews finalized, reconciled population data aggregation submitted by CPMOB and approves the format/content for the 6-month release mandated by Decision 4.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 54 (May 2027)

**Key Outputs/Deliverables:**

- PSC Approval to Publish Provisional Population Totals

**Dependencies:**

- Step 20: Data Freeze
- Judicial Review Board review underway

### 22. Provisional Population Totals published to Election Commission and public domain (Achieving 6-month milestone). DICAG commences mandatory 3-month public review period for provisional caste data (Decision 2).

**Responsible Body/Role:** Registrar General and Census Commissioner

**Suggested Timeframe:** Project Week 57 (October 2027)

**Key Outputs/Deliverables:**

- Publication of Provisional Population Totals (PPT)
- Start of 3-month Public Caste Data Review Window

**Dependencies:**

- Step 21: PPT Approval

### 23. DICAG concludes the 3-month public review of provisional caste data, consolidates feedback, and issues final linkage recommendations to CPMOB for Final Data Aggregation.

**Responsible Body/Role:** Data Integrity and Compliance Assurance Group (DICAG)

**Suggested Timeframe:** Project Week 61 (January 2028)

**Key Outputs/Deliverables:**

- Final Caste Linking Recommendation Document
- Final Assessment for Statistical Credibility (Pre-release)

**Dependencies:**

- Step 22: End of Public Review Period