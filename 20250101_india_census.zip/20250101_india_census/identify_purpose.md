**Purpose:** business

**Purpose Detailed:** Mega-scale national infrastructure and governance project involving logistical planning, technology deployment, political risk management, societal resource allocation determination, and extensive government resource management (logistics, personnel, finance).

**Topic:** Execution of India's Decennial Population Census (2026-2027)