This plan involves money.

## Currencies

- **INR:** Indian Rupee, the local currency for all expenses within India.
- **USD:** United States Dollar, for budgeting and reporting given the project's scale and potential for international comparison.

**Primary currency:** USD

**Currency strategy:** USD is recommended for budgeting and reporting to mitigate risks from potential currency fluctuations. INR will be used for local transactions. Hedging strategies may be considered to manage exchange rate risks.