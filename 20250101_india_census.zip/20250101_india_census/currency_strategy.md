This plan involves money.

## Currencies

- **INR:** The project budget is explicitly stated in Indian Rupees (₹12,000–15,000 crore), and all primary operational expenditures (salaries, local logistics) will occur within India.
- **USD:** Due to the massive scale of the project and the need for budgeting/reporting against international benchmarks (the text implies a USD equivalent for the budget), USD is a necessary reserve or reporting currency.

**Primary currency:** INR

**Currency strategy:** The primary budget and operational costs will be denominated and executed in Indian Rupees (INR). Given the scale and the funding source (Government of India), USD is included only for high-level reporting parity, but INR will be used for vendor payments and enumerator compensation. No significant foreign exchange risk is anticipated as expenditure is domestic.