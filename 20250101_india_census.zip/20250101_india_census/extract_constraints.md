## Positive Constraints

- Execute India's national population census
- Cover over 1.4 billion people across 240+ million households
- Phase 1 begins April 1, 2026
- Phase 1 runs through September 2026
- Phase 1 focuses on housing and facilities documentation
- Phase 2 runs September 2026 through April 1, 2027
- Phase 2 collects the full demographic dataset including the first comprehensive caste enumeration since 1931
- Broaden caste accounting beyond Scheduled Castes and Scheduled Tribes to cover all caste categories
- Deploy over 3 million government workers as enumerators
- Equip enumerators with a multilingual smartphone application integrated with satellite-based mapping
- Offer a digital survey option blended with traditional in-person enumeration
- Technology stack must function reliably across India's infrastructure variance
- Plan logistics across 28 states and 8 union territories
- Account for dozens of official languages
- Account for monsoon season disruption during Phase 1
- Account for security requirements in conflict-affected areas (Kashmir, Naxalite corridors, Northeast insurgency zones)
- Account for enumerating nomadic, homeless, and migrant populations
- Treat intense political pressure on methodology, question framing, and data release timing as a first-order operational constraint
- Plan quality assurance through independent verification surveys, GPS-stamped entries, and real-time anomaly detection
- Budget is estimated at ₹12,000–15,000 crore (approximately .4–1.8 billion USD)
- Budget funded entirely by the Government of India through the Ministry of Home Affairs
- Registrar General and Census Commissioner is the executing authority
- Success criterion: complete enumeration of 99%+ of households in both phases
- Success criterion: provisional population totals published within 6 months of Phase 2 completion
- Success criterion: full dataset including caste tables released within 18 months
- Success criterion: census must be accepted as methodologically credible by domestic and international statistical bodies
- Start project ASAP

## Negative Constraints

- Do not use census methodology from 2011 which relied entirely on paper forms
- Avoid enumeration gaps, duplicate counting, and post-hoc data quality issues characteristic of 2011 census
- Avoid relying solely on paper forms
- Avoid app/data risks like device procurement/distribution failures, app reliability failure in low-connectivity environments, data synchronization failure, deduplication failure, or enumerators fabricating entries to meet quotas
