Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 14 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 5 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the prompt constrains the scope to fundamental physics only. The plan involves legislation, treaties, currency adoption, governance reform, or any non-physics ‘laws’.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of digital data collection and comprehensive caste census at an unprecedented scale (1.4 billion people). The plan lacks independent evidence at comparable scale. 

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Each track must produce one authoritative source or a supervised pilot showing results vs a baseline. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Owner: Chief Census Strategist / Deliverable: Validation Report / Date: 2025-12-31.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a clear, defined mechanism-of-action (inputs→process→customer value) for key strategic concepts. For example, "Political Interference Mitigation" is identified as critical, but its specific mechanism is not detailed. 

**Mitigation**: Chief Census Strategist: Create one-pagers for each strategic concept (e.g., Political Interference Mitigation), detailing the mechanism-of-action, value hypotheses, success metrics, and decision hooks. Date: 2025-07-01.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies several risks (technical, financial, environmental, social, security, political) and proposes mitigation strategies. However, explicit cascade analysis and second-order risk registers are absent. For example, the plan mentions "delays in procuring supplies" but doesn't map the cascade.

**Mitigation**: Risk Management Team: Expand the risk register to include cascade effects for each identified risk, map second-order risks, and add controls with a dated review cadence. Due: Within 60 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions "Data Collection Permits", "Access Permits for Restricted Areas", and "Permits for operating in conflict zones" but lacks lead times.

**Mitigation**: Legal Team: Create a permit/approval matrix with all required permits, typical lead times in each jurisdiction, and scheduled allocation. Due: Within 90 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because committed sources/term sheets do not cover the required runway or financing gates/covenants are undefined. The plan mentions funding from the Government of India (₹12,000–15,000 crore) but lacks details on draw schedule, covenants, and status.

**Mitigation**: CFO: Develop a dated financing plan listing funding sources, status (e.g., committed, term sheet), draw schedule, covenants, and a NO-GO on missed financing gates. Due: Within 60 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget (₹12,000–15,000 crore) lacks substantiation via vendor quotes or scale-appropriate benchmarks normalized by area. The plan omits contingency for cost overruns. Adequacy is unknown.

**Mitigation**: CFO: Benchmark costs (≥3) for similar projects, obtain vendor quotes, normalize per-area (m²/ft²), add 10-20% contingency, and adjust budget or de-scope. Due: 2025-09-30.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., completion dates) as single numbers without providing a range or discussing alternative scenarios. For example, the goal is to complete the census by "April 1, 2027" without a worst-case scenario.

**Mitigation**: Project Management: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the April 1, 2027 completion date. Due: Within 60 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks essential engineering artifacts such as specifications, interface contracts, acceptance tests, and integration plans for core components. Their absence creates a critical failure mode.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners and dates within 90 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes several critical claims without providing verifiable evidence. For example, the plan states the goal is "Achieving 99%+ household enumeration" but lacks evidence of feasibility. 

**Mitigation**: Project Management: Produce an evidence pack with artifacts (documents/links/IDs) that support each critical claim. If evidence is unavailable, change scope. Due: 2025-12-31.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions several deliverables (e.g., "full dataset, including caste tables") without defining specific, verifiable qualities or acceptance criteria. The plan lacks SMART criteria for the full dataset.

**Mitigation**: Data Team: Define SMART acceptance criteria for the full dataset, including a KPI for data completeness (e.g., <1% missing values). Due: Within 60 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes a comprehensive caste enumeration. This feature adds significant political complexity without a clear demonstration of direct support for the core project goal of basic population enumeration. The core goals are to reshape India's parliamentary map and inform policy.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of the caste enumeration, complete with a KPI, owner, and estimated cost, or move the feature to the project backlog. Due: 2025-07-01.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies the need for 2.7M enumerators, but the plan lacks a clear rationale for how this role will be filled given the scale and skill requirements. The plan does not address the difficulty of recruiting and retaining such a large workforce.

**Mitigation**: HR Team: Conduct a talent market analysis for the Enumerator role, assessing availability, required skills, and compensation expectations. Due: Within 60 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a regulatory matrix mapping authorities, artifacts, lead times, and predecessors. The plan mentions the Census Act 1948 and IT Act 2000, but it does not map the required artifacts.

**Mitigation**: Legal Team: Develop a regulatory matrix mapping authorities, artifacts, lead times, and predecessors for all relevant regulations. Due: Within 90 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions a "Lack of long-term plan for technology/data maintenance" as Risk 12. However, the plan lacks details on funding/resource strategy, maintenance schedule, succession planning, technology roadmap, or adaptation mechanisms.

**Mitigation**: Sustainability Team: Develop an operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, and technology roadmap. Due: Within 120 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "Data Collection Permits", "Access Permits for Restricted Areas", and "Permits for operating in conflict zones" but lacks lead times. Success hinges on approvals.

**Mitigation**: Legal Team: Create a permit/approval matrix with all required permits, typical lead times in each jurisdiction, and scheduled allocation. Due: Within 90 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "Technology Redundancy Strategy" but lacks evidence of contracts/SLAs with vendors for connectivity or device maintenance. The plan does not include tested failover procedures. "Maintaining a parallel paper-based system provides redundancy."

**Mitigation**: Procurement Team: Secure SLAs with connectivity and device vendors, add a secondary supplier/path for critical services, and test failover procedures by 2025-12-31.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan states goals for the 'Ministry of Home Affairs' (accurate data for policy) and '3 Million Enumerators' (gain valuable skills). A conflict exists: MHA wants granular data, while enumerators may prioritize speed to meet quotas.

**Mitigation**: Project Management: Define a shared OKR that aligns MHA's need for granular data with enumerators' need for efficiency, such as 'Increase data accuracy while maintaining enumeration speed'. Due: 2025-07-01.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Management: Add a monthly review with KPI dashboard and a lightweight change board. Owner: Project Manager. Deliverable: Monthly Review Report. Date: 2025-07-01.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies several high risks (political interference, technical failures, operational challenges) but lacks a concrete cascade analysis. Political interference could undermine data quality, leading to flawed policy decisions and social unrest.

**Mitigation**: Risk Management Team: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Due: Within 90 days.