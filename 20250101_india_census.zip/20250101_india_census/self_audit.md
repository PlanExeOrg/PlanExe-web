Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 20 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 0 | Material risk with plausible path. |
| ✅ Low | 0 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the scope requires success literally depends on breaking a law of physics, which is only rated HIGH if success requires breaking a named law of physics. The plan deals with logistics, technology deployment, and political sequencing, which do not violate fundamental physics laws.

**Mitigation**: Project Management Office: Update the scope documentation to explicitly confirm the project does not rely on violating any fundamental laws of physics (e.g., conservation of energy) within 15 days.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project hinges on the highly novel combination of next-generation digital census tools deployed across variable infrastructure alongside groundbreaking, politically volatile caste enumeration, which lacks independent evidence at comparable scale across all these dimensions simultaneously.

**Mitigation**: Project Management Office: Run parallel validation tracks for Technology, Political Sequencing, and Caste Methodology, defining clear NO-GO gates for empirical soundness and legal clearance by Q4 2025. Owner: Executive Steering Committee / Deliverable: Integrated Validation Plan / Date: December 15, 2025.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan utilizes multiple undefined strategic concepts, such as 'Pioneer's Gambit' and 'Federal Data Integrity Liaisons,' without documented mechanism-of-action one-pagers that define inputs, process, customer value, and decision hooks.

**Mitigation**: Chief Census Strategist & Political Liaison: Produce executive one-pagers detailing the mechanism-of-action, success metrics, and decision hooks for 'The Pioneer's Gambit' and 'Federal Data Integrity Liaisons' within 45 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on an aggressive technological dependency (Pioneer's Gambit satellite hubs) whose high cost and complexity are minimized, directly creating a budget overrun risk that jeopardizes contingency funds necessary for paper audits that guarantee 99%+ coverage.

**Mitigation**: Financial Stewardship & Risk Budgeter: Commission an immediate cost-benefit analysis comparing satellite deployment TCO against low-bandwidth alternatives, aiming for a verified 40% cost reduction by Q4 2025.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the instruction specifies rating HIGH if the permit/approval matrix is absent. The plan documents regulatory bodies but lacks a comprehensive matrix detailing the typical lead times for required approvals like Census Act authorization or specific state cooperation MoUs exceeding 20% of allocated time.

**Mitigation**: Governance & Regulatory Compliance Officer: Develop and publish the authoritative Permit/Approval Matrix, detailing all necessary governance milestones and their required governmental sign-off lead times within 45 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because committed sources are absent. The plan does not name any specific funding source (e.g., Government allocation tranche, specific loan term sheet) nor provide a drawdown schedule or defined financing gates/covenants.

**Mitigation**: Financial Stewardship & Risk Budgeter: Draft the dated Financing Plan (Budget Charter) detailing committed INR sources, projected drawdowns coinciding with WBS phases, and covenants, targeting MHA approval by Q1 2026.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the instruction requires citing specific benchmarks/quotes and per-area math to substantiate the figure, but the entire document lacks any stated budget figures or cost normalization by area (cost per m²/ft²).

**Mitigation**: Financial Stewardship & Risk Budgeter: Develop preliminary cost normalization models for key CAPEX components (devices, satellite support) using benchmark data from Suggestion 1 (Uganda Census) by Q2 2026.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Pioneer's Gambit' selects decisions that present key projections like coverage (99%+), digital reliance (satellite deployment), and payment timing (7-day validation) as single commitments without explicit stress analysis or worst-case financial modeling for failure modes.

**Mitigation**: Executive Steering Committee: Mandate the production of Best/Base/Worst-Case Scenario Analyses for the 99%+ coverage KPI and the 7-day variable pay window, incorporating FM3 and FM8 failure probabilities, within 45 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan implies critical technical artifacts (specs, acceptance tests, integration plans) are missing, as the Expert Review warns that the chosen technology approach is 'punishing, financially extravagant' (Expert Issue 1.4.A) and the incentive design conflicts with reality (Expert Issue 1.5.C).

**Mitigation**: Digital Infrastructure & Connectivity Lead / Data Quality & Performance Auditor: Deliver technical specifications for the final remote connectivity strategy and the acceptance tests for the Day 1 data ingestion pipeline (MTTR < 4h) by Q4 2025.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the instructions require citing a specific claim and stating the missing artifact. The plan's analysis of Failure Mode FM6 states: 'Key Decisions: ... Pre-commit to releasing the baseline population totals for constituency delineation first, using only the initial housing frame documentation (Phase 1 data) before full demographic data is adjudicated...' This critical sequencing relies on an artifact—the Election Commission's legal agreement on this sequence—which Review 10 confirms is missing. Missing artifact: Formal agreement from the Election Commission of India (ECI) regarding the politically sensitive sequential data release.

**Mitigation**: Chief Census Strategist & Political Liaison: Secure a formal, signed Memorandum of Understanding from the Election Commission of India confirming acceptance of the 6-month offset between population and caste data release by Q4 2025.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project explicitly identifies 'Decision 2: Methodological Handling of Comprehensive Caste Data' as a core output whose success is measured by 'the accepted final linkage between caste identity and demographic counts for policy use.' No specifics, KPIs, or acceptance criteria for this 'linkage' are provided in the SMART criteria.

**Mitigation**: Chief Census Strategist & Political Liaison: Define SMART acceptance criteria for caste linkage, including a KPI for statistical consistency (e.g., linkage error rate <1%) accepted by NSC/ECI by December 31, 2025.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because Decision 2 proposes using a 'two-stage data collection' for caste data followed by a public review, but the plan does not define the necessary artifact: the specific rules for linking the provisional self-declaration to the final historical baseline, which Review Expert 2.5 flags as a potential failure.

**Mitigation**: Chief Census Strategist & Political Liaison: Finalize and legally bind the detailed caste Data Dictionary and linkage logic rules with ECI/NSC sign-off by Q4 2025, or else halt mass training.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the most specialized role is the Chief Census Strategist & Political Liaison, owning Decision 2 and 4, requiring the unique blend of high political acumen and deep statistical governance insight described in their background story, making them a likely unicorn.

**Mitigation**: Executive Steering Committee: Commission an immediate, confidential talent market validation survey for Chief Census Strategist profiles with relevant government policy experience within 30 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the instruction requires naming controlling regimes; the plan mentions the **Census Act of India, 1948** but fails to map out specific requirements for legality concerning the sensitive caste enumeration, which Expert Review 2.5 flags as a potential credibility crisis.

**Mitigation**: Governance & Regulatory Compliance Officer: Develop a comprehensive regulatory matrix, detailing statutes (Census Act, IT standards) and required approvals (ECI/NSC sign-off on Caste Methodology) by Q4 2025.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks any explicit framework or financial provision for the disposition, secure erasure, or long-term archival of the 3 million purchased digital assets post-census, creating an unquantified future liability (Assumption Issue 2).

**Mitigation**: Governance & Regulatory Compliance Officer / Financial Stewardship & Risk Budgeter: Establish and ring-fence a Decommissioning and Asset Management Fund (DAMF) equivalent to 8% of hardware expenditure by Q1 2026.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan depends on the cooperation of State Revenue Departments for the 72-hour paper audit contingency (Decision 1), but Assumption A7 relies solely on an unverified 80% staffing dedication from state staff, which threatens the 99%+ coverage goal.

**Mitigation**: Mass Logistics & Field Operations Architect: Secure signed Memorandums of Understanding (MoUs) from 80% of high-risk states confirming verifiable staff capacity allocation for the 72-hour audit window by Q2 2026.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on a critical external dependency (State Revenue Departments) for mandatory paper audits (Decision 1), and Assumption A7 suggests this capacity is unverified, directly threatening the 99%+ coverage goal if concurrent state mandates interfere.

**Mitigation**: Mass Logistics & Field Operations Architect: Secure signed Memorandums of Understanding (MoUs) from 80% of high-risk states confirming verifiable staff capacity allocation for the 72-hour audit window by Q2 2026.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because Finance (incentivized by budget adherence/contingency control) conflicts with Operations (Pioneer's Gambit mandates expensive satellite hubs/paper audits, straining the budget ceiling). Expert Issue 1.4.A highlights this. Quote: 'The adopted 'Pioneer's Gambit' strategy heavily depends on expensive, complex redundancies like deploying 3 million ruggedized devices AND satellite communication hubs... and severely strains the budget (₹15,000 Cr ceiling).'

**Mitigation**: Executive Steering Committee: Define a joint OKR tying budget performance (Contingency Buffer > 50% post-Q1 2027) to successful field coverage (>99.2%), requiring joint sign-off monthly.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks the required feedback loop elements: KPIs are superficial, cadence is vague, and critical missing components include change-control thresholds. Quote: 'KPI 1: Final Enumeration Coverage Rate: Success is defined as achieving a reconciled household coverage rate of 99.5% or higher...' but lacks thresholds for re-planning.

**Mitigation**: Executive Steering Committee: Establish a formal Change Control Board by Q2 2026, defining thresholds (e.g., 2-week delay or 5% budget variance) that automatically trigger mandatory KPI dashboard review.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan exhibits strong coupling/cascading failures identified in Failure Mode FM6: Political Stalemate leading to Delimitation halt. This occurs if the ECI rejects sequencing (Decision 4) due to the unvetted Caste Methodology (Decision 2), which collapses the primary political utility of the entire project.

**Mitigation**: Chief Census Strategist & Political Liaison: Secure a binding ECI agreement on the sequential data release schedule (Population before Caste) and Caste Methodology lock-in by Q4 2025. Owner: Chief Census Strategist & Political Liaison / Deliverable: Tripartite MoU with ECI / Date: December 31, 2025.