### 1. Tracking Critical Success Factor: 99%+ Household Coverage Achievement (Logistical Resilience Check)
**Monitoring Tools/Platforms:**

  - Digital Submission Rate Dashboard (Real-time)
  - Automated Reconciliation Reports (Digital vs. Paper Audits)
  - Field Supervisor Check-in Logs (Decision 1 adherence/satellite hub operational status)

**Frequency:** Daily during active enumeration; Weekly summary for CPMOB.

**Responsible Role:** Core Project Management & Operations Board (CPMOB)

**Adaptation Process:** Logistics Manager adjusts resource allocation (deploying audit teams or shifting supervisory focus) and reports needed activation of contingency satellite resources directly to DICAG for verification. Formal change requests raised to PSC if coverage gap mitigation efforts fail for 7 consecutive days.

**Adaptation Trigger:** Reported coverage rate for any specified administrative unit falls below 97% for 48 hours OR Satellite Hub operational failure rate exceeds 10% in a geographical cluster.

### 2. Monitoring Major Risk: Systemic Enumerator Fabrication/Data Quality (Risk 3)
**Monitoring Tools/Platforms:**

  - Real-Time Data Monitoring and Feedback System (RTM - Decision 9)
  - Anomaly Detection Algorithm Outputs
  - Enumerator Payment Validation Reports (Decision 5)

**Frequency:** Continuously (Automated); Daily review by DICAG.

**Responsible Role:** Data Integrity and Compliance Assurance Group (DICAG)

**Adaptation Process:** DICAG issues mandatory Remedial Action Notices to the responsible CPMOB supervisors. If anomaly flags link to systemic issues (e.g., GPS clustering), CPMOB immediately pauses contingent pay disbursements for the affected cohort pending investigation by DICAG.

**Adaptation Trigger:** System triggers an 'Outlier Event' indicating >5% of enumerators in a defined geographical block show data patterns highly correlated with known fabrication/fabrication thresholds (indicating failure of Decision 5 incentive structure or training failure).

### 3. Tracking Critical Success Factor: Political Sequencing Alignment (Population Data Precedes Caste Data)
**Monitoring Tools/Platforms:**

  - Project Steering Committee (PSC) Decision Log & Approved Timeline Tracker
  - Judicial Review Board Status Reports (Decision 4)
  - External Communication Audit Log

**Frequency:** Bi-weekly review by PSC; Monthly executive summary.

**Responsible Role:** Project Steering Committee (PSC)

**Adaptation Process:** If data aggregation milestones risk missing the 6-month PPT release target, the PSC convenes an emergency session to arbitrate between Election Commission (delimitation needs) and Legal Counsel (review board capacity), potentially escalating to the Cabinet Secretary for timeline adjustment directives.

**Adaptation Trigger:** CPMOB reports a projected delay exceeding 15 days for the final reconciliation of Phase 1 data required for Provisional Population Total (PPT) aggregation, threatening the 6-month deadline.

### 4. Monitoring Major Risk: Political Non-Cooperation & Methodology Adherence (Risk 2 & Decision 2)
**Monitoring Tools/Platforms:**

  - Federal Data Integrity Liaison Status Reports (Decision 6)
  - DICAG Methodology Compliance Review Checklists (Caste Data)
  - Judicial Review Board Docket Status

**Frequency:** Weekly reporting by Liaisons; Bi-weekly audit review.

**Responsible Role:** Data Integrity and Compliance Assurance Group (DICAG), escalated to PSC.

**Adaptation Process:** If DICAG detects significant methodological drift in caste data collection beyond agreed regional variances, the issue is immediately flagged to the PSC. If the drift challenges the 'Statistical Credibility' success criterion, the PSC mediates via the Federal Liaisons or initiates arbitration via the Judicial Review Board.

**Adaptation Trigger:** DICAG reports that regional deviations from the locked-in caste methodology (Decision 2) in any single state or Union Territory exceed 25% of the collected sample, suggesting localized sabotage or compliance failure.

### 5. Tracking Critical Success Factor: Provisional Population Totals (PPT) & Final Data Credibility Timelines
**Monitoring Tools/Platforms:**

  - Master Project Timeline Gantt Chart (Milestone Tracker)
  - Final Data Aggregation Quality Scorecard (Post-Phase 2 Data Freeze)

**Frequency:** Monthly milestone check.

**Responsible Role:** Registrar General and Census Commissioner (via CPMOB reporting to PSC).

**Adaptation Process:** If the data freeze requires extension beyond 30 days past Phase 2 completion, CPMOB analyzes the primary delay source (e.g., data cleaning vs. reconciliation errors) and submits an impact report to the PSC detailing necessary adjustments to the 18-month final release deadline (Caste Data).

**Adaptation Trigger:** Data freeze for provisional totals is not achieved by Month 1 post-Phase 2 completion (i.e., by May 2027).

### 6. Monitoring Major Risk: Enumerator Incentive System Functionality (Risk 3/Decision 5)
**Monitoring Tools/Platforms:**

  - Enumeration Team Payroll Processing Log
  - Data Validation Acceptance Rate Metrics Linked to Worker IDs

**Frequency:** Bi-weekly cycle review (aligned with payment schedule).

**Responsible Role:** Core Project Management & Operations Board (CPMOB)

**Adaptation Process:** If CPMOB confirms that validation rejection rates are high due to RTM false positives or training gaps (instead of fabrication), the PSC is alerted to review the incentive structure thresholds (Decision 5) to prevent mass non-payment, potentially authorizing a one-time 'good faith' partial interim payment.

**Adaptation Trigger:** More than 20% of enumerators miss their first scheduled performance-linked payout tranche (50% of salary) due to validation failure.