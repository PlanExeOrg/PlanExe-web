**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority (above ₹50 crore) and requires strategic oversight.
Negative Consequences: Potential budget overruns, project delays, and failure to meet census objectives.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: Materialization of a critical risk (e.g., political interference, major technology failure) requires strategic intervention and resource reallocation.
Negative Consequences: Project failure, loss of public trust, and inability to deliver census results.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: Inability of the PMO to reach a consensus on a key vendor selection decision requires higher-level arbitration.
Negative Consequences: Project delays, increased costs, and selection of a suboptimal vendor.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote on Scope Change Request
Rationale: Significant changes to the project scope require strategic review and approval to ensure alignment with overall objectives.
Negative Consequences: Scope creep, budget overruns, and failure to deliver the core census objectives.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Steering Committee
Rationale: Allegations of ethical misconduct or non-compliance require independent review and investigation.
Negative Consequences: Legal challenges, reputational damage, and loss of public trust.

**Technical Design Change impacting Data Security**
Escalation Level: Technical Advisory Group
Approval Process: Technical Advisory Group Review and Recommendation to PMO
Rationale: Changes to the technical architecture that could compromise data security require expert review and approval.
Negative Consequences: Data breaches, loss of public trust, and legal challenges.

**Stakeholder Resistance to Census Methodology**
Escalation Level: Stakeholder Engagement Group
Approval Process: Stakeholder Engagement Group Develops and Implements Enhanced Communication Plan, escalating to Steering Committee if resistance persists.
Rationale: Significant resistance from key stakeholders requires a coordinated communication and engagement strategy.
Negative Consequences: Lower response rates, inaccurate data, and political challenges.