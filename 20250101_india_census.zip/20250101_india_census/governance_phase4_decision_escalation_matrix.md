**Budget Request Exceeding PSC Threshold**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Majority vote (at least 4 out of 6 members), unless exceeding ₹1,000 Cr, then escalated to Cabinet Secretary.
Rationale: New expenditure requests or contingency utilization exceeding the established PSC threshold (₹500 Cr, noted in PSC ToR prep) require senior strategic authorization.
Negative Consequences: Project resource starvation or unbudgeted financial liability, potentially jeopardizing hardware procurement or satellite service continuity.

**CPMOB Deadlock on Operational Procedures Affecting Incentives**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC review and Chair's decision used to break standing operational disagreement.
Rationale: Disagreements within the CPMOB (e.g., conflicts between Data Quality Lead and Logistics Manager regarding Device Failure Limits or Payment Thresholds) require higher strategic arbitration to maintain operational traction.
Negative Consequences: Delay in synchronizing data feedback loops, resulting in multi-week delays in enumerator salary payouts (Risk 3 impact) and potential attrition/low morale.

**Critical Compliance Flag Issued by DICAG Regarding Caste Methodology Deviation**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC reviews DICAG's Critical Compliance Flag, specifically assessing the impact on political credibility and methodological acceptance criteria.
Rationale: If DICAG flags systemic non-adherence to the locked-in caste methodology (Decision 2), it threatens the project's core success criterion regarding methodological credibility.
Negative Consequences: Failure to pass external statistical review, massive reputational damage, and potential invalidation of caste data for policy use, undermining the primary social outcome.

**Materialization of Security Incident Leading to Data Confiscation in High-Risk Zones**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Emergency PSC session convened to authorize immediate security mobilization, determine scope of data loss, and sanction compensatory field strategy using contingency funds.
Rationale: Events compromising enumerator safety or leading to theft/destruction of 3M devices (Risk 5/Q5) require rapid strategic authorization beyond routine field response protocols.
Negative Consequences: Localized enumeration halts, physical risk to personnel, potential political fallout regarding security provision, and significant cost overrun from emergency replacement procurement.

**Major Data Release Sequencing Conflict (Delimitation vs. Caste Data Credibility)**
Escalation Level: Cabinet Secretary / Union Cabinet
Approval Process: Direct directive required from the highest executive level based on PSC recommendation, as this involves balancing parliamentary mandates vs. statistical integrity.
Rationale: This issue involves a direct conflict between the politically mandated timing of population data release (Decision 4) and the required review period for caste data, potentially requiring a national policy directive overruling standard sequencing.
Negative Consequences: If the PSC cannot resolve the conflict internally (e.g., if the Election Commission challenges the sequencing), it results in a political stalemate that could halt the entire census reporting pipeline.