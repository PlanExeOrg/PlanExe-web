A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The enumerators will have sufficient digital literacy to effectively use the smartphone application. | Conduct a baseline digital literacy assessment with a representative sample of potential enumerators. | The assessment reveals that more than 30% of potential enumerators lack basic digital skills (e.g., using a smartphone, navigating apps). |
| A2 | The public will willingly and accurately self-identify their caste during enumeration. | Conduct a pilot survey in diverse communities to assess willingness to disclose caste information and the consistency of self-reported caste identities. | The pilot survey reveals that more than 20% of respondents refuse to answer the caste question or provide inconsistent caste information. |
| A3 | The technology infrastructure (connectivity, device reliability) will be sufficient to support real-time data collection in most enumeration areas. | Conduct connectivity tests and device performance assessments in a representative sample of enumeration areas, including remote and underserved regions. | The tests reveal that more than 25% of enumeration areas experience unreliable connectivity (below 2G speeds) or frequent device malfunctions (more than 10% of devices). |
| A4 | The security protocols implemented will be sufficient to protect enumerators from harm in conflict-affected areas. | Conduct a security risk assessment in identified conflict zones, consulting with local law enforcement and community leaders. | The risk assessment reveals significant security threats that cannot be adequately mitigated with the planned security protocols (e.g., active militant presence, high risk of kidnapping). |
| A5 | The public awareness campaign will effectively reach and resonate with all segments of the population, including marginalized and hard-to-reach groups. | Conduct focus groups and surveys with representative samples of marginalized populations to assess their awareness of the census and their perceptions of its relevance and trustworthiness. | The focus groups and surveys reveal that more than 40% of marginalized populations are unaware of the census or distrust its purpose. |
| A6 | The inter-departmental coordination mechanisms will ensure seamless collaboration and resource sharing between government agencies involved in the census. | Conduct a simulation exercise involving representatives from key government agencies to test the effectiveness of the inter-departmental coordination mechanisms in responding to a hypothetical census-related emergency. | The simulation exercise reveals significant coordination gaps and delays in resource allocation, indicating that the inter-departmental coordination mechanisms are inadequate. |
| A7 | The supply chain for procuring smartphones and other essential equipment will remain stable and uninterrupted throughout the census period. | Conduct a thorough assessment of the supply chain, identifying potential vulnerabilities and alternative suppliers. | The assessment reveals significant risks of supply chain disruptions due to geopolitical instability, trade restrictions, or natural disasters. |
| A8 | The chosen incentive structure for enumerators will effectively motivate them to collect accurate data without incentivizing fraud or coercion. | Conduct a pilot study with different incentive structures to assess their impact on data quality and enumerator behavior. | The pilot study reveals that performance-based incentives lead to a significant increase in data fabrication or coercion, while fixed stipends result in low motivation and incomplete data collection. |
| A9 | The data collected during the census will be effectively utilized by policymakers and researchers to inform evidence-based decision-making. | Engage with policymakers and researchers to assess their data needs and develop a plan for disseminating and promoting the use of census data. | Policymakers and researchers express limited interest in using the census data or lack the capacity to analyze and interpret it effectively. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Digital Divide Disaster | Process/Financial | A1 | Training & Capacity Building Manager | CRITICAL (16/25) |
| FM2 | The Caste Census Conundrum | Technical/Logistical | A2 | Political Liaison & Stakeholder Manager | CRITICAL (15/25) |
| FM3 | The Connectivity Collapse | Market/Human | A3 | Technology & Data Security Lead | CRITICAL (16/25) |
| FM4 | The Security Breach Breakdown | Process/Financial | A4 | Security Protocol Rigor Lead | CRITICAL (15/25) |
| FM5 | The Echo Chamber Effect | Technical/Logistical | A5 | Public Awareness & Community Engagement Coordinator | CRITICAL (16/25) |
| FM6 | The Bureaucratic Bottleneck | Market/Human | A6 | Inter-Departmental Coordination Lead | HIGH (12/25) |
| FM7 | The Supply Chain Scramble | Technical/Logistical | A7 | Logistics & Deployment Coordinator | CRITICAL (15/25) |
| FM8 | The Incentive-Induced Inaccuracy | Market/Human | A8 | Data Quality & Validation Specialist | CRITICAL (16/25) |
| FM9 | The Data Graveyard | Process/Financial | A9 | Chief Census Strategist | MEDIUM (8/25) |


### Failure Modes

#### FM1 - The Digital Divide Disaster

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Training & Capacity Building Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Root cause: Insufficient digital literacy among enumerators.
- Contributing factor: Inadequate training resources and curriculum.
- Impact: Significant delays in data collection, increased error rates, and higher operational costs due to the need for extensive manual intervention and rework.
- Financial impact: Increased training costs, lower data quality leading to flawed policy decisions, and potential penalties for non-compliance with data accuracy standards.

##### Early Warning Signs
- Enumerator training completion rates fall below 85%
- Help desk requests related to basic app usage exceed 500 per day
- Data validation flags increase by 20% in the first month of enumeration

##### Tripwires
- Enumerator app usage logs show < 60% daily active users after week 2 of enumeration
- Data validation error rate exceeds 5% after the first month
- Training help desk reports > 100 unresolved digital literacy issues after 3 weeks

##### Response Playbook
- Contain: Immediately deploy mobile support teams to provide on-site assistance to enumerators struggling with the app.
- Assess: Conduct a rapid assessment of the digital literacy curriculum and identify areas for improvement.
- Respond: Revise the training curriculum to include more hands-on exercises and simplified instructions, and provide additional training sessions for enumerators who need extra support.


**STOP RULE:** If, after 2 months, the data validation error rate remains above 10% despite the revised training and support efforts, halt enumeration and reassess the feasibility of the digital data collection strategy.

---

#### FM2 - The Caste Census Conundrum

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Political Liaison & Stakeholder Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Root cause: Public unwillingness to accurately self-identify their caste.
- Contributing factor: Mistrust in government intentions, fear of discrimination, and social stigma associated with certain caste identities.
- Impact: Incomplete or inaccurate caste data, undermining the census's ability to inform policy interventions and potentially exacerbating social tensions.
- Logistical impact: Reduced response rates, increased need for follow-up surveys, and challenges in reaching marginalized communities.

##### Early Warning Signs
- Response rates for the caste question fall below 70% in pilot surveys
- Social media sentiment analysis reveals increasing public skepticism about the purpose of caste enumeration
- Community leaders express concerns about the potential for misuse of caste data

##### Tripwires
- Caste question refusal rate >= 25% in the first two weeks of enumeration
- Negative sentiment on social media regarding caste data collection >= 40%
- Formal complaints from community organizations about coercion or misrepresentation >= 5

##### Response Playbook
- Contain: Immediately suspend caste data collection in areas with high refusal rates and reports of coercion.
- Assess: Conduct a thorough review of the public awareness campaign and identify areas where messaging needs to be improved.
- Respond: Revise the public awareness campaign to emphasize the benefits of caste enumeration for social justice and equitable resource allocation, and engage trusted community leaders to build trust and encourage participation.


**STOP RULE:** If, after 3 months, the caste question refusal rate remains above 20% despite the revised messaging and community engagement efforts, abandon the comprehensive caste enumeration and revert to collecting only broad caste categories.

---

#### FM3 - The Connectivity Collapse

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Technology & Data Security Lead
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Root cause: Insufficient technology infrastructure to support real-time data collection.
- Contributing factor: Unreliable connectivity in remote areas, device malfunctions, and inadequate technical support.
- Impact: Data loss, delays in data synchronization, and increased reliance on manual data entry, leading to higher error rates and reduced data quality.
- Human impact: Frustration among enumerators, reduced morale, and potential for data fabrication.

##### Early Warning Signs
- Data synchronization rates fall below 80% in the first week of enumeration
- Enumerator reports of device malfunctions increase by 15%
- Technology support help desk is overwhelmed with connectivity-related issues

##### Tripwires
- Average data synchronization time exceeds 24 hours for >= 30% of enumerators
- Device malfunction reports >= 15% of deployed devices within the first month
- Connectivity-related support tickets remain unresolved for > 72 hours for >= 20% of enumerators

##### Response Playbook
- Contain: Immediately deploy mobile connectivity vans to provide temporary internet access in areas with unreliable connectivity.
- Assess: Conduct a rapid assessment of the connectivity infrastructure and identify areas where improvements are needed.
- Respond: Partner with telecom operators to expand cellular coverage in underserved regions, and provide additional training to enumerators on using the 'lite' app for offline data capture.


**STOP RULE:** If, after 2 months, the data synchronization rate remains below 70% despite the connectivity improvements and additional training, revert to a paper-based data collection system in the affected areas.

---

#### FM4 - The Security Breach Breakdown

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Security Protocol Rigor Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Root cause: Insufficient security protocols to protect enumerators in conflict zones.
- Contributing factor: Inadequate risk assessment, lack of coordination with local law enforcement, and insufficient training for enumerators on security procedures.
- Impact: Injuries or fatalities among enumerators, disruption of data collection efforts, and damage to the census's credibility.
- Financial impact: Increased insurance costs, compensation claims, and potential legal liabilities.

##### Early Warning Signs
- Security incident reports increase by 50% in conflict-affected areas
- Enumerator absenteeism rises above 20% in high-risk zones
- Local law enforcement expresses concerns about the adequacy of security arrangements

##### Tripwires
- Confirmed attacks on enumerators resulting in serious injury or death >= 2 incidents
- Enumeration halted in >= 3 districts due to security concerns
- Insurance claims related to enumerator safety exceed ₹50 lakh

##### Response Playbook
- Contain: Immediately suspend enumeration activities in the affected areas and evacuate all personnel to safety.
- Assess: Conduct a thorough review of the security protocols and identify areas where improvements are needed.
- Respond: Revise the security protocols to include enhanced security measures, such as armed escorts, improved communication systems, and better coordination with local law enforcement.


**STOP RULE:** If, after implementing the revised security protocols, further attacks occur, resulting in additional injuries or fatalities, abandon enumeration in the affected areas and rely on alternative data sources or statistical modeling.

---

#### FM5 - The Echo Chamber Effect

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Public Awareness & Community Engagement Coordinator
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Root cause: Public awareness campaign fails to reach and resonate with marginalized groups.
- Contributing factor: Inadequate targeting, culturally insensitive messaging, and reliance on mainstream media channels that are not accessible to all segments of the population.
- Impact: Underrepresentation of marginalized groups in the census data, leading to inaccurate policy decisions and perpetuation of existing inequalities.
- Logistical impact: Increased difficulty in reaching hard-to-reach populations, requiring additional resources and specialized enumeration techniques.

##### Early Warning Signs
- Response rates from marginalized communities lag behind the national average by 15%
- Social media sentiment analysis reveals negative perceptions of the census among marginalized groups
- Community leaders express concerns about the inclusivity of the public awareness campaign

##### Tripwires
- Response rates from Scheduled Castes/Tribes fall below 80% after the first month
- Negative sentiment on social media regarding the census among minority groups >= 30%
- Formal complaints from NGOs representing marginalized communities about lack of outreach >= 5

##### Response Playbook
- Contain: Immediately launch targeted outreach programs in marginalized communities, using culturally appropriate messaging and trusted community leaders as messengers.
- Assess: Conduct a rapid review of the public awareness campaign and identify areas where messaging needs to be improved to resonate with marginalized groups.
- Respond: Revise the public awareness campaign to include more diverse voices and perspectives, and utilize community-based media channels to reach hard-to-reach populations.


**STOP RULE:** If, after implementing the targeted outreach programs and revised messaging, response rates from marginalized communities remain significantly below the national average (more than 10% difference), consider alternative enumeration methods, such as door-to-door enumeration with trained community volunteers.

---

#### FM6 - The Bureaucratic Bottleneck

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Inter-Departmental Coordination Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Root cause: Inadequate inter-departmental coordination mechanisms.
- Contributing factor: Bureaucratic silos, conflicting priorities, and lack of clear lines of authority.
- Impact: Delays in resource allocation, logistical bottlenecks, and inconsistent implementation of census procedures.
- Human impact: Frustration among project staff, reduced morale, and potential for errors and omissions.

##### Early Warning Signs
- Significant delays in obtaining necessary permits and approvals from government agencies
- Logistical support requests are frequently denied or delayed
- Communication breakdowns between different government departments

##### Tripwires
- Permit approval times exceed 60 days for >= 25% of applications
- Logistical support requests are denied or delayed for >= 20% of requests
- Formal complaints from project staff about inter-departmental coordination issues >= 10

##### Response Playbook
- Contain: Immediately escalate the coordination issues to senior government officials and request their intervention.
- Assess: Conduct a thorough review of the inter-departmental coordination mechanisms and identify areas where improvements are needed.
- Respond: Establish clear lines of authority and communication protocols, and implement regular coordination meetings with representatives from all key government agencies.


**STOP RULE:** If, after implementing the revised coordination mechanisms, significant delays and bottlenecks persist, jeopardizing the census timeline and data quality, consider outsourcing certain functions to private sector partners or establishing a dedicated census agency with greater autonomy.

---

#### FM7 - The Supply Chain Scramble

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Logistics & Deployment Coordinator
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Root cause: Unstable and interrupted supply chain for smartphones and equipment.
- Contributing factor: Geopolitical instability, trade restrictions, natural disasters impacting manufacturing or transport.
- Impact: Shortages of smartphones, PPE, and other essential equipment, leading to delays in enumeration, reduced data quality, and increased costs.
- Logistical impact: Difficulty in equipping and deploying enumerators, requiring alternative (and potentially less efficient) data collection methods.

##### Early Warning Signs
- Lead times for smartphone orders increase by > 30%
- Key suppliers report production or shipping delays
- Prices for essential equipment rise by > 20%

##### Tripwires
- Smartphone delivery shortfall >= 20% of total order by Phase 1 start
- PPE stock levels fall below 50% of required inventory
- Shipping costs increase by >= 25% due to unforeseen tariffs

##### Response Playbook
- Contain: Immediately activate contingency plans, including sourcing equipment from alternative suppliers and prioritizing distribution to critical areas.
- Assess: Conduct a thorough review of the supply chain and identify the root causes of the disruptions.
- Respond: Diversify the supply chain to reduce reliance on single suppliers or regions, and negotiate long-term contracts with guaranteed delivery schedules.


**STOP RULE:** If, after 3 months, the smartphone delivery shortfall remains above 15% and alternative suppliers cannot be secured, significantly reduce the scope of the digital data collection and revert to a paper-based system in a substantial portion of enumeration areas.

---

#### FM8 - The Incentive-Induced Inaccuracy

- **Archetype**: Market/Human
- **Root Cause**: Assumption A8
- **Owner**: Data Quality & Validation Specialist
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Root cause: Chosen incentive structure motivates fraud or coercion.
- Contributing factor: Overemphasis on speed or completion rates, inadequate monitoring of data quality, and lack of ethical training for enumerators.
- Impact: Fabricated data, coerced responses, and biased census results, undermining the credibility and utility of the data.
- Human impact: Ethical compromises for enumerators, distrust from the public, and potential for social unrest.

##### Early Warning Signs
- Data validation error rates spike in areas with high incentive payouts
- Reports of coercion or data fabrication increase through the whistleblower hotline
- Enumerator surveys reveal concerns about the fairness or ethical implications of the incentive structure

##### Tripwires
- Data fabrication flags triggered for >= 10% of enumerators in high-incentive zones
- Whistleblower hotline receives >= 20 credible reports of coercion or data manipulation
- Enumerator satisfaction scores related to incentives fall below 60%

##### Response Playbook
- Contain: Immediately suspend the performance-based incentive program and revert to a fixed stipend for all enumerators.
- Assess: Conduct a thorough review of the incentive structure and identify the factors that contributed to the unintended consequences.
- Respond: Redesign the incentive structure to emphasize data quality and ethical behavior, and provide additional training to enumerators on data integrity and ethical considerations.


**STOP RULE:** If, after implementing the revised incentive structure and additional training, data fabrication and coercion persist, undermining the integrity of the census data, abandon the use of incentives altogether and rely on close supervision and rigorous data validation procedures.

---

#### FM9 - The Data Graveyard

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Chief Census Strategist
- **Risk Level:** MEDIUM 8/25 (Likelihood 2/5 × Impact 4/5)

##### Failure Story
- Root cause: Census data not effectively utilized by policymakers and researchers.
- Contributing factor: Lack of awareness, limited analytical capacity, data inaccessibility, or political disinterest.
- Impact: Wasted resources, missed opportunities for evidence-based decision-making, and limited social impact of the census.
- Financial impact: Reduced return on investment, difficulty justifying future census operations, and potential for budget cuts.

##### Early Warning Signs
- Policymakers and researchers express limited interest in accessing or using the census data
- Requests for data access and analysis support remain low
- Government agencies fail to incorporate census data into policy planning documents

##### Tripwires
- Data download requests from researchers and policymakers <= 50 within the first year of release
- Citations of census data in government policy documents <= 10 within the first year
- Funding for data dissemination and analysis activities cut by >= 20%

##### Response Playbook
- Contain: Immediately launch a targeted outreach campaign to promote the use of census data among policymakers and researchers.
- Assess: Conduct a survey to identify the barriers to data utilization and understand the data needs of potential users.
- Respond: Develop user-friendly data visualization tools and analysis resources, and provide training and technical assistance to policymakers and researchers on how to effectively use the census data.


**STOP RULE:** If, after 2 years, the census data remains underutilized, with limited impact on policy decisions and research, conduct a comprehensive review of the data collection and dissemination strategies and consider alternative approaches for maximizing the value of the census data.
