**Purpose:** business

**Purpose Detailed:** Execution of a large-scale governmental census operation, including logistical planning, technology deployment, data collection, and political considerations.

**Topic:** India's Decennial Population Census 2026-2027