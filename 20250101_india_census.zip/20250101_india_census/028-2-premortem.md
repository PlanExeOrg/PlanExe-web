A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The enumerator workforce will have sufficient digital literacy to effectively use the census application with minimal errors. | Administer a standardized digital literacy test to a representative sample of recruited enumerators before training begins. | More than 20% of the tested enumerators score below a pre-defined threshold indicating basic proficiency with smartphone applications and data entry. |
| A2 | The data anonymization techniques employed will effectively prevent re-identification of individuals, even with access to external datasets. | Conduct a red team exercise where independent data security experts attempt to re-identify individuals in a sample of anonymized census data using publicly available datasets. | The red team is able to successfully re-identify more than 5% of the individuals in the anonymized dataset with a high degree of confidence. |
| A3 | Community leaders and caste organizations will generally support the census efforts and encourage participation, even with the inclusion of caste data collection. | Conduct a survey of community leaders and caste organization representatives in a diverse set of regions to gauge their level of support for the census and their willingness to promote participation. | More than 30% of the surveyed community leaders and caste organization representatives express significant reservations about the census or indicate they are unlikely to actively encourage participation. |
| A4 | The supply chain for procuring 3.3 million smartphones will remain stable and uninterrupted throughout the project lifecycle. | Conduct a thorough assessment of the smartphone supply chain, including vendor capacity, raw material availability, and potential geopolitical risks. | The assessment identifies significant vulnerabilities in the supply chain that could lead to delays or disruptions in smartphone procurement, such as reliance on a single vendor or dependence on raw materials from politically unstable regions. |
| A5 | The inter-departmental coordination mechanisms established will effectively facilitate seamless data sharing and collaboration between various government agencies involved in the census. | Conduct a simulation exercise involving multiple government agencies to test the effectiveness of the data sharing protocols and communication channels established for the census. | The simulation reveals significant bottlenecks or communication breakdowns that hinder effective data sharing and collaboration between government agencies, such as incompatible data formats or lack of clear roles and responsibilities. |
| A6 | The public awareness campaign will effectively reach all segments of the population, including marginalized communities, and generate sufficient interest and understanding to encourage widespread participation. | Conduct a pre-campaign survey in a representative sample of the population, including marginalized communities, to assess their awareness and understanding of the census and their willingness to participate. | The survey reveals that a significant portion of the population, particularly in marginalized communities, lacks awareness or understanding of the census or expresses reluctance to participate due to privacy concerns or mistrust. |
| A7 | The enumerators will accurately and consistently apply the defined criteria for identifying and classifying different caste categories. | Conduct inter-rater reliability tests where multiple enumerators independently classify the caste of the same individuals based on provided information. | The inter-rater reliability score falls below 0.7, indicating significant inconsistencies in how enumerators are classifying caste categories. |
| A8 | The technology infrastructure (servers, network, data centers) will be resilient enough to handle peak data upload and processing loads without significant performance degradation or downtime. | Conduct load testing simulations to assess the performance of the technology infrastructure under peak data upload and processing conditions. | The load testing reveals that the infrastructure experiences significant performance degradation (e.g., slow response times, data upload failures) or downtime when subjected to peak loads. |
| A9 | The legal and regulatory framework surrounding data privacy and caste data collection will remain stable and unambiguous throughout the census process. | Engage a legal team to continuously monitor relevant laws, regulations, and court decisions related to data privacy and caste data collection. | Significant changes or ambiguities are identified in the legal and regulatory framework that could impact the legality or ethicality of the census data collection or handling procedures. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Digital Divide Disaster | Process/Financial | A1 | Training & Logistics Coordinator | CRITICAL (16/25) |
| FM2 | The Privacy Paradox | Technical/Logistical | A2 | Legal & Compliance Advisor | CRITICAL (15/25) |
| FM3 | The Caste Census Catastrophe | Market/Human | A3 | Community Engagement Coordinator | CRITICAL (20/25) |
| FM4 | The Smartphone Shortage Scramble | Process/Financial | A4 | Procurement Lead | CRITICAL (15/25) |
| FM5 | The Inter-Departmental Impasse | Technical/Logistical | A5 | Inter-Departmental Liaison | CRITICAL (16/25) |
| FM6 | The Apathy Avalanche | Market/Human | A6 | Public Awareness Campaign Manager | CRITICAL (20/25) |
| FM7 | The Caste Classification Chaos | Market/Human | A7 | Data Quality & Integrity Manager | CRITICAL (20/25) |
| FM8 | The Server Meltdown Mayhem | Technical/Logistical | A8 | Technology Deployment Lead | CRITICAL (15/25) |
| FM9 | The Legal Landmine Lockdown | Process/Financial | A9 | Legal & Compliance Advisor | CRITICAL (15/25) |


### Failure Modes

#### FM1 - The Digital Divide Disaster

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Training & Logistics Coordinator
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The assumption of sufficient digital literacy among enumerators proves false. A significant portion of the recruited workforce struggles with the smartphone application, leading to several cascading failures:

*   **Increased Training Costs:** Remedial training programs are hastily implemented, exceeding the initial budget allocation for training by 30%.
*   **Data Entry Errors:** Enumerators unfamiliar with the technology make frequent errors, requiring extensive manual correction and slowing down data processing.
*   **Reduced Enumeration Coverage:** Slower data collection rates and app malfunctions lead to incomplete enumeration in several regions, particularly those with older populations or limited access to digital resources.
*   **Delayed Timeline:** The project falls behind schedule due to the need for additional training and data correction, resulting in penalties and reputational damage.

##### Early Warning Signs
- Help desk call volume from enumerators exceeds 500 calls per day in the first week of training.
- Data validation error rates in pilot testing are 15% higher than anticipated.
- Enumerator training completion rates are 10% lower than projected after the first two weeks.

##### Tripwires
- Data validation error rate exceeds 10% after the first month of Phase 1.
- Training completion rate falls below 85% after the initial training period.
- Help desk resolution time for app-related issues exceeds 24 hours on average.

##### Response Playbook
- Contain: Immediately halt further deployment of the application and revert to paper-based data collection in affected areas.
- Assess: Conduct a rapid assessment of the digital literacy skills of the remaining enumerators and identify areas where additional support is needed.
- Respond: Implement targeted training programs and provide ongoing technical assistance to enumerators struggling with the technology.


**STOP RULE:** If, after three months of remedial training and support, the data validation error rate remains above 8%, the project will revert to a fully paper-based data collection methodology.

---

#### FM2 - The Privacy Paradox

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Legal & Compliance Advisor
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The assumption that data anonymization techniques will effectively prevent re-identification proves false. Despite the implementation of anonymization protocols, a determined group of data security experts is able to re-identify individuals in the released census dataset by cross-referencing it with publicly available information. This leads to:

*   **Legal Challenges:** Lawsuits are filed against the government, alleging violations of data privacy laws and demanding compensation for affected individuals.
*   **Public Outcry:** A major public relations crisis erupts, with widespread condemnation of the government's handling of sensitive data.
*   **Data Recall:** The government is forced to recall the released dataset, incurring significant costs and delaying the dissemination of census results.
*   **Erosion of Trust:** Public trust in the government's ability to protect personal information is severely damaged, making future census efforts more difficult.

##### Early Warning Signs
- Data security experts publicly express concerns about the adequacy of the anonymization techniques being used.
- A proof-of-concept attack demonstrating the potential for re-identification is published in a security journal.
- Internal audits reveal vulnerabilities in the data anonymization process.

##### Tripwires
- Independent security audit reveals a potential re-identification vulnerability with a severity score of 8 or higher (on a scale of 1-10).
- Number of downloads of the anonymized dataset exceeds 10,000 within the first week of release.
- Media reports highlight concerns about the potential for re-identification based on the released data.

##### Response Playbook
- Contain: Immediately suspend public access to the census dataset and initiate a thorough review of the anonymization protocols.
- Assess: Engage independent data security experts to conduct a comprehensive assessment of the re-identification risk and identify vulnerabilities in the anonymization process.
- Respond: Implement enhanced anonymization techniques, such as differential privacy, and re-release the dataset with stricter privacy controls.


**STOP RULE:** If a successful re-identification attack is confirmed after the implementation of enhanced anonymization techniques, the project will permanently withdraw the public dataset and rely solely on aggregated data for policy-making.

---

#### FM3 - The Caste Census Catastrophe

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Community Engagement Coordinator
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The assumption that community leaders and caste organizations will generally support the census proves false. A significant number of these groups actively oppose the inclusion of caste data collection, leading to:

*   **Widespread Boycotts:** Communities refuse to participate in the census, resulting in significant undercounting, particularly in regions with strong caste-based identities.
*   **Public Protests:** Large-scale protests erupt, disrupting census operations and generating negative publicity.
*   **Political Opposition:** Opposition parties exploit the controversy, further fueling public unrest and undermining the government's credibility.
*   **Legal Challenges:** Lawsuits are filed challenging the legality of caste data collection, potentially leading to a court-ordered halt to the census.

##### Early Warning Signs
- Key community leaders publicly denounce the inclusion of caste data collection.
- Social media sentiment analysis reveals a significant increase in negative sentiment towards the census.
- Attendance at community consultation meetings is significantly lower than anticipated.

##### Tripwires
- Participation rate in pilot census blocks falls below 70% due to community boycotts.
- Number of protest events related to the census exceeds 10 in a single week.
- Legal challenges are filed against the government challenging the legality of caste data collection.

##### Response Playbook
- Contain: Immediately suspend caste data collection in affected areas and initiate dialogue with community leaders to address their concerns.
- Assess: Conduct a rapid assessment of the reasons for community opposition and identify potential compromises or alternative approaches.
- Respond: Implement targeted communication campaigns to address misinformation and build trust, and consider modifying the caste data collection methodology to address community concerns.


**STOP RULE:** If, after three months of intensive community engagement efforts, significant community resistance persists and the participation rate remains below 75% in key regions, the project will abandon caste data collection altogether.

---

#### FM4 - The Smartphone Shortage Scramble

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Procurement Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The assumption of a stable smartphone supply chain proves false. Unexpected global events disrupt the production and delivery of smartphones, leading to:

*   **Procurement Delays:** The project is unable to procure the required number of smartphones on time, delaying the start of Phase 1 and Phase 2.
*   **Increased Costs:** The price of smartphones skyrockets due to scarcity, exceeding the allocated budget for device procurement by 40%.
*   **Compromised Specifications:** To stay within budget, the project is forced to procure lower-quality smartphones with limited functionality, impacting data collection efficiency and accuracy.
*   **Logistical Chaos:** The delayed and piecemeal delivery of smartphones creates logistical nightmares, disrupting training schedules and field operations.

##### Early Warning Signs
- Smartphone vendors announce production cuts or shipping delays due to supply chain disruptions.
- The price of smartphones on the open market increases by more than 15% within a month.
- The project receives notifications of force majeure from smartphone vendors.

##### Tripwires
- Smartphone delivery is delayed by more than 60 days.
- The cost of smartphones exceeds the budgeted amount by 25%.
- The number of smartphones delivered is less than 75% of the required quantity by the start of Phase 1.

##### Response Playbook
- Contain: Immediately activate alternative procurement channels and explore options for leasing or renting smartphones.
- Assess: Conduct a thorough assessment of the impact of the smartphone shortage on the project timeline and budget.
- Respond: Prioritize smartphone allocation to critical regions and consider extending the data collection period to compensate for the delays.


**STOP RULE:** If the smartphone shortage persists for more than six months and the project is unable to secure an adequate supply of devices, the project will revert to a paper-based data collection methodology in all regions.

---

#### FM5 - The Inter-Departmental Impasse

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Inter-Departmental Liaison
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The assumption of seamless inter-departmental coordination proves false. Bureaucratic hurdles and conflicting priorities hinder effective data sharing and collaboration between government agencies, leading to:

*   **Data Silos:** Critical data from various government databases remains inaccessible to the census project, limiting the ability to validate and enrich census data.
*   **Methodological Inconsistencies:** Different government agencies use different data collection methodologies and definitions, creating inconsistencies and hindering data integration.
*   **Communication Breakdowns:** Lack of clear communication channels and protocols leads to delays in decision-making and coordination, slowing down project progress.
*   **Duplicated Efforts:** Multiple government agencies conduct overlapping data collection activities, wasting resources and creating confusion among the public.

##### Early Warning Signs
- Government agencies fail to respond to data requests within the agreed-upon timeframe.
- Inter-departmental meetings are poorly attended and lack clear outcomes.
- Conflicting data definitions and methodologies are identified across different government databases.

##### Tripwires
- Data requests from the census project are delayed by more than 30 days.
- Inter-departmental meetings are canceled or postponed more than twice in a month.
- Significant discrepancies are identified between census data and data from other government sources.

##### Response Playbook
- Contain: Immediately escalate the coordination issues to senior government officials and seek their intervention.
- Assess: Conduct a thorough review of the inter-departmental coordination mechanisms and identify the root causes of the bottlenecks.
- Respond: Establish clear data sharing agreements and communication protocols, and provide training to government personnel on the importance of inter-departmental collaboration.


**STOP RULE:** If, after three months of intensive efforts to improve inter-departmental coordination, critical data remains inaccessible and significant methodological inconsistencies persist, the project will scale back its data validation and enrichment efforts and rely primarily on data collected directly by enumerators.

---

#### FM6 - The Apathy Avalanche

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Public Awareness Campaign Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The assumption that the public awareness campaign will effectively reach all segments of the population proves false. The campaign fails to resonate with marginalized communities, leading to:

*   **Low Participation Rates:** Response rates in marginalized communities are significantly lower than the national average, resulting in undercounting and inaccurate representation.
*   **Misinformation and Mistrust:** Misinformation about the census spreads rapidly through social media and word-of-mouth, fueling mistrust and discouraging participation.
*   **Community Resistance:** Some communities actively resist the census, viewing it as intrusive or irrelevant to their needs.
*   **Data Bias:** The underrepresentation of marginalized communities in the census data creates a biased picture of the population, undermining the accuracy and fairness of policy decisions.

##### Early Warning Signs
- Website traffic and social media engagement related to the census are significantly lower than anticipated.
- Focus group discussions reveal that marginalized communities are unaware of the census or have negative perceptions of it.
- Community leaders express concerns about the effectiveness of the public awareness campaign.

##### Tripwires
- Response rates in marginalized communities are more than 20% lower than the national average after the first month of Phase 2.
- Social media sentiment analysis reveals a significant increase in negative sentiment towards the census among marginalized communities.
- The number of complaints received from marginalized communities about the census exceeds 500 per week.

##### Response Playbook
- Contain: Immediately refocus the public awareness campaign on marginalized communities, using targeted messaging and culturally appropriate channels.
- Assess: Conduct a rapid assessment of the reasons for the campaign's failure to resonate with marginalized communities and identify potential improvements.
- Respond: Partner with trusted community leaders and organizations to disseminate accurate information and build trust, and consider offering incentives for participation.


**STOP RULE:** If, after three months of targeted outreach efforts, response rates in marginalized communities remain significantly below the national average and widespread mistrust persists, the project will acknowledge the limitations of the census data and adjust policy recommendations accordingly.

---

#### FM7 - The Caste Classification Chaos

- **Archetype**: Market/Human
- **Root Cause**: Assumption A7
- **Owner**: Data Quality & Integrity Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The assumption that enumerators will accurately classify caste proves false. Inconsistent application of caste criteria leads to:

*   **Data Skew:** Misclassification skews caste demographics, rendering data unreliable for policy.
*   **Community Outrage:** Affected communities protest inaccurate representation, damaging trust.
*   **Legal Challenges:** Inaccurate data triggers lawsuits questioning census validity.
*   **Policy Failures:** Skewed data leads to ineffective or discriminatory policies.

##### Early Warning Signs
- Inter-rater reliability scores for caste classification fall below 0.7.
- Complaints from community organizations about misclassification increase.
- Media reports highlight inconsistencies in caste data.

##### Tripwires
- Inter-rater reliability score for caste classification <= 0.6.
- Number of formal complaints from community organizations >= 50 per week.
- Media articles questioning caste data accuracy >= 3 per week.

##### Response Playbook
- Contain: Immediately suspend caste data collection and retrain enumerators.
- Assess: Review classification criteria and identify sources of inconsistency.
- Respond: Revise training materials, clarify criteria, and re-evaluate existing data.


**STOP RULE:** If, after retraining, inter-rater reliability remains below 0.7, caste data collection will be abandoned.

---

#### FM8 - The Server Meltdown Mayhem

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Technology Deployment Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The assumption of resilient infrastructure proves false. Peak data loads overwhelm systems, causing:

*   **Data Loss:** Server crashes result in data loss, requiring costly recovery efforts.
*   **Collection Delays:** System downtime halts enumeration, delaying project completion.
*   **Public Distrust:** Technical failures erode public confidence in census reliability.
*   **Budget Overruns:** Emergency infrastructure upgrades strain financial resources.

##### Early Warning Signs
- Server response times increase by >50% during peak hours.
- Data upload failure rates exceed 5%.
- System downtime occurs more than once per week.

##### Tripwires
- Server response time >= 5 seconds during peak hours.
- Data upload failure rate >= 10%.
- System downtime >= 4 hours per week.

##### Response Playbook
- Contain: Immediately shift data processing to backup servers and implement load balancing.
- Assess: Identify root causes of infrastructure bottlenecks and performance issues.
- Respond: Upgrade server capacity, optimize database performance, and improve network infrastructure.


**STOP RULE:** If critical system downtime exceeds 24 hours despite mitigation efforts, the project will revert to a decentralized data collection and processing model.

---

#### FM9 - The Legal Landmine Lockdown

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Legal & Compliance Advisor
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The assumption of a stable legal framework proves false. Unexpected legal challenges disrupt the census, causing:

*   **Data Collection Halt:** Court orders suspend data collection, delaying project completion.
*   **Legal Costs:** Defending lawsuits drains financial resources, impacting other areas.
*   **Methodology Changes:** Court rulings force changes to data collection methods, requiring costly revisions.
*   **Public Confusion:** Legal uncertainty erodes public trust and participation.

##### Early Warning Signs
- New data privacy laws are enacted that conflict with census procedures.
- Lawsuits are filed challenging the legality of caste data collection.
- Government agencies issue conflicting guidance on data handling.

##### Tripwires
- Court orders halt data collection in >= 3 states.
- Legal costs exceed 10% of the project budget.
- Government agencies issue conflicting data handling guidelines.

##### Response Playbook
- Contain: Immediately comply with court orders and suspend affected activities.
- Assess: Analyze legal challenges and revise procedures to ensure compliance.
- Respond: Engage with legal authorities, communicate changes to the public, and seek legislative clarification.


**STOP RULE:** If a final court ruling invalidates the core methodology of the census, the project will be terminated.
