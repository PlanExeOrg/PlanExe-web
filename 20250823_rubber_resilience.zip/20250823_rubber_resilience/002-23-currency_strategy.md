This plan involves money.

## Currencies

- **USD:** Primary currency for the overall $30 billion program budget and international transactions.
- **BRL:** Local currency for operations in Brazil, particularly for the bio-prospecting and genomic breeding effort.
- **EUR:** Relevant for operations in Eastern Europe (Ukraine, Russia, Poland) related to Russian dandelion cultivation and research.

**Primary currency:** USD

**Currency strategy:** USD is recommended as the primary currency for budgeting and reporting to mitigate risks from currency fluctuations across different regions. Local currencies (BRL, EUR) will be used for local transactions within Brazil and Eastern Europe, respectively. Hedging strategies may be considered to manage exchange rate risks.