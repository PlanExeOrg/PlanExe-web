### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and direction for this large-scale, high-impact, and long-term public-private partnership. Ensures alignment with overall goals and objectives.

**Responsibilities:**

- Approve strategic project plans and budgets exceeding $50 million.
- Monitor overall project progress against strategic goals and KPIs.
- Approve major scope changes or deviations from the strategic plan.
- Oversee strategic risk management and mitigation.
- Resolve strategic-level conflicts and escalate unresolved issues.
- Approve gate funding decisions at Years 3/7/12/18 based on KPI performance.

**Initial Setup Actions:**

- Finalize Terms of Reference and operating procedures.
- Appoint Chair and Vice-Chair.
- Establish meeting schedule and communication protocols.
- Define escalation paths and conflict resolution mechanisms.

**Membership:**

- Senior representatives from public funding agencies
- Senior representatives from private sector partners (OEMs, rubber producers)
- Independent expert in agricultural economics
- Independent expert in plant pathology
- Project Director

**Decision Rights:** Strategic decisions related to project scope, budget (>$50M), timeline, and strategic risk management. Approval of gate funding.

**Decision Mechanism:** Decisions made by majority vote, with the Chair having the tie-breaking vote. Any decision with significant financial implications (>$100M) requires unanimous approval.

**Meeting Cadence:** Quarterly, with ad-hoc meetings as needed for critical decisions.

**Typical Agenda Items:**

- Review of project progress against strategic goals and KPIs.
- Discussion and approval of budget requests exceeding $50 million.
- Review and approval of major scope changes or deviations from the strategic plan.
- Review of strategic risk register and mitigation plans.
- Discussion and resolution of strategic-level conflicts.
- Review of compliance reports and audit findings.
- Gate funding review and approval.

**Escalation Path:** Escalate to the executive leadership of the participating public and private organizations.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Provides centralized operational management, coordination, and support for the project. Ensures efficient execution and adherence to project plans.

**Responsibilities:**

- Develop and maintain project plans, schedules, and budgets (below $50M).
- Monitor day-to-day project activities and track progress against milestones.
- Manage operational risks and implement mitigation plans.
- Coordinate communication and collaboration among project teams.
- Prepare regular progress reports for the Steering Committee.
- Manage project documentation and knowledge sharing.
- Ensure compliance with project policies and procedures.
- Manage contracts and procurement processes (below $10M).

**Initial Setup Actions:**

- Establish PMO structure and staffing.
- Develop project management methodologies and tools.
- Define reporting templates and communication protocols.
- Set up project tracking and monitoring systems.

**Membership:**

- Project Manager
- Project Coordinators (for each major workstream: Breeding, Alternative Rubber, Containment, Smallholder Adoption)
- Financial Analyst
- Risk Manager
- Communications Manager
- Data Manager

**Decision Rights:** Operational decisions related to project execution, budget management (below $50M), and risk mitigation. Contract approvals below $10M.

**Decision Mechanism:** Decisions made by the Project Manager, in consultation with the PMO team. Conflicts escalated to the Project Director.

**Meeting Cadence:** Weekly, with ad-hoc meetings as needed for critical issues.

**Typical Agenda Items:**

- Review of project progress against milestones.
- Discussion of operational risks and mitigation plans.
- Review of budget status and expenditure reports.
- Coordination of communication and collaboration among project teams.
- Review of project documentation and knowledge sharing.
- Action item tracking and follow-up.

**Escalation Path:** Escalate to the Project Director.
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides expert technical guidance and assurance on key project aspects, including breeding, alternative rubber development, and SALB containment.

**Responsibilities:**

- Review and provide feedback on technical plans and proposals.
- Assess the feasibility and effectiveness of technical approaches.
- Identify potential technical risks and recommend mitigation strategies.
- Provide expert advice on emerging technologies and best practices.
- Evaluate the performance of technical teams and contractors.
- Ensure the technical soundness of project deliverables.

**Initial Setup Actions:**

- Identify and recruit qualified technical experts.
- Finalize Terms of Reference and operating procedures.
- Establish meeting schedule and communication protocols.
- Define areas of expertise and responsibilities.

**Membership:**

- Independent experts in plant breeding
- Independent experts in plant pathology
- Independent experts in agronomy
- Independent experts in rubber processing
- Independent experts in supply chain management
- Lead scientists from project research teams

**Decision Rights:** Provides recommendations and guidance on technical matters. Does not have direct decision-making authority, but its advice is highly influential.

**Decision Mechanism:** Decisions made by consensus among the technical experts. Dissenting opinions are documented and presented to the Steering Committee.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for critical technical issues.

**Typical Agenda Items:**

- Review of technical plans and proposals.
- Assessment of the feasibility and effectiveness of technical approaches.
- Identification of potential technical risks and mitigation strategies.
- Discussion of emerging technologies and best practices.
- Evaluation of the performance of technical teams and contractors.
- Review of technical deliverables.

**Escalation Path:** Escalate technical issues to the Project Steering Committee.
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures ethical conduct, regulatory compliance, and responsible use of project resources. Mitigates risks related to corruption, misallocation, and environmental impact.

**Responsibilities:**

- Develop and implement ethics and compliance policies and procedures.
- Monitor compliance with relevant laws, regulations, and ethical standards.
- Investigate allegations of fraud, corruption, and other misconduct.
- Ensure compliance with access-and-benefit-sharing (ABS) agreements.
- Oversee environmental impact assessments and mitigation plans.
- Promote transparency and accountability in project operations.
- Manage the whistleblower mechanism and protect whistleblowers from retaliation.
- Conduct regular audits of financial transactions, procurement processes, and contract management.

**Initial Setup Actions:**

- Finalize Terms of Reference and operating procedures.
- Appoint Ethics and Compliance Officer.
- Establish reporting channels and investigation protocols.
- Develop ethics and compliance training materials.

**Membership:**

- Independent legal expert
- Independent ethics expert
- Independent environmental expert
- Representative from the Internal Audit Department
- Ethics and Compliance Officer
- Representative from smallholder farmer communities

**Decision Rights:** Investigates ethical breaches and compliance violations. Recommends corrective actions and sanctions. Has authority to suspend project activities in cases of serious misconduct.

**Decision Mechanism:** Decisions made by majority vote. The Ethics and Compliance Officer has the tie-breaking vote.

**Meeting Cadence:** Quarterly, with ad-hoc meetings as needed for critical compliance issues.

**Typical Agenda Items:**

- Review of ethics and compliance policies and procedures.
- Discussion of compliance risks and mitigation plans.
- Investigation of allegations of fraud, corruption, and other misconduct.
- Review of environmental impact assessments and mitigation plans.
- Review of whistleblower reports and investigation outcomes.
- Review of audit findings and corrective actions.
- Review of ABS compliance.

**Escalation Path:** Escalate ethical breaches and compliance violations to the Project Steering Committee and, if necessary, to relevant regulatory authorities.
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Ensures effective communication, collaboration, and engagement with key stakeholders, including smallholder farmers, local communities, and environmental groups. Promotes social equity and minimizes potential conflicts.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Conduct regular consultations with key stakeholders.
- Provide information and updates on project progress and activities.
- Address stakeholder concerns and grievances.
- Promote equitable benefit-sharing and community development.
- Facilitate dialogue and collaboration among stakeholders.
- Monitor stakeholder satisfaction and address any issues.
- Ensure smallholder representation in project decision-making processes.

**Initial Setup Actions:**

- Identify key stakeholders and their interests.
- Develop a stakeholder engagement plan.
- Establish communication channels and feedback mechanisms.
- Recruit community liaison officers.

**Membership:**

- Representatives from smallholder farmer communities
- Representatives from local communities
- Representatives from environmental groups
- Community liaison officers
- Communications Manager
- Social Impact Assessment Specialist

**Decision Rights:** Provides recommendations on stakeholder engagement strategies and community development initiatives. Does not have direct decision-making authority, but its advice is highly influential.

**Decision Mechanism:** Decisions made by consensus among the stakeholder representatives. Dissenting opinions are documented and presented to the Project Steering Committee.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for critical stakeholder issues.

**Typical Agenda Items:**

- Review of stakeholder engagement plan.
- Discussion of stakeholder concerns and grievances.
- Review of community development initiatives.
- Review of stakeholder satisfaction surveys.
- Discussion of communication strategies and feedback mechanisms.
- Updates on project progress and activities.

**Escalation Path:** Escalate stakeholder issues to the Project Steering Committee.