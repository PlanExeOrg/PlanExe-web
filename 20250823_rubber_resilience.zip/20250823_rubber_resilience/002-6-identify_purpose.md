**Purpose:** business

**Purpose Detailed:** Large-scale public-private program to mitigate risks in the global natural rubber supply chain through disease containment, crop diversification, and smallholder adoption, aiming for resilient procurement and economic stability.

**Topic:** Global Natural Rubber Supply De-risking Program