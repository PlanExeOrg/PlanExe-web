
## Audit - Corruption Risks

- Bribery of government officials to expedite regulatory approvals (permits for bio-prospecting, cultivation, processing) or to overlook non-compliance with environmental regulations.
- Kickbacks from suppliers of planting materials, equipment, or processing infrastructure in exchange for preferential treatment in procurement processes.
- Conflicts of interest involving project personnel who have undisclosed financial interests in companies benefiting from the program (e.g., alternative rubber processors, OEM offtake partners).
- Nepotism in hiring or contracting, favoring relatives or friends for positions or contracts regardless of qualifications or competitive bids.
- Misuse of confidential information regarding breeding program advancements or alternative rubber commercialization strategies for personal gain or to benefit competing entities.

## Audit - Misallocation Risks

- Inflated invoices or fraudulent expense claims by project personnel or contractors, particularly in areas like travel, accommodation, or research expenses.
- Double-spending or duplicate payments for the same goods or services due to poor record-keeping or inadequate internal controls.
- Inefficient allocation of resources, such as overspending on SALB eradication efforts at the expense of breeding programs or alternative rubber development, hindering long-term resilience.
- Unauthorized use of project assets, such as vehicles, equipment, or facilities, for personal purposes or activities unrelated to the program's objectives.
- Misreporting of progress or results to justify continued funding or to conceal failures in containment, cultivar readiness, or alternative-rubber cost/quality KPIs.

## Audit - Procedures

- Conduct periodic internal audits (e.g., quarterly) of financial transactions, procurement processes, and contract management to detect irregularities and ensure compliance with policies and procedures. Responsibility: Internal Audit Department.
- Implement a robust contract review process with pre-defined approval thresholds for all contracts related to bio-prospecting, breeding, cultivation, processing, and OEM offtake agreements. Responsibility: Legal and Procurement Departments.
- Conduct regular (e.g., annual) external audits of the program's financial statements and performance against KPIs to provide independent assurance of accountability and transparency. Responsibility: Independent Audit Firm.
- Establish a whistleblower mechanism with clear reporting channels and protection against retaliation to encourage the reporting of suspected fraud, corruption, or other misconduct. Responsibility: Ethics and Compliance Officer.
- Perform compliance checks on all access-and-benefit-sharing (ABS) agreements to ensure adherence to legal and ethical obligations related to germplasm access and benefit distribution. Responsibility: Legal Department and ABS Compliance Officer.

## Audit - Transparency Measures

- Establish a public dashboard displaying key project metrics, including budget allocation, progress against milestones, SALB containment rates, cultivar readiness, and alternative-rubber cost/quality KPIs. Responsibility: Program Management Office.
- Publish minutes of steering committee meetings, including decisions related to budget allocation, strategic choices, and risk management, on the project website. Responsibility: Program Management Office.
- Develop and implement a publicly accessible whistleblower policy outlining reporting procedures, confidentiality protections, and investigation protocols. Responsibility: Ethics and Compliance Officer.
- Document and publish the selection criteria and rationale for major decisions, such as the selection of contractors, suppliers, and research partners, on the project website. Responsibility: Procurement and Program Management Office.
- Make relevant project policies and reports, including environmental impact assessments, ABS compliance plans, and audit reports, publicly available on the project website. Responsibility: Program Management Office.