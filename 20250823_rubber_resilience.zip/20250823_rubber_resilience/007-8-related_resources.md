## Suggestion 1 - The Sustainable Natural Rubber Initiative (SNRi)

The Sustainable Natural Rubber Initiative (SNRi) is a multi-stakeholder platform established to improve the socio-economic and environmental performance of the natural rubber value chain. It focuses on promoting sustainable practices among smallholder farmers, enhancing traceability, and fostering collaboration between industry players, governments, and civil society organizations. The initiative operates across Southeast Asia, including Thailand, Indonesia, and Malaysia, and aims to address issues such as deforestation, land grabbing, and labor rights violations in the rubber sector.

### Success Metrics

Increased adoption of sustainable rubber farming practices by smallholder farmers.
Enhanced traceability of natural rubber from plantation to end-product.
Reduced deforestation and land degradation in rubber-producing regions.
Improved socio-economic conditions for rubber farmers and workers.
Increased collaboration and knowledge sharing among stakeholders.

### Risks and Challenges Faced

Resistance from some industry players to adopt sustainable practices.
Difficulty in enforcing sustainable standards across complex supply chains.
Limited resources and capacity among smallholder farmers to implement sustainable practices.
Lack of consistent government policies and regulations to support sustainable rubber production.
Fluctuations in global rubber prices affecting the economic viability of sustainable rubber farming.

### Where to Find More Information

https://www.sustainablenaturalrubber.org/

### Actionable Steps

Contact the SNRi Secretariat through their website to inquire about partnership opportunities and best practices.
Engage with organizations like the World Wildlife Fund (WWF) and the Global Platform for Sustainable Natural Rubber (GPSNR), which are key partners in the SNRi.
Review the SNRi's publications and reports to understand their approach to sustainable rubber production and supply chain management.

### Rationale for Suggestion

The SNRi provides a relevant example of a multi-stakeholder initiative focused on improving the sustainability of the natural rubber industry. While it does not directly address SALB, its approach to promoting sustainable practices among smallholder farmers, enhancing traceability, and fostering collaboration aligns with the goals of the proposed project. The SNRi's experience in Southeast Asia, a major rubber-producing region, offers valuable insights into the challenges and opportunities of promoting sustainable rubber production.
## Suggestion 2 - Rubber Research Institute of India (RRII)

The Rubber Research Institute of India (RRII) is a premier research institution dedicated to advancing rubber cultivation and production in India. RRII conducts research on various aspects of rubber, including breeding, agronomy, pathology, and processing. It has played a crucial role in developing high-yielding, disease-resistant rubber clones and promoting sustainable rubber farming practices among smallholder farmers in India. RRII also provides training and extension services to rubber growers to improve their productivity and livelihoods.

### Success Metrics

Development and release of high-yielding, disease-resistant rubber clones.
Increased rubber productivity among smallholder farmers in India.
Reduced incidence of rubber diseases and pests.
Improved sustainability of rubber farming practices.
Enhanced knowledge and skills of rubber growers through training and extension services.

### Risks and Challenges Faced

Limited funding for research and development.
Difficulty in transferring research findings to smallholder farmers.
Emergence of new rubber diseases and pests.
Climate change impacts on rubber production.
Competition from synthetic rubber.

### Where to Find More Information

https://rubberboard.gov.in/

### Actionable Steps

Contact the Director of RRII to explore potential collaborations on rubber breeding and disease management.
Review RRII's research publications and technical bulletins to understand their approach to rubber cultivation and disease control.
Visit RRII's research facilities and experimental farms to learn about their breeding programs and sustainable farming practices.

### Rationale for Suggestion

The RRII offers a valuable example of a research institution focused on improving rubber cultivation and production. Its expertise in breeding disease-resistant rubber clones and promoting sustainable farming practices is highly relevant to the proposed project. RRII's experience in working with smallholder farmers in India provides insights into the challenges and opportunities of promoting sustainable rubber production in developing countries. The RRII has also worked on SALB resistant varieties, making it a highly relevant reference.
## Suggestion 3 - Bridgestone's Guayule Research and Commercialization Program

Bridgestone Americas is investing significantly in research and development to commercialize Guayule as a sustainable source of natural rubber. Their efforts include cultivating Guayule on a commercial scale in Arizona, developing efficient extraction and processing technologies, and collaborating with farmers and researchers to improve Guayule yields and rubber quality. The goal is to create a domestic, sustainable supply of natural rubber for tire production, reducing reliance on traditional Hevea rubber and mitigating supply chain risks.

### Success Metrics

Establishment of commercial-scale Guayule farms in Arizona.
Development of efficient and sustainable Guayule processing technologies.
Production of high-quality natural rubber from Guayule that meets tire manufacturing standards.
Reduction in Bridgestone's reliance on traditional Hevea rubber.
Creation of a domestic supply chain for natural rubber in the United States.

### Risks and Challenges Faced

Achieving commercially viable Guayule yields.
Developing cost-effective Guayule processing technologies.
Ensuring the quality and consistency of Guayule rubber.
Securing sufficient land and water resources for Guayule cultivation.
Gaining acceptance of Guayule rubber among tire manufacturers and consumers.

### Where to Find More Information

https://www.bridgestoneamericas.com/en/newsroom/press-releases/bridgestone-expands-guayule-research-operations-with-new-arizona-site
https://www.guayulerubber.com/

### Actionable Steps

Contact Bridgestone Americas to inquire about their Guayule research and commercialization program.
Review Bridgestone's publications and presentations on Guayule to understand their approach to cultivation, processing, and product development.
Visit Bridgestone's Guayule research facilities in Arizona to learn about their farming and processing operations.

### Rationale for Suggestion

Bridgestone's Guayule program provides a direct parallel to the alternative rubber component of the proposed project. It demonstrates a large-scale, industry-led effort to commercialize an alternative rubber source. The program's focus on cultivation, processing, and product development offers valuable lessons for establishing a commercial-scale Guayule industry. The fact that it is based in the USA also provides a geographically diverse example.

## Summary

The recommendations provide insights into managing a large-scale, multi-faceted project focused on de-risking the global natural rubber supply chain. The Sustainable Natural Rubber Initiative (SNRi) offers a model for multi-stakeholder collaboration and promoting sustainable practices. The Rubber Research Institute of India (RRII) provides expertise in breeding disease-resistant rubber clones and working with smallholder farmers. Bridgestone's Guayule program demonstrates a commercial approach to developing alternative rubber sources. Collectively, these projects offer valuable lessons for the proposed project.