This plan implies one or more physical locations.

## Requirements for physical locations

- Suitable climate for Hevea (rubber trees) cultivation
- Arid zones suitable for Guayule cultivation
- Temperate climates suitable for Russian dandelion cultivation
- Access to smallholder farming communities
- Proximity to research institutions and processing facilities
- Compliance with access-and-benefit-sharing agreements for bio-prospecting

## Location 1
Brazil

Amazon Rainforest Region

Research stations and rubber plantations in the Amazon

**Rationale**: Brazil, particularly the Amazon region, is a major rubber-producing area and a center for bio-prospecting. It is crucial for the Brazil-led bio-prospecting and genomic breeding effort. It also has existing infrastructure and expertise in rubber cultivation.

## Location 2
Southwest USA

Arizona, New Mexico, Texas

Agricultural research facilities and arid lands

**Rationale**: The arid climate of the Southwest USA is ideal for Guayule cultivation. Establishing commercial-scale Guayule production in this region diversifies the rubber supply chain and reduces dependence on Hevea.

## Location 3
Eastern Europe

Ukraine, Russia, Poland

Agricultural research facilities and temperate farmlands

**Rationale**: The temperate climate of Eastern Europe is suitable for Russian dandelion cultivation. Establishing commercial-scale Russian dandelion production in this region diversifies the rubber supply chain and reduces dependence on Hevea.

## Location Summary
The plan requires locations in Brazil for Hevea breeding, the Southwest USA for Guayule cultivation, and Eastern Europe for Russian dandelion cultivation. These locations support the plan's goals of disease containment, crop diversification, and resilient procurement.