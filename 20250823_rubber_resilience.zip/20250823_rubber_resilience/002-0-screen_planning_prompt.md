**Verdict:** 🟢 USABLE

**Rationale:** This prompt describes a concrete, actionable project with specific details about budget, timeline, deliverables, and success metrics. It provides enough information to generate a multi-step plan for de-risking the global natural rubber supply.