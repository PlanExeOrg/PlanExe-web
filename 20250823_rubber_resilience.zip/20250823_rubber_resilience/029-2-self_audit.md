Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 14 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 5 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The project focuses on disease containment, crop diversification, and smallholder adoption, which are all within the realm of known physics and biology. No mention of FTL, perpetual motion, or similar concepts.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan combines novel elements (product + market + tech/process + policy) without evidence at comparable scale. The plan integrates bio-prospecting, genomic breeding, and commercializing alternative rubber sources, representing a "groundbreaking endeavor" lacking independent validation.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: Project Lead / Deliverable: Validation Report / Date: 2027-01-01.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because no business-level mechanism-of-action is defined for the buzzwords. The plan mentions "resilient procurement" and "economic stability" as goals, but lacks a clear inputs→process→customer value chain, owner, and measurable outcomes for these strategic concepts.

**Mitigation**: Project Lead: Produce one-pagers for "resilient procurement" and "economic stability", defining value hypotheses, success metrics, owners, and decision hooks. Due: 2024-08-09.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because while the plan identifies several risks (regulatory, technical, financial, etc.), it doesn't explicitly analyze cascades or second-order effects. The plan mentions "proactive risk management strategies identified", but lacks detailed cascade mapping.

**Mitigation**: Risk and Compliance Officer: Conduct a workshop to map risk cascades (e.g., permit delay → financial penalties → budget shortfall) and identify controls. Due: 2024-08-09.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions "Regulatory and permitting delays" as a key risk, but lacks a detailed assessment of specific permits required, timelines, and costs. The plan needs a comprehensive regulatory due diligence assessment.

**Mitigation**: Regulatory Compliance Team: Create a permit/approval matrix with lead times from authoritative sources (e.g., regulatory agencies) for each jurisdiction. Due: 2024-08-09.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because committed sources/term sheets are absent. The plan mentions a "$30 billion public-private program" but lacks details on funding sources, draw schedules, covenants, or runway length. The plan needs a dated financing plan listing sources/status.

**Mitigation**: Finance Team: Develop a detailed financing plan listing funding sources (status, draw schedule, covenants) and a NO-GO on missed financing gates. Due: 2024-08-09.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks scale-appropriate benchmarks for fit-out and opex. The plan mentions a "$30 billion investment" over 25 years, but lacks per-area cost breakdowns (e.g., cost per m² for facilities) or vendor quotes.

**Mitigation**: Finance Team: Benchmark facility fit-out and operating costs per m² against ≥3 comparable projects. Adjust budget or de-scope by 2024-08-09.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections as single numbers without ranges or alternative scenarios. For example, the goal is to "de-risk the entire global natural rubber supply chain over 25 years with a $30 billion investment."

**Mitigation**: Finance Team: Conduct a sensitivity analysis for the $30 billion investment projection, including best-case, worst-case, and base-case scenarios. Due: 2024-08-09.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because core components lack engineering artifacts. The plan mentions "SALB Containment Protocol Enforcement" and "Hevea Breeding Program Scope" but lacks technical specifications, interface definitions, test plans, and integration maps for these critical components.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for the SALB Containment Protocol and Hevea Breeding Program. Due: 2024-08-09.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes critical claims without verifiable artifacts. For example, the plan states, "Establish a globally adopted SALB Containment Protocol," but lacks a draft protocol document, link, or ID to verify its existence or feasibility.

**Mitigation**: Containment Protocol Coordinator: Produce a draft of the SALB Containment Protocol, including key requirements and enforcement mechanisms, by 2024-08-09.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because a major deliverable, 'a globally adopted SALB Containment Protocol', is mentioned without specific, verifiable qualities. The plan states, "Establish a globally adopted SALB Containment Protocol," but lacks defined acceptance criteria.

**Mitigation**: Containment Protocol Coordinator: Define SMART acceptance criteria for the SALB Containment Protocol, including a KPI for adoption rate (e.g., 80% adoption by participating countries within 5 years). Due: 2024-08-09.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'Mobile SALB detection units'. This feature does not appear to directly support the core project goals of disease containment, crop diversification, and smallholder adoption. The plan lacks a benefit case.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of 'Mobile SALB detection units', complete with a KPI, owner, and estimated cost, or move the feature to the project backlog. Due: 2024-08-09.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a 'Hevea Breeding Program Lead' to deliver SALB-resistant cultivars. This role requires deep expertise in Hevea genetics, bio-prospecting, and genomic sequencing, making it both critical and likely difficult to fill.

**Mitigation**: HR Team: Validate the talent market for Hevea breeding experts with bio-prospecting and genomic sequencing experience. Deliverable: Talent Landscape Assessment. Date: 2024-08-09.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because legality is unclear. The plan lists permits (bio-prospecting, breeding, cultivation, processing, environmental) but lacks a regulatory matrix (authority, artifact, lead time, predecessors) or a fatal-flaw analysis. It needs a comprehensive regulatory due diligence assessment.

**Mitigation**: Regulatory Compliance Team: Create a regulatory matrix identifying authorities, required artifacts, lead times, and predecessors for each permit in each jurisdiction. Due: 2024-08-09.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan lacks a comprehensive operational sustainability plan. While it mentions "gated funding", it doesn't detail long-term funding sources, maintenance schedules, succession planning, or technology roadmaps. The plan needs a sustainability plan.

**Mitigation**: Project Team: Develop an operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms. Due: 2024-08-09.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "permits" but lacks specifics on zoning, occupancy, fire load, noise, or structural limits. The plan needs a fatal-flaw screen with authorities/experts to confirm viability. It is not about real-world proof.

**Mitigation**: Project Team: Perform a fatal-flaw screen with relevant authorities to identify potential hard constraints (zoning, occupancy, fire load, etc.). Deliverable: Summary report. Date: 2024-08-09.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions a "Clean Plant Network Governance" but lacks details on redundancy or failover mechanisms for this critical dependency. The plan does not describe backup propagation centers or alternative distribution channels.

**Mitigation**: Clean Plant Network Governance Team: Develop a business continuity plan for the Clean Plant Network, including backup propagation sites and alternative distribution channels. Due: 2024-08-09.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the Finance Department is incentivized by budget adherence, while the Hevea Breeding Program is incentivized by long-term cultivar development, creating a conflict over resource allocation. The plan does not address this conflict.

**Mitigation**: Project Lead: Create a shared OKR that aligns the Finance Department and the Hevea Breeding Program on a common outcome, such as "Deliver 3 SALB-resistant cultivars within budget". Due: 2024-08-09.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Lead: Establish a monthly review with a KPI dashboard and a lightweight change board to manage scope and budget. Due: 2024-08-09.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because ≥3 High risks are strongly coupled. Regulatory hurdles (Risk 1), technical challenges (Risk 2), and smallholder adoption (Risk 5) are tightly linked. Failure in one cascades to others, undermining the project's goals.

**Mitigation**: Project Lead: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Due: 2024-08-09.