**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic oversight and approval at a higher level.
Negative Consequences: Potential for budget overruns, scope creep, and misalignment with strategic objectives.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: Materialization of a critical risk threatens project success and requires strategic-level intervention and resource allocation.
Negative Consequences: Project delays, cost increases, failure to achieve project goals, and reputational damage.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Director
Approval Process: Project Director Review and Decision
Rationale: Inability of the PMO to reach consensus on a key operational decision necessitates resolution by a higher authority to maintain project momentum.
Negative Consequences: Delays in procurement, potential selection of a suboptimal vendor, and disruption to project timelines.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Significant changes to the project scope impact strategic objectives, budget, and timelines, requiring approval from the governing body.
Negative Consequences: Misalignment with strategic goals, budget overruns, project delays, and failure to deliver intended benefits.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation
Rationale: Allegations of unethical conduct require independent review and investigation to ensure compliance with ethical standards and protect project integrity.
Negative Consequences: Legal penalties, reputational damage, loss of stakeholder trust, and project disruption.

**Technical Impasse on SALB Containment Strategy**
Escalation Level: Technical Advisory Group
Approval Process: Technical Advisory Group Review and Recommendation to Steering Committee
Rationale: Disagreement among technical experts on the optimal SALB containment strategy requires external guidance and a consensus-based recommendation.
Negative Consequences: Ineffective disease containment, increased risk of SALB spread, and potential failure to achieve project goals.

**Stakeholder Grievance Regarding Smallholder Compensation**
Escalation Level: Stakeholder Engagement Group
Approval Process: Stakeholder Engagement Group Review and Recommendation to Steering Committee
Rationale: Concerns raised by stakeholders, particularly smallholder farmers, regarding compensation or project impacts require careful consideration and resolution to maintain community support.
Negative Consequences: Social unrest, project delays, reputational damage, and failure to achieve smallholder adoption goals.