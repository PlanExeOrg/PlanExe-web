## Primary Decisions
The vital few decisions that have the most impact.


The 'Critical' and 'High' impact levers address the fundamental project tensions of legal defensibility vs. family harmony, long-term preservation vs. initial cost, and public acceptance vs. artistic vision. These levers govern the project's core risks and opportunities. A key strategic dimension that could be missing is a more detailed plan for managing potential negative press or ethical objections from the public beyond the family.

### Decision 1: Legal Authorization Strategy
**Lever ID:** `e7588f86-7ca2-41c9-ae66-6b939026a083`

**The Core Decision:** The Legal Authorization Strategy lever focuses on securing the necessary legal permissions for the post-mortem skeletal preparation and public display. It controls the legal framework surrounding the project, aiming to ensure the client's wishes are honored and protected from legal challenges. Success is measured by the robustness of the legal documentation, the likelihood of withstanding family disputes, and the clarity of authority granted to the estate executor or trustee.

**Why It Matters:** A robust legal strategy minimizes the risk of family challenges and ensures the project's execution according to the deceased's wishes. However, aggressive legal tactics could strain family relationships and lead to negative publicity, while a weak legal foundation leaves the project vulnerable to being blocked or altered after death.

**Strategic Choices:**

1. Secure comprehensive legal authorization through a detailed will and advance directives, including specific clauses addressing potential objections and appointing an independent executor with explicit authority over body disposition
2. Pursue a court order during the client's lifetime affirming the legality and enforceability of the post-mortem wishes, establishing a legal precedent that binds the estate and minimizes the likelihood of successful challenges
3. Establish a legal framework that treats the skeleton as intellectual property, assigning ownership to a trust or institution that can then enforce the display rights, circumventing direct family control over the physical remains

**Trade-Off / Risk:** Prioritizing legal defensibility risks alienating family; the options fail to address proactive reconciliation with family members who may object to the plan.

**Strategic Connections:**

**Synergy:** This lever strongly synergizes with `Estate Executor Nomination` and `Trust Structure Design`. A well-defined legal strategy empowers the executor/trustee to act decisively, while a robust trust structure provides the financial and legal means to execute the plan, reinforcing the legal authorization.

**Conflict:** This lever can conflict with `Family Communication Approach`. A highly assertive legal strategy might alienate family members, increasing the likelihood of legal challenges, even if the legal documentation is strong. Balancing legal rigor with family sensitivity is crucial.

**Justification:** *Critical*, Critical because its synergy and conflict texts show it's a central hub connecting estate, family, and trust. It controls the project's core risk/reward profile by determining legal defensibility against family challenges.

### Decision 2: Family Communication Approach
**Lever ID:** `05a0d39f-5883-47a4-8a13-0169e07e0e37`

**The Core Decision:** The Family Communication Approach lever addresses how the client's wishes are communicated to their family. It controls the narrative and the process of informing family members, aiming to minimize conflict and gain their understanding or acceptance. Success is measured by the level of family support, the reduction of potential legal challenges, and the overall emotional well-being of the family during the process.

**Why It Matters:** Open and empathetic communication with family members can foster understanding and reduce the likelihood of legal challenges. However, it also carries the risk of encountering strong opposition that could derail the project or cause emotional distress to the client. A lack of communication, on the other hand, almost guarantees conflict.

**Strategic Choices:**

1. Engage a grief counselor or mediator to facilitate structured conversations with immediate family, focusing on understanding their concerns and finding common ground while clearly communicating the client's wishes and motivations
2. Create a video message from the client explaining the personal significance of the project and expressing their hopes for its impact, to be shared with family members after death as a means of conveying their intentions directly
3. Offer family members a role in the project's execution, such as selecting the display case design or contributing to the public-facing narrative, to foster a sense of involvement and ownership that mitigates potential resistance

**Trade-Off / Risk:** Emphasizing family harmony may compromise the client's autonomy; the options don't account for scenarios where family objections remain irreconcilable.

**Strategic Connections:**

**Synergy:** This lever synergizes with `Display Narrative Framing`. A well-crafted narrative, communicated effectively to the family, can help them understand the client's motivations and appreciate the project's significance, fostering acceptance. It also helps with `Legal Authorization Strategy` by reducing the likelihood of legal challenges.

**Conflict:** This lever can conflict with `Legal Authorization Strategy`. A strong legal stance, while protective, might be perceived as aggressive by the family, hindering open communication and potentially escalating conflict. Balancing legal protection with family sensitivity is key.

**Justification:** *High*, High because it directly impacts the likelihood of legal challenges and the emotional well-being of the family. It balances the client's wishes with potential family objections, influencing the project's overall success.

### Decision 3: Display Narrative Framing
**Lever ID:** `51338da9-3a7e-45be-aa23-bceb322c42a5`

**The Core Decision:** The Display Narrative Framing lever focuses on shaping the public perception of the skeletal display. It controls the message and context surrounding the display, aiming to preempt negative reactions and foster understanding. Success is measured by positive media coverage, public acceptance, and the absence of ethical backlash or controversy.

**Why It Matters:** A well-crafted public narrative can shape public perception and minimize negative reactions to the unconventional display. However, an overly sensationalized narrative could attract unwanted attention and ethical scrutiny, while a bland or apologetic narrative may fail to resonate with audiences or justify the project's existence.

**Strategic Choices:**

1. Position the display as a unique form of personal expression and memorialization, emphasizing the client's lifelong fascination with zombies and their desire to leave a lasting legacy that challenges conventional notions of death and remembrance
2. Frame the project as an educational opportunity to explore human anatomy, skeletal structure, and the process of decomposition, partnering with educational institutions to develop accompanying materials and programming
3. Curate the display as a contemporary art installation, inviting art critics and curators to interpret its artistic merit and cultural significance, thereby legitimizing the project within the art world and attracting a discerning audience

**Trade-Off / Risk:** Controlling the narrative risks appearing manipulative; the options overlook the value of open dialogue and diverse interpretations of the display.

**Strategic Connections:**

**Synergy:** This lever synergizes with `Host Institution Selection`. Choosing a host institution that aligns with the chosen narrative framing (e.g., an art museum for an artistic interpretation) enhances the narrative's credibility and reach. It also supports `Family Communication Approach` by providing a framework for explaining the project.

**Conflict:** This lever can conflict with `Family Communication Approach`. A narrative that is too focused on the client's personal desires, without acknowledging potential family concerns, could alienate family members and lead to resistance.

**Justification:** *High*, High because it shapes public perception and minimizes negative reactions. It connects to family communication and host institution selection, influencing the project's acceptance and long-term viability.

### Decision 4: Host Institution Selection
**Lever ID:** `465e42fa-213e-4ba6-b383-560b4a67d96b`

**The Core Decision:** The Host Institution Selection lever focuses on identifying and securing a suitable venue for the permanent public display of the skeleton. It controls the location and context of the display, aiming to ensure long-term preservation and public accessibility. Success is measured by the institution's willingness to host the display, its ability to provide adequate preservation conditions, and its alignment with the project's goals.

**Why It Matters:** Securing a reputable host institution ensures the long-term preservation and public accessibility of the display. However, institutions may have concerns about the ethical implications or potential controversy associated with the project, while a lack of institutional support leaves the display vulnerable to neglect or eventual removal.

**Strategic Choices:**

1. Target niche museums or galleries specializing in medical oddities, anatomical specimens, or unconventional art, as they may be more receptive to the project's unique nature and have experience managing similar displays
2. Partner with a university or research institution with a strong anatomy or forensic science program, offering the skeleton as a valuable teaching tool and research resource in exchange for long-term preservation and display
3. Establish a private foundation or trust dedicated to the display's upkeep and promotion, allowing for greater control over its presentation and ensuring its long-term financial sustainability independent of institutional priorities

**Trade-Off / Risk:** Prioritizing institutional acceptance may dilute the client's original vision; the options don't consider the trade-off between control and long-term viability.

**Strategic Connections:**

**Synergy:** This lever synergizes with `Long-Term Preservation Strategy`. Selecting an institution with established preservation protocols and resources ensures the long-term viability of the display. It also works with `Display Narrative Framing` to ensure the institution is aligned with the project's message.

**Conflict:** This lever can conflict with `Display Case Security Measures`. Institutions with limited security budgets may be less willing to host the display, requiring a trade-off between institutional prestige and security.

**Justification:** *Critical*, Critical because it ensures long-term preservation and public accessibility. It's a central hub connecting preservation, narrative, and security, directly impacting the project's legacy and visibility.

### Decision 5: Trust Structure Design
**Lever ID:** `fc87752b-e419-421b-87e1-a12d5598da3f`

**The Core Decision:** The Trust Structure Design lever establishes the financial framework for the project's long-term sustainability. It controls how funds are managed and disbursed, aiming to ensure sufficient resources are available for maintenance, preservation, and potential legal challenges. Success is measured by the trust's ability to generate income, protect assets, and fulfill its intended purpose over time. The trust must be legally sound and financially secure.

**Why It Matters:** The structure of the trust determines its ability to withstand legal challenges and ensure long-term funding. A poorly designed trust could be vulnerable to dissolution by family members or fail to generate sufficient income to cover ongoing preservation costs. A robust trust provides financial security and protects the project's integrity.

**Strategic Choices:**

1. Establish an irrevocable charitable trust with a board of directors composed of legal, financial, and art professionals, ensuring independent oversight and long-term stability.
2. Create a spendthrift trust with specific provisions preventing beneficiaries from accessing the principal, guaranteeing funds are available solely for the skeleton's maintenance and display.
3. Structure a hybrid trust combining elements of charitable and spendthrift trusts, allowing for limited distributions to family members while prioritizing the project's long-term funding needs.

**Trade-Off / Risk:** A weak trust structure invites legal challenges and funding shortfalls, but these options overlook the tax implications of different trust types on the estate and beneficiaries.

**Strategic Connections:**

**Synergy:** This lever strongly synergizes with `Long-Term Preservation Strategy`, providing the financial backing needed for its implementation. It also works with `Host Institution Selection`, as the trust can provide financial incentives for institutions to host the display.

**Conflict:** The trust structure can conflict with `Family Communication Approach` if family members feel excluded from its management or benefit. It also potentially conflicts with `Estate Executor Nomination` if the executor has conflicting priorities regarding the estate's assets.

**Justification:** *Critical*, Critical because it establishes the financial framework for long-term sustainability. It connects to preservation and host institution, ensuring resources are available for maintenance and potential legal challenges.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Biohazard Mitigation Protocol
**Lever ID:** `263bf58e-00f8-4f97-b017-77444519c5ce`

**The Core Decision:** The Biohazard Mitigation Protocol lever focuses on ensuring the safe handling of the body during the decomposition and skeletal preparation process. It controls the safety measures and procedures implemented, aiming to minimize the risk of biohazard exposure. Success is measured by adherence to safety regulations, the absence of biohazard incidents, and the protection of personnel involved.

**Why It Matters:** A comprehensive biohazard mitigation protocol protects the health and safety of personnel involved in the skeletal preparation process and ensures compliance with relevant regulations. However, overly stringent protocols can significantly increase costs and extend the timeline, while inadequate measures expose workers to potential health risks and legal liabilities.

**Strategic Choices:**

1. Implement a multi-layered biohazard control system, including enhanced PPE, negative-pressure ventilation in the mortuary facility, and rigorous surface decontamination procedures validated by regular environmental monitoring
2. Partner with a mortuary facility specializing in high-risk biohazard cases, ensuring access to specialized equipment and trained personnel experienced in handling potentially infectious remains
3. Incorporate advanced decomposition techniques, such as enzymatic digestion or chemical maceration, to accelerate tissue removal and reduce the duration of biohazard exposure, while carefully managing chemical waste disposal

**Trade-Off / Risk:** Focusing on safety may inflate costs and preparation time; the options neglect the trade-off between risk reduction and budgetary constraints.

**Strategic Connections:**

**Synergy:** This lever has a strong synergy with `Mortuary Vendor Diligence`. Selecting a mortuary vendor with robust biohazard protocols and specialized equipment directly enhances the effectiveness of the mitigation protocol. It also supports `Osteological Scope Definition` by ensuring a safe working environment.

**Conflict:** This lever can conflict with `Mortuary Vendor Diligence`. Mortuary vendors with the highest level of biohazard mitigation may be more expensive or less willing to accommodate the unusual nature of the request, creating a trade-off between safety and feasibility.

**Justification:** *Medium*, Medium because while essential for safety and compliance, its impact is largely contained within the mortuary phase. It has strong synergies with vendor selection but doesn't directly govern the core strategic tensions.

### Decision 7: Long-Term Preservation Strategy
**Lever ID:** `a2fd1f63-a8a4-4ba5-a2c8-639042dc753f`

**The Core Decision:** The Long-Term Preservation Strategy ensures the skeleton's integrity and display for decades. It controls the resources and methods used to combat degradation. Objectives include maintaining stable environmental conditions, securing funding for ongoing maintenance, and establishing conservation protocols. Success is measured by the skeleton's condition over time, the availability of funds, and the adherence to conservation best practices. This lever directly impacts the longevity and public perception of the project.

**Why It Matters:** A robust preservation strategy ensures the long-term integrity and stability of the skeleton and display case. However, advanced preservation techniques can be expensive and require specialized expertise, while inadequate measures risk deterioration and eventual loss of the display.

**Strategic Choices:**

1. Implement a museum-grade environmental control system within the display case, maintaining stable temperature, humidity, and UV light levels to minimize skeletal degradation and prevent microbial growth
2. Establish a dedicated endowment or trust fund to cover ongoing maintenance costs, including regular inspections, cleaning, repairs, and potential replacement of display case components
3. Develop a detailed conservation plan with a qualified conservator, outlining specific procedures for handling, cleaning, and repairing the skeleton, as well as protocols for addressing potential damage or deterioration over time

**Trade-Off / Risk:** Focusing on preservation costs may limit artistic expression; the options neglect the potential for creative display solutions that enhance longevity.

**Strategic Connections:**

**Synergy:** This lever strongly synergizes with `Host Institution Selection` by ensuring the chosen institution has the resources and commitment to uphold the preservation strategy. It also works with `Trust Structure Design` to guarantee funds are available for long-term care.

**Conflict:** A robust preservation strategy may conflict with `Osteological Scope Definition` if the chosen preparation methods are too aggressive or damaging for long-term stability. It also potentially conflicts with `Display Case Security Measures` if security protocols interfere with maintenance.

**Justification:** *High*, High because it ensures the skeleton's integrity and display for decades. It connects to host institution and trust design, directly impacting the project's longevity and public perception.

### Decision 8: Skeletal Pose Design
**Lever ID:** `c5151f9c-1829-41b9-83e3-b1d5340888f8`

**The Core Decision:** The Skeletal Pose Design lever defines the aesthetic and narrative impact of the displayed skeleton. It controls the final arrangement of the bones, aiming to evoke a zombie-like stance while maintaining anatomical plausibility and artistic merit. Success is measured by public engagement, critical reception, and the pose's ability to convey the intended message. The pose should be both captivating and respectful.

**Why It Matters:** The chosen pose significantly impacts the display's aesthetic and public reception. A more dramatic or overtly 'zombie-like' pose might attract attention but could also alienate potential host institutions or trigger ethical concerns. A more restrained and dignified pose might be less sensational but more palatable for a wider audience and easier to defend as artistic expression.

**Strategic Choices:**

1. Commission a series of maquettes from a sculptor to explore variations on the zombie theme, selecting a pose that balances anatomical accuracy with artistic expression and testing public reaction through online surveys.
2. Collaborate with a forensic anthropologist to develop a pose that reflects realistic post-mortem changes and decomposition processes, emphasizing the scientific and educational aspects of the display.
3. Adapt a pose from a classic work of art or literature featuring death or resurrection, providing a recognizable cultural reference point and grounding the display in established artistic traditions.

**Trade-Off / Risk:** A provocative pose risks alienating institutions and the public, while a conservative one might diminish the artistic impact, and the options fail to address the cost implications of complex poses.

**Strategic Connections:**

**Synergy:** This lever has strong synergy with `Display Narrative Framing`, as the pose should visually reinforce the chosen narrative. It also works well with `Osteological Scope Definition`, ensuring the level of anatomical detail supports the chosen pose.

**Conflict:** The pose design can conflict with `Legal Authorization Strategy` if it's deemed too offensive or disturbing, potentially leading to legal challenges. It also conflicts with `Family Communication Approach` if the pose is perceived as disrespectful by family members.

**Justification:** *Medium*, Medium because it impacts aesthetic and public reception, but its influence is less systemic than other levers. It synergizes with narrative framing but has limited impact on legal or financial aspects.

### Decision 9: Osteological Scope Definition
**Lever ID:** `964d64fb-b2a3-4121-9f55-c2350d31a76f`

**The Core Decision:** The Osteological Scope Definition lever determines the level of detail and accuracy in the skeletal preparation. It controls the cleaning, articulation, and restoration processes, aiming to balance scientific rigor with artistic expression and budgetary constraints. Success is measured by the anatomical correctness, aesthetic appeal, and long-term stability of the prepared skeleton. The scope should align with the project's overall goals.

**Why It Matters:** The level of detail and artistry in the skeletal preparation directly affects the project's cost and timeline. A basic articulation might be more affordable but less visually compelling. An elaborate, highly detailed preparation could be more impressive but also more time-consuming and expensive, potentially exceeding the budget.

**Strategic Choices:**

1. Prioritize anatomical accuracy and completeness, focusing on meticulous cleaning and articulation of all bones, even small or fragile ones, to create a scientifically accurate representation.
2. Emphasize artistic expression and visual impact, selectively highlighting certain bones or features to enhance the zombie-like aesthetic, while simplifying or omitting less visible elements.
3. Adopt a minimalist approach, focusing on the essential skeletal elements required to convey the desired pose and narrative, minimizing preparation time and cost without sacrificing overall impact.

**Trade-Off / Risk:** Detailed osteological work increases cost and time, while a minimalist approach might compromise the artistic vision, and the options don't consider the osteologist's existing skill set.

**Strategic Connections:**

**Synergy:** This lever synergizes with `Skeletal Pose Design`, as the level of detail should complement the chosen pose and enhance its impact. It also works with `Biohazard Mitigation Protocol`, ensuring the preparation process adheres to safety standards.

**Conflict:** A highly detailed scope can conflict with `Mortuary Vendor Diligence` if few vendors possess the necessary expertise or facilities. It also potentially conflicts with `Long-Term Preservation Strategy` if aggressive preparation techniques compromise the skeleton's long-term stability.

**Justification:** *Medium*, Medium because it determines the level of detail in skeletal preparation, impacting cost and timeline. It synergizes with pose design but has limited influence on legal or ethical considerations.

### Decision 10: Mortuary Vendor Diligence
**Lever ID:** `fa9bc636-de31-4bf2-bc6b-9c765c79b4a2`

**The Core Decision:** The Mortuary Vendor Diligence lever ensures the selection of a qualified and ethical facility for handling the body and preparing the skeleton. It controls the vendor selection process, aiming to minimize biohazard risks and ensure compliance with legal and ethical standards. Success is measured by the vendor's credentials, safety record, and adherence to the established biohazard mitigation protocol. Due diligence is crucial for risk management.

**Why It Matters:** The selection of a mortuary vendor impacts biohazard safety and legal compliance. A less reputable vendor might cut corners on safety protocols or lack the necessary licenses and permits, exposing the project to legal and ethical risks. A highly reputable vendor ensures adherence to all regulations and minimizes the risk of biohazard incidents.

**Strategic Choices:**

1. Conduct thorough background checks and site visits to multiple mortuary facilities, verifying their licenses, safety records, and experience handling biohazardous materials.
2. Require the mortuary vendor to provide a detailed written protocol outlining their biohazard management procedures, including PPE specifications, waste disposal methods, and emergency response plans.
3. Partner with a university-affiliated mortuary or forensic science center, leveraging their expertise and resources to ensure the highest standards of safety and ethical conduct.

**Trade-Off / Risk:** Thorough vendor diligence adds time and cost, while insufficient vetting increases biohazard and legal risks, and the options don't address the vendor's capacity to handle the skeletal preparation timeline.

**Strategic Connections:**

**Synergy:** This lever strongly synergizes with `Biohazard Mitigation Protocol`, as the vendor must be capable of implementing the protocol effectively. It also works with `Legal Authorization Strategy`, ensuring the vendor complies with all relevant laws and regulations.

**Conflict:** Stringent vendor diligence can conflict with `Osteological Scope Definition` if few vendors can meet the required standards for detailed preparation. It also potentially conflicts with `Budget` if highly qualified vendors command premium prices.

**Justification:** *Low*, Low because while important for risk management, its impact is primarily operational. It supports biohazard mitigation but doesn't directly address the core strategic tensions of the project.

### Decision 11: Display Case Security Measures
**Lever ID:** `ae12ccc2-d9d0-4098-a116-e40dcb6944d4`

**The Core Decision:** This lever focuses on safeguarding the skeletal display from theft or vandalism. It controls the level of security integrated into the display case, ranging from passive measures to advanced surveillance systems or even a self-destruct mechanism. The objective is to protect the integrity of the display and honor the client's wishes. Success is measured by the absence of security breaches, the longevity of the display, and the minimization of potential damage or loss.

**Why It Matters:** The level of security implemented in the display case affects the risk of theft or vandalism. Minimal security measures might be more cost-effective but leave the skeleton vulnerable to damage or loss. Robust security features provide greater protection but could also increase the display case's cost and complexity.

**Strategic Choices:**

1. Integrate a multi-layered security system into the display case, including reinforced glass, motion sensors, alarms, and video surveillance, to deter and detect unauthorized access.
2. Employ a passive security approach, relying on the host institution's existing security measures and the display case's inherent weight and size to prevent theft or vandalism.
3. Incorporate a self-destruct mechanism into the display case, designed to render the skeleton unrecoverable in the event of a break-in, prioritizing the project's artistic integrity over the skeleton's physical preservation.

**Trade-Off / Risk:** High security adds cost and complexity, while minimal security increases the risk of theft or vandalism, and the options don't consider the aesthetic impact of visible security features.

**Strategic Connections:**

**Synergy:** Strong security measures enhance the `Host Institution Selection` by making the display more attractive to risk-averse institutions. It also supports the `Long-Term Preservation Strategy` by preventing damage that would require costly restoration.

**Conflict:** High-end security features increase the overall project cost, potentially conflicting with the `Trust Structure Design` if the allocated budget is insufficient. A self-destruct mechanism directly conflicts with the goal of long-term preservation.

**Justification:** *Low*, Low because it's a tactical consideration focused on preventing theft or vandalism. While it enhances host institution selection, it doesn't address the project's fundamental strategic challenges.

### Decision 12: Estate Executor Nomination
**Lever ID:** `822e9fd2-8053-40dc-a203-57b060d151ae`

**The Core Decision:** This lever determines who will manage the estate and ensure the project's execution after death. It controls the choice of executor, ranging from a professional trust company to a close friend or a co-executor arrangement. The objective is to ensure the client's wishes are carried out effectively and impartially. Success is measured by the smooth administration of the estate, the absence of legal challenges, and the faithful execution of the project plan.

**Why It Matters:** The choice of executor directly impacts the execution of the will and the handling of the body. A sympathetic executor can facilitate the process and mediate family disputes, while a hostile or indifferent one can obstruct the project, leading to legal battles and delays. The executor's competence in managing complex estates and navigating legal challenges is crucial.

**Strategic Choices:**

1. Nominate a professional trust company with experience in handling complex estates and unconventional requests, ensuring impartial execution and minimizing family influence.
2. Appoint a close friend or confidant who deeply understands and supports the client's vision, empowering them to advocate for the project against potential family objections.
3. Establish a co-executor arrangement, combining a family member with a neutral third party, balancing familial representation with professional oversight.

**Trade-Off / Risk:** Selecting an executor balances loyalty to the client's vision with the practical need for impartiality, but it does not address the executor's potential lack of expertise in biohazard management.

**Strategic Connections:**

**Synergy:** A well-chosen executor, especially a professional, can greatly facilitate the `Legal Authorization Strategy` by ensuring all legal requirements are met. They can also work closely with the `Trust Structure Design` to manage funds effectively.

**Conflict:** Appointing a close friend as executor may create conflict with the `Family Communication Approach`, especially if family members disapprove of the project. This could also undermine the `Legal Authorization Strategy` if the family challenges the will.

**Justification:** *High*, High because the executor's competence and sympathy directly impact the project's execution. It connects to legal authorization and trust design, influencing the smooth administration of the estate.
