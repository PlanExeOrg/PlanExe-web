**Budget Request Exceeding PMO Authority (100,000 DKK)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's delegated financial authority and requires strategic review.
Negative Consequences: Potential budget overrun and impact on project scope.

**Critical Risk Materialization (e.g., Legal Challenge by Family)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Discussion and Action Plan Approval
Rationale: Requires strategic decision-making and resource allocation beyond the PMO's capacity.
Negative Consequences: Project delays, increased legal costs, and potential project halt.

**PMO Deadlock on Mortuary Vendor Selection (Ethical Concerns)**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Review and Recommendation
Rationale: Requires independent ethical review and guidance to ensure compliance with ethical standards.
Negative Consequences: Potential ethical violations, reputational damage, and legal liabilities.

**Proposed Major Scope Change (e.g., Alternative Display Pose)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Impacts project objectives, budget, and timeline, requiring strategic alignment.
Negative Consequences: Project delays, budget overruns, and misalignment with client's wishes.

**Reported Ethical Concern (e.g., Conflict of Interest)**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation
Rationale: Requires independent investigation and resolution to maintain ethical integrity.
Negative Consequences: Reputational damage, legal liabilities, and loss of stakeholder trust.

**Unresolved Ethical Issue after Ethics & Compliance Committee Review**
Escalation Level: Independent Ethics Advisor
Approval Process: Independent Ethics Advisor Final Determination
Rationale: Requires final ethical determination from an independent expert.
Negative Consequences: Potential ethical violations, reputational damage, and legal liabilities.