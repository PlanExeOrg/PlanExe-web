**Purpose:** personal

**Purpose Detailed:** Planning for the preparation, preservation, and public display of one's skeleton after death, including legal, ethical, biohazard, and logistical considerations.

**Topic:** Post-mortem skeletal preparation and public display