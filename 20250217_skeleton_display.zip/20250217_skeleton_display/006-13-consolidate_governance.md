# Governance Audit


## Audit - Corruption Risks

- Bribery of mortuary staff to expedite or overlook certain biohazard protocols, potentially compromising safety.
- Kickbacks from display case fabricators in exchange for selecting their services, potentially leading to substandard quality or inflated pricing.
- Conflicts of interest if the estate executor or trust manager has undisclosed financial ties to vendors involved in the project (e.g., osteologist, mortuary).
- Nepotism in the selection of vendors (e.g., display case fabricator, PR firm) without proper competitive bidding, leading to inflated costs or lower quality.
- Misuse of privileged information regarding potential host institutions to benefit a related party seeking a similar arrangement.

## Audit - Misallocation Risks

- Overspending on the display case fabrication, diverting funds from the preservation endowment.
- Inefficient allocation of legal fees, such as unnecessary litigation or excessive consultation hours.
- Misreporting of project progress to justify continued funding, even if milestones are not being met.
- Unauthorized use of trust funds for personal expenses by the trustee or executor.
- Double billing for services rendered by the osteologist or mortuary facility.

## Audit - Procedures

- Conduct quarterly internal audits of all project expenditures, comparing actual costs against the approved budget, with variance analysis and justification for any discrepancies. Responsibility: Internal Audit Team.
- Implement a multi-signature approval workflow for all payments exceeding 50,000 DKK, requiring sign-off from both the estate executor and a designated trust representative. Frequency: Per transaction.
- Engage an external auditor to review the trust's financial statements annually, ensuring compliance with Danish accounting standards and verifying the proper allocation of funds for preservation and maintenance. Frequency: Annually.
- Perform periodic compliance checks to ensure the mortuary facility and osteologist are adhering to all relevant biohazard safety protocols and ethical guidelines. Responsibility: Biohazard Safety Consultant, Frequency: Quarterly.
- Conduct a post-project audit to assess the overall effectiveness of the project management, identify lessons learned, and evaluate the achievement of project goals within the allocated budget and timeline. Responsibility: External Audit Team, Frequency: Post-project completion.

## Audit - Transparency Measures

- Establish a project dashboard accessible to key stakeholders (estate executor, trust manager, family representatives) displaying real-time budget status, milestone progress, and key decisions. Type: Web-based dashboard.
- Publish minutes of all meetings of the trust's board of directors, redacting any sensitive personal information, to ensure transparency in decision-making regarding the project's financial management. Frequency: Monthly.
- Implement a whistleblower mechanism allowing individuals to report suspected fraud, corruption, or ethical violations anonymously, with a clear process for investigating and addressing such reports.
- Make the project's legal authorization documents (will, advance directives, court order) publicly available, subject to redaction of sensitive personal information, to demonstrate the legal basis for the project. Location: Project website or designated repository.
- Document and publish the selection criteria and rationale for all major vendors (osteologist, mortuary facility, display case fabricator), demonstrating a fair and transparent procurement process. Location: Project website or designated repository.

# Internal Governance Bodies

### 1. Project Steering Committee

**Rationale for Inclusion:** Provides high-level strategic direction and oversight, given the project's complexity, ethical considerations, and potential for legal challenges. Ensures alignment with the client's wishes and manages strategic risks.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic guidance and direction.
- Monitor project progress against key milestones.
- Approve significant changes to project scope or budget (above 100,000 DKK).
- Oversee risk management and mitigation strategies.
- Resolve strategic conflicts and escalate issues as needed.
- Ensure compliance with ethical and legal requirements.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define escalation paths.
- Review project plan and risk assessment.

**Membership:**

- Estate Executor
- Trust Manager
- Legal Counsel
- Independent Ethics Advisor (external)
- Family Representative (if willing)

**Decision Rights:** Strategic decisions related to project scope, budget (above 100,000 DKK), timeline, risk management, and ethical considerations.

**Decision Mechanism:** Decisions made by majority vote, with the Estate Executor having the tie-breaking vote. The Independent Ethics Advisor can veto decisions deemed ethically unsound.

**Meeting Cadence:** Quarterly, or more frequently as needed.

**Typical Agenda Items:**

- Review project progress against milestones.
- Review and approve budget updates.
- Discuss and resolve strategic risks and issues.
- Review ethical and legal compliance.
- Approve changes to project scope or timeline.
- Review stakeholder engagement.

**Escalation Path:** Unresolved issues escalated to the Estate Executor, whose decision is final, except in cases of ethical concerns, which are escalated to the Independent Ethics Advisor for final determination.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages day-to-day execution, operational risk management, and decisions below strategic thresholds. Ensures efficient project delivery and adherence to the project plan.

**Responsibilities:**

- Develop and maintain project plan.
- Manage project budget (below 100,000 DKK) and track expenses.
- Coordinate project activities and resources.
- Monitor project progress and identify potential issues.
- Implement risk mitigation strategies.
- Prepare project reports and updates.
- Manage communication among project stakeholders.
- Ensure compliance with project standards and procedures.

**Initial Setup Actions:**

- Establish project management processes and tools.
- Develop project communication plan.
- Define roles and responsibilities of project team members.
- Set up project tracking and reporting systems.

**Membership:**

- Project Manager
- Osteologist
- Mortuary Facility Representative
- Display Case Fabricator Representative
- PR/Communications Professional

**Decision Rights:** Operational decisions related to project execution, budget management (below 100,000 DKK), resource allocation, and risk mitigation.

**Decision Mechanism:** Decisions made by the Project Manager, in consultation with relevant team members. Disputes escalated to the Project Steering Committee.

**Meeting Cadence:** Bi-weekly, or more frequently as needed.

**Typical Agenda Items:**

- Review project progress against plan.
- Discuss and resolve operational issues.
- Review and approve budget expenditures (below 100,000 DKK).
- Review risk register and mitigation strategies.
- Plan upcoming activities and milestones.
- Review stakeholder communication.

**Escalation Path:** Unresolved issues escalated to the Project Steering Committee.
### 3. Ethics & Compliance Committee

**Rationale for Inclusion:** Provides specialized input and assurance on ethical and compliance aspects of the project, given the sensitive nature of the project and potential for ethical concerns and legal challenges. Ensures adherence to ethical standards, GDPR, and relevant regulations.

**Responsibilities:**

- Review and approve ethical guidelines for the project.
- Monitor compliance with ethical standards and relevant regulations (including GDPR).
- Provide guidance on ethical issues and dilemmas.
- Investigate and resolve ethical complaints.
- Ensure compliance with Danish body disposition laws.
- Review and approve communication strategies to address ethical concerns.
- Advise on stakeholder engagement to ensure ethical considerations are addressed.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Develop ethical guidelines for the project.
- Establish a process for reporting and investigating ethical complaints.

**Membership:**

- Independent Ethics Advisor (external, also on Steering Committee)
- Legal Counsel
- Grief Counselor/Mediator
- Family Representative (if willing)
- Biohazard Safety Consultant

**Decision Rights:** Decisions related to ethical considerations, compliance with ethical standards and relevant regulations, and resolution of ethical complaints. Can halt project activities deemed ethically unsound.

**Decision Mechanism:** Decisions made by majority vote, with the Independent Ethics Advisor having the tie-breaking vote and veto power on ethical grounds.

**Meeting Cadence:** Monthly, or more frequently as needed.

**Typical Agenda Items:**

- Review ethical guidelines and compliance.
- Discuss and resolve ethical issues and dilemmas.
- Review and approve communication strategies to address ethical concerns.
- Review stakeholder engagement to ensure ethical considerations are addressed.
- Review and investigate ethical complaints.
- Monitor compliance with GDPR and relevant regulations.

**Escalation Path:** Unresolved ethical issues escalated to the Independent Ethics Advisor, whose decision is final. Legal compliance issues escalated to Legal Counsel, with final escalation to the Estate Executor if necessary.

# Governance Implementation Plan

### 1. Project Manager drafts initial Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**


### 2. Project Manager drafts initial Terms of Reference for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**


### 3. Circulate Draft SteerCo ToR for review by nominated members (Estate Executor, Trust Manager, Legal Counsel, Independent Ethics Advisor, Family Representative).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 4. Circulate Draft Ethics & Compliance Committee ToR for review by nominated members (Independent Ethics Advisor, Legal Counsel, Grief Counselor/Mediator, Family Representative, Biohazard Safety Consultant).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1
- Nominated Members List Available

### 5. Project Manager finalizes the Project Steering Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 6. Project Manager finalizes the Ethics & Compliance Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary

### 7. Project Sponsor formally appoints the Chair of the Project Steering Committee.

**Responsible Body/Role:** Estate Executor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 8. Project Sponsor formally appoints the Chair of the Ethics & Compliance Committee.

**Responsible Body/Role:** Estate Executor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 9. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Appointment Confirmation Email
- Final SteerCo ToR v1.0

### 10. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Appointment Confirmation Email
- Final Ethics & Compliance Committee ToR v1.0

### 11. Hold initial Project Steering Committee kick-off meeting to review project goals, governance structure, and initial priorities.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 12. Hold initial Ethics & Compliance Committee kick-off meeting to review project goals, governance structure, and initial priorities.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 13. Project Manager establishes project management processes and tools for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Project Management Plan
- Communication Plan

**Dependencies:**


### 14. Project Manager defines roles and responsibilities of project team members for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Roles and Responsibilities Matrix

**Dependencies:**

- Project Management Plan

### 15. Project Manager sets up project tracking and reporting systems for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Tracking System
- Reporting Templates

**Dependencies:**

- Roles and Responsibilities Matrix

### 16. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Project Tracking System
- Reporting Templates

# Decision Escalation Matrix

**Budget Request Exceeding PMO Authority (100,000 DKK)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's delegated financial authority and requires strategic review.
Negative Consequences: Potential budget overrun and impact on project scope.

**Critical Risk Materialization (e.g., Legal Challenge by Family)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Discussion and Action Plan Approval
Rationale: Requires strategic decision-making and resource allocation beyond the PMO's capacity.
Negative Consequences: Project delays, increased legal costs, and potential project halt.

**PMO Deadlock on Mortuary Vendor Selection (Ethical Concerns)**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Review and Recommendation
Rationale: Requires independent ethical review and guidance to ensure compliance with ethical standards.
Negative Consequences: Potential ethical violations, reputational damage, and legal liabilities.

**Proposed Major Scope Change (e.g., Alternative Display Pose)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Impacts project objectives, budget, and timeline, requiring strategic alignment.
Negative Consequences: Project delays, budget overruns, and misalignment with client's wishes.

**Reported Ethical Concern (e.g., Conflict of Interest)**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation
Rationale: Requires independent investigation and resolution to maintain ethical integrity.
Negative Consequences: Reputational damage, legal liabilities, and loss of stakeholder trust.

**Unresolved Ethical Issue after Ethics & Compliance Committee Review**
Escalation Level: Independent Ethics Advisor
Approval Process: Independent Ethics Advisor Final Determination
Rationale: Requires final ethical determination from an independent expert.
Negative Consequences: Potential ethical violations, reputational damage, and legal liabilities.

# Monitoring Progress

### 1. Tracking Key Performance Indicators (KPIs) against Project Plan
**Monitoring Tools/Platforms:**

  - Project Management Software Dashboard
  - KPI Tracking Spreadsheet
  - Project Plan Document

**Frequency:** Weekly

**Responsible Role:** Project Manager

**Adaptation Process:** PMO proposes adjustments via Change Request to Steering Committee

**Adaptation Trigger:** KPI deviates >10% from baseline or critical path milestone delayed by >2 weeks

### 2. Regular Risk Register Review
**Monitoring Tools/Platforms:**

  - Risk Register Document
  - Project Management Software

**Frequency:** Bi-weekly

**Responsible Role:** Project Manager

**Adaptation Process:** Risk mitigation plan updated by PMO; significant changes reviewed by Steering Committee

**Adaptation Trigger:** New critical risk identified or existing risk likelihood/impact increases significantly

### 3. Legal Authorization Progress Monitoring
**Monitoring Tools/Platforms:**

  - Legal Counsel Progress Reports
  - Legal Document Tracking System
  - Court Order Status Updates

**Frequency:** Monthly

**Responsible Role:** Legal Counsel

**Adaptation Process:** Legal strategy adjusted by Legal Counsel; significant changes reviewed by Steering Committee

**Adaptation Trigger:** Significant delays in legal proceedings or increased likelihood of legal challenges

### 4. Family Communication and Conflict Monitoring
**Monitoring Tools/Platforms:**

  - Grief Counselor/Mediator Reports
  - Family Communication Log
  - Meeting Minutes

**Frequency:** Monthly

**Responsible Role:** Grief Counselor/Mediator

**Adaptation Process:** Family communication strategy adjusted by Grief Counselor/Mediator; significant concerns escalated to Steering Committee

**Adaptation Trigger:** Increased family conflict or resistance to the project

### 5. Ethical Compliance Monitoring
**Monitoring Tools/Platforms:**

  - Ethics & Compliance Committee Meeting Minutes
  - Compliance Checklist
  - Stakeholder Feedback Log

**Frequency:** Monthly

**Responsible Role:** Ethics & Compliance Committee

**Adaptation Process:** Corrective actions assigned by Ethics & Compliance Committee; significant ethical concerns escalated to Independent Ethics Advisor

**Adaptation Trigger:** Audit finding requires action or significant ethical concern raised by stakeholders

### 6. Financial Sustainability Monitoring
**Monitoring Tools/Platforms:**

  - Trust Financial Statements
  - Budget Tracking Spreadsheet
  - Endowment Performance Reports

**Frequency:** Quarterly

**Responsible Role:** Trust Manager

**Adaptation Process:** Trust investment strategy adjusted by Trust Manager; significant funding shortfalls escalated to Steering Committee

**Adaptation Trigger:** Projected funding shortfall below 10% of required amount or endowment underperforms benchmark by >5%

### 7. Host Institution Engagement and Commitment Monitoring
**Monitoring Tools/Platforms:**

  - Host Institution Meeting Minutes
  - Memorandum of Understanding (MOU)
  - Contractual Agreement

**Frequency:** Quarterly

**Responsible Role:** Project Manager

**Adaptation Process:** Alternative host institutions identified by Project Manager; significant concerns escalated to Steering Committee

**Adaptation Trigger:** Host institution expresses concerns about the project or indicates potential withdrawal

### 8. Biohazard Safety Protocol Compliance Monitoring
**Monitoring Tools/Platforms:**

  - Biohazard Safety Consultant Reports
  - Mortuary Facility Inspection Reports
  - Incident Reports

**Frequency:** Monthly

**Responsible Role:** Biohazard Safety Consultant

**Adaptation Process:** Biohazard protocols updated by Biohazard Safety Consultant; significant safety violations escalated to Ethics & Compliance Committee

**Adaptation Trigger:** Biohazard incident occurs or safety inspection reveals non-compliance

### 9. Public Perception and Media Monitoring
**Monitoring Tools/Platforms:**

  - Media Monitoring Reports
  - Social Media Sentiment Analysis
  - Stakeholder Feedback Surveys

**Frequency:** Monthly

**Responsible Role:** PR/Communications Professional

**Adaptation Process:** PR strategy adjusted by PR/Communications Professional; significant negative publicity escalated to Steering Committee

**Adaptation Trigger:** Negative media coverage or significant negative sentiment expressed by the public

# Governance Extra

## Governance Validation Checks

1. Point 1: Completeness Confirmation: All core requested components (internal_governance_bodies, governance_implementation_plan, decision_escalation_matrix, monitoring_progress) appear to be generated.
2. Point 2: Internal Consistency Check: The Implementation Plan uses defined bodies, the Escalation Matrix aligns with the governance hierarchy, and Monitoring roles are consistent with assigned responsibilities. No immediate discrepancies are apparent.
3. Point 3: Potential Gaps / Areas for Enhancement: The role and authority of the Estate Executor, acting as Project Sponsor, needs further clarification. While mentioned in various contexts, their ultimate decision-making power and responsibility for overall project success should be explicitly stated in the Terms of Reference for the Project Steering Committee.
4. Point 4: Potential Gaps / Areas for Enhancement: The process for handling conflicts of interest, particularly involving family members or vendors, requires more detailed definition. The Ethics & Compliance Committee's responsibilities are outlined, but the specific steps for identifying, investigating, and resolving conflicts should be formalized in a documented procedure.
5. Point 5: Potential Gaps / Areas for Enhancement: The adaptation triggers in the Monitoring Progress plan are primarily reactive. Consider adding proactive triggers based on leading indicators (e.g., early warning signs of family dissatisfaction, preliminary feedback on the display narrative) to allow for more timely intervention.
6. Point 6: Potential Gaps / Areas for Enhancement: The escalation path for legal compliance issues could be more direct. Currently, it goes from Legal Counsel to the Estate Executor. Depending on the nature of the issue, it might be more appropriate to escalate directly to the Project Steering Committee or even an external regulatory body in certain circumstances.
7. Point 7: Potential Gaps / Areas for Enhancement: While the Ethics & Compliance Committee includes a Family Representative (if willing), the plan lacks detail on how to ensure their active participation and address potential power imbalances within the committee. Consider providing training or support to the Family Representative to enable them to effectively voice their concerns and contribute to ethical decision-making.

## Tough Questions

1. What is the current probability-weighted forecast for securing the necessary court order, and what contingency plans are in place if the initial application is rejected?
2. Show evidence of proactive measures taken to identify and mitigate potential conflicts of interest among all project stakeholders, including family members and vendors.
3. What specific metrics will be used to assess the effectiveness of the family communication strategy, and what are the pre-defined thresholds for triggering a change in approach?
4. What is the detailed financial model projecting the long-term sustainability of the trust, accounting for inflation, potential market downturns, and unexpected maintenance costs?
5. What are the specific criteria for evaluating potential host institutions, and how will the project ensure that the chosen institution remains committed to the project's long-term preservation goals?
6. What is the detailed biohazard management protocol, including specific PPE requirements, decontamination procedures, and emergency response plans, and how will its effectiveness be continuously monitored and verified?
7. What is the communication plan for addressing potential negative media coverage or ethical objections from the public, and what are the key messages that will be conveyed?
8. What is the plan to ensure the osteologist is adequately insured and bonded, and what recourse does the project have if the osteologist is unable to complete the work due to unforeseen circumstances?

## Summary

The governance framework establishes a multi-layered approach to managing the complex legal, ethical, and logistical challenges of this unconventional project. It emphasizes strategic oversight through the Project Steering Committee, operational management by the PMO, and ethical assurance by the Ethics & Compliance Committee. A key focus area is proactive risk management, particularly concerning legal challenges, ethical objections, and financial sustainability, with a strong emphasis on securing a legally defensible framework and managing stakeholder expectations.