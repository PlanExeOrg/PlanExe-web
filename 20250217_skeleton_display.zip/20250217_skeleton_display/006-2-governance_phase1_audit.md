
## Audit - Corruption Risks

- Bribery of mortuary staff to expedite or overlook certain biohazard protocols, potentially compromising safety.
- Kickbacks from display case fabricators in exchange for selecting their services, potentially leading to substandard quality or inflated pricing.
- Conflicts of interest if the estate executor or trust manager has undisclosed financial ties to vendors involved in the project (e.g., osteologist, mortuary).
- Nepotism in the selection of vendors (e.g., display case fabricator, PR firm) without proper competitive bidding, leading to inflated costs or lower quality.
- Misuse of privileged information regarding potential host institutions to benefit a related party seeking a similar arrangement.

## Audit - Misallocation Risks

- Overspending on the display case fabrication, diverting funds from the preservation endowment.
- Inefficient allocation of legal fees, such as unnecessary litigation or excessive consultation hours.
- Misreporting of project progress to justify continued funding, even if milestones are not being met.
- Unauthorized use of trust funds for personal expenses by the trustee or executor.
- Double billing for services rendered by the osteologist or mortuary facility.

## Audit - Procedures

- Conduct quarterly internal audits of all project expenditures, comparing actual costs against the approved budget, with variance analysis and justification for any discrepancies. Responsibility: Internal Audit Team.
- Implement a multi-signature approval workflow for all payments exceeding 50,000 DKK, requiring sign-off from both the estate executor and a designated trust representative. Frequency: Per transaction.
- Engage an external auditor to review the trust's financial statements annually, ensuring compliance with Danish accounting standards and verifying the proper allocation of funds for preservation and maintenance. Frequency: Annually.
- Perform periodic compliance checks to ensure the mortuary facility and osteologist are adhering to all relevant biohazard safety protocols and ethical guidelines. Responsibility: Biohazard Safety Consultant, Frequency: Quarterly.
- Conduct a post-project audit to assess the overall effectiveness of the project management, identify lessons learned, and evaluate the achievement of project goals within the allocated budget and timeline. Responsibility: External Audit Team, Frequency: Post-project completion.

## Audit - Transparency Measures

- Establish a project dashboard accessible to key stakeholders (estate executor, trust manager, family representatives) displaying real-time budget status, milestone progress, and key decisions. Type: Web-based dashboard.
- Publish minutes of all meetings of the trust's board of directors, redacting any sensitive personal information, to ensure transparency in decision-making regarding the project's financial management. Frequency: Monthly.
- Implement a whistleblower mechanism allowing individuals to report suspected fraud, corruption, or ethical violations anonymously, with a clear process for investigating and addressing such reports.
- Make the project's legal authorization documents (will, advance directives, court order) publicly available, subject to redaction of sensitive personal information, to demonstrate the legal basis for the project. Location: Project website or designated repository.
- Document and publish the selection criteria and rationale for all major vendors (osteologist, mortuary facility, display case fabricator), demonstrating a fair and transparent procurement process. Location: Project website or designated repository.