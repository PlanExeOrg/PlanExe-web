
## Documents to Create

### 1. Project Goal Statement/Charter

**ID:** 2c9fe72e-f5c6-403c-bc43-f30c34525a0b

**Description:** A high-level document outlining the project's purpose, goals, and key stakeholders. It serves as a guiding document for the entire project.

**Responsible Role Type:** Project Owner

**Primary Template:** Project Charter Template

**Steps:**

- Define the project's purpose and objectives.
- Identify key stakeholders and their roles.
- Outline the project's scope and deliverables.
- Establish project governance and decision-making processes.
- Document initial assumptions and constraints.

**Approval Authorities:** Self

### 2. Legal Authorization Strategy Plan

**ID:** ed5d7b0a-aded-4cc7-ad24-e7cbc52229c1

**Description:** A plan detailing the steps to secure the necessary legal permissions for the post-mortem skeletal preparation and public display, including choice of legal instruments and executor powers.

**Responsible Role Type:** Project Owner

**Primary Template:** Legal Strategy Outline

**Steps:**

- Research Danish body disposition laws.
- Consult with a legal specialist.
- Determine the optimal legal strategy (will, court order, trust).
- Outline the steps to secure legal authorization.
- Define success metrics for legal authorization.

**Approval Authorities:** Self, Legal Counsel

### 3. Family Communication Approach Plan

**ID:** 014cc48e-da2c-4976-8636-6ae6c5477fa8

**Description:** A plan outlining how the client's wishes will be communicated to their family, aiming to minimize conflict and gain their understanding or acceptance.

**Responsible Role Type:** Project Owner

**Primary Template:** Communication Plan Template

**Steps:**

- Identify key family members and their potential concerns.
- Determine the communication approach (grief counselor, video message, family involvement).
- Outline the communication timeline and methods.
- Define success metrics for family communication.
- Plan for conflict resolution.

**Approval Authorities:** Self, Grief Counselor/Mediator

### 4. Display Narrative Framing Plan

**ID:** a261d1d1-fdd6-410a-acff-a98145405c47

**Description:** A plan outlining how the public perception of the skeletal display will be shaped, aiming to preempt negative reactions and foster understanding.

**Responsible Role Type:** Project Owner

**Primary Template:** Narrative Outline

**Steps:**

- Determine the desired public narrative (personal expression, educational opportunity, art installation).
- Identify target audiences and their potential concerns.
- Outline the communication channels and methods.
- Define success metrics for public perception.
- Plan for managing negative publicity.

**Approval Authorities:** Self, PR/Communications Specialist

### 5. Host Institution Selection Plan

**ID:** a7b17d35-2cac-4a29-9d54-e1d501a5b389

**Description:** A plan outlining the process for identifying and securing a suitable venue for the permanent public display of the skeleton.

**Responsible Role Type:** Project Owner

**Primary Template:** Institution Selection Criteria

**Steps:**

- Identify potential host institutions (niche museums, universities, private foundations).
- Define selection criteria (willingness to host, preservation conditions, alignment with goals).
- Research potential institutions and their requirements.
- Outline the negotiation process.
- Define success metrics for host institution selection.

**Approval Authorities:** Self

### 6. Trust Structure Design Plan

**ID:** 0687cf1c-93c4-4155-81d6-c484c0b1b373

**Description:** A plan outlining the financial framework for the project's long-term sustainability, including how funds will be managed and disbursed.

**Responsible Role Type:** Project Owner

**Primary Template:** Trust Design Outline

**Secondary Template:** Spreadsheet Budget Template

**Steps:**

- Determine the optimal trust structure (charitable, spendthrift, hybrid).
- Outline the trust's governance and management.
- Define the trust's investment strategy.
- Estimate long-term funding needs.
- Consult with a financial advisor and tax attorney.

**Approval Authorities:** Self, Financial Advisor, Legal Counsel

### 7. Biohazard Mitigation Protocol Plan

**ID:** 1f0f6a44-359d-4bfe-8c02-841221a2ce9b

**Description:** A plan outlining the safety measures and procedures to be implemented during the decomposition and skeletal preparation process to minimize the risk of biohazard exposure.

**Responsible Role Type:** Project Owner

**Primary Template:** Biohazard Protocol Template

**Steps:**

- Identify potential biohazards.
- Define safety measures and procedures (PPE, ventilation, decontamination).
- Outline waste disposal methods.
- Consult with a biohazard safety consultant.
- Define success metrics for biohazard mitigation.

**Approval Authorities:** Self, Biohazard Safety Consultant

### 8. Long-Term Preservation Strategy Plan

**ID:** b21cfc73-b0bc-41d6-a7ab-c2bf43957c21

**Description:** A plan outlining the resources and methods used to ensure the skeleton's integrity and display for decades, combating degradation.

**Responsible Role Type:** Project Owner

**Primary Template:** Preservation Plan Template

**Steps:**

- Identify potential degradation factors (temperature, humidity, UV light).
- Define preservation methods (environmental control, cleaning, repairs).
- Outline the monitoring and maintenance schedule.
- Consult with a museum conservator.
- Define success metrics for long-term preservation.

**Approval Authorities:** Self, Museum Conservator

### 9. Skeletal Pose Design Plan

**ID:** 7dac79dc-78ba-4519-83f3-8db7ba9b8a66

**Description:** A plan outlining the aesthetic and narrative impact of the displayed skeleton, defining the final arrangement of the bones.

**Responsible Role Type:** Project Owner

**Primary Template:** Pose Design Outline

**Steps:**

- Explore variations on the zombie theme.
- Consult with a sculptor and forensic anthropologist.
- Develop maquettes and test public reaction.
- Define success metrics for pose design.
- Ensure anatomical plausibility.

**Approval Authorities:** Self, Sculptor, Forensic Anthropologist

### 10. Osteological Scope Definition Plan

**ID:** b72aea8a-ba21-4b9a-81b8-1f6d6ea18cfd

**Description:** A plan outlining the level of detail and accuracy in the skeletal preparation, balancing scientific rigor with artistic expression and budgetary constraints.

**Responsible Role Type:** Project Owner

**Primary Template:** Scope Definition Outline

**Secondary Template:** Spreadsheet Budget Template

**Steps:**

- Determine the level of detail (anatomical accuracy, artistic expression, minimalist approach).
- Outline the cleaning, articulation, and restoration processes.
- Consult with an osteologist.
- Define success metrics for osteological scope.
- Consider budgetary constraints.

**Approval Authorities:** Self, Osteologist

### 11. Mortuary Vendor Diligence Plan

**ID:** 2fadff76-01de-49bb-bddf-486ee80bff98

**Description:** A plan outlining the process for selecting a qualified and ethical facility for handling the body and preparing the skeleton.

**Responsible Role Type:** Project Owner

**Primary Template:** Vendor Selection Criteria

**Steps:**

- Identify potential mortuary vendors.
- Define selection criteria (licenses, safety records, biohazard protocols).
- Conduct background checks and site visits.
- Require a detailed written protocol.
- Define success metrics for mortuary vendor diligence.

**Approval Authorities:** Self, Biohazard Safety Consultant

### 12. Display Case Security Measures Plan

**ID:** c6d27bcd-da3b-4e5e-a1cc-acb42193119f

**Description:** A plan outlining the level of security integrated into the display case to safeguard the skeletal display from theft or vandalism.

**Responsible Role Type:** Project Owner

**Primary Template:** Security Plan Outline

**Steps:**

- Determine the level of security (reinforced glass, motion sensors, alarms, self-destruct mechanism).
- Consult with security experts.
- Outline the security protocols.
- Define success metrics for display case security.
- Consider aesthetic impact.

**Approval Authorities:** Self

### 13. Estate Executor Nomination Plan

**ID:** ac6a42ad-4538-42b1-9f08-4672561e3766

**Description:** A plan outlining the process for selecting who will manage the estate and ensure the project's execution after death.

**Responsible Role Type:** Project Owner

**Primary Template:** Executor Nomination Outline

**Steps:**

- Identify potential executors (trust company, close friend, co-executor arrangement).
- Define selection criteria (competence, sympathy, impartiality).
- Consult with a legal specialist.
- Outline the executor's responsibilities.
- Define success metrics for estate executor nomination.

**Approval Authorities:** Self, Legal Counsel

### 14. Initial Risk List

**ID:** f7b5da6d-0b5b-4d28-9a98-12483ff594fb

**Description:** A list of potential risks that could impact the project, along with their likelihood, severity, and mitigation strategies.

**Responsible Role Type:** Project Owner

**Primary Template:** Risk Register Template

**Steps:**

- Identify potential risks (regulatory, social, ethical, financial, operational, biohazard, supply chain, security).
- Assess the likelihood and severity of each risk.
- Develop mitigation strategies for each risk.
- Assign responsibility for monitoring and managing each risk.

**Approval Authorities:** Self

### 15. Communication Outline

**ID:** a88c70fc-d747-4a68-b1bc-8cbb57f2fd97

**Description:** A high-level outline of how communication will be managed throughout the project, including key stakeholders, communication channels, and frequency.

**Responsible Role Type:** Project Owner

**Primary Template:** Communication Plan Template

**Steps:**

- Identify key stakeholders.
- Determine communication channels (email, meetings, reports).
- Define communication frequency.
- Establish communication protocols.
- Assign responsibility for communication.

**Approval Authorities:** Self

### 16. Key People/Resources List

**ID:** 99965bdb-b488-4e3b-95b4-8b64111b7d4a

**Description:** A list of key people and resources required for the project, including their contact information and roles.

**Responsible Role Type:** Project Owner

**Primary Template:** Contact List Template

**Steps:**

- Identify key people (legal counsel, osteologist, mortuary facility, etc.).
- Identify key resources (funding, equipment, facilities).
- Gather contact information.
- Define roles and responsibilities.

**Approval Authorities:** Self

### 17. High-Level Budget

**ID:** e25003f4-9a25-4daf-84ff-c17b04bdb48f

**Description:** A high-level estimate of the project's costs, including legal fees, osteologist services, display case fabrication, and long-term preservation.

**Responsible Role Type:** Project Owner

**Primary Template:** Spreadsheet Budget Template

**Steps:**

- Identify cost categories (legal fees, osteologist services, display case fabrication, etc.).
- Estimate costs for each category.
- Allocate contingency funds.
- Review and approve the budget.

**Approval Authorities:** Self

### 18. Initial Timeline/Schedule

**ID:** 64a12f8c-c412-4369-bee7-3321e5cfd592

**Description:** A high-level schedule outlining the project's key milestones and deadlines.

**Responsible Role Type:** Project Owner

**Primary Template:** Gantt Chart Template

**Steps:**

- Identify key milestones (legal authorization, skeletal preparation, display case fabrication, etc.).
- Estimate the duration of each task.
- Define dependencies between tasks.
- Create a timeline/schedule.
- Review and approve the schedule.

**Approval Authorities:** Self

## Documents to Find

### 1. Danish Body Disposition Law Data

**ID:** ccb144a1-af54-4cd9-a8d3-2311d19d4c59

**Description:** Official Danish laws and regulations regarding body disposition, anatomical gifts, and public display of human remains. Needed to understand legal constraints and requirements.

**Recency Requirement:** Most recent version available

**Responsible Role Type:** Project Owner

**Access Difficulty:** Medium: Requires knowledge of Danish legal system and language skills.

**Steps:**

- Search the official Danish government website for legal information.
- Consult with a legal specialist in Danish law.
- Review relevant legal databases and publications.

### 2. List of Licensed Mortuary Facilities in Copenhagen

**ID:** e1c11882-6418-45b7-a0f0-af70f2271ed6

**Description:** A list of licensed mortuary facilities in Copenhagen that are equipped for biohazard management and skeletal preparation. Needed to identify potential vendors.

**Recency Requirement:** Updated within the last year

**Responsible Role Type:** Project Owner

**Access Difficulty:** Medium: Requires contacting government agencies or industry associations.

**Steps:**

- Contact the Danish Health Authority.
- Search online directories of mortuary facilities.
- Consult with funeral homes in Copenhagen.

### 3. Mortuary Vendor Biohazard Protocol Examples

**ID:** 0eeb1c02-8f86-4663-acf1-e08e90fd7a8f

**Description:** Examples of biohazard protocols used by mortuary facilities, including PPE specifications, waste disposal methods, and emergency response plans. Needed to develop a comprehensive biohazard mitigation protocol.

**Recency Requirement:** Within the last 5 years

**Responsible Role Type:** Project Owner

**Access Difficulty:** Medium: Requires contacting vendors and potentially signing non-disclosure agreements.

**Steps:**

- Request sample protocols from potential mortuary vendors.
- Search online databases of safety protocols.
- Consult with a biohazard safety consultant.

### 4. List of Osteologists/Anatomical Preparators

**ID:** c6a71cbb-1d9b-4dbb-bd39-faf2745c902b

**Description:** A list of qualified osteologists or anatomical preparators with experience in skeletal preparation and articulation. Needed to identify potential experts.

**Recency Requirement:** Updated within the last 2 years

**Responsible Role Type:** Project Owner

**Access Difficulty:** Medium: Requires contacting academic institutions and professional organizations.

**Steps:**

- Contact universities and research institutions with anatomy or forensic science programs in Denmark.
- Search online directories of medical professionals.
- Consult with museums and galleries that display skeletal remains.

### 5. Pricing Data for Osteologist Services

**ID:** 2badf08c-307e-495c-b2cd-5f28cb6b01ac

**Description:** Pricing information for osteologist services, including skeletal preparation, articulation, and posing. Needed to estimate project costs.

**Recency Requirement:** Within the last year

**Responsible Role Type:** Project Owner

**Access Difficulty:** Medium: Requires contacting professionals and potentially negotiating fees.

**Steps:**

- Request quotes from potential osteologists.
- Research industry standards for osteologist fees.
- Consult with museums and galleries that have commissioned similar work.

### 6. List of Potential Host Institutions in Copenhagen

**ID:** 02f35546-ab8f-4b8d-b94b-f749294a7aab

**Description:** A list of potential host institutions in Copenhagen that may be willing to display the skeleton, including museums, galleries, and universities. Needed to identify potential venues.

**Recency Requirement:** Updated within the last year

**Responsible Role Type:** Project Owner

**Access Difficulty:** Easy: Publicly available information.

**Steps:**

- Search online directories of museums and galleries in Copenhagen.
- Contact universities and research institutions with anatomy or forensic science programs.
- Consult with cultural organizations in Copenhagen.

### 7. Museum Display Case Specifications and Pricing Data

**ID:** 3ab039fe-accd-45d3-bc1d-73103f196a15

**Description:** Specifications and pricing information for museum-grade display cases with environmental controls. Needed to estimate project costs and ensure long-term preservation.

**Recency Requirement:** Within the last year

**Responsible Role Type:** Project Owner

**Access Difficulty:** Medium: Requires contacting vendors and potentially requesting custom quotes.

**Steps:**

- Contact display case manufacturers and suppliers.
- Research industry standards for museum display cases.
- Consult with museums and galleries that have purchased similar display cases.

### 8. Pricing Data for Biohazard Safety Consulting Services

**ID:** 0a2af527-f4c6-4134-878f-ffaa242692a7

**Description:** Pricing information for biohazard safety consulting services, including risk assessments, protocol development, and training. Needed to estimate project costs.

**Recency Requirement:** Within the last year

**Responsible Role Type:** Project Owner

**Access Difficulty:** Medium: Requires contacting professionals and potentially negotiating fees.

**Steps:**

- Request quotes from potential biohazard safety consultants.
- Research industry standards for consulting fees.
- Consult with organizations that have hired similar consultants.

### 9. Pricing Data for Grief Counseling/Mediation Services

**ID:** 24141f15-cb94-42ba-b63a-38d2f7be6658

**Description:** Pricing information for grief counseling and mediation services, including individual and family sessions. Needed to estimate project costs.

**Recency Requirement:** Within the last year

**Responsible Role Type:** Project Owner

**Access Difficulty:** Medium: Requires contacting professionals and potentially negotiating fees.

**Steps:**

- Request quotes from potential grief counselors and mediators.
- Research industry standards for counseling and mediation fees.
- Consult with organizations that have used similar services.

### 10. Pricing Data for PR/Communications Services

**ID:** e7dc13b7-b320-487e-9a47-d39dad454e82

**Description:** Pricing information for public relations and communications services, including media relations, crisis management, and stakeholder engagement. Needed to estimate project costs.

**Recency Requirement:** Within the last year

**Responsible Role Type:** Project Owner

**Access Difficulty:** Medium: Requires contacting professionals and potentially negotiating fees.

**Steps:**

- Request quotes from potential PR/communications specialists.
- Research industry standards for consulting fees.
- Consult with organizations that have hired similar specialists.

### 11. Examples of Ethical Guidelines for Displaying Human Remains

**ID:** b9561450-4549-4c24-8fb0-797f7e4e300d

**Description:** Examples of ethical guidelines used by museums and other institutions for displaying human remains. Needed to develop ethical guidelines for the project.

**Recency Requirement:** Within the last 10 years

**Responsible Role Type:** Project Owner

**Access Difficulty:** Medium: Requires searching specialized databases and contacting professionals.

**Steps:**

- Search online databases of museum ethics guidelines.
- Consult with museum professionals.
- Review publications on the ethical display of human remains.

### 12. Examples of Trust Agreements in Denmark

**ID:** 3ce5110b-a348-4843-abd2-e8f166d7c662

**Description:** Examples of trust agreements used in Denmark, including charitable trusts and spendthrift trusts. Needed to understand legal requirements and best practices.

**Recency Requirement:** Within the last 5 years

**Responsible Role Type:** Project Owner

**Access Difficulty:** Hard: Requires legal expertise and access to legal databases.

**Steps:**

- Consult with a legal specialist in Danish trust law.
- Search legal databases for sample trust agreements.
- Consult with financial advisors who specialize in trust management.

### 13. List of Biohazard Waste Disposal Companies in Copenhagen

**ID:** 4b35f06b-3ac3-44c0-acba-a859d96593e4

**Description:** A list of companies in Copenhagen that specialize in the disposal of biohazardous waste. Needed to ensure proper waste disposal.

**Recency Requirement:** Updated within the last year

**Responsible Role Type:** Project Owner

**Access Difficulty:** Easy: Publicly available information.

**Steps:**

- Search online directories of waste disposal companies.
- Contact the Danish Environmental Protection Agency.
- Consult with mortuary facilities in Copenhagen.

### 14. Museum Conservator Contact Information

**ID:** bf6a9ade-7418-4e99-b424-b3b0be12e497

**Description:** Contact information for museum conservators specializing in skeletal remains. Needed to consult on long-term preservation.

**Recency Requirement:** Current

**Responsible Role Type:** Project Owner

**Access Difficulty:** Medium: Requires contacting museums and professional organizations.

**Steps:**

- Contact museums with skeletal collections.
- Search professional organizations for conservators.
- Consult with university archaeology departments.