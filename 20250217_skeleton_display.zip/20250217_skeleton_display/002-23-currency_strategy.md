This plan involves money.

## Currencies

- **DKK:** Local currency for all expenses in Denmark, including legal fees, osteologist services, mortuary facility, display case fabrication, biohazard compliance, grief counseling, and a preservation endowment.

**Primary currency:** DKK

**Currency strategy:** The Danish Krone (DKK) will be used for all transactions. No additional international risk management is needed.