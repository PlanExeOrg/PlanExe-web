# Documents to Create

## Create Document 1: Project Goal Statement/Charter

**ID**: 2c9fe72e-f5c6-403c-bc43-f30c34525a0b

**Description**: A high-level document outlining the project's purpose, goals, and key stakeholders. It serves as a guiding document for the entire project.

**Responsible Role Type**: Project Owner

**Primary Template**: Project Charter Template

**Secondary Template**: None

**Steps to Create**:

- Define the project's purpose and objectives.
- Identify key stakeholders and their roles.
- Outline the project's scope and deliverables.
- Establish project governance and decision-making processes.
- Document initial assumptions and constraints.

**Approval Authorities**: Self

**Essential Information**:

- What specific legal authorizations (e.g., court order, permits) are required in Copenhagen for post-mortem skeletal preparation and public display?
- What are the key steps and timeline for securing these legal authorizations?
- What specific clauses must be included in the will and advance directives to ensure the client's wishes are legally binding and enforceable?
- What are the potential legal challenges from family members, and how can they be addressed proactively?
- What are the ethical considerations surrounding the public display of human remains, and how can they be addressed in the project's narrative and presentation?
- What specific information should be included in the client's video message to family members to convey their intentions and address potential concerns?
- What are the key elements of the 'Pioneer's Gambit' scenario, and how can they be implemented effectively in the project?
- What are the criteria for selecting a niche museum or gallery that aligns with the project's unconventional nature?
- What are the key provisions that should be included in the irrevocable charitable trust to ensure its long-term stability and independence?
- What are the roles and responsibilities of the board of directors for the charitable trust?
- What is the final, approved project goal statement, incorporating SMART criteria?
- What are the key dependencies, resources, and related goals for the project?
- What are the identified risks and mitigation strategies, tailored to the 'Pioneer's Gambit' scenario?
- What is the detailed stakeholder analysis, including engagement strategies for each stakeholder group?
- What are the specific regulatory and compliance requirements for the project, including permits, licenses, and compliance standards?

**Risks of Poor Quality**:

- An unclear or incomplete project goal statement leads to misaligned efforts and scope creep.
- A poorly defined legal strategy results in legal challenges and project delays.
- Inadequate family communication leads to conflict and potential legal battles.
- A poorly crafted narrative results in negative public perception and ethical concerns.
- Failure to secure a suitable host institution results in the project's long-term viability being compromised.
- A poorly designed trust structure results in financial instability and potential funding shortfalls.
- Incomplete risk assessment leads to unforeseen challenges and project delays.
- Inadequate stakeholder analysis results in miscommunication and lack of support.

**Worst Case Scenario**: The project is halted due to legal challenges, family objections, or ethical concerns, resulting in the client's wishes not being fulfilled and the allocated funds being wasted.

**Best Case Scenario**: The project is successfully executed, resulting in the public display of the skeleton in a reputable institution in Copenhagen, fulfilling the client's wishes and challenging conventional notions of death and remembrance. Enables clear decision-making on legal strategy, family communication, narrative framing, host institution selection, and trust structure design.

**Fallback Alternative Approaches**:

- Consult with legal experts specializing in body disposition law in Denmark to refine the legal strategy.
- Engage a grief counselor or mediator to facilitate family discussions and address potential concerns.
- Develop a detailed communication plan to manage public perception and address ethical concerns.
- Identify alternative host institutions and establish relationships.
- Consult with a financial advisor and tax attorney to optimize the trust structure.
- Break down the project into smaller, more manageable tasks with clear milestones and deadlines.
- Use project management software to track progress and manage resources effectively.
- Create a simpler version of the project goal statement focusing only on the absolute essential elements.

## Create Document 2: Legal Authorization Strategy Plan

**ID**: ed5d7b0a-aded-4cc7-ad24-e7cbc52229c1

**Description**: A plan detailing the steps to secure the necessary legal permissions for the post-mortem skeletal preparation and public display, including choice of legal instruments and executor powers.

**Responsible Role Type**: Project Owner

**Primary Template**: Legal Strategy Outline

**Secondary Template**: None

**Steps to Create**:

- Research Danish body disposition laws.
- Consult with a legal specialist.
- Determine the optimal legal strategy (will, court order, trust).
- Outline the steps to secure legal authorization.
- Define success metrics for legal authorization.

**Approval Authorities**: Self, Legal Counsel

**Essential Information**:

- What specific legal instruments (will, trust, court order) will be used to authorize the post-mortem skeletal preparation and public display?
- What specific clauses need to be included in the will and advance directives to address potential family objections and grant explicit authority to the executor?
- Outline the process for obtaining a court order affirming the legality and enforceability of the client's wishes during their lifetime.
- Detail the legal framework for treating the skeleton as intellectual property, including ownership assignment and enforcement of display rights.
- What are the specific powers and responsibilities of the estate executor or trustee regarding the project?
- Identify potential legal challenges from family members or other parties and outline strategies to mitigate these challenges.
- What are the key legal precedents or case laws that support the legality of the project in Denmark?
- Outline the process for obtaining all necessary permits and licenses for the project.
- What are the specific legal requirements for handling and disposing of human remains in Denmark?
- Detail the process for ensuring compliance with all relevant laws and regulations throughout the project.

**Risks of Poor Quality**:

- Failure to secure adequate legal authorization could result in legal challenges from family members or other parties, potentially halting the project.
- A weak legal strategy could leave the project vulnerable to being blocked or altered after the client's death.
- Inadequate legal documentation could lead to disputes over the client's wishes and the executor's authority.
- Failure to comply with relevant laws and regulations could result in legal penalties and reputational damage.

**Worst Case Scenario**: The project is blocked by legal challenges, the client's wishes are not honored, and the skeleton cannot be publicly displayed, resulting in significant financial loss and emotional distress.

**Best Case Scenario**: The project proceeds smoothly with full legal authorization, the client's wishes are honored, and the skeleton is successfully displayed in a public institution, creating a lasting legacy and challenging conventional notions of death and remembrance. Enables clear, legally sound decisions regarding the project's execution.

**Fallback Alternative Approaches**:

- Consult with a legal specialist experienced in body disposition law in Denmark.
- Focus on securing comprehensive legal authorization through a detailed will and advance directives.
- Prioritize open communication with family members to minimize potential legal challenges.
- Seek mediation or conflict resolution services to address family objections.
- Scale back the project to a private display if public display proves legally challenging.

## Create Document 3: Family Communication Approach Plan

**ID**: 014cc48e-da2c-4976-8636-6ae6c5477fa8

**Description**: A plan outlining how the client's wishes will be communicated to their family, aiming to minimize conflict and gain their understanding or acceptance.

**Responsible Role Type**: Project Owner

**Primary Template**: Communication Plan Template

**Secondary Template**: None

**Steps to Create**:

- Identify key family members and their potential concerns.
- Determine the communication approach (grief counselor, video message, family involvement).
- Outline the communication timeline and methods.
- Define success metrics for family communication.
- Plan for conflict resolution.

**Approval Authorities**: Self, Grief Counselor/Mediator

**Essential Information**:

- Identify all immediate and extended family members who need to be informed.
- List potential concerns, objections, or emotional reactions each family member might have regarding the project.
- Detail the specific communication methods to be used (e.g., in-person meetings, video message, written letters, mediated discussions).
- Outline the timeline for communication, including when and how each family member will be informed.
- Specify who will deliver the message (e.g., estate executor, grief counselor, client's video).
- Define the key messages to be conveyed, including the client's motivations, wishes, and the project's goals.
- Plan for addressing potential conflicts or disagreements among family members, including mediation or counseling options.
- Outline a process for ongoing communication and updates to family members throughout the project.
- Identify opportunities for family involvement in the project (e.g., selecting display case design, contributing to the narrative).
- Document any legal considerations related to family communication, such as consent forms or waivers.

**Risks of Poor Quality**:

- Increased family conflict and emotional distress.
- Legal challenges to the will or project execution.
- Negative publicity and damage to the client's reputation.
- Delays in project execution due to family objections.
- Strained family relationships and long-term resentment.

**Worst Case Scenario**: Complete family opposition leading to legal injunctions, preventing the project from proceeding and causing significant emotional and financial strain on all parties involved.

**Best Case Scenario**: Family members understand and accept the client's wishes, providing support and cooperation throughout the project, leading to a harmonious and successful execution of the memorialization plan.

**Fallback Alternative Approaches**:

- Consult with a grief counselor or mediator to develop a communication strategy.
- Focus on communicating with a smaller, more supportive group of family members.
- Document all communication efforts and decisions in writing.
- Seek legal advice on how to proceed if family members remain opposed.
- Create a simplified communication plan focusing only on essential information.

## Create Document 4: Display Narrative Framing Plan

**ID**: a261d1d1-fdd6-410a-acff-a98145405c47

**Description**: A plan outlining how the public perception of the skeletal display will be shaped, aiming to preempt negative reactions and foster understanding.

**Responsible Role Type**: Project Owner

**Primary Template**: Narrative Outline

**Secondary Template**: None

**Steps to Create**:

- Determine the desired public narrative (personal expression, educational opportunity, art installation).
- Identify target audiences and their potential concerns.
- Outline the communication channels and methods.
- Define success metrics for public perception.
- Plan for managing negative publicity.

**Approval Authorities**: Self, PR/Communications Specialist

**Essential Information**:

- What is the core message or theme to be conveyed through the display?
- Who are the primary target audiences (e.g., art enthusiasts, medical professionals, general public)?
- What are the potential ethical concerns or objections from each target audience?
- What specific language, imagery, and tone should be used to address these concerns?
- What are the key communication channels (e.g., press releases, museum website, social media) for disseminating the narrative?
- What are the specific goals for public perception (e.g., positive media coverage, high attendance, minimal controversy)?
- What are the metrics for measuring the success of the narrative (e.g., media sentiment analysis, visitor feedback, social media engagement)?
- What is the plan for responding to negative publicity or ethical challenges?
- What are the key talking points for interviews and public appearances?
- What visual elements (e.g., lighting, background, informational panels) will support the narrative?

**Risks of Poor Quality**:

- Negative public perception leading to protests or boycotts.
- Ethical backlash resulting in the display being removed.
- Failure to attract the desired audience.
- Damage to the client's reputation and legacy.
- Loss of investment due to lack of public interest.

**Worst Case Scenario**: The display is widely condemned as disrespectful and offensive, leading to its removal from the host institution and significant damage to the client's reputation.

**Best Case Scenario**: The display is positively received by the public and critics, generating significant interest and fostering a deeper understanding of the client's unique perspective on life and death, enabling informed decisions about the display's content and presentation.

**Fallback Alternative Approaches**:

- Consult with a PR/communications specialist to develop a more effective narrative.
- Conduct focus groups to test different narrative approaches.
- Simplify the narrative to focus on the most essential elements.
- Partner with an ethicist to address potential ethical concerns.
- Create a less controversial version of the display narrative.

## Create Document 5: Host Institution Selection Plan

**ID**: a7b17d35-2cac-4a29-9d54-e1d501a5b389

**Description**: A plan outlining the process for identifying and securing a suitable venue for the permanent public display of the skeleton.

**Responsible Role Type**: Project Owner

**Primary Template**: Institution Selection Criteria

**Secondary Template**: None

**Steps to Create**:

- Identify potential host institutions (niche museums, universities, private foundations).
- Define selection criteria (willingness to host, preservation conditions, alignment with goals).
- Research potential institutions and their requirements.
- Outline the negotiation process.
- Define success metrics for host institution selection.

**Approval Authorities**: Self

**Essential Information**:

- What are the specific criteria for evaluating potential host institutions (e.g., mission alignment, preservation capabilities, security measures, public accessibility, cost)?
- List potential host institutions in Copenhagen, Denmark, categorized by type (e.g., museums, galleries, universities, private foundations).
- What are the key contact persons at each potential host institution?
- Detail the proposed narrative framing and how it aligns with each institution's mission and values.
- Outline the negotiation strategy for securing a commitment from the chosen institution, including potential incentives (e.g., financial support, research opportunities).
- What are the key terms and conditions to be included in a legally binding agreement with the host institution (e.g., display duration, preservation responsibilities, security protocols, insurance coverage)?
- What are the alternative display options if the primary host institution is unavailable?
- What are the key performance indicators (KPIs) for evaluating the success of the host institution partnership (e.g., visitor attendance, media coverage, public feedback)?

**Risks of Poor Quality**:

- Failure to secure a suitable host institution, resulting in the skeleton not being publicly displayed.
- Selection of an institution that lacks the resources or commitment to properly preserve and maintain the display, leading to deterioration or removal.
- Ethical or reputational damage to the client's legacy due to misalignment with the institution's values or negative public perception.
- Legal challenges or disputes arising from unclear or unenforceable agreements with the host institution.

**Worst Case Scenario**: The skeleton cannot be publicly displayed due to the inability to find a suitable and willing host institution, resulting in the failure of the core project goal and the loss of investment in skeletal preparation and preservation.

**Best Case Scenario**: A reputable and well-suited host institution is secured, ensuring the long-term preservation, public accessibility, and positive reception of the skeletal display, fulfilling the client's vision and creating a lasting legacy.

**Fallback Alternative Approaches**:

- Broaden the search to include institutions outside of Copenhagen, Denmark.
- Consider establishing a private museum or gallery dedicated to the display.
- Explore temporary or rotating display options instead of a permanent installation.
- Consult with museum professionals or art curators for guidance on identifying and approaching potential host institutions.
- Create a detailed proposal package showcasing the project's artistic, educational, and cultural value to attract potential host institutions.

## Create Document 6: Trust Structure Design Plan

**ID**: 0687cf1c-93c4-4155-81d6-c484c0b1b373

**Description**: A plan outlining the financial framework for the project's long-term sustainability, including how funds will be managed and disbursed.

**Responsible Role Type**: Project Owner

**Primary Template**: Trust Design Outline

**Secondary Template**: Spreadsheet Budget Template

**Steps to Create**:

- Determine the optimal trust structure (charitable, spendthrift, hybrid).
- Outline the trust's governance and management.
- Define the trust's investment strategy.
- Estimate long-term funding needs.
- Consult with a financial advisor and tax attorney.

**Approval Authorities**: Self, Financial Advisor, Legal Counsel

**Essential Information**:

- What type of trust structure (irrevocable charitable, spendthrift, hybrid) best aligns with the project's goals and risk tolerance?
- Detail the governance structure of the trust, including the roles and responsibilities of trustees or board members.
- Outline the investment strategy for the trust, including asset allocation and risk management considerations.
- Calculate the estimated annual expenses for long-term preservation, maintenance, security, and potential legal challenges.
- Project the trust's ability to generate sufficient income to cover these expenses over the long term, considering inflation and potential economic downturns.
- Identify potential tax implications of the chosen trust structure on the estate and beneficiaries.
- Define the process for disbursing funds from the trust for specific project-related expenses.
- Specify any restrictions or limitations on the use of trust funds.
- Outline the process for amending or terminating the trust, if necessary.
- Detail the legal and regulatory requirements for establishing and maintaining the trust in Denmark.

**Risks of Poor Quality**:

- Insufficient funding for long-term preservation and maintenance.
- Vulnerability to legal challenges from family members or other parties.
- Inability to adapt to changing economic conditions or unforeseen expenses.
- Potential tax liabilities that could deplete trust assets.
- Lack of clear governance and oversight, leading to mismanagement or misuse of funds.
- Failure to comply with legal and regulatory requirements, resulting in penalties or dissolution of the trust.

**Worst Case Scenario**: The trust fails to generate sufficient income to cover ongoing expenses, leading to the deterioration or removal of the skeletal display and the failure to fulfill the client's wishes.

**Best Case Scenario**: The trust provides a stable and sustainable financial foundation for the project, ensuring its long-term preservation, public accessibility, and positive impact, while also minimizing legal and financial risks. Enables informed decisions about long-term financial planning and resource allocation.

**Fallback Alternative Approaches**:

- Consult with a financial advisor to explore alternative investment strategies or funding sources.
- Simplify the trust structure to reduce administrative costs and complexity.
- Reduce the scope of the project to lower long-term expenses.
- Seek pro bono legal assistance to minimize legal fees.
- Explore crowdfunding or other fundraising options to supplement trust income.

## Create Document 7: Long-Term Preservation Strategy Plan

**ID**: b21cfc73-b0bc-41d6-a7ab-c2bf43957c21

**Description**: A plan outlining the resources and methods used to ensure the skeleton's integrity and display for decades, combating degradation.

**Responsible Role Type**: Project Owner

**Primary Template**: Preservation Plan Template

**Secondary Template**: None

**Steps to Create**:

- Identify potential degradation factors (temperature, humidity, UV light).
- Define preservation methods (environmental control, cleaning, repairs).
- Outline the monitoring and maintenance schedule.
- Consult with a museum conservator.
- Define success metrics for long-term preservation.

**Approval Authorities**: Self, Museum Conservator

**Essential Information**:

- Identify specific degradation factors relevant to skeletal remains and display case materials (e.g., temperature fluctuations, humidity levels, UV light exposure, microbial growth).
- Detail the chosen preservation methods, including specific environmental control settings (temperature, humidity, UV light filtration), cleaning protocols, and repair techniques.
- Outline a detailed monitoring and maintenance schedule, specifying frequency of inspections, cleaning procedures, and component replacements.
- List the required equipment and supplies for long-term preservation (e.g., humidity sensors, UV light meters, specialized cleaning solutions, repair materials).
- Detail the process for securing funding for ongoing maintenance and potential repairs, including the trust's disbursement procedures.
- Define success metrics for long-term preservation, including acceptable levels of degradation, frequency of repairs, and overall condition of the skeleton and display case over time.
- Outline the process for documenting and tracking preservation efforts, including inspection reports, maintenance logs, and repair records.
- Specify the roles and responsibilities of individuals involved in the preservation process (e.g., museum conservator, maintenance personnel, trust manager).
- Detail the emergency response plan for addressing unexpected damage or deterioration, including contact information for relevant experts and procedures for securing the display case.

**Risks of Poor Quality**:

- Accelerated degradation of the skeleton and display case, leading to irreversible damage and loss of artistic integrity.
- Increased maintenance costs due to inadequate preservation measures.
- Potential for microbial growth or pest infestation, posing a biohazard risk.
- Loss of public interest and support due to the deteriorating condition of the display.
- Legal challenges from family members or regulatory bodies due to neglect of the display.

**Worst Case Scenario**: Complete deterioration of the skeleton and display case, resulting in the permanent removal of the display and loss of the client's legacy.

**Best Case Scenario**: Ensures the long-term integrity and stability of the skeleton and display case, allowing the client's vision to be realized for decades and fostering public engagement and appreciation.

**Fallback Alternative Approaches**:

- Consult with a museum conservator to develop a simplified preservation plan focusing on the most critical factors.
- Use a template for museum object preservation plans as a starting point.
- Prioritize preservation methods that are cost-effective and require minimal specialized expertise.
- Focus on preventive measures, such as environmental control and regular cleaning, rather than reactive repairs.
- Phase the implementation of the preservation plan, starting with the most essential elements and gradually adding more advanced measures as resources allow.

## Create Document 8: Estate Executor Nomination Plan

**ID**: ac6a42ad-4538-42b1-9f08-4672561e3766

**Description**: A plan outlining the process for selecting who will manage the estate and ensure the project's execution after death.

**Responsible Role Type**: Project Owner

**Primary Template**: Executor Nomination Outline

**Secondary Template**: None

**Steps to Create**:

- Identify potential executors (trust company, close friend, co-executor arrangement).
- Define selection criteria (competence, sympathy, impartiality).
- Consult with a legal specialist.
- Outline the executor's responsibilities.
- Define success metrics for estate executor nomination.

**Approval Authorities**: Self, Legal Counsel

**Essential Information**:

- Identify potential executors, considering a professional trust company, a close friend, or a co-executor arrangement.
- Define the specific criteria for selecting the executor, focusing on competence in estate management, sympathy towards the project's goals, and impartiality in handling family matters.
- Outline the executor's responsibilities, including managing the estate, overseeing the skeletal preparation and display, and resolving potential family disputes.
- Detail the process for formally nominating the executor, including necessary legal documentation and communication with relevant parties.
- Specify how the executor will be legally empowered to act decisively in accordance with the client's wishes, even in the face of potential objections.
- Describe the communication plan for informing the chosen executor of their responsibilities and the client's expectations.
- What are the specific legal requirements for executor nomination in Denmark?
- What are the potential conflicts of interest that need to be addressed when selecting an executor?
- What are the key performance indicators (KPIs) for evaluating the executor's performance?

**Risks of Poor Quality**:

- An executor who is unsympathetic to the project's goals may obstruct its execution or prioritize family objections over the client's wishes.
- An incompetent executor may mismanage the estate, leading to financial shortfalls or legal challenges that jeopardize the project.
- A poorly defined nomination process may result in legal challenges to the executor's authority, causing delays and increased costs.
- Lack of clear communication with the executor may lead to misunderstandings and misaligned priorities, hindering the project's progress.

**Worst Case Scenario**: The nominated executor actively sabotages the project due to personal objections or family pressure, leading to its complete abandonment and the loss of all invested funds.

**Best Case Scenario**: A highly competent and sympathetic executor efficiently manages the estate, navigates potential family disputes with grace, and ensures the project is executed flawlessly according to the client's wishes, resulting in a successful and impactful public display.

**Fallback Alternative Approaches**:

- Consult with an estate planning attorney to explore alternative executor nomination strategies.
- Establish a co-executor arrangement with a professional trust company and a trusted friend or family member.
- Create a detailed letter of instruction outlining the client's wishes and providing guidance to the executor.
- Secure a court order during the client's lifetime affirming the legality and enforceability of the post-mortem wishes, reducing the executor's potential liability.

## Create Document 9: Initial Risk List

**ID**: f7b5da6d-0b5b-4d28-9a98-12483ff594fb

**Description**: A list of potential risks that could impact the project, along with their likelihood, severity, and mitigation strategies.

**Responsible Role Type**: Project Owner

**Primary Template**: Risk Register Template

**Secondary Template**: None

**Steps to Create**:

- Identify potential risks (regulatory, social, ethical, financial, operational, biohazard, supply chain, security).
- Assess the likelihood and severity of each risk.
- Develop mitigation strategies for each risk.
- Assign responsibility for monitoring and managing each risk.

**Approval Authorities**: Self

**Essential Information**:

- List all potential risks to the project, categorized as regulatory, social, ethical, technical, financial, operational, biohazard, supply chain, and security.
- For each risk, estimate the likelihood (e.g., low, medium, high) and severity (e.g., low, medium, high) of its impact on the project.
- Outline specific mitigation strategies for each identified risk, detailing concrete actions to reduce the likelihood or severity of the risk.
- Identify the responsible party or role for monitoring and managing each risk.
- Detail the potential financial impact (in DKK) of each risk if it materializes.
- Specify triggers or warning signs that indicate a risk is becoming more likely or severe.
- Include a summary table ranking risks by severity and likelihood to prioritize mitigation efforts.
- Based on the 'Pioneer's Gambit' scenario, highlight risks that are amplified or mitigated by this strategic choice.
- Incorporate insights from the 'Review Assumptions' section of assumptions.md, particularly regarding family conflict, financial sustainability, and host institution commitment.
- Address the specific risks identified in the project-plan.md file, such as regulatory hurdles, family objections, and ethical concerns.

**Risks of Poor Quality**:

- Failure to identify critical risks leads to inadequate preparation and reactive problem-solving.
- Inaccurate risk assessments result in misallocation of resources and ineffective mitigation strategies.
- Vague or incomplete mitigation plans leave the project vulnerable to unforeseen challenges.
- Lack of assigned responsibility leads to delayed responses and unmanaged risks.
- Underestimating financial impacts results in budget overruns and project delays.
- Ignoring interdependencies between risks leads to cascading failures.
- An outdated risk list fails to account for evolving project conditions.

**Worst Case Scenario**: Unforeseen legal challenges, ethical objections, or financial shortfalls derail the project completely, resulting in the inability to fulfill the client's wishes and significant financial loss.

**Best Case Scenario**: Proactive risk management ensures smooth project execution, minimizes disruptions, and maximizes the likelihood of achieving the client's vision within budget and timeline, leading to a successful and impactful public display.

**Fallback Alternative Approaches**:

- Use a pre-existing risk register template and adapt it to the specific project context.
- Brainstorm potential risks with a team of stakeholders to gather diverse perspectives.
- Consult with experts in relevant fields (legal, ethical, biohazard) to identify potential risks.
- Focus on identifying the top 3-5 most critical risks and developing detailed mitigation plans for those.
- Start with a high-level risk list and iteratively refine it as the project progresses.

## Create Document 10: High-Level Budget

**ID**: e25003f4-9a25-4daf-84ff-c17b04bdb48f

**Description**: A high-level estimate of the project's costs, including legal fees, osteologist services, display case fabrication, and long-term preservation.

**Responsible Role Type**: Project Owner

**Primary Template**: Spreadsheet Budget Template

**Secondary Template**: None

**Steps to Create**:

- Identify cost categories (legal fees, osteologist services, display case fabrication, etc.).
- Estimate costs for each category.
- Allocate contingency funds.
- Review and approve the budget.

**Approval Authorities**: Self

**Essential Information**:

- List all anticipated expense categories (e.g., legal, mortuary, osteologist, display case, institution fees, trust management, family counseling, PR).
- Estimate the cost for each expense category, providing a range (low, medium, high) where uncertainty exists.
- Allocate a contingency fund (as a percentage or fixed amount) to cover unexpected expenses.
- Detail the assumptions underlying each cost estimate (e.g., hourly rate for legal counsel, material costs for display case).
- Outline the payment schedule for each vendor or service provider.
- Calculate the total estimated project cost, including contingency.
- Identify potential sources of cost overruns and mitigation strategies.
- Specify the currency (DKK) and any potential currency exchange risks.
- Requires review of quotes from potential vendors (mortuary, osteologist, display case fabricator).
- Requires consultation with legal counsel to estimate legal fees.

**Risks of Poor Quality**:

- Underestimating costs leads to budget overruns and project delays.
- Inaccurate cost estimates result in scope reduction or project abandonment.
- Failure to allocate sufficient contingency funds leaves the project vulnerable to unexpected expenses.
- Lack of transparency in cost assumptions makes it difficult to track and manage expenses.
- Poor budget management leads to financial strain and potential legal challenges.

**Worst Case Scenario**: The project runs out of funds before completion, resulting in the abandonment of the skeletal preparation and display, and potential legal battles over unpaid bills.

**Best Case Scenario**: The project is completed within budget, ensuring the long-term preservation and public display of the skeleton, while also providing financial security for ongoing maintenance and potential legal challenges. Enables informed decisions on resource allocation and scope management.

**Fallback Alternative Approaches**:

- Use a simplified budget template or online budgeting tool.
- Consult with a financial advisor or project management expert for assistance.
- Prioritize essential expenses and defer non-essential costs.
- Seek pro bono legal assistance or negotiate fixed fees with vendors.
- Reduce the scope of the project to align with available funding.


# Documents to Find

## Find Document 1: Danish Body Disposition Law Data

**ID**: ccb144a1-af54-4cd9-a8d3-2311d19d4c59

**Description**: Official Danish laws and regulations regarding body disposition, anatomical gifts, and public display of human remains. Needed to understand legal constraints and requirements.

**Recency Requirement**: Most recent version available

**Responsible Role Type**: Project Owner

**Steps to Find**:

- Search the official Danish government website for legal information.
- Consult with a legal specialist in Danish law.
- Review relevant legal databases and publications.

**Access Difficulty**: Medium: Requires knowledge of Danish legal system and language skills.

**Essential Information**:

- What specific Danish laws govern the post-mortem treatment and display of human remains?
- What are the legal requirements for obtaining permission to prepare a human skeleton for public display?
- Are there any restrictions on the pose or presentation of human remains in public displays?
- What legal precedents exist in Denmark regarding similar cases of unconventional body disposition?
- What are the potential legal liabilities associated with the public display of human remains in Denmark?
- What are the specific requirements for obtaining a body disposition permit in Copenhagen?
- What constitutes legal authorization from the deceased and/or their family for this type of project?
- List the specific sections of Danish law that pertain to anatomical gifts and their public display.
- Identify any specific ethical guidelines or legal interpretations related to the display of human remains for artistic or educational purposes.
- Detail the process for obtaining a court order to affirm the legality of the project, including required documentation and potential challenges.

**Risks of Poor Quality**:

- Failure to comply with Danish body disposition laws could result in legal challenges, project delays, and significant financial penalties.
- Inaccurate interpretation of legal requirements could lead to the project being blocked or shut down after significant investment.
- Ignoring ethical considerations could result in negative publicity and damage to the project's reputation.
- Misunderstanding the legal rights of family members could lead to legal battles and strained relationships.
- Lack of clarity on legal requirements could lead to delays in obtaining necessary permits and approvals.

**Worst Case Scenario**: The project is deemed illegal under Danish law, resulting in the seizure of the prepared skeleton, legal penalties, and complete abandonment of the public display plan, leading to significant financial loss and reputational damage.

**Best Case Scenario**: The project receives full legal authorization and support from Danish authorities, ensuring a smooth and legally sound execution of the plan, fostering public understanding and acceptance of the unconventional memorialization.

**Fallback Alternative Approaches**:

- Consult with a Danish legal expert specializing in body disposition law.
- Seek guidance from the Danish Health Authority on specific legal requirements.
- Research similar cases in other countries with more permissive laws regarding body disposition.
- Modify the project to align with existing legal frameworks, such as focusing on educational aspects rather than artistic expression.
- Abandon the public display plan and explore alternative forms of memorialization that are legally permissible.

## Find Document 2: List of Licensed Mortuary Facilities in Copenhagen

**ID**: e1c11882-6418-45b7-a0f0-af70f2271ed6

**Description**: A list of licensed mortuary facilities in Copenhagen that are equipped for biohazard management and skeletal preparation. Needed to identify potential vendors.

**Recency Requirement**: Updated within the last year

**Responsible Role Type**: Project Owner

**Steps to Find**:

- Contact the Danish Health Authority.
- Search online directories of mortuary facilities.
- Consult with funeral homes in Copenhagen.

**Access Difficulty**: Medium: Requires contacting government agencies or industry associations.

**Essential Information**:

- List of all licensed mortuary facilities in Copenhagen.
- For each facility, identify their specific certifications and licenses related to biohazard handling (BSL-2 or higher).
- For each facility, detail their experience with skeletal preparation or similar procedures.
- For each facility, list their available equipment and facilities relevant to biohazard containment and skeletal processing.
- For each facility, provide contact information (address, phone number, email).
- For each facility, identify their capacity to handle the skeletal preparation timeline.
- For each facility, detail their waste disposal methods and compliance with environmental regulations.
- For each facility, list any affiliations with universities or research institutions.
- For each facility, identify their willingness to accommodate the unusual nature of the request.

**Risks of Poor Quality**:

- Selecting a facility without proper licensing or equipment could lead to biohazard exposure and legal liabilities.
- Choosing a facility with limited experience in skeletal preparation could result in damage to the remains or an unsatisfactory outcome.
- Failure to comply with environmental regulations could result in fines and negative publicity.
- Selecting a facility that is unwilling to accommodate the unusual nature of the request could result in delays or project abandonment.

**Worst Case Scenario**: Legal action due to improper handling of biohazardous materials, project abandonment due to lack of suitable facilities, and significant financial loss.

**Best Case Scenario**: Secure a highly reputable and experienced mortuary facility that ensures the safe and ethical handling of the body, adheres to all regulations, and contributes to the successful completion of the project.

**Fallback Alternative Approaches**:

- Expand the search area to include mortuary facilities outside of Copenhagen, if necessary.
- Consult with forensic science experts at Copenhagen University Hospital for recommendations.
- Contact international mortuary facilities with expertise in skeletal preparation and explore the possibility of transporting the body.
- Engage a biohazard safety consultant to assess the capabilities of local facilities and recommend necessary upgrades or modifications.

## Find Document 3: List of Osteologists/Anatomical Preparators

**ID**: c6a71cbb-1d9b-4dbb-bd39-faf2745c902b

**Description**: A list of qualified osteologists or anatomical preparators with experience in skeletal preparation and articulation. Needed to identify potential experts.

**Recency Requirement**: Updated within the last 2 years

**Responsible Role Type**: Project Owner

**Steps to Find**:

- Contact universities and research institutions with anatomy or forensic science programs in Denmark.
- Search online directories of medical professionals.
- Consult with museums and galleries that display skeletal remains.

**Access Difficulty**: Medium: Requires contacting academic institutions and professional organizations.

**Essential Information**:

- Identify at least three osteologists or anatomical preparators with a minimum of 5 years of experience in skeletal preparation, specifically articulation and preservation.
- Detail their specific experience with human skeletal remains, including any prior projects involving public display.
- List their certifications or qualifications in anatomical preservation or related fields.
- Provide contact information (phone number, email address, website) for each candidate.
- Outline their fee structure, including hourly rates, project-based fees, and any associated costs (e.g., travel, materials).
- Assess their familiarity with Danish regulations regarding body disposition and biohazard management.
- Determine their availability within the project's 12-18 month timeline.
- Gather references from previous clients or institutions they have worked with.

**Risks of Poor Quality**:

- Engaging an unqualified osteologist leads to improper skeletal preparation, compromising anatomical accuracy and aesthetic appeal.
- Poor preservation techniques result in accelerated deterioration of the skeleton, shortening its lifespan and increasing maintenance costs.
- Lack of experience with public display projects leads to ethical or logistical challenges during installation and maintenance.
- Failure to comply with Danish regulations results in legal penalties and project delays.

**Worst Case Scenario**: The project is abandoned due to irreversible damage to the skeleton caused by improper preparation, resulting in a complete loss of investment and failure to fulfill the client's wishes.

**Best Case Scenario**: A highly skilled and experienced osteologist prepares the skeleton to museum-quality standards, ensuring its long-term preservation and contributing to a compelling and ethically sound public display that honors the client's vision.

**Fallback Alternative Approaches**:

- Expand the search to include anatomical preparators in neighboring countries (e.g., Sweden, Germany) who may be willing to travel to Copenhagen.
- Consult with forensic anthropologists or anatomists at Copenhagen University Hospital for recommendations.
- Contact international organizations specializing in skeletal biology or anatomical preservation for referrals.
- Consider engaging a less experienced preparator under the supervision of a senior expert to reduce costs while ensuring quality.

## Find Document 4: List of Potential Host Institutions in Copenhagen

**ID**: 02f35546-ab8f-4b8d-b94b-f749294a7aab

**Description**: A list of potential host institutions in Copenhagen that may be willing to display the skeleton, including museums, galleries, and universities. Needed to identify potential venues.

**Recency Requirement**: Updated within the last year

**Responsible Role Type**: Project Owner

**Steps to Find**:

- Search online directories of museums and galleries in Copenhagen.
- Contact universities and research institutions with anatomy or forensic science programs.
- Consult with cultural organizations in Copenhagen.

**Access Difficulty**: Easy: Publicly available information.

**Essential Information**:

- Identify at least five potential host institutions in Copenhagen suitable for displaying the skeleton.
- For each institution, list the contact person, their title, email address, and phone number.
- Detail the institution's mission statement and its alignment with the project's goals (unconventional memorialization, zombie theme, anatomical education).
- Describe the institution's existing exhibits and visitor demographics.
- Outline the institution's security measures and environmental control capabilities for preserving artifacts.
- Specify the institution's policies regarding controversial or unusual exhibits.
- Estimate the potential cost of hosting the display at each institution (e.g., rental fees, maintenance costs).
- Summarize any prior experience the institution has with displaying human remains or similar controversial exhibits.
- Document any specific requirements or restrictions the institution might have regarding the display (e.g., size limitations, content restrictions).

**Risks of Poor Quality**:

- Selecting an unsuitable host institution leads to rejection and project delays.
- Inadequate security or environmental controls result in damage or theft of the skeleton.
- Misalignment with the institution's mission leads to negative publicity or ethical concerns.
- Underestimating costs leads to budget overruns and potential project abandonment.
- Failure to identify a viable host institution results in the project's indefinite postponement.

**Worst Case Scenario**: The project fails because no suitable host institution can be found in Copenhagen, leading to the abandonment of the client's wishes and the loss of invested funds.

**Best Case Scenario**: A reputable and well-suited institution is secured, ensuring the long-term preservation and public accessibility of the display, fulfilling the client's vision and generating positive public engagement.

**Fallback Alternative Approaches**:

- Broaden the search to include institutions outside of Copenhagen, potentially in other parts of Denmark or Europe.
- Consider establishing a private museum or gallery dedicated to the display.
- Consult with art curators or museum consultants for advice on identifying and approaching potential host institutions.
- Simplify the display requirements to make it more appealing to a wider range of institutions.
- Re-evaluate the project's goals and consider alternative forms of memorialization if a suitable host institution cannot be found.

## Find Document 5: Examples of Trust Agreements in Denmark

**ID**: 3ce5110b-a348-4843-abd2-e8f166d7c662

**Description**: Examples of trust agreements used in Denmark, including charitable trusts and spendthrift trusts. Needed to understand legal requirements and best practices.

**Recency Requirement**: Within the last 5 years

**Responsible Role Type**: Project Owner

**Steps to Find**:

- Consult with a legal specialist in Danish trust law.
- Search legal databases for sample trust agreements.
- Consult with financial advisors who specialize in trust management.

**Access Difficulty**: Hard: Requires legal expertise and access to legal databases.

**Essential Information**:

- Identify the legal requirements for establishing a trust in Denmark, including necessary clauses and provisions.
- List examples of charitable trust agreements used in Denmark, detailing their structure and purpose.
- List examples of spendthrift trust agreements used in Denmark, detailing their structure and purpose.
- Detail the tax implications of different trust structures in Denmark for both the estate and beneficiaries.
- Identify any specific regulations or restrictions on trusts designed for unconventional purposes, such as funding a public art display.
- What are the standard fees associated with establishing and maintaining different types of trusts in Denmark?
- What are the legal requirements for appointing trustees and managing trust assets in Denmark?
- What are the common causes of legal challenges to trusts in Denmark, and how can they be avoided?

**Risks of Poor Quality**:

- A poorly structured trust could be vulnerable to legal challenges from family members, potentially dissolving the trust and halting the project.
- Insufficient funds within the trust could lead to inadequate maintenance and preservation of the skeleton, resulting in its deterioration or removal from display.
- Failure to comply with Danish trust laws could result in legal penalties and invalidate the trust.
- Inadequate tax planning could result in significant tax liabilities for the estate or beneficiaries, reducing the funds available for the project.

**Worst Case Scenario**: The trust is successfully challenged in court, leading to its dissolution. The funds intended for the project are distributed to other beneficiaries, and the project is abandoned due to lack of financial resources. The client's wishes are not fulfilled, and the skeleton is not publicly displayed.

**Best Case Scenario**: A legally sound and financially robust trust is established, ensuring the long-term funding and preservation of the skeletal display. The trust successfully withstands any legal challenges, and the project is executed according to the client's wishes, resulting in a lasting and impactful public display.

**Fallback Alternative Approaches**:

- Consult with a Danish legal specialist to draft a custom trust agreement tailored to the specific requirements of the project.
- Seek advice from financial advisors specializing in trust management to develop a diversified investment strategy for the trust.
- Explore alternative funding sources, such as grants or donations, to supplement the trust funds.
- Simplify the project scope to reduce costs and ensure financial sustainability within the existing budget.