# Purpose

**Purpose:** personal

**Purpose Detailed:** Planning for the preparation, preservation, and public display of one's skeleton after death, including legal, ethical, biohazard, and logistical considerations.

**Topic:** Post-mortem skeletal preparation and public display

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** This plan *unequivocally requires* physical actions and locations. It involves legal consultation, mortuary services, biohazard management, skeletal preparation by an osteologist, custom display case fabrication, and finding a physical location for permanent public display in Copenhagen. The entire process is rooted in physical actions and locations.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- licensed mortuary facility for skeletal preparation
- host institution for permanent display
- legal expertise in body disposition law in Denmark

## Location 1
Denmark

Copenhagen

Various licensed mortuary facilities in Copenhagen

**Rationale**: Copenhagen has several licensed mortuary facilities equipped to handle biohazard management and skeletal preparation, ensuring compliance with legal and ethical standards.

## Location 2
Denmark

Copenhagen

Copenhagen University Hospital

**Rationale**: This hospital has a strong forensic science program and may provide the necessary expertise for biohazard management and skeletal preparation.

## Location 3
Denmark

Copenhagen

The Medical Museum, Copenhagen

**Rationale**: The Medical Museum is a potential host institution that specializes in anatomical specimens and could be receptive to displaying the skeleton as part of its collection.

## Location Summary
The project requires physical locations in Copenhagen for legal consultation, mortuary services, and a host institution for the permanent display of the skeleton. Suggested locations include licensed mortuary facilities, Copenhagen University Hospital for expertise, and The Medical Museum for display.

# Currency Strategy

This plan involves money.

## Currencies

- **DKK:** Local currency for all expenses in Denmark, including legal fees, osteologist services, mortuary facility, display case fabrication, biohazard compliance, grief counseling, and a preservation endowment.

**Primary currency:** DKK

**Currency strategy:** The Danish Krone (DKK) will be used for all transactions. No additional international risk management is needed.

# Identify Risks


## Risk 1 - Regulatory & Permitting
Danish body disposition laws may not explicitly permit the requested skeletal preparation and public display, leading to legal challenges or denial of permits. The novelty of the request could result in unforeseen regulatory hurdles.

**Impact:** Project halt, legal battles, significant delays (6-12 months), additional legal fees of 50,000-100,000 DKK.

**Likelihood:** Medium

**Severity:** High

**Action:** Engage a Danish attorney specializing in body disposition law to thoroughly research and navigate relevant regulations. Secure pre-approval or a court order during the client's lifetime to validate the legality of the project. The chosen 'Pioneer's Gambit' scenario emphasizes this.

## Risk 2 - Social
Family members may strongly object to the skeletal preparation and public display, leading to legal challenges to the will, emotional distress, and negative publicity. The 'Pioneer's Gambit' scenario acknowledges this risk but doesn't fully mitigate it.

**Impact:** Legal challenges, project delays (3-6 months), increased legal fees (25,000-50,000 DKK), strained family relationships, negative media coverage.

**Likelihood:** Medium

**Severity:** High

**Action:** Implement a proactive family communication strategy involving a grief counselor or mediator. Create a video message from the client explaining their wishes. Explore offering family members a role in the project's execution to foster a sense of involvement. The chosen scenario includes a video message, but proactive engagement is crucial.

## Risk 3 - Ethical
The public display of a human skeleton in a zombie-like pose may be perceived as disrespectful, offensive, or unethical, leading to negative media coverage, public protests, or pressure on the host institution to remove the display.

**Impact:** Negative media coverage, public protests, damage to reputation, potential removal of the display, loss of investment.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a comprehensive public relations strategy to frame the display as a unique form of personal expression and memorialization. Partner with the host institution to create educational materials and programming that address ethical concerns. The 'Pioneer's Gambit' scenario includes narrative framing, but proactive engagement is crucial.

## Risk 4 - Technical
The skeletal preparation process may be more complex or time-consuming than anticipated, leading to delays and increased costs. Achieving the desired zombie-like pose while maintaining anatomical accuracy and structural integrity may be technically challenging.

**Impact:** Project delays (2-4 weeks), increased osteologist fees (10,000-20,000 DKK), potential need for additional expertise.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Engage an experienced osteologist with a proven track record of skeletal preparation and articulation. Develop a detailed skeletal pose design in advance, consulting with anatomical experts and sculptors. The 'Osteological Scope Definition' lever is relevant here.

## Risk 5 - Financial
The project costs may exceed the allocated budget of 1.5 million DKK due to unforeseen expenses, cost overruns, or the need for additional services. The preservation endowment may be insufficient to cover long-term maintenance costs.

**Impact:** Project delays, reduced scope, need for additional funding, potential abandonment of the project.

**Likelihood:** Medium

**Severity:** High

**Action:** Develop a detailed budget with contingency funds. Secure firm quotes from all vendors. Establish a robust trust structure to ensure long-term financial sustainability. The 'Trust Structure Design' lever is critical here.

## Risk 6 - Operational
The host institution may be unwilling or unable to provide adequate preservation conditions or security measures, leading to deterioration of the skeleton or theft/vandalism. The institution may later decide to remove the display due to changing priorities or ethical concerns.

**Impact:** Deterioration of the skeleton, theft/vandalism, removal of the display, loss of investment.

**Likelihood:** Low

**Severity:** High

**Action:** Carefully vet potential host institutions, ensuring their commitment to long-term preservation and security. Negotiate a legally binding agreement that guarantees the display's permanent placement and maintenance. The 'Host Institution Selection' lever is critical here.

## Risk 7 - Biohazard
Inadequate biohazard management during the decomposition and preparation phase could expose personnel to infectious agents, leading to health risks and legal liabilities.

**Impact:** Health risks to personnel, legal liabilities, project delays, increased costs.

**Likelihood:** Low

**Severity:** High

**Action:** Develop and implement a comprehensive biohazard mitigation protocol in consultation with a certified industrial hygienist. Select a mortuary facility with a proven track record of biohazard safety. The 'Biohazard Mitigation Protocol' and 'Mortuary Vendor Diligence' levers are relevant here.

## Risk 8 - Supply Chain
The custom-designed display case may be delayed or not meet specifications, leading to project delays and increased costs.

**Impact:** Project delays (1-2 months), increased costs (5,000-10,000 DKK), need for alternative display solutions.

**Likelihood:** Low

**Severity:** Medium

**Action:** Select a reputable display case fabricator with a proven track record. Develop detailed specifications and quality control procedures. Establish a contingency plan in case of delays or defects.

## Risk 9 - Security
The display case may be vulnerable to theft or vandalism, leading to damage or loss of the skeleton.

**Impact:** Damage or loss of the skeleton, reputational damage, financial loss.

**Likelihood:** Low

**Severity:** High

**Action:** Integrate robust security features into the display case, including reinforced glass, motion sensors, and alarms. Coordinate security measures with the host institution. The 'Display Case Security Measures' lever is relevant here.

## Risk summary
The most critical risks are legal challenges from family members, ethical objections from the public, and financial sustainability. The 'Pioneer's Gambit' scenario prioritizes legal defensibility and unconventional display, but requires careful management of family relations and public perception. A robust trust structure is essential to ensure long-term funding for preservation and potential legal battles. Trade-offs exist between prioritizing the client's artistic vision and mitigating potential negative consequences. The chosen scenario's success hinges on securing a court order and proactively managing public perception.

# Make Assumptions


## Question 1 - What specific funding allocation is planned for legal fees associated with defending the will against potential family challenges, and what contingency plans are in place if these costs exceed initial estimates?

**Assumptions:** Assumption: 200,000 DKK is allocated for legal fees, with a contingency fund of 50,000 DKK available for unexpected legal challenges. This is based on average legal costs for estate disputes in Denmark.

**Assessments:** Title: Financial Feasibility Assessment
Description: Evaluation of the adequacy of the allocated budget for legal fees and contingency planning.
Details: The initial allocation of 200,000 DKK for legal fees may be insufficient if family challenges are extensive. The contingency fund of 50,000 DKK provides a buffer, but a more detailed cost breakdown is needed. Risk: Legal costs exceeding budget. Impact: Project delays, reduced scope. Mitigation: Secure pro bono legal assistance, explore alternative dispute resolution methods. Opportunity: Negotiate fixed legal fees upfront.

## Question 2 - What is the detailed timeline for securing the necessary legal authorizations, including key milestones for drafting the will, obtaining court orders (if applicable), and finalizing agreements with the chosen mortuary and host institution?

**Assumptions:** Assumption: Securing legal authorizations, including a court order, will take approximately 6 months. This is based on typical processing times for legal proceedings in Denmark.

**Assessments:** Title: Timeline & Milestones Assessment
Description: Evaluation of the feasibility of the proposed timeline for securing legal authorizations.
Details: A 6-month timeline for legal authorizations is aggressive, especially if a court order is pursued. Risk: Delays in legal proceedings. Impact: Project delays, potential loss of momentum. Mitigation: Expedite legal processes, secure priority scheduling. Opportunity: Streamline legal documentation, leverage existing legal precedents.

## Question 3 - What specific expertise and certifications are required for the osteologist responsible for skeletal preparation, and how will their qualifications be verified to ensure anatomical accuracy and artistic quality?

**Assumptions:** Assumption: The osteologist will possess a minimum of 5 years of experience in skeletal preparation and articulation, with certifications in anatomical preservation techniques. This aligns with industry standards for professional osteologists.

**Assessments:** Title: Resources & Personnel Assessment
Description: Evaluation of the qualifications and expertise of the osteologist.
Details: Ensuring the osteologist has the required expertise is crucial for the project's success. Risk: Inadequate skills, poor quality preparation. Impact: Anatomical inaccuracies, aesthetic flaws. Mitigation: Conduct thorough background checks, review portfolios. Opportunity: Partner with a university-affiliated osteology lab for access to advanced resources.

## Question 4 - What specific Danish regulations govern body disposition and skeletal display, and how will the project ensure full compliance with these laws to avoid legal challenges or ethical violations?

**Assumptions:** Assumption: Danish body disposition laws allow for skeletal preparation and public display with proper legal authorization and ethical considerations. This is based on preliminary legal research.

**Assessments:** Title: Governance & Regulations Assessment
Description: Evaluation of the legal and regulatory framework governing body disposition and skeletal display in Denmark.
Details: Compliance with Danish regulations is paramount. Risk: Legal challenges, ethical violations. Impact: Project halt, legal penalties. Mitigation: Engage legal counsel, secure necessary permits. Opportunity: Advocate for clearer regulations, establish legal precedents.

## Question 5 - What specific biohazard safety protocols will be implemented during the skeletal preparation process, including PPE requirements, waste disposal procedures, and emergency response plans, to minimize risks to personnel and the environment?

**Assumptions:** Assumption: The mortuary facility will adhere to Biosafety Level 2 (BSL-2) standards for handling human remains, including appropriate PPE, waste disposal, and decontamination procedures. This is a standard safety protocol for mortuary facilities.

**Assessments:** Title: Safety & Risk Management Assessment
Description: Evaluation of the biohazard safety protocols and risk mitigation strategies.
Details: Biohazard safety is a critical concern. Risk: Exposure to infectious agents, environmental contamination. Impact: Health risks, legal liabilities. Mitigation: Implement strict safety protocols, conduct regular inspections. Opportunity: Partner with a biohazard safety consultant for expert guidance.

## Question 6 - What measures will be taken to minimize the environmental impact of the skeletal preparation process, including waste disposal, chemical usage, and energy consumption, to ensure sustainable practices?

**Assumptions:** Assumption: Environmentally friendly decomposition methods, such as enzymatic digestion, will be prioritized to minimize chemical usage and waste disposal. This aligns with sustainable practices in mortuary science.

**Assessments:** Title: Environmental Impact Assessment
Description: Evaluation of the environmental impact of the skeletal preparation process.
Details: Minimizing environmental impact is important. Risk: Pollution, resource depletion. Impact: Negative publicity, regulatory penalties. Mitigation: Use eco-friendly methods, recycle waste. Opportunity: Promote sustainable practices, reduce carbon footprint.

## Question 7 - What is the detailed strategy for engaging with immediate family members, including the use of a grief counselor or mediator, to address their concerns and obtain their consent for the skeletal preparation and public display?

**Assumptions:** Assumption: Family members will be open to engaging in facilitated discussions with a grief counselor or mediator to address their concerns and potentially reach a consensus. This is based on the assumption that family members value open communication.

**Assessments:** Title: Stakeholder Involvement Assessment
Description: Evaluation of the family engagement strategy and its potential impact on project success.
Details: Family consent is crucial for minimizing legal challenges. Risk: Family objections, legal disputes. Impact: Project delays, increased costs. Mitigation: Engage a grief counselor, offer family involvement. Opportunity: Build consensus, foster understanding.

## Question 8 - What specific operational systems will be implemented to track and manage the skeletal preparation process, including chain of custody documentation, inventory management, and quality control procedures, to ensure accountability and transparency?

**Assumptions:** Assumption: A digital chain-of-custody system will be used to track the skeleton from death to final display, ensuring accountability and preventing loss or damage. This is a standard practice in forensic science and art handling.

**Assessments:** Title: Operational Systems Assessment
Description: Evaluation of the operational systems for tracking and managing the skeletal preparation process.
Details: Robust operational systems are essential for accountability. Risk: Loss of control, data breaches. Impact: Legal liabilities, reputational damage. Mitigation: Implement digital tracking, conduct regular audits. Opportunity: Improve efficiency, enhance transparency.

# Distill Assumptions

- 200,000 DKK is allocated for legal fees, with a 50,000 DKK contingency.
- Securing legal authorizations, including a court order, will take approximately 6 months.
- Osteologist will have 5 years of experience and certifications in anatomical preservation.
- Danish body disposition laws allow skeletal preparation and display with proper authorization.
- Mortuary will adhere to Biosafety Level 2 (BSL-2) standards for handling remains.
- Environmentally friendly decomposition methods will be prioritized to minimize chemical usage.
- Family will engage in discussions with a counselor to address concerns and reach consensus.
- A digital chain-of-custody system will track the skeleton from death to display.

# Review Assumptions

## Domain of the expert reviewer
Project Management, Risk Management, and Legal Compliance

## Domain-specific considerations

- Legal and ethical compliance in Denmark regarding body disposition
- Stakeholder management, particularly family communication and potential conflicts
- Long-term financial sustainability and preservation of the display
- Biohazard mitigation and safety protocols

## Issue 1 - Inadequate Assessment of Family Conflict and Mitigation Strategies
While the plan acknowledges the risk of family objections, the assumption that family members will be open to facilitated discussions may be overly optimistic. The 'Pioneer's Gambit' scenario, while bold, could exacerbate family tensions if not handled delicately. The plan lacks concrete strategies for addressing scenarios where family objections remain irreconcilable even after mediation. This could lead to protracted legal battles, significantly delaying the project and increasing costs.

**Recommendation:** Develop a detailed family conflict resolution plan that includes: (1) A pre-mortem family meeting facilitated by a neutral third party to openly discuss the client's wishes and address concerns. (2) A clear escalation path for resolving disputes, including mediation and, if necessary, legal action. (3) A communication protocol for keeping family members informed throughout the project's execution. (4) Explore offering family members a role in the project, such as selecting the display case or contributing to the narrative, to foster a sense of involvement and ownership. (5) Secure written consent from all immediate family members, if possible, to minimize the risk of legal challenges.

**Sensitivity:** Failure to adequately address family conflict could result in legal challenges that delay the project by 6-12 months and increase legal costs by 100,000-300,000 DKK (baseline legal cost: 200,000 DKK). This could also negatively impact the project's ROI by 5-10% due to increased expenses and delayed public display.

## Issue 2 - Insufficient Detail Regarding Long-Term Financial Sustainability
The plan assumes that the trust structure will ensure long-term financial sustainability, but it lacks specific details on how the trust will generate income and cover ongoing maintenance costs. The plan does not address the potential impact of inflation, economic downturns, or unexpected expenses on the trust's ability to fund the project's long-term preservation. The plan also does not address the tax implications of the trust structure on the estate and beneficiaries.

**Recommendation:** Conduct a detailed financial analysis to determine the long-term funding needs of the project, including preservation, maintenance, security, insurance, and potential legal fees. Develop a diversified investment strategy for the trust to generate sufficient income to cover these costs, considering various economic scenarios. Establish a reserve fund within the trust to address unexpected expenses. Consult with a financial advisor and tax attorney to optimize the trust structure for tax efficiency and long-term sustainability. Explore options for securing additional funding through grants, donations, or sponsorships.

**Sensitivity:** If the trust fails to generate sufficient income, the project could face funding shortfalls that jeopardize its long-term preservation and public display. A 10% shortfall in funding could result in a 2-3% reduction in the project's ROI and potentially lead to the removal of the display within 5-10 years. Underestimating long-term costs by 20% could result in the project being abandoned.

## Issue 3 - Lack of Contingency Planning for Host Institution Withdrawal
The plan assumes that the chosen host institution will remain committed to displaying the skeleton permanently, but it lacks contingency plans for scenarios where the institution may withdraw its support due to changing priorities, ethical concerns, or financial difficulties. This could leave the project without a venue for public display, undermining its core purpose.

**Recommendation:** Develop a contingency plan that includes: (1) Identifying alternative host institutions in advance and establishing relationships with them. (2) Negotiating a legally binding agreement with the chosen host institution that includes clauses addressing potential withdrawal and ensuring the project's continued display. (3) Establishing a fund within the trust to cover the costs of relocating the display to a new venue if necessary. (4) Exploring options for creating a private museum or gallery to house the display if no suitable host institution can be found.

**Sensitivity:** If the host institution withdraws its support, the project could face significant costs associated with relocating the display, potentially ranging from 50,000 to 100,000 DKK. This could also delay the project's ROI by 1-2 years and negatively impact its public visibility.

## Review conclusion
The plan is ambitious and innovative, but it requires more robust risk mitigation strategies, particularly in the areas of family conflict, long-term financial sustainability, and host institution commitment. Addressing these issues proactively will significantly increase the likelihood of project success and ensure the client's vision is realized.