## Suggestion 1 - Body Worlds Exhibition

Body Worlds is a traveling exhibition of preserved human bodies and body parts, created through a process called plastination to reveal inner anatomical structures. The exhibition aims to educate the public about the human body, health, and disease. It has been displayed in numerous cities worldwide, attracting millions of visitors.

### Success Metrics

High attendance rates (millions of visitors worldwide)
Positive educational impact (demonstrated through visitor surveys and educational programs)
Long-term sustainability (exhibition has been running for over 20 years)
Successful navigation of ethical and legal challenges in various countries

### Risks and Challenges Faced

Ethical concerns regarding the use of human bodies for public display: Overcome by obtaining informed consent from donors and emphasizing the educational purpose of the exhibition.
Legal challenges related to body donation and display regulations in different countries: Mitigated by working closely with legal experts in each jurisdiction to ensure compliance.
Public criticism and protests from religious or cultural groups: Addressed through open dialogue, transparency, and emphasizing the scientific and educational value of the exhibition.
Preservation challenges related to maintaining the plastinated bodies in good condition: Managed through strict environmental controls and regular maintenance.

### Where to Find More Information

Official Body Worlds website: [https://bodyworlds.com/](https://bodyworlds.com/)
Gunther von Hagens' website: [https://www.koerperwelten.de/en/](https://www.koerperwelten.de/en/)
Academic articles and media reports on the ethical and educational aspects of Body Worlds

### Actionable Steps

Contact the Body Worlds organization through their website to inquire about their experiences with ethical and legal compliance.
Research academic literature on the ethical debates surrounding Body Worlds to understand potential public reactions.
Consult with legal experts specializing in body donation and display regulations in Denmark to ensure compliance.

### Rationale for Suggestion

Body Worlds is highly relevant due to its experience in publicly displaying human remains for educational purposes. It has faced and overcome similar ethical and legal challenges, providing valuable insights into navigating public perception and regulatory hurdles. While geographically distant, the ethical and legal frameworks it has navigated are universally applicable, especially concerning body disposition and public display.
## Suggestion 2 - The Medical Museion, Copenhagen

The Medical Museion in Copenhagen is a museum dedicated to the history of medicine. It houses a collection of medical instruments, anatomical specimens, and exhibits exploring the cultural and social aspects of health and disease. The museum aims to engage the public with medical history and promote understanding of the human body.

### Success Metrics

Consistent visitor numbers and positive visitor feedback.
Successful integration of medical history into public education.
Preservation and accessibility of medical artifacts and specimens.
Collaboration with researchers and healthcare professionals to enhance the museum's exhibits and programs.

### Risks and Challenges Faced

Ethical considerations related to displaying human remains and medical specimens: Addressed through careful curation, respectful presentation, and providing context about the historical and scientific significance of the items.
Preservation challenges related to maintaining the integrity of historical medical artifacts: Managed through strict environmental controls, conservation treatments, and proper storage.
Balancing the educational and entertainment aspects of the museum to appeal to a broad audience: Achieved through interactive exhibits, engaging storytelling, and diverse programming.
Securing funding and resources to support the museum's operations and expansion: Addressed through fundraising, grants, and partnerships with other institutions.

### Where to Find More Information

Official Medical Museion website: [https://www.museion.ku.dk/](https://www.museion.ku.dk/)
Publications and articles about the Medical Museion's exhibits and research.
Online databases and archives of medical history collections.

### Actionable Steps

Contact the Medical Museion's curators to discuss their experiences with displaying anatomical specimens and navigating ethical considerations.
Visit the museum to observe their exhibit design and preservation techniques.
Explore potential partnerships with the museum for hosting the skeletal display or collaborating on educational programs.

### Rationale for Suggestion

The Medical Museion is a geographically and culturally relevant example of an institution that displays medical specimens and explores the human body. Its experience in navigating ethical considerations, preserving artifacts, and engaging the public makes it a valuable resource for this project. It is located in Copenhagen, making direct communication and collaboration feasible. The museum's existing infrastructure and expertise could be leveraged for the long-term preservation and display of the skeleton.
## Suggestion 3 - The Krieger Collection at the Mütter Museum

The Mütter Museum in Philadelphia houses a collection of anatomical and pathological specimens, models, and medical instruments. The Krieger Collection, a subset of the museum's holdings, specifically features articulated skeletons and skeletal preparations. The museum aims to educate the public about anatomy, pathology, and medical history.

### Success Metrics

High visitor attendance and positive visitor feedback.
Successful integration of anatomical and pathological specimens into public education.
Preservation and accessibility of medical artifacts and specimens.
Adherence to ethical guidelines for the display of human remains.

### Risks and Challenges Faced

Ethical considerations related to displaying human remains: Addressed through respectful presentation, providing historical context, and emphasizing the educational value of the specimens.
Preservation challenges related to maintaining the integrity of skeletal preparations: Managed through strict environmental controls, conservation treatments, and proper handling.
Balancing the scientific and sensational aspects of the museum to appeal to a broad audience: Achieved through informative exhibits, engaging storytelling, and avoiding gratuitous displays.
Securing funding and resources to support the museum's operations and expansion: Addressed through fundraising, grants, and partnerships with other institutions.

### Where to Find More Information

Official Mütter Museum website: [https://muttermuseum.org/](https://muttermuseum.org/)
Publications and articles about the Mütter Museum's exhibits and collections.
Online databases and archives of medical history collections.

### Actionable Steps

Contact the Mütter Museum's curators to discuss their experiences with displaying articulated skeletons and navigating ethical considerations.
Research the Krieger Collection to understand the specific challenges and techniques involved in preserving skeletal preparations.
Explore potential partnerships with the museum for sharing expertise and best practices.

### Rationale for Suggestion

The Mütter Museum, particularly its Krieger Collection, provides a relevant example of an institution specializing in the display of articulated skeletons. While geographically distant, the museum's expertise in ethical display, preservation techniques, and public engagement is highly valuable. The museum's experience in managing a collection of skeletal remains can inform the project's approach to long-term preservation and ethical considerations. The Mütter Museum has a long history of displaying human remains and has developed best practices for doing so in a respectful and educational manner.

## Summary

Based on the provided project plan for post-mortem skeletal preparation and public display in Copenhagen, Denmark, here are three reference projects that offer relevant insights and actionable guidance. These suggestions focus on legal and ethical considerations, long-term preservation, and public engagement, aligning with the project's core challenges and strategic decisions.