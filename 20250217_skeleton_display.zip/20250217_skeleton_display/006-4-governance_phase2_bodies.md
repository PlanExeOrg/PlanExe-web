### 1. Project Steering Committee

**Rationale for Inclusion:** Provides high-level strategic direction and oversight, given the project's complexity, ethical considerations, and potential for legal challenges. Ensures alignment with the client's wishes and manages strategic risks.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic guidance and direction.
- Monitor project progress against key milestones.
- Approve significant changes to project scope or budget (above 100,000 DKK).
- Oversee risk management and mitigation strategies.
- Resolve strategic conflicts and escalate issues as needed.
- Ensure compliance with ethical and legal requirements.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define escalation paths.
- Review project plan and risk assessment.

**Membership:**

- Estate Executor
- Trust Manager
- Legal Counsel
- Independent Ethics Advisor (external)
- Family Representative (if willing)

**Decision Rights:** Strategic decisions related to project scope, budget (above 100,000 DKK), timeline, risk management, and ethical considerations.

**Decision Mechanism:** Decisions made by majority vote, with the Estate Executor having the tie-breaking vote. The Independent Ethics Advisor can veto decisions deemed ethically unsound.

**Meeting Cadence:** Quarterly, or more frequently as needed.

**Typical Agenda Items:**

- Review project progress against milestones.
- Review and approve budget updates.
- Discuss and resolve strategic risks and issues.
- Review ethical and legal compliance.
- Approve changes to project scope or timeline.
- Review stakeholder engagement.

**Escalation Path:** Unresolved issues escalated to the Estate Executor, whose decision is final, except in cases of ethical concerns, which are escalated to the Independent Ethics Advisor for final determination.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages day-to-day execution, operational risk management, and decisions below strategic thresholds. Ensures efficient project delivery and adherence to the project plan.

**Responsibilities:**

- Develop and maintain project plan.
- Manage project budget (below 100,000 DKK) and track expenses.
- Coordinate project activities and resources.
- Monitor project progress and identify potential issues.
- Implement risk mitigation strategies.
- Prepare project reports and updates.
- Manage communication among project stakeholders.
- Ensure compliance with project standards and procedures.

**Initial Setup Actions:**

- Establish project management processes and tools.
- Develop project communication plan.
- Define roles and responsibilities of project team members.
- Set up project tracking and reporting systems.

**Membership:**

- Project Manager
- Osteologist
- Mortuary Facility Representative
- Display Case Fabricator Representative
- PR/Communications Professional

**Decision Rights:** Operational decisions related to project execution, budget management (below 100,000 DKK), resource allocation, and risk mitigation.

**Decision Mechanism:** Decisions made by the Project Manager, in consultation with relevant team members. Disputes escalated to the Project Steering Committee.

**Meeting Cadence:** Bi-weekly, or more frequently as needed.

**Typical Agenda Items:**

- Review project progress against plan.
- Discuss and resolve operational issues.
- Review and approve budget expenditures (below 100,000 DKK).
- Review risk register and mitigation strategies.
- Plan upcoming activities and milestones.
- Review stakeholder communication.

**Escalation Path:** Unresolved issues escalated to the Project Steering Committee.
### 3. Ethics & Compliance Committee

**Rationale for Inclusion:** Provides specialized input and assurance on ethical and compliance aspects of the project, given the sensitive nature of the project and potential for ethical concerns and legal challenges. Ensures adherence to ethical standards, GDPR, and relevant regulations.

**Responsibilities:**

- Review and approve ethical guidelines for the project.
- Monitor compliance with ethical standards and relevant regulations (including GDPR).
- Provide guidance on ethical issues and dilemmas.
- Investigate and resolve ethical complaints.
- Ensure compliance with Danish body disposition laws.
- Review and approve communication strategies to address ethical concerns.
- Advise on stakeholder engagement to ensure ethical considerations are addressed.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Develop ethical guidelines for the project.
- Establish a process for reporting and investigating ethical complaints.

**Membership:**

- Independent Ethics Advisor (external, also on Steering Committee)
- Legal Counsel
- Grief Counselor/Mediator
- Family Representative (if willing)
- Biohazard Safety Consultant

**Decision Rights:** Decisions related to ethical considerations, compliance with ethical standards and relevant regulations, and resolution of ethical complaints. Can halt project activities deemed ethically unsound.

**Decision Mechanism:** Decisions made by majority vote, with the Independent Ethics Advisor having the tie-breaking vote and veto power on ethical grounds.

**Meeting Cadence:** Monthly, or more frequently as needed.

**Typical Agenda Items:**

- Review ethical guidelines and compliance.
- Discuss and resolve ethical issues and dilemmas.
- Review and approve communication strategies to address ethical concerns.
- Review stakeholder engagement to ensure ethical considerations are addressed.
- Review and investigate ethical complaints.
- Monitor compliance with GDPR and relevant regulations.

**Escalation Path:** Unresolved ethical issues escalated to the Independent Ethics Advisor, whose decision is final. Legal compliance issues escalated to Legal Counsel, with final escalation to the Estate Executor if necessary.