This plan implies one or more physical locations.

## Requirements for physical locations

- licensed mortuary facility for skeletal preparation
- host institution for permanent display
- legal expertise in body disposition law in Denmark

## Location 1
Denmark

Copenhagen

Various licensed mortuary facilities in Copenhagen

**Rationale**: Copenhagen has several licensed mortuary facilities equipped to handle biohazard management and skeletal preparation, ensuring compliance with legal and ethical standards.

## Location 2
Denmark

Copenhagen

Copenhagen University Hospital

**Rationale**: This hospital has a strong forensic science program and may provide the necessary expertise for biohazard management and skeletal preparation.

## Location 3
Denmark

Copenhagen

The Medical Museum, Copenhagen

**Rationale**: The Medical Museum is a potential host institution that specializes in anatomical specimens and could be receptive to displaying the skeleton as part of its collection.

## Location Summary
The project requires physical locations in Copenhagen for legal consultation, mortuary services, and a host institution for the permanent display of the skeleton. Suggested locations include licensed mortuary facilities, Copenhagen University Hospital for expertise, and The Medical Museum for display.