**Goal Statement:** Prepare and publicly display a posed human skeleton in Copenhagen, Denmark, after death, within 12-18 months, funded by a 1.5 million DKK trust.

## SMART Criteria

- **Specific:** The goal is to prepare the user's skeleton in a zombie-like pose and display it in a public institution in Copenhagen.
- **Measurable:** The goal will be measured by the successful articulation and mounting of the skeleton in a museum-grade display case within the specified timeframe, and its acceptance by a public institution for permanent display.
- **Achievable:** The goal is achievable given the user's allocation of 1.5 million DKK, and the availability of qualified osteologists, mortuary facilities, and potential host institutions in Copenhagen.
- **Relevant:** The goal is relevant to the user's desire for unconventional memorialization and lifelong fascination with zombies.
- **Time-bound:** The project should be completed within 12-18 months after the user's death.

## Dependencies

- Draft a legally binding will and advance directives authorizing skeletal preparation and display.
- Secure a mortuary facility licensed and equipped for biohazard management.
- Identify and secure a host institution in Copenhagen willing to house the display permanently.
- Establish a dedicated trust to fund and execute post-mortem wishes.

## Resources Required

- Legal counsel specializing in body disposition law in Denmark
- Qualified osteologist
- Mortuary facility
- Museum-grade sealed display case with environmental controls
- Certified industrial hygienist or biohazard safety consultant
- Grief counselor or mediator experienced in end-of-life planning
- PR or communications professional
- Funding of 1.5 million DKK

## Related Goals

- Challenge conventional notions of death and remembrance
- Leave a lasting legacy
- Express personal fascination with zombies

## Tags

- skeletal preparation
- public display
- unconventional memorialization
- zombies
- Copenhagen
- biohazard
- legal
- ethical

## Risk Assessment and Mitigation Strategies


### Key Risks

- Danish body disposition laws may not permit skeletal preparation/display.
- Family may object, leading to legal challenges, distress, negative publicity.
- Public display may be seen as disrespectful/offensive.
- Project costs may exceed budget (1.5M DKK).
- Institution may be unwilling/unable to provide preservation/security.

### Diverse Risks

- Regulatory risks
- Social risks
- Ethical risks
- Financial risks
- Operational risks

### Mitigation Plans

- Engage attorney, secure pre-approval/court order.
- Proactive family communication (counselor/mediator), client video message, involve family.
- PR strategy framing display as expression/memorialization. Partner with institution for education.
- Detailed budget with contingency. Secure firm quotes. Establish robust trust.
- Vet institutions, ensure commitment. Negotiate binding agreement for placement/maintenance.

## Stakeholder Analysis


### Primary Stakeholders

- Estate Executor
- Osteologist
- Mortuary Facility
- Legal Counsel
- Trust Manager
- Display Case Fabricator

### Secondary Stakeholders

- Immediate Family
- Potential Host Institutions (Museums, Galleries)
- Regulatory Bodies (Danish Health Authority)
- Public Audience
- Biohazard Safety Consultant
- Grief Counselor/Mediator
- PR/Communications Professional

### Engagement Strategies

- Provide regular updates and progress reports to the Estate Executor.
- Collaborate with the Osteologist on pose design and skeletal preparation.
- Ensure the Mortuary Facility adheres to biohazard protocols and legal requirements.
- Consult with Legal Counsel on all legal matters and documentation.
- Work with the Trust Manager to ensure financial stability and compliance.
- Coordinate with the Display Case Fabricator on design and security features.
- Engage Immediate Family in discussions and address their concerns.
- Negotiate with Potential Host Institutions to secure a permanent display location.
- Comply with all Regulatory Bodies and obtain necessary permits.
- Manage Public Audience perception through effective PR and communication.
- Consult with Biohazard Safety Consultant to ensure safety protocols are followed.
- Utilize Grief Counselor/Mediator to facilitate family discussions and resolve conflicts.
- Employ PR/Communications Professional to manage media relations and public perception.

## Regulatory and Compliance Requirements


### Permits and Licenses

- Body Disposition Permit
- Mortuary License
- Biohazard Handling Permit
- Display Permit (if required by host institution)

### Compliance Standards

- Danish Health Authority regulations for body disposition
- Biosafety Level 2 (BSL-2) standards for biohazard management
- Museum standards for environmental control and preservation
- Ethical guidelines for public display of human remains

### Regulatory Bodies

- Danish Health Authority
- Local Municipality (for display permits)
- Occupational Safety and Health Administration (if applicable)

### Compliance Actions

- Apply for Body Disposition Permit
- Ensure Mortuary License is valid and compliant
- Implement BSL-2 compliant biohazard management plan
- Schedule compliance audit for biohazard protocols
- Obtain Display Permit from local municipality
- Implement environmental control plan for display case
- Develop ethical guidelines for public display