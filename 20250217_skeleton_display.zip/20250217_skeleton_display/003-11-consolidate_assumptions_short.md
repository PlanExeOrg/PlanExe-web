# Purpose
# Post-mortem skeletal preparation and public display

- Planning for preparation, preservation, and display.
- Includes legal, ethical, biohazard, and logistical considerations.


# Plan Type
This plan requires physical locations.

Explanation: This plan requires physical actions and locations, including legal consultation, mortuary services, biohazard management, skeletal preparation, display case fabrication, and a permanent public display location in Copenhagen.

# Physical Locations
# Requirements for physical locations

- Licensed mortuary facility
- Host institution
- Legal expertise

## Location 1
Denmark, Copenhagen

- Licensed mortuary facilities
- Rationale: Biohazard management and skeletal preparation compliance.

## Location 2
Denmark, Copenhagen

- Copenhagen University Hospital
- Rationale: Forensic science expertise.

## Location 3
Denmark, Copenhagen

- The Medical Museum, Copenhagen
- Rationale: Potential host institution.

## Location Summary
Physical locations in Copenhagen are needed for legal consultation, mortuary services, and display. Suggested locations: mortuary facilities, Copenhagen University Hospital, and The Medical Museum.

# Currency Strategy
## Currencies

- DKK: Local currency for all expenses in Denmark.

Primary currency: DKK

Currency strategy: DKK will be used for all transactions. No additional international risk management is needed.

# Identify Risks
# Risk 1 - Regulatory & Permitting

- Danish body disposition laws may not permit skeletal preparation/display. Novelty could cause hurdles.
- Impact: Project halt, legal battles, delays (6-12 months), legal fees (50-100k DKK).
- Likelihood: Medium
- Severity: High
- Action: Engage attorney, secure pre-approval/court order. 'Pioneer's Gambit' emphasizes this.

# Risk 2 - Social

- Family may object, leading to legal challenges, distress, negative publicity.
- Impact: Legal challenges, delays (3-6 months), legal fees (25-50k DKK), strained relations, negative media.
- Likelihood: Medium
- Severity: High
- Action: Proactive family communication (counselor/mediator), client video message, involve family. Scenario includes video, but engagement is crucial.

# Risk 3 - Ethical

- Public display may be seen as disrespectful/offensive.
- Impact: Negative media, protests, damage to reputation, potential removal, loss of investment.
- Likelihood: Medium
- Severity: Medium
- Action: PR strategy framing display as expression/memorialization. Partner with institution for education. Scenario includes framing, but proactive engagement is crucial.

# Risk 4 - Technical

- Skeletal preparation may be complex/time-consuming. Achieving pose may be challenging.
- Impact: Delays (2-4 weeks), increased osteologist fees (10-20k DKK), need for expertise.
- Likelihood: Medium
- Severity: Medium
- Action: Engage experienced osteologist. Develop detailed pose design with experts. 'Osteological Scope Definition' is relevant.

# Risk 5 - Financial

- Project costs may exceed budget (1.5M DKK). Endowment may be insufficient.
- Impact: Delays, reduced scope, need for funding, potential abandonment.
- Likelihood: Medium
- Severity: High
- Action: Detailed budget with contingency. Secure firm quotes. Establish robust trust. 'Trust Structure Design' is critical.

# Risk 6 - Operational

- Institution may be unwilling/unable to provide preservation/security. May remove display.
- Impact: Deterioration, theft/vandalism, removal, loss of investment.
- Likelihood: Low
- Severity: High
- Action: Vet institutions, ensure commitment. Negotiate binding agreement for placement/maintenance. 'Host Institution Selection' is critical.

# Risk 7 - Biohazard

- Inadequate biohazard management could expose personnel.
- Impact: Health risks, legal liabilities, delays, increased costs.
- Likelihood: Low
- Severity: High
- Action: Implement biohazard protocol with hygienist. Select mortuary with safety record. 'Biohazard Mitigation Protocol' and 'Mortuary Vendor Diligence' are relevant.

# Risk 8 - Supply Chain

- Display case may be delayed/not meet specs.
- Impact: Delays (1-2 months), increased costs (5-10k DKK), need for alternatives.
- Likelihood: Low
- Severity: Medium
- Action: Select reputable fabricator. Develop specs/QC. Contingency plan.

# Risk 9 - Security

- Display case may be vulnerable to theft/vandalism.
- Impact: Damage/loss, reputational damage, financial loss.
- Likelihood: Low
- Severity: High
- Action: Integrate security features (reinforced glass, sensors, alarms). Coordinate with institution. 'Display Case Security Measures' is relevant.

# Risk summary

- Critical risks: legal challenges, ethical objections, financial sustainability.
- 'Pioneer's Gambit' prioritizes legal defensibility/unconventional display, requires family/public management.
- Robust trust is essential for funding/legal battles.
- Trade-offs exist between vision and consequences. Success hinges on court order/public perception.


# Make Assumptions
# Question 1 - Funding for Legal Fees

- Assumption: 200,000 DKK for legal fees, 50,000 DKK contingency.
- Assessment: Financial Feasibility

 - Initial allocation may be insufficient.
 - Risk: Legal costs exceeding budget.
  - Impact: Delays, reduced scope.
  - Mitigation: Pro bono assistance, dispute resolution.
  - Opportunity: Negotiate fixed fees.

# Question 2 - Timeline for Legal Authorizations

- Assumption: 6 months to secure legal authorizations.
- Assessment: Timeline & Milestones

 - 6-month timeline is aggressive.
 - Risk: Delays in legal proceedings.
  - Impact: Project delays, loss of momentum.
  - Mitigation: Expedite processes, priority scheduling.
  - Opportunity: Streamline documentation, leverage precedents.

# Question 3 - Osteologist Expertise and Certifications

- Assumption: Osteologist with 5+ years experience, certifications in anatomical preservation.
- Assessment: Resources & Personnel

 - Expertise is crucial.
 - Risk: Inadequate skills, poor quality.
  - Impact: Inaccuracies, flaws.
  - Mitigation: Background checks, portfolio review.
  - Opportunity: Partner with university lab.

# Question 4 - Danish Regulations for Body Disposition

- Assumption: Danish laws allow skeletal preparation with authorization and ethical considerations.
- Assessment: Governance & Regulations

 - Compliance is paramount.
 - Risk: Legal challenges, ethical violations.
  - Impact: Project halt, penalties.
  - Mitigation: Legal counsel, permits.
  - Opportunity: Advocate for clearer regulations.

# Question 5 - Biohazard Safety Protocols

- Assumption: Mortuary adheres to BSL-2 standards.
- Assessment: Safety & Risk Management

 - Biohazard safety is critical.
 - Risk: Exposure, contamination.
  - Impact: Health risks, liabilities.
  - Mitigation: Strict protocols, inspections.
  - Opportunity: Partner with safety consultant.

# Question 6 - Environmental Impact Minimization

- Assumption: Prioritize enzymatic digestion.
- Assessment: Environmental Impact

 - Minimizing impact is important.
 - Risk: Pollution, depletion.
  - Impact: Negative publicity, penalties.
  - Mitigation: Eco-friendly methods, recycle.
  - Opportunity: Promote sustainable practices.

# Question 7 - Family Engagement Strategy

- Assumption: Family open to facilitated discussions.
- Assessment: Stakeholder Involvement

 - Family consent is crucial.
 - Risk: Family objections, disputes.
  - Impact: Delays, costs.
  - Mitigation: Grief counselor, family involvement.
  - Opportunity: Build consensus.

# Question 8 - Operational Systems for Skeletal Preparation

- Assumption: Digital chain-of-custody system.
- Assessment: Operational Systems

 - Robust systems are essential.
 - Risk: Loss of control, data breaches.
  - Impact: Legal liabilities, damage.
  - Mitigation: Digital tracking, audits.
  - Opportunity: Improve efficiency.

# Distill Assumptions
# Project Plan

- 200,000 DKK allocated for legal fees, with 50,000 DKK contingency.
- Securing legal authorizations (court order) will take ~6 months.
- Osteologist: 5 years experience, anatomical preservation certifications.
- Danish body disposition laws allow skeletal preparation/display with authorization.
- Mortuary adheres to Biosafety Level 2 (BSL-2) standards.
- Prioritize environmentally friendly decomposition methods.
- Family will engage with counselor to address concerns/reach consensus.
- Digital chain-of-custody system tracks skeleton.


# Review Assumptions
# Domain of the expert reviewer
Project Management, Risk Management, and Legal Compliance

## Domain-specific considerations

- Legal/ethical compliance in Denmark regarding body disposition.
- Stakeholder management, family communication, and potential conflicts.
- Long-term financial sustainability and preservation.
- Biohazard mitigation and safety protocols.

## Issue 1 - Inadequate Assessment of Family Conflict and Mitigation Strategies
The plan assumes family openness to discussions, which may be optimistic. The 'Pioneer's Gambit' could worsen tensions if not handled delicately. The plan lacks strategies for irreconcilable objections, potentially leading to legal battles, delays, and increased costs.

Recommendation:

- Develop a detailed family conflict resolution plan:

 - Pre-mortem family meeting facilitated by a neutral third party.
 - Clear escalation path for resolving disputes.
 - Communication protocol for keeping family informed.
 - Offer family members a role in the project.
 - Secure written consent from immediate family to minimize legal challenges.

Sensitivity: Failure to address family conflict could result in legal challenges, delaying the project by 6-12 months and increasing legal costs by 100,000-300,000 DKK. This could negatively impact the project's ROI by 5-10%.

## Issue 2 - Insufficient Detail Regarding Long-Term Financial Sustainability
The plan assumes trust structure ensures sustainability but lacks details on income generation and maintenance costs. It doesn't address inflation, economic downturns, or unexpected expenses. The plan also doesn't address tax implications of the trust structure.

Recommendation:

- Conduct a detailed financial analysis to determine long-term funding needs.
- Develop a diversified investment strategy for the trust.
- Establish a reserve fund within the trust.
- Consult with a financial advisor and tax attorney.
- Explore options for securing additional funding.

Sensitivity: If the trust fails to generate sufficient income, the project could face funding shortfalls, jeopardizing its long-term preservation. A 10% shortfall could result in a 2-3% reduction in ROI and potentially lead to the removal of the display within 5-10 years.

## Issue 3 - Lack of Contingency Planning for Host Institution Withdrawal
The plan assumes the host institution will remain committed, but lacks contingency plans for withdrawal due to changing priorities, ethical concerns, or financial difficulties.

Recommendation:

- Develop a contingency plan:

 - Identify alternative host institutions and establish relationships.
 - Negotiate a legally binding agreement with the chosen host institution.
 - Establish a fund within the trust to cover relocation costs.
 - Explore options for creating a private museum or gallery.

Sensitivity: If the host institution withdraws, the project could face significant relocation costs, potentially ranging from 50,000 to 100,000 DKK. This could also delay the project's ROI by 1-2 years.

## Review conclusion
The plan requires more robust risk mitigation strategies, particularly in family conflict, financial sustainability, and host institution commitment. Addressing these issues will increase the likelihood of project success.