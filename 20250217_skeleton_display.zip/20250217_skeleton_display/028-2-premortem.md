A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The Danish legal system will uphold pre-approval/court order. | Engage a second, independent legal expert to review the initial legal strategy and provide a 'second opinion' on its robustness and potential vulnerabilities. | The second legal expert identifies significant vulnerabilities in the initial legal strategy that could lead to the pre-approval/court order being overturned. |
| A2 | The allocated budget of 1.5 million DKK will be sufficient to cover all project expenses. | Obtain detailed, itemized cost estimates from multiple vendors for all major project components (legal fees, osteologist services, display case fabrication, long-term preservation). | The total cost estimates from vendors exceed the allocated budget of 1.5 million DKK by more than 10%. |
| A3 | The immediate family will be open to engaging in facilitated discussions and addressing their concerns regarding the project. | Schedule initial consultations with key family members, facilitated by a grief counselor, to gauge their willingness to participate in open and honest discussions. | A majority of key family members decline to participate in facilitated discussions or express strong opposition to the project during initial consultations. |
| A4 | The chosen mortuary vendor will possess the necessary expertise and facilities for the specific skeletal preparation techniques required (e.g., enzymatic digestion, specific articulation methods). | Conduct a detailed site visit and technical assessment of the top 3 candidate mortuary vendors, focusing on their experience with similar projects and their capacity to meet the project's specific technical requirements. | None of the top 3 candidate mortuary vendors can demonstrate sufficient experience or possess the required facilities for the specific skeletal preparation techniques outlined in the project plan. |
| A5 | The Copenhagen art community will embrace the project as a legitimate form of artistic expression and memorialization. | Present the project concept and preliminary designs to a panel of art critics, curators, and artists from the Copenhagen art community and solicit their feedback. | The majority of the panel expresses skepticism or disapproval of the project, questioning its artistic merit or ethical implications. |
| A6 | The display case fabricator will be able to deliver a museum-grade display case that meets all specifications (environmental controls, security features, aesthetic requirements) within the allocated budget and timeline. | Obtain detailed, binding quotes from at least three reputable display case fabricators, including guarantees for performance, delivery timeline, and adherence to specifications. | None of the fabricators can provide a binding quote that meets all project specifications within the allocated budget and timeline. |
| A7 | The client's expressed desire for a 'zombie-like' pose is clearly defined and consistently understood by all stakeholders (osteologist, curator, family). | Develop a detailed visual reference guide (mood board, sketches, 3D models) illustrating the desired 'zombie-like' aesthetic and circulate it among all stakeholders for feedback and approval. | Stakeholders express significantly different interpretations of the 'zombie-like' aesthetic, leading to conflicting design proposals and a lack of consensus on the final pose. |
| A8 | The chosen host institution will maintain consistent policies regarding public access, interpretation, and display of human remains throughout the project's duration. | Obtain written confirmation from the host institution regarding their policies on public access, interpretation, and display of human remains, and include a clause in the agreement that requires them to provide advance notice of any policy changes. | The host institution is unable or unwilling to provide written confirmation of their policies or refuses to include a clause requiring advance notice of policy changes. |
| A9 | There will be sufficient public interest in the display to justify the ongoing costs of maintenance, security, and promotion. | Conduct a market analysis to estimate potential visitor numbers and revenue generation based on similar exhibits and local tourism trends. | The market analysis projects visitor numbers and revenue generation that are insufficient to cover the ongoing costs of maintenance, security, and promotion. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Endowment Evaporation | Process/Financial | A2 | Trust Manager | CRITICAL (20/25) |
| FM2 | The Legal Labyrinth | Technical/Logistical | A1 | Legal Counsel | CRITICAL (15/25) |
| FM3 | The Family Feud | Market/Human | A3 | Grief Counselor | CRITICAL (15/25) |
| FM4 | The Vendor Vanishing Act | Process/Financial | A4 | Mortuary Vendor Diligence Lead | CRITICAL (20/25) |
| FM5 | The Art World Rejection | Market/Human | A5 | Public Relations/Communications Specialist | CRITICAL (15/25) |
| FM6 | The Display Case Debacle | Technical/Logistical | A6 | Display Case Design Lead | CRITICAL (20/25) |
| FM7 | The Pose of Perpetual Confusion | Technical/Logistical | A7 | Osteological Scope Definition Lead | CRITICAL (20/25) |
| FM8 | The Policy Pivot | Process/Financial | A8 | Host Institution Liaison | CRITICAL (15/25) |
| FM9 | The Empty Gallery | Market/Human | A9 | Marketing and Outreach Coordinator | CRITICAL (20/25) |


### Failure Modes

#### FM1 - The Endowment Evaporation

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: Trust Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's financial foundation crumbles due to unforeseen cost overruns and inadequate long-term financial planning. Initial budget estimates prove wildly optimistic, failing to account for the specialized nature of the project and the unique challenges of preserving human remains. The trust fund, initially projected to provide ample resources for maintenance and legal challenges, is quickly depleted by escalating legal fees stemming from family disputes and unexpected preservation costs. The host institution, facing its own financial constraints, is unable to contribute to the display's upkeep, leaving the project vulnerable to neglect and eventual closure.

Contributing factors include a lack of due diligence in securing firm quotes from vendors, an underestimation of the complexity of the legal and ethical landscape, and a failure to anticipate the impact of inflation on long-term preservation costs. The consequences are dire: the display case falls into disrepair, the skeleton begins to deteriorate, and the project's artistic and educational value is compromised. Ultimately, the trust fund is exhausted, and the host institution, citing financial constraints and declining visitor numbers, removes the display from public view, effectively erasing the client's legacy.

##### Early Warning Signs
- Legal fees exceed 50,000 DKK within the first 3 months.
- Vendor quotes for display case fabrication exceed initial estimates by >= 20%.
- Trust fund investment returns fall below 4% in the first year.

##### Tripwires
- Trust fund balance falls below 80% of projected annual maintenance costs.
- Unpaid invoices to vendors exceed 10,000 DKK for >= 30 days.
- Host institution announces budget cuts impacting exhibit maintenance by >= 15%.

##### Response Playbook
- Contain: Immediately freeze all non-essential project spending.
- Assess: Conduct a comprehensive audit of all project expenses and revenue streams.
- Respond: Develop a revised financial plan, including securing additional funding sources or reducing project scope.


**STOP RULE:** The trust fund balance is insufficient to cover projected maintenance costs for the next 3 years.

---

#### FM2 - The Legal Labyrinth

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A1
- **Owner**: Legal Counsel
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Despite initial legal assurances, the project becomes entangled in a complex web of legal challenges and regulatory hurdles. The Danish legal system, unfamiliar with such an unconventional request, proves resistant to granting the necessary permits and approvals. A rival claimant to the estate emerges, disputing the validity of the will and challenging the client's capacity to make end-of-life decisions. The family, divided and embittered, files multiple lawsuits, further complicating the legal landscape and driving up legal costs.

Contributing factors include an inadequate understanding of Danish body disposition laws, a failure to anticipate potential legal challenges from family members, and an overreliance on a single legal strategy. The consequences are devastating: the project is placed on indefinite hold, the skeletal preparation is delayed, and the host institution withdraws its support, citing legal uncertainty and potential reputational damage. The client's vision is thwarted, and their legacy is tarnished by legal battles and public controversy.

##### Early Warning Signs
- Legal counsel expresses uncertainty about securing necessary permits within 6 months.
- A family member files a formal objection to the project with the probate court.
- Media outlets begin reporting on potential legal challenges to the project.

##### Tripwires
- A court issues a temporary restraining order halting the skeletal preparation process.
- Legal fees exceed 100,000 DKK without securing necessary permits.
- The host institution places the project on hold due to legal concerns.

##### Response Playbook
- Contain: Immediately cease all skeletal preparation activities.
- Assess: Conduct a thorough review of the legal strategy with a second, independent legal expert.
- Respond: Develop a revised legal strategy, including exploring alternative legal avenues or negotiating a settlement with opposing parties.


**STOP RULE:** A court issues a final ruling prohibiting the skeletal preparation and public display.

---

#### FM3 - The Family Feud

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Grief Counselor
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project is derailed by a bitter and irreconcilable family feud. Despite initial attempts at mediation, key family members remain vehemently opposed to the project, viewing it as disrespectful, macabre, and a violation of the client's dignity. The family's objections escalate into a public relations nightmare, with leaked documents, inflammatory statements, and accusations of exploitation. The media seizes on the controversy, fueling public outrage and pressuring the host institution to withdraw its support.

Contributing factors include a lack of empathy and understanding among family members, a failure to address their underlying emotional concerns, and an inadequate communication strategy. The consequences are catastrophic: the project's reputation is irreparably damaged, potential host institutions refuse to associate with the controversy, and the client's legacy is tarnished by family infighting and public condemnation. The project is abandoned, and the skeleton is quietly interred, a victim of human conflict and emotional turmoil.

##### Early Warning Signs
- Key family members refuse to attend mediation sessions.
- Family members leak confidential project documents to the media.
- Social media sentiment towards the project becomes overwhelmingly negative.

##### Tripwires
- A family member files a lawsuit seeking to block the project based on emotional distress.
- A major media outlet publishes a negative exposé on the project, citing family objections.
- The host institution receives >= 100 formal complaints from the public regarding the project's ethical implications.

##### Response Playbook
- Contain: Immediately suspend all public relations activities.
- Assess: Conduct a thorough assessment of family dynamics and identify key points of conflict.
- Respond: Develop a revised communication strategy, including engaging a neutral third party to mediate family disputes or offering concessions to address their concerns.


**STOP RULE:** Key family members publicly disavow the project and actively campaign against it, rendering it impossible to secure institutional support or public acceptance.

---

#### FM4 - The Vendor Vanishing Act

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Mortuary Vendor Diligence Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project grinds to a halt when the selected mortuary vendor proves incapable of handling the specialized skeletal preparation techniques required. Despite initial assurances, the vendor lacks the necessary expertise, equipment, or trained personnel to perform enzymatic digestion or the intricate articulation methods specified in the project plan. Attempts to outsource these tasks to other vendors prove costly and time-consuming, quickly depleting the project's budget. The osteologist, frustrated by the vendor's incompetence, threatens to withdraw from the project, further compounding the logistical nightmare.

Contributing factors include inadequate due diligence in assessing the vendor's capabilities, a failure to anticipate the complexity of the skeletal preparation process, and an overreliance on the vendor's initial promises. The consequences are severe: the project falls hopelessly behind schedule, the budget is exhausted by unexpected expenses, and the client's vision is compromised by the vendor's inability to deliver the required services.

##### Early Warning Signs
- The mortuary vendor requests frequent extensions to deadlines for key preparation tasks.
- The osteologist expresses concerns about the vendor's competence or the quality of their work.
- The project budget for mortuary services exceeds initial estimates by >= 15%.

##### Tripwires
- The mortuary vendor fails to meet a critical milestone deadline by >= 30 days.
- The osteologist formally withdraws from the project due to concerns about the vendor's performance.
- The project budget for mortuary services exceeds initial estimates by >= 25%.

##### Response Playbook
- Contain: Immediately suspend all payments to the mortuary vendor.
- Assess: Conduct a thorough assessment of the vendor's performance and identify the root causes of their failures.
- Respond: Terminate the contract with the mortuary vendor and engage a qualified replacement.


**STOP RULE:** A qualified replacement mortuary vendor cannot be secured within 60 days.

---

#### FM5 - The Art World Rejection

- **Archetype**: Market/Human
- **Root Cause**: Assumption A5
- **Owner**: Public Relations/Communications Specialist
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project faces widespread condemnation from the Copenhagen art community, who view the display as tasteless, exploitative, and lacking in artistic merit. Despite attempts to frame the project as a legitimate form of artistic expression and memorialization, critics and artists alike denounce it as a sensationalist stunt that trivializes death and disrespects human remains. Potential host institutions, sensitive to the art community's disapproval, refuse to exhibit the display, fearing reputational damage and a boycott from artists and patrons.

Contributing factors include a misjudgment of the Copenhagen art community's values and sensibilities, a failure to engage with key influencers and stakeholders, and an inadequate understanding of the ethical complexities surrounding the display of human remains. The consequences are devastating: the project is ostracized by the art world, potential funding sources dry up, and the client's vision is relegated to the fringes of the cultural landscape.

##### Early Warning Signs
- Prominent art critics publish scathing reviews of the project concept.
- Major art institutions decline invitations to participate in the project.
- Social media sentiment towards the project among Copenhagen artists and art enthusiasts becomes overwhelmingly negative.

##### Tripwires
- A petition calling for the project's cancellation gains >= 1000 signatures from members of the Copenhagen art community.
- A major art institution publicly announces its refusal to host the display, citing ethical concerns.
- The project's funding is withdrawn by a major art foundation or patron.

##### Response Playbook
- Contain: Immediately suspend all public relations activities and reassess the project's messaging.
- Assess: Conduct a thorough analysis of the art community's objections and identify potential areas for compromise.
- Respond: Revise the project's artistic concept and narrative to address the art community's concerns, or explore alternative venues outside the traditional art world.


**STOP RULE:** No reputable art institution in Copenhagen is willing to host the display after a 12-month search.

---

#### FM6 - The Display Case Debacle

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A6
- **Owner**: Display Case Design Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project is thrown into disarray when the display case fabricator fails to deliver a museum-grade case that meets the project's stringent specifications. Despite initial assurances, the fabricator struggles to source the required materials, implement the complex environmental control systems, or integrate the sophisticated security features outlined in the project plan. The delivery timeline is repeatedly delayed, and the final product falls far short of expectations, with substandard materials, faulty mechanisms, and inadequate protection for the skeleton.

Contributing factors include an unrealistic budget and timeline, a failure to adequately vet the fabricator's capabilities, and an overreliance on the fabricator's promises. The consequences are dire: the skeleton is left vulnerable to deterioration and theft, the project's aesthetic appeal is compromised, and the host institution threatens to withdraw its support, citing concerns about preservation and security.

##### Early Warning Signs
- The display case fabricator requests frequent extensions to deadlines for key fabrication tasks.
- The project budget for display case fabrication exceeds initial estimates by >= 15%.
- The fabricator fails to provide documentation verifying the display case's compliance with museum-grade standards.

##### Tripwires
- The display case delivery is delayed by >= 60 days.
- The display case fails to pass a critical quality control test, such as a leak test or a security breach test.
- The host institution formally expresses concerns about the display case's suitability for long-term preservation.

##### Response Playbook
- Contain: Immediately suspend all payments to the display case fabricator.
- Assess: Conduct a thorough assessment of the display case's deficiencies and identify the root causes of the fabricator's failures.
- Respond: Terminate the contract with the display case fabricator and engage a qualified replacement, or explore alternative display case options that meet the project's requirements.


**STOP RULE:** A museum-grade display case that meets all project specifications cannot be secured within 90 days.

---

#### FM7 - The Pose of Perpetual Confusion

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Osteological Scope Definition Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project descends into chaos due to a fundamental misunderstanding of the client's vision for a 'zombie-like' pose. The osteologist, interpreting the request literally, creates a grotesque and anatomically implausible arrangement of bones that is deemed offensive and disrespectful by the family. The curator, envisioning a more subtle and artistic interpretation, proposes a pose that is considered too tame and lacking in the desired 'zombie' aesthetic by the client's confidants. The lack of a clear and consistent definition of the 'zombie-like' pose leads to endless revisions, escalating costs, and a growing sense of frustration among all stakeholders.

Contributing factors include a failure to establish a shared understanding of the client's vision, inadequate communication between the osteologist, curator, and family, and an overreliance on subjective interpretations. The consequences are severe: the skeletal preparation is delayed indefinitely, the budget is exhausted by repeated revisions, and the project's artistic integrity is compromised by the lack of a cohesive vision.

##### Early Warning Signs
- The osteologist and curator submit conflicting pose designs that are significantly different in style and tone.
- Family members express dissatisfaction with the proposed pose designs, citing concerns about disrespect or lack of authenticity.
- The project budget for skeletal preparation exceeds initial estimates by >= 15%.

##### Tripwires
- The osteologist and curator are unable to agree on a final pose design after three rounds of revisions.
- The family formally objects to the proposed pose design, citing concerns about disrespect or misrepresentation of the client's wishes.
- The project budget for skeletal preparation exceeds initial estimates by >= 25%.

##### Response Playbook
- Contain: Immediately suspend all skeletal preparation activities and convene a meeting of all stakeholders to clarify the client's vision.
- Assess: Conduct a thorough review of the client's expressed wishes and gather additional information from their confidants to develop a more precise definition of the 'zombie-like' aesthetic.
- Respond: Develop a detailed visual reference guide (mood board, sketches, 3D models) illustrating the desired aesthetic and circulate it among all stakeholders for feedback and approval.


**STOP RULE:** A consensus on the skeletal pose cannot be reached after 60 days.

---

#### FM8 - The Policy Pivot

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A8
- **Owner**: Host Institution Liaison
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project is thrown into turmoil when the host institution abruptly changes its policies regarding the display of human remains, citing concerns about ethical considerations and public sensitivities. Despite initial assurances of support, the institution's new leadership, under pressure from community groups and internal stakeholders, imposes strict restrictions on the display's content, interpretation, and accessibility. The project team is forced to make drastic revisions to the display narrative, removing key elements that were central to the client's vision. The host institution also imposes limitations on public access, restricting viewing hours and limiting the number of visitors allowed to view the display at any given time.

Contributing factors include a lack of due diligence in assessing the host institution's long-term commitment to the project, a failure to anticipate potential policy changes, and an overreliance on the institution's initial promises. The consequences are severe: the project's artistic and educational value is compromised, its public impact is diminished, and the client's legacy is tarnished by censorship and restrictions.

##### Early Warning Signs
- The host institution announces a change in leadership or a restructuring of its curatorial staff.
- The host institution implements new policies regarding ethical considerations or public sensitivities.
- The host institution begins to express concerns about the project's content or potential for controversy.

##### Tripwires
- The host institution formally requests significant revisions to the display narrative or content.
- The host institution imposes restrictions on public access to the display that are deemed unacceptable by the project team.
- The host institution announces a review of its policies regarding the display of human remains.

##### Response Playbook
- Contain: Immediately suspend all public relations activities and reassess the project's messaging.
- Assess: Conduct a thorough review of the host institution's new policies and identify potential areas for compromise.
- Respond: Negotiate with the host institution to find a mutually acceptable solution, or explore alternative venues that are more aligned with the project's vision.


**STOP RULE:** The host institution imposes restrictions on the display that fundamentally compromise its artistic or educational value.

---

#### FM9 - The Empty Gallery

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Marketing and Outreach Coordinator
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project languishes in obscurity due to a lack of public interest and engagement. Despite initial optimism, the display fails to attract a significant audience, with visitor numbers falling far short of projections. The host institution, facing declining revenue and mounting maintenance costs, begins to question the project's long-term viability. Attempts to boost attendance through marketing campaigns and educational programs prove ineffective, and the display is eventually relegated to a remote corner of the museum, where it is largely ignored by visitors.

Contributing factors include an overestimation of public interest in the display, a failure to effectively market and promote the project, and an inadequate understanding of the target audience. The consequences are devastating: the project's artistic and educational value is unrealized, its financial sustainability is jeopardized, and the client's legacy is diminished by its lack of public impact.

##### Early Warning Signs
- Visitor numbers to the display fall below 50% of projected levels within the first six months.
- Marketing campaigns fail to generate significant media coverage or public interest.
- The host institution expresses concerns about the project's financial performance.

##### Tripwires
- Visitor numbers to the display average less than 100 per week for >= 3 consecutive months.
- The host institution reduces its marketing budget for the display by >= 25%.
- The project's revenue generation is insufficient to cover its ongoing maintenance and security costs.

##### Response Playbook
- Contain: Immediately suspend all non-essential project spending and reassess the marketing strategy.
- Assess: Conduct a thorough analysis of visitor demographics and preferences to identify potential areas for improvement.
- Respond: Develop a revised marketing plan targeting specific audience segments, or explore alternative display venues that may attract a larger audience.


**STOP RULE:** The project's revenue generation is insufficient to cover its ongoing maintenance and security costs for two consecutive years.
