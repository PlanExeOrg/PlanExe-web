
## Risk 1 - Regulatory & Permitting
Danish body disposition laws may not explicitly permit the requested skeletal preparation and public display, leading to legal challenges or denial of permits. The novelty of the request could result in unforeseen regulatory hurdles.

**Impact:** Project halt, legal battles, significant delays (6-12 months), additional legal fees of 50,000-100,000 DKK.

**Likelihood:** Medium

**Severity:** High

**Action:** Engage a Danish attorney specializing in body disposition law to thoroughly research and navigate relevant regulations. Secure pre-approval or a court order during the client's lifetime to validate the legality of the project. The chosen 'Pioneer's Gambit' scenario emphasizes this.

## Risk 2 - Social
Family members may strongly object to the skeletal preparation and public display, leading to legal challenges to the will, emotional distress, and negative publicity. The 'Pioneer's Gambit' scenario acknowledges this risk but doesn't fully mitigate it.

**Impact:** Legal challenges, project delays (3-6 months), increased legal fees (25,000-50,000 DKK), strained family relationships, negative media coverage.

**Likelihood:** Medium

**Severity:** High

**Action:** Implement a proactive family communication strategy involving a grief counselor or mediator. Create a video message from the client explaining their wishes. Explore offering family members a role in the project's execution to foster a sense of involvement. The chosen scenario includes a video message, but proactive engagement is crucial.

## Risk 3 - Ethical
The public display of a human skeleton in a zombie-like pose may be perceived as disrespectful, offensive, or unethical, leading to negative media coverage, public protests, or pressure on the host institution to remove the display.

**Impact:** Negative media coverage, public protests, damage to reputation, potential removal of the display, loss of investment.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a comprehensive public relations strategy to frame the display as a unique form of personal expression and memorialization. Partner with the host institution to create educational materials and programming that address ethical concerns. The 'Pioneer's Gambit' scenario includes narrative framing, but proactive engagement is crucial.

## Risk 4 - Technical
The skeletal preparation process may be more complex or time-consuming than anticipated, leading to delays and increased costs. Achieving the desired zombie-like pose while maintaining anatomical accuracy and structural integrity may be technically challenging.

**Impact:** Project delays (2-4 weeks), increased osteologist fees (10,000-20,000 DKK), potential need for additional expertise.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Engage an experienced osteologist with a proven track record of skeletal preparation and articulation. Develop a detailed skeletal pose design in advance, consulting with anatomical experts and sculptors. The 'Osteological Scope Definition' lever is relevant here.

## Risk 5 - Financial
The project costs may exceed the allocated budget of 1.5 million DKK due to unforeseen expenses, cost overruns, or the need for additional services. The preservation endowment may be insufficient to cover long-term maintenance costs.

**Impact:** Project delays, reduced scope, need for additional funding, potential abandonment of the project.

**Likelihood:** Medium

**Severity:** High

**Action:** Develop a detailed budget with contingency funds. Secure firm quotes from all vendors. Establish a robust trust structure to ensure long-term financial sustainability. The 'Trust Structure Design' lever is critical here.

## Risk 6 - Operational
The host institution may be unwilling or unable to provide adequate preservation conditions or security measures, leading to deterioration of the skeleton or theft/vandalism. The institution may later decide to remove the display due to changing priorities or ethical concerns.

**Impact:** Deterioration of the skeleton, theft/vandalism, removal of the display, loss of investment.

**Likelihood:** Low

**Severity:** High

**Action:** Carefully vet potential host institutions, ensuring their commitment to long-term preservation and security. Negotiate a legally binding agreement that guarantees the display's permanent placement and maintenance. The 'Host Institution Selection' lever is critical here.

## Risk 7 - Biohazard
Inadequate biohazard management during the decomposition and preparation phase could expose personnel to infectious agents, leading to health risks and legal liabilities.

**Impact:** Health risks to personnel, legal liabilities, project delays, increased costs.

**Likelihood:** Low

**Severity:** High

**Action:** Develop and implement a comprehensive biohazard mitigation protocol in consultation with a certified industrial hygienist. Select a mortuary facility with a proven track record of biohazard safety. The 'Biohazard Mitigation Protocol' and 'Mortuary Vendor Diligence' levers are relevant here.

## Risk 8 - Supply Chain
The custom-designed display case may be delayed or not meet specifications, leading to project delays and increased costs.

**Impact:** Project delays (1-2 months), increased costs (5,000-10,000 DKK), need for alternative display solutions.

**Likelihood:** Low

**Severity:** Medium

**Action:** Select a reputable display case fabricator with a proven track record. Develop detailed specifications and quality control procedures. Establish a contingency plan in case of delays or defects.

## Risk 9 - Security
The display case may be vulnerable to theft or vandalism, leading to damage or loss of the skeleton.

**Impact:** Damage or loss of the skeleton, reputational damage, financial loss.

**Likelihood:** Low

**Severity:** High

**Action:** Integrate robust security features into the display case, including reinforced glass, motion sensors, and alarms. Coordinate security measures with the host institution. The 'Display Case Security Measures' lever is relevant here.

## Risk summary
The most critical risks are legal challenges from family members, ethical objections from the public, and financial sustainability. The 'Pioneer's Gambit' scenario prioritizes legal defensibility and unconventional display, but requires careful management of family relations and public perception. A robust trust structure is essential to ensure long-term funding for preservation and potential legal battles. Trade-offs exist between prioritizing the client's artistic vision and mitigating potential negative consequences. The chosen scenario's success hinges on securing a court order and proactively managing public perception.