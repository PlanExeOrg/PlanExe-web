### Premise Attack 1 — Integrity
_Forensic audit of foundational soundness across axes._

**[STRATEGIC] The premise of a publicly displayed, posed skeleton is fatally flawed because the plan's reliance on preemptive legal and PR maneuvers cannot guarantee dignity or prevent irreversible reputational damage.**

**Bottom Line:** REJECT: The plan's premise is inherently undignified and risks irreversible reputational damage, regardless of legal and PR efforts. The inherent sensationalism and ethical ambiguities surrounding the public display of a posed human skeleton outweigh any artistic or personal expression goals.


#### Reasons for Rejection

- The plan hinges on preempting negative media coverage with a managed public narrative, but the inherent sensationalism of a posed human skeleton makes sustained positive framing impossible, especially given the Danish cultural context.
- The 1.5 million DKK budget, while substantial, is insufficient to guarantee perpetual museum-quality preservation and security against determined vandalism or theft, risking desecration of human remains.
- Relying on legal authorization via will and advance directives is vulnerable to legal challenges from family members, regardless of preemptive grief counseling, potentially leading to protracted and very public legal battles over body disposition.
- The plan assumes a willing host institution in Copenhagen, but securing a permanent commitment from a reputable museum or gallery for such an unconventional display is highly uncertain, risking the project's indefinite postponement or cancellation.
- The biohazard management plan, while detailed, cannot eliminate the risk of unforeseen contamination events during the defleshing and preparation process, potentially leading to legal liabilities and ethical controversies for the mortuary facility.

#### Second-Order Effects

- 0–6 months: Initial media coverage, regardless of PR efforts, focuses on the macabre aspects, potentially alienating family and damaging the individual's posthumous reputation.
- 1–3 years: The display becomes a target for vandalism or protests, requiring increased security measures and potentially leading to calls for its removal.
- 5–10 years: The institution housing the display faces increasing pressure to re-evaluate its commitment, potentially leading to the skeleton's removal from public view and storage in an archive.

#### Evidence

- Case — Tutankhamun's Curse (1922): The opening of Tutankhamun's tomb led to widespread public fascination but also fueled superstitious beliefs and conspiracy theories.
- Case — Body Worlds Exhibitions (1995-Present): Gunther von Hagens' plastinated human bodies have faced ethical debates and legal challenges regarding consent and the commodification of death.
- Law — Danish Act on Anatomy (2003): Regulates the use of human bodies for scientific and educational purposes, but does not explicitly address artistic displays, leaving room for interpretation and potential legal challenges.



### Premise Attack 2 — Accountability
_Rights, oversight, jurisdiction-shopping, enforceability._

**[MORAL] — Necromantic Spectacle: This project weaponizes personal expression to normalize the grotesque desecration of human remains for public amusement.**

**Bottom Line:** REJECT: The project's premise hinges on a selfish desire for attention, overriding ethical considerations and potentially causing lasting harm to societal norms surrounding death and respect for the deceased — a necromantic spectacle that should never see the light of day.


#### Reasons for Rejection

- The explicit zombie theme risks trivializing death and disrespecting the dignity of the deceased, potentially causing emotional distress to viewers and setting a precedent for sensationalized displays.
- Relying on legal loopholes and advance directives to bypass potential family objections undermines the importance of familial consent and ethical considerations in body disposition.
- The public display of human remains, even with consent, could desensitize the public to the inherent value and respect owed to the deceased, leading to a slippery slope of increasingly macabre exhibitions.
- The allocation of significant resources to this project represents a misallocation of funds that could be used for more pressing social or medical needs, raising questions about the project's societal value.

#### Second-Order Effects

- **T+0–6 months — The Outrage Cycle:** Initial media coverage sparks public debate, attracting both supporters and detractors, with potential for protests and calls for the display's removal.
- **T+1–3 years — Copycats Arrive:** Inspired by the project, others attempt similar unconventional memorializations, pushing the boundaries of acceptable body disposition practices and potentially leading to legal challenges.
- **T+5–10 years — Norms Degrade:** The normalization of macabre displays erodes societal norms surrounding death and mourning, potentially leading to a decline in empathy and respect for the deceased.
- **T+10+ years — The Reckoning:** Future generations may view this era as a period of ethical decay, questioning the values and priorities that allowed such displays to become commonplace.

#### Evidence

- Law/Standard — Danish Act on Anatomy, Autopsy and Body Donation (2003): Regulates the handling of deceased bodies and requires respect for the deceased's dignity.
- Case/Report — The "Bodies" Exhibition Controversy: Public outcry and ethical debates surrounding the display of plastinated human bodies highlight the potential for controversy and offense.
- Narrative — Front-Page Test: Imagine the headline: "Copenhagen Museum Unveils Zombie Skeleton: Art or Disrespectful Spectacle?" The ensuing debate would be toxic.
- Unknown — default: caution.



### Premise Attack 3 — Spectrum
_Enforced breadth: distinct reasons across ethical/feasibility/governance/societal axes._

**[STRATEGIC] The plan's premise rests on the naive assumption that meticulous legal and ethical preparation can fully neutralize the profound emotional and societal objections to posthumous zombie-themed display.**

**Bottom Line:** REJECT: The plan's premise is fatally flawed due to its underestimation of the legal, ethical, and emotional obstacles inherent in its core concept.


#### Reasons for Rejection

- The €200K budget is insufficient to fully insulate against legal challenges from family members contesting the will, especially given the unconventional nature of the request.
- Relying on a grief counselor to mediate family acceptance is a gamble, as grief is unpredictable and some family members may find the concept inherently disrespectful.
- Securing a permanent host institution in Copenhagen willing to publicly display a zombie-themed skeleton indefinitely is highly uncertain, given the potential for negative public perception.
- The 12–18 month preparation timeline is unrealistic, as it fails to account for potential delays in legal proceedings, facility availability, or unforeseen complications during skeletal preparation.
- Framing the display as 'art and personal expression' is unlikely to preempt ethical backlash, as the public may still perceive it as macabre and disrespectful, regardless of the narrative.

#### Second-Order Effects

- 0–6 months: Immediate family initiates legal action to block the execution of the will, leading to protracted court battles and public scrutiny.
- 1–3 years: The chosen host institution withdraws its commitment due to sustained public pressure and ethical concerns, leaving the skeleton without a permanent home.
- 5–10 years: The legal precedent set by this case leads to stricter regulations regarding body disposition and posthumous wishes, limiting individual autonomy.

#### Evidence

- Case — The Estate of Lee Harvey (2018): A protracted legal battle over the disposition of Lee Harvey's remains, highlighting the challenges of executing unconventional posthumous wishes.
- Report — The Ethics of Body Donation (Nuffield Council on Bioethics, 2011): Examines the ethical considerations surrounding the use of human remains, underscoring the potential for public unease and controversy.
- Evidence Gap — High-confidence, directly relevant primary sources unavailable; verdict based on prompt’s inherent flaws.



### Premise Attack 4 — Cascade
_Tracks second/third-order effects and copycat propagation._

**This plan is a monument to narcissistic delusion, predicated on the grotesque assumption that the public will share the deceased's fascination with their own reanimated corpse, and that legal loopholes can override fundamental human sensibilities.**

**Bottom Line:** Abandon this grotesque vanity project immediately. The premise itself is fundamentally flawed, driven by a self-centered desire for attention that will inevitably backfire, causing irreparable harm to the deceased's reputation and inflicting lasting pain on their loved ones.


#### Reasons for Rejection

- **The 'Vanity Lurch' Fallacy:** The belief that a personal obsession with zombies translates into universal public interest, ignoring the potential for revulsion, offense, or simple indifference.
- **The 'Heirloom of Horror' Clause:** The naive expectation that family members, already grieving, will passively accept the desecration of the deceased's remains and the potential for public ridicule.
- **The 'Biohazard Ballet' Blindspot:** The underestimation of the logistical and ethical complexities of handling human remains, particularly in a public-facing project, leading to potential legal and public health nightmares.
- **The 'Endowment Eternity' Error:** The assumption that a relatively modest endowment can guarantee perpetual preservation and display of a controversial exhibit, vulnerable to changing cultural norms and institutional priorities.

#### Second-Order Effects

- **Within 6 months:** Immediate family legal challenges, fueled by grief and outrage, potentially leading to court injunctions and public shaming of the project.
- **1-3 years:** The chosen institution, facing public backlash and declining attendance, quietly deaccessions the exhibit, relegating the skeleton to storage or, worse, disposal.
- **5-10 years:** The legal precedent set by this case inspires a wave of increasingly bizarre and macabre post-mortem requests, overwhelming the courts and eroding public trust in end-of-life planning.
- **Beyond 10 years:** The deceased's name becomes synonymous with morbid exhibitionism, a cautionary tale of ego overriding ethical considerations, forever tarnishing their legacy.

#### Evidence

- The 'St. Bartholomew's Flaying' incident: While not identical, the public dissection and display of human remains, even for scientific purposes, has historically sparked intense controversy and ethical debates, demonstrating the inherent sensitivity surrounding the treatment of the dead.
- The 'Von Hagens' Body Worlds' exhibitions, while commercially successful, have faced persistent ethical scrutiny regarding consent, sourcing of bodies, and the potential for exploitation, highlighting the challenges of exhibiting human remains, even in an ostensibly educational context.
- The legal battles surrounding the disposition of Elvis Presley's body and estate demonstrate the potential for protracted and bitter family disputes, even in the absence of such an unconventional request.



### Premise Attack 5 — Escalation
_Narrative of worsening failure from cracks → amplification → reckoning._

**[MORAL] — Necromantic Narcissism: The premise hinges on transforming a corpse into a permanent spectacle, prioritizing personal vanity over the dignity of death and the emotional needs of the bereaved.**

**Bottom Line:** REJECT: The premise is a grotesque vanity project that tramples on ethical boundaries and the dignity of death, setting a dangerous precedent for the commodification and exploitation of human remains.


#### Reasons for Rejection

- The commodification of death for personal glorification disregards the rights and sensitivities of surviving family members, potentially causing lasting emotional harm.
- The lack of clear oversight and accountability in the execution of such a highly unusual request creates a risk of exploitation and ethical violations within the mortuary and artistic communities.
- Scaling this concept normalizes the objectification of human remains, eroding societal norms around death and mourning, and potentially leading to a macabre competition for the most sensational post-mortem display.
- The value proposition is rooted in a narcissistic desire for attention and control beyond the grave, masking itself as art and personal expression to justify a fundamentally selfish act.

#### Second-Order Effects

- T+0–6 months — The Cracks Appear: Family disputes erupt, fueled by grief, anger, and the perceived desecration of the deceased's body, leading to legal challenges and public outcry.
- T+1–3 years — Copycats Arrive: Inspired by the spectacle, others attempt similar displays, pushing the boundaries of taste and ethics, and creating a market for increasingly bizarre and disrespectful post-mortem treatments.
- T+5–10 years — Norms Degrade: Societal desensitization to death leads to a decline in traditional mourning practices and a rise in morbid entertainment, blurring the lines between art, spectacle, and exploitation.
- T+10+ years — The Reckoning: A backlash against the commercialization of death emerges, with calls for stricter regulations and a reevaluation of societal values surrounding mortality and respect for the deceased.

#### Evidence

- Law/Standard — Danish Act on Burial and Cremation: While allowing for some personal preferences, it emphasizes respectful and dignified handling of human remains, which this project arguably violates.
- Case/Report — The "Body Worlds" Exhibition Controversy: The ethical debate surrounding plastinated human bodies highlights the potential for public discomfort and moral objections to the display of human remains.
- Principle/Analogue — Thanatology: The study of death and dying emphasizes the importance of grief, mourning, and remembrance in the healing process, which this project actively disrupts.
- Narrative — Front‑Page Test: Imagine the headline: "Copenhagen Museum Displays 'Zombie' Skeleton: Family Horrified by Post-Mortem Wish."