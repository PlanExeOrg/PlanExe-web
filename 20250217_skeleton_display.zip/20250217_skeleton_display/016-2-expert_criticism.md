# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Museum Conservator

**Knowledge**: artifact preservation, environmental control, material science, skeletal remains

**Why**: Needed to advise on the long-term preservation strategy, ensuring the skeleton's stability and display integrity.

**What**: Assess the proposed preservation methods and recommend optimal environmental conditions for the display case.

**Skills**: conservation planning, risk assessment, materials analysis, preventive conservation

**Search**: museum conservator, skeletal conservation, artifact preservation, Copenhagen

## 1.1 Primary Actions

- Immediately engage a risk management specialist experienced in cultural projects to conduct a thorough risk assessment and develop detailed contingency plans for the 'Pioneer's Gambit' scenario.
- Consult with a skeletal conservator to develop a comprehensive long-term preservation plan for the skeleton, including disaster preparedness and response.
- Conduct a formal ethical review of the project, involving ethicists, museum professionals, and representatives from relevant cultural or religious groups, and revise the display narrative and pose design accordingly.
- Obtain detailed quotes for all aspects of the project, including legal fees, osteologist services, display case fabrication, preservation, and ethical review, and revise the budget accordingly.
- Re-evaluate the 'Builder's Legacy' scenario as a viable alternative, considering its potential for mitigating family conflict and securing institutional support.

## 1.2 Secondary Actions

- Research and document case studies of similar unconventional memorialization projects, analyzing their successes and failures to identify best practices and potential pitfalls.
- Develop a detailed communication plan for engaging with potential host institutions, addressing their concerns and highlighting the project's educational and artistic value.
- Explore options for securing insurance coverage to protect against potential damage, theft, or legal liabilities.
- Create a detailed timeline for the project, including milestones, deadlines, and responsibilities, and regularly monitor progress to ensure it stays on track.

## 1.3 Follow Up Consultation

In the next consultation, we will review the revised risk assessment, preservation plan, ethical review findings, and budget. We will also discuss the progress in engaging with potential host institutions and developing a detailed communication plan. Be prepared to provide specific details on the qualifications and experience of the consultants you have engaged.

## 1.4.A Issue - Over-reliance on 'Pioneer's Gambit' without sufficient contingency planning.

The 'Pioneer's Gambit' scenario, while aligned with the client's ambition, carries significant risks related to family conflict and public controversy. The current plan lacks robust contingency plans if the legal strategy fails or if a suitable niche institution cannot be secured. The selection of this scenario appears to be driven more by alignment with the client's desires than a pragmatic assessment of potential roadblocks and alternative pathways. The other scenarios were dismissed too quickly.

### 1.4.B Tags

- risk_assessment
- contingency_planning
- scenario_selection
- confirmation_bias

### 1.4.C Mitigation

Develop detailed contingency plans for each key decision point within the 'Pioneer's Gambit' scenario. This includes alternative legal strategies, backup host institutions (including those considered in the 'Builder's Legacy' scenario), and revised communication approaches. Conduct a sensitivity analysis on the budget to identify areas where costs could escalate and develop mitigation strategies. Consult with a risk management specialist experienced in cultural projects to identify potential unforeseen challenges.

### 1.4.D Consequence

Without adequate contingency plans, the project is highly vulnerable to failure if the initial legal strategy is challenged, a suitable host institution cannot be found, or family objections escalate. This could result in significant financial losses and the inability to fulfill the client's wishes.

### 1.4.E Root Cause

Client's strong emotional attachment to the project and desire for a specific outcome may be clouding judgment and leading to an underestimation of potential risks.

## 1.5.A Issue - Insufficient detail regarding long-term preservation beyond environmental controls.

While the plan mentions environmental controls within the display case, it lacks specific details regarding the long-term preservation of the skeleton itself. Bone, even when properly prepared, is susceptible to degradation over time due to factors beyond humidity, temperature, and UV exposure. The plan needs to address potential issues like bone mineral loss, pest infestations (even in a sealed case), and the long-term effects of any adhesives or consolidants used during articulation. The plan also needs to address disaster planning.

### 1.5.B Tags

- preservation
- material_science
- risk_assessment
- disaster_planning

### 1.5.C Mitigation

Consult with a skeletal conservator specializing in osteological collections. Develop a comprehensive preservation plan that includes: (1) a detailed analysis of the bone's current condition and any existing damage; (2) selection of appropriate consolidants and adhesives that are chemically stable and reversible; (3) a schedule for regular inspections and cleaning by a trained conservator; (4) a disaster preparedness and response plan that addresses potential threats like fire, flood, and pest infestations; (5) a plan for re-housing or re-articulation if the original display case becomes compromised. Obtain quotes for these services and incorporate them into the trust fund.

### 1.5.D Consequence

Without a detailed preservation plan, the skeleton could deteriorate significantly over time, compromising its aesthetic appeal, scientific value, and the client's legacy. This could also lead to costly and potentially irreversible damage.

### 1.5.E Root Cause

Lack of expertise in skeletal conservation and a potential over-reliance on the display case to provide complete protection.

## 1.6.A Issue - Ethical considerations surrounding the 'zombie' pose are inadequately addressed.

The plan specifies a 'zombie-like' pose, which raises ethical concerns about the respectful treatment of human remains. While the client intends the pose to be dignified, the public perception may differ, potentially leading to accusations of disrespect, sensationalism, or even mockery. The current narrative framing focuses on personal expression but does not adequately address the potential for negative ethical interpretations, particularly from religious or cultural groups.

### 1.6.B Tags

- ethics
- public_perception
- narrative_framing
- cultural_sensitivity

### 1.6.C Mitigation

Conduct a thorough ethical review of the project, involving ethicists, museum professionals, and representatives from relevant cultural or religious groups. Explore alternative poses that evoke the intended theme without being overtly 'zombie-like' or potentially offensive. Refine the display narrative to emphasize the artistic and memorial aspects of the project, while acknowledging the ethical complexities and demonstrating respect for the deceased. Conduct public opinion research to gauge potential reactions to the pose and narrative, and adjust the plan accordingly. Document the ethical review process and incorporate its findings into the display's interpretive materials.

### 1.6.D Consequence

Failure to address ethical concerns could result in negative media coverage, public protests, and the refusal of potential host institutions to display the skeleton. This could damage the project's reputation and undermine its intended legacy.

### 1.6.E Root Cause

Client's focus on personal expression may be overshadowing the need to consider broader ethical implications and public perceptions.

---

# 2 Expert: End-of-Life Doula

**Knowledge**: end-of-life care, grief counseling, family mediation, legacy projects

**Why**: To provide support and guidance in navigating the emotional and practical aspects of end-of-life planning, especially with family.

**What**: Facilitate family discussions and help create a supportive environment for communicating the client's wishes.

**Skills**: active listening, empathy, conflict resolution, communication skills

**Search**: end of life doula, grief counseling, family mediation, Copenhagen

## 2.1 Primary Actions

- Immediately engage a family systems therapist or psychologist specializing in grief and family dynamics to assess and address potential family objections.
- Conduct a thorough ethical review of the project, consulting with ethicists specializing in death and dying, museum ethics, and cultural representation.
- Identify and vet at least two backup osteologists and mortuary vendors with the necessary expertise and facilities, securing written agreements outlining responsibilities and contingency plans.

## 2.2 Secondary Actions

- Conduct in-depth, one-on-one interviews with key family members to understand their values, beliefs, and concerns.
- Conduct focus groups with diverse members of the Copenhagen public to gauge their reactions to the proposed display.
- Consult with museum professionals experienced in handling sensitive or controversial exhibits.

## 2.3 Follow Up Consultation

Discuss the findings of the family assessments, ethical review, and vendor vetting process. Review and revise the project plan based on these findings, with a particular focus on the family communication strategy, ethical framework, and contingency plans.

## 2.4.A Issue - Over-reliance on Legal Solutions Without Addressing Root Causes

The plan heavily emphasizes legal strategies (court orders, ironclad wills) to overcome potential family objections. While legal protection is crucial, it appears to be the *primary* strategy, overshadowing deeper exploration of the root causes of potential family resistance. This approach risks alienating family members and creating an adversarial environment, potentially leading to more aggressive legal challenges, regardless of the strength of the legal documentation. The focus should shift towards understanding and addressing the underlying emotional and psychological factors driving potential objections.

### 2.4.B Tags

- family conflict
- legal over-reliance
- root cause neglect

### 2.4.C Mitigation

Consult with a family systems therapist or a psychologist specializing in grief and family dynamics *before* finalizing the legal strategy. Gather data: Conduct in-depth, one-on-one interviews with key family members to understand their values, beliefs about death and memorialization, and any pre-existing conflicts. Use this information to tailor the family communication approach and address their specific concerns. Read: "Difficult Conversations: How to Discuss What Matters Most" by Douglas Stone, Bruce Patton, and Sheila Heen.

### 2.4.D Consequence

Increased family conflict, potential legal challenges despite strong legal documentation, emotional distress for all parties involved, and potential sabotage of the project even after death.

### 2.4.E Root Cause

Fear of losing control over the project and a lack of trust in the family's ability to understand or accept the client's wishes.

## 2.5.A Issue - Insufficient Exploration of Ethical Implications and Public Perception

While the plan mentions a PR strategy, it seems reactive rather than proactive. The ethical implications of publicly displaying a posed human skeleton, particularly in a 'zombie-like' stance, are complex and require deeper consideration. The plan lacks a thorough exploration of potential cultural sensitivities, religious beliefs, and the potential for causing offense or distress to the public. The 'Pioneer's Gambit' scenario, while aligned with the client's vision, amplifies this risk by pushing ethical boundaries without a clear understanding of the potential consequences. The plan needs a more robust ethical framework to guide decision-making and mitigate potential negative impacts.

### 2.5.B Tags

- ethical oversight
- public backlash
- cultural sensitivity

### 2.5.C Mitigation

Conduct a thorough ethical review of the project, consulting with ethicists specializing in death and dying, museum ethics, and cultural representation. Gather data: Conduct focus groups with diverse members of the Copenhagen public to gauge their reactions to the proposed display and identify potential ethical concerns. Read: "Death Rights: Transforming How We Die in the Twenty-First Century" by Romayne Gallagher. Consult with museum professionals experienced in handling sensitive or controversial exhibits.

### 2.5.D Consequence

Negative media coverage, public protests, damage to the project's reputation, potential closure of the display, and lasting harm to the client's legacy.

### 2.5.E Root Cause

A focus on personal expression overshadowing consideration of the broader societal impact and potential harm to others.

## 2.6.A Issue - Lack of Contingency Planning for Osteologist and Mortuary Vendor Issues

The plan identifies the osteologist and mortuary vendor as key stakeholders, but it lacks detailed contingency plans for potential issues such as the osteologist becoming unavailable, the mortuary vendor going out of business, or either party failing to meet the project's requirements. Given the specialized nature of the project, finding suitable replacements could be challenging and time-consuming. The plan needs to address these operational risks with specific backup plans and alternative vendor options.

### 2.6.B Tags

- operational risk
- vendor dependency
- contingency planning

### 2.6.C Mitigation

Identify and vet at least two backup osteologists and mortuary vendors with the necessary expertise and facilities. Gather data: Obtain written agreements from the primary and backup vendors outlining their responsibilities, timelines, and contingency plans. Read: "The Checklist Manifesto: How to Get Things Right" by Atul Gawande. Consult with project management professionals to develop a detailed risk management plan.

### 2.6.D Consequence

Significant delays in project execution, increased costs due to emergency vendor replacements, potential compromise of the project's quality, and failure to meet the 12-18 month timeline.

### 2.6.E Root Cause

Underestimation of the complexity of the project and a failure to anticipate potential operational challenges.

---

# The following experts did not provide feedback:

# 3 Expert: Art Law Specialist

**Knowledge**: art law, intellectual property, cultural heritage law, Danish law

**Why**: Needed to navigate the legal complexities of displaying human remains as art and protecting the intellectual property rights.

**What**: Advise on structuring the legal framework to protect the display as art and address potential copyright issues.

**Skills**: contract negotiation, legal research, intellectual property law, art market

**Search**: art law specialist, intellectual property, cultural heritage, Denmark

# 4 Expert: Forensic Anthropologist

**Knowledge**: skeletal anatomy, taphonomy, forensic science, human osteology

**Why**: To ensure anatomical accuracy of the skeletal pose and provide scientific context to the display narrative.

**What**: Review the skeletal pose design for anatomical plausibility and advise on educational materials.

**Skills**: skeletal analysis, anatomical reconstruction, scientific communication, research

**Search**: forensic anthropologist, skeletal anatomy, human osteology, Copenhagen

# 5 Expert: Trust & Estate Accountant

**Knowledge**: trust accounting, estate tax, charitable giving, Danish tax law

**Why**: Needed to advise on the financial aspects of the trust, ensuring compliance with tax laws and maximizing long-term sustainability.

**What**: Review the trust structure and provide recommendations for tax-efficient management of assets.

**Skills**: financial planning, tax compliance, estate administration, accounting

**Search**: trust accountant, estate tax, charitable giving, Denmark

# 6 Expert: Museum Exhibition Designer

**Knowledge**: exhibition design, museum planning, visitor experience, accessibility

**Why**: To optimize the display case design for visual impact, security, and long-term preservation, enhancing the visitor experience.

**What**: Advise on the display case design, ensuring it meets museum standards for preservation and security.

**Skills**: spatial design, visual communication, project management, accessibility

**Search**: museum exhibition designer, display case design, visitor experience

# 7 Expert: Bioethics Consultant

**Knowledge**: bioethics, medical ethics, public health ethics, human remains

**Why**: To address potential ethical concerns surrounding the display of human remains and ensure responsible communication.

**What**: Review the project's ethical implications and advise on strategies for addressing public concerns.

**Skills**: ethical analysis, risk communication, stakeholder engagement, moral reasoning

**Search**: bioethics consultant, medical ethics, public display, human remains

# 8 Expert: Public Art Curator

**Knowledge**: public art, contemporary art, art criticism, cultural institutions

**Why**: To assess the artistic merit of the project and advise on framing it within the context of contemporary art.

**What**: Provide an artistic critique of the project and suggest ways to enhance its cultural significance.

**Skills**: art curation, art criticism, exhibition planning, art market

**Search**: public art curator, contemporary art, art criticism, Copenhagen