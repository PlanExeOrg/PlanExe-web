*Roles Needed & Example People*

# Roles

## 1. Legal Specialist (Body Disposition Law)

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Specialized legal expertise is needed for a defined period.  An independent contractor allows access to this expertise without a long-term employment commitment.

**Explanation**:
Ensures all actions comply with Danish law regarding body disposition, anatomical gifts, and public display, mitigating legal challenges.

**Consequences**:
Project could be halted or significantly altered due to legal challenges, resulting in wasted resources and failure to fulfill the client's wishes.

**People Count**:
min 1, max 2, depending on the complexity of Danish law and the need for specialized expertise in related areas (e.g., intellectual property).

**Typical Activities**:
Drafting legally sound wills and advance directives, securing necessary permits and approvals, advising on ethical considerations, and representing the client's interests in legal proceedings.

**Background Story**:
Astrid Nielsen, a sharp legal mind from Aarhus, Denmark, has dedicated her career to navigating the complex intersection of body disposition law and individual rights. After graduating from Aarhus University with a law degree specializing in bioethics, she spent several years working for a prominent Copenhagen law firm, where she gained extensive experience in estate planning and end-of-life directives. Astrid's deep understanding of Danish legal precedents and her passion for protecting individual autonomy make her uniquely suited to handle the legal challenges of this project. She is particularly adept at drafting legally binding documents that can withstand potential family challenges and securing necessary court orders.

**Equipment Needs**:
Computer with internet access, legal research databases, secure communication channels.

**Facility Needs**:
Office space for legal research and document preparation, access to legal libraries and archives.

## 2. Grief Counselor / Family Mediator

**Contract Type**: `independent_contractor`

**Contract Type Justification**: A grief counselor/mediator is needed for a specific purpose and duration.  This role is best filled by an independent contractor with expertise in family dynamics and end-of-life planning.

**Explanation**:
Facilitates communication with the client's family, addressing concerns and minimizing potential conflicts regarding the unconventional nature of the project.

**Consequences**:
Increased risk of family disputes, legal challenges to the will, and negative publicity, potentially derailing the project and causing emotional distress to the family.

**People Count**:
1

**Typical Activities**:
Facilitating family meetings, providing grief counseling, mediating conflicts, and developing communication strategies.

**Background Story**:
Henrik Olsen, a compassionate and experienced grief counselor from Odense, Denmark, has spent over 15 years helping families navigate the emotional complexities of death and bereavement. With a master's degree in psychology and specialized training in family mediation, Henrik has a proven track record of facilitating difficult conversations and resolving conflicts in a sensitive and constructive manner. His calm demeanor and empathetic approach make him an ideal choice for engaging with the client's family and addressing any concerns or objections they may have regarding the project. Henrik is skilled at creating a safe space for open dialogue and finding common ground, ensuring that the client's wishes are respected while also honoring the emotional needs of their loved ones.

**Equipment Needs**:
Private office space, recording equipment for client video message, video conferencing equipment.

**Facility Needs**:
Quiet, confidential meeting room for family sessions, access to grief counseling resources.

## 3. Osteologist / Anatomical Preparator

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Osteologists are highly specialized.  Hiring one as an independent contractor allows access to their skills for the duration of the skeletal preparation and articulation process.

**Explanation**:
Performs the skeletal preparation, articulation, and posing, ensuring anatomical accuracy and artistic vision are realized.

**Consequences**:
The skeleton may be improperly prepared, inaccurately posed, or prone to deterioration, compromising the project's artistic and scientific integrity.

**People Count**:
1

**Typical Activities**:
Skeletal preparation, articulation, posing, anatomical reconstruction, and preservation.

**Background Story**:
Freja Christensen, a meticulous and highly skilled osteologist from Copenhagen, Denmark, has a lifelong fascination with the human skeleton. After earning a degree in archaeology from the University of Copenhagen, she pursued specialized training in anatomical preparation and skeletal articulation. Freja has worked on numerous museum exhibits and forensic cases, honing her expertise in cleaning, preserving, and posing skeletal remains. Her artistic eye and attention to detail ensure that the client's skeleton will be prepared with the utmost care and precision, resulting in a stunning and anatomically accurate display. Freja is also well-versed in biohazard safety protocols and ethical considerations related to working with human remains.

**Equipment Needs**:
Osteological tools, PPE, articulation materials, specialized lighting, photography equipment.

**Facility Needs**:
Licensed mortuary facility with biohazard containment, anatomical preparation lab with ventilation and disposal systems.

## 4. Biohazard Safety Consultant

**Contract Type**: `independent_contractor`

**Contract Type Justification**: A biohazard safety consultant is needed for a specific project phase.  An independent contractor provides the necessary expertise without a long-term commitment.

**Explanation**:
Develops and oversees the implementation of biohazard protocols during the decomposition and preparation phases, ensuring the safety of personnel and compliance with regulations.

**Consequences**:
Increased risk of biohazard exposure, legal liabilities, and project delays due to safety violations.

**People Count**:
1

**Typical Activities**:
Developing biohazard protocols, conducting risk assessments, providing safety training, and overseeing waste disposal.

**Background Story**:
Mads Jørgensen, a pragmatic and highly qualified biohazard safety consultant from Aalborg, Denmark, has dedicated his career to protecting people from the risks associated with hazardous materials. With a degree in environmental science and certifications in industrial hygiene and safety management, Mads has extensive experience in developing and implementing biohazard protocols for a wide range of industries, including healthcare, research, and waste management. His meticulous approach and deep understanding of safety regulations make him an invaluable asset to this project. Mads is committed to ensuring that all personnel involved in the skeletal preparation process are protected from potential biohazard exposure and that all waste materials are disposed of in a safe and environmentally responsible manner.

**Equipment Needs**:
Air monitoring equipment, PPE, testing equipment, computer with data analysis software.

**Facility Needs**:
Access to mortuary facility for inspections, laboratory for sample analysis, office space for report writing.

## 5. Trust Manager / Financial Planner

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The trust manager requires a long-term commitment to ensure the trust's financial stability and compliance. A full-time employee provides the necessary oversight and management.

**Explanation**:
Manages the trust fund, ensuring sufficient resources are available for long-term preservation, maintenance, and potential legal challenges.

**Consequences**:
The project may face funding shortfalls, jeopardizing its long-term sustainability and potentially leading to the removal of the display.

**People Count**:
1

**Typical Activities**:
Managing trust funds, developing investment strategies, ensuring financial compliance, and providing financial advice.

**Background Story**:
Signe Rasmussen, a diligent and trustworthy financial planner from Roskilde, Denmark, has a passion for helping individuals and families achieve their long-term financial goals. With a degree in economics and certifications in financial planning and trust management, Signe has a proven track record of managing complex financial portfolios and ensuring the long-term sustainability of charitable trusts. Her expertise in investment strategies, tax planning, and estate administration makes her an ideal choice for managing the trust fund that will support this project. Signe is committed to ensuring that sufficient resources are available for the long-term preservation, maintenance, and potential legal challenges associated with the skeletal display.

**Equipment Needs**:
Computer with financial planning software, secure access to financial databases, communication tools.

**Facility Needs**:
Office space for financial analysis and client communication, access to financial institutions.

## 6. Museum Curator / Exhibition Designer

**Contract Type**: `independent_contractor`

**Contract Type Justification**: A museum curator/exhibition designer is needed for a specific project phase.  An independent contractor provides the necessary expertise without a long-term commitment.

**Explanation**:
Advises on display case design, environmental controls, and the overall presentation of the skeleton within a museum or gallery setting, ensuring long-term preservation and public engagement.

**Consequences**:
The display may be poorly designed, lack adequate preservation measures, or fail to engage the public effectively, diminishing its impact and longevity.

**People Count**:
1

**Typical Activities**:
Advising on display case design, environmental controls, exhibit layout, and public engagement strategies.

**Background Story**:
Klaus Schmidt, a visionary and experienced museum curator from Aarhus, Denmark, has a passion for creating engaging and thought-provoking exhibits that connect with audiences on an emotional level. With a degree in art history and specialized training in museum studies, Klaus has curated numerous successful exhibitions at museums and galleries throughout Denmark. His expertise in display case design, environmental controls, and the overall presentation of artifacts makes him an invaluable asset to this project. Klaus is committed to ensuring that the skeletal display is both aesthetically pleasing and scientifically accurate, while also respecting the ethical considerations associated with displaying human remains.

**Equipment Needs**:
Computer with design software, access to museum databases, communication tools.

**Facility Needs**:
Access to potential host institutions for site visits, design studio for exhibit planning.

## 7. Public Relations / Communications Specialist

**Contract Type**: `independent_contractor`

**Contract Type Justification**: A PR/communications specialist is needed for a specific project phase.  An independent contractor provides the necessary expertise without a long-term commitment.

**Explanation**:
Manages the public narrative surrounding the project, addressing ethical concerns and promoting understanding of the client's artistic vision.

**Consequences**:
Increased risk of negative media coverage, ethical backlash, and public opposition, potentially damaging the project's reputation and hindering its success.

**People Count**:
1

**Typical Activities**:
Developing public relations strategies, managing media relations, addressing ethical concerns, and promoting understanding of the project's artistic vision.

**Background Story**:
Louise Jensen, a strategic and results-oriented public relations specialist from Copenhagen, Denmark, has a proven track record of managing public perception and promoting understanding of complex and often controversial issues. With a degree in communications and extensive experience in media relations, crisis management, and stakeholder engagement, Louise is skilled at crafting compelling narratives that resonate with target audiences. Her expertise in ethical communication and her ability to navigate sensitive situations make her an ideal choice for managing the public narrative surrounding this project. Louise is committed to ensuring that the client's artistic vision is understood and appreciated, while also addressing any ethical concerns or potential backlash from the public.

**Equipment Needs**:
Computer with media monitoring software, communication tools, access to media contacts.

**Facility Needs**:
Office space for media monitoring and communication, access to press conferences and media events.

## 8. Estate Executor / Project Coordinator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The estate executor/project coordinator requires a long-term commitment to oversee all aspects of the project. A full-time employee provides the necessary oversight and management.

**Explanation**:
Oversees all aspects of the project, ensuring smooth execution, adherence to the client's wishes, and effective communication between all stakeholders.

**Consequences**:
Lack of coordination, delays, and potential conflicts between stakeholders, jeopardizing the project's overall success.

**People Count**:
min 1, max 2, depending on the complexity of the estate and the need for specialized project management skills. A co-executor arrangement might be beneficial.

**Typical Activities**:
Overseeing all aspects of the project, ensuring adherence to legal requirements, managing communication between stakeholders, and resolving conflicts.

**Background Story**:
Peter Hansen, a meticulous and highly organized estate executor from Copenhagen, Denmark, has a proven track record of managing complex estates and ensuring that the wishes of the deceased are carried out with the utmost care and precision. With a degree in law and extensive experience in estate administration, Peter is skilled at navigating the legal and financial complexities of estate settlement. His calm demeanor and attention to detail make him an ideal choice for overseeing all aspects of this project, from securing the necessary legal authorizations to coordinating the skeletal preparation and display. Peter is committed to ensuring that the client's wishes are honored and that all stakeholders are kept informed throughout the process.

**Equipment Needs**:
Computer with project management software, communication tools, secure document storage.

**Facility Needs**:
Office space for project coordination, access to all project-related facilities and stakeholders.

---

# Omissions

## 1. Contingency Plan for Osteologist Unavailability

The plan relies heavily on a single osteologist. If the osteologist becomes unavailable due to illness, relocation, or other unforeseen circumstances, the project could face significant delays and require finding a replacement with comparable skills and experience.

**Recommendation**:
Identify and vet a secondary osteologist as a backup. Establish a contract with the primary osteologist that includes provisions for transferring responsibilities and knowledge to a replacement if necessary. This could involve detailed documentation of the preparation process and access to ongoing work.

## 2. Plan for Display Case Maintenance and Repair

The plan mentions environmental controls but lacks detail on the ongoing maintenance and potential repair of the display case. Mechanical failures or damage could compromise the skeleton's preservation and require costly interventions.

**Recommendation**:
Develop a detailed maintenance schedule for the display case, including regular inspections, cleaning, and calibration of environmental controls. Establish a service agreement with the display case fabricator or a qualified technician for repairs and maintenance. Allocate funds within the trust specifically for display case upkeep.

## 3. Succession Planning for Key Roles

The plan identifies key roles like the Estate Executor and Trust Manager. However, it doesn't address what happens if these individuals become incapacitated or resign. Lack of succession planning could lead to disruptions and delays.

**Recommendation**:
For the Estate Executor and Trust Manager roles, designate successor individuals in the will and trust documents, respectively. Ensure these successors are fully briefed on the project's goals, legal requirements, and financial details. Consider a co-executor or co-trustee arrangement to provide redundancy.

---

# Potential Improvements

## 1. Clarify Family Involvement in Display Narrative

While the plan includes family communication, it's unclear whether family members will have input into the display narrative. Excluding them entirely could exacerbate potential conflicts.

**Recommendation**:
Offer family members the opportunity to contribute to the public-facing narrative, perhaps by sharing personal anecdotes or memories related to the client's fascination with zombies or their views on memorialization. This could foster a sense of involvement and ownership, mitigating potential resistance.

## 2. Formalize Communication Protocol Between Key Stakeholders

The plan mentions communication between stakeholders but lacks a formal protocol. This could lead to miscommunication, delays, and conflicting priorities.

**Recommendation**:
Establish a regular communication schedule (e.g., weekly or bi-weekly meetings) involving the Estate Executor, Osteologist, Trust Manager, and PR Specialist. Use a shared project management tool to track progress, assign tasks, and document decisions. This will ensure everyone is on the same page and working towards the same goals.

## 3. Define Criteria for 'Dignified' Zombie Pose

The plan specifies a 'dignified' zombie pose, but this is subjective. Lack of a clear definition could lead to disagreements and delays in the skeletal preparation phase.

**Recommendation**:
Develop a set of visual references or guidelines that illustrate the desired balance between zombie imagery and dignity. This could involve creating sketches, mockups, or mood boards that capture the intended aesthetic. Obtain feedback from the client (if possible) and key stakeholders on these visual aids to ensure alignment.