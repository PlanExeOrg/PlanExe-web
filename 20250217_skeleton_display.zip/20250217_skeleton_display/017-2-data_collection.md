## 1. Legal Authorization Strategy

A robust legal strategy minimizes the risk of family challenges and ensures the project's execution according to the deceased's wishes.

### Data to Collect

- Legal documentation requirements for post-mortem skeletal preparation
- Danish body disposition laws and regulations
- Potential legal challenges and precedents

### Simulation Steps

- Use legal research databases (e.g., Westlaw, LexisNexis) to gather information on Danish body disposition laws
- Simulate potential legal scenarios using legal case studies to understand implications

### Expert Validation Steps

- Consult with Astrid Nielsen, a legal specialist in body disposition law in Denmark
- Engage with the Danish Health Authority for regulatory compliance

### Responsible Parties

- Estate Executor
- Legal Specialist

### Assumptions

- **High:** Danish laws allow skeletal preparation with authorization and ethical considerations.

### SMART Validation Objective

Secure a pre-approval or court order affirming the legality of the post-mortem skeletal preparation within 6 months.

### Notes

- Legal complexities may arise due to the unconventional nature of the project.


## 2. Family Communication Approach

Open and empathetic communication with family members can foster understanding and reduce the likelihood of legal challenges.

### Data to Collect

- Family members' concerns and objections regarding the project
- Effective communication strategies for discussing sensitive topics

### Simulation Steps

- Conduct role-playing exercises to practice family discussions
- Use surveys to gauge family members' initial reactions to the project

### Expert Validation Steps

- Engage Henrik Olsen, a grief counselor or mediator, to facilitate family discussions
- Consult with family systems therapists for communication strategies

### Responsible Parties

- Estate Executor
- Grief Counselor

### Assumptions

- **High:** Family will engage with a counselor to address concerns.

### SMART Validation Objective

Complete facilitated discussions with immediate family by 2026-04-15 to address their concerns and foster understanding.

### Notes

- Family dynamics may complicate communication efforts.


## 3. Display Narrative Framing

A well-crafted public narrative can shape public perception and minimize negative reactions to the unconventional display.

### Data to Collect

- Public perception of the proposed display narrative
- Ethical considerations surrounding the display of human remains

### Simulation Steps

- Conduct focus groups to gather public opinions on the display narrative
- Analyze case studies of similar projects for narrative effectiveness

### Expert Validation Steps

- Consult with bioethics experts to review ethical implications
- Engage public art curators for feedback on narrative framing

### Responsible Parties

- Public Relations Specialist
- Museum Curator

### Assumptions

- **High:** The narrative will be accepted by the public and family.

### SMART Validation Objective

Develop a public narrative that resonates with audiences and addresses ethical concerns by 2026-05-30.

### Notes

- Public backlash could arise if the narrative is perceived as disrespectful.


## 4. Host Institution Selection

Securing a reputable host institution ensures the long-term preservation and public accessibility of the display.

### Data to Collect

- List of potential host institutions in Copenhagen
- Criteria for selecting a suitable institution

### Simulation Steps

- Research and compile a list of at least five potential host institutions
- Evaluate institutions based on their previous exhibitions and public engagement

### Expert Validation Steps

- Consult with museum professionals to assess institutional fit
- Engage with potential host institutions to gauge interest

### Responsible Parties

- Estate Executor
- Museum Curator

### Assumptions

- **High:** A suitable host institution will be willing to permanently display the skeleton.

### SMART Validation Objective

Secure a commitment from a suitable host institution by 2026-05-30.

### Notes

- Institutional resistance may arise due to the unconventional nature of the display.


## 5. Trust Structure Design

The structure of the trust determines its ability to withstand legal challenges and ensure long-term funding.

### Data to Collect

- Financial requirements for long-term maintenance and preservation
- Tax implications of the trust structure

### Simulation Steps

- Conduct financial modeling to estimate long-term funding needs
- Analyze different trust structures for tax efficiency

### Expert Validation Steps

- Consult with a financial advisor and tax attorney for trust structure design
- Engage with trust and estate accountants for compliance

### Responsible Parties

- Trust Manager
- Financial Planner

### Assumptions

- **High:** The trust will generate sufficient income for long-term sustainability.

### SMART Validation Objective

Establish an irrevocable charitable trust with a board of directors by 2026-04-30.

### Notes

- Financial shortfalls could jeopardize the project's completion.

## Summary

Immediate actionable tasks include validating the most sensitive assumptions related to legal authorization, family communication, display narrative framing, host institution selection, and trust structure design. Engage relevant experts and initiate data collection processes to ensure project success.