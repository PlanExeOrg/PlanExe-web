Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 15 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 4 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the project does not inherently require breaking any physical laws. The plan focuses on legal, ethical, and logistical challenges rather than fundamental physics.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of post-mortem skeletal preparation, zombie-inspired display, and public exhibition without precedent at comparable scale. There is no independent evidence this combination is viable. 

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/Regulatory, Technical/Safety, and Ethics/Societal. Each track must produce an authoritative source or supervised pilot showing results vs a baseline. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Owner: Project Lead / Deliverable: Validation Report / Date: 90 days


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan uses strategic concepts like "Legal Authorization Strategy", "Family Communication Approach", and "Display Narrative Framing" without defining their inputs→process→customer value. The plan lacks one-pagers defining these concepts.

**Mitigation**: Project Lead: Create one-pagers for each strategic concept, defining the mechanism-of-action (inputs→process→customer value), owner, and measurable outcomes. Due date: 30 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the risk register only identifies broad categories (regulatory, social, ethical, etc.) without analyzing specific cascade effects. The plan does not map how a permit delay could lead to a cash crunch.

**Mitigation**: Risk Management Specialist: Expand the risk register to include specific cascade scenarios (e.g., permit delay -> missed peak season -> revenue shortfall). Add controls and a dated review cadence. Due date: 60 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan assumes a 6-month timeline to secure legal authorizations, but the plan lacks evidence that this is achievable in the Danish legal system. The plan does not include a permit/approval matrix.

**Mitigation**: Legal Counsel: Rebuild the critical path with dated predecessors, authoritative permit lead times, and a NO-GO threshold on slip. Deliverable: Revised timeline. Date: 30 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions a 1.5 million DKK trust but lacks details on funding sources, draw schedule, and covenants. The plan does not include a financing plan listing sources/status, draw schedule, and covenants.

**Mitigation**: Trust Manager: Develop a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO‑GO on missed financing gates. Due date: 60 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget conflicts with the need for detailed vendor quotes and scale-appropriate benchmarks. The plan lacks evidence of cost normalization per area, which is critical for budget validation.

**Mitigation**: Owner: Project Manager; Deliverable: Obtain at least three vendor quotes, normalize costs per m², and adjust the budget or de-scope by 30 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents the 12-18 month completion timeline as a single point estimate without discussing alternative scenarios or providing a range. The plan lacks a sensitivity analysis for the timeline.

**Mitigation**: Project Manager: Conduct a schedule risk analysis, including best-case, worst-case, and most-likely scenarios, and identify critical path dependencies. Due date: 30 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks essential engineering artifacts such as specifications, interface contracts, acceptance tests, and an integration plan for critical components. Their absence creates a likely failure mode.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners and dates within 60 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes several critical claims without providing verifiable evidence. For example, it states, "Secure comprehensive legal authorization through a detailed will..." but does not include a sample will or authorization. 

**Mitigation**: Legal Team: Draft a sample will and advance directives demonstrating comprehensive legal authorization, including clauses addressing potential objections, within 60 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the deliverable "a new system" is mentioned without specific, verifiable qualities. The plan does not define acceptance criteria for the system.

**Mitigation**: Engineering Team: Define SMART acceptance criteria for the new system, including a KPI for system uptime (e.g., 99.9% availability), within 30 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes a 'zombie-like' pose, which adds complexity without clear support for the core goals of memorialization or preservation. It does not directly support legal defensibility or family harmony.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the 'zombie-like' pose, complete with a KPI, owner, and estimated cost, or move the feature to the project backlog. Due date: 30 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a highly specialized osteologist with expertise in both anatomical accuracy and artistic posing for a 'zombie-like' display. This combination of skills is rare and difficult to source.

**Mitigation**: Project Manager: Validate the talent market for osteologists with anatomical and artistic posing expertise in Denmark. Deliverable: List of 3+ qualified candidates. Date: 30 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not map required permits/licenses, controlling regimes/statutes, authorities, artifacts, lead times, or predecessors. Legality is unclear, and required approvals are unmapped, a potential showstopper.

**Mitigation**: Legal Team: Conduct a fatal-flaw analysis and create a regulatory matrix (authority, artifact, lead time, predecessors). Report NO-GO findings immediately. Due date: 60 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies the Trust Structure Design as critical for long-term sustainability, but lacks detail on income generation, maintenance costs, and adaptation mechanisms. The plan does not include a detailed operational sustainability plan.

**Mitigation**: Trust Manager: Develop an operational sustainability plan including a funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms. Due date: 90 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because success hinges on zoning/land‑use, occupancy/egress, fire load, structural limits, noise, and permits, but the plan does not map required permits/licenses, controlling regimes/statutes, authorities, artifacts, lead times, or predecessors.

**Mitigation**: Legal Team: Conduct a fatal-flaw analysis and create a regulatory matrix (authority, artifact, lead time, predecessors). Report NO-GO findings immediately. Due date: 60 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies vendors but lacks SLAs or tested failover plans. The plan mentions biohazard protocols but does not include evidence of secondary mortuary vendors or failover testing. 

**Mitigation**: Operations: Secure SLAs with primary vendors, identify a secondary mortuary vendor, and document a tested failover plan by 2024-08-01.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan states goals for 'Estate Executor' (smooth administration) and 'Family' (understanding), but does not address their conflicting incentives (executor must execute the will, even if the family objects).

**Mitigation**: Project Lead: Define a shared, measurable objective (OKR) for the Estate Executor and Family that aligns on a common outcome (e.g., 'Minimize legal challenges'). Due date: 30 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Establish a monthly review with a KPI dashboard and a lightweight change board to monitor progress and address deviations. Due date: 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies several high risks (legal, social, financial, operational) but lacks a cross-impact analysis. A legal challenge could trigger financial shortfalls and institutional withdrawal, but this cascade is not captured.

**Mitigation**: Risk Management Specialist: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Due date: 60 days.