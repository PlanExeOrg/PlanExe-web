A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The local Kødbyen community will embrace provocative marketing. | Run a small-scale, targeted ad campaign with provocative messaging and monitor community reaction on social media and local forums. | Negative sentiment exceeds 30% in online feedback within one week of the ad campaign launch. |
| A2 | High-quality plant-based meat alternatives can be consistently sourced at stable prices. | Obtain quotes and samples from at least three different plant-based meat suppliers and analyze their pricing history and supply chain stability. | Price volatility exceeds 15% month-over-month for key ingredients, or any supplier fails to guarantee supply for the next 6 months. |
| A3 | The grand opening will occur on schedule in month 3. | Create a detailed timeline with dependencies and milestones, and track progress weekly. Conduct a risk assessment to identify potential delays. | Any critical path task is delayed by more than 2 weeks by the end of month 1. |
| A4 | Local restaurants will be receptive to partnering with the vegan butcher shop. | Contact 10 local restaurants and gauge their interest in featuring the shop's plant-based meats on their menus or collaborating on joint promotions. | Fewer than 3 restaurants express genuine interest in a partnership. |
| A5 | The POS system will integrate seamlessly with inventory management and online ordering platforms. | Test the integration of the selected POS system with a sample inventory database and a mock online ordering platform. | The POS system fails to accurately track inventory or process online orders in the test environment. |
| A6 | The shop can attract and retain qualified staff with competitive wages and benefits. | Research local wage rates for similar positions and survey potential candidates about their salary expectations and desired benefits. | The shop receives fewer than 5 qualified applications per job posting, or the average salary expectation exceeds the budgeted amount by more than 10%. |
| A7 | Customers will be willing to pay a premium for sustainable packaging. | Offer a small discount for customers who bring their own containers and track the percentage of customers who opt for this option. | Less than 10% of customers choose the discount option within the first month. |
| A8 | The local power grid can reliably support the shop's energy demands, including refrigeration and cooking equipment. | Consult with the local power company to assess the grid's capacity and potential for outages in the Kødbyen area. | The power company identifies potential grid limitations or a history of frequent outages that could disrupt operations. |
| A9 | The shop's location in Kødbyen will remain a desirable destination for locals and tourists. | Monitor foot traffic in Kødbyen and track the number of new businesses opening and closing in the area. | Foot traffic declines by more than 15% month-over-month, or more than 3 businesses close in Kødbyen within a 3-month period. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Price Gouge Panic | Process/Financial | A2 | Financial Controller | CRITICAL (16/25) |
| FM2 | The Grand Opening Gridlock | Technical/Logistical | A3 | Operations Manager | CRITICAL (15/25) |
| FM3 | The Provocation Backfire | Market/Human | A1 | Marketing & Brand Manager | HIGH (10/25) |
| FM4 | The Partnership Desertion | Process/Financial | A4 | Partnership Development Lead | CRITICAL (16/25) |
| FM5 | The System Shutdown | Technical/Logistical | A5 | IT Manager | CRITICAL (15/25) |
| FM6 | The Staffing Shortage | Market/Human | A6 | Human Resources Manager | HIGH (10/25) |
| FM7 | The Green Premium Paradox | Market/Human | A7 | Marketing & Brand Manager | HIGH (12/25) |
| FM8 | The Powerless Plant-Based | Technical/Logistical | A8 | Operations Manager | HIGH (10/25) |
| FM9 | The Kødbyen Exodus | Process/Financial | A9 | Shop Manager | HIGH (10/25) |


### Failure Modes

#### FM1 - The Price Gouge Panic

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: Financial Controller
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The assumption of stable plant-based meat prices proves false. A major plant-based meat supplier experiences a production crisis due to a rare crop failure, leading to a sudden 40% price increase. The Supply Chain Coordinator scrambles to find alternative suppliers, but they either lack the same quality or demand even higher prices due to the increased demand. The Operations Manager, facing rapidly escalating costs, attempts to negotiate with existing suppliers, but they are unwilling to budge. The Financial Controller projects a significant drop in profit margins, forcing a difficult decision: raise prices and risk alienating customers, or absorb the costs and face financial losses. The Pricing Strategy, initially designed to be competitive, becomes unsustainable. The shop is forced to raise prices by 25%, leading to negative customer reviews and a decline in sales. The Marketing & Brand Manager attempts to mitigate the damage with promotional offers, but the high prices continue to deter customers. The shop struggles to meet its revenue targets, and the project faces a financial crisis.

##### Early Warning Signs
- Key plant-based meat suppliers announce production issues or price increases.
- Competitors begin raising prices on similar menu items.
- Customer feedback indicates price sensitivity and dissatisfaction with current pricing.

##### Tripwires
- Cost of key plant-based meat ingredients increases by >= 25% within a 30-day period.
- Gross profit margin falls below 40%.
- Customer satisfaction scores related to pricing drop by >= 15%.

##### Response Playbook
- Contain: Immediately freeze all non-essential spending.
- Assess: Conduct a thorough review of all supplier contracts and identify potential cost-saving measures.
- Respond: Negotiate with suppliers for better pricing, explore alternative ingredients, and adjust menu pricing strategically.


**STOP RULE:** Gross profit margin remains below 30% for two consecutive months.

---

#### FM2 - The Grand Opening Gridlock

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A3
- **Owner**: Operations Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The assumption that the grand opening will occur on schedule in month 3 proves false. The build-out is delayed due to unforeseen permitting issues and contractor scheduling conflicts. The Operations Manager scrambles to expedite the process, but the delays continue to mount. The Marketing & Brand Manager has already launched the marketing campaign, generating significant buzz and anticipation for the grand opening. As the opening date approaches, it becomes clear that the shop will not be ready in time. The grand opening is postponed, leading to negative publicity and disappointed customers. The Marketing & Brand Manager attempts to manage expectations with social media updates, but the delays continue to erode customer confidence. The shop misses its initial revenue targets, and the project faces a logistical nightmare.

##### Early Warning Signs
- Permitting process exceeds initial estimates by more than 2 weeks.
- Construction progress falls behind schedule by more than 1 week.
- Key equipment deliveries are delayed.

##### Tripwires
- Permit approvals delayed by >= 30 days beyond the initial estimate.
- Construction completion delayed by >= 2 weeks.
- Essential equipment delivery dates pushed back by >= 14 days.

##### Response Playbook
- Contain: Immediately halt all marketing activities related to the grand opening.
- Assess: Conduct a thorough review of the build-out timeline and identify critical bottlenecks.
- Respond: Negotiate with contractors to expedite the process, explore alternative permitting options, and communicate transparently with customers about the delays.


**STOP RULE:** Grand opening is delayed by more than 90 days.

---

#### FM3 - The Provocation Backfire

- **Archetype**: Market/Human
- **Root Cause**: Assumption A1
- **Owner**: Marketing & Brand Manager
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The assumption that the local Kødbyen community will embrace provocative marketing proves false. The Marketing & Brand Manager launches a bold campaign featuring edgy slogans and imagery designed to challenge traditional meat culture. However, the campaign backfires spectacularly. Local residents and community groups express outrage, accusing the shop of being insensitive and disrespectful. Social media is flooded with negative comments and calls for a boycott. The Community Liaison attempts to engage with community leaders, but the damage is already done. The shop's reputation is tarnished, and customer traffic plummets. The Executive Chef, facing declining sales, struggles to maintain morale among the staff. The project faces a market crisis, and the future of the vegan butcher shop is in jeopardy.

##### Early Warning Signs
- Negative sentiment on social media exceeds positive sentiment by a ratio of 2:1.
- Local community groups publicly denounce the marketing campaign.
- Customer traffic declines significantly after the launch of the campaign.

##### Tripwires
- Negative social media sentiment >= 60% within 7 days of campaign launch.
- Petition against the shop gains >= 500 signatures within 14 days.
- Weekly sales drop by >= 30% compared to pre-campaign levels.

##### Response Playbook
- Contain: Immediately suspend the provocative marketing campaign.
- Assess: Conduct a thorough review of the marketing strategy and identify the root causes of the negative reaction.
- Respond: Issue a public apology, engage with community leaders to address concerns, and develop a new marketing campaign that is more sensitive and respectful.


**STOP RULE:** Brand sentiment remains negative for more than 60 days despite corrective actions.

---

#### FM4 - The Partnership Desertion

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Partnership Development Lead
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The assumption that local restaurants will be receptive to partnering with the vegan butcher shop proves false. Despite initial enthusiasm, restaurants back out of agreements due to concerns about customer demand for vegan options, logistical challenges in integrating plant-based meats into their existing menus, or negative feedback from their chefs. The Partnership Development strategy, intended to expand reach and revenue, fails to gain traction. The Marketing & Brand Manager struggles to find alternative channels to promote the shop, leading to lower brand awareness and slower customer acquisition. The Financial Controller projects a significant shortfall in revenue, forcing budget cuts and impacting the shop's ability to invest in other marketing initiatives. The shop struggles to meet its sales targets, and the project faces a financial crisis.

##### Early Warning Signs
- Restaurants express hesitation or delays in finalizing partnership agreements.
- Restaurants report low customer demand for initial plant-based meat offerings.
- Restaurants request significant modifications to the shop's products or pricing.

##### Tripwires
- Number of active restaurant partnerships falls below 3 within the first 6 months.
- Revenue generated from restaurant partnerships is < 10% of total revenue after 9 months.
- Restaurant partners report customer satisfaction scores < 4 out of 5 for dishes featuring the shop's products.

##### Response Playbook
- Contain: Immediately halt all partnership-related marketing activities.
- Assess: Conduct a thorough review of the partnership strategy and identify the reasons for the lack of success.
- Respond: Offer more attractive partnership terms, develop customized plant-based meat options for restaurants, and explore alternative partnership models (e.g., pop-up events, joint marketing campaigns).


**STOP RULE:** Restaurant partnerships generate less than 5% of total revenue after 12 months.

---

#### FM5 - The System Shutdown

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: IT Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The assumption that the POS system will integrate seamlessly with inventory management and online ordering platforms proves false. The selected POS system experiences frequent glitches and integration issues, leading to inaccurate inventory tracking, order errors, and customer dissatisfaction. The Operations Manager struggles to manage the system, leading to operational inefficiencies and increased labor costs. The Customer Service & Sales Team is overwhelmed with complaints and struggles to process orders accurately. The online ordering platform malfunctions, resulting in lost orders and frustrated customers. The In-Store Technology Integration strategy, intended to streamline operations and enhance the customer experience, becomes a major source of frustration and disruption. The shop struggles to meet customer demand, and the project faces a logistical nightmare.

##### Early Warning Signs
- Frequent POS system crashes or slowdowns.
- Inaccurate inventory counts and discrepancies between physical stock and system data.
- Customer complaints about order errors and long wait times.

##### Tripwires
- POS system downtime exceeds 5 hours per week.
- Inventory discrepancies exceed 10% of total stock.
- Customer complaints related to order accuracy or wait times increase by >= 20%.

##### Response Playbook
- Contain: Immediately implement manual inventory tracking and order processing procedures.
- Assess: Conduct a thorough review of the POS system and identify the root causes of the integration issues.
- Respond: Contact the POS vendor for technical support, explore alternative POS systems, and provide additional training to staff on manual procedures.


**STOP RULE:** The POS system remains unreliable for more than 60 days despite corrective actions.

---

#### FM6 - The Staffing Shortage

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Human Resources Manager
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The assumption that the shop can attract and retain qualified staff with competitive wages and benefits proves false. The local labor market is tight, and the shop struggles to find experienced vegan chefs and service staff willing to work for the offered wages. High staff turnover leads to inconsistent product quality, poor customer service, and increased training costs. The Executive Chef is overwhelmed with managing the kitchen and training new staff, leading to menu innovation delays. The Operations Manager struggles to maintain efficient workflow, leading to operational inefficiencies and increased labor costs. The shop's reputation suffers, and customer traffic declines. The project faces a market crisis, and the future of the vegan butcher shop is in jeopardy.

##### Early Warning Signs
- The shop receives fewer than 5 qualified applications per job posting.
- Staff turnover rate exceeds 20% per month.
- Customer complaints about poor service or inconsistent product quality increase.

##### Tripwires
- Staff turnover rate >= 30% within the first 3 months.
- Number of unfilled job openings remains >= 2 for more than 30 days.
- Customer satisfaction scores related to service quality drop by >= 15%.

##### Response Playbook
- Contain: Immediately increase wages and benefits to attract and retain qualified staff.
- Assess: Conduct a thorough review of the recruitment and retention strategies and identify the reasons for the staffing shortage.
- Respond: Partner with local culinary schools to recruit students, offer signing bonuses and referral programs, and create a positive and supportive work environment.


**STOP RULE:** The shop is unable to maintain adequate staffing levels for more than 30 days.

---

#### FM7 - The Green Premium Paradox

- **Archetype**: Market/Human
- **Root Cause**: Assumption A7
- **Owner**: Marketing & Brand Manager
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The assumption that customers will be willing to pay a premium for sustainable packaging proves false. While customers express support for sustainability, they are unwilling to pay extra for it, especially given the competitive pricing of other food vendors in Kødbyen. The Pricing Strategy, designed to incorporate the cost of sustainable packaging, becomes unsustainable. The shop is forced to either absorb the extra cost, reducing profit margins, or switch to cheaper, less sustainable packaging, alienating environmentally conscious customers. The Marketing & Brand Manager struggles to communicate the value of sustainable packaging, and customer traffic declines. The project faces a market crisis, and the future of the vegan butcher shop is in jeopardy.

##### Early Warning Signs
- Low uptake of the discount for customers who bring their own containers.
- Customer complaints about the high prices of menu items.
- Competitors offer similar products at lower prices with less sustainable packaging.

##### Tripwires
- Less than 5% of customers opt for the discount option after 2 months.
- Customer satisfaction scores related to value for money drop by >= 10%.
- Sales of menu items with sustainable packaging are < 20% of total sales.

##### Response Playbook
- Contain: Immediately suspend the premium pricing for sustainable packaging.
- Assess: Conduct a thorough review of the pricing strategy and identify the reasons for the lack of customer willingness to pay.
- Respond: Explore alternative, more cost-effective sustainable packaging options, and communicate the value of sustainability through marketing campaigns and educational materials.


**STOP RULE:** The shop is unable to offer sustainable packaging without incurring significant financial losses.

---

#### FM8 - The Powerless Plant-Based

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Operations Manager
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The assumption that the local power grid can reliably support the shop's energy demands proves false. During a heatwave, the power grid in Kødbyen becomes overloaded, leading to frequent power outages. The shop's refrigeration and cooking equipment malfunctions, resulting in spoiled inventory and an inability to prepare menu items. The Operations Manager scrambles to find a backup power source, but the cost is prohibitive. The Customer Service & Sales Team is unable to process orders, and customers are turned away. The In-Store Technology Integration strategy, designed to streamline operations, becomes useless. The shop is forced to close temporarily, leading to lost revenue and a damaged reputation. The project faces a logistical nightmare, and the future of the vegan butcher shop is in jeopardy.

##### Early Warning Signs
- Frequent power fluctuations or brownouts in the Kødbyen area.
- Local businesses report issues with their electrical equipment.
- The power company issues warnings about potential grid overloads.

##### Tripwires
- Power outages occur >= 3 times per month.
- Refrigeration equipment malfunctions due to power fluctuations.
- The shop is forced to close due to power outages for >= 2 days per month.

##### Response Playbook
- Contain: Immediately implement emergency procedures for power outages, including backup refrigeration and cooking methods.
- Assess: Conduct a thorough review of the shop's energy consumption and identify potential energy-saving measures.
- Respond: Invest in a backup generator, explore alternative energy sources (e.g., solar panels), and negotiate with the power company for improved grid reliability.


**STOP RULE:** The shop is unable to operate reliably due to power grid limitations for more than 30 days.

---

#### FM9 - The Kødbyen Exodus

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Shop Manager
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The assumption that the shop's location in Kødbyen will remain a desirable destination proves false. A series of negative events, such as increased crime, rising rents, and the closure of several popular businesses, leads to a decline in foot traffic and a negative perception of the area. The Marketing & Brand Manager struggles to attract customers to the shop, and sales plummet. The Financial Controller projects a significant shortfall in revenue, forcing budget cuts and impacting the shop's ability to invest in marketing and operations. The shop struggles to meet its financial obligations, and the project faces a financial crisis.

##### Early Warning Signs
- Foot traffic in Kødbyen declines significantly.
- Several businesses close in the area.
- Local media reports on increased crime or other negative events in Kødbyen.

##### Tripwires
- Foot traffic declines by >= 20% within a 3-month period.
- More than 5 businesses close in Kødbyen within a 6-month period.
- Weekly sales drop by >= 30% compared to pre-decline levels.

##### Response Playbook
- Contain: Immediately implement cost-cutting measures and explore alternative revenue streams (e.g., online sales, catering).
- Assess: Conduct a thorough review of the shop's location and identify the reasons for the decline in foot traffic.
- Respond: Negotiate with the landlord for rent reductions, partner with other businesses in Kødbyen to promote the area, and explore the possibility of relocating to a more desirable location.


**STOP RULE:** The shop is unable to generate sufficient revenue to cover operating costs for more than 90 days.
