
## Audit - Corruption Risks

- Bribery of local inspectors (Danish Food and Veterinary Administration) to overlook violations of food safety regulations to expedite permits or avoid fines.
- Kickbacks from suppliers of plant-based meat alternatives in exchange for exclusive purchasing agreements, potentially sacrificing quality or cost-effectiveness.
- Conflicts of interest in awarding contracts for shop fixtures and fittings, favoring companies with personal connections over more qualified or competitive bidders.
- Misuse of confidential market research data for personal gain or to benefit competing businesses.
- Nepotism in hiring decisions, prioritizing unqualified friends or family members over more qualified candidates for chef, operations staff, or marketing specialist positions.

## Audit - Misallocation Risks

- Inflated invoices from suppliers or contractors, with the excess funds diverted for personal use.
- Double-billing for marketing expenses, claiming reimbursement for the same campaign from multiple sources or creating fictitious campaigns.
- Unnecessary or extravagant spending on shop fixtures and fittings, exceeding the allocated budget and diverting funds from other critical areas.
- Misreporting of sales figures or inventory levels to conceal theft or mismanagement of resources.
- Inefficient allocation of marketing budget, focusing on ineffective channels or campaigns that do not generate sufficient ROI.

## Audit - Procedures

- Conduct quarterly internal audits of financial records, including invoices, receipts, and bank statements, to detect any irregularities or discrepancies.
- Implement a robust expense approval workflow, requiring multiple levels of authorization for all expenditures above a certain threshold (e.g., 5,000 DKK).
- Perform regular inventory audits to verify the accuracy of stock levels and identify any potential losses or discrepancies.
- Conduct periodic reviews of supplier contracts to ensure compliance with agreed-upon terms and pricing.
- Engage an external auditor to conduct an annual review of the shop's financial statements and compliance with relevant regulations.

## Audit - Transparency Measures

- Publish a monthly budget dashboard displaying actual vs. planned expenditures for each category (marketing, product development, operations).
- Document and publish minutes of key management meetings, including discussions and decisions related to financial performance, marketing strategies, and operational issues.
- Establish a confidential whistleblower mechanism for employees to report suspected fraud, corruption, or other misconduct without fear of retaliation.
- Make the shop's food safety and sustainability policies publicly available on its website and in-store.
- Document the selection criteria and rationale for awarding major contracts to suppliers and contractors.