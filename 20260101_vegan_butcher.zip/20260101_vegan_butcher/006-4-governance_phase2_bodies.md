### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and guidance, ensuring alignment with project goals and managing strategic risks, given the project's budget and profitability targets.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Monitor project progress against strategic goals.
- Approve major changes to project scope, budget, or timeline (>$500,000 DKK).
- Oversee strategic risk management and mitigation.
- Resolve strategic conflicts and escalate issues as needed.
- Approve key strategic decisions (e.g., Signature Item Strategy, Market Positioning Strategy).

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define reporting requirements from the Project Management Office.

**Membership:**

- Senior Management Representative (Chair)
- Head of Marketing
- Head of Operations
- Financial Controller
- Independent External Advisor (Food Industry Expert)

**Decision Rights:** Strategic decisions related to project scope, budget, timeline, and risk management. Approval of expenditures exceeding 500,000 DKK.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Senior Management Representative (Chair) has the deciding vote. Dissenting opinions are documented in the meeting minutes.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of project progress against strategic goals.
- Review of key performance indicators (KPIs).
- Discussion and approval of proposed changes to project scope, budget, or timeline.
- Review of strategic risks and mitigation plans.
- Escalated issues from the Project Management Office or other governance bodies.
- Review of financial performance against budget.

**Escalation Path:** Executive Leadership Team
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages day-to-day project execution, ensuring efficient resource allocation, operational risk management, and adherence to project plans.

**Responsibilities:**

- Develop and maintain project plans, schedules, and budgets.
- Manage project resources and track project progress.
- Identify and manage operational risks.
- Monitor project performance against key performance indicators (KPIs).
- Prepare and present project status reports to the Project Steering Committee.
- Implement project management methodologies and best practices.
- Manage decisions below the strategic threshold (i.e. <500,000 DKK).

**Initial Setup Actions:**

- Establish project management methodologies and tools.
- Develop project communication plan.
- Define roles and responsibilities of project team members.
- Set up project tracking and reporting systems.

**Membership:**

- Project Manager (Lead)
- Operations Manager
- Marketing Manager
- Finance Representative
- Chef Representative

**Decision Rights:** Operational decisions related to project execution, resource allocation, and risk management. Approval of expenditures up to 500,000 DKK.

**Decision Mechanism:** Decisions made by the Project Manager in consultation with the project team. In case of disagreement, the issue is escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of upcoming tasks and milestones.
- Identification and management of operational risks.
- Review of project budget and expenses.
- Resolution of project issues and roadblocks.
- Updates from team members on their respective areas of responsibility.

**Escalation Path:** Project Steering Committee
### 3. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures compliance with relevant regulations, ethical standards, and internal policies, particularly regarding food safety, marketing practices, and data privacy (GDPR).

**Responsibilities:**

- Oversee compliance with Danish Food Safety Regulations and HACCP.
- Review and approve marketing materials to ensure ethical and responsible messaging.
- Ensure compliance with GDPR and other data privacy regulations.
- Investigate and resolve ethical concerns and compliance violations.
- Develop and implement ethics and compliance training programs.
- Oversee the whistleblower mechanism and ensure protection for whistleblowers.
- Review and approve supplier contracts to ensure ethical sourcing and fair labor practices.

**Initial Setup Actions:**

- Develop ethics and compliance policies and procedures.
- Establish a confidential reporting mechanism for ethical concerns.
- Conduct a compliance risk assessment.
- Develop a compliance training program.

**Membership:**

- Legal Counsel (Chair)
- Compliance Officer
- Head of Human Resources
- Independent External Ethics Advisor

**Decision Rights:** Decisions related to ethics and compliance matters, including investigations, disciplinary actions, and policy changes.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Legal Counsel (Chair) has the deciding vote.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of compliance with relevant regulations and ethical standards.
- Discussion of ethical concerns and compliance violations.
- Review of ethics and compliance training programs.
- Review of supplier contracts and ethical sourcing practices.
- Updates on changes to relevant regulations and ethical standards.
- Review of whistleblower reports and investigations.

**Escalation Path:** Executive Leadership Team
### 4. Stakeholder Engagement Group

**Rationale for Inclusion:** Provides a structured approach to gathering feedback from key stakeholders (customers, local community, suppliers) and incorporating it into project decisions, particularly regarding product development and marketing.

**Responsibilities:**

- Identify and engage with key stakeholders (customers, local community, suppliers).
- Gather feedback from stakeholders on product offerings, marketing campaigns, and customer service.
- Analyze stakeholder feedback and identify areas for improvement.
- Develop and implement stakeholder engagement plans.
- Communicate project updates and solicit input from stakeholders.
- Organize community events and partnerships.
- Address stakeholder concerns and complaints.

**Initial Setup Actions:**

- Identify key stakeholders.
- Develop a stakeholder engagement plan.
- Establish communication channels with stakeholders.
- Set up a system for collecting and analyzing stakeholder feedback.

**Membership:**

- Marketing Manager (Lead)
- Operations Manager
- Chef Representative
- Community Representative (External)

**Decision Rights:** Recommendations on product development, marketing campaigns, and customer service improvements based on stakeholder feedback.

**Decision Mechanism:** Recommendations made by consensus. In case of disagreement, the issue is escalated to the Project Management Office.

**Meeting Cadence:** Bi-monthly

**Typical Agenda Items:**

- Review of stakeholder feedback.
- Discussion of potential product improvements.
- Review of marketing campaign effectiveness.
- Planning of community events and partnerships.
- Addressing stakeholder concerns and complaints.
- Updates on project progress and solicit input from stakeholders.

**Escalation Path:** Project Management Office