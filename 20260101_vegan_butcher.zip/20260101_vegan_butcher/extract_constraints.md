## Positive Constraints

- Vegan Butcher Shop
- Sell artificial meat (Plant-Based)
- Location Kødbyen, Copenhagen
- Sell sandwiches
- Sell sausages
- Provocative marketing
- Budget: 10 million DKK
- Grand Opening in month 3
- Profitability Goal: month 12
- Create a signature item that is a social media hit
- Pick a realistic scenario
- 2 year lease inside Kødbyen
- Project start ASAP

## Negative Constraints

- Avoid the overly ambitious scenarios
- Do not use blockchain
- Do not use VR
- Do not use AR
- Do not use AI
- Do not use Robots
