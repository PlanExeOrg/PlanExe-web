**Budget Request Exceeding Core Project Team Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds financial limit delegated to the Core Project Team, requiring strategic oversight and budget approval at a higher level.
Negative Consequences: Potential budget overrun and project delays if not addressed promptly.

**Critical Risk Materialization Requiring Additional Resources**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Resource Allocation
Rationale: The Core Project Team lacks the authority to allocate significant additional resources to mitigate a critical risk, requiring strategic decision-making and resource prioritization by the Steering Committee.
Negative Consequences: Project failure or significant delays if the risk is not adequately addressed.

**Ethics & Compliance Committee Deadlock on Marketing Material Approval**
Escalation Level: CEO/Owner and Project Steering Committee
Approval Process: CEO/Owner Review and Final Decision, informed by Steering Committee input
Rationale: Disagreement within the Ethics & Compliance Committee regarding the ethical implications of marketing materials requires a higher authority to ensure alignment with brand values and regulatory compliance.
Negative Consequences: Potential legal penalties, reputational damage, and loss of customer trust if unethical or non-compliant marketing materials are released.

**Proposed Major Scope Change Impacting Project Timeline or Budget**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Impact Assessment
Rationale: Significant changes to the project scope require strategic review and approval to ensure alignment with overall business objectives and assess the impact on the project timeline and budget.
Negative Consequences: Project delays, budget overruns, and failure to meet strategic objectives if scope changes are not properly managed.

**Reported Ethical Violation Involving a Member of the Core Project Team**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to CEO/Owner
Rationale: Requires independent review and investigation to ensure impartiality and maintain ethical standards within the project team.
Negative Consequences: Legal penalties, reputational damage, and loss of employee morale if ethical violations are not addressed appropriately.

**Stakeholder Engagement Group cannot resolve a conflict with a Local Restaurant**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Mediation
Rationale: The Stakeholder Engagement Group needs higher authority to resolve a conflict that could impact the project's reputation or partnerships.
Negative Consequences: Damaged relationships with key stakeholders, negative publicity, and potential loss of business opportunities.