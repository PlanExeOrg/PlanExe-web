
## Audit - Corruption Risks

- Bribery of local food safety inspectors to overlook violations or expedite permits.
- Kickbacks from plant-based meat suppliers in exchange for exclusive contracts or inflated pricing.
- Conflicts of interest involving staff members with undisclosed financial ties to suppliers or competitors.
- Nepotism in hiring or awarding contracts, potentially leading to unqualified personnel or substandard services.
- Misuse of confidential market research data for personal gain or to benefit competing businesses.

## Audit - Misallocation Risks

- Inflated invoices from contractors during the shop build-out, with the excess funds diverted for personal use.
- Double-billing for marketing expenses, with the same invoice submitted multiple times.
- Unnecessary or overpriced equipment purchases, exceeding the allocated budget.
- Misreporting of sales figures to conceal embezzlement or theft of cash.
- Inefficient allocation of staff time, with employees performing personal tasks during work hours.

## Audit - Procedures

- Conduct quarterly internal audits of financial records, focusing on marketing expenses, supplier payments, and payroll.
- Perform unannounced spot checks of inventory levels and cash handling procedures.
- Implement a robust expense approval workflow with clearly defined authorization limits.
- Engage an external auditor to conduct an annual review of financial statements and compliance with regulations.
- Review supplier contracts regularly to ensure competitive pricing and adherence to ethical sourcing standards.

## Audit - Transparency Measures

- Publish a monthly budget dashboard showing actual vs. planned spending, highlighting any significant variances.
- Post minutes of key management meetings on a company intranet or shared drive, accessible to all employees.
- Establish a confidential whistleblower mechanism for reporting suspected fraud or misconduct.
- Document the selection criteria and rationale for all major vendor contracts.
- Make the shop's food safety inspection reports publicly available.