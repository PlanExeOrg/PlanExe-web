### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start
- Project Plan Approved

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1

**Dependencies:**

- Project Start
- Project Plan Approved

### 3. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Start
- Project Plan Approved

### 4. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Project Start
- Project Plan Approved

### 5. Circulate Draft SteerCo ToR for review by Senior Management Representative, Head of Marketing, Head of Operations, Financial Controller, and the Independent External Advisor.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary on SteerCo ToR

**Dependencies:**

- Draft SteerCo ToR v0.1

### 6. Circulate Draft PMO ToR for review by Operations Manager, Marketing Manager, Finance Representative, and Chef Representative.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary on PMO ToR

**Dependencies:**

- Draft PMO ToR v0.1

### 7. Circulate Draft Ethics & Compliance Committee ToR for review by Legal Counsel, Compliance Officer, Head of Human Resources, and the Independent External Ethics Advisor.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary on Ethics & Compliance Committee ToR

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 8. Circulate Draft Stakeholder Engagement Group ToR for review by Marketing Manager, Operations Manager, Chef Representative, and Community Representative.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary on Stakeholder Engagement Group ToR

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1

### 9. Project Manager finalizes the Project Steering Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary on SteerCo ToR

### 10. Project Manager finalizes the Project Management Office (PMO) Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final PMO ToR v1.0

**Dependencies:**

- Feedback Summary on PMO ToR

### 11. Project Manager finalizes the Ethics & Compliance Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary on Ethics & Compliance Committee ToR

### 12. Project Manager finalizes the Stakeholder Engagement Group Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Feedback Summary on Stakeholder Engagement Group ToR

### 13. Senior Management Representative formally appoints themselves as the Chair of the Project Steering Committee.

**Responsible Body/Role:** Senior Management Representative

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 14. Project Manager formally appoints the Operations Manager as the Lead of the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final PMO ToR v1.0

### 15. Senior Management Representative formally appoints the Legal Counsel as the Chair of the Ethics & Compliance Committee.

**Responsible Body/Role:** Senior Management Representative

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 16. Project Manager formally appoints the Marketing Manager as the Lead of the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0

### 17. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Appointment Confirmation Email

### 18. Project Manager schedules the initial Project Management Office (PMO) kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Appointment Confirmation Email

### 19. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Appointment Confirmation Email

### 20. Project Manager schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Appointment Confirmation Email

### 21. Hold initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Final SteerCo ToR v1.0

### 22. Hold initial Project Management Office (PMO) kick-off meeting & assign initial tasks.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Final PMO ToR v1.0

### 23. Hold initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Final Ethics & Compliance Committee ToR v1.0

### 24. Hold initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Final Stakeholder Engagement Group ToR v1.0

### 25. Project Steering Committee reviews and approves the project scope, budget, and timeline.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved Project Scope
- Approved Project Budget
- Approved Project Timeline

**Dependencies:**

- Meeting Minutes with Action Items from SteerCo Kick-off
- Project Plan Approved

### 26. Project Management Office (PMO) develops and maintains project plans, schedules, and budgets.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Ongoing

**Key Outputs/Deliverables:**

- Updated Project Plans
- Updated Project Schedules
- Updated Project Budgets

**Dependencies:**

- Approved Project Scope
- Approved Project Budget
- Approved Project Timeline

### 27. Ethics & Compliance Committee develops ethics and compliance policies and procedures.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Month 1

**Key Outputs/Deliverables:**

- Ethics and Compliance Policies and Procedures

**Dependencies:**

- Meeting Minutes with Action Items from Ethics & Compliance Committee Kick-off

### 28. Stakeholder Engagement Group identifies and engages with key stakeholders (customers, local community, suppliers).

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Month 1

**Key Outputs/Deliverables:**

- Stakeholder Engagement Plan
- List of Key Stakeholders

**Dependencies:**

- Meeting Minutes with Action Items from Stakeholder Engagement Group Kick-off