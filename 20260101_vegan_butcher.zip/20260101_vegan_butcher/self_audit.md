Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 15 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 4 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not describe any activities that would violate the laws of physics. The plan focuses on business strategy, marketing, and operations within the existing laws of nature.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of a vegan butcher shop with provocative marketing in Copenhagen, and lacks independent evidence at comparable scale. There is no mention of similar ventures or pilot programs.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/Regulatory, Technical/Operational, and Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: Project Lead / Deliverable: Validation Report / Date: 2026-06-30


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions strategic concepts like 'provocative marketing' and 'signature item' without defining their mechanisms or measurable outcomes. There are no one-pagers outlining value hypotheses or success metrics.

**Mitigation**: Marketing Manager: Create one-pagers for 'provocative marketing' and 'signature item' defining inputs→process→customer value, success metrics, and decision hooks. Due: 2026-05-01.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the risk register focuses on individual risks, but lacks analysis of second-order effects or cascading failures. The plan does not map out how one risk can trigger others, nor does it include controls for such cascades.

**Mitigation**: Risk Manager: Expand the risk register to map risk cascades and add controls, including a dated review cadence. Due: 2026-05-01.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions obtaining permits but lacks a detailed list of required permits, their lead times, and dependencies. Without this, timeline realism cannot be assessed.

**Mitigation**: Shop Manager: Create a permit/approval matrix with lead times and dependencies by 2026-05-01. Then rebuild the critical path with this data.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions a 10 million DKK budget but lacks detail on funding sources, draw schedule, and covenants. The plan does not specify if the funding is secured or indicative, nor does it mention runway length.

**Mitigation**: CFO: Create a dated financing plan listing sources/status, draw schedule, covenants, and a NO‑GO on missed financing gates. Due: 2026-05-01.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions a 10 million DKK budget but lacks detail on vendor quotes or scale-appropriate benchmarks. There is no per-area math, nor is there evidence of contingency. The plan does not normalize costs.

**Mitigation**: CFO: Benchmark costs (≥3), obtain vendor quotes, normalize per-area, and adjust budget or de-scope by 2026-05-01.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents a 12-month profitability target as a single point without range or sensitivity. The plan mentions a financial model but lacks best/worst case scenarios. "Achieve profitability within 12 months of project start."

**Mitigation**: CFO: Conduct sensitivity analysis on the financial model, including best/worst/base case scenarios for revenue and costs. Due: 2026-05-01.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks engineering artifacts for build-critical components. There are no technical specs, interface definitions, test plans, or integration maps. "The plan is business-oriented with a creative and potentially provocative tone..."

**Mitigation**: Engineering Lead: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components by 2026-06-30.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes several critical claims without providing verifiable evidence. For example, the plan states, "2-year lease negotiated inside Kødbyen, Copenhagen" but lacks the lease document itself.

**Mitigation**: Legal Team: Obtain and append the lease agreement for the Kødbyen location to the plan by 2026-05-01.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the deliverable, 'a viral signature item,' lacks specific, verifiable qualities. Success is measured by social media shares, customer reviews, and repeat purchases, but lacks quantifiable targets.

**Mitigation**: Marketing Manager: Define SMART criteria for the signature item, including a KPI for social media shares (e.g., 10,000 shares in 3 months). Due: 2026-05-01.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'In-Store Technology Integration' (self-ordering kiosks) without a clear benefit case tied to core goals like profitability or brand. It does not directly support the core project goals.

**Mitigation**: Project Team: Produce a one-page benefit case for In-Store Technology Integration, complete with a KPI, owner, and estimated cost, or move the feature to the project backlog. Due: 2026-05-01.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Executive Chef' role is critical for menu innovation and quality, but the plan doesn't address the difficulty of finding chefs skilled in vegan cuisine. "The Executive Chef is crucial for developing and maintaining the quality of the vegan menu..."

**Mitigation**: HR: Validate the talent market for vegan chefs in Copenhagen, including salary expectations and availability, by 2026-05-01 to inform recruitment strategy.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions obtaining permits but lacks a regulatory matrix (authority, artifact, lead time, predecessors). The plan does not name controlling regimes/statutes. "Secure necessary permits and licenses."

**Mitigation**: Shop Manager: Create a regulatory matrix identifying required permits/licenses, authorities, artifacts, and lead times. Flag showstoppers. Due: 2026-05-01.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions sustainability but lacks specifics on long-term funding, maintenance, or adaptation. The plan does not include a technology roadmap or succession plan. "Our primary goal is to create a successful and sustainable business..."

**Mitigation**: Operations Manager: Develop an operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, and technology roadmap by 2026-06-30.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies alternative locations but lacks evidence of zoning/land-use verification or written confirmation from authorities. The plan does not include fallback designs. "Alternative locations: Vesterbro, Nørrebro, and Frederiksberg..."

**Mitigation**: Shop Manager: Perform a fatal-flaw screen on alternative locations, seeking written zoning confirmation. Define NO-GO thresholds tied to constraint outcomes by 2026-05-31.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions reliance on plant-based meat manufacturers but lacks evidence of redundancy or tested failover plans. There are no SLAs mentioned. "Reliance on plant-based meat manufacturers. Quality control issues."

**Mitigation**: Supply Chain Coordinator: Secure SLAs with key suppliers, add a secondary supplier, and test failover procedures by 2026-06-30.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions 'Finance Department' and 'Marketing Manager' but does not address their conflicting incentives. Finance prioritizes cost control, while Marketing seeks brand awareness, creating tension over marketing spend.

**Mitigation**: Executive Team: Define a shared, measurable objective (OKR) for Finance and Marketing that aligns on customer acquisition cost (CAC) or return on ad spend (ROAS) by 2026-05-01.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a change-control process. Vague ‘we will monitor’ is insufficient. "Monitor and Optimize Operations", "Track Key Performance Indicators (KPIs)"

**Mitigation**: Project Lead: Add a monthly review with KPI dashboard and a lightweight change board with thresholds (when to re-plan/stop). Due: 2026-05-01.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies financial, market, and supply chain risks, but lacks a cross-impact analysis. A supply chain disruption could trigger financial shortfalls and force a shift away from provocative marketing, undermining the brand.

**Mitigation**: Risk Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by 2026-05-31.