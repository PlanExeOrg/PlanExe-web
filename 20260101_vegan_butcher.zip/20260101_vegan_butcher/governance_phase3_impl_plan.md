### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Plan Approved

### 3. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Project Plan Approved

### 4. Circulate Draft SteerCo ToR for review by nominated members (CEO/Owner, Head of Operations, Marketing Director, Finance Director, Independent Advisor).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1

### 5. Circulate Draft Ethics & Compliance Committee ToR for review by nominated members (Legal Counsel, Compliance Officer, HR Manager, Marketing Manager, Independent Ethics Advisor).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 6. Circulate Draft Stakeholder Engagement Group ToR for review by nominated members (Marketing Manager, Shop Manager, Community Liaison Officer, Representative from Local Restaurant Association, Representative from Local Community Group).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1

### 7. Project Manager finalizes the Project Steering Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 8. Project Manager finalizes the Ethics & Compliance Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary

### 9. Project Manager finalizes the Stakeholder Engagement Group Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Feedback Summary

### 10. CEO/Owner formally appoints the Chair of the Project Steering Committee.

**Responsible Body/Role:** CEO/Owner

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 11. Legal Counsel formally appoints the Chair of the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 12. Marketing Manager formally appoints the Chair of the Stakeholder Engagement Group.

**Responsible Body/Role:** Marketing Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0

### 13. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Appointment Confirmation Email
- Final SteerCo ToR v1.0

### 14. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Appointment Confirmation Email
- Final Ethics & Compliance Committee ToR v1.0

### 15. Project Manager schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Appointment Confirmation Email
- Final Stakeholder Engagement Group ToR v1.0

### 16. Hold initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 17. Hold initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 18. Hold initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 19. Core Project Team defines roles and responsibilities.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Roles and Responsibilities Matrix

**Dependencies:**


### 20. Core Project Team establishes communication protocols.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Communication Plan

**Dependencies:**

- Roles and Responsibilities Matrix

### 21. Core Project Team sets up project management tools.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Access to Project Management Software

**Dependencies:**

- Communication Plan

### 22. Core Project Team develops detailed project schedule.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Detailed Project Schedule

**Dependencies:**

- Access to Project Management Software

### 23. Project Steering Committee reviews and approves initial project plan.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Approved Project Plan

**Dependencies:**

- Meeting Minutes with Action Items
- Detailed Project Schedule

### 24. Ethics & Compliance Committee develops a compliance checklist.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Compliance Checklist

**Dependencies:**

- Meeting Minutes with Action Items

### 25. Ethics & Compliance Committee defines reporting procedures.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Reporting Procedures Document

**Dependencies:**

- Compliance Checklist

### 26. Stakeholder Engagement Group identifies key stakeholders.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Stakeholder Register

**Dependencies:**

- Meeting Minutes with Action Items

### 27. Stakeholder Engagement Group develops a communication plan.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Stakeholder Communication Plan

**Dependencies:**

- Stakeholder Register

### 28. Stakeholder Engagement Group establishes feedback mechanisms.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Feedback Collection System

**Dependencies:**

- Stakeholder Communication Plan