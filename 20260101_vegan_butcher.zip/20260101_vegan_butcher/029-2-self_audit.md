Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 15 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 5 | Material risk with plausible path. |
| ✅ Low | 0 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions cellular agriculture as a strategic choice for product innovation: "Pioneer novel plant-based meat alternatives using fermentation and cellular agriculture techniques, creating exclusive and high-value products." This requires unproven physical effects at the required scale with no conventional fallback.

**Mitigation**: R&D Team: Conduct a feasibility study on cellular agriculture techniques, assessing scalability, cost, and regulatory hurdles, and present findings within 90 days.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of "provocative marketing" and a vegan butcher shop without independent evidence at comparable scale. The plan states, "The Signature Item Strategy focuses on creating a unique and memorable product that defines the Vegan Butcher Shop," but lacks precedent.

**Mitigation**: Marketing Team: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, and Ethics/Societal, producing authoritative sources or supervised pilots showing results vs a baseline. Define NO-GO gates for empirical validity and legal clearance by 2026-03-01.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "provocative marketing" as a key strategy, but lacks a clear definition, owner, or measurable outcomes. The plan states, "The Signature Item Strategy focuses on creating a unique and memorable product," but doesn't define how this will be achieved or measured.

**Mitigation**: Marketing Team: Develop a one-pager defining "provocative marketing" with a mechanism-of-action, owner, measurable outcomes, and decision hooks by 2026-02-15.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies risks (financial, market, operational, social, technical, regulatory, supply chain) but lacks explicit analysis of cascades. The plan mentions "Financial planning, brand identity, market testing are essential," but doesn't map how these interact.

**Mitigation**: Risk Management Team: Create a risk cascade diagram illustrating the potential interdependencies and second-order effects of identified risks by 2026-03-01.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions obtaining permits but lacks a permit/approval matrix or a schedule. The plan states, "Secure necessary permits and licenses for operating a food business in Copenhagen," but provides no lead times.

**Mitigation**: Legal Team: Create a permit/approval matrix with authoritative lead times and predecessors, then rebuild the critical path with a NO-GO threshold on slip by 2026-02-15.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions funding sources but lacks specifics on committed sources, draw schedule, covenants, and runway length. The plan states, "Funding sources: loans, investors, personal investment," but provides no details.

**Mitigation**: Finance Team: Develop a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO-GO on missed financing gates by 2026-02-15.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan provides a budget breakdown (3M DKK marketing, 4M DKK product development, 3M DKK operations) but lacks per-area normalization or vendor quotes. The plan mentions a 10 million DKK budget but lacks benchmarks.

**Mitigation**: Finance Team: Obtain ≥3 vendor quotes for fit-out and equipment, normalize costs per m²/ft² against ≥3 benchmarks, and adjust budget or de-scope by 2026-03-01.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents revenue targets (50% by Month 6, 80% by Month 9) as single numbers without ranges or scenarios. The plan states, "Revenue Targets: 50% by Month 6, 80% by Month 9" without confidence intervals.

**Mitigation**: Finance Team: Develop best-case, worst-case, and base-case revenue scenarios, including sensitivity analysis on key drivers, by 2026-02-15.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks engineering artifacts for build-critical components. The plan mentions "plant-based meat alternatives" and "equipment for preparing sandwiches and sausages" but lacks technical specifications, interface definitions, or test plans.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for all build-critical components by 2026-03-01.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan states, "Specified location; lease negotiated," but lacks a copy of the lease agreement or evidence of its terms. Without the lease, the project's viability is unconfirmed.

**Mitigation**: Legal Team: Provide a copy of the signed lease agreement, including key terms (duration, cost, restrictions), by 2026-02-15.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "a signature item" without defining specific, verifiable qualities. The plan states, "The Signature Item Strategy focuses on creating a unique and memorable product," but lacks SMART criteria.

**Mitigation**: Marketing Team: Define SMART criteria for the signature item, including a KPI for social media shares (e.g., 10,000 shares within 1 month), by 2026-02-15.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes "provocative marketing" as a core strategy, but this adds complexity and risk without clear support for profitability or sustainability. The plan aims to "establish a profitable vegan butcher shop" and "promote sustainable food choices," but provocative marketing may undermine these goals.

**Mitigation**: Project Team: Produce a one-page benefit case for "provocative marketing," including a KPI, owner, and estimated cost, or move the feature to the project backlog by 2026-03-01.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies the "Brand & Marketing Strategist" as crucial for "provocative marketing" but lacks evidence this role can be filled. The plan states, "A full-time Brand & Marketing Strategist is crucial for developing and executing the 'provocative marketing' strategy..." without talent market validation.

**Mitigation**: HR Team: Conduct a talent market analysis for a Brand & Marketing Strategist with experience in "provocative marketing" in Copenhagen and present findings by 2026-02-15.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions obtaining permits but lacks a permit/approval matrix or a schedule. The plan states, "Secure necessary permits and licenses for operating a food business in Copenhagen," but provides no lead times.

**Mitigation**: Legal Team: Create a permit/approval matrix with authoritative lead times and predecessors, then rebuild the critical path with a NO-GO threshold on slip by 2026-02-15.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions efficient operations are critical for long-term sustainability, but lacks a detailed operational sustainability plan. The plan states, "Efficient operations are critical for long-term sustainability," but lacks specifics on funding, maintenance, or technology.

**Mitigation**: Operations Team: Develop an operational sustainability plan including a funding/resource strategy, maintenance schedule, succession planning, and technology roadmap by 2026-03-01.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan requires a physical location in Kødbyen, Copenhagen, but lacks evidence of zoning/land-use compliance. The plan states, "This plan requires a physical location (Kødbyen, Copenhagen)," but omits zoning verification.

**Mitigation**: Legal Team: Perform a fatal-flaw screen with Copenhagen authorities to confirm zoning/land-use compliance for a vegan butcher shop in Kødbyen by 2026-02-15.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks evidence of tested failover plans for critical vendors or data sources. The plan mentions "reliable supply chains" but lacks evidence of redundancy or tested business continuity plans.

**Mitigation**: Operations Team: Secure SLAs with key vendors, add a secondary supplier/data path for critical dependencies, and test failover procedures by 2026-03-01.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the Finance Department is incentivized by cost control, while the Marketing Team is incentivized by brand awareness, creating a conflict over "provocative marketing" spend. The plan states, "Financial constraints may lead to cost overruns."

**Mitigation**: Executive Team: Define a shared OKR for both Finance and Marketing focused on customer acquisition cost (CAC) and brand lift, aligning incentives by 2026-02-15.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Team: Add a monthly review with KPI dashboard and a lightweight change board with thresholds (when to re-plan/stop) by 2026-03-01.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies several high risks (Financial, Market & Competitive, Social) but lacks a cross-impact analysis. A social risk (marketing backfire) could trigger financial shortfalls and competitive disadvantage. The plan mentions "Critical risks: financial, competition, marketing backfire" but lacks a dependency map.

**Mitigation**: Risk Management Team: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by 2026-03-01.