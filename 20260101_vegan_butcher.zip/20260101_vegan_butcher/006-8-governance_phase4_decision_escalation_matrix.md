**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's financial approval limit of 500,000 DKK, requiring strategic oversight.
Negative Consequences: Potential budget overruns and impact on project profitability.

**Critical Risk Materialization with High Social Impact**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Mitigation Plan
Rationale: The 'provocative marketing' has backfired, causing significant brand damage and customer loss, requiring strategic intervention.
Negative Consequences: Severe brand damage, customer attrition, and potential project failure.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Mediation and Final Decision
Rationale: The PMO cannot reach a consensus on a key vendor, delaying project execution and potentially impacting quality.
Negative Consequences: Project delays, compromised product quality, and increased costs.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: A significant change to the project scope is proposed, requiring strategic alignment and budget adjustments.
Negative Consequences: Project delays, budget overruns, and misalignment with strategic goals.

**Reported Ethical Concern Regarding Food Safety**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Executive Leadership Team
Rationale: A potential violation of food safety regulations is reported, requiring independent investigation and corrective action.
Negative Consequences: Fines, legal liabilities, reputational damage, and potential closure of the shop.

**Stakeholder Engagement Group Disagreement on Marketing Campaign**
Escalation Level: Project Management Office (PMO)
Approval Process: PMO Review and Decision based on Project Goals
Rationale: The Stakeholder Engagement Group cannot agree on a marketing campaign, requiring PMO intervention to align with project objectives.
Negative Consequences: Ineffective marketing, alienated stakeholders, and reduced customer acquisition.