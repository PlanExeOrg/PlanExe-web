A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The target demographic will respond positively to provocative marketing. | Conduct A/B testing on social media with provocative vs. traditional ads. | Provocative ads have a significantly lower click-through rate and higher negative sentiment scores. |
| A2 | Local suppliers can consistently provide high-quality ingredients at competitive prices. | Obtain quotes and conduct quality assessments from at least three local suppliers for key ingredients. | Local suppliers' prices are consistently 15% higher than regional suppliers, or quality fails to meet standards in blind taste tests. |
| A3 | The shop can achieve a 20% profit margin within the first year of operation. | Develop a detailed financial model with projected revenue and expenses, including sensitivity analysis for key variables. | The financial model projects a profit margin consistently below 15% even under optimistic scenarios. |
| A4 | The Kødbyen location will attract sufficient foot traffic to sustain the business. | Conduct a foot traffic analysis at different times of day and days of the week. | Average daily foot traffic is less than 500 people during peak hours. |
| A5 | The shop's plant-based meat alternatives will be perceived as comparable in taste and texture to traditional meat products. | Conduct blind taste tests comparing the shop's products to traditional meat products. | Less than 50% of participants rate the shop's products as 'comparable' or 'better' in taste and texture. |
| A6 | The regulatory environment for plant-based food businesses in Copenhagen will remain stable. | Consult with a legal expert to assess potential changes in regulations. | The legal expert identifies pending legislation that could significantly increase compliance costs or restrict the sale of certain products. |
| A7 | The shop's staff will be effectively trained and motivated to consistently deliver excellent customer service. | Implement a comprehensive training program and conduct regular performance evaluations. | Customer satisfaction scores consistently fall below 4 out of 5 stars, or staff turnover exceeds 20% within the first 6 months. |
| A8 | The shop's cloud-based POS and inventory management systems will integrate seamlessly and function reliably. | Conduct thorough testing of the integrated systems under realistic operating conditions. | The systems experience frequent outages, data synchronization errors, or integration failures that disrupt operations. |
| A9 | The local community will actively support the shop's mission and values, leading to positive word-of-mouth referrals. | Engage with local community groups and measure their level of support through surveys and event participation. | Community engagement is low, and surveys indicate a lack of awareness or support for the shop's mission and values. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Red Ink Rebellion | Process/Financial | A3 | Financial Controller | CRITICAL (20/25) |
| FM2 | The Great Grain Drain | Technical/Logistical | A2 | Operations Manager | HIGH (12/25) |
| FM3 | The Provocation Pandemic | Market/Human | A1 | Brand & Marketing Strategist | HIGH (10/25) |
| FM4 | The Regulatory Reef | Process/Financial | A6 | Compliance and Regulatory Specialist | HIGH (10/25) |
| FM5 | The Taste Test Trauma | Technical/Logistical | A5 | Executive Chef / Product Innovation Lead | HIGH (12/25) |
| FM6 | The Kødbyen Kryptonite | Market/Human | A4 | Shop Manager | CRITICAL (16/25) |
| FM7 | The Digital Desert | Technical/Logistical | A8 | Operations Manager | HIGH (12/25) |
| FM8 | The Service Slaughter | Market/Human | A7 | Customer Experience Manager | CRITICAL (20/25) |
| FM9 | The Community Cold Shoulder | Process/Financial | A9 | Community Liaison | HIGH (12/25) |


### Failure Modes

#### FM1 - The Red Ink Rebellion

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A3
- **Owner**: Financial Controller
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's financial model was overly optimistic, failing to account for unexpected costs and lower-than-projected sales. Initial marketing spend was higher than planned due to the need to counteract negative publicity from the 'provocative marketing' campaign. Ingredient costs also rose sharply due to supply chain disruptions. The shop struggled to attract enough customers to offset these increased expenses, leading to a cash flow crisis. The team attempted to cut costs by reducing staff and compromising on ingredient quality, further alienating customers. Ultimately, the shop was unable to meet its financial obligations and was forced to close its doors.

##### Early Warning Signs
- Weekly revenue consistently 15% below projections.
- Operating expenses exceed budget by 10% for two consecutive months.
- Cash reserves fall below one month's operating expenses.

##### Tripwires
- Net profit margin <= 10% after 6 months.
- Cash on hand <= 500,000 DKK.
- Debt-to-equity ratio >= 1.5.

##### Response Playbook
- Contain: Immediately implement a hiring freeze and renegotiate supplier contracts.
- Assess: Conduct a thorough review of the financial model and identify areas for cost reduction and revenue enhancement.
- Respond: Develop a revised financial plan with more realistic projections and explore alternative funding options.


**STOP RULE:** Inability to secure additional funding or achieve a positive cash flow within 9 months of launch.

---

#### FM2 - The Great Grain Drain

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Operations Manager
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The Vegan Butcher Shop's commitment to local sourcing proved to be its downfall. A series of unexpected weather events decimated local crop yields, leading to severe shortages of key ingredients. The shop was unable to secure sufficient quantities of plant-based protein alternatives, resulting in frequent menu changes and inconsistent product quality. Customers grew frustrated with the unreliable offerings, and the shop's reputation suffered. Attempts to source ingredients from regional suppliers were hampered by logistical challenges and increased costs. Ultimately, the shop was unable to maintain a consistent supply of high-quality ingredients, leading to a decline in sales and eventual closure.

##### Early Warning Signs
- Key ingredient prices increase by 20% or more.
- Supplier delivery delays exceed 7 days.
- Inventory levels of key ingredients fall below 50% of target levels.

##### Tripwires
- Key ingredient shortages >= 3 days per month.
- Supplier fill rate <= 80%.
- Ingredient cost variance >= 10%.

##### Response Playbook
- Contain: Immediately activate backup supply agreements and explore alternative ingredient options.
- Assess: Conduct a thorough review of the supply chain and identify vulnerabilities.
- Respond: Diversify sourcing strategies and establish relationships with regional and international suppliers.


**STOP RULE:** Inability to secure a reliable supply of key ingredients for more than 30 consecutive days.

---

#### FM3 - The Provocation Pandemic

- **Archetype**: Market/Human
- **Root Cause**: Assumption A1
- **Owner**: Brand & Marketing Strategist
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The Vegan Butcher Shop's 'provocative marketing' strategy backfired spectacularly. While the initial campaigns generated significant buzz, they also alienated a large segment of the target demographic. The edgy and sometimes offensive content was perceived as insensitive and disrespectful, leading to a social media backlash and a boycott of the shop. Customers complained about the brand's tone and messaging, and many expressed their disappointment with the shop's values. Attempts to apologize and rebrand were unsuccessful, as the damage to the shop's reputation was already done. The shop struggled to regain the trust of its target audience, leading to a sharp decline in sales and eventual closure.

##### Early Warning Signs
- Negative sentiment on social media exceeds 30%.
- Customer complaints increase by 50% or more.
- Website traffic declines by 20% or more.

##### Tripwires
- Net Promoter Score (NPS) <= 0.
- Social media unfollow rate >= 5% per week.
- Brand mentions with negative sentiment >= 40%.

##### Response Playbook
- Contain: Immediately halt all 'provocative marketing' campaigns and issue a public apology.
- Assess: Conduct a thorough review of the marketing strategy and identify the root causes of the backlash.
- Respond: Develop a revised marketing plan with a focus on positive messaging and brand values.


**STOP RULE:** Continued negative publicity and declining sales for more than 60 days despite implementing corrective actions.

---

#### FM4 - The Regulatory Reef

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A6
- **Owner**: Compliance and Regulatory Specialist
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The Vegan Butcher Shop was blindsided by a sudden shift in Danish food regulations. New labeling requirements for plant-based products, coupled with stricter inspections, significantly increased compliance costs. The shop was forced to invest heavily in new packaging and labeling systems, as well as additional staff training. These unexpected expenses strained the shop's already tight budget, leading to cost-cutting measures that compromised product quality and customer service. Ultimately, the shop was unable to meet the new regulatory requirements and was forced to close its doors.

##### Early Warning Signs
- Rumors of pending regulatory changes circulate within the industry.
- Compliance costs exceed budget by 15% or more.
- The shop receives a warning from the Danish Food and Veterinary Administration.

##### Tripwires
- New regulations enacted with compliance deadline < 90 days.
- Compliance costs exceed 100,000 DKK unexpectedly.
- Failed compliance audit.

##### Response Playbook
- Contain: Immediately halt the sale of non-compliant products and begin the process of updating labeling and packaging.
- Assess: Conduct a thorough review of the new regulations and identify all areas of non-compliance.
- Respond: Develop a detailed compliance plan and allocate resources to address the regulatory changes.


**STOP RULE:** Inability to comply with new regulations within 120 days, resulting in significant fines or legal action.

---

#### FM5 - The Taste Test Trauma

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Executive Chef / Product Innovation Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
Despite initial optimism, the Vegan Butcher Shop's plant-based meat alternatives failed to impress customers. Blind taste tests revealed that the products were perceived as inferior in taste and texture to traditional meat products. Customers complained about the bland flavors, rubbery texture, and lack of authentic meat-like qualities. The shop struggled to improve its recipes and production methods, despite investing heavily in research and development. As a result, sales plummeted, and the shop was unable to attract a loyal customer base. Ultimately, the shop's inability to deliver a satisfying culinary experience led to its downfall.

##### Early Warning Signs
- Customer reviews consistently mention negative feedback on taste and texture.
- Sales of plant-based meat alternatives decline by 20% or more.
- Return rates for plant-based meat alternatives increase significantly.

##### Tripwires
- Taste test scores consistently below 6/10.
- Customer satisfaction ratings for taste and texture <= 3/5.
- Product return rate >= 10%.

##### Response Playbook
- Contain: Immediately halt production of poorly rated products and focus on improving recipes.
- Assess: Conduct thorough taste tests and gather customer feedback to identify areas for improvement.
- Respond: Invest in new ingredients, production methods, and recipe development to enhance taste and texture.


**STOP RULE:** Inability to achieve satisfactory taste test scores and customer satisfaction ratings within 6 months.

---

#### FM6 - The Kødbyen Kryptonite

- **Archetype**: Market/Human
- **Root Cause**: Assumption A4
- **Owner**: Shop Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The Vegan Butcher Shop's location in Kødbyen, initially seen as a prime spot, proved to be a major disadvantage. Despite the area's reputation as a food hub, foot traffic was surprisingly low, particularly during off-peak hours. The shop struggled to attract enough customers to sustain its business, as many potential patrons were deterred by the area's limited parking and accessibility. Furthermore, the shop faced intense competition from other food vendors in Kødbyen, making it difficult to stand out and attract attention. Ultimately, the shop's poor location led to low sales and eventual closure.

##### Early Warning Signs
- Foot traffic consistently below projections.
- Customer surveys indicate difficulty finding parking or accessing the shop.
- Sales are significantly lower during off-peak hours.

##### Tripwires
- Daily foot traffic <= 400 people.
- Customer acquisition cost >= 50 DKK.
- Sales during off-peak hours <= 20% of total sales.

##### Response Playbook
- Contain: Immediately implement targeted marketing campaigns to attract more customers to the shop.
- Assess: Conduct a thorough analysis of foot traffic patterns and customer demographics.
- Respond: Explore alternative marketing channels, such as online ordering and delivery services, and consider relocating to a more accessible location.


**STOP RULE:** Continued low foot traffic and declining sales for more than 90 days despite implementing corrective actions.

---

#### FM7 - The Digital Desert

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Operations Manager
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The Vegan Butcher Shop's reliance on integrated cloud-based systems proved disastrous. The POS, inventory, and online ordering systems, despite initial testing, suffered from frequent outages and synchronization errors. Orders were lost, inventory counts were inaccurate, and customers were unable to place online orders. Staff struggled to manage the unreliable systems, leading to long wait times and frustrated customers. Attempts to fix the problems were unsuccessful, as the underlying integration issues remained unresolved. Ultimately, the shop's inability to provide a seamless and reliable customer experience led to a decline in sales and eventual closure.

##### Early Warning Signs
- System outages occur more than once per week.
- Data synchronization errors are reported daily.
- Customer complaints about online ordering increase significantly.

##### Tripwires
- System uptime <= 95%.
- Data synchronization error rate >= 5%.
- Online order completion rate <= 70%.

##### Response Playbook
- Contain: Immediately switch to manual order processing and inventory management.
- Assess: Conduct a thorough review of the systems and identify the root causes of the problems.
- Respond: Replace the unreliable systems with more robust and reliable alternatives.


**STOP RULE:** Inability to restore reliable system functionality within 30 days, resulting in significant operational disruptions.

---

#### FM8 - The Service Slaughter

- **Archetype**: Market/Human
- **Root Cause**: Assumption A7
- **Owner**: Customer Experience Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Despite investing in training, the Vegan Butcher Shop's staff failed to deliver consistently excellent customer service. Employees were often disengaged, poorly informed, and unable to handle customer inquiries effectively. Customers complained about long wait times, rude service, and a lack of product knowledge. The shop struggled to create a welcoming and informative atmosphere, as staff members were often more interested in their phones than in assisting customers. As a result, the shop's reputation suffered, and it was unable to build a loyal customer base. Ultimately, the shop's poor customer service led to a decline in sales and eventual closure.

##### Early Warning Signs
- Customer reviews consistently mention negative feedback on service quality.
- Staff turnover rate increases significantly.
- Employee absenteeism rises above 10%.

##### Tripwires
- Customer satisfaction scores <= 3/5.
- Staff turnover rate >= 30% per year.
- Employee absenteeism rate >= 15%.

##### Response Playbook
- Contain: Immediately implement a customer service retraining program and provide additional support to staff.
- Assess: Conduct customer surveys and gather employee feedback to identify the root causes of the problems.
- Respond: Revamp the training program, improve employee compensation and benefits, and implement a performance management system.


**STOP RULE:** Continued negative customer feedback and high staff turnover for more than 90 days despite implementing corrective actions.

---

#### FM9 - The Community Cold Shoulder

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Community Liaison
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The Vegan Butcher Shop failed to connect with the local community, leading to a lack of support and negative word-of-mouth. Despite attempts to engage with local groups and promote the shop's values, the community remained indifferent. Local residents perceived the shop as an outsider, failing to integrate into the existing social fabric. The shop struggled to attract local customers, relying instead on tourists and visitors. As a result, sales were inconsistent, and the shop was unable to build a sustainable business. Ultimately, the shop's failure to gain community support led to its downfall.

##### Early Warning Signs
- Low attendance at community events hosted by the shop.
- Lack of positive mentions in local media.
- Limited participation in community partnerships.

##### Tripwires
- Community event attendance <= 20 people.
- Positive mentions in local media <= 1 per month.
- Community partnership participation rate <= 20%.

##### Response Playbook
- Contain: Immediately increase community outreach efforts and offer special promotions to local residents.
- Assess: Conduct surveys and focus groups to understand the community's perceptions of the shop.
- Respond: Revamp the community engagement strategy, partner with local organizations, and actively participate in community events.


**STOP RULE:** Continued lack of community support and declining sales for more than 120 days despite implementing corrective actions.
