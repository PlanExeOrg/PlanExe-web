## 1. Market Research on Customer Preferences

Understanding customer preferences is critical for developing products and marketing strategies that resonate with the target audience.

### Data to Collect

- Customer demographics and preferences regarding vegan products
- Feedback on potential signature items
- Perceptions of provocative marketing strategies

### Simulation Steps

- Conduct online surveys using tools like SurveyMonkey or Google Forms to gather customer preferences.
- Analyze social media trends using tools like Hootsuite or Sprout Social to gauge customer sentiment.

### Expert Validation Steps

- Consult with a market research analyst specializing in the food industry.
- Engage with local food bloggers for insights on customer preferences.

### Responsible Parties

- Marketing Manager
- Community Liaison

### Assumptions

- **High:** The target market is receptive to provocative marketing.

### SMART Validation Objective

By the end of month 2, gather feedback from at least 200 potential customers to validate marketing strategies and product preferences.

### Notes

- Focus on diverse demographics to ensure comprehensive insights.


## 2. Supply Chain Assessment

A reliable supply chain is essential for maintaining product quality and managing costs effectively.

### Data to Collect

- List of potential suppliers for plant-based ingredients
- Cost analysis of sourcing from different suppliers
- Quality control measures from suppliers

### Simulation Steps

- Use Excel or Google Sheets to create a cost-benefit analysis of potential suppliers.
- Conduct mock negotiations with suppliers to assess pricing and terms.

### Expert Validation Steps

- Consult with a supply chain risk analyst to evaluate supplier reliability.
- Engage with existing suppliers for feedback on quality control practices.

### Responsible Parties

- Supply Chain Coordinator
- Operations Manager

### Assumptions

- **High:** High-quality ingredients can be sourced at competitive prices.

### SMART Validation Objective

By the end of month 2, identify at least three reliable suppliers and conduct cost analysis to ensure competitive pricing.

### Notes

- Consider local suppliers to reduce transportation costs.


## 3. Financial Projections and Sensitivity Analysis

Accurate financial projections are crucial for assessing the viability of the business and securing funding.

### Data to Collect

- Detailed budget allocation across various business aspects
- Revenue forecasts based on market research
- Cost of goods sold estimates

### Simulation Steps

- Develop a financial model using Excel to project revenues and expenses over the first year.
- Conduct sensitivity analysis to assess the impact of varying ingredient costs and sales volume.

### Expert Validation Steps

- Engage a financial modeling expert to review projections and assumptions.
- Consult with a financial advisor experienced in the restaurant industry.

### Responsible Parties

- Financial Controller
- CFO/Finance Manager

### Assumptions

- **High:** The budget of 10 million DKK is sufficient to cover startup costs.

### SMART Validation Objective

By the end of month 2, complete a detailed financial model with sensitivity analysis and present it to stakeholders for review.

### Notes

- Include best-case and worst-case scenarios in the financial model.

## Summary

Immediate focus should be on validating the most sensitive assumptions regarding customer preferences, supply chain reliability, and financial projections. Engage experts early to ensure robust data collection and validation processes.