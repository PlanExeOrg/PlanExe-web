### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and guidance, given the project's budget, ambitious timeline, and need for a viral marketing campaign.  Ensures alignment with overall business objectives and manages strategic risks.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic direction and guidance.
- Monitor project progress against key milestones.
- Approve major changes to scope, budget, or timeline (above 250,000 DKK).
- Oversee strategic risk management.
- Resolve high-level conflicts and escalate issues as needed.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define escalation paths.
- Review and approve initial project plan.

**Membership:**

- CEO/Owner
- Head of Operations
- Marketing Director
- Finance Director
- Independent Advisor (Food Industry Expert)

**Decision Rights:** Strategic decisions related to project scope, budget (above 250,000 DKK), timeline, and strategic risks. Approval of major changes to the project plan.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the CEO/Owner has the deciding vote. Dissenting opinions are documented in the meeting minutes.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of project progress against milestones.
- Discussion of key risks and mitigation strategies.
- Review of financial performance against budget.
- Approval of change requests (above 250,000 DKK).
- Strategic alignment with business objectives.

**Escalation Path:** CEO/Owner for unresolved issues or conflicts within the Steering Committee.
### 2. Core Project Team

**Rationale for Inclusion:** Manages the day-to-day execution of the project, ensuring tasks are completed on time and within budget.  Provides operational risk management and reports progress to the Steering Committee.

**Responsibilities:**

- Develop and maintain detailed project plans.
- Manage day-to-day project activities.
- Track project progress and report to the Steering Committee.
- Manage operational risks and issues.
- Ensure tasks are completed on time and within budget.
- Coordinate with vendors and suppliers.
- Manage budget within delegated thresholds (below 250,000 DKK).

**Initial Setup Actions:**

- Define roles and responsibilities.
- Establish communication protocols.
- Set up project management tools.
- Develop detailed project schedule.

**Membership:**

- Project Manager
- Head Chef
- Marketing Manager
- Shop Manager
- Procurement Officer

**Decision Rights:** Operational decisions related to day-to-day project activities, task assignments, and budget management within delegated thresholds (below 250,000 DKK).

**Decision Mechanism:** Decisions made by the Project Manager in consultation with relevant team members.  Unresolved issues are escalated to the Steering Committee.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of current risks and issues.
- Task assignments and updates.
- Budget tracking and variance analysis.
- Coordination with vendors and suppliers.

**Escalation Path:** Project Steering Committee for issues exceeding the Project Manager's authority or requiring strategic guidance.
### 3. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures compliance with all relevant regulations, ethical standards, and internal policies, particularly given the provocative marketing strategy and the need to maintain a positive brand image.  Oversees GDPR compliance and ethical sourcing.

**Responsibilities:**

- Develop and maintain a compliance framework.
- Ensure compliance with all relevant regulations (e.g., food safety, GDPR).
- Review and approve marketing materials to ensure ethical standards are met.
- Investigate and resolve compliance violations.
- Provide training to staff on ethical conduct and compliance requirements.
- Oversee data privacy and security measures.
- Ensure ethical sourcing of ingredients.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Develop a compliance checklist.
- Define reporting procedures.

**Membership:**

- Legal Counsel
- Compliance Officer
- HR Manager
- Marketing Manager
- Independent Ethics Advisor

**Decision Rights:** Decisions related to compliance with regulations, ethical standards, and internal policies. Approval of marketing materials from a compliance perspective.  Enforcement of compliance violations.

**Decision Mechanism:** Decisions made by majority vote. The Independent Ethics Advisor has veto power on decisions related to ethical concerns. Dissenting opinions are documented.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of compliance reports.
- Discussion of emerging regulatory issues.
- Review of marketing materials for ethical compliance.
- Investigation of compliance violations.
- Updates on data privacy and security measures.

**Escalation Path:** CEO/Owner and Project Steering Committee for unresolved compliance issues or ethical concerns.
### 4. Stakeholder Engagement Group

**Rationale for Inclusion:** Manages relationships with key stakeholders, including local restaurants, food bloggers, and community members.  Ensures positive relationships and addresses any concerns or feedback.

**Responsibilities:**

- Identify and prioritize key stakeholders.
- Develop and implement a stakeholder engagement plan.
- Conduct regular meetings and communication with stakeholders.
- Gather feedback from stakeholders and address their concerns.
- Organize community events and partnerships.
- Monitor social media and online reviews.

**Initial Setup Actions:**

- Identify key stakeholders.
- Develop a communication plan.
- Establish feedback mechanisms.
- Define roles and responsibilities.

**Membership:**

- Marketing Manager
- Shop Manager
- Community Liaison Officer
- Representative from Local Restaurant Association
- Representative from Local Community Group

**Decision Rights:** Decisions related to stakeholder engagement activities, communication strategies, and community partnerships.  Addressing stakeholder concerns and feedback.

**Decision Mechanism:** Decisions made by consensus. Unresolved issues are escalated to the Project Steering Committee.

**Meeting Cadence:** Bi-monthly

**Typical Agenda Items:**

- Review of stakeholder feedback.
- Discussion of upcoming community events.
- Updates on partnerships with local restaurants and food bloggers.
- Review of social media and online reviews.
- Planning for stakeholder communication.

**Escalation Path:** Project Steering Committee for unresolved stakeholder issues or requiring strategic guidance.