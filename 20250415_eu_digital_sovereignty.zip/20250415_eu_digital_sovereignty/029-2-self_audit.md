Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 17 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 2 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The project focuses on migrating digital infrastructure, which is within the realm of engineering and technology rather than fundamental physics.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (digital infrastructure) + market (pan-European) + tech/process (migration) + policy (digital sovereignty) without independent evidence at comparable scale. The plan states, "The plan is highly ambitious, aiming for pan-European digital sovereignty and resilience".

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Strategic Program Director / Validation Report / 90 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (digital infrastructure) + market (pan-European) + tech/process (migration) + policy (digital sovereignty) without independent evidence at comparable scale. The plan states, "The plan is highly ambitious, aiming for pan-European digital sovereignty and resilience".

**Mitigation**: Strategic Program Director: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. / 90 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because while the plan identifies several risks (regulatory, technical, financial, etc.), it doesn't explicitly map out the cascade effects or provide a dated review cadence. The plan includes "Risk Assessment and Mitigation Strategies", but lacks cascade analysis.

**Mitigation**: Risk Management & Security Officer: Expand the risk register to include cascade effects (e.g., permit delays leading to financial penalties) and schedule a quarterly review cadence. / 60 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a permit/approval matrix and the timeline is aggressive. The plan states a goal of completion by 2035, but lacks detail on dependencies and potential delays. The plan also states "Secure funding from EU and national sources."

**Mitigation**: Technology & Infrastructure Migration Lead: Rebuild the critical path with dated predecessors, authoritative permit lead times, and a NO-GO threshold on slip. / 90 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions funding sources but lacks specifics on status, draw schedule, and covenants. The plan states "Budget of €150-250bn+" but does not specify funding sources or runway length.

**Mitigation**: Chief Financial Officer / Funding Strategist: Develop a dated financing plan listing sources/status, draw schedule, covenants, and a NO‑GO on missed financing gates. / 60 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget conflicts with the scale of the project and lacks sufficient substantiation. The plan mentions a "Budget of €150-250bn+" but provides no benchmarks, quotes, or per-area cost analysis to justify this figure.

**Mitigation**: Chief Financial Officer / Funding Strategist: Benchmark (≥3), obtain quotes, normalize per-area (m²/ft²), and adjust budget or de-scope by Q4 2024.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., completion dates) as single numbers without providing a range or discussing alternative scenarios. The plan states a goal of completion by 2035, but lacks sensitivity analysis.

**Mitigation**: Strategic Program Director: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the most critical projection (completion date). / 90 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks engineering artifacts for build-critical components. There are no technical specs, interface definitions, test plans, or integration maps. The plan mentions "migration of critical digital infrastructure" but lacks engineering details.

**Mitigation**: Technology & Infrastructure Migration Lead: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components. / 120 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes claims about compliance, funding, and technology without providing verifiable artifacts. For example, the plan states "Ensure GDPR/NIS2 compliance" but lacks evidence of a compliance framework or audit reports.

**Mitigation**: EU Policy & Regulatory Affairs Lead: Obtain and link verifiable artifacts (compliance framework, audit reports, funding agreements, technology assessments) to support critical claims. / 90 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "migrating critical infrastructure" without defining specific, verifiable qualities. The plan states "migrate critical digital infrastructure away from US-controlled providers" but lacks SMART acceptance criteria.

**Mitigation**: Technology & Infrastructure Migration Lead: Define SMART criteria for 'critical infrastructure migration,' including a KPI for successful migration rate (e.g., 99% of services migrated). / 60 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'European Technology Leadership Model' which may add cost/complexity without directly supporting core goals (digital sovereignty, reduced reliance on US providers). The plan states "fostering innovation and reducing reliance on foreign providers".

**Mitigation**: Project Team: Produce a one-page benefit case for the 'European Technology Leadership Model,' including KPI, owner, and estimated cost, or move the feature to the project backlog. / 30 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a 'Strategic Program Director' with deep understanding of EU policies, international relations, and large-scale project management. This combination of expertise is critical and likely rare.

**Mitigation**: HR Team: Validate the talent market for a 'Strategic Program Director' with EU policy, international relations, and large-scale project experience. / 60 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a regulatory matrix (authority, artifact, lead time, predecessors) and a fatal-flaw analysis. The plan mentions GDPR and NIS2 but lacks a comprehensive regulatory feasibility assessment.

**Mitigation**: EU Policy & Regulatory Affairs Lead: Develop a regulatory matrix and conduct a fatal-flaw analysis, identifying showstoppers and mapping approval pathways. / 90 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions long-term maintenance but lacks a detailed operational sustainability plan. The plan states "long-term maintenance" as a goal, but lacks a funding/resource strategy or technology roadmap.

**Mitigation**: Technology & Infrastructure Migration Lead: Develop an operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms. / 90 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a permit/approval matrix and the timeline is aggressive. The plan states a goal of completion by 2035, but lacks detail on dependencies and potential delays. The plan also states "Secure funding from EU and national sources."

**Mitigation**: Technology & Infrastructure Migration Lead: Rebuild the critical path with dated predecessors, authoritative permit lead times, and a NO-GO threshold on slip. / 90 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks evidence of redundancy or tested failover plans for external dependencies. The plan mentions "Reduce reliance on US-based cloud providers" but does not address vendor resilience.

**Mitigation**: Risk Management & Security Officer: Secure SLAs with key vendors, add a secondary supplier/path for critical services, and test failover procedures by Q3 2024.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'EU Commission' is incentivized by overall EU strategic goals, while 'National Governments' are incentivized by domestic political and economic priorities, creating a conflict over resource allocation and project scope.

**Mitigation**: Strategic Program Director: Establish a shared, measurable objective (OKR) that aligns both stakeholders on a common outcome, such as 'Increase EU digital sovereignty by X% by 2026'. / 60 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Strategic Program Director: Add a monthly review with KPI dashboard and a lightweight change board with decision thresholds (when to re-plan/stop). / 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies several risks (regulatory, technical, financial, etc.) but doesn't explicitly map out the cascade effects or provide a dated review cadence. The plan includes "Risk Assessment and Mitigation Strategies", but lacks cascade analysis.

**Mitigation**: Risk Management & Security Officer: Expand the risk register to include cascade effects (e.g., permit delays leading to financial penalties) and schedule a quarterly review cadence. / 60 days.