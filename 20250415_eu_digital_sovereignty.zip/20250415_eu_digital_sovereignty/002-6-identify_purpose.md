**Purpose:** business

**Purpose Detailed:** Strategic program for European digital sovereignty and resilience through migration of critical digital infrastructure away from US-controlled providers.

**Topic:** Pan-European Digital Infrastructure Migration Program