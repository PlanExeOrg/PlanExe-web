This plan involves money.

## Currencies

- **EUR:** The project is pan-European and the budget is estimated in EUR.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting. Local currencies may be used for local transactions within individual European countries.