### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 2. Circulate Draft PSC ToR v0.1 for review by Senior Representatives from the EU Commission and National Governments.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary
- PSC ToR v0.2

**Dependencies:**

- Draft PSC ToR v0.1 Completed
- Senior Representatives Identified

### 3. Project Manager incorporates feedback and finalizes the PSC ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final PSC ToR v1.0

**Dependencies:**

- Feedback Summary Received

### 4. Senior Management formally appoints the Chair and Vice-Chair of the Project Steering Committee (PSC).

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails
- Public Announcement

**Dependencies:**

- Final PSC ToR v1.0 Approved
- Potential Candidates Identified

### 5. Project Manager, in consultation with the PSC Chair, identifies and invites members to the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Nominated Members List
- Invitation Letters

**Dependencies:**

- PSC Chair Appointed

### 6. Senior Management formally confirms the membership of the Project Steering Committee (PSC).

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Membership Confirmation Letters
- PSC Membership List

**Dependencies:**

- Nominated Members List Available

### 7. Project Manager schedules and facilitates the initial kick-off meeting for the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Agenda
- Meeting Minutes with Action Items

**Dependencies:**

- PSC Membership Confirmed

### 8. The Project Steering Committee (PSC) holds its initial kick-off meeting to review the program strategy, objectives, and initial budget.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Approved Program Strategy
- Approved Initial Budget
- Initial Action Items

**Dependencies:**

- PSC Membership Confirmed
- Meeting Agenda
- Meeting Minutes with Action Items

### 9. Project Manager defines the PMO structure and roles.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- PMO Structure Document
- Roles and Responsibilities Matrix

**Dependencies:**

- Project Plan Approved

### 10. Project Manager develops project management methodologies and templates for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Management Methodology Document
- Project Templates (e.g., Project Charter, Risk Register)

**Dependencies:**

- PMO Structure Defined

### 11. Project Manager establishes project reporting and tracking systems for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Project Reporting System
- Project Tracking System

**Dependencies:**

- Project Management Methodology Defined

### 12. Project Manager recruits and trains PMO staff.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- PMO Staff Onboarded
- Training Materials
- Trained PMO Staff

**Dependencies:**

- PMO Structure Defined

### 13. Project Manager develops a communication plan for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- PMO Communication Plan

**Dependencies:**

- PMO Staff Onboarded

### 14. Project Manager schedules and holds the initial PMO kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Agenda
- Meeting Minutes with Action Items

**Dependencies:**

- PMO Staff Onboarded
- PMO Communication Plan

### 15. The Project Management Office (PMO) holds its initial kick-off meeting to review project management methodologies, reporting systems, and communication plan.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Approved Project Management Methodologies
- Approved Reporting Systems
- Approved Communication Plan
- Initial Action Items

**Dependencies:**

- PMO Staff Onboarded
- PMO Communication Plan
- Meeting Agenda
- Meeting Minutes with Action Items

### 16. Project Manager identifies and recruits technical experts for the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Nominated TAG Members List
- Invitation Letters

**Dependencies:**

- Project Steering Committee Established

### 17. Project Director formally confirms the membership of the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Membership Confirmation Letters
- TAG Membership List

**Dependencies:**

- Nominated TAG Members List Available

### 18. Project Manager defines the TAG scope and responsibilities.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- TAG Scope and Responsibilities Document

**Dependencies:**

- TAG Membership Confirmed

### 19. Project Manager establishes the TAG meeting schedule and communication protocols.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- TAG Meeting Schedule
- TAG Communication Protocols

**Dependencies:**

- TAG Scope and Responsibilities Defined

### 20. Project Manager develops technical evaluation criteria for the TAG.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- TAG Technical Evaluation Criteria

**Dependencies:**

- TAG Scope and Responsibilities Defined

### 21. Project Manager defines the process for the TAG to provide technical advice.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- TAG Technical Advice Process Document

**Dependencies:**

- TAG Technical Evaluation Criteria Defined

### 22. Project Manager schedules and facilitates the initial kick-off meeting for the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 14

**Key Outputs/Deliverables:**

- Meeting Agenda
- Meeting Minutes with Action Items

**Dependencies:**

- TAG Membership Confirmed
- TAG Technical Advice Process Document

### 23. The Technical Advisory Group (TAG) holds its initial kick-off meeting to review its scope, responsibilities, and technical evaluation criteria.

**Responsible Body/Role:** Technical Advisory Group (TAG)

**Suggested Timeframe:** Project Week 14

**Key Outputs/Deliverables:**

- Approved TAG Scope and Responsibilities
- Approved Technical Evaluation Criteria
- Initial Action Items

**Dependencies:**

- TAG Membership Confirmed
- Meeting Agenda
- Meeting Minutes with Action Items

### 24. Project Manager develops a code of ethics for the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 15

**Key Outputs/Deliverables:**

- Draft Code of Ethics v0.1

**Dependencies:**

- Project Steering Committee Established

### 25. Project Manager establishes compliance policies and procedures for the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 16

**Key Outputs/Deliverables:**

- Draft Compliance Policies and Procedures v0.1

**Dependencies:**

- Draft Code of Ethics v0.1

### 26. Project Manager identifies and recruits ECC members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 17

**Key Outputs/Deliverables:**

- Nominated ECC Members List
- Invitation Letters

**Dependencies:**

- Draft Compliance Policies and Procedures v0.1

### 27. Project Director formally confirms the membership of the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 18

**Key Outputs/Deliverables:**

- Membership Confirmation Letters
- ECC Membership List

**Dependencies:**

- Nominated ECC Members List Available

### 28. Project Manager establishes reporting mechanisms for ethical concerns for the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 19

**Key Outputs/Deliverables:**

- ECC Reporting Mechanisms Document

**Dependencies:**

- ECC Membership Confirmed

### 29. Project Manager develops a compliance training program for the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 20

**Key Outputs/Deliverables:**

- ECC Compliance Training Program

**Dependencies:**

- ECC Reporting Mechanisms Document

### 30. Project Manager schedules and facilitates the initial kick-off meeting for the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 21

**Key Outputs/Deliverables:**

- Meeting Agenda
- Meeting Minutes with Action Items

**Dependencies:**

- ECC Membership Confirmed
- ECC Compliance Training Program

### 31. The Ethics & Compliance Committee (ECC) holds its initial kick-off meeting to review the code of ethics, compliance policies, and reporting mechanisms.

**Responsible Body/Role:** Ethics & Compliance Committee (ECC)

**Suggested Timeframe:** Project Week 21

**Key Outputs/Deliverables:**

- Approved Code of Ethics
- Approved Compliance Policies and Procedures
- Approved Reporting Mechanisms
- Initial Action Items

**Dependencies:**

- ECC Membership Confirmed
- Meeting Agenda
- Meeting Minutes with Action Items

### 32. Project Manager identifies key stakeholders for the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 22

**Key Outputs/Deliverables:**

- Key Stakeholders List

**Dependencies:**

- Project Steering Committee Established

### 33. Project Manager develops a stakeholder engagement plan for the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 23

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Plan v0.1

**Dependencies:**

- Key Stakeholders List

### 34. Project Manager establishes communication channels for the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 24

**Key Outputs/Deliverables:**

- SEG Communication Channels Document

**Dependencies:**

- Draft Stakeholder Engagement Plan v0.1

### 35. Project Manager identifies and recruits SEG members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 25

**Key Outputs/Deliverables:**

- Nominated SEG Members List
- Invitation Letters

**Dependencies:**

- SEG Communication Channels Document

### 36. Project Director formally confirms the membership of the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 26

**Key Outputs/Deliverables:**

- Membership Confirmation Letters
- SEG Membership List

**Dependencies:**

- Nominated SEG Members List Available

### 37. Project Manager develops communication materials for the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 27

**Key Outputs/Deliverables:**

- SEG Communication Materials

**Dependencies:**

- SEG Membership Confirmed

### 38. Project Manager schedules and facilitates the initial kick-off meeting for the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 28

**Key Outputs/Deliverables:**

- Meeting Agenda
- Meeting Minutes with Action Items

**Dependencies:**

- SEG Membership Confirmed
- SEG Communication Materials

### 39. The Stakeholder Engagement Group (SEG) holds its initial kick-off meeting to review the stakeholder engagement plan and communication channels.

**Responsible Body/Role:** Stakeholder Engagement Group (SEG)

**Suggested Timeframe:** Project Week 28

**Key Outputs/Deliverables:**

- Approved Stakeholder Engagement Plan
- Approved Communication Channels
- Initial Action Items

**Dependencies:**

- SEG Membership Confirmed
- Meeting Agenda
- Meeting Minutes with Action Items