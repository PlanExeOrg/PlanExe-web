**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic oversight and approval at a higher level.
Negative Consequences: Potential for budget overruns, project delays, or scope reductions if not addressed strategically.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Approval of Revised Mitigation Strategy
Rationale: Materialization of a critical risk threatens project objectives and requires strategic intervention and resource reallocation.
Negative Consequences: Project failure, significant delays, or increased costs if the risk is not effectively managed.

**PMO Deadlock on Vendor Selection**
Escalation Level: Technical Advisory Group (TAG)
Approval Process: TAG Review and Recommendation to PMO
Rationale: Disagreement within the PMO on a key vendor selection requires expert technical evaluation and guidance to ensure the best solution is chosen.
Negative Consequences: Suboptimal technology selection, project delays, or increased costs if the deadlock is not resolved effectively.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Vote
Rationale: A major change to the project scope impacts strategic objectives, budget, and timelines, requiring approval from the highest governance body.
Negative Consequences: Project misalignment with strategic goals, budget overruns, or delays if the scope change is not properly evaluated and approved.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee (ECC)
Approval Process: Ethics Committee Investigation & Recommendation
Rationale: Ethical violations require independent review and investigation to ensure compliance with regulations and maintain project integrity.
Negative Consequences: Legal penalties, reputational damage, or project disruption if ethical concerns are not addressed promptly and effectively.

**Technical Advisory Group disagreement on key technology selection**
Escalation Level: Project Director
Approval Process: Project Director's final decision, documented with rationale.
Rationale: The TAG could not reach a consensus, and the Project Director needs to make a final decision to keep the project on track.
Negative Consequences: Potential for suboptimal technology selection, project delays, or increased costs if the deadlock is not resolved effectively.