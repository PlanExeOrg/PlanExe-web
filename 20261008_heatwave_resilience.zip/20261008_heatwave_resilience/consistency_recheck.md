_Consistency: first pass found 3 high / 6 medium / 0 low contradictions. Repair: round 1: 44 edits → 3 high / 4 medium; round 2: 33 edits → 2 high / 4 medium; round 3: 30 edits → 0 high / 4 medium. Published: round 3 (fewest high-severity issues). Shown below: the final check of the repaired documents (0 high / 4 medium / 4 low)._

## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Has the funder signed an amendment accepting drill-based evidence for the Month 4 gates and the €750k partial-release rule, and has the municipality named who covers a €200-400k delay gap? | Signed funding amendment by Month 0.5 (target); Month 1 is the tripwire. The partial-release rule is €750k at Month 4, with the remainder after the Month 5 re-test. The gap is €200-400k (estimate), against €160k free tranche-1 contingency. | Signed amendment from a budget-authorizing officer at Month 0.5-1. Written source for any bridging amount, from the municipal budget or the funder. A credit line is excluded by the no-debt model. | No sign-off by Month 1 means a freeze on discretionary commitments only. Tranche-1 orders that the €2.0M already covers should not be frozen. No sign-off and no bridge by Month 2 means re-scoping to the tranche-1 minimum (FM1 stop rule). Do not assume debt financing. |
| 2 | Are the kit supply chain and the first call-off locked? | First call-off of 600-800 kits (30-40%) placed by Month 1.2 with a signed delivery SLA. At least 2 suppliers committed to February delivery. 2-3 backup suppliers per category pre-qualified by Month 1. The expedite premium (€50-100k, estimate) sits inside the €800k kit category. | Firm supplier quotes, signed call-off and backup agreements at Month 1-1.2. Supplier market sounding at Month 0.3 and specs at Month 0.8. | Fewer than 2 suppliers can deliver in February, or the call-off is not placed by Month 1.2: activate the backup supplier within 2 business days. If kits reach <40% delivered by Month 4, cut scope to 1,000-1,500 homes and protect refuges and transport. Under 1,000 installed by Month 7.3 means stop new kit purchases. |
| 3 | Is the outreach model legally and operationally viable? | GDPR opinion at Month 1. At least 4 partner DPAs signed by Month 1.5. Combined partner capacity of at least 4,000 attempts/month (5,000 planned, estimate). Mock-call success of at least 60% in 50-100 calls at Month 1.5. A result of 55-59% triggers a defined correction. | Legal opinion, signed DPAs, partner capacity survey and written commitments, mock-call results at Month 1-1.5. | Delay enrollment and add backup partners. If counsel finds no valid lawful basis, or success stays below 60% after the Month 5 re-test, stop the intermediary model and redesign outreach. Door-knock capacity must then be added before the Month 4 gate. |
| 4 | Does the Month 2 readiness gate pass? | At least 8 of 10 sites signed with named managers. At least 50% of places accessible. Taxi retainer signed (capped at €80k). At least 20 volunteers vetted. Heat line mock passed. Outreach and escalation training completed (test ≥80%). 100% of tranche-1 orders placed. | Gate checklist and signed contracts at Month 2. Volunteer pipeline checked at Month 1.5 (<20 triggers a proportional retainer scale-up). | Fix unmet items by Month 2.5. If more than 4 weeks behind at Month 3, hold a funder restart or re-scope review. Fewer than 6 accessible signed sites at Month 2.5 means redesigning the network before the drill. |
| 5 | Does the full-system drill and after-action close pass all four scale gates, so the €1.5M can be released? | Drill at Month 3.2. At least 80% of planned centre hours delivered. At least 60% contact success from at least 300 attempts. Mean pickup under 45 min over at least 30 requests, including at least 5 wheelchair users. After-action report done and 100% of corrective actions closed by Month 3.9, before the Month 4 decision. | Independent observer's drill data and after-action report (draft Month 3.5, actions closed Month 3.9). The planned-hours basis and drill staffing must be defined before the drill. | A failed gate means no release; fix and re-test at Month 5. A second failure means scaling back to the tranche-1 minimum. If evidence is unmeasurable, release €750k at Month 4 and the remainder after the Month 5 re-test. |
| 6 | Is a Year-2 funding source committed by Month 9? | At least 1 letter of intent by Month 9. Full footprint is ≈€2.3M/year (estimate). The reduced scope must be a single defined range. | Funding letter from EU climate grants, national health budget or municipal mainstreaming. Mayoral continuity commitment by Month 11. Equity audit at Month 9. | Publish a reduced Year-2 scope (refuges and transport first, kits deferred) and obtain written mayoral commitment by Month 11. Otherwise the Month 12 roadmap must say the infrastructure will not continue, which weakens the peer-city case. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: Self-audit; Premortem FM1; Pitch
    canonical: financing_model_no_revenue = 100% grant-financed; no revenue, no debt, no debt service
    observed:  €200-400k contingency credit line / municipal credit line / bridging line of at least €200k
HIGH CF-002  document: canonical_facts (hiring_and_rota vs drill_and_rehearsal_schedule)
    canonical: hiring_and_rota = 40% hired at Month 3; full-system drill at Month 3.2
    observed:  Drill Month 3.2 must show ≥80% of planned hours with 30-40% of staff in post
MEDIUM CF-003  document: Self-audit; Review 12; Project plan; Pitch
    canonical: staffing_plan = 43 FTE peak (centres 18 = 14 + 4 reserve) plus about 1.5 FTE specialists; 40% hired Month 3
    observed:  Extra FTE roles from Month 0; 40 FTE by Month 3; 20-30% staff reserve
MEDIUM CF-004  document: Review 4; Review 11; Review 14
    canonical: contingency_exposure_and_free_contingency = Free contingency €280k; draws are alternatives; both occurring is €350-650k
    observed:  Expedite plus taxi-only fallback = €200-350k exposure against contingency
MEDIUM CF-005  document: Review 6; Review 2; Self-audit
    canonical: outreach_model_and_targets = 3,000 enrolled (≈9% of 65+); no municipal street team in Year 1
    observed:  <15% = equity failure; Year-2 25-35%; emergency street-team deployment; attempts treated as people reached
MEDIUM CF-006  document: Pitch; Review 11; Review 14; Self-audit
    canonical: year2_recurring_cost_estimate = ≈€2.3M per year for the same footprint (estimate, no inflation)
    observed:  €2.3M/year for city-wide scale with 15-20 sites and retrofits; reduced scope €1.5-2.0M vs €1.2-1.5M
MEDIUM CF-007  document: Premortem A1 and FM1
    canonical: procurement_route = First wave €500-700k by Month 1.5; all tranche-1 orders by Month 2
    observed:  Hold binding orders / freeze commitments above €25k until sign-off (tripwire Month 1)
MEDIUM CF-008  document: Exec summary; Review 1; Review 2
    canonical: kit_delivery_and_install_schedule = 40-50% delivered Month 4; 80% Month 5; 100% Month 6; 100% installed Month 7.3
    observed:  4-8 week slip puts 60-80% of kits into June-July, missing peak-risk May
LOW CF-009  document: Self-audit
    canonical: month4_gate_outreach_contact = ≥60% contact success from ≥300 attempts
    observed:  55% as early-warning level
LOW CF-010  document: Review 6
    canonical: evaluation_design_and_limits = No mortality-reduction target is set as a gate
    observed:  10-15% EMS reduction expectation; <5% triggers mid-season course correction
LOW CF-011  document: Review 5
    canonical: contingency_reserve = €160k tranche-1 contingency
    observed:  94% or more of the €160k
LOW CF-012  document: Self-audit; Pitch; Exec summary
    canonical: transport_model = Retainer capped at €80k with ≥10 vehicles within 20 min, ≥3 wheelchair-capable
    observed:  ≥15 vehicles within 20 min; ≥50 staff trained; gates 'proposed, to be locally calibrated'
```

### 1. Gap financing via credit line vs grant-only, no-debt model (🔴 High) — needs a project decision

- **Self-audit items 2, 4, 6, 15; Premortem FM1; Pitch Risks:** Self-audit and Premortem FM1 rely on a '€200-400k contingency credit line', 'pre-identified €200k credit line' and a 'municipal credit line' / 'bridging line of at least €200k'. Pitch accepts 'a cash gap of €200-400k'.
- **Canonical facts: financing_model_no_revenue; gate4_partial_release_rule:** The financing model is 100% grant-financed, with no debt and no debt service.
- **Why it conflicts:** The mitigations assume borrowing the financing model excludes. No document says who pays the €40-240k above the €160k tranche-1 contingency. A €200k line also does not cover the top of the €200-400k range.
- **Suggested resolution:** Remove the credit-line wording. Decide who covers the gap: a municipal budget advance, a funder agreement for earlier partial release, or a pre-agreed service-cut order (kits deferred first). Show it as a funded or unfunded line, not as debt.

### 2. Month 3.2 drill vs staff not yet hired (🔴 High) — needs a project decision

- **Canonical hiring_and_rota; Review 13 item 3; Premortem FM5:** Hiring is 40% at Month 3, 40% at Month 4 and 20% at Month 5, all in post by Month 6.7. The full-system drill is at Month 3.2, six days after the first cohort starts. Review 13 notes only 30-40% of staff are in post by Month 3.
- **Canonical month4 gates; Project plan SMART:** The Month 4 gate requires at least 80% of planned centre hours, at least 60% contact success and pickup under 45 min in the drill, and it releases €1.5M.
- **Why it conflicts:** A drill run mostly by untrained or unhired staff cannot show representative performance. The €1.5M release then rests on a drill that either measures a reduced staffing base or fails for staffing reasons. No document says what 'planned hours' means in the drill or who staffs it.
- **Suggested resolution:** Decide and document one of: (a) pull the first hiring cohort earlier, (b) staff the drill with seconded municipal staff, volunteers and contractors and define planned drill hours on that basis, or (c) state that the drill proves procedures only and the gate is re-tested at Month 5.

### 3. Staffing: extra roles, reserve share and hiring caps vs the 43 FTE plan (🟡 Medium) — needs a project decision

- **Canonical staffing_plan, hiring_and_rota:** 43 FTE at peak (coordination 3, centres 18 including 4 reserve, outreach 6, dispatch 3, phone 3, handypersons 10) plus about 1.5 FTE specialists. Hiring starts at Month 3.
- **Review 12; Self-audit items 4, 13, 18, 20; Project plan Mitigation; Pitch:** Review 12 and the Self-audit add a 1 FTE PMO lead and 1 FTE Partner Liaison Officer (Months 0-12), a 0.25 FTE risk officer from Month 0, a 0.5 FTE engineering lead, a 0.25 FTE communications monitor, an epidemiologist and a 0.5 FTE playbook officer. The Self-audit caps new hires at '40 FTE by Month 3'. The Project plan, Premortem A5 and Pitch promise a '20-30% staff reserve'.
- **Why it conflicts:** The added roles are needed from Month 0 but exceed the 3 coordination and 1.5 specialist FTE, and hiring starts at Month 3. '40 FTE by Month 3' contradicts the 40% (about 17 FTE) cohort at Month 3. The only reserve in the plan is 4 of 18 centre staff (about 9% of 43), not 20-30% overall.
- **Suggested resolution:** List every role with FTE, start month and budget line, and show that it fits 43 FTE plus 1.5 specialists or the €400k governance line. Replace '40 FTE by Month 3' with the 40/40/20 cohort schedule. State the reserve as 4 of 14 centre staff (about 29%) and drop the 20-30% claim for all staff.

### 4. Kit expedite premium counted in contingency exposure although it sits in the kit category (🟡 Medium)

- **Canonical contingency_exposure_and_free_contingency; Exec summary; Review 2; Self-audit item 5:** The expedite premium (€50-100k, estimate) is held inside the €800k kit category, and the contingency is free.
- **Review 4 item 1; Review 11 item 1; Review 14 item 2:** Review 4, Review 11 and Review 14 add the expedite premium to the taxi-only fallback ('combined exposure €200-350k, exceeding all free contingency'). The Self-audit separately says the premium 'leaves contingency free' and gives the exposure as €350-650k.
- **Why it conflicts:** The premium cannot both be funded inside the kit category and draw on the contingency. If it did, the contingency would no longer be free. The €200-350k figure is the taxi-only fallback plus the premium. It is neither the canonical exposure (€350-650k from taxi-only plus a delayed release) nor the expedite plus taxi scale-up (€90-180k).
- **Suggested resolution:** Treat the premium as a kit-category cost only. Contingency exposure is the taxi-only fallback (+€150-250k) or the delayed-release gap (€200-400k), and if both occur €350-650k (estimate), €70-370k above the €280k contingency.

### 5. Equity coverage target, failure threshold and units (🟡 Medium)

- **Exec summary; Review 6 item 3; Review 3 item 3:** Year-1 expectation is 13-16% coverage (3,000 enrolled plus 1,500-2,500 reached, about 29,000 unreached). Year-2 target is 20-25%. Door-knock is 2-3 temporary staff, €50-80k, 'reach' 1,500-2,500.
- **Review 6; Review 2 item 1; Review 1 item 3; Self-audit items 3 and 4; Exec summary:** Review 6 says '<15% signals equity failure', so most of the expected 13-16% range counts as failure. Review 2 says Year 2 takes coverage to '25-35%' (8,000-12,000 enrolled). The same items count 1,500-2,500 'contact attempts', not people, and 500-750 'enrollments' (30-50% conversion) against 'one-time contacts' in the Exec summary. The Self-audit prescribes an 'emergency street-team deployment' and checks ≥30% at Month 9. Review 1 says the expansion 'is not budgeted', while Review 3 reallocates it from the €450k outreach category.
- **Why it conflicts:** The same range is both the expectation and a failure. The Year-2 target differs (20-25% vs 25-35%). Coverage arithmetic needs people reached, not attempts, and 30-50% of 1,500-2,500 does not give 500-750. A municipal street team conflicts with the Year-1 NGO-only street model. ≥30% in the top-3 deprived areas is by Month 12 in one place and checked at Month 9 in another.
- **Suggested resolution:** Use one unit (unique people reached) and one Year-1 expectation (13-16%, estimate). Remove the '<15% = failure' line, or set the trigger against the 20% high-deprivation figure. Keep 20-25% as the only Year-2 target. Replace the emergency street team with NGO or ambassador capacity, or add a budget line. Fund the €50-80k explicitly from the outreach category.

### 6. Year-2 scope, cost and reduced-budget range (🟡 Medium) — needs a project decision

- **Canonical year2_recurring_cost_estimate; Exec summary:** Year-2 recurring cost is ≈€2.3M/year to continue the same footprint (estimate); funding source not identified.
- **Pitch Long-term Vision; Review 2 item 1; Review 11 item 2; Review 14 item 1; Self-audit:** Pitch: 'scales to all 170,000 residents by Year 2' at €2.3M/year, with 15-20 refuge sites and durable retrofits. Review 2: 8,000-12,000 enrolled in Year 2. Review 11 gives a reduced budget of €1.5-2.0M; Self-audit and Review 14 give €1.2-1.5M/year.
- **Why it conflicts:** One figure covers three scopes: same footprint, city-wide expansion and a reduced scope. Two incompatible reduced-scope ranges exist. Review 14 also lists '€3.5M setup costs and €800k home kits' as separate, although the kits are already inside the €3.5M.
- **Suggested resolution:** Keep ≈€2.3M/year for the same footprint only. Cost city-wide expansion and the reduced scope as separate, labelled estimates. Pick one reduced range and say which components it keeps. Correct the double-count of kits.

### 7. Funder sign-off deadline vs commitment freeze and binding orders (🟡 Medium)

- **Exec summary; Review 1; Self-audit:** Written funder sign-off is due by Month 0.5 (Exec summary, Review 1 and 5, Self-audit).
- **Premortem A1 and FM1; Canonical procurement_route:** Premortem A1 sets Month 0.5 as target and Month 1 as hard tripwire, and says to 'hold binding orders above the contingency-covered amount until sign-off'. FM1 freezes commitments above €25k and sets a stop rule at Month 2. The first call-off is at Month 1.2 and the first wave at Month 1.5.
- **Why it conflicts:** A freeze at the Month 1 tripwire would block the Month 1.2 call-off and Month 1.5 wave. The same dependency has three deadlines. Tranche 1 (€2.0M) is available from Month 0 regardless of the drill-rule agreement, and the text does not say which commitments it may cover before sign-off.
- **Suggested resolution:** Keep Month 0.5 as the target and Month 1 as the tripwire. State that tranche-1 orders within the €2.0M proceed; the freeze applies only to discretionary spending and anything that depends on tranche 2. Keep Month 2 as the stop rule only if no bridge exists.

### 8. Peak-risk season vs kit-delay damage (🟡 Medium)

- **Exec summary Focus; Review 1; Canonical kit_delivery_and_install_schedule:** Peak mortality is July-August. The season runs Months 6.8-11.8. Delivery schedule: 100% of kits by Month 6, 100% installed by Month 7.3.
- **Exec summary Risk 2; Review 1 item 2; Review 2 item 2:** A 4-8 week slip 'pushes 60-80% of kits into June-July, missing peak-risk May' (Exec summary, Review 2: only 400-800 homes installed by peak season).
- **Why it conflicts:** If peak risk is July-August, kits arriving in June-July are not missed. The schedule also puts 80% delivered by Month 5 and 100% by Month 6, so an 8-week slip reaches about Month 7-8, not 60-80% in June-July. The text also moves the peak between May, May-June and July-August.
- **Suggested resolution:** Define the peak-risk window once. Recompute the share of kits late for a 4-8 week slip against the delivery schedule. Keep the protected-window claim and the 400-800 homes figure only if the recomputation supports them.

### 9. Outreach early-warning level (55%) below the 60% failure line (⚪ Low)

- **Premortem A3 and FM3; Review 6 item 2:** Premortem and Review 6 use 65% (proposed threshold) as the early-warning level. 55-59% triggers a defined correction. Below 60% is a failure.
- **Self-audit items 2 and 19:** Self-audit gives '<60% in the Month 1.5 mock-call test (55% as early-warning level)', and '<60% with 55% as early warning'.
- **Why it conflicts:** An early warning at 55% sits below the 60% failure line, which inverts the order. A result of 55-59% is a failure by one rule and a warning by the other.
- **Suggested resolution:** Use 65% (proposed threshold) as the early-warning level, 55-59% as a defined correction, and below 60% as a failure, everywhere. Correct the Self-audit.

### 10. EMS reduction expectation vs 'no reduction target' (⚪ Low)

- **Canonical evaluation_design_and_limits; Exec summary; Project plan SMART:** No mortality-reduction target is set as a gate, and EMS calls are tracked with 'no reduction target'. The evaluation states its limits.
- **Review 6 item 1; Review 4 item 3; Review 8 item 1:** Review 6 sets a '10-15% reduction' expectation (8-18 fewer calls). It says <5% 'signals underutilization requiring mid-season course correction'. Reviews 4 and 8 say a baseline of 80-120 is too small to detect a 10-15% change.
- **Why it conflicts:** A numeric expectation with a corrective trigger works as a target. It sits within the noise of a provisional 80-120 baseline that the same documents say cannot detect it.
- **Suggested resolution:** Drop the 10-15% figure and the <5% trigger, or keep it as a hypothesis with no action trigger. Base course correction on operational KPIs (utilization, reach, contact success).

### 11. Contingency percentages (arithmetic) (⚪ Low)

- **Review 8 item 2; Review 9 item 3; Review 12 item 2:** €100-150k of emergency outreach staff is '63-94%' of the €160k tranche-1 contingency (Reviews 8, 9, 12).
- **Review 5 item 1:** Review 5 says the same €100-150k consumes '94% or more' of the €160k.
- **Why it conflicts:** €100k is 63% of €160k, so '94% or more' is wrong. 94% is the top of the range only.
- **Suggested resolution:** Use '63-94%' (€100-150k of €160k) in Review 5.

### 12. Residual parameter drift (transport guarantee, trained staff, gate status, milestones, health data) (⚪ Low)

- **Canonical transport_model, month2_readiness_gate, kit schedule, month4 gates; Self-audit item 2:** Canonical: standby retainer capped at €80k with ≥10 vehicles within 20 min. Escalation training 25-35 partner/street staff. ≥20 volunteers vetted at Month 2. Kits 100% installed at Month 7.3. Month 4 gates are user constraints. The missing health-data MOU does not delay the scale gate.
- **Self-audit items 11 and 17; Pitch; Exec summary:** Self-audit asks for ≥15 vehicles within 20 min at a ≤10% price cap. Pitch has ≥50 partner staff trained on escalation. Exec summary sets 'pipeline ≥20' by Month 2 and kit completion at Month 7 (Months 5-7 as Mar 8 to May 17). Pitch calls the gates 'proposed, to be locally calibrated' and also 'user constraints'. Self-audit item 17 says a missing MOU means 'gates cannot be measured fairly'. Peer cities differ across Pitch, Review 7 and Self-audit.
- **Why it conflicts:** Parameters and milestones for the same item differ between documents. The vehicle guarantee is 50% above the canonical standby and may not fit the €80k cap. The Pitch contradicts itself on whether the gates can change.
- **Suggested resolution:** Use the canonical values: ≥10 vehicles, 25-35 staff trained on escalation (50-80 briefed on GDPR), ≥20 vetted, kits 100% installed Month 7.3, and Month 7 = Month 7.3 only where the date is 05-17. State the gates are fixed (user constraint). Say the MOU affects evaluation, not the drill gates. Use one peer-city list.

## Summary

The plan is largely consistent on its core structure: €3.5M cap, 2.0 + 1.5 tranches, four Month 4 gates, Month 2 readiness criteria, drill schedule, kit and procurement dates, and the €280k contingency. The repairs fixed most earlier problems: the MOU deadlines, the spending-authority bands and the headline equity arithmetic. Material issues remain. The credit-line mitigations conflict with the no-debt financing model and leave the €200-400k delay gap unowned. The Month 3.2 drill is scheduled before most staff are hired. The roles and reserve share do not fit the 43 FTE plan. Smaller items are the expedite premium counted twice, the equity thresholds and units, the Year-2 scope, the peak-season framing, and drift in the Self-audit and Pitch. Two of these need project decisions (gap financing and drill staffing); the rest are text corrections.