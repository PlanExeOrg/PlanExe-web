This plan implies one or more physical locations.

## Requirements for physical locations

- Mid-sized non-capital EU city, population 150k–400k
- Existing municipal assets: libraries, community centers, churches, sports halls, malls suitable for cooling centers
- Social housing stock and top-floor flats to prioritize for home interventions
- Access to public health department, hospitals, EMS, primary care for coordination
- Accessible transport infrastructure and taxi/paratransit operator capacity
- Pharmacy and GP networks for enrollment and outreach partnerships
- Outdoor municipal work sites for worker-protection deployment
- Homeless services and NGO networks for street contact and unhoused support
- Radio, postal and community distribution channels for offline residents
- Administrative capacity for GDPR-compliant data handling and procurement

## Location 1
Spain

Valencian Community, city of Castellón de la Plana

Castellón de la Plana (population ~170k), eastern Spain, Mediterranean coast

**Rationale**: Mid-sized non-capital city with high summer heat and humid nights, large elderly population (65+ ~20%), significant social housing in blocks prone to poor insulation, existing municipal sports halls and community centers. Mediterranean climate increases heat-night mortality risk, matching the program's focus. Strong municipal administration and existing NGO networks for homeless services and migrants (sub-Saharan and North African communities). Proximity to Valencia provides university partnership for evaluation and procurement expertise.

## Location 2
Poland

Greater Poland region, city of Poznań

Poznań (population ~535k, but pilot districts ~200k population), west-central Poland

**Rationale**: Non-capital mid-sized city with increasing summer heat events and poor-insulation Soviet-era housing blocks. Large elderly population concentrated in social housing. Strong municipal health department and existing pharmacy and GP networks for enrollment. Established homeless-service NGOs and migrant communities (Ukrainian, Vietnamese) needing language access. City's administrative capacity and procurement experience supports rapid contracting before Month 2 (2026-12-08) gate. Positioning Poznań as a Central European pilot attracts EU scaling interest.

## Location 3
Italy

Emilia-Romagna region, city of Modena

Modena (population ~185k), northern Italy, Po River valley

**Rationale**: Non-capital mid-sized city with extreme summer heat and hot nights, large aging population (65+ ~23%), significant elderly living alone. Dense historic center and peripheral social housing offer clear cooling-center site options (libraries, parish halls, municipal sports facilities). Strong municipal health and social services with established GP and pharmacy networks. Existing volunteer infrastructure and migrant communities (Eastern European, North African) with NGO support. River-valley geography poses heat-island risk, making program visible locally and relevant to regional scaling across the Po valley.

## Location Summary
The plan requires a specific mid-sized non-capital EU city (population 150k–400k) with Mediterranean or continental summer heat, poor-insulation housing stock, substantial elderly and vulnerable populations, and established municipal assets (libraries, community centers, sports halls). Castellón de la Plana (Spain), Poznań (Poland), and Modena (Italy) are proposed as plausible pilot sites, each offering the combination of heat risk, social vulnerability, existing municipal and NGO infrastructure, and administrative capacity needed to meet the Month 2 (2026-12-08) readiness gate and Month 4 (2027-02-08) scale gate. The choice of city is critical: it determines the cooling-center network footprint, transport demand, outreach partnership routes, language access requirements, and the generalizability of the playbook to other EU cities in similar climates and housing contexts.