**4 open decisions: 2 high and 2 medium severity.** The most urgent are gap financing (by Month 1 = 2026-11-08) and the staffing basis for the Month 3.2 (2027-01-14) drill (by Month 2.5 = 2026-12-23), because both affect release of the €1.5M. The staffing roster is needed by Month 0.5 (2026-10-23). Year-2 scope can wait until Month 9 (2027-07-08). Until they are decided, the plan can safely proceed with tranche-1 orders within €2.0M, GDPR counsel, site contracting and supplier sounding, and hold discretionary commitments.

| # | Decision | Severity | Owner | Decide by | Blocks |
|---|---|---|---|---|---|
| 1 | Gap financing for delayed tranche-2 release | 🔴 High | Heat Response Steering Committee with the funder's budget-authorizing officer. | Month 1 (2026-11-08) (tripwire). Month 0.5 (2026-10-23) is the target. Month 1.2 (2026-11-14) call-offs and Month 1.5 (2026-11-23) orders depend on it. | Month 1.2 (2026-11-14) kit call-off, Month 2 (2026-12-08) readiness gate and the Month 4 (2027-02-08) tranche-2 release. |
| 2 | Staffing basis for the Month 3.2 (2027-01-14) drill | 🔴 High | Heat Response Steering Committee, with the funder consulted on gate evidence. | Month 2.5 (2026-12-23), when the drill protocol is finalised. Hiring changes would need to start before Month 3 (2027-01-08). | Month 3.2 (2027-01-14) drill and the Month 4 (2027-02-08) gate decision on €1.5M. |
| 3 | Full staffing roster and reserve | 🟡 Medium | Incident commander, approved by the Heat Response Steering Committee. | Month 0.5 (2026-10-23), because the roles are needed from Month 0 (2026-10-08) and the HR coordinator is also needed. | Month 2 (2026-12-08) readiness gate staffing and the first hiring cohort at Month 3 (2027-01-08). |
| 4 | Year-2 scope and funding | 🟡 Medium | Mayor and municipal council, with the funder. | Month 9 (2027-07-08) for a letter of intent, so the roadmap and equity audit can use it. Month 11 (2027-09-08) for mayoral commitment. | Month 12 (2027-10-08) Year-2 roadmap and the scaling cost model. |

## 1. Gap financing for delayed tranche-2 release (🔴 High)

**Decision:** Who covers the €200-400k cash gap if the €1.5M release is delayed to Months 5-6 (2027-03-08 to 2027-04-08), given the 100% grant-financed, no-debt model?

**Why it is open:** Self-audit, Premortem FM1 and Pitch assume a €200-400k credit line. The financing model excludes debt. Free tranche-1 contingency is only €160k, leaving €40-240k unowned.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Municipal budget advance, repaid from tranche 2. | Covers the gap without debt. Needs council or budget-officer approval. Keeps hours and transport at plan. | Financing model note; Premortem FM1; Pitch Risks; budget lines. |
| B. Funder agrees an earlier partial release (€750k at Month 4 = 2027-02-08). | Narrows the gap. Needs a signed funder amendment by Month 0.5-1. Aligns with the partial-release rule. | gate4_partial_release_rule; funder agreement; Premortem FM1. |
| C. Pre-agreed service-cut order, kits deferred first. | Gap shown as unfunded. Fewer kits; refuges and transport protected. No new money needed. | Kit scope (2,000 homes); stop rules; Premortem FM1. |

- **If nobody decides:** No sign-off by Month 1 (2026-11-08) freezes discretionary commitments. No bridge by Month 2 (2026-12-08) triggers re-scoping to the tranche-1 minimum.
- **Owner:** Heat Response Steering Committee with the funder's budget-authorizing officer.
- **Decide by:** Month 1 (2026-11-08) (tripwire). Month 0.5 (2026-10-23) is the target. Month 1.2 (2026-11-14) call-offs and Month 1.5 (2026-11-23) orders depend on it.
- **Blocks:** Month 1.2 (2026-11-14) kit call-off, Month 2 (2026-12-08) readiness gate and the Month 4 (2027-02-08) tranche-2 release.

## 2. Staffing basis for the Month 3.2 (2027-01-14) drill (🔴 High)

**Decision:** How is the Month 3.2 (2027-01-14) full-system drill staffed, and what does 'planned hours' mean, when only 40% of staff are hired by Month 3 (2027-01-08)?

**Why it is open:** Hiring is 40% at Month 3 (2027-01-08), with the drill six days after the first cohort starts. The Month 4 (2027-02-08) gates need ≥80% of planned hours, ≥60% contact success and pickup <45 min. No document defines the drill staffing or hours basis.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Pull the first hiring cohort earlier. | More representative drill. Raises early payroll within tranche 1. Needs a faster HR process; the HR coordinator is only 0.5 FTE. | hiring_and_rota; drill schedule; tranche-1 cashflow. |
| B. Staff the drill with seconded municipal staff, volunteers and contractors; define planned drill hours on that basis. | Keeps the hiring schedule. Gate evidence measures a reduced staffing base. Needs an observer-agreed hours definition before the drill. | Drill protocol (final Month 2.5 = 2026-12-23); gate definitions. |
| C. Treat the drill as proof of procedures only; re-test at Month 5 (2027-03-08). | Honest about staffing. €750k partial release at Month 4 (2027-02-08), remainder after the Month 5 (2027-03-08) re-test. Raises cash-gap risk. | gate4_partial_release_rule; month4 (2027-02-08) gates; funder amendment. |

- **If nobody decides:** The drill runs with partial staff. Gates are likely failed or unmeasurable, giving a €750k release or none.
- **Owner:** Heat Response Steering Committee, with the funder consulted on gate evidence.
- **Decide by:** Month 2.5 (2026-12-23), when the drill protocol is finalised. Hiring changes would need to start before Month 3 (2027-01-08).
- **Blocks:** Month 3.2 (2027-01-14) drill and the Month 4 (2027-02-08) gate decision on €1.5M.

## 3. Full staffing roster and reserve (🟡 Medium)

**Decision:** Which added roles are approved, and from which budget line, within the 43 FTE plan?

**Why it is open:** Reviews add a PMO lead, partner liaison, risk officer, engineering lead, comms monitor, epidemiologist and playbook officer from Month 0 (2026-10-08). The plan has 3 coordination and ~1.5 specialist FTE, with hiring from Month 3 (2027-01-08). Documents promise a '20-30% reserve' and '40 FTE by Month 3 (2027-01-08)'.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Fit all roles inside 43 FTE plus 1.5 specialists or the €400k governance line. | Budget cap unchanged. Some roles part-time or later. Needs a role table with FTE, start month and budget line. | staffing_plan; governance budget line; Self-audit; Review 12. |
| B. Add roles by cutting another category (e.g. kits). | Month 0 (2026-10-08) capacity is covered. Fewer kits or less contingency. | budget_allocation_by_category; kit scope. |
| C. Defer non-essential roles to Month 3 (2027-01-08) or later. | Lower early cost. Weaker Month 0-3 (2026-10-08 to 2027-01-08) delivery of the GDPR, procurement and partner work. | hiring_and_rota; Month 2 (2026-12-08) gate risk. |

- **If nobody decides:** Roles are filled informally from Month 0 (2026-10-08), creating unbudgeted cost. The reserve is stated as 4 of 14 centre staff.
- **Owner:** Incident commander, approved by the Heat Response Steering Committee.
- **Decide by:** Month 0.5 (2026-10-23), because the roles are needed from Month 0 (2026-10-08) and the HR coordinator is also needed.
- **Blocks:** Month 2 (2026-12-08) readiness gate staffing and the first hiring cohort at Month 3 (2027-01-08).

## 4. Year-2 scope and funding (🟡 Medium)

**Decision:** Which Year-2 scope will be funded: same footprint, city-wide expansion, or one defined reduced scope?

**Why it is open:** ≈€2.3M/year is the same-footprint estimate, with no funder identified. The Pitch uses it for city-wide scale with 15-20 sites. Reduced scope is €1.5-2.0M in one review and €1.2-1.5M in others. Kits are double-counted in places.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Same footprint at ≈€2.3M/year (estimate). | Needs a funding letter of intent by Month 9 (2027-07-08). Preserves evidence continuity. | Year-2 roadmap; year2_recurring_cost_estimate. |
| B. One reduced scope (refuges and transport first, kits deferred) with a single stated range. | Lower cost. Fewer residents covered. Needs mayoral commitment by Month 11 (2027-09-08). | Pitch; Reviews 11 and 14; Self-audit; roadmap. |
| C. City-wide expansion, costed as a separate labelled estimate. | Higher cost than €2.3M. Weaker evidence base after one season. | Pitch Long-term Vision; scaling cost model. |

- **If nobody decides:** No range is chosen. The Month 12 (2027-10-08) roadmap may say the infrastructure will not continue.
- **Owner:** Mayor and municipal council, with the funder.
- **Decide by:** Month 9 (2027-07-08) for a letter of intent, so the roadmap and equity audit can use it. Month 11 (2027-09-08) for mayoral commitment.
- **Blocks:** Month 12 (2027-10-08) Year-2 roadmap and the scaling cost model.

## Choices made on your behalf

Set when the scenario was selected, not by you. Confirm or change them.

| Lever | Chosen | Strongest alternative | Why it matters | Revisit by |
|---|---|---|---|---|
| Alert Trigger Ladder | National warning plus a low-cost advisory tier (phone check-ins and pre-positioned supplies only). | Locally calibrated thresholds weighting hot nights (Pioneer's Reach). | Sets when centres open and how many site-hours are spent. | After the Month 7 (2027-05-08) second drill and the first season (Month 12 = 2027-10-08). |
| Cooling Refuge Network Shape | About 10 small neighborhood refuges in libraries, parish halls and community centers. | A few large anchor sites with overnight hours (Consolidator's Safeguard). | Drives the €850k refuge category, supervision cost and walking access. | Month 2 (2026-12-08) readiness gate (fewer than 6 accessible signed sites means redesign). |
| Consent-Light Identification Routes | Intermediary-held lists; partners call on the city's behalf and only aggregates reach the city. | Opt-in registry via GPs and pharmacies (Consolidator's Safeguard). | Determines GDPR risk and whether isolated residents are reached. | Month 1 (2026-11-08) GDPR opinion and the Month 1.5 (2026-11-23) mock-call test. |
| Mobility Support Delivery | Vetted volunteer drivers (target 40) with a taxi standby retainer capped at €80k. | Taxi contract with guaranteed capacity (Consolidator's Safeguard). | Drives the 45-minute pickup gate and the taxi-only fallback cost of +€150-250k. | Month 1.5 (2026-11-23) volunteer pipeline check. |
| Command Seat Allocation | Incident commander in the mayor's office with a public-health deputy. | Rotating heat desk with delegated declaration (Pioneer's Reach), or clinical command (Consolidator's Safeguard). | Affects speed of procurement and alert declaration, and political exposure. | Month 1 (2026-11-08), when the delegation of authority is signed. |
