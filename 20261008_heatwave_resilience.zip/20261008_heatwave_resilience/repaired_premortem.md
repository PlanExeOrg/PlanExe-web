A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The funder will accept drill-based evidence for the Month 4 (2027-02-08) gates and the €750k partial-release rule, with no written agreement yet. | Send the funder a protocol memo by Month 0.5 (2026-10-23). Require a signed funding amendment from a budget-authorizing officer (target Month 0.5 (2026-10-23); hard tripwire Month 1 (2026-11-08)). Hold binding orders above the contingency-covered amount until sign-off. | Funder refuses in writing, or gives no signed sign-off, by Month 1 (2026-11-08). |
| A2 | Kit suppliers and the taxi operator will deliver on the stated lead times, with 40-50% of kits arriving by Month 4 (2027-02-08), and volunteer drivers will be vetted in time for the 45-minute transport gate. | Hold a supplier market sounding with 5-8 suppliers by Month 0.3 (2026-10-17); specs final Month 0.8 (2026-11-01), first call-off Month 1.2 (2026-11-14), all tranche-1 orders by Month 2 (2026-12-08). Obtain firm quotes with delivery penalties and a taxi retainer quote. Track the volunteer pipeline weekly. | Fewer than 2 suppliers commit to February delivery for 600-800 units. Or fewer than 20 volunteers are in the pipeline at Month 1.5 (2026-11-23). |
| A3 | Intermediary partners (housing associations, social services, NGOs, pharmacies) have the call capacity, the lawful basis and the willingness to contact enrolled residents and reach isolated, offline and migrant residents. | Survey all 4-6 partners by Month 0.8 (2026-11-01). Collect written capacity commitments. Run a mock-call test of 50-100 calls at Month 1.5 (2026-11-23). | Combined capacity is under 4,000 attempts/month, mock-call success is under 60% (results of 55-59% trigger a defined corrective action before the Month 2 = 2026-12-08 gate), or counsel finds no workable lawful basis. |
| A4 | At least 8 of 10 candidate refuge sites (libraries, community centers, parish halls) will sign facility-use agreements, be accessible within the remediation limit (<=€10k and <=4 weeks per site, proposed threshold), and have staff to open at Level 2-3 hours. | Hold site visits and an independent accessibility audit of all 10 sites by Month 1.5 (2026-11-23). Ask each site owner for written commitment to 10:00-20:00 opening and liability terms. | Fewer than 8 sites are signable, or places in fully accessible sites fall below 50% after remediation caps, by Month 1.5 (2026-11-23). |
| A5 | The municipality can hire and retain about 43 peak FTE, with 20-30% reserve (proposed threshold), within the staggered hiring plan, and staff will sustain multi-day heat waves without major absence or turnover. | Pre-clear position codes with municipal HR by Month 0.5 (2026-10-23). Post the first roles and measure applicants per role, time-to-offer and offer acceptance over 4 weeks. | Median time-to-offer exceeds 8 weeks, or fewer than 2 qualified applicants per role, or offer acceptance is under 70% (proposed threshold). |
| A6 | Hospitals and EMS will sign the data MOU by Month 1 (2026-11-08) and supply daily aggregate heat-related counts by 10:00 next day, with coding good enough to support a usable baseline and escalation triggers. | Meet EMS and hospital data and legal leads by Month 0.5 (2026-10-23). Submit the baseline data request at Month 0 (2026-10-08) and ask for a sample extract showing coding and completeness. | A partner refuses daily counts, requires a DPIA that delays signature beyond Month 2 (2026-12-08), or the extract shows heat coding is too incomplete to define a baseline. |
| A7 | The alert thresholds (Level 1 >=33°C/20°C; Level 2 >=35°C/22°C for >=2 days; Level 3 >=3 days, proposed thresholds) trigger on the right days, producing neither alert fatigue nor missed hot nights, using AEMET forecasts alone. | Obtain 10 years of AEMET temperature records for Castellón by Month 0.8 (2026-11-01). Count how many days per season each level would have triggered, and compare with local heat-related EMS peaks. | Thresholds would have triggered Level 2-3 on more than 40 days per season (estimate), far above the 25 planned full-activation days, or missed hot-night peaks in EMS data. |
| A8 | The 2,000-home kit rubric and handyperson model will reach top-floor and social-housing residents who consent to installation, and fans and shading will be used safely and kept through the season. | Pre-test the rubric on 50-100 sample addresses by Month 1.2 (2026-11-14). Phone a sample of 30 eligible households and record consent to a home visit and installation. | Consent to installation is under 50% (proposed threshold), or fewer than 1,200 homes scoring >=60 can be identified from partner data. |
| A9 | Public and media trust will hold: residents, including migrants and older people, will believe the program's messages, and a single refuge or outreach incident will not trigger a backlash that suppresses use. | Run 3-4 focus groups with 65+ and migrant residents by Month 1 (2026-11-08). Test message credibility and a scripted incident scenario, and ask which messengers they trust. | Fewer than 60% of participants (proposed threshold) say they would use a refuge or answer a partner call, or most name channels the plan does not use. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Winter Gate Cliff | Process/Financial | A1 | Project Manager (PMO Lead) | CRITICAL (15/25) |
| FM2 | The Empty Crates and Idle Cars | Technical/Logistical | A2 | Home Interventions and Handyperson Coordinator | CRITICAL (16/25) |
| FM3 | The Calls Nobody Answers | Market/Human | A3 | Outreach and Street Contact Lead | CRITICAL (16/25) |
| FM4 | The Locked Doors | Technical/Logistical | A4 | Cooling Center Network Manager | HIGH (12/25) |
| FM5 | The Empty Rota | Process/Financial | A5 | Project Manager (PMO Lead) | CRITICAL (16/25) |
| FM6 | The Silent Dashboard | Market/Human | A6 | Public-Health Deputy Incident Commander | HIGH (9/25) |
| FM7 | The Thermostat That Burned the Budget | Process/Financial | A7 | Incident Commander (Mayor's Office) | HIGH (12/25) |
| FM8 | The Fans Nobody Wanted | Technical/Logistical | A8 | Home Interventions and Handyperson Coordinator | HIGH (9/25) |
| FM9 | The Rumor That Emptied the Refuges | Market/Human | A9 | Communications, Language Access and Trusted Messenger Coordinator | HIGH (12/25) |


### Failure Modes

#### FM1 - The Winter Gate Cliff

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Project Manager (PMO Lead)
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Gates fall in the cool season, so the evidence is a drill.
- Funder acceptance was never obtained in writing.
- At Month 4 (2027-02-08) the funder withholds the €1.5M and wants real heat data.
- Cash gap of €200-400k (estimate) exceeds the €160k tranche-1 contingency.
- Staff, transport and kits are cut before the summer peak.
- Partners and volunteers disengage, and credibility is lost.

##### Early Warning Signs
- No signed funding amendment by Month 1 (2026-11-08)
- Funder asks for real-event data or a different drill scale
- Drill protocol not shared with funder by Month 2.5 (2026-12-23)
- Monthly burn above forecast by 10%

##### Tripwires
- No written funder sign-off by Month 1 (2026-11-08)
- Drill protocol not final by Month 2.5 (2026-12-23)
- Forecast cash gap >= €160k at the Month 3.5 (2027-01-23) reforecast

##### Response Playbook
- Contain: Freeze new commitments above €25k and defer discretionary hiring until funder position is confirmed in writing.
- Assess: Reforecast cash to Month 12 (2027-10-08) with the CFO within 5 days, and quantify the gap against the €160k contingency.
- Respond: Negotiate the €750k partial release or a municipal credit line, and re-scope services to the tranche-1 minimum if needed.


**STOP RULE:** If the funder gives no written acceptance of the drill or partial-release rule by Month 2 (2026-12-08) and no bridging line of at least €200k exists, restart or re-scope the project to the tranche-1 minimum.

---

#### FM2 - The Empty Crates and Idle Cars

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Home Interventions and Handyperson Coordinator
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Kit lead times prove longer than the 6-8 weeks assumed, with no pre-committed backup supplier.
- 60-80% of kits arrive after May.
- Volunteer vetting lags, so pickups stretch past 45 minutes and wheelchair users wait longest.
- The taxi-only fallback (+€150-250k, estimate) collides with the expedite premium.
- Kits are cut from 2,000 to 1,000-1,500.
- The transport gate fails in the drill.

##### Early Warning Signs
- Supplier quotes show lead time over 8 weeks
- Supplier misses an interim milestone by over 7 days
- Vetting cohort falls over 1 week behind
- Drill pickup times trend above 45 minutes

##### Tripwires
- First call-off not placed by Month 1.2 (2026-11-14)
- Fewer than 20 volunteers in the pipeline at Month 1.5 (2026-11-23)
- Less than 40% of kits delivered by Month 4 (2027-02-08)

##### Response Playbook
- Contain: Activate the pre-qualified backup supplier within 2 business days and scale the taxi retainer proportionally, capped at €80k; anything above is the taxi-only fallback (+€150-250k) and needs an approval decision.
- Assess: Rerun the delivery and dispatch simulation with actual numbers within 5 days, and cost the kit versus transport trade-off.
- Respond: Reduce the kit scope to 1,000-1,500 homes if needed, protect transport and refuges, and brief the funder.


**STOP RULE:** If fewer than 20 volunteers are vetted and no taxi retainer is signed by Month 2 (2026-12-08), pause scale-up and re-scope transport before any Month 4 (2027-02-08) release request.

---

#### FM3 - The Calls Nobody Answers

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Outreach and Street Contact Lead
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Partners are short of staff or lack a clear lawful basis.
- Contact success falls to 40-50%.
- Enrolled residents are mostly people already known to services; enrollment is about 9% of 65+ (estimate).
- Isolated, migrant and offline residents stay unreached.
- A summer heat event shows deaths concentrated among the unreached.
- Media coverage says the pilot served only the connected.
- Partners withdraw and Year-2 support erodes.

##### Early Warning Signs
- Partner capacity survey shows under 4,000 attempts/month
- Mock-call success under 65% (proposed threshold; 55-59% triggers a defined corrective action, under 60% is a failure)
- A partner delays or refuses to sign its DPA
- Fewer than 5% of calls in non-official languages

##### Tripwires
- Contact success <60% in the drill (Month 3.2, 2027-01-14)
- Fewer than 4 partner DPAs signed by Month 1.5 (2026-11-23)
- Enrollment below 1,500 by Month 5 (2027-03-08)

##### Response Playbook
- Contain: Reassign call targets from weak partners to backup partners and start daily contact logging.
- Assess: Audit enrollment by neighborhood, housing type and language within 7 days, and sample 50-100 consents for validity.
- Respond: Add door-knock teams and ambassador-led enrollment in high-deprivation blocks, and renegotiate partner targets and the gate.


**STOP RULE:** If contact success stays below 60% after the Month 5 (2027-03-08) re-test, or counsel finds no valid lawful basis, stop the intermediary model and redesign outreach.

---

#### FM4 - The Locked Doors

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A4
- **Owner**: Cooling Center Network Manager
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Site owners decline or add conditions on hours, liability or insurance.
- Audits find ramps, toilets or quiet rooms unusable at several sites.
- Remediation exceeds the cap, so sites are dropped.
- Network shrinks below 8 sites and accessible places fall under 50%.
- Drill delivers under 80% of planned hours; wheelchair users concentrate at a few sites.
- Transport demand and the Month 4 (2027-02-08) gate suffer.

##### Early Warning Signs
- Site owners not responding to agreement drafts within 10 days
- Audit rates 3 or more sites red
- Insurance cover for refuge use not bound by Month 1.5 (2026-11-23)
- Named site manager missing at any signed site

##### Tripwires
- Fewer than 8 signed sites at Month 1.5 (2026-11-23)
- Accessible places <50% of planned ~400 at Month 2 (2026-12-08)
- More than 3 sites rated red in the audit

##### Response Playbook
- Contain: Stop fit-out spending at red-rated sites and hold remediation orders above €10k per site.
- Assess: Re-map walking distance coverage (800 m) with the remaining sites within 5 days and recompute planned site-hours.
- Respond: Recruit replacement sites such as sports halls, or concentrate on accessible sites with transport support, and brief the funder.


**STOP RULE:** If fewer than 6 accessible, signed sites exist by Month 2.5 (2026-12-23), re-scope the network design before the drill.

---

#### FM5 - The Empty Rota

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A5
- **Owner**: Project Manager (PMO Lead)
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Municipal HR approvals and seasonal recruiting are slower than the plan.
- Hiring cohorts slip, so the Month 3.2 (2027-01-14) drill runs with few staff.
- Reserve is used up in the first heat wave.
- Overtime and agency replacement push payroll above plan.
- Burnout drives turnover mid-season.
- Payroll overruns compete with the €280k contingency.

##### Early Warning Signs
- Position codes not approved by Month 1 (2026-11-08)
- Offer acceptance under 70%
- Drill rota filled by fewer than 80% of planned staff
- Overtime hours above plan for 2 weeks

##### Tripwires
- Less than 40% of staff hired by Month 3 (2027-01-08)
- Staff in post <90% of plan at Month 6.7 (2027-04-29)
- Payroll forecast >10% over budget at any monthly review

##### Response Playbook
- Contain: Freeze non-essential roles and shift overtime approval to the PMO lead.
- Assess: Compare hires, absences and cost to plan by role within 5 days and identify gate-critical gaps.
- Respond: Use agency or part-time retirees for centers and phone line, cross-train staff, and trim lower-priority roles to protect gates.


**STOP RULE:** If staff in post are more than 4 weeks behind plan at Month 3 (2027-01-08), trigger the funder restart or re-scope review.

---

#### FM6 - The Silent Dashboard

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Public-Health Deputy Incident Commander
- **Risk Level:** HIGH 9/25 (Likelihood 3/5 × Impact 3/5)

##### Failure Story
- Hospital legal teams stall the MOU and ask for a DPIA.
- Heat coding is inconsistent, so counts are late or unreliable.
- Commander gets no escalation signal at 1.5x volume.
- Nurse line and outreach staff lack agreed escalation rules.
- Evaluation baseline is weak, and results are disputed.
- Clinicians distrust the program and local credibility drops.

##### Early Warning Signs
- MOU unsigned at Month 1 (2026-11-08)
- Sample extract shows large share of uncoded heat cases
- Validation pilot misses 10:00 delivery on over 30% of days
- Clinical leads decline to endorse escalation guidelines

##### Tripwires
- MOU not signed by Month 2 (2026-12-08)
- Daily counts delivered on <70% of days in the validation pilot
- Baseline not usable by Month 4 (2027-02-08)

##### Response Playbook
- Contain: Switch to the weekly aggregate fallback and rely on forecast triggers plus EMS-only counts.
- Assess: Audit coding on 50 sampled records within 7 days and recompute evaluation power.
- Respond: Negotiate a narrower EMS-only agreement with the university partner and reframe evaluation on operational outcomes.


**STOP RULE:** If no health data agreement exists by Month 3 (2027-01-08), drop mortality attribution claims and re-scope the evaluation.

---

#### FM7 - The Thermostat That Burned the Budget

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Incident Commander (Mayor's Office)
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Thresholds were set from national levels without local calibration.
- Season triggers far more Level 2-3 days than the 25 planned.
- Each extra full-activation day costs about €324 per planned site-hour across 10 sites (estimate).
- Refuge and transport spending exceeds plan; contingency is drawn early.
- Leadership raises thresholds mid-season, and a hot night is then missed.

##### Early Warning Signs
- Back-test shows more than 30 Level 2-3 days per season
- Spend per alert day above forecast for 2 reviews
- Partner complaints of alert fatigue
- Raise-the-threshold requests from departments

##### Tripwires
- Back-test triggers >40 full-activation days per season (estimate) by Month 1 (2026-11-08)
- Refuge spend >10% above forecast at any monthly review
- More than 30 full-activation days declared by Month 10 (2027-08-08)

##### Response Playbook
- Contain: Freeze threshold changes and hold extra Level 3 extensions until the commander and CFO approve each one.
- Assess: Rerun the back-test with local EMS data within 7 days and cost each alert tier per day.
- Respond: Shift marginal days to the Level 1 advisory tier, reset thresholds with public-health sign-off, and brief the funder.


**STOP RULE:** If projected alert-driven spend exceeds the free contingency of €280k before Month 9 (2027-07-08), cut refuge hours to the tranche-minimum and reset the ladder.

---

#### FM8 - The Fans Nobody Wanted

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Home Interventions and Handyperson Coordinator
- **Risk Level:** HIGH 9/25 (Likelihood 3/5 × Impact 3/5)

##### Failure Story
- Partner data cannot identify enough homes scoring >=60.
- Residents decline visits, citing mistrust or fear of landlords.
- Landlords or heritage rules block exterior shading.
- Handypeople install fewer homes per day than planned.
- Fan misuse or a fire-safety incident draws enforcement.
- Installs fall short of 2,000 by Month 7.3 (2027-05-17).

##### Early Warning Signs
- Consent rate under 50% in the pre-test
- Installations per handyperson per day below plan for 2 weeks
- Landlord refusals above 20% of blocks
- QA inspections fail more than 3% of installs

##### Tripwires
- Consent rate <50% in the Month 1.2 (2026-11-14) pre-test
- Fewer than 500 homes installed by Month 5 (2027-03-08)
- QA failure rate >3% in inspected installs

##### Response Playbook
- Contain: Pause installs at failing sites and quarantine any unsafe fan models.
- Assess: Review consent, access and productivity by block within 7 days.
- Respond: Switch to a lending scheme or landlord bulk deals, retarget unclaimed kits, and reduce scope with funder notice.


**STOP RULE:** If under 1,000 homes are installed by Month 7.3 (2027-05-17), stop new kit purchases and redirect remaining funds to refuges and transport.

---

#### FM9 - The Rumor That Emptied the Refuges

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Communications, Language Access and Trusted Messenger Coordinator
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Residents distrust official channels and refuges.
- An incident at a refuge or a street-outreach assault is reported in local media.
- Unsafe advice (alcohol, fan misuse) spreads faster than corrections.
- Utilization and enrollment fall; migrant and older residents stay home.
- Partners hesitate to be associated; political support weakens.

##### Early Warning Signs
- Refuge utilization under 50% of capacity on Level 2 days
- Misinformation not corrected within 4 hours
- Complaints or negative media about refuge safety
- Ambassador reports of community distrust

##### Tripwires
- Fewer than 60% of focus-group participants would use a refuge by Month 1 (2026-11-08)
- Utilization <50% on 2 consecutive Level 2 days
- Misinformation uncorrected for >4 h on 3 occasions

##### Response Playbook
- Contain: Issue a corrected message through trusted messengers and ambassadors within 4 hours, and pause any contested material.
- Assess: Interview ambassadors, faith leaders and 20 residents within 7 days to find the source of distrust.
- Respond: Co-design replacement messages with community leaders, publish incident findings openly, and shift effort to peer-delivered outreach.


**STOP RULE:** If utilization stays under 30% of capacity after two corrective campaigns by Month 10 (2027-08-08), pivot to door-to-door and peer-delivered cooling support.
