
## Audit - Corruption Risks

- Bribery or kickbacks from cooling-kit suppliers, transport contractors, or handyperson service providers in exchange for contract awards, sole-source purchasing, or expedited payment without competitive tender or quality verification.
- Nepotism in recruitment of cooling-center staff, outreach workers, dispatchers, or volunteer drivers through preferential hiring without transparent selection criteria or documented interviews.
- Conflicts of interest: incident commander, procurement officer, or partner-liaison staff steering contracts to family-owned suppliers, taxi operators, or translation firms, or accepting personal gifts or favors from vendors.
- Theft or misallocation of cooling kits, hydration supplies, or thermometer/hygrometer stock by handypersons, storage custodians, or center staff; sale of municipal equipment on the black market or for personal use.
- Information misuse: partner staff (housing associations, NGOs, social services) sharing enrolled residents' contact data with third parties (political campaigns, unsolicited marketing, creditors) beyond the agreed data-processing scope.
- Collusion between transport dispatchers and taxi-retainer operators to inflate trip counts, falsify response times, or double-bill for overlapping rides, or between outreach staff and intermediary partners to inflate contact-success metrics to meet the 60% gate.

## Audit - Misallocation Risks

- Budget misuse: reallocation of cooling-center operational funds (staffing, utilities, supplies) to unbudgeted items (office furniture, personal equipment, meals) or deliberate overspending on low-priority items to deplete contingency reserves.
- Double spending: same kit component (e.g., fans) purchased twice through different procurement routes (framework call-off and competitive tender) without canceling the first order, resulting in duplicate stock and wasted funds.
- Inefficient allocation: concentration of cooling centers in affluent neighborhoods while high-risk peripheral and historic-quarter areas remain under-served; failure to track equity coverage by deprivation index.
- Unauthorized use of transport assets: volunteer drivers or dispatchers using taxi-retainer vehicles for personal errands outside alert-day mobilization, or dispatchers redirecting resources to non-heat-response municipal functions.
- Poor record-keeping: lack of documented procurement files, missing contracts, unsigned MOUs, or no audit trail for cash disbursements, preventing verification of compliance with procurement rules or budget allocations.
- Misreporting progress or results: inflated contact-success rates (claiming 70% when actual data shows 50%), falsified drill metrics, or overstated kit installation completion to meet Month 4 (2027-02-08) gates and trigger conditional funding release.

## Audit - Procedures

- Quarterly external audit of procurement files and vendor contracts: review call-off orders, competitive tenders, sole-source justifications and supplier invoice-to-payment chains to verify compliance with municipal procurement thresholds and competitive requirements by Month 2, 5, 8, and 11 (2026-12-08, 2027-03-08, 2027-06-08, 2027-09-08).
- Monthly internal financial review: reconcile budget burn against planned spend by cost category (refuges, transport, kits, staffing, communications); flag overruns >10% and conduct drill-down reviews with cost-center owners within 5 working days.
- Biweekly data-integrity spot-checks of outreach contact logs and transport-dispatch records: audit 10% sample of recorded calls, contact outcomes and pickup times against actual partner records; validate drill metrics against real-time recordings or witness statements.
- Post-gate audit at Month 4 (2027-02-08): independent verification of all three gate metrics (80% center hours, 60% outreach success, <45-min transport) by external auditor; compare drill data against baseline assumptions and drill protocol to confirm fairness of measurement.
- Annual compliance audit of partner organizations (housing associations, NGOs, social services, pharmacies) against GDPR data-processing agreements: review consent records, staff confidentiality training logs, data-retention compliance and breach-notification procedures by Month 9 (2027-07-08).
- Post-season evaluation audit (Month 12 = 2027-10-08): verify heat-related EMS and ED data quality with hospitals/EMS, reconcile baseline estimates against final case counts, and validate any reported reductions in mortality with independent cause-of-death review.

## Audit - Transparency Measures

- Monthly public dashboard (municipal website) reporting: planned vs. actual cooling-center hours delivered, outreach contact attempts and success rates by partner, transport requests and average response times, cumulative kit installations by neighborhood, and budget spend-rate against forecast by cost category; updated by 5th of each month.
- Published weekly meeting minutes from the incident-command team and monthly partner-coordination meetings: document alert declarations, trigger thresholds used, cross-department decisions on escalation, corrective actions closed, and budget reforecasts; accessible to council and stakeholders within 5 working days of meeting.
- Heat Response Playbook (draft by Month 11 = 2027-09-08, final at Month 12 = 2027-10-08): public document detailing all SOPs, decision logic, cost assumptions, staffing specifications, partner roles and lessons learned; identifies city-specific adaptations and replicability conditions for peer EU cities.
- Quarterly public stakeholder briefing (Months 1, 4, 7, 10 = 2026-11-08, 2027-02-08, 2027-05-08, 2027-08-08): open forum where vulnerable residents, NGO partners, faith leaders and media can ask questions about program progress, equity coverage and upcoming actions; minutes published within 10 days.
- Procurement transparency summary (published by Month 2 = 2026-12-08): list all contracts ≥€50k with vendor name, scope, value, procurement route and rationale for method (e.g., 'framework call-off for rapid kit delivery') to enable scrutiny and demonstrate competitive justification.
- Post-season evaluation report (Month 12 = 2027-10-08): independent university analysis of heat-related EMS calls, ED visits and excess mortality with explicit confidence intervals, comparison-group methodology, temperature adjustment and attribution caveats; published in plain-language summary and technical annex for public and peer-city use.