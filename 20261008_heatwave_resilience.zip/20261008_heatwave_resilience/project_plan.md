**Goal Statement:** Run a 12-month heatwave-response pilot in Castellón de la Plana, Spain (~170k residents) within a €3.5M hard cap (€2.0M initial, €1.5M released at Month 4 = 2027-02-08 only if all four scale gates are met), to reduce heat-related harm among vulnerable residents without major construction, and deliver a repeatable playbook by Month 12 (2027-10-08).

## SMART Criteria

- **Specific:** Reduce heat-related harm in Castellón de la Plana through tiered alerts, about 10 cooling refuges, transport support, GDPR-compliant outreach to high-risk residents, home kits for 2,000 homes, health-system data loops, worker protection and public communications. The result is a Heat Response Playbook, scaling cost model, evaluation report and Year-2 roadmap.
- **Measurable:** Month 4 (2027-02-08) gates (user constraint): ≥80% of planned refuge hours delivered in the drill; ≥60% outreach contact success from ≥300 attempts; mean pickup under 45 min over ≥30 requests; after-action actions 100% closed. Also track heat-related EMS calls (baseline 80-120, estimate), ED visits, excess deaths (15-25, estimate) and equity coverage. No mortality-reduction target is a gate.
- **Achievable:** Uses existing libraries, community centers and parish halls, intermediary-held contact lists, volunteer drivers with taxi backup, and 43 peak FTE that can be hired or contracted. The €280k contingency covers some risks but not both the taxi-only fallback and a delayed release (exposure €350-650k, estimate). Cool-season gates rely on drills.
- **Relevant:** Multi-day heat events with hot nights are increasing and hit older, isolated, poorly housed, outdoor-working, unhoused and migrant residents hardest. The pilot gives a tested, auditable model other EU cities can adopt, and a basis for a Year-2 funding decision (≈€2.3M/year, estimate; source not identified).
- **Time-bound:** Project starts Month 0 (2026-10-08) and runs 12 months to Month 12 (2027-10-08). Readiness gate at Month 2 (2026-12-08); drill at Month 3.2 (2027-01-14); scale gate at Month 4 (2027-02-08); season Months 6.8-11.8; playbook drafting from Month 8 (2027-06-08); final deliverables at Month 12 (2027-10-08).

## Dependencies

- Mayoral delegation of authority signed and incident command roles named by Month 1 (2026-11-08)
- GDPR counsel engaged, legal opinion and partner data-processing agreements signed by Month 1.5 (2026-11-23)
- Procurement of refuge fit-out, transport retainer, home kits and handyperson services completed by Month 2 (2026-12-08)
- Hiring and vetting of staff and volunteer drivers, with training completed before gates
- Hospital, EMS and primary-care MOU for aggregate heat data, and a university evaluation partner

## Resources Required

- Home kits (shading, reflective blinds, fans, thermometer/hygrometers, hydration supplies) for 2,000 homes
- Taxi/accessible-transport standby retainer and volunteer driver insurance
- Refuge site fit-out: water, first-aid kits and AEDs
- Telephone interpretation, translation and printed materials (flyers, door hangers, posters)
- Heat helpline telephony and shared tracking spreadsheet

## Related Goals

- Reduce emergency and hospital load during heat events
- Improve housing resilience for top-floor and social-housing residents
- Expand to city-wide and other EU cities
- Strengthen language access and equity of public services

## Tags

- heatwave
- public health
- municipal
- Castellón de la Plana
- cooling centers

## Risk Assessment and Mitigation Strategies


### Key Risks

- Cool-season gates cannot be tested on real heat; drills are the evidence and the €1.5M release may be delayed, leaving a cash gap of €200-400k (estimate)
- Kit and transport procurement slips past Month 2 (2026-12-08), pushing installs beyond the season
- Volunteer recruitment or vetting shortfall pushes pickup times above 45 min or forces taxi-only (+€150-250k, estimate)
- GDPR challenge or partner withdrawal reduces outreach reach and the 60% contact gate
- Staff fatigue and absences in multi-day heat events degrade refuge hours and dispatch

### Diverse Risks

- Reputational damage from an incident at a refuge or a failed response under media attention
- Volunteer and street-outreach safety, including assault and safeguarding failures
- Misinformation (alcohol, fan misuse) and weak reach to offline and migrant residents
- Budget overrun and no identified funding for Year 2
- Alert-trigger errors: false alarms burn budget, missed hot nights harm residents

### Mitigation Plans

- Pre-specify drill protocol (final Month 2.5 = 2026-12-23) and full-system drill at Month 3.2 (2027-01-14); if evidence is insufficient, release €750k at Month 4 (2027-02-08) and the rest after a Month 5 (2027-03-08) re-test; hold €160k tranche-1 contingency
- Issue specs by Month 0.8 (2026-11-01), place the first 30-40% kit call-off at Month 1.2 (2026-11-14), and pre-qualify 2-3 backup suppliers per category; all tranche-1 orders by Month 2 (2026-12-08)
- Recruit volunteers from Month 0 (2026-10-08) in fortnightly vetting cohorts; if <20 recruits in pipeline at Month 1.5 (2026-11-23), scale the taxi retainer (capped at €80k)
- Obtain legal opinion by Month 1 (2026-11-08) and sign partner DPAs by Month 1.5 (2026-11-23); share only aggregates; audit partners at Month 9 (2027-07-08)
- Hold a 20-30% staff reserve, limit shifts to 3-4 consecutive days, and train in fatigue management by Month 3 (2027-01-08); require first-aid staff and AED per site, teams of ≥2, nurse triage line, and misinformation correction within 4 h

## Stakeholder Analysis


### Primary Stakeholders

- Incident commander (mayor's office) and public-health deputy
- Civil protection operations lead and communications lead
- Partner liaison officer and PMO/HR coordinator
- Refuge managers, dispatchers, phone operators, outreach staff and handypersons
- Volunteer drivers and community language ambassadors

### Secondary Stakeholders

- Housing associations, social services, NGOs, pharmacies and GPs
- Hospitals, EMS and the national meteorological service
- Taxi and accessible-transport operators and kit suppliers
- Funder, university evaluation partner and data protection authority
- High-risk residents, unhoused people, migrant communities, faith leaders and employers

### Engagement Strategies

- Primary team: daily SITREP at 08:30 on alert days, weekly progress reports during setup, prompt answers to information requests
- Partners: 09:30 briefing on alert days, signed MOUs/DPAs, monthly liaison contact, joint planning at Months 1, 4, 7 and 10 (2026-11-08, 2027-02-08, 2027-05-08, 2027-08-08)
- Health system: daily aggregate counts by 10:00, commander notified at ≥1.5× historical average volume
- Funder: gate reports at Months 2 and 4 (2026-12-08, 2027-02-08), plus immediate notice of scope or timeline changes
- Residents and community: radio, flyers, pharmacy posters, door hangers, opt-in SMS, trusted-messenger briefings, multilingual materials and focus-tested messages

## Regulatory and Compliance Requirements


### Permits and Licenses

- Facility-use agreements and insurance for each refuge site
- Public procurement approvals (framework call-offs, below-threshold and tenders)
- Volunteer driver insurance and background checks
- Municipal approval for exterior shading where building or heritage rules apply

### Compliance Standards

- GDPR and Spanish data-protection law (lawful basis, retention, breach notice within 48 h)
- Disability accessibility requirements for refuge sites
- Occupational health and safety rules for outdoor workers and outreach staff
- EU/Spanish public-procurement rules and audit readiness

### Regulatory Bodies

- Spanish Data Protection Agency (AEPD)
- Regional health authority and EMS
- National meteorological service (AEMET)
- Municipal legal and procurement departments

### Compliance Actions

- Engage GDPR counsel at Month 0.5 (2026-10-23); opinion by Month 1 (2026-11-08); DPIA/screening and partner DPAs by Month 1.5 (2026-11-23)
- Run accessibility audit of all sites by Month 1.5 (2026-11-23); ≥50% of places in fully accessible sites
- Benchmark and document procurement files; avoid order splitting to stay under thresholds
- Train handypersons on safe fan use and installation; inspect 10-20% of installs
- Audit partner consent records at Month 9 (2027-07-08); delete data ≤30 days after Month 12 (2027-10-08) unless re-consented