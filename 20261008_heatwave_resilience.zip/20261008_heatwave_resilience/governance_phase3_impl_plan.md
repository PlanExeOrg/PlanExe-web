### 1. Senior municipal leadership (mayor's chief of staff or delegated executive) formally designates the incident commander, public-health deputy, operations lead, communications lead and partner-liaison officer. Issue written position descriptions, delegations of authority, and escalation rules specific to each role. Confirm each person's availability for Months 0–12 (2026-10-08 to 2027-10-08) and establish their direct reporting lines to the mayor's office.

**Responsible Body/Role:** Mayor's office or delegated chief executive (pre-project senior leadership), supported by municipal HR director.

**Suggested Timeframe:** By end of Month 0.5 (2026-10-23). Early designation ensures clarity and allows concurrent recruitment and legal setup.

**Key Outputs/Deliverables:**

- Written appointment letters or position confirmations for 5 lead roles
- Role-specific position descriptions and delegations of authority
- Escalation and decision-authority matrix signed by mayor or delegate
- Confirmed start dates and contact details for each lead

**Dependencies:**

- Project approval and budget release by city council or mayor
- Organizational readiness to assign FTE capacity to these roles

### 2. Project Manager or incident commander engages a GDPR specialist legal firm by written contract. Scope: review the intermediary-held list model, draft data-processing agreement templates for housing associations, social services, NGOs, and pharmacies, assess lawful basis for contact, and advise on risk mitigation. Set budget ceiling (≤€30k estimate) and delivery deadline (legal opinion by Month 1 = 2026-11-08).

**Responsible Body/Role:** Incident commander (newly designated), with support from municipal legal department and procurement.

**Suggested Timeframe:** Within 1 week of incident commander's appointment (Month 0.3–0.5 = 2026-10-15 to 2026-10-23).

**Key Outputs/Deliverables:**

- Signed GDPR counsel retainer agreement
- Documented scope and deliverables list
- Budget and timeline agreement
- Counsel contact and escalation protocol

**Dependencies:**

- Incident commander designated
- Budget authorization for legal services (€20k–30k estimate)

### 3. Incident commander convenes the Project Management Office (PMO) core team: project coordinator (FTE), HR/recruitment coordinator (0.5 FTE), procurement specialist (0.5 FTE), and partner-liaison officer. Establish shared workspace (desks, email lists, shared drives), daily standup schedule (09:00, 15 min), weekly planning meeting (Mondays 14:00, 60 min), and communication protocols (escalation hotline, incident log). Publish project charter and governance-body establishment roadmap to all team members.

**Responsible Body/Role:** Incident commander, supported by HR director for staff allocation.

**Suggested Timeframe:** Within 2 weeks of incident commander appointment (Month 0.5–0.7 = 2026-10-23 to 2026-11-05).

**Key Outputs/Deliverables:**

- PMO workspace established with shared digital infrastructure
- Core team roles confirmed and responsibilities documented
- Standup and planning meeting schedules published and confirmed
- Project charter and governance-body roadmap distributed to all stakeholders

**Dependencies:**

- Incident commander designated
- Budget availability for PMO staffing

### 4. Municipal legal department and GDPR counsel jointly draft template data-processing agreements (DPAs) and memoranda of understanding (MOUs) for each partner type: housing associations, social services, NGOs, and pharmacies. DPAs specify lawful basis (public-task/consent hybrid, to be confirmed by counsel), data scope (contact details and risk flags only, no health records), retention (one season, October–September), and breach notification (within 48 hours). Counsel issues written legal opinion on intermediary-held list model and consent basis by Month 1 (2026-11-08).

**Responsible Body/Role:** GDPR specialist legal counsel (external retainer) and municipal legal lead (internal, 0.5 FTE).

**Suggested Timeframe:** Drafts completed by Month 1 (2026-11-08); legal opinion delivered by same date.

**Key Outputs/Deliverables:**

- Template DPA for housing associations (draft)
- Template DPA for social services (draft)
- Template DPA for NGOs (draft)
- Template DPA for pharmacies (draft)
- Written legal opinion on lawful basis and GDPR compliance
- Recommended revisions and clarifications

**Dependencies:**

- GDPR counsel retainer signed
- Municipal legal department engaged

### 5. Project coordinator issues procurement specifications for cooling kits (exterior shading, reflective blinds, fans, thermometers, hygrometers), handyperson installation services, and transport infrastructure (phone line systems, call-tracking software, dispatch coordination tools). Specifications must include required delivery dates (first tranche February, second tranche by April), quality standards, and sustainability/reuse clauses. Contact leading 3–5 suppliers per category to confirm availability and lead times; document responses.

**Responsible Body/Role:** Project coordinator and procurement specialist, with input from Home Kit Lead (once designated; interim coordination via project manager).

**Suggested Timeframe:** Specifications issued by Month 0.8 (2026-11-01); supplier contact and lead-time confirmation by Month 1 (2026-11-08).

**Key Outputs/Deliverables:**

- Kit procurement specification document (v0.1)
- Handyperson service specification
- Transport/dispatch infrastructure specification
- Supplier lead-time and availability summary

**Dependencies:**

- Project PMO established
- Budget allocation for kits and services confirmed

### 6. Incident commander and public-health deputy jointly set and document heat-alert trigger thresholds per the strategic decision (Alert Trigger Ladder). Thresholds: Level 1 Advisory (forecast high ≥33°C or night low ≥20°C on ≥2 consecutive days), Level 2 Alert (high ≥35°C and low ≥22°C for ≥2 consecutive days), Level 3 Emergency (same as Level 2 for ≥3 days or national red warning). Publish thresholds to Steering Committee and all partners. Coordinate with national meteorological service (AEMET) to confirm forecast data access and delivery schedule.

**Responsible Body/Role:** Incident commander and public-health deputy (newly designated).

**Suggested Timeframe:** By end of Month 1 (2026-11-08).

**Key Outputs/Deliverables:**

- Documented alert-trigger thresholds (Level 1, 2, 3) with decision rationale
- Confirmation of forecast data access from AEMET
- Alert decision-tree flowchart and decision authority assignment
- Internal briefing memo for Steering Committee members

**Dependencies:**

- Incident commander and public-health deputy designated
- Strategic decision on Alert Trigger Ladder finalized

### 7. Incident commander prepares a formal agenda, membership list, and standing-meeting schedule for the Heat Response Steering Committee. Confirm availability and meeting commitment from mayor or chief executive (Chair), public-health deputy (Vice-Chair), civil protection director, communications director, municipal finance director and external evaluation partner (advisor). Send meeting invitations and confirm attendance for the first meeting (Month 1.3 = 2026-11-17).

**Responsible Body/Role:** Incident commander with support from municipal chief of staff or executive assistant.

**Suggested Timeframe:** By Month 1.2 (2026-11-14).

**Key Outputs/Deliverables:**

- Steering Committee charter and ToR (v0.1)
- Confirmed membership list with role titles and contact details
- Standing-meeting schedule (monthly, then bi-weekly, then monthly per project phases)
- Agenda template and decision-logging template
- Written calendar invitations sent and RSVPs confirmed

**Dependencies:**

- Incident commander designated
- Governance-body descriptions from governance-phase2-bodies.json available

### 8. HR coordinator launches formal recruitment for all governance-body roles and core staff: Cooling Center Operations Lead (1 FTE), Outreach and Enrollment Lead (1 FTE), Transport Lead / Dispatch Coordinator (1 FTE), Home Kit Lead / Installation Coordinator (1 FTE), Legal and GDPR Lead (0.5–1 FTE, may be municipal legal department role). Publish job descriptions, advertise via municipal channels and relevant professional networks, set application deadline (end of Month 1 = 2026-11-08), and plan interviews for Month 1.3–1.5 (2026-11-17 to 2026-11-30).

**Responsible Body/Role:** HR coordinator (0.5 FTE, designated by incident commander) and municipal HR director.

**Suggested Timeframe:** Recruitment launched by Month 0.8 (2026-11-01); interviews completed by Month 1.5 (2026-11-23).

**Key Outputs/Deliverables:**

- Job description documents for 5 lead roles
- Published recruitment announcements
- Interview panel composition and schedule
- Shortlist of candidates by role

**Dependencies:**

- Incident commander and HR coordinator appointed
- Budget allocation for lead roles confirmed

### 9. First meeting of the Heat Response Steering Committee: Incident commander briefs on project status, governance-structure setup, legal-review scope and timeline, and procurement plan. Steering Committee formally approves: (1) alert-trigger thresholds (Level 1, 2, 3); (2) alert-declaration delegation and backup authority; (3) GDPR legal-review scope and budget; (4) procurement route and spending authority (frameworks + below-threshold for tranche 1). Committee confirms monthly meeting cadence during setup (Months 0–4 = 2026-10-08 to 2027-02-08). Document all approvals and decisions.

**Responsible Body/Role:** Heat Response Steering Committee (majority vote, Chair has tie-breaker; quorum 4 of 6 members including Chair or Vice-Chair).

**Suggested Timeframe:** Month 1.3 (2026-11-17); allow 1 week for scheduling after membership confirmed.

**Key Outputs/Deliverables:**

- Steering Committee meeting minutes with formal approvals
- Signed alert-declaration delegation letter
- Approved GDPR legal-review scope and budget authorization
- Approved procurement route and authority matrix
- Distribution of decisions to all stakeholders and departments

**Dependencies:**

- Steering Committee membership confirmed and first meeting scheduled
- Alert thresholds and delegation drafted for approval
- GDPR legal review initiated

### 10. Partner-liaison officer identifies and initiates formal engagement with ≥4 key intermediary partners: housing associations, social services, NGOs and pharmacy chains. Send introductory letters explaining the program, data-protection model (intermediary-held lists, no personal data to city), expected roles (outreach via their existing contacts, daily call-logging, partner training) and timeline. Request designation of a partner contact person for each organization. Schedule individual scoping meetings to understand partner capacity, existing data systems, and any data-governance constraints.

**Responsible Body/Role:** Partner-liaison officer (incident commander until this role is hired; then designated Partner-liaison Officer within Heat Response Operations Team).

**Suggested Timeframe:** Introductory letters sent by Month 0.8 (2026-11-01); scoping meetings held by Month 1.2 (2026-11-14).

**Key Outputs/Deliverables:**

- Written introductory letters to ≥4 partners
- Scoping-meeting notes for each partner (capacity, data systems, constraints)
- Designated partner contact person and escalation contact for each organization
- Summary of preliminary partner feedback and risks

**Dependencies:**

- Partner-liaison officer designated or interim role assigned
- Program governance and data-protection model finalized

### 11. Cooling-center Operations Lead (or interim coordinator) identifies all potential refuge sites (target 10, range 8–12): libraries, community centers, parish halls, sports halls, malls. Confirm facility ownership/management, current heating/cooling systems, accessibility status, available space for people and supplies, liability insurance, and facility-manager contact. Request provisional facility-use agreements from each site for the 5-month season (June–October, Months 6.8–11.8 = 2027-04-23 to 2027-09-30). Conduct preliminary accessibility audit checklist at each site.

**Responsible Body/Role:** Cooling-center Operations Lead (external candidate or interim coordinator from civil protection or public works) with support from municipal facilities/real-estate office.

**Suggested Timeframe:** By Month 1.2 (2026-11-14); provisional agreements signed by Month 1.5 (2026-11-23).

**Key Outputs/Deliverables:**

- List of 10 proposed cooling-center sites with location maps
- Preliminary facility-use agreements (draft or signed) with each site
- Accessibility audit checklist results for each site
- Summary of required fit-out work and estimated costs per site

**Dependencies:**

- Cooling-center Operations Lead designated or interim role established
- Steering Committee approved governance and alert model

### 12. GDPR legal lead and counsel finalize all template data-processing agreements and MOUs based on counsel's legal opinion (Month 1 = 2026-11-08). Make revisions per counsel advice. Prepare separate versions if needed for different partner types (housing associations may have different data-handling capacity than NGOs). Include: data scope, lawful basis, contact frequency, escalation rules, breach notification (≤48 hours), data deletion schedule (season end), staff confidentiality and training requirements. Distribute finalized DPAs to all identified partners by end of Month 1.3 (2026-11-17) with 2-week review/sign-off target (deadline Month 1.5 = 2026-11-23).

**Responsible Body/Role:** GDPR specialist legal counsel (external) and municipal legal lead (0.5 FTE), with input from incident commander and partner-liaison officer.

**Suggested Timeframe:** Finalized DPAs ready for partner distribution by Month 1.3 (2026-11-17); sign-off deadline Month 1.5 (2026-11-23).

**Key Outputs/Deliverables:**

- Finalized template DPAs incorporating counsel's legal opinion
- Version control and change-log for each DPA
- Covering letter explaining DPA to each partner
- DPA sign-off checklist and tracking log

**Dependencies:**

- GDPR counsel's legal opinion received (Month 1 = 2026-11-08)
- Partners identified and contact persons confirmed

### 13. HR coordinator conducts second-round interviews and makes job offers to selected candidates for Cooling Center Operations Lead, Outreach and Enrollment Lead, Transport Lead / Dispatch Coordinator, Home Kit Lead / Installation Coordinator, and Legal and GDPR Lead. Obtain signed offer letters and employment contracts. Agree start dates (target 50% by Month 1.8 = 2026-12-02, remainder by Month 2 = 2026-12-08). Conduct background checks, occupational health clearance and compliance documentation as required.

**Responsible Body/Role:** HR coordinator (0.5 FTE) and municipal HR director.

**Suggested Timeframe:** Offers made and accepted by Month 1.5 (2026-11-23); contracts signed by Month 1.7 (2026-11-29); start dates confirmed.

**Key Outputs/Deliverables:**

- Signed employment contracts or service agreements (5 lead roles)
- Background-check clearance confirmations
- Occupational health clearance or pre-employment health assessments
- Confirmed start dates and onboarding schedule

**Dependencies:**

- Recruitment interviews completed (Month 1.3–1.5 = 2026-11-17 to 2026-11-30)
- Budget authorization for salaries confirmed

### 14. Incident commander and partner-liaison officer conduct individual scoping meetings with each of the ≥4 identified intermediary partners. Agenda: (1) review partner's existing resident/client contact database and data-protection practices; (2) explain heat-response program goals and the intermediary-held list model (no city access to personal data); (3) present the data-processing agreement template and explain lawful basis for contact (public task / consent hybrid); (4) confirm partner's capacity to conduct phone outreach (call-list, staff, availability); (5) discuss escalation rules and partner feedback mechanism; (6) agree on pilot call targets and schedule for Month 2 (2026-12-08) mock-drill testing. Document all partner commitments and concerns.

**Responsible Body/Role:** Partner-liaison officer (newly hired, or interim coordinator if not yet in post) with incident commander.

**Suggested Timeframe:** Meetings held by Month 1.5 (2026-11-23); documented summaries by Month 1.7 (2026-11-29).

**Key Outputs/Deliverables:**

- Partner-scoping meeting notes (1 per partner)
- Partner capacity assessment and call-target agreement
- Escalation protocol and feedback mechanism agreed
- Partner sign-off on data-processing agreement (or issues flagged for resolution)

**Dependencies:**

- Introductory partner engagement completed (Month 0.8–1.2 = 2026-11-01 to 2026-11-14)
- DPA templates finalized and ready for partner review

### 15. Procurement specialist issues formal procurement notices for kits, handyperson services, and transport infrastructure. For fast-track items (kits, installation, phone systems), use framework call-offs or below-threshold purchasing routes per the approved procurement plan. Issue specification documents, evaluation criteria, and submission deadlines (target: bids due by Month 1.5 = 2026-11-23 for Month 1.7 = 2026-11-29 decision). For taxi/accessible-transport retainer, issue a small competitive RFQ or invite negotiation from 2–3 pre-qualified operators; aim to sign contract by Month 1.2 (2026-11-14) to lock in standby rates before summer demand.

**Responsible Body/Role:** Procurement specialist (0.5 FTE) with incident commander and relevant lead roles.

**Suggested Timeframe:** Notices issued by Month 1.3 (2026-11-17); bids received by Month 1.5 (2026-11-23); awards by Month 1.7 (2026-11-29).

**Key Outputs/Deliverables:**

- Procurement notices for kits, handyperson and phone-system items
- RFQ or invitation for transport retainer contract
- Bid evaluation reports and selection rationale
- Purchase orders or contract awards (pending final signatures)

**Dependencies:**

- Procurement specifications finalized (Month 0.8 = 2026-11-01)
- Budget allocation confirmed
- Steering Committee approval of procurement route

### 16. First operational meeting of the Heat Response Operations Team: Incident commander convenes public-health deputy, operations lead (civil protection), communications lead and partner-liaison officer (interim or newly hired). Agenda: (1) review alert thresholds and incident-command delegation; (2) confirm SITREP and briefing schedule (08:30 and 09:30 on alert days); (3) review public-communications plan and messaging templates; (4) review partner and cooling-center status; (5) establish daily decision-log and escalation hotline; (6) plan for Month 2 (2026-12-08) readiness-gate drills (phone line, outreach mock-calls). Publish operations team charter and meeting schedule to all staff and partners.

**Responsible Body/Role:** Incident commander (chair), with public-health deputy, operations lead, communications lead and partner-liaison officer.

**Suggested Timeframe:** Month 1.5 (2026-11-23).

**Key Outputs/Deliverables:**

- Heat Response Operations Team charter and ToR
- Standing meeting schedule (daily SITREP and 09:30 briefing on alert days, weekly on non-alert)
- Decision-log template and escalation protocol
- Communications-cadence and messaging templates (draft)

**Dependencies:**

- Incident commander and operations leads designated
- Alert thresholds and delegation finalized
- Steering Committee's first meeting held and decisions documented

### 17. All governance bodies now formally established submit their initial meeting minutes and charter documents to the Steering Committee. Legal lead conducts a compliance check: confirm all roles are filled (or interim assignments documented), all DPAs are signed or in final review, all procurement orders are placed, and all operational teams have published charters and meeting schedules. Incident commander submits a project-status dashboard showing: (1) governance bodies operational; (2) staffing progress (% of positions filled); (3) procurement status; (4) partner engagement status; (5) risks and corrective actions. This consolidated status report is reviewed at the Steering Committee's Month 2 (2026-12-08) meeting as part of the readiness-gate assessment.

**Responsible Body/Role:** Legal and GDPR Lead (0.5–1 FTE) with incident commander and PMO coordinator.

**Suggested Timeframe:** Compliance check completed by Month 1.8 (2026-12-02); status dashboard finalized by Month 2 (2026-12-08) readiness-gate meeting.

**Key Outputs/Deliverables:**

- Consolidated governance-body charter and ToR document (all bodies, 1 summary)
- Governance compliance checklist (roles filled, DPAs signed, procurement placed, operational charters published)
- Project-status dashboard (staffing %, procurement %, partner % engaged, risks and corrective actions)
- Month 2 (2026-12-08) readiness-gate evidence summary (centers ready, transport signed, phone line live, training completed, procurement ≥90% ordered)

**Dependencies:**

- All governance-body leads hired and in post or interim-assigned
- DPAs signed with all partners
- All procurement orders placed
- All governance bodies' first meetings held and documented

### 18. Cooling-center Operations Lead finalizes facility-use agreements with all 10 sites. Conduct a detailed accessibility audit at each site using a standardized checklist (wheelchair access, toilet facilities, water points, quiet/low-stimulus rooms, parking, emergency exits, first-aid kit availability, AED locations). Categorize sites as 'fully accessible' (no remediation needed) or 'minor modifications required' (≤€10k, ≤4 weeks). Issue remediation cost estimates and timelines for each site. Prioritize 5–6 fully accessible sites to open by June 1 (Month 6.8 = 2027-05-02). For sites requiring remediation, develop a schedule and budget authorization for work to complete by May 31.

**Responsible Body/Role:** Cooling-center Operations Lead with an accessibility consultant or municipal disability-access officer (advisory role).

**Suggested Timeframe:** Accessibility audit completed by Month 1.5 (2026-11-23); remediation plans finalized by Month 2 (2026-12-08).

**Key Outputs/Deliverables:**

- Detailed accessibility audit report for each of 10 sites
- Categorization of sites (fully accessible, minor remediation, unsuitable)
- Remediation cost estimates and timelines per site
- Site prioritization: 5–6 priority sites for June opening with no or minor work
- Approved remediation budget and schedule

**Dependencies:**

- Cooling-center Operations Lead hired and in post
- Provisional facility-use agreements signed (Month 1.5 = 2026-11-23)
- Accessibility consultant or municipal accessibility office engaged

### 19. Transport Lead (Dispatch Coordinator) begins volunteer-driver recruitment campaign targeting retirees, charity staff, faith-group members and community volunteers. Partner with NGOs, faith organizations, municipal community centers and local media to advertise. Accept applications from October through January (Months 0–3 = 2026-10-08 to 2027-01-08). Conduct vetting in monthly cohorts (background check, driving history, safeguarding screening, insurance verification). Target: 40 volunteer drivers (range 30–50), with ≥20 fully vetted and trained by Month 2 (2026-12-08), remainder by Month 3 (2027-01-08). Provide each volunteer with orientation on heat response, center locations, transport-request protocols, passenger safety and incident reporting.

**Responsible Body/Role:** Transport Lead / Dispatch Coordinator (external hire or interim coordinator from civil protection) with occupational health and volunteer-coordinator support.

**Suggested Timeframe:** Recruitment launched Month 0 (2026-10-08); applications accepted through January; vetting in batches (monthly cohorts beginning Month 1 = 2026-11-08); ≥20 fully trained by Month 2 (2026-12-08), remainder by Month 3 (2027-01-08).

**Key Outputs/Deliverables:**

- Volunteer-recruitment campaign flyers and social-media posts
- Volunteer application form and vetting checklist
- Batch 1 vetting results (background checks passed/failed) by Month 1.8 (2026-12-02)
- Volunteer driver insurance certificates and agreements
- Volunteer orientation and training schedule
- Volunteer roster with contact details and vehicle information

**Dependencies:**

- Transport Lead hired or interim role assigned
- Budget for volunteer expenses (mileage, fuel) and insurance confirmed

### 20. Outreach and Enrollment Lead develops heat-response outreach scripts (3–5 minute call format with escalation rules). Scripts should include: greeting and program introduction; identification of the resident's heat risk; description of cooling centers and transport support; consent confirmation for future contact; escalation triggers (signs of heat illness, social crisis, homelessness). Draft scripts in Spanish and test with focus groups of older residents (target: 10–15 participants) by Month 1.5 (2026-11-23) to confirm clarity, cultural appropriateness and acceptability. Incorporate feedback and finalize scripts by Month 1.8 (2026-12-02). Translate core scripts into 4–6 identified non-official languages by Month 2 (2026-12-08) and conduct language-group focus testing.

**Responsible Body/Role:** Outreach and Enrollment Lead (external hire or interim coordinator) with partner-liaison officer, public-health nurse adviser and community language ambassadors (as they are recruited).

**Suggested Timeframe:** Draft scripts Month 1 (2026-11-08); focus-group testing Month 1.3–1.5 (2026-11-17 to 2026-11-30); revisions and translations Month 1.5–2 (2026-11-30 to 2026-12-08).

**Key Outputs/Deliverables:**

- Heat-response call script (Spanish, v1.0)
- Focus-group testing notes and feedback
- Revised script incorporating feedback (v1.1)
- Escalation decision-tree and escalation script (when to call EMS, when to refer to nurse line)
- Scripts translated into 4–6 languages (draft versions for partner review)

**Dependencies:**

- Outreach and Enrollment Lead hired or interim role assigned
- GDPR legal review completed so scripts comply with consent and data-handling rules
- Community partners (focus groups) identified

### 21. Home Kit Lead develops a household-targeting rubric to identify homes eligible for the 2,000-kit program. Rubric scoring (0–100 points): top-floor or poor insulation = 30 points; age ≥75 (or 65+ with self-declared chronic condition) = 25 points; living alone = 20 points; built before 1980 = 15 points; no air-conditioning = 10 points. Eligibility threshold = ≥60 points. Validate rubric against a sample of 50–100 enrolled high-risk residents from partner contact lists to confirm sensitivity and specificity. Assess GDPR compliance (ensure rubric does not infer protected health data beyond what residents have consented to share). Finalize rubric by Month 1.8 (2026-12-02) and pilot the targeting process on a sample of 200 households by Month 2 (2026-12-08).

**Responsible Body/Role:** Home Kit Lead / Installation Coordinator (external hire or interim coordinator) with Outreach and Enrollment Lead and an equity analyst or data coordinator.

**Suggested Timeframe:** Draft rubric Month 1 (2026-11-08); validation and GDPR check Month 1.3–1.5 (2026-11-17 to 2026-11-30); finalized rubric Month 1.8 (2026-12-02); pilot targeting Month 2 (2026-12-08).

**Key Outputs/Deliverables:**

- Household-targeting rubric (scoring methodology, point weights, threshold)
- GDPR compliance assessment for rubric
- Validation-test results (sample of 50–100 households)
- Pilot-targeting report (200 households scored and prioritized)

**Dependencies:**

- Home Kit Lead hired or interim role assigned
- Enrolled high-risk resident data from outreach partners available
- GDPR legal review confirms data-handling scope

### 22. Incident commander and public-health deputy finalize the emergency-management operational structure in writing. Document: (1) alert-declaration process (forecast data receipt, threshold evaluation, decision authority, notification sequence); (2) daily SITREP and briefing schedule on alert days; (3) stand-down criteria and procedures (alert ends when forecast no longer meets thresholds and actual temperatures normal for 48 hours); (4) escalation hotline and incident-log procedures; (5) mutual-aid triggers with hospitals and EMS (e.g., notify at ≥1.5× historical average heat-related call volume); (6) handover coverage for multi-day events (backup incident commander, rotation of SITREP leads). Publish this as an operational playbook chapter. Conduct a tabletop scenario drill with the Operations Team (2 hours, Month 2 = 2026-12-08) to validate the process and identify gaps.

**Responsible Body/Role:** Incident commander with public-health deputy and operations lead (civil protection), supported by PMO coordinator.

**Suggested Timeframe:** Operational procedures documented by Month 1.8 (2026-12-02); tabletop drill conducted Month 2 (2026-12-08).

**Key Outputs/Deliverables:**

- Alert-declaration and operational procedures document (SOP, flowchart, decision tree)
- SITREP and briefing templates with sample data
- Stand-down criteria and notification procedure
- Mutual-aid trigger matrix (EMS/hospital notification thresholds)
- Tabletop scenario drill after-action report with lessons and corrective actions

**Dependencies:**

- Incident commander and operations leads designated
- Alert thresholds set and approved by Steering Committee
- Operations Team established and first meeting held

### 23. Procurement specialist places the first batch of purchase orders (30–40% of total kit volume, ≈600–800 kits) for cooling supplies (shading, fans, thermometers, hygrometers). Negotiate expedited delivery for February (Month 4 = 2027-02-08) to allow ≥6 weeks for installations before the first summer heat days (target June 1 = Month 6.8 = 2027-05-02). Lock in transport standby-retainer contract terms with taxi/accessible-transport operator if not already signed. Identify 2–3 backup suppliers for each kit category to mitigate supply-chain risk. Arrange secure interim storage (municipal facility or supply partner warehouse) for kits arriving in February–March.

**Responsible Body/Role:** Procurement specialist (0.5 FTE) with Home Kit Lead (once hired) and project coordinator.

**Suggested Timeframe:** First call-off orders placed by Month 1.2 (2026-11-14); transport contract signed by Month 1.2 (2026-11-14); backup suppliers identified by Month 1 (2026-11-08); storage arrangement confirmed by Month 1.5 (2026-11-23).

**Key Outputs/Deliverables:**

- Purchase orders for first kit batch (30–40% of 2,000 kits)
- Signed transport/taxi standby-retainer contract with pricing and performance terms
- Backup supplier contact list and pre-qualification documentation
- Storage facility agreement and inventory-management protocol

**Dependencies:**

- Procurement specs finalized and RFQs issued (Month 0.8–1 = 2026-11-01 to 2026-11-08)
- Supplier bids evaluated and awards recommended (Month 1.5 = 2026-11-23)
- Budget authorization for purchase orders confirmed

### 24. Conduct a formal, comprehensive Steering Committee meeting (Month 2 = 2026-12-08) to review and make a go/no-go decision on the Month 2 (2026-12-08) readiness gate. Gate criteria: (1) ≥8 of 10 cooling-center sites signed with named managers; (2) ≥50% of places in fully accessible sites; (3) transport retainer contract signed; (4) ≥20 volunteer drivers vetted; (5) heat helpline live (08:00–22:00 daily, 24-hour at Level 3) with a successful mock drill (5–8 simulated calls, ≥3 escalations handled correctly); (6) outreach training delivered to 50–80 partner and street-contact staff with ≥80% attendance and pass score; (7) 100% of tranche-1 procurement orders placed. Incident commander presents evidence for each criterion. Committee votes to pass, pass-with-conditions or fail, and approves any corrective actions if gate is not fully passed. Document decision.

**Responsible Body/Role:** Heat Response Steering Committee (majority vote, quorum 4 of 6 including Chair or Vice-Chair), with incident commander and lead-role representatives presenting evidence.

**Suggested Timeframe:** Month 2 (2026-12-08), scheduled 1 week in advance.

**Key Outputs/Deliverables:**

- Readiness-gate evidence summary (1-pager per criterion with supporting data)
- Heat helpline mock-drill after-action report
- Outreach training attendance and assessment results
- Procurement status and order-confirmation list
- Steering Committee decision minutes with formal vote
- Go/no-go approval for proceeding to Month 4 (2027-02-08) scale gate and full operations

**Dependencies:**

- All governance bodies operational and reporting metrics
- Cooling centers, transport, phone line and outreach staff in place
- Mock drills and training completed
- Procurement ≥90% ordered

### 25. Immediately after Month 2 (2026-12-08) readiness gate (whether passed or conditional), Evaluation Lead and university evaluation partner finalize the evaluation design and pre-register the analysis plan. Specify: baseline heat-related EMS and ED counts (obtained from hospitals by Month 1 = 2026-11-08, quality audited by Month 1.5 = 2026-11-23); comparison methodology (pilot vs. matched districts and prior years, aggregate counts only, no identifiable records); temperature-adjustment method; confidence-interval reporting; and plain-language statement of attribution limits. Data-processing agreement with hospitals, EMS and primary care is finalized; daily aggregate-count delivery test (validation pilot) scheduled for April (Month 6 = 2027-04-08). University partner publishes the pre-registered protocol on a registry (e.g., OSF) by Month 3 (2027-01-08).

**Responsible Body/Role:** Evaluation Lead (0.5–1 FTE, municipal or partner) and university evaluation partner (external, ≈€50k–80k contract).

**Suggested Timeframe:** Evaluation design finalized by Month 2.5 (2026-12-23); pre-registered protocol published by Month 3 (2027-01-08).

**Key Outputs/Deliverables:**

- Finalized evaluation design document (comparison groups, statistical methods, attribution approach)
- Data-processing agreement with hospitals/EMS/primary care
- Pre-registered analysis plan (published on OSF or registry)
- Baseline data-quality report and any limitations or caveats
- Data-sharing infrastructure test plan (validation pilot for April)

**Dependencies:**

- Baseline EMS and ED data obtained and quality-audited (Months 0–1 = 2026-10-08 to 2026-11-08)
- University evaluation partner contracted and data-processing agreement signed
- Steering Committee approved the evaluation scope

### 26. Recruit, vet and begin training 8–12 community-language ambassadors from identified migrant associations and communities. Ambassadors will be paid part-time staff (≈10–15 hours/week during alert season) responsible for: translating and culturally adapting materials; co-delivering phone-line interpretation support; accompanying door-knock teams in their own languages; staffing cooling-center welcome desks; and conducting focus-group testing of heat messages. Launch recruitment by Month 1 (2026-11-08) with a target start date of Month 1.8 (2026-12-02). Conduct vetting (background check, reference checks) and onboarding by Month 2 (2026-12-08). Provide ambassadors with a 2-day orientation on heat illness, program goals, escalation rules and confidentiality by Month 2.5 (2026-12-23).

**Responsible Body/Role:** Outreach and Enrollment Lead with partner-liaison officer and community association representatives.

**Suggested Timeframe:** Recruitment launched Month 1 (2026-11-08); ambassadors hired and onboarded by Month 2 (2026-12-08); orientation and training Month 2–2.5 (2026-12-08 to 2026-12-23).

**Key Outputs/Deliverables:**

- Ambassador recruitment flyers in community languages and via partner channels
- Ambassador job descriptions and role expectations
- Selected ambassador list with language coverage and community affiliations
- Background-check and reference-check documentation
- Ambassador orientation and training materials (translated)
- Signed ambassador agreements and NDA/confidentiality documents

**Dependencies:**

- Outreach and Enrollment Lead hired
- Target language groups identified (4–6 languages by Month 0 = 2026-10-08)
- Migrant community associations or NGO partners engaged
- Budget for ambassador stipends and training confirmed

### 27. Legal lead convenes a partner compliance-and-briefing session with representatives from all ≥4 key intermediary partners (housing associations, social services, NGOs, pharmacies). Agenda: (1) present the finalized data-processing agreements and obtain signatures if not yet signed; (2) brief all partner staff on GDPR obligations, data-protection rules, confidentiality and incident-reporting procedures; (3) distribute outreach scripts, escalation protocols and call-logging templates; (4) confirm partner call-target commitments for the remainder of the season; (5) establish weekly/bi-weekly partner-liaison contact schedule; (6) answer partner questions on consent, data-handling and liability. Document attendance and sign-off from each partner. Provide partners with training materials (slide deck, handout) and digital resources (template call logs, escalation guides).

**Responsible Body/Role:** Legal lead (0.5–1 FTE) with Outreach and Enrollment Lead, partner-liaison officer and GDPR counsel (advisors).

**Suggested Timeframe:** Briefing session conducted by Month 2 (2026-12-08); attendance confirmation and sign-off by Month 2.5 (2026-12-23).

**Key Outputs/Deliverables:**

- Signed data-processing agreements from all partners (or documented timeline for final signature)
- GDPR and confidentiality briefing slides and handout materials
- Outreach script and escalation protocol distributed to all partner staff (attendance log)
- Call-logging template and incident-reporting form provided to partners
- Partner commitment letter (call targets, data-handling, escalation)
- Weekly liaison contact schedule published

**Dependencies:**

- DPA templates finalized and customized per partner type (Month 1.3 = 2026-11-17)
- Partners have reviewed DPAs and provided feedback
- Outreach scripts and escalation protocols finalized (Month 1.8 = 2026-12-02)
- Legal lead and GDPR counsel available for briefing

### 28. Heating-systems and procurement coordinator confirms the delivery schedule and logistics for the first batch of cooling kits (30–40% of 2,000, ≈600–800 kits ordered at Month 1.2 = 2026-11-14). Negotiate expedited shipping for February arrival. Arrange intake inspection and inventory verification upon delivery. Set up secure interim storage with climate control (to prevent fan degradation) and an inventory-management system (tracking kit location, condition, hand-off to installers). Prepare a kit-distribution protocol: priority allocation to highest-scoring households (from Home Kit Lead's targeting rubric), geographic batching by neighborhood for installer efficiency, and consent verification before each household's installation is scheduled.

**Responsible Body/Role:** Procurement specialist (0.5 FTE), Home Kit Lead and logistics coordinator (may be shared with general municipal logistics).

**Suggested Timeframe:** Delivery logistics finalized by Month 2 (2026-12-08); storage facility prepared by Month 3 (2027-01-08); first kits received ≈Month 4 (2027-02-08).

**Key Outputs/Deliverables:**

- Kit delivery schedule and shipment confirmations
- Storage facility access and inventory-management protocol
- Kit-distribution sequencing and neighborhood/household priority list
- Installation-scheduling process (consent verification, scheduling letters to residents)
- Inventory-tracking system and daily intake log

**Dependencies:**

- Purchase order for first kit batch placed (Month 1.2 = 2026-11-14)
- Storage facility identified and contracted (Month 1.5 = 2026-11-23)
- Home Kit Lead hired and targeting rubric finalized (Month 1.8 = 2026-12-02)

### 29. Establish the heat-response phone line and dispatch-coordination system. Procure or configure telephony infrastructure (dedicated phone line, call queuing, call recording if permitted by Spanish law, call transfer to interpretation services). Set up call-tracking software (shared spreadsheet with partner-liaison officer, or a secure cloud platform) to log all incoming calls, resident details, requests, responses and escalations. Recruit 2–3 FTE phone-line operators (1 permanent + 1–2 surge/part-time) by Month 1.8 (2026-12-02). Conduct training (call scripts, escalation triggers, de-escalation, interpreter coordination, incident reporting) by Month 2.5 (2026-12-23). Conduct a 4–6 hour mock-call drill with 5–8 simulated calls including escalation cases (heat illness, social crisis) by Month 2.5 (2026-12-23) and document results.

**Responsible Body/Role:** Outreach and Enrollment Lead (phone-line owner) with transport lead (for dispatch coordination), PMO coordinator and occupational health.

**Suggested Timeframe:** Telephony infrastructure procured and installed by Month 1.8 (2026-12-02); operators hired by Month 1.8 (2026-12-02); training and mock drill completed by Month 2.5 (2026-12-23); system live and operational by Month 2 (2026-12-08) readiness gate.

**Key Outputs/Deliverables:**

- Phone-line setup with call-queuing and escalation features (tested)
- Call-tracking system (spreadsheet template or platform)
- Trained phone-line operators (employment contracts, training certificates)
- Call-handling and escalation SOP
- Mock-call drill report (5–8 simulated calls, ≥3 escalations, success rate ≥80%)
- Go-live checklist and 24-hour on-call support plan

**Dependencies:**

- Budget for phone-line setup and operators confirmed
- Outreach scripts and escalation protocols finalized
- Interpretation services contract signed (external provider or municipal arrangement)

### 30. Recruit, vet and begin training handypersons (target 10 FTE for Months 4–7 = 2027-02-08 to 2027-05-17) responsible for installing cooling kits (exterior shading, fans, thermometers). Vet candidates for occupational health and safety certification (or willingness to obtain it), relevant trade experience, background check and occupational-health clearance. Provide each handyperson with a 1-day safety-and-installation training covering: (1) electrical safety and fan-installation safety; (2) fan-use guidance for residents (directional airflow, outdoor-air intake); (3) shading and wind-resistance assessment; (4) building-code compliance checks; (5) customer communication and consent; (6) incident reporting and feedback. Training conducted by Month 3.5 (2027-01-23). Arrange tools, equipment and safety gear by Month 3 (2027-01-08). Finalize handyperson employment or contract terms by Month 3 (2027-01-08) with start date ≥Month 4 (2027-02-08).

**Responsible Body/Role:** Home Kit Lead / Installation Coordinator with occupational health and a qualified trades supervisor or external training provider.

**Suggested Timeframe:** Recruitment launched Month 2 (2026-12-08); hiring completed by Month 2.8 (2027-01-01); training conducted Month 3–3.5 (2027-01-08 to 2027-01-23).

**Key Outputs/Deliverables:**

- Handyperson job description and qualification criteria
- Recruitment announcements and applications (target 10 FTE)
- Vetting documentation (background checks, trade certifications, occupational-health clearance)
- Handyperson employment or service contracts (10)
- 1-day safety-and-installation training curriculum and materials
- Training attendance and assessment results (target ≥80% pass)
- Handyperson roster, contact details and insurance information

**Dependencies:**

- Home Kit Lead hired
- Budget for handyperson wages/contracts confirmed
- Kit components and installation specifications finalized
- Occupational health and safety requirements confirmed

### 31. PMO coordinator drafts the full-system operational drill protocol for Month 3.2 (2027-01-14). Drill will simulate a Level 2 or Level 3 alert lasting 4–6 hours, activating all systems: cooling centers open to full capacity, transport dispatch handles ≥30 simulated requests (including ≥5 wheelchair-user priority cases targeting 30-min pickup), outreach phone line receives ≥20 calls (mixture of enrollment inquiries, requests for transport, escalation cases), and all partner outreach staff place sample calls (≥300 attempts across all partners). Drill will test: center staffing and operations readiness, accessibility compliance, transport dispatch speed and volunteer/taxi coordination, phone-line call handling and escalation, heat-illness recognition and EMS escalation, and inter-organizational communication. Draft evaluation checklist and success criteria (80% center hours, 60% outreach success, <45 min transport time). Publish protocol to all participants by Month 2.5 (2026-12-23).

**Responsible Body/Role:** PMO coordinator (project manager) with incident commander, Cooling-center Operations Lead, Transport Lead, Outreach Lead and all governance-body leads.

**Suggested Timeframe:** Draft protocol completed by Month 2.5 (2026-12-23); drill conducted Month 3.2 (2027-01-14); after-action report completed by Month 3.5 (2027-01-23).

**Key Outputs/Deliverables:**

- Detailed drill protocol (scenario, timeline, participant roles, success criteria)
- Drill evaluation checklist and gate-metric data-collection forms
- Participant briefing and instructions (distributed to all staff and partners)
- Drill execution log (timeline of events, decisions, issues noted)
- Drill after-action report (center-hours delivered, outreach contact success rate, transport response times, escalation cases handled correctly)
- Corrective-action list with owners and completion deadlines

**Dependencies:**

- All governance bodies operational and reporting metrics
- Alert thresholds, operational procedures and escalation protocols finalized
- Cooling centers, transport, phone line and outreach staff in place or nearly in place

### 32. Conduct the full-system operational drill on a specified date (Month 3.2 = 2027-01-14) with all governance bodies and operational teams activated. Incident commander declares a simulated Level 2 alert (forecast high ≥35°C and low ≥22°C for 2 consecutive days). Operations Team convenes at 07:00, SITREP at 08:30, partner briefing at 09:30. Cooling centers open their doors at 10:00 with full staffing; transport dispatch stands by with volunteer drivers and taxi operator on standby; phone line opens at 08:00 with operators and (if possible) live interpretation services. Outreach partners place sample calls (target ≥300 attempts across all partners, ≥60% connection success rate). Transport requests are generated (target ≥30 requests, ≥5 wheelchair-user priority cases). After 4–6 hours of continuous operation, incident commander declares stand-down at 16:00. All teams complete incident logs and action-item forms. A debrief is held the same day (17:00–18:30) with all lead roles present.

**Responsible Body/Role:** Incident commander (exercise controller) with Heat Response Operations Team, all governance-body leads and operational staff (Cooling-center managers, transport dispatchers, phone-line operators, outreach partners).

**Suggested Timeframe:** Drill conducted Month 3.2 (2027-01-14); debrief completed same day; after-action report drafted within 3 days (by Month 3.3 = 2027-01-17).

**Key Outputs/Deliverables:**

- Drill execution log with timeline and decision record
- Center-hours delivered by site (target ≥80% of planned hours)
- Outreach contact attempts and success rates by partner (target ≥60%)
- Transport requests received, response times and wheelchair-user accommodation (target <45 min average, <30 min for priority cases)
- Heat-illness and escalation cases handled (number and outcome)
- Debrief notes and participant feedback
- Incident log of issues, gaps and corrective actions

**Dependencies:**

- Drill protocol finalized and distributed to all participants
- All operational systems (phone line, cooling centers, transport dispatch) live and tested
- Cooling-center staff, transport dispatchers and operators trained and on-call

### 33. Incident commander and key leads review drill after-action report (completed Month 3.5 = 2027-01-23) and identify all corrective actions needed before the Month 4 (2027-02-08) scale gate. Corrective actions fall into categories: (1) staffing gaps (additional operators, volunteers, center support staff); (2) procedural improvements (revised escalation rules, faster transport routing); (3) technology fixes (phone-line call queuing, dispatch software); (4) training needs (repeat training for staff who did not meet standards). Assign owner and completion deadline (target ≤Month 3.8 = 2027-02-01, within 2 weeks of drill debrief) for each action. Close-out checklist confirms all actions are verified complete by Month 3.9 (2027-02-04). Document closure with evidence (training records, system logs, staffing confirmations).

**Responsible Body/Role:** PMO coordinator (action-tracking owner) with incident commander and all governance-body leads who own specific corrective actions.

**Suggested Timeframe:** After-action report completed Month 3.5 (2027-01-23); corrective-action plan finalized Month 3.6 (2027-01-26); actions executed and closed by Month 3.9 (2027-02-04).

**Key Outputs/Deliverables:**

- Corrective-action list with owners, deadlines and completion evidence
- Staffing adjustments (additional hires or schedule changes) documented
- Revised procedures or escalation rules published to all staff
- Technology fixes or system improvements validated
- Repeat training or skill assessments completed and documented
- Closure checklist signed off by each action owner

**Dependencies:**

- Drill after-action report completed and shared with all leads
- Sufficient budget and staffing flexibility to execute corrective actions
- Steering Committee monitoring of closure status

### 34. Conduct the Steering Committee's Month 4 (2027-02-08) scale-gate review and funding-release decision. Incident commander presents comprehensive evidence for the four scale-gate criteria: (1) ≥80% of planned cooling-center hours delivered in the drill; (2) ≥60% contact success from ≥300 outreach attempts; (3) mean transport time <45 min over ≥30 requests (including ≥5 wheelchair users); (4) 100% of after-action corrective actions from the drill closed and verified. Additionally present: status of kit procurement and delivery (target ≥40% by Month 4 = 2027-02-08), handyperson training completion (all 10 trained and on-contract), partner compliance audit (GDPR, call-logging, data protection). If all criteria are met, Committee formally approves the release of the full €1.5M tranche-2 funding. If 1 criterion fails but evidence is incomplete (e.g., insufficient natural heat events by Month 4 = 2027-02-08 to validate gates in real conditions), Committee approves conditional release: €750k (50%) immediately, remainder after a re-test in Month 5 (2027-03-08) using real-world heat data. If 2+ criteria fail, Committee does not release tranche-2; corrective actions and re-test planned for Month 5 (2027-03-08) at the earliest. Document formal vote and decision.

**Responsible Body/Role:** Heat Response Steering Committee (majority vote, quorum 4 of 6 including Chair or Vice-Chair), with incident commander and governance-body leads presenting evidence.

**Suggested Timeframe:** Month 4 (2027-02-08), scheduled at least 1 week in advance; decision documented same day.

**Key Outputs/Deliverables:**

- Scale-gate evidence package (center hours, outreach success rate, transport response times, corrective-action closure, kit procurement status)
- Steering Committee meeting minutes with formal vote on each criterion
- Formal funding-release decision letter or memo (full release, conditional release, or no release)
- Communiqué to all staff and partners confirming gate decision and next steps

**Dependencies:**

- Drill completed and after-action report finalized (Month 3.5 = 2027-01-23)
- All corrective actions closed and verified (Month 3.9 = 2027-02-04)
- Kit procurement on track (≥40% delivered or in-transit by Month 4 = 2027-02-08)
- Handyperson recruitment and training completed

### 35. Following the Month 4 (2027-02-08) scale-gate decision (whether full, conditional or no release), the Steering Committee formally approves and the incident commander confirms the operational readiness of all governance bodies to enter the live operational season (Months 6.8–11.8 = 2027-04-23 to 2027-09-30). Each governance body lead submits a readiness certification covering: (1) staffing (all roles filled, trained, on-call rosters confirmed); (2) systems (phone line, dispatch, cooling centers, partner call-tracking operational and tested); (3) supplies (kits in storage or arriving, handyperson ready to deploy, shelter supplies stocked); (4) protocols (escalation, GDPR, incident reporting, stand-down all documented and drilled); (5) partner commitment (all intermediaries' MOUs signed, staff trained, call targets confirmed). Incident commander and Steering Committee Chair sign off on the overall go-live. A public announcement and pre-season communications campaign (flyers, radio, pharmacy posters, community briefings) launch by Month 6.5 (2027-04-23).

**Responsible Body/Role:** Incident commander and all governance-body leads, with Steering Committee Chair oversight.

**Suggested Timeframe:** Readiness certifications submitted by Month 4.5 (2027-02-23); Steering Committee review and go-live approval by Month 5 (2027-03-08).

**Key Outputs/Deliverables:**

- Readiness certification from each governance body (staffing, systems, supplies, protocols, partner commitment)
- Consolidated operational-readiness checklist
- Steering Committee formal approval and go-live authorization
- Public announcement of program launch (press release, municipal website, social media)
- Pre-season campaign materials (flyers, radio spots, pharmacy posters, community briefings)

**Dependencies:**

- Month 4 (2027-02-08) scale-gate decision made and communicated
- All staffing hired and trained
- All systems tested and operational
- Cooling-center accessibility audit and remediation completed
- Kit procurement and handyperson training on schedule

### 36. From Month 5 onward (2027-03-08), governance bodies transition from setup and gate-preparation mode to regular operational reporting and rhythm. Monthly Steering Committee meetings (standing: first Monday of each month 14 = 2027-12-08:00, Months 5–12 = 2027-03-08 to 2027-10-08) review: (1) financial forecasts and budget burn; (2) staffing and fatigue status; (3) partner engagement and capacity; (4) procurement delivery status; (5) risk register; (6) preparation for summer season (June–September). Operations Team maintains weekly meetings on non-alert days (Mondays 14:00, Months 5–8 = 2027-03-08 to 2027-06-08) and daily standups with SITREP (08:30) and partner briefing (09:30) during any alert periods. Sub-groups (Cooling Centers, Outreach, Transport, Home Kits) establish their own meeting cadences: Cooling Centers weekly (Tuesdays 14:00 during setup, transitioning to ad-hoc during season); Outreach weekly (Wednesdays 14:00, then daily during alert days); Transport weekly (Thursdays 14:00, then daily during alerts); Home Kits weekly (Mondays 10:00 during installation phase = Months 4–7 = 2027-02-08 to 2027-05-17). Data and evaluation group meets monthly (Fridays 14:00).

**Responsible Body/Role:** Incident commander (chair of Operations Team), Steering Committee members, and all governance-body leads.

**Suggested Timeframe:** Governance transition to regular rhythm by Month 5 (2027-03-08); sustained through end of project Month 12 (2027-10-08).

**Key Outputs/Deliverables:**

- Monthly Steering Committee meeting calendar and standing agendas published
- Weekly Operations Team and sub-group meeting schedules published
- Meeting-cadence documentation in the operational playbook
- Monthly financial and risk-management dashboards prepared by PMO for Steering Committee review
- Weekly operations summaries (for non-alert weeks) shared with stakeholders

**Dependencies:**

- All governance bodies established and leads in post
- Operational systems live and stable
- Financial and staffing tracking systems operational

### 37. From Month 8 onward (2027-06-08), the Evaluation Lead, data analyst and university evaluation partner begin drafting the final Heat Response Playbook, cost model, and evaluation report. Playbook chapters include: (1) strategic decisions and rationale (Alert Trigger Ladder, Refuge Network, Intermediary-Held Lists, Mobility Support, Command Structure, Home Kits, Health Integration, Worker Protection, Communications, Language Access, Evaluation); (2) SOPs and checklists (alert declaration, cooling-center operations, transport dispatch, phone-line handling, escalation, de-escalation, incident reporting, stand-down); (3) procurement and staffing templates (job descriptions, supplier specs, contract terms, partner MOUs); (4) lessons learned and adaptations (what worked, what was hard, what to change for Year 2); (5) unit costs and scaling assumptions (€ per person enrolled, per center-hour, per kit, per transport trip, per staff FTE). University partner analyzes operational and outcome data (EMS, ED, mortality proxies) against the pre-registered protocol. Playbook draft shared with peer EU cities for comment by Month 11 (2027-09-08); final version and evaluation report delivered by Month 12 (2027-10-08).

**Responsible Body/Role:** Evaluation Lead (0.5–1 FTE) with Playbook Editor (may be Evaluation Lead or separate role), university evaluation partner, and incident commander/governance leads (content contributors).

**Suggested Timeframe:** Playbook drafting begins Month 8 (2027-06-08); section drafts submitted by Month 10 (2027-08-08); peer-city review Month 11 (2027-09-08); final version Month 12 (2027-10-08).

**Key Outputs/Deliverables:**

- Heat Response Playbook (draft Months 8–10 = 2027-06-08 to 2027-08-08, final Month 12 = 2027-10-08)
- Scaling cost model with unit costs and assumptions
- Data and evaluation report (preliminary by Month 11 = 2027-09-08, final Month 12 = 2027-10-08)
- Year-2 roadmap (expansion priorities, elements to discontinue, estimated budget for Year 2)
- Lessons-learned and adaptation summary

**Dependencies:**

- Operational data collected throughout Months 6–11 (2027-04-08 to 2027-09-08) (center hours, outreach attempts/success, transport times, kit installations)
- Health-system outcome data (EMS, ED, mortality) collected and analyzed
- University evaluation partner data analysis complete
- All governance bodies document their decision-making and challenges for playbook lessons-learned section

### 38. Conduct a final Steering Committee meeting (Month 12 = 2027-10-08) to review and formally approve the Heat Response Playbook, scaling cost model, evaluation report and Year-2 roadmap for public release. Committee considers: (1) Are the lessons learned and adaptations clearly documented? (2) Is the cost model transparent and defensible for other EU cities? (3) Are attribution caveats and limitations honestly stated? (4) Is the Year-2 roadmap realistic and funded? Committee votes to approve for publication. Incident commander prepares a final project close-out report (budget reconciliation, staffing outcomes, partner feedback, next-steps). A final debrief meeting is held with all governance-body leads and key partners to capture verbal feedback and recognize contributions. Public launch event (press conference, municipal briefing, dissemination to peer cities and EU networks) scheduled for Month 12 (2027-10-08) or soon after.

**Responsible Body/Role:** Heat Response Steering Committee (majority vote), with incident commander, Evaluation Lead and playbook editor presenting final deliverables.

**Suggested Timeframe:** Final Steering Committee meeting Month 12 (2027-10-08); public launch by end of Month 12 (2027-10-08) or early Month 13 (2027-11-08).

**Key Outputs/Deliverables:**

- Steering Committee formal approval of Playbook, cost model, evaluation report and Year-2 roadmap (meeting minutes with vote)
- Final project close-out report (budget reconciliation, staffing, partner feedback, lessons learned)
- Public-release press release and communications pack
- Heat Response Playbook published (PDF and possibly online portal)
- Scaling cost model published with replicability guidance for other EU cities
- Evaluation report published with peer-reviewed or audited findings
- Year-2 roadmap and funding proposal (if applicable)
- Final debrief meeting minutes and participant feedback

**Dependencies:**

- All draft deliverables (Playbook, cost model, evaluation report, roadmap) completed and reviewed by Steering Committee by Month 11 (2027-09-08)
- Peer-city feedback incorporated (Month 11 = 2027-09-08)
- University evaluation partner's final report submitted
- Budget reconciliation and staffing outcomes documented