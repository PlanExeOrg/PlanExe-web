# Documents to Create

## Create Document 1: Heat Response Program Charter

**ID**: 0bcf463d-731c-446f-9d67-733e1f376c31

**Description**: Project charter defining goals, scope, constraints, stakeholders, and governance structure for the 12-month municipal heatwave-response pilot in Castellón de la Plana. Establishes authority, budget, timeline, and decision-making framework. Audience: city leadership, funder, partners, operational team.

**Responsible Role Type**: Project Manager / PMO Lead

**Primary Template**: PMI Project Charter Template

**Secondary Template**: EU Public Health Program Charter

**Steps to Create**:

- Synthesize project brief and SMART criteria into a one-page executive summary.
- Define scope: 10 cooling refuges, 40 volunteer drivers + taxi retainer, 5,000 outreach contact attempts, 2,000 home kits, health-data loop, worker protection, communications.
- Specify hard constraints: €3.5M cap, 12-month duration, no new legislation, GDPR limits, no major construction.
- List four scale gates (Month 4 = 2027-02-08): 80% center hours, 60% outreach success, <45-min transport, after-action closure.
- Name incident commander (mayor's office), public-health deputy, operations lead, communications lead, partner-liaison officer.
- Obtain signatures from mayor, funder representative, and incident commander by Month 0.5 (2026-10-23).

**Approval Authorities**: Mayor's office, funder, incident commander, public-health department director

**Essential Information**:

- Define the 12-month pilot scope in Castellón de la Plana: ~10 cooling refuges, 40 volunteer drivers + taxi backup, 5,000 outreach contact attempts, 2,000 home kits, health-data coordination, worker protection and multilingual communications.
- Establish hard constraints: €3.5M total cap (€2.0M initial, €1.5M conditional at Month 4 = 2027-02-08), no new legislation, GDPR compliance limits, no major construction, realistic hireable staffing.
- Specify the four scale gates (Month 4 = 2027-02-08): (1) ≥80% of planned cooling-center hours delivered; (2) ≥60% outreach contact success from ≥300 attempts; (3) mean pickup time <45 minutes over ≥30 requests including wheelchair users; (4) after-action report completed with 100% of corrective actions closed.
- Name the incident-command structure: mayor's office incident commander with public-health deputy, civil-protection operations lead, municipal communications lead, partner-liaison officer. Obtain written mayoral delegation of authority by Month 1 (2026-11-08) specifying trigger thresholds and backup authority.
- List critical dependencies: GDPR counsel opinion and partner data-processing agreements by Month 1.5 (2026-11-23); all procurement orders (kits, transport retainer, refuge fit-out, handyperson services) by Month 2 (2026-12-08); staff and volunteer vetting completed by Month 2 (2026-12-08); hospital/EMS aggregate-data MOU by Month 1 (2026-11-08).
- Define the readiness gate criteria (Month 2 = 2026-12-08): ≥8 of 10 sites contracted and staffed; ≥50% places fully accessible; transport retainer and ≥20 volunteer drivers vetted; heat helpline live and tested; all staff and partner training ≥80% complete; all tranche-1 procurement orders placed.
- Specify budget allocation across categories: Refuge network €850k; Transport €380k; Outreach/phone/street €450k; Home kits €800k; Health coordination €120k; Worker protection €50k; Communications/language €170k; Governance/PMO/legal/evaluation/playbook €400k; Contingency €280k (8% reserve).
- Set contingency-funding rules for gate failure or measurement uncertainty: failed gate = no release; unmeasurable/insufficient evidence (e.g. cool-season heat events absent) = €750k (50%) released at Month 4 (2027-02-08) with remainder after Month 5 (2027-03-08) re-test.
- Identify funding gaps and Year-2 sustainability: Year-2 recurring cost ≈€2.3M estimated for same footprint; funding source not identified. Taxi-only fallback scenario (+€150-250k) requires €40-240k above the €160k tranche-1 contingency if also paired with delayed-release cash gap.
- Establish the drill-and-rehearsal schedule: full-system drill Month 3.2 (2027-01-14); after-action corrective actions closed by Month 3.9 (2027-02-04); gate decision Month 4 (2027-02-08); second drill, transport stress test and stand-down drill by Month 7 (2027-05-08) before peak summer.

**Risks of Poor Quality**:

- Ambiguous or missing incident-command authority delays alert declarations by 6-12 hours during critical heat events, losing response time. Politicized or unsigned delegation invites legal challenge to alert decisions, undermining credibility with partners and the public.
- Incomplete or vague scope definition (unclear refuge footprint, transport capacity or outreach target groups) causes rework in procurement, hiring and partner contracting. Estimated delay: 2-4 weeks into the operational period; cost impact: €50-150k in expedited hiring or procurement.
- Unspecified gate criteria or measurement rules (e.g., unclear what constitutes ≥80% center hours or how to measure during a cool season) create disputes over funding release and erode funder and stakeholder confidence. Exposure: €1.5M release withheld or delayed by 4-8 weeks.
- Missing or incomplete budget allocation across workstreams creates mid-project conflicts over resource prioritization. If transport retainers or kit procurement are under-resourced, the program will fail gates (45-minute transport target, home-intervention coverage) and revert to lower-cost but less effective alternatives.
- Unclear staffing plan (FTE numbers, hiring timeline, role responsibilities, fatigue protocols) causes operational gaps during multi-day heat-wave surges. Centers close early or operate at reduced hours, phone line experiences long waits, transport dispatch slows. Estimated reach loss: 10-25% reduction in service capacity; staff turnover and burnout cost €10-20k per person.
- Weak or missing contingency-funding rules expose the program to €200-400k cash-flow gap if the Month 4 (2027-02-08) gates cannot be measured fairly (e.g., cool-season heat events absent) or are failed. Forced mid-summer contraction or project suspension damages equity, media credibility and partner trust.
- Unspecified GDPR and data-protection milestones or oversight mechanisms allow partners to proceed without clear lawful basis for outreach contact. Data regulator challenge or partner breach mid-season could halt outreach operations and reduce enrollment reach by 10-20%, failing the 60% contact-success gate.
- Absent or incomplete critical-path dependencies (e.g., procurement timelines, volunteer-vetting processes, facility-fit-out schedules) mean Month 2 (2026-12-08) readiness gate may be missed. Kit delivery slips beyond April, home interventions begin 4-8 weeks late, missing early-May heat events. Estimated mortality-impact loss: 15-25%.

**Worst Case Scenario**: The Heat Response Program Charter is not created, or is created with significant gaps and ambiguity. Result: At Month 1 (2026-11-08), the team lacks a written reference point for scope, authority and decision rules. Incident-command authority is unclear, GDPR compliance strategy is unsigned, and procurement does not proceed on time. The Month 2 (2026-12-08) readiness gate is missed by 3-4 weeks due to delayed contracting and staffing. By Month 4 (2027-02-08), facilities are not fully operational, volunteer drivers are under-vetted, and kits have not arrived. June heat events occur (or a drill is conducted), and gates are failed or unmeasurable due to incomplete preparation. The funder withholds the €1.5M release pending a re-test. By August (peak-risk period), the program is underfunded and contracted back to 3-4 refuges and minimal transport capacity. Vulnerable residents dependent on cooling centers and transport find services unavailable or degraded. Media reports elderly deaths during a heat wave, blaming failed program response. Political accountability questions undermine the playbook's credibility and scaling prospects. Year-2 funding is not approved, and the pilot closes. Estimated financial impact: €300-600k wasted; estimated excess mortality unpreventd: 5-15 additional heat-related deaths; reputational cost: program cited as cautionary example in EU heat-response discussions.

**Best Case Scenario**: The Heat Response Program Charter is completed by Month 0.5 (2026-10-23) with clear, authoritative definitions of scope, constraints, governance, gates and contingencies. The charter is signed by the mayor, funder and incident commander, establishing binding commitment and decision-making authority. Result: By Month 1 (2026-11-08), mayoral delegation is in place, GDPR counsel opinion is obtained and partner MOUs are drafted. Procurement proceeds on time; kits and transport contracts are ordered by Month 1.5-2 (2026-11-23 to 2026-12-08). Staff hiring follows the staggered schedule; volunteer recruitment yields 35+ drivers by Month 2 (2026-12-08). The Month 2 (2026-12-08) readiness gate is passed on schedule with all refuges contracted, staffed and accessible, phone line live and tested, and all procurement orders placed. A full-system drill in January (Month 3.2 = 2027-01-14) demonstrates operational readiness; after-action corrective actions are closed by Month 3.9 (2027-02-04). At Month 4 (2027-02-08), gates are measured via combined drill data and early summer heat events (or contingency re-test rule if cool-season). The €1.5M scale release is approved and flows on schedule by March (Month 5 = 2027-03-08), funding peak-summer operations (June-August) without cash-flow gaps. The program delivers ≥80% center hours, ≥60% outreach success and <45-minute transport times. Cooler-season evaluation shows modest reductions in heat-related EMS calls and ED visits (or null result with honest uncertainty reported). The playbook, cost model and equity-outcome summary are completed by Month 12 (2027-10-08), providing a reusable, auditable template for other EU cities. Year-2 funding discussions begin with evidence-based cost and outcomes data. Estimated mortality reduction (first year): 2-5 preventable deaths; estimated reputational and scaling value: €2-5M in follow-on programs across 3-5 EU cities.

**Fallback Alternative Approaches**:

- If a full, formal charter cannot be completed by Month 0.5 (2026-10-23) due to resource or approval delays, produce a Minimum Viable Charter by Month 0.8 (2026-11-01) covering: (1) one-page scope summary; (2) hard constraints and gates; (3) incident-command names and delegated authority; (4) procurement critical path; (5) Month 2 (2026-12-08) readiness gate checklist. Circulate to incident commander, funder and legal counsel for 48-hour rapid sign-off. This abbreviated version avoids project delay while deferring detailed SOPs to Month 1 (2026-11-08).
- If mayoral delegation cannot be obtained as a formal document by Month 1 (2026-11-08), use an interim verbal confirmation recorded in meeting minutes with attendees (mayor, health director, civil protection lead, funder representative), stating trigger thresholds and authorized persons. Obtain formal written delegation within 2 weeks thereafter. This preserves operational continuity if formal bureaucracy is slow.
- If all procurement cannot complete by Month 2 (2026-12-08) due to market delays, implement a two-wave strategy: fast-track 40-50% of kit volume and the transport retainer through below-threshold or framework purchasing by Month 1.5 (2026-11-23); defer the remaining 50-60% of kits to a competitive tender that concludes by Month 3 (2027-01-08). This splits procurement risk and still allows 80% kit delivery by April. Accept a 10-15% price premium on expedited first wave.
- If GDPR counsel cannot produce a full opinion by Month 1 (2026-11-08) due to regulatory uncertainty, obtain an interim legal letter by Month 0.8 (2026-11-01) stating that the intermediary-held-list model is provisionally compliant under GDPR Article 6(1)(e) (public task) pending finalized MOUs. Proceed with partner engagement on this interim basis; obtain full opinion by Month 1.5 (2026-11-23). This reduces legal bottleneck without exposing the program to unmitigated GDPR risk.
- If staff and volunteer recruitment falls behind (fewer than 20 volunteer drivers by Month 1.5 = 2026-11-23), scale the taxi-retainer contract proportionally to ensure transport-gate protection (≤45 min). Simultaneously extend volunteer recruitment deadlines to Month 2.5 (2026-12-23) and accelerate vetting (weekly cohorts instead of fortnightly). Accept that peak volunteer numbers may be lower and taxi costs higher (€50-100k overrun estimate), but avoid gate failure.
- If the Month 2 (2026-12-08) readiness gate is missed and corrective actions cannot close by Month 2.5 (2026-12-23), trigger a funder restart/re-scope conversation at Month 3 (2027-01-08). Options: (a) defer the Month 4 (2027-02-08) gate to Month 5 (2027-03-08) and adjust funding drawdown schedule; (b) reduce scope (e.g., 7-8 refuges instead of 10) to meet a revised readiness target by Month 3.5 (2027-01-23); (c) extend the pilot by 2-3 months into Month 15 (2028-01-08) if required. Charter should include explicit language authorizing this escalation path to avoid project paralysis.

## Create Document 2: Alert Trigger Ladder & Activation Thresholds

**ID**: 66c144d3-201d-4804-89ea-dd946e738907

**Description**: Defines three alert levels (Advisory, Alert, Emergency) with forecast trigger criteria, mandatory actions per tier, spending authority, and stand-down procedures. Links national meteorological-service forecasts to pre-agreed operational response. Audience: incident command, operations, partners, public.

**Responsible Role Type**: Incident Commander / Operations Lead

**Primary Template**: Heat Action Plan Alert Protocol (Barcelona/Paris model)

**Secondary Template**: National Meteorological Service Guidance (AEMET)

**Steps to Create**:

- Confirm temperature thresholds with national meteorological service (AEMET) and local climate context: Level 1 ≥33°C daytime or ≥20°C night for ≥2 days; Level 2 ≥35°C daytime and ≥22°C night for ≥2 days; Level 3 same for ≥3 days.
- Specify actions per level: advisory = phone checks + pre-positioned supplies; alert = centers 10:00-20:00; emergency = 24-hour operation + surge staffing.
- Define spending authorization per tier (e.g., Level 1 ≤€2k, Level 2 ≤€10k, Level 3 open).
- Establish stand-down criteria: forecast <35°C and prior 48 hours normal temperature; stand-down order ≤2 hours after criteria met.
- Include historical summer temperature data (2015–2025) for Castellón to validate thresholds post-hoc after first season.
- Finalize by Month 1 (2026-11-08); validate with AEMET; publish to partners and public by Month 6 (2027-04-08).

**Approval Authorities**: Incident commander, AEMET representative, operations lead, public-health deputy

**Essential Information**:

- Define three tiered alert levels (Advisory/Level 1, Alert/Level 2, Emergency/Level 3) with precise forecast-based trigger criteria (daytime highs and nighttime lows) and consecutive-day thresholds that convert national meteorological service (AEMET) forecasts into operational actions.
- Specify mandatory operational actions per tier: Level 1 → phone check-ins and pre-positioned supplies only; Level 2 → cooling centers 10:00–20:00 hours; Level 3 → 24-hour center operation plus surge staffing.
- Establish clear spending authorization limits for each alert tier (e.g., Level 1 ≤€2k, Level 2 ≤€10k, Level 3 open) to clarify which municipal officials can approve expenditures without escalation.
- Document stand-down criteria and procedures: alert ends when forecast falls below threshold temperatures AND prior 48 hours of actual temperatures remain normal; stand-down order issued and communicated to all partners and public ≤2 hours after criteria met.
- Include or reference historical summer temperature data (2015–2025) for Castellón de la Plana to validate that proposed thresholds correspond to observed heat events and heat-mortality risk in prior years; note any data gaps or limitations.
- Define escalation rules: when commander observes conditions (e.g., actual temperatures approaching threshold or meteorological-service confidence changes), procedures for upgrading or downgrading alert level mid-event.
- Specify forecast-access procedures: direct relationship with AEMET, forecast delivery timeline (5–7 days advance preferred; minimum 24 hours), confidence intervals, and how forecast uncertainty is handled (e.g., marginal advisory tier for borderline forecasts).
- Establish post-season review protocol: track false-alarm rate (full activations that did not result in widespread heat illness), missed-event rate (heat events that occurred below declared thresholds), and use metrics to refine thresholds after Year 1.

**Risks of Poor Quality**:

- Vague trigger thresholds or absent consecutive-day criteria lead to inconsistent alert declarations across years, eroding partner and public trust in the system and reducing operational readiness.
- Spending-authority ambiguity causes delayed approvals during critical hours, preventing timely activation of centers and transport when populations need help most.
- Absence of stand-down procedures prolongs unnecessary center operations, burning €5k–10k per false-alarm day and exhausting staff fatigue reserves needed for real events.
- Missing historical-data context allows thresholds to be set without grounding in local heat-mortality patterns, risking either over-activation (alert fatigue) or under-activation (missed dangerous nights).
- Incomplete escalation rules and forecast-access procedures leave command-seat occupant guessing about when and how to upgrade/downgrade, introducing politicization or clinical error.
- Absent post-season review discipline means the first season's learned adjustments are lost; thresholds cannot be refined based on observed false-alarm and missed-event rates, perpetuating suboptimal triggers.
- Lack of KPI tracking (false-alarm rate, missed-event rate, command response time) prevents data-driven improvement and credible reporting to funders and peer cities.

**Worst Case Scenario**: A poorly defined alert ladder causes cascading failures: thresholds set too high miss the dangerous hot-night events that drive mortality in vulnerable groups (elderly, isolated, homeless); command delays alert declaration by 12–24 hours because spending and escalation authority are unclear, leaving cooling centers closed when they are needed most. Alternatively, thresholds set too low trigger frequent false alarms that exhaust the €850k refuge budget on marginal days, leaving insufficient funds for real events in August. Partners and the public lose confidence after repeated false alerts, reducing enrollment and center uptake during the critical Month 4 (2027-02-08) scale gate evaluation, causing the gate to fail and the €1.5M release to be withheld. A preventable heat death occurs during a missed-event gap, triggering media scrutiny, political blame and program cancellation before Year 2 can be funded or evaluated.

**Best Case Scenario**: A clear, data-grounded alert ladder with specific forecast thresholds and spending authority enables incident commanders to declare alerts within 1 hour of forecast triggers, activating centers and transport reliably and predictably. Post-season review of false-alarm and missed-event rates (tracked as KPIs) allows thresholds to be refined after Year 1, reducing wasteful over-activation while ensuring dangerous nights are caught. Partners and the public understand alert criteria transparently, build trust in the system's fairness, and respond promptly to enrollment and center utilization. The ladder's clarity also speeds cross-department approvals by removing ambiguity about who can commit funds at each tier, enabling rapid procurement and redeployment decisions during multi-day heat waves. The documented thresholds and post-hoc refinement process become a reusable, transferable model for other EU cities with similar climates.

**Fallback Alternative Approaches**:

- If historical Castellón temperature and mortality data are unavailable or too sparse to calibrate local thresholds by Month 1 (2026-11-08), adopt the national AEMET alert framework directly (yellow, orange, red warnings) without local customization, accepting that sensitivity may be suboptimal but avoiding the analysis burden and timeline risk.
- If command-seat incident-commander availability or decision-making speed is unreliable, delegate alert declaration authority to the public-health director or a standing heat-desk duty officer with a written, pre-signed delegation letter specifying triggers, so declaration does not require mayoral sign-off in real time.
- If post-season threshold refinement requires analyst capacity not available internally by Month 8 (2027-06-08), commission a university or external consultant to conduct the false-alarm and missed-event analysis (cost estimate €8k–15k) and recommend Year-2 threshold adjustments.
- If AEMET forecast-delivery timing is unreliable or confidence intervals are wide, supplement with outputs from a local weather-station or university model (e.g., Universitat Jaume I, Castellón) that may provide higher-frequency or higher-confidence local forecasts; establish a dual-source protocol where alerts are declared only if both sources agree.
- If spending-authority clarity cannot be embedded in a single document due to municipal bureaucratic constraints, produce a parallel decision-matrix or flowchart that incident commanders can reference in real time, mapping alert level → spending limit → approver, with pre-signed blank purchase orders or standing delegations.
- If a full 10-year historical baseline is not available by Month 1.5 (2026-11-23), conduct a rapid mini-baseline using 3–5 recent summers and hospital/EMS records, acknowledged as provisional; commit to a retrospective full-baseline by Month 11 (2027-09-08) for Year-2 threshold refinement.

## Create Document 3: GDPR Compliance & Data-Processing Framework

**ID**: 7fbc7480-96b7-4a91-9f60-d6d2f8a92a4e

**Description**: Specifies lawful basis for heat-alert contact (public task + consent hybrid), defines controller/processor roles (housing associations, social services, NGOs as joint controllers or processors; city as recipient only), outlines data-protection-impact assessment (DPIA) scope, partner audit procedures, breach-notification escalation, and data-retention/deletion timeline (one season only, delete ≤30 days after Month 12 = 2027-10-08). Includes template data-processing agreements (DPAs), consent forms, privacy notices (translated), and audit checklists.

**Responsible Role Type**: GDPR Compliance Officer / Legal Counsel

**Primary Template**: EU GDPR Article 26 Joint Controller Agreement

**Secondary Template**: Data Processing Agreement (DPA) Template (Standard Contractual Clauses)

**Steps to Create**:

- Commission GDPR specialist law firm (€15-30k, Month 0.5 = 2026-10-23) to: (1) advise on lawful basis (public task + consent? consent-only? public-task-only?), (2) draft joint-controller agreement and processor DPA templates, (3) assess DPIA scope.
- Obtain written legal opinion by Month 1 (2026-11-08) confirming GDPR compliance path; if public-task basis is used, draft or identify municipal ordinance authorizing heat-alert contact.
- If consent-based: co-design affirmative-consent form (2 pages max, translated into 4-6 languages) specifying: purpose (heat-season welfare checks), data types, retention (one season), withdrawal method, and non-consensual alternative (street outreach if refuses contact calls).
- DPIA scope: If health-data loop (EMS/ED counts) is joint-controlled, complete formal DPIA (€8-12k, 4-6 weeks) addressing re-identification risk, access controls, retention security; submit to health-system legal teams by Month 1.3 (2026-11-17).
- Partner DPAs: Finalize joint-controller or processor agreements with each of 4-6 partner organizations (housing associations, social services, NGOs, pharmacies, hospitals, EMS) by Month 1.5 (2026-11-23). Agreements must specify: lawful basis, data types, retention, audit rights, breach notification (48-hour reporting to DPO and AEPD if applicable), and liability.
- Partner staff briefing: Conduct 1-hour session for 50-80 partner staff (housing caretakers, social workers, NGO field staff, pharmacists, EMS dispatch) on GDPR obligations, consent procedures, and incident reporting; distribute one-page checklist and maintain attendance roster; repeat annually.
- Designate a Data Protection Officer (DPO) or data-protection contact (0.3-0.5 FTE municipal staff or external consultant); publish DPO contact details in all resident-facing materials (flyers, posters, heat-line scripts, center signage).
- Establish breach-incident log (accessible only to DPO and incident commander): log suspected unauthorized access, disclosure, or data loss; notify AEPD within 48 hours if breach confirmed (Article 33); notify affected residents within 72 hours (Article 34).
- Partner audit: Month 9 (2027-07-08), spot-check 2-3 partner organizations for GDPR compliance (consent records, privacy-notice logs, staff training attendance, any breach reports). Document findings and corrective actions.
- Data deletion: ≤30 days after Month 12 (2027-10-08), delete all personal data from partner records and city systems unless re-consented for Year 2. Retain only aggregated outcome data (EMS counts, ED visits, participation numbers, anonymized).
- Finalize framework by Month 1.5 (2026-11-23); audit partner compliance by Month 9 (2027-07-08).

**Approval Authorities**: GDPR Counsel, Data Protection Officer, partner organizations' legal representatives, Spanish Data Protection Agency (AEPD) if consultation needed

**Essential Information**:

- Define the lawful basis for heat-alert contact (public task, consent, or hybrid model) under Spanish data-protection law and GDPR Article 6, with legal opinion by Month 1 (2026-11-08)
- Clarify data-controller and data-processor roles for each intermediary partner type (housing associations, social services, NGOs, pharmacies) and specify whether the city is a joint controller, separate controller, or recipient-only
- Design and draft affirmative-consent forms (translated into 4–6 non-official languages identified by Month 0 = 2026-10-08) specifying: purpose, data types, retention period (one season only), withdrawal method, and non-consensual alternative routes
- Scope and complete a Data Protection Impact Assessment (DPIA) if health-system data (EMS/ED aggregate counts) involves re-identification risk or cross-linking with city systems; address access controls, security and breach procedures
- Draft template data-processing agreements (DPAs) and joint-controller agreements conforming to GDPR Articles 26–28 and Spanish Organic Law 3/2018 (LOPDGDD); include provisions for sub-processors, audit rights, breach notification (48-hour escalation), liability allocation and international data transfers if applicable
- Establish a Data Protection Officer (DPO) role or designate a data-protection contact (municipal staff or external consultant, 0.3–0.5 FTE); publish DPO contact details in all resident-facing materials (flyers, heat-line scripts, refuge signage) and partner briefing materials
- Design and implement a breach-incident log (access-controlled, DPO + incident commander only) and escalation procedure: suspected breaches logged immediately, AEPD notification within 48 hours if breach confirmed (Article 33), resident notification within 72 hours (Article 34)
- Create partner-staff briefing package: 1-hour training session covering GDPR obligations, consent procedures, incident reporting, and confidentiality; conduct for 50–80 staff across all partner organizations by Month 2 (2026-12-08); maintain attendance roster and provide one-page checklist
- Define audit procedures for partner GDPR compliance: spot-check 2–3 partner organizations at Month 9 (2027-07-08) for consent records, privacy-notice logs, staff-training attendance, and any breach incidents; document findings and corrective-action timelines
- Specify data-retention and deletion procedures: all personal data retained only for the one-season period (October–September); deletion of all personal data from partner systems and city records within 30 days after Month 12 (2027-10-08) unless re-consented for Year 2; retain only aggregated outcome data (EMS counts, ED visits, anonymized participation numbers)

**Risks of Poor Quality**:

- Ambiguous or missing lawful-basis definition leads to legal challenge from data subjects or AEPD, halting outreach mid-season and forcing partner withdrawal; estimated delay 2–4 weeks and reputational harm
- Unclear controller/processor roles create liability confusion if a breach occurs, delaying incident response and violating GDPR Article 33 notification timelines (48-hour escalation)
- Consent forms that are unclear, untranslated, or legally insufficient for non-native speakers reduce enrollment validity and increase AEPD audit risk; estimated reach loss 10–20% if migrant communities distrust the process
- Incomplete DPIA or failure to assess re-identification risk leaves the program exposed to regulatory finding of inadequate safeguards; combined with cost and time to remediate: €10–20k and 4–8 weeks
- Weak or missing DPA templates result in partner non-compliance with GDPR obligations, exposing the city to joint-liability claims if data is mishandled; estimated exposure €50–100k in legal costs
- Absent DPO or unclear data-protection contact creates confusion over breach reporting and harms public trust; AEPD may levy administrative fines (Article 83–84, up to 4% of global revenue or €20M for public bodies)
- No breach-incident log or delayed escalation violates GDPR Article 33 and 34, incurring AEPD findings and potential fines for non-notification; estimated reputational and financial damage €20–100k
- Inadequate or untranslated partner briefing results in inconsistent GDPR compliance across organizations, increasing breach likelihood and audit findings; estimated cost to remediate €5–15k per partner
- Missing partner audit procedures prevent detection of consent violations or data misuse until after the season or after an AEPD complaint; remediation and fines retroactively applied
- Unclear or delayed data-deletion procedures leave personal data in systems beyond the retention period, violating GDPR Article 5(1)(e); residents or AEPD may demand deletion and impose fines for prolonged storage

**Worst Case Scenario**: 
A GDPR data-protection framework that is legally ambiguous, incomplete or inadequately translated results in a partner organization or data subject filing a complaint with Spain's AEPD. The AEPD investigation finds that the city lacked a clear lawful basis for contact, inadequate consent procedures for non-native speakers, or incomplete DPAs with unclear liability. While the investigation is ongoing (4–8 weeks), public media coverage of "unlawful heat-alert data collection" erodes resident trust and partner confidence, causing partner withdrawal and enrollment collapse. If the AEPD issues an administrative finding, the city faces reputational damage, mandatory corrective actions and a potential fine (EUR 10,000–100,000 range for public bodies). Outreach operations are halted mid-season pending legal remediation, costing estimated 2–4 weeks of lost contact time during peak heat risk and reducing the 60% outreach-contact gate achievement.


**Best Case Scenario**: 
A legally sound, pre-specified GDPR framework with clear lawful-basis opinion, translated consent forms, template DPAs and a designated DPO enables rapid partner sign-up by Month 1.5 (2026-11-23) and confident outreach from Month 2 (2026-12-08). Partner organizations operate with explicit guidance, attend staff briefings and maintain audit-ready consent records. Breaches (if any) are detected and escalated within 48 hours to the AEPD per Article 33. The program meets the 60% outreach-contact gate with high partner confidence and no legal challenges. The framework becomes a reusable, transferable model for other EU cities, demonstrating municipal data ethics and reducing adoption barriers for scaling.


**Fallback Alternative Approaches**:

- Engage a specialized GDPR law firm at Month 0.5 (2026-10-23) to provide a rapid legal opinion (€15–30k) on the most conservative lawful basis (consent-only) and provide template DPAs and consent forms ready for signature by Month 1 (2026-11-08); accept shorter retention windows or explicit opt-in if needed to simplify compliance and reduce partner friction
- If full DPIA is too resource-intensive, conduct a GDPR screening assessment (€3–5k, 1–2 weeks) to assess re-identification risk; if risk is low (aggregate counts only, no linking to health records), defer full DPIA and proceed with streamlined DPAs
- If recruiting a full-time DPO is unaffordable (0.5 FTE = €20–30k/year), designate a municipal legal officer or external consultant as part-time data-protection contact (0.3 FTE = €12–15k) with escalation authority to the incident commander; this reduces cost while maintaining breach-response accountability
- If partner capacity for consent and GDPR training is low, deliver briefings via recorded video (15 min) with accompanying one-page checklist and Q&A email support rather than live sessions; reduces scheduling friction and allows partners to train staff on their timeline by Month 2 (2026-12-08)
- If comprehensive partner audit (2–3 organizations) is resource-constrained at Month 9 (2027-07-08), conduct a desk-based audit using partner-submitted copies of consent records and staff-training logs rather than on-site inspections; reduces cost and time while maintaining accountability
- If data-deletion at Month 12 (2027-10-08) is operationally complex (distributed partner systems), establish a data-deletion task force 2 weeks before (Month 11.4 = 2027-09-20) to coordinate with all partners; provide a deletion checklist and certified deletion confirmation from each partner by deadline
- If translation into 4–6 languages exceeds budget, prioritize the 2–3 highest-volume language groups (identified by NGO/census data) and deliver translation by professional service; use pictograms and simplified Spanish for lower-volume groups; reduces cost from €15–25k to €8–12k

## Create Document 4: Full-System Drill Protocol & Exercise Script

**ID**: e27579ab-3489-45fb-a924-5c0b466d9fe3

**Description**: Detailed drill procedures for testing all operational elements (alert declaration, center activation, transport dispatch, outreach calls, EMS escalation, center stand-down) under realistic stress conditions. Specifies simulation scenarios (3+ consecutive hot-night events, 40+ simultaneous transport requests, 80%+ center occupancy, multi-day staff fatigue, misinformation reports), observer roles, timing, success criteria (80% center hours, 60% contact success, <45-min transport), and after-action reporting template.

**Responsible Role Type**: Operational Resilience & Surge Planning Lead / Project Manager

**Primary Template**: FEMA Full-Scale Exercise Protocol

**Secondary Template**: Incident-Command System (ICS) Exercise Evaluation Guide

**Steps to Create**:

- Drill scope (finalized Month 2.5 = 2026-12-23): Simulate 3+ consecutive hot-night alert events; activate all 10 cooling centers; dispatch 40+ simultaneous transport requests (including ≥5 wheelchair users); conduct 200+ outreach contact attempts via partners; manage center surge to 80%+ occupancy; simulate 2-3 EMS escalations and 1-2 misinformation reports; run continuously for 48-72 hours to test staff fatigue.
- Scenario vignettes: (1) Alert declared at 12:00 Day 1; centers open 10:00-20:00; 15 transport requests 12:00-18:00; (2) Second day: two requests at 06:00 (before official hours); centers extend to 06:00-22:00; 20 transport requests 10:00-20:00; (3) Multi-day transition: staff absences (2 call-outs per site), dispatch queue backs up, center occupancy peaks at 85%; misinformation (radio rumor: 'alcohol cools faster') circulates; messenger team and comms lead must respond ≤4 hours.
- Participant roles: Incident commander (declares alerts, authorizes spending); operations lead (manages centers, transport, EMS coordination); communications lead (public updates, misinformation response); dispatch coordinator (assigns drivers, tracks wait times); center managers and staff (log occupancy, manage residents, escalate incidents); outreach leads (log contact attempts); observer team (independent, track metrics, flag issues, document decisions).
- Success criteria (Month 4 gates = 2027-02-08): ≥80% of planned center-hours delivered (target 2,620 hours planned; pass ≥2,096 hours actual); ≥60% contact success (≥180 of 300 attempts reached, enrolled, or escalated); mean transport pickup <45 min over ≥30 requests (including wheelchair users); all after-action items identified and assigned by end of drill day 3.
- Measurement & data collection: Observer team logs in real-time: alert decision time (vs. forecast trigger + 1 h); center openings/closings (vs. plan); occupancy by hour (photos, tally); transport request count, assignment time, pickup time, destination; outreach contact attempts and outcomes (log form per partner); escalations and EMS interactions; any incidents (assault, injury, system failure); staff fatigue indicators (post-shift surveys); misinformation reports and response time.
- After-action process: Drill concludes 17:00 Day 3; draft after-action report within 48 hours (Day 4-5) documenting: actual vs. planned performance, root causes of any deviations, identified corrective actions, and assigned owners. Corrective-action meeting Week 1 post-drill (Month 3.4 = 2027-01-20) to review draft, assign owners, and set completion dates. All actions must be closed by Month 3.9 (2027-02-04) before Month 4 (2027-02-08) gate decision.
- Finalize drill protocol (including maps, contact lists, scripts, observer checklist) by Month 2.5 (2026-12-23); conduct drill Month 3.2 (2027-01-14); after-action draft Month 3.5 (2027-01-23); actions closed Month 3.9 (2027-02-04); gate decision Month 4 (2027-02-08).

**Approval Authorities**: Incident commander, operations lead, observer team (independent or external evaluator), funder representative

**Essential Information**:

- Define realistic multi-day simulation scenarios that mirror actual alert conditions: 3+ consecutive hot-night events triggering Level 2/3 alerts, with specific forecast trigger values (high ≥35°C, low ≥22°C) that activate the full center, transport and outreach network.
- Specify quantified success criteria aligned to the Month 4 (2027-02-08) gates: ≥80% of planned 2,620 center-hours delivered (pass ≥2,096 hours); ≥60% contact success from ≥300 outreach attempts (≥180 reached/enrolled); mean transport pickup <45 minutes over ≥30 requests including ≥5 wheelchair users; all corrective actions closed by Month 3.9 (2027-02-04).
- Detail stress-test scenarios simulating real operational failures: 40+ simultaneous transport requests at peak hours, centers reaching 80–85% occupancy, 2–3 staff absences per site due to fatigue, dispatch queue backlog, misinformation circulating (e.g., 'alcohol cools faster'), EMS escalations for heat-illness suspicion, and a late-arriving transport request (after-hours demand).
- Map participant roles with clear responsibilities: incident commander (declares drill start/end, authorizes escalations), operations lead (manages center and transport activations, logs occupancy), dispatch coordinators (assigns drivers, tracks time-to-pickup), center managers (staff the sites, document incidents), outreach leads (log contact attempts per partner), communications lead (responds to misinformation ≤4 hours), independent observer team (measures metrics, identifies root causes).
- Establish measurement protocol with real-time data collection: observer checklist capturing alert decision time (vs. forecast+1h target), center opening/closing times (vs. plan), hourly occupancy with photographic evidence, transport request count/assignment/pickup times, outreach contact outcomes (reached, enrolled, escalated, failed), EMS interactions, any incidents (assault, system failure, injury), staff fatigue survey post-drill.
- Prescribe after-action reporting and corrective-action closure: draft report within 48 hours (Month 3.5 = 2027-01-23); identify root causes for any performance gaps (e.g., 'dispatcher overwhelmed at 14:00 due to only 1 operator scheduled'); assign corrective owners and target dates; mandatory closure of all actions by Month 3.9 (2027-02-04) before gate decision.
- Define drill timing and scheduling: finalize protocol and maps by Month 2.5 (2026-12-23); execute full-system drill Month 3.2 (2027-01-14) for 48–72 consecutive hours; after-action meeting with funder and key partners Week 1 post-drill (Month 3.4 = 2027-01-20); corrective actions closed by Month 3.9 (2027-02-04); gate decision at Month 4 (2027-02-08).
- Include contingency measurement rule: if the drill provides insufficient evidence (e.g., poor participation, data gaps), document why; clarify that real heat events in June–July can supplement drill data for gate measurement; specify the fallback: 50% release at Month 4 (2027-02-08) if evidence mixed, full release deferred to Month 5 (2027-03-08).

**Risks of Poor Quality**:

- Unrealistic or vague stress-test scenarios fail to expose actual operational bottlenecks (e.g., dispatch overwhelmed, centers at capacity), allowing gaps to persist into the real summer season and causing preventable service failures during early-May heat events.
- Success criteria not anchored to the Month 4 (2027-02-08) gates allow subjective pass/fail decisions and diffuse accountability; unclear thresholds (e.g., 'most center hours delivered') invite disputes with the funder about whether gates are met, risking non-release of €1.5M funding.
- Incomplete participant-role definitions leave ambiguity about who decides to escalate to EMS, who authorizes stand-down, or who manages misinformation response; confusion during the drill leads to delayed decisions and eroded confidence in command structure.
- Poor data-collection protocols (missing observer assignments, no real-time logging, photos not taken) result in incomplete after-action evidence; without documented metrics, the funder cannot assess whether 80% center hours or 60% contact success were actually achieved, jeopardizing funding release.
- Weak after-action process (report written weeks later, corrective owners unclear, actions not tracked) allows identified problems to remain unfixed when the real summer season begins; staff may not know which fixes were implemented, reducing readiness and morale.
- Absence of a contingency-measurement rule leaves the city unprepared if June–July are cooler than normal and real heat events do not occur; the drill becomes the sole evidence, but if its quality is questioned, the Month 4 (2027-02-08) gate decision hangs unresolved, delaying the €1.5M release.
- Failure to test multilingual communications, volunteer-driver fatigue, or partner capacity during the drill means equity gaps and staffing weaknesses are discovered in real heat events instead, harming vulnerable residents and eroding public trust in the program.

**Worst Case Scenario**: The drill is poorly designed or executed: scenarios are abstract (e.g., 'simulate a hot day' without specific forecasts or request volumes), success criteria are subjective ('most centers operated well'), participant roles are unclear, and data collection is incomplete (occupancy estimates instead of counts, no transport time-logs). The after-action report identifies major gaps (e.g., 'dispatcher could not handle 40 requests'; 'outreach teams made only 150 of 300 planned calls due to partner staff absences'; 'average transport time was 62 minutes, not 45'). However, corrective actions are vague ('improve communications'), accountability is diffuse ('the team will do better'), and closure is incomplete by Month 3.9 (2027-02-04). The funder questions whether drill results are credible evidence for the Month 4 (2027-02-08) gate. No real heat events occur in June–July. The city cannot demonstrate that the 80% center-hours, 60% contact-success, and <45-minute transport gates have been met. The €1.5M scale release is withheld pending a re-test. By August, without confirmed funding, the program cuts center hours and transport capacity by 30%, leaving vulnerable residents at peak summer risk. A preventable heat death in late August triggers media investigation, finding the drill protocol had inadequate quality-assurance and the gates were never validly measured.

**Best Case Scenario**: The drill protocol is detailed and realistic: specific stress-test vignettes (e.g., 'alert declared 12:00; 40 transport requests 12:00–18:00; occupancy peaks 85% at 14:00; dispatch queue at 8 vehicles waiting; two staff call-outs; misinformation report 14:30') are scripted with expected outcomes. Success criteria are quantified and tied directly to the Month 4 (2027-02-08) gates: ≥2,096 center-hours observed, ≥180 outreach contacts logged, mean 43-minute transport time over 32 requests. Participant roles are explicit with decision authorities (commander declares stand-down ≤2 hours; comms lead responds to misinformation ≤4 hours). Real-time observer teams log data (timestamps, occupancy photos, transport assignment logs, contact forms per partner). The drill runs 48–72 hours with high-fidelity stress (concurrent fatigue, late calls, competing priorities). The after-action report (Month 3.5 = 2027-01-23) documents: drill ≥80% center-hours (2,150 of 2,620 planned); ≥60% contact success (195 of 300); mean 42-minute transport time; identifies 4 corrective actions (e.g., 'hire second dispatcher by Month 3 = 2027-01-08'; 'partner A needs call-center training by Month 3.5 = 2027-01-23'; 'signage installation at 2 sites by Month 3.8 = 2027-02-01'). All actions close by Month 3.9 (2027-02-04). The funder receives validated evidence. The €1.5M is released on schedule at Month 4 (2027-02-08). Staff confidence in the system increases. When real heat events occur in June–July, operations execute smoothly, meeting gates and demonstrating credible harm reduction that supports Year-2 funding and scaling to other EU cities.

**Fallback Alternative Approaches**:

- If designing a full 48–72 hour drill is too resource-intensive or risks coordinator burnout before the real season, conduct a tiered-exercise approach instead: tabletop exercise at Month 2.9 (2027-01-04) to walk through decision logic and role clarity (4–6 hours, in-person, command team + observer); functional exercise at Month 3.2 (2027-01-14) to test specific operational elements in sequence (dispatch response, center activation, partner call-out) with 2–3 hour runs, not full 72 hours; full-scale drill deferred to Month 7 (2027-05-08) after staffing is complete, allowing time for fixes identified in tabletop and functional exercises. Consolidate Month 4 (2027-02-08) gate evidence: 50% weight to functional exercise results, 50% to real heat events in May–June if available.
- If independent observer capacity is limited, assign one internal observer (e.g., PMO staff or evaluation partner) to each operational area (dispatch, outreach, centers) with pre-printed observer checklists and simple tally forms; conduct spot-check validation by an external evaluator (university partner) post-drill (review logs, interview participants, audit data) within 1 week. Accept lower real-time data quality in exchange for faster post-hoc validation and reduced coordination burden.
- If stress-testing 40+ simultaneous transport requests is infeasible with volunteer drivers or dispatch capacity, reduce the drill to 20–25 requests (realistic for a single-day Level 2 alert) and run the drill twice (transport stress test as separate functional exercise); measure average time-to-pickup in both runs and average the results. Document that the drill underestimates peak-capacity testing; use real June–July events (if any) to validate 40+ request performance.
- If partner outreach teams cannot commit to 200+ mock calls during a 48–72 hour drill (low capacity or competing summer work), reduce the mock-call target to 100 calls spread over 3 days (e.g., 30 calls Day 1, 35 Day 2, 35 Day 3) and measure contact success on a pro-rata basis; document that the drill uses a lower stress level and that real heat-event contact data will supplement the gates measurement. Ensure the 100 calls exercise the same partner network (all 5–6 intermediaries) to test each partner's process.
- If the drill cannot measure all four gates simultaneously due to scheduling or data constraints, conduct the drill focused on transport and center operations (quantifiable, high-risk), defer outreach-contact and after-action-closure validation to a second, lighter functional exercise or to real-event measurement in June–July. Gate decision rule: if drill passes ≥3 of 4 gates plus real events (if any) show contact success ≥60%, release the full €1.5M; if drill fails 2+ gates, release 50% contingently and re-test at Month 5 (2027-03-08).
- If the drill reveals major unfixable gaps (e.g., staffing shortage means dispatch cannot handle >20 requests), defer the Month 4 (2027-02-08) gate decision by agreement with the funder: release €750k (50%) immediately to sustain operations and hire additional dispatch staff; schedule a second drill or validated real-event test at Month 5 (2027-03-08) to measure all gates with corrected staffing; full release contingent on Month 5 (2027-03-08) results. Document the rationale and timeline in the gate-decision letter.

## Create Document 5: Procurement & Contracting Strategy

**ID**: f6efa0b2-0d45-432c-88ef-6bd643d1bbb1

**Description**: Specifies procurement routes (framework call-offs, below-threshold purchasing, simplified tenders) for four product categories: cooling kits (€800k), transport retainer (€80k), handyperson services (€150k), and refuge fit-out (€100k). Includes specifications, supplier-qualification criteria, delivery timelines, backup-supplier agreements, price-lock and expedite-fee authorization, and audit-trail documentation procedures.

**Responsible Role Type**: Municipal Procurement Officer / Contract Law Specialist

**Primary Template**: EU Public Procurement Directive Guidance (2014/24/EU)

**Secondary Template**: Spanish Public Procurement Regulations (LCSP)

**Steps to Create**:

- Procurement planning (Month 0 = 2026-10-08): Define €3.5M budget by category; identify existing municipal framework agreements (utilities, services, maintenance) suitable for call-offs; confirm legal thresholds (Spain: €50k EU below-threshold, varying by region for services/supplies).
- Specifications (by Month 0.8 = 2026-11-01): Issue detailed RFQs for (1) cooling kits: shading, reflective blinds, fans, thermometers, specs; (2) transport: vehicle type, capacity, response-time SLA, insurance; (3) handyperson: electrician/installer qualifications, training requirements; (4) fit-out: accessibility remediation, fit-out standards.
- Supplier identification & pre-qualification (Month 1 = 2026-11-08): Request quotes from ≥3 primary suppliers and ≥2 backup suppliers per category; evaluate on price, lead time, quality, and experience; pre-qualify backups with written 'emergency activation' agreements specifying ≤7-day mobilization and expedite premium (≤10% price increase).
- Procurement route decision (Month 1 = 2026-11-08): For each category, determine lowest-risk legal route: (1) kits ≤€100k/call-off = framework call-off if framework exists (audit-safe); (2) kits >€100k per batch = simplified below-threshold tender (€50-200k threshold band, written documentation, 2-3 quotes); (3) transport retainer ≤€80k = framework or simplified tender; (4) handyperson ≤€150k total = framework or simplified tender. Document route choice and legal justification.
- Order placement (Month 1.2-2 = 2026-11-14 to 2026-12-08): Place first-tranche kit orders (30-40%) by Month 1.2 (2026-11-14) with primary supplier; include SLA for February 2027 delivery. Place transport retainer contract by Month 1.2 (2026-11-14) with 48-hour cancellation clause. Confirm all tranche-1 orders placed by Month 2 (2026-12-08) readiness gate.
- Contract management: (1) Delivery tracking (log actual receipt date vs. planned); (2) quality assurance (inspect first 5% of kit shipment for defects); (3) invoice & payment (audit invoice against SLA, delivery confirmation, quality check); (4) change orders (scope/timeline changes require written approval and amendment; document reason, cost, and incident commander sign-off).
- Audit readiness: Maintain complete procurement file per order including: RFQ and responses, evaluation criteria and scoring, selected-supplier justification, contract document (signed), delivery record, quality-assurance checklist, payment authorization, and any change orders. File must be defense-able to municipal audit and EU auditors.
- Backup activation trigger: If any supplier misses committed delivery date by >1 week, immediately (≤24 hours) notify backup supplier, confirm mobilization, and place emergency order. Authorize expedite-fee payment (up to 10% premium, approximately €80-120k for kits; €8-12k for transport/services) without additional approval.
- Finalize procurement strategy by Month 0.8 (2026-11-01); execute first orders by Month 1.2 (2026-11-14); confirm all orders by Month 2 (2026-12-08).

**Approval Authorities**: Municipal Procurement Officer, CFO/Budget Director, incident commander (for budget authority), legal counsel (for contract terms)

**Essential Information**:

- Define procurement routes (framework call-offs vs. below-threshold purchasing vs. simplified tenders) for four product categories: cooling kits (€800k), transport retainer (€80k), handyperson services (€150k), and refuge fit-out (€100k), with rationale for each choice and audit defensibility.
- Specify detailed RFQ and specification documents for each category by Month 0.8 (2026-11-01), including product standards (cooling kit specifications: exterior shading, reflective blinds, fan type/wattage, thermometer/hygrometer accuracy, hydration supplies packaging), transport SLA (response time ≤20 min for ≥10 vehicles including ≥3 wheelchair-capable), handyperson qualifications (electrician certification, heat-safety training completion), and refuge fit-out accessibility standards (wheelchair access, AED placement, water/toilet facilities).
- Identify and pre-qualify ≥3 primary suppliers and ≥2 backup suppliers per category by Month 1 (2026-11-08), with written emergency-activation agreements specifying ≤7-day mobilization and expedite-fee caps (≤10% price premium authorized without additional approval).
- Document the order placement timeline and triggers: first-tranche kit call-off for 30–40% volume (600–800 units) by Month 1.2 (2026-11-14); transport retainer contract signed by Month 1.2 (2026-11-14) with 48-hour cancellation clause; all tranche-1 orders confirmed by Month 2 (2026-12-08) readiness gate.
- Establish backup-supplier activation rules: if primary supplier misses committed delivery date by >1 week, notify backup within 24 hours, confirm mobilization, and place emergency order; authorize expedite-fee payment (€80–120k for kits, €8–12k for services) without escalation if within the authorized cap.
- Create complete procurement-file audit trail per order including: RFQ and responses, evaluation criteria/scoring, selected-supplier justification, signed contract, delivery record, quality-assurance inspection checklist (first 5% of shipment), invoice vs. SLA verification, payment authorization, and any change orders with incident-commander sign-off.
- Define delivery-tracking and quality-assurance processes: log actual receipt vs. planned date; inspect first 5% of each kit shipment for defects and correct or replace within 5 business days; accept/reject invoice based on SLA, delivery confirmation and QA sign-off; escalate defects or delays to backup supplier immediately.
- Specify procurement governance: approval authorities (Municipal Procurement Officer, CFO/Budget Director, incident commander for budget, legal counsel for contract terms) and documentation standards (all files defense-ready for municipal and EU audit, with legal justification for each route choice).
- Calculate and authorize contingency spending: identify expedite-fee authorization threshold (€10–15k per procurement event without additional approval; cumulative ≤€120k from tranche-1 contingency); trigger condition: primary supplier delay >1 week; document business case (date, reason, cost, signed authorization).
- Quantify pricing risk and lock-in strategy: obtain fixed-price quotes and benchmark against market by Month 1 (2026-11-08); lock in transport-retainer rates by contract by Month 1.2 (2026-11-14) before summer demand spike; for kits, negotiate volume-discount terms and agree on expedite-fee caps before first order.

**Risks of Poor Quality**:

- If procurement routes are not legally justified or documented, audit may find non-compliance with EU Public Procurement Directive (2014/24/EU) and Spanish LCSP regulations, triggering mandatory re-procurement, project delay of 6–8 weeks, and reputational damage; estimated legal cost: €20–30k.
- Inadequate specifications (vague product standards, missing SLAs for transport, unclear installer qualifications) will result in quality mismatches, supplier disputes, contract claims and potential rework; examples: fans ordered without proper airflow specification causing resident harm, transport vehicles lacking wheelchair lifts failing accessibility gate, handyperson work failing electrical code inspection.
- If backup suppliers are not pre-qualified or emergency-activation procedures are unclear, primary supplier delay will cascade: kits will not arrive until March–April, delaying home installations past the first May–June heat events by 4–8 weeks; estimated reach loss: 15–25% of target homes untreated during peak-risk season.
- Missing or incomplete procurement-file documentation (RFQs, evaluation notes, contract copies, delivery records) will fail audit and undermine program credibility; funder, auditors and EU partners will question financial controls and procurement integrity, risking project pause or phase-out.
- Inadequate quality-assurance processes (no inspection of kit shipments, no verification of transport-vehicle specifications) will result in defective or unsuitable equipment reaching the field: fans that malfunction, reflective blinds that fail installation, wheelchair-access vehicles lacking proper lifts; remediation cost: €20–50k and operational disruption during alert days.
- If delivery tracking is not rigorously maintained, shortages or delivery mismatches will go undetected until late in the supply chain, causing sudden gaps in kit availability or transport capacity during early heat events; estimated operational impact: 2–3 week delay in full deployment.
- Budget and cost-control failures: if expedite fees are not pre-authorized or caps are exceeded, procurement coordinator will delay decisions or exceed budget, causing both order delays and overspend; estimated cost exposure: €150–250k if taxi-only fallback is triggered without pre-planning.
- Reputational damage if sole-source or repeat-vendor patterns emerge without documented justification; media, unions, auditors or political opponents may claim favoritism or inflated pricing, damaging public trust in the program.

**Worst Case Scenario**: Procurement delays exceed the Month 2 (2026-12-08) readiness gate, with no kits or transport contracts in place by the deadline. Primary suppliers confirm 10–14 week lead times, and backup suppliers are unavailable or unaffordable. Cooling kits do not arrive until April–May, home installations slip by 6–8 weeks, and no handypersons are contracted to install. Transport retainer is not signed, leaving only volunteer drivers (if recruitment succeeds, which is uncertain). The Month 2 (2026-12-08) readiness gate fails, and the program enters the cooling season (June–August) with no pre-positioned home kits and inadequate transport capacity. Early heat events in May–June find refuges open but transport severely constrained, home-level interventions absent, and the Month 4 (2027-02-08) gates unachievable. Scale funding (€1.5M) is not released, forcing budget cuts and mid-summer operational contraction. Vulnerability in homes and transport pathways during peak-risk summer months leads to preventable heat illness and death in untreated top-floor and mobility-limited residents; media coverage blames failed procurement planning and municipal incompetence. Estimated financial impact: €350–650k unbudgeted draw on contingency and operating costs, plus reputational damage affecting Year-2 funding and future EU partner interest.


**Best Case Scenario**: Procurement is completed on schedule with all orders placed by Month 2 (2026-12-08), kits arriving by April (Month 6.7 = 2027-04-29), and transport contract operational by Month 1.2 (2026-11-14). Cooling-center fit-out, refuge staffing and handyperson deployment are all in place by May 1 (Month 6.8 = 2027-05-02). First-tranche budget (€2.0M) is fully committed without cost overruns, contingency is preserved for operational needs, and backup suppliers are not needed. Home installations of 2,000 kits proceed smoothly February–May with zero defects and fast handyperson completion. Transport retainer delivers reliable response times (mean <40 min), volunteer driver vetting yields 40+ recruits, and dispatch coordination is rehearsed in May drills. Month 4 (2027-02-08) gates are passed on the strength of drill results, enabling full release of €1.5M scale funding on schedule. Summer heat events find the entire system operational and responsive: refuges reach 80%+ planned hours, outreach achieves 60%+ contact success, transport meets the 45-minute threshold, and staff morale is high. Procurement planning becomes a reusable playbook section that other EU cities can adapt, demonstrating transparent, auditable financial controls and schedule discipline.


**Fallback Alternative Approaches**:

- If primary supplier lead times exceed 6 weeks by Month 0.8 (2026-11-01), immediately activate backup suppliers and place a small first call-off (10–15% of volume, ~200 kits) with an expedite-fee premium (≤10%, ~€8–12k) at Month 1 (2026-11-08), then conduct a full competitive tender for the second tranche (70–80% of volume) with a longer delivery window (April–May) to obtain better pricing and avoid single-source dependency.
- If municipal framework agreements are unavailable or unsuitable for kits and transport, conduct a rapid simplified below-threshold tender (€50–200k band in Spain) for each category by Month 1 (2026-11-08), with a 2-week RFQ process and ≥3 quotes required; document evaluation and selected-supplier justification to maintain audit compliance.
- If legal counsel is unavailable or EU Procurement Directive interpretation is unclear, engage a specialized procurement law firm for focused advisory support (€5–10k scope) rather than full-scope representation; this accelerates route decisions without committing to extended legal retainer.
- If backup-supplier pre-qualification is not complete by Month 1 (2026-11-08), establish a contingency sourcing pool by Month 1.5 (2026-11-23) via rapid RFQs to secondary regional/national suppliers; confirm availability and expedite-fee caps in writing, then hold this pool on standby pending primary delivery.
- If refrigeration, storage or transportation logistics bottleneck kit distribution by February, arrange interim warehousing with the selected supplier or a third-party logistics provider (€3–5k monthly cost) rather than forcing delayed delivery; confirm cold-chain management (for certain kit materials, if applicable) in the storage contract.
- If handyperson vetting or certification cannot be completed by Month 3 (2027-01-08), contract an external installation firm (social enterprise, NGO or contractor group) that already holds certified electrician staff and can be mobilized at short notice with training only on the heat-safety checklist (2-hour briefing); this reduces hiring bottleneck but slightly increases unit cost (~€50/install).
- If the transport retainer bid process yields only one qualified respondent or quoted rates are unexpectedly high (>€80k), exercise a contingency procurement route: (a) extend the volunteer-driver target to 50–60 (recruiting urgently in November–December) and retain only a scaled-down taxi fallback (€30–40k, emergency-only, not standby retainer); or (b) negotiate a shorter retainer term (May–July only, not May–September) to stay within budget; or (c) broker a non-profit taxi or community-transport partnership that accepts lower rates in exchange for municipal promotion or procurement preference.
- If tranche-1 budget pressure forces cuts before Month 3 (2027-01-08), prioritize in order: (1) maintain full refuge fit-out and transport retainer (gates depend on them); (2) reduce kit volume to 1,500 (75% of 2,000 target) and cut lower-priority social housing; defer remaining 500 kits to tranche-2 (Month 4 = 2027-02-08 budget); or (3) negotiate volume discounts or phased payment terms with suppliers to defer cost to Month 4 (2027-02-08).


# Documents to Find

## Find Document 1: Castellón de la Plana Demographic & Census Data

**ID**: 616f23d3-774e-4db6-9946-6528ff41bced

**Description**: Official municipal census and demographic data (2020 or most recent) specifying: age distribution (65+ population count and percentage), housing types (owner-occupied, rented, social housing, top-floor prevalence), education and literacy levels, migrant and recent-arrival populations by origin country/language, employment rates, and health-insurance coverage. Identifies vulnerable populations and geographic concentrations for targeting cooling refuges and outreach. Primary input for vulnerability mapping and equity metrics.

**Recency Requirement**: Most recent available (2020 Census or municipal 2024-2025 update preferred); supplement with 2015-2020 trend data if needed.

**Responsible Role Type**: Project Manager / Data Analyst

**Steps to Find**:

- Contact Castellón de la Plana municipal statistics office or Valencian regional statistics agency (Institut Valencià d'Estadística, IVE).
- Request: age distribution (5-year bands, especially 65+), housing type by neighborhood, migrant/foreign-born population by country of origin, language spoken at home.
- Search national Spanish statistics portal (Instituto Nacional de Estadística, INE) for Castellón municipality-level data.
- Request municipal housing authority data on social-housing locations, building age, and insulation quality of stock.

**Access Difficulty**: Easy. Spanish census data are freely available via INE portal; municipal statistics are public unless privacy-restricted. Contact municipal social services or urban planning department for neighborhood-level housing stock detail.

**Essential Information**:

- Confirm whether Castellón de la Plana municipal census and demographic data (2020 or most recent) are accessible and contain: age distribution with 65+ count and percentage, housing types (owner-occupied, rented, social housing, top-floor prevalence), education and literacy levels, migrant and recent-arrival populations by origin country and language, employment rates, health-insurance coverage.
- Identify geographic concentration of vulnerable populations (65+, living alone, top-floor/poorly insulated units) by neighborhood or postcode to validate cooling-refuge site selection and outreach targeting.
- Quantify baseline heat-related EMS calls (current estimate 80–120 per summer) and heat-attributable excess mortality (current estimate 15–25 per summer) using municipal EMS records and health-department mortality data with consistent coding definitions.
- List all candidate cooling-refuge sites (libraries, community centers, parish halls, churches, sports halls, malls) with current use, operating hours, wheelchair access status, water/toilet/first-aid facilities, parking and signage.
- Confirm migrant and linguistic diversity: identify top 4–6 non-official languages spoken by residents and concentration in neighborhoods to guide interpretation and ambassador recruitment.

**Risks of Poor Quality**:

- Incomplete or outdated census data (older than 2020) will misidentify vulnerable-population concentrations, causing cooling refuges to be sited in low-need areas and home kits to reach the wrong households, reducing equity coverage and mortality protection.
- Missing baseline EMS and mortality counts will prevent credible attribution of harm reduction by Month 4 (2027-02-08), undermining the Month 4 (2027-02-08) gate evaluation and playbook credibility for other EU cities.
- Incomplete site inventory (missing wheelchair-access data or operating-hours constraints) will force remediation or site substitution mid-season, delaying refuge opening and delaying the Month 2 (2026-12-08) readiness gate.
- Inaccurate language-community identification will leave migrant residents unable to receive alerts or escalation guidance, reducing enrollment and contact-success rates below the 60% Month 4 (2027-02-08) gate and creating health and equity harm.
- Unverified population estimates will cause staffing and budget allocations to be misaligned with actual demand, leading to undersized or oversized operations and gate failure.

**Worst Case Scenario**: If demographic and census data are unavailable or inaccessible, the program cannot validate the pilot's geographic footprint or measure equity coverage. Cooling refuges may be sited in low-need areas and home kits directed to low-risk households, leaving the most vulnerable unprotected. Baseline EMS and mortality data missing or unreliable prevents credible Month 4 (2027-02-08) gate evaluation, risking non-release of the €1.5M scale funding and loss of funder confidence in the playbook. Unconfirmed migrant-language profiles delay ambassador recruitment and translation by 4–6 weeks, causing non-official-language residents to miss enrollment and alert contact entirely, resulting in preventable heat illness or death in those communities. Combined, these gaps could cause a 2–4 week delay to the Month 2 (2026-12-08) readiness gate and gate failure at Month 4 (2027-02-08), forcing the program to scale back or cease operation mid-summer.

**Best Case Scenario**: Accessible, recent census and administrative data (2020 or newer) with neighborhood-level granularity enable rapid, precise vulnerability mapping by Month 0.5 (2026-10-23), confirming cooling-refuge siting and outreach targeting. Baseline EMS and mortality data obtained by Month 1 (2026-11-08) with consistent heat-attribution coding in place by Month 2 (2026-12-08) provide a robust foundation for Month 4 (2027-02-08) gate evaluation and credible attribution analysis. Confirmed migrant-language communities and concentration data by Month 0 (2026-10-08) allow immediate ambassador recruitment and translation procurement, ensuring enrolled non-official-language residents receive alerts and escalation guidance in their preferred language. With these inputs, staffing and budget allocations align with actual demand, enabling the program to meet Month 2 (2026-12-08) readiness and Month 4 (2027-02-08) scale gates on schedule, deliver a credible playbook, and build funder confidence in scaling to other EU cities.

**Fallback Alternative Approaches**:

- If municipal census or housing data are unavailable, request aggregated data from municipal social services, housing authority and utility companies (gas/electricity distribution) to infer housing condition and age distribution by neighborhood; cross-reference with GIS mapping of buildings by age and energy-efficiency labels if available.
- If baseline EMS and mortality data are absent or historically uncoded for heat attribution, conduct a rapid retrospective audit of a sample of prior-summer ED and EMS records (n=100–200 cases) using clinical criteria (core temperature, heat-related ICD codes, clinical judgment) to establish a pilot baseline; estimate confidence intervals and caveats clearly in the Month 4 (2027-02-08) gate report.
- If current demographic data are outdated (pre-2015), supplement with the most recent municipal planning or health equity assessments, NGO local-knowledge interviews (housing associations, social services, faith leaders) and a rapid survey sample (n=200–300 residents in high-need neighborhoods) conducted by Month 1 (2026-11-08) to triangulate vulnerable populations.
- If migrant-language data are not recorded in municipal sources, contact NGO partners (immigrant associations, refugee services, faith communities) and conduct 5–10 key-informant interviews by Month 0.5 (2026-10-23) to identify top languages and neighborhood concentrations; cross-check against census 'country of birth' fields if available.
- If cooling-center site inventory is incomplete, conduct a 1-week rapid canvass (Month 0.5 = 2026-10-23) of all candidate facilities (libraries, community centers, etc.) via phone and in-person visit checklist covering wheelchair access, water/toilets/first-aid, parking, signage and current operating hours; document findings in a simple spreadsheet and use to prioritize remediation or substitution before site-selection decision at Month 1 (2026-11-08).

## Find Document 2: Castellón de la Plana Historical Heat Data & Temperature Records

**ID**: 1f879ea9-02e6-450a-bb45-247ffa4dff2e

**Description**: Daily maximum and minimum temperature records (2010-2025) from national meteorological service (AEMET) or local weather station, with date and location. Used to validate alert thresholds historically (how often does forecast ≥35°C daytime and ≥22°C night occur? how many are actual heat events vs. false alarms?), and to establish the baseline relationship between temperature and heat-related EMS/ED calls for temperature-adjusted evaluation.

**Recency Requirement**: 15-year historical record preferred (2010-2025); minimum 5-year baseline (2020-2025).

**Responsible Role Type**: Data and Evaluation Coordinator

**Steps to Find**:

- Contact Spanish national meteorological service (Agencia Estatal de Meteorología, AEMET) and request historical temperature data for Castellón de la Plana station (daily high/low, date).
- Download from AEMET public portal (https://www.aemet.es) or request via open-data API.
- Cross-check with local university or research institute weather data if available (e.g., Universitat Jaume I, Castelló, may have local station data).
- Obtain additional context: known major heat events in Castellón (2003, 2010, 2015, 2018, etc.) and their reported temperature and impact.

**Access Difficulty**: Easy. AEMET historical weather data are publicly available via portal and downloadable. Local university data may require a research-partnership request but are typically shared for public-health context.

**Essential Information**:

- Obtain 15-year daily maximum and minimum temperature records (2010–2025) from AEMET for Castellón de la Plana weather station, with date stamps for every record.
- Cross-validate alert-threshold frequency: how many days per year historically meet or exceed ≥35°C daytime AND ≥22°C night-time conditions for ≥2 consecutive days (Level 2 Alert trigger)?
- Quantify false-alarm rate: of those days meeting forecast thresholds, what percentage resulted in actual heat-related EMS/ED call spikes or mortality excess?
- Document known major heat events in Castellón (2003, 2010, 2015, 2018, and others): date, observed temperature, reported EMS calls, deaths, media coverage.
- Establish baseline temperature-mortality relationship: regression coefficient (deaths or EMS calls per 1°C above threshold) if data exist, with confidence intervals.
- Confirm data quality: missing days, measurement gaps, station relocations, or method changes over 15 years that could bias threshold calibration.
- Obtain parallel data from local university weather station (Universitat Jaume I) if available to validate AEMET record and assess local microclimate variation by neighborhood (e.g., heat-island effects in central vs. peripheral zones).

**Risks of Poor Quality**:

- Incomplete or missing data (>10% gaps) invalidates threshold calibration and forces reliance on national proxies, losing city-specific sensitivity and risking either over-alert (fatigue, budget burn) or under-alert (missed hot nights and preventable deaths).
- Inconsistent temperature measurement method or station relocation (e.g., different sensor, elevation, urban-ization change) introduces systematic bias; thresholds calibrated on 2010–2015 data may not apply 2025–2027.
- False-alarm rate unquantified: thresholds set without validation against actual EMS/ED load leave City uncertain whether forecast ≥35°C reliably predicts health impact; poor thresholds fail both gates and erode stakeholder trust.
- Baseline relationship (temperature vs. EMS/ED/mortality) absent or weak: evaluation at Month 4 (2027-02-08) cannot attribute observed changes to program vs. natural temperature variation, making scaling cost model non-credible.
- Neighborhood-level heat variation unmapped: peripheral and central Castellón may have 2–4°C difference due to density and materials; single city-wide threshold misses high-risk microclimates, leaving hot-spot residents under-protected.
- Historical data not accessible by Month 1 (2026-11-08): threshold calibration cannot be completed, forcing default (national thresholds) which may be misaligned to local climate, jeopardizing Month 2 (2026-12-08) readiness and drill validity.

**Worst Case Scenario**: If 15-year temperature records are incomplete, inaccessible, or of poor quality by Month 1 (2026-11-08), alert thresholds cannot be locally calibrated and must default to national forecast criteria. A defaulted, un-validated threshold may be misaligned to Castellón's actual heat-mortality risk: if too loose (low threshold), the program over-activates centers on marginal days, burning €10k–15k per false alarm and exhausting center-hours budget by July (€1.2M budget, 25 planned activation days, each ~€52k—three unnecessary activations consume €156k and reduce reserves for real peaks). If too tight (high threshold), the program misses hot-night events that drive elderly mortality, potentially leaving 5–10 heat-vulnerable residents unprotected during critical July–August surges. Either scenario—budget collapse or preventable mortality during observed heat event—triggers media scrutiny, funder loss of confidence, and non-release of €1.5M scale funding at Month 4 (2027-02-08). Estimated financial and reputational impact: €200k–400k cash shortfall plus credibility loss for playbook scaling to other EU cities.

**Best Case Scenario**: By Month 1 (2026-11-08), a complete 15-year AEMET record and validated local university data establish precise city-specific alert thresholds: ≥35°C daytime AND ≥22°C night-time occurs 18–25 days per season historically, and 80%+ of those days correlate with ≥1.3× baseline EMS call load. Threshold-calibrated forecasts reduce false alarms to <15% and ensure real heat events are caught. Baseline temperature-mortality regression (e.g., 2.1 deaths/°C above 32°C threshold) quantifies expected harm without intervention, enabling credible Month 4 (2027-02-08) attribution and scaling cost model ($X per prevented death). Neighborhood heat-mapping reveals that central Castellón reaches 2–3°C hotter than periphery; this directs home-kit and transport resources to highest-risk zones, improving equity and impact. Drill thresholds set using this data are realistic and validate operational readiness. Month 4 (2027-02-08) gate measurement against calibrated, evidence-grounded thresholds is defensible and builds stakeholder and funder confidence in the program's precision, supporting Year-2 continuation and replication to peer EU cities.

**Fallback Alternative Approaches**:

- If AEMET 15-year record is incomplete or inaccessible, request 5-year minimum baseline (2020–2025) by Month 1 (2026-11-08) and supplement with proxy: published Spanish national summer heat events (AEMET heat warnings, red-alert days) and Castellón newspaper archives (El Periódico de Castellón, La Ronda) documenting observed temperatures and health impacts in 2010–2019; cross-reference with hospital administrative data (admission logs by date, not patient names) to infer EMS call spikes.
- Contact Universitat Jaume I (Climate and Environmental Sciences group) at Month 0.5 (2026-10-23) to request access to local weather-station records or to conduct a 3–6 month pilot microclimate monitoring (April–September 2027) alongside AEMET data, establishing local calibration for future years.
- If baseline temperature-mortality relationship cannot be derived from local data (small samples, incomplete coding), use published regression coefficients from peer Spanish cities (Madrid, Barcelona, Valencia) adjusted for Castellón's climate and housing stock, documented in literature (e.g., Spanish National Health Institute reports on heat mortality). Disclose this limitation transparently in the evaluation report and playbook.
- Conduct a rapid expert-elicitation workshop at Month 1 (2026-11-08) with local public-health physician, EMS medical director and meteorologist: ask them to propose alert thresholds based on professional judgment and prior experience with Castellón heat events. Use their input to validate or adjust quantitative thresholds and document the rationale.
- If neighborhood-level heat mapping is not available, use proxy: map top-floor flats and poor-insulation social housing (available from municipal building registry) as proxy for heat vulnerability; concentrate home kits and mobile cool-points there, and measure neighborhood coverage equity in the evaluation report.
- For Month 2 (2026-12-08) readiness gate, use national meteorological forecast thresholds (AEMET red/orange/yellow warnings) as interim alert criteria, documented as provisional; commit to local calibration by Month 4 (2027-02-08) and threshold review by Month 6 (2027-04-08) once real summer 2027 data arrive. This allows gates to proceed on schedule while preserving the option to adjust thresholds for Year 2.

## Find Document 3: Castellón de la Plana Municipal Cooling-Center Asset Inventory

**ID**: f99bad9d-b417-474d-8a99-6239257d50ca

**Description**: Official list of municipal or accessible public facilities (libraries, community centers, parish halls, sports facilities, schools, government offices) with: location (address, postal code), floor area, occupancy capacity, current opening hours, accessibility features (wheelchair access, toilets, water, parking), utilities (air-conditioning, heating, water supply), and insurance/liability status. Used to identify and audit the 10 proposed cooling-center sites.

**Recency Requirement**: Current (2024-2025); update if facilities have undergone recent renovation or closure.

**Responsible Role Type**: Cooling Center Network Manager

**Steps to Find**:

- Contact Castellón de la Plana municipal facilities or asset-management department; request comprehensive facility inventory with accessibility audit data.
- Request municipal facility-use agreements or insurance documentation for liability assessment.
- Contact library system, municipal sports/recreation department, and social services to cross-check facility capacity and opening-hour availability.
- Visit or photograph proposed sites to verify accessibility; document any gaps (missing ramps, inadequate toilets, no quiet room).

**Access Difficulty**: Medium. Municipal facilities data are typically held internally; access requires formal request to facilities management or city procurement office. Some data may be classified (insurance, security). Accessibility audit reports may be incomplete; physical verification required.

**Essential Information**:

- Identify and list all municipal and publicly accessible facilities (libraries, community centers, parish halls, sports facilities, schools, government offices) in Castellón de la Plana with complete addresses and postal codes.
- Document floor area (m²) and current functional occupancy capacity for each site under normal and heat-alert conditions.
- Map accessibility features for each facility: wheelchair ramps/level entry, accessible toilets (≥1 per 50 occupants), water fountains or supply, parking (general and disabled), quiet/low-stimulus rooms.
- Record utilities availability: air-conditioning system type and capacity (kW or equivalent); backup power; water supply capacity (liters/hour); heating (not required for summer, note for completeness).
- Verify current opening hours and flexibility for extended hours (10:00–20:00 standard, 24:00 capability for ≥3 sites at alert Level 3).
- Confirm liability insurance coverage and facility-use agreement status for each proposed site; identify gaps requiring legal action before Month 2 (2026-12-08) readiness gate.
- Audit which sites meet accessibility standards (ramps, toilets, water, quiet space) to confirm ≥50% of planned refuge places are in fully accessible facilities, per the refuge-site standard.
- Identify remediation needs (cost, timeline) for each inaccessible site; confirm remediation cost ≤€10k and timeline ≤4 weeks, else deprioritize or defer the site.
- Verify capacity of water supply and sanitation under continuous occupancy (10:00–20:00, potentially 200–400 residents per day at Level 2–3 across all sites).
- Cross-reference each site's location (address, postal code) against the vulnerability heat map to confirm ≥70% of enrolled residents are within 800 m (10-minute walk) of ≥1 refuge.

**Risks of Poor Quality**:

- Incomplete or outdated facility list: if closed, relocated, or newly renovated sites are not flagged, the city may commit to sites that are unavailable, reducing actual refuge capacity below the planned 400 places and forcing transport-only access for residents who cannot travel.
- Missing or inaccurate accessibility audit: if ramps, toilets, water or quiet rooms are not documented, the city may open a site that excludes wheelchair users, deaf/hard-of-hearing, or sensory-sensitive residents, violating disability access law and failing the equity gate.
- Underestimated occupancy capacity: if a site's functional capacity is overstated (e.g., assuming 50 places when furniture/layout allows only 30), the city will overcommit refuge hours and overcrowd sites, increasing heat-illness risk and breaching occupancy fire codes.
- Insurance and liability gaps: if a facility lacks public-liability insurance or a formal use agreement is not signed by Month 2 (2026-12-08), the city faces litigation exposure if an incident occurs at an unstaffed or inadequately protected site.
- Utility underestimation: if water supply or sanitation capacity is not verified for continuous 10-hour occupancy, sites may run out of water or face toilet failures during peak alert days, forcing premature closures and resident evacuation.
- Spatial mismatch to vulnerable populations: if the 10 sites are located in affluent or central districts only, isolated and mobility-limited residents in peripheral neighborhoods will exceed the 800 m walking distance threshold, reducing actual reach by 20–30% and failing the equity intent.
- Remediation scope creep: if accessibility barriers are discovered after commitment (e.g., structural ramp required), remediation costs and timelines could exceed the €10k and 4-week thresholds, forcing site abandonment mid-setup and destabilizing the network footprint.
- Misalignment with refuge-hours assumption: if water, sanitation or utilities cannot support extended hours (24:00 at Level 3), the city cannot deliver the promised overnight cooling, reducing protection of hot-night mortality risk among elderly residents.

**Worst Case Scenario**: 
The city commits to 10 refuge sites without completing a full accessibility and capacity audit. Two sites (due to be large, central facilities) lack disability ramps and adequate sanitation and require €15k–20k and 6–8 week remediation. The audit is completed only in March (Month 5 = 2027-03-08), past the Month 2 (2026-12-08) readiness gate, leaving no time to fix the sites or find replacements. The city opens the refuges at 70% capacity (280 instead of 400 places) and cannot accommodate wheelchair users at three sites. During the first Level 3 alert in June, water supply fails at one site due to inadequate pressure, forcing evacuation of 80 residents mid-day. Media coverage frames the program as "inaccessible and unsafe." Enrollment collapses by 40%, outreach contact attempts drop to 3,000/month (from 5,000 planned), and the 60% contact-success gate fails. Reputational damage affects the scale decision and Year-2 funding is denied. Estimated reach loss: 900 residents; estimated legal cost: €50k–100k.


**Best Case Scenario**: 
A comprehensive, verified asset inventory is completed by Month 1 (2026-11-08), identifying 12 sites (8–12 planned), 450+ places, all with confirmed accessibility and utility capacity. Eight sites meet the fully accessible standard; two require <€8k remediation (ramping, toilet upgrade) on 2-week schedules; two are deferred or dropped. All sites are mapped against the vulnerability heat map, confirming ≥75% of enrolled residents within 800 m. Insurance, facility-use agreements and liability coverage are confirmed and signed by Month 2 (2026-12-08). Water-supply testing at each site confirms capacity for 10–24 hour continuous operation. Staffing and accessibility briefings occur without gaps. The first Level 3 alert in June opens all refuges at full capacity, water and sanitation function flawlessly, wheelchair and sensory-access accommodations are validated, and residents report feeling safe. Enrollment and contact rates hit 80% of target by Month 4 (2027-02-08). The scale gate is met. Documented accessibility and contingency infrastructure become a reusable model for other EU cities, strengthening the scaling playbook.


**Fallback Alternative Approaches**:

- If a comprehensive municipal inventory cannot be obtained by Month 0.5 (2026-10-23), engage a facility-assessment consultant (estimated cost €8k–12k, timeline 2–3 weeks) to conduct rapid site surveys and accessibility audits of the top 15 candidate facilities, prioritizing those already contracted or in frequent public use.
- If a single municipal facilities department cannot provide complete data, create a cross-departmental working group (libraries, sports/recreation, social services, public works) at Month 0 (2026-10-08) to pool facility ownership and operational information; designate one lead coordinator to compile a unified inventory by Month 1 (2026-11-08).
- If insurance or liability documentation is incomplete or outdated, require each site to obtain a renewal certificate of public-liability insurance (covering the heat-response activity) and a formal facility-use agreement signed by the facility owner/manager and the city legal department by Month 1.5 (2026-11-23); estimated cost €500–1,500 per site.
- If water-supply or sanitation capacity cannot be verified through existing utility records, conduct on-site water-pressure and flow tests (5–10 minutes per site) and a sanitation load assessment (occupancy × toilet ratio) in Month 1 (2026-11-08); estimated cost €1,500–2,500 for all sites; engage a municipal water/sanitation engineer.
- If accessibility audit findings exceed the €10k or 4-week remediation threshold for a site, immediately (by Month 1.5 = 2026-11-23) identify a backup facility (10–15 candidate replacements identified at Month 0 = 2026-10-08) and shift the refuge allocation; estimate 1–2 backup sites will be needed.
- If the spatial distribution of sites does not meet the 800 m walking-distance target for ≥70% of enrolled residents, augment the network with informal cool points (pharmacies, parish halls, shopping centers, sheltered housing) that are already air-conditioned and trusted by residents, requiring no new infrastructure investment but adding staffing coordination cost (estimated €50k–80k).
- If full 24-hour capability at three sites cannot be confirmed by Month 2 (2026-12-08), scale back to 10:00–22:00 hours at Level 2–3 and offer 24-hour transport-and-phone triage instead; this extends the transport model but keeps the refuge footprint viable.

## Find Document 4: Castellón de la Plana Baseline Heat-Related Mortality & Excess-Death Estimates

**ID**: 0bf77087-1fd6-46b3-ac5c-2546b74f0704

**Description**: Three-year historical data on deaths attributed to heat (ICD-10 code T67 or documentation of 'heat-related' in death certificate) or excess mortality during summer months (May-September) compared to expected seasonal baseline (e.g., via statistical/demographic methods). Used to establish baseline harm and to assess program attribution post-hoc. May be obtained from regional health authority, national health statistics office, or municipal vital statistics.

**Recency Requirement**: Most recent 3-5 years of data (2020-2025); supplement with 2010-2019 trend if available to establish longer-term patterns.

**Responsible Role Type**: Data and Evaluation Coordinator / Health Epidemiologist

**Steps to Find**:

- Contact regional health authority (SSVS) or Valencian public-health institute (Agencia de Salut Pública) for mortality data by cause of death, including heat-related codes (T67.0-T67.9).
- Request municipal vital statistics (registro civil) for death certificates with heat or heat-related condition notation.
- Search Spanish national health statistics portal (Instituto de Salud Carlos III) for Castellón excess-mortality or heat-attributable-death estimates.
- Contact university epidemiology department or research institute in Valencia region; they may have conducted prior heat-mortality studies with Castellón data.
- Request from national statistical office (INE) if mortality data by cause and municipality are published.

**Access Difficulty**: Hard. Mortality data are sensitive and privacy-protected. Individual death certificates are restricted-access. Aggregated mortality counts (by heat-code ICD-10 or monthly excess-death estimates) are more accessible via health authorities. University researchers may have already analyzed this data; a research partnership may accelerate access.

**Essential Information**:

- Confirm 3–5 years of historical heat-related mortality data (2020–2025) by ICD-10 heat codes (T67.0–T67.9) or death-certificate notation; provide annual counts, seasonal distribution (May–September focus), and geographic breakdowns by district or neighborhood within Castellón de la Plana.
- Establish baseline excess mortality during summer months using temperature-adjusted statistical methods (e.g., expected deaths minus observed deaths, or regression of deaths on temperature lagged 0–3 days); quantify 95% confidence intervals around baseline estimates to anchor uncertainty for Year-1 attribution analysis.
- Document data quality and coding consistency across years and providers (municipal vital records, regional health authority, EMS): identify gaps, coding rule changes, or incomplete records that may inflate or deflate baseline estimates by >10%.
- Provide demographic and geographic breakdowns of baseline by age bands (65–74, 75–84, 85+), living situation (alone vs. household), housing type (top-floor vs. ground, social vs. private), and neighborhood deprivation index or postal code to confirm vulnerability mapping used in the program design.
- List data custodians, access agreements, and confidentiality constraints; confirm whether aggregate counts (deaths by heat code) are openly available or require a data-processing agreement; specify retention period and deletion protocols post-evaluation.

**Risks of Poor Quality**:

- Incomplete or under-coded baseline (e.g., heat-related deaths coded as 'cardiovascular' rather than T67) will systematically underestimate true baseline, making any Year-1 program impact appear artificially large and undermining credibility of the scaling cost model when presented to peer EU cities.
- Inconsistent coding across years (e.g., 2020 excluded heat codes but 2021–2025 included them) introduces trend noise that cannot be distinguished from program effect, causing Month 4 (2027-02-08) attribution gates to fail or produce uninterpretable results.
- Missing or delayed access to data by Month 1 (2026-11-08) will delay coding-agreement meetings with EMS and health partners, pushing the MOU sign-off past the Month 2 (2026-12-08) readiness gate and preventing drill-based validation of daily aggregate reporting protocols.
- Baseline estimates with wide confidence intervals (e.g., ±30–50% around point estimate) or small cell counts in demographic subgroups will make it impossible to detect plausible program effects (15–25% reduction in heat deaths, estimate) with statistical power, weakening evaluation credibility and funder confidence in Year-2 funding decisions.
- Lack of geographic granularity (e.g., only city-wide totals, not by neighborhood) prevents the program from validating whether targeted intervention in high-risk districts achieved equity gains or merely reproduced prior patterns.

**Worst Case Scenario**: The program operates for 12 months, implements cooling centers, transport, outreach and home kits, and measures outcomes at Month 12 (2027-10-08). However, the baseline data are either unavailable, incomplete (coding gaps, missing years), or inconsistently defined. At evaluation, the team cannot distinguish program-driven mortality reduction from year-to-year noise or seasonal variation, and any claimed reduction (e.g., 20% fewer heat deaths) is challenged as unverifiable. The playbook is published with a caveat that attribution was not possible, undermining its credibility for other EU cities. Peer-city adoption is delayed or abandoned, and Year-2 funding (€2.3M, estimate) is withheld pending a stronger evaluation design, leaving the program unable to scale. Reputational damage: municipal government loses confidence in evidence-based health interventions.

**Best Case Scenario**: Baseline data are obtained by Month 1 (2026-11-08), coded consistently across years, with demographic and geographic breakdowns and 95% confidence intervals. The team validates the baseline via a partner audit at Month 1.5 (2026-11-23), achieves full coding agreement with EMS and hospitals by Month 2 (2026-12-08), and uses this to pre-specify the attribution analysis protocol. Daily aggregate reporting from health partners is validated during drills. At Month 12 (2027-10-08), evaluation shows plausible 12–18% reduction in heat-related EMS calls and 10–15% reduction in excess deaths with narrow confidence intervals. The playbook and scaling cost model are published with high credibility, attracting peer-city interest and securing Year-2 funding commitment from funder or new source. Program expands to city-wide by Month 15 (2028-01-08).

**Fallback Alternative Approaches**:

- If municipal vital-statistics records are unavailable or restricted-access, request aggregated excess-mortality estimates (observed minus expected deaths by month and age band) from the regional health authority (SSVS) or Valencian public-health institute (Agencia de Salut Pública), which may already have published this analysis for policy purposes.
- If historical EMS data by heat-code are not routinely extracted, commission a rapid retrospective review of EMS call records for Months 5–9 (2027-03-08 to 2027-07-08) of 2023–2025 using a simple triage form (call chief complaint, location, outcome, temperature that day); use the sample to estimate annual heat-call volume and seasonal pattern, accepting wider confidence intervals.
- If individual-level data access is blocked by privacy regulation, partner with a university epidemiology department or regional research institute (e.g., University of Valencia) that holds a data-use agreement with the health authority; they can compute baseline statistics under their institutional oversight and provide aggregate results to the city under a data-processing agreement.
- If baseline data collection will take >6 weeks and delay the Month 1 (2026-11-08) legal-review milestone, adopt a provisional baseline from published national or regional heat-mortality statistics (e.g., Spanish National Statistics Institute mortality tables) as a placeholder for drill planning and procurement; commit to replacing it with local data by Month 3 (2027-01-08).
- If demographic and neighborhood-level breakdowns of baseline cannot be linked to individual death records due to privacy constraints, use census and housing data to construct a vulnerability-weighted proxy baseline (e.g., age-stratified mortality rates applied to census age distribution in each neighborhood), which can be validated against aggregate totals and refined after Year 1.

## Find Document 5: Spanish & Valencian GDPR & Health-Data Protection Guidance

**ID**: 88109013-c68c-4514-9aae-15c88b189001

**Description**: Official regulatory guidance from Spanish Data Protection Agency (AEPD) and regional health authorities on: lawful basis for processing health data for public-health emergencies (Article 6 GDPR), consent requirements and withdrawal procedures (Article 7), data-processing agreements (Article 28), and special-category data rules (Article 9). Clarifies whether heat-alert contact is a 'public task' (Article 6(1)(e)) or requires explicit consent, and how intermediary-held health data (housing associations, social services) is governed.

**Recency Requirement**: Current GDPR guidance (2021 or later); AEPD published criteria or decisions preferred.

**Responsible Role Type**: GDPR Compliance Officer / Legal Counsel

**Steps to Find**:

- Visit Spanish Data Protection Agency (AEPD) website (aepd.es) and search for guidance on health data, public-health emergencies, and intermediary data sharing; download published documents and criteria.
- Request AEPD published decisions or opinions on heat-alert contact lawful basis (may be available as case studies or FAQ).
- Contact AEPD directly via email or phone for guidance on whether the intermediary-held-list model complies with Spanish law (they may issue formal written guidance).
- Search Valencian regional law (Generalitat Valenciana) for any regional data-protection guidance or health-privacy guidance (beyond national GDPR).
- Review Catalan Data Protection Authority (APDCAT) or other Spanish regional authority guidance for heat or emergency health contexts; may be transferable precedent.
- Consult with municipal legal department or GDPR counsel for case law or AEPD decisions on public-health and emergency-context data processing.

**Access Difficulty**: Easy to Medium. AEPD website has public guidance in Spanish; English translation may be needed. AEPD accepts guidance requests but response time varies (2-8 weeks). Regional authorities may have fewer published resources. Legal counsel familiar with Spanish GDPR practice is helpful.

**Essential Information**:

- Clarify whether heat-alert contact to intermediary-held residents (housing associations, social services, NGOs, pharmacies) qualifies as a 'public task' under GDPR Article 6(1)(e) or requires explicit consent under Article 7, and under which Spanish/Valencian legal authority.
- Define the lawful basis and data-processing chain for aggregate heat-related EMS and ED counts shared daily from hospitals and EMS to the city incident commander (Article 6 GDPR and Spanish health-privacy law equivalents).
- Specify retention periods, deletion procedures and conditions for re-consent if heat-alert operations continue into Year 2 beyond the initial 12-month pilot.
- Confirm whether data-processing agreements (Article 28 GDPR) with intermediary partners are mandatory or whether a simpler MOU suffices if no personal data is transferred to the city.
- Identify AEPD published decisions, guidance documents or case studies on heat emergencies, public-health alerts or intermediary-held health data to support the legal interpretation.
- State the procedure and timeline for notifying AEPD (or regional equivalent) if a data breach occurs during outreach (e.g., partner staff misconduct, accidental disclosure).

**Risks of Poor Quality**:

- Inaccurate or outdated GDPR guidance could lead to a legal challenge from data subjects or AEPD, delaying partner sign-off by 2–4 weeks and forcing redesign of the outreach model mid-implementation (Month 1–2 = 2026-11-08 to 2026-12-08 readiness gate risk).
- If the lawful basis is unclear, housing associations, social services or NGOs may withdraw from partnerships, reducing outreach reach by 10–25% and failing the Month 4 (2027-02-08) 60% contact-success gate.
- Guidance that incorrectly interprets Spanish data-protection law (beyond GDPR) could expose the city to additional liability under regional regulations, incurring unexpected legal fees (€15,000–30,000) and reputational damage.
- Missing guidance on breach notification timelines could cause the city to miss AEPD reporting deadlines (48 hours), triggering regulatory penalties and media scrutiny.
- Absence of precedent or case studies on heat emergencies could force reliance on generic GDPR guidance, leaving ambiguities about risk allocation between city and intermediary partners unresolved, leading to disputes during the season.

**Worst Case Scenario**: The city proceeds with the intermediary-held-list model without legal clearance, believing the 'public task' basis is solid. In June–July, a partner (e.g., housing association) faces AEPD scrutiny or a resident complaint about data handling. AEPD issues a provisional halt to data sharing pending investigation (typical 2–8 weeks). Outreach contact attempts drop from 5,000/month to 500–1,000/month, failing the 60% contact-success gate. The €1.5M scale funding is withheld at Month 4 (2027-02-08). The city must halt or drastically reduce operations by August during peak summer heat risk, leaving 1,500–2,000 enrolled residents without check-in support. Estimated harm: 5–15 preventable excess deaths in the unprotected population; legal remediation and potential fines €50,000–100,000; program credibility destroyed for Year 2 and EU scaling.

**Best Case Scenario**: AEPD or regional authority issues clear, published guidance by Month 1 (2026-11-08) confirming the intermediary-held-list model complies with Spanish law under the 'public task' basis, with specific language on retention and deletion. Template data-processing agreements are provided or confirmed as unnecessary. Partners (housing associations, social services, NGOs) sign MOUs by Month 1.5 (2026-11-23) with confidence. Outreach proceeds uninterrupted through the season, achieving ≥60% contact success and meeting the Month 4 (2027-02-08) gate. The €1.5M scale funding is released on schedule. The playbook documents this legal pathway as a reusable precedent for other EU cities, reducing their legal-review timeline and cost by 50% and accelerating pan-European adoption of the heat-response model.

**Fallback Alternative Approaches**:

- Obtain a formal written GDPR legal opinion from a specialist Spanish data-protection counsel by Month 0.5 (2026-10-23) if AEPD guidance is unavailable or delayed. Budget €15,000–30,000 and use the opinion as the basis for partner MOUs; this is slower than published guidance but provides contractual liability protection.
- Shift to a consent-based registry model (opt-in enrollment through GPs, pharmacies and cooling centers) if the public-task interpretation is rejected. This reduces legal risk but lowers reach to isolated, offline residents by an estimated 15–25%; combine with building-level canvassing via local sentinels to recover reach (adds €100,000–150,000 in outreach staffing and 4–6 weeks of timeline).
- Request a formal AEPD guidance opinion via the agency's guidance-request process (typically 4–8 weeks); parallel this with legal counsel drafting interim MOUs so that no delay occurs if AEPD response is slow.
- Engage a regional university law school or public-health research center as a partner to co-author a position paper on heat-emergency data sharing and submit it to AEPD as a reference; this builds precedent and may accelerate clarity (timeline 6–10 weeks, cost €5,000–10,000 co-funding).
- Pilot the intermediary-held-list model with one trusted partner (e.g., the largest housing association or social service) in Month 1–2 (2026-11-08 to 2026-12-08) under informal data-sharing practices, gather 2–4 weeks of operational data on partner capacity and resident response, then formally obtain legal clearance and scale to all partners by Month 3 (2027-01-08). This de-risks the model with evidence but delays full-scale outreach by 3–4 weeks.

## Find Document 6: EU & Spanish Public Procurement Rules & Thresholds (2024-2025)

**ID**: 27dfc82c-e0be-46ce-a7c8-90f12cae8251

**Description**: Current EU public-procurement directives (2014/24/EU, 2014/25/EU) and Spanish national transposition (LCSP - Ley de Contratos del Sector Público) specifying procurement thresholds (below-threshold vs. tender-required amounts), simplified procedures for emergency or low-value purchases, framework-agreement rules, and audit requirements. Used to determine legal procurement route for cooling kits, transport, and handyperson services within the €3.5M budget.

**Recency Requirement**: Current (2024-2025); Spanish LCSP as amended 2023-2024; EU Directive 2014/24/EU.

**Responsible Role Type**: Municipal Procurement Officer / Contract Law Specialist

**Steps to Find**:

- Download Spanish public-procurement law (LCSP, Ley 9/2017) from official government source (boe.es).
- Search Spanish Public Sector Contracts Board (Junta de Contratación del Sector Público) website for current thresholds, guidance, and case studies.
- Download EU Directive 2014/24/EU (Procurement Directive) and its preamble from EUR-Lex.
- Contact Spanish municipal association (FEMP) or local municipal procurement office for practical guidance on below-threshold purchasing and framework-agreement procedures in Spain.
- Search for OECD or EU publications on emergency procurement procedures (may be relevant if heat response is framed as emergency/public-health urgency).

**Access Difficulty**: Easy. Spanish law is public and available via boe.es; EU directives are on EUR-Lex. Municipal associations provide practical templates and training. Complexity is moderate; a municipal procurement officer or external legal counsel familiar with Spanish rules is helpful.

**Essential Information**:

- Identify the current EU and Spanish public-procurement regulatory framework (Directives 2014/24/EU, 2014/25/EU and LCSP transposition) applicable to the city of Castellón de la Plana in 2024–2025.
- Quantify the euro thresholds that trigger mandatory competitive tender vs. simplified/below-threshold procurement for each purchase category (cooling kits, transport retainer, handyperson services, refuge fit-out, security contracts).
- Determine which procurement pathways (framework call-offs, below-threshold direct award, simplified emergency procedures, competitive tender) are available to meet the Month 2 (2026-12-08) readiness gate without violating audit requirements.
- Document the audit-readiness requirements for each pathway: file documentation, competitive justification, price benchmarking, single-source authorization, and record retention.
- Clarify whether heat-response can be framed as an emergency or public-health urgency under Spanish law to justify expedited or non-competitive procedures.
- Specify template contract language required under LCSP for framework agreements and standby retainers (e.g., minimum capacity guarantees, call-off procedures, price escalation caps).
- Identify any Spanish municipal-association (FEMP) or regional government guidance on procurement templates or pre-vetted supplier lists for kits, transport, or security services.
- Define the liability and audit exposure if the city uses below-threshold purchasing repeatedly to avoid transparency or competitive bidding, and what documentation mitigates this risk.

**Risks of Poor Quality**:

- If thresholds are misunderstood or applied inconsistently, orders may be challenged as non-compliant, forcing re-tendering mid-season and delaying delivery by 4–8 weeks past the Month 2 (2026-12-08) gate.
- Lack of audit-ready documentation (e.g., missing competitive justification for sole-source awards, price benchmarking, or call-off records) exposes the city to regulatory audit findings, reputational damage and potential contract invalidation.
- Ambiguity on whether heat-response qualifies for emergency-procurement exemptions could lead to legal challenge by excluded bidders, tying up resources in dispute resolution.
- If handyperson, kit or transport contracts lack proper LCSP-compliant escalation-cap clauses, summer demand spikes could trigger cost increases of €50k–150k, forcing mid-season service cuts.
- Repeated use of below-threshold purchasing without transparent competitive process invites scrutiny from auditors, EU funder reviews and political opponents, undermining the program's credibility.
- Template contract language that fails to align with LCSP requirements (e.g., standby-retainer guarantees, call-off procedures, payment terms) could result in supplier disputes, non-performance claims or cost disputes during alert days.

**Worst Case Scenario**: The city misapplies procurement thresholds or uses expedited procedures without proper legal basis, triggering an audit finding or legal challenge by an excluded bidder. Contracts are invalidated mid-season; retenders delay kit delivery and transport contracting past March, preventing home interventions and forcing the transport model to taxi-only at +€150k–250k cost. Schedule slip of 4–8 weeks forces closure of Month 2 (2026-12-08) readiness gate. €1.5M scale funding is withheld. Program credibility erodes; playbook reuse by other EU cities is compromised. Estimated financial and reputational cost: €50k–100k legal remediation + €150k–250k operational overrun + loss of scaling opportunity.

**Best Case Scenario**: Clear, auditable procurement pathways are documented by Month 0.8 (2026-11-01), thresholds and justifications are pre-vetted by legal counsel, and a hybrid strategy (frameworks for speed, competitive tenders for tranche 2) meets the Month 2 (2026-12-08) gate without audit exposure. All kit and transport orders are placed by Month 2 (2026-12-08), delivery milestones are met by April, and home interventions and transport are operational by May. Procurement is transparent and replicable; other EU cities adopt the same templates and procedures, reducing their procurement time and risk. Public trust in municipal governance is strengthened. Program meets all gates and scales successfully.

**Fallback Alternative Approaches**:

- Engage a specialized Spanish public-procurement law firm by Month 0 (2026-10-08) (cost ≈€15k–30k) to provide written legal opinion on thresholds, eligible procedures, audit requirements and template contracts. Use the opinion to justify procurement decisions in writing and build audit-ready files.
- Contact the Spanish municipal association (FEMP) and request template procurement files, supplier pre-qualification lists, and guidance on heat-response emergencies. FEMP may have published case studies or model tenders for similar services.
- Consult the regional government (Generalitat Valenciana) procurement office to clarify whether regional or national frameworks for emergency public health exist, and whether they offer pre-qualified supplier lists or expedited procedures.
- Identify whether Castellón de la Plana has an existing municipal procurement framework (e.g., for energy, transport, or facilities management) that can be leveraged via call-off orders rather than new tenders.
- If competitive tendering cannot be completed by Month 2 (2026-12-08), split procurement into two phases: place 30–40% of kits and transport via below-threshold or framework by Month 1.2 (2026-11-14), then conduct a full competitive tender for the remainder starting Month 2 (2026-12-08), with delivery expected by Month 5 (2027-03-08). Document the split as a staged delivery strategy, not as avoidance of competition.
- Request a waiver or confirmation letter from the local EU funder (likely a national or regional ministry) clarifying whether the heat-response program qualifies for public-health emergency treatment under procurement rules, and in writing.

## Find Document 7: Castellón de la Plana NGO & Social Services Directory (Housing Associations, Social Care, Homeless Services, Migrant Organizations)

**ID**: b501f078-895b-4278-b459-d0b4227342d4

**Description**: Comprehensive list of local non-governmental and community organizations, including: housing associations/cooperatives (vivienda social), social services (servicios sociales), homeless or rough-sleeping services, migrant integration organizations, faith-based groups, and language/cultural associations. Includes contact names, phone, email, service scope, and current client base. Used to identify and engage partners for intermediary-held outreach, street contact, language access, and community trust-building.

**Recency Requirement**: Current (2024-2025); update annually; some turnover in staff/leadership expected.

**Responsible Role Type**: Partner Liaison Officer / Community Engagement Lead

**Steps to Find**:

- Contact Castellón municipal social services department for official registry of partner organizations and referral networks.
- Request municipal integration or migration office directory of migrant associations and support organizations.
- Search online directories: Plataforma del Voluntariado de España (Spanish volunteer directory), Guía del Tercer Sector (Spanish NGO directory), and regional Valencian NGO networks.
- Contact Castellón archdiocese or religious affairs office for list of faith-based organizations (mosques, churches, synagogues) active in social care.
- Inquire with municipal housing authority about housing associations and their outreach/welfare roles.
- Request homeless-service NGO directory from Castellón social services or regional authorities.

**Access Difficulty**: Easy to Medium. Municipal social services maintain partner registries (usually shared readily). Online directories and faith organizations are publicly listed. Contact details may be incomplete; direct phone verification needed.

**Essential Information**:

- Identify and list all active housing associations, social cooperatives (vivienda social) and social-housing managers operating in Castellón de la Plana with current contact names, phone numbers, email addresses, service areas and estimated client bases (target: 5-10 organizations).
- Obtain complete registry of municipal and regional social services offices (servicios sociales) with department heads, phone, email and service scope (elderly care, disability support, family services); confirm which offices manage outreach capacity for heat-alert campaigns.
- Compile comprehensive directory of homeless-services NGOs, rough-sleeping outreach teams and emergency shelter operators active in Castellón, including overnight shelter capacity, day-center locations, current client counts and outreach staff rosters.
- Locate and verify 4-6 migrant-integration organizations, language associations and cultural centers serving non-Spanish speaking communities (Arabic, Romanian, Portuguese speakers confirmed; others TBD at Month 0 = 2026-10-08), including staff, current client populations and existing community-trust relationships.
- Obtain contact details and social-mission descriptions for all active faith-based organizations (Christian churches, mosques, synagogues, other faiths) engaged in social outreach or welfare services in Castellón.
- Identify public libraries, community centers, parish halls and other existing assets (owners, facility managers, opening hours, accessibility status, water and toilet provision, security arrangements) suitable for conversion to cooling refuges.
- Document any existing data-sharing or welfare-referral partnerships between organizations (e.g., housing association → social services → NGO → pharmacy chains) to understand formal consent and data-handling agreements already in place.
- Confirm which organizations hold lawful bases (contractual duty, existing consent frameworks or public-task authority) for contacting their own clients or residents, and which would need new consent or data-processing agreements under GDPR.
- Quantify total potential reach: sum of enrolled clients, residents and service users across all identified partner organizations to validate whether 3,000 enrolled high-risk residents by Month 7 (2027-05-08) is achievable.
- Identify any known gaps in geographic coverage (neighborhoods or populations underserved by existing organizations) to inform recruitment of additional partners or direct municipal outreach.

**Risks of Poor Quality**:

- Incomplete or outdated partner directory means some high-risk residents will not be identified or contacted, reducing outreach reach below the 60% contact-success gate (Month 4 = 2027-02-08) and equity coverage by neighborhood.
- Inaccurate contact details (wrong phone, departed staff) lead to failed enrollment calls, wasting outreach capacity and delaying partner engagement, compressing the hiring and training timeline before Month 2 (2026-12-08).
- Missing or incorrect data on partner organization lawful bases and consent frameworks forces redundant GDPR vetting and delays MOU signature, potentially pushing data-processing agreements past the Month 1.5 (2026-11-23) deadline.
- Underestimating partner capacity (e.g., not knowing a housing association manages 8,000 residents) leads to unrealistic outreach targets and partner fatigue, causing mid-season partner dropout and loss of 10-20% of planned contacts.
- Failure to map existing data-sharing agreements and trust relationships causes duplicate consent requests or partner confusion about consent scope, eroding community trust and NGO cooperation.
- Unverified accessibility or facility information for proposed cooling-refuge sites (e.g., library lacking wheelchair access, parish hall lacking water) forces late-stage site remediation or substitution, jeopardizing the Month 2 (2026-12-08) readiness gate.
- Missing information on migrant-community organizations and language capabilities means language-access targets (≥5% of outreach in non-official languages, Month 4 = 2027-02-08) are unachievable, failing equity metrics.
- Lack of clarity on faith-leader involvement and trust relationships slows recruitment of trusted messengers, reducing uptake of communications and enrollment among faith-affiliated residents.

**Worst Case Scenario**: 
If the directory is incomplete, inaccurate or outdated, the outreach model collapses. Partner organizations cannot be contacted reliably, delaying engagement by 2-4 weeks and compressing MOU negotiation into a 2-week window before Month 2 (2026-12-08). Critical partners (social services, housing associations) may withdraw if GDPR concerns are not pre-cleared, reducing reach by 15-25% and invalidating the 3,000-enrollment target. Geographic gaps mean entire neighborhoods of vulnerable residents (e.g., migrant enclaves, homeless populations) are missed. A failed refresh of the directory mid-season (staff turnover in partner organizations) could orphan the outreach operation by July, collapsing the 60% contact-success gate and forcing the program to rely solely on self-enrollment at refuges, reducing demonstrated harm reduction and jeopardizing the Month 4 (2027-02-08) scale release of €1.5M.


**Best Case Scenario**: 
A current, verified directory with 50+ confirmed partner contacts enables rapid, parallel partner engagement from Month 0 (2026-10-08). GDPR compliance is pre-cleared via legal review of existing consent frameworks, accelerating MOU signature by Month 1 (2026-11-08). Outreach targets and partner capacity are realistic, lowering mid-season fatigue and dropout. Mapping of existing data-sharing agreements avoids consent redundancy and builds on established trust. Cooling-refuge sites are pre-verified for accessibility and facility readiness, eliminating remediation delays. Migrant organizations are identified and briefed early, enabling 8-12 community ambassadors to be recruited, vetted and trained by Month 2 (2026-12-08), supporting language-access targets. Faith-leader networks accelerate trusted-messenger recruitment. By Month 4 (2027-02-08), 3,000+ high-risk residents are enrolled and 60%+ are contacted, gates are met, and the program scales with credibility across EU peer cities.


**Fallback Alternative Approaches**:

- If municipal registry is outdated or incomplete, conduct rapid community canvas by Month 0.5 (2026-10-23): partner liaison officer and 2-3 community volunteers visit neighborhoods, query libraries, pharmacies, post offices, markets and faith centers by phone and in-person to build a current contact list. Budget: €3k-5k; timeline: 2-3 weeks.
- If formal social-services registry is unavailable, request the municipal integration officer or health department to provide names and phone numbers of known social organizations and programs; cross-check against online directories (Plataforma del Voluntariado de España, regional NGO databases, Linkedin searches for organization staff).
- If housing-association data is fragmented across municipal housing authority and regional cooperatives, issue a formal information request (solicitud de acceso) by Month 0 (2026-10-08) to municipal housing authority and regional government housing office, with 10-day statutory response time.
- If faith-organization contacts are weak, contact the Castellón archdiocese, the regional Islamic Federation (FEERI), and municipal religious affairs office for list of registered congregations and their social-outreach leaders; follow with phone verification of active programs.
- If migrant-community organizations are sparse in the directory, engage the municipal integration office (oficina de inmigración) or regional integration authority to request names and contacts of established migrant associations; cross-check census data on non-Spanish speakers by neighborhood to identify likely locations for targeting outreach.
- If partner data-governance frameworks are unclear, conduct a rapid 30-minute legal screening call with GDPR counsel (Month 0.5 = 2026-10-23) to identify which partners likely have lawful bases (public-task welfare duties, existing client consent) and which require new consent; use findings to prioritize GDPR vetting.
- If partner outreach capacity is reported as uncertain or minimal, propose a small pilot engagement with 2-3 partners (e.g., one housing association, one NGO, one pharmacy chain) in Month 1 (2026-11-08) to test call volumes and success rates before scaling to all partners; adjust targets and recruitment based on pilot results.
- If accessibility or facility readiness data for proposed refuge sites is missing, conduct a rapid site survey by municipal facilities/accessibility officer and partner liaison officer in Month 1 (2026-11-08): checklist inspection (ramps, toilets, water, AED, parking) of each proposed site, documented with photos and remediation cost estimates; drop or defer sites requiring >€10k remediation or >4 weeks work (per threshold).
- If cooling-refuge sites prove inadequate after survey, activate contingency site list (e.g., larger malls with seasonal tenants, municipal sports halls with off-season availability, temporary modular cooling units if budget allows); re-plan network footprint by Month 1.5 (2026-11-23).
- If the directory cannot be completed by Month 0.5 (2026-10-23), proceed with identified partners (50-70% of initial target) by Month 1 (2026-11-08) and backfill additional partners by Month 2 (2026-12-08); accept a 5-10% reduction in enrolled-resident target and geo-coverage to avoid delaying GDPR vetting and partner engagement.

## Find Document 8: Cooling Kit Suppliers & Availability (Exterior Shading, Reflective Blinds, Fans, Thermometers)

**ID**: 5e244756-36a0-4a28-a693-3aeede639bd9

**Description**: Supplier market survey for home-kit components: manufacturers or distributors of exterior shading/blinds, window fans, digital thermometers, and hygrometers available in Spain or Europe; unit costs, minimum order quantities, lead times (weeks to delivery), expedite options, and product specifications (quality, durability, safety standards for fans). Used to finalize kit procurement specifications and budget, and to validate whether €800k is sufficient for 2,000 homes.

**Recency Requirement**: Current pricing & availability (2024-2025); valid for 2-3 months lead time.

**Responsible Role Type**: Home Interventions and Handyperson Coordinator

**Steps to Find**:

- Conduct online search for EU/Spanish suppliers of: exterior aluminum blinds/shading (e.g., Bandalux, Gradus, Hunter Douglas, or local Spanish brands), reflective window treatments, directional window fans (6-8 inch, safe for elderly use), and digital thermometer/hygrometer kits.
- Request quotes from ≥3 suppliers per component (shading, blinds, fans, thermometers) for bulk orders (600-2,000 units); specify quality standards (safety, durability), lead time, and per-unit cost.
- Check if municipal procurement framework agreements already exist for energy-efficiency or home-improvement kits; may allow faster ordering.
- Request lead-time and expedite-cost information for Q1-Q2 2027 (Feb-May 2027) delivery to align with project schedule.
- Inquire about bulk discounts, payment terms, and product warranties.

**Access Difficulty**: Medium. Supplier information is available online or via direct contact; competition is moderate. Pricing varies by supplier, quality, and order size; multiple quotes are essential for cost validation.

**Essential Information**:

- Identify supplier options for exterior aluminum shading/blinds (e.g., Bandalux, Gradus, Hunter Douglas, local Spanish brands) with unit costs, minimum order quantities and lead times (weeks to delivery) for bulk orders (600–2,000 units).
- Confirm availability and lead times for 6–8 inch directional window fans safe for elderly use, with safety certifications (CE, UL or equivalent) and durability specifications.
- List digital thermometer/hygrometer kits suitable for distributed placement; specify accuracy, display readability for vision-impaired users and battery life.
- Obtain quotes from ≥3 suppliers per component (shading, blinds, fans, thermometers); compare per-unit cost, bulk discounts, payment terms and product warranties.
- Verify whether municipal procurement framework agreements already exist for energy-efficiency or home-improvement kits that could accelerate ordering.
- Confirm expedite-cost premium (% markup) and feasibility of Q1–Q2 2027 delivery (February–May 2027) to align with project home-installation schedule.
- Validate whether €300 per-home cost assumption (€250 hardware + €50 installation labour) is achievable under current market conditions or requires adjustment.
- Identify backup suppliers (2–3 per category) to mitigate single-source delay risk, with lead times and alternative product specifications.

**Risks of Poor Quality**:

- Supplier quotes not obtained by Month 0.8 (2026-11-01) delay first call-off order to after Month 1.5 (2026-11-23), pushing 40–50% kit delivery past Month 4 (2027-02-08) and home installations beyond May–June peak-risk season; estimated delay 4–8 weeks and lost mortality protection.
- Inaccurate cost data (e.g., suppliers quoting higher per-unit prices than budget assumed) reveals a shortfall in the €800k home-kit allocation mid-procurement, forcing cuts to kit quantity (500–1,000 fewer homes) or quality, or triggering budget reallocation that defunds transport or outreach.
- Supplier lead times longer than 4–6 weeks (e.g., 8–10 weeks from Asian supply-chain issues) make February delivery impossible without expensive expedite premiums (10–15%, €50k–100k estimate), exhausting contingency reserve.
- Fan products lacking proper safety certifications or durability for Mediterranean climate (e.g., corrosion in salt air) lead to resident safety incidents, liability claims or equipment failures mid-season requiring replacement.
- No identified backup suppliers means a single-source production delay or supplier bankruptcy forces abandonment of that component or sourcing at emergency premium costs.
- Missing framework agreement research causes re-procurement from scratch using slower competitive tendering, delaying orders by 3–4 weeks and missing the Month 2 (2026-12-08) readiness gate.

**Worst Case Scenario**: Supplier availability survey is delayed or returns inadequate data (no confirmed quotes, lead times >8 weeks, per-unit costs 20–30% higher than budgeted). The project cannot place first call-off orders by Month 1.2 (2026-11-14) and misses the Month 2 (2026-12-08) readiness gate procurement deadline. Home kits do not arrive until May–June at earliest, leaving no time for installation before summer peak-heat season (Months 6.8–11.8 = 2027-05-08 to 2027-10-08). Project is forced to cut kit scope from 2,000 homes to <1,000 or abandon home interventions entirely, reducing estimated mortality protection by 15–25% and failing to meet equity targets for top-floor and social-housing priority units. Budget shortfall of €100k–200k forces cuts to transport retainer or outreach staffing, jeopardizing the Month 4 (2027-02-08) gates and credibility of the pilot.

**Best Case Scenario**: Supplier survey identifies 3–4 competitive suppliers per component by Month 0.8 (2026-11-01) with per-unit costs within or below budget (€250 hardware), lead times 4–6 weeks, and established frameworks or bulk-discount terms. First call-off order for 600–800 kits (30–40% of 2,000) placed by Month 1.2 (2026-11-14) with expedite delivery to February; 40–50% stock in place by Month 4 (2027-02-08) allows installation pipeline to reach 80% completion by Month 7.3 (2027-05-17), covering 1,600 homes before and during peak summer heat. Backup suppliers identified and pre-qualified reduce single-source risk. Full-scale home-intervention coverage meets equity targets for top-floor and social-housing priority units. Cost savings from early competitive bidding preserve €50k–100k of contingency for other risks.

**Fallback Alternative Approaches**:

- If lead times >6 weeks: negotiate expedite fees (10–15% premium, €50k–100k estimate) with top 2–3 suppliers for February delivery to maintain timeline; absorb cost within the €800k home-kit budget or draw from contingency.
- If per-unit costs 15–20% above budget: reduce target kit quantity from 2,000 to 1,500–1,700 homes, prioritizing top-floor and social-housing units; scale lower without proportionally reducing installation quality.
- If preferred suppliers unavailable or backlogged: activate 2–3 pre-identified backup suppliers by Month 0.8 (2026-11-01) and conduct parallel procurement (split order across suppliers) to diversify risk and ensure volume.
- If municipal frameworks do not exist: conduct a fast competitive tender in two lots (shading/blinds in one lot, fans/thermometers in another) by Month 1 (2026-11-08), with 2-week turnaround to place orders by Month 1.5 (2026-11-23).
- If installation costs higher than €50/unit: negotiate fixed-price handyperson contracts by Month 1.5 (2026-11-23) or train municipal or volunteer installers (2–3 week ramp) to reduce labour cost.
- If no home kits available by April: defer non-priority (lower-scoring rubric) installations to Year 2 or shift to a seasonal lending scheme (May install, September collection) to stretch existing stock across multiple summers and reduce upfront procurement burden.