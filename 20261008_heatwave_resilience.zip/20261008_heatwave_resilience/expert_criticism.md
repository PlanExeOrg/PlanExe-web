# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Municipal Public Health & Heat Action Coordinator

**Knowledge**: Public health program design, heat-health equity, vulnerable-population epidemiology, EU public-health regulation, municipal health systems, evaluation methodology for small-area health outcomes

**Why**: The plan's foundation rests on identifying and reaching vulnerable groups (65+, chronic disease, living alone, migrants) and measuring heat-related harm (EMS, ED, excess mortality). This expert advises on baseline data validation, equity metrics design, and whether the intermediary-list model actually reaches the most isolated residents, addressing a critical open question in the plan.

**What**: Review the outreach model (intermediary-held lists, 3,000 enrolled target, 60% contact gate) and baseline estimates (80–120 EMS calls, 15–25 excess deaths), then propose a health-equity audit framework to confirm reach parity across neighborhoods, age bands, and housing type by Month 9 (2027-07-08).

**Skills**: Population health assessment, equity metrics, health data governance, vulnerable-population engagement, EMS/ED coding standards, excess-mortality attribution

**Search**: municipal heat action coordinator, public health equity epidemiologist, vulnerable population health outcomes, EU climate health program

## 1.1 Primary Actions

- By Month 0.95 (2026-11-06), obtain written funder sign-off on the drill-based gate criteria and the 50% partial-release rule (€750k at Month 4 = 2027-02-08 if evidence is insufficient, remainder after Month 5 = 2027-03-08 re-test). Document the funder's acceptance of the cool-season testing limitation in a decision memo. If the funder refuses, convene an emergency steering meeting to rescope the gates or defer the scale decision to Month 5 (2027-03-08).
- By Month 1.08 (2026-11-10), issue detailed procurement specifications for cooling kits (products, quantities, lead times, acceptance criteria) to 3 primary suppliers and 2 backup suppliers. Request quotes and delivery commitments by Month 0.95 (2026-11-06). By Month 1.15 (2026-11-13), sign backup-supplier agreements with automatic activation triggers (>2-week primary-supplier slippage) and pre-authorized premium fees (up to 10% cost increase). Place the first-tranche order (30–40% of kits, 600–800 units) by Month 1.2 (2026-11-14); confirm delivery schedule or escalate to backup by Month 1.5 (2026-11-23).
- By Month 1 (2026-11-08), conduct a partner capacity audit: survey housing associations, social services, NGOs and pharmacies to establish baseline call-center staffing, call time per resident, and summer turnover rates. By Month 1.5 (2026-11-23), agree in partner data-processing agreements on minimum staffing reserves (80% availability during alert season), daily contact logging (aggregate only, no identifiable data), and an escalation trigger if <60% are reached within 4 hours of Level 2 alert. By Month 3.2 (2027-01-14), during the full-system drill, measure actual contact rates; if <60%, adjust the gate to 55–58% or activate additional outreach resources; brief the funder by Month 3.5 (2027-01-23).
- By Month 0.8 (2026-11-01), name the incident commander (mayor's office), public-health deputy, operations lead (civil protection), communications lead and partner-coordination lead in writing. Obtain mayoral delegation of authority by Month 1 (2026-11-08). These roles are prerequisites for the remaining procurement and hiring actions to proceed.
- By Month 0.5 (2026-10-23), engage a specialist GDPR law firm (€15–30k budget) to review the intermediary-held-list model and draft partner data-processing agreements. Obtain written legal opinion by Month 1 (2026-11-08) confirming GDPR compliance and whether a formal Data Protection Impact Assessment is required. Finalize and execute partner agreements by Month 1.5 (2026-11-23); brief all partner staff (50–80 people) on GDPR obligations and confidentiality by Month 2 (2026-12-08).

## 1.2 Secondary Actions

- By Month 0.95 (2026-11-06), launch volunteer driver recruitment via municipal website, GP practices, NGO networks and faith organizations; target 30–50 volunteers. Issue vetting requirements (background check, insurance, safeguarding training) and set cohort milestones: ≥15–20 vetted and in-post by Month 2 (2026-12-08), remainder by Month 3 (2027-01-08). Establish an HR coordinator (0.5 FTE) by Month 0.5 (2026-10-23) to manage hiring and vetting timelines.
- By Month 0.95 (2026-11-06), issue procurement specifications for taxi/accessible-transport standby retainers and request firm quotes for alert-day capacity (≥10 vehicles, ≥3 wheelchair-capable, ≥20-min response time). Negotiate and sign the retainer contract by Month 1.2 (2026-11-14) with a capped cost of €80k per season and 48-hour cancellation notice if heat events do not materialize.
- By Month 0.95 (2026-11-06), identify and contact 8–12 proposed cooling-center sites (libraries, community centers, parish halls, sports facilities). By Month 1.15 (2026-11-13), execute facility-use MOUs specifying hours (minimum 10:00–20:00 daily at Level 2–3), staffing, security, and liability insurance. By Month 1.5 (2026-11-23), conduct accessibility audits (wheelchair ramps, accessible toilets, quiet rooms, water, signage); remediate gaps ≤€10k and ≤4 weeks or categorize as 'defer to July'. Ensure ≥50% of planned capacity is fully accessible by Month 2 (2026-12-08).
- By Month 0.95 (2026-11-06), contract a telephone answering service or repurpose municipal health-line capacity for the heat-alert helpline (08:00–22:00 daily during alert season, 24-hour at Level 3). Hire 2–3 part-time phone operators (30 hours/week) fluent in Spanish and ≥1 non-official language by Month 1.5 (2026-11-23). Conduct 4-hour training on escalation protocols and cooling-center information by Month 2 (2026-12-08). By Month 2.5 (2026-12-23), run a mock helpline drill (5–8 transport requests, 3–5 escalations) to validate readiness.
- By Month 1 (2026-11-08), negotiate an MOU with hospitals, EMS and primary-care providers for daily aggregate heat-related ED and EMS call counts (no identifiable patient data). Define agreed coding (e.g., ICD-10 T67.0–T67.9 for heat illness). Conduct a 2-week validation pilot starting Month 1.8 (2026-12-02) to test data feeds. Establish a nurse-advice line for outreach staff triage by Month 2 (2026-12-08). Set escalation thresholds: notify the incident commander at ≥1.5× historical average heat volume; consider mutual-aid at ≥2×. Document in a signed protocol by Month 2 (2026-12-08).
- By Month 1.5 (2026-11-23), finalize the heat-illness escalation checklist with a senior emergency-medicine clinician. Train all 25–35 planned outreach and street-contact staff on recognition, decision rules (when to call 112 vs phone triage), and de-escalation language by Month 1.5 (2026-11-23). Conduct role-play scenarios (15 vignettes) and require written test (≥80% pass) before alert-day authorization. Log attendance and refresh training in May (Month 8 = 2027-06-08).
- By Month 1 (2026-11-08), co-design a street-contact protocol with local homeless-service NGOs for alert-day rounds to unhoused residents. Define consent models for acute heat illness, off-duty procedures if staff are threatened, and escalation rules. By Month 1.5 (2026-11-23), complete background checks and safeguarding-training certification (3-hour module on de-escalation, trauma-informed care) for all volunteers and street-contact staff. Establish a rapid incident-reporting system with same-day documentation and supervisor debriefing within 2 hours. Designate a safeguarding lead (0.25 FTE) to track incidents and identify training gaps.
- By Month 1 (2026-11-08), publish a heat-protection guidance package for private employers (schedule shifts, mandatory breaks, water, shade at Level 2–3). Establish one municipal compliance monitor to visit ≥50% of active contracts (outdoor workers, construction, municipal services) and issue corrective notices ≤48 hours if violations are found. Draft heat clauses into new municipal tenders and contracts from Month 1 (2026-11-08) onward.
- By Month 1 (2026-11-08), confirm locally common non-official languages through municipal registers (candidates: Arabic, Romanian, Portuguese). By Month 1.5 (2026-11-23), recruit 8–12 paid community language ambassadors (10–15 h/week); budget ≈€67k. Brief them as trusted messengers on heat-safety messages and enrollment referrals by Month 2 (2026-12-08). Contract telephone interpretation services (≥2 languages, ≥08:00–22:00 daily during alert season) by Month 1 (2026-11-08).
- By Month 2.5 (2026-12-23), finalize the full-system drill protocol (locations, realism criteria, observer roles, evaluation rubric). Conduct the drill Month 3.2 (2027-01-14) with independent observation. Track center hours, contact attempts/successes, and pickup times over ≥30 requests (including ≥5 wheelchair users). Complete an after-action report by Month 3.5 (2027-01-23) and close all corrective actions by Month 3.9 (2027-02-04) before the Month 4 (2027-02-08) gate decision.
- By Month 1 (2026-11-08), commission a university or public-health institute evaluation partner under a data-processing agreement. Pre-specify the evaluation protocol: comparison design (pilot vs matched districts and prior years, temperature-adjusted, aggregate counts only), baseline data (heat-related EMS, ED, mortality with caveats), and limitations in plain language. Obtain baseline estimates and agreed coding by Month 4 (2027-02-08). Publish results regardless of direction by Month 12 (2027-10-08).

## 1.3 Follow Up Consultation

At the Month 1 (2026-11-08) steering-committee meeting, review the three risks above with the funder, incident commander and public-health deputy. Confirm in writing: (1) drill-based gates and the 50% partial-release rule; (2) backup-supplier activation and premium-fee authorization; (3) partner capacity and contact-rate audit plan. Establish a weekly procurement and staffing dashboard to flag any slippage >1 week. Plan the Month 2.5 (2026-12-23) drill protocol refinement and the Month 3.2 (2027-01-14) full-system drill. Discuss contingency drawdown rules: if any single risk (procurement, staffing, partner capacity) forces a contingency spend >€70k, convene an emergency meeting to re-scope the program or defer scale activation. Confirm Year-2 funding source identification target by Month 9 (2027-07-08) to enable planning for expansion or continuation.

## 1.4.A Issue - Cool-Season Gates Create Unfalsifiable Evidence Problem

The Month 2 (2026-12-08) and Month 4 (2027-02-08) gates fall in winter; you cannot test 80% center hours, 60% outreach contact, or <45-min transport against real heat events. The plan relies on drills, which funders may treat as weak evidence. If June–July temperatures are cool, gates become untestable, the €1.5M release is at risk, and a €200–400k cash gap emerges mid-season. The partial-release rule (€750k at Month 4 = 2027-02-08, remainder after May re-test) is complex and may not be accepted by your funder in writing.

### 1.4.B Tags

- unfalsifiable_gates
- cool_season_testing
- funder_risk
- cash_flow_gap

### 1.4.C Mitigation

By Month 1 (2026-11-08), obtain written funder confirmation that drills satisfy the Month 2 (2026-12-08) and Month 4 (2027-02-08) gates, and that the 50% partial-release rule applies if evidence is insufficient. Pre-specify the drill protocol (locations, scripts, realism criteria) by Month 2.5 (2026-12-23) and conduct the full-system drill Month 3.2 (2027-01-14) with independent observation. Document drill results rigorously (center hours logged, contact attempts and successes counted, pickup times recorded over ≥30 requests). If the funder refuses drill-based gates, defer the scale gate to Month 5 (2027-03-08) and move the €1.5M release decision to post-June, accepting the cash-flow risk and contingency hit.

### 1.4.D Consequence

Without funder sign-off, you face a €200–400k unfunded gap at Month 4 (2027-02-08) if gates fail to release on schedule. This forces mid-season cuts to staffing, home kits or transport. The program risks operational collapse and reputational damage if a heat event occurs while services are incomplete. Partners and volunteers may disengage if funding becomes uncertain.

### 1.4.E Root Cause

The project timeline was compressed to fit a 12-month cycle, pushing both readiness gates into cool months. The gate structure prioritizes schedule over evidence quality. Funders typically prefer real-world validation over simulations; this mismatch was not surfaced early with the funder.

## 1.5.A Issue - Procurement Critical Path Compressed to 6 Weeks; Supply-Chain Failure Is High-Risk

Procurement specs must be issued by Month 0.8 (2026-11-01), and all tranche-1 orders (€1.6M estimate) by Month 2 (2026-12-08). This is 6 weeks from today (Month 0 = 2026-10-08). Cooling kits need 4–6 weeks lead time; if orders slip past Month 1.2 (2026-11-14), delivery pushes into April–May, missing early June peak-risk heat events. You have identified backup suppliers as mitigation, but backup activation (procurement redirection, premium fees of 10–15%) is not budgeted separately and consumes €50–100k of the €280k contingency, leaving little margin for staffing or transport overruns.

### 1.5.B Tags

- supply_chain_risk
- compressed_timeline
- backup_activation_unclear
- contingency_inadequate

### 1.5.C Mitigation

By Month 0.8 (2026-11-01), issue detailed specs (products, quantities, delivery dates, acceptance criteria) to 3 suppliers and request quotes by Month 0.95 (2026-11-06). By Month 1.08 (2026-11-10), benchmark quotes and pre-qualify backup suppliers with signed agreements specifying: (a) activation trigger: if primary supplier reports >2-week slippage from promised delivery, city activates backup within 2 business days; (b) premium acceptance: city pre-authorizes up to 10% cost premium (approximately €60–80k for kits) without additional approval; (c) expedited delivery: backup confirms 3-week lead time or cites inability immediately. Place first-tranche order (30–40% of kits) at Month 1.2 (2026-11-14) with primary supplier. By Month 1.5 (2026-11-23), receive delivery confirmation or escalate to backup. Establish a weekly procurement dashboard tracking all orders, expected vs actual delivery dates, and contingency budget draw. By Month 2 (2026-12-08), confirm 50% of kit stock is either in-hand or under firm 4-week delivery commitment.

### 1.5.D Consequence

If kit procurement slips 4+ weeks, 40–60% of home installations will miss May–June peak-risk heat season, reducing the home-intervention impact and the visible program credibility. Transport and refuge operations can launch, but the home-kit leverage (2,000 visible installations, tangible benefit to residents) is undermined. This increases political pressure to cut other elements, triggering staff or transport reductions. If you activate a backup supplier without budget authority, audit risk and funder trust are damaged.

### 1.5.E Root Cause

The brief requires a repeatable playbook without new legislation, and the 12-month timeline forces compressed procurement. No buffer was built into the critical path for normal supplier lead times or GDPR/accessibility delays. The plan assumes 'specs by Month 0.8 (2026-11-01)' as achievable, but the incident commander, civil-protection operations lead, and public-health deputy may not be named until Month 1 (2026-11-08), delaying spec approval.

## 1.6.A Issue - Intermediary-List Outreach Model May Underreach Isolated Residents; 60% Contact Success Gate Is Ambitious and Unvalidated

The plan assumes intermediary organizations (housing associations, social services, NGOs, pharmacies) can contact ≥60% of enrolled residents on demand. This is a gate criterion for the €1.5M release. However: (a) no baseline call-center capacity exists for these partners; (b) 'enrolled' residents are self-selected (opt-in via GPs, pharmacies, centers), typically biasing toward people already in contact with services; (c) isolated, offline and recently migrant residents—the highest-risk group—are least likely to self-enroll; (d) partner call-center staff turnover during summer peak season is typical 10–20%, risking capacity loss mid-alert. The 60% contact rate is plausible for a motivated cohort but brittle if partner staffing degrades or bad weather causes multiple simultaneous alerts.

### 1.6.B Tags

- reach_inequality
- unvalidated_assumption
- partner_dependency
- gate_contention_risk

### 1.6.C Mitigation

By Month 1 (2026-11-08), survey the partner organizations (housing associations, social services, NGOs) to establish baseline call-center capacity: number of available staff, average call time per person, number of calls per person per alert day (1 or 2?), and typical summer staff turnover. By Month 1.5 (2026-11-23), agree in the partner DPAs on: (a) minimum staffing reserve (e.g., 80% normal staffing maintained even if absence reaches 15%); (b) escalation rule (if <50% of enrolled residents are reached within 4 hours of Level 2 alert, city allocates emergency taxi transport vouchers or activates backup outreach teams). By Month 2 (2026-12-08), pre-define the contact-success audit: each partner logs call date, time, outcome (reached, unreachable, declined, transport accepted) and shares aggregate counts (not identifiable data) daily by 12:00. By Month 3.2 (2027-01-14), during the full-system drill, track actual contact rates and call-center staff availability. If <60% are reached in the drill, adjust the gate to 55% or activate escalation protocols; do not hide shortfalls. Brief the funder at Month 3.5 (2027-01-23) on actual contact performance and partner capacity; if a gap is identified, agree on revised target or added resources.

### 1.6.D Consequence

If the 60% contact gate is unachieved and contested, the €1.5M release is at risk again, creating the same cash-flow gap as the cool-season risk. Operationally, if the city cannot reach enrolled residents reliably, the outreach program loses credibility with residents (a 40% failure rate is not acceptable), and the isolation of the target population is reinforced—exactly the equity outcome the program should prevent. Partners may blame the city for ambitious targets, damaging relationships for Year 2.

### 1.6.E Root Cause

The plan adopted intermediary-list identification to avoid GDPR risk and to reach offline residents, but it did not validate whether partner call-center capacity actually exists to execute a 60% success rate on alert days. The assumption was borrowed from Barcelona and Paris references but not contextualized to Castellón's partner landscape. No baseline capacity audit was conducted before designing the gate.

---

# 2 Expert: GDPR & Health Data Protection Specialist

**Knowledge**: EU data protection regulation, lawful basis for health data processing, intermediary liability and data-processing agreements, Spanish AEPD practice, health-data minimization, consent and retention frameworks

**Why**: The plan's GDPR strategy is critical: intermediary-held lists keep personal data away from the city, but the legal basis, liability sharing, partner audit rights, and breach escalation are only sketched. This expert ensures compliance, mitigates regulatory challenge risk, and advises whether the intermediary model withstands AEPD scrutiny—directly supporting the Month 1.5 (2026-11-23) DPA signing deadline.

**What**: Co-author the template data-processing agreements (DPAs) for housing associations, social services, NGOs and pharmacies; specify controller/processor roles, audit rights (spot-check consent records), and breach-notification triggers; advise on whether heat-alert contact qualifies as a 'public task' under GDPR Article 6(1)(e) or requires explicit consent; deliver legal opinion by Month 1 (2026-11-08).

**Skills**: Data-processing agreements drafting, health-data minimization, GDPR Article 6 basis-selection, Spanish data protection law, partner liability frameworks, audit-trail design

**Search**: GDPR health data specialist, data protection officer EU public health, GDPR DPA templates, intermediary data processing health

## 2.1 Primary Actions

- By Month 0.9 (2026-11-04): Engage a specialist GDPR law firm (€20–30k budget, 8–10 week engagement) to deliver three legal documents in parallel: (1) joint-controller agreement (Article 26) for housing associations and social services; (2) data-processor DPA for NGOs with discretion; (3) memorandum allocating each partner to the correct category based on the city's control over contact strategy. Do not wait for Month 1.5 (2026-11-23) to discover the DPA template is legally insufficient.
- By Month 1 (2026-11-08): Obtain written legal opinion from GDPR counsel confirming the lawful basis for heat-alert contact (consent vs. public-task vs. hybrid) and specifying which Article 6(1) basis applies. If public-task: produce a draft municipal ordinance for city-council approval by Month 1.2 (2026-11-14). If consent: finalize a two-page consent form (translated into Spanish, Valencian, Arabic, Portuguese, Romanian; budget €3–5k) and obtain city-legal sign-off on the form and withdrawal procedures.
- By Month 1 (2026-11-08): Commission a formal Data Protection Impact Assessment (DPIA, €8–12k, 4–6 weeks) for the health-data loop (hospital/EMS aggregate-count sharing). The DPIA must address: (1) definition of 'heat-related' coding and clinician judgment; (2) re-identification risk and controls; (3) retention period and secure deletion procedures; (4) joint-controller vs. processor status. Deliver the DPIA to hospital legal teams by Month 1.3 (2026-11-17) to allow 4–6 weeks for their review and approval before Month 1.5 (2026-11-23).
- By Month 1.5 (2026-11-23): Finalize and execute data-processing agreements with all partner organizations (housing associations, social services, NGOs, pharmacies, hospitals, EMS) incorporating the legal opinions and DPIA findings. Agreements must explicitly define: (a) joint-controller vs. processor relationship; (b) lawful basis (consent form or ordinance text attached); (c) data types and retention period; (d) withdrawal procedures and deletion timelines; (e) breach-notification and escalation contacts; (f) audit rights (city spot-check of consent records and privacy-notice logs); (g) liability allocation if a partner breaches confidentiality. Obtain countersignature from each partner's legal/data-protection representative, not just operational staff.
- By Month 2 (2026-12-08): Brief all 50–80 partner staff (housing caretakers, social-services workers, NGO field staff, pharmacists, GP practice managers, EMS dispatch supervisors, hospital data officers) on GDPR obligations specific to their organization. Provide written one-page checklists covering: (1) what data they hold and how it is protected; (2) how to respond to a withdrawal request (48-hour escalation to the city's data-protection contact); (3) incident reporting: if staff suspect a breach (unauthorized access, loss of contact list, disclosure to a third party), call the city's data-protection contact same-day and file a written incident report within 24 hours; (4) never disclose the enrolled-resident list to anyone except the partner's own authorized staff; (5) log all contact attempts (date, time, language, outcome) for audit purposes. Attendance mandatory; maintain roster for AEPD evidence.
- By Month 1 (2026-11-08): Specify in writing which organization is the Data Protection Officer (DPO) or data-protection contact for the program. If the city has no existing DPO, appoint or contract one (expected role: 0.3–0.5 FTE, cost €20–30k per year, available by Month 1 = 2026-11-08). The DPO is the single escalation point for: (1) breach reports from partners or residents; (2) withdrawal requests; (3) AEPD enquiries. Publish the DPO's contact details in all resident-facing materials (flyers, posters, heat-line scripts, cooling-center signage) so residents know how to report concerns.

## 2.2 Secondary Actions

- By Month 0.9 (2026-11-04): Request the Spanish Data Protection Agency (AEPD) to provide written guidance (or consult published AEPD criteria) on whether heat-alert contact in a municipal welfare context is lawful under Article 6(1)(e) (public task), Article 6(1)(c) (legal obligation), or only under Article 6(1)(a) (consent). This clarification will inform the legal opinion due at Month 1 (2026-11-08) and avoid costly re-work if counsel's assumption differs from AEPD practice.
- By Month 1 (2026-11-08): Prepare a resident-facing privacy notice (1–2 pages, translated into 4–6 languages) explaining: (1) what data will be collected (name, address, phone, language preference, transport needs, cooling-center preference); (2) why (heat-alert contact during high-temperature events); (3) who has access (named partner organizations only, not shared with third parties); (4) how long data are kept (deleted within 30 days after the season ends unless resident re-enrolls); (5) the right to withdraw (call the heat line, visit a cooling center, or email the DPO; processed within 48 hours). Attach this notice to all enrollment materials (GP posters, pharmacy flyers, cooling-center registration forms). Post on the city's website. Provide a summary in plain language for residents with limited literacy.
- By Month 1.5 (2026-11-23): Complete a DPIA addendum for the outreach component (intermediary-held contact lists), addressing: (1) scale of personal data (number of enrolled residents, estimated 3,000); (2) types of partners (housing associations, social services, NGOs—each a separate data processor/controller); (3) volume of contact attempts (5,000 per month in season); (4) escalation pathways (how outreach staff report heat-illness concerns to EMS without disclosing resident names to non-health partners); (5) residual risk that a partner discloses the list to a third party and mitigation (contractual liability, breach-notification obligations, spot-check audits). This DPIA is distinct from the health-data DPIA and should be reviewed by the city's legal department and shared with the funder (if required by grant conditions).
- By Month 2.5 (2026-12-23): Schedule a compliance audit checkpoint with all partner organizations to verify: (1) staff training completion rates (target ≥90%); (2) logged contact attempts (sample audit of 10–20 partner contact logs to confirm format and completeness); (3) any breach reports received (expected: zero, but investigate any outlier quickly); (4) consent withdrawal requests received (expected: <1% of enrolled residents; log and process within 48 hours). Report findings to the city's data-protection contact and the funder.
- By Month 7 (2027-05-08): Conduct a formal partner audit (allow 2–3 weeks, expected cost €5–8k if contracted externally, or 10–15 staff-days in-house) covering: (1) physical storage of contact lists (locked cabinets, access logs); (2) electronic storage (password-protected, encrypted, access logs); (3) sample of withdrawal requests processed (all within 48 hours? all notified to city DPO?); (4) any accidental disclosures or suspected breaches (timeline for reporting and remediation); (5) compliance with retention period (no data held beyond season unless explicitly re-consented). Produce an audit report by Month 7.5 (2027-05-23) and share corrective actions with each partner and the funder.
- By Month 12 (2027-10-08): Prepare a Data Protection & Privacy chapter in the Heat Response Playbook documenting: (1) the lawful basis used (consent, public task, or hybrid) with legal justification; (2) template DPAs and consent forms for next-year replication; (3) partner vetting and training requirements; (4) incident-reporting procedures and escalation contacts; (5) a sample Data Protection Impact Assessment (so peer cities can adapt it); (6) lessons learned: which consent model achieved highest enrollment, which partners had compliance gaps, what training gaps were found. This chapter will be critical for scaling to other EU cities and for demonstrating compliance to the funder and AEPD.
- Ongoing (monthly during season Months 6.8–11.8 = 2027-05-08 to 2027-09-08): Maintain a breach-incident log accessible only to the city DPO and incident commander. Log any suspected or confirmed: (1) unauthorized access to contact lists (e.g., list left in a public place, found in trash); (2) disclosure to a third party without consent (e.g., a partner staff member forwards a list to a journalist); (3) data loss (e.g., laptop theft from an outreach vehicle); (4) resident complaint (e.g., contacted after requesting withdrawal). For each incident: document date, nature, people affected, immediate response, root cause, and corrective action. If a breach is confirmed, notify AEPD within 48 hours (Article 33) and affected residents within 72 hours (Article 34), unless there is low risk of harm. Budget €10–20k for potential breach-response costs (notification letters, credit monitoring if addresses/phone leaked, legal advice).

## 2.3 Follow Up Consultation


In the next consultation, confirm: (1) Which municipal department or external contractor will serve as the Data Protection Officer (DPO)? If no DPO exists, budget and hire by Month 1 (2026-11-08). (2) Has the city's legal department approved the intermediary-held contact model, or does it prefer consent over public-task authorization? Confirm by Month 0.9 (2026-11-04) so counsel can draft the correct legal basis. (3) Have hospitals and EMS been contacted informally to assess whether they will accept daily aggregate-count sharing? If resistance is high, plan alternative data sources (EMS alone, quarterly aggregates, or manual sampling). (4) What languages are most common among recent migrants in Castellón de la Plana? Confirm by Month 0 (2026-10-08) so consent forms and privacy notices can be translated accurately. (5) Will the city council need to approve a municipal ordinance authorizing heat-alert contact, or can the mayor delegate this by executive order? Confirm by Month 1 (2026-11-08) to avoid delays in the legal-basis foundation. (6) What is the funder's policy on GDPR compliance evidence? Do they require a pre-specified DPIA or just an audit trail of decisions? Clarify to calibrate the scope of legal documentation.


## 2.4.A Issue - Intermediary-held list model lacks explicit lawful-basis documentation and creates orphaned liability

The plan states partner organizations (housing associations, social services, NGOs, pharmacies) will 'make the calls on the city's behalf' without the city holding personal data. This inverts the controller-processor relationship incorrectly: if the city is directing the contact strategy (when, whom, what message), the city is a joint controller, not a data subject. GDPR Article 26 requires a joint-controller agreement specifying roles, liabilities and breach-notification responsibilities. The current DPA template approach treats partners as processors, but the contact decision-making is joint. If a partner breaches confidentiality or contacts someone who objects, the city cannot disclaim liability simply because data never transferred. Spanish AEPD practice (Criterios, 2023) holds the beneficiary (city) jointly liable for partner-driven contact campaigns in welfare contexts.

### 2.4.B Tags

- GDPR-joint-controller
- lawful-basis-undefined
- liability-orphaned
- DPA-insufficient

### 2.4.C Mitigation

By Month 0.9 (2026-11-04), request the GDPR counsel to prepare three documents in parallel: (1) a joint-controller agreement (Article 26) specifying that the city and partner jointly decide contact strategy, retention, and breach protocols; (2) a processor agreement (DPA) for cases where the partner only executes city-defined scripts with no discretion; (3) a memorandum documenting why each partner falls into which category. For housing associations and social services (city-directed scripts, no partner discretion on who/when): use joint-controller form. For NGOs with their own welfare expertise (partner discretion on outreach method): use processor form. For pharmacies (retail, limited capacity): negotiate individual consent at the point of service instead of pre-enrolled lists. Obtain the AEPD's written view (request formal guidance by Month 1 = 2026-11-08) on whether heat-alert contact constitutes a lawful basis (Article 6(1)(e) public task, Article 6(1)(c) legal obligation, or Article 6(1)(f) legitimate interest) or requires explicit consent (Article 6(1)(a)). If counsel advises joint control, add 2-4 weeks to the Month 1.5 (2026-11-23) DPA-signing timeline and brief the funder at Month 1 (2026-11-08).

### 2.4.D Consequence

Without explicit joint-controller agreements, if a partner breaches confidentiality (e.g., discloses an enrolled resident's contact to a third party, or contacts someone who revoked consent), the city cannot prove it delegated that decision or that the partner acted without city authority. AEPD investigation will find the city liable as a joint controller. Regulatory fine risk: 2-4% of annual revenue (Article 83(4)) for a municipality. Reputational damage: local media story about a data breach from a city 'trusted' intermediary. Partner withdrawal: if an NGO receives a breach notice, it may terminate its MOU mid-season, cutting outreach reach by 10-20% and threatening the 60% contact-success gate. Legal remediation cost: €50-100k for incident response, breach notifications and AEPD cooperation.

### 2.4.E Root Cause

The intermediary model was chosen for simplicity and GDPR avoidance, but it conflates 'data does not move to the city' with 'city has no controller responsibilities.' The city determines alert triggers, contact frequency (1-2 calls per alert day per enrolled resident), timing, and escalation rules. That is joint control. No joint-controller agreement is mentioned. The DPA template (Month 1.5 = 2026-11-23) assumes processor relationships and is legally insufficient.

## 2.5.A Issue - Consent model is ambiguous and may not meet the legal basis required by Spanish law

The plan mentions 'consent withdrawal protocols' and 'opt-in registries' at GPs and pharmacies, but does not specify what type of consent or lawful basis the city is claiming. GDPR Article 6 lists six lawful bases: consent (6(1)(a)), contract (6(1)(b)), legal obligation (6(1)(c)), vital interests (6(1)(d)), public task (6(1)(e)), and legitimate interest (6(1)(f)). Spanish LOPDGDD Article 9 restricts public-sector heat contact to either explicit consent or a legal obligation/public-task basis. If consent is chosen: GDPR Article 7 requires affirmative acts (not pre-ticked boxes), clear information on withdrawal, and evidence the subject provided it. If public-task is chosen: the contact must be authorized by law (e.g., a municipal heat-alert ordinance), the city must retain clear audit trails, and withdrawal is limited. The plan does not define which basis is claimed, does not specify withdrawal mechanisms, and does not attach a consent form or withdrawal request procedure. This creates a compliance gap: if AEPD challenges the legal basis, the city cannot defend enrolled residents' contact or data retention.

### 2.5.B Tags

- consent-model-undefined
- lawful-basis-article6-missing
- withdrawal-undocumented
- LOPDGDD-article9-conflict

### 2.5.C Mitigation

By Month 0.9 (2026-11-04), the GDPR counsel must prepare a legal-basis memorandum deciding whether heat-alert contact is: (1) Consent-based, in which case prepare a two-page consent form (translated into 4-6 local languages) stating the purpose, data types, retention period, and withdrawal method; and brief GPs, pharmacies and NGO staff on how to obtain affirmative consent (signature, verbal confirmation recorded, online click); or (2) Public-task-based, in which case draft or obtain a municipal ordinance (approved by Month 1.2 = 2026-11-14 by the city council) authorizing the heat-alert contact and defining the scope (who, frequency, duration, escalation). Include a DPIA template (€5-10k to complete, delivered by Month 1.2 = 2026-11-14) that documents the lawful basis, necessity and proportionality, and consent/withdrawal procedures. Attach the consent form or ordinance text to the partner DPA agreements (Month 1.5 = 2026-11-23). Brief partner staff on withdrawal procedures: if a resident calls the heat line or visits a cooling center and requests removal from the contact list, the city must confirm and de-enroll within 48 hours, and notify all partners. Log withdrawals in the audit trail for AEPD review.

### 2.5.D Consequence

If AEPD investigates (triggered by a resident complaint or a data breach), the city cannot produce: a) a valid legal basis for contact, b) evidence of affirmative consent, or c) a withdrawal procedure compliant with Article 17 (right to erasure). AEPD can issue a corrective order (Article 58(2)(d)) requiring deletion of all enrolled-resident data within 30 days. This terminates the outreach program mid-season, cutting contact attempts to near zero and failing the 60% gate. Regulatory fine: 2-4% of revenue (€500k-1M+ for a city of 170k). Reputational damage: 'City illegally harvested health data' headline. Resident class-action risk: if breach occurs and residents can prove non-consensual contact, they may claim damages under Article 82 (estimated exposure €10-50k per resident × 100-300 enrolled residents = €1-15M, though municipal immunity may apply under Spanish law).

### 2.5.E Root Cause

The plan treats 'opt-in' and 'consent' as synonymous with 'GDPR-compliant,' but does not distinguish between Article 6 lawful bases or specify how residents provide affirmative consent. The decision-makers (mayor's office, public health) probably assume consent is the safest route, but true consent requires: a) a free choice not to enroll (alternative channel?), b) a specific consent form, c) clear withdrawal instructions, and d) evidence of affirmative action (signature, checkbox, phone confirmation). None of these are detailed. Alternatively, if the city claims a public-task basis (emergency public health), it must cite a legal authority (municipal ordinance or regional decree) that authorizes heat-alert contact, and that legal authority is not mentioned in the plan.

## 2.6.A Issue - Health data flow (aggregate EMS/ED counts) lacks DPIA and data-processor agreement specificity; health-system partners may face regulatory pressure to refuse

The plan specifies that hospitals and EMS will send 'daily aggregate heat-related EMS/ED counts' and 'no identifiable patient data' by 10:00 a.m. the next day. No Data Protection Impact Assessment (DPIA) is mentioned. The health-data loop decision (Decision 7) states 'MOU by Month 1 (2026-11-08)' but does not detail: (1) which ICD-10 codes or clinician judgments define 'heat-related' (a coded diagnosis is subjective and variable by clinician); (2) how aggregate counts are computed (daily total by hour? by ED section? by hospital?); (3) which data fields reach the city (only counts, or also triage category, age band, postal code?); (4) whether the health system is a joint controller (if the city specifies which counts and breakdowns) or a processor (if the health system autonomously decides); (5) how long aggregate data are retained (plan says 'deleted after 12 months,' but interim storage location and access controls are not specified); (6) whether the health-system MOU includes patient-safe harbor language (assuring staff that the city is not requesting re-identification or seeking to contact patients). Spanish health-data law (LSSP and regional hospital regulations) imposes strict confidentiality on clinical data, and hospital legal teams will likely refuse to sign an agreement that permits aggregate data to leave the hospital unless a Data-Processing Agreement (DPA) explicitly limits use. The current MOU outline (plan Section 7) is too vague.

### 2.6.B Tags

- DPIA-missing
- data-processor-vague
- health-data-definition-ambiguous
- hospital-legal-risk

### 2.6.C Mitigation

By Month 0.8 (2026-11-01), request the GDPR counsel to prepare: (1) a Data-Processing Agreement (DPA, 2-3 pages) for hospital/EMS data sharing, specifying that the health system is the data controller (not joint) and the city is the recipient (not processor); the DPA must state the city will not re-identify individuals, will not match data to other municipal records, and will delete aggregate counts within 12 months; (2) a one-page definition of 'heat-related' (e.g., ICD-10 codes T67.0-T67.9 plus clinician coding of 'heat exhaustion/stroke,' OR clinician judgment if no code, OR a heat-attribution algorithm agreed with the health system in advance); (3) a Data Protection Impact Assessment (DPIA, 4-6 pages, €8-12k to complete) assessing the privacy risks of daily aggregate-count sharing, the controls (aggregation, 12-month retention, no re-identification), and residual risks, concluding with a recommendation to proceed; (4) a hospital-specific addendum to the heat-helpline MOU (separate from the GP/pharmacy MOUs) that incorporates the DPA and DPIA findings and includes a 'safe harbor' clause: 'The city acknowledges that no identified patient data will be requested or used to contact individual patients.' Obtain hospital legal approval (allow 4-6 weeks) by Month 1.5 (2026-11-23). If a hospital refuses, identify an alternative data source: EMS alone can provide call-volume trends (easier to anonymize), or negotiate a quarterly aggregate (instead of daily) and delete after season-end.

### 2.6.D Consequence

If a hospital legal team discovers the MOU is non-compliant with LSSP and Spanish DPA guidance (expected outcome: 60-70% probability), they will request a formal DPA and DPIA before signing. This extends the Month 1 (2026-11-08) MOU signing by 4-8 weeks, pushing the health-data agreement to Month 2 (2026-12-08) or later. In the interim, the city loses daily EMS/ED counts, which are needed for the Month 4 (2027-02-08) evaluation baseline and for mid-season escalation decisions. Missing data by Month 1.5 (2026-11-23) means the evaluation cannot establish a valid baseline (required by Month 4 = 2027-02-08), which weakens the credibility of outcome claims and may prompt the funder to delay the €1.5M release pending re-baseline after Month 5 (2027-03-08). Operational impact: without daily EMS/ED counts, the incident commander cannot monitor whether call volume is rising due to heat (escalation trigger in the plan); the city defaults to alert-forecast triggers only, losing early-warning signals from the health system. If no count data reach the city by Month 6.8 (2027-05-02, start of season), the evaluation is unfeasible, and the Year-2 funding case collapses.

### 2.6.E Root Cause

The plan treats aggregate counts as 'not identifiable' and therefore low-risk, but Spanish health law treats even coded aggregate heat-related data as sensitive health information. Hospitals are required by LSSP Article 5 to implement strict access controls and minimize third-party disclosure. The MOU outlined in the plan does not meet hospital legal requirements: it names only the city as recipient, does not specify joint-control versus processor status, does not define 'heat-related' coding, and does not include data-minimization language (e.g., 'the city will not use counts to infer individual patients, will not attempt re-identification, and will not match counts to EMS dispatch logs that could reveal patient identity'). Hospital legal teams (especially in larger networks like Valencia) will flag this as non-compliant with their data-governance policies and may require a formal DPA and DPIA before signing.

---

# 3 Expert: Operational Resilience & Surge Planning Lead

**Knowledge**: Heat-wave surge planning, staff fatigue and scheduling, supply-chain contingency, volunteer management, multi-day event operations, incident command systems, service degradation under extreme events

**Why**: The plan identifies three critical operational risks: cool-season gate testing (no real heat until June), supply-chain compression (kits and transport by Feb–Apr), and staff fatigue during multi-day heat waves (15–25% service loss expected). This expert designs operational contingencies, staffing rotas, and surge protocols to protect the gates and service continuity, directly supporting the Month 2.5–4 (2026-12-23 to 2027-02-08) drill and gate-release pathway.

**What**: Co-design the drill protocol (Month 2.5 = 2026-12-23) and full-system drill script (Month 3.2 = 2027-01-14) to validate the four gates (center hours, contact success, pickup time, after-action closure) with high realism; specify supply-chain stress-test triggers (if any vendor >2-week delay by Feb 28 → activate backup, authorize premium); draft fatigue-management protocols (shift limits, rest-day enforcement, counseling access) for the Month 3 (2027-01-08) training.

**Skills**: Incident-command systems, surge-capacity planning, volunteer fatigue and scheduling, supply-chain risk and contingency, service-continuity testing, operational stress drills

**Search**: heat wave surge planning coordinator, operational resilience municipal services, multi-day event fatigue management, supply chain contingency heat

## 3.1 Primary Actions

- By Month 0.5 (2026-10-23): Secure written funder pre-approval for the partial-release rule (€750k at Month 4 = 2027-02-08 if gates are unmeasurable/drill-only, remainder after May re-test) and a heat-event contingency (€100k additional release if May-June summer is mild). Request funder confirmation in email and lodge copy with mayor and PMO.
- By Month 0.5 (2026-10-23): Engage a specialist GDPR law firm (€15-30k budget) to pre-review the intermediary-held-list model and draft partner data-processing agreements. Obtain a written legal opinion by Month 1 (2026-11-08) confirming GDPR compliance and confirming no DPIA is required because personal data does not transfer to the city.
- By Month 0.3 (2026-10-17): Conduct a rapid supplier-capacity survey (email 5-8 shading/blind/fan suppliers: stock, lead time for 600-800 units, expedite cost for ≤8-week delivery). By Month 0.7 (2026-10-29), issue preliminary procurement specs and place non-binding purchase intentions with top 2 suppliers. By Month 1.2 (2026-11-14), place binding first-tranche orders split 50-50 across primary + backup suppliers to avoid single-point failure.
- By Month 1 (2026-11-08): Establish a Fatigue & Safety Task Force (incident commander, HR coordinator, union representative, occupational health lead). Publish a written fatigue-management protocol by Month 2 (2026-12-08) specifying max 3 consecutive alert shifts, mandatory 2-day breaks, peer-debrief, occupational health screening and 24-hour counseling access post-incident.
- By Month 0.8 (2026-11-01): Launch volunteer driver recruitment at 60 targets (to achieve 40 vetted). Recruit starting Month -1 (2026-09-08, before project start) to create a pre-project pipeline. Name a volunteer-safety lead (0.25 FTE) responsible for incident tracking and weekly contact during alert season.
- By Month 1.2 (2026-11-14): Execute facility-use MOUs with ≥8 of 10 cooling-center sites specifying hours, staffing, security, liability, and accessibility remediation plan. Conduct accessibility audit by Month 1.5 (2026-11-23); ensure ≥50% of planned capacity is fully accessible by May or defer to July.
- By Month 1.2 (2026-11-14): Negotiate and lock in a taxi standby-retainer contract (€50-80k capped, ≥10 vehicles within 20 min, ≥3 wheelchair-capable) with legally binding 48-hour cancellation terms. Confirm backup supplier relationships for transport if volunteer recruitment falls short.
- By Month 1.5 (2026-11-23): Finalize and execute data-processing agreements with 4-6 main partner organizations (housing associations, social services, NGOs, pharmacies). Brief 50-80 partner staff on GDPR, consent, and confidentiality by Month 2 (2026-12-08).

## 3.2 Secondary Actions

- By Month 0.5 (2026-10-23): Request verified baseline data from municipal hospital, EMS, and primary-care network: 3-year history of heat-related ICD-10 coding, call volumes, ED visit patterns by month and age group. Flag any coding inconsistencies to health partners for standardization before Month 2 (2026-12-08).
- By Month 1 (2026-11-08): Conduct a focus-group test of the 'Hot Night Guarantee' value proposition (call within X min, ride within 45 min, cooled home) with 20-30 high-risk residents (65+, living alone, poor housing). Measure enrollment intent and refine messaging for trusted messengers.
- By Month 1 (2026-11-08): Confirm the local migrant language mix via municipal demographic data (candidates: Arabic, Romanian, Portuguese). Commission language-access cost breakdown (interpretation services vs. paid ambassadors) and recruit 8-12 paid ambassadors from migrant associations by Month 2 (2026-12-08).
- By Month 1 (2026-11-08): Map existing home-care, social services, and NGO outreach infrastructure to identify 4-6 intermediary organizations willing to hold contact lists and make enrollment calls on the city's behalf. Estimate their call capacity (calls/day during alert season) and secure MOUs by Month 1.5 (2026-11-23).
- By Month 1.5 (2026-11-23): Finalize and brief all outreach staff (25-35 people) and partner street-contact teams on heat-illness escalation protocols (recognition, decision rules for 112 vs. home management, nurse triage line). Require written test (≥80% pass) and logged attendance.
- By Month 1.5 (2026-11-23): Design and conduct a mock heat-helpline drill (simulate 8-12 transport requests and 3-5 escalations over 2 hours). Test dispatch integration, center occupancy tracking, and operator readiness. Correct any gaps in scripts or procedures before the Month 2 (2026-12-08) gate.
- By Month 2 (2026-12-08): Establish a daily health-data loop: MOU signed with hospital/EMS for daily aggregate heat-related call/visit counts by 10:00 a.m. next day. Validate data feed during a 2-week pilot (Month 1.8 = 2026-12-02). Launch a simple shared dashboard (secure spreadsheet) accessible to incident commander, health coordinator, and dispatch supervisor.
- By Month 2.5 (2026-12-23): Finalize the full-system drill protocol, including test locations, simulation vignettes (heat illness, transport requests, center overcrowding, staff absence, misinformation), timing, and success criteria. Share with partners for sign-off.
- By Month 3 (2027-01-08): Increase planned staff reserve from 20-30% to 40% (hire 60 FTE, operate 43) by extending hiring cohorts or recruiting part-time seasonal staff from retirees and charity networks. Establish occupational-health partnership for pre-season fitness and mid-season fatigue surveys.
- By Month 9 (2027-07-08): Audit partner consent records, privacy-notice logs and any breach incidents; verify compliance with data-protection agreements. Report findings to GDPR counsel and data protection authority if required. Plan data deletion (≤30 days after Month 12 = 2027-10-08) unless re-consent is secured for Year 2.

## 3.3 Follow Up Consultation

"The next consultation (Month 2 = 2026-12-08 readiness gate review) should focus on: (1) Funder communication—has the partial-release rule been accepted in writing? If not, escalate immediately. (2) Supply-chain status—have first-tranche kits been ordered? If orders are delayed by >2 weeks, activate backup suppliers now. (3) Staffing pipeline—how many volunteers are vetted? If <15 by Month 1.5 (2026-11-23), scale the taxi retainer immediately and accept the €150-250k cost. (4) Drill readiness—what gaps were found in the mock helpline and accessibility audit? (5) Partner engagement—are all intermediary-held-list MOUs signed and staff briefed? If not, outreach reach will slip below the 60% gate. Finally, request a written go/no-go recommendation from the incident commander by Month 2.5 (2026-12-23) confirming whether the Month 3.2 (2027-01-14) drill should proceed as planned or be delayed if any critical infrastructure is incomplete."


## 3.4.A Issue - Cool-Season Gates Cannot Be Validated on Real Outcomes—Drill Evidence Alone Is Brittle

The Month 2 (2026-12-08) readiness gate and Month 4 (2027-02-08) scale gate fall entirely in the cool season (Months 0-4 = October 2026–February 2027). Heat events and multi-day surges will not occur until Months 6-11 (2027-04-08 to 2027-09-08). This means all gates rely on tabletop exercises, drills and simulated demand, not real operational performance under actual thermal stress. Funders, city councils and peer cities will view this as weak evidence. A failed real-world response in June will not be caught by April metrics. The plan acknowledges this ('drills are the evidence') but does not adequately prepare for funder rejection or the €200-400k cash-flow gap if release is delayed.

### 3.4.B Tags

- gate-validation-risk
- cool-season-timing
- funder-credibility
- cash-flow-gap

### 3.4.C Mitigation

Immediately (by Month 0.5 = 2026-10-23) request explicit written funder approval for the partial-release rule (€750k at Month 4 = 2027-02-08 if evidence is insufficient, remainder after May re-test). Negotiate a 'heat-event strike clause': if the Month 5-6 (2027-03-08 to 2027-04-08) summer is mild, release €100k additional contingency specifically for that scenario. Redefine the drill success criterion to include 30-50 real transportation requests from actual frail residents (not just test cases), and 5-10 real welfare calls to enrolled people during a 'amber weather' advisory to test partner call-center readiness under mild heat. Document the funder's acceptance in writing and lodge a copy with the mayor and PMO.

### 3.4.D Consequence

Without written funder pre-agreement, a cool May-June and failed April gates could trigger the funder to withhold the €1.5M, creating a €350-650k cash gap (€200-400k shortfall + the €160k tranche-1 contingency exhaustion). The city would then be forced to choose: cut 50% of planned interventions, axe the home-kit program, shift to taxi-only (€150-250k draw), or halt operations mid-season. This would damage the city's credibility, erode partner trust, and leave the most vulnerable residents unserved during the actual heat peak.

### 3.4.E Root Cause

The calendar constraint (project start October 2026, gates in December and February) forces gate testing before the natural heat season. The plan assumes funders will accept drill evidence, but this assumption is not negotiated upfront with the funder. No contingency plan exists if the funder refuses partial release and demands May/June real-world data before releasing €1.5M.

## 3.5.A Issue - Staffing and Volunteer Recruitment Timeline Is Compressed and Fatigue Risk Is Underestimated

The plan requires 43 FTE at peak (18 at cooling centers alone) plus 30-50 vetted volunteer drivers, all in place by Month 6.7 (2027-04-29) for a season that runs Months 6.8-11.8. Vetting of volunteers takes 4-8 weeks per person (background check, insurance, training). The hiring plan is compressed into three cohorts (Month 3, 4, 5 = January–March), with 40% of all staff hired in Month 3 and 40 (2027-01-08, 2030-02-08)% in Month 4 (2027-02-08). Multi-day heat waves (Months 7-9 = 2027-05-08 to 2027-07-08) will drive fatigue, absenteeism and burnout: the plan assumes 15-25% service degradation but holds only a 20-30% staff reserve, which is insufficient for a distributed network of 10 sites plus 50+ volunteers. No fatigue-management protocol (shift rotation, peer support, occupational health) is documented by name or with assigned ownership. Street-contact and outreach teams face particular risk: they work in heat, often encounter distressed people, and may face assault or safeguarding incidents with minimal support.

### 3.5.B Tags

- staffing-compression
- volunteer-fatigue
- surge-staffing-reserve
- staff-safety-protocols

### 3.5.C Mitigation

By Month 1 (2026-11-08), establish a Fatigue & Safety Task Force (commander, HR coordinator, union representative if applicable, occupational health lead). Publish a written fatigue-management protocol by Month 2 (2026-12-08) specifying: max 3 consecutive alert-day shifts, mandatory 2-day break between shifts, peer-debrief 30 min post-shift, occupational health screening pre-season and after multi-day events, and access to counseling within 24 h post-incident. Increase the staff reserve from 20-30% to 40% (hire 60 FTE, operate 43) to absorb absences and burnout. Partner with a local university occupational-health clinic for free pre-season fitness screening and mid-season fatigue surveys. For volunteers, target 60 recruits (to achieve 40 vetted) and begin recruitment at Month -1 (2026-09-08, before project start) to create a pipeline. Name a volunteer-safety lead (0.25 FTE) responsible for incident tracking, safeguarding training, and weekly contact during alert season.

### 3.5.D Consequence

If staffing falls short by 20-30% during a sustained multi-day heat wave (Months 8-9 = 2027-06-08 to 2027-07-08), cooling-center hours will drop below the 80% gate by 15-20%, transport pickup times will exceed 45 minutes, and outreach teams will miss welfare calls to enrolled residents. Staff assault, burnout, and media coverage of exhausted teams will trigger reputational damage. Turnover from burnout will force rehiring mid-season at premium rates (20-30% wage premium, estimated €80-120k cost), which may exceed available contingency. By the critical heat-mortality period (July–August), the response will be degraded below design intent.

### 3.5.E Root Cause

The brief specifies a 'pragmatic' pilot that avoids aggressive scaling, but the staffing plan attempts to run 10 cooling centers, 50 volunteer drivers, 6 dedicated outreach staff and a dispatch center with a skeleton crew that was hired on a compressed 3-month timeline. Fatigue is acknowledged ('limit shifts to 3-4 consecutive days') but no enforcement mechanism, peer-support structure or occupational-health partnership is named. Volunteer recruitment assumes a 50% success rate ('30-50 volunteers') without market evidence. Outdoor and street-contact work (hottest, highest-risk conditions) has the least staffing buffer.

## 3.6.A Issue - Supply-Chain Compression and Procurement Bottleneck Risks Are Not Backed by Supplier Pre-Engagement

The plan requires €800k in home kits (shading, fans, thermometers, hydration supplies) and a taxi standby retainer (€80k) to be contracted and the first 30-40% of kits ordered by Month 1.2 (2026-11-14) and fully ordered by Month 2 (2026-12-08). This demands procurement specifications to be finalized by Month 0.8 (2026-11-01)—within 3 weeks of project start, today (2026-10-08). Lead times for exterior-shading materials, reflective blinds and specialized window fans can be 6-12 weeks in Spain, especially if custom-fitted for top-floor flats. The plan names 'backup suppliers' but provides no evidence of pre-engagement, capacity confirmation, or pricing. A 4-week delay in first-tranche orders (slip to December) means kits arrive in April instead of February, shifting installation past the May heat peak. The €150-250k 'taxi-only fallback' and the €20-50k expedite premium are mentioned as options but no decision pathway or trigger is specified.

### 3.6.B Tags

- procurement-lead-time
- supplier-engagement
- kit-delivery-slippage
- contingency-clarity

### 3.6.C Mitigation

By Month 0.3 (2026-10-17), conduct a rapid supplier-capacity survey (email to 5-8 regional shading, blind and fan suppliers, asking: do you carry stock, lead time for 600-800 units, expedite cost if ≤8 weeks?). By Month 0.5 (2026-10-23), issue preliminary procurement specs (10 pages max: shading type, reflective-blind spec, fan safety/directional-only models, thermometer/hygrometer ranges, delivery schedule). By Month 0.7 (2026-10-29), place non-binding purchase intention with top 2 suppliers (e.g., 'we intend to order 2,000 units Q1 2027; can you commit to delivery Feb 28 at [price]?'). By Month 1.2 (2026-11-14), place the binding first-tranche order with primary + backup supplier split (600 units each from two suppliers to avoid single-point failure). Designate a procurement lead with decision authority to activate backup suppliers or expedite premium (cap €50k) without a second approval. Document all supplier communications in a log with escalation triggers (>2-week slip = activate backup).

### 3.6.D Consequence

If procurement slips by 4+ weeks, first-tranche kits will arrive in April instead of February, pushing installation to June-July when heat events are at peak frequency. Outreach teams will be unable to offer a completed home kit during enrollment, reducing enrollment uptake by 20-30% (estimate). The June-July heat wave will find 30-50% of target homes unprotected, directly harming vulnerable residents during the highest-risk mortality window. A reputational incident (news story: 'City Fails to Install Cooling Kits Before Heat Wave') will undermine trust in the program and funder confidence for Year 2 scaling. The €150-250k fallback (cutting kits from 2,000 to 1,000-1,500) will not be triggered in time if the slip is discovered late, and the city will face a €200-350k unbudgeted cost to expedite.

### 3.6.E Root Cause

The procurement timeline is driven by the Month 2 (2026-12-08) gate (ready to deliver, kits on hand) and the May heat season, but supplier relationships are not pre-negotiated. The plan assumes 'existing municipal framework agreements' exist for kits and transport, but this is not verified. No supplier capacity survey has been conducted; no quotations have been requested. The plan also conflates 'specifications finalized' with 'orders placed': specs can take 4 weeks, tender 3-4 weeks, and contracting 2-3 weeks, consuming the entire 7-week runway from Month 0 (2026-10-08) to Month 1.2 (2026-11-14).

---

# 4 Expert: Transport Access & Mobility Innovation Consultant

**Knowledge**: Accessible transport for mobility-limited residents, taxi and paratransit contracting, volunteer driver programs, pickup-time optimization, wheelchair-user accessibility, shared mobility models, transport equity metrics

**Why**: The 45-minute pickup gate depends entirely on the transport model (40 volunteers + €80k taxi retainer). The plan is exposed here: if <20 volunteers recruit by Month 1.5 (2026-11-23), the retainer scales up but budget headroom is unclear; wheelchair users are named in the gate (≥5 of ≥30 requests) but no modeling of their longer pickup times exists. This expert validates the dispatch design, tests realism, and advises whether the volunteer-plus-taxi hybrid can meet the gate under peak load and multi-day fatigue.

**What**: Model transport demand scenarios (advisory vs alert vs emergency levels) and simulate dispatch performance under fatigue (simulate 10 alert days, 30 requests/day, 5 wheelchair users/day, 20% volunteer absence); calculate volunteer-recruitment shortfall exposure (if only 15 recruits vs 40 target, estimate cost and gate impact); propose pickup-time optimization (fixed shuttle loops vs on-demand, pre-position vehicles near high-need housing blocks); deliver findings and gate-readiness assessment by Month 3 (2027-01-08).

**Skills**: Transport modeling and simulation, volunteer-driver vetting and management, taxi/paratransit contract negotiation, wheelchair-user accessibility standards, dispatch optimization, pickup-time metrics

**Search**: accessible transport mobility coordinator, volunteer driver program management, wheelchair user transport equity, taxi paratransit contracting, dispatch optimization

## 4.1 Primary Actions

- By Month 1.2 (2026-11-14), obtain detailed taxi operator cost and response-time data for 15, 20, 30 and 45-minute service tiers; model dispatch using a queue simulator assuming 100-150 requests/alert day, 40 active volunteers and 15-minute median drive; redefine the 45-minute gate to exclude wheelchair users (separate <35-minute target for mobility-limited priority) or increase taxi budget to €120-150k and reduce home-kit scope to 1,200 homes.
- By Month 0.3 (2026-10-17), issue public recruitment call targeting 60-70 volunteer drivers with intake deadline Month 1.5 (2026-11-23); hire a dedicated Volunteer Coordinator (1.0 FTE, Month 0 = 2026-10-08 through 12) and Safeguarding Lead (0.5 FTE, Month 0 = 2026-10-08 through 12); implement rolling vetting batches (weekly police submissions, expected 10-14 day turnaround) and safeguarding cohort training (8 people, 2 hours, fortnightly from Month 1 = 2026-11-08) with written test.
- By Month 1 (2026-11-08), conduct a rapid enumeration survey of 200-300 households in three sample neighborhoods to measure actual reach of each intermediary channel (GPs, pharmacies, housing associations, NGOs); calculate coverage uplift needed to achieve 20-25% of target population (8,000-12,000 residents); add a door-knock and ambassador pathway (50-80 paid ambassadors, €100-150/month) to reach isolated, top-floor and migrant residents missed by intermediary-only model.
- By Month 1.5 (2026-11-23), implement a consent-validation protocol: intermediaries log each consent call (name, date, language, transport preference); city samples 50-100 consents monthly for callback verification; define 'active enrollment' as documented consent within the last 30 days, not historical contact counts.

## 4.2 Secondary Actions

- By Month 1.5 (2026-11-23), finalize volunteer no-show protocol: if a committed driver does not appear within 15 minutes of dispatch on an alert day, mark unavailable for remaining alert, require post-alert debrief before re-deployment; model expected availability by Month 3.5 (2027-01-23) assuming 20-25% attrition and brief funder on taxi-scale-up trigger (if active roster <20 by Month 7 = 2027-05-08, escalate retainer proportionally).
- Establish an escalation protocol for volunteer-driver safeguarding: safeguarding lead receives all incident reports same-day, conducts supervisor debrief within 2 hours, arranges occupational-health counseling within 24 hours; cluster >2 incidents in one month triggers mandatory retraining and funder notification.
- Pilot a mobile transport option (e.g., shuttle loops between high-concentration housing blocks and anchor refuges on declared alert days) to reduce individual on-demand trips by 20-30% and lower mean pickup time variability, especially for mobility-limited residents.
- By Month 4 (2027-02-08), commission an independent evaluation of intermediary-held-list reach and bias (comparing enrolled population to census by age, housing type, language, deprivation); publish findings and adjust Year 2 outreach strategy.
- Create a contingency volunteer reserve pool of 15-20 (50% more than active roster) recruited and vetted by Month 3 (2027-01-08), activated only on declared Level 3 alerts or if active roster falls below 20 drivers.

## 4.3 Follow Up Consultation


At the next consultation, bring: (1) Preliminary taxi-operator cost quotes and response-time commitments for the 15, 20, 30 and 45-minute service tiers (Month 1.2 = 2026-11-14 target); (2) Rapid enumeration survey results and intermediary-channel reach analysis showing coverage gaps and uplift needed (Month 1 = 2026-11-08); (3) Volunteer recruitment intake numbers and vetting pipeline status by Month 1.5 (2026-11-23) and Month 2 (2026-12-08); (4) Dispatch simulator model output (mean pickup time by request type, volunteer availability, alert level) to validate or adjust the 45-minute gate; (5) Draft consent-validation protocol and pilot results from intermediary callbacks (sample 50-100, verify true active enrollment). These inputs will clarify whether the transport target is realistic, whether volunteer safeguarding capacity is sufficient, and whether intermediary-only outreach is achieving meaningful coverage of isolated, high-risk residents.

## 4.4.A Issue - 45-minute transport target is unachievable without wheelchair-user degradation or budget overrun

The plan assumes 40 volunteer drivers (30-50 range) plus a €80k taxi retainer (≥10 vehicles) can deliver <45-minute mean pickup including ≥5 wheelchair users per drill. Analysis: 40 volunteers active on alert days realistically cover 30-35 (fatigue, illness, competing calls). With 5-8 concurrent transport requests typical at Month 3.2 (2027-01-14) drill scale, each wheelchair-accessible request (requiring vehicle, transfer time, boarding wait) adds 12-18 minutes to non-wheelchair users. Volunteer dispatch has 10-15 minute radio/coordination lag. At surge (100+ requests across a multi-day event), the queue backs up 60-90 minutes. The taxi retainer's 20-minute threshold becomes 45+ minutes by booking and vehicle availability. Wheelchair users will breach 45 minutes by Month 8-9 (2027-06-08 to 2027-07-08) when demand peaks, or the taxi cost scales to €150-200k to guarantee sub-30-minute response.

### 4.4.B Tags

- transport-target-unrealistic
- wheelchair-access-degradation
- surge-capacity-shortfall
- volunteer-reliability-gap
- budget-creep

### 4.4.C Mitigation

Redefine the 45-minute gate as an average excluding wheelchair-users (to be measured separately with a <35-minute target for mobility-limited priority cases). Model dispatch using a simple queue-and-resource simulator: assume 100-150 requests over a 12-hour alert day, 40 active volunteers (30 active + 10 surge reserve), 10-minute dispatch lag, 15-minute median drive, 8 minutes wheelchair boarding. Output: mean 52 minutes overall, 32 minutes for priority wheelchair users. Commission a taxi operator to provide detailed cost and response-time data for 15, 20, 30, and 45-minute response tiers; set contractual response tiers tied to alert level (Level 2 = 30 min, Level 3 = 20 min). By Month 1.2 (2026-11-14), obtain written taxi operator commitments including surge premium (€5-10 per vehicle-minute above baseline) and a maximum-response-time service credit. Build a volunteer reserve pool of 15-20 (50% more than active roster) recruited and vetted by Month 3 (2027-01-08), activated only on declared Level 3 alerts.

### 4.4.D Consequence

If the 45-minute target remains unmodified and untested with realistic dispatch modeling, Month 4 (2027-02-08) gate will likely fail (mean >50 minutes under drill stress-test conditions), causing non-release of €1.5M scale funding and leaving the program underfunded mid-season. Alternatively, if taxi costs scale to €150-200k to meet the target, home-kit budget is cut to 1,000-1,200 homes (from 2,000), increasing equity disparity and reducing uptake. Worst case: wheel-chair users experience mean 60-90 minute waits by Month 8-9 (2027-06-08 to 2027-07-08), creating liability and reputational damage if a mobility-limited resident's heat illness worsens during transport delays.

### 4.4.E Root Cause

The plan conflates best-case drill conditions (30-50 requests, organized groups, light volunteer load, no competing emergencies) with real-season conditions (300-500 requests, scattered, competing with municipal/EMS duties, multi-day fatigue). Volunteer driver reliability research shows 15-25% attrition mid-season; the plan has no reserve pool or surge contract. The 45-minute gate was set without modeling dispatch overhead or wheelchair-specific access time. No internal service-level differentiation: mobility-limited residents should be prioritized (30-min target) at the cost of accepting 60-90 minutes for walking-capable residents.

## 4.5.A Issue - Volunteer driver recruitment and safeguarding timelines are compressed and under-resourced

The plan targets 40 volunteer drivers (30-50 range) with ≥20 vetted by Month 2 (2026-12-08) and the rest by Month 3 (2027-01-08). Vetting includes background checks (10-14 days via police), insurance verification (7-10 days), safeguarding training (3 hours), and dispatch-system orientation (2 hours per person). Realistic throughput: ~2-3 recruits per week vetted fully. To reach 20 by Month 2 (2026-12-08) means starting recruitment in Month 0.3 (2026-10-17) and closing intake by Month 1.5 (2026-11-23). The plan says recruitment starts Month 0 (2026-10-08) but does not specify a closure date, intake method, or recruitment-lead FTE. Safeguarding incidents (assault during transport, inappropriate contact with vulnerable residents, vehicle accident causing injury) require incident reporting, occupational-health follow-up and retraining; the plan assigns a 0.25 FTE safeguarding lead but no deputy or escalation protocol if multiple incidents cluster. Volunteer attrition research shows 20-30% mid-season drop during fatigue-heavy multi-day events; no contingency roster is described.

### 4.5.B Tags

- volunteer-recruitment-lag
- vetting-bottleneck
- safeguarding-under-staffed
- attrition-unmanaged
- incident-response-gap

### 4.5.C Mitigation

Designate a dedicated Volunteer Coordinator (1.0 FTE, Month 0 = 2026-10-08 through Month 12 = 2027-10-08) and a Safeguarding Lead (0.5 FTE, Month 0 = 2026-10-08 through Month 12 = 2027-10-08). By Month 0.3 (2026-10-17), issue a public call targeting retirees, charity/faith workers and young professionals via municipal website, GP surgeries, NGO networks and community centers; set initial recruitment target of 60-70 (to account for 25-30% attrition), intake deadline Month 1.5 (2026-11-23). Implement a rolling vetting pipeline: batch background checks (weekly submission to police, expected 10-14 day turnaround); pair insurance checks with recruitment (pre-qualify drivers with personal insurance before intake, no delays). Conduct safeguarding training in cohorts (8 people, 2 hours each) fortnightly from Month 1 (2026-11-08) onward; require written test (≥80% pass). Establish a no-show protocol: if a volunteer commits to an alert day and does not show within 15 minutes of dispatch, mark as unavailable for the remaining alert, do not re-deploy without a post-alert debrief. By Month 3.5 (2027-01-23), model expected availability (assuming 20-25% attrition by Month 8 = 2027-06-08) and brief funder on reduced capacity or recommend taxi-scale-up trigger (if <20 volunteers in active roster by Month 7 = 2027-05-08, escalate retainer).

### 4.5.D Consequence

If recruitment closes late (Month 2 = 2026-12-08 instead of Month 1.5 = 2026-11-23), only 12-15 volunteers will be fully vetted by Month 2 (2026-12-08), forcing immediate taxi-retainer scale-up (€100-150k additional) and reducing home-kit budget. If safeguarding staffing is not increased, mid-season incident clustering (e.g., 2-3 assault reports in Month 8 = 2027-06-08) will overwhelm a 0.25 FTE lead, causing delayed incident response, volunteer morale collapse and potential reputational damage. Volunteer attrition by Month 8-9 (2027-06-08 to 2027-07-08) without a contingency roster will drop active drivers to 25-30, extending mean transport time from 45 minutes (drill) to 60-75 minutes (real season), failing the gate retroactively and creating media exposure.

### 4.5.E Root Cause

The plan underestimates the total FTE cost of volunteer management (vetting, on-boarding, dispatch coordination, incident handling, retention). A single safeguarding lead (0.25 FTE) is insufficient for 40 volunteers across a 6-month alert season; literature suggests 1 FTE per 15-20 active volunteers. Background-check delays are common in Q4 (holiday season); no contingency for slow police-records units is described. The plan does not specify what happens if a volunteer is vetting-complete but unavailable on a declared alert day (no show-up rate assumption).

## 4.6.A Issue - Intermediary-held list model reaches only ~9% of high-risk seniors and leaves isolated residents undetected

The plan relies on housing associations, social services, NGOs and pharmacies to identify and contact high-risk residents without personal data moving to the city. Target: 3,000 enrolled by Month 7 (2027-05-08), ≈9% of estimated 34,000 seniors 65+. Research on intermediary-held registries shows typical coverage 5-15% of target populations because: (1) people already known to services (GP, social care, housing) are over-represented; (2) isolated, living-alone seniors with no prior contact are missed; (3) pharmacies reach repeat customers only, missing those who do not fill prescriptions during the survey window; (4) migrant residents distrust formal intermediaries. The plan counts outreach 'attempts' (5,000/month in season) but does not distinguish between successful enrollment (consenting to be called on alert days) and one-time contact (a flyer handed out). No validation sampling is proposed: the plan cannot measure if the 3,000 'enrolled' target reflects real consent or inflated contact logs.

### 4.6.B Tags

- coverage-gap
- isolated-residents-missed
- enrollment-validation-weak
- intermediary-bias
- equity-disparity

### 4.6.C Mitigation

Reframe the 3,000 enrollment target as a floor, not a cap. By Month 1 (2026-11-08), conduct a rapid enumeration survey of 200-300 households in three sample neighborhoods (high deprivation, mixed, affluent) to establish actual reach of each intermediary channel (GPs, pharmacies, housing associations, NGOs); calculate uplift needed to reach 20-25% coverage (8,000-12,000 residents if baseline is 5-7%). Add a low-cost door-knock and sentinel pathway: recruit 50-80 'heat ambassadors' (retired nurses, social workers, bilingual community members) paid €100-150/month to distribute flyers in target blocks (top-floor/elderly concentrations identified via postal data or municipal energy audits) and report back on uptake (Month 1-2 = 2026-11-08 to 2026-12-08). Partner with NGOs to conduct targeted outreach to migrant and unhoused groups monthly (not relying on one-time intermediary referral). Implement a simple consent-validation protocol: intermediaries log each consent call (date, name, language, transport yes/no, cooling center preference); city samples 50-100 consents per month (5-10%) via callback to verify active consent and update contact info (Month 7-12 = 2027-05-08 to 2027-10-08). Define 'active enrollment' as documented consent obtained within the last 30 days, not historical contact counts.

### 4.6.D Consequence

If coverage remains at 9% (3,000 enrolled from 34,000 seniors), the program reaches a biased sub-population (those already connected to services) and misses isolated, solo-living, top-floor residents who face the highest mortality risk during hot nights. When a multi-day heat event occurs (Month 8-9 = 2027-06-08 to 2027-07-08), the 25,000 unreached seniors aged 65+ depend entirely on passive cooling advice (flyers, radio, website) which research shows is ineffective for isolated offline residents; preventable heat-illness cases and deaths may occur that the program could have addressed. Equity metrics (coverage by deprivation index, housing type, migration status) will reveal large gaps, undermining the program's credibility with funders and other EU cities. The 60% outreach contact-success gate will appear to pass (3,000 enrolled ÷ 5,000 attempts = 60%) but may reflect inflated contact logs, not real preparedness.

### 4.6.E Root Cause

The plan assumes intermediary-held lists are GDPR-compliant (avoiding personal data transfer to the city), which is true, but conflates GDPR compliance with coverage. Intermediaries are motivated to report high contact numbers to funders, but not to validate consent or follow-up use. The 9% coverage reflects the design's fundamental tension: the more the city avoids holding personal data, the less able it is to verify reach or to identify who is missing. No building-level canvassing or sentinel-recruitment is planned (those were rejected as 'too aggressive' in Decision 3), leaving top-floor residents in non-affiliated housing blocks unreached. Migrant and recent-arrival residents are named priority groups but no language-specific enrollment pathway is described.

---

# 5 Expert: Volunteer Management & Safeguarding Lead

**Knowledge**: Volunteer recruitment and retention, background-check protocols, safeguarding incident response, insurance and liability frameworks, volunteer fatigue management, vetting workflows, multi-month retention under seasonal pressure

**Why**: The plan requires 30-50 volunteer drivers vetted and operational by Month 2-3 (2026-12-08 to 2027-01-08), with no demonstrated recruitment pipeline or safeguarding protocols. The risk mitigation cites 'clear off-duty procedures if staff are threatened or assaulted' but does not detail incident response, counseling, or liability coverage. If recruitment stalls or a safeguarding breach occurs mid-season, the 45-minute transport gate collapses and reputational damage follows. This expert validates the vetting timeline, designs incident protocols and ensures insurance adequacy.

**What**: By Month 0.5 (2026-10-23), co-design the volunteer recruitment campaign (target 40, launch Month 0 = 2026-10-08) and specify vetting steps: background check turnaround (4-8 weeks/person), insurance requirements (personal vehicle or municipal policy), and safeguarding training (3-hour de-escalation module). By Month 1 (2026-11-08), establish an incident-response SOP: assault/threat triggers same-day supervisor debrief, 24-hour occupational-health counseling, and a safeguarding log reviewed fortnightly. By Month 1.5 (2026-11-23), audit insurance coverage (liability, assault trauma, vehicle damage) and confirm that the recruitment target (20 by Month 2, 40 = 2026-12-08, 2030-02-08 by Month 3 = 2027-01-08) is on track; if <20 in pipeline, escalate to incident commander and activate taxi-retainer scaling.

**Skills**: Volunteer vetting and background-check processes, safeguarding and incident reporting, insurance broker relationship, fatigue-informed rostering, trauma-informed peer support, recruitment-campaign design and tracking

**Search**: volunteer coordinator safeguarding training, background check vetting procedures, volunteer incident response protocol, volunteer fatigue management, municipal volunteer insurance

## 5.1 Primary Actions

- By Month 0.1 (2026-10-11), obtain written funder acceptance of drill-based evidence for the Month 4 (2027-02-08) gate and explicit endorsement of the 50% partial-release rule (€750k if unmeasurable). If the funder will not commit, secure a contingent credit line (€200–400k) from the municipality by Month 1 (2026-11-08) to cover cash-flow gaps.
- By Month 0.2 (2026-10-14), launch volunteer driver recruitment with a detailed pipeline plan (target 50 recruits, weekly cohorts starting now, 4–6 week vetting, 25% attrition assumption). Hire a 0.5 FTE volunteer coordinator to track cohorts, absences and fatigue. Define operationally: shift caps ≤3 consecutive alert days + 1–2 mandatory rest days per driver.
- By Month 0.5 (2026-10-23), commission a rapid social-network survey (200–300 high-risk residents) to identify which intermediaries reach whom and which 'isolation islands' exist (unhoused, private-rental, no service touch). By Month 1 (2026-11-08), design and cost a parallel building-level canvassing track for top 15–20 high-deprivation blocks, targeting ≥15% of enrollment from direct outreach by Month 7 (2027-05-08).
- By Month 0.3 (2026-10-17), finalize and commit to a written drill protocol and gate evidence criteria: ≥100 transport requests, ≥200 outreach contact attempts, ≥2,000 center-hour activations in Month 3.2 (2027-01-14) drill satisfy the Month 4 (2027-02-08) gate; <100 requests = re-test required. Brief the incident commander, CFO and funder monthly on progress.
- By Month 0.8 (2026-11-01), issue detailed procurement specifications for cooling kits, transport retainer and refuge fit-out to at least 3 suppliers per category; request quotes and lead-time confirmation by Month 1 (2026-11-08). Place first-tranche 30–40% kit order by Month 1.2 (2026-11-14); pre-qualify backup suppliers with expedited-delivery premium (10–15%) and activate if primary supplier misses February delivery.
- By Month 1 (2026-11-08), execute the taxi/accessible-transport standby-retainer contract (capped €80k, ≥10 vehicles within 20 minutes, ≥3 wheelchair-capable). Embed the retainer scale-up trigger in writing: if volunteer recruitment falls below 15 vetted by Month 1.5 (2026-11-23), increase retainer negotiation to cap €120k or shift taxi-only model for contingency.
- By Month 1.2 (2026-11-14), confirm completion of cooling-center facility-use MOUs (≥8 of 10 sites), staffing hire start for 12–18 part-time managers and assistants, and accessibility audit plan. Schedule remediation completion by Month 1.5 (2026-11-23) for any gaps <€10k and <4 weeks; categorize sites as 'fully accessible' or 'defer to July' and ensure ≥50% of planned capacity is fully accessible by May.
- By Month 1.5 (2026-11-23), complete vetting of first cohort of ≥20 volunteer drivers (background check, insurance, 2-hour safeguarding training). Finalize and execute all partner data-processing agreements (housing associations, social services, NGOs, pharmacies) with signed MOUs specifying lawful basis for contact, data retention (one season only), and breach notification (48-hour reporting). Brief 50–80 partner staff on GDPR and confidentiality by Month 2 (2026-12-08).

## 5.2 Secondary Actions

- By Month 0.5 (2026-10-23), engage a specialist GDPR law firm (€15,000–30,000) to pre-review the intermediary-held-list model and draft template MOUs. Obtain written legal opinion confirming GDPR compliance by Month 1 (2026-11-08).
- By Month 1 (2026-11-08), confirm local demographics (verified 65+ population, living-alone prevalence, top-floor housing concentration) from municipal data and census; audit baseline heat-related EMS calls and ED visits (80–120 call estimate, 15–25 excess-death estimate) from hospital and EMS records; confirm heat-coding practice with clinicians.
- By Month 1 (2026-11-08), finalize alert-trigger thresholds (proposed: Level 1 ≥33°C/≥20°C; Level 2 ≥35°C/≥22°C; Level 3 same + ≥3 days) in writing with the national meteorological service (AEMET) and incident commander; obtain approval for declaration procedures and authority delegation.
- By Month 1.2 (2026-11-14), hire the 0.5 FTE HR coordinator and partner-liaison officer (or assign to existing staff) with clear accountability for hiring, vetting, fatigue tracking and partner engagement. Establish a weekly staffing and pipeline status report (submitted to the incident commander by Fridays).
- By Month 1.5 (2026-11-23), identify 4–6 non-official languages most common in Castellón de la Plana (candidates: Arabic, Romanian, Portuguese) and hire 8–12 paid community language ambassadors (10–15 h/week) via migrant associations by Month 2 (2026-12-08). Budget ≈€67k for language work.
- By Month 2 (2026-12-08), conduct mandatory de-escalation, trauma-informed care and heat-illness escalation training for all 25–35 outreach and street-contact staff (3-hour modules); achieve ≥80% pass rate on written test; maintain audit trail of certifications.
- By Month 2 (2026-12-08), establish a heat-helpline phone service (08:00–22:00 daily during alerts, 24-hour at Level 3) staffed by 2–3 part-time operators with customer-service and language skills; integrate a shared real-time call-tracking spreadsheet (name optional, address/postcode optional, transport need, language, cooling-center preference) accessible to dispatch and center managers.
- By Month 2.5 (2026-12-23), finalize and distribute to all staff the heat-illness escalation checklist and de-escalation cards (laminated, pocket-sized); establish a nurse-advice line for real-time telephone triage of suspected heat illness; brief all staff on the line and its use.
- By Month 2.5 (2026-12-23), finalize the drill protocol and evidence criteria in writing, shared with the funder and all operational leads. Schedule the full-system drill for Month 3.2 (2027-01-14); reserve a 2-week after-action cycle (draft Month 3.5 = 2027-01-23, actions closed Month 3.9 = 2027-02-04, gate decision Month 4 = 2027-02-08).
- By Month 3 (2027-01-08), complete training for all 43 planned FTE on fatigue management, safe working hours and mandatory rest protocols. Publish a roster that enforces ≤3 consecutive alert days and 1–2 rest days; model surge capacity (20–30% reserve) and test it in the drill.
- By Month 3 (2027-01-08), agree with the hospital and EMS on daily aggregate heat-related call/visit counts (by 10:00 next day) and an escalation protocol: notify incident commander at ≥1.5× historical average, mutual-aid review at ≥2×. Conduct a 2-week validation pilot (Month 1.8 = 2026-12-02); resolve any IT or coding gaps by Month 2 (2026-12-08).
- By Month 6 (2027-04-08), complete focus-group testing of pre-season communications (radio, flyers, pharmacy posters, door hangers, SMS) with at least 2–3 high-risk resident groups (65+, living alone, migrants). Correct messaging for clarity and cultural sensitivity. Brief all trusted messengers (pharmacists, GPs, caretakers, faith leaders) on heat-safety talking points by this date.
- By Month 9 (2027-07-08), audit 10% of partner organizations (housing associations, social services, NGOs) for GDPR compliance, spot-checking consent records and privacy-notice logs. Flag any breaches for immediate remediation.
- By Month 12 (2027-10-08), delete all personal data from intermediary partners and city records unless re-consented; retain only aggregated outcome data (EMS calls, ED visits, participation) for evaluation and playbook development.

## 5.3 Follow Up Consultation

At the next meeting, review (1) funder's written acceptance of drill evidence and partial-release rule; (2) volunteer recruitment pipeline status and first cohort progress; (3) results of the social-network survey to validate intermediary reach and identify canvassing needs; (4) accessibility audit findings and remediation plan; (5) drill protocol finalization and evidence criteria; (6) partner GDPR opinions and MOU execution status; (7) any scope or timeline changes that trigger restart criteria. Request a monthly staffing pipeline report and drill rehearsal schedule by Month 1 (2026-11-08).

## 5.4.A Issue - Volunteer Recruitment and Fatigue Management Are Severely Underspecified, Risking the 45-Minute Transport Gate

The plan targets 40 volunteer drivers but provides no recruitment pipeline, no attrition assumption, and no fatigue-rotation protocol. Vetting 20 volunteers by Month 2 (2026-12-08) requires recruitment to start immediately (now), yet no recruitment campaign exists. Multi-day heat waves will drive absences; a 20–30% reserve is mentioned but not operationalized into shift caps or mandatory rest days. Without a staffing model that survives fatigue, the plan risks missing the <45-minute pickup gate and defaulting to expensive taxi-only operation mid-season.

### 5.4.B Tags

- volunteer_recruitment_pipeline_missing
- fatigue_rotation_undefined
- gate_risk_transport_time
- staffing_attrition_not_modeled
- vetting_timeline_too_aggressive

### 5.4.C Mitigation

By Month 0.2 (2026-10-14), issue a detailed volunteer recruitment brief specifying: target 50 recruits to net 40 vetted (25% attrition assumption), weekly cohorts of 5–8 starting now, and vetting SLA of 4–6 weeks per person. Define shift caps: ≤3 consecutive alert days, then 1–2 mandatory rest days. Assign a 0.5 FTE volunteer coordinator (not just HR) to track cohorts, absences and fatigue. Test this model against the gates by simulating a 10-day heat wave at Month 3.2 (2027-01-14) drill; if pickup times exceed 45 minutes under fatigue assumptions, trigger the taxi retainer scale-up plan (capped €80k → negotiable if needed) before May.

### 5.4.D Consequence

Without volunteer recruitment starting now and a tested fatigue model, the city risks deploying too few drivers by May, missing the <45-minute gate in the full-system drill (Month 3.2 = 2027-01-14), and forcing a costly taxi-only fallback (+€150–250k, straining the €160k tranche-1 contingency) or, worse, failing the Month 4 (2027-02-08) gate and losing the €1.5M scale release. Service degradation during multi-day waves will harm the program's credibility and strain remaining volunteers.

### 5.4.E Root Cause

The plan names volunteer drivers as a core lever but treats recruitment and fatigue as secondary. No one is assigned as volunteer lead with recruitment accountability. Fatigue management is abstract ('20–30% reserve') rather than concrete (shift caps, rest-day enforcement, cohort scheduling). The vetting timeline (4–8 weeks per person) is longer than the recruitment window (8 weeks to Month 2 = 2026-12-08), creating an impossible math unless hiring begins immediately.

## 5.5.A Issue - Cool-Season Gates Depend on Drill Evidence, Creating Funder Ambiguity and Cash-Flow Risk

The Month 4 (2027-02-08) gate (80% center hours, 60% outreach contact, <45-minute transport) must be tested by a drill in Month 3.2 (2027-01-14) because real heat events are unlikely in January. The pre-project assessment acknowledges this but proposes a 50% partial-release rule (€750k) if evidence is 'unmeasurable.' This rule is not written into the gate definition, is not accepted by the funder in writing, and leaves ambiguity: if the funder rejects drill evidence, the city faces a €200–400k cash gap (only €160k contingency available), forcing mid-season cuts to home kits, outreach or transport. No mitigation plan specifies who decides on partial release or how to proceed if the funder says 'no drill evidence, full gate or restart.'

### 5.5.B Tags

- cool_season_gate_credibility
- funder_ambiguity_on_drill
- cash_flow_risk_200k_400k
- partial_release_rule_not_binding
- contingency_insufficient

### 5.5.C Mitigation

By Month 0.1 (2026-10-11), secure a written letter from the funder confirming acceptance of drill evidence for the Month 4 (2027-02-08) gate and endorsing the 50% partial-release rule (€750k if evidence is insufficient, remainder after Month 5 = 2027-03-08 re-test with real data). Define 'insufficient evidence' in writing: <100 drill transport requests, <200 outreach contact attempts, or <2,000 center-hour drill activations mean re-test is required. If the funder will not commit in writing, de-risk by securing a contingent credit line (€200–400k) from the municipality or funder by Month 1 (2026-11-08). Brief the incident commander and CFO monthly on cash-flow scenarios.

### 5.5.D Consequence

If the funder rejects drill evidence at Month 4 (2027-02-08) and withholds the €1.5M, the city cannot fully fund outreach, home kits or transport through the May–August heat season. This forces mid-summer service cuts (e.g., pausing kit installations, reducing outreach frequency, capping transport to taxis only), harming vulnerable residents and destroying program credibility. The city may face media criticism ('promised help, then retreated') and reduced political support for Year 2.

### 5.5.E Root Cause

The plan treats the drill-based gate as an acceptable compromise but does not lock funder agreement in writing. The 50% partial-release rule is mentioned in the pre-project assessment and SWOT but not formalized as a funder commitment. No fallback funding source (credit line, reserve, year-2 carry-forward) is identified. The contingency (€280k) is too small to absorb a €200–400k gap.

## 5.6.A Issue - Intermediary-Held Identification May Underserve the Most Isolated Residents, Leaving Equity Goals at Risk

The plan relies on intermediary-held lists (housing associations, social services, NGOs, pharmacies) to reach 3,000 enrolled high-risk residents (≈9% of 65+). These intermediaries may not contact hard-to-reach people: those living alone without social services, residents in private rentals not tracked by housing associations, migrants avoiding official institutions, and unhoused people absent from all lists. The 60% outreach contact-success gate measures success among enrolled residents, not overall reach. Without a parallel universal or building-level canvassing component, the plan risks serving 'insiders' (known to services) while missing 'outsiders' (isolated, no institutional touch points). This contradicts the equity mandate to prioritize isolated residents.

### 5.6.B Tags

- identification_equity_gap
- intermediary_reach_limited_to_insiders
- unhoused_and_isolated_underrepresented
- 60percent_gate_measures_enrolled_not_coverage
- private_rental_gap

### 5.6.C Mitigation

By Month 0.5 (2026-10-23), commission a rapid social-network survey of 200–300 high-risk residents (65+, living alone, top-floor housing, self-reported health conditions) to identify which intermediaries can reach them and which 'islands' exist (unhoused, private-rental, isolated without services). By Month 1 (2026-11-08), design a second parallel identification track: building-level canvassing (door-knock or postcard-invite) in the top 15–20 blocks with highest deprivation/isolation scores, reaching households intermediaries do not touch. Set a equity KPI: ≥15% of enrolled residents from the canvassing track by Month 7 (2027-05-08). Measure coverage (not just success among enrolled) as a secondary gate: ≥20% of estimated high-risk population contacted by Month 4 (2027-02-08), including ≥10% from canvassing.

### 5.6.D Consequence

If the intermediary-held model serves only 'insiders,' the city enrolls residents already known to services and misses the program's intended highest-need population. This damages equity, fails to reach isolated residents who die at highest heat risk, and undercuts the program's credibility ('pilot reached only the connected'). Scaling to other EU cities will replicate this bias. The program also misses an opportunity to build trust with isolated groups who may be more receptive to a direct, low-pressure outreach approach than to intermediary-mediated contact.

### 5.6.E Root Cause

The plan adopts intermediary-held lists for GDPR safety and ease but does not validate that these intermediaries reach the full range of high-risk residents. The 3,000 enrollment target and 60% contact-success gate measure activity within the enrolled pool, not population-level coverage. No one is accountable for coverage equity. The decision to avoid building-level canvassing (justified as 'cost per person found') is not tested against actual network data.

---

# 6 Expert: Municipal Procurement & Contract Law Specialist

**Knowledge**: EU public-procurement law (thresholds, frameworks, tenders), Spanish procurement rules, contract design and risk allocation, competitive tendering, below-threshold purchasing, supplier qualification and audit, amendment and change-order procedures

**Why**: The plan's critical path compresses €500-700k of orders into Months 0-1 (2026-10-08 to 2026-11-08).5 (2026-10-08 to 2026-11-23) via 'framework call-offs/below-threshold' purchasing to meet the Month 2 (2026-12-08) readiness gate. However, the plan does not specify: (1) which framework agreements exist and are suitable; (2) the threshold breakpoints (€50k EU below-threshold, varying by region); (3) audit risk if orders are deliberately split to avoid thresholds; (4) contract-clause conflicts (heat-protection clauses in worker contracts slow tendering). This expert ensures compliance, reduces audit exposure, and verifies that the procurement route supports the schedule without legal challenge.

**What**: By Month 0 (2026-10-08), map the existing municipal framework agreements (coolers, transport, services) and identify which are suitable for call-offs without competition; confirm they include heating/cooling kits, handyperson services and transport. By Month 0.8 (2026-11-01), issue detailed procurement specifications for kits, handypersons, transport and center fit-out, specifying quantity, quality, delivery date and performance standards. By Month 1 (2026-11-08), determine the lowest-risk route for each category (framework call-off, below-threshold simplified, or open-tender); confirm that no single order or order-splitting pattern creates audit risk under Spanish law. By Month 1.5 (2026-11-23), audit-proof the procurement files (documented specs, quotes, selection rationale, change orders) and advise on contract-clause prioritization (speed vs heat-protection requirements).

**Skills**: EU public-procurement law and thresholds, Spanish procurement regulations, contract drafting and risk allocation, below-threshold purchasing, framework-agreement call-off procedures, audit-trail documentation, supplier relationship management

**Search**: EU public procurement law specialist, municipal procurement officer Spain, below-threshold purchasing compliance, contract law Spain procurement, audit-ready procurement documentation

## 6.1 Primary Actions

- By 2026-10-22 (Month 0.5 = 2026-10-23), engage a specialist GDPR law firm (€15–30k budget) and request written legal opinion on the intermediary-held-list model. Confirm that personal data does not transfer to the city and that the lawful basis for contact (public task + consent) is sound. Concurrently, identify 4–6 main partner organizations (housing associations, social services, NGOs, pharmacies) and schedule in-person meetings by 2026-11-08 to discuss data-processing agreements and contact protocols. Obtain their letter of commitment by 2026-11-15 (Month 1.3 = 2026-11-17).
- By 2026-11-01 (Month 0.8 = 2026-11-01), issue detailed RFQs to 5+ qualified vendors per procurement category (shading kits, reflective blinds, fans, thermometers, installation labor, transport/taxi services). Request firm price quotes, lead-time commitments and expedite-cost options. By 2026-11-08, select primary and 2 backup suppliers per category; document any price premiums for accelerated delivery. Place the first 30–40% kit call-off order by 2026-11-08 (not 2026-11-14) with signed delivery SLAs for February 2027 receipt. Simultaneously, issue transport RFQ to taxi/accessible-transport operators, request standby-retainer quotes for 10–15 vehicles within 20 min response, and sign a binding contract by 2026-11-15 (Month 1.3 = 2026-11-17) at the capped €80k rate (or scale to €120k if volunteer recruitment is lagging by Month 1.5 = 2026-11-23).
- By 2026-10-31 (Month 0.9 = 2026-11-04), secure written commitment from the funder (or funder's designated representative) confirming that drill-based evidence is acceptable for the Month 4 (2027-02-08) gates. Document the partial-release rule in writing: €750k (50%) released at Month 4 (2027-02-08) if gates are measurable but gates are not met, and the remaining €1.5M released after a Month 5 (2027-03-08) real-event re-test. Include a contingency plan ('Plan B') that specifies which services would be cut if tranche-2 funding does not release (e.g., home kits reduced from 2,000 to 1,000, refuges scaled to 6 core sites). Obtain funder sign-off on this Plan B before Month 2 (2026-12-08).
- By 2026-11-08 (Month 1 = 2026-11-08), obtain the mayor's signed delegation of authority document appointing the incident commander (mayor's office), public-health deputy, operations lead (civil protection), and communications lead (municipal communications). Ensure the delegation specifies alert-declaration authority, spending approval limits per tier, and escalation paths for cross-department requests. File the document with the municipal secretary and circulate to all partners and operational staff.
- By 2026-11-15 (Month 1.3 = 2026-11-17), establish a weekly procurement tracking dashboard (shared spreadsheet or low-code system) listing all categories (refuges, kits, transport, staffing, comms), order status, delivery dates and any delays. Assign a procurement lead (0.5 FTE) to manage the dashboard and trigger backup suppliers if any item slips by >1 week vs. target. By 2026-12-08 (Month 2 = 2026-12-08), confirm receipt or scheduled delivery of 40–50% of kit stock; if any supplier reports >2-week delay, immediately activate backup supplier and authorize expedite shipping premium.
- By 2026-12-08 (Month 2 = 2026-12-08), hire all permanent and contract staff for Month 2 (2026-12-08) readiness: cooling-center managers (1 per site, 10 FTE), outreach team lead (1 FTE), dispatch lead (1 FTE), phone-line manager (1 FTE), and HR/recruitment coordinator (0.5 FTE for Months 0–4 = 2026-10-08 to 2027-02-08). Conduct first-aid and customer-service training (1 day minimum) for center and phone staff. By 2026-11-08 (Month 1 = 2026-11-08), launch volunteer driver recruitment campaign via job centers, faith organizations and social media; target 60–80 applicants to achieve 40 vetted by Month 3 (2027-01-08). Run vetting cohorts every 2 weeks (background checks, insurance verification, 2-hour safeguarding training) and track completion on a live recruitment dashboard.
- By 2026-11-22 (Month 1.5 = 2026-11-23), finalize and execute data-processing agreements with all 4–6 partner organizations. Agreements must specify: data controller/processor roles, staff confidentiality clauses, audit rights for the city, breach-notification procedures (48-hour reporting to data protection authority), and retention period (one season, deleted by October 2027). Obtain countersigned agreements from each partner's authorized representative.
- By 2026-12-08 (Month 2 = 2026-12-08), conduct a full-system drill protocol planning session with operations, comms, and dispatch leads. Define the drill scope: 3+ consecutive hot-night alert events, 40+ simultaneous transport requests, 80%+ refuge occupancy, outreach fatigue (12+ hours), and escalation decision-points. Schedule the full-system drill for Month 3.2 (2027-01-14). Publish the drill protocol document (with roles, scripts, escalation trees) by 2026-12-23 (Month 2.5 = 2026-12-23) to allow 3 weeks of staff rehearsal before the live drill.

## 6.2 Secondary Actions

- By 2026-11-08 (Month 1 = 2026-11-08), coordinate with the regional meteorological service (AEMET) to confirm alert-threshold definitions (Level 1: high ≥33°C or low ≥20°C for 2+ days; Level 2: high ≥35°C and low ≥22°C for 2+ days; Level 3: same for 3+ days). Request historical summer temperature and heat-event data for Castellón (2015–2025) to validate thresholds post-hoc after the first season. Establish a standing weekly call (Mondays 09:00) with AEMET from May to September (Months 6–11 = 2027-04-08 to 2027-09-08) to review 7-day forecasts.
- By 2026-11-15 (Month 1.3 = 2026-11-17), work with the municipal occupational health service or a senior emergency-medicine clinician to co-design a heat-illness escalation checklist for outreach and street-contact staff. Checklist must include: recognition signs (confusion, loss of consciousness, hot/dry or profusely sweating skin, inability to stand), decision rules for EMS call (any severe sign, unconsciousness) vs. phone triage (mild dehydration, no severe signs), and de-escalation language. Conduct role-play training with 2–3 realistic vignettes per staff member; require written test (pass ≥80%) before authorization.
- By 2026-12-08 (Month 2 = 2026-12-08), establish a nurse-advice line (contracted or in-house) that outreach staff can call for real-time telephone triage of suspected heat illness. Document call protocols, referral pathways (escalate to 112 EMS, advise home management, refer to 111-style non-emergency service) and post-call logging. By Month 5 (2027-03-08), review first 10 calls to validate protocol and retrain staff if gaps are found.
- By 2026-11-22 (Month 1.5 = 2026-11-23), design and focus-test public messages with a sample of 20–30 high-risk residents (recruited via partner organizations). Test key messages: heat-alert recognition ('daytime high ≥35°C, night low ≥22°C'), cooling-center locations and hours, transport booking (heat line phone number), home-kit benefits, fan safety (directional use only, not opposing), and hydration importance. Identify any misinformation concerns (alcohol myths, incorrect fan advice) and design rapid-response talking points.
- By 2026-12-01 (Month 1.9 = 2026-12-05), recruit and train 8–12 paid community language ambassadors (10–15 h/week starting Month 2 = 2026-12-08) to co-create translated messages, accompany door-knock teams, and staff cooling-center welcome desks. Ambassadors should be selected from migrant associations and represent the locally most common non-official languages (to be confirmed by Month 0 = 2026-10-08 from municipal registers; candidates: Arabic, Romanian, Portuguese). Provide ambassadors with consistent scripts and weekly briefings.
- By 2027-01-08 (Month 3 = 2027-01-08), conduct a 'surge simulation' drill: run a continuous 72-hour alert drill with all staff, volunteers, partners and dispatch. Measure stress indicators (call-queue depth, refuge occupancy, transport wait times, staff fatigue reports). Use results to adjust shift rotations, staffing levels, and volunteer call-out procedures before the May season.
- By 2027-02-08 (Month 4 = 2027-02-08), hold a debrief meeting with all stakeholders (city leadership, partners, funders, evaluation team) to review drill results and after-action corrective actions. Confirm funder agreement on scale-gate evidence and final tranche-2 release. If gates are unmet but gates are measurable, activate the 50% partial-release rule and schedule a re-test for May (Month 7 = 2027-05-08) using real heat events.
- By 2027-04-08 (Month 6 = 2027-04-08), conduct trained-messenger briefings for pharmacists, GPs, caretakers and faith leaders across the city. Provide each group with: heat-alert recognition criteria, cooling-center and transport information, escalation protocols (when to refer residents to the heat line), and translated flyers. Measure attendance and knowledge via short post-briefing quiz.
- By 2027-05-08 (Month 7 = 2027-05-08), conduct a second full drill and transport stress test. Measure performance vs. Month 3.2 (2027-01-14) drill baseline; identify any degradation in reliability or speed. Confirm staffing, volunteer and equipment readiness before peak summer (July–August = Months 9–11 = 2027-07-08 to 2027-09-08).
- By 2027-07-08 (Month 9 = 2027-07-08), conduct a partner audit: spot-check consent records and privacy-notice logs at 2–3 partner sites to verify GDPR compliance. Review any heat-related incidents, data breaches or escalations reported by partners. Document audit results and corrective actions.
- By 2027-09-08 (Month 11 = 2027-09-08), draft the Heat Response Playbook, cost model and evaluation report. Include: SOPs and checklists for alert declaration, center operations, transport dispatch, outreach protocols and escalation; procurement lists and vendor contact information; partner MOUs; staffing templates; comms templates and scripts; baseline data, outcome counts and evaluation limitations. Share draft with two peer cities (e.g., Valencia, Barcelona) for external review by 2027-09-30 (Month 11.2 = 2027-09-14).

## 6.3 Follow Up Consultation

At the next meeting (recommend 2026-10-22, Month 0.5 = 2026-10-23), confirm: (1) funder's written acceptance of drill-based gates and partial-release rule; (2) procurement RFQ results and backup supplier commitments; (3) volunteer recruitment partnerships in place; (4) GDPR legal opinion timeline and partner data-processing agreement draft; (5) incident commander delegation document signed. Discuss the 'Hot Night Guarantee' killer-app concept (one simple promise to enrolled residents: call within X hours, ride within 45 min, cool home). Identify any political or organizational blockers to speed. Schedule a third meeting at Month 1 (2026-11-08) to review vendor quotes, partner commitments and drill protocol draft.

## 6.4.A Issue - Procurement timeline is critically compressed and supply-chain risk is understated

The plan requires 100% of tranche-1 orders placed by Month 2 (2026-12-08)—only 2 months away. Kit specifications must be issued by Month 0.8 (2026-11-01), first call-offs placed by Month 1.2 (2026-11-14). February delivery is assumed for 30–40% of stock to reach homes by April–May. This leaves zero margin for vendor quotes, design iteration, or supply-chain delays. If any category (shading, fans, installation labor) slips by 4 weeks, home installations miss the peak-risk window (Months 6–7 = 2027-04-08 to 2027-05-08). The contingency (€280k) cannot cover both a taxi-only fallback and procurement delay. No expedite-cost benchmark is documented.

### 6.4.B Tags

- supply_chain_compression
- delivery_schedule_risk
- contingency_inadequacy
- lack_of_vendor_quotes

### 6.4.C Mitigation

By 2026-10-15 (Month 0.3 = 2026-10-17), issue detailed RFQs to 5+ vendors per category (shading, fans, thermometers, installation labor) requesting firm quotes and lead-time commitments. By 2026-11-01, select primary and 2 backup suppliers per category; document price and timeline for expedited delivery (+10–15% cost). Place first 30% order by 2026-11-08 (not 2026-11-14) with signed SLAs for February delivery. Hold €80–120k expedite reserve inside contingency. Establish a weekly procurement dashboard tracking delivery vs. plan; trigger backup supplier activation if primary misses target by >1 week. Confirm all tranche-1 orders by 2026-12-01 (1 week early) to detect gaps before Month 2 (2026-12-08) gate.

### 6.4.D Consequence

Kit installation slips past May heat season, leaving 1,500+ highest-risk homes unprotected during peak-mortality months. Home intervention becomes an ineffective demonstrator. The €800k home-kit budget partially wasted on post-season work. Month 4 (2027-02-08) scale gate fails on lack of visible early-season impact. Funder holds back €1.5M, creating a €200–400k cash gap. Service degradation forces taxi-only operation mid-summer, adding €150–250k unbudgeted cost.

### 6.4.E Root Cause

Plan assumes procurement and hiring run in parallel with zero contingency. No vendor relationship established; quotes are not in hand. Expedite costs and lead-time uncertainty are not quantified. Procurement team likely does not yet exist (HR coordinator starts Month 0 = 2026-10-08). Unrealistic 8-week timeline for spec-to-order for a complex, multi-vendor, cross-category bundle.

## 6.5.A Issue - Month 2 (2026-12-08) and Month 4 (2027-02-08) readiness gates rest on drills in cool season; real-world validation is deferred until summer, creating a funding-release cliff

The €1.5M tranche-2 release depends on four gates at Month 4 (2027-02-08): 80% center hours, 60% outreach contact success, <45 min transport time, after-action closure. All evidence comes from drills and simulated alert days conducted in January–February—months with no historical heat events in Castellón. If evidence is deemed insufficient by the funder or regulator, partial-release rules allow only €750k (50%) at Month 4 (2027-02-08), leaving a €200–400k cash gap. Full June–July heat season will test operations without a confirmed second tranche. This forces a high-stakes re-test in March–April to unlock funds, with zero margin for operational tuning. Funder risk appetite for drill-only evidence is not documented.

### 6.5.B Tags

- gate_validation_timing
- cool_season_evidence
- cash_flow_cliff
- funder_alignment_missing

### 6.5.C Mitigation

Obtain written funder commitment by 2026-11-08 (Month 1 = 2026-11-08) that drill evidence is acceptable and details the partial-release rule (€750k at Month 4 = 2027-02-08 if gates are measurable but incomplete, full release by Month 5 after June real-event re-test). Design drills to mirror real alert stress: simulate 3+ consecutive hot-night events, peak transport demand (40+ simultaneous requests), refuge surge (80%+ occupancy), and outreach fatigue (12+ hours continuous). Document drill assumptions and limitations in the after-action report. Establish a 'summer validation checkpoint' at Month 8 (2027-06-08): if June–July real events occur, reconcile drill vs. actual performance and confirm final funding. Hold €120k tranche-2 contingency until Month 7 (2027-05-08) re-assessment. Pre-agree a 'plan B' if gates are unmet: identify which services would be cut to fit into tranche-1 only (e.g., reduce kits to 1,000, scale refuges to 6 sites).

### 6.5.D Consequence

Funder disputes drill evidence at Month 4 (2027-02-08) and withholds €1.5M pending real-event proof. City faces a €200–400k cash gap mid-February; must cut or delay refuge staffing, transport retainer, or home kits. Outreach momentum is lost; volunteer drivers stand down; emergency hiring and retraining in May under crisis pressure. If re-test is deferred to June and heat events are mild, the second tranche may never release. Playbook credibility damaged: other EU cities view the model as unproven and risky.

### 6.5.E Root Cause

Plan accepts cool-season gates as a given constraint but does not secure prior funder commitment in writing. Partial-release rule was added late and is untested. No 'Plan B' budget scenario for tranche-2 non-release. Evaluation design does not pre-specify what drill evidence constitutes 'success' in funder's eyes. Assumes good-faith interpretation by funder rather than contractual clarity.

## 6.6.A Issue - Staffing and volunteer recruitment are aggressive, compressed, and lack documented recruitment pipelines or retention strategy

The plan requires 43 FTE at peak (Months 4–7 = 2027-02-08 to 2027-05-17), including 10 handypersons, 18 center staff, 3 dispatchers, 6 outreach workers and 40 volunteer drivers. Hiring is staggered (40% Month 3 = 2027-01-08, 40% Month 4 = 2027-02-08, 20% Month 5 = 2027-03-08), with all in post by Month 6.7 (2027-04-29). Volunteer recruitment must produce 40 vetted drivers by Month 3 (2027-01-08) with only 4–8 weeks of lead time per vetting. No recruitment pipeline evidence is documented (partnerships with job centers, faith organizations, universities). Fatigue management is listed but assumes 3–4 day rotations; multi-day heat events (July–August at Months 9–11 = 2027-07-08 to 2027-09-08) will test retention and reliability. No documented exit or turnover plan if volunteers burn out mid-season.

### 6.6.B Tags

- aggressive_hiring_timeline
- volunteer_recruitment_unproven
- fatigue_risk_understated
- turnover_risk_no_plan
- no_recruitment_partnerships

### 6.6.C Mitigation

By 2026-10-22 (Month 0.5 = 2026-10-23), identify and sign MOUs with 3–5 recruitment partners (job centers, faith organizations, charitable networks, universities, retired professional associations). By 2026-11-08 (Month 1 = 2026-11-08), launch volunteer driver recruitment campaign with a clear value proposition ('Help save lives. 20–30 h/month, flexible, €12–15/h, safeguarding training provided'). Target 60–80 applicants to achieve 40 vetted by Month 3 (2027-01-08). Establish a rolling vetting cohort every 2 weeks (Months 1–4 = 2026-11-08 to 2027-02-08) rather than a single batch. For paid staff (center, dispatch, outreach), hire an HR/recruitment coordinator at Month 0 (2026-10-08) (0.5 FTE, €25k for 6 months). Create a staff retention plan: competitive pay (€16–18/h for center assistants), mental-health support during surge, peer debriefing after alerts, and a 'hero' recognition scheme. If volunteer recruitment falls short of 20 by Month 1.5 (2026-11-23), immediately scale the taxi retainer (from €80k capped to €120k) and reduce kit targets to 1,500 to free budget. Conduct a 'surge simulation' at Month 5.5 (2027-03-23): run a 72-hour continuous alert drill to test staff and volunteer endurance; use results to adjust rotations and staffing before the season.

### 6.6.D Consequence

Volunteer shortfall at Month 3 (2027-01-08) forces unplanned budget reallocation: taxi retainer scaled up (+€40–80k), home kits cut to 1,500 or 1,000, outreach reach reduced by 20–30%. Mean transport pickup time exceeds 45 min; Month 4 (2027-02-08) gate fails on transport-time criterion. Volunteer burnout mid-season (July–August, Months 9–11 = 2027-07-08 to 2027-09-08) leaves refuge shifts unstaffed or dispatch queues unmanaged. Multi-day heat wave triggers emergency recalls or unpaid overtime, damaging staff morale and retention into Year 2. Project credibility damaged: other EU cities question model's sustainability with limited funding.

### 6.6.E Root Cause

Plan assumes availability of volunteer drivers without evidence of recruitment market or partnerships. Vetting timeline (4–8 weeks per person) is realistic but aggressive given zero lead time. No contingency plan if recruitment underperforms. Fatigue and burnout are listed as risks but the mitigation (rotations + training) is generic; no real-world pilot data from other EU heat programs. Assumes municipal HR capacity to hire 43 FTE in 6 months without documented capacity.

---

# 7 Expert: Community Engagement & Trust-Building Practitioner

**Knowledge**: Migrant integration and language access, community co-design methods, faith-leader and peer-ambassador recruitment and training, trust-building in marginalized communities, misinformation counter-narratives, multilingual messaging design and testing, enrollment referral networks

**Why**: The plan names recent migrants and people living alone as priority groups but provides only generic 'trusted-messenger briefings' and 'focus-tested messages' without: (1) a local migrant-language audit (4-6 languages 'to be confirmed' Month 0 = 2026-10-08); (2) a co-design protocol with migrant organizations and faith leaders; (3) risk mitigation for misinformation (alcohol, fan misuse) beyond '≤4 h correction'; (4) enrollment validation (will intermediary calls succeed with migrants distrustful of official channels?). The SWOT identifies 'weak trust among migrants' as a threat. This expert designs enrollment pathways that actually reach migrants, tests messaging with them, and builds referral networks through trusted local figures.

**What**: By Month 0 (2026-10-08), audit the local migrant population (census data, NGO networks, faith leaders, language communities) and confirm the 4-6 non-official languages and a map of trusted organizations per language. By Month 0.5 (2026-10-23), recruit 8-12 paid community ambassadors (10-15 h/week, ~€7k total per person for 12 months) from migrant and faith organizations; brief them on the program and role. By Month 1 (2026-11-08), co-design enrollment messages, cooling-center welcome scripts and escalation language with ambassador focus groups; test drafts with ≥20 residents per language. By Month 2 (2026-12-08), train ambassadors on heat-illness signs, de-escalation and referral; establish a rapid-response process for misinformation (ambassador reports → communications lead reviews ≤4 h → corrected message deployed same day); track referral volume and contact outcomes by language.

**Skills**: Community co-design and participatory methods, multilingual communication design and testing, migrant community engagement, faith-leader partnerships, peer-ambassador recruitment and training, misinformation identification and counter-narrative design, trust-building in marginalized groups

**Search**: community engagement migrant integration, multilingual public health messaging, peer ambassador training, co-design health programs, faith leader partnerships public health

## 7.1 Primary Actions

- By Month 0.5 (2026-10-23), commission rapid resident-research (focus groups + interviews with ≥150 older isolated residents, recent migrants, homeless people) to identify what trust-building offer (e.g., trusted messenger first call, visible cooling kit, named contact guarantee) would drive enrollment among the most distrustful cohorts; use findings to redesign enrollment strategy beyond intermediary lists alone.
- By Month 1 (2026-11-08), conduct language-mapping survey of Castellón de la Plana's migrant and elderly neighborhoods (20–30 interviews per area across 5–7 high-concentration zones) to verify actual language mix and geographic clusters; allocate ≥€120k additional language budget and hire 2–3 full-time bilingual outreach coordinators to lead field enrollment and first-contact teams (not just interpretation).
- By Month 1 (2026-11-08), appoint a dedicated 'Community Trust Lead' (0.75 FTE) and allocate ≥€150k to immediately map and engage faith leaders, migrant associations, Roma representatives, homeless-service NGOs, and peer-support networks; schedule 5–7 co-design workshops by Month 1.5 (2026-11-23) asking communities 'What would make you believe this?' and 'Who would you trust to deliver it?'
- By Month 2 (2026-12-08), contract 8–12 community-vetted peer ambassadors (not part-time volunteers, but paid trusted community members with 15–20 h/week capacity) in each priority neighborhood; finalize messaging through co-design (not central templates); brief all messengers on heat-illness escalation, misinformation rebuttals, and rapid-response protocols.
- By Month 1.5 (2026-11-23), finalize GDPR-compliant data-processing agreements with all partner organizations AND document a secondary consent pathway for residents who refuse official intermediaries but will provide contact details to trusted community messengers; ensure bilingual staff capacity to conduct these consent conversations.
- Redefine the Month 4 (2027-02-08) outreach-contact-success gate to measure geographic coverage within high-risk neighborhoods (≥60% contact success among residents living in the top 3–5 high-deprivation areas, including unhoused populations), not just among enrolled registry members; this forces equitable reach, not registry convenience.

## 7.2 Secondary Actions

- By Month 2 (2026-12-08), require each cooling-center site to have at least one bilingual staff member (Spanish + one local minority language) on duty during alert hours; integrate bilingual hire into the 18-FTE refuge staffing plan, not as an add-on.
- By Month 3 (2027-01-08), establish a weekly 'Community Messenger Feedback Loop' where peer ambassadors and faith leaders report back on what misinformation, fears, and false beliefs they are hearing in informal networks; feed this into daily operational briefings and activate rapid-response counterspeech within 4 hours of each alert.
- By Month 4 (2027-02-08), conduct a qualitative enrollment audit: for each of the 3,000 enrolled residents, document source of enrollment (which intermediary, which messenger, which channel); disaggregate by age, language, housing type, and neighborhood; publish disaggregated data as equity metric; if any neighborhood or group is <30% of proportional target, trigger immediate outreach surge.
- By Month 6 (2027-04-08), before the public pre-season campaign launch, hold a 'community-messenger validation workshop' where peer ambassadors, faith leaders, and residents review all campaign materials (radio, flyers, SMS templates, center signage) and certify that messages are credible, culturally appropriate, and will not trigger distrust; revise any material that community validators flag.
- By Month 9 (2027-07-08), conduct a post-hoc audit of alert-day enrollment and service uptake, disaggregated by community and language; for any group that underutilized services, interview non-users about barriers (trust, language, accessibility, belief); document findings for Year-2 community co-design.
- From Month 0 (2026-10-08) forward, ensure that the Community Trust Lead (or equivalent) has a seat in the incident-commander daily SITREP at 08:30 and in monthly strategic reviews; this ensures community-trust risk surfaces alongside operational risk.
- Identify and pre-contract (by Month 1.5 = 2026-11-23) at least one university or independent research partner with expertise in migrant health and community trust-building to conduct a concurrent qualitative evaluation of trust dynamics; use findings to iterate the model mid-season (Month 7 = 2027-05-08) and to strengthen Year-2 design.

## 7.3 Follow Up Consultation

"In the next consultation, address: (1) Which specific communities in Castellón de la Plana are highest-risk and most distrustful? Bring neighborhood-level health and social data, and preliminary interviews with community leaders. (2) What evidence exists that intermediary-held lists and official phone lines work with isolated, mistrustful populations? Bring examples from other EU cities or research citations. (3) What is the actual budget flexibility for community-trust infrastructure (language staff, peer ambassadors, co-design workshops)? Bring a detailed line-item budget for the €170k communications category, with recommendations on reallocation. (4) Who will lead community engagement—is it embedded in the municipal team or outsourced to an NGO? Bring a proposed staffing model and accountability structure. (5) How will you measure whether trust has improved by Month 12 (2027-10-08)? Bring a qualitative-evaluation framework (not just enrollment numbers, but resident beliefs and attitudes)."

## 7.4.A Issue - Enrollment and outreach strategy bypasses the most isolated residents—intermediary-held lists alone will miss 80% of high-risk people who distrust formal services

The plan targets 3,000 enrolled residents (≈9% of 65+) via housing associations, social services, NGOs and pharmacies. However, these intermediaries predominantly reach people already connected to services. The most isolated—particularly older residents living alone, recent migrants with language barriers, and people with historical trauma regarding authorities—are systematically absent from these lists. Canvassing by building and street sentinels are mentioned but not resourced as primary routes, leaving a coverage gap of 15,000–20,000 high-risk people unreached by alert calls. Without a 'no-wrong-door' enrollment strategy that meets people where they are (markets, religious settings, soup kitchens), the program will concentrate resources on the easiest-to-reach 10% and miss those with highest mortality risk.

### 7.4.B Tags

- outreach-coverage-gap
- isolation-exclusion
- trust-deficit-migrant-elderly
- enrollment-bottleneck
- equity-blind-design

### 7.4.C Mitigation

By Month 1 (2026-11-08), commission rapid resident research (10–15 focus groups, 100–150 interviews) with older isolated residents, recent migrants, and people experiencing homelessness to identify what trust-building offer would drive enrollment (e.g., a trusted community messenger making the first call, a visible cooling kit as proof of benefit, a named human contact guarantee). Use findings to design a dual-track enrollment: intermediary-held lists for the reachable 10%, plus a community-ambassador-led outreach-to-isolation strategy for the remaining 90%. Allocate ≥€80k and 2 FTE from the communications budget to deploy 12–15 paid 'heat guides' in markets, places of worship, migrant/Roma associations, and soup kitchens from Month 3 (2027-01-08). Redefine the 60% outreach-success gate to measure contact attempts within 200 m of the target population's geographic clusters, not just the enrolled registry.

### 7.4.D Consequence

Without mitigation, 80% of the highest-risk isolated residents will remain outside the program, defeating the equity mandate. A heat event in July will reveal that enrolled residents are predominantly already-connected, employed older adults in formal housing—not the most vulnerable. The program's legitimacy with migrants, Roma, and homeless communities will collapse; subsequent Year-2 outreach will face active mistrust. Media coverage will frame the program as 'helping the connected and abandoning the isolated.' Reputational damage will undermine municipal capacity to run future public-health programs in marginalized communities.

### 7.4.E Root Cause

The intermediary-list model was selected for GDPR simplicity and speed, not for reach. The plan conflates legal safety with equitable coverage. No resident research was done to validate what would drive enrollment among the most distrustful cohorts (e.g., undocumented migrants, older people who have never called a government helpline). The plan also conflates 'opt-in' with 'accessible': an opt-in registry run by housing associations will miss people who are not tenants (subletting, informal arrangements).

## 7.5.A Issue - Language-access architecture is under-resourced and will fail to reach non-Spanish speakers at point of urgent need; interpretation is a compliance checkbox, not a trust-building lever

The plan allocates ≈€67k and 8–12 ambassadors (10–15 h/week) to serve 4–6 non-official languages across a city where migrant populations are concentrated in specific neighborhoods. The helpline will have telephone interpretation, but the outreach model depends on partner staff (housing caretakers, social workers, pharmacists) who are predominantly Spanish-monolingual. Door-knock teams will arrive with flyers in multiple languages but no bilingual staff. Cooling-center welcome desks will rely on pictograms and short phrases, which fail to convey safety-critical advice (fan use in extreme heat, medication interactions, heat-illness escalation). Recent migrants—identified as a priority group—will receive alert messages but not consent-based enrollment conversations in their preferred language, reducing uptake by an estimated 30–50%. Language access has been framed as a translation task, not as a trust-building infrastructure that requires bilingual staff presence in the field.

### 7.5.B Tags

- language-access-failure
- compliance-checkbox
- migrant-exclusion
- trust-infrastructure-missing
- point-of-contact-gap

### 7.5.C Mitigation

By Month 0.5 (2026-10-23), conduct a rapid language-mapping survey of Castellón de la Plana's migrant and elderly neighborhoods (20–30 short interviews in each of the 5–7 highest-concentration areas, plus municipal social services data) to identify the actual top 4–5 languages and geographic clusters. Allocate ≥€120k (€50k additional language budget) to hire 2–3 full-time bilingual outreach coordinators (one per major language cluster) from Month 2 (2026-12-08) onward, with authority to make enrollment calls and lead first-contact door-knock teams. Train these staff as 'heat health navigators' with brief clinical training (2-hour heat-illness recognition module), not just interpreters. Relocate ≥30% of the ambassador budget to support these coordinators. By Month 6 (2027-04-08), require all cooling-center sites to have at least one bilingual staff member on duty during alert hours, not just access to a phone line.

### 7.5.D Consequence

Without mitigation, non-Spanish speakers will fail to understand heat alerts, will not enroll, and will not seek cooling even when alerted. A multi-lingual heat event with media coverage will show that migrant residents were unreached, creating political pressure for a response that comes too late. Healthcare systems will see heat-related ED visits concentrated in non-Spanish-speaking cohorts, signaling a failed targeted intervention. Loss of trust among migrant communities will ripple into future public-health programs. The City will be seen as having allocated €67k to language work but not delivering accessible services to the named priority group.

### 7.5.E Root Cause

Budget and hiring constraints pushed language access to the margins. The plan treats translation as a cost item (leaflets, interpretation line) rather than as core field capacity. No labor model exists for bilingual outreach staff, and the ambassador model is part-time and concentrated in a narrow budget. The plan also lacks mapping of migrant neighborhoods and demographic data on which languages are spoken where; decisions are being made on assumed language mix ('candidates: Arabic, Romanian, Portuguese, to be confirmed') rather than verified local data.

## 7.6.A Issue - Trust infrastructure is entirely missing; there is no strategy to activate faith leaders, peer networks, and community organizations as credible messengers before the first heat event, making the program dependent on official channels that marginalized residents avoid

The plan mentions 'trusted messengers'—pharmacists, GPs, caretakers, faith leaders—but allocates no budget, no hiring, and no institutional relationship-building before Month 6 (2027-04-08), when the pre-season campaign launches. There is no evidence that faith leaders, Roma association heads, migrant mutual-aid networks, or peer-support groups have been contacted, briefed, or contracted to co-design heat-safety messaging. The 8–12 language ambassadors are part-time and paid, not embedded in community structures. When the first alert arrives in June, the city will attempt to reach isolated residents via official phone lines and cooling centers—the exact channels these residents distrust. No counterspeech infrastructure exists to counter misinformation (alcohol, misused fans) that will inevitably circulate in informal networks. The plan frames communication as a campaign (messages broadcasted to a mass audience) rather than as a dialogue-and-relationship ecosystem that makes people believe a safety message enough to act on it.

### 7.6.B Tags

- trust-infrastructure-absent
- community-partnership-shallow
- misinformation-undefended
- faith-leader-engagement-tokenistic
- peer-network-bypassed

### 7.6.C Mitigation

By Month 0 (2026-10-08), immediately allocate ≥€150k and one dedicated 'Community Trust Lead' (0.75 FTE, reporting to the incident commander) to map and engage faith leaders, migrant associations, Roma community representatives, homeless-service NGOs, older-resident peer groups, and women's networks in Castellón de la Plana. By Month 1 (2026-11-08), hold 5–7 structured co-design workshops with representatives of each community, asking: 'What would make you believe a heat-health message?' and 'Who in your community would you trust to deliver it?' Use findings to design community-specific heat-safety messaging (not centralized campaign templates) and to identify and contract 8–12 peer ambassadors per community (not language interpreters, but trusted community members). By Month 2 (2026-12-08), finalize and brief all contracted messengers on heat-illness recognition, escalation rules, and misinformation rebuttals (specific scripts for alcohol myths, fan misuse, etc.). Allocate a rapid-response budget (€30k) to activate messenger networks within 4 hours of a misinformation alert (e.g., WhatsApp groups, phone trees, local radio spots) to correct false advice. Establish a weekly 'messenger feedback loop' where community members report back on what they're hearing in informal networks, feeding into daily operational briefings.

### 7.6.D Consequence

Without mitigation, the program will spend €170k on communications that do not reach or persuade the most isolated residents. When the first heat event occurs, isolated older residents and migrants will not answer official calls; they will rely on family advice, street gossip, and informal networks—many of which will promote unsafe practices (opening windows, alcohol, lying in the sun). Heat-illness cases will spike in populations the program claimed to serve. Media investigation will reveal that the city paid for multilingual flyers that sat in community centers but never reached residents. Community leaders will report (privately, then publicly) that the city never asked them to help. Trust in municipal public health will drop for a generation; subsequent interventions will be met with skepticism and refusal to participate.

### 7.6.E Root Cause

The plan is a municipal operations document, not a community-trust document. Trusted-messenger engagement is a secondary decision (Decision 9), allocated ≈€50–70k, and scheduled to happen after procurement and operational setup are complete. The underlying logic is that official channels (phone lines, centers, flyers) can deliver messages, and trusted messengers are a nice-to-have amplifier. But for migrants, Roma, homeless people, and isolated older residents, official channels have low credibility; the messenger IS the message. The plan also has no community-co-design process; it was written by a municipal team with external input, not co-designed with the priority communities themselves.

---

# 8 Expert: Heat-Health Evaluation & Data Science Lead

**Knowledge**: Heat-attribution epidemiology, small-area health data analysis, temperature-adjusted mortality modeling, EMS/ED coding standards, time-series analysis with seasonal adjustment, heat-threshold calibration, comparison-group design, data-quality and validation workflows

**Why**: The plan's evaluation strategy is sketched lightly: 'pilot vs matched districts and prior years, temperature-adjusted, aggregate counts only.' However, four critical gaps exist: (1) baseline EMS/ED/mortality data is provisional (80-120 EMS, 15-25 deaths) and unvalidated; (2) coding practice for 'heat-related' varies by hospital and EMS service (explicit ICD-10 codes vs clinician judgment vs proxy indicators); (3) small-area counts in a 170k city are noisy, so the evaluation may be unable to detect real effects within one season; (4) the Month 4 (2027-02-08) gate includes no mortality outcome, only operational KPIs, so credibility of 'harm reduction' claims rests on EMS/ED data quality. This expert validates baselines, agrees coding standards with health partners, and specifies a realistic evaluation design that accounts for small-area limitations.

**What**: By Month 0 (2026-10-08), request detailed EMS and hospital baseline data (heat-coded calls, ED visits, timestamps) for ≥2 prior summers, and clarify coding practice (which ICD-10 codes count as 'heat-related'?). By Month 1 (2026-11-08), audit the data quality: completeness (% of records with heat coding), consistency (same codes across services), and temporal pattern (do peaks match known heat events?). By Month 2 (2026-12-08), finalize definitions and agree a temperature-adjusted baseline (e.g., average heat-related calls per 1°C above 32°C). By Month 4 (2027-02-08), pre-specify the evaluation protocol (comparison group selection, adjustment variables, statistical methods, subgroup analyses) and register it with a university partner; specify realistic power to detect a 10-15% reduction. By Month 12 (2027-10-08), deliver evaluation report with explicit confidence ranges and attribution limits (e.g., 'attributable to the program' vs 'coincident with').

**Skills**: Epidemiologic analysis and attribution methods, time-series temperature adjustment, small-area analysis and privacy protection, EMS/ED data validation and coding, comparison-group design, statistical power calculation, heat-health thresholds and calibration, data visualization for non-technical audiences

**Search**: heat health epidemiology evaluation, EMS ED coding standards heat illness, small-area health data analysis, temperature attribution mortality, heat threshold calibration

## 8.1 Primary Actions

- Obtain written funder sign-off on the drill-as-evidence protocol and the partial-release rule (€750k at Month 4 = 2027-02-08 if insufficient real evidence, remainder after May re-test) by Month 0.5 (2026-10-23). If the funder will not accept this, immediately escalate and renegotiate the funding structure (full disbursement with clawback, or identify contingency funding) before proceeding to any other work.
- Replan procurement timeline: issue specs by Month 0.5 (2026-10-23), pre-qualify backup suppliers with emergency-activation agreements by Month 1 (2026-11-08), place first-tranche kit orders by Month 1 (2026-11-08) (not Month 1.2 = 2026-11-14), and arrange interim storage by Month 1.5 (2026-11-23). Commit the €200k expedite premium immediately; do not hold it contingent. Confirm all first-tranche deliveries locked in for February 2027 by Month 1.5 (2026-11-23).
- Expand outreach target from 3,000 enrolled to 5,000–6,000 total contact attempts, aiming for ≥2,500 enrolled + 1,500–2,500 one-time reached. Add a targeted door-knock phase for top-floor and social-housing blocks in Months 5–6 (2027-03-08 to 2027-04-08) with 3 temporary staff to reach isolated residents missed by intermediaries. Redefine the 60% contact-success gate to measure contact rate by neighborhood deprivation index and housing type, not just enrollment rate.
- Place cooling-center facility contracts and execute accessibility audits by Month 1.5 (2026-11-23). Confirm ≥50% of places are fully accessible (wheelchair ramps, accessible toilets, quiet rooms) by Month 2 (2026-12-08). Any site that cannot meet accessibility by Month 2 (2026-12-08) should be deferred to July or replaced; do not defer until later.
- Engage a GDPR specialist law firm and obtain written legal opinion confirming that the intermediary-held-list model complies with Spanish law and GDPR by Month 1 (2026-11-08). Finalize and execute data-processing agreements with all partner organizations (housing associations, social services, NGOs, pharmacies) by Month 1.5 (2026-11-23). Brief 50–80 partner staff on confidentiality and consent protocols by Month 2 (2026-12-08). Do not rely on informal verbal agreement.

## 8.2 Secondary Actions

- Commission verified baseline data on heat-related EMS calls, ED visits and mortality coding from the municipal hospital, EMS service and primary-care network by Month 1 (2026-11-08). Compare to the plan's provisional estimates (80–120 EMS calls, 15–25 excess deaths); flag any material gaps and adjust the evaluation design and gates if baseline is much smaller or larger than estimated.
- Establish a monthly risk-review checkpoint at the project steering committee: Month 1 (2026-11-08), Month 2 (2026-12-08), Month 3 (2027-01-08), and Month 4 (2027-02-08, 2026-12-08, 2027-01-08, 2027-02-08). At each checkpoint, review: (1) funder confirmation status, (2) procurement order status and delivery confirmation, (3) volunteer recruitment pipeline and vetting progress, (4) partner DPA and consent tracking, (5) facility accessibility audit results. If any item is >2 weeks behind, escalate to the incident commander and activate contingency plans (e.g., scale taxi retainer if volunteers lag).
- Conduct a focus group test of the 'Hot Night Guarantee' messaging (call within X hours, ride within 45 minutes, cool home) with 15–20 high-risk residents (age 70+, living alone, low digital literacy) by Month 1 (2026-11-08). Measure: Would this offer make you enroll? What changes would make it more credible? Use results to refine enrollment messaging and ensure the promise is realistic given transport and staffing capacity.
- Pre-specify the drill protocol (final by Month 2.5 = 2026-12-23) with explicit realism criteria: simulate multi-day heat event (48–72 hours), include 3–5 volunteer failures/absences, test center occupancy surge to 80% capacity, simulate 2–3 escalations to EMS, and measure staff fatigue/error rates after 48 hours. Document drill evidence standards in writing and share with the funder by Month 2.5 (2026-12-23) so no surprises emerge at the Month 4 (2027-02-08) gate.
- Recruit volunteer drivers in fortnightly cohorts starting Month 0.5 (2026-10-23), with vetting and training 4–8 weeks. Require background checks, insurance verification, and 2-hour safeguarding training per person. Target ≥20 vetted by Month 2 (2026-12-08); if <15 are in the pipeline by Month 1.5 (2026-11-23), immediately scale the taxi retainer proportionally (estimate +€20–40k per 10-volunteer shortfall). Do not wait until Month 4 (2027-02-08) to discover insufficient volunteer capacity.
- Establish a nurse-advice triage line (0.5 FTE) by Month 2 (2026-12-08) for outreach staff to call with suspected heat-illness cases. Develop a checklist of escalation criteria (confusion, loss of consciousness, skin temperature, core-temperature indicators) and train all 25–35 outreach staff on the protocol by Month 2 (2026-12-08). Test the line with 3–5 mock calls during the month-2 readiness gate drill to ensure it integrates with EMS dispatch.
- Identify and lock in a Year-2 funding source (EU climate funding, national health budget, regional authority co-financing, or phased municipal budget) by Month 9 (2027-07-08), before the playbook is finalized. If no source is identified by Month 10 (2027-08-08), recommend to the funder and municipality which components would be cut to fit a reduced Year-2 budget (likely: home kits and handyperson service, retaining refuges and transport). Include this tradeoff in the Year-2 roadmap.

## 8.3 Follow Up Consultation

At the next consultation (recommended Month 0.5 = 2026-10-23), bring: (1) written funder response to the drill-as-evidence and partial-release rule; (2) preliminary supplier quotes and lead-time confirmations for kits and transport; (3) baseline EMS/ED/mortality data from hospital and EMS; (4) confirmed facility-use commitments from ≥8 of 10 proposed cooling-center sites; (5) volunteer-recruitment progress (numbers in pipeline, vetting timeline per candidate); (6) GDPR counsel engagement letter and preliminary legal advice on the intermediary-list model; (7) results of the 'Hot Night Guarantee' focus group. These six items are the leading indicators of whether the Month 2 (2026-12-08) and Month 4 (2027-02-08) gates are achievable. If any is stalled or shows negative indicators, escalate immediately to incident command.

## 8.4.A Issue - Cool-Season Gates Create Unmeasurable Evidence Problem

The Month 2 (2026-12-08) and Month 4 (2027-02-08) gates fall entirely in the cool season (November–February in Spain). Real heat events will not occur until June at earliest. The plan proposes drill-based evidence instead, but drills cannot replicate multi-day fatigue, heat-stress decision-making, or volunteer/staff burnout under real conditions. Funders and regulators may reject drill evidence as insufficient. If the €1.5M tranche-2 release is delayed pending real heat data, a €200–400k cash gap emerges that exceeds the €160k available tranche-1 contingency. This is a structural flaw, not a minor risk.

### 8.4.B Tags

- gate-evidence-gap
- cash-flow-risk
- funder-assumption-undocumented
- seasonal-timing-mismatch

### 8.4.C Mitigation

Immediately (by Month 0.5 = 2026-10-23) obtain written funder sign-off on the partial-release rule and drill-as-evidence protocol before any other work begins. If the funder will not accept drills, propose three alternatives: (a) redefine gates to require only operational readiness (contracts signed, staff hired, no performance thresholds) and defer performance gates to post-season; (b) negotiate a full €3.5M front-loaded disbursement with a clawback clause if gates are missed; (c) identify contingency funding (EU climate or health grants) to cover the €200–400k gap if tranche-2 is delayed. Document the chosen path in a signed amendment to the funding agreement by Month 1 (2026-11-08).

### 8.4.D Consequence

Without funder written agreement before Month 2 (2026-12-08), the program faces a 40–60% risk of tranche-2 withholding at Month 4 (2027-02-08). This forces mid-season cuts to transport retainer (raising pickup times above 45 min), cooling-center hours, or outreach staff. Service will degrade during the first real heat event, causing harm to enrolled residents and generating reputational damage ('pilot failed when it mattered'). The playbook becomes unusable for other cities because the pilot could not demonstrate operational success.

### 8.4.E Root Cause

The plan was designed to meet a two-month delivery deadline (Month 0 = 2026-10-08 to Month 2 = 2026-12-08 to 2026-12-08) in a cold climate. The gates were set to happen early to release tranche-2 before the funding year ends, but early means cool-season. No one documented the funder's appetite for drill-based evidence, so the gap was not surfaced until now. The root cause is compressed timeline + seasonal mismatch + undocumented assumption about evidence standards.

## 8.5.A Issue - Procurement Critical Path Compressed into 8 Weeks; Supply-Chain Buffer Missing

The plan requires all tranche-1 procurement orders placed by Month 2 (2026-12-08)—a hard gate. This means specs by Month 0.8 (2026-11-01), framework/below-threshold orders by Month 1.5 (2026-11-23), and all tenders closed by Month 2 (2026-12-08). For home kits and transport, delivery windows are extremely tight: first-tranche kits must arrive by Month 4 (2027-02-08) and be 80% installed by Month 5 (2027-03-08) to enable May–June deployment. If any supplier slips 4–6 weeks (normal for EU industrial supply), kits arrive in June–July after the first heat event. The plan notes the supply-chain risk but does not allocate enough schedule or budget buffer to absorb it.

### 8.5.B Tags

- procurement-schedule-risk
- supply-chain-buffer-insufficient
- delivery-window-tight
- contingency-not-pre-committed

### 8.5.C Mitigation

Replan procurement timeline: (1) Issue detailed specs to suppliers by Month 0.5 (2026-10-23), 5 days earlier than planned; request quotes + lead-time confirmation by Month 0.8 (2026-11-01). (2) Pre-qualify all backup suppliers and negotiate 'emergency activation' agreements by Month 1 (2026-11-08) specifying that 20–30% of first-tranche stock can be ordered at 7-day notice with expedited freight. (3) Place the first-tranche kit order (600–800 units) by Month 1 (2026-11-08), not Month 1.2 (2026-11-14), to gain one week of buffer. (4) Arrange interim storage (≥200 units) at a municipal facility by Month 1.5 (2026-11-23) so kits can be received and staged early if primary supplier delivers ahead of schedule. (5) Include in the retainer contract a 10% buffer-stock allowance (100–200 extra units) so if one tranche is lost in transit, a backup exists. Commit the €200k expedite premium immediately; do not hold it contingent.

### 8.5.D Consequence

If procurement slips 4–6 weeks, 60–80% of home kits will not be installed until July–August, missing the May–June peak-risk season entirely. The program will then have claimed a 2,000-home intervention on paper but delivered it after the first major heat event has already occurred. This breaks the enrollment promise ('your home will be cooler by May') and undermines trust for Year 2. Alternatively, the city cuts home kits from 2,000 to 1,000–1,500 to fit the revised timeline, which reduces coverage and the program's flagship tangible benefit.

### 8.5.E Root Cause

The procurement timeline was planned optimistically without realistic EU supplier lead times (6–8 weeks for mass-production items) or buffer for specification changes, supplier price renegotiation, or first-article inspections. No pre-commitment of backup suppliers or interim storage was made early enough. The €200k expedite budget was not actively deployed; it remained a contingency line instead of an active risk-mitigation lever.

## 8.6.A Issue - Outreach Reach Severely Constrained: 3,000 Enrolled ≈9% of 65+, Misses Most Isolated Residents

The outreach model targets 3,000 enrolled high-risk residents by Month 7 (2027-05-08), approximately 9% of the estimated 34,000 residents aged 65+. The plan uses intermediary-held lists (housing associations, social services, NGOs, pharmacies), which are GDPR-safe but depend on existing service contact. Residents who are isolated, living outside formal housing, mistrustful of services, or recently arrived will not appear on any list and will not be contacted unless a 'no wrong door' heat-line call reaches them. The 60% contact-success gate (Month 4 = 2027-02-08) measures reach only for enrolled residents; it says nothing about the 91% not enrolled. This is a coverage failure disguised as an operational gate.

### 8.6.B Tags

- outreach-coverage-gap
- isolated-residents-missed
- enrollment-rate-9-percent
- gate-measures-wrong-denominator
- equity-goal-not-met

### 8.6.C Mitigation

Redefine success metric and expand enrollment strategy: (1) Set an absolute outreach goal of 5,000–6,000 contact attempts (not 3,000 enrolled), aiming for 50% enrollment = 2,500–3,000 signed up, plus 1,500–2,500 people reached once via heat-line or street teams (even if not formally enrolled). (2) Add a targeted door-knock phase in Month 5–6 (2027-03-08 to 2027-04-08) for top-floor and social-housing blocks with low intermediary reach (neighborhoods with <50% coverage). Use the 6 outreach FTE and hire 3 temporary door-knock staff (Months 5–7 = 2027-03-08 to 2027-05-08) to cover ≤1,000 additional households in priority blocks. This finds isolated residents who avoid formal services. (3) Require intermediary partners to report their outreach attempt rate and their base (how many residents do they have access to per organization?), so gaps are visible. (4) Measure equity: track enrollment by neighborhood deprivation index and housing type. Report what percentage of the 65+ population in each neighborhood was ever reached, not just what percentage was enrolled.

### 8.6.D Consequence

Without expanded outreach, the program will have reached only the 'easy' 9% of residents who were already known to services. When a heat event occurs, the 91% unreached will not have transport pre-arranged, will not be enrolled in the phone-check-in list, and will not know about cooling centers. Mortality and morbidity will be concentrated in the unreached group. A post-event analysis will reveal that the program helped its enrollees but missed its most isolated targets, undermining the 'equity' claim and the pilot's credibility for scaling. The playbook will be seen as a service for already-registered residents, not as a program for vulnerable populations.

### 8.6.E Root Cause

The plan conflated 'operationally safe and GDPR-compliant' (intermediary-held lists) with 'equitable reach.' It set a gate (60% contact success among enrolled residents) that measures operational fidelity for the people already enrolled, not coverage of the hardest-to-reach. The plan rejected building-level canvassing as too labor-intensive but did not cost a hybrid model: intermediary reach + targeted door-knock for low-reach neighborhoods. The root cause is a design bias toward legal safety and operational simplicity over equity and population reach.