**Verdict:** 🟢 USABLE

**Rationale:** The prompt describes a concrete 12-month heatwave mortality reduction program. It gives a budget (€3.5M, staged), go/no-go gates, scope areas, metrics, deliverables and realism constraints. The formatting instructions about numbers and voice are legitimate output guidelines, not injection.