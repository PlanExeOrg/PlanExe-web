## Suggestion 1 - Barcelona Climate Shelters Network (Xarxa de Refugis Climàtics)

Barcelona City Council's network of air-conditioned or cool public spaces (libraries, civic centers, schools, parks), launched in 2019 and expanded in later summers. Each site has set opening hours and a public map. The network works alongside the city's heat-wave plan and social-services outreach to older residents. Sites are municipal assets rather than new builds.

### Success Metrics

Number of shelters in the network (the city reports a figure, not verified here)
Share of residents within a short walk of a shelter (city-reported, not verified)
Visits per season, reported by the city or the Barcelona public health agency

### Risks and Challenges Faced

Uneven site quality and accessibility: the city published site information and expanded the network gradually.
Low awareness among vulnerable residents: communication moved through social services and neighborhood networks.
Staffing and opening hours at municipal sites: the network used existing site staff, with extended hours set by alert level.

### Where to Find More Information

https://www.barcelona.cat (search 'refugis climàtics')
Barcelona Climate Plan documents on the Ajuntament de Barcelona website
Agència de Salut Pública de Barcelona (ASPB) publications

### Actionable Steps

Contact the Barcelona City Council climate shelters programme team through the Ajuntament's official contact form or press office.
Ask the Agència de Salut Pública de Barcelona for its heat-plan evaluation lead, to discuss refuge utilization and alert triggers.
Request a call with the programme coordinator to review site-selection criteria and the accessibility checklist.

### Rationale for Suggestion

Closest Mediterranean, Spanish-language match for the 'many small walkable refuges' design. It shows how to use libraries and community centers without construction, publish accessibility information and link refuges to social services. Barcelona is far larger than Castellón, so the scale does not transfer directly. Its siting logic does.
## Suggestion 2 - Paris Plan Canicule and Registre Canicule (Ville de Paris / CCAS)

Paris runs a heat-wave plan with a voluntary registry of vulnerable residents (older, disabled or isolated people). The city's social-action agency (CCAS) phones registered people during alerts. The city also opens cooled rooms and 'cool paths' and runs a volunteer scheme (Paris Entraide / Registre Canicule). Alert levels follow Météo-France's national heat warnings.

### Success Metrics

Number of people registered (published periodically by the city; not verified here)
Share of registered people reached by phone during alerts (reported in post-event reviews)
National post-2003 mortality reductions in later heatwaves (Santé publique France analyses)

### Risks and Challenges Faced

Registry under-enrolls isolated people: enrolment was promoted through health professionals, social services and neighbours.
Call-capacity peaks during alerts: CCAS staff and volunteers were mobilised, and calls were prioritised by vulnerability.
Data-protection rules: registration is voluntary and consent-based with defined retention.

### Where to Find More Information

https://www.paris.fr (search 'plan canicule')
Santé publique France heat-health publications: https://www.santepubliquefrance.fr
Météo-France vigilance canicule documentation

### Actionable Steps

Contact the CCAS de Paris / Ville de Paris social-action department through the official website contact form to ask for the registry call protocol.
Contact Santé publique France's environmental-health unit for the evaluation methods behind heat-mortality estimates.
Ask for the consent form template and data-retention terms to compare with the Spanish AEPD requirements.

### Rationale for Suggestion

Provides a documented consent-based registry, a phone-tree protocol and a tiered response keyed to national warnings, all within normal municipal powers and GDPR. This is what the 'no wrong door' enrollment and phone-tree design needs. Paris is a capital with far more resources, so the scale differs. The protocols are reusable. The plan's intermediary-list model differs from Paris's city-held registry, so the legal basis needs separate review in Spain.
## Suggestion 3 - Ahmedabad Heat Action Plan (with NRDC and Indian Institute of Public Health Gandhinagar)

South Asia's first city-level heat action plan, launched in 2013 by the Ahmedabad Municipal Corporation with the NRDC and the Indian Institute of Public Health Gandhinagar. It uses colour-coded forecast-based alerts, trained health workers, outdoor-worker guidance, public education and cool-roof pilots. Ahmedabad has several million residents. Later evaluations and updates are available.

### Success Metrics

Published analysis estimating avoided deaths per year after implementation (figure from the peer-reviewed study; not verified here)
Expansion of the model to other Indian cities

### Risks and Challenges Faced

Alert fatigue and threshold calibration: thresholds were revised using local mortality data over successive years.
Reaching informal and outdoor workers: the plan used worker guidance, community health workers and media.
Attribution of mortality change: published analyses state their limits.

### Where to Find More Information

NRDC Ahmedabad Heat Action Plan reports: https://www.nrdc.org
Peer-reviewed evaluation of the plan (search Ahmedabad Heat Action Plan evaluation, e.g. in Environmental Health Perspectives or PLOS)

### Actionable Steps

Contact the NRDC India climate resilience team through the NRDC website to ask about alert-threshold calibration.
Contact the Indian Institute of Public Health Gandhinagar's climate-health researchers for the evaluation protocol.

### Rationale for Suggestion

Secondary suggestion, geographically distant. It is the best-documented example of a tiered alert ladder with pre-agreed actions and a published evaluation, which matches the plan's trigger design. Climate, housing and governance differ substantially from Spain, so only the alert, communication and evaluation structure transfer.

## Summary

Reference projects for a Castellón de la Plana heatwave pilot (~170k residents, €3.5M, tiered alerts, small refuges, intermediary-held outreach, volunteer drivers with taxi backup). Mediterranean examples come first. Barcelona's climate shelter network and Paris's registry-based heat plan are close matches in climate and policy. Ahmedabad's Heat Action Plan is distant but is the best evidence for tiered alerts. Figures are approximate unless stated. Contacts are organisational roles, not named individuals. Verify all links and contacts before use.