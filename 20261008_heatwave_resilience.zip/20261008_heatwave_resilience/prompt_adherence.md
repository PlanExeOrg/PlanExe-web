**Overall Adherence: 93%**

```
IMPORTANCE_ADHERENCE_SUM = (5×5 + 5×5 + 5×5 + 5×5 + 5×5 + 5×5 + 5×4 + 5×5 + 4×4 + 4×4 + 4×4 + 4×5 + 5×4 + 4×4 + 5×5) = 324
IMPORTANCE_SUM = 5 + 5 + 5 + 5 + 5 + 5 + 5 + 5 + 4 + 4 + 4 + 4 + 5 + 4 + 5 = 70
OVERALL_ADHERENCE = IMPORTANCE_ADHERENCE_SUM / (IMPORTANCE_SUM × 5) = 324 / 350 = 93%
```

## Summary

| ID | Directive | Type | Importance | Adherence | Category |
|----|-----------|------|------------|-----------|----------|
| 1 | Design a 12-month program to reduce heatwave-related mortality and serious illness in a mid-sized EU city (150k–400k residents), prioritizing vulnerable groups: 65+, chronic cardiovascular/respiratory disease, living alone, top-floor/poorly insulated housing, outdoor workers, unhoused people, recent migrants. | Requirement | 5/5 | 5/5 | Fully honored |
| 2 | Total budget €3.5M for 12 months, staged as €2.0M initial (Month 0 = 2026-10-08) + €1.5M conditional release at Month 4 (2027-02-08) only if gates met. | Constraint | 5/5 | 5/5 | Fully honored |
| 3 | Work within normal municipal powers; do not assume new legislation, perfect data sharing, or unlimited staffing. Design for GDPR constraints and limited health-record access. | Constraint | 5/5 | 5/5 | Fully honored |
| 4 | Banned words/approaches: blockchain, NFT, VR, AR, 'fully automated', 'AI-driven diagnosis'. Do not rely on apps as primary solution; assume many vulnerable residents lack smartphones. | Banned | 5/5 | 5/5 | Fully honored |
| 5 | Pilot city: Castellón de la Plana, Spain (~170k residents). Target population: 65+ ≈34,000; living alone ≈25,500; top-floor/poorly insulated ≈42,500 (estimates, unverified). | Stated fact | 5/5 | 5/5 | Fully honored |
| 6 | Define heat alert levels with forecast thresholds (daytime high and night-time low). Establish incident-command structure: who declares alerts, owns operations/comms/partner coordination. Provide daily SITREP, partner briefings, public updates. | Requirement | 5/5 | 5/5 | Fully honored |
| 7 | Create 10 cooling centers using existing assets (libraries, community centers, malls, churches, sports halls). Specify hours, capacity, staffing, security, accessibility (wheelchair access, quiet rooms, water, toilets) and transport support for mobility-limited residents. | Requirement | 5/5 | 4/5 | Partially honored |
| 8 | GDPR-compliant outreach: use opt-in registries, GP/pharmacy partnerships, social services, housing associations, NGOs. Include 'no wrong door' enrollment (phone line, in-person). Design phone-tree + door-knock protocol with multilingual support and escalation rules. | Requirement | 5/5 | 5/5 | Fully honored |
| 9 | Deploy fast, cheap home-level interventions to ~2,000 highest-risk homes: exterior shading kits, reflective blinds, window fans, hydration, thermometer/hygrometer, guidance. Include selection rubric prioritizing top-floor/poor insulation and ages 75+. | Requirement | 4/5 | 4/5 | Partially honored |
| 10 | Integrate with hospitals, emergency services, primary care via minimal legal data loop (aggregate signals only). Define heat-illness escalation guidelines. Include proactive check-ins to prevent emergencies and protect healthcare capacity. | Requirement | 4/5 | 4/5 | Partially honored |
| 11 | Protect outdoor workers: adjust municipal schedules, mandatory breaks, water, shaded rest points at Level 2-3. Provide non-binding guidance package for private employers; include heat clauses in new municipal contracts. | Requirement | 4/5 | 4/5 | Partially honored |
| 12 | Public communications via channels reaching vulnerable people: radio, flyers, pharmacy posters, door hangers, SMS (opt-in), faith/community leaders. Counter misinformation (e.g., alcohol, incorrect fan use). Pre-season campaign and heat-event messaging templates. | Requirement | 4/5 | 5/5 | Fully honored |
| 13 | Month 2 (2026-12-08) readiness gate (2026-12-08): cooling centers contracted & staffed; transport contract signed; phone line operational; outreach training completed; procurement orders placed. Month 4 (2027-02-08) scale gate (2027-02-08) requires 80% center hours, ≥60% outreach contact success, <45 min transport time, AAR complete. | Requirement | 5/5 | 4/5 | Partially honored |
| 14 | Define baselines and measurement plan for primary outcomes (heat-related EMS calls, ED visits, mortality, excess mortality estimate) and operational KPIs (center utilization, transport requests, outreach attempts/success, kit installations, multilingual coverage). Include equity metrics by neighborhood, age, housing type. | Requirement | 4/5 | 4/5 | Partially honored |
| 15 | Deliver by Month 12 (2027-10-08): Heat Response Playbook (SOPs, checklists, scripts, procurement lists, MOUs); cost model for city-wide and EU scaling; data & evaluation report with clear limitations; Year-2 roadmap (expansion/stop decisions). Write for immediate municipal execution: clear owners, timelines, staffing counts, risk register. | Requirement | 5/5 | 5/5 | Fully honored |

## Issues

### Issue 7 - Create 10 cooling centers using existing assets (libraries, community centers, malls, churches, sports halls). Specify hours, capacity, staffing, security, accessibility (wheelchair access, quiet rooms, water, toilets) and transport support for mobility-limited residents.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 5/5
- **Evidence:** Plan names 10 refuge sites (range 8-12) at ~40 places each. Hours 10:00-20:00 at Level 2-3; 3 sites extend to 24:00 at Level 3. Staffing ~18 FTE at peak (14 + 4 reserve). Accessibility: ≥50% of places in fully accessible sites. AED + first-aid certified staff per site. Taxi retainer with ≥10 vehicles, ≥3 wheelchair-capable.
- **Explanation:** The plan addresses all seven elements (network, hours, capacity, staffing, security, accessibility, transport) but with some softening compared to the directive's language. 'About 10' cooling centers becomes an explicit range (8-12); accessibility requirement is softened from 'wheelchair access' across all sites to '≥50% in fully accessible sites', acknowledging trade-offs. Security is not explicitly mentioned in the plan (unsolicited caveat). Transport support is included but less detailed than the directive requests (taxi backup is named but volunteer driver coordination and contracts are less specific on accessibility features).

### Issue 13 - Month 2 (2026-12-08) readiness gate (2026-12-08): cooling centers contracted & staffed; transport contract signed; phone line operational; outreach training completed; procurement orders placed. Month 4 (2027-02-08) scale gate (2027-02-08) requires 80% center hours, ≥60% outreach contact success, <45 min transport time, AAR complete.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 5/5
- **Evidence:** Month 2 (2026-12-08) readiness gate: ≥8 of 10 sites signed, ≥50% places accessible, retainer signed, ≥20 volunteers vetted, heat line live, outreach training 100%, 100% tranche-1 procurement orders placed. Month 4 (2027-02-08) scale gate: ≥80% center hours, ≥60% outreach contact success from ≥300 attempts, <45 min mean pickup over ≥30 requests, after-action report 100% closed.
- **Explanation:** Both gates are defined, but the Month 2 (2026-12-08) gate is expanded beyond what the directive specifies (plan adds accessibility and volunteer recruitment thresholds; directive only lists the four named outcomes). More importantly, the Month 4 (2027-02-08) gate definition is softened: the plan defines gates as measurable in drills 'if real heat events are insufficient', which introduces a contingency not in the user directive. The directive states gates are go/no-go tests ('if gates are met'); the plan adds a partial-release rule (€750k at Month 4 = 2027-02-08 if evidence is insufficient, remainder deferred to Month 5 = 2027-03-08). This is an unsolicited caveat that weakens the hard constraint.

### Issue 9 - Deploy fast, cheap home-level interventions to ~2,000 highest-risk homes: exterior shading kits, reflective blinds, window fans, hydration, thermometer/hygrometer, guidance. Include selection rubric prioritizing top-floor/poor insulation and ages 75+.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Plan deploys kits to ~2,000 homes: exterior shading, reflective blinds, window fans, thermometer/hygrometer, hydration supplies, guidance. Budget €800k. Selection rubric prioritizes top-floor, poor insulation, ages 75+, living alone. Handyperson installation included with safety checks. 10-15% buffer stock pre-positioned.
- **Explanation:** The directive's core requirement is met: ~2,000 highest-risk homes receive a targeted package of named items (shading, blinds, fans, thermometer/hygrometer, hydration, guidance). Selection rubric is explicit and prioritizes the specified groups. However, the plan softens the scope slightly by labeling population estimates 'unverified' and by making installation contingent on handyperson availability (acknowledged risk: supply-chain delays could push 60-80% of kits into June-July, missing peak-risk May). The plan is realistic about constraints but does not reduce the commitment itself.

### Issue 10 - Integrate with hospitals, emergency services, primary care via minimal legal data loop (aggregate signals only). Define heat-illness escalation guidelines. Include proactive check-ins to prevent emergencies and protect healthcare capacity.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Health-system MOU by Month 1 (2026-11-08): daily aggregate heat-related EMS/ED counts only (no personal records). Heat-illness escalation guidelines defined: nurse triage line live by Month 2 (2026-12-08) for outreach-staff escalation. Notify commander at ≥1.5× historical average volume. University evaluation partner under DPA. Proactive check-ins mentioned in scope but not detailed in operations.
- **Explanation:** The directive requires three elements: (1) minimal legal data loop—met via aggregates-only MOU; (2) heat-illness escalation guidelines—partially met (nurse triage line is described but specific guidelines, escalation thresholds and scripts are not shown in the plan artifacts); (3) proactive check-ins to prevent emergencies—mentioned in scope ('reduce emergency and hospital load during heat events') but mechanisms are not detailed. The plan addresses the legal and coordination structure but under-specifies the clinical escalation pathways and proactive outreach protocols that would prevent emergencies.

### Issue 11 - Protect outdoor workers: adjust municipal schedules, mandatory breaks, water, shaded rest points at Level 2-3. Provide non-binding guidance package for private employers; include heat clauses in new municipal contracts.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Outdoor workers: municipal crews get shifted hours, mandatory breaks, water and shade at Level 2-3. Heat-protection clauses in new municipal contracts. Private employers offered non-binding guidance pack by Month 1 (2026-11-08). One compliance monitor spot-checks ≥50% of active contracts; corrective notice within 48 h.
- **Explanation:** The directive asks for a plan for outdoor workers (adjusted schedules, mandatory breaks, water, shaded rest points) and non-binding guidance for private employers, plus heat clauses in municipal contracts. The plan delivers all three, but the municipal worker protection is brief (no named rest points, no detail on schedule adjustments) and compliance is limited to spot-checks of 50% of contracts, not full enforcement. Private employer guidance is confirmed as non-binding and offered only as a guidance pack, which aligns with the directive's 'strongly promoted' language.

### Issue 14 - Define baselines and measurement plan for primary outcomes (heat-related EMS calls, ED visits, mortality, excess mortality estimate) and operational KPIs (center utilization, transport requests, outreach attempts/success, kit installations, multilingual coverage). Include equity metrics by neighborhood, age, housing type.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Primary outcomes: heat-related EMS calls (baseline 80-120), ED visits, excess mortality (15-25 estimate), temperature-adjusted attribution. Operational KPIs: center utilization, transport requests served, outreach attempt/success rates, home-intervention installs, multilingual coverage. Equity metrics: neighborhood deprivation index, age bands, housing type. Baseline data requested Month 0 (2026-10-08); audit Month 1 (2026-11-08); coding agreed Month 2 (2026-12-08).
- **Explanation:** All three metric categories (primary outcomes, operational KPIs, equity metrics) are named, but only operational KPIs are defined with specific targets (e.g., 60% outreach success, <45 min transport). Primary outcomes (EMS, ED, mortality) are identified but no reduction targets are set as gates—the plan explicitly states 'no mortality-reduction target is set as a gate.' Equity metrics are listed as categories (deprivation index, age, housing) but specific coverage targets are not stated (one risk mentions '≥30% in top-3 deprived areas by Month 12 = 2027-10-08' but this is not in the canonical facts). Baseline data collection timeline is realistic but represents a partially_honored approach: the directive asks for 'baselines and measurement plan'; the plan defines the plan but acknowledges baseline data may not be available until Month 4 (2027-02-08).
