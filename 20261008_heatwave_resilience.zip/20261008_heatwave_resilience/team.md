*Roles Needed & Example People*

# Roles

## 1. Heat Response Incident Commander

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Incident Commander must maintain continuous authority and institutional knowledge across a 12-month program with critical decision points at Months 2 and 4 (2026-12-08, 2027-02-08). This role drives daily governance, procurement approvals, and cross-department coordination throughout setup and operational phases. Political accountability and delegation-of-authority requirements demand a stable, authorized municipal officer, not a contractor or temporary arrangement.

**Explanation**:
Serves as the single point of authority for all alert declarations, operational decisions and cross-department coordination. Resides in or is delegated from the mayor's office, with a public-health deputy. Declares alerts, authorizes spending per tier, chairs daily SITREPs, and is accountable to the city for all response actions. Essential for speed, clarity and political legitimacy during real or simulated heat events.

**Consequences**:
Without clear, single-authority incident command, alert declarations will be delayed or contested across departments. Cross-department orders may conflict. Procurement approvals will stall. Political accountability will blur, inviting media scrutiny if a response fails. The city will fail to meet the Month 2 (2026-12-08) readiness gate (incident command authority signed and operational).

**People Count**:
1 primary incident commander (mayor's office or delegated) + 1 deputy (public health) = 2 total. The deputy must be capable of full authority if the primary is unavailable.

**Typical Activities**:
Declares heat alerts based on forecast thresholds within 1 hour of trigger; chairs daily SITREPs at 08:30 during alerts; authorizes spending per alert tier and resolves disputes between departments (e.g., cooling-center hours vs. budget); signs incident-command delegation letters and updates authorities if unavailable; reviews daily aggregate EMS/ED counts and escalates if volume exceeds thresholds; signs off on after-action reports and gate assessments; maintains continuity briefings with successor if political transitions occur.

**Background Story**:
María José García Ribera, 58, from Valencia, is a seasoned municipal administrator with 22 years in city government, including 8 years managing civil-protection responses to flooding and industrial incidents. She holds a degree in public administration and an executive qualification in emergency management. For the past 3 years, she has advised the mayor's office on resilience and sustainability. Her familiarity with heat-response protocols is limited but her authority to coordinate cross-department action is established; the mayor has explicitly delegated heat-alert declaration to her with written authority. She is known for decisive, evidence-based decision-making under time pressure.

**Equipment Needs**:
Computer with dual monitors and secure municipal network access; secure phone line and encrypted mobile device; incident-command software or shared access to alert tracking spreadsheet; audio-video conferencing system for daily SITREPs (08:30 briefings across departments); municipal authorization letter and delegation documentation (signed, filed); weather alert feed direct from national meteorological service (AEMET); real-time EMS/ED aggregate data dashboard (view-only secure access); alert-declaration templates and checklist documents.

**Facility Needs**:
Private office at mayor's office or civil protection HQ with 24-hour access during Months 6–11 (2027-04-08 to 2027-09-08); desk, phone and network connectivity; backup command-post facility (civil protection or health department) with same connectivity in case primary office is unavailable; secure meeting room for daily SITREPs (10–12 person capacity, AV equipment); access to municipal procurement and budget-authority systems.

## 2. Cooling Center Network Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Cooling Center Network Manager must contract sites, conduct accessibility audits, oversee staffing, and ensure 80% planned-hours delivery at the Month 4 gate (2027-02-08). This is continuous core accountability from Month 0 (2026-10-08) through Month 12 (2027-10-08), with front-loaded site-contracting work (Months 0–2 = 2026-10-08 to 2026-12-08) and sustained operational oversight during the season (Months 6–11 = 2027-04-08 to 2027-09-08). Staffing and safety protocols at 10 sites require institutional knowledge and real-time decision-making that only a full-time dedicated manager can deliver.

**Explanation**:
Owns the end-to-end delivery of the 10-site cooling refuge network: facility contracting, accessibility audits, staffing oversight, scheduling of opening hours by alert level, safety protocols (first-aid, AED, escalation), and utilization reporting. Ensures 80% of planned center-hours are delivered and ≥50% of places are fully accessible. Reports daily occupancy and any incidents to incident command during alerts.

**Consequences**:
Without a single center manager, site contracting and accessibility will slip past the Month 2 (2026-12-08) gate. Staffing will be uncoordinated; openings will miss scheduled hours. The 80% planned-hours gate (Month 4 = 2027-02-08) will fail. Residents will arrive at closed or over-capacity sites, harming credibility and equity.

**People Count**:
1 center network manager (full-time, Months 0-12 = 2026-10-08 to 2027-10-08). Plus 18 FTE part-time center staff (14 core + 4 reserve) across 10 sites, hired in cohorts during Months 3-5 (2027-01-08 to 2027-03-08).

**Typical Activities**:
Identifies and audits 10 cooling-center sites (libraries, community centers, parish halls) for accessibility (wheelchair ramps, water points, accessible toilets, quiet rooms); contracts facility-use MOUs specifying hours and staffing responsibility; hires and onboards 18 part-time center staff in cohorts; publishes center accessibility information (routes, toilets, parking) in plain language; ensures ≥1 first-aid-certified staffer and AED per site; schedules opening hours by alert level (10:00–20:00 at Level 2, 24-hour at Level 3); reports daily occupancy, staffing and incidents to command.

**Background Story**:
Ricardo Martínez López, 45, from Castellón, holds a degree in architecture and has managed municipal facilities for 15 years, including libraries and community centers. He has overseen accessibility audits for disability compliance and has experience contracting maintenance and security services. His knowledge of heat-response infrastructure is new; he attended a 2-day climate-resilience training in Barcelona in 2024. He is detail-oriented, process-driven and skilled at managing relationships with external facility managers and contractors. He speaks Spanish and Valencian fluently.

**Equipment Needs**:
Site-inspection checklist forms (printable, wheel-measure for distances, camera); accessibility audit tool (wheelchair-simulation, bathroom-door-width gauge, step height measure); first-aid certification tracking spreadsheet; AED procurement specifications and maintenance contracts; staffing rota software or shared spreadsheet; cooling-center occupancy/incident-reporting forms; communication devices (mobile phone, landline at office); cooling-center signage templates (printed, large-format for accessibility).

**Facility Needs**:
Office space (0.5-desk footprint) at municipal facilities department or city hall; internet access and phone line; secure storage for site-audit documentation and facility contracts; access to all 10 cooling-center sites for inspections (transport/vehicle or reimbursement); meeting space at each site for handover briefings with facility managers (10 visits, ~2 hours each); access to municipal procurement and facilities-management systems.

## 3. Transport Dispatch and Mobility Coordinator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Transport Dispatch and Mobility Coordinator must recruit, vet and manage 30–50 volunteer drivers (4–8 week vetting process), negotiate and manage a taxi standby-retainer contract, and operate dispatch during peak alert-day demand. This role spans continuous procurement and safeguarding accountability (Months 0–4 = 2026-10-08 to 2027-02-08) and sustained operational leadership (Months 5–12 = 2027-03-08 to 2027-10-08). The 45-minute transport-time gate (Month 4 = 2027-02-08) depends on this coordinator's ability to execute complex multi-vendor coordination and volunteer-management infrastructure that cannot be built or maintained part-time.

**Explanation**:
Recruits, vets and schedules volunteer drivers (target 40); manages the taxi standby-retainer contract; operates the transport dispatch center during alert days; coordinates with cooling centers on occupancy; tracks request-to-pickup time and escalates delays. Ensures mean pickup time <45 minutes and 100% of transport requests are attempted. Responsible for safeguarding vetting (background checks, insurance, training) and volunteer driver retention.

**Consequences**:
Without a dedicated coordinator, volunteer recruitment will stall and vetting will not be completed by Month 2 (2026-12-08). Taxi retainers will be unsigned or unmanaged. Dispatch will lack capacity during peak alert days, causing wait times to exceed 45 minutes and the transport-time gate to fail. Safeguarding breaches are more likely if vetting is weak or decentralized.

**People Count**:
1 mobility coordinator (full-time, Months 0-12 = 2026-10-08 to 2027-10-08) + 2 dispatch operators (alert-day hours, May-September, ~40% FTE seasonal) + 1 backup coordinator (standby, ~20% FTE). Total 1.6 FTE equivalent. Plus volunteer driver recruitment support from Month 0 (2026-10-08) and taxi/paratransit vendor management.

**Typical Activities**:
Recruits and vets 30–50 volunteer drivers via NGO networks and community outreach; conducts background checks, insurance verification and safeguarding training (4–8 weeks per cohort); manages a taxi standby-retainer contract with 2–3 suppliers; coordinates with dispatch operators to log transport requests, assign drivers and track time-to-pickup; escalates delays >45 minutes and reallocates drivers dynamically; conducts transport stress tests and drills; maintains volunteer driver rota and substitute coverage; reports mean pickup time and request-fulfillment rates daily during alerts.

**Background Story**:
Ahmed Hassan El-Sayed, 52, originally from Egypt, settled in Valencia 18 years ago and holds Spanish citizenship. He has 20 years of experience in transportation and logistics, including fleet management for a taxi cooperative. He is fluent in Spanish, Valencian, Arabic and English. He has no formal training in heat response but has worked with vulnerable populations through volunteer ambulance-driver roles. He is known for reliability, problem-solving and an ability to build trust with drivers and community partners. He understands insurance requirements and background-check processes.

**Equipment Needs**:
Transport dispatch software (spreadsheet or low-code platform) with real-time visibility to volunteer-driver location, transport requests, and arrival times; secure phone and mobile radio system for dispatchers; volunteer-driver insurance and vetting database (secure spreadsheet or minimal HR system); driver scheduling/rota software; stress-test scenario protocols and timing tools; transport-contract templates and vendor-management files; safeguarding incident-reporting forms.

**Facility Needs**:
Dedicated dispatch office or workstation (3 FTE: 2 operators + 1 backup/coordinator) with dual monitors per operator; 24-hour phone line and mobile coverage; secure climate-controlled facility for volunteer-driver records (vetting, insurance); meeting space for volunteer-driver training (20–30 person capacity, 4-hour sessions, fortnightly cohorts Months 0–2 = 2026-10-08 to 2026-12-08); fleet-staging area or parking for volunteer vehicles pre-positioned on alert days; access to municipal vehicle insurance and background-check processes.

## 4. Outreach and Street Contact Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Outreach and Street Contact Lead must design outreach protocols, partner with 4–6 intermediary organizations, conduct escalation training for 25–35 staff, and manage the 60% contact-success gate (Month 4 = 2027-02-08). This role requires continuous engagement with partners, design iteration based on early feedback, and real-time monitoring during alert days. The scope spans governance (MOUs, training), operations (contact tracking, escalation), and equity (reach monitoring), all of which demand a full-time institution-facing role, not episodic consulting.

**Explanation**:
Designs and deploys door-knock and street-contact protocols for high-risk residents. Works with housing associations, social services, NGOs and pharmacies to conduct phone and in-person outreach; manages a 'no wrong door' enrollment pathway via the heat line and in-person at cooling centers. Owns heat-illness escalation training for outreach staff, safety protocols for street-contact teams, and monitoring of the 60% contact-success gate. Reports daily outreach metrics to command during alerts.

**Consequences**:
Without dedicated outreach leadership, intermediary partners (housing associations, NGOs, social services) will operate inconsistently or not at all. Contact success will fall below 60%, failing the Month 4 (2027-02-08) gate. Unhoused residents will be missed entirely if street-contact protocols are not designed. Escalation training will not occur, increasing risk of delayed EMS calls during heat illness.

**People Count**:
1 outreach lead (full-time, Months 0-12 = 2026-10-08 to 2027-10-08) + 6 FTE outreach staff (door-knock teams, phone check-in staff, street-contact coordinators) hired in Months 3-5 (2027-01-08 to 2027-03-08). Plus partner-coordination roles split with the partner-liaison officer.

**Typical Activities**:
Co-designs heat-illness escalation checklists with clinical staff for outreach teams; partners with housing associations, social services and NGOs to establish call protocols and contact targets (300+ attempts/alert day); trains 25–35 outreach and street-contact staff on heat-illness recognition, de-escalation and escalation rules (test ≥80%); monitors daily contact attempts and success rates via shared tracking spreadsheet; conducts mid-season partner reviews to resolve capacity gaps; escalates if contact success drops below 60%; tracks reach by neighborhood deprivation, age and language; manages the no-wrong-door enrollment pathway via the heat line and in-person centers.

**Background Story**:
Laura Fernández Serrano, 41, from Alicante, holds a master's degree in public health and has 14 years in municipal social services, including 6 years managing outreach to homeless and isolated elderly residents. She speaks Spanish, Valencian and English and has led successful enrollment campaigns for municipal health programs (reach 70–80% of target populations). Her experience with GDPR compliance is intermediate; she has managed confidentiality protocols for social-services client lists. She is experienced in motivating partner organizations and resolving conflicts over data-sharing and accountability.

**Equipment Needs**:
Heat-illness escalation checklist (printed, laminated for outreach staff); phone triage protocols and decision-tree documents; partner-contact database (contact names, phone, email for housing associations, social services, NGOs, pharmacies); call-script templates (printed, translated); shared outreach-tracking spreadsheet (secure, visible to partners and city); training materials (slide decks, role-play scenarios); escalation phone numbers (112, nurse line, poison control); outreach incident-reporting forms; no-wrong-door enrollment intake forms (paper and digital).

**Facility Needs**:
Office (1 FTE) at social services or outreach-coordination hub with phone, email and secure internet; meeting space for partner coordination (6–8 person capacity, Months 1–2 = 2026-11-08 to 2026-12-08 weekly); training facility (30–40 person capacity) for outreach and street-contact staff training (80 hours total, Months 1–2 = 2026-11-08 to 2026-12-08); access to municipal GP, pharmacy and NGO partner offices for joint briefings; secure storage for outreach escalation protocols and incident logs.

## 5. Heat Helpline and Phone Operations Manager

**Contract Type**: `part_time_employee`

**Contract Type Justification**: Heat Helpline and Phone Operations Manager can operate effectively as a part-time employee (0.5 FTE Months 1–12 = 2026-11-08 to 2027-10-08) because the phone line itself is mostly inactive (10–15 alert days per summer of 120 days peak season ≈ 12% utilization). The manager role is to build and maintain the system before Months 5–8 (2027-03-08 to 2027-06-08), then supervise reactive operations during alerts. Administrative setup dominates Months 1–4 (2026-11-08 to 2027-02-08); operational intensity is episodic, not continuous.

**Explanation**:
Establishes and operates the heat-alert phone line (08:00-22:00 daily, 24-hour at Level 3); integrates phone intake with transport dispatch and cooling-center occupancy; trains phone operators on escalation protocols and multilingual service; manages call logging and escalation tracking. Ensures phone line is live and responsive by Month 2 (2026-12-08) readiness gate.

**Consequences**:
Without a dedicated phone manager, the heat line will open late (missing the Month 2 = 2026-12-08 gate) or will operate at poor quality (long wait times, misrouted requests). Callers will not be connected to transport dispatch or cooling-center availability in real-time. The shared tracking system will not be built or maintained, causing dispatch/center coordination failures during peak alert demand.

**People Count**:
1 phone operations manager (part-time, ~0.5 FTE, Months 1-12 = 2026-11-08 to 2027-10-08) + 2-3 part-time phone operators (30 hours/week during alert season, ~0.75 FTE each, May-September) + 1 backup operator (on-call). Total 2.75-3.25 FTE seasonal equivalent.

**Typical Activities**:
Establishes and operates the heat-alert helpline (08:00–22:00 daily, 24 hours on Level 3 days); hires and trains 2–3 part-time phone operators in heat-illness escalation, cooling-center locations and multilingual service; integrates phone intake with transport dispatch and center occupancy via a shared real-time spreadsheet; logs caller details (transport request, center preference, language) and confirms pickup time and center availability within 15 minutes; updates center occupancy every 30 minutes during alerts; conducts monthly call-quality audits; tracks wait times and call volume by alert level.

**Background Story**:
Susana Ruiz Gómez, 38, from Castellón, holds a degree in business administration and has 12 years' experience running a municipal health-information line. She has managed call centers, trained phone operators in customer service and de-escalation, and set up shared tracking systems using spreadsheets and simple cloud tools. Her heat-response knowledge is minimal; she attended a half-day orientation on heat illness. She is calm under pressure, detail-oriented about protocol compliance and skilled at managing operator fatigue and quality during long shifts.

**Equipment Needs**:
Phone-line equipment (dedicated number, answering system, call-recording for quality assurance); heat-helpline intake form (digital and printable); call-tracking spreadsheet (shared with dispatch and cooling centers in real-time); phone operator scripts and checklists (cooling-center locations, transport request workflow, escalation rules); cooling-center occupancy update forms (for centers to phone in every 30 min during alerts); multi-language phone-tree menus and automated prompts (Spanish, Valencian, Arabic, Portuguese, etc.); interpreter scheduling system; quality-monitoring and call-time-tracking logs.

**Facility Needs**:
Dedicated phone-line operations space (2–3 operator workstations with headsets and dual monitors); climate-controlled office with 24-hour access during Months 5–11 (2027-03-08 to 2027-09-08); high-quality phone and internet connectivity (redundant line for backup); secure storage for call recordings and daily logs (confidential per data-protection rules); meeting space for operator training (8–10 person capacity, 4-hour sessions, Months 1–2 = 2026-11-08 to 2026-12-08 and monthly refreshers); access to municipal telephone and IT systems; contracted interpretation-service hub or on-call interpreter station.

## 6. Home Interventions and Handyperson Coordinator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Home Interventions and Handyperson Coordinator must manage a critical 4–5 month procurement and installation timeline (Months 0–7 = 2026-10-08 to 2027-05-08) with zero tolerance for supply-chain delays past February–April. This role owns €800k in kit budget, vetting and training of 10 handypersons, and meeting the implicit gate that 40–50% of kits are installed by Month 4 (2027-02-08). The compressed procurement schedule, backup-supplier vetting, quality audits and installation supervision demand continuous full-time focus. After Month 7 (2027-05-08), the workload drops to close-out; a full-time appointment supports peak-season intensity and reduces restarting cost if procurement slips.

**Explanation**:
Procures cooling kits (shading, fans, blinds, thermometers, hydration supplies), manages the first-call supply chain and backup vendors, oversees handyperson recruitment and fan-safety training, schedules installations in priority homes (top-floor, social housing, by rubric score), conducts 10-20% quality audits of installs, and tracks installations against targets. Delivers first 40-50% of kits by Month 4 (2027-02-08) and 100% by Month 6 (2027-04-08).

**Consequences**:
Without a kit coordinator, procurement will slip past February and home interventions will miss the May-June heat season (20-25% loss in estimated mortality reduction). Handyperson vetting and training will not happen, risking unsafe fan installations (fire hazard, misuse). Supplier delays will not be managed; backup vendors will not be pre-qualified. The €800k home-kit budget will be wasted if kits are not installed by June.

**People Count**:
1 home-kit coordinator (full-time, Months 0-12 = 2026-10-08 to 2027-10-08) + 10 handypersons/installers (contracted or part-time, Months 4-7 = 2027-02-08 to 2027-05-17) + 1 quality-assurance auditor (contract, 20% FTE). Total 12 FTE equivalent across the 12 months, concentrated Feb-May.

**Typical Activities**:
Issues procurement specifications for cooling kits (shading material, reflective blinds, fans, thermometers, hygrometers) to suppliers; obtains quotes and lead-time confirmations; places first call-off order for 30–40% of kits by November 15; pre-qualifies 2–3 backup suppliers and signs backup agreements; negotiates expedited delivery premiums (10–15%); arranges interim storage at municipal facilities; hires 10 handypersons and conducts 2-hour fan-safety and installation-safety training; schedules installations in priority homes (top-floor, social housing) by rubric score; conducts spot-check quality audits of 10–20% of installations; tracks kit delivery, installations completed and budget spend weekly.

**Background Story**:
Carlos Morera Tomás, 50, from Valencia, is a retired construction supervisor with 28 years' experience managing installations and safety on residential sites. He holds certifications in electrical safety and workplace health. His heat-response knowledge is new; he recently completed a 2-day online course on heat-illness first aid. He is pragmatic, cost-conscious and skilled at quality control and vendor management. He speaks Spanish and Valencian and has established relationships with local trade contractors and suppliers.

**Equipment Needs**:
Kit procurement specifications and RFQ documents; supplier quotes and lead-time confirmations (spreadsheet); first call-off order contracts and backup-supplier agreements; expedited-delivery authorization and payment-processing forms; interim storage-facility management (inventory tracking, climate control, security); handyperson hiring and vetting records (background check, insurance, training certificates); fan-safety and installation-safety training materials (slide decks, videos, printed handouts); quality-assurance audit checklists; kit-delivery and installation-tracking spreadsheet; budget and spend-tracking by kit category.

**Facility Needs**:
Office (1 FTE) at municipal procurement or public works with phone and email; secure storage facility (500–800 m² minimum, climate-controlled, lockable) for kit inventory during Months 2–6 (2026-12-08 to 2027-04-08); access to municipal procurement, contracts and payment systems; meeting space for handyperson vetting and training (15–20 person capacity, 2-hour sessions, Months 3–4 = 2027-01-08 to 2027-02-08); handyperson staging area or workshop for tool storage and kit assembly/checking before installation; access to supplier warehouses and delivery logistics (coordinate with municipal transport).

## 7. GDPR Compliance and Legal Officer

**Contract Type**: `independent_contractor`

**Contract Type Justification**: GDPR Compliance and Legal Officer can be delivered as an independent contractor (or hybrid: 0.5 FTE municipal staff + external specialist counsel). The role is expert-driven, bounded-scope legal work: template MOUs/DPAs (Months 0–2 = 2026-10-08 to 2026-12-08), partner briefings (Month 2 = 2026-12-08), and mid-season audit (Month 9 = 2027-07-08). Front-loaded deliverables (legal opinions by Month 1 = 2026-11-08) suit fixed-scope contracting. A dedicated municipal legal officer would underutilize during operations phases (Months 6–8 = 2027-04-08 to 2027-06-08). Specialist GDPR counsel (€15–30k contract) can be embedded; municipal support for partner engagement is 0.5 FTE (separate line item).

**Explanation**:
Engages specialist GDPR counsel, oversees data-processing agreements (MOUs/DPAs) with all partner organizations (housing associations, social services, NGOs, pharmacies), ensures legal clearance for the intermediary-held-list model by Month 1 (2026-11-08), briefs partner staff on confidentiality and data-retention rules, and conducts mid-season GDPR audits. Protects the program from regulatory challenge and partner withdrawal.

**Consequences**:
Without dedicated legal oversight, data-processing agreements will not be signed by Month 1.5 (2026-11-23), delaying partner engagement. Partner withdrawal due to perceived GDPR risk could drop outreach reach by 10-20%. A regulatory inquiry or resident data-protection complaint could halt operations mid-season and force retrospective remediation (€15-30k estimate). The program loses credibility and transferability to peer EU cities.

**People Count**:
1 GDPR/legal officer (0.5 FTE, Months 0-12 = 2026-10-08 to 2027-10-08), supported by an external specialist GDPR law firm (contract, ≤€30k). Officer must have EU data-protection knowledge or access to legal counsel.

**Typical Activities**:
Engages specialist GDPR law firm for template data-processing agreements (MOUs/DPAs) with housing associations, social services, NGOs and pharmacies; reviews lawful basis for contact (public-task/consent hybrid), retention periods (one season, then deletion) and breach-notification rules; obtains written legal opinion confirming intermediary-held model compliance; briefs 50–80 partner staff on confidentiality and data-retention obligations before Month 2 (2026-12-08); conducts mid-season GDPR audit of partner consent records and training logs (Month 9 = 2027-07-08); escalates any suspected data breach to the data protection authority; drafts annual data-protection impact assessment (DPIA) summary if required.

**Background Story**:
Isabel Montoya Riera, 43, from Barcelona, is a municipal legal adviser specializing in data protection and public procurement. She holds a master's degree in data protection law (GDPR focus) and has 10 years' experience drafting privacy notices, data-processing agreements and compliance audits. Her familiarity with heat-response law is zero; heat programs are outside her previous brief. She is meticulous, risk-aware and skilled at managing relationships with data protection authorities and external counsel. She speaks Spanish, Catalan and English.

**Equipment Needs**:
GDPR legal templates (MOU/DPA drafts); data-processing agreement tracking spreadsheet; partner contact and signature documentation (secure files); partner-staff training attendance logs and confidentiality certification; consent-form templates (translated into 4–6 languages); data-retention and deletion schedules; breach-notification procedures and incident-reporting forms; audit checklists for partner compliance (consent records, staff training, data-handling); legal opinion documentation (signed, dated); communication letters to data protection authority (AEPD) if required.

**Facility Needs**:
Office (0.5 FTE) at municipal legal department or health department with secure file storage and phone; external specialist GDPR law firm on retainer (contract €15k–30k, Months 0–2 = 2026-10-08 to 2026-12-08 intensive, then ad-hoc); meeting space for partner DPA signature sessions (6–8 partner organizations, 1–2 hours each, Month 1.5 = 2026-11-23); secure digital-signature or contract-management system (or secure email and filing); access to municipal data-protection register and AEPD contact information.

## 8. Communications, Language Access and Trusted Messenger Coordinator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Communications, Language Access and Trusted Messenger Coordinator must design multilingual messaging, recruit and train 8–12 community ambassadors, manage translation of 4–6 languages, and execute a pre-season campaign (Month 6 = 2027-04-08 launch) and misinformation correction (≤4 hours response time during alerts). This is continuous core accountability Months 0–12 (2026-10-08 to 2027-10-08), with sustained operational intensity during the communication-heavy period (Months 5–8 = 2027-03-08 to 2027-06-08). Ambassador recruitment, translation procurement, and campaign execution require full-time coordination; the role cannot be fragmented across part-time or episodic effort.

**Explanation**:
Designs and executes the public communications strategy: pre-season campaign, heat-event messaging templates, myth-busting content, trusted-messenger briefings (pharmacists, GPs, caretakers, faith leaders), translation and interpretation services, and rapid misinformation correction (≤4 hours). Recruits and trains 8-12 paid community-language ambassadors. Ensures messages are accessible to offline, elderly and migrant residents. Reports media-monitoring and reach metrics to incident command.

**Consequences**:
Without a dedicated coordinator, messages will not be translated into 4-6 local languages, excluding 5-15% of the population (estimated 500-1,500 residents in Castellón). Trusted messengers will not be briefed consistently, reducing uptake among offline and elderly residents. Misinformation (alcohol, fan misuse) will spread unchecked, causing unsafe behaviors and preventable heat illness. Public reach will drop by 10-20%, reducing enrollment and utilization by 500-2,000 residents.

**People Count**:
1 communications/language coordinator (full-time, Months 0-12 = 2026-10-08 to 2027-10-08) + 1 part-time communications officer or social-media monitor (10-15 hours/week during season, ~0.25 FTE) + 8-12 paid community-language ambassadors (10-15 hours/week during season, ~0.9 FTE equivalent). Total 2.15 FTE equivalent.

**Typical Activities**:
Designs pre-season heat-safety campaign messaging (print, radio, SMS); focus-tests messages with older residents and migrants (Month 1 = 2026-11-08) to ensure clarity and cultural appropriateness; briefs trusted messengers (pharmacists, GPs, caretakers, faith leaders) with consistent scripts and leave-behind materials by Month 6 (2027-04-08); recruits and trains 8–12 paid community-language ambassadors to deliver messages in non-official languages during alert season; publishes alerts and public updates by 11:00 on Level 2–3 days; monitors social media and local forums for misinformation and responds with corrected facts within 4 hours; tracks message reach by demographic group and language; publishes translated door hangers, flyers and pictogram-first signage.

**Background Story**:
Javier García Alonso, 47, from Castellón, holds a degree in journalism and has 18 years in municipal communications, including 8 years as communications director for the health department. He is fluent in Spanish and Valencian and has basic conversational skills in English. His heat-response communication experience is limited; he attended a 1-day workshop on climate-health messaging. He is creative, responsive to media inquiries and skilled at working with community leaders and NGO partners. He understands misinformation risk and social-media monitoring.

**Equipment Needs**:
Pre-season campaign templates (radio scripts, poster graphics, flyer text, door-hanger designs, SMS templates); focus-group testing materials and feedback forms; trusted-messenger briefing packs (printed, translated, with role-play scenarios); community-language ambassador job descriptions, vetting forms and training materials; social-media monitoring dashboard (if available, or manual monitoring log); misinformation-correction fact-sheets (printed and digital); translation files for all key materials (4–6 languages); pictogram-based signage and instructional graphics (tested with non-literate users); media-contact list and press-release templates; campaign reach and demographic-tracking spreadsheet.

**Facility Needs**:
Office (1 FTE) at municipal communications or health department with phone, email and design software (or contracted designer access); meeting space for focus-group testing (12–15 person capacity, Months 0–1 = 2026-10-08 to 2026-11-08); trusted-messenger briefing venues (pharmacies, GP practices, faith centers, caretaker offices) for in-person training (8–12 sessions, 2 hours each, Month 6 = 2027-04-08); translation contractor workspace or external language-service provider; social-media monitoring tools or log-management system; radio and print-media production contacts and submission processes; immigrant community center or NGO space for ambassador recruitment and training (20–30 person capacity, Months 2–4 = 2026-12-08 to 2027-02-08).

## 9. Project Coordination, PMO and Staffing Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Project Coordination, PMO and Staffing Lead must deliver compressed procurement by Month 2 (2026-12-08), hire and onboard 43 FTE seasonal staff in Months 3–5 (2027-01-08 to 2027-03-08), track budget and KPIs daily during operations, and manage contingency escalation. This is the critical-path role for both setup (Months 0–4 = 2026-10-08 to 2027-02-08) and operational oversight (Months 5–12 = 2027-03-08 to 2027-10-08). The role requires continuous presence, no-handoff ownership of timelines, and real-time decision-support for the incident commander. Procurement compression, hiring ramp, budget burn rate, and gate measurement all depend on a single dedicated PMO lead; splitting this role or using a contractor would fragment accountability and miss early-warning signals.

**Explanation**:
Serves as the operational backbone: project management (timeline, milestones, budget tracking), HR/recruitment coordination (hiring, onboarding, shift rota, fatigue management), procurement administration (order placement, vendor management, delivery tracking), data and KPI reporting (daily/weekly metrics), and contingency management (risk monitoring, decision-trigger escalation). Owns Months 0-4 (2026-10-08 to 2027-02-08) compressed timeline; transitions to evaluation support by Month 8 (2027-06-08).

**Consequences**:
Without a PMO lead, procurement will not meet Month 2 (2026-12-08) deadline, slipping delivery by 2-4 weeks. Hiring timelines will miss, leaving centers and dispatch under-staffed in May-June. Budget tracking will be poor, risking €200-400k overspend or mid-season funding crisis. Risk escalation will be slow, causing the Month 4 (2027-02-08) gate decision to be made without clear readiness data. The playbook will not be drafted on time by Month 12 (2027-10-08).

**People Count**:
1 project manager / PMO lead (full-time, Months 0-12 = 2026-10-08 to 2027-10-08) + 0.5 FTE HR/recruitment coordinator (Months 0-6 = 2026-10-08 to 2027-04-08, peak intensity Months 0-4 = 2026-10-08 to 2027-02-08) = 1.5 FTE equivalent.

**Typical Activities**:
Creates and maintains project timeline and Gantt chart tracking procurement, hiring and key milestones against Month 2 (2026-12-08) and Month 4 (2027-02-08) gates; monitors budget spend by category weekly and reforecasts cash flow; coordinates recruitment of 43 FTE seasonal staff in cohorts (40% Month 3, 40 = 2027-01-08, 2030-02-08% Month 4, 20 = 2027-02-08, 2028-06-08% Month 5 = 2027-03-08); tracks procurement orders (placement date, supplier, delivery date, receipt confirmation); escalates risks (supply delays, hiring shortfalls, budget overruns) to incident command when decision trigger thresholds are crossed (e.g., <20 volunteers by Month 1.5 = 2026-11-23); produces gate readiness reports at Months 2 and 4 (2026-12-08, 2027-02-08) with corrective-action status; manages contingency budget reserve (€160k tranche 1, €120k tranche 2); transitions to playbook-support role from Month 8 (2027-06-08).

**Background Story**:
Silvia Serrano Domínguez, 35, from Castellón, holds a degree in business administration and has 8 years' experience in municipal project management, including coordination of European-funded urban regeneration projects. She has managed procurement timelines, hiring workflows and budget tracking. Her heat-response knowledge is minimal; she volunteered on a 1-week climate adaptation project in 2023. She is organized, deadline-driven and skilled at cross-team coordination and risk escalation. She speaks Spanish, Valencian and English.

**Equipment Needs**:
Project timeline/Gantt chart software (Excel, Asana, Monday.com, or similar); budget-tracking spreadsheet (by category and vendor); procurement order log (placement date, supplier, delivery date, receipt status); hiring and onboarding checklist (job descriptions, contracts, offer letters, orientation materials); risk register and decision-trigger log; gate-readiness report templates (Month 2 and 4 = 2026-12-08, 2027-02-08); KPI dashboard (center hours, transport time, outreach success, budget spend); contingency-fund authorization forms; staff absence and rota-tracking system; vendor-performance and payment-processing files.

**Facility Needs**:
Office (1.5 FTE: 1 FTE PMO + 0.5 FTE HR coordinator, Months 0–6 = 2026-10-08 to 2027-04-08 intensive; then 1 FTE for M&E support Months 7–12 = 2027-05-08 to 2027-10-08) at municipal administration or health department; dual-monitor workstations with phone and email; access to municipal project-management, HR, procurement and budget systems; secure shared-drive or cloud workspace for all stakeholder documents (read access for incident commander, coordination team; write access for PMO); meeting space for weekly coordination-team touchbases (8–10 person capacity, Monday mornings, 1 hour); access to municipal HR records and payroll for seasonal-staff management; printing and document-scanning facilities for procurement and hiring files.

---

# Omissions

## 1. No dedicated mental health or occupational health support for staff and volunteers exposed to distressing scenes or heat-illness incidents

Outreach, street-contact and cooling-center staff will regularly encounter residents in acute heat distress, potential heat stroke and vulnerable populations during multi-day heat waves. The risk register identifies psychological harm and staff turnover as operational risks, but the team structure lacks an occupational health coordinator or mental health liaison. This is critical for staff retention, reducing turnover costs (€10–20k per replacement) and maintaining service quality during peak-demand periods.

**Recommendation**:
Designate a 0.25 FTE occupational health liaison (municipal occupational health service or contracted occupational health nurse) responsible for: (1) debriefing staff after any heat-illness incident or distressing scene; (2) coordinating access to counselling services within 24 hours at city expense; (3) training team leaders on fatigue-management and burnout-recognition; (4) monitoring staff absences and sick leave for patterns indicating psychological harm; (5) conducting peer-support group sessions monthly during alert season. Include occupational health review at Months 2, 6 and 10 (2026-12-08, 2027-04-08, 2027-08-08) to identify emerging mental-health risks early.

## 2. No dedicated data quality assurance or evaluation lead for rigorous gate measurement and attribution analysis

The Month 4 (2027-02-08) gates depend on accurate measurement of center-hour delivery, outreach contact success, and transport time. The plan includes an evaluation design framework but assigns no FTE to data management, validation or real-time quality assurance during operations. Without a dedicated data officer, metrics will be incomplete, noisy or inconsistent across partners, risking indefensible gate decisions and weak playbook credibility for other EU cities.

**Recommendation**:
Assign a dedicated 1 FTE Data and Evaluation Coordinator (statistician or data analyst, Months 2–12 = 2026-12-08 to 2027-10-08) to: (1) validate baseline EMS/ED data by Month 1.5 (2026-11-23) and establish usable baseline by Month 3 (2027-01-08); (2) design and deploy real-time data collection forms for centers, transport, outreach and health partners; (3) conduct weekly data quality audits during operations (completeness, consistency, outlier flagging); (4) compute gate metrics (center hours, transport time, outreach success) by Month 3.9 (2027-02-04) with confidence intervals; (5) manage the evaluation database and prepare the Month 12 (2027-10-08) evaluation report. Link this role directly to incident command for daily KPI reporting during alerts.

## 3. No dedicated partner liaison and relationship manager for the 4–6 intermediary organizations and health system

The outreach model depends critically on housing associations, social services, NGOs, pharmacies and health providers maintaining engagement and consistent call-center capacity throughout the season. The plan mentions 'partner liaison officer' in stakeholder analysis but assigns no dedicated FTE; coordination is fragmented across outreach lead, GDPR officer and PMO. If a key partner faces capacity constraints or withdraws mid-season (15–20% risk), outreach reach could drop by 10–20%, failing the 60% contact-success gate.

**Recommendation**:
Designate a dedicated 1 FTE Partner Liaison Officer (Months 0–12 = 2026-10-08 to 2027-10-08), reporting to the incident commander, to: (1) negotiate and sign MOUs with all 4–6 partner organizations by Month 1.5 (2026-11-23); (2) conduct joint quarterly planning meetings at Months 1, 4, 7, 10 (2026-11-08, 2027-02-08, 2027-05-08, 2027-08-08) to review capacity and resolve conflicts; (3) maintain monthly contact with each partner to monitor call volume, staff capacity and early-warning signals of withdrawal; (4) provide real-time feedback on outreach performance (success rates, wait times, escalations) to partners; (5) identify and brief backup partners by Month 2 (2026-12-08) in case a primary partner drops. This role is essential for the 60% contact gate and for equity reach tracking.

## 4. No capacity for policy learning and Year-2 planning within the core team structure

The plan requires delivery of a Year-2 roadmap by Month 12 (2027-10-08) recommending what to expand, what to stop and what to scale city-wide. This demands synthesis of lessons from operations, equity tracking, staff feedback and cost accounting. The playbook-and-evaluation officer role (0.5 FTE Months 9–12 = 2027-07-08 to 2027-10-08) is insufficient to simultaneously run end-of-season operations, draft the playbook, and conduct forward-looking policy analysis. Without dedicated capacity for reflection and planning, Year-2 roadmap will be rushed and will miss stakeholder input.

**Recommendation**:
Add a 0.5 FTE Policy and Learning Officer (Months 8–12 = 2027-06-08 to 2027-10-08) working jointly with the PMO and evaluation lead to: (1) synthesize staff feedback, partner input and utilization data (Months 8–9 = 2027-06-08 to 2027-07-08); (2) conduct focus groups with high-risk residents about program experience (n=30–50, 2 groups, Month 9 = 2027-07-08); (3) cost out scenarios for Year-2 expansion (city-wide footprint, continued pilot, scale-back); (4) draft Year-2 roadmap with explicit go/no-go decisions for each service element (Months 10–11 = 2027-08-08 to 2027-09-08); (5) recommend budget and governance model for Year 2 (funder TBD). This role ensures transition from pilot to sustained program is informed, not reactive.

## 5. No dedicated quality assurance inspector for home-kit installation safety and building-code compliance

The plan includes 10 handypersons installing 2,000 cooling kits (exterior shading, fans) in homes during Months 4–7 (2027-02-08 to 2027-05-17). Safety checks (fan directional airflow, fire-hazard risk, building-code compliance) are mentioned in risk mitigation but no FTE is assigned to conduct them. A 10–20% audit rate (200–400 installs) requires ≥0.5 FTE site inspection capacity. Without dedicated inspection, unsafe installations or building-code violations could trigger enforcement action, litigation or media reputational damage.

**Recommendation**:
Assign a 0.5 FTE Quality Assurance and Safety Inspector (municipal building inspector or contracted auditor, Months 4–7 = 2027-02-08 to 2027-05-17) to: (1) conduct spot-check inspections of 10–20% of home kit installations (prioritizing structural, fire and electrical safety); (2) verify handyperson certification and training records before installation begins; (3) issue corrective notices within 24 hours for any code violations or safety gaps; (4) track remediation completion; (5) maintain audit logs for liability protection. Integrate QA findings into weekly progress reports to the kit coordinator; pause installations if >3% of audited work is non-compliant.

---

# Potential Improvements

## 1. Lack of explicit escalation decision tree and surge protocols for extreme-heat scenarios (40°C+ daytime or sustained multi-day heat)

The plan defines three alert levels with associated activations, but does not specify what additional actions trigger at sustained extremes (e.g., when forecast shows 40°C daytime for 5+ consecutive days, or national red warning persists). Extreme heat may require harder triage (directing oldest/frailest first), mutual-aid activation with hospitals, or temporary closure of some centers to concentrate staffing at largest sites. Without pre-set surge thresholds, incident command will improvise under crisis pressure, risking inconsistent decisions and reputational damage if a preventable death occurs during extreme heat.

**Recommendation**:
Draft an Extreme-Heat Surge Protocol by Month 3 (2027-01-08) specifying: (1) Tier 3a activation threshold (forecast ≥40°C daytime for ≥3 days + night low ≥23°C) triggers: all centers 24-hour operation, priority transport for 75+ and wheelchair users, pre-positioned water/shading at all outdoor municipal work sites, and pre-notification to hospitals and EMS of expected surge; (2) Tier 3b (same + national red warning or ≥5 consecutive days) adds: mutual-aid activation with neighboring city (pre-agreed partner), surge staffing from municipal emergency-reserve pool, closure of smaller centers to concentrate service, and direct hospital-EMS escalation for any suspected heat illness; (3) Mutual-aid agreement signed by Month 2.5 (2026-12-23) with neighboring city (e.g., Villarreal, ~30 km) specifying resource-sharing (staff, center capacity, transport vehicles). Include surge protocol in the drill at Month 7 (2027-05-08).

## 2. Insufficient detail on how to handle conflicting operational decisions (e.g., transport demand spike vs. dispatch capacity, center over-capacity vs. safety protocols)

During an alert, the incident commander, center network manager, and transport coordinator may face decisions that conflict (e.g., a cooling center reaches 100% capacity but residents continue arriving; transport dispatch is 60 minutes behind; EMS call volume is at 1.8× baseline). The plan mentions escalation to incident command but does not specify decision algorithms, delegation limits or communication protocols that preserve speed and clarity under stress.

**Recommendation**:
Develop an Operational Decision Matrix by Month 2.5 (2026-12-23) documenting: (1) Authority limits: incident commander has final authority on alert tier and stand-down; center network manager decides which sites to open and capacity adjustments; dispatch coordinator prioritizes by vulnerability (75+, wheelchair users, isolated residents) if wait times exceed 45 min; (2) Conflict resolution: if transport delay threatens the 45-min gate, dispatcher may request incident commander to authorize taxi-surge activation (additional vehicles at premium cost, up to €5k per day); (3) Safety thresholds: center closes entry if occupancy ≥110% fire-code capacity and transport redirects new arrivals to next-closest site with 15-min notice; (4) Health escalation: if EMS call volume reaches 1.5× baseline, commander notifies hospitals and prepares mutual-aid activation. Include conflict-scenario drills (e.g., capacity breach, dispatch overload) in the May full-system drill (Month 7 = 2027-05-08).

## 3. Limited clarity on financial accountability and mid-season budget re-forecasting if contingency is drawn or tranche-2 release is delayed

The plan allocates €280k contingency (8% of €3.5M) but does not specify: (1) who authorizes contingency draws >€10k; (2) how budget reforecasting occurs if tranche-2 (€1.5M) is delayed beyond Month 4 (2027-02-08); (3) which service elements are cut first if funding shortfalls occur; (4) how the city reports mid-season budget status to the funder and incident commander. Without clear financial governance, reactive spending and delayed decisions could cause missed gates or mid-season operational collapse.

**Recommendation**:
Establish a Financial Governance Protocol by Month 1.5 (2026-11-23) specifying: (1) Contingency-draw authority: draws >€5k require incident commander and PMO sign-off; draws >€25k also require funder notification within 24 hours; (2) Monthly budget review: PMO produces a spend-vs-forecast summary by the 25th of each month (Months 0–12 = 2026-10-08 to 2027-10-08), with re-forecast of cash flow to Month 12 (2027-10-08); (3) Trigger thresholds: if spend exceeds forecast by >10% (€200k), incident commander and PMO convene a budget-rebalancing meeting within 48 hours; if rebalancing cannot close the gap, funder is notified; (4) Spending priorities if funding shortfall: maintain center and transport operations first (gates 1 and 3); maintain outreach phone line second (gate 2); defer home-kit installations third (defer to Year 2 if needed); (5) Delayed release contingency: if Month 4 (2027-02-08) release is not approved, draw up to €150k from tranche-1 contingency (if available) to cover May–June operations, with re-test decision at Month 5 (2027-03-08). Monthly budget reports are presented to incident command and funder on the last working day of each month.

## 4. Underspecified role clarity and handoff procedures if the incident commander or other critical staff are absent during multi-day heat events

The plan names a deputy public-health incident commander but does not specify: (1) what decisions the deputy can make autonomously (alert declaration, spending authorization, resource reallocation) versus what requires consultation with the primary; (2) how long the primary can be absent before the deputy assumes full command; (3) handoff procedures and documentation if absence extends beyond 48 hours; (4) cross-training for the center manager, transport coordinator and communications lead to substitute for each other in emergencies.

**Recommendation**:
Draft a Continuity of Command and Succession Protocol by Month 2 (2026-12-08) specifying: (1) Primary incident commander (mayor's office or delegated) is the sole authority for alert declarations and spending authorization up to €50k per alert tier; above €50k, written approval required. (2) Deputy incident commander (public health) has full authority to declare and execute the approved response if the primary is unavailable for ≥2 hours; continuation ≥24 hours requires written notification to the mayor and funder. (3) If both primary and deputy are unavailable, written delegation passes to the civil protection operations lead (pre-signed, filed with municipal legal department) with the same authorities as the deputy, valid for ≤48 hours; beyond 48 hours, incident command returns to the mayor or funder decision. (4) Cross-training: center network manager and partner liaison officer can make operational (non-alert-declaration) decisions on center hours and partner coordination if incident commander is unavailable; dispatch coordinator can prioritize transport requests autonomously. (5) Handoff documentation: a brief incident-command log records all alert declarations, spending decisions, staffing adjustments and escalations daily; at shift-change (every 12 hours on multi-day events), the incoming commander reviews the log and confirms understanding with the outgoing commander.

## 5. No explicit feedback loop from residents using the program to improve service delivery mid-season

The plan tracks operational KPIs (center hours, transport time, outreach success) but does not include a mechanism to capture resident feedback about: accessibility barriers, quality of welcome at centers, comfort level with cooling spaces, perceived safety, language-access adequacy, or trust in the heat-illness escalation protocols. This feedback could identify equity gaps (e.g., elderly women avoiding mixed-gender day spaces) or low-quality implementations (e.g., dirty toilets, rude staff) early enough to fix in-season, improving both outcomes and equity.

**Recommendation**:
Implement a Simple Resident Feedback Loop by Month 6 (2027-04-08) consisting of: (1) Post-visit feedback cards at each cooling center (2–3 questions, large print, multilingual: 'Was this space comfortable? Did you understand what to do? Would you come again?'); staff collect completed cards in a box daily; partner liaison officer reviews cards weekly and flags issues (e.g., >20% 'no' responses on comfort) for correction within 48 hours. (2) Quarterly focus groups (n=10–15 residents per group, 45 min) at Months 3, 6, 9 (2027-01-08, 2027-04-08, 2027-07-08) to explore barriers (e.g., 'Why don't you use the cool center?'; 'What would make you trust the phone line?'); held at convenient times/locations; light refreshments provided; insights inform mid-season protocol adjustments. (3) Heat-line call-log analysis: randomly sample 5% of calls monthly (Months 5–11 = 2027-03-08 to 2027-09-08) for call quality, script adherence and resident satisfaction; >10% of calls rated 'poor quality' triggers staff retraining. These mechanisms ensure resident voice informs operations without slowing decision-making.

## 6. Vague timelines and ownership for translation and community-ambassador recruitment in early months (critical path risk)

Language access is identified as a priority for migrants and non-native speakers (5–8% of Castellón's population, estimated 8,500–13,600 people), but the team document does not specify: (1) who conducts the Month 0 (2026-10-08) language-need assessment; (2) which four-to-six languages are prioritized (assumed candidates: Arabic, Romanian, Portuguese, but unconfirmed); (3) who owns translation procurement, testing and quality assurance; (4) how community-ambassador recruitment occurs (which NGO partners, what timeline, pay rate). If translation and recruitment slip beyond Month 2 (2026-12-08), multilingual messaging will not be ready for the May-June season, reducing reach to migrants by an estimated 10–20% and potentially failing equity targets.

**Recommendation**:
Assign explicit ownership and timelines to the Communications Coordinator for language access: (1) By October 15 (Month 0.2 = 2026-10-14), conduct rapid language-need assessment via municipal integration office and NGO networks (e.g., housing associations, social services, migrant associations) to confirm top four-to-six languages; output: language list and estimated speaker counts per language. (2) By November 1 (Month 0.8 = 2026-11-01), commission professional translation of key materials (alert flyers, phone-line scripts, enrollment forms, cooling-center signage, fan-safety guidance) into the confirmed four-to-six languages; budget €15k–25k; delivery by Month 1.5 (2026-11-23). (3) By November 15 (Month 1.2 = 2026-11-14), launch community-ambassador recruitment through migrant associations and NGO partners, targeting 8–12 candidates (2 per language approximately); job description: 10–15 hours/week during alert season, hourly rate €12–15/hour (total ≈€50–75k for the season). (4) By December 8 (Month 2 = 2026-12-08), complete vetting and induction of 50% of target ambassadors (4–6 people) with de-escalation and heat-illness-recognition training; remainder by Month 3 (2027-01-08). (5) By April 15 (Month 6.1 = 2027-04-11), ambassadors are deployed at cooling centers and street-contact sites.

## 7. Insufficient specification of how to handle volunteers and partners experiencing safety incidents (assault, threat, witnessing severe distress)

The risk register identifies volunteer and street-contact staff safety as medium-to-high risk, and the Outreach Lead's responsibilities mention de-escalation training and safety protocols. However, the team document does not name an owner for: (1) incident-reporting systems and response procedures; (2) same-day debriefing and occupational-health referral; (3) investigation and learning from incidents; (4) communications with volunteers/partners after incidents (reassurance, peer-support offers). Without clear incident-response ownership, staff will feel unsupported after trauma, leading to turnover and liability exposure.

**Recommendation**:
Designate the Occupational Health Liaison (0.25 FTE, see first omission above) as the Incident Safety Owner and establish an Incident-Response Protocol by Month 2 (2026-12-08): (1) Any assault, threat, or serious distress exposure triggers immediate reporting to the Incident Safety Owner and incident commander within 2 hours via phone/secure email (one-page form capturing incident date/time, location, people involved, what happened, and actions taken). (2) Same-day response: occupational health liaison contacts the affected person by phone within 4 hours; offers immediate peer-support contact (another trained staff member); arranges access to counseling if desired (city-funded, up to 6 sessions). (3) Next-day debrief: Incident Safety Owner holds a 30-minute meeting with the affected person and their team lead to process the event and identify any operational changes needed (e.g., '3-person teams always' instead of '2-person teams'). (4) Weekly safety review: Incident Safety Owner reports all incidents (anonymized) to incident command and convenes a monthly safety-committee meeting with partner liaisons, outreach leads and volunteer coordinators to identify patterns and implement systemic changes (e.g., additional de-escalation training, revised site-access rules). (5) Public accountability: funder is informed of any serious incidents (assault, injury) within 24 hours. This prevents secondary trauma and builds a culture of safety.

## 8. Missing explicit plan for how cooling centers will manage frail or confused residents who arrive but cannot remain alone and have no designated caregiver present

Older and isolated residents, including those with mild cognitive impairment or dementia, may arrive at cooling centers but lack the capacity to coordinate their own transport home or may resist leaving if they feel unsafe or disoriented. The plan specifies accessibility and welcome protocols but does not address: (1) who is responsible for the resident's safety and supervision during their stay; (2) whether centers can accommodate extended stays (overnight, multiple days) if transport home is unavailable; (3) how to manage situations where a resident becomes acutely confused or combative; (4) communication with family or designated contacts.

**Recommendation**:
Draft a Frail and Vulnerable Resident Protocol by Month 2 (2026-12-08) to be implemented by cooling-center managers, specifying: (1) On arrival, center staff conduct a brief safety screen (using a simple checklist: alert/oriented? able to find toilet? able to communicate needs? has someone to contact?); (2) Residents who are alert and oriented are given a welcome card with center rules, phone numbers, and instructions for requesting help; (3) Residents who are confused, disoriented or alone and frail are assigned a staff member (or volunteer if available) to check in every 30 minutes, help with toileting and water, and identify any escalation needs; (4) If a resident is found to be at risk (e.g., very confused, showing signs of heat illness, no known contact), center staff immediately call the nurse triage line and the heat helpline to arrange transport home or to a hospital; (5) Centers may accommodate overnight stays (with AED, first aid and staff on-site) only if the resident is alert, consents, and transport home is unavailable; overnight stays are logged and escalated to incident command daily; (6) Center staff are trained in basic dementia-aware communication (calm tone, yes/no questions, patience) by Month 2 (2026-12-08) as part of the first-aid and customer-service induction.

## 9. No explicit mechanism for identifying and supporting outdoor municipal workers and private contractors during alert days before the formal alert is declared

The plan includes worker-protection clauses for municipal staff and guidance for private employers, but does not specify: (1) who monitors weather forecasts and alerts outdoor-work crews 24–48 hours in advance (before official alert declaration); (2) how private contractors outside municipal employment get timely warning; (3) what 'adjusted schedules' and 'mandatory breaks' mean operationally (e.g., start at 05:00, stop at 11:00, resume at 18:00?). Without proactive alerts to work sites, workers may not implement protections until the alert is declared at 12:00 mid-day, missing protection for the morning peak-heat period.

**Recommendation**:
Assign the public-works compliance monitor (see Risk 16 mitigation above) to establish a Proactive Worker Alert Protocol by Month 2 (2026-12-08): (1) Each morning (by 07:00) during the April–September season, the climate monitor reviews the national weather forecast and checks if an alert is likely in the next 24–48 hours (forecast ≥35°C daytime or ≥22°C night low for ≥2 consecutive days). (2) If likely, issue a Proactive Worker Alert by 09:00 to all municipal work crews (public works, parks, water, waste, housing maintenance) and active contractors (via email and phone to site managers) advising: forecast conditions, suggested schedule adjustments (start early, extended midday break), water and shade requirements, and that a formal alert may follow. (3) For private employers, the same message is distributed via the municipal employer-association email list and published on the city website. (4) When an official alert is declared, incident commander issues a formal Worker Activation Order confirming mandatory protections and schedule changes. (5) Compliance monitor conducts ≥2 unannounced site visits during each Level 2–3 alert day (sampling different sectors—public works, construction, waste, landscaping) to verify workers have water, shade, breaks and adjusted schedules. This reduces heat-illness risk among the working population by 4–8 weeks annually (April/May and August/September shoulder seasons).