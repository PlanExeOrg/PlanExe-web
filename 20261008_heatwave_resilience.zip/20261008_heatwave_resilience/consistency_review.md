## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Has the funder signed an amendment accepting drill-based evidence for the Month 4 (2027-02-08) gates and the €750k partial-release rule? | Written amendment signed by a budget-authorizing officer by Month 0.5 (2026-10-23) (before any binding order), with Month 1 (2026-11-08) as the hard tripwire. The rule is €750k (50%) at Month 4 (2027-02-08) if evidence is unmeasurable, and the remainder after the Month 5 (2027-03-08) re-test. A verbal assent does not count. | A signed funding amendment, expected Month 0.5 (2026-10-23). The funder briefing is scheduled for Month 0.1 (2026-10-11). | Freeze new commitments above €25k and defer discretionary hiring. If there is still no written acceptance at Month 2 (2026-12-08) and no funded bridge for the €200–400k gap, restart or re-scope to the tranche-1 minimum. Do not place the large kit orders (Month 1.2 = 2026-11-14) on an unconfirmed release rule. |
| 2 | Are the GDPR legal opinion and partner data-processing agreements (DPAs) in place, with enough partner call capacity and a valid lawful basis? | Counsel opinion at Month 1 (2026-11-08). At least 4 partner DPAs signed by Month 1.5 (2026-11-23). Combined partner capacity of at least 4,000 contact attempts per month (proposed threshold). Hospital/EMS data MOU signed (Month 1 = 2026-11-08; tripwire Month 2 = 2026-12-08). | Counsel's written opinion, the signed DPAs, and the partner capacity survey with written commitments (Months 1 to 1.5). The 50–100 call mock-call test is dated Month 1.5 (2026-11-23) in one document and Month 2 (2026-12-08) in others. | Delay enrollment and bring in backup partners. If counsel finds no valid lawful basis, stop the intermediary model and redesign outreach. If the health MOU is missing at Month 3 (2027-01-08), drop mortality-attribution claims and evaluate operational outcomes only. |
| 3 | Does the Month 2 (2026-12-08) readiness gate pass? | All of the following: ≥8 of 10 sites signed with named managers; ≥50% of places in accessible sites; taxi retainer signed (cap €80k, ≥10 vehicles within 20 min, ≥3 wheelchair-capable); ≥20 volunteer drivers vetted; heat line live with mock passed (5–8 requests, 3–5 escalations); outreach/escalation training of staff then in post and 25–35 partner/street staff (test ≥80%); 100% of tranche-1 orders placed, including the first kit call-off of 600–800 units (Month 1.2 = 2026-11-14). | The Month 2 (2026-12-08) gate report with signed contracts, the order register, training logs and the mock-call result. | Fix the unmet criterion by Month 2.5 (2026-12-23). If the project is more than 4 weeks behind at Month 3 (2027-01-08), trigger a funder restart or re-scope review. With fewer than 15 volunteers and no retainer, pause scale-up and re-scope transport. |
| 4 | Does the full-system drill pass all four Month 4 (2027-02-08) scale-gate criteria, so the €1.5M can be released? | ≥80% of planned center hours delivered; ≥60% contact success from ≥300 attempts; mean request-to-pickup <45 min over ≥30 requests including ≥5 wheelchair users; after-action report complete with 100% of corrective actions closed (Month 3.9 = 2027-02-04). | The independently observed drill at Month 3.2 (2027-01-14), the after-action draft at Month 3.5 (2027-01-23), and the gate decision at Month 4 (2027-02-08). | A failed gate means no release; fix and re-test at Month 5 (2027-03-08), and if it fails again scale back to the tranche-1 minimum. Unmeasurable or insufficient evidence means €750k at Month 4 (2027-02-08) and the remainder after the Month 5 (2027-03-08) re-test. |
| 5 | Are the home kits and enrollment on track for the heat season by Month 7.3 (2027-05-17)? | ≥40% of kits delivered by Month 4 (2027-02-08); ≥500 homes installed by Month 5 (2027-03-08); ≥1,000 homes installed by Month 7.3 (2027-05-17), with 2,000 as the target; ≥1,500 enrolled by Month 5 and 3,000 (2027-03-08, 2027-01-08, 2026-10-08) by Month 7 (2027-05-08); installation QA failure ≤3%. | The supplier delivery log, the installation register, the QA inspections (10–20% of installs) and the enrollment counts by neighborhood. | Switch to the backup supplier. Cut kit scope to 1,000–1,500 homes and protect refuges and transport. If fewer than 1,000 homes are installed at Month 7.3 (2027-05-17), stop new kit purchases and redirect the funds. Add door-knock outreach only once its funding source is decided. |
| 6 | Is at least one Year-2 funding source committed for the continuing footprint? | A letter of intent by Month 9 (2027-07-08) covering the Year-2 scope. The estimate is ≈€2.3M per year for the same footprint, with a scaled-back scope as the fallback. A mayoral continuity commitment follows by Month 11 (2027-09-08). | A funder or municipal letter of intent at Month 9 (2027-07-08), after sources are approached by Month 6 (2027-04-08). | Publish the scaled-back Year-2 scope and do not commit to expansion. Document the continuation limits in the Year-2 roadmap at Month 12 (2027-10-08). Do not promise city-wide scaling. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: premortem FM1 / self_audit
    canonical: financing_model_no_revenue = 100% grant-financed; no fares, no user charges, no revenue, no debt, no debt service
    observed:  municipal credit line / €200k credit line or bridging line
HIGH CF-002  document: executive_summary
    canonical: outreach_model_and_targets = 3,000 enrolled by Month 7 (2027-05-08) (≈9% of 65+ of ≈34,000)
    observed:  expanded to 20–25% coverage with only +1,500–2,500 contacts
HIGH CF-003  document: executive_summary / review_plan
    canonical: home_kit_scope_and_cost = ≈€600k for 2,000 homes + ≈€200k (expedite premium, storage, buffer stock, QA, hydration) = €800k
    observed:  €200k expedite premium pre-committed, consuming 71% of the €280k contingency; also €50–100k
HIGH CF-004  document: review_plan / self_audit / premortem FM2
    canonical: transport_model = taxi/accessible-transport standby retainer capped at €80k; scale up if <20 recruits in pipeline at Month 1.5 (2026-11-23)
    observed:  scale retainer to €100–120k if <15 vetted; stop rule <15 vetted at Month 2 (2026-12-08)
HIGH CF-005  document: project_plan / canonical_facts
    canonical: hiring_and_rota = hiring 40% Month 3, 40 (2027-01-08, 2030-02-08)% Month 4, 20 (2027-02-08, 2028-06-08)% Month 5 (2027-03-08); all in post by Month 6.7 (2027-04-29)
    observed:  Month 2 (2026-12-08) gate 'staffed'; Month 3.2 (2027-01-14) drill must deliver ≥80% of planned hours
MEDIUM CF-006  document: pitch / review_plan
    canonical: year2_recurring_cost_estimate = ≈€2.3M per year to continue the same footprint (estimate, no inflation); funding source not identified
    observed:  ≈€2.3M for city-wide scale-up with 15–20 sites and retrofits; reduced scope €1.2–1.5M vs €1.5–2.0M
MEDIUM CF-007  document: review_plan Review 6
    canonical: month4_gate_outreach_contact = ≥60% contact success from ≥300 attempts
    observed:  <55% success fails the gate
MEDIUM CF-008  document: pitch
    canonical: gate4_partial_release_rule = €750k at Month 4 (2027-02-08); remainder after a Month 5 (2027-03-08) re-test
    observed:  remainder after a May 2027 re-test; peer cities test in 2028
MEDIUM CF-009  document: pitch / executive_summary
    canonical: baseline_estimates = 80-120 heat-related EMS calls and 15-25 excess deaths per summer (provisional)
    observed:  25+ excess deaths; demonstrate ≥10–15% EMS reduction
MEDIUM CF-010  document: self_audit / review_plan
    canonical: taxi_only_fallback = draws 54-89% of the €280k contingency (only €160k available before Month 4 = 2027-02-08)
    observed:  54–89% of the €160k; 36–71%; 17–29% of outreach; 6 weeks / 3.5 weeks
MEDIUM CF-011  document: self_audit / review_plan / premortem
    canonical: procurement_route = specs Month 0.8 (2026-11-01); first wave by Month 1.5 (2026-11-23); all tranche-1 orders by Month 2 (2026-12-08); first kit call-off Month 1.2 (2026-11-14)
    observed:  RFQs/specs Month 0.3 (2026-10-17); first order Month 1 (2026-11-08); orders locked Month 1.5 (2026-11-23)
```

### 1. Gap financing vs the no-debt financing model (🔴 High) — needs a project decision

- **canonical_facts (financing_model_no_revenue, gate4_partial_release_rule):** Canonical: 100% grant-financed, no debt. Delayed release leaves a €200–400k cash gap, €40–240k above the €160k tranche-1 contingency.
- **premortem FM1; self_audit items 2 and 6:** FM1 proposes 'a municipal credit line', the stop rule needs 'a bridging line of at least €200k', and the self-audit proposes a '€200k credit line'. The stop-rule size of €200k is below the up-to-€240k shortfall left after the €160k contingency.
- **Why it conflicts:** The mitigations rely on borrowing or a credit line that the financing model excludes. No document says who pays the gap. The €200k bridge also does not cover the top of the stated gap range.
- **Suggested resolution:** Decide the bridging source explicitly. Options: a funder advance or earlier partial release, a municipal treasury advance accepted as non-debt, moving part of the €120k tranche-2 contingency into tranche 1, or a pre-agreed scale-back to the tranche-1 minimum. Size the bridge to the gap (up to about €240k after contingency), or define the scale-back instead.

### 2. Equity coverage target vs outreach arithmetic (🔴 High)

- **executive_summary (Key Deliverables, Risk 3); review_plan Review 3:** Intermediary lists enroll 3,000 residents, plus 1,500–2,500 door-knock contacts, giving a total reach of about 5,000 (≈9% of 34,000 rising to roughly 13–16%).
- **executive_summary Risk 3 and Overall Takeaway; review_plan Review 6 item 3:** The same door-knock step is said to 'achieve 20–25% coverage', and the equity KPI asks for ≈7,000–8,500 of 34,000 reached by Month 12 (2027-10-08). The unreached population is given as '25,000'.
- **Why it conflicts:** 3,000 + 1,500–2,500 = 4,500–5,500, which is 13–16% of 34,000, not 20–25%. Reaching 20–25% needs about 6,800–8,500 people, which the €50–80k expansion does not fund. With 5,000 reached, about 29,000 are unreached, not 25,000.
- **Suggested resolution:** Restate the pilot coverage as roughly 13–16% (estimate) and unreached as about 29,000. Treat 20–25% as a Year-2 target. If 20–25% is wanted in Year 1, a separately funded larger expansion has to be decided.

### 3. Kit expedite premium: size and where it is funded (🔴 High)

- **canonical_facts (home_kit_scope_and_cost, contingency_exposure_and_free_contingency):** Canonical: ≈€200k covers expedite premium, storage, buffer stock, QA and hydration supplies, inside the €800k kit category. No item is pre-committed in the €280k contingency.
- **executive_summary Risk 2; review_plan Review 1 item 2, Review 2 item 2, Review 8 item 3:** A '€200k expedite premium' is 'pre-committed' and 'consumes 71% of the €280k contingency'. The same documents also size the expedite premium at €50–100k (10–15%) and say it draws 36–71% of the tranche-1 contingency.
- **Why it conflicts:** The expedite premium is shown as €200k and as €50–100k, and as inside the kit budget and as a draw on contingency. If it is pre-committed from the contingency, the contingency is no longer free. 10–15% of hardware of about €500k is only about €50–75k.
- **Suggested resolution:** Keep the canonical split: the €800k kit category already holds the ≈€200k bundle. The expedite premium alone is a €50–100k (estimate) line within it. Contingency draws arise only when costs exceed that category. Remove 'pre-committed' and the 71% statement.

### 4. Taxi retainer cap and volunteer shortfall thresholds (🔴 High)

- **canonical_facts (transport_model, transport_contract_timing); project_plan Mitigation Plans:** Canonical: retainer capped at €80k. A shortfall is under 20 recruits in the pipeline at Month 1.5 (2026-11-23), and ≥20 volunteers must be vetted by Month 2 (2026-12-08). Project plan: 'scale the taxi retainer (capped at €80k)'.
- **review_plan Review 4 item 1; self_audit items 2, 15, 17; premortem FM2 stop rule; executive_summary Action Orientation:** If '<15 vetted by Month 1.5 (2026-11-23), scale the taxi retainer to €100–120k'. FM2 stop rule is 'fewer than 15 vetted' at Month 2 (2026-12-08). Executive summary says to confirm '≥20 volunteer drivers vetted' by Month 1.5 (2026-11-23).
- **Why it conflicts:** €100–120k exceeds the €80k cap. A trigger of 15 differs from 20, and the same ≥20-vetted milestone is dated Month 1.5 (2026-11-23) in one place and Month 2 (2026-12-08) in the others. 15 vetted at Month 2 (2026-12-08) would fail the readiness gate.
- **Suggested resolution:** Keep the €80k cap, the trigger of <20 recruits in the pipeline at Month 1.5 (2026-11-23), and ≥20 vetted at the Month 2 (2026-12-08) gate. Treat anything above €80k as the taxi-only fallback (+€150–250k), which needs an approval decision.

### 5. Drill and gate need staff who are not yet hired (🔴 High) — needs a project decision

- **project_plan (Measurable, Dependencies); canonical_facts (month2_readiness_gate, month4_gate_center_hours):** The Month 3.2 (2027-01-14) drill and Month 4 (2027-02-08) gate require ≥80% of planned center hours and a 3-FTE dispatch team. The Month 2 (2026-12-08) gate needs centers 'contracted and staffed'.
- **canonical_facts (hiring_and_rota); premortem FM5; review_plan Review 13 item 3:** Hiring is 40% at Month 3, 40 (2027-01-08, 2030-02-08)% at Month 4 and 20 (2027-02-08, 2028-06-08)% at Month 5 (2027-03-08), with all staff in post by Month 6.7 (2027-04-29). The documents say the drill 'runs with few staff' and 'only 30–40% of staff in post by Month 3 (2027-01-08)'.
- **Why it conflicts:** A drill six days after the first 40% cohort starts cannot show 80% of planned hours with staff who are mostly unhired and untrained. The gate evidence would then be unrepresentative of the real season.
- **Suggested resolution:** Decide how the drill is staffed: bring hiring forward within tranche 1, use seconded municipal staff and volunteers for the drill, or define 'planned hours' for the drill as a scaled-down roster. Record which staff counts the funder accepts.

### 6. Funder sign-off deadline and status (🟡 Medium)

- **executive_summary; review_plan Review 1 and Review 3:** Written funder sign-off on the drill rule and partial release is required by Month 0.5 (2026-10-23), before procurement. The Review states that no written agreement exists.
- **premortem A1 and FM1; self_audit items 6 and 20:** A signed amendment is due 'by Month 1 (2026-11-08)', failure is tripped at Month 1 (2026-11-08), and the stop rule is Month 2 (2026-12-08). The self-audit says 'only verbal assent documented'.
- **Why it conflicts:** The same dependency has three deadlines: Month 0.5 (2026-10-23), Month 1 (2026-11-08) and Month 2 (2026-12-08). Binding kit orders at Month 1.2 (2026-11-14) would come before a Month 1 or 2 (2026-11-08, 2026-12-08) sign-off. 'Verbal assent' is stated as fact, but the first funder briefing is only scheduled for Month 0.1 (2026-10-11).
- **Suggested resolution:** Use Month 0.5 (2026-10-23) as the target and Month 1 (2026-11-08) as the hard tripwire. Hold binding orders above the contingency-covered amount until sign-off. Delete the 'verbal assent' claim unless a record exists.

### 7. Year-2 scope and cost (🟡 Medium) — needs a project decision

- **canonical_facts (year2_recurring_cost_estimate); project_plan:** Canonical: ≈€2.3M per year continues the same footprint; funding source not identified.
- **pitch Long-term Vision; review_plan Reviews 2, 11 and 14; self_audit items 8 and 17:** The pitch says Year 2 'scales to all 170,000 residents' for ≈€2.3M, with 15–20 refuge sites and durable retrofits. Review 2 has 8,000–12,000 enrolled at €2.3M. The fallback is '€1.2–1.5M refuges only' in Review 14 and the self-audit, but 'reduced budget €1.5M–€2.0M' in Review 11.
- **Why it conflicts:** One cost figure is attached to a continuing footprint, a city-wide expansion with retrofits, and a larger enrollment. Two different reduced-budget ranges are also given.
- **Suggested resolution:** Define the Year-2 scenarios explicitly (continue the footprint ≈€2.3M; reduced; expanded) with separate cost estimates. Make the funding-source decision per scenario. Do not use €2.3M for the expanded case.

### 8. Outreach contact-success threshold and mock-call timing (🟡 Medium)

- **canonical_facts (month4_gate_outreach_contact); project_plan:** The gate is ≥60% contact success from ≥300 attempts.
- **review_plan Review 6 item 2; premortem A3 and FM3; self_audit item 2:** KPI 2 says '<55% success fails the gate'. The mock-call test is at Month 1.5 (2026-11-23) with a 55% trigger in A3, but at Month 2 (2026-12-08) validating ≥60% in the review and self-audit. The FM3 stop rule also uses 55%.
- **Why it conflicts:** A result of 55–59% fails a ≥60% gate, so '<55% fails' is wrong. The pre-test pass level and its month differ between documents.
- **Suggested resolution:** Keep ≥60% as the gate. Present 55% only as an early-warning or stop level. Fix the mock-call date (Month 1.5 = 2026-11-23 or Month 2 = 2026-12-08) and its pass level.

### 9. Pitch dates for re-test and peer-city test (🟡 Medium)

- **canonical_facts (gate4_partial_release_rule, deliverables_timeline); project_plan:** The remainder of the €1.5M is released after a Month 5 (2027-03-08) re-test. The peer-city test and draft playbook are at Month 11 (2027-09-08).
- **pitch Risks and Call to Action:** The pitch says 'the remainder after a May 2027 re-test' and that peer cities 'test the playbook in 2028'.
- **Why it conflicts:** A May re-test is about Month 7 (2027-05-08), two months later than Month 5 (2027-03-08), so the cash gap would be longer. A peer-city test in 2028 falls after the Month 12 (2027-10-08) playbook delivery.
- **Suggested resolution:** Change to a March 2027 (Month 5 = 2027-03-08) re-test and a peer-city test at Month 11 (2027-09-08). Describe 2028 as the wider rollout.

### 10. Outcome claims presented as fact or deliverable (🟡 Medium)

- **canonical_facts (baseline_estimates, evaluation_design_and_limits); project_plan:** Baseline is 80–120 heat-related EMS calls and 15–25 excess deaths per summer (provisional). No mortality-reduction target is a gate, and the evaluation reports limits.
- **pitch Overview; executive_summary Key Deliverables:** The pitch says Castellón 'faces 25+ excess deaths per summer' and promises 'demonstrable harm reduction'. The executive summary lists 'demonstration of ≥10–15% reduction in heat-related EMS calls' as a deliverable.
- **Why it conflicts:** '25+' is stated as fact and exceeds the provisional upper bound. A 10–15% reduction of 80–120 calls is 8–18 calls, which the Review says may be unmeasurable.
- **Suggested resolution:** Use '15–25 (estimate, pending audit)'. Describe EMS reduction as a tracked outcome with confidence ranges, not a deliverable to be demonstrated.

### 11. Percentage and duration arithmetic errors (🟡 Medium)

- **canonical_facts (taxi_only_fallback, budget_allocation_by_category):** Recomputed: €150–250k is 54–89% of the €280k contingency, but 94–156% of the €160k tranche-1 contingency. €50–100k is 31–63% of €160k. €50–80k is 11–18% of the €450k outreach category. Month 0.8 (2026-11-01) to Month 1.2 (2026-11-14) is about 13 days.
- **self_audit items 5 and 17; review_plan Reviews 2, 3 and 13:** Taxi-only fallback is said to exhaust '54–89% of the €160k'. €50–100k is '36–71% of tranche-1 contingency'. €50–80k is '17–29% of outreach budget'. The spec-to-order window is '6 weeks' in one place and '3.5 weeks' in another.
- **Why it conflicts:** The percentages are computed against the wrong base. The two windows differ from each other and from the dates (Month 0.8 = 2026-11-01 to Month 1.2 = 2026-11-14).
- **Suggested resolution:** Use the canonical figures and correct the bases: 54–89% refers to €280k only; tranche 1 has €160k. Put the window at about 2 weeks.

### 12. Procurement milestone months differ (🟡 Medium)

- **canonical_facts (procurement_route, kit_delivery_and_install_schedule); project_plan:** Specs are issued at Month 0.8 (2026-11-01). The first kit call-off (600–800 units) is placed at Month 1.2 (2026-11-14). Procurement is locked by Month 1.2 (2026-11-14).
- **premortem A2; review_plan Review 13 item 2; self_audit items 2 and 5; executive_summary Overall Takeaway:** RFQs go out at Month 0.3 (2026-10-17) and specs at Month 0.3 (2026-10-17) 'not Month 0.8 (2026-11-01)'. The first order is placed by 'Month 1 (2026-11-08), one week early'. The executive summary Overall Takeaway says orders are locked by Month 1.5 (2026-11-23).
- **Why it conflicts:** RFQs at Month 0.3 (2026-10-17) come before the specs at Month 0.8 (2026-11-01) that they depend on. The first order is dated Month 1 (2026-11-08) and Month 1.2 (2026-11-14), and the lock Month 1.2 (2026-11-14) and Month 1.5 (2026-11-23). Month 1 (2026-11-08) is also called 'one week early', but it is 6 days before Month 1.2 (2026-11-14).
- **Suggested resolution:** Keep the canonical dates. Month 0.3 (2026-10-17) can remain only as a supplier market sounding. Specs at Month 0.8 (2026-11-01), first call-off at Month 1.2 (2026-11-14), all tranche-1 orders by Month 2 (2026-12-08).

## Summary

The plan is largely consistent on its core structure: the budget allocation sums to €3.5M, the alert ladder, gate criteria, drill schedule and contingency figures match the canonical facts, and the self-audit counts add up. Most conflicts are in the derived documents (review, premortem, self-audit, pitch), which drift from the canonical dates, caps and thresholds, and contain several arithmetic errors, especially in coverage percentages and contingency shares. Three issues need project decisions rather than text fixes: how the €200–400k cash gap is financed under a no-debt model, how the Month 3.2 (2027-01-14) drill is staffed before most hires start, and what the Year-2 scope is. The plan is workable once these are settled and the dates are aligned.