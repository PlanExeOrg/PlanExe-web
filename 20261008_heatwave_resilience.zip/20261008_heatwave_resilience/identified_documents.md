
## Documents to Create

### 1. Heat Response Program Charter

**ID:** 0bcf463d-731c-446f-9d67-733e1f376c31

**Description:** Project charter defining goals, scope, constraints, stakeholders, and governance structure for the 12-month municipal heatwave-response pilot in Castellón de la Plana. Establishes authority, budget, timeline, and decision-making framework. Audience: city leadership, funder, partners, operational team.

**Responsible Role Type:** Project Manager / PMO Lead

**Primary Template:** PMI Project Charter Template

**Secondary Template:** EU Public Health Program Charter

**Steps:**

- Synthesize project brief and SMART criteria into a one-page executive summary.
- Define scope: 10 cooling refuges, 40 volunteer drivers + taxi retainer, 5,000 outreach contact attempts, 2,000 home kits, health-data loop, worker protection, communications.
- Specify hard constraints: €3.5M cap, 12-month duration, no new legislation, GDPR limits, no major construction.
- List four scale gates (Month 4 = 2027-02-08): 80% center hours, 60% outreach success, <45-min transport, after-action closure.
- Name incident commander (mayor's office), public-health deputy, operations lead, communications lead, partner-liaison officer.
- Obtain signatures from mayor, funder representative, and incident commander by Month 0.5 (2026-10-23).

**Approval Authorities:** Mayor's office, funder, incident commander, public-health department director

### 2. Incident Command Delegation Letter

**ID:** 949808f1-5ef1-4a78-9902-d01108ee2735

**Description:** Written delegation from the mayor to the named incident commander, specifying alert-declaration authority, spending limits per tier, escalation chain, and continuity procedures. Establishes legal basis for cross-department orders during heat events. Legal document filed with municipal secretary.

**Responsible Role Type:** Legal Counsel / Mayor's Office

**Primary Template:** Municipal Emergency Authority Delegation Template

**Steps:**

- Work with municipal legal department to draft delegation specifying: (1) trigger criteria (forecast thresholds), (2) alert-declaration procedures, (3) spending authority per tier.
- Name backup authority (public-health deputy) and cascading succession if primary unavailable ≥2 hours.
- Define cross-department authority: incident commander can direct civil protection, municipal services, transport, public works without secondary approval.
- Specify retention period (one year, renewable) and update triggers (e.g., at political transition).
- Obtain mayoral signature and file with municipal legal department by Month 1 (2026-11-08).
- Distribute to all partners and operational staff; brief all departments jointly.

**Approval Authorities:** Mayor, municipal legal counsel, city council if ordinance status required

### 3. Alert Trigger Ladder & Activation Thresholds

**ID:** 66c144d3-201d-4804-89ea-dd946e738907

**Description:** Defines three alert levels (Advisory, Alert, Emergency) with forecast trigger criteria, mandatory actions per tier, spending authority, and stand-down procedures. Links national meteorological-service forecasts to pre-agreed operational response. Audience: incident command, operations, partners, public.

**Responsible Role Type:** Incident Commander / Operations Lead

**Primary Template:** Heat Action Plan Alert Protocol (Barcelona/Paris model)

**Secondary Template:** National Meteorological Service Guidance (AEMET)

**Steps:**

- Confirm temperature thresholds with national meteorological service (AEMET) and local climate context: Level 1 ≥33°C daytime or ≥20°C night for ≥2 days; Level 2 ≥35°C daytime and ≥22°C night for ≥2 days; Level 3 same for ≥3 days.
- Specify actions per level: advisory = phone checks + pre-positioned supplies; alert = centers 10:00-20:00; emergency = 24-hour operation + surge staffing.
- Define spending authorization per tier (e.g., Level 1 ≤€2k, Level 2 ≤€10k, Level 3 open).
- Establish stand-down criteria: forecast <35°C and prior 48 hours normal temperature; stand-down order ≤2 hours after criteria met.
- Include historical summer temperature data (2015–2025) for Castellón to validate thresholds post-hoc after first season.
- Finalize by Month 1 (2026-11-08); validate with AEMET; publish to partners and public by Month 6 (2027-04-08).

**Approval Authorities:** Incident commander, AEMET representative, operations lead, public-health deputy

### 4. Cooling Refuge Network Operations Manual

**ID:** b6cf68d9-1a39-4b15-8793-d8f7e77ad45d

**Description:** Specifies site locations, accessibility standards, staffing roles, operating hours by alert level, safety protocols (first aid, AED, incident escalation), occupancy management, and supply requirements (water, toilets, quiet rooms, signage). Includes templates for daily occupancy logging and incident reporting.

**Responsible Role Type:** Cooling Center Network Manager

**Primary Template:** Municipal Facility Operations Standard

**Secondary Template:** Disability-Access Audit Checklist (EN 17210)

**Steps:**

- Audit all 10 proposed sites (libraries, community centers, parish halls) for accessibility (wheelchair ramps, toilets, quiet rooms, water, parking, signage).
- Score each site as 'fully accessible' or 'requires remediation'; prioritize ≥50% of places as fully accessible by Month 2 (2026-12-08).
- Draft facility-use MOU with each site specifying: hours (10:00-20:00 Level 2-3, extended to 24:00 Level 3 at 3 anchor sites), staffing (1 manager + assistants), security, liability, utilities cost-sharing.
- Design staffing structure: 1-2 staff per site per shift; rotation to cover 10:00-20:00 (Level 2) or 24:00 (Level 3) with ≤3-day shifts then rest days.
- Create daily occupancy-logging form (names optional, counts by hour, notes on access barriers, incidents).
- Develop incident-escalation tree: minor issues (no water) → site manager contact; heat illness → call nurse triage line → escalate if needed to EMS.
- Publish accessibility information (routes, facilities, opening hours, parking, quiet-room availability) in plain language and translated into 4-6 languages.
- Finalize by Month 2 (2026-12-08); train all center staff by Month 5 (2027-03-08).

**Approval Authorities:** Cooling Center Network Manager, incident commander, facility managers, disability-access officer

### 5. Transport Dispatch & Volunteer Driver Management Protocol

**ID:** b12e50a2-a4cd-4bd1-af2c-c1361c2ef107

**Description:** Specifies volunteer recruitment and vetting procedures (background checks, insurance, safeguarding training, shift caps), dispatch procedures (call intake, driver assignment, wait-time tracking, escalation), taxi retainer contract terms, and incident-response protocols (assault, vehicle accident, no-show).

**Responsible Role Type:** Transport Dispatch and Mobility Coordinator

**Primary Template:** Volunteer Driver Program SOP (Red Cross/Salvation Army model)

**Secondary Template:** Taxi/Paratransit Retainer Contract Template

**Steps:**

- Recruitment: Launch campaign targeting 60-80 volunteers (retirees, faith-group members, charity workers) by Month 0 (2026-10-08); intake deadline Month 1.5 (2026-11-23).
- Vetting: Background checks (police records), insurance verification (personal or municipal policy), and 2-hour safeguarding training (de-escalation, trauma-informed care, assault protocol). Vetting cohorts every 2 weeks; ≥20 vetted by Month 2 (2026-12-08).
- Dispatch procedures: Phone intake (name, address, postcode optional, transport need, cooling-center preference, language); log in shared spreadsheet updated in real-time; dispatcher assigns driver by proximity and availability; confirm pickup ETA within 15 min.
- Driver accountability: Confirm driver arrival within 15 min; no-show = mark unavailable for remainder of alert, require post-alert debrief before re-deployment.
- Taxi retainer: Contract with ≥10 vehicles (≥3 wheelchair-accessible), 20-min response guarantee, standby fee capped at €80k. Activation trigger: if volunteer roster <20 active by Month 1.5 (2026-11-23), scale retainer proportionally.
- Incident reporting: Assault, threat, vehicle accident, or safeguarding concern → same-day report to coordinator, occupational-health referral within 24 hours, debrief with supervisor, incident log maintained for audit.
- Finalize by Month 1 (2026-11-08); train all drivers and dispatchers by Month 2 (2026-12-08).

**Approval Authorities:** Transport Dispatch and Mobility Coordinator, incident commander, taxi operator, volunteer supervisor

### 6. Outreach & Street Contact Pathway SOP

**ID:** 10bf6304-e871-4235-a670-e84145e39e7b

**Description:** Defines outreach methods (intermediary-held contact lists, door-knock, street rounds for unhoused), enrollment process, heat-illness escalation protocols, staff safety procedures, and de-escalation scripts. Specifies roles of housing associations, social services, NGOs, pharmacies, and municipal outreach teams. Includes consent and withdrawal procedures.

**Responsible Role Type:** Outreach and Street Contact Lead

**Primary Template:** Municipal Social Services Outreach Protocol

**Secondary Template:** Heat Illness Recognition & Escalation Checklist (adapted from NOAA/CDC)

**Steps:**

- Intermediary-held lists: Map 4-6 partner organizations (housing associations, social services, NGOs, pharmacies) and establish baseline call-center capacity per partner (staff count, calls/day, turnover rate).
- Contact protocol: Each partner logs outreach attempts (date, time, outcome: reached/unreachable/declined/transport accepted) daily; city receives aggregate counts (no names) by 12:00 each alert day.
- Consent & withdrawal: Residents opt-in via GP, pharmacy, or center; consent form specifies heat-season contact only, 30-day retention, and withdrawal procedure (call heat line, visit center, email DPO).
- Heat-illness escalation: Co-design checklist with emergency-medicine clinician listing signs (confusion, weakness, core-temp indicators) and decision rules: 112 call if severe, phone triage if mild, home management if minimal.
- Street contact (unhoused): Partner with 1-2 NGOs to deploy alert-day mobile water/shade rounds to known sites; provide referral cards with heat-line and cooling-center addresses; transport triggers documented.
- Staff safety: Teams of ≥2 (never solo); de-escalation training (2-hour module, annual refresh); incident reporting within 2 hours; occupational-health counseling within 24 hours post-incident.
- Finalize by Month 1 (2026-11-08); train all outreach staff (25-35 people) by Month 2 (2026-12-08) with written test ≥80%.

**Approval Authorities:** Outreach and Street Contact Lead, incident commander, partner organizations, occupational health

### 7. Heat-Illness Recognition & Escalation Checklist

**ID:** 3fd92964-2199-48c4-abdc-f890cafa7beb

**Description:** Pocket-sized or laminated checklist for outreach, street-contact, cooling-center, and dispatch staff to recognize heat illness (confusion, weakness, skin temperature, loss of consciousness) and determine escalation path (EMS call vs. phone triage vs. home advice). Decision tree specifies when to call 112, when to use nurse triage line, and when to manage at home.

**Responsible Role Type:** Outreach and Street Contact Lead / Occupational Health Nurse

**Primary Template:** Heat-Related Illness Recognition Flowchart (CDC/NOAA model)

**Steps:**

- Co-design with senior emergency-medicine clinician and occupational health: list classic heat-stroke signs (confusion, loss of consciousness, hot/dry or profusely sweating skin) and milder heat-exhaustion signs (weakness, dizziness, nausea).
- Create a yes/no decision tree: if confused OR unconscious OR core-temp indicator → call 112; if mild weakness + no confusion → call nurse triage line; if mild dehydration + alert → home management (water, rest, cool compress).
- Specify nurse-triage-line purpose: phone assessment of suspected heat illness, guidance on home vs. transport to ED, escalation to EMS if needed.
- Include de-escalation language: calm tone, yes/no questions, acknowledgment of distress, no promises of immediate relief.
- Translate into 4-6 local languages; produce pocket-sized laminated cards (2 x 3 inches) for all field staff.
- Require written test (≥80% pass) before alert-day authorization; annual refresh training.
- Finalize by Month 1 (2026-11-08); distribute by Month 2 (2026-12-08).

**Approval Authorities:** Occupational Health Nurse, emergency-medicine consultant, Outreach Lead

### 8. Home Kit Targeting & Installation SOP

**ID:** 1b427ec7-41e0-4c6b-901c-7ca24afbc037

**Description:** Specifies rubric for household selection (top-floor/poor insulation, age ≥75, living alone, built <1980, no AC; score ≥60 for full kit), procurement specifications (shading, blinds, fans, thermometers, hydration supplies), handyperson vetting and training (fan-safety installation, code compliance), installation scheduling, quality-assurance audit (10-20% sample), and return/collection procedures if kits are loaned.

**Responsible Role Type:** Home Interventions and Handyperson Coordinator

**Primary Template:** Energy-Efficiency Retrofit Program SOP

**Secondary Template:** Handyperson Safety Checklist (electrical fan safety, building-code compliance)

**Steps:**

- Selection rubric: Score households 0-100 (top-floor/poor insulation 30 pts; age ≥75 or chronic condition 25 pts; living alone 20 pts; built before 1980 15 pts; no AC 10 pts). Prioritize ≥60-score households; prioritize further by deprivation index and housing type (social housing, top-floor rentals).
- Procurement specs: Exterior shading (aluminum reflective, 50% reflectivity minimum), reflective blinds (80%+), directional window fans (≥6-inch diameter, low noise, reversible airflow), digital thermometers (±0.5°C), hygrometers, and hydration supply packs (electrolyte tablets, water bottles).
- Handyperson hiring & training: Recruit 10 installers (Q1-Q2 2027); conduct 2-hour fan-safety and code-compliance training (safe electrical connections, wind-load testing, fire-hazard inspection, no blocking smoke detectors); require written test ≥80%.
- Installation protocol: Pre-site inspection (confirm no building-code conflicts); install shading/blinds per manufacturer specs; install fan with directional-airflow-only setup; leave written guidance with resident on safe fan use (day/night directional rules, water breaks, no alcohol).
- Quality assurance: Sample 10-20% of installations (100-200 homes) via municipal building inspector or external auditor; check workmanship, code compliance, resident understanding. If >3% are non-compliant, pause all installations and retrain handypersons.
- Delivery & install schedule: First 30-40% kits (600-800) delivered by Month 4 (2027-02-08); 80% by Month 5 (2027-03-08); 100% by Month 6 (2027-04-08); all installs completed by Month 7.3 (2027-05-17).
- Finalize by Month 0.8 (2026-11-01); place first-order by Month 1.2 (2026-11-14).

**Approval Authorities:** Home Interventions Coordinator, municipal building inspector, occupational health

### 9. GDPR Compliance & Data-Processing Framework

**ID:** 7fbc7480-96b7-4a91-9f60-d6d2f8a92a4e

**Description:** Specifies lawful basis for heat-alert contact (public task + consent hybrid), defines controller/processor roles (housing associations, social services, NGOs as joint controllers or processors; city as recipient only), outlines data-protection-impact assessment (DPIA) scope, partner audit procedures, breach-notification escalation, and data-retention/deletion timeline (one season only, delete ≤30 days after Month 12 = 2027-10-08). Includes template data-processing agreements (DPAs), consent forms, privacy notices (translated), and audit checklists.

**Responsible Role Type:** GDPR Compliance Officer / Legal Counsel

**Primary Template:** EU GDPR Article 26 Joint Controller Agreement

**Secondary Template:** Data Processing Agreement (DPA) Template (Standard Contractual Clauses)

**Steps:**

- Commission GDPR specialist law firm (€15-30k, Month 0.5 = 2026-10-23) to: (1) advise on lawful basis (public task + consent? consent-only? public-task-only?), (2) draft joint-controller agreement and processor DPA templates, (3) assess DPIA scope.
- Obtain written legal opinion by Month 1 (2026-11-08) confirming GDPR compliance path; if public-task basis is used, draft or identify municipal ordinance authorizing heat-alert contact.
- If consent-based: co-design affirmative-consent form (2 pages max, translated into 4-6 languages) specifying: purpose (heat-season welfare checks), data types, retention (one season), withdrawal method, and non-consensual alternative (street outreach if refuses contact calls).
- DPIA scope: If health-data loop (EMS/ED counts) is joint-controlled, complete formal DPIA (€8-12k, 4-6 weeks) addressing re-identification risk, access controls, retention security; submit to health-system legal teams by Month 1.3 (2026-11-17).
- Partner DPAs: Finalize joint-controller or processor agreements with each of 4-6 partner organizations (housing associations, social services, NGOs, pharmacies, hospitals, EMS) by Month 1.5 (2026-11-23). Agreements must specify: lawful basis, data types, retention, audit rights, breach notification (48-hour reporting to DPO and AEPD if applicable), and liability.
- Partner staff briefing: Conduct 1-hour session for 50-80 partner staff (housing caretakers, social workers, NGO field staff, pharmacists, EMS dispatch) on GDPR obligations, consent procedures, and incident reporting; distribute one-page checklist and maintain attendance roster; repeat annually.
- Designate a Data Protection Officer (DPO) or data-protection contact (0.3-0.5 FTE municipal staff or external consultant); publish DPO contact details in all resident-facing materials (flyers, posters, heat-line scripts, center signage).
- Establish breach-incident log (accessible only to DPO and incident commander): log suspected unauthorized access, disclosure, or data loss; notify AEPD within 48 hours if breach confirmed (Article 33); notify affected residents within 72 hours (Article 34).
- Partner audit: Month 9 (2027-07-08), spot-check 2-3 partner organizations for GDPR compliance (consent records, privacy-notice logs, staff training attendance, any breach reports). Document findings and corrective actions.
- Data deletion: ≤30 days after Month 12 (2027-10-08), delete all personal data from partner records and city systems unless re-consented for Year 2. Retain only aggregated outcome data (EMS counts, ED visits, participation numbers, anonymized).
- Finalize framework by Month 1.5 (2026-11-23); audit partner compliance by Month 9 (2027-07-08).

**Approval Authorities:** GDPR Counsel, Data Protection Officer, partner organizations' legal representatives, Spanish Data Protection Agency (AEPD) if consultation needed

### 10. Language Access & Community Trust Strategy

**ID:** 5d50e810-c0f7-42c0-b1ee-5473bf460bc7

**Description:** Identifies top 4-6 non-official languages spoken in Castellón de la Plana (candidates: Arabic, Romanian, Portuguese), maps migrant neighborhoods, specifies community-ambassador recruitment (8-12 paid ambassadors, 10-15 h/week), translation and interpretation services, and co-design process with migrant organizations, faith leaders, and peer networks. Includes rapid-response misinformation-correction protocols (≤4-hour turnaround, community-messenger activation).

**Responsible Role Type:** Communications, Language Access and Trusted Messenger Coordinator

**Primary Template:** Multilingual Public Health Campaign Framework

**Secondary Template:** Community Co-Design Participation Protocol

**Steps:**

- Language mapping (Month 0 = 2026-10-08): Audit municipal integration office data and conduct 20-30 interviews in 5-7 high-migrant neighborhoods to confirm actual language mix and speaker populations; validate 'candidates: Arabic, Romanian, Portuguese' estimate; identify geographic clusters.
- Identify trusted community organizations (Month 0.5 = 2026-10-23): Contact migrant associations, faith centers (mosques, churches, synagogues), Roma organizations, homeless-service NGOs, women's peer groups, and language-specific support networks; schedule co-design workshops.
- Co-design workshops (Month 1 = 2026-11-08): Hold 5-7 structured dialogues asking: 'What offer would make you enroll in heat alerts?' and 'Who in your community would you trust to deliver it?' Participants: community leaders, residents, peer advocates. Document findings and integrate into enrollment strategy.
- Ambassador recruitment (Month 1.5-2 = 2026-11-23 to 2026-12-08): Hire 8-12 community ambassadors (not volunteers; paid €100-150/month, 10-15 h/week during alert season) from identified trusted organizations; bilingual, trained on heat-illness recognition and escalation protocols; provide consistent scripts and weekly briefings.
- Translation of core materials: Flyers, enrollment forms, cooling-center welcome scripts, fan-safety guidance, escalation hotline scripts. Professional translation into 4-6 languages by Month 1.5 (2026-11-23); budget ≈€50k including translation, back-translation QA, and document design.
- Interpretation services: Contract telephone interpretation (≥2 languages, ≥08:00-22:00 daily during alert season) and co-locate an interpreter at largest cooling center (≥1 shift/day) starting Month 6 (2027-04-08); budget ≈€30k.
- Misinformation-response infrastructure: Establish a weekly 'messenger feedback loop' where community ambassadors and faith leaders report misinformation heard in local networks (alcohol myths, fan misuse); communications lead and messenger team review within 4 hours, craft corrected message, and deploy counter-narrative via WhatsApp groups, local radio, and in-person messenger networks within same alert day.
- Community-messenger validation: Before pre-season campaign launch (Month 6 = 2027-04-08), hold a 'validation workshop' where peer ambassadors, faith leaders, and resident focus groups review all campaign materials (radio scripts, flyers, SMS, center signage) and certify cultural appropriateness and credibility; revise any flagged material.
- Finalize language-access framework by Month 2 (2026-12-08); validate with community groups by Month 6 (2027-04-08).

**Approval Authorities:** Communications Coordinator, community-organization leaders, translation-quality reviewer, incident commander

### 11. Public Communications & Misinformation-Response Plan

**ID:** 7daa271e-688a-4f41-81b1-7d9f9e2749e6

**Description:** Pre-season campaign strategy (messages, channels, timeline), alert-day communication protocols (public update by 11:00 on Level 2-3 days), trusted-messenger briefing materials (pharmacists, GPs, caretakers, faith leaders), translated materials (4-6 languages), myth-busting scripts (alcohol, fan misuse), and rapid-response escalation for misinformation (≤4-hour correction, community-messenger activation). Includes sample radio scripts, door-hanger designs, SMS templates, and center signage.

**Responsible Role Type:** Communications, Language Access and Trusted Messenger Coordinator

**Primary Template:** Municipal Public Health Campaign Framework

**Secondary Template:** WHO Misinformation Rapid-Response Playbook

**Steps:**

- Message development (Month 0.5-1 = 2026-10-23 to 2026-11-08): Conduct focus groups with ≥20 high-risk residents (65+, living alone, migrants) to test key messages: heat-alert recognition (forecast threshold), cooling-center locations/hours, transport booking (phone number), home-kit benefits, and fan-safety rules (directional-use-only). Identify and document prevalent misinformation (alcohol helps, fans are dangerous, centers are unsafe).
- Trusted-messenger briefing materials (Month 1.5-6 = 2026-11-23 to 2027-04-08): Prepare 2-hour briefing packs for pharmacists, GPs, practice managers, building caretakers, mosque/church leaders, with: heat-alert recognition, cooling-center and transport information, escalation protocols (when to refer to heat line), answers to common questions, and translated leave-behind flyers. Conduct 8-12 briefing sessions (1-2 hours each) across city; measure attendance and knowledge via post-briefing quiz.
- Pre-season campaign (Month 5.5-6.5 = 2027-03-23 to 2027-04-23): Launch multi-channel campaign including: 2-3 radio spots (15-30 sec, prime time), posters (A3, large-print, illustrated), door hangers (1-page, multilingual), SMS opt-in messages (at cooling centers, pharmacies), and flyers at high-traffic sites (markets, faith centers, community centers). Budget ≈€50-60k.
- Alert-day communication (Months 6.8-11.8 = 2027-04-08 to 2027-09-08): Public update issued by 11:00 on Level 2-3 alert days via municipal website, SMS (opt-in list), radio, and partner networks; repeat each morning of multi-day events. Message: alert level, expected conditions, cooling-center locations/hours open, transport booking (heat-line phone), and home-safety advice (hydration, fan rules, when to seek help).
- Misinformation response (ongoing during season): Communications lead monitors social media, local forums, and community reports (via ambassadors) for misinformation; upon detection, confers with messenger team within 2 hours, drafts corrected message and myth-busting talking points, and activates rapid deployment: messenger phone trees (WhatsApp, email), local radio spot, and in-person messenger delivery at markets/centers within 4 hours of detection.
- Myth-busting scripts (finalized Month 1 = 2026-11-08): Prepare evidence-based rebuttals for: alcohol (myth: 'alcohol cools you down'; fact: 'alcohol dehydrates; drink water instead'), fan misuse (myth: 'fans are dangerous'; fact: 'directional fans help; recirculating fans in sealed rooms don't'), and center trust (myth: 'centers are for sick people'; fact: 'centers are for everyone to cool off; no medical requirement').
- Finalize campaign by Month 6 (2027-04-08); launch by Month 6.5 (2027-04-23).

**Approval Authorities:** Communications Coordinator, incident commander, trusted-messenger representatives, public-health advisor

### 12. Full-System Drill Protocol & Exercise Script

**ID:** e27579ab-3489-45fb-a924-5c0b466d9fe3

**Description:** Detailed drill procedures for testing all operational elements (alert declaration, center activation, transport dispatch, outreach calls, EMS escalation, center stand-down) under realistic stress conditions. Specifies simulation scenarios (3+ consecutive hot-night events, 40+ simultaneous transport requests, 80%+ center occupancy, multi-day staff fatigue, misinformation reports), observer roles, timing, success criteria (80% center hours, 60% contact success, <45-min transport), and after-action reporting template.

**Responsible Role Type:** Operational Resilience & Surge Planning Lead / Project Manager

**Primary Template:** FEMA Full-Scale Exercise Protocol

**Secondary Template:** Incident-Command System (ICS) Exercise Evaluation Guide

**Steps:**

- Drill scope (finalized Month 2.5 = 2026-12-23): Simulate 3+ consecutive hot-night alert events; activate all 10 cooling centers; dispatch 40+ simultaneous transport requests (including ≥5 wheelchair users); conduct 200+ outreach contact attempts via partners; manage center surge to 80%+ occupancy; simulate 2-3 EMS escalations and 1-2 misinformation reports; run continuously for 48-72 hours to test staff fatigue.
- Scenario vignettes: (1) Alert declared at 12:00 Day 1; centers open 10:00-20:00; 15 transport requests 12:00-18:00; (2) Second day: two requests at 06:00 (before official hours); centers extend to 06:00-22:00; 20 transport requests 10:00-20:00; (3) Multi-day transition: staff absences (2 call-outs per site), dispatch queue backs up, center occupancy peaks at 85%; misinformation (radio rumor: 'alcohol cools faster') circulates; messenger team and comms lead must respond ≤4 hours.
- Participant roles: Incident commander (declares alerts, authorizes spending); operations lead (manages centers, transport, EMS coordination); communications lead (public updates, misinformation response); dispatch coordinator (assigns drivers, tracks wait times); center managers and staff (log occupancy, manage residents, escalate incidents); outreach leads (log contact attempts); observer team (independent, track metrics, flag issues, document decisions).
- Success criteria (Month 4 gates = 2027-02-08): ≥80% of planned center-hours delivered (target 2,620 hours planned; pass ≥2,096 hours actual); ≥60% contact success (≥180 of 300 attempts reached, enrolled, or escalated); mean transport pickup <45 min over ≥30 requests (including wheelchair users); all after-action items identified and assigned by end of drill day 3.
- Measurement & data collection: Observer team logs in real-time: alert decision time (vs. forecast trigger + 1 h); center openings/closings (vs. plan); occupancy by hour (photos, tally); transport request count, assignment time, pickup time, destination; outreach contact attempts and outcomes (log form per partner); escalations and EMS interactions; any incidents (assault, injury, system failure); staff fatigue indicators (post-shift surveys); misinformation reports and response time.
- After-action process: Drill concludes 17:00 Day 3; draft after-action report within 48 hours (Day 4-5) documenting: actual vs. planned performance, root causes of any deviations, identified corrective actions, and assigned owners. Corrective-action meeting Week 1 post-drill (Month 3.4 = 2027-01-20) to review draft, assign owners, and set completion dates. All actions must be closed by Month 3.9 (2027-02-04) before Month 4 (2027-02-08) gate decision.
- Finalize drill protocol (including maps, contact lists, scripts, observer checklist) by Month 2.5 (2026-12-23); conduct drill Month 3.2 (2027-01-14); after-action draft Month 3.5 (2027-01-23); actions closed Month 3.9 (2027-02-04); gate decision Month 4 (2027-02-08).

**Approval Authorities:** Incident commander, operations lead, observer team (independent or external evaluator), funder representative

### 13. Procurement & Contracting Strategy

**ID:** f6efa0b2-0d45-432c-88ef-6bd643d1bbb1

**Description:** Specifies procurement routes (framework call-offs, below-threshold purchasing, simplified tenders) for four product categories: cooling kits (€800k), transport retainer (€80k), handyperson services (€150k), and refuge fit-out (€100k). Includes specifications, supplier-qualification criteria, delivery timelines, backup-supplier agreements, price-lock and expedite-fee authorization, and audit-trail documentation procedures.

**Responsible Role Type:** Municipal Procurement Officer / Contract Law Specialist

**Primary Template:** EU Public Procurement Directive Guidance (2014/24/EU)

**Secondary Template:** Spanish Public Procurement Regulations (LCSP)

**Steps:**

- Procurement planning (Month 0 = 2026-10-08): Define €3.5M budget by category; identify existing municipal framework agreements (utilities, services, maintenance) suitable for call-offs; confirm legal thresholds (Spain: €50k EU below-threshold, varying by region for services/supplies).
- Specifications (by Month 0.8 = 2026-11-01): Issue detailed RFQs for (1) cooling kits: shading, reflective blinds, fans, thermometers, specs; (2) transport: vehicle type, capacity, response-time SLA, insurance; (3) handyperson: electrician/installer qualifications, training requirements; (4) fit-out: accessibility remediation, fit-out standards.
- Supplier identification & pre-qualification (Month 1 = 2026-11-08): Request quotes from ≥3 primary suppliers and ≥2 backup suppliers per category; evaluate on price, lead time, quality, and experience; pre-qualify backups with written 'emergency activation' agreements specifying ≤7-day mobilization and expedite premium (≤10% price increase).
- Procurement route decision (Month 1 = 2026-11-08): For each category, determine lowest-risk legal route: (1) kits ≤€100k/call-off = framework call-off if framework exists (audit-safe); (2) kits >€100k per batch = simplified below-threshold tender (€50-200k threshold band, written documentation, 2-3 quotes); (3) transport retainer ≤€80k = framework or simplified tender; (4) handyperson ≤€150k total = framework or simplified tender. Document route choice and legal justification.
- Order placement (Month 1.2-2 = 2026-11-14 to 2026-12-08): Place first-tranche kit orders (30-40%) by Month 1.2 (2026-11-14) with primary supplier; include SLA for February 2027 delivery. Place transport retainer contract by Month 1.2 (2026-11-14) with 48-hour cancellation clause. Confirm all tranche-1 orders placed by Month 2 (2026-12-08) readiness gate.
- Contract management: (1) Delivery tracking (log actual receipt date vs. planned); (2) quality assurance (inspect first 5% of kit shipment for defects); (3) invoice & payment (audit invoice against SLA, delivery confirmation, quality check); (4) change orders (scope/timeline changes require written approval and amendment; document reason, cost, and incident commander sign-off).
- Audit readiness: Maintain complete procurement file per order including: RFQ and responses, evaluation criteria and scoring, selected-supplier justification, contract document (signed), delivery record, quality-assurance checklist, payment authorization, and any change orders. File must be defense-able to municipal audit and EU auditors.
- Backup activation trigger: If any supplier misses committed delivery date by >1 week, immediately (≤24 hours) notify backup supplier, confirm mobilization, and place emergency order. Authorize expedite-fee payment (up to 10% premium, approximately €80-120k for kits; €8-12k for transport/services) without additional approval.
- Finalize procurement strategy by Month 0.8 (2026-11-01); execute first orders by Month 1.2 (2026-11-14); confirm all orders by Month 2 (2026-12-08).

**Approval Authorities:** Municipal Procurement Officer, CFO/Budget Director, incident commander (for budget authority), legal counsel (for contract terms)

### 14. Health Data Loop & Escalation Protocol

**ID:** f775c8ef-58c7-4173-8176-2bf416ed8f05

**Description:** Specifies MOU with hospitals, EMS, and primary-care providers for daily aggregate heat-related call/ED-visit counts (ICD-10 codes T67.0-T67.9 or clinician judgment of heat-related), delivery by 10:00 a.m. next day, escalation thresholds (notify commander at ≥1.5× historical average, mutual-aid review at ≥2×), data-protection terms (no identifiable records), retention (12 months max, then delete), and data-governance roles. Includes data-validation pilot (2 weeks, Month 1.8 = 2026-12-02) and shared dashboard (secure spreadsheet or low-code platform).

**Responsible Role Type:** Public Health Coordinator / Health Data Manager

**Primary Template:** Health Data Sharing MOU (NHS/GDPR compliant)

**Secondary Template:** Data Protection Impact Assessment (DPIA) Template for Health Data

**Steps:**

- MOU negotiation (Month 1 = 2026-11-08): Meet with hospital legal, EMS operations, and primary-care leadership to discuss: heat-related call/visit data sharing, coding standards, daily reporting SLA, data-protection controls, and joint-controller vs. recipient relationship. Clarify definition of 'heat-related' (explicit ICD codes? clinician coding? proxy indicators like high-temp-day ED surge?).
- Coding agreement: Document the agreed heat-related coding standard in writing (e.g., 'ICD-10 T67.0-T67.9 plus clinician indication of heat-related on ED chart'); confirm this coding standard across all three organizations (hospital, EMS, primary care) to ensure consistency.
- DPIA for health-data loop (Month 1 = 2026-11-08, €8-12k, 4-6 weeks): Commission DPIA addressing: (1) purpose and scope (daily aggregate counts of heat-related EMS calls and ED visits); (2) data minimization (counts only, no identifiable patient records); (3) re-identification risk and controls (aggregation level, access controls); (4) retention and deletion (12 months, then delete); (5) recipient security and liability (city holds read-only access, cannot share with third parties). Deliver DPIA to health-system legal teams by Month 1.3 (2026-11-17) for review before MOU finalization.
- MOU terms: Final signed MOU by Month 1 (2026-11-08) must specify: (1) daily aggregate counts of EMS heat-related calls and ED visits by 10:00 a.m. next day (weekly fallback if daily is infeasible); (2) data format (e.g., 'date, call count, ED visit count, call type breakdown' = heart attack, fall, dehydration, documented heat illness); (3) no identifiable patient data; (4) city is recipient only (not joint controller), cannot re-identify individuals or contact patients; (5) 12-month retention, then delete; (6) escalation triggers (commander notification if volume ≥1.5× historical average; mutual-aid review if ≥2×); (7) breach reporting to AEPD within 48 hours if breach occurs at health provider; (8) annual review and renewal.
- Data-validation pilot (Month 1.8 = 2026-12-02 to Month 1.95 = 2026-12-07, 2 weeks): Test data feeds from all three sources; identify any reporting delays, coding inconsistencies, or missing days; document any issues and corrective actions; confirm data quality by Month 2 (2026-12-08).
- Shared dashboard: Deploy a secure spreadsheet (or low-code BI platform) accessible to incident commander, health coordinator, dispatch supervisor, and operations lead only; display daily counts, trend (vs. prior weeks/years), and escalation status (normal, ≥1.5×, ≥2×). Update each morning by 10:30 a.m. during alert season (Months 6.8-11.8 = 2027-04-08 to 2027-09-08).
- Escalation decision tree: If count reaches ≥1.5× historical average, incident commander is notified; if confirmed by second data source (e.g., ambulance logs), consider increasing alert level or center hours; if ≥2×, consider mutual-aid activation and hospital pre-notification of potential surge.
- Finalize MOU by Month 1 (2026-11-08); complete DPIA by Month 1.3 (2026-11-17); validate data feeds by Month 2 (2026-12-08); launch dashboard by Month 5 (2027-03-08).

**Approval Authorities:** Health Coordinator, hospital legal counsel, EMS director, primary-care representative, Data Protection Officer, incident commander

### 15. Staffing Plan & Fatigue Management Protocol

**ID:** aae7b2c5-faa4-4698-984d-6f2ca59cd8b9

**Description:** Specifies 43 FTE at peak (cooling centers 18, outreach 6, dispatch 3, phone line 3, handypersons 10, coordination 2-3), hiring timeline (40% Month 3 = 2027-01-08, 40% Month 4 = 2027-02-08, 20% Month 5 = 2027-03-08), shift rotation rules (≤3-4 consecutive alert days, 1-2 mandatory rest days), occupational-health support (pre-season fitness screening, post-incident counseling, fatigue surveys), fatigue-management training, cross-training (staff able to backfill absent colleagues), and contingency staffing (20-30% reserve capacity).

**Responsible Role Type:** Project Manager / HR Coordinator

**Primary Template:** Municipal Emergency Services Staffing Rota Template

**Secondary Template:** Occupational Health Fatigue Management Protocol

**Steps:**

- Staffing structure (Month 0 = 2026-10-08): Map roles and FTE: (1) cooling centers: 1-2 staff per site × 10 sites, staggered shifts (10:00-20:00 or 24:00 at anchor sites); (2) outreach: 1 lead + 5 field staff; (3) dispatch: 2 active + 1 backup; (4) phone line: 2 active + 1 backup; (5) handyperson: 10 (Months 4-7 = 2027-02-08 to 2027-05-08 only); (6) coordination: 1 PMO lead + 2 supporting roles.
- Hiring timeline: (1) Immediate (Month 0 = 2026-10-08): launch recruitment for HR coordinator (0.5 FTE, Months 0-6 = 2026-10-08 to 2027-04-08), volunteer coordinator (0.5 FTE, Months 0-12 = 2026-10-08 to 2027-10-08), and communications lead (1 FTE); (2) Month 3 (2027-01-08): hire 40% of permanent staff (center managers, outreach lead, dispatch supervisor, phone-line manager); (3) Month 4 (2027-02-08): hire 40% more (center staff, outreach workers, dispatchers); (4) Month 5 (2027-03-08): hire final 20% and handypersons. All in post by Month 6.7 (2027-04-29).
- Shift rotation: Cooling-center and dispatch staff work ≤3-4 consecutive alert days (e.g., Tuesday-Thursday alert, stand-down Friday-Sunday, back on-call Monday). After a multi-day event (5+ days), mandatory 2-day break. Rota must enforce this via a shared calendar; managers validate compliance weekly.
- Occupational health support (by Month 3 = 2027-01-08): (1) Partnership with municipal occupational-health clinic or external occupational-health nurse (0.25 FTE); (2) Pre-season fitness screening and fatigue baseline for all staff (May); (3) Mid-season fatigue survey (July) measuring: hours worked, sleep quality, stress level, work satisfaction; (4) Post-incident support: if staff encounter assault, severe distress, or heat-illness case, occupational health offers same-day or next-day counseling (free, confidential, up to 6 sessions); (5) Peer-support groups: monthly 1-hour informal group meetings (June, July, August) where staff can discuss experiences and stress; (6) Fatigue-management training (2 hours) covering: sleep hygiene, stress recognition, when to request leave, peer support resources.
- Cross-training (by Month 2 = 2026-12-08): Designate backup roles for critical positions: (1) center managers can assist with dispatch coordination if dispatcher absent; (2) outreach lead can staff the phone line if operator absent; (3) dispatch supervisor can manage center occupancy calls if center manager absent. Conduct 1-hour training for each cross-trained person; test in the drill.
- Contingency staffing (by Month 2 = 2026-12-08): Recruit and retain 20-30% reserve capacity to absorb absences: (1) hire 20% more part-time center assistants than minimum (e.g., 22 instead of 18, on-call hourly); (2) contract with a municipal or external call-center service for phone-line surge (extra operators available ≤24 hours notice); (3) target 50-60 volunteer drivers to net 40-50 active, creating a 20-30% volunteer reserve; (4) identify backup handypersons or contractor relationships for installer shortfall.
- Finalize staffing plan by Month 1 (2026-11-08); conduct hiring cohorts and training by Month 6.7 (2027-04-29); begin occupational-health partnership by Month 3 (2027-01-08).

**Approval Authorities:** Project Manager, HR Coordinator, occupational health, incident commander, union representative (if applicable)

### 16. Risk Register & Mitigation Action Tracker

**ID:** 990d141e-0393-4ebf-b1d0-367afc041efc

**Description:** Comprehensive risk log (25+ risks identified) with likelihood, severity, owner, mitigation action, trigger threshold, and status. Risks include cool-season gates, supply-chain compression, volunteer recruitment, GDPR challenge, partner withdrawal, staff fatigue, misinformation, political disruption, and budget overrun. Includes risk-review cadence (monthly), escalation criteria (>2 weeks behind schedule, >€50k budget draw, policy/legal challenge), and go/no-go decision framework at Months 2, 3, 4, 6 (2026-12-08, 2027-01-08, 2027-02-08, 2027-04-08).

**Responsible Role Type:** Project Manager / PMO Lead

**Primary Template:** Project Risk Management Framework (PMI PMBOK)

**Secondary Template:** Municipal Risk Register Template

**Steps:**

- Risk identification (Month 0 = 2026-10-08): Conduct risk workshop with incident commander, operations lead, communications lead, partner liaison, and legal counsel; brainstorm risks by category: gate/schedule, budget, procurement/supply chain, staffing, GDPR/legal, health/safety, reputational, partnerships, political/organizational.
- Risk assessment (Month 0.5 = 2026-10-23): For each risk, estimate: (1) likelihood (low/medium/high), (2) severity (low/medium/high), (3) risk score = likelihood × severity; prioritize high-score risks (high-high, high-medium, medium-high). Assign an owner (e.g., procurement lead for supply chain, HR coordinator for staffing, legal counsel for GDPR).
- Mitigation planning: For top 12-15 risks, co-design mitigation actions and assign owners with a due date. Specify: (1) preventive actions (proactive steps to reduce likelihood); (2) contingency plans (what to do if risk materializes); (3) trigger threshold (metric that signals the risk is occurring); (4) escalation path (who decides if risk requires decision or approval).
- Risk tracking (monthly): PMO maintains shared risk register (spreadsheet or low-code tracker) with columns: risk ID, description, category, owner, likelihood, severity, mitigation action, due date, current status (green/yellow/red), and last-reviewed date. Update during weekly coordination meetings. Escalate yellow/red items to incident commander and steering committee.
- Risk review cadence (monthly at steering committee, Months 0-6 = 2026-10-08 to 2027-04-08): Review top 12 risks; update status; confirm mitigation actions are on track; escalate any slippage >1 week. Conduct deeper risk review (all 25 risks, 2-hour session) at Months 2, 3, 4 (2026-12-08, 2027-01-08, 2027-02-08).
- Escalation criteria (trigger steering committee re-scope or go/no-go decision): (1) Any critical item (gate risk, legal challenge, >€50k budget draw) turns red; (2) ≥3 action items slip >2 weeks; (3) funder raises concern about gates or funding; (4) political or leadership transition occurs; (5) major incident (assault, data breach, service failure) occurs.
- Go/no-go decision framework: At Months 2 (2026-12-08), 3 (2027-01-08), and 4 (2027-02-08), incident commander and steering committee review risk register and decide: (1) continue as planned (green); (2) continue with mitigation adjustments (yellow); (3) escalate to funder and pause pending decision (red). Month 4 (2027-02-08) gate decision is conditional on risk register status: if ≥5 red items unresolved, gates cannot be certified as passed.
- Finalize risk framework by Month 0.5 (2026-10-23); begin tracking Month 1 (2026-11-08); review monthly Months 0-12 (2026-10-08 to 2027-10-08).

**Approval Authorities:** Project Manager, incident commander, steering committee, funder (for escalation decisions)

### 17. Heat Response Playbook & Standard Operating Procedures

**ID:** 2bf3380e-e2e5-4218-9686-8f87908043a9

**Description:** Comprehensive reference manual for Year 1 operations and replication to other EU cities. Includes decision rationale for each of 12 design levers, SOPs and checklists for each role (alert declaration, center opening, transport dispatch, outreach, escalation), scripts and templates (consent forms, communication messages, escalation checklists), unit-cost breakdown (€/center-hour, €/transport trip, €/enrollee), staffing templates, procurement lists, partner MOUs, and lessons learned. Specifies local adaptations needed per city (housing stock, climate, demographics, migrant profile).

**Responsible Role Type:** Project Manager / Playbook & Evaluation Lead

**Primary Template:** World Bank Project Implementation Manual

**Secondary Template:** UCLG Global Cities Covenant on Climate (playbook format)

**Steps:**

- Playbook structure (draft Months 8-9 = 2027-06-08 to 2027-07-08): Organize into 12 chapters matching the 12 decision levers in 'strategic_decisions.md': each chapter includes (1) decision statement (e.g., 'Alert Trigger Ladder'), (2) rationale and alternatives considered, (3) trade-off analysis (what was gained, what was sacrificed), (4) implementation steps and timeline, (5) key deliverables (documents, MOUs, contracts), (6) unit costs (€/unit), (7) staffing requirements, (8) role descriptions and contact templates, (9) success metrics and gates, (10) lessons learned post-pilot.
- SOPs and checklists: Include step-by-step procedures for: (1) alert declaration (when to declare, who decides, communication sequence), (2) cooling-center opening (check list: water, toilets, quiet room, first-aid kit, AED, staffing, occupancy log), (3) transport dispatch (intake form, driver assignment, ETA confirmation, wait-time tracking), (4) outreach contact (script, consent procedure, escalation rules), (5) EMS/escalation (decision tree for heat-illness severity, phone vs. 112), (6) stand-down (criteria, communication, de-briefing).
- Templates and scripts: Include editable/fillable versions of: (1) heat-alert declaration template, (2) cooling-center occupancy log, (3) transport request form, (4) outreach contact log, (5) consent form (translated into 4-6 languages), (6) public-alert message template, (7) trusted-messenger briefing script, (8) misinformation-correction fact sheet.
- Cost model (Month 10-11 = 2027-08-08 to 2027-09-08): Break down €3.5M by line item and calculate unit costs for replication: (1) €/center-hour (target ≈€324 fully loaded, including staff, utilities, security); (2) €/transport trip (≈€15-20 volunteer, ≈€25-35 taxi); (3) €/enrollee (≈€150 total program cost for 3,000 enrolled, includes outreach + phone line + referral overhead); (4) €/home kit (€250-300 hardware + €50 installation). Specify scaling assumptions: how costs change if city size, climate, or transport distance changes. Document sensitivity: what happens if volunteer recruitment is 50% vs. 100%?
- Staffing templates: Provide example job descriptions for: (1) incident commander (qualifications, authority, time commitment), (2) cooling-center manager (site-based coordinator), (3) outreach worker (field staff), (4) dispatch coordinator (volunteer and taxi management), (5) phone-line operator (customer service + escalation), (6) handyperson/installer (safety-certified). Include hiring timelines, salary benchmarks, and contingency ratios.
- Procurement list: Itemize all suppliers needed: (1) cooling kits (manufacturers, lead times, unit costs), (2) handyperson services (local contractors, insurance requirements), (3) transport (taxi operators, volunteer insurance), (4) cooling-center fit-out (water/sanitation suppliers, AED vendors), (5) communications (translation services, radio spots, design). Include contact information and contract templates.
- Partner MOUs: Provide template MOUs for: (1) cooling-center facility use, (2) intermediary-held-list outreach (housing associations, social services, NGOs, pharmacies), (3) health-data loop (hospital, EMS, primary care), (4) taxi/transport retainer, (5) volunteer driver program, (6) language ambassador contracts, (7) data-processing agreements (GDPR-compliant).
- Local adaptation guidance: Specify what aspects are replicable vs. context-dependent: (1) replicable: alert trigger methodology, cooling-center SOP, transport dispatch, outreach protocol, fatigue management; (2) context-dependent: language mix (varies by city migration pattern), housing stock type (affects kit design and target population), climate and historical heat thresholds (needs local calibration), partner landscape (varies by local NGO/health infrastructure). Provide checklist for peer cities: 'You will need to adapt: [item list].'
- Lessons learned chapter (draft Month 11 = 2027-09-08, finalized Month 12 = 2027-10-08): Document what worked, what didn't, what would change: (1) volunteer recruitment and retention challenges; (2) intermediary-list reach and coverage gaps; (3) gate measurement validity (drill vs. real events); (4) staff fatigue during multi-day events; (5) misinformation containment (success/failure); (6) partner engagement effectiveness; (7) budget allocation and contingency adequacy; (8) alert-threshold accuracy (false alarms vs. missed events); (9) equity outcomes (did the program reach the intended high-risk groups?); (10) recommendations for Year 2 and scaling.
- Finalize playbook (draft by Month 11 = 2027-09-08, final by Month 12 = 2027-10-08); conduct peer-city review at Month 11 (2027-09-08).

**Approval Authorities:** Project Manager, incident commander, evaluation partner, funder, peer-city representative (external validation)

### 18. Evaluation & Attribution Analysis Framework

**ID:** b7781852-d28d-4b4a-b1d9-126a6beeff9f

**Description:** Pre-specified evaluation protocol (registered, if possible, with university partner) defining comparison design (pilot vs. matched non-pilot districts and prior years), outcome measures (heat-related EMS calls, ED visits, excess mortality), temperature adjustment method, baseline data requirements, and explicit limitations/confidence intervals. Includes data-validation checklist, coding standards (ICD-10 heat codes), and statistical analysis plan. No mortality-reduction target is set as a gate; instead, the framework describes what reductions are plausible to detect given small-area sample sizes.

**Responsible Role Type:** Data and Evaluation Coordinator / Health Epidemiologist

**Primary Template:** World Health Organization Evaluation Framework (WHOQOL model)

**Secondary Template:** Pre-Registered Protocol Template (Open Science Framework)

**Steps:**

- Evaluation scope (Month 1 = 2026-11-08): Define outcome questions: (1) Did heat-related EMS calls decrease during alert days in pilot areas vs. non-pilot? (2) Did ED visits for heat-related complaints decline? (3) Is excess mortality attributable to the program? (4) Were operational KPIs met (center hours, transport time, outreach contact)?
- Baseline data (Month 1 = 2026-11-08): Request 3-year historical data from hospital, EMS, primary care: (1) heat-related ICD-10 codes (T67.0-T67.9); (2) daily call/visit counts by date and type; (3) patient demographics (age, sex, postal code, if available for aggregate analysis); (4) temperature data (daily high/low, historical Castellón 2015-2025). Conduct data-quality audit by Month 2 (2026-12-08): completeness (% of records with heat coding), consistency across services, temporal patterns (peaks align with known heat events).
- Comparison group selection (Month 2-3 = 2026-12-08 to 2027-01-08): Identify matched non-pilot districts or similar cities (same climate, housing, demographics) for parallel trend analysis. Use propensity-score matching on baseline characteristics (age, housing type, prior heat-related call rates) to reduce selection bias.
- Temperature adjustment (Month 3 = 2027-01-08): Model the relationship between temperature and heat-related calls/visits using prior years (e.g., Poisson regression of daily counts on daily temperature, lagged effects). This baseline relationship allows comparison of 'expected' calls at observed temperatures to 'actual' calls during the program; the difference is attributable to the program (or lack thereof).
- Statistical analysis plan (Month 2.5 = 2026-12-23): Pre-specify analysis: (1) primary outcome = percent change in heat-related calls/visits on Level 2-3 alert days (pilot vs. control); (2) subgroup analyses = by age (65+), housing type (top-floor, social housing), neighborhood deprivation index; (3) sensitivity analyses = alternative temperature-adjustment models, different lags; (4) confidence intervals and significance testing (95% CI, two-tailed p<0.05).
- Data governance (Months 0-4 = 2026-10-08 to 2027-02-08): Establish university or independent partner as evaluation lead under a data-processing agreement; partner holds all identifiable data (if any) and provides only aggregated counts to the city. City never receives patient-level data. Regular data-quality meetings (monthly) to discuss coding consistency, completeness, and any data-access delays.
- Baseline report (by Month 4 = 2027-02-08): Publish validated baseline (3-year heat-related call/ED visit counts, temperature-adjusted expectations, comparison-group characteristics, assumptions stated). This baseline must be established before season starts (Months 6-11 = 2027-04-08 to 2027-09-08) so that mid-season data can be compared to expectation.
- Mid-season review (Month 8 = 2027-06-08): If June-July heat events occur, conduct rapid analysis (within 2 weeks of heat wave end) comparing observed to expected calls; publish preliminary findings and any program-adjustment recommendations to incident command.
- Final evaluation report (by Month 12 = 2027-10-08): Comprehensive analysis of heat-related EMS, ED, and excess mortality outcomes; temperature-adjusted comparisons; subgroup findings; operational KPI results (center hours, transport times, outreach contact). Include explicit statements of: (1) what the program likely achieved (harm reduction attribution), (2) what is uncertain (small-area noise, alternative explanations), (3) confidence intervals and limitations (e.g., 'a 10-20% reduction in heat calls is plausible but not statistically certain with 1-year data from a mid-sized city'). Avoid false precision.
- Finalize framework (Month 1 = 2026-11-08); pre-register protocol (Month 2 = 2026-12-08); publish baseline report (Month 4 = 2027-02-08); deliver final evaluation (Month 12 = 2027-10-08).

**Approval Authorities:** Evaluation lead (university partner), incident commander, funder, AEPD (if sensitive data access required)

### 19. Year-2 Roadmap & Scaling Cost Model

**ID:** 134501d5-891f-436e-8aca-48529598e139

**Description:** Strategic recommendations for continuation or expansion of the program beyond Month 12 (2027-10-08). Includes: (1) which program elements to expand city-wide vs. de-prioritize; (2) estimated Year-2 cost (≈€2.3M/year for same footprint; adjust for expansion); (3) funding sources to be identified or secured; (4) staffing and capacity scaling; (5) replication checklist for peer EU cities; (6) go/no-go decision criteria for each component (refuges, transport, outreach, kits, communications).

**Responsible Role Type:** Project Manager / Policy and Learning Lead

**Primary Template:** Municipal Multi-Year Strategic Plan Template

**Secondary Template:** Cost Scaling Model (per-unit cost × scale)

**Steps:**

- Year-1 lessons synthesis (Months 9-10 = 2027-07-08 to 2027-08-08): Collect feedback from all stakeholders (staff, volunteers, partners, residents, funder) via interviews and focus groups; analyze operational data (center utilization, transport demand, outreach success, budgets spend); identify what worked vs. what needs improvement.
- Go/no-go decisions per component (Month 10 = 2027-08-08): For each of 12 program elements, make a recommendation: (1) EXPAND (e.g., scale refuges from 10 to 15 sites, increase outreach to 8,000 residents); (2) CONTINUE (maintain same footprint and quality); (3) MODIFY (change design based on Year-1 learning, e.g., shift from volunteer-only to taxi-supplemented transport); (4) DISCONTINUE (sunset component if ineffective or unsustainable). Provide evidence (utilization, cost-effectiveness, equity outcomes, staff/partner sustainability) for each decision.
- Scaling cost model (Month 10-11 = 2027-08-08 to 2027-09-08): Calculate per-unit costs from Year-1 actual: (1) €/center-hour (fully loaded with staff, utilities, overhead); (2) €/transport trip (volunteer vs. taxi; cost per km); (3) €/enrollee reached; (4) €/home kit installed. Use these unit costs to model Year-2 budget scenarios: (a) same footprint (10 refuges, 3,000 enrolled, 2,000 kits) = €2.3M estimate; (b) expanded (15 refuges, 5,000 enrolled, 3,000 kits) = €3.2M estimate; (c) scaled-back (6 refuges, 1,500 enrolled, 1,000 kits) = €1.5M estimate. Specify assumptions (wage inflation, supplier price changes, volunteer availability).
- Funding sources (Month 9-10 = 2027-07-08 to 2027-08-08): Identify potential sources for Year-2 (≈€2.3M): (1) municipal budget appropriation (request city council approval by Month 11 = 2027-09-08); (2) EU climate or health grants (search, apply by Month 9 = 2027-07-08, decision typically by Month 6-9 = 2027-04-08 to 2027-07-08 months later, i.e., beyond project end); (3) regional health authority co-financing (negotiate by Month 10 = 2027-08-08); (4) phased commitment from current funder (request multi-year agreement by Month 11 = 2027-09-08). If no source is identified by Month 10 (2027-08-08), recommend priority cuts and reduced-scope option.
- Staffing & capacity scaling (Month 10 = 2027-08-08): Model workforce implications of each go/no-go decision. For expansion (15 refuges): add 5-8 FTE permanent center staff, 2-3 FTE outreach. For continuance (10 refuges): convert seasonal/temporary roles to stable part-time permanent positions to improve retention. For scale-back (6 refuges): consolidate roles, some staff reduction, higher utilization per site.
- Replication checklist for peer EU cities (Month 11 = 2027-09-08): Create a 2-page checklist: 'Do you have: (1) local meteorological-service partnership and alert-trigger agreement? (2) ≥6 suitable indoor sites (libraries, community centers)? (3) housing association and NGO partnerships for outreach? (4) legal/GDPR advice on consent and intermediary data-sharing? (5) estimated target population (census data)? (6) municipal budget authority to commit €2-3M/year? (7) incident-command authority and city leadership buy-in?' For each 'no', add a lead-time buffer (e.g., +4 weeks for GDPR review, +8 weeks for facility contracting).
- Playbook dissemination (Month 12 = 2027-10-08): Publish playbook to a public repository (municipal website, EU-platform for climate cities, UCLG network); offer technical-assistance sessions for peer cities (2-3 cities, 2-3 months lead time each). Create a 'rapid-start' summary (4-page brief) for cities considering replication.
- Finalize Year-2 roadmap (Month 11 = 2027-09-08); publish roadmap and cost model (Month 12 = 2027-10-08).

**Approval Authorities:** Incident commander, steering committee, municipal leadership (mayor's office), funder, city council (if budget approval needed)

### 20. Communication Plan & Public Engagement Strategy

**ID:** 2c94005e-cd62-43a3-9ec5-8c03051f556a

**Description:** Specifies channels, timing, and key messages for communicating with residents, partners, media, and funder throughout the 12-month cycle. Includes: pre-season messaging (alerts, cooling-center info, transport booking), alert-day communications (public updates, trusted-messenger activation), post-event review communications, and annual reporting to funder and public.

**Responsible Role Type:** Communications, Language Access and Trusted Messenger Coordinator

**Primary Template:** Municipal Communications & Public Engagement Plan Template

**Steps:**

- Stakeholder map (Month 0.5 = 2026-10-23): Identify audiences (residents 65+, migrants, unhoused, families, employers, healthcare workers, faith leaders, media, funder, partner organizations) and their information needs (how to enroll, when alert occurs, what to do, how to access help).
- Channel strategy (by Month 1 = 2026-11-08): Select appropriate channels per audience: (1) residents 65+ (radio, pharmacy posters, door hangers, faith leaders); (2) migrants (community ambassadors, translated flyers, mobile outreach); (3) unhoused (NGO outreach, day-center notices, street flyers); (4) employers (email, local business chambers); (5) healthcare workers (MOU briefings, email alerts); (6) media (press releases, interviews); (7) funder (monthly reports, gate reviews).
- Pre-season communications (April-May = Months 6-7 = 2027-04-08 to 2027-05-08): Launch campaign (radio spots, posters, flyers, door hangers, SMS opt-in, trusted-messenger briefings); key messages: heat-alert recognition, cooling-center locations/hours, transport booking, home-safety advice (fans, hydration). Tone: informative, accessible, culturally appropriate. Measure: reach (# of impressions), uptake (# of enrollments, # of SMS sign-ups).
- Alert-day communications (May-September = Months 6.8-11.8 = 2027-04-08 to 2027-09-08): Public update issued by 11:00 on Level 2-3 days via municipal website, SMS, radio, partner networks. Message: alert level, expected temperatures, cooling-center hours (open/closed), transport booking number, home-safety reminders. Repeat each morning of multi-day event. Tone: reassuring, action-oriented. For Level 1 (advisory): partner email/SMS only, no public alert (to avoid alert fatigue).
- Misinformation response (ongoing, ≤4-hour turnaround): Communications lead monitors social media and community reports; upon misinformation detection (e.g., 'alcohol cools you down'), confers with messenger team, drafts corrected fact sheet and talking points, and activates rapid deployment via community messengers, local radio, and WhatsApp groups within 4 hours.
- Post-event communications (within 48 hours of stand-down): Brief statement from incident commander thanking residents for compliance, reporting on service utilization (# of people cooled, # of transport trips, any escalations), and early assessment of program performance. Tone: grateful, evidence-based.
- Annual reporting (Month 12 = 2027-10-08): Publish full evaluation report (EMS/ED data, attribution, operational results, lessons learned) to funder and public. Public summary (2-3 pages, plain language) for residents and media. Press release highlighting impact and Year-2 plans. Tone: honest about both successes and limitations; avoid overclaiming.
- Finalize plan by Month 1 (2026-11-08); begin execution by Month 6 (2027-04-08).

**Approval Authorities:** Communications Coordinator, incident commander, media relations officer, funder

### 21. Volunteer Driver Insurance & Safeguarding Framework

**ID:** dc31a3e8-2ea3-4023-8c82-cccac446ad99

**Description:** Specifies insurance requirements for volunteer drivers (personal vehicle liability, accident coverage, assault/threat trauma protection), safeguarding vetting procedures (background checks, reference verification, character assessment), incident-reporting protocols (assault, threat, vehicle accident, safeguarding concern), and occupational-health access (counseling within 24 hours post-incident). Includes insurance templates or vendor contacts and incident-response checklist.

**Responsible Role Type:** Transport Dispatch and Mobility Coordinator / Safeguarding Lead

**Primary Template:** Volunteer Driver Insurance & Safety Protocol (Red Cross/Charity Commission template)

**Steps:**

- Consult with municipal risk management and insurance broker to clarify: (1) whether municipal policy covers volunteers using personal vehicles, or separate volunteer insurance is required; (2) coverage limits for assault/threat-related trauma; (3) cost per volunteer or per fleet.
- Obtain sample insurance policies or broker recommendations for volunteer-driver liability and personal-accident coverage (€10-20/person/year typical cost in Spain).
- Co-design with municipal HR and police department: background-check procedures (police records check, 14-day turnaround), safeguarding-concern indicators (domestic violence history, prior assault, relevant criminal record), and vetting decision criteria.
- Draft incident-reporting form (1 page): date, time, location, incident type (assault, threat, accident, concerning behavior), people involved, immediate action taken, injuries/damage, witness names/contact.
- Specify immediate response (within 2 hours): supervisor contact, incident logging, occupational-health referral offer, follow-up call within 24 hours.
- Create rapid-access resource list: police 091 number, occupational health contact, counseling referral, legal advice hotline.
- Finalize by Month 1 (2026-11-08); brief all volunteers by Month 2 (2026-12-08).

**Approval Authorities:** Transport Dispatch Coordinator, Safeguarding Lead, municipal insurance broker, HR department

### 22. Accessibility Audit Tool & Remediation Checklist

**ID:** 095a16d5-a66b-4b6d-b419-6ad552b81a64

**Description:** Detailed checklist for auditing cooling-center sites and home installations for accessibility compliance (wheelchair ramps, accessible toilets, water fountains, quiet/low-stimulation rooms, signage, parking, accessible transportation, emergency egress). Specifies remediation priorities (what must be fixed before opening vs. what can be deferred), cost estimation, and site categorization (fully accessible, minor remediation, unsuitable).

**Responsible Role Type:** Cooling Center Network Manager

**Primary Template:** EN 17210 Accessibility Standard Checklist

**Secondary Template:** ADA Accessibility Guidelines (adapted for EU context)

**Steps:**

- Create 2-page checklist covering: (1) exterior access (parking, pathway, ramp slope/width, door handles); (2) interior (corridors width, elevator if multi-floor, water fountain height); (3) toilets (accessible stall, grab bars, hand-wash height); (4) quiet room (low noise, dim lighting, seating); (5) signage (large print, pictograms, Braille if feasible); (6) emergency exit (no barriers, clear path, evacuation chair if stairs-only exit); (7) staff awareness (trained to assist mobility-limited residents, first-aid trained).
- Assign scoring: complete yes/no for each item; calculate % compliance; sites <80% compliance = major remediation needed or unsuitable.
- Specify remediation priority: (A) must fix before opening (exterior access, emergency exit, accessible toilet); (B) should fix before opening (signage, water, staff training); (C) can defer to later (aesthetics, non-essential features).
- Estimate costs (Spain typical): exterior ramp €2-5k, toilet modification €3-8k, signage €1-2k, staff training €1k; total per site likely €5-15k.
- Test checklist at 1-2 pilot sites to validate realism and refine language; publish final version by Month 1 (2026-11-08).

**Approval Authorities:** Cooling Center Network Manager, disability-access officer, venue managers

### 23. Escalation Decision Tree & Clinical Triage Algorithm

**ID:** eb8c94ad-67de-4d58-87dc-5213b4c30c99

**Description:** Visual flowchart for outreach, street-contact, and cooling-center staff to rapidly assess heat-illness severity and decide: call 112 (EMS), use nurse triage line, or manage at home with hydration/rest. Includes recognition cues (confusion, weakness, loss of consciousness, skin temperature indicators), decision points, and action statements. Laminated pocket card version for field use.

**Responsible Role Type:** Outreach and Street Contact Lead / Occupational Health Nurse

**Primary Template:** Heat Illness Flowchart (CDC/NOAA model, adapted)

**Steps:**

- Co-design with emergency-medicine clinician and occupational health nurse: identify key discriminators between heat stroke (emergency), heat exhaustion (semi-urgent), and mild heat reaction (home management).
- Specify observable signs per category: heat stroke (confusion/altered mental status, loss of consciousness, hot/dry or profusely sweating, core-temp >40°C if measured), heat exhaustion (weakness, dizziness, nausea, normal mental status), mild reaction (flushed, thirsty, no weakness).
- Create yes/no decision tree: if confused OR unconscious → 112 EMS; if weak but alert → nurse triage line; if thirsty + normal → home management (water, rest, cool compress).
- Include escalation rule: if condition worsens after first call (triage says home, but person deteriorates), permission to call 112 immediately (reinforce to residents and staff).
- Design two versions: (1) full-page poster for cooling centers; (2) pocket-card (2x3 inches) for outreach field staff.
- Translate into 4-6 local languages; test with ≥5 users (health workers and lay staff) for comprehension and practical usability.
- Finalize by Month 1 (2026-11-08); print and distribute by Month 2 (2026-12-08).

**Approval Authorities:** Occupational Health Nurse, emergency-medicine consultant, Outreach Lead

### 24. Volunteer Driver Training & Competency Assessment

**ID:** b03e8849-592b-44d5-a5d5-fcf46e1d41f5

**Description:** 2-3 hour training curriculum for volunteer drivers covering: heat-illness recognition and escalation (decision tree from above), de-escalation and trauma-informed communication (how to interact with distressed residents), vehicle safety and passenger assistance (helping elderly or wheelchair users into vehicle), safeguarding (boundaries, confidentiality, appropriate behavior), incident reporting, and stress/fatigue awareness. Includes role-play scenarios, written test (≥80% pass required), and competency checklist.

**Responsible Role Type:** Transport Dispatch and Mobility Coordinator / Occupational Health

**Primary Template:** Volunteer Orientation & Safety Training Curriculum

**Steps:**

- Develop 3-hour training module: (1) heat-illness recognition (30 min, includes flowchart exercise); (2) de-escalation and trauma-informed interaction (30 min, role-play scenarios—angry resident, confused elderly, distressed person); (3) vehicle safety and passenger assistance (30 min, wheelchair entry practice if possible); (4) safeguarding, boundaries, confidentiality (30 min); (5) incident reporting and support (15 min); (6) stress, fatigue, and when to say no (15 min).
- Create role-play scenarios (3-5 vignettes): confused elderly resident who doesn't remember where cooling center is; aggressive younger person demanding immediate transport; wheelchair-using resident with anxiety about unfamiliar transport.
- Draft written test (10 questions, multiple choice): assess understanding of heat-illness signs, escalation rules, de-escalation principles, confidentiality, and incident reporting. Pass threshold: ≥80%.
- Develop competency checklist: trainer observes volunteer and confirms competency on (1) correct heat-illness assessment, (2) calm and respectful communication, (3) safe vehicle operation and passenger assistance, (4) correct incident-report format.
- Include case for ongoing refresher training: annual or bi-annual, especially after any incident or staff feedback about skill gaps.
- Finalize curriculum by Month 0.5 (2026-10-23); begin training volunteers by Month 1 (2026-11-08); require all volunteers to pass by Month 2 (2026-12-08).

**Approval Authorities:** Transport Dispatch Coordinator, occupational health, volunteer supervisor

### 25. Outreach & Street-Contact Staff Training & Competency Certification

**ID:** 3bcd1f28-b978-4f2e-8332-19eaef23d2f7

**Description:** Comprehensive training curriculum for 25-35 outreach, door-knock, and street-contact field staff covering: heat-illness recognition and escalation (decision tree), de-escalation and trauma-informed communication, safety protocols (personal safety, assault response, when to withdraw), informed consent and privacy (GDPR, what data can be collected), enrollment procedures (consent form, withdrawal instructions), and documentation (logging contact attempts, outcomes). Includes role-play scenarios, written test, and post-training certification.

**Responsible Role Type:** Outreach and Street Contact Lead

**Primary Template:** Social Work/Outreach Staff Training Manual

**Steps:**

- Develop 3-4 hour training curriculum: (1) program overview and goals (15 min); (2) heat-illness recognition and escalation (45 min); (3) de-escalation, trauma-informed communication, personal safety (45 min, includes assault-response protocol and when to withdraw/call backup); (4) informed consent, GDPR, and privacy (30 min); (5) enrollment procedures: how to introduce program, present consent form, explain withdrawal process (30 min); (6) documentation and call logging (15 min); (7) stress, burnout, and peer support (15 min).
- Create realistic role-play scenarios: resident suspicious of official contact (trust issue); isolated older person unable to fully understand consent (capacity assessment needed); person in acute distress (heat illness symptoms); aggressive or hostile encounter.
- Draft written test (15 questions): assess knowledge of heat-illness signs, escalation paths (EMS vs. home management), de-escalation principles, consent requirements, privacy rules, documentation, and personal-safety protocols. Pass threshold: ≥80%.
- Develop competency observation checklist: trainer shadows or role-plays with staff to confirm: (1) correct heat-illness assessment, (2) empathetic and respectful communication, (3) correct informed consent/withdrawal procedure, (4) accurate documentation, (5) appropriate safety boundaries.
- Include certification: upon passing written test + observation, staff receive dated certificate authorizing alert-day deployment.
- Plan for refresher training: annual, plus rapid retraining if any staff demonstrates skill gaps or after incidents.
- Finalize curriculum by Month 1 (2026-11-08); conduct training for all outreach staff by Month 2 (2026-12-08); maintain training records and certification for audit.

**Approval Authorities:** Outreach and Street Contact Lead, occupational health, incident commander

### 26. Misinformation Response & Rapid-Correction Protocol

**ID:** 016bea0b-fb6e-43ac-b8c4-c49d5a5b1e9d

**Description:** Procedures for detecting, assessing, and rapidly correcting dangerous misinformation during alert season. Specifies: (1) monitoring channels (social media, community messenger reports, local forums, rumors heard by staff); (2) assessment criteria (is this claim false? dangerous to health?); (3) response pathways (media relations, community messenger activation, SMS correction, radio spot); (4) messaging templates for common myths (alcohol, fan misuse, center safety); (5) escalation to incident commander if misinformation spreads widely.

**Responsible Role Type:** Communications, Language Access and Trusted Messenger Coordinator

**Primary Template:** Rapid-Response Misinformation Protocol (WHO/CDC model, adapted)

**Steps:**

- Identify likely misinformation themes (from prior heat events in Spain and Europe): alcohol myths ('drinking alcohol cools you down' is FALSE), fan misuse ('fans are dangerous' or 'fans work in extreme heat' are FALSE), center/vaccine distrust ('cooling centers will expose you to COVID' or 'government tracking'), and alternative remedies ('ice baths are dangerous', 'cold showers work').
- Draft fact-based, simple 2-3 sentence correction statements in Spanish, Valencian, and 2-3 other local languages, pre-reviewed by a clinician for accuracy. Example: 'Myth: Alcohol cools you. FACT: Alcohol dehydrates. Drink water instead and cool your skin with a wet cloth.'
- Create rapid-deployment workflow: (1) Communications lead receives misinformation report from messenger, social media, or staff (phone/email). (2) Lead assesses within 2 hours: is it false? health-risky? (3) If yes, activates response within 4 hours: (a) email fact-based correction to all community messengers + instruction to share via WhatsApp, phone tree, in-person (markets, centers); (b) tweet/post correction on municipal social media; (c) radio station submission for brief spot (if time/relationship allows); (d) SMS to enrolled residents if widespread concern.
- Assign one staff member as 'misinformation monitor' (part of communications team); review social media, local Facebook groups, and community reports daily during alert season.
- Set trigger for escalation: if misinformation spreads to >100 local social-media engagements or is reported by multiple independent sources, notify incident commander immediately; consider higher-level response (mayor statement, media interview).
- Document all misinformation incidents in a log: date detected, claim, assessment (false/dangerous?), response activated, timeline to correction, outlet reach, follow-up (did correction spread as widely as misinformation?). Use log to refine future messaging.
- Finalize protocol by Month 1 (2026-11-08); test with mock misinformation scenario during drill; operationalize by Month 6 (2027-04-08).

**Approval Authorities:** Communications Coordinator, incident commander, media relations officer

### 27. Financial Management & Contingency-Fund Authorization Framework

**ID:** a45dda6d-8eee-42bd-a471-1101f2165d25

**Description:** Specifies budget authority levels (who can approve spending <€5k, €5-50k, >€50k), contingency-fund draw procedures (when and how to request contingency spending, approval timelines), monthly budget-vs.-forecast tracking, reforecasting triggers (if spend exceeds plan by >10%, reforecast cash flow and alert steering committee), and mid-season budget-rebalancing decisions (if cost overruns appear, which services are priority for funding preservation vs. potential cuts).

**Responsible Role Type:** Project Manager / CFO

**Primary Template:** Municipal Budget Management Policy Template

**Steps:**

- Establish spending authority thresholds: (1) incident commander or PMO lead can approve ≤€5k (e.g., local purchase, emergency supplies); (2) steering committee approval needed €5-50k (e.g., change order, contract amendment); (3) funder and CFO approval >€50k (major scope or budget change).
- Contingency-fund access: €160k held in tranche 1 (Months 0-4 = 2026-10-08 to 2027-02-08) and €120k in tranche 2 (if released at Month 4 = 2027-02-08). Draws >€10k require written request to PMO (justification, amount, alternative if denied) + incident commander approval. PMO tracks cumulative contingency spend and alerts steering committee if >€80k drawn before Month 4 (2027-02-08).
- Monthly budget tracking (by PMO): Produce a spend-vs.-forecast summary by 25th of each month comparing actual invoiced costs to budgeted amount by category (refuges, transport, outreach, kits, staff, etc.); highlight variances >5%. Distribute to incident commander and steering committee.
- Reforecasting trigger: if any month's spend exceeds forecast by >10% (or cumulative overspend >€50k), PMO convenes emergency budget-review meeting within 48 hours with incident commander, category leads, and CFO to: (a) understand root cause (supplier price increase, hiring wage premium, higher utilization?); (b) estimate YTD and full-year impact; (c) identify rebalancing actions (absorb within contingency, reduce lower-priority services, request funder supplement).
- Service priority for cuts (if funding shortfall): (1) maintain refuge and transport operations first (gates depend on this); (2) maintain outreach phone line second (gate 2 depends on it); (3) defer home-kit installations third (defer some installs to Year 2 if needed); (4) reduce communications/language work if severe (least gate-critical).
- Escalation: if rebalancing cannot close a >€100k gap, notify funder within 1 week with options: (a) release contingency from tranche 2 early if available; (b) defer non-critical activities; (c) reduce scope (fewer sites, fewer kits); (d) seek supplemental funding from municipal budget. Funder decision within 2 weeks.
- Finalize framework by Month 1 (2026-11-08); begin monthly tracking Month 2 (2026-12-08); conduct reforecasting meetings as triggered.

**Approval Authorities:** Project Manager, CFO, incident commander, steering committee, funder (for major changes)

### 28. Diversity, Equity & Inclusion Metrics & Monitoring Plan

**ID:** 3554390c-4e0a-45a2-bf78-1ac7aa652f1f

**Description:** Specifies equity metrics to track whether the program reaches high-need populations fairly: (1) coverage by neighborhood deprivation index (% of 65+ population in each high-deprivation area enrolled or contacted); (2) coverage by housing type (top-floor, social housing, private rental); (3) language diversity in outreach (% of contact attempts in non-official languages); (4) migrant and recent-arrival reach (% of enrolled population from recent-arrival households); (5) unhoused reach (count of unhoused individuals contacted or served). Includes data-collection procedures, analysis plan, and go/no-go decision point (if equity gap >20% by Month 7 = 2027-05-08, activate equity-focused outreach surge).

**Responsible Role Type:** Project Manager / Data Analyst

**Primary Template:** Equity Metrics Framework (public health practice)

**Steps:**

- Define equity metrics: (1) deprivation-index coverage: compare % enrolled or contacted in each neighborhood (high/medium/low deprivation) to population % in that area; measure equity gap (difference between highest and lowest coverage); target: <10% gap by Month 7 (2027-05-08); (2) housing-type coverage: % of enrolled from top-floor vs. mid-floor vs. ground-floor; target: at least 50% from top-floor/priority units; (3) language diversity: % of outreach contact attempts in non-official languages; target: ≥5% by Month 7 (2027-05-08); (4) migrant reach: % of enrolled from households with recent-arrival status (moved <10 years); target: ≥10% by Month 7 (2027-05-08) (as proxy for integration success); (5) unhoused reach: count of distinct unhoused individuals contacted or transported per month; target: ≥30 per month.
- Data-collection procedure: (1) at enrollment or contact, log: neighborhood/postcode (enables deprivation mapping), housing type (collected by partner via brief question), primary language of contact, migrant status (self-reported or inferred from partner data), and unhoused status (for street teams); (2) no names required (privacy-compliant); (3) weekly aggregation by PMO into equity dashboard.
- Analysis plan (monthly): Disaggregate enrollment/contact rates by deprivation, housing, language, migrant status. Identify any group with <50% of target coverage (e.g., if unhoused reach is <15 people/month instead of ≥30 target, flag as under-served).
- Equity-surge trigger (Month 7 = 2027-05-08): if any group has ≥20% gap (e.g., high-deprivation neighborhoods 40% covered vs. low-deprivation 60% covered), activate targeted outreach: (a) deploy additional door-knock teams or ambassadors in under-served areas; (b) increase language-specific messaging; (c) partner engagement review (is partner reaching their capacity? is there untapped demand?).
- Quarterly equity review (Months 4, 7, 10, 12 = 2027-02-08, 2027-05-08, 2027-08-08, 2027-10-08): Publish equity dashboard to steering committee and funder; discuss findings and corrective actions.
- Finalize metrics and data-collection forms by Month 1 (2026-11-08); begin tracking Month 3 (2027-01-08); first equity review Month 4 (2027-02-08).

**Approval Authorities:** Project Manager, equity lead (if designated), incident commander, funder

## Documents to Find

### 1. Castellón de la Plana Demographic & Census Data

**ID:** 616f23d3-774e-4db6-9946-6528ff41bced

**Description:** Official municipal census and demographic data (2020 or most recent) specifying: age distribution (65+ population count and percentage), housing types (owner-occupied, rented, social housing, top-floor prevalence), education and literacy levels, migrant and recent-arrival populations by origin country/language, employment rates, and health-insurance coverage. Identifies vulnerable populations and geographic concentrations for targeting cooling refuges and outreach. Primary input for vulnerability mapping and equity metrics.

**Recency Requirement:** Most recent available (2020 Census or municipal 2024-2025 update preferred); supplement with 2015-2020 trend data if needed.

**Responsible Role Type:** Project Manager / Data Analyst

**Access Difficulty:** Easy. Spanish census data are freely available via INE portal; municipal statistics are public unless privacy-restricted. Contact municipal social services or urban planning department for neighborhood-level housing stock detail.

**Steps:**

- Contact Castellón de la Plana municipal statistics office or Valencian regional statistics agency (Institut Valencià d'Estadística, IVE).
- Request: age distribution (5-year bands, especially 65+), housing type by neighborhood, migrant/foreign-born population by country of origin, language spoken at home.
- Search national Spanish statistics portal (Instituto Nacional de Estadística, INE) for Castellón municipality-level data.
- Request municipal housing authority data on social-housing locations, building age, and insulation quality of stock.

### 2. Castellón de la Plana Historical Heat Data & Temperature Records

**ID:** 1f879ea9-02e6-450a-bb45-247ffa4dff2e

**Description:** Daily maximum and minimum temperature records (2010-2025) from national meteorological service (AEMET) or local weather station, with date and location. Used to validate alert thresholds historically (how often does forecast ≥35°C daytime and ≥22°C night occur? how many are actual heat events vs. false alarms?), and to establish the baseline relationship between temperature and heat-related EMS/ED calls for temperature-adjusted evaluation.

**Recency Requirement:** 15-year historical record preferred (2010-2025); minimum 5-year baseline (2020-2025).

**Responsible Role Type:** Data and Evaluation Coordinator

**Access Difficulty:** Easy. AEMET historical weather data are publicly available via portal and downloadable. Local university data may require a research-partnership request but are typically shared for public-health context.

**Steps:**

- Contact Spanish national meteorological service (Agencia Estatal de Meteorología, AEMET) and request historical temperature data for Castellón de la Plana station (daily high/low, date).
- Download from AEMET public portal (https://www.aemet.es) or request via open-data API.
- Cross-check with local university or research institute weather data if available (e.g., Universitat Jaume I, Castelló, may have local station data).
- Obtain additional context: known major heat events in Castellón (2003, 2010, 2015, 2018, etc.) and their reported temperature and impact.

### 3. Castellón de la Plana Municipal Cooling-Center Asset Inventory

**ID:** f99bad9d-b417-474d-8a99-6239257d50ca

**Description:** Official list of municipal or accessible public facilities (libraries, community centers, parish halls, sports facilities, schools, government offices) with: location (address, postal code), floor area, occupancy capacity, current opening hours, accessibility features (wheelchair access, toilets, water, parking), utilities (air-conditioning, heating, water supply), and insurance/liability status. Used to identify and audit the 10 proposed cooling-center sites.

**Recency Requirement:** Current (2024-2025); update if facilities have undergone recent renovation or closure.

**Responsible Role Type:** Cooling Center Network Manager

**Access Difficulty:** Medium. Municipal facilities data are typically held internally; access requires formal request to facilities management or city procurement office. Some data may be classified (insurance, security). Accessibility audit reports may be incomplete; physical verification required.

**Steps:**

- Contact Castellón de la Plana municipal facilities or asset-management department; request comprehensive facility inventory with accessibility audit data.
- Request municipal facility-use agreements or insurance documentation for liability assessment.
- Contact library system, municipal sports/recreation department, and social services to cross-check facility capacity and opening-hour availability.
- Visit or photograph proposed sites to verify accessibility; document any gaps (missing ramps, inadequate toilets, no quiet room).

### 4. Castellón de la Plana Housing Stock Characteristics (Age, Insulation, Top-Floor Distribution)

**ID:** 069732c6-24dc-4a99-86f7-63e276de0640

**Description:** Detailed housing data by neighborhood or postcode area: year built (pre-1970, 1970-1990, post-1990), estimated insulation quality (based on building standard era and renovation history), ownership type (social housing, private rental, owner-occupied), concentration of top-floor flats (% per neighborhood), and heating/cooling status (% with AC, % with no cooling). Used to target home-kit installations and identify neighborhoods with highest cooling-kit need.

**Recency Requirement:** Most recent municipal housing census or survey (2015-2025); supplement with building-code historical records if needed.

**Responsible Role Type:** Home Interventions and Handyperson Coordinator

**Access Difficulty:** Medium. Municipal urban planning data are public in principle but may be scattered across departments. Social-housing data are available from housing associations. Energy-company data may require privacy review (anonymized, aggregated only).

**Steps:**

- Contact Castellón municipal urban planning or housing department; request housing stock inventory with construction-date and type classification.
- Request municipal energy-efficiency survey or building-code compliance database if available.
- Contact housing associations and social-housing providers for lists of their properties, ages, and insulation status.
- Request utility or energy-company data (Endesa, Iberdrola) on building energy-consumption patterns by neighborhood (proxy for insulation quality and AC prevalence).
- Search regional housing authority (Generalitat Valenciana) databases for social-housing locations and characteristics.

### 5. Castellón de la Plana Healthcare Infrastructure & EMS System Data

**ID:** efbbaebd-db8e-4284-afef-2cdac13ed2cb

**Description:** Directory of hospitals (general and specialty), emergency departments, urgent-care centers, primary-care health centers (centros de salud), EMS service providers (ambulancias), and call-center locations with: capacity (beds, ED waiting areas), operating hours, heat-related EMS call and ED visit baseline data (if available), heat-related ICD-10 coding practice (which codes are used for heat illness), and existing data-sharing protocols with municipal government.

**Recency Requirement:** Current (2024-2025); baseline heat-related call/ED-visit data for 2-3 prior summers (2021-2024 minimum).

**Responsible Role Type:** Public Health Coordinator / Health Data Manager

**Access Difficulty:** Medium to Hard. Health-system data are sensitive and subject to strict privacy regulations (HIPAA-equivalent in EU). Access requires formal data-processing agreement (DPA) and legal review. Baseline counts may be available in aggregated form only (no patient identifiers). Coding practice varies by clinician and may not be standardized; clarification needed with medical directors.

**Steps:**

- Contact Castellón municipal health department or regional health authority (Servicio Valenciano de Salud, SSVS) for hospital and primary-care contact list and data-sharing procedures.
- Request hospital medical records and ED data: count of ED visits with heat-related ICD-10 codes (T67.0-T67.9) or clinician notation 'heat-related' per day/week for 3 prior summers; clarify coding practice and criteria for heat attribution.
- Contact local EMS service (061 Comunitat Valenciana or municipal ambulance service) for count of heat-related calls per day/week for 3 prior summers and their heat-related coding standard.
- Request primary-care network data if available: count of heat-related consultations or advice calls during prior summers.
- Inquire about existing data-sharing agreements or protocols between health system and municipal government; identify legal and IT contacts for MOU negotiation.

### 6. Castellón de la Plana Baseline Heat-Related Mortality & Excess-Death Estimates

**ID:** 0bf77087-1fd6-46b3-ac5c-2546b74f0704

**Description:** Three-year historical data on deaths attributed to heat (ICD-10 code T67 or documentation of 'heat-related' in death certificate) or excess mortality during summer months (May-September) compared to expected seasonal baseline (e.g., via statistical/demographic methods). Used to establish baseline harm and to assess program attribution post-hoc. May be obtained from regional health authority, national health statistics office, or municipal vital statistics.

**Recency Requirement:** Most recent 3-5 years of data (2020-2025); supplement with 2010-2019 trend if available to establish longer-term patterns.

**Responsible Role Type:** Data and Evaluation Coordinator / Health Epidemiologist

**Access Difficulty:** Hard. Mortality data are sensitive and privacy-protected. Individual death certificates are restricted-access. Aggregated mortality counts (by heat-code ICD-10 or monthly excess-death estimates) are more accessible via health authorities. University researchers may have already analyzed this data; a research partnership may accelerate access.

**Steps:**

- Contact regional health authority (SSVS) or Valencian public-health institute (Agencia de Salut Pública) for mortality data by cause of death, including heat-related codes (T67.0-T67.9).
- Request municipal vital statistics (registro civil) for death certificates with heat or heat-related condition notation.
- Search Spanish national health statistics portal (Instituto de Salud Carlos III) for Castellón excess-mortality or heat-attributable-death estimates.
- Contact university epidemiology department or research institute in Valencia region; they may have conducted prior heat-mortality studies with Castellón data.
- Request from national statistical office (INE) if mortality data by cause and municipality are published.

### 7. Spanish & Valencian GDPR & Health-Data Protection Guidance

**ID:** 88109013-c68c-4514-9aae-15c88b189001

**Description:** Official regulatory guidance from Spanish Data Protection Agency (AEPD) and regional health authorities on: lawful basis for processing health data for public-health emergencies (Article 6 GDPR), consent requirements and withdrawal procedures (Article 7), data-processing agreements (Article 28), and special-category data rules (Article 9). Clarifies whether heat-alert contact is a 'public task' (Article 6(1)(e)) or requires explicit consent, and how intermediary-held health data (housing associations, social services) is governed.

**Recency Requirement:** Current GDPR guidance (2021 or later); AEPD published criteria or decisions preferred.

**Responsible Role Type:** GDPR Compliance Officer / Legal Counsel

**Access Difficulty:** Easy to Medium. AEPD website has public guidance in Spanish; English translation may be needed. AEPD accepts guidance requests but response time varies (2-8 weeks). Regional authorities may have fewer published resources. Legal counsel familiar with Spanish GDPR practice is helpful.

**Steps:**

- Visit Spanish Data Protection Agency (AEPD) website (aepd.es) and search for guidance on health data, public-health emergencies, and intermediary data sharing; download published documents and criteria.
- Request AEPD published decisions or opinions on heat-alert contact lawful basis (may be available as case studies or FAQ).
- Contact AEPD directly via email or phone for guidance on whether the intermediary-held-list model complies with Spanish law (they may issue formal written guidance).
- Search Valencian regional law (Generalitat Valenciana) for any regional data-protection guidance or health-privacy guidance (beyond national GDPR).
- Review Catalan Data Protection Authority (APDCAT) or other Spanish regional authority guidance for heat or emergency health contexts; may be transferable precedent.
- Consult with municipal legal department or GDPR counsel for case law or AEPD decisions on public-health and emergency-context data processing.

### 8. Spanish Occupational Health & Worker Protection Standards (Heat in Outdoor Work)

**ID:** a8dd775d-1faa-40ba-9c54-83fac471e536

**Description:** Official Spanish labor law and EU directives on mandatory worker protection during heat: temperature thresholds that trigger mandatory rest breaks, shade and water provision, shift-time restrictions, and medical monitoring. Applies to municipal outdoor workers and contractors. Provides the legal basis for the 'worker protection clauses' in contracts and procurement.

**Recency Requirement:** Current law (2024-2025); minimum EU Directive 2003/88/EC (Working Time Directive) and any national transposition or updates.

**Responsible Role Type:** Legal Counsel / Occupational Health

**Access Difficulty:** Easy. Spanish labor law is publicly available; INSHT publishes free occupational health guidance. EU directives are available in all EU languages. Municipal associations provide practical templates.

**Steps:**

- Download Spanish labor law (Código del Trabajo) sections on occupational health and safety (Ley de Prevención de Riesgos Laborales, 31/1995) from official government source (boe.es).
- Search Spanish National Institute of Occupational Safety (INSHT) website for heat-related occupational health guidance and risk assessments.
- Review EU Directive 2003/88/EC (Working Time Directive) and any Spanish national transposition guidance.
- Contact Spanish municipal association (Federación Española de Municipios y Provincias, FEMP) for sample heat-protection contract clauses used in other cities.
- Search Valencian regional labor authority (Conselleria de Justicia, Administración Pública) for any regional guidance or precedent.

### 9. EU & Spanish Public Procurement Rules & Thresholds (2024-2025)

**ID:** 27dfc82c-e0be-46ce-a7c8-90f12cae8251

**Description:** Current EU public-procurement directives (2014/24/EU, 2014/25/EU) and Spanish national transposition (LCSP - Ley de Contratos del Sector Público) specifying procurement thresholds (below-threshold vs. tender-required amounts), simplified procedures for emergency or low-value purchases, framework-agreement rules, and audit requirements. Used to determine legal procurement route for cooling kits, transport, and handyperson services within the €3.5M budget.

**Recency Requirement:** Current (2024-2025); Spanish LCSP as amended 2023-2024; EU Directive 2014/24/EU.

**Responsible Role Type:** Municipal Procurement Officer / Contract Law Specialist

**Access Difficulty:** Easy. Spanish law is public and available via boe.es; EU directives are on EUR-Lex. Municipal associations provide practical templates and training. Complexity is moderate; a municipal procurement officer or external legal counsel familiar with Spanish rules is helpful.

**Steps:**

- Download Spanish public-procurement law (LCSP, Ley 9/2017) from official government source (boe.es).
- Search Spanish Public Sector Contracts Board (Junta de Contratación del Sector Público) website for current thresholds, guidance, and case studies.
- Download EU Directive 2014/24/EU (Procurement Directive) and its preamble from EUR-Lex.
- Contact Spanish municipal association (FEMP) or local municipal procurement office for practical guidance on below-threshold purchasing and framework-agreement procedures in Spain.
- Search for OECD or EU publications on emergency procurement procedures (may be relevant if heat response is framed as emergency/public-health urgency).

### 10. Castellón de la Plana NGO & Social Services Directory (Housing Associations, Social Care, Homeless Services, Migrant Organizations)

**ID:** b501f078-895b-4278-b459-d0b4227342d4

**Description:** Comprehensive list of local non-governmental and community organizations, including: housing associations/cooperatives (vivienda social), social services (servicios sociales), homeless or rough-sleeping services, migrant integration organizations, faith-based groups, and language/cultural associations. Includes contact names, phone, email, service scope, and current client base. Used to identify and engage partners for intermediary-held outreach, street contact, language access, and community trust-building.

**Recency Requirement:** Current (2024-2025); update annually; some turnover in staff/leadership expected.

**Responsible Role Type:** Partner Liaison Officer / Community Engagement Lead

**Access Difficulty:** Easy to Medium. Municipal social services maintain partner registries (usually shared readily). Online directories and faith organizations are publicly listed. Contact details may be incomplete; direct phone verification needed.

**Steps:**

- Contact Castellón municipal social services department for official registry of partner organizations and referral networks.
- Request municipal integration or migration office directory of migrant associations and support organizations.
- Search online directories: Plataforma del Voluntariado de España (Spanish volunteer directory), Guía del Tercer Sector (Spanish NGO directory), and regional Valencian NGO networks.
- Contact Castellón archdiocese or religious affairs office for list of faith-based organizations (mosques, churches, synagogues) active in social care.
- Inquire with municipal housing authority about housing associations and their outreach/welfare roles.
- Request homeless-service NGO directory from Castellón social services or regional authorities.

### 11. Castellón de la Plana Migrant Population & Language Profile

**ID:** 135a949f-a58d-40af-a511-761a2d1dd3c2

**Description:** Demographic data on migrant and foreign-born populations in Castellón, including: countries/regions of origin, estimated size (% of population), primary non-Spanish languages spoken, geographic clustering (which neighborhoods), and existing language-support infrastructure (community centers, interpretation services, migrant organizations). Used to specify language-access priorities (4-6 languages to translate/interpret) and to design culturally appropriate outreach and trust-building.

**Recency Requirement:** Most recent census or municipal survey (2020-2025); supplement with NGO field knowledge (migrant organizations know current migrant population profile).

**Responsible Role Type:** Communications, Language Access and Trusted Messenger Coordinator

**Access Difficulty:** Easy to Medium. Census data are public. Municipal integration offices maintain detailed knowledge. NGO organizations have field experience and can provide rapid assessment. Data may be scattered across departments; a central request to municipal coordinating office (e.g., mayor's office, social services) may be faster.

**Steps:**

- Contact Castellón municipal integration or migration office (if exists) for demographic data on foreign-born residents and languages spoken.
- Request INE (Spanish statistical office) census data on foreign-born population by nationality/origin country for Castellón municipality.
- Contact municipal social services for language-service data: how many non-Spanish interpreters does the city employ? which languages are most requested?
- Request information from migrant support organizations (identified in NGO directory above): what are the top 5-10 languages they encounter? which neighborhoods have highest migrant density?
- Search municipal website for published migration integration plans or reports; these often profile migrant populations.
- Request from municipal education department language data on immigrant children's home languages (school records may reflect current demographic).

### 12. Existing EU & Spanish City Heat Action Plans (Barcelona, Madrid, Paris, other EU cities) - Templates & Lessons Learned

**ID:** 2e1d3b3a-02ab-46ff-ab92-f22616815b3c

**Description:** Published heat action plans and operational playbooks from peer EU cities (Barcelona Climate Shelters Network, Paris Plan Canicule, Madrid Heat Wave Plan, Ahmedabad Heat Action Plan if available). Includes decision rationale, SOP templates, alert protocols, cooling-center models, transportation strategies, outreach methods, lessons learned, and cost structures. Used to validate design choices and to accelerate playbook development by adapting proven templates.

**Recency Requirement:** Published in last 5 years (2020-2025 preferred); earlier (2015+) are informative but may be outdated.

**Responsible Role Type:** Project Manager / Best-Practice Researcher

**Access Difficulty:** Easy to Medium. C40, UCLG, and major city websites have public plans. Academic literature is freely available via Google Scholar or institutional repositories. Some cities' detailed operational SOPs may not be fully published (proprietary or sensitive); direct request to city contacts or public-health agencies may yield unpublished templates.

**Steps:**

- Search C40 Cities Climate Leadership Group (c40.org) for member city heat plans and case studies; Barcelona, Madrid, Paris likely have published plans.
- Visit Barcelona Ajuntament website (barcelona.cat) and search for 'refugis climàtics' (climate shelters network) reports.
- Visit Paris (paris.fr) and search for 'Plan Canicule' and 'Registre Canicule' (heat registry) resources.
- Search UCLG (United Cities and Local Governments) or ICLEI networks for published city heat-action plans and playbooks.
- Contact NRDC (Natural Resources Defense Council) for Ahmedabad Heat Action Plan and replication guidance; available publicly.
- Search PubMed or Google Scholar for published peer-reviewed articles on heat action plans and city-level interventions (e.g., Heaviside et al., 2016; Sheridan et al., 2019).
- Request directly from Barcelona public-health agency (Agència de Salut Pública de Barcelona, ASPB) or Paris CCAS for their playbooks and evaluation reports.

### 13. Taxi/Accessible Transport Operator Availability & Pricing (Castellón de la Plana)

**ID:** 4b6f71fe-9d60-4a88-8540-8a59abf93317

**Description:** Market survey of local taxi and accessible-transport services: fleet size, vehicle types (standard, wheelchair-accessible, paratransit), hourly rates, standby retainer options, response-time guarantees, insurance coverage, and willingness to commit to heat-alert standby capacity. Used to negotiate the transport retainer contract and to validate whether the €80k budget is adequate.

**Recency Requirement:** Current (2024-2025); updated within 3 months of project start.

**Responsible Role Type:** Transport Dispatch and Mobility Coordinator

**Access Difficulty:** Medium. Taxi operators and paratransit services are private businesses; they are willing to provide quotes but may not publish rates. Direct phone/email contact or a formal RFQ is needed. Some quotes may be inflated initially; negotiation is expected.

**Steps:**

- Contact 3-5 local taxi companies or transport cooperatives (identified via local business directory or taxi regulator) and request pricing for: (1) hourly standby retainer (pay to hold X vehicles available ≤Y-minute response), (2) per-trip pricing (€ per km or per trip), (3) wheelchair-accessible vehicle availability and cost premium.
- Request references from other municipal or emergency services that contract with local operators.
- Inquire about insurance coverage, driver vetting, and safeguarding procedures.
- For paratransit services (if exist separately from taxis), contact municipal social services for existing vendor contacts and pricing.

### 14. Cooling Kit Suppliers & Availability (Exterior Shading, Reflective Blinds, Fans, Thermometers)

**ID:** 5e244756-36a0-4a28-a693-3aeede639bd9

**Description:** Supplier market survey for home-kit components: manufacturers or distributors of exterior shading/blinds, window fans, digital thermometers, and hygrometers available in Spain or Europe; unit costs, minimum order quantities, lead times (weeks to delivery), expedite options, and product specifications (quality, durability, safety standards for fans). Used to finalize kit procurement specifications and budget, and to validate whether €800k is sufficient for 2,000 homes.

**Recency Requirement:** Current pricing & availability (2024-2025); valid for 2-3 months lead time.

**Responsible Role Type:** Home Interventions and Handyperson Coordinator

**Access Difficulty:** Medium. Supplier information is available online or via direct contact; competition is moderate. Pricing varies by supplier, quality, and order size; multiple quotes are essential for cost validation.

**Steps:**

- Conduct online search for EU/Spanish suppliers of: exterior aluminum blinds/shading (e.g., Bandalux, Gradus, Hunter Douglas, or local Spanish brands), reflective window treatments, directional window fans (6-8 inch, safe for elderly use), and digital thermometer/hygrometer kits.
- Request quotes from ≥3 suppliers per component (shading, blinds, fans, thermometers) for bulk orders (600-2,000 units); specify quality standards (safety, durability), lead time, and per-unit cost.
- Check if municipal procurement framework agreements already exist for energy-efficiency or home-improvement kits; may allow faster ordering.
- Request lead-time and expedite-cost information for Q1-Q2 2027 (Feb-May 2027) delivery to align with project schedule.
- Inquire about bulk discounts, payment terms, and product warranties.

### 15. Castellón de la Plana Municipal Budget Process & Authority Structure

**ID:** 5f7b9586-62a7-425d-b397-9cf0f048697d

**Description:** Official municipal budget documentation specifying: annual budget cycle (when submissions are due, approval timelines), approval authority (city council, mayor, department heads), contingency and emergency-reserve procedures, and multi-year funding commitment processes. Clarifies how to secure €3.5M initial authorization and how contingency draws and budget rebalancing require approval.

**Recency Requirement:** Current municipal budget cycle (2024-2025 fiscal year); procedures may be stable year-to-year.

**Responsible Role Type:** Project Manager / CFO

**Access Difficulty:** Easy to Medium. Municipal budget procedures are public (required by EU transparency rules). Documents are typically available via finance office or city website; some require formal information request.

**Steps:**

- Contact Castellón municipal finance/budget office (Intervención, Tesorería) for current budget cycle documentation and procedures.
- Request: (1) budget approval timeline and authority structure; (2) contingency and emergency-fund procedures; (3) multi-year funding commitment process; (4) rebalancing or amendment procedures mid-year.
- Search municipal website for published budget documents, ordinances, or council decisions on budget procedures.
- Contact city council secretary for information on council approval processes for large municipal projects and multi-year funding commitments.

### 16. Spanish Public Procurement Market Data & Supplier Benchmarks (Cooling Kits, Transport, Installation Services)

**ID:** 32df6743-ef94-498e-86a2-b7fc39992b77

**Description:** Market pricing and supplier availability for cooling-kit components (shading, blinds, fans, thermometers), transport services (taxi, accessible vehicles, retainer models), and handyperson/installation services in Spain (rates, qualifications, typical contract terms). Used to benchmark the €800k kit budget and €80k transport retainer against realistic market prices.

**Recency Requirement:** Current 2024-2025 market pricing; obtain quotes directly from suppliers for project-specific assessment.

**Responsible Role Type:** Procurement Officer / Home Interventions Coordinator

**Access Difficulty:** Medium. Market pricing varies by supplier, order size, and timing; multiple competitive quotes are essential. Private companies provide quotes but may inflate initial proposals; negotiation is expected. Time-bound RFQs (close-out date) help accelerate responses.

**Steps:**

- Issue formal RFQs (requests for quotation) to 3-5 suppliers per category with specifications (cooling kits for 2,000 homes, transport retainer for 40 volunteer drivers + taxi backup); request unit costs and lead times.
- Search Spanish industrial suppliers (e.g., Alibaba, local Spanish distributors) for cooling-kit components and pricing; validate with manufacturers for bulk orders.
- Contact 3-5 taxi/transport operators in Castellón region for pricing on standby retainers and per-trip rates; benchmark against other Spanish cities.
- Request pricing from handyperson/contractor associations or municipal contractor databases for typical installation rates in the region.
- Consult municipal procurement office for historical pricing data on prior equipment or service contracts.

### 17. Voluntary Sector & Charity Insurance Requirements & Providers in Spain

**ID:** 9dc37bb6-172c-4955-8d27-078e7e71c733

**Description:** Information on insurance options for volunteer-driver programs in Spain: liability coverage for volunteers using personal vehicles, assault/threat-related trauma insurance, and typical costs/providers. Clarifies what municipal or third-party insurance is required and available.

**Recency Requirement:** Current 2024-2025; insurance markets evolve, so recent data preferred.

**Responsible Role Type:** Transport Dispatch Coordinator / Insurance Broker

**Access Difficulty:** Medium. Insurance brokers provide quotes readily; finding cost-effective options for volunteers requires shopping. Municipal insurance may or may not extend to volunteers; clarification needed early.

**Steps:**

- Contact Spanish insurance brokers specializing in non-profit/charity coverage (search 'seguros para voluntarios España').
- Request quotes for: (1) volunteer-driver personal-vehicle liability; (2) assault/threat trauma coverage; (3) municipal umbrella policy for all volunteers.
- Contact Spanish Red Cross (Cruz Roja Española) or Caritas or other large charities operating volunteer-driver programs; ask about their insurance arrangements and vendor recommendations.
- Inquire with municipal risk management office about existing umbrella coverage that may extend to volunteers.
- Search for European volunteer insurance schemes (e.g., Allianz, Zurich) with operations in Spain; may offer bulk/non-profit rates.

### 18. Spanish Electrical Safety Standards for Fans & Home Installation (IEC/EN Compliance)

**ID:** 912fdfe0-140e-4ec4-abfd-a245c098999b

**Description:** Electrical safety and building-code standards applicable to window fans and other electrical home-kit components installed in Spain: IEC 60950 (electrical safety), EN standards for appliances, Spanish building code (Código Técnico de Edificación), and heritage/historic-preservation requirements (if applicable in Castellón's old town). Used to specify safe fan products and installation procedures.

**Recency Requirement:** Current standards (2024-2025 editions); standards are stable but periodically updated.

**Responsible Role Type:** Home Interventions Coordinator / Building Inspector

**Access Difficulty:** Medium to Hard. Technical standards are detailed and require expertise to interpret. Municipal building inspector is the best resource for local requirements; manufacturers provide compliance certificates but these require legal/technical interpretation.

**Steps:**

- Download Spanish building code (Código Técnico de Edificación) relevant sections on electrical safety and appliance installation from Spanish ministry source (mitma.gob.es).
- Download EN and IEC standards from European standards body (CEN/CENELEC) or Spanish standards organization (AENOR); standards are paid-access but key excerpts may be free.
- Contact municipal building-code inspector for guidance on required standards for fan installation and any local heritage or aesthetic requirements (especially in Castellón's historic center).
- Request from fan manufacturers: safety certifications and compliance documentation (CE marks, test reports) for proposed products.