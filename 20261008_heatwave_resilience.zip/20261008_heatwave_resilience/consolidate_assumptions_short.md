# Purpose
and

# Domain
and

# Plan Type
# Municipal Heatwave Mortality-Reduction Program

## Overview

This is a 12-month physical program for a mid-sized European city to reduce heat-related mortality. It cannot be executed digitally alone.

## Physical Requirements

- Cooling centers: Libraries, community centers, malls, churches, sports halls must be contracted, staffed, secured, and made accessible (wheelchair access, quiet rooms, water, toilets).
- Transport: Taxi, paratransit, or volunteer-driver services must physically move mobility-limited residents to centers within target time.
- Outreach: Door-knocking, in-person enrollment, and welfare checks on isolated residents are face-to-face activities requiring staff and volunteer safety considerations.
- Home interventions: Exterior shading kits, reflective blinds, window fans, thermometers, hygrometers, and hydration supplies must be procured, stored, distributed, and installed. Handyperson service required for top-floor flats and social housing.
- Health system coordination: Hospitals, EMS, and primary care are involved. Proactive check-ins aim to reduce ambulance and emergency department load.
- Worker protection: Outdoor municipal workers need shaded rest points, water, adjusted schedules, and mandatory breaks on real work sites.
- Communications: Flyers, pharmacy posters, door hangers, radio, and faith and community leaders are used because many vulnerable residents are offline. Physical distribution required.
- Site-specific and staffing needs: Program requires identification of target EU city and its housing stock, plus hiring or contracting of coordinators, outreach staff, center staff, and drivers. Drills and early-season heat days must be conducted to meet the Month 2 (2026-12-08) readiness gate and Month 4 (2027-02-08) scale gate.

## Digital Components

Data dashboard, SMS opt-in, and evaluation report support physical operations but are not the primary solution.

# Physical Locations
# Physical Location Requirements

- Mid-sized non-capital EU city, population 150k–400k
- Existing municipal assets: libraries, community centers, churches, sports halls, malls suitable for cooling centers
- Social housing stock and top-floor flats to prioritize for home interventions
- Access to public health department, hospitals, EMS, primary care for coordination
- Accessible transport infrastructure and taxi/paratransit operator capacity
- Pharmacy and GP networks for enrollment and outreach partnerships
- Outdoor municipal work sites for worker-protection deployment
- Homeless services and NGO networks for street contact and unhoused support
- Radio, postal and community distribution channels for offline residents
- Administrative capacity for GDPR-compliant data handling and procurement

## Location 1: Castellón de la Plana, Spain

Valencian Community, eastern Spain, Mediterranean coast (population ~170k). High summer heat and humid nights; large elderly population (65+ ~20%); significant social housing in poor-insulation blocks. Mediterranean climate increases heat-night mortality risk. Strong municipal administration and NGO networks for homeless services and migrants (sub-Saharan and North African communities). Proximity to Valencia provides university partnership for evaluation and procurement expertise.

## Location 2: Poznań, Poland

Greater Poland region, west-central Poland (pilot districts ~200k population). Increasing summer heat events; poor-insulation Soviet-era housing blocks; large elderly population in social housing. Strong municipal health department and pharmacy/GP networks. Established homeless-service NGOs and migrant communities (Ukrainian, Vietnamese) requiring language access. Administrative capacity and procurement experience support rapid contracting before Month 2 (2026-12-08). Central European positioning attracts EU scaling interest.

## Location 3: Modena, Italy

Emilia-Romagna region, northern Italy, Po River valley (population ~185k). Extreme summer heat and hot nights; large aging population (65+ ~23%); significant elderly living alone. Dense historic center and peripheral social housing with clear cooling-center site options (libraries, parish halls, municipal sports facilities). Strong municipal health and social services with GP and pharmacy networks. Existing volunteer infrastructure and migrant communities (Eastern European, North African) with NGO support. River-valley geography poses heat-island risk.

## Location Summary

The plan requires a mid-sized non-capital EU city (population 150k–400k) with Mediterranean or continental summer heat, poor-insulation housing stock, substantial elderly and vulnerable populations, and established municipal assets. Castellón de la Plana, Poznań, and Modena are proposed as pilot sites, each offering heat risk, social vulnerability, existing municipal and NGO infrastructure, and administrative capacity to meet the Month 2 (2026-12-08) readiness gate and Month 4 (2027-02-08) scale gate. City choice determines cooling-center network footprint, transport demand, outreach partnership routes, language access requirements, and playbook generalizability to other EU cities in similar climates and housing contexts.

# Currency Strategy
# Budget and Currency

## Primary Currency

- EUR: Project currency for all budgeting, procurement, contracts and reporting.
- Project scope: €3.5M, 12-month municipal program in EU cities (Spain, Poland, or Italy).
- Funding schedule: €2.0M initial + €1.5M at Month 4 (2027-02-08) contingent on gate review.

## Cost Items

- Cooling centers
- Transport contracts
- Home kits
- Staff and procurement

## Currency Strategy

- All transactions in EUR.
- Project confined to single Eurozone or EU member state.
- No foreign exchange risk management required.
- Vendor contracts, payroll and grant disbursements conducted in EUR.


# Identify Risks
# Risk 1 - Regulatory & Permitting

GDPR compliance uncertainty despite intermediary-held lists strategy. Data-processing agreements with housing associations, social services, NGOs and pharmacies require legal review and may face delays if partners lack established data-governance frameworks. Regulatory interpretation of lawful basis for contact (consent vs. public task) varies across EU jurisdictions.

Impact: Legal challenge to enrollment or outreach methods could delay partner sign-off by 2–4 weeks. Withdrawal of a key partner due to perceived GDPR risk could reduce enrollment reach by 15–25%. Estimated legal review and remediation cost: €15,000–30,000.

Likelihood: Medium
Severity: Medium

## Action

Engage a specialist GDPR legal firm by Month 1 (2026-11-08) to pre-review data-processing agreements with housing associations, social services and NGOs. Draft template MOUs with clear lawful basis and retention limits. Obtain written legal clearance for the intermediary-held list model and consent protocols before the Month 2 (2026-12-08) readiness gate. Build a 2-week legal-review buffer into the procurement timeline.

# Risk 2 - Operational

Month 2 (2026-12-08) readiness gate (cooling centers contracted and staffed; transport contract signed; phone line operational; outreach training completed; procurement orders placed) compresses multiple parallel work streams into 8 weeks during the cool season, leaving no time for mock heat events or drill feedback loops before the gate.

Impact: Staff and volunteers may not be operationally ready on alert day. Cooling-center opening-day incidents (accessibility failures, staffing gaps, poor signage) could harm public trust and damage credibility with partners. Estimated delay to full operational readiness: 2–3 weeks into the summer season.

Likelihood: High
Severity: Medium

## Action

Front-load cooling-center contracting and handover by end of Month 1 (2026-11-08) to allow 3–4 weeks of operational rehearsal (staffing placement, accessibility checks, security drills, signage installation) before the Month 2 (2026-12-08) gate. Conduct one full-system mock alert drill in March (Month 5 = 2027-03-08) with all centers, transport, phone line and outreach staff operating simultaneously. Use drill results to close gaps before June (Month 8 = 2027-06-08) summer season.

# Risk 3 - Financial

€1.5M second-tranche release at Month 4 (2027-02-08) is contingent on meeting three operational gates (80% center hours, 60% outreach success, <45 minutes transport time) measured during early-season heat days. If June and July temperatures are below historical norms or fall outside alert thresholds, gates cannot be tested fairly, and scale release may be withheld despite operational readiness.

Impact: Without summer heat events by Month 4 (2027-02-08), gates cannot be validated, and €1.5M release may be delayed to Months 5–6 (2027-03-08 to 2027-04-08) or denied if metrics are unverifiable. Budget burn for May–July operations will exceed initial €2.0M if gates are not released on schedule. Estimated shortfall: €200,000–400,000 in operational costs.

Likelihood: Medium
Severity: High

## Action

Redefine the Month 4 (2027-02-08) gate to include formal drills and simulated alert-day scenarios as acceptable evidence, not solely real heat events. Pre-specify a drill protocol by Month 3 (2027-01-08) that mirrors alert-day operations (centers open, transport mobilized, outreach phone line active for 4–6 hours). Document drill results and staffing performance metrics to support the Month 4 (2027-02-08) release decision. Include a contingency budget reserve of €150,000–200,000 to cover May–July operational costs if natural heat events are delayed.

# Risk 4 - Operational

Volunteer driver recruitment and vetting (safeguarding, insurance, background checks) may fall short of target numbers by Month 2 (2026-12-08) if volunteer response is low or vetting takes longer than 6 weeks. Taxi backup contract alone will be inadequate if volunteer gaps exist, and standby retainers may exhaust budget allocated for home kits.

Impact: Fewer than planned volunteer drivers could increase average time-to-transport above the 45-minute gate target by 10–15 minutes, causing gate failure. Shift to taxi-only operation would increase transport costs by €150,000–250,000, forcing cuts to home-kit distribution (500–1000 fewer kits installed).

Likelihood: Medium
Severity: Medium

## Action

Launch volunteer recruitment immediately at Month 0 (2026-10-08), targeting retirees, charity staff and faith-group members through NGO and community networks. Conduct vetting in batches (fortnightly cohorts) rather than all at once, so early cohorts are trained and road-tested by Month 1 (2026-11-08). Establish a taxi-retainer contract by Month 1 (2026-11-08) with a lower threshold guarantee than initially planned. Set a trigger threshold: if volunteer numbers fall below 50% of target by Month 1.5 (2026-11-23), increase taxi retainer proportionally rather than waiting until after the Month 2 (2026-12-08) gate.

# Risk 5 - Supply Chain

Procurement of cooling kits (exterior shading, reflective blinds, window fans, thermometers, hygrometers) by Month 2 (2026-12-08) depends on supplier availability and delivery lead times. If primary suppliers are unavailable or backlogs exceed 4–6 weeks, orders placed in October–November may not arrive until February–March, delaying home-intervention rollout past the summer season.

Impact: If kits do not arrive until March, they cannot be installed before the first heat event in May–June. Target of priority top-floor and social-housing installations will slip to July–August at earliest. Estimated delay: 4–8 weeks. Cost impact if alternative suppliers charge premiums: €50,000–100,000.

Likelihood: Medium
Severity: High

## Action

Issue procurement specifications by end of Month 0 (2026-10-08) to identify supplier availability and lead times. Place first call-off orders for 30–40% of total kit volume by mid-Month 1 (2026-11-08) to secure early stock. Negotiate expedited delivery for February arrival, accepting a 10–15% price premium. Arrange interim storage at municipal facility or supply partner warehouse. Keep a small stock of pre-positioned kits (shading and fans) by February to enable immediate deployment if a heat event occurs in March. Identify backup suppliers for each kit component to mitigate single-source delay.

# Risk 6 - Operational & Safety

Door-knock and street-contact outreach teams will encounter residents in heat distress or acute illness during alert days. Teams lack clinical training and may misjudge escalation severity, leading to delayed EMS calls or inappropriate advice. Safety protocols for staff encountering aggressive or vulnerable residents are not yet defined.

Impact: Outreach staff may fail to recognize heat stroke or severe dehydration and delay critical EMS calls by 10–30 minutes. Over-escalation could saturate EMS with borderline cases. Staff encountering hostile or distressed residents without clear de-escalation guidance risk injury or psychological harm. Potential litigation if a resident suffers preventable harm after staff contact.

Likelihood: Medium
Severity: High

## Action

Partner with a municipal nurse adviser or occupational health service to co-design escalation protocols for outreach staff. Include a checklist for recognizing heat illness signs (confusion, loss of consciousness, core temperature >40°C indicators, severe weakness) and decision trees for when to call EMS, advise home management or refer to 111-style phone triage. Train all outreach and street-contact staff on the protocol before the Month 2 (2026-12-08) gate, with refresher drills in May. Provide safety communication cards and a check-in system so teams can report incidents and receive same-day debriefing if they encounter acute cases. Establish peer support for staff exposed to distressing scenes.

# Risk 7 - Operational

Intermediary partners (housing associations, social services, NGOs, pharmacies) will independently conduct phone outreach and enrollment on the city's behalf. Quality and consistency of outreach contact will vary; some partners may lack call-center capacity or training, leading to missed calls, poor enrollment retention or residents disengaging after the first contact.

Impact: Outreach contact success rate (targeting 60% for enrolled residents) may fall to 40–50% if partner call capacity is insufficient or scripts are delivered inconsistently. Partner fatigue or turnover mid-season could drop success rate to 20–30% by July–August, failing the Month 4 (2027-02-08) gate. Estimated loss: 500–1000 contact attempts per alert day across all partners.

Likelihood: Medium
Severity: Medium

## Action

Co-design a detailed outreach protocol and script with each key partner during Months 0–1 (2026-10-08 to 2026-11-08). Include call targets per alert day, escalation rules and sample language. Conduct joint training for all partner staff by end of Month 1 (2026-11-08), with role-play drills using realistic scenarios. Establish a shared call-tracking dashboard (via secure spreadsheet or partner-hosted system) where partners log calls, outcomes and escalations daily. Monitor partner call volumes and contact success weekly; provide real-time feedback and script adjustments if success drops below 60%. Schedule mid-season partner review at Month 6 (2027-04-08) to identify and resolve gaps before gate measurement at Month 4 (2027-02-08).

# Risk 8 - Technical & Integration

The phone line (heat helpline) and transport-dispatch system will need to integrate with partner call-tracking and cooling-center occupancy data to avoid double-booking and ensure residents reach appropriate sites. If systems are not integrated, coordination failures will occur under peak alert-day demand.

Impact: Residents calling the heat line for transport may be unable to confirm center availability and wait times. Transport dispatch and center staffing may not coordinate, causing residents to arrive at full sites while others are empty. Estimated operational chaos: 10–20% of transport requests may be misdirected or cancelled. Reputational damage if media covers residents being turned away from overcrowded centers.

Likelihood: Medium
Severity: Medium

## Action

Define a simple data-integration protocol by Month 1 (2026-11-08): phone-line staff log transport requests and center of choice in a shared spreadsheet updated in real-time. Transport dispatch accesses the same feed to prioritize routing, and each center reports current occupancy and capacity every 15 minutes via phone or WhatsApp to the dispatch hub. Establish a duty coordinator role who monitors the shared system during alert days and authorizes dispatch redirects if a site reaches capacity. Run this protocol in the March mock-alert drill. Keep the system deliberately simple (spreadsheet-based, not a custom app) to ensure rapid setup by Month 2 (2026-12-08) and resilience if cloud systems fail.

# Risk 9 - Operational

Cooling centers must meet accessibility standards (wheelchair access, quiet rooms, water, toilets) across multiple sites. Existing facilities may have accessibility gaps; remediation takes time and cost, and some sites may be unsuitable. If accessibility is not validated before opening, residents in wheelchairs or with sensory needs will be excluded.

Impact: Wheelchair-using or mobility-limited residents unable to access some sites will over-concentrate at the few fully accessible centers, breaching capacity and transport targets. Estimated exclusion: 5–10% of targeted mobility-limited residents. Potential disability-access complaint or lawsuit. Estimated remediation cost: €20,000–40,000 per site. Delay: 2–4 weeks per site if structural work is required.

Likelihood: Medium
Severity: Medium

## Action

Conduct an accessibility audit of all proposed cooling-center sites by end of Month 1 (2026-11-08), assessing wheelchair access, toilet facilities, water points, quiet/low-stimulus rooms, parking and signage. Categorize sites as 'fully accessible', 'minor modifications needed' and 'unsuitable'. Prioritize fully accessible sites for opening in May; defer sites requiring remediation to July or drop them if remediation exceeds €10,000 or takes >4 weeks. Ensure at least 50% of planned center capacity is in fully accessible sites. Publish accessibility info (accessible routes, toilet locations, quiet room availability) for each site in a simple leaflet and on the municipal website so residents can choose sites that meet their needs.

# Risk 10 - Reputational & Social

Public communications campaign must counter misinformation about heat response (e.g., use of alcohol, incorrect fan use in extreme heat, distrust of cooling centers). If misinformation spreads unchecked, residents may adopt dangerous coping strategies and avoid the program. Poor messaging in multilingual communities could be misinterpreted or ignored.

Impact: Residents following unsafe advice (drinking alcohol, using fans during extreme heat without airflow) could experience preventable heat illness. Uptake of cooling centers and enrollment in the registry could drop by 10–20% if residents distrust the message or believe unsafe alternatives. Estimated reach loss: 1000–2000 residents in a city of 170k–200k. Media or social-media backlash if a preventable death occurs after resident ignored the program's guidance.

Likelihood: Medium
Severity: High

## Action

Develop a pre-season communications strategy by Month 1 (2026-11-08) that includes positive messaging (cooling centers as safe, welcoming spaces), explicit myth-busting (alcohol does not help; fans can worsen extreme heat if airflow is stagnant) and trusted messengers (pharmacists, GPs, caretakers, faith leaders with pre-approved scripts). Test key messages with focus groups of older residents and recent migrants at Month 1 (2026-11-08) to ensure clarity and uptake. Deploy messaging via radio (most common channel for 65+), pharmacy posters, door hangers and SMS (opt-in) in the city's main spoken languages plus visual guides (pictograms). Assign a communications officer to monitor social media and local forums during alert days and respond to misinformation within 2–4 hours with corrected facts and credible sources.

# Risk 11 - Operational

The plan relies on municipal and contracted staff deployed across multiple sites and alert days with limited advance notice (heat forecasts are typically issued 3–5 days before an event). Staffing for centers, transport dispatch, phone line and street teams will face fatigue and absences during multi-day heat waves, especially if staff are not full-time or do not have standby reserves.

Impact: During a 5–7 day heat wave, cooling centers may operate at reduced hours due to staff absences (sickness, fatigue, childcare conflicts). Transport dispatch may slow if dispatcher is overwhelmed or absent. Outreach phone line may have long wait times (>10 minutes) for vulnerable residents. Estimated service degradation: 10–25% reduction in center hours, 15–30 minute delays in transport dispatch, partial closure of phone line during peak hours.

Likelihood: High
Severity: Medium

## Action

Hire or contract for 20–30% staffing reserve capacity (additional part-time center staff, backup dispatcher, on-call phone operators) to cover absences and multi-day surges. Cross-train staff across roles (e.g., center managers can back up phone dispatch) to allow flexible redeployment. Establish a rota system that limits consecutive alert-day shifts to 3–4 days per person and mandates 1–2 days rest between multi-day events. Contract two dispatchers and a backup coordinator, not one. Use a mix of municipal staff and a partnered call-center service (e.g., municipal health line) that can surge capacity during alerts. Conduct fatigue-management training with managers by Month 3 (2027-01-08), including recognition of burnout and peer-support protocols.

# Risk 12 - Financial

The €3.5M budget is staged as €2.0M initial and €1.5M at Month 4 (2027-02-08), with no contingency buffer explicitly identified. Costs may overrun in procurement (supplier price increases), staffing (market wages higher than estimated) or transport (taxi retainer rates increase as summer demand peaks).

Impact: If procurement or staffing costs overrun by 10–15%, the initial €2.0M will be exhausted before Month 3 (2027-01-08), forcing delays in hiring, kit distribution or center operations. If transport costs exceed budget by €100,000–200,000, home-kit installations or outreach phone line will be defunded. Estimated budget shortfall under 15% overrun: €200,000–300,000.

Likelihood: Medium
Severity: High

## Action

Reserve 8–10% of each phase as contingency (€160,000 from initial €2.0M, €120,000 from second tranche €1.5M, total €280,000). Pre-benchmark costs for kits, transport, staffing and procurement before Month 1 (2026-11-08) against market quotes to confirm budget adequacy. Track monthly spend against forecast and reforecast cash flow by Month 2 (2026-12-08) and Month 3.5 (2027-01-23) to identify overrun risks early. If overruns appear likely, prioritize: (1) maintaining center and transport operations for gates; (2) staffing for phone line and outreach; (3) home kits (can be partially deferred to Year 2 if needed). Negotiate fixed-price transport and kit-supply contracts (not cost-plus) by Month 1 (2026-11-08) to lock in rates and avoid summer spikes.

# Risk 13 - Operational

Outreach to unhoused people (via street teams or NGO partners) involves contact with individuals in acute distress and creates duty-of-care ambiguities. Street teams may face hostility, and consent protocols for providing water, transport or cooling access to someone in acute heat illness who is not enrolled are undefined.

Impact: Street outreach staff may be assaulted or abused during alert-day contact; without clear safety protocols, psychological harm and staff turnover could result. Consent and safeguarding failures could lead to litigation. Estimated cost of staff incident response (counseling, leave, recruitment): €10,000–20,000.

Likelihood: Medium
Severity: High

## Action

Co-design street-contact protocols with homeless-service NGOs and occupational health by Month 1 (2026-11-08). Define consent models for acute distress (e.g., assumed consent for water/shade if person is incoherent but alert enough to accept help), escalation rules for calling EMS, and clear off-duty procedures if staff are threatened. Provide all street-contact staff (city or NGO) with de-escalation and trauma-informed care training before Month 2 (2026-12-08). Pair each street team with a supervisor or co-worker, not solo outreach. Establish a rapid incident-reporting and staff-support system: any incident (assault, distressing scene) triggers same-day debriefing and access to occupational health. Ensure insurance and safeguarding liability are clarified in NGO partner agreements before work begins.

# Risk 14 - Operational

The plan depends on reliable forecasts from the national meteorological service to trigger alert levels. If forecasts are uncertain, delayed or wrong, the city may fail to activate centers in time or over-activate on false alarms, wasting budget and eroding trust.

Impact: A late-issued forecast (24 hours before onset) could delay center opening by 6–12 hours, missing early-morning heat peaks. An incorrect forecast that predicts extreme heat that does not materialize could trigger unnecessary full activation, burning €5,000–10,000 in center-hours and staffing costs. Repeated false alarms could erode public trust and staff readiness. Estimated financial impact: €20,000–50,000 per incorrect trigger.

Likelihood: Low
Severity: Medium

## Action

Establish a direct relationship with the national meteorological service (and local university weather station if available) by Month 1 (2026-11-08) to receive forecasts 5–7 days in advance and clarify confidence intervals. Define alert thresholds to include a marginal advisory tier (for forecasts with lower confidence or borderline temperatures) that triggers phone check-ins and pre-positioned supplies only, not full center activation. Reserve full activation for forecasts with high confidence and clear threshold exceedance. Publish the alert forecast to partners and residents 24 hours in advance. Conduct post-event review of forecast accuracy and alert-trigger decisions monthly to refine thresholds and trust in the forecast.

# Risk 15 - Integration & System

Health system coordination relies on daily aggregate counts of heat-related EMS calls and ED visits, but hospitals and EMS may lack standardized coding for heat-related presentations or may not be able to produce daily counts without disrupting operations. If data is delayed, coded inconsistently or incomplete, the city cannot verify health impact or adjust operations mid-season.

Impact: Missing or late daily EMS/ED data could delay escalation decisions during a multi-day heat wave by 12–24 hours. Without reliable health data, the Month 4 (2027-02-08) gate evaluation of program impact will be unreliable, risking credibility of the scaling cost model. Estimated data-access delay: 2–4 weeks due to IT and reporting processes.

Likelihood: Medium
Severity: Medium

## Action

Negotiate a data-sharing MOU with hospitals, EMS and primary care by end of Month 1 (2026-11-08), specifying (1) daily aggregate counts of ED visits and EMS calls coded as heat-related (to be agreed with clinical teams), (2) delivery of counts by 10 a.m. the next day via secure email or API, (3) a simple standardized form to ensure consistency. Conduct a 2-week data-validation pilot in April to test the reporting process and identify IT/coding gaps. Establish a fallback: if daily data cannot be produced, agree on weekly aggregate counts sufficient for trend analysis. Publish daily and weekly aggregate counts in a simple dashboard accessible to city operations staff (not the public, to protect privacy) so decisions can be made.

# Risk 16 - Operational

The plan includes mandatory heat-protection clauses in municipal contracts (adjusted work schedules, breaks, water, shade). Enforcement requires site inspections and contractor compliance monitoring, which consume municipal public-works staff capacity. Private employers outside municipal contracts are only encouraged via guidance; uptake and compliance are uncertain.

Impact: Without dedicated inspector capacity, contractor compliance with heat clauses will be spotty. Private employer adoption of heat guidance is likely to be <30% without regulatory incentive, leaving outdoor workers at private firms (construction, agriculture, delivery) at continued risk. Reputational risk: if a municipal contractor or private-firm outdoor worker suffers preventable heat illness, media and unions will question the program's effectiveness.

Likelihood: Medium
Severity: Medium

## Action

Designate one municipal public-works supervisor or contracted health-and-safety officer as heat-compliance monitor, with authority to conduct spot inspections of municipal and contracted outdoor work sites during alert days. Develop a simple heat-compliance checklist (schedule changes, water availability, shade areas, mandatory rest breaks, worker education) and conduct unannounced site visits to at least 50% of active contracts each summer. Document findings and issue corrective notices to contractors within 48 hours of non-compliance. For private employers, publish a heat-protection guidance pack (English and main languages in the city) by Month 1 (2026-11-08) and promote it via chambers of commerce, employer associations and local media. Offer free consultation to employers on heat-protection plans. Tie any municipal incentives (e.g., procurement bonus points) to certified heat-protection training for private firms, incentivizing voluntary adoption.

# Risk 17 - Integration & Stakeholder

The plan requires partnerships with housing associations, social services, NGOs, pharmacies and faith organizations to conduct outreach and refer residents. If partner engagement is weak, partners lack capacity or priorities change mid-season, enrollment and contact rates will collapse.

Impact: Loss of a key partner could reduce outreach reach by 10–20%. If social services deprioritize heat outreach during a busy month, contact attempts could drop from planned 5000/month to 3000/month, failing the 60% contact-success gate. Estimated reach loss: 500–1000 residents per alert period.

Likelihood: Medium
Severity: Medium

## Action

Sign formal partnership MOUs with housing associations, social services, NGOs and pharmacy chains by end of Month 1 (2026-11-08), including outreach commitments, data-sharing terms, liability and escalation contacts. Conduct joint quarterly planning meetings (Months 1, 4, 7, 10 = 2026-11-08, 2027-02-08, 2027-05-08, 2027-08-08) to review capacity, adjust targets and resolve conflicts. Establish a dedicated partner liaison officer (city-side) who maintains monthly contact, monitors capacity and escalates issues early. Provide partners with training, scripts and real-time feedback on performance (call counts, contact success) to maintain engagement. Build contingency: if a key partner drops out mid-season, identify a backup partner (second social service, NGO coalition) by Month 2 (2026-12-08) and brief them as standby.

# Risk 18 - Operational

The plan aims for average transport time-to-pickup of <45 minutes during alert days. This depends on volunteer driver availability, taxi retainer response times and geographic distribution of residents needing transport. During peak demand (early morning of a heat day), dispatcher may be overwhelmed and wait times could exceed 45 minutes.

Impact: If average transport time climbs to 50–60 minutes, the Month 4 (2027-02-08) gate (<45 minutes) will be failed, triggering a scale-back in funding and credibility. Residents waiting >1 hour for transport may decide not to travel to a cooling center, reducing utilization.

Likelihood: Medium
Severity: Medium

## Action

Hire or contract two dispatchers and one backup coordinator for the transport system to handle simultaneous requests during peak alert-day demand. Pre-position volunteer drivers and a taxi retainer fleet by 7 a.m. on each forecast alert day, so resources are standing by and not deployed elsewhere. Set dispatch software or spreadsheet to prioritize elderly and mobility-limited residents (target 30 minutes), then others (target 45 minutes). Conduct a transport stress test in May using a simulated alert scenario (5–10 transport requests in 2 hours) to measure actual dispatch performance and identify bottlenecks. If stress test shows average times >45 minutes, increase taxi retainer capacity or recruit additional volunteer drivers before June. Track average transport time daily during summer alerts and report to the city coordinator.

# Risk 19 - Operational

Multilingual outreach and communications must reach recent migrants and residents with limited local-language skills, but translation and interpretation services are expensive and time-consuming. If communications are offered only in the city's main language(s) and English, significant populations may be excluded.

Impact: Recent migrants from non-European language groups may miss alerts or enrollment information, reducing reach by 10–20% in neighborhoods with high migrant density. Estimated reach loss: 500–1500 residents per city, depending on migrant population proportion. Reduced uptake could fail outreach-contact-success gates if migrant communities are under-counted.

Likelihood: Medium
Severity: Medium

## Action

Identify the city's top 4–6 spoken languages by recent migrants (via municipal integration data, census or NGO networks) by Month 0 (2026-10-08). Procure interpretation services for the phone line (remote interpreter on standby during alert days) and translation of key materials (alert flyers, enrollment scripts, cooling-center welcome guides) by Month 1 (2026-11-08). Partner with migrant community associations to recruit community language ambassadors (paid part-time roles, 10–15 hours/week during summer) to deliver messages, accompany door-knocks and staff cooling-center welcome desks in their own languages. Test translated materials with focus groups of native speakers at Month 1 (2026-11-08) to ensure accuracy and cultural appropriateness. Deploy translated door hangers, flyers and SMS in selected neighborhoods with high migrant density. Budget: €15,000–25,000 for translation, interpretation and ambassador stipends.

# Risk 20 - Reputational & Social

A resident or visitor to a cooling center could suffer a preventable health event (heat stroke, cardiac event, fall) if the center is not staffed with first-aid capacity and there is no clear escalation to medical care. If such an incident occurs and media coverage ensues, the program could be blamed for inadequate safeguarding despite best efforts.

Impact: A serious incident at a cooling center could lead to litigation, regulatory complaint and loss of public trust. Reputational damage could reduce center uptake by 10–20% and invite political scrutiny of the program's continuation. Estimated legal and reputation cost: €50,000–100,000.

Likelihood: Low
Severity: High

## Action

Ensure every cooling center is staffed by at least one person with first-aid certification (refreshed annually) and a defibrillator (AED) on-site with staff trained in its use. Establish rapid escalation to 112 (emergency services) with pre-positioned phone line and clear incident-reporting protocols. Conduct center managers in basic heat-illness recognition and first-response (cold water, rest, elevation) by Month 2 (2026-12-08). Run quarterly first-aid refresher drills at each center (April, June, September) to keep skills sharp. Draft incident-response and incident-reporting templates so that any event is documented, reviewed by the city health officer and escalated if needed. Ensure liability insurance covers center operations and staff are aware of coverage limits. Communicate center first-aid and emergency procedures clearly to residents on entry (signage, staff introduction) to set expectations.

# Risk 21 - Operational

The plan includes home installation of fans and shading by a handyperson service, which requires safety checks to ensure fans are used safely (directional airflow in extreme heat, not recirculating hot air) and shading installation does not create fire hazards or building-code violations. If safety checks are skipped or insufficient, residents could misuse fans and suffer harm, or insurance and liability issues could arise.

Impact: Resident misuse of installed fans could worsen heat illness rather than help. Installation of external shading that violates building codes or historic-preservation rules could trigger enforcement action and removal. Estimated remediation or legal cost: €10,000–30,000.

Likelihood: Low
Severity: Medium

## Action

Require all home-installation work (fans, shading) to be carried out by certified handypersons or contractors who have completed a 2-hour heat-safety and installation-safety training by Month 2 (2026-12-08). Training must cover (1) proper fan use (directional airflow, outdoor-air intake, not closed-room recirculation), (2) safe installation on exterior surfaces (wind resistance, fire safety), (3) checking building-code compliance before work, (4) simple written guidance left with the resident on safe fan use and water intake. Conduct spot inspections of 10–20% of installations (selected randomly and by risk level) by a municipal building inspector or external quality auditor to verify workmanship and code compliance. Provide all residents receiving installations with written guidance (translated) on safe use.

# Risk 22 - Operational

The plan declares cooling centers and support services during heat alerts, then requires rapid stand-down when the alert ends. Staff, volunteers and partners may remain in alert mode longer than needed (treating borderline cases as emergencies, over-utilizing services), inflating costs and prolonging fatigue. Conversely, premature stand-down could leave residents vulnerable if heat returns within days.

Impact: Prolonged over-alert activation could increase operational costs by 15–25% (€75,000–125,000 over the summer if 2–3 alerts occur). Premature stand-down followed by rapid heat return could cause service gaps and trust erosion.

Likelihood: Low
Severity: Low

## Action

Define clear stand-down criteria in the alert protocol: cooling centers, transport dispatch and outreach phone line stand down when the forecast no longer meets alert thresholds and temperatures have been normal for 48 hours. Assign the city incident commander authority to issue stand-down orders and communicate them to all partners and the public within 2 hours. Include stand-down procedures in the Month 2 (2026-12-08) readiness gate training and drill. Check forecasts daily during summer and issue updates to partners each morning. Conduct a mock stand-down drill in May to practice the process.

# Risk 23 - Financial & Governance

The plan is a 12-month pilot with a requirement to produce a repeatable playbook and scaling cost model for other EU cities by Month 12 (2027-10-08). Documenting, costing and refining the model requires staff time and data analysis that may not be budgeted separately, and the playbook's transferability to very different EU cities is uncertain.

Impact: If playbook documentation is not funded explicitly, it will be rushed or incomplete, limiting its value to other cities. Playbook reuse by cities with different housing stock, climates, demographics and legal frameworks may require substantial local adaptation. Estimated effort: 300–500 staff-hours for playbook drafting, cost modeling and validation. If not budgeted: incomplete or late delivery.

Likelihood: Medium
Severity: Low

## Action

Assign a dedicated playbook and evaluation officer (0.5 FTE for Months 9–12 = 2027-07-08 to 2027-10-08, or 1 FTE for Month 12 = 2027-10-08 post-season) within the budget to lead documentation work. Begin playbook drafting in Month 8 (2027-06-08) (not after the season ends) so lessons are captured while fresh. Include sections on: (1) decision rationale and trade-offs for each element; (2) SOPs and checklists for each role; (3) budget breakdown by cost type and scaling assumptions; (4) city-specific adaptations (housing stock, climate, demographics); (5) replication checklist for other EU cities. Conduct playbook testing with a peer city at Month 11 (2027-09-08) to identify gaps and refine guidance. Publish a draft playbook by Month 11 (2027-09-08) and final version by Month 12 (2027-10-08). Cost model must include unit costs (€/person enrolled, €/center-hour, €/transport trip) and assumptions about how these scale to city size and climate.

# Risk 24 - Operational

The plan's success hinges on achieving 80% of planned cooling-center hours, 60% outreach contact success and <45-minute transport time at the Month 4 (2027-02-08) gate. If any gate fails, €1.5M scale funding may not be released, forcing mid-season contraction. However, the gate measurement period (early summer, June–July) may not include sufficient heat events to test performance fairly.

Impact: If June–July are cooler than normal and no alert thresholds are crossed, gates cannot be measured against real heat events. Scale funding delay could force closure of some centers or transport capacity by August, harming residents during the peak-risk period. Estimated impact: 2–4 week delay in scale funding release or non-release if gates are deemed unmeasurable.

Likelihood: Medium
Severity: Medium

## Action

Revise gate criteria to allow measurement via formal drills and simulated alert scenarios if real heat events are insufficient. Pre-specify a drill protocol by Month 3 (2027-01-08) that mirrors alert-day operations (all centers open, transport mobilized, phone line active for 4–6 hours) and is conducted in April or May (before the Month 4 = 2027-02-08 gate). Measure drill-based performance (center hours delivered, transport response time, outreach phone line wait time) and staff observations. Document drill results and use them to validate the Month 4 (2027-02-08) gates alongside any early real-event data. Include contingency decision: if insufficient heat events or drill results are available by Month 4 (2027-02-08), release 50% of the €1.5M to sustain operations through summer and defer full-release decision to Month 5 (2027-03-08) (based on June data).

# Risk 25 - Strategic & Organizational

The plan requires a mayor's-office incident commander (or delegated authority) to declare alerts and coordinate cross-department action. If the mayor's office is distracted by other crises or transitions (staff turnover, election cycles), incident command may weaken or become politicized, leading to delayed or inconsistent alert decisions.

Impact: Delayed alert declarations could cost 12–24 hours of response time during a critical heat event. Politicized alerts could erode scientific credibility and partner trust. Staff turnover could orphan the heat program mid-summer if the new administration deprioritizes it.

Likelihood: Low
Severity: Medium

## Action

Establish a written delegation of authority for heat-alert declaration, signed by the mayor and filed with the municipal legal department, specifying (1) the trigger criteria (forecast thresholds), (2) who can declare (incident commander, deputy, backup), (3) escalation chain if the primary commander is unavailable, (4) that alert declarations are evidence-based and not subject to political review. Ensure the deputy incident commander (from public health) has clear authority to declare if the mayor's office is unavailable. Conduct cross-training so the health department, civil protection and city council each understand the alert protocol independently. Include heat-program continuity in the mayor's transition briefing if elections or staff changes occur. Protect the heat-program officer role (1 FTE) from year-to-year budget cuts by framing it as ongoing business continuity, not a temporary project.

# Risk Summary

This 12-month municipal heatwave mortality-reduction program faces moderate-to-high operational, financial and reputational risks concentrated in the Month 2 (2026-12-08) and Month 4 (2027-02-08) readiness and scale gates. The three most critical risks are: (1) Supply-chain and procurement delays for cooling kits and transport contracts—if these do not arrive by February, the program cannot deploy home interventions or guarantee transport capacity in time for the first summer heat events, jeopardizing both the Month 2 (2026-12-08) and Month 4 (2027-02-08) gates and forcing budget reallocation. (2) Gate validation during cool season—the Month 4 (2027-02-08) gates (80% center hours, 60% outreach success, <45-minute transport) depend on real heat events or drills occurring by June; if June–July are cool, gates cannot be fairly measured, risking non-release of €1.5M scale funding and mid-summer operational collapse. (3) Staffing and volunteer availability—if street-contact, cooling-center and transport-dispatch teams are under-staffed or under-trained by June, they will fail to meet gates and leave residents at risk during peak summer heat.

Mitigation priorities: (a) Front-load procurement and contracting by end of Month 1 (2026-11-08) with contingency suppliers and price locks; (b) Redefine gates to allow drill-based evidence alongside real events and include a contingency funding model if gates are delayed; (c) Launch volunteer recruitment immediately and conduct staffing stress tests by May.

Secondary risks include GDPR compliance uncertainty, partner capacity and engagement, technology integration failures, and reputational damage from operational failures or misinformation. The plan is viable if these gate and staffing risks are actively managed from Month 0 (2026-10-08) onward, with clear decision points at Months 1, 2, 3.5 and 4 (2026-11-08, 2026-12-08, 2027-01-23, 2027-02-08).

# Make Assumptions
# Question 1 - Pilot Site Selection and Heat-Mortality Baseline

Assumptions:

- Castellón de la Plana (Spain, ~170k population) selected as pilot given Mediterranean climate, large elderly population (65+ ~20%) and existing municipal assets.
- Baseline heat-related EMS calls estimated at 80–120 calls per summer season (May–September).
- Heat-attributable excess mortality estimated at 15–25 deaths per summer using temperature-mortality regression methods.
- Figures provisional pending access to municipal EMS records and health department mortality data.

## Baseline Data Availability and Accuracy Assessment

Establishes the quantifiable baseline against which program impact will be measured and confirms whether historical heat-mortality and heat-related EMS data are available and reliable for gate evaluation and attribution analysis.

Baseline data quality is critical for the Month 4 (2027-02-08) scale gate and for credibly evaluating harm reduction by Month 12 (2027-10-08).

Risks:

- Three-year historical data may not exist if the city has not previously tracked heat-related calls systematically, forcing baseline estimation from proxy data.
- Coding inconsistency across EMS providers or summers could introduce 10–30% noise into baseline estimates.
- Mortality data requires manual chart review or cause-of-death coding that may take 4–8 weeks to obtain.

Mitigation:

- Request EMS and mortality data by Month 0 (2026-10-08).
- Conduct rapid data-quality audit by Month 1 (2026-11-08).
- Agree with health partners on heat-attribution coding before Month 2 (2026-12-08) readiness gate so drill and real-event data can be compared consistently.

Opportunity: Strong baseline enables robust attribution and strengthens playbook credibility for scaling to other cities.

# Question 2 - Governance and Incident-Command Authority

Assumptions:

- A written delegation of authority will be signed by the mayor by Month 1 (2026-11-08), clearly stating trigger thresholds (forecast daytime high ≥35°C and night-time low ≥22°C for three consecutive days).
- Delegation specifies who declares alerts (mayor or named deputy) and backup authority if the primary commander is unavailable.
- Delegation filed with municipal legal department and briefed to city council.
- Cross-training ensures health, civil protection and public-works departments can operate independently of mayoral day-to-day involvement.
- Authority is non-delegable to political advisors; only municipal officers have trigger authority.

## Governance and Incident-Command Authority Clarity Assessment

Evaluates whether alert-declaration authority is clear, insulated from politicization, and robust against staff transitions or organizational disruptions.

Ambiguous authority or political oversight of alert declarations carries severe reputational risk: delayed alerts cost response time; politicized alerts undermine scientific credibility and invite media scrutiny if a preventable death occurs.

Risks:

- Mayor's office may resist formal constraint of authority.
- If delegation is unsigned or vague, the city may face legal challenge if decisions are questioned.
- Staff turnover (e.g., new mayor after elections) may orphan the program unless the delegation is embedded in city ordinance or charter, not just a memo.

Mitigation:

- Embed delegation in municipal ordinance if possible (higher authority, survives staff change).
- Brief all relevant departments jointly so everyone understands the protocol independently.
- Frame delegation as routine emergency-management practice, not a constraint on mayoral authority.

Opportunity: Clear authority speeds decisions by hours during critical alerts and demonstrates professional governance to EU peer cities and auditors.

# Question 3 - Geographic and Demographic Vulnerability Mapping

Assumptions:

- Castellón de la Plana ~170k population, ~90% urban, 20% aged 65+, ~5–8% recent migrants (North African, sub-Saharan, Eastern European; primary languages Spanish, Arabic, Portuguese).
- ~15% living alone; ~25% in top-floor flats or poorly insulated social housing.
- Most vulnerable neighborhoods are north and west peripheral blocks (built Soviet-era or 1970s, poor insulation, high concentrations of 65+, renters) and central historic quarter (elderly homeowners, limited AC, narrow streets trapping heat).
- Figures are estimates pending municipal census and housing survey data.

## Geographic and Demographic Vulnerability Mapping Assessment

Validates the spatial distribution of high-risk residents to confirm that cooling centers and outreach are positioned to reach the most vulnerable, and that equity metrics can track coverage by deprivation and demographic bands.

Precise vulnerability data determines whether the network footprint is adequate and where home kits should be concentrated.

Risks:

- If vulnerable populations are unmapped, the city may build a network that misses high-need areas.
- Postcodes/neighborhoods may not align with administrative wards, complicating equity tracking.
- Language and migration data from municipal sources may be dated and under-count undocumented residents.

Mitigation:

- Combine census, GP-registered patient lists, housing-association data and NGO local knowledge (Months 0–1 = 2026-10-08 to 2026-11-08) to build a rapid vulnerability heat-map.
- Use this to confirm cooling-center site selection and outreach-partner allocation.
- Track coverage metrics by neighborhood throughout the summer.

Opportunity: Vulnerability map becomes a reusable tool for other years and for scaling to peer cities.

# Question 4 - Staffing Plan and Retention

Assumptions:

- Mid-sized city pilot requires ~35–50 FTE total for May–September (5-month operational season): ~2–3 FTE coordination/command; ~12–18 FTE cooling-center staffing; ~4–6 FTE outreach; ~2–3 FTE transport dispatch; ~2–3 FTE phone line; ~5–10 FTE handyperson or contracted installers (February–May).
- Most staff (centers, outreach, transport) are part-time or seasonal (alert-day only).
- Volunteer drivers (~30–50) and center helpers (~20–30) supplement paid staff.
- Hiring begins Month 0 (2026-10-08); all staff in post by April 30 (Month 6.7 = 2027-04-29).
- Retention strategy: clear role descriptions, fatigue management, peer support, pro-rata leave entitlements.

## Staffing Availability, Readiness and Retention Assessment

Evaluates whether realistic staffing numbers can be recruited, trained and retained to meet operational gates and maintain morale during multi-day heat-wave surges.

Staffing is the most likely source of Month 2 (2026-12-08) and Month 4 (2027-02-08) gate failure.

Risks:

- Seasonal hiring (February–April) competes with other municipal summer hiring; part-time and temporary roles may attract lower-quality candidates.
- Training 50+ people (staff + volunteers) in parallel to procurement and partner negotiations stretches coordination capacity.
- Volunteer recruitment may under-deliver if response is poor in autumn/winter when heat feels distant; safeguarding vetting can take 4–8 weeks and bottleneck dispatch-driver start-dates.
- Staff fatigue during multi-day heat waves (7+ consecutive alert days) will drive absences and turnover mid-season.

Mitigation:

- Designate a recruitment/HR coordinator (0.5 FTE, Months 0–4 = 2026-10-08 to 2027-02-08) by Month 0 (2026-10-08).
- Launch volunteer recruitment in October–November (when heat safety is topical).
- Stagger staff hiring in cohorts (40% in January, 40% in February, 20% in March) so training is incremental and retention can be evaluated early.
- Establish fatigue-management protocols and cross-training by Month 2 (2026-12-08).

Opportunity: Rigorous staffing planning can serve as a model for other EU cities and reduce chaotic hiring and rework.

# Question 5 - Procurement and Contracting Timeline

Assumptions:

- Procurement follows a staged approach: fast frameworks or below-threshold purchasing for kits, handyperson services and initial transport by Month 1.5 (2026-11-23), releasing €500k–700k for immediate orders.
- Full competitive tenders for longer-lead items (transport standby retainers, multi-site security contracts) by Month 2 (2026-12-08).
- Delivery of 40–50% of kit stock by Month 4, 80 (2027-02-08, 2033-06-08)% by Month 5, 100 (2027-03-08, 2035-02-08)% by Month 6 (2027-04-08).
- Transport contract signed by January 31 (Month 3.7 = 2027-01-29); handyperson and installer teams in place by February.
- Procurement assumes 4–6 week lead time for kits and 2–3 week notice for transport activation.
- Backup suppliers identified for kits, handyperson services and transport before Month 1 (2026-11-08).

## Procurement Speed, Risk and Budget Execution Assessment

Evaluates whether the procurement pathway can meet the Month 2 (2026-12-08) readiness gate without compromising quality, competition or audit compliance, and whether supply-chain risks are mitigated.

Procurement is the critical path to the Month 2 (2026-12-08) gate. If kits, transport or center fit-out are delayed beyond Month 5 (2027-03-08), home interventions and transport capacity will miss the first summer heat events.

Risks:

- Below-threshold and framework purchasing reduce competition and may yield higher unit costs; audit scrutiny may arise if sole-source or repeat use of the same vendors is challenged.
- Transport retainers lock in capacity but cost €50k–80k for standby (not used) unless a hot summer occurs; taxi suppliers may raise rates during peak summer demand.
- Kit suppliers may face production delays and miss February delivery; without backup suppliers, the program loses 2–4 weeks.

Mitigation:

- Issue specs for kits and services by October 31 (Month 0.8 = 2026-11-01).
- Contact suppliers immediately to confirm availability and lead times.
- Place first call-off order for 30–40% of kit volume by November 15 (Month 1.2 = 2026-11-14) to secure stock.
- Identify 2–3 backup suppliers for each category (kits, handyperson, transport) by Month 1 (2026-11-08).
- Lock in transport retainer rates by contract by end of Month 1 (2026-11-08) before summer demand spikes.

Opportunity: Transparent, benchmarked procurement builds playbook reusability across EU cities.

# Question 6 - Gate Measurement Validity and Contingency Funding

Assumptions:

- Month 4 (2027-02-08) gate measurement window includes both real heat events (if temperatures exceed thresholds May–July) and formal operational drills.
- A drill protocol pre-specified by Month 3 (2027-01-08), defining mock-alert scenarios (4–6 hour activation, all centers open, transport and phone line mobilized, outreach calls to sample enrolled residents).
- Drill performance data compared against gate targets alongside any real-event data.
- If both drills and real events fall short of sufficient evidence by Month 4 (2027-02-08), gate decision deferred to Month 5 (2027-03-08) with 50% of the €1.5M scale funding released contingently.

## Gate Measurement Validity and Contingency-Funding Assessment

Evaluates the fairness and feasibility of measuring operational gates during a cool season, and proposes contingency decision-rules to avoid non-release of funds due to weather chance.

Early summer (June–July) weather is unpredictable. If June–July are cooler than normal, alert thresholds will not be crossed, preventing real-world gate testing.

Risks:

- If June–July are cooler than normal (25% probability in Mediterranean climates), alert thresholds will not be crossed.
- Drill-based evidence may be viewed as weaker than real-event data by funders or auditors.
- If gates are not released on schedule, the program will face a budget shortfall by August (estimated €200k–400k) and may be forced to close some centers mid-summer.

Mitigation:

- Draft drill protocol by Month 2.5 (2026-12-23), specifying date, duration, participant roles and target metrics.
- Conduct a full-system drill by Month 7 (2027-05-08) with all centers, transport, phone and outreach staff.
- Document drill results rigorously (center-hours opened, transport requests and response times, phone-line call volume and wait time, outreach contact attempts).
- Redefine gate decision rule: release €1.5M on time if (real heat events + drill data) demonstrate ≥80% center hours, ≥60% outreach success and <45-min transport.
- If evidence is mixed, release 50% contingently by Month 4 (2027-02-08) and defer full release to Month 5 (2027-03-08) based on June real-world data.

Opportunity: Robust gate protocol demystifies funding decisions and builds stakeholder confidence in program management.

# Question 7 - Multilingual Access and Equity Reach

Assumptions:

- Top 4–6 spoken non-official languages (estimated): Spanish pilot—Arabic, Portuguese, Romanian; Polish pilot—Ukrainian, Vietnamese, Russian; Italian pilot—Romanian, Albanian, Arabic.
- These communities represent 5–15% of the population but may be concentrated in 2–3 neighborhoods.
- Translation and interpretation services include: professional translation of key materials into each language by Month 1 (2026-11-08); telephone interpretation service for the heat-line and outreach staff; recruitment of 8–12 paid community-language ambassadors (part-time, 10–15 hrs/week during alert season); pictogram-first designs for door hangers and center signage.
- Reach verification: track language of enrollment contacts and verify that non-official-language speakers comprise ≥5% of outreach calls.

## Multilingual Access and Equity Reach Assessment

Evaluates whether language-access strategies will ensure recent migrants and non-native speakers can receive life-saving alerts and escalation guidance without delay, and whether coverage can be verified.

Excluded or delayed communication to non-native speakers could constitute health and equity harm.

Risks:

- Professional translation alone is expensive (~€15k–25k for 4–6 languages) and does not build trust or address cultural barriers.
- Ambassadors take 6–8 weeks to recruit, vet and brief (months 0–2 = 2026-10-08 to 2026-12-08), creating timeline pressure.
- Telephone interpretation services scale quickly but may be impersonal and ineffective for residents who avoid formal systems.
- Without pre-testing translated messages with native speakers, translations can be culturally inappropriate or medically inaccurate.
- Language reach tracking requires outreach staff to log the language used in each contact, adding administrative burden and potential privacy issues.

Mitigation:

- Identify top languages and ambassador candidates by Month 0 (2026-10-08) through municipal integration offices and NGOs.
- Commission professional translation of top 3–4 languages by Month 1 (2026-11-08).
- Recruit ambassadors in parallel (months 0–2 = 2026-10-08 to 2026-12-08) and conduct focus-group testing of translated materials with native speakers before Month 2 (2026-12-08).
- Budget for interpretation services (€200–300/day during alert days) in addition to ambassadors.
- Track language diversity in outreach calls via simple log form; audit 10% of calls by spot-check to verify language protocols are followed.

Opportunity: Multilingual messaging demonstrates inclusive governance and provides a reusable, transferable model for other EU cities with diverse migration profiles.

# Question 8 - GDPR Compliance and Data Protection

Assumptions:

- Intermediary-held-list model complies with GDPR by: housing associations, social services and NGOs contact their own residents/clients using existing lawful bases (contractual, consent-based, public-task duties) and do not transfer personal data to the city.
- Only aggregate outreach results reported to the city (e.g., "100 residents contacted, 65 enrolled, average response time 2.5 days"), not names, addresses or health records.
- Opt-in consent forms (or partner-managed consent refresh) specify that contact is for heat-season welfare checks and can be declined.
- Data retention limited to one season (October–September) and deleted thereafter.
- Data-processing agreement (DPA) or MOU between each partner and the city clarifies data controller/processor roles, liability, breach notification and staff confidentiality.
- GDPR risk level: moderate, because contact initiated by trusted intermediaries and no personal data leaves the partner's systems.

## GDPR Compliance, Data Protection and Partner Accountability Assessment

Evaluates whether the intermediary-held-list model is legally sound under GDPR and whether partner accountability mechanisms can reduce data-protection risk and trust erosion if breaches occur.

GDPR compliance is a hard constraint for the plan's viability. The intermediary model is more protective than a city-held registry, but each partner's data-governance maturity varies.

Risks:

- If a partner lacks a clear lawful basis for calling residents, the city cannot compel contact, limiting reach.
- If a partner does not have explicit consent or a GDPR-compliant privacy notice on file, data regulator review could halt outreach mid-season.
- If a partner breaches confidentiality, the city may face legal liability and trust erosion.
- If a partner's systems are breached, residents' data could be exposed.
- Residents may withdraw consent mid-season, reducing contact base.
- Consent-refresh and data-retention mechanics are unclear.

Mitigation:

- Engage specialist GDPR legal counsel by Month 0.5 (2026-10-23) to draft template MOUs/DPAs for each partner type (housing association, social service, NGO, pharmacy).
- Specify lawful basis (public-task/consent hybrid is typical for welfare), contact frequency, consent withdrawal mechanism and breach-notification procedures.
- Obtain written legal sign-off by Month 1 (2026-11-08).
- Brief all partners on GDPR obligations and staff confidentiality by Month 2 (2026-12-08).
- Audit partner compliance mid-season (July, Month 9 = 2027-07-08) via spot-check review of consent records and staff training logs.
- Establish a breach-reporting hotline so residents can report partner misconduct quickly.

Opportunity: Well-documented and audited GDPR compliance becomes a reusable, transferable safeguard for other EU cities and demonstrates municipal data ethics.

# Distill Assumptions
# Heat Response System – Castellón de la Plana Pilot

## Site & Baseline

- Castellón de la Plana (Spain, ~170k population) selected as pilot.
- Baseline 80–120 heat-related EMS calls per summer; 15–25 heat-attributable excess deaths per summer (temperature-mortality regression).
- 20% population aged 65+; 5–8% recent migrants; ~15% living alone; ~25% in top-floor or poorly insulated units.
- Vulnerable neighborhoods: peripheral north/west blocks (1960s–1980s, poor insulation) and central historic quarter.

## Governance & Alert Declaration

- Written mayoral delegation signed by Month 1 (2026-11-08) with clear trigger thresholds and backup authority chain.
- Alert declarations issued within 1 hour of forecast trigger.
- Incident-command structure: mayor's office incident commander with public-health deputy.
- Cross-training across health, civil protection and public works enables independent operation.

## Alert Tiers & Activation

- Low-cost advisory tier combines national warning with phone check-ins.
- Full center activation reserved for upper tiers only.

## Cooling Centers & Transport

- 8–12 small neighborhood refuges in libraries, community centers, parish halls within walking distance.
- Vetted volunteer drivers (30–50) coordinated by dispatcher; taxi backup for transport-gate protection.
- Transport time-to-arrival gate <45 minutes average including wheelchair-accessible vehicles.
- Cooling-center 80% planned-hours gate measured via real events and operational drills.

## Outreach & Enrollment

- Intermediary-held contact lists (housing associations, social services, NGOs, pharmacies) with no personal data transferred to city.
- Outreach contact-success gate ≥60% for enrolled high-risk residents on alert days.
- Data from Consent-Light Identification Routes feeds home-kit targeting, outreach and enrollment.
- Street contact pathway for unhoused residents: daytime mobile rounds, drop-in cool points, referral transport triggers.

## Language Access & Equity

- Professional translation of key materials into 4–6 locally common non-official languages by Month 1 (2026-11-08).
- 8–12 paid community-language ambassadors (part-time, 10–15 hrs/week during alert season) recruited and briefed by Month 1 (2026-11-08).
- Pictogram-first door hangers and center signage to reach non-literate residents.
- Telephone interpretation service for heat line and outreach staff during alert-day hours.
- Coverage by neighborhood deprivation index, age bands and housing type tracked as equity metrics.

## Data Protection & Consent

- GDPR-compliant data-processing agreements drafted with each partner type by Month 0.5 (2026-10-23).
- Partner-held contact data limited to one season (October–September); deleted thereafter.
- Consent forms specify heat-season welfare checks and allow mid-season withdrawal.
- Audit of partner GDPR compliance mid-season (Month 9 = 2027-07-08) via consent-record spot-checks.

## Home Intervention Kits

- Includes exterior shading, reflective blinds, window fans, thermometers, hygrometers, hydration supplies.
- Rubric-based household selection prioritizes top-floor units and social-housing blocks.
- Handyperson installation and fan-safety checks included; no major construction work.
- Lending scheme optional: kits installed May, collected September, cleaned and redeployed across seasons.
- Handyperson work scheduled February–April before center and outreach peak demand.

## Staffing & Operations

- 35–50 FTE seasonal staff (May–September) across coordination, centers, outreach, dispatch, phone line and installations.
- Hiring and training completed by April 30 to ready all staff before May summer season.
- 30% reserve staffing capacity built in to absorb multi-day surge and fatigue absences.
- Fatigue-management protocols and staff cross-training established by Month 2 (2026-12-08).
- Volunteer drivers subject to background checks, insurance, safeguarding vetting (4–8 week process).

## Procurement & Supply Chain

- Procurement of kits, transport contracts and center fit-out completed by Month 2 (2026-12-08) readiness gate.
- 40–50% of kit stock delivered by February; 80% by March; 100% by April.
- Below-threshold purchasing and frameworks used for fast kit and service procurement by Month 1.5 (2026-11-23).
- Transport standby retainer locked in by Month 1 (2026-11-08) before summer demand spike.
- 2–3 backup suppliers identified for kits, handyperson services, transport by Month 1 (2026-11-08).
- Specs for kits and services issued by October 31; first call-off order placed by November 15.

## Clinical Integration

- MOU signed with hospitals, EMS, primary care for daily aggregate counts (no identifiable patient records).
- Clinical nurse triage line for outreach staff to escalate suspected heat illness and prevent unnecessary EMS calls.

## Workplace Protection

- Heat-protection clauses in municipal employment contracts requiring schedule changes, breaks, water, shade.
- Guidance package and recognition scheme offered to private employers (non-binding).

## Public Communication & Misinformation

- Pre-season public campaign plus heat-event messaging templates via radio, flyers, pharmacy posters, door hangers, SMS.
- Trusted messengers (pharmacists, GPs, caretakers, faith leaders) briefed with consistent scripts and printed leave-behinds.
- Misinformation rebuttal channel to counter unsafe advice (alcohol, incorrect fan use in extreme heat).

## Testing & Validation

- Month 4 (2027-02-08) gate measured via operational drills if June–July temperatures below historical norms and real events insufficient.
- Pre-specified drill protocol with mock-alert scenarios defined by Month 3 (2027-01-08) to test gates fairly.
- Formal drill protocol pre-specified by Month 3 (2027-01-08); full-system drill executed by May.
- After-action report completed with corrective actions closed before Month 4 (2027-02-08) gate decision.

## Evaluation & Attribution

- Base comparison design: pilot districts vs. matched non-pilot districts and prior years, aggregate EMS and ED counts only.
- Heat-related EMS calls, ED visits, excess mortality tracked as primary outcome proxies.
- Center utilization, transport requests served, outreach attempt/success rates tracked as operational KPIs.
- Temperature-adjusted attribution for heat-day outcomes; explicit confidence ranges and attribution limits stated plainly.
- Local calibration of alert thresholds from historical temperature and mortality data, reviewed after Year 1.
- Successive consecutive hot nights weighted more heavily than daytime peaks in threshold formula.

## Funding & Gates

- Two-stage funding: €2.0M initial release; €1.5M released at Month 4 (2027-02-08) if gates met.
- Month 2 (2026-12-08) readiness gate: cooling centers contracted, staffed, transport signed, phone line operational, procurement orders placed, training completed.
- Contingency-funding rule: 50% of €1.5M released if evidence mixed; full release deferred to Month 5 (2027-03-08) if needed.

## Deliverables

- Heat Response Playbook with SOPs, checklists, scripts, procurement lists, partner MOUs delivered by Month 12 (2027-10-08).
- Cost model for city-wide scaling and replication to other EU cities delivered by Month 12 (2027-10-08).
- Data and evaluation report with limitations clearly stated delivered by Month 12 (2027-10-08).
- Year-2 roadmap identifying expansion priorities, elements to discontinue delivered by Month 12 (2027-10-08).

## Risk Management

- Reputational risk register includes politicization of alerts, failed response during media scrutiny, equity gaps.
- Volunteer-safety risk includes potential assault during street contact, safeguarding breaches, personal vehicle liability.


# Review Assumptions
# Gate Measurement Validity During Cool Season and €1.5M Release Contingency

## Issue

Month 4 (2027-02-08) gates (80% center hours, 60% outreach success, <45-minute transport) depend on June–July heat events, which are unpredictable. If temperatures fall below alert thresholds, gates cannot be measured against real events, risking non-release of €1.5M scale funding and mid-summer operational collapse.

## Recommendation

Redefine Month 4 (2027-02-08) gate to accept operational drills as valid evidence alongside real heat events. Pre-specify drill protocol by Month 3 (2027-01-08) mirroring alert-day operations (all centers open, transport mobilized, phone line active for 4–6 hours). Conduct full-system drill in May with rigorous documentation of center-hours, transport response times and outreach contact attempts. Establish contingency-funding rule: release €1.5M on time if combined real-event and drill data demonstrate gate targets; if ambiguous, release 50% contingently by Month 4 (2027-02-08) and defer full release to Month 5 (2027-03-08) based on June real data. Include €150k–200k contingency reserve within initial €2.0M to cover May–July operational costs if scale funding is delayed.

## Sensitivity

If June–July are cooler than normal (20–25% probability in Mediterranean climates), real heat events will not occur and gates cannot be tested fairly. Drill-based evidence alone may delay funding release by 3–6 weeks, forcing budget cuts. Financial impact: €200k–400k shortfall if scale release deferred from Month 4 (2027-02-08) to Month 5–6 (2027-03-08 to 2027-04-08). If gates are not released on schedule, cooling-center hours and transport capacity may contract by 25–40% by August, reducing mortality protection during peak-risk late summer.

# Supply-Chain and Procurement Timeline Compression for Cooling Kits and Transport Contracts

## Issue

Procurement of cooling kits (exterior shading, reflective blinds, fans, thermometers), handyperson services and transport contracts must be completed by Month 2 (2026-12-08) readiness gate to allow delivery by April and deployment in May–June. Lead times for kit suppliers are typically 4–6 weeks; transport retainer contracts require 2–3 week notice. Delays beyond February–March will push home-intervention rollout past the first summer heat events, missing peak-risk early season. Supply-chain disruptions or single-source dependency could force expensive expedited shipping (10–15% premium) or alternative supplier sourcing at higher cost.

## Recommendation

Issue procurement specifications and contact suppliers by October 31 (Month 0.8 = 2026-11-01) to confirm availability and lead times. Place first call-off orders for 30–40% of total kit volume by November 15 (Month 1.2 = 2026-11-14) to secure early stock. Negotiate expedited February delivery, accepting 10–15% price premium (€50k–100k estimate) if needed. Identify 2–3 backup suppliers for each category by Month 1 (2026-11-08) and pre-qualify them. Lock in transport standby-retainer rates by contract by end of Month 1 (2026-11-08). Arrange interim storage at municipal facility or partner warehouse. Keep 10–15% stock buffer pre-positioned by February for emergency deployment if heat events occur in March.

## Sensitivity

If primary kit suppliers face production delays (4–8 week slip from Asian supply-chain issues), orders placed in October–November will not arrive until March–April, delaying home interventions by 4–8 weeks. Cost impact: €50k–100k for expedited shipping and backup suppliers. If transport retainer prices spike during peak summer demand (June–August), unbudgeted increases of €150k–250k could force cuts to home-kit installations (500–1000 fewer kits estimate) or other services. If 50% or fewer kits are delivered by February (Month 4 = 2027-02-08), home interventions begin 4–6 weeks late, missing peak-risk May–June period and reducing estimated mortality reduction by 15–25%.

# Staffing Recruitment, Vetting and Fatigue Management for Multi-Day Heat-Wave Surges

## Issue

Operational readiness requires 35–50 FTE staff (cooling-center, outreach, dispatch, phone line, installers) recruited and trained by April 30 (Month 6.7 = 2027-04-29). Volunteer driver vetting (background checks, insurance, safeguarding) takes 4–8 weeks and may bottleneck dispatch-driver start-dates if recruitment response is low. During multi-day heat waves (7+ consecutive alert days in July–August), fatigue and absences will stress service continuity; part-time and seasonal staff may prioritize personal family needs over shifts, reducing capacity by 10–25%. Without 20–30% reserve staffing capacity, service degradation is likely: cooling centers operate at reduced hours, transport dispatch slows (15–30 minute delays), phone line experiences long wait times (>10 minutes).

## Recommendation

Designate recruitment/HR coordinator (0.5 FTE, Months 0–4 = 2026-10-08 to 2027-02-08) by Month 0 (2026-10-08). Launch volunteer recruitment in October–November targeting retirees, charity staff and faith-group members through NGO networks in parallel with municipal advertising. Conduct vetting in fortnightly cohorts so early cohorts are trained and road-tested by Month 1 (2026-11-08). Stagger staff hiring in cohorts (40% January, 40% February, 20% March) so training is incremental. Establish taxi-retainer backup contract by Month 1 (2026-11-08) with proportionally reduced guarantee; if volunteer numbers fall below 50% of target by Month 1.5 (2026-11-23), increase taxi retainer proportionally. Build 20–30% reserve staffing capacity (additional part-time center staff, backup dispatcher, on-call phone operators). Establish rota limits: consecutive alert-day shifts max 3–4 days, mandatory 1–2 days rest between multi-day events. Cross-train staff across roles (center managers back up dispatch). Provide fatigue-management training and peer-support protocols by Month 3 (2027-01-08).

## Sensitivity

If volunteer recruitment falls short by 30–50%, transport costs increase by €150k–250k to shift to taxi-only operation, forcing cuts to home-kit distribution (500–1000 fewer kits estimate). Baseline: 30–50 volunteer drivers; variance: if only 15–25 volunteers recruited, average time-to-transport will slip from 45 minutes (target) to 55–70 minutes, failing Month 4 (2027-02-08) gate. If vetting delays slip volunteers' start-dates by 3–6 weeks, dispatch capacity will be under-staffed until June, compromising early-May response capacity. During multi-day heat waves, staff absence and fatigue-driven reduced hours could degrade center capacity by 15–25% and increase transport wait times by 20–40 minutes. Estimated cost of staff incident response, counseling and replacement hire if burnout occurs: €10k–20k per staff member; for 5–10 staff turnover: €50k–200k total.

# Review Conclusion

This 12-month municipal heatwave mortality-reduction program is viable but faces three critical interdependent risks: (1) gate measurement during cool season with contingency-funding uncertainty—Month 4 (2027-02-08) gates depend on June–July heat events that may not occur, risking €1.5M non-release and mid-summer operational collapse; (2) supply-chain and procurement compression—kits and transport contracts must be ordered by November–December (Months 1–2 = 2026-11-08 to 2026-12-08) to arrive by February–April, or home interventions and transport capacity will miss the first summer events; (3) staffing recruitment and fatigue management—35–50 FTE staff must be hired, vetted and trained by April, with 20–30% reserve capacity to absorb multi-day surges, or operational gates will fail.

## Mitigation Priorities

- Redefine gates to accept drill-based evidence and establish contingency-funding rules by Month 2 (2026-12-08).
- Begin procurement and supplier vetting by October 2026 and place first orders by November to secure stock.
- Launch volunteer recruitment immediately and conduct staffing stress tests by May.
- Address GDPR compliance uncertainty via specialist legal review by Month 0.5 (2026-10-23).
- Mitigate partner capacity and engagement via joint MOUs and performance monitoring.
- Mitigate equity reach across language groups via community ambassadors and multilingual materials.

With active management of these risks at Months 1, 2, 3.5 and 4 (2026-11-08, 2026-12-08, 2027-01-23, 2027-02-08), the program can meet gates, protect vulnerable residents and generate a reusable playbook for other EU cities.