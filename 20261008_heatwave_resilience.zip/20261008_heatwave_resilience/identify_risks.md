
## Risk 1 - Regulatory & Permitting
GDPR compliance uncertainty despite intermediary-held lists strategy. Data-processing agreements with housing associations, social services, NGOs and pharmacies require legal review and may face delays if partners lack established data-governance frameworks. Regulatory interpretation of lawful basis for contact (consent vs. public task) varies across EU jurisdictions and may differ between Spain, Poland and Italy.

**Impact:** Legal challenge to enrollment or outreach methods could delay partner sign-off by 2–4 weeks. Withdrawal of a key partner (e.g., housing association) due to perceived GDPR risk could reduce enrollment reach by 15–25%. Estimated legal review and remediation cost: €15,000–30,000.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Engage a specialist GDPR legal firm by Month 1 (2026-11-08) to pre-review data-processing agreements with housing associations, social services and NGOs. Draft template MOUs with clear lawful basis (public task, data controller/processor split) and retention limits. Obtain written legal clearance for the intermediary-held list model and consent protocols before Month 2 (2026-12-08) readiness gate. Build a 2-week legal-review buffer into the procurement timeline.

## Risk 2 - Operational
Month 2 (2026-12-08) readiness gate (cooling centers contracted + staffed; transport contract signed; phone line operational; outreach training completed; procurement orders placed) compresses multiple parallel work streams into 8 weeks during the cool season, leaving no time for mock heat events or drill feedback loops before the gate.

**Impact:** Staff and volunteers may not be operationally ready on alert day despite formal training. Cooling-center opening-day incidents (accessibility failures, staffing gaps, poor signage) could harm public trust and damage credibility with partners. Estimated delay to full operational readiness: 2–3 weeks into the summer season. Reputational damage if media covers a preventable operational failure.

**Likelihood:** High

**Severity:** Medium

**Action:** Front-load cooling-center contracting and handover by end of Month 1 (2026-11-08) to allow 3–4 weeks of operational rehearsal (staffing placement, accessibility checks, security drills, signage installation) before the Month 2 (2026-12-08) gate. Conduct one full-system mock alert drill in March (Month 5 = 2027-03-08) with all centers, transport, phone line and outreach staff operating simultaneously. Use drill results to close gaps before June (Month 8 = 2027-06-08) summer season. Document drill findings and corrective actions formally to satisfy the Month 4 (2027-02-08) gate requirement.

## Risk 3 - Financial
€1.5M second-tranche release at Month 4 (2027-02-08) is contingent on meeting three operational gates (80% center hours, 60% outreach success, <45 minutes transport time) measured during early-season heat days. If June and July temperatures are below historical norms or fall outside alert thresholds, gates cannot be tested fairly, and the scale release may be withheld despite operational readiness.

**Impact:** Without summer heat events by Month 4 (2027-02-08), gates cannot be validated, and €1.5M release may be delayed to Month 5–6 (2027-03-08 to 2027-04-08) or denied if metrics are unverifiable. Budget burn for May–July operations (center staffing, transport standby, outreach phone line) will exceed initial €2.0M if gates are not released on schedule. Estimated shortfall: €200,000–400,000 in operational costs.

**Likelihood:** Medium

**Severity:** High

**Action:** Redefine the Month 4 (2027-02-08) gate to include formal drills and simulated alert-day scenarios as acceptable evidence, not solely real heat events. Pre-specify a 'drill protocol' by Month 3 (2027-01-08) that mirrors alert-day operations (centers open, transport mobilized, outreach phone line active for 4–6 hours) and allows gates to be tested without waiting for weather. Document drill results and staffing performance metrics to support the Month 4 (2027-02-08) release decision. Include a contingency budget reserve (€150,000–200,000) to cover May–July operational costs if natural heat events are delayed.

## Risk 4 - Operational
Volunteer driver recruitment and vetting (safeguarding, insurance, background checks) may fall short of target numbers by Month 2 (2026-12-08) if volunteer response is low or vetting takes longer than 6 weeks. Taxi backup contract alone will be inadequate if volunteer gaps exist, and standby retainers may exhaust budget allocated for home kits.

**Impact:** Fewer than planned volunteer drivers could increase average time-to-transport above the 45-minute gate target by 10–15 minutes, causing gate failure. Shift to taxi-only operation would increase transport costs by €150,000–250,000, forcing cuts to home-kit distribution (500–1000 fewer kits installed). Estimated delay in volunteer placement: 3–6 weeks.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Launch volunteer recruitment immediately at Month 0 (2026-10-08), targeting retirees, charity staff and faith-group members through NGO and community networks in parallel with HR/staffing advertising. Conduct vetting in batches (fortnightly cohorts) rather than all at once, so early cohorts are trained and road-tested by Month 1 (2026-11-08). Establish a taxi-retainer contract by Month 1 (2026-11-08) with a lower threshold guarantee than initially planned, allowing gradual scale-up of volunteer numbers. Set a trigger threshold: if volunteer numbers fall below 50% of target by Month 1.5 (2026-11-23), increase taxi retainer proportionally rather than waiting until after the Month 2 (2026-12-08) gate.

## Risk 5 - Supply Chain
Procurement of cooling kits (exterior shading, reflective blinds, window fans, thermometers, hygrometers) by Month 2 (2026-12-08) depends on supplier availability and delivery lead times. If primary suppliers are unavailable or backlogs exceed 4–6 weeks, orders placed in October–November may not arrive until February–March, delaying home-intervention rollout past the summer season.

**Impact:** If kits do not arrive until March, they cannot be installed before the first heat event in May–June. Target of priority top-floor and social-housing installations will slip to July–August at earliest, missing the peak-risk early summer period. Estimated delay: 4–8 weeks. Cost impact: if alternative suppliers charge premiums for expedited shipping, additional cost of €50,000–100,000.

**Likelihood:** Medium

**Severity:** High

**Action:** Issue procurement specifications by end of Month 0 (October 2026) to identify supplier availability and lead times. Place first call-off orders for 30–40% of total kit volume by mid-Month 1 (November 2026) to secure early stock. Negotiate expedited delivery for February arrival, accepting a 10–15% price premium. Arrange interim storage at municipal facility or a supply partner's warehouse. Keep a small stock of pre-positioned kits (shading and fans) by February to enable immediate deployment if a heat event occurs in March. Identify backup suppliers for each kit component to mitigate single-source delay.

## Risk 6 - Operational & Safety
Door-knock and street-contact outreach teams will encounter residents in heat distress or acute illness during alert days. Teams lack clinical training and may misjudge escalation severity, leading to delayed EMS calls or inappropriate advice. Safety protocols for staff encountering aggressive or vulnerable residents are not yet defined.

**Impact:** Outreach staff may fail to recognize heat stroke or severe dehydration and delay critical EMS calls by 10–30 minutes. Alternatively, over-escalation could saturate EMS with borderline cases. Staff encountering hostile or distressed residents without clear de-escalation guidance risk injury or psychological harm. Potential litigation if a resident suffers preventable harm after staff contact.

**Likelihood:** Medium

**Severity:** High

**Action:** Partner with a municipal nurse adviser or occupational health service to co-design escalation protocols for outreach staff. Include a checklist for recognizing heat illness signs (confusion, loss of consciousness, core temperature >40°C indicators, severe weakness) and decision trees for when to call EMS, advise home management or refer to 111-style phone triage. Train all outreach and street-contact staff on the protocol before Month 2 (2026-12-08) gate, with refresher drills in May. Provide safety communication cards and a check-in system so teams can report incidents and receive same-day debriefing if they encounter acute cases. Establish peer support for staff exposed to distressing scenes.

## Risk 7 - Operational
Intermediary partners (housing associations, social services, NGOs, pharmacies) will independently conduct phone outreach and enrollment on the city's behalf. Quality and consistency of outreach contact will vary; some partners may lack call-center capacity or training, leading to missed calls, poor enrollment retention or residents disengaging after the first contact.

**Impact:** Outreach contact success rate (targeting 60% for enrolled residents) may fall to 40–50% if partner call capacity is insufficient or if scripts are delivered inconsistently. Partner fatigue or turnover mid-season could drop success rate to 20–30% by July–August, failing the Month 4 (2027-02-08) gate. Estimated loss: 500–1000 contact attempts per alert day across all partners.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Co-design a detailed outreach protocol and script with each key partner (housing associations, social services, NGOs, pharmacies) during Month 0–1 (2026-10-08 to 2026-11-08). Include call targets per alert day, escalation rules and sample language. Conduct joint training for all partner staff by end of Month 1 (2026-11-08), with role-play drills using realistic scenarios. Establish a shared call-tracking dashboard (via secure spreadsheet or partner-hosted system, not city-owned) where partners log calls, outcomes and escalations daily, reviewed by the city coordinator. Monitor partner call volumes and contact success weekly; provide real-time feedback and script adjustments if success drops below 60%. Schedule mid-season partner review at Month 6 (2027-04-08) to identify and resolve gaps before gate measurement at Month 4 (2027-02-08).

## Risk 8 - Technical & Integration
The phone line (heat helpline) and transport-dispatch system will need to integrate with partner call-tracking and cooling-center occupancy data to avoid double-booking and ensure residents reach appropriate sites. If systems are not integrated (phone line is city-run, transport-dispatch is contracted, center capacity is reported manually), coordination failures will occur under peak alert-day demand.

**Impact:** Residents calling the heat line for transport may be unable to confirm center availability and wait times, leading to wasted trips or overcrowding at one site while others are empty. Transport dispatch and center staffing may not coordinate, causing residents to arrive at full sites. Estimated operational chaos: 10–20% of transport requests may be misdirected or cancelled. Reputational damage if media covers residents being turned away from overcrowded centers.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Define a simple data-integration protocol by Month 1 (2026-11-08): phone-line staff log transport requests and center of choice in a shared spreadsheet (or low-cost ticketing system) updated in real-time, transport dispatch accesses the same feed to prioritize routing, and each center reports current occupancy and capacity every 15 minutes via phone or WhatsApp to the dispatch hub. Establish a 'duty coordinator' role who monitors the shared system during alert days and authorizes dispatch redirects if a site reaches capacity. Run this protocol in the March mock-alert drill to identify bottlenecks and fix them before June. Keep the system deliberately simple (spreadsheet-based, not a custom app) to ensure rapid setup by Month 2 (2026-12-08) and resilience if cloud systems fail.

## Risk 9 - Operational
Cooling centers must meet accessibility standards (wheelchair access, quiet rooms, water, toilets) across multiple sites (libraries, parish halls, community centers, sports halls). Existing facilities may have accessibility gaps; remediation takes time and cost, and some sites may be unsuitable. If accessibility is not validated before opening, residents in wheelchairs or with sensory needs will be excluded.

**Impact:** Wheelchair-using or mobility-limited residents unable to access some sites will over-concentrate at the few fully accessible centers, breaching capacity and transport targets. Estimated exclusion: 5–10% of targeted mobility-limited residents. Potential disability-access complaint or lawsuit. Public criticism for excluding the most vulnerable. Estimated remediation cost: €20,000–40,000 per site (ramps, accessible toilets, signage). Delay: 2–4 weeks per site if structural work is required.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Conduct an accessibility audit of all proposed cooling-center sites by end of Month 1 (2026-11-08), assessing wheelchair access, toilet facilities, water points, quiet/low-stimulus rooms, parking and signage. Categorize sites as 'fully accessible', 'minor modifications needed' and 'unsuitable'. Prioritize fully accessible sites for opening in May; defer sites requiring remediation to July or drop them if remediation exceeds €10,000 or takes >4 weeks. Ensure at least 50% of planned center capacity is in fully accessible sites. Publish accessibility info (accessible routes, toilet locations, quiet room availability) for each site in a simple leaflet and on the municipal website so residents can choose sites that meet their needs.

## Risk 10 - Reputational & Social
Public communications campaign must counter misinformation about heat response (e.g., use of alcohol, incorrect fan use in extreme heat, distrust of cooling centers). If misinformation spreads unchecked, residents may adopt dangerous coping strategies and avoid the program. Poor messaging in multilingual communities could be misinterpreted or ignored.

**Impact:** Residents following unsafe advice (drinking alcohol, using fans during extreme heat without airflow) could experience preventable heat illness. Uptake of cooling centers and enrollment in the registry could drop by 10–20% if residents distrust the message or believe unsafe alternatives. Estimated reach loss: 1000–2000 residents in a city of 170k–200k. Media or social-media backlash if a preventable death occurs after resident ignored the program's guidance.

**Likelihood:** Medium

**Severity:** High

**Action:** Develop a pre-season communications strategy by Month 1 (2026-11-08) that includes positive messaging (cooling centers as safe, welcoming spaces), explicit myth-busting (alcohol does not help; fans can worsen extreme heat if airflow is stagnant) and trusted messengers (pharmacists, GPs, caretakers, faith leaders with pre-approved scripts). Test key messages with focus groups of older residents and recent migrants (Month 1 = 2026-11-08) to ensure clarity and uptake. Deploy messaging via radio (most common channel for 65+), pharmacy posters, door hangers and SMS (opt-in) in the city's main spoken languages plus visual guides (pictograms). Assign a communications officer to monitor social media and local forums during alert days and respond to misinformation within 2–4 hours with corrected facts and credible sources.

## Risk 11 - Operational
The plan relies on municipal and contracted staff deployed across multiple sites and alert days with limited advance notice (heat forecasts are typically issued 3–5 days before an event). Staffing for centers, transport dispatch, phone line and street teams will face fatigue and absences during multi-day heat waves, especially if staff are not full-time or do not have standby reserves.

**Impact:** During a 5–7 day heat wave (Month 7–8 = 2027-05-08 to 2027-06-08), cooling centers may operate at reduced hours due to staff absences (sickness, fatigue, childcare conflicts). Transport dispatch may slow if dispatcher is overwhelmed or absent. Outreach phone line may have long wait times (>10 minutes) for vulnerable residents. Estimated service degradation: 10–25% reduction in center hours, 15–30 minute delays in transport dispatch, partial closure of phone line during peak hours.

**Likelihood:** High

**Severity:** Medium

**Action:** Hire or contract for 20–30% staffing reserve capacity (additional part-time center staff, backup dispatcher, on-call phone operators) to cover absences and multi-day surges. Cross-train staff across roles (e.g., center managers can back up phone dispatch) to allow flexible redeployment. Establish a rota system that limits consecutive alert-day shifts to 3–4 days per person and mandates 1–2 days rest between multi-day events. For transport dispatch, contract two dispatchers and a backup coordinator, not one. For the phone line, use a mix of municipal staff and a partnered call-center service (e.g., municipal health line) that can surge capacity during alerts. Conduct fatigue-management training with managers by Month 3 (2027-01-08), including recognition of burnout and peer-support protocols.

## Risk 12 - Financial
The €3.5M budget is staged as €2.0M initial and €1.5M at Month 4 (2027-02-08), with no contingency buffer explicitly identified. Costs may overrun in procurement (supplier price increases), staffing (market wages higher than estimated), or transport (taxi retainer rates increase as summer demand peaks). Without contingency, overspends in one area force cuts to others.

**Impact:** If procurement or staffing costs overrun by 10–15%, the initial €2.0M will be exhausted before Month 3 (2027-01-08), forcing delays in hiring, kit distribution or center operations. If transport costs exceed budget by €100,000–200,000 (e.g., taxi rates spike in July), home-kit installations or outreach phone line will be defunded. Estimated budget shortfall under 15% overrun: €200,000–300,000.

**Likelihood:** Medium

**Severity:** High

**Action:** Reserve 8–10% of each phase as contingency (€160,000 from initial €2.0M, €120,000 from second tranche €1.5M, total €280,000). Pre-benchmark costs for kits, transport, staffing and procurement before Month 1 (2026-11-08) against market quotes to confirm budget adequacy. Track monthly spend against forecast and reforecast cash flow by Month 2 (2026-12-08) and Month 3.5 (2027-01-23) to identify overrun risks early. If overruns appear likely, prioritize: (1) maintaining center and transport operations for gates; (2) staffing for phone line and outreach; (3) home kits (can be partially deferred to Year 2 if needed). Negotiate fixed-price transport and kit-supply contracts (not cost-plus) by Month 1 (2026-11-08) to lock in rates and avoid summer spikes.

## Risk 13 - Operational
Outreach to unhoused people (via street teams or NGO partners) involves contact with individuals in acute distress and creates duty-of-care ambiguities. Street teams may face hostility, and consent protocols for providing water, transport or cooling access to someone in acute heat illness who is not enrolled are undefined.

**Impact:** Street outreach staff may be assaulted or abused during alert-day contact; without clear safety protocols, psychological harm and staff turnover could result. Consent and safeguarding failures could lead to litigation (e.g., if an unhoused person is transported without clear consent or suffers harm in a cooling center). Estimated cost of staff incident response (counseling, leave, recruitment): €10,000–20,000.

**Likelihood:** Medium

**Severity:** High

**Action:** Co-design street-contact protocols with homeless-service NGOs and occupational health by Month 1 (2026-11-08). Define consent models for acute distress (e.g., assumed consent for water/shade if person is incoherent but alert enough to accept help), escalation rules for calling EMS, and clear off-duty procedures if staff are threatened. Provide all street-contact staff (city or NGO) with de-escalation and trauma-informed care training before Month 2 (2026-12-08). Pair each street team with a supervisor or co-worker, not solo outreach. Establish a rapid incident-reporting and staff-support system: any incident (assault, distressing scene) triggers same-day debriefing and access to occupational health. Ensure insurance and safeguarding liability are clarified in NGO partner agreements before work begins.

## Risk 14 - Operational
The plan depends on reliable forecasts from the national meteorological service to trigger alert levels. If forecasts are uncertain, delayed or wrong, the city may fail to activate centers in time or over-activate on false alarms, wasting budget and eroding trust.

**Impact:** A late-issued forecast (24 hours before onset) could delay center opening by 6–12 hours, missing early-morning heat peaks. An incorrect forecast that predicts extreme heat that does not materialize could trigger unnecessary full activation, burning €5,000–10,000 in center-hours and staffing costs. Repeated false alarms could erode public trust and staff readiness. Estimated financial impact: €20,000–50,000 per incorrect trigger.

**Likelihood:** Low

**Severity:** Medium

**Action:** Establish a direct relationship with the national meteorological service (and local university weather station if available) by Month 1 (2026-11-08) to receive forecasts 5–7 days in advance and clarify confidence intervals. Define alert thresholds to include a 'marginal' advisory tier (for forecasts with lower confidence or borderline temperatures) that triggers phone check-ins and pre-positioned supplies only, not full center activation. Reserve full activation for forecasts with high confidence and clear threshold exceedance. Publish the alert forecast to partners and residents 24 hours in advance so centers can confirm staffing and residents can plan. Conduct post-event review of forecast accuracy and alert-trigger decisions monthly to refine thresholds and trust in the forecast.

## Risk 15 - Integration & System
Health system coordination relies on daily aggregate counts of heat-related EMS calls and ED visits, but hospitals and EMS may lack standardized coding for 'heat-related' presentations or may not be able to produce daily counts without disrupting operations. If data is delayed, coded inconsistently or incomplete, the city cannot verify health impact or adjust operations mid-season.

**Impact:** Missing or late daily EMS/ED data could delay escalation decisions during a multi-day heat wave by 12–24 hours, reducing early intervention. Without reliable health data, the Month 4 (2027-02-08) gate evaluation of program impact will be unreliable, risking credibility of the scaling cost model. Estimated data-access delay: 2–4 weeks due to IT and reporting processes.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Negotiate a data-sharing MOU with hospitals, EMS and primary care by end of Month 1 (2026-11-08), specifying (1) daily aggregate counts of ED visits and EMS calls coded as heat-related (to be agreed with clinical teams), (2) delivery of counts by 10 a.m. the next day via secure email or API, (3) a simple standardized form to ensure consistency. Conduct a 2-week data-validation pilot in April to test the reporting process and identify IT/coding gaps. Establish a fallback: if daily data cannot be produced, agree on weekly aggregate counts sufficient for trend analysis. Train hospital and EMS staff on the agreed coding and reporting process before May. Publish daily and weekly aggregate counts in a simple dashboard accessible to city operations staff (not the public, to protect privacy) so decisions can be made.

## Risk 16 - Operational
The plan includes mandatory heat-protection clauses in municipal contracts (adjusted work schedules, breaks, water, shade). Enforcement requires site inspections and contractor compliance monitoring, which consume municipal public-works staff capacity. Private employers outside municipal contracts are only encouraged via guidance, not required; uptake and compliance are uncertain.

**Impact:** Without dedicated inspector capacity, contractor compliance with heat clauses will be spotty, and municipal outdoor workers may still suffer heat illness. Private employer adoption of heat guidance is likely to be <30% without regulatory incentive, leaving outdoor workers at private firms (construction, agriculture, delivery) at continued risk. Estimated reputational risk: if a municipal contractor or private-firm outdoor worker suffers preventable heat illness, media and unions will question the program's effectiveness.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Designate one municipal public-works supervisor or contracted health-and-safety officer as heat-compliance monitor, with authority to conduct spot inspections of municipal and contracted outdoor work sites during alert days. Develop a simple heat-compliance checklist (schedule changes, water availability, shade areas, mandatory rest breaks, worker education) and conduct unannounced site visits to at least 50% of active contracts each summer. Document findings and issue corrective notices to contractors within 48 hours of non-compliance. For private employers, publish a heat-protection guidance pack (English and main languages in the city) by Month 1 (2026-11-08) and promote it via chambers of commerce, employer associations and local media. Offer free consultation to employers on heat-protection plans. Tie any municipal incentives (e.g., procurement bonus points) to certified heat-protection training for private firms, incentivizing voluntary adoption.

## Risk 17 - Integration & Stakeholder
The plan requires partnerships with housing associations, social services, NGOs, pharmacies and faith organizations to conduct outreach and refer residents. If partner engagement is weak, partners lack capacity or priorities change mid-season, enrollment and contact rates will collapse.

**Impact:** Loss of a key partner (e.g., largest housing association serving 1000+ residents) could reduce outreach reach by 10–20%. If social services deprioritize heat outreach during a busy month, contact attempts could drop from planned 5000/month to 3000/month, failing the 60% contact-success gate. Estimated reach loss: 500–1000 residents per alert period.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Sign formal partnership MOUs with housing associations, social services, NGOs and pharmacy chains by end of Month 1 (2026-11-08), including outreach commitments, data-sharing terms, liability and escalation contacts. Conduct joint quarterly planning meetings (Month 1, 4, 7, 10 = 2026-11-08, 2027-02-08, 2027-05-08, 2027-08-08) to review capacity, adjust targets and resolve conflicts. Establish a dedicated partner liaison officer (city-side) who maintains monthly contact, monitors capacity and escalates issues early. Provide partners with training, scripts and real-time feedback on performance (call counts, contact success) to maintain engagement. Build contingency: if a key partner drops out mid-season, identify a backup partner (second social service, NGO coalition) by Month 2 (2026-12-08) and brief them as standby.

## Risk 18 - Operational
The plan aims for average transport time-to-pickup of <45 minutes during alert days. This depends on volunteer driver availability, taxi retainer response times, and geographic distribution of residents needing transport. During peak demand (early morning of a heat day), dispatcher may be overwhelmed and wait times could exceed 45 minutes.

**Impact:** If average transport time climbs to 50–60 minutes, the Month 4 (2027-02-08) gate (<45 minutes) will be failed, triggering a scale-back in funding and credibility. Residents waiting >1 hour for transport may decide not to travel to a cooling center, reducing utilization. Estimated impact on gate failure: 10–15% increase in wait times if dispatch is not well-coordinated.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Hire or contract two dispatchers and one backup coordinator for the transport system (not one) to handle simultaneous requests during peak alert-day demand. Pre-position volunteer drivers and a taxi retainer fleet by 7 a.m. on each forecast alert day, so resources are standing by and not deployed elsewhere. Set dispatch software or spreadsheet to prioritize elderly and mobility-limited residents (shortest acceptable wait time 30 minutes), then others (target 45 minutes). Conduct a 'transport stress test' in May using a simulated alert scenario (5–10 transport requests in 2 hours) to measure actual dispatch performance and identify bottlenecks. If stress test shows average times >45 minutes, increase taxi retainer capacity or recruit additional volunteer drivers before June. Track average transport time daily during summer alerts and report to the city coordinator.

## Risk 19 - Operational
Multilingual outreach and communications must reach recent migrants and residents with limited local-language skills, but translation and interpretation services are expensive and time-consuming. If communications are offered only in the city's main language(s) and English, significant populations may be excluded.

**Impact:** Recent migrants from non-European language groups (sub-Saharan, North African, Eastern European, Vietnamese, etc., depending on city demographics) may miss alerts or enrollment information, reducing reach by 10–20% in neighborhoods with high migrant density. Estimated reach loss: 500–1500 residents per city, depending on migrant population proportion. Reduced uptake could fail outreach-contact-success gates if migrant communities are under-counted.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Identify the city's top 4–6 spoken languages by recent migrants (via municipal integration data, census or NGO networks) by Month 0 (2026-10-08). Procure interpretation services for the phone line (remote interpreter on standby during alert days) and translation of key materials (alert flyers, enrollment scripts, cooling-center welcome guides) by Month 1 (2026-11-08). Partner with migrant community associations to recruit community language ambassadors (paid part-time roles, 10–15 hours/week during summer) to deliver messages, accompany door-knocks and staff cooling-center welcome desks in their own languages. Test translated materials with focus groups of native speakers (Month 1 = 2026-11-08) to ensure accuracy and cultural appropriateness. Deploy translated door hangers, flyers and SMS in selected neighborhoods with high migrant density. Budget: €15,000–25,000 for translation, interpretation and ambassador stipends.

## Risk 20 - Reputational & Social
A resident or visitor to a cooling center could suffer a preventable health event (heat stroke, cardiac event, fall) if the center is not staffed with first-aid capacity and there is no clear escalation to medical care. If such an incident occurs and media coverage ensues, the program could be blamed for inadequate safeguarding despite best efforts.

**Impact:** A serious incident at a cooling center could lead to litigation, regulatory complaint and loss of public trust. Even if the program is not legally liable, reputational damage could reduce center uptake by 10–20% and invite political scrutiny of the program's continuation. Estimated legal and reputation cost: €50,000–100,000.

**Likelihood:** Low

**Severity:** High

**Action:** Ensure every cooling center is staffed by at least one person with first-aid certification (refreshed annually) and a defibrillator (AED) on-site with staff trained in its use. Establish rapid escalation to 112 (emergency services) with pre-positioned phone line and clear incident-reporting protocols. Conduct center managers in basic heat-illness recognition and first-response (cold water, rest, elevation) by Month 2 (2026-12-08). Run quarterly first-aid refresher drills at each center (April, June, September) to keep skills sharp. Draft incident-response and incident-reporting templates so that any event is documented, reviewed by the city health officer and escalated if needed. Ensure liability insurance covers center operations and staff are aware of coverage limits. Communicate center first-aid and emergency procedures clearly to residents on entry (signage, staff introduction) to set expectations.

## Risk 21 - Operational
The plan includes home installation of fans and shading by a handyperson service, which requires safety checks to ensure fans are used safely (directional airflow in extreme heat, not recirculating hot air) and shading installation does not create fire hazards or building-code violations. If safety checks are skipped or insufficient, residents could misuse fans and suffer harm, or insurance and liability issues could arise.

**Impact:** Resident misuse of installed fans (e.g., closed-room recirculation during extreme heat) could worsen heat illness rather than help, and if linked to a preventable death or hospital admission, litigation could follow. Installation of external shading that violates building codes or historic-preservation rules could trigger enforcement action and removal, undermining resident confidence. Estimated remediation or legal cost: €10,000–30,000.

**Likelihood:** Low

**Severity:** Medium

**Action:** Require all home-installation work (fans, shading) to be carried out by certified handypersons or contractors (not volunteers) who have completed a 2-hour heat-safety and installation-safety training by Month 2 (2026-12-08). Training must cover (1) proper fan use (directional airflow, outdoor-air intake, not closed-room recirculation), (2) safe installation on exterior surfaces (wind resistance, fire safety), (3) checking building-code compliance before work, (4) simple written guidance left with the resident on safe fan use and water intake. Conduct spot inspections of 10–20% of installations (selected randomly and by risk level) by a municipal building inspector or external quality auditor to verify workmanship and code compliance. Document inspection findings and any remediation work. Provide all residents receiving installations with written guidance (translated) on safe use; include troubleshooting and links to advice.

## Risk 22 - Operational
The plan declares cooling centers and support services during heat alerts, then requires rapid stand-down when the alert ends. Staff, volunteers and partners may remain in alert mode longer than needed (treating borderline cases as emergencies, over-utilizing services), inflating costs and prolonging fatigue. Conversely, premature stand-down could leave residents vulnerable if heat returns within days.

**Impact:** Prolonged over-alert activation could increase operational costs by 15–25% (€75,000–125,000 over the summer if 2–3 alerts occur). Premature stand-down followed by rapid heat return could cause service gaps and trust erosion. Inconsistent stand-down decisions across partners could leave some services active and others closed, confusing residents.

**Likelihood:** Low

**Severity:** Low

**Action:** Define clear stand-down criteria in the alert protocol: cooling centers, transport dispatch and outreach phone line stand down when the forecast no longer meets alert thresholds and temperatures have been normal for 48 hours. Assign the city incident commander authority to issue stand-down orders and communicate them to all partners and the public within 2 hours. Include stand-down procedures in the Month 2 (2026-12-08) readiness gate training and drill (how staff clock out, centers close cleanly, volunteers are released). Check forecasts daily during summer and issue updates to partners each morning so everyone knows the current status. Conduct a mock stand-down drill in May to practice the process.

## Risk 23 - Financial & Governance
The plan is a 12-month pilot with a requirement to produce a 'repeatable playbook and scaling cost model for other EU cities' by Month 12 (2027-10-08) (end of 2027). Documenting, costing and refining the model requires staff time and data analysis that may not be budgeted separately, and the playbook's transferability to very different EU cities (e.g., Baltic countries vs. Southern Europe) is uncertain.

**Impact:** If playbook documentation is not funded explicitly, it will be rushed or incomplete, limiting its value to other cities. Playbook reuse by cities with different housing stock, climates, demographics and legal frameworks may require substantial local adaptation, reducing the apparent transferability and cost model's credibility. Estimated effort: 300–500 staff-hours for playbook drafting, cost modeling and validation. If not budgeted: incomplete or late delivery.

**Likelihood:** Medium

**Severity:** Low

**Action:** Assign a dedicated playbook and evaluation officer (0.5 FTE for Months 9–12 = 2027-07-08 to 2027-10-08, or 1 FTE for Month 12 = 2027-10-08 post-season) within the budget to lead documentation work. Begin playbook drafting in Month 8 (2027-06-08) (not after the season ends) so lessons are captured while fresh. Include sections on: (1) decision rationale and trade-offs for each element (cooling centers, transport, outreach, etc.); (2) SOPs and checklists for each role; (3) budget breakdown by cost type and scaling assumptions; (4) city-specific adaptations (housing stock, climate, demographics); (5) replication checklist for other EU cities. Conduct playbook testing with a peer city (Month 11 = 2027-09-08) to identify gaps and refine guidance. Publish a draft playbook by Month 11 (2027-09-08) and final version by Month 12 (2027-10-08). Cost model must include both unit costs (€/person enrolled, €/center-hour, €/transport trip) and assumptions about how these scale to city size and climate.

## Risk 24 - Operational
The plan's success hinges on achieving 80% of planned cooling-center hours, 60% outreach contact success and <45-minute transport time at the Month 4 (2027-02-08) gate. If any gate fails, €1.5M scale funding may not be released, forcing mid-season contraction. However, the gate measurement period (early summer, June–July) may not include sufficient heat events to test performance fairly.

**Impact:** If June–July are cooler than normal and no alert thresholds are crossed, gates cannot be measured against real heat events. Drill-based gate evidence may be weak if performed in cool conditions and not replicated during actual alerts. Scale funding delay could force closure of some centers or transport capacity by August, harming residents during the peak-risk period. Estimated impact: 2–4 week delay in scale funding release or non-release if gates are deemed unmeasurable.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Revise gate criteria to allow measurement via formal drills and simulated alert scenarios if real heat events are insufficient. Pre-specify a 'drill protocol' by Month 3 (2027-01-08) that mirrors alert-day operations (all centers open, transport mobilized, phone line active for 4–6 hours) and is conducted in April or May (before the Month 4 = 2027-02-08 gate). Measure drill-based performance (center hours delivered, transport response time, outreach phone line wait time) and staff observations. Document drill results and use them to validate the Month 4 (2027-02-08) gates alongside any early real-event data. Include contingency decision: if insufficient heat events or drill results are available by Month 4 (2027-02-08), release 50% of the €1.5M to sustain operations through summer and defer full-release decision to Month 5 (2027-03-08) (based on June data).

## Risk 25 - Strategic & Organizational
The plan requires a mayor's-office incident commander (or delegated authority) to declare alerts and coordinate cross-department action. If the mayor's office is distracted by other crises or transitions (staff turnover, election cycles), incident command may weaken or become politicized, leading to delayed or inconsistent alert decisions.

**Impact:** Delayed alert declarations could cost 12–24 hours of response time during a critical heat event. Politicized alerts (declaring or withholding based on political optics rather than forecasts) could erode scientific credibility and partner trust. Staff turnover in the mayor's office could orphan the heat program mid-summer if the new administration deprioritizes it. Estimated impact: 2–4 week operational disruption or alert-declaration delay.

**Likelihood:** Low

**Severity:** Medium

**Action:** Establish a written delegation of authority for heat-alert declaration, signed by the mayor and filed with the municipal legal department, specifying (1) the trigger criteria (forecast thresholds), (2) who can declare (incident commander, deputy, backup), (3) escalation chain if the primary commander is unavailable, (4) that alert declarations are evidence-based and not subject to political review. Ensure the deputy incident commander (from public health) has clear authority to declare if the mayor's office is unavailable. Conduct cross-training so the health department, civil protection and city council each understand the alert protocol independently. Include heat-program continuity in the mayor's transition briefing if elections or staff changes occur. Protect the heat-program officer role (1 FTE) from year-to-year budget cuts by framing it as ongoing business continuity, not a temporary project.

## Risk summary
This 12-month municipal heatwave mortality-reduction program faces moderate-to-high operational, financial and reputational risks concentrated in the Month 2 (2026-12-08) and Month 4 (2027-02-08) readiness and scale gates. The three most critical risks are: (1) **Supply-chain and procurement delays** for cooling kits and transport contracts—if these do not arrive by February, the program cannot deploy home interventions or guarantee transport capacity in time for the first summer heat events, jeopardizing both the Month 2 (2026-12-08) and Month 4 (2027-02-08) gates and forcing budget reallocation. (2) **Gate validation during cool season**—the Month 4 (2027-02-08) gates (80% center hours, 60% outreach success, <45-minute transport) depend on real heat events or drills occurring by June; if June–July are cool, gates cannot be fairly measured, risking non-release of €1.5M scale funding and mid-summer operational collapse. (3) **Staffing and volunteer availability**—if street-contact, cooling-center and transport-dispatch teams are under-staffed or under-trained by June, they will fail to meet gates and leave residents at risk during peak summer heat. Mitigation priorities: (a) front-load procurement and contracting by end of Month 1 (2026-11-08) with contingency suppliers and price locks; (b) redefine gates to allow drill-based evidence alongside real events and include a contingency funding model if gates are delayed; (c) launch volunteer recruitment immediately and conduct staffing stress tests by May. Secondary risks include GDPR compliance uncertainty, partner capacity and engagement, technology integration failures, and reputational damage from operational failures or misinformation. The plan is viable if these gate and staffing risks are actively managed from Month 0 (2026-10-08) onward, with clear decision points at Months 1, 2, 3.5 and 4 (2026-11-08, 2026-12-08, 2027-01-23, 2027-02-08).