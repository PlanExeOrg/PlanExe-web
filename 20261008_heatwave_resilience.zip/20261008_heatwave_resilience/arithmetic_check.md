26 explicit calculations found in the documents re-computed without an LLM; all match their stated result.

