This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** The plan is a 12-month municipal heatwave mortality-reduction program for a mid-sized European city. It is physical throughout and cannot be run online alone. Its core activities take place in the real world:

- **Cooling centers:** Libraries, community centers, malls, churches and sports halls must be contracted, staffed, secured and made accessible (wheelchair access, quiet rooms, water, toilets). Residents must physically travel to them.
- **Transport:** Taxi, paratransit or volunteer-driver services must physically move mobility-limited residents to the centers within a target time.
- **Outreach:** Door-knocking, in-person enrollment at centers and welfare checks on people living alone are face-to-face activities. They carry staff and volunteer safety considerations.
- **Home interventions:** Exterior shading kits, reflective blinds, window fans, thermometers and hygrometers, and hydration supplies must be procured, stored, distributed and installed. A handyperson service must visit top-floor flats and social housing.
- **Health system coordination:** Hospitals, EMS and primary care are physical services. Proactive check-ins are meant to keep ambulances and emergency departments free.
- **Worker protection:** Outdoor municipal workers need shaded rest points, water, adjusted schedules and mandatory breaks on real work sites.
- **Communications:** Flyers, pharmacy posters, door hangers, radio and faith and community leaders are used because many vulnerable residents are offline. This work needs physical distribution.
- **Site-specific and staffing needs:** The plan requires a specific EU city and its housing stock, plus hiring or contracting of coordinators, outreach staff, center staff and drivers. Drills and early-season heat days must be run on the ground to meet the Month 2 (2026-12-08) readiness gate and the Month 4 (2027-02-08) scale gate.

Some components are digital, such as the data dashboard, the SMS opt-in and the evaluation report. They support the physical operations and are not the primary solution, because the brief rules out an app-first approach. The plan clearly involves physical locations, materials, travel, installation and in-person work, so it is classified as physical.