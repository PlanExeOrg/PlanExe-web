# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** Moderate, city-scale public-health program in one non-capital EU city (150k–400k residents). EUR 3.5M (user constraint) over 12 months, released as EUR 2.0M up front and EUR 1.5M at Month 4 (2027-02-08) if gates are met. The brief asks for a practical pilot footprint that expands only after early success. It also asks for a repeatable playbook and a scaling cost model for other EU cities. The ambition is demonstrable harm reduction, not transformation.

**Risk and Novelty:** Low-to-moderate risk and low novelty. Heat-health action plans, cooling centers and welfare checks are established practice. The main risks are operational: the Month 2 (2026-12-08) and Month 4 (2027-02-08) gates fall in the cool season, so evidence must come from drills and simulated alert days. Other risks are GDPR exposure, volunteer safety, reputational damage after a failed response, and surge during extreme events. The brief explicitly says to avoid the most aggressive scenario.

**Complexity and Constraints:** High breadth, with seven workstreams: governance, cooling and transport, outreach, home kits, health coordination, worker protection and communications. Hard constraints: no new legislation, GDPR limits and no access to health records, no app-first design, realistic hireable staffing, and no major construction. Explicit gates: 80% of planned center hours delivered, outreach contact success of at least 60%, average time-to-transport under 45 minutes, and a closed after-action report. Procurement and contracting must finish by Month 2 (2026-12-08).

**Domain and Tone:** Public-health and municipal governance, written for immediate execution by a municipality. Operational and equity-focused, with clear owners, SOPs, a risk register and KPIs. Public money requires accountability and defensibility.

**Holistic Profile:** A pragmatic, gate-driven municipal pilot that must reach vulnerable and often offline residents. It has to stay inside normal municipal powers and GDPR limits, and it must pass early performance gates using drills. It needs moderate ambition, controlled risk, fast cross-department decisions, and a balance of reach, cost and legal safety. It does not need experimental or maximal-coverage designs.

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Pragmatic Foundation
**Strategic Logic:** Combines the national warning with a low-cost advisory tier, formal neighborhood refuges within walking distance, and intermediary-held lists that keep personal data with trusted organizations. Volunteer drivers with taxi backup and mayoral-level command balance reach, cost and speed of approvals. This path is the most likely to meet the Month 4 (2027-02-08) gate (80% of planned center hours, at least 60% outreach contact success, under 45 minutes to transport) without extreme risk.

**Fit Score:** 9/10

**Why This Path Was Chosen:** It matches the brief's mix of libraries, community centers and churches within walking distance. Intermediary-held lists (housing associations, social services, NGOs, pharmacies) fit the GDPR constraints, and the advisory tier controls cost and alert fatigue. Mayoral-level command speeds procurement before Month 2 (2026-12-08), and taxi backup protects the 45-minute transport gate. It is the most likely to meet the Month 4 (2027-02-08) gates at moderate risk.

**Key Strategic Decisions:**

- **Alert Trigger Ladder:** Combine the national warning with a low-cost advisory tier that triggers only phone check-ins and pre-positioned supplies, so full center activation is reserved for the upper tiers.
- **Cooling Refuge Network Shape:** Contract many small neighborhood refuges in libraries, parish halls and community centers, accepting higher supervision costs per hour to keep most vulnerable residents within walking distance.
- **Consent-Light Identification Routes:** Use intermediary-held lists, where housing associations, social services and NGOs make the calls on the city's behalf, so personal data never moves to the city and only aggregate contact results are reported.
- **Mobility Support Delivery:** Recruit and train vetted volunteer drivers coordinated by a dispatcher, covering insurance and safeguarding checks, and keep taxi contracts only as a backup for failures and peak demand.
- **Command Seat Allocation:** Place the incident commander in the mayor's office with a deputy from public health, so cross-department orders carry political weight and procurement approvals move quickly.

**The Decisive Factors:**

- **Fit with ambition and risk:** The plan is a moderate, gate-driven pilot that must avoid the most aggressive path. This scenario balances reach, cost and speed without extreme risk.
- **GDPR and offline reach:** Intermediary-held lists (housing associations, social services, NGOs, pharmacies) keep personal data out of city hands. They also reach people who are not smartphone users.
- **Gate readiness:** Many small walkable refuges in libraries, parish halls and community centers match the brief's asset list. Mayoral-level command with a public-health deputy speeds contracting and procurement before the Month 2 (2026-12-08) gate. Taxi backup protects the 45-minute transport target.
- **Budget discipline:** The advisory tier limits alert fatigue and center-hour spend.
- **Why not the others:**
  - The Pioneer's Reach adds staffing intensity, liability ambiguity and thin-data calibration, which makes the gates harder to meet.
  - The Consolidator's Safeguard is safe but leaves isolated and mobility-limited residents under-covered, and its retainers draw budget away from home kits.

---
## Alternative Paths
### The Pioneer's Reach
**Strategic Logic:** Prioritizes finding and serving the hardest-to-reach residents through local calibration, building-level canvassing with neighborhood sentinels, trusted informal refuges and mobile cooling, with a delegated heat desk for speed. It accepts higher quality variance, staffing intensity and liability complexity, so the Month 2 (2026-12-08) and Month 4 (2027-02-08) gates (user constraints) need close tracking. Because the first gates fall in the cool season (Months 2 and 4 = 2026-12-08, 2027-02-08), gate evidence will depend on drills and simulated alert days, which this option leans on heavily.

**Fit Score:** 4/10

**Assessment of this Path:** It maximizes reach to hidden residents, but building-level canvassing, informal refuges outside the liability framework, mobile cooling and local calibration with thin data are staffing-heavy and variable in quality. This conflicts with the instruction to avoid the most aggressive path and with the Month 2 (2026-12-08) and Month 4 (2027-02-08) gate timelines.

**Key Strategic Decisions:**

- **Alert Trigger Ladder:** Calibrate city-specific thresholds from local historical temperature and mortality records, with consecutive hot nights weighted more heavily than daytime peaks, and review them after the first season.
- **Cooling Refuge Network Shape:** Build a hybrid network that adds cool common rooms in existing sheltered housing and social-housing blocks and pharmacy waiting areas as informal refuges, using spaces already air-conditioned and trusted by residents.
- **Consent-Light Identification Routes:** Canvass by building rather than by person, with door-knock teams covering all top-floor and poorly insulated units in selected blocks, and recruit caretakers, postal workers and shop owners as trained neighborhood sentinels.
- **Mobility Support Delivery:** Schedule fixed shuttle loops between housing blocks and refuges on alert days and add mobile cooling vehicles for blocks with many housebound residents, reducing individual on-demand trips.
- **Command Seat Allocation:** Create a standing heat desk staffed by a rotating duty officer roster across departments, with a written delegation letter so any officer can declare an alert without waiting for a superior.

### The Consolidator's Safeguard
**Strategic Logic:** Chooses the most proven and controllable options: fixed national-forecast thresholds, a few staffed anchor sites, a consent-based registry, contracted taxi capacity with guaranteed response, and clinically led command. This minimizes GDPR, liability and calibration risk and gives predictable costs and clear accountability for the Month 2 (2026-12-08) and Month 4 (2027-02-08) gates. The trade-off is lower coverage of isolated residents and reliance on transport to reach the sites.

**Fit Score:** 6/10

**Assessment of this Path:** It is low-risk and controllable, with clear clinical accountability and guaranteed taxi capacity. However, a few large sites and an opt-in registry under-serve isolated, mobility-limited and offline residents. A taxi-only model with retainers also diverts budget from home kits, and the design is less equity-oriented than the brief requires.

**Key Strategic Decisions:**

- **Alert Trigger Ladder:** Adopt fixed forecast thresholds for daytime highs and night-time lows across three tiers, taking the national meteorological service forecast as the sole input and avoiding local calibration work.
- **Cooling Refuge Network Shape:** Contract a few large anchor sites such as sports halls and malls with extended and overnight hours, concentrating staff, medical cover and security while relying on the transport contract for access.
- **Consent-Light Identification Routes:** Build an opt-in heat registry enrolled through GPs, pharmacies and centers, with explicit consent and a short retention period, accepting that the most isolated residents are underrepresented.
- **Mobility Support Delivery:** Sign an on-call contract with taxi and accessible-transport operators with guaranteed alert-day capacity, paying a standby retainer to secure response times and wheelchair-capable vehicles.
- **Command Seat Allocation:** Assign command to the municipal public health department, with civil protection supplying the operations section, so clinical judgement drives alert declarations and escalation rules.
