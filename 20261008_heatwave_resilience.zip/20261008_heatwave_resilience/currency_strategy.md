This plan involves money.

## Currencies

- **EUR:** Primary currency for budgeting and reporting. The project is a €3.5M, 12-month municipal program in EU cities (Spain, Poland, or Italy), with staged funding (€2.0M initial + €1.5M at Month 4 = 2027-02-08 if gates are met). Cooling centers, transport contracts, home kits, staff and procurement are all cost items in euros.

**Primary currency:** EUR

**Currency strategy:** All transactions will use EUR for budgeting, procurement, contracts and reporting. The project is confined to a single EU city within the Eurozone or EU member states, so no foreign exchange risk management is required. All vendor contracts (cooling centers, transport operators, kit suppliers, handyperson services), payroll and grant disbursements will be conducted in EUR.