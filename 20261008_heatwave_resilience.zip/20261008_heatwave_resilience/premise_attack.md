### Premise Attack 1 — Integrity
_Forensic audit of foundational soundness across axes._

**[STRATEGIC] The plan's funding gate and success claim depend on heat events that cannot occur in the window where they are tested: the €1.5M release at Month 4 (2027-02-08) requires performance on alert days, but Month 4 (2027-02-08) falls in winter and the heat season only begins around Months 8–11 (2027-06-08 to 2027-09-08).**

**Bottom Line:** REJECT: A €1.5M winter gate that requires summer heat-day performance, plus a one-season mortality claim that cannot be measured, means the programme's go/no-go and its proof of success are both built on conditions that cannot be observed when they are tested.


#### Reasons for Rejection

- The Month 4 (2027-02-08) gate requires '80% of planned cooling-center hours delivered', 'time-to-transport under 45 minutes during alert days' and 'early-season heat days', but Month 4 (2027-02-08) is the start of February 2027 for a city in the EU, so no heat alert will have been called and the gate can only be passed on simulated drills.
- The €2.0M / €1.5M split ties 43% of the budget (€1.5M of €3.5M) to a test that measures drill theatre, not response under heat, so the money is either released on a rehearsal or withheld on an event that cannot happen. That makes the release decision arbitrary either way.
- The Month 4 (2027-02-08) outreach success target of ≥60% for 'enrolled high-risk residents' can only be met by counting people who opted in during a winter registration push. Those people are self-selected and more connected than the isolated, non-smartphone, recent-migrant and unhoused residents the plan says it prioritises.
- The goal of 'demonstrably' reducing mortality and serious illness in one summer within a pilot footprint of a 150k–400k city has no statistical power. Heat deaths in a single mid-sized city are a few dozen to a few hundred and swing with the weather, so a mild or extreme summer would swamp any effect, and attribution is admitted to be weak.
- Hot nights and multi-day events are assumed to be increasing, yet the evaluation has only one season and a limited pilot footprint. Success or failure will be read off summer 2027 weather and not off what the programme did.

#### Second-Order Effects

- 0–6 months: The Month 2 (2026-12-08) and Month 4 (2027-02-08) gates are passed or failed on paper drills in winter, with contracts, procurement orders and staff committed before anyone has seen a real alert day, and the drill-based pass becomes the justification for releasing €1.5M.
- 1–3 years: A single-season result is taken as proof or disproof of effectiveness. A mild summer is credited to the programme and a hot one blamed on it, and the evaluation report becomes a contested document the city can neither defend nor retract.
- 5–10 years: The playbook, and the cost model built on one pilot season and its drill-based gate, is copied to other EU cities as a template. Funders learn to accept winter drills as readiness evidence, and heat planning ends up optimised for passing gates instead of for the late-night, hot-weather cases that cause deaths.

#### Evidence

- Case/Incident — Europe summer 2022 heat mortality (Ballester et al., Nature Medicine, 2023): an estimated 61,672 heat-related deaths with a 95% CI of 37,643–86,807 across 35 countries, showing how wide the uncertainty is even at continental scale, let alone for one mid-sized city.
- Law/Standard — General Data Protection Regulation, Article 9 (2016): health data is a special category needing a specific legal basis, which limits how a municipality can identify and register vulnerable residents ahead of the season.



### Premise Attack 2 — Accountability
_Rights, oversight, jurisdiction-shopping, enforceability._

**[STRATEGIC] — The February Heatwave Gate: a programme that starts in October 2026 and releases €1.5M at Month 4 (February 2027) on "early-season heat days" that cannot exist in a European winter, then promises to "demonstrably reduce" deaths in one 150k–400k city where a single summer's death count is too small and too noisy to show anything.**

**Bottom Line:** REJECT: The February Heatwave Gate makes the money release depend on weather that does not exist and the success claim depend on numbers too small to prove it, so this pilot would certify itself rather than protect anyone. A premise that cannot test the thing it exists to fix should not be funded.


#### Reasons for Rejection

- The gate rewards performance on heat days that will not occur before Month 4 (2027-02-08), so the €1.5M release can only be passed on rehearsals and paperwork, or be delayed until after the summer it was meant to protect, and in either case the money tests nothing about real heat.
- The people most likely to die alone in a hot top-floor flat (isolated elders, recent migrants wary of officials, people with no GP relationship) are the ones least likely to opt in to a registry, answer a phone, or open a door to a stranger, so the plan's consent-based design aims at the residents who need it least and presents the rest as covered.
- Responsibility is spread across a city incident lead, libraries, churches, malls, taxi firms, volunteer drivers, pharmacies and NGOs, none of whom answers for a death in an unvisited flat, and the only data allowed to flow (aggregate signals) cannot show who was missed, so failure leaves no name and no owner.
- A €3.5M one-city pilot sold as 'demonstrably' lowering mortality sets a promise the statistics cannot keep: a few dozen heat deaths in a single summer swing more from year to year than any pilot could move, so the evaluation will credit mild weather as success or blame hot weather for failure, and other cities will copy the label without the proof.

#### Second-Order Effects

- **T+0–6 months — The Cracks Appear:** The Month 2 (2026-12-08) and Month 4 (2027-02-08) gates are passed on tabletop drills and winter-time 'simulations', so contracts for cooling sites, taxis and handypeople are locked in before anyone has seen a real alert day.
- **T+1–3 years — Copycats Arrive:** Other mid-sized cities cite the pilot's 'passed gates' as proof of effectiveness and adopt the same package, including the calendar and the opt-in registry, with no evidence of lives saved.
- **T+5–10 years — Norms Degrade:** Heat protection gets treated as a seasonal outreach project with a phone line and a fan kit, which crowds out the harder question of why elderly residents live in unbearable top-floor flats.
- **T+10+ years — The Reckoning:** After a lethal multi-day heat event with hot nights, the city's own after-action report shows the registered were looked after and the unregistered died, and the programme's 'success' record becomes the evidence against it.

#### Evidence

- Case/Report — Ballester et al., Nature Medicine (2023): estimated 61,672 heat-attributable deaths in Europe between 30 May and 4 September 2022, with higher rates in women and in southern countries; heat deaths are large in aggregate but scattered thinly across cities and years, which is why a single-city, single-season mortality claim is statistically weak.
- Case/Report — WHO Regional Office for Europe, 'Heat–health action plans: guidance' (2008) and 'Heat and health in the WHO European Region: updated evidence for effective prevention' (2021): treat heat-health planning as a standing multi-year system that includes early warning, health-sector readiness and housing, not a one-year pilot that is scored in winter.
- Law/Standard — GDPR (Regulation (EU) 2016/679) Art. 9 (special categories of data, including health): limits how GP, pharmacy and social-service lists can be used to find high-risk residents, so the 'who is most at risk' list the plan depends on is the one it is least able to lawfully build (exact municipal lawful basis not verified).
- Narrative — Front-Page Test: 'City paid €3.5M for a heat plan, passed its gate in February, and found the dead in flats nobody had registered.'



### Premise Attack 3 — Spectrum
_Enforced breadth: distinct reasons across ethical/feasibility/governance/societal axes._

**[STRATEGIC] A €3.5M pilot launched in October, gated at Month 4 (2027-02-08) on summer heat that cannot occur, and judged on one season's deaths, promises proof it can never produce.**

**Bottom Line:** REJECT: A winter-started, one-season, €3.5M pilot whose funding gate needs heat that will not exist and whose success claim needs statistics a city this size cannot supply is a plan to buy a press release, not to save lives.


#### Reasons for Rejection

- The Month 4 (2027-02-08) scale gate (Month 4 = 2027-02-08 falls in early February 2027) demands performance on "early-season heat days", which do not exist in a European winter, so the €1.5M release rests on drills and theatre or on an event that cannot arrive.
- The goal of "demonstrably" reducing mortality in one summer, in a city of 150k–400k, collides with arithmetic: heat deaths there number in the tens at most (estimate), year-to-year weather swings swamp any effect, and attribution is modelled, not counted.
- The €2.0M tranche is committed through the Month 2 (2026-12-08) readiness gate (December 2026), forcing the city to contract and staff cooling centers, sign a transport contract, and run a phone line for months of dead winter before one hot day tests any of it.
- The enrollment design (opt-in registries, GP and pharmacy partnerships, NGO lists) under GDPR and without health-record access finds mainly people already connected to services, while the isolated, living-alone, and recently arrived residents who die first stay invisible, and the ≥60% contact-success gate measures only those already enrolled.
- The "no major construction" constraint leaves shading kits, fans, and thermometers as the only response to the real killers, namely poorly insulated top-floor flats and hot nights, and cooling centers depend on frail, mobility-limited people travelling, a behaviour for which direct health-benefit evidence is thin.

#### Second-Order Effects

- 0–6 months: By Month 2 (2026-12-08) the city is paying for idle staffed cooling centers and a silent transport contract in midwinter, and at Month 4 (2027-02-08) the €1.5M decision is made on rehearsal results, so the gate is either quietly softened or passed on theatre.
- 1–3 years: Year-2 expansion is justified by operational counts (hours delivered, kits installed) rather than outcomes; a mild first summer is credited to the program, and a severe one produces deaths that the "pilot" cannot explain or defend.
- 5–10 years: A playbook built from a single season and a cost model extrapolated from it is copied across EU cities as proven practice, locking in recurring operating costs with no funding line and diverting attention from the housing stock that causes the deaths.

#### Evidence

- Report — Ballester et al., "Heat-related mortality in Europe during the summer of 2022," Nature Medicine (2023): estimated 61,672 heat-related deaths across 35 countries between 30 May and 4 September 2022 using modelling, showing that heat mortality is a statistical estimate, which a single mid-sized city's one-season data cannot resolve.
- Report/Guidance — CDC, "The Use of Cooling Centers to Prevent Heat-Related Illness: Summary of Evidence and Strategies for Implementation" (year not verified): states that direct peer-reviewed evidence of health impact from cooling centers is limited and best implementation strategies are unclear.
- Case/Incident — Chicago heat wave (1995): nearly 800 deaths, concentrated among isolated elderly residents in run-down neighborhoods who did not go to places outside their ordinary circles, as documented by Eric Klinenberg.



### Premise Attack 4 — Cascade
_Tracks second/third-order effects and copycat propagation._

**This is a Strategic Flaw. The plan is a heat-season program on a calendar that cannot work: it starts in autumn, puts its €1.5M release gate in the middle of winter, and promises a "demonstrable" mortality reduction in one summer in one mid-sized city. That reduction cannot be measured, so the funding gate and the success claim both rest on evidence the program cannot produce.**

**Bottom Line:** Abandon this premise. A 12-month, €3.5M program that starts in October, releases its main funding in February on drill results, and then claims a demonstrable mortality reduction from one summer in one city is built on a timeline and a measurement claim that reality will not support. The failure comes from the premise (the calendar, the gate and the outcome claim), not from execution detail, so better implementation will not fix it.


#### Reasons for Rejection

- The February Heatwave Paradox: Month 0 is 2026-10-08, so Month 2 (2026-12-08) falls in early December 2026 and Month 4 in early February 2027. The Month 4 (2027-02-08) gate requires "early-season heat days", "time-to-transport on alert days" and 80% of planned cooling-center hours delivered. None of those can occur in a European February. The gate is therefore either a table-top drill dressed up as operational performance, or it silently fails. Either way, €1.5M (43% of the budget) is released on rehearsal data. The real stress test, Months 8-11 (2027-06-08 to 2027-09-08) (roughly June to September 2027), falls after the money is committed.
- The Signal-to-Noise Mirage: "Demonstrably reduce" heat-related deaths and ED visits in a city of 150k-400k, in one season, with no concurrent control, cannot be shown. Heat-attributable deaths in a city this size are likely tens per season, and the plan gives no figure (estimate, not verified). Season-to-season variation in heat exposure alone will swamp any plausible program effect. Ahmedabad's pre/post evaluation used a multi-year baseline in a far larger city and still produced a very wide confidence interval. A mild summer shows "success" by luck, and a brutal one shows "failure" by luck. The only thing the plan can credibly demonstrate is process outputs, and those are not outcomes.
- The Opt-In Survivorship Filter: GDPR-compliant opt-in registries, GP and pharmacy referrals and NGO lists mainly enroll people who already have contact with services. The isolated, the undocumented, the unhoused and the lonely top-floor tenant are the ones who stay off the lists. The gate metric (contact success of at least 60% for "enrolled" residents) measures reachability among the already-reachable. It rewards enrolling easy cases, and it can be passed at the same moment the people who actually die are missed.
- The Seven-Programs-in-a-Trenchcoat problem: The scope bundles seven separate programs: incident command, a cooling-center network with transport, a GDPR outreach operation, a home-retrofit and handyperson service, health-system data coordination, worker protection and a multi-channel communications campaign. Each normally takes a full organization and a full season to stand up. They must be procured, contracted, staffed and trained in about 8 months under normal municipal powers. Public procurement, MOUs with hospitals and churches, and recruitment of multilingual outreach staff and handypeople for a seasonal 4-month job will each slip. With €3.5M spread this thin, each stream ends up under-resourced, and the gate checklist rewards getting all of them to a minimum rather than getting the critical ones right.
- The Seasonal Cliff: A 12-month grant for a 3-4 month hazard means that staff, taxi and paratransit contracts, venue agreements and volunteer rosters are built, then dissolved or left idle, with only one real exposure window inside the funding period. Year-2 "what to expand" decisions are made from one weather draw. The 12-month deliverables (playbook, scaling cost model, evaluation) arrive with the same unrepresentative evidence base.

#### Second-Order Effects

- Months 0-2 (2026-10-08 to 2026-12-08) (autumn to early winter 2026-27): Procurement, MOUs and recruitment are rushed with no heat pressure to focus decision-makers. Venues and transport providers sign for a service they will not deliver for 6+ months. The Month 2 (2026-12-08) readiness checklist is passed on paper (contracts signed, training done) while no live operation exists.
- Months 3-5 (2027-01-08 to 2027-03-08) (winter to early spring 2027): The Month 4 (2027-02-08) gate cannot be tested on real heat days. Under pressure to release funds, the team uses simulated alerts, which yields self-graded results ("45-minute transport" measured in a drill with pre-briefed drivers). The release of €1.5M is either approved on weak evidence or disputed. If disputed, the program loses 3-4 months of its remaining build window and enters summer with half its funding unspent or unallocated.
- Months 6-8 (2027-04-08 to 2027-06-08) (spring to early summer 2027): Pre-season communications and home-intervention installs run into landlord permissions, tenant no-shows and handyperson capacity. Outreach staff hired in winter churn out or are unavailable. Enrollment skews toward residents who are already connected to services, so coverage looks high in the reports while the isolated stay uncovered.
- Months 8-11 (2027-06-08 to 2027-09-08) (summer 2027): The outcome depends on the weather. In a mild summer there are too few alert days to show any effect, and the program is declared a success or failure on noise. In a severe multi-day event with hot nights, demand for transport and cooling-center capacity exceeds the contracted ceilings, volunteer and staff safety incidents occur, and the first public failure (a death in an unvisited flat) is attributed to the city. The reputational risk lands at the point of greatest exposure.
- Months 12-24 (2027-28): The evaluation report is inconclusive by necessity. Funders and councils read this either as proof the program was worthless or as proof of success, depending on the weather and the political reader. The Year-2 roadmap rests on one season. Seasonal contracts lapse and trained staff disperse. The scaling cost model circulates to other EU cities with unvalidated unit costs and an effect size nobody can defend.

#### Evidence

- Ahmedabad Heat Action Plan (India's first, piloted 2013 and fully implemented 2014): the published pilot evaluation compared 2014-2015 against a 2007-2010 baseline using distributed-lag models. It estimated 1,190 avoided deaths per year, with a 95% CI of 162-2,218. That is a multi-year baseline, a very large city and a very wide interval. A single-season, single-city European pilot has far less statistical power than this best-case precedent (PMC6236972).
- Ballester et al., Nature Medicine (2023): an estimated 61,672 heat-related deaths in Europe, 30 May-4 September 2022 (95% CI 37,643-86,807). The burden is large across 35 countries but is a continental signal built on 823 regions, not something a single mid-sized city can resolve in one season. The same paper calls for strengthened surveillance and long-term prevention plans, not 12-month pilots.
- France, August 2003: a heatwave killed on the order of 15,000 people, mainly isolated elderly people, and prompted a national heat plan with registries of vulnerable residents (death toll and details not re-verified here). The lesson is that isolation, not the weather alone, kills. A program that depends on opt-in enrollment systematically misses the isolated.
- Chicago, July 1995: roughly 700 heat-related deaths (not re-verified here), and Eric Klinenberg's analysis in "Heat Wave" attributes the highest risk to socially isolated residents in neighborhoods with weak social infrastructure. It is a direct analogy for why a contact-success-rate metric over enrolled residents can look excellent while the real risk group stays outside the system.



### Premise Attack 5 — Escalation
_Narrative of worsening failure from cracks → amplification → reckoning._

**[STRATEGIC] — The Winter Gate: A program whose release of €1.5M at Month 4 (2027-02-08) depends on "early-season heat days" and drills, and whose success is judged on mortality in a single mid-sized city, has gates and outcome measures that cannot be tested in the season they claim to certify, so the funding decision rests on theatre rather than evidence.**

**Bottom Line:** REJECT: A €3.5M single-city program whose release gate cannot be tested before the heat season and whose headline outcome cannot be measured at this scale certifies readiness it has not demonstrated and protects no one it cannot count. The gate is closed.


#### Reasons for Rejection

- Rights and dignity: the plan's central mechanism is to find, enroll and door-knock the very people who are isolated, undocumented or distrustful of institutions (older people living alone, recent migrants, unhoused people), yet it sets a ≥60% contact-success gate that rewards the municipality for reaching its easiest-to-reach enrollees and invites pressure on staff to count weak contacts as successes, leaving the most hidden residents counted as covered while they are not.
- Accountability and oversight: the Month 4 (2027-02-08) gate is self-certified by the same municipal team that spends the money and writes the after-action report. Its pass conditions (80% of cooling-center hours delivered, transport under 45 minutes on alert days, corrective actions closed) can only be observed if heat alerts occur by Month 4 (2027-02-08), a point in the program that falls in the cold season (proposed reading of the month offsets). Without real alert days, the gate is passed or failed on simulated drills, and no independent party can verify that the €1.5M release was earned.
- Systemic risk and scale: the premise that heat harm can be 'demonstrably reduced' in one city of 150k–400k within one season is statistically unsound. Heat deaths in a city this size in a bad summer are likely in the tens to low hundreds (estimate, not verified), the weather varies from year to year, and there is no control city. Any fall or rise in EMS calls, ED visits or excess mortality cannot be attributed to the program, so the planned cost model for scaling city-wide and to other EU cities extrapolates from noise.
- Value-proposition rot: the plan promises a ready-to-run playbook and a scalable cost model while bundling seven workstreams (cooling centers, transport, outreach, home kits, health-system data loop, worker protection, communications) into €3.5M and a first-season footprint. It claims that low-cost kits, volunteer-dependent outreach and non-binding employer guidance together shield people from a hazard that kills mostly through isolation and housing. This is a promise of proof that the design cannot deliver, and it leaves the city holding a 'pilot success' narrative it cannot defend.

#### Second-Order Effects

- T+0–6 months — The Cracks Appear: the Month 2 (2026-12-08) readiness gate is met on paper, with cooling-center contracts signed, a phone line live and procurement orders placed. The Month 4 (2027-02-08) scale gate then has no heat days to test, so it is passed on drills and tabletop exercises, the €1.5M is released on unverified performance, and the first rigorous finding of the program is that its gates never measured heat response.
- T+1–3 years — Copycats Arrive: neighboring cities and EU funders adopt the 'gated heat pilot' template and its headline KPIs (center hours delivered, transport times, contact rates), because these are easy to report. Procurement standardizes on activity metrics rather than lives protected, and cities certify readiness they have never exercised in real heat.
- T+5–10 years — Norms Degrade: after a mild first summer the pilot is credited with a success it cannot prove, and after a severe one the failure is attributed to weather. Either way the evidence base for heat-health planning gets noisier, enrolled registries age and go stale, volunteer networks burn out, and the mailing list of 'high-risk residents' becomes a GDPR liability that no one owns.
- T+10+ years — The Reckoning: a multi-day heat event with hot nights hits a city that believes it is protected. Deaths cluster among older people alone in top-floor flats who were never enrolled, and the inquiry finds the municipality funded a tested-in-name system, repeating the pattern of earlier heat disasters in which official preparedness did not reach the isolated.

#### Evidence

- Case/Report — 1995 Chicago heat wave: about 739 heat-related deaths in five days, mostly elderly and poor residents, many living alone. Eric Klinenberg's 'Heat Wave: A Social Autopsy of Disaster in Chicago' (2002) documents how official preparedness and services failed to reach the isolated, which is the same population the contact-success KPI would undercount (https://en.wikipedia.org/wiki/1995_Chicago_heat_wave).
- Case/Report — Ballester et al., Nature Medicine (2023), 'Heat-related mortality in Europe during the summer of 2022': an estimated 61,672 heat-related deaths (95% CI 37,643–86,807) across Europe, illustrating how wide the uncertainty is even for continental estimates and how weak attribution is at the scale of one mid-sized city (https://repositori.upf.edu/items/0fd12826-374c-4ec7-af25-5fcc5bafded9/full).
- Case/Report — 2003 European heatwave: estimated deaths exceeded 70,000 across Europe, with France alone around 14,800–19,000 (sources differ), despite mature health systems. The deaths were driven by isolation and housing rather than by a lack of cooling-center hours (https://en.wikipedia.org/wiki/2003_European_heatwave).
- Principle/Analogue — Evaluation design (public health): a single-site, single-season intervention with no comparison group and highly variable weather exposure cannot support causal claims about mortality, so 'demonstrable reduction' is a statistical promise the design cannot meet.