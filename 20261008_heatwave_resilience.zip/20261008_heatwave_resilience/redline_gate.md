**Verdict:** 🟢 ALLOW

**Rationale:** The prompt requests a public-health municipal heatwave protection plan; it is protective, non-harmful, and gives no capability for harm.

### Violation Details

| Detail                | Value |
|-----------------------|-------|
| **Capability Uplift**     | No |