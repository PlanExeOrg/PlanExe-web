# Governance Audit


## Audit - Corruption Risks

- Bribery or kickbacks from cooling-kit suppliers, transport contractors, or handyperson service providers in exchange for contract awards, sole-source purchasing, or expedited payment without competitive tender or quality verification.
- Nepotism in recruitment of cooling-center staff, outreach workers, dispatchers, or volunteer drivers through preferential hiring without transparent selection criteria or documented interviews.
- Conflicts of interest: incident commander, procurement officer, or partner-liaison staff steering contracts to family-owned suppliers, taxi operators, or translation firms, or accepting personal gifts or favors from vendors.
- Theft or misallocation of cooling kits, hydration supplies, or thermometer/hygrometer stock by handypersons, storage custodians, or center staff; sale of municipal equipment on the black market or for personal use.
- Information misuse: partner staff (housing associations, NGOs, social services) sharing enrolled residents' contact data with third parties (political campaigns, unsolicited marketing, creditors) beyond the agreed data-processing scope.
- Collusion between transport dispatchers and taxi-retainer operators to inflate trip counts, falsify response times, or double-bill for overlapping rides, or between outreach staff and intermediary partners to inflate contact-success metrics to meet the 60% gate.

## Audit - Misallocation Risks

- Budget misuse: reallocation of cooling-center operational funds (staffing, utilities, supplies) to unbudgeted items (office furniture, personal equipment, meals) or deliberate overspending on low-priority items to deplete contingency reserves.
- Double spending: same kit component (e.g., fans) purchased twice through different procurement routes (framework call-off and competitive tender) without canceling the first order, resulting in duplicate stock and wasted funds.
- Inefficient allocation: concentration of cooling centers in affluent neighborhoods while high-risk peripheral and historic-quarter areas remain under-served; failure to track equity coverage by deprivation index.
- Unauthorized use of transport assets: volunteer drivers or dispatchers using taxi-retainer vehicles for personal errands outside alert-day mobilization, or dispatchers redirecting resources to non-heat-response municipal functions.
- Poor record-keeping: lack of documented procurement files, missing contracts, unsigned MOUs, or no audit trail for cash disbursements, preventing verification of compliance with procurement rules or budget allocations.
- Misreporting progress or results: inflated contact-success rates (claiming 70% when actual data shows 50%), falsified drill metrics, or overstated kit installation completion to meet Month 4 (2027-02-08) gates and trigger conditional funding release.

## Audit - Procedures

- Quarterly external audit of procurement files and vendor contracts: review call-off orders, competitive tenders, sole-source justifications and supplier invoice-to-payment chains to verify compliance with municipal procurement thresholds and competitive requirements by Month 2, 5, 8, and 11 (2026-12-08, 2027-03-08, 2027-06-08, 2027-09-08).
- Monthly internal financial review: reconcile budget burn against planned spend by cost category (refuges, transport, kits, staffing, communications); flag overruns >10% and conduct drill-down reviews with cost-center owners within 5 working days.
- Biweekly data-integrity spot-checks of outreach contact logs and transport-dispatch records: audit 10% sample of recorded calls, contact outcomes and pickup times against actual partner records; validate drill metrics against real-time recordings or witness statements.
- Post-gate audit at Month 4 (2027-02-08): independent verification of all three gate metrics (80% center hours, 60% outreach success, <45-min transport) by external auditor; compare drill data against baseline assumptions and drill protocol to confirm fairness of measurement.
- Annual compliance audit of partner organizations (housing associations, NGOs, social services, pharmacies) against GDPR data-processing agreements: review consent records, staff confidentiality training logs, data-retention compliance and breach-notification procedures by Month 9 (2027-07-08).
- Post-season evaluation audit (Month 12 = 2027-10-08): verify heat-related EMS and ED data quality with hospitals/EMS, reconcile baseline estimates against final case counts, and validate any reported reductions in mortality with independent cause-of-death review.

## Audit - Transparency Measures

- Monthly public dashboard (municipal website) reporting: planned vs. actual cooling-center hours delivered, outreach contact attempts and success rates by partner, transport requests and average response times, cumulative kit installations by neighborhood, and budget spend-rate against forecast by cost category; updated by 5th of each month.
- Published weekly meeting minutes from the incident-command team and monthly partner-coordination meetings: document alert declarations, trigger thresholds used, cross-department decisions on escalation, corrective actions closed, and budget reforecasts; accessible to council and stakeholders within 5 working days of meeting.
- Heat Response Playbook (draft by Month 11 = 2027-09-08, final at Month 12 = 2027-10-08): public document detailing all SOPs, decision logic, cost assumptions, staffing specifications, partner roles and lessons learned; identifies city-specific adaptations and replicability conditions for peer EU cities.
- Quarterly public stakeholder briefing (Months 1, 4, 7, 10 = 2026-11-08, 2027-02-08, 2027-05-08, 2027-08-08): open forum where vulnerable residents, NGO partners, faith leaders and media can ask questions about program progress, equity coverage and upcoming actions; minutes published within 10 days.
- Procurement transparency summary (published by Month 2 = 2026-12-08): list all contracts ≥€50k with vendor name, scope, value, procurement route and rationale for method (e.g., 'framework call-off for rapid kit delivery') to enable scrutiny and demonstrate competitive justification.
- Post-season evaluation report (Month 12 = 2027-10-08): independent university analysis of heat-related EMS calls, ED visits and excess mortality with explicit confidence intervals, comparison-group methodology, temperature adjustment and attribution caveats; published in plain-language summary and technical annex for public and peer-city use.

# Internal Governance Bodies

### 1. Heat Response Steering Committee

**Rationale for Inclusion:** This is a high-complexity, multi-department municipal program with strategic dependencies on mayoral authority, cross-departmental coordination, and significant reputational risk. A strategic-oversight body is essential to ensure political alignment, secure timely budget decisions, resolve inter-departmental conflicts, and provide accountability to the funder and city council. The brief explicitly requires a mayor's-office incident commander; a Steering Committee crystallizes this authority and ensures continuity across staff transitions.

**Responsibilities:**

- Approve alert-trigger thresholds and incident-command delegation; escalate threshold changes to council if politically sensitive
- Release or withhold €1.5M tranche-2 funding at Month 4 (2027-02-08) based on gate-review evidence
- Resolve cross-department resource conflicts (e.g., public works, health, civil protection) and authorize budget reallocation
- Review monthly reforecasts and approve contingency-reserve drawdowns >€20k
- Oversee legal and GDPR compliance; approve data-processing agreements with partners
- Approve Year-2 roadmap and playbook before public release

**Initial Setup Actions:**

- Establish written delegation of incident-command authority signed by the mayor by Month 1 (2026-11-08)
- Set alert-trigger thresholds (Level 1: high ≥33°C or low ≥20°C on ≥2 consecutive days; Level 2: high ≥35°C and low ≥22°C for ≥2 consecutive days; Level 3: same as Level 2 for ≥3 consecutive days or national red warning) by Month 1 (2026-11-08)
- Approve incident-command and operations structure; name incident commander, operations lead and communications lead by Month 0.5 (2026-10-23)
- Engage GDPR counsel and approve legal-review scope by Month 0.5 (2026-10-23)
- Authorize procurement route and spending authorities by Month 0.8 (2026-11-01)

**Membership:**

- Mayor or delegated chief executive (Chair)
- Deputy Mayor or head of municipal health/public protection (Vice-Chair)
- Director of civil protection and emergency services
- Director of municipal communications
- Municipal finance director (observer for budget forecasts)
- External independent member: university or public-health institute evaluation partner (advisory, non-voting)

**Decision Rights:** Strategic decisions only: alert-threshold setting and modification; tranche-2 funding release/non-release; reallocation of >€20k from contingency; approval of GDPR and data-processing agreements; authorization of procurement routes and supplier sole-source justifications >€100k; approval of Year-2 roadmap and playbook before publication. All operational decisions remain with the incident commander and PMO. Escalation from operational level occurs for decisions impacting budget >€20k, legal exposure, or inter-departmental authority conflicts.

**Decision Mechanism:** Majority vote (4 of 6 members). Quorum = 4 members including Chair or Vice-Chair. Tie-breaker: Chair vote. In emergencies (e.g., mid-alert funding decision), incident commander may brief Chair and one other member by phone and recommend action; formalized in the next meeting (≤3 days). Legal and GDPR decisions require sign-off from legal counsel before vote.

**Meeting Cadence:** Monthly during Months 0–4 (2026-10-08 to 2027-02-08, project setup and gates) on the first Monday; bi-weekly during Months 5–7 (2027-03-08 to 2027-05-08, kit distribution and initial operations); monthly during Months 8–12 (2027-06-08 to 2027-10-08, season and playbook). Emergency meetings within 24 hours if: non-release of tranche-2 becomes likely, legal challenge emerges, major breach occurs, or incident commander escalates unresolved conflict.

**Typical Agenda Items:**

- Incident-command and operational status (via PMO briefing): alert declarations, response performance, gate-metric tracking
- Financial status: budget burn by cost category, reforecast and contingency drawdown justifications
- Legal and GDPR compliance: partner DPA progress, data-protection audit findings, breach-notification log
- Staffing and partner engagement: recruitment status, partner capacity and satisfaction, staff retention and fatigue incidents
- Gate metrics progress: cooling-center hours, outreach contact success, transport response time, drill results (if applicable)
- Risk register review: new risks, escalated mitigation actions, insurance and liability incidents
- Year-2 planning (Months 10–12 = 2027-08-08 to 2027-10-08): roadmap development, scaling cost model validation, funder and peer-city engagement

**Escalation Path:** Steering Committee decisions on budget release, threshold changes or legal interpretation escalate to the city council (or mayoral cabinet if council is not in session) if: (1) spending approval needed is above the mayor's delegated authority, (2) a legal opinion is contested, or (3) the decision affects public policy beyond heat response (e.g., new data-protection rules). Operational escalations to the Steering Committee come from the incident commander or PMO if: unresolved cross-department conflict, contingency drawdown >€20k needed, or legal exposure. If the Steering Committee cannot decide, the mayor casts the deciding vote; if still deadlocked, legal counsel issues a binding opinion (for GDPR/compliance) or the decision is tabled and deferred to the city council.
### 2. Heat Response Operations Team (Incident Command Structure)

**Rationale for Inclusion:** Operational delivery of cooling centers, transport, outreach, home kits and health coordination requires a unified command structure with clear ownership, rapid decision-making authority and incident-day responsiveness. The incident commander must declare alerts, mobilize resources, and coordinate cross-departmental actions within hours. This team executes the alert-trigger ladder, staffs refuges, dispatches transport and manages partner operations during alert periods. It also tracks gate metrics and prepares gate-review evidence for the Steering Committee.

**Responsibilities:**

- Declare heat alerts (Level 1, 2, 3) within 1 hour of forecast trigger; inform partners and public within 24 hours
- Mobilize cooling centers, transport dispatch, phone line and street contact on alert days; stand down when thresholds no longer met and temperatures normal for 48 hours
- Coordinate daily operations: SITREP at 08:30, partner briefing at 09:30, public update by 11:00 on Level 2-3 days
- Manage center staffing, volunteer dispatch, phone-line operations and outreach team deployment; authorize re-allocation of resources between sites if demand exceeds capacity at one location
- Escalate heat-illness or safety incidents to EMS; coordinate with health-system partners (hospitals, EMS) on aggregate data exchange and mutual-aid triggers
- Monitor and track gate-metric data daily: center-hours opened, outreach calls and success rates, transport requests and response times, kit installations
- Conduct monthly review of performance metrics, partner feedback and risk register; escalate budget or resource issues to Steering Committee; authorize corrective actions within operational scope (staffing adjustments, scheduling changes, local script updates)

**Initial Setup Actions:**

- Designate incident commander, public-health deputy, operations lead, communications lead and partner-liaison officer by Month 0.5 (2026-10-23)
- Establish written position descriptions, delegations of authority and role-specific escalation rules for each lead by Month 1 (2026-11-08)
- Establish daily SITREP and briefing schedule (09:30 start, 30-minute duration) and draft agenda templates by Month 1.2 (2026-11-14)
- Set up heat-response operations workspace (shared desks, phone line, email lists, shared drives, daily-log templates) by Month 1.5 (2026-11-23)
- Brief incident-command team on alert thresholds, decision criteria and escalation rules by Month 2 (2026-12-08); conduct tabletop scenario drill by Month 2.5 (2026-12-23)

**Membership:**

- Incident commander (mayor's office or delegated chief-of-staff equivalent)
- Public health deputy (municipal health department)
- Operations lead (civil protection or emergency management)
- Communications lead (municipal communications office)
- Partner-liaison officer (dedicated to this program, may be pooled from public health or social services)
- PMO/program coordinator (reports to incident commander, tracks budgets, gates and schedules)

**Decision Rights:** Operational decisions within delegated spending and personnel authority: alert declaration per thresholds set by Steering Committee; daily resource mobilization and staffing; re-allocation of resources between sites on alert days; partner communications and coordination; frontline incident management (first aid, escalation to EMS, de-escalation protocols). Cannot commit budget >€20k, alter strategic thresholds, or approve procurement without Steering Committee. Can authorize corrective actions <€5k (e.g., emergency supplies, local staff overtime). Decisions on gate-metric interpretation that affect the Month 4 (2027-02-08) release decision escalate to Steering Committee.

**Decision Mechanism:** Incident commander has final authority on daily operational decisions during alert periods. For non-alert decisions (e.g., monthly review, staffing adjustments, corrective actions), incident commander convenes the full Operations Team; consensus sought, but incident commander decides if consensus cannot be reached within 24 hours. Public-health deputy has veto on clinical safety decisions (e.g., escalation protocols, health-data access); if vetoed, incident commander escalates to Steering Committee. Communications lead has editorial control over public messaging; incident commander may override for urgent/sensitive statements, but communications lead may appeal to Steering Committee if override is systematic.

**Meeting Cadence:** Daily during alert days (Level 1, 2 or 3): SITREP 08:30 (15 min), partner briefing 09:30 (30 min), public update 11:00 (10 min). Weekly during non-alert periods (Months 1–5 = 2026-11-08 to 2027-03-08): Monday 14:00 (60 min) to review progress, staffing, procurement and risks. Bi-weekly during summer (Months 6–8 = 2027-04-08 to 2027-06-08) to monitor early heat and kit distribution. Daily during Months 9–11 (2027-07-08 to 2027-09-08, peak season): SITREP and briefing only if alert active; Friday debrief (60 min) for weekly review. Post-season: monthly closure/evaluation meetings.

**Typical Agenda Items:**

- Alert status and threshold interpretation: forecast review, trigger logic, alert-declaration timing and rationale
- Cooling-center operations: occupancy, staffing, supply availability, incident reports, accessibility issues, site-specific problems
- Transport and dispatch: request volume, response times, volunteer driver availability, taxi backup utilization, mobility-limited resident experience
- Outreach and enrollment: contact attempts by partner, success rates, language coverage, difficult-to-reach populations, escalation cases
- Health-system data: daily EMS/ED counts, trends, mutual-aid triggers, clinical escalation cases, hospital capacity alerts
- Staffing and fatigue: absences, incident reports, training gaps, peer support needs, retention issues
- Financial and procurement: spend tracking by category, reforecast, contingency-reserve status, supply-chain delays, vendor performance
- Risk and incident register: new incidents, safeguarding concerns, GDPR breaches, reputational issues, corrective actions status
- Gate-metric tracking: drilling progress, real-event data, readiness for Month 2, 4 (2026-12-08, 2027-02-08) gates

**Escalation Path:** Operational issues affecting gates or requiring >€20k spending escalate to the Steering Committee. During alert periods, critical incidents (serious injury, safety failure, reputational crisis) are reported immediately to the incident commander and chair of the Steering Committee; Steering Committee can convene within 24 hours if needed. If an alert threshold or interpretation is contested by a partner or the health system, the public-health deputy convenes a rapid review (24 hours) with relevant partners; if still unresolved, escalates to Steering Committee. Volunteer or staff safety incidents involving police or legal liability are reported immediately to the incident commander and municipal legal counsel; legal counsel advises on escalation to Steering Committee or council.
### 3. Cooling Center Operations & Accessibility Group

**Rationale for Inclusion:** Ten independent cooling-center sites require consistent staffing, safety, accessibility and service standards. This group ensures each site meets opening-day readiness, delivers planned hours, maintains accessibility, handles incident response and keeps supplies stocked. It is a specialized operational sub-unit reporting to the incident commander's Operations Team, responsible for the tangible 'refuge network' experience. The Month 4 (2027-02-08) gate (80% planned center hours) depends on this group's execution.

**Responsibilities:**

- Coordinate contracting and fit-out (water, first-aid kits, AEDs, signage, quiet rooms) at all 10 sites by Month 2 (2026-12-08)
- Conduct accessibility audit of all sites by Month 1.5 (2026-11-23); prioritize 5 fully accessible sites for May opening
- Hire and train cooling-center managers (1 per site) and support staff (1–2 per site) by Month 4 (2027-02-08); conduct health-and-safety orientation and first-aid training
- Operate centers per alert level: Level 1 = standby only; Level 2 = 10:00-20:00 daily; Level 3 = 3 sites extend to 24:00; stand down within 2 hours of end-alert declaration
- Track daily center-hours delivered, occupancy and supply usage; escalate accessibility or staffing gaps within 4 hours
- Respond to incidents at centers (injury, medical emergency, distressed resident): first-aid response, EMS notification if needed, incident log and debrief within 24 hours
- Manage supply chain (water, ice, first-aid kits, toiletries, printed materials) and inventory; order replacement supplies with 2-week lead time

**Initial Setup Actions:**

- Identify and secure facility-use agreements for all 10 sites by Month 1 (2026-11-08); confirm space, utilities and liability insurance
- Conduct accessibility audit and remediation planning for all sites by Month 1.5 (2026-11-23); prioritize 5 fully accessible sites (≥50% of planned capacity)
- Procure fit-out items (water dispensers, first-aid kits, AEDs, signage, quiet-room setup) and deliver to sites by Month 5 (2027-03-08)
- Recruit and vet cooling-center managers by Month 4 (2027-02-08); assign one manager per site with documented position description
- Conduct opening-day drill at all sites with full staffing, supply checks, accessibility verification and signage by Month 5.5 (2027-03-23)

**Membership:**

- Center Operations Lead (dedicates 1 FTE, reports to incident commander)
- Cooling-center manager representatives from 3–4 sites (rotates quarterly to ensure input from all 10 sites)
- Supply-chain and inventory coordinator (0.5 FTE, shared with other operations)
- Accessibility consultant or municipal disability-access officer (advisory, spot-check verification)

**Decision Rights:** Center Operations Lead approves: staffing adjustments within approved budget (hiring, scheduling changes, overtime up to 10% of budgeted hours); site-specific supply orders and emergency purchases <€2k; minor operational changes (e.g., water-distribution points, signage placement) and local accommodation of residents with disabilities. Cannot approve major remediation (>€10k per site), procurement of new equipment types, or changes to opening hours without incident commander approval. Accessibility decisions require review by the accessibility consultant before implementation. If a site is deemed unsafe or inaccessible beyond remediation, Center Operations Lead recommends closure to incident commander; incident commander decides in consultation with Steering Committee.

**Decision Mechanism:** Center Operations Lead makes routine staffing and supply decisions. Escalations to the incident commander occur if: accessibility or safety issues at a site threaten opening-day readiness, a site manager requests reassignment due to performance or safety concerns, or supply shortages threaten operations. For decisions affecting >3 sites, Center Operations Lead convenes site representatives (≥2 managers) and seeks consensus; if not reached within 24 hours, escalates to incident commander with both the managers' views and the lead's recommendation.

**Meeting Cadence:** Weekly during Months 1–5 (2026-11-08 to 2027-03-08, setup phase): Tuesdays 14:00 (60 min), covering fit-out, staffing, accessibility audit progress and procurement. Daily during alert days (Months 6–11 = 2027-04-08 to 2027-09-08): Morning briefing 08:00 (15 min) covering center readiness, staffing confirmation and supply status; afternoon debrief 18:00 (30 min) reviewing occupancy, incidents and corrective actions. Weekly on non-alert days during summer: Monday 14:00 (45 min) for supply planning, staffing review and accessibility checks.

**Typical Agenda Items:**

- Site readiness: facility-use agreement status, remediation progress, fit-out delivery, staffing assignments and training completion
- Accessibility: audit findings by site, remediation timeline and cost, prioritization of fully accessible sites, accessibility-check checklist completion
- Staffing: hiring progress, first-aid and orientation training, manager readiness, rostering for alert days, absence and leave planning
- Operations: center-hours delivered and occupancy by site, supply usage and inventory, incident reports and safety issues, resident feedback and accommodations
- Procurement and budgets: supply-chain status, lead-time risks, inventory turnover, cost tracking
- Equity: coverage of sites by neighborhood deprivation index, accessibility by disability type, language support availability at each site

**Escalation Path:** Site-specific safety or accessibility issues escalate to Center Operations Lead immediately; if remediation is not feasible within 4 weeks or costs >€10k, escalate to incident commander with options (defer opening, drop site, apply for supplementary funding). Staffing problems (manager unable to work, high absence rate, safety incident involving staff) escalate to incident commander. Supply-chain delays >2 weeks escalate to PMO/procurement coordinator to trigger backup suppliers. If a center fails the accessibility audit and remediation is not feasible, incident commander decides in consultation with Steering Committee whether to proceed with a non-fully-accessible site or defer its opening until remediation is complete. Accessibility consultant may appeal any decision to defer or proceed with non-accessible site to the disability-access ombudsman or local authority if consultation is inadequate.
### 4. Outreach, Enrollment and Intermediary-Partner Coordination Group

**Rationale for Inclusion:** High-risk residents are identified and contacted via intermediary partners (housing associations, social services, NGOs, pharmacies) who hold their own data. This group ensures partner readiness, coordinates outreach protocols and scripts, tracks contact-attempt and success-rate data (the Month 4 2027-02-08 gate requires ≥60% success), and manages the 'no wrong door' enrollment mechanism (phone line + in-person at refuges). It also ensures multilingual access, reaches unhoused people via street contact, and navigates the complex GDPR constraints of intermediary-held lists.

**Responsibilities:**

- Co-design and agree outreach scripts, call targets, escalation rules and feedback mechanisms with each partner by Month 1 (2026-11-08)
- Conduct joint training for all partner outreach staff (50–80 people across housing, social services, NGOs, pharmacies) by Month 2 (2026-12-08); refresher training before June alerts
- Monitor and track partner call volumes, contact attempts and success rates daily on alert days; provide real-time feedback to partners (call target vs. actual, success rate vs. gate threshold)
- Operate the heat-response phone line (08:00–22:00 daily; 24:00 at Level 3): answer enrollment inquiries, provide information on cooling centers and transport, log calls and escalations
- Coordinate street contact (NGO-led rounds for unhoused residents) and drop-in cool points at day centers; track outreach to unhoused cohort separately
- Manage 'no wrong door' intake: accept registrations at phone line and in-person at cooling centers; feed enrollment into transport and outreach dispatch systems
- Ensure multilingual access: coordinate interpretation services for phone line and outreach staff; brief community-language ambassadors; track language diversity in call logs

**Initial Setup Actions:**

- Identify and sign MOUs with ≥4 key intermediary partners (housing associations, social services, NGOs) by Month 1 (2026-11-08); specify outreach commitments, data terms and escalation contacts
- Draft outreach script (3–5 minute format with escalation rules) in collaboration with partners and nurse adviser by Month 1 (2026-11-08); test with focus groups of older residents by Month 1.5 (2026-11-23)
- Identify top 4–6 non-official languages spoken in the city and commission translation of core materials (flyer, enrollment script, escalation guidance) by Month 1 (2026-11-08)
- Recruit 8–12 community-language ambassadors from migrant associations by Month 1.5 (2026-11-23); brief them on heat illness, centers, transport and protocol by Month 2 (2026-12-08)
- Procure phone line infrastructure, call-tracking software (shared spreadsheet or secure platform) and first-aid/incident-escalation templates by Month 1.5 (2026-11-23); conduct mock-call drills with partners by Month 2 (2026-12-08)
- Agree street-contact protocol with homeless-service NGO partners and co-design referral cards and water/shade provision by Month 1 (2026-11-08)

**Membership:**

- Outreach and Enrollment Lead (1 FTE, reports to incident commander)
- Phone-line coordinator (1 FTE, reports to outreach lead)
- Partner-liaison officer (if separate from Command-Structure role; else liaison officer split between both groups)
- Representative or contact person from each of ≥4 key intermediary partners (housing association, social service, NGO, pharmacy chain)
- Community-language ambassador representative (rotating, 1 ambassador per month, advisory)

**Decision Rights:** Outreach Lead approves: script iterations and local language-specific adaptations within the agreed escalation framework; partner-specific call-target adjustments (up to ±20% of planned volume) based on partner feedback and capacity; local accommodation for residents (e.g., preferred language, preferred contact time) within the no-wrong-door protocol. Cannot approve changes to alert thresholds or escalation criteria without incident commander; cannot alter the 60% contact-success gate measurement without Steering Committee; cannot change phone-line hours or escalation path to health services. Partner representatives approve their own staffing decisions and call-volume commitment changes; if a partner proposes to reduce call volume by >20%, escalates to partner-liaison officer and incident commander.

**Decision Mechanism:** Outreach Lead makes routine enrollment, call-tracking and script decisions. Monthly partner-coordination meetings convene all partner representatives; consensus sought on call targets, script effectiveness and performance feedback; if consensus cannot be reached on a data-sharing or escalation issue, outreach lead proposes a resolution with documented partner input, and incident commander decides. Language and cultural-appropriateness decisions are made by outreach lead with input from community-language ambassadors and focus-group feedback; ambassadors have veto over messaging that is culturally insensitive or medically inaccurate, with escalation to incident commander if overridden.

**Meeting Cadence:** Weekly during Months 1–5 (2026-11-08 to 2027-03-08, setup and training): Wednesdays 14:00 (90 min) for script finalization, training delivery and materials translation. Bi-weekly during Months 6–8 (2027-04-08 to 2027-06-08, pre-season and early season): Mondays 10:00 (60 min) for phone-line readiness, partner briefing and early-season performance review. Daily during alert days (Months 9–11 = 2027-07-08 to 2027-09-08): Morning briefing 08:00 (10 min) confirming partner call staffing; afternoon debrief 17:00 (30 min) reviewing call volumes, success rates and incidents. Weekly on non-alert days during summer: Friday 14:00 (60 min) for performance tracking, troubleshooting and partner feedback.

**Typical Agenda Items:**

- Partner readiness: MOUs signed, staffing confirmed, training completed, data-tracking systems set up, access to call-list data from each partner confirmed
- Script and protocol: script effectiveness feedback from partners, escalation decision-making, language-specific adaptations, cultural appropriateness checks
- Phone-line operations: call volume, wait times, interpreter availability, incident escalations, staff fatigue and feedback
- Outreach performance: contact attempts and success rates by partner, comparisons to gate targets, language diversity in calls (≥5% non-official language target), difficult-to-reach populations
- Enrollment and no-wrong-door: in-person intake at cooling centers, phone-line registrations, duplicate prevention, data quality checks
- Street contact and unhoused: NGO round volumes, outreach to unhoused residents, referrals to centers and transport, incident reports
- Multilingual access: interpretation-service utilization and cost, translation quality feedback, ambassador recruitment and briefing progress, pictogram effectiveness
- GDPR and data protection: partner compliance audit schedule, consent-withdrawal log, data-retention timeline, breach-notification protocol

**Escalation Path:** Partner capacity issues or call-volume shortfalls escalate to partner-liaison officer; if a partner cannot meet ≥40% of target calls, incident commander evaluates remediation (additional support, reduced target, partner replacement). Phone-line staffing or infrastructure failures escalate to outreach lead immediately; if outages exceed 2 hours, incident commander is notified and backup protocols activated (e.g., SMS registration, in-person-only intake). Contact-success rate trending <60% triggers real-time adjustment: script review, partner debriefing, target reassessment and extra briefing by end of week. Language-access gaps (>5% of calls cannot be answered in the resident's language) escalate to outreach lead with 5-working-day remediation plan (additional interpreter, ambassador deployment). GDPR compliance concerns (e.g., partner data breach, unauthorized contact) escalate immediately to legal counsel and GDPR adviser; incident commander and Steering Committee notified if breach is serious or affects >100 residents.
### 5. Transport Coordination and Dispatch Group

**Rationale for Inclusion:** The transport system (volunteer drivers + taxi backup) determines whether the Month 4 (2027-02-08) gate of <45-minute average pickup time is met. This group recruits and manages volunteer drivers, coordinates with taxi operators, dispatches rides during alert days, and ensures wheelchair-accessible transport for mobility-limited residents. Transport is a critical bottleneck: if volunteer recruitment falls short or taxi retainers are insufficient, the entire gate fails, and home-kit budget gets cut. This group must operate with reliable metrics, clear prioritization and responsive escalation.

**Responsibilities:**

- Recruit, vet (background checks, insurance, safeguarding) and train volunteer drivers (target 40, range 30–50) by Month 2 (2026-12-08); conduct refresher training before June
- Manage volunteer-driver insurance and liability; conduct biannual safety reviews of volunteer fleet
- Sign standby-retainer contract with taxi/accessible-transport operator (capped €80k, ≥10 vehicles within 20 min, ≥3 wheelchair-capable) by Month 1.2 (2026-11-14); manage taxi-operator performance
- Operate dispatch center: answer transport requests, confirm destination (cooling center choice), prioritize elderly and mobility-limited residents (target 30-min pickup), general residents (target 45-min), log all requests and actual response times
- Ensure wheelchair-accessible vehicles are matched to wheelchair-user requests; track accessibility-accommodation success rate
- Track daily requests, response times, volunteer-vs-taxi utilization, failed requests and reasons; escalate gaps to incident commander
- Manage volunteer coordination: rostering, absence coverage, fuel/mileage reimbursement, incident reporting and debrief if volunteers encounter distressed residents

**Initial Setup Actions:**

- Identify and vet potential volunteer drivers from community networks (retirees, charity staff, faith groups) by Month 0.5 (2026-10-23); launch recruitment campaign by Month 0.8 (2026-11-01)
- Design volunteer vetting process (background check, driving-history review, safeguarding check, insurance verification) and conduct batch vetting (monthly cohorts) beginning Month 1 (2026-11-08)
- Procure taxi/accessible-transport standby retainer and sign contract by Month 1.2 (2026-11-14); include performance-measure clauses (response time <20 min, vehicle availability ≥80%, wheelchair-accessible vehicles ≥3)
- Establish dispatch infrastructure: phone line with call-logging, volunteer driver contact list, taxi operator hotline, shared real-time tracking spreadsheet or app, maps of cooling centers and travel times
- Recruit dispatch coordinator and backup dispatcher by Month 3 (2027-01-08); conduct dispatch training and mock-drill by Month 3.5 (2027-01-23)

**Membership:**

- Transport Lead / Dispatch Coordinator (1 FTE, reports to incident commander)
- Backup dispatcher (1 FTE)
- Volunteer driver representative (rotating, 1 volunteer per month, advisory)
- Taxi-operator contract manager (external, coordinated by transport lead)
- Accessibility advocate or disability-access officer (advisory, quarterly vehicle-access audits)

**Decision Rights:** Transport Lead approves: volunteer driver scheduling and roster adjustments; mileage/fuel reimbursement within budget; taxi-operator escalation (performance complaints, vehicle failures); local routing and destination changes per resident preference (e.g., preferred center). Cannot approve changes to response-time gates (30 min for priority, 45 min average), volunteer recruitment targets or taxi retainer terms without incident commander. Cannot commit >€5k for emergency transport or vehicle rental without incident commander approval. Volunteer representatives provide feedback on driver experience; taxi operator commits to service-level targets; both can escalate performance concerns to transport lead with 24-hour response required.

**Decision Mechanism:** Transport Lead makes routine dispatch and volunteer-management decisions. Volunteer-recruitment strategy and targets are set by transport lead with incident commander (Month 0.5 = 2026-10-23). Taxi-operator performance disputes are reviewed monthly by transport lead; if unresolved, escalate to incident commander. Priority-resident pickup (30-min target for mobility-limited) overrides general requests within dispatcher authority; if dispatch system cannot meet 30-min target >10% of the time, transport lead convenes emergency review with volunteers and taxi operator to identify and fix bottlenecks within 2 days.

**Meeting Cadence:** Weekly during Months 0–5 (2026-10-08 to 2027-03-08, recruitment and setup): Thursdays 14:00 (60 min) covering volunteer recruitment pipeline, vetting cohort schedule, taxi-contract negotiation and dispatch-infrastructure setup. Bi-weekly during Months 6–8 (2027-04-08 to 2027-06-08, pre-season): Thursdays 10:00 (45 min) for volunteer training, rosters, taxi-operator readiness and transport stress-test planning. Daily during alert days (Months 9–11 = 2027-07-08 to 2027-09-08): Dispatch briefing 07:30 (10 min) confirming volunteer and taxi availability; afternoon debrief 18:00 (30 min) reviewing request volumes, response times, accessibility matches and incidents. Weekly on non-alert days: Thursday 14:00 (60 min) for performance metrics, route optimization and volunteer feedback.

**Typical Agenda Items:**

- Volunteer recruitment and vetting: recruitment campaign results, vetting-cohort completion, signed agreements, insurance verification, training status
- Volunteer rostering and management: scheduling for alert days, absence coverage, fuel/mileage reimbursement tracking, incident reports and debriefings, retention feedback
- Taxi-operator performance: request fulfillment, response times, vehicle availability, wheelchair-accessible vehicle deployment, incident reports, contract compliance
- Dispatch operations: daily request volume and response times, volunteer vs. taxi utilization ratio, failed requests and reasons, priority-resident pickup success (30-min target)
- Accessibility: wheelchair-user request matching, vehicle-access audit results, accessibility-accommodation success rate, resident feedback
- Transport stress test (pre-season May drill): simulated request volume, dispatch load, response-time achievement, bottleneck identification and fixes
- Financial tracking: volunteer mileage/fuel reimbursement, taxi-operator invoice reconciliation, budget forecast

**Escalation Path:** Volunteer-recruitment shortfalls (pipeline <20 drivers by Month 1.5 = 2026-11-23) trigger taxi-retainer scale-up (capped €80k); transport lead proposes adjustment, incident commander approves. Volunteer safety incidents (assault, accident, safeguarding concern) escalate immediately to transport lead and incident commander; occupational health and legal counsel notified. Taxi-operator performance failures (response time >30 min >25% of the time, vehicle unavailability) are escalated to taxi operator with 48-hour remediation plan; if unresolved, incident commander considers contract termination or reduced reliance on volunteers. Accessibility failures (>1 wheelchair user cannot be transported within <45 min) trigger immediate review and extra wheelchair-capable taxi deployment. If average response time exceeds 45 minutes for >1 consecutive alert day, incident commander convenes emergency review with transport lead, volunteers and taxi operator within 24 hours to identify causes and corrective actions; failure to achieve <45 min within 3 days escalates to Steering Committee as gate risk.
### 6. Home Kit Distribution, Installation and Quality Assurance Group

**Rationale for Inclusion:** The home-kit program (shading, fans, thermometers, hydration supplies) reaches 2,000 high-risk homes (top-floor, poorly insulated, elderly, isolated). This group manages procurement, targeting, installation scheduling, handyperson vetting, and quality checks (particularly fan-safety). Installation must complete by Month 7.3 (2027-05-17) to benefit from the first heat events. The group also tracks equity metrics (coverage by neighborhood, housing type, age), manages supply logistics, and ensures GDPR compliance in the targeting process (no unauthorized access to vulnerability scores).

**Responsibilities:**

- Develop and maintain household-targeting rubric (score 0-100: top-floor 30 pts, age ≥75 25 pts, living alone 20 pts, pre-1980 15 pts, no AC 10 pts; ≥60 for kit eligibility) based on Consent-Light Identification Routes data
- Identify eligible households from enrolled high-risk residents and partner lists; verify consent before approaching; generate installation schedules by neighborhood and housing block
- Procure cooling kits (exterior shading, reflective blinds, fans, thermometers, hygrometers, hydration supplies) with 30–40% first call-off by Month 1.2 (2026-11-14); stagger deliveries to meet Feb, Mar, Apr, Jun targets
- Recruit, vet and train handypersons (target 10 FTE for Months 4–7 = 2027-02-08 to 2027-05-08) in installation safety, fan-use guidance and building-code compliance by Month 3 (2027-01-08)
- Schedule and execute home installations with consent, accessibility accommodation (no multi-floor climbs for elderly) and safety checks (fan testing, shading wind resistance, electrical safety); provide written guidance to residents on safe use (translated)
- Conduct quality-assurance inspections of 10–20% of installations (random sample + risk-based high-floor sites) by external QA auditor; log any issues and corrective actions within 5 days
- Track and report equity metrics: % installed by neighborhood deprivation index, housing type (social vs. private rental vs. owner-occupied), age band and language; identify and close coverage gaps by June

**Initial Setup Actions:**

- Obtain partner contact lists (housing associations, social services) and enrolled high-risk residents by Month 0.5 (2026-10-23)
- Finalize household-targeting rubric and validate against sample population by Month 1 (2026-11-08); check GDPR compliance of rubric (no sensitive data stored outside consent scope)
- Issue procurement specs for kits by Month 0.8 (2026-11-01); place first call-off order (30–40%) by Month 1.2 (2026-11-14); arrange storage by Month 3 (2027-01-08)
- Identify and vet handyperson service providers or recruit individual handypersons (employment vs. contract) by Month 2.5 (2026-12-23); conduct safety and installation training by Month 3 (2027-01-08)
- Design home-installation packet: consent form, scheduling letter, safety guidance, installation checklist and follow-up; translate into 4–6 languages by Month 2 (2026-12-08)

**Membership:**

- Home Kit Lead / Installation Coordinator (1 FTE, reports to incident commander)
- Procurement and logistics coordinator (0.5 FTE, shared with general procurement)
- Handyperson supervisor (1 FTE, manages 10-person team)
- Quality-assurance auditor (0.5 FTE external or internal, spot-check inspections)
- Equity analyst or data coordinator (0.5 FTE, tracks coverage metrics)
- Housing-sector representative from a key partner (advisory, site-access and landlord-cooperation facilitation)

**Decision Rights:** Home Kit Lead approves: household eligibility assessments per the agreed rubric; installation scheduling and route optimization; handyperson assignments and rescheduling; quality-assurance findings and corrective-action authorization (up to €500 per fix). Cannot alter the targeting rubric or equity metrics definitions without Steering Committee (data-governance and fairness decision). Cannot commit >€5k for emergency kit procurement or expedited delivery without incident commander. Handyperson supervisor approves: work scheduling, overtime, tool and supply management, and preliminary safety checks before formal QA. QA auditor has veto over any installation deemed unsafe (fan misuse, shading wind-resistance failure, electrical hazard); veto escalates immediately to Home Kit Lead and incident commander for remediation or re-do.

**Decision Mechanism:** Home Kit Lead makes routine targeting, scheduling and quality decisions. Eligibility disputes (e.g., a resident just below the 60-point rubric threshold but clearly vulnerable) are escalated to Home Kit Lead with partner input; lead decides with documented rationale (e.g., 'approved despite 58 points due to note from GP of severe cardiac disease'). Equity coverage gaps (e.g., <5% of kits in highest-deprivation neighborhoods by Month 6 = 2027-04-08) trigger review by home kit lead and equity analyst; if closure plan is inadequate, escalates to incident commander and outreach lead for outreach-targeted recruitment into the target neighborhoods. Handyperson safety or performance issues escalate to handyperson supervisor; if unresolved within 24 hours, escalate to home kit lead.

**Meeting Cadence:** Weekly during Months 0–3 (2026-10-08 to 2027-01-08, procurement and planning): Mondays 14:00 (60 min) for rubric finalization, procurement specs and handyperson recruitment. Weekly during Months 4–7 (2027-02-08 to 2027-05-08, installation): Mondays 10:00 (90 min) covering scheduling, supply delivery, handyperson deployment, quality-assurance findings and equity-coverage tracking. Bi-weekly during Months 8–11 (2027-06-08 to 2027-09-08, post-installation): Mondays 14:00 (45 min) for final coverage reports, lessons learned and follow-up surveys.

**Typical Agenda Items:**

- Targeting and eligibility: rubric validation, household-list generation, consent status by partner, enrollment growth vs. installation targets
- Procurement and logistics: kit delivery schedules, storage utilization, backup supplier status, lead-time risks, cost tracking
- Handyperson recruitment and training: hiring progress, training completion, safety protocols, incident reports, performance feedback
- Installation scheduling and execution: weekly installation targets, neighborhoods covered, appointment confirmations, accessibility accommodations (e.g., elderly mobility limits), resident feedback
- Quality assurance: inspection results, defect rates, corrective-action log, safety incidents, re-do or remediation completion
- Equity metrics: installations by neighborhood deprivation, housing type, age band, language; comparison to targets; coverage-gap analysis and closure plans
- Follow-up and resident satisfaction: post-installation surveys, safe-use guidance effectiveness, complaints or misuse reports

**Escalation Path:** Supply-chain delays (first call-off delivery >2 weeks late) escalate to procurement coordinator and incident commander; backup suppliers triggered if delay exceeds 3 weeks. Handyperson recruiting shortfalls (fewer than 7 of 10 FTE recruited by Month 3 = 2027-01-08) escalate to home kit lead; contingency: contract temporary labor or reduce installation targets. Installation-pace shortfalls (trajectory shows <80% completion by Month 7 = 2027-05-08) trigger schedule tightening and overtime authorization by home kit lead; if still on track to miss target, escalates to incident commander. Quality-assurance failures (>10% of inspected installations unsafe) trigger remedial training and re-work; if defect rate persists, handyperson supervisor and affected providers are reviewed for replacement. Equity-coverage gaps (highest-deprivation neighborhoods <30% of target by Month 6 = 2027-04-08) escalate to outreach lead for additional targeted enrollment; if closure plan unavailable within 1 week, escalates to incident commander and Steering Committee as equity risk.
### 7. Legal, GDPR Compliance and Data Protection Group

**Rationale for Inclusion:** This is a high-risk program handling personal data from intermediary partners, consent protocols, and partner data-processing agreements. GDPR compliance is a hard constraint; any significant breach or challenge could halt outreach mid-season. This group ensures pre-cleared data-processing agreements with each partner type, audits partner compliance mid-season, manages breach notification, and oversees data retention and deletion. It is a specialized assurance body reporting to the Steering Committee and supporting the incident commander's operations.

**Responsibilities:**

- Engage GDPR legal counsel by Month 0.5 (2026-10-23); obtain legal opinion on intermediary-held list model and consent basis by Month 1 (2026-11-08)
- Draft template data-processing agreements (DPAs) for housing associations, social services, NGOs and pharmacies specifying lawful basis (public task + consent hybrid typical), data scope (contact details and risk flags only, no health records), retention (one season, delete after), and breach notification (<48 hours)
- Obtain partner sign-off on DPAs by Month 1.5 (2026-11-23); brief partner staff on GDPR obligations and confidentiality by Month 2 (2026-12-08); document training attendance
- Conduct data-protection impact assessment (DPIA) screening for the program; if higher risk (unlikely given intermediary model), commission full DPIA by Month 1.5 (2026-11-23)
- Audit partner GDPR compliance at Month 9 (2027-07-08): spot-check consent records (≥20 files per partner), staff confidentiality training logs, data-retention status and any disclosed breaches; issue audit report with corrective-action requests
- Establish breach-reporting hotline and incident log; if breach reported, assess impact within 24 hours and notify data-protection authority within 48 hours if required (>100 individuals at high risk); notify affected residents within 5 days
- Oversee data deletion at season end (by October 31, Month 13 = 2027-11-08, unless re-consent obtained)

**Initial Setup Actions:**

- Retain GDPR specialist legal firm by Month 0.5 (2026-10-23) (estimated cost €20k–30k for advice + DPA drafting)
- Brief legal firm on intermediary-held list model, partner types, expected data types and retention needs by Month 0.7 (2026-10-29)
- Receive and review legal opinion on lawful basis and DPA template by Month 1 (2026-11-08); incorporate feedback and customize DPAs for each partner type
- Distribute DPA drafts to partners by Month 1.3 (2026-11-17) with 2-week sign-off target; resolve partner queries by Month 1.5 (2026-11-23)
- Conduct DPIA screening by Month 1 (2026-11-08); commission full DPIA if required by Month 1.3 (2026-11-17)

**Membership:**

- Legal and GDPR Lead (0.5–1 FTE, reports to Steering Committee and incident commander, likely shared with municipal legal department)
- GDPR specialist legal counsel (external retainer, available for advice on breaches, interpretation disputes)
- Data-protection officer (if the city has a DPO; else legal lead assumes this role)
- Partner representative from each partner type (advisory, DPA compliance and feedback)

**Decision Rights:** Legal lead approves: final versions of DPAs and partner briefing materials; DPIA screening and determination (full DPIA needed or not); breach-notification decisions (authority notification required or not); data-retention and deletion schedules; staff confidentiality training content and verification; audit findings and corrective-action requests to partners. Cannot approve operational decisions that have legal implications (e.g., change to data scope, alteration of lawful basis) without consulting GDPR legal counsel. Cannot override GDPR counsel's legal opinion; if counsel is consulted and gives advice, legal lead must follow unless Steering Committee overrides (documented with funder notification). Partners cannot opt out of DPA compliance; non-compliance is an enforcement matter handled by legal lead with incident commander escalation.

**Decision Mechanism:** Legal lead makes routine GDPR and data-protection decisions (training, audit scheduling, breach assessment). GDPR counsel and legal lead consult on novel or contentious issues (e.g., expanded data scope, new partner type); legal counsel advises, legal lead decides with incident commander. Partner DPA disputes (e.g., partner claims data scope is too broad) are addressed first by legal lead with partner; if unresolved, escalates to incident commander and then Steering Committee if necessary. Breach investigations are led by legal counsel with legal lead oversight; incident commander and Steering Committee kept informed.

**Meeting Cadence:** Weekly during Months 0–2 (2026-10-08 to 2026-12-08, setup phase): Thursdays 10:00 (60 min) for legal opinion development, DPA drafting and partner briefing preparation. Bi-weekly during Months 3–8 (2027-01-08 to 2027-06-08): Thursdays 14:00 (45 min) for compliance monitoring, staff training verification and incident log review. Monthly during Months 9–12 (2027-07-08 to 2027-10-08, audit and closure): Thursdays 14:00 (45 min) for audit findings, partner corrective actions and data-deletion planning.

**Typical Agenda Items:**

- GDPR counsel advice: interpretation of lawful basis, DPA compliance, partner questions, novel scenarios or disputes
- DPA status: partner sign-off progress, outstanding negotiations, execution deadlines
- Partner compliance: training attendance logs, data-access controls, file-security verification, incident-awareness surveys
- DPIA and risk assessment: screening results, full DPIA scope (if required), residual risks, mitigation actions
- Breach management: incident log review, breach reports received, assessment and authority-notification decisions, affected-resident notification
- Staff and partner training: confidentiality-briefing attendance, training content updates, re-training scheduling
- Data deletion and retention: end-of-season deletion schedule, resident opt-in renewals for Year 2 (if applicable), data-archival for evaluation (stripped of identifiers)

**Escalation Path:** Novel or contentious GDPR issues escalate to GDPR legal counsel; counsel's written advice is binding on legal lead unless overridden by Steering Committee (with funder and data-protection authority notification). Serious breaches (>100 residents, health data exposed, or deliberate misuse) escalate immediately to legal counsel, legal lead and incident commander; Steering Committee notified; data-protection authority notified within 48 hours if required by law. Partner non-compliance (e.g., unauthorized contact of residents, data breach, failure to train staff) is first addressed by legal lead with incident commander; if unresolved within 10 days, escalates to Steering Committee for enforcement (contract termination, remedial supervision, or referral to data-protection authority). Any request to expand data scope or alter consent basis escalates to legal counsel and Steering Committee for approval.
### 8. Evaluation, Data Quality and Playbook Documentation Group

**Rationale for Inclusion:** Month 12 (2027-10-08) deliverables include a repeatable Heat Response Playbook, a scaling cost model and a credible evaluation report on heat-related EMS calls, ED visits and mortality. This group ensures baseline data quality (Months 0–1 = 2026-10-08 to 2026-11-08), coordinates the evaluation design with a university partner, tracks outcome data throughout the season, produces the Month 4 (2027-02-08) gate-review evidence, and synthesizes lessons learned into the playbook. It is a specialized analytical group reporting to the Steering Committee and supporting the incident commander's after-action reviews.

**Responsibilities:**

- Obtain or estimate baseline heat-related EMS calls and ED visits and excess mortality data from hospitals/EMS; conduct data-quality audit by Month 1 (2026-11-08); agree on heat-attribution coding with clinical partners by Month 2 (2026-12-08)
- Negotiate a data-processing agreement with hospitals, EMS and primary care for daily aggregate heat-related counts (no identifiable records); establish a secure data-sharing method (email, SFTP, API) and a daily 10:00 a.m. delivery target by Month 1 (2026-11-08)
- Conduct a 2-week data-validation pilot in April (Month 6 = 2027-04-08) to test reporting process and identify IT/coding gaps before the season; agree on a fallback method (weekly if daily unavailable) by Month 1.5 (2026-11-23)
- Define evaluation design: baseline vs. pilot heat-days (post-stratified by temperature or matched district comparisons), aggregate EMS/ED counts, excess mortality estimation with temperature adjustment and confidence intervals; pre-specify analysis plan by Month 3 (2027-01-08)
- Convene a university evaluation partner under a data-processing agreement; partner conducts independent analysis and publishes findings regardless of direction by Month 12 (2027-10-08); provides a pre-registration of the analysis plan by Month 3 (2027-01-08)
- Compile all operational-performance data (gate metrics: center hours, outreach success, transport time; equity metrics: coverage by neighborhood and housing type; staffing and budget data) into a project database by Month 4 (2027-02-08) for gate review and later playbook costing
- Draft the Heat Response Playbook from Month 8 (2027-06-08) onward; include SOPs, decision trees, checklists, procurement specs, staffing plans, partner MOUs, cost breakdowns and lessons learned; conduct peer-city review by Month 11 (2027-09-08); finalize by Month 12 (2027-10-08)

**Initial Setup Actions:**

- Request baseline EMS and mortality data from hospitals and EMS by Month 0 (2026-10-08); establish data custodian role and request timelines
- Conduct rapid baseline data-quality audit (completeness, coding consistency, signal reliability) by Month 1 (2026-11-08); document any limitations
- Identify a university or public-health research partner (estimated cost €50k–80k for evaluation services); draft a research-collaboration agreement and data-processing agreement by Month 0.8 (2026-11-01)
- Design and agree evaluation plan with university partner and hospital/EMS clinical leads by Month 2.5 (2026-12-23); finalize by Month 3 (2027-01-08)
- Establish a secure data-sharing infrastructure (encrypted email or SFTP) with hospitals/EMS for daily aggregate counts; begin daily data collection by Month 1.8 (2026-12-02)
- Develop a playbook outline and assign sections by Month 7 (2027-05-08); begin drafting from Month 8 (2027-06-08) with lessons captured in real-time

**Membership:**

- Evaluation and Playbook Lead (0.5–1 FTE, reports to Steering Committee, may be shared with municipal public health or contracted to evaluation partner)
- University evaluation partner: epidemiologist or health-services researcher (lead analyst and publication lead)
- Data analyst (0.5–1 FTE municipal or partner staff, data extraction, quality assurance, database management)
- Health-system data custodian (hospital or EMS representative, provides baseline and ongoing outcome data)
- Incident commander and operations team (source of operational-performance data and lessons learned)

**Decision Rights:** Evaluation Lead approves: baseline data-quality assessments, coding-agreement decisions with clinical partners, evaluation-design specification and analysis-plan finalization with university partner. Cannot alter the fundamental comparison design or attribution methodology without Steering Committee and university partner approval (analytical integrity). Cannot release preliminary or final evaluation findings without university partner review and approval (to ensure scientific integrity). Operational groups approve what data gets extracted and shared for evaluation (performance metrics, program costs); cannot be forced to share data outside the agreed scope without legal/GDPR clearance. University partner has full editorial autonomy over the final evaluation report; findings cannot be suppressed or reframed by the municipality.

**Decision Mechanism:** Evaluation Lead and data analyst make routine data-quality and extraction decisions. Novel methodological questions (e.g., how to account for weather variation in heat-death attribution) are escalated to the university partner for expert advice. Data-collection failures or quality issues are escalated to health-system data custodian with 5-working-day remediation target; if unresolved, escalates to incident commander and Steering Committee for leverage. The university partner retains full autonomy over analytical decisions (statistical methods, interpretation of results); if the city disagrees with a finding, the disagreement is documented and published alongside the main report, but the finding is not suppressed.

**Meeting Cadence:** Monthly during Months 0–3 (2026-10-08 to 2027-01-08, design): Fridays 14:00 (60 min) for baseline-data review, partner agreement and evaluation-plan finalization. Bi-weekly during Months 4–7 (2027-02-08 to 2027-05-08, data collection): Fridays 10:00 (45 min) for data-quality checks, coding-process updates and gate-evidence compilation. Weekly during Months 8–11 (2027-06-08 to 2027-09-08, playbook drafting): Fridays 14:00 (60 min) for section drafting, lessons-capture, cost-model development and peer-city review. Monthly during Month 12 (2027-10-08): Final report, playbook and deliverable finalization.

**Typical Agenda Items:**

- Baseline data: completeness checks, coding agreement with clinical partners, historical patterns and seasonality, confidence-interval estimates for small areas
- Data-sharing infrastructure: hospital/EMS system testing, daily-count delivery confirmation, data-quality monitoring, holiday/staffing coverage for data delivery
- Evaluation design: comparison methodology, temperature adjustment, statistical power, sample-size sufficiency, pre-registered analysis plan, limitations and caveats
- Gate evidence: operationalization of the three gate metrics (center hours, outreach success, transport time), data-collection protocol, drill vs. real-event evidence weighting
- Ongoing outcome data: daily heat-related EMS and ED counts, weekly trend analysis, seasonal patterns, attribution to program activities (attribution challenges and caveats)
- Operational data compilation: center-hours tracking by site, outreach-attempt and success-rate log, transport-request and response-time log, kit-installation progress, staffing and budget by category
- Equity analysis: coverage by neighborhood deprivation, housing type, age band, language; comparison to target groups; outlier neighborhoods with low coverage
- Playbook development: section completion, lessons-learned capture from operations, cost-model development (unit costs per person, per center-hour, per kit), replicability guidance for peer cities
- University partner coordination: progress on analysis, preliminary findings, final-report timeline, data-archival and secondary-use agreements

**Escalation Path:** Baseline-data quality issues (e.g., <80% of heat-related cases are coded consistently) escalate to health-system data custodian and incident commander for remediation; if unresolved, data limitations are documented in the final report and caveats added to gate-review evidence. Data-sharing failures (e.g., hospital cannot provide daily counts due to IT constraints) escalate to Steering Committee for negotiation or fallback method (weekly aggregate). Evaluation-design disputes (e.g., comparison group selection methodology contested by partners) are resolved by the university partner's expert judgment; if the city disputes a decision, documented disagreement is published alongside the final report. Gate-evidence interpretation disputes (e.g., drill results vs. real-event data weighted differently) are decided by the Steering Committee with Evaluation Lead and university partner input. Playbook draft-section disputes (e.g., partners disagree with how their role is documented) are escalated to incident commander for facilitated resolution; final authority rests with Evaluation Lead and playbook editor, who may include dissenting partner commentary in an appendix.

# Governance Implementation Plan

### 1. Senior municipal leadership (mayor's chief of staff or delegated executive) formally designates the incident commander, public-health deputy, operations lead, communications lead and partner-liaison officer. Issue written position descriptions, delegations of authority, and escalation rules specific to each role. Confirm each person's availability for Months 0–12 (2026-10-08 to 2027-10-08) and establish their direct reporting lines to the mayor's office.

**Responsible Body/Role:** Mayor's office or delegated chief executive (pre-project senior leadership), supported by municipal HR director.

**Suggested Timeframe:** By end of Month 0.5 (2026-10-23). Early designation ensures clarity and allows concurrent recruitment and legal setup.

**Key Outputs/Deliverables:**

- Written appointment letters or position confirmations for 5 lead roles
- Role-specific position descriptions and delegations of authority
- Escalation and decision-authority matrix signed by mayor or delegate
- Confirmed start dates and contact details for each lead

**Dependencies:**

- Project approval and budget release by city council or mayor
- Organizational readiness to assign FTE capacity to these roles

### 2. Project Manager or incident commander engages a GDPR specialist legal firm by written contract. Scope: review the intermediary-held list model, draft data-processing agreement templates for housing associations, social services, NGOs, and pharmacies, assess lawful basis for contact, and advise on risk mitigation. Set budget ceiling (≤€30k estimate) and delivery deadline (legal opinion by Month 1 = 2026-11-08).

**Responsible Body/Role:** Incident commander (newly designated), with support from municipal legal department and procurement.

**Suggested Timeframe:** Within 1 week of incident commander's appointment (Month 0.3–0.5 = 2026-10-15 to 2026-10-23).

**Key Outputs/Deliverables:**

- Signed GDPR counsel retainer agreement
- Documented scope and deliverables list
- Budget and timeline agreement
- Counsel contact and escalation protocol

**Dependencies:**

- Incident commander designated
- Budget authorization for legal services (€20k–30k estimate)

### 3. Incident commander convenes the Project Management Office (PMO) core team: project coordinator (FTE), HR/recruitment coordinator (0.5 FTE), procurement specialist (0.5 FTE), and partner-liaison officer. Establish shared workspace (desks, email lists, shared drives), daily standup schedule (09:00, 15 min), weekly planning meeting (Mondays 14:00, 60 min), and communication protocols (escalation hotline, incident log). Publish project charter and governance-body establishment roadmap to all team members.

**Responsible Body/Role:** Incident commander, supported by HR director for staff allocation.

**Suggested Timeframe:** Within 2 weeks of incident commander appointment (Month 0.5–0.7 = 2026-10-23 to 2026-11-05).

**Key Outputs/Deliverables:**

- PMO workspace established with shared digital infrastructure
- Core team roles confirmed and responsibilities documented
- Standup and planning meeting schedules published and confirmed
- Project charter and governance-body roadmap distributed to all stakeholders

**Dependencies:**

- Incident commander designated
- Budget availability for PMO staffing

### 4. Municipal legal department and GDPR counsel jointly draft template data-processing agreements (DPAs) and memoranda of understanding (MOUs) for each partner type: housing associations, social services, NGOs, and pharmacies. DPAs specify lawful basis (public-task/consent hybrid, to be confirmed by counsel), data scope (contact details and risk flags only, no health records), retention (one season, October–September), and breach notification (within 48 hours). Counsel issues written legal opinion on intermediary-held list model and consent basis by Month 1 (2026-11-08).

**Responsible Body/Role:** GDPR specialist legal counsel (external retainer) and municipal legal lead (internal, 0.5 FTE).

**Suggested Timeframe:** Drafts completed by Month 1 (2026-11-08); legal opinion delivered by same date.

**Key Outputs/Deliverables:**

- Template DPA for housing associations (draft)
- Template DPA for social services (draft)
- Template DPA for NGOs (draft)
- Template DPA for pharmacies (draft)
- Written legal opinion on lawful basis and GDPR compliance
- Recommended revisions and clarifications

**Dependencies:**

- GDPR counsel retainer signed
- Municipal legal department engaged

### 5. Project coordinator issues procurement specifications for cooling kits (exterior shading, reflective blinds, fans, thermometers, hygrometers), handyperson installation services, and transport infrastructure (phone line systems, call-tracking software, dispatch coordination tools). Specifications must include required delivery dates (first tranche February, second tranche by April), quality standards, and sustainability/reuse clauses. Contact leading 3–5 suppliers per category to confirm availability and lead times; document responses.

**Responsible Body/Role:** Project coordinator and procurement specialist, with input from Home Kit Lead (once designated; interim coordination via project manager).

**Suggested Timeframe:** Specifications issued by Month 0.8 (2026-11-01); supplier contact and lead-time confirmation by Month 1 (2026-11-08).

**Key Outputs/Deliverables:**

- Kit procurement specification document (v0.1)
- Handyperson service specification
- Transport/dispatch infrastructure specification
- Supplier lead-time and availability summary

**Dependencies:**

- Project PMO established
- Budget allocation for kits and services confirmed

### 6. Incident commander and public-health deputy jointly set and document heat-alert trigger thresholds per the strategic decision (Alert Trigger Ladder). Thresholds: Level 1 Advisory (forecast high ≥33°C or night low ≥20°C on ≥2 consecutive days), Level 2 Alert (high ≥35°C and low ≥22°C for ≥2 consecutive days), Level 3 Emergency (same as Level 2 for ≥3 days or national red warning). Publish thresholds to Steering Committee and all partners. Coordinate with national meteorological service (AEMET) to confirm forecast data access and delivery schedule.

**Responsible Body/Role:** Incident commander and public-health deputy (newly designated).

**Suggested Timeframe:** By end of Month 1 (2026-11-08).

**Key Outputs/Deliverables:**

- Documented alert-trigger thresholds (Level 1, 2, 3) with decision rationale
- Confirmation of forecast data access from AEMET
- Alert decision-tree flowchart and decision authority assignment
- Internal briefing memo for Steering Committee members

**Dependencies:**

- Incident commander and public-health deputy designated
- Strategic decision on Alert Trigger Ladder finalized

### 7. Incident commander prepares a formal agenda, membership list, and standing-meeting schedule for the Heat Response Steering Committee. Confirm availability and meeting commitment from mayor or chief executive (Chair), public-health deputy (Vice-Chair), civil protection director, communications director, municipal finance director and external evaluation partner (advisor). Send meeting invitations and confirm attendance for the first meeting (Month 1.3 = 2026-11-17).

**Responsible Body/Role:** Incident commander with support from municipal chief of staff or executive assistant.

**Suggested Timeframe:** By Month 1.2 (2026-11-14).

**Key Outputs/Deliverables:**

- Steering Committee charter and ToR (v0.1)
- Confirmed membership list with role titles and contact details
- Standing-meeting schedule (monthly, then bi-weekly, then monthly per project phases)
- Agenda template and decision-logging template
- Written calendar invitations sent and RSVPs confirmed

**Dependencies:**

- Incident commander designated
- Governance-body descriptions from governance-phase2-bodies.json available

### 8. HR coordinator launches formal recruitment for all governance-body roles and core staff: Cooling Center Operations Lead (1 FTE), Outreach and Enrollment Lead (1 FTE), Transport Lead / Dispatch Coordinator (1 FTE), Home Kit Lead / Installation Coordinator (1 FTE), Legal and GDPR Lead (0.5–1 FTE, may be municipal legal department role). Publish job descriptions, advertise via municipal channels and relevant professional networks, set application deadline (end of Month 1 = 2026-11-08), and plan interviews for Month 1.3–1.5 (2026-11-17 to 2026-11-30).

**Responsible Body/Role:** HR coordinator (0.5 FTE, designated by incident commander) and municipal HR director.

**Suggested Timeframe:** Recruitment launched by Month 0.8 (2026-11-01); interviews completed by Month 1.5 (2026-11-23).

**Key Outputs/Deliverables:**

- Job description documents for 5 lead roles
- Published recruitment announcements
- Interview panel composition and schedule
- Shortlist of candidates by role

**Dependencies:**

- Incident commander and HR coordinator appointed
- Budget allocation for lead roles confirmed

### 9. First meeting of the Heat Response Steering Committee: Incident commander briefs on project status, governance-structure setup, legal-review scope and timeline, and procurement plan. Steering Committee formally approves: (1) alert-trigger thresholds (Level 1, 2, 3); (2) alert-declaration delegation and backup authority; (3) GDPR legal-review scope and budget; (4) procurement route and spending authority (frameworks + below-threshold for tranche 1). Committee confirms monthly meeting cadence during setup (Months 0–4 = 2026-10-08 to 2027-02-08). Document all approvals and decisions.

**Responsible Body/Role:** Heat Response Steering Committee (majority vote, Chair has tie-breaker; quorum 4 of 6 members including Chair or Vice-Chair).

**Suggested Timeframe:** Month 1.3 (2026-11-17); allow 1 week for scheduling after membership confirmed.

**Key Outputs/Deliverables:**

- Steering Committee meeting minutes with formal approvals
- Signed alert-declaration delegation letter
- Approved GDPR legal-review scope and budget authorization
- Approved procurement route and authority matrix
- Distribution of decisions to all stakeholders and departments

**Dependencies:**

- Steering Committee membership confirmed and first meeting scheduled
- Alert thresholds and delegation drafted for approval
- GDPR legal review initiated

### 10. Partner-liaison officer identifies and initiates formal engagement with ≥4 key intermediary partners: housing associations, social services, NGOs and pharmacy chains. Send introductory letters explaining the program, data-protection model (intermediary-held lists, no personal data to city), expected roles (outreach via their existing contacts, daily call-logging, partner training) and timeline. Request designation of a partner contact person for each organization. Schedule individual scoping meetings to understand partner capacity, existing data systems, and any data-governance constraints.

**Responsible Body/Role:** Partner-liaison officer (incident commander until this role is hired; then designated Partner-liaison Officer within Heat Response Operations Team).

**Suggested Timeframe:** Introductory letters sent by Month 0.8 (2026-11-01); scoping meetings held by Month 1.2 (2026-11-14).

**Key Outputs/Deliverables:**

- Written introductory letters to ≥4 partners
- Scoping-meeting notes for each partner (capacity, data systems, constraints)
- Designated partner contact person and escalation contact for each organization
- Summary of preliminary partner feedback and risks

**Dependencies:**

- Partner-liaison officer designated or interim role assigned
- Program governance and data-protection model finalized

### 11. Cooling-center Operations Lead (or interim coordinator) identifies all potential refuge sites (target 10, range 8–12): libraries, community centers, parish halls, sports halls, malls. Confirm facility ownership/management, current heating/cooling systems, accessibility status, available space for people and supplies, liability insurance, and facility-manager contact. Request provisional facility-use agreements from each site for the 5-month season (June–October, Months 6.8–11.8 = 2027-04-23 to 2027-09-30). Conduct preliminary accessibility audit checklist at each site.

**Responsible Body/Role:** Cooling-center Operations Lead (external candidate or interim coordinator from civil protection or public works) with support from municipal facilities/real-estate office.

**Suggested Timeframe:** By Month 1.2 (2026-11-14); provisional agreements signed by Month 1.5 (2026-11-23).

**Key Outputs/Deliverables:**

- List of 10 proposed cooling-center sites with location maps
- Preliminary facility-use agreements (draft or signed) with each site
- Accessibility audit checklist results for each site
- Summary of required fit-out work and estimated costs per site

**Dependencies:**

- Cooling-center Operations Lead designated or interim role established
- Steering Committee approved governance and alert model

### 12. GDPR legal lead and counsel finalize all template data-processing agreements and MOUs based on counsel's legal opinion (Month 1 = 2026-11-08). Make revisions per counsel advice. Prepare separate versions if needed for different partner types (housing associations may have different data-handling capacity than NGOs). Include: data scope, lawful basis, contact frequency, escalation rules, breach notification (≤48 hours), data deletion schedule (season end), staff confidentiality and training requirements. Distribute finalized DPAs to all identified partners by end of Month 1.3 (2026-11-17) with 2-week review/sign-off target (deadline Month 1.5 = 2026-11-23).

**Responsible Body/Role:** GDPR specialist legal counsel (external) and municipal legal lead (0.5 FTE), with input from incident commander and partner-liaison officer.

**Suggested Timeframe:** Finalized DPAs ready for partner distribution by Month 1.3 (2026-11-17); sign-off deadline Month 1.5 (2026-11-23).

**Key Outputs/Deliverables:**

- Finalized template DPAs incorporating counsel's legal opinion
- Version control and change-log for each DPA
- Covering letter explaining DPA to each partner
- DPA sign-off checklist and tracking log

**Dependencies:**

- GDPR counsel's legal opinion received (Month 1 = 2026-11-08)
- Partners identified and contact persons confirmed

### 13. HR coordinator conducts second-round interviews and makes job offers to selected candidates for Cooling Center Operations Lead, Outreach and Enrollment Lead, Transport Lead / Dispatch Coordinator, Home Kit Lead / Installation Coordinator, and Legal and GDPR Lead. Obtain signed offer letters and employment contracts. Agree start dates (target 50% by Month 1.8 = 2026-12-02, remainder by Month 2 = 2026-12-08). Conduct background checks, occupational health clearance and compliance documentation as required.

**Responsible Body/Role:** HR coordinator (0.5 FTE) and municipal HR director.

**Suggested Timeframe:** Offers made and accepted by Month 1.5 (2026-11-23); contracts signed by Month 1.7 (2026-11-29); start dates confirmed.

**Key Outputs/Deliverables:**

- Signed employment contracts or service agreements (5 lead roles)
- Background-check clearance confirmations
- Occupational health clearance or pre-employment health assessments
- Confirmed start dates and onboarding schedule

**Dependencies:**

- Recruitment interviews completed (Month 1.3–1.5 = 2026-11-17 to 2026-11-30)
- Budget authorization for salaries confirmed

### 14. Incident commander and partner-liaison officer conduct individual scoping meetings with each of the ≥4 identified intermediary partners. Agenda: (1) review partner's existing resident/client contact database and data-protection practices; (2) explain heat-response program goals and the intermediary-held list model (no city access to personal data); (3) present the data-processing agreement template and explain lawful basis for contact (public task / consent hybrid); (4) confirm partner's capacity to conduct phone outreach (call-list, staff, availability); (5) discuss escalation rules and partner feedback mechanism; (6) agree on pilot call targets and schedule for Month 2 (2026-12-08) mock-drill testing. Document all partner commitments and concerns.

**Responsible Body/Role:** Partner-liaison officer (newly hired, or interim coordinator if not yet in post) with incident commander.

**Suggested Timeframe:** Meetings held by Month 1.5 (2026-11-23); documented summaries by Month 1.7 (2026-11-29).

**Key Outputs/Deliverables:**

- Partner-scoping meeting notes (1 per partner)
- Partner capacity assessment and call-target agreement
- Escalation protocol and feedback mechanism agreed
- Partner sign-off on data-processing agreement (or issues flagged for resolution)

**Dependencies:**

- Introductory partner engagement completed (Month 0.8–1.2 = 2026-11-01 to 2026-11-14)
- DPA templates finalized and ready for partner review

### 15. Procurement specialist issues formal procurement notices for kits, handyperson services, and transport infrastructure. For fast-track items (kits, installation, phone systems), use framework call-offs or below-threshold purchasing routes per the approved procurement plan. Issue specification documents, evaluation criteria, and submission deadlines (target: bids due by Month 1.5 = 2026-11-23 for Month 1.7 = 2026-11-29 decision). For taxi/accessible-transport retainer, issue a small competitive RFQ or invite negotiation from 2–3 pre-qualified operators; aim to sign contract by Month 1.2 (2026-11-14) to lock in standby rates before summer demand.

**Responsible Body/Role:** Procurement specialist (0.5 FTE) with incident commander and relevant lead roles.

**Suggested Timeframe:** Notices issued by Month 1.3 (2026-11-17); bids received by Month 1.5 (2026-11-23); awards by Month 1.7 (2026-11-29).

**Key Outputs/Deliverables:**

- Procurement notices for kits, handyperson and phone-system items
- RFQ or invitation for transport retainer contract
- Bid evaluation reports and selection rationale
- Purchase orders or contract awards (pending final signatures)

**Dependencies:**

- Procurement specifications finalized (Month 0.8 = 2026-11-01)
- Budget allocation confirmed
- Steering Committee approval of procurement route

### 16. First operational meeting of the Heat Response Operations Team: Incident commander convenes public-health deputy, operations lead (civil protection), communications lead and partner-liaison officer (interim or newly hired). Agenda: (1) review alert thresholds and incident-command delegation; (2) confirm SITREP and briefing schedule (08:30 and 09:30 on alert days); (3) review public-communications plan and messaging templates; (4) review partner and cooling-center status; (5) establish daily decision-log and escalation hotline; (6) plan for Month 2 (2026-12-08) readiness-gate drills (phone line, outreach mock-calls). Publish operations team charter and meeting schedule to all staff and partners.

**Responsible Body/Role:** Incident commander (chair), with public-health deputy, operations lead, communications lead and partner-liaison officer.

**Suggested Timeframe:** Month 1.5 (2026-11-23).

**Key Outputs/Deliverables:**

- Heat Response Operations Team charter and ToR
- Standing meeting schedule (daily SITREP and 09:30 briefing on alert days, weekly on non-alert)
- Decision-log template and escalation protocol
- Communications-cadence and messaging templates (draft)

**Dependencies:**

- Incident commander and operations leads designated
- Alert thresholds and delegation finalized
- Steering Committee's first meeting held and decisions documented

### 17. All governance bodies now formally established submit their initial meeting minutes and charter documents to the Steering Committee. Legal lead conducts a compliance check: confirm all roles are filled (or interim assignments documented), all DPAs are signed or in final review, all procurement orders are placed, and all operational teams have published charters and meeting schedules. Incident commander submits a project-status dashboard showing: (1) governance bodies operational; (2) staffing progress (% of positions filled); (3) procurement status; (4) partner engagement status; (5) risks and corrective actions. This consolidated status report is reviewed at the Steering Committee's Month 2 (2026-12-08) meeting as part of the readiness-gate assessment.

**Responsible Body/Role:** Legal and GDPR Lead (0.5–1 FTE) with incident commander and PMO coordinator.

**Suggested Timeframe:** Compliance check completed by Month 1.8 (2026-12-02); status dashboard finalized by Month 2 (2026-12-08) readiness-gate meeting.

**Key Outputs/Deliverables:**

- Consolidated governance-body charter and ToR document (all bodies, 1 summary)
- Governance compliance checklist (roles filled, DPAs signed, procurement placed, operational charters published)
- Project-status dashboard (staffing %, procurement %, partner % engaged, risks and corrective actions)
- Month 2 (2026-12-08) readiness-gate evidence summary (centers ready, transport signed, phone line live, training completed, procurement ≥90% ordered)

**Dependencies:**

- All governance-body leads hired and in post or interim-assigned
- DPAs signed with all partners
- All procurement orders placed
- All governance bodies' first meetings held and documented

### 18. Cooling-center Operations Lead finalizes facility-use agreements with all 10 sites. Conduct a detailed accessibility audit at each site using a standardized checklist (wheelchair access, toilet facilities, water points, quiet/low-stimulus rooms, parking, emergency exits, first-aid kit availability, AED locations). Categorize sites as 'fully accessible' (no remediation needed) or 'minor modifications required' (≤€10k, ≤4 weeks). Issue remediation cost estimates and timelines for each site. Prioritize 5–6 fully accessible sites to open by June 1 (Month 6.8 = 2027-05-02). For sites requiring remediation, develop a schedule and budget authorization for work to complete by May 31.

**Responsible Body/Role:** Cooling-center Operations Lead with an accessibility consultant or municipal disability-access officer (advisory role).

**Suggested Timeframe:** Accessibility audit completed by Month 1.5 (2026-11-23); remediation plans finalized by Month 2 (2026-12-08).

**Key Outputs/Deliverables:**

- Detailed accessibility audit report for each of 10 sites
- Categorization of sites (fully accessible, minor remediation, unsuitable)
- Remediation cost estimates and timelines per site
- Site prioritization: 5–6 priority sites for June opening with no or minor work
- Approved remediation budget and schedule

**Dependencies:**

- Cooling-center Operations Lead hired and in post
- Provisional facility-use agreements signed (Month 1.5 = 2026-11-23)
- Accessibility consultant or municipal accessibility office engaged

### 19. Transport Lead (Dispatch Coordinator) begins volunteer-driver recruitment campaign targeting retirees, charity staff, faith-group members and community volunteers. Partner with NGOs, faith organizations, municipal community centers and local media to advertise. Accept applications from October through January (Months 0–3 = 2026-10-08 to 2027-01-08). Conduct vetting in monthly cohorts (background check, driving history, safeguarding screening, insurance verification). Target: 40 volunteer drivers (range 30–50), with ≥20 fully vetted and trained by Month 2 (2026-12-08), remainder by Month 3 (2027-01-08). Provide each volunteer with orientation on heat response, center locations, transport-request protocols, passenger safety and incident reporting.

**Responsible Body/Role:** Transport Lead / Dispatch Coordinator (external hire or interim coordinator from civil protection) with occupational health and volunteer-coordinator support.

**Suggested Timeframe:** Recruitment launched Month 0 (2026-10-08); applications accepted through January; vetting in batches (monthly cohorts beginning Month 1 = 2026-11-08); ≥20 fully trained by Month 2 (2026-12-08), remainder by Month 3 (2027-01-08).

**Key Outputs/Deliverables:**

- Volunteer-recruitment campaign flyers and social-media posts
- Volunteer application form and vetting checklist
- Batch 1 vetting results (background checks passed/failed) by Month 1.8 (2026-12-02)
- Volunteer driver insurance certificates and agreements
- Volunteer orientation and training schedule
- Volunteer roster with contact details and vehicle information

**Dependencies:**

- Transport Lead hired or interim role assigned
- Budget for volunteer expenses (mileage, fuel) and insurance confirmed

### 20. Outreach and Enrollment Lead develops heat-response outreach scripts (3–5 minute call format with escalation rules). Scripts should include: greeting and program introduction; identification of the resident's heat risk; description of cooling centers and transport support; consent confirmation for future contact; escalation triggers (signs of heat illness, social crisis, homelessness). Draft scripts in Spanish and test with focus groups of older residents (target: 10–15 participants) by Month 1.5 (2026-11-23) to confirm clarity, cultural appropriateness and acceptability. Incorporate feedback and finalize scripts by Month 1.8 (2026-12-02). Translate core scripts into 4–6 identified non-official languages by Month 2 (2026-12-08) and conduct language-group focus testing.

**Responsible Body/Role:** Outreach and Enrollment Lead (external hire or interim coordinator) with partner-liaison officer, public-health nurse adviser and community language ambassadors (as they are recruited).

**Suggested Timeframe:** Draft scripts Month 1 (2026-11-08); focus-group testing Month 1.3–1.5 (2026-11-17 to 2026-11-30); revisions and translations Month 1.5–2 (2026-11-30 to 2026-12-08).

**Key Outputs/Deliverables:**

- Heat-response call script (Spanish, v1.0)
- Focus-group testing notes and feedback
- Revised script incorporating feedback (v1.1)
- Escalation decision-tree and escalation script (when to call EMS, when to refer to nurse line)
- Scripts translated into 4–6 languages (draft versions for partner review)

**Dependencies:**

- Outreach and Enrollment Lead hired or interim role assigned
- GDPR legal review completed so scripts comply with consent and data-handling rules
- Community partners (focus groups) identified

### 21. Home Kit Lead develops a household-targeting rubric to identify homes eligible for the 2,000-kit program. Rubric scoring (0–100 points): top-floor or poor insulation = 30 points; age ≥75 (or 65+ with self-declared chronic condition) = 25 points; living alone = 20 points; built before 1980 = 15 points; no air-conditioning = 10 points. Eligibility threshold = ≥60 points. Validate rubric against a sample of 50–100 enrolled high-risk residents from partner contact lists to confirm sensitivity and specificity. Assess GDPR compliance (ensure rubric does not infer protected health data beyond what residents have consented to share). Finalize rubric by Month 1.8 (2026-12-02) and pilot the targeting process on a sample of 200 households by Month 2 (2026-12-08).

**Responsible Body/Role:** Home Kit Lead / Installation Coordinator (external hire or interim coordinator) with Outreach and Enrollment Lead and an equity analyst or data coordinator.

**Suggested Timeframe:** Draft rubric Month 1 (2026-11-08); validation and GDPR check Month 1.3–1.5 (2026-11-17 to 2026-11-30); finalized rubric Month 1.8 (2026-12-02); pilot targeting Month 2 (2026-12-08).

**Key Outputs/Deliverables:**

- Household-targeting rubric (scoring methodology, point weights, threshold)
- GDPR compliance assessment for rubric
- Validation-test results (sample of 50–100 households)
- Pilot-targeting report (200 households scored and prioritized)

**Dependencies:**

- Home Kit Lead hired or interim role assigned
- Enrolled high-risk resident data from outreach partners available
- GDPR legal review confirms data-handling scope

### 22. Incident commander and public-health deputy finalize the emergency-management operational structure in writing. Document: (1) alert-declaration process (forecast data receipt, threshold evaluation, decision authority, notification sequence); (2) daily SITREP and briefing schedule on alert days; (3) stand-down criteria and procedures (alert ends when forecast no longer meets thresholds and actual temperatures normal for 48 hours); (4) escalation hotline and incident-log procedures; (5) mutual-aid triggers with hospitals and EMS (e.g., notify at ≥1.5× historical average heat-related call volume); (6) handover coverage for multi-day events (backup incident commander, rotation of SITREP leads). Publish this as an operational playbook chapter. Conduct a tabletop scenario drill with the Operations Team (2 hours, Month 2 = 2026-12-08) to validate the process and identify gaps.

**Responsible Body/Role:** Incident commander with public-health deputy and operations lead (civil protection), supported by PMO coordinator.

**Suggested Timeframe:** Operational procedures documented by Month 1.8 (2026-12-02); tabletop drill conducted Month 2 (2026-12-08).

**Key Outputs/Deliverables:**

- Alert-declaration and operational procedures document (SOP, flowchart, decision tree)
- SITREP and briefing templates with sample data
- Stand-down criteria and notification procedure
- Mutual-aid trigger matrix (EMS/hospital notification thresholds)
- Tabletop scenario drill after-action report with lessons and corrective actions

**Dependencies:**

- Incident commander and operations leads designated
- Alert thresholds set and approved by Steering Committee
- Operations Team established and first meeting held

### 23. Procurement specialist places the first batch of purchase orders (30–40% of total kit volume, ≈600–800 kits) for cooling supplies (shading, fans, thermometers, hygrometers). Negotiate expedited delivery for February (Month 4 = 2027-02-08) to allow ≥6 weeks for installations before the first summer heat days (target June 1 = Month 6.8 = 2027-05-02). Lock in transport standby-retainer contract terms with taxi/accessible-transport operator if not already signed. Identify 2–3 backup suppliers for each kit category to mitigate supply-chain risk. Arrange secure interim storage (municipal facility or supply partner warehouse) for kits arriving in February–March.

**Responsible Body/Role:** Procurement specialist (0.5 FTE) with Home Kit Lead (once hired) and project coordinator.

**Suggested Timeframe:** First call-off orders placed by Month 1.2 (2026-11-14); transport contract signed by Month 1.2 (2026-11-14); backup suppliers identified by Month 1 (2026-11-08); storage arrangement confirmed by Month 1.5 (2026-11-23).

**Key Outputs/Deliverables:**

- Purchase orders for first kit batch (30–40% of 2,000 kits)
- Signed transport/taxi standby-retainer contract with pricing and performance terms
- Backup supplier contact list and pre-qualification documentation
- Storage facility agreement and inventory-management protocol

**Dependencies:**

- Procurement specs finalized and RFQs issued (Month 0.8–1 = 2026-11-01 to 2026-11-08)
- Supplier bids evaluated and awards recommended (Month 1.5 = 2026-11-23)
- Budget authorization for purchase orders confirmed

### 24. Conduct a formal, comprehensive Steering Committee meeting (Month 2 = 2026-12-08) to review and make a go/no-go decision on the Month 2 (2026-12-08) readiness gate. Gate criteria: (1) ≥8 of 10 cooling-center sites signed with named managers; (2) ≥50% of places in fully accessible sites; (3) transport retainer contract signed; (4) ≥20 volunteer drivers vetted; (5) heat helpline live (08:00–22:00 daily, 24-hour at Level 3) with a successful mock drill (5–8 simulated calls, ≥3 escalations handled correctly); (6) outreach training delivered to 50–80 partner and street-contact staff with ≥80% attendance and pass score; (7) 100% of tranche-1 procurement orders placed. Incident commander presents evidence for each criterion. Committee votes to pass, pass-with-conditions or fail, and approves any corrective actions if gate is not fully passed. Document decision.

**Responsible Body/Role:** Heat Response Steering Committee (majority vote, quorum 4 of 6 including Chair or Vice-Chair), with incident commander and lead-role representatives presenting evidence.

**Suggested Timeframe:** Month 2 (2026-12-08), scheduled 1 week in advance.

**Key Outputs/Deliverables:**

- Readiness-gate evidence summary (1-pager per criterion with supporting data)
- Heat helpline mock-drill after-action report
- Outreach training attendance and assessment results
- Procurement status and order-confirmation list
- Steering Committee decision minutes with formal vote
- Go/no-go approval for proceeding to Month 4 (2027-02-08) scale gate and full operations

**Dependencies:**

- All governance bodies operational and reporting metrics
- Cooling centers, transport, phone line and outreach staff in place
- Mock drills and training completed
- Procurement ≥90% ordered

### 25. Immediately after Month 2 (2026-12-08) readiness gate (whether passed or conditional), Evaluation Lead and university evaluation partner finalize the evaluation design and pre-register the analysis plan. Specify: baseline heat-related EMS and ED counts (obtained from hospitals by Month 1 = 2026-11-08, quality audited by Month 1.5 = 2026-11-23); comparison methodology (pilot vs. matched districts and prior years, aggregate counts only, no identifiable records); temperature-adjustment method; confidence-interval reporting; and plain-language statement of attribution limits. Data-processing agreement with hospitals, EMS and primary care is finalized; daily aggregate-count delivery test (validation pilot) scheduled for April (Month 6 = 2027-04-08). University partner publishes the pre-registered protocol on a registry (e.g., OSF) by Month 3 (2027-01-08).

**Responsible Body/Role:** Evaluation Lead (0.5–1 FTE, municipal or partner) and university evaluation partner (external, ≈€50k–80k contract).

**Suggested Timeframe:** Evaluation design finalized by Month 2.5 (2026-12-23); pre-registered protocol published by Month 3 (2027-01-08).

**Key Outputs/Deliverables:**

- Finalized evaluation design document (comparison groups, statistical methods, attribution approach)
- Data-processing agreement with hospitals/EMS/primary care
- Pre-registered analysis plan (published on OSF or registry)
- Baseline data-quality report and any limitations or caveats
- Data-sharing infrastructure test plan (validation pilot for April)

**Dependencies:**

- Baseline EMS and ED data obtained and quality-audited (Months 0–1 = 2026-10-08 to 2026-11-08)
- University evaluation partner contracted and data-processing agreement signed
- Steering Committee approved the evaluation scope

### 26. Recruit, vet and begin training 8–12 community-language ambassadors from identified migrant associations and communities. Ambassadors will be paid part-time staff (≈10–15 hours/week during alert season) responsible for: translating and culturally adapting materials; co-delivering phone-line interpretation support; accompanying door-knock teams in their own languages; staffing cooling-center welcome desks; and conducting focus-group testing of heat messages. Launch recruitment by Month 1 (2026-11-08) with a target start date of Month 1.8 (2026-12-02). Conduct vetting (background check, reference checks) and onboarding by Month 2 (2026-12-08). Provide ambassadors with a 2-day orientation on heat illness, program goals, escalation rules and confidentiality by Month 2.5 (2026-12-23).

**Responsible Body/Role:** Outreach and Enrollment Lead with partner-liaison officer and community association representatives.

**Suggested Timeframe:** Recruitment launched Month 1 (2026-11-08); ambassadors hired and onboarded by Month 2 (2026-12-08); orientation and training Month 2–2.5 (2026-12-08 to 2026-12-23).

**Key Outputs/Deliverables:**

- Ambassador recruitment flyers in community languages and via partner channels
- Ambassador job descriptions and role expectations
- Selected ambassador list with language coverage and community affiliations
- Background-check and reference-check documentation
- Ambassador orientation and training materials (translated)
- Signed ambassador agreements and NDA/confidentiality documents

**Dependencies:**

- Outreach and Enrollment Lead hired
- Target language groups identified (4–6 languages by Month 0 = 2026-10-08)
- Migrant community associations or NGO partners engaged
- Budget for ambassador stipends and training confirmed

### 27. Legal lead convenes a partner compliance-and-briefing session with representatives from all ≥4 key intermediary partners (housing associations, social services, NGOs, pharmacies). Agenda: (1) present the finalized data-processing agreements and obtain signatures if not yet signed; (2) brief all partner staff on GDPR obligations, data-protection rules, confidentiality and incident-reporting procedures; (3) distribute outreach scripts, escalation protocols and call-logging templates; (4) confirm partner call-target commitments for the remainder of the season; (5) establish weekly/bi-weekly partner-liaison contact schedule; (6) answer partner questions on consent, data-handling and liability. Document attendance and sign-off from each partner. Provide partners with training materials (slide deck, handout) and digital resources (template call logs, escalation guides).

**Responsible Body/Role:** Legal lead (0.5–1 FTE) with Outreach and Enrollment Lead, partner-liaison officer and GDPR counsel (advisors).

**Suggested Timeframe:** Briefing session conducted by Month 2 (2026-12-08); attendance confirmation and sign-off by Month 2.5 (2026-12-23).

**Key Outputs/Deliverables:**

- Signed data-processing agreements from all partners (or documented timeline for final signature)
- GDPR and confidentiality briefing slides and handout materials
- Outreach script and escalation protocol distributed to all partner staff (attendance log)
- Call-logging template and incident-reporting form provided to partners
- Partner commitment letter (call targets, data-handling, escalation)
- Weekly liaison contact schedule published

**Dependencies:**

- DPA templates finalized and customized per partner type (Month 1.3 = 2026-11-17)
- Partners have reviewed DPAs and provided feedback
- Outreach scripts and escalation protocols finalized (Month 1.8 = 2026-12-02)
- Legal lead and GDPR counsel available for briefing

### 28. Heating-systems and procurement coordinator confirms the delivery schedule and logistics for the first batch of cooling kits (30–40% of 2,000, ≈600–800 kits ordered at Month 1.2 = 2026-11-14). Negotiate expedited shipping for February arrival. Arrange intake inspection and inventory verification upon delivery. Set up secure interim storage with climate control (to prevent fan degradation) and an inventory-management system (tracking kit location, condition, hand-off to installers). Prepare a kit-distribution protocol: priority allocation to highest-scoring households (from Home Kit Lead's targeting rubric), geographic batching by neighborhood for installer efficiency, and consent verification before each household's installation is scheduled.

**Responsible Body/Role:** Procurement specialist (0.5 FTE), Home Kit Lead and logistics coordinator (may be shared with general municipal logistics).

**Suggested Timeframe:** Delivery logistics finalized by Month 2 (2026-12-08); storage facility prepared by Month 3 (2027-01-08); first kits received ≈Month 4 (2027-02-08).

**Key Outputs/Deliverables:**

- Kit delivery schedule and shipment confirmations
- Storage facility access and inventory-management protocol
- Kit-distribution sequencing and neighborhood/household priority list
- Installation-scheduling process (consent verification, scheduling letters to residents)
- Inventory-tracking system and daily intake log

**Dependencies:**

- Purchase order for first kit batch placed (Month 1.2 = 2026-11-14)
- Storage facility identified and contracted (Month 1.5 = 2026-11-23)
- Home Kit Lead hired and targeting rubric finalized (Month 1.8 = 2026-12-02)

### 29. Establish the heat-response phone line and dispatch-coordination system. Procure or configure telephony infrastructure (dedicated phone line, call queuing, call recording if permitted by Spanish law, call transfer to interpretation services). Set up call-tracking software (shared spreadsheet with partner-liaison officer, or a secure cloud platform) to log all incoming calls, resident details, requests, responses and escalations. Recruit 2–3 FTE phone-line operators (1 permanent + 1–2 surge/part-time) by Month 1.8 (2026-12-02). Conduct training (call scripts, escalation triggers, de-escalation, interpreter coordination, incident reporting) by Month 2.5 (2026-12-23). Conduct a 4–6 hour mock-call drill with 5–8 simulated calls including escalation cases (heat illness, social crisis) by Month 2.5 (2026-12-23) and document results.

**Responsible Body/Role:** Outreach and Enrollment Lead (phone-line owner) with transport lead (for dispatch coordination), PMO coordinator and occupational health.

**Suggested Timeframe:** Telephony infrastructure procured and installed by Month 1.8 (2026-12-02); operators hired by Month 1.8 (2026-12-02); training and mock drill completed by Month 2.5 (2026-12-23); system live and operational by Month 2 (2026-12-08) readiness gate.

**Key Outputs/Deliverables:**

- Phone-line setup with call-queuing and escalation features (tested)
- Call-tracking system (spreadsheet template or platform)
- Trained phone-line operators (employment contracts, training certificates)
- Call-handling and escalation SOP
- Mock-call drill report (5–8 simulated calls, ≥3 escalations, success rate ≥80%)
- Go-live checklist and 24-hour on-call support plan

**Dependencies:**

- Budget for phone-line setup and operators confirmed
- Outreach scripts and escalation protocols finalized
- Interpretation services contract signed (external provider or municipal arrangement)

### 30. Recruit, vet and begin training handypersons (target 10 FTE for Months 4–7 = 2027-02-08 to 2027-05-17) responsible for installing cooling kits (exterior shading, fans, thermometers). Vet candidates for occupational health and safety certification (or willingness to obtain it), relevant trade experience, background check and occupational-health clearance. Provide each handyperson with a 1-day safety-and-installation training covering: (1) electrical safety and fan-installation safety; (2) fan-use guidance for residents (directional airflow, outdoor-air intake); (3) shading and wind-resistance assessment; (4) building-code compliance checks; (5) customer communication and consent; (6) incident reporting and feedback. Training conducted by Month 3.5 (2027-01-23). Arrange tools, equipment and safety gear by Month 3 (2027-01-08). Finalize handyperson employment or contract terms by Month 3 (2027-01-08) with start date ≥Month 4 (2027-02-08).

**Responsible Body/Role:** Home Kit Lead / Installation Coordinator with occupational health and a qualified trades supervisor or external training provider.

**Suggested Timeframe:** Recruitment launched Month 2 (2026-12-08); hiring completed by Month 2.8 (2027-01-01); training conducted Month 3–3.5 (2027-01-08 to 2027-01-23).

**Key Outputs/Deliverables:**

- Handyperson job description and qualification criteria
- Recruitment announcements and applications (target 10 FTE)
- Vetting documentation (background checks, trade certifications, occupational-health clearance)
- Handyperson employment or service contracts (10)
- 1-day safety-and-installation training curriculum and materials
- Training attendance and assessment results (target ≥80% pass)
- Handyperson roster, contact details and insurance information

**Dependencies:**

- Home Kit Lead hired
- Budget for handyperson wages/contracts confirmed
- Kit components and installation specifications finalized
- Occupational health and safety requirements confirmed

### 31. PMO coordinator drafts the full-system operational drill protocol for Month 3.2 (2027-01-14). Drill will simulate a Level 2 or Level 3 alert lasting 4–6 hours, activating all systems: cooling centers open to full capacity, transport dispatch handles ≥30 simulated requests (including ≥5 wheelchair-user priority cases targeting 30-min pickup), outreach phone line receives ≥20 calls (mixture of enrollment inquiries, requests for transport, escalation cases), and all partner outreach staff place sample calls (≥300 attempts across all partners). Drill will test: center staffing and operations readiness, accessibility compliance, transport dispatch speed and volunteer/taxi coordination, phone-line call handling and escalation, heat-illness recognition and EMS escalation, and inter-organizational communication. Draft evaluation checklist and success criteria (80% center hours, 60% outreach success, <45 min transport time). Publish protocol to all participants by Month 2.5 (2026-12-23).

**Responsible Body/Role:** PMO coordinator (project manager) with incident commander, Cooling-center Operations Lead, Transport Lead, Outreach Lead and all governance-body leads.

**Suggested Timeframe:** Draft protocol completed by Month 2.5 (2026-12-23); drill conducted Month 3.2 (2027-01-14); after-action report completed by Month 3.5 (2027-01-23).

**Key Outputs/Deliverables:**

- Detailed drill protocol (scenario, timeline, participant roles, success criteria)
- Drill evaluation checklist and gate-metric data-collection forms
- Participant briefing and instructions (distributed to all staff and partners)
- Drill execution log (timeline of events, decisions, issues noted)
- Drill after-action report (center-hours delivered, outreach contact success rate, transport response times, escalation cases handled correctly)
- Corrective-action list with owners and completion deadlines

**Dependencies:**

- All governance bodies operational and reporting metrics
- Alert thresholds, operational procedures and escalation protocols finalized
- Cooling centers, transport, phone line and outreach staff in place or nearly in place

### 32. Conduct the full-system operational drill on a specified date (Month 3.2 = 2027-01-14) with all governance bodies and operational teams activated. Incident commander declares a simulated Level 2 alert (forecast high ≥35°C and low ≥22°C for 2 consecutive days). Operations Team convenes at 07:00, SITREP at 08:30, partner briefing at 09:30. Cooling centers open their doors at 10:00 with full staffing; transport dispatch stands by with volunteer drivers and taxi operator on standby; phone line opens at 08:00 with operators and (if possible) live interpretation services. Outreach partners place sample calls (target ≥300 attempts across all partners, ≥60% connection success rate). Transport requests are generated (target ≥30 requests, ≥5 wheelchair-user priority cases). After 4–6 hours of continuous operation, incident commander declares stand-down at 16:00. All teams complete incident logs and action-item forms. A debrief is held the same day (17:00–18:30) with all lead roles present.

**Responsible Body/Role:** Incident commander (exercise controller) with Heat Response Operations Team, all governance-body leads and operational staff (Cooling-center managers, transport dispatchers, phone-line operators, outreach partners).

**Suggested Timeframe:** Drill conducted Month 3.2 (2027-01-14); debrief completed same day; after-action report drafted within 3 days (by Month 3.3 = 2027-01-17).

**Key Outputs/Deliverables:**

- Drill execution log with timeline and decision record
- Center-hours delivered by site (target ≥80% of planned hours)
- Outreach contact attempts and success rates by partner (target ≥60%)
- Transport requests received, response times and wheelchair-user accommodation (target <45 min average, <30 min for priority cases)
- Heat-illness and escalation cases handled (number and outcome)
- Debrief notes and participant feedback
- Incident log of issues, gaps and corrective actions

**Dependencies:**

- Drill protocol finalized and distributed to all participants
- All operational systems (phone line, cooling centers, transport dispatch) live and tested
- Cooling-center staff, transport dispatchers and operators trained and on-call

### 33. Incident commander and key leads review drill after-action report (completed Month 3.5 = 2027-01-23) and identify all corrective actions needed before the Month 4 (2027-02-08) scale gate. Corrective actions fall into categories: (1) staffing gaps (additional operators, volunteers, center support staff); (2) procedural improvements (revised escalation rules, faster transport routing); (3) technology fixes (phone-line call queuing, dispatch software); (4) training needs (repeat training for staff who did not meet standards). Assign owner and completion deadline (target ≤Month 3.8 = 2027-02-01, within 2 weeks of drill debrief) for each action. Close-out checklist confirms all actions are verified complete by Month 3.9 (2027-02-04). Document closure with evidence (training records, system logs, staffing confirmations).

**Responsible Body/Role:** PMO coordinator (action-tracking owner) with incident commander and all governance-body leads who own specific corrective actions.

**Suggested Timeframe:** After-action report completed Month 3.5 (2027-01-23); corrective-action plan finalized Month 3.6 (2027-01-26); actions executed and closed by Month 3.9 (2027-02-04).

**Key Outputs/Deliverables:**

- Corrective-action list with owners, deadlines and completion evidence
- Staffing adjustments (additional hires or schedule changes) documented
- Revised procedures or escalation rules published to all staff
- Technology fixes or system improvements validated
- Repeat training or skill assessments completed and documented
- Closure checklist signed off by each action owner

**Dependencies:**

- Drill after-action report completed and shared with all leads
- Sufficient budget and staffing flexibility to execute corrective actions
- Steering Committee monitoring of closure status

### 34. Conduct the Steering Committee's Month 4 (2027-02-08) scale-gate review and funding-release decision. Incident commander presents comprehensive evidence for the four scale-gate criteria: (1) ≥80% of planned cooling-center hours delivered in the drill; (2) ≥60% contact success from ≥300 outreach attempts; (3) mean transport time <45 min over ≥30 requests (including ≥5 wheelchair users); (4) 100% of after-action corrective actions from the drill closed and verified. Additionally present: status of kit procurement and delivery (target ≥40% by Month 4 = 2027-02-08), handyperson training completion (all 10 trained and on-contract), partner compliance audit (GDPR, call-logging, data protection). If all criteria are met, Committee formally approves the release of the full €1.5M tranche-2 funding. If 1 criterion fails but evidence is incomplete (e.g., insufficient natural heat events by Month 4 = 2027-02-08 to validate gates in real conditions), Committee approves conditional release: €750k (50%) immediately, remainder after a re-test in Month 5 (2027-03-08) using real-world heat data. If 2+ criteria fail, Committee does not release tranche-2; corrective actions and re-test planned for Month 5 (2027-03-08) at the earliest. Document formal vote and decision.

**Responsible Body/Role:** Heat Response Steering Committee (majority vote, quorum 4 of 6 including Chair or Vice-Chair), with incident commander and governance-body leads presenting evidence.

**Suggested Timeframe:** Month 4 (2027-02-08), scheduled at least 1 week in advance; decision documented same day.

**Key Outputs/Deliverables:**

- Scale-gate evidence package (center hours, outreach success rate, transport response times, corrective-action closure, kit procurement status)
- Steering Committee meeting minutes with formal vote on each criterion
- Formal funding-release decision letter or memo (full release, conditional release, or no release)
- Communiqué to all staff and partners confirming gate decision and next steps

**Dependencies:**

- Drill completed and after-action report finalized (Month 3.5 = 2027-01-23)
- All corrective actions closed and verified (Month 3.9 = 2027-02-04)
- Kit procurement on track (≥40% delivered or in-transit by Month 4 = 2027-02-08)
- Handyperson recruitment and training completed

### 35. Following the Month 4 (2027-02-08) scale-gate decision (whether full, conditional or no release), the Steering Committee formally approves and the incident commander confirms the operational readiness of all governance bodies to enter the live operational season (Months 6.8–11.8 = 2027-04-23 to 2027-09-30). Each governance body lead submits a readiness certification covering: (1) staffing (all roles filled, trained, on-call rosters confirmed); (2) systems (phone line, dispatch, cooling centers, partner call-tracking operational and tested); (3) supplies (kits in storage or arriving, handyperson ready to deploy, shelter supplies stocked); (4) protocols (escalation, GDPR, incident reporting, stand-down all documented and drilled); (5) partner commitment (all intermediaries' MOUs signed, staff trained, call targets confirmed). Incident commander and Steering Committee Chair sign off on the overall go-live. A public announcement and pre-season communications campaign (flyers, radio, pharmacy posters, community briefings) launch by Month 6.5 (2027-04-23).

**Responsible Body/Role:** Incident commander and all governance-body leads, with Steering Committee Chair oversight.

**Suggested Timeframe:** Readiness certifications submitted by Month 4.5 (2027-02-23); Steering Committee review and go-live approval by Month 5 (2027-03-08).

**Key Outputs/Deliverables:**

- Readiness certification from each governance body (staffing, systems, supplies, protocols, partner commitment)
- Consolidated operational-readiness checklist
- Steering Committee formal approval and go-live authorization
- Public announcement of program launch (press release, municipal website, social media)
- Pre-season campaign materials (flyers, radio spots, pharmacy posters, community briefings)

**Dependencies:**

- Month 4 (2027-02-08) scale-gate decision made and communicated
- All staffing hired and trained
- All systems tested and operational
- Cooling-center accessibility audit and remediation completed
- Kit procurement and handyperson training on schedule

### 36. From Month 5 onward (2027-03-08), governance bodies transition from setup and gate-preparation mode to regular operational reporting and rhythm. Monthly Steering Committee meetings (standing: first Monday of each month 14 = 2027-12-08:00, Months 5–12 = 2027-03-08 to 2027-10-08) review: (1) financial forecasts and budget burn; (2) staffing and fatigue status; (3) partner engagement and capacity; (4) procurement delivery status; (5) risk register; (6) preparation for summer season (June–September). Operations Team maintains weekly meetings on non-alert days (Mondays 14:00, Months 5–8 = 2027-03-08 to 2027-06-08) and daily standups with SITREP (08:30) and partner briefing (09:30) during any alert periods. Sub-groups (Cooling Centers, Outreach, Transport, Home Kits) establish their own meeting cadences: Cooling Centers weekly (Tuesdays 14:00 during setup, transitioning to ad-hoc during season); Outreach weekly (Wednesdays 14:00, then daily during alert days); Transport weekly (Thursdays 14:00, then daily during alerts); Home Kits weekly (Mondays 10:00 during installation phase = Months 4–7 = 2027-02-08 to 2027-05-17). Data and evaluation group meets monthly (Fridays 14:00).

**Responsible Body/Role:** Incident commander (chair of Operations Team), Steering Committee members, and all governance-body leads.

**Suggested Timeframe:** Governance transition to regular rhythm by Month 5 (2027-03-08); sustained through end of project Month 12 (2027-10-08).

**Key Outputs/Deliverables:**

- Monthly Steering Committee meeting calendar and standing agendas published
- Weekly Operations Team and sub-group meeting schedules published
- Meeting-cadence documentation in the operational playbook
- Monthly financial and risk-management dashboards prepared by PMO for Steering Committee review
- Weekly operations summaries (for non-alert weeks) shared with stakeholders

**Dependencies:**

- All governance bodies established and leads in post
- Operational systems live and stable
- Financial and staffing tracking systems operational

### 37. From Month 8 onward (2027-06-08), the Evaluation Lead, data analyst and university evaluation partner begin drafting the final Heat Response Playbook, cost model, and evaluation report. Playbook chapters include: (1) strategic decisions and rationale (Alert Trigger Ladder, Refuge Network, Intermediary-Held Lists, Mobility Support, Command Structure, Home Kits, Health Integration, Worker Protection, Communications, Language Access, Evaluation); (2) SOPs and checklists (alert declaration, cooling-center operations, transport dispatch, phone-line handling, escalation, de-escalation, incident reporting, stand-down); (3) procurement and staffing templates (job descriptions, supplier specs, contract terms, partner MOUs); (4) lessons learned and adaptations (what worked, what was hard, what to change for Year 2); (5) unit costs and scaling assumptions (€ per person enrolled, per center-hour, per kit, per transport trip, per staff FTE). University partner analyzes operational and outcome data (EMS, ED, mortality proxies) against the pre-registered protocol. Playbook draft shared with peer EU cities for comment by Month 11 (2027-09-08); final version and evaluation report delivered by Month 12 (2027-10-08).

**Responsible Body/Role:** Evaluation Lead (0.5–1 FTE) with Playbook Editor (may be Evaluation Lead or separate role), university evaluation partner, and incident commander/governance leads (content contributors).

**Suggested Timeframe:** Playbook drafting begins Month 8 (2027-06-08); section drafts submitted by Month 10 (2027-08-08); peer-city review Month 11 (2027-09-08); final version Month 12 (2027-10-08).

**Key Outputs/Deliverables:**

- Heat Response Playbook (draft Months 8–10 = 2027-06-08 to 2027-08-08, final Month 12 = 2027-10-08)
- Scaling cost model with unit costs and assumptions
- Data and evaluation report (preliminary by Month 11 = 2027-09-08, final Month 12 = 2027-10-08)
- Year-2 roadmap (expansion priorities, elements to discontinue, estimated budget for Year 2)
- Lessons-learned and adaptation summary

**Dependencies:**

- Operational data collected throughout Months 6–11 (2027-04-08 to 2027-09-08) (center hours, outreach attempts/success, transport times, kit installations)
- Health-system outcome data (EMS, ED, mortality) collected and analyzed
- University evaluation partner data analysis complete
- All governance bodies document their decision-making and challenges for playbook lessons-learned section

### 38. Conduct a final Steering Committee meeting (Month 12 = 2027-10-08) to review and formally approve the Heat Response Playbook, scaling cost model, evaluation report and Year-2 roadmap for public release. Committee considers: (1) Are the lessons learned and adaptations clearly documented? (2) Is the cost model transparent and defensible for other EU cities? (3) Are attribution caveats and limitations honestly stated? (4) Is the Year-2 roadmap realistic and funded? Committee votes to approve for publication. Incident commander prepares a final project close-out report (budget reconciliation, staffing outcomes, partner feedback, next-steps). A final debrief meeting is held with all governance-body leads and key partners to capture verbal feedback and recognize contributions. Public launch event (press conference, municipal briefing, dissemination to peer cities and EU networks) scheduled for Month 12 (2027-10-08) or soon after.

**Responsible Body/Role:** Heat Response Steering Committee (majority vote), with incident commander, Evaluation Lead and playbook editor presenting final deliverables.

**Suggested Timeframe:** Final Steering Committee meeting Month 12 (2027-10-08); public launch by end of Month 12 (2027-10-08) or early Month 13 (2027-11-08).

**Key Outputs/Deliverables:**

- Steering Committee formal approval of Playbook, cost model, evaluation report and Year-2 roadmap (meeting minutes with vote)
- Final project close-out report (budget reconciliation, staffing, partner feedback, lessons learned)
- Public-release press release and communications pack
- Heat Response Playbook published (PDF and possibly online portal)
- Scaling cost model published with replicability guidance for other EU cities
- Evaluation report published with peer-reviewed or audited findings
- Year-2 roadmap and funding proposal (if applicable)
- Final debrief meeting minutes and participant feedback

**Dependencies:**

- All draft deliverables (Playbook, cost model, evaluation report, roadmap) completed and reviewed by Steering Committee by Month 11 (2027-09-08)
- Peer-city feedback incorporated (Month 11 = 2027-09-08)
- University evaluation partner's final report submitted
- Budget reconciliation and staffing outcomes documented

# Decision Escalation Matrix

**Month 4 (2027-02-08) Scale-Gate Failure or Unmeasurable Evidence**
Escalation Level: Heat Response Steering Committee
Approval Process: Majority vote (4 of 6 members including Chair or Vice-Chair). Steering Committee reviews gate-measurement evidence (drill data, real-world heat events, corrective-action closure). If gates are failed, the Committee votes on: (1) no release of €1.5M tranche-2 and mandatory corrective re-test by Month 5 (2027-03-08), or (2) conditional 50% release (€750k) if evidence is incomplete due to cool season, with final decision after Month 5 (2027-03-08) re-test. If gates are passed, full €1.5M is approved for immediate release.
Rationale: The Month 4 (2027-02-08) gate decision gates control €1.5M funding release (43% of total budget) and determines operational scale for the critical May–September heat season. A failed gate triggers a budget crisis (€200–400k cash gap) and potential service reductions mid-summer. The decision affects public safety, partner continuity, and program credibility. Only the Steering Committee has authority to approve or withhold conditional funding and escalate unmet gates to corrective re-planning.
Negative Consequences: Non-release or delayed release of €1.5M by 4–8 weeks would force closure of 25–40% of planned cooling-center hours and transport capacity by August, coinciding with peak summer heat risk. Estimated harm: 500–1,500 fewer high-risk residents reached, 15–25% reduction in outreach contact success, loss of volunteer driver confidence and partner engagement. Reputational damage: audit and funder scrutiny if gates are failed; media coverage if residents are turned away from overcrowded centers during a heat wave.

**Budget Overrun or Contingency-Reserve Drawdown Exceeding €20k**
Escalation Level: Heat Response Steering Committee
Approval Process: Incident commander submits a budget-reforecast report documenting: (1) spending by category to date, (2) variance from budget, (3) root cause, (4) corrective action (reduce scope, reallocate budget, draw contingency). Steering Committee reviews and votes to approve the reforecast and contingency drawdown (if >€20k requested). Large drawdowns (>€50k) require documented justification (e.g., supplier price spike, staff absence surge, emergency remediation) and may trigger supplier or scope review.
Rationale: The total €3.5M budget is hard-capped with limited contingency (€280k = 8%). Overruns threaten both gates and final deliverables. Overruns may stem from procurement delays requiring expedited shipping, staffing gaps forcing extended taxi retainers, or facility remediation cost growth. Steering Committee authority ensures spending decisions are visible, documented and aligned with strategic priorities (gates > playbook > home kits, in case trade-offs are needed).
Negative Consequences: Uncontrolled spending exhausts contingency by Month 6 (2027-04-08), leaving no buffer for summer emergencies (staff illness surge, supplier failure, facility damage). If €280k is drawn and overruns continue, tranche-2 release is at risk. Cumulative overrun of 15% (€525k) creates a funding shortfall of €245k that cannot be covered, forcing either mid-season service cuts or funder request for supplementary funds (likely denied if funder is a municipal council with fixed budgets). Reputational cost: audit finding of budget mismanagement, loss of funder confidence for Year-2 proposal.

**GDPR Compliance Breach or Partner Data-Handling Violation**
Escalation Level: Heat Response Steering Committee
Approval Process: Legal and GDPR Lead (with external GDPR legal counsel) investigates any reported or discovered breach. Assessment includes: data scope affected, number of residents, confidentiality risk, partner culpability. Legal team determines if breach must be reported to the Spanish Data Protection Authority (AEPD) within 48 hours (if >100 residents at high risk or health data exposed). Steering Committee is briefed within 24 hours of discovery. If breach is serious (100+ residents, deliberate misuse, regulator notification required), Committee may authorize: (1) contract suspension of breaching partner, (2) resident notification campaign, (3) enhanced oversight, (4) corrective-action plan with funder notification. Decision is documented and, if required, escalated to municipal legal counsel and city council.
Rationale: The program relies on intermediary-held contact lists and partner compliance with GDPR and data-protection obligations. A breach (e.g., partner leaks resident contact details or health flags to a third party, or unauthorized contact outside the agreed scope) undermines resident trust, violates the legal basis for the program, and exposes the city to regulatory fines and litigation. GDPR compliance is a hard constraint: failure to resolve a breach promptly risks program suspension or funder withdrawal.
Negative Consequences: Serious breach (100+ residents, health data exposed) triggers 48-hour AEPD notification requirement and potential regulatory investigation. Estimated fine under GDPR Article 83: €10k–€50k (minor breach) to €100k–€500k+ (serious breach involving health data). Resident notification and credit-monitoring costs: €5k–€20k. Partner contract termination reduces outreach reach by 10–20% (500–1,000 residents). Loss of public trust and media coverage of 'data leak' damages program credibility and Year-2 funding prospects. Estimated total reputational and financial cost: €100k–€750k.

**Critical Incident at a Cooling Center (Serious Injury, Death, Major Safety Failure)**
Escalation Level: Heat Response Steering Committee (if serious or reputational impact); immediate notification to incident commander and chair within hours
Approval Process: Cooling-Center Operations Lead reports incident to incident commander immediately. Incident commander convenes an emergency review (within 24 hours) with operations lead, legal counsel and occupational health to assess: (1) cause (staffing gap, equipment failure, medical emergency, accessibility failure); (2) liability and insurance coverage; (3) immediate corrective action (site closure, additional staffing, equipment repair); (4) public communication and incident disclosure; (5) regulatory reporting (to occupational safety authority if staff injury, to municipal health authority if resident harm). Steering Committee is notified same day if incident involves death, serious injury, or reputational crisis (media attention likely). Committee may authorize: (a) site temporary closure and remediation, (b) external incident investigation, (c) public statement and transparency, (d) enhanced insurance or legal defense. If fatality occurs and program is blamed, funder and city council are notified immediately and Steering Committee meets within 48 hours to decide continuation.
Rationale: A serious incident (death, heat-stroke hospitalization, fall, assault) at a cooling center creates immediate liability, regulatory exposure and reputational crisis. The center is municipally managed and staffed; the city is liable for duty of care. Rapid escalation ensures legal protection, incident documentation, corrective action and transparent communication. Transparency and swift action reduce legal and reputational risk; cover-up or delay amplifies damage.
Negative Consequences: Serious injury or death at a center followed by delayed or poor response triggers: (1) litigation by resident/family for negligence, seeking €50k–€500k+ damages; (2) media coverage ('municipal heat program fails to protect resident') damaging public trust; (3) occupational safety regulator investigation if staff injured; (4) funder loss of confidence and Year-2 funding denial; (5) city council political pressure to defund or restructure the program; (6) partner and volunteer recruitment collapse due to reputational damage. Estimated cost: €200k–€1M (legal defense, settlement, lost funding, staff replacement).

**Volunteer Driver or Outreach Staff Safety Incident (Assault, Abuse, Safeguarding Concern)**
Escalation Level: Heat Response Steering Committee; immediate escalation to incident commander and occupational health
Approval Process: Transport Lead or Outreach Lead reports incident to incident commander and occupational health within 2 hours. Occupational health conducts immediate welfare check and offers counseling/support. HR coordinator and legal counsel assess: (1) whether police/authorities should be notified (assault, threat); (2) incident documentation and log; (3) staff/volunteer leave entitlements and duty-of-care obligations; (4) insurance coverage; (5) safeguarding and volunteer-management protocol review. If incident indicates systemic safeguarding failure (multiple incidents, inadequate training, poor vetting), incident commander escalates to Steering Committee within 24 hours for governance-level decision on: (a) safeguarding protocol audit and retraining, (b) volunteer recruitment pause and re-vetting, (c) additional supervision and insurance requirements, (d) external safeguarding review if serious or repeated incidents.
Rationale: Volunteers and staff are municipal program representatives and are exposed to vulnerable residents (elderly, isolated, potentially hostile). Assaults, abuse or safeguarding breaches create duty-of-care obligations, legal liability, and staff safety risks. Swift incident response protects staff welfare, fulfills legal obligations and identifies systemic issues (poor training, insufficient vetting, inadequate supervision) before they recur.
Negative Consequences: Unaddressed staff safety incident leads to: (1) volunteer or staff resignation, reducing dispatch and outreach capacity by 5–15%; (2) retained trauma and reduced effectiveness of affected staff; (3) reputation damage affecting future volunteer recruitment; (4) litigation if staff/volunteer claims negligence or inadequate safeguarding; (5) occupational health regulator finding if incident indicates systematic risk. Cumulative impact of 2–3 incidents without remediation could force program pause or external safeguarding takeover. Estimated cost per serious incident: €10k–€50k (legal, counseling, recruitment replacement).

**Procurement or Supply-Chain Failure Threatening Month 2 (2026-12-08) Readiness Gate or Home-Kit Deployment Deadline**
Escalation Level: Heat Response Steering Committee (if delay exceeds 4 weeks or forces budget contingency drawdown >€50k)
Approval Process: Procurement specialist and Home Kit Lead (or Cooling-Center Operations Lead) report supply-chain risk to incident commander within 5 working days of discovery. Incident commander convenes emergency review with PMO coordinator, lead role and legal counsel to assess: (1) root cause (supplier bankruptcy, production delay, shipping disruption, quality issue); (2) impact (which gate is at risk, delay duration, cost of expedite/backup supplier); (3) corrective action options (accelerate delivery, use backup supplier, reduce scope); (4) budget impact (does contingency or scope cut avoidable). If delay exceeds 3 weeks or remediation requires >€50k contingency drawdown, incident commander escalates to Steering Committee within 24 hours with: (a) delay timeline and gate-impact assessment, (b) corrective-action options ranked by cost and speed, (c) recommendation (e.g., pay 15% premium for expedite, or defer non-critical items to Month 5 = 2027-03-08). Committee votes on approval and any scope trade-offs (e.g., reduce home-kit count to prioritize cooling centers).
Rationale: Cooling kits, transport contracts and center fit-out are on the critical path to the Month 2 (2026-12-08) readiness gate and the May–June summer season. Delays >4 weeks push kit installation or transport readiness into June or July, missing the peak early-summer heat risk and failing gates. Escalation ensures visibility of supply-chain risks, timely use of contingency funds for expedited delivery, and if necessary, scope trade-offs approved by leadership rather than ad-hoc cuts.
Negative Consequences: Supply-chain failure causing >6-week delay in kits or transport (e.g., supplier bankruptcy, shipping port disruption) means home interventions cannot be installed before June heat events, reducing estimated mortality reduction by 15–25%. Transport readiness slip forces reliance on taxi-only model (+€150–250k), cutting home-kit budget by €150–250k (500–1,000 fewer kits). Cascading impacts: Month 2 (2026-12-08) readiness gate fails due to incomplete procurement; Month 4 (2027-02-08) scale gate fails due to low home-kit installation numbers; €1.5M tranche-2 is not released on schedule; program enters summer under-resourced. Estimated total cost of 6-week delay: €150–250k contingency drawdown + 15–25% reduced mortality protection + reputational damage (gates failed despite advance planning).

# Monitoring Progress

### 1. Gate-Metric and Operational-KPI Tracking (Month 2 = 2026-12-08 Readiness, Month 4 = 2027-02-08 Scale, Seasonal Performance)
**Monitoring Tools/Platforms:**

  - Gate-Measurement Checklist (Excel/shared spreadsheet)
  - Cooling-Center Hours and Occupancy Log (daily site-by-site tracking)
  - Transport Dispatch Log (request-by-request response-time tracking)
  - Outreach Contact-Attempt and Success-Rate Spreadsheet (by partner, daily)
  - PMO Operations Dashboard (consolidated weekly summary)

**Frequency:** Daily during alert days (Months 6.8-11.8 = 2027-04-23 to 2027-09-30); weekly on non-alert days during setup (Months 1-5 = 2026-11-08 to 2027-03-08); consolidated monthly for steering committee review.

**Responsible Role:** PMO Coordinator and Incident Commander, with daily data collection from Cooling-Center Operations Lead, Transport Lead and Outreach Lead.

**Adaptation Process:** Weekly Operations Team review (Mondays 14:00, non-alert Months 1-5 = 2026-11-08 to 2027-03-08) identifies metric shortfalls (center hours <80%, outreach success <60%, transport time >45 min); incident commander authorizes corrective actions: additional staffing, script revision, route re-optimization, escalation support. Monthly reports to Steering Committee flag trends requiring budget reallocation or scope adjustment. At Month 2 (2026-12-08) and Month 4 (2027-02-08), consolidated gate-evidence package is prepared for formal go/no-go decision.

**Adaptation Trigger:** Month 2 (2026-12-08) Readiness Gate: if any of the 7 readiness criteria unmet, incident commander convenes 24-hour corrective-action meeting and reports to Steering Committee; if criteria cannot be closed by Month 2.5 (2026-12-23), gate is flagged as fail-at-risk. Month 4 (2027-02-08) Scale Gate: if center-hours or outreach-success or transport-time fail the thresholds, no release of tranche-2 €1.5M (triggering €200-400k cash gap); if evidence is insufficient due to cool season, conditional 50% release (€750k) and re-test at Month 5 (2027-03-08). Real-time during season: if transport time rises above 45 min for >1 consecutive alert day, transport lead escalates to incident commander within 2 hours; if persistence >3 days, escalates to Steering Committee as gate-failure risk.

### 2. Critical Success Factor Tracking: Cooling-Refuge Network Reach and Accessibility (Equity and Access)
**Monitoring Tools/Platforms:**

  - Site-Coverage Map and Equity-Reach Analysis (GIS if available, or spreadsheet with neighborhood postcode data)
  - Cooling-Center Occupancy and Demographics Spreadsheet (age, gender, neighborhood, language, disability accommodation)
  - Accessibility Audit Checklist and Remediation-Tracking Log (per site)
  - Equity Metrics Dashboard (% of target 65+ reached, % from top-deprivation neighborhoods, % in fully accessible sites, % with language support)

**Frequency:** Monthly during setup (Months 1-5 = 2026-11-08 to 2027-03-08) to confirm site readiness and accessibility; weekly during season (Months 6.8-11.8 = 2027-04-23 to 2027-09-30) to track occupancy by neighborhood and demographic; final equity-coverage summary at Month 12 (2027-10-08).

**Responsible Role:** Cooling-Center Operations Lead and an Equity Analyst or Data Coordinator (0.5 FTE), reporting to incident commander.

**Adaptation Process:** Monthly Operations Team review compares actual occupancy and demographics against targets (≥70% of enrolled residents within 800 m; ≥50% of places in fully accessible sites; ≥5% of users identified as non-official-language speaker or wheelchair user). If a site shows low utilization (<20% occupancy on alert days) or if a neighborhood is under-represented (≤20% of expected enrollees), Cooling-Center Operations Lead recommends: (1) extended hours or special programming at underused sites, (2) targeted outreach to under-represented neighborhoods, (3) transport-priority deployment to sites serving highest-need areas. Accessibility shortfalls (e.g., wheelchair users turned away) trigger immediate site remediation or closure; inaccessible sites are closed until remediation is complete (≤4 weeks, ≤€10k).

**Adaptation Trigger:** Site occupancy <20% over 2 consecutive alert days → Operations Lead meets with site manager within 24 hours to identify barriers (location, hours, comfort, marketing); adjust hours, transport routing, or outreach targeting within 1 week. Site accessibility failure (wheelchair user cannot access toilet, quiet room unavailable, stairs block entry) → reported by center staff or observed in accessibility spot-check; if not immediately remediable, site is closed to new entrants and referrals diverted to accessible sites within 4 hours. Geographic equity gap (highest-deprivation neighborhoods contribute <30% of enrollees by Month 6 = 2027-04-08) → Outreach Lead and partner-liaison officer launch targeted street-team and partner recruitment in those neighborhoods by Month 6.5 (2027-04-23); if coverage gap persists to Month 7 (2027-05-08), incident commander re-allocates outreach resources or requests additional partner commitments.

### 3. Critical Success Factor Tracking: Outreach Enrollment and Contact Success (60% Gate and Equity Reach)
**Monitoring Tools/Platforms:**

  - Partner Call-Logging Spreadsheet (calls attempted, calls connected, consent obtained, reasons for no-contact, language of contact)
  - Enrollment Registry by Partner and Neighborhood (tracked in intermediary systems; city receives aggregate counts only, GDPR-compliant)
  - Outreach-Success Rate Calculation (success = call connected + information provided or referral accepted; gate = ≥60%)
  - No-Wrong-Door Tracking (phone-line and in-person intake at centers; separate count from partner-based outreach)

**Frequency:** Daily during alert days to track active outreach; weekly during setup (Months 1-5 = 2026-11-08 to 2027-03-08) to validate scripts and partner readiness; real-time dashboard (rolling 7-day average) during season (Months 6.8-11.8 = 2027-04-23 to 2027-09-30) to identify contact-rate shortfalls before they compound.

**Responsible Role:** Outreach and Enrollment Lead and phone-line coordinator, with daily data aggregation from all intermediary partners (housing associations, social services, NGOs, pharmacies).

**Adaptation Process:** Real-time partner feedback loop: if a partner reports call-completion rates <50% on any alert day, Outreach Lead convenes emergency 24-hour review with that partner to diagnose (staff absence, script confusion, technical issue with phone systems, resident unavailability) and implement corrective action (additional staff surge, script simplification, extended calling window). Weekly review (Fridays 14:00, Months 1-5 = 2026-11-08 to 2027-03-08) compares actual script-test results (do residents understand the message and accept referral?) against baseline expectations; if acceptance is <60%, script is revised with partner input and focus-group tested by end of week. During season, if rolling 7-day average contact success falls <60%, Outreach Lead escalates to incident commander within 24 hours with proposed remediation (e.g., additional interpretation support, ambassador pairing with partners, extension of calling hours).

**Adaptation Trigger:** Individual partner monthly success rate <60% (measured as calls connected / attempts) for 2 consecutive weeks → Outreach Lead and partner representative meet within 48 hours; if partner lacks capacity, assess whether call targets should be reduced (triggering lower total enrollment) or supplemented by a backup partner or city-funded surge staff. If >2 partners fail the 60% threshold simultaneously, incident commander escalates to Steering Committee as a gate-failure risk by Day 7 of the alert week. Non-official-language contact rates <5% of total attempts (city-wide, month-on-month) → Language-access coordinator (Outreach Lead with community ambassadors) increases interpreter deployment or ambassador pairing with partners within 1 week; if gap persists to Month 8 (2027-06-08), escalates to incident commander and Steering Committee as equity-goal failure.

### 4. Critical Success Factor Tracking: Transport Capacity and Response Time (45-Minute Gate and Wheelchair-User Access)
**Monitoring Tools/Platforms:**

  - Transport Dispatch Log (request timestamp, caller ID, destination choice, volunteer/taxi assignment, pickup time, actual arrival time, user feedback)
  - Volunteer Driver Availability and Utilization Report (daily count of available drivers, requests served, average pickup time by priority level)
  - Taxi-Operator Performance Report (requests assigned to taxi, response times, vehicle type deployed, accessibility match)
  - Transport Stress-Test Results (pre-season May drill and simulated peak-demand scenarios)

**Frequency:** Real-time logging during alert days; daily summary at end of each alert day; weekly aggregate report on non-alert days during setup (Months 1-5 = 2026-11-08 to 2027-03-08); monthly Steering Committee dashboard during season (Months 6.8-11.8 = 2027-04-23 to 2027-09-30).

**Responsible Role:** Transport Lead / Dispatch Coordinator (1 FTE) and backup dispatcher (1 FTE), with data aggregation by PMO coordinator.

**Adaptation Process:** Daily alert-day debrief (18:00, Cooling-Center Operations Lead, Transport Lead, Outreach Lead, incident commander) reviews transport requests, response times, failed requests and reasons (volunteer unavailable, taxi delayed, resident refused transport). If average response time for any alert day is >45 min, Transport Lead convenes same-day remediation meeting with volunteer representative and taxi operator to identify bottleneck (e.g., volunteer geographic clustering, taxi dispatch lag, mismatched destinations). Corrective actions authorized same-day: re-position volunteers, alert taxi operator of high-demand geography, cascade requests to backup volunteers or additional taxi surge. Weekly review (Thursdays 14:00, Months 1-5 = 2026-11-08 to 2027-03-08) compares volunteer recruitment pipeline against targets (target 40, range 30-50; if <20 by Month 1.5 = 2026-11-23, proportionally increase taxi retainer by €10-30k). Wheelchair-user requests are flagged separately; if any wheelchair user waits >45 min or is assigned a non-wheelchair-accessible vehicle, incident commander is notified within 2 hours and Transport Lead submits same-day corrective-action memo.

**Adaptation Trigger:** Single alert-day average response time >45 min → Transport Lead escalates to incident commander within 4 hours with root-cause summary and corrective action. Sustained average >45 min over 2+ consecutive alert days → incident commander convenes Steering Committee emergency session within 24 hours; gate failure for Month 4 (2027-02-08) is flagged and remediation plan (additional taxi surge, volunteer recruitment acceleration, route optimization, standby expansion) is approved or budget reallocation authorized. Volunteer recruitment <20 by Month 1.5 (2026-11-23) → taxi retainer is scaled up by €10-30k (proportional offset) within 48 hours; if volunteer target remains unmet by Month 2 (2026-12-08), Month 2 (2026-12-08) readiness gate is conditional on taxi-retainer adequacy confirmation. Wheelchair-user wait >45 min or non-accessible vehicle assignment → incident commander is notified within 2 hours; if this occurs >1 time per week during season, Transport Lead meets with taxi operator to enforce wheelchair-accessible vehicle availability; if operator cannot comply, backup taxi provider is activated or volunteer recruitment for accessible vehicles accelerates.

### 5. Major Risk Tracking: Procurement and Supply-Chain Delivery (Cooling Kits and Transport Contracts)
**Monitoring Tools/Platforms:**

  - Procurement Status Dashboard (order-placement dates, supplier lead times, delivery-date forecasts, expedite-cost exposure)
  - Kit-Delivery Tracking Log (units ordered, units received, units in storage, units deployed, inventory aging)
  - Taxi-Retainer Contract Performance Scorecard (standby fee, request volume, response times, vehicle availability, wheelchair-accessible units)

**Frequency:** Weekly during setup (Months 0-3 = 2026-10-08 to 2027-01-08) to confirm supplier timelines and place orders on schedule; bi-weekly during Months 4-7 (2027-02-08 to 2027-05-17) to track kit delivery, acceptance and handoff to handypersons; monthly thereafter.

**Responsible Role:** Procurement Specialist (0.5 FTE) and Home Kit Lead, with backup supplier coordination and expedite-authorization by incident commander.

**Adaptation Process:** Weekly procurement review (Thursdays 10:00, Months 0-3 = 2026-10-08 to 2027-01-08) confirms supplier lead times and confirms first call-off order (30-40% kit volume) is placed by Month 1.2 (2026-11-14); if supplier lead time exceeds 6 weeks, backup suppliers are activated immediately or expedite premium (estimated 10-15% cost increase, €50-100k) is approved by incident commander. Bi-weekly kit-delivery review (Mondays 10:00, Months 4-7 = 2027-02-08 to 2027-05-17) tracks: (1) kits received and passed quality inspection, (2) inventory turnover rate (kits deployed faster than plan indicates under-budgeting or slower indicates lagging installations), (3) handyperson installation pace (target 100% installed by Month 7.3 = 2027-05-17). If 40% of kits are not received by Month 4 (2027-02-08), gap is flagged as Month 4 (2027-02-08) gate-evidence risk; Home Kit Lead requests expedite at supplier or activates backup within 24 hours. Taxi-retainer scorecard (monthly, Mondays 14:00 Transport Lead review) tracks whether operator meets response-time commitment (<20 min), vehicle availability (≥10 vehicles ≥80% of alert days), wheelchair-accessible units (≥3, always available); if operator is underperforming on 2+ metrics 2 consecutive months, contract amendment or termination is escalated to incident commander.

**Adaptation Trigger:** Supplier delay of >3 weeks detected (e.g., unit does not ship by forecast date) → Procurement Specialist contacts supplier for expedite commit within 24 hours; if manufacturer cannot accelerate, backup supplier is contacted same day for alternative sourcing. Approval for expedite cost ≤€50k is granted by incident commander; cost >€50k requires Steering Committee approval. Kit delivery 2+ weeks late (would miss planned installation before June 1 = Month 6.8 = 2027-05-02 heat events) → Home Kit Lead escalates to incident commander with cost/timeline trade-offs (pay 15% premium for air-freight, or defer installations to July, or reduce kit count from 2,000 to 1,500). Decision is made within 48 hours and escalated to Steering Committee if contingency drawdown >€20k or scope reduction is needed. Taxi-operator performance failure (response time >25 min average, vehicle unavailability >2 alert days per week) detected in monthly scorecard → Transport Lead meets with operator within 48 hours to issue corrective-action notice (cure within 2 weeks or contract amendment/termination considered); if operator cannot cure, incident commander activates backup taxi provider or redirect requests to volunteer-only model if volunteer capacity permits.

### 6. Major Risk Tracking: GDPR Compliance and Partner Data-Protection (Legal Constraint and Operational Continuity)
**Monitoring Tools/Platforms:**

  - Data-Processing Agreement (DPA) Sign-Off Tracker (status with each of 4+ partners, sign-off deadline Month 1.5 = 2026-11-23)
  - Partner GDPR Compliance Audit Checklist (consent-record spot-check, staff-training attendance, data-handling practices, incident reporting)
  - Breach-Incident Log (any reported or discovered data-handling violation; contact with data-protection authority if required)

**Frequency:** Monthly during setup (Months 0-2 = 2026-10-08 to 2026-12-08) to track DPA negotiation and sign-off; quarterly spot-check audit of partner compliance (Month 3 = 2027-01-08, Month 6 = 2027-04-08, Month 9 = 2027-07-08); real-time breach-incident log during entire project.

**Responsible Role:** Legal and GDPR Lead (0.5-1 FTE, may be municipal legal department or external GDPR counsel), with partner-liaison officer for audit coordination.

**Adaptation Process:** Monthly DPA sign-off check (Thursdays 10:00, Months 0-2 = 2026-10-08 to 2026-12-08) monitors each partner's review and approval of the template DPA; if a partner flags GDPR concerns (e.g., questions the lawful basis for contact), legal lead convenes immediate clarification call with GDPR counsel; legal response is provided within 48 hours and incorporated into revised DPA. Quarterly partner-compliance audit (Months 3, 6, 9 = 2027-01-08, 2027-04-08, 2027-07-08) spot-checks (per partner): 10-20 resident-contact consent records to verify explicit consent is documented; staff-training attendance logs to confirm all personnel have received GDPR and confidentiality briefing; data-handling practice observations (e.g., phone calls are logged correctly, personal data is not shared with unauthorized recipients); any-incident disclosure (e.g., 'we misdirected a call to a resident's adult child instead of the resident'). Audit findings are summarized in a report issued to the partner within 5 days, with corrective-action timeline (target: cure within 10 days). Real-time breach log: any partner or staff member can report a suspected data breach via a confidential hotline; legal lead investigates within 24 hours, assesses whether breach meets AEPD notification threshold (>100 residents at high risk, or health data exposed), and decides within 48 hours whether to notify the data-protection authority (mandatory within 48 hours if threshold met).

**Adaptation Trigger:** Partner DPA not signed by Month 1.5 (2026-11-23) deadline → legal lead meets with partner within 48 hours to identify blocking issue and issue a revised DPA with clarifications or remove partner from program if they cannot agree with lawful basis. >25% of partner staff audited are unable to articulate GDPR confidentiality rules (fail 'quiz' or cannot cite their confidentiality agreement) → partner is issued corrective-action notice requiring re-training within 2 weeks; legal lead may audit again post-re-training; if re-audit fails, partner is placed on enhanced oversight (weekly instead of quarterly compliance checks). Breach involving ≥10 residents (e.g., partner confirms it contacted 10 residents who had withdrawn consent) → legal lead and GDPR counsel assess severity and authority-notification requirement within 24 hours; if >100 residents potentially affected, AEPD notification is issued within 48 hours and incident commander notifies Steering Committee and funder immediately; corrective action (enhanced vetting, contract amendment, partner suspension) is authorized within 5 days. Serious breach involving health data (e.g., partner leaks resident's cardiac-disease flag to unauthorized third party) → immediate partner contract suspension pending investigation; legal lead escalates to incident commander and Steering Committee within 24 hours; funder is notified; AEPD notification issued within 48 hours; estimated GDPR fine exposure €10k-500k+ depending on negligence; program operational continuity assessed (can other partners absorb outreach load if breaching partner is terminated?).

### 7. Major Risk Tracking: Staffing Availability and Fatigue During Multi-Day Heat Waves (Operational Continuity and Service Degradation)
**Monitoring Tools/Platforms:**

  - Staffing Roster and Absence Log (by role: cooling-center managers, support staff, dispatchers, phone operators, handypersons, outreach teams; daily headcount and sickness/leave record during alert days)
  - Fatigue-Incident Report (any safety incident, staff complaint, or performance issue potentially related to overwork or fatigue)
  - Service-Degradation Tracker (any reduction in center hours, transport dispatch delays, phone-line wait times, escalation failures correlated with staffing gaps)

**Frequency:** Daily during alert days to confirm available staff and escalate absences immediately; weekly review (Mondays 14:00) during non-alert periods to forecast staffing risk for next alert period; monthly fatigue-management audit (1st Friday of each month, Months 3-12 = 2027-01-08 to 2027-10-08).

**Responsible Role:** HR Coordinator (0.5 FTE, Months 0-4 = 2026-10-08 to 2027-02-08) and then PMO Coordinator (0.5 FTE, Months 5-12 = 2027-03-08 to 2027-10-08), with incident commander escalation authority.

**Adaptation Process:** Daily absence check: on each forecast alert day (by 06:30), all operational leads (Cooling-Center Operations, Transport, Outreach) confirm available staff numbers to incident commander and PMO coordinator; if any role is <80% staffed, incident commander convenes immediate 30-minute conference call to authorize: (1) cancellation or consolidation of lower-priority centers, (2) mutual-aid across departments (e.g., PMO staff back up phone line), (3) call-back of off-duty staff or authorization of overtime premium pay, (4) early stand-down criteria if alert is low-risk. Weekly forecast review (Mondays 14:00) compares staffing roster against planned alert-day scenarios and identifies upcoming gaps (e.g., 'July 15-17 alert forecast but 3 center managers on leave'); if gap cannot be filled with internal cross-training or scheduled overtime, incident commander approves emergency hire or temporary staffing agency contract within 48 hours. Monthly fatigue audit (Fridays 14:00): HR coordinator reviews incident logs, staff-sick-leave patterns, and performs anonymous staff surveys (5-question pulse check on workload, safety concerns, intent-to-stay); if fatigue-related absences are >10% in a given week or multiple staff report safety concerns, HR coordinator convenes immediate fatigue-management meeting with affected department lead and proposes: (a) shift-limit enforcement (no staff works >4 consecutive alert days), (b) peer-support or counseling access, (c) temporary reduction in service scope (e.g., close 1 lower-utilization center) to reduce demand, (d) staffing surge authorization.

**Adaptation Trigger:** Any alert-day staffing level <80% for a critical role (cooling-center manager, dispatcher, phone-line operator) → incident commander is notified by 06:00 on alert day; within 2 hours, contingency staffing is deployed (cross-training, mutual aid, emergency hire) and if not achievable, service reduction is announced to the public and partners (e.g., 'Due to staffing constraints, 2 of 10 cooling centers will close today; transport may experience 60+ minute delays'). Fatigue-related absence rate >15% in a given week (e.g., 3 of 18 cooling-center FTE out sick during a 3-day alert) → incident commander escalates to Steering Committee within 24 hours with assessment of service-degradation risk; if degradation >25% (fewer center-hours, longer transport times), Steering Committee may authorize temporary service reduction, additional staffing budget or alert-scope narrowing until staffing recovers. Staff-injury incident related to fatigue (e.g., transport dispatcher collision while driving during 6th consecutive alert day) or safeguarding breach due to fatigue (e.g., outreach worker mishandles heat-illness escalation) → immediate escalation to legal counsel, occupational health and Steering Committee; post-incident review and remedial training/rest is mandatory before staff returns to duty; incident commander re-evaluates fatigue-management protocols and may enforce stricter shift limits or surge-staffing thresholds.

# Governance Extra

## Governance Validation Checks

1. **Completeness Confirmation:** All core requested components are generated across five phases: Phase 1 audit procedures document corruption and misallocation risks; Phase 2 internal bodies establish 6 primary governance structures (Steering Committee, Operations Team, Cooling Centers, Outreach, Transport, Home Kits, Legal/GDPR, Evaluation); Phase 3 implementation plan sequences 47 detailed setup and operational steps (Months 0–12 = 2026-10-08 to 2027-10-08); Phase 4 decision-escalation matrix covers 5 major issue types with approval authority (gates, budget, GDPR, critical incidents, procurement); Phase 5 monitoring plan specifies tracking frequency, tools, and adaptation triggers for 7 critical success factors (gate metrics, equity reach, outreach success, transport time, procurement, GDPR compliance, staffing fatigue). Deliverables (playbook, cost model, evaluation report, Year-2 roadmap) are assigned by Month 12 (2027-10-08). Framework is comprehensive.
2. **Internal Consistency Check:** Logical alignment between stages is largely sound. Implementation plan sequences governance-body establishment and role recruitment appropriately (Months 0–2 = 2026-10-08 to 2026-12-08 setup, Month 3 = 2027-01-08 full-system drill, Month 4 = 2027-02-08 gate decision, Month 5+ sustained operations). Decision-escalation matrix correctly assigns budget/gate/GDPR escalations to Steering Committee with incident commander as escalation initiator; Operations Team has clear delegated authority for <€5k spend and operational decisions. Monitoring plan links gate-metric tracking to Operations Team weekly reviews and Steering Committee monthly dashboards, creating feedback loops. However, one consistency gap exists: the ultimate Project Sponsor's role and veto authority over Steering Committee decisions is not explicitly defined. If mayor is Chair but holds other portfolio responsibilities, who decides if mayoral-office capacity for incident command becomes unavailable mid-season? Delegation letter (Phase 3, Step 6) addresses backup authority only for alert declaration, not for strategic Steering Committee decisions (budget reallocation, gate interpretation, year-2 planning).
3. **Process Depth and Clarity Gaps – Volunteer Safeguarding and Duty-of-Care Boundaries:** Transport and Outreach sections mandate teams ≥2 (never solo) and reference 'safeguarding checks' and 'incident reporting,' but the actual duty-of-care protocols for encounters with heat-distressed residents are underdeveloped. Transport phase3 specifies vetting (background check, insurance, safeguarding screening) and Phase 5 includes fatigue-incident tracking, yet specific guidance on when staff should call EMS vs. provide water/shade, consent models for acute distress (e.g., disoriented elderly resident unwilling to go to center), and de-escalation scripts are missing. Street-contact pathway (risk register item) acknowledges 'consent and enforcement ambiguities' but governance bodies do not formally own protocols for contact with unhoused people; Street Contact Pathway group is listed in assumptions but not in Phase 2 internal bodies, creating a coordination gap if field incidents occur. Mitigation: Phase 3 should add a detailed step (Month 1.5 or 2 = 2026-11-23, 2026-12-08) for co-designing heat-illness escalation checklists with a municipal nurse adviser or occupational health partner, then validate in drills (Phase 5, monitoring).
4. **Conflict-of-Interest Management and Independent Oversight – Limited Detail:** Phase 1 audit mentions nepotism, kickbacks, and sole-source purchasing risks but does not specify how the Steering Committee or external evaluation partner (described as advisory, non-voting member) will oversee procurement integrity. No rotation of procurement authority, no competitive bid review by an independent panel, no post-award audit oversight are documented. External evaluation partner has full editorial autonomy over evaluation report (Phase 4, decision-escalation), which is good for independence, but no formal conflict-of-interest disclosure or independence certification from the university partner is specified. If the university is in Castellón or Valencia and has existing municipal relationships, potential bias is unaddressed. Mitigation: Phase 3 should add a month-0 step requiring: (1) procurement governance policy (lowest-price, best-value, or other criteria; bid review thresholds); (2) university partner independence declaration; (3) post-award audit schedule (quarterly, external auditor).
5. **Escalation Path Endpoints and Authority Ambiguity:** Several escalation paths terminate at vague endpoints. Phase 4 specifies that operational escalations reach 'incident commander' or 'Steering Committee,' but many decisions (e.g., GDPR policy change, contract termination of a major partner, major scope reduction) could exceed incident commander authority and Steering Committee voting authority. The phrase 'if still deadlocked, legal counsel issues binding opinion' (Phase 2, Steering Committee rationale) creates a de facto fourth authority (legal counsel) whose mandate and scope are not written. If legal counsel and the Steering Committee disagree on whether a gate failure is remediable or whether tranche-2 should be released on contingent terms, who breaks the tie? Phase 4 specifies 'city council' as an escalation destination for policy changes, but no decision-escalation matrix entry addresses city-council involvement in gate decisions or major budget reforecasts. Mitigation: Phase 3 should explicitly define: (1) which decisions require city-council notification vs. approval (gate release likely requires approval; staffing adjustment likely requires notice only); (2) define incident commander's upper spending and scope-change authority (current: <€5k); (3) clarify legal counsel's advisory vs. binding role; (4) establish a three-way tie-break rule (incident commander + Steering Committee Chair + legal counsel unanimous or defer to funder).
6. **Processes for Thresholds, Triggers and Contingencies – Underspecified in Places:** Alert-trigger thresholds (Level 1, 2, 3 by temperature and consecutive-day counts) are specified in Phase 3, Step 6, but stand-down criteria ('thresholds no longer met + 48 hours normal temperature') lack precision: does 'normal' mean <30°C, <25°C, <20°C? Historical baselines are not defined until Month 1 (2026-11-08) baseline audit (Phase 5), so the 48-hour stand-down rule cannot be operationalized until summer. Adaptation triggers in Phase 5 specify numeric thresholds for escalation (e.g., center occupancy <20% → review within 24 hours; contact-success rate <60% for 2 weeks → escalate) but do not define the decision rule for whether to modify the trigger itself after Month 7 (2027-05-08) if evidence accumulates that a threshold is wrong. Will thresholds be re-calibrated post-season for Year 2? Who owns that decision? Transport-time gate specifies <45 minutes average but internal priority target 30 minutes for mobility-limited; if average is 42 minutes but 70% of mobility-limited users wait >30 minutes, does the gate pass or fail? Mitigation: Phase 1 (audit procedures) should add a quarterly 'threshold validation review' (Months 2, 5, 8, 11 = 2026-12-08, 2027-03-08, 2027-06-08, 2027-09-08) where Operations Team compares gate thresholds against real data and recommends adjustments; Steering Committee approves threshold changes with documented rationale.

## Tough Questions

1.  **What is the current probability-weighted forecast for June–September 2027 heat-event frequency, multi-day-wave frequency, and night-temperature extremes in Castellón de la Plana, and how does this compare to the threshold assumptions (Level 2: high ≥35°C and low ≥22°C for ≥2 days; Level 3 for ≥3 days)? Will June–July likely produce sufficient real-world heat events to validate the Month 4 (2027-02-08) gates fairly, or should the contingency-funding rule for 50% conditional release be pre-approved now to reduce gate-decision risk in February?
2. **Show documented evidence that the intermediary-held list model (housing associations, social services, NGOs, pharmacies making calls on behalf of the city) will achieve ≥60% contact success with ≥300 enrolled high-risk residents during the full-system drill (Month 3.2 = 2027-01-14). What are the partner's historical call-completion rates for similar populations, and what de-escalation or follow-up protocols will be used if a partner's contact rate falls below 50%?**
3. **Produce a detailed volunteer-recruitment pipeline forecast: as of today (Month 0 = 2026-10-08), how many confirmed volunteer-driver prospects exist in the recruitment target (retirees, charity staff, faith-group members)? What are the monthly recruitment and vetting-completion rates from comparable municipal volunteer programs in Spain or EU cities? If recruitment reaches only 20–25 volunteers by Month 2 (2026-12-08) instead of the target 40, how will the taxi-retainer contract (currently capped €80k) be scaled to fill the gap, and does this fit in the €3.5M budget without cutting home kits?
4. **Verify baseline heat-related EMS and ED-visit counts: provide 3-year historical data (2024–2026) from Castellón de la Plana EMS and hospitals on calls/visits coded as heat-related, with data-quality audit (% complete, coding consistency, seasonal patterns). If such data does not exist, how will the city establish a defensible baseline by Month 1 (2026-11-08) for the evaluation protocol, and what are the assumptions about baseline uncertainty?
5. **Clarify the ultimate project sponsor's role and veto authority: if the mayor's office is the incident commander's seat and the mayor holds other portfolio responsibilities, who ensures continuity and strategic oversight if the mayor is unavailable (illness, leave, election transition) for >2 weeks during the critical Months 4–9 (2027-02-08 to 2027-07-08) period? Is the Steering Committee Vice-Chair (head of public health) authorized to make gate-release decisions unilaterally, or does Steering Committee require the mayor's attendance?
6. **Produce an operational plan for the Months 5–6 (2027-03-08 to 2027-04-08) contingency-funding scenario in which the Month 4 (2027-02-08) scale gate is not fully passed due to insufficient June heat events. If only 50% of €1.5M (€750k) is released contingently, which services are deferred or cut (e.g., are home kits paused, are backup volunteers stood down, are outreach targets reduced)? What is the staffing plan during May–June if the contingency release occurs, and are there specific escalation triggers to suspend or stand down services?
7. **Document the street-contact protocol for unhoused residents during alert days: who formally owns the outreach to this group (NGO partner or municipal team), what is the explicit duty-of-care boundary when staff encounter someone in acute heat distress or with mental-health crisis, at what point is emergency medical services (EMS) called vs. water/shade/transport offered, and what are the safeguarding and consent rules when a person cannot provide informed consent? Provide draft scripts and incident-escalation checklist for the drill (Month 3.2 = 2027-01-14).

## Summary

This 12-month municipal heatwave mortality-reduction program in Castellón de la Plana, Spain (€3.5M, 43 FTE peak) uses a tiered-alert governance model with mayoral-level incident command, intermediary-held outreach lists (housing associations, social services, NGOs, pharmacies), 10 neighborhood cooling refuges, volunteer+taxi transport, and 2,000 home-kit installations. The framework balances equity reach (targeting 65+, isolated, poorly housed, migrants) with GDPR constraints and operational speed. Two hard gates (Month 2 = 2026-12-08 readiness: centers/transport/phone/training in place; Month 4 = 2027-02-08 scale: ≥80% center hours, ≥60% outreach contact, <45 min transport time) condition €1.5M tranche-2 release. Governance consists of a strategic Steering Committee (mayor, health, civil protection, communications, finance, external evaluation partner), an Operations Team (incident commander, deputies, communications), and six operational sub-bodies (cooling centers, outreach/enrollment, transport, home kits, legal/GDPR, evaluation/playbook). Key strengths: clear incident-command authority, intermediary model preserves privacy, drill-based gate evidence allows measurement even during cool seasons, equity tracking by neighborhood and demographic. Key gaps: insufficient detail on volunteer safeguarding and street-contact duty-of-care boundaries; escalation endpoints sometimes vague ("Senior Management"); limited contingency for staffing surge during extreme events; adaptation thresholds for standby reductions post-alert are undefined; role clarity for the ultimate Project Sponsor is not explicit within the hierarchies.