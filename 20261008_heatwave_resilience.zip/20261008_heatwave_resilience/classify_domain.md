**Primary domain:** Heat Health Action Planning

**Secondary domains:** Emergency Management, Data Protection Law, Public Health Outreach

**Rationale:** Heat Health Action Planning is the only outcome-role candidate and owns the main success criterion: reducing heat-related deaths and illness through alert-triggered municipal response. Public Health Outreach, Emergency Management and the others are subordinate methods or constraints.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Heat Health Action Planning | 5 | 5 | outcome | Core success criterion is reducing heat-related mortality and illness through alert-triggered municipal response. |
| Public Health Outreach | 5 | 5 | method | Phone-tree, door-knock and enrollment of high-risk residents is the core delivery mechanism. |
| Emergency Management | 4 | 4 | method | Incident-command governance, alert levels, drills, surge planning and cooling-center operations rely on emergency management. |
| Data Protection Law | 4 | 4 | constraint | GDPR limits identification, registries, and health-data sharing for outreach to high-risk residents. |
| Public Procurement | 4 | 4 | method | Contracting cooling centers, transport and home-intervention kits within municipal rules and gate deadlines. |
| Urban Climate Adaptation | 4 | 4 | method | Heat-resilience measures like shading and cooling refuges for hot-night events in cities. |
| Epidemiological Surveillance | 4 | 4 | method | Baselines, excess mortality estimates and aggregate health signals for evaluation and gating. |
| Occupational Health | 3 | 4 | constraint | Outdoor municipal workers need heat-stress schedules, breaks, water and employer guidance. |
| Social Work | 4 | 3 | stakeholder | Social services lists, door-knock outreach and support for isolated, unhoused and migrant residents. |