## Primary Decisions
The vital few decisions that have the most impact.


The Critical levers (Alert Trigger Ladder, Cooling Refuge Network Shape, Consent-Light Identification Routes, Mobility Support Delivery) cover the core trade-offs: sensitivity versus budget, access versus staffing, coverage versus GDPR exposure, and cost versus the 45-minute transport target. High levers cover governance, procurement speed, home kits and health integration. Missing dimensions: explicit staffing and volunteer-safety capacity, and surge and extreme-event contingency.

### Decision 1: Alert Trigger Ladder
**Lever ID:** `051de1aa-88d5-466e-ae28-8ab0bc9001fd`

**The Core Decision:** Defines the tiered heat-alert ladder (forecast daytime highs and night-time lows, consecutive hot nights) that converts a forecast into funded, pre-agreed actions. Success means few missed dangerous events, a controlled false-alarm rate, and clear spending authority per tier. Thresholds should be recorded as provisional (proposed) and reviewed after the first season, with the false-alarm and missed-event rate tracked as KPIs.

**Why It Matters:** The definition of each alert level decides when money, staff and volunteers are mobilised. Triggers set too low cause alert fatigue and burn the center-hours budget on marginal days. Triggers set too high miss the hot-night events that drive mortality among older residents. The ladder also decides who can authorise spending, which ties it to the governance structure.

**Strategic Choices:**

1. Adopt fixed forecast thresholds for daytime highs and night-time lows across three tiers, taking the national meteorological service forecast as the sole input and avoiding local calibration work.
2. Calibrate city-specific thresholds from local historical temperature and mortality records, with consecutive hot nights weighted more heavily than daytime peaks, and review them after the first season.
3. Combine the national warning with a low-cost advisory tier that triggers only phone check-ins and pre-positioned supplies, so full center activation is reserved for the upper tiers.

**Trade-Off / Risk:** Local calibration improves accuracy, but a small city may have too few historical heat events to calibrate against, so a sophisticated threshold can still end up as a rounded guess.

**Strategic Connections:**

**Synergy:** Feeds Command Seat Allocation by giving the alert declarer unambiguous criteria, and drives Cooling Refuge Network Shape and Mobility Support Delivery, since tiered activation lets overnight hours and standby transport be scaled only when needed.

**Conflict:** Tight, sensitive triggers strain the center-hours budget and Procurement Speed Route stock, while high triggers risk missing hot nights. Local calibration also competes with Attribution and Comparison Design for scarce analyst time and limited historical data.

**Justification:** *Critical*, Critical hub: it converts forecasts into funded actions and sets spending authority per tier. It drives refuge hours, transport standby, street rounds and procurement stock. It controls the core tension between alert fatigue and budget burn versus missed hot-night events.

### Decision 2: Cooling Refuge Network Shape
**Lever ID:** `3f84fb80-bffd-45ce-baa6-960671698b0d`

**The Core Decision:** Sets the footprint, hours and type of cooling spaces: small neighborhood refuges, large anchor sites, or a hybrid including sheltered housing common rooms and pharmacies. Key measures are the share of high-risk residents within a set walking distance (to be defined), utilization, hours delivered against the 80% Month 4 (2027-02-08) gate, and whether overnight cooling exists. Incident ownership and accessibility checks must be assigned per site.

**Why It Matters:** The shape of the network determines how many frail residents can actually reach a cool space and for how long. Many small neighborhood sites shorten walking distances but multiply staffing, security and accessibility checks. Few large sites are easier to run but depend heavily on transport. The choice also determines whether overnight cooling is offered, which matters most for hot-night risk.

**Strategic Choices:**

1. Contract many small neighborhood refuges in libraries, parish halls and community centers, accepting higher supervision costs per hour to keep most vulnerable residents within walking distance.
2. Contract a few large anchor sites such as sports halls and malls with extended and overnight hours, concentrating staff, medical cover and security while relying on the transport contract for access.
3. Build a hybrid network that adds cool common rooms in existing sheltered housing and social-housing blocks and pharmacy waiting areas as informal refuges, using spaces already air-conditioned and trusted by residents.

**Trade-Off / Risk:** Informal refuges in housing blocks and pharmacies cost little, but they sit outside the formal staffing, accessibility and liability framework, so quality varies and someone must still own incidents occurring there.

**Strategic Connections:**

**Synergy:** Works with Mobility Support Delivery, since shuttle loops and taxi retainers can be sized to the chosen site pattern, and with Street Contact Pathway, where outreach staff can enroll and refer people at sites.

**Conflict:** Many small sites multiply staffing and security needs, straining the budget and the Command Seat Allocation span of control. Few large sites raise dependence on Mobility Support Delivery and the 45-minute transport target.

**Justification:** *Critical*, Critical because the network footprint, hours and overnight offer determine who can physically reach cooling. It sets staffing, security and budget load, drives transport demand, and is directly tied to the Month 4 (2027-02-08) gate of 80% planned hours delivered.

### Decision 3: Consent-Light Identification Routes
**Lever ID:** `08574780-bfb4-4c86-96af-ef1a149387f8`

**The Core Decision:** Determines how high-risk residents are found without the city holding health records: opt-in registry, partner-held lists contacted by intermediaries, or building-level canvassing with local sentinels. Success is measured by coverage of the target groups, outreach contact rate (60% gate for enrolled residents), data-protection impact assessment completion, and reach among isolated residents. Legal basis and retention must be documented per route.

**Why It Matters:** The city cannot hold health records, so the way high-risk people are identified controls both coverage and GDPR exposure. Opt-in registries are the cleanest legally but tend to miss the most isolated residents. Partner-held lists reach more people but raise questions about the legal basis for contact. Geographic approaches avoid personal lists but cost more outreach time per person found.

**Strategic Choices:**

1. Build an opt-in heat registry enrolled through GPs, pharmacies and centers, with explicit consent and a short retention period, accepting that the most isolated residents are underrepresented.
2. Use intermediary-held lists, where housing associations, social services and NGOs make the calls on the city's behalf, so personal data never moves to the city and only aggregate contact results are reported.
3. Canvass by building rather than by person, with door-knock teams covering all top-floor and poorly insulated units in selected blocks, and recruit caretakers, postal workers and shop owners as trained neighborhood sentinels.

**Trade-Off / Risk:** Building-level canvassing avoids list-based GDPR risk and finds hidden residents, but it consumes staff hours on households that are not at risk and may feel intrusive without strong local trust.

**Strategic Connections:**

**Synergy:** Supplies the contact base for Street Contact Pathway and the household candidates for Home Kit Targeting and Fitting. Pairing with Language Access Architecture ensures enrolled residents are reached in a language they understand.

**Conflict:** Registry-based consent limits reach, in tension with the equity goals tracked in Attribution and Comparison Design. Building canvassing consumes outreach hours that compete with Street Contact Pathway capacity and the Home Kit Targeting and Fitting budget.

**Justification:** *Critical*, Critical because it governs the coverage-versus-GDPR trade-off and supplies the contact base for outreach and home kits. It decides whether isolated residents are found at all, and drives the 60% contact-success gate and equity outcomes.

### Decision 4: Mobility Support Delivery
**Lever ID:** `3ec18596-3a00-4b69-8a84-895b6ce77872`

**The Core Decision:** Chooses how mobility-limited residents reach cooling: contracted taxis and accessible vehicles, vetted volunteer drivers, or scheduled shuttle loops and mobile cooling. It decides whether the under-45-minute average time-to-transport gate can be met, including for wheelchair users. Key measures are requests served, wait times, cost per trip, safeguarding incidents, and the share of requests that could not be fulfilled.

**Why It Matters:** The 45-minute transport target depends on who provides rides and when they are called. Contracted taxis are fast and reliable but expensive per trip and often unsuitable for wheelchair users. Volunteers lower the cost but add safeguarding and insurance duties. Moving cooling to people can reduce the number of trips needed but narrows the services on offer.

**Strategic Choices:**

1. Sign an on-call contract with taxi and accessible-transport operators with guaranteed alert-day capacity, paying a standby retainer to secure response times and wheelchair-capable vehicles.
2. Recruit and train vetted volunteer drivers coordinated by a dispatcher, covering insurance and safeguarding checks, and keep taxi contracts only as a backup for failures and peak demand.
3. Schedule fixed shuttle loops between housing blocks and refuges on alert days and add mobile cooling vehicles for blocks with many housebound residents, reducing individual on-demand trips.

**Trade-Off / Risk:** Fixed loops are predictable and cheap per rider but serve only residents who can board and wait, so the least mobile residents, who most need help, may still depend on costly door-to-door rides.

**Strategic Connections:**

**Synergy:** Amplifies Cooling Refuge Network Shape by extending the effective reach of fewer, larger sites, and uses Alert Trigger Ladder tiers to time standby retainers and dispatch readiness.

**Conflict:** Standby retainers and wheelchair-capable vehicles take budget from Home Kit Targeting and Fitting. Volunteer models add safeguarding burdens that compete with Procurement Speed Route timelines before the Month 2 (2026-12-08) readiness gate.

**Justification:** *Critical*, Critical because the under-45-minute transport gate depends on it, and it determines whether larger refuge sites are usable by frail and wheelchair-using residents. It competes for budget with home kits and links to triggers, refuges and street teams.

### Decision 5: Command Seat Allocation
**Lever ID:** `800f65e1-6777-4d46-b2be-6fac870126fd`

**The Core Decision:** Assigns who declares alerts and who commands operations, communications and partner coordination, with written delegations and a clear accountability line. Success is measured by time from forecast trigger to declaration, absence of conflicting orders across departments, handover coverage during multi-day events, and clear public accountability if a response fails.

**Why It Matters:** Deciding which municipal office holds the incident commander role sets how quickly an alert is declared and how clearly operations, communications and partner coordination are separated. A seat close to the mayor speeds budget and cross-department decisions, while a seat in public health keeps clinical judgement central. The choice shapes who is accountable when a response fails in front of the press.

**Strategic Choices:**

1. Place the incident commander in the mayor's office with a deputy from public health, so cross-department orders carry political weight and procurement approvals move quickly.
2. Assign command to the municipal public health department, with civil protection supplying the operations section, so clinical judgement drives alert declarations and escalation rules.
3. Create a standing heat desk staffed by a rotating duty officer roster across departments, with a written delegation letter so any officer can declare an alert without waiting for a superior.

**Trade-Off / Risk:** Political-level command speeds decisions but can politicise alert declarations, while a health-led seat is credible but may lack authority over libraries, transport and public works; a rotating roster risks diffuse accountability when fatigue sets in.

**Strategic Connections:**

**Synergy:** Gives Alert Trigger Ladder a clear declaring authority so thresholds convert into action quickly. It also speeds Procurement Speed Route approvals when the commander can direct cross-department purchasing.

**Conflict:** A political seat risks politicising alerts, which clashes with the evidence-based thresholds in Alert Trigger Ladder. A rotating heat desk may blur accountability for Mobility Support Delivery and field operations during fatigue-heavy multi-day events.

**Justification:** *High*, Governs accountability and speed of alert declaration and cross-department action. It links to triggers and procurement approvals, and the politicised-versus-clinical authority trade-off matters. It is less of a budget hub than the operational delivery levers, so High rather than Critical.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Home Kit Targeting and Fitting
**Lever ID:** `983eaf4d-34f2-4e0c-82e9-f438cc3447f2`

**The Core Decision:** Governs which homes receive shading, reflective blinds, fans, thermometers and hygrometers, and how they are installed without construction. A scoring rubric, landlord bulk deals, or a seasonal lending scheme each trade precision against cost and speed. Measures include installations completed, share of top-floor and social-housing priority units covered, fan safety checks, and resident-reported use. Consent and return logistics must be set up front.

**Why It Matters:** The home package has to reach the riskiest dwellings with a limited budget and no construction work. A rubric-based household selection concentrates spending but needs eligibility checks and consent. Bulk installation through landlords reaches more homes at lower unit cost but depends on landlord cooperation. Lending kits instead of giving them permanently stretches stock across seasons but needs storage and return logistics.

**Strategic Choices:**

1. Score households with a rubric using top-floor location, building age, age and living situation, then give the highest-scoring homes a full kit with handyperson installation and a safety check of fans.
2. Agree bulk installations with social-housing landlords, fitting exterior shading and reflective blinds to whole blocks at once, trading household-level targeting for lower unit cost and faster coverage.
3. Run a seasonal kit-lending scheme where shading, fans and thermometers are installed in May and collected in September, then cleaned and redeployed, so the same stock serves more households over the years.

**Trade-Off / Risk:** Lending extends the budget, but the collection and refurbishment burden falls on a handyperson team that is already stretched in summer, and residents may resist returning equipment they depend on.

**Strategic Connections:**

**Synergy:** Benefits from Consent-Light Identification Routes, which supply candidate households, and from Procurement Speed Route, which secures kits and handyperson capacity before the season. Trusted Messenger Channel Mix can raise uptake and correct fan-misuse.

**Conflict:** Competes with Mobility Support Delivery and Cooling Refuge Network Shape for the same limited budget and staff. Lending adds collection workload for handypeople, and landlord deals depend on cooperation outside municipal control.

**Justification:** *High*, High because it controls precision versus cost in the home-level package, and priority top-floor and social-housing coverage. It depends on identification and procurement, and competes with transport and refuge budgets. It is a delivery lever rather than a system hub.

### Decision 7: Health Loop and Worker Duty Levers
**Lever ID:** `c001d797-dbc8-4b19-a702-a159f7d8cf8e`

**The Core Decision:** Defines how hospitals, EMS, primary care and employers connect to the heat response without new legislation or identifiable records. Success is measured by MOU signed before the Month 2 (2026-12-08) gate, daily aggregate counts received on alert days, escalation guidelines used consistently by call-takers and outreach staff, and municipal crews and contractors covered by heat-protection rules.

**Why It Matters:** The city has to use health and employment data lawfully and without new legislation. Daily aggregate signals from EMS and hospitals can inform escalation without exposing patient records. For workers, the city controls its own staff and contractors directly but private employers only by persuasion. How strongly it uses procurement and public pressure determines how far protection extends beyond municipal crews.

**Strategic Choices:**

1. Agree an MOU for daily aggregate counts of heat-related EMS calls and ED visits, with shared escalation guidelines for call-takers and outreach staff, and no sharing of identifiable patient records.
2. Write heat-protection clauses into municipal contracts and tenders, requiring schedule changes, breaks, water and shade from contractors, and publish a guidance pack and recognition scheme for private employers.
3. Pair outreach staff with a clinical nurse line that gives phone triage on suspected heat illness, so mild cases are managed at home and EMS capacity is reserved for severe cases.

**Trade-Off / Risk:** Contract clauses give the city real leverage over contractors, but enforcement relies on site inspections the municipality may not be able to staff, and private employers outside its tenders remain untouched.

**Strategic Connections:**

**Synergy:** Strengthens Street Contact Pathway by giving outreach staff clear escalation rules and a nurse line for suspected heat illness. It also supplies the aggregate EMS and ED counts that Attribution and Comparison Design needs for evaluation.

**Conflict:** Contract heat clauses compete with Procurement Speed Route, since added conditions slow tenders and narrow suppliers. Nurse-line and MOU work also draws scarce clinical and analyst time away from Mobility Support Delivery staffing.

**Justification:** *High*, High because it links hospitals, EMS and nurse-line triage to outreach escalation and protects healthcare capacity. It also supplies the aggregate outcome data for evaluation. Worker clauses add a second scope that conflicts with procurement speed.

### Decision 8: Procurement Speed Route
**Lever ID:** `2b1e09e0-5071-4a61-959f-a1e15bb5ce8e`

**The Core Decision:** Chooses the purchasing pathway for kits, handyperson services, transport, security and center fit-out so orders are placed by the Month 2 (2026-12-08) readiness gate. Key measures are days from specification to order, share of orders placed on time, price benchmarking against market quotes, audit-readiness of files, and whether the approach can be reused under other EU cities' procurement rules.

**Why It Matters:** The procurement pathway for kits, transport, security and center fit-out sets how fast orders are placed by the Month 2 (2026-12-08) gate and how much price and quality competition the city gets. Faster routes reduce schedule risk but narrow supplier choice and raise audit scrutiny. The route chosen also determines whether the playbook can be reused by other EU cities under their own rules.

**Strategic Choices:**

1. Use existing municipal or central-purchasing framework agreements with call-off orders for kits, vehicles and services, accepting limited product choice in exchange for placing orders within weeks.
2. Run a short competitive tender in lots, separating kits, handyperson installation and transport, so small local firms and social enterprises can bid and no single supplier failure stalls the program.
3. Place a small first order of pre-positioned stock through simplified below-threshold purchasing, then run a full competitive process for the second tranche once the Month 4 (2027-02-08) gate releases funds.

**Trade-Off / Risk:** Frameworks and below-threshold buying meet the schedule, but if call-off prices go unbenchmarked or orders are split to stay under thresholds, the city risks an audit finding that undermines the program's public credibility.

**Strategic Connections:**

**Synergy:** Enables Home Kit Targeting and Fitting by getting stock and installers in place before the first heat events. It also gives Mobility Support Delivery a signed transport contract in time for the Month 2 (2026-12-08) gate.

**Conflict:** Fast frameworks limit supplier choice, which constrains Home Kit Targeting and Fitting product fit and local social-enterprise participation. Speed also conflicts with the contract-clause requirements in Health Loop and Worker Duty Levers.

**Justification:** *High*, High because it governs schedule risk against the Month 2 (2026-12-08) readiness gate for kits, transport and installers. It enables home kits and transport contracts but conflicts with contract clauses, language work and supplier choice. Audit risk also affects public credibility.

### Decision 9: Trusted Messenger Channel Mix
**Lever ID:** `cd73026b-177e-48d6-a165-02682fb3c079`

**The Core Decision:** Sets who carries heat-safety messages to residents who are offline or distrust official channels, and how limited communication budget is split between professional messengers, mass media and peer ambassadors. Success means briefed messengers, consistent scripts, reach among 65+, migrants and people living alone, and quick correction of unsafe advice such as alcohol use or misused fans.

**Why It Matters:** Because many at-risk residents are offline, who delivers the message matters as much as the channel. Using familiar figures such as pharmacists, GPs, building caretakers and faith leaders improves uptake and counters unsafe advice, but it requires training and consistent scripts. Spreading effort across many channels dilutes the budget, so the mix determines how much is left for field delivery.

**Strategic Choices:**

1. Invest most of the communications budget in pharmacist, GP-practice, caretaker and faith-leader briefings with printed leave-behinds, and keep mass media to radio and low-cost municipal channels.
2. Run a conventional pre-season campaign through local radio, posters, door hangers and flyers, with a lighter partner briefing layer and a rapid-response rebuttal channel for misinformation.
3. Recruit residents who have lived through past heat events, including older tenants and migrant community members, as paid peer ambassadors who deliver messages in building lobbies, markets and language groups.

**Trade-Off / Risk:** Peer and professional messengers reach people mass media misses, but they spread consistent messaging only with sustained briefing, and a single ambassador repeating unsafe advice like alcohol or misused fans can damage trust.

**Strategic Connections:**

**Synergy:** Amplifies Language Access Architecture, since trusted community messengers deliver translated content credibly. It also feeds enrollment into Consent-Light Identification Routes through pharmacists, GPs and caretakers who can refer residents.

**Conflict:** Heavy investment in messenger training and peer ambassadors reduces funds for Street Contact Pathway field staff and Home Kit Targeting and Fitting. Decentralised messengers also strain message consistency controlled by Command Seat Allocation.

**Justification:** *Medium*, Medium: it improves uptake, enrollment referrals and misinformation control among offline residents. It amplifies language access and identification, but it is an optimisation of reach and does not decide the core operational trade-offs. It competes for field budget.

### Decision 10: Attribution and Comparison Design
**Lever ID:** `dda15186-39ef-42c7-933c-0e007145ecff`

**The Core Decision:** Determines how credibly the program can claim reductions in heat-related EMS calls, ED visits and excess mortality, and how defensible the scaling cost model is. Scope covers comparison groups, temperature adjustment, data-processing agreements, analyst capacity and plain-language statements of limits. Success is a pre-specified protocol, usable baselines by Month 4 (2027-02-08), and honest uncertainty ranges.

**Why It Matters:** The evaluation design determines whether reported reductions in EMS calls, ED visits and excess deaths can be credibly linked to the program rather than to a mild summer. Stronger comparison designs need more data access, partner cooperation and analyst time. Simpler pre-post comparisons cost less but are easily challenged, which affects the credibility of the cost model for other cities.

**Strategic Choices:**

1. Compare heat-day outcomes in pilot districts against matched non-pilot districts and prior years, adjusting for temperature, using aggregate EMS, ED and mortality counts only.
2. Use a pre-post comparison against a multi-year city baseline, report heat-attributable excess mortality with explicit confidence ranges, and state attribution limits in plain language.
3. Commission an independent university or public-health institute partner to pre-register the evaluation protocol and analyze data under a data-processing agreement, publishing results regardless of direction.

**Trade-Off / Risk:** Independent pre-registered evaluation increases credibility, but small-area counts in a mid-sized city are noisy, so even a well-designed comparison may be unable to detect real effects within one season.

**Strategic Connections:**

**Synergy:** Builds on Health Loop and Worker Duty Levers, whose aggregate EMS and ED counts supply the outcome data. It also supports Alert Trigger Ladder by testing whether thresholds correspond to real health impacts.

**Conflict:** Matched-district comparison conflicts with Cooling Refuge Network Shape and Home Kit Targeting and Fitting, which concentrate effort in the highest-need areas. Independent evaluation also consumes budget otherwise available for field delivery.

**Justification:** *Medium*, Medium: it sets the credibility of outcome claims and the scaling cost model, but it does not affect delivery within the first season. Small-area counts limit detection anyway. It conflicts mildly with concentrating effort in high-need areas.

### Decision 11: Language Access Architecture
**Lever ID:** `6c3b08dc-5896-49e6-9070-a5aa9686a1a7`

**The Core Decision:** Determines how alerts, enrollment scripts and heat-illness escalation guidance reach recent migrants and other residents with limited local-language skills. Scope covers the heat line, door-knock teams, cooling-center welcome desks and printed materials. Success metrics: share of enrolled residents contacted in their preferred language, language coverage of the heat line during alert hours, and enrollment parity across neighborhoods. Must be workable before the Month 2 (2026-12-08) readiness gate.

**Why It Matters:** Recent migrants with limited service access are a named priority group, and translated flyers alone rarely reach them. How the city delivers language support determines whether alerts, scripts and escalation guidance work in practice. A cheap, centralised approach may fail on trust, while community-based approaches take longer to build before the season.

**Strategic Choices:**

1. Contract a telephone interpretation service for the heat line and outreach staff, and translate core materials into the locally most common languages identified from municipal registers.
2. Recruit paid community language ambassadors from migrant associations to co-write messages, accompany door-knocks and staff cooling-center welcome desks in their own languages.
3. Build a pictogram-first message set for door hangers, flyers and center signage tested with residents, relying on images and short phrases so one design serves many language groups.

**Trade-Off / Risk:** Interpretation lines scale quickly but do little for trust, ambassadors build trust but depend on recruitment time and fair pay, and pictograms can be misread for nuanced safety advice such as fan use or medication.

**Strategic Connections:**

**Synergy:** Amplifies Trusted Messenger Channel Mix, since ambassadors double as community messengers, and strengthens Consent-Light Identification Routes by making NGO and community referrals credible and understandable to migrants who avoid formal registries.

**Conflict:** Competes with Procurement Speed Route, because ambassador recruitment and pictogram testing take longer than buying interpretation services before Month 2 (2026-12-08). Also draws budget and staff time from Home Kit Targeting and Fitting and Mobility Support Delivery.

**Justification:** *Medium*, Medium: it is essential for the migrant priority group and amplifies messengers and identification. It is mainly an enabling layer on other levers, and its overlap with the messenger mix lowers its standalone strategic weight.

### Decision 12: Street Contact Pathway
**Lever ID:** `19aa58cd-6159-4122-9aef-58afa868db60`

**The Core Decision:** Provides a dedicated route to unhoused people, who are absent from registries and rarely reachable by phone. Scope includes alert-day rounds, water and shade provision, referral cards, on-the-spot transport triggers and clear rules on consent and enforcement boundaries. Success metrics: distinct individuals contacted per alert day, share referred or transported, heat-illness events in this group, and partner reporting quality. Staffing needs to be realistic for a mid-sized city.

**Why It Matters:** Unhoused people rarely appear on registries or answer phones, so the usual enrollment route misses them. A dedicated street contact pathway shifts effort toward mobile teams and shelter partners, drawing resources away from housed outreach. It also raises questions about consent and enforcement boundaries when staff meet someone in clear distress.

**Strategic Choices:**

1. Fund existing homeless-service NGOs to run daytime mobile water-and-shade rounds with cooling vests and referral cards, keeping the city out of direct contact.
2. Deploy a small municipal street team, jointly staffed with a nurse and a social worker, that patrols known sites on alert days and can trigger transport on the spot.
3. Open drop-in daytime cool points at day centers and soup kitchens already trusted by the target group, with showers, storage for belongings and no identification required.

**Trade-Off / Risk:** NGO-led rounds preserve trust but depend on partner capacity and reporting, a municipal team gives control but may deter people wary of authorities, and fixed drop-in points miss those who will not travel.

**Strategic Connections:**

**Synergy:** Works with Mobility Support Delivery, because street teams can trigger transport directly to cooling centers, and with Alert Trigger Ladder, which can schedule rounds and drop-in hours by alert level for timely deployment.

**Conflict:** Diverts scarce nurses, social workers and budget from housed outreach under Consent-Light Identification Routes. A municipal team also complicates Command Seat Allocation, since it needs clear ownership, and may erode NGO trust.

**Justification:** *Medium*, Medium: it serves a narrow but high-risk group, the unhoused. It links to transport and alert tiers but affects a small share of overall mortality. It draws scarce clinical and social staff from housed outreach, and can be delegated to NGOs.
