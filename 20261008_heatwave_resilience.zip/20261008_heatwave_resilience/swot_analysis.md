
## Strengths 👍💪🦾
- Established practice: heat action plans, refuges and welfare checks are proven, giving low novelty risk.
- Existing municipal assets (libraries, community centers, parish halls) allow about 10 refuge sites (~400 places) without construction.
- Intermediary-held lists keep personal data with trusted partners, lowering GDPR exposure and reaching offline residents.
- Mayoral-level command with a public-health deputy speeds cross-department approvals and procurement.
- Disciplined design: a tiered alert ladder (Level 1 advisory) limits alert fatigue, explicit gates and a €280k contingency (8%).
- Strong NGO networks and a nearby university (Valencia) support outreach, language access and evaluation.

## Weaknesses 👎😱🪫⚠️
- KILLER APPLICATION MISSING: no single compelling flagship use-case yet exists that makes residents, partners and other cities adopt the model. The plan is a bundle of seven workstreams, so the value proposition is diffuse and hard to communicate or scale.
- Month 2 (2026-12-08) and Month 4 (2027-02-08) gates fall in the cool season, so evidence rests on drills, which funders may see as weaker.
- Hard critical path: procurement, hiring (43 peak FTE) and vetting of ≥20 volunteers all compress into Months 0-2 (2026-10-08 to 2026-12-08).
- Baseline data (80-120 EMS calls, 15-25 excess deaths, provisional estimates) is unverified, and small-area counts are noisy.
- Contingency (€280k) cannot cover both the taxi-only fallback and a delayed release (exposure €350-650k, estimate).
- No identified funding for Year 2 (≈€2.3M/year, estimate).
- Opt-in/intermediary reach: 3,000 enrolled residents is ≈9% of 65+ (estimate), leaving most at-risk people unreached.

## Opportunities 🌈🌐
- Develop a killer application: a 'Hot Night Guarantee' for enrolled high-risk residents. Any Level 2-3 alert triggers a trusted-person call within a set time, a ride to a refuge within 45 minutes, and a fitted cool home. One simple promise could drive enrollment, trust and funder interest. Obstacles: it depends on volunteer and taxi capacity, partner call capacity, GDPR-limited reach, a cool-season launch, and a promise that must be kept at surge.
- Use the 2,000 home kits (rubric-scored) as a visible, tangible benefit that supports enrollment.
- Learn from Barcelona's refuge network and Paris's registry protocols, and from Ahmedabad's tiered alerts and evaluation.
- Publish a reusable playbook and cost model (€/center-hour, €/trip, €/enrollee) to attract EU funding for scaling.
- Use trusted messengers (pharmacists, GPs, caretakers, faith leaders) and ambassadors to build trust and referrals.
- Local data from the first season can calibrate alert thresholds for Year 2.

## Threats ☠️🛑🚨☢︎💩☣︎
- Cool June-July weather could leave the gates untestable, delaying the €1.5M and causing a €200-400k cash gap (estimate).
- Supply-chain slippage of 4-8 weeks could push kit installation past the first heat events.
- Volunteer shortfall could push pickup times above 45 minutes or force taxi-only operation (+€150-250k).
- GDPR challenge or partner withdrawal could cut outreach reach by 10-25%.
- Reputational damage from an incident at a refuge, an outreach assault or a failed response under media attention.
- Staff fatigue and surge in multi-day heat waves could cut service 10-25%.
- Misinformation (alcohol, fan misuse) and weak trust among migrants.
- Political turnover or competing crises could weaken incident command.

## Recommendations 💡✅
- Month 0-1 (2026-10-08 to 2026-11-08): Incident commander and communications lead define the 'Hot Night Guarantee' (call, ride, cool home) as the flagship offer. Test its wording with focus groups by Month 1 (2026-11-08).
- Month 1 (2026-11-08): Procurement lead issues specs by Month 0.8 (2026-11-01), places the first 30-40% kit call-off at Month 1.2 (2026-11-14) and signs the taxi retainer (cap €80k), with 2-3 backup suppliers per category.
- Month 0.5-1.5: Legal counsel and partner liaison officer obtain the GDPR opinion (Month 1 = 2026-11-08) and sign partner DPAs (Month 1.5 = 2026-11-23).
- Month 0-3 (2026-10-08 to 2027-01-08): HR coordinator and volunteer lead recruit in fortnightly cohorts, with ≥20 vetted by Month 2 (2026-12-08). If fewer than 20 are in the pipeline at Month 1.5 (2026-11-23), scale the retainer.
- Month 2.5-4: Operations lead finalizes the drill protocol (Month 2.5 = 2026-12-23), runs the full-system drill (Month 3.2 = 2027-01-14) and closes after-action items by Month 3.9 (2027-02-04). The funder is briefed on the 50% partial-release rule.
- Month 2-7 (2026-12-08 to 2027-05-08): Health deputy and university partner agree EMS/ED coding and a pre-specified evaluation protocol. They also identify a Year-2 funding source by Month 9 (2027-07-08).

## Strategic Objectives 🎯🔭⛳🏅
- Pass the Month 2 (2026-12-08) readiness gate: ≥8 of 10 refuge sites signed, ≥50% of places accessible, retainer signed, ≥20 volunteers vetted, and 100% of tranche-1 orders placed.
- Pass the Month 4 (2027-02-08) scale gate: ≥80% of planned refuge hours delivered in the drill, ≥60% contact success from ≥300 attempts, mean pickup <45 min over ≥30 requests, and all after-action items closed.
- Enroll 3,000 high-risk residents by Month 7 (2027-05-08), with ≥5% of outreach calls in non-official languages.
- Install kits in 2,000 homes (rubric score ≥60) by Month 7.3 (2027-05-17), with 10-20% of installs inspected.
- By Month 12 (2027-10-08), deliver the playbook, cost model, evaluation report and a Year-2 roadmap with an identified funding source.

## Assumptions 🤔🧠🔍
- Castellón de la Plana (~170k residents) is the pilot site; population estimates (65+ ≈34,000) are unverified.
- Baseline of 80-120 EMS calls and 15-25 excess deaths per summer is provisional.
- Alert thresholds (≥33°C/20°C advisory; ≥35°C/22°C alert) are proposed and will be reviewed after the first season.
- The funder accepts drill evidence for the Month 4 (2027-02-08) gate and the 50% partial-release rule.
- No new legislation is needed, and the mayor signs the delegation of authority by Month 1 (2026-11-08).
- The budget is 100% grant-financed, with no revenue.

## Missing Information 🧩🤷‍♂️🤷‍♀️
- Verified local EMS, ED and mortality history, and heat coding practice.
- Recruitment evidence for volunteer drivers and taxi retainer quotes.
- Partner call-center capacity and lawful basis confirmed by counsel (AEPD view).
- Resident research on what offer would drive enrollment (killer-app validation).
- Accessibility audit results for candidate sites.
- Funder's written position on drill-based gates.
- Year-2 funding source.
- Local migrant language mix, to be confirmed Month 0 (2026-10-08).

## Questions 🙋❓💬📌
- Which single promise to residents would make an isolated 75-year-old enroll, and can the city keep it on its worst day?
- Is the 45-minute pickup target realistic for wheelchair users with 40 volunteers and a capped €80k retainer?
- What happens if the funder rejects drill evidence at Month 4 (2027-02-08), and can the €160k tranche-1 contingency cover the gap?
- Does the intermediary-list model reach the most isolated residents, or does it mainly reach people already known to services?
- Who funds Year 2, and which components would be cut if funding is only partial?