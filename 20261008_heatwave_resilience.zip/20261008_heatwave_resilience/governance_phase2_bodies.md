### 1. Heat Response Steering Committee

**Rationale for Inclusion:** This is a high-complexity, multi-department municipal program with strategic dependencies on mayoral authority, cross-departmental coordination, and significant reputational risk. A strategic-oversight body is essential to ensure political alignment, secure timely budget decisions, resolve inter-departmental conflicts, and provide accountability to the funder and city council. The brief explicitly requires a mayor's-office incident commander; a Steering Committee crystallizes this authority and ensures continuity across staff transitions.

**Responsibilities:**

- Approve alert-trigger thresholds and incident-command delegation; escalate threshold changes to council if politically sensitive
- Release or withhold €1.5M tranche-2 funding at Month 4 (2027-02-08) based on gate-review evidence
- Resolve cross-department resource conflicts (e.g., public works, health, civil protection) and authorize budget reallocation
- Review monthly reforecasts and approve contingency-reserve drawdowns >€20k
- Oversee legal and GDPR compliance; approve data-processing agreements with partners
- Approve Year-2 roadmap and playbook before public release

**Initial Setup Actions:**

- Establish written delegation of incident-command authority signed by the mayor by Month 1 (2026-11-08)
- Set alert-trigger thresholds (Level 1: high ≥33°C or low ≥20°C on ≥2 consecutive days; Level 2: high ≥35°C and low ≥22°C for ≥2 consecutive days; Level 3: same as Level 2 for ≥3 consecutive days or national red warning) by Month 1 (2026-11-08)
- Approve incident-command and operations structure; name incident commander, operations lead and communications lead by Month 0.5 (2026-10-23)
- Engage GDPR counsel and approve legal-review scope by Month 0.5 (2026-10-23)
- Authorize procurement route and spending authorities by Month 0.8 (2026-11-01)

**Membership:**

- Mayor or delegated chief executive (Chair)
- Deputy Mayor or head of municipal health/public protection (Vice-Chair)
- Director of civil protection and emergency services
- Director of municipal communications
- Municipal finance director (observer for budget forecasts)
- External independent member: university or public-health institute evaluation partner (advisory, non-voting)

**Decision Rights:** Strategic decisions only: alert-threshold setting and modification; tranche-2 funding release/non-release; reallocation of >€20k from contingency; approval of GDPR and data-processing agreements; authorization of procurement routes and supplier sole-source justifications >€100k; approval of Year-2 roadmap and playbook before publication. All operational decisions remain with the incident commander and PMO. Escalation from operational level occurs for decisions impacting budget >€20k, legal exposure, or inter-departmental authority conflicts.

**Decision Mechanism:** Majority vote (4 of 6 members). Quorum = 4 members including Chair or Vice-Chair. Tie-breaker: Chair vote. In emergencies (e.g., mid-alert funding decision), incident commander may brief Chair and one other member by phone and recommend action; formalized in the next meeting (≤3 days). Legal and GDPR decisions require sign-off from legal counsel before vote.

**Meeting Cadence:** Monthly during Months 0–4 (2026-10-08 to 2027-02-08, project setup and gates) on the first Monday; bi-weekly during Months 5–7 (2027-03-08 to 2027-05-08, kit distribution and initial operations); monthly during Months 8–12 (2027-06-08 to 2027-10-08, season and playbook). Emergency meetings within 24 hours if: non-release of tranche-2 becomes likely, legal challenge emerges, major breach occurs, or incident commander escalates unresolved conflict.

**Typical Agenda Items:**

- Incident-command and operational status (via PMO briefing): alert declarations, response performance, gate-metric tracking
- Financial status: budget burn by cost category, reforecast and contingency drawdown justifications
- Legal and GDPR compliance: partner DPA progress, data-protection audit findings, breach-notification log
- Staffing and partner engagement: recruitment status, partner capacity and satisfaction, staff retention and fatigue incidents
- Gate metrics progress: cooling-center hours, outreach contact success, transport response time, drill results (if applicable)
- Risk register review: new risks, escalated mitigation actions, insurance and liability incidents
- Year-2 planning (Months 10–12 = 2027-08-08 to 2027-10-08): roadmap development, scaling cost model validation, funder and peer-city engagement

**Escalation Path:** Steering Committee decisions on budget release, threshold changes or legal interpretation escalate to the city council (or mayoral cabinet if council is not in session) if: (1) spending approval needed is above the mayor's delegated authority, (2) a legal opinion is contested, or (3) the decision affects public policy beyond heat response (e.g., new data-protection rules). Operational escalations to the Steering Committee come from the incident commander or PMO if: unresolved cross-department conflict, contingency drawdown >€20k needed, or legal exposure. If the Steering Committee cannot decide, the mayor casts the deciding vote; if still deadlocked, legal counsel issues a binding opinion (for GDPR/compliance) or the decision is tabled and deferred to the city council.
### 2. Heat Response Operations Team (Incident Command Structure)

**Rationale for Inclusion:** Operational delivery of cooling centers, transport, outreach, home kits and health coordination requires a unified command structure with clear ownership, rapid decision-making authority and incident-day responsiveness. The incident commander must declare alerts, mobilize resources, and coordinate cross-departmental actions within hours. This team executes the alert-trigger ladder, staffs refuges, dispatches transport and manages partner operations during alert periods. It also tracks gate metrics and prepares gate-review evidence for the Steering Committee.

**Responsibilities:**

- Declare heat alerts (Level 1, 2, 3) within 1 hour of forecast trigger; inform partners and public within 24 hours
- Mobilize cooling centers, transport dispatch, phone line and street contact on alert days; stand down when thresholds no longer met and temperatures normal for 48 hours
- Coordinate daily operations: SITREP at 08:30, partner briefing at 09:30, public update by 11:00 on Level 2-3 days
- Manage center staffing, volunteer dispatch, phone-line operations and outreach team deployment; authorize re-allocation of resources between sites if demand exceeds capacity at one location
- Escalate heat-illness or safety incidents to EMS; coordinate with health-system partners (hospitals, EMS) on aggregate data exchange and mutual-aid triggers
- Monitor and track gate-metric data daily: center-hours opened, outreach calls and success rates, transport requests and response times, kit installations
- Conduct monthly review of performance metrics, partner feedback and risk register; escalate budget or resource issues to Steering Committee; authorize corrective actions within operational scope (staffing adjustments, scheduling changes, local script updates)

**Initial Setup Actions:**

- Designate incident commander, public-health deputy, operations lead, communications lead and partner-liaison officer by Month 0.5 (2026-10-23)
- Establish written position descriptions, delegations of authority and role-specific escalation rules for each lead by Month 1 (2026-11-08)
- Establish daily SITREP and briefing schedule (09:30 start, 30-minute duration) and draft agenda templates by Month 1.2 (2026-11-14)
- Set up heat-response operations workspace (shared desks, phone line, email lists, shared drives, daily-log templates) by Month 1.5 (2026-11-23)
- Brief incident-command team on alert thresholds, decision criteria and escalation rules by Month 2 (2026-12-08); conduct tabletop scenario drill by Month 2.5 (2026-12-23)

**Membership:**

- Incident commander (mayor's office or delegated chief-of-staff equivalent)
- Public health deputy (municipal health department)
- Operations lead (civil protection or emergency management)
- Communications lead (municipal communications office)
- Partner-liaison officer (dedicated to this program, may be pooled from public health or social services)
- PMO/program coordinator (reports to incident commander, tracks budgets, gates and schedules)

**Decision Rights:** Operational decisions within delegated spending and personnel authority: alert declaration per thresholds set by Steering Committee; daily resource mobilization and staffing; re-allocation of resources between sites on alert days; partner communications and coordination; frontline incident management (first aid, escalation to EMS, de-escalation protocols). Cannot commit budget >€20k, alter strategic thresholds, or approve procurement without Steering Committee. Can authorize corrective actions <€5k (e.g., emergency supplies, local staff overtime). Decisions on gate-metric interpretation that affect the Month 4 (2027-02-08) release decision escalate to Steering Committee.

**Decision Mechanism:** Incident commander has final authority on daily operational decisions during alert periods. For non-alert decisions (e.g., monthly review, staffing adjustments, corrective actions), incident commander convenes the full Operations Team; consensus sought, but incident commander decides if consensus cannot be reached within 24 hours. Public-health deputy has veto on clinical safety decisions (e.g., escalation protocols, health-data access); if vetoed, incident commander escalates to Steering Committee. Communications lead has editorial control over public messaging; incident commander may override for urgent/sensitive statements, but communications lead may appeal to Steering Committee if override is systematic.

**Meeting Cadence:** Daily during alert days (Level 1, 2 or 3): SITREP 08:30 (15 min), partner briefing 09:30 (30 min), public update 11:00 (10 min). Weekly during non-alert periods (Months 1–5 = 2026-11-08 to 2027-03-08): Monday 14:00 (60 min) to review progress, staffing, procurement and risks. Bi-weekly during summer (Months 6–8 = 2027-04-08 to 2027-06-08) to monitor early heat and kit distribution. Daily during Months 9–11 (2027-07-08 to 2027-09-08, peak season): SITREP and briefing only if alert active; Friday debrief (60 min) for weekly review. Post-season: monthly closure/evaluation meetings.

**Typical Agenda Items:**

- Alert status and threshold interpretation: forecast review, trigger logic, alert-declaration timing and rationale
- Cooling-center operations: occupancy, staffing, supply availability, incident reports, accessibility issues, site-specific problems
- Transport and dispatch: request volume, response times, volunteer driver availability, taxi backup utilization, mobility-limited resident experience
- Outreach and enrollment: contact attempts by partner, success rates, language coverage, difficult-to-reach populations, escalation cases
- Health-system data: daily EMS/ED counts, trends, mutual-aid triggers, clinical escalation cases, hospital capacity alerts
- Staffing and fatigue: absences, incident reports, training gaps, peer support needs, retention issues
- Financial and procurement: spend tracking by category, reforecast, contingency-reserve status, supply-chain delays, vendor performance
- Risk and incident register: new incidents, safeguarding concerns, GDPR breaches, reputational issues, corrective actions status
- Gate-metric tracking: drilling progress, real-event data, readiness for Month 2, 4 (2026-12-08, 2027-02-08) gates

**Escalation Path:** Operational issues affecting gates or requiring >€20k spending escalate to the Steering Committee. During alert periods, critical incidents (serious injury, safety failure, reputational crisis) are reported immediately to the incident commander and chair of the Steering Committee; Steering Committee can convene within 24 hours if needed. If an alert threshold or interpretation is contested by a partner or the health system, the public-health deputy convenes a rapid review (24 hours) with relevant partners; if still unresolved, escalates to Steering Committee. Volunteer or staff safety incidents involving police or legal liability are reported immediately to the incident commander and municipal legal counsel; legal counsel advises on escalation to Steering Committee or council.
### 3. Cooling Center Operations & Accessibility Group

**Rationale for Inclusion:** Ten independent cooling-center sites require consistent staffing, safety, accessibility and service standards. This group ensures each site meets opening-day readiness, delivers planned hours, maintains accessibility, handles incident response and keeps supplies stocked. It is a specialized operational sub-unit reporting to the incident commander's Operations Team, responsible for the tangible 'refuge network' experience. The Month 4 (2027-02-08) gate (80% planned center hours) depends on this group's execution.

**Responsibilities:**

- Coordinate contracting and fit-out (water, first-aid kits, AEDs, signage, quiet rooms) at all 10 sites by Month 2 (2026-12-08)
- Conduct accessibility audit of all sites by Month 1.5 (2026-11-23); prioritize 5 fully accessible sites for May opening
- Hire and train cooling-center managers (1 per site) and support staff (1–2 per site) by Month 4 (2027-02-08); conduct health-and-safety orientation and first-aid training
- Operate centers per alert level: Level 1 = standby only; Level 2 = 10:00-20:00 daily; Level 3 = 3 sites extend to 24:00; stand down within 2 hours of end-alert declaration
- Track daily center-hours delivered, occupancy and supply usage; escalate accessibility or staffing gaps within 4 hours
- Respond to incidents at centers (injury, medical emergency, distressed resident): first-aid response, EMS notification if needed, incident log and debrief within 24 hours
- Manage supply chain (water, ice, first-aid kits, toiletries, printed materials) and inventory; order replacement supplies with 2-week lead time

**Initial Setup Actions:**

- Identify and secure facility-use agreements for all 10 sites by Month 1 (2026-11-08); confirm space, utilities and liability insurance
- Conduct accessibility audit and remediation planning for all sites by Month 1.5 (2026-11-23); prioritize 5 fully accessible sites (≥50% of planned capacity)
- Procure fit-out items (water dispensers, first-aid kits, AEDs, signage, quiet-room setup) and deliver to sites by Month 5 (2027-03-08)
- Recruit and vet cooling-center managers by Month 4 (2027-02-08); assign one manager per site with documented position description
- Conduct opening-day drill at all sites with full staffing, supply checks, accessibility verification and signage by Month 5.5 (2027-03-23)

**Membership:**

- Center Operations Lead (dedicates 1 FTE, reports to incident commander)
- Cooling-center manager representatives from 3–4 sites (rotates quarterly to ensure input from all 10 sites)
- Supply-chain and inventory coordinator (0.5 FTE, shared with other operations)
- Accessibility consultant or municipal disability-access officer (advisory, spot-check verification)

**Decision Rights:** Center Operations Lead approves: staffing adjustments within approved budget (hiring, scheduling changes, overtime up to 10% of budgeted hours); site-specific supply orders and emergency purchases <€2k; minor operational changes (e.g., water-distribution points, signage placement) and local accommodation of residents with disabilities. Cannot approve major remediation (>€10k per site), procurement of new equipment types, or changes to opening hours without incident commander approval. Accessibility decisions require review by the accessibility consultant before implementation. If a site is deemed unsafe or inaccessible beyond remediation, Center Operations Lead recommends closure to incident commander; incident commander decides in consultation with Steering Committee.

**Decision Mechanism:** Center Operations Lead makes routine staffing and supply decisions. Escalations to the incident commander occur if: accessibility or safety issues at a site threaten opening-day readiness, a site manager requests reassignment due to performance or safety concerns, or supply shortages threaten operations. For decisions affecting >3 sites, Center Operations Lead convenes site representatives (≥2 managers) and seeks consensus; if not reached within 24 hours, escalates to incident commander with both the managers' views and the lead's recommendation.

**Meeting Cadence:** Weekly during Months 1–5 (2026-11-08 to 2027-03-08, setup phase): Tuesdays 14:00 (60 min), covering fit-out, staffing, accessibility audit progress and procurement. Daily during alert days (Months 6–11 = 2027-04-08 to 2027-09-08): Morning briefing 08:00 (15 min) covering center readiness, staffing confirmation and supply status; afternoon debrief 18:00 (30 min) reviewing occupancy, incidents and corrective actions. Weekly on non-alert days during summer: Monday 14:00 (45 min) for supply planning, staffing review and accessibility checks.

**Typical Agenda Items:**

- Site readiness: facility-use agreement status, remediation progress, fit-out delivery, staffing assignments and training completion
- Accessibility: audit findings by site, remediation timeline and cost, prioritization of fully accessible sites, accessibility-check checklist completion
- Staffing: hiring progress, first-aid and orientation training, manager readiness, rostering for alert days, absence and leave planning
- Operations: center-hours delivered and occupancy by site, supply usage and inventory, incident reports and safety issues, resident feedback and accommodations
- Procurement and budgets: supply-chain status, lead-time risks, inventory turnover, cost tracking
- Equity: coverage of sites by neighborhood deprivation index, accessibility by disability type, language support availability at each site

**Escalation Path:** Site-specific safety or accessibility issues escalate to Center Operations Lead immediately; if remediation is not feasible within 4 weeks or costs >€10k, escalate to incident commander with options (defer opening, drop site, apply for supplementary funding). Staffing problems (manager unable to work, high absence rate, safety incident involving staff) escalate to incident commander. Supply-chain delays >2 weeks escalate to PMO/procurement coordinator to trigger backup suppliers. If a center fails the accessibility audit and remediation is not feasible, incident commander decides in consultation with Steering Committee whether to proceed with a non-fully-accessible site or defer its opening until remediation is complete. Accessibility consultant may appeal any decision to defer or proceed with non-accessible site to the disability-access ombudsman or local authority if consultation is inadequate.
### 4. Outreach, Enrollment and Intermediary-Partner Coordination Group

**Rationale for Inclusion:** High-risk residents are identified and contacted via intermediary partners (housing associations, social services, NGOs, pharmacies) who hold their own data. This group ensures partner readiness, coordinates outreach protocols and scripts, tracks contact-attempt and success-rate data (the Month 4 2027-02-08 gate requires ≥60% success), and manages the 'no wrong door' enrollment mechanism (phone line + in-person at refuges). It also ensures multilingual access, reaches unhoused people via street contact, and navigates the complex GDPR constraints of intermediary-held lists.

**Responsibilities:**

- Co-design and agree outreach scripts, call targets, escalation rules and feedback mechanisms with each partner by Month 1 (2026-11-08)
- Conduct joint training for all partner outreach staff (50–80 people across housing, social services, NGOs, pharmacies) by Month 2 (2026-12-08); refresher training before June alerts
- Monitor and track partner call volumes, contact attempts and success rates daily on alert days; provide real-time feedback to partners (call target vs. actual, success rate vs. gate threshold)
- Operate the heat-response phone line (08:00–22:00 daily; 24:00 at Level 3): answer enrollment inquiries, provide information on cooling centers and transport, log calls and escalations
- Coordinate street contact (NGO-led rounds for unhoused residents) and drop-in cool points at day centers; track outreach to unhoused cohort separately
- Manage 'no wrong door' intake: accept registrations at phone line and in-person at cooling centers; feed enrollment into transport and outreach dispatch systems
- Ensure multilingual access: coordinate interpretation services for phone line and outreach staff; brief community-language ambassadors; track language diversity in call logs

**Initial Setup Actions:**

- Identify and sign MOUs with ≥4 key intermediary partners (housing associations, social services, NGOs) by Month 1 (2026-11-08); specify outreach commitments, data terms and escalation contacts
- Draft outreach script (3–5 minute format with escalation rules) in collaboration with partners and nurse adviser by Month 1 (2026-11-08); test with focus groups of older residents by Month 1.5 (2026-11-23)
- Identify top 4–6 non-official languages spoken in the city and commission translation of core materials (flyer, enrollment script, escalation guidance) by Month 1 (2026-11-08)
- Recruit 8–12 community-language ambassadors from migrant associations by Month 1.5 (2026-11-23); brief them on heat illness, centers, transport and protocol by Month 2 (2026-12-08)
- Procure phone line infrastructure, call-tracking software (shared spreadsheet or secure platform) and first-aid/incident-escalation templates by Month 1.5 (2026-11-23); conduct mock-call drills with partners by Month 2 (2026-12-08)
- Agree street-contact protocol with homeless-service NGO partners and co-design referral cards and water/shade provision by Month 1 (2026-11-08)

**Membership:**

- Outreach and Enrollment Lead (1 FTE, reports to incident commander)
- Phone-line coordinator (1 FTE, reports to outreach lead)
- Partner-liaison officer (if separate from Command-Structure role; else liaison officer split between both groups)
- Representative or contact person from each of ≥4 key intermediary partners (housing association, social service, NGO, pharmacy chain)
- Community-language ambassador representative (rotating, 1 ambassador per month, advisory)

**Decision Rights:** Outreach Lead approves: script iterations and local language-specific adaptations within the agreed escalation framework; partner-specific call-target adjustments (up to ±20% of planned volume) based on partner feedback and capacity; local accommodation for residents (e.g., preferred language, preferred contact time) within the no-wrong-door protocol. Cannot approve changes to alert thresholds or escalation criteria without incident commander; cannot alter the 60% contact-success gate measurement without Steering Committee; cannot change phone-line hours or escalation path to health services. Partner representatives approve their own staffing decisions and call-volume commitment changes; if a partner proposes to reduce call volume by >20%, escalates to partner-liaison officer and incident commander.

**Decision Mechanism:** Outreach Lead makes routine enrollment, call-tracking and script decisions. Monthly partner-coordination meetings convene all partner representatives; consensus sought on call targets, script effectiveness and performance feedback; if consensus cannot be reached on a data-sharing or escalation issue, outreach lead proposes a resolution with documented partner input, and incident commander decides. Language and cultural-appropriateness decisions are made by outreach lead with input from community-language ambassadors and focus-group feedback; ambassadors have veto over messaging that is culturally insensitive or medically inaccurate, with escalation to incident commander if overridden.

**Meeting Cadence:** Weekly during Months 1–5 (2026-11-08 to 2027-03-08, setup and training): Wednesdays 14:00 (90 min) for script finalization, training delivery and materials translation. Bi-weekly during Months 6–8 (2027-04-08 to 2027-06-08, pre-season and early season): Mondays 10:00 (60 min) for phone-line readiness, partner briefing and early-season performance review. Daily during alert days (Months 9–11 = 2027-07-08 to 2027-09-08): Morning briefing 08:00 (10 min) confirming partner call staffing; afternoon debrief 17:00 (30 min) reviewing call volumes, success rates and incidents. Weekly on non-alert days during summer: Friday 14:00 (60 min) for performance tracking, troubleshooting and partner feedback.

**Typical Agenda Items:**

- Partner readiness: MOUs signed, staffing confirmed, training completed, data-tracking systems set up, access to call-list data from each partner confirmed
- Script and protocol: script effectiveness feedback from partners, escalation decision-making, language-specific adaptations, cultural appropriateness checks
- Phone-line operations: call volume, wait times, interpreter availability, incident escalations, staff fatigue and feedback
- Outreach performance: contact attempts and success rates by partner, comparisons to gate targets, language diversity in calls (≥5% non-official language target), difficult-to-reach populations
- Enrollment and no-wrong-door: in-person intake at cooling centers, phone-line registrations, duplicate prevention, data quality checks
- Street contact and unhoused: NGO round volumes, outreach to unhoused residents, referrals to centers and transport, incident reports
- Multilingual access: interpretation-service utilization and cost, translation quality feedback, ambassador recruitment and briefing progress, pictogram effectiveness
- GDPR and data protection: partner compliance audit schedule, consent-withdrawal log, data-retention timeline, breach-notification protocol

**Escalation Path:** Partner capacity issues or call-volume shortfalls escalate to partner-liaison officer; if a partner cannot meet ≥40% of target calls, incident commander evaluates remediation (additional support, reduced target, partner replacement). Phone-line staffing or infrastructure failures escalate to outreach lead immediately; if outages exceed 2 hours, incident commander is notified and backup protocols activated (e.g., SMS registration, in-person-only intake). Contact-success rate trending <60% triggers real-time adjustment: script review, partner debriefing, target reassessment and extra briefing by end of week. Language-access gaps (>5% of calls cannot be answered in the resident's language) escalate to outreach lead with 5-working-day remediation plan (additional interpreter, ambassador deployment). GDPR compliance concerns (e.g., partner data breach, unauthorized contact) escalate immediately to legal counsel and GDPR adviser; incident commander and Steering Committee notified if breach is serious or affects >100 residents.
### 5. Transport Coordination and Dispatch Group

**Rationale for Inclusion:** The transport system (volunteer drivers + taxi backup) determines whether the Month 4 (2027-02-08) gate of <45-minute average pickup time is met. This group recruits and manages volunteer drivers, coordinates with taxi operators, dispatches rides during alert days, and ensures wheelchair-accessible transport for mobility-limited residents. Transport is a critical bottleneck: if volunteer recruitment falls short or taxi retainers are insufficient, the entire gate fails, and home-kit budget gets cut. This group must operate with reliable metrics, clear prioritization and responsive escalation.

**Responsibilities:**

- Recruit, vet (background checks, insurance, safeguarding) and train volunteer drivers (target 40, range 30–50) by Month 2 (2026-12-08); conduct refresher training before June
- Manage volunteer-driver insurance and liability; conduct biannual safety reviews of volunteer fleet
- Sign standby-retainer contract with taxi/accessible-transport operator (capped €80k, ≥10 vehicles within 20 min, ≥3 wheelchair-capable) by Month 1.2 (2026-11-14); manage taxi-operator performance
- Operate dispatch center: answer transport requests, confirm destination (cooling center choice), prioritize elderly and mobility-limited residents (target 30-min pickup), general residents (target 45-min), log all requests and actual response times
- Ensure wheelchair-accessible vehicles are matched to wheelchair-user requests; track accessibility-accommodation success rate
- Track daily requests, response times, volunteer-vs-taxi utilization, failed requests and reasons; escalate gaps to incident commander
- Manage volunteer coordination: rostering, absence coverage, fuel/mileage reimbursement, incident reporting and debrief if volunteers encounter distressed residents

**Initial Setup Actions:**

- Identify and vet potential volunteer drivers from community networks (retirees, charity staff, faith groups) by Month 0.5 (2026-10-23); launch recruitment campaign by Month 0.8 (2026-11-01)
- Design volunteer vetting process (background check, driving-history review, safeguarding check, insurance verification) and conduct batch vetting (monthly cohorts) beginning Month 1 (2026-11-08)
- Procure taxi/accessible-transport standby retainer and sign contract by Month 1.2 (2026-11-14); include performance-measure clauses (response time <20 min, vehicle availability ≥80%, wheelchair-accessible vehicles ≥3)
- Establish dispatch infrastructure: phone line with call-logging, volunteer driver contact list, taxi operator hotline, shared real-time tracking spreadsheet or app, maps of cooling centers and travel times
- Recruit dispatch coordinator and backup dispatcher by Month 3 (2027-01-08); conduct dispatch training and mock-drill by Month 3.5 (2027-01-23)

**Membership:**

- Transport Lead / Dispatch Coordinator (1 FTE, reports to incident commander)
- Backup dispatcher (1 FTE)
- Volunteer driver representative (rotating, 1 volunteer per month, advisory)
- Taxi-operator contract manager (external, coordinated by transport lead)
- Accessibility advocate or disability-access officer (advisory, quarterly vehicle-access audits)

**Decision Rights:** Transport Lead approves: volunteer driver scheduling and roster adjustments; mileage/fuel reimbursement within budget; taxi-operator escalation (performance complaints, vehicle failures); local routing and destination changes per resident preference (e.g., preferred center). Cannot approve changes to response-time gates (30 min for priority, 45 min average), volunteer recruitment targets or taxi retainer terms without incident commander. Cannot commit >€5k for emergency transport or vehicle rental without incident commander approval. Volunteer representatives provide feedback on driver experience; taxi operator commits to service-level targets; both can escalate performance concerns to transport lead with 24-hour response required.

**Decision Mechanism:** Transport Lead makes routine dispatch and volunteer-management decisions. Volunteer-recruitment strategy and targets are set by transport lead with incident commander (Month 0.5 = 2026-10-23). Taxi-operator performance disputes are reviewed monthly by transport lead; if unresolved, escalate to incident commander. Priority-resident pickup (30-min target for mobility-limited) overrides general requests within dispatcher authority; if dispatch system cannot meet 30-min target >10% of the time, transport lead convenes emergency review with volunteers and taxi operator to identify and fix bottlenecks within 2 days.

**Meeting Cadence:** Weekly during Months 0–5 (2026-10-08 to 2027-03-08, recruitment and setup): Thursdays 14:00 (60 min) covering volunteer recruitment pipeline, vetting cohort schedule, taxi-contract negotiation and dispatch-infrastructure setup. Bi-weekly during Months 6–8 (2027-04-08 to 2027-06-08, pre-season): Thursdays 10:00 (45 min) for volunteer training, rosters, taxi-operator readiness and transport stress-test planning. Daily during alert days (Months 9–11 = 2027-07-08 to 2027-09-08): Dispatch briefing 07:30 (10 min) confirming volunteer and taxi availability; afternoon debrief 18:00 (30 min) reviewing request volumes, response times, accessibility matches and incidents. Weekly on non-alert days: Thursday 14:00 (60 min) for performance metrics, route optimization and volunteer feedback.

**Typical Agenda Items:**

- Volunteer recruitment and vetting: recruitment campaign results, vetting-cohort completion, signed agreements, insurance verification, training status
- Volunteer rostering and management: scheduling for alert days, absence coverage, fuel/mileage reimbursement tracking, incident reports and debriefings, retention feedback
- Taxi-operator performance: request fulfillment, response times, vehicle availability, wheelchair-accessible vehicle deployment, incident reports, contract compliance
- Dispatch operations: daily request volume and response times, volunteer vs. taxi utilization ratio, failed requests and reasons, priority-resident pickup success (30-min target)
- Accessibility: wheelchair-user request matching, vehicle-access audit results, accessibility-accommodation success rate, resident feedback
- Transport stress test (pre-season May drill): simulated request volume, dispatch load, response-time achievement, bottleneck identification and fixes
- Financial tracking: volunteer mileage/fuel reimbursement, taxi-operator invoice reconciliation, budget forecast

**Escalation Path:** Volunteer-recruitment shortfalls (pipeline <20 drivers by Month 1.5 = 2026-11-23) trigger taxi-retainer scale-up (capped €80k); transport lead proposes adjustment, incident commander approves. Volunteer safety incidents (assault, accident, safeguarding concern) escalate immediately to transport lead and incident commander; occupational health and legal counsel notified. Taxi-operator performance failures (response time >30 min >25% of the time, vehicle unavailability) are escalated to taxi operator with 48-hour remediation plan; if unresolved, incident commander considers contract termination or reduced reliance on volunteers. Accessibility failures (>1 wheelchair user cannot be transported within <45 min) trigger immediate review and extra wheelchair-capable taxi deployment. If average response time exceeds 45 minutes for >1 consecutive alert day, incident commander convenes emergency review with transport lead, volunteers and taxi operator within 24 hours to identify causes and corrective actions; failure to achieve <45 min within 3 days escalates to Steering Committee as gate risk.
### 6. Home Kit Distribution, Installation and Quality Assurance Group

**Rationale for Inclusion:** The home-kit program (shading, fans, thermometers, hydration supplies) reaches 2,000 high-risk homes (top-floor, poorly insulated, elderly, isolated). This group manages procurement, targeting, installation scheduling, handyperson vetting, and quality checks (particularly fan-safety). Installation must complete by Month 7.3 (2027-05-17) to benefit from the first heat events. The group also tracks equity metrics (coverage by neighborhood, housing type, age), manages supply logistics, and ensures GDPR compliance in the targeting process (no unauthorized access to vulnerability scores).

**Responsibilities:**

- Develop and maintain household-targeting rubric (score 0-100: top-floor 30 pts, age ≥75 25 pts, living alone 20 pts, pre-1980 15 pts, no AC 10 pts; ≥60 for kit eligibility) based on Consent-Light Identification Routes data
- Identify eligible households from enrolled high-risk residents and partner lists; verify consent before approaching; generate installation schedules by neighborhood and housing block
- Procure cooling kits (exterior shading, reflective blinds, fans, thermometers, hygrometers, hydration supplies) with 30–40% first call-off by Month 1.2 (2026-11-14); stagger deliveries to meet Feb, Mar, Apr, Jun targets
- Recruit, vet and train handypersons (target 10 FTE for Months 4–7 = 2027-02-08 to 2027-05-08) in installation safety, fan-use guidance and building-code compliance by Month 3 (2027-01-08)
- Schedule and execute home installations with consent, accessibility accommodation (no multi-floor climbs for elderly) and safety checks (fan testing, shading wind resistance, electrical safety); provide written guidance to residents on safe use (translated)
- Conduct quality-assurance inspections of 10–20% of installations (random sample + risk-based high-floor sites) by external QA auditor; log any issues and corrective actions within 5 days
- Track and report equity metrics: % installed by neighborhood deprivation index, housing type (social vs. private rental vs. owner-occupied), age band and language; identify and close coverage gaps by June

**Initial Setup Actions:**

- Obtain partner contact lists (housing associations, social services) and enrolled high-risk residents by Month 0.5 (2026-10-23)
- Finalize household-targeting rubric and validate against sample population by Month 1 (2026-11-08); check GDPR compliance of rubric (no sensitive data stored outside consent scope)
- Issue procurement specs for kits by Month 0.8 (2026-11-01); place first call-off order (30–40%) by Month 1.2 (2026-11-14); arrange storage by Month 3 (2027-01-08)
- Identify and vet handyperson service providers or recruit individual handypersons (employment vs. contract) by Month 2.5 (2026-12-23); conduct safety and installation training by Month 3 (2027-01-08)
- Design home-installation packet: consent form, scheduling letter, safety guidance, installation checklist and follow-up; translate into 4–6 languages by Month 2 (2026-12-08)

**Membership:**

- Home Kit Lead / Installation Coordinator (1 FTE, reports to incident commander)
- Procurement and logistics coordinator (0.5 FTE, shared with general procurement)
- Handyperson supervisor (1 FTE, manages 10-person team)
- Quality-assurance auditor (0.5 FTE external or internal, spot-check inspections)
- Equity analyst or data coordinator (0.5 FTE, tracks coverage metrics)
- Housing-sector representative from a key partner (advisory, site-access and landlord-cooperation facilitation)

**Decision Rights:** Home Kit Lead approves: household eligibility assessments per the agreed rubric; installation scheduling and route optimization; handyperson assignments and rescheduling; quality-assurance findings and corrective-action authorization (up to €500 per fix). Cannot alter the targeting rubric or equity metrics definitions without Steering Committee (data-governance and fairness decision). Cannot commit >€5k for emergency kit procurement or expedited delivery without incident commander. Handyperson supervisor approves: work scheduling, overtime, tool and supply management, and preliminary safety checks before formal QA. QA auditor has veto over any installation deemed unsafe (fan misuse, shading wind-resistance failure, electrical hazard); veto escalates immediately to Home Kit Lead and incident commander for remediation or re-do.

**Decision Mechanism:** Home Kit Lead makes routine targeting, scheduling and quality decisions. Eligibility disputes (e.g., a resident just below the 60-point rubric threshold but clearly vulnerable) are escalated to Home Kit Lead with partner input; lead decides with documented rationale (e.g., 'approved despite 58 points due to note from GP of severe cardiac disease'). Equity coverage gaps (e.g., <5% of kits in highest-deprivation neighborhoods by Month 6 = 2027-04-08) trigger review by home kit lead and equity analyst; if closure plan is inadequate, escalates to incident commander and outreach lead for outreach-targeted recruitment into the target neighborhoods. Handyperson safety or performance issues escalate to handyperson supervisor; if unresolved within 24 hours, escalate to home kit lead.

**Meeting Cadence:** Weekly during Months 0–3 (2026-10-08 to 2027-01-08, procurement and planning): Mondays 14:00 (60 min) for rubric finalization, procurement specs and handyperson recruitment. Weekly during Months 4–7 (2027-02-08 to 2027-05-08, installation): Mondays 10:00 (90 min) covering scheduling, supply delivery, handyperson deployment, quality-assurance findings and equity-coverage tracking. Bi-weekly during Months 8–11 (2027-06-08 to 2027-09-08, post-installation): Mondays 14:00 (45 min) for final coverage reports, lessons learned and follow-up surveys.

**Typical Agenda Items:**

- Targeting and eligibility: rubric validation, household-list generation, consent status by partner, enrollment growth vs. installation targets
- Procurement and logistics: kit delivery schedules, storage utilization, backup supplier status, lead-time risks, cost tracking
- Handyperson recruitment and training: hiring progress, training completion, safety protocols, incident reports, performance feedback
- Installation scheduling and execution: weekly installation targets, neighborhoods covered, appointment confirmations, accessibility accommodations (e.g., elderly mobility limits), resident feedback
- Quality assurance: inspection results, defect rates, corrective-action log, safety incidents, re-do or remediation completion
- Equity metrics: installations by neighborhood deprivation, housing type, age band, language; comparison to targets; coverage-gap analysis and closure plans
- Follow-up and resident satisfaction: post-installation surveys, safe-use guidance effectiveness, complaints or misuse reports

**Escalation Path:** Supply-chain delays (first call-off delivery >2 weeks late) escalate to procurement coordinator and incident commander; backup suppliers triggered if delay exceeds 3 weeks. Handyperson recruiting shortfalls (fewer than 7 of 10 FTE recruited by Month 3 = 2027-01-08) escalate to home kit lead; contingency: contract temporary labor or reduce installation targets. Installation-pace shortfalls (trajectory shows <80% completion by Month 7 = 2027-05-08) trigger schedule tightening and overtime authorization by home kit lead; if still on track to miss target, escalates to incident commander. Quality-assurance failures (>10% of inspected installations unsafe) trigger remedial training and re-work; if defect rate persists, handyperson supervisor and affected providers are reviewed for replacement. Equity-coverage gaps (highest-deprivation neighborhoods <30% of target by Month 6 = 2027-04-08) escalate to outreach lead for additional targeted enrollment; if closure plan unavailable within 1 week, escalates to incident commander and Steering Committee as equity risk.
### 7. Legal, GDPR Compliance and Data Protection Group

**Rationale for Inclusion:** This is a high-risk program handling personal data from intermediary partners, consent protocols, and partner data-processing agreements. GDPR compliance is a hard constraint; any significant breach or challenge could halt outreach mid-season. This group ensures pre-cleared data-processing agreements with each partner type, audits partner compliance mid-season, manages breach notification, and oversees data retention and deletion. It is a specialized assurance body reporting to the Steering Committee and supporting the incident commander's operations.

**Responsibilities:**

- Engage GDPR legal counsel by Month 0.5 (2026-10-23); obtain legal opinion on intermediary-held list model and consent basis by Month 1 (2026-11-08)
- Draft template data-processing agreements (DPAs) for housing associations, social services, NGOs and pharmacies specifying lawful basis (public task + consent hybrid typical), data scope (contact details and risk flags only, no health records), retention (one season, delete after), and breach notification (<48 hours)
- Obtain partner sign-off on DPAs by Month 1.5 (2026-11-23); brief partner staff on GDPR obligations and confidentiality by Month 2 (2026-12-08); document training attendance
- Conduct data-protection impact assessment (DPIA) screening for the program; if higher risk (unlikely given intermediary model), commission full DPIA by Month 1.5 (2026-11-23)
- Audit partner GDPR compliance at Month 9 (2027-07-08): spot-check consent records (≥20 files per partner), staff confidentiality training logs, data-retention status and any disclosed breaches; issue audit report with corrective-action requests
- Establish breach-reporting hotline and incident log; if breach reported, assess impact within 24 hours and notify data-protection authority within 48 hours if required (>100 individuals at high risk); notify affected residents within 5 days
- Oversee data deletion at season end (by October 31, Month 13 = 2027-11-08, unless re-consent obtained)

**Initial Setup Actions:**

- Retain GDPR specialist legal firm by Month 0.5 (2026-10-23) (estimated cost €20k–30k for advice + DPA drafting)
- Brief legal firm on intermediary-held list model, partner types, expected data types and retention needs by Month 0.7 (2026-10-29)
- Receive and review legal opinion on lawful basis and DPA template by Month 1 (2026-11-08); incorporate feedback and customize DPAs for each partner type
- Distribute DPA drafts to partners by Month 1.3 (2026-11-17) with 2-week sign-off target; resolve partner queries by Month 1.5 (2026-11-23)
- Conduct DPIA screening by Month 1 (2026-11-08); commission full DPIA if required by Month 1.3 (2026-11-17)

**Membership:**

- Legal and GDPR Lead (0.5–1 FTE, reports to Steering Committee and incident commander, likely shared with municipal legal department)
- GDPR specialist legal counsel (external retainer, available for advice on breaches, interpretation disputes)
- Data-protection officer (if the city has a DPO; else legal lead assumes this role)
- Partner representative from each partner type (advisory, DPA compliance and feedback)

**Decision Rights:** Legal lead approves: final versions of DPAs and partner briefing materials; DPIA screening and determination (full DPIA needed or not); breach-notification decisions (authority notification required or not); data-retention and deletion schedules; staff confidentiality training content and verification; audit findings and corrective-action requests to partners. Cannot approve operational decisions that have legal implications (e.g., change to data scope, alteration of lawful basis) without consulting GDPR legal counsel. Cannot override GDPR counsel's legal opinion; if counsel is consulted and gives advice, legal lead must follow unless Steering Committee overrides (documented with funder notification). Partners cannot opt out of DPA compliance; non-compliance is an enforcement matter handled by legal lead with incident commander escalation.

**Decision Mechanism:** Legal lead makes routine GDPR and data-protection decisions (training, audit scheduling, breach assessment). GDPR counsel and legal lead consult on novel or contentious issues (e.g., expanded data scope, new partner type); legal counsel advises, legal lead decides with incident commander. Partner DPA disputes (e.g., partner claims data scope is too broad) are addressed first by legal lead with partner; if unresolved, escalates to incident commander and then Steering Committee if necessary. Breach investigations are led by legal counsel with legal lead oversight; incident commander and Steering Committee kept informed.

**Meeting Cadence:** Weekly during Months 0–2 (2026-10-08 to 2026-12-08, setup phase): Thursdays 10:00 (60 min) for legal opinion development, DPA drafting and partner briefing preparation. Bi-weekly during Months 3–8 (2027-01-08 to 2027-06-08): Thursdays 14:00 (45 min) for compliance monitoring, staff training verification and incident log review. Monthly during Months 9–12 (2027-07-08 to 2027-10-08, audit and closure): Thursdays 14:00 (45 min) for audit findings, partner corrective actions and data-deletion planning.

**Typical Agenda Items:**

- GDPR counsel advice: interpretation of lawful basis, DPA compliance, partner questions, novel scenarios or disputes
- DPA status: partner sign-off progress, outstanding negotiations, execution deadlines
- Partner compliance: training attendance logs, data-access controls, file-security verification, incident-awareness surveys
- DPIA and risk assessment: screening results, full DPIA scope (if required), residual risks, mitigation actions
- Breach management: incident log review, breach reports received, assessment and authority-notification decisions, affected-resident notification
- Staff and partner training: confidentiality-briefing attendance, training content updates, re-training scheduling
- Data deletion and retention: end-of-season deletion schedule, resident opt-in renewals for Year 2 (if applicable), data-archival for evaluation (stripped of identifiers)

**Escalation Path:** Novel or contentious GDPR issues escalate to GDPR legal counsel; counsel's written advice is binding on legal lead unless overridden by Steering Committee (with funder and data-protection authority notification). Serious breaches (>100 residents, health data exposed, or deliberate misuse) escalate immediately to legal counsel, legal lead and incident commander; Steering Committee notified; data-protection authority notified within 48 hours if required by law. Partner non-compliance (e.g., unauthorized contact of residents, data breach, failure to train staff) is first addressed by legal lead with incident commander; if unresolved within 10 days, escalates to Steering Committee for enforcement (contract termination, remedial supervision, or referral to data-protection authority). Any request to expand data scope or alter consent basis escalates to legal counsel and Steering Committee for approval.
### 8. Evaluation, Data Quality and Playbook Documentation Group

**Rationale for Inclusion:** Month 12 (2027-10-08) deliverables include a repeatable Heat Response Playbook, a scaling cost model and a credible evaluation report on heat-related EMS calls, ED visits and mortality. This group ensures baseline data quality (Months 0–1 = 2026-10-08 to 2026-11-08), coordinates the evaluation design with a university partner, tracks outcome data throughout the season, produces the Month 4 (2027-02-08) gate-review evidence, and synthesizes lessons learned into the playbook. It is a specialized analytical group reporting to the Steering Committee and supporting the incident commander's after-action reviews.

**Responsibilities:**

- Obtain or estimate baseline heat-related EMS calls and ED visits and excess mortality data from hospitals/EMS; conduct data-quality audit by Month 1 (2026-11-08); agree on heat-attribution coding with clinical partners by Month 2 (2026-12-08)
- Negotiate a data-processing agreement with hospitals, EMS and primary care for daily aggregate heat-related counts (no identifiable records); establish a secure data-sharing method (email, SFTP, API) and a daily 10:00 a.m. delivery target by Month 1 (2026-11-08)
- Conduct a 2-week data-validation pilot in April (Month 6 = 2027-04-08) to test reporting process and identify IT/coding gaps before the season; agree on a fallback method (weekly if daily unavailable) by Month 1.5 (2026-11-23)
- Define evaluation design: baseline vs. pilot heat-days (post-stratified by temperature or matched district comparisons), aggregate EMS/ED counts, excess mortality estimation with temperature adjustment and confidence intervals; pre-specify analysis plan by Month 3 (2027-01-08)
- Convene a university evaluation partner under a data-processing agreement; partner conducts independent analysis and publishes findings regardless of direction by Month 12 (2027-10-08); provides a pre-registration of the analysis plan by Month 3 (2027-01-08)
- Compile all operational-performance data (gate metrics: center hours, outreach success, transport time; equity metrics: coverage by neighborhood and housing type; staffing and budget data) into a project database by Month 4 (2027-02-08) for gate review and later playbook costing
- Draft the Heat Response Playbook from Month 8 (2027-06-08) onward; include SOPs, decision trees, checklists, procurement specs, staffing plans, partner MOUs, cost breakdowns and lessons learned; conduct peer-city review by Month 11 (2027-09-08); finalize by Month 12 (2027-10-08)

**Initial Setup Actions:**

- Request baseline EMS and mortality data from hospitals and EMS by Month 0 (2026-10-08); establish data custodian role and request timelines
- Conduct rapid baseline data-quality audit (completeness, coding consistency, signal reliability) by Month 1 (2026-11-08); document any limitations
- Identify a university or public-health research partner (estimated cost €50k–80k for evaluation services); draft a research-collaboration agreement and data-processing agreement by Month 0.8 (2026-11-01)
- Design and agree evaluation plan with university partner and hospital/EMS clinical leads by Month 2.5 (2026-12-23); finalize by Month 3 (2027-01-08)
- Establish a secure data-sharing infrastructure (encrypted email or SFTP) with hospitals/EMS for daily aggregate counts; begin daily data collection by Month 1.8 (2026-12-02)
- Develop a playbook outline and assign sections by Month 7 (2027-05-08); begin drafting from Month 8 (2027-06-08) with lessons captured in real-time

**Membership:**

- Evaluation and Playbook Lead (0.5–1 FTE, reports to Steering Committee, may be shared with municipal public health or contracted to evaluation partner)
- University evaluation partner: epidemiologist or health-services researcher (lead analyst and publication lead)
- Data analyst (0.5–1 FTE municipal or partner staff, data extraction, quality assurance, database management)
- Health-system data custodian (hospital or EMS representative, provides baseline and ongoing outcome data)
- Incident commander and operations team (source of operational-performance data and lessons learned)

**Decision Rights:** Evaluation Lead approves: baseline data-quality assessments, coding-agreement decisions with clinical partners, evaluation-design specification and analysis-plan finalization with university partner. Cannot alter the fundamental comparison design or attribution methodology without Steering Committee and university partner approval (analytical integrity). Cannot release preliminary or final evaluation findings without university partner review and approval (to ensure scientific integrity). Operational groups approve what data gets extracted and shared for evaluation (performance metrics, program costs); cannot be forced to share data outside the agreed scope without legal/GDPR clearance. University partner has full editorial autonomy over the final evaluation report; findings cannot be suppressed or reframed by the municipality.

**Decision Mechanism:** Evaluation Lead and data analyst make routine data-quality and extraction decisions. Novel methodological questions (e.g., how to account for weather variation in heat-death attribution) are escalated to the university partner for expert advice. Data-collection failures or quality issues are escalated to health-system data custodian with 5-working-day remediation target; if unresolved, escalates to incident commander and Steering Committee for leverage. The university partner retains full autonomy over analytical decisions (statistical methods, interpretation of results); if the city disagrees with a finding, the disagreement is documented and published alongside the main report, but the finding is not suppressed.

**Meeting Cadence:** Monthly during Months 0–3 (2026-10-08 to 2027-01-08, design): Fridays 14:00 (60 min) for baseline-data review, partner agreement and evaluation-plan finalization. Bi-weekly during Months 4–7 (2027-02-08 to 2027-05-08, data collection): Fridays 10:00 (45 min) for data-quality checks, coding-process updates and gate-evidence compilation. Weekly during Months 8–11 (2027-06-08 to 2027-09-08, playbook drafting): Fridays 14:00 (60 min) for section drafting, lessons-capture, cost-model development and peer-city review. Monthly during Month 12 (2027-10-08): Final report, playbook and deliverable finalization.

**Typical Agenda Items:**

- Baseline data: completeness checks, coding agreement with clinical partners, historical patterns and seasonality, confidence-interval estimates for small areas
- Data-sharing infrastructure: hospital/EMS system testing, daily-count delivery confirmation, data-quality monitoring, holiday/staffing coverage for data delivery
- Evaluation design: comparison methodology, temperature adjustment, statistical power, sample-size sufficiency, pre-registered analysis plan, limitations and caveats
- Gate evidence: operationalization of the three gate metrics (center hours, outreach success, transport time), data-collection protocol, drill vs. real-event evidence weighting
- Ongoing outcome data: daily heat-related EMS and ED counts, weekly trend analysis, seasonal patterns, attribution to program activities (attribution challenges and caveats)
- Operational data compilation: center-hours tracking by site, outreach-attempt and success-rate log, transport-request and response-time log, kit-installation progress, staffing and budget by category
- Equity analysis: coverage by neighborhood deprivation, housing type, age band, language; comparison to target groups; outlier neighborhoods with low coverage
- Playbook development: section completion, lessons-learned capture from operations, cost-model development (unit costs per person, per center-hour, per kit), replicability guidance for peer cities
- University partner coordination: progress on analysis, preliminary findings, final-report timeline, data-archival and secondary-use agreements

**Escalation Path:** Baseline-data quality issues (e.g., <80% of heat-related cases are coded consistently) escalate to health-system data custodian and incident commander for remediation; if unresolved, data limitations are documented in the final report and caveats added to gate-review evidence. Data-sharing failures (e.g., hospital cannot provide daily counts due to IT constraints) escalate to Steering Committee for negotiation or fallback method (weekly aggregate). Evaluation-design disputes (e.g., comparison group selection methodology contested by partners) are resolved by the university partner's expert judgment; if the city disputes a decision, documented disagreement is published alongside the final report. Gate-evidence interpretation disputes (e.g., drill results vs. real-event data weighted differently) are decided by the Steering Committee with Evaluation Lead and university partner input. Playbook draft-section disputes (e.g., partners disagree with how their role is documented) are escalated to incident commander for facilitated resolution; final authority rests with Evaluation Lead and playbook editor, who may include dissenting partner commentary in an appendix.