## 1. Cool-Season Gate Measurement & Funder Evidence Acceptance

The Month 2 (2026-12-08) and Month 4 (2027-02-08) gates fall in the cool season with no real heat events. Funder acceptance of drill-based evidence is undocumented and is the single highest-risk assumption. If the funder rejects drills at Month 4 (2027-02-08), a €200–400k cash gap emerges, forcing mid-season cuts that harm residents during peak summer. This must be validated immediately before any other work proceeds.

### Data to Collect

- Written funder confirmation that drill-based evidence is acceptable for Month 2 (2026-12-08) and Month 4 (2027-02-08) gates
- Funder's written acceptance of the partial-release rule (€750k at Month 4 = 2027-02-08 if gates are unmeasurable, remainder after Month 5 = 2027-03-08 re-test)
- Funder's definition of 'sufficient evidence' (e.g., minimum drill scale: transport requests, outreach attempts, center-hour activations)
- Contingency funding or credit-line commitment (€200–400k) if tranche-2 release is delayed
- Funder's policy on real-event validation: when would gates be re-tested if cool June–July occurs?

### Simulation Steps

- Create a written 'Funder Communication Protocol' document specifying drill criteria, partial-release thresholds and contingency triggers; share with funder by email with 5-day response deadline (Month 0.2 = 2026-10-14)
- Schedule a synchronous video call (or in-person meeting if funder is local) by Month 0.3 (2026-10-17) to walk through the cool-season timing, drill protocol draft, and €200–400k cash-gap scenario; record funder's verbal position and follow up with written summary within 24 hours
- Use a simple decision-tree flowchart (drill evidence accepted? → proceed to Month 1 = 2026-11-08. Evidence rejected? → escalate to mayor's office, negotiate alternative funding) to clarify contingencies and distribute to all stakeholders

### Expert Validation Steps

- Engage the funding organization's program officer (or their supervisor if the officer is hesitant) to confirm in writing that drill evidence meets their evidence standards; require explicit sign-off from someone with budget-authorization authority, not just program staff
- If the funder is a national or EU fund, consult the funder's published guidance on 'proof of concept' and 'pilot gate evidence' to identify any precedent for drill-based validation in other similar programs
- If the funder remains resistant, request an in-principle decision letter that allows the program to proceed with operational preparedness (Month 2 = 2026-12-08 gate) while deferring the scale-gate financial decision to Month 5 (2027-03-08) based on real-event data; this trades some timeline risk for certainty

### Responsible Parties

- Project Manager/PMO Lead: draft and circulate funder-communication protocol
- Incident Commander: participate in funder discussion and confirm political/operational feasibility of partial-release scenario
- Funder's program officer: provide written responses and approve alternative funding pathways if needed
- Finance/CFO liaison: quantify the €200–400k cash-gap scenario and confirm municipal credit-line availability

### Assumptions

- **High:** Funder will accept drill-based evidence for cool-season gates because operational readiness is measurable and real-event validation is unavoidable given the seasonal timing. Funder views this as a replicable risk for other pilot cities and has precedent (e.g., EU disaster-response pilots, climate-adaptation programs) for evidence-light early gates.
- **High:** A partial-release rule (€750k at Month 4 = 2027-02-08, remainder after May re-test) is financially and politically acceptable because it de-risks the program: the city delivers operationally, and the funder retains funding leverage to ensure quality. Both parties have aligned interest in scaling only if gates are truly met.
- **Medium:** Municipal credit-line or EU contingency funding of €200–400k is accessible within 48 hours if a tranche-2 release is withheld, allowing the city to bridge operations through June without immediate cuts. Historical precedent: municipalities can draw credit lines for cash-flow timing gaps.
- **Medium:** Funder defines 'sufficient drill evidence' as: ≥100 simulated transport requests, ≥200 outreach contact attempts, ≥2,000 center-hour activations, and all after-action items closed. These thresholds are achievable in a month-long drill protocol.

### SMART Validation Objective

By Month 1 (2026-11-08), obtain written funder confirmation that: (1) drill-based evidence satisfies Month 2 (2026-12-08) and Month 4 (2027-02-08) gates if gates are measurable; (2) unmeasurable evidence triggers the €750k partial release at Month 4 (2027-02-08) and re-test at Month 5 (2027-03-08); (3) a contingency funding mechanism (credit line, clawback, or EU grant) is in place to cover any cash gap >€160k if tranche-2 is delayed beyond Month 4 (2027-02-08). Document in a signed amendment to the funding agreement.

### Notes

- This is the single gate-release risk. All other risks (procurement, staffing, partner engagement) are operationally manageable; but if the funder withholds €1.5M at Month 4 (2027-02-08) due to evidence rejection, the program has no recourse within the current budget.
- Schedule this conversation for Month 0.2 (2026-10-14), before procurement and hiring begin. A 'no' from the funder at Month 4 (2027-02-08) means 4 months of wasted setup costs and broken promises to residents and partners.
- Document everything in writing. Verbal assent from the funder is not sufficient; a signed amendment to the funding agreement is required.


## 2. Procurement Lead-Time Validation & Supplier Backup Activation Triggers

Cooling kits (shading, fans, thermometers) must be ordered by Month 1.2 (2026-11-14) and delivered 40–50% by Month 4 (2027-02-08) to enable installation by Month 6 (2027-04-08) before the first heat events in May–June. EU suppliers typically require 6–8 weeks for mass-produced items. If the primary supplier slips by 4 weeks, kits arrive in June, missing the peak-risk May period and breaking the enrollment promise. No supplier relationships exist yet; this is a blind spot. Validation must occur by Month 0.8 (2026-11-01) to allow replan.

### Data to Collect

- Detailed supplier quotes and firm lead-time commitments for kits (shading, fans, reflective blinds, thermometers, hydration supplies) from ≥3 primary vendors and ≥2 backup vendors
- Expedited-delivery cost premiums (% above standard price for 2–4 week acceleration) and minimum-order quantities per supplier
- Supplier capacity (available stock vs. custom-build timeline) and production constraints during Q4–Q1 (holiday season, Chinese New Year for Asian suppliers)
- Warehouse/interim-storage options and costs for 600–800 units staging area by Month 1.5 (2026-11-23)
- Logistics and duty/tariff information if kits are imported; border delays during Q4 are common

### Simulation Steps

- Issue a detailed RFQ (Request for Quotation) to 5–8 regional and national suppliers by email by Month 0.3 (2026-10-17), specifying exact quantities (600–800 units for first tranche), quality specs, delivery address, and deadline for quote (5 business days). Use a standardized RFQ template with columns for supplier name, lead time (days), price, expedite-cost %, and available stock.
- Create a supplier-scoring spreadsheet (price, lead time, backup availability, geographic risk) and rank vendors; select top primary and 2 backups by Month 0.8 (2026-11-01). Model supply-chain scenarios: (a) primary supplier on-time, (b) primary slips 2 weeks, (c) primary slips 4+ weeks. For each scenario, calculate backup-activation cost and delivery date shift.
- Run a delivery-timeline simulation: if first order placed Month 1.2 (2026-11-14), when do kits arrive under each scenario? Create a Gantt chart showing planned vs. stress-test timelines; identify the 'point of no return' date (by which backup must be activated to retain May delivery).

### Expert Validation Steps

- Contact 2–3 municipal procurement officers from comparable EU cities (Valencia, Barcelona, Italian cities) who have run home-kit distribution programs; ask for their supplier lead-time experience and any single-source-failure incidents they encountered. Document lessons learned and apply to Castellón's vendor selection.
- Engage a procurement specialist (€5–8k contract, 2–3 week engagement) to pre-qualify all identified suppliers, verify business registration and financial stability, and confirm that they can support emergency activation (48-hour order acceptance). Specialist delivers a 'supplier risk scorecard' rating each vendor on reliability, capacity-surge capability, and communication responsiveness.
- Request written commitment letters from primary and backup suppliers (by Month 1 = 2026-11-08) specifying: (a) firm price quote, (b) committed delivery date for ≥600 units, (c) 'emergency activation' trigger (city can order additional 200–300 units at 7-day notice with expedite fee capped at X%), and (d) penalty clauses if supplier misses committed date.

### Responsible Parties

- Procurement lead: issue RFQs, track responses, score suppliers, negotiate backup agreements, maintain weekly delivery dashboard
- Finance/budget officer: confirm expedite-cost authorization (up to €200k premium) and interim-storage budget allocation
- Facilities/public works: identify and contract interim storage (500–800 m², lockable, climate-controlled, accessible for unloading)
- Primary and backup suppliers: provide firm quotes, delivery schedules, and emergency-activation agreements signed

### Assumptions

- **High:** At least 2–3 credible suppliers exist in Spain or Portugal that can provide shading, fans, and thermometers at the required volume (600–800 units) within 6–8 weeks. Suppliers are willing to offer emergency-acceleration options for a 10–15% cost premium.
- **Medium:** Interim storage of 600–800 units (≈60–80 m² footprint, 2–3 pallets) is available within the municipal facility network at minimal cost (≤€500/month). Storage is secure, climate-controlled to prevent mold/humidity damage, and accessible for staged delivery to installation sites.
- **High:** Expedite-cost premiums for accelerated delivery are ≤15% (estimate: 10–15% above standard price). If actual expedite costs exceed 20%, the €200k budget buffer may be insufficient and cost-sharing with home-kit scope reduction becomes necessary.
- **Medium:** First-tranche orders can be placed by Month 1.2 (2026-11-14) without full specification approval from the city council or other governance bodies. Municipal procurement authority can issue orders directly for items <€100k per supplier or via existing framework agreements.

### SMART Validation Objective

By Month 1.2 (2026-11-14), confirm in writing that: (1) primary supplier can deliver 600–800 units by February 2027 at a fixed price with penalty clauses; (2) 2 backup suppliers are pre-qualified and will activate within 7 days of notice if primary supplier slips >2 weeks; (3) interim storage (≥200 units) is secured at a municipal facility by Month 1.5 (2026-11-23); (4) all tranche-1 kit orders are placed by Month 2 (2026-12-08) with delivery confirmations locked in. Track against timeline weekly; trigger backup activation immediately if primary supplier misses any intermediate milestone by >7 days.

### Notes

- This data collection must complete by Month 1 (2026-11-08) to allow a 2-week replan cycle before orders are placed at Month 1.2 (2026-11-14). Any discovery of supply-chain risk later will force immediate contingency spending or scope cuts.
- The €150–250k 'taxi-only fallback' is unavailable if kits also slip, because both are competing for budget: if transport costs rise by €150k AND kits are delayed (forcing expedite premium of €80–120k), the combined hit is €230–370k, exceeding the €160k available tranche-1 contingency by €70–210k.
- Build in a 10–15% buffer stock (100–200 extra units) in the first tranche to account for damage in transit, installation errors, or emergency replacement needs.


## 3. Volunteer Driver Recruitment, Vetting & Retention Pipeline Validation

The 45-minute transport-time gate depends on 40 volunteer drivers being vetted and operationally ready by Month 2–3 (2026-12-08 to 2027-01-08). Vetting includes background checks (10–14 days via police), insurance verification (7–10 days), and safeguarding training (3 hours per person). No recruitment partnership, no intake method, and no retention strategy are documented. If recruitment falls short of 20 by Month 1.5 (2026-11-23), the taxi retainer must be scaled up immediately (+€40–80k), forcing home-kit scope cuts from 2,000 to 1,500. This is a second-order risk with high financial impact; validation is critical by Month 1 (2026-11-08).

### Data to Collect

- Recruitment partnership confirmations from ≥3 organizations (job centers, faith communities, NGO networks, retired-professional associations, universities) specifying intake procedures and expected volunteer yield (e.g., 'job center expects 15 applications/week for volunteer transport roles')
- Police background-check turnaround time and cost (per person); clarify holiday season delays (Q4 typically slower)
- Insurance requirements and available products (volunteer vehicle liability insurance, cost per driver, coverage limits)
- Baseline volunteer attrition rate from comparable municipal programs in Spain or EU (expected 15–25% by mid-season)
- Completed vetting pipeline as of Month 1.5 (2026-11-23): number of recruits in intake, vetting, training and fully-operational status

### Simulation Steps

- Launch volunteer recruitment immediately (Month 0.1 = 2026-10-11) with a public call via job centers, faith organizations, municipal website and social media, specifying: role (flexible alert-day driver), time commitment (10–30 h/month average), pay (€12–15/h), and training provided. Set initial intake deadline Month 1.5 (2026-11-23) targeting 50–60 applications.
- Model the vetting pipeline as a flowchart with weekly cohorts (5–8 recruits per cohort starting Month 0.5 = 2026-10-23): background check (2 weeks turnaround), insurance verification (1 week), 2-hour safeguarding training (1 week), written test, and operational sign-off. Calculate expected yield: 60 recruits → ≈50 pass vetting → ≈40 active (20% early attrition) by Month 2 (2026-12-08).
- Track pipeline weekly on a public dashboard (numbers in intake, in vetting, in training, fully-approved) and flag any cohort that falls >1 week behind. Establish a decision rule: if <15 are fully vetted by Month 1.5 (2026-11-23), immediately activate the taxi-retainer scale-up trigger (increase capped offer from €80k to €100–120k and re-negotiate with operator for confirmed ≥15 vehicles).

### Expert Validation Steps

- Contact 2–3 municipal volunteer-coordinator leads from Valencia, Barcelona, or other Spanish cities with active volunteer-driver programs; ask about: (a) typical recruitment yield (applications-to-vetted ratio), (b) vetting timeline and bottlenecks, (c) mid-season attrition patterns, (d) safeguarding incidents encountered. Document lessons and apply to Castellón's planning.
- Engage a specialist HR/recruitment consultant (€8–12k contract, 2–3 weeks) to design the recruitment campaign, identify partnership contacts, and provide a vetted list of 5+ recruitment organizations with confirmed capacity to support the volume target. Consultant delivers a 'recruitment risk scorecard' assessing each partner's ability to deliver on intake promises.
- Request written commitments from recruitment partners (job centers, faith organizations) specifying monthly intake target and current volunteer-driver candidate pipeline (e.g., 'job center has 10 active volunteer-driver candidates available immediately'). Verify they have capacity to promote the program and conduct intake screening.

### Responsible Parties

- HR/Recruitment Coordinator: manage recruitment campaign, partner relationships, intake coordination, vetting tracking
- Volunteer Safeguarding Lead: conduct vetting reviews, training delivery, incident tracking, retention outreach
- Police/background-check liaison: communicate vetting turnaround times and manage batch submissions
- Insurance broker: verify coverage options and cost per driver
- Recruitment partner organizations: deliver intake candidates and conduct preliminary screening

### Assumptions

- **High:** Recruitment partners (job centers, faith organizations, NGOs) can supply 50–60 volunteer-driver candidates by Month 1.5 (2026-11-23) from existing networks and media promotion. Yield from applicants-to-vetted is ≈70% (42 approved from 60 applicants), and early attrition by Month 2 (2026-12-08) is ≈20% (leaving 33 operationally available).
- **Medium:** Police background checks complete within 10–14 days per person under normal circumstances; Q4 delays (holidays, staffing) add 1–2 weeks. Batch submissions (weekly cohorts of 5–8) are more efficient than individual submissions.
- **Medium:** Volunteer vehicle insurance is available at ≤€500/year per driver, covering liability and personal injury. Municipal insurance policy may cover volunteers under an endorsement (cost TBD with broker).
- **High:** Mid-season volunteer attrition is 15–25%, with peak loss during July–August (multi-day heat waves, fatigue). A 40-volunteer target requires 50–52 recruits at Month 0 (2026-10-08) to sustain 40 active through Month 11 (2027-09-08).

### SMART Validation Objective

By Month 1.5 (2026-11-23), confirm that: (1) ≥15–20 volunteer drivers are fully vetted and trained, in a pilot-ready cohort; (2) ≥30–35 recruits are in the vetting/training pipeline with confirmed completion dates by Month 2.5 (2026-12-23); (3) recruitment partners have signed commitments to continue intake and are on track to deliver ≥40 recruits by Month 3 (2027-01-08); (4) if <15 are fully vetted by this date, a written contingency decision is made to scale the taxi retainer and reduce home-kit scope. Conduct a 'recruitment stress test' (simulate dispatch demand with only 20 volunteers) at Month 2 (2026-12-08) and measure mean pickup time under fatigue.

### Notes

- If recruitment falls short, the consequences are immediate and costly: <15 volunteers by Month 1.5 (2026-11-23) → trigger taxi-retainer scale-up (+€40–80k) → reduce home kits from 2,000 to 1,000–1,500 → lower equity reach and visible program credibility. This is a 'canary in the coal mine' for the whole program.
- Safeguarding vetting (criminal-record check, interview, references) is non-negotiable. Street-contact roles and transport for mobility-limited residents require high trust. Any corner-cutting on vetting exposes the city to liability and reputational damage.
- Build in a 20–30% reserve pool of vetted-but-inactive volunteers (15–20 people on a standby roster) activated only on Level 3 alerts or if active roster falls <25. This requires recruiting 60–70 total candidates to secure 40–50 active + 15–20 reserve.


## 4. GDPR Compliance & Data-Processing Agreement Validation

The intermediary-held-list model (housing associations, social services, NGOs, pharmacies) is central to GDPR safety but lacks explicit legal validation. Without written GDPR counsel opinion and signed data-processing agreements (DPAs) by Month 1.5 (2026-11-23), partner engagement will stall, and the city faces regulatory risk (AEPD investigation, €100k+ fines). If a partner withdraws mid-season citing GDPR concerns, outreach reach drops by 10–20%, failing the 60% contact-success gate. Legal clarity must be obtained by Month 1 (2026-11-08) to unlock partner recruitment and training.

### Data to Collect

- Written GDPR legal opinion from a specialist law firm confirming that the intermediary-held-list model complies with GDPR Article 6 (lawful basis: consent or public task) and Spanish LOPDGDD Article 9
- Determination of whether the city is a joint data controller (Article 26 joint-controller agreement required) or data subject; clarity on processor relationships for each partner type
- Template data-processing agreements (DPAs) for housing associations, social services, NGOs, and pharmacies, specifying: data types, lawful basis, retention period, breach notification, audit rights
- Data Protection Impact Assessment (DPIA) screening or full DPIA for the health-data loop (hospital/EMS aggregate counts), assessing re-identification risk and controls
- Partner GDPR compliance readiness (do partners have existing data-governance policies, staff training, incident-reporting procedures?) assessed via a brief survey

### Simulation Steps

- Engage a GDPR specialist law firm (€20–30k contract, 4–6 weeks engagement) by Month 0.5 (2026-10-23) with a detailed brief on the intermediary model, partner organizations, and data types. Request delivery of: (1) legal opinion memo (2–3 pages) on lawful basis and controller status, (2) template DPA for each partner type, (3) consent form (if consent-based) or ordinance (if public-task-based) translated into Spanish and Valencian, (4) DPIA template or summary for the health-data loop.
- Create a GDPR compliance checklist (partner data-handling practices, staff confidentiality, access logs, breach-reporting procedures) and distribute to all 4–6 main partners (housing associations, social services, NGOs, pharmacies) by Month 1 (2026-11-08), asking them to complete by Month 1.3 (2026-11-17) to identify gaps. Use a simple online form (Google Forms or equivalent) to collect responses.
- Prepare a Data Protection Impact Assessment (DPIA) for the health-data loop: document data flow (hospital → city), controls (aggregation, 12-month deletion), and residual risks (re-identification via postal code + age + sex); conclude with a recommendation (proceed with safeguards, or reject) by Month 1.5 (2026-11-23).

### Expert Validation Steps

- Request written guidance from the Spanish Data Protection Agency (AEPD) (or consult published AEPD criteria/rulings on heat-alert contact) on whether intermediary-held lists and daily contact calls to enrolled residents constitute a lawful basis under Article 6 and LOPDGDD. AEPD formal guidance is not always available, but published opinions can clarify precedent. Allocate 2–4 weeks for AEPD response if a formal request is made.
- Have the GDPR counsel review each partner organization's existing data-governance policies and provide a 'compliance readiness rating' (green: ready, yellow: needs training, red: major gaps). Partners rated 'red' must remediate before enrolling in the program (e.g., adopt a privacy notice, document consent, implement access logs).
- Engage a municipal legal department representative (or city attorney) to review the signed DPAs before execution to confirm alignment with municipal liability and insurance policies. Confirm that joint-controller agreements do not create unexpected shared liability for the city if a partner breaches confidentiality.

### Responsible Parties

- GDPR/Legal Officer: coordinate with counsel, draft consent forms/ordinances, oversee DPIA, manage partner compliance audits
- Specialist GDPR Law Firm: deliver legal opinions, template DPAs, DPIA template
- Partner organizations (4–6): complete GDPR readiness survey, execute DPAs, train staff on confidentiality and consent protocols
- Municipal legal department: review DPAs for liability implications, confirm alignment with municipal insurance

### Assumptions

- **High:** The intermediary-held-list model (personal data never transferred to the city, only aggregates reported) complies with GDPR and Spanish law, because data controllers (housing associations, social services, NGOs) independently determine contact frequency and methods, and the city only specifies alert triggers. Joint-controller agreements (Article 26) clarify roles and liability.
- **Medium:** Partner organizations have (or can quickly adopt) basic data-governance practices: written privacy notices, documented consent, incident-reporting procedures, and staff confidentiality training. No partner will be unable to meet baseline GDPR compliance due to resource constraints.
- **High:** A lawful basis for heat-alert contact can be established under GDPR Article 6(1)(e) (public task) via a municipal ordinance, avoiding the need for explicit consent from every enrolled resident. If consent is required (Article 6(1)(a)), the consent form and withdrawal procedures are simple enough to implement at scale.
- **Medium:** The Spanish Data Protection Agency (AEPD) will provide timely guidance (within 2–4 weeks) on heat-alert contact lawfulness if a formal request is submitted; published AEPD criteria and precedent cases are available to inform the legal opinion if AEPD cannot respond.

### SMART Validation Objective

By Month 1.5 (2026-11-23), obtain: (1) signed GDPR legal opinion confirming lawful basis (specify Article 6 basis: consent 6(1)(a), public task 6(1)(e), or hybrid) and controller/processor roles for each partner; (2) executed data-processing agreements signed by each of the 4–6 main partners, incorporating the legal opinion and DPA template; (3) written GDPR compliance readiness assessment for each partner, with remediation plan for any 'red-rated' gaps; (4) DPIA screening for the health-data loop completed and approved. Train 50–80 partner staff on GDPR, confidentiality and consent by Month 2 (2026-12-08). Conduct partner GDPR audit (spot-check consent records, access logs) at Month 9 (2027-07-08).

### Notes

- GDPR compliance is a hard blocker: if the legal opinion is unfavorable or partners withdraw due to perceived GDPR risk, outreach enrollment collapses and the program is unviable. This must be validated by Month 1 (2026-11-08) before any partner recruitment or data-processing begins.
- The intermediary model is chosen to avoid personal data transfer to the city, but this also reduces the city's control over contact and audit rights. Joint-controller agreements must carefully define each party's role and liability so no party can claim the other is responsible for a breach.
- Data deletion is mandatory: all personal data (names, addresses, phone numbers) held by partners must be deleted within 30 days after Month 12 (2027-10-08) unless residents re-consent for Year 2. Ensure all partners understand and can execute this deletion.


## 5. Intermediary Outreach Network Capacity & Reach Validation

The 60% outreach-contact-success gate (Month 4 = 2027-02-08) depends on 4–6 intermediary organizations (housing associations, social services, NGOs, pharmacies) having adequate call-center capacity to contact enrolled residents on alert days. The plan assumes ≥3,000 enrolled, targeting 5,000 contact attempts per month in season, with 60% success (3,000 reached). However, no baseline capacity has been documented: How many staff do housing associations actually have available? What are their summer turnover rates? How many calls can they attempt per person per day? If partner capacity is <50% of assumptions, the contact-success gate will fail immediately, and the program has no contingency (the intermediary model does not allow the city to directly make calls). Capacity validation is critical by Month 1 (2026-11-08).

### Data to Collect

- Current call-center staffing (FTE) per partner organization available for outreach during alert season (May–September)
- Typical call volume per staff member per day (calls/person/day) and average call duration (minutes/call)
- Summer turnover or availability constraints (staff take leave, competing priorities) with estimated capacity loss (%)
- Historical maximum call volume each partner has sustained (to establish baseline peak capacity)
- Infrastructure: do partners have telephone systems, call-logging tools, and real-time reporting capabilities to support daily tracking and escalation?

### Simulation Steps

- Conduct a brief telephone survey (15–20 minutes per organization) of the 4–6 identified intermediary organizations by Month 0.8 (2026-11-01), asking their operations leads: current social-work/outreach staff count, average calls-per-day they handle, call duration, summer staffing constraints, and available data-tracking systems. Record responses in a standardized form.
- Create a capacity simulation: assume 3,000 enrolled residents, 5,000 contact attempts/month in season, ≥60% success. Distribute target across partners based on their size (e.g., social services 40%, housing associations 30%, NGOs 20%, pharmacies 10%). Calculate implied call attempts per staff member per day per partner. Identify any partner falling significantly short of required capacity.
- Model stress scenarios: if one partner drops out mid-season (capacity loss >30% due to staff illness or competing priorities), can remaining partners absorb the shortfall? Create a contingency-routing plan specifying which partners would take additional load.
- Prepare a mock-call simulation (5–10 sample calls per partner) at Month 1.5 (2026-11-23) to test their systems and measure actual call-taking speed and logging accuracy; use results to adjust capacity estimates and call scripts.

### Expert Validation Steps

- Request written capacity commitments from each of the 4–6 partner organizations (by Month 1 = 2026-11-08) specifying: (a) baseline staff available for heat outreach during May–September, (b) committed contact-attempt target per alert day (e.g., 'social services will attempt 800 calls per alert day'), (c) escalation procedures if they fall short (e.g., 'if we cannot reach 60% by 12:00, city can activate backup partners'), and (d) confirmation that call-logging and real-time reporting are available.
- Consult with 2–3 municipal social services or NGO leads from comparable EU cities (Valencia, Barcelona, or other mid-sized cities) about their experience with intermediary-call programs: typical capacity utilization, seasonal constraints, and common failures. Identify patterns and red flags.
- Engage a call-center operations expert (€3–5k contract, brief review) to audit partner call-handling infrastructure and estimate realistic capacity under high-volume conditions (alert-day surge). Expert provides a capacity scorecard and recommendations for process improvements (e.g., batch-calling, shift rotation) to meet targets.

### Responsible Parties

- Partner Liaison Officer: conduct capacity survey, obtain written commitments, monitor partner performance against targets
- Outreach Lead: design and run mock-call simulation, train partners on call scripts, provide real-time feedback during drills
- Each intermediary partner: supply capacity data, participate in mock drills, commit to contact-attempt targets in writing
- Call-center operations expert (contract): audit partner infrastructure and provide capacity recommendations

### Assumptions

- **High:** The 4–6 identified intermediary organizations (housing associations, social services, NGOs, pharmacies) collectively have ≥30–40 FTE of social-work/outreach staff available for heat-alert contact work during May–September. Each organization can sustain ≥20–30 calls per day per staff member, yielding ≥600–1,200 combined attempts per alert day.
- **Medium:** Summer staffing loss (leave, competing crises) is ≤15% from baseline, so net available capacity remains ≥85% of normal staffing levels. No partner will experience >25% staffing loss in any single month.
- **Medium:** All 4–6 partners have access to telephone systems, basic call-logging (spreadsheet or minimal CRM), and the ability to report daily or weekly contact counts to the city. None require custom IT integration or data-pipeline setup beyond a shared secure spreadsheet.
- **Medium:** Partner staff are motivated to participate in heat outreach (alignment with their missions of supporting vulnerable residents) and will prioritize heat calls over competing work during Level 2–3 alerts. Intrinsic motivation is sufficient; no additional incentive payments are required.

### SMART Validation Objective

By Month 1 (2026-11-08), confirm that: (1) each partner has provided a written capacity commitment (baseline staff, contact-attempt targets, data-tracking capability); (2) the combined capacity of all 4–6 partners equals or exceeds 5,000 contact attempts/month in season, with ≥60% expected success (≥3,000 reached); (3) a contingency routing plan exists: if any partner falls <50% of committed capacity by Month 2.5 (2026-12-23), city can reallocate that partner's target to backup partners or activate emergency outreach staff. Measure actual capacity in the full-system drill (Month 3.2 = 2027-01-14) with ≥300 simulated enrollment calls, and validate ≥60% success rate. If drill shows <55% success, adjust gate to 55–58% or activate escalation protocols.

### Notes

- This is the second most critical operational gate after volunteer recruitment. If partners lack call capacity, the 60% contact-success gate will fail at Month 4 (2027-02-08), and there is no fallback: the city cannot directly call 3,000+ people without violating the GDPR intermediary model. The only recourse is to reduce the enrollment target (to 2,000 or fewer), which reduces the program's reach.
- Partner capacity is likely to degrade under multi-day heat events (July–August, Months 9–10 = 2027-07-08 to 2027-08-08) due to staff fatigue and competing demands. Capacity should be measured at realistic peak stress (not just average), and a 20% reserve should be built into staffing targets.
- If the mock-call simulation (Month 1.5 = 2026-11-23) reveals that partners can only sustain ≤40% contact success, escalate immediately to the outreach lead and incident commander. Options: (a) reduce enrollment target to 2,000, (b) activate city outreach staff directly (trade GDPR risk for reach), or (c) scale the taxi retainer (use transport drivers to hand-deliver alerts). Each option has budget or legal implications that must be resolved by Month 2 (2026-12-08).


## 6. Baseline Heat-Health Data Quality & Coding Validation

The Month 4 (2027-02-08) evaluation baseline depends on verified heat-related EMS calls (estimated 80–120 per summer) and excess mortality (estimated 15–25 deaths). These figures are provisional and unverified. If the actual baseline is 2–3× smaller (20–40 EMS calls, 5–10 deaths), the evaluation may lack statistical power to detect a real 10–15% reduction. Conversely, if baseline is larger (200+ EMS calls), the evaluation needs a larger sample and different comparison design. Coding practice also varies: some hospitals code heat explicitly (ICD-10 T67.0–T67.9), others code symptoms (dehydration, syncope) without flagging heat attribution. Without baseline clarity by Month 1 (2026-11-08), the evaluation design will be built on sand, and the month-12 report will reveal the analysis is underpowered or uninterpretable.

### Data to Collect

- Three years (2023–2025) of heat-related EMS calls by date and location (postcode if available), coded as explicit heat-related or coded as symptoms (dehydration, syncope, collapse) that may be heat-attributable
- Three years of ED visits to the main hospital coded as heat-related or as heat-attributable symptoms; determine which ICD-10 codes are used
- Excess mortality estimates (per municipality or regional health authority) for hot-season months (June–September) for the past 3 years, with temperature-adjusted attribution if available
- Confirmation of which organization (EMS service, hospital, regional public health authority) maintains the authoritative baseline; who is the data custodian and what are access restrictions?
- Coding practice documentation: does the EMS use explicit 'heat-related' coding? Does the hospital? If not, how are heat-attributable cases identified (retrospective chart review, symptom pattern)?
- Data quality metrics: completeness (% of records with required fields), consistency across services, temporal patterns (do peaks match known heat events?)

### Simulation Steps

- Request 3-year historical data (2023–2025) from the municipal EMS service, hospital ED, and regional public-health authority by email with a specific data-request form (identify variables: date, time, location, ICD-10 code, chief complaint, age, outcome). Request delivery by Month 0.8 (2026-11-01) to allow analysis time.
- Create a data-quality audit spreadsheet: calculate completeness (% of records with each variable), identify missing or inconsistent date ranges, flag any zero-count months (which may indicate data entry issues). Analyze temporal pattern: do high-count days or weeks align with known heat events from meteorological data (AEMET archives)?
- Conduct a manual coding review: sample 30–50 EMS call records and 30–50 ED visits coded as 'heat-related' and verify against clinical documentation (chief complaint, vital signs, treatment) that they are plausibly heat-attributable. Identify any false positives or false negatives.
- Compare the three-year average to the plan's provisional estimate (80–120 EMS calls, 15–25 deaths per summer). Calculate the magnitude of difference and assess power: if actual baseline is 30 EMS calls (vs. 100 estimated), a 20% reduction is only 6 cases/season, requiring a much larger comparison group or longer time series to detect statistically.

### Expert Validation Steps

- Engage a heat-health epidemiologist (€10–15k contract, 4–6 weeks) to audit the baseline data, assess coding practice, and recommend a temperature-adjusted baseline model (e.g., regress EMS calls on daily mean temperature and prior-day maximum to estimate expected calls at different heat levels). Epidemiologist delivers a 'baseline validation report' with confidence intervals and recommendations for the evaluation design.
- Contact the director of the municipal EMS service and hospital ED to confirm: (a) whether they code heat-related cases explicitly, (b) if not, whether a retrospective review is feasible to identify heat-attributable cases from clinical notes, and (c) whether they can provide daily aggregate counts by 10:00 a.m. next day during the season.
- Request written confirmation from the regional public-health authority (or Ministry of Health) regarding heat-attributable excess-mortality estimates for the city for prior years (2023–2025). This is typically published post-hoc (3–6 months after summer) and uses temperature-adjusted regression; use published estimates as a benchmark for the program's year-one evaluation.

### Responsible Parties

- Data/Evaluation Coordinator: request and receive historical data, conduct quality audit, manage epidemiologist contract, deliver baseline report
- Heat-health epidemiologist (contract): validate coding, build temperature-adjusted model, assess power, provide evaluation-design recommendations
- EMS service director: confirm coding practice, commit to daily-count reporting during season, clarify access restrictions
- Hospital ED director: same as EMS
- Regional public-health authority: provide excess-mortality estimates and temperature-adjustment methodology

### Assumptions

- **High:** Heat-related EMS calls and ED visits are coded or documented in a way that can be identified from administrative data (ICD-10 codes, chief complaint text, or retrospective chart review). Baseline data for 2023–2025 is available and accurate.
- **Medium:** The actual baseline (80–120 EMS calls, 15–25 deaths per summer) is accurate within ±50% (i.e., actual range is 40–180 EMS, 8–38 deaths). The provisional estimate was based on published literature or peer-city benchmarks, not uninformed guessing.
- **Medium:** EMS and hospital data systems can produce daily aggregate counts (no identifiable patient data) by 10:00 a.m. each day during May–September. Neither service requires >1 hour of manual compilation per day; automated or semi-automated reports are feasible.
- **High:** Statistical power to detect a 10–15% reduction in EMS calls or ED visits is adequate given the baseline size. If the actual baseline is much smaller than estimated (e.g., 30 calls/season vs. 100 estimated), power calculations must be redone and the evaluation may be under-powered to detect effects smaller than 30–40%.

### SMART Validation Objective

By Month 4 (2027-02-08), deliver: (1) a 'baseline validation report' confirming the 3-year average of heat-related EMS calls, ED visits and excess mortality with confidence intervals and coding-quality assessment; (2) a temperature-adjusted baseline model showing expected EMS/ED calls at different heat levels (for comparison during evaluation); (3) confirmation of data-custodian roles and real-time reporting procedures (hospital and EMS will provide daily aggregates by 10:00 a.m. during alerts); (4) statistical power calculation for the evaluation: given the actual baseline size, what reduction (%) can be detected with 95% confidence using a comparison-group design? If power is insufficient (e.g., actual baseline is 30 EMS calls and expected detection limit is >30% reduction), document the limitation explicitly in the evaluation plan and the final report.

### Notes

- Baseline data quality is foundational. A poorly documented or inconsistently coded baseline will undermine the credibility of the final evaluation, even if the program was operationally successful. Time spent validating the baseline now (Month 1 = 2026-11-08) pays dividends at Month 12 (2027-10-08).
- If the actual baseline is much smaller than estimated (e.g., Castellón de la Plana has typically only 30–40 heat-related EMS calls per summer, not 80–120), the program should not increase the annual target to artificially inflate effect size. Instead, the evaluation design should be revised to focus on secondary outcomes (cooling-center utilization, transport equity, partner engagement) or to extend the evaluation timeline to Year 2 to accumulate larger sample sizes.
- Heat-attribution is inherently uncertain: not all ED visits coded as 'heat exhaustion' are caused by heat (some are concurrent conditions), and not all heat-related deaths are coded as such (some are coded as cardiac, stroke, or unspecified). The evaluation should state these limitations explicitly and use confidence intervals rather than point estimates.


## 7. Cooling-Center Accessibility & Facility Readiness Audit

The Month 2 (2026-12-08) readiness gate requires ≥50% of cooling-center places (≥200 of ≈400) to be fully accessible (wheelchair ramps, accessible toilets, quiet rooms, water, signage). The plan identifies 10 sites (libraries, community centers, parish halls, sports facilities) but has not audited them. Accessibility remediation can cost €10k–40k per site and take 2–4 weeks; any site failing accessibility by Month 2 (2026-12-08) will be deferred to July or dropped, reducing planned capacity and forcing more residents to depend on transport. This gate is hard to achieve without early action; validation must occur by Month 1 (2026-11-08).

### Data to Collect

- Physical accessibility audit results (from a certified accessibility auditor or municipal building inspector) for each of the 10 proposed cooling-center sites: wheelchair ramps, elevator/lift access, accessible toilet facilities (grab bars, height, door width), water fountains or stations, signage (large print, pictograms), quiet/low-stimulus rooms, emergency exit routes
- Remediation cost estimates and timelines per site (who will do work, how long, cost cap for the site to remain eligible)
- Site capacity (number of places available for residents, parking, water and toilet ratios relative to occupancy)
- Facility-use agreements (MOU or lease) confirmation: can the city open the site during alert hours (10:00–20:00 at Level 2, potentially 24-hour at Level 3)?
- Staffing and security arrangements per site: who manages the site, are there existing staff, do they need training on heat-illness first aid or escalation procedures?

### Simulation Steps

- Schedule accessibility audits for all 10 proposed sites by Month 0.8 (2026-11-01), with audit completion by Month 1 (2026-11-08). Use a standardized accessibility checklist (e.g., following Spanish accessibility standards or EU accessibility guidelines): wheelchair access, toilet accessibility, quiet room presence, water availability, signage, emergency routes. For each site, generate a 'green/yellow/red' rating (green = fully accessible now, yellow = minor remediation <€5k and <2 weeks, red = major work or unsuitable).
- Create a remediation scorecard: list all sites, their accessibility rating, estimated cost and timeline for remediation. Prioritize the 8 'greenest' sites for opening at Month 2 (2026-12-08). For any 'yellow' sites, confirm remediation can be completed by Month 2 (2026-12-08) (4 weeks away from Month 0.8 = 2026-11-01) and commit budget. For any 'red' sites, recommend deferral to July or dropping from the network.
- Prepare a site-opening readiness checklist per site: facility MOU signed, manager named, staff identified, first-aid and heat-illness training scheduled, water/toilets operational, signage installed, quiet room designated, accessible entrance clear, emergency procedures posted. Use this checklist for the Month 2 (2026-12-08) gate audit.

### Expert Validation Steps

- Engage a certified accessibility auditor (or municipal building inspector with accessibility expertise) (€8–12k for 10 sites, 2–3 weeks) to conduct professional accessibility audits. Auditor delivers a detailed report per site with photographs, remediation recommendations and cost estimates.
- For any site rated 'yellow' (remediable), obtain quotes from 2–3 contractors for the specified remediation work. Confirm timelines fit within the 4-week window (Month 0.8 = 2026-11-01 to Month 1.3 = 2026-11-17 to 2026-11-17) and budget (≤€10k per site cap is specified in the plan; anything higher requires exception approval).
- Consult with representatives from disability-advocate organizations or wheelchair-user groups in Castellón de la Plana (if such groups exist) to validate the accessibility audit findings and ensure that the audit captures real usability barriers, not just regulatory compliance (e.g., the presence of a ramp is not enough if the slope is too steep for a wheelchair user to navigate alone).

### Responsible Parties

- Cooling-Center Network Manager: coordinate accessibility audits, collect site responses, manage remediation timeline and budget, ensure MOUs are signed
- Certified accessibility auditor (contract): conduct 10-site audits, deliver detailed findings and cost estimates per site
- Facilities/public works: approve remediation work, hire contractors, oversee completion, confirm timeline
- Site managers/facilities partners: participate in audit, confirm capacity for staffing and alerts, sign MOUs

### Assumptions

- **High:** At least 8 of the 10 proposed sites (libraries, community centers, parish halls, sports facilities) in Castellón de la Plana are already reasonably accessible (wheelchair ramps, accessible toilets) or can be made accessible with minor remediation (≤€10k, ≤4 weeks). No site requires major construction work (e.g., elevator installation, structural modifications) which would be prohibitively costly.
- **Medium:** The 8 accessible sites collectively provide ≥200 places (50% of 400 planned) and are distributed geographically to serve most neighborhoods within walking distance. The distribution is equitable: no single site dominates, and high-need neighborhoods (high deprivation, many 65+ residents) are within 800 m of at least one site.
- **Medium:** All 10 proposed facility partners (libraries, community centers, churches, sports clubs) are willing to open during alert hours (10:00–20:00 at minimum, potentially 24-hour at Level 3) and to sign facility-use MOUs. No partner will withdraw or impose unreasonable conditions (e.g., extreme costs, unavailability on weekends).
- **Low:** Existing facility staff can be trained on heat-illness recognition and escalation within 1 day (4 hours), and no additional safety equipment (AED, first-aid supplies) is missing or unavailable. Minimal capital investment beyond training is required.

### SMART Validation Objective

By Month 1.5 (2026-11-23), confirm that: (1) all 10 proposed sites have been audited for accessibility, with results documented in a standardized format; (2) at least 8 of 10 sites are rated 'green' (fully accessible) or 'yellow-remediable' (minor work <€10k, <4 weeks); (3) remediation for all 'yellow' sites is scheduled and funded by Month 2 (2026-12-08); (4) the cumulative places available in all 'green' and remediated 'yellow' sites equals or exceeds 200 (50% of 400 planned); (5) facility-use MOUs are signed for at least 8 sites, specifying hours, staffing, liability and accessibility requirements; (6) each site has a named manager, identified staff, and scheduled training dates. Any 'red'-rated site is either dropped or deferred to July; do not include it in Month 2 (2026-12-08) gate calculation.

### Notes

- Accessibility audit is a gating item: if 6 of 10 sites are rated 'red' (unsuitable), the program loses 60% of planned capacity, forcing a network redesign and potentially a delay to the Month 2 (2026-12-08) gate. Early audit (Month 0.8 = 2026-11-01) provides time to pivot if needed.
- Accessibility includes not just wheelchair access but also quiet rooms for residents with sensory sensitivities, accessible water fountains (not just toilets), and legible signage for people with low vision. A site may have a wheelchair ramp but be otherwise noisy or overwhelming for an older person with anxiety.
- If a key site (e.g., a central sports hall with 80+ places) fails accessibility, the fallback is to reduce the planned network size and increase focus on the 8 accessible sites, which may mean fewer places within walking distance for some neighborhoods. This trade-off should be decided by the incident commander and funder before Month 2 (2026-12-08).

## Summary


## Immediate Actionable Tasks

**Critical path (complete by Month 1 = 2026-11-08):**

1. **Funder Evidence Acceptance** (Item 1): Obtain written funder confirmation that drill-based gates are acceptable and that the €750k partial-release rule applies if evidence is insufficient. This is the highest-risk assumption; proceed with confidence only after written sign-off. If the funder refuses, immediately escalate and renegotiate funding structure or identify contingency credit line.

2. **Procurement Lead-Time Validation** (Item 2): Issue detailed RFQs to 5+ kit suppliers, obtain firm quotes and delivery commitments, and pre-qualify 2–3 backup suppliers with emergency-activation agreements by Month 1 (2026-11-08). Lock in first-tranche orders by Month 1.2 (2026-11-14) with February delivery confirmation. Any slippage >2 weeks triggers backup activation immediately.

3. **Volunteer Recruitment Launch** (Item 3): Begin volunteer driver recruitment immediately (Month 0.1 = 2026-10-11) targeting 50–60 candidates, establish a rolling vetting pipeline with fortnightly cohorts, and track pipeline status weekly. If <15 are fully vetted by Month 1.5 (2026-11-23), immediately activate the taxi-retainer scale-up trigger to €100–120k and accept reduced home-kit scope.

4. **GDPR Compliance Kickoff** (Item 4): Engage GDPR specialist law firm by Month 0.5 (2026-10-23) (€20–30k, 4–6 weeks). Obtain written legal opinion on lawful basis and controller/processor roles by Month 1 (2026-11-08). Finalize and execute all partner data-processing agreements by Month 1.5 (2026-11-23). No partner recruitment or outreach training can proceed without signed DPAs.

5. **Intermediary Capacity Survey** (Item 5): Conduct brief capacity survey of all 4–6 intermediary partners (housing associations, social services, NGOs, pharmacies) by Month 0.8 (2026-11-01). Obtain written capacity commitments (staff, contact-attempt targets) by Month 1 (2026-11-08). If combined capacity is <4,000 contact attempts/month or if expected contact-success rate is <55%, escalate to outreach lead and incident commander immediately for contingency planning.

6. **Baseline Data Request** (Item 6): Request 3-year historical heat-related EMS calls, ED visits and mortality data from EMS, hospital and regional public-health authority by email (Month 0.3 = 2026-10-17). Commission a heat-health epidemiologist (€10–15k, 4–6 weeks) to validate baseline by Month 1 (2026-11-08). If actual baseline is <50 EMS calls per summer (vs. 80–120 estimated), flag power limitation for the evaluation design immediately.

7. **Cooling-Center Accessibility Audits** (Item 7): Engage certified accessibility auditor (€8–12k, 2–3 weeks) to audit all 10 proposed sites by Month 1 (2026-11-08). If >3 sites are rated 'red' (major remediation), escalate site-selection decisions to the cooling-center network manager and incident commander immediately. Confirm ≥8 accessible sites by Month 1.5 (2026-11-23).

**High-impact decision points:**

- **Month 0.5 (2026-10-23)**: Funder response to drill-based gates and partial-release rule must be written. If funder refuses, activate contingency funding or re-scope gates.
- **Month 1 (2026-11-08)**: Incident commander, GDPR counsel, epidemiologist, and accessibility auditor all deliver key findings. Major decision point: if any single item fails (funder refusal, GDPR blocker, baseline underpowered, accessibility gap), escalate to mayor's office and steering committee for re-scope options.
- **Month 1.5 (2026-11-23)**: Volunteer recruitment, partner capacity, and DPA execution all converge. If any are short of target, trigger immediate contingency (taxi scale-up, reduced kit scope, GDPR re-negotiation with partners).
- **Month 2 (2026-12-08)**: Readiness gate passed or failed based on procurement orders placed, volunteer vetting progress, partner DPAs signed, and site accessibility confirmed. Any failed gate criterion requires immediate corrective action or program re-scope.

**Validation sequence:** Start with Items 1 and 4 (funder + GDPR) in parallel immediately, as they are legal/governance blockers. Simultaneously, launch Items 2, 3, 5 and 7 (operational work). Complete Item 6 (baseline) by Month 1 (2026-11-08) to inform evaluation design. All seven items should be substantially complete by Month 1.5 (2026-11-23) to de-risk the Month 2 (2026-12-08) readiness gate.

