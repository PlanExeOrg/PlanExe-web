Persuasive elevator pitch.

# Castellón de la Plana Heat-Response Pilot: Life-Saving Infrastructure for Vulnerable Residents

## Project Overview

**Every multi-day heatwave leaves older, isolated, and poorly housed residents in life-threatening conditions.** Castellón de la Plana faces 15–25 (estimate) heat-attributable excess deaths per summer, pending audit. This €3.5M, 12-month pilot operationalizes a replicable heat-response system that aims to reduce harm and tests the model through tiered alerts, 10 walkable cooling refuges, GDPR-safe outreach to 3,000 high-risk residents, home safety kits for 2,000 homes, and health-system coordination—all without new legislation or major construction.

Built on **established practice** from Barcelona, Paris, and Ahmedabad, tested by drills before summer, and governed by clear gates, the pilot delivers a playbook and scaling cost model for other EU cities to adopt. Gates (proposed, to be locally calibrated): ≥80% refuge hours delivered, ≥60% outreach contact, <45-minute transport, and 100% of corrective actions closed. The pilot aims to reduce harm and tests the model, offering municipal credibility, and a replicable blueprint for climate-resilient cities.

## Target Audience

- **Municipal decision-makers:** Mayor, chief health officer, budget director
- **Public-health authorities:** Regional and national agencies; EU climate-resilience funding bodies
- **Peer municipalities:** Cities in Spain and other EU nations considering heat-response pilots
- **Health systems:** Hospitals, emergency medical services, primary care providers
- **Community leaders:** Representatives of older, isolated, and migrant residents in Castellón

The pitch emphasizes measurable gates, **replicability**, and legal defensibility for officials; equity and harm reduction for health and community sectors; and the scaling playbook for peer cities and funders seeking transferable models.

## Risks and Mitigation Strategies

- **Cool-season gates depend on drills, not real heat.** Contingency: pre-specify the drill protocol by Month 2.5 (2026-12-23). If evidence is insufficient, release €750k (50%) at Month 4 (2027-02-08) and the remainder after a Month 5 (2027-03-08) re-test, accepting a cash gap of €200–400k.

- **Procurement slips past the December 2026 deadline.** Mitigation: issue specs by November 2026; place first-tranche orders by November 2026; pre-qualify 2–3 backup suppliers per category; hold €160k contingency in tranche 1.

- **Volunteer recruitment shortfall.** If <20 recruits are in the vetting pipeline by November 2026, scale the taxi retainer up (capped at €80k), trading cost for reliability.

- **GDPR challenge or partner withdrawal.** Mitigation: engage legal counsel by October 2026 (cost ≤€30k); sign partner data-processing agreements by November 2026; audit partners at Month 9 (2027-07-08).

- **Staff fatigue during multi-day heat events.** Mitigation: limit shifts to 3–4 consecutive alert days, hold a 20–30% staff reserve, and train all staff in fatigue management by January 2027.

## Metrics for Success

**Primary gates (user constraints):**

- ≥80% of planned cooling-center hours delivered in the full-system drill (January 2027)
- ≥60% outreach contact success from ≥300 attempts
- Mean request-to-transport time <45 min over ≥30 simulated requests (including ≥5 wheelchair users)
- After-action report completed with 100% of corrective actions closed

**Operational measures:**

- ≥8 of 10 sites signed with named managers; ≥50% of places accessible by Month 2 (2026-12-08)
- Heat line live with mock-call test passed
- ≥50 partner staff trained on escalation
- 100% of tranche-1 procurement orders placed on schedule

**Reach and equity:**

- 3,000 enrolled high-risk residents by May 2027
- ≥70% of enrolled residents within 800 m (10-min walk) of a refuge
- ≥5% of outreach calls in non-official languages
- 2,000 homes with kits installed by May 2027

**Health outcomes (not a gate):**

- Baseline heat-related EMS calls (80–120 estimated) and excess deaths (15–25 estimated)
- Comparison to prior years and matched districts
- Heat-illness misinformation corrected within 4 hours

## Stakeholder Benefits

**For the municipality:** A tested, auditable response system that meets national heat-warning obligations, reduces reputational risk from a failed summer response, protects the health system from surge, and positions Castellón as a climate-leader peer city for EU funding.

**For residents:** Reduced heat-illness risk through refuge access within walking distance, phone support and transport for mobility-limited people, cooler homes via installed kits, and clear escalation if heat illness occurs.

**For health systems:** Daily aggregate data on heat-related EMS calls and ED visits to guide escalation; a nurse triage line that diverts mild cases from EMS; and lower surge demand during multi-day events.

**For employers:** Clarity on municipal heat-protection rules and recognition for compliance.

**For peer cities:** A complete playbook, scaling cost model (≈€2.3M/year estimated for repeat), and evidence from drills and the first season, reducing their own pilots' uncertainty.

**For funders:** Demonstrable harm reduction, gate-based accountability, a clear scaling pathway, and low-risk **replication** potential across EU cities.

## Ethical Considerations

The pilot keeps personal health data out of municipal hands by using intermediary-held lists (housing associations, social services, NGOs) that contact residents on the city's behalf; only aggregate results are shared, complying with GDPR without requiring new legislation. **Vulnerable residents** (older, isolated, migrant) are explicitly prioritized in outreach, home-kit targeting, and transport, with language access for ≥4 non-official languages via paid community ambassadors.

Unhoused residents are reached via NGO-led street rounds and drop-in cool points, not surveillance. Volunteers undergo safeguarding and insurance checks; all street staff work in teams of ≥2. Alert thresholds are evidence-based (national forecast + local consecutive hot nights) to avoid false alarms that waste budget or erode trust. The evaluation design reports uncertainty ranges honestly and does not claim unverifiable mortality reductions. All operational policies are published and subject to public and data-protection oversight. After-action incident reports are completed transparently; corrective actions are tracked.

## Collaboration Opportunities

- **Housing associations and social services:** Enroll and contact residents directly, avoiding municipal data-handling risk.
- **Pharmacies, GPs, and faith leaders:** Serve as trusted messengers and enrollment referral points.
- **Hospitals and EMS:** Contribute daily aggregate heat-related call and visit counts to guide escalation; in return, the city shares nurse-line triage and worker-protection guidance.
- **NGOs serving unhoused people:** Lead street rounds and cool-point management; the city funds their alert-day shifts and transport triggers.
- **Taxi and accessible-transport operators:** Sign a standby retainer to guarantee response capacity; volunteer drivers augment capacity at lower cost.
- **Schools and community centers:** Loan their libraries and civic halls as refuge sites during summer, freeing municipal maintenance.
- **University epidemiologists:** Pre-register the evaluation design and conduct independent analysis under a data-processing agreement, strengthening credibility.
- **Peer cities** (Barcelona, Valencia, Murcia): Test the playbook at Month 11 (2027-09-08) and contribute data to refine the scaling cost model; 2028 is the wider rollout.

## Long-term Vision

The pilot is the foundation of a city-scale heat-resilience system that scales to all of Castellón's 170,000 residents by Year 2 (estimated €2.3M/year recurring cost; funding source to be identified). Year-2 investments focus on durable home retrofits (exterior shading, insulation) in high-priority social-housing blocks, expanding the cooling-refuge network to 15–20 sites, and embedding heat-response skills into municipal operations, health systems, and employers' routine work.

The **Playbook** becomes a template for adoption by 5–10 peer EU cities by 2030, creating a network of cities with interoperable alert thresholds, shared evaluation methods, and common procurement leverage. By 2035, the pilot model informs a binding EU directive on municipal heat-health action plans, and heat-response funding is mainstreamed into city budgets and the health budget rather than treated as emergency spend.

The deeper vision: a region where heat is no longer a mortality event, where vulnerable residents are known, supported, and safe, and where municipal and health systems operate as integrated climate-resilience infrastructure.

## Call to Action

- **Approve the pilot by October 2026 and authorize the mayoral delegation of authority by November 2026** so that procurement, partnership agreements, and staff hiring can meet the December 2026 readiness gate.

- The funder should confirm the drill-based evidence rule and partial-release protocol in writing.

- Prospective partner cities (Barcelona, Valencia, Murcia) should signal intent to test the playbook at Month 11 (2027-09-08); 2028 is the wider rollout.

- Municipal departments should assign incident commanders and nominate cooling-center managers now.

- Health systems should designate data liaisons for the MOU by November 2026.

**Delay past Month 1 (2026-11-08) risks slipping the Month 2 (2026-12-08) procurement gate and losing the first season's evidence window.**