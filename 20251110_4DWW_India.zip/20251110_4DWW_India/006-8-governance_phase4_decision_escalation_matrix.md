**Budget Request Exceeding PMO Authority (INR 50 crore)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority and requires strategic oversight.
Negative Consequences: Potential for misallocation of funds, budget overruns, and failure to achieve project objectives.

**Critical Risk Materialization (e.g., Regulatory Delay)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Mitigation Plan and Resource Allocation
Rationale: Requires strategic decision-making and potential reallocation of resources to mitigate significant project risks.
Negative Consequences: Project delays, increased costs, and potential failure to achieve project goals.

**PMO Deadlock on Pilot Company Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Selection Criteria and Final Decision
Rationale: Requires higher-level intervention to resolve disagreements and ensure alignment with project objectives.
Negative Consequences: Delays in pilot program launch, selection of unsuitable pilot companies, and potential for biased outcomes.

**Proposed Major Scope Change (e.g., Adding a New Sector)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Impact Assessment and Approval
Rationale: Requires strategic assessment of the impact on project objectives, budget, and timeline.
Negative Consequences: Scope creep, budget overruns, project delays, and potential failure to achieve original objectives.

**Reported Ethical Concern (e.g., Data Privacy Breach)**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics & Compliance Committee Investigation and Recommendation to CEO of NITI Aayog
Rationale: Requires independent investigation and corrective action to maintain ethical standards and regulatory compliance.
Negative Consequences: Legal penalties, reputational damage, loss of stakeholder trust, and potential project shutdown.

**Unresolved Technical Issues**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Technical Advisory Group Recommendations and Decision
Rationale: Requires strategic decision-making and potential reallocation of resources to resolve significant technical issues.
Negative Consequences: Project delays, increased costs, and potential failure to achieve project goals.

**Unresolved Stakeholder Issues**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Stakeholder Engagement Group Recommendations and Decision
Rationale: Requires strategic decision-making and potential reallocation of resources to resolve significant stakeholder issues.
Negative Consequences: Project delays, increased costs, and potential failure to achieve project goals.

**Serious Ethical Breaches or Regulatory Violations**
Escalation Level: CEO of NITI Aayog
Approval Process: CEO Review of Ethics & Compliance Committee Recommendations and Decision
Rationale: Requires strategic decision-making and potential reallocation of resources to resolve significant ethical breaches or regulatory violations.
Negative Consequences: Project delays, increased costs, and potential failure to achieve project goals.