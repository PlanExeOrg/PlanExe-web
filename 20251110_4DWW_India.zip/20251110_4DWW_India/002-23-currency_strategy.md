This plan involves money.

## Currencies

- **INR:** Indian Rupees for local expenses, salaries, incentives, and operational costs within India.
- **USD:** US Dollars for budgeting and reporting, given the project budget is initially provided in USD and for potential international transactions or comparisons.

**Primary currency:** USD

**Currency strategy:** While INR will be used for local transactions, USD is recommended for budgeting and reporting to mitigate risks from currency fluctuations. The initial budget is provided in USD, making it a suitable primary currency for overall financial management. For significant projects, the primary currency must be USD.