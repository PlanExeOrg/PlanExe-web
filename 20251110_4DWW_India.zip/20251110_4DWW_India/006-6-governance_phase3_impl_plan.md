### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Project Manager circulates Draft SteerCo ToR for review by CEO of NITI Aayog, Secretary of Ministry of Labour and Employment, Secretary of Department of Economic Affairs, and Independent Expert in Labor Economics.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Circulation Email
- Draft SteerCo ToR v0.1

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager consolidates feedback on SteerCo ToR and revises the document.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Feedback Summary
- Draft SteerCo ToR v0.2

**Dependencies:**

- Feedback from nominated SteerCo members

### 4. CEO of NITI Aayog formally approves the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** CEO of NITI Aayog

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0

**Dependencies:**

- Draft SteerCo ToR v0.2

### 5. CEO of NITI Aayog formally appoints the Chair and Vice-Chair of the Project Steering Committee.

**Responsible Body/Role:** CEO of NITI Aayog

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved SteerCo ToR v1.0

### 6. Project Manager coordinates with appointed members to schedule the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Email

### 7. Hold the initial Project Steering Committee kick-off meeting to review project goals, governance structure, and initial plans.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- SteerCo ToR Approved
- SteerCo Chair Appointed
- SteerCo Members Confirmed

### 8. Program Director (PMO Head) establishes the PMO structure and staffing plan.

**Responsible Body/Role:** Program Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- PMO Structure Document
- PMO Staffing Plan

**Dependencies:**

- Project Plan Approved

### 9. Program Director develops project management processes and templates for the PMO.

**Responsible Body/Role:** Program Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Management Processes Document
- Project Templates

**Dependencies:**

- PMO Structure Document

### 10. Program Director sets up project tracking and reporting systems for the PMO.

**Responsible Body/Role:** Program Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Tracking System
- Reporting System

**Dependencies:**

- Project Management Processes Document

### 11. Program Director defines communication protocols for the PMO.

**Responsible Body/Role:** Program Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Communication Protocols Document

**Dependencies:**

- Project Tracking System

### 12. Program Director recruits and onboards PMO staff (Project Managers, Data Analysts, Legal Counsel, Communications Specialist, Stakeholder Engagement Officer, Support Staff).

**Responsible Body/Role:** Program Director

**Suggested Timeframe:** Project Week 5-8

**Key Outputs/Deliverables:**

- Staffing Complete
- Onboarding Materials

**Dependencies:**

- PMO Staffing Plan

### 13. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Program Management Office (PMO)

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- PMO Staffing Complete

### 14. Project Manager identifies and recruits independent technical experts (Data Scientist, Statistician, IT Security Expert) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- List of TAG Nominees
- Recruitment Outreach Materials

**Dependencies:**

- Project Plan Approved

### 15. Project Manager defines the scope of responsibilities for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- TAG Scope of Responsibilities Document

**Dependencies:**

- List of TAG Nominees

### 16. Project Manager establishes meeting schedule and communication protocols for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- TAG Meeting Schedule
- TAG Communication Protocols Document

**Dependencies:**

- TAG Scope of Responsibilities Document

### 17. Project Manager, in consultation with the PMO Data Analyst Lead, reviews and approves the initial data collection plan for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Approved Initial Data Collection Plan

**Dependencies:**

- TAG Meeting Schedule
- TAG Communication Protocols Document

### 18. Project Manager coordinates with appointed members to schedule the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Approved Initial Data Collection Plan

### 19. Hold the initial Technical Advisory Group kick-off meeting to review project goals, governance structure, and initial plans.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- TAG Members Confirmed
- TAG Scope Defined
- TAG Meeting Scheduled

### 20. Legal Counsel drafts a code of ethics for the program.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Draft Code of Ethics

**Dependencies:**

- Project Plan Approved

### 21. Legal Counsel establishes compliance monitoring procedures.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Compliance Monitoring Procedures Document

**Dependencies:**

- Draft Code of Ethics

### 22. Legal Counsel sets up a whistleblower mechanism.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Whistleblower Mechanism Document

**Dependencies:**

- Compliance Monitoring Procedures Document

### 23. Legal Counsel conducts initial ethics and compliance training for project staff.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Training Materials
- Training Records

**Dependencies:**

- Whistleblower Mechanism Document

### 24. Project Manager identifies and recruits Data Privacy Officer and Ethics Officer for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- List of Ethics & Compliance Committee Nominees
- Recruitment Outreach Materials

**Dependencies:**

- Training Records

### 25. Project Manager coordinates with appointed members to schedule the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- List of Ethics & Compliance Committee Nominees

### 26. Hold the initial Ethics & Compliance Committee kick-off meeting to review project goals, governance structure, and initial plans.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Ethics & Compliance Committee Members Confirmed
- Code of Ethics Developed
- Compliance Procedures Established

### 27. PMO Stakeholder Engagement Officer develops a stakeholder engagement plan.

**Responsible Body/Role:** PMO Stakeholder Engagement Officer

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Plan

**Dependencies:**

- Project Plan Approved

### 28. PMO Stakeholder Engagement Officer establishes communication channels.

**Responsible Body/Role:** PMO Stakeholder Engagement Officer

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Communication Channels Document

**Dependencies:**

- Draft Stakeholder Engagement Plan

### 29. PMO Stakeholder Engagement Officer sets up a feedback mechanism.

**Responsible Body/Role:** PMO Stakeholder Engagement Officer

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Feedback Mechanism Document

**Dependencies:**

- Communication Channels Document

### 30. Project Manager identifies and recruits representatives from Industry Body, Trade Union, State Labor Department, and Employee Representative for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- List of Stakeholder Engagement Group Nominees
- Recruitment Outreach Materials

**Dependencies:**

- Feedback Mechanism Document

### 31. Project Manager coordinates with appointed members to schedule the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- List of Stakeholder Engagement Group Nominees

### 32. Hold the initial Stakeholder Engagement Group kick-off meeting to review project goals, governance structure, and initial plans.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Stakeholder Engagement Group Members Confirmed
- Stakeholder Engagement Plan Developed
- Communication Channels Established