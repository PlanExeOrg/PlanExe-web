**Purpose:** business

**Purpose Detailed:** Strategic planning and implementation of a national program to improve productivity and equity through a 4-Day Work Week.

**Topic:** Implementation plan for a 4-Day Work Week program in India