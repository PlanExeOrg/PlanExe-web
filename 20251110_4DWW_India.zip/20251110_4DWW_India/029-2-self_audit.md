Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 16 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 3 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The project focuses on economics, governance, and policy, which are outside the scope of physics.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (4DWW) + market (India) + tech/process + policy without independent evidence at comparable scale. There is no mention of precedent for this specific combination. This creates a likely failure mode.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: PMO / Deliverable: Validation Report / Date: 2026-Q2


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a clear, measurable definition of 'productivity', a strategic concept driving the plan. The plan mentions 'Productivity' as a key metric, but expert reviews highlight a 'Lack of Rigorous Productivity Definition'.

**Mitigation**: Data Analytics and M&E Lead: Produce a one-pager defining productivity with a mechanism-of-action, owner, and measurable outcomes. Include value hypotheses, success metrics, and decision hooks. Date: 2026-Q2


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan's risk register does not explicitly address second-order risks like permit delays leading to revenue shortfalls or lease penalties. The plan lists 'Regulatory & Permitting' as a risk, but lacks cascade analysis.

**Mitigation**: Risk Management Officer: Expand the risk register to include cascade effects of identified risks, mapping out potential second-order consequences and adding controls. Due date: 2026-Q2


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not include a permit/approval matrix. The plan mentions 'Regulatory and Compliance Requirements' but does not map out the specific permits needed, their lead times, or dependencies.

**Mitigation**: Legal and Regulatory Specialist: Create a permit/approval matrix detailing required permits, lead times, dependencies, and responsible parties. Include NO-GO thresholds for delays. Date: 2026-Q2


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan does not include a dated financing plan listing sources/status, draw schedule, covenants, and a NO‑GO on missed financing gates. The plan mentions 'Funding from government and private sector' but lacks specifics.

**Mitigation**: PMO: Develop a detailed financing plan including funding sources, status, draw schedule, covenants, and NO-GO criteria for missed gates. Date: 2026-Q2


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks scale-appropriate benchmarks or vendor quotes to substantiate the budget. There is no mention of cost per m²/ft² or comparable projects. This omission creates a likely failure mode.

**Mitigation**: PMO: Obtain ≥3 relevant comparables, normalize costs per area (m²/ft²), and adjust the budget or de-scope by 2026-Q2.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents projections as single numbers without ranges or alternative scenarios. For example, 'Systemic: 15% faster iteration cycles based on real-time data' lacks a confidence interval.

**Mitigation**: Data Analyst: Conduct a sensitivity analysis or best/worst/base-case scenario analysis for the '15% faster iteration cycles' projection. Due date: 2026-Q2


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks engineering artifacts for build-critical components. There are no technical specs, interface definitions, test plans, or integration maps. This creates a likely failure mode.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components by 2026-Q3.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (4DWW) + market (India) + tech/process + policy without independent evidence at comparable scale. There is no mention of precedent for this specific combination. This creates a likely failure mode.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: PMO / Deliverable: Validation Report / Date: 2026-Q2


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions 'a new system' without specific, verifiable qualities. The plan mentions 'Technology Integration Approach' but lacks SMART acceptance criteria.

**Mitigation**: Technology Integration Lead: Define SMART criteria for the technology integration approach, including a KPI for system uptime (e.g., 99.9% availability). Date: 2026-Q2


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'AI-powered adaptive learning system' without a clear benefit case. The core project goals are 'Increased productivity' and 'Improved equity'. It's unclear how AI directly supports these goals.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the AI-powered adaptive learning system, complete with a KPI, owner, and estimated cost, or move the feature to the project backlog. Date: 2026-Q2


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a 'Informal Sector Integration Specialist' to address the unique challenges of the informal sector. This role is critical for achieving equity goals, and finding someone with the right expertise and experience in this area is likely to be difficult.

**Mitigation**: HR: Validate the talent market for an 'Informal Sector Integration Specialist' by surveying relevant NGOs and posting a sample job description. Due date: 2026-Q2


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not map out the specific permits needed, their lead times, or dependencies. The plan mentions 'Regulatory and Compliance Requirements' but does not include a permit/approval matrix.

**Mitigation**: Legal and Regulatory Specialist: Create a permit/approval matrix detailing required permits, lead times, dependencies, and responsible parties. Include NO-GO thresholds for delays. Date: 2026-Q2


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan lacks a detailed operational sustainability plan. While the plan mentions resources and timelines, it does not address long-term funding, maintenance, or technology obsolescence. The plan mentions 'Funding from government and private sector'.

**Mitigation**: PMO: Develop an operational sustainability plan including a funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms. Date: 2026-Q3


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not address zoning/land-use, occupancy/egress, fire load, structural limits, noise, or permits. The plan requires physical locations, but lacks a fatal-flaw screen with authorities/experts.

**Mitigation**: Facilities Team: Perform a fatal-flaw screen with local authorities to identify zoning, occupancy, and other hard constraints for pilot locations by 2026-Q2.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions reliance on third-party vendors but lacks details on SLAs, redundancy, or tested failover. The plan lists 'Reliance on third-party vendors creates vulnerabilities' as a risk, but lacks specifics.

**Mitigation**: Procurement: Secure SLAs with key vendors, add a secondary supplier/path for critical services, and test failover procedures by 2026-Q3.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'PMO' is incentivized by successful program implementation, while 'State Governments' are incentivized by local economic and political gains. A conflict arises if PMO standards hinder state customization.

**Mitigation**: PMO and State Government Representatives: Co-create a shared OKR focused on balancing national standards with state-level customization, measured by adoption and satisfaction. Date: 2026-Q2


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: PMO: Establish a monthly review with a KPI dashboard and a lightweight change board. Define thresholds for re-planning or stopping. Owner: Program Director. Date: 2026-Q2


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan has ≥3 High risks (FM1, FM3, FM4, FM6, FM7, FM9) that are strongly coupled. For example, FM4 (Data Delusion) can trigger FM1 (Productivity Mirage) and FM7 (Wage War).

**Mitigation**: PMO: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Date: 2026-Q3