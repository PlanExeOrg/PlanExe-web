This plan involves money.

## Currencies

- **USD:** Primary currency for budgeting and reporting, given the international scope and the project budget is provided in USD.
- **GBP:** Relevant for project activities and potential staff/consultants in the United Kingdom, specifically London.
- **CAD:** Relevant for project activities and potential staff/consultants in Canada, specifically Toronto.

**Primary currency:** USD

**Currency strategy:** USD will be used for consolidated budgeting and reporting. GBP and CAD may be used for local transactions in the UK and Canada, respectively. Exchange rate fluctuations should be monitored, and hedging strategies considered for large transactions.