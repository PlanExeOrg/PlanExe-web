### 1. Project Sponsor formally approves the 'Pioneer' strategic path and authorizes the initial $3.5M budget allocation (50/25/25 split).

**Responsible Body/Role:** Senior Executive Sponsor

**Suggested Timeframe:** Project Week 1 (2026-Feb 07)

**Key Outputs/Deliverables:**

- Signed Project Charter reflecting Pioneer strategy
- Phase budget appropriations ($1.75M for P1)

**Dependencies:**

- Selection of 'Pioneer' strategic path (from Analysis Files)

### 2. Project Manager initiates recruitment for Scientific & Editorial Review Board (SERB) external members (Linguistic Review Panel Chair, Editorial Board Chair) and drafts initial SERB Terms of Reference (ToR).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1 - 2

**Key Outputs/Deliverables:**

- Draft SERB ToR v0.1
- Shortlist of primary and backup external SERB candidates

**Dependencies:**

- Senior Executive Sponsor authorization

### 3. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee (PSC) and the Core Operational Team (COT).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1
- Draft COT ToR v0.1

**Dependencies:**

- Internal decision on governance activation timing (Early mobilization per Pioneer strategy)

### 4. Internal Legal Counsel drafts initial ToR for the Compliance and IP Governance Body (CIGB), focusing on data privacy and IP assignment requirements.

**Responsible Body/Role:** Internal Legal Counsel

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft CIGB ToR v0.1
- Initial Data Consent Protocol Draft

**Dependencies:**

- Draft PSC/COT ToRs defined

### 5. Project Steering Committee (PSC) convenes for its *Inaugural Formation Meeting* (Chaired by Project Director, non-voting until formal election), confirming ToRs, appointing internal chair roles, and ratifying the initial Risk Register.

**Responsible Body/Role:** Senior Executive Sponsor

**Suggested Timeframe:** Project Week 4 (2026-Feb 28)

**Key Outputs/Deliverables:**

- Approved PSC, COT, SERB, CIGB ToRs v1.0
- Election of PSC Chair and appointment of internal COT Chair/Legal Counsel for CIGB Chair
- Ratified Risk Register (including Risk 5 mitigation actions)

**Dependencies:**

- Draft PSC, COT, CIGB ToRs finalized
- Internal membership list confirmed

### 6. Project Manager executes contracts/stipends for the secured Linguistic Review Panel members (External) and facilitates their initial induction session, formally establishing advisory input for the SERB.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4 - 6

**Key Outputs/Deliverables:**

- Signed commitment letters/contracts for Linguistic Review Panel
- Linguistic Review Panel Induction Minutes

**Dependencies:**

- PSC approval of the governance structure activation timeline (Pioneer Path)

### 7. Core Operational Team (COT) mobilizes: Finalizes functional requirements for the XML/TEI dictionary platform and begins drafting core rule specifications (Ordinal Approach, Morphology Threshold protocol definitions).

**Responsible Body/Role:** Core Operational Team (COT)

**Suggested Timeframe:** Project Month 1 (by 2026-Mar-31)

**Key Outputs/Deliverables:**

- Functional Requirements Document for Dictionary Platform (XML/TEI)
- Draft rationale documents for Ordinal Standardization and Morphology Threshold (Cognitive Load)

**Dependencies:**

- PSC approval of initial resource expenditure
- Finalized Ordinal and Morphology strategies

### 8. Scientific & Editorial Review Board (SERB) holds its *Inaugural Working Session* to review the initial rule drafts, focusing on coherence between Ordinal and Morphology strategies, and defines the protocol for assessing 'naturalness'.

**Responsible Body/Role:** SERB (Chaired by Linguistic Review Panel Chair)

**Suggested Timeframe:** Project Month 2 (by 2026-Apr-30)

**Key Outputs/Deliverables:**

- SERB Review Feedback Summary on Draft Rules v0.2
- Approved Naturalness Assessment Protocol (Risk 3 mitigation)

**Dependencies:**

- COT delivery of initial rule drafts
- Linguistic Review Panel members onboarded

### 9. Compliance and IP Governance Body (CIGB) completes its initial actions: Drafts Compliance Checklist (ISO alignment) and ratifies Pilot Data Consent Protocols for use in Phase 2.

**Responsible Body/Role:** Compliance and IP Governance Body (CIGB)

**Suggested Timeframe:** Project Month 3 (by 2026-May-31)

**Key Outputs/Deliverables:**

- Phase 1 Compliance Checklist for Rule Set v1.0
- Finalized Pilot Data Consent Forms

**Dependencies:**

- Legal Counsel sign-off on consent protocols
- SERB sign-off on ISO documentation format alignment

### 10. COT integrates SERB/Linguistic Review feedback into the rule set and initiates the Safety Critical Double-Blind Review (SCDBR) for the top 500 lexicon terms (Risk 5 mitigation).

**Responsible Body/Role:** Core Operational Team (COT)

**Suggested Timeframe:** Project Month 6 - 10

**Key Outputs/Deliverables:**

- Reference Dictionary Draft Structure (incorporating SCDBR findings)
- Grapheme-to-Phoneme Mapping finalized v1.0

**Dependencies:**

- SERB feedback incorporated into rules
- Completion of core 5,000 word lexicon mapping

### 11. SERB conducts formal final review checkpoint for Phase 1 deliverables (Rule Set, Dictionary Structure), issuing a binding technical approval signal required for transition to Phase 2.

**Responsible Body/Role:** Scientific & Editorial Review Board (SERB)

**Suggested Timeframe:** End of Phase 1 (2027-Jan-31)

**Key Outputs/Deliverables:**

- Binding Technical Approval of Clear English Standard component Drafts
- Finalized Rationale Documentation for v1.0

**Dependencies:**

- Completion of SCDBR and Lexicon validation
- COT finalization of Style Guide draft

### 12. Project Steering Committee (PSC) holds the Gate 1 Review for Phase Transition: accepting Phase 1 deliverables and formally authorizing the $875k budget release for Phase 2 (Pilot Execution).

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Month 12 (2027-Jan-31)

**Key Outputs/Deliverables:**

- Phase 1 Completion Sign-off
- Authorization of Phase 2 Budget Release

**Dependencies:**

- SERB Binding Technical Approval
- CIGB approval of pilot data readiness

### 13. COT manages the allocation of the $40k parser development budget (Risk 2 mitigation) and coordinates with selected pilot partners to build/validate the ordinal integration Proof of Concept (PoC).

**Responsible Body/Role:** Core Operational Team (COT)

**Suggested Timeframe:** Project Month 13 - 18

**Key Outputs/Deliverables:**

- Ordinal Integration PoC operational and tested against standard text processors
- Phase 2 Pilot Infrastructure established

**Dependencies:**

- Phase 2 Budget Authorization
- Finalized Ordinal Strategy (numeric markers)

### 14. COT oversees the development and rigorous testing of the Pilot Curriculum materials, ensuring alignment with Grapheme maps and addressing the dual cohort needs (ESL/Technical). Pilot materials printing (FSC certified) commences.

**Responsible Body/Role:** Core Operational Team (COT)

**Suggested Timeframe:** Project Month 14 - 20

**Key Outputs/Deliverables:**

- Final Pilot Curriculum Materials (Print & Digital)
- Pilot Assessment Framework calibrated against 85/90 metric

**Dependencies:**

- Completion of core Phase 1 rule set (SERB Sign-off)
- CIGB sign-off on data handling for pilot cohorts

### 15. Pilot Cohorts commence testing. COT monitors data pipeline integrity, and the Head of Pilot Coordination feeds real-time qualitative feedback (especially performance against the 'naturalness' score) to the SERB.

**Responsible Body/Role:** Head of Pilot Coordination (via COT)

**Suggested Timeframe:** Project Month 19 - 28

**Key Outputs/Deliverables:**

- Raw pilot performance data collected (Error rates, Retention Scores)
- Bi-weekly Naturalness Score tally (for SERB review)

**Dependencies:**

- Pilot Curriculum deployment
- Established data collection systems validated (Risk 5)

### 16. SERB reviews preliminary data periodically. If the naturalness score falls below 7/10 (Issue 2 trigger), the SERB authorizes the Project Director to release up to $150k from the Phase 2 Aesthetic Refinement budget to initiate targeted refinement sprints.

**Responsible Body/Role:** Scientific & Editorial Review Board (SERB)

**Suggested Timeframe:** Ongoing during Phase 2 Pilot (Month 19 onwards)

**Key Outputs/Deliverables:**

- Refinement Sprint Authorization Notice (if required)
- Budget reallocation documentation provided to PSC

**Dependencies:**

- Pilot naturalness data available
- PSC authorization for conditional budget release (Issue 2 mitigation)

### 17. SERB conducts final evaluation of all Phase 2 metrics against the Go/No-Go criteria (85/90 comprehension, ordinal error rate < 5%). SERB issues its binding recommendation to the PSC.

**Responsible Body/Role:** Scientific & Editorial Review Board (SERB)

**Suggested Timeframe:** End of Phase 2 (Month 24 target)

**Key Outputs/Deliverables:**

- Binding Go/No-Go Recommendation Report
- Summary of pilot outcomes and remaining risks for Phase 3

**Dependencies:**

- Completion of 30-day retention measurement phase
- Linguistic Review Panel review of final pilot data

### 18. Project Steering Committee (PSC) holds the Gate 2 Review (Go/No-Go Decision Point). Based on SERB recommendation, the PSC casts the final binding vote on proceeding to Phase 3 and publishes the decision.

**Responsible Body/Role:** Project Steering Committee (PSC) (Senior Executive Sponsor casts tie-breaker)

**Suggested Timeframe:** Month 25

**Key Outputs/Deliverables:**

- Formal Go/No-Go Decision Documentation
- If 'No-Go': Deactivation plan for Phase 3 resources/remediation plan.

**Dependencies:**

- SERB Binding Go/No-Go Recommendation

### 19. If Go decision is affirmed, COT transitions final v1.0 rule set and corpus to Phase 3 Licensing/Outreach team, and CIGB finalizes the Public Licensing Policy framework for immediate release.

**Responsible Body/Role:** COT and CIGB

**Suggested Timeframe:** Month 26

**Key Outputs/Deliverables:**

- Finalized Standard Reference Package for Launch
- Public Licensing Policy v1.0 published

**Dependencies:**

- PSC Go Decision

### 20. Phase 3 execution: Outreach activities commence (targeting ISO/Standards bodies and publishers). PSC authorizes release of Phase 3 budget ($875k) contingent upon securing Letters of Intent covering 150% of post-project operational costs (Issue 1 mitigation).

**Responsible Body/Role:** Project Steering Committee (PSC) and Outreach Lead (via COT)

**Suggested Timeframe:** Month 27 - 36

**Key Outputs/Deliverables:**

- Signed LOIs meeting financial threshold
- Phase 3 operational budget expenditure tracking report
- Limited-scope adoption agreements signed

**Dependencies:**

- PSC Go Decision
- Final v1.0 Standard Package availability

### 21. Final Project Closure: PSC reviews final budget reconciliation and project delivery success against all stated goals over the 36-month period.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Month 36 (End of Program)

**Key Outputs/Deliverables:**

- Final Project Closure Report
- Archived Governance Sign-off Records

**Dependencies:**

- Completion of Phase 3 outreach activities