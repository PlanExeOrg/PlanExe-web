### 1. Project Kickoff and Charter Approval by Project Sponsor. Secure initial budget release ($1.575M for Phase 1).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Approved Project Charter
- Phase 1 Budget Release ($1.575M)
- Initial mobilization funds released

**Dependencies:**

- Project definition finalized

### 2. Project Manager (PM) initiates contracting for mandated Phase 1 Governance Support Roles (Governance Administrator, IP/Standards Lawyer, Project Scribe).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1 - 2

**Key Outputs/Deliverables:**

- Contracts initiated for 3 external Phase 1 Governance Support Roles
- Budget allocated for Governance setup (part of Phase 1 budget)

**Dependencies:**

- Project Charter and Budget Approval
- Decision 4 and Assumption 3 context

### 3. PM drafts initial Terms of Reference (ToR) for Project Steering Committee (PSC), Internal Editorial and Rule Board (IERB), External Advisory Board (ELSAB), and Pilot Assurance & Compliance Group (PACG), referencing required decision rights/mechanisms.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft ToRs for all four governance bodies (v0.1)
- Draft PSC Charter

**Dependencies:**

- Governance Structure Selection (Decision 4) confirmed via Strategic Path
- Governance Body Definitions derived from governance-phase2-bodies.json

### 4. Finalize membership list and execute appointment letters for the Project Steering Committee (PSC), chaired by the Project Sponsor.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Confirmed PSC Membership List
- Formal Chair Appointment for PSC

**Dependencies:**

- Draft PSC Charter/ToR approved

### 5. PSC formally reviews, amends, and approves the PSC Charter and the ToRs for IERB, ELSAB, and PACG. PSC authorizes convening of sub-committees.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved PSC Charter
- Approved ToRs for IERB, ELSAB, PACG (v1.0)
- Formal mandate issued to establish IERB, ELSAB, PACG

**Dependencies:**

- Draft ToRs reviewed
- PSC formally constituted

### 6. Internal Editorial and Rule Board (IERB) Chair (Project Director) convenes contracted Governance Support roles and establishes internal version control protocols for 'Clear English Standard v1.0'.

**Responsible Body/Role:** Project Director (IERB Chair)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- IERB Kick-off Meeting Minutes
- v1.0 Rule Documentation Platform established
- Rules definition timeline developed

**Dependencies:**

- IERB ToR approved
- Governance Support Roles contracted

### 7. IERB drafts operational ToR, defining segregation of duties from ELSAB and leading Phase 1 linguistic work streams (Ordinals, Morphology, Lexicon foundation).

**Responsible Body/Role:** Internal Editorial and Rule Board (IERB)

**Suggested Timeframe:** Project Week 5 - 6

**Key Outputs/Deliverables:**

- IERB Operational ToR v1.0
- Phase 1 Work Breakdown Structure finalized

**Dependencies:**

- IERB Kick-off Meeting completed

### 8. ELSAB Chair is nominated and external members are onboarded by Governance Administrator. ELSAB defines consensus voting protocols and initial review schedule.

**Responsible Body/Role:** Governance Administrator (supported by IERB)

**Suggested Timeframe:** Project Week 6 - 8

**Key Outputs/Deliverables:**

- Confirmed ELSAB Chair
- ELSAB Consensus Protocol Document
- MOU with standards body targeted (Assumption 4)

**Dependencies:**

- ELSAB ToR approved
- Hiring of Governance Administrator

### 9. PACG Chair (Compliance Officer) finalizes Data Privacy Protocols and secures ethical/regulatory approvals for international pilot cohorts (Boston, London, Geneva).

**Responsible Body/Role:** Pilot Assurance & Compliance Group (PACG)

**Suggested Timeframe:** Project Week 8 - 12 (Early Phase 1)

**Key Outputs/Deliverables:**

- Approved International Data Privacy Protocols
- Ethical Review Board Approvals Secured
- Facility readiness check initiated for testing sites (Assumption 6)

**Dependencies:**

- PACG fully constituted
- Location selection finalized

### 10. IERB drafts foundational rule packages based on confirmed strategic choices (Ordinal Approach, Morphological Threshold) and delivers initial review package to ELSAB.

**Responsible Body/Role:** Internal Editorial and Rule Board (IERB)

**Suggested Timeframe:** Project Month 2 - 4

**Key Outputs/Deliverables:**

- Draft Ordinal Standardization Rule Set
- Draft Morphological Regularization Policy
- First ELSAB Review Package

**Dependencies:**

- Strategic Decisions finalized
- IERB operational

### 11. ELSAB conducts formal review of foundational rule packages, focusing on alignment with intelligibility constraints and international standards compatibility.

**Responsible Body/Role:** External Linguistics & Standards Advisory Board (ELSAB)

**Suggested Timeframe:** Project Month 4 - 5

**Key Outputs/Deliverables:**

- ELSAB Feedback Report on Rule Packages
- Endorsement/Rejection of Ordinal Approach (If required)

**Dependencies:**

- First ELSAB Review Package received

### 12. IERB incorporates ELSAB feedback on foundational rules and finalizes the initial structure of the Reference Dictionary (Core Lexicon mapping strategy).

**Responsible Body/Role:** Internal Editorial and Rule Board (IERB)

**Suggested Timeframe:** Project Month 5 - 7

**Key Outputs/Deliverables:**

- Reference Dictionary Specification v1.0
- Updated Rule Package v0.5

**Dependencies:**

- ELSAB Feedback Report

### 13. IERB develops the first draft of the Style Guide, applying finalized rules for ordinals and morphology, in preparation for Phase 2 curriculum use.

**Responsible Body/Role:** Internal Editorial and Rule Board (IERB)

**Suggested Timeframe:** Project Month 7 - 9

**Key Outputs/Deliverables:**

- Draft Style Guide v0.5
- First draft of Disambiguation Markers based on Decision 8

**Dependencies:**

- Rule Package v0.5 approval

### 14. PSC holds governance review checkpoint: Review IP Status (Risk 1) and confirm readiness to transition funding focus from Rule Specification to Pilot Execution.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** 2027-Jan-01 (To meet MOU target)

**Key Outputs/Deliverables:**

- Status Report on MOU/IP Engagement (Risk 1)
- Go Checkpoint on Phase 1 completion readiness

**Dependencies:**

- MOU target achieved (Assumption 4)
- Phase 1 technical definition 50% complete

### 15. IERB drafts the initial Pilot Curriculum materials based on the Draft Style Guide, coordinating with Instructional Designer.

**Responsible Body/Role:** Internal Editorial and Rule Board (IERB)

**Suggested Timeframe:** Project Month 10 - 12

**Key Outputs/Deliverables:**

- Pilot Curriculum Draft v1.0 (Print & Digital)
- Assessment Instruments calibrated to Go/No-Go Metrics (Decision 5)

**Dependencies:**

- Draft Style Guide v0.5 complete

### 16. IERB coordinates with ESL Publisher partners to secure Letters of Intent (LOI) for Phase 2 pilot integration (Risk 4 mitigation).

**Responsible Body/Role:** Internal Editorial and Rule Board (IERB)

**Suggested Timeframe:** Project Month 11 - 12

**Key Outputs/Deliverables:**

- LOIs secured from targeted ESL publishers
- Lighthouse Partnership identified for technical validation

**Dependencies:**

- Draft Style Guide available for partner review

### 17. PSC formally approves Phase 1 completion (2027-May-02) and authorizes release of Phase 2 Budget ($1.225M). Governance shifts focus to Pilot Execution and Assurance.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** 2027-May-02 (Project Month 12)

**Key Outputs/Deliverables:**

- Phase 1 Completion Certificate
- Phase 2 Budget Release ($1.225M)
- Finalized 'Clear English Standard v1.0' Rule Set (Locked for V1.0)

**Dependencies:**

- Rule Set definition substantially complete
- Pilot Curriculum ready for deployment

### 18. PACG validates the physical testing infrastructure (labs/network) in Boston, London, and Geneva, ensuring standardization/security compliance (Assumption 6).

**Responsible Body/Role:** Pilot Assurance & Compliance Group (PACG)

**Suggested Timeframe:** Project Month 12 - 14 (Early Phase 2)

**Key Outputs/Deliverables:**

- Validation Report on International Testing Facilities
- Go-ahead for participant recruitment

**Dependencies:**

- Phase 1 completion
- Budget release for Phase 2 operations

### 19. IERB launches parallel pilot tests with English ESL and Native Technical Writer cohorts across all sites, using finalized curriculum and assessments.

**Responsible Body/Role:** Internal Editorial and Rule Board (IERB)

**Suggested Timeframe:** Project Month 14 - 20

**Key Outputs/Deliverables:**

- Raw Test Data Logs (Comprehension Speed, Ordinal Error Rates)
- Interim Pilot Feedback Logs

**Dependencies:**

- PACG Validation Report
- Pilot materials distributed

### 20. PACG conducts ongoing audits of pilot data integrity and participant ethics compliance throughout the testing period.

**Responsible Body/Role:** Pilot Assurance & Compliance Group (PACG)

**Suggested Timeframe:** Project Month 14 - 24 (Ongoing)

**Key Outputs/Deliverables:**

- Bi-weekly Data Integrity Reports
- Alerts issued to IERB/PSC regarding potential severe compliance breaches

**Dependencies:**

- Pilot testing active

### 21. ELSAB reviews initial pilot data trends (at Month 18), providing pre-assessment advisory on metric interpretation, specifically regarding the 14-day ESL comprehension constraint (Risk 5 mitigation).

**Responsible Body/Role:** External Linguistics & Standards Advisory Board (ELSAB)

**Suggested Timeframe:** Project Month 18

**Key Outputs/Deliverables:**

- Preliminary Data Interpretation Advisory Memo
- Recommendations for pre-Go/No-Go adjustments to IERB

**Dependencies:**

- Initial Pilot Data available

### 22. IERB uses interim feedback (especially on ordinal error rates/Risk 2 contingency) to finalize the Reference Dictionary and produce the final 'Clear English Standard v1.0' Rule Set and Style Guide (Deliverables 1 & 3).

**Responsible Body/Role:** Internal Editorial and Rule Board (IERB)

**Suggested Timeframe:** Project Month 20 - 23

**Key Outputs/Deliverables:**

- Final Reference Dictionary (Deliverable 2)
- Clear English Standard v1.0 (Final Draft)

**Dependencies:**

- Interim Pilot Feedback incorporation

### 23. PACG compiles the comprehensive final Pilot Data Report mapping all results directly against the Go/No-Go Metrics (Risk 5 validation).

**Responsible Body/Role:** Pilot Assurance & Compliance Group (PACG)

**Suggested Timeframe:** Project Month 24

**Key Outputs/Deliverables:**

- Final Raw Data and Compliance Report
- Formal Recommendation on Phase 3 Progression (Go/No-Go)

**Dependencies:**

- Pilot testing concluded

### 24. ELSAB conducts final review of the consolidated Standard Package (Rules, Dictionary, Style Guide) against its mandate for legitimacy and consensus endorsement.

**Responsible Body/Role:** External Linguistics & Standards Advisory Board (ELSAB)

**Suggested Timeframe:** Project Month 24 - 25

**Key Outputs/Deliverables:**

- Formal ELSAB Endorsement of Standard v1.0
- Final Report on Legitimacy and Consensus Achievement

**Dependencies:**

- Final Standard Package delivered
- PACG Final Report available

### 25. PSC convenes for the mandatory Phase 2 Go/No-Go Decision, based on PACG report and ELSAB endorsement. Authorizes or denies transition to Phase 3 and release of Phase 3 Budget ($700K).

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Month 25

**Key Outputs/Deliverables:**

- Formal Go/No-Go Decision Document
- Phase 3 Budget Authorization (if 'Go')

**Dependencies:**

- PACG Final Report
- ELSAB Endorsement

### 26. Upon 'Go' decision, IERB finalizes the Public Licensing Policy (Deliverable 5) and initiates development of the software Style Checker module (Assumption 3).

**Responsible Body/Role:** Internal Editorial and Rule Board (IERB)

**Suggested Timeframe:** Project Month 26 - 28

**Key Outputs/Deliverables:**

- Public Licensing Policy Finalized
- Style Checker Software Development Commenced

**Dependencies:**

- PSC Phase 3 Authorization

### 27. Project Management Office (under PSC oversight) initiates Outreach Strategy (Decision 10): Launch public publication of Standard v1.0, begin Lighthouse Partnership technical integration, and activate ESL publisher commitments.

**Responsible Body/Role:** Project Steering Committee (PSC) / Project Manager

**Suggested Timeframe:** Project Month 28 - 30

**Key Outputs/Deliverables:**

- Clear English Standard v1.0 formally published
- Licensing documentation active
- Lighthouse Partnership implementation review scheduled

**Dependencies:**

- Standard v1.0 finalized and approved
- Phase 3 Budget released

### 28. IERB initiates tasks for v2.0 rule refinement, prioritizing input gathered during Phase 3 outreach, ensuring v1.0 stability is maintained for one year post-launch.

**Responsible Body/Role:** Internal Editorial and Rule Board (IERB)

**Suggested Timeframe:** Project Month 30 - 36 (Ongoing)

**Key Outputs/Deliverables:**

- v2.0 Scoping Document
- Post-launch Adoption Feedback Analysis

**Dependencies:**

- Standard v1.0 launch