# Purpose
# Clear English Project Plan

## Purpose

- Developing a new, standardized variant of English ('Clear English') for professional/educational use (e.g., technical writing, ESL).
- Large-scale project for professional standardization and education infrastructure improvement.

## Topic

- Creation and implementation plan for a standardized, consistent variant of English ('Clear English').


# Domain
# Project Planning Summary

## Rationale and Domains

- Primary domain: Standards Development
- Secondary domains: Linguistics, Curriculum Development, Applied Phonetics
- Rationale: Success criterion is publishing 'Clear English Standard v1.0' in Phase 3. Lexicography and Linguistics are inputs; Standard is the product.

## Disciplines Involved

- Linguistics (5/5): Defines formal linguistic rules (outcome).
- Applied Phonetics (5/5): Defines consistent grapheme-to-phoneme mapping (method).
- Lexicography (5/5): Creating reference dictionary/defining core lexicon (outcome).
- Standards Development (5/4): Goal is publishing a formal public standard document (outcome).
- Technical Writing (4/5): Targeted professional field for adoption (market).
- Educational Assessment (5/4): Defines and executes metrics (comprehension speed/retention) (method).
- Standardization Engineering (5/4): Goal is defining and publishing a formal, parallel standard (outcome).
- Curriculum Development (4/4): Developing learning materials/testing pilot usability (method).
- Instructional Design (4/4): Developing pilot curriculum and assessments (method).


# Plan Type
# Project Classification

- Requires one or more physical locations.
- Cannot be executed digitally.

## Rationale

- Multi-year, structured definition, testing, and publication process for a new linguistic standard ('Clear English Standard v1.0').
- Execution requires extensive physical activities:

    - Securing/maintaining a physical workspace for the editorial board and linguists.
    - Physically printing and distributing pilot curriculum materials.
    - Organizing in-person testing cohorts (requiring physical presence for administration/monitoring).
    - Potentially holding physical steering committee meetings.

- Development of learning materials (curriculum) implies physical setup and distribution management.
- Classified as physical due to detailed governance, budget allocation, physical review cycles, and creation of tangible educational assets (print curriculum).


# Physical Locations
# Project Planning: Physical Locations

## Requirements for physical locations

- Space for editorial board and linguistic team collaboration (Phase 1 & 2)
- Facilities for in-person pilot testing cohorts (ESL & technical users)
- Secure environment for managing confidential rule sets and budget oversight
- Proximity to potential academic partners or ESL/technical publishers

## Location 1
USA - Boston, Massachusetts / Cambridge Area

- Co-working/office space near MIT/Harvard linguistics or education departments.
- Rationale: Global hub for linguistic research; strong ties to ESL education/technical writing; supports 'Builder's Foundation' pilot and outreach.

## Location 2
UK - London, England

- Flexible office space near major universities or established publishing houses.
- Rationale: Access to native English speakers for pilot testing validation; strong academic/editorial infrastructure for governance setup.

## Location 3
Switzerland - Geneva / Zurich

- Neutral, quiet location for international advisory board meetings.
- Rationale: Neutral, internationally respected location for hosting external advisory board meetings required by consensus-driven Governance Structure.

## Location Summary
Three locations suggested due to requirements for physical execution (governance, development, pilot testing). Boston for academic synergy/pilot proximity; London for publishing/linguistic connections; Geneva/Zurich for neutral advisory board site.

# Currency Strategy
## Currencies

- USD: Primary budgeting currency; staff compensation (US). Budget total $3.5M.
- GBP: Local currency (UK/London) for transactions, payroll, pilot expenses.
- CHF: Local currency (Switzerland/Geneva/Zurich) for advisory board costs.

Primary currency: USD

Currency strategy: Use USD for consolidated budgeting/contingency. Payments for local expenses (GBP, CHF) should use low-fee rails; consider slight hedging against USD fluctuation for multi-year budget cycles.

# Identify Risks
## Risk 1 - Regulatory & Permitting
Lack of international recognition or IP protection for 'Clear English Standard v1.0'. Standardization based on consensus lacks regulatory mandate, risking unauthorized modification (fragmentation).
Impact: Competing variants undermine integrity. 3-6 month delay in Phase 3 for IP/standards engagement.
Likelihood: Medium
Severity: High
Action: Establish legal/IP workstream in Phase 1 for copyright/trademark protection (US, UK/EU). Engage international standards bodies or seek formal institutional endorsement.

## Risk 2 - Technical
Inconsistent application/ambiguity from Ordinal Standardization Approach (e.g., '1r' vs. spelled out). Compact marker system risk misinterpretation if style guide is not strictly enforced.
Impact: Increased ordinal error rates in Phase 2, potentially triggering 'No-Go'. High-consequence errors post-launch.
Likelihood: Medium
Severity: High
Action: Phase 2 metric targets ordinal marker legibility vs. standard English convention. Contingency: If error rates high, authorize fallback to Decision Strategy 3 (Style Guide deferral/limited spelling).

## Risk 3 - Financial
Budget overruns due to high consultation costs from consensus-driven Governance Structure. $3.5M budget is tight for international operations, physical testing, and expert review.
Impact: Phase 3 outreach/licensing underfunded. Requires $300,000-$500,000 overrun, potentially forcing cancellation of public licensing.
Likelihood: High
Severity: Medium
Action: Implement Decision 6, Strategy 3: Reserve 20% contingency ($700k) managed centrally. Cap external advisor compensation; prioritize remote collaboration over in-person meetings.

## Risk 4 - Social
Pushback from educators/native speakers against morphological regularization, risking rejection despite 'parallel standard' goal.
Impact: Outreach failure, ESL publisher rejection, low adoption. Negative media criticism late in Phase 3.
Likelihood: High
Severity: Medium
Action: 'Builder's Foundation' retains conservative Morphological Regularization Threshold. Emphasize 'parallel standard' messaging. Develop case study rebuttals showing retention of high-frequency irregularities minimizes friction.

## Risk 5 - Operational
Failure to meet the two-week intelligibility benchmark in Phase 2 pilots (Decision 5 'No-Go'). Caused by aggressive regularization or complex homograph markers.
Impact: Project termination or restructuring after 24 months. $3.5M budget loss as Phase 3 launch blocked.
Likelihood: Medium
Severity: High
Action: Prioritize the 14-day comprehension metric. Mitigation relies on parallel pilot cohort structure (Decision 3, Strategy 2) to rapidly identify cognitive slowdown source for targeted rule refinement.

## Risk 6 - Supply Chain
Delays/cost fluctuations for physical assets: Pilot curriculum (print) and reference materials across international sites (Boston, London, Geneva).
Impact: 4-8 week delay in Phase 2 pilot launch if print/distribution bottlenecks occur, impacting Go/No-Go timeline.
Likelihood: Medium
Severity: Medium
Action: Phase 1: Secure firm contracts with international print vendors, ensuring capacity buffers. Define digital distribution (PDF/eBook) as primary backup for materials.

## Risk 7 - Integration/Sustainability
Scope creep/fragmentation due to consensus-driven Governance Structure. Boards may propose additions or re-address Phase 1 rules, causing timeline drift.
Impact: Phase 1 extends to 15-18 months, compressing testing/publication. Forces budget draw-down or compromises rule quality.
Likelihood: High
Severity: Medium
Action: Define governance authority boundaries *before* Phase 1 completion. Only Phase 1 decided rules subject to review; new areas flagged for 'v2.0' consideration to protect v1.0 schedule.

## Risk 8 - Technical
Failure to develop a minimally invasive, universally adoptable Homograph Disambiguation Policy without visual clutter or increased parsing effort.
Impact: If mandatory markers used (Decision 8, Strategy 1), friction leads to rejection. If omitted, safety documentation integrity is weakly supported.
Likelihood: Medium
Severity: Medium
Action: Initially follow Decision 8, Strategy 1 (mandatory slash-notation for top 5 pairs) for safety validation only. Favor Decision 8, Strategy 3 (optional, minimal diacritics) for general style. Phase 2 must test cognitive load of mandatory markers.

## Risk summary
Key risks center on validation and organizational friction from 'Builder's Foundation' choices. Highest severity: Operational Failure (2-week Intelligibility Benchmark). Highest combined risk: Social Pushback/Educator Rejection due to fundamental English changes. Third critical concern: Financial Strain from consensus governance consultation costs. Mitigation requires focus on rigorous validation (Operational), managing stakeholder expectations (Social), and stringent budget control (Financial). Parallel pilots mitigate Operational Risk and provide data for Social Risk governance reviews.

# Make Assumptions
## Question 1 - Proposed Budget Allocation Split ($3.5M Total)

- Strategy 6.1: 45/35/20 split.
- Phase 1 (Specification): 45% ($1.575M) - Highest proportion for specialized linguistic talent/corpus.
- Phase 2 (Pilot): 35% ($1.225M) - Covers physical pilot execution/curriculum distribution.
- Phase 3 (Launch): 20% ($700K) - Ring-fenced for outreach/licensing, addressing Financial Risk (Risk 3).

## Question 2 - Target Completion Date for Phase 1 Rule Specification

- Start Date: 2026-May-03.
- Phase 1 Duration: Exactly 12 calendar months.
- Target Completion Date: 2027-May-02.
- Rationale: Fixed duration required for sequential gating and consensus-driven Governance (Decision 4).
- Risk Management: PM must enforce 12-month limit to prevent slippage into Phase 2 dependencies if advisory board delays rule acceptance (Risk 7).
- Success Metric: 95% rule finalization by 2027-May-02.

## Question 3 - Specific Roles Contracted in Phase 1 for Governance

- Decision 4 (Consensus Governance) requires three external roles in Phase 1:
- Dedicated Governance Administrator: To manage advisory board logistics/minutes.
- Specialist in Intellectual Property/Standards Law: To handle Risk 1.
- Dedicated Project Scribe/Liaison: To manage communication flow between team and board.
- Funding Note: IP/Legal expertise must be funded within Phase 1 budget; 75% of $700K contingency should cover these high-rate consultants.

## Question 4 - Formal Mechanism for IP Compliance and Endorsement (Risk 1)

- Mechanism: Establish a memorandum of understanding (MOU) during Phase 1 with a recognized national linguistic standards body.
- Purpose: Obtain provisional 'vetted draft' status for 'Clear English Standard v1.0'.
- Rationale: Proactive engagement mitigates Regulatory Vacuum risk (Risk 1) and boosts legitimacy for outreach (Decision 10).
- Success Metric: Signed MOU by 2027-Jan-01.

## Question 5 - Quantifying/Mitigating High-Consequence Errors (Risk 2)

- Approach: Ordinal Standardization Approach (numeric + single-character suffix, e.g., '1r') flagged as high-risk.
- Mitigation: Dedicated Phase 2 testing track focused exclusively on safety-critical glossaries (Decision 3).
- Target: Ordinal error rate below 0.5% in this cohort.
- Contingency (Risk 2 Mitigation): If threshold exceeded, prepare alternative Style Guide format (Decision 3, Strategy 3) for rapid deployment in Phase 2 refinement.

## Question 6 - Physical Environmental Controls for Testing Locations (Boston, London, Geneva)

- Requirement: Standardized, controlled environment computer labs (or equivalent quiet spaces) in all three locations.
- Infrastructure: Dedicated, high-speed, localized network access for digital assessments.
- Rationale: Minimizing external variables (Noise/Risk 5) is critical for measuring comprehension speed within the target 14-day window.
- Timeline: Securing and validating physical lab spaces must occur during the latter half of Phase 1.
- Budget Note: Phase 2 budget must account for $150,000 across sites for standardization software licenses/local hardware maintenance.

## Question 7 - Engaging ESL Publishers/Partners to Counter Social Pushback (Risk 4)

- Strategy (Decision 10): Focus on securing one foundational ESL publisher commitment.
- Phase 1 Target: Define morphological stability of initial 1,000 most common words.
- Engagement Loop: Provide early draft style guides in exchange for formal Letter of Intent (LOI) for pilot integration.
- Goal: Securing LOI by end of Phase 2 (2028-May-02) demonstrates market desire and counters Risk 4.

## Question 8 - Provisions for Multi-Currency Flow and Physical Logistics (US, UK, Switzerland)

- Provision: Dedicated 5% contingency within the Operation Systems budget (part of $700K total contingency).
- Allocation: $35,000 ring-fenced for foreign exchange hedging and international shipping/logistics insurance premiums.
- Mitigation: Directly mitigates Risk 6 (Supply Chain delays) and supports physical hosting requirements across locales.


# Distill Assumptions
# Project Plan Summary

## Budget & Funding

- Total Budget: $3.5M
- Allocation: Phase 1 (45%), Phase 2 (35%), Phase 3 (20%)
- Contingency: 5% for international logistics/currency hedging.

## Timeline & Milestones

- Phase 1 Duration: 12 months, ending 2027-May-02.
- Legal Compliance: MOU with standards body by 2027-Jan-01.

## Technical & Scope Requirements

- Ordinal Suffix: Single-character ('1r') for numeric compactness.
- Morphology: Basic plural nouns isolated; verbs fully regularized.
- Lexicon Update: Prioritize near-regular standard English words for phonetic consistency.
- Safety Critical Pilot Error Rate: < 0.5% ordinal error rate.
- Phase 3 Launch Metric: Comprehension time < 14 days in pilot assessments.

## Governance & Legal

- Consensus Governance: Requires three external roles contracted immediately in Phase 1.
- Advisory Board: External body using formal majority voting for consensus.

## Testing & Partnerships

- Pilot Testing: Requires standardized, controlled lab environments across three international locations.
- Pilot Tracks: Parallel tracks for adult ESL and native technical writers.
- Partnership Goals:

    - Foundational ESL publisher commitment (LOI) targeted by end of Phase 2.
    - One Lighthouse Partnership secured for technical documentation validation.

# Review Assumptions
## Domain of the expert reviewer
Strategic Risk Management & Project Viability Assessment

## Domain-specific considerations

- Linguistic Standardization Viability
- Adoption Rate of Novel Constructs
- Multi-jurisdictional Operational Logistics (Physical/Financial)
- Interplay between Linguistic Purity and Intelligibility Metrics

## Issue 1 - Missing Assumption on Core Lexicon Substitution Cost/Effort
Plan regularizes verbs but uses a conservative approach to the 5,000-word core lexicon (Decision 9, Strategy 1). Implies significant substitution for irregular words.

- Missing assumption: Quantification of substitution labor/cost for rewriting, pronunciation mapping, and dictionary generation (Phase 1). Impacts Phase 1 budget/timeline.

Recommendation:

- Develop assumption quantifying expected lexical substitution rate (e.g., '15% of 5,000 core words require remapping').
- Budget Phase 1 consulting rate based on this, explicitly costing effort (X hours at $Y/hour per word).

Sensitivity:

- 25% substitution rate vs. assumed low rate increases Phase 1 linguistic consulting budget by $200,000 - $450,000, or extends duration by 1.5 to 3 months, threatening the 2027-May-02 deadline. ROI reduced by 5-10%.

## Issue 2 - Unrealistic Assumption: Guaranteed Feasibility of 14-Day Intelligibility Benchmark for ESL Cohorts
'Builder's Foundation' hinges on strict '2-week intelligibility' (14-day No-Go metric) for regularization. 14 days for adult ESL learners learning fundamental shifts is potentially unrealistic. Assumes perfect curriculum design with zero cognitive overhead from other changes.

Recommendation:

- Revise Decision 5 (Go/No-Go metric) to include a tiered definition for ESL vs. Native speakers. Example revision: 'If ESL cohort comprehension time > 18 days OR Native cohort speed degradation > 10% vs. baseline.'
- Establish assumption that curriculum design complexity is lower than estimated, based on second language acquisition benchmarks.

Sensitivity:

- If ESL time shifts to 21 days, current metric triggers 'No-Go' (Risk 5). Causes total project failure (100% ROI loss) or mandates 6-9 month remediation extension, costing $400,000 - $650,000 in Phase 2.

## Issue 3 - Missing Assumption Regarding Technological Platform for Rule Enforcement and Scalability
Plan assumes physical execution but lacks explicit assumption on the technology platform for scaling enforcement (linter/style checker) of 'Clear English Standard v1.0' across digital workflows.

Recommendation:

- Add explicit assumption: 'A proprietary, automated Style Checker software module will be developed during Phase 2 (costed in 35% budget) to enforce v1.0 rules, integrating upon pilot conclusion. Success relies on utilizing existing syntax parsing platforms.'

Sensitivity:

- If proprietary software development is required, Phase 2 cost inflates by $150,000 - $300,000. Delay until Phase 3 drops adoption rates by 30-50% for technical users, delaying ROI realization by 12-18 months.

## Review conclusion
Plan requires pragmatic balance but misses critical dependencies or relies on optimistic assumptions. Gaps: quantifying lexical substitution labor (Missing Assumption 1), empirical feasibility of 14-day ESL target (Unrealistic Assumption 2), and plan for digital enforcement (Missing Assumption 3). Failure to address morphological remapping complexity and tight learning constraint risks immediate project termination via Governance Go/No-Go metrics.