# Purpose
# Project Plan: Clear English Standardization

## Purpose

- Strategic planning and execution for developing a new standardized language variant.
- Intended for technical documentation, education, and ESL instruction.
- Large-scale, formal project creating a specialized, auditable standard for societal use.
- Aligning with business/professional project management and standardization efforts.

## Topic

- Development and controlled rollout of a standardized, simplified variant of English ('Clear English').


# Plan Type
# Project Classification

- Physical

## Rationale

- Involves development, standardization, material creation (corpus, dictionary, curriculum).
- Requires piloting and governance setup for 'Clear English'.
- Needs human effort, physical infrastructure (offices, computing, meeting spaces).
- Requires physical creation/testing of print/pilot materials.
- Governance setup, corpus creation, local cohort piloting, and formal publishing require physical presence.


# Physical Locations
# Project Planning - Physical Locations

## Requirements for physical locations

- Space for governance meetings (Editorial Board, Linguistic Review)
- Facilities for developing/hosting computer resources for corpus management
- Proximity to potential pilot cohort testing sites (adult ESL centers/tech doc firms)
- Access to administrative/professional support staff

## Location 1

- USA: Washington D.C. / Northern Virginia (NoVA)
- Space: Flexible Office Space near Federal Triangle or Rosslyn area
- Rationale: High density of standards organizations (NIST, ANSI), strong technical writing industry presence, accessibility for linguistic experts/policy meetings.

## Location 2

- United Kingdom
- Space: London Metropark Area (Co-working space like Shoreditch/Tech City)
- Rationale: Access to global linguistic talent, strong presence of major ESL publishing houses, established mechanisms for international standards development.

## Location 3

- USA: Southeastern US (e.g., Atlanta or Raleigh-Durham)
- Space: University Research Park Proximity
- Rationale: Lower operational cost than D.C./NYC; excellent access to major universities with strong Applied Linguistics for recruitment/pilot feedback.

## Location Summary
A centralized operational hub is necessary for governance, infrastructure, pilot coordination, and standards interaction. Recommended locations: D.C. area (standards access), London (global reach/publishing), and a lower-cost US research hub (recruitment/efficiency) to support Phase 1 and Phase 2.

# Currency Strategy
# Currencies

- USD: Project budget ($3.5M), default accounting currency (USA hubs).
- GBP: Required for London, UK hub (space, local staff).

Currency strategy: Budget is $3.5M USD. UK expenditures (GBP) must convert from USD budget, using forward contracts or timing to mitigate rate fluctuations over three years.

# Identify Risks
## Risk 1 - Financial

- Strategy: 'Pioneer' front-loads 50% ($1.75M) of $3.5M budget into Phase 1 for linguistic definition.
- Risk: Phase 2/3 ($1.75M) is constrained; overrun in Phase 1 impacts pilot/launch funding.
- Impact: Overrun > $200k (5.7% total) forces cuts to Phase 2 scope/rigor, invalidating Go/No-Go metrics or compromising Phase 3 outreach.
- Likelihood: Medium
- Severity: High
- Action: Implement rigorous EVM for Phase 1 deliverables. Allocate $350k (10% total) contingency released only post Phase 1 sign-off, forcing operation on a strict $3.15M basis.

## Risk 2 - Technical/Linguistic

- Approach: Ordinal Standardization uses numeric + invariant markers (e.g., '5th'), creating friction in digital text processing (Decision 1).
- Risk: Failure to develop/procure required tagging/parsing tools in Phase 2 stalls adoption.
- Impact: 3–6 month integration delays in Phase 3; $50k–$100k unplanned custom software costs during Phase 2 setup.
- Likelihood: Medium
- Severity: Medium
- Action: Task technical WG in Phase 1 to define strict XML/SGML tagging standards. Allocate $40k in Phase 2 budget for specialist to develop/validate PoC integration parser for major platform.

## Risk 3 - Social/Acceptance

- Reliance: Intelligibility in 2 weeks relies on Morphology Regularization Threshold (Decision 2); prioritizing opaque irregularities.
- Risk: Large set of retained, irregular words leads to native speaker perception of 'artificiality' or ESL user frustration, causing pushback.
- Impact: Pilot cohorts rating 'naturalness' below 6/10 reduces perceived value, derailing Phase 3 licensing efforts (zero ROI).
- Likelihood: High
- Severity: High
- Action: Prioritize cognitive load threshold (Choice 2 in Decision 2) over frequency. Include qualitative section in Phase 2 assessment focused only on perceived naturalness/aesthetic acceptance from native speakers, feeding this score into Go/No-Go (Decision 8).

## Risk 4 - Regulatory & Permitting / Governance

- Strategy: Mobilize Governance Structure early (Pioneer) by securing external Linguistic Review panel commitments in Phase 1.
- Risk: Key experts unavailable due to stipends not meeting constraints, delaying review and compromising QA foundation.
- Impact: 4–6 week delay in Phase 1 rule finalization, delaying Phase 2 start and consuming contingency funds.
- Likelihood: Medium
- Severity: Medium
- Action: Prioritize securing commitment letters alongside budget estimates for stipends. Pre-approve 'back-up' pool of three secondary reviewers authorized for immediate step-in if primaries fail contracts in 60 days.

## Risk 5 - Operational/Integration

- Requirement: Piloting involves safety-critical/technical glossaries using newly defined Core Lexicon (5,000 words) mapping to Standard English.
- Risk: Imperfect alignment or ambiguity in mapping for critical safety terms creates regulatory liability concerns.
- Impact: Errors in safety terms during Phase 2 require full corpus/curriculum iteration (6-week delay) and potential legal exposure.
- Likelihood: Low
- Severity: High
- Action: Implement mandatory 'Safety Critical Double-Blind Review' sweep in Phase 1 final month by two independent, certified domain experts reviewing the 500 highest-frequency technical terms for zero-tolerance errors.

## Risk 6 - Supply Chain / Physical Logistics

- Requirement: Phase 2 uses physical locations (D.C., London, SE US); London hub requires GBP expenditure.
- Risk: USD/GBP exchange rate volatility causes operational budget shortfalls for UK leases/support.
- Impact: Sustained 15% adverse USD/GBP shift cuts 4 months of London physical space/support staffing.
- Likelihood: Medium
- Severity: Medium
- Action: Use USD-denominated contracts for long-term staff where possible (US-based remote). Attempt fixed-rate GBP lease payments for 18 months or purchase moderate forward contracts for Phase 2 high-cost period.

## Risk 7 - Technical/Linguistic

- Strategy: Grapheme-to-Phoneme Mapping prioritizes strict clarity over phonetic diversity (Decision 6).
- Risk: Rules may be technically consistent but sound unnatural or 'monotone,' failing the 'intelligible to current English speakers' constraint.
- Impact: Perceived utility plummets if Phase 2 materials sound 'alien,' failing intelligibility goal despite comprehension scores.
- Likelihood: Medium
- Severity: Medium
- Action: Adopt Strategy 1 (strict mapping) for Phase 1 definition. Integrate Strategy 3 (optional diacritics) into Style Guide as optional enhancements for native speakers, allowing core curriculum to remain strictly phonetic.

## Risk summary

- Project faces high-leverage risks from ambitious linguistic scope constrained by tight budget/timeline.
- Critical Risks: Financial Underfunding (due to 50% Phase 1 front-loading) and Social/Acceptance Risk ('naturalness' perception). Phase 1 overrun cripples validation data generation for Go/No-Go.
- Mitigation required: Tight budgetary controls (EVM) and prioritizing qualitative 'naturalness' feedback in pilots.
- Secondary Risk: Integration Friction due to numeric ordinal markers burdens Phase 3 adoption costs.


# Make Assumptions
## Question 1 - Budget Allocation (Pioneer Strategy: 50/25/25)

- Total Budget: $3.5M
- Phase 1 (Specification/Corpus): $1.75M (50%)
- Phase 2 (Pilot/Testing): $875k (25%)
- Phase 3 (Standardization/Launch): $875k (25%)

Assessments:

- Front-loading Phase 1 is aggressive; supports linguistic purity goal.
- Phase 2 ($875k) must cover curriculum/cohort management; risk in underestimating pilot infrastructure.
- If Phase 1 > $1.8M, Phase 3 outreach budget ($875k) is threatened.

## Question 2 - Phase 1 Conclusion Milestone and Phase 2 Go/No-Go Metric

- Phase 1 Conclusion Milestone: 2027-Jan-31 (Assumes start date ASAP from 2026-Jan-31).
- Phase 2 Go/No-Go Metric: 85% of pilot participants demonstrate comprehension equivalent to 90% of the native baseline within 14 days.

Assessments:

- 3-year timeline is tight.
- Phase 1 delay > 1 month compresses Phase 2 window, jeopardizing data integrity.
- 85%/90% metric is ambitious; requires rigorous statistical validation within Phase 2 budget.

## Question 3 - Core Linguistics/Development Team Headcount (Phase 1)

- Planned Headcount (FTEs): 5 (Project Management, Senior Linguists, Technical Writers).
- Function: Corpus mapping and style guide drafting.
- External support: Specialized contractors for corpus tool development; review stipends budgeted separately.

Assessments:

- 5 FTEs plus contractors for corpus, dictionary, style guide is resource-intensive.
- If recruitment is slow, external review schedule is jeopardized, increasing contractor costs.

## Question 4 - Regulatory/Standardization Body Consultation (Phase 1)

- Body Leveraged/Consulted: Alignment with ISO standards for technical specifications (e.g., ISO/IEC Directives, Part 2) for documentation structure (versioning, change control).

Assessments:

- Alignment with ISO/IEC minimizes friction for Phase 3 writers.
- Failure to define structure risks proprietary format cumbersome for audit/integration.

## Question 5 - Ordinal Strategy Integration Risk and Phase 2 Mitigation Budget

- Baseline Risk Level (Integration with commercial publishing tools): High Impact/Medium Likelihood.
- Phase 2 Mitigation Budget Line Item (Custom parser development): $40,000 USD (from Phase 2 budget).

Assessments:

- $40k allocation must be tracked rigorously.
- Deeper incompatibility found in Phase 1 may require reallocation from Pilot Curriculum budget ($875k).

## Question 6 - Environmental/Ecological Impact Assessment for Pilot Curriculum

- Assessment Focus: Sustainable paper sourcing (FSC certification) for limited physical print runs.
- Scale assumption: Limited to 200 printed sets total across US/UK.

Assessments:

- Basic audit needed due to physical materials (Phase 2 requirement).
- Prioritize digital-first modules; use certified printers to minimize reputational risk.

## Question 7 - Industry Associations Targeted for Lexicon Scope Validation (Phase 1)

- Associations Targeted (besides ESL publishers):

    - Major global standards body (e.g., relevant committee within ISO/IEC JTC 1).
    - Major technical writing trade organization (e.g., STC).

Assessments:

- Early buy-in from standards bodies is critical for Pioneer strategy.
- Lack of support by end of Phase 1 renders Phase 3 licensing policy ineffective.

## Question 8 - Mandated Technology Platform for Reference Dictionary (Phase 1)

- Mandated Platform: Self-describing, text-based format (JSON or XML compliant with underlying TEI schema).
- Goal: Maximum portability across environments for Phase 2.

Assessments:

- Interoperable format (XML/TEI) minimizes technical debt.
- Implementation team must dedicate resources early in Phase 1 to develop robust API endpoints for dictionary connection to Phase 2 delivery system.


# Distill Assumptions
# Project Plan Summary

## Budget Allocation

- Phase 1: 50% ($1.75M)
- Phase 2: 25% ($875k)
- Phase 3: 25% ($875k)

## Timeline & Phases

- Phase 1 completion: 12 months after start (2027-Jan-31)
- Program duration: 3 years (three 12-month gated phases)

## Go/No-Go Criteria

- Decision authority: External Linguistic Review panel (post-Phase 2)
- Requirement: 85% comprehension of 90% of native baseline in 14 days.

## Team & Resources

- Core team: 5 FTEs plus contractors (Phase 1 corpus mapping)
- Phase 1: Full 5-member Linguistic Review panel secured upfront for rule review.

## Technical Specifications & Dictionary

- Documentation format: Aligns with ISO/IEC standards.
- Reference Dictionary format: Portable JSON/XML (requires early API development).
- Lexicon scope: Capped at 5,000 words with pronunciation guidance.

## Linguistic Standardization

- Ordinal standardization: One specific approach chosen (numeric marker assumed).
- Morphology changes: Subset of irregular changes regularized based on cognitive load.
- Grapheme mapping: Prioritizes strict clarity over phonetic diversity.

## Pilot & Outreach

- Pilot runs: Limited to 200 sets; focus on FSC certified sustainable sourcing.
- Pilot curriculum: Must serve ESL learners and native speakers effectively.
- Phase 1 outreach: Targets one major standards body and one technical writing organization.

## Development Goals

- Average adult comprehension goal: Equivalent to one week of exposure success.

## Risks & Mitigation

- Ordinal marker risk: High impact/Medium likelihood; $40k reserved for parser development.


# Review Assumptions
## Domain of the expert reviewer
Strategic Project Risk & Linguistic Standardization Management

## Domain-specific considerations

- Interdependency: linguistic scope (Morphology) vs. budget.
- Quantification: stakeholder acceptance (naturalness vs. correctness).
- Governance timing vs. initial IP quality.
- Managing physical execution vs. digital standardization goals.

## Issue 1 - Critical Missing Assumption: Sustainability of Adoption Infrastructure (Phase 3 Resources)

- Phase 1 front-loads 50% budget ($1.75M) for rules definition; Phase 3 launch/outreach gets only 25% ($875k).
- Assumes subsequent licensing/adoption funds operational costs, but no explicit guarantee exists for sustaining standard post-$3.5M funding. Risk of obsolescence if adoption is low.

Recommendation:

- Introduce mandatory Phase 2 metric: Secure Letters of Intent (LOI) covering 150% of proposed Phase 3 operational budget ($1.31M annual run rate).
- If secured, repurpose $437.5k Phase 3 outreach to bolster Phase 2 rigor.
- If not, Phase 3 becomes low-cost, self-sustaining technical documentation only.

Sensitivity:

- If revenue fails to cover 75% of annual operational cost, ROI drops from 400% to 50% within three years. Impacts KPI success by 75-90%.

## Issue 2 - Under-Exploration: Quantifying the Cost of Linguistic 'Naturalness' Trade-off

- Risk identified: Strict simplification leads to 'artificial' feel. Mitigation accepts cognitive load regularization and adds qualitative scoring.
- Missing: Quantified assumption for iterative refinement budget/time if naturalness score < 7/10.

Recommendation:

- Create dedicated Remediation Contingency budget line from $875k Phase 2 allocation.
- Earmark $150,000 (approx. 17% of Phase 2) for 'Aesthetic Refinement Sprints,' activated only if 'naturalness' score lags by > 1.0 point below target. Ring-fences resources.

Sensitivity:

- Failure requiring one 6-week Sprint ($150,000) delays Phase 3 launch by 6–10 weeks.
- Delay reduces projected ROI by 8-12% due to delayed revenue recognition.

## Issue 3 - Unrealistic Assumption: Phase 1 Timeline Adherence (12 Months)

- Phase 1 (Specification, mapping, governance, ISO alignment) in 12 months by 5 FTEs/contractors against $1.75M is aggressive given novelty and reliance on external commitments.

Recommendation:

- Adjust timeline assumption: Target 14 months for Phase 1 (12 months as stretch goal).
- Reallocate 5% of Phase 2 budget ($43,750) to Phase 1 contingency for buffer time (expert negotiation/rule locking).

Sensitivity:

- 1-month Phase 1 delay compresses Phase 2 pilot window from 12 to 11 months.
- Insufficient sample size may lead to premature Go/No-Go, resulting in 1:5 chance of project failure due to insufficient validation data.

## Review conclusion
Plan is strategically aggressive ('Pioneer'), prioritizing upfront quality over later contingency. Critical weaknesses involve unassumed risk quantification: 1) Sustainability reliance on un-guaranteed Phase 3 revenue; 2) Lack of dedicated resources for subjective 'naturalness' failure remediation; 3) Optimistic 12-month Phase 1 timeline. Immediate action: conditional budget reallocation based on Phase 3 revenue commitments, ring-fencing funds for aesthetic refinement, and building a 2-month buffer into the initial timeline.