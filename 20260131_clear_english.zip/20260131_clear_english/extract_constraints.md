## Positive Constraints

- Design and launch a new standardized variant of English called 'Clear English'
- Fix high-friction inconsistencies across ordinals, spelling-to-sound, irregular morphology, and ambiguous homographs
- Remain intelligible to current English speakers
- Establish a parallel standard for education, ESL, technical writing, and safety-critical documentation
- Define a three-year program with gated phases
- Phase 1 (12 months) must specify the rules and produce a reference corpus
- Phase 2 (12 months) must pilot learning materials and test usability
- Phase 3 (12 months) must publish a public standard and launch limited-scope adoption
- Average adult comprehension within 2 weeks of exposure (Intelligibility goal)
- Ordinal handling must remove special cases (11th/12th/13th; 1st/2nd/3rd; 21st/31st patterns)
- Ordinal approach must be either 'numeric + invariant ordinal marker' or 'fully spelled ordinals with regularized endings'
- Spelling-to-sound must define a minimal, consistent grapheme-to-phoneme mapping
- Spelling-to-sound must keep the Latin alphabet
- Diacritics in spelling-to-sound are optional but must be minimal and justified
- Morphology regularization must apply to a defined subset of irregular verbs and plurals (e.g., go/went, mouse/mice)
- Morphology changes must be capped to preserve recognizability
- Specify a threshold for when irregular forms are retained
- Homograph/homophone handling must introduce disambiguation rules or optional markers for a limited list of high-impact pairs (e.g., lead/lead, read/read)
- Must have a clear policy for when homograph disambiguation is required
- Core lexicon must be 5,000 words
- Core lexicon must include regularized pronunciation guidance
- Core lexicon must include a mapping from standard English
- Pilot cohorts must include adult ESL learners
- Pilot cohorts must include native speakers using a safety-critical or technical glossary
- Budget must be $3.5M total across three years
- Must propose a realistic budget split across three years
- Must produce 'Clear English Standard v1.0' with formal rule set and rationale (Deliverable)
- Must produce a Reference dictionary (word list + pronunciation guidance + mappings) (Deliverable)
- Must produce a Style guide covering ordinals, disambiguation markers, and regularized morphology (Deliverable)
- Must produce a Pilot curriculum (print + digital) with assessments (Deliverable)
- Must produce a Public licensing policy enabling third-party adoption (Deliverable)
- Must define governance (editorial board + linguistic review)
- Must define a risk register (including educator pushback, rule ambiguity, fragmentation)
- Must define an outreach plan (academic partners, ESL publishers, standards orgs)
- Must include a clear go/no-go decision point after Phase 2 based on pilot data
- Pilot data for go/no-go must include comprehension speed
- Pilot data for go/no-go must include ordinal error rate
- Pilot data for go/no-go must include pronunciation consistency score
- Pilot data for go/no-go must include learner retention after 30 days
- Project start ASAP

## Negative Constraints

- Avoid being a wholesale replacement of English
- Avoid aggressive scenarios related to mandates
- Avoid aggressive scenarios related to immediate K-12 replacement
- Avoid aggressive scenarios related to universal adoption claims
