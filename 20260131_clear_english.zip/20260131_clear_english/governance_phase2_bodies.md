### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** Required for high-level strategic direction, budget management ($3.5M total, critical phase approvals), and governing the major gated transition points, especially the Phase 2 Go/No-Go decision calibration.

**Responsibilities:**

- Approve Phase budgets (Phase 1: $1.75M, Phase 2: $875k escalation), expenditure above $50,000 operational threshold.
- Ratify major scope changes or deviations from the 'Pioneer' strategy.
- Hold final authority over the Go/No-Go decision immediately following the Linguistic Review Panel recommendation.
- Oversee high-level financial risk management, including contingency release ($350k pool).

**Initial Setup Actions:**

- Finalize and approve the Project Charter and Phase Budget Split (50/25/25).
- Elect the Chair and decide on preliminary conflict resolution protocols.
- Review and accept the initial Risk Register, specifically Risk 1 (Financial overrun).

**Membership:**

- Project Director (Chair)
- Senior Executive Sponsor (Organization Head)
- Head of Finance/Budget Office
- Internal Lead Legal Counsel

**Decision Rights:** Strategic direction, budget approvals over $50,000, phase gate authorization, ultimate Go/No-Go vote.

**Decision Mechanism:** Consensus required for strategic alignment; simple majority (3 of 4) otherwise. Tie-breaker resides with the Senior Executive Sponsor.

**Meeting Cadence:** Monthly for Phase 1, Bi-weekly during Gate Reviews (End of Phase 1, End of Phase 2).

**Typical Agenda Items:**

- Project health via RAG status and EVM review.
- Review of critical decision escalations from the Core Operational Team.
- Phase Transition Readiness Assessment (Gate Reviews).

**Escalation Path:** Issues requiring budget reallocation over $100k or changes to the fundamental project strategy escalate to the Organization's Executive Leadership Council (External body, not listed here).
### 2. Core Operational Team (COT)

**Rationale for Inclusion:** Responsible for the day-to-day execution, technical specification drafting, corpus development, and managing operational risks (e.g., $40k parser budget, 5,000-word lexicon definition). This separates execution from strategic oversight.

**Responsibilities:**

- Develop and manage the reference corpus and dictionary (lexicography).
- Draft the v1.0 rule set, Style Guide Appendix A (Morphology/Ordinal rationale).
- Manage the $40k budget for the ordinal integration PoC parser development (Risk 2 mitigation).
- Manage pilot recruitment logistics and data pipeline integrity (Risk 5 mitigation).

**Initial Setup Actions:**

- Finalize specific functional requirements for the XML/TEI dictionary platform (Q8).
- Establish internal version control system for the evolving rule set.
- Mobilize the core 5 FTE development team and secure initial contractor agreements.

**Membership:**

- Project Manager (Chair)
- Lead Linguist (Rule Finalization)
- Senior Technical Writer (Style Guide Drafting)
- Corpus Infrastructure Lead

**Decision Rights:** Operational decisions below $50,000; adherence to linguistic parameters defined by the Linguistic Review Panel; technical implementation choices (e.g., Grapheme strategy implementation).

**Decision Mechanism:** Simple majority vote among members. The Project Manager casts the deciding vote in case of ties on operational matters.

**Meeting Cadence:** Daily stand-up, weekly working session.

**Typical Agenda Items:**

- Progress against corpus mapping goals and Lexicon completion percentage.
- Review of newly defined rules for consistency (Grapheme mapping, Morphology).
- Operational risk items and immediate resolution pathway.

**Escalation Path:** Unresolved technical ambiguities or disagreements regarding linguistics (below Linguistic Review threshold) or budget variances over $10,000 escalate to the Scientific & Editorial Review Board.
### 3. Scientific & Editorial Review Board (SERB)

**Rationale for Inclusion:** This body serves as the critical quality assurance layer for the linguistic output, integrating the advisory expertise (Linguistic Review panel members in Phase 1) with internal editorial gatekeeping before PSC ratification. It manages the integrity of the actual standard artefact.

**Responsibilities:**

- Review and provide binding technical approval on Phase 1 outputs: rule set, dictionary structure, and Style Guide draft.
- Manage the review of the Safety Critical Double-Blind findings (Risk 5).
- Calibrate Phase 2 pilot metrics (ordinal error rate < 5%, comprehension 85/90) for final recommendation to the PSC.
- Oversee the $150k Aesthetic Refinement Sprint budget if triggered (Issue 2).

**Initial Setup Actions:**

- Finalize Terms of Reference, explicitly confirming the input flow from the secured Linguistic Review panel stipends.
- Establish clear data requirements for the Phase 2 Pilot Cohorts.
- Define the initial protocol for assessing 'naturalness' vs. 'consistency' trade-offs (Risk 3 mitigation).

**Membership:**

- Linguistic Review Panel Chair (Independent/External/Chair)
- Editorial Board Chair (Independent/External)
- Project Director (Non-voting liaison)
- Head of Pilot Coordination (Internal, metrics reporting)

**Decision Rights:** Technical acceptance of Phase 1 deliverables; recommendation (vote) on Phase 2 Go/No-Go continuation.

**Decision Mechanism:** Strict consensus required for approval of core linguistic artifacts (Rule Set v1.0). For metric reporting and minor issues, 2 out of 3 voting members must agree. Tie-breaker for technical disputes rests with the designated Linguistic Review Panel Chair.

**Meeting Cadence:** Bi-weekly during Phase 1 drafting; Weekly during review checkpoints (Month 6, Month 12); Monthly during Phase 2.

**Typical Agenda Items:**

- Review of safety-critical term conformity (Risk 5 check).
- Assessment of rule coherence across Ordinals, Spelling, and Morphology.
- Tallying preliminary pilot performance indicators and triggering Refinement Sprint if needed (Issue 2).

**Escalation Path:** Disagreements that prevent v1.0 sign-off transition to the Project Steering Committee (PSC) as a binding strategic/conflict resolution matter.
### 4. Compliance and IP Governance Body (CIGB)

**Rationale for Inclusion:** Given the project involves creating a parallel standard, formal publication, licensing, and handling of sensitive cohort data (GDPR/CCPA), dedicated oversight is required to manage regulatory and intellectual property risks explicitly mentioned in the plan and audit file.

**Responsibilities:**

- Ensure compliance with all data protection regulations regarding pilot participant data (GDPR/CCPA).
- Oversee the drafting and ratification of the Public Licensing Policy framework.
- Ensure ISO/IEC alignment for documentation structure and version control (Assumption Q4).
- Review all third-party contractor agreements for IP assignment clarity.

**Initial Setup Actions:**

- Draft initial Compliance Checklist (ISO alignment) for Phase 1 completion.
- Establish the anonymous whistleblower mechanism (Audit risk mitigation).
- Formalize data consent and anonymization protocols for Phase 2 pilot data.

**Membership:**

- Internal Legal Counsel (Chair)
- External IP/Standards Advisor (Independent)
- Head of Finance/Contract Manager
- Project Manager (Liaison, non-voting)

**Decision Rights:** Binding approval on all Public Licensing Policy drafts and sign-off on data handling compliance certifications.

**Decision Mechanism:** Unanimous consent required for licensing policy finalization. 2-of-3 voting members for operational compliance procedural changes.

**Meeting Cadence:** Monthly during Phase 1 (policy drafting), Quarterly during Phase 2/3.

**Typical Agenda Items:**

- Pilot Data usage audit status and consent review status.
- Review status of ISO alignment checks (Risk 4/Assumption Q7).
- Drafting updates on IP protection guarantees for v1.0.

**Escalation Path:** Critical statutory compliance breaches or unresolved IP disputes escalate immediately to the Project Steering Committee (PSC) and external Regulatory bodies for mandatory reporting.