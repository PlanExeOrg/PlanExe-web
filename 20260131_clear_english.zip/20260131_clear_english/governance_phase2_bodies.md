### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** Required for high-level strategic oversight, budget authorization above operational thresholds, and managing ultimate accountability for the success criteria (2-week intelligibility, Phase 3 launch). Given the strategic risk of pushback and the financial scale ($3.5M), executive oversight is mandatory.

**Responsibilities:**

- Authorize milestone completions and release of funds between major phases ($1.575M, $1.225M, $700K budget tranches).
- Final approval of the Go/No-Go decision checkpoint at Phase 2 conclusion.
- Strategic oversight of the overall three-year timeline and budget contingency ($700K).
- Review and approve major changes to the strategic path (e.g., pivot from 'Builder's Foundation').

**Initial Setup Actions:**

- Finalize and approve the Project Charter and Terms of Reference (ToR).
- Formally appoint the Project Sponsor and Chair.
- Establish the financial threshold for operational budget release (e.g., $50,000 increment).

**Membership:**

- Project Sponsor (Chair)
- Executive Leadership Representative (Finance/Strategy)
- Director of Organizational Change (for adoption oversight)
- Project Director (Non-voting Secretary)

**Decision Rights:** Financial decisions > $50,000; Approval of Phase Gate completion (Phase 1->2, Phase 2->3); Strategic direction changes.

**Decision Mechanism:** Majority vote (simple quorum of 3/4 required). Tie-breaker: Project Sponsor holds casting vote.

**Meeting Cadence:** Quarterly, with ad-hoc sessions called before Phase Gates.

**Typical Agenda Items:**

- Review of overall financial health vs. $3.5M plan.
- Phase Gate readiness reports (Go/No-Go checkpoints).
- Strategic Risk Review (Regulatory Vacuum, Financial Strain).
- Approval of contracts exceeding $100,000.

**Escalation Path:** N/A (This is the highest internal strategic body; escalates externally to organizational CEO/Board if budget thresholds are breached unmitigated by contingency).
### 2. Internal Editorial and Rule Board (IERB)

**Rationale for Inclusion:** This body is crucial for operational management and rapid decision-making concerning the technical rule definition (Phase 1 & 2). Selected strategy ('Builder's Foundation') favors a lean internal board for speed, which is then overlaid by the external Advisory Board for consensus.

**Responsibilities:**

- Execute day-to-day management of Phase 1 rule specification (Ordinals, Morphology, Homographs).
- Manage the Core Lexicon mapping development (Reference Dictionary).
- Manage operational risk register and resolve ambiguities below strategic thresholds.
- Direct curriculum development based on strategic decisions (e.g., defining the exact implementation of '1r' suffix in style guides).

**Initial Setup Actions:**

- Finalize Terms of Reference specifying segregation of duties from the external Advisory Board.
- Appoint internal Lead Linguist and Project Manager as joint operational leads.
- Establish Version Control protocols for the evolving 'Clear English Standard v1.0' draft.

**Membership:**

- Project Director (Chair)
- Lead Linguist/Rule Architect
- Core Lexicographer
- Lead Instructional Designer (Phase 2)

**Decision Rights:** Operational decisions and rule tweaks below the threshold requiring Advisory Board consensus (decisions < $50,000 or rule changes not impacting core strategic levers).

**Decision Mechanism:** Consensus required (all members agree). Tie-breaker: Project Director resolves internal disagreements; if unresolved, escalates immediately to the Project Steering Committee (PSC) or External Advisory Board based on technical vs. strategic nature.

**Meeting Cadence:** Bi-weekly (weekly during high-intensity rule finalization in Phase 1).

**Typical Agenda Items:**

- Review of Grapheme-to-Phoneme mapping progress.
- Assessment of operational risk register against Phase 2 milestones (Risk 2, 8).
- Internal review cycles for Style Guide drafts.
- Preparation package for the External Advisory Board.

**Escalation Path:** Issues requiring broad organizational legitimacy, significant budget variation, or failure to reach internal consensus are escalated to the External Advisory Board for deliberation, or directly to the PSC if time-critical.
### 3. External Linguistics & Standards Advisory Board (ELSAB)

**Rationale for Inclusion:** Mandated by the chosen 'Builder's Foundation' strategy to prioritize legitimacy and consensus over speed. This external body provides independent, expert assurance and the necessary political coverage to counter social pushback (Risk 4) and validate the standard internationally (Risk 1).

**Responsibilities:**

- Provide formal consensus approval on key strategic choices (Ordinal Approach, Morphological Threshold, Pilot Go/No-Go interpretation).
- Review and formally endorse the 'Clear English Standard v1.0' rule set prior to Phase 3 publication.
- Advise on alignment with international IP and standards body requirements.
- Serve as the primary arbiter for rule ambiguity resolution escalated from IERB.

**Initial Setup Actions:**

- Finalize contracts for the three required external specialists (Governance Administrator nominated by IERB to support this board).
- Define consensus voting procedures and conflict resolution protocols.
- Establish formal review cadence aligned with Phase 1 rule definition.

**Membership:**

- External Linguistic Expert (Chair, agreed by Board)
- External Expert in Standards/IP Law (Mandated Consultant)
- External Senior Educator/Curriculum Specialist (Ensures teachability)
- Internal IERB Lead Linguist (Non-voting liaison)

**Decision Rights:** Formal endorsement of Rule Set v1.0 and interpretation of complexity trade-offs (e.g., whether retained irregularities violate intelligibility constraints).

**Decision Mechanism:** Formal majority voting (2 out of 3 external votes required). Tie-breaker: If votes are split 1-1-1, the matter is escalated to the PSC for strategic arbitration, citing high fragmentation risk (Risk 7).

**Meeting Cadence:** Monthly during Phase 1; Bi-monthly during Phase 2.

**Typical Agenda Items:**

- Review of Phase 1 rule package drafts.
- Formal review of Go/No-Go metric data from Phase 2 pilots.
- Resolution of high-level ambiguity escalated by IERB.
- Review of IP and Standards engagement progress (Risk 1).

**Escalation Path:** Unresolved major rule conflicts or procedural disputes are escalated to the Project Steering Committee (PSC) within 7 days.
### 4. Pilot Assurance & Compliance Group (PACG)

**Rationale for Inclusion:** Given the high novelty, the tight 2-week intelligibility constraint (Operational Failure Risk 5), and strict legal requirements (GDPR/ethics for pilot participants - Risk 1), a dedicated assurance body is needed to maintain data integrity and compliance.

**Responsibilities:**

- Oversee ethical handling of all international pilot data (GDPR, participant consent).
- Validate integrity of assessment administration across all three physical sites (Boston, London, Geneva).
- Ensure pilot results directly map to the defined Go/No-Go metrics without modification (mitigating Misreporting Risk).
- Monitor compliance against IP protection efforts (Risk 1) during testing involving draft standards.

**Initial Setup Actions:**

- Finalize Data Privacy Protocols for international testing cohorts.
- Establish audit logs linking raw pilot data integrity to official Phase 2 metric reports.
- Secure necessary ethical review board approvals for human subject testing.

**Membership:**

- Project Compliance Officer (Chair)
- Internal Audit Representative (Ensures data integrity)
- External Legal Counsel representative (Focused on Ethics/Data Handling)
- Representative from Pilot Operations Lead (IERB liaison)

**Decision Rights:** Authority to halt pilot testing immediately if severe data handling, ethical breaches, or outright manipulation of Go/No-Go scores (Misreporting Risk) is detected.

**Decision Mechanism:** Unanimous decision required to halt testing; otherwise, majority vote suffices for minor protocol adjustments. Tie-breaker: Project Compliance Officer determines immediate action.

**Meeting Cadence:** Bi-weekly during active Phase 2 pilot execution; Monthly review of compliance logging thereafter.

**Typical Agenda Items:**

- Review of subject consent forms and data access logs.
- Verification report on ordinal error rates and comprehension speed scores integrity.
- Review of adherence to international data handling laws.
- Status update on IP documentation security.

**Escalation Path:** Immediate escalation to the Project Steering Committee (PSC) if a decision to halt testing is required, pending PSC ratification within 48 hours.