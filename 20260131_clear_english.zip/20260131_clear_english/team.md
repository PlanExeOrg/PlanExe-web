*Roles Needed & Example People*

# Roles

## 1. Lead Linguistic Architect

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Lead Architect defines core, continuous intellectual property (the rules) across the multi-year project. This role requires deep integration and consistent accountability, best served by an FTE.

**Explanation**:
Defines the core structural rules (orthography, morphology, homograph handling) for Clear English. Responsible for producing the rule set that forms the heart of v1.0.

**Consequences**:
Inconsistent application of rules, leading to a standard that fails the intelligibility goal, causing significant errors in the reference corpus and pilot assessment.

**People Count**:
1

**Typical Activities**:
Defining the core orthographic and morphological rules for Clear English v1.0; leading the Linguistic Review Panel's assessment of rule coherence; finalizing the rationale linking specific irregular forms retained (Morphology Threshold) to the final standard structure; ensuring the spelling-to-sound mapping is logically sound across the 5,000-word lexicon.

**Background Story**:
Dr. Anya Volkov, hailing from St. Petersburg, Russia, combines a Ph.D. in Theoretical Linguistics from the Sorbonne with over a decade spent structuring controlled languages for multinational aerospace consortia based primarily out of Munich, Germany. She possesses deep expertise in grapheme-phoneme mapping theory, historical morphology analysis, and developing computational grammars; her specific skills include formal logic application in linguistic rule-sets and extensive experience in designing standards compliant with ISO directives. Given her background in creating highly rigid, yet intelligible, communication systems for safety-critical data handling, Dr. Volkov is uniquely relevant as she has direct experience balancing linguistic purity against real-world functional constraints.

**Equipment Needs**:
High-performance workstation capable of running computational linguistic software suites (e.g., corpus analysis tools, formal grammar processors), specialized software licenses for rule modeling and textual analysis, access to large-scale digital text corpora.

**Facility Needs**:
Secure, quiet office space conducive to deep analytical work, dedicated meeting facilities for the Linguistic Review Panel (Pioneer strategy requires upfront commitment), reliable high-speed network access for external expert collaboration.

## 2. Corpus Development & Lexicographer

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Corpus development and lexicography is intensive, foundational work spanning Phases 1 and 2. Given the precision required for the 5,000-word core lexicon, continuous, dedicated FTE effort is necessary for consistency.

**Explanation**:
Manages the creation, mapping (to standard English), and curation of the 5,000-word reference lexicon and ensures accurate pronunciation guidance according to the Grapheme-to-Phoneme mapping strategy.

**Consequences**:
The core artifact (reference dictionary) will be incomplete or inaccurate, rendering Phase 2 curriculum development impossible and invalidating technical documentation use cases.

**People Count**:
min 1, max 2, depending on project scale and workload.

**Typical Activities**:
Developing the 5,000-word reference dictionary ensuring accurate mappings from Standard English; curating pronunciation data based on Dr. Volkov's Grapheme-to-Phoneme mapping; building the structured, TEI-compliant format for the dictionary backend; assisting in the final data preparation for the Style Guide appendices.

**Background Story**:
Kenji Tanaka grew up in Osaka, Japan, where his early fascination with character systems led him to earn dual Master's degrees in Computational Linguistics and Digital Archiving from the University of Tokyo. He spent his early career developing complex lexical databases for an international translation software firm, mastering the challenges of mapping inconsistent source language forms to standardized target outputs, particularly focusing on massive, cross-referenced dictionaries. Kenji's familiarity with managing data integrity across legacy and modern systems, coupled with his lexicographical focus, makes him essential for ensuring the reference dictionary and core lexicon are perfectly constructed and machine-readable.

**Equipment Needs**:
Database management system/server infrastructure for hosting the 5,000-word reference dictionary; advanced text editing software capable of handling XML/TEI schema structures; scripting environment (Python/R) for corpus mapping and data validation tools.

**Facility Needs**:
Data center access or secure cloud hosting environment for the reference corpus and dictionary; dedicated workspace for data preparation and quality assurance verification tasks.

## 3. Governance & Standards Manager

**Contract Type**: `independent_contractor`

**Contract Type Justification**: This role involves establishing the *structure* of governance and ensuring ISO compliance. Given the 'Pioneer' strategy secures the full review panel upfront, these high-level coordination and structural definition tasks fit well with high-value, defined-scope consultancy (IC).

**Explanation**:
Responsible for structuring the Editorial Board and Linguistic Review Panel, managing external expert onboarding (stipends, scheduling), and ensuring the final standard structure aligns with ISO/IEC directives for portability and version control.

**Consequences**:
Failure to secure external rigor, leading to the final standard lacking credible authority or necessary compliance structure for third-party adoption in Phase 3.

**People Count**:
1

**Typical Activities**:
Drafting the terms of reference and contracts for the Editorial Board and Linguistic Review panel members; establishing the formal governance schedule (Pioneer Strategy); ensuring the final structure of Standard v1.0 adheres to ISO/IEC Directives; structuring the public licensing policy framework.

**Background Story**:
Eleanor Vance, based in Washington D.C., brings a background in regulatory compliance and organizational governance, having previously managed the accreditation process for international technical documentation standards at a major US standards body. Holding an MPA from Georgetown, Eleanor specializes in creating operational frameworks, managing external expert advisory boards, and ensuring that technical outputs meet global formatting and versioning requirements (like ISO Directives). Her relevance stems from the 'Pioneer' strategy's need to immediately secure buy-in and structure for the Linguistic Review panel, ensuring the v1.0 standard has immediate authoritative support.

**Equipment Needs**:
Document management system compliant with ISO change control procedures; professional conferencing hardware/software for complex remote governance meetings; secure digital repository for standard drafts and licensing documents.

**Facility Needs**:
Office with professional meeting space suitable for hosting the Editorial Board and Linguistic Review panel (crucial for upfront commitments); administrative support infrastructure for processing expert stipends and contract management.

## 4. Phase 2 Pilot & Assessment Lead

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Pilot testing and assessment involve specific, time-bound deployments in Phase 2. The curriculum design and metric calculation benefit from specialized external expertise focusing purely on validation rather than continuous development.

**Explanation**:
Designs the dual-track curriculum, manages recruitment of ESL/technical cohorts, oversees the two-week comprehension trials, and formally calculates the Go/No-Go metrics based on retention and error rates.

**Consequences**:
Poorly designed pilots result in invalid or biased data, leading the Go/No-Go Authority to make a decision based on flawed evidence, endangering the entire 3-year investment.

**People Count**:
2

**Typical Activities**:
Designing the dual-track pilot curriculum (ESL vs. Technical); executing the comprehension and 30-day retention testing protocols; managing recruitment and logistics for the pilot cohorts; synthesizing raw test data into the objective metrics required by the Go/No-Go decision point.

**Background Story**:
Marcus O'Connell, educated in applied psychology and curriculum design in Dublin, settled his career in London, working extensively with major ESL publishing houses where he specialized in rapid proficiency metrics. He has led numerous pilot programs designed to test the practical impact of pedagogical simplifications on adult learners, focusing heavily on comprehension speed and long-term retention models. Marcus is relevant because Phase 2 hinges entirely on the successful, unbiased execution of the dual-track pilot, testing if the 2-week intelligibility goal is met and valid data is captured for the Go/No-Go authority.

**Equipment Needs**:
Learning Management System (LMS) license capable of hosting both print-simulation and adaptive digital assessments; specialized eye-tracking or response-time measurement hardware/software for immediate comprehension testing; data analysis tools (R/SPSS) for statistical validation of Go/No-Go metrics.

**Facility Needs**:
Recruitment liaison office/center for managing pilot cohort logistics (physical or secure virtual testing environments); private testing rooms for administering controlled comprehension trials.

## 5. Technical Integration Specialist

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Technical Integration Specialist is dedicated to a narrowly defined, high-risk technical task (PoC parser for ordinal markers), fitting the definition of a short-term specialist required to develop a specific artifact.

**Explanation**:
Focuses narrowly on the technical implementation friction, specifically designing and validating the Proof-of-Concept (PoC) parser necessary to handle the chosen numeric ordinal markers in digital workflows.

**Consequences**:
The chosen ordinal path causes catastrophic integration failure in Phase 3 adoption due to unanticipated digital rendering issues, undermining the value proposition for technical writers.

**People Count**:
1

**Typical Activities**:
Designing the strict XML/SGML tagging protocols for ordinal markers; leading the development and validation of the Proof-of-Concept integration parser ($40k budget line item); consulting with Dr. Volkov on implementation feasibility of homograph disambiguation markers within a digital text flow.

**Background Story**:
Javier Rios, based out of Raleigh-Durham, NC, is a specialist software engineer whose entire career has focused on digital typography, parsing tools, and text encoding for high-reliability, information-dense fields like pharmacology documentation. His technical expertise lies in transforming novel character sets or syntactic markers into formats readable by legacy enterprise systems, often involving custom XML/SGML tag development and validation. Javier is critical because the chosen numeric ordinal marker strategy introduces immediate, documented technical friction that must be solved *before* Phase 3 adoption, necessitating a dedicated PoC parser build during Phase 2.

**Equipment Needs**:
Integrated Development Environment (IDE) for C++/Python; access to commercial text processing tools (e.g., MS Word, Adobe InDesign editors) to test integration friction; version control system dedicated to parser development; budget contingency ($40k for PoC parser).

**Facility Needs**:
A dedicated, small technical workspace or lab environment for testing parsing scripts against anticipated Phase 3 publishing workflows; reliable access to platform-specific test environments (e.g., various XML rendering engines).

## 6. Project Financial & Risk Controller

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Financial control and risk tracking (EVM) must be integrated seamlessly throughout the entire 3-year program, especially given the tight budget and front-loaded spending plan. This requires continuous oversight.

**Explanation**:
Executes the complex budget strategy (50/25/25 split), tracks EVM rigorously against the $3.5M limit, manages contingency release, and oversees the monetization/licensing setup for Phase 3 to ensure sustainability.

**Consequences**:
Phase 1 budget overrun jeopardizes the entire project timeline and feasibility of conducting rigorous Phase 2 testing, leading to a premature or invalid Go/No-Go decision.

**People Count**:
1

**Typical Activities**:
Implementing and rigorously tracking EVM across all phases, with specific oversight on the Phase 1 linguistic definition effort; managing the $350k contingency release approvals; tracking US/GBP expenditure variance; designing the financial model underpinning the public licensing policy for Phase 3 sustainability.

**Background Story**:
Sarah Chen is a financial analyst specializing in managing multi-year, fixed-scope engineering and R&D budgets, based out of the US operations hub in NoVA. Her expertise lies in aggressive Earned Value Management (EVM) and contingency allocation, crucial for projects where scope definition (Phase 1) demands heavy front-loading. Sarah's relevance is tied directly to resource constraint management: using the 50/25/25 split, ensuring the high upfront commitment for linguistic rigor does not bankrupt the validation effort, and setting up the financial framework to monitor the sustainability of the standard post-funding.

**Equipment Needs**:
Enterprise Resource Planning (ERP) or robust EVM software for tracking $3.5M budget burn-rate; financial modeling software; secure system for managing licensing fee projections and basic Light Commercial Agreements (LCAs) for Phase 3.

**Facility Needs**:
Secure office location with high administrative support capabilities (e.g., D.C. hub) to manage external contractor payments, stipends, and detailed financial reporting required by Project Director and stakeholders.

---

# Omissions

## 1. Missing Role: Curriculum Content Developer/Editor (Phase 2 Support)

The team has a dedicated Pilot & Assessment Lead, but no role specifically responsible for the continuous drafting, editing, and iteration of the actual learning materials (print and digital curriculum) specified as a key deliverable. This work is crucial during Phase 2 and risks being under-resourced if the Assessment Lead must also perform detailed copywriting/editing.

**Recommendation**:
Add a temporary, specialized Contractor role for 'Curriculum Content Editor' for Phase 2. This person would work under the Pilot Lead to ensure the content structure derived from the Lead Architect's rules is pedagogically effective and error-free before delivery to cohorts.

## 2. Missing Role: Outreach & Licensing Coordinator (Phase 3 Focused)

The project requires publishing a public standard and defining a licensing policy in Phase 3. While the Governance & Standards Manager handles the *structure* of the policy, there is no dedicated resource to actively manage industry outreach, negotiate early licensing terms, or coordinate the standards body liaison required for adoption.

**Recommendation**:
Allocate a specific contractual engagement (e.g., 6 months in Phase 3) for an 'Adoption & Licensing Coordinator.' This role bridges the gap between the technical standard document and market uptake, leveraging expertise from outreach efforts identified in related resources (STC, ISO).

## 3. Missing Role: Infrastructure/DevOps Support for Corpus Hosting

The Corpus Development role requires database management systems and secure cloud hosting for the reference dictionary (an XML/TEI structure). While the Corpus role manages the *content*, there is no dedicated technical person (DevOps/SysAdmin) to build, secure, and maintain the necessary database infrastructure for the 5,000-word dictionary across three years.

**Recommendation**:
Integrate basic infrastructure setup/management into the Corpus Development role's scope, or, preferably, budget for a part-time, dedicated Technical Support Contractor tasked solely with setting up and hardening the TEI/XML database environment in early Phase 1.

---

# Potential Improvements

## 1. Clarify Relationship Between Lead Architect and Parallel Roles

The Lead Linguistic Architect (Dr. Volkov) sets the rules, but the Project Financial & Risk Controller needs to budget for external validation of high-impact terms, and the Pilot Lead needs input on 'naturalness' scoring. The flow of authority/dependency between these teams needs sharper definition.

**Recommendation**:
Explicitly state in the Lead Architect's mandate that rule finalization (Phase 1) includes sign-off milestones required by the Risk Controller (e.g., finalizing the top 500 safety terms for double-blind review before Phase 2 commencement).

## 2. Refine Phase 2 Budget Allocation Based on Risk/Assumptions

The Pioneer strategy front-loads 50% to Phase 1, leaving Phase 2 with $875k. Assumptions noted a $150k 'Aesthetic Refinement Sprint' budget needed if naturalness fails, and $40k for the ordinal parser. This consumes over 20% of Phase 2 upfront for mitigation, potentially starving core testing infrastructure.

**Recommendation**:
The Financial Controller must establish ring-fenced sub-budgets within the Phase 2 allocation: $150k for Aesthetic Refinement (conditional release) and $40k for Parser PoC (pre-committed). The remaining $685k should then be rigorously managed to ensure sufficient allocation remains for the logistics of running the 200-person pilot.

## 3. Integrate Physical Logistics Planning Sooner

The assumptions material acknowledged the need for physical locations (D.C., London, SE US) and currency strategy (USD/GBP) but the current team roles focus heavily on digital deliverables (corpus, rules, software). Securing physical space, especially in London requiring GBP contracts, needs governance setup now, not later.

**Recommendation**:
Assign the Governance & Standards Manager (Eleanor Vance, D.C.-based) primary responsibility for investigating physical facility costs and locking in long-term lease options/forward currency contracts for the two anticipated secondary hubs during Phase 1, ensuring operational readiness for Phase 2.

## 4. Clarity on the 'Second' Corpus Development Resource

The Corpus Development & Lexicographer role specifies a count of 'min 1, max 2.' Since Phase 1 is judged highly aggressive (12 months for 5,000 words + full rule set), having only one dedicated FTE might not be enough, especially when balancing content creation with the technical requirements of XML/TEI formatting.

**Recommendation**:
The Project Director should operate the role count as '1 FTE baseline, with approval to hire a second FTE (Contractor) if the Phase 1 corpus progress burn-down rate falls below 90% of target by Month 6. This uses EVM triggers to authorize necessary scope expansion budget.