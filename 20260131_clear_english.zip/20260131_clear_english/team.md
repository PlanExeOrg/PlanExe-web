*Roles Needed & Example People*

# Roles

## 1. Lead Linguist & Standard Architect

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Lead Linguist drives foundational, high-expertise foundational decisions (Phase 1 rule specification). This project requires specialized, deep expertise for a defined period, making an external expert engagement (consultant) more cost-effective and flexible than a full-time hire for the initial 12 months.

**Explanation**:
Responsible for the foundational linguistic decisions (morphology, phonetics, lexicon mapping) and authoring 'Clear English Standard v1.0'. This role drives Phase 1 output and steers the linguistic integrity based on strategic decisions.

**Consequences**:
Rules will be inconsistent, lacking the necessary rigor to achieve standardization goals, leading to likely failure in Phase 2 validation.

**People Count**:
min 1, max 2, depending on complexity of phonology mapping

**Typical Activities**:
Defining the exact minimal set of graphemes and optional diacritics for the 5,000-word lexicon; creating the formal rule-set for regularizing the past-tense verbs targeted by the Morphological Regularization Threshold; developing phonological mappings for the Reference Dictionary; advising the Governance Board on the linguistic integrity of proposed changes.

**Background Story**:
Dr. Alistair Finch, hailing from Edinburgh, Scotland, possesses a PhD in Historical Linguistics with a specialization in comparative phonology and has spent two decades consulting for major dictionary publishers (e.g., Oxford, Merriam-Webster) on corpus design and grapheme-to-phoneme mapping inconsistencies, giving him an intimate familiarity with English's most unstable elements; this project is relevant because his expertise is directly required to architect the consistent spelling-to-sound system and define the necessary morphological modifications under the conservative 'Builder's Foundation' constraints.

**Equipment Needs**:
High-performance workstation with specialized linguistic analysis software (e.g., corpus annotation tools, phoneme mapping editors) for defining the Clear English Standard v1.0 rules and Reference Dictionary.

**Facility Needs**:
Private office or secure collaboration space for intensive rule specification and consultation with the Governance Administrator, ideally near academic linguistic resources (e.g., Boston/Cambridge).

## 2. Curriculum Design & Pilot Coordinator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Managing the multi-site, parallel pilot cohorts (ESL/Technical) and ensuring data integrity for the critical Go/No-Go decision (Decision 5) requires dedicated, continuous oversight and control throughout Phase 2. This is a core operational function.

**Explanation**:
Manages Phase 2 execution. Responsible for designing, testing, and deploying the pilot learning materials for both ESL and technical writing cohorts, ensuring assessments align precisely with the 2-week intelligibility metric.

**Consequences**:
Inability to effectively test the standard against user groups, resulting in poor data quality for the critical Go/No-Go decision, jeopardizing project viability.

**People Count**:
min 1, max 3, depending on workload of parallel cohort management

**Typical Activities**:
Designing the structure and content of the parallel pilot curricula for both ESL students and technical writers; developing and deploying digital assessment tools to measure comprehension speed and retention accurately across the three planned testing sites; coordinating logistics with on-site testing personnel for the Phase 2 cohorts; creating feedback loops to translate pilot failures into Rule Refinements for the Editorial Board.

**Background Story**:
Maria Santos, based primarily in Boston, Massachusetts, holds a Master's in Instructional Technology and has spent her career designing adaptive learning platforms, most recently for adult ESL programs in community colleges; she is intimately familiar with the challenges of rapid language acquisition, making her essential for meeting the two-week intelligibility benchmark for the ESL cohort, which is central to the project's success under the 'Builder's Foundation' strategy.

**Equipment Needs**:
Access to standardized testing software licenses (digital assessments), localized hardware (laptops/tablets) for data collection reliability across sites, and secure local network infrastructure for data upload.

**Facility Needs**:
Access to controlled, quiet testing labs/computer facilities in at least three international locations (Boston, London, Geneva) for administering in-person pilot tests to ESL and technical cohorts.

## 3. Governance & Operations Administrator

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Consensus Governance Structure (Decision 4) requires external administrative support capable of handling logistics for an advisory board, potentially across three international locations, and managing budgets/risks. This specialized, high-trust role is often secured via an experienced external project management contractor.

**Explanation**:
Handles the logistics for the consensus-driven Editorial Board and external Advisory Board (as per Decision 4). Manages project scheduling, documentation flow, budget tracking ($3.5M), and risk register monitoring throughout all phases.

**Consequences**:
Immediate timelines risks (Risk 7) due to unmanaged meeting overhead; financial negligence leading to potential budget overruns (Risk 3), especially concerning multi-currency logistics.

**People Count**:
1

**Typical Activities**:
Administering the schedule and documentation flow for the Editorial and Advisory Boards; tracking expenditure against the three-year budget, ensuring compliance with international currency transfers; proactively monitoring the central Risk Register (especially Financial/Integration risks) and reporting status to the board; managing the logistics for international advisory meetings.

**Background Story**:
Elias Vance, a seasoned independent project consultant operating out of Geneva, Switzerland, built his reputation managing complex, multi-jurisdictional standardization efforts for international non-profits, giving him deep experience in setting up consensus-driven governance structures and managing high-stakes budgets under tight constraints; his relevance stems from the need to flawlessly execute Decision 4, establishing the external Advisory Board and ensuring the $3.5M budget is tracked across USD, GBP, and CHF despite the risk of scope creep.

**Equipment Needs**:
Secure project management software suite, sophisticated spreadsheet/ERP tools for detailed multi-currency budget tracking, and video conferencing infrastructure capable of reliable international connections for advisory board meetings.

**Facility Needs**:
A central, secure office location (ideally Geneva/Zurich for board meetings) with high levels of administrative support for scheduling and documentation management across all phases.

## 4. External Relations & Adoption Specialist

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Adoption strategy (Decision 10) in Phase 3 is highly specialized, requiring business development skills to secure Lighthouse Partnerships and ESL publisher LOIs. This is best handled by a specialized consultant engaged heavily in Phase 2/3 for maximum strategic impact.

**Explanation**:
Drives user adoption, focusing on securing external validation. Responsible for outreach strategy (Decision 10), cultivating the Lighthouse Partnership, securing the ESL publisher LOI, and drafting the Public Licensing Policy (Phase 3 deliverable).

**Consequences**:
A technically perfect standard will fail adoption (low ROI). Risks fragmentation (Risk 1) if standards bodies/publishers are not secured early.

**People Count**:
min 1, max 2, depending on the diversity of required outreach (legal/business)

**Typical Activities**:
Leading outreach efforts to secure the primary technical 'Lighthouse Partnership'; drafting the technical sections of the Style Guide, focusing specifically on the unambiguous placement and use of ordinal markers and homograph disambiguation policies; facilitating feedback sessions with the native technical writer cohort during Phase 2 pilot testing.

**Background Story**:
Hiroshi Tanaka, having worked extensively in technical publishing and corporate communications based out of London, England, specializes in creating international documentation standards for aerospace hardware compliance, making him the ideal driver for adoption among safety-critical technical writers; his background ensures the final Style Guide and v1.0 standard are optimized for professional utility, supporting the necessary 'Lighthouse Partnership' outlined in Decision 10.

**Equipment Needs**:
CRM/database for tracking Lighthouse Partnerships and publisher contacts, presentation equipment for stakeholder proposals, and necessary travel budget for securing commitments (Decision 10).

**Facility Needs**:
Office or shared workspace accessible to major publishing/technical hubs (e.g., London) to facilitate face-to-face engagement with potential high-profile adoption partners.

## 5. Lexicographer & Reference Author

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Creating the precise 5,000-word Reference Dictionary and mapping pronunciations requires intensive, focused lexicographical expertise, primarily needed during the intensive rule finalization of Phase 1. This expertise is best contracted for the duration of the specification effort.

**Explanation**:
Responsible for the precise definition and systematic creation of the 5,000-word Reference Dictionary, including all pronunciation mappings and homograph disambiguation rules (Decision 8). Key driver for Phase 1 data integrity.

**Consequences**:
The core deliverable (dictionary/ruleset) will be incomplete or contain costly errors related to word substitution and mapping, leading to rework in Phase 2 testing.

**People Count**:
1

**Typical Activities**:
Executing the final definition and mapping of the 5,000-word Core Lexicon; formally documenting the existing standard English form against the Clear English pronunciation guide; authoring the technical specifications for homograph disambiguation markers (Decision 8) within the lexicon entries; validating the reference corpus against established frequency tables.

**Background Story**:
Dr. Chloe Hayes, a lexicographer trained at the University of Chicago, specializes in diachronic semantic shifts and corpus linguistics, with specific experience in mapping irregular orthographies to phonetic targets; she is deeply involved in the highly specific task of building the Reference Dictionary, ensuring that the chosen 5,000 core words are systematically mapped and that the chosen conservative regularization threshold is accurately reflected in the final word list.

**Equipment Needs**:
Subscription access to large, validated English corpora for comparative analysis, database management system for the 5,000-word Reference Dictionary, and tools for generating pronunciation guides.

**Facility Needs**:
Dedicated workspace suitable for highly focused, manual lexicographical data entry and cross-referencing work throughout Phase 1.

## 6. Legal & Standards Compliance Officer

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Legal expertise for IP/Standards engagement (Risk 1 mitigation) is highly specialized and required intensely only during Phase 1/2 development and preliminary Phase 3 filing. Essential to secure expert counsel on a contractual basis.

**Explanation**:
Focuses exclusively on navigating intellectual property, securing trademark/copyright protection, and formalizing the MOU with a recognized standards body (Risk 1 mitigation). Essential for granting legitimacy to the final v1.0 standard in Phase 3.

**Consequences**:
Exposure to regulatory risk and fragmentation (Risk 1). The final standard lacks the legal framework necessary for third-party adoption and defense.

**People Count**:
min 1 (Consultant level for Phase 1/2, scaled down in Phase 3)

**Typical Activities**:
Drafting the legal framework for the Public Licensing Policy deliverable; negotiating and securing the Memorandum of Understanding (MOU) with a recognized standards body by the 2027-Jan-01 deadline; advising the Editorial Board on legal repercussions of rule ambiguity in Phase 1; managing all registration procedures for 'Clear English Standard v1.0' IP.

**Background Story**:
Vivian Holloway, a specialist in international regulatory compliance and IP law based in Washington D.C., possesses extensive experience securing intellectual property for novel standards in both the US and EU markets; her immediate focus is mitigating Regulatory Vacuum risk by securing the necessary legal framework and MOU during Phase 1, which is critical for ensuring the final standard is protectable for third-party monetization.

**Equipment Needs**:
Specialized legal/IP research databases, secure digital signature platforms for MOU finalization, and efficient international communication channels (budgeted via Risk 8 contingency).

**Facility Needs**:
Secure legal office/consulting space, likely remote or co-located with the Governance Administrator, requiring secure document handling capabilities for IP registration filings.

## 7. Technical Writer & Style Guide Developer

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Translating complex linguistic rules into a living Style Guide (a key deliverable) requires close, continuous iteration with the Lead Linguist and Pilot Coordinator throughout Phases 1 and 2. This requires internal dedication and control over knowledge transfer.

**Explanation**:
Translates the abstract linguistic rules finalized in Phase 1 into practical, enforceable documentation: the Style Guide. This role focuses on clarity for professional users, managing ordinal notation enforcement and disambiguation marker policies.

**Consequences**:
The rules may be linguistically sound but unusable or inconsistent in professional contexts, failing the safety-critical technical writing pilot objectives.

**People Count**:
1

**Typical Activities**:
Drafting the official 'Style Guide' deliverable based on Phase 1 outputs, concentrating on clear enforcement rules for the numeric/invariant ordinal marker approach ('1r'); collaborating with the Pilot Coordinator to ensure the technical cohort training materials reflect real-world application; verifying the Style Guide's compliance with safety documentation principles.

**Background Story**:
Robert Chen, based in Cambridge, MA, is a seasoned technical editor with a background in producing high-stakes documentation for the financial sector, where ambiguity is unacceptable; his primary role is translating the abstract linguistic rules into practical, everyday guidance for professional users, ensuring the Style Guide provides an accessible bridge between the old standard and Clear English.

**Equipment Needs**:
Word processing and desktop publishing software capable of precise formatting for generating the formal Style Guide deliverable, and access to corpus compliance checking tools.

**Facility Needs**:
Desk space closely integrated with the Lead Linguist (ID 1) and Pilot Coordinator (ID 2) to ensure real-time translation of rule sets into actionable style guide content.

## 8. Assessment & Data Analyst

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Designing, implementing, and analyzing the quantitative framework for the Go/No-Go metrics (Decision 5) is central to project survival. This requires dedicated, controlled execution across international test sites throughout Phase 2.

**Explanation**:
Designs the quantitative framework to measure pilot success against the Go/No-Go Metrics (Decision 5). Responsible for designing comprehension speed tests, administering assessments across physical sites, and analyzing data integrity for the final Go/No-Go report.

**Consequences**:
Inability to objectively measure pilot performance; the Go/No-Go decision becomes subjective or based on flawed data, risking premature launch or unnecessary termination (Risk 5).

**People Count**:
1

**Typical Activities**:
Designing the statistical analysis plan for pilot data (retention, comprehension speed, error rates); implementing standardized assessment protocols across Boston, London, and Geneva sites (Risk 8 mitigation); producing the final analytical report used by the Editorial Board for the final Go/No-Go determination; training site administrators on controlled testing environment protocols.

**Background Story**:
Lena Petrova, stationed in London, specializes in quantitative research design and psychometrics, holding a Master’s in Experimental Psychology, and has previously managed clinical trials measuring cognitive load in language processing; she is essential because her expertise directly underpins the project's viability, as she must objectively measure the 14-day intelligibility benchmark and provide the data that fuels the critical Phase 2 Go/No-Go decision.

**Equipment Needs**:
Statistical analysis software packages (e.g., R, SPSS, or specialized psychometric tools), high-fidelity data visualization software for Go/No-Go reporting, and secure data storage compliant with international privacy regulations.

**Facility Needs**:
Offices or remote access points capable of connecting to the controlled testing environments in Boston, London, and Geneva to oversee protocol adherence and data integrity.

---

# Omissions

## 1. Missing Role: In-House Technical Writer/Editor for Governance

The team has a dedicated Technical Writer focused on the Style Guide (ID 7), but the Governance Administrator (ID 3) lacks dedicated technical writing or editing support needed to efficiently manage and document rule changes coming from the consensus-driven Advisory Board during Phase 2.

**Recommendation**:
Integrate an ongoing part-time technical writer resource into the Governance/Ops team or assign the existing Technical Writer (ID 7) 10 hours/week in Phase 2 purely for documenting Advisory Board decisions and updating the internal rule log, preventing administrative logjams.

## 2. Missing Digital Enforcement Platform Strategy

The project requires enforcing the standard in technical writing workflows, but data analysis suggests no explicit role or budget assumption for developing the necessary digital tool (like a linter or style checker) needed to scale adoption beyond manual checks in Phase 3. This contradicts the need for universal application.

**Recommendation**:
Add a deliverable/task in Phase 2: 'Develop a functional prototype of the Clear English Style Checker and integrate it into the Pilot environment.' This requires budgeting for a dedicated software engineer/developer consultant, perhaps funded by contingency if necessary.

## 3. Insufficient Dedication to IP/Legal throughout Phase 2/3

The Legal & Standards Compliance Officer (ID 6) is contracted for Phase 1/2 development, but Risk 1 highlights the complexity of securing IP/MOU. Full registration and licensing policy finalization occur in Phase 3, which lacks dedicated legal bandwidth in the current staffing.

**Recommendation**:
Adjust the contract type for the Legal Officer (ID 6) from scaled consultant to a retainer model extending through Phase 3, ensuring continuous legal oversight for licensing policy drafting and final trademark registration.

---

# Potential Improvements

## 1. Clarify Overlap between Lead Linguist (ID 1) and Lexicographer (ID 5)

Both the Lead Linguist (Architect) and the Lexicographer (Reference Author) handle rule definition and dictionary creation in Phase 1, risking duplication of effort regarding morphological and homograph rules established by strategic decisions.

**Recommendation**:
Explicitly assign Lead Linguist (ID 1) responsibility for *defining* the abstract, high-level rules (e.g., the morphological threshold), and assign Lexicographer (ID 5) responsibility for the *application* of those rules precisely to the 5,000-word corpus and mapping documentation.

## 2. Strengthen Phase 2 Data Analysis for ESL vs. Technical Cohorts

The success hinges on balancing two very different user bases (ESL vs. native technical writers) using shared metrics (Decision 5). The Assessment Analyst (ID 8) needs explicit reporting requirements to ensure metrics are analyzed independently for each cohort.

**Recommendation**:
Mandate that the Assessment & Data Analyst (ID 8) produces two separate Go/No-Go data profiles: one weighted heavily on ESL retention/speed, and one weighted on technical writer consistency/ordinal error rate. The Editorial Board then reviews these two profiles against the composite metric.

## 3. Streamline Pilot Material Logistics using Existing Roles

Pilot material deployment requires coordination between Curriculum Coordinator (ID 2), Governance Administrator (ID 3, for budget/international shipping), and Legal Officer (ID 6). This critical logistical pathway is not explicitly assigned a single person responsible for the physical supply chain management described in Risk 6.

**Recommendation**:
Delegate the physical logistics and supply chain execution concerning pilot materials (printing, shipping, local setup compliance in Boston/London/Geneva) explicitly to the Governance & Operations Administrator (ID 3), as this falls under their core operational oversight, freeing the Curriculum Coordinator (ID 2) to focus purely on content delivery and instructional quality.