## Suggestion 1 - Basic English

Basic English was a simplified subset of English created by Charles Kay Ogden in the 1920s. It aimed to be an international auxiliary language, easy to learn and use by non-native speakers. It consisted of a core vocabulary of 850 words and a simplified grammar. The project involved defining the vocabulary, creating learning materials, and promoting its adoption.

### Success Metrics

Defined a core vocabulary of 850 words.
Published books and articles in Basic English.
Gained some international recognition and use, particularly in education.
Demonstrated the feasibility of a simplified English variant.

### Risks and Challenges Faced

Limited adoption due to competition from other international languages (e.g., Esperanto).
Criticism for being too restrictive and unnatural.
Difficulty in expressing complex ideas with a limited vocabulary.
Overcome by focusing on basic communication and education.

### Where to Find More Information

https://ogden.basic-english.org/
https://en.wikipedia.org/wiki/Basic_English

### Actionable Steps

Contact the Ogden Trust (if it still exists) for historical documents and insights.
Search academic databases for publications on Basic English and its impact.
Analyze the Basic English vocabulary and grammar rules for potential lessons learned.

### Rationale for Suggestion

Basic English is a directly relevant historical precedent for creating a simplified version of English. It shares the objective of making English easier to learn and use, particularly for non-native speakers. While Basic English aimed for broader adoption as an international language, the Clear English project shares the goal of creating a more consistent and accessible form of English for specific purposes. Studying the successes and failures of Basic English can provide valuable insights into vocabulary selection, grammar simplification, and adoption strategies.
## Suggestion 2 - Special English (now VOA Learning English)

Special English, now known as VOA Learning English, is a simplified version of English used by the Voice of America (VOA) for news broadcasts. It uses a limited vocabulary (around 1500 words) and simplified sentence structures to make news accessible to English language learners. The project involves writing and broadcasting news stories in Special English, creating learning materials, and providing resources for English learners.

### Success Metrics

Maintained a consistent vocabulary of around 1500 words.
Produced daily news broadcasts in Special English.
Attracted a large audience of English language learners worldwide.
Demonstrated the effectiveness of simplified English for news communication.

### Risks and Challenges Faced

Maintaining accuracy and objectivity while using a limited vocabulary.
Keeping the language up-to-date and relevant.
Competing with other English learning resources.
Addressed by focusing on clear and concise reporting, regular vocabulary updates, and online accessibility.

### Where to Find More Information

https://learningenglish.voanews.com/
https://en.wikipedia.org/wiki/VOA_Special_English

### Actionable Steps

Explore the VOA Learning English website for examples of simplified news stories.
Analyze the VOA Learning English vocabulary list and grammar guidelines.
Contact VOA Learning English staff for insights into their editorial process and audience engagement strategies.

### Rationale for Suggestion

VOA Learning English is a successful example of using simplified English for a specific purpose (news communication). It shares the Clear English project's goal of making English more accessible to non-native speakers. Studying VOA Learning English can provide valuable insights into vocabulary selection, sentence simplification, and maintaining clarity while using a limited vocabulary. The project's long-term success and large audience demonstrate the demand for simplified English resources.
## Suggestion 3 - Plain Language Movement

The Plain Language Movement is an international effort to promote clear and concise communication in government, business, and other sectors. It aims to make information easier to understand by using simple language, clear organization, and effective design. The movement involves developing guidelines for plain language, training writers and communicators, and advocating for the use of plain language in official documents and communications.

### Success Metrics

Increased awareness of the importance of clear communication.
Development of plain language guidelines and standards.
Adoption of plain language principles by government agencies and businesses.
Improved readability and comprehension of official documents.

### Risks and Challenges Faced

Resistance from writers and communicators who are accustomed to using complex language.
Difficulty in measuring the effectiveness of plain language.
Maintaining consistency and quality across different organizations and contexts.
Addressed by providing training and resources, demonstrating the benefits of plain language, and establishing clear standards.

### Where to Find More Information

https://www.plainlanguage.gov/
https://en.wikipedia.org/wiki/Plain_language

### Actionable Steps

Review the plain language guidelines and resources available on PlainLanguage.gov.
Contact plain language organizations for training and consulting services.
Analyze examples of plain language documents and communications.

### Rationale for Suggestion

While not focused on creating a new variant of English, the Plain Language Movement shares the Clear English project's goal of improving clarity and accessibility in communication. It provides valuable insights into developing guidelines for clear writing, training communicators, and promoting the adoption of plain language principles. The movement's success in influencing government and business practices demonstrates the potential for widespread adoption of clear communication standards. The focus on readability and comprehension is directly relevant to the Clear English project's objectives.

## Summary

The user is planning a project to design and launch a new standardized variant of English, called "Clear English." The project aims to address inconsistencies in ordinals, spelling-to-sound, morphology, and homographs, while remaining intelligible to current English speakers. The project has a three-year timeline and a budget of $3.5M. The strategic decisions, assumptions, and risks have been identified. The following are reference projects that could provide valuable insights.