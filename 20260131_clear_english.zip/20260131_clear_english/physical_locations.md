This plan implies one or more physical locations.

## Requirements for physical locations

- Space for governance meetings (Editorial Board, Linguistic Review)
- Facilities for developing and hosting computer resources for corpus management
- Proximity to potential pilot cohort testing sites (adult ESL centers or technical documentation firms)
- Access to administrative/professional support staff

## Location 1
USA

Washington D.C. / Northern Virginia (NoVA)

Flexible Office Space near Federal Triangle or Rosslyn area

**Rationale**: High density of standards organizations (NIST, ANSI), strong technical writing industry presence, and accessibility for linguistic experts and policy meetings (governance activation).

## Location 2
United Kingdom

London Metropark Area

Co-working space focusing on knowledge-based startups (e.g., Shoreditch/Tech City)

**Rationale**: Access to global linguistic talent pool, strong presence of major ESL publishing houses (relevant for Phase 3 launch), and established mechanisms for international standards development.

## Location 3
USA

Southeastern US (e.g., Atlanta or Raleigh-Durham)

University Research Park Proximity

**Rationale**: Lower operational cost compared to D.C./NYC while providing excellent access to major universities with strong Applied Linguistics departments to recruit for internal work and pilot integration feedback.

## Location Summary
Since this project requires formal governance setup, corpus management infrastructure, pilot execution coordination, and interactions with standards bodies, a centralized operational hub is necessary. Locations in the Washington D.C. area (for standards access), London (for global reach and publishing), and a lower-cost US research hub (for recruitment and operational efficiency) are recommended to support Phase 1 development and Phase 2 piloting.