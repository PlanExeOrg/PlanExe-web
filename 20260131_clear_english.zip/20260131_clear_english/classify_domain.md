**Primary domain:** Standards Development

**Secondary domains:** Linguistics, Curriculum Development, Applied Phonetics

**Rationale:** Standards Development is chosen because the central success criterion is publishing the 'Clear English Standard v1.0' in Phase 3. Linguistics and Lexicography are critical inputs, but the culmination and official product is the standard itself. Standardization Engineering is too general compared to Standards Development.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Linguistics | 5 | 5 | outcome | The core deliverable is defining formal linguistic rules for the English variant. |
| Applied Phonetics | 5 | 5 | method | Directly responsible for defining the consistent grapheme-to-phoneme mapping. |
| Lexicography | 5 | 5 | outcome | Creating the reference dictionary and defining the core lexicon is a primary deliverable. |
| Standards Development | 5 | 4 | outcome | The project's goal culminates in publishing a formal public standard document. |
| Technical Writing | 4 | 5 | market | One of the primary professional fields targeted for 'Clear English' adoption. |
| Educational Assessment | 5 | 4 | method | Required to define and execute metrics like comprehension speed and retention. |
| Standardization Engineering | 5 | 4 | outcome | The project's entire goal is to define and publish a formal, parallel standard. |
| Curriculum Development | 4 | 4 | method | Developing learning materials and testing pilot usability is central to adoption success. |
| Instructional Design | 4 | 4 | method | Developing pilot curriculum and assessments requires instructional design expertise. |