
## Documents to Create

### 1. Project Charter

**ID:** 99d3a779-7398-4971-81cf-bf6312cdfa5b

**Description:** A formal document that initiates the Clear English project, defining its objectives, scope, stakeholders, and high-level timelines. It serves as the foundation for all subsequent planning activities. Includes initial risk assessment and resource allocation.

**Responsible Role Type:** Project Manager

**Primary Template:** PMI Project Charter Template

**Steps:**

- Define project goals and objectives based on the project description.
- Identify key stakeholders and their roles.
- Outline the project scope, deliverables, and success criteria.
- Establish a high-level timeline and budget.
- Obtain approval from key stakeholders.

**Approval Authorities:** Steering Committee, Funding Organization

### 2. Linguistic Scope Strategy Plan

**ID:** b3661ac6-d727-46fc-84a4-a38173a69c48

**Description:** A high-level plan outlining the breadth of linguistic features targeted for regularization in Clear English. It defines which aspects of the language (ordinals, spelling-to-sound, morphology, homographs) will be addressed and to what extent. This plan will guide the development of specific regularization rules and inform the adoption pathway strategy.

**Responsible Role Type:** Lead Linguist

**Steps:**

- Analyze existing English inconsistencies in ordinals, spelling-to-sound, morphology, and homographs.
- Evaluate the trade-offs between comprehensiveness, intelligibility, and adoption feasibility.
- Define the scope of linguistic features to be regularized.
- Establish criteria for selecting high-impact morphological irregularities and homographs.
- Document the rationale for the chosen linguistic scope.

**Approval Authorities:** Editorial Board

### 3. Adoption Pathway Strategy Plan

**ID:** d0b8031f-3e58-44d1-9990-d192346aa0d6

**Description:** A high-level plan defining the target audience and rollout plan for Clear English. It controls the initial focus (ESL, technical documentation, K-12) and the pace of expansion. This plan will guide the development of marketing and communication strategies and inform the funding model strategy.

**Responsible Role Type:** Community Engagement Coordinator

**Steps:**

- Identify potential target audiences for Clear English (ESL learners, technical writers, K-12 students).
- Evaluate the needs and characteristics of each target audience.
- Define the initial focus and pace of expansion.
- Develop a rollout plan that minimizes resistance and maximizes impact.
- Document the rationale for the chosen adoption pathway.

**Approval Authorities:** Editorial Board

### 4. Funding Model Strategy Plan

**ID:** 9c88f367-258a-4982-a7b0-7c9db4bb9fce

**Description:** A high-level plan determining how the Clear English project will be financed. It controls the sources of funding (grants, licensing, DAO) and the financial management approach. This plan will guide the development of grant proposals and licensing agreements and inform the governance structure.

**Responsible Role Type:** Funding and Licensing Manager

**Steps:**

- Identify potential funding sources (grants, licensing, DAO).
- Evaluate the feasibility and sustainability of each funding source.
- Define the financial management approach.
- Develop a plan for securing sufficient resources to support all project activities.
- Document the rationale for the chosen funding model.

**Approval Authorities:** Steering Committee

### 5. Morphological Regularization Strategy Plan

**ID:** 19343f51-e0f6-454e-a1be-eefa5ee2cfd8

**Description:** A high-level plan defining the extent to which irregular verb conjugations and pluralizations are standardized in Clear English. It controls the balance between simplification and maintaining recognizability for existing English speakers. This plan will guide the development of specific regularization rules and inform the linguistic scope strategy.

**Responsible Role Type:** Lead Linguist

**Steps:**

- Analyze existing English irregular verb conjugations and pluralizations.
- Evaluate the trade-offs between simplification and maintaining recognizability.
- Define the extent of morphological regularization.
- Establish criteria for selecting irregular forms to be regularized.
- Document the rationale for the chosen morphological regularization strategy.

**Approval Authorities:** Editorial Board

### 6. Governance and Editorial Control Framework

**ID:** ae3a9dbb-e60c-4ce9-a6e0-e9e1234a311c

**Description:** A framework defining the decision-making structure for the Clear English standard. It controls who has the authority to approve rules, resolve disputes, and manage the evolution of the standard. This framework will guide the establishment of an editorial board and advisory board and inform the community engagement approach.

**Responsible Role Type:** Governance and Standards Liaison

**Steps:**

- Define the roles and responsibilities of the editorial board and advisory board.
- Establish a process for approving rules and resolving disputes.
- Define the decision-making authority for managing the evolution of the standard.
- Develop a framework for incorporating community feedback.
- Document the rationale for the chosen governance structure.

**Approval Authorities:** Steering Committee

### 7. Risk Register

**ID:** f9dce161-e86f-435e-aa2d-37bf131c990b

**Description:** A document that identifies potential risks to the Clear English project, assesses their likelihood and impact, and outlines mitigation strategies. It will be regularly updated throughout the project lifecycle.

**Responsible Role Type:** Project Manager

**Primary Template:** PMI Risk Register Template

**Steps:**

- Identify potential risks based on the project description, assumptions, and expert input.
- Assess the likelihood and impact of each risk.
- Develop mitigation strategies for each risk.
- Assign responsibility for monitoring and managing each risk.
- Establish a process for regularly reviewing and updating the risk register.

**Approval Authorities:** Steering Committee

### 8. Communication Plan

**ID:** f8552675-e0a9-40c6-bb07-ee175ab9caa8

**Description:** A plan outlining how information about the Clear English project will be communicated to stakeholders. It defines the target audiences, communication channels, frequency, and key messages.

**Responsible Role Type:** Community Engagement Coordinator

**Steps:**

- Identify key stakeholders and their communication needs.
- Define the communication channels to be used (e.g., email, website, social media).
- Establish a communication schedule and frequency.
- Develop key messages for each target audience.
- Assign responsibility for managing communication activities.

**Approval Authorities:** Project Manager

### 9. Stakeholder Engagement Plan

**ID:** 0893e445-4d02-4b08-9721-a2f64a657611

**Description:** A plan outlining how stakeholders will be involved in the Clear English project. It defines the level of participation, engagement activities, and communication strategies for each stakeholder group.

**Responsible Role Type:** Community Engagement Coordinator

**Steps:**

- Identify key stakeholders and their interests.
- Define the level of participation for each stakeholder group.
- Develop engagement activities (e.g., surveys, focus groups, workshops).
- Establish a communication strategy for each stakeholder group.
- Assign responsibility for managing stakeholder engagement activities.

**Approval Authorities:** Project Manager

### 10. Change Management Plan

**ID:** 365e4e61-2a3e-449f-a0d3-2c67270798d2

**Description:** A plan outlining how changes to the Clear English standard will be managed. It defines the process for proposing changes, evaluating their impact, and implementing them.

**Responsible Role Type:** Governance and Standards Liaison

**Steps:**

- Define the process for proposing changes to the Clear English standard.
- Establish criteria for evaluating the impact of proposed changes.
- Define the process for implementing approved changes.
- Develop a communication strategy for informing stakeholders about changes.
- Assign responsibility for managing the change management process.

**Approval Authorities:** Editorial Board

### 11. High-Level Budget/Funding Framework

**ID:** 372dda41-dd21-47cc-8c0e-c6f1913e1aca

**Description:** A high-level overview of the project budget, including funding sources, expense categories, and key assumptions. It provides a financial roadmap for the project.

**Responsible Role Type:** Funding and Licensing Manager

**Steps:**

- Identify all project expenses.
- Categorize expenses into major categories (e.g., personnel, materials, travel).
- Estimate the cost of each expense category.
- Identify potential funding sources and their expected contributions.
- Develop a high-level budget that aligns expenses with funding sources.

**Approval Authorities:** Steering Committee

### 12. Funding Agreement Structure/Template

**ID:** 1d93e8fe-4a0e-4088-99f3-7530c5138839

**Description:** A template for structuring agreements with funding organizations, outlining the terms and conditions of funding, reporting requirements, and intellectual property rights.

**Responsible Role Type:** Funding and Licensing Manager

**Steps:**

- Research standard funding agreement terms and conditions.
- Consult with legal counsel to ensure compliance with applicable laws and regulations.
- Develop a template that outlines the key terms and conditions of funding, reporting requirements, and intellectual property rights.
- Obtain approval from legal counsel and the steering committee.

**Approval Authorities:** Legal Counsel, Steering Committee

### 13. Initial High-Level Schedule/Timeline

**ID:** b775b947-f87b-467a-84c3-590dd102bfad

**Description:** A high-level timeline outlining the major phases of the Clear English project, key milestones, and estimated durations. It provides a roadmap for project execution.

**Responsible Role Type:** Project Manager

**Primary Template:** Gantt Chart Template

**Steps:**

- Identify the major phases of the project (e.g., definition, development, pilot, launch).
- Define key milestones for each phase.
- Estimate the duration of each phase.
- Develop a high-level timeline that aligns phases, milestones, and durations.
- Obtain approval from the steering committee.

**Approval Authorities:** Steering Committee

### 14. M&E Framework

**ID:** a3dfe97b-29d6-4931-bc4c-3668841195c7

**Description:** A framework for monitoring and evaluating the progress and impact of the Clear English project. It defines the key indicators, data collection methods, and reporting requirements.

**Responsible Role Type:** Usability and Assessment Expert

**Primary Template:** Logical Framework Template

**Steps:**

- Define the key indicators for measuring project progress and impact.
- Identify data collection methods for each indicator (e.g., surveys, assessments, usage statistics).
- Establish reporting requirements and frequency.
- Develop a framework for analyzing and interpreting data.
- Obtain approval from the steering committee.

**Approval Authorities:** Steering Committee

### 15. Current State Assessment of English Language Inconsistencies

**ID:** 587c5ad5-ab1a-409d-84f2-ea3928091c85

**Description:** A baseline report assessing the current state of inconsistencies in English grammar, spelling, and pronunciation, focusing on the areas targeted by Clear English (ordinals, spelling-to-sound, morphology, homographs). This report will provide a benchmark for measuring the impact of the Clear English standard.

**Responsible Role Type:** Lead Linguist

**Steps:**

- Conduct a literature review of existing research on English language inconsistencies.
- Analyze existing English corpora to identify the frequency and distribution of inconsistencies.
- Consult with linguistic experts to gather insights on the challenges of English language learning.
- Document the findings in a comprehensive report.

**Approval Authorities:** Editorial Board

## Documents to Find

### 1. Existing National ESL Curriculum Standards

**ID:** 5ff28950-de73-409c-8c9b-bbc8e1fb3ed4

**Description:** Existing curriculum standards for ESL education in participating nations. These will inform the development of Clear English learning materials and ensure alignment with educational requirements. Intended audience: Curriculum Development Specialists.

**Recency Requirement:** Most recent available.

**Responsible Role Type:** Curriculum Development Specialist

**Access Difficulty:** Medium: Requires navigating government websites and contacting educational institutions.

**Steps:**

- Search government education websites.
- Contact national education boards.
- Review academic literature on ESL curriculum standards.

### 2. Participating Nations Literacy Rate Data

**ID:** 738a6734-de49-4bad-9163-f254384be746

**Description:** Statistical data on literacy rates in participating nations, broken down by age, education level, and language background. This data will help to identify target audiences and assess the potential impact of Clear English. Intended audience: Community Engagement Coordinator.

**Recency Requirement:** Within the last 5 years.

**Responsible Role Type:** Community Engagement Coordinator

**Access Difficulty:** Medium: Requires navigating statistical databases and potentially contacting government agencies.

**Steps:**

- Search UNESCO Institute for Statistics.
- Contact national statistical offices.
- Review academic literature on literacy rates.

### 3. Existing Plain Language Guidelines

**ID:** 34b4e0c7-8b8e-4326-87bb-a2a2c108e96a

**Description:** Existing guidelines and standards for plain language in government, business, and other sectors. These guidelines will inform the development of the Clear English style guide and ensure alignment with best practices in clear communication. Intended audience: Technical Writer / Documentation Specialist.

**Recency Requirement:** Most recent available.

**Responsible Role Type:** Technical Writer / Documentation Specialist

**Access Difficulty:** Easy: Publicly available on government websites and standards organizations.

**Steps:**

- Search PlainLanguage.gov.
- Review ISO standards on plain language.
- Contact plain language organizations.

### 4. Existing English Language Corpora

**ID:** 4ec78b2c-818a-4430-bea7-62c323b4bddf

**Description:** Existing corpora of English language text, including the British National Corpus (BNC) and the Corpus of Contemporary American English (COCA). These corpora will be used to analyze the frequency and distribution of linguistic features and to develop the Clear English reference corpus. Intended audience: Lead Linguist.

**Recency Requirement:** Most recent available versions.

**Responsible Role Type:** Lead Linguist

**Access Difficulty:** Medium: Requires registration and potentially fees for access to some corpora.

**Steps:**

- Search online repositories of language corpora.
- Contact corpus linguistics research centers.
- Review academic literature on language corpora.

### 5. Existing English Dictionaries and Style Guides

**ID:** 957bab96-f04e-4b9b-8ee0-3148ed83329c

**Description:** Existing English dictionaries (e.g., Oxford English Dictionary, Merriam-Webster) and style guides (e.g., Chicago Manual of Style, AP Stylebook). These resources will be used to inform the development of the Clear English dictionary and style guide. Intended audience: Technical Writer / Documentation Specialist.

**Recency Requirement:** Most recent available editions.

**Responsible Role Type:** Technical Writer / Documentation Specialist

**Access Difficulty:** Easy: Publicly available for purchase or through library access.

**Steps:**

- Purchase or access online versions of dictionaries and style guides.
- Review library resources.
- Search online bookstores.

### 6. Existing Research on English Language Acquisition

**ID:** 1f3808a2-7c80-4aa8-9471-e66a155510e2

**Description:** Existing research on the challenges faced by ESL learners in acquiring English grammar, spelling, and pronunciation. This research will inform the development of Clear English learning materials and assessment tools. Intended audience: Curriculum Development Specialist.

**Recency Requirement:** Within the last 10 years.

**Responsible Role Type:** Curriculum Development Specialist

**Access Difficulty:** Medium: Requires access to academic databases and potentially contacting research institutions.

**Steps:**

- Search academic databases (e.g., JSTOR, ERIC).
- Review academic journals on language acquisition.
- Contact ESL research centers.

### 7. Existing ISO and W3C Standards

**ID:** 6a44ed12-3135-4908-9d9a-34860a39b8f3

**Description:** Existing standards from the International Organization for Standardization (ISO) and the World Wide Web Consortium (W3C) related to language, accessibility, and technical documentation. These standards will inform the development of the Clear English standard and ensure compliance with international best practices. Intended audience: Governance and Standards Liaison.

**Recency Requirement:** Most recent available versions.

**Responsible Role Type:** Governance and Standards Liaison

**Access Difficulty:** Medium: Requires navigating standards organization websites and potentially purchasing standards documents.

**Steps:**

- Search the ISO and W3C websites.
- Review standards documentation.
- Contact ISO and W3C representatives.

### 8. Existing National Education Standards

**ID:** fb5438a2-4771-42a2-b722-e360966332fc

**Description:** Existing national education standards related to English language arts and ESL education. These standards will inform the development of Clear English learning materials and ensure alignment with educational requirements. Intended audience: Curriculum Development Specialist.

**Recency Requirement:** Most recent available.

**Responsible Role Type:** Curriculum Development Specialist

**Access Difficulty:** Medium: Requires navigating government websites and contacting educational institutions.

**Steps:**

- Search government education websites.
- Contact national education boards.
- Review academic literature on education standards.

### 9. Existing Research on Cognitive Load in Language Learning

**ID:** 675d9b9e-93ab-4f84-bc44-56309be30ce4

**Description:** Existing research on cognitive load theory and its application to language learning. This research will inform the design of Clear English learning materials and assessment tools, with a focus on minimizing cognitive load for learners. Intended audience: Curriculum Development Specialist.

**Recency Requirement:** Within the last 10 years.

**Responsible Role Type:** Curriculum Development Specialist

**Access Difficulty:** Medium: Requires access to academic databases and potentially contacting research institutions.

**Steps:**

- Search academic databases (e.g., JSTOR, ERIC).
- Review academic journals on cognitive psychology and language learning.
- Contact cognitive psychology research centers.

### 10. Existing Data on Common English Language Errors

**ID:** 4ef1706e-1d03-461a-9a4a-8f8bd6877e42

**Description:** Data on common errors made by English language learners, categorized by error type (grammar, spelling, pronunciation). This data will inform the development of Clear English learning materials and assessment tools, focusing on addressing the most common challenges faced by learners. Intended audience: Lead Linguist.

**Recency Requirement:** Within the last 10 years.

**Responsible Role Type:** Lead Linguist

**Access Difficulty:** Medium: Requires access to academic databases and potentially contacting research institutions.

**Steps:**

- Search academic databases (e.g., JSTOR, ERIC).
- Review academic journals on applied linguistics and ESL education.
- Contact ESL research centers and language testing organizations.