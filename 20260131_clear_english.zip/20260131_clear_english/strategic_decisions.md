## Primary Decisions
The vital few decisions that have the most impact.


The vital few levers must prioritize resource reality (Budget), foundational linguistic scope (Morphology Threshold), and validation structure (Go/No-Go Authority/Calibration). These address the core tension between maximizing linguistic precision versus managing the tight $3.5M constraint and ensuring demonstrable, objective success before launch. Grapheme mapping and Ordinal choice represent the next critical layer defining the technical output artifact.

### Decision 1: Ordinal Standardization Approach
**Lever ID:** `a02e7404-5556-42b5-adb9-47d4585e5a74`

**The Core Decision:** This lever dictates the fundamental choice for representing ordinals: either using numeric markers (e.g., '4th') or full, regularized spelling (e.g., 'fourtheth'). Selecting the numeric path prioritizes simpler rule learning and vocabulary size but complicates digital text integration. Success is measured by the artifact’s final form and its proven integration feasibility tested during Phase 2 adoption pilots.

**Why It Matters:** Selecting the numeric + invariant ordinal marker path minimizes the required spelling corpus expansion and drastically reduces the number of novel, hard-to-memorize surface forms for learners. However, integrating non-alphabetic markers increases friction for traditional text processing tools and publishing workflows relying solely on standard typography, potentially slowing adoption in existing digital documentation pipelines.

**Strategic Choices:**

1. Commit to the numeric + invariant ordinal marker approach (e.g., 5th, 21st) to maintain shallow rule complexity but accept required custom rendering or tagging in final outputs.
2. Implement fully spelled ordinals with regularized suffix application (e.g., *twentifirst*, *elefth*) accepting greater learning overhead to preserve maximal textual uniformity.
3. Defer all ordinal standardization to Phase 3, using the current English ruleset in Phases 1 and 2 while clearly defining the scope of regularization for the final standard.

**Trade-Off / Risk:** Deferring ordinal rules defers cross-cutting rule testing, potentially locking in design decisions that the Phase 2 pilot later invalidates; choosing the marker approach burdens future layout systems immediately.

**Strategic Connections:**

**Synergy:** Synergizes with Grapheme-to-Phoneme Mapping Strategy by potentially simplifying the overall sound mapping requirements if the numeric approach is chosen, reducing the scope of spelling regularization.

**Conflict:** Conflicts with Budget Allocation Strategy if the numeric marker approach is chosen, as custom rendering or tagging/parsing tools development might inflate Phase 2 and 3 operational costs unexpectedly.

**Justification:** *High*, This lever dictates the surface artifact of the standard, creating a fundamental conflict between technical simplicity (numeric markers) and output compatibility (textual uniformity). It directly influences corpus complexity and Phase 2 processing costs.

### Decision 2: Morphology Regularization Threshold
**Lever ID:** `c09e8013-4cf8-4f66-8763-462fe06b7ef6`

**The Core Decision:** This lever sets the strict boundaries on how many common irregular English forms (verbs/plurals) are simplified. A strict threshold yields a more consistent, learnable system vital for the ESL mandate but dramatically increases the initial Phase 1 effort for corpus mapping. Success hinges on achieving the intelligibility goal without producing a lexicon too sparse to be useful, measured by learner retention in Phase 2.

**Why It Matters:** Lowering the threshold for rule inclusion broadens the scope of the linguistic project, demanding more corpus mapping effort in Phase 1 and introducing greater risk of intelligibility drift in Phase 2. Conversely, retaining too many common irregular forms limits the efficiency gains promised by Clear English, leading to low perceived value among initial technical users.

**Strategic Choices:**

1. Set the irregular retention threshold based purely on word frequency across the reference corpus, regularizing all verbs and nouns appearing above the 90th percentile of usage.
2. Establish the threshold based on perceived cognitive load, regularizing only forms where the irregular derivation is entirely opaque (e.g., went/go) while retaining transparently derived forms if they exist.
3. Cap the total number of irregular forms allowed in the final specification at 50 instances, regardless of frequency, prioritizing high-impact verbs over common but context-specific plurals.

**Trade-Off / Risk:** Frequency-based retention risks keeping confusing outliers if they appear consistently, while a fixed cap forces arbitrary exclusions that complicate the style guide's internal consistency checks.

**Strategic Connections:**

**Synergy:** Works closely with Grapheme-to-Phoneme Mapping Strategy; a higher threshold (fewer changes) simplifies the phonetic rules needed, while a lower threshold demands deeper, more complex mapping coherence.

**Conflict:** Directly conflicts with Budget Allocation Strategy; lowering the threshold increases Phase 1 scope complexity, potentially demanding budget reserves better suited for Phase 2 pilot execution and analysis.

**Justification:** *Critical*, This lever controls the core trade-off between linguistic depth/comprehensiveness and scope complexity. It directly impacts Phase 1 effort (budget) and the intelligibility goal, acting as a major constraint on the overall perceived value of Clear English.

### Decision 3: Governance Structure Activation
**Lever ID:** `328154b3-c2f6-45f4-83ca-e0a06da1ea19`

**The Core Decision:** This defines when and how the quality assurance and ultimate authority structure is established. Early activation ensures external technical rigor on Phase 1 output but burdens the initial budget. Success is defined by the governance body’s successful ratification of the Style Guide and Reference Dictionary outputs following initial linguistic critique.

**Why It Matters:** Establishing a full, independent Editorial Board and Linguistic Review body during Phase 1 requires significant early budget allocation for stipends and administrative overhead, potentially starving the corpus development work needed for accurate Phase 2 testing. Delaying governance activation until the end of Phase 2 centralizes initial rule-setting power, speeding up specification but increasing the risk of institutional lock-in preceding full external review.

**Strategic Choices:**

1. Mobilize a small three-person steering committee immediately to manage Phase 1 specification, deferring the full 9-person Editorial Board activation until the Phase 2 pilot results are analyzed.
2. Secure full external commitments for the 5-member Linguistic Review panel upfront, dedicating a fixed portion of the budget to their initial review of Phase 1 rule drafts to ensure quality from the start.
3. Fund the governance structure by treating initial board meetings as contract deliverables, paying members only upon successful sign-off of the preceding phase's primary artifact, linking cost directly to progress.

**Trade-Off / Risk:** Delaying governance centralizes risk and decision-making power within the immediate project team, potentially biasing early architectural decisions against long-term standardization requirements.

**Strategic Connections:**

**Synergy:** Amplifies the impact of Go/No-Go Decision Point Authority by establishing which external body holds the final arbiter role, ensuring unbiased metric evaluation against project goals post-pilot.

**Conflict:** Directly trades off against Budget Allocation Strategy, as activating a full board early consumes capital needed for technical specification work in Phase 1 or pilot preparation in Phase 2.

**Justification:** *High*, This is a key structural lever affecting quality assurance and authority distribution. Its timing dictates early budget strain vs. the risk of design lock-in, fundamentally influencing the ratification of the final standard (v1.0).

### Decision 4: Budget Allocation Strategy
**Lever ID:** `bdfa938d-f3fb-4358-a4ac-b9d478d76e2c`

**The Core Decision:** This strategy allocates the $3.5M budget across the three phases, fundamentally shaping the project's risk profile. Front-loading development maximizes linguistic quality but risks poor adoption infrastructure; favoring launch increases market penetration chances but risks finding critical rule flaws too late. Success is measured by achieving phase objectives within budget constraints, particularly sufficient funding for Phase 3 outreach.

**Why It Matters:** Front-loading the budget heavily into Phase 1 (Specification and Corpus) ensures the linguistic foundation is robust before expensive pilot execution, but leaves Phase 3 (Public Launch) critically underfunded for necessary outreach, licensing infrastructure, and support staff. Spreading the budget evenly reduces risk resolution flexibility if unforeseen linguistic issues emerge late in Phase 2, making corrective iterations expensive.

**Strategic Choices:**

1. Allocate 50% of the budget to Phase 1 for rigorous linguistic definition, utilizing the remaining 50% equally across Phases 2 and 3 to support the intensive pilot and launch activities.
2. Front-load 65% into Phase 1 and 2 combined to secure high-quality corpus tooling and run extensive internal pre-pilots, leaving a minimal budget for the public outreach required in Phase 3.
3. Reserve 20% of the total budget as an untouchable contingency pool released only upon formal approval of the Phase 2 Go/No-Go decision, forcing early phases to operate under extreme capital constraint.

**Trade-Off / Risk:** Front-loading risks creating a perfect specification that cannot be effectively marketed or defended in Phase 3, while reserving a large contingency severely constrains necessary upfront tooling investments.

**Strategic Connections:**

**Synergy:** Must align with Pilot Curriculum Development Approach, ensuring sufficient funds remain in Phase 2 to support the development and testing of high-quality learning materials for the pilot cohorts.

**Conflict:** Creates inherent tension with Morphology Regularization Threshold; a tight budget forces the team to adopt a higher threshold (fewer changes) to reduce immediate Phase 1 corpus work.

**Justification:** *Critical*, As the primary resource constraint ($3.5M), this lever dictates the feasibility of all other options, especially the scope of regularization (Morphology) and the rigor of governance activation. It controls the project's survival across all three phases.

### Decision 5: Go/No-Go Decision Point Authority
**Lever ID:** `e8a99df2-cffc-45a9-816c-53a3d3bd8d0f`

**The Core Decision:** This lever determines who holds the final decision power regarding project continuation after Phase 2 testing reveals initial impact data. The primary success metric is ensuring the decision is made based on empirical Phase 2 results (intelligibility/comprehension) rather than political or internal momentum bias, minimizing sunk costs if clarity goals are missed.

**Why It Matters:** Granting the Phase 3 Editorial Board veto power over the Phase 2 metrics ensures that only feasible standards proceed, but risks biasing the decision toward technical perfection rather than achieving the required usability in real-world pilot settings. Conversely, deferring the final go/no-go decision until the end of Phase 3 allows maximum piloting time but risks incurring substantial sunk costs on curriculum development if the core comprehensibility metrics are missed early on.

**Strategic Choices:**

1. Empower the external Linguistic Review panel, rather than the internal Project Director, to make the binding go/no-go decision solely based on the objective ordinal error rate and retention scores after Phase 2.
2. Establish an automatic Phase 3 continuation trigger if pilot comprehension scores exceed a predefined threshold, irrespective of negative feedback concerning style guide complexity or homograph marker usage.
3. Delay the go/no-go decision until the final validation of the public licensing policy in Phase 3, treating the Phase 2 results only as advisory checkpoints, not decision gates.

**Trade-Off / Risk:** Delaying the go/no-go decision past Phase 2 forces commitment to subsequent resource-intensive activities, compounding financial exposure if core comprehension goals are demonstrably failed in the pilot.

**Strategic Connections:**

**Synergy:** Frames the utility of Phase 2 Go/No-Go Success Calibration, as this authority acts upon the defined calibration results provided by the pilot assessment teams during the review window.

**Conflict:** If authority is internal/hierarchical, it conflicts with Governance Structure Activation, which aims to distribute decision review power to independent linguistic and editorial experts.

**Justification:** *Critical*, This lever controls the primary risk mitigating gate, determining which entity validates Phase 2 results. It has direct synergy with Governance and high conflict with sunk cost exposure, making it central to strategic survival.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Grapheme-to-Phoneme Mapping Strategy
**Lever ID:** `ac555a8c-5945-4ce9-b6bb-2e6159b5711a`

**The Core Decision:** This lever defines the rule set for mapping written characters (graphemes) to sounds (phonemes) for the Clear English lexicon. Success is measured by the resulting consistency score in pronunciation exercises and its impact on achieving the two-week comprehension goal. A strict mapping ensures consistency but must balance this against retaining enough nuance to avoid sounding overly simplistic or artificial in context.

**Why It Matters:** Defining a minimal, consistent grapheme-to-phoneme mapping enhances pronunciation clarity, aiding ESL learners significantly. However, this may limit the richness of English phonetics, potentially leading to a loss of nuance in pronunciation.

**Strategic Choices:**

1. Establish a strict grapheme-to-phoneme mapping that prioritizes clarity over phonetic diversity to aid comprehension.
2. Create a flexible mapping system that allows for regional variations in pronunciation while maintaining core consistency.
3. Incorporate optional diacritics for complex sounds, providing learners with additional pronunciation guidance without overwhelming them.

**Trade-Off / Risk:** Implementing a strict mapping may simplify learning but risks oversimplifying the language, potentially alienating advanced users who appreciate phonetic nuances.

**Strategic Connections:**

**Synergy:** This strategy strongly amplifies the Pilot Curriculum Development Approach by providing the fundamental phonetic basis needed for all instructional materials in the pilot phase.

**Conflict:** It trades off against the Morphology Regularization Threshold, as overly strict phonetic rules might require more complex regularization for retained irregular forms to align their spelling and sound.

**Justification:** *High*, This is the lynchpin for pronunciation consistency and directly underpins ESL intelligibility goals. Its complexity influences Morphology regularization scope and curriculum design, making it a core technical pillar.

### Decision 7: Pilot Curriculum Development Approach
**Lever ID:** `791aac64-8c51-4182-83bd-170b4f520d04`

**The Core Decision:** This determines the design methodology for instructional materials used in Phase 2, focusing on how to serve both adult ESL learners (prioritizing foundational clarity) and native speakers (focusing on technical application). Success relies on achieving high scores across all defined pilot metrics for both cohorts simultaneously, ensuring the materials are usable, effective, and gather balanced feedback for the final standard.

**Why It Matters:** Creating a pilot curriculum tailored for both ESL learners and native speakers ensures comprehensive feedback on usability and comprehension. However, this dual focus may dilute the curriculum's effectiveness for either group if not carefully balanced.

**Strategic Choices:**

1. Design a curriculum that emphasizes practical applications for ESL learners while incorporating feedback from native speakers to enhance relevance.
2. Develop separate pilot curricula for ESL learners and native speakers, allowing for targeted feedback and tailored learning experiences.
3. Integrate collaborative workshops with both ESL learners and native speakers to co-create curriculum materials, fostering inclusivity and shared ownership.

**Trade-Off / Risk:** Separate curricula may provide focused learning but risks creating silos that hinder cross-group understanding and collaboration.

**Strategic Connections:**

**Synergy:** It draws significant resources from the Budget Allocation Strategy and must align closely with the input defined by the Grapheme-to-Phoneme Mapping Strategy and Ordinal Standardization Approach.

**Conflict:** The necessity of accommodating two diverse user groups creates inherent tension with the Go/No-Go Decision Point Authority, as balancing dual success metrics complicates achieving a single consensus threshold.

**Justification:** *Medium*, Crucial for Phase 2 execution and gathering metrics, but its design choices are largely reactive to the more foundational rule-setting levers (Ordinal, Morphology, Grapheme mapping). It enables metric collection rather than defining the core strategic rules.

### Decision 8: Phase 2 Go/No-Go Success Calibration
**Lever ID:** `c0b47a67-f8b3-4878-acf4-980d3a836bf2`

**The Core Decision:** This lever establishes the quantified pass/fail criteria for moving from Phase 2 development into the public standardization phase. Deciding the calibration weights (e.g., emphasizing error rate vs. retention) dictates project risk tolerance. Success means selecting a balanced but rigorous calibration that validates technical rule adherence while confirming practical utility for adoption.

**Why It Matters:** Heavily weighting the pronunciation consistency score over learner retention means the project prioritizes strict adherence to the new phonological rules over long-term user internalization. If the new pronunciation is technically correct but contextually unnatural, pilot users might score well on immediate recitation tests but fail to integrate the new system effectively over the 30-day follow-up period.

**Strategic Choices:**

1. Set the Go/No-Go threshold by requiring the median ordinal error rate across cohorts to be below five percent, while making the 30-day learner retention score only a secondary, qualitative indicator.
2. Mandate that the average adult comprehension gain must exceed 80% of the standard English baseline within the two-week exposure window, overriding all other quantitative metrics if this target is missed.
3. Base the final decision 70% on the ordinal error rate and pronunciation consistency score combined, treating the pilot curriculum's functional applicability in safety documentation as the absolute determinant.

**Trade-Off / Risk:** Prioritizing immediate error rates in the Go/No-Go decision favors establishing technical correctness early, but it risks discounting the crucial long-term metric of user retention and sustained application outside the testing environment.

**Strategic Connections:**

**Synergy:** This calibration directly validates the output of the Pilot Curriculum Development Approach and establishes the performance benchmarks required by the Governance Structure Activation.

**Conflict:** Calibration choices often conflict with the Budget Allocation Strategy, as exceptionally high success thresholds may necessitate unanticipated resource extensions or require scope reduction to meet the defined metrics.

**Justification:** *High*, This lever defines *how* success is measured, directly translating abstract goals (intelligibility) into actionable Phase 3 continuation criteria. It establishes the objective standard against which the Decision Point Authority will operate.
