## Primary Decisions
The vital few decisions that have the most impact.


The five vital levers address the core tensions between Linguistic Purity/Utility versus Intelligibility/Speed. Critical levers—Governance Structure, Morphological Threshold, and Pilot Go/No-Go Metrics—manage rule consistency, learning friction, and the validation gate. High-impact levers, including Budget Allocation and Outreach Strategy, ensure the resources and partnerships exist to implement and legitimize the final standard. The group effectively prioritizes governance and user validation over granular lexical choices.

### Decision 1: Ordinal Standardization Approach
**Lever ID:** `5ea93f6e-1235-4019-bc81-3a6d8a78b133`

**The Core Decision:** This lever determines how ordinal numbers are represented, critically balancing orthographic consistency against direct numerical comprehension. The chosen approach directly impacts the complexity of the Style Guide deliverable. Success hinges on selecting an approach that minimizes confusion for ESL learners while retaining speed advantages for professional text, validated by extremely low error rates in the pilot assessments.

**Why It Matters:** Choosing numeric notation with an invariant marker simplifies the rule set by eliminating complex suffix agreements, directly supporting rapid comprehension in technical contexts. However, this choice forces reliance on symbol interpretation, which may slightly increase cognitive load compared to fully spelled forms for native speakers undergoing initial exposure, potentially stressing the two-week intelligibility benchmark.

**Strategic Choices:**

1. Adopt a convention using the numeral followed by a consistent, single-character written ordinal suffix (e.g., '1st' becomes '1r'), prioritizing numeric compactness over pure orthographic presentation.
2. Fully regularize all written ordinals by applying a uniform suffix (e.g., '-eth' or '-nd') to all numbers, accepting increased complexity in numeral-to-word conversion for non-standard spellings.
3. Delegate the ordinal resolution entirely to the Style Guide, providing distinct, minimally disruptive, regularized spellings for 1st–100th only, deferring all higher ordinals to simple numeric display.

**Trade-Off / Risk:** Delegating ordinal resolution limits the standardization gain and increases the complexity of the crucial style guide deliverable, potentially introducing ambiguity in long-form technical specifications where higher numbers are used.

**Strategic Connections:**

**Synergy:** Synergizes with Homograph Disambiguation Policy by offering a consistent format for symbolic representation, simplifying marker management across the Style Guide.

**Conflict:** Conflicts with Morphological Regularization Threshold; a highly numeric approach reduces the perceived necessity for complex spelling consistency elsewhere, potentially leading to mixed priorities.

**Justification:** *High*, This lever directly controls the complexity of the Style Guide deliverable and the balance between orthography and numerical comprehension. It's critical because the choice forces a constraint on the intelligibility metric, which is a core project goal.

### Decision 2: Morphological Regularization Threshold
**Lever ID:** `a4438d22-d3ff-4d85-96e0-3867cd1c7d08`

**The Core Decision:** This strategic choice defines the acceptable level of linguistic imperfection retained in the language standard. Setting a high threshold for regularization increases the linguistic utility of Clear English but stresses the two-week intelligibility goal due to retained exceptions. Key metrics involve measuring the sheer count of irregular forms retained versus the impact on learner retention scores.

**Why It Matters:** Defining a strict cap on retained irregularities minimizes the departure from established recognition patterns, which aids the intelligibility constraint by preserving familiar chunks of language. This efficiency, however, means core high-frequency irregular terms (e.g., common verbs) will remain inconsistent, forcing the reference dictionary to handle dual pronunciations.

**Strategic Choices:**

1. Retain all irregular forms whose frequency in the 5,000-word core lexicon exceeds a defined corpus threshold, sacrificing morphological consistency for high-frequency recognition.
2. Regularize all verbs exhibiting common past-tense deviation, irrespective of frequency, forcing learners to manage a larger initial set of novel grammatical rules.
3. Isolate irregular forms only to basic plural nouns (mice, feet), treating all verb morphology as the primary target for complete regularization within the standard.

**Trade-Off / Risk:** Sacrificing consistency for high-frequency recognition reduces the linguistic lift of the standard, creating persistent friction points that undermine the overall goal of fixing high-friction inconsistencies over the long term.

**Strategic Connections:**

**Synergy:** Amplifies Core Lexicon Update Strategy; a higher threshold reduces the labor required on defining pronunciation guidance for many familiar irregular forms in the dictionary.

**Conflict:** Trades off against Phase 2 Pilot Data Go/No-Go Metrics, as retaining too many irregularities may cause the learner retention or comprehension score benchmarks to be missed.

**Justification:** *Critical*, This determines the core linguistic utility versus feasibility trade-off. It directly influences the 'high-friction' goal while simultaneously risking failure on the two-week intelligibility benchmark, linking it to core success metrics.

### Decision 3: Pilot Cohort Selection and Priority
**Lever ID:** `ffc98025-ac6a-4c66-91c7-932b21a21128`

**The Core Decision:** This lever dictates the initial focus group for usability testing, which sets the learning curve expectations for the entire project. Prioritizing ESL learners validates the remedial aspects of the standard, whereas professional focus validates its efficiency gains. Success is measured by positive feedback on curriculum satisfaction from the prioritized cohort and early identification of critical usability gaps.

**Why It Matters:** Prioritizing adult ESL learners ensures early validation against the highest expected friction points—pronunciation and morphology—which directly validates the project's core linguistic assumptions. Focusing solely on this group might delay crucial feedback from native professionals in safety-critical documentation who adhere to established norms.

**Strategic Choices:**

1. Commit eighty percent of Phase 2 effort to developing materials and testing solely with native speakers using the safety-critical glossary, validating professional utility first.
2. Structure the pilot to run parallel tracks, dividing resources equally between adult ESL cohorts learning from scratch and native technical writers focused only on applying the disambiguation rules.
3. Begin pilots exclusively with native speakers using the technical glossary to measure comprehension speed, only introducing ESL cohorts once the rule set stability is confirmed past the first nine months.

**Trade-Off / Risk:** Prioritizing native technical writers risks creating a standard optimized for compliance rather than learning ease, potentially hindering the long-term educational adoption pathway required for broader cultural impact.

**Strategic Connections:**

**Synergy:** Strongly supports Budget Allocation Strategy by concentrating Phase 2 resources, ensuring the defined pilot curriculum receives focused, high-touch deployment regardless of the budget split.

**Conflict:** Conflicts with Outreach Strategy for Early Adopters, as an unbalanced focus may alienate the neglected cohort (either ESL publishers or technical documentation teams) during initial engagement.

**Justification:** *High*, This lever governs the focus of Phase 2 testing, determining whether the standard is validated for its educational (ESL) or professional (safety-critical) objective. It strongly dictates resource allocation and feedback quality.

### Decision 4: Governance Structure Selection
**Lever ID:** `3abd9b35-3dc6-4643-88d3-5498e3aa4dbc`

**The Core Decision:** This defines the ownership and decision-making flow for resolving ambiguities during the standard's development and review cycle. A centralized structure risks low legitimacy but offers speed, while consensus-driven governance ensures broad buy-in but risks timeline slippage. The key outcome is a governance framework that prevents rule deadlock during pilot iteration.

**Why It Matters:** Establishing a small, internal editorial board composed solely of internal staff prioritizes speed and tight control over the project timeline, ensuring rapid response to internal testing failures. This centralization risks alienating external linguistic bodies required for later legitimacy and broad adoption trust.

**Strategic Choices:**

1. Form a lean, internal Editorial Board comprising only the Lead Linguist and Project Manager, granting them expedited authority to resolve minor rule ambiguities during Phase 2 testing.
2. Establish an external advisory board governed by formal majority voting, requiring cross-discipline consensus before finalizing any rule change, heavily prioritizing legitimacy over speed.
3. Defer the formal governance structure setup until Phase 3, dedicating Phase 1 and 2 solely to technical rule generation without external oversight or broad consultation.

**Trade-Off / Risk:** Deferring governance introduces significant risk of fragmentation late in the project, as external stakeholders will treat the final published standard as an imposed mandate rather than a collaboratively developed consensus.

**Strategic Connections:**

**Synergy:** Enables effectiveness of Phase 2 Pilot Data Go/No-Go Metrics by providing a clear, agreed-upon body empowered to interpret real-time pilot failures and authorize rule adjustments post-decision.

**Conflict:** Conflicts with Budget Allocation Strategy; establishing an external or consensus-based board requires significant budgetary allocation for meetings, travel, and external expert compensation.

**Justification:** *Critical*, This is the central hub for resolving all future ambiguities and ensuring project momentum. Its structure dictates the speed and legitimacy of rule refinement, impacting every deliverable and the Go/No-Go decision.

### Decision 5: Phase 2 Pilot Data Go/No-Go Metrics
**Lever ID:** `3b79c090-d2d9-4d7f-921a-5f1a2304038b`

**The Core Decision:** This lever defines the quantitative criteria and weightings used to decide whether the project proceeds from pilot testing (Phase 2) to public standard release (Phase 3). Establishing strict governance over these metrics ensures that adoption is contingent only upon proven efficacy in the target environments, mitigating risk exposure.

**Why It Matters:** Tying the Phase 3 launch decision strictly to measurable pilot outcomes forces a trade-off between speed and demonstrated efficacy. If retention rates are high but ordinal error rates are also high, a strict gate forces a costly redesign, whereas favoring speed might launch a standard that requires significant post-launch patching.

**Strategic Choices:**

1. Execute the Phase 3 launch only if all four stated metrics (comprehension speed, ordinal error, consistency score, and retention) meet or exceed 90% of their respective internal targets.
2. Establish a weighted decision matrix where learner retention is worth 60% of the total score, allowing high retention to compensate for moderate failures in pronunciation consistency.
3. Implement a binary 'No-Go' switch if the average adult comprehension time in the pilot exceeds 14 days, regardless of performance on other metrics, prioritizing the 2-week intelligibility constraint.

**Trade-Off / Risk:** Weighting retention over other metrics risks signing off on a standard that is easy to learn but fails to deliver the necessary technical precision required for safety-critical documentation fields.

**Strategic Connections:**

**Synergy:** Synergizes critically with Pilot Cohort Selection and Priority; the chosen metrics validate or invalidate the learning curve observed specifically within the chosen pilot groups.

**Conflict:** Conflicts with Budget Allocation Strategy; failure based on these metrics forces a costly realignment or extension of Phase 2 activities, consuming contingency funds.

**Justification:** *Critical*, This lever formalizes the project's ultimate success condition. It controls the gateway to Phase 3 and provides the concrete feedback loop necessary to validate the entire effort against the comprehensibility constraint.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Budget Allocation Strategy
**Lever ID:** `813dc096-f956-4866-ace0-e06ed90f1fa7`

**The Core Decision:** This lever controls the temporal distribution of financial resources, directly impacting the staffing and duration of foundational rule definition versus final adoption activities. Extreme front-loading risks under-resourcing the mandated outreach and licensing activities in Phase 3, while linear distribution may lead to insufficient depth in the initial linguistic specification.

**Why It Matters:** Front-loading the budget into Phase 1 heavily invests in foundational linguistic theory and corpus construction, maximizing the quality of the 'Clear English Standard v1.0' deliverable. This creates a significant cost pressure in Phase 3, potentially necessitating reduced spending on the critical public licensing and outreach necessary for adoption.

**Strategic Choices:**

1. Allocate 45% of the total budget to Phase 1 (Specification and Corpus), allowing for intensive external linguistic consulting and rigorous referencing during rule finalization.
2. Maintain a strictly linear budget distribution across Phases 1, 2, and 3, emphasizing sustained outreach efforts in Phase 3 to guarantee visibility and early adoption momentum.
3. Reserve a 20% contingency pool until the Phase 2 Go/No-Go decision, forcing austerity in early rule definition but buffering against unforeseen delays in pilot material production.

**Trade-Off / Risk:** Front-loading the budget creates a structural risk by undersupporting the final, crucial publication and outreach phase, potentially delivering a perfect standard that nobody knows how to implement.

**Strategic Connections:**

**Synergy:** Directly enables Governance Structure Selection; a front-loaded budget allows for hiring premium linguistic talent early to establish high-quality governance processes during Phase 1 specification.

**Conflict:** Trades off against Outreach Strategy for Early Adopters, as heavy investment in Phase 1 specification leaves fewer funds available for active, widespread promotional activities necessary for adoption.

**Justification:** *High*, Controls the feasibility of high-quality rule definition (Phase 1) versus necessary market entry activities (Phase 3 outreach). It's a foundational constraint that directly enables or cripples subsequent strategic activities.

### Decision 7: Irregularity Retention Threshold
**Lever ID:** `c8b548d1-d8f2-46e3-9816-6e5404f219ae`

**The Core Decision:** This lever dictates the balance between linguistic purity and rapid standardization progress by defining which irregular forms (verbs, plurals) are altered versus retained in the core lexicon. A high threshold minimizes initial changes, speeding up Phase 1 rule definition. Success hinges on ensuring retained irregularities do not impede the critical two-week comprehension goal for new learners.

**Why It Matters:** Establishing a high threshold for retaining irregular verb/plural forms minimizes changes needed in the 5,000-word core lexicon and accelerates rule finalization for Phase 1. However, retaining frequent, high-impact irregulars known to confuse ESL learners may violate the two-week comprehension goal, forcing extensive remediation within the Phase 2 pilot curriculum materials.

**Strategic Choices:**

1. Retain all irregular forms whose existing frequency in published corpora exceeds ninety percent of the fully regularized alternative's frequency, prioritizing immediate recognition.
2. Regularize only those verb forms exhibiting complete stem vowel change (e.g., sing/sang/sung) and retain all other forms, regardless of frequency, to limit scope.
3. Mandate regularization for all verbs occurring more than once per every thousand words in the final reference corpus, aggressively pruning exceptions.

**Trade-Off / Risk:** Defining regularization based on corpus frequency risks keeping difficult exceptions if they frequently appear in established technical texts, thereby undermining the primary goal of rapid learner comprehension.

**Strategic Connections:**

**Synergy:** Synergizes with Core Lexicon Update Strategy by directly influencing which existing words necessitate new pronunciation mapping rules during Phase 1 setup.

**Conflict:** Conflicts with Phase 2 Pilot Data Go/No-Go Metrics, as retaining difficult irregularities might cause low learner retention scores, potentially triggering a No-Go decision.

**Justification:** *Medium*, While highly related to Morphological Regularization Threshold, this lever focuses more narrowly on the *scope* of retained irregularities. It is slightly less critical as the 'threshold' (a4438d22) better defines the overall strategic tension.

### Decision 8: Homograph Disambiguation Policy
**Lever ID:** `143bd64b-e0fd-4888-85a6-c2e095973c95`

**The Core Decision:** This policy governs the introduction of explicit textual cues to resolve meaning differences between homographs (e.g., homographs used in technical writing). The scope ranges from mandated markers to complete omission. Success requires ensuring technical clarity without overloading the style guide or discouraging user adoption due to perceived clutter.

**Why It Matters:** Introducing required, optional markers for high-impact homographs simplifies parsing ambiguity in safety-critical text, satisfying the objective's requirement for technical documentation clarity. However, requiring editors to use these markers adds a substantial verification step to the Phase 3 style guide compliance checks and may encourage users to ignore stylistic markers entirely if adoption is not universal.

**Strategic Choices:**

1. Implement a mandatory slash-notation disambiguator (e.g., lead/metal or lead/guide) only for the top five confusing pairs, enforced via automated corpus scanning pre-publication.
2. Omit all explicit disambiguation markers, relying solely on surrounding lexical context for resolution, placing the burden entirely on the two-week comprehension target.
3. Introduce optional, minimal diacritics (e.g., dot over the vowel) for all homographs, which are encouraged but never strictly enforced in the v1.0 standard.

**Trade-Off / Risk:** Omitting explicit disambiguation relies entirely on context absorption within two weeks, heavily risking failure in safety documentation where misinterpretation of homophones like 'lead' has high consequence impact.

**Strategic Connections:**

**Synergy:** Enhances the effectiveness of Pilot Cohort Selection and Priority by providing clear, unambiguous material for cohorts focused on safety-critical documentation use cases.

**Conflict:** Conflicts with Outreach Strategy for Early Adopters, as mandatory markers (the clearest option) may be seen as overly aggressive by potential partners accustomed to context-only disambiguation.

**Justification:** *Medium*, This addresses a scoped friction point (homographs) important for safety documentation. It is less central than morphology or governance, primarily impacting the style guide and pilot validation material construction.

### Decision 9: Core Lexicon Update Strategy
**Lever ID:** `06cc5f1a-6cd9-4a7d-9e38-ad4773946ff7`

**The Core Decision:** This strategy manages the contents and mapping procedures for the 5,000-word standardized lexicon. It balances adherence to new phonetic rules against leveraging existing high-frequency vocabulary for native speaker intelligibility. Success is measured by the ease of creating the reference dictionary and its immediate comprehensibility score.

**Why It Matters:** The decision on how to handle the 5,000-word core lexicon profoundly impacts the mapping complexity and the intelligibility goal. Choosing to prioritize phonetically regular words over existing high-frequency standard words simplifies the reference dictionary but immediately raises the barrier for native speaker acceptance in the short term.

**Strategic Choices:**

1. Map the Clear English pronunciation guide only to standard English words that already possess a near-regular spelling pattern, minimizing required lexicon substitution.
2. Replace the 50 least phonetically regular words in the core 5,000 list with demonstrably regular synonyms, accepting a slight increase in translation distance.
3. Designate the Core Lexicon as a pure transliteration database, enforcing no required replacement of existing words, even if they clash with broader spelling-to-sound rules.

**Trade-Off / Risk:** Prioritizing lexical substitution over phonetic consistency directly undermines the goal of a consistent grapheme-to-phoneme mapping, creating isolated anomalies within the standardized pronunciation guide.

**Strategic Connections:**

**Synergy:** Directly enables the successful execution of the Phase 2 Pilot Data Go/No-Go Metrics by providing the tested material used to measure comprehension speed and learner retention.

**Conflict:** Creates a potential trade-off with Morphological Regularization Threshold; aggressively replacing words for regularity might conflict with retaining necessary high-frequency irregular forms.

**Justification:** *Medium*, Primarily tactical concerning the structure of the dictionary deliverable. It supports the spelling/sound goal but is secondary to the high-level regularization decisions (A4438d22) that define which words are even present.

### Decision 10: Outreach Strategy for Early Adopters
**Lever ID:** `fe94333b-6fe4-47bc-8c19-c7c48cdc4a64`

**The Core Decision:** This strategy focuses on engaging specific, influential groups—like technical firms or publishers—early to validate and integrate the initial standard drafts. Its success is quantified by securing high-profile commitments, which legitimizes the 'Clear English' variant for its intended professional and educational scopes.

**Why It Matters:** The method chosen for initial outreach shapes the perception of the standard; focusing narrowly on academic linguistics risks alienating the primary target markets of technical writing and ESL publishers. Conversely, aggressive marketing might trigger the risk of perceived mandate or premature adoption before rule finalization.

**Strategic Choices:**

1. Secure one major, highly visible technical documentation firm as a committed 'Lighthouse Partnership' to exclusively pilot the standard internally for Phase 3 validation.
2. Focus all outreach efforts solely on collaborating with established ESL textbook publishers to integrate the standard into their next revision cycle, bypassing complex technical review boards.
3. Fund a competitive grant program for independent linguistic researchers to stress-test the rule set against fringe orthographic cases, using findings to refine the final style guide.

**Trade-Off / Risk:** Funding external grants introduces a high degree of uncertainty regarding the actionable nature of the feedback, potentially diverting resources from necessary pilot curriculum development and testing.

**Strategic Connections:**

**Synergy:** Amplifies the effectiveness of Governance Structure Selection by ensuring that the editorial board receives relevant, high-stakes utilization feedback prior to formal standard publication.

**Conflict:** May conflict with Irregularity Retention Threshold; aggressive outreach might generate early demands to alter finalized rules, forcing re-work or slowing down rule finalization established in Phase 1.

**Justification:** *High*, Since the purpose is business/adoption, defining the initial adoption path is paramount. It mitigates the risk of fragmentation and sets the groundwork for the mandated public licensing success in Phase 3.
