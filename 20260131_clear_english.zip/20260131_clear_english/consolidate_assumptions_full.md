# Purpose

**Purpose:** business

**Purpose Detailed:** Strategic planning and execution for developing a new standardized language variant intended for technical documentation, education, and ESL instruction. This constitutes a large-scale, formal project aimed at creating a specialized, auditable standard for societal use, aligning with business/professional project management and standardization efforts.

**Topic:** Development and controlled rollout of a standardized, simplified variant of English ('Clear English').

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** The plan involves the development, standardization, material creation (corpus, dictionary, curriculum), piloting, and governance setup for a new linguistic standard ('Clear English'). This is a complex project that requires human effort, physical infrastructure (offices, computing resources, meeting spaces for the editorial board and linguistic reviewers), and the physical creation and testing of print and potentially physical pilot materials/assessments. While much of the analysis is digital, setting up the governance, creating the reference corpus, running pilots with physical/local cohorts, and publishing a formal standard are all activities that require a physical presence and resources. Therefore, the overall plan is classified as physical due to the management and execution requirements of a formal, multi-phase standardization project.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Space for governance meetings (Editorial Board, Linguistic Review)
- Facilities for developing and hosting computer resources for corpus management
- Proximity to potential pilot cohort testing sites (adult ESL centers or technical documentation firms)
- Access to administrative/professional support staff

## Location 1
USA

Washington D.C. / Northern Virginia (NoVA)

Flexible Office Space near Federal Triangle or Rosslyn area

**Rationale**: High density of standards organizations (NIST, ANSI), strong technical writing industry presence, and accessibility for linguistic experts and policy meetings (governance activation).

## Location 2
United Kingdom

London Metropark Area

Co-working space focusing on knowledge-based startups (e.g., Shoreditch/Tech City)

**Rationale**: Access to global linguistic talent pool, strong presence of major ESL publishing houses (relevant for Phase 3 launch), and established mechanisms for international standards development.

## Location 3
USA

Southeastern US (e.g., Atlanta or Raleigh-Durham)

University Research Park Proximity

**Rationale**: Lower operational cost compared to D.C./NYC while providing excellent access to major universities with strong Applied Linguistics departments to recruit for internal work and pilot integration feedback.

## Location Summary
Since this project requires formal governance setup, corpus management infrastructure, pilot execution coordination, and interactions with standards bodies, a centralized operational hub is necessary. Locations in the Washington D.C. area (for standards access), London (for global reach and publishing), and a lower-cost US research hub (for recruitment and operational efficiency) are recommended to support Phase 1 development and Phase 2 piloting.

# Currency Strategy

This plan involves money.

## Currencies

- **USD:** The project budget is defined in USD ($3.5M), and the identified operational hubs are primarily in the USA, making USD the default accounting currency.
- **GBP:** One key operational hub is proposed for London, UK, requiring expenditures in local currency for physical space and local staff.

**Primary currency:** USD

**Currency strategy:** The project is budgeted entirely in USD ($3.5M). All international expenditures in the UK (GBP) should be managed by converting necessary operational amounts from the USD budget, using forward contracts or strategic timing to mitigate exchange rate fluctuations during the three-year execution period.

# Identify Risks


## Risk 1 - Financial
The chosen 'Pioneer' strategy front-loads 50% of the $3.5M budget into Phase 1 for rigorous linguistic definition, leaving a constrained $1.75M for 24 months of piloting, material creation, and public launch (Phases 2 & 3). If corpus development or governance activation (Decision 3) exceeds Phase 1 estimates, crucial development work in Phase 2 (curriculum creation, pilot management) may be underfunded.

**Impact:** A Phase 1 budget overrun exceeding $200,000 (5.7% of total budget) would necessitate severe cuts to Phase 2 pilot scope and rigor, potentially invalidating the Go/No-Go metrics or severely compromising the Phase 3 outreach plan.

**Likelihood:** Medium

**Severity:** High

**Action:** Implement rigorous earned value management (EVM) tracking specifically on Phase 1 linguistic deliverables. Immediately allocate $350,000 (10% of total) into a dedicated contingency pool released only after Phase 1 sign-off, forcing the initial specification work to operate on a strict $3.15M basis.

## Risk 2 - Technical/Linguistic
The chosen Ordinal Standardization Approach commits to numeric + invariant markers (e.g., '5th'). While simplifying the rule set, this introduces friction in digital text processing (Decision 1). If required tagging/parsing tools for seamless integration into existing technical documentation workflows are not developed or procured in Phase 2, adoption will stall.

**Impact:** Integration delays of 3–6 months in Phase 3 adoption, and potentially $50,000–$100,000 in unplanned custom software procurement or development costs during Phase 2 setup.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Task a small technical working group during Phase 1 to define strict XML/SGML tagging standards for ordinal markers. Allocate a specific line item ($40,000) within the Phase 2 budget for contracting one specialist to develop/validate a proof-of-concept integration parser for a major technical documentation platform.

## Risk 3 - Social/Acceptance
The project aims for intelligibility within 2 weeks, relying heavily on the Morphology Regularization Threshold (Decision 2) which prioritizes regularizing opaque irregularities (e.g., 'went'). If the set of retained, irregular, high-frequency words (those below the regularization threshold) is still too large or contextually confusing, native speaker perception of 'artificiality' or ESL learner frustration will lead to significant pushback, undermining the soft launch.

**Impact:** If pilot cohorts (native speakers) rate 'naturalness' below 6/10, the perceived value decreases, leading to public relations challenges that could derail Phase 3 licensing efforts, yielding zero adoption ROI.

**Likelihood:** High

**Severity:** High

**Action:** Mitigate by selecting the cognitive load threshold (Choice 2 in Decision 2) rather than frequency alone. Explicitly include a qualitative section in the Phase 2 assessment focused *only* on perceived naturalness and aesthetic acceptance from native speakers, feeding this score directly into the Go/No-Go metrics calibration (Decision 8).

## Risk 4 - Regulatory & Permitting / Governance
The Governance Structure is mobilized early (Pioneer strategy) by securing full external commitments for the Linguistic Review panel in Phase 1. If key linguistic experts (especially those with necessary academic standing) cannot commit their time for stipends commensurate with the tight Phase 1 budget constraints, the review process will be delayed, and the quality assurance foundation will be compromised.

**Impact:** A 4–6 week delay in Phase 1 rule finalization due to expert unavailability, resulting in a delayed start for Phase 2 and potentially consuming project contingency funds to retain staff.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Prioritize securing commitment letters alongside budget estimates for Phase 1 stipends. Have a pre-approved 'back-up' pool of three secondary reviewers identified during Phase 1 planning, authorized to step in immediately if primary choices fail to finalize contracts within the first 60 days.

## Risk 5 - Operational/Integration
The project requires launching pilot cohorts using safety-critical or technical glossaries. If the newly defined Core Lexicon (5,000 words) mapping to Standard English does not perfectly align or if ambiguity/error exists in the mapping for crucial safety terms, regulatory liability concerns could arise concerning the pilot materials themselves.

**Impact:** If mapping errors are found in safety-relevant terms during Phase 2, remediation requires a full iteration of corpus/curriculum updates (an estimated 6-week delay) and may introduce potential legal exposure depending on the jurisdiction of the pilot.

**Likelihood:** Low

**Severity:** High

**Action:** Implement a mandatory 'Safety Critical Double-Blind Review' sweep during the final month of Phase 1, where two independent, certified domain experts (e.g., aviation safety writer, medical technical communicator) review the 500 highest-frequency technical terms for zero-tolerance errors before materials are printed for Phase 2.

## Risk 6 - Supply Chain / Physical Logistics
Phase 2 requires utilizing physical locations (D.C., London, SE US) for governance/pilot coordination, necessitating expenditure in GBP for the London hub. Exchange rate volatility between USD (budget currency) and GBP could cause operational budget shortfalls for physical space leases and local administrative support in the UK during the 3-year period.

**Impact:** A sustained 15% adverse shift in the USD/GBP exchange rate could necessitate cutting 4 months of physical office rental/support staff in London, impacting governance meeting logistics or pilot coordination effectiveness.

**Likelihood:** Medium

**Severity:** Medium

**Action:** As per currency strategy, use USD-denominated contracts for long-term staff where possible (hiring US-based remote staff serving the UK hub). For physical leases in London, attempt to secure a fixed-rate GBP payment schedule for the first 18 months or purchase moderate-sized forward contracts covering the high-cost Phase 2 period.

## Risk 7 - Technical/Linguistic
The Grapheme-to-Phoneme Mapping Strategy prioritizes strict clarity over phonetic diversity (Decision 6). This risks creating pronunciation rules that are technically consistent but feel highly unnatural or result in 'monotone' text when used by native speakers, potentially leading to compliance failure on the 'intelligible to current English speakers' constraint.

**Impact:** If Phase 2 pilot materials are perceived as sounding 'alien' or machine-generated, the overall perceived utility plummets, failing the intelligibility goal even if measurable comprehension scores are met.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Adopt Strategy 1 (strict mapping) for Phase 1 definition but integrate Strategy 3 (optional diacritics) into the Style Guide (Deliverable). These diacritics serve as optional 'enhancements' for native speakers, allowing the core curriculum to be strictly phonetic while offering pathways to higher performance/naturalness.

## Risk summary
This project faces high-leverage risks stemming fundamentally from the ambitious linguistic scope constrained by a tight budget and timeline. The two most critical risks are **Financial Underfunding** due to the 50% budget front-loading required by the 'Pioneer' strategy, and **Social/Acceptance Risk** concerning the perceived naturalness of the strict morphological changes. If the upfront linguistic rigor (Phase 1) overruns costs, Phase 2 piloting will be crippled, failing to generate the validation data required for the Go/No-Go gate. Mitigation requires tight budgetary controls (EVM) and prioritizing the qualitative feedback on 'naturalness' during pilot testing to ensure the linguistic purity achieved academically translates into usable acceptance.

A secondary, high-impact risk is the creation of **Integration Friction** due to the chosen numeric ordinal markers, which burdens ongoing costs for Phase 3 adoption infrastructure.

# Make Assumptions


## Question 1 - Given the $3.5M budget and the 'Pioneer' strategy front-loading 50% to Phase 1, what specific USD allocation (and corresponding percentage) will be assigned to Phase 1 (Specification/Corpus), Phase 2 (Pilot/Testing), and Phase 3 (Standardization/Launch)?

**Assumptions:** Assumption: Following the Pioneer strategy, the budget split will be precisely 50% for Phase 1 ($1.75M), 25% for Phase 2 ($875k), and 25% for Phase 3 ($875k) to ensure maximum investment in foundational rule definition while maintaining equal operational support for piloting and launch outreach.

**Assessments:** Title: Financial Feasibility Assessment
Description: Evaluation of the budget allocation across the three mandated phases based on the chosen Pioneer strategy.
Details: Front-loading Phase 1 ($1.75M) is aggressive but supports the goal of linguistic purity. The $875k allocated to Phase 2 must rigorously cover curriculum development and cohort management; risk lies in underestimating pilot infrastructure costs. If Phase 1 exceeds $1.8M, Phase 3 outreach budget ($875k) is immediately threatened, impacting the ability to secure initial third-party licensing agreements.

## Question 2 - What is the defined milestone (e.g., date or deliverable completion) for the formal conclusion of Phase 1, and what specific metric defines the successful completion of the Phase 2 Pilot Go/No-Go validation against the 2-week intelligibility target (e.g., required median comprehension score)?

**Assumptions:** Assumption: The project start date being 'ASAP' from 2026-Jan-31 means Phase 1 concludes on 2027-Jan-31. The Go/No-Go threshold requires 85% of the pilot participants to demonstrate comprehension equivalent to 90% of the native baseline within 14 days.

**Assessments:** Title: Timeline and Milestone Risk Assessment
Description: Analysis of schedule adherence risk based on defined phase lengths and validation success criteria.
Details: A firm 3-year timeline is tight given the complexity. If Phase 1 specification slides by more than one month, the 12-month Phase 2 pilot execution window is compressed, jeopardizing data integrity for the Go/No-Go decision. The 85%/90% comprehension metric is ambitious; achieving it requires rigorous statistical validation, which must be scoped within the Phase 2 budget ($875k).

## Question 3 - Considering the early activation of the full Linguistic Review panel in Phase 1 (Pioneer strategy), what is the planned headcount and estimated full-time equivalent (FTE) allocation required for the core internal Linguistics/Development Team responsible for corpus mapping and style guide drafting?

**Assumptions:** Assumption: The core team (Project Management, Senior Linguists, Technical Writers) requires 5 dedicated FTEs for Phase 1, supplemented by specialized contractors for corpus tool development. External Linguistic Review stipends are budgeted separately within the Phase 1 operational overhead.

**Assessments:** Title: Resource Allocation and Expertise Assessment
Description: Evaluation of personnel requirements needed to populate the core team supporting early governance.
Details: Relying on 5 FTEs plus contractors to deliver the reference corpus, dictionary, and style guide under tight Phase 1 deadlines is resource-intensive. The $1.75M Phase 1 budget must cover these salaries; if recruitment is slow (Risk 4), the external review body may have insufficient material to review on schedule, necessitating higher contractor costs to catch up.

## Question 4 - What specific regulatory or standardization body (e.g., ISO, relevant National Standards Body) will be leveraged or consulted during Phase 1 to ensure the 'Clear English Standard v1.0' metadata and documentation structure align with established technical documentation standards?

**Assumptions:** Assumption: Due to the D.C./NoVA location targeting standards bodies, the project will align its formal documentation structure (versioning, change control) with ISO standards for technical specifications (e.g., ISO/IEC Directives, Part 2), even if formal accreditation is not sought.

**Assessments:** Title: Governance and Regulatory Mapping Assessment
Description: Review of adherence to external standards frameworks to ensure professional acceptance of v1.0.
Details: Aligning documentation structure with ISO/IEC directives (even without formal submission) minimizes friction for technical writers adopting the standard in Phase 3. Failure to define this structure early risks creating a proprietary format that external partners (and the Governance Board) find cumbersome to audit or integrate into existing quality systems.

## Question 5 - What baseline risk level (Low, Medium, High) is assigned to the failure of the chosen Ordinal Strategy (numeric + invariant marker) to integrate technically with dominant commercial publishing tools, and what corresponding Phase 2 mitigation budget line item is reserved for custom parser development?

**Assumptions:** Assumption: The risk of technical integration friction for the numeric marker approach is assigned a 'High' impact but 'Medium' likelihood, as identified in the risk register. A baseline of $40,000 USD is provisionally carved out from the Phase 2 budget for specialized developer contracting.

**Assessments:** Title: Safety and Risk Management Efficacy
Description: Assessment of the robustness of mitigation plans related to the high-novelty technical decisions.
Details: The $40k allocation is a reasonable starting point but must be rigorously tracked. If internal testing in Phase 1 reveals deeper incompatibilities (e.g., dependency on specific XML schemas), this budget line item may be invalidated, requiring a mid-project reallocation from the Pilot Curriculum budget ($875k), thus increasing Risk 1 (Financial Underfunding).

## Question 6 - Which specific environmental or ecological impact assessment is required for the production and distribution of the initial pilot curriculum materials, especially considering the potential need for physical print runs in both US and UK locations?

**Assumptions:** Assumption: Given the focus on technical documentation, the pilot print runs will be limited (no more than 200 printed materials sets total). The environmental assessment will focus primarily on sustainable paper sourcing (FSC certification) for the physical materials used in the Phase 2 cohorts.

**Assessments:** Title: Environmental Impact Mitigation Strategy
Description: Evaluation of the footprint related to physical material creation and logistic coordination.
Details: While the primary outputs are digital standards, the requirement for physical curriculum materials in Phase 2 (per plan_type.md) necessitates a basic audit. To comply with potential internal sustainability goals, prioritize digital-first learning modules and use certified, low-impact printing partners for the limited physical runs in the US and UK locations, thereby minimizing regulatory scrutiny and reputational risk.

## Question 7 - Regarding Stakeholder Involvement, which specific industry associations (besides ESL publishers) will be targeted for formal consultation or partnership during Phase 1 outreach to validate the technical necessity of the 5,000-word core lexicon scope?

**Assumptions:** Assumption: Outreach in Phase 1 will prioritize direct engagement with one major global standards body (e.g., relevant committee within ISO/IEC JTC 1) and one major technical writing trade organization (e.g., STC) to validate the lexicon's utility for technical documentation.

**Assessments:** Title: Stakeholder Engagement and Adoption Pathway Assessment
Description: Analysis of proactive engagement strategies required for ensuring external buy-in for the parallel standard.
Details: Early engagement with standards bodies is critical for the Pioneer strategy. Failure to secure letters of support/buy-in from these groups by the end of Phase 1 will render the Phase 3 licensing policy ineffective, as technical infrastructure providers will await external validation before investing integration effort.

## Question 8 - What fundamental technology platform (e.g., database structure, markup language) will be mandated in Phase 1 for the storage and querying of the Reference Dictionary (including Grapheme-to-Phoneme mappings) to ensure immediate operational system compatibility across the diverse physical/digital environments required for Phase 2 piloting?

**Assumptions:** Assumption: The Reference Dictionary will utilize a self-describing, text-based format (preferably JSON or XML compliant with an underlying TEI schema) to ensure maximum portability between the D.C. operational hub, the London consultation space, and subsequent digital curriculum deployment tools.

**Assessments:** Title: Operational Systems Design and Portability Assessment
Description: Evaluation of foundational technology choices for managing the core intellectual property (the dictionary and rules).
Details: Mandating a widely interoperable format like XML/TEI minimizes the technical debt and integration friction identified in Risk 2. However, the implementation team must dedicate resources early in Phase 1 to developing robust API endpoints connecting the dictionary database to the Pilot Curriculum delivery system, otherwise, Phase 2 testing data collection will be manually intensive and prone to error.

# Distill Assumptions

- Budget split is 50% ($1.75M) Phase 1, 25% ($875k) Phase 2, 25% ($875k) Phase 3.
- Phase 1 concludes 12 months after start (2027-Jan-31).
- Go/No-Go requires 85% comprehending 90% of native baseline in 14 days.
- Core team needs 5 FTEs plus contractors for Phase 1 corpus mapping.
- Documentation structure aligns with ISO/IEC standards for technical specifications.
- Ordinal marker risk is High impact/Medium likelihood; $40k reserved for parser development.
- Pilot print runs limited to 200 sets; focus on FSC certified sustainable sourcing.
- Phase 1 outreach targets one major standards body and one technical writing organization.
- Reference Dictionary mandates portable JSON/XML format, requiring early API development.
- Average adult comprehension goal is equivalent to one week of exposure success.
- Intelligibility requires a 3-year program divided into three 12-month gated phases.
- One specific approach is chosen for ordinal standardization (numeric marker assumed).
- A subset of irregular morphology changes are regularized based on cognitive load.
- Full 5-member Linguistic Review panel secured upfront for Phase 1 rule review.
- Grapheme mapping prioritizes strict clarity over phonetic diversity for consistency.
- Pilot curriculum must serve both ESL learners and native speakers effectively.
- Go/No-Go decision authority rests with the external Linguistic Review panel post-Phase 2.
- Lexicon scope is capped at 5,000 words with pronunciation guidance.

# Review Assumptions

## Domain of the expert reviewer
Strategic Project Risk & Linguistic Standardization Management

## Domain-specific considerations

- Interdependency between linguistic scope (Morphology) and budget constraints.
- Accurate quantification of stakeholder acceptance (naturalness vs. correctness).
- Governance timing versus initial intellectual property development quality.
- Managing physical execution alongside digital standardization goals.

## Issue 1 - Critical Missing Assumption: Sustainability of Adoption Infrastructure (Phase 3 Resources)
The Pioneer strategy front-loads 50% of the budget ($1.75M) into Phase 1 rules definition, leaving only 25% ($875k) for Phase 3 launch and outreach. The analysis heavily assumes subsequent licensing/adoption will fund operational costs, but there is no explicit assumption guaranteeing that the revenue/licensing pipeline required to sustain the standard *after* the $3.5M project funding expires will materialize. If early adopters are low, or if licensing fees are insufficient to cover ongoing governance/maintenance, the standard risks obsolescence shortly after v1.0 release.

**Recommendation:** Introduce a mandatory Phase 2 success metric: Secure Letters of Intent (LOI) for commercial licensing agreements that, in aggregate, cover at least 150% of the proposed Phase 3 operational budget ($875k * 1.5 = $1.31M annual run rate). If LOIs are secured, the $437.5k allocated to Phase 3 outreach can be safely repurposed to bolster Phase 2 rigor. If not, Phase 3 must be reduced to a low-cost, self-sustaining technical documentation release only.

**Sensitivity:** If licensing revenue fails to cover 75% of the annual operational cost (baseline: 0% reliance on revenue), the project's long-term ROI drops from an expected 400% (based on widespread adoption) to 50% within three years post-launch, effectively marking the project a short-term expense rather than a sustainable product line. This risk impacts KPI success post-project by 75-90%.

## Issue 2 - Under-Exploration: Quantifying the Cost of Linguistic 'Naturalness' Trade-off
The project has correctly identified the risk that strict linguistic simplification (Morphology Threshold, Grapheme Mapping) leads to an 'artificial' feel (Risk 3). The chosen mitigation involves accepting cognitive load regularization (Choice 2) and adding qualitative scoring to the Go/No-Go criteria. However, there is no quantified assumption detailing the required budget/time dedicated to iterative refinement *based on* negative naturalness scores found in Phase 2. If the score falls below 7/10, significant remedial work may be needed.

**Recommendation:** Create a dedicated Remediation Contingency budget line item derived from the $875k Phase 2 allocation. Specifically, earmark $150,000 (approx. 17% of Phase 2 budget) for 'Aesthetic Refinement Sprints' activated *only if* the qualitative 'naturalness' score lags by more than 1.0 point below the target. This ring-fences resources for managing the social risk effectively, preventing scope creep into the Phase 3 marketing budget.

**Sensitivity:** If the qualitative naturalness check fails, requiring one full 6-week Remediation Sprint (costing $150,000), the Phase 3 launch timeline will be delayed by 6–10 weeks (due to re-testing and re-publication). This delay reduces the projected ROI by 8-12% due to delayed revenue recognition, assuming a conservative ROI calculation based on a 3-year amortization schedule.

## Issue 3 - Unrealistic Assumption: Phase 1 Timeline Adherence (12 Months)
The assumption mandates a highly complex Phase 1 (Specification/Corpus mapping, defining grammar, securing external governance commitments, defining ISO alignment) be completed in exactly 12 months by 5 FTEs plus contractors against a $1.75M budget. Given the high novelty, the intricate nature of cross-language mapping (Grapheme/Phoneme), and reliance on securing external expert commitments (Risk 4), a 12-month timeline is extremely aggressive and likely exceeds industry benchmarks for true standardization projects.

**Recommendation:** Adjust the timeline assumption: Assume a maximum 14-month duration for Phase 1, viewing the 12-month mark only as an *aggressive stretch goal*. Formally reallocate 5% of the Phase 2 budget ($43,750) to Phase 1 contingency to compensate for the inevitable minor slippage in expert stipend negotiation and final rule locking. This buys necessary buffer time without immediately cannibalizing pilot execution resources.

**Sensitivity:** Delaying Phase 1 conclusion by 1 month (from 12 to 13 months) forces Phase 2 to start 1 month late, compressing the critical pilot window. If the Phase 2 window (originally 12 months) is compressed to 11 months, the statistically significant sample size required for the Go/No-Go decision (85% comprehension) may not be met, potentially leading to a premature or inconclusive Go/No-Go decision, resulting in a 1:5 chance of project failure due to insufficient validation data.

## Review conclusion
The project plan is strategically aggressive ('Pioneer'), prioritizing linguistic quality upfront at the expense of early financial contingency for later phases. The three most critical weaknesses revolve around unassumed risk quantification: 1) The long-term sustainability reliant on un-guaranteed Phase 3 revenue streams; 2) The lack of dedicated resources to remediate the subjective 'naturalness' failure during piloting; and 3) The highly optimistic 12-month timeline for Phase 1 rule definition. Immediate action should involve conditional budget reallocation based on securing Phase 3 revenue commitments, formally ring-fencing funds for aesthetic refinement, and building a necessary 2-month buffer into the initial timeline.