This plan involves money.

## Currencies

- **USD:** Primary budgeting currency recommended for project management and compensating US-based staff/consultants, given the large total budget ($3.5M) and headquarters likely in the US (Boston mentioned).
- **GBP:** Local currency for transactions, payroll, and pilot administration in the UK location (London).
- **CHF:** Local currency for facility/meeting costs associated with hosting the international advisory board in Switzerland (Geneva/Zurich).

**Primary currency:** USD

**Currency strategy:** The project involves significant international operational expenses across the US, UK, and Switzerland. The primary currency for budgeting and contingency management will be USD to consolidate reporting. Payments for local staff, facilities, and localized pilot expenses will occur in GBP or CHF as necessary, but cross-border transactions should ideally be managed via low-fee international payment rails or hedged slightly against USD fluctuation during multi-year budgeting cycles.