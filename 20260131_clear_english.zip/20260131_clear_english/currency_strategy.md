This plan involves money.

## Currencies

- **USD:** The project budget is defined in USD ($3.5M), and the identified operational hubs are primarily in the USA, making USD the default accounting currency.
- **GBP:** One key operational hub is proposed for London, UK, requiring expenditures in local currency for physical space and local staff.

**Primary currency:** USD

**Currency strategy:** The project is budgeted entirely in USD ($3.5M). All international expenditures in the UK (GBP) should be managed by converting necessary operational amounts from the USD budget, using forward contracts or strategic timing to mitigate exchange rate fluctuations during the three-year execution period.