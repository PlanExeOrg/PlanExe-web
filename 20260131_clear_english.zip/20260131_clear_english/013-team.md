*Roles Needed & Example People*

# Roles

## 1. Lead Linguist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Lead linguists are essential for the entire duration of the project to ensure consistency and quality of the Clear English standard.

**Explanation**:
A lead linguist is crucial for defining the rules and structure of Clear English, ensuring it is both consistent and intelligible.

**Consequences**:
Inconsistent or poorly defined linguistic rules, leading to a standard that is difficult to learn and use.

**People Count**:
min 2, max 4, depending on the breadth of linguistic features targeted for regularization.

**Typical Activities**:
Defining the rules and structure of Clear English, ensuring consistency and intelligibility. Conducting linguistic analysis to identify areas for simplification and regularization. Collaborating with other linguists and stakeholders to refine the standard. Reviewing and approving all linguistic changes to the Clear English standard.

**Background Story**:
Alistair Humphrey, originally from Oxford, England, is a seasoned linguist with a Ph.D. in theoretical linguistics from MIT. He has over 15 years of experience in language standardization and simplification projects, including work on international auxiliary languages. Alistair is deeply familiar with the challenges of balancing linguistic consistency with intelligibility and adoption ease. His expertise in phonology, morphology, and syntax makes him particularly relevant for defining the core rules of Clear English.

**Equipment Needs**:
High-performance computer, linguistic software (e.g., corpus analysis tools, phonetic analysis software), access to online linguistic databases, noise-cancelling headphones, transcription software.

**Facility Needs**:
Quiet office space with ergonomic setup, access to meeting rooms for collaboration, access to a library or resource center.

## 2. Curriculum Development Specialist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Curriculum development specialists are needed throughout the project to create and refine learning materials based on pilot feedback.

**Explanation**:
This role is essential for creating learning materials that effectively teach Clear English to target audiences, such as ESL learners and technical writers.

**Consequences**:
Ineffective learning materials, resulting in low comprehension and adoption rates.

**People Count**:
min 2, max 3, depending on the number of pilot cohorts and the variety of learning materials required.

**Typical Activities**:
Creating learning materials that effectively teach Clear English to target audiences. Designing and developing textbooks, digital resources, and assessments. Collaborating with educators and linguists to refine the curriculum based on pilot feedback. Ensuring that learning materials are aligned with the Clear English standard and pedagogical best practices.

**Background Story**:
Maria Rodriguez, hailing from Miami, Florida, is an experienced curriculum developer with a master's degree in education from Columbia University. She has spent the last decade creating ESL learning materials for diverse student populations, including adult learners and K-12 students. Maria is adept at translating complex linguistic concepts into engaging and accessible learning experiences. Her background in instructional design and assessment makes her ideally suited for developing the Clear English pilot curriculum.

**Equipment Needs**:
Computer with curriculum development software (e.g., Adobe Creative Suite, Microsoft Office), access to online educational resources, printer, scanner, camera for creating multimedia content.

**Facility Needs**:
Office space with ergonomic setup, access to meeting rooms for collaboration, access to pilot classrooms for observation and testing.

## 3. Usability and Assessment Expert

**Contract Type**: `independent_contractor`

**Contract Type Justification**: A usability and assessment expert can be contracted for specific phases to design and conduct tests, providing specialized expertise without a long-term commitment.

**Explanation**:
This expert will design and conduct usability tests to ensure Clear English is easy to learn and use, and will develop assessments to measure comprehension and retention.

**Consequences**:
Lack of objective data on the usability and effectiveness of Clear English, leading to a standard that may not meet the needs of its target audience.

**People Count**:
1

**Typical Activities**:
Designing and conducting usability tests to ensure Clear English is easy to learn and use. Developing assessments to measure comprehension and retention. Analyzing data to identify areas for improvement. Providing recommendations for enhancing the usability and effectiveness of the Clear English standard.

**Background Story**:
Kenji Tanaka, a Tokyo native now based in San Francisco, is a freelance usability and assessment expert with a Ph.D. in Human-Computer Interaction from Stanford University. He has extensive experience in designing and conducting usability tests for language learning software and educational platforms. Kenji's expertise in quantitative and qualitative research methods makes him well-equipped to evaluate the usability and effectiveness of Clear English.

**Equipment Needs**:
Computer with usability testing software (e.g., Morae, UserZoom), assessment development tools, eye-tracking equipment (optional), recording equipment (audio/video), statistical analysis software (e.g., SPSS, R).

**Facility Needs**:
Usability testing lab with one-way mirror and recording capabilities, access to pilot classrooms for assessment, quiet office space for data analysis.

## 4. Community Engagement Coordinator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: A community engagement coordinator is crucial for building consensus and addressing concerns among stakeholders throughout the project's lifecycle.

**Explanation**:
This role is vital for building consensus and addressing concerns among stakeholders, such as educators, linguists, and potential users.

**Consequences**:
Stakeholder resistance and lack of buy-in, leading to reduced adoption and potential fragmentation of the standard.

**People Count**:
1

**Typical Activities**:
Building consensus and addressing concerns among stakeholders. Organizing outreach events, workshops, and online forums. Facilitating communication between the project team and the community. Gathering feedback from stakeholders and incorporating it into the project plan.

**Background Story**:
Sarah Chen, originally from Vancouver, Canada, is a community engagement specialist with a background in communications and public relations. She has worked on several large-scale public awareness campaigns, including initiatives to promote literacy and language learning. Sarah is skilled at building relationships with diverse stakeholders and facilitating constructive dialogue. Her experience in community outreach and stakeholder management makes her ideally suited for coordinating community engagement efforts for the Clear English project.

**Equipment Needs**:
Computer with CRM software, social media management tools, email marketing platform, presentation software, audio/video conferencing equipment.

**Facility Needs**:
Office space with ergonomic setup, access to meeting rooms for outreach events, access to presentation equipment (projector, screen, microphone).

## 5. Project Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: A project manager is needed full-time to oversee all aspects of the project and ensure it stays on track.

**Explanation**:
A project manager is needed to oversee all aspects of the project, ensuring it stays on track and within budget.

**Consequences**:
Project delays, budget overruns, and a lack of coordination among team members.

**People Count**:
1

**Typical Activities**:
Overseeing all aspects of the project, ensuring it stays on track and within budget. Developing and maintaining project plans, schedules, and budgets. Coordinating team activities and resolving conflicts. Monitoring progress and reporting to stakeholders.

**Background Story**:
David Miller, a Chicago native, is a seasoned project manager with over 15 years of experience in leading complex projects in the education and technology sectors. He holds a PMP certification and has a proven track record of delivering projects on time and within budget. David is adept at managing cross-functional teams and coordinating diverse activities. His organizational skills and attention to detail make him well-suited for overseeing all aspects of the Clear English project.

**Equipment Needs**:
Computer with project management software (e.g., Asana, Jira, MS Project), communication tools (e.g., Slack, Microsoft Teams), budgeting and financial management software.

**Facility Needs**:
Office space with ergonomic setup, access to meeting rooms for team meetings, access to a printer/scanner.

## 6. Technical Writer / Documentation Specialist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: A technical writer is needed to create and maintain the Clear English Standard document and style guide, requiring consistent involvement.

**Explanation**:
This role is responsible for creating the Clear English Standard document, style guide, and other technical documentation.

**Consequences**:
Lack of clear and comprehensive documentation, making it difficult for others to understand and implement the Clear English standard.

**People Count**:
1

**Typical Activities**:
Creating the Clear English Standard document, style guide, and other technical documentation. Ensuring that the documentation is clear, comprehensive, and easy to understand. Maintaining and updating the documentation as needed. Collaborating with linguists and educators to ensure accuracy and consistency.

**Background Story**:
Emily Carter, from Austin, Texas, is a technical writer and documentation specialist with a degree in English and a minor in linguistics from the University of Texas. She has experience creating technical documentation for software companies and educational institutions. Emily is skilled at translating complex information into clear and concise language. Her expertise in technical writing and documentation makes her ideally suited for creating the Clear English Standard document and style guide.

**Equipment Needs**:
Computer with word processing software, desktop publishing software, version control system (e.g., Git), access to linguistic resources and style guides.

**Facility Needs**:
Quiet office space with ergonomic setup, access to meeting rooms for collaboration, access to a printer/scanner.

## 7. Governance and Standards Liaison

**Contract Type**: `full_time_employee`

**Contract Type Justification**: A governance and standards liaison needs to be consistently engaged with standards organizations and regulatory bodies throughout the project.

**Explanation**:
This role will focus on engaging with standards organizations (ISO, W3C) and regulatory bodies to ensure compliance and promote adoption.

**Consequences**:
Failure to meet regulatory requirements and limited adoption by key organizations.

**People Count**:
1

**Typical Activities**:
Engaging with standards organizations (ISO, W3C) and regulatory bodies to ensure compliance and promote adoption. Monitoring regulatory trends and developments. Participating in relevant committees and working groups. Advocating for the Clear English standard.

**Background Story**:
Raj Patel, originally from Mumbai, India, but now residing in Geneva, Switzerland, is a governance and standards liaison with a background in international relations and regulatory affairs. He has worked for several international organizations, including the United Nations and the World Trade Organization. Raj is skilled at navigating complex regulatory landscapes and building relationships with key stakeholders. His experience in governance and standards makes him ideally suited for engaging with standards organizations and regulatory bodies.

**Equipment Needs**:
Computer with access to regulatory databases and standards documentation, communication tools for international collaboration, presentation software.

**Facility Needs**:
Office space with ergonomic setup, access to meeting rooms for virtual meetings, access to a printer/scanner.

## 8. Funding and Licensing Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: A funding and licensing manager is needed to secure grants and manage licensing agreements, ensuring financial sustainability throughout the project.

**Explanation**:
This role is responsible for securing grant funding and managing licensing agreements to ensure the project's financial sustainability.

**Consequences**:
Insufficient funding and lack of a sustainable revenue stream, leading to project delays or failure.

**People Count**:
min 1, max 2, depending on the complexity of the funding model and the number of licensing agreements.

**Typical Activities**:
Securing grant funding and managing licensing agreements to ensure the project's financial sustainability. Developing financial models and budgets. Identifying potential funding sources and preparing grant proposals. Negotiating licensing agreements with publishers and software developers.

**Background Story**:
Isabella Rossi, an Italian-American from New York City, is a funding and licensing manager with a background in finance and business development. She has experience securing grant funding for non-profit organizations and managing licensing agreements for intellectual property. Isabella is skilled at developing financial models and negotiating contracts. Her expertise in funding and licensing makes her ideally suited for securing grant funding and managing licensing agreements for the Clear English project.

**Equipment Needs**:
Computer with financial modeling software, CRM software, legal document management system, communication tools for outreach to funding sources.

**Facility Needs**:
Office space with ergonomic setup, access to meeting rooms for presentations, access to a printer/scanner.

---

# Omissions

## 1. Accessibility Specialist

The project aims to create a standard for education and technical documentation, which should be accessible to people with disabilities. An accessibility specialist can ensure the Clear English standard and related materials adhere to accessibility guidelines (e.g., WCAG).

**Recommendation**:
Include an accessibility specialist (potentially as a consultant) to review the Clear English standard, style guide, and learning materials for accessibility. This could involve ensuring text is screen reader-compatible, providing alternative text for images, and designing materials that are usable by people with visual, auditory, cognitive, and motor impairments.

## 2. Long-Term Maintenance Plan

The project plan lacks a detailed strategy for the long-term evolution and maintenance of the Clear English standard beyond the initial three-year program. Without a plan for updates, revisions, and community support, the standard risks becoming obsolete or fragmented.

**Recommendation**:
Develop a detailed plan for the long-term maintenance of the Clear English standard, including a governance structure, funding model, and process for incorporating community feedback. This plan should address how the standard will be updated, revised, and supported beyond the initial three-year program.

## 3. Ethical Considerations Review

While data privacy is mentioned, a broader ethical review is missing. Creating a new language standard has potential social and cultural impacts that need careful consideration.

**Recommendation**:
Conduct a thorough ethical review of the project, considering potential biases in the standard, cultural impacts, and the potential for unintended consequences. This review should involve ethicists, linguists, and representatives from diverse communities.

---

# Potential Improvements

## 1. Clarify Go/No-Go Criteria

The go/no-go criteria after Phase 2 (80%+ comprehension, positive feedback, 3+ org adoption) are somewhat vague. 'Positive feedback' is subjective and '3+ org adoption' might not be a strong indicator of long-term success.

**Recommendation**:
Define more specific and measurable criteria for the go/no-go decision after Phase 2. For example, quantify 'positive feedback' through surveys with specific metrics, and define what constitutes 'adoption' by an organization (e.g., using Clear English in official documentation or training materials).

## 2. Refine Stakeholder Engagement

The stakeholder engagement plan mentions surveys, focus groups, and forums, but lacks specifics on how conflicting feedback will be resolved and incorporated into the standard.

**Recommendation**:
Establish a formal process for analyzing stakeholder feedback and resolving conflicting opinions. This could involve creating a stakeholder advisory board with representatives from different groups, developing a decision-making framework for incorporating feedback, and communicating clearly how stakeholder input has influenced the standard.

## 3. Strengthen Financial Sustainability

The funding model relies heavily on grants (70%), which are inherently uncertain. Licensing revenue (30%) is also speculative, especially in the early stages.

**Recommendation**:
Diversify funding sources beyond grants and licensing. Explore alternative revenue models, such as crowdfunding, sponsorships, or partnerships with educational institutions. Develop a detailed financial model with best-case, worst-case, and most-likely scenarios to assess the project's financial viability.