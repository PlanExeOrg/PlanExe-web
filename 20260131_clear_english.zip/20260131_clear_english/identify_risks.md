
## Risk 1 - Financial
The chosen 'Pioneer' strategy front-loads 50% of the $3.5M budget into Phase 1 for rigorous linguistic definition, leaving a constrained $1.75M for 24 months of piloting, material creation, and public launch (Phases 2 & 3). If corpus development or governance activation (Decision 3) exceeds Phase 1 estimates, crucial development work in Phase 2 (curriculum creation, pilot management) may be underfunded.

**Impact:** A Phase 1 budget overrun exceeding $200,000 (5.7% of total budget) would necessitate severe cuts to Phase 2 pilot scope and rigor, potentially invalidating the Go/No-Go metrics or severely compromising the Phase 3 outreach plan.

**Likelihood:** Medium

**Severity:** High

**Action:** Implement rigorous earned value management (EVM) tracking specifically on Phase 1 linguistic deliverables. Immediately allocate $350,000 (10% of total) into a dedicated contingency pool released only after Phase 1 sign-off, forcing the initial specification work to operate on a strict $3.15M basis.

## Risk 2 - Technical/Linguistic
The chosen Ordinal Standardization Approach commits to numeric + invariant markers (e.g., '5th'). While simplifying the rule set, this introduces friction in digital text processing (Decision 1). If required tagging/parsing tools for seamless integration into existing technical documentation workflows are not developed or procured in Phase 2, adoption will stall.

**Impact:** Integration delays of 3–6 months in Phase 3 adoption, and potentially $50,000–$100,000 in unplanned custom software procurement or development costs during Phase 2 setup.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Task a small technical working group during Phase 1 to define strict XML/SGML tagging standards for ordinal markers. Allocate a specific line item ($40,000) within the Phase 2 budget for contracting one specialist to develop/validate a proof-of-concept integration parser for a major technical documentation platform.

## Risk 3 - Social/Acceptance
The project aims for intelligibility within 2 weeks, relying heavily on the Morphology Regularization Threshold (Decision 2) which prioritizes regularizing opaque irregularities (e.g., 'went'). If the set of retained, irregular, high-frequency words (those below the regularization threshold) is still too large or contextually confusing, native speaker perception of 'artificiality' or ESL learner frustration will lead to significant pushback, undermining the soft launch.

**Impact:** If pilot cohorts (native speakers) rate 'naturalness' below 6/10, the perceived value decreases, leading to public relations challenges that could derail Phase 3 licensing efforts, yielding zero adoption ROI.

**Likelihood:** High

**Severity:** High

**Action:** Mitigate by selecting the cognitive load threshold (Choice 2 in Decision 2) rather than frequency alone. Explicitly include a qualitative section in the Phase 2 assessment focused *only* on perceived naturalness and aesthetic acceptance from native speakers, feeding this score directly into the Go/No-Go metrics calibration (Decision 8).

## Risk 4 - Regulatory & Permitting / Governance
The Governance Structure is mobilized early (Pioneer strategy) by securing full external commitments for the Linguistic Review panel in Phase 1. If key linguistic experts (especially those with necessary academic standing) cannot commit their time for stipends commensurate with the tight Phase 1 budget constraints, the review process will be delayed, and the quality assurance foundation will be compromised.

**Impact:** A 4–6 week delay in Phase 1 rule finalization due to expert unavailability, resulting in a delayed start for Phase 2 and potentially consuming project contingency funds to retain staff.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Prioritize securing commitment letters alongside budget estimates for Phase 1 stipends. Have a pre-approved 'back-up' pool of three secondary reviewers identified during Phase 1 planning, authorized to step in immediately if primary choices fail to finalize contracts within the first 60 days.

## Risk 5 - Operational/Integration
The project requires launching pilot cohorts using safety-critical or technical glossaries. If the newly defined Core Lexicon (5,000 words) mapping to Standard English does not perfectly align or if ambiguity/error exists in the mapping for crucial safety terms, regulatory liability concerns could arise concerning the pilot materials themselves.

**Impact:** If mapping errors are found in safety-relevant terms during Phase 2, remediation requires a full iteration of corpus/curriculum updates (an estimated 6-week delay) and may introduce potential legal exposure depending on the jurisdiction of the pilot.

**Likelihood:** Low

**Severity:** High

**Action:** Implement a mandatory 'Safety Critical Double-Blind Review' sweep during the final month of Phase 1, where two independent, certified domain experts (e.g., aviation safety writer, medical technical communicator) review the 500 highest-frequency technical terms for zero-tolerance errors before materials are printed for Phase 2.

## Risk 6 - Supply Chain / Physical Logistics
Phase 2 requires utilizing physical locations (D.C., London, SE US) for governance/pilot coordination, necessitating expenditure in GBP for the London hub. Exchange rate volatility between USD (budget currency) and GBP could cause operational budget shortfalls for physical space leases and local administrative support in the UK during the 3-year period.

**Impact:** A sustained 15% adverse shift in the USD/GBP exchange rate could necessitate cutting 4 months of physical office rental/support staff in London, impacting governance meeting logistics or pilot coordination effectiveness.

**Likelihood:** Medium

**Severity:** Medium

**Action:** As per currency strategy, use USD-denominated contracts for long-term staff where possible (hiring US-based remote staff serving the UK hub). For physical leases in London, attempt to secure a fixed-rate GBP payment schedule for the first 18 months or purchase moderate-sized forward contracts covering the high-cost Phase 2 period.

## Risk 7 - Technical/Linguistic
The Grapheme-to-Phoneme Mapping Strategy prioritizes strict clarity over phonetic diversity (Decision 6). This risks creating pronunciation rules that are technically consistent but feel highly unnatural or result in 'monotone' text when used by native speakers, potentially leading to compliance failure on the 'intelligible to current English speakers' constraint.

**Impact:** If Phase 2 pilot materials are perceived as sounding 'alien' or machine-generated, the overall perceived utility plummets, failing the intelligibility goal even if measurable comprehension scores are met.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Adopt Strategy 1 (strict mapping) for Phase 1 definition but integrate Strategy 3 (optional diacritics) into the Style Guide (Deliverable). These diacritics serve as optional 'enhancements' for native speakers, allowing the core curriculum to be strictly phonetic while offering pathways to higher performance/naturalness.

## Risk summary
This project faces high-leverage risks stemming fundamentally from the ambitious linguistic scope constrained by a tight budget and timeline. The two most critical risks are **Financial Underfunding** due to the 50% budget front-loading required by the 'Pioneer' strategy, and **Social/Acceptance Risk** concerning the perceived naturalness of the strict morphological changes. If the upfront linguistic rigor (Phase 1) overruns costs, Phase 2 piloting will be crippled, failing to generate the validation data required for the Go/No-Go gate. Mitigation requires tight budgetary controls (EVM) and prioritizing the qualitative feedback on 'naturalness' during pilot testing to ensure the linguistic purity achieved academically translates into usable acceptance.

A secondary, high-impact risk is the creation of **Integration Friction** due to the chosen numeric ordinal markers, which burdens ongoing costs for Phase 3 adoption infrastructure.