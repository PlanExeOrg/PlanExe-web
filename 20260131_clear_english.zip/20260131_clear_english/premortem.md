A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The $40,000 allocated in Phase 2 is sufficient to develop the Proof-of-Concept parser required to integrate the numeric ordinal markers into commercial text processing suites. | Obtain fixed-price quotes from three specialist integration vendors based on the drafted XML/SGML tagging protocol for the Lead Technical WG by the end of Q1 Phase 1. | All three vendor quotes exceed $60,000, or the Lead Technical WG reports an inability to finalize the protocol within the first 6 months of Phase 1. |
| A2 | The chosen 'Pioneer' strategy's aggressive 50% budget front-loading into Phase 1 ($1.75M) will not overrun by more than the $350k contingency, thus preserving the $875k Phase 2 validation budget. | The Financial Controller must report zero Cost Variance (CV) exceeding 5% against the monthly baseline for the first 9 months of Phase 1. | The cumulative Cost Variance (CV) exceeds $175,000 (10% of Phase 1 budget) before the end of Month 6 of Phase 1. |
| A3 | The external Linguistic Review Panel, secured upfront per the Pioneer strategy, will remain committed and contractually bound even though substantive review payments are gated until Phase 1 rule finalization. | Obtain signed commitment letters from all five primary reviewers confirming their contractual obligation to the agreed, delayed payment schedule. | More than one primary reviewer withdraws or demands partial payment mobilization before substantive rule drafts are delivered. |
| A4 | The $875,000 allocated for Phase 2 (Pilot Execution) is sufficient to support both the recruitment/incentives for two diverse cohorts (ESL/Technical) and the development/licensing of the specialized dual-track digital assessment platform required for capturing Phase 2 metrics. | The Pilot & Assessment Lead must secure fixed-price agreements from prospective pilot hosting/assessment platforms that total no more than $150,000 for the entire Phase 2 duration. | Fixed-price quotes for necessary assessment infrastructure and recruitment logistics exceed $200,000, leaving less than 75% of the original budget for direct cohort incentives and curriculum testing. |
| A5 | The Core Development Team (5 FTEs) can successfully complete the complex tasks of corpus mapping, rule finalization, and initial dictionary construction (5,000 words, Grapheme-to-Phoneme definition, Morphology lock) within the 12-month target window, despite the ambitious scope. | The Lead Linguistic Architect must report a Cost Performance Index (CPI) of 1.0 or greater and a Schedule Performance Index (SPI) of 0.95 or greater in the EVM report for Months 1 through 6 of Phase 1. | The SPI drops below 0.90 at any point in the first 6 months, indicating schedule slippage that cannot be mathematically recovered within the remaining 6-month Phase 1 timeline. |
| A6 | The 'killer application' path—securing Letters of Intent (LOIs) from safety-critical sectors (Aerospace/Medical)—will gain sufficient traction during Phase 1 consultations to validate the $875k Phase 3 launch budget before the Phase 2 Go/No-Go decision. | By the milestone for Phase 1 completion (Month 12), the Governance & Standards Manager must have secured signed, non-binding Letters of Intent from at least two distinct high-value organizations totaling claimed adoption volume equivalent to 150% of the estimated Phase 3 operational budget ($1.31M annual run rate). | At the Phase 2 Go/No-Go Decision Point, the total committed LOI value is less than 50% of the projected Phase 3 annual operating cost. |
| A7 | The external experts hired for the Linguistic Review Panel (Decision 3) possess the necessary practical experience in *linguistic policy application* rather than just theoretical linguistics to effectively arbitrate complex trade-offs (like naturalness vs. technical error rate) during the Go/No-Go decision. | During Q2 Phase 1 onboarding, the Lead Linguistic Architect must conduct a peer review of the proposed curriculum assessment methodology (designed by the Pilot Lead) and receive validation from the Review Panel members indicating practical policy alignment, not just theoretical agreement. | Two or more scheduled Review Panel members explicitly defer arbitration rulings on assessment design issues back to the internal Project Director during the first formal review session in Phase 2. |
| A8 | The selection of the Cognitive Load Threshold for morphology regularization (Decision 2) results in a final list of retained irregular forms that native speaker validators rate as acceptable (i.e., 'naturalness' score above the baseline target of 6/10). | The Corpus Development & Lexicographer must present the signed-off list of retained irregulars where the Cognitive Load Consultant confirms the density of retained forms does not exceed 5% of the total 5,000-word lexicon. | Simulated native speaker review of the finalized morphology set yields an average 'naturalness' score below 6.0/10, triggering the need for the $150,000 Aesthetic Refinement Sprint contingency. |
| A9 | The project's physical infrastructure needs (D.C. HQ, access to university research parks) can be satisfied using flexible, co-working/temporary leases secured during Phase 1 without incurring significant operational budget risk or adverse currency effects from the required GBP expenditures. | The Governance & Standards Manager must finalize initial lease estimates and secure favorable USD/GBP forward contracts covering at least 18 months of anticipated London operational costs by the end of Month 6 of Phase 1. | The actual cost for securing appropriate facilities in the London hub, due to unfavorable exchange rates or lack of short-term leasing options, requires a budget transfer from the centrally held $350k contingency fund. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Contingency Collapse: Strangling Validation with Upfront Overrun | Process/Financial | A2 | Project Financial & Risk Controller | CRITICAL (20/25) |
| FM2 | The Markup Mismatch: Digital Ecosystem Rejection | Technical/Logistical | A1 | Technical Integration Specialist | HIGH (12/25) |
| FM3 | The Inactive Expert: Governance Lock-In Failure | Market/Human | A3 | Governance & Standards Manager | CRITICAL (15/25) |
| FM4 | The Pilot Poverty Trap: Underfunding Validation Rigor | Process/Financial | A4 | Pilot & Assessment Lead | CRITICAL (16/25) |
| FM5 | The Linguistic Lockdown Lag: Core Rule Finalization Delay | Technical/Logistical | A5 | Lead Linguistic Architect | CRITICAL (20/25) |
| FM6 | The Empty Lobby: Commercial Adoption Deficit | Market/Human | A6 | Governance & Standards Manager | CRITICAL (20/25) |
| FM7 | The Policy Paralysis: Over-Reliance on Ivory Tower Arbitration | Process/Financial | A7 | Governance & Standards Manager | CRITICAL (15/25) |
| FM8 | The Aesthetic Anomaly: Unnatural Rules Provoke Rejection | Technical/Logistical | A8 | Lead Linguistic Architect | CRITICAL (16/25) |
| FM9 | The Currency Chasm: London Hub Operational Failure | Process/Financial | A9 | Governance & Standards Manager | HIGH (12/25) |


### Failure Modes

#### FM1 - The Contingency Collapse: Strangling Validation with Upfront Overrun

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: Project Financial & Risk Controller
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Failure stems from the foundational decision to front-load 50% of the budget into Phase 1 linguistic definition. If Phase 1 exceeds $1.75M by more than $175k (10% of Phase 1 funding), the mandated $875k Phase 2 validation budget is directly compromised. This forces premature reduction in pilot cohort size or length, leading to statistically insufficient data (low N). The Financial Controller lacks the required flexibility to manage Scope Creep vs. Resource Depletion, as the $350k contingency is designed to cover *unexpected* complexity, not standard schedule inefficiencies.

##### Early Warning Signs
- Monthly Earned Value Management (EVM) reports show cumulative Cost Variance (CV) above $100,000 by Month 4 of Phase 1.
- The Project Financial & Risk Controller requests transfer of utility funds from the Phase 2 pilot logistics line item to cover Phase 1 contractor invoices.
- The Governance & Standards Manager reports difficulty in executing the revised governance payment schedule due to funding shortfalls.

##### Tripwires
- Cumulative Phase 1 CV exceeds $175,000 before Month 9.
- Phase 2 Pilot Recruitment Budget line item shows actual spend exceeding 15% of planned baseline by Month 3 of Phase 2.
- Less than 80% of the 200-person pilot cohort is confirmed enrolled by the established Phase 2 start date.

##### Response Playbook
- Contain: Immediately halt all non-essential discretionary Phase 1 spending (e.g., external technical consultation beyond core linguistic FTEs).
- Assess: The Financial Controller must issue a 'Budget Breach Alert' to the Project Director, calculating the exact required reduction to the Phase 2 pilot size necessary to maintain solvency.
- Respond: Initiate a formal scope reduction review targeting the 'Aesthetic Refinement Sprint' budget ($150k) for complete elimination, followed by presenting a revised, statistically justified minimum viable pilot size based on the remaining Phase 2 funding.


**STOP RULE:** If Phase 1 overrun necessitates reducing the Phase 2 pilot cohort size below 120 participants, rendering the Go/No-Go data statistically invalid, the project pivots to an internal, non-public advisory release.

---

#### FM2 - The Markup Mismatch: Digital Ecosystem Rejection

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A1
- **Owner**: Technical Integration Specialist
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The reliance on numeric ordinal markers ('5th') assumes that existing commercial text processing suites (InDesign, CMS platforms) can gracefully handle the custom XML/SGML tagging defined in Phase 1. Failure occurs if the required PoC parser development cost balloons beyond the $40,000 allocated budget, or if the tagging protocol fundamentally conflicts with widely adopted industry standards like DITA/S1000D. This forces the project to either abandon the efficient numeric marker choice (reworking the core standard) or face catastrophic adoption friction in Phase 3, leading to resistance from technical publishing sectors (the 'killer application').

##### Early Warning Signs
- The first vendor quote during Q1 Phase 1 assessment exceeds $50,000 for custom parser/tagging work.
- The Workflow Specialist Audit flags a critical-severity incompatibility with the primary target CMS by Month 4 of Phase 1.
- The Legal team issues a flag regarding IP ownership implications of the proposed parser source code.

##### Tripwires
- The fixed-price quote for PoC parser development comes back at $65,000 or higher.
- The Technical Integration Specialist reports the need for an architecturally distinct parsing solution (not just a script) during Phase 2 setup.
- Testing against the top two target commercial suites fails to render ordinals correctly with less than 5 lines of custom code.

##### Response Playbook
- Contain: Instantly freeze all spending on non-essential Phase 1 linguistic modeling and redirect the Technical Integration Specialist to work only on developing a fallback, fully spelled-out ordinal standard for comparison.
- Assess: Convene the Lead Linguistic Architect and Governance & Standards Manager to assess the cost/time impact of switching to the textual ordinal standard (Decision 1, Choice 2) versus absorbing the technical overrun cost.
- Respond: If the overrun exceeds $30,000, halt PoC development and immediately engage the Linguistic Architect to redraft the ordinal specification to conform to the fully textual option, absorbing the cost/delay as necessary technical debt to preserve long-term adoption.


**STOP RULE:** If the cost to develop a functional parser for the numeric marker exceeds $90,000 (225% of allocated budget), the project must pivot immediately to the fully textual ordinal standard (Choice 2 in Decision 1), irrespective of the impact on Phase 1 design simplicity.

---

#### FM3 - The Inactive Expert: Governance Lock-In Failure

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Governance & Standards Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The Pioneer strategy mandates securing external expert commitment upfront to ensure rigorous QA. If the assumption that these experts remain committed (despite delayed payment schedules contingent on Phase 1 completion) is false, the review timeline collapses. The key consequence is that the Linguistic Review Panel stalls its formal assessment post-Phase 1. This causes a ripple effect where the finalized Style Guide and Lexicon lack the crucial external sign-off required for external accreditation (ISO/IEC alignment) and licensing credibility, directly undermining the value proposition for the high-stakes 'killer application' segment.

##### Early Warning Signs
- The Governance & Standards Manager reports that two of the five primary reviewers have requested the pre-approved backup reviewers be activated within the first 60 days.
- The formal schedule for the Initial Review Synchronization Meeting (Phase 1 Milestone) slips by more than 15 days due to scheduling conflicts with Panel members.
- The Project Director receives inquiries regarding the delayed payment structure from Panel members or their administrative contacts.

##### Tripwires
- More than one primary reviewer formally requests an escalation of stipend amount relative to the stated Phase 1 budget.
- The Synchronization Meeting is formally rescheduled three or more times past the original target date.
- The Policy/Standards Consultant issues a warning that the lack of an active panel review impacts ISO compliance documentation.

##### Response Playbook
- Contain: Issue a formal 'Expert Disengagement Notice' to the non-responsive reviewers, invoking the pre-approved backup pool contract activation immediately.
- Assess: The Governance Manager must immediately report the impact of the change on the Phase 1 Rule Locking timeline to the Project Director and Lead Linguist, noting which external review milestones are now at risk.
- Respond: If the backup pool does not confirm 100% commitment within 7 calendar days, the Project Director must downgrade the Phase 1 Sign-off requirement (Decision 5) to an internal Director/Linguist consensus, acknowledging the loss of external QA rigor but preserving the schedule to protect Phase 2 funding.


**STOP RULE:** If the number of active, committed Linguistic Review Panel members drops below three at any point during Phase 1 rule finalization, the project must immediately pivot to an internal advisory board structure and abandon the ISO/IEC external accreditation goal.

---

#### FM4 - The Pilot Poverty Trap: Underfunding Validation Rigor

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Pilot & Assessment Lead
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
This failure mode stems from the insufficient funding presumed for Phase 2 assessment infrastructure ($875k total). If upfront assessment platform costs or recruitment incentives prove unexpectedly high (e.g., requiring $200k instead of the assumed $150k total), the remaining budget fragment for cohort management and curriculum delivery becomes critically thin. This leads to insufficient sample sizes or reduced testing duration (e.g., shorter than the required 14-day exposure window), resulting in statistically weak or biased Go/No-Go data. The root cause is the over-optimistic budget allocation for Phase 2 logistics.

##### Early Warning Signs
- Fixed-price quotes for the Learning Management System license exceed $120,000 by Month 3 of Phase 1.
- The recruitment agency reports that incentive packages must be raised by 25% to meet target enrollment numbers for the technical cohort.
- The Pilot & Assessment Lead reports the budget cannot support necessary data analysis tools beyond basic spreadsheet functionality.

##### Tripwires
- Total committed spending on Phase 2 infrastructure (LMS + Recruitment fixed costs) exceeds $175,000 by the end of Phase 1.
- The planned duration of the 14-day comprehension testing window cannot be guaranteed due to funding constraints on cohort participation incentives.

##### Response Playbook
- Contain: Immediately enforce a hiring freeze on the proposed Curriculum Content Editor FTE/Contractor role and require the Pilot Lead to utilize existing documentation resources during Phase 2.
- Assess: The Financial Controller must execute a zero-based budget review for Phase 2, identifying which cohort (ESL or Technical) must be reduced in size by 30% to cover infrastructure overruns.
- Respond: If necessary cohort reduction impacts statistical power below 80% confidence level, trigger immediate arbitration with the Go/No-Go authority to accept a longer, smaller pilot (extending Phase 2 timeline by 8 weeks) instead of cancelling enrollment.


**STOP RULE:** If the revised Phase 2 operational budget, after infrastructure commitments, covers less than 8 testing environments required for parallel cohort testing, the project halts Phase 2 enrollment until external funding/grants can fully cover the logistics.

---

#### FM5 - The Linguistic Lockdown Lag: Core Rule Finalization Delay

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Lead Linguistic Architect
- **Risk Level:** CRITICAL 20/25 (Likelihood 5/5 × Impact 4/5)

##### Failure Story
This failure occurs if the Core Development Team, tasked with defining the complex rules (Grapheme mapping, Morphology regularization) within Phase 1's aggressive 12-month window, misses schedule targets (SPI < 0.95). This delay is likely due to unforeseen complexity in computational phonology or contention over the Cognitive Load threshold, requiring multiple iterations. Because Phase 2 curriculum drafting is strictly dependent on final locked-down rules, any delay in Phase 1 directly compresses the available time for quality curriculum design and pilot setup, increasing the probability that the pilot assessment data suffers from flawed curriculum content or is statistically invalid due to insufficient data collection time.

##### Early Warning Signs
- The Lead Linguistic Architect reports that the specific mapping for the 100 most complex Grapheme-to-Phoneme cases requires more than two internal review cycles.
- The Corpus Development role reports that the finalized (but unapproved) morphology list is being queried for conflict by external contractors working on the Reference Dictionary XML schema.
- EVM reporting shows SPI consistently below 0.95 for three consecutive monthly reports during the first half of Phase 1.

##### Tripwires
- The Grapheme-to-Phoneme Mapping Strategy Lock task (ID: 3edfc0c5-475d-4b96-a71a-3353ba9beebd) is not achieved by Month 10 of Phase 1.
- The Lead Linguist formally requests a scope reduction in the initial 500 safety-critical terms pending further mapping refinement in Phase 2 instead of Phase 1.
- The Governance & Standards Manager reports the Linguistic Review Panel cannot confirm scheduling for the first substantive review meeting within the original Phase 1 window.

##### Response Playbook
- Contain: Immediately pause all non-essential lexicography work (e.g., the full 5,000-word mapping) and reassign the Corpus Development FTE to support the Lead Architect in automating rule validation reports to speed up the Grapheme-to-Phoneme process.
- Assess: The Project Director must convene an emergency governance session to determine if the Phase 1 schedule slip (based on current SPI) necessitates triggering the 2-month timeline extension previously recommended to mitigate high risk.
- Respond: If a slip is confirmed, formally notify the Pilot Lead to adjust the Phase 2 start date accordingly, explicitly reducing the pilot testing window length by a corresponding amount, and notifying stakeholders that the statistical confidence level for the Go/No-Go will be lower than initially targeted.


**STOP RULE:** If the final lock-down of the core linguistic rules (Morphology, Ordinal format, Grapheme Map) is delayed past Month 15 of Phase 1, the project must pause curriculum design and revert to internal simulation testing only, deferring the expensive Phase 2 pilot until rules are finalized.

---

#### FM6 - The Empty Lobby: Commercial Adoption Deficit

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Governance & Standards Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
This failure is rooted in the assumption that high-value adoption commitments (LOIs) can be secured based on incomplete Phase 1 specifications. If potential high-value adopters in high-stakes industries (aerospace, medical) view the incomplete rule set (especially concerning ordinal marking friction or morphology complexity) as too risky for their internal documentation mandates, they will withhold commitment. This results in Phase 3 launching with no guaranteed revenue stream exceeding the operational burn rate, making the standard irrelevant or obsolete, as the high ROI hinges on landing those initial, mission-critical contracts.

##### Early Warning Signs
- By Month 9 of Phase 1, fewer than two technical/safety-critical organizations have agreed to even a preliminary technical consultation regarding the Ordinal Tagging Protocol.
- The Governance & Standards Manager reports receiving pushback on the provisional licensing model complexity from potential adopters.
- External expert feedback consistently highlights the lack of definition in the Safety Critical Double-Blind Review scope (Risk 5).

##### Tripwires
- Total cumulative value of LOIs secured by the end of Phase 2 is less than $500,000 equivalent run rate.
- Project Director fails to secure a formal statement from the Project Advisory Board prioritizing the 'killer application' over general ESL adoption by Month 3 of Phase 2.
- The rate of change in the ISO compliance structure during Phase 1 requires more than two substantive amendments to the planned Change Management Protocol.

##### Response Playbook
- Contain: Immediately shift the focus of the Governance Manager away from general ISO structural setup toward exclusively drafting the 'Minimum Viable Standard Adoption Package' targeting only the highest-risk, highest-certainty safety-critical glossary adaptation.
- Assess: Convene the Project Director and Financial Controller to calculate the absolute minimum revenue needed from Phase 3 to cover the operational costs of maintaining the London hub and required infrastructure support for 12 months.
- Respond: If projected LOI value falls below the calculated minimum, immediately trigger a strategic review to sunset the London hub operations (mitigation R6) and pivot the commercial strategy to an academic/open-source model supported solely by the US-based contingency.


**STOP RULE:** If no LOIs demonstrating clear integration commitment are secured by the Phase 2 Go/No-Go decision, the project pivots from a public standard launch to deploying the final rule set internally for one single, high-value partner only, eliminating Phase 3 launch costs.

---

#### FM7 - The Policy Paralysis: Over-Reliance on Ivory Tower Arbitration

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Governance & Standards Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
This failure occurs if the external Linguistic Review Panel (secured per Pioneer strategy) turns out to be purely academic, lacking experience in applying policy under tight, metric-driven constraints (like the 5% error rate vs. the qualitative naturalness score). Unable to effectively arbitrate conflicts between technical correctness and user acceptance during the Go/No-Go review, the panel stalls, demanding further data collection or re-adjudication. This procedural deadlock consumes critical timeline buffer (Risk 3/Issue 3), potentially leading to the expiration of the pilot testing agreements, thereby invalidating the entire Phase 2 exercise without providing a binding conclusion.

##### Early Warning Signs
- During Phase 2 data analysis, the Panel defaults to requesting supplementary qualitative studies (e.g., extended focus groups) rather than rendering a decision based on provided metrics.
- The Pilot & Assessment Lead reports that the Panel cannot agree on the weighting of the ordinal error rate vs. the retention score by the scheduled review date.
- More than two formal requests for arbitration clarification are submitted between the Panel and the Project Director in the first month of the review period.

##### Tripwires
- The binding Go/No-Go decision meeting is postponed by more than 10 working days past the scheduled date.
- The Panel formally requests a 6-week extension to gather 'further corroborating data' beyond the scope of the existing pilot plan.
- The Panel requires a re-calibration workshop that necessitates additional, unplanned contract funding for external psychometric validation.

##### Response Playbook
- Contain: Immediately freeze all internal preparation for Phase 3 licensing scale-up activities and re-assign the Project Director to facilitate daily arbitration meetings between the Panel and the Pilot Lead.
- Assess: The Governance Manager must seek written advice from the International Standards Consultant (Expert 2) on the formal procedures for breaking arbitration deadlock outlined in the ISO framework used for structuring the Panel.
- Respond: If deadlock persists past the rescheduled decision date, the Project Director must formally invoke a pre-agreed 'Majority Rule Override' clause, accepting the decision of the technical lead (Linguistic Architect) if the error rate is below 5%, regardless of the Panel's qualitative dissent.


**STOP RULE:** If the Panel's required arbitration process exceeds 60 calendar days, the Project Director must unilaterally issue the Go/No-Go recommendation based on internal data metrics to prevent total schedule loss, accepting the risk of external governance invalidation.

---

#### FM8 - The Aesthetic Anomaly: Unnatural Rules Provoke Rejection

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Lead Linguistic Architect
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
This technical/linguistic failure arises because the chosen Cognitive Load Threshold for morphology simplification (Decision 2) was too aggressive, assuming that *retaining* the most common irregular forms (like 'went/go') does not result in a perceived 'unnaturalness' score below acceptable levels. Despite meeting the strict technical metrics (ordinal error rate is low, comprehensibility is fast), native speaker validators rate the resulting language as alien, monotone, or too simplistic. This directly invalidates the crucial Social/Acceptance Risk mitigation strategy, leading to low enthusiasm among potential early adopters in the technical writing community, eroding the perceived value of the standard.

##### Early Warning Signs
- The running average of the qualitative 'naturalness' score during Phase 2 testing drops below 6.5/10 by the halfway point of the 14-day testing window.
- The Pilot Lead reports that technical cohort participants consistently substitute retained irregular forms with newly regularized (but linguistically incorrect) variants when asked to write freely.
- The Cognitive Load Modeling Consultant flags that the retained set of irregulars generates disproportionate working memory load compared to the newly simplified forms.

##### Tripwires
- The median 'naturalness' score calculated at the end of the 14-day testing period is 6.0 or lower.
- The $150,000 Aesthetic Refinement contingency budget line item is requested for activation by the Pilot Lead.
- The external Linguistic Review Panel issues a consensus finding stating the language 'lacks necessary contextual nuance for professional application.'

##### Response Playbook
- Contain: Immediately initiate the pre-funded Aesthetic Refinement Sprint ($150k contingency) under the Pilot Lead's direction, focusing only on adding complexity/nuance back into the retained irregular forms currently scoring poorly.
- Assess: The Lead Linguistic Architect must conduct an urgent root cause analysis comparing the Cognitive Load Threshold selection (final output) against the initial input parameters provided by the Cognitive Load Consultant.
- Respond: If refinement sprints consume over 60% of the contingency budget without raising the naturalness score above 7.0/10, the Project Director must formally declare the 'naturalness' component of the Go/No-Go criteria as advisory only, focusing the final binding decision solely on the objective error rate and comprehension gain.


**STOP RULE:** If the naturalness score stagnates below 7.0/10 after the full $150,000 refinement budget is spent, the project proceeds only as an internal, mandatory technical documentation system for the primary sponsor, abandoning the broader ESL/public standard launch.

---

#### FM9 - The Currency Chasm: London Hub Operational Failure

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Governance & Standards Manager
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
This failure arises from the assumption that the USD budget can easily absorb the required GBP operational costs for the London hub without significant financial hedging or operational planning during Phase 1. A sustained adverse currency shift (e.g., 15%+ unfavorable USD/GBP movement) erodes the operational runway for the London office, forcing a reduction in physical presence or staffing required for crucial international standards liaison and ESL publisher outreach. This operational constraint directly hampers the Governance Manager’s ability to secure ISO compliance sign-off and limits the necessary engagement with UK-based linguistic talent, ultimately delaying the authoritative V1.0 publication.

##### Early Warning Signs
- Three consecutive monthly USD budget reports show that GBP expenditures are tracking 10% higher than modeled burn-rate projections.
- The Governance & Standards Manager reports difficulty securing renewal options for short-term leases due to un-hedged budget uncertainty.
- The Financial Modeler indicates that utilization of the $350k contingency fund dips below 50% due to covering currency variances.

##### Tripwires
- The USD cost equivalent for the London hub for a single quarter exceeds 28% of the total Phase 2 operational budget ($875k).
- The Financial Controller reports that the required forward currency contracts for the next 12 months are economically unviable based on current market indicators.
- The Project Director receives a formal notice regarding delayed rent or service payments for the London facility.

##### Response Playbook
- Contain: Immediately halt all new physical procurement activities for the London hub; temporarily reassign international liaison tasks to the D.C. team using remote conferencing infrastructure.
- Assess: The Financial Controller must present a scenario analysis detailing the exact monetary threshold (in adverse rate movement) that triggers the complete termination of the London physical presence commitment in favor of fully remote work structures.
- Respond: If the assessed risk threshold is breached, formally notify the landlords/service providers of the necessary pivot to a remote-first operational model, reallocating the saved lease/staffing capital to bolster the Phase 3 outreach marketing budget rather than Phase 1/2 execution, accepting a delay in international recruitment.


**STOP RULE:** If the adverse USD/GBP movement requires drawing more than 50% of the designated $350k contingency fund solely to maintain the London operational costs through the end of Phase 2, the London hub must be decommissioned immediately, and all governance/standardization liaison functions must be permanently centralized in the US/D.C. hub.
