This plan involves money.

## Currencies

- **USD:** Primary currency as the project is international, involves high-tech infrastructure procurement (servers, compute), and targets a global developer community.

**Primary currency:** USD

**Currency strategy:** Given the international scope, high-tech infrastructure purchasing needs, and strategic basing of operations in the USA, USD will be used for all major capital expenditures, infrastructure contracts, and centralized financial reporting to mitigate exchange rate risks.