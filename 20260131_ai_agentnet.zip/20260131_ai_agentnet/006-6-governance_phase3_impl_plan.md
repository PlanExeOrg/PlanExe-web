### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**


### 2. Project Manager circulates Draft SteerCo ToR v0.1 for review by proposed members (CTO, CISO, Head of Product Development, Head of Legal and Compliance, Independent Ethics Advisor, Senior Project Manager).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Circulation Email
- Review Feedback from Proposed Members

**Dependencies:**

- Draft SteerCo ToR v0.1
- Proposed Members List Available

### 3. Project Manager consolidates feedback and revises the SteerCo ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- SteerCo ToR v0.2

**Dependencies:**

- Review Feedback from Proposed Members

### 4. Project Sponsor formally approves the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0

**Dependencies:**

- SteerCo ToR v0.2

### 5. Project Sponsor formally appoints the Chairperson of the Project Steering Committee (likely CTO or Head of Product Development).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved SteerCo ToR v1.0

### 6. Project Sponsor formally confirms the membership of the Project Steering Committee (CTO, CISO, Head of Product Development, Head of Legal and Compliance, Independent Ethics Advisor, Senior Project Manager).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Approved SteerCo ToR v1.0
- Appointment Confirmation Email

### 7. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Membership Confirmation Emails

### 8. Hold the initial Project Steering Committee kick-off meeting to review ToR, discuss project goals, and establish communication protocols.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 9. Project Manager defines roles and responsibilities for the Core Project Team members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Roles and Responsibilities Document

**Dependencies:**


### 10. Project Manager establishes communication channels and protocols for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Communication Protocol Document

**Dependencies:**


### 11. Project Manager sets up project management tools and systems for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Management Tools and Systems Setup

**Dependencies:**


### 12. Project Manager develops a detailed project schedule and budget for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Detailed Project Schedule
- Detailed Project Budget

**Dependencies:**


### 13. Project Manager schedules the initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Core Project Team Roles and Responsibilities Document
- Core Project Team Communication Protocol Document
- Project Management Tools and Systems Setup
- Detailed Project Schedule
- Detailed Project Budget

### 14. Hold the initial Core Project Team kick-off meeting to review roles, responsibilities, communication protocols, project schedule, and budget.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 15. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**


### 16. Project Manager circulates Draft TAG ToR v0.1 for review by proposed members (Lead Software Engineer, Security Architect, Data Architect, External Technical Consultant, Cloud Infrastructure Specialist).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Circulation Email
- Review Feedback from Proposed Members

**Dependencies:**

- Draft TAG ToR v0.1
- Proposed Members List Available

### 17. Project Manager consolidates feedback and revises the TAG ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- TAG ToR v0.2

**Dependencies:**

- Review Feedback from Proposed Members

### 18. Project Steering Committee approves the Technical Advisory Group Terms of Reference.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Approved TAG ToR v1.0

**Dependencies:**

- TAG ToR v0.2

### 19. Project Steering Committee formally confirms the membership of the Technical Advisory Group (Lead Software Engineer, Security Architect, Data Architect, External Technical Consultant, Cloud Infrastructure Specialist).

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Approved TAG ToR v1.0

### 20. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Membership Confirmation Emails

### 21. Hold the initial Technical Advisory Group kick-off meeting to review ToR, discuss project goals, and establish communication protocols.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 22. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**


### 23. Project Manager circulates Draft Ethics & Compliance Committee ToR v0.1 for review by proposed members (Compliance Officer, Data Protection Officer, Legal Counsel, Independent Ethics Advisor, Representative from the Adaptive Governance Model council).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Circulation Email
- Review Feedback from Proposed Members

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1
- Proposed Members List Available

### 24. Project Manager consolidates feedback and revises the Ethics & Compliance Committee ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee ToR v0.2

**Dependencies:**

- Review Feedback from Proposed Members

### 25. Project Steering Committee approves the Ethics & Compliance Committee Terms of Reference.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Approved Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Ethics & Compliance Committee ToR v0.2

### 26. Project Steering Committee formally confirms the membership of the Ethics & Compliance Committee (Compliance Officer, Data Protection Officer, Legal Counsel, Independent Ethics Advisor, Representative from the Adaptive Governance Model council).

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Approved Ethics & Compliance Committee ToR v1.0

### 27. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Membership Confirmation Emails

### 28. Hold the initial Ethics & Compliance Committee kick-off meeting to review ToR, discuss project goals, and establish communication protocols.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation