Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 17 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 2 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The project focuses on creating a social media platform for AI agents, which falls within the realm of computer science and software engineering, not physics. Therefore, no mitigation is needed.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (social media platform) + market (AI agents) + tech/process (AI collaboration) + policy (ethical oversight) without independent evidence at comparable scale. There's no precedent for a social media platform exclusively for AI agents.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: Project Manager / Deliverable: Validation Report / Date: 12 weeks.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks definitions with business-level mechanisms-of-action, owners, and measurable outcomes for strategic concepts. The plan mentions 'AI AgentNet' and 'AI collaboration' as driving concepts, but omits one-pagers defining value hypotheses, success metrics, and decision hooks.

**Mitigation**: Platform Strategist: Create one-pagers for 'AI AgentNet' and 'AI collaboration,' including value hypotheses, success metrics, and decision hooks, to clarify strategic concepts. Due Date: 30 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because a major hazard class (legal/regulatory) is minimized. The plan identifies regulatory risks but lacks concrete mitigation for data privacy and ethical concerns. The risk register does not analyze cascades explicitly. "Conduct legal reviews, implement privacy-by-design principles..."

**Mitigation**: Legal Team: Map cascades from regulatory delays (e.g., GDPR non-compliance) to financial/reputational impacts. Expand the risk register with controls and a dated review cadence. Due: 60 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions regulatory and compliance requirements and the need for permits and licenses, but does not include a matrix identifying required approvals, lead times, or dependencies.

**Mitigation**: Project Manager: Create a permit/approval matrix with required approvals, lead times, and dependencies. Include NO-GO thresholds on slip. Due: 60 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because committed sources/term sheets are absent. The plan mentions a $5 million budget but lacks details on funding sources, draw schedule, covenants, and runway length. "Initial budget: $5 million (Phase 1: $2M, Phase 2: $1.5M, Phase 3: $1.5M)"

**Mitigation**: CFO: Develop a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO-GO on missed financing gates. Due: 30 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget conflicts with vendor quotes or scale-appropriate benchmarks. The plan lacks sufficient comparables and contingency, which could lead to significant financial shortfalls.

**Mitigation**: Owner: Financial Analyst; Benchmark ≥3 relevant comparables, obtain quotes, normalize per-area, and adjust budget or de-scope by 30 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., user acquisition, revenue growth) as single numbers without providing a range or discussing alternative scenarios. For example, the timeline lists specific durations for each phase without contingency planning.

**Mitigation**: Project Manager: Conduct a sensitivity analysis or create best/worst/base-case scenarios for user acquisition and revenue projections. Due: 60 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because core components lack engineering artifacts. The plan lacks technical specifications, interface definitions, test plans, and an integration map with owners/dates for build-critical components. This absence creates a likely failure mode.

**Mitigation**: Engineering Lead: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components. Due: 90 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes several critical claims without providing verifiable evidence. For example, the plan mentions obtaining a "Data Protection License" without providing any evidence that this license exists or is obtainable.

**Mitigation**: Legal Team: Research the requirements for obtaining a "Data Protection License" and provide evidence of its existence and feasibility. Due: 30 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project's final outputs are poorly defined. The plan mentions "AI AgentNet" as a deliverable without specific, verifiable qualities. The plan lacks SMART criteria for the platform's success.

**Mitigation**: Platform Strategist: Define SMART criteria for AI AgentNet, including a KPI for agent engagement (e.g., 70% monthly active agents). Due Date: 30 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (social media platform) + market (AI agents) + tech/process (AI collaboration) + policy (ethical oversight) without independent evidence at comparable scale. There's no precedent for a social media platform exclusively for AI agents.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: Project Manager / Deliverable: Validation Report / Date: 12 weeks.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Sustainability Advocate' role is the unicorn role. The plan requires long-term sustainability, technological advancements, evolving agent needs, and ethical considerations. Finding someone with expertise in all these areas is likely difficult.

**Mitigation**: HR: Conduct a talent market analysis for the 'Sustainability Advocate' role, assessing the availability of candidates with the required expertise. Due: 30 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions regulatory and compliance requirements and the need for permits and licenses, but does not include a matrix identifying required approvals, lead times, or dependencies.

**Mitigation**: Project Manager: Create a permit/approval matrix with required approvals, lead times, and dependencies. Include NO-GO thresholds on slip. Due: 60 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan lacks specifics on long-term funding, maintenance, and adaptation. The plan mentions "Operational Costs: $50,000/year" but lacks details on revenue projections and operational expenses beyond year one.

**Mitigation**: CFO: Develop a 3-5 year operational sustainability plan, including a detailed funding/resource strategy, maintenance schedule, and technology roadmap. Due: 90 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions regulatory and compliance requirements and the need for permits and licenses, but does not include a matrix identifying required approvals, lead times, or dependencies.

**Mitigation**: Project Manager: Create a permit/approval matrix with required approvals, lead times, and dependencies. Include NO-GO thresholds on slip. Due: 60 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks specifics on redundancy and tested failover for critical vendors, data sources, and facilities. The plan mentions "Cloud infrastructure" but lacks specifics on geographic distribution, backup systems, or disaster recovery plans.

**Mitigation**: Infrastructure Lead: Document all external dependencies (vendors, data sources, facilities), secure SLAs, add a secondary supplier/path for each, and test failover. Due: 90 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the 'Finance Department' is incentivized by budget adherence, while the 'R&D Team' is incentivized by innovation, creating a conflict over experimental spending. The plan does not address this conflict.

**Mitigation**: Project Manager: Create a shared, measurable objective (OKR) that aligns both Finance and R&D on a common outcome, such as 'Increase platform adoption by X% while staying within Y budget'. Due: 30 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board. Define thresholds for re-planning or stopping. Due: 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan has ≥3 Critical risks (FM1, FM2, FM3, FM4, FM5, FM6, FM7, FM8, FM9) that are strongly coupled. FM3 (Bias) can trigger FM6 (Silent Senate) and FM8 (Gated Fortress), leading to FM1 (Empty Town Square).

**Mitigation**: Project Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Due: 90 days.