This plan involves money.

## Currencies

- **USD:** Primary currency for budgeting and reporting, especially given the potential location in Silicon Valley and international scope.
- **CAD:** Relevant if a significant portion of development or operations is based in Toronto.
- **GBP:** Relevant if a significant portion of development or operations is based in London.

**Primary currency:** USD

**Currency strategy:** USD will be used for consolidated budgeting and reporting. CAD and GBP may be used for local transactions if operations are established in Toronto or London, respectively. Currency exchange rates should be monitored and hedging strategies considered to mitigate risks from exchange rate fluctuations.