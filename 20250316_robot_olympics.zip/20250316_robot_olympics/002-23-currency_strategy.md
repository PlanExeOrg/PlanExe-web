This plan involves money.

## Currencies

- **CNY:** Local currency for transactions within China if Beijing is selected.
- **JPY:** Local currency for transactions within Japan if Tokyo is selected.
- **KRW:** Local currency for transactions within South Korea if Seoul is selected.
- **USD:** For international transactions, budgeting, and potential prize money.

**Primary currency:** USD

**Currency strategy:** USD will be used for budgeting and reporting. Local currencies (CNY, JPY, or KRW) will be used for local transactions depending on the selected location. Hedging against exchange rate fluctuations may be necessary.