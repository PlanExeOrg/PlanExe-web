### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 2. Circulate Draft SteerCo ToR for review by nominated members (Senior Representative from the International Robotics Federation, Project Director, Technical Director, Marketing Director, Sponsorship Manager, Legal Counsel).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 3. Project Manager finalizes the SteerCo ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Senior Representative from the International Robotics Federation formally appointed as Steering Committee Chair.

**Responsible Body/Role:** CEO of the Robot Olympics Organizing Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Manager formally confirms Steering Committee membership with all nominated members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Final SteerCo ToR v1.0
- Appointment Confirmation Email

### 6. Schedule initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Membership Confirmation Emails

### 7. Hold initial Project Steering Committee kick-off meeting to review project plan, budget, and initial setup actions.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 8. Project Director defines roles and responsibilities for each Core Project Team member.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Roles and Responsibilities Matrix

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 9. Project Director establishes communication protocols and reporting procedures for the Core Project Team.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Communication Plan
- Reporting Procedures Document

**Dependencies:**

- Roles and Responsibilities Matrix

### 10. Project Director sets up project management tools and systems for the Core Project Team.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Management System Setup
- Access Granted to Team Members

**Dependencies:**

- Communication Plan
- Reporting Procedures Document

### 11. Project Director develops a detailed project schedule and budget for the Core Project Team.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Detailed Project Schedule
- Detailed Project Budget

**Dependencies:**

- Project Management System Setup

### 12. Project Director establishes risk management processes for the Core Project Team.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Risk Management Plan

**Dependencies:**

- Detailed Project Schedule
- Detailed Project Budget

### 13. Schedule initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Risk Management Plan

### 14. Hold initial Core Project Team kick-off meeting to review project plan, roles, and responsibilities.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 15. Project Director identifies and recruits qualified technical experts for the Technical Advisory Group.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- List of Nominated Technical Experts

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 16. Project Director defines the scope of responsibilities for the Technical Advisory Group.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Scope of Responsibilities Document

**Dependencies:**

- List of Nominated Technical Experts

### 17. Project Director establishes communication protocols and reporting procedures for the Technical Advisory Group.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Communication Plan
- Reporting Procedures Document

**Dependencies:**

- Scope of Responsibilities Document

### 18. Project Director develops a framework for evaluating robot safety and performance for the Technical Advisory Group.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Robot Safety and Performance Evaluation Framework

**Dependencies:**

- Communication Plan
- Reporting Procedures Document

### 19. Project Director establishes a process for reviewing and approving technical specifications for the Technical Advisory Group.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Technical Specification Review and Approval Process

**Dependencies:**

- Robot Safety and Performance Evaluation Framework

### 20. Project Director formally confirms Technical Advisory Group membership with all nominated members (Professor of Robotics, Robotics Engineer, AI Specialist, Safety Expert).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Technical Specification Review and Approval Process

### 21. Schedule initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Technical Director

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Membership Confirmation Emails

### 22. Hold initial Technical Advisory Group kick-off meeting to review scope, responsibilities, and evaluation framework.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 23. Legal Counsel develops a code of ethics for the Robot Olympics for the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Code of Ethics

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 24. Legal Counsel identifies all relevant regulations and compliance requirements for the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Compliance Requirements Document

**Dependencies:**

- Draft Code of Ethics

### 25. Legal Counsel establishes procedures for reporting and investigating ethical violations for the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Ethical Violation Reporting and Investigation Procedures

**Dependencies:**

- Compliance Requirements Document

### 26. Legal Counsel develops a training program on ethical conduct and compliance for the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Ethical Conduct and Compliance Training Program

**Dependencies:**

- Ethical Violation Reporting and Investigation Procedures

### 27. Legal Counsel establishes a process for reviewing and approving contracts and agreements for the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Contract and Agreement Review and Approval Process

**Dependencies:**

- Ethical Conduct and Compliance Training Program

### 28. Project Director formally confirms Ethics & Compliance Committee membership with all nominated members (Ethics Consultant, Data Privacy Officer, Representative from the International Robotics Federation).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Contract and Agreement Review and Approval Process

### 29. Schedule initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Membership Confirmation Emails

### 30. Hold initial Ethics & Compliance Committee kick-off meeting to review code of ethics, compliance requirements, and reporting procedures.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda