**Purpose:** business

**Purpose Detailed:** Planning and outlining the structure, events, rules, and challenges for a Robot Olympics in 2026, focusing on showcasing humanoid robot capabilities.

**Topic:** Robot Olympics 2026