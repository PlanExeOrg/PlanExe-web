# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Supply Chain Risk Analyst

**Knowledge**: Supply chain security, hardware integrity, vendor risk management

**Why**: To assess and mitigate risks associated with component origin verification and vendor diversity initiatives.

**What**: Analyze the e-bus supply chain for vulnerabilities and recommend mitigation strategies.

**Skills**: Risk assessment, supply chain auditing, vendor due diligence

**Search**: supply chain risk analyst, hardware security, vendor assessment

## 1.1 Primary Actions

- Immediately commission a detailed risk assessment comparing hardware air-gapping to alternative security architectures, quantifying operational impact and residual risk.
- Develop a comprehensive supply chain security plan that includes vendor audits, firmware integrity verification, and a vulnerability disclosure program.
- Define specific, measurable criteria for verifying the 'no-remote-kill' capability, including test cases and a formal attestation process.

## 1.2 Secondary Actions

- Extend the national rollout timeline to 18-24 months to allow for thorough testing and implementation.
- Increase the budget contingency to 15% (DKK 18M) to address potential cost overruns.
- Establish a threat intelligence program to proactively monitor cyber threats relevant to e-bus systems and the supply chain.
- Investigate and develop a secure, real-time passenger information system that leverages the enhanced security infrastructure to provide a 'killer application' for users.

## 1.3 Follow Up Consultation

In the next consultation, we will review the detailed risk assessment, the comprehensive supply chain security plan, and the specific criteria for 'no-remote-kill' verification. We will also discuss alternative security architectures and strategies for mitigating operational disruptions.

## 1.4.A Issue - Over-Reliance on Hardware Air-Gapping Without Sufficient Justification and Risk Assessment

The plan heavily emphasizes hardware-based air-gapping as the primary security control. While air-gapping can be effective, it's a drastic measure that can severely impact functionality, diagnostics, and updates. The current documentation lacks a robust justification for this approach, particularly considering the potential operational disruptions and the possibility of introducing new vulnerabilities through the air-gap hardware itself. There's insufficient evidence that less disruptive measures have been adequately considered and ruled out. The 'Pioneer's Gambit' scenario selection reinforces this potentially flawed approach.

### 1.4.B Tags

- air-gap
- operational_impact
- risk_assessment
- justification
- hardware_security

### 1.4.C Mitigation

Immediately commission a detailed risk assessment comparing hardware air-gapping to alternative security architectures (e.g., strong network segmentation, zero-trust access controls, enhanced monitoring). This assessment MUST quantify the potential operational impact (downtime, maintenance costs, diagnostic limitations) of each option, as well as the residual risk after implementing each control. Consult with operational technology (OT) security experts experienced in public transportation systems. Review NIST SP 800-82 (Guide to Industrial Control Systems Security) for relevant guidance. Provide detailed data on the existing network architecture, data flows, and vendor access protocols to facilitate a realistic assessment.

### 1.4.D Consequence

Without a proper risk assessment, the project risks implementing an overly restrictive and costly solution that significantly disrupts e-bus operations without providing a commensurate increase in security. It could also introduce new vulnerabilities through the air-gap hardware itself, negating the intended benefits.

### 1.4.E Root Cause

Lack of comprehensive risk assessment and over-reliance on a single security control.

## 1.5.A Issue - Insufficient Focus on Supply Chain Security Beyond Component Origin Verification

While the plan mentions component origin verification, it doesn't adequately address the broader supply chain security risks. The focus seems to be primarily on identifying the source of components, but it neglects other critical aspects such as firmware integrity, software assurance, and vendor security practices. Given the reliance on Chinese-made e-buses, a more comprehensive supply chain security strategy is essential. The current approach is reactive rather than proactive.

### 1.5.B Tags

- supply_chain_security
- firmware_integrity
- vendor_security
- proactive_security

### 1.5.C Mitigation

Develop a comprehensive supply chain security plan that includes: (1) Mandatory security audits of all critical vendors (including Yutong and its sub-tier suppliers) focusing on their software development lifecycle, firmware update processes, and vulnerability management practices. (2) Implementation of a robust firmware integrity verification process, including cryptographic signing and secure boot mechanisms. (3) Establishment of a vulnerability disclosure program to encourage responsible reporting of security flaws. (4) Continuous monitoring of vendor security advisories and threat intelligence feeds to identify potential supply chain attacks. Consult with supply chain security experts and review NIST SP 800-161 (Supply Chain Risk Management Practices for Federal Information Systems and Organizations). Provide detailed information on the e-bus component list, vendor relationships, and software/firmware update processes.

### 1.5.D Consequence

Failure to address supply chain security comprehensively leaves the e-bus systems vulnerable to malicious implants, compromised firmware, and other supply chain attacks. This could result in remote control of the buses, data breaches, or denial of service.

### 1.5.E Root Cause

Narrow focus on component origin verification and lack of a holistic supply chain security strategy.

## 1.6.A Issue - Lack of Clarity on 'No-Remote-Kill' Verification and Attestation

The plan repeatedly mentions the requirement for verifiable 'no-remote-kill' designs with independent cyber attestations. However, it lacks specific details on how this will be achieved and what criteria will be used to determine whether a design meets this requirement. The attestation standard seems to focus on general cybersecurity posture rather than specifically addressing the 'remote kill' vulnerability. Without clear and measurable criteria, the 'no-remote-kill' requirement becomes meaningless.

### 1.6.B Tags

- attestation
- verification
- remote_kill
- criteria
- measurement

### 1.6.C Mitigation

Define specific, measurable, achievable, relevant, and time-bound (SMART) criteria for verifying the 'no-remote-kill' capability. This should include: (1) A detailed analysis of all potential remote access pathways to critical systems (drive, brake, steer). (2) Development of specific test cases to simulate remote kill scenarios and verify the effectiveness of security controls. (3) Establishment of a formal attestation process that requires independent third-party validation of the 'no-remote-kill' criteria. (4) Ongoing monitoring and testing to ensure that the 'no-remote-kill' capability remains effective over time. Consult with cybersecurity experts specializing in automotive security and review relevant industry standards such as SAE J3061 (Cybersecurity Guidebook for Cyber-Physical Vehicle Systems). Provide detailed information on the e-bus system architecture, remote access protocols, and security controls.

### 1.6.D Consequence

Without clear and measurable criteria for 'no-remote-kill' verification, the project risks procuring e-buses that still have exploitable remote access vulnerabilities, negating the primary goal of the project.

### 1.6.E Root Cause

Lack of specific and measurable criteria for 'no-remote-kill' verification and attestation.

---

# 2 Expert: OT/ICS Security Engineer

**Knowledge**: Operational technology, industrial control systems, SCADA security

**Why**: To provide expertise on securing the e-bus control systems and implementing the air-gap solution.

**What**: Evaluate the proposed air-gap solution and hardening measures for critical control systems.

**Skills**: OT security, ICS hardening, network segmentation, air-gapping

**Search**: OT security engineer, ICS security, air gap implementation

## 2.1 Primary Actions

- Conduct a comprehensive risk assessment that considers the operational impact of air-gapping, including maintenance, updates, and incident response. Consult with OT/ICS security experts experienced in implementing air-gapping in transportation or similar environments.
- Develop a detailed network segmentation architecture that defines clear zones of trust, access control policies, and monitoring mechanisms. Consult with network security architects experienced in OT/ICS environments.
- Develop a robust firmware update management process that includes verifying the authenticity and integrity of all firmware updates, testing updates in a dedicated test environment before deployment, and implementing a rollback mechanism in case of update failures. Consult with firmware security experts.

## 2.2 Secondary Actions

- Implement a zero-trust security model within each network segment, requiring strict authentication and authorization for all network access.
- Deploy network intrusion detection and prevention systems (IDS/IPS) to monitor network traffic and detect anomalous activity within each segment.
- Implement a secure boot process for all critical e-bus systems, ensuring that only verified and trusted firmware can be loaded and executed.
- Conduct regular firmware audits to identify vulnerabilities and ensure that all systems are running the latest security patches.

## 2.3 Follow Up Consultation

In the next consultation, we will review the detailed risk assessment, network segmentation architecture, and firmware update management process. Please provide detailed diagrams, procedures, and documentation for each of these areas. We will also discuss the human element of air-gapping and the training program for operators and maintenance personnel.

## 2.4.A Issue - Over-Reliance on Air-Gapping Without Sufficient Contextual Understanding

The plan heavily emphasizes air-gapping as the primary security control. While air-gapping can be effective, it's often presented as a silver bullet without considering the operational implications and potential for circumvention. The current plan lacks sufficient detail on how air-gapping will be implemented, managed, and monitored in a real-world e-bus environment. There's a risk of creating a false sense of security if the air gap is not properly designed and maintained. The plan also doesn't address the human element – how will operators interact with air-gapped systems, and what measures are in place to prevent accidental or malicious bridging of the air gap?

### 2.4.B Tags

- air-gapping
- operational_impact
- human_factor
- false_security

### 2.4.C Mitigation

1. Conduct a thorough risk assessment that considers the operational impact of air-gapping, including maintenance, updates, and incident response. Consult with OT/ICS security experts experienced in implementing air-gapping in transportation or similar environments. Read NIST SP 800-82r3, 'Guide to Industrial Control Systems (ICS) Security,' for guidance on risk assessment and security controls. Provide detailed diagrams of the proposed air-gapped architecture, including all network connections and data flows. 2. Develop detailed procedures for managing and monitoring the air gap, including physical security measures, access controls, and audit trails. Consult with physical security experts to ensure the air gap cannot be easily bypassed. 3. Implement a robust training program for operators and maintenance personnel on the importance of maintaining the air gap and the procedures for interacting with air-gapped systems. Conduct regular security awareness training and phishing simulations.

### 2.4.D Consequence

Compromised critical systems despite the air gap, operational disruptions due to poorly managed air-gapped systems, increased attack surface due to new vulnerabilities introduced by the air-gap implementation.

### 2.4.E Root Cause

Lack of deep understanding of the complexities of air-gapping in a real-world OT environment.

## 2.5.A Issue - Insufficient Focus on Network Segmentation Beyond Air-Gapping

While air-gapping is mentioned, the plan lacks a comprehensive network segmentation strategy. Air-gapping alone is not sufficient. A layered approach with multiple zones of trust is crucial. The plan needs to define clear network segments, access control policies, and monitoring mechanisms to limit the blast radius of a potential attack. The current plan doesn't address how different e-bus systems (e.g., passenger information, ticketing, diagnostics) will be segmented and secured. There's a risk of lateral movement within the e-bus network if segmentation is not properly implemented.

### 2.5.B Tags

- network_segmentation
- lateral_movement
- defense_in_depth
- access_control

### 2.5.C Mitigation

1. Develop a detailed network segmentation architecture that defines clear zones of trust, access control policies, and monitoring mechanisms. Consult with network security architects experienced in OT/ICS environments. Read the Purdue Enterprise Reference Architecture (PERA) model for guidance on network segmentation. Provide a detailed network diagram illustrating the proposed segmentation architecture, including all network connections and data flows. 2. Implement a zero-trust security model within each network segment, requiring strict authentication and authorization for all network access. 3. Deploy network intrusion detection and prevention systems (IDS/IPS) to monitor network traffic and detect anomalous activity within each segment.

### 2.5.D Consequence

Successful lateral movement by attackers within the e-bus network, compromise of multiple systems due to a single vulnerability, increased downtime and recovery costs.

### 2.5.E Root Cause

Underestimation of the importance of network segmentation as a complementary security control to air-gapping.

## 2.6.A Issue - Inadequate Consideration of Firmware Security and Update Mechanisms

The plan mentions firmware audits, but lacks detail on how firmware updates will be managed and secured. Firmware is a critical attack vector in OT/ICS environments. The plan needs to address how firmware updates will be verified, tested, and deployed to prevent malicious or compromised updates from being installed. The current plan doesn't address the potential for supply chain attacks targeting firmware. There's a risk of bricking e-bus systems if firmware updates are not properly managed.

### 2.6.B Tags

- firmware_security
- supply_chain_attack
- update_management
- bricking

### 2.6.C Mitigation

1. Develop a robust firmware update management process that includes verifying the authenticity and integrity of all firmware updates, testing updates in a dedicated test environment before deployment, and implementing a rollback mechanism in case of update failures. Consult with firmware security experts. Read NIST SP 800-147B, 'BIOS Integrity Measurement Guidelines,' for guidance on firmware security. Provide a detailed description of the proposed firmware update management process, including all steps and security controls. 2. Implement a secure boot process for all critical e-bus systems, ensuring that only verified and trusted firmware can be loaded and executed. 3. Conduct regular firmware audits to identify vulnerabilities and ensure that all systems are running the latest security patches.

### 2.6.D Consequence

Compromised e-bus systems due to malicious or vulnerable firmware, bricking of e-bus systems due to failed firmware updates, increased attack surface due to unpatched vulnerabilities.

### 2.6.E Root Cause

Lack of awareness of the importance of firmware security in OT/ICS environments.

---

# The following experts did not provide feedback:

# 3 Expert: Public Transportation Security Specialist

**Knowledge**: Public transit security, emergency response, risk management

**Why**: To ensure the security measures align with operational needs and minimize disruption to public transportation services.

**What**: Review the rollback playbook and emergency response drills for practicality and effectiveness.

**Skills**: Transit security, emergency planning, risk assessment, training

**Search**: public transit security, emergency response plan, security drills

# 4 Expert: Data Privacy Legal Counsel

**Knowledge**: GDPR, data anonymization, privacy law, compliance

**Why**: To ensure compliance with data privacy regulations when implementing data flow monitoring and operational data blacklisting.

**What**: Advise on data anonymization standards and legal compliance for data handling.

**Skills**: Data privacy, legal compliance, GDPR, data anonymization techniques

**Search**: data privacy lawyer, GDPR compliance, data anonymization

# 5 Expert: Cybersecurity Compliance Auditor

**Knowledge**: Cybersecurity standards, compliance auditing, risk assessment

**Why**: To evaluate the adherence to cybersecurity attestation standards and procurement security requirements.

**What**: Conduct audits of vendor security practices and compliance with established standards.

**Skills**: Compliance auditing, risk management, cybersecurity frameworks

**Search**: cybersecurity compliance auditor, vendor security audit, risk assessment

# 6 Expert: Incident Response Coordinator

**Knowledge**: Incident response planning, crisis management, cybersecurity

**Why**: To develop and refine the incident response protocols and ensure effective execution during security incidents.

**What**: Create a comprehensive incident response plan that integrates with the rollback playbook.

**Skills**: Incident management, crisis communication, cybersecurity training

**Search**: incident response coordinator, crisis management, cybersecurity incident plan

# 7 Expert: Threat Intelligence Analyst

**Knowledge**: Threat analysis, cybersecurity trends, risk mitigation

**Why**: To establish a proactive threat intelligence program that identifies emerging risks relevant to e-bus systems.

**What**: Develop a framework for continuous threat monitoring and intelligence sharing.

**Skills**: Threat analysis, risk assessment, cybersecurity research

**Search**: threat intelligence analyst, cybersecurity trends, risk mitigation strategies

# 8 Expert: Transportation Systems Engineer

**Knowledge**: Public transportation systems, engineering design, operational efficiency

**Why**: To ensure that security measures do not compromise the operational efficiency of e-bus systems.

**What**: Assess the impact of proposed security measures on e-bus performance and operations.

**Skills**: Systems engineering, transportation design, operational analysis

**Search**: transportation systems engineer, public transit design, operational efficiency