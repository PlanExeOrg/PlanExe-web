Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 14 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 5 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan focuses on cybersecurity measures and does not inherently violate any laws of physics. The goal is to "sever all remote access pathways" and "air-gap drive/brake/steer".

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan combines a novel product (Chinese e-buses) + market (Danish public transport) + tech/process (air-gapping) + policy (procurement mandates) without evidence of comparable success. The plan states, "sever all vendor remote paths, air-gap drive/brake/steer..."

**Mitigation**: Run parallel validation tracks: Market/Demand (public acceptance), Legal/Regulatory (compliance), Technical/Operational (air-gap impact), Ethics/Societal (privacy). Define NO-GO gates: (1) empirical validity, (2) legal clearance. Reject mismatched PoCs. Owner: Project Manager / Validation Report / 2027-Apr-27


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan uses terms like "zero-trust architecture" and "red team/blue team exercise" without defining their specific implementation or measurable outcomes. The plan states, "Establish a zero-trust architecture...Implement a red team/blue team exercise..."

**Mitigation**: Cybersecurity Architect: Produce one-pagers defining "zero-trust architecture" and "red team/blue team exercise" in the e-bus context, including value hypotheses, success metrics, and decision hooks by 2026-Aug-27.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies risks (regulatory, technical, financial, etc.) but lacks explicit analysis of cascade effects. The plan states, "Mitigation: Testing, vendor diversification, cost management." There is no mention of legal, safety, or reputational risks.

**Mitigation**: Risk Management Team: Expand the risk register to include legal, safety, and reputational risks, map potential cascade effects, and add controls with a review cadence by 2026-Aug-27.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 9-month national rollout is optimistic given vendor selection, system deployment, and security attestation. The plan states, "National rollout: 2 months vendor selection, 4 months deployment, 3 months attestation."

**Mitigation**: Project Manager: Extend the national rollout timeline to 18-24 months, detailing task breakdown/resource allocation, phasing rollout, and establishing vendor/stakeholder communication by 2026-Aug-27.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not include a dated financing plan listing sources/status, draw schedule, and covenants. The plan mentions a budget of DKK 120M, but lacks details on funding sources and draw schedules.

**Mitigation**: CFO: Create a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO-GO on missed financing gates by 2026-Aug-27.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 9-month national rollout is optimistic given vendor selection, system deployment, and security attestation. The plan states, "National rollout: 2 months vendor selection, 4 months deployment, 3 months attestation."

**Mitigation**: Project Manager: Extend the national rollout timeline to 18-24 months, detailing task breakdown/resource allocation, phasing rollout, and establishing vendor/stakeholder communication by 2026-Aug-27.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (budget, timeline) as single numbers without ranges or alternative scenarios. The plan states, "Budget of DKK 120M" and "The project is expected to be completed within 12 months."

**Mitigation**: Project Manager: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the project's budget and timeline, due by 2026-Aug-27.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks engineering artifacts for build-critical components. There are no technical specifications, interface definitions, test plans, or integration maps. The plan mentions "air-gap drive/brake/steer from cloud/OTA" but lacks specifics.

**Mitigation**: Engineering Team Lead: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for the air-gap solution by 2026-Nov-27.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes claims about verifiable 'no-remote-kill' designs and independent cyber attestations without providing verifiable artifacts. The plan states, "tighten procurement to require verifiable 'no-remote-kill' designs with independent cyber attestations".

**Mitigation**: Procurement Security Specialist: Obtain sample 'no-remote-kill' design verification reports and attestation documentation from potential vendors by 2026-Aug-27, or change scope.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "isolation/rollback playbook operators can execute in hours" without defining specific, verifiable qualities. The plan states, "publish an isolation/rollback playbook operators can execute in hours."

**Mitigation**: Incident Response Coordinator: Define SMART criteria for the rollback playbook, including a KPI for MTTR (e.g., <4 hours) and a test plan by 2026-Aug-27.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes a "Vendor Diversity Initiative" that adds complexity without directly supporting the core goals of air-gapping and 'no-remote-kill'. The plan states, "The Vendor Diversity Initiative aims to reduce reliance on single e-bus manufacturers..."

**Mitigation**: Project Team: Produce a one-page benefit case justifying the Vendor Diversity Initiative's inclusion, complete with a KPI, owner, and estimated cost, or move the feature to the project backlog by 2026-Aug-27.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a "Cybersecurity Architect" to design and oversee security, but the role is both essential and likely difficult to fill. The plan states, "Responsible for designing and overseeing the implementation of the cybersecurity measures..."

**Mitigation**: HR: Validate the talent market for Cybersecurity Architects with e-bus experience by contacting recruiting firms and posting job ads within 30 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a regulatory matrix (authority, artifact, lead time, predecessors) for permits, licenses, and codes. The plan states, "Engage with regulatory bodies early in the project." but lacks specifics.

**Mitigation**: Legal Team: Create a regulatory matrix (authority, artifact, lead time, predecessors) for permits, licenses, and codes by 2026-Aug-27.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan lacks a comprehensive operational sustainability plan. The plan mentions "enhance cybersecurity of public transportation infrastructure" but omits details on long-term funding, maintenance, and technology roadmaps.

**Mitigation**: Project Manager: Develop an operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms by 2026-Nov-27.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions regulatory compliance but lacks a fatal-flaw screen with authorities. The plan states, "Engage with regulatory bodies early in the project." but lacks specifics on zoning, occupancy, fire load, etc.

**Mitigation**: Legal Team: Conduct a fatal-flaw screen with relevant authorities to identify potential hard constraints and NO-GO thresholds by 2026-Aug-27.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions vendor contracts but lacks evidence of SLAs with defined uptime, response times, and penalties. The plan states, "Negotiate vendor contracts and agreements" but does not include specific SLA terms.

**Mitigation**: Procurement Security Specialist: Secure SLAs with vendors that explicitly define acceptable access parameters, response times, security protocols, and penalties for non-compliance by 2026-Nov-27.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the stated goals of the Cybersecurity Team (secure e-buses) and Procurement (cost-effective vendor selection) conflict. Cybersecurity may want expensive solutions, while Procurement seeks cheaper options.

**Mitigation**: Project Manager: Create a shared OKR for Cybersecurity and Procurement focused on 'cost-effective security' with measurable targets by 2026-Aug-27.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board with escalation thresholds by 2026-Aug-27.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan has ≥3 High risks (timeline, budget, threat intelligence) that are strongly coupled. A delay in vendor selection (timeline) can lead to budget overruns. Lack of threat intelligence can render security ineffective.

**Mitigation**: Project Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by 2026-Nov-27.