
## Audit - Corruption Risks

- Bribery of procurement officials to favor specific vendors who may not offer the most secure solutions.
- Conflicts of interest where project team members have undisclosed financial ties to e-bus vendors or cybersecurity firms.
- Kickbacks from vendors to project personnel in exchange for favorable contract terms or relaxed security requirements.
- Misuse of confidential procurement information to give certain vendors an unfair advantage in the bidding process.
- Trading favors with vendors, such as accepting gifts or hospitality, in exchange for overlooking security vulnerabilities or non-compliance.

## Audit - Misallocation Risks

- Misuse of the DKK 120M budget for personal gain or unauthorized expenses.
- Double spending on cybersecurity attestations or penetration testing services.
- Inefficient allocation of resources, such as overspending on hardware while underfunding personnel training.
- Unauthorized use of project assets, such as vehicles or equipment, for non-project-related activities.
- Misreporting project progress or results to justify continued funding or to conceal delays or failures.

## Audit - Procedures

- Conduct periodic internal reviews of procurement processes to ensure compliance with security requirements and ethical standards (quarterly, internal audit team).
- Perform post-project external audits of financial transactions to identify any instances of fraud or misallocation of funds (post-project, external audit firm).
- Review vendor contracts to ensure they include clear security requirements, performance metrics, and penalties for non-compliance (at contract signing and annually, legal counsel).
- Implement expense workflows with multiple levels of approval to prevent unauthorized spending (ongoing, finance department).
- Conduct compliance checks to ensure adherence to GDPR, NIS Directive, and ISO 27001 standards (annually, compliance officer).

## Audit - Transparency Measures

- Publish a project progress dashboard that tracks key milestones, budget expenditures, and security metrics (monthly, project website).
- Publish minutes of key project meetings, including those of the steering committee and technical advisory group (monthly, project website).
- Establish a whistleblower mechanism for reporting suspected fraud, corruption, or security breaches (ongoing, independent ethics hotline).
- Provide public access to relevant project policies and reports, such as the cybersecurity attestation standard and the operator rollback playbook (upon completion, project website).
- Document and publish the selection criteria for major decisions, such as vendor selection and technology choices (at decision time, project website).