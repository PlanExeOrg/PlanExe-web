## Primary Decisions
The vital few decisions that have the most impact.


The 'Critical' and 'High' impact levers address the fundamental project tensions of security vs. functionality (System Isolation, Control System Hardening), security vs. cost/vendor choice (Procurement Security, Attestation), and proactive vs. reactive security (Firmware Audit, Rollback). A potential missing dimension is active threat intelligence gathering to proactively identify emerging risks.

### Decision 1: Vendor Access Protocols
**Lever ID:** `ce9317e4-d882-48b8-b7d6-431eb29a4cb0`

**The Core Decision:** This lever defines the rules and technologies governing vendor access to e-bus systems. It aims to minimize remote access vulnerabilities while enabling necessary maintenance. Success is measured by a reduction in unauthorized access attempts and the timely resolution of security incidents without hindering vendor support.

**Why It Matters:** Restricting vendor access reduces the risk of remote exploitation but may hinder legitimate maintenance and updates. A complete block could delay critical patches, while overly permissive access negates the security gains. Balancing vendor support with security requires careful configuration and monitoring.

**Strategic Choices:**

1. Establish a zero-trust architecture, mandating multi-factor authentication and continuous authorization for all vendor access attempts, logging all actions for auditability
2. Implement a segregated network for vendor access, limiting connectivity to only the specific systems requiring maintenance and actively monitoring traffic for anomalies
3. Negotiate service-level agreements with vendors that explicitly define acceptable access parameters, response times, and security protocols, incorporating penalties for non-compliance

**Trade-Off / Risk:** Balancing vendor access for maintenance with security is crucial, as overly restrictive measures can hinder necessary updates and repairs.

**Strategic Connections:**

**Synergy:** This lever works well with System Isolation Strategy, ensuring that even when vendors have access, it's within a controlled, segmented environment.

**Conflict:** This lever conflicts with Operator Rollback Capability, as overly restrictive vendor access might delay critical patches needed for effective rollback procedures.

**Justification:** *High*, High importance due to its direct impact on vendor maintenance vs. security trade-off. It connects to system isolation and operator rollback, indicating a central role in managing external access risks.

### Decision 2: System Isolation Strategy
**Lever ID:** `8fc7cc85-9f83-4dab-8434-df9c2c38378f`

**The Core Decision:** This lever focuses on physically or logically separating critical e-bus systems from external networks to prevent remote exploitation. Success is measured by the absence of remote breaches and the ability to maintain essential functionality despite isolation. It requires a balance between security and operational needs.

**Why It Matters:** Physically isolating critical systems from the network prevents remote exploitation but can complicate diagnostics and updates. A complete air gap may require manual intervention for routine tasks, increasing operational overhead. Partial isolation offers a compromise but requires careful design to prevent breaches.

**Strategic Choices:**

1. Implement a unidirectional gateway to allow data to flow from the e-bus systems to a central monitoring station, but block any inbound communication paths
2. Deploy a hardware-based air gap solution that physically disconnects the drive, brake, and steering systems from any network connection, relying on local control systems
3. Utilize a virtual air gap by creating isolated virtual machines for critical systems, preventing direct network access while allowing controlled data transfer through secure channels

**Trade-Off / Risk:** System isolation is vital, but complete air-gapping can hinder diagnostics and updates, necessitating a balanced approach to maintain functionality.

**Strategic Connections:**

**Synergy:** This lever strongly synergizes with Network Segmentation Architecture, creating distinct zones of trust and minimizing the attack surface.

**Conflict:** This lever constrains Data Flow Monitoring, as complete isolation can make it difficult to collect and analyze data for threat detection and performance monitoring.

**Justification:** *Critical*, Critical because it directly addresses the core goal of air-gapping critical systems. Its synergy with network segmentation and conflict with data flow monitoring highlight its central role in the security architecture.

### Decision 3: Cybersecurity Attestation Standard
**Lever ID:** `73e56697-3322-4545-ba4c-26fde72ac228`

**The Core Decision:** This lever establishes a standard for independent verification of e-bus cybersecurity posture. It aims to ensure that systems meet defined security criteria through rigorous testing and assessment. Success is measured by the credibility and thoroughness of the attestation process and a reduction in identified vulnerabilities.

**Why It Matters:** Requiring independent cybersecurity attestations adds a layer of assurance but increases procurement costs and may limit vendor selection. A rigorous standard ensures thorough testing, while a weak standard provides a false sense of security. The credibility of the attestation process is paramount.

**Strategic Choices:**

1. Mandate third-party penetration testing and vulnerability assessments of all e-bus systems, requiring vendors to remediate identified issues before deployment
2. Establish a certification program for e-bus cybersecurity, requiring vendors to obtain certification from an accredited organization before being eligible for procurement
3. Implement a red team/blue team exercise to simulate real-world attacks on e-bus systems, evaluating the effectiveness of security controls and incident response procedures

**Trade-Off / Risk:** Independent cybersecurity attestations enhance assurance, but the rigor and credibility of the attestation process are critical to avoid false security.

**Strategic Connections:**

**Synergy:** This lever amplifies Procurement Security Requirements by providing an objective measure of vendor security practices during the selection process.

**Conflict:** This lever trades off against Vendor Diversity Initiative, as stringent attestation requirements may limit the pool of eligible vendors.

**Justification:** *High*, High importance as it provides an objective measure of vendor security, impacting procurement and vendor diversity. It ensures verifiable 'no-remote-kill' designs, a key project requirement.

### Decision 4: Procurement Security Requirements
**Lever ID:** `0e8555de-b9b7-4ac3-9fb6-6bcb66131f06`

**The Core Decision:** This lever integrates security considerations into the e-bus procurement process, mandating vendors to meet specific cybersecurity requirements. It aims to ensure that security is a primary factor in vendor selection. Success is measured by the strength of security controls in procured systems and a reduction in vulnerabilities.

**Why It Matters:** Stricter procurement requirements can improve security but may increase costs and limit vendor choices. A comprehensive set of requirements ensures thorough evaluation, while vague requirements provide little benefit. Balancing security with cost and availability is key.

**Strategic Choices:**

1. Incorporate security requirements into the e-bus procurement process, mandating vendors to provide detailed information on system architecture, security controls, and vulnerability management practices
2. Establish a pre-qualification process for e-bus vendors, requiring them to demonstrate compliance with cybersecurity standards before being eligible to bid on contracts
3. Implement a security scoring system to evaluate e-bus vendor proposals, assigning points based on the strength of their security controls and vulnerability management practices

**Trade-Off / Risk:** Stringent procurement requirements enhance security, but may increase costs and limit vendor options, requiring a balance between security and practicality.

**Strategic Connections:**

**Synergy:** This lever is amplified by Cybersecurity Attestation Standard, which provides a clear benchmark for evaluating vendor security claims during procurement.

**Conflict:** This lever constrains Vendor Diversity Initiative, as stricter security requirements may reduce the number of vendors able to meet the criteria.

**Justification:** *Critical*, Critical because it integrates security into vendor selection, directly impacting the security posture of procured systems. Its synergy with attestation and conflict with vendor diversity make it a key strategic control point.

### Decision 5: Control System Hardening
**Lever ID:** `1484034e-0ada-43ac-88ff-bd4c73cec49c`

**The Core Decision:** Control System Hardening focuses on physically and logically securing critical e-bus components. It involves isolation, access controls, and secure boot processes. Success is measured by the reduction in attack surface, prevention of unauthorized access, and improved resilience against cyberattacks targeting essential systems.

**Why It Matters:** Hardening control systems involves physically isolating critical components and implementing robust access controls. This can impact the functionality of certain features, such as remote diagnostics, and may require significant modifications to the e-bus architecture. However, it reduces the attack surface and prevents unauthorized access to essential systems.

**Strategic Choices:**

1. Physically isolate critical control systems (drive, brake, steer) from the network by implementing air-gapping techniques and dedicated hardware interfaces.
2. Implement multi-factor authentication and role-based access control for all control system interfaces, restricting access to authorized personnel only.
3. Develop a secure boot process for control systems, ensuring that only verified and trusted firmware can be loaded and executed.

**Trade-Off / Risk:** Air-gapping offers strong security but limits remote diagnostics, while access controls add complexity and secure boot requires ongoing maintenance.

**Strategic Connections:**

**Synergy:** This lever is strengthened by Network Segmentation Architecture, which further isolates critical systems. It also benefits from the Cybersecurity Attestation Standard, ensuring hardening measures meet defined criteria.

**Conflict:** Hardening may limit the functionality of Vendor Access Protocols, such as remote diagnostics. It also requires careful consideration of Operational Data Blacklisting to avoid unintended consequences.

**Justification:** *Critical*, Critical because it directly secures critical e-bus components. Its synergies with network segmentation and attestation, and conflicts with vendor access, make it a foundational element.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Operator Rollback Capability
**Lever ID:** `8423c046-2de3-4f71-8382-52c9acc4a20f`

**The Core Decision:** This lever empowers operators to quickly restore e-bus systems to a secure state after a security incident. It requires well-defined procedures, robust backup mechanisms, and regular training. Success is measured by the speed and effectiveness of the rollback process and the minimization of downtime.

**Why It Matters:** Providing operators with a rollback capability allows for rapid recovery from compromised systems but requires robust backup and recovery mechanisms. A well-tested playbook enables quick action, while a poorly designed process can exacerbate the problem. Training and readiness are essential.

**Strategic Choices:**

1. Develop a standardized rollback procedure that allows operators to quickly revert e-bus systems to a known good state in the event of a security incident
2. Implement a secure backup and recovery system that automatically creates regular snapshots of e-bus system configurations, enabling rapid restoration
3. Conduct regular tabletop exercises with operators to simulate security incidents and practice the rollback procedure, ensuring familiarity and proficiency

**Trade-Off / Risk:** Operator rollback capabilities enable rapid recovery, but require robust backup mechanisms and well-tested procedures to be effective in a crisis.

**Strategic Connections:**

**Synergy:** This lever is enabled by Security Patching Cadence, ensuring that rollback points include the latest security updates for faster recovery.

**Conflict:** This lever conflicts with Control System Hardening, as overly aggressive hardening might complicate the rollback process or create incompatibilities with backup images.

**Justification:** *High*, High importance because it provides a rapid recovery mechanism, directly addressing the risk of compromised systems. Its connection to security patching and conflict with control system hardening are strategically relevant.

### Decision 7: Data Flow Monitoring
**Lever ID:** `980e43e7-9836-4e46-b954-f9bec18f6f2b`

**The Core Decision:** Data Flow Monitoring establishes continuous surveillance of network traffic to detect anomalies indicative of intrusions or data breaches. Success hinges on the ability to rapidly analyze high volumes of data and accurately identify malicious patterns. Key metrics include detection rate, false positive rate, and time to detection.

**Why It Matters:** Monitoring data flows can detect anomalies and potential intrusions, but requires significant processing power and expertise. Comprehensive monitoring provides early warning, while limited monitoring may miss critical events. Privacy considerations must also be addressed.

**Strategic Choices:**

1. Implement a network intrusion detection system to monitor data flows between e-bus systems and external networks, identifying suspicious activity and potential security breaches
2. Deploy a security information and event management (SIEM) system to collect and analyze security logs from e-bus systems, providing real-time visibility into security events
3. Establish a data loss prevention (DLP) system to monitor data flows for sensitive information, preventing unauthorized transmission of confidential data

**Trade-Off / Risk:** Data flow monitoring detects intrusions, but requires significant resources and expertise, balancing comprehensive coverage with practical limitations.

**Strategic Connections:**

**Synergy:** Data Flow Monitoring enhances the effectiveness of the Incident Data Retention Policy by providing the raw data needed for post-incident analysis and forensic investigation.

**Conflict:** Data Flow Monitoring can conflict with System Isolation Strategy if overly aggressive monitoring interferes with legitimate data flows within segmented networks, hindering operational efficiency.

**Justification:** *Medium*, Medium importance. While useful for intrusion detection, its conflict with system isolation and dependence on resources make it less central than other levers.

### Decision 8: Emergency Response Drills
**Lever ID:** `b35a1fab-0fe8-4f0c-b9c1-5f0ede74c1d7`

**The Core Decision:** Emergency Response Drills are periodic simulations designed to test and refine the operator's ability to execute the isolation and rollback playbook. Success is measured by the speed and accuracy of the response, as well as the identification of weaknesses in the playbook or training. 

**Why It Matters:** Regular drills validate the effectiveness of the isolation and rollback playbook, ensuring operators can respond swiftly to potential threats. However, frequent drills can disrupt service and require significant staff time, potentially leading to operator fatigue and reduced responsiveness over time.

**Strategic Choices:**

1. Conduct unannounced, full-scale drills quarterly to simulate real-world attack scenarios and identify vulnerabilities in the response process
2. Implement tabletop exercises bi-annually, focusing on communication protocols and decision-making processes during a cyber incident
3. Develop a train-the-trainer program to empower local operators to conduct regular, low-impact drills without central oversight

**Trade-Off / Risk:** Frequent, realistic drills improve response readiness, but the disruption and resource demands must be carefully managed to avoid diminishing returns.

**Strategic Connections:**

**Synergy:** Emergency Response Drills directly validate and improve the Operator Rollback Capability, ensuring operators are prepared to execute the rollback plan effectively under pressure.

**Conflict:** Emergency Response Drills can conflict with Operator Training Curriculum if the drills are not integrated into a broader training program, leading to operator fatigue and reduced engagement.

**Justification:** *Medium*, Medium importance. It validates the rollback playbook, but its impact is dependent on the effectiveness of the rollback capability itself. Disruption is a concern.

### Decision 9: Component Origin Verification
**Lever ID:** `fe4a5b87-91df-426c-9858-50c2790d1d50`

**The Core Decision:** Component Origin Verification aims to secure the supply chain by confirming the source and integrity of critical e-bus components. Success is measured by the percentage of components verified and the reduction in supply chain vulnerabilities identified. This process adds assurance against hardware-based attacks.

**Why It Matters:** Verifying the origin and integrity of all critical components reduces the risk of supply chain attacks and malicious hardware implants. However, this process can be time-consuming and expensive, potentially delaying the rollout and increasing procurement costs.

**Strategic Choices:**

1. Establish a rigorous audit process to trace the origin of all critical components back to the manufacturer and verify their integrity
2. Implement a risk-based approach, focusing verification efforts on components from high-risk vendors or those with a history of security vulnerabilities
3. Partner with a trusted third-party to conduct independent component verification and provide ongoing supply chain monitoring

**Trade-Off / Risk:** Component verification strengthens supply chain security, but the cost and time investment must be balanced against the overall risk profile.

**Strategic Connections:**

**Synergy:** Component Origin Verification strengthens the Procurement Security Requirements by adding a layer of due diligence to vendor selection and component sourcing.

**Conflict:** Component Origin Verification can conflict with the Vendor Diversity Initiative if stringent verification requirements limit the pool of eligible vendors, potentially reducing competition and increasing costs.

**Justification:** *Medium*, Medium importance. Addresses supply chain risks, but the cost and time investment need to be balanced. It's less critical than securing the overall system architecture.

### Decision 10: Network Segmentation Architecture
**Lever ID:** `22ba3f54-b6ba-433c-9595-40bdf243097b`

**The Core Decision:** Network Segmentation Architecture divides the e-bus network into isolated zones to limit the blast radius of a cyberattack. Success is measured by the degree of isolation achieved and the reduction in lateral movement possible for attackers. This reduces the impact of successful intrusions.

**Why It Matters:** Implementing robust network segmentation limits the impact of a successful cyberattack by isolating critical systems from less secure networks. However, complex segmentation can increase network management overhead and potentially hinder legitimate data flows required for operational efficiency.

**Strategic Choices:**

1. Create a physically isolated network for critical systems, completely separated from the internet and other external networks
2. Implement a virtualized network architecture with micro-segmentation, allowing for granular control over network traffic and access permissions
3. Utilize a zero-trust network model, requiring strict authentication and authorization for all network access, regardless of location or device

**Trade-Off / Risk:** Network segmentation reduces attack surface, but overly complex architectures can impede operations and increase management costs.

**Strategic Connections:**

**Synergy:** Network Segmentation Architecture complements Control System Hardening by providing an additional layer of defense, limiting the potential damage from vulnerabilities in individual control systems.

**Conflict:** Network Segmentation Architecture can conflict with Data Flow Monitoring if overly strict segmentation rules impede the flow of legitimate data required for effective monitoring and analysis.

**Justification:** *High*, High importance as it limits the impact of attacks. Synergies with control system hardening and conflicts with data flow monitoring show its systemic impact on security.

### Decision 11: Incident Data Retention Policy
**Lever ID:** `78fafa18-9b5c-4e8e-916a-c6100ae19bfa`

**The Core Decision:** Incident Data Retention Policy defines the rules for storing and managing security-related data to facilitate incident investigation and analysis. Success is measured by the completeness and accessibility of retained data, balanced against storage costs and compliance with privacy regulations. 

**Why It Matters:** A comprehensive data retention policy ensures that sufficient forensic data is available to investigate and learn from security incidents. However, storing large volumes of data can be expensive and raise privacy concerns, requiring careful consideration of data minimization and anonymization techniques.

**Strategic Choices:**

1. Retain all security logs and network traffic data for a minimum of one year to facilitate thorough incident investigations and trend analysis
2. Implement a tiered data retention policy, prioritizing the retention of critical security logs and anonymizing or deleting less relevant data after a shorter period
3. Utilize a security information and event management (SIEM) system to automatically collect, analyze, and retain relevant security data based on predefined rules and thresholds

**Trade-Off / Risk:** Data retention supports incident analysis, but balancing security needs with storage costs and privacy regulations is crucial for long-term viability.

**Strategic Connections:**

**Synergy:** Incident Data Retention Policy supports Firmware Audit Protocol by providing historical data to identify patterns and anomalies in firmware behavior over time.

**Conflict:** Incident Data Retention Policy can conflict with Operational Data Blacklisting if overly aggressive blacklisting rules inadvertently delete valuable security logs needed for incident investigation.

**Justification:** *Medium*, Medium importance. Supports incident analysis, but balancing security needs with storage costs and privacy regulations is crucial. Less direct impact than isolation or procurement.

### Decision 12: Security Patching Cadence
**Lever ID:** `e7b739d5-6515-45a0-8cb2-c496b8074262`

**The Core Decision:** Security Patching Cadence defines the frequency and process for applying security updates to e-bus systems. It aims to minimize vulnerabilities by promptly addressing known issues. Success is measured by the percentage of systems patched within the defined timeframe and the reduction in security incidents related to unpatched vulnerabilities.

**Why It Matters:** Regular security patching mitigates known vulnerabilities and reduces the attack surface. However, frequent patching can disrupt operations and introduce instability, requiring careful testing and change management procedures.

**Strategic Choices:**

1. Establish a monthly patching cycle for all critical systems, prioritizing the installation of security updates that address actively exploited vulnerabilities
2. Implement a risk-based patching approach, focusing on patching systems with the highest risk exposure and deferring less critical updates to a later date
3. Create a dedicated test environment to thoroughly evaluate the impact of security patches before deploying them to production systems

**Trade-Off / Risk:** Consistent patching reduces vulnerabilities, but the operational disruption and potential for instability necessitate a well-defined testing and deployment process.

**Strategic Connections:**

**Synergy:** This lever works well with the Firmware Audit Protocol, as audits identify vulnerabilities that necessitate patching. It also supports Control System Hardening by addressing software-level weaknesses.

**Conflict:** A frequent patching cadence may conflict with Operator Rollback Capability if patches introduce instability. It also requires careful coordination with the Operator Training Curriculum to ensure operators understand changes.

**Justification:** *Medium*, Medium importance. While necessary, patching is a reactive measure. Its conflict with rollback and operator training makes it less strategically central.

### Decision 13: Operator Training Curriculum
**Lever ID:** `6dc3675c-7768-4dca-8691-89fece585b28`

**The Core Decision:** The Operator Training Curriculum aims to equip personnel with the knowledge and skills to identify and respond to cybersecurity threats. Its scope includes awareness training, role-based modules, and simulated exercises. Success is measured by improved operator awareness, reduced phishing susceptibility, and faster incident response times.

**Why It Matters:** Comprehensive operator training enhances awareness of cybersecurity threats and equips personnel with the skills to identify and respond to incidents. However, extensive training programs can be costly and time-consuming, requiring ongoing investment to maintain operator proficiency.

**Strategic Choices:**

1. Develop a mandatory cybersecurity awareness training program for all operators, covering topics such as phishing, social engineering, and password security
2. Implement role-based training modules tailored to the specific responsibilities and security risks associated with each operator's job function
3. Conduct regular simulated phishing campaigns and other security exercises to test operator awareness and identify areas for improvement

**Trade-Off / Risk:** Well-trained operators are a critical line of defense, but the cost and effort of ongoing training must be justified by demonstrable improvements in security posture.

**Strategic Connections:**

**Synergy:** This lever amplifies the effectiveness of the Emergency Response Drills by ensuring operators know how to react. It also supports Data Flow Monitoring by helping operators identify anomalous activity.

**Conflict:** Extensive training may compete with resources allocated to Cybersecurity Skills Investment, which focuses on specialized cybersecurity personnel. It also requires ongoing investment, potentially conflicting with budget constraints.

**Justification:** *Medium*, Medium importance. Enhances awareness, but its impact is dependent on the effectiveness of other security measures. Resource constraints are a concern.

### Decision 14: Firmware Audit Protocol
**Lever ID:** `59ffcd2b-08c9-437b-a765-c8efcf8883a8`

**The Core Decision:** The Firmware Audit Protocol establishes a process for identifying vulnerabilities in e-bus firmware. It involves specialized expertise and tools to analyze system software. Success is measured by the number of vulnerabilities identified and the speed with which vendors remediate them, contributing to a more secure system overall.

**Why It Matters:** Implementing a rigorous firmware audit protocol will identify vulnerabilities in existing e-bus systems. This will require specialized expertise and tools, potentially delaying the isolation timeline if significant flaws are uncovered. However, it provides a concrete assessment of the current risk landscape and informs subsequent mitigation efforts.

**Strategic Choices:**

1. Mandate third-party security audits of all e-bus firmware, prioritizing critical systems and network interfaces, and require vendors to remediate identified vulnerabilities within a defined timeframe.
2. Establish an in-house security team to conduct firmware audits, developing proprietary tools and methodologies to analyze e-bus systems and identify potential security flaws.
3. Collaborate with academic institutions and cybersecurity research groups to perform firmware audits, leveraging their expertise and resources to assess e-bus systems and identify vulnerabilities.

**Trade-Off / Risk:** Independent audits offer deeper insights but add delays, while in-house teams build expertise but may lack specialized skills for complex firmware analysis.

**Strategic Connections:**

**Synergy:** This lever directly informs the Security Patching Cadence by identifying vulnerabilities that need to be addressed. It also supports Control System Hardening by revealing weaknesses in the system's core.

**Conflict:** A thorough audit may delay the System Isolation Strategy if significant flaws are uncovered, requiring more extensive remediation. It also requires specialized skills, potentially drawing resources from Cybersecurity Skills Investment.

**Justification:** *High*, High importance because it identifies vulnerabilities, informing patching and hardening efforts. Its potential to delay isolation highlights its strategic impact.

### Decision 15: Vendor Diversity Initiative
**Lever ID:** `958463d9-4379-49b4-b153-9170a30a6e34`

**The Core Decision:** The Vendor Diversity Initiative aims to reduce reliance on single e-bus manufacturers, mitigating the risk of widespread vulnerabilities. It involves multi-vendor procurement and incentivizing new market entrants. Success is measured by the diversity of the vendor base and the overall improvement in security practices across vendors.

**Why It Matters:** Diversifying the vendor base reduces reliance on any single manufacturer and mitigates the risk of widespread vulnerabilities. This may involve higher initial procurement costs and increased complexity in managing multiple vendors. However, it fosters competition and encourages vendors to prioritize security.

**Strategic Choices:**

1. Establish a multi-vendor procurement strategy, sourcing e-buses from a diverse range of manufacturers to reduce reliance on any single vendor.
2. Incentivize new market entrants by offering preferential procurement terms to vendors who demonstrate superior security practices and verifiable 'no-remote-kill' designs.
3. Collaborate with other European nations to create a joint procurement program, leveraging collective bargaining power to negotiate favorable terms with multiple vendors.

**Trade-Off / Risk:** Vendor diversity reduces risk but increases management complexity, while incentivizing new entrants may require subsidies or relaxed requirements.

**Strategic Connections:**

**Synergy:** This initiative complements Procurement Security Requirements by ensuring a broader range of vendors meet security standards. It also supports Component Origin Verification by making supply chains more transparent.

**Conflict:** Vendor diversity can increase the complexity of System Isolation Strategy due to variations in system architecture. It may also require adjustments to the Operator Training Curriculum to accommodate different e-bus models.

**Justification:** *Medium*, Medium importance. Reduces reliance on single vendors, but increases management complexity. Less direct impact on immediate security than isolation or hardening.

### Decision 16: Cybersecurity Skills Investment
**Lever ID:** `ae58d94b-7da0-4969-a41f-bed306245554`

**The Core Decision:** This lever focuses on building internal cybersecurity capabilities through training and dedicated teams. Success is measured by reduced incident response times, improved threat detection rates, and decreased reliance on external consultants. It aims to empower the workforce to proactively manage and mitigate cybersecurity risks within the public transportation system.

**Why It Matters:** Investing in cybersecurity skills within the public transportation workforce enhances the ability to identify and respond to threats. This requires dedicated training programs and resources, potentially diverting funds from other operational areas. However, it empowers operators to proactively manage security risks and reduces reliance on external expertise.

**Strategic Choices:**

1. Establish a comprehensive cybersecurity training program for public transportation personnel, covering topics such as threat detection, incident response, and secure system administration.
2. Create a dedicated cybersecurity team within the public transportation authority, responsible for monitoring systems, conducting vulnerability assessments, and responding to security incidents.
3. Partner with local universities and technical colleges to develop cybersecurity curricula tailored to the needs of the public transportation sector.

**Trade-Off / Risk:** Internal expertise improves responsiveness but requires ongoing investment, while external partnerships offer specialized skills but may lack domain knowledge.

**Strategic Connections:**

**Synergy:** Cybersecurity Skills Investment strongly supports Operator Training Curriculum, ensuring personnel have the knowledge to execute security protocols effectively. It also amplifies Emergency Response Drills.

**Conflict:** This lever may compete with Vendor Diversity Initiative if resources are diverted from vendor selection to internal training. It also trades off against short-term budget constraints.

**Justification:** *Low*, Low importance. While beneficial, it's a supporting lever. Its impact is realized over time and less critical for the immediate isolation and rollback goals.

### Decision 17: Operational Data Blacklisting
**Lever ID:** `7643be37-05a6-4b55-8ed7-3807be5232d2`

**The Core Decision:** This lever restricts vendor access to sensitive operational data to minimize remote exploitation risks. Key metrics include the reduction in data breaches and unauthorized access attempts. Success depends on balancing data protection with the need for remote diagnostics and maintenance, potentially requiring increased on-site support.

**Why It Matters:** Blacklisting specific data points from vendor access limits the potential for remote exploitation. This may hinder remote diagnostics and maintenance, requiring more on-site support. However, it reduces the attack surface and protects sensitive operational information.

**Strategic Choices:**

1. Implement a data blacklisting policy that restricts vendor access to sensitive operational data, such as GPS coordinates, passenger counts, and real-time vehicle telemetry.
2. Anonymize or redact sensitive data before it is transmitted to vendors, protecting passenger privacy and preventing the exploitation of operational information.
3. Establish a secure data enclave for storing sensitive operational data, limiting vendor access to authorized personnel only and implementing strict access controls.

**Trade-Off / Risk:** Data blacklisting enhances privacy but limits remote support, while anonymization adds complexity and may reduce data utility.

**Strategic Connections:**

**Synergy:** Operational Data Blacklisting enhances System Isolation Strategy by limiting the data available to external entities. It also supports Procurement Security Requirements by reducing data exposure.

**Conflict:** This lever constrains Vendor Access Protocols, limiting the scope of remote diagnostics and support. It also creates a trade-off with Data Flow Monitoring if blacklisting impedes legitimate monitoring activities.

**Justification:** *Low*, Low importance. Limits vendor access to sensitive data, but may hinder remote diagnostics. Less critical than system-level security measures.
