This plan involves money.

## Currencies

- **DKK:** Local currency for project execution in Denmark.

**Primary currency:** DKK

**Currency strategy:** The local currency (DKK) will be used for all transactions. No additional international risk management is needed.