# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** The plan aims to address a critical security vulnerability in a significant portion of Denmark's public transportation system, starting with a pilot in Copenhagen and scaling nationally. This indicates a substantial, nationwide ambition.

**Risk and Novelty:** The plan addresses a novel and potentially high-risk security vulnerability. The risk stems from the potential for remote exploitation of critical systems, while the novelty lies in the specific focus on Chinese-made e-buses and their potential 'kill-switch' vulnerabilities.

**Complexity and Constraints:** The plan is complex due to the need to integrate security measures into existing systems, manage vendor relationships, and ensure the continued operation of public transportation. Constraints include a budget of DKK 120M and a 12-month timeline.

**Domain and Tone:** The plan falls within the domain of cybersecurity and public transportation infrastructure. The tone is serious and pragmatic, focusing on mitigating a specific threat.

**Holistic Profile:** The plan is a focused, nationwide initiative to mitigate a novel cybersecurity risk in public transportation, requiring a balance of robust security measures, vendor management, and operational continuity within a defined budget and timeline.

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Pioneer's Gambit
**Strategic Logic:** This scenario embraces a high-risk, high-reward approach, prioritizing cutting-edge security measures and technological leadership. It accepts higher initial costs and potential disruptions to vendor relationships in pursuit of the most robust and future-proof security posture.

**Fit Score:** 9/10

**Why This Path Was Chosen:** This scenario aligns well with the plan's ambition to address a novel security risk with robust measures, including air-gapping and red team/blue team exercises, reflecting a proactive and aggressive security posture.

**Key Strategic Decisions:**

- **Vendor Access Protocols:** Establish a zero-trust architecture, mandating multi-factor authentication and continuous authorization for all vendor access attempts, logging all actions for auditability
- **System Isolation Strategy:** Deploy a hardware-based air gap solution that physically disconnects the drive, brake, and steering systems from any network connection, relying on local control systems
- **Cybersecurity Attestation Standard:** Implement a red team/blue team exercise to simulate real-world attacks on e-bus systems, evaluating the effectiveness of security controls and incident response procedures
- **Procurement Security Requirements:** Implement a security scoring system to evaluate e-bus vendor proposals, assigning points based on the strength of their security controls and vulnerability management practices
- **Control System Hardening:** Physically isolate critical control systems (drive, brake, steer) from the network by implementing air-gapping techniques and dedicated hardware interfaces.

**The Decisive Factors:**

The Pioneer's Gambit is the most suitable scenario because its high-risk, high-reward approach aligns with the plan's need to address a potentially critical security vulnerability. 

*   The plan's ambition to secure public transportation from a novel threat necessitates a proactive and robust security posture, which this scenario provides through air-gapping and red team/blue team exercises.
*   The Builder's Foundation, while balanced, might not be aggressive enough to counter the 'kill-switch' vulnerability.
*   The Consolidator's Shield prioritizes cost-control and stability, which could compromise the effectiveness of the security measures needed to address the identified risk. The plan requires decisive action, not incremental improvements.

---
## Alternative Paths
### The Builder's Foundation
**Strategic Logic:** This scenario seeks a balanced and pragmatic approach, focusing on proven security measures and collaborative vendor relationships. It prioritizes stability and manageability, aiming for solid progress while carefully managing risks and costs.

**Fit Score:** 7/10

**Assessment of this Path:** This scenario offers a balanced approach, but its reliance on virtual air gaps and segregated networks might not be aggressive enough given the identified 'kill-switch' vulnerability and the need for decisive action.

**Key Strategic Decisions:**

- **Vendor Access Protocols:** Implement a segregated network for vendor access, limiting connectivity to only the specific systems requiring maintenance and actively monitoring traffic for anomalies
- **System Isolation Strategy:** Utilize a virtual air gap by creating isolated virtual machines for critical systems, preventing direct network access while allowing controlled data transfer through secure channels
- **Cybersecurity Attestation Standard:** Mandate third-party penetration testing and vulnerability assessments of all e-bus systems, requiring vendors to remediate identified issues before deployment
- **Procurement Security Requirements:** Incorporate security requirements into the e-bus procurement process, mandating vendors to provide detailed information on system architecture, security controls, and vulnerability management practices
- **Control System Hardening:** Implement multi-factor authentication and role-based access control for all control system interfaces, restricting access to authorized personnel only.

### The Consolidator's Shield
**Strategic Logic:** This scenario prioritizes stability, cost-control, and risk-aversion above all else. It leverages existing infrastructure and proven security practices, minimizing disruption and focusing on compliance with established standards. It favors vendor collaboration and avoids aggressive or unproven technologies.

**Fit Score:** 5/10

**Assessment of this Path:** This scenario's focus on stability and cost-control makes it less suitable, as it might not provide the necessary level of security to address the identified vulnerability effectively. Unidirectional gateways and certification programs are less proactive.

**Key Strategic Decisions:**

- **Vendor Access Protocols:** Negotiate service-level agreements with vendors that explicitly define acceptable access parameters, response times, and security protocols, incorporating penalties for non-compliance
- **System Isolation Strategy:** Implement a unidirectional gateway to allow data to flow from the e-bus systems to a central monitoring station, but block any inbound communication paths
- **Cybersecurity Attestation Standard:** Establish a certification program for e-bus cybersecurity, requiring vendors to obtain certification from an accredited organization before being eligible for procurement
- **Procurement Security Requirements:** Establish a pre-qualification process for e-bus vendors, requiring them to demonstrate compliance with cybersecurity standards before being eligible to bid on contracts
- **Control System Hardening:** Develop a secure boot process for control systems, ensuring that only verified and trusted firmware can be loaded and executed.
