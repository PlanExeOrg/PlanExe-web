# Purpose
# Securing Public Transportation E-Buses

- Mitigating cybersecurity risks in public transportation infrastructure.
- Isolating critical systems from remote access.
- Establishing secure procurement practices.

## E-Bus Remote Access Vulnerabilities

- Focus on securing e-buses.


# Plan Type
This plan requires physical locations. It cannot be executed digitally.

Explanation: The plan involves physical systems (e-buses) and actions to secure them, including on-site assessment, system isolation, and procurement process changes. The goal is to physically 'air-gap' critical systems.

# Physical Locations
This plan implies one or more physical locations.

## Requirements for physical locations

- proximity to public transportation infrastructure
- space for on-site assessments and modifications
- access to local vendors and cybersecurity experts

## Location 1
Denmark, Copenhagen

Copenhagen, Denmark

Rationale: Starting point for the pilot project, essential for on-site assessments and modifications.

## Location 2
Denmark, Aarhus

Aarhus, Denmark

Rationale: Growing public transportation network and access to local cybersecurity resources.

## Location 3
Denmark, Odense

Odense, Denmark

Rationale: Strategic location with existing public transport systems and potential for collaboration with local vendors for cybersecurity solutions.

## Location Summary
Copenhagen is the primary location. Aarhus and Odense are recommended for future expansion due to public transportation infrastructure and access to cybersecurity resources.

# Currency Strategy
## Currencies

- DKK: Local currency.

Primary currency: DKK

Currency strategy: Use DKK for all transactions. No international risk management needed.

# Identify Risks
# Risk 1 - Regulatory & Permitting

- New regulations could delay implementation.
- Impact: 2-6 month delay, legal challenges, DKK 5-10 million cost increase.
- Likelihood: Medium
- Severity: Medium
- Action: Engage regulatory bodies early, establish legal review.

# Risk 2 - Technical

- 'Air-gap' solution may be ineffective or cause operational issues.
- Impact: Compromised security, service delays, DKK 2-4 million costs.
- Likelihood: Medium
- Severity: High
- Action: Test air-gap, develop contingency plans, implement monitoring.

# Risk 3 - Financial

- Budget of DKK 120M may be insufficient. 'Pioneer's Gambit' is high-risk.
- Impact: Project delays, reduced scope, potential failure, DKK 10-20 million overruns.
- Likelihood: Medium
- Severity: High
- Action: Develop cost breakdown, explore funding, monitor spending.

# Risk 4 - Supply Chain

- Reliance on limited vendors, especially Chinese, creates vulnerabilities.
- Impact: Compromised security, procurement delays, reputational damage, DKK 3-7 million losses.
- Likelihood: Medium
- Severity: High
- Action: Diversify vendors, implement supply chain security, establish contracts.

# Risk 5 - Operational

- Security measures could disrupt operations.
- Impact: Service disruptions, passenger dissatisfaction, DKK 1-3 million costs.
- Likelihood: Medium
- Severity: Medium
- Action: Plan implementation, communicate with passengers, develop contingency plans.

# Risk 6 - Security

- Security measures may not be effective against cyberattacks.
- Impact: Compromised security, data breaches, service disruption, DKK 5-10 million losses.
- Likelihood: Medium
- Severity: High
- Action: Conduct penetration testing, implement monitoring, stay informed.

# Risk 7 - Social

- Public perception could be negative.
- Impact: Public opposition, reputational damage, legal challenges.
- Likelihood: Low
- Severity: Medium
- Action: Communicate transparently, address privacy concerns.

# Risk 8 - Technical

- Ban on blockchain/AI/quantum technologies may limit solutions.
- Impact: Missed opportunities, outdated solutions, DKK 2-5 million upgrade costs.
- Likelihood: Low
- Severity: Medium
- Action: Re-evaluate ban, stay informed about advancements.

# Risk 9 - Integration

- Integrating new measures with existing systems may be challenging.
- Impact: Implementation delays, compatibility issues, DKK 3-6 million costs.
- Likelihood: Medium
- Severity: Medium
- Action: Assess systems, develop integration plans, work with vendors.

# Risk 10 - Environmental

- Modifications could impact energy efficiency or emissions.
- Impact: Increased consumption, higher emissions, non-compliance, DKK 1-3 million fines.
- Likelihood: Low
- Severity: Medium
- Action: Assess impact, ensure compliance, consider alternatives.

# Risk summary

- Cybersecurity risks exist due to remote exploitation of e-buses.
- Critical risks: Ineffective 'air-gap', supply chain vulnerabilities, budget overruns.
- Mitigation: Testing, vendor diversification, cost management.
- 'Pioneer's Gambit' requires monitoring.
- Trade-off between security and operational functionality.


# Make Assumptions
# Question 1 - Budget Breakdown (DKK 120M)

- Assumption: National rollout (DKK 72M), Copenhagen pilot (DKK 24M), personnel (DKK 12M), technology (DKK 6M), contingency (DKK 6M).

## Assessments: Financial Feasibility

- Description: Evaluate budget adequacy.
- Details: Breakdown seems reasonable, but needs detailed cost analysis.
- Risks: Underestimation of costs, overruns.
- Mitigation: Cost tracking, value engineering, secure funding.
- Opportunity: Efficient resource allocation for expansion.

# Question 2 - Milestones (90-day Pilot, 9-month Rollout)

- Assumption: Pilot: system assessment (30 days), isolation (30 days), testing (30 days). Rollout: vendor selection (2 months), deployment (4 months), attestation (3 months).

## Assessments: Timeline Risk

- Description: Analyze timeline feasibility.
- Details: Timeline is aggressive.
- Risks: Delays in vendor selection, technical issues, regulatory hurdles.
- Mitigation: Proactive planning, parallel processing, monitoring.
- Opportunity: Streamlining processes can accelerate timeline.

# Question 3 - Roles and Expertise

- Assumption: Cybersecurity experts, engineers, administrators, project managers, legal counsel. Pilot (5-7), Rollout (15-20).

## Assessments: Resource Allocation

- Description: Evaluate human resources.
- Details: Availability of cybersecurity professionals is a constraint.
- Risks: Recruiting, skill gaps, burnout.
- Mitigation: Compensation, training, partnerships.
- Opportunity: Developing internal expertise.

# Question 4 - Regulatory Compliance

- Assumption: Danish Transport Authority, Data Protection Agency, ENISA. Compliance via legal review, best practices, audits.

## Assessments: Regulatory Compliance

- Description: Analyze adherence to regulations.
- Details: Non-compliance leads to fines.
- Risks: Evolving regulations, misinterpretation, inadequate documentation.
- Mitigation: Engage with bodies, legal review, compliance records.
- Opportunity: Enhancing public trust.

# Question 5 - Safety Protocols

- Assumption: Lockout/tagout, electrical safety training, PPE, manufacturer guidelines. Hazard identification, risk assessment, control measures.

## Assessments: Safety and Risk Management

- Description: Evaluate safety protocols.
- Details: Accidents lead to injuries.
- Risks: Electrical hazards, failures, human error.
- Mitigation: Training, inspections, adherence to protocols.
- Opportunity: Improving employee morale.

# Question 6 - Environmental Impact

- Assumption: Focus on energy, emissions, waste. Optimize energy, use friendly materials, dispose of waste properly.

## Assessments: Environmental Impact

- Description: Analyze environmental impact.
- Details: Modifications affect efficiency.
- Risks: Increased consumption, emissions, non-compliance.
- Mitigation: Energy-efficient components, system configurations, waste protocols.
- Opportunity: Enhancing environmental credentials.

# Question 7 - Stakeholder Involvement

- Assumption: Meetings with operators, public forums, online surveys. Communication channel for concerns.

## Assessments: Stakeholder Engagement

- Description: Evaluate engagement strategy.
- Details: Lack of support leads to delays.
- Risks: Miscommunication, conflicting interests, failure to address concerns.
- Mitigation: Communication, transparent decisions, listening.
- Opportunity: Enhancing project acceptance.

# Question 8 - Monitoring and Maintenance

- Assumption: System checks, anomaly detection, security audits. Inspections, software updates, hardware replacements. Redundant systems, manual overrides, emergency procedures.

## Assessments: Operational Systems

- Description: Analyze operational systems.
- Details: Specialized procedures needed.
- Risks: System failures, security breaches, inefficiencies.
- Mitigation: Monitoring tools, maintenance schedules, fallback plans.
- Opportunity: Improving system reliability.


# Distill Assumptions
# Project Plan

## Budget

- National rollout: DKK 72M
- Copenhagen pilot: DKK 24M

## Timeline

- Copenhagen pilot: 30 days each for assessment, implementation, validation.
- National rollout: 2 months vendor selection, 4 months deployment, 3 months attestation.

## Team

- Pilot team: 5-7 experts
- Rollout team: 15-20 (deployment specialists included)

## Compliance

- Legal review
- ISO 27001
- Audits with Danish/EU regulatory bodies

## Safety

- Lockout/tagout
- PPE
- Electrical safety training
- Manufacturer guidelines

## Environmental Impact

- Optimize energy
- Use green materials
- Proper e-waste disposal

## Stakeholder Involvement

- Meetings
- Forums
- Surveys
- Dedicated communication channels

## Monitoring and Fallback

- System checks
- Anomaly detection
- Security audits
- Fallback: Redundancy, overrides


# Review Assumptions
# Domain of the expert reviewer
Cybersecurity and Project Management with a focus on Risk Assessment

## Domain-specific considerations

- Critical infrastructure protection
- Supply chain security
- Operational technology (OT) security
- Regulatory compliance (GDPR, NIS Directive)
- Vendor risk management
- Incident response planning

## Issue 1 - Unrealistic Timeline for National Rollout
The 9-month national rollout (vendor selection, system deployment, security attestation) is optimistic. Vendor selection is lengthy with security requirements. System deployment across a national network has logistical/technical challenges. Security attestation ('red team/blue team') requires planning, execution, and remediation time. The timeline risks cutting security corners or delays.

Recommendation: Extend the timeline to 18-24 months. Detail task breakdown/resource allocation. Phase rollout, starting small. Establish communication with vendors/stakeholders. Consider external consultants.

Sensitivity: A 9-15 month delay could increase costs by 10-20% (DKK 12-24 million). ROI could be delayed.

## Issue 2 - Insufficient Budget Contingency
The 5% (DKK 6M) contingency is inadequate given the 'Pioneer's Gambit' risk and potential technical challenges, regulatory changes, or supply chain disruptions. The project involves novel security, complex integration, and vendors, introducing uncertainty. A larger contingency is essential.

Recommendation: Increase contingency to 15% (DKK 18M). Conduct risk assessment to identify cost drivers. Establish a process for accessing/managing the fund. Explore cost reduction.

Sensitivity: Exhausted contingency could cause delays, scope reductions, or cancellation. A 10% cost increase without contingency could reduce ROI by 3-5% or delay completion by 6-12 months.

## Issue 3 - Lack of Active Threat Intelligence Gathering
The plan focuses on reactive measures (firmware audits/patching) but lacks proactive threat intelligence. Without it, the project may be blindsided by threats specific to e-bus systems/components, rendering security ineffective.

Recommendation: Establish a threat intelligence program to monitor cyber threats relevant to e-bus systems/supply chain. Subscribe to feeds, participate in information sharing, and conduct threat hunting. Integrate intelligence into monitoring/response. Allocate resources for analysts/tools.

Sensitivity: Failure to address threats could result in a cyberattack, leading to service disruptions, data breaches, and financial losses. An attack could cost 5-10% of the budget (DKK 6-12 million) in response/remediation. ROI could be reduced by 10-15%.

## Review conclusion
The plan commits to cybersecurity, but the timeline, contingency, and threat intelligence pose risks. Addressing these issues will improve the project's success.