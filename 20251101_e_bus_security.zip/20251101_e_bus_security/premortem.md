A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The hardware-based air gap solution will not introduce new vulnerabilities or compatibility issues. | Conduct penetration testing on the air-gapped system in a controlled environment. | Discovery of exploitable vulnerabilities in the air-gapped system itself or significant compatibility issues with existing e-bus systems. |
| A2 | Vendors will fully cooperate in providing necessary information and access for security audits. | Request detailed security documentation and access to vendor systems for a sample audit. | Vendor refusal to provide requested information or access, or significant delays in providing it. |
| A3 | The threat intelligence feeds will provide accurate, timely, and relevant information about emerging cyber threats targeting e-bus systems. | Compare multiple threat intelligence feeds against known vulnerabilities in e-bus systems and assess their accuracy and timeliness. | Significant discrepancies between feeds, outdated information, or lack of coverage for known e-bus vulnerabilities. |
| A4 | E-bus operators will readily adopt and consistently adhere to the new security protocols and procedures outlined in the rollback playbook. | Conduct a pilot training session with a representative group of e-bus operators and assess their understanding and acceptance of the new protocols. | Significant resistance to the new protocols, low scores on knowledge assessments, or reluctance to follow procedures during simulated drills. |
| A5 | The existing e-bus infrastructure (charging stations, maintenance facilities, network connectivity) can adequately support the implementation of the air-gap solution without requiring significant and costly modifications. | Conduct a detailed site survey of a representative sample of e-bus charging stations and maintenance facilities to assess their compatibility with the air-gap hardware and network architecture. | Significant infrastructure limitations identified, such as insufficient power capacity, inadequate space for hardware installation, or lack of network connectivity for monitoring and management. |
| A6 | The Danish public will generally support the project's security measures, even if they result in minor service disruptions or inconveniences. | Conduct a public opinion survey to gauge public perception of the project and their willingness to accept potential service disruptions in exchange for enhanced security. | Widespread public opposition to the project, negative media coverage, or significant concerns about privacy or convenience. |
| A7 | The project team possesses sufficient expertise and experience in all relevant areas (cybersecurity, e-bus systems, procurement, project management) to successfully execute the project within the given timeline and budget. | Conduct a skills gap analysis of the project team and assess their experience in similar projects. | Significant skills gaps identified, lack of experience in relevant areas, or insufficient capacity to handle the project's workload. |
| A8 | The selected air-gap solution will not negatively impact the energy efficiency or environmental performance of the e-buses. | Measure the energy consumption and emissions of e-buses before and after the installation of the air-gap solution. | Significant increase in energy consumption or emissions after the air-gap installation, exceeding acceptable thresholds or violating environmental regulations. |
| A9 | There are no hidden or undocumented functionalities (e.g., backdoors, remote access tools) in the existing e-bus systems that could compromise the effectiveness of the security measures. | Conduct a thorough forensic analysis of the e-bus firmware and software to identify any hidden or undocumented functionalities. | Discovery of hidden functionalities that could bypass security controls or provide unauthorized access to critical systems. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Paper Tiger Procurement | Process/Financial | A2 | Procurement Security Specialist | CRITICAL (16/25) |
| FM2 | The Air Gap Backfire | Technical/Logistical | A1 | Head of Engineering | CRITICAL (15/25) |
| FM3 | The Blind Spot Breach | Market/Human | A3 | Cybersecurity Team Lead | CRITICAL (15/25) |
| FM4 | The Human Firewall Failure | Process/Financial | A4 | Training and Simulation Coordinator | CRITICAL (16/25) |
| FM5 | The Infrastructure Bottleneck | Technical/Logistical | A5 | E-Bus Systems Engineer | CRITICAL (15/25) |
| FM6 | The Public Backlash | Market/Human | A6 | Public Relations/Communications Role | CRITICAL (15/25) |
| FM7 | The Expertise Erosion | Process/Financial | A7 | Project Manager | CRITICAL (16/25) |
| FM8 | The Greenwashing Paradox | Technical/Logistical | A8 | Environmental Compliance Officer | CRITICAL (15/25) |
| FM9 | The Trojan Horse | Market/Human | A9 | Cybersecurity Team Lead | CRITICAL (15/25) |


### Failure Modes

#### FM1 - The Paper Tiger Procurement

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: Procurement Security Specialist
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project's procurement security requirements are rendered toothless because vendors, particularly the dominant Chinese manufacturer Yutong, refuse to fully cooperate with security audits. This stems from a cultural reluctance to disclose proprietary information and a belief that existing certifications are sufficient. The project team, under pressure to meet deadlines and avoid alienating a key vendor, accepts incomplete documentation and relies on superficial assessments. This leads to the procurement of e-buses with hidden vulnerabilities and a false sense of security. When a zero-day exploit targeting these vulnerabilities is discovered, the entire fleet is at risk, and the cost of remediation skyrockets due to the lack of vendor support and the need for extensive in-house analysis.

##### Early Warning Signs
- Vendor audit requests are repeatedly delayed or met with resistance.
- Security documentation provided by vendors is incomplete or lacks detail.
- Vendor representatives are evasive or unwilling to answer specific security questions.

##### Tripwires
- Vendor audit completion rate <= 75%
- Vendor security documentation completeness score <= 60%
- Vendor response time to security inquiries >= 10 days

##### Response Playbook
- Contain: Immediately halt procurement from non-compliant vendors.
- Assess: Conduct an independent security assessment of the vendor's systems and documentation.
- Respond: Engage legal counsel to enforce contractual obligations or seek alternative vendors.


**STOP RULE:** If key vendors refuse to provide necessary security information, rendering 'no-remote-kill' verification impossible, cancel the project or pivot to alternative e-bus models.

---

#### FM2 - The Air Gap Backfire

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A1
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's reliance on a hardware-based air gap solution backfires spectacularly. The chosen air gap device, intended to isolate critical e-bus systems, introduces a new set of vulnerabilities. A firmware flaw in the device allows attackers to bypass the air gap and gain access to the supposedly protected systems. This flaw goes undetected during initial testing due to insufficient penetration testing and a lack of understanding of the device's internal architecture. Furthermore, the air gap solution proves to be incompatible with existing diagnostic tools, hindering maintenance and troubleshooting. When a cyberattack exploits the firmware flaw, the entire e-bus fleet is compromised, leading to widespread service disruptions and potential safety hazards. The project team is forced to scramble to develop a patch for the air gap device, further delaying the rollout and eroding public trust.

##### Early Warning Signs
- Penetration testing of the air-gapped system reveals unexpected network connections.
- Diagnostic tools fail to function correctly after the air gap device is installed.
- The air gap device vendor releases a security advisory about a critical firmware vulnerability.

##### Tripwires
- Successful penetration test of air-gapped system = TRUE
- Diagnostic tool failure rate >= 20%
- Air gap device firmware vulnerability severity score >= 7

##### Response Playbook
- Contain: Immediately isolate all affected e-buses from the network.
- Assess: Conduct a thorough forensic analysis to determine the extent of the compromise.
- Respond: Develop and deploy a patch for the air gap device firmware or replace the device with a more secure alternative.


**STOP RULE:** If the air gap solution itself is found to be fundamentally insecure and cannot be patched effectively, abandon the air-gapping strategy and pivot to alternative security measures.

---

#### FM3 - The Blind Spot Breach

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Cybersecurity Team Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's threat intelligence program fails to provide adequate warning of a sophisticated cyberattack targeting a specific vulnerability in the e-bus braking system. The threat intelligence feeds used by the project team are either outdated, incomplete, or irrelevant to the specific threats facing the e-bus fleet. This is compounded by a lack of internal expertise in threat analysis and a failure to integrate threat intelligence data effectively into security measures. As a result, the project team is blindsided by the attack, which exploits the braking system vulnerability to cause a series of accidents. Public trust in the safety of e-buses plummets, ridership declines, and the project faces intense scrutiny from regulators and the media. The cost of responding to the accidents, compensating victims, and restoring public confidence far exceeds the project's initial budget.

##### Early Warning Signs
- Threat intelligence feeds consistently fail to identify known vulnerabilities in e-bus systems.
- Security analysts report difficulty in correlating threat intelligence data with internal security logs.
- The project team is unaware of recent cyberattacks targeting similar transportation systems in other countries.

##### Tripwires
- Threat intelligence feed coverage of e-bus vulnerabilities <= 50%
- Correlation rate between threat intelligence data and security logs <= 60%
- Number of unreported cyberattacks on similar systems >= 3

##### Response Playbook
- Contain: Immediately ground all e-buses with the vulnerable braking system.
- Assess: Conduct a thorough investigation to determine the source and extent of the attack.
- Respond: Implement a patch for the braking system vulnerability and enhance threat intelligence gathering capabilities.


**STOP RULE:** If the threat intelligence program consistently fails to provide timely and accurate information about emerging cyber threats, and the risk of successful cyberattacks remains unacceptably high, cancel the project and reassess the overall security strategy.

---

#### FM4 - The Human Firewall Failure

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Training and Simulation Coordinator
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
Despite the implementation of a robust air-gapping solution and stringent security protocols, a critical vulnerability remains: human error. E-bus operators, overwhelmed by the complexity of the new security procedures and lacking adequate training, frequently bypass security protocols in the name of efficiency. They share passwords, disable multi-factor authentication, and fail to follow the rollback playbook during simulated incidents. This leads to a gradual erosion of the security posture, creating opportunities for attackers to exploit human weaknesses. When a targeted phishing campaign compromises an operator's credentials, the attacker gains access to critical systems, bypassing the technical safeguards and causing widespread disruption. The cost of remediation is compounded by legal liabilities and reputational damage.

##### Early Warning Signs
- Operators frequently request password resets or report issues with multi-factor authentication.
- Operators are observed bypassing security protocols during routine tasks.
- Simulated phishing campaigns have a high success rate among e-bus operators.

##### Tripwires
- Operator compliance with security protocols <= 70%
- Phishing simulation success rate >= 30%
- Number of password reset requests per operator per month >= 2

##### Response Playbook
- Contain: Immediately reinforce security training for all e-bus operators.
- Assess: Conduct a thorough review of operator workflows and identify areas where security protocols are overly burdensome.
- Respond: Simplify security procedures, provide additional support, and implement stricter enforcement measures.


**STOP RULE:** If operator non-compliance with security protocols persists despite repeated training and support, and the risk of human error remains unacceptably high, consider implementing more automated security measures or re-evaluating the air-gapping strategy.

---

#### FM5 - The Infrastructure Bottleneck

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: E-Bus Systems Engineer
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's air-gapping solution encounters unforeseen logistical challenges due to limitations in the existing e-bus infrastructure. Charging stations lack sufficient power capacity to support the additional hardware required for the air gap, leading to delays in charging and reduced operational efficiency. Maintenance facilities are not equipped to handle the specialized maintenance requirements of the air-gapped systems, resulting in increased downtime and higher maintenance costs. Network connectivity for monitoring and management is inadequate, hindering the ability to detect and respond to security incidents. These infrastructure bottlenecks significantly increase the project's costs and timeline, jeopardizing its overall feasibility.

##### Early Warning Signs
- Charging times for e-buses increase significantly after the air-gap hardware is installed.
- Maintenance facilities report difficulty in servicing the air-gapped systems.
- Network monitoring tools report intermittent connectivity issues with the air-gapped systems.

##### Tripwires
- E-bus charging times increase by >= 20%
- Maintenance downtime for air-gapped systems increases by >= 30%
- Network connectivity uptime for air-gapped systems <= 80%

##### Response Playbook
- Contain: Immediately assess the infrastructure limitations and develop mitigation strategies.
- Assess: Conduct a detailed cost-benefit analysis of upgrading the infrastructure versus alternative security solutions.
- Respond: Secure additional funding to upgrade the infrastructure or explore alternative security measures that are less demanding on existing resources.


**STOP RULE:** If the infrastructure limitations prove insurmountable and the cost of upgrading the infrastructure exceeds a predefined threshold (e.g., 20% of the total project budget), abandon the air-gapping strategy and pivot to alternative security measures.

---

#### FM6 - The Public Backlash

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Public Relations/Communications Role
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's security measures, intended to protect e-buses from cyberattacks, trigger a public backlash due to perceived inconveniences and privacy concerns. Passengers complain about increased security checks, longer boarding times, and the collection of personal data for security monitoring. Privacy advocates raise concerns about the potential for misuse of this data. Negative media coverage fuels public opposition, leading to protests and calls for the project to be scrapped. Politicians, sensitive to public opinion, withdraw their support, jeopardizing the project's funding and future. The project team is forced to scale back the security measures, compromising the overall security posture and undermining the project's goals.

##### Early Warning Signs
- Public opinion surveys show declining support for the project.
- Social media sentiment analysis reveals a growing number of negative comments about the security measures.
- Privacy advocacy groups file complaints with regulatory agencies.

##### Tripwires
- Public support for the project <= 50%
- Negative sentiment on social media >= 60%
- Number of complaints filed with regulatory agencies >= 10

##### Response Playbook
- Contain: Immediately launch a public awareness campaign to address public concerns and highlight the benefits of the security measures.
- Assess: Conduct a thorough review of the security measures to identify areas where privacy and convenience can be improved.
- Respond: Modify the security measures to address public concerns, enhance transparency, and provide stronger privacy protections.


**STOP RULE:** If public opposition to the project remains widespread despite efforts to address their concerns, and the project's legitimacy is seriously undermined, cancel the project or significantly revise the security strategy to prioritize public acceptance.

---

#### FM7 - The Expertise Erosion

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Project Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project suffers from a critical lack of expertise within the project team. Key personnel, particularly in cybersecurity and e-bus systems engineering, lack the necessary experience to effectively implement the air-gapping solution and manage the complex security protocols. This leads to a series of costly mistakes, including the selection of an incompatible air-gap device, the misconfiguration of security settings, and the failure to identify critical vulnerabilities. The project spirals out of control as the team struggles to overcome these challenges, leading to significant budget overruns, timeline delays, and a compromised security posture. The lack of expertise also hinders effective communication with vendors and stakeholders, further exacerbating the problems.

##### Early Warning Signs
- Frequent requests for external consultants and advisors.
- Inability to resolve technical issues without external assistance.
- Poor communication and coordination between team members.
- Lack of clear understanding of project goals and objectives.

##### Tripwires
- Reliance on external consultants exceeds 40% of project hours.
- Number of unresolved technical issues per month >= 5.
- Project budget variance >= 10%.

##### Response Playbook
- Contain: Immediately assess the skills and experience of the project team and identify critical gaps.
- Assess: Develop a plan to address the skills gaps, including training, mentoring, and recruitment of experienced personnel.
- Respond: Secure additional funding for training and recruitment or consider outsourcing key tasks to external experts.


**STOP RULE:** If the project team consistently fails to demonstrate the necessary expertise to effectively manage the project, and the cost of addressing the skills gaps exceeds a predefined threshold (e.g., 15% of the total project budget), cancel the project or significantly revise the scope to align with the team's capabilities.

---

#### FM8 - The Greenwashing Paradox

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Environmental Compliance Officer
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's air-gapping solution, intended to enhance cybersecurity, inadvertently compromises the energy efficiency and environmental performance of the e-buses. The additional hardware required for the air gap increases the weight of the buses, leading to higher energy consumption and increased emissions. The air-gapping solution also interferes with the e-bus's energy management system, further reducing its efficiency. This creates a public relations nightmare as the project, intended to promote sustainable transportation, is now seen as contributing to environmental degradation. The project faces intense scrutiny from environmental groups and regulators, leading to legal challenges and reputational damage. The cost of mitigating the environmental impact far exceeds the project's initial budget.

##### Early Warning Signs
- Energy consumption of e-buses increases significantly after the air-gap installation.
- Emissions from e-buses exceed acceptable thresholds.
- Negative media coverage focusing on the environmental impact of the project.

##### Tripwires
- Energy consumption of e-buses increases by >= 15%
- Emissions from e-buses exceed regulatory limits by >= 10%
- Number of negative media articles per month >= 5.

##### Response Playbook
- Contain: Immediately assess the environmental impact of the air-gapping solution and develop mitigation strategies.
- Assess: Conduct a detailed cost-benefit analysis of alternative air-gapping solutions or alternative security measures that are less demanding on energy efficiency.
- Respond: Secure additional funding to implement energy-efficient air-gapping solutions or explore alternative security measures that minimize environmental impact.


**STOP RULE:** If the air-gapping solution consistently fails to meet environmental standards, and the cost of mitigating the environmental impact exceeds a predefined threshold (e.g., 10% of the total project budget), abandon the air-gapping strategy and pivot to alternative security measures.

---

#### FM9 - The Trojan Horse

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Cybersecurity Team Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Despite the implementation of robust security measures, the project is undermined by a hidden backdoor in the existing e-bus systems. This backdoor, intentionally planted by the manufacturer or a malicious third party, allows attackers to bypass all security controls and gain complete control of the e-bus fleet. The project team, unaware of the backdoor's existence, focuses on external threats and neglects to thoroughly analyze the internal workings of the e-bus systems. When the backdoor is exploited, the entire fleet is compromised, leading to widespread disruption, data breaches, and potential safety hazards. Public trust in the safety and security of e-buses is shattered, and the project is deemed a complete failure. The cost of recovering from the attack and restoring public confidence is astronomical.

##### Early Warning Signs
- Unexplained network activity originating from e-bus systems.
- Security logs show evidence of unauthorized access to critical systems.
- Security analysts report difficulty in understanding the internal workings of the e-bus firmware and software.

##### Tripwires
- Unexplained network traffic volume from e-buses >= 10%
- Number of unauthorized access attempts per month >= 3
- Security analyst time spent on reverse engineering e-bus systems >= 50%

##### Response Playbook
- Contain: Immediately isolate all e-buses from the network and conduct a thorough forensic analysis to identify the backdoor.
- Assess: Determine the scope of the compromise and the potential impact on public safety and data privacy.
- Respond: Develop and deploy a patch to remove the backdoor and implement enhanced security monitoring to detect future intrusions.


**STOP RULE:** If a hidden backdoor is discovered in the e-bus systems, and the manufacturer is unwilling or unable to provide a reliable patch, cancel the project and replace the e-bus fleet with systems from a more trustworthy vendor.
