### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and direction for the project, ensuring alignment with organizational goals and objectives, given the project's high-profile nature and potential impact on public transportation infrastructure.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic guidance and direction.
- Monitor project progress against key milestones.
- Approve major changes to project scope, budget, or timeline (above DKK 5M).
- Oversee risk management and mitigation strategies.
- Resolve high-level conflicts and escalate issues as needed.
- Approve vendor selection for contracts exceeding DKK 10M.
- Review and approve the cybersecurity attestation standard.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define escalation procedures.
- Approve initial project plan.

**Membership:**

- Senior Management Representative (Chair)
- Head of Public Transportation
- Chief Information Security Officer (CISO)
- Chief Financial Officer (CFO)
- Independent Cybersecurity Expert (External)

**Decision Rights:** Strategic decisions related to project scope, budget, timeline, and major risks. Approval of changes exceeding DKK 5M or impacting project timeline by more than 1 month.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Senior Management Representative (Chair) has the deciding vote. Dissenting opinions are documented in meeting minutes.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of project progress against milestones.
- Discussion of key risks and mitigation strategies.
- Approval of change requests.
- Review of financial performance.
- Updates from the Technical Advisory Group.
- Vendor selection updates (contracts > DKK 10M).

**Escalation Path:** To the CEO or equivalent senior executive.
### 2. Core Project Team

**Rationale for Inclusion:** Manages the day-to-day execution of the project, ensuring tasks are completed on time and within budget.  Essential for operational efficiency and effective communication across project workstreams.

**Responsibilities:**

- Develop and maintain project plans.
- Manage project budget and resources.
- Track project progress and report on status.
- Identify and manage project risks and issues.
- Coordinate project activities across different teams.
- Implement the cybersecurity attestation standard.
- Develop and execute the operator rollback playbook.
- Manage vendor relationships (contracts below DKK 10M).
- Ensure compliance with regulatory requirements.

**Initial Setup Actions:**

- Define roles and responsibilities.
- Establish communication protocols.
- Set up project management tools.
- Develop detailed project schedule.
- Establish risk management framework.

**Membership:**

- Project Manager (Chair)
- Lead Cybersecurity Engineer
- Procurement Manager
- Operations Manager
- Compliance Officer

**Decision Rights:** Operational decisions related to project execution, resource allocation (within approved budget), and risk management (below strategic thresholds).

**Decision Mechanism:** Decisions made by the Project Manager in consultation with team members. Disagreements are escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against schedule.
- Discussion of current risks and issues.
- Action item tracking.
- Budget updates.
- Vendor performance updates (contracts < DKK 10M).
- Compliance updates.

**Escalation Path:** To the Project Steering Committee.
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and guidance on cybersecurity aspects of the project, ensuring the implementation of robust security measures and compliance with industry best practices. Given the technical complexity of air-gapping and securing e-bus systems, this group is crucial.

**Responsibilities:**

- Provide technical expertise on cybersecurity issues.
- Review and approve technical designs and specifications.
- Evaluate the effectiveness of security measures.
- Conduct penetration testing and vulnerability assessments.
- Advise on the selection of cybersecurity technologies and vendors.
- Develop and maintain the cybersecurity attestation standard.
- Review and approve the operator rollback playbook.
- Advise on control system hardening strategies.

**Initial Setup Actions:**

- Define scope of technical expertise.
- Establish communication channels with the Core Project Team.
- Develop technical review process.
- Identify key technical risks.

**Membership:**

- Lead Cybersecurity Engineer (Chair)
- Senior Network Architect
- Security Operations Center (SOC) Manager
- Independent Cybersecurity Consultant (External)
- E-Bus System Engineer

**Decision Rights:** Technical decisions related to cybersecurity architecture, technology selection, and security testing. Recommendations on technical risks and mitigation strategies.

**Decision Mechanism:** Decisions made by consensus. In case of disagreement, the Lead Cybersecurity Engineer (Chair) makes the final decision, documenting dissenting opinions.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of technical designs and specifications.
- Discussion of security vulnerabilities and mitigation strategies.
- Penetration testing results.
- Technology updates.
- Review of incident response plans.
- Updates on threat intelligence.

**Escalation Path:** To the Project Steering Committee.
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures the project adheres to ethical standards, regulatory requirements (GDPR, NIS Directive, ISO 27001), and anti-corruption policies. Given the public nature of the project and the potential for conflicts of interest, this committee is essential for maintaining transparency and accountability.

**Responsibilities:**

- Oversee compliance with GDPR, NIS Directive, and ISO 27001.
- Review and approve procurement processes to ensure fairness and transparency.
- Investigate allegations of fraud, corruption, or ethical violations.
- Develop and implement anti-corruption policies and procedures.
- Ensure data privacy and security.
- Monitor vendor compliance with ethical standards.
- Review and approve data anonymization standards.
- Oversee the whistleblower mechanism.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish reporting procedures.
- Develop compliance checklist.
- Establish whistleblower hotline.

**Membership:**

- Compliance Officer (Chair)
- Legal Counsel
- Internal Audit Manager
- Data Protection Officer
- Independent Ethics Advisor (External)

**Decision Rights:** Decisions related to ethical conduct, regulatory compliance, and anti-corruption measures. Authority to investigate allegations of misconduct and recommend disciplinary action.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Compliance Officer (Chair) has the deciding vote.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of compliance with GDPR, NIS Directive, and ISO 27001.
- Discussion of ethical issues and concerns.
- Review of procurement processes.
- Investigation of alleged violations.
- Updates on regulatory changes.
- Review of data privacy policies.

**Escalation Path:** To the CEO or equivalent senior executive.