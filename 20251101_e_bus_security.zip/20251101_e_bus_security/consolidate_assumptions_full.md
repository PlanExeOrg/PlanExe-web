# Purpose

**Purpose:** business

**Purpose Detailed:** Mitigating cybersecurity risks in public transportation infrastructure by isolating critical systems from remote access and establishing secure procurement practices.

**Topic:** Securing public transportation e-buses from remote access vulnerabilities

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** This plan *explicitly* involves physical systems (e-buses) and requires physical actions to secure them. It includes on-site assessment, isolation of systems, and modification of procurement processes. The goal is to physically 'air-gap' critical systems. This is *inherently* a physical undertaking.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- proximity to public transportation infrastructure
- space for on-site assessments and modifications
- access to local vendors and cybersecurity experts

## Location 1
Denmark

Copenhagen

Copenhagen, Denmark

**Rationale**: Copenhagen is the starting point for the pilot project, making it essential for on-site assessments and modifications to the e-bus systems.

## Location 2
Denmark

Aarhus

Aarhus, Denmark

**Rationale**: Aarhus has a growing public transportation network and access to local cybersecurity resources, making it suitable for a secondary pilot or expansion.

## Location 3
Denmark

Odense

Odense, Denmark

**Rationale**: Odense offers a strategic location with existing public transport systems and potential for collaboration with local vendors for cybersecurity solutions.

## Location Summary
Copenhagen is the primary location for the pilot project, while Aarhus and Odense are recommended for future expansion due to their public transportation infrastructure and access to cybersecurity resources.

# Currency Strategy

This plan involves money.

## Currencies

- **DKK:** Local currency for project execution in Denmark.

**Primary currency:** DKK

**Currency strategy:** The local currency (DKK) will be used for all transactions. No additional international risk management is needed.

# Identify Risks


## Risk 1 - Regulatory & Permitting
New regulations or interpretations of existing regulations could delay or prevent the implementation of the proposed security measures. For example, regulations regarding data privacy or the modification of public transportation vehicles could pose challenges.

**Impact:** A delay of 2-6 months in project completion, potential legal challenges, and increased project costs of DKK 5-10 million due to compliance requirements.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Engage with relevant regulatory bodies early in the project to understand potential compliance requirements and proactively address any concerns. Establish a legal review process for all proposed security measures.

## Risk 2 - Technical
The 'air-gap' solution may not be fully effective, or may introduce unintended operational issues. For example, physically disconnecting systems may prevent necessary diagnostics or updates, or create unforeseen compatibility problems.

**Impact:** Compromised security despite implemented measures, operational disruptions leading to service delays, and additional costs of DKK 2-4 million for troubleshooting and redesign.

**Likelihood:** Medium

**Severity:** High

**Action:** Conduct thorough testing of the air-gap solution in a controlled environment before deployment. Develop contingency plans for operational issues that may arise. Implement robust monitoring to detect any breaches or anomalies.

## Risk 3 - Financial
The project budget of DKK 120M may be insufficient to cover all necessary security measures, especially if unforeseen technical challenges or regulatory requirements arise. The 'Pioneer's Gambit' strategy is high-risk and may lead to cost overruns.

**Impact:** Project delays due to lack of funding, reduced scope of security measures, and potential failure to achieve the project's objectives. Cost overruns of DKK 10-20 million.

**Likelihood:** Medium

**Severity:** High

**Action:** Develop a detailed cost breakdown and contingency plan. Explore alternative funding sources or prioritize security measures based on risk assessment. Regularly monitor project spending and adjust the plan as needed.

## Risk 4 - Supply Chain
Reliance on a limited number of vendors, particularly Chinese manufacturers, could create vulnerabilities in the supply chain. Component Origin Verification is only a 'medium' importance decision, which may not be sufficient. This could lead to compromised hardware or software.

**Impact:** Compromised security due to malicious hardware or software, delays in procurement, and potential reputational damage. Financial losses of DKK 3-7 million.

**Likelihood:** Medium

**Severity:** High

**Action:** Diversify the vendor base and implement rigorous supply chain security measures, including component origin verification and security audits. Establish strong contractual agreements with vendors that include security requirements and penalties for non-compliance.

## Risk 5 - Operational
The implementation of security measures could disrupt public transportation operations, leading to service delays and inconvenience for passengers. For example, the 'air-gap' solution may require manual intervention for routine tasks.

**Impact:** Service disruptions, passenger dissatisfaction, and potential reputational damage. Increased operational costs of DKK 1-3 million due to manual processes.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Carefully plan and coordinate the implementation of security measures to minimize disruptions. Communicate proactively with passengers about potential delays. Develop contingency plans for operational issues that may arise.

## Risk 6 - Security
The implemented security measures may not be effective against sophisticated cyberattacks. The 'Pioneer's Gambit' strategy, while aggressive, may not anticipate all potential attack vectors.

**Impact:** Compromised security, data breaches, and potential disruption of public transportation services. Financial losses of DKK 5-10 million due to incident response and remediation.

**Likelihood:** Medium

**Severity:** High

**Action:** Conduct regular penetration testing and vulnerability assessments to identify weaknesses in the security measures. Implement robust monitoring and incident response procedures. Stay informed about emerging cyber threats and adapt the security measures as needed.

## Risk 7 - Social
Public perception of the security measures could be negative if they are seen as intrusive or inconvenient. For example, increased security checks or surveillance could raise privacy concerns.

**Impact:** Public opposition to the project, reputational damage, and potential legal challenges. Reduced public trust in the public transportation system.

**Likelihood:** Low

**Severity:** Medium

**Action:** Communicate transparently with the public about the security measures and their benefits. Address any privacy concerns and ensure that the measures are implemented in a way that minimizes inconvenience.

## Risk 8 - Technical
The project bans the use of blockchain/AI/quantum technologies. This may limit the ability to leverage potentially useful security solutions, especially in the long term.

**Impact:** Missed opportunities to enhance security, potential for the implemented solutions to become outdated more quickly, and increased costs in the long run due to the need for future upgrades. Increased costs of DKK 2-5 million for future upgrades.

**Likelihood:** Low

**Severity:** Medium

**Action:** Regularly re-evaluate the ban on blockchain/AI/quantum technologies to determine if they can be safely and effectively incorporated into the security measures. Stay informed about advancements in these technologies and their potential applications in cybersecurity.

## Risk 9 - Integration
Integrating new security measures with existing e-bus systems and infrastructure may be challenging, especially given the variety of bus models and manufacturers. The Vendor Diversity Initiative may exacerbate this issue.

**Impact:** Delays in project implementation, compatibility issues, and increased costs for customization and integration. Increased costs of DKK 3-6 million for customization and integration.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Conduct thorough assessments of the existing e-bus systems and infrastructure before implementing new security measures. Develop detailed integration plans and test them in a controlled environment. Work closely with vendors to ensure compatibility and smooth integration.

## Risk 10 - Environmental
Modifications to the e-buses could impact their energy efficiency or emissions, potentially conflicting with environmental regulations or sustainability goals.

**Impact:** Increased energy consumption, higher emissions, and potential non-compliance with environmental regulations. Fines and penalties of DKK 1-3 million.

**Likelihood:** Low

**Severity:** Medium

**Action:** Assess the environmental impact of all proposed modifications to the e-buses. Ensure that the modifications comply with environmental regulations and do not significantly increase energy consumption or emissions. Consider alternative security measures that have a lower environmental impact.

## Risk summary
The project faces significant cybersecurity risks, primarily due to the potential for remote exploitation of Chinese-made e-buses. The most critical risks are the potential ineffectiveness of the 'air-gap' solution, the possibility of supply chain vulnerabilities, and the risk of budget overruns. Mitigation strategies should focus on thorough testing, vendor diversification, and proactive cost management. The 'Pioneer's Gambit' strategy, while ambitious, requires careful monitoring and adaptation to ensure its feasibility and effectiveness. A key trade-off is between security and operational functionality, which must be carefully balanced to avoid disrupting public transportation services.

# Make Assumptions


## Question 1 - What is the detailed breakdown of the DKK 120M budget, including allocations for the Copenhagen pilot, national rollout, personnel, technology, and contingency?

**Assumptions:** Assumption: 60% of the budget (DKK 72M) is allocated to the national rollout, 20% (DKK 24M) to the Copenhagen pilot, 10% (DKK 12M) to personnel, 5% (DKK 6M) to technology procurement, and 5% (DKK 6M) to contingency. This aligns with typical project budget distributions, prioritizing the larger-scale national rollout while allocating sufficient funds for the pilot and unforeseen issues.

**Assessments:** Title: Financial Feasibility Assessment
Description: Evaluation of the budget allocation's adequacy for achieving project goals.
Details: The budget breakdown appears reasonable, but a detailed cost analysis is needed to validate these allocations. Risks include underestimation of air-gapping costs, cybersecurity attestation expenses, and potential cost overruns in the national rollout. Mitigation strategies involve rigorous cost tracking, value engineering, and securing additional funding sources if necessary. Opportunity: Efficient resource allocation can lead to cost savings and potentially allow for expansion of the project's scope.

## Question 2 - What are the specific milestones for the 90-day Copenhagen pilot and the subsequent 9-month national rollout, including key deliverables and decision points?

**Assumptions:** Assumption: The Copenhagen pilot will include milestones for system assessment (30 days), isolation implementation (30 days), and testing/validation (30 days). The national rollout will have milestones for vendor selection (2 months), system deployment (4 months), and security attestation (3 months). This allows for a structured approach with clear deliverables at each stage.

**Assessments:** Title: Timeline Risk Assessment
Description: Analysis of the project timeline's feasibility and potential delays.
Details: The timeline is aggressive, especially considering the complexity of air-gapping and security attestation. Risks include delays in vendor selection, technical challenges during system deployment, and unforeseen regulatory hurdles. Mitigation strategies involve proactive planning, parallel processing of tasks, and close monitoring of progress. Opportunity: Streamlining processes and leveraging automation can accelerate the timeline and ensure timely project completion.

## Question 3 - What specific roles and expertise are required for the project team, and how will these resources be allocated between the Copenhagen pilot and the national rollout?

**Assumptions:** Assumption: The project team will include cybersecurity experts, electrical engineers, system administrators, project managers, and legal counsel. The Copenhagen pilot will require a dedicated team of 5-7 experts, while the national rollout will necessitate a larger team of 15-20, including regional deployment specialists. This ensures adequate expertise and support throughout the project lifecycle.

**Assessments:** Title: Resource Allocation Assessment
Description: Evaluation of the adequacy and allocation of human resources for the project.
Details: The availability of skilled cybersecurity professionals is a potential constraint. Risks include difficulty in recruiting and retaining qualified personnel, skill gaps within the team, and potential burnout due to workload. Mitigation strategies involve competitive compensation packages, training programs, and strategic partnerships with universities and cybersecurity firms. Opportunity: Developing internal expertise can create a sustainable cybersecurity capability within the public transportation system.

## Question 4 - Which specific regulatory bodies and standards (e.g., GDPR, NIS Directive) are relevant to this project, and how will compliance be ensured throughout the implementation?

**Assumptions:** Assumption: Relevant regulatory bodies include the Danish Transport Authority, the Danish Data Protection Agency, and the European Union Agency for Cybersecurity (ENISA). Compliance will be ensured through a dedicated legal review process, adherence to industry best practices (e.g., ISO 27001), and regular audits. This proactive approach minimizes legal and regulatory risks.

**Assessments:** Title: Regulatory Compliance Assessment
Description: Analysis of the project's adherence to relevant regulations and standards.
Details: Non-compliance with regulations can lead to significant fines, legal challenges, and reputational damage. Risks include evolving regulatory landscape, misinterpretation of regulations, and inadequate documentation. Mitigation strategies involve engaging with regulatory bodies, establishing a legal review process, and maintaining comprehensive compliance records. Opportunity: Demonstrating strong regulatory compliance can enhance public trust and improve the project's credibility.

## Question 5 - What are the specific safety protocols and risk management procedures that will be implemented during the physical air-gapping process to prevent accidents or damage to the e-buses?

**Assumptions:** Assumption: Safety protocols will include lockout/tagout procedures, electrical safety training for personnel, use of personal protective equipment (PPE), and adherence to manufacturer's safety guidelines. Risk management procedures will involve hazard identification, risk assessment, and implementation of control measures. This ensures a safe working environment and minimizes the risk of accidents.

**Assessments:** Title: Safety and Risk Management Assessment
Description: Evaluation of the project's safety protocols and risk management procedures.
Details: Accidents during the air-gapping process can lead to injuries, equipment damage, and project delays. Risks include electrical hazards, mechanical failures, and human error. Mitigation strategies involve comprehensive safety training, regular equipment inspections, and strict adherence to safety protocols. Opportunity: Implementing a robust safety culture can improve employee morale and reduce the likelihood of accidents.

## Question 6 - What measures will be taken to assess and mitigate the environmental impact of the air-gapping process, including potential changes to energy consumption or emissions?

**Assumptions:** Assumption: The environmental impact assessment will focus on energy consumption, emissions, and waste generation. Mitigation measures will include optimizing energy usage, using environmentally friendly materials, and properly disposing of electronic waste. This minimizes the project's environmental footprint.

**Assessments:** Title: Environmental Impact Assessment
Description: Analysis of the project's potential environmental impact and mitigation strategies.
Details: Modifications to e-buses can affect their energy efficiency and emissions. Risks include increased energy consumption, higher emissions, and non-compliance with environmental regulations. Mitigation strategies involve selecting energy-efficient components, optimizing system configurations, and adhering to waste management protocols. Opportunity: Implementing sustainable practices can enhance the project's environmental credentials and contribute to broader sustainability goals.

## Question 7 - How will stakeholders (e.g., bus operators, passengers, local communities) be involved in the project, and what mechanisms will be used to gather feedback and address concerns?

**Assumptions:** Assumption: Stakeholder involvement will include regular meetings with bus operators, public forums for community feedback, and online surveys to gather passenger opinions. A dedicated communication channel will be established to address concerns and provide updates. This ensures transparency and fosters public support.

**Assessments:** Title: Stakeholder Engagement Assessment
Description: Evaluation of the project's stakeholder engagement strategy.
Details: Lack of stakeholder support can lead to project delays, public opposition, and reputational damage. Risks include miscommunication, conflicting interests, and failure to address concerns. Mitigation strategies involve proactive communication, transparent decision-making, and active listening to stakeholder feedback. Opportunity: Building strong relationships with stakeholders can enhance project acceptance and create a sense of shared ownership.

## Question 8 - How will the air-gapped systems be monitored and maintained to ensure continued security and operational efficiency, and what fallback mechanisms will be in place in case of system failures?

**Assumptions:** Assumption: Monitoring will involve regular system checks, anomaly detection, and security audits. Maintenance will include scheduled inspections, software updates (via secure channels), and hardware replacements. Fallback mechanisms will include redundant systems, manual overrides, and emergency response procedures. This ensures continued security and operational resilience.

**Assessments:** Title: Operational Systems Assessment
Description: Analysis of the project's operational systems and maintenance procedures.
Details: Air-gapped systems require specialized monitoring and maintenance procedures. Risks include system failures, security breaches due to inadequate monitoring, and operational inefficiencies. Mitigation strategies involve implementing robust monitoring tools, establishing clear maintenance schedules, and developing comprehensive fallback plans. Opportunity: Optimizing operational systems can improve system reliability and reduce downtime.

# Distill Assumptions

- National rollout budget is DKK 72M, Copenhagen pilot is DKK 24M.
- Copenhagen pilot: 30 days each for assessment, implementation, and validation.
- National rollout: 2 months vendor selection, 4 months deployment, 3 months attestation.
- Pilot team: 5-7 experts; rollout team: 15-20, including deployment specialists.
- Compliance via legal review, ISO 27001, and audits with Danish/EU regulatory bodies.
- Safety: Lockout/tagout, PPE, electrical safety training, and manufacturer guidelines.
- Environmental impact: Optimize energy, use green materials, dispose of e-waste properly.
- Stakeholder involvement: Meetings, forums, surveys, and dedicated communication channels.
- Monitoring: System checks, anomaly detection, security audits; fallback: redundancy, overrides.

# Review Assumptions

## Domain of the expert reviewer
Cybersecurity and Project Management with a focus on Risk Assessment

## Domain-specific considerations

- Critical infrastructure protection
- Supply chain security
- Operational technology (OT) security
- Regulatory compliance (GDPR, NIS Directive)
- Vendor risk management
- Incident response planning

## Issue 1 - Unrealistic Timeline for National Rollout
The assumption that the national rollout, including vendor selection, system deployment, and security attestation, can be completed in just 9 months is highly optimistic. Vendor selection alone can be a lengthy process, especially with stringent security requirements. System deployment across a national public transportation network involves significant logistical and technical challenges. Security attestation, particularly with a 'red team/blue team' exercise, requires substantial time for planning, execution, and remediation. The compressed timeline increases the risk of cutting corners on security or experiencing significant delays.

**Recommendation:** Extend the national rollout timeline to at least 18-24 months. Conduct a detailed task breakdown and resource allocation exercise to identify potential bottlenecks. Implement a phased rollout approach, starting with smaller deployments to refine processes and address unforeseen issues. Establish clear communication channels with vendors and stakeholders to manage expectations and proactively address delays. Consider using external consultants to accelerate the vendor selection and security attestation processes.

**Sensitivity:** A delay in the national rollout by 9-15 months (baseline: 9 months) could increase total project costs by 10-20% (DKK 12-24 million) due to extended project management overhead, contract penalties, and potential cost escalation. The ROI could be delayed by a similar timeframe, impacting the overall financial viability of the project.

## Issue 2 - Insufficient Budget Contingency
The allocation of only 5% (DKK 6M) of the total budget for contingency is inadequate, given the high-risk nature of the 'Pioneer's Gambit' strategy and the potential for unforeseen technical challenges, regulatory changes, or supply chain disruptions. The project involves novel security measures, complex system integration, and reliance on external vendors, all of which introduce significant uncertainty. A larger contingency fund is essential to mitigate the impact of unexpected costs and ensure project success.

**Recommendation:** Increase the contingency budget to at least 15% (DKK 18M) of the total project budget. Conduct a thorough risk assessment to identify potential cost drivers and quantify their potential impact. Establish a clear process for accessing and managing the contingency fund, including approval thresholds and reporting requirements. Explore opportunities to reduce project costs through value engineering and competitive bidding.

**Sensitivity:** If the contingency fund is exhausted due to unforeseen costs, the project may face delays, scope reductions, or even cancellation. A 10% increase in project costs (baseline: DKK 120M) without adequate contingency could reduce the project's ROI by 3-5% or require securing additional funding, potentially delaying the project completion date by 6-12 months.

## Issue 3 - Lack of Active Threat Intelligence Gathering
The plan focuses on reactive security measures like firmware audits and patching, but lacks a proactive component for gathering and analyzing threat intelligence. Without active threat intelligence, the project may be blindsided by emerging threats or vulnerabilities specific to the e-bus systems or their components. This could render the implemented security measures ineffective against targeted attacks.

**Recommendation:** Establish a threat intelligence program that actively monitors and analyzes emerging cyber threats relevant to the e-bus systems and their supply chain. Subscribe to threat intelligence feeds, participate in industry information sharing groups, and conduct regular threat hunting exercises. Integrate threat intelligence into the security monitoring and incident response processes to proactively identify and mitigate potential attacks. Allocate resources for specialized threat intelligence analysts and tools.

**Sensitivity:** A failure to proactively identify and address emerging threats could result in a successful cyberattack, leading to service disruptions, data breaches, and financial losses. A successful attack could cost between 5-10% of the total project budget (DKK 6-12 million) in incident response, remediation, and reputational damage. The ROI could be reduced by 10-15% due to the costs associated with the attack and the potential loss of public trust.

## Review conclusion
The project plan demonstrates a strong commitment to cybersecurity, but the unrealistic timeline, insufficient contingency, and lack of active threat intelligence pose significant risks. Addressing these issues through a more realistic timeline, a larger contingency fund, and a proactive threat intelligence program will significantly improve the project's chances of success.