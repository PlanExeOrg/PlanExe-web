### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start

### 2. Project Manager circulates Draft SteerCo ToR v0.1 for review by Senior Management Representative, Head of Public Transportation, Chief Information Security Officer (CISO), Chief Financial Officer (CFO), and the Independent Cybersecurity Expert (External).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1 circulated for review

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager consolidates feedback on Draft SteerCo ToR and revises the document.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- SteerCo ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1 circulated for review
- Feedback from nominated members

### 4. Senior Management Representative formally approves the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** Senior Management Representative

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0

**Dependencies:**

- SteerCo ToR v0.2

### 5. Senior Management Representative formally appoints the Chair of the Project Steering Committee.

**Responsible Body/Role:** Senior Management Representative

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved SteerCo ToR v1.0

### 6. Project Manager, in consultation with the Senior Management Representative, formally confirms the membership of the Project Steering Committee (Head of Public Transportation, Chief Information Security Officer (CISO), Chief Financial Officer (CFO), Independent Cybersecurity Expert (External)).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Approved SteerCo ToR v1.0
- Appointment of Chair

### 7. Project Manager schedules the initial kick-off meeting for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Membership Confirmation Emails

### 8. Hold the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda
- Membership Confirmation Emails

### 9. Project Steering Committee approves the initial project plan.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved Project Plan

**Dependencies:**

- Hold the initial Project Steering Committee kick-off meeting.

### 10. Project Manager defines roles and responsibilities for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Roles and Responsibilities Document

**Dependencies:**

- Project Start

### 11. Project Manager establishes communication protocols for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Communication Protocols Document

**Dependencies:**

- Project Start

### 12. Project Manager sets up project management tools for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Project Management Tool Configuration

**Dependencies:**

- Project Start

### 13. Project Manager develops a detailed project schedule for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Detailed Project Schedule

**Dependencies:**

- Project Start

### 14. Project Manager establishes a risk management framework for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Risk Management Framework Document

**Dependencies:**

- Project Start

### 15. Project Manager confirms the membership of the Core Project Team (Lead Cybersecurity Engineer, Procurement Manager, Operations Manager, Compliance Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Core Project Team Membership Confirmation Emails

**Dependencies:**

- Detailed Project Schedule

### 16. Project Manager schedules the initial kick-off meeting for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Core Project Team Membership Confirmation Emails

### 17. Hold the initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda
- Core Project Team Membership Confirmation Emails

### 18. Lead Cybersecurity Engineer defines the scope of technical expertise required for the Technical Advisory Group.

**Responsible Body/Role:** Lead Cybersecurity Engineer

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Technical Advisory Group Scope of Expertise Document

**Dependencies:**

- Hold the initial Core Project Team kick-off meeting.

### 19. Lead Cybersecurity Engineer establishes communication channels between the Technical Advisory Group and the Core Project Team.

**Responsible Body/Role:** Lead Cybersecurity Engineer

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Technical Advisory Group Communication Channels Document

**Dependencies:**

- Hold the initial Core Project Team kick-off meeting.

### 20. Lead Cybersecurity Engineer develops a technical review process for the Technical Advisory Group.

**Responsible Body/Role:** Lead Cybersecurity Engineer

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Technical Advisory Group Technical Review Process Document

**Dependencies:**

- Hold the initial Core Project Team kick-off meeting.

### 21. Lead Cybersecurity Engineer identifies key technical risks for the Technical Advisory Group.

**Responsible Body/Role:** Lead Cybersecurity Engineer

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Technical Advisory Group Key Technical Risks Document

**Dependencies:**

- Hold the initial Core Project Team kick-off meeting.

### 22. Lead Cybersecurity Engineer confirms the membership of the Technical Advisory Group (Senior Network Architect, Security Operations Center (SOC) Manager, Independent Cybersecurity Consultant (External), E-Bus System Engineer).

**Responsible Body/Role:** Lead Cybersecurity Engineer

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Technical Advisory Group Membership Confirmation Emails

**Dependencies:**

- Technical Advisory Group Key Technical Risks Document

### 23. Lead Cybersecurity Engineer schedules the initial kick-off meeting for the Technical Advisory Group.

**Responsible Body/Role:** Lead Cybersecurity Engineer

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Technical Advisory Group Membership Confirmation Emails

### 24. Hold the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda
- Technical Advisory Group Membership Confirmation Emails

### 25. Compliance Officer drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Compliance Officer

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Start

### 26. Compliance Officer circulates Draft Ethics & Compliance Committee ToR v0.1 for review by Legal Counsel, Internal Audit Manager, Data Protection Officer, and Independent Ethics Advisor (External).

**Responsible Body/Role:** Compliance Officer

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1 circulated for review

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 27. Compliance Officer consolidates feedback on Draft Ethics & Compliance Committee ToR and revises the document.

**Responsible Body/Role:** Compliance Officer

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1 circulated for review
- Feedback from nominated members

### 28. Compliance Officer formally approves the Ethics & Compliance Committee Terms of Reference.

**Responsible Body/Role:** Compliance Officer

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Ethics & Compliance Committee ToR v0.2

### 29. Compliance Officer formally appoints the Chair of the Ethics & Compliance Committee.

**Responsible Body/Role:** Compliance Officer

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved Ethics & Compliance Committee ToR v1.0

### 30. Compliance Officer confirms the membership of the Ethics & Compliance Committee (Legal Counsel, Internal Audit Manager, Data Protection Officer, Independent Ethics Advisor (External)).

**Responsible Body/Role:** Compliance Officer

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Membership Confirmation Emails

**Dependencies:**

- Approved Ethics & Compliance Committee ToR v1.0
- Appointment of Chair

### 31. Compliance Officer establishes reporting procedures for the Ethics & Compliance Committee.

**Responsible Body/Role:** Compliance Officer

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Reporting Procedures Document

**Dependencies:**

- Approved Ethics & Compliance Committee ToR v1.0

### 32. Compliance Officer develops a compliance checklist for the Ethics & Compliance Committee.

**Responsible Body/Role:** Compliance Officer

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Compliance Checklist

**Dependencies:**

- Approved Ethics & Compliance Committee ToR v1.0

### 33. Compliance Officer establishes a whistleblower hotline for the Ethics & Compliance Committee.

**Responsible Body/Role:** Compliance Officer

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Whistleblower Hotline Information

**Dependencies:**

- Approved Ethics & Compliance Committee ToR v1.0

### 34. Compliance Officer schedules the initial kick-off meeting for the Ethics & Compliance Committee.

**Responsible Body/Role:** Compliance Officer

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Ethics & Compliance Committee Membership Confirmation Emails

### 35. Hold the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda
- Ethics & Compliance Committee Membership Confirmation Emails