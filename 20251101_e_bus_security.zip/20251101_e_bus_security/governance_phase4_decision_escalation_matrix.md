**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the Core Project Team's approved spending limit, requiring strategic oversight and budget reallocation approval.
Negative Consequences: Potential budget overruns, project delays, or scope reduction if not addressed.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Strategy
Rationale: The Core Project Team cannot manage the risk with existing resources or mitigation plans, requiring strategic guidance and potential resource reallocation.
Negative Consequences: Project failure, security breach, or significant operational disruption if the risk is not effectively managed.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Vendor Proposals and Final Selection
Rationale: The Core Project Team cannot agree on a vendor, requiring a higher-level decision to ensure project progress and alignment with strategic goals.
Negative Consequences: Procurement delays, potential selection of a suboptimal vendor, or project delays.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Scope Change Request
Rationale: The proposed change significantly alters the project's objectives or deliverables, requiring strategic alignment and budget adjustments.
Negative Consequences: Project scope creep, budget overruns, or failure to meet original project objectives.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation
Rationale: Requires independent review and investigation to ensure ethical conduct and compliance with regulations.
Negative Consequences: Legal penalties, reputational damage, or project disruption if ethical violations are not addressed.

**Technical Design Dispute within Technical Advisory Group**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Decision based on Expert Input
Rationale: The Technical Advisory Group cannot reach consensus on a critical technical design, requiring strategic guidance and resolution to avoid technical flaws.
Negative Consequences: Implementation of a flawed technical design, increased security vulnerabilities, or project delays.

**Vendor Contract Dispute Exceeding DKK 10M**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Negotiation Strategy Approval
Rationale: The Core Project Team cannot resolve a contractual dispute with a vendor involving a significant financial amount, requiring strategic intervention.
Negative Consequences: Legal challenges, financial losses, or project delays due to unresolved vendor issues.