**Overall Adherence: 99%**

```
IMPORTANCE_ADHERENCE_SUM = (3×5 + 4×4 + 5×5 + 5×5 + 5×5 + 5×5 + 4×5 + 5×5 + 5×5 + 5×5 + 4×5 + 4×5 + 4×5) = 286
IMPORTANCE_SUM = 3 + 4 + 5 + 5 + 5 + 5 + 4 + 5 + 5 + 5 + 4 + 4 + 4 = 58
OVERALL_ADHERENCE = IMPORTANCE_ADHERENCE_SUM / (IMPORTANCE_SUM × 5) = 286 / 290 = 99%
```

## Summary

| ID | Directive | Type | Importance | Adherence | Category |
|----|-----------|------|------------|-----------|----------|
| 1 | Denmark runs hundreds of Chinese-made e-buses (incl. Yutong). | Stated fact | 3/5 | 5/5 | Fully honored |
| 2 | Ruter showed the same class has a SIM/OTA path that gives the manufacturer digital access. | Stated fact | 4/5 | 4/5 | Fully honored |
| 3 | Sever or operator-gateway all vendor remote paths. | Requirement | 5/5 | 5/5 | Fully honored |
| 4 | Air-gap drive/brake/steer from cloud/OTA. | Requirement | 5/5 | 5/5 | Fully honored |
| 5 | Tighten procurement to require verifiable 'no-remote-kill' designs. | Requirement | 5/5 | 5/5 | Fully honored |
| 6 | Require independent cyber attestations. | Requirement | 5/5 | 5/5 | Fully honored |
| 7 | Start with Copenhagen. | Requirement | 4/5 | 5/5 | Fully honored |
| 8 | Publish an isolation/rollback playbook operators can execute in hours. | Requirement | 5/5 | 5/5 | Fully honored |
| 9 | Budget: DKK 120M. | Constraint | 5/5 | 5/5 | Fully honored |
| 10 | Timeline: 12 months total. | Constraint | 5/5 | 5/5 | Fully honored |
| 11 | 90-day Copenhagen pilot. | Constraint | 4/5 | 5/5 | Fully honored |
| 12 | ~9 months national rollout. | Constraint | 4/5 | 5/5 | Fully honored |
| 13 | Banned words: blockchain/AI/quantum. | Banned | 4/5 | 5/5 | Fully honored |

## Issues

### Issue 2 - Ruter showed the same class has a SIM/OTA path that gives the manufacturer digital access.

- **Category:** Fully honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** potential 'kill-switch' vulnerabilities
- **Explanation:** The plan addresses the potential kill-switch vulnerability.
