**Goal Statement:** Sever or operator-gateway all vendor remote paths, air-gap drive/brake/steer from cloud/OTA, and tighten procurement to require verifiable 'no-remote-kill' designs with independent cyber attestations, starting with Copenhagen, and publish an isolation/rollback playbook operators can execute in hours.

## SMART Criteria

- **Specific:** The goal is to eliminate remote access vulnerabilities in Chinese-made e-buses, particularly Yutong, by physically isolating critical systems and implementing stringent procurement standards.
- **Measurable:** Success will be measured by the complete removal of remote access pathways to critical e-bus systems, verifiable through independent cybersecurity attestations and penetration testing.
- **Achievable:** The goal is achievable within the given budget and timeline by focusing on a phased approach, starting with a pilot in Copenhagen and scaling nationally.
- **Relevant:** This goal is crucial to protect public transportation infrastructure from potential foreign interference and ensure the safety and reliability of e-bus operations.
- **Time-bound:** The project is expected to be completed within 12 months, with a 90-day pilot in Copenhagen followed by a national rollout.

## Dependencies

- Assessment of existing e-bus systems in Copenhagen to identify remote access vulnerabilities.
- Development of a hardware-based air-gap solution for critical e-bus systems.
- Establishment of a cybersecurity attestation standard for e-bus procurement.
- Creation of an operator rollback playbook for rapid system recovery.

## Resources Required

- Air-gap hardware devices
- Cybersecurity expertise for system assessment and implementation
- Legal counsel for regulatory compliance and contract review

## Related Goals

- Enhance cybersecurity of public transportation infrastructure.
- Improve procurement practices to prioritize security.
- Establish robust incident response capabilities for e-bus systems.

## Tags

- cybersecurity
- public transportation
- e-bus
- remote access
- air-gap
- procurement
- Denmark
- Copenhagen

## Risk Assessment and Mitigation Strategies


### Key Risks

- Ineffective 'air-gap' solution may cause operational issues.
- Budget of DKK 120M may be insufficient.
- Reliance on limited vendors, especially Chinese, creates vulnerabilities.
- Security measures could disrupt operations.

### Diverse Risks

- Technical risks
- Financial risks
- Supply chain risks
- Operational risks

### Mitigation Plans

- Test air-gap solution, develop contingency plans, implement monitoring.
- Develop detailed cost breakdown, explore additional funding, closely monitor spending.
- Diversify vendors, implement supply chain security measures, establish clear contractual agreements.
- Plan implementation carefully, communicate proactively with passengers, develop contingency plans.

## Stakeholder Analysis


### Primary Stakeholders

- E-Bus Operators
- Cybersecurity Experts
- Project Managers

### Secondary Stakeholders

- Danish Transport Authority
- E-Bus Vendors (e.g., Yutong)
- Passengers

### Engagement Strategies

- Regular progress reports and updates to e-bus operators.
- Collaboration with cybersecurity experts on system assessment and implementation.
- Consultation with the Danish Transport Authority to ensure compliance.
- Transparent communication with passengers regarding potential service disruptions.

## Regulatory and Compliance Requirements


### Permits and Licenses


### Compliance Standards

- GDPR
- NIS Directive
- ISO 27001

### Regulatory Bodies

- Danish Transport Authority
- Danish Data Protection Agency
- ENISA (European Union Agency for Cybersecurity)

### Compliance Actions

- Engage with regulatory bodies early in the project.
- Establish a legal review process for all contracts and agreements.
- Implement data anonymization standards to comply with GDPR.