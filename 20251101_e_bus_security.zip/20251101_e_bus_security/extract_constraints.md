## Positive Constraints

- Sever or operator-gateway all vendor remote paths
- Air-gap drive/brake/steer from cloud/OTA
- Tighten procurement to require verifiable 'no-remote-kill' designs with independent cyber attestations
- Start with Copenhagen
- Publish an isolation/rollback playbook operators can execute in hours
- Budget: DKK 120M
- Timeline: 12 months total
- 90-day Copenhagen pilot
- ~9 months national rollout

## Negative Constraints

- Do not use blockchain
- Do not use AI
- Do not use quantum
