Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 16 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 3 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The project focuses on e-commerce and tea sourcing, which are within the bounds of known physics.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (imported tea) + market (Czech Republic) + tech/process (e-commerce) + policy (food safety regulations) without independent evidence at comparable scale. There is no mention of precedent.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Owner: Project Manager / Deliverable: Validation Report / Date: 2026-06-30


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because no named frameworks/strategies are defined with a business-level mechanism-of-action (inputs→process→customer value), an owner, and measurable outcomes. The plan lacks one-pagers defining these strategic concepts.

**Mitigation**: Project Manager: Create one-pagers for 'Builder's Blend', 'hybrid fulfillment', 'ethical sourcing', and 'sustainable brand' with value hypotheses, success metrics, and decision hooks by 2026-05-01.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because a major hazard class (cybersecurity) is minimized, and the plan lacks explicit analysis of cascades. The risk register does not map cascades (e.g., permit delay → missed peak season → revenue shortfall).

**Mitigation**: Risk Manager: Expand the risk register to include cybersecurity threats and map potential risk cascades, adding controls and a dated review cadence by 2026-05-01.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions the need for a licensed physical space and regulatory compliance, but lacks a detailed action plan for securing the space and obtaining permits.

**Mitigation**: Legal Team: Develop a permit/approval matrix with required permits, lead times in the jurisdiction, and dated predecessors. Include a NO-GO threshold on slip by 2026-05-01.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not specify funding sources, draw schedule, or covenants. The document mentions "secure funding" as an action, but lacks specifics. Runway length is not defined.

**Mitigation**: Finance Team: Develop a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO‑GO on missed financing gates by 2026-05-01.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget conflicts with vendor quotes or scale-appropriate benchmarks. The plan lacks evidence of cost comparisons and contingency planning.

**Mitigation**: Owner: Finance Team, Deliverable: Benchmark costs against at least 3 suppliers, normalize per area, and adjust budget or de-scope by 2026-05-01.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., timeline) as a single number without providing a range or discussing alternative scenarios. The initial timeline of 6 months is overly optimistic. The plan lacks contingency planning.

**Mitigation**: Project Manager: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the project timeline, including potential delays, by 2026-05-01.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks critical engineering artifacts such as specs, interface contracts, acceptance tests, and integration plans for core components. Their absence creates a likely failure mode.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners and dates by 2026-05-01.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes several critical claims without providing verifiable evidence. For example, it states the brand will be "sustainable and ethically sourced" without providing certifications or supply chain audits.

**Mitigation**: Sustainability Team: Obtain certifications (e.g., Fair Trade) and supply chain audit reports to verify sustainability and ethical sourcing claims by 2026-05-01.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project's final output, "a high-quality imported tea e-commerce business", lacks specific, verifiable qualities. There are no SMART criteria for 'high-quality'.

**Mitigation**: Marketing Team: Define SMART criteria for 'high-quality', including a KPI for customer satisfaction (e.g., average rating of 4.5/5) by 2026-05-01.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'Tea Blend Customization' as a decision, but it does not directly support the core project goals of addressing low operating margins or securing a licensed physical space.

**Mitigation**: Project Team: Produce a one-page benefit case for 'Tea Blend Customization' justifying its inclusion, complete with a KPI, owner, and estimated cost, or move it to the project backlog by 2026-05-01.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a 'Tea Sourcing and Supply Chain Coordinator' with expertise in tea sourcing, quality control, and logistics. This role is critical for securing reliable suppliers and managing the supply chain.

**Mitigation**: HR Team: Validate the talent market for a 'Tea Sourcing and Supply Chain Coordinator' with specific experience in the Czech Republic and imported goods by 2026-05-01.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because legality is unclear. The plan identifies the need for a dedicated licensed physical space and regulatory compliance, but lacks a detailed action plan for securing the space and obtaining permits.

**Mitigation**: Legal Team: Develop a regulatory matrix (authority, artifact, lead time, predecessors) for Czech food/e-commerce, including a Fatal-Flaw Analysis and NO-GO on adverse findings by 2026-05-01.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions operational costs and funding but lacks a detailed sustainability plan. There is no discussion of long-term maintenance, technology obsolescence, or personnel dependency. The plan does not address environmental/social impact.

**Mitigation**: Operations Team: Develop an operational sustainability plan including a funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms by 2026-05-01.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions the need for a licensed physical space but lacks a fatal-flaw screen with authorities. There is no evidence of written confirmation or fallback designs/sites.

**Mitigation**: Project Manager: Conduct a fatal-flaw screen with Czech authorities regarding zoning, occupancy, and permits for the physical space by 2026-05-01.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions partnering with a 3PL but lacks details on SLAs, failover plans, or tested redundancy. The plan does not include evidence of tested failovers.

**Mitigation**: Operations Team: Secure SLAs with the 3PL provider, add a secondary 3PL supplier, and test failover procedures by 2026-06-01.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the 'Marketing Specialist' is incentivized to increase brand awareness and customer acquisition, while the 'Financial Planner' is incentivized to minimize costs and maximize profitability. This creates a conflict over marketing spend.

**Mitigation**: Project Manager: Define a shared OKR (Objective and Key Results) for both the Marketing Specialist and Financial Planner, aligning marketing spend with profitability targets by 2026-05-01.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a change-control process with thresholds. Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board, including owners, thresholds, and a re-plan/stop process by 2026-05-01.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because ≥3 High risks are strongly coupled. A1 (regulatory guidance cost) + A4 (platform customization) + A6 (team expertise) can cascade into financial failure. The plan lacks a cross-impact analysis.

**Mitigation**: Project Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by 2026-05-01.