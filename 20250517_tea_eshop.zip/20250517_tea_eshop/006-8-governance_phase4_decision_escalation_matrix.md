**Budget Request Exceeding Core Project Team Authority (100,000 CZK)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the financial authority delegated to the Core Project Team and requires strategic review and approval at a higher level.
Negative Consequences: Potential budget overruns, project delays, and misalignment with strategic objectives.

**Critical Risk Materialization Requiring Significant Resource Allocation**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Budget/Timeline
Rationale: Materialization of a critical risk (e.g., regulatory hurdle, major supply chain disruption) necessitates a reassessment of project priorities and resource allocation beyond the Core Project Team's capacity.
Negative Consequences: Project failure, significant financial losses, reputational damage, and inability to meet project goals.

**Core Project Team Deadlock on Vendor Selection Impacting Regulatory Compliance**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics & Compliance Committee Review and Recommendation
Rationale: Disagreement within the Core Project Team regarding vendor selection, particularly when it involves regulatory compliance (e.g., food safety certification), requires independent review and resolution by the Ethics & Compliance Committee.
Negative Consequences: Selection of a non-compliant vendor, leading to regulatory violations, fines, and potential business closure.

**Proposed Major Scope Change (e.g., significant product line expansion)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Strategic Alignment
Rationale: A major change to the project scope (e.g., adding a new product line) has significant strategic implications and requires approval from the Project Steering Committee to ensure alignment with overall business objectives and resource availability.
Negative Consequences: Misallocation of resources, project delays, and failure to achieve original project goals.

**Reported Ethical Concern Regarding Supplier Practices**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to CEO
Rationale: Ethical concerns, such as reports of unethical sourcing practices, require independent investigation and resolution by the Ethics & Compliance Committee to ensure adherence to ethical standards and protect the company's reputation.
Negative Consequences: Reputational damage, loss of customer trust, legal liabilities, and potential boycott.

**Unresolved Compliance Issues or Ethical Concerns**
Escalation Level: CEO
Approval Process: CEO Review and Final Decision
Rationale: Unresolved compliance issues or ethical concerns from the Ethics & Compliance Committee require final resolution by the CEO to ensure accountability and adherence to the highest standards of ethical conduct.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust.