
## Audit - Corruption Risks

- Bribery of regulatory officials to expedite or overlook licensing requirements for the physical space or tea importation.
- Kickbacks from suppliers in exchange for preferential treatment or inflated pricing, compromising the quality and cost-effectiveness of the tea.
- Conflicts of interest where project team members have undisclosed financial ties to suppliers or logistics providers, influencing vendor selection.
- Misuse of confidential information regarding pricing strategies or marketing plans shared with competitors or suppliers for personal gain.
- Nepotism in hiring or vendor selection, leading to unqualified personnel or substandard services, particularly in areas like website development or legal consulting.

## Audit - Misallocation Risks

- Misuse of marketing funds for personal expenses or ineffective campaigns that do not align with the brand positioning or target audience.
- Inflated invoices or payments to suppliers or logistics providers, with the excess funds diverted for personal use.
- Double-billing for consulting services or legal fees related to regulatory compliance.
- Inefficient allocation of resources to the physical space, such as unnecessary renovations or equipment purchases.
- Poor record-keeping and lack of documentation for financial transactions, making it difficult to track expenses and identify discrepancies.

## Audit - Procedures

- Conduct quarterly internal audits of financial records, including invoices, receipts, and bank statements, to identify any discrepancies or unauthorized transactions. Responsibility: Internal Audit Team.
- Perform annual external audits of the e-commerce platform's security measures and data privacy compliance to ensure adherence to GDPR and other relevant regulations. Responsibility: External Audit Firm.
- Implement a contract review process with pre-defined approval thresholds for all supplier and logistics agreements to ensure competitive pricing and prevent kickbacks. Responsibility: Legal and Procurement Departments.
- Conduct periodic spot checks of inventory levels and storage conditions in the physical space to prevent spoilage or theft. Responsibility: Operations Manager.
- Review marketing campaign performance metrics regularly to assess the effectiveness of marketing spend and identify any potential misuse of funds. Responsibility: Marketing Manager and Finance Department.

## Audit - Transparency Measures

- Publish a quarterly project progress dashboard on the company website, including key performance indicators (KPIs) such as website traffic, conversion rates, and customer acquisition cost.
- Maintain a publicly accessible register of all suppliers and logistics providers, including their contact information and a summary of their services.
- Implement a whistleblower mechanism that allows employees and stakeholders to report suspected fraud or corruption anonymously.
- Document and publish the selection criteria for all major vendors and consultants, ensuring that the process is fair and transparent.
- Publish minutes of key project meetings, including decisions related to financial allocations and vendor selection, on an internal company portal accessible to all employees.