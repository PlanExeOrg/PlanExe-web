This plan involves money.

## Currencies

- **CZK:** Local currency for the Czech Republic, where the e-commerce business will operate.
- **EUR:** Euro is widely accepted in the Czech Republic and may be useful for international transactions with suppliers.

**Primary currency:** CZK

**Currency strategy:** The Czech Koruna (CZK) will be used for all local transactions. For international transactions, especially with suppliers, consider hedging against exchange rate fluctuations between CZK and EUR or USD, or using cards with no foreign transaction fees. Given the relatively stable economy of the Czech Republic, no additional international risk management is needed beyond standard currency exchange considerations.