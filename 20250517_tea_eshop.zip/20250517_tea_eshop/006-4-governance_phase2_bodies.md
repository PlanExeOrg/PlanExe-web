### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and guidance, given the project's complexity, financial risks, and need for regulatory compliance.  Ensures alignment with overall business objectives.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic direction and guidance.
- Monitor project progress against key milestones.
- Approve major changes to scope, budget, or timeline (above 100,000 CZK).
- Oversee risk management and mitigation strategies.
- Resolve strategic conflicts and escalate issues as needed.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define escalation paths.
- Approve initial project plan.

**Membership:**

- CEO
- CFO
- Head of Marketing
- Head of Operations
- Independent External Advisor (e-commerce expert)

**Decision Rights:** Strategic decisions related to project scope, budget (above 100,000 CZK), timeline, and risk management.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the CEO has the deciding vote.  Any decision impacting regulatory compliance requires unanimous approval.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review project progress against milestones.
- Review and approve budget variances.
- Discuss and resolve strategic issues.
- Review risk register and mitigation plans.
- Approve major changes to scope, budget, or timeline.

**Escalation Path:** CEO (for unresolved issues within the Steering Committee).
### 2. Core Project Team

**Rationale for Inclusion:** Manages day-to-day project execution, ensuring tasks are completed on time and within budget.  Provides operational risk management and makes decisions below strategic thresholds.

**Responsibilities:**

- Develop and maintain project plan.
- Manage project tasks and resources.
- Track project progress and report to the Steering Committee.
- Identify and manage operational risks.
- Implement mitigation strategies.
- Manage day-to-day budget (below 100,000 CZK).
- Coordinate with suppliers and logistics providers.

**Initial Setup Actions:**

- Define roles and responsibilities.
- Establish communication protocols.
- Set up project tracking system.
- Develop initial project schedule.

**Membership:**

- Project Manager
- Marketing Specialist
- Operations Manager
- Customer Service Representative

**Decision Rights:** Operational decisions related to project execution, resource allocation (below 100,000 CZK), and risk management.

**Decision Mechanism:** Decisions made by the Project Manager in consultation with team members.  Unresolved disagreements escalated to the Steering Committee.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review project progress against plan.
- Discuss and resolve operational issues.
- Review risk register and mitigation plans.
- Track budget expenditures.
- Plan upcoming tasks.

**Escalation Path:** Project Steering Committee (for issues exceeding the Project Manager's authority or unresolved disagreements).
### 3. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures ethical sourcing, regulatory compliance (GDPR, food safety), and data privacy.  Provides assurance that the project adheres to legal and ethical standards.

**Responsibilities:**

- Develop and implement compliance policies and procedures.
- Monitor compliance with relevant regulations (GDPR, food safety, import/export).
- Conduct ethical sourcing audits.
- Investigate and resolve compliance violations.
- Provide training on ethical and compliance issues.
- Oversee data privacy and security measures.
- Ensure adherence to HACCP standards.
- Review and approve all marketing materials for compliance with advertising standards.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Develop compliance program.
- Define reporting procedures.

**Membership:**

- Legal Consultant
- Data Protection Officer
- Operations Manager
- Independent Ethics Advisor
- Quality Control Manager

**Decision Rights:** Decisions related to compliance policies, ethical sourcing, data privacy, and regulatory adherence.  Has the authority to halt project activities if compliance is at risk.

**Decision Mechanism:** Decisions made by majority vote. The Legal Consultant's opinion is binding on legal compliance matters. The Independent Ethics Advisor's opinion is strongly considered on ethical matters.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review compliance reports.
- Discuss and resolve compliance violations.
- Review ethical sourcing practices.
- Review data privacy and security measures.
- Update compliance policies and procedures.
- Review marketing materials for compliance.

**Escalation Path:** CEO (for unresolved compliance issues or ethical concerns).