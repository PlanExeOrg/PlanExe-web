A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The local consulting firm will provide comprehensive regulatory guidance at a predictable cost. | Obtain fixed-price quotes from multiple consulting firms for a clearly defined scope of services. | Quotes vary widely or exceed a pre-defined budget threshold (e.g., 50,000 CZK) for the core compliance package. |
| A2 | The hybrid fulfillment model will be more cost-effective than a fully outsourced or fully owned model. | Develop a detailed cost model comparing all three fulfillment models (owned, outsourced, hybrid) using realistic order volume projections and cost data. | The cost model shows that either a fully outsourced or fully owned model is consistently cheaper across a range of order volumes. |
| A3 | Czech consumers are willing to pay a premium for ethically sourced tea, justifying higher sourcing costs. | Conduct a survey of Czech tea consumers to gauge their willingness to pay a premium for ethically sourced tea, presenting different price points and product descriptions. | The survey results indicate that the majority of Czech consumers are unwilling to pay a premium exceeding a pre-defined threshold (e.g., 10%) for ethically sourced tea. |
| A4 | The e-commerce platform can be effectively customized to meet the specific needs of the Czech market (language, payment gateways, shipping integrations). | Develop a prototype of the e-commerce platform with key Czech-specific customizations and test its functionality with a group of Czech users. | The prototype reveals significant technical challenges or limitations in customizing the platform to meet Czech requirements, resulting in a poor user experience. |
| A5 | The Czech market is not saturated with tea e-commerce businesses and there is room for a new entrant. | Conduct a thorough competitive analysis, including a count of existing tea e-commerce businesses, their market share, and their marketing strategies. | The competitive analysis reveals a highly saturated market with limited opportunities for a new entrant to gain significant market share. |
| A6 | The team possesses sufficient expertise in all critical areas (e-commerce, tea sourcing, marketing, regulatory compliance) to execute the project successfully. | Conduct a skills gap analysis of the project team, identifying any areas where expertise is lacking and assessing the availability of external resources to fill those gaps. | The skills gap analysis reveals significant gaps in critical areas, and external resources are either unavailable or too expensive to be feasible. |
| A7 | The Czech consumer base is readily accessible and responsive to online marketing efforts, allowing for efficient customer acquisition. | Run a small-scale, targeted online advertising campaign in the Czech Republic and measure the click-through rates, conversion rates, and customer acquisition costs. | The online advertising campaign yields significantly lower click-through rates, conversion rates, and higher customer acquisition costs than industry benchmarks for similar products. |
| A8 | The chosen tea varieties will maintain consistent quality and availability throughout the year, regardless of seasonal variations or supply chain disruptions. | Research the seasonal availability and quality variations of the chosen tea varieties, and assess the potential impact of climate change and other factors on supply chain stability. | The research reveals significant seasonal variations in quality or availability, or a high risk of supply chain disruptions due to climate change or other factors. |
| A9 | The e-commerce platform will be secure from cyberattacks and data breaches, protecting customer data and maintaining business continuity. | Conduct a thorough security audit of the e-commerce platform, including penetration testing and vulnerability scanning, to identify potential security weaknesses. | The security audit reveals significant vulnerabilities that could be exploited by cyberattacks, potentially compromising customer data or disrupting business operations. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Compliance Cost Overrun Catastrophe | Process/Financial | A1 | Project Manager | CRITICAL (20/25) |
| FM2 | The Fulfillment Bottleneck Nightmare | Technical/Logistical | A2 | Operations Manager | CRITICAL (15/25) |
| FM3 | The Ethical Premium Price Rejection | Market/Human | A3 | Marketing Specialist | CRITICAL (20/25) |
| FM4 | The Untranslatable Platform Debacle | Process/Financial | A4 | Project Manager | CRITICAL (20/25) |
| FM5 | The Red Ocean Suffocation | Technical/Logistical | A5 | Marketing Specialist | CRITICAL (15/25) |
| FM6 | The Incompetence Implosion | Market/Human | A6 | Project Manager | CRITICAL (20/25) |
| FM7 | The Marketing Echo Chamber | Market/Human | A7 | Marketing Specialist | CRITICAL (20/25) |
| FM8 | The Seasonal Supply Chain Meltdown | Technical/Logistical | A8 | Operations Manager | CRITICAL (15/25) |
| FM9 | The Data Breach Debacle | Process/Financial | A9 | Project Manager | HIGH (10/25) |


### Failure Modes

#### FM1 - The Compliance Cost Overrun Catastrophe

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Project Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project relied on partnering with a local consulting firm to navigate Czech food and e-commerce regulations. The initial assumption was that the consulting firm would provide comprehensive guidance at a predictable cost. However, after signing the contract, the consulting firm presented a series of unexpected additional fees for services not initially included in the scope, such as specialized import permits and ongoing compliance monitoring. These fees quickly escalated, exceeding the allocated budget for regulatory compliance. The project team, already operating on thin margins, was forced to divert funds from marketing and website development to cover the cost overruns. This resulted in a poorly designed website, ineffective marketing campaigns, and ultimately, low sales. The business struggled to achieve profitability and was forced to shut down within a year.

##### Early Warning Signs
- Initial consulting quotes are significantly lower than industry averages.
- The consulting contract lacks a clearly defined scope of services and a fixed price.
- The consulting firm has a history of upselling additional services to clients.

##### Tripwires
- Actual consulting fees exceed budgeted amount by 15%
- Legal penalties or fines are incurred due to non-compliance
- Critical permit applications are delayed by more than 30 days

##### Response Playbook
- Contain: Immediately freeze all non-essential spending.
- Assess: Conduct a thorough audit of all consulting fees and identify areas where costs can be reduced.
- Respond: Renegotiate the consulting contract or seek alternative legal counsel.


**STOP RULE:** Total regulatory compliance costs exceed 20% of initial capital expenditure.

---

#### FM2 - The Fulfillment Bottleneck Nightmare

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Operations Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project opted for a hybrid fulfillment model, assuming it would be the most cost-effective solution. However, the leased facility proved to be too small to handle the actual order volume, leading to significant bottlenecks in order processing and shipping. The 3PL partner, while initially promising, struggled to integrate with the e-commerce platform, resulting in frequent errors and delays. The lack of a fully integrated system meant that inventory levels were often inaccurate, leading to stockouts and customer dissatisfaction. The technical challenges of coordinating the hybrid model proved to be overwhelming, resulting in increased fulfillment costs, delayed deliveries, and ultimately, a loss of customers. The business was unable to scale effectively and eventually collapsed under the weight of its logistical inefficiencies.

##### Early Warning Signs
- Order fulfillment times consistently exceed target levels.
- Inventory discrepancies are frequent and significant.
- The 3PL partner reports difficulty integrating with the e-commerce platform.

##### Tripwires
- Average order fulfillment time exceeds 72 hours.
- Inventory discrepancy rate exceeds 5%
- Customer complaints related to shipping delays increase by 20%

##### Response Playbook
- Contain: Immediately implement manual workarounds to address order processing bottlenecks.
- Assess: Conduct a thorough review of the fulfillment process and identify the root causes of the delays and errors.
- Respond: Renegotiate the 3PL contract or explore alternative fulfillment models.


**STOP RULE:** Fulfillment costs exceed 15% of revenue for two consecutive months.

---

#### FM3 - The Ethical Premium Price Rejection

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Marketing Specialist
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project positioned itself as a provider of ethically sourced tea, assuming that Czech consumers were willing to pay a premium for this value proposition. However, market research revealed that while Czech consumers valued ethical sourcing, they were unwilling to pay significantly more for it, especially in a price-sensitive market. The higher prices made the tea less competitive compared to established brands and cheaper alternatives. The marketing campaigns, while emphasizing ethical sourcing, failed to resonate with the target audience, resulting in low sales and limited brand awareness. The business struggled to attract customers and was forced to lower prices, eroding profit margins and ultimately leading to its demise. The ethical premium proved to be a fatal miscalculation.

##### Early Warning Signs
- Website conversion rates are significantly lower than projected.
- Customer feedback indicates price sensitivity.
- Competitors are undercutting prices despite not emphasizing ethical sourcing.

##### Tripwires
- Website conversion rate falls below 1%
- Customer acquisition cost exceeds pre-defined threshold by 20%
- Sales volume is 30% below projections after 3 months

##### Response Playbook
- Contain: Immediately halt all marketing campaigns emphasizing the ethical premium.
- Assess: Conduct further market research to understand consumer price sensitivity and preferences.
- Respond: Adjust pricing strategy to be more competitive or reposition the brand to focus on other value propositions.


**STOP RULE:** Gross profit margin falls below 30% for two consecutive months.

---

#### FM4 - The Untranslatable Platform Debacle

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Project Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project team selected an e-commerce platform based on its global popularity and assumed it could be easily customized for the Czech market. However, they quickly discovered that translating the platform into Czech was more complex and expensive than anticipated. The platform's built-in translation tools were inadequate, and hiring professional translators proved to be costly. Furthermore, integrating Czech payment gateways and shipping providers required extensive custom coding, which strained the project's budget and timeline. The resulting website was clunky, difficult to navigate for Czech speakers, and lacked essential local payment options. Customers abandoned their shopping carts in droves, leading to low sales and a rapid depletion of the marketing budget. The business failed to gain traction and was forced to shut down within months.

##### Early Warning Signs
- The initial translation of the website is riddled with errors and awkward phrasing.
- Integrating Czech payment gateways requires extensive custom coding.
- Czech customers report difficulty navigating the website.

##### Tripwires
- Website conversion rate is 50% below projections after 1 month.
- Customer complaints related to website usability increase by 30%
- The cost of website customization exceeds the budgeted amount by 25%

##### Response Playbook
- Contain: Immediately halt all further website development and customization efforts.
- Assess: Conduct a thorough review of the website's usability and functionality with a group of Czech users.
- Respond: Explore alternative e-commerce platforms that are better suited for the Czech market or hire a specialized web development team with expertise in Czech localization.


**STOP RULE:** Website customization costs exceed 30% of the initial capital expenditure.

---

#### FM5 - The Red Ocean Suffocation

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Marketing Specialist
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project team entered the Czech tea e-commerce market assuming there was ample room for a new player. However, they soon discovered that the market was already saturated with established businesses, both local and international. These competitors had strong brand recognition, loyal customer bases, and sophisticated marketing strategies. The new entrant struggled to differentiate itself and gain visibility in the crowded marketplace. Despite investing heavily in marketing, the project team was unable to attract a significant number of customers. The high customer acquisition costs and low sales volume made the business unsustainable. The project team underestimated the intensity of the competition and failed to develop a compelling value proposition that would resonate with Czech consumers. The business was quickly overwhelmed and forced to close its doors.

##### Early Warning Signs
- Customer acquisition costs are significantly higher than projected.
- Website traffic is low despite aggressive marketing efforts.
- Competitors are launching aggressive marketing campaigns to defend their market share.

##### Tripwires
- Customer acquisition cost exceeds pre-defined threshold by 30%
- Website traffic is 40% below projections after 2 months
- Market share remains below 1% after 6 months

##### Response Playbook
- Contain: Immediately re-evaluate the marketing strategy and identify areas where costs can be reduced.
- Assess: Conduct a thorough competitive analysis to identify opportunities for differentiation.
- Respond: Develop a new marketing campaign that focuses on a niche market or a unique value proposition.


**STOP RULE:** Customer acquisition cost exceeds 50% of the average order value for two consecutive months.

---

#### FM6 - The Incompetence Implosion

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Project Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project team, while enthusiastic, lacked sufficient expertise in several critical areas. The team's knowledge of e-commerce best practices was limited, resulting in a poorly designed website and ineffective online marketing campaigns. Their understanding of tea sourcing and quality control was inadequate, leading to inconsistent product quality and customer dissatisfaction. Furthermore, their knowledge of Czech food safety regulations was incomplete, resulting in compliance issues and potential legal penalties. The team's lack of expertise led to a series of costly mistakes and missed opportunities. The business struggled to overcome these challenges and was ultimately unable to compete effectively. The project team's overconfidence and lack of experience proved to be a fatal flaw.

##### Early Warning Signs
- Project milestones are consistently delayed due to lack of expertise.
- The team struggles to make informed decisions in critical areas.
- External consultants are frequently required to correct mistakes.

##### Tripwires
- Project milestones are delayed by more than 30 days.
- The cost of external consultants exceeds the budgeted amount by 20%
- Customer satisfaction scores fall below 70%

##### Response Playbook
- Contain: Immediately identify the areas where expertise is lacking and seek external assistance.
- Assess: Conduct a thorough skills gap analysis of the project team and develop a plan to address the gaps.
- Respond: Hire experienced personnel or engage external consultants to provide specialized expertise.


**STOP RULE:** The project fails to meet a critical regulatory deadline due to lack of expertise.

---

#### FM7 - The Marketing Echo Chamber

- **Archetype**: Market/Human
- **Root Cause**: Assumption A7
- **Owner**: Marketing Specialist
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project team assumed that Czech consumers were readily accessible and responsive to online marketing. However, their initial campaigns yielded dismal results. They discovered that Czech consumers were highly skeptical of online advertising and preferred to rely on word-of-mouth recommendations and trusted local brands. The team's attempts to engage with consumers on social media were met with apathy or even hostility. The marketing messages, while well-crafted, failed to resonate with the Czech cultural context. The project team realized too late that they had underestimated the challenges of reaching and engaging with their target audience. The marketing budget was quickly exhausted with little to show for it, and the business was unable to attract a sustainable customer base.

##### Early Warning Signs
- Click-through rates on online advertisements are significantly below industry averages.
- Social media engagement is minimal despite consistent posting.
- Customer acquisition costs are far exceeding projections.

##### Tripwires
- Click-through rate on online ads is below 0.1%
- Social media engagement (likes, shares, comments) is less than 1% of followers
- Customer acquisition cost exceeds 1000 CZK

##### Response Playbook
- Contain: Immediately pause all underperforming marketing campaigns.
- Assess: Conduct in-depth market research to understand Czech consumer preferences and media consumption habits.
- Respond: Develop a new marketing strategy that focuses on building trust and credibility through local partnerships and word-of-mouth marketing.


**STOP RULE:** Customer acquisition cost exceeds 1500 CZK for two consecutive months.

---

#### FM8 - The Seasonal Supply Chain Meltdown

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Operations Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project team assumed that their chosen tea varieties would maintain consistent quality and availability throughout the year. However, they were unprepared for the realities of seasonal variations and supply chain disruptions. During the winter months, the quality of certain tea varieties plummeted, and prices soared due to limited availability. A major shipping port closure due to a typhoon further exacerbated the problem, leaving the business with empty shelves and angry customers. The project team scrambled to find alternative suppliers, but the quality was inconsistent, and the prices were exorbitant. The business was unable to fulfill orders, leading to a massive loss of customer trust and a tarnished brand reputation. The seasonal supply chain meltdown proved to be a catastrophic blow from which the business never recovered.

##### Early Warning Signs
- Supplier lead times are increasing significantly.
- The quality of incoming tea shipments is declining.
- Prices for certain tea varieties are spiking unexpectedly.

##### Tripwires
- Supplier lead time exceeds 6 weeks
- Quality control rejects exceed 10% of incoming shipments
- Price of key tea varieties increases by 50%

##### Response Playbook
- Contain: Immediately notify customers of potential delays and offer refunds or alternative products.
- Assess: Conduct a thorough review of the supply chain and identify vulnerabilities to seasonal variations and disruptions.
- Respond: Diversify sourcing regions, build buffer stock, and develop contingency plans for potential disruptions.


**STOP RULE:** The business is unable to fulfill more than 20% of orders for one month due to supply chain issues.

---

#### FM9 - The Data Breach Debacle

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Project Manager
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The project team, focused on launching quickly, underestimated the importance of cybersecurity. They assumed their e-commerce platform was inherently secure. However, a sophisticated cyberattack exploited a vulnerability in the platform's code, granting hackers access to sensitive customer data, including credit card information. The data breach triggered a public relations nightmare, as news of the security lapse spread rapidly online. Customers lost trust in the business and cancelled their accounts en masse. The business faced hefty fines for violating data privacy regulations and was forced to spend a fortune on security upgrades and legal fees. The reputational damage and financial losses proved to be insurmountable, and the business was forced to declare bankruptcy.

##### Early Warning Signs
- Unusual activity is detected on the e-commerce platform.
- Customers report suspicious emails or phone calls.
- Security software flags potential vulnerabilities.

##### Tripwires
- Intrusion detection system flags a high-severity security threat.
- Customer complaints about fraudulent activity increase by 100%
- The e-commerce platform fails a security audit

##### Response Playbook
- Contain: Immediately shut down the e-commerce platform and notify law enforcement.
- Assess: Conduct a thorough forensic investigation to determine the extent of the data breach.
- Respond: Notify affected customers, implement enhanced security measures, and cooperate with regulatory authorities.


**STOP RULE:** Customer data is confirmed to have been compromised in a data breach.
