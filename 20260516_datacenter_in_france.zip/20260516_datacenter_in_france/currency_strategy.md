This plan involves money.

## Currencies

- **EUR:** The primary currency of the project location (France) for land acquisition, labor, local taxes, and grid connection costs.
- **USD:** Hardware procurement (GPUs/TPUs, networking gear) and potential international financing will expose the project to USD fluctuations.

**Primary currency:** EUR

**Currency strategy:** EUR will be the primary currency for budgeting, operational accounting, and reporting, as local costs (land, labor, grid) are EUR-denominated. Significant USD exposure due to hardware procurement must be tracked separately, and a formal FX hedging strategy (e.g., forward contracts) must be implemented for all major anticipated USD hardware purchases starting in Phase 1 to stabilize the budget against exchange rate volatility.