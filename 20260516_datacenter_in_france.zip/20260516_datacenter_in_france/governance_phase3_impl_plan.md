### 1. Project Sponsor formally authorizes the immediate initiation of Phase 0 activities, including the establishment of the Governance Framework and the appointment of the Formation Lead.

**Responsible Body/Role:** Executive Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Formal Project Initiation Mandate
- Designation of Project Director (CPMG Chair)
- Appointment of Interim Setup Lead (for initial drafting)

**Dependencies:**

- Project Charter Finalized (Implied from Input)

### 2. Interim Setup Lead drafts initial Terms of Reference (ToR) documents for the Project Steering Committee (PSC), Core Project Management Group (CPMG), and Regulatory & Compliance Assurance Board (RCAB), incorporating strategic decisions made (Pragmatic Scale-Up strategy).

**Responsible Body/Role:** Interim Setup Lead

**Suggested Timeframe:** Project Week 1-2

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1
- Draft CPMG ToR v0.1
- Draft RCAB ToR v0.1

**Dependencies:**

- Formal Project Initiation Mandate

### 3. Interim Setup Lead circulates draft ToRs for initial high-level review focusing on decision rights, thresholds (€500M), and membership composition.

**Responsible Body/Role:** Interim Setup Lead

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Stakeholder Feedback Summary on ToRs
- Updated Draft ToRs (v0.2)

**Dependencies:**

- Draft PSC ToR v0.1
- Draft CPMG ToR v0.1
- Draft RCAB ToR v0.1

### 4. Executive Sponsor officially appoints the Chair, CFO, CTO, and External Advisor for the Project Steering Committee (PSC).

**Responsible Body/Role:** Executive Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Formal PSC Membership Confirmation
- PSC Chair Appointment Notification

**Dependencies:**

- Updated Draft ToRs (v0.2)

### 5. The Executive Sponsor, utilizing nominations from the newly confirmed PSC, formally approves the final PSC ToR and establishes the definitive governance framework.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Approved Governance Framework Document
- Final PSC ToR (v1.0)

**Dependencies:**

- Formal PSC Membership Confirmation

### 6. Project Director (CPMG Chair) is appointed by the PSC, and the PSC confirms the initial setup actions for CPMG and RCAB.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Project Director Appointment Confirmation
- Final CPMG and RCAB ToR Approval

**Dependencies:**

- Approved Governance Framework Document

### 7. The Project Director (CPMG Chair) finalizes the detailed membership selection for the CPMG and RCAB based on ToR requirements and initiates rapid recruitment/nomination for external expert roles.

**Responsible Body/Role:** Project Director (CPMG Chair)

**Suggested Timeframe:** Project Week 6-8

**Key Outputs/Deliverables:**

- CPMG Membership Confirmation
- RCAB Membership Confirmation (including external counsel retention)

**Dependencies:**

- Project Director Appointment Confirmation

### 8. Hold the inaugural Kick-off Meeting for the Core Project Management Group (CPMG) to align on Phase 1 SMART criteria, Phase 0 deliverables, and establish tactical reporting rhythms.

**Responsible Body/Role:** Core Project Management Group (CPMG)

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- CPMG Kick-off Meeting Minutes
- Initial Phase 0 Workstream Allocation Register

**Dependencies:**

- CPMG Membership Confirmation
- Final CPMG ToR Approval

### 9. Hold the inaugural Meeting for the Regulatory & Compliance Assurance Board (RCAB). RCAB prioritizes establishing the DGSI communication protocol and finalizing the land boundary verification plan accounting for the 80% buffer zone.

**Responsible Body/Role:** Regulatory & Compliance Assurance Board (RCAB)

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- RCAB Kick-off Minutes
- DGSI Communication Protocol Matrix
- Land Integrity Audit Plan (Decision 10 mitigation)

**Dependencies:**

- RCAB Membership Confirmation
- Final RCAB ToR Approval

### 10. Hold the Inaugural Project Steering Committee (PSC) meeting. PSC formally ratifies the establishment of CPMG and RCAB, reviews Phase 0 status against Strategic Decision Matrix, and approves the initial Risk Register prioritization.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- PSC Inaugural Meeting Minutes & Ratification of Operational Bodies
- Approved Prioritized Risk Register

**Dependencies:**

- CPMG Kick-off Meeting Minutes
- RCAB Kick-off Minutes

### 11. CPMG initiates detailed modeling for the hyper-dense 32.2 km² buildable area and commits initial budget for securing preliminary Right-of-Way (ROW) easements crucial for future high-voltage transmission tie-lines (Decision 1 Linkage).

**Responsible Body/Role:** Core Project Management Group (CPMG)

**Suggested Timeframe:** Project Month 3

**Key Outputs/Deliverables:**

- Hyper-Dense Footprint Model v1.0
- ROW Application Submissions for Phase 2 Connection Points

**Dependencies:**

- Approved Prioritized Risk Register
- Assumptions Q8 Implementation Start

### 12. RCAB conducts the first mandatory Internal Security/Compliance Checkpoint, focusing specifically on the physical segregation plan for the Phase 1 500 MW commercial load relative to future sovereign zone requirements (Risk 5 mitigation).

**Responsible Body/Role:** Regulatory & Compliance Assurance Board (RCAB)

**Suggested Timeframe:** Project Month 4

**Key Outputs/Deliverables:**

- Security Separation Compliance Report v1.0
- Formal Go/No-Go Recommendation for Phase 1 Construction Start (Technical/Security Layer)

**Dependencies:**

- Lead Electrical/Grid Liaison Manager delivers initial substation demarcation plan

### 13. PSC reviews the Security Separation Report and either grants authority to commence main land remediation and grid connection feasibility studies, or mandates remediation based on RCAB findings.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Month 5

**Key Outputs/Deliverables:**

- Phase 1 Construction Start Authorization (Subject to Power/Tenant Gates)

**Dependencies:**

- Security Separation Compliance Report v1.0
- CPMG Report on Holding Cost Budget Allocation (Review Issue 2)