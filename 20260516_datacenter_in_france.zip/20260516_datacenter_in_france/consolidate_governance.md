# Governance Audit


## Audit - Corruption Risks

- Bribery or kickbacks to local planning officials (DREAL, Municipalities) to expedite zoning approvals or secure favorable land assembly terms for the massive 161 km² footprint or the 'hyper-dense development model' (Decision 2).
- Nepotism in selecting contractors for brownfield remediation, where firms with personal ties to project leadership are chosen over demonstrably more qualified/cheaper bidders, potentially inflating the €250M–€750M Phase 0 budget (Risk 9).
- Conflict of interest arising if personnel involved in negotiating fiber optic right-of-way easements (Decision 5/7) also hold undisclosed financial interests in the chosen terrestrial carriers or subsea landing point construction firms.
- Misuse of influence with RTE/EDF officials to secure preferential grid connection slots or more favorable capital contribution requirements for the 9 GW buildout, especially since grid capacity is treated as highly uncertain (Decision 1/9).
- Trading favors with regulatory bodies (e.g., DGSI/ANSSI) where accelerated validation of the sovereign AI partition (Decision 3) is exchanged for granting local authorities favorable terms in the Public Benefit/Heat Reuse agreements (Decision 6).

## Audit - Misallocation Risks

- Misallocation of Phase 1 CAPEX (up to €10B) towards premature investment in high-cost, dark fiber ownership (Decision 7) before the 60% tenant commitment threshold for Phase 2 is met, undermining liquidity for mandatory grid upgrade collateral.
- Budgetary overrun on land holding costs for the 80% buffer zone (128.8 km²), as the plan highlights this needs dedicated funding but lacks a firm cost estimate, potentially diverting funds from essential cybersecurity hardening (Risk 7/Assumption Issue 2).
- Inefficient allocation of technical resources toward meeting the ultra-aggressive PUE target of 1.15 in brownfield Phase 1, leading to material cost overruns on specialized liquid cooling systems when a PUE target of 1.20 (conservative approach) would suffice without violating tenant SLAs (Risk 2/Assumption Q4).
- Unauthorized utilization of Power Purchase Agreement (PPA) capacity intended for the *firmly contracted* 1 GW Phase 1 tranche for speculative customer testing or internal development, risking the binding RTE allocation for Phase 2 expansion (Risk 3).
- Misreporting of workforce integration progress: Paying prime contractors based on invoices claiming high local hiring percentages (Decision 8) without validation, leading to inflated community compensation funds or procurement of less skilled/more costly labor.

## Audit - Procedures

- Quarterly financial audit focusing on the split between EUR (local) and USD (hardware) expenditures, requiring reconciliation of the 70% FX hedge documentation against actual invoices for GPU/TPU procurement (Currency Strategy/Risk 4).
- Pre-FID Audit (Phase 1 Construction Financing): Verification that a binding RTE allocation contract for Phases 2/3 transmission *or* sufficient collateral provisions are formally documented *before* releasing construction capital, as per the Pragmatic Scale-Up strategy (Decision 1/Risk 3).
- Physical Segregation Audit (Bi-annually during Phase 1): On-site verification of physical and logical separation between the initial 500 MW-1 GW commercial cluster and the planned sovereign AI zones, checking substation demarcation and access controls mandated by DGSI protocols (Risk 5).
- Compliance Check on Infrastructure Contingency Budget (Post-Phase 0): Audit the ring-fenced budget allocated for land holding costs (128.8 km²) and Workforce Skill Uplift contingencies to ensure these technical/social buffers were not prematurely reallocated to core compute CAPEX (Review Issue 2/3).
- Land Use Verification (Annually): Independent survey mapping utilizing Geo-spatial analysis to confirm that the 80% reserved buffer acreage corresponds to the mandated ecological offsets and community integration spaces, cross-referenced against local permitting conditions (Decision 10/Risk 7).

## Audit - Transparency Measures

- Publicly accessible, delayed (30-day lag) financial dashboard displaying Phase 1 CAPEX burn rate, segregated by Land Acquisition, Grid Connection Fees (RTE payments), and Hardware Procurement (EUR/USD split).
- Formal publication of the Land Assembly Modality agreement (Decision 2) detailing which parcels are designated as 'Permanent Ecological Offset' versus 'Expansion Reserve,' verifiable by local authorities.
- Establish an independent Whistleblower Mechanism, managed by an external legal firm, specifically soliciting reports related to procurement favoring local suppliers or integrity breaches concerning environmental remediation contracts (Risk 9).
- Publish quarterly status reports detailing progress against Local Workforce Sourcing quotas (Decision 8), including the number of trainees enrolled in the skills academy and the percentage of non-specialized labor filled locally.
- Mandatory publication of the operational PUE and water usage metrics (per GW block) within 60 days of Phase 1 commissioning, allowing anchor tenants and regulators to verify performance against the 1.20 target.

# Internal Governance Bodies

### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** Required for high-level strategic decision-making, managing the extreme financial scale (€100B+) and the critical cross-domain dependencies (Grid, Land, Security). It must enforce the 'Pragmatic Scale-Up' strategy and sign off on all major deviation requests from the plan.

**Responsibilities:**

- Approve all Gate decisions (Phase 0 to 1, 1 to 2, etc.) based on satisfaction of strategic levers.
- Authorize capital expenditure variances exceeding 10% of the current phase budget or any unbudgeted obligation exceeding €500M.
- Provide ultimate arbitration for high-level cross-functional conflicts (e.g., Fiber vs. Power funding priority).
- Oversight of Risk Register, specifically for Critical Risks (Regulatory Delays, RTE Confirmation Failure, Social License Erosion).
- Approve major changes to the 9 GW target or the 161 km² conceptual footprint.

**Initial Setup Actions:**

- Finalize and approve the Project Charter and Governance Framework, including conflict resolution protocols.
- Appoint Chairperson (must be a senior sponsor outside the core delivery team).
- Establish the financial threshold for strategic versus operational decision authority (€500M).

**Membership:**

- Executive Sponsor (Chair)
- Chief Financial Officer (CFO)
- Chief Technology Officer (CTO)
- Head of Regulatory & Legal Affairs (Non-voting advisory)
- Independent External Governance Advisor (Voting member, focused on fiduciary duty)

**Decision Rights:** All strategic roadmap decisions, Gate Approvals (FID), budget allocations above €500M, and formal approval of revised major risk acceptance.

**Decision Mechanism:** Consensus required for Gate Approvals; Simple Majority for operational direction changes. Tie-breaker: The Executive Sponsor casts the deciding vote after mandatory 48-hour cooling-off period.

**Meeting Cadence:** Monthly, or immediately following critical external milestones (e.g., RTE consultation outcome).

**Typical Agenda Items:**

- Review of Phase Progress vs. Strategic Decision Matrix Execution
- Financial Burn Rate vs. Budgeted Tolerance (EUR/USD Split)
- Escalation Review: Issues deemed unresolvable by the Operational Management Group
- Audit Report Review (especially Compliance Check on Infrastructure Contingency Budget)

**Escalation Path:** External Shareholders / Board of Directors (for issues threatening project continuation or governance integrity).
### 2. Core Project Management Group (CPMG)

**Rationale for Inclusion:** This body manages the day-to-day execution of the 'Pragmatic Scale-Up' strategy. It is responsible for coordinating workstreams (Land, Grid Studies, Design) and making tactical decisions below the €500M strategic threshold, ensuring adherence to Phase 1 SMART criteria.

**Responsibilities:**

- Day-to-day management of the 3-year Phase 1 roadmap.
- Managing the interface between workstream leads (Design, Procurement, Regulatory Liaison).
- Detailed management of the €12.5M–€37.5M workforce/social license budget.
- Monitoring and enforcing the 1.20 PUE tolerance in detailed design and construction.
- Managing operational risk including cyber segregation checks (Risk 5).

**Initial Setup Actions:**

- Appoint Project Director (Chair of CPMG).
- Establish standardized reporting templates for all specialized workstreams (Land, Power, Security).
- Finalize resource allocation for the initial hyper-dense 32.2 km² buildable zone modeling.

**Membership:**

- Project Director (Chair)
- Lead Civil/Site Manager
- Lead Electrical/Grid Liaison Manager
- Head of Technology & Design (Liquid Cooling/PUE focus)
- Compliance & Security Coordinator (DGSI liaison)

**Decision Rights:** Operational decisions regarding cross-discipline resource allocation, tactical selection of vendors within approved procurement envelopes, approval of design changes up to 10% cost impact within a single workstream, and any decision under €500M.

**Decision Mechanism:** Simple majority vote. Decisions impacting multiple workstreams require documented alignment. Tie-breaker: Project Director's vote.

**Meeting Cadence:** Twice Weekly (Operational Synchronization); Weekly Detailed Progress Review.

**Typical Agenda Items:**

- Review of Remediation Progress vs. Budget (Risk 9)
- Status of RTE impact study submissions (pre-FID checkpoint)
- Progress against Local Workforce Quotas (Decision 8 implementation)
- Technical Review: Liquid Cooling performance parameters and integration milestones.

**Escalation Path:** Project Steering Committee (PSC) for any decision involving schedule delay risks exceeding 3 months, or budget triggers exceeding 10% of the active Phase 1 budget tranche.
### 3. Regulatory & Compliance Assurance Board (RCAB)

**Rationale for Inclusion:** Given the critical reliance on French permitting, DGSI/ANSSI alignment (Decision 3), and managing high legal/reputational risk associated with land assembly (Decision 2, 10) and corruption (Audit Risks), a dedicated, independent assurance body is necessary to ensure compliance is proactive, not reactive.

**Responsibilities:**

- Conduct mandatory compliance checks against DGSI/ANSSI protocols prior to Phase 1 construction FID.
- Oversee the integrity of land assembly documentation (confirming 80% buffer zoning integrity per Decision 10).
- Manage the independent Whistleblower Mechanism and oversee anti-corruption audits.
- Vetting all contracts related to brownfield remediation to prevent misallocation risk (Audit Risk 9).
- Formal sign-off on the physical/logical separation of Phase 1 commercial zone from future sovereign zones (Risk 5).

**Initial Setup Actions:**

- Retain independent external counsel specializing in French ICPE/Regulatory law.
- Establish the formal communication protocol matrix for DGSI engagement.
- Mandate the first Physical Segregation Audit schedule (bi-annual).

**Membership:**

- Head of Legal & Compliance (Chair)
- Designated DGSI Liaison Officer (Internal Security)
- External Integrity & Audit Partner (Independent)
- Environmental Compliance Specialist (External)

**Decision Rights:** Authority to halt specific workstreams (e.g., foundation pours, substation construction) pending certification of compliance with French law or security protocols. Veto power over the release of funds designated for community compensation until verified delivery (Decision 8).

**Decision Mechanism:** Unanimous agreement required for issuing 'Stop Work' or 'No-Go' advisory to the PSC on compliance matters. All other decisions require a 2/3 majority vote.

**Meeting Cadence:** Bi-monthly during Phase 0/1; Quarterly thereafter.

**Typical Agenda Items:**

- Review of DGSI Status against Security Partitioning Milestones
- Status of Permanent Ecological Offset Verification (Land Use Audit)
- Review of Whistleblower/Conflict of Interest Registry
- Compliance Checklist sign-off for next major capital release.

**Escalation Path:** Project Steering Committee (PSC) if a compliance deadlock stalls the project timeline by more than 4 weeks.

# Governance Implementation Plan

### 1. Project Sponsor formally authorizes the immediate initiation of Phase 0 activities, including the establishment of the Governance Framework and the appointment of the Formation Lead.

**Responsible Body/Role:** Executive Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Formal Project Initiation Mandate
- Designation of Project Director (CPMG Chair)
- Appointment of Interim Setup Lead (for initial drafting)

**Dependencies:**

- Project Charter Finalized (Implied from Input)

### 2. Interim Setup Lead drafts initial Terms of Reference (ToR) documents for the Project Steering Committee (PSC), Core Project Management Group (CPMG), and Regulatory & Compliance Assurance Board (RCAB), incorporating strategic decisions made (Pragmatic Scale-Up strategy).

**Responsible Body/Role:** Interim Setup Lead

**Suggested Timeframe:** Project Week 1-2

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1
- Draft CPMG ToR v0.1
- Draft RCAB ToR v0.1

**Dependencies:**

- Formal Project Initiation Mandate

### 3. Interim Setup Lead circulates draft ToRs for initial high-level review focusing on decision rights, thresholds (€500M), and membership composition.

**Responsible Body/Role:** Interim Setup Lead

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Stakeholder Feedback Summary on ToRs
- Updated Draft ToRs (v0.2)

**Dependencies:**

- Draft PSC ToR v0.1
- Draft CPMG ToR v0.1
- Draft RCAB ToR v0.1

### 4. Executive Sponsor officially appoints the Chair, CFO, CTO, and External Advisor for the Project Steering Committee (PSC).

**Responsible Body/Role:** Executive Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Formal PSC Membership Confirmation
- PSC Chair Appointment Notification

**Dependencies:**

- Updated Draft ToRs (v0.2)

### 5. The Executive Sponsor, utilizing nominations from the newly confirmed PSC, formally approves the final PSC ToR and establishes the definitive governance framework.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Approved Governance Framework Document
- Final PSC ToR (v1.0)

**Dependencies:**

- Formal PSC Membership Confirmation

### 6. Project Director (CPMG Chair) is appointed by the PSC, and the PSC confirms the initial setup actions for CPMG and RCAB.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Project Director Appointment Confirmation
- Final CPMG and RCAB ToR Approval

**Dependencies:**

- Approved Governance Framework Document

### 7. The Project Director (CPMG Chair) finalizes the detailed membership selection for the CPMG and RCAB based on ToR requirements and initiates rapid recruitment/nomination for external expert roles.

**Responsible Body/Role:** Project Director (CPMG Chair)

**Suggested Timeframe:** Project Week 6-8

**Key Outputs/Deliverables:**

- CPMG Membership Confirmation
- RCAB Membership Confirmation (including external counsel retention)

**Dependencies:**

- Project Director Appointment Confirmation

### 8. Hold the inaugural Kick-off Meeting for the Core Project Management Group (CPMG) to align on Phase 1 SMART criteria, Phase 0 deliverables, and establish tactical reporting rhythms.

**Responsible Body/Role:** Core Project Management Group (CPMG)

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- CPMG Kick-off Meeting Minutes
- Initial Phase 0 Workstream Allocation Register

**Dependencies:**

- CPMG Membership Confirmation
- Final CPMG ToR Approval

### 9. Hold the inaugural Meeting for the Regulatory & Compliance Assurance Board (RCAB). RCAB prioritizes establishing the DGSI communication protocol and finalizing the land boundary verification plan accounting for the 80% buffer zone.

**Responsible Body/Role:** Regulatory & Compliance Assurance Board (RCAB)

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- RCAB Kick-off Minutes
- DGSI Communication Protocol Matrix
- Land Integrity Audit Plan (Decision 10 mitigation)

**Dependencies:**

- RCAB Membership Confirmation
- Final RCAB ToR Approval

### 10. Hold the Inaugural Project Steering Committee (PSC) meeting. PSC formally ratifies the establishment of CPMG and RCAB, reviews Phase 0 status against Strategic Decision Matrix, and approves the initial Risk Register prioritization.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- PSC Inaugural Meeting Minutes & Ratification of Operational Bodies
- Approved Prioritized Risk Register

**Dependencies:**

- CPMG Kick-off Meeting Minutes
- RCAB Kick-off Minutes

### 11. CPMG initiates detailed modeling for the hyper-dense 32.2 km² buildable area and commits initial budget for securing preliminary Right-of-Way (ROW) easements crucial for future high-voltage transmission tie-lines (Decision 1 Linkage).

**Responsible Body/Role:** Core Project Management Group (CPMG)

**Suggested Timeframe:** Project Month 3

**Key Outputs/Deliverables:**

- Hyper-Dense Footprint Model v1.0
- ROW Application Submissions for Phase 2 Connection Points

**Dependencies:**

- Approved Prioritized Risk Register
- Assumptions Q8 Implementation Start

### 12. RCAB conducts the first mandatory Internal Security/Compliance Checkpoint, focusing specifically on the physical segregation plan for the Phase 1 500 MW commercial load relative to future sovereign zone requirements (Risk 5 mitigation).

**Responsible Body/Role:** Regulatory & Compliance Assurance Board (RCAB)

**Suggested Timeframe:** Project Month 4

**Key Outputs/Deliverables:**

- Security Separation Compliance Report v1.0
- Formal Go/No-Go Recommendation for Phase 1 Construction Start (Technical/Security Layer)

**Dependencies:**

- Lead Electrical/Grid Liaison Manager delivers initial substation demarcation plan

### 13. PSC reviews the Security Separation Report and either grants authority to commence main land remediation and grid connection feasibility studies, or mandates remediation based on RCAB findings.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Month 5

**Key Outputs/Deliverables:**

- Phase 1 Construction Start Authorization (Subject to Power/Tenant Gates)

**Dependencies:**

- Security Separation Compliance Report v1.0
- CPMG Report on Holding Cost Budget Allocation (Review Issue 2)

# Decision Escalation Matrix

**Budget Contingency Triggered for Land Holding Costs**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC review of budget variance (Review Issue 2), requiring consensus authorization for accessing the Capital Contingency Line item exceeding €500M.
Rationale: The cost of holding the 80% land buffer (a core element of the chosen pragmatic strategy) is unbudgeted. Expenditure exceeding the CPMG's operational limit (€500M tolerance) requires strategic sign-off.
Negative Consequences: Failure to approve budget leads to legal challenges or abandonment of reserved land crucial for future expansion flexibility, potentially constraining the 9 GW vision.

**RTE Refusal for Binding Phase 2 Transmission Allocation**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Mandatory immediate escalation from CPMG to PSC (as this confirms Critical Risk 3). PSC must decide whether to secure capacity via Risk Strategy Choice 1 (front-loading capital) or formally recalibrate the 9 GW timeline/scope.
Rationale: RTE's decision directly determines the viability of scaling beyond 1 GW within the 15-year timeframe and dictates the long-lead time for critical grid infrastructure (Risk 3). This exceeds CPMG tactical management.
Negative Consequences: Project schedule stalls indefinitely post-Phase 1 completion, potentially stranding Phase 1 capital if tenants withdraw due to lack of future expansion confidence.

**RCAB Veto on Phase 1 Construction Start due to Security Isolation Failure**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC must adjudicate the RCAB veto, which requires unanimous agreement from RCAB to halt work. The PSC Chair casts the tie-breaker vote after requiring a mandatory 48-hour cooling-off period.
Rationale: RCAB has explicit veto power over workstream commencement related to the security demarcation between commercial and sovereign zones (Risk 5). A veto halts critical path construction.
Negative Consequences: A multi-month delay to the Physical Segregation Audit introduces high risk of missing the 3-year Phase 1 completion target, jeopardizing tenant FID timelines.

**Proposal to Pivot from Hyper-Dense Model to Split-Campus Model**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Requires a formal recommendation from the CPMG, supported by technical verification that the 2ms RTT latency requirement can be met between clusters (Assumptions Q6), followed by a Simple Majority vote at the PSC.
Rationale: This constitutes a major change to the physical footprint rationalization strategy (Decision 2/Land Assembly Modality), impacting security perimeter design, internal logistics, and overall CAPEX estimates significantly.
Negative Consequences: Failure to achieve 2ms RTT renders the new model infeasible for core AI workloads, requiring re-design of the entire connectivity plan and potentially increasing USD hardware exposure volatility.

**Negotiated PPA terms include an EDF price structure deemed unhedgable against the Decision 4 (60% Tenant Threshold)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: CFO presents the financial impact analysis to the PSC. Approval requires a consensus decision to either accept the unhedgable risk, or use committed tenant revenue leverage to demand renegotiation with EDF/RTE.
Rationale: Power Procurement Sequencing (Decision 9) interacts directly with Tenant Acquisition Thresholds (Decision 4). If the cost structure of power contradicts the financial prudence mandated by revenue triggers, the PSC must intervene above the CPMG's financial authorization level.
Negative Consequences: Committing to a PPAs that locks in high operational costs jeopardizes the project's competitive position, potentially violating financial covenants linked to the expected ROI profile.

# Monitoring Progress

### 1. Tracking Critical Success Milestones via Phase Gates
**Monitoring Tools/Platforms:**

  - Project Steering Committee (PSC) Decision Log
  - Project Plan v1.0 Roadmap Tracking Dashboard
  - Phase Gate Acceptance Checklists

**Frequency:** Post-Milestone / Quarterly Review

**Responsible Role:** Project Steering Committee (PSC)

**Adaptation Process:** If a Phase Gate (e.g., Phase 1 FID) conditions are not met, the PSC initiates a formal reassessment, potentially triggering the 'kill criteria' or recommending a scope reduction plan to the Executive Sponsor/Board.

**Adaptation Trigger:** Failure to satisfy all required conditions, including power confirmation and 60% tenant commitment threshold, for progression to the next Phase (e.g., Phase 2 expansion FID).

### 2. Monitoring Grid Integration Certainty (Critical Risk 3)
**Monitoring Tools/Platforms:**

  - RTE/EDF Correspondence Log
  - Electrical/Grid Liaison Manager Weekly Status Report
  - Power Procurement Sequencing Compliance Tracker

**Frequency:** Weekly (Phase 0/1); Bi-weekly (Pre-Phase 2 FID)

**Responsible Role:** Core Project Management Group (CPMG) / Lead Electrical Manager

**Adaptation Process:** If RTE engagement indicates delays beyond the 36-month assumed buffer (Review Issue 1), the CPMG escalates immediately to the PSC to negotiate a binding amendment to the Tenant Acquisition Trigger Threshold (Decision 4) via a 'Power Readiness Lockout Clause'.

**Adaptation Trigger:** Any official communication from RTE signaling a delay in transmission impact study completion or confirming a grid upgrade timeline exceeding 36 months post-Phase 2 FID.

### 3. Tracking Sovereign AI Alignment and Security Isolation (Critical Risk 5)
**Monitoring Tools/Platforms:**

  - Security Separation Compliance Report v1.0 (from RCAB)
  - DGSI/ANSSI Communication Matrix
  - Physical Segregation Audit Schedule

**Frequency:** Bi-monthly (via RCAB)

**Responsible Role:** Regulatory & Compliance Assurance Board (RCAB)

**Adaptation Process:** If RCAB issues a 'No-Go' advisory due to inadequate physical isolation of the first 500 MW load, the CPMG must halt all related physical construction until remediation is certified. Failure to resolve within 4 weeks mandates escalation to the PSC (as per Escalation Matrix).

**Adaptation Trigger:** Negative finding on the Security Separation Compliance Report (v1.0 or subsequent audits) or failure to receive required protocol sign-off from DGSI by specified checkpoint dates.

### 4. Land Control and Buffer Zone Integrity Monitoring
**Monitoring Tools/Platforms:**

  - Land Integrity Audit Plan Report (RCAB)
  - ROW Application Status Tracker
  - Quarterly Land Holding Cost Reconciliation Statement

**Frequency:** Quarterly

**Responsible Role:** Regulatory & Compliance Assurance Board (RCAB)

**Adaptation Process:** If Land Holding Costs exceed the budgeted contingency, the CPMG must present a plan to the PSC to reclassify 50% of the 'Permanent Ecological Offset' buffer to 'Phase 2/3 Expansion Reserve' status to reduce ongoing holding expenses (Review Issue 2).

**Adaptation Trigger:** Quarterly reconciliation shows holding costs exceeding 15% cumulative variance, or if a local judicial challenge targets the legal designation of the permanent buffer zones.

### 5. Tenant Commitment Monitoring (Decision 4)
**Monitoring Tools/Platforms:**

  - Contract Status Tracker (Take-or-Pay Commitments)
  - Financial Modeling Dashboard (Leveraging committed revenue for debt structuring)

**Frequency:** Monthly

**Responsible Role:** CFO / Project Steering Committee (PSC)

**Adaptation Process:** If committed take-or-pay revenue falls below 40% of the next tranche's required anchor (60% threshold), the PSC must formally suspend all financing activities related to Phase 2 infrastructure (e.g., grid link advancement) and initiate renegotiation efforts with existing anchor tenants to raise commitment levels.

**Adaptation Trigger:** Tenant commitment percentage falls below the 60% threshold required for Phase 2 expansion FID, or if existing tenants provide notice of withdrawal.

### 6. Workforce Uplift & Social License Performance Check
**Monitoring Tools/Platforms:**

  - Local Workforce Quota Report (CPMG)
  - Skills Academy Enrollment & Certification Log
  - Heat Reuse Feasibility Study Progress Report

**Frequency:** Monthly

**Responsible Role:** Core Project Management Group (CPMG) / Compliance Coordinator

**Adaptation Process:** If actual local specialty hire rates lag behind the planned velocity (e.g., <30% specialty hires in Year 1, Review Issue 3), the CPMG must immediately draw down the dedicated workforce contingency budget (€20M-€40M) to hire short-term specialized management teams to oversee local training.

**Adaptation Trigger:** Failure to meet quarterly targets for required local apprentice enrollment or securing the first binding Heat Reuse off-take agreement.

# Governance Extra

## Governance Validation Checks

1. Completeness Confirmation: All major requested components (Bodies, Implementation Plan, Escalation Matrix, Monitoring Plan) appear to be generated.
2. Internal Consistency Check: The framework is highly consistent; the 'Pragmatic Scale-Up' strategy dictated the conservative nature of the governance (e.g., soft power commitment for Phase 1) and is enforced in the bodies' responsibilities (PSC enforces Gate Approvals) and the Monitoring Plan (Gate tracking). The RCAB's focus on land integrity directly reflects the critical risk identified around the 80% buffer zone.
3. Potential Gaps / Areas for Enhancement 1: The role and authority of the 'Independent External Governance Advisor' on the PSC are listed as 'Voting member, focused on fiduciary duty,' but their specific mechanism for raising dissenting fiduciary warnings outside of the standard vote (e.g., reporting directly to shareholders on ethical concerns) is unclear.
4. Potential Gaps / Areas for Enhancement 2: The implementation plan (Stage 3) focuses heavily on setup (Weeks 1-12). There is insufficient detail on the *ongoing* process for how the CPMG reports findings/variances from the complex technical models (PUE, Water, Inter-Cluster Latency) *into* the RCAB for specialized assurance review.
5. Potential Gaps / Areas for Enhancement 3: Decision thresholds are defined (e.g., PSC decision limit €500M), but the process for **delegation of authority below the CPMG** (e.g., to site managers or procurement leads) for routine, low-impact decisions that would otherwise clog the CPMG cycle is missing.
6. Potential Gaps / Areas for Enhancement 4: The accountability for tracking and executing the formal FX hedging strategy (USD exposure) is implied within the Finance function (CFO on PSC/CPMG) but does not have a dedicated tracking role or explicit checkpoint within the RCAB or CPMG routines, despite being a Critical Risk (Risk 4).
7. Potential Gaps / Areas for Enhancement 5: While Decision 10 requires defining buffer land usage (Permanent Offset vs. Expansion Reserve), the mechanism for the *annual reassessment* of the Expansion Reserve flexibility, particularly how the PSC authorizes a shift away from 'Permanent' status, lacks a specific trigger or explicit review step in the Monitoring Plan.

## Tough Questions

1. What is the specific, contractually defined mechanism and timeline (in months) required for RTE to confirm the binding 3 GW transmission allocation *after* Phase 2 FID is triggered by the 60% tenant commitment (Decision 4)? Does the 36-month buffer assumption (Review Issue 1) incorporate regulatory grace periods, and if so, where is this validated internally?
2. Given the 'hyper-dense' model mandates 80% of the 161 km² as buffers, what is the audited, year-on-year holding cost for the 128.8 km² of land, and what specific line item in the budget (Phase 0/1 CAPEX) is strictly ring-fenced to cover this cost, distinct from remediation or compute CAPEX, referencing Assumption Issue 2?
3. What are the documented, legally binding 'kill criteria' referenced in the Monitoring Plan? Specifically, if the DGSI veto (Escalation Matrix) or a PUE failure (>1.25) occurs, what is the maximum allowable remediation timeline before the PSC must trigger project cancellation or radical downsizing (as allowed by the 'red-team' mandate)?
4. The RCAB has veto power over construction start based on security isolation. Detail the exact demarcation point (e.g., physical fencing breach, substation breaker status) that constitutes a failure under Risk 5, and quantify the financial penalty or schedule slip incurred for every week construction is halted awaiting RCAB sign-off.
5. Since Phase 1 relies on non-binding consultation for power, what specific collateral funds (EUR amount) have been legally ring-fenced and documented as available to meet RTE’s potential capital contribution request should RTE mandate upfront funding triggers contradicting the 'No Grid Pre-Commitment' posture (Decision 9)?
6. To validate the 60% tenant commitment threshold (Decision 4), provide the legal structure of the required 'take-or-pay' contracts. Are they subject to standard force majeure provisions, or do they contain specific, punitive clauses if the *developer* fails to deliver capacity due to unanticipated French regulatory delays (e.g., RTE or permit stalls)?
7. How does the CPMG ensure the integrity of the aggressive local workforce uplift (Decision 8) without inflating the PUE ceiling of 1.20 due to inexperienced labor managing complex liquid cooling systems? Provide the variance tolerance in management overhead cost budgeted to mitigate this velocity risk (Assumption Issue 3) versus the cost of importing skilled oversight.

## Summary

The governance framework implements a robust, risk-averse 'Pragmatic Scale-Up' methodology, effectively enforcing skepticism by linking major expansions to binding external validations (power commitments) and high tenant revenue hurdles (60% threshold). Key strengths lie in the clear separation of strategic oversight (PSC) and dedicated compliance assurance (RCAB), directly addressing the high regulatory and security risks inherent in the 9 GW French deployment. However, the framework remains heavily exposed to external timelines, particularly RTE lead times and the cost/viability of the massive planned land buffers, necessitating immediate quantification of regulatory buffers and land holding costs.