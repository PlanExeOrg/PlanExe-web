## Positive Constraints

- Establish an intentionally extreme hyperscale AI data center campus
- Location: Hauts-de-France, France
- Focus on industrial AI belt around Cambrai / E-Valley, Valenciennes / Denain / Escaudain, Dunkirk, Saint-Omer
- Notional footprint: 12.7 km × 12.7 km
- Notional footprint: approximately 161 km² / 40,000 acres
- Full-buildout power target: 9 GW
- Timeline: 10–15+ years
- Phase 1 power: 500 MW–1 GW
- Use: high-density GPU/TPU clusters for AI training, fine-tuning, batch inference, sovereign AI, and selected enterprise inference
- PUE target: 1.15–1.25
- Cooling: direct-to-chip liquid cooling by default
- Cooling: optional 50–100 MW immersion cooling pilot
- Water strategy: prefer zero- or ultra-low-water cooling
- Power strategy: French low-carbon grid, nuclear-backed contracts, EDF/RTE coordination, PPAs, BESS, grid flexibility, and limited backup generation
- Connectivity: diverse fiber to Paris, London, Brussels, Amsterdam, Frankfurt, Marseille, and subsea/transatlantic routes
- Security: national-security review, hardened perimeter, cyber/OT separation, anti-drone systems, supply-chain security, and resilience against sabotage or grid/fiber disruption
- Building height: typical height 14–20 m
- Building height: maximum height 25–30 m
- Building size: individual halls 20,000–100,000 m², with some up to 150,000+ m²
- Full buildout: 50–100+ major buildings
- Land-use model must cover data halls, substations, BESS, backup generation, roads/logistics, fiber corridors, stormwater, biodiversity buffers, heat-reuse infrastructure, security setbacks, expansion reserve, community buffers, agricultural or ecological continuation zones, and brownfield remediation zones
- Budget Phase 0 feasibility/site control: €250M–€750M
- Budget Phase 1 (500 MW–1 GW): €5B–€10B
- Budget Expansion to 3 GW: €25B–€45B
- Budget Full 9 GW buildout: €100B–€140B+
- Currency: EUR as the primary currency
- Track USD exposure separately for GPUs/TPUs, networking hardware, selected software, and international vendor contracts
- Phase 0: Years 0–1 (Feasibility, site control, land assembly, grid hosting capacity, EDF/RTE engagement, cooling/water feasibility, environmental baseline, community risk, fiber feasibility, anchor tenant validation, financing pre-commitments, permitting path, national-security review, and no-build alternative)
- Phase 1: Years 1–3 (Build 500 MW–1 GW with 8–20 data halls, dedicated substation, BESS/backup, liquid-cooling loop, diverse fiber, hardened perimeter, first tenants, public benefit agreement, local workforce program, and environmental monitoring)
- Phase 2: Years 3–7 (Scale to 1–3 GW with more halls, additional substations, transmission upgrades, heat-reuse pilots, expanded fiber, supplier ecosystem, and public-benefit payments)
- Phase 3: Years 7–11 (Scale to 3–6 GW with sovereign AI zones, high-security compute partitions, standardized liquid cooling, resilience testing, and lifecycle replacement planning)
- Phase 4: Years 11–15+ (Reach 9 GW)
- Today's date: 2026-May-16

## Negative Constraints

- Treat this as a red-team planning scenario: the plan must be rigorous, skeptical
- Plan must recommend downsizing, splitting the campus, delaying expansion, or cancelling the project if feasibility fails
- Do not assume the answer to feasibility is yes
- Do not invent binding commitments from RTE, EDF, DGSI, ANSSI, tenants, municipalities, or prefectural authorities
- Treat all external approvals, grid commitments, security clearances, tenant contracts, and public-sector commitments as uncertain until the plan defines a realistic process to obtain them
- Do not assume most of the 161 km² should be buildings
- Do not assume water cooling is okay: treat freshwater or evaporative cooling as high-risk
- The output must be skeptical, not promotional
- The output must identify what would make the project infeasible
- The output must identify what must be proven before serious capital is committed
