# Purpose
# Project Plan Summary

## Purpose

- Business: Strategic planning and feasibility assessment.

## Topic

- Development of an intentionally extreme hyperscale AI data center campus (9 GW) in Hauts-de-France, France.


# Domain
# Project Planning Summary

## Rationale

- Primary Domain: Data Center Infrastructure Planning (defined by 9 GW campus scope/scale/feasibility).
- Secondary Domains: Electrical Power Engineering, French Regulatory Compliance.
- Land Development supports central planning.

## Disciplines Involved

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|

- Data Center Infrastructure Planning | 5 | 5 | outcome | Project defined by hyperscale DC planning/execution. |
- French Regulatory Compliance | 5 | 5 | constraint | Permitting, environmental law, security reviews are critical blockers. |
- Energy Grid Management | 5 | 5 | constraint | 9 GW power depends on French grid feasibility/coordination. |
- Electrical Power Engineering | 5 | 4 | constraint | Sourcing/integrating 9 GW power is a critical bottleneck. |
- Large Scale Land Development | 4 | 4 | method | Modeling 161 km² across zones is core planning. |
- Telecommunications Infrastructure | 4 | 4 | method | Diverse, low-latency fiber is essential for AI compute. |
- Urban and Regional Planning | 4 | 4 | outcome | Land parcel assembly and zoned land-use model require expertise. |
- Real Estate Acquisition | 4 | 4 | method | Assembling 161 km² requires specialized methods. |
- Environmental Impact Assessment | 4 | 4 | constraint | Water, biodiversity, remediation are key feasibility/permitting constraints. |


# Plan Type
# Project Classification

- Requires one or more physical locations.
- Cannot be executed digitally.

# Explanation

- Multi-year strategy focused on physical execution: building a massive data center campus (161 km²) in Hauts-de-France, France.
- Involves massive physical construction, land acquisition/assembly (161 km²).
- Coordinates multi-gigawatt electrical infrastructure (9 GW).
- Manages physical cooling systems (liquid cooling loops).
- Establishes physical fiber routes.
- Deals with brownfield remediation.
- Navigates physical permitting processes localized to specific parcels of land.
- Plan is overwhelmingly dedicated to overcoming rigorous physical, engineering, logistical, and regulatory hurdles required to place compute in the real world.


# Physical Locations
# Project Plan - Location Requirements

## Requirements for physical locations

- Footprint: 161 km² (30 km² buildable)
- Power: Access to 9 GW contracted, reliable, low-carbon/nuclear-backed post-Phase 2
- Proximity: Existing industrial revitalization zones (Cambrai, Dunkirk, Valenciennes)
- Cooling: Favorable climate (low high-water cooling risk)
- Latency: Strategic to Paris, London, Brussels, Frankfurt via diverse fiber
- Land: Suitable brownfield/industrial for remediation and large-scale development

## Location 1
France
Hauts-de-France Region: Cluster 1 (E-Valley/Cambrai)

- Land near Cambrai or Valenciennes (brownfield redevelopment).
- Rationale: Targets industrial redevelopment, high initial velocity for land assembly (1 GW phase) using existing logistics.

## Location 2
France
Hauts-de-France Region: Cluster 2 (Dunkirk Port Area)

- Industrial/reclaimed land near Port of Dunkirk.
- Rationale: Access to heavy logistics, potential maritime fiber, heat-reuse partners, or diverse power interconnection.

## Location 3
France
Hauts-de-France Region: Buffer/Expansion Reserve Zones

- Agricultural/ecological buffer parcels adjacent to Clusters 1 and 2.
- Rationale: Supports 'hyper-dense development model'; preserves 80% of 161 km² as non-buildable buffer/expansion reserve, mitigating sprawl/impact, maintaining expansion option up to 9 GW over 15 years.

## Location Summary
Targets Hauts-de-France, France (Cambrai, Valenciennes, Dunkirk zones). Three locations align with Skeptical Path: two primary clusters for dense buildout, one adjacent area for mandated ecological/community buffers (80% of 161 km²).

# Currency Strategy
# Currencies

- EUR: Primary for land, labor, local taxes, grid connection (project location: France).
- USD: Hardware procurement (GPUs/TPUs, networking) and international financing exposure.

Primary currency: EUR

Currency strategy:

- EUR for budgeting, accounting, reporting (local costs).
- Track USD exposure from hardware procurement.
- Implement formal FX hedging strategy (e.g., forward contracts) for major USD hardware purchases starting Phase 1.


# Identify Risks
# Project Risks and Mitigation

## Risk 1 - Regulatory & Permitting
Failure to secure land assembly consents/permits for fragmented development in Hauts-de-France. Legal challenges over buffer zone designation (Decision 2 - Choice 2) could stop construction.

- Impact: 12–24 month delay to Phase 1 FID; €500M–€1B overrun; forced buildable area reduction (<15 km² from 30 km²).
- Likelihood: High
- Severity: High
- Action: Proactively engage DREAL/DDETSPP for 'Projet d'Intérêt Général' (PIG) status for critical infrastructure; treat buffer zones as non-negotiable early concessions.

## Risk 2 - Technical
Inability to meet aggressive PUE target of 1.15–1.25 at 1 GW+ using default direct-to-chip liquid cooling at scale in brownfield deployment.

- Impact: PUE increase of 0.1 (1.25–1.35 average); €5M–€10M annual energy cost increase at 1 GW; potential violation of PUE clauses tied to anchor tenants (Decision 4).
- Likelihood: Medium
- Severity: Medium
- Action: Pilot liquid cooling validation via digital twins during design. De-risk Phase 1 with performance-based escalator clauses for anchor tenants if PUE misses target by >0.05 due to integration issues.

## Risk 3 - Financial
Sunk capital if RTE/EDF cannot confirm capacity for Phase 2 (3 GW) before Phase 1 (1 GW) financing closes (Decision 1 - Choice 2).

- Impact: Inability to secure binding transmission allocation could halt project, potentially stranding €1B–€2B Phase 0/1 capital if tenants withdraw.
- Likelihood: High
- Severity: High
- Action: Strictly adhere to Pragmatic Scale-Up: no Phase 2 expansion funding (beyond studies) until RTE provides a formal, legally binding contract for required transmission upgrades.

## Risk 4 - Supply Chain
Exposure to USD/EUR exchange rate volatility affecting hardware procurement despite hedging.

- Impact: If EUR depreciates >10% vs. USD, hardware costs could inflate by €8B–€15B on the €100B-€140B budget for 9 GW buildout.
- Likelihood: Medium
- Severity: High
- Action: Implement multi-year forward hedging for 70% of USD hardware needs (Phase 1 & 2). Require Phase 1 tenants to contract in EUR-equivalent terms to pass on minor FX deviation risk.

## Risk 5 - Operational / Security
Failure to secure DGSI/ANSSI protocols and sign-off on sovereign AI partition (Decision 3) before leasing 500 MW, risking denial of state contracts.

- Impact: Loss of premium domestic revenue stream, jeopardizing 60% commitment threshold for Phase 2 (Decision 4); potential loss of €10B–€20B in long-term contracted revenue.
- Likelihood: Medium
- Severity: High
- Action: Isolate initial 500 MW cluster from planned sovereign zone. Proactively engage DGSI in Phase 0/1 with detailed security schematics, integrating Layer 1 physical segregation into initial substation planning.

## Risk 6 - Environmental / Water
Hydrological constraints in Hauts-de-France making 'ultra-low-water' cooling non-viable or prohibitively expensive.

- Impact: If evaporative cooling is needed, water consumption may trigger regional restrictions, leading to mandatory curtailment (€1M–€5M penalty per week).
- Likelihood: Medium
- Severity: Medium
- Action: Mandate zero-water density heat rejection (e.g., dry coolers) for 100% of Phase 1, accepting temporary PUE degradation (max 1.20) until water sustainability is proven.

## Risk 7 - Social / Policy
Public opposition or judicial appeal on the 'hyper-dense development model' sacrificing 80% of land for buffers (Decision 2, Choice 2 & Decision 10).

- Impact: Prefecture could reduce buildable area to <20 km², constraining 9 GW target to 3–4 GW, forcing business case re-evaluation.
- Likelihood: High
- Severity: High
- Action: Aggressively implement Decision 8 (Workforce Uplift) and Decision 6 (Heat Reuse) in Phase 0. Use buffer land for tangible community benefits (e.g., local solar farm) to gain stakeholder cooperation.

## Risk 8 - Technical / Integration
Latency incompatibility between terrestrial fiber routes (Decision 5) and synchronized AI training needs across Paris/London/Brussels network (sub-millisecond consistency).

- Impact: Latency >1.5ms (terrestrial RT to Paris) may allow tenant SLA breach claims, risking contract loss if dark fiber/subsea investment is deferred until Phase 3.
- Likelihood: Medium
- Severity: Medium
- Action: Task specialists for independent, real-time latency benchmarking. If results are below requirement, commit Phase 1 CAPEX to securing dark fiber rights-of-way for the Phase 2 path, accepting conflict with Power Procurement Sequencing.

## Risk 9 - Financial / Budgeting
Underestimation of Brownfield Remediation Costs due to industrial history (steel, refinery, military zones).

- Impact: Remediation costs (€250M–€750M budget) could double/triple (€500M–€2.25B) if hazardous materials require advanced handling, delaying data hall construction start.
- Likelihood: Medium
- Severity: Medium
- Action: Dedicate 80% of Phase 0 budget to comprehensive environmental testing and risk modeling. Secure fixed-price remediation contracts with regional specialists before land assembly finalization.

## Risk Summary
Project profile is extremely high-risk, dominated by regulatory uncertainty and interdependent critical path items. 'Pragmatic Scale-Up' strategy reduces immediate financial exposure but elevates risk of political/social blockage due to land rationalization (80% buffers).

Critical Risks:
1. Regulatory Delays (High/High): Judicial review of fragmented development could halt progress.
2. RTE/Grid Confirmation (High/High): Deferring grid investment until Phase 2 FID risks stranding Phase 1 capital if capacity confirmation is delayed.
3. Social License Erosion (High/High): Failure of Workforce Uplift/Heat Reuse monetization risks political rejection or mandated footprint reduction, undermining 9 GW goal.

Mitigation overlap exists: successful social license programs support faster regulatory permitting. Core trade-off remains speed (AI market need) versus financial prudence (mandate).

# Make Assumptions
## Question 1 - Quantified Footprint Allocation

- Target buildable area (20% hyper-dense model): 32.2 km² (Data center/substations)
- Essential buffer/community/ecological zones (80%): 128.8 km²
- Assessments: Land Use Feasibility

    - Allocating 80% mitigates local opposition but reduces initial 15-year capacity.
    - Benefit: Streamlines permitting for the 20% core.
    - Risk: Fails if anchor tenants require contiguous expansion, requiring split-campus review.
    - Opportunity: Buffer allows long-term expansion for heat exchange/water management.

## Question 2 - Binding Go/No-Go Trigger for Phase 2 Transmission Upgrades

- Explicit trigger: Execution of signed, take-or-pay, non-cancellable Power Purchase Agreements covering 60% of the 2 GW expansion tranche.
- Assessments: Grid Investment Control

    - Links financial sign-off to physical grid commitment.
    - Risk: Stranded capital if RTE demands commitment before the 60% tenant threshold.
    - Benefit: Infrastructure investment scales directly with bankable revenue.

## Question 3 - Specific EUR Public Benefit Commitment Locked in Phase 0

- Commitment: Mandatory minimum of 5% of Phase 0 budget (€12.5M–€37.5M) allocated for initial operational funding of the regional skills academy and feasibility studies for the heat-reuse industrial partner.
- Assessments: Social License Stabilization

    - Front-loading visible benefits mitigates social risks (Risk 7).
    - Benefit: Turns opposition into cooperation, accelerating permitting.
    - Risk: Commitments must be non-binding to maintain efficacy.

## Question 4 - Projected Maximum Operational PUE for Phase 1

- Projected Maximum Operational PUE: 1.20 (includes BESS losses, liquid cooling mandate).
- Assumptions: Liquid cooling optimized for 1.15 target; BESS losses estimated at 2%.
- Assessments: Efficiency and Operational Cost Performance

    - Risk: PUE > 1.25 increases operational costs by ~€5M/GW/year.
    - Opportunity: Achievable PUE justifies liquid-cooling CAPEX.

## Question 5 - Projected EUR Cost Variance Based on 10% Unfavorable FX Shift

- Projected Cost Variance: Approximately €4.32 Billion (unhedged portion).
- Assumptions: 30% of €120B CAPEX is USD-denominated hardware; 70% hedged.
- Assessments: Financial Exposure and Hedging Efficacy

    - Residual exposure mandates contingency budgeting.
    - Benefit: Mandates immediate execution of forward contracts upon Phase 1 pricing lock.
    - Risk: Unhedged exposure requires contingency line item for debt servicing covenants.

## Question 6 - Minimum Acceptable Latency Deviation for Split-Campus Synchronization

- Minimum Latency: Below 2ms round-trip time (RTT) between Cluster 1 and Cluster 2.
- Assumptions: Requires dedicated, privately leased, high-grade terrestrial fiber paths.
- Assessments: Inter-Campus Synchronization Viability

    - If 2ms RTT fails, the split-campus model is unviable for demanding AI workloads.
    - Opportunity: If met, enables decoupling of regulatory/power risks.

## Question 7 - Initial 500 MW Hardware Procurement and DGSI Assurance

- Hardware Focus: Commercial-grade, non-restricted AI accelerators for Phase 1.
- Assurance Method: Hardware housed in physically separate buildings with legally ring-fenced primary substation capacity (Substation 1 isolated from Sovereign Zone substations).
- Assessments: Security Isolation and Initial Revenue Path

    - Benefit: Allows immediate revenue generation while sovereign zone designs are reviewed.
    - Risk: 'Non-classified' definition must be formally agreed in Phase 0 to prevent retrofitting.

## Question 8 - Temporary Land-Use Mechanism Secured in Phase 0 for Future Interconnection Points

- Mechanism: Preliminary right-of-way (ROW) easements secured for Phase 2 required expansion substations and tie-lines, including adjacent buffer land.
- Assessments: Long-Lead Physical Infrastructure Control

    - Securing ROW is a long-lead permitting activity decoupled from financing trigger.
    - Failure transforms grid uncertainty (Risk 3) into a physical blocker.
    - Benefit: Buffers implementation schedule against utility's internal timeline.

# Distill Assumptions
# Project Plan Summary

## Area & Buffers

- Buildable area: 32.2 km² (20% of 161 km²)
- Buffers: 80% reserved

## Funding & Tranches

- Phase 2 transmission funding triggers at 60% take-or-pay contracts for 2 GW tranche.

## Phase 0 Allocations

- 5% of initial budget for local skills academy.
- Heat-reuse feasibility studies.
- Secure preliminary right-of-way easements for Phase 2 transmission upgrades.

## Phase 1 Targets & Requirements

- Operational PUE target: 1.20 (conservative).
- Cooling: Mandatory direct-to-chip liquid cooling.
- Hardware isolation: Phase 1 commercial hardware must be physically isolated via separate substation capacity from future sovereign zones.

## Technical Requirements

- Inter-cluster latency (split campuses): Below 2ms RTT for synchronized AI workloads.

## Risks

- Financial Risk: 10% EUR/USD unfavorable shift creates approx. €4.32 Billion unhedged hardware cost exposure.


# Review Assumptions
## Domain of the expert reviewer
High-Scale Infrastructure Project Planning and Feasibility Assessment

## Domain-specific considerations

- Grid Interconnection Lead Times (RTE/EDF)
- French Regulatory/Sovereignty Alignment (DGSI/ANSSI)
- Large-Scale Land Assembly and Zoning Complexity (161 km²)
- Capital Allocation Sequencing vs. Revenue Triggering
- Workforce Development for Specialized Infrastructure

## Issue 1 - Critical Missing Assumption: Regulatory Time Buffer (RTE/Permitting)

- Plan uses 'Pragmatic Scale-Up' (deferring Phase 2 funding until 60% tenant commitment).
- Missing assumption: Explicit RTE approval/upgrade completion time after funding commitment (3-5 years typical).
- Dependency gap: Tenants commit based on power availability, but infrastructure completion is external.
- Recommendation: Assume minimum 36-month completion for RTE upgrades post-Phase 2 FID. Adjust Tenant Acquisition Trigger Threshold (Decision 4) with 'Power Readiness Lockout Clause': Phase 2 COD = Min(Tenant Anchor COD + 12 months, RTE Upgrade Completion Date).
- Sensitivity: 18-month vs 36-month grid lead time increases delay by 1.5 years, losing 8-12% ROI over four years, increasing CoC by €500M–€800M.

## Issue 2 - Under-Explored Assumption: Financial Viability of 80% Land Buffer

- Model reserves 80% (128.8 km²) as buffer/reserves (32.2 km² buildable).
- Assumption: Preserves optionality/smooths permitting.
- Viability hinges on holding cost coverage (operating budget vs. capitalized).
- Risk: Legally holding 80% as 'permanent ecological preservation' for 15 years without binding community benefit contracts (Decision 6) is questionable.
- Recommendation: Explicitly budget holding cost for 128.8 km² (€50k–€75k/ha annually). Decouple permanence: Reclassify 50% buffer as 'Phase 2/3 Expansion Reserve' (annual renewal) and 30% as 'Permanent Ecological Offset' (upfront, binding commitments via Decision 10).
- Sensitivity: Undershooting annual holding cost by €20k/ha risks €1.3B overrun in early CAPEX. Loss of 10 km² buildable area due to disputes reduces capacity from 9 GW to ~6 GW, decreasing potential ROI by 30-40%.

## Issue 3 - Unrealistic Assumption: Workforce Skill Uplift Velocity

- Decision 8 mandates 75% local workforce sourcing via apprenticeships for social license.
- Assumption ignores skill generation time from vocational schools (Decision 3/8) needed for specialized liquid-cooled DCs and DGSI isolation checks.
- Risk: Underestimates management overhead and quality control risks of unproven upskilling.
- Recommendation: Introduce staffing latency: Assume 30% local specialty hire in Year 1, rising to 50% in Year 2. Rely on higher-cost international contractors initially. Integrate contingency budget (€20M–€40M) for importing specialized management teams to oversee training.
- Sensitivity: Labor unavailability could extend Phase 1 (1 GW) from 24 months to 30-36 months. This 6-12 month delay plus management costs (€50M–€100M) reduces NPV by 4-6%.

## Review conclusion

- Plan is strategically sound (phased approach identified interdependencies).
- Execution timeline is overly optimistic regarding external dependencies.
- Critical weaknesses identified via quantified missing assumptions:

1. Missing Grid Completion Buffer: Poses 1.5-year revenue delay risk due to unbuffered RTE execution time.
2. Uncosted Land Holding: Massive 80% buffer lacks budget, risking €1.3B early CAPEX overrun.
3. Workforce Optimism: Rapid local upskilling risks 6-12 month technical delays in Year 1 impacting early ROI.

- Immediate Action: Lock in regulatory timing buffers, fully budget land holding costs, accept higher initial construction costs/delays for genuine local workforce integration.
