
## Question 1 - What is the quantified breakdown of the 161 km² footprint allocation, specifying the target buildable area (data center/substations) versus the essential buffer/community/ecological zones for the hyper-dense model?

**Assumptions:** Assumption: Based on the 'hyper-dense development model' (20% buildable), the target physical buildable area for data halls, substations, and critical infrastructure is approximately 32.2 km² (20% of 161 km²), with the remaining 128.8 km² allocated to non-buildable buffers and expansion reserve as identified in the land use strategy.

**Assessments:** Title: Land Use Feasibility Assessment
Description: Evaluation of the physical practicality of assembling and zoning the designated hyper-dense-plus-buffer footprint.
Details: Allocating 80% to buffers severely mitigates local opposition (Risk 7) but reduces the ultimate capacity threshold achievable within the initial 15 years. Benefit: Streamlines permitting velocity for the 20% core footprint. Risk: If anchor tenants demand contiguous, expansive deployment, this model fails, requiring a split-campus review. Opportunity: The 128.8 km² buffer provides significant long-term flexibility for heat exchange/water management infrastructure expansion without requiring new land acquisition.

## Question 2 - Given the 'Pragmatic Scale-Up' strategy, what is the explicit, legally defined milestone (outside of EDF/RTE internal timelines) that will serve as the binding **Go/No-Go** trigger for funding Phase 2 transmission upgrades (Grid Integration Decision 1)?

**Assumptions:** Assumption: The binding trigger for committing capital to Phase 2 (3 GW) transmission upgrades will be the execution of signed, take-or-pay, non-cancellable Power Purchase Agreements covering 60% of the 2 GW expansion tranche, independent of RTE's internal construction schedule.

**Assessments:** Title: Grid Investment Control Assessment
Description: Analysis of the financial linkage between tenant revenue commitment and major capital expenditure on external grid infrastructure.
Details: This links the financial decision gate (Tenant Trigger Threshold) directly to the physical grid commitment, adhering to the skeptical mandate. Risk: If RTE requires definitive capital commitment for grid prep *before* the 60% tenant threshold is met, the project faces stranded capital risk (Risk 3). Benefit: Ensures infrastructure investment scales directly with bankable revenue signals.

## Question 3 - What specific EUR-denominated public benefit commitment or infrastructure investment (e.g., workforce training funding, heat exchange partnership capital) will be contractually locked in during Phase 0 to immediately satisfy community concerns regarding land use and workforce displacement (Decision 10)?

**Assumptions:** Assumption: Phase 0 budget (€250M–€750M) will allocate a mandatory minimum of 5% (€12.5M–€37.5M) towards initial operational funding for the regional skills academy (Decision 8) and feasibility studies for the identified heat-reuse industrial partner near Dunkirk (Decision 6).

**Assessments:** Title: Social License Stabilization Assessment
Description: Evaluation of immediate investment required to secure the political/social operating environment for the 15-year plan.
Details: Front-loading small, visible, tangible benefits (jobs/heat study) mitigates high-likelihood social risks (Risk 7). Benefit: Turns local opposition into negotiated cooperation, accelerating permitting velocity through prefectural support. Risk: If the commitments are non-binding, they lose efficacy rapidly; mandatory allocation within Phase 0 ensures seriousness.

## Question 4 - What is the projected maximum operational PUE (including BESS and ancillary power losses) expected for the Phase 1 build, considering the mandated default liquid cooling system and the rejection of high-water-use cooling methods (Risk 6 mitigation)?

**Assumptions:** Assumption: Full utilization of direct-to-chip liquid cooling, optimized for the 1.15 target, coupled with BESS charging/discharging efficiency losses (estimated at 2% overhead), results in a conservative Phase 1 operational PUE target of 1.20, even if the 1.15 goal is missed initially.

**Assessments:** Title: Efficiency and Operational Cost Performance
Description: Verification of the expected energy efficiency based on technology choices and risk mitigation strategies.
Details: A 1.20 PUE is achievable but requires precise integration of liquid cooling manifolds without significant parasitic losses from pumps or HVAC for non-IT load. Risk: If PUE exceeds 1.25 (Risk 2), long-term operational costs increase by ~€5M/GW/year, impacting contract profitability. Opportunity: Maintaining near-target PUE justifies the higher liquid-cooling CAPEX compared to alternatives.

## Question 5 - What is the projected EUR cost variance for the full 9 GW buildout (€100B–€140B+) if the EUR/USD exchange rate shifts unfavorable by 10% relative to the Phase 0 baseline, assuming only 70% of anticipated USD hardware expenditure is hedged?

**Assumptions:** Assumption: Based on a €120B total budget (midpoint) and assuming 30% of total CAPEX is USD-denominated hardware subject to FX changes, a 10% unfavorable shift translates to an additional gross cost impact of approximately €4.32 Billion (0.30 * 120B * 0.10).

**Assessments:** Title: Financial Exposure and Hedging Efficacy
Description: Quantifying the remaining FX risk after applying the mandated 70% hedge strategy.
Details: The residual €4.3B exposure highlights that the 70% hedge is insufficient to fully de-risk the project's largest variable cost category (hardware). Benefit: This projection mandates immediate execution of the forward contract strategy immediately upon locking in Phase 1 pricing. Risk: Unhedged exposure of this magnitude necessitates a dedicated budget contingency line item to absorb potential volatility impacting debt servicing covenants.

## Question 6 - Since the split-campus model (Decision 2) is favored over contiguous assembly, what is the minimum acceptable latency deviation between the two primary industrial clusters (Cluster 1: Cambrai/E-Valley and Cluster 2: Dunkirk) to ensure functional synchronization for synchronized AI workloads?

**Assumptions:** Assumption: Due to the 50–70 km separation between the primary clusters, the required inter-site latency must be maintained below 2ms round-trip time (RTT) for synchronized AI operations, necessitating dedicated, privately leased, high-grade terrestrial fiber paths between the two locations.

**Assessments:** Title: Inter-Campus Synchronization Viability
Description: Assessment of the technical feasibility of maintaining critical synchronization latency across the decentralized physical model.
Details: If the required 2ms RTT cannot be met via direct terrestrial connection between Cluster 1 and 2, the split-campus model becomes functionally unviable for demanding AI workloads, forcing a centralization that conflicts with the land assembly strategy. Opportunity: If met, this enables decoupling of regulatory/power risks between the two sites.

## Question 7 - Where specifically will the initial 500 MW Phase 1 construction focus its hardware procurement (GPUs/TPUs) to satisfy the 'non-classified commercial tenants' requirement, and how will DGSI assurance be provided that this initial cluster is physically isolated from any future sovereign zones?

**Assumptions:** Assumption: Phase 1 hardware will utilize commercial-grade, non-restricted AI accelerators (e.g., current generation enterprise models), which will be housed in physically separate buildings whose associated primary substation capacity (substation 1) is legally ring-fenced from the planned sovereign zone substations (substation 2) designated for Phase 3/4.

**Assessments:** Title: Security Isolation and Initial Revenue Path
Description: Evaluation of the initial execution plan for satisfying both immediate revenue needs and long-term sovereign compliance (Risk 5).
Details: Physical isolation (separate substations/halls) acts as the practical pre-certification mitigation for the sovereign zone delay. Benefit: Allows for immediate revenue generation while DGSI reviews finalized sovereign partition designs. Risk: The definition of 'non-classified' must be formally agreed upon in Phase 0 to avoid later requirement creep that forces retrofitting these initial halls.

## Question 8 - Considering the 'Pragmatic Scale-Up' strategy defers transmission upgrades until Phase 2, what specific, temporary land-use mechanism (e.g., easement, lease structure) will be immediately secured in Phase 0 for the future interconnection points required for the 3 GW expansion?

**Assumptions:** Assumption: Phase 0 land acquisition will immediately secure preliminary right-of-way (ROW) easements for the exact locations of the Phase 2 required expansion substations and the transmission tie-lines (including the required buffer land adjacent to rights-of-way), even if final financing for the physical build is deferred.

**Assessments:** Title: Long-Lead Physical Infrastructure Control
Description: Assessing control over physical real estate necessary for future grid integration, independent of power commitment funding.
Details: Securing ROW easements is a long-lead permitting activity that must be decoupled from the grid financing trigger. Failure to secure ROW in Phase 0 transforms the grid uncertainty (Risk 3) into a physical land assembly blocker that cannot be solved later. Benefit: This buffers the physical implementation schedule against the utility's internal political timeline for granting transmission access.