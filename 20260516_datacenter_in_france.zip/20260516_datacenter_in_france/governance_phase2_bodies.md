### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** Required for high-level strategic decision-making, managing the extreme financial scale (€100B+) and the critical cross-domain dependencies (Grid, Land, Security). It must enforce the 'Pragmatic Scale-Up' strategy and sign off on all major deviation requests from the plan.

**Responsibilities:**

- Approve all Gate decisions (Phase 0 to 1, 1 to 2, etc.) based on satisfaction of strategic levers.
- Authorize capital expenditure variances exceeding 10% of the current phase budget or any unbudgeted obligation exceeding €500M.
- Provide ultimate arbitration for high-level cross-functional conflicts (e.g., Fiber vs. Power funding priority).
- Oversight of Risk Register, specifically for Critical Risks (Regulatory Delays, RTE Confirmation Failure, Social License Erosion).
- Approve major changes to the 9 GW target or the 161 km² conceptual footprint.

**Initial Setup Actions:**

- Finalize and approve the Project Charter and Governance Framework, including conflict resolution protocols.
- Appoint Chairperson (must be a senior sponsor outside the core delivery team).
- Establish the financial threshold for strategic versus operational decision authority (€500M).

**Membership:**

- Executive Sponsor (Chair)
- Chief Financial Officer (CFO)
- Chief Technology Officer (CTO)
- Head of Regulatory & Legal Affairs (Non-voting advisory)
- Independent External Governance Advisor (Voting member, focused on fiduciary duty)

**Decision Rights:** All strategic roadmap decisions, Gate Approvals (FID), budget allocations above €500M, and formal approval of revised major risk acceptance.

**Decision Mechanism:** Consensus required for Gate Approvals; Simple Majority for operational direction changes. Tie-breaker: The Executive Sponsor casts the deciding vote after mandatory 48-hour cooling-off period.

**Meeting Cadence:** Monthly, or immediately following critical external milestones (e.g., RTE consultation outcome).

**Typical Agenda Items:**

- Review of Phase Progress vs. Strategic Decision Matrix Execution
- Financial Burn Rate vs. Budgeted Tolerance (EUR/USD Split)
- Escalation Review: Issues deemed unresolvable by the Operational Management Group
- Audit Report Review (especially Compliance Check on Infrastructure Contingency Budget)

**Escalation Path:** External Shareholders / Board of Directors (for issues threatening project continuation or governance integrity).
### 2. Core Project Management Group (CPMG)

**Rationale for Inclusion:** This body manages the day-to-day execution of the 'Pragmatic Scale-Up' strategy. It is responsible for coordinating workstreams (Land, Grid Studies, Design) and making tactical decisions below the €500M strategic threshold, ensuring adherence to Phase 1 SMART criteria.

**Responsibilities:**

- Day-to-day management of the 3-year Phase 1 roadmap.
- Managing the interface between workstream leads (Design, Procurement, Regulatory Liaison).
- Detailed management of the €12.5M–€37.5M workforce/social license budget.
- Monitoring and enforcing the 1.20 PUE tolerance in detailed design and construction.
- Managing operational risk including cyber segregation checks (Risk 5).

**Initial Setup Actions:**

- Appoint Project Director (Chair of CPMG).
- Establish standardized reporting templates for all specialized workstreams (Land, Power, Security).
- Finalize resource allocation for the initial hyper-dense 32.2 km² buildable zone modeling.

**Membership:**

- Project Director (Chair)
- Lead Civil/Site Manager
- Lead Electrical/Grid Liaison Manager
- Head of Technology & Design (Liquid Cooling/PUE focus)
- Compliance & Security Coordinator (DGSI liaison)

**Decision Rights:** Operational decisions regarding cross-discipline resource allocation, tactical selection of vendors within approved procurement envelopes, approval of design changes up to 10% cost impact within a single workstream, and any decision under €500M.

**Decision Mechanism:** Simple majority vote. Decisions impacting multiple workstreams require documented alignment. Tie-breaker: Project Director's vote.

**Meeting Cadence:** Twice Weekly (Operational Synchronization); Weekly Detailed Progress Review.

**Typical Agenda Items:**

- Review of Remediation Progress vs. Budget (Risk 9)
- Status of RTE impact study submissions (pre-FID checkpoint)
- Progress against Local Workforce Quotas (Decision 8 implementation)
- Technical Review: Liquid Cooling performance parameters and integration milestones.

**Escalation Path:** Project Steering Committee (PSC) for any decision involving schedule delay risks exceeding 3 months, or budget triggers exceeding 10% of the active Phase 1 budget tranche.
### 3. Regulatory & Compliance Assurance Board (RCAB)

**Rationale for Inclusion:** Given the critical reliance on French permitting, DGSI/ANSSI alignment (Decision 3), and managing high legal/reputational risk associated with land assembly (Decision 2, 10) and corruption (Audit Risks), a dedicated, independent assurance body is necessary to ensure compliance is proactive, not reactive.

**Responsibilities:**

- Conduct mandatory compliance checks against DGSI/ANSSI protocols prior to Phase 1 construction FID.
- Oversee the integrity of land assembly documentation (confirming 80% buffer zoning integrity per Decision 10).
- Manage the independent Whistleblower Mechanism and oversee anti-corruption audits.
- Vetting all contracts related to brownfield remediation to prevent misallocation risk (Audit Risk 9).
- Formal sign-off on the physical/logical separation of Phase 1 commercial zone from future sovereign zones (Risk 5).

**Initial Setup Actions:**

- Retain independent external counsel specializing in French ICPE/Regulatory law.
- Establish the formal communication protocol matrix for DGSI engagement.
- Mandate the first Physical Segregation Audit schedule (bi-annual).

**Membership:**

- Head of Legal & Compliance (Chair)
- Designated DGSI Liaison Officer (Internal Security)
- External Integrity & Audit Partner (Independent)
- Environmental Compliance Specialist (External)

**Decision Rights:** Authority to halt specific workstreams (e.g., foundation pours, substation construction) pending certification of compliance with French law or security protocols. Veto power over the release of funds designated for community compensation until verified delivery (Decision 8).

**Decision Mechanism:** Unanimous agreement required for issuing 'Stop Work' or 'No-Go' advisory to the PSC on compliance matters. All other decisions require a 2/3 majority vote.

**Meeting Cadence:** Bi-monthly during Phase 0/1; Quarterly thereafter.

**Typical Agenda Items:**

- Review of DGSI Status against Security Partitioning Milestones
- Status of Permanent Ecological Offset Verification (Land Use Audit)
- Review of Whistleblower/Conflict of Interest Registry
- Compliance Checklist sign-off for next major capital release.

**Escalation Path:** Project Steering Committee (PSC) if a compliance deadlock stalls the project timeline by more than 4 weeks.