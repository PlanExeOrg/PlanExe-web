*Roles Needed & Example People*

# Roles

## 1. Chief Infrastructure Strategist & Project Architect

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Chief Infrastructure Strategist must be a deeply embedded, long-term contributor responsible for maintaining complex, strategic alignment (e.g., 9 GW roadmap vs. feasibility) over a 10-15 year timeline. This role requires deep organizational commitment and fiduciary duty.

**Explanation**:
Owns the overall strategic choices (e.g., split-campus vs. contiguous, hyper-dense model) and ensures the 15-year roadmap aligns with feasibility findings. Acts as the primary liaison for the 'red team' mandate.

**Consequences**:
Strategic drift, failure to challenge core ambitious assumptions (like 9 GW or 161 km²), and misalignment between phased funding gates and external regulatory readiness.

**People Count**:
min 1, max 2, depending on workload distribution

**Equipment Needs**:
High-performance workstation/server for complex infrastructure modeling (GIS, BIM, Digital Twin simulations for 161 km² layout), Subscription access to high-resolution cadastral and environmental data platforms.

**Facility Needs**:
Secure, dedicated office space with robust physical and cyber security protocols for handling long-term strategic roadmaps and sensitive financial/security governance documents.

## 2. Regulatory & Sovereignty Compliance Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Regulatory oversight (DGSI/DREAL) is continuous and high-stakes, requiring deep, protected knowledge retention and direct accountability to internal governance. This demands full-time, dedicated employment for security and permitting.

**Explanation**:
Manages all interactions with French national security agencies (DGSI, ANSSI) and local permitting bodies (DREAL, Prefectures). Ensures the sovereign AI partition design and hardware sourcing comply with national standards from Phase 0.

**Consequences**:
Total blockage of the sovereign AI tenant base, critical delays in national security review, and potential legal challenges to land use/environmental approvals derived from stakeholder skepticism.

**People Count**:
2

**Equipment Needs**:
Secure terminal access for communication with DGSI/ANSSI secure networks, specialized hardware classification documentation systems, and secure data storage for national security protocols.

**Facility Needs**:
Secure, access-controlled facility zone with dedicated clearance levels for handling classified design reviews related to sovereign AI partitioning and physical security infrastructure planning.

## 3. Grid & Power Procurement Specialist

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Grid & Power Procurement often requires niche expertise in French energy market regulations (RTE/EDF PPA structures) that is best sourced from highly specialized consultants (ICs) for complex, discrete negotiation processes like securing 9 GW allocation pathways, rather than maintaining a permanent FTE for this specific regulatory challenge.

**Explanation**:
Responsible for all negotiation and technical modeling with RTE and EDF. Translates the 9 GW load profile into binding grid upgrade requirements and sequences Power Purchase Agreement (PPA) negotiations relative to tenant commitment triggers.

**Consequences**:
Stranded capital risk if grid upgrades are paid for prematurely, or fatal delay if RTE capacity confirmation misses the Phase 2 FID timeline (Risk 3).

**People Count**:
min 2, max 3, due to complexity of RTE engagement

**Equipment Needs**:
Advanced power flow modeling software (e.g., PowerFactory, PSSE) capable of simulating 3 GW/9 GW load injections into the RTE network, standardized template library for complex PPA negotiation and financial modeling software supporting EUR/USD tracking.

**Facility Needs**:
Temporary, secure facility space for high-stakes negotiation sessions with RTE/EDF counterparties, featuring encrypted communication channels for sensitive PPA discussions.

## 4. Large-Scale Land & Civil Works Model Modeler

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Large-Scale Land Modeling, especially concerning the complex, rationalized 161 km² footprint (hyper-dense buildable vs. 80% buffer), requires specialized geospatial and brownfield real estate expertise for a focused 3-5 year assembly period. This is typically managed via fixed-term consultancies.

**Explanation**:
Focuses exclusively on the 161 km² physical layout, rationalizing the hyper-dense buildable area (32.2 km²) against the required buffers (128.8 km²). Responsible for budgeting land holding costs and modeling brownfield remediation logistics.

**Consequences**:
Massive CAPEX overrun due to unbudgeted land holding costs, failure to secure necessary ROW easements for future utility connections, and inability to present a legally viable land-use model to authorities.

**People Count**:
min 1, max 2, depending on the complexity of fragmented site control

**Equipment Needs**:
High-precision Geospatial Information System (GIS) and CAD/BIM software licenses for modeling the 161 km² layout, specialized environmental sampling and remediation planning software, and land holding cost tracking ledger.

**Facility Needs**:
Access to high-capacity plotters and secure, temperature-controlled physical storage for original land deeds, ROW paperwork, and preliminary environmental survey reports.

## 5. Hyperscale Data Center Design & Cooling Engineer

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Design and engineering for advanced, novel cooling systems (direct-to-chip liquid cooling at 1.15 PUE) is highly specialized. The best experts often operate as specialized consultants (ICs) available on a project-by-project basis to ensure leading-edge feasibility.

**Explanation**:
Translates the 1.15-1.25 PUE target into finalized technical specifications for direct-to-chip liquid cooling, focusing on high-density build models (low-rise halls) and ensuring ultra-low water consumption architecture for Phase 1.

**Consequences**:
Failure to meet operational PUE targets, leading to increased operational expenditure (OPEX) and potential breach of tenant/PPA efficiency clauses.

**People Count**:
1

**Equipment Needs**:
Computational Fluid Dynamics (CFD) simulation suite for validation of 1.15 PUE liquid cooling performance at scale, specialized thermal testing rigs for direct-to-chip hardware validation, and detailed specification sheets/portfolios of dry cooler manufacturers.

**Facility Needs**:
Access to a local test environment or lab space capable of simulating high-density heat rejection conditions for short-duration pilots, even if full cooling plant construction is delayed.

## 6. Financial Controller & Currency Risk Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Financial control, especially managing multi-billion EUR budgets, FX hedging, and setting internal financing gates aligned with multi-year construction tranches, requires permanent, fiduciary responsibility and deep integration into the project's financing structure.

**Explanation**:
Owns the multi-currency budget (€EUR vs. $USD hardware exposure). Structures financial triggers (Decision 4) and implements FX hedging strategies to protect the multi-billion Euro CAPEX against exchange rate volatility.

**Consequences**:
Uncontrolled budget erosion due to unfavorable EUR/USD movements (€4B+ risk identified), or setting financial expansion triggers (Decision 4) that do not align with lending covenants.

**People Count**:
1

**Equipment Needs**:
Enterprise ERP/Financial Reporting software integrated with FX tracking modules, dedicated terminal access for managing forward currency hedging contracts (Bloomberg terminal or equivalent), and sophisticated debt/syndication modeling tools.

**Facility Needs**:
A highly secure, firewalled financial operations room, isolated from general project network access, necessary for managing multi-billion Euro financing drawdowns and sensitive hedging operations.

## 7. Social License & Community Benefits Orchestrator

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Social License and Heat Reuse require expertise in French public relations, regional economics, and environmental negotiation. This expertise is often best contracted on a retainer basis to manage specific political sprints (permitting phases) rather than maintained full-time post-stabilization.

**Explanation**:
Focuses on mitigating social risk by linking Heat Reuse monetization (Decision 6) and the Local Workforce Uplift Mandate (Decision 8) to tangible community outcomes. Essential for accelerating permitting velocity by converting opposition to partnership.

**Consequences**:
Fatal political or judicial delays due to local opposition regarding land use and lack of direct economic benefit, undermining the 15-year project viability.

**People Count**:
1

**Equipment Needs**:
Community engagement software platforms for tracking local sentiment, dedicated liaison communication contracts for regional mayors/prefectures, and standardized documentation templates for Heat Reuse Offtake Agreements (with associated low-margin financial models).

**Facility Needs**:
Flexible, publicly accessible or neutral meeting space near the target zones (e.g., in Cambrai or Valenciennes) suitable for hosting community information sessions and establishing the fund office for the skills academy.

## 8. Telecoms & Connectivity Architect

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Telecoms Architecture, particularly securing diverse low-latency fiber routes and negotiating subsea commitments (Decision 5), is a discrete, high-value task typically outsourced to specialized connectivity architects (ICs) who manage carrier negotiations and dark fiber agreements.

**Explanation**:
Designs the redundant, low-latency fiber strategy (terrestrial and subsea focus). Ensures the physical connectivity strategy (Decision 5) can sustain synchronized AI training workloads across distributed campus clusters if a split-campus model is adopted.

**Consequences**:
Failure to deliver necessary latency thresholds for compute tenants, resulting in tenant attrition or significant operational penalties based on network performance SLAs.

**People Count**:
1

**Equipment Needs**:
Network topology mapping software supporting long-haul low-latency path analysis, specialized fiber route acquisition database access (for French ROW mapping), and contracts for laser communication testing equipment for RTT validation.

**Facility Needs**:
Secure coordination hub for managing multiple specialized fiber contractors, ensuring physical and virtual separation between terrestrial and subsea route planning efforts.

---

# Omissions

## 1. Missing Dedicated Construction & Logistics Management Role

The project involves coordinating massive civil works, brownfield remediation, and the phased construction of 50-100+ data halls across potentially fragmented sites (Decision 2). While the Land Modeler handles planning, there is no dedicated role to manage the on-site interface, contractor oversight, logistics scheduling, and adherence to the 3-year Phase 1 timeline.

**Recommendation**:
Introduce a temporary, highly experienced 'Program Director - Construction & Logistics' (IC or FTE for Phase 0-2). This role must integrate schedules from the Land Modeler, Cooling Engineer, and Workforce Orchestrator to ensure physical build progress aligns with energy and tenant commitment gates.

## 2. Absence of Dedicated Water Resource Management Expertise

The plan cites 'Water risk' as Medium/Medium severity and mandates 'ultra-low-water cooling,' yet the team structure lacks a recognized expert (FTE or IC) specifically focused on French hydrological permitting, regulatory engagement with ARS (Regional Health Agencies) regarding water rights, or sophisticated water recycling system integration.

**Recommendation**:
Contract a specialized 'Water Resource Engineer/Consultant' (IC, Phase 0-2) to focus exclusively on modeling the water balance for the defined cooling architecture against regional restrictions. This role must liaise directly with the Regulatory Lead regarding ARS approvals, which are often slower than DREAL permits.

## 3. No Defined Role for Financial Hedging Execution

The Financial Controller is responsible for managing currency risk, but the management of active, multi-hundred-million USD forward contracts (as implied by the 70% hedging strategy) requires dedicated execution, monitoring, and counterparty management that goes beyond standard financial control duties.

**Recommendation**:
If the Financial Controller cannot dedicate significant capacity, contract a 'Treasury & FX Execution Specialist' (IC, Phase 1 focus). This specialist executes the hedging positions dictated by the Financial Controller and monitors mark-to-market valuations daily, ensuring the project survives the identified €4.32B USD/EUR variance risk.

## 4. Missing Internal Technical Assurance/Quality Control

The project relies heavily on novel technology integration (9 GW grid coordination, 1.15 PUE liquid cooling, complex security isolation). There is no dedicated internal role bridging the physical realities of the Engineering team with the strategic requirements of the Strategist, risking technical deviations that breach performance SLAs.

**Recommendation**:
Assign the responsibility for formal QA/QC verification on technical delivery (e.g., PUE validation, fiber latency testing) to the Chief Infrastructure Strategist, but mandate they engage an external, independent 'Technical Verifier' (IC, short-term contract for Phase 1 commissioning) to audit compliance against the design specifications before Tenant/RTE witness tests.

---

# Potential Improvements

## 1. Clarify Land Responsibility Between Modeler and Strategist

The Land Modeler (IC) handles planning/modeling, while the Chief Strategist (FTE) owns the strategic choice (hyper-dense model reserving 80%). This creates ambiguity regarding who is ultimately accountable for the politically sensitive *holding cost* commitment identified as a critical budget risk.

**Recommendation**:
Explicitly assign the 'Financial Accountability for Buffer Holding Costs (128.8 km²)' to the Financial Controller, but mandate that the Chief Strategist must secure the explicit Board/Funder approval for the calculated holding budget as part of every funding gate, directly linking the strategic land conservation choice to financial compliance.

## 2. Formalize the Interface Between Sovereignty and Construction

The Regulatory Lead deals with DGSI/ANSSI, while the Construction Program (missing role) manages physical security implementation. The critical need for physical isolation between Phase 1 and Sovereign zones requires a unified management point to prevent construction errors from violating security protocols.

**Recommendation**:
Establish a mandatory 'Security Implementation Steering Committee' meeting bi-weekly during Phase 1 construction. This committee must include the Regulatory Lead and the Construction Director, requiring joint sign-off on all physical demarcation points, substation interface wiring, and access control installation schedules that affect the sovereign partition boundary.

## 3. Integrate Workforce Uplift Timeline with Contractor Selection

The Local Workforce Orchestrator (IC) focuses on social license, but the Grid/Power Specialist and the Land Modeler rely on contractors (EPCs/Remediation) that may resist hiring local apprentices, directly conflicting with Decision 8 (75% local hiring mandate).

**Recommendation**:
Mandate that all Request for Proposals (RFPs) issued by the Construction Director (or equivalents) for Phase 1 civil works and remediation must include a mandatory, weighted scoring component (e.g., 15% of the total score) based strictly on the prospective contractor's submitted, auditable plan with the Workforce Orchestrator to achieve the 75% local hiring quota.

## 4. Systematize Decision Gate Documentation Beyond Initial Readout

The project relies on clearly defined Decision Gates (e.g., Phase 2 FID contingent on 60% tenant commitment). The current structure risks these gates degrading over 15 years without standardized documentation of past fulfillment.

**Recommendation**:
For every Decision Gate (Phase 1 FID, Phase 2 FID, etc.), require the Chief Infrastructure Strategist to produce a 'Gate Fulfillment Sign-Off Report' summarizing evidence against each required dependency (e.g., 'RTE Contract Executed: Yes/No, Date: YYYY-MM-DD'). This formalizes the 'red team' review process for future leadership transitions.