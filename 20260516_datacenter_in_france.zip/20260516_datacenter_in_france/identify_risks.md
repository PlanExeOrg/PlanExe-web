
## Risk 1 - Regulatory & Permitting
Failure to secure necessary land assembly consents and operational permits for the hyper-dense, but geographically fragmented, development spanning multiple industrial zones in Hauts-de-France. Legal challenges from agricultural/environmental groups against the large-scale buffer zone designation (Decision 2 - Choice 2) could freeze construction.

**Impact:** A delay of 12–24 months in achieving Phase 1 Final Investment Decision (FID), translating to an estimated €500M–€1B overrun in financing and carrying costs for Phase 0/1, or forced reduction of the desired buildable area from 30 km² to below 15 km².

**Likelihood:** High

**Severity:** High

**Action:** Immediately initiate proactive engagement with regional environmental authorities (DREAL) and prefectural offices (DDETSPP) to secure 'Projet d'Intérêt Général' (PIG) status for the critical infrastructure components (substations, main fiber conduits) that span multiple municipalities, treating the agreed-upon buffer zones as non-negotiable early concessions.

## Risk 2 - Technical
Inability to meet the aggressive PUE target of 1.15–1.25 across 1 GW+ capacity using default direct-to-chip liquid cooling at scale, given the novelty of deploying this technology for the entire first tranche in a non-optimized, brownfield environment.

**Impact:** Exceeding the target PUE by 0.1 (moving to 1.25–1.35 average) could increase annual operational energy costs by an estimated €5M–€10M at 1 GW capacity, and critically, may violate contractual PUE performance clauses tied to initial anchor tenants (Decision 4).

**Likelihood:** Medium

**Severity:** Medium

**Action:** Pilot the liquid cooling infrastructure validation extensively during the design phase using digital twins and hardware simulation. De-risk Phase 1 by ensuring anchor tenants accept a performance-based escalator clause tied to energy costs if PUE targets are missed by more than 0.05 due to unforeseen pump/fluid dynamics integration challenges.

## Risk 3 - Financial
Sunk capital expenditure if RTE/EDF cannot confirm the necessary grid upgrades for Phase 2 (3 GW) capacity commitment before Phase 1 (1 GW) construction financing is finalized, as per Decision 1 (Choice 2 - Pragmatic Scale-Up).

**Impact:** The inability to secure binding transmission allocation by the Phase 1 FID decision gate could force a halt, potentially stranding €1B–€2B of already spent Phase 0/1 capital (land assembly, initial build out) if anchor tenants withdraw pending power certainty.

**Likelihood:** High

**Severity:** High

**Action:** Strictly adhere to the Pragmatic Scale-Up strategy: do not proceed with Phase 2 expansion funding (beyond studies) until RTE provides a formal, legally binding contract for the required backbone transmission capacity upgrades for the next expansion tranche.

## Risk 4 - Supply Chain
Significant exposure to USD/EUR exchange rate volatility affecting the procurement of high-density GPU/TPU hardware and networking gear, despite currency hedging strategy (Currency Strategy).

**Impact:** If the EUR depreciates by >10% relative to the USD between procurement contracts and final hardware payment dates, the total hardware cost for the 9 GW buildout could inflate by an unhedged €8B–€15B on the total projected €100B-€140B budget.

**Likelihood:** Medium

**Severity:** High

**Action:** Implement multi-year forward hedging contracts for 70% of projected USD hardware needs (Phase 1 and 2). Critically, Phase 1 tenants must be asked to contract in EUR-equivalent terms, passing the risk of minor remaining FX deviation back to the consumer.

## Risk 5 - Operational / Security
Failure to secure DGSI/ANSSI protocols and sign off on the sovereign AI partition (Decision 3) prior to leasing 500 MW of physical space, leading to high-security buildout inefficiency or denial of crucial state contracts.

**Impact:** If the sovereign partition cannot be certified, the project loses access to the premium (and assumed stable) domestic revenue stream, jeopardizing the 60% required commitment threshold for Phase 2 expansion (Decision 4), potentially leading to €10B–€20B in lost long-term contracted revenue.

**Likelihood:** Medium

**Severity:** High

**Action:** Isolate the initial 500 MW cluster entirely from the planned sovereign zone footprint. Proactively engage DGSI in Phase 0/1 with detailed security design schematics for the *future* partition, ensuring Layer 1 physical segregation is integrated into initial substation planning, even if operational certification is deferred.

## Risk 6 - Environmental / Water
Unforeseen hydrological or environmental constraints in Hauts-de-France (a region with known water stress, despite better climate than the South) making the 'ultra-low-water' liquid cooling strategy technically non-viable or prohibitively expensive via high-volume water recycling infrastructure.

**Impact:** If the site requires evaporative cooling for peak load management, operational water consumption could trigger regional water restrictions, potentially leading to mandatory operational curtailment during summer months, resulting in €1M–€5M in immediate revenue penalties per week of restriction.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Mandate the use of zero-water density heat rejection (e.g., dry coolers or advanced heat pumps) for 100% of the Phase 1 build, accepting a temporary PUE degradation (e.g., 1.20 max) until long-term water sustainability can be proven via pilot, thereby front-loading the PUE constraint over the water constraint.

## Risk 7 - Social / Policy
Public opposition or judicial appeal stalls development based on the 'hyper-dense development model' which sacrifices 80% of the 161 km² for buffers, leading to accusations of hoarding land without immediate community benefit or causing loss of agricultural land (Decision 2, Choice 2 & Decision 10).

**Impact:** Local pushback could result in the Prefecture reducing the allowed buildable area to less than 20 km², fatally constraining the 9 GW target to a maximum of 3–4 GW, requiring a complete re-evaluation of the 15-year business case.

**Likelihood:** High

**Severity:** High

**Action:** Aggressively implement Decision 8 (Workforce Uplift) and Decision 6 (Heat Reuse) in Phase 0. Use the designated buffer land not just for biodiversity, but for demonstrably tangible community benefits (e.g., a pre-certified solar farm supplying local housing) to convert potential opposition into localized stakeholder cooperation.

## Risk 8 - Technical / Integration
Latency incompatibility between the chosen terrestrial fiber routes (Decision 5) and the needs of synchronized AI model training workloads, which require sub-millisecond consistency across the Paris/London/Brussels network.

**Impact:** If the latency exceeds mandated tenant SLAs (e.g., over 1.5ms terrestrial round trip to Paris), tenants may claim breach of contract, potentially leading to contract renegotiation or vacancy if the necessary dark fiber/subsea investment cannot be secured until Phase 3.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Immediately task a specialist engineering team to conduct independent, real-time latency benchmarking across multiple incumbent carriers. If results confirm performance marginally below requirements, commit Phase 1 CAPEX to securing dark fiber rights-of-way for the identified geographically diverse Phase 2 fiber path, accepting the conflict with Power Procurement Sequencing.

## Risk 9 - Financial / Budgeting
Underestimation of Brownfield Remediation Costs within the identified industrial zones (Cambrai/Dunkirk). Contamination levels may exceed expectations, particularly given the site's industrial history (former steel, refinery, military zones).

**Impact:** Phase 0 remediation costs, initially budgeted at €250M–€750M, could easily double or triple (€500M–€2.25B cumulative spend) if unforeseen hazardous materials require advanced soil stabilization or off-site disposal, delaying the physical start of data hall construction.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Require 80% of Phase 0 budget allocation to be dedicated to comprehensive, deep-bore environmental testing and risk modeling on the targeted buildable parcels, securing fixed-price remediation contracts with established regional specialists *before* land assembly finalization.

## Risk summary
The project faces an extremely high-risk profile dominated by regulatory uncertainty and interdependent critical path items. The 'Pragmatic Scale-Up' strategy adopted mitigates immediate financial exposure (by deferring grid commitment and enforcing high tenant thresholds) but heightens the risk of political/social blockage due to the extreme land rationalization (80% buffers vs. 20% buildable area). **The three most critical risks are:** 1. **Regulatory Delays in Land Assembly/Permitting (High/High):** Local judicial review of the fragmented, hyper-dense land model could halt all progress. 2. **RTE/Grid Confirmation (High/High):** The decision to delay transmission investment until Phase 2 FID risks stranding Phase 1 capital if grid capacity is denied or delayed significantly beyond the expected 3-7 year lead time. 3. **Social License Erosion (High/High):** Failure to convert community opposition via proactive workforce development and heat-reuse monetization will lead to outright political rejection or mandated footprint reduction, undermining the 9 GW ambition.

Mitigation strategies are heavily overlapping: successful social license programs (Workforce/Heat Reuse) directly support faster regulatory permitting, reducing the likelihood of the first critical risk. However, the core trade-off remains between speed (required by the AI market) and financial prudence (required by the skeptical red-team mandate).