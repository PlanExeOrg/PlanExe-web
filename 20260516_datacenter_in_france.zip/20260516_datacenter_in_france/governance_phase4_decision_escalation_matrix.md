**Budget Contingency Triggered for Land Holding Costs**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC review of budget variance (Review Issue 2), requiring consensus authorization for accessing the Capital Contingency Line item exceeding €500M.
Rationale: The cost of holding the 80% land buffer (a core element of the chosen pragmatic strategy) is unbudgeted. Expenditure exceeding the CPMG's operational limit (€500M tolerance) requires strategic sign-off.
Negative Consequences: Failure to approve budget leads to legal challenges or abandonment of reserved land crucial for future expansion flexibility, potentially constraining the 9 GW vision.

**RTE Refusal for Binding Phase 2 Transmission Allocation**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Mandatory immediate escalation from CPMG to PSC (as this confirms Critical Risk 3). PSC must decide whether to secure capacity via Risk Strategy Choice 1 (front-loading capital) or formally recalibrate the 9 GW timeline/scope.
Rationale: RTE's decision directly determines the viability of scaling beyond 1 GW within the 15-year timeframe and dictates the long-lead time for critical grid infrastructure (Risk 3). This exceeds CPMG tactical management.
Negative Consequences: Project schedule stalls indefinitely post-Phase 1 completion, potentially stranding Phase 1 capital if tenants withdraw due to lack of future expansion confidence.

**RCAB Veto on Phase 1 Construction Start due to Security Isolation Failure**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC must adjudicate the RCAB veto, which requires unanimous agreement from RCAB to halt work. The PSC Chair casts the tie-breaker vote after requiring a mandatory 48-hour cooling-off period.
Rationale: RCAB has explicit veto power over workstream commencement related to the security demarcation between commercial and sovereign zones (Risk 5). A veto halts critical path construction.
Negative Consequences: A multi-month delay to the Physical Segregation Audit introduces high risk of missing the 3-year Phase 1 completion target, jeopardizing tenant FID timelines.

**Proposal to Pivot from Hyper-Dense Model to Split-Campus Model**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Requires a formal recommendation from the CPMG, supported by technical verification that the 2ms RTT latency requirement can be met between clusters (Assumptions Q6), followed by a Simple Majority vote at the PSC.
Rationale: This constitutes a major change to the physical footprint rationalization strategy (Decision 2/Land Assembly Modality), impacting security perimeter design, internal logistics, and overall CAPEX estimates significantly.
Negative Consequences: Failure to achieve 2ms RTT renders the new model infeasible for core AI workloads, requiring re-design of the entire connectivity plan and potentially increasing USD hardware exposure volatility.

**Negotiated PPA terms include an EDF price structure deemed unhedgable against the Decision 4 (60% Tenant Threshold)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: CFO presents the financial impact analysis to the PSC. Approval requires a consensus decision to either accept the unhedgable risk, or use committed tenant revenue leverage to demand renegotiation with EDF/RTE.
Rationale: Power Procurement Sequencing (Decision 9) interacts directly with Tenant Acquisition Thresholds (Decision 4). If the cost structure of power contradicts the financial prudence mandated by revenue triggers, the PSC must intervene above the CPMG's financial authorization level.
Negative Consequences: Committing to a PPAs that locks in high operational costs jeopardizes the project's competitive position, potentially violating financial covenants linked to the expected ROI profile.