**Q1: What are the critical levers identified in the project for achieving the 9 GW target?**

A1: The critical levers include Power Capacity (Grid Integration, Power Procurement Sequencing) and Revenue Certainty (Tenant Trigger Thresholds). These elements are essential for establishing the project's physical and financial foundation, ensuring the engineering and financial viability of reaching the 9 GW capacity.

**Q2: What risks are associated with the Grid Integration and Power Source Commitment decision?**

A2: The primary risks include substantial sunk costs if the project commits to the 9 GW target prematurely without securing binding transmission allocation from RTE. This could lead to delays and cost overruns due to RTE's regional transmission upgrades, which are outside the developer's control.

**Q3: How does the Land Assembly Modality and Footprint Rationalization decision impact project feasibility?**

A3: This decision impacts feasibility by determining the physical geography of the campus. Attempting to assemble a contiguous 161 km² parcel poses challenges in local planning consent and could lead to multi-year litigation delays. A split-campus model may expedite land control but complicates security and logistics.

**Q4: What is the significance of the Tenant Acquisition Trigger Threshold in the project?**

A4: The Tenant Acquisition Trigger Threshold controls the pace of scaling from 1 GW to 3 GW, requiring secured revenue contracts before expanding infrastructure. This approach protects the project from overbuilding but may slow down market capture, risking first-mover advantage.

**Q5: What ethical considerations are involved in the project, particularly regarding local workforce sourcing?**

A5: The project mandates that 75% of non-specialized construction labor hours be filled by local apprentices to secure social license and mitigate opposition. This commitment aims to convert potential NIMBYism into local support but introduces management overhead and quality control risks.

**Q6: What are the potential consequences of failing to secure binding transmission allocation from RTE before Phase 1 financing closes?**

A6: Failing to secure binding transmission allocation could result in stranded capital investments of €1B–€2B for Phase 0 and Phase 1 if tenants withdraw. This could halt the project entirely, jeopardizing the feasibility of the entire 9 GW target.

**Q7: How does the project plan to address public opposition related to land use and environmental impact?**

A7: The project plans to mitigate public opposition by designating 80% of the land as buffers and community integration spaces, which aims to provide tangible local benefits and reduce environmental concerns. Additionally, a local workforce sourcing mandate is intended to foster community support.

**Q8: What are the implications of the project's reliance on local workforce sourcing for construction?**

A8: Relying on local workforce sourcing may enhance community support and social license but could also introduce risks related to skill shortages and management overhead. This could lead to delays in construction timelines and increased costs if local training programs do not meet the project's needs.

**Q9: What are the risks associated with the project's ambitious PUE targets, and how might they affect tenant contracts?**

A9: The project aims for a PUE of 1.20, but failing to meet this target could lead to increased operational costs and potential breaches of efficiency clauses in tenant contracts. This could jeopardize tenant relationships and revenue streams, particularly if costs exceed expectations.

**Q10: What ethical considerations arise from the project's heat reuse strategy, and how does it aim to benefit the local community?**

A10: The heat reuse strategy aims to monetize waste heat by providing it to local industries, transforming a potential liability into a community asset. However, it raises ethical considerations regarding the upfront capital costs and the complexity of securing long-term contracts, which may not yield immediate benefits for the community.