Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 18 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 1 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is an ambitious, but entirely physical, industrial construction and utility-scale infrastructure development plan; its success depends on engineering, regulatory approval, finance, and resource availability, none of which violate known laws of physics. The plan correctly frames its feasibility around real-world constraints like land assembly, grid capacity (9 GW is a massive but achievable electrical load target), water availability, and permitting, none of which require breaking physics.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of extreme scale, fragmented land assembly, managing complex French sovereign compliance (DGSI/ANSSI), and coordinating multi-GW grid integration without independent precedents for this specific combination, as noted in the premortem assessment.

**Mitigation**: Project Management Office: Define and execute parallel validation tracks (Technical/Grid, Legal/Security, Market/Tenant) with global 'NO-GO' gates based on empirical validity and regulatory clearance within 60 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because several strategic concepts like 'Pragmatic Scale-Up', 'hyper-dense development model', and 'Sovereign AI Hub' are central drivers but lack explicit definition spanning inputs→output→value, as noted in the required analysis for Decision 2 and throughout the plan.

**Mitigation**: Chief Infrastructure Strategist & Project Architect: Produce three one-pagers defining the inputs, processes, and customer value for 'Pragmatic Scale-Up', 'Hyper-Dense Model', and 'Sovereign AI Hub' within 45 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan explicitly relies on making strategic trade-offs that significantly underestimate or ignore second-order consequences, particularly around land holding costs and regulatory timing. Pre-mortem FM1/FM4 highlights that failing to budget for the 80% buffer land holding cost (>$1.3B risk) is a critical financial failure mode, and FM2 highlights that deferring RTE funding confirmation risks stranding Phase 1 capital, showing critical gaps in risk cascade analysis.

**Mitigation**: Financial Controller & Currency Risk Manager: Immediately finalize the 18-month validated holding cost budget for 128.8 km² and present it to the Board for acceptance as mandatory Phase 1 CAPEX commitment within 30 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan embraces a strategy ("Pragmatic Scale-Up") that explicitly defers grid funding commitments until revenue triggers are met, yet external analysis flags that RTE upgrade lead times typical for 3 GW could exceed the time buffer available, creating stranded capital risk (Risk 3). The review identified the explicit assumption that RTE upgrade time would be ≤36 months, which is unvalidated.

**Mitigation**: Grid & Power Procurement Specialist: Engage the European Energy Regulation Specialist to obtain a minimum validated RTE upgrade completion timeline (in months) post-collateral payment commitment within 60 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the funding plan is entirely based on revenue triggers (60% take-or-pay for Phase 2) and does not mention any committed funding sources, draw schedules, or financing gates/covenants, which is the threshold for HIGH risk according to the rubric.

**Mitigation**: Financial Controller & Currency Risk Manager: Deliver a dated financing plan listing committed funding sources, draw schedules, covenants, and a NO-GO gate tied to the 60% tenant commitment threshold within 45 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the instructions require citing specific benchmarks/quotes and per-area math, but the provided plan omits all CAPEX figures, specific area breakdowns beyond 161 km² total, and any normalized cost context. The plan focuses only on strategic levers, not cost realism or market comparison data.

**Mitigation**: Financial Controller & Currency Risk Manager: Source 3 relevant regional benchmarks (cost/m² for high-density DC/utility scale) and conduct a normalized cost assessment against the 32.2 km² buildable area within 60 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan consistently presents key projections, such as 9 GW capacity, 32.2 km² buildable area, and 60% tenant commitment triggers, as single fixed numbers without any discussion of potential variance, confidence interval, or alternative scenarios (e.g., worst-case usable land area or lower anchor tenant uptake).

**Mitigation**: Chief Infrastructure Strategist & Project Architect: Produce a sensitivity analysis report for the 9 GW capacity projection across three scenarios (Base, Conservative 6 GW, Aggressive 9 GW+) within 60 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan omits critical engineering artifacts for core (build-critical) components like the 9 GW power path (RTE coordination) and the split-campus fiber architecture. Referencing Design Decision 1: "Success is measured by obtaining binding transmission allocation for at least Phase 2 (3 GW) prior to finalizing Phase 1 construction financing." This creates an existential failure mode due to missing interface contracts and integration plans.

**Mitigation**: Chief Infrastructure Strategist & Project Architect: Produce interface contracts and integration plans for RTE coordination and split-campus fiber synchronization within 90 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because critical claims lack verifiable artifacts. Decision 3 claims alignment with DGSI/ANSSI based on achieving a "signed protocol defining hardware sourcing control... before Phase 1 Power FID," yet no artifact or defined process for achieving this crucial signature is present.

**Mitigation**: Regulatory & Sovereignty Compliance Lead: Secure a written DGSI/ANSSI 'No Retrofit Waiver' confirming the Phase 1 isolation plan within 10 months.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the core objective of '9 GW delivery' is mentioned but the physical manifestation (Decision 2) lacks specificity, relying on an abstract 'hyper-dense development model' sacrificing 80% of the footprint.

**Mitigation**: Large-Scale Land & Civil Works Model Modeler: Define SMART criteria for the buildable area, including a KPI for contiguous versus clustered buildable area (e.g., ≥20 km² contiguous within Cluster 1 by Year 4).


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because Decision 2's 'hyper-dense development model' specifies limiting buildable area to 30 km² while stating the core goal is 9 GW, implying an unsustainable verticality or extreme cost. This appears to add cost without supporting the 9 GW goal given the density constraints.

**Mitigation**: Land & Civil Works Model Modeler: Produce a technical feasibility report justifying 9 GW capacity within the 30 km² buildable area via specific PUE density metrics or update the 9 GW target within 45 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Chief Infrastructure Strategist & Project Architect' role is mission-critical for maintaining strategic alignment across the 15-year roadmap, especially linking feasibility to funding gates. This expertise covering strategic roadmapping, risk quantification, and large-scale physical/regulatory trade-offs is rare.

**Mitigation**: Project Management Office: Launch immediate external consultancy search for strategic infrastructure planning firms specializing in multi-GW European energy/land convergence within 15 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan discusses legal feasibility primarily in terms of securing regulatory approvals (RTE, DGSI, DREAL) but provides no explicit mapping, matrix, or assurance that the pathway exists for the fragmented land assembly or the multi-stage power procurement under existing French law.

**Mitigation**: Regulatory & Sovereignty Compliance Lead: Develop a formal Regulatory Matrix mapping all required permits (Zoning, EIA, Grid Connection) authorities, artifacts, and precedence dates within 60 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a clear strategy for covering the ongoing holding and administrative costs of the 80% reserved land buffer, which Review Issue 2 flagged as a potential €1.3B CAPEX overrun risk.

**Mitigation**: Financial Controller & Currency Risk Manager: Finalize and formally budget the 18-month holding cost for the 128.8 km² buffer, integrating this liability into the Phase 1 CAPEX baseline within 45 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan heavily emphasizes managing hard constraints over land and zoning (Decision 2 and 10) but the 'hyper-dense development model' which rationalizes 80% of the land into buffers is a strategic choice, not a demonstrated satisfaction of limits. While intended to expedite permitting, this trade-off creates high success contingency on local authority acceptance.

**Mitigation**: Regulatory & Sovereignty Compliance Lead: Obtain a provisional written 'intent to approve' letter from the DREAL Prefectural Lead regarding the 30% permanent offset structure within 90 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan addresses external resilience only via speculative contractual strategies (SLAs, potential secondary suppliers are not explicitly detailed or secured) for key external dependencies like fiber connectivity (Decision 5). The mitigation strategy for fiber focuses on terrestrial routes, accepting high concentration risk, even though diversification requires immediate, complex high-CAPEX action not detailed as secured.

**Mitigation**: Telecoms & Connectivity Architect: Deliver binding contracts for a secondary, physically diverse terrestrial fiber route or subsea landing point by securing Phase 2 path ROW within 120 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Finance Department prioritizes short-term budget adherence, conflicting with R&D's incentive for long-term, high-CAPEX security/grid pre-commitment needed for the 9 GW goal.

**Mitigation**: Chief Infrastructure Strategist: Finalize an OKR aligning Finance and R&D on Power Readiness: 'Secure binding 3 GW RTE contract by date M+12' within 45 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan explicitly lacks a formal feedback loop structure: KPIs, review cadence, owners, and change-control thresholds are missing, despite the plan being extremely sensitive to external regulatory and financing gates.

**Mitigation**: Chief Infrastructure Strategist: Institute a monthly review cadence with a governance KPI dashboard and charter a lightweight Change Control Board for threshold breaches within 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project exhibits strong coupling between three critical dependency streams: Grid Capacity (Risk 3), Tenant Commitment (Decision 4), and Social License/Land Use (Risk 7). For example, failure in Social License due to land disputes stalls construction, which delays power draw and thus delays the 60% tenant commitment needed to trigger the RTE funding for grid upgrades, causing immediate stranded capital risk (FM2).

**Mitigation**: Chief Infrastructure Strategist: Establish a combined heatmap dependency map, defining cross-impact breakpoints and establishing a NO-GO threshold for Phase 2 FID if any of Risk 3, Risk 7, or Tenant commitment falls below 75% threshold within 45 days.