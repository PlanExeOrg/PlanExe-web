## Primary Decisions
The vital few decisions that have the most impact.


The vital few (Critical levers) focus on establishing the physical and financial foundation: Power Capacity (Grid Integration, Power Procurement Sequencing) and Revenue Certainty (Tenant Trigger Thresholds). These three levers control the hard engineering and financial viability of reaching 9 GW. High-impact levers (National Security, Social License, Workforce) are vital non-engineering elements that prevent the critical path infrastructure from being politically or legally blocked. The group collectively addresses the core tension between maximizing speed-to-market for AI compute and managing massive, uncertain long-term CAPEX related to French regulatory approvals.

### Decision 1: Grid Integration and Power Source Commitment
**Lever ID:** `b00fc888-34bf-4edd-9fb7-db1a8e0a6c52`

**The Core Decision:** This lever manages the critical dependency between physical construction commencement and securing contracted electrical capacity from RTE. Success is measured by obtaining binding transmission allocation for at least Phase 2 (3 GW) prior to finalizing Phase 1 construction financing. It involves negotiating high initial capital outlay for feasibility studies to accelerate the overall timeline while accepting the uncertainty inherent in French grid planning decisions.

**Why It Matters:** Committing to the 9 GW target prematurely risks substantial sunk costs in preliminary grid connection studies and substation rights-of-way that RTE may deny or heavily condition. A conservative approach mandates securing binding, contracted capacity allocation for Phase 2 (3 GW) before approving Phase 1 construction financing, acknowledging that RTE-mandated regional transmission upgrades introduce major, uncontrolled schedule risk and cost overruns outside developer control. Delaying firm power commitment until a later gate pushes tenants further downstream, potentially jeopardizing take-or-pay contracts.

**Strategic Choices:**

1. Negotiate a firm, contracted 500MW-1GW connection point for Phase 1 contingent on immediate, pre-paid submission of subsequent grid impact studies required for the full 9 GW capacity, accepting high initial capital exposure to expedite timeline.
2. Limit Phase 1 scope to 500 MW backed only by a non-binding RTE hosting consultation response, deferring all transmission upgrade capital expenditure until the 3 GW expansion gate, prioritizing immediate land and building mobilization over power certainty.
3. Establish a dual-path parallel strategy where the core campus targets 3 GW utilizing contracted nuclear power, while the remaining 6 GW is explicitly budgeted and planned as physically separate, geographically decoupled microgrids powered by contracted, on-site co-located long-duration BESS charged via PPA, accepting higher PUE for distribution.
4. Immediately reduce the target power commitment for the entire project to 3 GW total capacity, focusing all grid negotiation efforts on securing a single, proven transmission corridor, thereby de-risking the initial 8-year timeline.

**Trade-Off / Risk:** Tying Phase 1 financing to future grid confirmation for 9 GW creates an unmanageable schedule risk tied to RTE decisions, whereas scoping down limits initial revenue potential and campus dominance in the target region.

**Strategic Connections:**

**Synergy:** Amplifies Power Procurement Sequencing and Risk Hedging by securing the physical corridor for future power buys. It is constrained by Land Assembly Modality and Footprint Rationalization.

**Conflict:** Conflicts with Tenant Acquisition Trigger Threshold by potentially securing power before tenants are fully locked in, risking stranded fixed power capacity if demand dips unexpectedly.

**Justification:** *Critical*, This lever directly governs the project's core feasibility (9 GW delivery). It is the central hub connecting financing, tenant contracts, and physical manifestation, as securing grid capacity is the longest, most uncontrolled dependency in the plan, dictating the pace of all subsequent phases.

### Decision 2: Land Assembly Modality and Footprint Rationalization
**Lever ID:** `182c7249-4c09-4842-b27a-e05ac3137228`

**The Core Decision:** This strategic decision dictates the physical geography of the campus, addressing the infeasibility of aggregating 161 km² contiguously. Rationalization involves distributing phases across existing industrial zones to expedite land control and permitting velocity. Success metrics include reduced dispute timelines and successful integration of previously fragmented sites into a unified security and logistics concept, minimizing land-use sprawl.

**Why It Matters:** Attempting to assemble the contiguous 161 km² square parcel in Hauts-de-France presents extreme challenges in local planning consent, agricultural displacement, and brownfield aggregation, likely leading to multi-year litigation delays. Adopting a split-campus model across 3-5 existing, fully zoned industrial parks (e.g., Dunkirk port logistics, E-Valley) simplifies land control and accelerates Phase 1 but fragments the centralized security perimeter and increases internal logistics overhead for shared services like H/R or central offices. The high-rise mandate for AI compute density within a wide footprint pushes the land-use model toward inefficient internal sprawl rather than optimized density.

**Strategic Choices:**

1. Abandon the contiguous 161 km² block and instead secure distinct, non-contiguous land parcels totaling 50 km² across three established, permitted industrial zones (e.g., Cambrai, Dunkirk, Valenciennes) to accelerate Phase 1 readiness and fragment environmental permitting risk.
2. Force the consolidation of the full 161 km² target by offering a substantial, non-negotiable public benefit or land-value guarantee package to prefectural authorities, streamlining assembly under a single, comprehensive, but politically vulnerable, exceptional planning decree.
3. Institute a hyper-dense development model where 80% of the 161 km² is immediately designated as permanent ecological preservation/water retention/agricultural buffer around five strategically placed, highly secure, and vertically integrated 1 GW nodes, effectively limiting buildable area to 30 km² long-term.

**Trade-Off / Risk:** Forcing a single, monolithic land assembly guarantees schedule delays via local judicial review, whereas distributing the asset across industrial zones sacrifices centralized security and logistical efficiency for speed of land control.

**Strategic Connections:**

**Synergy:** Synergizes strongly with Local Social License and Community Buffer Zones, as splitting the campus across multiple sites may dilute localized opposition to a single, massive land grab.

**Conflict:** Creates conflict with National Security and Sovereignty Alignment by complicating the establishment of a single, hardened, perimeter-controlled zone necessary for sensitive national compute workloads.

**Justification:** *High*, This decision controls the initial speed of deployment versus the long-term security posture. The conflict between contiguous land assembly and a fragmented split-campus directly impacts the feasibility of meeting the 161 km² footprint or the security requirements for sovereign AI workloads.

### Decision 3: National Security and Sovereignty Alignment
**Lever ID:** `2d21cacb-07ff-4ee3-91ca-ab89bc0e7f52`

**The Core Decision:** This lever ensures the project's core French sovereign AI mandate is met by proactively aligning physical design and operational protocols with DGSI/ANSSI requirements from the outset. Success depends on achieving a signed protocol defining hardware sourcing control and internal security partitioning before Phase 1 Power FID. This governs access to premium, state-backed revenue streams, treating security compliance as an enabler rather than a post-construction certification.

**Why It Matters:** Failure to secure early, explicit alignment with DGSI/ANSSI regarding hardware provenance, data classification, and physical security for the sovereign AI partition jeopardizes the entire tenant base, as French state entities require stringent guarantees. Treating the national security review as a post-Phase 1 permitting milestone delays revenue; conversely, tailoring the physical design (e.g., dedicated facility layers, hardened corridors) prematurely adds substantial construction cost and reduces flexibility should security requirements shift based on geopolitical events beyond Year 3. The timeline for security clearance is often the longest uncontrolled path in French infrastructure projects.

**Strategic Choices:**

1. Mandate that the first 500 MW load remains exclusively for non-classified commercial tenants until a formal, signed agreement governing the separation, auditing, and operational protocols for the dedicated sovereign AI partition is executed with relevant national authorities.
2. Immediately allocate 2 GW of the total capacity as a pre-engineered, physically isolated, and dedicated sovereign compute zone, designed to the highest DGSI standards from Day 1, even if initial tenants are non-sovereign, to secure favorable regulatory status early.
3. Execute Phase 1 entirely on a temporary, modular, and externally hardened perimeter, deliberately foregoing initial sovereign classification until the facility demonstrates 24 months of flawless, low-incident operational performance and predictable PUE metrics.

**Trade-Off / Risk:** Delaying physical security hardening for the sovereign zone until after Phase 1 risks expensive retrofitting or outright denial of high-value government contracts, but early over-engineering inflates Phase 1 capital expenditure unnecessarily.

**Strategic Connections:**

**Synergy:** Directly enables Heat Reuse and Public Benefit Monetization by providing a secure framework under which sensitive domestic workloads can operate, boosting domestic value.

**Conflict:** Creates tension with Tenant Acquisition Trigger Threshold, as meeting stringent security requirements immediately raises the base cost engineering for all initial capacity, potentially slowing initial commercial lease-up.

**Justification:** *Critical*, This lever controls access to the most strategic and high-value tenant segment (sovereign AI) for the entire 9 GW buildout. Failure here undermines the project's differentiated value proposition, acting as a non-negotiable prerequisite for future state participation and revenue stability.

### Decision 4: Tenant Acquisition Trigger Threshold
**Lever ID:** `876ac8dc-d585-433d-ae2b-ca9fbe0095ba`

**The Core Decision:** This lever controls the pace of scale-up—specifically transitioning from 1 GW to 3 GW—by making expansion conditional on anchored, bankable revenue contracts, not merely projected market growth. Success is defined by securing high-percentage take-or-pay commitments before commencing high-CAPEX infrastructure builds like the next wave of substations. This prioritizes financial stability over aggressive market capture speed.

**Why It Matters:** Setting the expansion trigger (Phase 2 FID) contingent on 30–50% committed capacity via take-or-pay contracts forces a deliberate slowdown, protecting the project from overbuilding power infrastructure but potentially ceding market share to faster competitors in the Northern European AI race. Conversely, proceeding with expansion based on soft LOIs or pipeline visibility (e.g., 10% commitment) allows for rapid deployment but introduces material financing risk if anchor tenants retract during the 3-year construction window for the next tranche, leading to stranded substation capacity.

**Strategic Choices:**

1. Raise the minimum take-or-pay commitment threshold for the 1-3 GW expansion gate to 60% of the next tranche's capacity, sacrificing speed entirely in favor of leveraging committed revenue to secure significantly lower, syndicated debt financing rates.
2. Mandate that only US Dollar-denominated GW-capacity contracts for sovereign AI workloads count toward the Phase 2 expansion trigger, creating a higher barrier to entry but insulating the project's core P&L from short-term EUR/USD volatility.
3. Approve Phase 2 expansion based solely on achieving 100% utilization of the Phase 1 1 GW capacity being guaranteed by a consortium of three medium-sized European cloud providers, accepting lower per-unit revenue for guaranteed base-load tenancy.

**Trade-Off / Risk:** Requiring high revenue commitment (60%+) for expansion de-risks financing against vacancy but dramatically slows reaction time to sudden spikes in AI compute demand, sacrificing first-mover advantage.

**Strategic Connections:**

**Synergy:** Synergizes with Grid Integration and Power Source Commitment by using committed tenant revenue as the leverage required to unlock further high-capacity grid investment discussions with RTE.

**Conflict:** Directly conflicts with Fiber Connectivity Path Diversity and Ownership, as aggressive commitment thresholds might force early, suboptimal fiber expansion decisions before strategic long-term routing is finalized.

**Justification:** *Critical*, This is the primary financial gate controlling expansion risk. It directly manages the trade-off between aggressive speed-to-market and financial prudence, ensuring committed revenue covers the massive capital expenditure required for subsequent grid and land commitments.

### Decision 5: Fiber Connectivity Path Redundancy and Terrestrial vs. Subsea Access
**Lever ID:** `b50b7c15-19d1-4b06-bd0f-46fb2d08c412`

**The Core Decision:** This lever involves granular selection and negotiation of physical fiber assets, directly balancing latency performance (crucial for AI workloads) against single-point-of-failure risk from terrestrial route concentration. The objective is achieving geographic diversity across multiple continental points and subsea access early in the plan. Success is defined by achieving multi-route physical separation, even if it necessitates utilizing higher-cost or slightly higher-latency secondary connections initially.

**Why It Matters:** The choice among diverse fiber routes directly impacts the critical low-latency connection to major European financial and AI hubs, which is non-negotiable for the intended use case. Prioritizing a single, ultra-low latency terrestrial path with minimal terrestrial hops, while faster, concentrates catastrophic risk on a single physical corridor susceptible to localized digging or infrastructure failure across the French/Belgian border. Developing immediate redundancy via multiple terrestrial paths, or incorporating immediate subsea route diversity, adds significant initial right-of-way negotiation complexity and higher operational leasing costs.

**Strategic Choices:**

1. Mandate diversity only through the primary terrestrial routes to Paris and Brussels, accepting the geographic concentration risk in exchange for achieving best-possible latency metrics necessary for time-sensitive AI model training synchronization.
2. Fund the immediate physical construction or long-term leasing of physically separate fiber trenches, simultaneously entering agreements for two different subsea landing points (e.g., Dieppe/Calais and Dieppe/UK), prioritizing resilience over the first year's latency performance.
3. Outsource all fiber corridor development to a single, established carrier under a 15-year managed service contract, accepting their pre-existing primary routes in exchange for eliminating the immediate financial and administrative burden of land acquisition/easement processing.

**Trade-Off / Risk:** Outsourcing connectivity eliminates immediate complexity but locks the campus into a carrier's existing infrastructure limitations, which may not meet the evolving, specialized bandwidth or ultra-low latency requirements of the core AI workloads.

**Strategic Connections:**

**Synergy:** Is strongly amplified by Fiber Connectivity Path Diversity and Ownership, as this lever defines the requirements the ownership strategy must execute upon for resilience and performance.

**Conflict:** Trades off against Local Workforce Sourcing and Skill Uplift Mandate. Focusing intense early effort and capital on complex fiber easement negotiation detracts focus from essential local recruitment and training programs.

**Justification:** *Critical*, This lever is the financial control mechanism over the Grid Integration lever; determining *when* to commit capital to infrastructure upgrades (grid/substations) against tenant revenue dictates viability. It manages the core financial tension of the 15-year 9 GW buildout timeline.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Heat Reuse and Public Benefit Monetization
**Lever ID:** `6c281e97-6b1e-4468-9b1f-23bac3cbea90`

**The Core Decision:** This lever integrates the campus into the regional economy by monetizing waste heat, transforming a liability into a community benefit asset. Key success involves signing binding, low-margin, long-term off-take agreements to justify the upfront capital cost of specialized trenching and civil works. This mitigates social license risk by providing tangible, immediate local value outside of traditional employment figures.

**Why It Matters:** Exploring complex, high-volume heat reuse opportunities (e.g., district heating, industrial processes near Dunkirk) necessitates extending the physical campus boundary and increasing initial civil works expenditure significantly beyond standard data center footprints. While this transforms community relations into a public-benefit asset, the actual off-take contracts—which are essential for proving the ROI of this infrastructure—are typically long-term, low-margin, and introduce contractual complexity far earlier than standard tenant agreements. Deliberately ignoring heat reuse allows for simpler, faster site buildout and power density optimization but guarantees significant social license friction.

**Strategic Choices:**

1. Commit 2 GW of Phase 2 capacity specifically to serve a signed, take-or-pay contract with the local energy utility for dedicated low-grade heat export via trenching and pipeline infrastructure dedicated to district heating within the nearest 10 km radius.
2. Delay all heat reuse infrastructure planning until Phase 3, focusing Phase 1 and 2 solely on maximizing power density and PUE within the core footprint, managing community opposition via direct financial compensation only.
3. Design the campus land use to immediately incorporate a high-temperature waste heat sink (e.g., industrial biomass conversion or greenhouse cluster) requiring only the first two Phase 1 halls' heat rejection, utilizing this concrete, local use case to accelerate community acceptance.

**Trade-Off / Risk:** Early commitment to low-margin heat reuse leverages community benefit to unlock permitting faster, but the required upfront civil engineering diverts critical capital away from core compute deployment and capacity expansion.

**Strategic Connections:**

**Synergy:** Amplifies Local Social License and Community Buffer Zones by providing a concrete, structural benefit to the local community that reinforces the project's utility beyond compute rental.

**Conflict:** Directly conflicts with Power Procurement Sequencing and Risk Hedging by requiring complex civil works and potentially lower-value heat contracts to be funded before firm power contracts are fully settled.

**Justification:** *High*, While not directly tied to compute uptime, this lever is the primary mechanism to neutralize social license friction, which is a critical path blocker for permitting 9 GW sprawl. Success here accelerates the social feasibility necessary for the physical build.

### Decision 7: Fiber Connectivity Path Diversity and Ownership
**Lever ID:** `a4c4412a-55f5-4e21-8d6a-3c0fca7b5657`

**The Core Decision:** This lever governs the project's physical data transport foundation, balancing CAPEX against latency and vendor lock-in. Full ownership of dedicated dark fiber paths offers superior latency control and resilience against carrier disruptions, essential for hyperscale AI synchronization. Success is measured by achieving demonstrated low-latency paths to the four core hubs (Paris, London, Brussels, Frankfurt) while minimizing USD exposure associated with long-term international fiber leases.

**Why It Matters:** Relying primarily on diverse terrestrial routes linking to existing major hubs (Paris, London) creates dependency on incumbent telecom operators (Orange, Altice) for right-of-way access and service level agreements, introducing uncontrolled backhaul latency jitter. Taking an unconventional approach by partially funding and co-owning a dedicated dark fiber spur directly to the Dieppe or Dunkirk coastline for eventual subsea cable landing de-risks carrier dependency but requires substantial upfront capital investment before Phase 3 and introduces maritime regulatory hurdles.

**Strategic Choices:**

1. Procure redundant physical fiber paths from the three dominant national carriers, accepting the associated right-of-way limitations in exchange for minimizing initial infrastructure capital expenditure below 500 MW capacity.
2. Fund the engineering and initial trenching for a wholly-owned, direct-run dark fiber link from the campus boundary connecting to a single, strategically chosen, nearby subsea cable landing station, accepting a three-year delay to service.
3. Establish mandatory, legally binding Service Level Agreements (SLAs) with secondary/tertiary regional providers to ensure connectivity resilience, intentionally operating the first 1 GW cluster below peak performance thresholds to manage connection fragility.

**Trade-Off / Risk:** Owning dark fiber provides superior control over latency and dependency risk but requires significant CAPEX exposure tied to fiber installation before the facility generates meaningful revenue, delaying ROI.

**Strategic Connections:**

**Synergy:** Synergizes with Fiber Connectivity Path Redundancy and Terrestrial vs. Subsea Access by committing capital to resilience. Strong ownership minimizes operational dependency on external carriers.

**Conflict:** Conflicts with Power Procurement Sequencing and Risk Hedging by demanding substantial upfront capital before revenue generation. This diverts necessary funds from immediate grid financing requirements.

**Justification:** *Medium*, This is vital for AI synchronization but secondary to power and land. While critical, the options provided show that ownership requires high upfront CAPEX that competes with the more fundamental grid/power commitments needed for Phase 1.

### Decision 8: Local Workforce Sourcing and Skill Uplift Mandate
**Lever ID:** `35de1b16-a126-4e71-bc3a-0b14b088d5fe`

**The Core Decision:** This mandate centers on securing the long-term social license and operational talent pipeline by integrating local communities into the construction and operational workforce. The primary goal is to convert potential local NIMBYism into local support by ensuring the majority of accessible jobs are filled by upskilled regional hires. Success hinges on meeting local employment quotas without compromising construction quality or causing significant Phase 1 delays due to skill mismatch.

**Why It Matters:** Meeting the massive labor requirement for 50–100+ buildings using only pre-existing specialized data center construction labor from outside Hauts-de-France will inflate local labor costs and provoke strong political backlash regarding local economic benefit. Implementing an aggressive, mandatory in-region apprentice and retraining program for local residents builds significant social license capital and lowers long-term operating costs but introduces significant initial management overhead and risks quality control during the rapid Phase 1 ramp-up.

**Strategic Choices:**

1. Contract with a single, large, international EPC firm, granting them sole responsibility for labor acquisition, accepting the higher overall cost structure in exchange for guaranteed delivery timelines for the 1 GW build.
2. Establish a mandatory skills transfer requirement where 75% of all non-specialized construction labor hours must be filled by apprentices enrolled in locally certified technical schools, with failure triggering predefined community compensation penalties.
3. Focus initial workforce needs exclusively on highly-mechanized facility construction (e.g., prefabricated modules) to minimize human labor density until data center operations staffing can be stabilized via partnerships with regional universities.

**Trade-Off / Risk:** Prioritizing local workforce integration builds essential social license but compromises immediate construction speed and requires the project to absorb the upfront costs and risks associated with large-scale upskilling.

**Strategic Connections:**

**Synergy:** Directly amplifies Local Social License and Community Buffer Zones by providing tangible, sustained local economic benefits that justify land use decisions.

**Conflict:** Severely constrains Power Procurement Sequencing and Risk Hedging, as the associated training and management overhead delay construction schedules, pushing back PPA activation dates necessary to finalize grid commitments.

**Justification:** *High*, This lever is foundational to securing the long-term social license; failure leads to operational friction and political resistance. It directly supports the Heat Reuse strategy and mitigates risks associated with rapid local integration.

### Decision 9: Power Procurement Sequencing and Risk Hedging
**Lever ID:** `e28bc006-c51a-409c-90a6-1f5f52347eb8`

**The Core Decision:** This lever addresses the single longest lead-time risk: coordinating the 9 GW power delivery with EDF/RTE. The decision is whether to front-load massive collateral/financing for grid upgrades necessary between 3 GW and 9 GW early on, or deferring this obligation until later phases. Aggressively pre-funding secures capacity slots but creates massive capital overhang; deferral maximizes short-term liquidity but introduces severe grid sequencing risk post-Phase 1.

**Why It Matters:** Determining whether to finance large-scale grid upgrade collateral upfront or waiting until anchor tenants commit dictates the project's initial capital outlay versus its capacity delivery timeline. Front-loading substation and dedicated transmission works ensures rapid Phase 1 scaling upon site readiness, but ties up significant preliminary capital against uncertain ultimate demand realization. Deferring these major grid investments until binding multi-GW PPA is signed significantly reduces initial exposure but risks massive delay if RTE capacity allocation requires multi-year, sequential local network hardening not funded by the developer.

**Strategic Choices:**

1. Pre-fund 50% of the estimated RTE/local distribution network upgrade costs immediately in Phase 0 based on the 9 GW projection, securing the theoretical right-of-way and preliminary engineering slots before any major tenant commitment.
2. Adopt a strict 'No Grid Pre-Commitment' posture, meaning all grid investment collateral and infrastructure advancement is contingent upon a fully executed, validated power purchase agreement covering at least 5 GW before subsequent expansion funding is released beyond Phase 1.
3. Utilize temporary, high-density modular flywheel or kinetic energy storage deployment sufficient for 200 MW of the initial 500 MW load, buying twelve months to negotiate firm grid access for the remaining Phase 1 load without upfront multi-GW infrastructure financing.

**Trade-Off / Risk:** Pre-funding transmission upgrades based on a 9 GW projection is financially reckless without firm PPA signatures, yet waiting for grid confirmation stalls the critical, long-lead transmission component required before the site is viable.

**Strategic Connections:**

**Synergy:** Directly couples with Grid Integration and Power Source Commitment by providing the financial assurances needed to secure priority transmission upgrades based on future capacity projections.

**Conflict:** Conflicts with Tenant Acquisition Trigger Threshold, as massive pre-funding locks up capital that could otherwise be used to secure favorable power pricing or co-invest in tenant-specific infrastructure.

**Justification:** *High*, This lever dictates the physical land-use trade-off versus communal opposition. Given the 161 km² footprint, managing community backlash via land allocation is a direct control point over schedule risk and potential project stagnation from judicial review.

### Decision 10: Local Social License and Community Buffer Zones
**Lever ID:** `e2aeb220-75fd-4db9-bab7-5c6a14ecd9d5`

**The Core Decision:** This strategy determines the physical land allocation dedicated to non-compute, non-power infrastructure, directly trading off compute density against community acceptance and environmental compliance. Allocating substantial acreage for buffers, cooling system setbacks, and biodiversity offsets ensures smooth permitting continuity and reduces opposition risk, which is crucial for a 15-year build. Failure to secure this social license transforms land availability from a technical constraint into a legal/political blocker.

**Why It Matters:** The allocation of physical space for community engagement and ecological buffers determines the level of local political friction encountered during the multi-year buildout and permitting process. Generously allocating land for green buffers, local amenities, and agricultural continuation zones mitigates public opposition (social license risk) but reduces the economically productive footprint available for data halls and power infrastructure, forcing a lower eventual 9 GW capacity outcome within the 161 km² envelope. Conversely, aggressively minimizing buffers to maximize compute density accelerates capital return but maximizes the probability of high-cost judicial challenges or local mandates halting construction during Phase 1 or 2.

**Strategic Choices:**

1. Allocate a minimum of 25% of the 161 km² footprint for mandated, permanent biodiversity offsets, community integration spaces, and agricultural continuation zones, treating this acreage as an essential, non-negotiable element of the Phase 0 cost structure.
2. Adopt a 'Build-then-Mitigate' approach where the initial 1 GW build occupies the minimum necessary footprint, delaying the land zoning and commitment for large buffer zones until Phase 3, when clear project success makes mitigation funding politically easier.
3. Integrate a 'Shared Power Infrastructure' model, where the campus finances the necessary grid hardening for the entire surrounding region (not just the campus needs), positioning the project as the primary engine for local industrial stability rather than an isolated consumer.

**Trade-Off / Risk:** The Build-then-Mitigate approach fatally risks permitting renewal by postponing crucial social license investments, likely leading to litigation that freezes expansion after initial 1 GW deployment success.

**Strategic Connections:**

**Synergy:** Synergizes with Local Workforce Sourcing and Skill Uplift Mandate, as visible, permanent ecological/community investment reinforces the narrative that the project is a long-term regional partner.

**Conflict:** Directly conflicts with Land Assembly Modality and Footprint Rationalization, as any land proactively designated for ecological buffers directly reduces the maximum possible square meterage available for high-value data halls and power substations.

**Justification:** *Medium*, This is heavily related to lever 'a4c4412a'. Choosing physical path diversity is a critical network resiliency choice, but it is tactical compared to securing the power foundation (Critical levers) required to even bring the network online.
