# Documents to Create

## Create Document 1: Project Charter: 9 GW Hauts-de-France AI Campus

**ID**: cedbbf94-cbd5-4f77-a41a-8cd210fdadc9

**Description**: Foundational document establishing official project scope, objectives (Phases 1 & 9GW goal), alignment with the 'Pragmatic Scale-Up' strategy, authorized budget envelope (€100B+ projection), high-level schedule, and ultimate decision authorities. Document type: Project Charter/Mandate.

**Responsible Role Type**: Chief Infrastructure Strategist & Project Architect

**Primary Template**: PMI Project Charter Template

**Secondary Template**: Internal Governance Mandate Template

**Steps to Create**:

- Incorporate strategic mandates from all 10 key decisions into scope boundaries.
- Define the required conditional budget allocation between CAPEX for 1 GW build and pre-funding for feasibility/ROW securing.
- Obtain formal sign-off from Financial Controller regarding the funding gates aligned with Decision 4 (60% Tenant Threshold).

**Approval Authorities**: Executive Steering Committee

**Essential Information**:

- Detail the **final, non-negotiable scope** for Phase 1 (500MW - 1GW operational capacity) aligned with the 'Pragmatic Scale-Up' path.
- Quantify the authorized CAPEX envelope for Phase 1 construction and the ring-fenced budget for Phase 0 enabling activities (ROW, skills academy).
- Explicitly list the **binding trigger conditions** for unlocking Phase 2 expansion funding, referencing the 60% take-or-pay threshold (Decision 4) and the required RTE commitment status (Decision 1).
- Define the **legal status and initial handling** of the 128.8 km² buffer zone (80% footprint), specifying which portion is 'Permanent Ecological Offset' and which is 'Expansion Reserve' (Review Issue 2).
- Establish the **governing decision** on Land Assembly Modality: confirmation of the 'hyper-dense development model' (32.2 km² buildable area) over contiguous assembly.
- Finalize the **PUE performance commitment** for Phase 1 (Max 1.20 operational ceiling) and the associated contractual liability triggers related to anchor tenants (Risk 2).
- Mandate the **physical separation protocol** (Substation 1 isolation) required for initial commercial hardware versus future sovereign compute zones (Risk 5/Assumption Q7).
- Document the **Time Buffer Assumptions** derived from external review, specifically assuming a minimum 36-month lead time for RTE upgrades post-Phase 2 FID, and integrate resulting 'Power Readiness Lockout Clauses' into the schedule.

**Risks of Poor Quality**:

- Ambiguity in the Phase 1 scope or resource allocation leading to immediate scope creep or under-funding of critical enabling activities (e.g., land holding costs or skills academy).
- Lack of clear financial gates (Decision 4 linkage) results in Phase 2 capital deployment being initiated prematurely based on soft commitments, risking stranded assets if tenant thresholds are not met.
- Unresolved land status (Permanent vs. Reserve) leads to immediate legal challenges against the 'hyper-dense' model, triggering Risk 7 and construction halting.
- Absence of clear security isolation mandates (Risk 5) forces costly retrofitting during Phase 2 or jeopardizes eligibility for high-value sovereign contracts.
- Failure to explicitly incorporate buffer time for RTE confirmation (Review Issue 1) leads to the Phase 1 schedule being over-optimistic, guaranteeing contract breaches with tenants expecting power availability.

**Worst Case Scenario**: The project secures only partial Phase 1 financing due to unclear contractual risk transfer mechanisms (especially regarding the 80% land buffer), leading to immediate inability to secure necessary ROW, while high initial CAPEX sunk into feasibility studies (€1B+) cannot be recovered, resulting in project suspension or mandated significant scope reduction before 500 MW is operational.

**Best Case Scenario**: Executive Steering Committee sign-off provides undeniable executive mandate for the 'Pragmatic Scale-Up' framework, immediately unblocking resources for critical Phase 0 activities (land holding, skills academy funding) and establishing clear, de-risked funding gates that satisfy financial controllers and anchor tenants, thereby reducing the projected 1.5-year grid delay impact via upfront ROW securing, accelerating confidence in the 3-year Phase 1 completion goal.

**Fallback Alternative Approaches**:

- If explicit 80/20 land status cannot be agreed upon, immediately shift budget from general CAPEX contingency to secure 5-year binding lease options for the 32.2 km² buildable area, delaying the permanent designation of the buffer area (128.8 km²) until Heat Reuse contracts (Decision 6) are finalized.
- If internal analysis struggles to finalize the precise €100B+ envelope segregation, utilize the PMI Project Charter Template structure to define the budget as a 'Band' (e.g., €8B–€12B Phase 1 CAPEX) anchored only by the fixed costs agreed for the known Phase 0 activities (e.g., skills academy funding).
- If anchor tenant negotiations stall on the 60% revenue threshold, default to Decision 3, Choice 1: pivot Phase 1 focus entirely to securing the sovereign partition mandate first, using state guarantees as the Phase 2 funding trigger instead of commercial revenue.

## Create Document 2: Grid Interconnection Feasibility and Commitment Strategy (RTE/EDF)

**ID**: 6ca3f3c0-d617-44b5-b320-bb45acaebdb7

**Description**: Strategy document detailing the path to secure Phase 2 (3 GW) grid allocation. It must mathematically link the 60% tenant commitment threshold (Decision 4) to the required collateral funding date for RTE upgrades, in line with the 'No Grid Pre-Commitment' strategy for major works (Decision 1). Document type: Technical-Financial Strategy.

**Responsible Role Type**: Grid & Power Procurement Specialist

**Primary Template**: Energy Interconnection Strategy Framework

**Secondary Template**: PPA Term Sheet Template

**Steps to Create**:

- Formalize the pre-paid application process for the Phase 1 (500MW-1GW) hosting consultation.
- Model the required financial collateral structure needed by RTE for Phase 2 upgrades, contingent on the 60% tenant trigger.
- Develop the formal engagement timeline for RTE based on assumed 36-month upgrade completion buffer (Expert Review Issue 1).

**Approval Authorities**: Chief Infrastructure Strategist & Project Architect, Financial Controller & Currency Risk Manager

**Essential Information**:

- Quantify the minimum required financial collateral (in EUR) necessary for RTE to formally initiate feasibility and preliminary upgrade commitments for the Phase 2 expansion (3 GW) based on current French energy regulatory models.
- Establish the precise schedule dependency: Define the mandatory lead time (in months) between the execution of the 60% tenant commitment trigger (Decision 4) and the date the required collateral must be paid to RTE to ensure Phase 2 capacity is theoretically available 36 months later (Adhering to Review Issue 1).
- Detail the formal structure of the non-binding hosting consultation response for Phase 1 (500MW-1GW) and specify the exact deliverables required by RTE at this stage to satisfy Decision 1, Choice 2.
- Develop a strategy for legally insulating Phase 1 CAPEX financing from requirements for Phase 2 transmission upgrade collateral, adhering to the 'No Grid Pre-Commitment' strategy.
- Compare the financial impact (NPV/CoC) of a 36-month vs. a 48-month assumed RTE upgrade completion timeline on the overall project IRR.

**Risks of Poor Quality**:

- Incorrect collateral modeling leads to insufficient capital reserved at the 60% tenant trigger point, causing RTE to reject the commitment timeline and forcing a multi-year delay in Phase 2 power delivery.
- An inaccurate or optimistic schedule buffer (e.g., assuming <36 months for RTE upgrades) results in Phase 2 tenants activating power agreements before infrastructure is ready, leading to SLA breaches and potential contract clawbacks.
- Failure to clearly separate Phase 1 financing from Phase 2 collateral obligations results in lenders rejecting Phase 1 financing due to unmanaged grid commitment dependency.
- Misalignment between the PPA negotiation timeline and the technical commitment date for RTE leads to paying premium prices for delayed transmission slots.

**Worst Case Scenario**: The financial controller misunderstands the collateral requirements, leading to the inability to fund the necessary RTE bond immediately upon hitting the 60% tenant trigger, resulting in RTE revoking the preliminary capacity allocation slots required for 3 GW, halting the entire 9 GW program indefinitely due to unresolvable power supply constraints.

**Best Case Scenario**: The strategy mathematically proves that Phase 1 financing is fully decoupled from Phase 2 grid collateral, allowing Phase 1 FID to proceed based on existing RTE non-binding confirmation, while simultaneously securing a fixed, risk-buffered timeline (36 months post-commit) for Phase 2 power availability, enabling the Tenant Acquisition Trigger to be set with high confidence.

**Fallback Alternative Approaches**:

- If accurate collateral modeling proves impossible due to opaque RTE guidelines, revert Decision 1 to Choice 3 (Dual-path microgrid strategy) for the 6 GW beyond the initial 3 GW to physically bypass the most uncertain grid interconnection points.
- If a firm 36-month completion buffer cannot be secured from RTE experts, immediately negotiate higher initial power commitment (1 GW firm commitment for Phase 1 instead of 500MW soft) to gain political leverage for priority scheduling on grid upgrades.
- Develop a 'Provisional Collateral' strategy using a highly liquid financial instrument contingent on Phase 2 tenant revenue realization, allowing the commitment deadline to be met without immediately using primary project CAPEX.

## Create Document 3: Land Assembly and Use Model (GIS-Based Delineation)

**ID**: 23063434-b15f-4dfe-948c-6cf50ee90956

**Description**: A highly detailed geographic information system (GIS) model delineating the full 161 km² footprint. Must identify and digitally fence the 32.2 km² buildable area (hyper-dense nodes), the 128.8 km² buffer zone, and specifically mark the 30% 'Permanent Ecological Offset' acreage required for pre-emptive permitting risk mitigation (Decision 10). Document type: Technical Land Model/Regulatory Input Data.

**Responsible Role Type**: Large-Scale Land & Civil Works Model Modeler

**Primary Template**: GIS Cadastral Mapping Standard

**Secondary Template**: Brownfield Remediation Zoning Plan

**Steps to Create**:

- Integrate parcel data for Cambrai, Dunkirk, and Valenciennes clusters.
- Digitally assign zoning statuses (Buildable, Expansion Reserve, Permanent Offset) based on strategic decisions.
- Calculate and budget 18 months of estimated holding costs for the 128.8 km² buffer zone (Expert Review Issue 2).

**Approval Authorities**: Chief Infrastructure Strategist & Project Architect, French Land Use and Environmental Lawyer

**Essential Information**:

- Digitally delineate the full 161 km² required footprint using GIS mapping standards.
- Precisely fence the 32.2 km² designated 'Buildable Area' (hyper-dense nodes) based on Decision 2 (Choice 3) and Q1 Assumptions.
- Digitally assign zoning statuses for the 128.8 km² buffer, specifically marking the 30% acreage designated as 'Permanent Ecological Offset' (Decision 10, Choice 2 rationale).
- Output must include calculated 18-month holding costs for the 128.8 km² buffer, ring-fenced from infrastructure CAPEX (Review Issue 2).
- The GIS model must clearly show the physical isolation alignment for Substation 1 serving the 500 MW Phase 1 area, separate from future sovereign compute zones (Review Q7).

**Risks of Poor Quality**:

- Incorrect buffer/buildable area calculation leads to direct budget overrun (>€1.3B estimate if holding costs are miscalculated or permanently designated land is incorrect).
- Inaccurate digital fencing violates zoning submissions (DREAL/DDETSPP), leading to immediate judicial challenge against the 'hyper-dense development model' and stopping physical site mobilization.
- Failure to visually separate Phase 1 power infrastructure in the model jeopardizes DGSI security assurance checkpoints regarding physical segregation (Risk 5).
- Inability to transition buffer land status (e.g., from 'Reserve' to 'Permanent Offset') due to poor initial delineation, leading to high administrative overhead and potential social license erosion.

**Worst Case Scenario**: A flawed GIS model causes rejection by local permitting authorities during Phase 0 submission, forcing an immediate re-evaluation of the 80% buffer strategy and potentially reducing the buildable area to less than planned, thus capping the maximum achievable capacity significantly below the 4 GW target, rendering the 9 GW strategy infeasible.

**Best Case Scenario**: The highly detailed, validated GIS model accelerates DREAL/Prefecture approval by clearly defining non-buildable zones upfront, preempting litigation risk associated with land use disputes (Risk 7), securing the 32.2 km² core buildable area quickly, and allowing remediation contracts to commence without regulatory pause.

**Fallback Alternative Approaches**:

- If integration of existing parcel data is too complex, revert to utilizing high-resolution satellite imagery and simplified 1 km x 1 km grid overlays provisionally, flagging all areas outside the 32.2 km² core as 'High Uncertainty Land/Buffer Pending Final Survey' for regulatory submission.
- If accurate holding cost calculation is delayed, proceed with the GIS delineation but allocate a maximum fixed contingency (€100M) in the Phase 0 budget specifically for unknown land holding costs, acknowledging the explicit budgetary risk identified in the review.
- Engage a French environmental planning lawyer immediately to draft preliminary zoning definitions based on the visual GIS output, even if cost data is pending, to meet regulatory submission deadlines.

## Create Document 4: Sovereign Security & Commercial Isolation Protocol (Phase 1 & 2)

**ID**: 6b633f24-7ca4-4407-8b81-d17707018826

**Description**: Technical specification document detailing the physical and logical separation required between the initial 500 MW commercial load and the future dedicated sovereign AI partition (Decision 3). Must define hardware provenance requirements for Phase 1 non-classified hardware and mandate the use of dedicated, segregated substation capacity (Substation 1 concept) for initial load.

**Responsible Role Type**: Regulatory & Sovereignty Compliance Lead

**Primary Template**: DGSI/ANSSI Interface Compliance Roadmap Template

**Secondary Template**: Physical Security Segregation Standard

**Steps to Create**:

- Define explicit hardware sourcing criteria for the 500 MW commercial phase.
- Map out the location and switching logic for Substation 1 isolation.
- Produce a formal briefing document for DGSI engagement based on pre-signed requirements.

**Approval Authorities**: Regulatory & Sovereignty Compliance Lead, Chief Infrastructure Strategist & Project Architect

**Essential Information**:

- Define explicit hardware provenance criteria/chain of custody requirements for the initial 500 MW commercial load hardware, ensuring alignment with DGSI expectations even if the hardware is non-classified.
- Detail the complete physical schematics for Substation 1, mandated exclusively for the initial 500 MW commercial load, demonstrating full electrical and physical isolation from future sovereign partitions (Decision 3).
- Produce a formal briefing document detailing the operational plan for isolating the initial commercial load, referencing the agreed-upon separation protocols required before Phase 1 Power FID.
- Specify the logical (network segregation) and physical security measures planned for the 500 MW cluster to ensure zero cross-contamination with the location earmarked for the dedicated sovereign compute zone.
- Quantify the lead time required for DGSI/ANSSI review based on the submitted schematics, to be logged as a dependency/buffer for the overall Phase 2 timeline (Review Issue 1 implicitly applies to security clearance timing).

**Risks of Poor Quality**:

- Failure to secure DGSI agreement on the isolation protocol risks mandatory, expensive retrofitting of the initial 500 MW build, or denial of qualification for subsequent sovereign contracts.
- Ambiguous hardware provenance rules for Phase 1 could lead to procurement risks, forcing the project to discard non-conforming components or violate security alignment mandates.
- Inadequate substation isolation design leads to regulatory rejection of the entire security model, jeopardizing the core value proposition (high-value government/sovereign tenants).
- Delaying formal DGSI engagement due to an incomplete protocol forces security review into the critical path after Phase 1 construction FID, potentially causing significant, uncontrolled delays (Risk 5).

**Worst Case Scenario**: DGSI/ANSSI rejects the Phase 1 commercial cluster's operational security plan because of inadequate physical isolation from future sovereign zones, resulting in the inability to secure premium domestic contracts, thereby failing the 60% tenant commitment threshold for Phase 2 expansion (Decision 4 failure).

**Best Case Scenario**: Achieving signed protocol/agreement on the isolation plan with DGSI/ANSSI during Phase 0/1 engagement. This proactively de-risks the sovereign revenue stream, secures favorable regulatory status, and allows Phase 1 commercial operations to commence without risk of mandated security retrofit, directly enabling the successful execution of Decision 3's strategic goal.

**Fallback Alternative Approaches**:

- If definitive DGSI requirements are unattainable, proceed with Substation 1 isolation designed to the highest established European commercial banking security standards, documenting the divergence and creating a time-boxed contingency budget to upgrade to DGSI-specified hardware after Year 2 operations commence.
- If physical isolation schematics are blocked by RTE/Land development uncertainty, pivot the initial 500 MW to utilize only fully-vetted, open-source hardware stacks (no national sensitive components) to minimize sovereignty risk until physical sub-zones are confirmed.
- Engage a specialized French security consultancy (with prior government clearances) to pressure-test and rapidly finalize the isolation specifications based on analogous infrastructure precedents.

## Create Document 5: Risk Register (Initial Critical Path Analysis)

**ID**: 5ef83b35-5c2f-4cb9-90d5-10baa156f0f3

**Description**: The comprehensive compilation of initial risks (Regulatory, RTE/Grid, Social License Erosion, PUE failure) detailing likelihood, severity, initial mitigation actions, and assigning *primary ownership roles* based on the defined team structure. Crucial for tracking the project's 'red team' mandate.

**Responsible Role Type**: Chief Infrastructure Strategist & Project Architect

**Primary Template**: Standard Project Risk Register Template

**Secondary Template**: Cross-Dependency Risk Matrix

**Steps to Create**:

- Formalize assignment of ownership for the 9 identified critical risks.
- Incorporate mitigation strategies reviewed in expert feedback (e.g., buffer land budget—Review Issue 2).
- Establish the mandatory bi-weekly review structure for Security Implementation Steering Committee (Team Omission 2).

**Approval Authorities**: Project Development Team

**Essential Information**:

- List the 9 primary risks identified, derived from the 'Identify Risks' section, ensuring likelihood and severity are quantified for each.
- For each of the 9 risks, explicitly detail the mitigation plan or action derived from the 'Project Plan.md' section.
- Define the 'primary ownership roles' for each of the 9 risks, linking them to specific functions within the Project Development Team structure (even if the structure itself is implied/omitted, define roles like 'Grid Lead', 'Regulatory Counsel', 'Security Architect', etc., based on the nature of the risk).
- Incorporate the quantified feedback recommendations from the 'Review Assumptions' section (e.g., incorporating the 36-month RTE buffer assumption, the land holding cost budget directive, and the phased workforce scaling).
- Define the required structure and frequency for the 'Security Implementation Steering Committee' review cadence as it pertains to Risks 5 and 7.

**Risks of Poor Quality**:

- Failure to assign clear risk ownership will cause critical mitigation actions (especially related to land holding capital and grid buffering) to be dropped or delayed, leading directly to schedule slippage or unexpected cost overruns.
- Inaccurate mapping of mitigation strategies will result in the wrong team acting on the wrong priority, specifically endangering the alignment between the Pragmatic Scale-Up finance trigger and the RTE lead time.
- Omitting quantitative feedback from assumption review (e.g., RTE buffer time) will result in the register not capturing the true execution risk profile, leading to an inaccurate perception of the Phase 1 completion probability.
- If primary ownership roles are vague, the 'red-team' mandate fails, as risks will not be actively tracked or reported against defined performance metrics.

**Worst Case Scenario**: The risk register fails to capture the true schedule risk associated with external dependencies (RTE lead times, permitting challenges on land buffers), leading the Project Development Team to believe Phase 1 is on schedule until crucial mitigation actions (like securing buffer land holding budget or establishing regulatory time buffers) are missed, resulting in a project halt or a multi-year delay impacting initial revenue streams and triggering covenant breaches on initial financing.

**Best Case Scenario**: A high-quality, actionable Risk Register allows the Chief Infrastructure Strategist to immediately delegate clear accountability for all 9 critical risks, directly integrating the quantitative buffers (RTE time, land holding costs) identified in expert review, ensuring the 'Pragmatic Scale-Up' strategy effectively mitigates regulatory and structural dependencies before Phase 1 FID.

**Fallback Alternative Approaches**:

- If role assignment is difficult due to undefined team structure, initially assign all 'High Severity/High Likelihood' risks directly to the 'Chief Infrastructure Strategist & Project Architect' role until functional leads can be confirmed.
- If detailed mitigation steps from 'Review Assumptions' are too complex to incorporate immediately, create a mandatory subsidiary action item for the relevant risk owner to schedule a focused workshop within one week to convert complex assumptions into concrete, tracked tasks.
- Use the structure of the 'Cross-Dependency Risk Matrix' template to force linking ownership across the key decision levers (e.g., linking Risk 3 (RTE Failure) directly to Decision 1 owner) as a temporary substitute for detailed role assignments.


# Documents to Find

## Find Document 1: RTE/Enedis Frameworks for Multi-Stage Grid Interconnection Financing

**ID**: 61852e43-f4ba-4af5-918b-fdb4d6bf5440

**Description**: Existing regulatory documents or procedural handbooks detailing the financial requirements (collateral vs. binding commitment timelines) for a staged connection request projected over 9 GW in the Hauts-de-France region. Needed to quantify Risk 3.

**Recency Requirement**: Current regulations essential (post-2022 structure)

**Responsible Role Type**: Grid & Power Procurement Specialist

**Steps to Find**:

- Search the official RTE website for 'Tarif d'Utilisation des Réseaux Publics d'Électricité' (TURPE) documentation related to new large industrial connections.
- Contact the Energy Regulation Specialist to locate precedents for developer-funded regional network upgrades.
- Review French Cre documents related to network investment mandates.

**Access Difficulty**: Medium

**Essential Information**:

- Detail the exact financial collateral timing versus binding capacity allocation deadlines for staged grid access requests (e.g., 1 GW initial commitment versus 9 GW ultimate target) as stipulated by current RTE/Enedis frameworks.
- List the specific financial instruments (e.g., deposits, irrevocable letters of credit) required by RTE to secure Phase 2 transmission reservation slots prior to receiving binding 'Affirmation de Prêt' (Loan Affirmation) for transmission infrastructure investment.
- Quantify the maximum documented lead time (in months) RTE requires to complete mandatory regional transmission hardening necessary for a 3 GW connection following financial commitment, based on post-2022 regulations.
- Identify any regulatory clauses that explicitly link a developer's right to defer major transmission collateral payments (Risk 3) to the execution of take-or-pay tenant contracts (Decision 4 threshold).

**Risks of Poor Quality**:

- Inaccurate assessment of collateral timing leads to under-budgeting for required Phase 0/1 cash reserves, causing a liquidity crisis when RTE demands upfront funding for Phase 2 studies.
- Misinterpreting the RTE lead time for infrastructure hardening results in an over-optimistic timeline for the 'Pragmatic Scale-Up' strategy, causing Phase 2 FID to occur before power is ready, stranding Phase 1 capital.
- Failure to identify contingency financing clauses means the project cannot pivot if binding tenant commitments (60% threshold) are secured before RTE is ready, creating an unmanageable financial gap.

**Worst Case Scenario**: A 9-month mismatch between the guaranteed 60% tenant commitment trigger (Phase 2 FID) and the mandated RTE transmission upgrade completion results in the financial inability to secure the required 3 GW grid capacity, forcing a permanent scale reduction from 9 GW to the non-viable 3 GW/4 GW range, severely undermining the project's foundational ambition and decreasing Net Present Value by over 30%.

**Best Case Scenario**: Precise quantification of RTE's financial and timeline requirements allows the Power Procurement Specialist to structure the Phase 2 financing request such that the 60% tenant revenue trigger perfectly aligns with the required RTE collateral submission dates, effectively eliminating Risk 3 (Stranded Capital) and proving the feasibility of the highly interdependent financing gates.

**Fallback Alternative Approaches**:

- If framework documents are unavailable, immediately commission a targeted legal review engagement with a specialized French energy law firm to model financing scenarios based on precedent cases cited in recent large industrial interconnection approvals.
- Engage EDF/EDF Trading proactively to model multiple scenarios for capacity buyback or PPA sunset clauses tied to a 'Grid Readiness Delay' metric, converting unknown regulatory risk into quantifiable P&L contingency.
- Pilot a small-scale (100 MW) provisional grid connection request utilizing a dedicated reserve fund, treating the administrative process as a real-time learning exercise to empirically derive the required collateral amounts.

## Find Document 2: DGSI/ANSSI Data Center Security Certification Requirements (Current)

**ID**: 7c3147ca-229f-4ae3-a6a0-8fa822ca0d13

**Description**: Official documentation outlining the necessary physical segregation, hardware provenance auditing standards, and timeline expectations for achieving sovereign AI classification status in France for large-scale compute infrastructure. Crucial input for Decision 3.

**Recency Requirement**: Most recent published guidelines (within 1 year)

**Responsible Role Type**: Regulatory & Sovereignty Compliance Lead

**Steps to Find**:

- Search the ANSSI portal for 'Guide Security des Centres de Données' or equivalent high-level classification path documents.
- Submit formal inquiry through the designated regulatory liaison channel regarding preliminary review schedules.
- Consult with the EU Sovereign AI Policy Advisor for internal DGSI contacts.

**Access Difficulty**: Hard

**Essential Information**:

- List the specific architectural requirements (e.g., physical separation distance, hardened casing levels) mandated by DGSI/ANSSI for the future Sovereign AI partition (Decision 3).
- Quantify the required timeline buffer (minimum number of months) between DGSI/ANSSI final sign-off and the proposed Phase 2 expansion FID based on historical precedent provided by French authorities.
- Detail the mandatory process for hardware provenance auditing, specifically listing acceptable Tier/Origin certifications necessary to satisfy sovereign requirements.
- Identify all operational protocols (monitoring, access control, intrusion response) that must be specifically documented and governed by a signed agreement *before* Phase 1 Power FID is achieved.

**Risks of Poor Quality**:

- Misinterpreting security partitioning requirements leads to expensive, mandatory retrofitting of Phase 1 facilities to meet DGSI standards, causing a 6-9 month delay to sovereign tenant leasing.
- Failure to accurately estimate the DGSI review timeline results in the Tenant Acquisition Trigger Threshold (60% commitment) being breached before security clearance is granted, leading to stranded anchor tenants or forced renegotiation of high-value contracts.
- Incomplete understanding of hardware origin requirements results in procurement of non-compliant accelerators, making the facility ineligible for sensitive state workloads, thereby eroding the project's key value proposition.
- Submitting incomplete or outdated requirements leads to an initial rejection from ANSSI, adding 4-6 months to the overall regulatory clearance path, conflicting with the 3-year Phase 1 timeline.

**Worst Case Scenario**: The project successfully commissions its Phase 1 commercial capacity, but DGSI/ANSSI denies the ability to isolate or certify the planned sovereign AI zone within the existing physical design, rendering the highest-value revenue stream inaccessible, resulting in a 30-40% reduction in long-term projected NPV and the failure of the Phase 2 expansion trigger.

**Best Case Scenario**: Achieving a signed protocol with DGSI/ANSSI early in Phase 1 that locks in the security architecture. This allows the team to accelerate the design of the sovereign partition in parallel with commercial rollout, securing preferential government integration status and guaranteeing access to the highest-margin state contracts upon facility readiness, validating the 'security as an enabler' strategy.

**Fallback Alternative Approaches**:

- Initiate a targeted legal review engagement with a specialized French administrative law firm focused solely on DGSI compliance timelines to establish a credible regulatory buffer timescale (to address Review Issue 1).
- Engage DGSI/ANSSI directly via the 'Regulatory & Sovereignty Compliance Lead' to negotiate a 'Provisional Certification Pathway' that allows initial commercial tenants while concurrently validating the sovereign zone isolation design.
- If the full hardware provenance auditing details are unavailable, immediately commit to procuring only hardware components explicitly listed on a pre-approved, high-security French or EU vendor list, albeit at a temporary cost premium.

## Find Document 3: Hauts-de-France Regional Spatial Planning Documents (PLU/SCOT)

**ID**: cc1b09ce-8d8a-4ee0-bae1-398e4c1f3d66

**Description**: Local/Departmental zoning plans (PLU/SCOT) for the identified clusters (Cambrai, Dunkirk, Valenciennes) to confirm current industrial designation, existing environmental constraints (water tables, protected areas), and procedures for land aggregation concessions. Essential input for the Land Assembly Model.

**Recency Requirement**: Published within last 3 years

**Responsible Role Type**: Large-Scale Land & Civil Works Model Modeler

**Steps to Find**:

- Search departmental/regional authority portals (Préfecture Hauts-de-France) for planning documents related to large industrial development zones.
- Obtain cadastral maps covering the proposed 161 km² area.
- Engage the French Land Use and Environmental Lawyer for specific zoning interpretation.

**Access Difficulty**: Medium

**Essential Information**:

- List specific industrial zoning designations (PLU/SCOT) for the clustered areas: Cambrai, Dunkirk, and Valenciennes.
- Identify all existing environmental constraints (e.g., protected water tables, known ecological conservation zones, or prior remediation requirements) mapped across the 161 km² target area.
- Detail the specific administrative/legal procedures required within the identified zones to secure land aggregation concessions (e.g., expropriation paths, public utility declarations).
- Confirm the procedural timeline (if available) for the local authorities to grant concessions needed for the 'hyper-dense development model' (32.2 km² buildable zone).
- Identify any existing land-use limitations that conflict with the 'Permanent Ecological Preservation' designation required for the 80% buffer zone.

**Risks of Poor Quality**:

- Utilization of outdated zoning data will lead to immediate legal challenges and delays when submitting land aggregation plans, violating the 'Pragmatic Scale-Up' approach.
- Failure to identify hidden environmental constraints (e.g., water tables) will result in unforeseen remediation CAPEX and potential mandatory adoption of higher-cost cooling methods, thus invalidating the PUE goals.
- Incorrect understanding of aggregation procedures will lead to the filing of insufficient planning applications, resulting in administrative rejection and potential judicial review against the fragmented site strategy.
- If spatial constraints (e.g., local protected zones) conflict with the proposed 32.2 km² buildable core, the 9 GW target becomes unachievable without significant land-use litigation.

**Worst Case Scenario**: Obtaining incorrect or incomplete spatial planning documents leads to filing permit applications with fundamental conflicts (e.g., building on protected ecological land), resulting in an immediate Judicial STOP Order on land assembly (Risk 1), delaying Phase 1 FID by 2+ years and triggering significant write-downs on pre-paid feasibility studies.

**Best Case Scenario**: Confirmation of suitable, contiguous, and industrially zoned parcels across the three chosen clusters allows for the immediate front-loading of definitive site control documentation, enabling the Land Assembly Model to proceed on schedule, directly supporting the Phase 1 construction timeline.

**Fallback Alternative Approaches**:

- Initiate immediate, funded parallel negotiations for Land Assembly Modality (Decision 2) focusing only on existing brownfield sites explicitly zoned for high-intensity industrial use, bypassing areas requiring environmental reclassification.
- Commission a third-party, high-fidelity GIS mapping overlay exercise integrating current DREAL environmental data with cadastral records across the entire 161 km² area, prioritizing data accuracy over document recency.
- Engage local municipal planning directors (Mairie) directly for informal confirmation of zoning intent regarding the 80% buffer reservation, potentially mitigating risks identified in Review Issue 2.

## Find Document 4: French Environmental & Water Usage Regulations (ICPE/ARS)

**ID**: dc14dc00-6618-4ace-bac6-2242ec4b0a2c

**Description**: Legislation governing industrial site classification (ICPE) for power consumption and data center water usage restrictions as enforced by DREAL and ARS bodies in the Hauts-de-France region. Needed to validate the PUE/cooling strategy against mandatory curtailment threats (Risk 6).

**Recency Requirement**: Current operational status mandatory

**Responsible Role Type**: Hyperscale Data Center Design & Cooling Engineer

**Steps to Find**:

- Search the Legifrance database for relevant ICPE decrees pertaining to high-capacity power/heat rejection facilities.
- Request specific guidance from DREAL/ARS regarding regional water scarcity thresholds for industrial cooling in the specific catchment areas near Dunkirk/Cambrai.

**Access Difficulty**: Medium

**Essential Information**:

- Identify the specific ICPE classifications applicable to a combined 9 GW data center and associated substation infrastructure in Hauts-de-France.
- List the precise, quantified maximum water withdrawal limits (m³/hour or m³/year) permitted for data center cooling operations in the target catchment areas, particularly under seasonal drought scenarios.
- Detail any mandated operational restrictions or curtailment procedures triggered when the Environmental Authority (ARS) forecasts water stress above specific thresholds (e.g., amber/red alert levels).
- Confirm the feasibility and associated permitting timeline/cost for implementing 100% dry/zero-water cooling for the initial 1 GW phase (PUE target ceiling of 1.20).
- Outline the reporting frequency and data format required by DREAL/ARS to demonstrate compliance with water usage and heat rejection disclosures.

**Risks of Poor Quality**:

- Violation of regional water quotas leading to mandatory operational curtailment for up to 1 GW (Risk 6), immediately breaching PUE-linked tenant contracts (Decision 4).
- Inaccurate ICPE classification leading to incorrect initial design assumptions for external heat rejection infrastructure, forcing costly retrofits or reduced efficiency.
- Assuming sufficient water availability based on national law, only to find local ARS enforcement prevents adequate cooling, degrading PUE above the 1.20 tolerance threshold.
- Delayed permitting due to insufficient or incorrectly formatted environmental compliance documentation required by DREAL/ARS, stalling the land assembly process.

**Worst Case Scenario**: Regional water authorities enforce substantial, unbudgeted mandatory curtailment (e.g., 50% reduction in operations) during the first year of 1 GW operation due to exceeding ARS limits derived from flawed regulatory assumptions, immediately triggering major SLA penalties and jeopardizing initial revenue streams.

**Best Case Scenario**: Clear, early confirmation of ultra-low water usage allowances based on dry cooling design (PUE <=1.20), resulting in expedited water permits and removing groundwater/hydrological risk as a critical path concern for subsequent expansion phases.

**Fallback Alternative Approaches**:

- Immediately increase the CAPEX allocation for Phase 1 to fund 100% dedicated, redundant dry cooling towers, accepting the PUE degradation to 1.20, to bypass reliance on local surface/groundwater licenses.
- Engage a specialized French environmental consultancy with a proven track record specifically addressing ARS and DREAL water licensing for large industrial sites in Hauts-de-France.
- If wet cooling feasibility cannot be confirmed by Q4 2025, formally revise the Land Use Feasibility Assumption (Water/PUE) and commit budget for necessary land adjustments to accommodate required footprint for dry cooling capacity.

## Find Document 5: Brownfield Site Environmental Baseline Reports (Cluster 1 & 2)

**ID**: f9dc09fc-5ae9-4b18-a691-d682d6ed990f

**Description**: Existing preliminary environmental surveys or contamination reports pertaining to past industrial uses (steel/refinery) on the proposed buildable 32.2 km² cluster areas. This data directly informs the required remediation capital expenditure estimate (Risk 9).

**Recency Requirement**: Historical reports acceptable, provided they haven't triggered new cleanup orders since publication.

**Responsible Role Type**: Large-Scale Land & Civil Works Model Modeler

**Steps to Find**:

- Submit formal Freedom of Information requests (or equivalent French process) to DREAL/local environmental agencies for historical site usage reports.
- Request data from the Chamber of Commerce related to former tenants on the identified industrial parks.

**Access Difficulty**: Hard

**Essential Information**:

- Identify the exact soil contamination classification (e.g., ICPE subclass) for the 32.2 km² buildable area in Cluster 1 (Cambrai/Valenciennes) and Cluster 2 (Dunkirk).
- Quantify the volume and required remediation technique (e.g., excavation, stabilization) for detected hazardous materials, correlating directly to the Risk 9 budget overrun estimates (€250M–€2.25B).
- List confirmed historical land use activities post-1980 for every major sub-parcel contributing to the 32.2 km² buildable zone.
- Detail any existing environmental restrictions or pre-loaded remediation requirements mandated by the DREAL/DDETSPP on the land parcels as of the current date.

**Risks of Poor Quality**:

- Inaccurate contamination mapping leading to doubling of remediation capital expenditure (€500M–€2.25B overrun), consuming contingency funds and delaying construction start by 3-6 months.
- Failure to identify hidden hazardous materials requiring specialized handling, leading to immediate stop-work orders from environmental authorities.
- Mismatch between assumed contamination profile and actual requirements, causing the remediation contracts to fail to meet the fixed-price agreement status sought in Phase 0.

**Worst Case Scenario**: Discovery of Class 1 highly contaminated zones requiring deep excavation or off-site processing across more than 10% of the buildable area, pushing total remediation costs above €1.5B and delaying data hall construction commencement by over one year, paralyzing Phase 1 FID.

**Best Case Scenario**: Reports confirm low-level, manageable contamination requiring fixed-volume stabilization costing approximately €250M, allowing for early lock-in of fixed-price EPC remediation contracts, securing the Phase 1 construction start within the 3-year timeline.

**Fallback Alternative Approaches**:

- Immediately fund comprehensive, on-site, high-resolution phase one environmental site assessments (ESAs) and targeted geotechnical surveys across the entire 32.2 km² buildable footprint to establish a local baseline.
- Engage remediation specialists to provide tiered, scenario-based cost proposals based on discovery of specific contaminant classes (e.g., heavy metals vs. complex hydrocarbons).
- Adjust Phase 1 budget allocation to increase the contingency line item for environmental risk from 10% to 30% of the initial remediation estimate until binding contracts are secured.

## Find Document 6: TenneT/RTE Analogous Multi-GW Staged Interconnection Case Study Reports

**ID**: 4c1ae489-42d4-4cf7-8817-11dacc0b9e17

**Description**: Case studies or annual report sections detailing how TenneT (Netherlands) or RTE managed the interconnection and upgrade funding for projects achieving multi-GW scale in phases (similar to the 1 GW -> 3 GW -> 9 GW transition). Crucial for validating the Grid Strategy.

**Recency Requirement**: Post-2017 focusing on large-scale digital infrastructure.

**Responsible Role Type**: Grid & Power Procurement Specialist

**Steps to Find**:

- Review TenneT/RTE annual reports concerning high-demand industrial park connection agreements.
- Search for public records or case studies referenced by the Eemshaven digital hub analogue.
- Consult with the European Energy Regulation Specialist for proprietary access points.

**Access Difficulty**: Medium

**Essential Information**:

- Identify binding timelines for mandated RTE grid upgrade completion subsequent to receiving the financial commitment/funding for Phase 2 (3 GW) expansion.
- Quantify the developer-funded percentage vs. RTE-funded percentage for the transmission upgrades required between the 3 GW and 9 GW capacity milestones.
- Detail the specific contract mechanism (e.g., performance bonds, contractual penalties) interconnecting the Tenant Acquisition Trigger Threshold (60% take-or-pay) to the financier's release of collateral for RTE interconnection studies.
- List specific case studies demonstrating successful staggered capacity acquisition (1GW -> 3GW -> 9GW) in complex EU regulatory environments (analogous to TenneT/RTE experience).
- Extract verifiable data points regarding the maximum time buffer (delay) experienced between financial commitment for grid upgrades and actual power availability confirmation for similar multi-stage data center builds.

**Risks of Poor Quality**:

- Failure to accurately model RTE upgrade timelines (post-commitment) will lead to an inaccurate 'Power Readiness Lockout Clause', resulting in a 1.5-year revenue delay and increased Cost of Capital (€500M–€800M overrun).
- Inaccurate assessment of required developer collateral funding for non-committed phases (3 GW+) risks stranding Phase 1 capital if RTE demands pre-funding beyond agreed limits.
- Lack of context regarding analogous project funding structures may lead to under-budgeting for contingencies required to manage the high-risk RTE dependency.
- If data lags pre-2017, the analysis may not account for modern requirements of hyperscale AI compute interconnection (higher initial power surge stability).

**Worst Case Scenario**: The project locks Phase 1 financing based on optimistic external timelines, commits necessary collateral funding, but then RTE reports a non-negotiable 3-year grid upgrade schedule post-commitment, leading to an inability to satisfy Phase 2 tenant anchor contracts and resulting in the stranding of €1B–€2B of Phase 0/1 capital and potential termination penalties.

**Best Case Scenario**: By incorporating precise RTE timeline buffers derived from case studies, the 'Power Readiness Lockout Clause' is accurately defined, allowing the project to synchronize Tenant Acquisition (60% threshold) with infrastructure availability, thereby minimizing stranded capacity risk and ensuring Phase 2 FID proceeds exactly as planned post-Phase 1 stabilization.

**Fallback Alternative Approaches**:

- Initiate immediate specialized consulting study focused solely on French Transmission Planning Law to establish legally mandated RTE upgrade lead times, treating external timelines as a non-negotiable constraint.
- Immediately engage EDF/State representatives via the DGSI channel to obtain confidential internal RTE scheduling forecasts for the specific network region, bypassing standard public reporting cycles.
- Develop a 'Temporary Power Solution' annex plan (e.g., modular BESS for 200MW backup, Decision 9, Choice 3) to absorb up to 12 months of RTE delay risk for Phase 1 operations, isolating this buffer from primary financing.

## Find Document 7: DGSI/ANSSI Hardware Provenance & Supply Chain Control Documentation

**ID**: bd83ba3f-db0c-4f63-8f19-80a0767e0760

**Description**: High-level policy documents describing the regulatory classification criteria for IT hardware components that must be restricted, audited, or sourced domestically to achieve 'sovereign certification' status (Decision 3 input). This defines the non-negotiable physical and logical isolation requirements.

**Recency Requirement**: Current security policy essential

**Responsible Role Type**: Regulatory & Sovereignty Compliance Lead

**Steps to Find**:

- Consult with the EU Sovereign AI Policy Advisor for any publicly accessible guidance on 'critical infrastructure hardware sourcing'.
- Search official EU security agency publications relating to supply chain resilience for AI infrastructure.

**Access Difficulty**: Hard

**Essential Information**:

- Detail the exact hardware sourcing restrictions (domestic vs. international) required for the sovereign AI partition.
- List the specific data classification levels (e.g., Secret Défense, Confidentiel Défense) that mandate dedicated physical isolation.
- Define the required audit frequency and scope imposed by DGSI/ANSSI on hardware provenance tracking.
- Provide the mandatory physical and logical isolation standards (e.g., air-gapping requirements, dedicated powerfeeds, HVAC segregation) needed to satisfy Decision 3 and achieve sovereign certification readiness.
- Quantify the timeline deviation impact if hardware sourcing does not meet these criteria before Phase 1 Power FID.

**Risks of Poor Quality**:

- Inaccurate design based on outdated security policies leads to mandatory, expensive retrofitting of Phase 1 infrastructure to meet sovereign partition standards, increasing sunk CAPEX.
- Failure to isolate hardware correctly results in denial of access to high-value French state and defense compute contracts, immediately jeopardizing the 60% trigger threshold for Phase 2 expansion.
- Lack of clarity on acceptable hardware provenance leads to supply chain blockages, delaying the acquisition of necessary GPUs/TPUs for the initial 500 MW deployment.
- Incorrect design interpretation causes the project to fail the mandatory DGSI checkpoint, resulting in a complete halt of regulatory progress.

**Worst Case Scenario**: Failure to obtain signed protocol defining hardware provenance control results in the entire 9 GW capacity being classified as non-sovereign, resulting in the loss of €10B–€20B in long-term premium government revenue streams and potential revocation of key operational licenses.

**Best Case Scenario**: Securing clear, signed DGSI/ANSSI protocols proactively defines the security architecture for the entire campus, enabling immediate allocation of 2 GW as pre-engineered sovereign capacity, thereby accelerating access to premium revenue streams and de-risking the entire long-term project justification.

**Fallback Alternative Approaches**:

- Engage a specialized French regulatory consultant with established relationships at DGSI/ANSSI for an immediate, closed-door interpretation session regarding current hardware sourcing policies.
- Design the initial 500 MW commercial cluster with physically redundant, isolated infrastructure pathways that allow for rapid re-zoning (reclassification) to the sovereign standard with minimal retrofit upon final policy confirmation.
- If policy criteria are unattainable, pivot strategy to target only non-sovereign, Tier 1 non-governmental anchor tenants whose contractual requirements are less stringently regulated regarding hardware origin.

## Find Document 8: Hauts-de-France Regional Energy Infrastructure Plans (9GW Context)

**ID**: 1860cb42-2a48-4dd7-89d2-20643c8487bb

**Description**: Strategic energy planning documents from the Hauts-de-France Regional Council showing projected available transmission capacity and planned future nuclear/renewable PPAs in the 2028-2035 timeframe. This data informs the long-term viability of the 9 GW ambition independent of isolated RTE negotiation points.

**Recency Requirement**: Regional energy planning documents published within last 3 years

**Responsible Role Type**: Grid & Power Procurement Specialist

**Steps to Find**:

- Search the regional government website for 'Schéma Régional Climat Air Énergie' (SRCAE) or regional economic development plans.
- Contact local DREAL/DGEC representatives for regional energy forecasts.

**Access Difficulty**: Medium

**Essential Information**:

- Detail the projected RTE transmission capacity allocations specifically planned for the 9 GW data center cluster target area between 2028 and 2035, independent of immediate RTE project negotiations.
- List pre-approved or earmarked long-term Power Purchase Agreements (PPAs) or generation firming commitments (nuclear/renewable) identified at the regional level that underpin the 9 GW availability.
- Quantify the regional pipeline for renewable energy sites or industrial off-takers that might directly conflict with or support the project's scheduled 9 GW power demand timeline.
- Identify any regional master plans that mandate specific power quality or grid hardening standards for large industrial consumers in the Hauts-de-France region.

**Risks of Poor Quality**:

- Inaccurate long-term power availability assessment leads to over-committing to tenants based on unconfirmed regional pipeline capacity beyond Phase 2.
- Failure to align procurement sequencing with regional plans prevents optimal financing rates, as PPA negotiations cannot leverage confirmed long-term capacity availability.
- If regional plans show capacity constraints post-2030, the 9 GW ambition is invalidated at a very late stage, forcing a costly, rapid downsize or abandonment of subsequent phases.
- Missing conflicts with local renewable targets could trigger opposition from regional environmental agencies, impacting permitting velocity.

**Worst Case Scenario**: The regional plans reveal that the necessary non-RTE upgrades or PPA availability for the 3 GW to 9 GW expansion is not feasible until after 2035, making the 9 GW goal unachievable within the project's financial modeling timeline, leading to massive write-downs on sunk Phase 1/2 CAPEX.

**Best Case Scenario**: The document confirms substantial regional energy infrastructure planning supports the 9 GW target timeline (or clearly dictates required regulatory steps), allowing the Power Procurement Specialist to secure favorable, pre-validated financing terms that de-risk the Grid Integration lever beyond Phase 2 funding commitment.

**Fallback Alternative Approaches**:

- Mandate the Grid & Power Procurement Specialist to initiate formal, pre-application data requests directly with EDF/RTE referencing the project's expected scale, even if formal feasibility studies are not yet funded.
- Commission an independent, high-cost feasibility study specifically focused on regional microgrid/BESS firming capacity utilization (aligning with Decision 1, Choice 3) to create a parallel power commitment track independent of official RTE forecasts.
- Engage a senior lobbyist with deep ties to the Hauts-de-France Prefect's office to gain access to pre-release infrastructure planning drafts.