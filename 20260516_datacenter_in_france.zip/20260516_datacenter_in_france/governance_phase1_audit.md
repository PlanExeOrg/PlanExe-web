
## Audit - Corruption Risks

- Bribery or kickbacks to local planning officials (DREAL, Municipalities) to expedite zoning approvals or secure favorable land assembly terms for the massive 161 km² footprint or the 'hyper-dense development model' (Decision 2).
- Nepotism in selecting contractors for brownfield remediation, where firms with personal ties to project leadership are chosen over demonstrably more qualified/cheaper bidders, potentially inflating the €250M–€750M Phase 0 budget (Risk 9).
- Conflict of interest arising if personnel involved in negotiating fiber optic right-of-way easements (Decision 5/7) also hold undisclosed financial interests in the chosen terrestrial carriers or subsea landing point construction firms.
- Misuse of influence with RTE/EDF officials to secure preferential grid connection slots or more favorable capital contribution requirements for the 9 GW buildout, especially since grid capacity is treated as highly uncertain (Decision 1/9).
- Trading favors with regulatory bodies (e.g., DGSI/ANSSI) where accelerated validation of the sovereign AI partition (Decision 3) is exchanged for granting local authorities favorable terms in the Public Benefit/Heat Reuse agreements (Decision 6).

## Audit - Misallocation Risks

- Misallocation of Phase 1 CAPEX (up to €10B) towards premature investment in high-cost, dark fiber ownership (Decision 7) before the 60% tenant commitment threshold for Phase 2 is met, undermining liquidity for mandatory grid upgrade collateral.
- Budgetary overrun on land holding costs for the 80% buffer zone (128.8 km²), as the plan highlights this needs dedicated funding but lacks a firm cost estimate, potentially diverting funds from essential cybersecurity hardening (Risk 7/Assumption Issue 2).
- Inefficient allocation of technical resources toward meeting the ultra-aggressive PUE target of 1.15 in brownfield Phase 1, leading to material cost overruns on specialized liquid cooling systems when a PUE target of 1.20 (conservative approach) would suffice without violating tenant SLAs (Risk 2/Assumption Q4).
- Unauthorized utilization of Power Purchase Agreement (PPA) capacity intended for the *firmly contracted* 1 GW Phase 1 tranche for speculative customer testing or internal development, risking the binding RTE allocation for Phase 2 expansion (Risk 3).
- Misreporting of workforce integration progress: Paying prime contractors based on invoices claiming high local hiring percentages (Decision 8) without validation, leading to inflated community compensation funds or procurement of less skilled/more costly labor.

## Audit - Procedures

- Quarterly financial audit focusing on the split between EUR (local) and USD (hardware) expenditures, requiring reconciliation of the 70% FX hedge documentation against actual invoices for GPU/TPU procurement (Currency Strategy/Risk 4).
- Pre-FID Audit (Phase 1 Construction Financing): Verification that a binding RTE allocation contract for Phases 2/3 transmission *or* sufficient collateral provisions are formally documented *before* releasing construction capital, as per the Pragmatic Scale-Up strategy (Decision 1/Risk 3).
- Physical Segregation Audit (Bi-annually during Phase 1): On-site verification of physical and logical separation between the initial 500 MW-1 GW commercial cluster and the planned sovereign AI zones, checking substation demarcation and access controls mandated by DGSI protocols (Risk 5).
- Compliance Check on Infrastructure Contingency Budget (Post-Phase 0): Audit the ring-fenced budget allocated for land holding costs (128.8 km²) and Workforce Skill Uplift contingencies to ensure these technical/social buffers were not prematurely reallocated to core compute CAPEX (Review Issue 2/3).
- Land Use Verification (Annually): Independent survey mapping utilizing Geo-spatial analysis to confirm that the 80% reserved buffer acreage corresponds to the mandated ecological offsets and community integration spaces, cross-referenced against local permitting conditions (Decision 10/Risk 7).

## Audit - Transparency Measures

- Publicly accessible, delayed (30-day lag) financial dashboard displaying Phase 1 CAPEX burn rate, segregated by Land Acquisition, Grid Connection Fees (RTE payments), and Hardware Procurement (EUR/USD split).
- Formal publication of the Land Assembly Modality agreement (Decision 2) detailing which parcels are designated as 'Permanent Ecological Offset' versus 'Expansion Reserve,' verifiable by local authorities.
- Establish an independent Whistleblower Mechanism, managed by an external legal firm, specifically soliciting reports related to procurement favoring local suppliers or integrity breaches concerning environmental remediation contracts (Risk 9).
- Publish quarterly status reports detailing progress against Local Workforce Sourcing quotas (Decision 8), including the number of trainees enrolled in the skills academy and the percentage of non-specialized labor filled locally.
- Mandatory publication of the operational PUE and water usage metrics (per GW block) within 60 days of Phase 1 commissioning, allowing anchor tenants and regulators to verify performance against the 1.20 target.