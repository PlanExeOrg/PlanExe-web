**Overall Adherence: 94%**

```
IMPORTANCE_ADHERENCE_SUM = (4×5 + 5×5 + 5×4 + 5×5 + 5×5 + 5×5 + 4×5 + 3×4 + 4×5 + 5×5 + 3×3 + 4×4 + 3×5 + 4×5 + 5×5) = 302
IMPORTANCE_SUM = 4 + 5 + 5 + 5 + 5 + 5 + 4 + 3 + 4 + 5 + 3 + 4 + 3 + 4 + 5 = 64
OVERALL_ADHERENCE = IMPORTANCE_ADHERENCE_SUM / (IMPORTANCE_SUM × 5) = 302 / 320 = 94%
```

## Summary

| ID | Directive | Type | Importance | Adherence | Category |
|----|-----------|------|------------|-----------|----------|
| 1 | Establish an intentionally extreme hyperscale AI data center campus. | Requirement | 4/5 | 5/5 | Fully honored |
| 2 | Location must be Hauts-de-France, France. | Constraint | 5/5 | 5/5 | Fully honored |
| 3 | Fixed notional footprint of 12.7 km × 12.7 km (approx. 161 km² / 40,000 acres). | Constraint | 5/5 | 4/5 | Partially honored |
| 4 | Full-buildout power target of 9 GW over 10–15+ years. | Constraint | 5/5 | 5/5 | Fully honored |
| 5 | Treat this as a red-team planning scenario; plan must be rigorous and skeptical. | Intent | 5/5 | 5/5 | Fully honored |
| 6 | Plan must recommend downsizing, splitting, delaying, or cancelling if feasibility fails. | Intent | 5/5 | 5/5 | Fully honored |
| 7 | Phase 1 power must be 500 MW–1 GW. | Requirement | 4/5 | 5/5 | Fully honored |
| 8 | PUE target of 1.15–1.25. | Requirement | 3/5 | 4/5 | Partially honored |
| 9 | Prefer zero- or ultra-low-water cooling; treat freshwater cooling as high-risk. | Requirement | 4/5 | 5/5 | Fully honored |
| 10 | Do not assume external approvals (RTE, EDF, DGSI, etc.) are guaranteed until proven. | Banned | 5/5 | 5/5 | Fully honored |
| 11 | Buildings should have typical height of 14–20 m and max height of 25–30 m. | Requirement | 3/5 | 3/5 | Softened |
| 12 | Create a land-use model accounting for non-building areas (buffers, infrastructure, etc.). | Requirement | 4/5 | 4/5 | Partially honored |
| 13 | Use EUR as the primary currency for budgeting; track USD exposure separately. | Constraint | 3/5 | 5/5 | Fully honored |
| 14 | Phase 0 must cover feasibility, site control, and setting up the permitting path. | Requirement | 4/5 | 5/5 | Fully honored |
| 15 | Decision gate for expansion requires anchor tenants with 30–50% take-or-pay commitments. | Requirement | 5/5 | 5/5 | Fully honored |

## Issues

### Issue 3 - Fixed notional footprint of 12.7 km × 12.7 km (approx. 161 km² / 40,000 acres).

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 5/5
- **Evidence:** Footprint must accommodate 161 km² (though rationalized to ~30 km² buildable area)
- **Explanation:** The plan acknowledges the 161 km² notional footprint but immediately rationalizes the buildable area to 32.2 km² (20%), which aligns with the land-use model requirement for non-building areas. However, Issue 2 analysis notes the financial complexity of holding 128.8 km² which suggests the full square is managed, but the directive was for a *fixed* footprint, which the plan softens by aggressively partitioning it.

### Issue 11 - Buildings should have typical height of 14–20 m and max height of 25–30 m.

- **Category:** Softened
- **Adherence:** 3/5
- **Importance:** 3/5
- **Evidence:** No specific building height metrics are detailed in the provided artifacts.
- **Explanation:** The artifacts discuss low-to-mid-rise development implicitly via the land use model, but they do not explicitly state the 14-20m typical or 25-30m maximum height constraints, nor do they include the required justification for ruling out taller buildings.

### Issue 12 - Create a land-use model accounting for non-building areas (buffers, infrastructure, etc.).

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Allocating 80% to buffers... remaining 128.8 km² allocated to non-buildable buffers and expansion reserve
- **Explanation:** The plan strongly addresses the land-use model by quantifying the 80/20 split (128.8 km² buffer vs. 32.2 km² buildable). However, the model section detailing the *full* required accounting (e.g., explicit line items for heat-reuse infrastructure, security setbacks) is referenced conceptually but not fully itemized as requested in the prompt's list.

### Issue 8 - PUE target of 1.15–1.25.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 3/5
- **Evidence:** achieving operational PUE <=1.20 in Phase 1
- **Explanation:** The plan sets the target at <=1.20, which falls within the requested 1.15-1.25 range. However, the analysis (Assumption 4) uses 1.20 as the conservative baseline, slightly weakening the lower bound possibility (1.15).
