**Goal Statement:** Successfully complete Phase 1 (500 MW–1 GW buildout) of the Hauts-de-France AI data center campus within 3 years, achieving operational PUE of 1.20, securing 500 MW-1 GW in non-classified commercial capacity, and obtaining legally binding grid commitment for the subsequent 2 GW expansion tranche prior to Phase 1 construction financing FID.

## SMART Criteria

- **Specific:** Successfully build, commission, and operate a functionally and contractually validated 500 MW to 1 GW segment of the hyperscale AI data center campus in Hauts-de-France, focusing on liquid cooling and strict power segregation until national security clearance for sovereign zones is finalized.
- **Measurable:** Phase 1 completion is measured by successful operation at target PUE (<=1.20), verified contractual commitment for 60% of the next 2 GW expansion tranche (Decision 4), and a binding RTE allocation contract for new transmission capacity required for Phase 2.
- **Achievable:** Achievable by adhering to the Pragmatic Scale-Up strategy, which intentionally limits initial power commitment to non-binding consultation for Phase 1, reducing immediate CAPEX exposure, and focusing on hyper-dense construction within a pre-defined 32.2 km² buildable area.
- **Relevant:** This phase validates the core technical and financial assumptions required to pursue the full 9 GW long-term goal, specifically testing grid coordination feasibility, tenant demand thresholds, and social license viability in the chosen region.
- **Time-bound:** 3 Years (End of Phase 1)

## Dependencies

- Completion of Phase 0 Feasibility, Site Control, and Land Assembly Agreements.
- Successful execution of pre-paid RTE grid impact studies for initial 1 GW load (Decision 1, Choice 2).
- Securing preliminary right-of-way easements for Phase 2 transmission upgrades (Assumptions Q8).
- Formal agreement on physical and logical isolation protocols for the future sovereign compute zone (Decision 3).
- Securing initial, binding contracts covering 30-50% of the next 2 GW expansion tranche (Decision 4).

## Resources Required

- Land control documentation for 161 km² area, primarily for 32.2 km² buildable zone and 128.8 km² buffer.
- EUR denominated financing (€5B–€10B) for Phase 1 CAPEX.
- Direct-to-chip liquid cooling components (pumps, piping, heat rejection equipment).
- Hardware Procurement Contracts denominated in EUR or covered by 70% forward hedging (for initial 1 GW compute).
- Specialized environmental remediation contractors for brownfield sites.
- Local workforce development program funding (~€12.5M–€37.5M initial allocation).

## Related Goals

- Finalize 9 GW Power Procurement Strategy (Post-Phase 1)
- Achieve DGSI/ANSSI Sign-off for Sovereign AI Partitioning (Post-Phase 1)
- Establish Full Multi-Route Fiber Network to Core European Hubs (Phase 2)

## Tags

- Hyperscale
- Hauts-de-France
- AI Data Center
- 9GW
- Liquid Cooling
- Grid Feasibility
- Skepticism

## Risk Assessment and Mitigation Strategies


### Key Risks

- Regulatory Delays: Judicial challenges to the fragmented, hyper-dense land assembly plan (80% buffer).
- RTE/Grid Confirmation Failure: Inability to secure binding 3 GW capacity allocation before Phase 1 construction FID.
- Failure to Monetize Local Benefit: Inability to secure binding Heat Reuse contracts or meet workforce quotas, eroding social license.

### Diverse Risks

- Technical: Inability to consistently maintain PUE <=1.20 in brownfield deployment under liquid cooling load.
- Financial: Budget overrun (€1.3B+) due to uncosted holding costs for permanent and reserve buffer land.
- Operational/Security: Failure to physically isolate Phase 1 commercial load from future sovereign zone, jeopardizing premium revenue.

### Mitigation Plans

- For Regulatory Delays: Proactively designate 30% of the buffer as legally binding 'Permanent Ecological Offset' in Phase 0 (Decision 10, Choice 2) to preempt litigation regarding long-term land use.
- For RTE/Grid Confirmation Failure: Adhere strictly to 'No Grid Pre-Commitment' for upgrade capital (Decision 1, Choice 2), making Phase 2 expansion FID contingent on 60% signed tenant capacity (Decision 4) *and* a formal RTE contract for transmission upgrades.
- For Failure to Monetize Local Benefit: Immediately budget and execute the initial skill academy funding commitment (€12.5M minimum) and formalize feasibility studies for heat reuse partners in Phase 0 (Assumptions Q3, Decision 6).
- For Technical PUE Risk: Mandate dry-cooling only for Phase 1 heat rejection, setting operational PUE tolerance ceiling at 1.20 (Assumptions Q4) to manage water scarcity risks.
- For Land Holding Cost: Explicitly budget holding costs for the 128.8 km² buffer for 18 months upfront, ring-fenced from infrastructure CAPEX (Review Issue 2).
- For Operational/Security Isolation: Contractually and physically separate Substation 1 for initial 500 MW load from all future sovereign zone connection points, using dedicated feeders (Pre-Project Q4).

## Stakeholder Analysis


### Primary Stakeholders

- Project Development Team (Plan Execution)
- Anchor Tenants (Post-FID capacity purchasers)
- EPC/Construction Managers (Delivery of 1 GW physical build)

### Secondary Stakeholders

- RTE / EDF (Grid Access and Power Contracts)
- DGSI / ANSSI (National Security Vetting & Sovereignty Alignment)
- DREAL / Prefectural Authorities (Land Zoning, Environmental Permits)
- Local Municipalities (Cambrai, Valenciennes, Dunkirk - Social License/Workforce)

### Engagement Strategies

- Project Team: Weekly progress reviews and formal decision gate submissions for all planning milestones.
- Anchor Tenants: Quarterly confidential updates on power reliability verification and security status, linking Phase 2 expansion FID directly to their commitment thresholds.
- RTE/EDF: Utilize pre-paid studies to force high-priority review slots; provide necessary collateral estimations contingent on binding capacity confirmation.
- Regulatory Authorities (DGSI/ANSSI): Proactive, front-loaded engagement in Phase 0/1 with isolation schematics to accelerate security review timelines for the non-classified initial load.
- Local Municipalities: Implement mandatory 75% local hiring clause (Decision 8) and commence immediate funding for the regional skills academy to secure social license over buffer land usage.

## Regulatory and Compliance Requirements


### Permits and Licenses

- Land Use Zoning Approvals for Fragmented Parcels (DREAL/Local Authorities)
- Environmental Impact Assessment (EIA) Approvals across multiple zones
- Water Usage Permits (Given ultra-low/zero-water cooling preference)
- Electrical Connection Permit for 1 GW capacity (RTE/Enedis)

### Compliance Standards

- French National Security Requirements (DGSI/ANSSI) for Data Center Classification
- EU GDPR and Data Sovereignty Requirements
- PUE and Efficiency Standards (Related to PPA terms)
- Brownfield Remediation Standards (ICPE classifications if applicable)

### Regulatory Bodies

- Direction régionale de l'environnement, de l'aménagement et du logement (DREAL)
- Direction Départementale des Territoires et de la Mer (DDETSPP)
- Réseau de Transport d'Électricité (RTE)
- Direction Générale de la Sécurité Intérieure (DGSI)

### Compliance Actions

- Submit formal request for expedited review of the hyper-dense land use model under the local planning authority (Phase 0).
- Schedule DGSI checkpoint meeting (Q4 2026) to review physical segregation plans between commercial and sovereign clusters.
- Implement compliance plan for brownfield remediation based on Phase 0 environmental baseline testing.
- Execute initial PPA template negotiations requiring EDF/EDF-backed green energy sources for the 1 GW commitment.