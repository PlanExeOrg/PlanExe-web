# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: French Land Use and Environmental Lawyer

**Knowledge**: DREAL regulation, ICPE permitting, agricultural zoning, brownfield remediation

**Why**: Needed to rigorously assess feasibility of the 80% land buffer model and navigate complex, fragmented environmental/zoning approvals in Hauts-de-France.

**What**: Advise on legal structuring for the 30% 'Permanent Ecological Offset' to pre-empt judicial challenges to the land assembly.

**Skills**: Land law, EIA procedures, administrative litigation, zoning compliance

**Search**: Avocat droit de l'urbanisme Hauts-de-France, DREAL permitting specialist

## 1.1 Primary Actions

- Engage a land-use consultant to create a detailed GIS-based land-use model for the 32.2 km² buildable area.
- Secure a binding power purchase agreement with RTE for at least 1 GW capacity before proceeding with construction financing.
- Develop and implement a comprehensive community engagement strategy to secure social license and address local concerns.

## 1.2 Secondary Actions

- Conduct a detailed risk assessment of the permitting process and identify potential legal challenges.
- Establish a timeline for community engagement activities and stakeholder consultations.
- Monitor and evaluate the effectiveness of community outreach efforts and adjust strategies as necessary.

## 1.3 Follow Up Consultation

Discuss the progress on land-use planning, power procurement negotiations, and community engagement efforts. Evaluate any emerging risks and adjust the project timeline accordingly.

## 1.4.A Issue - Inadequate Land Use Planning

The proposed plan lacks a detailed land-use model that clearly defines the specific areas allocated for various uses, including data halls, substations, and biodiversity buffers. This ambiguity could lead to significant delays in permitting and community opposition.

### 1.4.B Tags

- land_use
- permitting
- community_opposition

### 1.4.C Mitigation

Immediately engage a land-use consultant to develop a comprehensive GIS-based land-use model that delineates specific zones for each intended use within the 32.2 km² buildable area. This model should include detailed cadastral references and ensure compliance with local zoning regulations.

### 1.4.D Consequence

Failure to define land use zones could result in prolonged permitting processes, increased legal challenges, and potential loss of community support, jeopardizing the entire project timeline.

### 1.4.E Root Cause

Insufficient initial planning and stakeholder engagement regarding land use and zoning compliance.

## 1.5.A Issue - Unclear Power Procurement Strategy

The power procurement strategy is overly reliant on non-binding commitments from RTE, which poses a significant risk to the project's feasibility. Without a clear, binding agreement for the necessary power capacity, the project may face insurmountable delays.

### 1.5.B Tags

- power_procurement
- risk_management

### 1.5.C Mitigation

Prioritize securing a binding power purchase agreement (PPA) with RTE for at least 1 GW before proceeding with construction financing. Engage legal counsel to negotiate terms that minimize risk and ensure timely access to power.

### 1.5.D Consequence

Without a binding PPA, the project risks significant delays and potential financial losses, as construction may proceed without guaranteed power availability.

### 1.5.E Root Cause

Overconfidence in securing power commitments without a structured negotiation strategy.

## 1.6.A Issue - Insufficient Community Engagement Strategy

The current plan does not adequately address community engagement or the social license to operate. This oversight could lead to public opposition and legal challenges, particularly regarding land use and environmental impacts.

### 1.6.B Tags

- community_engagement
- social_license

### 1.6.C Mitigation

Develop a comprehensive community engagement strategy that includes regular consultations with local stakeholders, transparent communication about project benefits, and commitments to local workforce development. Allocate budget for community outreach initiatives.

### 1.6.D Consequence

Neglecting community engagement could result in significant public backlash, legal challenges, and delays in project approval, ultimately threatening the project's viability.

### 1.6.E Root Cause

Lack of proactive engagement and communication with local communities and stakeholders.

---

# 2 Expert: European Energy Regulation Specialist (RTE/PPA)

**Knowledge**: RTE grid access rules, French energy market structure, large-scale PPA negotiation

**Why**: Critical expert to evaluate the consequences and necessary collateral for securing binding 3 GW grid commitment against uncertain tenant revenue, per Decision 1.

**What**: Model the financial impact and timeline consequences of the RTE 'No Grid Pre-Commitment for upgrades' strategy versus immediate collateral financing.

**Skills**: Grid interconnection policy, high-voltage transmission law, PPA structuring, French energy market

**Search**: RTE connection studies cost, French network upgrade funding, EDF PPA negotiation expert

## 2.1 Primary Actions

- Define the exact 32.2 km² of buildable area and establish geo-fenced GIS boundaries for the 128.8 km² buffer zones by June 30, 2026.
- Wire the pre-paid fee to RTE for the initial hosting consultation response for the 500 MW Phase 1 load by May 24, 2026.
- Implement a local workforce sourcing and skill uplift mandate, ensuring that 75% of non-specialized construction labor hours are filled by local apprentices.

## 2.2 Secondary Actions

- Engage with local authorities to ensure alignment on land use and buffer zone requirements.
- Develop a detailed community engagement strategy to address potential public opposition.
- Explore partnerships with local educational institutions for workforce development.

## 2.3 Follow Up Consultation

Discuss the progress on land use planning, power procurement strategy, and community engagement efforts. Review any feedback from RTE and local authorities regarding the project's feasibility.

## 2.4.A Issue - Inadequate Land Use Planning

The current plan lacks a detailed and specific land use model that clearly defines the buildable area and necessary buffer zones. This could lead to significant delays in permitting and community opposition.

### 2.4.B Tags

- land_use
- permitting
- community_opposition

### 2.4.C Mitigation

Immediately define the exact 32.2 km² of buildable area within designated clusters, using specific cadastral references. Establish geo-fenced GIS boundaries for the 128.8 km² buffer zones and flag required road/fiber ROW corridors by June 30, 2026.

### 2.4.D Consequence

Failure to address land use planning could result in judicial challenges, delaying the project and increasing costs significantly.

### 2.4.E Root Cause

Insufficient detail in land assembly strategy and lack of proactive engagement with local authorities.

## 2.5.A Issue - Unclear Power Procurement Strategy

The power procurement strategy is overly reliant on non-binding commitments from RTE for Phase 1, which poses a risk to the project's feasibility if binding agreements for future capacity are not secured.

### 2.5.B Tags

- power_procurement
- RTE
- feasibility

### 2.5.C Mitigation

Wire the pre-paid fee to RTE for the initial hosting consultation response for the 500 MW Phase 1 load by May 24, 2026, and initiate a parallel engineering track to model required substations.

### 2.5.D Consequence

Without a clear and binding power procurement strategy, the project risks significant delays and potential financial losses due to unfulfilled capacity commitments.

### 2.5.E Root Cause

Overly optimistic assumptions regarding RTE's responsiveness and capacity allocation.

## 2.6.A Issue - Insufficient Community Engagement and Social License Strategy

The plan does not adequately address community engagement or the social license required for such a large-scale project, which could lead to public opposition and regulatory hurdles.

### 2.6.B Tags

- community_engagement
- social_license
- public_opposition

### 2.6.C Mitigation

Implement a local workforce sourcing and skill uplift mandate, ensuring that 75% of non-specialized construction labor hours are filled by local apprentices. Begin funding for a regional skills academy immediately.

### 2.6.D Consequence

Failure to secure social license could result in significant delays, increased costs, and potential project cancellation due to public opposition.

### 2.6.E Root Cause

Lack of proactive community engagement and failure to demonstrate tangible local benefits.

---

# The following experts did not provide feedback:

# 3 Expert: Hyperscale Thermal Design Engineer

**Knowledge**: Direct-to-chip cooling, PUE optimization, 9 GW thermal rejection systems

**Why**: Required to validate the technical achievability and cost drivers of maintaining PUE <1.20 while scaling ultra-low-water cooling across a fragmented, brownfield 9 GW campus.

**What**: Validate the cooling load calculations against the feasibility of the 32.2 km² buildable area footprint, identifying key piping/pumping CAPEX risks.

**Skills**: Computational fluid dynamics, data center thermodynamics, liquid cooling integration, waste heat management

**Search**: Direct-to-chip cooling 9GW scale, high density data center thermal design

# 4 Expert: EU Sovereign AI & Cyber Security Policy Advisor

**Knowledge**: ANSSI security certifications, DGSI review process, data sovereignty compliance

**Why**: Crucial for assessing the risk associated with delaying sovereign security alignment and quantifying the revenue risk of non-compliant Phase 1 hardware isolation (Decision 3).

**What**: Develop a compliance roadmap showing the minimum DGSI sign-off required before Year 3 to unlock sovereign revenue streams.

**Skills**: Cyber compliance, hardware provenance auditing, national security clearance processes, European digital strategy

**Search**: ANSSI data center certification timeline, DGSI requirements for compute parks

# 5 Expert: Socio-Economic Impact Assessor

**Knowledge**: Local job creation metrics, community compensation frameworks, social license development

**Why**: Needed to evaluate Decision 8 (Workforce Mandate) and Decision 10 (Buffer Zones) to convert potential NIMBYism into tangible local political capital for permitting speed.

**What**: Quantify the minimum local employment commitment (percentage/headcount) necessary to persuade the Prefect to expedite the land-use zoning approval timeline.

**Skills**: Stakeholder mapping, socio-economic modeling, grievance redress mechanisms, ESG reporting

**Search**: Measuring social license impact data center France, local hiring mandates large infrastructure

# 6 Expert: FX Risk Treasury Strategist

**Knowledge**: EUR/USD hedging instruments, cross-currency financing, hardware procurement exposure

**Why**: The plan calls for tracking significant USD exposure for GPUs/TPUs against a EUR budget; this expert assesses the risk insulation strategy proposed in the budget assumptions.

**What**: Audit the proposed 70% forward hedging assumption against current market volatility to stress-test the residual budget risk for the €5B-€10B Phase 1 CAPEX.

**Skills**: Derivative contracts, commodity hedging, corporate treasury management, capital structure optimization

**Search**: FX hedging strategy AI hardware procurement, EUR USD treasury risk management

# 7 Expert: Regional Industrial Ecosystem Planner

**Knowledge**: Hauts-de-France industrial clusters, waste heat off-take logistics, infrastructure synergy

**Why**: Required to assess the practical viability and contractual complexity of Decision 6 (Heat Reuse) within the specific Dunkirk/Cambrai/E-Valley industrial geography.

**What**: Identify the nearest 3 viable industrial anchor partners capable of absorbing at least 500 MWth of low-grade heat output from Phase 2 infrastructure.

**Skills**: Industrial symbiosis, circular economy planning, district heating feasibility, regional development incentives

**Search**: Waste heat reuse market France, Industrial cluster Hauts-de-France opportunities

# 8 Expert: Hyperscale Fiber Optic Architect

**Knowledge**: Terrestrial fiber right-of-way, subsea cable landing agreements, low-latency network design

**Why**: Needed to properly vet the latency and resilience trade-offs in Decision 5 (Fiber Connectivity), balancing speed/terrestrial concentration against subsea redundancy investment.

**What**: Provide a comparison matrix detailing the RTT latency/diversification score for the preferred terrestrial route versus co-funding a new subsea connection point.

**Skills**: DWDM technology, dark fiber negotiation, carrier SLA review, transatlantic connectivity

**Search**: Subsea cable landing points France feasibility, low latency fiber route Paris London