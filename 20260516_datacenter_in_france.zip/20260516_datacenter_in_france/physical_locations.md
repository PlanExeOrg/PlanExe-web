This plan implies one or more physical locations.

## Requirements for physical locations

- Footprint must accommodate 161 km² (though rationalized to ~30 km² buildable area)
- Access to 9 GW of contracted, reliable, low-carbon/nuclear-backed power post-Phase 2
- Proximity to existing industrial revitalization zones (Cambrai, Dunkirk, Valenciennes)
- Favorable cooling climate (low risk for high-water cooling)
- Strategic latency to Paris, London, Brussels, and Frankfurt via diverse fiber routes
- Access to suitable brownfield or industrial land suitable for remediation and large-scale development

## Location 1
France

Hauts-de-France Region: Cluster 1 (E-Valley/Cambrai)

Industrial land near Cambrai or Valenciennes focusing on brownfield redevelopment (E-Valley zone).

**Rationale**: This primary zone targets the established industrial redevelopment narrative. It offers high initial velocity for land assembly if a fragmented/hyper-dense model is adopted, focusing on early phases (1 GW) supported by existing logistics infrastructure.

## Location 2
France

Hauts-de-France Region: Cluster 2 (Dunkirk Port Area)

Industrial or reclaimed land near the Port of Dunkirk.

**Rationale**: Crucial for accessing heavy logistics, potential maritime fiber routes (Dieppe/Calais alternative), and potentially better access to heavy industrial heat-reuse partners or diverse power supply interconnection points (e.g., through ports logistics nodes).

## Location 3
France

Hauts-de-France Region: Buffer/Expansion Reserve Zones

Large-scale agricultural or ecological buffer land parcels identified immediately adjacent to Clusters 1 and 2.

**Rationale**: Supports the chosen 'hyper-dense development model' where 80% of the notional 161 km² is preserved as non-buildable buffer, ecological zones, and land expansion reserve. This mitigates local opposition to urban sprawl and water/stormwater impact while maintaining the legal option to expand up to 9 GW capacity over the 15-year timeline.

## Location Summary
The plan explicitly targets Hauts-de-France, France, focusing on industrial zones near Cambrai, Valenciennes, and Dunkirk. Three locations are specified to align with the Skeptical Path (Pragmatic Scale-Up): identifying two primary industrial clusters for dense buildout and a third adjacent area for land assembly dedicated to the mandated ecological and community buffers (80% of the notional 161 km² footprint).