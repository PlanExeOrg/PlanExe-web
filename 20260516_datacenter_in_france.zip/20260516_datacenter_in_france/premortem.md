A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The 36-month minimum lead time for RTE transmission upgrades following collateral payment commitment is sufficient to avoid blocking the Phase 2 expansion FID based on the 60% tenant trigger. | Engage the European Energy Regulation Specialist to produce a formal, documented range estimate (in months) for 3 GW RTE upgrade completion following funding commitment, comparing it against the mandated window set by the 60% tenant trigger. | The specialist confirms that the minimum RTE completion timeline exceeds 36 months when factoring in typical French administrative latency post-collateral payment. |
| A2 | The proposed 'hyper-dense development model' (80% permanent buffer/reserve) will be legally and politically accepted by DREAL/Prefectural Authorities without requiring a reduction of the buildable area below the planned 32.2 km². | Submit the legal structure defining the 30% 'Permanent Ecological Offset' and the 18-month renewal mechanism for the 50% 'Expansion Reserve' to the French Land Use Lawyer for an immediate assessment of judicial risk. | The lawyer advises that the proposed 30% permanent offset is insufficient to guarantee zoning acceptance without additional, immediate, non-budgeted land compensation or facing litigation that stalls the process past Q2 2027. |
| A3 | The ambitious 75% local workforce upskilling mandate can be achieved within the 3-year Phase 1 schedule without incurring more than a 5% premium on civil construction costs due to quality control overhead or contractor resistance. | Require the EPC bidder interviews to include mandatory scoring weights (min 15%) based on their auditable plan to meet the 75% local hiring quota, and mandate the Social License Orchestrator calculate the cost contingency based on initial RFPs. | Proposed, locked-in EPC contracts show an average required premium exceeding 7% to meet the 75% mandate, or the Workforce Orchestrator confirms local supply cannot meet Q4 2026 supervisory needs. |
| A1 | The 36-month minimum lead time for RTE transmission upgrades following collateral payment commitment is sufficient to avoid blocking the Phase 2 expansion FID based on the 60% tenant trigger. | Engage the European Energy Regulation Specialist to produce a formal, documented range estimate (in months) for 3 GW RTE upgrade completion following funding commitment, comparing it against the mandated window set by the 60% tenant trigger. | The specialist confirms that the minimum RTE completion timeline exceeds 36 months when factoring in typical French administrative latency post-collateral payment. |
| A2 | The proposed 'hyper-dense development model' (80% permanent buffer/reserve) will be legally and politically accepted by DREAL/Prefectural Authorities without requiring a reduction of the buildable area below the planned 32.2 km². | Submit the legal structure defining the 30% 'Permanent Ecological Offset' and the 18-month renewal mechanism for the 50% 'Expansion Reserve' to the French Land Use Lawyer for an immediate assessment of judicial risk. | The lawyer advises that the proposed 30% permanent offset is insufficient to guarantee zoning acceptance without additional, immediate, non-budgeted land compensation or facing litigation that stalls the process past Q2 2027. |
| A3 | The ambitious 75% local workforce upskilling mandate can be achieved within the 3-year Phase 1 schedule without incurring more than a 5% premium on civil construction costs due to quality control overhead or contractor resistance. | Require the EPC bidder interviews to include mandatory scoring weights (min 15%) based on their auditable plan to meet the 75% local hiring quota, and mandate the Social License Orchestrator calculate the cost contingency based on initial RFPs. | Proposed, locked-in EPC contracts show an average required premium exceeding 7% to meet the 75% mandate, or the Workforce Orchestrator confirms local supply cannot meet Q4 2026 supervisory needs. |
| A4 | The reliance on initial non-restricted, commercial-grade hardware for the first 500 MW will not necessitate costly retrofitting or operational segmentation when the DGSI/ANSSI requirements for the future sovereign partition (2 GW) are finalized. | Secure a written DGSI 'No Retrofit Waiver' confirming that the proposed physical segregation (Substation 1 isolation) for the initial 500 MW load is sufficient to accommodate the final sovereign security layering without internal hardware modification. | DGSI states that physical segregation is insufficient, requiring dedicated, nationally approved accelerators or a physical rebuild of the isolation boundary within the first 500 MW facility, invalidating pre-lease assumptions. |
| A5 | The projected PUE degradation from using dry coolers (mandated by water scarcity) for Phase 1 will remain acceptably low (PUE ≤ 1.20) even under peak ambient temperature conditions in Hauts-de-France. | The Hyperscale Thermal Design Engineer must complete CFD modeling validating the 1.20 PUE target using manufacturers' dry-cooler performance curves under the 99th percentile (hottest observed) ambient conditions for the Dunkirk/Cambrai zone. | CFD analysis shows that under 99th percentile conditions, the required dry-cooling capacity forces the operational PUE for Phase 1 to average 1.25 or higher, exposing the project to energy cost overruns and potential tenant SLA breaches. |
| A6 | Long-term, low-margin Heat Reuse Offtake contracts (Decision 6) can be structured to cover the dedicated operational OpEx of the required heat rejection infrastructure plus a minimum 2% net margin, ensuring the social benefit does not become a perpetual drag on overall project profitability. | The Socio-Economic Orchestrator must present initial Heads of Terms from at least one viable industrial partner in the Dunkirk cluster where the implied IRR on the dedicated heat transfer CAPEX exceeds 4.0% (to cover OpEx + 2% margin). | All initial off-take proposals yield an IRR below 2.0% when accounting for pipeline maintenance, pumping energy OpEx, and long-term regulatory risk, indicating the social benefit is a net cost center. |
| A1 | The 36-month minimum lead time for RTE transmission upgrades following collateral payment commitment is sufficient to avoid blocking the Phase 2 expansion FID based on the 60% tenant trigger. | Engage the European Energy Regulation Specialist to produce a formal, documented range estimate (in months) for 3 GW RTE upgrade completion following funding commitment, comparing it against the mandated window set by the 60% tenant trigger. | The specialist confirms that the minimum RTE completion timeline exceeds 36 months when factoring in typical French administrative latency post-collateral payment. |
| A2 | The proposed 'hyper-dense development model' (80% permanent buffer/reserve) will be legally and politically accepted by DREAL/Prefectural Authorities without requiring a reduction of the buildable area below the planned 32.2 km². | Submit the legal structure defining the 30% 'Permanent Ecological Offset' and the 18-month renewal mechanism for the 50% 'Expansion Reserve' to the French Land Use Lawyer for an immediate assessment of judicial risk. | The lawyer advises that the proposed 30% permanent offset is insufficient to guarantee zoning acceptance without additional, immediate, non-budgeted land compensation or facing litigation that stalls the process past Q2 2027. |
| A3 | The ambitious 75% local workforce upskilling mandate can be achieved within the 3-year Phase 1 schedule without incurring more than a 5% premium on civil construction costs due to quality control overhead or contractor resistance. | Require the EPC bidder interviews to include mandatory scoring weights (min 15%) based on their auditable plan to meet the 75% local hiring quota, and mandate the Social License Orchestrator calculate the cost contingency based on initial RFPs. | Proposed, locked-in EPC contracts show an average required premium exceeding 7% to meet the 75% mandate, or the Workforce Orchestrator confirms local supply cannot meet Q4 2026 supervisory needs. |
| A4 | The reliance on initial non-restricted, commercial-grade hardware for the first 500 MW will not necessitate costly retrofitting or operational segmentation when the DGSI/ANSSI requirements for the future sovereign partition (2 GW) are finalized. | Secure a written DGSI 'No Retrofit Waiver' confirming that the proposed physical segregation (Substation 1 isolation) for the initial 500 MW load is sufficient to accommodate the final sovereign security layering without internal hardware modification. | DGSI states that physical segregation is insufficient, requiring dedicated, nationally approved accelerators or a physical rebuild of the isolation boundary within the first 500 MW facility, invalidating pre-lease assumptions. |
| A5 | The projected PUE degradation from using dry coolers (mandated by water scarcity) for Phase 1 will remain acceptably low (PUE ≤ 1.20) even under peak ambient temperature conditions in Hauts-de-France. | The Hyperscale Thermal Design Engineer must complete CFD modeling validating the 1.20 PUE target using manufacturers' dry-cooler performance curves under the 99th percentile (hottest observed) ambient conditions for the Dunkirk/Cambrai zone. | CFD analysis shows that under 99th percentile conditions, the required dry-cooling capacity forces the operational PUE for Phase 1 to average 1.25 or higher, exposing the project to energy cost overruns and potential tenant SLA breaches. |
| A6 | Long-term, low-margin Heat Reuse Offtake contracts (Decision 6) can be structured to cover the dedicated operational OpEx of the required heat rejection infrastructure plus a minimum 2% net margin, ensuring the social benefit does not become a perpetual drag on overall project profitability. | The Socio-Economic Orchestrator must present initial Heads of Terms from at least one viable industrial partner in the Dunkirk cluster where the implied IRR on the dedicated heat transfer CAPEX exceeds 4.0% (to cover OpEx + 2% margin). | All initial off-take proposals yield an IRR below 2.0% when accounting for pipeline maintenance, pumping energy OpEx, and long-term regulatory risk, indicating the social benefit is a net cost center. |
| A7 | Securing necessary right-of-way (ROW) easements for the geographically diverse terrestrial fiber routes required for Phase 1 latency targets (Decision 5) can be acquired and contracted within the standard 12-month mobilization window set for site civil works. | The Telecoms & Connectivity Architect must deliver 100% contracted ROW agreements for the primary terrestrial links to Paris and Brussels, or verify that these contracts are in final legal review stage with all counterparties, prior to Phase 1 construction FID. | ROW negotiations with incumbent carriers and local landowners face localized injunctions or demands for unique, non-standard compensation that delay final contracting by more than 4 months beyond the construction schedule baseline. |
| A8 | The necessary advanced, multi-axis robotic assembly and deployment protocols for direct-to-chip liquid cooling manifolds and piping infrastructure are mature, sourced from a single qualified vendor, and do not require unforeseen custom engineering during the Phase 1 1 GW ramp-up. | The Hyperscale Data Center Design & Cooling Engineer must finalize contracts with a single vendor for 100% of the Phase 1 liquid cooling infrastructure (piping, manifold arrays, quick-connects) that includes firm delivery dates 12 months in advance of required installation start. | The primary vendor declares force majeure or requires a 6-month re-engineering process due to unforeseen site conditions or complexity related to integrating the cooling manifolds across the fragmented, non-contiguous industrial zones. |
| A9 | The initial commercial/non-sovereign leases signed for Phase 1 capacity (500 MW - 1 GW) will maintain an average contracted revenue yield per MW that is at least 15% higher than the projected minimum revenue from a fully secured sovereign AI workload contract. | The Strategy Lead must present executed early-stage Leasing Agreements that demonstrate an average EUR/MW/year yield that exceeds the NPV-adjusted minimum sovereign rate by the required margin, with no more than 20% of capacity secured via performance guarantees instead of take-or-pay. | The executed Phase 1 leases average less than 5% yield differential against the modeled sovereign baseline, suggesting the market is not currently bidding sufficient premium for fast-to-market commercial space. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Buffer Budget Black Hole | Process/Financial | A2 | Financial Controller & Currency Risk Manager | CRITICAL (20/25) |
| FM2 | The RTE Paralysis: Stranded Collateral Risk | Technical/Logistical | A1 | Grid & Power Procurement Specialist | CRITICAL (25/25) |
| FM3 | Local Mandate Backlash and The Skill Mismatch Delay | Market/Human | A3 | Social License & Community Benefits Orchestrator | CRITICAL (16/25) |
| FM4 | The Buffer Budget Black Hole | Process/Financial | A1 | Financial Controller & Currency Risk Manager | CRITICAL (20/25) |
| FM5 | Local Mandate Backlash and The Skill Mismatch Delay | Technical/Logistical | A3 | Social License & Community Benefits Orchestrator | CRITICAL (16/25) |
| FM6 | Sovereign Contamination Halts Commercial Leasing | Market/Human | A4 | Regulatory & Sovereignty Compliance Lead | CRITICAL (20/25) |
| FM7 | The Buffer Budget Black Hole | Process/Financial | A1 | Financial Controller & Currency Risk Manager | CRITICAL (20/25) |
| FM8 | Terrestrial Fiber Gridlock Cripples Synchronization | Technical/Logistical | A7 | Telecoms & Connectivity Architect | CRITICAL (20/25) |
| FM9 | Anchor Tenants Downgrade Yield Expectations | Market/Human | A9 | Strategy & Regulatory Affairs | CRITICAL (16/25) |


### Failure Modes

#### FM1 - The Buffer Budget Black Hole

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: Financial Controller & Currency Risk Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project critically relies on reserving 80% of the 161 km² footprint for buffers/reserves to satisfy social license and initial zoning requirements. By assuming this land can be held indefinitely without fully budgeting its annual carrying cost (taxes, basic maintenance, legal fees), the Phase 1 CAPEX is deceptively low. When judicial or prefectural review demands immediate, binding financial dedication to the 30% permanent offset and an 18-month holding budget for the 50% reserve, the unbudgeted capital call (estimated at >€1.3 Billion) is triggered prematurely. This forces a draw on committed financing lines intended for critical long-lead power equipment, leading to immediate covenant breaches with lenders who assumed a higher proportion of infrastructure commitment versus land holding cost, resulting in a halt of construction drawings release.

##### Early Warning Signs
- The Land Modeler reports holding cost variance >15% against the initial 18-month budget estimate by M+6.
- The Financial Controller flags an upcoming draw request reduction greater than 5% due to land holding costs overriding infrastructure funding.
- DREAL demands a finalized, legally binding escrow account for the 30% permanent offset before granting EIA approval.

##### Tripwires
- Unbudgeted Land Holding Cost Exceeds €500 Million
- DREAL Delays Zoning Approval by >90 Days Pending Buffer Capital Confirmation

##### Response Playbook
- Contain: Immediately place an 18-month moratorium on securing ROW easements for non-essential Phase 2 fiber/grid ties to reallocate immediate capital to the land holding escrow.
- Assess: Financial Controller must re-run Phase 1 financing stress test with a €1.3B land holding cost baked into the initial CAPEX baseline to determine current covenant breach position.
- Respond: Approach primary creditors with a re-baselined Phase 1 budget, formally requesting a capital reallocation waiver by sacrificing non-critical internal R&D budget lines.


**STOP RULE:** Final holding cost budget for the 128.8 km^2 buffer exceeds 15% of the total Phase 1 CAPEX budget, mandating a formal review of the 9 GW strategic viability.

---

#### FM2 - The RTE Paralysis: Stranded Collateral Risk

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A1
- **Owner**: Grid & Power Procurement Specialist
- **Risk Level:** CRITICAL 25/25 (Likelihood 5/5 × Impact 5/5)

##### Failure Story
The project intentionally defers funding major RTE transmission upgrades (required for 3 GW expansion) until the 60% tenant revenue trigger is met (Pragmatic Scale-Up). However, if the assumed 36-month RTE completion window proves overly optimistic—and expert consultation reveals a typical 48-month timeline—the grid will not be ready for Phase 2 capacity when tenants arrive. Tenants, seeing power scarcity, will balk at 60% commitments, causing the trigger to fail. If the landlord proceeds to pay the initial financial collateral for the 3 GW studies based on the old timeline, that collateral becomes stranded capital €1B-€2B, while the Phase 1 site runs out of expansion room, resulting in a complete halt of the 9 GW scaling ambition and massive liquidity drag.

##### Early Warning Signs
- European Energy Regulation Specialist reports minimum RTE upgrade lead time > 40 months in formal documentation.
- RTE demands collateral for Phase 2 studies that significantly exceeds the budgeted allowance for pre-FID activities.
- Phase 1 tenant commitment rate stagnates below 40% for two consecutive quarters, indicating doubt about future expansion availability.

##### Tripwires
- RTE Confirmed Upgrade Timeline Exceeds 42 Months Post-FID
- Phase 2 Tenant Commitment Falls Below 50% by M+18

##### Response Playbook
- Contain: Immediately pause all non-essential work related to Phase 2 infrastructure planning (e.g., fiber route acquisition for Phase 2) to conserve liquidity.
- Assess: Grid Specialist must determine the exact delta cost and time required to secure a binding RTE commitment for only 1.5 GW (Phase 2 Lite) based on current tenant status.
- Respond: Strategy Lead must present the Board with a 'Grid Confirmed' vs. 'Tenant Confirmed' pivot scenario, prioritizing immediate collateral release if grid certainty can be bought early.


**STOP RULE:** RTE officially publishes an interconnection schedule that pushes Phase 2 (3 GW) readiness past Year 7, invalidating the 15-year 9 GW timeline.

---

#### FM3 - Local Mandate Backlash and The Skill Mismatch Delay

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Social License & Community Benefits Orchestrator
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project mandates a 75% utilization of local upskilled apprentices to secure critical social license and favorable permitting velocity. The failure mode occurs when the reality of local technical school capabilities conflicts with the aggressive Phase 1 construction schedule (3 years). High reliance on internal team optimism (assuming training works perfectly) leads to scheduling specialized liquid cooling and high-security isolation with under-skilled labor. This technical deficit causes cascading quality failures, forcing EPC contractors to implement expensive mitigation (hiring premium international specialists) exceeding the contingency budget, or, worse, causing major quality breaches in the critical PUE/security isolation layers. This results in a 6-12 month delay in achieving 1.20 PUE validation and DGSI review readiness, leading to tenant SLA breaches on early capacity.

##### Early Warning Signs
- EPC contractor submits formal notice citing 75% local hiring mandate as a cause for a 45-day schedule slip.
- The calculated premium cost for integrating oversight management exceeds the €40M contingency budget by 20%.
- PUE validation tests repeatedly fail to break stagnation above 1.25 due to novice installation errors in cooling loop integrity.

##### Tripwires
- Phase 1 Construction Schedule Slips by > 60 days due to Labor Shortages
- Local Workforce Integration Rate Falls Below 50% by M+15

##### Response Playbook
- Contain: Immediately halt mobilization of subsequent construction crews that rely heavily on specialized liquid cooling skills until the primary cohort demonstrates competence.
- Assess: Social License Orchestrator must quantify the exact OPEX penalty exposure from the PUE degradation caused by the skill gap, comparing it against the cost of importing immediate supplemental senior labor.
- Respond: Initiate the 'Premium Labor Fly-In' contingency plan, accepting the immediate budget overrun to stabilize the schedule, while simultaneously lobbying local authorities to relax the 75% mandate temporarily in exchange for increased funding into permanent training infrastructure.


**STOP RULE:** The operational PUE validation for the first 250 MW fails to reach 1.25 within 9 months of initial commissioning, indicating a permanent, unrecoverable technical/skills deficit.

---

#### FM4 - The Buffer Budget Black Hole

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Financial Controller & Currency Risk Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project critically relies on reserving 80% of the 161 km² footprint for buffers/reserves to satisfy social license and initial zoning requirements. By assuming this land can be held indefinitely without fully budgeting its annual carrying cost (taxes, basic maintenance, legal fees). When judicial or prefectural review demands immediate, binding financial dedication to the 30% permanent offset and an 18-month holding budget for the 50% reserve, the unbudgeted capital call (estimated at >€1.3 Billion) is triggered prematurely. This forces a draw on committed financing lines intended for critical long-lead power equipment, leading to immediate covenant breaches with lenders who assumed a higher proportion of infrastructure commitment versus land holding cost, resulting in a halt of construction drawings release.

##### Early Warning Signs
- The Land Modeler reports holding cost variance >15% against the initial 18-month budget estimate by M+6.
- The Financial Controller flags an upcoming draw request reduction greater than 5% due to land holding costs overriding infrastructure funding.
- DREAL Delays Zoning Approval by >90 Days Pending Buffer Capital Confirmation

##### Tripwires
- Unbudgeted Land Holding Cost Exceeds €500 Million
- DREAL Delays Zoning Approval by >90 Days Pending Buffer Capital Confirmation

##### Response Playbook
- Contain: Immediately place an 18-month moratorium on securing ROW easements for non-essential Phase 2 fiber/grid ties to reallocate immediate capital to the land holding escrow.
- Assess: Financial Controller must re-run Phase 1 financing stress test with a €1.3B land holding cost baked into the initial CAPEX baseline to determine current covenant breach position.
- Respond: Approach primary creditors with a re-baselined Phase 1 budget, formally requesting a capital reallocation waiver by sacrificing non-critical internal R&D budget lines.


**STOP RULE:** Final holding cost budget for the 128.8 km² buffer exceeds 15% of the total Phase 1 CAPEX budget, mandating a formal review of the 9 GW strategic viability.

---

#### FM5 - Local Mandate Backlash and The Skill Mismatch Delay

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A3
- **Owner**: Social License & Community Benefits Orchestrator
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project mandates a 75% utilization of local upskilled apprentices to secure critical social license and favorable permitting velocity. The failure mode occurs when the reality of local technical school capabilities conflicts with the aggressive Phase 1 construction schedule (3 years). High reliance on internal team optimism (assuming training works perfectly) leads to scheduling specialized liquid cooling and high-security isolation with under-skilled labor. This technical deficit causes cascading quality failures, forcing EPC contractors to implement expensive mitigation (hiring premium international specialists) exceeding the contingency budget, or, worse, causing major quality breaches in the critical PUE/security isolation layers. This results in a 6-12 month delay in achieving 1.20 PUE validation and DGSI review readiness, leading to tenant SLA breaches on early capacity.

##### Early Warning Signs
- EPC contractor submits formal notice citing 75% local hiring mandate as a cause for a 45-day schedule slip.
- The calculated premium cost for integrating oversight management exceeds the €40M contingency budget by 20%.
- PUE validation tests repeatedly fail to break stagnation above 1.25 due to novice installation errors in cooling loop integrity.

##### Tripwires
- Phase 1 Construction Schedule Slips by > 60 days due to Labor Shortages
- Local Workforce Integration Rate Falls Below 50% by M+15

##### Response Playbook
- Contain: Immediately halt mobilization of subsequent construction crews that rely heavily on specialized liquid cooling skills until the primary cohort demonstrates competence.
- Assess: Social License Orchestrator must quantify the exact OPEX penalty exposure from the PUE degradation caused by the skill gap, comparing it against the cost of importing immediate supplemental senior labor.
- Respond: Initiate the 'Premium Labor Fly-In' contingency plan, accepting the immediate budget overrun to stabilize the schedule, while simultaneously lobbying local authorities to relax the 75% mandate temporarily in exchange for increased funding into permanent training infrastructure.


**STOP RULE:** The operational PUE validation for the first 250 MW fails to reach 1.25 within 9 months of initial commissioning, indicating a permanent, unrecoverable technical/skills deficit.

---

#### FM6 - Sovereign Contamination Halts Commercial Leasing

- **Archetype**: Market/Human
- **Root Cause**: Assumption A4
- **Owner**: Regulatory & Sovereignty Compliance Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project assumes that the initial 500 MW commercial cluster can utilize non-restricted hardware and physical segregation (Substation 1) while the subsequent sovereign zone design is finalized and reviewed by DGSI/ANSSI. If DGSI rejects this intermediate quarantine state—stating that any shared infrastructure (e.g., common fiber entry point, shared utility feed to Substation 1) compromises future sovereign integrity—the entire Phase 1 build is retroactively deemed non-compliant for the premium state contract stream. Crucially, if the hardware already installed is deemed unacceptable for the sovereign roadmap, major commercial tenants demanding both commercial and sovereign workload capacity will perceive immediate operational risk or vendor lock-in, causing them to pause or retract their Phase 2 commitments (which rely on a clear revenue path), collapsing the 60% Tenant Acquisition Trigger Threshold before Phase 2 FID can occur.

##### Early Warning Signs
- DGSI/ANSSI review takes longer than 10 months without issuing formal feedback on hardware class guidelines.
- Phase 1 anchor tenants request contractual clauses that condition their expansion on a defined, high-confidence sovereign certification timeline.
- The Regulatory Lead reports that DGSI insists on an end-to-end, single-vendor hardware stack across the entire site.

##### Tripwires
- DGSI/ANSSI Review Passes 12 Months Without Written Security Protocol Confirmation
- Anchor Tenants Demand Legal Indemnity Regarding Future Sovereign Zone Segregation

##### Response Playbook
- Contain: Immediately cease procurement of any non-DGSI approved hardware slated for installation beyond the currently commissioned 100 MW load.
- Assess: Regulatory Lead performs a rapid gap-analysis contrasting current Phase 1 hardware specifications against known high-security baseline requirements, quantifying potential retrofitting costs.
- Respond: Strategy Lead initiates immediate negotiations with DGSI for a formal 'Work-In-Progress Security Waiver' for the existing 100 MW, while simultaneously shifting Phase 1 leasing focus away from hybrid clients toward purely commercial entities.


**STOP RULE:** DGSI issues a formal finding that the existing physical substation infrastructure utilized by Phase 1 non-sovereign tenants necessitates physical separation that requires decommissioning or modification of the Phase 1 power feed.

---

#### FM7 - The Buffer Budget Black Hole

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Financial Controller & Currency Risk Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project critically relies on reserving 80% of the 161 km² footprint for buffers/reserves to satisfy social license and initial zoning requirements. By assuming this land can be held indefinitely without fully budgeting its annual carrying cost (taxes, basic maintenance, legal fees). When judicial or prefectural review demands immediate, binding financial dedication to the 30% permanent offset and an 18-month holding budget for the 50% reserve, the unbudgeted capital call (estimated at >€1.3 Billion) is triggered prematurely. This forces a draw on committed financing lines intended for critical long-lead power equipment, leading to immediate covenant breaches with lenders who assumed a higher proportion of infrastructure commitment versus land holding cost, resulting in a halt of construction drawings release.

##### Early Warning Signs
- The Land Modeler reports holding cost variance >15% against the initial 18-month budget estimate by M+6.
- The Financial Controller flags an upcoming draw request reduction greater than 5% due to land holding costs overriding infrastructure funding.
- DREAL Delays Zoning Approval by >90 Days Pending Buffer Capital Confirmation

##### Tripwires
- Unbudgeted Land Holding Cost Exceeds €500 Million
- DREAL Delays Zoning Approval by >90 Days Pending Buffer Capital Confirmation

##### Response Playbook
- Contain: Immediately place an 18-month moratorium on securing ROW easements for non-essential Phase 2 fiber/grid ties to reallocate immediate capital to the land holding escrow.
- Assess: Financial Controller must re-run Phase 1 financing stress test with a €1.3B land holding cost baked into the initial CAPEX baseline to determine current covenant breach position.
- Respond: Approach primary creditors with a re-baselined Phase 1 budget, formally requesting a capital reallocation waiver by sacrificing non-critical internal R&D budget lines.


**STOP RULE:** Final holding cost budget for the 128.8 km² buffer exceeds 15% of the total Phase 1 CAPEX budget, mandating a formal review of the 9 GW strategic viability.

---

#### FM8 - Terrestrial Fiber Gridlock Cripples Synchronization

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Telecoms & Connectivity Architect
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Phase 1 relies upon securing diverse, low-latency terrestrial fiber paths (to Paris/Brussels) within the standard 12-month construction mobilization window to support synchronized AI workloads across the desired clustered sites. If ROW acquisition proves unexpectedly protracted due to opposition from regional landowners or incumbent carriers enforcing restrictive legacy contracts, the required low-latency paths cannot be stood up in time. This results in cross-cluster latency exceeding 2ms RTT, immediately violating the technical requirements necessary for high-frequency model synchronization. Tenants relying on this cluster connectivity will immediately breach their connectivity SLAs, leading to penalty claims and, critically, making the 60% threshold for Phase 2 expansion unachievable as tenants cite foundational infrastructure failure over capacity shortage.

##### Early Warning Signs
- Telecoms Architect reports that 50% of required Tier 1 terrestrial ROW agreements are still pending legal sign-off past M+9.
- Incumbent carriers file a formal objection with the local permitting authority contesting the proposed fiber conduit route segmentation.
- Internal latency tests between initial build clusters run >2.5ms RTT using provisional carrier access.

##### Tripwires
- ROW Acquisition Completion Rate for Phase 1 Fiber < 80% by M+15
- First Tenant Move-in Fails Latency SLA Test (>2.2ms RTT)

##### Response Playbook
- Contain: Immediately divert remaining Phase 1 fiber CAPEX away from secondary/tertiary carrier negotiations and concentrate 100% effort on co-funding the identified subsea landing point to establish *one* highly resilient, albeit higher-latency, path.
- Assess: Telecoms Architect must quantify the impact of a >2ms Latency baseline on the largest projected Phase 1 tenant's contractual penalty exposure.
- Respond: Strategy team must immediately present a 'Latency Cap Waiver' proposal to anchor tenants, offering short-term OpEx credits in exchange for accepting a temporary higher latency until long-haul redundancy can be established.


**STOP RULE:** Final latency between any two major cluster nodes exceeds 3.0ms RTT 6 months post-initial tenant activation.

---

#### FM9 - Anchor Tenants Downgrade Yield Expectations

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Strategy & Regulatory Affairs
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The 'Pragmatic Scale-Up' strategy is predicated on Phase 1 commercial leasing generating significantly higher yields (assumed 15% premium) than future sovereign contracts to cover early funding gaps and organizational drag. If the market softens or competing European capacity comes online faster than anticipated, anchor tenants will refuse to enter high-commitment take-or-pay deals that meet the 15% premium assumption. This forces the organization to accept revenue closer to the lower sovereign baseline. This lower-than-expected initial yield starves the operating budget, preventing the organization from meeting the required internal IRR hurdle for the massive capital expenditure required for the Heat Reuse network (Decision 6) and the high mandatory holding costs for the land buffer (A2), leading to immediate financial underperformance relative to investor covenants.

##### Early Warning Signs
- Average committed EUR/MW/year across initial ten signed LOIs is less than 8% above the modeled sovereign baseline.
- Tenant Acquisition progress stalls at 40% capacity utilization for three consecutive months post-M+24, indicating market saturation.
- Leasing team reports that 30% of capacity signed now relies on performance-based revenue guarantees rather than firm take-or-pay clauses.

##### Tripwires
- Phase 1 Committed Yield Falls Below 10% Premium to Sovereign Baseline
- Tenant Acquisition Progress Stalls Below 60% Committed Capacity by M+36

##### Response Playbook
- Contain: Immediately suspend marketing funds targeting non-anchor (smaller) commercial tenants and redirect all sales efforts toward leveraging existing relationships to secure one final 200 MW sovereign MoU negotiation.
- Assess: Financial Controller runs a revised model showing viability if the average IRR on the *entire* 9 GW project drops by 150 basis points due to sustained lower starting yields.
- Respond: Strategy Lead initiates discussions with anchor tenants proposing a 'Revenue Share Backstop' mechanism, where the developer agrees to forgo the final 2% developer margin on sovereign contracts if the commercial tenants meet an aggressive 1 GW utilization target by Year 4.


**STOP RULE:** The cumulative committed revenue for Phase 2 remains below 55% of the requirement 6 months past the scheduled Phase 2 FID date.
