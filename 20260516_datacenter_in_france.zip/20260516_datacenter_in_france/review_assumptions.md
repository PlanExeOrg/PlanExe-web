## Domain of the expert reviewer
High-Scale Infrastructure Project Planning and Feasibility Assessment

## Domain-specific considerations

- Grid Interconnection Lead Times (RTE/EDF)
- French Regulatory/Sovereignty Alignment (DGSI/ANSSI)
- Large-Scale Land Assembly and Zoning Complexity (161 km²)
- Capital Allocation Sequencing vs. Revenue Triggering
- Workforce Development for Specialized Infrastructure

## Issue 1 - Critical Missing Assumption: Regulatory Time Buffer (RTE/Permitting)
The plan heavily relies on the 'Pragmatic Scale-Up' strategy, deferring transmission funding until 60% tenant commitment for Phase 2 (3 GW). However, there is *no explicit assumption* about the actual time required by RTE (Réseau de Transport d'Électricité) to *approve and complete* mandated transmission upgrades *after* funding commitment. French grid extension lead times are notoriously long, often exceeding 3-5 years for multi-GW projects. This creates a dangerous dependency gap: tenants commit based on power availability, but infrastructure completion time is outside developer control.

**Recommendation:** Introduce a critical missing assumption based on conservative external benchmarks: Assume a minimum 36-month completion time for RTE-mandated substation and tie-line upgrades following Phase 2 FID (i.e., the 60% tenant trigger). Adjust the Tenant Acquisition Trigger Threshold (Decision 4) to include a 'Power Readiness Lockout Clause': Phase 2 Commercial Operation Date (COD) is defined as Min(Tenant Anchor COD + 12 months, RTE Upgrade Completion Date).

**Sensitivity:** The baseline assumption is an implicit 18-month grid lead time post-funding. If the actual lead time is 36 months (50% longer), the delay in realizing 3 GW revenue pushes the project's overall timeline by 1.5 years. This delay equates to a loss of projected ROI by 8-12% over the first four years due to deferred revenue scaling, potentially increasing the total project cost of capital by €500M–€800M.

## Issue 2 - Under-Explored Assumption: Financial Viability of 80% Land Buffer
The chosen 'hyper-dense' model reserves 80% (128.8 km²) of the target 161 km² for buffers and reserves, with only 20% (32.2 km²) buildable. The assumption is that this preserves optionality and smooths permitting. However, the financial viability hinges on whether the cost of acquiring and holding this massive land reserve (even if less contested) is covered by the operating budget or must be capitalized. Furthermore, the ability to *legally* hold 80% of land designated for future industrial expansion as 'permanent ecological preservation' or 'buffer' under French planning law for 15 years without strong, binding ongoing community benefit contracts (Decision 6) is highly questionable and risks regulatory reversal.

**Recommendation:** Explicitly assume a holding cost budget for the 128.8 km² buffer zone, estimated at €50,000–€75,000 per hectare annually for maintenance, insurance, and ongoing legal defense buffers. Crucially, decouple the 'permanent' nature of 80% from the strategic plan: Reclassify 50% of the buffer as 'Phase 2/3 Expansion Reserve' requiring only annual agricultural lease renewal, and the remaining 30% as 'Permanent Ecological Offset' requiring upfront, binding, funded commitments to local environmental bodies (Decision 10).

**Sensitivity:** If the annual holding cost for the 12,880 hectares is underestimated by €20,000/hectare (total €257.6M annually for 5 years pre-scaling), the initial Phase 0/1 CAPEX will overrun by €1.3B. If local authorities mandate converting 30% of the buildable area (10 km²) back into buffer due to social disputes, the maximum potential capacity is permanently reduced from 9 GW to ~6 GW, decreasing baseline potential ROI by 30-40%.

## Issue 3 - Unrealistic Assumption: Workforce Skill Uplift Velocity
Decision 8 mandates aggressive local workforce sourcing (75% apprenticeships) to secure social license. While necessary, assuming this can be achieved without causing Phase 1 construction delays is highly optimistic. Specialized construction for liquid-cooled DCs, combined with the requirement for DGSI physical isolation verification (Risk 5), demands specialized skills that regional vocational schools (Decision 3/8) cannot generate instantly. The assumption appears to underestimate the management overhead and quality control risks associated with a massive, unproven upskilling program.

**Recommendation:** Introduce a staffing latency factor to the timeline: Assume only 30% of specialty construction hours can be filled by qualified local hires in Year 1, rising to 50% by Year 2, forcing reliance on higher-cost international contractors for the initial 12-18 months. Integrate a contingency budget line item of €20M–€40M specifically for importing specialized management teams to *oversee and train* the local workforce, mitigating quality risk without halting site mobilization.

**Sensitivity:** If specialized labor is unavailable, the construction timeline for Phase 1 (1 GW) could realistically extend from a baseline of 24 months to 30-36 months. This 6-12 month delay, combined with associated project management costs (€50M–€100M), would reduce the project's Net Present Value (NPV) by 4-6% based on foregone early revenues.

## Review conclusion
The project plan is strategically sound in identifying interdependent risks (Power, Land, Social License) and appropriately selects a skeptical, phased approach ('Pragmatic Scale-Up'). However, the execution timeline is overly optimistic, specifically regarding external dependencies. The review identified three critical weaknesses by quantifying missing assumptions:

1. **Missing Grid Completion Buffer:** The plan lacks a realistic timeline for RTE execution post-funding commitment, posing a 1.5-year revenue delay risk.
2. **Uncosted Land Holding:** The massive 80% buffer zone is assumed manageable but lacks a dedicated holding cost budget, risking a €1.3B overrun in early CAPEX.
3. **Workforce Optimism:** The reliance on rapid local upskilling to maintain the aggressive construction schedule introduces a high likelihood of 6-12 month technical delays in Year 1, impacting early ROI.

Immediate action must focus on locking in regulatory timing buffers, fully budgeting for the massive land reserve, and accepting higher initial construction costs/delays to ensure genuine local workforce integration.