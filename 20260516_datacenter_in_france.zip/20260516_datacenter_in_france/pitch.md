Persuasive elevator pitch.

# Architecting the 9 GW Sovereign AI Engine for France

This document outlines the strategic roadmap for building the **9 GW Sovereign AI Engine for France**, focusing on achieving national digital autonomy through disciplined, phased scaling and aggressive de-risking.

## Project Overview and Core Strategy

We are moving beyond tentative planning to architect a machine of unprecedented scale. The primary focus is tackling the Gordian knot of French infrastructure: **Power, Land, and Sovereignty**.

Our approach utilizes the meticulously planned 'Pragmatic Scale-Up' path across the 15-year roadmap. This strategy involves:

- Building fast where we control the land (**hyper-dense nodes**).
- Locking-in leverage where we do not (committing to expansion only after securing **60% take-or-pay anchors** before committing massive grid CAPEX).

This process systematically de-risks every critical dependency, proving feasibility block-by-block to provide the bedrock for French AI leadership without incurring undue financial risk from bureaucratic uncertainty. This is defined as controlled, strategic aggression.

## Target Audience

This pitch is directed at key decision-makers who prioritize risk mitigation on multi-decade, high-CAPEX projects:

- **Senior Investors**
- **Governmental Partners** (Prefectural Authorities, DGSI/ANSSI liaisons)
- **Key Infrastructure Stakeholders** (RTE/EDF executives)

## Risks and Mitigation Strategies

We directly confront the three identified 'Key Risks' through proactive measures integrated into the design:

- **Regulatory Delays:** Mitigated by proactively zoning 25% of the land as permanent ecological offset (Decision 10) to satisfy local opposition.
- **RTE/Grid Confirmation Failure:** Mitigated by strictly tying expansion CAPEX to both secured tenant revenue (60% threshold) and binding power contracts (Decision 4 & 1).
- **Failure to Monetize Local Benefit:** Mitigated by immediately budgeting for the skills academy and heat reuse feasibility.

Our strategy is built on anticipating and neutralizing these blocking factors through **controlled development**.

## Stakeholder Benefits

The project delivers tangible value tailored to distinct stakeholder groups:

- **Investors:** Gain minimized exposure to uncertain French regulatory timelines by linking scale-up to **proven revenue** (Decision 4).
- **Government Partners:** Secure verifiable national sovereignty via pre-engineered security isolation protocols (Decision 3) and tangible regional economic uplift via the **mandated local workforce investment** (Decision 8).

## Ethical Considerations and Community Integration

Our design prioritizes **long-term community integration** over quick profit, evidenced by key decisions:

- The hyper-dense node strategy preserves 80% of the footprint for ecological and community buffers to minimize sprawl (Decision 2).
- An ironclad mandate exists to train and employ **75% of the local workforce** (Decision 8).

Social license is treated as a foundation, not an afterthought.

## Metrics for Success

Success is measured beyond standard operational efficiency goals (Phase 1 operation at <=1.20 PUE). Critical validation points include:

- Achieving *binding* RTE allocation for the **3 GW Phase 2 requirement** *before* Phase 1 construction financing FID.
- Securing **60% committed take-or-pay revenue** for the next tranche.

These metrics validate the core power and **financial de-risking strategy**.

## Collaboration Opportunities

We actively seek external partnerships to enhance project delivery:

- **Regional technical schools** to co-develop the skills academy required for workforce uplift (Decision 8).
- **National energy partners** to collaborate on the feasibility studies for high-volume, low-margin heat reuse contracts, transforming a liability into a **public benefit asset** (Decision 6).

## Long-term Vision

This 9 GW campus is positioned to be Europe's largest AI facility and the template for **resilient, sovereign European digital infrastructure**. By mastering the integration of massive power demands, navigating complex sovereign security requirements, and demonstrating sustainable land use through hyper-density, we create a repeatable, de-risked blueprint for the next wave of critical energy-intensive technology deployment across the continent.

## Call to Action

We are proceeding immediately to **Phase 0 validation**. We require commitment to:

- Fund the pre-paid RTE grid impact studies.
- Finalize the legal structure for the 75% local workforce mandate.

These commitments must be secured within the next **90 days** to maintain our Q4 2026 Phase 1 Construction FID timeline.