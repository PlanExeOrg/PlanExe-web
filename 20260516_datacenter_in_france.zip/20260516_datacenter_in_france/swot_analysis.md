
## Strengths 👍💪🦾
- Strategic location in Hauts-de-France offers proximity to key Northern European markets (Paris, London, Brussels, Frankfurt) and leverages the region's industrial redevelopment narrative.
- Strong technical foundation targeting low PUE (1.15–1.25) through mandatory direct-to-chip liquid cooling, optimizing operational efficiency.
- Adoption of the 'Pragmatic Scale-Up' strategy, which de-risks capital deployment by linking Phase 2 funding to 60% committed tenant revenue (Decision 4).
- Proactive security planning via early engagement and physical isolation protocols for the sovereign AI partition (Decision 3), vital for attracting premium state contracts and mitigating state risk.
- Land-use model that reserves 80% (128.8 km²) as buffers/reserves (hyper-dense model), which strategically mitigates immediate opposition from agricultural displacement and environmental concerns.

## Weaknesses 👎😱🪫⚠️
- Extreme capital outlay required, with full 9 GW buildout projected at €100B–€140B+.
- High dependency on external, uncontrolled French regulatory bodies (RTE, DREAL, DGSI) for grid connection and permitting, creating critical path schedule risk.
- The required 161 km² footprint is exceptionally large, forcing a fragmented, hyper-dense model across multiple industrial zones, complicating unified physical security and logistics.
- The ambitious technological roadmap (ultra-low PUE, immediate liquid cooling scale-up on brownfield sites) introduces higher-than-standard technical integration risk (Risk 2).
- Missing 'Killer Application': The plan targets general AI training/inference but lacks a flagship, compelling use case uniquely tailored to the French/EU context that would guarantee expedited national backing or immediate demand pull beyond commercial hyperscaler needs.

## Opportunities 🌈🌐
- Development of a **Killer Application**: Creating a dedicated, high-profile 'Sovereign AI Hub' leveraging ANSSI/DGSI certification to become the default, trusted compute provider for French and specific EU public sector workloads, thereby guaranteeing foundational utilization and favorable long-term PPA terms.
- Monetization of Waste Heat (Decision 6): Leveraging the industrial context (Dunkirk/Cambrai) to secure binding, long-term contracts for industrial heat reuse, transforming an environmental liability into a local economic asset and accelerating social license.
- Leveraging Extreme Scale: The 9 GW target, if realized, positions the campus as a primary digital pillar in Northern Europe, attracting Tier 1 anchor tenants willing to sign high-commitment, long-term (take-or-pay) contracts.
- Workforce Development (Decision 8): Aggressive local skill uplift program can create a unique, competitive operational labor advantage within Hauts-de-France, lowering long-term OpEx and solidifying social license.
- Strategic Fiber Ownership: Opportunity to secure long-term dark fiber rights-of-way or co-fund subsea landing points (Decision 5), reducing dependency on incumbent carriers and gaining favorable latency control for the entire 15-year lifecycle.

## Threats ☠️🛑🚨☢︎💩☣︎
- RTE/Grid Capacity Denial or Extreme Delay: Failure to secure binding transmission upgrades for Phase 2 (3 GW) by the time Phase 1 construction financing closes (Risk 3).
- Permitting Hold-Up: Judicial review or political intervention challenging the 80% land buffer model (Risk 7), arresting construction momentum post-Phase 1 success.
- Geopolitical and Currency Volatility: Significant EUR/USD depreciation increasing hardware procurement costs by billions (€4.32B residual risk without full hedging).
- Security Review Bottleneck (DGSI/ANSSI): Protracted national security vetting for the sovereign partition could delay access to premium revenue streams, causing tenant migration risk.
- Water Scarcity Constraints: Regional hydrological limitations forcing an immediate switch from preferred low-water cooling to higher-risk methods, leading to mandatory curtailment (Risk 6).

## Recommendations 💡✅
- Immediately budget and execute long-lead physical securing of Rights-of-Way (ROW) easements for Phase 2 transmission interconnects, irrespective of immediate financing commitment, to buffer the RTE schedule risk. **Owner:** Infrastructure Lead. **Deadline:** 2026-12-31.
- Initiate the 'Sovereign AI Hub Killer Application' track: Allocate 20% of the Phase 0 budget to secure pre-agreements with DGSI/ANSSI defining the operational parameters for a dedicated 2 GW partition, contingent on the success of the initial 500 MW commercial load. This ensures a defined premium revenue stream by Year 5. **Owner:** Strategy & Regulatory Affairs. **Deadline:** Q1 2027 (10 months).
- Formalize the 80% land buffer as a binding local concession by establishing the 'Permanent Ecological Offset' for 30% of the total acreage and immediately contracting the holding costs for the remaining 50% Expansion Reserve for 18 months, integrating the associated CAPEX into the Phase 1 budget review. **Owner:** Land & Development Director. **Deadline:** 2026-09-01.
- Mandate that all major hardware procurement contracts (GPUs/TPUs) for Phase 1 and Phase 2 tranches feature EUR-indexed pricing floors and mandatory 70% forward FX hedging coverage, moving the residual USD exposure below €1 Billion. **Owner:** CFO/Treasury. **Deadline:** Q2 2027 (Concurrent with hardware ordering).
- Prioritize finalizing one binding, industrial heat-reuse off-take partner (Decision 6) within the Dunkirk cluster planning zone to convert the social license risk into a concrete public benefit asset, using this pilot to de-risk further community acceptance across the entire footprint. **Owner:** Community Engagement Lead. **Deadline:** Q4 2026.

## Strategic Objectives 🎯🔭⛳🏅
- Secure a binding RTE capacity contract for a minimum of 2.5 GW (for Phase 2 expansion) by the date of FID for Phase 1 construction, validated against secured tenant commitments totaling 60% of the 2 GW tranche. (Time-bound: Prior to Phase 1 FID).
- Successfully deploy and commission the initial 500 MW commercial compute capacity (Phase 1) while maintaining a verifiable operational PUE of 1.20 or less, and achieve DGSI sign-off on the physical isolation of this commercial zone. (Measurable: PUE <=1.20 & DGSI check). (Time-bound: Within 36 months).
- Neutralize the primary land assembly risk by securing legally binding agreements for 30% of the non-buildable 128.8 km² buffer zone as permanent offset and budget holding capital for the remainder for 18 months. (Measurable: 38.6 km² committed/budgeted). (Time-bound: 2027-05-16 + 18 months).
- Finalize the contractual and technical blue-print (including dedicated fiber path requirements) necessary to deliver sub-2ms latency across the defined multi-site campus architecture required for synchronized AI workloads by the end of Phase 1. (Measurable: Sub-2ms RTT validation report). (Time-bound: 36 months).

## Assumptions 🤔🧠🔍
- The Pragmatic Scale-Up strategy is the chosen path, prioritizing financial de-risking over immediate speed to market.
- The buildable area is constrained to approximately 32.2 km² (20% of the 161 km² target), with the remaining 80% dedicated as buffers requiring long-term holding costs.
- Phase 2 transmission upgrades (post-1 GW) will require a minimum validated construction/commissioning lead time of 36 months from funding commitment (RTE update).
- Anchor tenants will honor the 60% take-or-pay commitment threshold required for Phase 2 expansion FID.
- The French national security apparatus (DGSI/ANSSI) will permit the initial 500 MW commercial load to operate while the dedicated sovereign partition is concurrently designed and reviewed.

## Missing Information 🧩🤷‍♂️🤷‍♀️
- Specific regulatory timelines (in months) RTE requires for grid upgrade feasibility studies and subsequent construction completion following the payment of required collateral for a 3 GW connection.
- Detailed market study justifying the demand profile that can commit 60% of the 2 GW expansion tranche (Phase 2) within the 3-year timeframe.
- Precise cost modeling for the 128.8 km² buffer acreage holding costs (e.g., property taxes, maintenance, administration) required for the multi-year commitment.
- Confirmed specific subsea cable landing points (e.g., Dieppe, Calais) to accurately assess the cost and latency trade-offs for Decision 5.
- The formal requirements from DGSI/ANSSI regarding the definition of 'non-classified' vs. 'sovereign' hardware separation, which directly impacts Phase 1 operational flexibility.

## Questions 🙋❓💬📌
- Given the reliance on the 'hyper-dense' model, how would the project's financial case change if judicial review forces the buildable area down from 32 km² to 20 km², effectively capping the long-term capacity at ~5-6 GW instead of 9 GW?
- If RTE confirms that a 3 GW connection is technically possible but requires the project to fund an additional €2 Billion in regional grid reinforcement *before* Phase 2 FID, does this trigger a reassessment of the overall 9 GW feasibility, or is this considered a necessary cost of the strategic location?
- What specific, non-technical metric (e.g., local employment percentage, guaranteed heat-reuse volume) is considered the single most important lever for securing rapid, positive social license sign-off from the Hauts-de-France Prefect?
- How sensitive is the optimal Phase 1 (1 GW) tenant acquisition strategy to the initial 500 MW being designated as non-sovereign/commercial versus being partially ring-fenced immediately for a high-profile, non-classified French corporate contract?
- If a validated 'Killer Application' (e.g., a major government contract for national language model training) guarantees immediate purchase of 1.5 GW capacity starting in Year 4, should we violate the Pragmatic Scale-Up strategy and immediately fund non-binding RTE studies for 5 GW in Phase 0 to capture that revenue, accepting the associated financial overhang?