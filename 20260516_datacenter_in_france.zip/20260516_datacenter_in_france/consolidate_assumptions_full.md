# Purpose

**Purpose:** business

**Purpose Detailed:** Strategic planning and feasibility assessment for a massive, multi-phase, infrastructure-intensive commercial data center project targeting 9 GW capacity, involving significant capital expenditure, grid coordination, regulatory navigation, and long-term industrial development.

**Topic:** Development of an intentionally extreme hyperscale AI data center campus (9 GW) in Hauts-de-France, France.

# Domain

**Primary domain:** Data Center Infrastructure Planning

**Secondary domains:** Electrical Power Engineering, Large Scale Land Development, French Regulatory Compliance

**Rationale:** Data Center Infrastructure Planning is the primary outcome because this project is fundamentally defined by the scope, scale, and rigorous feasibility planning of the 9 GW campus. While Electrical Power Engineering and French Regulatory Compliance are critical constraints, the overall success criterion rests on the master plan itself. Urban and Regional Planning is the strongest alternative, but it supports the central data center planning effort.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Data Center Infrastructure Planning | 5 | 5 | outcome | The entire project is defined by the planning and execution of a hyperscale data center. |
| French Regulatory Compliance | 5 | 5 | constraint | Navigating French permitting, environmental law, and security reviews is a critical blocker. |
| Energy Grid Management | 5 | 5 | constraint | The 9 GW power requirement critically depends on French grid feasibility and coordination. |
| Electrical Power Engineering | 5 | 4 | constraint | Sourcing and integrating 9 GW of power from the French grid is a critical feasibility bottleneck. |
| Large Scale Land Development | 4 | 4 | method | Assembling and modeling the use of 161 km² across multiple zones is a core planning component. |
| Telecommunications Infrastructure | 4 | 4 | method | Diverse, low-latency fiber connectivity across Europe is essential for AI compute function. |
| Urban and Regional Planning | 4 | 4 | outcome | The massive land parcel assembly and zoned land-use model requires significant planning expertise. |
| Real Estate Acquisition | 4 | 4 | method | Assembling 161 km² of land requires specialized land acquisition and assembly methods. |
| Environmental Impact Assessment | 4 | 4 | constraint | Water, biodiversity, and brownfield remediation are key feasibility and permitting constraints. |

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** The plan is an extremely detailed, multi-year strategy focused on the physical execution of building a massive data center campus spanning 161 km² in Hauts-de-France, France. This involves massive physical construction, land acquisition/assembly (161 km²), coordinating multi-gigawatt electrical infrastructure (9 GW), managing physical cooling systems (liquid cooling loops), establishing physical fiber routes, dealing with brownfield remediation, and navigating physical permitting processes localized to specific parcels of land. Even though the *output* relates to software/AI compute, the *plan* is overwhelmingly dedicated to overcoming rigorous physical, engineering, logistical, and regulatory hurdles required to place that compute in the real world. Therefore, it is classified as physical.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Footprint must accommodate 161 km² (though rationalized to ~30 km² buildable area)
- Access to 9 GW of contracted, reliable, low-carbon/nuclear-backed power post-Phase 2
- Proximity to existing industrial revitalization zones (Cambrai, Dunkirk, Valenciennes)
- Favorable cooling climate (low risk for high-water cooling)
- Strategic latency to Paris, London, Brussels, and Frankfurt via diverse fiber routes
- Access to suitable brownfield or industrial land suitable for remediation and large-scale development

## Location 1
France

Hauts-de-France Region: Cluster 1 (E-Valley/Cambrai)

Industrial land near Cambrai or Valenciennes focusing on brownfield redevelopment (E-Valley zone).

**Rationale**: This primary zone targets the established industrial redevelopment narrative. It offers high initial velocity for land assembly if a fragmented/hyper-dense model is adopted, focusing on early phases (1 GW) supported by existing logistics infrastructure.

## Location 2
France

Hauts-de-France Region: Cluster 2 (Dunkirk Port Area)

Industrial or reclaimed land near the Port of Dunkirk.

**Rationale**: Crucial for accessing heavy logistics, potential maritime fiber routes (Dieppe/Calais alternative), and potentially better access to heavy industrial heat-reuse partners or diverse power supply interconnection points (e.g., through ports logistics nodes).

## Location 3
France

Hauts-de-France Region: Buffer/Expansion Reserve Zones

Large-scale agricultural or ecological buffer land parcels identified immediately adjacent to Clusters 1 and 2.

**Rationale**: Supports the chosen 'hyper-dense development model' where 80% of the notional 161 km² is preserved as non-buildable buffer, ecological zones, and land expansion reserve. This mitigates local opposition to urban sprawl and water/stormwater impact while maintaining the legal option to expand up to 9 GW capacity over the 15-year timeline.

## Location Summary
The plan explicitly targets Hauts-de-France, France, focusing on industrial zones near Cambrai, Valenciennes, and Dunkirk. Three locations are specified to align with the Skeptical Path (Pragmatic Scale-Up): identifying two primary industrial clusters for dense buildout and a third adjacent area for land assembly dedicated to the mandated ecological and community buffers (80% of the notional 161 km² footprint).

# Currency Strategy

This plan involves money.

## Currencies

- **EUR:** The primary currency of the project location (France) for land acquisition, labor, local taxes, and grid connection costs.
- **USD:** Hardware procurement (GPUs/TPUs, networking gear) and potential international financing will expose the project to USD fluctuations.

**Primary currency:** EUR

**Currency strategy:** EUR will be the primary currency for budgeting, operational accounting, and reporting, as local costs (land, labor, grid) are EUR-denominated. Significant USD exposure due to hardware procurement must be tracked separately, and a formal FX hedging strategy (e.g., forward contracts) must be implemented for all major anticipated USD hardware purchases starting in Phase 1 to stabilize the budget against exchange rate volatility.

# Identify Risks


## Risk 1 - Regulatory & Permitting
Failure to secure necessary land assembly consents and operational permits for the hyper-dense, but geographically fragmented, development spanning multiple industrial zones in Hauts-de-France. Legal challenges from agricultural/environmental groups against the large-scale buffer zone designation (Decision 2 - Choice 2) could freeze construction.

**Impact:** A delay of 12–24 months in achieving Phase 1 Final Investment Decision (FID), translating to an estimated €500M–€1B overrun in financing and carrying costs for Phase 0/1, or forced reduction of the desired buildable area from 30 km² to below 15 km².

**Likelihood:** High

**Severity:** High

**Action:** Immediately initiate proactive engagement with regional environmental authorities (DREAL) and prefectural offices (DDETSPP) to secure 'Projet d'Intérêt Général' (PIG) status for the critical infrastructure components (substations, main fiber conduits) that span multiple municipalities, treating the agreed-upon buffer zones as non-negotiable early concessions.

## Risk 2 - Technical
Inability to meet the aggressive PUE target of 1.15–1.25 across 1 GW+ capacity using default direct-to-chip liquid cooling at scale, given the novelty of deploying this technology for the entire first tranche in a non-optimized, brownfield environment.

**Impact:** Exceeding the target PUE by 0.1 (moving to 1.25–1.35 average) could increase annual operational energy costs by an estimated €5M–€10M at 1 GW capacity, and critically, may violate contractual PUE performance clauses tied to initial anchor tenants (Decision 4).

**Likelihood:** Medium

**Severity:** Medium

**Action:** Pilot the liquid cooling infrastructure validation extensively during the design phase using digital twins and hardware simulation. De-risk Phase 1 by ensuring anchor tenants accept a performance-based escalator clause tied to energy costs if PUE targets are missed by more than 0.05 due to unforeseen pump/fluid dynamics integration challenges.

## Risk 3 - Financial
Sunk capital expenditure if RTE/EDF cannot confirm the necessary grid upgrades for Phase 2 (3 GW) capacity commitment before Phase 1 (1 GW) construction financing is finalized, as per Decision 1 (Choice 2 - Pragmatic Scale-Up).

**Impact:** The inability to secure binding transmission allocation by the Phase 1 FID decision gate could force a halt, potentially stranding €1B–€2B of already spent Phase 0/1 capital (land assembly, initial build out) if anchor tenants withdraw pending power certainty.

**Likelihood:** High

**Severity:** High

**Action:** Strictly adhere to the Pragmatic Scale-Up strategy: do not proceed with Phase 2 expansion funding (beyond studies) until RTE provides a formal, legally binding contract for the required backbone transmission capacity upgrades for the next expansion tranche.

## Risk 4 - Supply Chain
Significant exposure to USD/EUR exchange rate volatility affecting the procurement of high-density GPU/TPU hardware and networking gear, despite currency hedging strategy (Currency Strategy).

**Impact:** If the EUR depreciates by >10% relative to the USD between procurement contracts and final hardware payment dates, the total hardware cost for the 9 GW buildout could inflate by an unhedged €8B–€15B on the total projected €100B-€140B budget.

**Likelihood:** Medium

**Severity:** High

**Action:** Implement multi-year forward hedging contracts for 70% of projected USD hardware needs (Phase 1 and 2). Critically, Phase 1 tenants must be asked to contract in EUR-equivalent terms, passing the risk of minor remaining FX deviation back to the consumer.

## Risk 5 - Operational / Security
Failure to secure DGSI/ANSSI protocols and sign off on the sovereign AI partition (Decision 3) prior to leasing 500 MW of physical space, leading to high-security buildout inefficiency or denial of crucial state contracts.

**Impact:** If the sovereign partition cannot be certified, the project loses access to the premium (and assumed stable) domestic revenue stream, jeopardizing the 60% required commitment threshold for Phase 2 expansion (Decision 4), potentially leading to €10B–€20B in lost long-term contracted revenue.

**Likelihood:** Medium

**Severity:** High

**Action:** Isolate the initial 500 MW cluster entirely from the planned sovereign zone footprint. Proactively engage DGSI in Phase 0/1 with detailed security design schematics for the *future* partition, ensuring Layer 1 physical segregation is integrated into initial substation planning, even if operational certification is deferred.

## Risk 6 - Environmental / Water
Unforeseen hydrological or environmental constraints in Hauts-de-France (a region with known water stress, despite better climate than the South) making the 'ultra-low-water' liquid cooling strategy technically non-viable or prohibitively expensive via high-volume water recycling infrastructure.

**Impact:** If the site requires evaporative cooling for peak load management, operational water consumption could trigger regional water restrictions, potentially leading to mandatory operational curtailment during summer months, resulting in €1M–€5M in immediate revenue penalties per week of restriction.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Mandate the use of zero-water density heat rejection (e.g., dry coolers or advanced heat pumps) for 100% of the Phase 1 build, accepting a temporary PUE degradation (e.g., 1.20 max) until long-term water sustainability can be proven via pilot, thereby front-loading the PUE constraint over the water constraint.

## Risk 7 - Social / Policy
Public opposition or judicial appeal stalls development based on the 'hyper-dense development model' which sacrifices 80% of the 161 km² for buffers, leading to accusations of hoarding land without immediate community benefit or causing loss of agricultural land (Decision 2, Choice 2 & Decision 10).

**Impact:** Local pushback could result in the Prefecture reducing the allowed buildable area to less than 20 km², fatally constraining the 9 GW target to a maximum of 3–4 GW, requiring a complete re-evaluation of the 15-year business case.

**Likelihood:** High

**Severity:** High

**Action:** Aggressively implement Decision 8 (Workforce Uplift) and Decision 6 (Heat Reuse) in Phase 0. Use the designated buffer land not just for biodiversity, but for demonstrably tangible community benefits (e.g., a pre-certified solar farm supplying local housing) to convert potential opposition into localized stakeholder cooperation.

## Risk 8 - Technical / Integration
Latency incompatibility between the chosen terrestrial fiber routes (Decision 5) and the needs of synchronized AI model training workloads, which require sub-millisecond consistency across the Paris/London/Brussels network.

**Impact:** If the latency exceeds mandated tenant SLAs (e.g., over 1.5ms terrestrial round trip to Paris), tenants may claim breach of contract, potentially leading to contract renegotiation or vacancy if the necessary dark fiber/subsea investment cannot be secured until Phase 3.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Immediately task a specialist engineering team to conduct independent, real-time latency benchmarking across multiple incumbent carriers. If results confirm performance marginally below requirements, commit Phase 1 CAPEX to securing dark fiber rights-of-way for the identified geographically diverse Phase 2 fiber path, accepting the conflict with Power Procurement Sequencing.

## Risk 9 - Financial / Budgeting
Underestimation of Brownfield Remediation Costs within the identified industrial zones (Cambrai/Dunkirk). Contamination levels may exceed expectations, particularly given the site's industrial history (former steel, refinery, military zones).

**Impact:** Phase 0 remediation costs, initially budgeted at €250M–€750M, could easily double or triple (€500M–€2.25B cumulative spend) if unforeseen hazardous materials require advanced soil stabilization or off-site disposal, delaying the physical start of data hall construction.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Require 80% of Phase 0 budget allocation to be dedicated to comprehensive, deep-bore environmental testing and risk modeling on the targeted buildable parcels, securing fixed-price remediation contracts with established regional specialists *before* land assembly finalization.

## Risk summary
The project faces an extremely high-risk profile dominated by regulatory uncertainty and interdependent critical path items. The 'Pragmatic Scale-Up' strategy adopted mitigates immediate financial exposure (by deferring grid commitment and enforcing high tenant thresholds) but heightens the risk of political/social blockage due to the extreme land rationalization (80% buffers vs. 20% buildable area). **The three most critical risks are:** 1. **Regulatory Delays in Land Assembly/Permitting (High/High):** Local judicial review of the fragmented, hyper-dense land model could halt all progress. 2. **RTE/Grid Confirmation (High/High):** The decision to delay transmission investment until Phase 2 FID risks stranding Phase 1 capital if grid capacity is denied or delayed significantly beyond the expected 3-7 year lead time. 3. **Social License Erosion (High/High):** Failure to convert community opposition via proactive workforce development and heat-reuse monetization will lead to outright political rejection or mandated footprint reduction, undermining the 9 GW ambition.

Mitigation strategies are heavily overlapping: successful social license programs (Workforce/Heat Reuse) directly support faster regulatory permitting, reducing the likelihood of the first critical risk. However, the core trade-off remains between speed (required by the AI market) and financial prudence (required by the skeptical red-team mandate).

# Make Assumptions


## Question 1 - What is the quantified breakdown of the 161 km² footprint allocation, specifying the target buildable area (data center/substations) versus the essential buffer/community/ecological zones for the hyper-dense model?

**Assumptions:** Assumption: Based on the 'hyper-dense development model' (20% buildable), the target physical buildable area for data halls, substations, and critical infrastructure is approximately 32.2 km² (20% of 161 km²), with the remaining 128.8 km² allocated to non-buildable buffers and expansion reserve as identified in the land use strategy.

**Assessments:** Title: Land Use Feasibility Assessment
Description: Evaluation of the physical practicality of assembling and zoning the designated hyper-dense-plus-buffer footprint.
Details: Allocating 80% to buffers severely mitigates local opposition (Risk 7) but reduces the ultimate capacity threshold achievable within the initial 15 years. Benefit: Streamlines permitting velocity for the 20% core footprint. Risk: If anchor tenants demand contiguous, expansive deployment, this model fails, requiring a split-campus review. Opportunity: The 128.8 km² buffer provides significant long-term flexibility for heat exchange/water management infrastructure expansion without requiring new land acquisition.

## Question 2 - Given the 'Pragmatic Scale-Up' strategy, what is the explicit, legally defined milestone (outside of EDF/RTE internal timelines) that will serve as the binding **Go/No-Go** trigger for funding Phase 2 transmission upgrades (Grid Integration Decision 1)?

**Assumptions:** Assumption: The binding trigger for committing capital to Phase 2 (3 GW) transmission upgrades will be the execution of signed, take-or-pay, non-cancellable Power Purchase Agreements covering 60% of the 2 GW expansion tranche, independent of RTE's internal construction schedule.

**Assessments:** Title: Grid Investment Control Assessment
Description: Analysis of the financial linkage between tenant revenue commitment and major capital expenditure on external grid infrastructure.
Details: This links the financial decision gate (Tenant Trigger Threshold) directly to the physical grid commitment, adhering to the skeptical mandate. Risk: If RTE requires definitive capital commitment for grid prep *before* the 60% tenant threshold is met, the project faces stranded capital risk (Risk 3). Benefit: Ensures infrastructure investment scales directly with bankable revenue signals.

## Question 3 - What specific EUR-denominated public benefit commitment or infrastructure investment (e.g., workforce training funding, heat exchange partnership capital) will be contractually locked in during Phase 0 to immediately satisfy community concerns regarding land use and workforce displacement (Decision 10)?

**Assumptions:** Assumption: Phase 0 budget (€250M–€750M) will allocate a mandatory minimum of 5% (€12.5M–€37.5M) towards initial operational funding for the regional skills academy (Decision 8) and feasibility studies for the identified heat-reuse industrial partner near Dunkirk (Decision 6).

**Assessments:** Title: Social License Stabilization Assessment
Description: Evaluation of immediate investment required to secure the political/social operating environment for the 15-year plan.
Details: Front-loading small, visible, tangible benefits (jobs/heat study) mitigates high-likelihood social risks (Risk 7). Benefit: Turns local opposition into negotiated cooperation, accelerating permitting velocity through prefectural support. Risk: If the commitments are non-binding, they lose efficacy rapidly; mandatory allocation within Phase 0 ensures seriousness.

## Question 4 - What is the projected maximum operational PUE (including BESS and ancillary power losses) expected for the Phase 1 build, considering the mandated default liquid cooling system and the rejection of high-water-use cooling methods (Risk 6 mitigation)?

**Assumptions:** Assumption: Full utilization of direct-to-chip liquid cooling, optimized for the 1.15 target, coupled with BESS charging/discharging efficiency losses (estimated at 2% overhead), results in a conservative Phase 1 operational PUE target of 1.20, even if the 1.15 goal is missed initially.

**Assessments:** Title: Efficiency and Operational Cost Performance
Description: Verification of the expected energy efficiency based on technology choices and risk mitigation strategies.
Details: A 1.20 PUE is achievable but requires precise integration of liquid cooling manifolds without significant parasitic losses from pumps or HVAC for non-IT load. Risk: If PUE exceeds 1.25 (Risk 2), long-term operational costs increase by ~€5M/GW/year, impacting contract profitability. Opportunity: Maintaining near-target PUE justifies the higher liquid-cooling CAPEX compared to alternatives.

## Question 5 - What is the projected EUR cost variance for the full 9 GW buildout (€100B–€140B+) if the EUR/USD exchange rate shifts unfavorable by 10% relative to the Phase 0 baseline, assuming only 70% of anticipated USD hardware expenditure is hedged?

**Assumptions:** Assumption: Based on a €120B total budget (midpoint) and assuming 30% of total CAPEX is USD-denominated hardware subject to FX changes, a 10% unfavorable shift translates to an additional gross cost impact of approximately €4.32 Billion (0.30 * 120B * 0.10).

**Assessments:** Title: Financial Exposure and Hedging Efficacy
Description: Quantifying the remaining FX risk after applying the mandated 70% hedge strategy.
Details: The residual €4.3B exposure highlights that the 70% hedge is insufficient to fully de-risk the project's largest variable cost category (hardware). Benefit: This projection mandates immediate execution of the forward contract strategy immediately upon locking in Phase 1 pricing. Risk: Unhedged exposure of this magnitude necessitates a dedicated budget contingency line item to absorb potential volatility impacting debt servicing covenants.

## Question 6 - Since the split-campus model (Decision 2) is favored over contiguous assembly, what is the minimum acceptable latency deviation between the two primary industrial clusters (Cluster 1: Cambrai/E-Valley and Cluster 2: Dunkirk) to ensure functional synchronization for synchronized AI workloads?

**Assumptions:** Assumption: Due to the 50–70 km separation between the primary clusters, the required inter-site latency must be maintained below 2ms round-trip time (RTT) for synchronized AI operations, necessitating dedicated, privately leased, high-grade terrestrial fiber paths between the two locations.

**Assessments:** Title: Inter-Campus Synchronization Viability
Description: Assessment of the technical feasibility of maintaining critical synchronization latency across the decentralized physical model.
Details: If the required 2ms RTT cannot be met via direct terrestrial connection between Cluster 1 and 2, the split-campus model becomes functionally unviable for demanding AI workloads, forcing a centralization that conflicts with the land assembly strategy. Opportunity: If met, this enables decoupling of regulatory/power risks between the two sites.

## Question 7 - Where specifically will the initial 500 MW Phase 1 construction focus its hardware procurement (GPUs/TPUs) to satisfy the 'non-classified commercial tenants' requirement, and how will DGSI assurance be provided that this initial cluster is physically isolated from any future sovereign zones?

**Assumptions:** Assumption: Phase 1 hardware will utilize commercial-grade, non-restricted AI accelerators (e.g., current generation enterprise models), which will be housed in physically separate buildings whose associated primary substation capacity (substation 1) is legally ring-fenced from the planned sovereign zone substations (substation 2) designated for Phase 3/4.

**Assessments:** Title: Security Isolation and Initial Revenue Path
Description: Evaluation of the initial execution plan for satisfying both immediate revenue needs and long-term sovereign compliance (Risk 5).
Details: Physical isolation (separate substations/halls) acts as the practical pre-certification mitigation for the sovereign zone delay. Benefit: Allows for immediate revenue generation while DGSI reviews finalized sovereign partition designs. Risk: The definition of 'non-classified' must be formally agreed upon in Phase 0 to avoid later requirement creep that forces retrofitting these initial halls.

## Question 8 - Considering the 'Pragmatic Scale-Up' strategy defers transmission upgrades until Phase 2, what specific, temporary land-use mechanism (e.g., easement, lease structure) will be immediately secured in Phase 0 for the future interconnection points required for the 3 GW expansion?

**Assumptions:** Assumption: Phase 0 land acquisition will immediately secure preliminary right-of-way (ROW) easements for the exact locations of the Phase 2 required expansion substations and the transmission tie-lines (including the required buffer land adjacent to rights-of-way), even if final financing for the physical build is deferred.

**Assessments:** Title: Long-Lead Physical Infrastructure Control
Description: Assessing control over physical real estate necessary for future grid integration, independent of power commitment funding.
Details: Securing ROW easements is a long-lead permitting activity that must be decoupled from the grid financing trigger. Failure to secure ROW in Phase 0 transforms the grid uncertainty (Risk 3) into a physical land assembly blocker that cannot be solved later. Benefit: This buffers the physical implementation schedule against the utility's internal political timeline for granting transmission access.

# Distill Assumptions

- Buildable area targets 32.2 km² (20% of 161 km²), with 80% reserved for buffers.
- Phase 2 transmission funding triggers upon 60% take-or-pay contracts for the 2 GW tranche.
- Phase 0 allocates 5% of initial budget for local skills academy and heat-reuse feasibility studies.
- Conservative Phase 1 operational PUE target is set at 1.20, utilizing mandatory direct-to-chip liquid cooling.
- A 10% unfavorable EUR/USD shift creates approximately €4.32 Billion unhedged cost exposure on hardware.
- Inter-cluster latency for split campuses must remain below 2ms RTT for synchronized AI workloads.
- Phase 1 commercial hardware must be physically isolated via separate substation capacity from future sovereign zones.
- Phase 0 must immediately secure preliminary right-of-way easements for Phase 2 transmission upgrades.

# Review Assumptions

## Domain of the expert reviewer
High-Scale Infrastructure Project Planning and Feasibility Assessment

## Domain-specific considerations

- Grid Interconnection Lead Times (RTE/EDF)
- French Regulatory/Sovereignty Alignment (DGSI/ANSSI)
- Large-Scale Land Assembly and Zoning Complexity (161 km²)
- Capital Allocation Sequencing vs. Revenue Triggering
- Workforce Development for Specialized Infrastructure

## Issue 1 - Critical Missing Assumption: Regulatory Time Buffer (RTE/Permitting)
The plan heavily relies on the 'Pragmatic Scale-Up' strategy, deferring transmission funding until 60% tenant commitment for Phase 2 (3 GW). However, there is *no explicit assumption* about the actual time required by RTE (Réseau de Transport d'Électricité) to *approve and complete* mandated transmission upgrades *after* funding commitment. French grid extension lead times are notoriously long, often exceeding 3-5 years for multi-GW projects. This creates a dangerous dependency gap: tenants commit based on power availability, but infrastructure completion time is outside developer control.

**Recommendation:** Introduce a critical missing assumption based on conservative external benchmarks: Assume a minimum 36-month completion time for RTE-mandated substation and tie-line upgrades following Phase 2 FID (i.e., the 60% tenant trigger). Adjust the Tenant Acquisition Trigger Threshold (Decision 4) to include a 'Power Readiness Lockout Clause': Phase 2 Commercial Operation Date (COD) is defined as Min(Tenant Anchor COD + 12 months, RTE Upgrade Completion Date).

**Sensitivity:** The baseline assumption is an implicit 18-month grid lead time post-funding. If the actual lead time is 36 months (50% longer), the delay in realizing 3 GW revenue pushes the project's overall timeline by 1.5 years. This delay equates to a loss of projected ROI by 8-12% over the first four years due to deferred revenue scaling, potentially increasing the total project cost of capital by €500M–€800M.

## Issue 2 - Under-Explored Assumption: Financial Viability of 80% Land Buffer
The chosen 'hyper-dense' model reserves 80% (128.8 km²) of the target 161 km² for buffers and reserves, with only 20% (32.2 km²) buildable. The assumption is that this preserves optionality and smooths permitting. However, the financial viability hinges on whether the cost of acquiring and holding this massive land reserve (even if less contested) is covered by the operating budget or must be capitalized. Furthermore, the ability to *legally* hold 80% of land designated for future industrial expansion as 'permanent ecological preservation' or 'buffer' under French planning law for 15 years without strong, binding ongoing community benefit contracts (Decision 6) is highly questionable and risks regulatory reversal.

**Recommendation:** Explicitly assume a holding cost budget for the 128.8 km² buffer zone, estimated at €50,000–€75,000 per hectare annually for maintenance, insurance, and ongoing legal defense buffers. Crucially, decouple the 'permanent' nature of 80% from the strategic plan: Reclassify 50% of the buffer as 'Phase 2/3 Expansion Reserve' requiring only annual agricultural lease renewal, and the remaining 30% as 'Permanent Ecological Offset' requiring upfront, binding, funded commitments to local environmental bodies (Decision 10).

**Sensitivity:** If the annual holding cost for the 12,880 hectares is underestimated by €20,000/hectare (total €257.6M annually for 5 years pre-scaling), the initial Phase 0/1 CAPEX will overrun by €1.3B. If local authorities mandate converting 30% of the buildable area (10 km²) back into buffer due to social disputes, the maximum potential capacity is permanently reduced from 9 GW to ~6 GW, decreasing baseline potential ROI by 30-40%.

## Issue 3 - Unrealistic Assumption: Workforce Skill Uplift Velocity
Decision 8 mandates aggressive local workforce sourcing (75% apprenticeships) to secure social license. While necessary, assuming this can be achieved without causing Phase 1 construction delays is highly optimistic. Specialized construction for liquid-cooled DCs, combined with the requirement for DGSI physical isolation verification (Risk 5), demands specialized skills that regional vocational schools (Decision 3/8) cannot generate instantly. The assumption appears to underestimate the management overhead and quality control risks associated with a massive, unproven upskilling program.

**Recommendation:** Introduce a staffing latency factor to the timeline: Assume only 30% of specialty construction hours can be filled by qualified local hires in Year 1, rising to 50% by Year 2, forcing reliance on higher-cost international contractors for the initial 12-18 months. Integrate a contingency budget line item of €20M–€40M specifically for importing specialized management teams to *oversee and train* the local workforce, mitigating quality risk without halting site mobilization.

**Sensitivity:** If specialized labor is unavailable, the construction timeline for Phase 1 (1 GW) could realistically extend from a baseline of 24 months to 30-36 months. This 6-12 month delay, combined with associated project management costs (€50M–€100M), would reduce the project's Net Present Value (NPV) by 4-6% based on foregone early revenues.

## Review conclusion
The project plan is strategically sound in identifying interdependent risks (Power, Land, Social License) and appropriately selects a skeptical, phased approach ('Pragmatic Scale-Up'). However, the execution timeline is overly optimistic, specifically regarding external dependencies. The review identified three critical weaknesses by quantifying missing assumptions:

1. **Missing Grid Completion Buffer:** The plan lacks a realistic timeline for RTE execution post-funding commitment, posing a 1.5-year revenue delay risk.
2. **Uncosted Land Holding:** The massive 80% buffer zone is assumed manageable but lacks a dedicated holding cost budget, risking a €1.3B overrun in early CAPEX.
3. **Workforce Optimism:** The reliance on rapid local upskilling to maintain the aggressive construction schedule introduces a high likelihood of 6-12 month technical delays in Year 1, impacting early ROI.

Immediate action must focus on locking in regulatory timing buffers, fully budgeting for the massive land reserve, and accepting higher initial construction costs/delays to ensure genuine local workforce integration.