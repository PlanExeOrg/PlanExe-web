## 1. RTE Grid Upgrade Timeline & Collateral Requirement

This data directly validates the critical path dependency identified in Risk 3 and Review Issue 1. Deferring Phase 2 funding until 60% tenant commitment (Pragmatic Scale-Up) is infeasible if RTE requires an excessively long lead time (>36 months) for infrastructure completion, risking stranded capacity.

### Data to Collect

- Exact timeline (months) for RTE transmission upgrade completion following financial commitment for 3 GW capacity.
- Required financial collateral amount (EUR) demanded by RTE for Phase 2 (3 GW) grid interconnection initiation.
- Binding PPA template structure for capacity allocation post-Phase 1 FID.

### Simulation Steps

- Use PowerFactory/PSSE to model the 9 GW load injection profile onto the RTE network segments impacting Hauts-de-France.
- Develop a spreadsheet model applying the known French cost-per-MW metrics for substation upgrades (based on Suggestion 3 findings) to estimate collateral requirements as a function of required lead time.

### Expert Validation Steps

- Consult the European Energy Regulation Specialist (RTE/PPA expert) to calibrate the required collateral quantum and the minimum mandated timeline for RTE infrastructure completion post-funding.
- Request timeline confirmation data from the Land Use and Environmental Lawyer's network regarding average political/legal buffer applied to DREAL-approved grid infrastructure projects.

### Responsible Parties

- Grid & Power Procurement Specialist (IC)
- Chief Infrastructure Strategist & Project Architect (FTE)

### Assumptions

- **High:** RTE requires a minimum of 36 months for network upgrade completion after Phase 2 funding commitment is secured.
- **Medium:** The initial pre-paid hosting fee for Phase 1 (500MW) will accelerate the RTE planning process without influencing the longer-term 3 GW readiness timeline.

### SMART Validation Objective

Obtain formally documented range estimates (in months) for RTE transmission upgrade completion for 3 GW post-FID from the European Energy Regulation Specialist by 2026-11-01.

### Notes

- Focus on locking down the Phase 2 FID dependency rigorously against the validated power readiness timeline.


## 2. Land Holding Cost & Legal Structuring for Buffer Zones

Review Issue 2 highlighted that the holding cost for the 80% buffer is unbudgeted, posing a critical CAPEX risk (€1.3B+ overrun). This data is essential to integrate this strategic concession into the Phase 1 budget.

### Data to Collect

- Annual holding cost per hectare (EUR/ha/year) for non-buildable industrial/agricultural land in the Dunkirk/Cambrai zones (for 128.8 km²).
- Legal documentation requirements (e.g., specific deeds/clauses) for establishing a 30% 'Permanent Ecological Offset' under French law.
- Standard lease/easement costs for the 50% 'Expansion Reserve' area for an initial 18-month commitment period.

### Simulation Steps

- Use GIS/CAD software (managed by Land Modeler) to calculate the specific acreage breakdown for 32.2 km² buildable, 38.6 km² permanent offset, and 90.2 km² 18-month reserve.
- Model the cumulative 18-month holding cost based on interpolated local tax rates and maintenance estimates for 128.8 km².

### Expert Validation Steps

- Consult the French Land Use and Environmental Lawyer to validate the proposed legal structure for the 30% permanent offset and the viability/cost of the 18-month renewal option for the reserve area.
- Engage the Socio-Economic Impact Assessor to benchmark the proposed buffer holding costs against regional development incentive frameworks.

### Responsible Parties

- Large-Scale Land & Civil Works Model Modeler (IC)
- Financial Controller & Currency Risk Manager (FTE)

### Assumptions

- **High:** The modeled average holding cost per hectare is accurate within a 10% margin of the actual cadastral charges levied by local communes.
- **High:** A 30% permanent ecological offset is legally sufficient to preempt most land-use judicial challenges against the hyper-dense model.

### SMART Validation Objective

Formalize a binding 18-month operating budget line item for the 128.8 km² land holding costs, validated by the Land Use Lawyer, by 2026-09-01.

### Notes

- This directly addresses the critical financial risk associated with the hyper-dense land strategy.


## 3. DGSI/ANSSI Security Isolation Protocol Definition

Risk 5 highlights that failure to secure early security alignment jeopardizes access to premium sovereign revenues. Data collection must define the explicit boundary conditions for the initial commercial leasing (Decision 3, Choice 1).

### Data to Collect

- Formal document outlining DGSI/ANSSI requirements for physical and logical separation between non-classified commercial compute (Phase 1) and the future sovereign AI partition.
- Timeline (in months) for DGSI review of initial Proof-of-Concept security architecture for the 500 MW isolation.
- Definition of 'non-classified hardware' acceptable for immediate Phase 1 deployment.

### Simulation Steps

- N/A - This is primary regulatory documentation retrieval.
- Map the logical flow of substation capacity (Substation 1 isolation) against the DGSI security demarcation points within the BIM/Digital Twin model (managed by Chief Architect).

### Expert Validation Steps

- Consult the EU Sovereign AI & Cyber Security Policy Advisor to interpret the DGSI documentation and review the project's proposed physical isolation schematics for acceptance.
- Regulatory & Sovereignty Compliance Lead to arrange a formal Phase 0 architecture review meeting with DGSI.

### Responsible Parties

- Regulatory & Sovereignty Compliance Lead (FTE)
- Chief Infrastructure Strategist & Project Architect (FTE)

### Assumptions

- **Medium:** The DGSI/ANSSI review process for the initial 500 MW isolation concept can be completed within 10 months, concurrent with Phase 1 construction.
- **Medium:** The initial 500 MW hardware procurement (Risk 7) can be sourced without requiring specialized, nationally approved accelerators, allowing immediate revenue capture.

### SMART Validation Objective

Secure a written DGSI confirmation that the proposed physical segregation plan for Phase 1 (500 MW) meets the minimum standard required to *avoid* retrofitting when the sovereign zone is eventually built, by Q1 2027.

### Notes

- This is a high-stakes compliance gate that must inform tenant leasing terms.


## 4. Phase 1 Workforce Skill Uplift Velocity & Contractor Resistance

Review Issue 3 identified workforce optimism as a source of 6-12 month delays. Validating the realistic speed of skills development and contractor acceptance of the 75% mandate is necessary to accurately forecast Phase 1 completion date (Goal Statement constraint: 3 years).

### Data to Collect

- Average lead time (months) for local technical schools in Hauts-de-France to certify a new apprentice cohort capable of specialized construction work (e.g., piping for liquid cooling).
- Standard contract clauses used by EPC firms in the region regarding local hiring mandates (75% quota) and associated penalty/premium rates for compliance.
- Budgetary cost associated with importing specialized, non-local management/QC teams to oversee local training (Contingency budget input).

### Simulation Steps

- Modeling scheduling impact: Apply the estimated skill generation latency (if >6 months) to the Phase 1 construction schedule to quantify potential delay to 1 GW COD.
- Use cost modeling software to integrate premium/penalty costs from EPC resistance into the overall Phase 1 construction budget.

### Expert Validation Steps

- Consult the Socio-Economic Impact Assessor to confirm realistic velocity for local skills development and job integration.
- Consult the Program Director - Construction & Logistics (to be hired/assigned) to gauge typical EPC resistance levels to such strong local hiring mandates.
- Consult the Social License & Community Benefits Orchestrator regarding negotiated apprenticeship rates.

### Responsible Parties

- Social License & Community Benefits Orchestrator (IC)
- Chief Infrastructure Strategist & Project Architect (FTE)

### Assumptions

- **Medium:** The required 75% local hiring mandate will incur an average 5% premium on civil construction costs due to management overhead or contractor surcharge.
- **High:** Local technical schools can provide sufficient initial supervisors/trainers within 12 months to support the ramp-up.

### SMART Validation Objective

Establish a validated, 12-month phased local hiring roadmap, acceptable to contracted EPC partners (or resulting in finalized premium costs), by Q4 2026.

### Notes

- This data updates the strategic decision on workforce vs. speed trade-off.

## Summary

Immediate prioritization must focus on locking down the external timeline constraints that dictate Phase 1 feasibility and 9 GW optionality. The most critical data collection tasks are validating the RTE upgrade lead time (Data Item 1) and fully budgeting the land holding costs associated with the chosen 80% buffer strategy (Data Item 2), as these represent high-sensitivity, high-impact external dependencies impacting both schedule and CAPEX. Concurrently, the feasibility of large-scale local workforce integration must be quantified to manage schedule risk against social license requirements (Data Item 3). Actions should begin immediately by engaging the designated external experts (RTE/Land Use/Socio-Economic) to secure timeline assurances.