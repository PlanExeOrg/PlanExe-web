# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** Intentionally extreme hyperscale, targeting 9 GW capacity across a massive 161 km² footprint, spanning 10–15+ years with €100B+ expenditure. Aims for regional dominance.

**Risk and Novelty:** Extremely high risk and novelty. The plan demands rigorous feasibility analysis, treating commitments as uncertain ('red-team'). It requires overcoming novel challenges in land aggregation, multi-GW grid coordination in France, and advanced liquid cooling deployment at this scale.

**Complexity and Constraints:** Extremely high complexity. Defined by numerous engineering constraints (PUE 1.15-1.25, liquid cooling), financial constraints (€100B+ budget), strict regulatory hurdles (DGSI/ANSSI), and mandatory skepticism regarding external approvals (RTE, Prefectures).

**Domain and Tone:** Industrial infrastructure development (Data Center/Energy/Real Estate) combined with high-level corporate strategy. The tone is rigorously skeptical, analytical, and condition-heavy, demanding feasibility proof rather than promotional certainty.

**Holistic Profile:** 

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Builder: Pragmatic Scale-Up
**Strategic Logic:** This path prioritizes a measured, phased approach that validates each major commitment before escalating capital. It seeks the optimal balance between speed and de-risking, relying on strong anchor tenants and avoiding the political pitfalls of extreme land demands while managing grid exposure commensurate with secured revenue.

**Fit Score:** 9/10

**Why This Path Was Chosen:** This scenario best fits the requirement to be 'rigorous, skeptical, and allowed to recommend downsizing,' as it heavily validates commitments before scaling, controlling power exposure (non-binding RTE for Phase 1) and rationalizing the footprint (hyper-dense model).

**Key Strategic Decisions:**

- **Grid Integration and Power Source Commitment:** Limit Phase 1 scope to 500 MW backed only by a non-binding RTE hosting consultation response, deferring all transmission upgrade capital expenditure until the 3 GW expansion gate, prioritizing immediate land and building mobilization over power certainty.
- **Land Assembly Modality and Footprint Rationalization:** Institute a hyper-dense development model where 80% of the 161 km² is immediately designated as permanent ecological preservation/water retention/agricultural buffer around five strategically placed, highly secure, and vertically integrated 1 GW nodes, effectively limiting buildable area to 30 km² long-term.
- **National Security and Sovereignty Alignment:** Mandate that the first 500 MW load remains exclusively for non-classified commercial tenants until a formal, signed agreement governing the separation, auditing, and operational protocols for the dedicated sovereign AI partition is executed with relevant national authorities.
- **Tenant Acquisition Trigger Threshold:** Raise the minimum take-or-pay commitment threshold for the 1-3 GW expansion gate to 60% of the next tranche's capacity, sacrificing speed entirely in favor of leveraging committed revenue to secure significantly lower, syndicated debt financing rates.
- **Fiber Connectivity Path Redundancy and Terrestrial vs. Subsea Access:** Mandate diversity only through the primary terrestrial routes to Paris and Brussels, accepting the geographic concentration risk in exchange for achieving best-possible latency metrics necessary for time-sensitive AI model training synchronization.

**The Decisive Factors:**

The 'Pragmatic Scale-Up' scenario is the superior fit because the project plan’s core directive is to conduct a 'red-team planning scenario' that is 'rigorous, skeptical,' and *allowed* to fail or downsize.

*   **Alignment with Skepticism:** This scenario enforces validation gates, using non-binding power commitments for Phase 1 and demanding high revenue thresholds (60% take-or-pay) for Phase 2 expansion, directly recognizing the plan's need to treat external approvals as uncertain until proven.
*   **Risk Management:** It embraces footprint rationalization by adopting a 'hyper-dense development model' for the 161 km² area, addressing complexity without resorting to the politically risky forced consolidation favored by The Pioneer.
*   **Comparative Weakness of Others:** 'The Pioneer' accelerates risk by forcing full land assembly and pre-engineering the sovereign zone, violating the plan's skeptical tone. 'The Consolidator' fails because it dismisses the core ambition by immediately cutting the target to 3 GW, rather than proving feasibility at 9 GW.

---
## Alternative Paths
### The Pioneer: Accelerated Dominance
**Strategic Logic:** This path aggressively pursues the 9 GW vision by front-loading capital and complexity to secure regional primacy and meet potential early market demand spikes. It accepts high financial and regulatory risk by aiming for the fastest possible mobilization across power commitment, land assembly, and security definition.

**Fit Score:** 8/10

**Assessment of this Path:** This scenario directly matches the plan's inherent 'intentionally extreme' nature by front-loading risks, such as forcing land consolidation and immediately defining a sovereign zone, aligning with the $9 GW ambition.

**Key Strategic Decisions:**

- **Grid Integration and Power Source Commitment:** Negotiate a firm, contracted 500MW-1GW connection point for Phase 1 contingent on immediate, pre-paid submission of subsequent grid impact studies required for the full 9 GW capacity, accepting high initial capital exposure to expedite timeline.
- **Land Assembly Modality and Footprint Rationalization:** Force the consolidation of the full 161 km² target by offering a substantial, non-negotiable public benefit or land-value guarantee package to prefectural authorities, streamlining assembly under a single, comprehensive, but politically vulnerable, exceptional planning decree.
- **National Security and Sovereignty Alignment:** Immediately allocate 2 GW of the total capacity as a pre-engineered, physically isolated, and dedicated sovereign compute zone, designed to the highest DGSI standards from Day 1, even if initial tenants are non-sovereign, to secure favorable regulatory status early.
- **Tenant Acquisition Trigger Threshold:** Approve Phase 2 expansion based solely on achieving 100% utilization of the Phase 1 1 GW capacity being guaranteed by a consortium of three medium-sized European cloud providers, accepting lower per-unit revenue for guaranteed base-load tenancy.
- **Fiber Connectivity Path Redundancy and Terrestrial vs. Subsea Access:** Fund the immediate physical construction or long-term leasing of physically separate fiber trenches, simultaneously entering agreements for two different subsea landing points (e.g., Dieppe/Calais and Dieppe/UK), prioritizing resilience over the first year's latency performance.

### The Consolidator: Stability and Cost Control
**Strategic Logic:** This conservative strategy minimizes regulatory exposure and upfront CapEx by immediately scaling back the overall ambition to a demonstrably achievable 3 GW total footprint. It favors proven operational stability over market capture speed, leveraging controlled cost structures to enhance financing credibility.

**Fit Score:** 4/10

**Assessment of this Path:** This scenario is a poor fit because it immediately scales down the core ambition to 3 GW, which contradicts the plan's explicit focus on planning for a 9 GW target and addressing the feasibility of the extreme scale.

**Key Strategic Decisions:**

- **Grid Integration and Power Source Commitment:** Immediately reduce the target power commitment for the entire project to 3 GW total capacity, focusing all grid negotiation efforts on securing a single, proven transmission corridor, thereby de-risking the initial 8-year timeline.
- **Land Assembly Modality and Footprint Rationalization:** Abandon the contiguous 161 km² block and instead secure distinct, non-contiguous land parcels totaling 50 km² across three established, permitted industrial zones (e.g., Cambrai, Dunkirk, Valenciennes) to accelerate Phase 1 readiness and fragment environmental permitting risk.
- **National Security and Sovereignty Alignment:** Execute Phase 1 entirely on a temporary, modular, and externally hardened perimeter, deliberately foregoing initial sovereign classification until the facility demonstrates 24 months of flawless, low-incident operational performance and predictable PUE metrics.
- **Tenant Acquisition Trigger Threshold:** Mandate that only US Dollar-denominated GW-capacity contracts for sovereign AI workloads count toward the Phase 2 expansion trigger, creating a higher barrier to entry but insulating the project's core P&L from short-term EUR/USD volatility.
- **Fiber Connectivity Path Redundancy and Terrestrial vs. Subsea Access:** Outsource all fiber corridor development to a single, established carrier under a 15-year managed service contract, accepting their pre-existing primary routes in exchange for eliminating the immediate financial and administrative burden of land acquisition/easement processing.
