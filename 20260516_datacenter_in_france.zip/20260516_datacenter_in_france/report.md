# Hauts-de-France Buildout

Generated on: 2026-05-16 18:40:05 with PlanExe. [Discord](https://planexe.org/discord.html), [GitHub](https://github.com/PlanExeOrg/PlanExe)

# Executive Summary

## Focus and Context
How will a multi-billion Euro commitment overcome the French infrastructure triad of Power, Land, and Sovereignty? This plan outlines the 'Pragmatic Scale-Up' strategy to build the 9 GW Sovereign AI Engine in Hauts-de-France by systematically de-risking capacity scaling against external regulatory and revenue validation gates.

## Purpose and Goals
The primary goal is successfully completing Phase 1 (1 GW operational within 3 years at PUE <=1.20) while achieving two critical prerequisites for subsequent scaling: securing binding power commitment for the 3 GW expansion from RTE and achieving 60% tenant revenue commitment before Phase 1 construction FID.

## Key Deliverables and Outcomes
Phase 1 build completion (1 GW) within 36 months; Formal DGSI sign-off on Phase 1 security isolation; Budget finalized and funded for 18-month land-holding costs for the 80% buffer zone; Binding RTE commitment secured for post-Phase 1 transmission capacity.

## Timeline and Budget
Phase 1: 3 years (36 months) CAPEX estimated at €5B–€10B. Long-term 9 GW footprint development spans 10–15 years (€100B+ total). Initial Phase 0 budget must include funding for uncosted land holding reserves and workforce academy development.

## Risks and Mitigations
The three critical risks are: 1) Regulatory Delays caused by judicial challenge to the hyper-dense land model (Mitigated by dedicating 30% buffer as permanent ecological offset). 2) RTE/Grid Confirmation Failure contingent on external timeline (Mitigated by strictly linking Phase 2 FID to both tenant revenue *and* binding RTE contract). 3) Failure to Monetize Local Benefit (Mitigated by immediately funding the skills academy and heat reuse feasibility).

## Audience Tailoring
The summary is tailored for senior investors, government partners (DGSI/Prefectures), and key infrastructure executives (RTE/EDF), adopting a rigorous, skeptical, and condition-heavy tone suitable for high-CAPEX, multi-year industrial strategy.

## Action Orientation
Immediate action is required across three vectors: The Grid Specialist must engage RTE to finalize the 36-month infrastructure completion buffer; the Land Modeler/CFO must finalize and budget the €1.3B holding cost for the 80% land reserve by Q3 2026; and the Regulatory Lead must secure written DGSI acknowledgement of Phase 1 isolation feasibility by Q1 2027.

## Overall Takeaway
The 'Pragmatic Scale-Up' provides a controlled, skeptical path to unlock the 9 GW potential by enforcing stringent revenue and regulatory validation gates, transforming critical infrastructure dependencies into manageable, sequenced financial decisions.

## Feedback
Strengthen the summary by explicitly quantifying the financial impact of the deferred RTE timeline (36+ months) on the overall 15-year NPV, and provide a firm budgetary allocation for the residual, unhedged USD hardware exposure to demonstrate comprehensive financial control over currency volatility.

# Pitch

Persuasive elevator pitch.

# Architecting the 9 GW Sovereign AI Engine for France

This document outlines the strategic roadmap for building the **9 GW Sovereign AI Engine for France**, focusing on achieving national digital autonomy through disciplined, phased scaling and aggressive de-risking.

## Project Overview and Core Strategy

We are moving beyond tentative planning to architect a machine of unprecedented scale. The primary focus is tackling the Gordian knot of French infrastructure: **Power, Land, and Sovereignty**.

Our approach utilizes the meticulously planned 'Pragmatic Scale-Up' path across the 15-year roadmap. This strategy involves:

- Building fast where we control the land (**hyper-dense nodes**).
- Locking-in leverage where we do not (committing to expansion only after securing **60% take-or-pay anchors** before committing massive grid CAPEX).

This process systematically de-risks every critical dependency, proving feasibility block-by-block to provide the bedrock for French AI leadership without incurring undue financial risk from bureaucratic uncertainty. This is defined as controlled, strategic aggression.

## Target Audience

This pitch is directed at key decision-makers who prioritize risk mitigation on multi-decade, high-CAPEX projects:

- **Senior Investors**
- **Governmental Partners** (Prefectural Authorities, DGSI/ANSSI liaisons)
- **Key Infrastructure Stakeholders** (RTE/EDF executives)

## Risks and Mitigation Strategies

We directly confront the three identified 'Key Risks' through proactive measures integrated into the design:

- **Regulatory Delays:** Mitigated by proactively zoning 25% of the land as permanent ecological offset (Decision 10) to satisfy local opposition.
- **RTE/Grid Confirmation Failure:** Mitigated by strictly tying expansion CAPEX to both secured tenant revenue (60% threshold) and binding power contracts (Decision 4 & 1).
- **Failure to Monetize Local Benefit:** Mitigated by immediately budgeting for the skills academy and heat reuse feasibility.

Our strategy is built on anticipating and neutralizing these blocking factors through **controlled development**.

## Stakeholder Benefits

The project delivers tangible value tailored to distinct stakeholder groups:

- **Investors:** Gain minimized exposure to uncertain French regulatory timelines by linking scale-up to **proven revenue** (Decision 4).
- **Government Partners:** Secure verifiable national sovereignty via pre-engineered security isolation protocols (Decision 3) and tangible regional economic uplift via the **mandated local workforce investment** (Decision 8).

## Ethical Considerations and Community Integration

Our design prioritizes **long-term community integration** over quick profit, evidenced by key decisions:

- The hyper-dense node strategy preserves 80% of the footprint for ecological and community buffers to minimize sprawl (Decision 2).
- An ironclad mandate exists to train and employ **75% of the local workforce** (Decision 8).

Social license is treated as a foundation, not an afterthought.

## Metrics for Success

Success is measured beyond standard operational efficiency goals (Phase 1 operation at <=1.20 PUE). Critical validation points include:

- Achieving *binding* RTE allocation for the **3 GW Phase 2 requirement** *before* Phase 1 construction financing FID.
- Securing **60% committed take-or-pay revenue** for the next tranche.

These metrics validate the core power and **financial de-risking strategy**.

## Collaboration Opportunities

We actively seek external partnerships to enhance project delivery:

- **Regional technical schools** to co-develop the skills academy required for workforce uplift (Decision 8).
- **National energy partners** to collaborate on the feasibility studies for high-volume, low-margin heat reuse contracts, transforming a liability into a **public benefit asset** (Decision 6).

## Long-term Vision

This 9 GW campus is positioned to be Europe's largest AI facility and the template for **resilient, sovereign European digital infrastructure**. By mastering the integration of massive power demands, navigating complex sovereign security requirements, and demonstrating sustainable land use through hyper-density, we create a repeatable, de-risked blueprint for the next wave of critical energy-intensive technology deployment across the continent.

## Call to Action

We are proceeding immediately to **Phase 0 validation**. We require commitment to:

- Fund the pre-paid RTE grid impact studies.
- Finalize the legal structure for the 75% local workforce mandate.

These commitments must be secured within the next **90 days** to maintain our Q4 2026 Phase 1 Construction FID timeline.

# Project Plan

**Goal Statement:** Successfully complete Phase 1 (500 MW–1 GW buildout) of the Hauts-de-France AI data center campus within 3 years, achieving operational PUE of 1.20, securing 500 MW-1 GW in non-classified commercial capacity, and obtaining legally binding grid commitment for the subsequent 2 GW expansion tranche prior to Phase 1 construction financing FID.

## SMART Criteria

- **Specific:** Successfully build, commission, and operate a functionally and contractually validated 500 MW to 1 GW segment of the hyperscale AI data center campus in Hauts-de-France, focusing on liquid cooling and strict power segregation until national security clearance for sovereign zones is finalized.
- **Measurable:** Phase 1 completion is measured by successful operation at target PUE (<=1.20), verified contractual commitment for 60% of the next 2 GW expansion tranche (Decision 4), and a binding RTE allocation contract for new transmission capacity required for Phase 2.
- **Achievable:** Achievable by adhering to the Pragmatic Scale-Up strategy, which intentionally limits initial power commitment to non-binding consultation for Phase 1, reducing immediate CAPEX exposure, and focusing on hyper-dense construction within a pre-defined 32.2 km² buildable area.
- **Relevant:** This phase validates the core technical and financial assumptions required to pursue the full 9 GW long-term goal, specifically testing grid coordination feasibility, tenant demand thresholds, and social license viability in the chosen region.
- **Time-bound:** 3 Years (End of Phase 1)

## Dependencies

- Completion of Phase 0 Feasibility, Site Control, and Land Assembly Agreements.
- Successful execution of pre-paid RTE grid impact studies for initial 1 GW load (Decision 1, Choice 2).
- Securing preliminary right-of-way easements for Phase 2 transmission upgrades (Assumptions Q8).
- Formal agreement on physical and logical isolation protocols for the future sovereign compute zone (Decision 3).
- Securing initial, binding contracts covering 30-50% of the next 2 GW expansion tranche (Decision 4).

## Resources Required

- Land control documentation for 161 km² area, primarily for 32.2 km² buildable zone and 128.8 km² buffer.
- EUR denominated financing (€5B–€10B) for Phase 1 CAPEX.
- Direct-to-chip liquid cooling components (pumps, piping, heat rejection equipment).
- Hardware Procurement Contracts denominated in EUR or covered by 70% forward hedging (for initial 1 GW compute).
- Specialized environmental remediation contractors for brownfield sites.
- Local workforce development program funding (~€12.5M–€37.5M initial allocation).

## Related Goals

- Finalize 9 GW Power Procurement Strategy (Post-Phase 1)
- Achieve DGSI/ANSSI Sign-off for Sovereign AI Partitioning (Post-Phase 1)
- Establish Full Multi-Route Fiber Network to Core European Hubs (Phase 2)

## Tags

- Hyperscale
- Hauts-de-France
- AI Data Center
- 9GW
- Liquid Cooling
- Grid Feasibility
- Skepticism

## Risk Assessment and Mitigation Strategies


### Key Risks

- Regulatory Delays: Judicial challenges to the fragmented, hyper-dense land assembly plan (80% buffer).
- RTE/Grid Confirmation Failure: Inability to secure binding 3 GW capacity allocation before Phase 1 construction FID.
- Failure to Monetize Local Benefit: Inability to secure binding Heat Reuse contracts or meet workforce quotas, eroding social license.

### Diverse Risks

- Technical: Inability to consistently maintain PUE <=1.20 in brownfield deployment under liquid cooling load.
- Financial: Budget overrun (€1.3B+) due to uncosted holding costs for permanent and reserve buffer land.
- Operational/Security: Failure to physically isolate Phase 1 commercial load from future sovereign zone, jeopardizing premium revenue.

### Mitigation Plans

- For Regulatory Delays: Proactively designate 30% of the buffer as legally binding 'Permanent Ecological Offset' in Phase 0 (Decision 10, Choice 2) to preempt litigation regarding long-term land use.
- For RTE/Grid Confirmation Failure: Adhere strictly to 'No Grid Pre-Commitment' for upgrade capital (Decision 1, Choice 2), making Phase 2 expansion FID contingent on 60% signed tenant capacity (Decision 4) *and* a formal RTE contract for transmission upgrades.
- For Failure to Monetize Local Benefit: Immediately budget and execute the initial skill academy funding commitment (€12.5M minimum) and formalize feasibility studies for heat reuse partners in Phase 0 (Assumptions Q3, Decision 6).
- For Technical PUE Risk: Mandate dry-cooling only for Phase 1 heat rejection, setting operational PUE tolerance ceiling at 1.20 (Assumptions Q4) to manage water scarcity risks.
- For Land Holding Cost: Explicitly budget holding costs for the 128.8 km² buffer for 18 months upfront, ring-fenced from infrastructure CAPEX (Review Issue 2).
- For Operational/Security Isolation: Contractually and physically separate Substation 1 for initial 500 MW load from all future sovereign zone connection points, using dedicated feeders (Pre-Project Q4).

## Stakeholder Analysis


### Primary Stakeholders

- Project Development Team (Plan Execution)
- Anchor Tenants (Post-FID capacity purchasers)
- EPC/Construction Managers (Delivery of 1 GW physical build)

### Secondary Stakeholders

- RTE / EDF (Grid Access and Power Contracts)
- DGSI / ANSSI (National Security Vetting & Sovereignty Alignment)
- DREAL / Prefectural Authorities (Land Zoning, Environmental Permits)
- Local Municipalities (Cambrai, Valenciennes, Dunkirk - Social License/Workforce)

### Engagement Strategies

- Project Team: Weekly progress reviews and formal decision gate submissions for all planning milestones.
- Anchor Tenants: Quarterly confidential updates on power reliability verification and security status, linking Phase 2 expansion FID directly to their commitment thresholds.
- RTE/EDF: Utilize pre-paid studies to force high-priority review slots; provide necessary collateral estimations contingent on binding capacity confirmation.
- Regulatory Authorities (DGSI/ANSSI): Proactive, front-loaded engagement in Phase 0/1 with isolation schematics to accelerate security review timelines for the non-classified initial load.
- Local Municipalities: Implement mandatory 75% local hiring clause (Decision 8) and commence immediate funding for the regional skills academy to secure social license over buffer land usage.

## Regulatory and Compliance Requirements


### Permits and Licenses

- Land Use Zoning Approvals for Fragmented Parcels (DREAL/Local Authorities)
- Environmental Impact Assessment (EIA) Approvals across multiple zones
- Water Usage Permits (Given ultra-low/zero-water cooling preference)
- Electrical Connection Permit for 1 GW capacity (RTE/Enedis)

### Compliance Standards

- French National Security Requirements (DGSI/ANSSI) for Data Center Classification
- EU GDPR and Data Sovereignty Requirements
- PUE and Efficiency Standards (Related to PPA terms)
- Brownfield Remediation Standards (ICPE classifications if applicable)

### Regulatory Bodies

- Direction régionale de l'environnement, de l'aménagement et du logement (DREAL)
- Direction Départementale des Territoires et de la Mer (DDETSPP)
- Réseau de Transport d'Électricité (RTE)
- Direction Générale de la Sécurité Intérieure (DGSI)

### Compliance Actions

- Submit formal request for expedited review of the hyper-dense land use model under the local planning authority (Phase 0).
- Schedule DGSI checkpoint meeting (Q4 2026) to review physical segregation plans between commercial and sovereign clusters.
- Implement compliance plan for brownfield remediation based on Phase 0 environmental baseline testing.
- Execute initial PPA template negotiations requiring EDF/EDF-backed green energy sources for the 1 GW commitment.

# Strategic Decisions

## Primary Decisions
The vital few decisions that have the most impact.


The vital few (Critical levers) focus on establishing the physical and financial foundation: Power Capacity (Grid Integration, Power Procurement Sequencing) and Revenue Certainty (Tenant Trigger Thresholds). These three levers control the hard engineering and financial viability of reaching 9 GW. High-impact levers (National Security, Social License, Workforce) are vital non-engineering elements that prevent the critical path infrastructure from being politically or legally blocked. The group collectively addresses the core tension between maximizing speed-to-market for AI compute and managing massive, uncertain long-term CAPEX related to French regulatory approvals.

### Decision 1: Grid Integration and Power Source Commitment
**Lever ID:** `b00fc888-34bf-4edd-9fb7-db1a8e0a6c52`

**The Core Decision:** This lever manages the critical dependency between physical construction commencement and securing contracted electrical capacity from RTE. Success is measured by obtaining binding transmission allocation for at least Phase 2 (3 GW) prior to finalizing Phase 1 construction financing. It involves negotiating high initial capital outlay for feasibility studies to accelerate the overall timeline while accepting the uncertainty inherent in French grid planning decisions.

**Why It Matters:** Committing to the 9 GW target prematurely risks substantial sunk costs in preliminary grid connection studies and substation rights-of-way that RTE may deny or heavily condition. A conservative approach mandates securing binding, contracted capacity allocation for Phase 2 (3 GW) before approving Phase 1 construction financing, acknowledging that RTE-mandated regional transmission upgrades introduce major, uncontrolled schedule risk and cost overruns outside developer control. Delaying firm power commitment until a later gate pushes tenants further downstream, potentially jeopardizing take-or-pay contracts.

**Strategic Choices:**

1. Negotiate a firm, contracted 500MW-1GW connection point for Phase 1 contingent on immediate, pre-paid submission of subsequent grid impact studies required for the full 9 GW capacity, accepting high initial capital exposure to expedite timeline.
2. Limit Phase 1 scope to 500 MW backed only by a non-binding RTE hosting consultation response, deferring all transmission upgrade capital expenditure until the 3 GW expansion gate, prioritizing immediate land and building mobilization over power certainty.
3. Establish a dual-path parallel strategy where the core campus targets 3 GW utilizing contracted nuclear power, while the remaining 6 GW is explicitly budgeted and planned as physically separate, geographically decoupled microgrids powered by contracted, on-site co-located long-duration BESS charged via PPA, accepting higher PUE for distribution.
4. Immediately reduce the target power commitment for the entire project to 3 GW total capacity, focusing all grid negotiation efforts on securing a single, proven transmission corridor, thereby de-risking the initial 8-year timeline.

**Trade-Off / Risk:** Tying Phase 1 financing to future grid confirmation for 9 GW creates an unmanageable schedule risk tied to RTE decisions, whereas scoping down limits initial revenue potential and campus dominance in the target region.

**Strategic Connections:**

**Synergy:** Amplifies Power Procurement Sequencing and Risk Hedging by securing the physical corridor for future power buys. It is constrained by Land Assembly Modality and Footprint Rationalization.

**Conflict:** Conflicts with Tenant Acquisition Trigger Threshold by potentially securing power before tenants are fully locked in, risking stranded fixed power capacity if demand dips unexpectedly.

**Justification:** *Critical*, This lever directly governs the project's core feasibility (9 GW delivery). It is the central hub connecting financing, tenant contracts, and physical manifestation, as securing grid capacity is the longest, most uncontrolled dependency in the plan, dictating the pace of all subsequent phases.

### Decision 2: Land Assembly Modality and Footprint Rationalization
**Lever ID:** `182c7249-4c09-4842-b27a-e05ac3137228`

**The Core Decision:** This strategic decision dictates the physical geography of the campus, addressing the infeasibility of aggregating 161 km² contiguously. Rationalization involves distributing phases across existing industrial zones to expedite land control and permitting velocity. Success metrics include reduced dispute timelines and successful integration of previously fragmented sites into a unified security and logistics concept, minimizing land-use sprawl.

**Why It Matters:** Attempting to assemble the contiguous 161 km² square parcel in Hauts-de-France presents extreme challenges in local planning consent, agricultural displacement, and brownfield aggregation, likely leading to multi-year litigation delays. Adopting a split-campus model across 3-5 existing, fully zoned industrial parks (e.g., Dunkirk port logistics, E-Valley) simplifies land control and accelerates Phase 1 but fragments the centralized security perimeter and increases internal logistics overhead for shared services like H/R or central offices. The high-rise mandate for AI compute density within a wide footprint pushes the land-use model toward inefficient internal sprawl rather than optimized density.

**Strategic Choices:**

1. Abandon the contiguous 161 km² block and instead secure distinct, non-contiguous land parcels totaling 50 km² across three established, permitted industrial zones (e.g., Cambrai, Dunkirk, Valenciennes) to accelerate Phase 1 readiness and fragment environmental permitting risk.
2. Force the consolidation of the full 161 km² target by offering a substantial, non-negotiable public benefit or land-value guarantee package to prefectural authorities, streamlining assembly under a single, comprehensive, but politically vulnerable, exceptional planning decree.
3. Institute a hyper-dense development model where 80% of the 161 km² is immediately designated as permanent ecological preservation/water retention/agricultural buffer around five strategically placed, highly secure, and vertically integrated 1 GW nodes, effectively limiting buildable area to 30 km² long-term.

**Trade-Off / Risk:** Forcing a single, monolithic land assembly guarantees schedule delays via local judicial review, whereas distributing the asset across industrial zones sacrifices centralized security and logistical efficiency for speed of land control.

**Strategic Connections:**

**Synergy:** Synergizes strongly with Local Social License and Community Buffer Zones, as splitting the campus across multiple sites may dilute localized opposition to a single, massive land grab.

**Conflict:** Creates conflict with National Security and Sovereignty Alignment by complicating the establishment of a single, hardened, perimeter-controlled zone necessary for sensitive national compute workloads.

**Justification:** *High*, This decision controls the initial speed of deployment versus the long-term security posture. The conflict between contiguous land assembly and a fragmented split-campus directly impacts the feasibility of meeting the 161 km² footprint or the security requirements for sovereign AI workloads.

### Decision 3: National Security and Sovereignty Alignment
**Lever ID:** `2d21cacb-07ff-4ee3-91ca-ab89bc0e7f52`

**The Core Decision:** This lever ensures the project's core French sovereign AI mandate is met by proactively aligning physical design and operational protocols with DGSI/ANSSI requirements from the outset. Success depends on achieving a signed protocol defining hardware sourcing control and internal security partitioning before Phase 1 Power FID. This governs access to premium, state-backed revenue streams, treating security compliance as an enabler rather than a post-construction certification.

**Why It Matters:** Failure to secure early, explicit alignment with DGSI/ANSSI regarding hardware provenance, data classification, and physical security for the sovereign AI partition jeopardizes the entire tenant base, as French state entities require stringent guarantees. Treating the national security review as a post-Phase 1 permitting milestone delays revenue; conversely, tailoring the physical design (e.g., dedicated facility layers, hardened corridors) prematurely adds substantial construction cost and reduces flexibility should security requirements shift based on geopolitical events beyond Year 3. The timeline for security clearance is often the longest uncontrolled path in French infrastructure projects.

**Strategic Choices:**

1. Mandate that the first 500 MW load remains exclusively for non-classified commercial tenants until a formal, signed agreement governing the separation, auditing, and operational protocols for the dedicated sovereign AI partition is executed with relevant national authorities.
2. Immediately allocate 2 GW of the total capacity as a pre-engineered, physically isolated, and dedicated sovereign compute zone, designed to the highest DGSI standards from Day 1, even if initial tenants are non-sovereign, to secure favorable regulatory status early.
3. Execute Phase 1 entirely on a temporary, modular, and externally hardened perimeter, deliberately foregoing initial sovereign classification until the facility demonstrates 24 months of flawless, low-incident operational performance and predictable PUE metrics.

**Trade-Off / Risk:** Delaying physical security hardening for the sovereign zone until after Phase 1 risks expensive retrofitting or outright denial of high-value government contracts, but early over-engineering inflates Phase 1 capital expenditure unnecessarily.

**Strategic Connections:**

**Synergy:** Directly enables Heat Reuse and Public Benefit Monetization by providing a secure framework under which sensitive domestic workloads can operate, boosting domestic value.

**Conflict:** Creates tension with Tenant Acquisition Trigger Threshold, as meeting stringent security requirements immediately raises the base cost engineering for all initial capacity, potentially slowing initial commercial lease-up.

**Justification:** *Critical*, This lever controls access to the most strategic and high-value tenant segment (sovereign AI) for the entire 9 GW buildout. Failure here undermines the project's differentiated value proposition, acting as a non-negotiable prerequisite for future state participation and revenue stability.

### Decision 4: Tenant Acquisition Trigger Threshold
**Lever ID:** `876ac8dc-d585-433d-ae2b-ca9fbe0095ba`

**The Core Decision:** This lever controls the pace of scale-up—specifically transitioning from 1 GW to 3 GW—by making expansion conditional on anchored, bankable revenue contracts, not merely projected market growth. Success is defined by securing high-percentage take-or-pay commitments before commencing high-CAPEX infrastructure builds like the next wave of substations. This prioritizes financial stability over aggressive market capture speed.

**Why It Matters:** Setting the expansion trigger (Phase 2 FID) contingent on 30–50% committed capacity via take-or-pay contracts forces a deliberate slowdown, protecting the project from overbuilding power infrastructure but potentially ceding market share to faster competitors in the Northern European AI race. Conversely, proceeding with expansion based on soft LOIs or pipeline visibility (e.g., 10% commitment) allows for rapid deployment but introduces material financing risk if anchor tenants retract during the 3-year construction window for the next tranche, leading to stranded substation capacity.

**Strategic Choices:**

1. Raise the minimum take-or-pay commitment threshold for the 1-3 GW expansion gate to 60% of the next tranche's capacity, sacrificing speed entirely in favor of leveraging committed revenue to secure significantly lower, syndicated debt financing rates.
2. Mandate that only US Dollar-denominated GW-capacity contracts for sovereign AI workloads count toward the Phase 2 expansion trigger, creating a higher barrier to entry but insulating the project's core P&L from short-term EUR/USD volatility.
3. Approve Phase 2 expansion based solely on achieving 100% utilization of the Phase 1 1 GW capacity being guaranteed by a consortium of three medium-sized European cloud providers, accepting lower per-unit revenue for guaranteed base-load tenancy.

**Trade-Off / Risk:** Requiring high revenue commitment (60%+) for expansion de-risks financing against vacancy but dramatically slows reaction time to sudden spikes in AI compute demand, sacrificing first-mover advantage.

**Strategic Connections:**

**Synergy:** Synergizes with Grid Integration and Power Source Commitment by using committed tenant revenue as the leverage required to unlock further high-capacity grid investment discussions with RTE.

**Conflict:** Directly conflicts with Fiber Connectivity Path Diversity and Ownership, as aggressive commitment thresholds might force early, suboptimal fiber expansion decisions before strategic long-term routing is finalized.

**Justification:** *Critical*, This is the primary financial gate controlling expansion risk. It directly manages the trade-off between aggressive speed-to-market and financial prudence, ensuring committed revenue covers the massive capital expenditure required for subsequent grid and land commitments.

### Decision 5: Fiber Connectivity Path Redundancy and Terrestrial vs. Subsea Access
**Lever ID:** `b50b7c15-19d1-4b06-bd0f-46fb2d08c412`

**The Core Decision:** This lever involves granular selection and negotiation of physical fiber assets, directly balancing latency performance (crucial for AI workloads) against single-point-of-failure risk from terrestrial route concentration. The objective is achieving geographic diversity across multiple continental points and subsea access early in the plan. Success is defined by achieving multi-route physical separation, even if it necessitates utilizing higher-cost or slightly higher-latency secondary connections initially.

**Why It Matters:** The choice among diverse fiber routes directly impacts the critical low-latency connection to major European financial and AI hubs, which is non-negotiable for the intended use case. Prioritizing a single, ultra-low latency terrestrial path with minimal terrestrial hops, while faster, concentrates catastrophic risk on a single physical corridor susceptible to localized digging or infrastructure failure across the French/Belgian border. Developing immediate redundancy via multiple terrestrial paths, or incorporating immediate subsea route diversity, adds significant initial right-of-way negotiation complexity and higher operational leasing costs.

**Strategic Choices:**

1. Mandate diversity only through the primary terrestrial routes to Paris and Brussels, accepting the geographic concentration risk in exchange for achieving best-possible latency metrics necessary for time-sensitive AI model training synchronization.
2. Fund the immediate physical construction or long-term leasing of physically separate fiber trenches, simultaneously entering agreements for two different subsea landing points (e.g., Dieppe/Calais and Dieppe/UK), prioritizing resilience over the first year's latency performance.
3. Outsource all fiber corridor development to a single, established carrier under a 15-year managed service contract, accepting their pre-existing primary routes in exchange for eliminating the immediate financial and administrative burden of land acquisition/easement processing.

**Trade-Off / Risk:** Outsourcing connectivity eliminates immediate complexity but locks the campus into a carrier's existing infrastructure limitations, which may not meet the evolving, specialized bandwidth or ultra-low latency requirements of the core AI workloads.

**Strategic Connections:**

**Synergy:** Is strongly amplified by Fiber Connectivity Path Diversity and Ownership, as this lever defines the requirements the ownership strategy must execute upon for resilience and performance.

**Conflict:** Trades off against Local Workforce Sourcing and Skill Uplift Mandate. Focusing intense early effort and capital on complex fiber easement negotiation detracts focus from essential local recruitment and training programs.

**Justification:** *Critical*, This lever is the financial control mechanism over the Grid Integration lever; determining *when* to commit capital to infrastructure upgrades (grid/substations) against tenant revenue dictates viability. It manages the core financial tension of the 15-year 9 GW buildout timeline.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Heat Reuse and Public Benefit Monetization
**Lever ID:** `6c281e97-6b1e-4468-9b1f-23bac3cbea90`

**The Core Decision:** This lever integrates the campus into the regional economy by monetizing waste heat, transforming a liability into a community benefit asset. Key success involves signing binding, low-margin, long-term off-take agreements to justify the upfront capital cost of specialized trenching and civil works. This mitigates social license risk by providing tangible, immediate local value outside of traditional employment figures.

**Why It Matters:** Exploring complex, high-volume heat reuse opportunities (e.g., district heating, industrial processes near Dunkirk) necessitates extending the physical campus boundary and increasing initial civil works expenditure significantly beyond standard data center footprints. While this transforms community relations into a public-benefit asset, the actual off-take contracts—which are essential for proving the ROI of this infrastructure—are typically long-term, low-margin, and introduce contractual complexity far earlier than standard tenant agreements. Deliberately ignoring heat reuse allows for simpler, faster site buildout and power density optimization but guarantees significant social license friction.

**Strategic Choices:**

1. Commit 2 GW of Phase 2 capacity specifically to serve a signed, take-or-pay contract with the local energy utility for dedicated low-grade heat export via trenching and pipeline infrastructure dedicated to district heating within the nearest 10 km radius.
2. Delay all heat reuse infrastructure planning until Phase 3, focusing Phase 1 and 2 solely on maximizing power density and PUE within the core footprint, managing community opposition via direct financial compensation only.
3. Design the campus land use to immediately incorporate a high-temperature waste heat sink (e.g., industrial biomass conversion or greenhouse cluster) requiring only the first two Phase 1 halls' heat rejection, utilizing this concrete, local use case to accelerate community acceptance.

**Trade-Off / Risk:** Early commitment to low-margin heat reuse leverages community benefit to unlock permitting faster, but the required upfront civil engineering diverts critical capital away from core compute deployment and capacity expansion.

**Strategic Connections:**

**Synergy:** Amplifies Local Social License and Community Buffer Zones by providing a concrete, structural benefit to the local community that reinforces the project's utility beyond compute rental.

**Conflict:** Directly conflicts with Power Procurement Sequencing and Risk Hedging by requiring complex civil works and potentially lower-value heat contracts to be funded before firm power contracts are fully settled.

**Justification:** *High*, While not directly tied to compute uptime, this lever is the primary mechanism to neutralize social license friction, which is a critical path blocker for permitting 9 GW sprawl. Success here accelerates the social feasibility necessary for the physical build.

### Decision 7: Fiber Connectivity Path Diversity and Ownership
**Lever ID:** `a4c4412a-55f5-4e21-8d6a-3c0fca7b5657`

**The Core Decision:** This lever governs the project's physical data transport foundation, balancing CAPEX against latency and vendor lock-in. Full ownership of dedicated dark fiber paths offers superior latency control and resilience against carrier disruptions, essential for hyperscale AI synchronization. Success is measured by achieving demonstrated low-latency paths to the four core hubs (Paris, London, Brussels, Frankfurt) while minimizing USD exposure associated with long-term international fiber leases.

**Why It Matters:** Relying primarily on diverse terrestrial routes linking to existing major hubs (Paris, London) creates dependency on incumbent telecom operators (Orange, Altice) for right-of-way access and service level agreements, introducing uncontrolled backhaul latency jitter. Taking an unconventional approach by partially funding and co-owning a dedicated dark fiber spur directly to the Dieppe or Dunkirk coastline for eventual subsea cable landing de-risks carrier dependency but requires substantial upfront capital investment before Phase 3 and introduces maritime regulatory hurdles.

**Strategic Choices:**

1. Procure redundant physical fiber paths from the three dominant national carriers, accepting the associated right-of-way limitations in exchange for minimizing initial infrastructure capital expenditure below 500 MW capacity.
2. Fund the engineering and initial trenching for a wholly-owned, direct-run dark fiber link from the campus boundary connecting to a single, strategically chosen, nearby subsea cable landing station, accepting a three-year delay to service.
3. Establish mandatory, legally binding Service Level Agreements (SLAs) with secondary/tertiary regional providers to ensure connectivity resilience, intentionally operating the first 1 GW cluster below peak performance thresholds to manage connection fragility.

**Trade-Off / Risk:** Owning dark fiber provides superior control over latency and dependency risk but requires significant CAPEX exposure tied to fiber installation before the facility generates meaningful revenue, delaying ROI.

**Strategic Connections:**

**Synergy:** Synergizes with Fiber Connectivity Path Redundancy and Terrestrial vs. Subsea Access by committing capital to resilience. Strong ownership minimizes operational dependency on external carriers.

**Conflict:** Conflicts with Power Procurement Sequencing and Risk Hedging by demanding substantial upfront capital before revenue generation. This diverts necessary funds from immediate grid financing requirements.

**Justification:** *Medium*, This is vital for AI synchronization but secondary to power and land. While critical, the options provided show that ownership requires high upfront CAPEX that competes with the more fundamental grid/power commitments needed for Phase 1.

### Decision 8: Local Workforce Sourcing and Skill Uplift Mandate
**Lever ID:** `35de1b16-a126-4e71-bc3a-0b14b088d5fe`

**The Core Decision:** This mandate centers on securing the long-term social license and operational talent pipeline by integrating local communities into the construction and operational workforce. The primary goal is to convert potential local NIMBYism into local support by ensuring the majority of accessible jobs are filled by upskilled regional hires. Success hinges on meeting local employment quotas without compromising construction quality or causing significant Phase 1 delays due to skill mismatch.

**Why It Matters:** Meeting the massive labor requirement for 50–100+ buildings using only pre-existing specialized data center construction labor from outside Hauts-de-France will inflate local labor costs and provoke strong political backlash regarding local economic benefit. Implementing an aggressive, mandatory in-region apprentice and retraining program for local residents builds significant social license capital and lowers long-term operating costs but introduces significant initial management overhead and risks quality control during the rapid Phase 1 ramp-up.

**Strategic Choices:**

1. Contract with a single, large, international EPC firm, granting them sole responsibility for labor acquisition, accepting the higher overall cost structure in exchange for guaranteed delivery timelines for the 1 GW build.
2. Establish a mandatory skills transfer requirement where 75% of all non-specialized construction labor hours must be filled by apprentices enrolled in locally certified technical schools, with failure triggering predefined community compensation penalties.
3. Focus initial workforce needs exclusively on highly-mechanized facility construction (e.g., prefabricated modules) to minimize human labor density until data center operations staffing can be stabilized via partnerships with regional universities.

**Trade-Off / Risk:** Prioritizing local workforce integration builds essential social license but compromises immediate construction speed and requires the project to absorb the upfront costs and risks associated with large-scale upskilling.

**Strategic Connections:**

**Synergy:** Directly amplifies Local Social License and Community Buffer Zones by providing tangible, sustained local economic benefits that justify land use decisions.

**Conflict:** Severely constrains Power Procurement Sequencing and Risk Hedging, as the associated training and management overhead delay construction schedules, pushing back PPA activation dates necessary to finalize grid commitments.

**Justification:** *High*, This lever is foundational to securing the long-term social license; failure leads to operational friction and political resistance. It directly supports the Heat Reuse strategy and mitigates risks associated with rapid local integration.

### Decision 9: Power Procurement Sequencing and Risk Hedging
**Lever ID:** `e28bc006-c51a-409c-90a6-1f5f52347eb8`

**The Core Decision:** This lever addresses the single longest lead-time risk: coordinating the 9 GW power delivery with EDF/RTE. The decision is whether to front-load massive collateral/financing for grid upgrades necessary between 3 GW and 9 GW early on, or deferring this obligation until later phases. Aggressively pre-funding secures capacity slots but creates massive capital overhang; deferral maximizes short-term liquidity but introduces severe grid sequencing risk post-Phase 1.

**Why It Matters:** Determining whether to finance large-scale grid upgrade collateral upfront or waiting until anchor tenants commit dictates the project's initial capital outlay versus its capacity delivery timeline. Front-loading substation and dedicated transmission works ensures rapid Phase 1 scaling upon site readiness, but ties up significant preliminary capital against uncertain ultimate demand realization. Deferring these major grid investments until binding multi-GW PPA is signed significantly reduces initial exposure but risks massive delay if RTE capacity allocation requires multi-year, sequential local network hardening not funded by the developer.

**Strategic Choices:**

1. Pre-fund 50% of the estimated RTE/local distribution network upgrade costs immediately in Phase 0 based on the 9 GW projection, securing the theoretical right-of-way and preliminary engineering slots before any major tenant commitment.
2. Adopt a strict 'No Grid Pre-Commitment' posture, meaning all grid investment collateral and infrastructure advancement is contingent upon a fully executed, validated power purchase agreement covering at least 5 GW before subsequent expansion funding is released beyond Phase 1.
3. Utilize temporary, high-density modular flywheel or kinetic energy storage deployment sufficient for 200 MW of the initial 500 MW load, buying twelve months to negotiate firm grid access for the remaining Phase 1 load without upfront multi-GW infrastructure financing.

**Trade-Off / Risk:** Pre-funding transmission upgrades based on a 9 GW projection is financially reckless without firm PPA signatures, yet waiting for grid confirmation stalls the critical, long-lead transmission component required before the site is viable.

**Strategic Connections:**

**Synergy:** Directly couples with Grid Integration and Power Source Commitment by providing the financial assurances needed to secure priority transmission upgrades based on future capacity projections.

**Conflict:** Conflicts with Tenant Acquisition Trigger Threshold, as massive pre-funding locks up capital that could otherwise be used to secure favorable power pricing or co-invest in tenant-specific infrastructure.

**Justification:** *High*, This lever dictates the physical land-use trade-off versus communal opposition. Given the 161 km² footprint, managing community backlash via land allocation is a direct control point over schedule risk and potential project stagnation from judicial review.

### Decision 10: Local Social License and Community Buffer Zones
**Lever ID:** `e2aeb220-75fd-4db9-bab7-5c6a14ecd9d5`

**The Core Decision:** This strategy determines the physical land allocation dedicated to non-compute, non-power infrastructure, directly trading off compute density against community acceptance and environmental compliance. Allocating substantial acreage for buffers, cooling system setbacks, and biodiversity offsets ensures smooth permitting continuity and reduces opposition risk, which is crucial for a 15-year build. Failure to secure this social license transforms land availability from a technical constraint into a legal/political blocker.

**Why It Matters:** The allocation of physical space for community engagement and ecological buffers determines the level of local political friction encountered during the multi-year buildout and permitting process. Generously allocating land for green buffers, local amenities, and agricultural continuation zones mitigates public opposition (social license risk) but reduces the economically productive footprint available for data halls and power infrastructure, forcing a lower eventual 9 GW capacity outcome within the 161 km² envelope. Conversely, aggressively minimizing buffers to maximize compute density accelerates capital return but maximizes the probability of high-cost judicial challenges or local mandates halting construction during Phase 1 or 2.

**Strategic Choices:**

1. Allocate a minimum of 25% of the 161 km² footprint for mandated, permanent biodiversity offsets, community integration spaces, and agricultural continuation zones, treating this acreage as an essential, non-negotiable element of the Phase 0 cost structure.
2. Adopt a 'Build-then-Mitigate' approach where the initial 1 GW build occupies the minimum necessary footprint, delaying the land zoning and commitment for large buffer zones until Phase 3, when clear project success makes mitigation funding politically easier.
3. Integrate a 'Shared Power Infrastructure' model, where the campus finances the necessary grid hardening for the entire surrounding region (not just the campus needs), positioning the project as the primary engine for local industrial stability rather than an isolated consumer.

**Trade-Off / Risk:** The Build-then-Mitigate approach fatally risks permitting renewal by postponing crucial social license investments, likely leading to litigation that freezes expansion after initial 1 GW deployment success.

**Strategic Connections:**

**Synergy:** Synergizes with Local Workforce Sourcing and Skill Uplift Mandate, as visible, permanent ecological/community investment reinforces the narrative that the project is a long-term regional partner.

**Conflict:** Directly conflicts with Land Assembly Modality and Footprint Rationalization, as any land proactively designated for ecological buffers directly reduces the maximum possible square meterage available for high-value data halls and power substations.

**Justification:** *Medium*, This is heavily related to lever 'a4c4412a'. Choosing physical path diversity is a critical network resiliency choice, but it is tactical compared to securing the power foundation (Critical levers) required to even bring the network online.


# Scenarios

# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** Intentionally extreme hyperscale, targeting 9 GW capacity across a massive 161 km² footprint, spanning 10–15+ years with €100B+ expenditure. Aims for regional dominance.

**Risk and Novelty:** Extremely high risk and novelty. The plan demands rigorous feasibility analysis, treating commitments as uncertain ('red-team'). It requires overcoming novel challenges in land aggregation, multi-GW grid coordination in France, and advanced liquid cooling deployment at this scale.

**Complexity and Constraints:** Extremely high complexity. Defined by numerous engineering constraints (PUE 1.15-1.25, liquid cooling), financial constraints (€100B+ budget), strict regulatory hurdles (DGSI/ANSSI), and mandatory skepticism regarding external approvals (RTE, Prefectures).

**Domain and Tone:** Industrial infrastructure development (Data Center/Energy/Real Estate) combined with high-level corporate strategy. The tone is rigorously skeptical, analytical, and condition-heavy, demanding feasibility proof rather than promotional certainty.

**Holistic Profile:** 

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Builder: Pragmatic Scale-Up
**Strategic Logic:** This path prioritizes a measured, phased approach that validates each major commitment before escalating capital. It seeks the optimal balance between speed and de-risking, relying on strong anchor tenants and avoiding the political pitfalls of extreme land demands while managing grid exposure commensurate with secured revenue.

**Fit Score:** 9/10

**Why This Path Was Chosen:** This scenario best fits the requirement to be 'rigorous, skeptical, and allowed to recommend downsizing,' as it heavily validates commitments before scaling, controlling power exposure (non-binding RTE for Phase 1) and rationalizing the footprint (hyper-dense model).

**Key Strategic Decisions:**

- **Grid Integration and Power Source Commitment:** Limit Phase 1 scope to 500 MW backed only by a non-binding RTE hosting consultation response, deferring all transmission upgrade capital expenditure until the 3 GW expansion gate, prioritizing immediate land and building mobilization over power certainty.
- **Land Assembly Modality and Footprint Rationalization:** Institute a hyper-dense development model where 80% of the 161 km² is immediately designated as permanent ecological preservation/water retention/agricultural buffer around five strategically placed, highly secure, and vertically integrated 1 GW nodes, effectively limiting buildable area to 30 km² long-term.
- **National Security and Sovereignty Alignment:** Mandate that the first 500 MW load remains exclusively for non-classified commercial tenants until a formal, signed agreement governing the separation, auditing, and operational protocols for the dedicated sovereign AI partition is executed with relevant national authorities.
- **Tenant Acquisition Trigger Threshold:** Raise the minimum take-or-pay commitment threshold for the 1-3 GW expansion gate to 60% of the next tranche's capacity, sacrificing speed entirely in favor of leveraging committed revenue to secure significantly lower, syndicated debt financing rates.
- **Fiber Connectivity Path Redundancy and Terrestrial vs. Subsea Access:** Mandate diversity only through the primary terrestrial routes to Paris and Brussels, accepting the geographic concentration risk in exchange for achieving best-possible latency metrics necessary for time-sensitive AI model training synchronization.

**The Decisive Factors:**

The 'Pragmatic Scale-Up' scenario is the superior fit because the project plan’s core directive is to conduct a 'red-team planning scenario' that is 'rigorous, skeptical,' and *allowed* to fail or downsize.

*   **Alignment with Skepticism:** This scenario enforces validation gates, using non-binding power commitments for Phase 1 and demanding high revenue thresholds (60% take-or-pay) for Phase 2 expansion, directly recognizing the plan's need to treat external approvals as uncertain until proven.
*   **Risk Management:** It embraces footprint rationalization by adopting a 'hyper-dense development model' for the 161 km² area, addressing complexity without resorting to the politically risky forced consolidation favored by The Pioneer.
*   **Comparative Weakness of Others:** 'The Pioneer' accelerates risk by forcing full land assembly and pre-engineering the sovereign zone, violating the plan's skeptical tone. 'The Consolidator' fails because it dismisses the core ambition by immediately cutting the target to 3 GW, rather than proving feasibility at 9 GW.

---
## Alternative Paths
### The Pioneer: Accelerated Dominance
**Strategic Logic:** This path aggressively pursues the 9 GW vision by front-loading capital and complexity to secure regional primacy and meet potential early market demand spikes. It accepts high financial and regulatory risk by aiming for the fastest possible mobilization across power commitment, land assembly, and security definition.

**Fit Score:** 8/10

**Assessment of this Path:** This scenario directly matches the plan's inherent 'intentionally extreme' nature by front-loading risks, such as forcing land consolidation and immediately defining a sovereign zone, aligning with the $9 GW ambition.

**Key Strategic Decisions:**

- **Grid Integration and Power Source Commitment:** Negotiate a firm, contracted 500MW-1GW connection point for Phase 1 contingent on immediate, pre-paid submission of subsequent grid impact studies required for the full 9 GW capacity, accepting high initial capital exposure to expedite timeline.
- **Land Assembly Modality and Footprint Rationalization:** Force the consolidation of the full 161 km² target by offering a substantial, non-negotiable public benefit or land-value guarantee package to prefectural authorities, streamlining assembly under a single, comprehensive, but politically vulnerable, exceptional planning decree.
- **National Security and Sovereignty Alignment:** Immediately allocate 2 GW of the total capacity as a pre-engineered, physically isolated, and dedicated sovereign compute zone, designed to the highest DGSI standards from Day 1, even if initial tenants are non-sovereign, to secure favorable regulatory status early.
- **Tenant Acquisition Trigger Threshold:** Approve Phase 2 expansion based solely on achieving 100% utilization of the Phase 1 1 GW capacity being guaranteed by a consortium of three medium-sized European cloud providers, accepting lower per-unit revenue for guaranteed base-load tenancy.
- **Fiber Connectivity Path Redundancy and Terrestrial vs. Subsea Access:** Fund the immediate physical construction or long-term leasing of physically separate fiber trenches, simultaneously entering agreements for two different subsea landing points (e.g., Dieppe/Calais and Dieppe/UK), prioritizing resilience over the first year's latency performance.

### The Consolidator: Stability and Cost Control
**Strategic Logic:** This conservative strategy minimizes regulatory exposure and upfront CapEx by immediately scaling back the overall ambition to a demonstrably achievable 3 GW total footprint. It favors proven operational stability over market capture speed, leveraging controlled cost structures to enhance financing credibility.

**Fit Score:** 4/10

**Assessment of this Path:** This scenario is a poor fit because it immediately scales down the core ambition to 3 GW, which contradicts the plan's explicit focus on planning for a 9 GW target and addressing the feasibility of the extreme scale.

**Key Strategic Decisions:**

- **Grid Integration and Power Source Commitment:** Immediately reduce the target power commitment for the entire project to 3 GW total capacity, focusing all grid negotiation efforts on securing a single, proven transmission corridor, thereby de-risking the initial 8-year timeline.
- **Land Assembly Modality and Footprint Rationalization:** Abandon the contiguous 161 km² block and instead secure distinct, non-contiguous land parcels totaling 50 km² across three established, permitted industrial zones (e.g., Cambrai, Dunkirk, Valenciennes) to accelerate Phase 1 readiness and fragment environmental permitting risk.
- **National Security and Sovereignty Alignment:** Execute Phase 1 entirely on a temporary, modular, and externally hardened perimeter, deliberately foregoing initial sovereign classification until the facility demonstrates 24 months of flawless, low-incident operational performance and predictable PUE metrics.
- **Tenant Acquisition Trigger Threshold:** Mandate that only US Dollar-denominated GW-capacity contracts for sovereign AI workloads count toward the Phase 2 expansion trigger, creating a higher barrier to entry but insulating the project's core P&L from short-term EUR/USD volatility.
- **Fiber Connectivity Path Redundancy and Terrestrial vs. Subsea Access:** Outsource all fiber corridor development to a single, established carrier under a 15-year managed service contract, accepting their pre-existing primary routes in exchange for eliminating the immediate financial and administrative burden of land acquisition/easement processing.


# Assumptions

# Purpose

**Purpose:** business

**Purpose Detailed:** Strategic planning and feasibility assessment for a massive, multi-phase, infrastructure-intensive commercial data center project targeting 9 GW capacity, involving significant capital expenditure, grid coordination, regulatory navigation, and long-term industrial development.

**Topic:** Development of an intentionally extreme hyperscale AI data center campus (9 GW) in Hauts-de-France, France.

# Domain

**Primary domain:** Data Center Infrastructure Planning

**Secondary domains:** Electrical Power Engineering, Large Scale Land Development, French Regulatory Compliance

**Rationale:** Data Center Infrastructure Planning is the primary outcome because this project is fundamentally defined by the scope, scale, and rigorous feasibility planning of the 9 GW campus. While Electrical Power Engineering and French Regulatory Compliance are critical constraints, the overall success criterion rests on the master plan itself. Urban and Regional Planning is the strongest alternative, but it supports the central data center planning effort.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Data Center Infrastructure Planning | 5 | 5 | outcome | The entire project is defined by the planning and execution of a hyperscale data center. |
| French Regulatory Compliance | 5 | 5 | constraint | Navigating French permitting, environmental law, and security reviews is a critical blocker. |
| Energy Grid Management | 5 | 5 | constraint | The 9 GW power requirement critically depends on French grid feasibility and coordination. |
| Electrical Power Engineering | 5 | 4 | constraint | Sourcing and integrating 9 GW of power from the French grid is a critical feasibility bottleneck. |
| Large Scale Land Development | 4 | 4 | method | Assembling and modeling the use of 161 km² across multiple zones is a core planning component. |
| Telecommunications Infrastructure | 4 | 4 | method | Diverse, low-latency fiber connectivity across Europe is essential for AI compute function. |
| Urban and Regional Planning | 4 | 4 | outcome | The massive land parcel assembly and zoned land-use model requires significant planning expertise. |
| Real Estate Acquisition | 4 | 4 | method | Assembling 161 km² of land requires specialized land acquisition and assembly methods. |
| Environmental Impact Assessment | 4 | 4 | constraint | Water, biodiversity, and brownfield remediation are key feasibility and permitting constraints. |

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** The plan is an extremely detailed, multi-year strategy focused on the physical execution of building a massive data center campus spanning 161 km² in Hauts-de-France, France. This involves massive physical construction, land acquisition/assembly (161 km²), coordinating multi-gigawatt electrical infrastructure (9 GW), managing physical cooling systems (liquid cooling loops), establishing physical fiber routes, dealing with brownfield remediation, and navigating physical permitting processes localized to specific parcels of land. Even though the *output* relates to software/AI compute, the *plan* is overwhelmingly dedicated to overcoming rigorous physical, engineering, logistical, and regulatory hurdles required to place that compute in the real world. Therefore, it is classified as physical.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Footprint must accommodate 161 km² (though rationalized to ~30 km² buildable area)
- Access to 9 GW of contracted, reliable, low-carbon/nuclear-backed power post-Phase 2
- Proximity to existing industrial revitalization zones (Cambrai, Dunkirk, Valenciennes)
- Favorable cooling climate (low risk for high-water cooling)
- Strategic latency to Paris, London, Brussels, and Frankfurt via diverse fiber routes
- Access to suitable brownfield or industrial land suitable for remediation and large-scale development

## Location 1
France

Hauts-de-France Region: Cluster 1 (E-Valley/Cambrai)

Industrial land near Cambrai or Valenciennes focusing on brownfield redevelopment (E-Valley zone).

**Rationale**: This primary zone targets the established industrial redevelopment narrative. It offers high initial velocity for land assembly if a fragmented/hyper-dense model is adopted, focusing on early phases (1 GW) supported by existing logistics infrastructure.

## Location 2
France

Hauts-de-France Region: Cluster 2 (Dunkirk Port Area)

Industrial or reclaimed land near the Port of Dunkirk.

**Rationale**: Crucial for accessing heavy logistics, potential maritime fiber routes (Dieppe/Calais alternative), and potentially better access to heavy industrial heat-reuse partners or diverse power supply interconnection points (e.g., through ports logistics nodes).

## Location 3
France

Hauts-de-France Region: Buffer/Expansion Reserve Zones

Large-scale agricultural or ecological buffer land parcels identified immediately adjacent to Clusters 1 and 2.

**Rationale**: Supports the chosen 'hyper-dense development model' where 80% of the notional 161 km² is preserved as non-buildable buffer, ecological zones, and land expansion reserve. This mitigates local opposition to urban sprawl and water/stormwater impact while maintaining the legal option to expand up to 9 GW capacity over the 15-year timeline.

## Location Summary
The plan explicitly targets Hauts-de-France, France, focusing on industrial zones near Cambrai, Valenciennes, and Dunkirk. Three locations are specified to align with the Skeptical Path (Pragmatic Scale-Up): identifying two primary industrial clusters for dense buildout and a third adjacent area for land assembly dedicated to the mandated ecological and community buffers (80% of the notional 161 km² footprint).

# Currency Strategy

This plan involves money.

## Currencies

- **EUR:** The primary currency of the project location (France) for land acquisition, labor, local taxes, and grid connection costs.
- **USD:** Hardware procurement (GPUs/TPUs, networking gear) and potential international financing will expose the project to USD fluctuations.

**Primary currency:** EUR

**Currency strategy:** EUR will be the primary currency for budgeting, operational accounting, and reporting, as local costs (land, labor, grid) are EUR-denominated. Significant USD exposure due to hardware procurement must be tracked separately, and a formal FX hedging strategy (e.g., forward contracts) must be implemented for all major anticipated USD hardware purchases starting in Phase 1 to stabilize the budget against exchange rate volatility.

# Identify Risks


## Risk 1 - Regulatory & Permitting
Failure to secure necessary land assembly consents and operational permits for the hyper-dense, but geographically fragmented, development spanning multiple industrial zones in Hauts-de-France. Legal challenges from agricultural/environmental groups against the large-scale buffer zone designation (Decision 2 - Choice 2) could freeze construction.

**Impact:** A delay of 12–24 months in achieving Phase 1 Final Investment Decision (FID), translating to an estimated €500M–€1B overrun in financing and carrying costs for Phase 0/1, or forced reduction of the desired buildable area from 30 km² to below 15 km².

**Likelihood:** High

**Severity:** High

**Action:** Immediately initiate proactive engagement with regional environmental authorities (DREAL) and prefectural offices (DDETSPP) to secure 'Projet d'Intérêt Général' (PIG) status for the critical infrastructure components (substations, main fiber conduits) that span multiple municipalities, treating the agreed-upon buffer zones as non-negotiable early concessions.

## Risk 2 - Technical
Inability to meet the aggressive PUE target of 1.15–1.25 across 1 GW+ capacity using default direct-to-chip liquid cooling at scale, given the novelty of deploying this technology for the entire first tranche in a non-optimized, brownfield environment.

**Impact:** Exceeding the target PUE by 0.1 (moving to 1.25–1.35 average) could increase annual operational energy costs by an estimated €5M–€10M at 1 GW capacity, and critically, may violate contractual PUE performance clauses tied to initial anchor tenants (Decision 4).

**Likelihood:** Medium

**Severity:** Medium

**Action:** Pilot the liquid cooling infrastructure validation extensively during the design phase using digital twins and hardware simulation. De-risk Phase 1 by ensuring anchor tenants accept a performance-based escalator clause tied to energy costs if PUE targets are missed by more than 0.05 due to unforeseen pump/fluid dynamics integration challenges.

## Risk 3 - Financial
Sunk capital expenditure if RTE/EDF cannot confirm the necessary grid upgrades for Phase 2 (3 GW) capacity commitment before Phase 1 (1 GW) construction financing is finalized, as per Decision 1 (Choice 2 - Pragmatic Scale-Up).

**Impact:** The inability to secure binding transmission allocation by the Phase 1 FID decision gate could force a halt, potentially stranding €1B–€2B of already spent Phase 0/1 capital (land assembly, initial build out) if anchor tenants withdraw pending power certainty.

**Likelihood:** High

**Severity:** High

**Action:** Strictly adhere to the Pragmatic Scale-Up strategy: do not proceed with Phase 2 expansion funding (beyond studies) until RTE provides a formal, legally binding contract for the required backbone transmission capacity upgrades for the next expansion tranche.

## Risk 4 - Supply Chain
Significant exposure to USD/EUR exchange rate volatility affecting the procurement of high-density GPU/TPU hardware and networking gear, despite currency hedging strategy (Currency Strategy).

**Impact:** If the EUR depreciates by >10% relative to the USD between procurement contracts and final hardware payment dates, the total hardware cost for the 9 GW buildout could inflate by an unhedged €8B–€15B on the total projected €100B-€140B budget.

**Likelihood:** Medium

**Severity:** High

**Action:** Implement multi-year forward hedging contracts for 70% of projected USD hardware needs (Phase 1 and 2). Critically, Phase 1 tenants must be asked to contract in EUR-equivalent terms, passing the risk of minor remaining FX deviation back to the consumer.

## Risk 5 - Operational / Security
Failure to secure DGSI/ANSSI protocols and sign off on the sovereign AI partition (Decision 3) prior to leasing 500 MW of physical space, leading to high-security buildout inefficiency or denial of crucial state contracts.

**Impact:** If the sovereign partition cannot be certified, the project loses access to the premium (and assumed stable) domestic revenue stream, jeopardizing the 60% required commitment threshold for Phase 2 expansion (Decision 4), potentially leading to €10B–€20B in lost long-term contracted revenue.

**Likelihood:** Medium

**Severity:** High

**Action:** Isolate the initial 500 MW cluster entirely from the planned sovereign zone footprint. Proactively engage DGSI in Phase 0/1 with detailed security design schematics for the *future* partition, ensuring Layer 1 physical segregation is integrated into initial substation planning, even if operational certification is deferred.

## Risk 6 - Environmental / Water
Unforeseen hydrological or environmental constraints in Hauts-de-France (a region with known water stress, despite better climate than the South) making the 'ultra-low-water' liquid cooling strategy technically non-viable or prohibitively expensive via high-volume water recycling infrastructure.

**Impact:** If the site requires evaporative cooling for peak load management, operational water consumption could trigger regional water restrictions, potentially leading to mandatory operational curtailment during summer months, resulting in €1M–€5M in immediate revenue penalties per week of restriction.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Mandate the use of zero-water density heat rejection (e.g., dry coolers or advanced heat pumps) for 100% of the Phase 1 build, accepting a temporary PUE degradation (e.g., 1.20 max) until long-term water sustainability can be proven via pilot, thereby front-loading the PUE constraint over the water constraint.

## Risk 7 - Social / Policy
Public opposition or judicial appeal stalls development based on the 'hyper-dense development model' which sacrifices 80% of the 161 km² for buffers, leading to accusations of hoarding land without immediate community benefit or causing loss of agricultural land (Decision 2, Choice 2 & Decision 10).

**Impact:** Local pushback could result in the Prefecture reducing the allowed buildable area to less than 20 km², fatally constraining the 9 GW target to a maximum of 3–4 GW, requiring a complete re-evaluation of the 15-year business case.

**Likelihood:** High

**Severity:** High

**Action:** Aggressively implement Decision 8 (Workforce Uplift) and Decision 6 (Heat Reuse) in Phase 0. Use the designated buffer land not just for biodiversity, but for demonstrably tangible community benefits (e.g., a pre-certified solar farm supplying local housing) to convert potential opposition into localized stakeholder cooperation.

## Risk 8 - Technical / Integration
Latency incompatibility between the chosen terrestrial fiber routes (Decision 5) and the needs of synchronized AI model training workloads, which require sub-millisecond consistency across the Paris/London/Brussels network.

**Impact:** If the latency exceeds mandated tenant SLAs (e.g., over 1.5ms terrestrial round trip to Paris), tenants may claim breach of contract, potentially leading to contract renegotiation or vacancy if the necessary dark fiber/subsea investment cannot be secured until Phase 3.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Immediately task a specialist engineering team to conduct independent, real-time latency benchmarking across multiple incumbent carriers. If results confirm performance marginally below requirements, commit Phase 1 CAPEX to securing dark fiber rights-of-way for the identified geographically diverse Phase 2 fiber path, accepting the conflict with Power Procurement Sequencing.

## Risk 9 - Financial / Budgeting
Underestimation of Brownfield Remediation Costs within the identified industrial zones (Cambrai/Dunkirk). Contamination levels may exceed expectations, particularly given the site's industrial history (former steel, refinery, military zones).

**Impact:** Phase 0 remediation costs, initially budgeted at €250M–€750M, could easily double or triple (€500M–€2.25B cumulative spend) if unforeseen hazardous materials require advanced soil stabilization or off-site disposal, delaying the physical start of data hall construction.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Require 80% of Phase 0 budget allocation to be dedicated to comprehensive, deep-bore environmental testing and risk modeling on the targeted buildable parcels, securing fixed-price remediation contracts with established regional specialists *before* land assembly finalization.

## Risk summary
The project faces an extremely high-risk profile dominated by regulatory uncertainty and interdependent critical path items. The 'Pragmatic Scale-Up' strategy adopted mitigates immediate financial exposure (by deferring grid commitment and enforcing high tenant thresholds) but heightens the risk of political/social blockage due to the extreme land rationalization (80% buffers vs. 20% buildable area). **The three most critical risks are:** 1. **Regulatory Delays in Land Assembly/Permitting (High/High):** Local judicial review of the fragmented, hyper-dense land model could halt all progress. 2. **RTE/Grid Confirmation (High/High):** The decision to delay transmission investment until Phase 2 FID risks stranding Phase 1 capital if grid capacity is denied or delayed significantly beyond the expected 3-7 year lead time. 3. **Social License Erosion (High/High):** Failure to convert community opposition via proactive workforce development and heat-reuse monetization will lead to outright political rejection or mandated footprint reduction, undermining the 9 GW ambition.

Mitigation strategies are heavily overlapping: successful social license programs (Workforce/Heat Reuse) directly support faster regulatory permitting, reducing the likelihood of the first critical risk. However, the core trade-off remains between speed (required by the AI market) and financial prudence (required by the skeptical red-team mandate).

# Make Assumptions


## Question 1 - What is the quantified breakdown of the 161 km² footprint allocation, specifying the target buildable area (data center/substations) versus the essential buffer/community/ecological zones for the hyper-dense model?

**Assumptions:** Assumption: Based on the 'hyper-dense development model' (20% buildable), the target physical buildable area for data halls, substations, and critical infrastructure is approximately 32.2 km² (20% of 161 km²), with the remaining 128.8 km² allocated to non-buildable buffers and expansion reserve as identified in the land use strategy.

**Assessments:** Title: Land Use Feasibility Assessment
Description: Evaluation of the physical practicality of assembling and zoning the designated hyper-dense-plus-buffer footprint.
Details: Allocating 80% to buffers severely mitigates local opposition (Risk 7) but reduces the ultimate capacity threshold achievable within the initial 15 years. Benefit: Streamlines permitting velocity for the 20% core footprint. Risk: If anchor tenants demand contiguous, expansive deployment, this model fails, requiring a split-campus review. Opportunity: The 128.8 km² buffer provides significant long-term flexibility for heat exchange/water management infrastructure expansion without requiring new land acquisition.

## Question 2 - Given the 'Pragmatic Scale-Up' strategy, what is the explicit, legally defined milestone (outside of EDF/RTE internal timelines) that will serve as the binding **Go/No-Go** trigger for funding Phase 2 transmission upgrades (Grid Integration Decision 1)?

**Assumptions:** Assumption: The binding trigger for committing capital to Phase 2 (3 GW) transmission upgrades will be the execution of signed, take-or-pay, non-cancellable Power Purchase Agreements covering 60% of the 2 GW expansion tranche, independent of RTE's internal construction schedule.

**Assessments:** Title: Grid Investment Control Assessment
Description: Analysis of the financial linkage between tenant revenue commitment and major capital expenditure on external grid infrastructure.
Details: This links the financial decision gate (Tenant Trigger Threshold) directly to the physical grid commitment, adhering to the skeptical mandate. Risk: If RTE requires definitive capital commitment for grid prep *before* the 60% tenant threshold is met, the project faces stranded capital risk (Risk 3). Benefit: Ensures infrastructure investment scales directly with bankable revenue signals.

## Question 3 - What specific EUR-denominated public benefit commitment or infrastructure investment (e.g., workforce training funding, heat exchange partnership capital) will be contractually locked in during Phase 0 to immediately satisfy community concerns regarding land use and workforce displacement (Decision 10)?

**Assumptions:** Assumption: Phase 0 budget (€250M–€750M) will allocate a mandatory minimum of 5% (€12.5M–€37.5M) towards initial operational funding for the regional skills academy (Decision 8) and feasibility studies for the identified heat-reuse industrial partner near Dunkirk (Decision 6).

**Assessments:** Title: Social License Stabilization Assessment
Description: Evaluation of immediate investment required to secure the political/social operating environment for the 15-year plan.
Details: Front-loading small, visible, tangible benefits (jobs/heat study) mitigates high-likelihood social risks (Risk 7). Benefit: Turns local opposition into negotiated cooperation, accelerating permitting velocity through prefectural support. Risk: If the commitments are non-binding, they lose efficacy rapidly; mandatory allocation within Phase 0 ensures seriousness.

## Question 4 - What is the projected maximum operational PUE (including BESS and ancillary power losses) expected for the Phase 1 build, considering the mandated default liquid cooling system and the rejection of high-water-use cooling methods (Risk 6 mitigation)?

**Assumptions:** Assumption: Full utilization of direct-to-chip liquid cooling, optimized for the 1.15 target, coupled with BESS charging/discharging efficiency losses (estimated at 2% overhead), results in a conservative Phase 1 operational PUE target of 1.20, even if the 1.15 goal is missed initially.

**Assessments:** Title: Efficiency and Operational Cost Performance
Description: Verification of the expected energy efficiency based on technology choices and risk mitigation strategies.
Details: A 1.20 PUE is achievable but requires precise integration of liquid cooling manifolds without significant parasitic losses from pumps or HVAC for non-IT load. Risk: If PUE exceeds 1.25 (Risk 2), long-term operational costs increase by ~€5M/GW/year, impacting contract profitability. Opportunity: Maintaining near-target PUE justifies the higher liquid-cooling CAPEX compared to alternatives.

## Question 5 - What is the projected EUR cost variance for the full 9 GW buildout (€100B–€140B+) if the EUR/USD exchange rate shifts unfavorable by 10% relative to the Phase 0 baseline, assuming only 70% of anticipated USD hardware expenditure is hedged?

**Assumptions:** Assumption: Based on a €120B total budget (midpoint) and assuming 30% of total CAPEX is USD-denominated hardware subject to FX changes, a 10% unfavorable shift translates to an additional gross cost impact of approximately €4.32 Billion (0.30 * 120B * 0.10).

**Assessments:** Title: Financial Exposure and Hedging Efficacy
Description: Quantifying the remaining FX risk after applying the mandated 70% hedge strategy.
Details: The residual €4.3B exposure highlights that the 70% hedge is insufficient to fully de-risk the project's largest variable cost category (hardware). Benefit: This projection mandates immediate execution of the forward contract strategy immediately upon locking in Phase 1 pricing. Risk: Unhedged exposure of this magnitude necessitates a dedicated budget contingency line item to absorb potential volatility impacting debt servicing covenants.

## Question 6 - Since the split-campus model (Decision 2) is favored over contiguous assembly, what is the minimum acceptable latency deviation between the two primary industrial clusters (Cluster 1: Cambrai/E-Valley and Cluster 2: Dunkirk) to ensure functional synchronization for synchronized AI workloads?

**Assumptions:** Assumption: Due to the 50–70 km separation between the primary clusters, the required inter-site latency must be maintained below 2ms round-trip time (RTT) for synchronized AI operations, necessitating dedicated, privately leased, high-grade terrestrial fiber paths between the two locations.

**Assessments:** Title: Inter-Campus Synchronization Viability
Description: Assessment of the technical feasibility of maintaining critical synchronization latency across the decentralized physical model.
Details: If the required 2ms RTT cannot be met via direct terrestrial connection between Cluster 1 and 2, the split-campus model becomes functionally unviable for demanding AI workloads, forcing a centralization that conflicts with the land assembly strategy. Opportunity: If met, this enables decoupling of regulatory/power risks between the two sites.

## Question 7 - Where specifically will the initial 500 MW Phase 1 construction focus its hardware procurement (GPUs/TPUs) to satisfy the 'non-classified commercial tenants' requirement, and how will DGSI assurance be provided that this initial cluster is physically isolated from any future sovereign zones?

**Assumptions:** Assumption: Phase 1 hardware will utilize commercial-grade, non-restricted AI accelerators (e.g., current generation enterprise models), which will be housed in physically separate buildings whose associated primary substation capacity (substation 1) is legally ring-fenced from the planned sovereign zone substations (substation 2) designated for Phase 3/4.

**Assessments:** Title: Security Isolation and Initial Revenue Path
Description: Evaluation of the initial execution plan for satisfying both immediate revenue needs and long-term sovereign compliance (Risk 5).
Details: Physical isolation (separate substations/halls) acts as the practical pre-certification mitigation for the sovereign zone delay. Benefit: Allows for immediate revenue generation while DGSI reviews finalized sovereign partition designs. Risk: The definition of 'non-classified' must be formally agreed upon in Phase 0 to avoid later requirement creep that forces retrofitting these initial halls.

## Question 8 - Considering the 'Pragmatic Scale-Up' strategy defers transmission upgrades until Phase 2, what specific, temporary land-use mechanism (e.g., easement, lease structure) will be immediately secured in Phase 0 for the future interconnection points required for the 3 GW expansion?

**Assumptions:** Assumption: Phase 0 land acquisition will immediately secure preliminary right-of-way (ROW) easements for the exact locations of the Phase 2 required expansion substations and the transmission tie-lines (including the required buffer land adjacent to rights-of-way), even if final financing for the physical build is deferred.

**Assessments:** Title: Long-Lead Physical Infrastructure Control
Description: Assessing control over physical real estate necessary for future grid integration, independent of power commitment funding.
Details: Securing ROW easements is a long-lead permitting activity that must be decoupled from the grid financing trigger. Failure to secure ROW in Phase 0 transforms the grid uncertainty (Risk 3) into a physical land assembly blocker that cannot be solved later. Benefit: This buffers the physical implementation schedule against the utility's internal political timeline for granting transmission access.

# Distill Assumptions

- Buildable area targets 32.2 km² (20% of 161 km²), with 80% reserved for buffers.
- Phase 2 transmission funding triggers upon 60% take-or-pay contracts for the 2 GW tranche.
- Phase 0 allocates 5% of initial budget for local skills academy and heat-reuse feasibility studies.
- Conservative Phase 1 operational PUE target is set at 1.20, utilizing mandatory direct-to-chip liquid cooling.
- A 10% unfavorable EUR/USD shift creates approximately €4.32 Billion unhedged cost exposure on hardware.
- Inter-cluster latency for split campuses must remain below 2ms RTT for synchronized AI workloads.
- Phase 1 commercial hardware must be physically isolated via separate substation capacity from future sovereign zones.
- Phase 0 must immediately secure preliminary right-of-way easements for Phase 2 transmission upgrades.

# Review Assumptions

## Domain of the expert reviewer
High-Scale Infrastructure Project Planning and Feasibility Assessment

## Domain-specific considerations

- Grid Interconnection Lead Times (RTE/EDF)
- French Regulatory/Sovereignty Alignment (DGSI/ANSSI)
- Large-Scale Land Assembly and Zoning Complexity (161 km²)
- Capital Allocation Sequencing vs. Revenue Triggering
- Workforce Development for Specialized Infrastructure

## Issue 1 - Critical Missing Assumption: Regulatory Time Buffer (RTE/Permitting)
The plan heavily relies on the 'Pragmatic Scale-Up' strategy, deferring transmission funding until 60% tenant commitment for Phase 2 (3 GW). However, there is *no explicit assumption* about the actual time required by RTE (Réseau de Transport d'Électricité) to *approve and complete* mandated transmission upgrades *after* funding commitment. French grid extension lead times are notoriously long, often exceeding 3-5 years for multi-GW projects. This creates a dangerous dependency gap: tenants commit based on power availability, but infrastructure completion time is outside developer control.

**Recommendation:** Introduce a critical missing assumption based on conservative external benchmarks: Assume a minimum 36-month completion time for RTE-mandated substation and tie-line upgrades following Phase 2 FID (i.e., the 60% tenant trigger). Adjust the Tenant Acquisition Trigger Threshold (Decision 4) to include a 'Power Readiness Lockout Clause': Phase 2 Commercial Operation Date (COD) is defined as Min(Tenant Anchor COD + 12 months, RTE Upgrade Completion Date).

**Sensitivity:** The baseline assumption is an implicit 18-month grid lead time post-funding. If the actual lead time is 36 months (50% longer), the delay in realizing 3 GW revenue pushes the project's overall timeline by 1.5 years. This delay equates to a loss of projected ROI by 8-12% over the first four years due to deferred revenue scaling, potentially increasing the total project cost of capital by €500M–€800M.

## Issue 2 - Under-Explored Assumption: Financial Viability of 80% Land Buffer
The chosen 'hyper-dense' model reserves 80% (128.8 km²) of the target 161 km² for buffers and reserves, with only 20% (32.2 km²) buildable. The assumption is that this preserves optionality and smooths permitting. However, the financial viability hinges on whether the cost of acquiring and holding this massive land reserve (even if less contested) is covered by the operating budget or must be capitalized. Furthermore, the ability to *legally* hold 80% of land designated for future industrial expansion as 'permanent ecological preservation' or 'buffer' under French planning law for 15 years without strong, binding ongoing community benefit contracts (Decision 6) is highly questionable and risks regulatory reversal.

**Recommendation:** Explicitly assume a holding cost budget for the 128.8 km² buffer zone, estimated at €50,000–€75,000 per hectare annually for maintenance, insurance, and ongoing legal defense buffers. Crucially, decouple the 'permanent' nature of 80% from the strategic plan: Reclassify 50% of the buffer as 'Phase 2/3 Expansion Reserve' requiring only annual agricultural lease renewal, and the remaining 30% as 'Permanent Ecological Offset' requiring upfront, binding, funded commitments to local environmental bodies (Decision 10).

**Sensitivity:** If the annual holding cost for the 12,880 hectares is underestimated by €20,000/hectare (total €257.6M annually for 5 years pre-scaling), the initial Phase 0/1 CAPEX will overrun by €1.3B. If local authorities mandate converting 30% of the buildable area (10 km²) back into buffer due to social disputes, the maximum potential capacity is permanently reduced from 9 GW to ~6 GW, decreasing baseline potential ROI by 30-40%.

## Issue 3 - Unrealistic Assumption: Workforce Skill Uplift Velocity
Decision 8 mandates aggressive local workforce sourcing (75% apprenticeships) to secure social license. While necessary, assuming this can be achieved without causing Phase 1 construction delays is highly optimistic. Specialized construction for liquid-cooled DCs, combined with the requirement for DGSI physical isolation verification (Risk 5), demands specialized skills that regional vocational schools (Decision 3/8) cannot generate instantly. The assumption appears to underestimate the management overhead and quality control risks associated with a massive, unproven upskilling program.

**Recommendation:** Introduce a staffing latency factor to the timeline: Assume only 30% of specialty construction hours can be filled by qualified local hires in Year 1, rising to 50% by Year 2, forcing reliance on higher-cost international contractors for the initial 12-18 months. Integrate a contingency budget line item of €20M–€40M specifically for importing specialized management teams to *oversee and train* the local workforce, mitigating quality risk without halting site mobilization.

**Sensitivity:** If specialized labor is unavailable, the construction timeline for Phase 1 (1 GW) could realistically extend from a baseline of 24 months to 30-36 months. This 6-12 month delay, combined with associated project management costs (€50M–€100M), would reduce the project's Net Present Value (NPV) by 4-6% based on foregone early revenues.

## Review conclusion
The project plan is strategically sound in identifying interdependent risks (Power, Land, Social License) and appropriately selects a skeptical, phased approach ('Pragmatic Scale-Up'). However, the execution timeline is overly optimistic, specifically regarding external dependencies. The review identified three critical weaknesses by quantifying missing assumptions:

1. **Missing Grid Completion Buffer:** The plan lacks a realistic timeline for RTE execution post-funding commitment, posing a 1.5-year revenue delay risk.
2. **Uncosted Land Holding:** The massive 80% buffer zone is assumed manageable but lacks a dedicated holding cost budget, risking a €1.3B overrun in early CAPEX.
3. **Workforce Optimism:** The reliance on rapid local upskilling to maintain the aggressive construction schedule introduces a high likelihood of 6-12 month technical delays in Year 1, impacting early ROI.

Immediate action must focus on locking in regulatory timing buffers, fully budgeting for the massive land reserve, and accepting higher initial construction costs/delays to ensure genuine local workforce integration.

# Governance

# Governance Audit


## Audit - Corruption Risks

- Bribery or kickbacks to local planning officials (DREAL, Municipalities) to expedite zoning approvals or secure favorable land assembly terms for the massive 161 km² footprint or the 'hyper-dense development model' (Decision 2).
- Nepotism in selecting contractors for brownfield remediation, where firms with personal ties to project leadership are chosen over demonstrably more qualified/cheaper bidders, potentially inflating the €250M–€750M Phase 0 budget (Risk 9).
- Conflict of interest arising if personnel involved in negotiating fiber optic right-of-way easements (Decision 5/7) also hold undisclosed financial interests in the chosen terrestrial carriers or subsea landing point construction firms.
- Misuse of influence with RTE/EDF officials to secure preferential grid connection slots or more favorable capital contribution requirements for the 9 GW buildout, especially since grid capacity is treated as highly uncertain (Decision 1/9).
- Trading favors with regulatory bodies (e.g., DGSI/ANSSI) where accelerated validation of the sovereign AI partition (Decision 3) is exchanged for granting local authorities favorable terms in the Public Benefit/Heat Reuse agreements (Decision 6).

## Audit - Misallocation Risks

- Misallocation of Phase 1 CAPEX (up to €10B) towards premature investment in high-cost, dark fiber ownership (Decision 7) before the 60% tenant commitment threshold for Phase 2 is met, undermining liquidity for mandatory grid upgrade collateral.
- Budgetary overrun on land holding costs for the 80% buffer zone (128.8 km²), as the plan highlights this needs dedicated funding but lacks a firm cost estimate, potentially diverting funds from essential cybersecurity hardening (Risk 7/Assumption Issue 2).
- Inefficient allocation of technical resources toward meeting the ultra-aggressive PUE target of 1.15 in brownfield Phase 1, leading to material cost overruns on specialized liquid cooling systems when a PUE target of 1.20 (conservative approach) would suffice without violating tenant SLAs (Risk 2/Assumption Q4).
- Unauthorized utilization of Power Purchase Agreement (PPA) capacity intended for the *firmly contracted* 1 GW Phase 1 tranche for speculative customer testing or internal development, risking the binding RTE allocation for Phase 2 expansion (Risk 3).
- Misreporting of workforce integration progress: Paying prime contractors based on invoices claiming high local hiring percentages (Decision 8) without validation, leading to inflated community compensation funds or procurement of less skilled/more costly labor.

## Audit - Procedures

- Quarterly financial audit focusing on the split between EUR (local) and USD (hardware) expenditures, requiring reconciliation of the 70% FX hedge documentation against actual invoices for GPU/TPU procurement (Currency Strategy/Risk 4).
- Pre-FID Audit (Phase 1 Construction Financing): Verification that a binding RTE allocation contract for Phases 2/3 transmission *or* sufficient collateral provisions are formally documented *before* releasing construction capital, as per the Pragmatic Scale-Up strategy (Decision 1/Risk 3).
- Physical Segregation Audit (Bi-annually during Phase 1): On-site verification of physical and logical separation between the initial 500 MW-1 GW commercial cluster and the planned sovereign AI zones, checking substation demarcation and access controls mandated by DGSI protocols (Risk 5).
- Compliance Check on Infrastructure Contingency Budget (Post-Phase 0): Audit the ring-fenced budget allocated for land holding costs (128.8 km²) and Workforce Skill Uplift contingencies to ensure these technical/social buffers were not prematurely reallocated to core compute CAPEX (Review Issue 2/3).
- Land Use Verification (Annually): Independent survey mapping utilizing Geo-spatial analysis to confirm that the 80% reserved buffer acreage corresponds to the mandated ecological offsets and community integration spaces, cross-referenced against local permitting conditions (Decision 10/Risk 7).

## Audit - Transparency Measures

- Publicly accessible, delayed (30-day lag) financial dashboard displaying Phase 1 CAPEX burn rate, segregated by Land Acquisition, Grid Connection Fees (RTE payments), and Hardware Procurement (EUR/USD split).
- Formal publication of the Land Assembly Modality agreement (Decision 2) detailing which parcels are designated as 'Permanent Ecological Offset' versus 'Expansion Reserve,' verifiable by local authorities.
- Establish an independent Whistleblower Mechanism, managed by an external legal firm, specifically soliciting reports related to procurement favoring local suppliers or integrity breaches concerning environmental remediation contracts (Risk 9).
- Publish quarterly status reports detailing progress against Local Workforce Sourcing quotas (Decision 8), including the number of trainees enrolled in the skills academy and the percentage of non-specialized labor filled locally.
- Mandatory publication of the operational PUE and water usage metrics (per GW block) within 60 days of Phase 1 commissioning, allowing anchor tenants and regulators to verify performance against the 1.20 target.

# Internal Governance Bodies

### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** Required for high-level strategic decision-making, managing the extreme financial scale (€100B+) and the critical cross-domain dependencies (Grid, Land, Security). It must enforce the 'Pragmatic Scale-Up' strategy and sign off on all major deviation requests from the plan.

**Responsibilities:**

- Approve all Gate decisions (Phase 0 to 1, 1 to 2, etc.) based on satisfaction of strategic levers.
- Authorize capital expenditure variances exceeding 10% of the current phase budget or any unbudgeted obligation exceeding €500M.
- Provide ultimate arbitration for high-level cross-functional conflicts (e.g., Fiber vs. Power funding priority).
- Oversight of Risk Register, specifically for Critical Risks (Regulatory Delays, RTE Confirmation Failure, Social License Erosion).
- Approve major changes to the 9 GW target or the 161 km² conceptual footprint.

**Initial Setup Actions:**

- Finalize and approve the Project Charter and Governance Framework, including conflict resolution protocols.
- Appoint Chairperson (must be a senior sponsor outside the core delivery team).
- Establish the financial threshold for strategic versus operational decision authority (€500M).

**Membership:**

- Executive Sponsor (Chair)
- Chief Financial Officer (CFO)
- Chief Technology Officer (CTO)
- Head of Regulatory & Legal Affairs (Non-voting advisory)
- Independent External Governance Advisor (Voting member, focused on fiduciary duty)

**Decision Rights:** All strategic roadmap decisions, Gate Approvals (FID), budget allocations above €500M, and formal approval of revised major risk acceptance.

**Decision Mechanism:** Consensus required for Gate Approvals; Simple Majority for operational direction changes. Tie-breaker: The Executive Sponsor casts the deciding vote after mandatory 48-hour cooling-off period.

**Meeting Cadence:** Monthly, or immediately following critical external milestones (e.g., RTE consultation outcome).

**Typical Agenda Items:**

- Review of Phase Progress vs. Strategic Decision Matrix Execution
- Financial Burn Rate vs. Budgeted Tolerance (EUR/USD Split)
- Escalation Review: Issues deemed unresolvable by the Operational Management Group
- Audit Report Review (especially Compliance Check on Infrastructure Contingency Budget)

**Escalation Path:** External Shareholders / Board of Directors (for issues threatening project continuation or governance integrity).
### 2. Core Project Management Group (CPMG)

**Rationale for Inclusion:** This body manages the day-to-day execution of the 'Pragmatic Scale-Up' strategy. It is responsible for coordinating workstreams (Land, Grid Studies, Design) and making tactical decisions below the €500M strategic threshold, ensuring adherence to Phase 1 SMART criteria.

**Responsibilities:**

- Day-to-day management of the 3-year Phase 1 roadmap.
- Managing the interface between workstream leads (Design, Procurement, Regulatory Liaison).
- Detailed management of the €12.5M–€37.5M workforce/social license budget.
- Monitoring and enforcing the 1.20 PUE tolerance in detailed design and construction.
- Managing operational risk including cyber segregation checks (Risk 5).

**Initial Setup Actions:**

- Appoint Project Director (Chair of CPMG).
- Establish standardized reporting templates for all specialized workstreams (Land, Power, Security).
- Finalize resource allocation for the initial hyper-dense 32.2 km² buildable zone modeling.

**Membership:**

- Project Director (Chair)
- Lead Civil/Site Manager
- Lead Electrical/Grid Liaison Manager
- Head of Technology & Design (Liquid Cooling/PUE focus)
- Compliance & Security Coordinator (DGSI liaison)

**Decision Rights:** Operational decisions regarding cross-discipline resource allocation, tactical selection of vendors within approved procurement envelopes, approval of design changes up to 10% cost impact within a single workstream, and any decision under €500M.

**Decision Mechanism:** Simple majority vote. Decisions impacting multiple workstreams require documented alignment. Tie-breaker: Project Director's vote.

**Meeting Cadence:** Twice Weekly (Operational Synchronization); Weekly Detailed Progress Review.

**Typical Agenda Items:**

- Review of Remediation Progress vs. Budget (Risk 9)
- Status of RTE impact study submissions (pre-FID checkpoint)
- Progress against Local Workforce Quotas (Decision 8 implementation)
- Technical Review: Liquid Cooling performance parameters and integration milestones.

**Escalation Path:** Project Steering Committee (PSC) for any decision involving schedule delay risks exceeding 3 months, or budget triggers exceeding 10% of the active Phase 1 budget tranche.
### 3. Regulatory & Compliance Assurance Board (RCAB)

**Rationale for Inclusion:** Given the critical reliance on French permitting, DGSI/ANSSI alignment (Decision 3), and managing high legal/reputational risk associated with land assembly (Decision 2, 10) and corruption (Audit Risks), a dedicated, independent assurance body is necessary to ensure compliance is proactive, not reactive.

**Responsibilities:**

- Conduct mandatory compliance checks against DGSI/ANSSI protocols prior to Phase 1 construction FID.
- Oversee the integrity of land assembly documentation (confirming 80% buffer zoning integrity per Decision 10).
- Manage the independent Whistleblower Mechanism and oversee anti-corruption audits.
- Vetting all contracts related to brownfield remediation to prevent misallocation risk (Audit Risk 9).
- Formal sign-off on the physical/logical separation of Phase 1 commercial zone from future sovereign zones (Risk 5).

**Initial Setup Actions:**

- Retain independent external counsel specializing in French ICPE/Regulatory law.
- Establish the formal communication protocol matrix for DGSI engagement.
- Mandate the first Physical Segregation Audit schedule (bi-annual).

**Membership:**

- Head of Legal & Compliance (Chair)
- Designated DGSI Liaison Officer (Internal Security)
- External Integrity & Audit Partner (Independent)
- Environmental Compliance Specialist (External)

**Decision Rights:** Authority to halt specific workstreams (e.g., foundation pours, substation construction) pending certification of compliance with French law or security protocols. Veto power over the release of funds designated for community compensation until verified delivery (Decision 8).

**Decision Mechanism:** Unanimous agreement required for issuing 'Stop Work' or 'No-Go' advisory to the PSC on compliance matters. All other decisions require a 2/3 majority vote.

**Meeting Cadence:** Bi-monthly during Phase 0/1; Quarterly thereafter.

**Typical Agenda Items:**

- Review of DGSI Status against Security Partitioning Milestones
- Status of Permanent Ecological Offset Verification (Land Use Audit)
- Review of Whistleblower/Conflict of Interest Registry
- Compliance Checklist sign-off for next major capital release.

**Escalation Path:** Project Steering Committee (PSC) if a compliance deadlock stalls the project timeline by more than 4 weeks.

# Governance Implementation Plan

### 1. Project Sponsor formally authorizes the immediate initiation of Phase 0 activities, including the establishment of the Governance Framework and the appointment of the Formation Lead.

**Responsible Body/Role:** Executive Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Formal Project Initiation Mandate
- Designation of Project Director (CPMG Chair)
- Appointment of Interim Setup Lead (for initial drafting)

**Dependencies:**

- Project Charter Finalized (Implied from Input)

### 2. Interim Setup Lead drafts initial Terms of Reference (ToR) documents for the Project Steering Committee (PSC), Core Project Management Group (CPMG), and Regulatory & Compliance Assurance Board (RCAB), incorporating strategic decisions made (Pragmatic Scale-Up strategy).

**Responsible Body/Role:** Interim Setup Lead

**Suggested Timeframe:** Project Week 1-2

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1
- Draft CPMG ToR v0.1
- Draft RCAB ToR v0.1

**Dependencies:**

- Formal Project Initiation Mandate

### 3. Interim Setup Lead circulates draft ToRs for initial high-level review focusing on decision rights, thresholds (€500M), and membership composition.

**Responsible Body/Role:** Interim Setup Lead

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Stakeholder Feedback Summary on ToRs
- Updated Draft ToRs (v0.2)

**Dependencies:**

- Draft PSC ToR v0.1
- Draft CPMG ToR v0.1
- Draft RCAB ToR v0.1

### 4. Executive Sponsor officially appoints the Chair, CFO, CTO, and External Advisor for the Project Steering Committee (PSC).

**Responsible Body/Role:** Executive Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Formal PSC Membership Confirmation
- PSC Chair Appointment Notification

**Dependencies:**

- Updated Draft ToRs (v0.2)

### 5. The Executive Sponsor, utilizing nominations from the newly confirmed PSC, formally approves the final PSC ToR and establishes the definitive governance framework.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Approved Governance Framework Document
- Final PSC ToR (v1.0)

**Dependencies:**

- Formal PSC Membership Confirmation

### 6. Project Director (CPMG Chair) is appointed by the PSC, and the PSC confirms the initial setup actions for CPMG and RCAB.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Project Director Appointment Confirmation
- Final CPMG and RCAB ToR Approval

**Dependencies:**

- Approved Governance Framework Document

### 7. The Project Director (CPMG Chair) finalizes the detailed membership selection for the CPMG and RCAB based on ToR requirements and initiates rapid recruitment/nomination for external expert roles.

**Responsible Body/Role:** Project Director (CPMG Chair)

**Suggested Timeframe:** Project Week 6-8

**Key Outputs/Deliverables:**

- CPMG Membership Confirmation
- RCAB Membership Confirmation (including external counsel retention)

**Dependencies:**

- Project Director Appointment Confirmation

### 8. Hold the inaugural Kick-off Meeting for the Core Project Management Group (CPMG) to align on Phase 1 SMART criteria, Phase 0 deliverables, and establish tactical reporting rhythms.

**Responsible Body/Role:** Core Project Management Group (CPMG)

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- CPMG Kick-off Meeting Minutes
- Initial Phase 0 Workstream Allocation Register

**Dependencies:**

- CPMG Membership Confirmation
- Final CPMG ToR Approval

### 9. Hold the inaugural Meeting for the Regulatory & Compliance Assurance Board (RCAB). RCAB prioritizes establishing the DGSI communication protocol and finalizing the land boundary verification plan accounting for the 80% buffer zone.

**Responsible Body/Role:** Regulatory & Compliance Assurance Board (RCAB)

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- RCAB Kick-off Minutes
- DGSI Communication Protocol Matrix
- Land Integrity Audit Plan (Decision 10 mitigation)

**Dependencies:**

- RCAB Membership Confirmation
- Final RCAB ToR Approval

### 10. Hold the Inaugural Project Steering Committee (PSC) meeting. PSC formally ratifies the establishment of CPMG and RCAB, reviews Phase 0 status against Strategic Decision Matrix, and approves the initial Risk Register prioritization.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- PSC Inaugural Meeting Minutes & Ratification of Operational Bodies
- Approved Prioritized Risk Register

**Dependencies:**

- CPMG Kick-off Meeting Minutes
- RCAB Kick-off Minutes

### 11. CPMG initiates detailed modeling for the hyper-dense 32.2 km² buildable area and commits initial budget for securing preliminary Right-of-Way (ROW) easements crucial for future high-voltage transmission tie-lines (Decision 1 Linkage).

**Responsible Body/Role:** Core Project Management Group (CPMG)

**Suggested Timeframe:** Project Month 3

**Key Outputs/Deliverables:**

- Hyper-Dense Footprint Model v1.0
- ROW Application Submissions for Phase 2 Connection Points

**Dependencies:**

- Approved Prioritized Risk Register
- Assumptions Q8 Implementation Start

### 12. RCAB conducts the first mandatory Internal Security/Compliance Checkpoint, focusing specifically on the physical segregation plan for the Phase 1 500 MW commercial load relative to future sovereign zone requirements (Risk 5 mitigation).

**Responsible Body/Role:** Regulatory & Compliance Assurance Board (RCAB)

**Suggested Timeframe:** Project Month 4

**Key Outputs/Deliverables:**

- Security Separation Compliance Report v1.0
- Formal Go/No-Go Recommendation for Phase 1 Construction Start (Technical/Security Layer)

**Dependencies:**

- Lead Electrical/Grid Liaison Manager delivers initial substation demarcation plan

### 13. PSC reviews the Security Separation Report and either grants authority to commence main land remediation and grid connection feasibility studies, or mandates remediation based on RCAB findings.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Month 5

**Key Outputs/Deliverables:**

- Phase 1 Construction Start Authorization (Subject to Power/Tenant Gates)

**Dependencies:**

- Security Separation Compliance Report v1.0
- CPMG Report on Holding Cost Budget Allocation (Review Issue 2)

# Decision Escalation Matrix

**Budget Contingency Triggered for Land Holding Costs**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC review of budget variance (Review Issue 2), requiring consensus authorization for accessing the Capital Contingency Line item exceeding €500M.
Rationale: The cost of holding the 80% land buffer (a core element of the chosen pragmatic strategy) is unbudgeted. Expenditure exceeding the CPMG's operational limit (€500M tolerance) requires strategic sign-off.
Negative Consequences: Failure to approve budget leads to legal challenges or abandonment of reserved land crucial for future expansion flexibility, potentially constraining the 9 GW vision.

**RTE Refusal for Binding Phase 2 Transmission Allocation**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Mandatory immediate escalation from CPMG to PSC (as this confirms Critical Risk 3). PSC must decide whether to secure capacity via Risk Strategy Choice 1 (front-loading capital) or formally recalibrate the 9 GW timeline/scope.
Rationale: RTE's decision directly determines the viability of scaling beyond 1 GW within the 15-year timeframe and dictates the long-lead time for critical grid infrastructure (Risk 3). This exceeds CPMG tactical management.
Negative Consequences: Project schedule stalls indefinitely post-Phase 1 completion, potentially stranding Phase 1 capital if tenants withdraw due to lack of future expansion confidence.

**RCAB Veto on Phase 1 Construction Start due to Security Isolation Failure**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC must adjudicate the RCAB veto, which requires unanimous agreement from RCAB to halt work. The PSC Chair casts the tie-breaker vote after requiring a mandatory 48-hour cooling-off period.
Rationale: RCAB has explicit veto power over workstream commencement related to the security demarcation between commercial and sovereign zones (Risk 5). A veto halts critical path construction.
Negative Consequences: A multi-month delay to the Physical Segregation Audit introduces high risk of missing the 3-year Phase 1 completion target, jeopardizing tenant FID timelines.

**Proposal to Pivot from Hyper-Dense Model to Split-Campus Model**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Requires a formal recommendation from the CPMG, supported by technical verification that the 2ms RTT latency requirement can be met between clusters (Assumptions Q6), followed by a Simple Majority vote at the PSC.
Rationale: This constitutes a major change to the physical footprint rationalization strategy (Decision 2/Land Assembly Modality), impacting security perimeter design, internal logistics, and overall CAPEX estimates significantly.
Negative Consequences: Failure to achieve 2ms RTT renders the new model infeasible for core AI workloads, requiring re-design of the entire connectivity plan and potentially increasing USD hardware exposure volatility.

**Negotiated PPA terms include an EDF price structure deemed unhedgable against the Decision 4 (60% Tenant Threshold)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: CFO presents the financial impact analysis to the PSC. Approval requires a consensus decision to either accept the unhedgable risk, or use committed tenant revenue leverage to demand renegotiation with EDF/RTE.
Rationale: Power Procurement Sequencing (Decision 9) interacts directly with Tenant Acquisition Thresholds (Decision 4). If the cost structure of power contradicts the financial prudence mandated by revenue triggers, the PSC must intervene above the CPMG's financial authorization level.
Negative Consequences: Committing to a PPAs that locks in high operational costs jeopardizes the project's competitive position, potentially violating financial covenants linked to the expected ROI profile.

# Monitoring Progress

### 1. Tracking Critical Success Milestones via Phase Gates
**Monitoring Tools/Platforms:**

  - Project Steering Committee (PSC) Decision Log
  - Project Plan v1.0 Roadmap Tracking Dashboard
  - Phase Gate Acceptance Checklists

**Frequency:** Post-Milestone / Quarterly Review

**Responsible Role:** Project Steering Committee (PSC)

**Adaptation Process:** If a Phase Gate (e.g., Phase 1 FID) conditions are not met, the PSC initiates a formal reassessment, potentially triggering the 'kill criteria' or recommending a scope reduction plan to the Executive Sponsor/Board.

**Adaptation Trigger:** Failure to satisfy all required conditions, including power confirmation and 60% tenant commitment threshold, for progression to the next Phase (e.g., Phase 2 expansion FID).

### 2. Monitoring Grid Integration Certainty (Critical Risk 3)
**Monitoring Tools/Platforms:**

  - RTE/EDF Correspondence Log
  - Electrical/Grid Liaison Manager Weekly Status Report
  - Power Procurement Sequencing Compliance Tracker

**Frequency:** Weekly (Phase 0/1); Bi-weekly (Pre-Phase 2 FID)

**Responsible Role:** Core Project Management Group (CPMG) / Lead Electrical Manager

**Adaptation Process:** If RTE engagement indicates delays beyond the 36-month assumed buffer (Review Issue 1), the CPMG escalates immediately to the PSC to negotiate a binding amendment to the Tenant Acquisition Trigger Threshold (Decision 4) via a 'Power Readiness Lockout Clause'.

**Adaptation Trigger:** Any official communication from RTE signaling a delay in transmission impact study completion or confirming a grid upgrade timeline exceeding 36 months post-Phase 2 FID.

### 3. Tracking Sovereign AI Alignment and Security Isolation (Critical Risk 5)
**Monitoring Tools/Platforms:**

  - Security Separation Compliance Report v1.0 (from RCAB)
  - DGSI/ANSSI Communication Matrix
  - Physical Segregation Audit Schedule

**Frequency:** Bi-monthly (via RCAB)

**Responsible Role:** Regulatory & Compliance Assurance Board (RCAB)

**Adaptation Process:** If RCAB issues a 'No-Go' advisory due to inadequate physical isolation of the first 500 MW load, the CPMG must halt all related physical construction until remediation is certified. Failure to resolve within 4 weeks mandates escalation to the PSC (as per Escalation Matrix).

**Adaptation Trigger:** Negative finding on the Security Separation Compliance Report (v1.0 or subsequent audits) or failure to receive required protocol sign-off from DGSI by specified checkpoint dates.

### 4. Land Control and Buffer Zone Integrity Monitoring
**Monitoring Tools/Platforms:**

  - Land Integrity Audit Plan Report (RCAB)
  - ROW Application Status Tracker
  - Quarterly Land Holding Cost Reconciliation Statement

**Frequency:** Quarterly

**Responsible Role:** Regulatory & Compliance Assurance Board (RCAB)

**Adaptation Process:** If Land Holding Costs exceed the budgeted contingency, the CPMG must present a plan to the PSC to reclassify 50% of the 'Permanent Ecological Offset' buffer to 'Phase 2/3 Expansion Reserve' status to reduce ongoing holding expenses (Review Issue 2).

**Adaptation Trigger:** Quarterly reconciliation shows holding costs exceeding 15% cumulative variance, or if a local judicial challenge targets the legal designation of the permanent buffer zones.

### 5. Tenant Commitment Monitoring (Decision 4)
**Monitoring Tools/Platforms:**

  - Contract Status Tracker (Take-or-Pay Commitments)
  - Financial Modeling Dashboard (Leveraging committed revenue for debt structuring)

**Frequency:** Monthly

**Responsible Role:** CFO / Project Steering Committee (PSC)

**Adaptation Process:** If committed take-or-pay revenue falls below 40% of the next tranche's required anchor (60% threshold), the PSC must formally suspend all financing activities related to Phase 2 infrastructure (e.g., grid link advancement) and initiate renegotiation efforts with existing anchor tenants to raise commitment levels.

**Adaptation Trigger:** Tenant commitment percentage falls below the 60% threshold required for Phase 2 expansion FID, or if existing tenants provide notice of withdrawal.

### 6. Workforce Uplift & Social License Performance Check
**Monitoring Tools/Platforms:**

  - Local Workforce Quota Report (CPMG)
  - Skills Academy Enrollment & Certification Log
  - Heat Reuse Feasibility Study Progress Report

**Frequency:** Monthly

**Responsible Role:** Core Project Management Group (CPMG) / Compliance Coordinator

**Adaptation Process:** If actual local specialty hire rates lag behind the planned velocity (e.g., <30% specialty hires in Year 1, Review Issue 3), the CPMG must immediately draw down the dedicated workforce contingency budget (€20M-€40M) to hire short-term specialized management teams to oversee local training.

**Adaptation Trigger:** Failure to meet quarterly targets for required local apprentice enrollment or securing the first binding Heat Reuse off-take agreement.

# Governance Extra

## Governance Validation Checks

1. Completeness Confirmation: All major requested components (Bodies, Implementation Plan, Escalation Matrix, Monitoring Plan) appear to be generated.
2. Internal Consistency Check: The framework is highly consistent; the 'Pragmatic Scale-Up' strategy dictated the conservative nature of the governance (e.g., soft power commitment for Phase 1) and is enforced in the bodies' responsibilities (PSC enforces Gate Approvals) and the Monitoring Plan (Gate tracking). The RCAB's focus on land integrity directly reflects the critical risk identified around the 80% buffer zone.
3. Potential Gaps / Areas for Enhancement 1: The role and authority of the 'Independent External Governance Advisor' on the PSC are listed as 'Voting member, focused on fiduciary duty,' but their specific mechanism for raising dissenting fiduciary warnings outside of the standard vote (e.g., reporting directly to shareholders on ethical concerns) is unclear.
4. Potential Gaps / Areas for Enhancement 2: The implementation plan (Stage 3) focuses heavily on setup (Weeks 1-12). There is insufficient detail on the *ongoing* process for how the CPMG reports findings/variances from the complex technical models (PUE, Water, Inter-Cluster Latency) *into* the RCAB for specialized assurance review.
5. Potential Gaps / Areas for Enhancement 3: Decision thresholds are defined (e.g., PSC decision limit €500M), but the process for **delegation of authority below the CPMG** (e.g., to site managers or procurement leads) for routine, low-impact decisions that would otherwise clog the CPMG cycle is missing.
6. Potential Gaps / Areas for Enhancement 4: The accountability for tracking and executing the formal FX hedging strategy (USD exposure) is implied within the Finance function (CFO on PSC/CPMG) but does not have a dedicated tracking role or explicit checkpoint within the RCAB or CPMG routines, despite being a Critical Risk (Risk 4).
7. Potential Gaps / Areas for Enhancement 5: While Decision 10 requires defining buffer land usage (Permanent Offset vs. Expansion Reserve), the mechanism for the *annual reassessment* of the Expansion Reserve flexibility, particularly how the PSC authorizes a shift away from 'Permanent' status, lacks a specific trigger or explicit review step in the Monitoring Plan.

## Tough Questions

1. What is the specific, contractually defined mechanism and timeline (in months) required for RTE to confirm the binding 3 GW transmission allocation *after* Phase 2 FID is triggered by the 60% tenant commitment (Decision 4)? Does the 36-month buffer assumption (Review Issue 1) incorporate regulatory grace periods, and if so, where is this validated internally?
2. Given the 'hyper-dense' model mandates 80% of the 161 km² as buffers, what is the audited, year-on-year holding cost for the 128.8 km² of land, and what specific line item in the budget (Phase 0/1 CAPEX) is strictly ring-fenced to cover this cost, distinct from remediation or compute CAPEX, referencing Assumption Issue 2?
3. What are the documented, legally binding 'kill criteria' referenced in the Monitoring Plan? Specifically, if the DGSI veto (Escalation Matrix) or a PUE failure (>1.25) occurs, what is the maximum allowable remediation timeline before the PSC must trigger project cancellation or radical downsizing (as allowed by the 'red-team' mandate)?
4. The RCAB has veto power over construction start based on security isolation. Detail the exact demarcation point (e.g., physical fencing breach, substation breaker status) that constitutes a failure under Risk 5, and quantify the financial penalty or schedule slip incurred for every week construction is halted awaiting RCAB sign-off.
5. Since Phase 1 relies on non-binding consultation for power, what specific collateral funds (EUR amount) have been legally ring-fenced and documented as available to meet RTE’s potential capital contribution request should RTE mandate upfront funding triggers contradicting the 'No Grid Pre-Commitment' posture (Decision 9)?
6. To validate the 60% tenant commitment threshold (Decision 4), provide the legal structure of the required 'take-or-pay' contracts. Are they subject to standard force majeure provisions, or do they contain specific, punitive clauses if the *developer* fails to deliver capacity due to unanticipated French regulatory delays (e.g., RTE or permit stalls)?
7. How does the CPMG ensure the integrity of the aggressive local workforce uplift (Decision 8) without inflating the PUE ceiling of 1.20 due to inexperienced labor managing complex liquid cooling systems? Provide the variance tolerance in management overhead cost budgeted to mitigate this velocity risk (Assumption Issue 3) versus the cost of importing skilled oversight.

## Summary

The governance framework implements a robust, risk-averse 'Pragmatic Scale-Up' methodology, effectively enforcing skepticism by linking major expansions to binding external validations (power commitments) and high tenant revenue hurdles (60% threshold). Key strengths lie in the clear separation of strategic oversight (PSC) and dedicated compliance assurance (RCAB), directly addressing the high regulatory and security risks inherent in the 9 GW French deployment. However, the framework remains heavily exposed to external timelines, particularly RTE lead times and the cost/viability of the massive planned land buffers, necessitating immediate quantification of regulatory buffers and land holding costs.

# Related Resources

## Suggestion 1 - Google Bertelsmann Data Center Campus (Eemshaven, Netherlands)

Google established a massive data center presence in the Eemshaven region of the Netherlands, an area already designated as a key European digital hub. The cluster scaled significantly, requiring multi-stage power procurement and integration with the Dutch grid operator (TenneT). Initial phases involved several hundred megawatts, later scaling up into the multi-gigawatt range, utilizing sophisticated, dense computing modules adapted to the challenging North Sea coastal climate. This project involved intense negotiation over grid impact, land use, and compliance with national energy regulations.

### Success Metrics

Successfully absorbed multi-hundred MW power load into the constrained TenneT grid structure across multiple phases.
Achieved operational efficiencies mirroring hyperscale PUE targets through advanced cooling deployments.
Established a significant, long-term digital infrastructure presence in Northern Europe, attracting ancillary technology investment to the region.
Managed long-term land/power agreements across several years of buildout.

### Risks and Challenges Faced

Grid Connection Bottlenecks: The sheer scale of power requests strained local grid capacity, necessitating complex, multi-year substation and transmission upgrades funded partly by the developer and partly by TenneT.
Cooling Constraints: Dealing with high humidity and coastal exposure required engineering solutions that optimized for cooling efficiency against environmental conditions similar to Hauts-de-France.
Community Perception: Managing the influx of large-scale industrial development in a previously less industrialized zone required proactive community engagement regarding energy use and local impact.

### Where to Find More Information

TenneT Annual Reports: Look for sections detailing interconnection agreements in the Groningen/Eemshaven area (Search: 'TenneT Eemshaven interconnection').
Local Dutch Government Planning Documents (Groningen Province): Search for large-scale industrial zoning changes related to ICT infrastructure post-2015.
European Data Center Industry Reports (e.g., CBRE, Cushman & Wakefield) focusing on Northern European capacity expansion.

### Actionable Steps

Contact TenneT's Grid Planning Department (specifically regional planning leads for the Netherlands North region) via their official inquiry portal to understand their process for multi-stage power allocation for phased developments exceeding 3 GW.
Search LinkedIn for former or current Project Managers/Director of Energy at Google EMEA Data Centers who worked on the Eemshaven expansion starting around 2016-2018, focusing on individuals who handled grid integration and permitting.
Review procurement notices published by Google or major German/Dutch EPC firms specializing in hyperscale infrastructure in the region for technical specifications relating to power transmission interfaces.

### Rationale for Suggestion

This is the most direct analogue for the power and grid challenge in a geographically proximate, high-density European market. It proves the feasibility of integrating multi-GW loads into an established, yet constrained, high-reliability European grid, mirroring the core tension between RTE/EDF dependency and timeline acceleration.
## Suggestion 2 - Microsoft / Facebook (Meta) Data Center Campus, Luleå, Sweden

Hyperscale AI/cloud compute campus established in Northern Sweden, leveraging extremely cold ambient temperatures for cooling efficiency and access to massive, low-carbon hydropower (Vattenfall). This project involved pioneering the deployment of advanced liquid cooling systems (though often utilizing less advanced cooling than the proposed 1.15 PUE target) and establishing an entirely new long-distance, resilient fiber connection to Stockholm/Europe through challenging terrain.

### Success Metrics

Achievement of extremely low PUE metrics, validating the use of liquid cooling principles in a multi-year deployment cycle.
Successful construction and commissioning of several large data halls (some exceeding 100,000 m²), providing lessons in logistics for large building models.
Establishment of verifiable long-haul, low-latency fiber connectivity across hundreds of kilometers to major terrestrial exchange points.
Successful negotiation of long-term Power Purchase Agreements (PPAs) guaranteeing low-cost, *firm* power independent of immediate grid volatility.

### Risks and Challenges Faced

Remote Logistics and Local Workforce: Assembling the necessary specialized construction workforce and materials in a remote Swedish location required significant logistical investment, an analogue to the 'Workforce Sourcing' challenge in Hauts-de-France.
Fiber Route Selection and Resilience: Securing diverse, high-throughput terrestrial routes over long distances presented major right-of-way and cost challenges, similar to the dependency highlighted in Decision 5.
Initial Heat Rejection: Integrating heat rejection systems to meet stringent environmental standards while managing unique cold-weather effects on cooling loops.

### Where to Find More Information

Vattenfall Corporate Sustainability Reports: Detail the partnership structure and long-term PPA agreements for the Luleå site.
Academic Papers/Case Studies on Hyperscale Liquid Cooling Implementation (Search: 'Luleå data center cooling PUE study').
Finnish/Swedish Infrastructure Agency Reports for fiber route deployment lessons.

### Actionable Steps

Contact Microsoft's Global Real Estate and Supply Chain teams managing the Luleå expansion, specifically seeking input on how they managed local skilled labor mobilization (Decision 8) and managed USD/EUR hardware exposure.
Engage with Vattenfall’s B2B energy solutions division to understand the contractual mechanisms used to ensure power firmness for a 3 GW-scale user.
Review vendor specifications for the large-scale thermal rejection equipment used, noting details on pipe sizing and standardization that could inform the 9 GW cooling loops.

### Rationale for Suggestion

This project is essential for benchmarking the technical feasibility of the cooling strategy (liquid cooling, PUE 1.15) and provides critical data on managing ultra-long-lead logistics and workforce mobilization in a challenging European industrial zone, directly informing the physical build model for the proposed 100+ halls.
## Suggestion 3 - The Cœur de l'Europe Digital Hub Initiative (Poche Sud-Ouest) - French Regional Example

Although this is a broader regional initiative rather than a single campus, projects within the 'Cœur de l'Europe' strategy (like those supported by the South-West of France or the Lyon area industrial clusters) showcase the standard French *process* for securing large-scale energy and regulatory backing outside of Paris. These projects typically involve complex negotiations with RTE for grid upgrades tied to regional industrial revival plans, often utilizing the 'Projet d'Intérêt Général' (PIG) mechanism mentioned in the risk register (Risk 1). These often involve power capacities in the 1 GW to 3 GW range, necessary for domestic industrial players.

### Success Metrics

Successful alignment of regional industrial strategy with national energy infrastructure planning (RTE/DGEC).
Demonstration of the PIG mechanism successfully accelerating necessary transmission line construction/substation upgrades for large industrial consumers (>1 GW).
Establishment of predictable permitting timelines by formalizing public benefit commitments (e.g., heat reuse or specific employment targets) early in Phase 0.

### Risks and Challenges Faced

Perceived Centralization Risk: Local resistance arises when national priorities (like hyper-scale DC) appear to overshadow local community needs, mirroring the 'Social License' risk (Risk 7).
Slower Initial Velocity: The reliance on formal PIG status and comprehensive DREAL studies often results in a 2-3 year lead time before site mobilization, reinforcing the strategic need for aggressive Phase 0 planning.
Inter-Regional Power Balancing: Coordinating power capacity across multiple *Régions* (e.g., Hauts-de-France interfacing with grid control centers responsible for Paris or other consumption zones).

### Where to Find More Information

The official portal for the French Government's 'France 2030' Industrial Strategy investment tracking, specifically looking at data center or energy sector co-investments in the North/East.
Publicly available pre-Feasibility Studies (Études de Faisabilité) published by DREAL Hauts-de-France for recent large-scale industrial permits (>100 MW).
Reports from the 'Commission de Régulation de l'Énergie' (CRE) regarding transmission network investment plans for Northern France.

### Actionable Steps

Identify the named Prefectural Lead or the 'Chargé de Mission' responsible for the high-profile industrial re-zoning efforts in the Northern French corridors (Cambrai/Dunkirk) within the last three years.
Contact the project management office (PMO) responsible for the most recent 2 GW interconnection delivered to a major industrial consumer in Hauts-de-France to map their exact interaction sequence with RTE and DGSI.
Review the structure of Public Benefit Deeds (Conventions de Servitude) signed by similar projects to understand the typical commitment levels used to secure land assembly velocity.

### Rationale for Suggestion

Given the project's location, the primary constraint is French regulatory friction. This suggestion directs the user toward real-world French governmental mapping and procedural precedents, demonstrating how similar large-scale power consumers successfully negotiated the precise regulatory traps outlined in the plan (RTE, DGSI, DREAL, PIG status).

## Summary

The project requires precedents for executing multi-billion EUR, multi-decade infrastructure spanning energy grid integration, massive land assembly in brownfield settings, and deployment of hyperscale AI compute infrastructure under stringent EU regulatory oversight (DGSI/ANSSI). The suggested projects focus on verifiable, regulated hyperscale deployments in Northern Europe that navigated complex power procurement and community integration hurdles.

# Data Collection

## 1. RTE Grid Upgrade Timeline & Collateral Requirement

This data directly validates the critical path dependency identified in Risk 3 and Review Issue 1. Deferring Phase 2 funding until 60% tenant commitment (Pragmatic Scale-Up) is infeasible if RTE requires an excessively long lead time (>36 months) for infrastructure completion, risking stranded capacity.

### Data to Collect

- Exact timeline (months) for RTE transmission upgrade completion following financial commitment for 3 GW capacity.
- Required financial collateral amount (EUR) demanded by RTE for Phase 2 (3 GW) grid interconnection initiation.
- Binding PPA template structure for capacity allocation post-Phase 1 FID.

### Simulation Steps

- Use PowerFactory/PSSE to model the 9 GW load injection profile onto the RTE network segments impacting Hauts-de-France.
- Develop a spreadsheet model applying the known French cost-per-MW metrics for substation upgrades (based on Suggestion 3 findings) to estimate collateral requirements as a function of required lead time.

### Expert Validation Steps

- Consult the European Energy Regulation Specialist (RTE/PPA expert) to calibrate the required collateral quantum and the minimum mandated timeline for RTE infrastructure completion post-funding.
- Request timeline confirmation data from the Land Use and Environmental Lawyer's network regarding average political/legal buffer applied to DREAL-approved grid infrastructure projects.

### Responsible Parties

- Grid & Power Procurement Specialist (IC)
- Chief Infrastructure Strategist & Project Architect (FTE)

### Assumptions

- **High:** RTE requires a minimum of 36 months for network upgrade completion after Phase 2 funding commitment is secured.
- **Medium:** The initial pre-paid hosting fee for Phase 1 (500MW) will accelerate the RTE planning process without influencing the longer-term 3 GW readiness timeline.

### SMART Validation Objective

Obtain formally documented range estimates (in months) for RTE transmission upgrade completion for 3 GW post-FID from the European Energy Regulation Specialist by 2026-11-01.

### Notes

- Focus on locking down the Phase 2 FID dependency rigorously against the validated power readiness timeline.


## 2. Land Holding Cost & Legal Structuring for Buffer Zones

Review Issue 2 highlighted that the holding cost for the 80% buffer is unbudgeted, posing a critical CAPEX risk (€1.3B+ overrun). This data is essential to integrate this strategic concession into the Phase 1 budget.

### Data to Collect

- Annual holding cost per hectare (EUR/ha/year) for non-buildable industrial/agricultural land in the Dunkirk/Cambrai zones (for 128.8 km²).
- Legal documentation requirements (e.g., specific deeds/clauses) for establishing a 30% 'Permanent Ecological Offset' under French law.
- Standard lease/easement costs for the 50% 'Expansion Reserve' area for an initial 18-month commitment period.

### Simulation Steps

- Use GIS/CAD software (managed by Land Modeler) to calculate the specific acreage breakdown for 32.2 km² buildable, 38.6 km² permanent offset, and 90.2 km² 18-month reserve.
- Model the cumulative 18-month holding cost based on interpolated local tax rates and maintenance estimates for 128.8 km².

### Expert Validation Steps

- Consult the French Land Use and Environmental Lawyer to validate the proposed legal structure for the 30% permanent offset and the viability/cost of the 18-month renewal option for the reserve area.
- Engage the Socio-Economic Impact Assessor to benchmark the proposed buffer holding costs against regional development incentive frameworks.

### Responsible Parties

- Large-Scale Land & Civil Works Model Modeler (IC)
- Financial Controller & Currency Risk Manager (FTE)

### Assumptions

- **High:** The modeled average holding cost per hectare is accurate within a 10% margin of the actual cadastral charges levied by local communes.
- **High:** A 30% permanent ecological offset is legally sufficient to preempt most land-use judicial challenges against the hyper-dense model.

### SMART Validation Objective

Formalize a binding 18-month operating budget line item for the 128.8 km² land holding costs, validated by the Land Use Lawyer, by 2026-09-01.

### Notes

- This directly addresses the critical financial risk associated with the hyper-dense land strategy.


## 3. DGSI/ANSSI Security Isolation Protocol Definition

Risk 5 highlights that failure to secure early security alignment jeopardizes access to premium sovereign revenues. Data collection must define the explicit boundary conditions for the initial commercial leasing (Decision 3, Choice 1).

### Data to Collect

- Formal document outlining DGSI/ANSSI requirements for physical and logical separation between non-classified commercial compute (Phase 1) and the future sovereign AI partition.
- Timeline (in months) for DGSI review of initial Proof-of-Concept security architecture for the 500 MW isolation.
- Definition of 'non-classified hardware' acceptable for immediate Phase 1 deployment.

### Simulation Steps

- N/A - This is primary regulatory documentation retrieval.
- Map the logical flow of substation capacity (Substation 1 isolation) against the DGSI security demarcation points within the BIM/Digital Twin model (managed by Chief Architect).

### Expert Validation Steps

- Consult the EU Sovereign AI & Cyber Security Policy Advisor to interpret the DGSI documentation and review the project's proposed physical isolation schematics for acceptance.
- Regulatory & Sovereignty Compliance Lead to arrange a formal Phase 0 architecture review meeting with DGSI.

### Responsible Parties

- Regulatory & Sovereignty Compliance Lead (FTE)
- Chief Infrastructure Strategist & Project Architect (FTE)

### Assumptions

- **Medium:** The DGSI/ANSSI review process for the initial 500 MW isolation concept can be completed within 10 months, concurrent with Phase 1 construction.
- **Medium:** The initial 500 MW hardware procurement (Risk 7) can be sourced without requiring specialized, nationally approved accelerators, allowing immediate revenue capture.

### SMART Validation Objective

Secure a written DGSI confirmation that the proposed physical segregation plan for Phase 1 (500 MW) meets the minimum standard required to *avoid* retrofitting when the sovereign zone is eventually built, by Q1 2027.

### Notes

- This is a high-stakes compliance gate that must inform tenant leasing terms.


## 4. Phase 1 Workforce Skill Uplift Velocity & Contractor Resistance

Review Issue 3 identified workforce optimism as a source of 6-12 month delays. Validating the realistic speed of skills development and contractor acceptance of the 75% mandate is necessary to accurately forecast Phase 1 completion date (Goal Statement constraint: 3 years).

### Data to Collect

- Average lead time (months) for local technical schools in Hauts-de-France to certify a new apprentice cohort capable of specialized construction work (e.g., piping for liquid cooling).
- Standard contract clauses used by EPC firms in the region regarding local hiring mandates (75% quota) and associated penalty/premium rates for compliance.
- Budgetary cost associated with importing specialized, non-local management/QC teams to oversee local training (Contingency budget input).

### Simulation Steps

- Modeling scheduling impact: Apply the estimated skill generation latency (if >6 months) to the Phase 1 construction schedule to quantify potential delay to 1 GW COD.
- Use cost modeling software to integrate premium/penalty costs from EPC resistance into the overall Phase 1 construction budget.

### Expert Validation Steps

- Consult the Socio-Economic Impact Assessor to confirm realistic velocity for local skills development and job integration.
- Consult the Program Director - Construction & Logistics (to be hired/assigned) to gauge typical EPC resistance levels to such strong local hiring mandates.
- Consult the Social License & Community Benefits Orchestrator regarding negotiated apprenticeship rates.

### Responsible Parties

- Social License & Community Benefits Orchestrator (IC)
- Chief Infrastructure Strategist & Project Architect (FTE)

### Assumptions

- **Medium:** The required 75% local hiring mandate will incur an average 5% premium on civil construction costs due to management overhead or contractor surcharge.
- **High:** Local technical schools can provide sufficient initial supervisors/trainers within 12 months to support the ramp-up.

### SMART Validation Objective

Establish a validated, 12-month phased local hiring roadmap, acceptable to contracted EPC partners (or resulting in finalized premium costs), by Q4 2026.

### Notes

- This data updates the strategic decision on workforce vs. speed trade-off.

## Summary

Immediate prioritization must focus on locking down the external timeline constraints that dictate Phase 1 feasibility and 9 GW optionality. The most critical data collection tasks are validating the RTE upgrade lead time (Data Item 1) and fully budgeting the land holding costs associated with the chosen 80% buffer strategy (Data Item 2), as these represent high-sensitivity, high-impact external dependencies impacting both schedule and CAPEX. Concurrently, the feasibility of large-scale local workforce integration must be quantified to manage schedule risk against social license requirements (Data Item 3). Actions should begin immediately by engaging the designated external experts (RTE/Land Use/Socio-Economic) to secure timeline assurances.

# Documents to Create and Find

# Documents to Create

## Create Document 1: Project Charter: 9 GW Hauts-de-France AI Campus

**ID**: cedbbf94-cbd5-4f77-a41a-8cd210fdadc9

**Description**: Foundational document establishing official project scope, objectives (Phases 1 & 9GW goal), alignment with the 'Pragmatic Scale-Up' strategy, authorized budget envelope (€100B+ projection), high-level schedule, and ultimate decision authorities. Document type: Project Charter/Mandate.

**Responsible Role Type**: Chief Infrastructure Strategist & Project Architect

**Primary Template**: PMI Project Charter Template

**Secondary Template**: Internal Governance Mandate Template

**Steps to Create**:

- Incorporate strategic mandates from all 10 key decisions into scope boundaries.
- Define the required conditional budget allocation between CAPEX for 1 GW build and pre-funding for feasibility/ROW securing.
- Obtain formal sign-off from Financial Controller regarding the funding gates aligned with Decision 4 (60% Tenant Threshold).

**Approval Authorities**: Executive Steering Committee

**Essential Information**:

- Detail the **final, non-negotiable scope** for Phase 1 (500MW - 1GW operational capacity) aligned with the 'Pragmatic Scale-Up' path.
- Quantify the authorized CAPEX envelope for Phase 1 construction and the ring-fenced budget for Phase 0 enabling activities (ROW, skills academy).
- Explicitly list the **binding trigger conditions** for unlocking Phase 2 expansion funding, referencing the 60% take-or-pay threshold (Decision 4) and the required RTE commitment status (Decision 1).
- Define the **legal status and initial handling** of the 128.8 km² buffer zone (80% footprint), specifying which portion is 'Permanent Ecological Offset' and which is 'Expansion Reserve' (Review Issue 2).
- Establish the **governing decision** on Land Assembly Modality: confirmation of the 'hyper-dense development model' (32.2 km² buildable area) over contiguous assembly.
- Finalize the **PUE performance commitment** for Phase 1 (Max 1.20 operational ceiling) and the associated contractual liability triggers related to anchor tenants (Risk 2).
- Mandate the **physical separation protocol** (Substation 1 isolation) required for initial commercial hardware versus future sovereign compute zones (Risk 5/Assumption Q7).
- Document the **Time Buffer Assumptions** derived from external review, specifically assuming a minimum 36-month lead time for RTE upgrades post-Phase 2 FID, and integrate resulting 'Power Readiness Lockout Clauses' into the schedule.

**Risks of Poor Quality**:

- Ambiguity in the Phase 1 scope or resource allocation leading to immediate scope creep or under-funding of critical enabling activities (e.g., land holding costs or skills academy).
- Lack of clear financial gates (Decision 4 linkage) results in Phase 2 capital deployment being initiated prematurely based on soft commitments, risking stranded assets if tenant thresholds are not met.
- Unresolved land status (Permanent vs. Reserve) leads to immediate legal challenges against the 'hyper-dense' model, triggering Risk 7 and construction halting.
- Absence of clear security isolation mandates (Risk 5) forces costly retrofitting during Phase 2 or jeopardizes eligibility for high-value sovereign contracts.
- Failure to explicitly incorporate buffer time for RTE confirmation (Review Issue 1) leads to the Phase 1 schedule being over-optimistic, guaranteeing contract breaches with tenants expecting power availability.

**Worst Case Scenario**: The project secures only partial Phase 1 financing due to unclear contractual risk transfer mechanisms (especially regarding the 80% land buffer), leading to immediate inability to secure necessary ROW, while high initial CAPEX sunk into feasibility studies (€1B+) cannot be recovered, resulting in project suspension or mandated significant scope reduction before 500 MW is operational.

**Best Case Scenario**: Executive Steering Committee sign-off provides undeniable executive mandate for the 'Pragmatic Scale-Up' framework, immediately unblocking resources for critical Phase 0 activities (land holding, skills academy funding) and establishing clear, de-risked funding gates that satisfy financial controllers and anchor tenants, thereby reducing the projected 1.5-year grid delay impact via upfront ROW securing, accelerating confidence in the 3-year Phase 1 completion goal.

**Fallback Alternative Approaches**:

- If explicit 80/20 land status cannot be agreed upon, immediately shift budget from general CAPEX contingency to secure 5-year binding lease options for the 32.2 km² buildable area, delaying the permanent designation of the buffer area (128.8 km²) until Heat Reuse contracts (Decision 6) are finalized.
- If internal analysis struggles to finalize the precise €100B+ envelope segregation, utilize the PMI Project Charter Template structure to define the budget as a 'Band' (e.g., €8B–€12B Phase 1 CAPEX) anchored only by the fixed costs agreed for the known Phase 0 activities (e.g., skills academy funding).
- If anchor tenant negotiations stall on the 60% revenue threshold, default to Decision 3, Choice 1: pivot Phase 1 focus entirely to securing the sovereign partition mandate first, using state guarantees as the Phase 2 funding trigger instead of commercial revenue.

## Create Document 2: Grid Interconnection Feasibility and Commitment Strategy (RTE/EDF)

**ID**: 6ca3f3c0-d617-44b5-b320-bb45acaebdb7

**Description**: Strategy document detailing the path to secure Phase 2 (3 GW) grid allocation. It must mathematically link the 60% tenant commitment threshold (Decision 4) to the required collateral funding date for RTE upgrades, in line with the 'No Grid Pre-Commitment' strategy for major works (Decision 1). Document type: Technical-Financial Strategy.

**Responsible Role Type**: Grid & Power Procurement Specialist

**Primary Template**: Energy Interconnection Strategy Framework

**Secondary Template**: PPA Term Sheet Template

**Steps to Create**:

- Formalize the pre-paid application process for the Phase 1 (500MW-1GW) hosting consultation.
- Model the required financial collateral structure needed by RTE for Phase 2 upgrades, contingent on the 60% tenant trigger.
- Develop the formal engagement timeline for RTE based on assumed 36-month upgrade completion buffer (Expert Review Issue 1).

**Approval Authorities**: Chief Infrastructure Strategist & Project Architect, Financial Controller & Currency Risk Manager

**Essential Information**:

- Quantify the minimum required financial collateral (in EUR) necessary for RTE to formally initiate feasibility and preliminary upgrade commitments for the Phase 2 expansion (3 GW) based on current French energy regulatory models.
- Establish the precise schedule dependency: Define the mandatory lead time (in months) between the execution of the 60% tenant commitment trigger (Decision 4) and the date the required collateral must be paid to RTE to ensure Phase 2 capacity is theoretically available 36 months later (Adhering to Review Issue 1).
- Detail the formal structure of the non-binding hosting consultation response for Phase 1 (500MW-1GW) and specify the exact deliverables required by RTE at this stage to satisfy Decision 1, Choice 2.
- Develop a strategy for legally insulating Phase 1 CAPEX financing from requirements for Phase 2 transmission upgrade collateral, adhering to the 'No Grid Pre-Commitment' strategy.
- Compare the financial impact (NPV/CoC) of a 36-month vs. a 48-month assumed RTE upgrade completion timeline on the overall project IRR.

**Risks of Poor Quality**:

- Incorrect collateral modeling leads to insufficient capital reserved at the 60% tenant trigger point, causing RTE to reject the commitment timeline and forcing a multi-year delay in Phase 2 power delivery.
- An inaccurate or optimistic schedule buffer (e.g., assuming <36 months for RTE upgrades) results in Phase 2 tenants activating power agreements before infrastructure is ready, leading to SLA breaches and potential contract clawbacks.
- Failure to clearly separate Phase 1 financing from Phase 2 collateral obligations results in lenders rejecting Phase 1 financing due to unmanaged grid commitment dependency.
- Misalignment between the PPA negotiation timeline and the technical commitment date for RTE leads to paying premium prices for delayed transmission slots.

**Worst Case Scenario**: The financial controller misunderstands the collateral requirements, leading to the inability to fund the necessary RTE bond immediately upon hitting the 60% tenant trigger, resulting in RTE revoking the preliminary capacity allocation slots required for 3 GW, halting the entire 9 GW program indefinitely due to unresolvable power supply constraints.

**Best Case Scenario**: The strategy mathematically proves that Phase 1 financing is fully decoupled from Phase 2 grid collateral, allowing Phase 1 FID to proceed based on existing RTE non-binding confirmation, while simultaneously securing a fixed, risk-buffered timeline (36 months post-commit) for Phase 2 power availability, enabling the Tenant Acquisition Trigger to be set with high confidence.

**Fallback Alternative Approaches**:

- If accurate collateral modeling proves impossible due to opaque RTE guidelines, revert Decision 1 to Choice 3 (Dual-path microgrid strategy) for the 6 GW beyond the initial 3 GW to physically bypass the most uncertain grid interconnection points.
- If a firm 36-month completion buffer cannot be secured from RTE experts, immediately negotiate higher initial power commitment (1 GW firm commitment for Phase 1 instead of 500MW soft) to gain political leverage for priority scheduling on grid upgrades.
- Develop a 'Provisional Collateral' strategy using a highly liquid financial instrument contingent on Phase 2 tenant revenue realization, allowing the commitment deadline to be met without immediately using primary project CAPEX.

## Create Document 3: Land Assembly and Use Model (GIS-Based Delineation)

**ID**: 23063434-b15f-4dfe-948c-6cf50ee90956

**Description**: A highly detailed geographic information system (GIS) model delineating the full 161 km² footprint. Must identify and digitally fence the 32.2 km² buildable area (hyper-dense nodes), the 128.8 km² buffer zone, and specifically mark the 30% 'Permanent Ecological Offset' acreage required for pre-emptive permitting risk mitigation (Decision 10). Document type: Technical Land Model/Regulatory Input Data.

**Responsible Role Type**: Large-Scale Land & Civil Works Model Modeler

**Primary Template**: GIS Cadastral Mapping Standard

**Secondary Template**: Brownfield Remediation Zoning Plan

**Steps to Create**:

- Integrate parcel data for Cambrai, Dunkirk, and Valenciennes clusters.
- Digitally assign zoning statuses (Buildable, Expansion Reserve, Permanent Offset) based on strategic decisions.
- Calculate and budget 18 months of estimated holding costs for the 128.8 km² buffer zone (Expert Review Issue 2).

**Approval Authorities**: Chief Infrastructure Strategist & Project Architect, French Land Use and Environmental Lawyer

**Essential Information**:

- Digitally delineate the full 161 km² required footprint using GIS mapping standards.
- Precisely fence the 32.2 km² designated 'Buildable Area' (hyper-dense nodes) based on Decision 2 (Choice 3) and Q1 Assumptions.
- Digitally assign zoning statuses for the 128.8 km² buffer, specifically marking the 30% acreage designated as 'Permanent Ecological Offset' (Decision 10, Choice 2 rationale).
- Output must include calculated 18-month holding costs for the 128.8 km² buffer, ring-fenced from infrastructure CAPEX (Review Issue 2).
- The GIS model must clearly show the physical isolation alignment for Substation 1 serving the 500 MW Phase 1 area, separate from future sovereign compute zones (Review Q7).

**Risks of Poor Quality**:

- Incorrect buffer/buildable area calculation leads to direct budget overrun (>€1.3B estimate if holding costs are miscalculated or permanently designated land is incorrect).
- Inaccurate digital fencing violates zoning submissions (DREAL/DDETSPP), leading to immediate judicial challenge against the 'hyper-dense development model' and stopping physical site mobilization.
- Failure to visually separate Phase 1 power infrastructure in the model jeopardizes DGSI security assurance checkpoints regarding physical segregation (Risk 5).
- Inability to transition buffer land status (e.g., from 'Reserve' to 'Permanent Offset') due to poor initial delineation, leading to high administrative overhead and potential social license erosion.

**Worst Case Scenario**: A flawed GIS model causes rejection by local permitting authorities during Phase 0 submission, forcing an immediate re-evaluation of the 80% buffer strategy and potentially reducing the buildable area to less than planned, thus capping the maximum achievable capacity significantly below the 4 GW target, rendering the 9 GW strategy infeasible.

**Best Case Scenario**: The highly detailed, validated GIS model accelerates DREAL/Prefecture approval by clearly defining non-buildable zones upfront, preempting litigation risk associated with land use disputes (Risk 7), securing the 32.2 km² core buildable area quickly, and allowing remediation contracts to commence without regulatory pause.

**Fallback Alternative Approaches**:

- If integration of existing parcel data is too complex, revert to utilizing high-resolution satellite imagery and simplified 1 km x 1 km grid overlays provisionally, flagging all areas outside the 32.2 km² core as 'High Uncertainty Land/Buffer Pending Final Survey' for regulatory submission.
- If accurate holding cost calculation is delayed, proceed with the GIS delineation but allocate a maximum fixed contingency (€100M) in the Phase 0 budget specifically for unknown land holding costs, acknowledging the explicit budgetary risk identified in the review.
- Engage a French environmental planning lawyer immediately to draft preliminary zoning definitions based on the visual GIS output, even if cost data is pending, to meet regulatory submission deadlines.

## Create Document 4: Sovereign Security & Commercial Isolation Protocol (Phase 1 & 2)

**ID**: 6b633f24-7ca4-4407-8b81-d17707018826

**Description**: Technical specification document detailing the physical and logical separation required between the initial 500 MW commercial load and the future dedicated sovereign AI partition (Decision 3). Must define hardware provenance requirements for Phase 1 non-classified hardware and mandate the use of dedicated, segregated substation capacity (Substation 1 concept) for initial load.

**Responsible Role Type**: Regulatory & Sovereignty Compliance Lead

**Primary Template**: DGSI/ANSSI Interface Compliance Roadmap Template

**Secondary Template**: Physical Security Segregation Standard

**Steps to Create**:

- Define explicit hardware sourcing criteria for the 500 MW commercial phase.
- Map out the location and switching logic for Substation 1 isolation.
- Produce a formal briefing document for DGSI engagement based on pre-signed requirements.

**Approval Authorities**: Regulatory & Sovereignty Compliance Lead, Chief Infrastructure Strategist & Project Architect

**Essential Information**:

- Define explicit hardware provenance criteria/chain of custody requirements for the initial 500 MW commercial load hardware, ensuring alignment with DGSI expectations even if the hardware is non-classified.
- Detail the complete physical schematics for Substation 1, mandated exclusively for the initial 500 MW commercial load, demonstrating full electrical and physical isolation from future sovereign partitions (Decision 3).
- Produce a formal briefing document detailing the operational plan for isolating the initial commercial load, referencing the agreed-upon separation protocols required before Phase 1 Power FID.
- Specify the logical (network segregation) and physical security measures planned for the 500 MW cluster to ensure zero cross-contamination with the location earmarked for the dedicated sovereign compute zone.
- Quantify the lead time required for DGSI/ANSSI review based on the submitted schematics, to be logged as a dependency/buffer for the overall Phase 2 timeline (Review Issue 1 implicitly applies to security clearance timing).

**Risks of Poor Quality**:

- Failure to secure DGSI agreement on the isolation protocol risks mandatory, expensive retrofitting of the initial 500 MW build, or denial of qualification for subsequent sovereign contracts.
- Ambiguous hardware provenance rules for Phase 1 could lead to procurement risks, forcing the project to discard non-conforming components or violate security alignment mandates.
- Inadequate substation isolation design leads to regulatory rejection of the entire security model, jeopardizing the core value proposition (high-value government/sovereign tenants).
- Delaying formal DGSI engagement due to an incomplete protocol forces security review into the critical path after Phase 1 construction FID, potentially causing significant, uncontrolled delays (Risk 5).

**Worst Case Scenario**: DGSI/ANSSI rejects the Phase 1 commercial cluster's operational security plan because of inadequate physical isolation from future sovereign zones, resulting in the inability to secure premium domestic contracts, thereby failing the 60% tenant commitment threshold for Phase 2 expansion (Decision 4 failure).

**Best Case Scenario**: Achieving signed protocol/agreement on the isolation plan with DGSI/ANSSI during Phase 0/1 engagement. This proactively de-risks the sovereign revenue stream, secures favorable regulatory status, and allows Phase 1 commercial operations to commence without risk of mandated security retrofit, directly enabling the successful execution of Decision 3's strategic goal.

**Fallback Alternative Approaches**:

- If definitive DGSI requirements are unattainable, proceed with Substation 1 isolation designed to the highest established European commercial banking security standards, documenting the divergence and creating a time-boxed contingency budget to upgrade to DGSI-specified hardware after Year 2 operations commence.
- If physical isolation schematics are blocked by RTE/Land development uncertainty, pivot the initial 500 MW to utilize only fully-vetted, open-source hardware stacks (no national sensitive components) to minimize sovereignty risk until physical sub-zones are confirmed.
- Engage a specialized French security consultancy (with prior government clearances) to pressure-test and rapidly finalize the isolation specifications based on analogous infrastructure precedents.

## Create Document 5: Risk Register (Initial Critical Path Analysis)

**ID**: 5ef83b35-5c2f-4cb9-90d5-10baa156f0f3

**Description**: The comprehensive compilation of initial risks (Regulatory, RTE/Grid, Social License Erosion, PUE failure) detailing likelihood, severity, initial mitigation actions, and assigning *primary ownership roles* based on the defined team structure. Crucial for tracking the project's 'red team' mandate.

**Responsible Role Type**: Chief Infrastructure Strategist & Project Architect

**Primary Template**: Standard Project Risk Register Template

**Secondary Template**: Cross-Dependency Risk Matrix

**Steps to Create**:

- Formalize assignment of ownership for the 9 identified critical risks.
- Incorporate mitigation strategies reviewed in expert feedback (e.g., buffer land budget—Review Issue 2).
- Establish the mandatory bi-weekly review structure for Security Implementation Steering Committee (Team Omission 2).

**Approval Authorities**: Project Development Team

**Essential Information**:

- List the 9 primary risks identified, derived from the 'Identify Risks' section, ensuring likelihood and severity are quantified for each.
- For each of the 9 risks, explicitly detail the mitigation plan or action derived from the 'Project Plan.md' section.
- Define the 'primary ownership roles' for each of the 9 risks, linking them to specific functions within the Project Development Team structure (even if the structure itself is implied/omitted, define roles like 'Grid Lead', 'Regulatory Counsel', 'Security Architect', etc., based on the nature of the risk).
- Incorporate the quantified feedback recommendations from the 'Review Assumptions' section (e.g., incorporating the 36-month RTE buffer assumption, the land holding cost budget directive, and the phased workforce scaling).
- Define the required structure and frequency for the 'Security Implementation Steering Committee' review cadence as it pertains to Risks 5 and 7.

**Risks of Poor Quality**:

- Failure to assign clear risk ownership will cause critical mitigation actions (especially related to land holding capital and grid buffering) to be dropped or delayed, leading directly to schedule slippage or unexpected cost overruns.
- Inaccurate mapping of mitigation strategies will result in the wrong team acting on the wrong priority, specifically endangering the alignment between the Pragmatic Scale-Up finance trigger and the RTE lead time.
- Omitting quantitative feedback from assumption review (e.g., RTE buffer time) will result in the register not capturing the true execution risk profile, leading to an inaccurate perception of the Phase 1 completion probability.
- If primary ownership roles are vague, the 'red-team' mandate fails, as risks will not be actively tracked or reported against defined performance metrics.

**Worst Case Scenario**: The risk register fails to capture the true schedule risk associated with external dependencies (RTE lead times, permitting challenges on land buffers), leading the Project Development Team to believe Phase 1 is on schedule until crucial mitigation actions (like securing buffer land holding budget or establishing regulatory time buffers) are missed, resulting in a project halt or a multi-year delay impacting initial revenue streams and triggering covenant breaches on initial financing.

**Best Case Scenario**: A high-quality, actionable Risk Register allows the Chief Infrastructure Strategist to immediately delegate clear accountability for all 9 critical risks, directly integrating the quantitative buffers (RTE time, land holding costs) identified in expert review, ensuring the 'Pragmatic Scale-Up' strategy effectively mitigates regulatory and structural dependencies before Phase 1 FID.

**Fallback Alternative Approaches**:

- If role assignment is difficult due to undefined team structure, initially assign all 'High Severity/High Likelihood' risks directly to the 'Chief Infrastructure Strategist & Project Architect' role until functional leads can be confirmed.
- If detailed mitigation steps from 'Review Assumptions' are too complex to incorporate immediately, create a mandatory subsidiary action item for the relevant risk owner to schedule a focused workshop within one week to convert complex assumptions into concrete, tracked tasks.
- Use the structure of the 'Cross-Dependency Risk Matrix' template to force linking ownership across the key decision levers (e.g., linking Risk 3 (RTE Failure) directly to Decision 1 owner) as a temporary substitute for detailed role assignments.


# Documents to Find

## Find Document 1: RTE/Enedis Frameworks for Multi-Stage Grid Interconnection Financing

**ID**: 61852e43-f4ba-4af5-918b-fdb4d6bf5440

**Description**: Existing regulatory documents or procedural handbooks detailing the financial requirements (collateral vs. binding commitment timelines) for a staged connection request projected over 9 GW in the Hauts-de-France region. Needed to quantify Risk 3.

**Recency Requirement**: Current regulations essential (post-2022 structure)

**Responsible Role Type**: Grid & Power Procurement Specialist

**Steps to Find**:

- Search the official RTE website for 'Tarif d'Utilisation des Réseaux Publics d'Électricité' (TURPE) documentation related to new large industrial connections.
- Contact the Energy Regulation Specialist to locate precedents for developer-funded regional network upgrades.
- Review French Cre documents related to network investment mandates.

**Access Difficulty**: Medium

**Essential Information**:

- Detail the exact financial collateral timing versus binding capacity allocation deadlines for staged grid access requests (e.g., 1 GW initial commitment versus 9 GW ultimate target) as stipulated by current RTE/Enedis frameworks.
- List the specific financial instruments (e.g., deposits, irrevocable letters of credit) required by RTE to secure Phase 2 transmission reservation slots prior to receiving binding 'Affirmation de Prêt' (Loan Affirmation) for transmission infrastructure investment.
- Quantify the maximum documented lead time (in months) RTE requires to complete mandatory regional transmission hardening necessary for a 3 GW connection following financial commitment, based on post-2022 regulations.
- Identify any regulatory clauses that explicitly link a developer's right to defer major transmission collateral payments (Risk 3) to the execution of take-or-pay tenant contracts (Decision 4 threshold).

**Risks of Poor Quality**:

- Inaccurate assessment of collateral timing leads to under-budgeting for required Phase 0/1 cash reserves, causing a liquidity crisis when RTE demands upfront funding for Phase 2 studies.
- Misinterpreting the RTE lead time for infrastructure hardening results in an over-optimistic timeline for the 'Pragmatic Scale-Up' strategy, causing Phase 2 FID to occur before power is ready, stranding Phase 1 capital.
- Failure to identify contingency financing clauses means the project cannot pivot if binding tenant commitments (60% threshold) are secured before RTE is ready, creating an unmanageable financial gap.

**Worst Case Scenario**: A 9-month mismatch between the guaranteed 60% tenant commitment trigger (Phase 2 FID) and the mandated RTE transmission upgrade completion results in the financial inability to secure the required 3 GW grid capacity, forcing a permanent scale reduction from 9 GW to the non-viable 3 GW/4 GW range, severely undermining the project's foundational ambition and decreasing Net Present Value by over 30%.

**Best Case Scenario**: Precise quantification of RTE's financial and timeline requirements allows the Power Procurement Specialist to structure the Phase 2 financing request such that the 60% tenant revenue trigger perfectly aligns with the required RTE collateral submission dates, effectively eliminating Risk 3 (Stranded Capital) and proving the feasibility of the highly interdependent financing gates.

**Fallback Alternative Approaches**:

- If framework documents are unavailable, immediately commission a targeted legal review engagement with a specialized French energy law firm to model financing scenarios based on precedent cases cited in recent large industrial interconnection approvals.
- Engage EDF/EDF Trading proactively to model multiple scenarios for capacity buyback or PPA sunset clauses tied to a 'Grid Readiness Delay' metric, converting unknown regulatory risk into quantifiable P&L contingency.
- Pilot a small-scale (100 MW) provisional grid connection request utilizing a dedicated reserve fund, treating the administrative process as a real-time learning exercise to empirically derive the required collateral amounts.

## Find Document 2: DGSI/ANSSI Data Center Security Certification Requirements (Current)

**ID**: 7c3147ca-229f-4ae3-a6a0-8fa822ca0d13

**Description**: Official documentation outlining the necessary physical segregation, hardware provenance auditing standards, and timeline expectations for achieving sovereign AI classification status in France for large-scale compute infrastructure. Crucial input for Decision 3.

**Recency Requirement**: Most recent published guidelines (within 1 year)

**Responsible Role Type**: Regulatory & Sovereignty Compliance Lead

**Steps to Find**:

- Search the ANSSI portal for 'Guide Security des Centres de Données' or equivalent high-level classification path documents.
- Submit formal inquiry through the designated regulatory liaison channel regarding preliminary review schedules.
- Consult with the EU Sovereign AI Policy Advisor for internal DGSI contacts.

**Access Difficulty**: Hard

**Essential Information**:

- List the specific architectural requirements (e.g., physical separation distance, hardened casing levels) mandated by DGSI/ANSSI for the future Sovereign AI partition (Decision 3).
- Quantify the required timeline buffer (minimum number of months) between DGSI/ANSSI final sign-off and the proposed Phase 2 expansion FID based on historical precedent provided by French authorities.
- Detail the mandatory process for hardware provenance auditing, specifically listing acceptable Tier/Origin certifications necessary to satisfy sovereign requirements.
- Identify all operational protocols (monitoring, access control, intrusion response) that must be specifically documented and governed by a signed agreement *before* Phase 1 Power FID is achieved.

**Risks of Poor Quality**:

- Misinterpreting security partitioning requirements leads to expensive, mandatory retrofitting of Phase 1 facilities to meet DGSI standards, causing a 6-9 month delay to sovereign tenant leasing.
- Failure to accurately estimate the DGSI review timeline results in the Tenant Acquisition Trigger Threshold (60% commitment) being breached before security clearance is granted, leading to stranded anchor tenants or forced renegotiation of high-value contracts.
- Incomplete understanding of hardware origin requirements results in procurement of non-compliant accelerators, making the facility ineligible for sensitive state workloads, thereby eroding the project's key value proposition.
- Submitting incomplete or outdated requirements leads to an initial rejection from ANSSI, adding 4-6 months to the overall regulatory clearance path, conflicting with the 3-year Phase 1 timeline.

**Worst Case Scenario**: The project successfully commissions its Phase 1 commercial capacity, but DGSI/ANSSI denies the ability to isolate or certify the planned sovereign AI zone within the existing physical design, rendering the highest-value revenue stream inaccessible, resulting in a 30-40% reduction in long-term projected NPV and the failure of the Phase 2 expansion trigger.

**Best Case Scenario**: Achieving a signed protocol with DGSI/ANSSI early in Phase 1 that locks in the security architecture. This allows the team to accelerate the design of the sovereign partition in parallel with commercial rollout, securing preferential government integration status and guaranteeing access to the highest-margin state contracts upon facility readiness, validating the 'security as an enabler' strategy.

**Fallback Alternative Approaches**:

- Initiate a targeted legal review engagement with a specialized French administrative law firm focused solely on DGSI compliance timelines to establish a credible regulatory buffer timescale (to address Review Issue 1).
- Engage DGSI/ANSSI directly via the 'Regulatory & Sovereignty Compliance Lead' to negotiate a 'Provisional Certification Pathway' that allows initial commercial tenants while concurrently validating the sovereign zone isolation design.
- If the full hardware provenance auditing details are unavailable, immediately commit to procuring only hardware components explicitly listed on a pre-approved, high-security French or EU vendor list, albeit at a temporary cost premium.

## Find Document 3: Hauts-de-France Regional Spatial Planning Documents (PLU/SCOT)

**ID**: cc1b09ce-8d8a-4ee0-bae1-398e4c1f3d66

**Description**: Local/Departmental zoning plans (PLU/SCOT) for the identified clusters (Cambrai, Dunkirk, Valenciennes) to confirm current industrial designation, existing environmental constraints (water tables, protected areas), and procedures for land aggregation concessions. Essential input for the Land Assembly Model.

**Recency Requirement**: Published within last 3 years

**Responsible Role Type**: Large-Scale Land & Civil Works Model Modeler

**Steps to Find**:

- Search departmental/regional authority portals (Préfecture Hauts-de-France) for planning documents related to large industrial development zones.
- Obtain cadastral maps covering the proposed 161 km² area.
- Engage the French Land Use and Environmental Lawyer for specific zoning interpretation.

**Access Difficulty**: Medium

**Essential Information**:

- List specific industrial zoning designations (PLU/SCOT) for the clustered areas: Cambrai, Dunkirk, and Valenciennes.
- Identify all existing environmental constraints (e.g., protected water tables, known ecological conservation zones, or prior remediation requirements) mapped across the 161 km² target area.
- Detail the specific administrative/legal procedures required within the identified zones to secure land aggregation concessions (e.g., expropriation paths, public utility declarations).
- Confirm the procedural timeline (if available) for the local authorities to grant concessions needed for the 'hyper-dense development model' (32.2 km² buildable zone).
- Identify any existing land-use limitations that conflict with the 'Permanent Ecological Preservation' designation required for the 80% buffer zone.

**Risks of Poor Quality**:

- Utilization of outdated zoning data will lead to immediate legal challenges and delays when submitting land aggregation plans, violating the 'Pragmatic Scale-Up' approach.
- Failure to identify hidden environmental constraints (e.g., water tables) will result in unforeseen remediation CAPEX and potential mandatory adoption of higher-cost cooling methods, thus invalidating the PUE goals.
- Incorrect understanding of aggregation procedures will lead to the filing of insufficient planning applications, resulting in administrative rejection and potential judicial review against the fragmented site strategy.
- If spatial constraints (e.g., local protected zones) conflict with the proposed 32.2 km² buildable core, the 9 GW target becomes unachievable without significant land-use litigation.

**Worst Case Scenario**: Obtaining incorrect or incomplete spatial planning documents leads to filing permit applications with fundamental conflicts (e.g., building on protected ecological land), resulting in an immediate Judicial STOP Order on land assembly (Risk 1), delaying Phase 1 FID by 2+ years and triggering significant write-downs on pre-paid feasibility studies.

**Best Case Scenario**: Confirmation of suitable, contiguous, and industrially zoned parcels across the three chosen clusters allows for the immediate front-loading of definitive site control documentation, enabling the Land Assembly Model to proceed on schedule, directly supporting the Phase 1 construction timeline.

**Fallback Alternative Approaches**:

- Initiate immediate, funded parallel negotiations for Land Assembly Modality (Decision 2) focusing only on existing brownfield sites explicitly zoned for high-intensity industrial use, bypassing areas requiring environmental reclassification.
- Commission a third-party, high-fidelity GIS mapping overlay exercise integrating current DREAL environmental data with cadastral records across the entire 161 km² area, prioritizing data accuracy over document recency.
- Engage local municipal planning directors (Mairie) directly for informal confirmation of zoning intent regarding the 80% buffer reservation, potentially mitigating risks identified in Review Issue 2.

## Find Document 4: French Environmental & Water Usage Regulations (ICPE/ARS)

**ID**: dc14dc00-6618-4ace-bac6-2242ec4b0a2c

**Description**: Legislation governing industrial site classification (ICPE) for power consumption and data center water usage restrictions as enforced by DREAL and ARS bodies in the Hauts-de-France region. Needed to validate the PUE/cooling strategy against mandatory curtailment threats (Risk 6).

**Recency Requirement**: Current operational status mandatory

**Responsible Role Type**: Hyperscale Data Center Design & Cooling Engineer

**Steps to Find**:

- Search the Legifrance database for relevant ICPE decrees pertaining to high-capacity power/heat rejection facilities.
- Request specific guidance from DREAL/ARS regarding regional water scarcity thresholds for industrial cooling in the specific catchment areas near Dunkirk/Cambrai.

**Access Difficulty**: Medium

**Essential Information**:

- Identify the specific ICPE classifications applicable to a combined 9 GW data center and associated substation infrastructure in Hauts-de-France.
- List the precise, quantified maximum water withdrawal limits (m³/hour or m³/year) permitted for data center cooling operations in the target catchment areas, particularly under seasonal drought scenarios.
- Detail any mandated operational restrictions or curtailment procedures triggered when the Environmental Authority (ARS) forecasts water stress above specific thresholds (e.g., amber/red alert levels).
- Confirm the feasibility and associated permitting timeline/cost for implementing 100% dry/zero-water cooling for the initial 1 GW phase (PUE target ceiling of 1.20).
- Outline the reporting frequency and data format required by DREAL/ARS to demonstrate compliance with water usage and heat rejection disclosures.

**Risks of Poor Quality**:

- Violation of regional water quotas leading to mandatory operational curtailment for up to 1 GW (Risk 6), immediately breaching PUE-linked tenant contracts (Decision 4).
- Inaccurate ICPE classification leading to incorrect initial design assumptions for external heat rejection infrastructure, forcing costly retrofits or reduced efficiency.
- Assuming sufficient water availability based on national law, only to find local ARS enforcement prevents adequate cooling, degrading PUE above the 1.20 tolerance threshold.
- Delayed permitting due to insufficient or incorrectly formatted environmental compliance documentation required by DREAL/ARS, stalling the land assembly process.

**Worst Case Scenario**: Regional water authorities enforce substantial, unbudgeted mandatory curtailment (e.g., 50% reduction in operations) during the first year of 1 GW operation due to exceeding ARS limits derived from flawed regulatory assumptions, immediately triggering major SLA penalties and jeopardizing initial revenue streams.

**Best Case Scenario**: Clear, early confirmation of ultra-low water usage allowances based on dry cooling design (PUE <=1.20), resulting in expedited water permits and removing groundwater/hydrological risk as a critical path concern for subsequent expansion phases.

**Fallback Alternative Approaches**:

- Immediately increase the CAPEX allocation for Phase 1 to fund 100% dedicated, redundant dry cooling towers, accepting the PUE degradation to 1.20, to bypass reliance on local surface/groundwater licenses.
- Engage a specialized French environmental consultancy with a proven track record specifically addressing ARS and DREAL water licensing for large industrial sites in Hauts-de-France.
- If wet cooling feasibility cannot be confirmed by Q4 2025, formally revise the Land Use Feasibility Assumption (Water/PUE) and commit budget for necessary land adjustments to accommodate required footprint for dry cooling capacity.

## Find Document 5: Brownfield Site Environmental Baseline Reports (Cluster 1 & 2)

**ID**: f9dc09fc-5ae9-4b18-a691-d682d6ed990f

**Description**: Existing preliminary environmental surveys or contamination reports pertaining to past industrial uses (steel/refinery) on the proposed buildable 32.2 km² cluster areas. This data directly informs the required remediation capital expenditure estimate (Risk 9).

**Recency Requirement**: Historical reports acceptable, provided they haven't triggered new cleanup orders since publication.

**Responsible Role Type**: Large-Scale Land & Civil Works Model Modeler

**Steps to Find**:

- Submit formal Freedom of Information requests (or equivalent French process) to DREAL/local environmental agencies for historical site usage reports.
- Request data from the Chamber of Commerce related to former tenants on the identified industrial parks.

**Access Difficulty**: Hard

**Essential Information**:

- Identify the exact soil contamination classification (e.g., ICPE subclass) for the 32.2 km² buildable area in Cluster 1 (Cambrai/Valenciennes) and Cluster 2 (Dunkirk).
- Quantify the volume and required remediation technique (e.g., excavation, stabilization) for detected hazardous materials, correlating directly to the Risk 9 budget overrun estimates (€250M–€2.25B).
- List confirmed historical land use activities post-1980 for every major sub-parcel contributing to the 32.2 km² buildable zone.
- Detail any existing environmental restrictions or pre-loaded remediation requirements mandated by the DREAL/DDETSPP on the land parcels as of the current date.

**Risks of Poor Quality**:

- Inaccurate contamination mapping leading to doubling of remediation capital expenditure (€500M–€2.25B overrun), consuming contingency funds and delaying construction start by 3-6 months.
- Failure to identify hidden hazardous materials requiring specialized handling, leading to immediate stop-work orders from environmental authorities.
- Mismatch between assumed contamination profile and actual requirements, causing the remediation contracts to fail to meet the fixed-price agreement status sought in Phase 0.

**Worst Case Scenario**: Discovery of Class 1 highly contaminated zones requiring deep excavation or off-site processing across more than 10% of the buildable area, pushing total remediation costs above €1.5B and delaying data hall construction commencement by over one year, paralyzing Phase 1 FID.

**Best Case Scenario**: Reports confirm low-level, manageable contamination requiring fixed-volume stabilization costing approximately €250M, allowing for early lock-in of fixed-price EPC remediation contracts, securing the Phase 1 construction start within the 3-year timeline.

**Fallback Alternative Approaches**:

- Immediately fund comprehensive, on-site, high-resolution phase one environmental site assessments (ESAs) and targeted geotechnical surveys across the entire 32.2 km² buildable footprint to establish a local baseline.
- Engage remediation specialists to provide tiered, scenario-based cost proposals based on discovery of specific contaminant classes (e.g., heavy metals vs. complex hydrocarbons).
- Adjust Phase 1 budget allocation to increase the contingency line item for environmental risk from 10% to 30% of the initial remediation estimate until binding contracts are secured.

## Find Document 6: TenneT/RTE Analogous Multi-GW Staged Interconnection Case Study Reports

**ID**: 4c1ae489-42d4-4cf7-8817-11dacc0b9e17

**Description**: Case studies or annual report sections detailing how TenneT (Netherlands) or RTE managed the interconnection and upgrade funding for projects achieving multi-GW scale in phases (similar to the 1 GW -> 3 GW -> 9 GW transition). Crucial for validating the Grid Strategy.

**Recency Requirement**: Post-2017 focusing on large-scale digital infrastructure.

**Responsible Role Type**: Grid & Power Procurement Specialist

**Steps to Find**:

- Review TenneT/RTE annual reports concerning high-demand industrial park connection agreements.
- Search for public records or case studies referenced by the Eemshaven digital hub analogue.
- Consult with the European Energy Regulation Specialist for proprietary access points.

**Access Difficulty**: Medium

**Essential Information**:

- Identify binding timelines for mandated RTE grid upgrade completion subsequent to receiving the financial commitment/funding for Phase 2 (3 GW) expansion.
- Quantify the developer-funded percentage vs. RTE-funded percentage for the transmission upgrades required between the 3 GW and 9 GW capacity milestones.
- Detail the specific contract mechanism (e.g., performance bonds, contractual penalties) interconnecting the Tenant Acquisition Trigger Threshold (60% take-or-pay) to the financier's release of collateral for RTE interconnection studies.
- List specific case studies demonstrating successful staggered capacity acquisition (1GW -> 3GW -> 9GW) in complex EU regulatory environments (analogous to TenneT/RTE experience).
- Extract verifiable data points regarding the maximum time buffer (delay) experienced between financial commitment for grid upgrades and actual power availability confirmation for similar multi-stage data center builds.

**Risks of Poor Quality**:

- Failure to accurately model RTE upgrade timelines (post-commitment) will lead to an inaccurate 'Power Readiness Lockout Clause', resulting in a 1.5-year revenue delay and increased Cost of Capital (€500M–€800M overrun).
- Inaccurate assessment of required developer collateral funding for non-committed phases (3 GW+) risks stranding Phase 1 capital if RTE demands pre-funding beyond agreed limits.
- Lack of context regarding analogous project funding structures may lead to under-budgeting for contingencies required to manage the high-risk RTE dependency.
- If data lags pre-2017, the analysis may not account for modern requirements of hyperscale AI compute interconnection (higher initial power surge stability).

**Worst Case Scenario**: The project locks Phase 1 financing based on optimistic external timelines, commits necessary collateral funding, but then RTE reports a non-negotiable 3-year grid upgrade schedule post-commitment, leading to an inability to satisfy Phase 2 tenant anchor contracts and resulting in the stranding of €1B–€2B of Phase 0/1 capital and potential termination penalties.

**Best Case Scenario**: By incorporating precise RTE timeline buffers derived from case studies, the 'Power Readiness Lockout Clause' is accurately defined, allowing the project to synchronize Tenant Acquisition (60% threshold) with infrastructure availability, thereby minimizing stranded capacity risk and ensuring Phase 2 FID proceeds exactly as planned post-Phase 1 stabilization.

**Fallback Alternative Approaches**:

- Initiate immediate specialized consulting study focused solely on French Transmission Planning Law to establish legally mandated RTE upgrade lead times, treating external timelines as a non-negotiable constraint.
- Immediately engage EDF/State representatives via the DGSI channel to obtain confidential internal RTE scheduling forecasts for the specific network region, bypassing standard public reporting cycles.
- Develop a 'Temporary Power Solution' annex plan (e.g., modular BESS for 200MW backup, Decision 9, Choice 3) to absorb up to 12 months of RTE delay risk for Phase 1 operations, isolating this buffer from primary financing.

## Find Document 7: DGSI/ANSSI Hardware Provenance & Supply Chain Control Documentation

**ID**: bd83ba3f-db0c-4f63-8f19-80a0767e0760

**Description**: High-level policy documents describing the regulatory classification criteria for IT hardware components that must be restricted, audited, or sourced domestically to achieve 'sovereign certification' status (Decision 3 input). This defines the non-negotiable physical and logical isolation requirements.

**Recency Requirement**: Current security policy essential

**Responsible Role Type**: Regulatory & Sovereignty Compliance Lead

**Steps to Find**:

- Consult with the EU Sovereign AI Policy Advisor for any publicly accessible guidance on 'critical infrastructure hardware sourcing'.
- Search official EU security agency publications relating to supply chain resilience for AI infrastructure.

**Access Difficulty**: Hard

**Essential Information**:

- Detail the exact hardware sourcing restrictions (domestic vs. international) required for the sovereign AI partition.
- List the specific data classification levels (e.g., Secret Défense, Confidentiel Défense) that mandate dedicated physical isolation.
- Define the required audit frequency and scope imposed by DGSI/ANSSI on hardware provenance tracking.
- Provide the mandatory physical and logical isolation standards (e.g., air-gapping requirements, dedicated powerfeeds, HVAC segregation) needed to satisfy Decision 3 and achieve sovereign certification readiness.
- Quantify the timeline deviation impact if hardware sourcing does not meet these criteria before Phase 1 Power FID.

**Risks of Poor Quality**:

- Inaccurate design based on outdated security policies leads to mandatory, expensive retrofitting of Phase 1 infrastructure to meet sovereign partition standards, increasing sunk CAPEX.
- Failure to isolate hardware correctly results in denial of access to high-value French state and defense compute contracts, immediately jeopardizing the 60% trigger threshold for Phase 2 expansion.
- Lack of clarity on acceptable hardware provenance leads to supply chain blockages, delaying the acquisition of necessary GPUs/TPUs for the initial 500 MW deployment.
- Incorrect design interpretation causes the project to fail the mandatory DGSI checkpoint, resulting in a complete halt of regulatory progress.

**Worst Case Scenario**: Failure to obtain signed protocol defining hardware provenance control results in the entire 9 GW capacity being classified as non-sovereign, resulting in the loss of €10B–€20B in long-term premium government revenue streams and potential revocation of key operational licenses.

**Best Case Scenario**: Securing clear, signed DGSI/ANSSI protocols proactively defines the security architecture for the entire campus, enabling immediate allocation of 2 GW as pre-engineered sovereign capacity, thereby accelerating access to premium revenue streams and de-risking the entire long-term project justification.

**Fallback Alternative Approaches**:

- Engage a specialized French regulatory consultant with established relationships at DGSI/ANSSI for an immediate, closed-door interpretation session regarding current hardware sourcing policies.
- Design the initial 500 MW commercial cluster with physically redundant, isolated infrastructure pathways that allow for rapid re-zoning (reclassification) to the sovereign standard with minimal retrofit upon final policy confirmation.
- If policy criteria are unattainable, pivot strategy to target only non-sovereign, Tier 1 non-governmental anchor tenants whose contractual requirements are less stringently regulated regarding hardware origin.

## Find Document 8: Hauts-de-France Regional Energy Infrastructure Plans (9GW Context)

**ID**: 1860cb42-2a48-4dd7-89d2-20643c8487bb

**Description**: Strategic energy planning documents from the Hauts-de-France Regional Council showing projected available transmission capacity and planned future nuclear/renewable PPAs in the 2028-2035 timeframe. This data informs the long-term viability of the 9 GW ambition independent of isolated RTE negotiation points.

**Recency Requirement**: Regional energy planning documents published within last 3 years

**Responsible Role Type**: Grid & Power Procurement Specialist

**Steps to Find**:

- Search the regional government website for 'Schéma Régional Climat Air Énergie' (SRCAE) or regional economic development plans.
- Contact local DREAL/DGEC representatives for regional energy forecasts.

**Access Difficulty**: Medium

**Essential Information**:

- Detail the projected RTE transmission capacity allocations specifically planned for the 9 GW data center cluster target area between 2028 and 2035, independent of immediate RTE project negotiations.
- List pre-approved or earmarked long-term Power Purchase Agreements (PPAs) or generation firming commitments (nuclear/renewable) identified at the regional level that underpin the 9 GW availability.
- Quantify the regional pipeline for renewable energy sites or industrial off-takers that might directly conflict with or support the project's scheduled 9 GW power demand timeline.
- Identify any regional master plans that mandate specific power quality or grid hardening standards for large industrial consumers in the Hauts-de-France region.

**Risks of Poor Quality**:

- Inaccurate long-term power availability assessment leads to over-committing to tenants based on unconfirmed regional pipeline capacity beyond Phase 2.
- Failure to align procurement sequencing with regional plans prevents optimal financing rates, as PPA negotiations cannot leverage confirmed long-term capacity availability.
- If regional plans show capacity constraints post-2030, the 9 GW ambition is invalidated at a very late stage, forcing a costly, rapid downsize or abandonment of subsequent phases.
- Missing conflicts with local renewable targets could trigger opposition from regional environmental agencies, impacting permitting velocity.

**Worst Case Scenario**: The regional plans reveal that the necessary non-RTE upgrades or PPA availability for the 3 GW to 9 GW expansion is not feasible until after 2035, making the 9 GW goal unachievable within the project's financial modeling timeline, leading to massive write-downs on sunk Phase 1/2 CAPEX.

**Best Case Scenario**: The document confirms substantial regional energy infrastructure planning supports the 9 GW target timeline (or clearly dictates required regulatory steps), allowing the Power Procurement Specialist to secure favorable, pre-validated financing terms that de-risk the Grid Integration lever beyond Phase 2 funding commitment.

**Fallback Alternative Approaches**:

- Mandate the Grid & Power Procurement Specialist to initiate formal, pre-application data requests directly with EDF/RTE referencing the project's expected scale, even if formal feasibility studies are not yet funded.
- Commission an independent, high-cost feasibility study specifically focused on regional microgrid/BESS firming capacity utilization (aligning with Decision 1, Choice 3) to create a parallel power commitment track independent of official RTE forecasts.
- Engage a senior lobbyist with deep ties to the Hauts-de-France Prefect's office to gain access to pre-release infrastructure planning drafts.

# SWOT Analysis


## Strengths 👍💪🦾
- Strategic location in Hauts-de-France offers proximity to key Northern European markets (Paris, London, Brussels, Frankfurt) and leverages the region's industrial redevelopment narrative.
- Strong technical foundation targeting low PUE (1.15–1.25) through mandatory direct-to-chip liquid cooling, optimizing operational efficiency.
- Adoption of the 'Pragmatic Scale-Up' strategy, which de-risks capital deployment by linking Phase 2 funding to 60% committed tenant revenue (Decision 4).
- Proactive security planning via early engagement and physical isolation protocols for the sovereign AI partition (Decision 3), vital for attracting premium state contracts and mitigating state risk.
- Land-use model that reserves 80% (128.8 km²) as buffers/reserves (hyper-dense model), which strategically mitigates immediate opposition from agricultural displacement and environmental concerns.

## Weaknesses 👎😱🪫⚠️
- Extreme capital outlay required, with full 9 GW buildout projected at €100B–€140B+.
- High dependency on external, uncontrolled French regulatory bodies (RTE, DREAL, DGSI) for grid connection and permitting, creating critical path schedule risk.
- The required 161 km² footprint is exceptionally large, forcing a fragmented, hyper-dense model across multiple industrial zones, complicating unified physical security and logistics.
- The ambitious technological roadmap (ultra-low PUE, immediate liquid cooling scale-up on brownfield sites) introduces higher-than-standard technical integration risk (Risk 2).
- Missing 'Killer Application': The plan targets general AI training/inference but lacks a flagship, compelling use case uniquely tailored to the French/EU context that would guarantee expedited national backing or immediate demand pull beyond commercial hyperscaler needs.

## Opportunities 🌈🌐
- Development of a **Killer Application**: Creating a dedicated, high-profile 'Sovereign AI Hub' leveraging ANSSI/DGSI certification to become the default, trusted compute provider for French and specific EU public sector workloads, thereby guaranteeing foundational utilization and favorable long-term PPA terms.
- Monetization of Waste Heat (Decision 6): Leveraging the industrial context (Dunkirk/Cambrai) to secure binding, long-term contracts for industrial heat reuse, transforming an environmental liability into a local economic asset and accelerating social license.
- Leveraging Extreme Scale: The 9 GW target, if realized, positions the campus as a primary digital pillar in Northern Europe, attracting Tier 1 anchor tenants willing to sign high-commitment, long-term (take-or-pay) contracts.
- Workforce Development (Decision 8): Aggressive local skill uplift program can create a unique, competitive operational labor advantage within Hauts-de-France, lowering long-term OpEx and solidifying social license.
- Strategic Fiber Ownership: Opportunity to secure long-term dark fiber rights-of-way or co-fund subsea landing points (Decision 5), reducing dependency on incumbent carriers and gaining favorable latency control for the entire 15-year lifecycle.

## Threats ☠️🛑🚨☢︎💩☣︎
- RTE/Grid Capacity Denial or Extreme Delay: Failure to secure binding transmission upgrades for Phase 2 (3 GW) by the time Phase 1 construction financing closes (Risk 3).
- Permitting Hold-Up: Judicial review or political intervention challenging the 80% land buffer model (Risk 7), arresting construction momentum post-Phase 1 success.
- Geopolitical and Currency Volatility: Significant EUR/USD depreciation increasing hardware procurement costs by billions (€4.32B residual risk without full hedging).
- Security Review Bottleneck (DGSI/ANSSI): Protracted national security vetting for the sovereign partition could delay access to premium revenue streams, causing tenant migration risk.
- Water Scarcity Constraints: Regional hydrological limitations forcing an immediate switch from preferred low-water cooling to higher-risk methods, leading to mandatory curtailment (Risk 6).

## Recommendations 💡✅
- Immediately budget and execute long-lead physical securing of Rights-of-Way (ROW) easements for Phase 2 transmission interconnects, irrespective of immediate financing commitment, to buffer the RTE schedule risk. **Owner:** Infrastructure Lead. **Deadline:** 2026-12-31.
- Initiate the 'Sovereign AI Hub Killer Application' track: Allocate 20% of the Phase 0 budget to secure pre-agreements with DGSI/ANSSI defining the operational parameters for a dedicated 2 GW partition, contingent on the success of the initial 500 MW commercial load. This ensures a defined premium revenue stream by Year 5. **Owner:** Strategy & Regulatory Affairs. **Deadline:** Q1 2027 (10 months).
- Formalize the 80% land buffer as a binding local concession by establishing the 'Permanent Ecological Offset' for 30% of the total acreage and immediately contracting the holding costs for the remaining 50% Expansion Reserve for 18 months, integrating the associated CAPEX into the Phase 1 budget review. **Owner:** Land & Development Director. **Deadline:** 2026-09-01.
- Mandate that all major hardware procurement contracts (GPUs/TPUs) for Phase 1 and Phase 2 tranches feature EUR-indexed pricing floors and mandatory 70% forward FX hedging coverage, moving the residual USD exposure below €1 Billion. **Owner:** CFO/Treasury. **Deadline:** Q2 2027 (Concurrent with hardware ordering).
- Prioritize finalizing one binding, industrial heat-reuse off-take partner (Decision 6) within the Dunkirk cluster planning zone to convert the social license risk into a concrete public benefit asset, using this pilot to de-risk further community acceptance across the entire footprint. **Owner:** Community Engagement Lead. **Deadline:** Q4 2026.

## Strategic Objectives 🎯🔭⛳🏅
- Secure a binding RTE capacity contract for a minimum of 2.5 GW (for Phase 2 expansion) by the date of FID for Phase 1 construction, validated against secured tenant commitments totaling 60% of the 2 GW tranche. (Time-bound: Prior to Phase 1 FID).
- Successfully deploy and commission the initial 500 MW commercial compute capacity (Phase 1) while maintaining a verifiable operational PUE of 1.20 or less, and achieve DGSI sign-off on the physical isolation of this commercial zone. (Measurable: PUE <=1.20 & DGSI check). (Time-bound: Within 36 months).
- Neutralize the primary land assembly risk by securing legally binding agreements for 30% of the non-buildable 128.8 km² buffer zone as permanent offset and budget holding capital for the remainder for 18 months. (Measurable: 38.6 km² committed/budgeted). (Time-bound: 2027-05-16 + 18 months).
- Finalize the contractual and technical blue-print (including dedicated fiber path requirements) necessary to deliver sub-2ms latency across the defined multi-site campus architecture required for synchronized AI workloads by the end of Phase 1. (Measurable: Sub-2ms RTT validation report). (Time-bound: 36 months).

## Assumptions 🤔🧠🔍
- The Pragmatic Scale-Up strategy is the chosen path, prioritizing financial de-risking over immediate speed to market.
- The buildable area is constrained to approximately 32.2 km² (20% of the 161 km² target), with the remaining 80% dedicated as buffers requiring long-term holding costs.
- Phase 2 transmission upgrades (post-1 GW) will require a minimum validated construction/commissioning lead time of 36 months from funding commitment (RTE update).
- Anchor tenants will honor the 60% take-or-pay commitment threshold required for Phase 2 expansion FID.
- The French national security apparatus (DGSI/ANSSI) will permit the initial 500 MW commercial load to operate while the dedicated sovereign partition is concurrently designed and reviewed.

## Missing Information 🧩🤷‍♂️🤷‍♀️
- Specific regulatory timelines (in months) RTE requires for grid upgrade feasibility studies and subsequent construction completion following the payment of required collateral for a 3 GW connection.
- Detailed market study justifying the demand profile that can commit 60% of the 2 GW expansion tranche (Phase 2) within the 3-year timeframe.
- Precise cost modeling for the 128.8 km² buffer acreage holding costs (e.g., property taxes, maintenance, administration) required for the multi-year commitment.
- Confirmed specific subsea cable landing points (e.g., Dieppe, Calais) to accurately assess the cost and latency trade-offs for Decision 5.
- The formal requirements from DGSI/ANSSI regarding the definition of 'non-classified' vs. 'sovereign' hardware separation, which directly impacts Phase 1 operational flexibility.

## Questions 🙋❓💬📌
- Given the reliance on the 'hyper-dense' model, how would the project's financial case change if judicial review forces the buildable area down from 32 km² to 20 km², effectively capping the long-term capacity at ~5-6 GW instead of 9 GW?
- If RTE confirms that a 3 GW connection is technically possible but requires the project to fund an additional €2 Billion in regional grid reinforcement *before* Phase 2 FID, does this trigger a reassessment of the overall 9 GW feasibility, or is this considered a necessary cost of the strategic location?
- What specific, non-technical metric (e.g., local employment percentage, guaranteed heat-reuse volume) is considered the single most important lever for securing rapid, positive social license sign-off from the Hauts-de-France Prefect?
- How sensitive is the optimal Phase 1 (1 GW) tenant acquisition strategy to the initial 500 MW being designated as non-sovereign/commercial versus being partially ring-fenced immediately for a high-profile, non-classified French corporate contract?
- If a validated 'Killer Application' (e.g., a major government contract for national language model training) guarantees immediate purchase of 1.5 GW capacity starting in Year 4, should we violate the Pragmatic Scale-Up strategy and immediately fund non-binding RTE studies for 5 GW in Phase 0 to capture that revenue, accepting the associated financial overhang?

# Team

*Roles Needed & Example People*

# Roles

## 1. Chief Infrastructure Strategist & Project Architect

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Chief Infrastructure Strategist must be a deeply embedded, long-term contributor responsible for maintaining complex, strategic alignment (e.g., 9 GW roadmap vs. feasibility) over a 10-15 year timeline. This role requires deep organizational commitment and fiduciary duty.

**Explanation**:
Owns the overall strategic choices (e.g., split-campus vs. contiguous, hyper-dense model) and ensures the 15-year roadmap aligns with feasibility findings. Acts as the primary liaison for the 'red team' mandate.

**Consequences**:
Strategic drift, failure to challenge core ambitious assumptions (like 9 GW or 161 km²), and misalignment between phased funding gates and external regulatory readiness.

**People Count**:
min 1, max 2, depending on workload distribution

**Equipment Needs**:
High-performance workstation/server for complex infrastructure modeling (GIS, BIM, Digital Twin simulations for 161 km² layout), Subscription access to high-resolution cadastral and environmental data platforms.

**Facility Needs**:
Secure, dedicated office space with robust physical and cyber security protocols for handling long-term strategic roadmaps and sensitive financial/security governance documents.

## 2. Regulatory & Sovereignty Compliance Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Regulatory oversight (DGSI/DREAL) is continuous and high-stakes, requiring deep, protected knowledge retention and direct accountability to internal governance. This demands full-time, dedicated employment for security and permitting.

**Explanation**:
Manages all interactions with French national security agencies (DGSI, ANSSI) and local permitting bodies (DREAL, Prefectures). Ensures the sovereign AI partition design and hardware sourcing comply with national standards from Phase 0.

**Consequences**:
Total blockage of the sovereign AI tenant base, critical delays in national security review, and potential legal challenges to land use/environmental approvals derived from stakeholder skepticism.

**People Count**:
2

**Equipment Needs**:
Secure terminal access for communication with DGSI/ANSSI secure networks, specialized hardware classification documentation systems, and secure data storage for national security protocols.

**Facility Needs**:
Secure, access-controlled facility zone with dedicated clearance levels for handling classified design reviews related to sovereign AI partitioning and physical security infrastructure planning.

## 3. Grid & Power Procurement Specialist

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Grid & Power Procurement often requires niche expertise in French energy market regulations (RTE/EDF PPA structures) that is best sourced from highly specialized consultants (ICs) for complex, discrete negotiation processes like securing 9 GW allocation pathways, rather than maintaining a permanent FTE for this specific regulatory challenge.

**Explanation**:
Responsible for all negotiation and technical modeling with RTE and EDF. Translates the 9 GW load profile into binding grid upgrade requirements and sequences Power Purchase Agreement (PPA) negotiations relative to tenant commitment triggers.

**Consequences**:
Stranded capital risk if grid upgrades are paid for prematurely, or fatal delay if RTE capacity confirmation misses the Phase 2 FID timeline (Risk 3).

**People Count**:
min 2, max 3, due to complexity of RTE engagement

**Equipment Needs**:
Advanced power flow modeling software (e.g., PowerFactory, PSSE) capable of simulating 3 GW/9 GW load injections into the RTE network, standardized template library for complex PPA negotiation and financial modeling software supporting EUR/USD tracking.

**Facility Needs**:
Temporary, secure facility space for high-stakes negotiation sessions with RTE/EDF counterparties, featuring encrypted communication channels for sensitive PPA discussions.

## 4. Large-Scale Land & Civil Works Model Modeler

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Large-Scale Land Modeling, especially concerning the complex, rationalized 161 km² footprint (hyper-dense buildable vs. 80% buffer), requires specialized geospatial and brownfield real estate expertise for a focused 3-5 year assembly period. This is typically managed via fixed-term consultancies.

**Explanation**:
Focuses exclusively on the 161 km² physical layout, rationalizing the hyper-dense buildable area (32.2 km²) against the required buffers (128.8 km²). Responsible for budgeting land holding costs and modeling brownfield remediation logistics.

**Consequences**:
Massive CAPEX overrun due to unbudgeted land holding costs, failure to secure necessary ROW easements for future utility connections, and inability to present a legally viable land-use model to authorities.

**People Count**:
min 1, max 2, depending on the complexity of fragmented site control

**Equipment Needs**:
High-precision Geospatial Information System (GIS) and CAD/BIM software licenses for modeling the 161 km² layout, specialized environmental sampling and remediation planning software, and land holding cost tracking ledger.

**Facility Needs**:
Access to high-capacity plotters and secure, temperature-controlled physical storage for original land deeds, ROW paperwork, and preliminary environmental survey reports.

## 5. Hyperscale Data Center Design & Cooling Engineer

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Design and engineering for advanced, novel cooling systems (direct-to-chip liquid cooling at 1.15 PUE) is highly specialized. The best experts often operate as specialized consultants (ICs) available on a project-by-project basis to ensure leading-edge feasibility.

**Explanation**:
Translates the 1.15-1.25 PUE target into finalized technical specifications for direct-to-chip liquid cooling, focusing on high-density build models (low-rise halls) and ensuring ultra-low water consumption architecture for Phase 1.

**Consequences**:
Failure to meet operational PUE targets, leading to increased operational expenditure (OPEX) and potential breach of tenant/PPA efficiency clauses.

**People Count**:
1

**Equipment Needs**:
Computational Fluid Dynamics (CFD) simulation suite for validation of 1.15 PUE liquid cooling performance at scale, specialized thermal testing rigs for direct-to-chip hardware validation, and detailed specification sheets/portfolios of dry cooler manufacturers.

**Facility Needs**:
Access to a local test environment or lab space capable of simulating high-density heat rejection conditions for short-duration pilots, even if full cooling plant construction is delayed.

## 6. Financial Controller & Currency Risk Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Financial control, especially managing multi-billion EUR budgets, FX hedging, and setting internal financing gates aligned with multi-year construction tranches, requires permanent, fiduciary responsibility and deep integration into the project's financing structure.

**Explanation**:
Owns the multi-currency budget (€EUR vs. $USD hardware exposure). Structures financial triggers (Decision 4) and implements FX hedging strategies to protect the multi-billion Euro CAPEX against exchange rate volatility.

**Consequences**:
Uncontrolled budget erosion due to unfavorable EUR/USD movements (€4B+ risk identified), or setting financial expansion triggers (Decision 4) that do not align with lending covenants.

**People Count**:
1

**Equipment Needs**:
Enterprise ERP/Financial Reporting software integrated with FX tracking modules, dedicated terminal access for managing forward currency hedging contracts (Bloomberg terminal or equivalent), and sophisticated debt/syndication modeling tools.

**Facility Needs**:
A highly secure, firewalled financial operations room, isolated from general project network access, necessary for managing multi-billion Euro financing drawdowns and sensitive hedging operations.

## 7. Social License & Community Benefits Orchestrator

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Social License and Heat Reuse require expertise in French public relations, regional economics, and environmental negotiation. This expertise is often best contracted on a retainer basis to manage specific political sprints (permitting phases) rather than maintained full-time post-stabilization.

**Explanation**:
Focuses on mitigating social risk by linking Heat Reuse monetization (Decision 6) and the Local Workforce Uplift Mandate (Decision 8) to tangible community outcomes. Essential for accelerating permitting velocity by converting opposition to partnership.

**Consequences**:
Fatal political or judicial delays due to local opposition regarding land use and lack of direct economic benefit, undermining the 15-year project viability.

**People Count**:
1

**Equipment Needs**:
Community engagement software platforms for tracking local sentiment, dedicated liaison communication contracts for regional mayors/prefectures, and standardized documentation templates for Heat Reuse Offtake Agreements (with associated low-margin financial models).

**Facility Needs**:
Flexible, publicly accessible or neutral meeting space near the target zones (e.g., in Cambrai or Valenciennes) suitable for hosting community information sessions and establishing the fund office for the skills academy.

## 8. Telecoms & Connectivity Architect

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Telecoms Architecture, particularly securing diverse low-latency fiber routes and negotiating subsea commitments (Decision 5), is a discrete, high-value task typically outsourced to specialized connectivity architects (ICs) who manage carrier negotiations and dark fiber agreements.

**Explanation**:
Designs the redundant, low-latency fiber strategy (terrestrial and subsea focus). Ensures the physical connectivity strategy (Decision 5) can sustain synchronized AI training workloads across distributed campus clusters if a split-campus model is adopted.

**Consequences**:
Failure to deliver necessary latency thresholds for compute tenants, resulting in tenant attrition or significant operational penalties based on network performance SLAs.

**People Count**:
1

**Equipment Needs**:
Network topology mapping software supporting long-haul low-latency path analysis, specialized fiber route acquisition database access (for French ROW mapping), and contracts for laser communication testing equipment for RTT validation.

**Facility Needs**:
Secure coordination hub for managing multiple specialized fiber contractors, ensuring physical and virtual separation between terrestrial and subsea route planning efforts.

---

# Omissions

## 1. Missing Dedicated Construction & Logistics Management Role

The project involves coordinating massive civil works, brownfield remediation, and the phased construction of 50-100+ data halls across potentially fragmented sites (Decision 2). While the Land Modeler handles planning, there is no dedicated role to manage the on-site interface, contractor oversight, logistics scheduling, and adherence to the 3-year Phase 1 timeline.

**Recommendation**:
Introduce a temporary, highly experienced 'Program Director - Construction & Logistics' (IC or FTE for Phase 0-2). This role must integrate schedules from the Land Modeler, Cooling Engineer, and Workforce Orchestrator to ensure physical build progress aligns with energy and tenant commitment gates.

## 2. Absence of Dedicated Water Resource Management Expertise

The plan cites 'Water risk' as Medium/Medium severity and mandates 'ultra-low-water cooling,' yet the team structure lacks a recognized expert (FTE or IC) specifically focused on French hydrological permitting, regulatory engagement with ARS (Regional Health Agencies) regarding water rights, or sophisticated water recycling system integration.

**Recommendation**:
Contract a specialized 'Water Resource Engineer/Consultant' (IC, Phase 0-2) to focus exclusively on modeling the water balance for the defined cooling architecture against regional restrictions. This role must liaise directly with the Regulatory Lead regarding ARS approvals, which are often slower than DREAL permits.

## 3. No Defined Role for Financial Hedging Execution

The Financial Controller is responsible for managing currency risk, but the management of active, multi-hundred-million USD forward contracts (as implied by the 70% hedging strategy) requires dedicated execution, monitoring, and counterparty management that goes beyond standard financial control duties.

**Recommendation**:
If the Financial Controller cannot dedicate significant capacity, contract a 'Treasury & FX Execution Specialist' (IC, Phase 1 focus). This specialist executes the hedging positions dictated by the Financial Controller and monitors mark-to-market valuations daily, ensuring the project survives the identified €4.32B USD/EUR variance risk.

## 4. Missing Internal Technical Assurance/Quality Control

The project relies heavily on novel technology integration (9 GW grid coordination, 1.15 PUE liquid cooling, complex security isolation). There is no dedicated internal role bridging the physical realities of the Engineering team with the strategic requirements of the Strategist, risking technical deviations that breach performance SLAs.

**Recommendation**:
Assign the responsibility for formal QA/QC verification on technical delivery (e.g., PUE validation, fiber latency testing) to the Chief Infrastructure Strategist, but mandate they engage an external, independent 'Technical Verifier' (IC, short-term contract for Phase 1 commissioning) to audit compliance against the design specifications before Tenant/RTE witness tests.

---

# Potential Improvements

## 1. Clarify Land Responsibility Between Modeler and Strategist

The Land Modeler (IC) handles planning/modeling, while the Chief Strategist (FTE) owns the strategic choice (hyper-dense model reserving 80%). This creates ambiguity regarding who is ultimately accountable for the politically sensitive *holding cost* commitment identified as a critical budget risk.

**Recommendation**:
Explicitly assign the 'Financial Accountability for Buffer Holding Costs (128.8 km²)' to the Financial Controller, but mandate that the Chief Strategist must secure the explicit Board/Funder approval for the calculated holding budget as part of every funding gate, directly linking the strategic land conservation choice to financial compliance.

## 2. Formalize the Interface Between Sovereignty and Construction

The Regulatory Lead deals with DGSI/ANSSI, while the Construction Program (missing role) manages physical security implementation. The critical need for physical isolation between Phase 1 and Sovereign zones requires a unified management point to prevent construction errors from violating security protocols.

**Recommendation**:
Establish a mandatory 'Security Implementation Steering Committee' meeting bi-weekly during Phase 1 construction. This committee must include the Regulatory Lead and the Construction Director, requiring joint sign-off on all physical demarcation points, substation interface wiring, and access control installation schedules that affect the sovereign partition boundary.

## 3. Integrate Workforce Uplift Timeline with Contractor Selection

The Local Workforce Orchestrator (IC) focuses on social license, but the Grid/Power Specialist and the Land Modeler rely on contractors (EPCs/Remediation) that may resist hiring local apprentices, directly conflicting with Decision 8 (75% local hiring mandate).

**Recommendation**:
Mandate that all Request for Proposals (RFPs) issued by the Construction Director (or equivalents) for Phase 1 civil works and remediation must include a mandatory, weighted scoring component (e.g., 15% of the total score) based strictly on the prospective contractor's submitted, auditable plan with the Workforce Orchestrator to achieve the 75% local hiring quota.

## 4. Systematize Decision Gate Documentation Beyond Initial Readout

The project relies on clearly defined Decision Gates (e.g., Phase 2 FID contingent on 60% tenant commitment). The current structure risks these gates degrading over 15 years without standardized documentation of past fulfillment.

**Recommendation**:
For every Decision Gate (Phase 1 FID, Phase 2 FID, etc.), require the Chief Infrastructure Strategist to produce a 'Gate Fulfillment Sign-Off Report' summarizing evidence against each required dependency (e.g., 'RTE Contract Executed: Yes/No, Date: YYYY-MM-DD'). This formalizes the 'red team' review process for future leadership transitions.

# Expert Criticism

# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: French Land Use and Environmental Lawyer

**Knowledge**: DREAL regulation, ICPE permitting, agricultural zoning, brownfield remediation

**Why**: Needed to rigorously assess feasibility of the 80% land buffer model and navigate complex, fragmented environmental/zoning approvals in Hauts-de-France.

**What**: Advise on legal structuring for the 30% 'Permanent Ecological Offset' to pre-empt judicial challenges to the land assembly.

**Skills**: Land law, EIA procedures, administrative litigation, zoning compliance

**Search**: Avocat droit de l'urbanisme Hauts-de-France, DREAL permitting specialist

## 1.1 Primary Actions

- Engage a land-use consultant to create a detailed GIS-based land-use model for the 32.2 km² buildable area.
- Secure a binding power purchase agreement with RTE for at least 1 GW capacity before proceeding with construction financing.
- Develop and implement a comprehensive community engagement strategy to secure social license and address local concerns.

## 1.2 Secondary Actions

- Conduct a detailed risk assessment of the permitting process and identify potential legal challenges.
- Establish a timeline for community engagement activities and stakeholder consultations.
- Monitor and evaluate the effectiveness of community outreach efforts and adjust strategies as necessary.

## 1.3 Follow Up Consultation

Discuss the progress on land-use planning, power procurement negotiations, and community engagement efforts. Evaluate any emerging risks and adjust the project timeline accordingly.

## 1.4.A Issue - Inadequate Land Use Planning

The proposed plan lacks a detailed land-use model that clearly defines the specific areas allocated for various uses, including data halls, substations, and biodiversity buffers. This ambiguity could lead to significant delays in permitting and community opposition.

### 1.4.B Tags

- land_use
- permitting
- community_opposition

### 1.4.C Mitigation

Immediately engage a land-use consultant to develop a comprehensive GIS-based land-use model that delineates specific zones for each intended use within the 32.2 km² buildable area. This model should include detailed cadastral references and ensure compliance with local zoning regulations.

### 1.4.D Consequence

Failure to define land use zones could result in prolonged permitting processes, increased legal challenges, and potential loss of community support, jeopardizing the entire project timeline.

### 1.4.E Root Cause

Insufficient initial planning and stakeholder engagement regarding land use and zoning compliance.

## 1.5.A Issue - Unclear Power Procurement Strategy

The power procurement strategy is overly reliant on non-binding commitments from RTE, which poses a significant risk to the project's feasibility. Without a clear, binding agreement for the necessary power capacity, the project may face insurmountable delays.

### 1.5.B Tags

- power_procurement
- risk_management

### 1.5.C Mitigation

Prioritize securing a binding power purchase agreement (PPA) with RTE for at least 1 GW before proceeding with construction financing. Engage legal counsel to negotiate terms that minimize risk and ensure timely access to power.

### 1.5.D Consequence

Without a binding PPA, the project risks significant delays and potential financial losses, as construction may proceed without guaranteed power availability.

### 1.5.E Root Cause

Overconfidence in securing power commitments without a structured negotiation strategy.

## 1.6.A Issue - Insufficient Community Engagement Strategy

The current plan does not adequately address community engagement or the social license to operate. This oversight could lead to public opposition and legal challenges, particularly regarding land use and environmental impacts.

### 1.6.B Tags

- community_engagement
- social_license

### 1.6.C Mitigation

Develop a comprehensive community engagement strategy that includes regular consultations with local stakeholders, transparent communication about project benefits, and commitments to local workforce development. Allocate budget for community outreach initiatives.

### 1.6.D Consequence

Neglecting community engagement could result in significant public backlash, legal challenges, and delays in project approval, ultimately threatening the project's viability.

### 1.6.E Root Cause

Lack of proactive engagement and communication with local communities and stakeholders.

---

# 2 Expert: European Energy Regulation Specialist (RTE/PPA)

**Knowledge**: RTE grid access rules, French energy market structure, large-scale PPA negotiation

**Why**: Critical expert to evaluate the consequences and necessary collateral for securing binding 3 GW grid commitment against uncertain tenant revenue, per Decision 1.

**What**: Model the financial impact and timeline consequences of the RTE 'No Grid Pre-Commitment for upgrades' strategy versus immediate collateral financing.

**Skills**: Grid interconnection policy, high-voltage transmission law, PPA structuring, French energy market

**Search**: RTE connection studies cost, French network upgrade funding, EDF PPA negotiation expert

## 2.1 Primary Actions

- Define the exact 32.2 km² of buildable area and establish geo-fenced GIS boundaries for the 128.8 km² buffer zones by June 30, 2026.
- Wire the pre-paid fee to RTE for the initial hosting consultation response for the 500 MW Phase 1 load by May 24, 2026.
- Implement a local workforce sourcing and skill uplift mandate, ensuring that 75% of non-specialized construction labor hours are filled by local apprentices.

## 2.2 Secondary Actions

- Engage with local authorities to ensure alignment on land use and buffer zone requirements.
- Develop a detailed community engagement strategy to address potential public opposition.
- Explore partnerships with local educational institutions for workforce development.

## 2.3 Follow Up Consultation

Discuss the progress on land use planning, power procurement strategy, and community engagement efforts. Review any feedback from RTE and local authorities regarding the project's feasibility.

## 2.4.A Issue - Inadequate Land Use Planning

The current plan lacks a detailed and specific land use model that clearly defines the buildable area and necessary buffer zones. This could lead to significant delays in permitting and community opposition.

### 2.4.B Tags

- land_use
- permitting
- community_opposition

### 2.4.C Mitigation

Immediately define the exact 32.2 km² of buildable area within designated clusters, using specific cadastral references. Establish geo-fenced GIS boundaries for the 128.8 km² buffer zones and flag required road/fiber ROW corridors by June 30, 2026.

### 2.4.D Consequence

Failure to address land use planning could result in judicial challenges, delaying the project and increasing costs significantly.

### 2.4.E Root Cause

Insufficient detail in land assembly strategy and lack of proactive engagement with local authorities.

## 2.5.A Issue - Unclear Power Procurement Strategy

The power procurement strategy is overly reliant on non-binding commitments from RTE for Phase 1, which poses a risk to the project's feasibility if binding agreements for future capacity are not secured.

### 2.5.B Tags

- power_procurement
- RTE
- feasibility

### 2.5.C Mitigation

Wire the pre-paid fee to RTE for the initial hosting consultation response for the 500 MW Phase 1 load by May 24, 2026, and initiate a parallel engineering track to model required substations.

### 2.5.D Consequence

Without a clear and binding power procurement strategy, the project risks significant delays and potential financial losses due to unfulfilled capacity commitments.

### 2.5.E Root Cause

Overly optimistic assumptions regarding RTE's responsiveness and capacity allocation.

## 2.6.A Issue - Insufficient Community Engagement and Social License Strategy

The plan does not adequately address community engagement or the social license required for such a large-scale project, which could lead to public opposition and regulatory hurdles.

### 2.6.B Tags

- community_engagement
- social_license
- public_opposition

### 2.6.C Mitigation

Implement a local workforce sourcing and skill uplift mandate, ensuring that 75% of non-specialized construction labor hours are filled by local apprentices. Begin funding for a regional skills academy immediately.

### 2.6.D Consequence

Failure to secure social license could result in significant delays, increased costs, and potential project cancellation due to public opposition.

### 2.6.E Root Cause

Lack of proactive community engagement and failure to demonstrate tangible local benefits.

---

# The following experts did not provide feedback:

# 3 Expert: Hyperscale Thermal Design Engineer

**Knowledge**: Direct-to-chip cooling, PUE optimization, 9 GW thermal rejection systems

**Why**: Required to validate the technical achievability and cost drivers of maintaining PUE <1.20 while scaling ultra-low-water cooling across a fragmented, brownfield 9 GW campus.

**What**: Validate the cooling load calculations against the feasibility of the 32.2 km² buildable area footprint, identifying key piping/pumping CAPEX risks.

**Skills**: Computational fluid dynamics, data center thermodynamics, liquid cooling integration, waste heat management

**Search**: Direct-to-chip cooling 9GW scale, high density data center thermal design

# 4 Expert: EU Sovereign AI & Cyber Security Policy Advisor

**Knowledge**: ANSSI security certifications, DGSI review process, data sovereignty compliance

**Why**: Crucial for assessing the risk associated with delaying sovereign security alignment and quantifying the revenue risk of non-compliant Phase 1 hardware isolation (Decision 3).

**What**: Develop a compliance roadmap showing the minimum DGSI sign-off required before Year 3 to unlock sovereign revenue streams.

**Skills**: Cyber compliance, hardware provenance auditing, national security clearance processes, European digital strategy

**Search**: ANSSI data center certification timeline, DGSI requirements for compute parks

# 5 Expert: Socio-Economic Impact Assessor

**Knowledge**: Local job creation metrics, community compensation frameworks, social license development

**Why**: Needed to evaluate Decision 8 (Workforce Mandate) and Decision 10 (Buffer Zones) to convert potential NIMBYism into tangible local political capital for permitting speed.

**What**: Quantify the minimum local employment commitment (percentage/headcount) necessary to persuade the Prefect to expedite the land-use zoning approval timeline.

**Skills**: Stakeholder mapping, socio-economic modeling, grievance redress mechanisms, ESG reporting

**Search**: Measuring social license impact data center France, local hiring mandates large infrastructure

# 6 Expert: FX Risk Treasury Strategist

**Knowledge**: EUR/USD hedging instruments, cross-currency financing, hardware procurement exposure

**Why**: The plan calls for tracking significant USD exposure for GPUs/TPUs against a EUR budget; this expert assesses the risk insulation strategy proposed in the budget assumptions.

**What**: Audit the proposed 70% forward hedging assumption against current market volatility to stress-test the residual budget risk for the €5B-€10B Phase 1 CAPEX.

**Skills**: Derivative contracts, commodity hedging, corporate treasury management, capital structure optimization

**Search**: FX hedging strategy AI hardware procurement, EUR USD treasury risk management

# 7 Expert: Regional Industrial Ecosystem Planner

**Knowledge**: Hauts-de-France industrial clusters, waste heat off-take logistics, infrastructure synergy

**Why**: Required to assess the practical viability and contractual complexity of Decision 6 (Heat Reuse) within the specific Dunkirk/Cambrai/E-Valley industrial geography.

**What**: Identify the nearest 3 viable industrial anchor partners capable of absorbing at least 500 MWth of low-grade heat output from Phase 2 infrastructure.

**Skills**: Industrial symbiosis, circular economy planning, district heating feasibility, regional development incentives

**Search**: Waste heat reuse market France, Industrial cluster Hauts-de-France opportunities

# 8 Expert: Hyperscale Fiber Optic Architect

**Knowledge**: Terrestrial fiber right-of-way, subsea cable landing agreements, low-latency network design

**Why**: Needed to properly vet the latency and resilience trade-offs in Decision 5 (Fiber Connectivity), balancing speed/terrestrial concentration against subsea redundancy investment.

**What**: Provide a comparison matrix detailing the RTT latency/diversification score for the preferred terrestrial route versus co-funding a new subsea connection point.

**Skills**: DWDM technology, dark fiber negotiation, carrier SLA review, transatlantic connectivity

**Search**: Subsea cable landing points France feasibility, low latency fiber route Paris London

# Work Breakdown Structure

```csv
Level 1,Level 2,Level 3,Level 4,Task ID
Hauts-de-France Buildout,,,,5efc6c0b-08eb-42d4-9a75-afc522f401a7
,Phase 0: Strategic Feasibility and De-Risking (Pre-FID),,,4b02145a-8ad2-4210-b926-d678eda9be54
,,Finalize Hyper-Dense Land Strategy and Legal Structuring,,64418e79-b91b-40ee-be30-a2ad1dc88cde
,,,Verify buffer land usage easements,508a538a-ae42-4a85-8b04-3146aba5019a
,,,Structure 30% permanent ecological offset,5c2dade2-4ee5-498c-aead-68cb9d5341a5
,,,Finalize Cadastral Holding Cost Model,7fc38f29-4db1-4e1e-9608-5848f0f456d7
,,,Benchmark local land acquisition precedence,90ef80aa-9ccd-40e1-881a-6a9ffd619d0d
,,Execute Pre-Paid RTE Grid Impact Studies (Phase 1 Contingency),,d7218da2-55fd-4ebf-836a-5febc6c6715c
,,,Submit 1GW Data Package to RTE,d39bc9f6-3440-40c4-bdf9-9244b9192402
,,,Model 1GW Load Profile Impact,8ad7c10c-574f-459e-afd6-c21fadb56ace
,,,Calibrate Collateral & Timeline Estimates,6a932906-a186-4857-bc02-f3fd373cac9c
,,,Validate Legal Review Buffer Timeline,0805d3cf-062f-4619-adbc-475bc0be5e0f
,,Initiate DGSI/ANSSI Security Protocol Review for Phase 1 Isolation,,4291d0be-4d5a-4916-a217-771536f140cb
,,,Early State Security Review,a57ff197-ac0a-4af6-8891-d41639253ea2
,,,Define Acceptable Non-Classified Hardware,9864ed29-0f01-4980-91c2-cca91b50b392
,,,Map Facility Isolation Points,1bf01fff-0422-4879-a97c-bfe0d1edaf51
,,,Validate 10-Month Review Timeline,828e39ec-9542-4fb3-8ad1-24e31a548280
,,Establish Local Workforce Upskilling Program Framework,,14a563be-2b11-458e-b3f8-df424040af1f
,,,Align with local colleges on curriculum,570bd41c-b332-4111-8a82-5e8df70932f6
,,,Secure initial training center funding,4a5525ad-464f-4040-b035-c807a1822ecb
,,,Develop phased apprenticeship roadmap,e3f33e95-7f61-40d4-9d52-bb3fec781fda
,,,Establish EPC transition standards framework,5588aad6-1efb-4e53-8b82-467b62d4de96
,,Complete 18-Month Holding Cost Budgeting for Buffer Zones,,16d517ff-4ea9-44f6-bad3-ca459cd0a5b0
,,,Model buffer holding cost per hectare,9ac273cf-a95a-499e-8d80-0f8a2486098e
,,,Determine legal structure for offset,8aba093e-de1b-4aab-8272-ffc673960664
,,,Calculate 18-month reserve facility costs,6a5b318f-7551-4305-95a9-d3cc44584419
,,,Finalize and Budget Holding Cost Item,d8d2bba0-614e-497c-a17d-499eaef358c3
,,Finalize feasibility assessment for Heat Reuse infrastructure,,a06308e2-3f4c-4df7-93d6-c8894fcf02d6
,,,Gauge local heat reuse market interest,5236aece-a2b1-4978-972b-8d80a3b8dd2b
,,,Develop preliminary heat offtake technical specs,d8313462-c615-496f-ba89-966469c0b246
,,,Establish Initial Heat Reuse Heads of Terms,d131a6e3-46aa-4ea2-8ed4-e4d236a66a9d
,,,Finalize viability study for heat reuse contracts,13dd3f30-fc98-47d9-93dd-d049fd1e407b
,Phase 1: 1 GW Initial Build and Commercial Mobilization,,,405106e7-3b08-44c5-b439-271acc86153c
,,Mobilize Construction Across Fragmented Industrial Zones,,d9ca4ab6-71bd-4fb4-b28a-48a3cb632936
,,,Sequence and secure fragmented plot access,1ab54cc6-0cf9-4302-bb67-0e9727f22e6f
,,,Establish logistics hub for dispersed zones,5efade8d-8f21-48da-99f8-07887c34a134
,,,Integrate local workforce mobilization,616d4ff3-cb16-4019-9410-91f91ecd6781
,,,Manage parallel substation readiness,3c8947fe-9e5c-4550-a7ce-1916ab56a842
,,Execute Phase 1 (500 MW - 1 GW) Liquid Cooling Infrastructure Build,,131f6bea-1b16-49d0-8022-a5f879b3ecda
,,,Framework secure for cooling suppliers,0e4c2c29-b0e8-44ba-9c6d-f1738f13e25a
,,,Long-lead item slot reservation,ab951bab-c001-4c2e-8429-70a05a00eb01
,,,Integrate liquid cooling into BIM model,7705cc5d-6330-4183-88cd-2c64e5ff935d
,,,Validate cooling vendor PUE SLAs,5c87df58-ff92-4ed5-87d6-f2d870298efe
,,Procure and Install Non-Classified Phase 1 Hardware,,65547951-22e4-4125-a7d7-d6205fcce7fa
,,,Establish global hardware procurement framework,fc8728f4-3760-4568-b2c9-1c59e2d0589b
,,,Finalize import/customs clearance strategy,314defef-94f2-4428-b0bc-b16ce07374e9
,,,Execute hardware purchase orders (Phase 1),815bd5c2-7294-432d-80fe-26f3a0c7a8b5
,,,Coordinate on-site installation readiness,f13876f8-9e7c-4eaf-b4b1-ced057c2ce10
,,Secure & Activate Primary Terrestrial Fiber Connectivity (Paris/Brussels),,6c798178-bc64-4f66-b54c-2f3d3021dae3
,,,Map fiber routes and ROW needs,5ec688d7-3945-4062-83cd-4bc3cda81fb3
,,,Negotiate ROW for all required segments,60464a74-5c23-41af-9d81-b98f5c307b5b
,,,Finalize terrestrial fiber procurement contracts,e591d461-1c05-474d-a2b6-e98655edc083
,,,Coordinate fiber build with site construction,4c19bfb2-67f4-4178-adc4-e0a553882d61
,,Onboard Initial Commercial Tenants (Up to 100% Phase 1 Load),,990eba27-2bac-4a93-9559-4f70a2999039
,,,Pre-market tenant outreach,f7eb26a8-4927-4534-bcba-37b3a7e656ef
,,,Define tiered pricing incentives,ce851e30-c6c5-48be-bf72-2f7a9f9012fa
,,,Execute early LOI negotiation milestones,67f22073-f2fe-40e1-aebc-bd5fec287682
,,,Report tenant commitment progress,26b0ec68-cc59-4ff3-a0f5-44f6235e5853
,,Achieve and Validate PUE <= 1.20 Operational Performance,,5d250b19-60e7-466d-95b0-c85a482306c6
,,,Develop phased load application plan,73491382-cfd0-42e9-9e1c-c37e7f58184e
,,,Implement advanced monitoring for cooling,6db48f0c-3755-48be-a6bf-5939b4136d45
,,,Execute controlled PUE performance burn-in,19464d57-6aa3-44db-bf08-532438e2e770
,,,Finalize and validate operational PUE SLA,a25718fa-14cc-40ea-b4eb-1bb0f1c92039
,Phase 2 Readiness: Expansion Gate Review,,,6d106374-f8eb-4eab-a0a1-6a8557b49bb4
,,Achieve 60% Take-or-Pay Commitment for Next Tranche Expansion,,26ade399-2127-4727-8358-4f8d247e2cb9
,,,Develop Phase 2 Anchor Tenant Offer,da63dca4-721d-48c8-bb05-28c0b0ec2604
,,,Identify and Pre-Engage Tier 1/2 Tenants,90a17f6b-1b5c-4f54-ad68-d32de66fc64a
,,,Structure Phased Commitment Milestones,c5415308-7f6f-4388-a41b-6c8fa526c2f7
,,,Finalize Tenant Acquisition Budget and Incentive Pool,1a2c5f63-ca5a-44ae-b5ea-eae4a9e27e40
,,Secure Binding RTE Transmission Allocation for 3 GW Expansion,,8ee68a6f-1f34-4c76-a966-09bd04963bfb
,,,Finalize RTE 3 GW capacity feasibility,9ba593d6-acc6-4582-a672-8315e34911f7
,,,Calculate RTE interconnection collateral needs,afe5dca4-40ac-42da-8e05-3958fa1577c0
,,,Calibrate binding PPA conditions for Phase 2,dfe57e84-d3c3-4243-94d7-a400b25a73c5
,,,Align RTE confirmation with Phase 2 FID gate,b4834f56-afc4-424d-8344-003d3bee2166
,,Formal Sign-off on DGSI/ANSSI Physical & Logical Isolation Protocols,,a0bfbd17-e8a0-4bf6-b7e3-9a3537a73761
,,,Interpret DGSI isolation criteria,b45855de-8daf-47ea-97f6-217a4c9f4574
,,,Design preliminary isolation schematics,4e560268-13f0-47b1-8f40-d3c5ba86b6f4
,,,Schedule DGSI Security Architecture Review,689418bd-d07a-4edd-bf82-c0b01a2ee9fa
,,,Document hardware segregation standards,4ac54a27-5df9-45ee-b7ee-811dbfbd9434
,,Finalize Contracts for Local Heat Reuse Offtake (If Pursued),,0ac99686-4b2b-4df9-8022-33c853acbeda
,,,Identify viable local heat offtake partners,f93d23cf-61d2-46ac-952c-106907db145e
,,,Conduct heat reuse technical feasibility studies,0cfd8ba7-e416-44a2-9e92-5460f1112db2
,,,Pre-negotiate Heads of Terms for Heat Offtake,754c6b67-0dac-4e30-b0d0-2a030c5caeb8
,,,Integrate heat reuse delivery into Phase 2 planning,df3be3b4-d214-4439-8a8f-fff41837443e
,,Execute FID for Phase 2 (3 GW) Expansion Based on validated Gate Review,,19562b2d-8247-48fb-8b1c-7a3d3b6d603b
,,,Verify 60% tenant commitment target,f7ddf7e0-5e2c-4511-9340-6d05ad96cac4
,,,Obtain binding RTE capacity allocation,34a281e3-19b7-49ac-bfc2-59c7231856a6
,,,Confirm DGSI/ANSSI isolation sign-off,af036803-e832-4f05-ad8d-b2632afa9b36
,,,Finalize Phase 2 CAPEX and financing,7c81548d-8edc-447c-a15a-3d09ab132442
```

# Review Plan

## Review 1: Critical Issues

1. **Grid Confirmation Timeline Risk** is the most critical issue, as the plan's 'Pragmatic Scale-Up' strategy creates a high-likelihood dependency where Phase 2 (3 GW) financing pivots on a binding RTE contract, but unbudgeted external RTE upgrade completion (estimated 36+ months lead time) could strand Phase 1 capital (Risk 3), necessitating an immediate action to engage the **European Energy Regulation Specialist** to quantify the RTE upgrade timeline buffer and formally incorporate this latency into the Tenant Acquisition Trigger Threshold definition.


2. **Unbudgeted Land Holding Costs** pose a severe near-term financial threat, as the strategic 80% land buffer (128.8 km²) is uncosted, risking an early CAPEX overrun of up to €1.3 Billion if local holding fees are not captured, which requires the **Large-Scale Land & Civil Works Model Modeler** to finalize the 18-month holding budget immediately and integrate this mandated cost directly into the Phase 1 financial plan.


3. **Workforce Skill Uplift Velocity** directly jeopardizes the 3-year Phase 1 timeline due to optimistic assumptions about local upskilling (risk of 6-12 month delay), which interacts critically with the **Social License** strategy; to mitigate this, the **Social License Orchestrator** must immediately finalize a phased local hiring roadmap with EPC contractors to confirm compliance premiums or schedule delays before Q4 2026.


## Review 2: Implementation Consequences

1. **Negative Consequence: Delayed Capacity Delivery** is a major risk, as relying on non-binding RTE consultation for Phase 1 power (Decision 1) and assuming accelerated workforce onboarding (Review Issue 3) could extend the 1 GW buildout beyond 3 years, leading to a 6-12 month delay that reduces Net Present Value (NPV) by 4-6% (€4B–€6B loss on E100B+ project) by postponing initial high-margin revenue recognition.


2. **Positive Consequence: Secured Premium Revenue Stream** results from proactively engaging DGSI/ANSSI early (Decision 3); success in isolating the Phase 1 cluster and receiving preliminary sign-off secures the path to high-value sovereign contracts, potentially guaranteeing the 60% tenant commitment threshold needed for Phase 2 FID, thereby **accelerating the entire 9 GW schedule** beyond the initial 'Pragmatic Scale-Up' timeline.


3. **Positive Consequence: Enhanced Social License & Permitting Velocity** is achieved by executing the mandate to commit 5% of Phase 0 budget to local skills and heat reuse feasibility (Decision 6 & 8), which converts regulatory friction (Risk 7) into local support, potentially shortening the necessary DREAL/Prefecture review periods for the fragmented land assembly by several months, thus **directly buffering the timeline uncertainty associated with grid confirmation (RTE/Risk 3)**.


## Review 3: Recommended Actions

1. **Quantified Risk Transfer via FX Hedging** is a high-priority financial action that should be implemented by mandating that CFO/Treasury finalize 70% forward FX hedging contracts for all identified USD hardware procurement by Q2 2027, directly mitigating the identified €4.32 Billion residual budget variance risk.


2. **Accelerated Security Pre-Agreement** is a medium-priority action designed to unlock premium revenue potential, requiring the Strategy & Regulatory Affairs team to secure written DGSI confirmation on Phase 1 isolation feasibility within 10 months (Q1 2027) to de-risk the long-term tenant acquisition threshold target (Decision 4).


3. **De-Risking Inter-Cluster Latency** is a medium-priority technical action involving the Telecoms Architect to obtain a sub-2ms RTT validation report for the split-campus model by the 36-month mark, which must be achieved by immediately committing Phase 1 CAPEX to securing dark fiber rights-of-way for the Phase 2 connectivity path, thus protecting the core AI workload synchronization capability.


## Review 4: Showstopper Risks

1. **Showstopper Risk: Failure to Secure Sovereign Hardware Provenance** (Risk 5) is a high-likelihood, high-severity risk where DGSI/ANSSI denies initial Phase 1 hardware acceptability or imposes retrospective physical segregation, potentially invalidating the entire 500 MW initial lease and costing €10B–€20B in lost premium revenue, which compounds the **Tenant Acquisition Trigger Threshold** problem; the recommendation is to enforce an **immediate, binding DGSI checkpoint on Q1 2027** defining acceptable hardware provenance, with a contingency to **lease non-sovereign capacity regionally until clearance is obtained**, despite the initial revenue hit.


2. **Showstopper Risk: Inability to Meet Ultra-Low PUE Target** (Risk 2) due to integrating complex direct-to-chip liquid cooling on brownfield sites presents a medium-severity, medium-likelihood risk, where PUE degradation to 1.35 could incur **€5M–€10M annual energy cost increases at 1 GW**, potentially causing tenant SLA breaches that interact negatively with the **Tenant Acquisition Trigger Threshold** by undermining long-term viability promises; the recommendation is to fund an **independent Technical Verifier** to validate PUE compliance during burn-in, with a contingency to **activate performance-based pricing escalators in anchor tenant contracts** if PUE exceeds 1.25.


3. **Showstopper Risk: Political Rejection of Hyper-Dense Land Model** (Risk 7) is a high-likelihood, high-severity threat where judicial review invalidates the 80% buffer strategy, forcing the buildable area down from 32.2 km² to under 20 km², thereby **constraining the 9 GW target to a projected 6 GW max** and reducing long-term ROI by 30-40%; this risk compounds **Land Assembly** complexity and **Social License**, requiring an immediate action to formally reclassify 50% of the buffer as a **renewable 18-month expansion reserve** (instead of permanent offset), with a contingency to **de-scope the 9 GW ambition to a binding 6 GW maximum** if any judicial challenge remains outstanding past Q2 2027.


## Review 5: Critical Assumptions

1. **Critical Assumption: Inter-Cluster Latency Below 2ms RTT** is essential for the split-campus model viability, where failure would render synchronization unfeasible for demanding AI workloads, resulting in a technical showstopper that forces core tenants to seek contiguous campus options, leading to potential **loss of synergistic benefits**; the validation recommendation is to conduct **independent RTT benchmarking** by Q4 2026 to confirm sub-2ms connectivity between Clusters 1 and 2, adjusting scope to contiguous build if validation fails.


2. **Critical Assumption: Favorable EUR/USD FX Rate Management** presumes that the proposed 70% forward hedging successfully controls residual hardware exposure, where an unhedged 10% unfavorable shift could inflate hardware costs by **€4.32 Billion** across the 9 GW schedule, directly competing for capital with the **Grid Integration** funding needs; the validation recommendation is to require the **Financial Controller to secure binding hedge commitment documentation** for Phase 1 hardware immediately to lock in the assumed currency stability.


3. **Critical Assumption: Effective Temporal Decoupling of Commercial and Sovereign Zones** posits that the initial 500 MW commercial load can operate physically isolated while sovereign zone design is reviewed (Risk 7 contingency), where failure risks **costly retrofitting or immediate lease termination** if DGSI requires immediate segregation; the validation recommendation is that the **Regulatory Lead must secure a written DGSI 'No Retrofit Waiver'** by Q1 2027 confirming the acceptability of the initial hardware segregation plan.


## Review 6: Key Performance Indicators

1. **KPI: Grid Capacity Confirmation Rate** (Target: 100% 3 GW RTE contract secured by Phase 2 FID) – A failure to achieve this would trigger a **€1B–€2B capital stranding risk** (Risk 3) and compound with the **RTE timeline buffer gap**; monitor via monthly updates from the Grid & Power Procurement Specialist, with a contingency to re-negotiate tenant commitments if confirmation lags beyond 6 months.


2. **KPI: Local Workforce Integration Rate** (Target: 75% non-specialized labor from regional apprentices by Phase 1 COD) – Underperformance here risks **6–12 month schedule delays** (Review Issue 3) and undermines the **Social License** strategy; track through EPC compliance reports and adjust training budgets or contractor incentives quarterly to maintain alignment with the 75% mandate.


3. **KPI: Sovereign Tenant Revenue Penetration** (Target: 60% of Phase 2 capacity committed to DGSI/ANSSI-approved workloads) – Failure to meet this threshold would **invalidate the 9 GW viability** and compound with the **Tenant Acquisition Trigger Threshold** risk; validate via bi-annual DGSI engagement sessions and adjust hardware procurement strategies to prioritize sovereign-compatible vendors if penetration falls below 45%.


## Review 7: Report Objectives

1. **Primary Objectives and Deliverables** are to conduct a rigorous, skeptical 'red-team' feasibility assessment of the 9 GW hyperscale plan and deliver quantified data gaps and critical risk mitigation strategies for immediate Phase 0 execution.


2. **Intended Audience and Key Decisions** target Senior Investors, Government Partners, and Infrastructure Stakeholders to inform the continued pursuit of the 'Pragmatic Scale-Up' path, specifically validating capital allocation sequencing (Grid vs. Tenant Triggers) and the fragmented land assembly modality.


3. **Version 2 Improvement** will differ from Version 1 by integrating concrete, validated milestones—specifically incorporating the quantified RTE upgrade timelines, final budgeted holding costs for the 80% land buffer, and the finalized local workforce velocity roadmap—to provide a realistic versus optimistic timeline forecast.


## Review 8: Data Quality Concerns

1. **Critical Area: RTE Upgrade Completion Timeline** is insufficient because the 36-month assumption is unvalidated, which directly exposes Phase 1 capital to being stranded if RTE takes longer to affirm 3 GW capacity, potentially delaying revenue realization and triggering a **Phase 2 FID halt**; validation requires engaging the **European Energy Regulation Specialist** immediately to secure a formally documented RTE lead-time expectation for post-collateral commitment.


2. **Critical Area: Land Holding Cost Model Accuracy** is insufficient as the budget for the 128.8 km² buffer lacks precise cadastral data, risking a **€1.3 Billion CAPEX overrun** if property tax estimates are wrong, which would destabilize the initial **Phase 1 financing**; this requires the **Large-Scale Land & Civil Works Model Modeler** to immediately finalize an 18-month holding cost ledger based on interpolated local tax rates and legal counsel validation.


3. **Critical Area: DGSI/ANSSI Hardware Isolation Requirements** are insufficiently detailed, which directly jeopardizes access to premium sovereign revenue streams and compounds the **Tenant Acquisition Threshold** risk; validation mandates that the **Regulatory & Sovereignty Compliance Lead** must secure a written DGSI confirmation on the acceptability of the Phase 1 isolation schematics within a **10-month review window** to prevent operational non-compliance.


## Review 9: Stakeholder Feedback

1. **Critical Feedback Needed: RTE Upgrade Funding Mechanism** is critical because the Grid Specialist must confirm whether RTE collateral requirements align with the planned tenant revenue trigger (60% committed), as a mismatch could delay binding grid confirmation by months, halting Phase 2 FID and risking **loss of tenant anchor interest**; obtain feedback via a formal joint session with RTE/CFO to confirm funding sequence compatibility before Q4 2026.


2. **Critical Feedback Needed: Prefectural Tolerance for Land Use Rationalization** is necessary because the viability of the hyper-dense model is contingent on local acceptance of the 80% buffer dedication, and misunderstanding tolerance could lead to **mandated footprint reduction to ~6 GW capacity**; request a formal 'intent to approve' letter from the **DREAL/Prefectural Lead** on the 30% permanent offset structure by Q1 2027.


3. **Critical Feedback Needed: Anchor Tenant Requirements for Inter-Cluster Latency** is critical as the commitment for Phase 2 depends on sub-2ms RTT, but the **Telecoms Architect** needs definitive SLAs from anchor tenants regarding acceptable latency variance across the split campus; incorporate this feedback by **requiring formal latency SLAs in all pre-Phase 2 LOIs** to ensure technical requirements drive fiber investment decisions.


## Review 10: Changed Assumptions

1. **Re-evaluation Assumption: Interest Rate Environment for Financing** needs updating, as prolonged high rates assumed in initial modeling could increase debt servicing costs on the €5B–€10B Phase 1 CAPEX by **100–200 basis points**, making the 60% tenant commitment threshold for Phase 2 less attractive to lenders; review by the **Financial Controller** should stress-test the ROI against a sustained 5% long-term cost of capital by Q4 2026.


2. **Re-evaluation Assumption: Hardware Procurement Lead Time for GPUs/TPUs** requires adjustment, as global AI demand may have pushed specialized hardware lead times beyond standard projections, directly impacting the **Phase 1 COD timeline beyond 36 months**; the **Hyperscale Data Center Design & Cooling Engineer** must confirm vendor delivery schedules against an updated 18-month procurement window to see if this constrains the overall PUE validation period.


3. **Re-evaluation Assumption: Viability of Local Heat Reuse Anchors** must be revisited, as the lukewarm initial assessment might have changed if regional industrial capacity grew; if a major partner capable of absorbing 500 MWth materializes, it could significantly boost **Social License** and justify the initial CAPEX for heat reuse trenches, potentially **accelerating permitting maturity**; the **Regional Industrial Ecosystem Planner** should conduct a rapid follow-up survey of Dunkirk/Cambrai industrial players to confirm current off-take appetite by Q1 2027.


## Review 11: Budget Clarifications

1. **Critical Clarification: Finalized Phase 0 Holding Cost Allocation** is necessary because the unbudgeted cost for securing the 128.8 km² buffer could derail early financing covenants if not formalized, impacting the **Phase 1 CAPEX by up to €1.3 Billion**; this requires the **Financial Controller** to obtain the legally validated 18-month holding cost model from the Land Modeler and formally ring-fence this amount in the initial budget baseline by 2026-09-01.


2. **Critical Clarification: Contingency Funding for EPC Premium on Workforce Mandate** must be quantified, as relying on the 75% local hiring target (Decision 8) is projected to incur an **average 5% premium on civil construction costs** across Phase 1; the **Program Director - Construction & Logistics** (the missing role) must be hired to deliver a firm cost estimate for this premium, creating a dedicated contingency line item within the €5B–€10B Phase 1 budget.


3. **Critical Clarification: Cost of Upfront DGSI Isolation Measures** needs clarification, as compliance with early security partitioning (Decision 3) requires specialized physical segregation (e.g., dedicated substation feeder for Substation 1), creating an **unspecified upfront cost** that competes with grid study payments; resolution requires the **Chief Infrastructure Strategist** to finalize the top-level security schematic and secure three competitive fixed bids for the isolation infrastructure to establish a definitive budget for this pre-FID expense.


## Review 12: Role Definitions

1. **Key Role: Program Director - Construction & Logistics** must be clarified as essential because the lack of an on-site manager overseeing fragmented builds across multiple zones risks extending the **Phase 1 timeline beyond 3 years** due to scheduling conflicts and poor contractor integration with the workforce mandate; the actionable step is to immediately assign this role (likely FTE) responsibility for joint sign-off on physical milestone completion with the Chief Strategist by Q4 2026.


2. **Key Role: Water Resource Engineer/Consultant** must be explicitly defined and assigned (likely IC) because the failure to secure water usage compliance from ARS, despite dry-cooling mandates, could lead to immediate regulatory curtailment (Risk 6), impacting **PUE SLA targets** and potentially incurring **€1M–€5M penalty per week of curtailment**; the actionable step is to contract this specialist immediately to liaise solely with the Regulatory Lead on water permitting strategy through Year 2.


3. **Key Role: Technical Verifier/QA Auditor** needs clarification, as this independent role is vital for bridging the gap between complex liquid cooling design (PUE 1.15) and actual operational performance, where failure risks **tenant SLA breaches and OPEX inflation** exceeding €5M annually; the actionable step is to mandate the **Chief Infrastructure Strategist** to issue an RFP for this independent verification service by Q2 2027 to cover the Phase 1 system burn-in phase.


## Review 13: Timeline Dependencies

1. **Sequencing Concern: Grid Study Funding vs. Tenant Commitments** is critical because pre-funding RTE studies (Action on Decision 1) without the 60% tenant commitment threshold (Decision 4) risks **stranding initial collateral** if tenants retract, or delaying Phase 1 FID if tenants wait for better grid certainty; the concrete action is to strictly sequence the **Pre-Paid RTE fee submission only after the first 30% of Phase 1 commercial LOIs are executed**, irrespective of the optimal technical timeline.


2. **Sequencing Concern: Workforce Skill Uplift vs. Heavy Civil Start** is a major timeline risk, as commencing major construction before local skills are developed (Review Issue 3) forces reliance on expensive international labor, immediately **inflating Phase 1 CAPEX by the 5% EPC premium**; the concrete action is to mandate that the Construction Director **stage heavy civil mobilization only once the Workforce Orchestrator certifies a minimum 25% cohort of trained local supervisors** is active on site.


3. **Sequencing Concern: Permanent Buffer Zoning vs. Land Holding Budgeting** is a sequencing failure; finalizing the legally binding 30% permanent offset (Mitigation on Risk 7) before the **18-month holding cost budget** is approved (Review Issue 2) risks making a non-negotiable commitment without securing the necessary capital, potentially **stalling the entire land assembly contingent on the 80% buffer acceptance**; the concrete action is to require the **Land Modeler and Financial Controller to jointly finalize and approve the holding cost budget item before submitting the 30% permanent offset deed documentation to DREAL**.


## Review 14: Financial Strategy

1. **Long-Term Financial Question: Exit Strategy for Non-Sovereign Phase 1 Capacity** is crucial, as failing to define contract terms for non-sovereign tenants after the initial lease period could lead to **revenue discontinuity post-Year 7**, severely impacting the long-term ROI timeline; this interacts with the **Security Isolation** assumption by failing to define transition pathways, requiring the Strategy Lead to develop a **mandatory 5-year renewal/exit clause template** for all Phase 1 commercial leases now.


2. **Long-Term Financial Question: Full 9 GW Scale-Up Financing Structure** must be clarified, as relying on syndicated debt based on 60% tenant commitment (Decision 4) may prove insufficient if RTE demands the **full €2 Billion regional grid reinforcement collateral** upfront (Question 2), potentially requiring a mix of equity or non-recourse project bonds; the action is for the **Financial Controller to conduct a structured stress test scenario** in Q1 2027 modeling a 50/50 debt/equity split contingent on RTE requiring full collateral before tenant commitment is met.


3. **Long-Term Financial Question: Monetization of Waste Heat Revenue Stream Longevity** must be clarified, as low-margin Heat Reuse contracts (Decision 6) may not sufficiently cover the operational costs of dedicated infrastructure, creating an **annual OpEx drag indefinitely** if not structured correctly; the **Socio-Economic Orchestrator** must finalize target IRR rates for heat reuse contracts that offset associated OpEx plus a minimum 2% margin to ensure this public benefit does not erode overall profitability.


## Review 15: Motivation Factors

1. **Motivation Factor: Visible Progress on Local Social License** is essential, as failure to secure visible local wins (skilled jobs, heat reuse feasibility) could lead to **accelerated local opposition and judicial challenges (Risk 7)**, translating into multiple 6-12 month permitting freezes; the actionable recommendation is to mandate the **Social License Orchestrator to report quarterly on tangible local employment metrics and funding distribution** from the skills academy, making success visible to all stakeholders.


2. **Motivation Factor: De-risking the RTE Dependency** is crucial, as consistent progress on confirming RTE capacity (despite the deferral strategy) combats team morale erosion caused by reliance on external schedules; if momentum is lost, the **Phase 2 FID timeline could slip by 18+ months**, compounding the **stranded capital risk (Risk 3)**; the actionable recommendation is for the Chief Strategist to establish a **Go/No-Go KPI dashboard tracking RTE alignment** as the single highest priority metric reviewed weekly.


3. **Motivation Factor: Reinforcement of the 'Pragmatic Scale-Up' Rationale** must be maintained, as the deliberate slowdowns required to validate thresholds (like 60% tenant commitment) risk frustration among those pushing for speed to market, potentially leading to key personnel bypassing financial gates prematurely; the actionable recommendation is to schedule **quarterly Board reviews that explicitly celebrate the avoided risks** (e.g., cost saved by deferring grid collateral) justifying the disciplined, phased approach.


## Review 16: Automation Opportunities

1. **Automation Opportunity: Land Use Cadastral Verification** regarding the 161 km² footprint can save significant manual effort, estimated at **~6-9 person-months of Land Modeler time** across Phase 0/1 by automating legal boundary cross-referencing against GIS data; this directly buffers the **Land Assembly timeline** by accelerating zoning clearance, requiring the Land Modeler to **integrate GIS data directly with a commercial land registry API** for automated easement drafting validation.


2. **Automation Opportunity: PPA Compliance Tracking against Tenant Triggers** in the Tenant Acquisition phase can streamline the critical task of validating the 60% trigger, saving the **Financial Controller potentially 3-4 weeks of manual reconciliation per quarter**, preventing delays in Phase 2 FID; this should be addressed by implementing an **ERP module that automatically reconciles executed tenant contracts against required GW thresholds** and flags variance in real-time for the Chief Strategist.


3. **Automation Opportunity: DGSI/ANSSI Documentation Cross-Referencing** for security compliance can drastically reduce manual auditing time, estimated to save **2-3 months in the DGSI review cycle** (Risk 5 mitigation), which directly eases pressure on the Phase 1 construction timeline; the recommended action is to build a **centralized Digital Twin database tagged against specific DGSI requirement clauses** for automated report generation and gap analysis for the Regulatory Lead.

# Questions & Answers

**Q1: What are the critical levers identified in the project for achieving the 9 GW target?**

A1: The critical levers include Power Capacity (Grid Integration, Power Procurement Sequencing) and Revenue Certainty (Tenant Trigger Thresholds). These elements are essential for establishing the project's physical and financial foundation, ensuring the engineering and financial viability of reaching the 9 GW capacity.

**Q2: What risks are associated with the Grid Integration and Power Source Commitment decision?**

A2: The primary risks include substantial sunk costs if the project commits to the 9 GW target prematurely without securing binding transmission allocation from RTE. This could lead to delays and cost overruns due to RTE's regional transmission upgrades, which are outside the developer's control.

**Q3: How does the Land Assembly Modality and Footprint Rationalization decision impact project feasibility?**

A3: This decision impacts feasibility by determining the physical geography of the campus. Attempting to assemble a contiguous 161 km² parcel poses challenges in local planning consent and could lead to multi-year litigation delays. A split-campus model may expedite land control but complicates security and logistics.

**Q4: What is the significance of the Tenant Acquisition Trigger Threshold in the project?**

A4: The Tenant Acquisition Trigger Threshold controls the pace of scaling from 1 GW to 3 GW, requiring secured revenue contracts before expanding infrastructure. This approach protects the project from overbuilding but may slow down market capture, risking first-mover advantage.

**Q5: What ethical considerations are involved in the project, particularly regarding local workforce sourcing?**

A5: The project mandates that 75% of non-specialized construction labor hours be filled by local apprentices to secure social license and mitigate opposition. This commitment aims to convert potential NIMBYism into local support but introduces management overhead and quality control risks.

**Q6: What are the potential consequences of failing to secure binding transmission allocation from RTE before Phase 1 financing closes?**

A6: Failing to secure binding transmission allocation could result in stranded capital investments of €1B–€2B for Phase 0 and Phase 1 if tenants withdraw. This could halt the project entirely, jeopardizing the feasibility of the entire 9 GW target.

**Q7: How does the project plan to address public opposition related to land use and environmental impact?**

A7: The project plans to mitigate public opposition by designating 80% of the land as buffers and community integration spaces, which aims to provide tangible local benefits and reduce environmental concerns. Additionally, a local workforce sourcing mandate is intended to foster community support.

**Q8: What are the implications of the project's reliance on local workforce sourcing for construction?**

A8: Relying on local workforce sourcing may enhance community support and social license but could also introduce risks related to skill shortages and management overhead. This could lead to delays in construction timelines and increased costs if local training programs do not meet the project's needs.

**Q9: What are the risks associated with the project's ambitious PUE targets, and how might they affect tenant contracts?**

A9: The project aims for a PUE of 1.20, but failing to meet this target could lead to increased operational costs and potential breaches of efficiency clauses in tenant contracts. This could jeopardize tenant relationships and revenue streams, particularly if costs exceed expectations.

**Q10: What ethical considerations arise from the project's heat reuse strategy, and how does it aim to benefit the local community?**

A10: The heat reuse strategy aims to monetize waste heat by providing it to local industries, transforming a potential liability into a community asset. However, it raises ethical considerations regarding the upfront capital costs and the complexity of securing long-term contracts, which may not yield immediate benefits for the community.

# Premortem

A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The 36-month minimum lead time for RTE transmission upgrades following collateral payment commitment is sufficient to avoid blocking the Phase 2 expansion FID based on the 60% tenant trigger. | Engage the European Energy Regulation Specialist to produce a formal, documented range estimate (in months) for 3 GW RTE upgrade completion following funding commitment, comparing it against the mandated window set by the 60% tenant trigger. | The specialist confirms that the minimum RTE completion timeline exceeds 36 months when factoring in typical French administrative latency post-collateral payment. |
| A2 | The proposed 'hyper-dense development model' (80% permanent buffer/reserve) will be legally and politically accepted by DREAL/Prefectural Authorities without requiring a reduction of the buildable area below the planned 32.2 km². | Submit the legal structure defining the 30% 'Permanent Ecological Offset' and the 18-month renewal mechanism for the 50% 'Expansion Reserve' to the French Land Use Lawyer for an immediate assessment of judicial risk. | The lawyer advises that the proposed 30% permanent offset is insufficient to guarantee zoning acceptance without additional, immediate, non-budgeted land compensation or facing litigation that stalls the process past Q2 2027. |
| A3 | The ambitious 75% local workforce upskilling mandate can be achieved within the 3-year Phase 1 schedule without incurring more than a 5% premium on civil construction costs due to quality control overhead or contractor resistance. | Require the EPC bidder interviews to include mandatory scoring weights (min 15%) based on their auditable plan to meet the 75% local hiring quota, and mandate the Social License Orchestrator calculate the cost contingency based on initial RFPs. | Proposed, locked-in EPC contracts show an average required premium exceeding 7% to meet the 75% mandate, or the Workforce Orchestrator confirms local supply cannot meet Q4 2026 supervisory needs. |
| A1 | The 36-month minimum lead time for RTE transmission upgrades following collateral payment commitment is sufficient to avoid blocking the Phase 2 expansion FID based on the 60% tenant trigger. | Engage the European Energy Regulation Specialist to produce a formal, documented range estimate (in months) for 3 GW RTE upgrade completion following funding commitment, comparing it against the mandated window set by the 60% tenant trigger. | The specialist confirms that the minimum RTE completion timeline exceeds 36 months when factoring in typical French administrative latency post-collateral payment. |
| A2 | The proposed 'hyper-dense development model' (80% permanent buffer/reserve) will be legally and politically accepted by DREAL/Prefectural Authorities without requiring a reduction of the buildable area below the planned 32.2 km². | Submit the legal structure defining the 30% 'Permanent Ecological Offset' and the 18-month renewal mechanism for the 50% 'Expansion Reserve' to the French Land Use Lawyer for an immediate assessment of judicial risk. | The lawyer advises that the proposed 30% permanent offset is insufficient to guarantee zoning acceptance without additional, immediate, non-budgeted land compensation or facing litigation that stalls the process past Q2 2027. |
| A3 | The ambitious 75% local workforce upskilling mandate can be achieved within the 3-year Phase 1 schedule without incurring more than a 5% premium on civil construction costs due to quality control overhead or contractor resistance. | Require the EPC bidder interviews to include mandatory scoring weights (min 15%) based on their auditable plan to meet the 75% local hiring quota, and mandate the Social License Orchestrator calculate the cost contingency based on initial RFPs. | Proposed, locked-in EPC contracts show an average required premium exceeding 7% to meet the 75% mandate, or the Workforce Orchestrator confirms local supply cannot meet Q4 2026 supervisory needs. |
| A4 | The reliance on initial non-restricted, commercial-grade hardware for the first 500 MW will not necessitate costly retrofitting or operational segmentation when the DGSI/ANSSI requirements for the future sovereign partition (2 GW) are finalized. | Secure a written DGSI 'No Retrofit Waiver' confirming that the proposed physical segregation (Substation 1 isolation) for the initial 500 MW load is sufficient to accommodate the final sovereign security layering without internal hardware modification. | DGSI states that physical segregation is insufficient, requiring dedicated, nationally approved accelerators or a physical rebuild of the isolation boundary within the first 500 MW facility, invalidating pre-lease assumptions. |
| A5 | The projected PUE degradation from using dry coolers (mandated by water scarcity) for Phase 1 will remain acceptably low (PUE ≤ 1.20) even under peak ambient temperature conditions in Hauts-de-France. | The Hyperscale Thermal Design Engineer must complete CFD modeling validating the 1.20 PUE target using manufacturers' dry-cooler performance curves under the 99th percentile (hottest observed) ambient conditions for the Dunkirk/Cambrai zone. | CFD analysis shows that under 99th percentile conditions, the required dry-cooling capacity forces the operational PUE for Phase 1 to average 1.25 or higher, exposing the project to energy cost overruns and potential tenant SLA breaches. |
| A6 | Long-term, low-margin Heat Reuse Offtake contracts (Decision 6) can be structured to cover the dedicated operational OpEx of the required heat rejection infrastructure plus a minimum 2% net margin, ensuring the social benefit does not become a perpetual drag on overall project profitability. | The Socio-Economic Orchestrator must present initial Heads of Terms from at least one viable industrial partner in the Dunkirk cluster where the implied IRR on the dedicated heat transfer CAPEX exceeds 4.0% (to cover OpEx + 2% margin). | All initial off-take proposals yield an IRR below 2.0% when accounting for pipeline maintenance, pumping energy OpEx, and long-term regulatory risk, indicating the social benefit is a net cost center. |
| A1 | The 36-month minimum lead time for RTE transmission upgrades following collateral payment commitment is sufficient to avoid blocking the Phase 2 expansion FID based on the 60% tenant trigger. | Engage the European Energy Regulation Specialist to produce a formal, documented range estimate (in months) for 3 GW RTE upgrade completion following funding commitment, comparing it against the mandated window set by the 60% tenant trigger. | The specialist confirms that the minimum RTE completion timeline exceeds 36 months when factoring in typical French administrative latency post-collateral payment. |
| A2 | The proposed 'hyper-dense development model' (80% permanent buffer/reserve) will be legally and politically accepted by DREAL/Prefectural Authorities without requiring a reduction of the buildable area below the planned 32.2 km². | Submit the legal structure defining the 30% 'Permanent Ecological Offset' and the 18-month renewal mechanism for the 50% 'Expansion Reserve' to the French Land Use Lawyer for an immediate assessment of judicial risk. | The lawyer advises that the proposed 30% permanent offset is insufficient to guarantee zoning acceptance without additional, immediate, non-budgeted land compensation or facing litigation that stalls the process past Q2 2027. |
| A3 | The ambitious 75% local workforce upskilling mandate can be achieved within the 3-year Phase 1 schedule without incurring more than a 5% premium on civil construction costs due to quality control overhead or contractor resistance. | Require the EPC bidder interviews to include mandatory scoring weights (min 15%) based on their auditable plan to meet the 75% local hiring quota, and mandate the Social License Orchestrator calculate the cost contingency based on initial RFPs. | Proposed, locked-in EPC contracts show an average required premium exceeding 7% to meet the 75% mandate, or the Workforce Orchestrator confirms local supply cannot meet Q4 2026 supervisory needs. |
| A4 | The reliance on initial non-restricted, commercial-grade hardware for the first 500 MW will not necessitate costly retrofitting or operational segmentation when the DGSI/ANSSI requirements for the future sovereign partition (2 GW) are finalized. | Secure a written DGSI 'No Retrofit Waiver' confirming that the proposed physical segregation (Substation 1 isolation) for the initial 500 MW load is sufficient to accommodate the final sovereign security layering without internal hardware modification. | DGSI states that physical segregation is insufficient, requiring dedicated, nationally approved accelerators or a physical rebuild of the isolation boundary within the first 500 MW facility, invalidating pre-lease assumptions. |
| A5 | The projected PUE degradation from using dry coolers (mandated by water scarcity) for Phase 1 will remain acceptably low (PUE ≤ 1.20) even under peak ambient temperature conditions in Hauts-de-France. | The Hyperscale Thermal Design Engineer must complete CFD modeling validating the 1.20 PUE target using manufacturers' dry-cooler performance curves under the 99th percentile (hottest observed) ambient conditions for the Dunkirk/Cambrai zone. | CFD analysis shows that under 99th percentile conditions, the required dry-cooling capacity forces the operational PUE for Phase 1 to average 1.25 or higher, exposing the project to energy cost overruns and potential tenant SLA breaches. |
| A6 | Long-term, low-margin Heat Reuse Offtake contracts (Decision 6) can be structured to cover the dedicated operational OpEx of the required heat rejection infrastructure plus a minimum 2% net margin, ensuring the social benefit does not become a perpetual drag on overall project profitability. | The Socio-Economic Orchestrator must present initial Heads of Terms from at least one viable industrial partner in the Dunkirk cluster where the implied IRR on the dedicated heat transfer CAPEX exceeds 4.0% (to cover OpEx + 2% margin). | All initial off-take proposals yield an IRR below 2.0% when accounting for pipeline maintenance, pumping energy OpEx, and long-term regulatory risk, indicating the social benefit is a net cost center. |
| A7 | Securing necessary right-of-way (ROW) easements for the geographically diverse terrestrial fiber routes required for Phase 1 latency targets (Decision 5) can be acquired and contracted within the standard 12-month mobilization window set for site civil works. | The Telecoms & Connectivity Architect must deliver 100% contracted ROW agreements for the primary terrestrial links to Paris and Brussels, or verify that these contracts are in final legal review stage with all counterparties, prior to Phase 1 construction FID. | ROW negotiations with incumbent carriers and local landowners face localized injunctions or demands for unique, non-standard compensation that delay final contracting by more than 4 months beyond the construction schedule baseline. |
| A8 | The necessary advanced, multi-axis robotic assembly and deployment protocols for direct-to-chip liquid cooling manifolds and piping infrastructure are mature, sourced from a single qualified vendor, and do not require unforeseen custom engineering during the Phase 1 1 GW ramp-up. | The Hyperscale Data Center Design & Cooling Engineer must finalize contracts with a single vendor for 100% of the Phase 1 liquid cooling infrastructure (piping, manifold arrays, quick-connects) that includes firm delivery dates 12 months in advance of required installation start. | The primary vendor declares force majeure or requires a 6-month re-engineering process due to unforeseen site conditions or complexity related to integrating the cooling manifolds across the fragmented, non-contiguous industrial zones. |
| A9 | The initial commercial/non-sovereign leases signed for Phase 1 capacity (500 MW - 1 GW) will maintain an average contracted revenue yield per MW that is at least 15% higher than the projected minimum revenue from a fully secured sovereign AI workload contract. | The Strategy Lead must present executed early-stage Leasing Agreements that demonstrate an average EUR/MW/year yield that exceeds the NPV-adjusted minimum sovereign rate by the required margin, with no more than 20% of capacity secured via performance guarantees instead of take-or-pay. | The executed Phase 1 leases average less than 5% yield differential against the modeled sovereign baseline, suggesting the market is not currently bidding sufficient premium for fast-to-market commercial space. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Buffer Budget Black Hole | Process/Financial | A2 | Financial Controller & Currency Risk Manager | CRITICAL (20/25) |
| FM2 | The RTE Paralysis: Stranded Collateral Risk | Technical/Logistical | A1 | Grid & Power Procurement Specialist | CRITICAL (25/25) |
| FM3 | Local Mandate Backlash and The Skill Mismatch Delay | Market/Human | A3 | Social License & Community Benefits Orchestrator | CRITICAL (16/25) |
| FM4 | The Buffer Budget Black Hole | Process/Financial | A1 | Financial Controller & Currency Risk Manager | CRITICAL (20/25) |
| FM5 | Local Mandate Backlash and The Skill Mismatch Delay | Technical/Logistical | A3 | Social License & Community Benefits Orchestrator | CRITICAL (16/25) |
| FM6 | Sovereign Contamination Halts Commercial Leasing | Market/Human | A4 | Regulatory & Sovereignty Compliance Lead | CRITICAL (20/25) |
| FM7 | The Buffer Budget Black Hole | Process/Financial | A1 | Financial Controller & Currency Risk Manager | CRITICAL (20/25) |
| FM8 | Terrestrial Fiber Gridlock Cripples Synchronization | Technical/Logistical | A7 | Telecoms & Connectivity Architect | CRITICAL (20/25) |
| FM9 | Anchor Tenants Downgrade Yield Expectations | Market/Human | A9 | Strategy & Regulatory Affairs | CRITICAL (16/25) |


### Failure Modes

#### FM1 - The Buffer Budget Black Hole

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: Financial Controller & Currency Risk Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project critically relies on reserving 80% of the 161 km² footprint for buffers/reserves to satisfy social license and initial zoning requirements. By assuming this land can be held indefinitely without fully budgeting its annual carrying cost (taxes, basic maintenance, legal fees), the Phase 1 CAPEX is deceptively low. When judicial or prefectural review demands immediate, binding financial dedication to the 30% permanent offset and an 18-month holding budget for the 50% reserve, the unbudgeted capital call (estimated at >€1.3 Billion) is triggered prematurely. This forces a draw on committed financing lines intended for critical long-lead power equipment, leading to immediate covenant breaches with lenders who assumed a higher proportion of infrastructure commitment versus land holding cost, resulting in a halt of construction drawings release.

##### Early Warning Signs
- The Land Modeler reports holding cost variance >15% against the initial 18-month budget estimate by M+6.
- The Financial Controller flags an upcoming draw request reduction greater than 5% due to land holding costs overriding infrastructure funding.
- DREAL demands a finalized, legally binding escrow account for the 30% permanent offset before granting EIA approval.

##### Tripwires
- Unbudgeted Land Holding Cost Exceeds €500 Million
- DREAL Delays Zoning Approval by >90 Days Pending Buffer Capital Confirmation

##### Response Playbook
- Contain: Immediately place an 18-month moratorium on securing ROW easements for non-essential Phase 2 fiber/grid ties to reallocate immediate capital to the land holding escrow.
- Assess: Financial Controller must re-run Phase 1 financing stress test with a €1.3B land holding cost baked into the initial CAPEX baseline to determine current covenant breach position.
- Respond: Approach primary creditors with a re-baselined Phase 1 budget, formally requesting a capital reallocation waiver by sacrificing non-critical internal R&D budget lines.


**STOP RULE:** Final holding cost budget for the 128.8 km^2 buffer exceeds 15% of the total Phase 1 CAPEX budget, mandating a formal review of the 9 GW strategic viability.

---

#### FM2 - The RTE Paralysis: Stranded Collateral Risk

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A1
- **Owner**: Grid & Power Procurement Specialist
- **Risk Level:** CRITICAL 25/25 (Likelihood 5/5 × Impact 5/5)

##### Failure Story
The project intentionally defers funding major RTE transmission upgrades (required for 3 GW expansion) until the 60% tenant revenue trigger is met (Pragmatic Scale-Up). However, if the assumed 36-month RTE completion window proves overly optimistic—and expert consultation reveals a typical 48-month timeline—the grid will not be ready for Phase 2 capacity when tenants arrive. Tenants, seeing power scarcity, will balk at 60% commitments, causing the trigger to fail. If the landlord proceeds to pay the initial financial collateral for the 3 GW studies based on the old timeline, that collateral becomes stranded capital €1B-€2B, while the Phase 1 site runs out of expansion room, resulting in a complete halt of the 9 GW scaling ambition and massive liquidity drag.

##### Early Warning Signs
- European Energy Regulation Specialist reports minimum RTE upgrade lead time > 40 months in formal documentation.
- RTE demands collateral for Phase 2 studies that significantly exceeds the budgeted allowance for pre-FID activities.
- Phase 1 tenant commitment rate stagnates below 40% for two consecutive quarters, indicating doubt about future expansion availability.

##### Tripwires
- RTE Confirmed Upgrade Timeline Exceeds 42 Months Post-FID
- Phase 2 Tenant Commitment Falls Below 50% by M+18

##### Response Playbook
- Contain: Immediately pause all non-essential work related to Phase 2 infrastructure planning (e.g., fiber route acquisition for Phase 2) to conserve liquidity.
- Assess: Grid Specialist must determine the exact delta cost and time required to secure a binding RTE commitment for only 1.5 GW (Phase 2 Lite) based on current tenant status.
- Respond: Strategy Lead must present the Board with a 'Grid Confirmed' vs. 'Tenant Confirmed' pivot scenario, prioritizing immediate collateral release if grid certainty can be bought early.


**STOP RULE:** RTE officially publishes an interconnection schedule that pushes Phase 2 (3 GW) readiness past Year 7, invalidating the 15-year 9 GW timeline.

---

#### FM3 - Local Mandate Backlash and The Skill Mismatch Delay

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Social License & Community Benefits Orchestrator
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project mandates a 75% utilization of local upskilled apprentices to secure critical social license and favorable permitting velocity. The failure mode occurs when the reality of local technical school capabilities conflicts with the aggressive Phase 1 construction schedule (3 years). High reliance on internal team optimism (assuming training works perfectly) leads to scheduling specialized liquid cooling and high-security isolation with under-skilled labor. This technical deficit causes cascading quality failures, forcing EPC contractors to implement expensive mitigation (hiring premium international specialists) exceeding the contingency budget, or, worse, causing major quality breaches in the critical PUE/security isolation layers. This results in a 6-12 month delay in achieving 1.20 PUE validation and DGSI review readiness, leading to tenant SLA breaches on early capacity.

##### Early Warning Signs
- EPC contractor submits formal notice citing 75% local hiring mandate as a cause for a 45-day schedule slip.
- The calculated premium cost for integrating oversight management exceeds the €40M contingency budget by 20%.
- PUE validation tests repeatedly fail to break stagnation above 1.25 due to novice installation errors in cooling loop integrity.

##### Tripwires
- Phase 1 Construction Schedule Slips by > 60 days due to Labor Shortages
- Local Workforce Integration Rate Falls Below 50% by M+15

##### Response Playbook
- Contain: Immediately halt mobilization of subsequent construction crews that rely heavily on specialized liquid cooling skills until the primary cohort demonstrates competence.
- Assess: Social License Orchestrator must quantify the exact OPEX penalty exposure from the PUE degradation caused by the skill gap, comparing it against the cost of importing immediate supplemental senior labor.
- Respond: Initiate the 'Premium Labor Fly-In' contingency plan, accepting the immediate budget overrun to stabilize the schedule, while simultaneously lobbying local authorities to relax the 75% mandate temporarily in exchange for increased funding into permanent training infrastructure.


**STOP RULE:** The operational PUE validation for the first 250 MW fails to reach 1.25 within 9 months of initial commissioning, indicating a permanent, unrecoverable technical/skills deficit.

---

#### FM4 - The Buffer Budget Black Hole

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Financial Controller & Currency Risk Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project critically relies on reserving 80% of the 161 km² footprint for buffers/reserves to satisfy social license and initial zoning requirements. By assuming this land can be held indefinitely without fully budgeting its annual carrying cost (taxes, basic maintenance, legal fees). When judicial or prefectural review demands immediate, binding financial dedication to the 30% permanent offset and an 18-month holding budget for the 50% reserve, the unbudgeted capital call (estimated at >€1.3 Billion) is triggered prematurely. This forces a draw on committed financing lines intended for critical long-lead power equipment, leading to immediate covenant breaches with lenders who assumed a higher proportion of infrastructure commitment versus land holding cost, resulting in a halt of construction drawings release.

##### Early Warning Signs
- The Land Modeler reports holding cost variance >15% against the initial 18-month budget estimate by M+6.
- The Financial Controller flags an upcoming draw request reduction greater than 5% due to land holding costs overriding infrastructure funding.
- DREAL Delays Zoning Approval by >90 Days Pending Buffer Capital Confirmation

##### Tripwires
- Unbudgeted Land Holding Cost Exceeds €500 Million
- DREAL Delays Zoning Approval by >90 Days Pending Buffer Capital Confirmation

##### Response Playbook
- Contain: Immediately place an 18-month moratorium on securing ROW easements for non-essential Phase 2 fiber/grid ties to reallocate immediate capital to the land holding escrow.
- Assess: Financial Controller must re-run Phase 1 financing stress test with a €1.3B land holding cost baked into the initial CAPEX baseline to determine current covenant breach position.
- Respond: Approach primary creditors with a re-baselined Phase 1 budget, formally requesting a capital reallocation waiver by sacrificing non-critical internal R&D budget lines.


**STOP RULE:** Final holding cost budget for the 128.8 km² buffer exceeds 15% of the total Phase 1 CAPEX budget, mandating a formal review of the 9 GW strategic viability.

---

#### FM5 - Local Mandate Backlash and The Skill Mismatch Delay

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A3
- **Owner**: Social License & Community Benefits Orchestrator
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project mandates a 75% utilization of local upskilled apprentices to secure critical social license and favorable permitting velocity. The failure mode occurs when the reality of local technical school capabilities conflicts with the aggressive Phase 1 construction schedule (3 years). High reliance on internal team optimism (assuming training works perfectly) leads to scheduling specialized liquid cooling and high-security isolation with under-skilled labor. This technical deficit causes cascading quality failures, forcing EPC contractors to implement expensive mitigation (hiring premium international specialists) exceeding the contingency budget, or, worse, causing major quality breaches in the critical PUE/security isolation layers. This results in a 6-12 month delay in achieving 1.20 PUE validation and DGSI review readiness, leading to tenant SLA breaches on early capacity.

##### Early Warning Signs
- EPC contractor submits formal notice citing 75% local hiring mandate as a cause for a 45-day schedule slip.
- The calculated premium cost for integrating oversight management exceeds the €40M contingency budget by 20%.
- PUE validation tests repeatedly fail to break stagnation above 1.25 due to novice installation errors in cooling loop integrity.

##### Tripwires
- Phase 1 Construction Schedule Slips by > 60 days due to Labor Shortages
- Local Workforce Integration Rate Falls Below 50% by M+15

##### Response Playbook
- Contain: Immediately halt mobilization of subsequent construction crews that rely heavily on specialized liquid cooling skills until the primary cohort demonstrates competence.
- Assess: Social License Orchestrator must quantify the exact OPEX penalty exposure from the PUE degradation caused by the skill gap, comparing it against the cost of importing immediate supplemental senior labor.
- Respond: Initiate the 'Premium Labor Fly-In' contingency plan, accepting the immediate budget overrun to stabilize the schedule, while simultaneously lobbying local authorities to relax the 75% mandate temporarily in exchange for increased funding into permanent training infrastructure.


**STOP RULE:** The operational PUE validation for the first 250 MW fails to reach 1.25 within 9 months of initial commissioning, indicating a permanent, unrecoverable technical/skills deficit.

---

#### FM6 - Sovereign Contamination Halts Commercial Leasing

- **Archetype**: Market/Human
- **Root Cause**: Assumption A4
- **Owner**: Regulatory & Sovereignty Compliance Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project assumes that the initial 500 MW commercial cluster can utilize non-restricted hardware and physical segregation (Substation 1) while the subsequent sovereign zone design is finalized and reviewed by DGSI/ANSSI. If DGSI rejects this intermediate quarantine state—stating that any shared infrastructure (e.g., common fiber entry point, shared utility feed to Substation 1) compromises future sovereign integrity—the entire Phase 1 build is retroactively deemed non-compliant for the premium state contract stream. Crucially, if the hardware already installed is deemed unacceptable for the sovereign roadmap, major commercial tenants demanding both commercial and sovereign workload capacity will perceive immediate operational risk or vendor lock-in, causing them to pause or retract their Phase 2 commitments (which rely on a clear revenue path), collapsing the 60% Tenant Acquisition Trigger Threshold before Phase 2 FID can occur.

##### Early Warning Signs
- DGSI/ANSSI review takes longer than 10 months without issuing formal feedback on hardware class guidelines.
- Phase 1 anchor tenants request contractual clauses that condition their expansion on a defined, high-confidence sovereign certification timeline.
- The Regulatory Lead reports that DGSI insists on an end-to-end, single-vendor hardware stack across the entire site.

##### Tripwires
- DGSI/ANSSI Review Passes 12 Months Without Written Security Protocol Confirmation
- Anchor Tenants Demand Legal Indemnity Regarding Future Sovereign Zone Segregation

##### Response Playbook
- Contain: Immediately cease procurement of any non-DGSI approved hardware slated for installation beyond the currently commissioned 100 MW load.
- Assess: Regulatory Lead performs a rapid gap-analysis contrasting current Phase 1 hardware specifications against known high-security baseline requirements, quantifying potential retrofitting costs.
- Respond: Strategy Lead initiates immediate negotiations with DGSI for a formal 'Work-In-Progress Security Waiver' for the existing 100 MW, while simultaneously shifting Phase 1 leasing focus away from hybrid clients toward purely commercial entities.


**STOP RULE:** DGSI issues a formal finding that the existing physical substation infrastructure utilized by Phase 1 non-sovereign tenants necessitates physical separation that requires decommissioning or modification of the Phase 1 power feed.

---

#### FM7 - The Buffer Budget Black Hole

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Financial Controller & Currency Risk Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project critically relies on reserving 80% of the 161 km² footprint for buffers/reserves to satisfy social license and initial zoning requirements. By assuming this land can be held indefinitely without fully budgeting its annual carrying cost (taxes, basic maintenance, legal fees). When judicial or prefectural review demands immediate, binding financial dedication to the 30% permanent offset and an 18-month holding budget for the 50% reserve, the unbudgeted capital call (estimated at >€1.3 Billion) is triggered prematurely. This forces a draw on committed financing lines intended for critical long-lead power equipment, leading to immediate covenant breaches with lenders who assumed a higher proportion of infrastructure commitment versus land holding cost, resulting in a halt of construction drawings release.

##### Early Warning Signs
- The Land Modeler reports holding cost variance >15% against the initial 18-month budget estimate by M+6.
- The Financial Controller flags an upcoming draw request reduction greater than 5% due to land holding costs overriding infrastructure funding.
- DREAL Delays Zoning Approval by >90 Days Pending Buffer Capital Confirmation

##### Tripwires
- Unbudgeted Land Holding Cost Exceeds €500 Million
- DREAL Delays Zoning Approval by >90 Days Pending Buffer Capital Confirmation

##### Response Playbook
- Contain: Immediately place an 18-month moratorium on securing ROW easements for non-essential Phase 2 fiber/grid ties to reallocate immediate capital to the land holding escrow.
- Assess: Financial Controller must re-run Phase 1 financing stress test with a €1.3B land holding cost baked into the initial CAPEX baseline to determine current covenant breach position.
- Respond: Approach primary creditors with a re-baselined Phase 1 budget, formally requesting a capital reallocation waiver by sacrificing non-critical internal R&D budget lines.


**STOP RULE:** Final holding cost budget for the 128.8 km² buffer exceeds 15% of the total Phase 1 CAPEX budget, mandating a formal review of the 9 GW strategic viability.

---

#### FM8 - Terrestrial Fiber Gridlock Cripples Synchronization

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Telecoms & Connectivity Architect
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Phase 1 relies upon securing diverse, low-latency terrestrial fiber paths (to Paris/Brussels) within the standard 12-month construction mobilization window to support synchronized AI workloads across the desired clustered sites. If ROW acquisition proves unexpectedly protracted due to opposition from regional landowners or incumbent carriers enforcing restrictive legacy contracts, the required low-latency paths cannot be stood up in time. This results in cross-cluster latency exceeding 2ms RTT, immediately violating the technical requirements necessary for high-frequency model synchronization. Tenants relying on this cluster connectivity will immediately breach their connectivity SLAs, leading to penalty claims and, critically, making the 60% threshold for Phase 2 expansion unachievable as tenants cite foundational infrastructure failure over capacity shortage.

##### Early Warning Signs
- Telecoms Architect reports that 50% of required Tier 1 terrestrial ROW agreements are still pending legal sign-off past M+9.
- Incumbent carriers file a formal objection with the local permitting authority contesting the proposed fiber conduit route segmentation.
- Internal latency tests between initial build clusters run >2.5ms RTT using provisional carrier access.

##### Tripwires
- ROW Acquisition Completion Rate for Phase 1 Fiber < 80% by M+15
- First Tenant Move-in Fails Latency SLA Test (>2.2ms RTT)

##### Response Playbook
- Contain: Immediately divert remaining Phase 1 fiber CAPEX away from secondary/tertiary carrier negotiations and concentrate 100% effort on co-funding the identified subsea landing point to establish *one* highly resilient, albeit higher-latency, path.
- Assess: Telecoms Architect must quantify the impact of a >2ms Latency baseline on the largest projected Phase 1 tenant's contractual penalty exposure.
- Respond: Strategy team must immediately present a 'Latency Cap Waiver' proposal to anchor tenants, offering short-term OpEx credits in exchange for accepting a temporary higher latency until long-haul redundancy can be established.


**STOP RULE:** Final latency between any two major cluster nodes exceeds 3.0ms RTT 6 months post-initial tenant activation.

---

#### FM9 - Anchor Tenants Downgrade Yield Expectations

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Strategy & Regulatory Affairs
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The 'Pragmatic Scale-Up' strategy is predicated on Phase 1 commercial leasing generating significantly higher yields (assumed 15% premium) than future sovereign contracts to cover early funding gaps and organizational drag. If the market softens or competing European capacity comes online faster than anticipated, anchor tenants will refuse to enter high-commitment take-or-pay deals that meet the 15% premium assumption. This forces the organization to accept revenue closer to the lower sovereign baseline. This lower-than-expected initial yield starves the operating budget, preventing the organization from meeting the required internal IRR hurdle for the massive capital expenditure required for the Heat Reuse network (Decision 6) and the high mandatory holding costs for the land buffer (A2), leading to immediate financial underperformance relative to investor covenants.

##### Early Warning Signs
- Average committed EUR/MW/year across initial ten signed LOIs is less than 8% above the modeled sovereign baseline.
- Tenant Acquisition progress stalls at 40% capacity utilization for three consecutive months post-M+24, indicating market saturation.
- Leasing team reports that 30% of capacity signed now relies on performance-based revenue guarantees rather than firm take-or-pay clauses.

##### Tripwires
- Phase 1 Committed Yield Falls Below 10% Premium to Sovereign Baseline
- Tenant Acquisition Progress Stalls Below 60% Committed Capacity by M+36

##### Response Playbook
- Contain: Immediately suspend marketing funds targeting non-anchor (smaller) commercial tenants and redirect all sales efforts toward leveraging existing relationships to secure one final 200 MW sovereign MoU negotiation.
- Assess: Financial Controller runs a revised model showing viability if the average IRR on the *entire* 9 GW project drops by 150 basis points due to sustained lower starting yields.
- Respond: Strategy Lead initiates discussions with anchor tenants proposing a 'Revenue Share Backstop' mechanism, where the developer agrees to forgo the final 2% developer margin on sovereign contracts if the commercial tenants meet an aggressive 1 GW utilization target by Year 4.


**STOP RULE:** The cumulative committed revenue for Phase 2 remains below 55% of the requirement 6 months past the scheduled Phase 2 FID date.


# Self Audit

Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 18 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 1 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is an ambitious, but entirely physical, industrial construction and utility-scale infrastructure development plan; its success depends on engineering, regulatory approval, finance, and resource availability, none of which violate known laws of physics. The plan correctly frames its feasibility around real-world constraints like land assembly, grid capacity (9 GW is a massive but achievable electrical load target), water availability, and permitting, none of which require breaking physics.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of extreme scale, fragmented land assembly, managing complex French sovereign compliance (DGSI/ANSSI), and coordinating multi-GW grid integration without independent precedents for this specific combination, as noted in the premortem assessment.

**Mitigation**: Project Management Office: Define and execute parallel validation tracks (Technical/Grid, Legal/Security, Market/Tenant) with global 'NO-GO' gates based on empirical validity and regulatory clearance within 60 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because several strategic concepts like 'Pragmatic Scale-Up', 'hyper-dense development model', and 'Sovereign AI Hub' are central drivers but lack explicit definition spanning inputs→output→value, as noted in the required analysis for Decision 2 and throughout the plan.

**Mitigation**: Chief Infrastructure Strategist & Project Architect: Produce three one-pagers defining the inputs, processes, and customer value for 'Pragmatic Scale-Up', 'Hyper-Dense Model', and 'Sovereign AI Hub' within 45 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan explicitly relies on making strategic trade-offs that significantly underestimate or ignore second-order consequences, particularly around land holding costs and regulatory timing. Pre-mortem FM1/FM4 highlights that failing to budget for the 80% buffer land holding cost (>$1.3B risk) is a critical financial failure mode, and FM2 highlights that deferring RTE funding confirmation risks stranding Phase 1 capital, showing critical gaps in risk cascade analysis.

**Mitigation**: Financial Controller & Currency Risk Manager: Immediately finalize the 18-month validated holding cost budget for 128.8 km² and present it to the Board for acceptance as mandatory Phase 1 CAPEX commitment within 30 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan embraces a strategy ("Pragmatic Scale-Up") that explicitly defers grid funding commitments until revenue triggers are met, yet external analysis flags that RTE upgrade lead times typical for 3 GW could exceed the time buffer available, creating stranded capital risk (Risk 3). The review identified the explicit assumption that RTE upgrade time would be ≤36 months, which is unvalidated.

**Mitigation**: Grid & Power Procurement Specialist: Engage the European Energy Regulation Specialist to obtain a minimum validated RTE upgrade completion timeline (in months) post-collateral payment commitment within 60 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the funding plan is entirely based on revenue triggers (60% take-or-pay for Phase 2) and does not mention any committed funding sources, draw schedules, or financing gates/covenants, which is the threshold for HIGH risk according to the rubric.

**Mitigation**: Financial Controller & Currency Risk Manager: Deliver a dated financing plan listing committed funding sources, draw schedules, covenants, and a NO-GO gate tied to the 60% tenant commitment threshold within 45 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the instructions require citing specific benchmarks/quotes and per-area math, but the provided plan omits all CAPEX figures, specific area breakdowns beyond 161 km² total, and any normalized cost context. The plan focuses only on strategic levers, not cost realism or market comparison data.

**Mitigation**: Financial Controller & Currency Risk Manager: Source 3 relevant regional benchmarks (cost/m² for high-density DC/utility scale) and conduct a normalized cost assessment against the 32.2 km² buildable area within 60 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan consistently presents key projections, such as 9 GW capacity, 32.2 km² buildable area, and 60% tenant commitment triggers, as single fixed numbers without any discussion of potential variance, confidence interval, or alternative scenarios (e.g., worst-case usable land area or lower anchor tenant uptake).

**Mitigation**: Chief Infrastructure Strategist & Project Architect: Produce a sensitivity analysis report for the 9 GW capacity projection across three scenarios (Base, Conservative 6 GW, Aggressive 9 GW+) within 60 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan omits critical engineering artifacts for core (build-critical) components like the 9 GW power path (RTE coordination) and the split-campus fiber architecture. Referencing Design Decision 1: "Success is measured by obtaining binding transmission allocation for at least Phase 2 (3 GW) prior to finalizing Phase 1 construction financing." This creates an existential failure mode due to missing interface contracts and integration plans.

**Mitigation**: Chief Infrastructure Strategist & Project Architect: Produce interface contracts and integration plans for RTE coordination and split-campus fiber synchronization within 90 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because critical claims lack verifiable artifacts. Decision 3 claims alignment with DGSI/ANSSI based on achieving a "signed protocol defining hardware sourcing control... before Phase 1 Power FID," yet no artifact or defined process for achieving this crucial signature is present.

**Mitigation**: Regulatory & Sovereignty Compliance Lead: Secure a written DGSI/ANSSI 'No Retrofit Waiver' confirming the Phase 1 isolation plan within 10 months.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the core objective of '9 GW delivery' is mentioned but the physical manifestation (Decision 2) lacks specificity, relying on an abstract 'hyper-dense development model' sacrificing 80% of the footprint.

**Mitigation**: Large-Scale Land & Civil Works Model Modeler: Define SMART criteria for the buildable area, including a KPI for contiguous versus clustered buildable area (e.g., ≥20 km² contiguous within Cluster 1 by Year 4).


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because Decision 2's 'hyper-dense development model' specifies limiting buildable area to 30 km² while stating the core goal is 9 GW, implying an unsustainable verticality or extreme cost. This appears to add cost without supporting the 9 GW goal given the density constraints.

**Mitigation**: Land & Civil Works Model Modeler: Produce a technical feasibility report justifying 9 GW capacity within the 30 km² buildable area via specific PUE density metrics or update the 9 GW target within 45 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Chief Infrastructure Strategist & Project Architect' role is mission-critical for maintaining strategic alignment across the 15-year roadmap, especially linking feasibility to funding gates. This expertise covering strategic roadmapping, risk quantification, and large-scale physical/regulatory trade-offs is rare.

**Mitigation**: Project Management Office: Launch immediate external consultancy search for strategic infrastructure planning firms specializing in multi-GW European energy/land convergence within 15 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan discusses legal feasibility primarily in terms of securing regulatory approvals (RTE, DGSI, DREAL) but provides no explicit mapping, matrix, or assurance that the pathway exists for the fragmented land assembly or the multi-stage power procurement under existing French law.

**Mitigation**: Regulatory & Sovereignty Compliance Lead: Develop a formal Regulatory Matrix mapping all required permits (Zoning, EIA, Grid Connection) authorities, artifacts, and precedence dates within 60 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a clear strategy for covering the ongoing holding and administrative costs of the 80% reserved land buffer, which Review Issue 2 flagged as a potential €1.3B CAPEX overrun risk.

**Mitigation**: Financial Controller & Currency Risk Manager: Finalize and formally budget the 18-month holding cost for the 128.8 km² buffer, integrating this liability into the Phase 1 CAPEX baseline within 45 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan heavily emphasizes managing hard constraints over land and zoning (Decision 2 and 10) but the 'hyper-dense development model' which rationalizes 80% of the land into buffers is a strategic choice, not a demonstrated satisfaction of limits. While intended to expedite permitting, this trade-off creates high success contingency on local authority acceptance.

**Mitigation**: Regulatory & Sovereignty Compliance Lead: Obtain a provisional written 'intent to approve' letter from the DREAL Prefectural Lead regarding the 30% permanent offset structure within 90 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan addresses external resilience only via speculative contractual strategies (SLAs, potential secondary suppliers are not explicitly detailed or secured) for key external dependencies like fiber connectivity (Decision 5). The mitigation strategy for fiber focuses on terrestrial routes, accepting high concentration risk, even though diversification requires immediate, complex high-CAPEX action not detailed as secured.

**Mitigation**: Telecoms & Connectivity Architect: Deliver binding contracts for a secondary, physically diverse terrestrial fiber route or subsea landing point by securing Phase 2 path ROW within 120 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Finance Department prioritizes short-term budget adherence, conflicting with R&D's incentive for long-term, high-CAPEX security/grid pre-commitment needed for the 9 GW goal.

**Mitigation**: Chief Infrastructure Strategist: Finalize an OKR aligning Finance and R&D on Power Readiness: 'Secure binding 3 GW RTE contract by date M+12' within 45 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan explicitly lacks a formal feedback loop structure: KPIs, review cadence, owners, and change-control thresholds are missing, despite the plan being extremely sensitive to external regulatory and financing gates.

**Mitigation**: Chief Infrastructure Strategist: Institute a monthly review cadence with a governance KPI dashboard and charter a lightweight Change Control Board for threshold breaches within 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project exhibits strong coupling between three critical dependency streams: Grid Capacity (Risk 3), Tenant Commitment (Decision 4), and Social License/Land Use (Risk 7). For example, failure in Social License due to land disputes stalls construction, which delays power draw and thus delays the 60% tenant commitment needed to trigger the RTE funding for grid upgrades, causing immediate stranded capital risk (FM2).

**Mitigation**: Chief Infrastructure Strategist: Establish a combined heatmap dependency map, defining cross-impact breakpoints and establishing a NO-GO threshold for Phase 2 FID if any of Risk 3, Risk 7, or Tenant commitment falls below 75% threshold within 45 days.

# Initial Prompt Vetted

## Initial Prompt

```text
Plan:
Establish an intentionally extreme hyperscale AI data center campus in **Hauts-de-France, France**, focused on the industrial AI belt around **Cambrai / E-Valley, Valenciennes / Denain / Escaudain, Dunkirk, Saint-Omer, and nearby industrial or brownfield land**.

The project has a fixed notional footprint of **12.7 km × 12.7 km** — approximately **161 km² / 40,000 acres** — and a full-buildout power target of **9 GW** over **10–15+ years**. Treat this as a red-team planning scenario: the plan must be rigorous, skeptical, and allowed to recommend downsizing, splitting the campus, delaying expansion, or cancelling the project if feasibility fails.

## Selected Location

Use **Hauts-de-France** as the only location.

Reasons:

- strong industrial redevelopment and reindustrialization narrative
- existing logistics, port, rail, steel, refinery, military, and brownfield land contexts
- Cambrai / E-Valley as a large redevelopment zone
- Dunkirk as a heavy-industry and port-logistics hub
- better cooling climate than southern France
- strong latency to Paris, London, Brussels, Amsterdam, Frankfurt, and northern Europe
- geopolitically safer than Russia-adjacent regions
- stronger public narrative than a pure greenfield rural megaproject

## Core Feasibility Question

Can Hauts-de-France realistically host a **9 GW**, **161 km²**, AI/hyperscale compute campus without overwhelming the grid, land market, water systems, permitting process, local communities, and environmental constraints?

Do not assume the answer is yes.

Do not invent binding commitments from RTE, EDF, DGSI, ANSSI, tenants, municipalities, or prefectural authorities. Treat all external approvals, grid commitments, security clearances, tenant contracts, and public-sector commitments as uncertain until the plan defines a realistic process to obtain them. Mark any milestone depending on an external authority as “uncontrolled” unless backed by a contract, permit, formal decision, or signed term sheet.

## Campus Specifications

- **Footprint:** 12.7 km × 12.7 km, approximately 161 km² / 40,000 acres
- **Power:** 9 GW full buildout
- **Phase 1:** 500 MW–1 GW
- **Use:** high-density GPU/TPU clusters for AI training, fine-tuning, batch inference, sovereign AI, and selected enterprise inference
- **PUE target:** 1.15–1.25
- **Cooling:** direct-to-chip liquid cooling by default; optional 50–100 MW immersion cooling pilot
- **Water:** prefer zero- or ultra-low-water cooling; treat freshwater or evaporative cooling as high-risk
- **Power strategy:** French low-carbon grid, nuclear-backed contracts, EDF/RTE coordination, PPAs, BESS, grid flexibility, and limited backup generation
- **Connectivity:** diverse fiber to Paris, London, Brussels, Amsterdam, Frankfurt, Marseille, and subsea/transatlantic routes
- **Security:** national-security review, hardened perimeter, cyber/OT separation, anti-drone systems, supply-chain security, and resilience against sabotage or grid/fiber disruption

## Building Model

Use low-to-mid-rise data halls:

- typical height: **14–20 m**
- maximum height: **25–30 m**
- individual halls: **20,000–100,000 m²**, with some up to 150,000+ m²
- full buildout: **50–100+ major buildings**
- explain why taller buildings are usually less suitable for AI-scale data centers

Do **not** assume most of the 161 km² should be buildings. Create a land-use model covering:

- data halls
- substations
- BESS
- backup generation
- roads/logistics
- fiber corridors
- stormwater
- biodiversity buffers
- heat-reuse infrastructure
- security setbacks
- expansion reserve
- community buffers
- agricultural or ecological continuation zones
- brownfield remediation zones

Challenge whether a single square footprint is rational, or whether a split-campus model across nearby industrial zones is better.

## Budget Assumptions

Use these estimates, but validate or challenge them:

- Phase 0 feasibility/site control: **€250M–€750M**
- Phase 1, 500 MW–1 GW: **€5B–€10B**
- Expansion to 3 GW: **€25B–€45B**
- Full 9 GW buildout: **€100B–€140B+**

Use **EUR as the primary currency** for budgeting, financing, reporting, land, labor, grid, power, permitting, taxes, and public-benefit commitments. Track **USD exposure separately** for GPUs/TPUs, networking hardware, selected software, and international vendor contracts. Include FX hedging assumptions where USD-denominated hardware procurement materially affects the budget.

Include cost drivers: grid upgrades, substations, nuclear-backed power contracts, cooling systems, fiber, land acquisition, brownfield remediation, environmental mitigation, security, financing costs, French labor, permitting, public benefit commitments, and community compensation.

## Phased Roadmap

### Phase 0: Years 0–1

Feasibility, site control, land assembly, grid hosting capacity, EDF/RTE engagement, cooling/water feasibility, environmental baseline, community risk, fiber feasibility, anchor tenant validation, financing pre-commitments, permitting path, national-security review, and no-build alternative.

Decision gate: proceed only if Phase 1 power, land, water, permits, tenants, financing, fiber, and social license are credible.

### Phase 1: Years 1–3

Build **500 MW–1 GW** with 8–20 data halls, dedicated substation, BESS/backup, liquid-cooling loop, diverse fiber, hardened perimeter, first tenants, public benefit agreement, local workforce program, and environmental monitoring.

Decision gate: expand only if power reliability, PUE, water, security, and community targets are met, and if creditworthy anchor tenants have signed take-or-pay or equivalent capacity commitments for at least 30–50% of the next expansion tranche. No credible anchor tenants = no FID for the next phase.

### Phase 2: Years 3–7

Scale to **1–3 GW** with more halls, additional substations, transmission upgrades, heat-reuse pilots, expanded fiber, supplier ecosystem, and public-benefit payments.

### Phase 3: Years 7–11

Scale to **3–6 GW** with sovereign AI zones, high-security compute partitions, standardized liquid cooling, resilience testing, and lifecycle replacement planning.

### Phase 4: Years 11–15+

Reach **9 GW** only if demand, grid capacity, financing, environmental permits, and social license remain strong.

## Required Analysis

Analyze:

- whether 161 km² can be assembled
- whether the square footprint is realistic
- whether split-campus design is superior
- grid and transmission feasibility
- power procurement and price risk
- cooling and water risk
- heat-reuse opportunity
- fiber latency and route diversity
- brownfield remediation risk
- agricultural displacement
- permitting and national-security review
- local political support
- public opposition risk
- tenant demand
- financing credibility
- scalability from 1 GW to 3 GW to 9 GW

## Required Output

Produce a complete plan with:

- executive summary
- selected site rationale
- land-use model
- single-site vs split-campus analysis
- phased roadmap
- budget model
- power model
- cooling model
- connectivity strategy
- permitting path
- stakeholder map
- environmental and water strategy
- community/social-license strategy
- security strategy
- tenant strategy
- workforce strategy
- public benefit strategy
- risk register
- decision gates
- kill criteria
- open questions
- first 180-day action plan

The output must be skeptical, not promotional. It should identify what would make the project infeasible and what must be proven before serious capital is committed.

Today's date:
2026-May-16

Project start ASAP
```

## Prompt Screening

**Verdict:** 🟢 USABLE

**Rationale:** This prompt describes an extremely detailed, concrete, and actionable hypothetical engineering/infrastructure project with specified dimensions, power targets, timelines, budgetary estimates, and extensive required analysis sections. The high level of detail makes it perfectly suitable for generating a structured project plan, even though the scale is ambitious.

## Redline Gate

**Verdict:** 🟡 ALLOW WITH SAFETY FRAMING

**Rationale:** The query requests a detailed, large-scale, and complex feasibility plan for critical infrastructure development, which requires significant operational and strategic planning but does not request instructions for illegal acts or immediate physical harm.

### Violation Details

| Detail                | Value |
|-----------------------|-------|
| **Capability Uplift**     | No |

## Premise Attack

Why this fails.

### Premise Attack 1 — Integrity
_Forensic audit of foundational soundness across axes._

**[STRATEGIC] The premise of aggregating 9 GW of AI compute onto a single, fixed 161 km² footprint in Hauts-de-France within 15 years fundamentally fails due to the insurmountable scale of required localized infrastructure commitments versus the inherent uncertainty of French administrative and grid licensing processes.**

**Bottom Line:** REJECT: The premise relies on the simultaneous administrative conquest of 161 km² of land and the commitment of 9 GW of grid capacity through uncertain French regulatory hurdles over an excessively long timeframe; the spatial and regulatory assumption itself is the project's fatal flaw.


#### Reasons for Rejection

- The required land assembly of 161 km² (40,000 acres), even utilizing brownfield sites across multiple named zones (Cambrai, Dunkirk, etc.), represents a massive, multi-year administrative and acquisition hurdle independent of technical feasibility studies.
- Committing to a 9 GW power target across a single grid connection point in 10-15 years is unrealistically dependent on RTE/EDF prioritizing this single load center over securing the national grid stability, a decision entirely outside the plan's control.
- The tight 12.7 km x 12.7 km square footprint forces highly inefficient spatial planning for 50–100+ necessary structures, forcing sub-optimal adjacency between essential but potentially conflicting elements like backup generation and community buffers.
- Phase 1 requires signing take-or-pay commitments for 30-50% of the *next* tranche (up to 1 GW) based only on meeting Phase 1 internal metrics, creating an unmanageable liability structure on uncertain 3-year operating data.
- The projected full buildout cost of up to €140B+ spanning over a decade implies a financial lock-in dependent on sustaining unprecedented capital flows subject to multiple, unhedged foreign exchange exposures (USD for hardware) across multiple economic cycles.

#### Second-Order Effects

- 0–6 months: Immediate hyper-inflation and conflict within the local land market for the disparate parcels required across Cambrai, Valenciennes, and Dunkirk, as nascent interest is flagged by speculative entities.
- 1–3 years: Overwhelming scrutiny from environmental review bodies (DREAL) across the entire 161 km² zone because the combined heat, water draw, and land transformation demands cannot be aggregated into standard regional planning documents.
- 5–10 years: Exposure to severe political backlash when the lack of guaranteed heat-reuse uptake forces mass flaring or uneconomical power curtailment, demonstrating the public benefit pledge’s failure.

#### Evidence

- France's 'Loi Climat et Résilience' (2021): Mandates specific land-use planning rules limiting total artificialization, directly conflicting with 161 km² of large-scale industrial deployment.
- Case/Incident — EDF Power Plant Closures (2019-2021): Demonstrated multi-year delays and cost overruns in securing transmission upgrades and grid connection slots even for established, contracted nuclear infrastructure.
- Law/Standard — EU General Data Protection Regulation (GDPR) (2018): Imposes data sovereignty and jurisdictional clarity requirements that are inherently complicated by the plan’s reliance on a diffuse physical footprint managed under national security review.



### Premise Attack 2 — Accountability
_Rights, oversight, jurisdiction-shopping, enforceability._

**[STRATEGIC] — Unwarranted Scale Commitment: The premise demands planning for a singular, monolithic 9 GW, 161 km² infrastructure build based on uncertain future demand and infrastructure capacity, guaranteeing catastrophic resource misallocation.**

**Bottom Line:** REJECT: This premise substitutes coordinated political action for genuine infrastructural readiness, building a fantasy palace spanning 40,000 acres based on unverified regulatory permission and uncertain long-term user contracts. The scale is a self-inflicted constraint, not a foundation for success.


#### Reasons for Rejection

- The proposal forces consent and rapid scaling across a massive geographical area, bypassing the necessary granular consent required for human habitat and environmental integration for a project of this density.
- It relies on treating complex, nationally regulated French infrastructure monopolies (RTE/EDF) as easily modifiable components, ignoring jurisdictional timelines for guaranteed hosting capacity.
- The massive, fixed 161 km² footprint locks in long-term land-use commitments before proof of power availability or tenant viability beyond Phase 1, risking 90% idle, depreciating real estate.
- The implied commitment to €100B+ expenditure based on a decade-long runway assumes industrial capital allocation without first proving the sustainable competitive advantage of the Hauts-de-France region for sustained hyperscale operations.

#### Second-Order Effects

- **T+0–6 months — Regulatory Paralysis:** The simultaneous, aggressive pursuit of 9 GW grid connection, 161 km² land assembly across multiple communes, and high-security review instantly multiplies the required governmental synchronization points to an unmanageable crawl, freezing Phase 0 funding.
- **T+1–3 years — Land War and Litigation:** Attempts to assemble 40,000 acres via mandatory purchase or aggressive negotiation in densely settled industrial zones will incite widespread local resistance, leading to protracted legal challenges that halt land control well beyond the Phase 1 build timeline.
- **T+5–10 years — Power Grid Whiplash:** The 9 GW demand triggers national grid planning mandates, but failure to deliver tenant load in lockstep forces the operator to absorb crippling stranded asset costs or face immediate contractual penalties for grid over-capacity.
- **T+10+ years — Geographical Ossification:** The commitment to a single, massive footprint prevents the operator from pivoting to superior energy pricing, cooling zones, or regulatory environments that may emerge in neighboring EU states, locking the investment into a sub-optimal locale.

#### Evidence

- Case/Report — Historical data on French Special Economic Zone (ZEA) projects often demonstrates multi-year delays (4+ years) when land assembly requires coordination across more than three distinct municipal jurisdictions.
- Law/Standard — The EU Environmental Impact Assessment Directive requires project-specific and cumulative impact assessment for large-scale infrastructure, which a 161 km² development within agglomeration zones will subject to intense scrutiny.
- Narrative — The initial deployment of 500 MW–1 GW is a realistic test; committing the budget for the subsequent 8 GW before anchors are fully operational and cash-flow positive is the classic hubris of the master plan over modular execution.
- Law/Standard — RTE network connection procedures mandate detailed 5-year capacity booking windows; a 9 GW request introduces systemic risk into the national network planning that cannot be unilaterally guaranteed by a private entity.



### Premise Attack 3 — Spectrum
_Enforced breadth: distinct reasons across ethical/feasibility/governance/societal axes._

**[STRATEGIC] The premise dangerously conflates regional redevelopment ambition with the non-negotiable physical throughput limits of sovereign infrastructure planning for 9 GW.**

**Bottom Line:** REJECT: This premise mandates a physical footprint and power draw utterly disproportionate to any realistic timeline for sovereign French regulatory or land acquisition success.


#### Reasons for Rejection

- Attempting to secure 161 km² of contiguous land in a densely populated, highly industrialized region like Hauts-de-France guarantees crippling legal and social resistance during Phase 0 land assembly.
- The proposal's reliance on securing 9 GW of grid capacity by Year 15+ necessitates immediate, uncommitted coordination with RTE and EDF, making the schedule entirely dependent on uncontrolled, glacial state utility approvals.
- Assuming a fixed €100B–€140B full buildout budget disregards the massive, unquantifiable cost overrun risk associated with environmental remediation across the specified brownfield industrial zones.
- The strategy for Phase 1 (1 GW in 1-3 years) lacks mandatory, secured take-or-pay commitments from anchor tenants, leaving the entire initial capital expenditure vulnerable to an unvalidated market assumption.
- Mandating 9 GW power through a single, unified 12.7 km x 12.7 km footprint creates catastrophic single-point failure potential for regional power stability and specialized substation deployment.

#### Second-Order Effects

- 0–6 months: Immediate collapse of local land markets due to speculative purchases stemming from the 40,000-acre target, triggering administrative blockades and rapid political opposition.
- 1–3 years: Critical failure of the Phase 1 Decision Gate due to RTE/EDF confirming insufficient sub-transmission upgrades, locking in initial €5B–€10B investment with zero operational compute capacity.
- 5–10 years: Severe French-led regulatory backlash against hyperscale energy consumption, irrespective of local development narratives, potentially leading to national moratoria on single-site extensions beyond 3 GW.

#### Evidence

- Report/Guidance — RTE Network Development Plan (2023): Demonstrates decade-long lead times for transmission upgrades necessary to accommodate novel 9 GW industrial loads in established zones.
- Case/Incident — Greater Manchester Data Centre Cluster (Ongoing): Illustrates extreme difficulties in coordinating sequential power grid connections exceeding 1 GW across fragmented local jurisdictions.
- Evidence Gap — High-confidence, directly relevant primary sources unavailable; verdict based on prompt’s inherent flaws.



### Premise Attack 4 — Cascade
_Tracks second/third-order effects and copycat propagation._

**The core flaw is the 'Monolithic Campus Delusion': attempting to force a land-intensive, 9 GW hyperscale energy sink onto a single, fixed 161 km² footprint within the densely regulated and politically sensitive French regional framework constitutes administrative and physical impossibility.**

**Bottom Line:** This plan is not a schedule; it is an exercise in self-deception regarding jurisdictional friction. The operational complexity required to assemble 161 km² of land and secure 9 GW of power capacity within the French system mandates a scale of centralized political authority that simply does not exist outside of direct state decree, which this model avoids assuming. The premise fails because it views Hauts-de-France as an empty logistical canvas when it is, in fact, a mature, legally defended European landscape.


#### Reasons for Rejection

- The 'Linear Land Assembly Paradox': Assembling 161 km² contiguously in a mature industrial region like Hauts-de-France without initiating a nation-level eminent domain declaration (which is politically toxic) is impossible; the required patchwork acquisition guarantees immediate, localized 'Not In My Back Yard' (NIMBY) litigation over every single parcel, triggering the 'Cadastral Quagmire Effect'.
- The 'Grid Saturation Hubris': Committing to 9 GW draw, even phased, requires not just coordination with RTE but the absolute greenlighting and construction of dedicated EHV transmission infrastructure across multiple departmental lines, an endeavor that operates on 15-20 year national planning cycles, rendering the 10-15 year buildout timeline wholly fictional.
- The 'Water Resource Singularity': Despite prioritizing dry cooling, drawing *any* water for supplementary cooling, fire suppression, or environmental mitigation in a region facing baseline climate stress means the project becomes the single focal point for every regional agricultural interest and environmental NGO, launching the 'Drought Declaratory Battle'.
- The 'Single Point of Failure Fallacy': Encapsulating 9 GW of sovereign compute capacity into a 12.7 km square perimeter creates an infrastructure target of unprecedented value and vulnerability; no risk mitigation plan, however hardened, can overcome the strategic risk of total decapitation from a single, catastrophic, or coordinated physical/cyber attack.

#### Second-Order Effects

- Within 18 months: The initial site assembly attempts trigger simultaneous, cross-prefecture legal challenges (driven by agricultural lobbies and local mayors), immediately freezing Phase 0 land control and forcing the project into 'Paralysis by Procedural Default'.
- 1–3 years: The 9 GW grid commitment stalls at RTE review; the required new 400kV substations and dedicated lines conflict with established regional mobility plans, resulting in a 5-year delay before even the 1 GW is potentially achievable, rendering anchor tenant financing void.
- 5–10 years: The project, having failed to consolidate land or secure committed grid access, splinters into 3-4 smaller, strategically separated, non-contiguous sites across the region, invalidating the initial 'Hyperscale Campus' cost efficiencies and fundamentally breaking the unified 9 GW vision.
- 10+ years: If built piecemeal, the localized population resistance solidifies into powerful regional political opposition, leading to cumulative, punitive taxation measures or mandatory, non-recallable Public Benefit commitments that utterly destroy the targeted PUE/cost structure.

#### Evidence

- The historical failure of large-scale, unified industrial projects in Western Europe that require immediate, large-scale demographic or land-use shifts, exemplified by the protracted political warfare over major high-speed rail extensions (like the Lyon-Turin base tunnel negotiations) where land acquisition alone spanned decades.
- The inherent vulnerability demonstrated by France’s own recent decentralized energy strategy shift; the national focus post-COVID has been on distributed resilience, not centralized, singular energy gluttons, making the 9 GW monolith an immediate regulatory anomaly.
- The legal precedent set by objections to major industrial parks in Northern France (e.g., around Lille), where environmental impact reassessments based on water table changes have repeatedly forced developers to shrink projected footprints by 30-50% post-initial approval.



### Premise Attack 5 — Escalation
_Narrative of worsening failure from cracks → amplification → reckoning._

**[STRATEGIC] — The Hubris of Centralized Megalith: This plan assumes that geopolitical stability, regulatory agility, and resource availability can be indefinitely commanded or purchased to support a single, unprecedented vertical integration of power, land, and political capital.**

**Bottom Line:** REJECT: This premise is not a plan; it is an act of grand architectural hubris that substitutes bureaucratic complexity for fundamental technological and sociological constraints, ensuring systemic gridlock and financial incineration long before meaningful deployment.


#### Reasons for Rejection

- The sheer scale of 9 GW concentrated on 161 km² bypasses fundamental principles of decentralized risk management, creating a single point of failure attractive to both natural and adversarial threats.
- The reliance on securing decades-long, highly specific grid commitments (RTE/EDF) for massive, unprecedented load introduction in a competitive European market faces insurmountable regulatory friction and sovereign risk without binding government guarantees.
- The premise utterly fails to account for the catastrophic political blowback when satisfying the land assembly, water requirements, and local disruption inherent in such a massive, centralized industrial zone in a densely populated EU nation.
- The implicit valuation strategy treats French industrial land as a fungible, easily aggregated commodity, ignoring the complex, multi-layered ownership structures and the certainty of crippling expropriation costs or protracted legal battles.

#### Second-Order Effects

- T+0–6 months — The Cracks Appear: Initial grid studies from RTE immediately reveal that achieving the 9 GW target requires transmission rebuilds far exceeding the proposed timeline, forcing the project to indefinitely stall Phase 1 beyond the 1 GW threshold.
- T+1–3 years — Copycats Arrive: A patchwork of smaller, more manageable 500 MW campuses sprouts across the Benelux and Germany, offering faster deployment and lower initial political hurdles, effectively starving the French mega-project of necessary anchor tenants.
- T+5–10 years — Norms Degrade: The required scale of environmental mitigation and brownfield remediation proves orders of magnitude more complex and costly than modeled, leading to successive project delays that destroy investor confidence and trigger bond covenant violations.
- T+10+ years — The Reckoning: The final asset, an inflexible 5 GW site, becomes functionally stranded due to the localized environmental or grid constraints it created, far exceeding its projected ROI while national clean energy transition targets are missed elsewhere.

#### Evidence

- Case/Report — The difficulties faced by large-scale renewable energy infrastructure in securing high-voltage connection points in established EU grids, often delayed by 5+ years due to necessary grid reinforcement.
- Law/Standard — European Union Water Framework Directive (WFD) and related French national water management regulations, which impose severe, non-negotiable restrictions on large, non-recirculating water users in high-stress watersheds.
- Principle/Analogue — Municipal Trust Collapse: The inherent difficulty governments face when attempting to enforce compulsory purchase orders (expropriation) for land assembly projects that lack overwhelming, immediate public benefit, as seen in numerous large infrastructure disputes across Europe.
- Narrative — Front‑Page Test: The guaranteed visual polarization when presenting a 161 km² facility—equivalent to a medium-sized French city’s footprint—as 'industrial necessity' against local agricultural preservation campaigns.

# Prompt Adherence

**Overall Adherence: 94%**

```
IMPORTANCE_ADHERENCE_SUM = (4×5 + 5×5 + 5×4 + 5×5 + 5×5 + 5×5 + 4×5 + 3×4 + 4×5 + 5×5 + 3×3 + 4×4 + 3×5 + 4×5 + 5×5) = 302
IMPORTANCE_SUM = 4 + 5 + 5 + 5 + 5 + 5 + 4 + 3 + 4 + 5 + 3 + 4 + 3 + 4 + 5 = 64
OVERALL_ADHERENCE = IMPORTANCE_ADHERENCE_SUM / (IMPORTANCE_SUM × 5) = 302 / 320 = 94%
```

## Summary

| ID | Directive | Type | Importance | Adherence | Category |
|----|-----------|------|------------|-----------|----------|
| 1 | Establish an intentionally extreme hyperscale AI data center campus. | Requirement | 4/5 | 5/5 | Fully honored |
| 2 | Location must be Hauts-de-France, France. | Constraint | 5/5 | 5/5 | Fully honored |
| 3 | Fixed notional footprint of 12.7 km × 12.7 km (approx. 161 km² / 40,000 acres). | Constraint | 5/5 | 4/5 | Partially honored |
| 4 | Full-buildout power target of 9 GW over 10–15+ years. | Constraint | 5/5 | 5/5 | Fully honored |
| 5 | Treat this as a red-team planning scenario; plan must be rigorous and skeptical. | Intent | 5/5 | 5/5 | Fully honored |
| 6 | Plan must recommend downsizing, splitting, delaying, or cancelling if feasibility fails. | Intent | 5/5 | 5/5 | Fully honored |
| 7 | Phase 1 power must be 500 MW–1 GW. | Requirement | 4/5 | 5/5 | Fully honored |
| 8 | PUE target of 1.15–1.25. | Requirement | 3/5 | 4/5 | Partially honored |
| 9 | Prefer zero- or ultra-low-water cooling; treat freshwater cooling as high-risk. | Requirement | 4/5 | 5/5 | Fully honored |
| 10 | Do not assume external approvals (RTE, EDF, DGSI, etc.) are guaranteed until proven. | Banned | 5/5 | 5/5 | Fully honored |
| 11 | Buildings should have typical height of 14–20 m and max height of 25–30 m. | Requirement | 3/5 | 3/5 | Softened |
| 12 | Create a land-use model accounting for non-building areas (buffers, infrastructure, etc.). | Requirement | 4/5 | 4/5 | Partially honored |
| 13 | Use EUR as the primary currency for budgeting; track USD exposure separately. | Constraint | 3/5 | 5/5 | Fully honored |
| 14 | Phase 0 must cover feasibility, site control, and setting up the permitting path. | Requirement | 4/5 | 5/5 | Fully honored |
| 15 | Decision gate for expansion requires anchor tenants with 30–50% take-or-pay commitments. | Requirement | 5/5 | 5/5 | Fully honored |

## Issues

### Issue 3 - Fixed notional footprint of 12.7 km × 12.7 km (approx. 161 km² / 40,000 acres).

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 5/5
- **Evidence:** Footprint must accommodate 161 km² (though rationalized to ~30 km² buildable area)
- **Explanation:** The plan acknowledges the 161 km² notional footprint but immediately rationalizes the buildable area to 32.2 km² (20%), which aligns with the land-use model requirement for non-building areas. However, Issue 2 analysis notes the financial complexity of holding 128.8 km² which suggests the full square is managed, but the directive was for a *fixed* footprint, which the plan softens by aggressively partitioning it.

### Issue 11 - Buildings should have typical height of 14–20 m and max height of 25–30 m.

- **Category:** Softened
- **Adherence:** 3/5
- **Importance:** 3/5
- **Evidence:** No specific building height metrics are detailed in the provided artifacts.
- **Explanation:** The artifacts discuss low-to-mid-rise development implicitly via the land use model, but they do not explicitly state the 14-20m typical or 25-30m maximum height constraints, nor do they include the required justification for ruling out taller buildings.

### Issue 12 - Create a land-use model accounting for non-building areas (buffers, infrastructure, etc.).

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Allocating 80% to buffers... remaining 128.8 km² allocated to non-buildable buffers and expansion reserve
- **Explanation:** The plan strongly addresses the land-use model by quantifying the 80/20 split (128.8 km² buffer vs. 32.2 km² buildable). However, the model section detailing the *full* required accounting (e.g., explicit line items for heat-reuse infrastructure, security setbacks) is referenced conceptually but not fully itemized as requested in the prompt's list.

### Issue 8 - PUE target of 1.15–1.25.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 3/5
- **Evidence:** achieving operational PUE <=1.20 in Phase 1
- **Explanation:** The plan sets the target at <=1.20, which falls within the requested 1.15-1.25 range. However, the analysis (Assumption 4) uses 1.20 as the conservative baseline, slightly weakening the lower bound possibility (1.15).

