
## Documents to Create

### 1. Project Charter: 9 GW Hauts-de-France AI Campus

**ID:** cedbbf94-cbd5-4f77-a41a-8cd210fdadc9

**Description:** Foundational document establishing official project scope, objectives (Phases 1 & 9GW goal), alignment with the 'Pragmatic Scale-Up' strategy, authorized budget envelope (€100B+ projection), high-level schedule, and ultimate decision authorities. Document type: Project Charter/Mandate.

**Responsible Role Type:** Chief Infrastructure Strategist & Project Architect

**Primary Template:** PMI Project Charter Template

**Secondary Template:** Internal Governance Mandate Template

**Steps:**

- Incorporate strategic mandates from all 10 key decisions into scope boundaries.
- Define the required conditional budget allocation between CAPEX for 1 GW build and pre-funding for feasibility/ROW securing.
- Obtain formal sign-off from Financial Controller regarding the funding gates aligned with Decision 4 (60% Tenant Threshold).

**Approval Authorities:** Executive Steering Committee

### 2. Grid Interconnection Feasibility and Commitment Strategy (RTE/EDF)

**ID:** 6ca3f3c0-d617-44b5-b320-bb45acaebdb7

**Description:** Strategy document detailing the path to secure Phase 2 (3 GW) grid allocation. It must mathematically link the 60% tenant commitment threshold (Decision 4) to the required collateral funding date for RTE upgrades, in line with the 'No Grid Pre-Commitment' strategy for major works (Decision 1). Document type: Technical-Financial Strategy.

**Responsible Role Type:** Grid & Power Procurement Specialist

**Primary Template:** Energy Interconnection Strategy Framework

**Secondary Template:** PPA Term Sheet Template

**Steps:**

- Formalize the pre-paid application process for the Phase 1 (500MW-1GW) hosting consultation.
- Model the required financial collateral structure needed by RTE for Phase 2 upgrades, contingent on the 60% tenant trigger.
- Develop the formal engagement timeline for RTE based on assumed 36-month upgrade completion buffer (Expert Review Issue 1).

**Approval Authorities:** Chief Infrastructure Strategist & Project Architect, Financial Controller & Currency Risk Manager

### 3. Land Assembly and Use Model (GIS-Based Delineation)

**ID:** 23063434-b15f-4dfe-948c-6cf50ee90956

**Description:** A highly detailed geographic information system (GIS) model delineating the full 161 km² footprint. Must identify and digitally fence the 32.2 km² buildable area (hyper-dense nodes), the 128.8 km² buffer zone, and specifically mark the 30% 'Permanent Ecological Offset' acreage required for pre-emptive permitting risk mitigation (Decision 10). Document type: Technical Land Model/Regulatory Input Data.

**Responsible Role Type:** Large-Scale Land & Civil Works Model Modeler

**Primary Template:** GIS Cadastral Mapping Standard

**Secondary Template:** Brownfield Remediation Zoning Plan

**Steps:**

- Integrate parcel data for Cambrai, Dunkirk, and Valenciennes clusters.
- Digitally assign zoning statuses (Buildable, Expansion Reserve, Permanent Offset) based on strategic decisions.
- Calculate and budget 18 months of estimated holding costs for the 128.8 km² buffer zone (Expert Review Issue 2).

**Approval Authorities:** Chief Infrastructure Strategist & Project Architect, French Land Use and Environmental Lawyer

### 4. Sovereign Security & Commercial Isolation Protocol (Phase 1 & 2)

**ID:** 6b633f24-7ca4-4407-8b81-d17707018826

**Description:** Technical specification document detailing the physical and logical separation required between the initial 500 MW commercial load and the future dedicated sovereign AI partition (Decision 3). Must define hardware provenance requirements for Phase 1 non-classified hardware and mandate the use of dedicated, segregated substation capacity (Substation 1 concept) for initial load.

**Responsible Role Type:** Regulatory & Sovereignty Compliance Lead

**Primary Template:** DGSI/ANSSI Interface Compliance Roadmap Template

**Secondary Template:** Physical Security Segregation Standard

**Steps:**

- Define explicit hardware sourcing criteria for the 500 MW commercial phase.
- Map out the location and switching logic for Substation 1 isolation.
- Produce a formal briefing document for DGSI engagement based on pre-signed requirements.

**Approval Authorities:** Regulatory & Sovereignty Compliance Lead, Chief Infrastructure Strategist & Project Architect

### 5. Fiber Connectivity Requirements & Resilience Matrix

**ID:** b74e75b5-6e6b-480a-99a2-afba375749c0

**Description:** Defines the technical specifications for latency and redundancy necessary for synchronized AI workloads (<2ms RTT between internal clusters; primary routing paths defined). It formalizes the trade-off decision (Decision 5) by scoring terrestrial primary routes versus investment required for immediate dark fiber rights-of-way.

**Responsible Role Type:** Telecoms & Connectivity Architect

**Primary Template:** Network Architecture Specification Document

**Secondary Template:** Carrier SLA Benchmarking Report Template

**Steps:**

- Benchmark RTT performance metrics for primary terrestrial routes (Paris/Brussels).
- Calculate the CAPEX estimate required for immediate dark fiber securing versus managed service outsourcing (Decision 5 choices).
- Map required cable landing points (Coastal options) to inform Fiber Ownership Decision (Decision 7).

**Approval Authorities:** Chief Infrastructure Strategist & Project Architect, Hyperscale Data Center Design & Cooling Engineer

### 6. Local Social License & Workforce Integration Framework

**ID:** 41639c5f-273b-4b99-b068-16f6f0810fa9

**Description:** Framework detailing the tangible community benefits required to secure rapid permitting velocity. Must include the budget allocation/structure for the regional skills academy (5% Phase 0 budget) and specify the auditable mechanisms for verifying the 75% local hiring mandate (Decision 8) across all Phase 1 EPC contracts.

**Responsible Role Type:** Social License & Community Benefits Orchestrator

**Primary Template:** Social License Agreement (SLA) Template

**Secondary Template:** Skills Academy Funding Allocation Schedule

**Steps:**

- Determine the initial minimum funding level (€12.5M–€37.5M) derived from the budget assumptions.
- Draft the auditable compliance clause for RFP scoring related to local workforce sourcing (Team Omission 3).
- Establish preliminary engagement protocols with vocational training centers.

**Approval Authorities:** Chief Infrastructure Strategist & Project Architect, Local Municipalities (via Regulatory Lead)

### 7. Phase 1 Financial Exposure & Currency Hedging Plan

**ID:** e8e5aedc-1c30-46e8-b727-6c7586009739

**Description:** Detailed financial plan detailing the Phase 1 budget (€5B–€10B estimate), specifically isolating USD-denominated hardware costs. It must mandate and structure the 70% forward hedging mechanism to mitigate the identified €4.32B residual FX risk, ensuring all hardware contracts are EUR-indexed where possible.

**Responsible Role Type:** Financial Controller & Currency Risk Manager

**Primary Template:** Project Budget & Financial Control Document

**Secondary Template:** FX Hedging Program Mandate

**Steps:**

- Finalize the 1 GW hardware component cost breakdown.
- Establish mandatory covenants with Treasury to execute 70% forward contracts upon funding release.
- Create contingency line item for the remaining residual USD exposure.

**Approval Authorities:** Executive Steering Committee, FX Risk Treasury Strategist

### 8. Risk Register (Initial Critical Path Analysis)

**ID:** 5ef83b35-5c2f-4cb9-90d5-10baa156f0f3

**Description:** The comprehensive compilation of initial risks (Regulatory, RTE/Grid, Social License Erosion, PUE failure) detailing likelihood, severity, initial mitigation actions, and assigning *primary ownership roles* based on the defined team structure. Crucial for tracking the project's 'red team' mandate.

**Responsible Role Type:** Chief Infrastructure Strategist & Project Architect

**Primary Template:** Standard Project Risk Register Template

**Secondary Template:** Cross-Dependency Risk Matrix

**Steps:**

- Formalize assignment of ownership for the 9 identified critical risks.
- Incorporate mitigation strategies reviewed in expert feedback (e.g., buffer land budget—Review Issue 2).
- Establish the mandatory bi-weekly review structure for Security Implementation Steering Committee (Team Omission 2).

**Approval Authorities:** Project Development Team

### 9. Fiber Connectivity Path Latency Benchmarking Report

**ID:** 8917a5f0-17ac-44dd-96b0-23f876bdce71

**Description:** A technical report comparing the projected latency (RTT) for synchronized AI workloads across the two main fiber strategies decided in Decision 5: (1) Primary Terrestrial Routes to Paris/Brussels, and (2) Co-funded Subsea Diversification. The report must quantify the resilience score vs. the achieved latency consistency (sub-2ms goal). Document type: Technical Validation Report.

**Responsible Role Type:** Telecoms & Connectivity Architect

**Primary Template:** Network Performance Validation Report

**Secondary Template:** Latency Trade-Off Analysis

**Steps:**

- Obtain preliminary quotes/SLAs from terrestrial carriers based on Decision 5 requirements.
- Model the impact of latency jitter on internode cluster synchronization.
- Produce the scored comparison matrix for Executive Review.

**Approval Authorities:** Chief Infrastructure Strategist & Project Architect, Hyperscale Data Center Design & Cooling Engineer

### 10. Phase 1 Operational PUE Validation Plan & Dry-Cooling Specification

**ID:** fa85bdf1-2a42-480a-8689-6249d30b795f

**Description:** Technical specification detailing the mandatory use of dry/zero-water heat rejection for Phase 1 (1 GW) to mitigate hydrological risk (Risk 6). Includes the acceptance criteria (max 1.20 PUE) and the method for validating this against the mandated direct-to-chip cooling architecture.

**Responsible Role Type:** Hyperscale Data Center Design & Cooling Engineer

**Primary Template:** PUE Target Adherence Plan

**Secondary Template:** Cooling System Specification Document

**Steps:**

- Modify CFD model to reflect 100% dry-cooler utilization for Phase 1 rejection load.
- Define the specific instrumentation and data logging required for PUE auditing during commissioning.
- Establish the contractual penalty triggers tied to PUE > 1.20.

**Approval Authorities:** Financial Controller & Currency Risk Manager, Project Development Team

### 11. Heat Reuse Monetization Strategy & Industrial Offtake Roadmap

**ID:** 64d8e94d-82fb-4168-86bf-c98e8c00579c

**Description:** Outlines the strategy for Decision 6, prioritizing the identification and conceptual design for connecting Heat Reuse infrastructure to a specific, high-volume industrial partner within the Dunkirk cluster. Includes initial low-margin revenue modeling to justify required Phase 0 civil works CAPEX.

**Responsible Role Type:** Social License & Community Benefits Orchestrator

**Primary Template:** Industrial Symbiosis Proposal

**Secondary Template:** Waste Heat Offtake Financial Projection

**Steps:**

- Identify 3 pre-qualified off-take partners based on input from the Regional Industrial Ecosystem Planner.
- Model the financial impact (low margin) of securing a 10-year take-or-pay contract for the first 500 MWth of rejected heat.
- Define the scope of required trenching/piping civil works necessary for Phase 0 pilot.

**Approval Authorities:** Chief Infrastructure Strategist & Project Architect, Regulatory & Sovereignty Compliance Lead

### 12. Gate Fulfillment Sign-Off Report: Phase 1 FID Readiness

**ID:** fa78944a-cc87-4154-85fb-a65e73a5a261

**Description:** Formal document produced prior to Phase 1 Construction FID. It provides verified evidence that all dependencies established in the Goal Statement have been met, including budget sign-offs, regulatory submissions, and initial Power/Tenant commitments, as required by the improved governance process (Team Omission 4).

**Responsible Role Type:** Chief Infrastructure Strategist & Project Architect

**Primary Template:** Decision Gate Closure Checklist Template

**Secondary Template:** Project Phase Exit Report

**Steps:**

- Compile evidence reports from all functional leads (Power, Land, Security, Financial).
- Confirm holding costs for the 128.8 km² buffer have been budgeted for 18 months (Review Issue 2).
- Confirm DGSI checkpoint meeting scheduled for Q4 2026 (Risk 5 mitigation follow-up).

**Approval Authorities:** Executive Steering Committee

## Documents to Find

### 1. RTE/Enedis Frameworks for Multi-Stage Grid Interconnection Financing

**ID:** 61852e43-f4ba-4af5-918b-fdb4d6bf5440

**Description:** Existing regulatory documents or procedural handbooks detailing the financial requirements (collateral vs. binding commitment timelines) for a staged connection request projected over 9 GW in the Hauts-de-France region. Needed to quantify Risk 3.

**Recency Requirement:** Current regulations essential (post-2022 structure)

**Responsible Role Type:** Grid & Power Procurement Specialist

**Access Difficulty:** Medium

**Steps:**

- Search the official RTE website for 'Tarif d'Utilisation des Réseaux Publics d'Électricité' (TURPE) documentation related to new large industrial connections.
- Contact the Energy Regulation Specialist to locate precedents for developer-funded regional network upgrades.
- Review French Cre documents related to network investment mandates.

### 2. DGSI/ANSSI Data Center Security Certification Requirements (Current)

**ID:** 7c3147ca-229f-4ae3-a6a0-8fa822ca0d13

**Description:** Official documentation outlining the necessary physical segregation, hardware provenance auditing standards, and timeline expectations for achieving sovereign AI classification status in France for large-scale compute infrastructure. Crucial input for Decision 3.

**Recency Requirement:** Most recent published guidelines (within 1 year)

**Responsible Role Type:** Regulatory & Sovereignty Compliance Lead

**Access Difficulty:** Hard

**Steps:**

- Search the ANSSI portal for 'Guide Security des Centres de Données' or equivalent high-level classification path documents.
- Submit formal inquiry through the designated regulatory liaison channel regarding preliminary review schedules.
- Consult with the EU Sovereign AI Policy Advisor for internal DGSI contacts.

### 3. Hauts-de-France Regional Spatial Planning Documents (PLU/SCOT)

**ID:** cc1b09ce-8d8a-4ee0-bae1-398e4c1f3d66

**Description:** Local/Departmental zoning plans (PLU/SCOT) for the identified clusters (Cambrai, Dunkirk, Valenciennes) to confirm current industrial designation, existing environmental constraints (water tables, protected areas), and procedures for land aggregation concessions. Essential input for the Land Assembly Model.

**Recency Requirement:** Published within last 3 years

**Responsible Role Type:** Large-Scale Land & Civil Works Model Modeler

**Access Difficulty:** Medium

**Steps:**

- Search departmental/regional authority portals (Préfecture Hauts-de-France) for planning documents related to large industrial development zones.
- Obtain cadastral maps covering the proposed 161 km² area.
- Engage the French Land Use and Environmental Lawyer for specific zoning interpretation.

### 4. French Environmental & Water Usage Regulations (ICPE/ARS)

**ID:** dc14dc00-6618-4ace-bac6-2242ec4b0a2c

**Description:** Legislation governing industrial site classification (ICPE) for power consumption and data center water usage restrictions as enforced by DREAL and ARS bodies in the Hauts-de-France region. Needed to validate the PUE/cooling strategy against mandatory curtailment threats (Risk 6).

**Recency Requirement:** Current operational status mandatory

**Responsible Role Type:** Hyperscale Data Center Design & Cooling Engineer

**Access Difficulty:** Medium

**Steps:**

- Search the Legifrance database for relevant ICPE decrees pertaining to high-capacity power/heat rejection facilities.
- Request specific guidance from DREAL/ARS regarding regional water scarcity thresholds for industrial cooling in the specific catchment areas near Dunkirk/Cambrai.

### 5. Brownfield Site Environmental Baseline Reports (Cluster 1 & 2)

**ID:** f9dc09fc-5ae9-4b18-a691-d682d6ed990f

**Description:** Existing preliminary environmental surveys or contamination reports pertaining to past industrial uses (steel/refinery) on the proposed buildable 32.2 km² cluster areas. This data directly informs the required remediation capital expenditure estimate (Risk 9).

**Recency Requirement:** Historical reports acceptable, provided they haven't triggered new cleanup orders since publication.

**Responsible Role Type:** Large-Scale Land & Civil Works Model Modeler

**Access Difficulty:** Hard

**Steps:**

- Submit formal Freedom of Information requests (or equivalent French process) to DREAL/local environmental agencies for historical site usage reports.
- Request data from the Chamber of Commerce related to former tenants on the identified industrial parks.

### 6. Sample Heat Reuse Off-take Contracts (Industrial Symbiosis)

**ID:** 0e16cdbc-2c1d-4b97-a96b-2809d0f59a06

**Description:** Examples of long-term, low-margin, high-volume heat transfer agreements used by large European industrial assets (e.g., steel, chemical plants) in France or Germany to transfer waste heat to district heating utilities or industrial partners. Needed for structuring Decision 6 agreements.

**Recency Requirement:** Last 5 years preferred

**Responsible Role Type:** Social License & Community Benefits Orchestrator

**Access Difficulty:** Medium

**Steps:**

- Consult with the Regional Industrial Ecosystem Planner for precedent contracts in Dunkirk/Flanders industrial basin.
- Search regulatory archives for public records of adjudicated energy transfer contracts involving major industrial self-generators.

### 7. TenneT/RTE Analogous Multi-GW Staged Interconnection Case Study Reports

**ID:** 4c1ae489-42d4-4cf7-8817-11dacc0b9e17

**Description:** Case studies or annual report sections detailing how TenneT (Netherlands) or RTE managed the interconnection and upgrade funding for projects achieving multi-GW scale in phases (similar to the 1 GW -> 3 GW -> 9 GW transition). Crucial for validating the Grid Strategy.

**Recency Requirement:** Post-2017 focusing on large-scale digital infrastructure.

**Responsible Role Type:** Grid & Power Procurement Specialist

**Access Difficulty:** Medium

**Steps:**

- Review TenneT/RTE annual reports concerning high-demand industrial park connection agreements.
- Search for public records or case studies referenced by the Eemshaven digital hub analogue.
- Consult with the European Energy Regulation Specialist for proprietary access points.

### 8. French Vocational Training & Apprenticeship Program Audit Standards

**ID:** f6563139-df17-4c0c-86e5-ca76d4921ca5

**Description:** Official guidelines and auditing standards from the relevant French Ministry (e.g., Education, Labor) detailing certification requirements and verification methods for specialized technical apprenticeships applicable to modern data center operations and liquid cooling maintenance. Input for validating the 75% local hiring mandate feasibility (Decision 8).

**Recency Requirement:** Current certification requirements

**Responsible Role Type:** Social License & Community Benefits Orchestrator

**Access Difficulty:** Medium

**Steps:**

- Search French Government portals for 'Certification Compétences Data Center' or 'Apprentissage Technique Industrie'.
- Engage the Local Workforce expert for official documentation sources.

### 9. DGSI/ANSSI Hardware Provenance & Supply Chain Control Documentation

**ID:** bd83ba3f-db0c-4f63-8f19-80a0767e0760

**Description:** High-level policy documents describing the regulatory classification criteria for IT hardware components that must be restricted, audited, or sourced domestically to achieve 'sovereign certification' status (Decision 3 input). This defines the non-negotiable physical and logical isolation requirements.

**Recency Requirement:** Current security policy essential

**Responsible Role Type:** Regulatory & Sovereignty Compliance Lead

**Access Difficulty:** Hard

**Steps:**

- Consult with the EU Sovereign AI Policy Advisor for any publicly accessible guidance on 'critical infrastructure hardware sourcing'.
- Search official EU security agency publications relating to supply chain resilience for AI infrastructure.

### 10. Hauts-de-France Regional Energy Infrastructure Plans (9GW Context)

**ID:** 1860cb42-2a48-4dd7-89d2-20643c8487bb

**Description:** Strategic energy planning documents from the Hauts-de-France Regional Council showing projected available transmission capacity and planned future nuclear/renewable PPAs in the 2028-2035 timeframe. This data informs the long-term viability of the 9 GW ambition independent of isolated RTE negotiation points.

**Recency Requirement:** Regional energy planning documents published within last 3 years

**Responsible Role Type:** Grid & Power Procurement Specialist

**Access Difficulty:** Medium

**Steps:**

- Search the regional government website for 'Schéma Régional Climat Air Énergie' (SRCAE) or regional economic development plans.
- Contact local DREAL/DGEC representatives for regional energy forecasts.