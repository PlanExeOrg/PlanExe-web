This plan implies one or more physical locations.

## Requirements for physical locations

- Precision sheet-metal fabrication capability (laser cutting, bending, CNC machining)
- ISO-certified precision-metal manufacturing ecosystem
- Accredited EMC/shielding testing laboratory with RF measurement chambers
- EU conformity assessment and certification support
- Cross-border logistics and warehousing access for European distribution
- Access to prepper and preparedness communities for presales and feedback
- Critical-infrastructure buyer networks and procurement contacts
- Skilled RF and shielding engineering expertise
- Low-cost production base with existing fabrication tooling
- Proximity to or integration with European supply chains

## Location 1
Estonia

Tallinn, Estonia

Precision sheet-metal fabrication facilities, Tallinn industrial district or technology parks (e.g., Ülemiste City, Tehnopol)

**Rationale**: Primary manufacturing anchor explicitly stated in the plan. Tallinn offers low-cost, ISO-certified precision-metal ecosystem with laser-cut and bent sheet-metal capabilities. Soft tooling and design iteration fit local fabricators' flexible tooling. Proximity to Scandinavian and European markets for cross-border fulfilment.

## Location 2
European Union (multi-site testing and certification)

Accredited EMC laboratory locations (Central Europe or Northern Europe preferred)

Independent accredited test facilities (e.g., Germany, Sweden, Netherlands, or Estonia) certified under EN/IEC standards for RF shielding enclosure testing

**Rationale**: Design and certification require accredited EMC testing for shielding effectiveness (IEEE 299.1 or equivalent) to meet Shielding Proof Standard decision. A single accredited lab validation is planned for the final design. Proximity to Tallinn or EU logistics hubs reduces travel and sample-shipping costs. Testing must meet critical-infrastructure procurement standards.

## Location 3
European Union (distributed buyer access)

Multiple European cities (prepper networks, critical-infrastructure hubs, and preparedness communities)

Prepper forums, emergency-response agencies, utility operators, critical-infrastructure centres, and established preparedness retailers across EU (e.g., Germany, Scandinavia, UK, France)

**Rationale**: Presale and demand validation require direct access to prepper communities and critical-infrastructure buyers for deposits, pilots, and reference customers. Buyer segment sequencing starts with prepper networks and transitions to infrastructure procurement. Distributed presence supports multi-use RF-isolation narrative and cross-border fulfilment planning. Wireless and in-person engagement with communities and procurement offices accelerates sales cycles.

## Location Summary
The plan requires three classes of physical location. First, Tallinn, Estonia, is the anchor for sheet-metal manufacturing and design iteration, leveraging its low-cost, ISO-certified precision-metal ecosystem and soft-tooling flexibility. Second, an accredited EMC testing laboratory within or near the EU is essential for the single accredited validation of the final design against RF shielding standards, meeting critical-infrastructure procurement requirements. Third, distributed European locations (prepper networks, emergency-response agencies, utility operators, and established retailers) are needed for presale deposits, pilot feedback, buyer engagement, and market access. The plan is geographically anchored to Tallinn for production but requires EU-wide buyer access and testing capabilities to execute the presale-gated, staged-funding model and reach the positive cash flow required for the second tranche.