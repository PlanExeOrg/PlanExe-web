# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** Small-to-medium personal venture: a self-funded €750k (user constraint) in two stages (€400k Year-1 burn, €350k follow-on gated on positive cash flow). One SKU, one manufacturing base (Tallinn), a European market. Ambition is a viable niche hardware business, not a mass-market or category-defining one. Server-grade cages are deferred.

**Risk and Novelty:** Moderate-to-high commercial risk, low technical novelty. Faraday enclosures are a proven concept, but demand is niche and unproven. Key risks are a failed shielding test after tooling is committed, weak prepper volumes, long critical-infrastructure sales cycles, and claim-substantiation exposure, because a passive box protects only stored spare devices. The personal-capital constraint and the cash-flow gate make irreversible early commitments dangerous.

**Complexity and Constraints:** Moderate operational complexity: design, prototyping, accredited EMC testing, EU conformity, sheet-metal tooling in Tallinn, cross-border fulfilment, and pre-sales. Hard constraints are the fixed budget, the tranche condition tied to positive cash flow, and the Year-1 timeline. Sequencing of tooling versus test evidence versus presales is the central difficulty. Applicability of specific test standards (e.g. IEEE 299.1) is not verified.

**Domain and Tone:** Commercial hardware entrepreneurship: product development, certification, manufacturing, market entry and monetization. The tone is pragmatic and capital-conscious, and the plan is explicitly 'pre-sold' and conditional on traction.

**Holistic Profile:** A capital-constrained, evidence-gated niche hardware launch. It needs staged commitment (prove the design, pre-sell, then tool), a rigid single-SKU design that suits Tallinn fabrication, a demand signal before cash is spent, and a customer base wide enough to reach positive cash flow for the second tranche. It does not need a high-risk premium infrastructure bet or a purely defensive retail-dependent posture.

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Pragmatic Foundation: Prove, Pre-Sell, Then Tool
**Strategic Logic:** Iterate cheaply on an in-house rig, buy one accredited validation for the final design, and gate hard tooling on refundable-deposit presales. Widening the narrative to multi-use RF isolation adds a steadier second market beyond preppers, supporting the cash-flow gate for the €350k follow-on (user constraint). A single rigid enclosure keeps re-qualification scope small.

**Fit Score:** 9/10

**Why This Path Was Chosen:** Matches the pre-sold, staged-funding structure: cheap iteration on an in-house rig, one accredited validation, and tooling released only after deposit thresholds are met. The multi-use narrative widens the market to support the cash-flow gate, and the rigid enclosure fits Tallinn's metal ecosystem.

**Key Strategic Decisions:**

- **Shielding Proof Standard:** Build an in-house shielding test rig for rapid design iteration, then buy a single accredited lab validation only for the final design and use it as the public claim.
- **Threat Narrative and Claim Scope:** Reposition the same enclosure as a multi-use RF-isolation product for privacy, travel, key-fob security and digital-forensics buyers, with disaster preparedness as one use case.
- **Enclosure Architecture:** Develop a rigid folded-aluminium or steel enclosure with a continuous conductive-gasket lid seam, sized to fit the largest common laptop and several phones in one SKU.
- **Presale and Demand Validation Mechanism:** Run a refundable-deposit presale through prepper forums and communities, with a stated minimum order threshold that must be met before tooling money is committed.
- **Year-1 Burn Sequencing:** Front-load design, prototyping and test-lab work with soft tooling, and defer hard tooling and the main production run until pre-test results confirm the design and presales exist.

**The Decisive Factors:**

- **Fit with the plan's structure:** The plan is a pre-sold, self-funded, two-tranche launch. This scenario gates hard tooling on a presale threshold and pre-test results, so irreversible spend follows evidence.
- **Risk control:** An in-house rig plus one accredited validation limits costly failed lab runs. A single rigid enclosure keeps re-qualification small and suits Tallinn sheet-metal fabrication.
- **Cash-flow gate:** Multi-use RF-isolation positioning opens a steadier market than preppers alone, which supports positive cash flow for the €350k follow-on.
- **Pioneer's Gambit:** Too expensive and slow for €400k Year-1. Early tooling, a hybrid seal and long infrastructure sales cycles risk sunk cost and a missed gate.
- **Capital Shield:** Safe, but a niche prepper claim sold via wholesale gives thin margins and low volume, and it skips the plan's pre-sale mechanism.

---
## Alternative Paths
### The Pioneer's Gambit: Infrastructure-Grade from Day One
**Strategic Logic:** Position the enclosure as a documented continuity-of-operations kit backed by full accredited test evidence per unit, a serviceable seal and early production-grade tooling. This targets higher-value infrastructure buyers and accepts that long sales cycles and a possible failed certification could consume Year-1 funds and leave sunk tooling cost. The bet is that early reference customers and best-in-class proof create a defensible premium position.

**Fit Score:** 3/10

**Assessment of this Path:** Early production tooling, a hybrid seal design, per-unit accredited reports and slow infrastructure pilots all add cost and risk. This clashes with a self-funded budget and a cash-flow-gated second tranche, and a failed certification would leave sunk tooling cost.

**Key Strategic Decisions:**

- **Shielding Proof Standard:** Commission an accredited EMC laboratory to test production-representative units against a recognised enclosure-shielding standard and publish the full frequency-sweep report with every unit sold.
- **Threat Narrative and Claim Scope:** Lead with a documented continuity-of-operations kit for critical-infrastructure operators, bundling the enclosure with a written spare-device recovery procedure instead of selling a standalone box.
- **Enclosure Architecture:** Develop a hybrid with a rigid sheet-metal frame and a replaceable seal cartridge, so the wear part can be swapped or re-verified without replacing the full unit.
- **Presale and Demand Validation Mechanism:** Sign paid pilot agreements with a small number of critical-infrastructure operators, using their test feedback and reference status to unlock wider procurement.
- **Year-1 Burn Sequencing:** Commit early to production-grade tooling and a first batch to shorten time to revenue, accepting that a failed certification test would leave sunk cost in tooling that needs rework.

### The Capital Shield: Narrow Claims, Reserved Runway
**Strategic Logic:** Minimise cash at risk and legal exposure: a tight, honest prepper claim scope, a simple rigid enclosure with one accredited validation, and sales through established retailers that carry audience and fulfilment. A reserve held outside committed spending absorbs redesign or retest costs. The trade-off is lower volume potential and thinner margins in return for protecting the self-funded capital and runway.

**Fit Score:** 6/10

**Assessment of this Path:** Protects capital and limits claim exposure, but a narrow prepper niche sold through wholesale retailers gives thin margins and low volume. It also drops the plan's pre-sale mechanism and may not reach the positive cash flow the €350k follow-on needs.

**Key Strategic Decisions:**

- **Shielding Proof Standard:** Build an in-house shielding test rig for rapid design iteration, then buy a single accredited lab validation only for the final design and use it as the public claim.
- **Threat Narrative and Claim Scope:** Position the product around solar-storm and pulse resilience for preppers, with explicit scope statements that it protects stored spare devices rather than grid-connected equipment.
- **Enclosure Architecture:** Develop a rigid folded-aluminium or steel enclosure with a continuous conductive-gasket lid seam, sized to fit the largest common laptop and several phones in one SKU.
- **Presale and Demand Validation Mechanism:** Sell through established preparedness and survival retailers on consignment-free wholesale terms, using their audience and fulfilment instead of building a direct storefront.
- **Year-1 Burn Sequencing:** Hold a defined reserve of the Year-1 budget (proposed share, to be set in planning) outside all committed spending until the first confirmed orders, using the reserve to absorb redesign or retest costs.
