## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Do written fabricator and gasket quotes confirm a unit cost at or below EUR 77 (estimate) with capacity reserved for 800 units? | Unit cost <= EUR 77 (estimate), the gate break-even at 750 units/quarter and EUR 149 list price. Gasket lead time <= 3 weeks, trial-batch reject rate < 5%. Stop if no fabricator can deliver 800 units at or below EUR 85 by Month 7 (2027-05-08). | Fixed-price written quotes from 2-3 Tallinn fabricators and 2 gasket suppliers by Month 1 (2026-11-08); secondary-fabricator trial parts by Month 2 (2026-12-08). | Switch to the secondary fabricator. If unit cost stays above EUR 77, margin falls below EUR 60 and the base case no longer clears the EUR 25k gate. Then re-price (EUR 149 is the only list price), cut volume plans, or stop before committing hard tooling. |
| 2 | Is a signed accredited-lab statement of work in place with fixed cost of EUR 15k, the standard confirmed, and a report date no later than Month 6 (2027-04-08)? | Fixed cost EUR 15k; quote < EUR 20k (a quote >= EUR 20k is the tripwire); samples at Month 4 (2027-02-08), report at Month 5 (2027-03-08), latest Month 6 (2027-04-08); IEEE 299.1 or equivalent confirmed. | Pre-engagement calls with 2-3 labs by Month 0.5 (2026-10-23); signed SoW by Month 1.5 (2026-11-23). | Switch to the backup lab. If the costlier-standard plus re-test gap (up to 15k) has no signed funding decision by Month 6 (2027-04-08) (for example raising the reserve to 30k by cutting marketing 10k), cancel or pivot. A report later than Month 6 (2027-04-08) delays tooling and batch 1, and a 90-day gate extension becomes likely. |
| 3 | Do the legal opinion and insurer quotes show that no CE or notified-body work is required and that shielding claims are insurable within budget? | No CE work (otherwise +10-30k and +8-12 weeks, unfunded). Premium <= EUR 15k per year (proposed threshold), fitting inside the 75k marketing/sales/operations line. Insurance terms locked by Month 2.5 (2026-12-23). | Legal opinion by Month 1 (2026-11-08); written insurer positions on shielding claims and the terms lock at Month 2.5 (2026-12-23). | Pause presale launch and tooling commitments. If the CE and insurance gap exceeds EUR 30k (estimate) with no signed funding decision by Month 3 (2027-01-08), pivot or cancel. A smaller gap needs an explicit funding decision (reserve plus marketing cut, or narrower claims). |
| 4 | Does early presale data show a demand mix and realised price that can reach the gate? | At Month 3 (2027-01-08): prepper deposits <= 70% of total, presale conversion >= 40%, average realised price >= EUR 120 (halt floor). Gate arithmetic: at 750 units/quarter and EUR 82 direct cost, EUR 25k surplus needs a margin of about EUR 60, so about EUR 142 realised. Pilots (10-20 units at EUR 84) agreed by Month 3 (2027-01-08). | Weekly segment tracker (deposits, price, refunds) from Month 1 (2026-11-08); Month 3 (2027-01-08) check. | Reallocate EUR 10-15k of marketing to infrastructure and privacy segments. If the price or mix stays below the gate-consistent level, withhold hard tooling and plan for a smaller or cheaper-to-serve scope or a stop. In the prepper-only case at EUR 15/unit the quarterly result is -8.75k and the gate fails. |
| 5 | Are net presale deposits (after refunds) at least EUR 80k and has the accredited report confirmed the design, so that hard tooling can be released? | Net deposits >= EUR 80k (target 120k) AND lab report/pre-test confirms the design, at Month 6 (2027-04-08); cumulative refunds <= 15% of deposits by Month 8 (2027-06-08); refund rate <= 20% at Month 6 (2027-04-08). | Earmarked-account reconciliation and the lab report (Month 5 = 2027-03-08); joint founder and advisor release decision at Month 6 (2027-04-08). | No hard tooling. Pivot pricing and channel mix and extend presale to Month 8 (2027-06-08) at most. If net deposits are still below EUR 80k at Month 8 (2027-06-08), the tranche is expected to be withheld and the founder reviews wind-down. |
| 6 | Does the trailing-quarter operating cash surplus reach EUR 25k, with presale deposits and one-off spend excluded? | Surplus >= EUR 25k over Months 9-12 (2027-07-08 to 2027-10-08), which needs about 672 units delivered and paid. Pass >= 25k; ambiguous -5k to +25k lets the founder extend 90 days; below -5k fails and the tranche is withheld. | Receipts less direct unit cost less recurring opex, reconciled monthly. Founder and external advisor sign-off by Month 12.5 (2027-10-23). | Between -5k and +25k: 90-day extension and re-measure. Below -5k: EUR 350k not released, and the founder decides on wind-down or an extended low-burn phase. Year-2 buffer stock, the smaller SKU and the tranche allocation all stay unfunded. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: canonical_facts (demand_pivot_triggers); premortem A2; executive summary
    canonical: gate_arithmetic = Gate pass needs (25,000 + 20,000)/67 = 672 units per quarter; margin 67 = 149 - 82
    observed:  Realised price >= EUR 120 'holds the EUR 67 contribution'; margin EUR 50-67 passes the gate
HIGH CF-002  document: executive summary; review_plan; self_audit
    canonical: downside_margin_case = 750 units give 11.25k - 20k opex = -EUR 8.75k per quarter; gate fails
    observed:  EUR 11.25k quarterly margin, missing the EUR 25k gate by EUR 13.75k
HIGH CF-003  document: pitch
    canonical: cash_flow_gate_definition = Threshold >= EUR 25k
    observed:  EUR 30k+ quarterly surplus to clear the cash-flow gate
HIGH CF-004  document: pitch
    canonical: deposit_use_open_decision = OPEN: share of unit price a deposit represents and whether deposits pay unit cost
    observed:  deposits of EUR 149 per unit; EUR 120 effective with deposit timing
MEDIUM CF-005  document: premortem FM2; review_plan Reviews 8, 10
    canonical: unit_cost_and_margin_eur = Unit cost 70 + freight 12 = 82; contribution 67
    observed:  Stop rule at EUR 85; margin 64-72; quarterly 22.5-24.75k at cost 77-85
MEDIUM CF-006  document: review_plan Review 5; self_audit item 7
    canonical: lab_standard_fallback = Worst case up to 35k against the 20k reserve, a 15k gap
    observed:  Total lab spend 35-50k; EUR 15-30k unfunded gap
MEDIUM CF-007  document: review_plan Reviews 9, 11, 14
    canonical: production_line_composition_eur = Unallocated production headroom: 0k
    observed:  net 37k buffer / 35k net headroom
MEDIUM CF-008  document: canonical_facts / executive summary
    canonical: unbudgeted_items_absorbed = Funded inside the 75k marketing/sales/operations line
    observed:  75k described as 'marketing EUR 75k'; opex run rate 80k/yr plus one-offs
MEDIUM CF-009  document: canonical_facts
    canonical: design_milestones = Month 5 (2027-03-08) tooling decision gate; first batch committed Month 6 (2027-04-08)
    observed:  Hard-tooling gate at Month 6 (2027-04-08) (pitch, self_audit, premortem)
MEDIUM CF-010  document: review_plan Reviews 6 and 13
    canonical: accredited_lab_plan = Samples submitted Month 4 (2027-02-08), report Month 5 (2027-03-08), latest Month 6 (2027-04-08), including a design-readiness review
    observed:  Review by Month 4.5 (2027-02-23); pre-test results locked by Month 5 (2027-03-08) before committing samples
MEDIUM CF-011  document: executive summary Feedback; review_plan; self_audit
    canonical: accredited_lab_plan = Statement of work with fixed cost and date by Month 1.5 (2026-11-23)
    observed:  Signed lab SoW by Month 0.5 (2026-10-23)
MEDIUM CF-012  document: pitch; review_plan Reviews 9, 11
    canonical: month05_prerequisites = Gate convention by Month 0.5 (2026-10-23); legal opinion and presale terms/SLA by Month 1 (2026-11-08); insurance terms locked by Month 2.5 (2026-12-23)
    observed:  Presale deposits 'open now'; insurance certificate published by Month 2 (2026-12-08)
```

### 1. Realised-price floor and margin range vs gate arithmetic (🔴 High) — needs a project decision

- **Canonical demand_pivot_triggers; premortem A2/FM3/FM9; executive summary Overall Takeaway; review_plan Review 2 #2:** Halt presale marketing if average realised price < EUR 120 (about 80% of list); premortem A2: a realised price of EUR 120 or more holds the EUR 67 contribution; executive summary: demand mix yields EUR 50-67 unit margin and passes the gate.
- **Canonical unit_cost_and_margin_eur and gate_arithmetic:** Contribution = price - 82 direct cost. At EUR 120 contribution is 38, giving 750 x 38 - 20k = 8.5k. At EUR 50 margin the surplus is 17.5k. The gate needs about EUR 60 margin (about EUR 142 realised price).
- **Why it conflicts:** A EUR 120 price does not hold a EUR 67 margin, and neither a EUR 120 price nor a EUR 50-67 margin range clears the EUR 25k gate at 750 units per quarter. The stated thresholds would let the project continue while the gate is already unreachable.
- **Suggested resolution:** Keep the gate arithmetic (about EUR 60 margin, about EUR 142 realised price at 750 units and 82 direct cost). Restate the EUR 120 floor either as a halt/stop level that is explicitly below the gate-passing level, or raise it. Replace 'EUR 50-67' with 'at least about EUR 60'. Clarify that AOV/order value and per-unit price are different measures.

### 2. Prepper-downside shortfall understated (🔴 High)

- **Executive summary Risks; review_plan Review 1 #2, Review 5 #2, Review 15 #2; self_audit items 2, 4, 8, 10, 20:** Prepper-only scenario yields EUR 11.25k quarterly margin, missing the EUR 25k gate by EUR 13.75k.
- **Canonical downside_margin_case; premortem FM3:** 750 units x 15 = 11.25k less 20k opex = -8.75k per quarter; shortfall vs the 25k gate = 33.75k. Quarterly break-even is 1,333 units.
- **Why it conflicts:** 11.25k is gross contribution before opex, compared against a gate defined after opex. The miss is understated by 20k. Review 14 has the same slip: 600 units at EUR 15 is called a 9k loss, but 9k - 20k = -11k.
- **Suggested resolution:** Use the canonical figures: -8.75k per quarter, a miss of 33.75k, and 1,333 units for break-even. Correct Review 14 to -11k for 600 units. Correct all documents that repeat 11.25k vs 25k / 13.75k.

### 3. Gate threshold EUR 30k+ in the pitch (🔴 High)

- **Pitch, Project Overview (also Risk 8 example 'EUR 30k or more'):** The project targets EUR 30k+ quarterly surplus to clear the cash-flow gate.
- **Canonical cash_flow_gate_definition and gate_signoff_and_tiebreak; executive summary; project plan; pitch Metrics section:** Gate pass is a trailing-quarter operating surplus >= EUR 25k. Base case 30.25k is a result, not the threshold.
- **Why it conflicts:** A 30k+ target would need about 747 units per quarter (50k/67), so it is effectively zero tolerance. It also shifts the ambiguous band to 25-30k. The pitch's own Metrics section says 25k.
- **Suggested resolution:** Use EUR 25k (proposed threshold) everywhere. State 30.25k as the base-case outcome, with 5.25k headroom.

### 4. Pitch presents EUR 149 deposits while deposit share is open (🔴 High) — needs a project decision

- **Pitch, Project Overview, Stakeholder Benefits, Call to Action:** Deposits of EUR 149 per unit (estimate) unlock hard tooling; presale buyers get early access at EUR 149 (EUR 120 effective with deposit timing).
- **Canonical deposit_use_open_decision; review_plan Reviews 9-11, 14:** OPEN: whether ring-fenced presale deposits may pay unit cost of matching orders, and what share of the unit price a deposit is. EUR 149 is the list price; EUR 120 is a halt threshold, not a discount.
- **Why it conflicts:** The pitch treats a full-price deposit as settled and reads the EUR 120 halt threshold as an 'effective price'. The deposit share and use change working capital, the 160k production-line funding and the gate cash.
- **Suggested resolution:** Decision needed. Options: (a) deposit = full price held in the earmarked account (liability); (b) partial deposit (percentage of EUR 149) with the balance at delivery; (c) deposits may or may not fund matching unit cost. Until decided, the pitch should say 'deposit amount to be set'. The EUR 120 floor should not be called an effective price.

### 5. Unit-cost stop rules and sensitivity arithmetic (🟡 Medium)

- **Premortem FM2; review_plan Reviews 8 and 10:** FM2 stop rule: cancel if no fabricator delivers 800 units at or below EUR 85 unit cost. Review 10: unit cost EUR 77-85 gives quarterly 22.5-24.75k (miss by 0.25-2.75k). Review 8: margin 64-72.
- **Premortem FM2 tripwire and A3; self_audit item 2; canonical unit_cost_and_margin_eur:** Tripwire/NO-GO is EUR 77. At unit cost 77 (+12 freight) the margin is 60, giving exactly 25k; at 85 the margin is 52 and the surplus is 19k (gate fails). Margin 64-72 treats 82 (direct cost incl. freight) as unit cost.
- **Why it conflicts:** A stop rule at EUR 85 allows a cost at which the base case already fails the gate by 6k, while the other documents use 77. The sensitivity figures in Reviews 8 and 10 do not follow from the canonical 70+12 structure.
- **Suggested resolution:** Use EUR 77 as the go/no-go (gate break-even). Treat 77-85 as 'gate fails unless price or volume compensates'. Recompute: unit cost 77 gives 25.0k, 85 gives 19.0k per quarter.

### 6. Lab overrun gap arithmetic (🟡 Medium)

- **review_plan Review 5 #1; self_audit item 7:** Lab spend reaches EUR 35-50k, creating a EUR 15-30k unfunded gap; lab escalation + re-test + CE = 35-50k, gap 15-30k.
- **Canonical lab_standard_fallback and ce_marking_fallback:** Worst case is up to 35k of overrun (standard +10-20k, re-test 8-15k) against the 20k reserve, a 15k gap. If CE (+10-30k) is added, the overrun is about 28-65k and the gap about 8-45k.
- **Why it conflicts:** The 35k in the canonical fact is the overrun, not total lab spend (total would be 15k + 35k = 50k). The 15-30k gap range does not follow from either the lab-only or the lab + CE case.
- **Suggested resolution:** Keep the canonical wording: lab-only worst case overrun 35k, gap 15k (5k if the reserve rises to 30k). Give the CE-inclusive case separately with its own range, or state that CE is a separate unfunded item.

### 7. Production-line headroom shown as 35-37k (🟡 Medium)

- **review_plan Review 9 #2, Review 11 #1, Review 14 #2:** Deposits pay 50% of unit cost (EUR 75): 160k covers 105k + 18k freight + funds a net 37k buffer; 160k leaves only 35k net headroom for hard tooling and buffer stock; 135k remains for batch-1 tooling and batch-2 labor.
- **Canonical production_line_composition_eur and unit_financing_baseline:** 160k = tooling 30k + gasket stock 7k + units 105k + freight 18k; unallocated headroom 0k.
- **Why it conflicts:** The 37k remainder is already allocated to tooling (30k) and gasket stock (7k), so no buffer exists. Also, EUR 75 is 50% of the EUR 149 price, not 50% of the EUR 70 unit cost (35). 'Batch-2 labor/overhead' is not a line item.
- **Suggested resolution:** Restate: headroom is 0k in every deposit scenario. Deposit use only changes the timing of cash, not the cap. Remove the 35-37k 'buffer' wording and fix the 50% reference once the deposit-share decision is made.

### 8. 75k marketing/sales/operations line cannot absorb all listed items (🟡 Medium) — needs a project decision

- **Canonical unbudgeted_items_absorbed; executive summary Timeline and Budget:** Legal opinion 2-5k, LCA 2-5k, premium (not estimated) and part-time ops 5-8k are funded inside the 75k line. Executive summary labels the 75k as 'marketing'.
- **Canonical recurring_opex_eur; cash_flow_gate_definition:** Recurring opex is 80k per year (marketing 40k, ops 13k, insurance 8k, accountant/legal/software 7k, re-verification/spot tests 12k), and the gate subtracts 20k opex per quarter.
- **Why it conflicts:** After the one-offs (about 9-18k) the line has about 57-66k left, against about 67k of marketing, insurance, accountant and spot-test costs. A premium above 8k or an unestimated cost leaves the line over-allocated. The 75k is a mix of marketing, sales and operations, not 'marketing'. The line does not show how the Month 9-12 (2027-07-08 to 2027-10-08) opex of 20k is covered inside the Year-1 cap.
- **Suggested resolution:** Decision needed: defer re-verification and spot tests (12k), LCA or part-time ops, or shift the redesign reserve. Relabel the line as marketing/sales/operations and show a line-level Year-1 breakdown.

### 9. Tooling decision gate: Month 5 (2027-03-08) vs Month 6 (2027-04-08) (🟡 Medium) — needs a project decision

- **Canonical design_milestones; assumptions Financial Sequencing:** Month 5 (2027-03-08) tooling decision gate; first batch committed Month 6 (2027-04-08).
- **Canonical presale_tooling_gate_eur; self_audit item 2; pitch Call to Action:** Net deposits >= 80k are measured at Month 6 (2027-04-08); joint hard-tooling decision at Month 6 (2027-04-08); pitch: tooling gate closes at Month 6 (2027-04-08).
- **Why it conflicts:** A decision at Month 5 (2027-03-08) cannot depend on a deposit count that is only due at Month 6 (2027-04-08). Documents use both months for the same gate.
- **Suggested resolution:** Set Month 5 (2027-03-08) as the lab-report review/readiness check and Month 6 (2027-04-08) as the single tooling-release gate (deposits + lab confirmation). Amend design_milestones.

### 10. Design-readiness review scheduled after sample submission (🟡 Medium)

- **review_plan Review 6 KPI 2 and Review 13 #1:** Execute design-readiness review by Month 4.5 (2027-02-23); lock pre-test results by Month 5 (2027-03-08) before committing lab samples; review is a prerequisite to formal submission at Month 4 (2027-02-08).
- **Canonical accredited_lab_plan; project plan; premortem FM1:** Samples submitted Month 4 (2027-02-08), report Month 5 (2027-03-08); the design-readiness review (2-3k) is part of the lab plan and precedes submission.
- **Why it conflicts:** Month 4.5 (2027-02-23) is after submission and Month 5 (2027-03-08) is the report date, so the review cannot precede submission. The sequence is out of order and the Month 5 (2027-03-08) lock would push the report beyond Month 6 (2027-04-08).
- **Suggested resolution:** Hold the readiness review before Month 4 (2027-02-08) (for example at Month 3.5 = 2027-01-23, right after rig validation at Month 3 = 2027-01-08), then submit samples at Month 4 (2027-02-08).

### 11. Lab SoW and consultancy timing (🟡 Medium)

- **Executive summary Feedback (1); review_plan Review 3 #1 headline, Review 5/KPI 2; self_audit items 5, 13, 17:** Lock a signed lab SoW with fixed cost by Month 0.5 (2026-10-23); lab selection and signed SoW by Month 0.5 (2026-10-23); signed consultant agreement by Month 1 (2026-11-08).
- **Canonical accredited_lab_plan and month05_prerequisites; project plan Dependencies; executive summary Action Orientation:** Only lab pre-engagement contacts and signed consultancy/university milestones are due by Month 0.5 (2026-10-23); the lab SoW with fixed cost and date is due by Month 1.5 (2026-11-23). The same documents also say Month 1.5 (2026-11-23).
- **Why it conflicts:** Two different deadlines for the same SoW, sometimes inside one item (Review 3 #1). The consultancy agreement is Month 0.5 (2026-10-23) in the canonical facts but Month 1 (2026-11-08) in self_audit item 13. A Month 0.5 (2026-10-23) SoW is only about 2 weeks after project start and before pre-engagement results exist.
- **Suggested resolution:** Use Month 0.5 (2026-10-23) for pre-engagement contacts and the consultancy/university milestone signatures, and Month 1.5 (2026-11-23) for the signed lab SoW.

### 12. Presale 'open now' precedes its prerequisites (🟡 Medium)

- **Pitch Call to Action; executive summary Action Orientation:** Presale deposits: open now through Month 8 (2027-06-08); presale campaigns live Month 1 (2026-11-08); (assumptions: campaigns from Month 0 = 2026-10-08).
- **Canonical month05_prerequisites and compliance_posture; premortem FM4; review_plan Reviews 9, 11:** Gate convention and earmarked account by Month 0.5-1; presale terms/SLA and legal opinion by Month 1 (2026-11-08); insurance terms locked Month 2.5 (2026-12-23). FM4 playbook pauses presale launch until legal opinion and insurance are in writing. Review 9 and 11 publish the insurance certificate at Month 2 (2026-12-08), before the Month 2.5 (2026-12-23) lock.
- **Why it conflicts:** Deposits cannot be taken before the deposit-accounting convention, refund terms and legal scope exist, and the planned insurer quote dates (Months 1-1.5) and certificate (Month 2 = 2026-12-08) are out of order with the Month 2.5 (2026-12-23) terms lock. FM4 would require pausing a launch that the plan schedules earlier than the insurance lock.
- **Suggested resolution:** Define the presale start date: deposits open only after the gate convention, presale terms/SLA and legal opinion (Month 1 = 2026-11-08), and state clearly whether deposits may be taken before insurance is bound (Month 2.5 = 2026-12-23). Publish the certificate after the Month 2.5 (2026-12-23) lock.

## Summary

The plan is largely consistent on its structure: EUR 750k split into 400k and 350k, the single SKU, the Year-1 allocation, the Month 0.5/1/1.5/3/5/6/8/12.5 (2026-10-23, 2026-11-08, 2026-11-23, 2027-01-08, 2027-03-08, 2027-04-08, 2027-06-08, 2027-10-23) milestones, and the deposit-as-liability rule all reconcile with the canonical facts. The main defects are arithmetic and threshold drift. The prepper-downside shortfall is understated (13.75k instead of 33.75k). The EUR 120 realised-price floor and the EUR 50-67 margin range are inconsistent with the 25k gate. The pitch uses a 30k gate and a EUR 149 deposit that the canonical facts leave open. Unit-cost stop rules and several reserve and headroom figures do not follow from the canonical numbers. There are also a few sequencing errors (design-readiness review after sample submission, tooling gate at Month 5 = 2027-03-08 versus Month 6 = 2027-04-08, presale "open now" versus Month 1 = 2026-11-08 prerequisites). Most are repairable text fixes. The real open decisions are deposit use and share, and funding for the 75k operations line and for any CE or lab overrun.