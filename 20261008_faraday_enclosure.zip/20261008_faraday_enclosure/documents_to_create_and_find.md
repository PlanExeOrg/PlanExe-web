# Documents to Create

## Create Document 1: Project Charter & Governance Framework

**ID**: 85af38e3-5fa0-45c0-a86e-f2690889a110

**Description**: Foundational charter document establishing project scope (single-SKU rigid Faraday enclosure, Tallinn manufacturing, EU market), stakeholder roles, decision authorities, approval governance, and critical success criteria. Audience: founder, external advisor, all key roles. Includes cash-flow gate definition, tranche-release conditions, and tiebreak rules. Status: prerequisite for all downstream planning.

**Responsible Role Type**: Project Manager & Founder

**Primary Template**: PMI Project Charter Template

**Secondary Template**: World Bank Logical Framework

**Steps to Create**:

- Define project scope, objectives, and constraints (EUR 400k Year-1 cap, EUR 350k conditional tranche, Month 12.5 = 2027-10-23 gate decision).
- Establish governance structure: founder + external advisor sign-off on cash-flow gate by Month 12.5 (2027-10-23).
- Document decision authorities for critical gates: design-readiness (Month 5 = 2027-03-08), hard-tooling release (Month 6 = 2027-04-08), presale cutoff (Month 8 = 2027-06-08), cash-flow gate (Month 12.5 = 2027-10-23).
- Specify approval authorities for gate decisions and escalation rules for ambiguous results.
- Publish charter and obtain founder and advisor sign-off by Month 0.5 (2026-10-23).

**Approval Authorities**: Founder, External Financial Advisor

**Essential Information**:

- Define the single-SKU scope (rigid folded aluminium/steel Faraday enclosure, conductive-gasket lid seam, Tallinn manufacturing, EU market) and explicitly exclude server-grade cages and multi-SKU variants.
- Establish the governance structure: identify decision authorities (founder, external financial advisor) and approval workflow for critical gates (design-readiness Month 5 = 2027-03-08, hard-tooling release Month 6 = 2027-04-08, presale cutoff Month 8 = 2027-06-08, cash-flow gate sign-off Month 12.5 = 2027-10-23).
- Document the cash-flow gate measurement convention in writing: define 'positive cash flow' as trailing-quarter operating surplus from delivered-unit revenue only (excluding presale deposits), set the threshold at EUR 25k (proposed), and specify the measurement window (Months 9-12 = 2027-07-08 to 2027-10-08).
- Specify presale deposit accounting: classify deposits as liabilities held in a separate earmarked account, never counted as cash flow, and reserved exclusively for fulfillment. Set a refund cap trigger (15% cumulative by Month 8 = 2027-06-08) and a segment-rebalancing response.
- Define the hard-tooling release gate: deposits must reach EUR 80k (proposed threshold) AND the accredited lab pre-test/design-readiness review must confirm design readiness. Document the decision logic and escalation if either condition is missed.
- Establish tiebreak rules for ambiguous gate results: pass if >= EUR 25k, fail if < -EUR 5k, ambiguous -5k to +25k: founder may extend runway 90 days and re-measure or release on advisor recommendation.
- List all critical stakeholders and their decision authorities: founder (capital, strategy, tiebreak), external financial advisor (gate sign-off, independent verification), EMC consultancy (design milestones), university lab (prototype rig), accredited lab (design-readiness review), Tallinn fabricator (tooling and batch release), legal counsel (compliance posture), product-liability insurer (claim cover limits).
- Document the budget cap (EUR 400k Year-1 hard ceiling) and explicitly allocate across design/prototyping (70k), in-house test rig (40k), accredited lab (15k), soft tooling (20k), production line 160k, marketing/sales/operations (75k), and redesign reserve (20k). Identify free contingency (EUR 20k reserve only; zero production headroom).
- Specify the presale cutoff date (Month 8 = 2027-06-08) and delivery lead-time promise (2-3 weeks from order confirmation), so fulfilled deliveries arrive before gate measurement (Month 12 = 2027-10-08).
- Define the approval and escalation process: founder and external advisor jointly measure cash-flow result by Month 12.5 (2027-10-23); document what evidence (bank statements, invoices, quarterly P&L) is required; specify who signs the gate decision and how disputes are resolved.

**Risks of Poor Quality**:

- Ambiguous gate definition (unwritten, loosely interpreted) leads to founder and advisor disagreement at Month 12 (2027-10-08), delaying the EUR 350k tranche decision into Month 13-14 (2027-11-08 to 2027-12-08) when market momentum is fading and competitive threats emerge.
- Failure to document hard-tooling gate logic allows premature or incorrect commitment of the 30k tooling spend before presale deposits or lab confirmation arrive, locking sunk cost into a design that later fails accredited testing, exhausting the 20k redesign reserve and forcing a tranche-dependent delay.
- Undefined presale deposit accounting (loose treatment as 'cash') creates perverse incentive to release the EUR 350k follow-on before presale fulfillment is proven, risking the company spending follow-on cash on operations while presale refunds and delivery slips consume cash, leaving Year-2 underfunded and operations stranded.
- Lack of governance structure and decision authorities for critical gates enables founder solo decision-making without external validation, increasing risk of poor judgment under cash pressure (Month 8-10 = 2027-06-08 to 2027-08-08) and creating founder liability if advisory board disputes the gate sign-off later.
- Missing escalation rules for ambiguous results (gate falls -5k to +25k, or lab delays Month 6 = 2027-04-08 → Month 7 = 2027-05-08) creates operational paralysis: founder delays tooling release while cash burn continues, or commits tooling prematurely to force gate result, both leading to poor outcomes.
- Undefined presale cutoff and delivery-lead-time promise allows orders placed in Month 9-10 (2027-07-08 to 2027-08-08) to deliver after gate measurement (Month 12 = 2027-10-08), missing in-time revenue by EUR 10-30k and causing the gate to fail by thin margin when it could have passed with proper cutoff enforcement.
- Failing to identify and document stakeholder roles creates confusion on who approves design changes, budget overruns, supplier switching, segment pivots, and presale campaign shifts, leading to delayed decisions and missed milestones during high-stress months (Months 6-9 = 2027-04-08 to 2027-07-08).
- Poor specification of the redesign reserve (EUR 20k, details undefined) leaves no clear decision rule for whether a lab re-test overrun (8-15k per test) triggers reserve draw-down, higher approval threshold, marketing cuts, or tranche dependency, creating surprise and conflict at decision time.

**Worst Case Scenario**: A founder-led venture with EUR 400k Year-1 cap and a EUR 350k tranche gated on positive cash flow launches without a written charter or gate definition. At Month 12 (2027-10-08), presales total EUR 95k (above the EUR 80k threshold estimate), but 30% prepper mix and long infrastructure sales cycles result in only EUR 18k of deliverable revenue by Month 12 (2027-10-08), missing the EUR 25k gate threshold by EUR 7k. The founder and external advisor dispute whether presale deposits (EUR 95k, liabilities) should count as cash, or whether the gate measurement window should extend past Month 12 (2027-10-08) to include Month 13-14 (2027-11-08 to 2027-12-08) deliveries. Without written convention, they disagree for 4 weeks (Month 12.5-13 = 2027-10-23 to 2027-11-23), during which market attention fades, a competitor launches, and two infrastructure pilots are lost. The EUR 350k tranche is withheld; the company has no capital for inventory replenishment or marketing. The founder is forced to wind down or seek dilutive external funding at a weak valuation, or to operate on presale cash flow alone (EUR 18k quarterly) insufficient to sustain operations (EUR 20k quarterly opex). The venture fails to become viable within Year-2.

**Best Case Scenario**: A written charter and governance framework published by Month 0.5 (2026-10-23) defines scope, stakeholders, decision authorities, and the cash-flow gate measurement convention (delivered-unit revenue only, EUR 25k threshold, Month 9-12 = 2027-07-08 to 2027-10-08 window, founder + advisor sign-off by Month 12.5 = 2027-10-23). The charter transparently communicates the gate logic to all presale customers and stakeholders upfront, building trust. At Month 6 (2027-04-08), the hard-tooling gate is clearly met: EUR 110k presale deposits (confirmed) and accredited lab pre-test confirms design readiness. Batch-1 tooling is released with no ambiguity. By Month 12 (2027-10-08), presales reach EUR 160k (mixed prepper, infrastructure, privacy segments), and 1,200 units are delivered, generating EUR 80.4k in operating cash flow (1,200 × EUR 67 contribution - EUR 20k opex) with EUR 55k surplus above the gate. The EUR 350k follow-on is released by Month 12.5 (2027-10-23) on schedule; the founder confidently commits to inventory replenishment, multi-channel marketing, and a smaller-SKU variant, accelerating Year-2 to 3,000 units and EUR 121k annual operating profit (estimate). The clear governance framework enables rapid decision-making during high-stress periods and delivers founder credibility for future funding.

**Fallback Alternative Approaches**:

- If writing a full PMI Project Charter and Logical Framework document proves time-intensive, adopt a lightweight alternative: draft a 2-3 page 'Gate & Governance Charter' (Month 0.5 = 2026-10-23) covering only the critical elements—scope, decision authorities, gate definition, tiebreak rules, and stakeholder roles—and defer detailed RACI and approval workflows to a separate 'Decision Authority Matrix' (Month 1 = 2026-11-08). Use a pre-approved company or industry template (e.g., World Bank Logical Framework, simplified) and adapt the critical sections rather than writing from scratch.
- If consensus on the gate definition is difficult (founder uncertainty about threshold, advisor skepticism about presale deposit treatment), schedule a 2-hour facilitated working session (Month 0.25 = 2026-10-16) with founder and external advisor to co-author the convention, using a structured template (define 'cash,' set threshold, write measurement formula, document tiebreak) and document the outcome as a 1-page memo signed by both. Record dissent (if any) as an appendix so disputes do not re-emerge later.
- If legal counsel is unavailable or slow (legal opinion blocked until Month 1.5 = 2026-11-23), commission the Product Charter in parallel with a simplified 'Interim Compliance Statement' (Month 0.5 = 2026-10-23) listing which EU directives are assumed applicable (General Product Safety, EMC, consumer protection), what claims will be restricted, and a placeholder for full legal opinion by Month 1.5 (2026-11-23). Update the charter once the opinion arrives.
- If external advisor is unavailable or reluctant to co-sign the gate, designate a qualified alternative (accountant, experienced mentor, sector advisor) with clear authority and sign-off responsibility by Month 0.5 (2026-10-23). Document their qualifications and contact/escalation protocol in the charter so no ambiguity exists about who measures the gate result.
- If presale deposit accounting remains contentious (founder wants to count deposits as cash, advisor opposes), publish both views in the charter with a tiebreak rule: 'Presale deposits are classified as liabilities by default (conservative); if presale refund rate stays below 10% through Month 9 (2027-07-08), founder may request a 1-month variance review (Month 10 = 2027-08-08) to re-classify surplus deposits as contributed cash, subject to advisor approval.' Document the variance process so it is controlled, not ad hoc.

## Create Document 2: Cash-Flow Gate Measurement Convention & Governance Rule

**ID**: 88a41893-e4a3-4ada-b07d-b57ada98927d

**Description**: Binding written rule defining what constitutes positive cash flow for the EUR 350k tranche release. Specifies: operating cash surplus = delivered-unit receipts minus direct unit costs minus recurring opex (presale deposits excluded); threshold EUR 25k quarterly (Months 9-12 = 2027-07-08 to 2027-10-08); measurement window end Month 12.5 (2027-10-23); tiebreak rule for ambiguous ±5k range; external audit requirement. Audience: founder, external advisor, stakeholders. Status: must be published before presale launch.

**Responsible Role Type**: Financial Officer & Founder

**Primary Template**: Financial Governance Policy Template

**Secondary Template**: Funding Agreement Conditions Precedent

**Steps to Create**:

- Define operating cash flow calculation method: receipts from delivered and paid units only.
- Exclude presale deposits from cash-flow definition; classify as liabilities in separate earmarked account.
- Set threshold (EUR 25k quarterly, Month 9-12 = 2027-07-08 to 2027-10-08 measurement window).
- Define presale cutoff date (Month 8 = 2027-06-08) to ensure fulfillment before gate measurement.
- Document tiebreak rule: if result is -EUR 5k to +EUR 25k, founder + external advisor jointly decide within 5 business days.
- Specify weekly tracking dashboard and monthly cash reconciliation process.
- Obtain founder and external advisor signatures by Month 0.5 (2026-10-23).

**Approval Authorities**: Founder, External Financial Advisor

**Essential Information**:

- Define the precise accounting rule for 'positive cash flow': specify that it is calculated as trailing-quarter operating receipts from delivered and paid units minus direct unit costs (EUR 70 per unit cost plus EUR 12 freight, estimate) minus recurring quarterly opex (EUR 20k per quarter, estimate), with presale deposits explicitly excluded and held as liabilities in a separate earmarked account.
- Establish the cash-flow threshold and measurement window: EUR 25k (proposed threshold) cumulative quarterly operating surplus measured over Months 9–12 (2027-07-08 to 2027-10-08), with sign-off deadline Month 12.5 (2027-10-23).
- Document the presale cutoff date (Month 8 = 2027-06-08) to ensure customer orders are fulfilled before the gate measurement window, preventing delivery delays from eroding cash flow.
- Define the tiebreak rule for ambiguous results (EUR –5k to +25k range): founder and external advisor jointly decide within 5 business days whether to extend the measurement window 90 days or accept the result as-is.
- Specify the weekly cash-tracking dashboard and monthly reconciliation process: track operational receipts, direct costs, presale deposits (as liabilities), refund rate (stop rule: >15% of deposits by Month 8 = 2027-06-08 triggers narrative pivot), and the calculated operating surplus.
- Detail the presale deposit handling: deposits held in separate earmarked account, ring-fenced exclusively for fulfilling matching orders, never counted as operational cash flow, and refunded on request without drawing on operating cash.
- Include the refund-rate trigger: if cumulative refunds exceed 15% of total deposits by Month 8 (2027-06-08), founder reviews and may pivot marketing narrative or buyer-segment strategy.
- Specify governance and sign-off: founder and one external advisor (accountant or experienced mentor) jointly measure the result and sign off; decision is binding and non-negotiable unless the tiebreak rule applies.
- Explain the consequence of passing the gate (≥EUR 25k): the EUR 350k follow-on tranche is released by Month 13 (2027-11-08) for inventory, marketing, R&D and buffer-stock deployment.
- Explain the consequence of failing the gate (<EUR –5k): the EUR 350k follow-on is withheld, and founder retains discretion to extend runway 90 days (to end of Month 15 = 2028-01-08) and re-measure, or to wind down the venture.

**Risks of Poor Quality**:

- Loose or ambiguous definition of 'positive cash flow' allows presale deposits (which are customer liabilities, not earnings) to be counted as operational cash, masking weakness in actual unit profitability. Result: EUR 350k tranche is released prematurely before fulfillment obligations are met; subsequent refunds or delivery delays consume the follow-on capital, leaving Year-2 underfunded and forcing external funding with founder dilution.
- Failure to exclude presale deposits from the cash-flow calculation or to ring-fence them in a separate account creates perverse incentive to commit follow-on spending before customer orders are actually fulfilled and paid, concentrating cash-flow timing risk into the gate-measurement window.
- Unclear or unpublished gate rule leads to founder-advisor disagreement at Month 12 (2027-10-08), delaying the EUR 350k decision into Month 13–14 (2027-11-08 to 2027-12-08) when competitive and seasonal pressures mount; delayed capital commitment misses Q1 Year-2 inventory and marketing windows.
- Missing presale cutoff date (Month 8 = 2027-06-08) allows late orders placed in Month 9–10 (2027-07-08 to 2027-08-08) to slip fulfillment into Month 11–12 (2027-09-08 to 2027-10-08) or later, pushing delivered-unit receipts past the gate measurement window and causing in-time revenue to miss by EUR 10–30k (100–300 units at EUR 67 margin estimate).
- Ill-defined tiebreak rule for ambiguous results (EUR –5k to +25k) creates governance vacuum: founder and advisor may dispute whether to extend 90 days or declare gate failure, burning weeks of decision time when presale fulfillment momentum matters.
- No monthly cash-tracking dashboard or reconciliation process allows operational cash drift (e.g., presale liabilities being used for opex, or refund spikes) to remain undetected until gate measurement, by which time corrective action is too late.
- Missing or loose refund-rate trigger (15% proposed threshold) fails to alert founder to demand weakness early; refund spike in Month 7–8 (2027-05-08 to 2027-06-08) due to delivery delays or narrative fatigue can erode operating cash by EUR 15–30k (estimate), tipping a marginal pass into a fail.

**Worst Case Scenario**: The gate convention is published ambiguously or presale deposits are loosely counted as 'cash flow'. By Month 11 (2027-09-08), presale deposits total EUR 120k but fulfillment lags: only 500 of 1,200 promised units are delivered and invoiced, yielding delivered-unit revenue of EUR 75k (500 × EUR 149 list price, estimate). Direct costs and quarterly opex consume EUR 55k (500 × EUR 82 direct cost, estimate plus EUR 20k opex), leaving EUR 20k operating surplus. However, if presale deposits are loosely counted, the convention appears to show EUR 120k cash inflow, triggering EUR 350k release. By Month 12 (2027-10-08), delivery delays and refund requests consume EUR 30k of the follow-on capital; the founder ends Year-2 with EUR 350k tranche spent on fulfillment and opex, no capital for inventory replenishment or growth, and a venture underfunded for any strategic pivot. Alternatively, if the gate convention is ambiguous, the founder and advisor dispute the result for 3 weeks; the decision is deferred to Month 13 (2027-11-08), missing the Month 12.5 (2027-10-23) deadline. The EUR 350k tranche hangs in limbo during critical Q1 Year-2 inventory and marketing season, presale momentum fades as customers wait for fulfillment, and the venture runs out of cash in Month 14 (2027-12-08) with no capital to execute growth or pivot. In either scenario, the founder's EUR 350k personal capital is committed blindly, capital discipline fails, and the venture enters financial distress or wind-down by Month 15 (2028-01-08).

**Best Case Scenario**: The gate convention is published before presale launch (Month 0.5 = 2026-10-23), defining cash flow precisely: delivered-unit receipts minus direct costs minus recurring opex, with presale deposits held as liabilities and excluded entirely. A presale cutoff date (Month 8 = 2027-06-08) ensures early orders are fulfilled by Month 12 (2027-10-08). By Month 11 (2027-09-08), 750 units are delivered and invoiced (EUR 112k revenue estimate); direct costs and quarterly opex total EUR 82k (estimate), leaving EUR 30k operating surplus, exceeding the EUR 25k gate by EUR 5.25k (estimate). The founder and external advisor sign off on the gate result by Month 12.5 (2027-10-23). The EUR 350k follow-on is released by Month 13 (2027-11-08), enabling inventory replenishment (200–300 unit buffer stock in an EU warehouse, EUR 30–60k estimate), expanded marketing for Q1 Year-2 (EUR 40–60k estimate), and R&D for a phone-only SKU variant. Year-2 steady-state achieves 750 units per quarter (3,000 annually) at EUR 67 margin (estimate), generating EUR 201k annual contribution, which exceeds EUR 80k recurring opex and yields EUR 121k annual operating surplus (estimate). The gate convention's transparency and founder-advisor sign-off establish governance credibility; presale customers understand delivery timelines and gate logic upfront, reducing refund risk and supporting sustainable growth. By Month 24 (2028-10-08) the venture reaches profitability and can consider organic expansion (warehouse footprint, SKU variants, or infrastructure market focus) without external funding dilution.

**Fallback Alternative Approaches**:

- If the gate convention cannot be agreed with an external advisor by Month 0.5 (2026-10-23), establish a simple, self-audit rule in writing (founder drafts, timestamps, and publishes to stakeholders): 'Quarterly operating cash = receipts from delivered units minus direct unit costs minus recurring opex; deposits excluded.' Founder measures result and publishes it monthly; external advisor spot-checks annually or at gate decision.
- If monthly cash-tracking and reconciliation process is too resource-intensive, use a simplified ledger: one sheet tracking receipts (by invoice date), direct costs (by unit count), opex, presale liability balance, and refund count. Update weekly and share with advisor monthly; trigger the 15% refund-rate stop rule automatically if refunds exceed that threshold.
- If presale deposits accumulate faster than expected (e.g., EUR 150k+ by Month 4 = 2027-02-08) and the founder is uncertain whether deposits should fund part of unit costs or remain 100% in the liability account, adopt a conservative rule: 'All presale deposits remain liabilities and are not counted against the production budget. Unit cost is paid from the EUR 160k production-line budget (decision). Deposits are held in trust and used only to fulfill matching customer orders or refund on request.' This avoids any ambiguity and keeps the 400k cap binding.
- If refund requests spike unexpectedly in Month 7–8 (2027-05-08 to 2027-06-08) due to news fatigue or delivery delays, and the 15% refund-rate trigger is hit, the founder may immediately (a) pivot marketing to the multi-use RF-isolation narrative (privacy, travel security, key-fob protection) to re-attract buyers, (b) offer a 30-day refund window (hard cutoff) for presales after which refunds are subject to a EUR 15 restocking fee (estimate), or (c) extend presale cutoff from Month 8 (2027-06-08) to Month 9 (2027-07-08) to allow more time for conversion before the gate window closes, if budget headroom allows.
- If the founder lacks an experienced financial advisor or cannot secure one by Month 1 (2026-11-08), substitute a quarterly accountant review (EUR 400–600 per quarter, estimate, within the 75k ops budget): an external accountant audits the monthly ledger, confirms the operating-cash calculation and presale-liability treatment, and co-signs the gate result with the founder at Month 12.5 (2027-10-23).
- If the gate decision becomes ambiguous (result falls in the EUR –5k to +25k range) and the founder and advisor cannot agree on the 90-day extension option, escalate to a neutral third-party decision-maker: a business advisor, mentor, or mentor group who reviews the cash statement and delivers a binding recommendation (pass, fail, or extend) within 5 business days. This preserves decision momentum and governance credibility.

## Create Document 3: Year-1 Monthly Budget & Burn Schedule

**ID**: bee838fc-0a54-40fa-8f5c-d9770e254284

**Description**: Detailed month-by-month allocation of the EUR 400k Year-1 cap across design (EUR 70k, Months 0-2 = 2026-10-08 to 2026-12-08), in-house rig (EUR 40k, Months 0-2 = 2026-10-08 to 2026-12-08), accredited lab (EUR 15k, Months 2-5 = 2026-12-08 to 2027-03-08), soft tooling (EUR 20k, Months 2-5 = 2026-12-08 to 2027-03-08), production line (EUR 160k, Months 5-12 = 2027-03-08 to 2027-10-08), marketing/operations (EUR 75k), and redesign reserve (EUR 20k, uncommitted until Month 5 = 2027-03-08). Includes monthly cash-burn review gates at Months 5 and 8 (2027-03-08, 2027-06-08) with >10% variance freeze trigger. Audience: founder, financial officer, external advisor.

**Responsible Role Type**: Financial Officer

**Primary Template**: Startup Monthly Cash-Flow Budget Template

**Secondary Template**: Stage-Gate Funding Schedule

**Steps to Create**:

- Break down the EUR 400k cap into category budgets (design, rig, lab, tooling, production, marketing, reserve).
- Allocate spend across Months 0-12 (2026-10-08 to 2027-10-08) based on project milestones (design freeze Month 2 = 2026-12-08, lab Month 5 = 2027-03-08, tooling Month 6 = 2027-04-08, fulfillment Months 6-9 = 2027-04-08 to 2027-07-08, gate measurement Months 9-12 = 2027-07-08 to 2027-10-08).
- Hold hard-tooling and full production-batch spending uncommitted until both conditions: deposits ≥EUR 80k AND lab pre-test confirms design (Month 5 = 2027-03-08).
- Establish monthly cash-burn review gates: Month 5 (2027-03-08) (EUR 40k overrun trigger), Month 8 (2027-06-08) (EUR 120k overrun trigger).
- Document contingency rules: if overrun >10%, freeze discretionary spending pending variance explanation.
- Preserve minimum EUR 30k runway for redesign fallback by Month 5 (2027-03-08).
- Create shared tracking spreadsheet (deposits, invoices, refunds, operating cash) for weekly founder-advisor review.

**Approval Authorities**: Founder, External Financial Advisor

**Essential Information**:

- Create a month-by-month (Months 0-12, 2026-10-08 to 2027-10-08) cash allocation table breaking down the EUR 400k hard cap across six spending categories: design/prototyping/EMC consultancy (EUR 70k, Months 0-2 = 2026-10-08 to 2026-12-08), in-house test rig (EUR 40k, Months 0-2 = 2026-10-08 to 2026-12-08), accredited lab fees (EUR 15k, Months 2-5 = 2026-12-08 to 2027-03-08), soft tooling (EUR 20k, Months 2-5 = 2026-12-08 to 2027-03-08), production line (EUR 160k including hard tooling EUR 30k, gasket stock EUR 7k, unit costs EUR 105k for 1,500 units, outbound freight EUR 18k; Months 5-12 = 2027-03-08 to 2027-10-08), marketing/sales/operations (EUR 75k), and redesign reserve (EUR 20k, uncommitted until Month 5 = 2027-03-08).
- Define and document the spending gate conditions: hard tooling and full production-batch spending are released only when both conditions are met simultaneously at Month 5 (2027-03-08): (a) net presale deposits ≥ EUR 80k (proposed threshold) AND (b) accredited lab pre-test/design-readiness review confirms the design is test-ready.
- Establish monthly cash-burn review gates with triggers: Month 5 (2027-03-08) gate checks cumulative design/rig/lab spend against EUR 40k threshold; if overrun > EUR 40k, freeze discretionary spending and trigger a variance explanation. Month 8 (2027-06-08) gate checks cumulative spend against EUR 120k threshold; if overrun > EUR 120k, halt non-critical spending pending review. Any variance > 10% triggers a spending freeze and variance analysis.
- Detail the production-line spending timeline: hard tooling (EUR 30k) and first batch commitment (EUR 160k total, about EUR 119k for 800 units at EUR 70 unit cost plus EUR 12 freight per unit) release only after the Month 5 (2027-03-08) dual gate. Batch 1 production Months 6-7 (2027-04-08 to 2027-05-08), fulfillment/shipment Months 7-9 (2027-05-08 to 2027-07-08), with follow-on batch of 700 units committed Months 8-9 (2027-06-08 to 2027-07-08) to meet the 1,500 Year-1 delivery target.
- Create a separate contingency and sensitivity section showing: (a) presale-shortfall scenario (deposits < EUR 80k by Month 6 = 2027-04-08 triggers stop rule: no hard tooling, pivot messaging, extend presale offer to Month 8 = 2027-06-08 at most); (b) lab-cost overrun scenario (standard costs EUR 25k instead of EUR 15k, or +10-20k for higher-cost standard); (c) redesign-reserve drawdown (one lab re-test EUR 8-15k reduces free contingency from EUR 20k to EUR 5-12k); (d) operational-expense overrun showing impact on the remaining Year-1 budget.
- Quantify and document the free Year-1 contingency: starting with EUR 20k redesign reserve and EUR 0 production headroom (total EUR 20k available for all unplanned costs and overruns). Show in-month cash position (cumulative actual spend vs. plan) and remaining runway at each gate checkpoint (Month 2, 5, 8, 12 = 2026-12-08, 2027-03-08, 2027-06-08, 2027-10-08).
- Define presale-deposit accounting: presale deposits are held in a separate earmarked account and classified as liabilities (not counted as cash), ringfenced exclusively for fulfilling presale orders, and never used for operating spending. Show a separate presale-liability schedule tracking deposits received, refunds issued, and net liability by month.
- Establish the operational-spending baseline: EUR 75k total across Months 0-12 (2026-10-08 to 2027-10-08), allocated as marketing/sales channels (deposit capture, segment targeting, brand messaging) estimated at EUR 40k, part-time operations hire at EUR 5-8k (10-15 h/week from Month 6 = 2027-04-08 onward at EUR 200-300/week), and contingency for legal opinion (EUR 2-5k), LCA (EUR 2-5k), and product-liability insurance premium (amount not estimated). Show which items are committed upfront vs. discretionary.
- Create a production-batch commitment schedule showing when Batch 1 (800 units, EUR 119k at list price EUR 149/unit) triggers and shipment windows (Month 7-8 = 2027-05-08 to 2027-06-08 production, Month 8-9 = 2027-06-08 to 2027-07-08 shipping for first 750 units; second 700 units Month 10-12 = 2027-08-08 to 2027-10-08). Include weekly shipment forecast tied to presale order timing.
- Specify the presale cutoff and lead-time impact: presale (deposit) offers close Month 8 (2027-06-08); build-to-order ships within 2-3 weeks of order confirmation (about 4-5 weeks total); orders placed after Month 8 (2027-06-08) continue as ordinary orders but are not promised in-time before the Month 12 (2027-10-08) cash-flow gate measurement window. Calculate the latest order-placement date for in-time delivery (about Month 9 = 2027-07-08) and map presale cutoff to fulfillment completion.
- Document the cash-flow gate measurement criteria in the budget context: operating cash surplus of the trailing quarter (Months 9-12 = 2027-07-08 to 2027-10-08) = (delivered-unit revenue - direct unit costs - recurring opex), threshold ≥ EUR 25k (proposed threshold). Show the base-case quarterly cash-flow projection (1,500 units delivered = 750 Months 7-8 = 2027-05-08 to 2027-06-08, 750 Months 9-12 = 2027-07-08 to 2027-10-08; 750 Q3 units deliver EUR 50.25k revenue - EUR 61.5k direct cost - EUR 20k opex = -EUR 31.25k; 750 Q4 units deliver EUR 50.25k revenue - EUR 61.5k direct cost - EUR 20k opex = -EUR 31.25k; revised: calculate the actual quarterly split based on the build-to-order 2-3 week lead time from order confirmation). Verify the gate passes with the 5.25k margin above EUR 25k threshold.

**Risks of Poor Quality**:

- Unsequenced or ambiguous spending gate conditions allow hard tooling and production batches to be committed before presale deposits or design validation exist, creating sunk-cost risk if the accredited lab test later fails or presales underperform. The result is EUR 30-40k in non-recoverable tooling and initial-batch costs with no revenue offset.
- Missing monthly cash-burn checkpoints leave spending uncontrolled; a 20% overrun in design or prototyping (EUR 14k) compresses the remaining production budget and forces late-stage cuts to inventory, marketing, or contingency, reducing presale velocity and increasing the risk of missing the EUR 80k deposit gate.
- Incorrect or missing presale-deposit accounting treats refundable customer deposits as operating cash, inflating the apparent cash position and triggering false signals that hard tooling should be released. When deposits are later refunded or converted to liabilities, operating cash falls short of plan and the company faces a cash-flow crisis mid-Year-1.
- Miscalculation or omission of the redesign reserve in the gate-contingency section leaves zero fallback funding if the accredited lab test reveals a need for a re-test (EUR 8-15k) or if a higher-cost EMC standard is recommended (EUR 10-20k overrun estimate). The company must then choose between cutting production inventory (losing the presale gate advantage) or seeking unplanned external capital.
- Unclear production-batch timing and fulfillment lead times result in shipments arriving after the Month 12 (2027-10-08) cash-flow gate measurement window, so the delivered-unit revenue that was forecast to pass the gate never materializes in the measurement period. The gate fails not because the product is unsaleable, but because fulfillment scheduling was not tied to the gate deadline.
- Absence of contingency and sensitivity scenarios for presale shortfall, lab-cost overruns, or operational delays leaves the founder without decision rules. When a risk materializes (deposits lag, lab cost exceeds budget, or fulfillment slips), the budget becomes obsolete and the founder must improvise rather than execute a pre-planned pivot.
- Lack of monthly cash-position tracking and early-warning indicators prevents timely detection of spending drift. A EUR 10-15k overrun in Months 2-3 (2026-12-08 to 2027-01-08) that should trigger a variance investigation instead compounds silently, and by Month 5 (2027-03-08) the company discovers a EUR 50k shortfall with limited time to adjust.
- Omission or understatement of operational expenses (legal opinion, product-liability insurance, LCA, part-time operations hire) results in actual Year-1 spending exceeding the EUR 75k budget line by EUR 5-15k. The overrun competes with production or marketing spend, reducing inventory or campaign reach and weakening the presale target.
- Failure to align the presale cutoff date (Month 8 = 2027-06-08) and build-to-order lead time (2-3 weeks = 4-5 weeks total) with the cash-flow gate measurement window (Months 9-12 = 2027-07-08 to 2027-10-08) causes orders placed in Months 8-9 (2027-06-08 to 2027-07-08) to deliver in Months 10-12 (2027-08-08 to 2027-10-08), missing the gate deadline if fulfillment slips by even 1-2 weeks.
- Unclear or missing quarterly cash-flow breakdown leaves ambiguity about whether the gate is passed. If Months 9-12 (2027-07-08 to 2027-10-08) are split unequally (e.g., 200 units Months 9-10 = 2027-07-08 to 2027-08-08, 550 units Months 11-12 = 2027-09-08 to 2027-10-08), the measurement window calculation and the EUR 25k threshold verification are opaque, inviting founder second-guessing or advisor dispute at Month 12.5 (2027-10-23) sign-off.

**Worst Case Scenario**: 
Hard tooling (EUR 30k) and the first production batch (EUR 89k for 800 units) are committed in Month 5-6 (2027-03-08 to 2027-04-08) based on presale deposits of EUR 85k and a lab pre-test confirmation. However, the accredited lab then reports that the enclosure design requires a more stringent standard or seam redesign, recommending a EUR 18k re-test and EUR 5-10k in design changes. The redesign reserve of EUR 20k is consumed entirely. Concurrently, presale refunds spike to EUR 12k (15% of deposits) due to a news-cycle fade on Carrington risk, reducing net deposits to EUR 73k. Hard tooling and batch 1 inventory (EUR 119k total) are already committed and cannot be cancelled. Production proceeds, but design-change delays push fulfillment from Month 8 (2027-06-08) to Month 10 (2027-08-08). By the cash-flow gate measurement window (Months 9-12 = 2027-07-08 to 2027-10-08), only 300 units are delivered (vs. 750 planned), generating EUR 20.1k in revenue, which after direct costs (EUR 24.6k) and EUR 20k opex yields EUR -24.5k cash flow—well below the EUR 25k gate threshold. The EUR 350k follow-on tranche is withheld. The company is left holding EUR 60k in excess unsold inventory, EUR 10k in presale refund obligations, and depleted cash reserves by Month 13 (2027-11-08), forcing an immediate wind-down or emergency restructuring.


**Best Case Scenario**: 
The Year-1 Monthly Budget & Burn Schedule is completed by Month 0.5 (2026-10-23) with clear month-by-month allocation, gate conditions, and contingency triggers. Design and prototyping complete on schedule (Month 2 = 2026-12-08), consuming EUR 70k as budgeted. In-house rig validation passes (Month 3 = 2027-01-08, EUR 40k). Accredited lab pre-engagement confirms a EUR 15k, 6-week standard (Months 4-5 = 2027-02-08 to 2027-03-08). Presale campaigns in three buyer segments generate EUR 92k net deposits by Month 5 (2027-03-08), exceeding the EUR 80k gate threshold. Lab report confirms design readiness in Month 5 (2027-03-08) with no redesign needed. Hard tooling and Batch 1 (EUR 119k) are committed in Month 6 (2027-04-08) with zero delay. Production and fulfillment proceed as planned: 750 units ship Months 7-8 (2027-05-08 to 2027-06-08), 750 units ship Months 9-12 (2027-07-08 to 2027-10-08). By the gate measurement window (Months 9-12 = 2027-07-08 to 2027-10-08), 750 delivered units generate EUR 50.25k revenue, direct costs are EUR 61.5k, opex is EUR 20k, yielding EUR -31.25k in Q4. However, the 750 units delivered in Months 7-8 (2027-05-08 to 2027-06-08) (EUR 50.25k revenue, EUR 61.5k cost, EUR 20k opex in Q3) yield EUR -31.25k in Q3. Revised: if 375 units deliver in Months 7-8 (2027-05-08 to 2027-06-08) (Q3 surplus EUR 25.12k - 30.75k - 20k = EUR -25.63k) and 1,125 units in Months 9-12 (2027-07-08 to 2027-10-08) (Q4 surplus EUR 75.38k - 92.25k - 20k = EUR -36.87k), the gate fails on the arithmetic alone. Recalculation: break-even is 299 units/quarter; 750 units/quarter at EUR 67 contribution = EUR 50.25k - 20k opex = EUR 30.25k surplus per quarter, passing the EUR 25k gate. The EUR 350k follow-on is released in Month 12.5 (2027-10-23) by founder and advisor sign-off. Inventory turnover meets the 30-40 day target; presale refund rate stays below 10%; no cost overruns or design changes consume contingency. The company enters Year-2 with positive cash flow, proven traction (1,500 units, 40+ reference customers), and EUR 350k in capital to fund inventory buildup, multi-channel marketing, and a smaller-SKU variant. First-year financial close shows EUR 350-370k revenue, EUR 160-180k direct costs, EUR 80k opex, and EUR 110-130k net operating income, demonstrating the venture's viability to the founder and potential future investors.


**Fallback Alternative Approaches**:

- If detailed monthly spend forecasting proves time-prohibitive or uncertain, create a simplified quarterly budget (Q1-4 of Year-1) with the same allocation and gate conditions, and defer detailed monthly scheduling until Month 1 (2026-11-08) after initial design and presale setup are confirmed. This reduces the upfront planning burden while preserving the critical gate logic.
- If presale deposits and lab timeline uncertainty makes the Month 5 (2027-03-08) hard-tooling gate too rigid, introduce a rolling contingency: commit soft tooling and design finalization by Month 5 (2027-03-08) unconditionally (EUR 70k + EUR 20k = EUR 90k sunk), but gate hard tooling and batch production on a sliding window (Month 6-7 = 2027-04-08 to 2027-05-08) based on accumulated deposits and lab pre-test results, so a 1-month slip in the lab does not automatically force a hard-tooling miss.
- Engage a part-time financial controller or bookkeeper (5-10 h/week, EUR 150-200/week estimate) starting Month 0 (2026-10-08) to build and maintain the budget spreadsheet, reconcile actual spend against plan weekly, and flag variances before they compound. This transfers the execution burden from the founder and ensures the budget is a live tool rather than a static plan.
- If the presale-deposit accounting and gate-measurement rule remain ambiguous despite effort to clarify them, ask the external financial advisor (the Month 12.5 = 2027-10-23 sign-off party) to draft the convention in collaboration with the founder by Month 0 (2026-10-08), so they jointly own the rule and disputes at gate measurement are avoided.
- If contingency and sensitivity scenarios prove complex, use a simple 'impact ladder' format: for each risk (lab cost overrun, presale shortfall, refund spike), document the trigger threshold (EUR amount or date), the impact on the budget (which line-item is cut or which gate is delayed), and the decision rule (e.g., 'if lab cost > EUR 25k, cut marketing by EUR 10k and extend presale deadline'). This makes contingencies actionable without full scenario modeling.
- If monthly shipment forecasting from presale orders is unpredictable, use a conservative assumption: hold back 20-30% of planned Year-1 delivery volume (target 1,500, conservative 1,050-1,200) and recognize it only when presale orders are in hand (Month 6 = 2027-04-08 onward). The gate measurement window then uses the conservative volume, and any additional shipments in Months 11-12 (2027-09-08 to 2027-10-08) are upside to the cash-flow calculation.
- If product-liability insurance costs prove difficult to estimate, obtain preliminary quotes from 2-3 insurers by Month 1 (2026-11-08) and include the mid-range premium (estimate: EUR 1-2k annually or EUR 200-400 one-time) in the EUR 75k operational line. Lock the final premium by Month 2.5 (2026-12-23) and document any variance as an overrun against the EUR 75k allocation.
- If the redesign reserve of EUR 20k feels insufficient after initial design or supply-chain assessment, increase it to EUR 30k by deferring EUR 10k of Year-1 marketing spend (reduce the EUR 75k ops line to EUR 65k) and commit to a more aggressive paid-channel strategy (e.g., presale Kickstarter or platform fees) to reach the EUR 80k deposit gate faster, offsetting the marketing spend cut.

## Create Document 4: Shielding Proof Standard & Accredited Lab Statement of Work

**ID**: 7abd525d-bd43-46b1-a6ce-b8050a0e86b7

**Description**: Fixed-price, fixed-date engagement with accredited EMC laboratory specifying: applicable RF shielding standard (IEEE 299.1 or confirmed alternative), frequency range, cost cap (EUR 15k), design-readiness review (EUR 2-3k, Month 4 = 2027-02-08), report delivery date (Month 5 = 2027-03-08, latest Month 6 = 2027-04-08), re-test provision, and penalty clauses for schedule slip (EUR 500/week credit). Signed by Month 1.5 (2026-11-23). Includes backup lab pre-qualification by Month 2 (2026-12-08). Audience: RF engineer, project manager, financial officer.

**Responsible Role Type**: RF Engineer & Project Manager

**Primary Template**: Professional Services Statement of Work Template

**Secondary Template**: Laboratory Testing Agreement

**Steps to Create**:

- Contact 2-3 accredited EMC labs (Germany, Sweden, Netherlands, Estonia) for no-cost pre-engagement consultation by Month 0.5 (2026-10-23).
- Confirm applicable standard (IEEE 299.1 or alternative) and frequency range for small Faraday enclosures.
- Lock fixed cost (EUR 15k cap) and committed report delivery (Month 5 = 2027-03-08, no later than Month 6 = 2027-04-08).
- Request design-readiness review scope (EUR 2-3k, 2-week turnaround by Month 4 = 2027-02-08).
- Document re-test provision (included in EUR 15k cap or separately capped at EUR 10k).
- Include penalty clause for schedule slip: EUR 500/week credited against invoice.
- Pre-qualify secondary lab by Month 2 (2026-12-08) as fallback.
- Obtain signed statement of work by Month 1.5 (2026-11-23).

**Approval Authorities**: RF Engineer, Accredited EMC Laboratory Director

**Essential Information**:

- Specify the applicable RF shielding standard for small Faraday enclosures (IEEE 299.1 or confirmed alternative), confirmed via consultation with 2–3 accredited EMC laboratories by Month 0.5 (2026-10-23).
- Lock a fixed-price, fixed-delivery-date statement of work with the selected accredited EMC laboratory by Month 1.5 (2026-11-23), capping cost at EUR 15k and guaranteeing report delivery by Month 5 (2027-03-08), latest Month 6 (2027-04-08).
- Define and cost a design-readiness review service (EUR 2–3k estimate) to be conducted by Month 4 (2027-02-08), confirming the enclosure design is test-ready before costly sample submission.
- Document the frequency range, attenuation threshold, and test methodology the lab will use, so design targets align with actual test parameters before prototyping is complete.
- Include a re-test provision in the statement of work: clarify whether one re-test is included in the EUR 15k cap or capped separately at EUR 8–15k (estimate) if the first run fails or requires redesign.
- Establish penalty clause for schedule slip: EUR 500/week credit against invoice if the report delivery misses the committed date, protecting the Month 6 (2027-04-08) latest date for hard-tooling release.
- Pre-qualify a secondary accredited EMC laboratory by Month 2 (2026-12-08) as a fallback, with equivalent scope and timeline, to mitigate single-lab dependency risk.
- Obtain written, signed statement of work from the primary laboratory by Month 1.5 (2026-11-23); the SOW becomes the binding commitment and schedule control document for the accredited test phase.

**Risks of Poor Quality**:

- Vague or missing standard specification: if the chosen standard (IEEE 299.1 or alternative) is not confirmed in writing, the lab may recommend a costlier or longer standard (e.g. MIL-STD-285) during sample submission (Month 4 = 2027-02-08), adding EUR 10–20k and 4–8 weeks (estimate), consuming the EUR 20k redesign reserve and missing the Month 6 (2027-04-08) latest report date.
- No fixed price or delivery date: if the SOW leaves cost and timeline open, EUR 15k estimate overruns to EUR 25–30k and report slips to Month 7 (2027-05-08) or later, compressing the redesign buffer and pushing hard-tooling commit into Month 7 (2027-05-08) or beyond, which cascades presale fulfillment and misses the cash-flow gate measurement window.
- Inadequate or missing design-readiness review: without pre-test feedback from the lab, the design may have latent seam or gasket flaws that fail the formal test, forcing costly re-qualification (EUR 8–15k, estimate) and a 2-month delay, consuming the redesign reserve and delaying revenue past Month 12 (2027-10-08) gate measurement.
- Missing or weak penalty clause: if the lab slips schedule with no financial consequence, report delivery may stretch to Month 7–8 (2027-05-08 to 2027-06-08) or beyond, leaving no time for redesign and forcing a hard-tooling commit on unvalidated design or a gate-extension decision.
- No fallback laboratory: if the primary lab experiences capacity loss, shifts pricing, or fails to deliver, no secondary relationship exists, forcing urgent re-engagement that delays the report by 4–6 weeks (estimate) and risks missing the hard-tooling gate.
- Weak or missing re-test provision: if the SOW does not clarify whether re-testing is included in the EUR 15k cap, a first-run failure triggers a billing dispute and cost surprise (EUR 8–15k, estimate), exhausting contingency and forcing a tranche-extension decision to proceed.

**Worst Case Scenario**: 
The accredited laboratory recommends a higher-cost or longer standard (MIL-STD-285 vs. IEEE 299.1 estimate) during Month 4 (2027-02-08) sample submission, adding EUR 20k and 6–8 weeks. Simultaneously, the first test run reveals seam leakage at 100–500 MHz, necessitating a design change and re-test (EUR 12k, estimate). Combined unfunded cost: EUR 32k against the EUR 20k reserve, leaving a EUR 12k gap. The report slips to Month 7–8 (2027-05-08 to 2027-06-08) or beyond. Hard-tooling release is forced to month 7 (2027-05-08), batch 1 fulfillment compresses into Months 8–9 (2027-06-08 to 2027-07-08), and delivered-unit revenue (presale cutoff Month 8 = 2027-06-08) arrives too late to count toward the Q4 cash-flow gate (Months 9–12 = 2027-07-08 to 2027-10-08). Gate measurement is met only if prepper volume is higher than forecast; otherwise the EUR 350k follow-on is withheld, halting inventory and marketing, and forcing wind-down or founder capital injection.


**Best Case Scenario**: 
By Month 0.5 (2026-10-23), two accredited laboratories confirm that IEEE 299.1 is the applicable standard, cost is EUR 13–15k (fixed), and report delivery is guaranteed by Month 5 (2027-03-08). Design-readiness review by Month 4 (2027-02-08) confirms the enclosure seam design is sound and expected attenuation meets claims. First test run in Month 5 (2027-03-08) passes without rework. Report is published, hard-tooling commit is released by Month 6 (2027-04-08) on schedule, batch 1 (800 units) is delivered in Months 7–8 (2027-05-08 to 2027-06-08), and presale fulfillment achieves 750 delivered units by Month 12 (2027-10-08), generating EUR 50k+ operating cash flow (750 units × EUR 67 margin − EUR 20k opex = EUR 30.25k, within gate threshold). The EUR 350k follow-on is released by Month 12.5 (2027-10-23), enabling inventory replenishment, marketing ramp, and infrastructure pilot expansion. Credible, published lab report acts as procurement qualifier for infrastructure buyers, accelerating Year-2 sales.


**Fallback Alternative Approaches**:

- If primary lab contact is slow to respond, initiate contact with 3–4 laboratories simultaneously (Month 0.5 = 2026-10-23) and issue a competitive SOW request to the three most responsive, with decision deadline of Month 1 (2026-11-08). Select the lab with the firmest cost and timeline commitment, not necessarily the lowest cost.
- If the standard recommendation from the lab is costlier than IEEE 299.1 (estimate) and adds EUR 10k+ to the budget, schedule an urgent meeting (within 3 days) with the lab and the EMC consultancy (contracted by Month 0.5 = 2026-10-23) to evaluate whether a narrower frequency range or reduced attenuation threshold claim would meet marketing needs under the costlier standard, or whether a second lab's opinion could validate the lower-cost standard.
- If the design-readiness review is delayed or the lab lacks capacity for pre-test consultation, engage the contracted EMC consultancy to conduct an equivalent design review (within the EUR 20–25k consultancy budget) by Month 3 (2027-01-08) and use that feedback to de-risk the formal lab submission, then proceed with lab testing confident in design readiness.
- If the primary lab signals a schedule slip beyond Month 5 (2027-03-08) (e.g., due to their capacity constraints), invoke the secondary lab pre-qualified by Month 2 (2026-12-08) immediately. Transfer samples and SOW terms to the secondary lab, with a commitment to deliver report by Month 6 (2027-04-08); this delays start by 2–3 weeks but maintains the Month 6 (2027-04-08) latest date for hard-tooling release.
- If the first test run fails due to seam or gasket leakage, immediately engage the EMC consultancy to design a targeted gasket or seam revision (within 2 weeks, by Month 5.5 = 2027-03-23). Resubmit samples for re-test under the same lab or the secondary lab, targeting a report by Month 6.5 (2027-04-23). Hard-tooling release moves to Month 7 (2027-05-08), batch 1 fulfillment shifts to Months 8–9 (2027-06-08 to 2027-07-08), and presale cutoff becomes Month 7 (2027-05-08) instead of Month 8 (2027-06-08) to preserve time for fulfillment before the gate measurement window.

## Create Document 5: Enclosure Design & Prototype Validation Report

**ID**: 0edf4a7c-d5ce-485a-b91a-4bccba7251d7

**Description**: Technical documentation of the single rigid folded-aluminium/steel enclosure design (seam/gasket architecture, material specs, internal dimensions ~420 x 280 x 50 mm, mass 2-4 kg). Includes in-house rig validation results (attenuation at 50 MHz, 100 MHz, 500 MHz, 1 GHz across three independent prototype builds), seam-cycle repeatability data, and design-readiness confirmation for lab submission. Audience: RF engineer, project manager, accredited lab, compliance officer.

**Responsible Role Type**: RF Engineer

**Primary Template**: Engineering Design Review Template

**Secondary Template**: EMC Test Protocol Document

**Steps to Create**:

- Define enclosure geometry, material (aluminium/steel), seam/lid closure design, and conductive-gasket specification.
- Establish in-house test rig methodology and measurement protocol.
- Run two independent prototype seam cycles by Month 3 (2027-01-08), documenting attenuation across frequency band.
- Measure repeatability and identify any design vulnerabilities (e.g., gasket compression variance, seam leakage).
- Prepare design-readiness dossier for lab pre-engagement review (Month 4 = 2027-02-08): materials, seam design, in-house attenuation data, test plan.
- Document any design trade-offs (size vs. margin, weight vs. shielding, cost vs. performance).
- Obtain lab pre-test feedback and confirm design readiness by Month 5 (2027-03-08).

**Approval Authorities**: RF Engineer, Accredited EMC Laboratory

**Essential Information**:

- Define and document the rigid folded-aluminium/steel enclosure geometry: internal dimensions (target ~420 x 280 x 50 mm), external envelope, mass range (2-4 kg estimate), and form factor to fit common laptops (up to 17 inches) and phones (up to 6.5 inches).
- Specify the seam and lid-closure architecture: conductive-gasket design, material grade, compression tolerance, and repeatability requirements across multiple assembly cycles.
- Establish the in-house shielding test-rig methodology: measurement protocol, frequency bands tested (50 MHz, 100 MHz, 500 MHz, 1 GHz minimum estimate), attenuation threshold targets, and acceptance criteria aligned with IEEE 299.1 or equivalent standard.
- Execute two independent prototype seam cycles by Month 3 (2027-01-08), documenting measured attenuation across the full frequency band for each build, with statistical repeatability analysis.
- Measure gasket compression variance, seam-leakage risk, and identify design vulnerabilities (e.g., lid-hinge wear, material fatigue points, tolerance stack-up) that could degrade shielding after repeated cycles.
- Produce a design-readiness dossier for the accredited lab pre-engagement review (Month 4 = 2027-02-08): complete material specifications, seam CAD drawings, in-house attenuation data, proposed test plan, and identified trade-offs (size vs. margin, weight vs. shielding, cost vs. performance).
- Quantify design cost implications: material cost per unit, gasket sourcing (primary and backup suppliers), fabrication lead times, and tooling assumptions (soft vs. hard).
- Document design decisions and sign-offs: RF engineer approval, accredited lab feedback confirming design readiness by Month 5 (2027-03-08), and confirmation that the design is ready for sample submission without material changes.
- Provide visual and dimensional fit verification: photographs or CAD renderings showing the enclosure accommodating representative devices (13-inch, 15-inch, 17-inch laptops and major phone sizes), with documented pass/fail results.

**Risks of Poor Quality**:

- Incomplete or ambiguous seam/gasket design documentation delays accredited lab pre-engagement review by 2-4 weeks, pushing the lab-report delivery from Month 5 (2027-03-08) to Month 6-7 (2027-04-08 to 2027-05-08) and consuming the redesign buffer before the presale window opens.
- In-house rig validation omits critical attenuation data (e.g., missing frequency bands, only one seam cycle, no repeatability analysis) leading the accredited lab to reject the design as unproven, triggering a costly re-test (EUR 8-15k estimate) and 2-month delay.
- Design-readiness dossier lacks material-sourcing or lead-time details, causing the fabricator to report unobtainable gasket or metal grades during tooling planning (Month 5-6 = 2027-03-08 to 2027-04-08), forcing a redesign with no budget or time buffer.
- Failure to document design trade-offs (size, weight, cost) leaves ambiguity on hard-tooling assumptions; the accredited lab or fabricator later identifies rework needed after samples are submitted, adding EUR 5-10k re-work cost and 3-4 weeks delay.
- Fit-verification data missing or incomplete (no photos, only one laptop size tested) allows design to enter production with undetected fit problems, triggering 20-30% return/refund rate (estimate) and damaging presale conversion and Year-1 cash flow.
- Ambiguous cost or weight specifications leave production-batch planning without unit cost or BOM accuracy, making it impossible to commit the EUR 160k production-line budget or forecast presale contribution margin for the cash-flow gate.
- Lab pre-test feedback not documented or integrated into the final design; sample submission (Month 4 = 2027-02-08) reveals design changes not agreed with the lab, forcing re-work or requiring a new test run outside the EUR 15k budget.

**Worst Case Scenario**: 
The Enclosure Design & Prototype Validation Report is incomplete, omits critical attenuation data from in-house testing, or lacks accredited-lab design-readiness confirmation. The report is submitted to the lab without verified fit or gasket repeatability data. Lab review (Month 4 = 2027-02-08) reveals design ambiguities, material sourcing issues or unproven seam performance, triggering a mandatory second test run (EUR 8-15k estimate, +6-8 weeks). Redesign and re-test delays the final accredited report from Month 5 (2027-03-08) to Month 7 (2027-05-08), compressing presale window and production timeline. Hard-tooling release slips to Month 7-8 (2027-05-08 to 2027-06-08). First production batch delivers late (Month 9-10 = 2027-07-08 to 2027-08-08 vs. Month 6-7 target = 2027-04-08 to 2027-05-08), and presale fulfillment concentrates in Month 10-12 (2027-08-08 to 2027-10-08), missing the cash-flow gate measurement window (Months 9-12 = 2027-07-08 to 2027-10-08). Delivered-unit revenue falls short of the EUR 25k quarterly threshold (estimate 50-100 units delivered by end of Year-1 instead of 750 estimate), gate fails, and the EUR 350k follow-on is withheld, stranding the venture with unfulfilled presales, depleted cash, and no capital for operations or redesign.


**Best Case Scenario**: 
The Enclosure Design & Prototype Validation Report is complete by Month 3 (2027-01-08), documents two independent prototype seam cycles with confirmed attenuation across 50 MHz to 1 GHz band, verifies fit for laptops and phones, and includes a detailed design-readiness dossier with material specs, gasket sourcing plan, and cost breakdown. The report is submitted to the accredited lab by Month 3.5 (2027-01-23) and the lab pre-engagement review (Month 4 = 2027-02-08) confirms the design is test-ready with no material changes required. Sample submission proceeds without delay; the final accredited lab report is delivered by Month 5 (2027-03-08) as planned, confirming attenuation across the claimed frequency band. Hard tooling is released on schedule (Month 6 = 2027-04-08) once presale deposits meet the EUR 80k threshold, and first production batch (800 units, estimate) ships by Month 6 (2027-04-08). Presale fulfillment accelerates in Months 7-9 (2027-05-08 to 2027-07-08), ensuring 750-800 units delivered by Month 12 (2027-10-08), yielding EUR 50k+ quarterly cash surplus (estimate 750 units × EUR 67 contribution - EUR 20k opex ≈ EUR 30k) and passing the cash-flow gate. The EUR 350k follow-on is released on schedule (Month 12.5 = 2027-10-23), enabling buffer-stock warehousing, expanded marketing, and Year-2 growth.


**Fallback Alternative Approaches**:

- If in-house test rig is unavailable or delayed past Month 2 (2026-12-08): contract a university lab or accredited EMC facility to run preliminary shielding measurements on the first prototype (EUR 5-8k estimate, 2-3 weeks) to substitute for in-house validation, but lock this plan by Month 1.5 (2026-11-23) to avoid timeline slip.
- If accredited lab cannot accommodate a pre-test design-readiness review: conduct a structured design review with the independent EMC consultancy (included in the EUR 20-25k milestone budget) by Month 4 (2027-02-08), documenting readiness sign-off before sample submission to de-risk lab feedback delays.
- If prototype seam repeatability cannot be confirmed by Month 3 (2027-01-08): document the in-house results available and mark the design as 'provisional' pending accredited lab confirmation; note any seam-cycle variance as a known risk in the dossier and request the lab to prioritize seam stress-testing in the validation plan.
- If fit verification (multi-device testing) is incomplete by Month 3 (2027-01-08): publish preliminary size-and-fit guidance in presale materials based on CAD dimensions and label fits as 'estimated pending customer feedback,' with a 30-day presale fit-refund offer to de-risk oversized claims.
- If design-cost or material-sourcing data is unclear: engage the Tallinn fabricator for a 'cost-readiness review' (EUR 1-2k, 1 week turnaround estimate) to confirm material availability, gasket sourcing and unit-cost estimate, and integrate fabricator feedback into the dossier before the accredited lab review.
- If accredited lab requires material changes to the design after Month 4 (2027-02-08) sample submission: use the EUR 20k redesign reserve to fund one iteration (materials and re-test within 8-15k estimate); if changes exceed reserve, defer non-critical design features to a Month 9+ variant and keep the core single-SKU design stable.
- If schedule slip is unavoidable (design-readiness decision delayed to Month 6 = 2027-04-08 or later): pivot to a 'phased presale' model: (a) accept 'soft' presale commitments (non-refundable deposits) for Month 6+ delivery starting Month 4 (2027-02-08) with a caveat that design-readiness and lab report determine final delivery date; (b) hold 'hard' tooling and batch commitments until Month 6 (2027-04-08) lab report is confirmed.

## Create Document 6: Product Compliance & Regulatory Opinion

**ID**: 68b7e579-f559-4326-90f7-36d949724fc4

**Description**: Written legal opinion on EU product-safety rule applicability: EMC Directive 2014/30/EU, General Product Safety Directive 2001/95/EC, CE marking requirement, consumer-protection rules, warranty and liability exposure. Delivered by Month 1 (2026-11-08), informs claim-scope language and product-liability insurance strategy. Audience: founder, compliance officer, marketer, insurer.

**Responsible Role Type**: Legal Counsel

**Primary Template**: EU Product Compliance Legal Opinion Template

**Secondary Template**: Product Liability Risk Assessment

**Steps to Create**:

- Commission legal opinion from EU product-safety counsel by Month 0.5 (2026-10-23).
- Review applicable directives: EMC Directive, General Product Safety Directive, harmonized standards.
- Assess CE marking requirement: whether enclosure is in-scope or exempt.
- Evaluate consumer-protection rules and warranty/disclaimer language.
- Assess liability exposure if shielding claims are exceeded in a real electromagnetic event.
- Deliver written opinion by Month 1 (2026-11-08).
- Recommend scope-limitation language for all marketing and presale materials.

**Approval Authorities**: Legal Counsel (EU Product Safety Specialist)

**Essential Information**:

- Identify which EU product-safety directives apply to the Faraday enclosure: EMC Directive 2014/30/EU, General Product Safety Directive 2001/95/EC, or both (applicability not verified).
- Determine whether CE marking is legally required for the enclosure or whether it falls outside mandatory scope.
- Define the legally permissible scope and limits of all shielding-performance claims based on the measured attenuation data from the accredited lab report (target: accredited lab report by Month 5 = 2027-03-08).
- Assess liability exposure if shielding claims are not met in a real electromagnetic event (e.g., Carrington Event, RF exposure incident).
- Recommend precise warranty and liability-disclaimer language for all presale terms, marketing materials, and product documentation.
- Clarify product-liability insurance requirements: coverage scope (defect claims, misrepresentation), minimum coverage (250–500k estimate), and insurability of enclosure-shielding claims under EU product rules.
- Advise on consumer-protection and distance-selling compliance for presale deposits, refund terms, and delivery obligations under EU Directive 2011/83/EU.
- Identify any harmonized standards (e.g., IEC standards for enclosures) and their applicability to the shielding design and testing methodology.

**Risks of Poor Quality**:

- Unclear applicability of EU directives creates regulatory risk: if EMC Directive applies but is not identified, selling without CE marking exposes the company to regulatory challenge, mandatory recall, or fines (€10–30k estimate).
- Weak or ambiguous claim-scope language invites consumer complaints and misrepresentation claims if the enclosure underperforms in a real event; liability and reputational damage may exceed insurance coverage.
- Missing liability-disclaimer language in presale terms and warranty creates exposure to refund demands or class-action complaints if customers claim the product failed them; uninsured liability consumes founder capital.
- Failure to clarify product-liability insurance terms (coverage cap, exclusions, premium cost) leaves the company uninsured during Year-1 launch when presales and delivery pressure are high.
- Vague advice on claim limits allows marketing to exceed measured data, weakening credibility with infrastructure buyers and exposing the company to enforcement action by consumer-protection authorities.
- Missing or incorrect consumer-protection language on presale deposits and refund terms (EU Directive 2011/83/EU) violates distance-selling rules and creates liability for improper contract terms.

**Worst Case Scenario**: A regulatory challenge issued by an EU consumer-protection authority in Month 8–10 (2027-06-08 to 2027-08-08), mid-presale and near the cash-flow gate measurement window, alleges that shielding claims exceed measured data or that the enclosure falls under the EMC Directive and lacks required CE marking. The company is forced to halt presale marketing, revise all materials, and possibly submit to notified-body assessment (€10–30k, 8–12 weeks estimate). Presale deposits spike in refund requests as customers lose confidence; refund rate climbs from 15% to 30–40% (estimate), consuming €30–50k of deposits held as liabilities. Year-1 cash flow falls below the €25k gate threshold, the €350k follow-on is withheld, and the founder is left underfunded to complete fulfillment or pursue Year-2 growth. Reputational damage from regulatory action and media coverage of "false" shielding claims reduces future sales momentum by 40–60% (estimate), even after materials are corrected.

**Best Case Scenario**: A clear, authoritative legal opinion delivered by Month 1 (2026-11-08) identifies that the enclosure falls outside the EMC Directive and General Product Safety Directive scope (or only General Product Safety applies with limited restrictions), and provides precise claim-limiting language that is legally sufficient and commercially credible. Marketing and presale terms are revised to match measured data exactly, with a clear scope statement ('protects stored spare devices only') that aligns expectations and reduces refund risk. Product-liability insurance is locked at a reasonable premium (cost absorbed in the 75k marketing/operations budget), with confirmed coverage for €250–500k in defect and misrepresentation claims. Presale marketing proceeds with legal confidence, conversion rate remains 40–50% (estimate baseline) rather than declining due to regulatory uncertainty, and deposits meet the €80–120k tooling gate by Month 5–6 (2027-03-08 to 2027-04-08). The accredited lab report aligns with claims, no redesign is needed, and the enclosure reaches the cash-flow gate measurement window (Month 12 = 2027-10-08) with presale refund rates below 15% (estimate), allowing the gate to pass and the €350k follow-on to be released on schedule by Month 12.5 (2027-10-23).

**Fallback Alternative Approaches**:

- If EU product-rule applicability remains ambiguous after legal research, commission a second legal opinion from a notified-body advisor or EU regulatory consultant (€3–8k estimate, 2–3 weeks) to confirm CE marking scope and obtain a written safety assessment that can be published as supporting documentation alongside the accredited lab report.
- If product-liability insurance is unavailable or prohibitively expensive for Faraday enclosures, structure the presale and warranty terms to shift liability to customers: clearly state 'as-is' sale with strict scope limits, offer annual re-verification service as a paid add-on tied to seal maintenance, and limit refund periods to 30 days (standard consumer protection) rather than open-ended.
- If the legal opinion identifies that CE marking is required but accredited lab testing would delay Month 6 (2027-04-08) hard-tooling release, defer CE-marking submission and presale launch to Month 3 (2027-01-08) and pre-fund a notified-body assessment (€15–25k estimate) within the redesign reserve (increase from €20k to €40k by reallocating €20k from marketing), so hard tooling is not released until both test and CE work are complete.
- If legal counsel identifies that General Product Safety Directive imposes undocumented obligations (e.g., traceability, instruction manuals, testing records), establish a compliance tracking sheet by Month 1.5 (2026-11-23) listing all obligations and assign a part-time compliance person (5 h/week, €100/week estimate) to monitor adherence, absorbing cost in the €75k operations budget.
- If insurance is unavailable or covers only defect claims (not misrepresentation), add a third-party certification or audit layer (e.g., a published test summary from a reputable independent lab) to strengthen claim credibility and reduce perceived misrepresentation risk, shifting insurable liability from the company to the test evidence.

## Create Document 7: Presale Terms, Delivery SLA & Refund Policy

**ID**: 00f78eb1-4f29-41c0-88d5-84d340c14c27

**Description**: Customer-facing presale agreement specifying: order placement process, 30-day refund guarantee for fit/quality issues, 2-3 week ship SLA with 4-5 week estimated delivery, 48-hour customer support response target, device-fit responsibility disclaimer, and presale cutoff date (Month 8 = 2027-06-08). Linked to Product Fit Guide. Audience: presale customers, customer support, compliance officer.

**Responsible Role Type**: Legal Counsel & Presale Manager

**Primary Template**: E-Commerce Terms of Service Template

**Secondary Template**: Consumer Protection SLA Document

**Steps to Create**:

- Draft presale order agreement covering order confirmation, payment, and refund process.
- Specify 30-day money-back guarantee for fit and quality issues; refunds processed within 10 business days.
- State delivery timeline: ships within 2-3 weeks of order confirmation, estimated delivery 4-5 weeks.
- Include device-fit responsibility: customer verifies device compatibility using published fit guide.
- Link to detailed Product Fit Guide with dimensions and device examples.
- Specify customer support escalation: 48-hour response target, contact path.
- Include presale cutoff date (Month 8 = 2027-06-08) and post-cutoff order handling.
- Review with legal counsel for EU consumer-protection compliance.
- Publish on presale landing pages and send to all presale customers by Month 1.5 (2026-11-23).

**Approval Authorities**: Legal Counsel, Presale Manager

**Essential Information**:

- Define the presale order placement process: required customer information, payment method, confirmation timeline, and order acknowledgment procedure.
- Specify the 30-day refund guarantee: eligible reasons (fit/quality issues), processing timeline (10 business days), refund method and account, and non-refundable items if any.
- Quantify delivery timeline: ships within 2-3 weeks of order confirmation; estimated customer delivery 4-5 weeks; include shipping method and carrier options.
- Detail the device-fit responsibility disclaimer: customer must verify device compatibility using the published Product Fit Guide; list compatible laptop sizes (up to 17 inches), phone sizes (up to 6.5 inches), and internal dimensions (approx. 420 x 280 x 50 mm).
- Establish customer support escalation path: 48-hour response target for support inquiries, contact channels (email, phone, web form), escalation procedure for unresolved issues.
- Specify the presale cutoff date: Month 8 (2027-06-08); orders placed after this date are handled as ordinary post-cutoff orders with separate delivery timeline.
- Document post-cutoff order handling: clarify whether post-cutoff orders are available, pricing, and expected delivery timeline or waitlist status.
- Include hyperlink or reference to the Product Fit Guide document for device compatibility details.
- State VAT and OSS (One-Stop Shop) tax treatment for EU distance sales; clarify whether price shown is ex-VAT or inc-VAT.
- Address cancellation and modification rights: up to what point can a customer cancel, and what happens to deposits if they do.
- Define dispute resolution: complaint escalation path, timeframe for resolution attempt, and governing law (Estonia or buyer's country under EU consumer law).

**Risks of Poor Quality**:

- Unclear refund terms or overly restrictive policy triggers refund disputes and social-media complaints during the critical presale phase (Months 6-9 = 2027-04-08 to 2027-07-08), damaging reputation and reducing conversion rate by 15-25% (estimate).
- Vague delivery timeline creates customer expectation mismatch; if ships-within language is ambiguous, customers file disputes when delivery extends beyond stated window, consuming support time and generating refund requests that strain cash flow around the Month 9-12 (2027-07-08 to 2027-10-08) gate measurement.
- Missing device-fit disclaimer leaves the company liable for fit complaints and returns; if customers claim the enclosure doesn't fit their device and the terms do not clearly place fit-verification responsibility on the buyer, refund rate may spike to 15-30% (estimate), consuming presale deposits and delaying the cash-flow gate.
- Lack of support escalation process creates unresolved customer issues that linger; slow response (>5 days) to fit complaints or shipping inquiries increases churn, refund rate, and negative reviews that suppress presale conversion in later months.
- Presale cutoff date and post-cutoff order handling are ambiguous; if the terms do not clarify whether Month 8 (2027-06-08) cutoff means presales end or just the delivery window changes, customers placing orders in Month 9 (2027-07-08) may expect fast fulfillment, leading to breach-of-SLA claims during the cash-flow gate measurement period.
- Non-compliance with EU consumer-protection and distance-selling rules (e.g., missing statutory information on cooling-off rights, trader identification, or dispute resolution) triggers regulatory warning or fine (€2-10k estimate, not verified) and requires costly document revision.
- Inconsistency between presale terms and the Product Fit Guide or marketing materials creates legal exposure; customers cite marketing promises that conflict with terms disclaimers, leading to disputes and reputational damage.
- Terms do not address VAT or OSS treatment, leaving buyers uncertain about total cost and creating compliance risk if the company collects VAT on non-EU sales without OSS registration.

**Worst Case Scenario**: 
Presale terms are legally non-compliant, unclear on device fit, or overly restrictive on refunds. Result: (1) Regulatory challenge from EU consumer authorities during Months 6-9 (2027-04-08 to 2027-07-08) requiring emergency document revision and recompilation (€5-15k estimate, legal cost + fulfillment interruption); (2) Refund rate spikes to 25-35% (estimate) as customers cite unmet expectations, consuming €30-40k of presale deposits and reducing delivered-unit cash flow below the €25k gate threshold by €10-20k; (3) Social-media complaints amplify during a high-profile news cycle (e.g., solar-storm coverage), tanking presale conversion in Months 8-10 (2027-06-08 to 2027-08-08) and leaving presale target unmet; (4) Company fails the cash-flow gate at Month 12.5 (2027-10-23) due to refund-driven cash leakage and missed delivery deadlines, and the €350k follow-on is withheld. Consequence: venture is left with committed €160k production cost, €20k redesign reserve committed to failed lab re-testing, and no follow-on capital, forcing wind-down or external funding with severe dilution.


**Best Case Scenario**: 
Clear, legally compliant presale terms establish a credible customer contract and reduce friction during the critical presale phase (Months 1-8 = 2026-11-08 to 2027-06-08). (1) Fit disclaimer and link to the Product Fit Guide enable self-service customer verification, reducing fit-related refund claims to <5% (estimate) and preserving presale deposits. (2) 30-day refund guarantee and clear support escalation (48-hour response) build buyer confidence during the launch, enabling presale conversion of 50-60% (estimate) across buyer segments and target of €120k deposits by Month 6 (2027-04-08). (3) EU-compliant language and distance-selling disclosures (cooling-off rights, trader info, VAT clarity) avoid regulatory challenge and give presale customers legal certainty, reducing support escalations by 20-30% (estimate). (4) Clear presale cutoff date (Month 8 = 2027-06-08) and post-cutoff order handling manage customer expectations, so orders placed in Months 7-8 (2027-05-08 to 2027-06-08) are fulfilled on time before the cash-flow gate measurement window (Months 9-12 = 2027-07-08 to 2027-10-08), enabling positive cash flow and gate pass of €30k+. (5) Published terms serve as a reference for presale marketing and buyer onboarding, reducing disputes and creating a repeatable, scalable presale process for the post-gate period.


**Fallback Alternative Approaches**:

- Adapt a commercial e-commerce terms template (Shopify, WooCommerce, or Magento pre-built) and customize for the presale-specific language (cutoff date, device fit, build-to-order timeline), reducing creation time by 50% (estimate) and leveraging battle-tested legal language.
- Engage a contract attorney or legal template service (LawBite, Rocket Lawyer, or equivalent EU provider) to draft EU-compliant presale terms for €500-1,500 (estimate), avoiding in-house errors and ensuring statutory compliance with cooling-off rights and distance-selling rules.
- Commission a legal opinion on EU consumer-protection applicability (€2-5k estimate, already planned by Month 1 = 2026-11-08) and use it to define the presale terms scope, then have the attorney draft terms based on the opinion rather than starting from scratch.
- Publish a minimal presale SLA first (Month 1 = 2026-11-08): shipping promise + 30-day refund guarantee + support contact, then expand terms incrementally with legal review as presale campaigns launch, rather than delaying presale start for a complete document.
- Use a presale platform (Kickstarter, Indiegogo, or Backerkit) that supplies pre-drafted terms and handles refunds and customer communication, outsourcing terms compliance and fulfillment to the platform and reducing in-house legal and operations burden.
- Hire a part-time legal operations person (10-15 h/week, €200-300/week estimate) starting Month 1 (2026-11-08) to draft and manage presale terms, monitor compliance, and handle customer escalations; absorb cost inside the 75k marketing/operations budget.

## Create Document 8: Presale Campaign Strategy & Segment Tracking Framework

**ID**: 261be031-1218-4684-b95a-87a0370b2b25

**Description**: Three-segment presale strategy (Prepper Networks, Infrastructure Buyers, Privacy/Forensics) with distinct landing pages, messaging, and weekly deposit tracking. Includes segment-mix pivot triggers (if Prepper >70% by Month 3 = 2027-01-08, reallocate EUR 10-15k marketing budget to Infrastructure/Privacy). Tracks deposit count, value, AOV, refund rate by segment. Audience: presale manager, project manager, external advisor.

**Responsible Role Type**: Presale & Demand Validation Manager

**Primary Template**: Go-to-Market Strategy Template

**Secondary Template**: A/B Testing & Campaign Measurement Plan

**Steps to Create**:

- Define three buyer personas: Prepper (solar-storm/continuity), Infrastructure (emergency-response procurement), Privacy/Forensics (travel security/data protection).
- Create distinct landing pages for each segment with targeted messaging and value propositions.
- Set segment deposit targets: Prepper 40-50%, Infrastructure 30-40%, Privacy/Forensics 35-45% (by Month 6 = 2027-04-08).
- Establish weekly tracking dashboard: deposit count, total value, average order value, refund rate by segment.
- Define pivot trigger: if Prepper deposits exceed 70% by Month 3 (2027-01-08), reallocate EUR 10-15k marketing to Infrastructure and Privacy channels.
- Document fallback presale pricing (15-20% reduction estimate if conversion <40% by Month 3 = 2027-01-08).
- Negotiate 1-2 fast-track infrastructure pilot agreements by Month 3 (2027-01-08) (10-20 units at EUR 84/unit, delivery Month 5 = 2027-03-08).
- Set presale conversion target ≥40% and minimum average order value EUR 120 by Month 6 (2027-04-08).
- Publish weekly tracker shared with founder and external advisor.

**Approval Authorities**: Presale Manager, Project Manager

**Essential Information**:

- Define three distinct buyer personas with messaging, value propositions, and call-to-action for each: (1) Prepper Networks (solar-storm/continuity focus), (2) Infrastructure Buyers (emergency-response procurement, reference value), (3) Privacy/Forensics Communities (travel security, data protection).
- Design three separate landing pages or presale channels with segment-specific copy, pricing presentation, and lead-capture mechanisms. Map messaging to each segment's primary concern: disaster resilience, operational continuity, or privacy.
- Establish baseline deposit targets and conversion-rate goals by segment for Month 6 (2027-04-08): Prepper target 40–50% deposit rate (estimate), Infrastructure 30–40%, Privacy/Forensics 35–45%. Total target EUR 120k net deposits (proposed threshold).
- Create weekly tracking dashboard with metrics by segment: (1) deposit count and cumulative value, (2) average order value (AOV), (3) deposit-to-presale-inquiry conversion rate, (4) refund count and rate, (5) time-to-deposit (sales cycle). Share with founder and external advisor.
- Define and document segment-mix pivot triggers: if Prepper deposits exceed 70% of total by Month 3 (2027-01-08), reallocate EUR 10–15k from Prepper marketing budget to Infrastructure and Privacy channels to correct skew (proposed threshold).
- Define fallback pricing strategy (estimate): if cumulative presale conversion is below 40% by Month 3 (2027-01-08), model and document a 15–20% list-price reduction to EUR 126–127 per unit and evaluate impact on unit contribution margin (67 EUR baseline). Include decision rule for when to activate.
- Negotiate and document 1–2 fast-track infrastructure pilot agreements by Month 3 (2027-01-08): scope (10–20 units), price (EUR 84 per unit = cost plus 20%), delivery date (Month 5 = 2027-03-08), and reference rights. Track as a lead indicator for infrastructure segment conversion.
- Set and monitor presale conversion success criteria by Month 6 (2027-04-08): (1) minimum 40% of inquiry-to-deposit conversion rate (estimate), (2) minimum average order value EUR 120 (proposed threshold, about 80% of list price EUR 149), (3) overall presale deposits EUR 80–120k (proposed threshold). Document go/no-go decision rules.
- Document the hard-tooling release gate logic in the campaign brief: hard tooling releases only when (1) net presale deposits ≥ EUR 80k (proposed threshold) AND (2) accredited lab pre-test confirms design readiness (Month 5 = 2027-03-08 report). Link deposit milestones to tooling timeline so presale team understands the consequence of falling short.
- Track and report refund rate by segment weekly. Set refund-rate cap: if cumulative refunds exceed 15% (estimate) of total deposits by Month 8 (2027-06-08), trigger narrative or channel pivot to re-stabilize demand (proposed threshold). Document refund reasons (fit, delivery delay, changed mind) to inform redesign.
- Establish presale cutoff date (Month 8 = 2027-06-08) in the campaign materials and confirm it with buyers: presale deposits close on this date; new orders after that deliver post-gate. This ensures early-order fulfillment before the Month 12 (2027-10-08) cash-flow gate measurement.
- Document A/B testing plan for landing pages (if budget allows): test two prepper messaging variants (Carrington resilience vs. RF privacy), two infrastructure variants (compliance/continuity vs. incident response), and measure deposit velocity and AOV by variant. Recommend best performer by Month 2 (2026-12-08).
- Define escalation and decision authority: presale manager owns campaign execution and weekly tracker; project manager approves segment-mix pivots and pricing fallback; founder approves hard-tooling gate decision when EUR 80k deposit threshold is met.

**Risks of Poor Quality**:

- Undefined segment targets and success criteria: presale team lacks clarity on deposit goals, conversion benchmarks, and go/no-go decision rules, leading to uncoordinated messaging, missed deposit targets, and delayed hard-tooling release or unexpected pivot decisions.
- Absence of weekly tracking by segment: founder and advisor cannot identify underperforming segments in real time (Month 1–3 = 2026-11-08 to 2027-01-08), so the EUR 10–15k reallocation pivot at Month 3 (2027-01-08) is delayed or based on incomplete data, allowing prepper-dominated mix to persist and compress margins to unsustainable levels (EUR 10–20 per unit estimate).
- Vague pivot triggers and decision rules: if pivot condition (70% prepper threshold) is not precisely documented, presale manager interprets it inconsistently or defers the decision, allowing high-volume prepper sales to lock in before infrastructure and privacy campaigns gain traction, leaving insufficient diversity for the cash-flow gate.
- No presale cutoff date: if presale offer remains open through Month 10 (2027-08-08) or later without explicit closure, orders placed close to the cash-flow gate measurement window (Month 12 = 2027-10-08) deliver late, their revenue misses the gate, and cumulative delivered-unit cash flow falls short of EUR 25k (proposed threshold), blocking the EUR 350k tranche.
- Missing hard-tooling gate logic in campaign messaging: if presale materials do not explain that tooling is conditional on EUR 80k deposits and lab approval, presale buyers may believe production is guaranteed and expect delivery before gate measurement. Unmet expectations lead to complaints, refund requests, and reduced presale velocity.
- Undefined pilot strategy for infrastructure buyers: without a documented fast-track pilot agreement template (pricing EUR 84, scope 10–20 units, delivery Month 5 = 2027-03-08) and clear lead-qualification criteria, infrastructure team wastes time on unqualified prospects or misses early pilots that would generate Month 5–6 (2027-03-08 to 2027-04-08) reference revenue.
- Insufficient refund-rate monitoring: if refund reasons are not tracked and analyzed weekly by segment, the campaign team cannot identify whether fit issues, delivery delays, or changed demand are driving refunds. A 20–30% (estimate) refund spike goes undetected until cash flow is already consumed, risking gate failure.
- Weak or absent A/B testing plan: if presale landing-page variants are not tested, the campaign team may be running messaging that generates low conversion or AOV, wasting marketing spend and leaving deposit velocity weak by Month 3 (2027-01-08) when the pivot decision is due.
- No documented escalation path: if presale manager, project manager, and founder have unclear decision authority and communication cadence, hard-tooling gate decisions (EUR 80k threshold, Month 6 = 2027-04-08) are delayed, tooling supplier orders slip, and first-batch production is pushed into Months 7–8 (2027-05-08 to 2027-06-08), compressing fulfillment window before the gate.
- Inconsistent or missing deposit accounting: if the campaign does not clearly distinguish between gross presale inquiries, deposits received, refund requests, and net deposits (for the EUR 80k tooling gate), the presale team reports false progress to the founder, triggering premature tooling release before deposits are truly committed.

**Worst Case Scenario**: 
A presale campaign without clear segment targets, weekly tracking, and documented pivot triggers runs undirected for Months 1–4 (2026-11-08 to 2027-02-08), allowing Prepper-focused marketing to dominate deposit inflow. By Month 3 (2027-01-08), 75% of EUR 60k received deposits are from prepper networks (high-volume, low-margin EUR 10–20 per unit estimate). Presale manager fails to trigger the EUR 10–15k reallocation to Infrastructure and Privacy channels. Refund tracking is absent, so when a news cycle fades in Month 4 (2027-02-08), a 25% refund spike consumes EUR 15k of the EUR 60k, leaving net deposits at EUR 45k—below the EUR 80k (proposed threshold) tooling gate. No hard-tooling release occurs. Accredited lab report arrives Month 5 (2027-03-08) confirming the design, but production cannot start. Presale team extends the campaign into Months 6–8 (2027-04-08 to 2027-06-08), but momentum is lost. By Month 8 (2027-06-08), cumulative net deposits reach EUR 85k (just crossing the gate), but the 2-month delay in hard-tooling commitment (from Month 6 = 2027-04-08 to Month 8 = 2027-06-08 to 2027-06-08) compresses first-batch production and fulfillment into Months 8–10 (2027-06-08 to 2027-08-08). Orders placed in Months 6–7 (2027-04-08 to 2027-05-08) do not deliver until Month 11–12 (2027-09-08 to 2027-10-08), just before or after the cash-flow gate measurement cutoff (Month 12 = 2027-10-08). Only 600–800 units (estimate) are delivered and invoiced by end-of-quarter cutoff, generating EUR 40–54k contribution (600–800 × EUR 67). Less recurring opex EUR 20k = EUR 20–34k, which barely meets or misses the EUR 25k (proposed threshold) gate. Uncertainty on gate result delays sign-off into Month 13 (2027-11-08), leaving founder without the EUR 350k tranche decision. Year-2 inventory replenishment is blocked, marketing pauses, and the venture enters financial constraint despite having technically viable demand. The EUR 750k total (user constraint) capital is exhausted, with no follow-on growth or contingency, and the business winds down or seeks external funding with dilution.


**Best Case Scenario**: 
A presale campaign with clear segment definitions, weekly tracking dashboards, and documented pivot triggers runs tightly across Months 1–6 (2026-11-08 to 2027-04-08). Prepper, Infrastructure, and Privacy landing pages launch Month 1 (2026-11-08) with distinct messaging and A/B variants tested by Month 2 (2026-12-08). Weekly tracking by segment reveals balanced deposit inflow: 35% Prepper (EUR 42k estimate), 35% Infrastructure (EUR 42k estimate), 30% Privacy (EUR 36k estimate) = EUR 120k target by Month 6 (2027-04-08). Infrastructure team negotiates two fast-track pilots (20 units at EUR 84 each, delivery Month 5 = 2027-03-08) by Month 3 (2027-01-08), generating EUR 1.68k revenue and a proof-of-concept reference. Refund rate stays below 8% across all segments (strong delivery messaging and fit expectations). Lab pre-test review (Month 4–5 = 2027-02-08 to 2027-03-08) confirms design readiness; full report arrives Month 5 (2027-03-08) with target attenuation figures. By Month 6 (2027-04-08), hard-tooling gate is clearly met: EUR 120k net deposits (proposed threshold) + lab approval. Hard tooling commits immediately; first batch (800 units) enters production Month 6 (2027-04-08). Fulfillment ramps: 750 units delivered Months 6–9 (2027-04-08 to 2027-07-08) with 2–3 week lead times, generating EUR 112.5k revenue (750 × EUR 149). Year-1 delivered revenue reaches EUR 113k–115k (including pilot EUR 1.68k) by end of Q3 (Month 9 = 2027-07-08). Q4 (Months 9–12 = 2027-07-08 to 2027-10-08) closes with another 750 units delivered, generating EUR 112.5k, bringing Year-1 total to EUR 225k+. Q4 operating cash flow (750 units × EUR 67 contribution = EUR 50.25k, less opex EUR 20k = EUR 30.25k) exceeds the EUR 25k (proposed threshold) gate by EUR 5.25k. Gate sign-off by Month 12.5 (2027-10-23) is straightforward. EUR 350k follow-on is released, enabling inventory replenishment (200–300 unit buffer stock in EU warehouse), expanded marketing, and potential variant development (phone-only SKU). Year-2 outlook is clear: 3,000 units at EUR 67 contribution = EUR 201k, less EUR 80k opex = EUR 121k annual operating surplus (estimate). The venture achieves positive cash flow and demonstrates viable niche traction within the founder's capital constraints.


**Fallback Alternative Approaches**:

- If presale tracking by segment cannot be established within resources available (Month 1 = 2026-11-08), implement a simplified single-dashboard tracking approach: aggregate presale deposits by week and overall conversion rate (target ≥40% by Month 3 = 2027-01-08), deferring segment-level reporting until Month 2 (2026-12-08). Assign one part-time analyst (5–10 h/week, EUR 100–150/week) to manage the tracker; founder reviews weekly data and makes pivot decisions manually if thresholds are crossed.
- If A/B testing of landing pages is not feasible due to platform or timeline constraints, publish two sequential campaigns (Months 1–2 = 2026-11-08 to 2026-12-08: Prepper focus; Month 2–3 = 2026-12-08 to 2027-01-08: Infrastructure focus) and measure deposit inflow and AOV by period to identify which segment responds faster. Use winner messaging for Months 3–6 (2027-01-08 to 2027-04-08) concentration.
- If infrastructure pilot negotiation cannot close by Month 3 (2027-01-08), substitute with an open 'beta reference program': offer 20–30 units at cost + 10% (EUR 77 per unit, estimate) to infrastructure and privacy early adopters who agree to provide written feedback and act as references by Month 7 (2027-05-08). Formalize reference-rights terms in a simple one-page agreement to accelerate buy-in.
- If refund tracking becomes resource-intensive, implement a monthly (not weekly) refund-rate reporting, with a single go/no-go decision at Month 6 (2027-04-08): if cumulative refund rate exceeds 12% (estimate), pause presale marketing and conduct a customer-feedback sprint (5–10 interviews, 2–3 days) to diagnose and fix the primary complaints. Findings inform messaging or positioning pivot for Months 6–8 (2027-04-08 to 2027-06-08).
- If the presale cutoff date (Month 8 = 2027-06-08) cannot be enforced (e.g., presale platform does not support auto-closure), establish a hard 'gate closure' announcement at Month 7.5 (2027-05-23): emails to all active inquiries state 'Presale closes Month 8 (2027-06-08); orders after this date deliver post-gate and are not guaranteed by Month 12 (2027-10-08).' Revert to manual presale acceptance after Month 8 (2027-06-08) with explicit lead-time warnings.
- If the EUR 80k (proposed threshold) tooling gate is not cleanly met by Month 6 (2027-04-08)—deposits are EUR 70–80k with ambiguity around refund liability—convene founder + one advisor for a 30-minute decision call at Month 6.5 (2027-04-23). Frame decision: either (a) commit tooling on EUR 75k net and accept 10% downside risk (delivery delay or refund if presale falls through), or (b) extend presale and defer tooling to Month 7 (2027-05-08) with risk of missing early fulfillment. Document decision and rationale.
- If segment-mix pivot (reallocate EUR 10–15k from Prepper to Infrastructure) cannot happen at Month 3 (2027-01-08) due to already-committed ad spend, instead instruct all Prepper-channel owners to pause new ad spend and redirect budget to 'cold-outreach' to infrastructure and privacy prospects (email lists, procurement forums, trade shows). Redeploy human time rather than paid media, saving 2–3 weeks to refocus by Month 3.5 (2027-01-23).
- If the fast-track infrastructure pilot cannot be formally negotiated, identify one 'lead pilot' candidate by Month 2 (2026-12-08) and offer a confidential 'soft commitment' call: pilot 10–15 units at EUR 84 (cost + 20%) with a 45-day evaluation period and no formal contract until results are positive. Verbal commitment or a simple email agreement is sufficient to move forward with production allocation.
- If weekly tracking dashboard cannot be built due to tool unavailability (CRM, Google Sheets, etc.), track presale data in a simple CSV file updated by hand every Friday: deposit count, total value, top three countries/buyer types, refunds received, inquiries outstanding. Share as an email attachment to founder and advisor. Upgrade to a formal dashboard if presale volume exceeds 500 inquiries by Month 3 (2027-01-08).

## Create Document 9: RF Engineering Milestone Agreement & Co-Development IP Terms

**ID**: 6077813e-cb7c-4f85-8d80-6ce22e8fc337

**Description**: Signed consultant agreement with RF engineer (Dr. Tamm) specifying milestones (prototype design Month 2 = 2026-12-08 EUR 5k, in-house rig validation Month 3 = 2027-01-08 EUR 8k, lab coordination Month 4-5 = 2027-02-08 to 2027-03-08 EUR 7k, redesign support EUR 3-5k), total EUR 23-25k. Includes knowledge-transfer and IP terms: consultant retains design credit/publication rights; founder owns exclusive manufacturing/commercial rights. Includes fallback plan (part-time RF hire 0.5 FTE EUR 25k/year) if consultant unavailable post-Month 5 (2027-03-08). Signed by Month 0.5 (2026-10-23). Audience: RF engineer, founder, project manager.

**Responsible Role Type**: Founder & RF Engineer

**Primary Template**: Independent Contractor Statement of Work

**Secondary Template**: Intellectual Property Assignment Agreement

**Steps to Create**:

- Define milestone deliverables: (1) Prototype design documentation (Month 2 = 2026-12-08, EUR 5k), (2) In-house rig validation & attenuation report (Month 3 = 2027-01-08, EUR 8k), (3) Lab submission & pre-test review (Month 4-5 = 2027-02-08 to 2027-03-08, EUR 7k), (4) Design-revision support if needed (Month 5-6 = 2027-03-08 to 2027-04-08, EUR 3-5k contingent).
- Specify payment terms (EUR 5k upon design review sign-off, EUR 8k upon rig report, EUR 7k upon lab submission, EUR 3-5k upon revision completion).
- Document IP terms: consultant retains academic publication and credit rights; founder owns exclusive commercial and manufacturing rights.
- Include post-Month 5 (2027-03-08) retainer option: EUR 200-400/month (5 hrs/week estimate) for Q&A and warranty support during production ramp.
- Document exit plan: if consultant unavailable, part-time RF engineer (0.5 FTE, EUR 25k/year) hired to own design changes and warranty diagnostics.
- Include confidentiality and non-compete clauses (standard scope).
- Obtain signatures from consultant and founder by Month 0.5 (2026-10-23).

**Approval Authorities**: Founder, RF Engineer (Dr. Tamm)

**Essential Information**:

- Define and document the RF engineering milestone agreement with Dr. Tamm (or equivalent consultant), specifying exact deliverables at each stage: prototype design (Month 2 = 2026-12-08), in-house rig validation with two independent seam cycles (Month 3 = 2027-01-08), lab coordination and pre-test review (Month 4–5 = 2027-02-08 to 2027-03-08), and redesign support contingency (Month 5–6 = 2027-03-08 to 2027-04-08).
- Establish fixed payment terms aligned to deliverable sign-off: EUR 5k upon prototype design review completion, EUR 8k upon in-house rig validation report, EUR 7k upon accredited lab submission, EUR 3–5k (contingent) upon revision completion, totaling EUR 23–25k.
- Clarify intellectual property ownership and publication rights: consultant retains academic credit and publication rights; founder owns exclusive commercial and manufacturing rights. Specify any design-documentation ownership and secrecy obligations.
- Document post-Month 5 (2027-03-08) contingency options: retainer for ongoing Q&A and warranty support during production ramp (EUR 200–400/month, 5 hrs/week estimate), or exit plan triggering a part-time RF engineer hire (0.5 FTE, EUR 25k/year) if consultant is unavailable.
- Include standard protective clauses: confidentiality (scope and duration), non-compete restrictions (if any), liability cap and indemnification, and insurance requirements if applicable.
- Obtain signatures from both consultant and founder by Month 0.5 (2026-10-23), establishing enforceable commitment to the milestone schedule and payment terms.

**Risks of Poor Quality**:

- Ambiguous or missing milestone definitions allow consultant to deliver vague design documentation, incomplete in-house rig validation or uncoordinated lab submission, delaying the accredited lab report from the Month 5 (2027-03-08) target to Month 6–7 (2027-04-08 to 2027-05-08), compressing the presale window and eroding the redesign buffer.
- Unclear payment terms or missing sign-off criteria create payment disputes; consultant withholds deliverables until payment clarification, halting project flow and straining cash-flow tracking within the EUR 400k Year-1 cap.
- Unspecified IP and publication rights lead to disputes over design disclosure, patent filing or consultant publishing results before commercial launch, damaging competitive advantage and investor confidence.
- Missing post-Month 5 (2027-03-08) exit clause leaves founder without a backup if consultant becomes unavailable during critical production ramp (Months 6–9 = 2027-04-08 to 2027-07-08), forcing urgent hiring at higher cost and schedule risk.
- Lack of confidentiality and non-compete language exposes proprietary shielding design, gasket specifications, Tallinn fabricator relationships and cost data to competitor access or insider disclosure.
- Unsigned or informal agreement creates legal ambiguity if consultant disputes payment, IP ownership or deliverable quality, requiring costly arbitration or contract enforcement that consumes cash and founder attention during critical presale phase (Months 6–9 = 2027-04-08 to 2027-07-08).

**Worst Case Scenario**: Consultant delays prototype delivery by 4–6 weeks (Month 2 = 2026-12-08 → Month 3.5 = 2027-01-23) due to vague specifications, causing in-house rig validation to slip from Month 3 (2027-01-08) to Month 4 (2027-02-08), and accredited lab submission from Month 4 (2027-02-08) to Month 5–6 (2027-03-08 to 2027-04-08). Lab report then arrives in Month 6–7 (2027-04-08 to 2027-05-08), missing the Month 5 (2027-03-08) latest date. Hard tooling commitment slips from Month 6 (2027-04-08) to Month 7–8 (2027-05-08 to 2027-06-08), compressing the production and fulfillment window from 4 months to 2 months before the cash-flow gate measurement (Month 12 = 2027-10-08). Presale deliveries concentrate in Months 11–12 (2027-09-08 to 2027-10-08), leaving insufficient receipts to clear the EUR 25k quarterly threshold by Month 12.5 (2027-10-23) sign-off. The cash-flow gate fails due to late delivery, the EUR 350k follow-on is withheld, and the founder must wind down operations or find unplanned external funding with dilution to founder equity.

**Best Case Scenario**: Signed, crystal-clear milestone agreement with Dr. Tamm locks RF design capability and defines exact deliverables, payment triggers, and intellectual property ownership upfront. Prototype design arrives by Month 2 (2026-12-08) on schedule; in-house rig validation (two independent seam cycles) completes by Month 3 (2027-01-08) with documented attenuation across the full frequency band; accredited lab pre-test review is conducted Month 4 (2027-02-08), confirming test readiness; lab report arrives Month 5 (2027-03-08) with positive results. Design is confirmed and presale deposits have exceeded EUR 80k by Month 5.5 (2027-03-23), triggering hard tooling release Month 6 (2027-04-08) on schedule. First batch (800 units) enters production Month 6 (2027-04-08), with deliveries ramping Months 7–8 (2027-05-08 to 2027-06-08) and Months 9–12 (2027-07-08 to 2027-10-08). By Month 12 (2027-10-08), 750+ units are delivered and paid for, generating EUR 30+ k quarterly operating surplus, clearing the cash-flow gate by Month 12.5 (2027-10-23) sign-off. The EUR 350k follow-on is released on schedule, funding inventory, marketing ramp and design variants. Founder credibility with accredited lab and suppliers is established, and RF expertise is secured for warranty and design iteration through Month 12 (2027-10-08) onward.

**Fallback Alternative Approaches**:

- If Dr. Tamm or the identified consultant is unavailable or unresponsive to agreement negotiation by Month 0.5 (2026-10-23), immediately engage a second independent EMC consultancy (Germany or Netherlands) with the same statement-of-work template. Lock cost and timeline with the backup by Month 1 (2026-11-08); if both consultancies decline or delay response, escalate to hiring a part-time RF engineer (0.5 FTE, EUR 25k/year) by Month 1.5 (2026-11-23) to own the design, moving that cost within the EUR 400k Year-1 cap by reducing marketing spend EUR 10–15k.
- If the consultancy or university partnership lacks capacity to deliver the in-house rig validation by Month 3 (2027-01-08), engage a third-party test laboratory (not necessarily accredited) to conduct rapid shielding measurements on prototype samples using a simplified test protocol (e.g., field-strength measurements in an anechoic chamber or open-field range, non-certified but documented). Publish these results as 'internal validation data' alongside the accredited lab report, reducing reliance on a single measurement source and accelerating feedback to design iteration by 2–3 weeks.
- If accredited lab cost estimates exceed EUR 15k budget by >20% (estimate: EUR 18k+), request a phased test plan splitting the full frequency band across two smaller runs (e.g., 50–500 MHz in Month 4 = 2027-02-08, 0.5–3 GHz in Month 5 = 2027-03-08) at 40–50% cost each, or negotiate a design-consultation review (EUR 2–3k) before sample submission to reduce re-test risk. Publish partial reports and iterate design before the second run.
- If the university lab partnership fails to materialize (delays or declined collaboration by Month 1.5 = 2026-11-23), hire a part-time RF technician or engineer at a local Tallinn technical college or fabrication shop to set up and run the in-house rig validation in-house, using documented open-source or DIY measurement protocols (e.g., RF shielding test boxes, function generators, spectrum analyzers rented or borrowed). Pair with the EMC consultancy for methodology review, reducing fixed university dependency.
- If a major design change is required after the Month 5 (2027-03-08) lab report (e.g., seam redesign for >5 dB improvement in 100 MHz band), request expedited re-test from the accredited lab (2–3 week turnaround, EUR 10–12k estimate premium) or run the re-test with a secondary lab in parallel to the primary lab, splitting the cost and timeline risk. Increase the redesign reserve from EUR 20k to EUR 30k by cutting Year-1 marketing spend EUR 10k if necessary.

## Create Document 10: Initial Baseline Assessment: Faraday Enclosure Market Demand & Regulatory Landscape

**ID**: 084ee3b9-d403-4d4d-b7e4-88381a8a90d9

**Description**: Baseline assessment of core problem: demand for consumer-grade Faraday enclosures is niche and unvalidated; EU regulatory applicability (EMC Directive, General Product Safety Directive, CE marking) is unverified; claim-substantiation exposure under consumer law is high. Assessment documents current market size (estimate: thousands of units/year across all vendors, primarily US-based), competitive landscape (Mission Darkness, Silent Pocket precedents), and regulatory risk (if EMC Directive applies, CE marking may be required, adding EUR 10-30k and 8-12 weeks cost/schedule). Deliverables: market-size estimate, competitor benchmarks, regulatory clarification by Month 1 (2026-11-08). Audience: founder, external advisor.

**Responsible Role Type**: Product Manager & Legal Counsel

**Primary Template**: Market Assessment & Regulatory Landscape Report

**Secondary Template**: Competitive Analysis Template

**Steps to Create**:

- Research global Faraday enclosure market: identify 5-10 competitors (US, EU, Asia), pricing (USD/EUR 80-300 range estimate), volumes (not public, inferred from reviews and sales signals), and target segments.
- Benchmark competitors: Mission Darkness (laser-cut metal, published test data, forensics positioning), Silent Pocket (fabric pouches, privacy/travel positioning), others.
- Assess EU regulatory applicability: contact 2-3 EU notified bodies or EMC consultants to clarify whether enclosures fall under EMC Directive, General Product Safety Directive, or are exempt; confirm CE marking requirement; identify applicable harmonized standards.
- Identify gaps in competitor regulatory documentation (most have no published compliance strategy; opportunity for Carrington Event Prep differentiation via transparency).
- Estimate Year-1 addressable market in EU preppers + infrastructure + privacy segments (estimate: 2,000-5,000 units/year across all segments, based on search volume and forum activity).
- Clarify consumer-protection liability landscape: interview 2-3 legal counsels on warranty and claim-substantiation exposure if Faraday protection claims are exceeded in a real event.
- Publish assessment by Month 1 (2026-11-08); share with founder and external advisor to inform presale strategy and compliance posture.

**Approval Authorities**: Product Manager, Legal Counsel

**Essential Information**:

- Quantify the current EU market size for consumer Faraday enclosures: units sold annually by segment (preppers, infrastructure, privacy/forensics), average selling price by competitor, and geographic concentration.
- Identify 5–10 active competitors (US, EU, Asia) with published products, pricing (EUR 80–300 range estimate), claimed attenuation figures, target segments, and sales/revenue signals (reviews, social-media engagement, forum mentions).
- Clarify regulatory applicability in the EU: determine whether the enclosure falls under the EMC Directive, General Product Safety Directive, or is exempt; confirm whether CE marking or notified-body assessment is required; identify the applicable harmonized standard (IEEE 299.1, MIL-STD-285, or equivalent).
- Estimate the addressable market within Year-1 reach: segment breakdown (prepper networks, critical-infrastructure operators, privacy/digital-forensics buyers) with deposit velocity assumptions (40–50%, 30–40%, 35–45% conversion estimates), order-value distribution, and sales-cycle length by segment.
- Document competitor compliance and marketing posture: assess published lab reports, warranty/liability disclaimers, claim-substantiation evidence, and whether competitors face regulatory or consumer complaints.
- Clarify consumer-protection and liability landscape: define what claim-substantiation burden applies under EU law if Faraday-enclosure performance claims exceed measured data, and quantify reputational/legal risk if the product underperforms in a real EMI event.
- Benchmark supply-chain and manufacturing precedent: identify existing Tallinn precision-metal fabricators serving similar niches, their typical lead times for soft tooling and hard tooling, and cost structure (per-unit, batch, tooling fees).

**Risks of Poor Quality**:

- Overstated market-size estimate leads to oversized presale targets and hard-tooling commitments, resulting in excess inventory, working-capital strain, and sunk tooling cost if demand proves lower than forecast.
- Missed or mischaracterized regulatory requirement (e.g., EMC Directive applies but assessment concludes exempt) leads to marketing or product launch without required CE marking or notified-body approval; regulatory challenge, mandatory recall, or fines incurred post-launch consume unexpected cash and delay revenue.
- Underestimated competitor threat or market saturation (e.g., Silent Pocket or Mission Darkness expands EU presence during Year-1) erodes presale conversion and margins before the company reaches profitability; reference-customer advantage is lost.
- Inaccurate segment conversion or sales-cycle timing (e.g., infrastructure pilots assumed 8–12 weeks but actually 16–24 weeks) causes presale deposits and delivered-unit revenue to miss the cash-flow gate window, blocking the EUR 350k tranche release.
- Vague claim-substantiation exposure assessment (e.g., no legal clarity on warranty liability) allows marketing to overstate enclosure capability; customer complaints or litigation post-launch create reputational and financial damage that insurance does not cover.
- Missing supply-chain and cost precedent (e.g., soft tooling actually costs EUR 40k, not 20k estimate) breaks the Year-1 budget assumption and forces cuts to design validation, accredited testing, or marketing, weakening the foundation for both the design and presales.

**Worst Case Scenario**: Regulatory assessment concludes the EMC Directive applies, requiring CE marking and notified-body assessment (EUR 10–30k, 8–12 weeks not budgeted), discovered only at Month 4 (2027-02-08) when accredited lab submission is imminent. Simultaneously, competitor benchmarking reveals Silent Pocket or a new entrant has captured 50% of the addressable prepper market or undercut price by 30%, and market-size estimate is revealed to be 3x too high. Combined, presale deposits stay at EUR 40–60k (below the EUR 80k gate), hard tooling is not released, and the company faces a choice: pivot without tooling (uncompetitive), absorb the compliance cost and delay launch (tranche dependent), or wind down. The founder's EUR 400k is largely spent on non-productive design and testing, and the EUR 350k follow-on is withheld. Project halts by Month 9–10 (2027-07-08 to 2027-08-08).

**Best Case Scenario**: Assessment clarifies that no CE marking is required (enclosure exempt from EMC Directive under General Product Safety Directive only), unlocking straightforward marketing without regulatory friction. Competitor analysis shows fragmented, undifferentiated market (no dominant player in EU), and estimated addressable market of 4,000–5,000 units annually (prepper: 2,500, infrastructure: 1,000, privacy: 500–1,000 estimate). Presale testing shows 60% conversion rate and EUR 140–160 average order value (above EUR 149 list), generating EUR 130k deposits by Month 5 (2027-03-08). Design validation and accredited lab report confirm attenuation targets; hard tooling is released on schedule. Year-1 delivers 1,500 units at EUR 67 contribution margin, generating EUR 100k gross contribution and EUR 30–50k operating cash surplus (above the EUR 25k gate). The EUR 350k follow-on is released, enabling EU buffer-stock warehousing, a phone-only SKU variant, and scaled marketing. Reference customers from infrastructure pilots accelerate Year-2 procurement.

**Fallback Alternative Approaches**:

- If regulatory assessment is inconclusive or requires notified-body engagement beyond the EUR 2–5k estimate, defer hard conclusions to Month 1.5 (2026-11-23) and engage a specialized EMC compliance consultant (EUR 3–5k additional) with a rapid statement of notified-body requirements; do not proceed to hard tooling until clarity is confirmed.
- If competitor benchmarking reveals a dominant player or price-undercut threat, pivot presale messaging to a defensible sub-segment (e.g., 'forensics-grade' with published validation or 'privacy-first' with transparency; see Threat Narrative and Claim Scope decision) rather than broad 'Carrington prep'; reallocate marketing spend to the differentiated segment and measure segment-specific conversion.
- If market-size estimate is revised downward (e.g., to <2,000 units annually), tighten the presale target to EUR 60–80k instead of EUR 120k, and commit a smaller first batch (500 units, EUR 75–80k tooling+production) to reduce sunk-cost risk; this delays infrastructure volume but preserves cash for design and compliance.
- If presale conversion or average order value falls below forecast by Month 4 (2027-02-08), pause hard-tooling commitment and run a 2-week rapid survey of non-converters (refund-request reasons, price sensitivity, delivery concerns) to identify a quick messaging or offering pivot (e.g., financing, bundle with a service, or entry-level smaller SKU).
- If supply-chain cost baseline (soft tooling, unit cost) exceeds estimate by >15%, negotiate a cost-sharing arrangement with the accredited lab (e.g., lab provides in-house measurement access in exchange for a reduced milestone fee) or defer the internal rig iteration and rely on the lab's design-readiness review to reduce upfront spending; accept a slightly longer design cycle (Month 6 = 2027-04-08 report instead of Month 5 = 2027-03-08).
- Commission a second market-assessment from an independent EMC or product-strategy consultant (EUR 5–10k) to validate or challenge the baseline-assessment conclusions; use the independent view to resolve disagreement with advisors or stress-test assumptions before hard-tooling release.

## Create Document 11: Presale Segment A/B Testing & Demand Validation Experiment Plan

**ID**: 91ec900b-6160-4f83-b9b5-42d12de74248

**Description**: Planned experiment for Months 0-3 (2026-10-08 to 2027-01-08) testing three buyer-segment narratives (Carrington preparedness, forensics/compliance, privacy/travel security) via separate landing pages. Specifies: sample size, conversion metrics (inquiry-to-deposit ratio), average order value, segment-mix outcome, and decision rule for pivot. Audience: presale manager, project manager, external advisor.

**Responsible Role Type**: Presale Manager

**Primary Template**: A/B Testing & Experiment Design Template

**Secondary Template**: Customer Research Plan

**Steps to Create**:

- Design three landing pages, each targeting one buyer segment with distinct value proposition (Carrington + continuity, forensics/compliance/evidence, privacy/data-protection + travel security).
- Set up tracking: unique URL for each segment, pixel-based conversion tracking, email capture.
- Run campaigns in parallel for 8 weeks (Months 1-2 = 2026-11-08 to 2026-12-08); measure weekly.
- Key metrics: unique visitors per segment, inquiry-to-deposit conversion rate, average deposit amount (AOV), customer feedback/objections.
- Decision threshold (Month 3 = 2027-01-08): identify segment with highest deposit velocity and AOV ≥ EUR 120 (target). Allocate 60% of marketing budget to winning segment.
- Document findings and pivot decision in writing; adjust presale messaging for Months 3-8 (2027-01-08 to 2027-06-08) based on winner.
- If no clear winner (AOV <EUR 120 across all segments), trigger pricing pivot (reduce list price 15-20%) or extend presale test.

**Approval Authorities**: Presale Manager, Project Manager

**Essential Information**:

- Design three distinct landing pages, each targeting one buyer segment with tailored value propositions: (1) Carrington Event Prep + continuity of operations, (2) forensics/compliance/evidence preservation, (3) privacy/data protection + travel security. Each must include segment-specific copy, messaging, and imagery.
- Set up conversion tracking infrastructure: unique URL per segment, pixel-based analytics, email capture mechanism. Measure weekly visitor volume, inquiry-to-deposit conversion rate (%), average deposit amount (AOV), and customer feedback/objections for each segment during Months 1–2 (2026-11-08 to 2026-12-08).
- Define sample-size target and minimum viable conversion rate per segment (estimate: 40–50% inquiry-to-deposit ratio). Calculate required visitor traffic to achieve EUR 80k deposit threshold across all segments by Month 6 (2027-04-08).
- Establish decision rule for Month 3 (2027-01-08) pivot: identify winning segment (highest deposit velocity + AOV ≥ EUR 120). Reallocate 60% of marketing budget to winning segment; reallocate 10–15k from underperforming segments.
- If no clear winner (AOV < EUR 120 across all segments) or prepper segment exceeds 70% of total deposits: trigger pricing pivot (reduce list price 15–20%, estimate) or extend presale test with messaging refresh.
- Document findings in a written experiment report (Month 3 = 2027-01-08): deposit counts by segment, AOV by segment, conversion-rate ranking, customer objections, and pivot recommendation for Months 3–8 (2027-01-08 to 2027-06-08) marketing allocation.
- Define and track refund rate by segment weekly; if cumulative refunds exceed 15% of segment deposits by Month 8 (2027-06-08), isolate the cause (fit, delivery, messaging mismatch) and trigger segment-specific response.

**Risks of Poor Quality**:

- Ambiguous conversion metrics or missing tracking infrastructure result in weak signals at Month 3 (2027-01-08), delaying the pivot decision. Without clear weekly data, the team cannot distinguish between slow presale velocity and ineffective messaging, risking continued spend on an underperforming segment.
- Poorly designed landing pages (weak value proposition, unclear pricing, low trust signals) reduce conversion rates across all segments, resulting in deposit volume falling short of the EUR 80k tooling-gate threshold by Month 6 (2027-04-08). This delays or blocks hard-tooling release, compressing production and fulfillment before the cash-flow gate (Month 12 = 2027-10-08).
- Missing or inconsistent customer feedback collection prevents identification of segment-specific objections (price, fit, delivery timeline, threat narrative mismatch). This leaves the presale team unable to iterate messaging or address pain points, increasing refund risk and depressing conversion.
- Failure to segment-tag leads and deposits during capture makes post-hoc analysis unreliable. At Month 3 (2027-01-08), the team cannot accurately attribute AOV, refund rate, or objections to segments, forcing a costly data-recovery effort or leading to a misdirected pivot.
- Undefined decision thresholds (e.g., AOV EUR 120 target, 70% prepper concentration trigger) create governance ambiguity at Month 3 (2027-01-08). The presale manager and project manager may disagree on whether to pivot, delaying the go/no-go decision by weeks and squeezing the time available to execute a corrected strategy.
- Lack of a pre-committed budget-reallocation plan (the 60% to winner, 10–15k shift from losers) allows scope creep: the project team may over-invest in underperforming segments, wasting scarce Year-1 marketing budget (EUR 75k total, estimate) before the pivot is decided and executed.

**Worst Case Scenario**: An A/B test that produces ambiguous or misinterpreted results at Month 3 (2027-01-08) leaves the presale strategy undecided, and the team continues spending on a misaligned segment mix through Month 6 (2027-04-08). By Month 6 (2027-04-08), presale deposits fall 20–30% short of the EUR 80k tooling-gate threshold (reaching ~EUR 55–65k, estimate), preventing hard-tooling release. The production batch is deferred into Month 8 (2027-06-08) at the earliest, compressing fulfillment to only 2–3 months before the Year-1 cash-flow gate measurement (Month 12 = 2027-10-08). Late-arriving orders miss the delivery window, deposit refunds spike by 15–25% (estimate) as disappointed customers cancel, and the measured Year-1 cash flow falls EUR 10–20k short of the EUR 25k gate threshold, blocking the EUR 350k follow-on and forcing wind-down or unplanned restructuring.

**Best Case Scenario**: A well-executed experiment identifies a clear winning segment by Month 3 (2027-01-08): either infrastructure buyers (highest AOV ~EUR 250–300) or privacy/forensics segment (mid-range AOV ~EUR 100–150), accounting for 50–60% of deposits. The presale team reallocates 60% of remaining Year-1 marketing budget (EUR 45k, estimate) to the winning segment, while re-testing messaging in underperforming segments or pausing them entirely. By Month 6 (2027-04-08), cumulative deposits reach EUR 120k (proposed threshold), hard tooling is released, and Batch 1 (800 units, estimate) enters production. This enables fulfillment to begin by Month 7 (2027-05-08), allowing 1,500 units to be delivered and paid for by the Month 12 (2027-10-08) cash-flow gate measurement (Month 12 = 2027-10-08), achieving the EUR 25k surplus and unlocking the EUR 350k follow-on. Winning-segment messaging becomes the template for Year-2 marketing and scalable acquisition.

**Fallback Alternative Approaches**:

- If tracking infrastructure cannot be set up in time for a Month 1 (2026-11-08) launch, use a simplified manual-collection approach: unique email alias and intake form per segment (e.g. prep@, forensics@, privacy@), with daily download and weekly reporting of deposit counts and customer notes. Sacrifice real-time weekly dashboarding, but preserve segment attribution by Month 3 (2027-01-08).
- If three concurrent landing pages create operational complexity (copywriting, design, traffic routing), reduce to two tests initially (prepper/Carrington vs. privacy/forensics), and defer infrastructure segment to Month 2 (2026-12-08) once the first two show traction. This simplifies Month 1 (2026-11-08) launch and allows messaging learnings from the first test to inform the infrastructure page.
- If conversion rates stay below 40% (estimate) across all segments by Month 2.5 (2026-12-23), pause A/B testing and commission a rapid customer-research sprint: conduct 10–15 interviews or surveys with target buyers across segments to uncover messaging, pricing, or product-fit objections. Results feed into a messaging refresh and re-launch by Month 3.5 (2027-01-23), extending the test window to Month 5 (2027-03-08) for adequate sample size.
- If a single segment (e.g. prepper) dominates 80%+ of deposits by Month 2 (2026-12-08), pivot the test: keep the dominant segment as-is, and reallocate 50% of its budget to aggressively testing price-sensitive variants (e.g. 'basic' at EUR 99 vs. 'premium' at EUR 149) and complementary RF-isolation use cases (travel security, workplace privacy) to diversify revenue mix and reduce margin risk.
- If the Month 3 (2027-01-08) pivot decision is ambiguous (no clear winner, AOV between EUR 100–130, both prepper and infrastructure segments healthy), use a tiebreaker: prioritize the segment with the highest average order value and longest sales cycle (infrastructure, typically 8–12 weeks), as infrastructure closure in Months 5–6 (2027-03-08 to 2027-04-08) can meet the Month 6 (2027-04-08) tooling gate; prepper deposits may arrive faster but close after the gate decision.

## Create Document 12: Accredited Lab Pre-Engagement Consultation Summary & Lab Selection Decision

**ID**: 3c55c9b1-3947-4229-811b-233d2b58530e

**Description**: Summary of pre-engagement consultations with 2-3 accredited EMC laboratories (conducted Month 0.5 = 2026-10-23). Documents: standard recommendation (IEEE 299.1 or alternative applicability for small enclosures), frequency range (e.g., 100 kHz - 1 GHz), cost (EUR 15k cap confirmed or overrun risk identified), timeline (report delivery Month 5 = 2027-03-08 or later), design-readiness review scope (EUR 2-3k, 2-week turnaround). Concludes with lab selection and statement of work signing date. Audience: RF engineer, project manager, financial officer.

**Responsible Role Type**: RF Engineer

**Primary Template**: Laboratory Selection & RFQ Summary

**Secondary Template**: Supplier Comparison Matrix

**Steps to Create**:

- Contact 2-3 candidate labs (Germany, Sweden, Netherlands, Estonia) by Month 0.5 (2026-10-23) with request for pre-engagement consultation (standard, cost, timeline, design-readiness review).
- Compile consultation notes: lab name, standard(s) recommended (IEEE 299.1 or alternative applicability to small enclosures), frequency range (confirm 100 kHz to 1 GHz coverage), cost quote (EUR X for full testing, EUR Y for re-test if needed), timeline commitment (report delivery date), design-readiness review (cost and turnaround), re-test provision.
- Create comparison matrix: side-by-side evaluation of 2-3 labs on cost, timeline, standard applicability, re-test flexibility, design-review availability.
- Identify preferred lab based on: (1) cost ≤ EUR 15k cap, (2) timeline commitment for Month 5 (2027-03-08) report delivery, (3) design-readiness review availability Month 4 (2027-02-08), (4) re-test provision within original cost cap.
- Document lab selection rationale and obtain preliminary written quote by Month 1 (2026-11-08).
- Sign statement of work with chosen lab by Month 1.5 (2026-11-23) specifying fixed cost, delivery date, re-test terms, penalty for slip.

**Approval Authorities**: RF Engineer, Project Manager

**Essential Information**:

- Conduct pre-engagement consultations with 2–3 accredited EMC laboratories by Month 0.5 (2026-10-23) and document: (1) Applicable standard recommendation (IEEE 299.1 or alternative) for small Faraday enclosures, including justification for applicability; (2) Frequency range coverage (confirm 100 kHz to 1 GHz minimum); (3) Total test cost (fixed quote, confirm EUR 15k cap or flag overrun risk ≥ EUR 10k); (4) Re-test cost and terms if initial results fall short; (5) Committed report delivery date (confirm Month 5 = 2027-03-08 or flag delay risk); (6) Design-readiness review scope, cost (EUR 2–3k estimate), and turnaround time (2-week target); (7) Penalty clauses or SoW provisions for timeline slip.
- Create a side-by-side comparison matrix evaluating candidate labs on: (A) cost predictability and fixed-price commitment; (B) timeline alignment with Month 5 (2027-03-08) report delivery deadline; (C) design-readiness review availability in Month 4 (2027-02-08); (D) willingness to engage in pre-submission design consultation; (E) re-test flexibility and cost containment; (F) accreditation body and standard compliance; (G) geographic location and sample-shipping logistics.
- Identify and document the preferred lab selection based on: (1) Cost ≤ EUR 15k cap for full testing; (2) Committed report delivery by Month 5 (2027-03-08) with penalty for slip; (3) Design-readiness review (EUR 2–3k) available by Month 4 (2027-02-08); (4) Re-test provision within original cost cap or clearly priced; (5) Clear pre-engagement consultation output documenting standard recommendation and frequency-range confirmation.
- Obtain preliminary written cost quote and scope statement from preferred lab by Month 1 (2026-11-08); lock statement of work (SoW) with fixed cost, delivery date, design-review terms, and re-test provision by Month 1.5 (2026-11-23).
- Establish decision gate if cost exceeds EUR 15k cap or delivery date cannot be committed by Month 5 (2027-03-08): document the variance (e.g., +EUR 10k, +2-week delay), quantify impact on redesign reserve and presale window, and present options (e.g., absorb 5k within redesign reserve, defer to secondary lab, or reduce production batch budget).
- Document contingency: if preferred lab confirms higher-cost standard (e.g. MIL-STD-285) or longer timeline, identify secondary lab selection and cost/timeline trade-off to founder and project manager by Month 1 (2026-11-08).

**Risks of Poor Quality**:

- Undefined or deferred lab selection creates timeline ambiguity: if the document does not confirm a fixed report delivery date (Month 5 = 2027-03-08) or lock in cost (EUR 15k cap), the accredited lab work slips, pushing the design-readiness decision gate into Month 6–7 (2027-04-08 to 2027-05-08). This compresses hard-tooling release, first production batch, and presale fulfilment window from 3 months to 1–2 months before the cash-flow gate measurement (Month 12 = 2027-10-08), increasing risk of delivery failures and refund exposure by 20–30% (estimate).
- Incomplete lab cost analysis leaves EUR 10–20k (estimate) overrun risk unfunded: if the document does not confirm the EUR 15k cap or flag cost variance, a higher-cost standard (MIL-STD-285 vs. IEEE 299.1, not verified), additional frequency-range coverage, or re-test provision can exceed budget by 10–20k (estimate). This consumes the EUR 20k redesign reserve entirely, leaving zero contingency for design rework and eliminating the buffer against the Year-1 EUR 400k cap.
- Missing design-readiness review scope or skipped pre-engagement consultation prevents the team from understanding which shielding attenuation levels the lab expects, which frequency bands are critical, and whether the prototype design is test-ready before sample submission. Result: first lab submission returns unexpected results (attenuation below claims in key frequency bands), forcing redesign or re-test (EUR 8–15k estimate), missing the Month 5 (2027-03-08) report date and consuming time and budget needed for presale fulfilment.
- Ambiguous re-test terms (cost, timeline, conditions) create cash-flow risk: if the document does not specify whether a failed first lab run is covered by the EUR 15k budget or costs additional EUR 8–15k (estimate), and whether re-test timeline adds 4–8 weeks (estimate), the team cannot forecast cash burn or gate-measurement timing. A failed run after tooling commitment (Month 6 = 2027-04-08) then forces either unbudgeted spending or acceptance of a failed gate due to missed delivery dates.
- Lack of secondary lab fallback: if the document does not identify a backup lab and contingency cost, a primary lab capacity issue, standard-interpretation disagreement, or timeline slip (cost +20%, timeline +8 weeks, not verified) leaves the team with no alternative in Month 1–2 (2026-11-08 to 2026-12-08), forcing a cascading delay or tranche-dependent re-planning.

**Worst Case Scenario**: The document is deferred or omitted entirely, or pre-engagement consultations are not conducted until Month 1–2 (2026-11-08 to 2026-12-08). As a result, the team does not lock in lab cost (EUR 15k cap), standard (IEEE 299.1 or equivalent), or report delivery date (Month 5 = 2027-03-08) until sample submission (Month 4 = 2027-02-08). A lab then recommends MIL-STD-285 (higher cost and longer duration, not verified), adding EUR 15–25k and 6–8 weeks (estimate). The first lab run fails due to seam leakage or gasket quality (estimated 20–30% failure rate in hardware iteration, not verified), requiring redesign and re-test (EUR 12–20k estimate). The accredited lab report arrives in Month 7–8 (2027-05-08 to 2027-06-08), 2–3 months late. Hard tooling release is delayed from Month 6 (2027-04-08) to Month 8 (2027-06-08), compressing the presale fulfilment window to 2 months before the cash-flow gate measurement (Month 12 = 2027-10-08). Early presale orders (deposited in Months 1–3 = 2026-11-08 to 2027-01-08) deliver late, triggering refund requests (estimated 15–25% refund rate, not verified) that consume EUR 15–30k (estimate) of deposited cash. Delivered-unit cash flow falls from the EUR 50k+ forecast to EUR 20–25k, just meeting or missing the EUR 25k gate threshold (proposed threshold). The EUR 350k follow-on decision is borderline or negative, forcing the founder to either extend the runway 90 days (governance ambiguity) or receive a withheld tranche, leaving Year-2 underfunded and halting inventory replenishment and marketing.

**Best Case Scenario**: The document is completed by Month 0.5 (2026-10-23) with pre-engagement consultations from 2–3 labs confirming: (1) IEEE 299.1 or equivalent is the applicable standard for small enclosures, with clear applicability to the 420 x 280 x 50 mm design; (2) Frequency range 100 kHz to 1 GHz is supported at no cost premium; (3) Fixed test cost EUR 14–15k, within cap; (4) Report delivery committed to Month 5 (2027-03-08) with contractual penalty for slip; (5) Design-readiness review (EUR 2–3k) scheduled for Month 4 (2027-02-08), with feedback that the prototype is test-ready and expected attenuation is in the EUR 25–40 dB range (estimate). A statement of work is signed by Month 1.5 (2026-11-23), locking cost and timeline. The team submits samples in Month 4 (2027-02-08), receives the design-readiness review (confirms no major rework needed), and receives a favourable lab report by Month 5 (2027-03-08) showing attenuation > EUR 30 dB across the claimed band. Hard tooling is released by Month 6 (2027-04-08) as planned. The 1,500 units are manufactured and 750 units (Months 7–8 = 2027-05-08 to 2027-06-08) plus 750 units (Months 9–10 = 2027-07-08 to 2027-08-08) are delivered on schedule, with < 5% (estimate) fit-related returns. Delivered-unit cash flow reaches EUR 50–60k by Month 12 (2027-10-08), comfortably meeting the EUR 25k gate (proposed threshold) and enabling the EUR 350k follow-on to be released by Month 12.5 (2027-10-23) without governance ambiguity. The documented, transparent lab validation also serves as a credibility anchor for critical-infrastructure pilots and regulatory clarity, reducing claim-substantiation risk.

**Fallback Alternative Approaches**:

- If the preferred lab cannot commit to the EUR 15k cost or Month 5 (2027-03-08) delivery date by Month 1 (2026-11-08), immediately activate the secondary lab (identified in the pre-engagement consultation in Month 0.5 = 2026-10-23) and lock its SoW by Month 1.5 (2026-11-23). Accept a cost increase up to EUR 18k (absorb 3k within redesign reserve) if necessary to preserve the Month 5 (2027-03-08) report date, as timeline slip poses higher risk than modest cost overrun.
- If the lab recommends a costlier standard (e.g. MIL-STD-285, +EUR 10–20k estimate) or longer duration (+4–8 weeks estimate) than IEEE 299.1, accept the higher cost for one layer (e.g. testing methodology) but negotiate to keep the frequency-range scope and attenuation threshold within the EUR 15k budget. For example, test 80–20% of the claimed frequency band (100 kHz–500 MHz vs. 1 GHz) to reduce cost without major claim impact. Document the trade-off (claim scope narrowed) and present to the founder with the cost/timing impact by Month 1 (2026-11-08).
- If the preferred lab's design-readiness review is unavailable or costly (> EUR 3k estimate), substitute with a detailed technical pre-submission call (no charge) and ask the lab to confirm in writing whether the prototype design will pass: e.g., 'Lab confirms design is test-ready for IEEE 299.1 testing. Expected attenuation range: EUR 25–40 dB. No major redesign anticipated.' This preserves design feedback and timeline confidence at zero cost.
- If re-test terms are vague or re-test cost is not contained within the EUR 15k budget, negotiate and document a fixed re-test price (e.g. EUR 8k for one re-test, EUR 12k for two) and a condition: re-test cost is charged only if first-run attenuation falls short of a defined threshold (e.g. EUR 20 dB at key frequencies, not verified). Ensure the SoW specifies that one re-test is included in the EUR 15k cost or cost-capped at EUR 8k, so the redesign reserve (EUR 20k) covers the rework.
- If the accredited lab process is delayed (report pushed from Month 5 = 2027-03-08 to Month 6–7 = 2027-04-08 to 2027-05-08) due to factors outside the team's control (e.g. lab backlog), preemptively conduct a second, parallel in-house rig validation cycle (two independent seam-test cycles, no cost beyond the EUR 40k in-house rig budget) by Month 3.5 (2027-01-23). This document the design robustness and builds confidence that the accredited lab run will pass, so hard tooling can be gate-released by Month 6 (2027-04-08) on a 'lab in progress' basis if deposit threshold is met, rather than waiting until Month 7–8 (2027-05-08 to 2027-06-08).

## Create Document 13: In-House Shielding Test Rig Build Plan & Validation Protocol

**ID**: 9c39e8bb-ebaa-4dbc-819d-99fbb3d8a955

**Description**: Technical specification and build plan for in-house RF measurement rig (signal generator, spectrum analyzer, shielded measurement chamber or Faraday cage). Includes target attenuation measurements (50 MHz, 100 MHz, 500 MHz, 1 GHz), seam-cycle repeatability testing (two independent prototypes, minimum three measurements per frequency), and acceptance criteria for design readiness (attenuation variance <5%, no catastrophic failures). Timeline: rig setup Months 0-1 (2026-10-08 to 2026-11-08), prototype 1 build and testing Month 2-3 (2026-12-08 to 2027-01-08), validation report Month 3 (2027-01-08). Audience: RF engineer, project manager.

**Responsible Role Type**: RF Engineer

**Primary Template**: Test Plan & Engineering Specification

**Secondary Template**: Prototype Validation Report Template

**Steps to Create**:

- Specify test rig hardware: signal generator (100 kHz to 1 GHz frequency range), spectrum analyzer (resolution <1 dB), shielded measurement chamber or Faraday cage enclosure.
- Define measurement protocol: source impedance, field-strength levels, attenuation calculation (incident vs. transmitted field ratio), repeatability criteria (multiple measurements per frequency and seam cycle).
- Build timeline: rig assembly and calibration Months 0-1 (2026-10-08 to 2026-11-08); prototype 1 fabrication and fit-up Month 2 (2026-12-08); measurement and seam-cycle testing Month 3 (2027-01-08).
- Measurement plan: test attenuation at 50 MHz, 100 MHz, 500 MHz, 1 GHz (and intermediate frequencies if time permits). Run two independent open/close cycles per frequency (seam compression and release). Document attenuation value and variance.
- Acceptance criteria: attenuation meets claimed band (e.g., ≥ 60 dB from 100 MHz to 1 GHz, ≥ 40 dB at 50 MHz); variance across seam cycles <5%; no field leakage at seams >-20 dB (relative to claimed band).
- Document results in validation report (Month 3 = 2027-01-08); if results meet criteria, proceed to lab design-readiness review; if results fall short, identify design weakness (seam, gasket, aperture) and iterate.

**Approval Authorities**: RF Engineer, Project Manager

**Essential Information**:

- Specify RF measurement hardware requirements: signal generator frequency range (100 kHz to 1 GHz minimum), spectrum analyzer resolution (<1 dB), shielded measurement chamber or Faraday-cage specifications, source impedance, field-strength levels, and calibration protocol.
- Define measurement methodology: attenuation calculation formula (incident vs. transmitted field ratio), repeatability criteria (minimum three measurements per frequency and seam cycle), acceptance variance thresholds (<5% proposed), and catastrophic-failure criteria.
- Establish testing protocol across target frequency bands: attenuation targets at 50 MHz, 100 MHz, 500 MHz, 1 GHz (and intermediate frequencies if resources permit), seam-compression and release cycles (two independent prototypes minimum), and documentation standards for each measurement.
- Document rig assembly and calibration plan: timeline (Months 0–1 = 2026-10-08 to 2026-11-08), equipment sourcing, calibration procedures, measurement-environment validation, and sign-off criteria before prototype testing begins.
- Detail prototype build and fit-up procedure: enclosure fabrication (Month 2 = 2026-12-08), lid-seam and gasket integration, dimensional verification (fits to claimed internal size 420 x 280 x 50 mm estimate), and repeatability preparation (two independent prototypes with identical tooling).
- Specify acceptance criteria for design readiness: minimum attenuation in each band (e.g., ≥60 dB from 100 MHz to 1 GHz, ≥40 dB at 50 MHz, proposed thresholds), seam-cycle variance <5% (proposed threshold), field-leakage limits at seams >-20 dB relative to claimed band, and pass/fail decision logic.
- Create validation report template (Month 3 = 2027-01-08): measured attenuation values and variance by frequency, seam-cycle repeatability data, comparison to acceptance criteria, identification of any design weaknesses (seam, gasket, aperture), and clear pass/fail recommendation for lab design-readiness review.
- Define escalation pathway if results fall short: specify which design parameters (seam compression depth, gasket material, aperture shielding) will be investigated, iteration timeline (if redesign needed, by when must in-house rig re-test complete?), and decision point for escalating to the external EMC consultancy.
- Link outputs to downstream milestones: in-house validation report (Month 3 = 2027-01-08) must precede lab design-readiness review (Month 4 = 2027-02-08, €2–3k estimate), lab sample submission, and accredited lab report target (Month 5 = 2027-03-08). Document assumption that passing in-house validation is a prerequisite for lab submission.

**Risks of Poor Quality**:

- Undefined measurement protocol or loose acceptance criteria allow subjective interpretation of results, creating confusion between the RF engineer and project manager about whether the design is truly ready for accredited testing. A weak validation report delays or misguides the lab submission decision, wasting the Month 4–5 window (2027-02-08 to 2027-03-08).
- Missing equipment specifications (generator frequency range, spectrum analyzer resolution) or incomplete calibration procedures introduce measurement error that invalidates attenuation data. Lab results may later contradict in-house findings, forcing costly re-design or re-test and consuming the €20k redesign reserve prematurely.
- Insufficient documentation of seam-cycle repeatability (single measurement per frequency or single prototype) fails to catch intermittent leakage or gasket creep, so the design passes in-house testing but fails accredited lab testing. Re-test after tooling commitment incurs €8–15k (estimate) and delays the report to Month 7 (2027-05-08), compressing the presale and fulfillment window.
- Acceptance criteria not clearly defined or not tied to the lab's expected methodology (IEEE 299.1 or equivalent, not verified) result in a design deemed 'ready' by in-house standards but rejected or flagged for revision by the accredited lab. Misalignment forces redesign and re-testing, exceeding the 20k reserve and pushing hard-tooling release past Month 6 (2027-04-08).
- Validation report unclear about which design parameters (seam, gasket, apertures) drove results leaves no actionable feedback for iteration if results fall short. The RF engineer and project manager cannot prioritize redesign efforts, wasting time on low-impact changes while critical weaknesses remain.
- Missing linkage between validation report and lab pre-engagement review (design-readiness consultation) means the lab sees the rig results only after submitting expensive samples, with no prior opportunity to flag mismatches in methodology or frequency range. Lab requests scope expansion or re-testing, incurring unbudgeted costs and timeline slips.

**Worst Case Scenario**: In-house rig setup or measurement protocol is poorly defined, or acceptance criteria are loose and interpreted subjectively. Prototype 1 passes in-house validation on weak or ambiguous evidence, but when samples are submitted to the accredited lab (Month 4 = 2027-02-08), the lab measurement reveals attenuation ≥10 dB below in-house readings in one or more frequency bands, indicating seam or gasket failure not caught by the rig. The lab flags the design as not ready and recommends re-test after redesign. A second lab run (€8–15k estimate) plus minor redesign consume the €20k reserve entirely and delay the report to Month 7 (2027-05-08), a 2-month slip past the target. Hard tooling and batch 1 are deferred until Month 8 (2027-06-08) or later, compressing presale fulfillment into Months 8–12 (2027-06-08 to 2027-10-08). Cumulative delivered-unit revenue by the cash-flow gate measurement (Month 12 = 2027-10-08) falls short of the €25k threshold if presale orders are concentrated in later months and 2–3 week lead times push delivery past Month 12 (2027-10-08). The gate fails, €350k follow-on is withheld, and the venture reaches Month 12 (2027-10-08) with no runway for inventory replenishment or operations beyond the core team.

**Best Case Scenario**: In-house rig is built to specification with accredited equipment and documented calibration (Months 0–1 = 2026-10-08 to 2026-11-08). Prototype 1 is fabricated on schedule (Month 2 = 2026-12-08) and measured against two independent seam cycles with consistent results: attenuation ≥65 dB from 100 MHz to 1 GHz, ≥45 dB at 50 MHz, variance <3% across cycles. Validation report (Month 3 = 2027-01-08) is clear, detailed, and confirms design readiness. Lab design-readiness review (Month 4 = 2027-02-08) validates the rig methodology and attenuation targets, giving confidence that the accredited test will pass. Accredited lab report arrives on schedule (Month 5 = 2027-03-08) confirming the same attenuation bands and report is published immediately. Hard tooling and batch 1 (800 units, €119k) are committed (Month 6 = 2027-04-08) once presale deposits exceed €80k. Fulfillment proceeds on schedule (Months 6–9 = 2027-04-08 to 2027-07-08), with 750 units delivered by Month 9 (2027-07-08), enabling strong delivered-unit revenue (€112.5k estimate) that easily exceeds the €25k quarterly gate threshold. €350k follow-on is released (Month 12.5 = 2027-10-23), enabling inventory expansion, marketing ramp, and second-phase product development.

**Fallback Alternative Approaches**:

- If in-house rig build is delayed beyond Month 1 (2026-11-08) or procurement of RF equipment is slow: negotiate early access to the university lab's RF measurement chamber and spectrum analyzer (if co-development partnership is in place) to run prototype 1 testing there rather than in-house. Document the arrangement in the university milestone agreement by Month 0.5 (2026-10-23), with the understanding that university-facility testing serves as the in-house rig equivalent and must complete by Month 3 (2027-01-08) before lab submission.
- If prototype 1 produces ambiguous results (attenuation in expected range but high variance >8% across seam cycles, or inconsistent results between frequencies): commission a rapid design-review consultation with the EMC consultancy (€2–3k estimate, 1 week turnaround) to diagnose the root cause (seam compression, gasket creep, aperture leakage) and recommend a low-cost redesign. This avoids submitting a questionable design to the accredited lab and buying time for prototype 2 validation (Month 3–4 = 2027-01-08 to 2027-02-08) before hard tooling commit.
- If rig hardware procurement is supply-constrained (e.g., spectrum analyzer lead time >4 weeks estimate): lease or borrow accredited lab equipment temporarily (typically €500–1000 per week estimate for access to chamber and instruments) to run in-house validation in Month 2 (2026-12-08). The borrowed equipment cost is expensed within the €15k lab budget line; the validation data is owned by the company and can inform both in-house and accredited lab work.
- If the target frequency bands (50 MHz, 100 MHz, 500 MHz, 1 GHz) prove difficult to measure due to rig limitations or noise environment: reduce the in-house protocol to the three most critical frequencies (100 MHz, 500 MHz, 1 GHz) and defer 50 MHz measurement to the accredited lab (where shielded chambers provide cleaner data). This shortens in-house rig setup and prototype testing by ~1 week (estimate), keeping the Month 3 (2027-01-08) report date achievable.
- If in-house validation reveals a major design weakness (e.g., attenuation <40 dB at 100 MHz) that would require substantial seam or gasket redesign: escalate immediately to the EMC consultancy for an expedited design review (€3–5k estimate, 1–2 weeks) and commission prototype 2 with the revised design in parallel. Submit both prototype 1 (as-built) and prototype 2 (revised) to the lab for comparison, so the lab can assess the design change impact directly. This avoids losing the Month 5 (2027-03-08) lab report date and keeps hard tooling commit on schedule.
- If accredited lab pre-engagement confirms that IEEE 299.1 is not the applicable standard and a costlier alternative (MIL-STD-285, not verified) is required: immediately negotiate with the lab for a 'tiered' validation approach: accredited testing of the core frequency band (100 MHz to 1 GHz, lower cost) plus optional expanded testing to lower/higher frequencies (à la carte fees). This controls cost to €15k for the core band and defers expanded testing to the €350k follow-on phase, protecting Year-1 budget.


# Documents to Find

## Find Document 1: EU EMC Directive 2014/30/EU & Related Harmonized Standards

**ID**: 72efc6d4-1fd1-4513-8e61-f0c2cee9b087

**Description**: Official EU regulatory text on electromagnetic compatibility for electrical/electronic equipment. Specifies scope, CE marking requirements, notified-body assessment, and conformity procedures. Relevant to determine whether Faraday enclosures are in-scope and whether CE marking is mandatory. Source material for legal opinion and compliance strategy.

**Recency Requirement**: Current legislation; version effective 2016 onward.

**Responsible Role Type**: Legal Counsel

**Steps to Find**:

- Access EUR-Lex database (https://eur-lex.europa.eu/) and search for 'Directive 2014/30/EU'.
- Download full text and preamble; search for 'enclosure', 'shielding', 'RF', 'attenuation' scope language.
- Cross-reference with EN harmonized standards (EN IEC 61000-6-2, EN IEC 61000-6-4) listed in official EU NANDO (New Approach Notified and Designated Organisations) database.
- Consult with notified body or EMC consultancy on whether small passive enclosures are in-scope (likely exempt if non-electronic, but verify).
- Document findings in legal opinion by Month 1 (2026-11-08).

**Access Difficulty**: Easy. EU-Lex is public; full texts available in PDF and HTML formats at no cost.

**Essential Information**:

- Quantify the exact applicability of the EU EMC Directive 2014/30/EU to passive Faraday enclosures: are they in-scope for CE marking, notified-body assessment, and conformity documentation, or exempt as non-electronic equipment?
- Identify which harmonized standards (EN IEC 61000-6-2, EN IEC 61000-6-4, IEEE 299.1, MIL-STD-285, or other) apply to small enclosure shielding effectiveness measurement and what frequency ranges they cover.
- Define the mandatory scope of marketing and performance claims under EU General Product Safety Directive and distance-selling consumer-protection rules: what is legally permissible language for a passive RF-isolation enclosure, and what explicit disclaimers are required?
- Determine whether a single third-party accredited-lab report (not CE certification) is legally sufficient as the basis for all shielding performance claims in EU markets, or whether additional notified-body or conformity documentation is mandatory.
- Quantify the legal liability exposure for claim-substantiation failure: if an enclosure underperforms in a real electromagnetic event and a customer suffers loss, what legal remedies are available (warranty claims, product-safety enforcement, reputational harm) and what insurance coverage is typically obtainable?
- Specify the VAT and cross-border distance-selling obligations for a Tallinn-based vendor shipping to EU buyers: OSS registration requirements, invoice documentation, proof-of-delivery for VAT reversal, and refund/return documentation.
- Detail any mandatory product-safety warnings, instruction-manual requirements, or periodic re-verification obligations (e.g., annual shielding re-test certification) that apply to Faraday enclosures sold as consumer products in the EU.
- Confirm whether product-liability insurance covering Faraday-enclosure claims is obtainable in EU markets, what coverage limits and exclusions are standard, and what premium estimates apply for a EUR 250–500k coverage level.

**Risks of Poor Quality**:

- Incorrect determination of CE-marking applicability risks either (a) launching without mandatory certification, exposing the company to regulatory enforcement action, product recall and fines, or (b) undertaking expensive notified-body assessment unnecessarily, consuming EUR 10–30k (estimate) and 8–12 weeks (estimate) not budgeted in the EUR 400k Year-1 cap.
- Misidentification of applicable measurement standards prevents accurate accredited-lab testing: lab may recommend a costlier or longer-duration standard than budgeted (EUR 15k, 6 weeks), forcing EUR 10–20k (estimate) additional spend and 4–8 week (estimate) schedule slip that compress the presale and redesign window.
- Vague or overstated marketing claims that exceed measured lab data expose the company to consumer-protection challenges, forced claim revision, and reputational damage. In the event of a real electromagnetic incident involving customer loss, unsubstantiated claims create breach-of-warranty and misrepresentation liability that standard product-liability insurance may exclude.
- Missing VAT or distance-selling compliance (OSS registration, invoice requirements, proof of delivery, refund documentation) creates exposure to EU tax audits, penalties for improper VAT treatment, and administrative friction that delays refunds and damages customer trust during the presale phase.
- Failure to secure product-liability insurance due to Faraday-enclosure claims being uninsurable or excluded from standard coverage leaves the company personally liable for claims that could exceed the EUR 400k Year-1 budget, forcing founder personal asset exposure.
- Lack of clarity on whether annual re-verification or maintenance documentation is required creates scope ambiguity for the accredited-lab report: a single test may not satisfy long-term warranty or procurement requirements, forcing post-sale support obligations that strain operations.
- Incomplete instruction-manual or warning requirements result in missing or non-compliant product documentation, which can be grounds for regulatory enforcement even if the enclosure itself performs correctly, damaging brand and delaying shipments.

**Worst Case Scenario**: 
Misunderstanding of EU regulatory applicability and claim-substantiation rules leads to one or more cascading failures: (1) The product launches without discovering that CE marking is mandatory, and an EU regulator issues a compliance notice or product-recall order within Months 6–12 (2027-04-08 to 2027-10-08), forcing an emergency redesign, re-testing, or market withdrawal that consumes the EUR 20k (estimate) redesign reserve and delays the cash-flow gate by 3–4 months, blocking the EUR 350k follow-on. (2) A presale customer or regulator challenges marketing claims as exceeding measured data, triggering a forced claim revision that narrows addressable market and reduces presale conversion by 20–40% (estimate), leaving presale deposits below the EUR 80k (proposed threshold) tooling gate and stranding the venture without tooling or inventory. (3) Product-liability insurance is obtained with an exclusion for Faraday-enclosure claims, leaving the company personally liable; a real-world incident involving customer loss creates a claim exceeding EUR 100k (estimate) in legal fees and damages that depletes remaining Year-1 cash and founder personal resources, forcing wind-down. Combined, regulatory uncertainty and uninsured liability can exhaust the EUR 400k Year-1 budget on legal defense and remediation, block the EUR 350k follow-on, and leave the founder with personal loss exposure.


**Best Case Scenario**: 
A definitive legal opinion by Month 1 (2026-11-08) confirms that Faraday enclosures are not in-scope for CE marking (classified as non-electronic equipment under the General Product Safety Directive only), so voluntary accredited-lab reporting and strict claim-limiting language are legally sufficient. Marketing claims are locked to measured attenuation across the tested frequency range, with an explicit scope statement: "This enclosure protects stored spare devices only. It does not protect active equipment or prevent grid-scale events." Product-liability insurance is obtained covering EUR 250–500k (estimate) in defect claims, with Faraday-enclosure performance claims clarified and insurable. VAT and distance-selling requirements are clarified and implemented (OSS registration, invoice templates, refund procedures). Result: the accredited-lab report serves as unambiguous public credibility and legal protection; all marketing, sales, and presale materials are compliant and defensible; no surprise regulatory costs or schedule slip arise; product-liability claims are covered by insurance; and the EUR 400k Year-1 budget is executed as planned, reaching the cash-flow gate on schedule by Month 12 (2027-10-08).


**Fallback Alternative Approaches**:

- If legal opinion confirms CE marking is mandatory and notified-body assessment is required: immediately (Month 0.5–1 = 2026-10-23 to 2026-11-08) contact 2–3 EU notified bodies (Germany, Netherlands, Sweden) for a fast-track CE assessment quote; if cost exceeds EUR 20k (estimate) or timeline extends past Month 6 (2027-04-08), reduce the redesign reserve from EUR 20k to EUR 10k and shift EUR 10k from marketing to CE assessment, accepting later presale launch or smaller marketing budget. Alternatively, narrow the product narrative to exclude any health, safety, or performance claims and sell solely as 'RF-isolation accessory for electronics storage' with no protection assertions, reducing conformity scope.
- If the accredited lab requires a costlier or longer standard (MIL-STD-285 or higher) than budgeted: request the lab to perform a lower-cost initial survey test (1–2 days) to confirm feasibility before full certification, using that result to decide whether to (a) proceed with costlier test by raising the reserve to EUR 30k (cut marketing by EUR 10k), (b) narrow the frequency range to reduce test scope and cost, or (c) defer full accreditation and launch with in-house-rig results only, accepting lower infrastructure-buyer credibility.
- If product-liability insurance for Faraday enclosures is uninsurable or excludes shielding claims: shift marketing language to emphasize privacy, RF isolation, and electronic device protection from everyday RF exposure (not emergency/disaster events), reducing perceived safety-critical use and making claims more insurable. Alternatively, obtain a bespoke policy from a specialty insurer at higher premium (5–10% of EUR 250–500k coverage estimate), funded by increasing the presale price by EUR 5–10 per unit or reducing early marketing spend.
- If EU distance-selling VAT rules create significant compliance friction: contract a specialized VAT and OSS compliance service provider (EUR 2–5k annual estimate) to handle registration, invoicing, and refund documentation, or partner with an EU-based fulfillment provider (DHL, Amazon Logistics) that handles VAT compliance as part of their service, shifting administrative load out of founder operations.
- If annual re-verification or maintenance certification is required: negotiate with the accredited lab upfront (Month 1.5 = 2026-11-23) for a post-sale verification package (e.g., annual re-test of sample units at 20–50% of initial cost, estimate EUR 3–5k per year) and price this into the product offering (EUR 15–25 per unit annual fee estimate), creating a recurring revenue stream and converting a compliance cost into customer value.
- If marketing claims cannot be substantiated by the accredited lab result: establish an independent third-party testing consortium (in partnership with other Faraday vendors or academic labs) that publishes comparative performance data across brands, providing peer-validated evidence that supports broader claims without bearing solo burden of proof.

## Find Document 2: EU General Product Safety Directive 2001/95/EC & Consumer Protection Rules

**ID**: 7e3fcaac-0222-431d-86b3-ce9bf4f5e50f

**Description**: Official EU legislation governing consumer product safety, warning labels, liability, and conformity. Specifies scope (any product intended for consumer use), claim substantiation, and warranty/liability exposure. Applies even if EMC Directive is out-of-scope. Relevant for claim wording, fit disclaimers, and refund policy compliance.

**Recency Requirement**: Current legislation; supplemented by Directive 2011/83/EU on consumer rights (distance contracts, cancellation).

**Responsible Role Type**: Legal Counsel

**Steps to Find**:

- Access EUR-Lex and search for 'Directive 2001/95/EC' (General Product Safety Directive).
- Cross-reference Directive 2011/83/EU on consumer rights (cancellation, distance selling).
- Download full texts; search for 'liability', 'information', 'safety', 'warnings', 'commercial practices'.
- Identify country-specific implementations (e.g., Estonia Consumer Protection Act) if Tallinn-based operations create local jurisdiction.
- Document scope-statement and disclaimer language needed for presale terms and product documentation.
- Include findings in legal opinion by Month 1 (2026-11-08).

**Access Difficulty**: Easy. EU-Lex is public; all texts available in multiple EU languages.

**Essential Information**:

- Identify which EU product-safety directives and consumer-protection rules apply to a passive Faraday enclosure marketed for RF shielding of stored devices (General Product Safety Directive 2001/95/EC applicability; EMC Directive 2014/30/EU applicability; distance-selling and cancellation rules under Directive 2011/83/EU).
- List the exact claim-substantiation requirements: what performance claims are permissible without third-party certification, and what warranty disclaimers or scope statements are legally required to limit liability for failure in a real electromagnetic event.
- Detail the mandatory warning labels, product information, and documentation required for consumer sale within the EU, and confirm whether these must be included with every unit or only in presale terms.
- Specify the refund and cancellation obligations for presale (distance-selling) contracts: 14-day cancellation right scope, restocking fees permissibility, and how presale deposits are treated under consumer law.
- Quantify the potential regulatory penalties (fines, mandatory recalls, injunctions) if marketing claims exceed measured data or are deemed misleading under consumer-protection rules.
- Clarify whether a passive enclosure requires CE marking, notified-body assessment, or other third-party conformity proof under any applicable directive, and identify the applicable standard or test method.
- Confirm the product-liability insurance applicability: whether Faraday-enclosure performance claims are insurable, what coverage limits are standard, and what exclusions or caveats insurers typically impose.

**Risks of Poor Quality**:

- Incorrect determination of applicability (e.g., EMC Directive applies but is missed) leads to regulatory challenge, product recall, or fines (EUR 10–80k estimate) after presale launch, damaging brand trust and consuming scarce Year-1 cash.
- Overstated marketing claims (e.g., 'protects against Carrington events' without qualified scope) violate consumer-protection rules and create warranty/liability exposure; customer complaints or enforcement action force claim revision or product withdrawal mid-presale.
- Missing or inadequate scope statement and disclaimers create reputational risk if a customer experiences device loss in a real electromagnetic event and claims misrepresentation; uninsured liability exposure exceeds company reserves.
- Unclear refund policy under EU distance-selling rules (Directive 2011/83/EU) exposes presale deposits to unexpected cancellation claims and refund obligations, eroding working capital at critical funding gates.
- Failure to lock product-liability insurance terms early leaves the company uninsured during presale; a single customer claim or product defect triggers legal costs (EUR 30–80k estimate) that consume the EUR 20k redesign reserve.

**Worst Case Scenario**: Regulatory enforcement action in Month 6–8 (2027-04-08 to 2027-06-08) (e.g., by an EU member-state consumer authority) disputes claim substantiation or applicability of CE marking requirements, forcing presale pause, claim revision, and potential product recall. Simultaneous uninsured liability claim from a customer alleging device loss in an electromagnetic event triggers legal defense costs (EUR 50–100k estimate) that exhaust the EUR 20k reserve and halt production. Combined regulatory and liability exposure forces wind-down of Year-1 operations, withholds the EUR 350k follow-on, and leaves the founder with sunk tooling and design costs unrecovered.

**Best Case Scenario**: Legal opinion by Month 1 (2026-11-08) confirms General Product Safety Directive applicability but exempts the product from CE marking under EMC Directive. Clear scope statement and measured-data-only claims pass consumer-protection scrutiny. Product-liability insurance terms are locked at standard rates (EUR 15–25k annual premium estimate) with coverage up to EUR 500k. Presale terms comply with distance-selling rules and refund obligations are understood by customers upfront. Throughout Year-1, no regulatory challenge or liability claim emerges, and the accredited lab report provides independent credibility. The gate is met, the EUR 350k follow-on is released without compliance friction, and Year-2 operations scale without legal or insurance constraints.

**Fallback Alternative Approaches**:

- If legal opinion (Month 1 = 2026-11-08) indicates CE marking or notified-body assessment is required: immediately request a statement of work from the accredited EMC lab covering conformity documentation (EUR 10–25k estimate, 8–12 week timeline estimate). Reprioritize the Year-1 burn schedule to front-load conformity work before presale launch; defer non-critical spending (e.g., reduce marketing budget by EUR 10–15k) to absorb the additional cost within the EUR 400k cap.
- If product-liability insurance is unavailable or prohibitively expensive (>EUR 50k/year estimate): strengthen the scope statement to explicitly disclaim coverage of active, grid-connected, or real-time equipment and limit warranty to 'stored spare devices only.' Publish the disclaimer prominently in presale terms, on product packaging, and in the lab report. Require presale customers to sign a scope-acknowledgment document before order confirmation, creating a paper trail of informed consent.
- If presale refund claims spike above 15% by Month 6 (2027-04-08) due to delivery delays or fit issues: temporarily suspend new presale deposits and switch to a wholesale or consignment model with established retailers (e.g., survival, preparedness, or privacy retailers) that carry inventory and customer support. This shifts refund and customer-service liability to the retailer and reduces direct consumer-law exposure.
- If a regulatory challenge emerges mid-presale (Month 6–8 = 2027-04-08 to 2027-06-08): engage a specialized consumer-protection or product-compliance lawyer (cost: EUR 5–15k estimate) to defend the claim and negotiate a settlement or revised compliance pathway. Simultaneously, pause presale marketing and pivot to wholesale or B2B channels (critical-infrastructure buyers, emergency planners) where contract terms can be negotiated and standardized, reducing consumer-protection friction.
- If product-liability insurance terms are restrictive or exclude Faraday-enclosure claims: consider a self-insurance model with a dedicated reserve (EUR 30–50k estimate, funded from the EUR 350k follow-on post-gate) and a limited-liability warranty cap (e.g., EUR 500 per unit maximum claim, stated in presale terms). This reduces premium cost but requires clear customer communication and potentially a higher presale price to cover the self-insured risk.

## Find Document 3: IEEE 299.1 Standard for Shielding Enclosure Testing (or Equivalent RF Shielding Standard)

**ID**: e29c0813-a089-4055-b2e7-711cadb4bd90

**Description**: International standard specifying test methodology for RF shielding effectiveness of small enclosures. Covers frequency range (typically 20 MHz to 40 GHz), measurement equipment, sample preparation, and pass/fail criteria. Essential for accredited lab selection and test planning. Source material for RF engineer and lab pre-engagement consultation.

**Recency Requirement**: Latest edition (2018 or 2021, depending on availability); older versions acceptable if confirmed by accredited lab as applicable.

**Responsible Role Type**: RF Engineer

**Steps to Find**:

- Search IEEE Standards Online (https://standards.ieee.org/) for 'IEEE 299.1' and related enclosure standards.
- If direct access unavailable, request standard quote from IEEE; alternatively, check with accredited EMC labs (DEKRA, TÜV, SGS) which typically have library access.
- Cross-check with IEC or EN equivalents (IEC 61000-4-3, EN standards for shielding).
- Obtain copy of standard (or sufficient excerpt) by Month 0.5 (2026-10-23) to share with lab pre-engagement consultation.
- If IEEE 299.1 is inapplicable, lab will recommend alternative (e.g., MIL-STD-285, IEC 61000-4-3) in pre-engagement consultation by Month 0.5 (2026-10-23).

**Access Difficulty**: Medium. IEEE standards require paid subscription (approximately USD 100-200 per standard) or institutional library access. Accredited labs often have copies available for consultation.

**Essential Information**:

- Identify the specific RF shielding standard(s) applicable to small Faraday enclosures (IEEE 299.1, IEC 61000-4-3, MIL-STD-285, or EN equivalent), including frequency range, measurement methodology, and pass/fail attenuation thresholds.
- Confirm the exact cost (fixed quote, not estimate) for accredited EMC laboratory testing of a production-representative enclosure sample against the selected standard.
- Verify the accredited laboratory's timeline for design-readiness review, sample submission protocol, measurement duration, and report delivery target (committed date, not estimate).
- Document the laboratory's recommendation on whether IEEE 299.1 is applicable or whether an alternative, potentially higher-cost standard (e.g., MIL-STD-285) is required for EU critical-infrastructure procurement credibility.
- Specify the frequency range and attenuation thresholds (dB, frequency bands) that the selected standard defines as 'pass' for a Faraday enclosure, to set the design target before prototyping begins.
- List any additional compliance testing or certification steps (EMC Directive, notified-body assessment, CE marking) required by EU rules if the enclosure is sold as a standalone product or bundled kit.
- Provide guidance on sample preparation, seam and gasket configuration, and aperture/port constraints that the standard imposes, to inform enclosure design iteration.
- Clarify the cost and timeline implications if the chosen standard requires re-testing after any design change (seam, gasket material, size, apertures).

**Risks of Poor Quality**:

- Wrong standard selected: lab pre-engagement assumes IEEE 299.1 but recommends MIL-STD-285 or other variant, adding €10–20k (estimate) cost and 4–8 weeks (estimate) delay, exceeding the €15k budget and Month 5 (2027-03-08) report target.
- Undefined pass/fail thresholds: enclosure is designed to unstated attenuation target, lab test fails on a minor shortfall, and the cost of re-test (€8–15k estimate) and redesign (€10–20k estimate) consumes the €20k redesign reserve and delays the report by 2–4 months, compressing the presale and fulfillment window before the cash-flow gate measurement (Month 12 = 2027-10-08).
- Applicability ambiguity: standard applicability is not confirmed before design freeze; seam or gasket changes after certification force costly re-qualification under a stricter standard, and the €20k reserve is exhausted before redesign is complete, leaving zero contingency for other overruns.
- Cost or timeline surprises in lab engagement: quoted cost is higher than €15k budget or report timeline slips past Month 5 (2027-03-08), forcing a choice to accept lower-quality accreditation, pay out-of-budget, or delay tooling and presale fulfillment.
- Weak credibility with infrastructure buyers: if the selected standard or methodology is not recognized by critical-infrastructure procurement, the accredited report does not support infrastructure sales, narrowing the presale market to preppers alone and raising the risk that cash flow misses the €25k (proposed threshold) gate.
- Claim-substantiation exposure: marketing claims state attenuation thresholds or frequency range not confirmed by the test standard, creating regulatory challenge risk or customer complaints if real-world performance falls short of stated claims.

**Worst Case Scenario**: 
The accredited laboratory pre-engagement (not yet done) reveals that the selected standard (assumed IEEE 299.1) is inapplicable for a standalone small enclosure; the lab recommends MIL-STD-285 or a multi-part EU standard suite requiring €25–35k (estimate) total cost, 12–16 week timeline, and monthly re-validation after design changes. Prototype design proceeds based on the wrong standard assumptions. By Month 4 (2027-02-08), samples are submitted for testing under the assumed method. Month 5 (2027-03-08) lab report fails on attenuation shortfall in the 100–1000 MHz band due to seam-gasket interaction not accounted for in the cheaper standard. Re-test is required under the correct standard, consuming the full €20k redesign reserve and an additional €15k not budgeted. Hard tooling decision is deferred from Month 6 (2027-04-08) to Month 7.5 (2027-05-23) at earliest. Presale fulfillment window compresses from 5 months to 2.5 months before the cash-flow gate (Month 12 = 2027-10-08). Delivery lead times extend from 2–3 weeks to 6–8 weeks, and presale conversion drops 20–30% (estimate) due to long delays. Realized presale volume is 600 units instead of 800, generating delivered-unit receipts of EUR 40k (estimate) by Month 12 (2027-10-08), falling EUR 15k short of the €25k gate threshold. The €350k follow-on is withheld. Founder faces a Year-2 funding gap with no capital for inventory, marketing or R&D, forcing a restructuring or wind-down.


**Best Case Scenario**: 
By Month 0.5 (2026-10-23), three accredited EU EMC laboratories confirm that IEEE 299.1 (or IEC 61000-4-3 annex, not verified) is the standard applicable to standalone small Faraday enclosures for the tested frequency range. One lab offers a fixed-cost statement of work (€13–15k within budget) including a no-cost design-readiness review and a committed report delivery by Month 5 (2027-03-08). The lab specifies the exact pass threshold: ≥30 dB attenuation across 10 MHz to 10 GHz (estimate, illustrative). Enclosure design targets this threshold, and two in-house rig validation cycles (two independent seam configurations) confirm margin by Month 3 (2027-01-08). Samples are submitted Month 4 (2027-02-08); report arrives on time Month 5 (2027-03-08) with full frequency-sweep data showing 35–42 dB attenuation (above target), no re-test required. Report is published with presale marketing and added to every unit sale as proof. Infrastructure procurement reviewers accept the published report as credible evidence, unlocking infrastructure pilot orders (€30–50k estimate revenue contribution) by Month 6 (2027-04-08). Presale deposits reach €120k by Month 6 (2027-04-08), hard tooling is released, batch 1 (800 units) ships Months 7–9 (2027-05-08 to 2027-07-08), and delivered-unit receipts by Month 12 (2027-10-08) total €43k (estimate, 750 units at €60 average margin including infrastructure premium). Cash-flow gate is passed by €18k margin. The €350k follow-on is released Month 12.5 (2027-10-23), funding Year-2 inventory and marketing.


**Fallback Alternative Approaches**:

- If IEEE 299.1 is not applicable and a costlier MIL-STD-285 or multi-part EU standard is required: negotiate with two backup accredited labs for the lowest fixed cost and fastest timeline; if total cost exceeds €25k, raise the redesign reserve from €20k to €30k by cutting Year-1 marketing spend by €10k (reduce from €75k to €65k), accepting lower presale awareness but protecting design validation.
- If the chosen standard's pass threshold is undefined or higher than the enclosure can meet: request a pre-test design-readiness review from the lab (€2–3k estimate) at Month 2 (2026-12-08) to get feedback on likely attenuation before expensive sample submission; use feedback to iterate in-house rig design if margin is insufficient, deferring lab submission to Month 5 (2027-03-08) and report to Month 6.5 (2027-04-23).
- If the accredited lab timeline slips past Month 5 (2027-03-08): identify and lock a second accredited lab by Month 2 (2026-12-08) as a backup with a committed report date by Month 6 (2027-04-08); if primary lab delays past Month 4.5 (2027-02-23), switch to backup immediately.
- If EU conformity regulations (EMC Directive, CE marking) apply but are not budgeted: commission a legal opinion by Month 0.5 (2026-10-23) on applicable directives and notified-body scope; if CE is required, negotiate with the accredited lab to include notified-body assessment in the test report scope, spreading the cost across the €15k test budget instead of adding €10–30k separate cost.
- If presale market is weak and hard tooling cannot be committed by Month 6 (2027-04-08) due to insufficient deposits: extend presale offer to Month 8 (2027-06-08) and pivot marketing narrative from disaster prep (Carrington Event) to multi-use RF isolation (privacy, travel, key-fob security, digital-forensics) to attract higher-value buyer segments; if deposits remain below €80k (proposed threshold) at Month 8 (2027-06-08), release the €350k follow-on as a co-investment tranche conditional on founder matching additional capital, or wind down the venture.
- If the standard-recommended design is incompatible with the single-SKU constraint (e.g., size, seam method, materials): negotiate with the lab for alternative configurations that meet the standard but fit the manufacturing plan; or plan a two-SKU launch (large and small) with a phased approach, launching the large SKU in Year-1 on the revised timeline and deferring the small SKU to Month 12+ post-gate.

## Find Document 4: Tallinn Precision Sheet-Metal Fabrication Industry Data & ISO 9001 Certified Fabricator Directory

**ID**: e567c624-86f8-4fee-a285-1c2edbd35279

**Description**: Directory or industry data on Tallinn and Estonia-based precision sheet-metal fabricators with ISO 9001/9003 certification, laser-cutting and CNC-bending capability. Includes names, locations, capabilities, lead times, and pricing benchmarks. Source material for fabricator identification and supplier comparison.

**Recency Requirement**: Current (2024-2026); updated annually acceptable.

**Responsible Role Type**: Supply Chain Coordinator

**Steps to Find**:

- Contact Estonian Chamber of Commerce & Industry (https://www.koda.ee/) for directory of precision-metal fabricators in Tallinn industrial district.
- Search Google Maps and industry databases (e.g., Kompass, local industry portals) for 'precision metal fabrication', 'laser cutting', 'CNC bending' in Tallinn, Estonia.
- Review ISO 9001 certification databases (EMAS, notified bodies lists) for Tallinn-area metal fabricators.
- Identify companies: request capability brochures, pricing samples (laser-cut and bend accuracy, tolerances, materials), lead times, capacity availability.
- Pre-qualify primary and secondary fabricators by Month 1 (2026-11-08) with trial batch quote.
- Document cost benchmarks: soft tooling (laser setup, material cutting, bending, finishing) typically EUR 500-1,500 per design iteration, unit cost EUR 50-80 per unit for low-volume batch (500-1,000 units estimate).

**Access Difficulty**: Medium. Chamber of Commerce databases may require membership or direct contact. Google Maps and company websites are public. ISO certification databases are public; individual company certifications may require request to the company.

**Essential Information**:

- Identify the complete roster of ISO 9001/9003-certified precision sheet-metal fabricators in Tallinn and Estonia with laser-cutting and CNC-bending capability; include company names, addresses, contact details, and certifications.
- Document the technical capabilities of each fabricator: minimum and maximum sheet-thickness tolerance, laser-cut edge finish, CNC-bend accuracy, available materials (aluminium, steel grades), and lead times for soft tooling (design iteration) versus hard tooling.
- Quantify soft-tooling cost benchmarks for a small-batch enclosure design (single laser-cut and bend iteration): typical cost range in EUR per design change, including material waste and labour.
- List the unit cost per enclosure for low-volume batch production (500–1,000 units, 800 units baseline): material cost, labour, finishing, and final assembly by each fabricator, with volume discounts documented.
- Establish lead times for each critical path: prototype fabrication (2–4 weeks estimate), hard-tooling design and setup (4–8 weeks estimate), and first production batch (1,500 units, 4–6 weeks estimate).
- Identify which fabricators have spare capacity for the Year-1 programme (1,500 units total in two batches) and confirm availability for Month 6–9 (2027-04-08 to 2027-07-08) production window.
- Confirm material sourcing for conductive gaskets and seals: which fabricators supply them in-house or have pre-qualified external suppliers; lead times and cost per unit.
- Document pricing and availability of a secondary Tallinn-area precision-metal fabricator and gasket supplier as backup, with trial quotes for soft and hard tooling.

**Risks of Poor Quality**:

- Missing or incomplete fabricator directory delays supplier identification and negotiation, pushing fabricator contracts past Month 1.5 (2026-11-23) statement-of-work deadline and compressing prototype-development timeline.
- Inaccurate unit-cost or lead-time benchmarks lead to underbudgeting production costs or missing the Month 6 (2027-04-08) hard-tooling release gate, consuming the EUR 20k redesign reserve or blocking presale fulfillment.
- Lack of confirmed secondary-supplier quotes leaves the programme vulnerable to primary-fabricator price increases or capacity loss, with no documented alternative and risk of 4–6 week sourcing delays during critical production months.
- Unconfirmed gasket-material sourcing creates a hidden critical-path dependency; delays in gasket supply can slip first-batch delivery by 2–4 weeks and trigger refund requests during the Month 9–12 (2027-07-08 to 2027-10-08) cash-flow gate measurement window.
- Inaccurate technical-capability data (tolerance, bend accuracy, materials) leads to design-iteration loops after the accredited lab test, forcing costly re-qualification (EUR 8–15k per re-test estimate) and consuming the redesign reserve.
- Incomplete lead-time and capacity documentation leaves scheduling assumptions undocumented; if actual lead times exceed estimate by 2–4 weeks, batch 1 delivery slips and presale fulfillment commitments are broken, damaging credibility and increasing refund exposure.

**Worst Case Scenario**: Primary fabricator is identified late or lacks available capacity for the Month 6–9 (2027-04-08 to 2027-07-08) production window; no secondary supplier is pre-qualified. Gasket-material sourcing is unconfirmed and has a 6–8 week lead time (estimate). Hard tooling cannot be released on schedule; first batch is delayed to Month 8–9 (2027-06-08 to 2027-07-08) or beyond. Presale customers awaiting fulfillment (targeting delivery by Month 7–8 = 2027-05-08 to 2027-06-08) experience 4–8 week slips. Refund requests spike (20–30% estimate), consuming presale deposits needed for cash flow. Delivered-unit receipts in the cash-flow gate window (Months 9–12 = 2027-07-08 to 2027-10-08) fall short of the EUR 25k threshold by EUR 10–20k, the gate fails, and the EUR 350k follow-on is withheld. The venture reaches Month 12 (2027-10-08) with unfulfilled presale obligations, depleted cash, and no access to growth capital.

**Best Case Scenario**: A pre-qualified primary fabricator (Tallinn-based, ISO 9001-certified) confirms capacity and fixed pricing for Year-1 soft and hard tooling; unit cost is EUR 70 (estimate, within budget). A documented secondary fabricator and gasket supplier are identified and trial-quoted by Month 1 (2026-11-08), reducing supply-chain concentration risk. Soft tooling for prototype fabrication is completed within estimated lead times (2–4 weeks per iteration). Hard tooling is released on schedule by Month 6 (2027-04-08) when presale deposits reach the EUR 80k threshold. First batch (800 units) is delivered to presale customers on time (Month 7–8 = 2027-05-08 to 2027-06-08), with <10% fit-related returns. Gasket supply is uninterrupted, ensuring shielding integrity across all production units. Batch 2 (700 units) is delivered Months 9–12 (2027-07-08 to 2027-10-08), generating delivered-unit receipts of EUR 30–35k in the gate window. The cash-flow gate is met or exceeded, the EUR 350k follow-on is released by Month 12.5 (2027-10-23), and Year-2 production ramps to 3,000 units annually.

**Fallback Alternative Approaches**:

- If ISO 9001-certified Tallinn fabricators lack documented capacity or have pricing 20%+ above estimate: engage the Estonian Chamber of Commerce & Industry (https://www.koda.ee/) or local technology parks (e.g., Ülemiste City, Tehnopol) for direct referrals and negotiate capacity reservation or price-lock agreements by Month 1 (2026-11-08).
- If Tallinn-based secondary fabricator cannot be identified: research precision-metal shops in neighbouring EU countries (Latvia, Lithuania, Poland) with direct air/rail access to Tallinn-area suppliers for component finishing and assembly, balancing logistics cost against supply-chain diversification.
- If gasket-material supply is unconfirmed or has >4 week lead time: immediately source conductive-gasket samples from international suppliers (e.g., Germany, UK, US) with expedited delivery and lock in a 30–60 day buffer-stock agreement (EUR 5–10k estimate) before Month 1.5 (2026-11-23) to de-risk production.
- If soft-tooling iteration costs exceed budget (EUR 20k plan, EUR 30k estimated range): commission the fabricator to design the enclosure in CAD and perform one free 2D laser-cut and bend simulation to confirm manufacturability before committing material and labour, reducing rework loops.
- If the primary fabricator experiences a capacity or financial crisis during Month 5–7 (2027-03-08 to 2027-05-08): activate the pre-qualified secondary supplier immediately and commission batch 1 from them, even at a 5–10% cost premium (EUR 3–7k estimate), to meet the Month 6 (2027-04-08) tooling-release gate and avoid presale fulfillment slippage.

## Find Document 5: Presale Community Forums, Prepper Networks & Infrastructure Buyer Contacts Database

**ID**: 885a815e-4a5b-433f-a173-2661b79145ea

**Description**: Compiled list and outreach contacts for prepper networks (Reddit r/preppers, German preparedness communities, UK survival forums), digital-forensics/privacy communities (r/privacy, data-protection forums), and critical-infrastructure buyer groups (emergency management agencies, utility operators, security consultants). Source material for presale customer targeting and pilot-buyer outreach.

**Recency Requirement**: Current (2024-2026); forum activity and contact lists updated quarterly.

**Responsible Role Type**: Presale Manager

**Steps to Find**:

- Identify major prepper communities: Reddit r/preppers (500k+ members), Survivalist Forum, UK Prepping forums, German 'Vorsorge' and 'Krisenvorsorge' communities (e.g., krisenvorsorge.org, similar German-language sites).
- Identify digital-forensics and privacy communities: r/privacy (500k+ members), Digital Forensics & Incident Response (DFIR) communities, corporate IT security forums, SANS community.
- Identify critical-infrastructure buyer networks: contact lists for emergency management agencies (FEMA equivalent in EU countries), utility operators, telecommunications authorities.
- Compile database: community name, contact person (if community-managed), typical member profile, engagement level (active discussions on relevant topics), posting guidelines (self-promotion rules).
- Identify 3-5 key influencers or moderators per community for pilot outreach by Month 1 (2026-11-08).
- Use list to launch presale campaigns (Prepper, Infrastructure, Privacy segments) by Month 1 (2026-11-08).

**Access Difficulty**: Medium. Public forums are open; private groups may require membership. Influencer and official contact information requires research and direct outreach.

**Essential Information**:

- Compile a master list of active prepper and preparedness communities with current membership counts, posting activity levels, and identified influencers or moderators by community (target: 3–5 per community) by Month 0.5 (2026-10-23).
- Identify and contact critical-infrastructure buyer networks including emergency-management agencies (EU equivalents to FEMA), utility operators, telecommunications authorities, and civil-protection consultants with decision-maker names and email contacts by Month 1 (2026-11-08).
- Document digital-forensics and privacy communities (r/privacy, DFIR forums, corporate IT security groups) with member profiles, engagement patterns, and contact protocols for outreach by Month 1 (2026-11-08).
- List community-specific engagement rules and self-promotion guidelines so presale campaigns comply with each forum's terms and avoid moderation blocks or bans.
- Provide segment-specific outreach templates and messaging for each buyer type (prepper networks emphasizing Carrington/disaster preparedness; infrastructure buyers emphasizing continuity-of-operations; privacy/forensics buyers emphasizing RF isolation and key-fob security).
- Track deposit velocity and average order value by community/segment weekly starting Month 1 (2026-11-08) to identify which segment converts fastest and adjust marketing allocation by Month 3 (2027-01-08).
- Record influencer and moderator outreach responses, pilot-interest indicators, and early feedback on product fit and messaging to inform Month 3 (2027-01-08) pivot decision if prepper share exceeds 70% of deposits.

**Risks of Poor Quality**:

- Inaccurate or outdated contact lists result in wasted outreach to inactive forums or disconnected decision-makers, delaying infrastructure pilot agreements and reducing the credibility of presale campaigns.
- Missing engagement rules for each community cause presale posts to be flagged as spam or self-promotion, resulting in post removal, account suspension, and reputation damage before launch.
- Insufficient influencer identification fails to leverage early adopters and trusted voices, leaving presale campaigns reliant on cold outreach with low conversion rates and long sales cycles.
- Lack of segment-specific messaging templates leads to generic or misaligned messaging (e.g., disaster-prep language to IT security buyers or vice versa), reducing deposit conversion and diluting brand positioning.
- No weekly tracking of deposit velocity by segment prevents real-time pivot decisions, leaving marketing spend committed to underperforming channels past Month 3 (2027-01-08) decision gate.
- Missing infrastructure buyer contact data delays critical-infrastructure pilot agreements, allowing long sales cycles (8–12 weeks estimate) to extend past the presale and fulfillment window, missing the cash-flow gate measurement window (Months 9–12 = 2027-07-08 to 2027-10-08).

**Worst Case Scenario**: Presale campaigns launch into outdated or inactive forums with missing community rules, resulting in post removal, account suspension, and reputational damage before Month 1.5 (2026-11-23). No influencer relationships are established, so presale deposits arrive through cold outreach only, converting at 10–20% (estimate) versus 40–50% baseline (estimate). Infrastructure buyer contacts are missing, so critical-infrastructure pilots do not close until Month 10–12 (2027-08-08 to 2027-10-08) or not at all, leaving presale volume skewed to low-margin prepper units. Combined effect: net presale deposits fall short of EUR 80k (proposed threshold) by Month 6 (2027-04-08), hard tooling is not released, no first batch is produced, fulfillment and revenue miss the cash-flow gate window, and the EUR 350k follow-on is withheld. Company reaches Month 12 (2027-10-08) with design validated but no product in market and no positive cash flow, forcing wind-down or pivoting to external funding with founder dilution.

**Best Case Scenario**: Database of 8–12 active prepper forums, 4–6 privacy/forensics communities, and 15–20 critical-infrastructure buyer contacts is compiled and verified by Month 0.5 (2026-10-23), with 3–5 influencers or decision-makers identified per venue. Presale campaigns launch compliant with each community's rules and leveraging trusted influencers, achieving 45–60% (estimate) deposit conversion within 2–4 weeks. Weekly tracking identifies infrastructure buyers as early deposits (Month 2–3 = 2026-12-08 to 2027-01-08), allowing fast-track pilot agreements to close by Month 3.5 (2027-01-23) with 10–20 infrastructure units at cost + 20%, delivering revenue and reference status by Month 5 (2027-03-08). Parallel deposit inflow from all three segments reaches EUR 110–150k by Month 5 (2027-03-08), triggering hard-tooling release by Month 6 (2027-04-08) and first production batch. Fulfillment of 1,500 units across Months 7–12 (2027-05-08 to 2027-10-08) generates EUR 30–40k quarterly cash flow, exceeding the EUR 25k (proposed threshold) gate and unlocking the EUR 350k follow-on by Month 12.5 (2027-10-23).

**Fallback Alternative Approaches**:

- If community database cannot be compiled by Month 0.5 (2026-10-23): hire a market-research contractor (EUR 8–12k estimate) by Month 0.5 (2026-10-23) to assemble and verify the list, including influencer contact and engagement-rule documentation by Month 1 (2026-11-08).
- If direct outreach to forums is slow or unresponsive: partner with an established preparedness retailer or consultant (e.g., prepper podcast host, survival school, emergency-response consultant) by Month 1.5 (2026-11-23) to conduct presale outreach on a commission basis (10–15% estimate), trading slower direct deposits for faster influencer-backed volume.
- If critical-infrastructure buyer contacts prove hard to identify or unreachable: engage a government-affairs or emergency-management consultant (EUR 5–10k estimate) by Month 2 (2026-12-08) to provide access to utility, emergency-management, and telecom procurement networks in target EU countries.
- If community engagement rules prevent presale posts: develop a presale landing page or whitepaper-download model (instead of direct forum sales) to be shared in forums as educational content, with lead capture and outreach, reducing reliance on in-forum selling and community moderation.
- If deposit velocity tracking reveals low infrastructure conversion by Month 3 (2027-01-08): reallocate EUR 10–15k from prepper marketing to a targeted LinkedIn or corporate-IT-channel campaign for the privacy/forensics and IT-security buyer segments (Month 3.5 = 2027-01-23 onward), using the parallel segment approach documented in the assumptions.