**Primary domain:** Electromagnetic Shielding Engineering

**Secondary domains:** Precision Sheet Metal Manufacturing, Product Certification, Consumer Product Marketing

**Rationale:** Electromagnetic Shielding Engineering is the only outcome-role candidate and owns the main success criterion, a certified, effective Faraday enclosure. EMC Testing and Product Certification are constraints; manufacturing, design, marketing and finance are subordinate methods or markets.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Electromagnetic Shielding Engineering | 5 | 5 | outcome | Core product is a certified Faraday enclosure; shielding effectiveness defines success. |
| Electromagnetic Compatibility Testing | 5 | 5 | constraint | Shielding effectiveness must be measured and verified against recognised standards for credible certification. |
| Precision Sheet Metal Manufacturing | 4 | 4 | method | Production anchored in Tallinn's ISO-certified precision-metal fabrication ecosystem. |
| Product Certification | 4 | 4 | constraint | Product must pass EMC/shielding testing and EU conformity requirements before sale. |
| Consumer Product Marketing | 4 | 4 | market | Pre-selling to prepping networks and infrastructure buyers requires niche go-to-market and demand validation. |
| Industrial Design | 4 | 4 | method | Enclosure design for phones and laptops must balance usability, aesthetics, and shielding performance. |
| Startup Financial Management | 4 | 3 | method | Staged €750k funding with cash-flow-conditional tranche requires burn control and gating. |
| Supply Chain Logistics | 3 | 3 | method | Distribution from Tallinn across Europe requires fulfilment, customs, and shipping management. |
| Crowdfunding and Presales | 3 | 3 | market | Pre-selling to prepper networks and infrastructure buyers validates demand and supports cash flow. |