# Governance Audit


## Audit - Corruption Risks

- Founder or supplier kickbacks on hard-tooling contracts: Tallinn fabricator or gasket suppliers may offer to inflate invoices in exchange for undisclosed payments, exploiting single-supplier concentration and limited Year-1 oversight. Risk elevated by direct founder involvement in supplier selection and lack of independent procurement review.
- Nepotism in critical-infrastructure pilot selection: Founder or advisors may steer pilot agreements to connected individuals or entities rather than competitive merit, compromising reference-customer credibility and introducing undisclosed financial interests in the gate-measurement process.
- Conflict of interest in lab selection and gate sign-off: Founder may select an accredited EMC lab offering favorable (biased) test results or looser standards in exchange for future non-disclosed benefits. External advisor appointed to co-sign the cash-flow gate may have undisclosed financial stakes in gate outcome (e.g., bonus tied to tranche release), creating incentive to inflate cash-flow interpretation.
- Misuse of presale deposits as personal operating capital: Although designated as customer liabilities, presale deposits held in founder's personal or company account may be commingled with personal funds or used for non-product expenses (marketing, travel, advisory fees) before fulfillment obligations are met, creating de facto embezzlement risk.
- Information asymmetry in presale refund handling: Founder controls presale refund approvals and accounting without independent audit; refund requests may be selectively denied or delayed to inflate apparent cash flow at gate-measurement window, distorting the qualification for the EUR 350k tranche.
- Trading favors with university partner: Co-development partnership with Estonian university lab may involve undisclosed quid-pro-quo arrangements (founder financial support to lab projects, preferential treatment in publication rights) in exchange for expedited or biased test results and measurement access.

## Audit - Misallocation Risks

- Budget drift from presale/marketing into hard tooling or production: Year-1 budget allocates EUR 75k to marketing/sales/operations, but if presale deposits arrive early (Month 3-4 = 2027-01-08 to 2027-02-08), founder may prematurely commit hard-tooling spend (EUR 30k estimate) from the presale liability account or cut marketing short to fund production, violating the gate-sequencing rule and burning option value.
- Untracked overruns in accredited-lab fees and redesign iterations: Lab statement of work caps at EUR 15k, but if design-readiness review (EUR 2-3k estimate) or failed first test (EUR 8-15k re-test estimate) occur, the EUR 20k redesign reserve is consumed. Unclear approval chain for incremental lab spending allows overruns to exceed budgeted EUR 15k without formal decision.
- Double-spending on in-house test rig and accredited lab: Year-1 budget allocates EUR 40k to in-house rig but does not clearly separate capital equipment (one-time EUR 5-10k estimate) from consumables and labor (EUR 30-35k estimate). Risk of funding rig twice if capital vs. operating distinction is blurred, or duplicating measurement capabilities already available through university partner.
- Misallocation of soft-tooling EUR 20k to other design/prototyping uses: Soft tooling allocated EUR 20k is intended for laser-cut and bend fixtures, but may be diverted to rapid-prototyping materials, CAD software, or fabricator trial batches without approval, leaving actual soft tooling underfunded and delaying design iteration.
- Presale-deposit mixing with operational revenue in gate-measurement accounting: Deposits classified as liabilities are held separately but may be inadvertently commingled in monthly cash reconciliation, inflating apparent operating cash flow and triggering premature gate release or false conclusion that gate is met when underlying unit sales and margin are insufficient.
- Unbudgeted spending absorbed into the EUR 75k operations line without tracking: Legal opinion (EUR 2-5k estimate), product-liability insurance premium (not estimated), LCA (EUR 2-5k estimate), and part-time operations (EUR 5-8k estimate Year-1) are assumed funded within the EUR 75k line, but no sub-allocation is defined. Risk of line overrun if insurance costs exceed budget or multiple legal/advisory needs emerge, crowding out presale marketing investment.

## Audit - Procedures

- Monthly cash reconciliation audit (Months 1-12 = 2026-11-08 to 2027-10-08): Review actual spend vs. Year-1 budget allocation monthly. Verify that design/prototyping, lab, soft tooling, production and marketing each track to planned amounts within ±10%. Flag any spend category exceeding plan by >10% and require founder approval for revised allocation. Segregate presale deposits from operating cash and verify deposits are held in earmarked account with zero operating withdrawals.
- Quarterly accredited-lab statement of work and design-readiness review audit (Month 0.5-1.5 = 2026-10-23 to 2026-11-23, Month 4-5 = 2027-02-08 to 2027-03-08): Obtain fixed-price statement of work from chosen EMC lab by Month 1.5 (2026-11-23) and verify cost, timeline (report by Month 5 = 2027-03-08) and standard applicability. At Month 4 (2027-02-08), review lab pre-engagement findings (design-readiness confirmation, estimated attenuation). Post-report (Month 5-6 = 2027-03-08 to 2027-04-08): audit lab report for frequency range tested, attenuation data, any design-revision recommendations and cost/timeline impact.
- Presale deposit and refund audit (Months 1, 3, 6, 9, 12 = 2026-11-08, 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08): Track net presale deposits (gross deposits minus approved refunds) against the EUR 80k tooling gate. Verify refund approvals are documented (reason, customer contact, authorization) and refund rate is <15% cumulatively by Month 8 (2027-06-08). Validate that presale deposits remain in earmarked account and no operating withdrawals occur.
- Hard-tooling commitment gate audit (Month 5-6 = 2027-03-08 to 2027-04-08): Before hard tooling is released, confirm in writing that (a) presale deposits (net of refunds) ≥EUR 80k (proposed threshold), (b) accredited lab pre-test confirms design readiness, (c) in-house rig validation passed twice, and (d) redesign reserve EUR 20k remains uncommitted. Document the gate decision and authorized approver.
- Supplier and fabricator pricing audit (Month 1.5 = 2026-11-23 and Month 6 = 2027-04-08 and 2027-04-08): Lock primary Tallinn fabricator and gasket supplier pricing in signed contracts by Month 1.5 (2026-11-23). Audit pricing at Month 6 (2027-04-08) to verify no cost increases >10% have occurred; if they have, trigger secondary-supplier transition. Verify gasket buffer stock (EUR 7k estimate for 30-day supply) is in place before batch 1 production (Month 6 = 2027-04-08).
- Cash-flow gate measurement and sign-off audit (Month 12 = 2027-10-08, decision Month 12.5 = 2027-10-23): Calculate trailing-quarter operating cash flow (Months 9-12 = 2027-07-08 to 2027-10-08) using delivered-unit revenue only (no deposits), less direct unit costs and recurring opex. Verify threshold test (≥EUR 25k proposed) and document sign-off by founder and external advisor. If result is ambiguous (-5k to +25k estimate), apply tiebreak rule. Audit supporting invoices and payment records from 10-15% of delivered units.

## Audit - Transparency Measures

- Published monthly cash-flow dashboard (Months 1-12 = 2026-11-08 to 2027-10-08, updated within 7 days of month-end): Accessible to founder, external advisor and any presale customers who request it. Show Year-1 budget allocation vs. actuals (design, lab, tooling, production, marketing), presale deposits (gross and refunds), operating cash flow (delivered-unit revenue minus direct costs and opex), and months of runway remaining. Flag any variance >10% from plan.
- Written and published cash-flow gate measurement convention (by Month 0.5 = 2026-10-23): Define positive cash flow as trailing-quarter operating revenue from delivered units only, threshold EUR 25k (proposed), measurement window Months 9-12 (2027-07-08 to 2027-10-08), and tiebreak rule if result is ambiguous. Publish in all presale terms, marketing materials and governance documentation so all stakeholders understand gate logic before deposits are collected.
- Quarterly external advisor review and sign-off (Months 3, 6, 9, 12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08): Retain an external financial advisor (accountant or experienced mentor) to review monthly cash reconciliation quarterly, verify presale deposit accounting and offer written assessment of progress toward cash-flow gate. Advisor co-signs gate result at Month 12.5 (2027-10-23).
- Published accredited-lab statement of work and report excerpt (by Month 1.5 = 2026-11-23 for statement of work; Month 5 = 2027-03-08 for report): Share the lab's fixed-cost statement of work and timeline commitment publicly (on company website or presale landing page). After report is delivered, publish an executive summary (attenuation data, frequency range tested, any design-revision recommendations) so buyers see the evidence underlying product claims.
- Documented presale terms, delivery SLA and refund policy (by Month 1 = 2026-11-08): Publish written presale terms including deposit amount, refund conditions (30-day return window, reason-based approval), delivery lead time (2-3 weeks estimate), and contact escalation procedure. Include scope statement: 'Protects stored spare devices against RF exposure; does not protect active equipment or prevent grid-scale events.' Link all presale materials to this policy so terms are unambiguous.
- Annual compliance and claim-substantiation audit (Month 3 = 2027-01-08 and Month 12 = 2027-10-08 and 2027-10-08): Review all marketing claims and sales materials to verify alignment with measured accredited-lab data. Confirm scope statement and frequency-range disclaimers are published with every sales channel. Document legal opinion findings (applicable EU product rules) and product-liability insurance coverage limits. Report any claim variance to the external advisor for sign-off.

# Internal Governance Bodies

### 1. Project Steering Committee

**Rationale for Inclusion:** Capital-constrained, two-tranche hardware venture with high strategic and financial risk. The EUR 400k Year-1 cap and conditional EUR 350k follow-on create non-negotiable decision gates: tooling release gated on presale deposits and lab validation, and tranche release gated on measured positive cash flow. A Steering Committee provides strategic oversight of the sequencing decisions (Shielding Proof Standard, Year-1 Burn, Presale Validation, Cash-Flow Gate) and ensures evidence-gated spending protects the founder's personal capital. Essential for a solo-funded founder facing irreversible commitments.

**Responsibilities:**

- Approve the cash-flow gate measurement convention and define positive-cash-flow threshold (Month 0.5 = 2026-10-23)
- Approve Year-1 budget allocation across design, lab, tooling, production and marketing; monitor spending vs. plan and approve material changes (>10% variance)
- Gate the hard-tooling release decision: confirm presale deposits ≥ EUR 80k, accredited lab pre-test readiness, and in-house rig validation before tooling is committed (Month 5–6 = 2027-03-08 to 2027-04-08)
- Review and approve any spending above EUR 5k outside the original allocation or any EUR 20k redesign reserve drawdown
- Approve segment-sequencing pivots if presale deposits are prepper-heavy (>70% by Month 3 = 2027-01-08) or total conversion falls below 40% (estimated threshold)
- Measure and approve cash-flow gate result (EUR 25k threshold, proposed) at Month 12.5 (2027-10-23) and recommend tranche release or withheld decision to founder

**Initial Setup Actions:**

- Draft and publish the written cash-flow gate measurement convention (definition, threshold, measurement window, tiebreak rule) by Month 0.5 (2026-10-23)
- Create the monthly Year-1 burn schedule (EUR 400k allocation across design, lab, tooling, production, marketing, reserves) by Month 0.5 (2026-10-23)
- Recruit one external advisor (accountant or experienced mentor) to co-sign gate result and serve as independent second opinion on tranche release
- Establish monthly cash-reconciliation review cadence with founder and advisor
- Document decision-escalation thresholds (e.g., hard-tooling gate logic, spending freeze triggers, pivot decision criteria) in a written governance charter by Month 0.5 (2026-10-23)

**Membership:**

- Founder / project principal
- External financial advisor (accountant or experienced mentor, independent)

**Decision Rights:** Strategic decisions above EUR 5k and all gate decisions (tooling release, spending freeze triggers, tranche measurement, segment pivots). Threshold: Any decision affecting the EUR 400k cap, presale validation, or cash-flow gate outcome. Decisions below EUR 5k (routine supplies, marketing micro-adjustments) are delegated to operations.

**Decision Mechanism:** Consensus preferred; if consensus cannot be reached on the gate result (Month 12.5 = 2027-10-23), founder has final authority (tiebreak) to release tranche or withhold. For operational decisions above EUR 5k, founder proposes and advisor signs off or escalates to full committee within 3 business days. For gate result, written measurement record is prepared by Month 12.5 (2027-10-23) and both founder and advisor sign off, or document dissent.

**Meeting Cadence:** Monthly (typically 1 hour, last week of month). Emergency meetings on request if spending variance exceeds 10%, presale conversion falls below 40% (estimated), or cash balance threatens runway. Special review at Month 5 (2027-03-08) for lab-report assessment and tooling gate decision.

**Typical Agenda Items:**

- Actual vs. budgeted spending (design, lab, tooling, production, marketing) and variance explanation
- Presale deposit velocity, refund rate, and segment mix (prepper, infrastructure, privacy); pivot triggers assessed
- Lab status and pre-test readiness (Month 4–5 = 2027-02-08 to 2027-03-08)
- Hard-tooling gate decision criteria confirmed (deposits ≥ EUR 80k, lab pre-test OK, in-house rig passed twice) (Month 5–6 = 2027-03-08 to 2027-04-08)
- Quarterly cash-flow projection and months of runway remaining
- Any unbudgeted items, overruns, or requests to reallocate reserve funds

**Escalation Path:** All unresolved strategic issues (gate disputes, major budget changes, segment pivots, tranche decisions) escalate to founder with advisor concurrence. If founder and advisor cannot agree on gate result, the dissent is documented and founder retains decision authority; the decision is recorded in writing with both parties' signatures. No escalation beyond this structure exists (no board, no external funder); the founder is the ultimate decision-maker within the framework.
### 2. Design and Certification Working Group

**Rationale for Inclusion:** Shielding effectiveness and EMC validation are the core technical risks. The plan gates hard tooling on accredited lab pre-test confirmation and in-house rig validation, meaning design iteration and certification readiness directly drive the tooling release (Month 5–6 = 2027-03-08 to 2027-04-08). This group oversees the critical path: prototype design, in-house shielding rig (two independent cycles), accredited lab engagement, and any design changes forced by lab results. It also manages the EUR 20k redesign reserve and ensures claim-to-evidence alignment for compliance.

**Responsibilities:**

- Coordinate prototype design and RF shielding analysis with the independent EMC consultancy (EUR 20–25k, milestone-based)
- Oversee the in-house shielding test rig setup, validation methodology, and execution of two independent seam cycles by Month 3 (2027-01-08)
- Manage the accredited EMC laboratory engagement: select lab, obtain fixed-cost statement of work by Month 1.5 (2026-11-23), conduct design-readiness review (Month 4 = 2027-02-08), submit samples, and receive report (Month 5 = 2027-03-08)
- Assess lab pre-test results for design readiness; if readiness is not confirmed, escalate redesign scope and cost impact to Steering Committee
- If accredited lab results fall short of claims or show design issues, manage the redesign trade-off: scope (claim narrowing) vs. rework (cost and timeline impact) vs. retry
- Ensure all marketing claims and scope statements are aligned with measured lab data; publish the accredited lab report with every unit sold
- Track compliance with the single-SKU rigid-metal enclosure architecture and flag any design changes that require re-qualification

**Initial Setup Actions:**

- Lock the EMC consultancy milestone agreement with fixed deliverables, cost (EUR 20–25k cap) and timeline (prototype review Month 2 = 2026-12-08, lab coordination Month 4 = 2027-02-08) by Month 0.5 (2026-10-23)
- Finalize the university lab co-development partnership with written agreement covering measurement access, rig capital (EUR 5–10k estimate), consumables budget, timeline and IP/publication rights by Month 0.5 (2026-10-23)
- If university partnership is not confirmed by Month 1.5 (2026-11-23), hire a part-time RF engineer (0.5 FTE, EUR 25k Year-1 estimate) immediately to preserve design timeline
- Conduct pre-engagement consultations with 2–3 accredited EMC labs (Germany, Sweden, Netherlands, or Estonia) to confirm applicable standard, frequency range, test methodology and cost by Month 0.5 (2026-10-23)
- Select the accredited lab and obtain fixed-cost statement of work (cost locked, report delivery date locked) by Month 1.5 (2026-11-23)
- Define design-readiness criteria and in-house rig validation pass/fail rules by Month 1 (2026-11-08)

**Membership:**

- Founder (project lead, design decisions)
- Independent EMC consultancy (RF design and lab coordination, milestone-based)
- Estonian university lab partner (in-house rig and measurement support, co-development)
- Accredited EMC laboratory (external, test execution and report)
- Part-time RF engineer if university partnership fails (backup, 0.5 FTE from Month 1.5 = 2026-11-23 onward)

**Decision Rights:** Technical design decisions within scope (seam design, gasket materials, internal fit, frequency range claims, scope statement) up to EUR 5k per change. Lab selection and statement-of-work approval (all terms, cost, timeline). Any design change or redesign scope that impacts cost >EUR 1k or timeline >2 weeks escalates to Steering Committee. Claim-to-evidence alignment (marketing scope statement and frequency-band disclaimers) is binding; no claim is published without this group's sign-off.

**Decision Mechanism:** Consensus among founder, consultancy and lab (if lab is engaged). If consultancy and founder disagree on design feasibility or cost, the lab pre-engagement review (Month 4 = 2027-02-08) is the tiebreaker: if the lab confirms readiness, design proceeds; if lab raises concerns, founder and consultancy jointly assess rework scope or claim narrowing. Any decision to increase the redesign reserve or reallocate budget escalates to Steering Committee.

**Meeting Cadence:** Bi-weekly (60–90 minutes, Mondays 10:00 AM or by agreement). Monthly deep-dive reviews at Month 2, 4, and 5 (2026-12-08, 2027-02-08, 2027-03-08) for prototype, lab pre-test and report assessment. Ad-hoc emergency meetings if design issues emerge that threaten Month 5 (2027-03-08) report deadline.

**Typical Agenda Items:**

- Prototype design status and RF analysis progress (consultancy)
- In-house rig setup and validation results (two independent cycles) (university lab)
- Accredited lab pre-engagement status: standard selection, frequency range, cost and timeline (lab liaison)
- Design-readiness assessment: does design meet lab expectations? Any red flags? (Month 4–5 = 2027-02-08 to 2027-03-08)
- Lab report summary: attenuation data, frequency range tested, any design-revision recommendations, re-test cost/timeline if needed (Month 5 = 2027-03-08)
- Claim-to-evidence review: are all marketing claims and scope statements aligned with measured lab data?
- Redesign scope and cost impact if lab results require changes

**Escalation Path:** Any design change or redesign scope that impacts EUR 400k budget or tooling-gate timeline (Month 5–6 = 2027-03-08 to 2027-04-08) escalates to Steering Committee with full cost/timeline impact documentation. If lab recommends a costlier standard (MIL-STD-285 vs. IEEE 299.1 estimate) or design revision requiring re-test, escalate with two scenarios: (a) proceed with costlier path and fund from EUR 20k reserve (or 30k if redesign reserve is raised) or seek timeline extension, (b) narrow claims and avoid re-test. Steering Committee approves which path to take within 3 business days.
### 3. Compliance and Liability Committee

**Rationale for Inclusion:** A passive Faraday enclosure sold against rare, extreme threats (solar storm, electromagnetic pulse) creates claim-substantiation and consumer-protection exposure. The plan limits claims to measured attenuation and includes scope statements (protects stored spare devices only), but applicability of EU product-safety rules, EMC Directive, and consumer-law liability are not verified. This committee ensures (1) legal risk is identified and managed (legal opinion by Month 1 = 2026-11-08), (2) product claims align with measured evidence (monthly compliance audit), (3) product-liability insurance is in place and covers Faraday-specific risks, and (4) regulatory requirements are tracked and met.

**Responsibilities:**

- Commission and review a legal opinion on applicable EU product-safety rules (General Product Safety Directive, EMC Directive, consumer-protection rules) by Month 1 (2026-11-08) and document findings (EUR 2–5k estimate)
- Define the scope statement (protects stored spare devices against RF exposure; does not protect active equipment or prevent grid-scale events) and ensure it appears in all marketing, presale terms and product materials
- Lock product-liability insurance coverage (EUR 250–500k estimated limits) by Month 2.5 (2026-12-23), confirm Faraday-enclosure claims are insurable, and document coverage limits and exclusions
- Conduct monthly claim-substantiation audit: verify all marketing claims (attenuation values, frequency band, protective scope) are supported by accredited lab data or measured evidence and that frequency-range disclaimers are published
- If EU directive applicability requires CE marking or notified-body assessment, document the requirement and cost/timeline impact (EUR 10–30k estimate, 8–12 weeks estimate) by Month 2 (2026-12-08) and escalate to Steering Committee
- Maintain a compliance checklist (claim limiting, scope statement, insurance status, lab report publication, presale terms) and flag any drift in compliance at each monthly review
- Establish a claim-revision protocol: if a product fails or if new regulatory guidance is issued, assess whether claims or scope statement must be revised; escalate any required revision to Steering Committee and Design & Certification group

**Initial Setup Actions:**

- Identify legal counsel with expertise in EU product-safety and consumer-protection law (prefer local Estonian counsel or EU generalist) by Month 0.5 (2026-10-23)
- Commission legal opinion on General Product Safety Directive, EMC Directive applicability, and consumer-protection duties by Month 1 (2026-11-08); budget EUR 2–5k estimate
- Draft the scope statement ('Protects stored spare devices against RF exposure; does not protect active equipment or prevent grid-scale events') and publish in all presale terms and marketing materials by Month 1 (2026-11-08)
- Identify and engage product-liability insurers who will cover Faraday-enclosure or RF-shielding products; lock coverage terms (limits, exclusions, premium) by Month 2.5 (2026-12-23)
- Create a compliance checklist (claim limiting, scope statement, lab report, insurance status, presale terms, warranty limits) and assign a reviewer (founder or part-time operations person) to audit monthly
- Publish the accredited lab report executive summary (attenuation data, frequency band tested, scope of testing) publicly with every unit sold by Month 5 (2027-03-08) onward

**Membership:**

- Founder (compliance owner, decision-maker)
- External legal counsel (EU product law expertise, for opinion and advice)
- Product-liability insurer (coverage assessment and terms)
- Design & Certification group liaison (to align lab report and claims)

**Decision Rights:** Legal opinions on regulatory applicability are binding: if the EMC Directive applies or CE marking is required, the cost and timeline are escalated to Steering Committee as a mandatory gate decision. Scope statement and claim limitations are binding: no marketing material is published without Compliance Committee sign-off. Product-liability insurance terms (limits, exclusions) are approved and locked by Month 2.5 (2026-12-23). Monthly compliance audits are advisory: if drift is detected (e.g., a salesperson mentions protection during grid-scale events), the committee flags it and founder must correct it within 3 business days or escalate to Steering Committee.

**Decision Mechanism:** Consensus between founder and legal counsel on legal-opinion findings and implications. If legal counsel and founder disagree on regulatory requirement interpretation, a second legal opinion is obtained (cost borne by Year-1 budget) and Steering Committee is notified. Insurance terms are agreed between founder and insurer; if insurer requires claim narrowing or exclusions, Steering Committee approves the trade-off (narrower claims vs. lower premium). Compliance audits are reviewed by founder and flagged findings are corrected or escalated within 3 business days.

**Meeting Cadence:** Monthly (45–60 minutes, tied to Steering Committee calendar). Special reviews at Month 1 (2026-11-08) for legal-opinion receipt, Month 2.5 (2026-12-23) for insurance lock-in, and Month 5 (2027-03-08) for lab-report and claim-alignment review.

**Typical Agenda Items:**

- Legal opinion status and findings (Month 1 = 2026-11-08)
- Insurance quotes and coverage terms; lock-in decision (Month 2–3 = 2026-12-08 to 2027-01-08)
- Compliance checklist review: claim limiting, scope statement, warranty terms, presale SLA
- Monthly claim audit: sample presale marketing, website, email communications; verify scope statement and frequency-band disclaimers are present
- Lab report alignment with claims: does measured attenuation support all marketing claims? Any narrowing needed?
- Any regulatory guidance updates or customer complaints received; assess claim-revision risk
- Post-gate: customer returns, warranty claims, or RF-event exposure and lessons learned

**Escalation Path:** If legal counsel advises that the EMC Directive applies and CE marking is required, or if product-liability insurer declines coverage or imposes significant exclusions, escalate immediately to Steering Committee with full cost and timeline impact (EUR 10–30k estimate, 8–12 weeks estimate for CE work). If a customer complaint or product failure occurs, escalate to Steering Committee and Design & Certification group to assess claim-revision risk and reputational impact. If a regulatory agency contacts the company, escalate to legal counsel and Steering Committee immediately.
### 4. Presale and Revenue Validation Committee

**Rationale for Inclusion:** The cash-flow gate depends on delivered-unit revenue of EUR 25k quarterly (proposed threshold) by Month 12 (2027-10-08). Presale-deposit velocity, segment mix, conversion rate and delivery lead times directly determine whether this gate is met. The plan assumes parallel presale campaigns across preppers, infrastructure buyers and privacy/forensics segments, with data-driven pivots if prepper mix exceeds 70% (estimated) by Month 3 (2027-01-08). This committee owns presale validation: deposit tracking, segment analysis, demand-pivot triggers, and delivery promise management. It bridges presale commitment and delivered-unit revenue.

**Responsibilities:**

- Design and launch parallel presale campaigns targeting preppers (40–50% estimated deposit rate), infrastructure buyers (30–40% estimated rate) and privacy/forensics (35–45% estimated rate) by Month 1 (2026-11-08)
- Track net presale deposits (gross deposits minus refunds) weekly; maintain a separate earmarked account and ensure deposits are never used for operating spending
- Monitor deposit velocity, refund rate, average order value and segment mix; identify which segment is dominating deposits
- Assess demand-pivot triggers monthly: if prepper deposits exceed 70% of total by Month 3 (2027-01-08), reallocate EUR 10–15k marketing spend from prepper to infrastructure/privacy channels
- Establish fast-track pilot agreements with 1–2 infrastructure buyers by Month 3 (2027-01-08) (pilot units at cost plus 20% estimate, delivery Month 5 = 2027-03-08) to generate in-time reference and revenue
- Gate hard-tooling release: confirm net presale deposits ≥ EUR 80k (proposed threshold) and in-house rig validation complete by Month 5–6 (2027-03-08 to 2027-04-08)
- Manage presale delivery promises: set presale cutoff date at Month 8 (2027-06-08); all orders before cutoff must be delivered by Month 12 (2027-10-08) to count toward cash-flow gate
- Track delivered-unit revenue (invoiced and paid) separately from presale deposits; monthly cash-flow dashboard shows operational revenue vs. presale liability
- If presale conversion falls below 40% (estimated) by Month 3 (2027-01-08) or average order value falls below EUR 50 (estimated), escalate pivot or stop-rule recommendation to Steering Committee

**Initial Setup Actions:**

- Identify prepper forums, online communities and mailing lists; draft prepper-focused presale campaign messaging and landing page by Month 0.5 (2026-10-23)
- Identify critical-infrastructure and emergency-planning buyer contacts (government agencies, utilities, facility operators); draft infrastructure-focused messaging and pilot proposal template by Month 0.5 (2026-10-23)
- Identify digital-forensics, privacy-advocacy and corporate IT security communities; draft multi-use RF-isolation messaging by Month 0.5 (2026-10-23)
- Set up presale deposit account (earmarked, separate from operating cash) and document deposit ring-fencing policy and refund-approval workflow by Month 0.5 (2026-10-23)
- Launch all three presale campaigns by Month 1 (2026-11-08); track deposits, refunds and segment mix in a weekly dashboard
- Develop presale terms document and delivery SLA (build-to-order, 2–3 week lead time, 30-day refund window) by Month 1 (2026-11-08); publish in all presale materials
- Set the hard-tooling gate criteria in writing by Month 1 (2026-11-08): 'Hard tooling releases when net presale deposits ≥ EUR 80k AND accredited lab pre-test confirms design readiness AND in-house rig validation passes twice'

**Membership:**

- Founder (presale strategy and buyer relationship lead)
- Part-time operations person (presale platform and deposit tracking, added Month 1 = 2026-11-08 or earlier if volume warrants)
- External advisor liaison (to monitor segment mix and pivot triggers)

**Decision Rights:** Presale campaign messaging and buyer outreach are founder-approved; no campaign material is published without founder sign-off. Presale terms (deposit refund policy, delivery lead time, scope statements) are locked by Month 1 (2026-11-08) and binding. Hard-tooling gate decision (deposits ≥ EUR 80k confirmation) is approved by Steering Committee based on this group's weekly dashboard and Month 5–6 (2027-03-08 to 2027-04-08) gate-readiness assessment. Any decision to pivot marketing spend (e.g., shift EUR 10–15k from prepper to infrastructure channels) is approved by Steering Committee within 3 business days of the Month 3 (2027-01-08) trigger assessment. Presale delivery cutoff date (Month 8 = 2027-06-08) is fixed by Month 2 (2026-12-08).

**Decision Mechanism:** Consensus among founder and operations/advisor on weekly presale dashboard findings and weekly pivot recommendations. If founder and advisor disagree on whether the 70% prepper threshold has been crossed (Month 3 = 2027-01-08), the data (deposit count and value by segment) is reviewed together and a decision is made within 3 business days; if still unresolved, Steering Committee is asked to adjudicate. Hard-tooling gate confirmation (deposits ≥ EUR 80k) is documented in writing with founder and advisor sign-off by Month 5.5 (2027-03-23).

**Meeting Cadence:** Weekly (30–45 minutes, Mondays 9:00 AM or by agreement) for presale dashboard review. Monthly deep-dive reviews (60 minutes, tied to Steering Committee calendar) at Months 1, 3, 6, 9, 12 (2026-11-08, 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08). Emergency meeting if presale conversion rate drops to <30% (estimated) in any given week or refund rate spikes above 20% (estimated) in a month.

**Typical Agenda Items:**

- Weekly presale deposits and refunds: gross, net, and segment mix (prepper, infrastructure, privacy/forensics)
- Deposit velocity trend and extrapolation to the EUR 80k gate target by Month 6 (2027-04-08)
- Average order value and revenue impact by segment; margin contribution estimate
- Refund requests: reasons (fit, delivery time, changed mind, news cycle) and approval/denial decisions
- Marketing campaign performance by segment: cost per deposit, conversion rate, messaging resonance
- Segment pivot assessment (Month 3 = 2027-01-08): is prepper mix > 70%? Recommend reallocation?
- Infrastructure pilot status: agreements signed? Delivery date confirmed? Reference credibility?
- Presale delivery queue and lead-time forecast; identify any risk of missing the Month 8 (2027-06-08) cutoff or Month 12 (2027-10-08) gate measurement
- Cash-flow gate projection: based on current deposits and delivery pace, will EUR 25k quarterly threshold be met by Month 12 (2027-10-08)?

**Escalation Path:** If presale deposits fall below EUR 80k by Month 6 (2027-04-08), escalate to Steering Committee with a stop-rule recommendation: either extend presale to Month 8 (2027-06-08) and delay hard tooling, or pivot channel/messaging urgently, or (if still below EUR 80k at Month 8 = 2027-06-08) withhold hard tooling and prepare for wind-down or founder capital contribution. If presale conversion falls below 40% (estimated) by Month 3 (2027-01-08) or average order value falls below EUR 50 (estimated), escalate to Steering Committee with contingency options: reposition narrative, shift channels, or halt presale marketing. If refund rate exceeds 20% (estimated) by Month 6 (2027-04-08), escalate delivery or messaging issues to Steering Committee and Design & Certification group. If infrastructure pilots stall past Month 6 (2027-04-08), escalate to founder with recommendation to widen multi-use RF-isolation narrative (privacy, travel, corporate security) in marketing to accelerate higher-value segments.
### 5. Production and Supply Chain Committee

**Rationale for Inclusion:** The plan commits to hard tooling only after presale deposits reach EUR 80k (proposed threshold) and design is validated by accredited lab (Month 5–6 = 2027-03-08 to 2027-04-08). Once tooling is released, production execution is time-critical: first batch (800 units) must be delivered by Months 7–8 (2027-05-08 to 2027-06-08) to support fulfillment before the cash-flow gate measurement window (Months 9–12 = 2027-07-08 to 2027-10-08). This committee manages the Tallinn production model, supplier coordination, soft and hard tooling, inventory, quality control and freight logistics. It also owns supply-chain risk mitigation (secondary fabricator, gasket buffer stock) and cost management within the EUR 160k production-line budget.

**Responsibilities:**

- Identify and pre-qualify primary Tallinn precision-metal fabricator and secondary backup fabricator by Month 1 (2026-11-08); conduct trial laser-cut batches to confirm quality
- Lock primary fabricator pricing and capacity agreement (soft tooling, hard tooling, and production batches) with signed contract specifying price caps, delivery dates and capacity reservation by Month 1.5 (2026-11-23)
- Identify and qualify conductive-gasket material suppliers (primary and backup); hold 30-day buffer stock (EUR 5–10k estimate) before production release
- Manage hard-tooling release: confirm presale deposits ≥ EUR 80k and accredited lab pre-test OK by Month 5–6 (2027-03-08 to 2027-04-08); submit hard-tooling order and lock commitment by Month 6 (2027-04-08)
- Manage first production batch (800 units): schedule production runs to meet delivery dates (Months 7–8 = 2027-05-08 to 2027-06-08) for presale fulfillment
- Coordinate with presale fulfillment: ensure production batch 1 (800 units) is available for delivery to customers by Month 7 (2027-05-08) and follow-on batches (700 units) by Month 9 (2027-07-08)
- Manage outbound freight logistics: negotiate volume-discount rates with DHL, UPS or local carrier and lock pricing for Year-1 by Month 1.5 (2026-11-23); track landed cost (EUR 8–15 per unit estimate) and freight variance
- Monitor actual unit cost (EUR 70 estimate) vs. budget (EUR 105k for 1,500 units); flag cost inflation and adjust order sizes if margins compress
- Conduct monthly supplier and fabricator reviews: lead times, quality (defect rates), price stability. If primary fabricator raises prices >10% or signals capacity loss, trigger secondary-supplier transition immediately
- Quality control: inspect initial production batches for seam integrity, gasket contact, fit and shielding margin. Flag any quality issues that may impact lab claims or customer satisfaction

**Initial Setup Actions:**

- Identify and contact 2–3 Tallinn precision-metal fabricators by Month 0.5 (2026-10-23); request quotes for soft tooling (laser cut, bend) and hard tooling (progressive die or equivalent)
- Order trial laser-cut samples from primary and secondary fabricators by Month 0.5 (2026-10-23); assess fit, tolerance and finish by Month 1 (2026-11-08)
- Lock primary fabricator soft-tooling and hard-tooling pricing in signed agreement by Month 1.5 (2026-11-23), specifying price caps, delivery windows and capacity reservation
- Identify conductive-gasket suppliers (primary and backup, qualified for RF shielding) by Month 0.5 (2026-10-23); order samples and confirm material specs, lead times and pricing by Month 1 (2026-11-08)
- Pre-qualify secondary Tallinn fabricator with a signed backup agreement by Month 1.5 (2026-11-23) in case primary supplier fails
- Negotiate freight pricing with DHL, UPS and local carriers; lock volume rates by Month 1.5 (2026-11-23)
- Create a production schedule and quality-control checklist by Month 2 (2026-12-08) for soft-tooling trials, hard-tooling release and batch production

**Membership:**

- Founder (supplier relationships, production decisions, quality sign-off)
- Primary Tallinn fabricator (manufacturing partner)
- Secondary backup fabricator (contingency)
- Gasket material suppliers (primary and backup)
- Freight logistics partner (DHL, UPS, or local carrier)
- Part-time operations person (supply-chain tracking, quality inspections, inventory management, added Month 1 = 2026-11-08 or earlier)

**Decision Rights:** Hard-tooling release is approved by Steering Committee (gates on presale deposits and lab validation); once approved, production schedule is founder-approved and binding on fabricators (signed purchase order). Supplier pricing and terms (cost caps, delivery dates, capacity) are locked by Month 1.5 (2026-11-23); any price increase >10% (estimated) triggers a secondary-supplier assessment by this committee and a decision recommendation to Steering Committee. Quality-control decisions (accept/reject batches, investigate defects) are made by founder and operations person; any defect that impacts lab claims or customer fit escalates to Design & Certification group. Production-batch delays >2 weeks (estimated) that threaten presale delivery dates escalate to Steering Committee.

**Decision Mechanism:** Consensus among founder, primary fabricator and operations on production schedule and quality standards. If primary fabricator signals a price increase or capacity loss, founder and operations assess secondary-supplier readiness and recommend transition timing to Steering Committee within 3 business days. If a batch quality issue emerges, founder and operations investigate with the fabricator and decide on remediation (rework, scrap, or design change); major rework (>5% of batch) escalates to Design & Certification group and Steering Committee.

**Meeting Cadence:** Bi-weekly (45–60 minutes, Tuesdays 10:00 AM or by agreement) for supplier status, production progress and quality reviews. Monthly deep-dive reviews (90 minutes, tied to Steering Committee calendar) at Months 2, 4, 6, 8, 10, 12 (2026-12-08, 2027-02-08, 2027-04-08, 2027-06-08, 2027-08-08, 2027-10-08). Emergency meeting if a supplier fails to deliver on schedule or if quality defects emerge.

**Typical Agenda Items:**

- Primary fabricator status: soft-tooling progress, hard-tooling design review, production schedule (Month 4–6 = 2027-02-08 to 2027-04-08)
- Hard-tooling gate readiness (Month 5–6 = 2027-03-08 to 2027-04-08): presale deposits confirmed, lab pre-test OK? Ready to release tooling?
- Production batch schedule: Batch 1 (800 units) delivery date (Months 7–8 = 2027-05-08 to 2027-06-08), follow-on batches (Months 8–12 = 2027-06-08 to 2027-10-08)
- Actual unit cost vs. budget (EUR 70 estimate); any cost inflation identified?
- Gasket material supply: sufficient buffer stock in place? Lead time stable?
- Freight logistics: volume rates locked? Landed cost on track?
- Quality control: initial batch inspection, defect findings, corrective actions
- Secondary fabricator status: backup agreement in place? Capability confirmed?
- Supply-chain risk register: any supplier concentration, lead-time or capacity risks emerging?

**Escalation Path:** Any supplier price increase >10% (estimated) or capacity loss signals triggers an urgent secondary-supplier assessment and transition recommendation to Steering Committee within 3 business days. Production-batch delays >2 weeks (estimated) that threaten delivery dates (Months 7–8 = 2027-05-08 to 2027-06-08 for Batch 1) escalate to Steering Committee with contingency options (expedite fees, secondary fabricator, delivery timeline adjustment). Any quality defect affecting >5% of a batch or any defect impacting lab claims escalates to Design & Certification group and Steering Committee with impact assessment and remediation cost. If hard-tooling costs exceed EUR 30k (estimate, budgeted EUR 30k) by >20% (EUR 6k overrun), escalate to Steering Committee with a decision on whether to absorb overrun from redesign reserve or reallocate from other lines.
### 6. Financial Governance and Gate Measurement Committee

**Rationale for Inclusion:** The EUR 350k follow-on tranche is conditional on positive cash flow (EUR 25k quarterly operating surplus, proposed threshold, measured end of Year-1 Month 12 = 2027-10-08). This gate is non-negotiable; it protects the founder's personal capital and enforces evidence-gated spending discipline. This committee owns cash-flow accounting, monthly cash reconciliation, gate-measurement methodology, and the final sign-off decision at Month 12.5 (2027-10-23). It also monitors burn rate vs. budget, presale-deposit liability segregation, and any unbudgeted spending that threatens the EUR 400k cap or gate outcome.

**Responsibilities:**

- Maintain the written cash-flow gate measurement convention (definition: operating revenue from delivered units only, excluding presale deposits; threshold: EUR 25k quarterly surplus; measurement window: Months 9–12 = 2027-07-08 to 2027-10-08; tiebreak rule if ambiguous) agreed at Month 0.5 (2026-10-23)
- Track monthly actual spending vs. Year-1 budget allocation (EUR 400k across design, lab, tooling, production, marketing, reserves); report variance monthly and flag any category exceeding ±10%
- Segregate presale deposits as liabilities in a separate earmarked account; ensure zero operating withdrawals from deposit account and all refunds are documented
- Calculate and publish monthly cash-flow dashboard: Year-1 budget allocation vs. actuals, presale deposits (gross and refunds), operating revenue (delivered units invoiced and paid minus direct costs and recurring opex), and months of runway remaining
- Measure trailing-quarter operating cash flow (Months 9–12 = 2027-07-08 to 2027-10-08) using delivered-unit revenue only, subtract direct unit costs (EUR 82 per unit estimate: EUR 70 cost plus EUR 12 freight) and recurring opex (EUR 20k per quarter estimate), and calculate surplus
- At Month 12 (2027-10-08), document the gate result in writing: revenue, costs, opex, and calculated surplus (or deficit). If result is ambiguous (-EUR 5k to +EUR 25k estimate), apply the tiebreak rule (founder may extend 90 days and re-measure, or founder retains discretion)
- Obtain sign-off from founder and external advisor by Month 12.5 (2027-10-23) on gate result and tranche release recommendation
- If gate is met (surplus ≥ EUR 25k), recommend release of EUR 350k follow-on to founder. If gate is not met (surplus < EUR 25k), recommend withholding and document decision rationale

**Initial Setup Actions:**

- Draft and publish the written cash-flow gate measurement convention by Month 0.5 (2026-10-23), including: definition of operating cash flow (delivered-unit revenue only, no presale deposits), threshold (EUR 25k proposed quarterly surplus), measurement window (Months 9–12 = 2027-07-08 to 2027-10-08), and tiebreak rule (founder discretion if -EUR 5k to +EUR 25k estimate)
- Create the monthly Year-1 burn schedule (EUR 400k allocation: design/prototyping/EMC consultancy EUR 70k, in-house rig EUR 40k, accredited lab EUR 15k, soft tooling EUR 20k, production line EUR 160k, marketing/sales/operations EUR 75k, redesign reserve EUR 20k) by Month 0.5 (2026-10-23)
- Set up separate earmarked presale-deposit account (not commingled with operational cash); document ring-fencing policy and refund-approval workflow by Month 0.5 (2026-10-23)
- Create monthly cash-reconciliation template showing: budget allocation vs. actuals (by category), presale deposits (gross, refunds, net), delivered-unit revenue (units, price, gross), direct costs and opex, operating cash flow, and months of runway by Month 1 (2026-11-08)
- Recruit external financial advisor (accountant or experienced mentor) to review monthly reconciliation quarterly (Months 3, 6, 9, 12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08) and co-sign gate result at Month 12.5 (2027-10-23) by Month 0.5 (2026-10-23)
- Define unit cost and margin assumptions for gate calculation: EUR 70 per unit (estimate), EUR 12 freight (estimate), EUR 149 list price (estimate), contribution EUR 67 per unit (estimate), recurring opex EUR 20k per quarter (estimate) by Month 0.5 (2026-10-23)

**Membership:**

- Founder (cash-flow owner, tranche decision authority)
- External financial advisor (accountant or experienced mentor, independent, gate co-sign authority)
- Part-time operations/finance person (monthly cash reconciliation, invoice tracking, deposit accounting, added Month 1 = 2026-11-08 or earlier)

**Decision Rights:** The cash-flow gate measurement convention is locked by Month 0.5 (2026-10-23) and binding; it cannot be changed after launch. Monthly budget variance reporting (category overage >10%) is flagged and requires founder approval for any reallocation. Presale-deposit accounting (segregation, refund approvals, liability classification) is fixed and audited monthly. The gate result (EUR 25k threshold calculation) is determined mechanically on delivered-unit revenue by Month 12 (2027-10-08); if result is unambiguous (clearly ≥EUR 25k or clearly <EUR 25k), founder and advisor sign off within 3 business days. If result is ambiguous (-EUR 5k to +EUR 25k estimate), the tiebreak rule applies: founder retains discretion to extend runway 90 days and re-measure, or founder decides tranche release based on advisor guidance.

**Decision Mechanism:** Founder and external advisor jointly review monthly cash reconciliation; any variance >10% in a budget category is discussed and founder approves reallocation or spending freeze within 3 business days. Presale-deposit accounting is audited monthly by operations/finance person and reviewed by advisor quarterly; if drift is detected (e.g., operational spending from deposit account), it is flagged immediately and corrected. Gate result is calculated independently by operations/finance person and reviewed by both founder and advisor by Month 12 (2027-10-08); calculation is documented with supporting invoices and payment records from 10–15% sample of delivered units. If founder and advisor cannot agree on gate result interpretation (e.g., whether a pending invoice should be counted as 'paid'), the calculation is escalated to the external financial advisor for tiebreak within 3 business days of Month 12 (2027-10-08).

**Meeting Cadence:** Monthly (60 minutes, last week of month, within 7 days of month-end) for cash reconciliation review. Quarterly (90 minutes, tied to Steering Committee calendar) at Months 3, 6, 9, 12 (2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08) for deep-dive variance analysis and advisor sign-off on progress toward gate. Special gate-measurement meeting at Month 12.5 (2027-10-23) for final result sign-off and tranche decision.

**Typical Agenda Items:**

- Monthly budget allocation vs. actuals: design, lab, tooling, production, marketing spend and variance explanation
- Presale deposits: gross received, refunds approved and paid, net deposits held
- Delivered units: count, invoiced, paid (sample audit of 10–15% of receipts to confirm cash payment)
- Quarterly cash-flow calculation: delivered-unit revenue, less direct costs (EUR 82 per unit estimate), less recurring opex (EUR 20k per quarter estimate), equals operating surplus
- Months of runway: based on actual burn rate vs. budget, how many months of cash remains if spending continues at current pace?
- Any unbudgeted spending, overruns, or contingency draws (redesign reserve, contingency); impact on EUR 400k cap
- Presale deposit liability: verified in separate account? Zero operating withdrawals? Refund policy complied with?
- Gate projection: based on Year-1 performance, will the EUR 25k quarterly surplus threshold be met by Month 12 (2027-10-08)?
- At Month 12.5 (2027-10-23): gate result sign-off (delivered units, costs, opex, surplus calculation) and tranche release recommendation

**Escalation Path:** Any budget category exceeding plan by >10% (estimated) or any unplanned spending >EUR 5k is flagged and escalated to Steering Committee for approval of reallocation or spending freeze within 3 business days. If actual cash burn is running >10% above Year-1 budget by Month 6 (2027-04-08), a spending-freeze review is triggered and Steering Committee approves cuts or deferral of presale marketing or operations spend to stay within the EUR 400k cap. If presale deposits are misused (operational spending from deposit account detected), the issue is escalated immediately to founder for correction and Steering Committee is notified. If gate-measurement result falls below EUR 25k by Month 12 (2027-10-08), founder and advisor assess the root cause (insufficient delivered-unit volume, higher-than-expected refunds, cost inflation) and decide whether to pursue the 90-day extension (tiebreak rule) or accept tranche withheld. If EUR 400k Year-1 cap is exceeded by Month 11 (2027-09-08), an emergency spending freeze is implemented and Steering Committee is convened within 48 hours to authorize additional founder capital contribution or accept reduced headcount/activities.

# Governance Implementation Plan

### 1. Founder establishes the Carrington Event Prep project governance framework by drafting a written governance charter defining the five internal governance bodies, their roles, decision rights, meeting cadence, and escalation paths. Founder also drafts the cash-flow gate measurement convention (definition: operating revenue from delivered units only, excluding presale deposits; threshold: EUR 25k quarterly surplus; measurement window: Months 9–12 = 2027-07-08 to 2027-10-08) and the monthly Year-1 burn schedule (EUR 400k allocation across design, lab, soft tooling, production, and marketing). Both documents are circulated for advisor review.

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- Written Governance Charter (draft, defining all five bodies)
- Cash-Flow Gate Measurement Convention (written definition, threshold, measurement window, tiebreak rule)
- Monthly Year-1 Burn Schedule (EUR 400k allocation by category)

**Dependencies:**

- Project start and founder commitment
- Decision on five governance bodies (already defined in project inputs)

### 2. Founder identifies and recruits one external financial advisor (accountant or experienced mentor) to serve as an independent co-signatory on the cash-flow gate result at Month 12.5 (2027-10-23) and to review monthly cash reconciliation quarterly. Advisor is briefed on the project scope, budget cap, gate logic, and their role in governance oversight. A written advisory engagement letter is signed, outlining advisor responsibilities, meeting schedule, and compensation (if any).

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- External Advisor Identified and Confirmed (name, expertise, availability)
- Signed Advisory Engagement Letter (roles, responsibilities, meeting cadence, compensation)
- Advisor Briefing Complete (project overview, governance framework, gate logic)

**Dependencies:**

- Governance charter and gate convention drafted
- Advisor availability and willingness confirmed

### 3. Founder publishes the written cash-flow gate measurement convention and governance charter in all project materials (presale terms, website, investor/stakeholder communications) so that all buyers and stakeholders understand the gate logic and tranche-release criteria upfront. Founder also finalizes and publishes the presale terms document, including refund policy (maximum 30-day window, refund cap 15% of deposits by Month 8 = 2027-06-08 as a pivot trigger), delivery SLA (build-to-order, 2–3 week lead time), and scope statement (protects stored spare devices only).

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Published Cash-Flow Gate Convention (in presale materials and website)
- Published Governance Charter (summary version for stakeholders)
- Finalized Presale Terms Document (refund policy, SLA, scope statement, accepted payment methods)
- Presale Platform Ready (deposits accepted through separate earmarked account)

**Dependencies:**

- Cash-flow gate convention and charter approved by founder and advisor
- Accredited lab selection and legal opinion in progress (see parallel steps)

### 4. Founder contacts 2–3 accredited EMC laboratories (Germany, Sweden, Netherlands, or Estonia) for no-cost pre-engagement consultations. Founder documents each lab's recommendation for the applicable standard (proposed IEEE 299.1, not verified), frequency range, test methodology, estimated cost (target: EUR 15k, locked), timeline (target: report by Month 5 = 2027-03-08), and design-readiness review scope (EUR 2–3k, estimate). Founder compares quotes and selects the lab best aligned with cost predictability and timeline.

**Responsible Body/Role:** Founder / Project Principal (with EMC Consultancy support from Month 1 = 2026-11-08 onward)

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Lab Pre-Engagement Consultation Summaries (3 labs, standard recommendations, cost estimates, timelines)
- Lab Selection Recommendation (based on cost, timeline, credibility)

**Dependencies:**

- Project start
- EMC consultancy contact established (parallel step)

### 5. Founder identifies and engages an independent EMC consultancy on a fixed milestone-based agreement. The agreement specifies deliverables: prototype RF design review (Month 2 = 2026-12-08), in-house rig design and setup consultation (Month 2 = 2026-12-08), accredited lab coordination and design-readiness confirmation (Month 4 = 2027-02-08), and lab result interpretation (Month 5 = 2027-03-08). Total cost is capped at EUR 20–25k (estimate) with no overruns permitted. Milestone agreement includes penalty clauses for missed deadlines. If the consultancy cannot commit to the timeline by Month 0.5 (2026-10-23), a backup consultancy is identified immediately.

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- EMC Consultancy Selected (name, expertise, references checked)
- Signed Milestone Agreement (deliverables, cost cap EUR 20–25k, timeline, penalty clauses)
- Backup Consultancy Identified (in case primary fails)

**Dependencies:**

- Project scope and design requirements known (single-SKU rigid enclosure)
- Timeline milestones agreed (Month 2–5 = 2026-12-08 to 2027-03-08 design and lab cycle)

### 6. Founder initiates co-development partnership with an Estonian university lab (e.g., Tallinn University of Technology) providing access to in-house shielding test-rig facilities and RF measurement equipment. Partnership agreement specifies: (1) university provides measurement access and capital support for rig setup (EUR 5–10k estimate), (2) founder provides consumables and operational costs, (3) IP and publication rights are clarified upfront, (4) milestones are tied to prototype availability (Month 2 = 2026-12-08) and validation completion (Month 3 = 2027-01-08). Partnership is documented in a written co-development agreement signed by Month 0.5 (2026-10-23). If university partnership is not confirmed by Month 1.5 (2026-11-23), founder immediately hires a part-time RF engineer (0.5 FTE, EUR 25k Year-1 estimate) as backup.

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- University Lab Partner Identified (institution, lab director, capabilities)
- Signed Co-Development Agreement (IP rights, capital/consumables costs, publication terms, milestones)
- In-House Rig Design Specification (frequency range, attenuation measurement methodology, calibration standard)
- Backup RF Engineer Hiring Plan (in case university partnership fails by Month 1.5 = 2026-11-23)

**Dependencies:**

- Project scope and design requirements known
- University lab capability and availability confirmed

### 7. Founder commissions a legal opinion on applicable EU product-safety rules, including General Product Safety Directive, EMC Directive applicability, and consumer-protection duties. Legal counsel (prefer Estonian or EU-based) delivers findings by Month 1 (2026-11-08). Legal opinion documents: (1) which directives apply (if any), (2) product-liability exposure and warranty obligations, (3) claim substantiation requirements, (4) compliance recommendations. Cost budget: EUR 2–5k (estimate). Findings are shared with the Compliance and Liability Committee and used to finalize the scope statement and marketing disclaimers.

**Responsible Body/Role:** Founder / Project Principal (with external legal counsel)

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Legal Opinion on EU Product-Safety Rules (applicability of EMC Directive, General Product Safety Directive, consumer law)
- Regulatory Compliance Roadmap (CE marking requirement assessment, claim substantiation rules)
- Scope Statement Final Version (protects stored spare devices only; does not protect active equipment or grid-scale events)

**Dependencies:**

- Project scope and marketing narrative defined
- Legal counsel identified and engaged

### 8. Founder sets up the presale-deposit account as a separate, earmarked bank account, distinct from operational cash. Founder documents the deposit ring-fencing policy: (1) deposits are classified as liabilities, not revenue or cash flow, (2) operational spending is never drawn from this account, (3) deposits are used only to fulfill presale orders, (4) refunds are approved by founder and tracked, (5) month-end reconciliation is completed. An accountant or operations person is designated to manage this account. The separate account is audited monthly by Month 1.5 (2026-11-23) onward.

**Responsible Body/Role:** Founder / Project Principal (with part-time operations/finance support from Month 1 = 2026-11-08)

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Presale Deposit Account Opened (separate from operational cash)
- Deposit Ring-Fencing Policy Documented (written procedures for deposit use, refunds, accounting)
- Monthly Reconciliation Template (deposits received, refunds paid, net deposits, liability tracking)
- Audit Log Started (deposits and refunds recorded daily)

**Dependencies:**

- Presale terms document finalized
- Bank account access confirmed
- Governance charter and gate convention approved

### 9. Founder formally establishes the Project Steering Committee by confirming membership: (1) Founder / Project Principal, (2) External Financial Advisor (recruited earlier). Founder schedules the first Steering Committee meeting for Month 1 (2026-11-08) to review and approve the governance charter, cash-flow gate convention, burn schedule, and initial risks. Founder documents committee decision rights, meeting cadence (monthly, last week of month, typically 1 hour), and escalation procedures. A written Steering Committee Charter is signed by both members by Month 1.5 (2026-11-23).

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Project Steering Committee Formally Constituted (founder and advisor confirmed, written confirmation)
- Steering Committee Charter Signed (decision rights, meeting cadence, escalation paths, tiebreak rules)
- First Steering Committee Meeting Held (Month 1 = 2026-11-08)
- Meeting Minutes: Gate Convention Approved, Burn Schedule Approved, Initial Risk Register Reviewed

**Dependencies:**

- External advisor recruited and engaged
- Governance charter and gate convention drafted by founder
- Legal and lab engagement in progress

### 10. Founder identifies and pre-qualifies the primary Tallinn precision-metal fabricator and a secondary backup fabricator. Founder requests quotations for: (1) soft tooling (laser cutting and CNC bending for prototyping and early batches), (2) hard tooling (progressive die or equivalent for production), and (3) per-unit production cost (target: EUR 70 estimate). Founder also conducts trial laser-cut batches with both primary and secondary suppliers (Month 0–1 = 2026-10-08 to 2026-11-08) to assess quality, tolerance, finish, and lead times. Trial samples are reviewed and documented.

**Responsible Body/Role:** Founder / Project Principal (with Production and Supply Chain Committee support from Month 1.5 = 2026-11-23 onward)

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Primary Fabricator Identified and Quoted (soft tooling, hard tooling, unit cost)
- Secondary Backup Fabricator Identified and Quoted (same scope)
- Trial Laser-Cut Samples Received and Inspected (primary and secondary, documented pass/fail)
- Fabricator Capability Assessment (quality, tolerance, lead time, capacity)

**Dependencies:**

- Enclosure design specification finalized (single-SKU rigid aluminium/steel, conductive-gasket seam)
- Target unit cost (EUR 70 estimate) and production volume (1,500 units Year-1) known

### 11. Founder identifies and pre-qualifies conductive-gasket material suppliers (primary and backup). Founder requests quotations for RF-shielding-grade gasket materials matching the enclosure seam design, specifying: (1) attenuation performance (to support shielding claims), (2) durability and compression-set characteristics, (3) lead times (minimum 4 weeks estimate), (4) per-unit cost (to fit within EUR 70 total unit cost estimate). Founder also calculates buffer-stock requirement: 30-day supply based on expected monthly production (target: 125 units/month Year-1 average) = approximately 125 units worth of gasket material, costing EUR 5–10k (estimate). Gasket supplier agreements are documented by Month 1 (2026-11-08).

**Responsible Body/Role:** Founder / Project Principal (with Production and Supply Chain Committee support from Month 1.5 = 2026-11-23 onward)

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Primary Gasket Supplier Identified and Quoted (material spec, attenuation, lead time, unit cost)
- Backup Gasket Supplier Identified and Quoted (same spec)
- Gasket Buffer Stock Calculated (30-day supply, EUR 5–10k estimate)
- Supplier Quality and Lead-Time Confirmation

**Dependencies:**

- Enclosure seam design finalized (conductive-gasket type and spec)
- Production volume and lead-time forecast known

### 12. Founder formally establishes the Design and Certification Working Group by confirming membership: (1) Founder (design lead and decision authority), (2) EMC Consultancy (RF design and lab coordination), (3) Estonian University Lab (in-house rig and measurement support), (4) Accredited EMC Laboratory (external, once selected), and (5) Backup RF Engineer (if university partnership fails by Month 1.5 = 2026-11-23). Founder schedules the first Design & Certification meeting for Month 1.5 (2026-11-23) to review: (1) prototype design requirements, (2) in-house rig validation methodology, (3) accredited lab engagement timeline, (4) design-readiness criteria. A written working group charter is confirmed by Month 2 (2026-12-08).

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 1.5 (2026-11-23)

**Key Outputs/Deliverables:**

- Design and Certification Working Group Formally Constituted (membership confirmed, roles assigned)
- Working Group Charter Signed (decision rights, meeting cadence bi-weekly, agenda framework)
- First Working Group Meeting Held (Month 1.5 = 2026-11-23)
- Meeting Minutes: Design Requirements Reviewed, Rig Validation Plan Confirmed, Lab Timeline Locked

**Dependencies:**

- EMC consultancy and university lab agreements signed
- Accredited lab pre-engagement consultations completed
- Design and Certification group charter drafted by founder

### 13. Founder obtains a fixed-cost statement of work from the selected accredited EMC laboratory. Statement of work specifies: (1) applicable standard (IEEE 299.1 or equivalent, documented), (2) frequency range (to be confirmed), (3) attenuation measurement method, (4) number of test samples required, (5) total cost (fixed at EUR 15k cap, estimate), (6) design-readiness review cost (EUR 2–3k estimate, included in total), (7) report delivery date (committed by Month 5 = 2027-03-08, latest Month 6 = 2027-04-08), (8) re-test cost if first attempt fails (EUR 8–15k estimate, outside the original contract). Statement of work is signed by founder and lab director by Month 1.5 (2026-11-23). A copy is shared with the Design & Certification Working Group.

**Responsible Body/Role:** Founder / Project Principal (with Design and Certification Working Group input)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 1.5 (2026-11-23)

**Key Outputs/Deliverables:**

- Signed Lab Statement of Work (cost fixed EUR 15k, report date Month 5 = 2027-03-08)
- Lab Standard and Frequency Range Confirmed (IEEE 299.1 or equivalent documented)
- Design-Readiness Review Scope Defined (EUR 2–3k estimate, Month 4 = 2027-02-08)
- Re-Test Cost and Timeline Documented (EUR 8–15k estimate, outside original contract)

**Dependencies:**

- Accredited lab selected (Month 0–1 = 2026-10-08 to 2026-11-08)
- Enclosure design specification finalized

### 14. Founder signs a binding pricing and capacity agreement with the primary Tallinn fabricator, locking in: (1) soft-tooling cost (estimated for laser-cut and bend iterations, Months 1–3 = 2026-11-08 to 2027-01-08), (2) hard-tooling cost (estimated EUR 30k, range 20–40k estimate, released only at Month 5–6 = 2027-03-08 to 2027-04-08 after presale gate is met), (3) per-unit production cost (EUR 70 estimate, no increase without 60-day notice and founder approval), (4) production batch schedule (Batch 1: 800 units, Months 7–8 = 2027-05-08 to 2027-06-08; follow-on batches: 700 units Months 9–12 = 2027-07-08 to 2027-10-08), (5) capacity reservation (committed slot for these batches, no capacity loss or reallocation to other customers), (6) price-increase cap (no more than 10% annually, effective Month 13 = 2027-11-08 onward). Agreement is signed by founder and fabricator by Month 1.5 (2026-11-23). A backup agreement with the secondary fabricator is signed simultaneously, contingent on primary failure.

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 1.5 (2026-11-23)

**Key Outputs/Deliverables:**

- Signed Primary Fabricator Agreement (pricing locked, capacity reserved, schedule committed)
- Signed Secondary Fabricator Backup Agreement (same terms, contingent on primary failure)
- Soft Tooling Budget Confirmed (estimated cost, Months 1–3 = 2026-11-08 to 2027-01-08)
- Hard Tooling Cost Locked (EUR 30k estimate, release gated on Month 5–6 = 2027-03-08 to 2027-04-08 presale deposits)

**Dependencies:**

- Primary and secondary fabricators identified and quoted
- Enclosure design specification finalized
- Budget allocation (EUR 20k soft tooling, EUR 30k hard tooling, EUR 105k unit cost) approved

### 15. Founder establishes the Compliance and Liability Committee by confirming membership: (1) Founder (compliance owner, decision authority), (2) External Legal Counsel (EU product law expertise), (3) Product-Liability Insurer (coverage assessment and terms), (4) Design & Certification Group Liaison (to align lab report and claims). Founder schedules the first Compliance & Liability meeting for Month 1.5 (2026-11-23) to review: (1) legal opinion findings on applicable directives, (2) product-liability insurance quotes and coverage terms, (3) scope statement and claim-limiting language, (4) warranty and refund obligations. A written committee charter is confirmed by Month 2 (2026-12-08).

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 1.5 (2026-11-23)

**Key Outputs/Deliverables:**

- Compliance and Liability Committee Formally Constituted (membership confirmed)
- Committee Charter Signed (decision rights, meeting cadence monthly, escalation paths)
- First Committee Meeting Held (Month 1.5 = 2026-11-23)
- Meeting Minutes: Legal Opinion Reviewed, Insurance Quotes Compared, Scope Statement Finalized

**Dependencies:**

- Legal opinion commissioned and delivered
- External legal counsel and insurer contacts established
- Governance charter and compliance framework drafted by founder

### 16. Founder contacts 2–3 product-liability insurers who cover Faraday enclosures, RF-shielding products, or consumer electronics. Founder requests quotes for coverage limits of EUR 250–500k (estimate) for defect claims, failure, and misrepresentation liability. Founder asks each insurer to clarify: (1) whether Faraday-enclosure claims are insurable (no exclusion for 'rare events'), (2) claim-substantiation requirements, (3) warranty and refund exposure, (4) premium costs, (5) exclusions or limitations, (6) whether annual re-verification is required. Quotes are compared by Month 2 (2026-12-08). Insurance terms are locked with the selected insurer by Month 2.5 (2026-12-23).

**Responsible Body/Role:** Founder / Project Principal (with Compliance and Liability Committee oversight)

**Suggested Timeframe:** Month 1.5 (2026-11-23) to Month 2.5 (2026-12-23)

**Key Outputs/Deliverables:**

- Insurance Quotes Received (3 insurers, coverage EUR 250–500k estimate, premiums compared)
- Insurance Policy Locked (coverage limits, exclusions, premium, effective date Month 3 = 2027-01-08)
- Coverage Confirmation Letter (insurer confirms Faraday-enclosure claims are covered)
- Compliance Summary: Insurance and Warranty Obligations Documented

**Dependencies:**

- Legal opinion on applicable product-safety rules completed
- Scope statement drafted and reviewed
- Compliance and Liability Committee formed

### 17. Founder designs and prepares parallel presale campaigns targeting three buyer segments: (1) Prepper Networks and Online Communities (disaster-preparedness theme, messaging about solar-storm and pulse resilience, deposit rate 40–50% estimate, average order value EUR 50–70 estimate), (2) Critical-Infrastructure and Emergency-Planning Buyers (documentation and pilots, messaging about continuity of operations, deposit rate 30–40% estimate, order value EUR 200–300+ estimate), (3) Privacy, Digital-Forensics, and Corporate IT Buyers (multi-use RF-isolation narrative, messaging about privacy and RF security, deposit rate 35–45% estimate, order value EUR 80–150 estimate). Founder drafts distinct presale marketing copy, landing pages, email templates, and buyer-contact lists for each segment. Campaigns are reviewed by founder and external advisor by Month 1.5 (2026-11-23). Presale platforms (web form, payment processor, email list) are set up by Month 2 (2026-12-08).

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Prepper Campaign Materials Drafted (messaging, landing page, email templates, community contact list)
- Infrastructure Campaign Materials Drafted (pilot proposal, documentation pack outline, buyer contact list)
- Privacy/Corporate Campaign Materials Drafted (multi-use RF-isolation narrative, contact list)
- Presale Platform Set Up (web form, payment processor linked to separate deposit account, email automation)
- Campaign Launch Plan Confirmed (Month 1 = 2026-11-08 release date for all three segments)

**Dependencies:**

- Scope statement and marketing disclaimers finalized
- Presale terms and delivery SLA published
- Presale deposit account and ring-fencing procedures ready

### 18. Founder formally establishes the Presale and Revenue Validation Committee by confirming membership: (1) Founder (presale strategy, buyer relationships), (2) Part-Time Operations Person (deposit tracking, data dashboard, reporting), (3) External Advisor Liaison (segment analysis, pivot trigger assessment). Founder schedules the first meeting for Month 1.5 (2026-11-23) to review: (1) presale campaign designs, (2) deposit-tracking methodology and weekly dashboard, (3) segment-mix analysis triggers (prepper > 70% by Month 3 = 2027-01-08 escalates presale pivot), (4) conversion-rate and average-order-value thresholds, (5) presale cutoff date (Month 8 = 2027-06-08). A written committee charter is confirmed by Month 2 (2026-12-08).

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 1.5 (2026-11-23)

**Key Outputs/Deliverables:**

- Presale and Revenue Validation Committee Formally Constituted (membership confirmed)
- Committee Charter Signed (decision rights, weekly/monthly meeting cadence, pivot triggers)
- First Committee Meeting Held (Month 1.5 = 2026-11-23)
- Presale Dashboard Template Confirmed (weekly tracking: deposits, refunds, segment mix, conversion rate, AOV)
- Pivot Trigger Criteria Documented (prepper > 70%, conversion < 40%, AOV < EUR 50 estimate)

**Dependencies:**

- Presale campaigns designed and reviewed
- Presale deposit account set up
- Part-time operations person identified (to be hired Month 1 = 2026-11-08 or earlier)

### 19. Founder launches all three parallel presale campaigns (prepper, infrastructure, privacy/forensics) simultaneously by Month 1 (2026-11-08). Presale offers are posted on the project website, announced in prepper forums and communities, sent to critical-infrastructure buyer contacts, and shared in digital-forensics and privacy-advocacy networks. Presale terms, delivery SLA (2–3 week build-to-order lead time), refund policy (30-day window, 15% cumulative cap by Month 8 = 2027-06-08 as pivot trigger), and scope statement (protects stored spare devices only) are displayed prominently. Presale deposits begin flowing into the separate earmarked account. The operations person tracks deposits and refunds daily starting Month 1 (2026-11-08).

**Responsible Body/Role:** Founder / Project Principal (with Part-Time Operations support)

**Suggested Timeframe:** Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- All Three Presale Campaigns Launched (prepper, infrastructure, privacy/forensics)
- Presale Deposits Begin Flowing (tracked daily into separate account)
- First Week Presale Dashboard (deposits, refunds, segment mix)
- Communications Log (campaign reach, email opens, landing-page clicks, deposit velocity)

**Dependencies:**

- Presale campaigns designed and tested
- Presale platform and deposit account ready
- Presale terms and delivery SLA published
- Part-time operations person on board

### 20. Founder formally establishes the Production and Supply Chain Committee by confirming membership: (1) Founder (supplier relationships, production decisions, quality sign-off), (2) Primary Tallinn Fabricator (manufacturing partner), (3) Secondary Backup Fabricator (contingency), (4) Gasket Material Suppliers (primary and backup), (5) Freight Logistics Partner (DHL, UPS, or local carrier), (6) Part-Time Operations/Supply-Chain Manager (tracking, inspections, inventory management). Founder schedules the first Production & Supply Chain meeting for Month 2 (2026-12-08) to review: (1) soft-tooling schedule (laser-cut trials, Months 1–3 = 2026-11-08 to 2027-01-08), (2) hard-tooling readiness (Month 5–6 gate = 2027-03-08 to 2027-04-08), (3) gasket buffer stock (30-day supply in place by Month 6 = 2027-04-08), (4) production batch schedule (Batch 1: Months 7–8 = 2027-05-08 to 2027-06-08). A written committee charter is confirmed by Month 2 (2026-12-08).

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 1.5 (2026-11-23) to Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Production and Supply Chain Committee Formally Constituted (membership confirmed, roles assigned)
- Committee Charter Signed (decision rights, bi-weekly/monthly meeting cadence, escalation paths)
- First Committee Meeting Held (Month 2 = 2026-12-08)
- Meeting Minutes: Soft Tooling Schedule Reviewed, Supplier Agreements Confirmed, Quality-Control Plan Finalized

**Dependencies:**

- Primary and secondary fabricators identified and agreements signed
- Gasket suppliers identified and quoted
- Freight logistics partner identified and rates negotiated
- Production and supply-chain committee charter drafted by founder

### 21. Founder negotiates volume-discount freight rates with 2–3 freight carriers (DHL, UPS, FedEx, local carriers) for Year-1 presale and production shipments. Founder requests quotes for: (1) standard parcel shipments from Tallinn to major EU destinations (EUR 8–15 per unit estimate), (2) volume discounts based on 1,500 units Year-1 forecast, (3) pricing lock-in period (Year-1, with price adjustment effective Month 13 = 2027-11-08 onward), (4) tracking and delivery-confirmation capability. Freight rates are locked with the selected carrier(s) by Month 1.5 (2026-11-23). Landed cost impact on unit margin is calculated (EUR 12 per unit estimate, part of EUR 82 direct cost). Freight costs are incorporated into the monthly cash-flow dashboard.

**Responsible Body/Role:** Founder / Project Principal (with Production and Supply Chain Committee input)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 1.5 (2026-11-23)

**Key Outputs/Deliverables:**

- Freight Carrier Quotes Received (3 carriers, rates per unit EUR 8–15 estimate, volume discounts)
- Freight Rates Locked (selected carrier(s), pricing locked for Year-1, EUR 12 per unit budgeted)
- Freight Contract Signed (carrier, pricing, SLA, tracking, delivery confirmation)
- Landed Cost Impact Documented (included in EUR 82 direct cost, EUR 67 contribution margin)

**Dependencies:**

- Production volume forecast (1,500 units Year-1) and shipment destinations known
- Primary production site (Tallinn) confirmed

### 22. Founder establishes the Financial Governance and Gate Measurement Committee by confirming membership: (1) Founder (cash-flow owner, tranche decision authority), (2) External Financial Advisor (independent co-signatory on gate result), (3) Part-Time Operations/Finance Person (monthly cash reconciliation, invoice tracking). Founder schedules the first meeting for Month 2 (2026-12-08) to review: (1) the written cash-flow gate measurement convention, (2) the monthly burn schedule and budget allocation, (3) monthly cash-reconciliation methodology (budget vs. actuals, presale deposits, delivered-unit revenue, opex), (4) the gate calculation formula (EUR 25k quarterly surplus threshold, Months 9–12 = 2027-07-08 to 2027-10-08 measurement window). A written committee charter is confirmed by Month 2 (2026-12-08).

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 1.5 (2026-11-23) to Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Financial Governance and Gate Measurement Committee Formally Constituted (membership confirmed)
- Committee Charter Signed (decision rights, monthly meeting cadence, gate measurement protocol)
- First Committee Meeting Held (Month 2 = 2026-12-08)
- Monthly Cash-Reconciliation Template Confirmed (budget vs. actuals, presale deposits, revenue, opex, runway)
- Gate Calculation Formula Locked (EUR 25k quarterly threshold, Months 9–12 = 2027-07-08 to 2027-10-08 measurement window)

**Dependencies:**

- Cash-flow gate measurement convention drafted and approved by Steering Committee
- Monthly burn schedule created and approved
- External financial advisor recruited
- Part-time operations/finance person identified

### 23. Founder creates a comprehensive compliance checklist (to be reviewed monthly by the Compliance and Liability Committee and Financial Governance Committee) covering: (1) marketing claims limiting to measured attenuation and tested frequency band, (2) scope statement (protects stored spare devices only) present in all materials, (3) warranty and refund terms aligned with consumer law, (4) product-liability insurance active and cover verified, (5) accredited lab report published with every unit sold, (6) presale SLA (2–3 week lead time, 30-day refund window) honored, (7) no claims of protection for active equipment or grid-scale events, (8) monthly audit sample (presale marketing, website, email communications reviewed). Compliance checklist is finalized and published by Month 2 (2026-12-08). First audit is conducted by Month 2.5 (2026-12-23).

**Responsible Body/Role:** Founder / Project Principal (with Compliance and Liability Committee oversight)

**Suggested Timeframe:** Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Compliance Checklist Document (monthly audit protocol, 8-item checklist, responsibility assignments)
- First Monthly Audit Conducted (Month 2.5 = 2026-12-23, sample of marketing materials reviewed)
- Audit Result Documented (pass/fail per item, any drift noted and corrected)
- Compliance Dashboard Created (tracking compliance status monthly, flagging any corrective actions needed)

**Dependencies:**

- Scope statement and marketing disclaimers finalized
- Product-liability insurance locked
- Accredited lab engagement plan confirmed
- Presale terms and delivery SLA published

### 24. Founder hires or confirms a part-time operations and finance person (10–15 hours/week, EUR 200–300/week estimate) by Month 1 (2026-11-08), or immediately if presale volume warrants earlier start. This person is responsible for: (1) daily presale-deposit tracking and reconciliation, (2) refund approvals and processing, (3) monthly cash-reconciliation (budget vs. actuals), (4) presale-to-delivery queue management and shipment coordination, (5) quality-control inspections (initial production batches), (6) supplier and fabricator communications, (7) presale dashboard updates (weekly), (8) monthly compliance audit. Person is on-boarded by Month 1 (2026-11-08) with documented procedures and access to all systems (deposit account, budget spreadsheet, supplier contacts). Backup procedures are documented in case this person becomes unavailable.

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Part-Time Operations/Finance Person Hired and On-Boarded
- Job Description and Procedures Manual Created (deposit tracking, refunds, cash reconciliation, quality control, supplier coordination)
- System Access Granted (deposit account, budget spreadsheet, presale platform, supplier databases)
- Backup Procedures Documented (in case person becomes unavailable)

**Dependencies:**

- Budget for operations person allocated (EUR 5–8k Year-1 within the EUR 75k marketing/operations line)
- Presale platform ready and campaigns launching

### 25. Founder convenes the first Steering Committee review meeting at Month 2 (2026-12-08) to assess Project governance setup progress across all five committees. Agenda includes: (1) governance framework checklist (five committees formally established? charters signed? first meetings held?), (2) budget allocation and burn-schedule approval (EUR 400k Year-1 by category), (3) lab engagement status (statement of work signed? report date locked?), (4) presale campaign launch confirmation (all three segments active? deposit tracking working?), (5) compliance framework status (legal opinion received? insurance locked? scope statement published?), (6) production timeline confirmation (soft and hard tooling gated correctly?), (7) risk register initial review (top 10–15 risks identified and mitigation assigned). Meeting minutes are documented and each committee head confirms their readiness. A governance 'go' decision is issued or a blockers list is escalated.

**Responsible Body/Role:** Project Steering Committee (Founder + External Advisor)

**Suggested Timeframe:** Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Governance Readiness Checklist Completed (five committees established, charters signed, kickoff meetings held)
- First Steering Committee Review Meeting Held (Month 2 = 2026-12-08)
- Meeting Minutes: Governance 'Go' Decision Issued or Blockers Escalated
- Risk Register Initial (15 risks, owners, mitigation plans, review cadence)
- Budget Allocation Approved (EUR 400k Year-1 by category, monthly burn schedule locked)

**Dependencies:**

- All five committees formally established and chartered
- First meetings of each committee held
- Lab, EMC consultancy, university, fabricator, and insurer agreements signed
- Presale campaigns launched

### 26. Founder initiates prototype RF design with the EMC consultancy and university lab. Prototype design activities include: (1) enclosure geometry, seam design, gasket specification, and internal layout for phones and laptops, (2) RF shielding analysis (seam leakage, aperture shielding, lid-seal performance) using simulation or lab measurement, (3) materials selection (aluminum or steel, gasket material), (4) preliminary bill of materials and unit cost estimate. Design is reviewed by Month 2 (2026-12-08) (prototype readiness for rig testing). Prototype fabrication begins using soft tooling (laser-cut samples from the primary fabricator). First prototype samples are ready for in-house rig testing by Month 3 (2027-01-08). Design documentation and trade-off rationale are recorded.

**Responsible Body/Role:** Design and Certification Working Group (EMC Consultancy, University Lab, Founder)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Prototype Design Specification (enclosure geometry, materials, seam design, gasket spec, BOM, unit cost estimate)
- RF Shielding Analysis (simulation or preliminary measurement, attenuation expectations, frequency band)
- Prototype Fabrication Samples Ordered (soft-tooling laser-cut samples, primary fabricator)
- Design Review Meeting (Month 2 = 2026-12-08, EMC consultancy, university lab, founder approval)

**Dependencies:**

- Enclosure architecture decision finalized (single-SKU rigid metal, conductive-gasket seam)
- EMC consultancy and university lab agreements signed
- Prototype fabricator (primary and secondary) qualified

### 27. University lab sets up the in-house shielding test rig for RF measurement and validation. Rig setup activities include: (1) RF source (signal generator or pulser), (2) measurement equipment (field probes, RF meter), (3) calibration and frequency-range setup (target frequency band matching accredited lab standard, proposed IEEE 299.1 or equivalent), (4) test sample holder and sealing methodology, (5) validation methodology (attenuation measurement across frequency band, two independent seam cycles for durability assessment). Rig is ready for prototype testing by Month 3 (2027-01-08). Rig calibration and baseline testing are documented. Cost of rig capital and consumables (EUR 5–10k estimate) is funded from the co-development agreement.

**Responsible Body/Role:** Design and Certification Working Group (University Lab lead, EMC Consultancy support)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 3 (2027-01-08)

**Key Outputs/Deliverables:**

- In-House Shielding Test Rig Designed and Built (RF source, measurement equipment, holder, calibration)
- Rig Calibration Report (baseline frequency response, measurement accuracy verification)
- Test Methodology Documented (frequency band, attenuation measurement procedure, durability/seam-cycle protocol)
- Rig Ready for Prototype Testing by Month 3 (2027-01-08)

**Dependencies:**

- University lab partnership agreement signed
- Frequency band and measurement standard confirmed (from accredited lab pre-engagement)
- Rig capital and consumables budget (EUR 5–10k estimate) allocated

### 28. University lab and founder conduct in-house shielding validation testing on the first prototype enclosures using the test rig. Testing includes: (1) attenuation measurement across the target frequency band (e.g., 50 MHz to 1 GHz, estimate, to be confirmed by lab standard), (2) seam integrity and gasket contact assessment (visual and measurement), (3) first seam-cycle durability test (open and close the lid 10 times, re-measure attenuation to verify gasket resilience), (4) second independent seam cycle on a fresh sample (confirm repeatability). Test results are documented with attenuation curves, frequency-band summary, pass/fail criteria (minimum attenuation target, e.g., >60 dB estimate, to be confirmed by lab). If results meet in-house criteria (two passing cycles), design is deemed 'pre-test ready' and escalated to the accredited lab for design-readiness review. If results fall short, a redesign scope and impact are assessed by the Design & Certification group and escalated to Steering Committee.

**Responsible Body/Role:** Design and Certification Working Group (University Lab lead, Founder, EMC Consultancy support)

**Suggested Timeframe:** Month 3 (2027-01-08)

**Key Outputs/Deliverables:**

- In-House Rig Validation Test Report (attenuation data across frequency band, two independent seam cycles, pass/fail criteria met)
- Design Pre-Test Readiness Confirmed (documented by university lab and EMC consultancy)
- Prototype Revision Summary (any minor changes made to prototype based on rig results, seam adjustments, gasket refinements)
- Lab Samples Prepared (prototype enclosure(s) packaged for shipment to accredited lab, Month 4 = 2027-02-08)

**Dependencies:**

- In-house test rig operational and calibrated
- Prototype samples from soft-tooling fabrication ready
- Test methodology and pass/fail criteria documented

### 29. Founder and Design & Certification group coordinate with the accredited EMC laboratory to conduct a pre-submission design-readiness review. This review (EUR 2–3k estimate, included in the EUR 15k lab budget) includes: (1) presentation of the prototype design, RF analysis, and in-house rig results to the lab's RF engineer, (2) lab assessment of design readiness and likely attenuation performance, (3) lab confirmation of test methodology and frequency range (aligned with the lab's standard), (4) discussion of sample preparation and submission timing, (5) lab feedback on any design features that may impact shielding or require re-qualification. Output: design-readiness confirmation letter from the lab. If the lab raises any concerns (e.g., seam design may not achieve claimed attenuation, frequency range mismatch), the Design & Certification group assesses redesign scope and cost impact (potentially drawing from the EUR 20k reserve). If readiness is confirmed, sample submission is scheduled for Month 4 (2027-02-08).

**Responsible Body/Role:** Design and Certification Working Group (EMC Consultancy lead, Founder, Lab liaison)

**Suggested Timeframe:** Month 4 (2027-02-08)

**Key Outputs/Deliverables:**

- Lab Pre-Submission Design-Readiness Review Conducted (Month 4 = 2027-02-08)
- Lab Design-Readiness Confirmation Letter (design is test-ready, no major concerns, attenuation expectations align with measured targets)
- Test Sample Preparation Plan (prototype enclosure(s), gasket condition, sealing procedure, sample handling)
- Lab Test Schedule Confirmed (samples submitted Month 4 = 2027-02-08, report delivery Month 5 = 2027-03-08)

**Dependencies:**

- In-house rig validation completed and pre-test readiness confirmed
- Accredited lab statement of work signed with design-readiness review scope defined
- Prototype samples ready for lab submission

### 30. Founder and EMC consultancy coordinate final prototype sample preparation and submission to the accredited EMC laboratory. Sample preparation includes: (1) enclosure unit(s) representing production-representative design (soft tooling or limited hard-tool trial sample), (2) gasket in production-representative condition, (3) sealing and assembly per production procedure, (4) documentation of sample condition, serial numbers, and photographic record. Samples are shipped to the lab by early Month 4 (2027-02-08) with handling instructions and test-request form. Lab acknowledges receipt and confirms expected report delivery by Month 5 (2027-03-08), latest Month 6 (2027-04-08). Any concerns about sample condition or test feasibility are escalated immediately to the Design & Certification group.

**Responsible Body/Role:** Design and Certification Working Group (Founder, EMC Consultancy, Lab liaison)

**Suggested Timeframe:** Month 4 (2027-02-08)

**Key Outputs/Deliverables:**

- Lab Samples Prepared and Documented (production-representative enclosure, gasket, sealing per procedure, photos)
- Samples Shipped to Accredited Lab (shipping confirmation, tracking number, test-request form submitted)
- Lab Receipt Confirmed (email from lab acknowledging receipt, sample condition OK, test schedule confirmed)

**Dependencies:**

- Prototype design finalized and pre-test readiness confirmed by lab
- Prototype samples from soft-tooling fabrication ready for submission
- Lab statement of work and design-readiness review completed

### 31. Accredited EMC laboratory conducts full shielding-effectiveness testing on the submitted prototype samples. Testing includes: (1) RF source application across the frequency band (proposed IEEE 299.1 standard or equivalent, not verified), (2) attenuation measurement at multiple frequencies (e.g., 50 MHz to 1 GHz in 50 MHz steps, estimate), (3) attenuation data plotted as frequency sweep, (4) identification of any frequency bands with lower-than-expected attenuation or seam/seal issues, (5) final report with attenuation curves, summary table (minimum/maximum/average attenuation), frequency range tested, test methodology, and recommendations (if any). Lab delivers the report by Month 5 (2027-03-08) as scheduled in the statement of work. Report is marked 'final' and suitable for publication with products.

**Responsible Body/Role:** Accredited EMC Laboratory (external test execution)

**Suggested Timeframe:** Month 4 (2027-02-08) to Month 5 (2027-03-08)

**Key Outputs/Deliverables:**

- Accredited Lab Test Execution (RF testing per IEEE 299.1 or equivalent standard)
- Lab Report Delivered (attenuation curves, frequency sweep, summary table, test methodology, recommendations, Month 5 = 2027-03-08)

**Dependencies:**

- Lab samples submitted and received
- Lab testing schedule confirmed
- Test methodology and frequency range aligned between lab and founder

### 32. Design & Certification Working Group receives and reviews the accredited lab report. Review includes: (1) confirmation that attenuation results meet or exceed in-house rig predictions and marketing claims, (2) identification of any frequency bands with lower attenuation or potential seam/gasket issues, (3) assessment of whether results support the intended sales claims (e.g., '>60 dB attenuation from 50 MHz to 1 GHz' estimate, to be confirmed by actual lab data), (4) evaluation of any lab recommendations for design changes or re-qualification, (5) discussion of re-test cost and timeline if results fall short of claims. If results are satisfactory, the group approves the design as 'certified' and the report is designated for publication with every product. If results reveal issues requiring redesign, the group escalates cost/timeline impact to Steering Committee and assesses whether to: (a) accept narrower frequency-range or attenuation claims (no redesign), (b) fund a minor redesign from the EUR 20k reserve and schedule a re-test (EUR 8–15k re-test cost), or (c) halt the project. Design readiness for hard tooling is confirmed by Month 5.5 (2027-03-23).

**Responsible Body/Role:** Design and Certification Working Group (Founder, EMC Consultancy, Steering Committee oversight)

**Suggested Timeframe:** Month 5 (2027-03-08) to Month 5.5 (2027-03-23)

**Key Outputs/Deliverables:**

- Lab Report Reviewed and Assessed (attenuation data, frequency range, claim alignment confirmed)
- Design Certification Decision (approved for publication, or requires redesign with cost/timeline impact)
- Marketing Claims Finalized (attenuation values, frequency band, scope statement, all backed by lab data)
- Lab Report Approved for Publication (final version, to be published with every product shipped)

**Dependencies:**

- Accredited lab report delivered (Month 5 = 2027-03-08)
- In-house rig results available for comparison
- Design and Certification group meeting held to review report

### 33. Steering Committee holds a special review meeting at Month 5 (2027-03-08) or Month 5.5 (2027-03-23) to assess the accredited lab report and confirm readiness for the hard-tooling gate decision at Month 5–6 (2027-03-08 to 2027-04-08). Agenda includes: (1) lab report summary and design certification status, (2) presale deposit status (target EUR 80k net deposits, proposed threshold, by Month 6 = 2027-04-08), (3) in-house rig validation completion (two independent seam cycles confirmed), (4) hard-tooling release decision criteria: deposits >= EUR 80k AND lab pre-test confirms design readiness AND in-house rig passes twice. If all gate criteria are met (or expected to be met by Month 6 = 2027-04-08), the committee issues a 'gate conditional' approval, authorizing founder to submit the hard-tooling order to the fabricator once deposits are confirmed. If gate criteria are not met (e.g., lab results fall short, deposits lag), the committee escalates redesign or presale-pivot recommendations.

**Responsible Body/Role:** Project Steering Committee (Founder + External Advisor)

**Suggested Timeframe:** Month 5 (2027-03-08) to Month 5.5 (2027-03-23)

**Key Outputs/Deliverables:**

- Steering Committee Special Review Meeting Held (Month 5 = 2027-03-08)
- Lab Report Assessment and Design Certification Confirmed (or redesign scope escalated)
- Hard-Tooling Gate Readiness Assessed (design certified, presale deposits approaching EUR 80k estimate, in-house rig validated)
- Conditional Hard-Tooling Gate Approval (founder authorized to release tooling order once deposits confirmed at Month 6 = 2027-04-08)

**Dependencies:**

- Accredited lab report delivered and reviewed
- Presale deposits tracked and reported (current status at Month 5 = 2027-03-08)
- In-house rig validation completed
- Steering Committee meeting scheduled and held

### 34. Financial Governance and Gate Measurement Committee, led by founder and external advisor, confirms that net presale deposits (after refunds) have reached or are projected to exceed EUR 80k (proposed threshold) by Month 6 (2027-04-08). Verification includes: (1) total deposits received (summed from separate deposit account), (2) refunds approved and paid (summed), (3) net deposits calculated (deposits minus refunds), (4) projection of deposits through Month 6 (2027-04-08) based on current deposit velocity and any campaign adjustments. Once net deposits reach EUR 80k, founder and advisor jointly sign a 'Hard-Tooling Gate Confirmation' document, authorizing the Production and Supply Chain Committee to release the hard-tooling order to the primary fabricator. Gate confirmation is documented in writing by Month 6 (2027-04-08).

**Responsible Body/Role:** Financial Governance and Gate Measurement Committee (Founder, External Advisor, Operations/Finance support)

**Suggested Timeframe:** Month 5 (2027-03-08) to Month 6 (2027-04-08)

**Key Outputs/Deliverables:**

- Monthly Presale Dashboard Updated (deposits, refunds, net deposits, segment mix, conversion rate, AOV)
- Hard-Tooling Gate Confirmation Calculated (net deposits >= EUR 80k verified, documented in writing)
- Gate Confirmation Signed (founder and external advisor sign-off, Month 6 = 2027-04-08)
- Hard-Tooling Authorization Issued to Production Committee (move forward with tooling order)

**Dependencies:**

- Presale campaigns active and deposits flowing for 4–5 months (Months 1–5 = 2026-11-08 to 2027-03-08)
- Deposit tracking and reconciliation procedures working
- Gate threshold (EUR 80k) and confirmation protocol established

### 35. Production and Supply Chain Committee, authorized by the hard-tooling gate confirmation, submits the hard-tooling order to the primary Tallinn fabricator. Hard-tooling order includes: (1) tool specification and design documentation (from the finalized prototype design), (2) production quantity (first batch: 800 units; follow-on batches: 700 units Months 9–12 = 2027-07-08 to 2027-10-08), (3) delivery schedule (Batch 1 ready by Month 8 = 2027-06-08, follow-on by Month 12 = 2027-10-08), (4) quality standards and inspection requirements, (5) tooling cost (locked at EUR 30k estimate per agreement), (6) contingency contact (if primary fabricator encounters issues, secondary fabricator is notified). Hard-tooling order is formalized in a signed purchase order by founder and fabricator by Month 6 (2027-04-08).

**Responsible Body/Role:** Production and Supply Chain Committee (Founder, Primary Fabricator, Backup Fabricator standby)

**Suggested Timeframe:** Month 6 (2027-04-08)

**Key Outputs/Deliverables:**

- Hard-Tooling Order Submitted (tool design, production batch quantities, delivery schedule, cost EUR 30k locked)
- Purchase Order Signed (founder and primary fabricator, Month 6 = 2027-04-08)
- Secondary Fabricator Alert (notified of tooling order and backup readiness)
- Tool Delivery Schedule Confirmed (fabricator commits delivery timeline for Batch 1 by Month 8 = 2027-06-08)

**Dependencies:**

- Hard-tooling gate confirmation signed and authorization issued
- Design finalized and certified by accredited lab
- Prototype design documentation complete and ready for tooling
- Primary fabricator agreement signed with tooling cost and schedule locked

### 36. Production and Supply Chain Committee confirms that conductive-gasket buffer stock (30-day supply, EUR 5–10k estimate) is secured, in stock, and ready for production. Gasket material sourcing verification includes: (1) primary gasket supplier orders and delivery confirmed (30-day supply in-house or in-transit), (2) backup gasket supplier identified and samples tested, (3) gasket material specifications confirmed to match lab-validated seam design, (4) material storage conditions appropriate (temperature, humidity control), (5) consumption schedule understood (gaskets consumed as units are produced). Gasket buffer-stock order is placed by Month 6 (2027-04-08) to ensure 30-day supply is available when production begins (Batch 1, Months 7–8 = 2027-05-08 to 2027-06-08).

**Responsible Body/Role:** Production and Supply Chain Committee (Primary Gasket Supplier, Backup Supplier, Founder oversight)

**Suggested Timeframe:** Month 6 (2027-04-08)

**Key Outputs/Deliverables:**

- Gasket Buffer Stock Secured (30-day supply in-house or in-transit, EUR 5–10k investment)
- Supplier Delivery Confirmed (primary supplier commitment to delivery by Month 6.5 = 2027-04-23)
- Quality and Spec Verification (material samples tested, attenuation performance confirmed, seam design compatibility)
- Storage Plan Confirmed (handling procedures, environment control, inventory tracking)

**Dependencies:**

- Enclosure seam design finalized and lab-validated
- Primary and backup gasket suppliers qualified and agreements signed
- Gasket budget (EUR 5–10k estimate, part of EUR 160k production line) allocated

### 37. Presale and Revenue Validation Committee, supported by the operations/finance person, conducts the Month 3 (2027-01-08) segment-mix analysis. Analysis includes: (1) deposit count and value by segment (prepper, infrastructure, privacy/forensics), (2) deposit rates and conversion percentages for each segment, (3) average order values by segment, (4) pivot trigger assessment: if prepper deposits > 70% of total, a marketing-spend reallocation recommendation is issued (shift EUR 10–15k from prepper to infrastructure/privacy channels). If pivot triggers are activated, the committee meets with founder to approve the reallocation and executes revised marketing campaigns within 3 business days. If segment mix looks balanced or infrastructure/privacy leads, presale momentum is confirmed and no major pivot is needed. Analysis is documented and shared with Steering Committee.

**Responsible Body/Role:** Presale and Revenue Validation Committee (Founder, Operations/Finance, External Advisor)

**Suggested Timeframe:** Month 3 (2027-01-08)

**Key Outputs/Deliverables:**

- Segment-Mix Analysis Report (deposits by segment, conversion rates, AOV by segment, pivot trigger assessment)
- Month 3 (2027-01-08) Presale Dashboard Updated (deposits YTD, refunds, net deposits, segment % breakdown, rolling conversion rate)
- Pivot Decision Issued (marketing spend reallocation approved/not needed, messaging adjustments if any)
- Marketing Campaign Adjustments Executed (if pivot triggered, EUR 10–15k reallocated within 3 days)

**Dependencies:**

- Presale campaigns running for 2 months (Months 1–3 = 2026-11-08 to 2027-01-08)
- Deposit tracking dashboard operational
- Pivot trigger thresholds and reallocation plan pre-approved by Steering Committee

### 38. Presale and Revenue Validation Committee conducts the Month 6 (2027-04-08) presale-cutoff decision and announcement. Decision includes: (1) confirmation that presale deposit offer (refundable) closes on Month 8 (2027-06-08), (2) communication to presale customers that orders placed after Month 8 (2027-06-08) will not be fulfilled within the Months 7–12 (2027-05-08 to 2027-10-08) delivery window and will defer to later batches, (3) rationale: ensuring all presale orders from Months 1–8 (2026-11-08 to 2027-06-08) are delivered by Month 12 (2027-10-08) so that delivery-unit revenue counts toward the cash-flow gate measurement, (4) continued presale marketing through Month 8 (2027-06-08), with a final push in Month 7–8 (2027-05-08 to 2027-06-08), (5) presale cutoff enforcement: any orders after Month 8 (2027-06-08) are accepted as 'regular orders' with longer lead times or deferred to post-gate fulfillment. Cutoff announcement is published on the website and sent to presale list by Month 6.5 (2027-04-23).

**Responsible Body/Role:** Presale and Revenue Validation Committee (Founder, Operations/Finance)

**Suggested Timeframe:** Month 6 (2027-04-08)

**Key Outputs/Deliverables:**

- Presale Cutoff Decision Document (Month 8 = 2027-06-08 cutoff, rationale, delivery window locked)
- Presale Cutoff Announcement (published on website, sent to presale list by Month 6.5 = 2027-04-23)
- Order Queue Management Plan (presale orders tracked separately from post-cutoff orders, delivery sequencing confirmed)

**Dependencies:**

- Hard-tooling gate confirmation and production authorization complete (Month 6 = 2027-04-08)
- Presale momentum confirmed (deposits on track for EUR 80–120k estimate)
- Delivery schedule and fulfillment capacity understood (build-to-order, 2–3 week lead time)

### 39. Production and Supply Chain Committee confirms receipt of hard-tooling from the primary Tallinn fabricator and validates tool quality. Tool validation includes: (1) physical inspection of the hardened tool/dies for accuracy and finish, (2) trial production run: 10–20 sample units produced using the hard tooling to verify fit, finish, seam integrity, and gasket contact, (3) comparison of trial-run units against prototype design and lab-validated specification, (4) identification of any tool adjustments needed (minor tweaks to die tolerance, gasket seating, or sealing surfaces), (5) quality-control checklist sign-off. If trial run is successful, full production authorization is issued. If issues emerge, they are corrected by the fabricator before production ramp (no charge to founder per agreement). Tool validation is completed by Month 7 (2027-05-08).

**Responsible Body/Role:** Production and Supply Chain Committee (Primary Fabricator, Founder quality sign-off, Operations/Finance inspection support)

**Suggested Timeframe:** Month 7 (2027-05-08)

**Key Outputs/Deliverables:**

- Hard Tool Received and Validated (tool quality verified, trial production run completed)
- Trial Production Report (10–20 sample units, fit/finish/seam assessment, QC checklist sign-off)
- Tool Adjustment Confirmation (any minor adjustments completed by fabricator)
- Full Production Authorization Issued (Batch 1 production can proceed, month 7–8 = 2027-05-08 to 2027-06-08)

**Dependencies:**

- Hard-tooling order submitted and delivered (Month 6–7 = 2027-04-08 to 2027-05-08)
- Quality-control inspection procedures documented
- Trial production trial capacity available in fabricator's schedule

### 40. Production and Supply Chain Committee confirms launch of Batch 1 production (800 units) at the primary Tallinn fabricator. Production launch includes: (1) release of material (sheet metal, gaskets, fasteners, packaging) to the fabricator's production floor, (2) start of laser-cutting, bending, seam-welding (or assembly), gasket placement, and final assembly per production procedure, (3) in-process quality checks (seam inspection, gasket seating verification, fit testing with representative phones and laptops), (4) final packing and labeling per presale order specifications, (5) production status tracked weekly (units produced, quality issues, on-time delivery forecast). Batch 1 production runs Months 7–8 (2027-05-08 to 2027-06-08), with delivery expected by end of Month 8 (2027-06-08). First units (50–100 estimate) are ready for presale fulfillment by Month 7.5 (2027-05-23).

**Responsible Body/Role:** Production and Supply Chain Committee (Primary Fabricator lead, Founder QA oversight, Operations/Finance coordination)

**Suggested Timeframe:** Month 7 (2027-05-08) to Month 8 (2027-06-08)

**Key Outputs/Deliverables:**

- Batch 1 Production Launched (800 units, laser cutting through final assembly and packing)
- Weekly Production Status Reports (units produced, defect findings, on-time delivery forecast)
- Quality Control Inspections (in-process checks, final fit testing, documented results)
- First Units Ready for Fulfillment (50–100 units by Month 7.5 = 2027-05-23, shipped to presale customers)

**Dependencies:**

- Hard tool delivered and validated (Month 7 = 2027-05-08)
- Gasket buffer stock in-house and ready (Month 6–7 = 2027-04-08 to 2027-05-08)
- Presale order queue compiled and prioritized
- Freight carrier pickup schedule coordinated

### 41. Presale fulfillment begins at the operations/finance team level. Fulfillment process includes: (1) daily order queue review (presale orders chronologically ordered, build-to-order confirmation sent to customer with 2–3 week delivery estimate), (2) production status check with fabricator (where are my units in the queue?), (3) unit receipt from fabricator and quality-final inspection (visual check, test fit with representative devices, gasket condition), (4) packing and labeling (include accredited lab report, scope statement card, warranty terms, contact info), (5) pickup coordination with freight carrier (DHL, UPS, or local carrier), (6) shipment tracking number sent to customer, (7) delivery confirmation received and recorded. Fulfillment pace scales with Batch 1 delivery: 50–100 units Months 7.5–8 (2027-05-23 to 2027-06-08), 400–500 units by end of Month 9 (2027-07-08), 750 units by end of Month 12 (2027-10-08). Monthly fulfillment dashboard tracks units shipped, refunds issued, delivery-time compliance.

**Responsible Body/Role:** Presale and Revenue Validation Committee (Operations/Finance lead, Production & Supply Chain coordination, Founder oversight)

**Suggested Timeframe:** Month 7 (2027-05-08) to Month 12 (2027-10-08)

**Key Outputs/Deliverables:**

- Daily Fulfillment Process Implemented (order queue, production coordination, QC inspection, packing, shipment tracking)
- Monthly Fulfillment Dashboard (units shipped, refunds issued, delivery-time compliance, customer satisfaction notes)
- Lab Report Packaged with Every Unit (accredited lab report, scope statement, warranty terms)
- Delivery Performance Tracked (target: 750 units delivered by Month 12 = 2027-10-08)

**Dependencies:**

- Batch 1 production and first units ready (Month 7.5 = 2027-05-23)
- Presale order queue compiled and prioritized
- Freight carrier integration completed (pickup, tracking, delivery)
- Operations/finance fulfillment procedures documented

### 42. Production and Supply Chain Committee confirms launch of follow-on production batches (700 units total, split across Months 9–12 = 2027-07-08 to 2027-10-08) at the primary fabricator. Follow-on batches are scheduled to match presale fulfillment demand: (1) Month 9 (2027-07-08): 350 units, (2) Month 11 (2027-09-08): 350 units, with flexible adjustment based on presale delivery pace and customer feedback. Each batch follows the same quality-control procedures as Batch 1. Production status and quality metrics are reported weekly to the Production Committee. By Month 12 (2027-10-08), all follow-on batches are delivered and presale fulfillment is complete.

**Responsible Body/Role:** Production and Supply Chain Committee (Primary Fabricator, Founder, Operations/Finance coordination)

**Suggested Timeframe:** Month 9 (2027-07-08) to Month 12 (2027-10-08)

**Key Outputs/Deliverables:**

- Follow-On Batch Schedule Confirmed (700 units total: 350 Months 9–10 = 2027-07-08 to 2027-08-08, 350 Months 11–12 = 2027-07-08 to 2027-10-08)
- Weekly Production Status Reports (units produced, delivery tracking, quality metrics)
- By Month 12 (2027-10-08): All Year-1 Units Delivered (1,500 units total shipped to presale customers)

**Dependencies:**

- Batch 1 production completed and fulfillment underway (Months 7–9 = 2027-05-08 to 2027-07-08)
- Presale demand and fulfillment pace confirmed
- Fabricator capacity and delivery schedule confirmed for follow-on batches

### 43. Financial Governance and Gate Measurement Committee begins monthly cash-flow tracking and reconciliation, starting Month 1 (2026-11-08). Monthly reconciliation activities include: (1) summary of Year-1 budget allocation vs. actual spending (design, lab, soft tooling, hard tooling, production, marketing, reserves), (2) variance analysis (any category >10% variance is flagged and explained), (3) presale deposits (gross received, refunds approved, net deposits held in earmarked account, never commingled with operational cash), (4) delivered-unit revenue (units shipped, invoiced, paid; sample audit of 10–15% of receipts to confirm cash payment), (5) operating expenses (salaries, software, legal, insurance), (6) cash balance and months of runway (based on current burn rate), (7) gate projection: on track for EUR 25k quarterly surplus by Month 12 (2027-10-08) or on-risk. Monthly reconciliation is completed by Month-end + 7 days and reviewed by founder and external advisor. Results are documented in the monthly dashboard and escalated to Steering Committee.

**Responsible Body/Role:** Financial Governance and Gate Measurement Committee (Operations/Finance lead, External Advisor, Founder review)

**Suggested Timeframe:** Ongoing, Month 1 (2026-11-08) through Month 12 (2027-10-08)

**Key Outputs/Deliverables:**

- Monthly Cash-Flow Reconciliation Dashboard (budget vs. actuals, presale deposits, delivered-unit revenue, opex, cash balance, runway)
- Monthly Variance Report (flagging categories >10% variance and corrective actions)
- Quarterly Deep-Dive Analysis (Months 3, 6, 9, 12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08) with advisor sign-off

**Dependencies:**

- Monthly burn schedule and budget allocation established (Month 0.5 = 2026-10-23)
- Presale deposit account set up and ring-fenced (Month 0.5 = 2026-10-23)
- Operations/finance person on-boarded with reconciliation procedures documented

### 44. Compliance and Liability Committee conducts monthly compliance audits starting Month 2.5 (2026-12-23), reviewing a sample of presale marketing materials, website copy, email communications, and product packing insert. Each audit checks the 8-item compliance checklist: (1) marketing claims limited to measured attenuation, (2) scope statement present, (3) warranty/refund terms compliant, (4) insurance status verified, (5) lab report to be published with units, (6) presale SLA honored, (7) no claims of protection for active equipment or grid-scale events, (8) customer refund/complaint log reviewed. Audit results (pass/fail per item, any drift) are documented and shared with founder. If drift is detected (e.g., a marketing email mentions 'grid-scale protection'), founder is notified and has 3 business days to correct it. Audits are completed monthly and escalated to Steering Committee quarterly (Months 3, 6, 9, 12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08).

**Responsible Body/Role:** Compliance and Liability Committee (Founder, Legal Counsel, Compliance auditor role)

**Suggested Timeframe:** Ongoing, Month 2.5 (2026-12-23) through Month 12 (2027-10-08)

**Key Outputs/Deliverables:**

- Monthly Compliance Audit Report (8-item checklist completed, pass/fail per item, drift corrections)
- Compliance Dashboard (tracking compliance status monthly, flagging corrective actions)
- Quarterly Escalations (Months 3, 6, 9, 12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08) to Steering Committee if major issues

**Dependencies:**

- Compliance checklist established and documented (Month 2 = 2026-12-08)
- Marketing materials and communications published and accessible for audit
- Compliance audit procedures documented and assigned

### 45. Steering Committee holds monthly oversight meetings (last week of each month, typically 1 hour) starting Month 1 (2026-11-08) through Month 12 (2027-10-08). Monthly agenda includes: (1) actual vs. budgeted spending (design, lab, tooling, production, marketing) and variance explanation, (2) presale deposit velocity, refund rate, and segment mix; pivot triggers assessed (prepper > 70%, conversion < 40%), (3) lab status (in progress, pre-test results, design certification), (4) hard-tooling gate readiness assessment (Months 5–6 = 2027-03-08 to 2027-04-08 focus), (5) production progress and quality metrics (Months 7–12 = 2027-05-08 to 2027-10-08), (6) quarterly cash-flow projection and months of runway remaining, (7) any unbudgeted items, overruns, or requests to reallocate reserve funds, (8) compliance audit results (quarterly summary), (9) risk register review and updates. Monthly minutes are documented, and decisions/escalations are recorded. Special meetings are convened if spending variance exceeds 10%, presale conversion falls below 40% (estimated), or cash balance threatens runway.

**Responsible Body/Role:** Project Steering Committee (Founder + External Advisor)

**Suggested Timeframe:** Ongoing, Month 1 (2026-11-08) through Month 12 (2027-10-08), monthly cadence, last week of month

**Key Outputs/Deliverables:**

- Monthly Steering Committee Meeting Minutes (agenda items, decisions, escalations documented)
- Monthly Dashboard Review (budget variance, presale progress, lab/production status, cash position)
- Special Meetings (convened if triggers met: 10% variance, <40% conversion, runway threatened)

**Dependencies:**

- Steering Committee charter and meeting calendar established (Month 0.5 = 2026-10-23)
- Monthly input dashboards from each working committee available
- Founder and advisor availability and engagement confirmed

### 46. Financial Governance and Gate Measurement Committee, with founder and external advisor participation, begins the EUR 350k tranche gate-measurement process at Month 11 (2027-09-08), preparing for the final gate decision at Month 12 (2027-10-08). Gate-measurement activities include: (1) compilation of delivered-unit revenue data for the trailing quarter (Months 9–12 = 2027-07-08 to 2027-10-08): units shipped, invoiced, and paid only (no presale deposits), (2) subtraction of direct unit costs (EUR 70 unit cost + EUR 12 freight = EUR 82 per unit estimate) from revenue, (3) subtraction of recurring opex (EUR 20k per quarter estimate: marketing, operations, insurance, legal, software), (4) calculation of operating cash surplus (or deficit) for Months 9–12 (2027-07-08 to 2027-10-08), (5) comparison of result against the gate threshold (EUR 25k proposed threshold). Preliminary gate result is ready by Month 12 (2027-10-08), documented in writing with supporting invoices and payment records audited (10–15% sample). Final gate sign-off is scheduled for Month 12.5 (2027-10-23).

**Responsible Body/Role:** Financial Governance and Gate Measurement Committee (Operations/Finance lead, External Advisor, Founder)

**Suggested Timeframe:** Month 11 (2027-09-08) to Month 12 (2027-10-08)

**Key Outputs/Deliverables:**

- Gate-Measurement Data Compiled (delivered units, revenue, costs, opex for Months 9–12 = 2027-07-08 to 2027-10-08)
- Supporting Documentation Audited (sample of invoices and payment records verified, 10–15% of transactions)
- Gate Calculation Completed (operating cash surplus or deficit computed, threshold comparison)
- Preliminary Gate Result Documented (revenue, costs, opex, surplus/deficit, signature lines for final sign-off)

**Dependencies:**

- Delivered-unit revenue tracking active and complete (Months 7–12 = 2027-05-08 to 2027-10-08)
- Presale fulfillment complete by Month 12 (2027-10-08) (1,500 units delivered)
- Monthly cash-flow reconciliation and expense tracking ongoing

### 47. Project Steering Committee holds a final gate-measurement review meeting at Month 12 (2027-10-08) or Month 12.5 (2027-10-23) to assess the calculated gate result against the threshold (EUR 25k quarterly operating surplus, Months 9–12 = 2027-07-08 to 2027-10-08). Meeting agenda includes: (1) review of gate-measurement calculation (revenue, costs, opex, surplus/deficit), (2) assessment of whether result is clearly above EUR 25k threshold (gate PASS), clearly below (gate FAIL), or ambiguous (-EUR 5k to +EUR 25k estimate), (3) discussion of any methodology questions or corrections needed, (4) if gate result is PASS (>= EUR 25k): founder and advisor sign the gate-result document and recommend release of EUR 350k follow-on tranche to founder for allocation decision, (5) if gate result is FAIL (< EUR 25k): root-cause analysis (insufficient delivered-unit volume, higher-than-expected refunds, cost inflation) and decision whether to pursue the 90-day tiebreak extension (founder may extend and re-measure in Months 13–14 = 2027-11-08 to 2027-12-08) or accept withholding of the tranche.

**Responsible Body/Role:** Project Steering Committee (Founder + External Advisor) with Financial Governance Committee support

**Suggested Timeframe:** Month 12 (2027-10-08) to Month 12.5 (2027-10-23)

**Key Outputs/Deliverables:**

- Final Gate-Measurement Review Meeting Held (Month 12.5 = 2027-10-23)
- Gate Result Confirmed (PASS >= EUR 25k, FAIL < EUR 25k, or AMBIGUOUS -EUR 5k to +EUR 25k)
- Gate Decision Document Signed (founder and external advisor, EUR 350k tranche release recommendation or withholding rationale documented)
- Tranche Release Authorization (if PASS, EUR 350k authorized for founder allocation) or Tiebreak Decision (if AMBIGUOUS, founder exercises discretion; if FAIL, withholding documented)

**Dependencies:**

- Gate-measurement data compiled and audited (Month 12 = 2027-10-08)
- Presale fulfillment complete and all Year-1 delivered-unit revenue recognized
- Steering Committee meeting convened and both members present

### 48. Founder makes the EUR 350k follow-on tranche allocation decision (once gate is passed and authorization is issued at Month 12.5 = 2027-10-23). Allocation options include: (1) inventory replenishment (EUR 80–120k estimate): buffer stock in EU warehouse (200–300 units trial, 30–60 day inventory cycle) to reduce lead times and accelerate customer fulfillment, (2) marketing and sales acceleration (EUR 80–120k estimate): campaigns to expand infrastructure and privacy segments, establish distribution partnerships, attend trade shows, (3) R&D and product variants (EUR 50–100k estimate): smaller SKU variant (phone-only enclosure) or server-grade cage exploration, (4) personnel and operations (EUR 30–50k estimate): full-time operations manager, part-time sales, expanded customer support, (5) working capital and contingency reserve (EUR 30–50k estimate). Founder, in consultation with external advisor, documents the allocation plan and submits it to the Steering Committee for approval by Month 13 (2027-11-08). Once approved, tranche spending begins under the same governance oversight as Year-1.

**Responsible Body/Role:** Founder / Project Principal (with External Advisor consultation and Steering Committee approval)

**Suggested Timeframe:** Month 12.5 (2027-10-23) to Month 13 (2027-11-08)

**Key Outputs/Deliverables:**

- EUR 350k Tranche Allocation Plan (inventory, marketing, R&D, personnel, working capital breakdown)
- Allocation Plan Approved by Steering Committee (Month 13 = 2027-11-08)
- Tranche Spending Authorization Issued (founder proceeds with planned investments)

**Dependencies:**

- EUR 350k tranche released by gate decision (Month 12.5 = 2027-10-23)
- Allocation options assessed and prioritized
- Steering Committee consultation completed

### 49. Post-gate governance review and continuous improvement: At Month 13 (2027-11-08) onward, Steering Committee transitions all five governance committees to Year-2 operational mode with updated charters, KPIs, and decision-making authority reflecting the newly released EUR 350k tranche. Activities include: (1) update Steering Committee charter to reflect expanded budget authority and any new strategic decisions (e.g., smaller SKU variant, server-grade cage feasibility study), (2) update each working committee charter with Year-2 responsibilities (Design & Certification: SKU variant design or deferred R&D; Production: increased volumes and potential multi-site sourcing; Presale/Revenue: ongoing marketing and distribution partnerships; Compliance: post-market monitoring and customer feedback; Financial Governance: continued monthly tracking, annual budget for Year-2, tranche spending reallocation rules), (3) schedule governance refresher meetings (all five committees, Month 13 = 2027-11-08) to confirm Year-2 engagement, (4) document lessons learned from Year-1 governance execution (what worked, what would improve), (5) establish Year-2 KPIs and success metrics for each committee. Continuous governance evolution ensures that the governance framework remains aligned with the venture's evolving scale and complexity.

**Responsible Body/Role:** Project Steering Committee (with input from all five working committees)

**Suggested Timeframe:** Month 13 (2027-11-08) onward

**Key Outputs/Deliverables:**

- Updated Steering Committee Charter for Year-2 (budget authority, strategic decisions, new risks)
- Updated Working Committee Charters for Year-2 (roles, responsibilities, decision rights under expanded budget)
- Governance Refresher Meetings Held (all five committees, Month 13 = 2027-11-08, Year-2 priorities confirmed)
- Year-1 Lessons-Learned Report (governance effectiveness, improvements for Year-2)
- Year-2 KPIs and Success Metrics (by committee, tied to EUR 350k tranche and growth targets)

**Dependencies:**

- Year-1 governance execution complete and EUR 350k tranche released
- Steering Committee and all five working committees fully operational
- Year-1 outcomes known (presale volume, delivered units, cash-flow gate result, customer feedback)

# Decision Escalation Matrix

**Accredited Lab Results Fall Short of Marketing Claims or Design Requires Redesign**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee reviews lab findings, assesses redesign scope (cost and timeline impact), decides whether to: (a) accept narrower attenuation/frequency-band claims (no redesign cost), (b) fund redesign from the EUR 20k reserve and schedule re-test (EUR 8–15k re-test cost, 2-month delay), or (c) halt the project. Decision made within 5 business days of receiving lab report. Approval requires consensus between founder and external advisor; if consensus cannot be reached, founder retains decision authority but advisor documents dissent.
Rationale: Accredited lab validation gates the hard-tooling release decision and defines the credibility of all product claims. Failed or compromised test results after prototype investment creates a critical path threat: re-testing consumes scarce budget (up to 35k total in worst case: costlier standard + re-test, vs. 20k reserve), delays hard-tooling release from Month 6 (2027-04-08) past the Month 6 (2027-04-08) hard deadline, compresses the presale fulfillment window before the cash-flow gate, and risks sunk cost in soft tooling. The decision determines whether the venture proceeds or requires restructuring.
Negative Consequences: Lab results falling 20–30% short of claims or revealing seam/gasket failures force a redesign costing EUR 8–15k (re-test) plus design iteration (1–2 weeks). Hard-tooling release slips from Month 6 (2027-04-08) to Month 7–8 (2027-05-08 to 2027-06-08), compressing production and presale fulfillment to 2–3 months before the cash-flow gate measurement window (Months 9–12 = 2027-07-08 to 2027-10-08). If fewer than 400–500 units are delivered by Month 12 (2027-10-08) due to manufacturing delay, the cash-flow gate (EUR 25k quarterly surplus, proposed threshold) is missed and the EUR 350k follow-on is withheld. Reputational damage if presale customers discover lab results underperform claims. In worst case (costlier standard + re-test = up to 35k total cost vs. 20k reserve), the EUR 15k gap forces either cutting the production batch size, deferring follow-on marketing, or founder capital contribution, all of which reduce the venture's runway and competitiveness.

**Net Presale Deposits Fall Below EUR 80k Threshold by Month 6 (2027-04-08), Blocking Hard-Tooling Release**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee reviews presale dashboard (deposit velocity, refund rate, segment mix) by Month 5.5 (2027-03-23). If deposits are trending below EUR 80k, committee assesses: (a) extend presale offer to Month 8 (2027-06-08) and defer hard-tooling release, with corresponding delay to batch 1 production, (b) reallocate marketing spend (shift EUR 10–15k from prepper to infrastructure/privacy channels) to accelerate higher-value segments, (c) reduce unit price by EUR 10–20 to stimulate conversion, or (d) halt hard tooling and prepare for wind-down. Decision and authorization issued by Month 6 (2027-04-08). Approval requires consensus; founder has final authority if advisor dissents.
Rationale: The EUR 80k presale-deposit threshold gates the hard-tooling commitment, protecting the founder's capital by ensuring demand is proven before irreversible manufacturing cost is incurred. Presale deposits fund the EUR 30k hard-tooling cost and validate market traction. If deposits fall short, committing hard tooling risks sunk cost on a product with unproven demand. The presale-demand signal is essential to reaching positive cash flow (EUR 25k quarterly surplus, proposed threshold) by the Month 12 (2027-10-08) gate measurement window. Weak deposits indicate either the narrative/positioning is not resonating, the price point is too high, or the lead time is too long; escalation allows for mid-course corrections before spending becomes irreversible.
Negative Consequences: Presale deposits trending below EUR 80k by Month 6 (2027-04-08) signal weak market traction. Proceeding with hard tooling without demand confirmation risks EUR 30k sunk cost for a product with no confirmed orders. If hard tooling is committed and presales remain weak (e.g., 50 units delivered by Month 12 = 2027-10-08), cumulative cash flow is EUR 3.35k (50 units × EUR 67 margin - EUR 20k recurring opex for the quarter), missing the EUR 25k gate by EUR 21.65k. The EUR 350k follow-on is withheld, halting inventory replenishment and marketing, forcing the venture to wind down or seek external funding with founder dilution. Alternatively, if escalation triggers a presale extension (defer hard tooling to Month 7 = 2027-05-08) but deposits remain weak, batch 1 delivery slips from Months 7–8 (2027-05-08 to 2027-06-08) to Months 8–9 (2027-06-08 to 2027-07-08), leaving only 2–3 months for fulfillment before the gate measurement window closes, further compressing cash-flow visibility. If escalation triggers a pricing cut (reduce EUR 149 list price to EUR 120–130) to stimulate presales, unit contribution margin falls to EUR 38–48 (from EUR 67), requiring 350+ units per quarter to achieve the EUR 25k gate (vs. 375 baseline), a 7–20% volume increase that may not materialize.

**Presale Segment Mix Skews Heavily Toward Low-Margin Prepper Units (>70% by Month 3 = 2027-01-08) While Infrastructure/Privacy Orders Remain Slow**
Escalation Level: Project Steering Committee and Presale and Revenue Validation Committee
Approval Process: Presale and Revenue Validation Committee identifies the trigger (prepper deposits > 70% of total) at Month 3 (2027-01-08) review and submits a marketing-pivot recommendation to Steering Committee within 5 business days. Recommendation includes: (a) immediate reallocation of EUR 10–15k marketing spend from prepper channels to infrastructure and privacy campaigns, (b) fast-track pilot agreements with 1–2 infrastructure buyers (pilot units at cost + 20%, delivery Month 5 = 2027-03-08) to generate in-time reference orders, (c) widening the multi-use RF-isolation narrative in messaging to attract corporate IT and privacy segments, (d) or, if pivot fails to accelerate higher-value deposits by Month 6 (2027-04-08), a presale cutoff or channel-mix reconsideration. Steering Committee approves the pivot within 3 business days. Approval requires founder and advisor consensus; founder has final authority.
Rationale: Presale segment mix directly determines unit economics and cash-flow gate feasibility. Prepper-dominant mix (>70%) yields low average order value (EUR 50–70, estimate) and thin unit margin (EUR 15–20 per unit, estimate, after lower pricing). High-value infrastructure orders (EUR 200–300+ per unit, margin EUR 60–120+ estimate) are essential to achieving the EUR 25k quarterly surplus gate. If presale deposits are 80% prepper (EUR 2.4k margin per 50 units) and 20% infrastructure (EUR 1.2k margin per 10 units), cumulative quarter cash flow is EUR 3.6k (50–60 units at blended EUR 60 margin) minus EUR 20k recurring opex = EUR –16.4k, missing the gate. Escalation triggers a strategic pivot to rebalance segment mix and increase the weighted-average unit margin before hard-tooling commitment locks the venture into a low-margin position.
Negative Consequences: If presale deposits skew 70–80% toward preppers by Month 3 (2027-01-08) and no corrective action is taken, the entire Year-1 presale base tilts toward low-margin units. Cumulative presale of EUR 80k (threshold) distributed as 70% prepper (EUR 56k, ~2,800 units at EUR 20 margin = EUR 56k contribution) and 30% higher-value (EUR 24k, ~100 units at EUR 100 margin = EUR 10k contribution) yields a blended contribution of EUR 66k across ~2,900 units, or EUR 22.75k per quarter (based on 3 months fulfillment window). This falls short of the EUR 25k gate threshold by EUR 2.25k. If the prepper mix reaches 80–90%, the shortfall widens to EUR 8–15k, guaranteeing gate failure. Infrastructure sales cycles (8–12 weeks from pilot to order) mean that fast-track pilots closed at Month 3 (2027-01-08) with delivery at Month 5 (2027-03-08) may not generate invoiced and paid revenue until Month 6–7 (2027-04-08 to 2027-05-08), missing the cash-flow gate measurement window (Months 9–12 = 2027-07-08 to 2027-10-08) entirely if subsequent infrastructure procurements stall. Without escalation and correction, the gate fails, EUR 350k is withheld, and the venture faces underfunding or wind-down.

**Actual Year-1 Burn Rate Exceeds Budget by >10% (e.g., Lab Fees, Design Iteration, or Soft-Tooling Costs Overrun) and EUR 400k Cap Is at Risk**
Escalation Level: Project Steering Committee
Approval Process: Financial Governance and Gate Measurement Committee flags any budget category exceeding plan by >10% (e.g., design 77k vs. 70k budget) in the monthly reconciliation. Issue is escalated to Steering Committee within 7 days of month-end. Steering Committee reviews: (a) whether overrun is a one-time variance (e.g., lab fee pre-payment) or a sustained burn-rate increase, (b) whether the EUR 20k redesign reserve can absorb the overrun, (c) whether a contingency draw or spending freeze is needed in other categories (e.g., reduce marketing spend from EUR 75k to EUR 65k), or (d) whether founder capital contribution is required. If accumulated variance exceeds EUR 20k (5% of 400k cap) by Month 6 (2027-04-08), a hard spending freeze is triggered for non-critical items until the issue is resolved. Approval requires consensus between founder and advisor; founder retains authority for any reduction in headcount or feature scope.
Rationale: The EUR 400k Year-1 budget cap is a user constraint and a core governance protection. Any material overrun compresses free contingency (baseline EUR 20k redesign reserve) and threatens the venture's ability to absorb a lab re-test (EUR 8–15k), a design revision, or unexpected fabrication delays. Early detection and escalation allow for spending adjustments before irreversible commitments are made (e.g., hard tooling at Month 6 = 2027-04-08). Overruns that occur after hard tooling (Month 6 = 2027-04-08 onward) cannot be corrected without cutting production batch size or marketing spend, both of which reduce presale fulfillment and cash-flow gate success.
Negative Consequences: Unchecked burn-rate overruns consume the EUR 20k redesign reserve and leave the venture with zero free contingency. If design iteration overruns by EUR 15k (e.g., EMC consultancy milestone fees exceed EUR 25k due to scope creep) and a lab re-test is then required (EUR 8–15k), the total contingency draw is EUR 23–30k, exceeding the EUR 20k reserve by EUR 3–10k. With zero production headroom in the budget, the shortfall must be absorbed by cutting production batch size (e.g., from 1,500 units to 1,200–1,400 units, reducing Year-1 revenue by EUR 45–90k), deferring marketing spend (reducing presale volume by 10–20%), or requesting founder capital contribution (which signals distress and weakens the staged-funding gate logic). Any of these outcomes reduces presale volume and cash-flow gate feasibility. In worst case, burn-rate overruns consume the entire EUR 400k by Month 10 (2027-08-08) with insufficient production or fulfillment capacity remaining, and the EUR 350k follow-on is withheld, leaving the venture starved of inventory and marketing capital in Months 11–12 (2027-09-08 to 2027-10-08) when cash-flow gate measurement occurs.

**Regulatory Challenge or Product-Liability Claim Emerges (EMC Directive Applicability Confirmed, CE Marking Required, or Customer Injury/Misrepresentation Claim Filed)**
Escalation Level: Project Steering Committee (with Compliance and Liability Committee support)
Approval Process: Compliance and Liability Committee receives notice of regulatory inquiry or customer claim and immediately escalates to Steering Committee. Committee convenes within 48 hours to assess: (a) whether the EMC Directive applies and CE marking is required (if confirmed, EUR 10–30k and 8–12 weeks needed for notified-body assessment, not budgeted), (b) whether product-liability insurance covers the claim (coverage review with insurer within 24 hours), (c) whether marketing claims or scope statements must be revised to mitigate further exposure, (d) cost and timeline impact, and (e) whether the EUR 400k cap or EUR 350k tranche release is affected. If regulatory requirement is confirmed and unfunded (CE marking required, EUR 10–30k overrun, estimate), Steering Committee decides: (i) seek an expedited regulatory pathway (cost/timeline trade-off), (ii) defer CE compliance to post-gate (risk ongoing sales without compliance), or (iii) halt presale marketing and seek founder capital contribution or external funding. Approval requires founder decision with advisor input within 5 business days of regulatory notification.
Rationale: Product-safety and liability exposure are existential risks for a hardware startup. The Faraday enclosure is marketed for protection against rare electromagnetic events; failed claims or regulatory non-compliance in a real-world event create reputational and legal liability that can exceed company reserves and founder's personal assets. The plan assumes General Product Safety Directive applicability (not verified) and no CE marking requirement, but if either assumption is wrong, unfunded regulatory work (EUR 10–30k estimate, 8–12 weeks estimate) emerges. Rapid escalation enables the Steering Committee to decide whether to accept compliance cost and delay, defer compliance (accepting legal risk), or restructure the venture. Unescalated compliance issues discovered during presale or fulfillment create customer-facing friction (product recalled, claims denied by insurance) and reputational damage that is difficult to repair.
Negative Consequences: If the EMC Directive applies and CE marking is required (not verified), EUR 10–30k (estimate) and 8–12 weeks (estimate) are needed for notified-body assessment. With zero production headroom in the EUR 400k budget, the full cost must be absorbed by cutting production batch size (reducing Year-1 units from 1,500 to 1,200–1,400, losing EUR 45–75k revenue, estimate), deferring hard tooling (slipping batch 1 from Month 8 = 2027-06-08 to Month 10–11 = 2027-08-08 to 2027-09-08, leaving only 1–2 months for fulfillment before gate measurement closes), or requesting founder capital contribution. Any delay compresses the presale fulfillment window and risks missing the EUR 25k quarterly surplus gate by reducing delivered-unit volume. If a product-liability claim is filed (customer loss in an electromagnetic event, alleging breach of warranty or misrepresentation), product-liability insurance may deny coverage if claims exceed policy limits or if the policy excludes Faraday-enclosure claims (insurability not verified). Founder is exposed to uninsured liability, legal defense costs (EUR 10–50k, estimate), potential settlement or judgment, and reputational damage. Presale conversion falls 30–50% (estimate) as early adopters and infrastructure buyers flee the brand. The gate fails due to presale collapse and reputational damage to future sales.

**Tallinn Primary Fabricator Signals Capacity Loss, Price Increase >10%, or Supply-Chain Disruption (Gasket Material Delay, Freight Constraint) Threatens Batch 1 Production Schedule**
Escalation Level: Production and Supply Chain Committee (with Steering Committee escalation if cost/timeline impact is material)
Approval Process: Production and Supply Chain Committee meets weekly and flags any supplier risk (capacity, pricing, lead time) immediately. If primary fabricator signals a price increase >10% (EUR 70 unit cost + 10% = EUR 77, reducing margin by EUR 7 per unit) or capacity loss, committee assesses secondary fabricator readiness within 3 business days. If secondary fabricator can absorb the batch at locked pricing within 2-week timeline loss, production transition is authorized immediately without Steering Committee escalation. If secondary fabricator cannot meet timeline or cost, the cost impact and timeline slip (e.g., Batch 1 delivery slips from Month 8 = 2027-06-08 to Month 9 = 2027-07-08, losing 3–4 weeks of presale fulfillment window) are escalated to Steering Committee within 5 business days. Steering Committee decides: (a) absorb the cost increase within the EUR 20k reserve (if <EUR 10k impact), (b) defer production batch or reduce batch size to offset cost, or (c) request founder capital contribution. For gasket supply disruption (material delays >2 weeks), buffer-stock protocol is triggered: secondary gasket supplier is activated within 48 hours, expedited delivery is ordered (at premium cost, EUR 2–5k estimate), or production lead time is extended 1–2 weeks to allow primary supplier recovery. Approval requires founder sign-off within 3 business days.
Rationale: Production schedule is the critical path for presale fulfillment and cash-flow gate success. Batch 1 must be delivered by Month 8 (2027-06-08) to allow 3–4 months of fulfillment (Months 8–12 = 2027-06-08 to 2027-10-08) before the gate measurement window closes. Any supply-chain disruption that delays Batch 1 beyond Month 9 (2027-07-08) compresses the fulfillment window to 2–3 months, reducing delivered-unit volume and cash-flow gate success. Fabricator price increases directly reduce unit margin (EUR 70 unit cost increases to EUR 77 = EUR 7 margin loss per unit × 1,500 units = EUR 10.5k annual impact, reducing cash-flow gate result by 50%). Early detection and escalation enable contingency activation (secondary supplier, buffer-stock protocol) before delivery slips occur.
Negative Consequences: If the primary fabricator increases unit cost by 10% (EUR 70 → EUR 77) and Steering Committee defers the decision (no escalation), the margin compression (EUR 7 per unit × 1,500 units = EUR 10.5k annual loss, estimate) is discovered only at gate measurement in Month 12 (2027-10-08). Cash-flow gate result falls from EUR 30.25k (baseline) to EUR 19.75k, missing the EUR 25k threshold by EUR 5.25k and triggering gate ambiguity (-5k to +25k range, tiebreak rule applies). Founder discretion is required to extend 90 days and re-measure, adding governance complexity and delaying tranche release into Month 14 (2027-12-08) onward. If fabricator signals capacity loss and production batch is deferred from Month 8 (2027-06-08) to Month 10 (2027-08-08), only 2 months remain for fulfillment before the gate measurement window (Months 9–12 = 2027-07-08 to 2027-10-08) closes. Batch 1 delivery of 800 units is split: ~400 units delivered by Month 12 (2027-10-08) (counted toward gate), ~400 units delivered in Months 13+ (post-gate, not counted). Cash flow falls by ~EUR 13.5k (400 units × EUR 67 margin, estimate), bringing gate result to approximately EUR 16.75k and triggering gate failure. Gasket-material supply disruption (2–4 week delay, estimate) halts production entirely until secondary supplier activates; if secondary supplier requires premium pricing (EUR 2–5k estimate, 3–5% of EUR 105k unit cost budget), contingency is triggered and EUR 20k reserve is drawn down, leaving zero buffer for design issues or other overruns.

# Monitoring Progress

### 1. Tracking Key Performance Indicators (KPIs) Against Project Plan
**Monitoring Tools/Platforms:**

  - Monthly Year-1 Burn Schedule Tracking Spreadsheet
  - Presale Dashboard (deposits, refunds, segment mix, conversion rate, AOV)
  - Production Status Dashboard (batch progress, unit cost, defect rate)
  - Quarterly Cash-Flow Reconciliation Template

**Frequency:** Monthly (within 7 days of month-end) with quarterly deep-dives; special reviews at Months 5 (2027-03-08), 6 (2027-04-08), and 12 (2027-10-08)

**Responsible Role:** Financial Governance and Gate Measurement Committee (Operations/Finance lead with founder and external advisor oversight)

**Adaptation Process:** If any budget category exceeds plan by >10%, the Financial Governance Committee flags the variance and proposes reallocation or spending freeze within 3 business days. Steering Committee approves reallocation (>EUR 5k) within 3 days. If cumulative variance exceeds EUR 20k (5% of EUR 400k cap) by Month 6 (2027-04-08), a hard spending freeze is triggered. Monthly dashboard is shared with Steering Committee for review at monthly meetings.

**Adaptation Trigger:** Any budget category variance >10% (e.g., design 77k vs. 70k budget); cumulative month-to-date burn >10% above plan; cash balance falling below 2-month runway; presale conversion falling below 40% (estimated) by Month 3 (2027-01-08)

### 2. Accredited EMC Laboratory Validation and Design Certification Readiness Monitoring
**Monitoring Tools/Platforms:**

  - Accredited Lab Statement of Work and Timeline (fixed cost EUR 15k, report delivery Month 5 = 2027-03-08)
  - In-House Test Rig Validation Report (two independent seam cycles, attenuation data)
  - Lab Design-Readiness Review Documentation (pre-submission assessment, Month 4 = 2027-02-08)
  - Lab Test Report (attenuation curves, frequency sweep, summary, recommendations)

**Frequency:** Bi-weekly Design & Certification Working Group meetings; special deep-dive reviews at Month 4 (2027-02-08) for design-readiness review and Month 5 (2027-03-08) for report assessment; emergency meeting if redesign scope emerges

**Responsible Role:** Design and Certification Working Group (EMC Consultancy, University Lab, Founder, Accredited Lab liaison)

**Adaptation Process:** If in-house rig validation fails to pass two independent seam cycles by Month 3 (2027-01-08), Design & Certification group assesses redesign scope and cost impact and escalates to Steering Committee with options: (a) minor seam adjustments (cost EUR 2-5k, 1-week delay), (b) major redesign (EUR 10-15k, 4-6 week delay, uses redesign reserve), or (c) narrower claims (no redesign). If accredited lab pre-test (Month 4 = 2027-02-08) raises design concerns, group decides whether to: (a) incorporate lab feedback and revise design pre-submission, (b) proceed with submission and accept re-test risk, or (c) defer and extend timeline. If lab report (Month 5 = 2027-03-08) falls short of claims, Steering Committee decides: (a) accept narrower attenuation/frequency-band claims (no cost), (b) fund redesign from EUR 20k reserve and re-test (EUR 8-15k, 2-month delay), or (c) halt project.

**Adaptation Trigger:** In-house rig validation shows attenuation >20% below target or seam/gasket degradation after two cycles (fail trigger: <50 dB estimate, to be confirmed by lab standard); lab pre-test raises design concerns requiring changes; lab report shows attenuation 10-20% below claims (triggers design-revision assessment) or >20% below (triggers hard decision: accept narrower claims or redesign); lab recommends costlier standard (MIL-STD-285 vs. IEEE 299.1 estimate) adding >EUR 10k overrun

### 3. Presale Deposit Acquisition and Demand Validation Mechanism Monitoring
**Monitoring Tools/Platforms:**

  - Weekly Presale Dashboard (gross deposits, refunds, net deposits by segment: prepper, infrastructure, privacy/forensics)
  - Conversion-Rate and AOV Tracking (deposit rate % by segment, average order value EUR by segment)
  - Presale Campaign Performance Log (marketing spend by channel, cost-per-deposit, messaging resonance notes)
  - Deposit Account Audit Trail (daily deposits and refunds reconciliation in separate earmarked account)

**Frequency:** Weekly (Mondays, 30-45 minutes) for presale dashboard review and segment-mix assessment; monthly (tied to Steering Committee calendar) for deep-dive segment analysis and pivot trigger evaluation; special reviews at Month 3 (2027-01-08) for prepper >70% pivot trigger, Month 6 (2027-04-08) for hard-tooling gate confirmation (deposits >=EUR 80k), Month 8 (2027-06-08) for presale cutoff enforcement

**Responsible Role:** Presale and Revenue Validation Committee (Founder, Operations/Finance, External Advisor liaison)

**Adaptation Process:** If prepper deposits exceed 70% of total by Month 3 (2027-01-08), committee issues an immediate marketing-pivot recommendation to Steering Committee: reallocate EUR 10-15k from prepper to infrastructure/privacy channels, widen RF-isolation narrative in messaging, establish fast-track infrastructure pilots (pilot units at cost +20%, delivery Month 5 = 2027-03-08). Steering Committee approves reallocation within 3 business days. If presale conversion falls below 40% (estimated) by Month 3 (2027-01-08), committee assesses: (a) pricing cut (EUR 149 → EUR 120-130), (b) channel shift, (c) messaging revision, or (d) extended presale window. If net deposits fall below EUR 80k by Month 6 (2027-04-08), hard-tooling gate is not released; committee recommends presale extension to Month 8 (2027-06-08) or go/no-go decision. If refund rate exceeds 20% (estimated) by Month 6 (2027-04-08), committee escalates delivery or messaging issues to Steering Committee and Design & Certification group (fit problems) for rapid corrective action.

**Adaptation Trigger:** Prepper deposits >70% of total by Month 3 (2027-01-08) (triggers marketing pivot); presale conversion rate <40% (estimated) by Month 3 (2027-01-08) (triggers strategy reassessment); average order value <EUR 50 (estimated) by Month 3 (2027-01-08) (triggers channel or pricing review); net deposits <EUR 80k (proposed threshold) by Month 6 (2027-04-08) (gates hard-tooling release); refund rate >20% (estimated) by Month 6 (2027-04-08) (escalates messaging/delivery issues); presale deposit account shows operational withdrawals (ring-fencing violation, immediate correction required)

### 4. Hard-Tooling Release and Production Gate Confirmation Monitoring
**Monitoring Tools/Platforms:**

  - Presale Deposit Account Balance and Net Confirmation (deposits minus refunds, verified by Month 6 = 2027-04-08)
  - Accredited Lab Design-Certification Sign-Off Letter (design certified, no major redesign concerns)
  - In-House Rig Validation Pass Documentation (two independent seam cycles completed, pass/fail criteria met)
  - Hard-Tooling Gate Confirmation Document (founder and external advisor jointly signed authorization, Month 6 = 2027-04-08)
  - Hard-Tooling Purchase Order (fabricator commitment, cost locked EUR 30k estimate, delivery schedule confirmed)

**Frequency:** Weekly Production & Supply Chain Committee meetings (starting Month 6 = 2027-04-08); Month 5 (2027-03-08) special Steering Committee review to assess gate readiness; Month 6 (2027-04-08) gate-confirmation sign-off meeting

**Responsible Role:** Financial Governance and Gate Measurement Committee (gate confirmation); Production and Supply Chain Committee (tooling order execution)

**Adaptation Process:** At Month 5 (2027-03-08), Steering Committee holds special meeting to confirm: (1) accredited lab pre-test confirms design readiness (yes/no), (2) in-house rig validation passes twice (yes/no), (3) presale deposits on track for EUR 80k by Month 6 (2027-04-08) (yes/no). If all three criteria are met, Steering Committee issues 'gate conditional' approval authorizing hard-tooling order upon final deposit confirmation. At Month 6 (2027-04-08), Financial Governance Committee confirms net deposits >=EUR 80k, founder and advisor jointly sign Gate Confirmation Document, and Production & Supply Chain Committee immediately submits hard-tooling purchase order to primary fabricator. If deposits fall short (EUR 70-79k), committee recommends presale extension to Month 8 (2027-06-08) with corresponding batch 1 delay. If deposits are significantly short (<EUR 60k), committee recommends no hard-tooling commitment and go/no-go decision by founder and advisor on project continuation.

**Adaptation Trigger:** Net presale deposits reach EUR 80k by Month 6 (2027-04-08) (gate PASS: authorize hard tooling); deposits fall below EUR 80k by Month 6 (2027-04-08) (gate FAIL/EXTEND: presale extended to Month 8 = 2027-06-08, batch 1 delayed); accredited lab report shows design not certified or requires redesign (gate CONDITIONAL: redesign decision required before hard tooling); in-house rig validation shows failure of first or second seam cycle (gate HOLD: investigation and corrective action required)

### 5. Cash-Flow Gate Measurement and EUR 350k Tranche Release Decision Monitoring
**Monitoring Tools/Platforms:**

  - Monthly Cash-Flow Reconciliation Dashboard (budget vs. actuals, presale deposits liability, delivered-unit revenue, opex, runway)
  - Delivered-Unit Revenue Tracking (units shipped, invoiced, paid; sample audit 10-15% of receipts)
  - Direct Cost and Opex Reconciliation (unit cost EUR 70 estimate, freight EUR 12 estimate, recurring opex EUR 20k/quarter estimate)
  - Gate Calculation Template (operating surplus = delivered-unit revenue - direct costs - opex; threshold EUR 25k quarterly)
  - Gate Measurement Sign-Off Document (founder and external advisor co-signature, Month 12.5 = 2027-10-23)

**Frequency:** Monthly (within 7 days of month-end) for cash reconciliation; quarterly (Months 3, 6, 9, 12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08) for deep-dive analysis and advisor sign-off; special gate-measurement meeting at Month 12.5 (2027-10-23) for final result sign-off and tranche decision

**Responsible Role:** Financial Governance and Gate Measurement Committee (Operations/Finance lead, External Advisor, Founder)

**Adaptation Process:** Monthly cash-reconciliation tracks actual spending vs. EUR 400k Year-1 cap and presale deposit liability segregation. Quarterly reviews assess progress toward gate (EUR 25k quarterly operating surplus, Months 9-12 = 2027-07-08 to 2027-10-08). By Month 11 (2027-09-08), committee begins final gate-measurement calculation: sum delivered-unit revenue for Months 9-12 (2027-07-08 to 2027-10-08), subtract direct costs (EUR 82/unit estimate), subtract recurring opex (EUR 20k/quarter estimate), calculate surplus. If result is clear PASS (>=EUR 25k), founder and advisor sign Gate Confirmation by Month 12.5 (2027-10-23) and recommend EUR 350k tranche release. If result is FAIL (<EUR 25k), root-cause analysis is conducted and decision made: (a) if in ambiguous range (-EUR 5k to +EUR 25k estimate), tiebreak rule applies (founder may extend 90 days and re-measure, or founder decides tranche release based on advisor guidance), (b) if clearly below threshold (<-EUR 5k), tranche is withheld and founder reviews wind-down or extension strategy. Gate result and tiebreak decision (if any) are documented in writing with both founder and advisor signatures.

**Adaptation Trigger:** Operating cash surplus (Months 9-12 = 2027-07-08 to 2027-10-08) is >=EUR 25k (gate PASS: tranche released); operating surplus is <EUR 25k but >-EUR 5k (gate AMBIGUOUS: tiebreak rule applies, founder may extend 90 days); operating surplus is <-EUR 5k (gate FAIL: tranche withheld, restructuring decision required); monthly burn rate exceeds budget by >10% (triggers reallocation or freeze); months of runway fall below 2 months at current burn rate (triggers emergency action)

### 6. Supply-Chain Risk and Production Execution Monitoring
**Monitoring Tools/Platforms:**

  - Primary and Secondary Fabricator Agreements (pricing locked, capacity reserved, delivery dates, price-cap clauses)
  - Gasket Supplier Agreements (primary and backup, material spec, lead times, buffer stock EUR 5-10k estimate)
  - Production Status Report (weekly units produced, quality metrics, lead-time forecast, defect findings)
  - Quality-Control Inspection Checklist (in-process seam integrity, gasket seating, fit testing, final packing)
  - Supply-Chain Risk Register (supplier concentration, material delays, capacity constraints, mitigation actions)

**Frequency:** Weekly (bi-weekly starting Month 2 = 2026-12-08) Production & Supply Chain Committee meetings (45-60 minutes); monthly deep-dive reviews at Months 2, 4, 6, 8, 10, 12 (2026-12-08, 2027-02-08, 2027-04-08, 2027-06-08, 2027-08-08, 2027-10-08) with fabricator and supplier status updates; emergency meeting if supplier signals capacity loss, price increase >10%, or delivery delay >2 weeks

**Responsible Role:** Production and Supply Chain Committee (Founder, Primary Fabricator, Backup Fabricator, Gasket Suppliers, Freight Carrier, Operations/Finance)

**Adaptation Process:** Weekly status reviews flag any supplier risk (capacity, pricing, lead time). If primary fabricator signals price increase >10% (EUR 70 unit cost +10% = EUR 77, reducing margin EUR 7/unit), committee assesses secondary fabricator readiness within 3 business days. If secondary can absorb batch at locked pricing within 2-week timeline loss, production transition authorized immediately. If secondary cannot meet criteria, cost/timeline impact escalated to Steering Committee (e.g., EUR 10.5k margin loss for 1,500 units, or batch 1 delivery slip from Month 8 = 2027-06-08 to Month 9 = 2027-07-08). For gasket supply disruption (material delays >2 weeks), buffer-stock protocol triggered: secondary supplier activated within 48 hours, expedited delivery ordered (EUR 2-5k premium estimate), or production lead time extended 1-2 weeks. If hard-tooling delivery from primary fabricator is delayed >2 weeks, secondary fabricator is notified immediately and transition authorization issued within 5 business days. If Batch 1 delivery slips beyond Month 9 (2027-07-08), presale fulfillment window compresses and Steering Committee is notified of impact on cash-flow gate feasibility.

**Adaptation Trigger:** Primary fabricator price increase >10% (triggers secondary-supplier assessment); primary fabricator capacity loss signaled (triggers secondary-supplier transition authorization); gasket material supply delay >2 weeks (triggers backup supplier activation); hard-tooling delivery delayed >2 weeks from committed date (triggers secondary-tooling assessment); Batch 1 production delays >1 week (updated fulfillment forecast shared with Steering Committee); unit cost variance >5% (EUR 70 ±EUR 3.50 estimate) due to material or waste inflation (triggers cost-mitigation assessment)

### 7. Compliance, Legal, and Liability Posture Monitoring
**Monitoring Tools/Platforms:**

  - Legal Opinion on Applicable EU Product Rules (EMC Directive, General Product Safety Directive, consumer-protection duties, Month 1 = 2026-11-08)
  - Product-Liability Insurance Policy (coverage limits EUR 250-500k estimate, terms locked Month 2.5 = 2026-12-23)
  - Compliance Checklist (8 items: claim limiting, scope statement, warranty/refund terms, insurance status, lab report publication, presale SLA, no grid-scale protection claims, warranty limits)
  - Monthly Compliance Audit Report (sample review of marketing materials, website, email, product packing insert; drift detection and correction log)

**Frequency:** Monthly (starting Month 2.5 = 2026-12-23) compliance audits (sample of presale materials reviewed); quarterly escalations (Months 3, 6, 9, 12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08) to Steering Committee with audit summary; special reviews at legal-opinion receipt (Month 1 = 2026-11-08) and insurance lock-in (Month 2.5 = 2026-12-23)

**Responsible Role:** Compliance and Liability Committee (Founder, External Legal Counsel, Product-Liability Insurer, Design & Certification liaison)

**Adaptation Process:** Legal opinion findings (Month 1 = 2026-11-08) determine regulatory roadmap: if EMC Directive applies, CE marking requirement is identified and cost/timeline impact (EUR 10-30k estimate, 8-12 weeks estimate) is escalated to Steering Committee for decision (proceed with CE work, defer compliance to post-gate accepting legal risk, or halt project). Insurance terms are locked by Month 2.5 (2026-12-23); if insurer declines coverage or imposes exclusions for Faraday-enclosure claims, Steering Committee assesses risk exposure and decides on claim narrowing or alternative insurance. Monthly compliance audits (starting Month 2.5 = 2026-12-23) review presale marketing, website, emails, and product materials against the 8-item checklist. If drift is detected (e.g., marketing copy mentions 'grid-scale protection'), founder is notified and has 3 business days to correct materials. If customer complaint or regulatory inquiry is received, immediate escalation to Steering Committee and legal counsel within 48 hours; assessment of claim-revision risk and reputational impact conducted within 5 business days.

**Adaptation Trigger:** Legal opinion confirms EMC Directive applicability, requiring CE marking (unfunded, EUR 10-30k estimate, 8-12 weeks estimate, escalates to Steering Committee for go/no-go decision); product-liability insurer declines coverage or imposes significant exclusions (escalates to Steering Committee and legal counsel for risk assessment); monthly compliance audit detects marketing drift (claim limiting violation, scope statement absent, warranty terms inconsistent) - founder corrects within 3 business days or escalates; customer complaint or regulatory inquiry received (immediate escalation to legal counsel and Steering Committee within 48 hours); presale refund request citing misrepresentation or fit issues (reviewed for pattern; if >10% of orders by Month 7 = 2027-05-08, triggers messaging or design review)

### 8. Presale Fulfillment Performance and Delivery Lead-Time Monitoring
**Monitoring Tools/Platforms:**

  - Daily Presale Order Queue (orders chronologically ordered, build-to-order confirmation and delivery estimate provided to each customer)
  - Weekly Fulfillment Status Report (units shipped, in-queue, defects/returns, refunds processed)
  - Delivery Performance Tracking (delivery target vs. actual, customer satisfaction notes, complaints logged)
  - Inventory Days Outstanding (target 30-40 days for presale batch, 1.5x turnover per month target)

**Frequency:** Daily order queue management (operations person); weekly fulfillment dashboard updates (Mondays); monthly fulfillment review tied to Steering Committee and Presale Committee calendars; special tracking at Month 8 (2027-06-08) presale cutoff and Month 12 (2027-10-08) gate measurement window

**Responsible Role:** Presale and Revenue Validation Committee (Operations/Finance lead, Production & Supply Chain coordination)

**Adaptation Process:** Daily operations verify presale-to-production coordination: presale order queue is matched against production schedule from fabricator, build-to-order confirmation sent to customer with 2-3 week delivery estimate, unit receipt from fabricator inspected for quality, packing includes accredited lab report and scope statement, shipment tracking provided to customer. Weekly fulfillment dashboard tracks units shipped, refunds issued, delivery-time compliance. If delivery lead times exceed 3.5 weeks (estimate) for >10% of orders, logistics partner or fabricator performance is escalated to Production & Supply Chain Committee within 3 business days. If fit complaints exceed 10% of orders by Month 7 (2027-05-08), Design & Certification group assesses root cause (enclosure design, size variant mismatch, or customer expectation mismatch) and recommends: (a) minor design tweak (if feasible within production run), (b) fit guide publication (educate future customers), or (c) phone-only SKU variant study (funded post-gate). If refund rate exceeds 20% (estimated) in any month, Presale Committee escalates causes (delivery delays, fit issues, changed mind due to news cycle) to Steering Committee for messaging or operational corrective action.

**Adaptation Trigger:** Delivery lead time exceeds 3.5 weeks (estimate) for >10% of presale orders (escalates logistics/production issues); fit complaints exceed 10% of orders by Month 7 (2027-05-08) (triggers design review or smaller-SKU variant study); refund rate exceeds 20% (estimated) in any month (escalates messaging or delivery issues); customer satisfaction score on delivery or product quality falls below 4/5 (estimate) for two consecutive months (triggers quality or process review)

# Governance Extra

## Governance Validation Checks

1. Completeness Confirmation: All core governance components are generated across five stages. Stage 1 (Audit Details) covers anti-corruption and misallocation risks with 15 audit procedures. Stage 2 (Internal Governance Bodies) defines five committees with clear charters, decision rights, and escalation paths. Stage 3 (Implementation Plan) details 29 sequential steps from Month 0 (2026-10-08) to Month 13+. Stage 4 (Escalation Matrix) covers six critical decision issues with approval processes and consequences. Stage 5 (Monitoring Progress) establishes seven monitoring approaches with KPIs, tools, and adaptation triggers. All major project constraints (EUR 400k Year-1 cap, EUR 350k conditional tranche, single SKU, Tallinn production, presale-gated hard tooling, cash-flow gate definition) are embedded in governance frameworks.
2. Internal Consistency Check: Logical alignment across stages is confirmed with identified discrepancies. Implementation Plan correctly references all five governance bodies and gates hard-tooling release on presale deposits (EUR 80k threshold) and accredited lab pre-test confirmation (Month 5–6 = 2027-03-08 to 2027-04-08). Escalation Matrix maps hard-tooling gate, segment-mix pivot, burn-rate overruns, regulatory challenges, and supply-chain risks to appropriate approval bodies (Steering Committee or working committees). Monitoring Progress tracks gate measurement using delivered-unit revenue only (no presale deposits counted), consistent with the cash-flow gate definition. However, one discrepancy exists: the Implementation Plan (Step 17) and Monitoring Progress both reference EUR 25k quarterly threshold but do not explicitly confirm how this threshold was derived from the baseline case (750 units × EUR 67 margin – EUR 20k opex = EUR 30.25k). This derivation is in the canonical facts but absent from governance rollout documents; recommend clarification in the cash-flow gate convention (Month 0.5 = 2026-10-23) to ensure stakeholder understanding. Minor inconsistency: Compliance Committee charter references product-liability insurance coverage confirmation by Month 2.5 (2026-12-23), but Implementation Plan (Step 15) schedules insurance lock-in at Month 2.5 (2026-12-23) without explicit pre-engagement of insurers; recommend Month 1.5 (2026-11-23) insurer outreach to confirm feasibility before lock-in deadline.
3. Clarity of Roles and Authority—Gaps Identified: (a) Project Sponsor (founder) role is clear as ultimate decision authority within the governance framework (Steering Committee final say, tiebreak authority on gate result), but escalation path for decisions that founder and advisor cannot resolve (beyond the gate result) is undefined. If a major governance dispute arises (e.g., disagreement on gate measurement methodology, compliance requirement interpretation), no third-party arbitration or escalation above the Steering Committee exists; recommend documenting a tiebreak protocol (e.g., external advisor role expanded to include arbitration, or a named advisory board member with veto authority). (b) Role of external financial advisor is defined narrowly as co-signatory on gate result and monthly cash-reconciliation reviewer, but unclear whether advisor has authority to halt spending, demand re-measurement, or escalate to founder independently if cash reconciliation shows gaming or fraud (e.g., presale deposits being misclassified as operational cash). Recommend expanding advisor charter to include independent audit authority and right to escalate concerns to founder within 24 hours without filter. (c) Design & Certification Working Group decision authority is clear for technical design choices, but ownership of 'claim-to-evidence alignment' (ensuring marketing claims do not exceed lab-measured attenuation) is split between Design & Certification and Compliance & Liability committees; if a design change is made post-lab-report that affects claims, responsibility for notifying both committees and revising marketing is unclear. Recommend assigning explicit responsibility: Design & Certification group updates lab-validated claim scope; Compliance & Certification group audits all published marketing within 5 business days.
4. Process Depth—Missing Definition of Key Operational Processes: (a) Conflict of Interest and Whistleblower Protocol: The governance framework does not define procedures for detecting or managing conflicts of interest (e.g., founder bias in supplier selection, advisor financial stake in gate outcome, preferred lab bias toward favorable results). Recommend adding a Conflict of Interest Disclosure requirement at Month 0.5 (2026-10-23) for all governance committee members and suppliers; establish a confidential escalation channel (external ombudsman or advisor) for concerns about governance integrity. (b) Change Control and Scope Creep: Implementation Plan allows presale pivot (reallocation of EUR 10–15k marketing spend) and design changes (seam redesign, gasket material swap) within the EUR 20k reserve without formal change-control procedures. No structured assessment of cumulative impact (e.g., two design changes totaling EUR 12k plus one marketing reallocation totaling EUR 15k = EUR 27k total scope drift) is documented. Recommend adding a Change Control Log (Month 1 = 2026-11-08 onward) tracking all changes >EUR 1k or >1 week impact with cumulative impact dashboard reviewed at each Steering Committee meeting. (c) Stakeholder Communication Protocol: The framework defines presale terms and scope statements but does not specify how product changes, delays, compliance findings (e.g., insurance exclusions), or gate measurement results are communicated to presale customers. Recommend documenting an escalation communication protocol (e.g., 'If lab report shows attenuation 10–20% below claims, founder notifies presale customers within 3 business days with revised specifications and refund option'). (d) Succession and Knowledge Continuity: The governance framework is founder-centric with advisor as a secondary role. If founder becomes unavailable (illness, family, visa), no documented backup decision-maker or knowledge transfer is defined beyond 'backup operations contact' (risk mitigation in Risk 15). Recommend establishing a formal Governance Succession Plan by Month 1 (2026-11-08) naming a backup founder authority (e.g., advisor assumes founder decision authority if founder is unavailable >2 weeks) and documenting critical knowledge (supplier contracts, customer lists, financial procedures) in a shared encrypted location.
5. Thresholds and Delegation—Granularity Gaps: (a) Monthly spending freeze trigger (EUR 20k cumulative variance by Month 6 = 2027-04-08) is clear, but no sub-threshold escalation triggers are defined for categories (e.g., if design spending exceeds EUR 70k plan by 15% = EUR 10.5k, does it escalate immediately or is it absorbed within the 10% variance tolerance per category?). Recommend clarifying variance thresholds: 5–10% variance = Operations/Finance person flags and proposes reallocation; >10% variance in any category = escalated to Steering Committee within 3 business days; cumulative YTD variance >EUR 15k (4% of cap) = spending freeze trigger. (b) Presale pivot decision (Marketing spend reallocation if prepper deposits >70%) is clear, but no granular guidance exists for smaller pivots (e.g., if prepper deposits are 65–70%, is a 5k reallocation recommended?). Recommend defining graduated response: 60–70% prepper = 5k reallocation to infrastructure; 70–80% = 10k reallocation; >80% = halt prepper marketing and focus all EUR 75k on infrastructure/privacy. (c) Production batch timing and quality-control acceptance criteria are not defined in governance terms. Fabricator delivers Batch 1 by Month 8 (2027-06-08) (estimate), but acceptance criteria (defect rate <X%, seam inspection pass rate >X%, fit-test pass rate >X%) are not documented; recommend establishing a Quality Acceptance Plan by Month 2 (2026-12-08) with pass/fail thresholds, inspection log, and authority to accept, quarantine, or reject batches.
6. Integration Gaps—Audit and Monitoring Linkage: (a) The five governance committees have well-defined monitoring tools (dashboards, reports, checklists) but no formal audit-close-the-loop procedure is documented. For example, if the Presale Committee flags a refund-rate overrun (>20% by Month 6 = 2027-04-08), the trigger escalates to Steering Committee, but no structured follow-up (corrective action plan, re-audit after 2 weeks) is defined; recommend adding Audit Follow-Up Procedure: all flags escalated to Steering Committee require a documented corrective action by Month X, with re-audit scheduled 2 weeks post-correction. (b) Compliance Committee conducts monthly audits, but findings are not automatically integrated into Design & Certification or Presale committees; if a compliance audit detects marketing drift (e.g., claims exceeding lab data), responsibility for notifying Design & Certification (to assess claim-evidence alignment) and Presale (to halt non-compliant marketing) is undefined. Recommend establishing a Compliance Alert Protocol: any flag detected in monthly audit is escalated to Design & Certification and Presale within 1 business day with a required response (correction or escalation to Steering Committee) within 3 business days. (c) Supply-chain risk register (Production Committee) and financial cash-flow tracking (Financial Governance Committee) operate independently; if supply-chain disruption causes batch 1 delay (Batch 1 slips from Month 8 = 2027-06-08 to Month 9 = 2027-07-08), impact on cash-flow gate (fewer units delivered by Month 12 = 2027-10-08) is not automatically calculated or escalated to Financial Governance Committee. Recommend integrating supply-chain and financial monitoring: Production Committee flags batch delays to Financial Governance Committee with projected delivered-unit impact; Financial Governance Committee updates cash-flow gate projection accordingly and escalates to Steering Committee if impact >EUR 5k.

## Tough Questions

1. By Month 0.5 (2026-10-23), has the cash-flow gate measurement convention been published in writing and confirmed in writing by both the founder and external advisor? Specifically, what is the exact formula for calculating 'operating cash surplus' (revenue sources, cost deductions, opex inclusions), and how will disputes about invoice timing or cost allocation be resolved? Show the signed convention document.
2. By Month 1.5 (2026-11-23), has a fixed-cost statement of work been signed by the accredited EMC laboratory specifying the test standard (IEEE 299.1 or equivalent, with standard name), frequency range (specify MHz range), number of test samples, cost locked at EUR 15k (±0%), report delivery date locked (Month 5 = 2027-03-08 absolute deadline), and re-test cost if the first run fails? Provide the signed SOW with all terms explicit.
3. By Month 3 (2027-01-08), what is the measured presale deposit mix by segment (prepper % of total, infrastructure %, privacy/forensics %), and what is the average order value (AOV) by segment? If prepper deposits exceed 70% of total, what specific marketing-spend reallocation (channel, messaging, budget amount) has been approved by the Steering Committee and executed? Provide the weekly deposit dashboard and the reallocation approval memo.
4. At Month 5 (2027-03-08), when the accredited lab report is delivered, what specific attenuation values (in dB) are measured at key frequencies (50 MHz, 100 MHz, 500 MHz, 1 GHz estimate)? Do measured values support the intended marketing claims without revision, or do claims require narrowing? If redesign is recommended by the lab, what is the cost estimate and timeline impact, and has the Steering Committee approved the redesign funding from the EUR 20k reserve or recommended halting the project?
5. At Month 6 (2027-04-08), when the hard-tooling gate decision is made, can the founder and external advisor jointly confirm in writing that: (a) net presale deposits (gross deposits minus refunds) are ≥EUR 80k (the proposed threshold), (b) the accredited lab report confirms the design is production-ready with no major rework, (c) in-house rig validation passed two independent seam cycles meeting attenuation targets, and (d) the designer reserves EUR 20k (or revised reserve amount) remains uncommitted? Provide the signed hard-tooling gate confirmation document with actual deposit amount and lab certifications cited.
6. By Month 9 (2027-07-08), how many presale units have been delivered and invoiced (cumulative year-to-date), and what is the verified collected cash from delivered-unit sales (excluding presale deposits)? Given the baseline case of 750 units by Month 12 (2027-10-08) at EUR 67 margin contribution, is the venture on track to deliver at least 500 units by Month 12 (2027-10-08) to achieve EUR 25k quarterly surplus (EUR 20k opex)? Show the monthly fulfillment-to-invoice-to-cash-receipt pipeline with sample audit of 10–15% of transactions.

## Summary

Carrington Event Prep operates under a rigorous five-layer governance structure designed to protect a founder's personal EUR 750k capital (EUR 400k Year-1 cap, EUR 350k conditional follow-on) against the dual risks of technical failure (shielding test redesign) and demand shortfall (weak presale volumes). The framework gates irreversible spending (hard tooling, batch production) on evidence: presale deposits ≥EUR 80k, accredited lab design certification, and in-house validation. Five governance committees (Steering, Design & Certification, Compliance & Liability, Presale & Revenue, Production & Supply Chain, Financial Governance) divide decision authority with clear escalation paths; monthly monitoring dashboards track budget variance, segment-mix pivots, and cash-flow gate progress. A cash-flow gate (EUR 25k quarterly operating surplus from delivered units, Months 9–12 = 2027-07-08 to 2027-10-08) determines tranche release at Month 12.5 (2027-10-23). Key strengths: hard-tooling gating prevents sunk cost before demand is proven; weekly presale tracking enables rapid segment-mix correction; separate earmarked deposit accounting enforces liability segregation. Key vulnerabilities: accredited lab standard selection and cost are not confirmed before prototype investment; presale conversion risk is concentrated in a niche market (preppers) with thin margins; infrastructure sales cycles may extend past gate measurement window; zero production-budget headroom leaves no room for lab re-testing or regulatory (CE marking) surprises. Governance effectiveness depends on disciplined execution of monthly reviews, transparent escalation of material variances, and founder + advisor consensus on gate measurement methodology—particularly if the gate result falls in the ambiguous range (–EUR 5k to +EUR 25k), triggering founder discretion to extend or release the tranche.