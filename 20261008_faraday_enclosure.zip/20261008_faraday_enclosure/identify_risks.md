
## Risk 1 - Technical & Design
Shielding effectiveness may not meet target attenuation in accredited lab testing. The plan assumes a single-SKU rigid enclosure with conductive-gasket seams designed and iterated on an in-house rig, then validated once by an accredited EMC lab. If lab results fall short of claims or reveal seam/gasket failures, the design must be reworked, but hard tooling may already be committed. Re-testing adds €8–15k per run (estimate), and each design change after certification requires re-qualification.

**Impact:** Failed lab validation after tooling commitment incurs sunk hard-tooling cost (€20–40k estimate) and forces redesign or claim reduction. Re-testing and re-qualification delay revenue by 2–4 months and consume €15–30k (estimate) from Year-1 budget. Weakened claims reduce infrastructure buyer confidence and may lower presale conversion. In worst case, sunk tooling cost and redesign expenses exhaust Year-1 budget before presales mature, blocking access to the €350k follow-on.

**Likelihood:** Medium

**Severity:** High

**Action:** Gate hard tooling release on a documented pre-test design review with the accredited lab, so the lab confirms methodology and design readiness before sample submission. Run the in-house rig validation twice (two independent seam cycles) and document attenuation across the full claimed frequency band before committing to accredited testing. Reserve €20k (estimate) of Year-1 budget explicitly for one re-test and minor redesign. Schedule the single accredited lab run no later than Month 4 (2027-02-08), so redesign time remains before presales commit shipping dates.

## Risk 2 - Financial & Cash Flow
Presale deposits may not reach the stated minimum-order threshold needed to release hard tooling, or conversion to delivered units may lag the cash-flow gate window. Prepper communities are price-sensitive and skeptical of marketing; infrastructure buyers move slowly through procurement. If deposits arrive slowly or refund requests cluster after a news cycle mentioning Carrington risk, the cash flow needed to trigger the €350k follow-on may not be met within the Year-1 window, stranding the venture.

**Impact:** Shortfall in presale deposits delays or prevents hard-tooling release, pushing first revenue beyond Month 9 (2027-07-08) and risking missed cash-flow gate by end of Year-1. A €150–250k shortfall (estimate) in presale deposits or a 3-month slip in delivered-unit receipts may leave cumulative cash flow below the tranche gate even after presale fulfillment. In consequence, the €350k follow-on is withheld, halting inventory replenishment, marketing and R&D, and forcing the venture into financial constraint or wind-down.

**Likelihood:** Medium

**Severity:** High

**Action:** Define the cash-flow gate measurement convention before launch (Month 0.5 = 2026-10-23) using trailing-quarter delivered-unit receipts only, excluding presale deposits, so presale timing does not distort the gate. Set the minimum presale threshold at €80–120k (estimate, to be refined) and commit tooling only after that threshold is met and pre-test results confirm the design. Track presale conversion and refund rates weekly and trigger a pivot (pivot to multi-use RF-isolation narrative or seek alternative buyer segments) if conversion falls below 40% (estimate) by Month 3 (2027-01-08). Run parallel presale campaigns in prepper networks and critical-infrastructure buyer groups from Month 0 (2026-10-08) to test both segments' deposit rates.

## Risk 3 - Market & Demand
Presale volume may skew heavily toward low-value prepper units (price-sensitive, small orders), while critical-infrastructure orders remain slow, leaving the company with inventory of unprofitable low-margin product. The plan assumes a multi-use RF-isolation narrative to widen addressable market, but this may dilute the Carrington brand and slow niche prepper adoption if messaging is inconsistent. Alternatively, a strict prepper positioning may cap unit volume well below what the €750k plan needs to reach positive cash flow.

**Impact:** Prepper-skewed presales generate high unit volume but low margin (unit price €40–60 estimate, gross margin €10–20 estimate per unit), while infrastructure orders (unit price €150–300 estimate, margin €60–120 estimate) arrive slowly or not at all. Result: 3000–4000 prepper units sold at €15 margin versus 100–200 infrastructure units at €80 margin. Cumulative Year-1 revenue €60–80k (estimate) is insufficient to cover €400k Year-1 burn, and positive cash flow is not achieved, blocking the €350k follow-on. Company reaches Month 12 (2027-10-08) with depleted cash and no path to profitability.

**Likelihood:** High

**Severity:** High

**Action:** Test the multi-use RF-isolation narrative (privacy, travel, key-fob security, digital-forensics) in parallel with Carrington messaging from Month 1 (2026-11-08). Run separate presale campaigns in prepper forums, digital-forensics communities and corporate IT security groups to measure deposit velocity and average order value by segment. If prepper conversion exceeds 70% of total presales by Month 3 (2027-01-08), pivot marketing away from Carrington and emphasize RF isolation and privacy. Set a minimum average order value (€50–100 estimate) as a go/no-go gate for continuing presales; if average order falls below €40, halt presale marketing and shift to wholesale or distribution channels. Negotiate a wholesale agreement with an established prepper retailer (consignment-free terms) as a backup channel to accelerate infrastructure-segment access.

## Risk 4 - Regulatory & Compliance
EU product-safety and consumer-protection rules applicable to the enclosure are not definitively verified. If the enclosure falls under the EMC Directive or General Product Safety Directive (applicability not verified), marketing claims that exceed measured data or tested frequency range expose the company to regulatory challenge, mandatory product recall, or fines. Reputational damage from a failed real-world Carrington event or customer complaints about shielding are difficult to insure and may exceed company reserves.

**Impact:** Regulatory challenge or consumer complaint requiring claim revision or product recall incurs €30–80k (estimate) in legal fees, redesign, and retest. Uninsured liability exposure if a customer experiences device loss in an EMI event and sues for breach of warranty or misrepresentation creates potential multi-year legal cost and reputational damage. In scenario with high-profile Carrington event during Year-1 or Year-2, unmet customer expectations and social media amplification damage brand and sales momentum, reducing presale conversion and post-launch revenue by 30–50% (estimate).

**Likelihood:** Medium

**Severity:** High

**Action:** Commission a legal opinion on applicable EU product rules (EMC Directive, General Product Safety Directive, consumer protection rules) by Month 1 (2026-11-08) (€2–5k estimate). Limit all marketing and data-sheet claims strictly to measured shielding attenuation across the tested frequency band and explicitly disclaim protection for grid-connected equipment or real-time events. Include scope statements in all sales materials: 'This enclosure protects stored spare devices against RF exposure. It does not protect active equipment or prevent grid-scale events.' Obtain product liability insurance covering €250–500k (estimate) in defect claims and seek clarification on whether Faraday-enclosure claims are insurable; if not, adjust liability cap in warranty terms. Publish the accredited lab report with every sale so customers see the exact measured data and frequency range tested.

## Risk 5 - Supply Chain & Production
Tallinn precision-metal fabrication base is assumed low-cost and ISO-certified, but supply-chain risk is concentrated in a single region and single supplier base. Soft tooling (laser cut and bend) is assumed flexible for iteration, but if the chosen Tallinn fabricator lacks capacity or changes pricing during Year-1, redesign or scaled production becomes difficult. Conductive-gasket materials may require import; supplier delays or quality variance in gaskets can delay production and certification.

**Impact:** Tallinn fabricator capacity constraints or price increases (10–20% estimate) during Year-1 raise unit cost and reduce margins, offsetting presale cash. Loss of primary fabricator access (e.g., due to capacity reallocation or bankruptcy) forces urgent sourcing from a secondary supplier, adding 4–6 weeks (estimate) delay and potential quality re-qualification. Gasket-material supply chain disruption delays first batch shipment by 2–4 weeks (estimate), missing customer delivery promises and triggering refund requests that strain cash flow around the Month 9 (2027-07-08) cash-flow gate measurement window.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Identify and pre-qualify a secondary Tallinn-area precision-metal fabricator and gasket supplier by Month 1 (2026-11-08), with a trial laser-cut batch to confirm quality. Lock in tooling and fabrication pricing with the primary supplier for Year-1 in a signed agreement specifying capacity reservation and price caps. Source conductive-gasket material from at least two qualified suppliers (one primary, one backup) and hold a 30-day buffer stock (€5–10k estimate) of gaskets before production release. Document all sourcing risks and lead times in a supply-chain risk register reviewed monthly. If primary fabricator raises prices above 10% or signals capacity loss, trigger the secondary-supplier transition and accelerate first production run to de-risk inventory.

## Risk 6 - Operational & Execution
The plan requires RF and shielding engineering expertise that a founder-led team may lack. The plan assumes either an in-house RF engineer (salaried) or an EMC consultancy on milestone basis. A salaried hire adds €40–60k (estimate) fixed Year-1 cost; a consultancy on milestone basis incurs lumpy spending (€5–10k per milestone) and may have timeline misalignment with the presale schedule. Lack of internal expertise or external support delays prototype design and extends time to first accredited lab test, compressing the presale window and redesign buffer.

**Impact:** Delayed prototype development (2–3 months slip estimate) pushes accredited lab test from Month 4 (2027-02-08) to Month 6 (2027-04-08) or later, leaving insufficient time for redesign and presale fulfillment before the Year-1 cash-flow gate. Milestone-based EMC consultancy with slow delivery or timeline misalignment adds unexpected delays and costs. Alternatively, hiring a full-time RF engineer at €50k/year (estimate) consumes 12.5% of Year-1 budget with no presale revenue to offset, straining cash and forcing cuts elsewhere (marketing, testing, or tooling).

**Likelihood:** High

**Severity:** Medium

**Action:** Secure RF and shielding expertise by Month 0.5 (2026-10-23) using a hybrid model: engage an independent EMC consultancy on a fixed milestone basis (€20–25k estimate for design review and first accredited lab coordination) and co-develop the enclosure with an Estonian university lab (e.g., Tallinn University of Technology) in exchange for access to their RF measurement chambers and publication rights. This limits fixed headcount and early salary cost while securing technical capability and accredited lab access. Set clear milestones: prototype design by Month 2 (2026-12-08), in-house rig validation by Month 3 (2027-01-08), lab submission by Month 4 (2027-02-08), report by Month 5 (2027-03-08). If university partnership does not materialize, hire a part-time RF engineer (0.5 FTE, €25k estimate Year-1) or contract a second consultancy firm for backup.

## Risk 7 - Logistics & Distribution
The plan specifies Tallinn as the single production and shipping point for all European presales. Heavy metal enclosures (estimated 2–4 kg per unit) incur significant freight costs, especially to distant EU markets (Southern Europe, UK). Build-to-order fulfilment requires long lead times (3–4 weeks estimate from presale to shipment), which may disappoint buyers expecting immediate delivery. Buffer stock in a third-party EU warehouse reduces lead times but ties up working capital (€30–60k estimate for 500–1000 units), consuming cash needed for design, testing, and marketing.

**Impact:** Freight costs add €8–15 per unit (estimate) to landed cost, reducing margins by 15–30% (estimate) depending on presale geography. Long lead times reduce presale conversion if buyers want protection 'now' rather than waiting 3–4 weeks. Buffer stock in third-party warehouse ties up €30–60k (estimate) working capital, reducing available cash for design and testing and risking cash-flow gate delay if inventory does not turn fast (sales slower than forecast). Alternatively, build-to-order delays trigger refund requests or complaints, damaging trust with early adopters during critical presale phase.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Defer buffer-stock warehousing until presale volume and conversion rate are proven (Month 6 = 2027-04-08 onward). Run first production run (500–800 units estimate, based on presale deposits) and ship directly from Tallinn on a 2–3 week build-to-order cycle, quoting delivery dates upfront in presale terms. Partner with a logistics provider (DHL, UPS, or local carrier) to negotiate volume-discount freight rates and lock in pricing for Year-1. Set presale delivery expectations clearly: 'Ships within 3 weeks of order confirmation.' If presale conversion exceeds 60% and average order value exceeds €80 (estimate) by Month 5 (2027-03-08), negotiate a trial 60-day buffer in a regional EU warehouse (Central Europe or Scandinavia) for 200–300 units to serve high-demand regions. Monitor inventory days outstanding (target: 30–40 days) and halt buffer stock if turnover falls below 1.5x per month.

## Risk 8 - Market & Segment Timing
The plan assumes sequencing buyers (prepper networks first, infrastructure buyers second) to prove demand and build reference customers. However, infrastructure procurement cycles are typically 6–12 months or longer, meaning a pilot or initial order may not close until Month 8–12 (2027-06-08 to 2027-10-08) or beyond the Year-1 window. If infrastructure orders do not arrive in time to contribute to the cash-flow gate measurement (end of Year-1), the positive-cash-flow condition for the €350k follow-on may not be met, even if volumes are technically healthy.

**Impact:** Slow infrastructure procurement delays large reference orders until Month 9–12 (2027-07-08 to 2027-10-08) or beyond, meaning delivered-unit revenue from infrastructure arrives after the Year-1 cash-flow gate cutoff. Result: only small prepper volumes count toward the gate, and cumulative cash flow may fall short of the threshold (not yet defined in the plan) needed to unlock the €350k follow-on. Company reaches Month 12 (2027-10-08) with growing preorder backlog and production readiness but insufficient delivered-unit revenue to satisfy the gate, blocking capital access and forcing a funding crisis or restructuring.

**Likelihood:** Medium

**Severity:** High

**Action:** Clearly define the cash-flow gate measurement window and threshold before launch (Month 0.5 = 2026-10-23), e.g., 'Positive quarterly operating cash flow (delivered units only) of €30k or more in Q4 of Year-1.' Sequence buyer outreach in parallel, not strictly sequentially: approach prepper networks and infrastructure buyers concurrently starting Month 1 (2026-11-08), so presale deposits arrive from both segments and infrastructure pilots close sooner. Set a 'fast-track' pilot agreement with one or two infrastructure buyers by Month 3 (2027-01-08) (pilot units at cost plus 20% estimate, with delivery by Month 5 = 2027-03-08) to generate an in-time reference and revenue. If infrastructure deals stall past Month 6 (2027-04-08), pivot presale marketing to the multi-use RF-isolation narrative (privacy, travel security) to widen addressable market and accelerate adoption outside the niche prepper base. Document segment-by-segment presale and revenue tracking in a monthly dashboard shared with the tranche-gate governance team.

## Risk 9 - Financial & Burn Rate
The €400k Year-1 budget (user constraint) is allocated across design, prototyping, accredited lab fees, soft tooling, first production batch, marketing, and personnel. Spending is not explicitly sequenced in the provided plan, so there is risk of front-loading irreversible costs (hard tooling, large production runs) before proof and presales exist. Overruns in any area (lab fees, design iteration, prototyping) compress the remainder and may force cuts to marketing or testing that slow presale uptake or compromise design validation.

**Impact:** Unsequenced €400k spend risks exhausting cash on design and tooling before presales materialize, leaving insufficient runway to market, fulfill presales, or absorb redesign costs. A 20% overrun (€80k estimate) in prototyping, lab fees, or tooling leaves only €320k for production, marketing, and contingency—insufficient to fund a meaningful first production batch and marketing push. Company reaches Month 9–10 (2027-07-08 to 2027-08-08) with cash depleted, presales not yet validated, and no funds to execute fulfillment or pivot, forcing early wind-down or external funding with dilution to the founder.

**Likelihood:** High

**Severity:** Medium

**Action:** Create an explicit monthly Year-1 burn schedule (Month 0.5 = 2026-10-23) allocating the €400k across design (€30k estimate), prototyping and in-house test rig (€40k estimate), accredited lab fees (€15k estimate), soft tooling (€20k estimate), first production batch (€150–200k estimate), contingency/redesign reserve (€20k estimate), and marketing/sales (€50–75k estimate). Hold the €20k redesign reserve uncommitted until Month 5 (2027-03-08) (post lab test). Release hard-tooling spend only after presale deposits reach €80k (estimate threshold) and pre-test results confirm design, so irreversible commitments follow evidence. Track actual spend versus plan weekly; if cumulative burn exceeds plan by 10% at any milestone, trigger a review and spending freeze until the source and impact are clarified. Document carry-over assumptions: if presales are delayed, what spending will be deferred or cut?

## Risk 10 - Technical & Design
The plan specifies a single-SKU rigid folded-aluminium or steel enclosure sized to fit the largest common laptop and several phones. A single size may not accommodate the range of devices (13-inch to 17-inch laptops, various phone sizes), risking customer dissatisfaction if their device does not fit or leaves them space for accessories. Alternatively, offering multiple sizes within the single-SKU constraint requires multiple tooling variants, which violates the single-SKU goal and raises re-qualification cost.

**Impact:** Fit-and-finish complaints for devices that are marginal fits (too tight, no space for cables) reduce presale conversion and trigger returns, raising refund cost and damaging reputation. A rigid enclosure sized for a 15-inch laptop may not fit 17-inch devices or may leave a 13-inch device with excessive rattle and potential shielding loss at seams. If 30–50% (estimate) of presale orders are returned or complained about due to fit, refund cost and reputational damage reduce future presale conversion and sales momentum by 20–40% (estimate).

**Likelihood:** Medium

**Severity:** Medium

**Action:** In the design phase (Month 1–2 = 2026-11-08 to 2026-12-08), publish a detailed size-and-fit guide showing which laptop models and phone sizes fit the enclosure. Test the prototype fit against the three most common laptop sizes (13-inch, 15-inch, 17-inch) and five major phone models; document pass/fail with photos. In presale materials, explicitly state 'This enclosure fits laptops up to 17 inches (maximum internal dimensions: 420 x 280 x 50 mm estimate) and phones up to 6.5 inches'. Offer a 30-day no-questions refund for fit-related returns within the first 100 units sold as a trust-builder during launch phase. If fit complaints exceed 10% of orders by Month 7 (2027-05-08), commission a follow-on smaller SKU variant (e.g., phone-only pouch) for Month 9+ release, keeping the launch single SKU but enabling a family variant later.

## Risk 11 - Organizational & Governance
The plan is founder-led and self-funded, with a staged €350k follow-on conditional on positive cash flow. No governance structure is defined for deciding when the cash-flow gate is met, what constitutes 'positive cash flow', or who makes the tranche release decision. Ambiguity creates risk of dispute, founder delay, or inconsistent interpretation of the gate condition, especially if a cash-flow measurement window is missed or results are borderline.

**Impact:** Unclear cash-flow gate definition leads to founder second-guessing or advisory-board disagreement on gate release, delaying the €350k tranche decision into Month 13–14 (2027-11-08 to 2027-12-08) when competitive and market timing pressures mount. Lack of clarity on presale refund policy and delivery obligations creates founder liability if presale customers demand refunds due to long lead times or fit issues. Founder burnout from solo operations and continuous fundraising/gate-measurement work increases risk of operational errors, missed deadlines, and poor decision-making in Month 6–12 (2027-04-08 to 2027-10-08) as cash pressure rises.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Draft and document the cash-flow gate measurement convention by Month 0.5 (2026-10-23) (e.g., 'Positive operating cash flow measured on delivered-unit revenue only, trailing 3-month average of €25k+, measured end of Year-1 Q4'). Establish a simple governance checkpoint: founder + one external advisor (e.g., accountant or experienced advisor) will measure and sign off on gate result by Month 12.5 (2027-10-23). Publish this convention and checkpoint plan publicly in presale terms and marketing, so all stakeholders understand the gate logic upfront. Create a written presale terms document (refund policy, delivery timelines, contact escalation path) by Month 1 (2026-11-08), so presale customers know their rights and the founder has clear obligations. If founder capacity becomes strained by Month 6 (2027-04-08) (operations, fundraising, gate measurement), hire a part-time operations or finance person (10–15 hrs/week, €200–300/week estimate) to handle fulfillment, refunds, and cash-flow tracking, freeing founder for strategy and presale work.

## Risk 12 - Technical & Certification
The plan assumes one accredited EMC lab validation for the final design, using the report as the public credibility basis for all sales claims. However, the applicable standard for small enclosures (IEEE 299.1 or equivalent) is not verified; if the chosen lab recommends a different or more stringent standard, the test methodology and cost may differ from plan assumptions. Additionally, if the lab uses a different frequency range or attenuation threshold than the enclosure design targets, results may fall short of marketing claims.

**Impact:** Lab recommends a higher-cost or longer-duration test standard (e.g., full MIL-STD-285 instead of IEEE 299.1 estimate), adding €10–20k (estimate) and 4–8 weeks (estimate) to the certification timeline. Test results show attenuation below marketing claims in certain frequency bands (e.g., lower attenuation at 50–100 MHz than claimed), requiring claim revision or design change. Revision forces either (a) a second lab test (€8–15k estimate, 6–8 weeks) or (b) a narrower frequency-range claim that weakens market positioning and infrastructure buyer credibility.

**Likelihood:** Medium

**Severity:** High

**Action:** By Month 0.5 (2026-10-23), contact 2–3 accredited EMC laboratories (e.g., in Germany, Sweden, Netherlands) and request a pre-engagement consultation (often free or low-cost) to clarify applicable standards, test methodology, cost, and timeline for a small Faraday enclosure. Document the lab's recommendation for the applicable standard and frequency range. Choose the lab based on (a) cost predictability, (b) timeline fit (committed report delivery by Month 5 = 2027-03-08), and (c) willingness to engage in design consultation before formal submission. Request a design-readiness review (€2–3k estimate) before submitting samples, so the lab confirms that the design is test-ready and gives feedback on likely attenuation before costly sample submission. Lock in test cost and timeline in a statement of work by Month 1.5 (2026-11-23), so no surprises emerge in Month 4 (2027-02-08).

## Risk 13 - Financial & Funding
The plan relies on presale deposits (refundable) and positive Year-1 cash flow to unlock the €350k follow-on tranche. If presale deposits are refundable and a news cycle (e.g., solar-storm hype or lack thereof) shifts demand, presale refund requests may spike, consuming deposits that were counted as cash flow. Additionally, if the positive-cash-flow gate is defined loosely (e.g., including presale deposits as cash), it creates a perverse incentive to commit follow-on spending before presales are actually fulfilled, leaving real cash-flow exposure.

**Impact:** Presale refund spike (20–30% of deposits estimate if Carrington narrative fades) reduces available cash by €20–40k at a critical point (Month 8–9 = 2027-06-08 to 2027-07-08) when production tooling must be committed. Alternatively, if presale deposits are counted as 'positive cash flow' but aren't yet delivered, the €350k follow-on is released before fulfillment obligations are met, and if fulfillment then slips, the company has spent the follow-on tranche on ongoing operations and has no capital for inventory replenishment or growth, leaving it underfunded.

**Likelihood:** Medium

**Severity:** High

**Action:** Define presale deposits as 'liabilities, not cash flow' in the accounting framework from Month 0.5 (2026-10-23). Measure positive cash flow using only delivered-unit revenue (invoiced and paid), not presale deposits. Hold presale deposits in a separate earmarked account and do not use them for operational spending; ring-fence them exclusively for fulfilling presale orders, so refunds do not trap operational cash. Set a presale deposit refund cap: if cumulative refunds exceed 15% (estimate) of total deposits by Month 8 (2027-06-08), trigger a pivot in marketing narrative or buyer-segment strategy to re-attract and stabilize demand. Document a monthly cash reconciliation (operational cash vs. presale liability) and share it with an advisor or accountant to catch any drift in definitions before gate measurement.

## Risk 14 - Market & Competitive
The Faraday enclosure market for consumers is small and niche (preppers, privacy advocates, digital-forensics professionals). If a competitor enters with better branding, lower price, or equivalent performance during Year-1 or early Year-2, the Carrington Event Prep product may lose presale momentum and market-access advantages. Additionally, if a large retailer (e.g., Amazon, specialty preparedness retailer) launches its own private-label Faraday enclosure, it can undercut price and capture channel access faster than a self-funded startup.

**Impact:** Competitive product entry reduces presale conversion by 20–40% (estimate) as early adopters split between brands. Price competition compresses margins, forcing choices between (a) accepting lower profit per unit, (b) cutting marketing spend to preserve cash, or (c) exiting low-margin segments. Market share loss in Year-1 reduces the reference-customer credibility and sales momentum needed to close infrastructure deals in Year-2, lowering the cash-flow gate result and delaying or blocking the €350k follow-on tranche.

**Likelihood:** Low

**Severity:** Medium

**Action:** Establish a brand and positioning differentiation starting Month 1 (2026-11-08): emphasize the multi-use RF-isolation narrative (privacy, travel, security) alongside Carrington prep, so the product appeals beyond disaster preppers and is less vulnerable to a niche competitor. Build a community around early adopters and infrastructure pilots to create switching cost and lock-in (e.g., annual verification service, community forums). Monitor competitor landscape monthly and trigger a strategic pivot if a credible competitor launches within 6 months: either (a) emphasize manufacturing locality ('Designed and made in Estonia'), (b) add a services layer (shielding verification, fit consulting), or (c) open a second market segment (e.g., corporate IT security) to diversify revenue. Document IP and design choices (e.g., specific seam design, gasket materials) that are defensible and difficult to replicate quickly.

## Risk 15 - Operational & Execution
The plan specifies a small, founder-led team without detailed staffing or decision-making structure. Managing design, prototyping, supplier coordination in Tallinn, accredited lab engagement, presale marketing, and fulfillment across multiple geographies and functions is intensive work. Founder burnout, illness, or personal circumstance (family, visa, legal) could halt execution for weeks and create cascading delays in critical paths.

**Impact:** Founder absence (illness, family emergency) during Month 4–5 (2027-02-08 to 2027-03-08) (critical lab submission and design-review period) delays accredited lab engagement by 2–4 weeks (estimate), pushing lab report from Month 5 (2027-03-08) to Month 6–7 (2027-04-08 to 2027-05-08). Consequent delays compress the presale and production timeline, reducing the window for resolving issues before the Year-1 cash-flow gate. Burnout in Month 8–10 (2027-06-08 to 2027-08-08) (high-stress presale fulfillment period) leads to poor decision-making, missed deadlines, or quality oversights in production that damage customer experience and reduce repeat sales. Visa or personal constraint affecting Tallinn access prevents hands-on supplier coordination and quality control during early production runs.

**Likelihood:** Low

**Severity:** Medium

**Action:** Establish a backup operations contact by Month 1 (2026-11-08) (part-time advisor or operations person with authority to make decisions if founder is unavailable). Document critical decision paths and escalation procedures for key suppliers, lab contacts, and customer support so another person can step in. Create a detailed timeline and decision-checklist document by Month 1 (2026-11-08) so the plan is not held only in the founder's head. Plan for Tallinn visits in advance: schedule visits in Month 1 (2026-11-08) (supplier identification), Month 2–3 (2026-12-08 to 2027-01-08) (design review with fabricator), Month 4–5 (2027-02-08 to 2027-03-08) (pre-test design confirmation), and Month 7–8 (2027-05-08 to 2027-06-08) (first production quality control), so visits are concentrated and planned rather than reactive. Arrange for a local Tallinn-based liaison (e.g., part-time engineering contact, local accountant) to handle ongoing supplier communication if founder is unavailable for extended periods.

## Risk summary
Carrington Event Prep is a self-funded, capital-constrained, two-tranche hardware venture (€400k Year-1, €350k follow-on gated on positive cash flow) anchored in Tallinn manufacturing and presale-validated demand. The most critical risks are: (1) **Shielding validation and redesign cost** – a failed accredited lab test after tooling commitment forces costly re-qualification or sunk loss; (2) **Insufficient presale volume or cash-flow gate misalignment** – niche prepper demand may not generate enough deposits or delivered-unit revenue to unlock the €350k follow-on within the Year-1 window, stranding the venture; (3) **Long infrastructure sales cycles and claim-substantiation exposure** – slow procurement and weak claim-to-evidence match under EU consumer law create delivery pressure against testing time and reputational risk. These risks interact: strict cash-flow gate timing pressures presales and fulfilment speed, which shortens the design-iteration window and increases redesign risk. Mitigation depends on clear sequencing: cheap in-house iteration before any hard tooling, explicit deposit thresholds tied to test results, and a multi-use narrative (RF isolation, not just Carrington prep) to widen the reachable market and ease the cash-flow gate.