**Overall Adherence: 90%**

```
IMPORTANCE_ADHERENCE_SUM = (5×5 + 5×5 + 5×5 + 5×4 + 5×5 + 4×4 + 5×3 + 5×4 + 4×4 + 4×5 + 4×5 + 4×5 + 4×5 + 4×5 + 5×4) = 307
IMPORTANCE_SUM = 5 + 5 + 5 + 5 + 5 + 4 + 5 + 5 + 4 + 4 + 4 + 4 + 4 + 4 + 5 = 68
OVERALL_ADHERENCE = IMPORTANCE_ADHERENCE_SUM / (IMPORTANCE_SUM × 5) = 307 / 340 = 90%
```

## Summary

| ID | Directive | Type | Importance | Adherence | Category |
|----|-----------|------|------------|-----------|----------|
| 1 | Total funding EUR 750k, self-funded by founder; hard cap EUR 400k Year-1 (Months 0–12 = 2026-10-08 to 2027-10-08); EUR 350k follow-on conditional on positive cash flow gate at Month 12.5 (2027-10-23). | Constraint | 5/5 | 5/5 | Fully honored |
| 2 | Design, certify, and distribute single-SKU Faraday enclosure (rigid folded aluminium/steel, continuous conductive-gasket lid, ~420×280×50 mm, 2–4 kg) for phones and laptops. Server-grade cages out of scope. | Requirement | 5/5 | 5/5 | Fully honored |
| 3 | Manufacturing anchored in Tallinn, Estonia. Market is EU/Europe. All budgeting in EUR. Production and shipping from Tallinn. | Stated fact | 5/5 | 5/5 | Fully honored |
| 4 | Year-1 budget allocation: design/prototyping/EMC consultancy 70k, in-house test rig 40k, accredited lab 15k, soft tooling 20k, production line 160k, marketing/sales/operations 75k, redesign reserve 20k (total 400k). | Constraint | 5/5 | 4/5 | Partially honored |
| 5 | Production line 160k: hard tooling 30k, gasket buffer 7k, 1,500 units at 70/unit (105k), outbound freight 1,500×12=18k. Zero unallocated production headroom. | Constraint | 5/5 | 5/5 | Fully honored |
| 6 | Redesign reserve EUR 20k, uncommitted until Month 5 (2027-03-08) lab result. May rise to 30k by cutting marketing 10k. After lab re-test (8–15k), free contingency drops to 5–12k. | Constraint | 4/5 | 4/5 | Partially honored |
| 7 | One accredited EMC lab validation per IEEE 299.1 or equivalent; fixed-cost SOW by Month 1.5 (2026-11-23); samples Month 4 (2027-02-08); report Month 5 (2027-03-08), latest Month 6 (2027-04-08). Report published with every unit. | Requirement | 5/5 | 3/5 | Partially honored |
| 8 | Cash-flow gate at Month 12.5 (2027-10-23): trailing Q4 (Months 9–12 = 2027-07-08 to 2027-10-08) operating surplus (receipts minus direct unit costs minus recurring opex, excluding deposits and one-off dev spend) must be ≥ EUR 25k to release 350k tranche. Ambiguous -5k to +25k: founder may extend 90 days. | Constraint | 5/5 | 4/5 | Partially honored |
| 9 | Presale deposits held as liabilities in earmarked account, never counted as cash flow or operating spend. Refund cap: if cumulative refunds exceed 15% by Month 8 (2027-06-08), pivot narrative or segment. Presale closes Month 8 (2027-06-08). | Constraint | 4/5 | 4/5 | Partially honored |
| 10 | Hard tooling released only when net presale deposits ≥ EUR 80k AND accredited lab pre-test confirms design. Target EUR 120k by Month 6 (2027-04-08). | Constraint | 4/5 | 5/5 | Fully honored |
| 11 | Presale target to European prepping networks and critical-infrastructure buyers. Pilot: 10–20 units at cost +20% (84/unit), agreed by Month 3 (2027-01-08), delivered Month 5 (2027-03-08). | Requirement | 4/5 | 5/5 | Fully honored |
| 12 | Year-1 volume: 1,500 units (800 Batch 1 + 700 follow-on). Year-1 revenue estimate 1,500×149 = EUR 223.5k. Year-2 steady state 3,000 units/year, revenue EUR 447k/year. | Stated fact | 4/5 | 5/5 | Fully honored |
| 13 | Recurring opex EUR 80k/year (20k/quarter): marketing 40k, part-time ops 13k, insurance 8k, admin/legal/software 7k, re-verification 12k. No debt; founder absorbs Year-1 deficit. | Constraint | 4/5 | 5/5 | Fully honored |
| 14 | Server-grade cages deferred until market traction proven. No voluntary CE marking Year-1. No full-time RF hire. Buffer stock and phone-only SKU variant outside Year-1 cap; require tranche or receipts. | Banned | 4/5 | 5/5 | Fully honored |
| 15 | Execute: founder-led commercial product launch within fixed budget and defined cash-flow gate; not a study or feasibility phase. Conditional tranche release and wind-down decision if gate fails. | Intent | 5/5 | 4/5 | Partially honored |

## Issues

### Issue 7 - One accredited EMC lab validation per IEEE 299.1 or equivalent; fixed-cost SOW by Month 1.5 (2026-11-23); samples Month 4 (2027-02-08); report Month 5 (2027-03-08), latest Month 6 (2027-04-08). Report published with every unit.

- **Category:** Partially honored
- **Adherence:** 3/5
- **Importance:** 5/5
- **Evidence:** Plan specifies 'one accredited EMC lab validation per IEEE 299.1 or equivalent; fixed-cost SOW by Month 1.5 (2026-11-23); samples Month 4 (2027-02-08); report Month 5 (2027-03-08), latest Month 6 (2027-04-08). Report published with every unit.'
- **Explanation:** Dates and intent are honored, but the directive requires 'fixed-cost SOW by Month 1.5 (2026-11-23)' and the plan defers lab selection and cost confirmation to Month 0.5 (2026-10-23) pre-engagement. The plan does not lock a signed SOW by Month 1.5 (2026-11-23); it only commits to 'lock in cost and timeline in a statement of work by Month 1.5 (2026-11-23)' in the assumptions. This is a softened approach—engagement precedes commitment.

### Issue 4 - Year-1 budget allocation: design/prototyping/EMC consultancy 70k, in-house test rig 40k, accredited lab 15k, soft tooling 20k, production line 160k, marketing/sales/operations 75k, redesign reserve 20k (total 400k).

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 5/5
- **Evidence:** Plan allocates: design/prototyping/EMC consultancy 70k, in-house test rig 40k, accredited lab 15k, soft tooling 20k, production line 160k, marketing/sales/operations 75k, redesign reserve 20k. Totals €400k.
- **Explanation:** Budget allocation is stated, but the presale_deposit_use and tranche_use remain OPEN decisions. The plan assumes the allocation but does not fully resolve whether presale deposits offset unit costs or stay ring-fenced as liabilities. This is a critical execution detail left unresolved.

### Issue 8 - Cash-flow gate at Month 12.5 (2027-10-23): trailing Q4 (Months 9–12 = 2027-07-08 to 2027-10-08) operating surplus (receipts minus direct unit costs minus recurring opex, excluding deposits and one-off dev spend) must be ≥ EUR 25k to release 350k tranche. Ambiguous -5k to +25k: founder may extend 90 days.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 5/5
- **Evidence:** Plan states: 'Operating cash surplus of the trailing quarter (Months 9-12 = 2027-07-08 to 2027-10-08) = receipts from delivered and paid units - direct unit costs - recurring opex. Threshold >= EUR 25k. Sign-off by founder + external advisor by Month 12.5 (2027-10-23). Ambiguous -5k to +25k: founder may extend 90 days.'
- **Explanation:** The gate definition and measurement window are honored, but the directive specifies 'trailing Q4 (Months 9–12 = 2027-07-08 to 2027-10-08)' and the plan states the same. However, the directive uses the term 'receipts minus direct unit costs minus recurring opex' and the plan correctly interprets this. A minor ambiguity: the directive says 'excluding deposits and one-off dev spend,' and the plan excludes deposits but does not explicitly flag one-off dev spend exclusion in the main text.

### Issue 15 - Execute: founder-led commercial product launch within fixed budget and defined cash-flow gate; not a study or feasibility phase. Conditional tranche release and wind-down decision if gate fails.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 5/5
- **Evidence:** Plan states: 'Execute: founder-led commercial product launch within fixed budget and defined cash-flow gate; not a study or feasibility phase. Conditional tranche release and wind-down decision if gate fails.'
- **Explanation:** The intent is honored—the plan is action-oriented and gate-based. However, the plan includes multiple unsolicited caveats and feasibility disclaimers (lab cost risk +€10–20k, standard applicability not verified, CE marking risk +€10–30k, insurance risk unconfirmed) that soften the execution posture and flag contingencies the user did not ask for. These are risk mitigations, not breaches, but they add scope creep beyond the directive to execute within the given constraints.

### Issue 6 - Redesign reserve EUR 20k, uncommitted until Month 5 (2027-03-08) lab result. May rise to 30k by cutting marketing 10k. After lab re-test (8–15k), free contingency drops to 5–12k.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Plan states: '€20k redesign reserve, uncommitted until Month 5 (2027-03-08) lab result. May rise to 30k by cutting marketing 10k. After lab re-test (8–15k), free contingency drops to 5–12k.'
- **Explanation:** The reserve structure and optionality are described, but the plan does not lock in a final decision on whether to cut marketing to 30k or accept the 5-12k post-retest gap. This leaves execution ambiguity.

### Issue 9 - Presale deposits held as liabilities in earmarked account, never counted as cash flow or operating spend. Refund cap: if cumulative refunds exceed 15% by Month 8 (2027-06-08), pivot narrative or segment. Presale closes Month 8 (2027-06-08).

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Plan states: 'Presale deposits are liabilities held in a separate earmarked account, never counted as cash flow, and not used for operating spending. Refund cap: if cumulative refunds > 15% of deposits by Month 8 (2027-06-08), pivot the narrative or segment. Presale (deposit) offer closes Month 8 (2027-06-08).'
- **Explanation:** The plan honors the refund cap, deposit liability treatment, and presale cutoff. However, the directive states 'if cumulative refunds exceed 15% by Month 8 (2027-06-08), pivot narrative or segment,' which is treated as a trigger for decision, not an automatic action. The plan's phrasing suggests a soft trigger ('pivot narrative or segment') rather than a hard rule, leaving execution discretion open.
