Persuasive elevator pitch.

# Protect What Matters When Everything Fails

## Project Overview

A **single-SKU Faraday enclosure**—rigid, tested, and manufactured in Tallinn—shields phones and laptops from electromagnetic threats. This is a niche hardware business that proves demand, controls risk through staged investment, and opens a multi-use RF-isolation market beyond preppers: digital forensics, privacy travelers, and critical-infrastructure buyers all value documented shielding.

The product is a rigid folded aluminium/steel enclosure with continuous conductive-gasket lid seam, designed for phones and laptops up to 17 inches and 6.5 inches respectively (estimate). Internal dimensions are approximately 420 × 280 × 50 mm (estimate), with a mass of 2–4 kg (estimate).

**Value proposition:** Published test data from an accredited lab, a transparent scope (stored devices only), and a supply chain rooted in Tallinn's precision-metal ecosystem. No hype, no unproven claims—just **evidence-backed protection** sold to buyers who understand the risk.

The business model is presale-gated: deposits of EUR 149 per unit (estimate) unlock hard tooling only when net presale deposits reach EUR 80k (proposed threshold) AND the accredited lab confirms the design. Year-1 targets 1,500 units shipped at list price EUR 149, with an estimated contribution margin of EUR 67 per unit after direct costs and outbound freight. Funded by EUR 750k self-investment in two stages (EUR 400k Year 1, EUR 350k follow-on on gate), the project targets EUR 30k+ quarterly surplus to clear the cash-flow gate and fund scale.

## Target Audience

**Primary:** Hardware-savvy investors and founders evaluating self-funded, evidence-gated hardware launches with staged tranche release.

**Secondary:** Critical-infrastructure procurement teams and security-conscious organizations seeking documented RF-isolation for spare-device protection and continuity planning.

**Tertiary:** Digital-forensics, privacy, and preparedness communities who understand electromagnetic threats and value transparent test data over marketing.

**Not targeted:** Mass-market retail or consumer skeptics; the focus is on segments that pay for proof and accept niche positioning.

## Risks and Mitigation Strategies

- **Failed or expensive lab test:** An accredited EMC lab run costs EUR 8–15k if it fails; a costlier standard (not yet verified) adds EUR 10–20k.

  - *Mitigation:* In-house rig validated twice before lab submission; EUR 20k redesign reserve held uncommitted until Month 5 (2027-03-08); design-readiness review with the lab before formal testing.

- **Presales below EUR 80k:** Weak prepper demand caps deposits below the tooling gate.

  - *Mitigation:* Multi-use RF narrative (privacy, forensics, travel) broadens addressable market; Month 3 (2027-01-08) segment pivot if prepper dominance detected; extend presale to Month 8 (2027-06-08) if needed, with no hard tooling until threshold is met.

- **Cash-flow gate fails:** Margin erodes if prepper mix dominates (EUR 15/unit estimate, downside case).

  - *Mitigation:* Pilot agreements with infrastructure buyers generate higher-value early revenue; quarterly cash tracking and refund-rate alerts; design smaller SKU post-gate to raise unit economics.

- **Regulatory surprise:** EU EMC Directive or CE marking may apply (not yet verified), adding EUR 10–30k and 8–12 weeks unfunded.

  - *Mitigation:* Legal opinion by Month 1 (2026-11-08); claim scope limited to tested frequency band; product-liability insurance locked by Month 2.5 (2026-12-23).

## Metrics for Success

- **Proof and credibility:** Accredited lab report published (IEEE 299.1 or equivalent, not verified) with attenuation sweep data by Month 5 (2027-03-08); zero marketing claims exceeding measured values; zero regulatory challenges by Month 12 (2027-10-08).

- **Demand validation:** Presale net deposits ≥ EUR 80k by Month 6 (2027-04-08); presale conversion ≥ 40% by Month 3 (2027-01-08); refund rate ≤ 15% cumulative by Month 8 (2027-06-08).

- **Production and delivery:** 800 units batch 1 delivered by Month 8 (2027-06-08); 1,500 total units delivered Year 1; defect rate ≤ 2%; lead time ≤ 4–5 weeks after order.

- **Cash-flow gate:** Trailing-quarter operating surplus ≥ EUR 25k (Months 9–12 = 2027-07-08 to 2027-10-08), the trigger to unlock EUR 350k follow-on. Base case EUR 30.25k surplus (estimate), margin EUR 5.25k above gate.

- **Broader impact:** Reference customers in two segments (preppers, infrastructure or forensics); repeat order rate ≥ 20% from Year-1 buyers; product-liability claims rate ≤ 5% of units shipped by Month 12 (2027-10-08).

## Stakeholder Benefits

- **Founder/funder:** Staged EUR 750k investment (EUR 400k Year 1, EUR 350k on gate) protects personal capital; presale gate and lab results gate hard tooling before cash is spent; positive cash flow by Month 12 (2027-10-08) proves unit economics.

- **EMC consultancy and university lab:** Paid milestones (EUR 20–25k consultancy cap, university measurement services); design credit in public reports; potential ongoing validation and product-variant work.

- **Tallinn fabricators and suppliers:** Presale threshold secures batch-1 demand (800 units); soft tooling initially, hard tooling scaled on proven volume; repeat orders Year-2+ at 3,000 units/year (estimate); preferred-vendor status.

- **Presale buyers and pilots:** Early access at EUR 149 (EUR 120 effective with deposit timing); documented shielding proof; 30-day money-back guarantee; infrastructure pilots gain reference-customer rights and input on design.

- **Critical-infrastructure and forensics buyers:** Third-party test data for procurement compliance; transparent scope statement reducing claim exposure; supply continuity from an EU source; optional verification service (Year-2+).

## Ethical Considerations

**Honest claims:** Product scope limited to stored spare devices only; tested frequency range published; no claims of grid protection or real-time shielding of active equipment.

**Transparency:** Full accredited lab report (attenuation sweep) published with every unit sold; presale terms and refund policy transparent up front; monthly cash-flow and segment tracking shared with external advisor for gate sign-off.

**Liability posture:** Product-liability insurance (EUR 250–500k estimate) in place by Month 2.5 (2026-12-23); warranty terms tied to seal condition and documented use; scope limitation and user guidance reduce reputational risk in rare events.

**No overselling to vulnerable communities:** Prepper and emergency-preparedness messaging emphasizes one use case among many, not false security; privacy and forensics positioning honest about radio-isolation limits.

**Independent oversight:** External financial advisor co-signs the cash-flow gate decision (Month 12.5, 2027-10-23), preventing founder bias; legal opinion on regulatory applicability obtained before product launch (not verified assumptions); customer-complaint and refund tracking flagged monthly.

## Collaboration Opportunities

- **Channel partners and resellers:** Established emergency-preparedness retailers, digital-forensics suppliers, and privacy-focused online communities can carry the product on consignment-free wholesale (margin share negotiable).

- **Critical-infrastructure pilots:** Government, utility, or emergency-planning agencies can co-develop reference use cases and documentation in exchange for pilot-unit access and reference rights.

- **Accredited testing labs and standards bodies:** The project seeks input from EMC labs on test method applicability (IEEE 299.1, MIL-STD-285 precedents not verified) to shape the standard scope and cost; feedback on shielding-claim wording helps refine industry best practices.

- **Academic and research partnerships:** TalTech (Tallinn University of Technology) radio and electronics groups can contribute RF design and measurement expertise in exchange for published credit, facility access, and follow-on variant work.

- **Insurance and legal advisors:** Product-liability insurers and EU compliance counsel can help refine warranty, claim scope, and regulatory posture in exchange for case documentation and potential industry publication.

- **Supplier and logistics partners:** Tallinn precision-metal fabricators (primary and secondary) and EU logistics providers gain volume-committed orders and inventory-smoothing; gasket suppliers secure a 30-day buffer-stock relationship.

## Long-term Vision

**Year 1–2:** Prove the single rigid enclosure across presale and infrastructure segments, reach positive cash flow, and unlock the EUR 350k follow-on. Establish Tallinn as a credible EU manufacturing base for **RF-isolation products**.

**Year 2–3:** Expand the product line: phone-only/smaller SKU variant (funded post-gate) and optional annual shielding re-verification service (recurring revenue). Widen critical-infrastructure procurement through documented reference customers.

**Year 3–5:** Grow to 5,000–10,000 units/year (estimate) across preppers, privacy, forensics, and infrastructure segments. Consider buffer-stock warehousing in central Europe to reduce delivery lead times. Explore adjacent RF-isolation niches: larger safe boxes, server-grade cages (deferred), and custom enclosures for enterprise.

**Sustainability:** Move toward operating margins of EUR 100k+/year (estimate based on 3,000-unit Year-2 run rate and EUR 201k contribution less EUR 80k opex); reduce reliance on presales; invest in brand and **compliance posture** as competitive moats.

**Exit or scale:** A profitable, stable hardware business serving multiple segments can be acquired by security, emergency-preparedness, or forensics players, or remain an independent niche with founder control. The goal is viable, not venture-scale.

## Call to Action

- **Presale deposits:** Open now through Month 8 (2027-06-08) at EUR 149 per unit, refundable until Month 8.5 (2027-06-23), delivery Months 6–9 (2027-04-08 to 2027-07-08).

- **Critical-infrastructure pilots:** Fast-track 10–20 units at cost-plus 20% (EUR 84 per unit), agreed by Month 3 (2027-01-08), delivered Month 5 (2027-03-08), with reference-customer rights.

- **Advisors and channel partners:** Contact the project lead at neoneye@gmail.com with capacity, logistics, or procurement enquiries.

- **Tooling gate:** The hard-tooling decision gate closes at Month 6 (2027-04-08). Deposits ≥ EUR 80k (proposed threshold) unlock production.

- **Key milestones to track:** Accredited lab report (Month 5, 2027-03-08) and first shipments (Months 6–9, 2027-04-08 to 2027-07-08).
