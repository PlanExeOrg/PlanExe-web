### Premise Attack 1 — Integrity
_Forensic audit of foundational soundness across axes._

**[STRATEGIC] A €750k personal bet on selling Faraday cages for phones and laptops to protect against a Carrington-class storm targets the wrong failure: such a storm's damage is to long conductors and grid transformers, not to unplugged handhelds, and the buyers who might pay are too small and too slow to fund a hardware company.**

**Bottom Line:** REJECT: The product shields phones and laptops from a storm that mainly harms the power grid, and the buyers who could repay €750k do not buy it.


#### Reasons for Rejection

- A solar superstorm drives currents through long conductors such as power lines, transformers and telegraph runs, so the product shields the device class least exposed while the grid, which makes the devices useful, stays unprotected.
- The Stage 2 release of €350k 'conditional on positive cash flow' after a €400k Year-1 burn (user constraint) needs a certified, tooled, pre-sold single-SKU product to turn cash-positive within about 12 months, but certification, tooling and inventory all come before revenue and the buyers are a thin niche.
- European prepping networks are a small, price-sensitive, DIY-minded segment that can replicate a shielded metal box with a cheap metal container and a lining, so a €400k-funded precision-metal product has no clear premium to charge.
- Critical-infrastructure buyers buy shielding for racks, rooms and facilities under formal tender and test standards, and Tallinn-made phone and laptop boxes are not what those buyers procure, which is why the plan defers server-grade cages and thereby defers the only buyer with real budget.
- Demand depends on an event with no dated occurrence: the May 2024 G5 storm caused only minor disruption, so the pre-sale pitch has no recent damage to point to and sales are likely to be episodic fear-driven spikes, not steady cash flow.

#### Second-Order Effects

- 0–6 months: Funds go to design, shielding test-lab time and prototype tooling while pre-sale conversion stays unproven, so a large share of the €400k Year-1 burn is spent before any evidence of demand exists.
- 1–3 years: The Stage 2 cash-flow gate is missed or met only through discounting, leaving the founder to choose between writing off the €350k follow-on and funding it from personal savings anyway with a certified but low-volume SKU.
- 5–10 years: The company ends as a small niche accessory maker or is wound down, and the founder's personal capital is lost to a threat model that never needed a phone-sized cage.

#### Evidence

- Case/Incident — Carrington Event (1859): the documented damage was to telegraph networks, long wire systems, which supports the point that the exposure is long conductors, not standalone handheld devices.
- Case/Incident — G5 geomagnetic storm (May 2024): the strongest storm in about two decades produced only relatively minor disruption, though some grid operators such as Transpower in New Zealand took precautionary measures, which undercuts a fear-driven demand case.
- Law/Standard — IEEE Std 299 (shielding effectiveness of enclosures, 9 kHz to 18 GHz): this is the recognised test method for enclosures and sets a verification burden (lab time and cost not verified) that a single-SKU startup must pay before any sale.



### Premise Attack 2 — Accountability
_Rights, oversight, jurisdiction-shopping, enforceability._

**[STRATEGIC] — The Wrong Armor Fallacy: a €750 k (user constraint) bet on shielding phones and laptops against a Carrington-class storm, a threat that mainly hits long power lines, transformers and cables, so the product protects what was never the target and sells comfort to people who will have no grid to charge what's inside.**

**Bottom Line:** REJECT: The Wrong Armor Fallacy leaves the product shielding the least vulnerable part of the Carrington threat while the grid, the real failure, stays untouched. A founder's €750 k (user constraint) should not buy certified reassurance for a risk the box does not address.


#### Reasons for Rejection

- A buyer who pays to feel protected is sold a safety story that does not match the physics, because the 1859 storm's danger is currents in long conductors, not a pulse frying the handset in a pocket, so the customer's trust and money are taken on a false premise.
- Critical-infrastructure buyers answer to regulators and procurement rules and will not pick a single-SKU consumer-grade box from a one-person Tallinn start-up, while the 'certify' step rests on self-selected labs and marketing claims that nobody independent audits.
- Faraday-bag claims already sit in a market where the lab-tested vendors are the exception, so a new entrant adds one more unverifiable box to a pile of look-alikes that can be copied by any metal shop, with no way to recall a failure once the 'doomsday' use case arrives and the shell is breached by a pinhole or a bad seam.
- The value rests on fear-marketing to a small prepper niche for a product with one purchase per customer, no repeat revenue, and no proof the 'positive cash flow' trigger for the €350 k (user constraint) follow-on is reachable, so the founder is lending savings to a story, not a market.

#### Second-Order Effects

- **T+0–6 months — The Cracks Appear:** Pre-sale deposits from prepper networks arrive before any independent shielding test exists, turning early customers into creditors of an unfinished product.
- **T+1–3 years — Copycats Arrive:** Cheap metal-box and pouch clones undercut the single SKU, and the founder must either race to the bottom or retreat into ever louder survival claims.
- **T+5–10 years — Norms Degrade:** Shielding marketing normalises 'storm-proof your phone' as a purchase, pulling attention from grid hardening, spare transformers and community resilience that actually decide the outcome.
- **T+10+ years — The Reckoning:** If a major geomagnetic event comes, owners open the box to a working phone with no network, no power and no charger, and the brand becomes shorthand for useless preparedness.

#### Evidence

- Case/Report — The March 1989 Hydro-Québec geomagnetic storm collapsed the grid and left about five million people without power for roughly nine hours, an event that damaged the power system, not consumer phones.
- Case/Report — The 1859 Carrington Event is documented through telegraph systems, where induced currents in long lines let operators work some equipment with batteries disconnected: the harm path ran through long conductors, not pocket-sized devices.
- Law/Standard — IEEE Std 299-2006 (measuring shielding effectiveness of enclosures) is the usual reference, and its use by only some consumer Faraday vendors shows how thin independent verification is in this niche.
- Narrative — Front-Page Test: 'Founder spends €750,000 of personal savings on storm boxes; when the grid fails, customers hold shielded phones they cannot charge.'



### Premise Attack 3 — Spectrum
_Enforced breadth: distinct reasons across ethical/feasibility/governance/societal axes._

**[STRATEGIC] A geomagnetic storm threatens long power lines, not pocketed phones, so €750k buys a certified answer to a problem the Carrington scenario doesn't pose to handhelds.**

**Bottom Line:** REJECT: This plan sells a sealed metal box as insurance against a disaster that would break the grid and not the handheld, and it should not receive a single euro of the €750k.


#### Reasons for Rejection

- Physics: storms of Carrington class act by inducing currents in kilometres-long conductors such as grids and pipelines, so a phone or laptop sitting in a drawer is not the failing component and the enclosure shields against a threat that is not aimed at it.
- Utility: the single-SKU box for phones and laptops protects devices that, after the grid collapses, are still cut off from dead cell towers and a dark internet, so the buyer is purchasing an intact brick with a depleting battery.
- Finance: the €350k follow-on is released only on positive cash flow after a €400k Year-1 burn, which demands that a certification-heavy hardware start-up turn profitable in twelve months on a product bought once, if at all.
- Market: pre-selling to prepping networks and critical-infrastructure buyers pairs a small hobbyist niche with buyers who specify room-scale or rack-scale shielding, and deferring server-grade cages abandons the only segment with real budgets.
- Legitimacy: a 'certified' claim of protection against a once-in-centuries event can never be field-validated by the customer, so every sale rests on fear and leaves the founder exposed to misleading-advertising liability under EU consumer law.

#### Second-Order Effects

- 0–6 months: Design and certification spend runs ahead of any pre-orders, and early prepper-forum buyers ask for proof against an event no lab can reproduce, so the first-year €400k is consumed before a single credible sales figure appears.
- 1–3 years: Cash flow stays negative, the €350k follow-on never unlocks, and the Tallinn production line is left with idle precision-metal tooling and unsold stock of a product with no repeat demand.
- 5–10 years: The venture dissolves with the entire €750k of personal savings written off, and the brand is remembered as one more fear-driven gadget that pushed buyers toward the wrong preparation.

#### Evidence

- Case/Incident — Hydro-Québec geomagnetic blackout (1989): a storm collapsed the provincial grid and left about six million people without power for roughly nine hours, showing the damage path runs through the grid, not pocket devices.
- Case/Incident — May 2024 Gannon storm (G5): NOAA reported grid irregularities and GPS/HF degradation while FEMA and the Department of Energy reported no significant impact to the population, so no demand-validating device-loss event occurred.
- Report/Guidance — IEEE 299.1-2013 (2013): defines shielding-effectiveness measurement for enclosures between 0.1 m and 2 m, which is the only established yardstick for 'certified' claims on a small box and does not test against any space-weather event.



### Premise Attack 4 — Cascade
_Tracks second/third-order effects and copycat propagation._

**The plan sells a pocket-sized shield against a threat that does not hit pocket-sized devices. Carrington-class storms damage long conductors such as grids and cables, not an unplugged phone in a drawer. It then pairs that mismatch with a commodity product, a tiny non-repeating buyer pool, and a self-imposed cash-flow gate the product cannot pass.**

**Bottom Line:** Abandon the premise. A phone-and-laptop Faraday box does not address how a Carrington-class storm actually causes harm, which is through grid and network failure, and it competes in a category where certification is already commodity marketing. Better design, cheaper Tallinn manufacturing or smarter staging of the €750 k cannot fix a product that protects the wrong thing for a buyer who purchases it once.


#### Reasons for Rejection

- THE WRONG-VICTIM PARADOX: The 1859 storm burned telegraph lines. The March 1989 Québec storm collapsed a grid through long-conductor induced currents. Nothing in that record shows damage to small, disconnected consumer electronics. The brand 'Carrington Event Prep' promises protection for devices that were never the casualty. The real loss is the grid, which a €400 k enclosure cannot protect. A buyer who thinks it through will conclude the product addresses a different disaster from the one they fear.
- THE DARK-PHONE DEAD-END: If a storm takes down the grid and the network, a protected phone becomes an offline brick once its battery drains. The enclosure keeps a device alive that has no power, no towers and no internet to use. The value proposition therefore weakens exactly when the scenario it is named after occurs. Only a Faraday-plus-power-plus-comms bundle would matter, and that is a different, larger, costlier product the plan has not defined.
- THE CERTIFICATE COMMODITY TRAP: Established brands such as Mission Darkness and GoDark already advertise lab-tested bags and enclosures citing MIL-STD-188-125 and IEEE 299 (vendor marketing, not independently confirmed). A new single-SKU entrant is a late arrival in a crowded, cheap category. Estonian machining adds cost and weight against rolled-fabric bags that already carry the same buzzwords. Certification gets the product to parity but gives no advantage.
- THE ONE-SALE CUSTOMER LOOP: A prepper buys one enclosure and never returns. There is no consumable, no upgrade cycle and no network effect. A €350 k follow-on that is conditional on 'positive cash flow' in Year 1 assumes pre-sales will cover certification, tooling, inventory and marketing at once. For a sub-scale niche, that gate is very likely to fail. The plan then stays in permanent half-funded limbo with no revenue to justify the second tranche.
- THE PROCUREMENT MIRAGE: 'Critical-infrastructure buyers' do not buy phone boxes. They buy engineered shielded rooms, rack-level and site-level protection, under multi-year tender cycles, with accredited test reports and liability backing. Deferring server-grade cages removes the only part of the range those buyers could care about. The sales story is aimed at the audience least able to buy this product.
- THE UNFALSIFIABLE PROMISE LIABILITY: The headline benefit, surviving a once-in-centuries solar superstorm, cannot be verified in the field. Lab shielding-effectiveness figures are not storm survival. Marketing 'Carrington-proof' to European consumers invites consumer-protection and misleading-claims exposure (general EU unfair-commercial-practices principles, specific application not verified). A single failed unit or a skeptical review becomes a reputational and legal problem for a one-person-funded company.

#### Second-Order Effects

- Months 0-6 (2026-10-08 to 2027-04-08): Cash goes to enclosure design, test-lab fees, tooling and a Tallinn supplier before a single binding order exists. Pre-sale conversion lands far below plan, and early customer interviews raise the 'my phone wasn't the problem' objection that the plan does not answer.
- Months 6-12 (2027-04-08 to 2027-10-08): Certification slips, and pre-sale promises begin to age. Marketing leans harder on fear-based claims such as 'Carrington-proof' to compensate for weak demand. Reviewers, prepper forums and consumer groups start questioning the physics, which damages credibility in the very community the plan relies on.
- Months 12-15 (2027-10-08 to 2028-01-08): The positive-cash-flow gate for the €350 k tranche is missed, or is passed only by a one-time pre-sale spike that does not repeat. The founder must either release the second tranche against the stated rule or stop. Sunk-cost pressure favors releasing it, which would turn a bounded loss into a larger one.
- Months 15-30 (2028-01-08 to 2029-04-08): Inventory of a single-SKU, single-purpose metal product sits unsold and cannot be repurposed. Larger incumbents undercut on price, or the same shielding claims appear in cheaper fabric bags. Distribution is limited to a niche that has already bought once.
- Months 30-60 (2029-04-08 to 2031-10-08): The venture winds down with most of the €750 k (user constraint) spent. It leaves behind unsold stock, a certification file with no market, and possible warranty or advertising-claim disputes. If the 'critical-infrastructure' pivot is attempted late, it fails for lack of engineering credibility and project references.

#### Evidence

- The 1859 Carrington Event is documented as a telegraph-network event. Operators saw sparks, some stations had paper ignite, and some operators kept sending with their batteries disconnected. The documented damage was to long-wire infrastructure, not to small standalone devices (Wikipedia and History.com summaries).
- The 13 March 1989 geomagnetic storm collapsed Hydro-Québec's James Bay transmission network in under 90 seconds. About six million people lost power for roughly nine hours (Hydro-Québec). The grid failed because of induced currents in long lines and transformers. A Faraday box on a phone would not have changed that outcome, and a 'Carrington prep' customer's real exposure is that outage.
- Existing products already occupy the shielding category. Mission Darkness markets bags and enclosures described as lab-tested to MIL-STD-188-125 and IEEE 299-2006, and other sellers advertise MIL-STD-188-125-2 results and over 100 dB attenuation (vendor claims, independent verification not confirmed). The proposed single SKU would arrive in a market where certification language is already common.
- No direct precedent exists for a self-funded, single-SKU 'solar superstorm' consumer hardware company reaching sustainable cash flow (not verified). The nearest analogy is the pattern of one-off, fear-driven preparedness products, which are bought once and then fade. That analogy is general and not tied to a named company.



### Premise Attack 5 — Escalation
_Narrative of worsening failure from cracks → amplification → reckoning._

**[STRATEGIC] — The Phantom Threat Tax: the product sells a metal box against a hazard (a Carrington-class storm) that acts through long grid and cable conductors rather than by frying handheld phones and laptops, so the enclosure protects against a danger that mostly does not reach the devices it holds, and the company's whole revenue case rests on that mismatch.**

**Bottom Line:** REJECT: This plan sells a one-product company on a threat the product does not meaningfully address, and it comes with a funding gate that rewards exaggeration. The gate is closed.


#### Reasons for Rejection

- Rights and dignity: the business monetizes fear and the dignity of anxious buyers, including critical-infrastructure staff, by selling a certified-looking assurance about a threat whose effect on the stored devices is, at best, unproven.
- Accountability and oversight: no recognized standard or regulator can tell a buyer that a phone-and-laptop enclosure delivers resilience against a geomagnetic storm, so a self-funded founder would be certifying his own claims, and critical-infrastructure buyers would be held responsible for a procurement that cannot be audited.
- Systemic risk and scale: a Carrington-class event would mainly hit transformers, long conductors and the grid. A buyer holding a boxed phone with no grid, no network and no charging would have a false sense of preparedness, which could lead people to under-invest in power, communications and supply continuity.
- Value-proposition rot: the plan treats 'Faraday' as a premium material feature, yet the product is a commodity metal box. Its real demand is a small, fear-driven, event-triggered niche, and the 'positive cash flow' gate for the €350 k follow-on (user constraint) depends on fear spikes rather than repeat use, so the company either quits or inflates its claims to survive.

#### Second-Order Effects

- T+0–6 months — The Cracks Appear: Months 0-6 (2026-10-08 to 2027-04-08) are spent on certification, tooling and pre-sale outreach. Pre-orders from prepper networks are small and sporadic, and no test lab or buyer can name a standard that proves the product helps against the event named on the box.
- T+1–3 years — Copycats Arrive: Months 12-36 (2027-10-08 to 2029-10-08), cheap imported shielded pouches and boxes undercut the Tallinn-built unit. The founder must pick between lower margins and louder claims, and he picks louder claims.
- T+5–10 years — Norms Degrade: Months 60-120 (2031-10-08 to 2036-10-08), 'solar-storm-proof' labels spread across the consumer market. Independent testers and journalists show that the shielding is not the relevant protection, and the whole category gets treated as snake oil, which also hurts legitimate resilience work.
- T+10+ years — The Reckoning: After Month 120 (2036-10-08), the stock sits in warehouses and attics, the founder has lost the full €750 k (user constraint), and the first real grid failure shows that the stored devices had no grid or network to connect to, so the brand becomes a cautionary example.

#### Evidence

- Case/Report — Carrington Event (1859): The documented damage was to long telegraph lines, with induced currents causing sparks and fires at telegraph stations. It was not damage to small, localized equipment, so the historical record does not support a 'box your handheld device' remedy.
- Case/Report — Hydro-Québec blackout (13 March 1989): A geomagnetic storm collapsed the whole provincial grid within about two minutes and left millions without power for roughly 12 hours. The harm came through the grid, and a device in an enclosure would have been powerless and cut off anyway.
- Principle/Analogue — Electromagnetics: Geomagnetic storms produce very large-scale, quasi-DC induced electric fields. Their effects accumulate over long conductors such as power lines, pipelines and telegraph cables, while small isolated devices see little of the effect. A Faraday cage addresses a different threat, a fast high-frequency pulse such as the E1 component of a nuclear EMP, so the product name and the hazard it is marketed against do not match.
- Principle/Analogue — Behavioral Economics: Demand for protection against rare catastrophes spikes after salient events and then fades (neglect of probability). Revenue therefore comes in bursts and cannot meet a 'sustained positive cash flow' trigger.