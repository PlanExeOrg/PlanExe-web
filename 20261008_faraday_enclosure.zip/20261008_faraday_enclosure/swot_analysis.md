
## Strengths 👍💪🦾
- Proven concept: Faraday enclosures are technically mature, so risk is commercial rather than scientific.
- Tallinn has a low-cost, ISO-certified sheet-metal base (laser cutting, bending) suited to a rigid single SKU with soft tooling.
- Evidence-gated sequencing: hard tooling (30k, estimate) is released only when net deposits reach EUR 80k (proposed threshold) and the lab report confirms the design.
- Strong unit economics on paper: EUR 149 list (estimate) less EUR 82 direct cost gives EUR 67 contribution per unit (estimate).
- No debt and a self-funded EUR 750k (user constraint), so there is no debt service or investor pressure.
- Clear gate rules: deposits are liabilities, the gate is defined, and there is a presale cutoff and refund triggers.
- Claim discipline: claims are limited to measured attenuation, and the accredited report is published with every unit.

## Weaknesses 👎😱🪫⚠️
- KILLER APPLICATION MISSING: no single compelling use case yet makes buying urgent. Disaster prep is a rare-event purchase with a weak, hard-to-prove benefit. Privacy, forensics and travel uses are untested and fragmented.
- Gate headroom is thin: the base case of 750 units per quarter gives EUR 30.25k, only EUR 5.25k above the EUR 25k gate (estimate). At EUR 15 margin the quarter loses EUR 8.75k (estimate).
- Free contingency is only EUR 20k, and production headroom is 0k. A re-test plus a costlier standard could reach 35k, leaving a 15k gap with no funding source.
- CE/EMC Directive applicability is not verified. A 10-30k unfunded cost (estimate) and 8-12 weeks of delay would follow if it applies.
- The founder lacks in-house RF expertise and depends on a consultancy and a university whose timelines are uncertain.
- Founder-led with key-person risk and one SKU. A single size may fit few devices well.
- Open decisions: whether deposits can fund unit cost, and how the EUR 350k tranche would be used.

## Opportunities 🌈🌐
- KILLER APPLICATION CAN BE DEVELOPED: test candidate flagship uses, such as a forensics/evidence-handling and corporate travel-security kit (phones and laptops carried into hostile environments) or a continuity-of-operations spare-device kit. These buyers have recurring budgets, a clear need for verified attenuation, and a higher willingness to pay than preppers. Select the one with the best deposit velocity and margin by Month 3 (2027-01-08).
- Multi-use RF-isolation positioning widens the market beyond preppers, as Silent Pocket shows.
- A published accredited report is a differentiator against competitors' unverified claims (Mission Darkness precedent).
- Fast-track infrastructure pilots (EUR 84 per unit, estimate) can supply early references.
- Annual re-verification service as a recurring revenue stream and a way to support the seal's long-term integrity.
- Post-gate expansion: a phone-only SKU, EU buffer stock, and resellers in forensics supply.
- Media attention on solar storms and grid resilience can lift awareness.

## Threats ☠️🛑🚨☢︎💩☣︎
- Obstacles to a killer app: the buyers with the strongest need (forensics, security teams) have long procurement cycles and favour established US brands. Splitting messaging across segments dilutes the brand. A single 420 x 280 x 50 mm size (estimate) may not suit the lead use case. The lab report may show weak low-frequency attenuation, undermining the flagship claim.
- Prepper-heavy demand is low-margin and price-sensitive, and the gate would then fail.
- Failed or costlier lab test (re-test 8-15k; MIL-STD-285 +10-20k, not verified) delays the report by about 2 months and likely forces the 90-day gate extension.
- Infrastructure sales cycles may run past Month 12 (2027-10-08), so revenue lands after the gate window.
- Liability and reputational exposure if the product underperforms in a real event. Insurability is not verified.
- Refund spikes if the news cycle fades (20-30% of deposits, estimate).
- Incumbents or retailer private labels can undercut on price. Fabricator price increases (10-20%, estimate) and gasket supply delays also threaten margin.

## Recommendations 💡✅
- By Month 0.5 (2026-10-23): the founder signs the gate convention, the monthly burn schedule, and the consultancy and university milestones. Contact 2-3 accredited labs to confirm the standard, cost and date.
- By Month 3 (2027-01-08): the founder runs parallel landing-page and deposit tests for 3 candidate killer apps (forensics/travel-security kit, continuity kit, prepper). Choose the flagship by deposit velocity and average price, and reallocate 10-15k of marketing to it.
- By Month 1 (2026-11-08): legal counsel delivers the opinion on CE/EMC applicability, and the founder obtains an insurance quote. Lock insurance terms by Month 2.5 (2026-12-23). Settle the CE fallback funding before presale launch.
- By Month 1 (2026-11-08): the founder decides how to cover the 15k worst-case lab gap, either by raising the reserve to 30k through a 10k marketing cut or by cutting the follow-on batch.
- By Month 3 (2027-01-08): the founder agrees 1-2 fast-track infrastructure or forensics pilots (10-20 units, delivery Month 5 = 2027-03-08) with reference rights.
- By Month 1 (2026-11-08): the operations lead pre-qualifies a secondary fabricator and two gasket suppliers, and fixes primary pricing and capacity in a signed agreement.

## Strategic Objectives 🎯🔭⛳🏅
- By Month 1.5 (2026-11-23), sign a fixed-cost lab statement of work (15k total) with a report date no later than Month 5 (2027-03-08).
- By Month 3 (2027-01-08), identify one flagship use case (the killer app) that accounts for at least 40% of deposits (proposed threshold) and an average realised price of EUR 120 or more per unit.
- By Month 6 (2027-04-08), reach net presale deposits of at least EUR 80k (target EUR 120k), with prepper share at or below 70% (proposed threshold).
- Deliver 1,500 units within the EUR 400k cap by Month 12 (2027-10-08) (estimate).
- By Month 12.5 (2027-10-23), achieve a trailing-quarter operating surplus of at least EUR 25k (672+ units at EUR 67 contribution, proposed threshold) with sign-off by founder and advisor.

## Assumptions 🤔🧠🔍
- The canonical figures hold: EUR 149 list price, EUR 70 unit cost and EUR 12 freight (estimates).
- IEEE 299.1 or an equivalent standard is accepted by the lab (not verified).
- The product falls outside the EMC Directive and needs no CE marking (not verified).
- Deposits are held as liabilities and do not count toward the cap or the gate.
- Presale conversion and deposit rates match the segment estimates.
- The Tallinn fabricator holds pricing and capacity.
- The founder is available to visit Tallinn on the planned schedule.

## Missing Information 🧩🤷‍♂️🤷‍♀️
- Evidence of willingness to pay by segment, and which use case could be the killer app.
- Lab-confirmed standard, frequency band, cost and report date.
- Legal opinion on EMC Directive and product-safety applicability, and insurability of shielding claims.
- Competitor pricing and performance data in Europe, including private-label risk.
- Real fabricator quotes for unit cost, tooling and capacity, and gasket sourcing.
- Whether deposits may pay unit cost, and the deposit share of the price.
- Intended use of the EUR 350k tranche.
- University IP and timeline terms.

## Questions 🙋❓💬📌
- Which single buyer, in which single moment of need, would pay EUR 149 without a long sales cycle, and what evidence supports that?
- Is the founder willing to pivot the brand away from the Carrington narrative if the forensics or privacy segment proves stronger?
- How will the plan cope if the lab shows weak low-frequency shielding? Would a narrower claim still sell?
- Which unfunded risk is the founder prepared to absorb first: the lab gap (15k), a CE requirement (10-30k), or a gate miss?
- Is a EUR 5.25k margin over the gate acceptable, or should the gate threshold, price or volume plan change?