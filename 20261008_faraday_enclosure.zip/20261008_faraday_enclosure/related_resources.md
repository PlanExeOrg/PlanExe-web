## Suggestion 1 - Mission Darkness Faraday bags and boxes (MOS Equipment)

US maker of Faraday bags, boxes and cases sold to digital-forensics, law-enforcement, military and consumer buyers. Products are marketed with published shielding-effectiveness test data and a stated frequency range, and sold directly and through resellers. Operating for roughly a decade (approximate, not verified).

### Success Metrics

Sustained multi-year sales to forensics and government buyers (qualitative; volumes not verified)
Published test data used as a procurement qualifier
Broad reseller and distributor network

### Risks and Challenges Faced

Claim credibility: addressed by publishing third-party test results and stated test method.
Knock-offs with unverified claims: addressed by differentiating on documented testing.
Seal and closure wear on bags: addressed by durable closures and guidance on handling.

### Where to Find More Information

https://www.mosequipment.com (Mission Darkness product and test pages)
Product data sheets and test-report downloads on the manufacturer site

### Actionable Steps

Contact MOS Equipment sales or technical support via the website form to ask which test method and lab they use.
Buy one box and one bag and measure them on the planned in-house rig as a benchmark.
Approach their reseller list (forensics suppliers) as potential channel partners.

### Rationale for Suggestion

Closest commercial analogue: a documented-test Faraday product sold to forensics and privacy buyers, which supports the plan's multi-use RF-isolation narrative and the claim-to-evidence posture. Geographically distant (US); no comparable Estonian precedent was found.
## Suggestion 2 - Silent Pocket Faraday products

US consumer brand selling Faraday phone pouches, laptop sleeves and bags for privacy, travel and security. Sells online and through retail, with a privacy and everyday-use positioning rather than disaster-only messaging.

### Success Metrics

Long-running consumer brand with online and retail presence (volumes not verified)
Positioning beyond preppers into travel and privacy
Product range expanded from phone pouches to laptop and bag formats

### Risks and Challenges Faced

Niche demand: widened by privacy, travel and key-fob use cases.
Fabric seal degradation: addressed with usage guidance and replacement products.
Claim scrutiny: addressed by stated test results.

### Where to Find More Information

https://silent-pocket.com
Brand product pages and published testing statements

### Actionable Steps

Contact the company through its website for wholesale or partnership enquiries.
Study its multi-use messaging for campaign design.
Compare price points against the EUR 149 list price (estimate).

### Rationale for Suggestion

Shows that the multi-use RF-isolation narrative can broaden demand beyond preppers, directly supporting the plan's cash-flow gate logic. Fabric rather than rigid metal, so a design contrast; geographically distant.
## Suggestion 3 - Tallinn University of Technology (TalTech) radio and electronics research capacity

Estonian public university with electronics, radio engineering and measurement research groups. Candidate partner for co-development and in-house rig validation in exchange for access and credit rights, as the plan proposes.

### Success Metrics

Existing university-industry collaboration programmes (not verified in detail)
Availability of RF measurement equipment (to be confirmed)

### Risks and Challenges Faced

Academic timelines versus commercial schedule: settle milestones and penalties in writing before work starts.
IP ownership: agree terms up front with the technology transfer office.

### Where to Find More Information

https://taltech.ee (department and research group pages)
TalTech technology transfer or industry cooperation office

### Actionable Steps

Contact the TalTech industry cooperation or technology transfer office to identify the relevant radio or electronics lab lead.
Request a paid measurement-services quote and IP terms by Month 0.5 (2026-10-23).
Keep a part-time RF engineer fallback if no agreement by Month 1.5 (2026-11-23).

### Rationale for Suggestion

Only local, same-country resource for RF measurement and expertise; chosen as a secondary suggestion because no confirmed prior Faraday project there is documented. Treat as a capability reference, not a case study.

## Summary

Reference projects for a self-funded, single-SKU Faraday enclosure launched from Tallinn with presales and staged funding. Few projects match all traits, so the picks cover three angles: consumer RF-isolation products (Mission Darkness, Silent Pocket), crowdfunded or presold hardware with staged tooling (Pebble-style crowdfunding is avoided; Estonian hardware such as Skeleton Technologies is not comparable), and Estonian or EU shielding and test capacity (TalTech, accredited labs). Geographically close precedents are limited, so US and UK consumer Faraday brands serve as product and claims references. All contacts are organisations or roles to approach; no personal names, emails or figures are asserted. Figures such as prices and volumes of these firms are not verified. Use them to benchmark proof standards, claim wording, channels and test costs against the plan's EUR 400k Year-1 cap (user constraint), EUR 149 list price (estimate) and hard-tooling gate of EUR 80k net deposits (proposed threshold).