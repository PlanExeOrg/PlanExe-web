36 explicit calculations found in the documents re-computed without an LLM; 1 does not match its stated result.

| Section | Statement | Stated | Computed |
|---|---|---|---|
| Expert Criticism | ' yet the arithmetic for the gate ('750 units × EUR 67 = EUR 30.25k') does not specify whether this includes deposit-funded orders | 30.25k | 50.25k |
