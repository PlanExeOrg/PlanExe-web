
## Documents to Create

### 1. Project Charter & Governance Framework

**ID:** 85af38e3-5fa0-45c0-a86e-f2690889a110

**Description:** Foundational charter document establishing project scope (single-SKU rigid Faraday enclosure, Tallinn manufacturing, EU market), stakeholder roles, decision authorities, approval governance, and critical success criteria. Audience: founder, external advisor, all key roles. Includes cash-flow gate definition, tranche-release conditions, and tiebreak rules. Status: prerequisite for all downstream planning.

**Responsible Role Type:** Project Manager & Founder

**Primary Template:** PMI Project Charter Template

**Secondary Template:** World Bank Logical Framework

**Steps:**

- Define project scope, objectives, and constraints (EUR 400k Year-1 cap, EUR 350k conditional tranche, Month 12.5 = 2027-10-23 gate decision).
- Establish governance structure: founder + external advisor sign-off on cash-flow gate by Month 12.5 (2027-10-23).
- Document decision authorities for critical gates: design-readiness (Month 5 = 2027-03-08), hard-tooling release (Month 6 = 2027-04-08), presale cutoff (Month 8 = 2027-06-08), cash-flow gate (Month 12.5 = 2027-10-23).
- Specify approval authorities for gate decisions and escalation rules for ambiguous results.
- Publish charter and obtain founder and advisor sign-off by Month 0.5 (2026-10-23).

**Approval Authorities:** Founder, External Financial Advisor

### 2. Cash-Flow Gate Measurement Convention & Governance Rule

**ID:** 88a41893-e4a3-4ada-b07d-b57ada98927d

**Description:** Binding written rule defining what constitutes positive cash flow for the EUR 350k tranche release. Specifies: operating cash surplus = delivered-unit receipts minus direct unit costs minus recurring opex (presale deposits excluded); threshold EUR 25k quarterly (Months 9-12 = 2027-07-08 to 2027-10-08); measurement window end Month 12.5 (2027-10-23); tiebreak rule for ambiguous ±5k range; external audit requirement. Audience: founder, external advisor, stakeholders. Status: must be published before presale launch.

**Responsible Role Type:** Financial Officer & Founder

**Primary Template:** Financial Governance Policy Template

**Secondary Template:** Funding Agreement Conditions Precedent

**Steps:**

- Define operating cash flow calculation method: receipts from delivered and paid units only.
- Exclude presale deposits from cash-flow definition; classify as liabilities in separate earmarked account.
- Set threshold (EUR 25k quarterly, Month 9-12 = 2027-07-08 to 2027-10-08 measurement window).
- Define presale cutoff date (Month 8 = 2027-06-08) to ensure fulfillment before gate measurement.
- Document tiebreak rule: if result is -EUR 5k to +EUR 25k, founder + external advisor jointly decide within 5 business days.
- Specify weekly tracking dashboard and monthly cash reconciliation process.
- Obtain founder and external advisor signatures by Month 0.5 (2026-10-23).

**Approval Authorities:** Founder, External Financial Advisor

### 3. Year-1 Monthly Budget & Burn Schedule

**ID:** bee838fc-0a54-40fa-8f5c-d9770e254284

**Description:** Detailed month-by-month allocation of the EUR 400k Year-1 cap across design (EUR 70k, Months 0-2 = 2026-10-08 to 2026-12-08), in-house rig (EUR 40k, Months 0-2 = 2026-10-08 to 2026-12-08), accredited lab (EUR 15k, Months 2-5 = 2026-12-08 to 2027-03-08), soft tooling (EUR 20k, Months 2-5 = 2026-12-08 to 2027-03-08), production line (EUR 160k, Months 5-12 = 2027-03-08 to 2027-10-08), marketing/operations (EUR 75k), and redesign reserve (EUR 20k, uncommitted until Month 5 = 2027-03-08). Includes monthly cash-burn review gates at Months 5 and 8 (2027-03-08, 2027-06-08) with >10% variance freeze trigger. Audience: founder, financial officer, external advisor.

**Responsible Role Type:** Financial Officer

**Primary Template:** Startup Monthly Cash-Flow Budget Template

**Secondary Template:** Stage-Gate Funding Schedule

**Steps:**

- Break down the EUR 400k cap into category budgets (design, rig, lab, tooling, production, marketing, reserve).
- Allocate spend across Months 0-12 (2026-10-08 to 2027-10-08) based on project milestones (design freeze Month 2 = 2026-12-08, lab Month 5 = 2027-03-08, tooling Month 6 = 2027-04-08, fulfillment Months 6-9 = 2027-04-08 to 2027-07-08, gate measurement Months 9-12 = 2027-07-08 to 2027-10-08).
- Hold hard-tooling and full production-batch spending uncommitted until both conditions: deposits ≥EUR 80k AND lab pre-test confirms design (Month 5 = 2027-03-08).
- Establish monthly cash-burn review gates: Month 5 (2027-03-08) (EUR 40k overrun trigger), Month 8 (2027-06-08) (EUR 120k overrun trigger).
- Document contingency rules: if overrun >10%, freeze discretionary spending pending variance explanation.
- Preserve minimum EUR 30k runway for redesign fallback by Month 5 (2027-03-08).
- Create shared tracking spreadsheet (deposits, invoices, refunds, operating cash) for weekly founder-advisor review.

**Approval Authorities:** Founder, External Financial Advisor

### 4. Shielding Proof Standard & Accredited Lab Statement of Work

**ID:** 7abd525d-bd43-46b1-a6ce-b8050a0e86b7

**Description:** Fixed-price, fixed-date engagement with accredited EMC laboratory specifying: applicable RF shielding standard (IEEE 299.1 or confirmed alternative), frequency range, cost cap (EUR 15k), design-readiness review (EUR 2-3k, Month 4 = 2027-02-08), report delivery date (Month 5 = 2027-03-08, latest Month 6 = 2027-04-08), re-test provision, and penalty clauses for schedule slip (EUR 500/week credit). Signed by Month 1.5 (2026-11-23). Includes backup lab pre-qualification by Month 2 (2026-12-08). Audience: RF engineer, project manager, financial officer.

**Responsible Role Type:** RF Engineer & Project Manager

**Primary Template:** Professional Services Statement of Work Template

**Secondary Template:** Laboratory Testing Agreement

**Steps:**

- Contact 2-3 accredited EMC labs (Germany, Sweden, Netherlands, Estonia) for no-cost pre-engagement consultation by Month 0.5 (2026-10-23).
- Confirm applicable standard (IEEE 299.1 or alternative) and frequency range for small Faraday enclosures.
- Lock fixed cost (EUR 15k cap) and committed report delivery (Month 5 = 2027-03-08, no later than Month 6 = 2027-04-08).
- Request design-readiness review scope (EUR 2-3k, 2-week turnaround by Month 4 = 2027-02-08).
- Document re-test provision (included in EUR 15k cap or separately capped at EUR 10k).
- Include penalty clause for schedule slip: EUR 500/week credited against invoice.
- Pre-qualify secondary lab by Month 2 (2026-12-08) as fallback.
- Obtain signed statement of work by Month 1.5 (2026-11-23).

**Approval Authorities:** RF Engineer, Accredited EMC Laboratory Director

### 5. Enclosure Design & Prototype Validation Report

**ID:** 0edf4a7c-d5ce-485a-b91a-4bccba7251d7

**Description:** Technical documentation of the single rigid folded-aluminium/steel enclosure design (seam/gasket architecture, material specs, internal dimensions ~420 x 280 x 50 mm, mass 2-4 kg). Includes in-house rig validation results (attenuation at 50 MHz, 100 MHz, 500 MHz, 1 GHz across three independent prototype builds), seam-cycle repeatability data, and design-readiness confirmation for lab submission. Audience: RF engineer, project manager, accredited lab, compliance officer.

**Responsible Role Type:** RF Engineer

**Primary Template:** Engineering Design Review Template

**Secondary Template:** EMC Test Protocol Document

**Steps:**

- Define enclosure geometry, material (aluminium/steel), seam/lid closure design, and conductive-gasket specification.
- Establish in-house test rig methodology and measurement protocol.
- Run two independent prototype seam cycles by Month 3 (2027-01-08), documenting attenuation across frequency band.
- Measure repeatability and identify any design vulnerabilities (e.g., gasket compression variance, seam leakage).
- Prepare design-readiness dossier for lab pre-engagement review (Month 4 = 2027-02-08): materials, seam design, in-house attenuation data, test plan.
- Document any design trade-offs (size vs. margin, weight vs. shielding, cost vs. performance).
- Obtain lab pre-test feedback and confirm design readiness by Month 5 (2027-03-08).

**Approval Authorities:** RF Engineer, Accredited EMC Laboratory

### 6. Product Compliance & Regulatory Opinion

**ID:** 68b7e579-f559-4326-90f7-36d949724fc4

**Description:** Written legal opinion on EU product-safety rule applicability: EMC Directive 2014/30/EU, General Product Safety Directive 2001/95/EC, CE marking requirement, consumer-protection rules, warranty and liability exposure. Delivered by Month 1 (2026-11-08), informs claim-scope language and product-liability insurance strategy. Audience: founder, compliance officer, marketer, insurer.

**Responsible Role Type:** Legal Counsel

**Primary Template:** EU Product Compliance Legal Opinion Template

**Secondary Template:** Product Liability Risk Assessment

**Steps:**

- Commission legal opinion from EU product-safety counsel by Month 0.5 (2026-10-23).
- Review applicable directives: EMC Directive, General Product Safety Directive, harmonized standards.
- Assess CE marking requirement: whether enclosure is in-scope or exempt.
- Evaluate consumer-protection rules and warranty/disclaimer language.
- Assess liability exposure if shielding claims are exceeded in a real electromagnetic event.
- Deliver written opinion by Month 1 (2026-11-08).
- Recommend scope-limitation language for all marketing and presale materials.

**Approval Authorities:** Legal Counsel (EU Product Safety Specialist)

### 7. Presale Terms, Delivery SLA & Refund Policy

**ID:** 00f78eb1-4f29-41c0-88d5-84d340c14c27

**Description:** Customer-facing presale agreement specifying: order placement process, 30-day refund guarantee for fit/quality issues, 2-3 week ship SLA with 4-5 week estimated delivery, 48-hour customer support response target, device-fit responsibility disclaimer, and presale cutoff date (Month 8 = 2027-06-08). Linked to Product Fit Guide. Audience: presale customers, customer support, compliance officer.

**Responsible Role Type:** Legal Counsel & Presale Manager

**Primary Template:** E-Commerce Terms of Service Template

**Secondary Template:** Consumer Protection SLA Document

**Steps:**

- Draft presale order agreement covering order confirmation, payment, and refund process.
- Specify 30-day money-back guarantee for fit and quality issues; refunds processed within 10 business days.
- State delivery timeline: ships within 2-3 weeks of order confirmation, estimated delivery 4-5 weeks.
- Include device-fit responsibility: customer verifies device compatibility using published fit guide.
- Link to detailed Product Fit Guide with dimensions and device examples.
- Specify customer support escalation: 48-hour response target, contact path.
- Include presale cutoff date (Month 8 = 2027-06-08) and post-cutoff order handling.
- Review with legal counsel for EU consumer-protection compliance.
- Publish on presale landing pages and send to all presale customers by Month 1.5 (2026-11-23).

**Approval Authorities:** Legal Counsel, Presale Manager

### 8. Product Fit Guide & Device Compatibility Documentation

**ID:** 9d2ef388-1a4f-4b78-b925-fee2c48cad8e

**Description:** Customer-facing guide with photographs, internal dimensions (approx. 420 x 280 x 50 mm), and compatibility examples: laptops 13-17 inch (including specific models that fit and do not fit), phones 4.5-6.5 inch. Sets realistic expectations and reduces fit-complaint refunds. Audience: presale customers, customer support.

**Responsible Role Type:** Product Manager & Industrial Designer

**Primary Template:** Product Specification Sheet Template

**Secondary Template:** Customer Quick-Start Guide

**Steps:**

- Document internal enclosure dimensions (approx. 420 x 280 x 50 mm) with clear drawings and photos.
- Test fit against three common laptop sizes (13-inch, 15-inch, 17-inch examples).
- Test fit against five major phone models; document pass/fail with photos.
- Create 1-2 page guide with: internal dimensions, fit examples (devices that fit), explicit 'Does Not Fit' examples.
- Include packing and access instructions (where to place device, cable management).
- Link guide prominently on all presale pages and include in packaging.
- Update guide if prototype testing reveals fit surprises (e.g., certain 17-inch models too tight).
- Publish by Month 1.5 (2026-11-23).

**Approval Authorities:** Product Manager, Compliance Officer

### 9. Supply Chain Risk Register & Supplier Agreements

**ID:** 7be707ea-569b-481a-9d50-e75217dcd47b

**Description:** Live spreadsheet documenting Tallinn fabricator and gasket-supplier lead times, pricing, capacity headroom, and risk signals. Includes signed primary-fabricator agreement (pricing cap ±10% without 30-day notice, reserved capacity 500-1,000 units Year-1, delay remedy EUR 500/week credit). Pre-qualification of secondary fabricator (trial batch Month 2 = 2026-12-08) and backup gasket suppliers. Maintained monthly by supply-chain coordinator. Audience: supply-chain coordinator, project manager, financial officer.

**Responsible Role Type:** Supply Chain Coordinator

**Primary Template:** Supply Chain Risk Register Template

**Secondary Template:** Supplier Master Agreement

**Steps:**

- Identify primary Tallinn precision-metal fabricator with laser-cut and CNC-bend capability.
- Negotiate and sign Year-1 fabrication agreement: unit-cost caps (no increase >10% without notice), capacity reservation (500-1,000 units), delay remedy (EUR 500/week credit).
- Pre-qualify secondary Tallinn/Estonia fabricator; conduct trial batch (50-100 units) by Month 2 (2026-12-08) to confirm quality and tolerance parity.
- Source conductive-gasket material from primary and backup supplier by Month 1.5 (2026-11-23); lock pricing.
- Establish 30-day buffer gasket inventory (EUR 5-10k estimate) before production release.
- Create live risk register tracking: fabricator lead times, pricing, capacity headroom, supply signals.
- Update register monthly; trigger secondary-supplier transition if primary signals price increase >10% or capacity loss.
- Document all supply-chain decisions and escalation paths.

**Approval Authorities:** Supply Chain Coordinator, Founder

### 10. Presale Campaign Strategy & Segment Tracking Framework

**ID:** 261be031-1218-4684-b95a-87a0370b2b25

**Description:** Three-segment presale strategy (Prepper Networks, Infrastructure Buyers, Privacy/Forensics) with distinct landing pages, messaging, and weekly deposit tracking. Includes segment-mix pivot triggers (if Prepper >70% by Month 3 = 2027-01-08, reallocate EUR 10-15k marketing budget to Infrastructure/Privacy). Tracks deposit count, value, AOV, refund rate by segment. Audience: presale manager, project manager, external advisor.

**Responsible Role Type:** Presale & Demand Validation Manager

**Primary Template:** Go-to-Market Strategy Template

**Secondary Template:** A/B Testing & Campaign Measurement Plan

**Steps:**

- Define three buyer personas: Prepper (solar-storm/continuity), Infrastructure (emergency-response procurement), Privacy/Forensics (travel security/data protection).
- Create distinct landing pages for each segment with targeted messaging and value propositions.
- Set segment deposit targets: Prepper 40-50%, Infrastructure 30-40%, Privacy/Forensics 35-45% (by Month 6 = 2027-04-08).
- Establish weekly tracking dashboard: deposit count, total value, average order value, refund rate by segment.
- Define pivot trigger: if Prepper deposits exceed 70% by Month 3 (2027-01-08), reallocate EUR 10-15k marketing to Infrastructure and Privacy channels.
- Document fallback presale pricing (15-20% reduction estimate if conversion <40% by Month 3 = 2027-01-08).
- Negotiate 1-2 fast-track infrastructure pilot agreements by Month 3 (2027-01-08) (10-20 units at EUR 84/unit, delivery Month 5 = 2027-03-08).
- Set presale conversion target ≥40% and minimum average order value EUR 120 by Month 6 (2027-04-08).
- Publish weekly tracker shared with founder and external advisor.

**Approval Authorities:** Presale Manager, Project Manager

### 11. Compliance Checklist & Claim Substantiation Matrix

**ID:** a0cc255e-c6c7-4c65-948c-5ab3afbb6f95

**Description:** Ongoing compliance monitoring tool mapping all marketing claims to measured lab data. Specifies claim-scope limitation: enclosure protects stored spare devices only; does not protect active grid-connected equipment or guarantee protection in actual Carrington-class solar storm. Updated monthly to ensure all presale, website, forum, and social-media claims are tied to accredited lab attenuation data. Audience: marketer, compliance officer, legal counsel.

**Responsible Role Type:** Compliance Officer & Legal Counsel

**Primary Template:** Compliance Audit Checklist Template

**Secondary Template:** Marketing Claims Substantiation Matrix

**Steps:**

- Define scope statement (approved by legal counsel): protects stored spare devices only; no protection for active equipment or grid-scale events.
- Create claim-substantiation matrix: every marketing claim linked to a measured lab data point or test method.
- Publish scope statement on all presale materials, product data sheets, and packaging.
- After accredited lab report delivery (Month 5 = 2027-03-08), audit all presale and marketing materials against reported attenuation data.
- If lab results fall short of presale claims in any frequency band, narrow claims to tested band or commission redesign.
- Monthly compliance review: marketer, compliance officer, legal counsel check new materials before publication.
- Quarterly audit: legal counsel verifies all claims against lab report; flag any unsupported claims for revision.
- Update checklist if new regulatory guidance or customer complaints emerge.

**Approval Authorities:** Legal Counsel, Compliance Officer

### 12. Product-Liability Insurance Agreement & Risk Transfer Documentation

**ID:** bcc98fc3-8207-41d1-aa8c-89122b3347f0

**Description:** Signed product-liability insurance policy (EUR 250-500k coverage estimate, terms to be confirmed). Specifies covered perils (product defects, warranty breaches), excluded perils (acts of God, actual electromagnetic events), deductibles, and claim procedures. Locked by Month 2.5 (2026-12-23). Used to support compliance posture and manage reputational risk if a real EMI event damages customer devices. Audience: founder, legal counsel, financial officer.

**Responsible Role Type:** Legal Counsel & Financial Officer

**Primary Template:** Product Liability Insurance Agreement

**Secondary Template:** Risk Transfer & Insurance Certificate

**Steps:**

- Commission product-liability insurance quote from underwriter with experience in consumer electronics and RF/EMI products by Month 1 (2026-11-08).
- Confirm insurability of Faraday-enclosure shielding claims; identify exclusions (e.g., acts of God, actual Carrington events).
- Specify coverage limits (EUR 250-500k estimate) and deductibles.
- Negotiate terms to include Year-2 claims-made coverage if gate passes.
- Lock insurance terms by Month 2.5 (2026-12-23).
- Obtain signed policy and certificate of insurance.
- Publish certificate on presale website and include with product documentation.

**Approval Authorities:** Insurance Underwriter, Legal Counsel

### 13. Monthly Cash Reconciliation & Variance Dashboard

**ID:** 5ccc2727-cc37-4e0b-81db-9e5655767d4e

**Description:** Shared weekly tracking spreadsheet (deposits, invoices, refunds, operating cash, monthly burn vs. plan). Updated by financial officer, reviewed by founder and external advisor. Flags cumulative spend >10% variance (EUR 40k at Month 5 = 2027-03-08, EUR 120k at Month 8 = 2027-06-08) and triggers discretionary-spending freeze. Serves as audit trail for cash-flow gate measurement by Month 12.5 (2027-10-23). Audience: founder, financial officer, external advisor.

**Responsible Role Type:** Financial Officer

**Primary Template:** Excel/Google Sheets Cash-Flow Dashboard Template

**Secondary Template:** Weekly Financial Status Report

**Steps:**

- Create shared spreadsheet with weekly columns: deposits (by segment), invoices (delivered units), refunds, operating cash, month-to-date and cumulative burn.
- Separate presale deposits (liability column) from operating cash (asset column).
- Track monthly spend by category (design, lab, tooling, production, marketing, opex).
- Calculate cumulative burn vs. plan; flag >10% variance (EUR 40k alert at Month 5 = 2027-03-08, EUR 120k at Month 8 = 2027-06-08).
- Add monthly burn review dates (Months 2, 5, 8, 12 = 2026-12-08, 2027-03-08, 2027-06-08, 2027-10-08): freeze discretionary spending if variance >10% pending review.
- Update every Friday; share with founder and external advisor weekly.
- Archive snapshots at each gate milestone (Months 5, 6, 8, 12.5 = 2027-03-08, 2027-04-08, 2027-06-08, 2027-10-23) for audit trail.
- Use dashboard results to inform Month 3 (2027-01-08) presale-segment pivot decision and Month 12.5 (2027-10-23) gate sign-off.

**Approval Authorities:** Financial Officer, External Advisor

### 14. Stakeholder Engagement & Communication Plan

**ID:** 0aec4c41-f587-4340-a473-c54ebfefc532

**Description:** Calendar and format for founder-team check-ins (weekly 30 min, project manager + financial officer), monthly advisor board call (60 min), quarterly supplier calls (30 min), and critical-path escalation procedures. Identifies backup decision authority (operations advisor) and clarity on who makes decisions at each gate. Audience: founder, project manager, financial officer, external advisor, supply-chain coordinator.

**Responsible Role Type:** Project Manager

**Primary Template:** Stakeholder Communication Plan Template

**Secondary Template:** Project Status Report Format

**Steps:**

- Schedule weekly 30-minute check-in: founder, project manager, financial officer review cash, presale metrics, blockers.
- Schedule monthly 60-minute advisory board call: founder, project manager, financial officer, external advisor discuss progress, gate readiness, strategic pivots.
- Schedule quarterly supplier calls (Months 3, 6, 9, 12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08) to maintain Tallinn fabricator and gasket supplier relationships.
- Document critical-path escalation: decisions that block revenue (hard-tooling release, segment pivots, refund policy) require advisory-board input or approval.
- Designate backup operations contact (Erik, part-time advisor) with authority to step in if founder unavailable.
- Publish decision checklist at each gate (Months 5, 6, 8, 12.5 = 2027-03-08, 2027-04-08, 2027-06-08, 2027-10-23) so milestones are transparent.
- Define founder support: if presale fulfillment and cash management become overwhelming by Month 6 (2027-04-08), hire part-time operations person immediately.

**Approval Authorities:** Founder, Project Manager

### 15. Presale-to-Revenue-to-Gate Measurement Reconciliation Procedure

**ID:** 67d6867d-8b1c-4fb7-9054-ca882927946c

**Description:** Step-by-step procedure for Month 12.5 (2027-10-23) cash-flow gate sign-off: reconcile presale deposits held (liabilities), delivered-unit invoices (revenue), refund requests (liability reduction), and operating expenses to calculate trailing-quarter operating surplus (EUR 25k threshold). Includes audit trail, external advisor verification, tiebreak rule if result is ±5k of threshold, and tranche-release or wind-down decision. Audience: founder, financial officer, external advisor.

**Responsible Role Type:** Financial Officer

**Primary Template:** Financial Gate Measurement & Audit Procedure

**Secondary Template:** Fund Release Checklist Template

**Steps:**

- Archive all deposit records (customer name, amount, date, refund requests, resolution).
- Compile delivered-unit invoices for Months 9-12 (2027-07-08 to 2027-10-08), verified as paid by Month 12.5 (2027-10-23).
- Calculate direct unit costs (EUR 70/unit × delivered) and recurring opex (EUR 20k/quarter = EUR 20k for Q4).
- Compute operating surplus: total delivered invoices - direct costs - opex = EUR X.
- Compare X to EUR 25k threshold; document decision: pass (≥EUR 25k), fail (<EUR -5k), ambiguous (EUR -5k to EUR 25k).
- If pass: recommend tranche release.
- If ambiguous: founder + external advisor jointly decide within 5 business days per tiebreak rule (e.g., extend 90 days and re-measure).
- If fail: recommend wind-down or extension decision.
- Obtain founder and external advisor signatures on gate result by Month 12.5 (2027-10-23).
- Publish decision summary (pass/fail/ambiguous, reasoning, actions) within 5 business days.

**Approval Authorities:** Financial Officer, External Advisor, Founder

### 16. RF Engineering Milestone Agreement & Co-Development IP Terms

**ID:** 6077813e-cb7c-4f85-8d80-6ce22e8fc337

**Description:** Signed consultant agreement with RF engineer (Dr. Tamm) specifying milestones (prototype design Month 2 = 2026-12-08 EUR 5k, in-house rig validation Month 3 = 2027-01-08 EUR 8k, lab coordination Month 4-5 = 2027-02-08 to 2027-03-08 EUR 7k, redesign support EUR 3-5k), total EUR 23-25k. Includes knowledge-transfer and IP terms: consultant retains design credit/publication rights; founder owns exclusive manufacturing/commercial rights. Includes fallback plan (part-time RF hire 0.5 FTE EUR 25k/year) if consultant unavailable post-Month 5 (2027-03-08). Signed by Month 0.5 (2026-10-23). Audience: RF engineer, founder, project manager.

**Responsible Role Type:** Founder & RF Engineer

**Primary Template:** Independent Contractor Statement of Work

**Secondary Template:** Intellectual Property Assignment Agreement

**Steps:**

- Define milestone deliverables: (1) Prototype design documentation (Month 2 = 2026-12-08, EUR 5k), (2) In-house rig validation & attenuation report (Month 3 = 2027-01-08, EUR 8k), (3) Lab submission & pre-test review (Month 4-5 = 2027-02-08 to 2027-03-08, EUR 7k), (4) Design-revision support if needed (Month 5-6 = 2027-03-08 to 2027-04-08, EUR 3-5k contingent).
- Specify payment terms (EUR 5k upon design review sign-off, EUR 8k upon rig report, EUR 7k upon lab submission, EUR 3-5k upon revision completion).
- Document IP terms: consultant retains academic publication and credit rights; founder owns exclusive commercial and manufacturing rights.
- Include post-Month 5 (2027-03-08) retainer option: EUR 200-400/month (5 hrs/week estimate) for Q&A and warranty support during production ramp.
- Document exit plan: if consultant unavailable, part-time RF engineer (0.5 FTE, EUR 25k/year) hired to own design changes and warranty diagnostics.
- Include confidentiality and non-compete clauses (standard scope).
- Obtain signatures from consultant and founder by Month 0.5 (2026-10-23).

**Approval Authorities:** Founder, RF Engineer (Dr. Tamm)

### 17. Presale Deposit Contingency & Refund Escalation Protocol

**ID:** 78f3e60f-0b2d-41b3-abb1-ae542db1bd4a

**Description:** Procedure for handling presale refund requests and fit complaints. Specifies: 30-day money-back guarantee for fit/quality; refunds processed within 10 business days; fit complaints >10% by Month 7 (2027-05-08) trigger smaller-SKU variant study; refund rate >20% by Month 6 (2027-04-08) triggers messaging review. Includes weekly complaint log (reason, resolution, impact on cash flow), escalation authority, and decision thresholds. Audience: customer support, project manager, financial officer.

**Responsible Role Type:** Customer Support & Project Manager

**Primary Template:** Customer Service SOP & Escalation Procedure

**Secondary Template:** Contingency Response Plan

**Steps:**

- Document refund process: customer initiates within 30 days, support verifies fit/quality issue, refund issued within 10 business days to original payment method.
- Create weekly complaint log: customer name, complaint category (fit, quality, delivery, other), resolution, date resolved.
- Trigger thresholds: (1) Fit complaints >10% of orders by Month 7 (2027-05-08) → investigate root cause (undersized design, manufacturing variance, customer misunderstanding); (2) Refund rate >20% by Month 6 (2027-04-08) → trigger messaging/positioning review.
- Escalation authority: support manager handles complaints <EUR 100 refund; project manager handles larger requests; founder makes policy exceptions.
- Monthly dashboard: fit complaints %, refund rate %, average refund amount, cumulative refund cash flow impact.
- If fit complaints trigger alternate-size SKU study, defer to post-gate (funded by EUR 350k tranche or revenues).
- If refund rate spikes unexpectedly, founder may pause presale marketing and pivot narrative or reduce presale pricing.
- Monitor impact on cash-flow gate measurement: cumulative refunds count as negative cash flow in Month 12.5 (2027-10-23) calculation.

**Approval Authorities:** Project Manager, Founder

### 18. Founder Support & Business Continuity Plan

**ID:** dcb4cb73-0926-4052-a8f1-df1144e1bc67

**Description:** Contingency plan addressing founder burnout, illness, or visa issues. Designates backup operations advisor (Erik, 0.2 FTE, EUR 5-8k/year retainer) with escalation authority. Specifies: weekly backup advisor briefing on critical path, decision authority if founder unavailable, 48-hour response requirement for critical supplier/buyer issues, advisory-board backup for gate decisions. Includes documented decision-checklist and critical-contact list (lab, suppliers, key buyers). Audience: founder, backup operations contact, external advisor.

**Responsible Role Type:** Founder & Backup Operations Contact

**Primary Template:** Business Continuity & Succession Plan

**Secondary Template:** Crisis Management Procedure

**Steps:**

- Identify backup operations contact with hardware startup experience and Tallinn/EU network (e.g., Erik, experienced advisor).
- Establish retainer agreement (0.2 FTE, EUR 5-8k Year-1 estimate) with backup contact for on-call availability.
- Schedule weekly 30-minute briefing: backup contact receives update on critical path, presale metrics, supplier and buyer status.
- Document decision authority: if founder unavailable >3 days, backup contact can make decisions on: supplier transitions, presale pricing adjustments, refund policy exceptions (up to EUR 5k), customer escalations.
- Escalate tranche-release and hard-tooling decisions to external advisor if founder unavailable.
- Create critical-contact list: accredited lab, primary fabricator, gasket suppliers, top 5 presale buyers, legal counsel, insurance underwriter.
- Document key-person procedures: monthly decision checklist, presale campaign status, supply-chain risks, cash-flow status.
- Identify backup for quarterly Tallinn site visits (supply-chain coordinator as secondary).
- Plan for burnout mitigation: add part-time operations person (10-15 hrs/week) by Month 6 (2027-04-08) if fulfillment and cash management become overwhelming.
- Publish plan to external advisor and backup contact by Month 1 (2026-11-08).

**Approval Authorities:** Founder, External Advisor

### 19. Accrued Liabilities & Warranty Reserve Accounting Framework

**ID:** 043c60aa-206a-4203-af38-028c0cd71ca3

**Description:** Accounting framework for presale deposits (earmarked liability account, never used for operations), accrued refund liability (estimated 15% of deposits by Month 8 = 2027-06-08 trigger review), and post-gate warranty/seal-reversion reserve (if 3-year warranty or seal-reversion service is offered post-gate). Defines reserve calculations, journal entries, and quarterly reconciliation. Audience: financial officer, founder, external accountant.

**Responsible Role Type:** Financial Officer

**Primary Template:** Accounting Policy & Reserve Calculation Template

**Secondary Template:** Balance Sheet Liability Management

**Steps:**

- Establish presale deposit liability account: EUR X creditors' liability (not revenue) on balance sheet.
- Track refund requests weekly; accrue estimated refund liability = refund-request rate × total outstanding deposits.
- Define accrual threshold: if cumulative refunds exceed 15% of deposits by Month 8 (2027-06-08), investigate root cause and adjust accrual.
- Document journal entries: presale deposit received = debit cash, credit presale liability; refund issued = debit presale liability, credit cash; delivered unit = debit cash (invoice), credit revenue.
- Monthly reconciliation: presale deposits outstanding, refunds issued, net deposit liability; ensure total refunds ≤ deposit account balance.
- Post-gate (if EUR 350k released): define warranty reserve if product warranty is offered; accrue reserve based on historical defect/seal-failure rates (to be established in Year-2).
- Quarterly review: financial officer, founder, external accountant audit presale liability accounting and reserve levels.
- Use accrual-based accounting for cash-flow gate measurement: include refund accruals in Month 12.5 (2027-10-23) calculation.

**Approval Authorities:** Financial Officer, External Accountant

### 20. High-Level Budget & Funding Framework

**ID:** 0cef8dd7-f621-4f07-a368-d59fec4d2c9f

**Description:** EUR 750k two-tranche structure: EUR 400k Year-1 (Months 0-12 = 2026-10-08 to 2027-10-08, user constraint), EUR 350k follow-on conditional on positive cash flow (gate release Month 12.5 = 2027-10-23). Includes intended allocation of EUR 350k (inventory, marketing, R&D, buffer stock, SKU variants) to be clarified pre-gate. Identifies any post-gate funding needs for Year-2 growth. Audience: founder, external advisor, potential stakeholders.

**Responsible Role Type:** Financial Officer & Founder

**Primary Template:** Startup Funding & Use-of-Funds Summary

**Secondary Template:** Capital Allocation Plan

**Steps:**

- Specify total budget: EUR 750k (EUR 400k Year-1, EUR 350k follow-on, user constraint).
- Document Year-1 allocation: design EUR 70k, rig EUR 40k, lab EUR 15k, tooling EUR 20k, production EUR 160k (incl. batch 1 and first batch 2 units), marketing EUR 75k, reserve EUR 20k.
- Identify EUR 350k follow-on allocation framework (preliminary): inventory/buffer stock (EUR 50-100k estimate), marketing scale-up (EUR 80k estimate), R&D/SKU variants (EUR 50k estimate), operational buffer (EUR 80k estimate), remaining for growth capital (EUR 40-70k estimate).
- Flag open decision: exact EUR 350k allocation to be confirmed by Month 9 (2027-07-08) in light of gate-measurement results.
- Identify any Year-2 capital needs beyond EUR 350k (e.g., larger buffer stock, additional production lines) and timeline.
- Specify funding constraints: no debt, no outside investment (founder self-funded, personal capital at risk).
- Publish framework by Month 0.5 (2026-10-23) for stakeholder review.

**Approval Authorities:** Founder, External Advisor

### 21. Presale Order Processing & Fulfillment SOP

**ID:** 94f5b99a-8606-46bb-8869-4317291f2863

**Description:** Standard operating procedure for presale order intake (landing page form, payment processing), deposit receipt and accounting, order confirmation and delivery tracking, customer support escalation, refund authorization. Specifies: 2-3 week ship SLA from confirmation, build-to-order process, tracking updates, delivery confirmation. Audience: customer support, fulfillment coordinator, financial officer.

**Responsible Role Type:** Customer Support & Fulfillment Coordinator

**Primary Template:** E-Commerce Order Processing SOP

**Secondary Template:** Fulfillment & Logistics Procedure

**Steps:**

- Document order intake: landing page form, customer name/device model/shipping address/email, payment method (credit card, bank transfer), deposit amount (EUR 149 or negotiated).
- Confirm order: issue order number, estimated ship date (2-3 weeks), estimated delivery window (4-5 weeks from ship date).
- Receipt to accounting: deposit received = credit presale liability, bank confirm transfer within 1 business day.
- Production queue: order batches assigned to Tallinn fabricator production schedule; assembly, QC, and packing.
- Ship: UPS/DHL label generated, tracking number sent to customer, package tendered to carrier.
- Delivery: tracking updates sent to customer; estimated delivery based on carrier estimate.
- Delivery confirmation: customer email upon carrier delivery; follow-up if no confirmation within expected window.
- Customer support: 48-hour response target for fit, quality, delivery questions; escalation to project manager for refunds or exceptions.
- Refund authorization: customer initiates within 30 days, support verifies issue, project manager approves refund, finance processes within 10 business days.
- Monthly dashboard: orders placed, orders shipped, delivery rate %, refund requests, average shipping cost, customer satisfaction score (if tracked).
- Document contingency: if Tallinn supplier delay >5 days, notify customer immediately with revised ship date.

**Approval Authorities:** Fulfillment Coordinator, Project Manager

### 22. Initial Baseline Assessment: Faraday Enclosure Market Demand & Regulatory Landscape

**ID:** 084ee3b9-d403-4d4d-b7e4-88381a8a90d9

**Description:** Baseline assessment of core problem: demand for consumer-grade Faraday enclosures is niche and unvalidated; EU regulatory applicability (EMC Directive, General Product Safety Directive, CE marking) is unverified; claim-substantiation exposure under consumer law is high. Assessment documents current market size (estimate: thousands of units/year across all vendors, primarily US-based), competitive landscape (Mission Darkness, Silent Pocket precedents), and regulatory risk (if EMC Directive applies, CE marking may be required, adding EUR 10-30k and 8-12 weeks cost/schedule). Deliverables: market-size estimate, competitor benchmarks, regulatory clarification by Month 1 (2026-11-08). Audience: founder, external advisor.

**Responsible Role Type:** Product Manager & Legal Counsel

**Primary Template:** Market Assessment & Regulatory Landscape Report

**Secondary Template:** Competitive Analysis Template

**Steps:**

- Research global Faraday enclosure market: identify 5-10 competitors (US, EU, Asia), pricing (USD/EUR 80-300 range estimate), volumes (not public, inferred from reviews and sales signals), and target segments.
- Benchmark competitors: Mission Darkness (laser-cut metal, published test data, forensics positioning), Silent Pocket (fabric pouches, privacy/travel positioning), others.
- Assess EU regulatory applicability: contact 2-3 EU notified bodies or EMC consultants to clarify whether enclosures fall under EMC Directive, General Product Safety Directive, or are exempt; confirm CE marking requirement; identify applicable harmonized standards.
- Identify gaps in competitor regulatory documentation (most have no published compliance strategy; opportunity for Carrington Event Prep differentiation via transparency).
- Estimate Year-1 addressable market in EU preppers + infrastructure + privacy segments (estimate: 2,000-5,000 units/year across all segments, based on search volume and forum activity).
- Clarify consumer-protection liability landscape: interview 2-3 legal counsels on warranty and claim-substantiation exposure if Faraday protection claims are exceeded in a real event.
- Publish assessment by Month 1 (2026-11-08); share with founder and external advisor to inform presale strategy and compliance posture.

**Approval Authorities:** Product Manager, Legal Counsel

### 23. Post-Gate Use-of-Funds Roadmap & Year-2 Business Plan

**ID:** de943fc7-54cd-4698-b4d4-e0f6eec92885

**Description:** Preliminary roadmap for EUR 350k allocation if cash-flow gate passes (Month 12.5 = 2027-10-23 decision): inventory and buffer stock in EU warehouse (EUR 50-100k estimate), marketing scale-up and brand building (EUR 80k estimate), R&D for phone-only or smaller-SKU variant (EUR 50k estimate), operational headcount and systems (EUR 80k estimate), contingency (EUR 40-70k). Identifies Year-2 revenue target (3,000 units/year, EUR 447k gross revenue, EUR 201k operating surplus before opex), break-even economics (EUR 20k/quarter opex → 1,333 units/quarter for break-even). Clarifies decision points for EUR 350k release by Month 9 (2027-07-08). Audience: founder, external advisor.

**Responsible Role Type:** Founder & Financial Officer

**Primary Template:** Year-2 Business Plan & Capital Allocation

**Secondary Template:** Growth Strategy Roadmap

**Steps:**

- If gate passes: allocate EUR 350k as (preliminary): buffer-stock warehouse/inventory EUR 50-100k, marketing/brand EUR 80k, R&D/SKU variants EUR 50k, headcount/operations EUR 80k, contingency EUR 40-70k.
- Define Year-2 revenue target: 3,000 units/year (750/quarter), EUR 447k gross revenue (estimate).
- Calculate Year-2 operating economics: contribution margin 3,000 × EUR 67 = EUR 201k; opex EUR 80k (higher than Year-1 due to part-time ops, marketing, support); annual operating surplus EUR 121k (estimate).
- Identify Year-2 priorities: (1) buffer-stock logistics to reduce delivery lead times from 4-5 weeks to 2-3 weeks, (2) marketing to scale presale volume beyond break-even, (3) phone-only SKU to reduce fit complaints and expand addressable market, (4) customer retention (re-verification service, seal warranty).
- Set Year-2 revenue milestone: EUR 100k achieved by Month 18 (2028-04-08) onward; EUR 250k by Month 24 (2028-10-08).
- Document decision trigger: by Month 9 (2027-07-08), founder + external advisor confirm gate tracking and decide whether to allocate EUR 350k or preserve optionality pending final gate measurement.
- Publish preliminary roadmap by Month 3 (2027-01-08) for stakeholder alignment.

**Approval Authorities:** Founder, External Advisor

### 24. Presale Segment A/B Testing & Demand Validation Experiment Plan

**ID:** 91ec900b-6160-4f83-b9b5-42d12de74248

**Description:** Planned experiment for Months 0-3 (2026-10-08 to 2027-01-08) testing three buyer-segment narratives (Carrington preparedness, forensics/compliance, privacy/travel security) via separate landing pages. Specifies: sample size, conversion metrics (inquiry-to-deposit ratio), average order value, segment-mix outcome, and decision rule for pivot. Audience: presale manager, project manager, external advisor.

**Responsible Role Type:** Presale Manager

**Primary Template:** A/B Testing & Experiment Design Template

**Secondary Template:** Customer Research Plan

**Steps:**

- Design three landing pages, each targeting one buyer segment with distinct value proposition (Carrington + continuity, forensics/compliance/evidence, privacy/data-protection + travel security).
- Set up tracking: unique URL for each segment, pixel-based conversion tracking, email capture.
- Run campaigns in parallel for 8 weeks (Months 1-2 = 2026-11-08 to 2026-12-08); measure weekly.
- Key metrics: unique visitors per segment, inquiry-to-deposit conversion rate, average deposit amount (AOV), customer feedback/objections.
- Decision threshold (Month 3 = 2027-01-08): identify segment with highest deposit velocity and AOV ≥ EUR 120 (target). Allocate 60% of marketing budget to winning segment.
- Document findings and pivot decision in writing; adjust presale messaging for Months 3-8 (2027-01-08 to 2027-06-08) based on winner.
- If no clear winner (AOV <EUR 120 across all segments), trigger pricing pivot (reduce list price 15-20%) or extend presale test.

**Approval Authorities:** Presale Manager, Project Manager

### 25. Infrastructure Buyer Fast-Track Pilot Agreement Template & Pilot Negotiation Checklist

**ID:** aca76a23-8f9f-4293-894e-b48ac99a701a

**Description:** Template for fast-track infrastructure pilot agreements (10-20 units, cost + 20% = EUR 84/unit, delivery Month 5 = 2027-03-08, feedback by Month 6 = 2027-04-08, reference rights). Includes negotiation checklist (pilot scope, success criteria, reference-use rights, feedback timeline, potential procurement follow-on) and list of 5-10 target pilot buyers (emergency-response agencies, utility operators, security consultants). Audience: presale manager, founder.

**Responsible Role Type:** Presale Manager

**Primary Template:** Pilot Program Agreement Template

**Secondary Template:** Customer Reference Agreement

**Steps:**

- Define pilot scope: 10-20 enclosures, cost +20% markup (EUR 84/unit), delivery by Month 5 (2027-03-08), pilot evaluation 1 month, feedback report, reference rights for marketing.
- Specify success criteria: seal integrity after 100 open/close cycles, attenuation consistent with published lab report, fit for customer device models.
- Draft pilot agreement: pilot units at cost+20%, trial period 1 month, feedback required by Month 6 (2027-04-08), right to quote customer as reference in sales materials, option for procurement follow-on.
- Create negotiation checklist: identify 1-2 target infrastructure buyers (emergency-management office, utility co, security consultancy) by Month 2 (2026-12-08); contact by Month 2.5 (2026-12-23); negotiate terms by Month 3 (2027-01-08); sign by Month 3 (2027-01-08); ship by Month 5 (2027-03-08).
- Define follow-on path: if pilot feedback is positive, buyer commits to procurement (estimated 50-200 units in Year-1 post-pilot) or provides testimony for other infrastructure buyers.
- Budget pilot cost: 15 units × EUR 84 = EUR 1,260 (absorbed in production line EUR 160k or presale marketing EUR 75k allocation).

**Approval Authorities:** Presale Manager, Founder

### 26. Secondary Fabricator Trial Batch Evaluation & Contingency Sourcing Plan

**ID:** 29981d5d-3b74-4966-94f9-9d4bb547dc6d

**Description:** Detailed plan for secondary fabricator trial (50-100 units, laser-cut and CNC-bend accuracy testing, dimensional tolerance verification ±0.1 mm, finish quality comparison vs. primary fabricator). Includes evaluation criteria, pass/fail decision, and contingency-activation protocol (if primary supplier signals capacity loss or price increase >10%, transition to secondary within 5 business days). Audience: supply-chain coordinator, project manager.

**Responsible Role Type:** Supply Chain Coordinator

**Primary Template:** Supplier Qualification & Testing Protocol

**Secondary Template:** Contingency Sourcing Plan

**Steps:**

- Identify secondary fabricator (Tallinn/Estonia area, ISO 9001, laser and CNC capability) by Month 1 (2026-11-08).
- Issue trial batch quote: 50-100 units, laser accuracy ±0.1 mm (seams and slots), CNC bend tolerance ±0.5 degree, burr-free finish, visual QC report.
- Receive trial batch by Month 2 (2026-12-08); unpack and inspect.
- Evaluation criteria: dimensional accuracy (measure 10 random units, compare to spec), seam quality (visual, burr-free), bend repeatability (measure bend angle variance across 10 units), overall finish consistency vs. primary fabricator samples.
- Pass/fail decision: if secondary meets ±0.1 mm tolerance and visual quality matches primary, approve as backup supplier; document lead time and pricing.
- Contingency protocol: if primary supplier signals price increase >10% or capacity loss, activate secondary within 5 business days (issue purchase order, arrange shipment); if secondary trial failed, identify tertiary supplier by Month 3 (2027-01-08).
- Document sourcing decision and contingency trigger in supply-chain risk register; communicate to project manager.

**Approval Authorities:** Supply Chain Coordinator, Founder

### 27. Accredited Lab Pre-Engagement Consultation Summary & Lab Selection Decision

**ID:** 3c55c9b1-3947-4229-811b-233d2b58530e

**Description:** Summary of pre-engagement consultations with 2-3 accredited EMC laboratories (conducted Month 0.5 = 2026-10-23). Documents: standard recommendation (IEEE 299.1 or alternative applicability for small enclosures), frequency range (e.g., 100 kHz - 1 GHz), cost (EUR 15k cap confirmed or overrun risk identified), timeline (report delivery Month 5 = 2027-03-08 or later), design-readiness review scope (EUR 2-3k, 2-week turnaround). Concludes with lab selection and statement of work signing date. Audience: RF engineer, project manager, financial officer.

**Responsible Role Type:** RF Engineer

**Primary Template:** Laboratory Selection & RFQ Summary

**Secondary Template:** Supplier Comparison Matrix

**Steps:**

- Contact 2-3 candidate labs (Germany, Sweden, Netherlands, Estonia) by Month 0.5 (2026-10-23) with request for pre-engagement consultation (standard, cost, timeline, design-readiness review).
- Compile consultation notes: lab name, standard(s) recommended (IEEE 299.1 or alternative applicability to small enclosures), frequency range (confirm 100 kHz to 1 GHz coverage), cost quote (EUR X for full testing, EUR Y for re-test if needed), timeline commitment (report delivery date), design-readiness review (cost and turnaround), re-test provision.
- Create comparison matrix: side-by-side evaluation of 2-3 labs on cost, timeline, standard applicability, re-test flexibility, design-review availability.
- Identify preferred lab based on: (1) cost ≤ EUR 15k cap, (2) timeline commitment for Month 5 (2027-03-08) report delivery, (3) design-readiness review availability Month 4 (2027-02-08), (4) re-test provision within original cost cap.
- Document lab selection rationale and obtain preliminary written quote by Month 1 (2026-11-08).
- Sign statement of work with chosen lab by Month 1.5 (2026-11-23) specifying fixed cost, delivery date, re-test terms, penalty for slip.

**Approval Authorities:** RF Engineer, Project Manager

### 28. In-House Shielding Test Rig Build Plan & Validation Protocol

**ID:** 9c39e8bb-ebaa-4dbc-819d-99fbb3d8a955

**Description:** Technical specification and build plan for in-house RF measurement rig (signal generator, spectrum analyzer, shielded measurement chamber or Faraday cage). Includes target attenuation measurements (50 MHz, 100 MHz, 500 MHz, 1 GHz), seam-cycle repeatability testing (two independent prototypes, minimum three measurements per frequency), and acceptance criteria for design readiness (attenuation variance <5%, no catastrophic failures). Timeline: rig setup Months 0-1 (2026-10-08 to 2026-11-08), prototype 1 build and testing Month 2-3 (2026-12-08 to 2027-01-08), validation report Month 3 (2027-01-08). Audience: RF engineer, project manager.

**Responsible Role Type:** RF Engineer

**Primary Template:** Test Plan & Engineering Specification

**Secondary Template:** Prototype Validation Report Template

**Steps:**

- Specify test rig hardware: signal generator (100 kHz to 1 GHz frequency range), spectrum analyzer (resolution <1 dB), shielded measurement chamber or Faraday cage enclosure.
- Define measurement protocol: source impedance, field-strength levels, attenuation calculation (incident vs. transmitted field ratio), repeatability criteria (multiple measurements per frequency and seam cycle).
- Build timeline: rig assembly and calibration Months 0-1 (2026-10-08 to 2026-11-08); prototype 1 fabrication and fit-up Month 2 (2026-12-08); measurement and seam-cycle testing Month 3 (2027-01-08).
- Measurement plan: test attenuation at 50 MHz, 100 MHz, 500 MHz, 1 GHz (and intermediate frequencies if time permits). Run two independent open/close cycles per frequency (seam compression and release). Document attenuation value and variance.
- Acceptance criteria: attenuation meets claimed band (e.g., ≥ 60 dB from 100 MHz to 1 GHz, ≥ 40 dB at 50 MHz); variance across seam cycles <5%; no field leakage at seams >-20 dB (relative to claimed band).
- Document results in validation report (Month 3 = 2027-01-08); if results meet criteria, proceed to lab design-readiness review; if results fall short, identify design weakness (seam, gasket, aperture) and iterate.

**Approval Authorities:** RF Engineer, Project Manager

### 29. Marketing Message Architecture & Brand Positioning Framework

**ID:** 6529c396-c679-4662-a8c7-863745b098ce

**Description:** Brand positioning and messaging framework across three buyer segments. Defines core value proposition (verified RF shielding protection via published lab data), brand personality (transparent, evidence-based, not hype-driven), and segment-specific narratives (Carrington preparedness for preppers; regulatory compliance and evidence integrity for forensics/security; privacy and data protection for privacy advocates). Includes claim-wording guidelines (limit to measured attenuation, no exaggeration), and consistency rules (all channels align on core value). Audience: founder, presale manager, marketer.

**Responsible Role Type:** Presale Manager

**Primary Template:** Brand Positioning & Messaging Platform

**Secondary Template:** Marketing Communication Guidelines

**Steps:**

- Define core value proposition: 'Independently verified RF shielding protection via accredited lab testing, published for transparency.'
- Define brand personality: evidence-driven, honest about limitations (stored devices only), credible, not sensationalist.
- Define three segment narratives: (1) Prepper: Carrington solar-storm risk mitigation, continuity of spare-device access. (2) Forensics/Security: evidence integrity, sealed chain-of-custody, regulatory compliance. (3) Privacy/Travel: data protection, RF isolation for sensitive devices during travel.
- Establish claim-wording rules: (a) all claims reference measured lab attenuation and tested frequency range, (b) explicit scope limitation ('stored spare devices only'), (c) no claims about protection during actual electromagnetic events.
- Create messaging matrix: core message (verified shielding), segment-specific angle (preparedness/compliance/privacy), proof point (lab report), call-to-action (presale deposit or pilot agreement).
- Establish consistency rules: presale landing page, social media, forum posts, product documentation all align on core message and scope.
- Review and approve messaging by Month 1 (2026-11-08) with legal counsel to ensure compliance; freeze messaging changes after Month 1.5 (2026-11-23) to ensure consistency during presale phase.

**Approval Authorities:** Presale Manager, Legal Counsel

## Documents to Find

### 1. EU EMC Directive 2014/30/EU & Related Harmonized Standards

**ID:** 72efc6d4-1fd1-4513-8e61-f0c2cee9b087

**Description:** Official EU regulatory text on electromagnetic compatibility for electrical/electronic equipment. Specifies scope, CE marking requirements, notified-body assessment, and conformity procedures. Relevant to determine whether Faraday enclosures are in-scope and whether CE marking is mandatory. Source material for legal opinion and compliance strategy.

**Recency Requirement:** Current legislation; version effective 2016 onward.

**Responsible Role Type:** Legal Counsel

**Access Difficulty:** Easy. EU-Lex is public; full texts available in PDF and HTML formats at no cost.

**Steps:**

- Access EUR-Lex database (https://eur-lex.europa.eu/) and search for 'Directive 2014/30/EU'.
- Download full text and preamble; search for 'enclosure', 'shielding', 'RF', 'attenuation' scope language.
- Cross-reference with EN harmonized standards (EN IEC 61000-6-2, EN IEC 61000-6-4) listed in official EU NANDO (New Approach Notified and Designated Organisations) database.
- Consult with notified body or EMC consultancy on whether small passive enclosures are in-scope (likely exempt if non-electronic, but verify).
- Document findings in legal opinion by Month 1 (2026-11-08).

### 2. EU General Product Safety Directive 2001/95/EC & Consumer Protection Rules

**ID:** 7e3fcaac-0222-431d-86b3-ce9bf4f5e50f

**Description:** Official EU legislation governing consumer product safety, warning labels, liability, and conformity. Specifies scope (any product intended for consumer use), claim substantiation, and warranty/liability exposure. Applies even if EMC Directive is out-of-scope. Relevant for claim wording, fit disclaimers, and refund policy compliance.

**Recency Requirement:** Current legislation; supplemented by Directive 2011/83/EU on consumer rights (distance contracts, cancellation).

**Responsible Role Type:** Legal Counsel

**Access Difficulty:** Easy. EU-Lex is public; all texts available in multiple EU languages.

**Steps:**

- Access EUR-Lex and search for 'Directive 2001/95/EC' (General Product Safety Directive).
- Cross-reference Directive 2011/83/EU on consumer rights (cancellation, distance selling).
- Download full texts; search for 'liability', 'information', 'safety', 'warnings', 'commercial practices'.
- Identify country-specific implementations (e.g., Estonia Consumer Protection Act) if Tallinn-based operations create local jurisdiction.
- Document scope-statement and disclaimer language needed for presale terms and product documentation.
- Include findings in legal opinion by Month 1 (2026-11-08).

### 3. IEEE 299.1 Standard for Shielding Enclosure Testing (or Equivalent RF Shielding Standard)

**ID:** e29c0813-a089-4055-b2e7-711cadb4bd90

**Description:** International standard specifying test methodology for RF shielding effectiveness of small enclosures. Covers frequency range (typically 20 MHz to 40 GHz), measurement equipment, sample preparation, and pass/fail criteria. Essential for accredited lab selection and test planning. Source material for RF engineer and lab pre-engagement consultation.

**Recency Requirement:** Latest edition (2018 or 2021, depending on availability); older versions acceptable if confirmed by accredited lab as applicable.

**Responsible Role Type:** RF Engineer

**Access Difficulty:** Medium. IEEE standards require paid subscription (approximately USD 100-200 per standard) or institutional library access. Accredited labs often have copies available for consultation.

**Steps:**

- Search IEEE Standards Online (https://standards.ieee.org/) for 'IEEE 299.1' and related enclosure standards.
- If direct access unavailable, request standard quote from IEEE; alternatively, check with accredited EMC labs (DEKRA, TÜV, SGS) which typically have library access.
- Cross-check with IEC or EN equivalents (IEC 61000-4-3, EN standards for shielding).
- Obtain copy of standard (or sufficient excerpt) by Month 0.5 (2026-10-23) to share with lab pre-engagement consultation.
- If IEEE 299.1 is inapplicable, lab will recommend alternative (e.g., MIL-STD-285, IEC 61000-4-3) in pre-engagement consultation by Month 0.5 (2026-10-23).

### 4. Accredited EMC Laboratory Lists & Notified Bodies Database (NANDO)

**ID:** 8566ada0-faf4-4c7c-9f07-b28fc5386a12

**Description:** Official list of EU notified bodies and accredited testing laboratories certified to perform EMC/RF shielding testing. Specifies lab name, location, scope of accreditation (standards, frequency range), and contact information. Source material for lab selection and pre-engagement consultation.

**Recency Requirement:** Current; updated quarterly. Last-updated date should be within 6 months.

**Responsible Role Type:** RF Engineer & Project Manager

**Access Difficulty:** Easy. NANDO and ILAC databases are public and searchable online at no cost. Lab contact information typically available on their websites.

**Steps:**

- Access EU NANDO database (https://nando.ec.europa.eu/) for notified bodies accredited for EMC testing.
- Filter by country (Germany, Sweden, Netherlands, Estonia) and scope (RF shielding, enclosures, frequency range 100 kHz-1 GHz).
- Cross-check with ILAC (International Laboratory Accreditation Cooperation) database and ISO 17011 for independent lab accreditation.
- Compile list of 5-10 candidate labs with scope matching small Faraday enclosure testing.
- Contact each lab by Month 0.5 (2026-10-23) for pre-engagement consultation (standard, cost, timeline, design-readiness review).
- Document findings and lab selection by Month 1.5 (2026-11-23).

### 5. Current EU Market Data on RF/EMI Shielding Products & Preparedness Segment

**ID:** 7926302c-fec7-4644-acf0-0881de7310ba

**Description:** Statistical data or market reports on consumer demand for Faraday enclosures, RF-isolation products, and disaster-preparedness gear in EU markets. Includes forum activity (prepper communities), product reviews (Amazon EU, preparedness retailers), and search trends (Google Trends, keyword volume). Provides baseline for market-size estimate and segment demand validation.

**Recency Requirement:** Most recent available (2024-2026); trend data 2020 onward acceptable for pattern identification.

**Responsible Role Type:** Presale Manager & Product Manager

**Access Difficulty:** Medium. Google Trends and retailer websites are public and free. Forums require community participation but are typically open. Competitor sales data may not be publicly available; will require estimation from reviews and signals.

**Steps:**

- Search Google Trends for 'Faraday enclosure', 'RF shielding', 'solar storm preparedness' in EU countries (Germany, UK, Scandinavia); identify seasonality and volume trends.
- Review Amazon EU, specialist prepper retailers (e.g., German/UK/Scandinavian preparedness sites), and digital-forensics supplier catalogs for comparable product listings and customer reviews.
- Monitor prepper forums (Reddit r/preppers, German/Scandinavian preparedness communities, privacy-focused forums) for demand signals and pricing tolerance.
- Request sales data from existing Faraday-enclosure vendors (Mission Darkness, Silent Pocket) if willing; otherwise, use public reviews and Q&A signals.
- Compile baseline: estimated EU market size (2,000-5,000 units/year across all vendors, estimate), average selling price (EUR 100-250, estimate), segment distribution (prepper vs. forensics vs. privacy).
- Use data to inform presale target (EUR 80-120k deposits = 530-800 units if average presale price is EUR 149 estimate) and segment-mix validation plan.

### 6. Tallinn Precision Sheet-Metal Fabrication Industry Data & ISO 9001 Certified Fabricator Directory

**ID:** e567c624-86f8-4fee-a285-1c2edbd35279

**Description:** Directory or industry data on Tallinn and Estonia-based precision sheet-metal fabricators with ISO 9001/9003 certification, laser-cutting and CNC-bending capability. Includes names, locations, capabilities, lead times, and pricing benchmarks. Source material for fabricator identification and supplier comparison.

**Recency Requirement:** Current (2024-2026); updated annually acceptable.

**Responsible Role Type:** Supply Chain Coordinator

**Access Difficulty:** Medium. Chamber of Commerce databases may require membership or direct contact. Google Maps and company websites are public. ISO certification databases are public; individual company certifications may require request to the company.

**Steps:**

- Contact Estonian Chamber of Commerce & Industry (https://www.koda.ee/) for directory of precision-metal fabricators in Tallinn industrial district.
- Search Google Maps and industry databases (e.g., Kompass, local industry portals) for 'precision metal fabrication', 'laser cutting', 'CNC bending' in Tallinn, Estonia.
- Review ISO 9001 certification databases (EMAS, notified bodies lists) for Tallinn-area metal fabricators.
- Identify companies: request capability brochures, pricing samples (laser-cut and bend accuracy, tolerances, materials), lead times, capacity availability.
- Pre-qualify primary and secondary fabricators by Month 1 (2026-11-08) with trial batch quote.
- Document cost benchmarks: soft tooling (laser setup, material cutting, bending, finishing) typically EUR 500-1,500 per design iteration, unit cost EUR 50-80 per unit for low-volume batch (500-1,000 units estimate).

### 7. Conductive Gasket & EMI Shielding Material Supplier Directories & Pricing Data

**ID:** 34bcc379-d5d3-4a00-8ea4-c60a0d646957

**Description:** List of European suppliers of conductive elastomer gaskets (nickel-copper, silver-plated materials), EMI absorbers, and shielding adhesives. Includes product datasheets, pricing, lead times, and minimum order quantities. Source material for gasket sourcing and buffer-stock budgeting.

**Recency Requirement:** Current product catalogs (2024-2026); pricing valid for current ordering.

**Responsible Role Type:** Supply Chain Coordinator & RF Engineer

**Access Difficulty:** Easy. Supplier websites, datasheets, and pricing are public. Volume quotes require direct contact but are typically provided within 48 hours.

**Steps:**

- Search industry directories: Digi-Key, Heilind, Heilind Electronics, or European equivalents for conductive gasket suppliers.
- Identify suppliers: Parker Chomerics (conductive gaskets), Laird Technologies, Würth Elektronik, and regional distributors in Germany, Sweden, Netherlands.
- Request product datasheets and pricing for enclosure-seam gaskets (nickel-copper, compression 30-40%, durometer 60-70 Shore A estimate).
- Obtain lead-time data: typically 2-6 weeks for standard materials, 6-12 weeks for custom formulations.
- Pre-qualify primary and secondary suppliers by Month 1.5 (2026-11-23); lock pricing for Year-1 volume (500-1,500 meters estimate).
- Budget buffer stock: 30-day supply (EUR 5-10k estimate) held before production release to prevent supply disruption.

### 8. EU Product Liability Insurance Market Data & Underwriter Appetite for Electronics/RF Products

**ID:** b25b8d9b-1717-4096-ba5d-3dcc35a8c08f

**Description:** Data on product-liability insurance availability and pricing for consumer electronics and RF/shielding products in EU market. Includes typical coverage limits, deductibles, premiums, and exclusions. Identifies insurers willing to cover Faraday-enclosure claims and any known industry-specific restrictions.

**Recency Requirement:** Current (2024-2026); insurance terms valid for 12-month policy period.

**Responsible Role Type:** Legal Counsel & Financial Officer

**Access Difficulty:** Medium. Insurance brokers require direct contact and business information (entity structure, revenue projections, product details). Quotes typically provided within 1-2 weeks.

**Steps:**

- Contact 3-5 European insurance brokers specializing in product liability for consumer electronics (e.g., Allianz, AXA, Hiscox, or specialty tech insurers).
- Request preliminary quotes for Faraday-enclosure manufacturer: coverage EUR 250-500k, deductible EUR 5-10k estimate, annual premium EUR 3-8k estimate (based on industry benchmarks).
- Clarify coverage scope: whether RF shielding claims are insurable and any exclusions (acts of God, actual Carrington events, etc.).
- Request sample policy wording and claims procedures.
- Lock insurance terms by Month 2.5 (2026-12-23).
- Budget EUR 8k within the EUR 75k marketing/operations allocation for insurance premium (Year-1 estimate).

### 9. Faraday Enclosure Competitive Products & Pricing Analysis

**ID:** f2f49540-e06c-406b-8ebd-33f351beb996

**Description:** Comparative data on existing Faraday enclosure and RF-isolation product offerings: Mission Darkness (US-based, laser-cut metal, published test data, pricing USD 100-400 estimate), Silent Pocket (US, fabric pouches, EUR 60-200 estimate), and regional competitors. Includes product specs, claimed attenuation, customer reviews, and go-to-market strategy. Source material for competitive positioning and pricing benchmark.

**Recency Requirement:** Current pricing and product specs (2024-2026); customer reviews 2023-2026 acceptable.

**Responsible Role Type:** Presale Manager & Product Manager

**Access Difficulty:** Easy. Competitor websites and product pages are public; reviews aggregated on Amazon and retailer sites.

**Steps:**

- Visit Mission Darkness (https://www.mosequipment.com/) and Silent Pocket (https://silent-pocket.com/) websites; review product specs, published test data, pricing, and customer Q&A/reviews.
- Search Amazon EU for 'Faraday enclosure', 'RF shielding case', 'Faraday bag' and review product listings, prices, reviews, and seller comments.
- Review digital-forensics and preparedness retailer sites for Faraday product offerings and pricing.
- Compile competitive matrix: product type (rigid/fabric), claimed attenuation, price, target segment (preppers/forensics/privacy), testing/documentation approach.
- Identify gaps: most competitors lack published accredited-lab test reports; Carrington Event Prep can differentiate via transparency and third-party validation.
- Use pricing data to inform EUR 149 presale price (estimate): positioned between Mission Darkness (premium) and Silent Pocket (budget), target is middle market with proven test data.
- Document findings in competitive analysis by Month 1 (2026-11-08).

### 10. Tallinn & Estonia Cost-of-Living & Wage Data for Operations Budgeting

**ID:** c150dbbd-605f-4614-b3ad-b87e821e8221

**Description:** Current wage data for part-time operations and customer-support roles in Tallinn/Estonia. Includes typical hourly rates for operations coordinators, customer-service staff, and logistics coordinators. Source material for presale-support and fulfillment staffing budget.

**Recency Requirement:** Current (2024-2026); wage data for 2026 Q4 acceptable.

**Responsible Role Type:** Financial Officer

**Access Difficulty:** Medium. Estonia wage databases may require Estonian-language proficiency or translation. Recruitment agencies typically provide free salary surveys upon request.

**Steps:**

- Consult Estonian salary databases (Palkauudis, Statistics Estonia - Statistikaamet) for average wages by role and region.
- Request salary surveys from Estonian recruitment agencies (CVPartners, employers.ee) or HR consultancies.
- Cross-check with global cost-of-living indices (Numbeo, Glassdoor) for Tallinn wage benchmarks.
- Compile data: part-time customer support (EUR 8-12/hour estimate), operations coordinator (EUR 12-16/hour estimate), fulfillment (EUR 10-14/hour estimate).
- Budget part-time operations role (10-15 hrs/week from Month 6 = 2027-04-08 = EUR 200-300/week estimate = EUR 5-8k Year-1 partial).
- Include in marketing/operations EUR 75k allocation.

### 11. EU Cross-Border Logistics Cost Data (Tallinn to EU Destinations)

**ID:** c4018102-6306-4377-8d56-3e1bd2e5a4dc

**Description:** Freight cost benchmarks for shipping small packages (2-4 kg enclosures) from Tallinn to major EU destinations (Germany, UK, Scandinavia, Southern Europe). Includes parcel carriers (DHL, UPS, Deutsche Post), delivery times, and volume-discount rates. Source material for presale delivery SLA and freight-cost budgeting.

**Recency Requirement:** Current pricing (2024-2026, updated regularly by carriers).

**Responsible Role Type:** Supply Chain Coordinator

**Access Difficulty:** Easy. Carrier websites offer self-service quote tools; direct contact yields volume pricing within 24 hours.

**Steps:**

- Request shipping quotes from DHL, UPS, FedEx, and local Estonian carriers (Omniva, Smartpost) for 2 kg and 4 kg packages from Tallinn to sample destinations (Berlin, Copenhagen, London, Barcelona, Milan).
- Obtain pricing for standard parcel (2-3 week delivery) and express (4-5 day) options.
- Compile volume-discount rates if shipping 100+ packages/month.
- Typical freight estimate: EUR 8-15 per unit for EU-wide delivery (depending on weight and destination).
- Budget outbound freight in production line: EUR 12/unit (midpoint) × 1,500 units = EUR 18k Year-1.
- Use data to inform fulfillment logistics plan (direct shipment vs. buffer-stock warehouse) by Month 5 (2027-03-08).

### 12. Presale Platform & E-Commerce SaaS Pricing & Capabilities (Shopify, WooCommerce, Typeform, etc.)

**ID:** 0b85a06a-94ee-49ee-aa59-b560feca55ab

**Description:** Pricing and feature data for presale landing-page platforms, payment processors, and order-management systems. Includes Shopify, WooCommerce, Typeform, MailChimp, HubSpot, and alternatives. Source material for presale infrastructure budgeting and platform selection.

**Recency Requirement:** Current (2024-2026); pricing updated monthly by SaaS providers.

**Responsible Role Type:** Presale Manager & Financial Officer

**Access Difficulty:** Easy. All vendor websites offer free trials and public pricing; demos available on request.

**Steps:**

- Visit Shopify, WooCommerce, Typeform, MailChimp, and HubSpot websites; review pricing tiers, features (deposit collection, email tracking, A/B testing, analytics).
- Compile feature matrix: which platform supports multi-segment presale campaigns, deposit tracking by segment, automatic refund processing, customer support ticketing.
- Estimate total Year-1 cost: landing-page hosting (Shopify EUR 30-100/month), email marketing (MailChimp EUR 20-50/month), form builder (Typeform EUR 25-70/month), CRM (HubSpot free or EUR 50+/month), total EUR 3-6k/year estimate.
- Budget EUR 5k within marketing EUR 75k allocation for presale platform setup and annual SaaS subscriptions.
- Select platform by Month 1 (2026-11-08) to launch three separate presale campaigns by Month 1 (2026-11-08).

### 13. Presale Community Forums, Prepper Networks & Infrastructure Buyer Contacts Database

**ID:** 885a815e-4a5b-433f-a173-2661b79145ea

**Description:** Compiled list and outreach contacts for prepper networks (Reddit r/preppers, German preparedness communities, UK survival forums), digital-forensics/privacy communities (r/privacy, data-protection forums), and critical-infrastructure buyer groups (emergency management agencies, utility operators, security consultants). Source material for presale customer targeting and pilot-buyer outreach.

**Recency Requirement:** Current (2024-2026); forum activity and contact lists updated quarterly.

**Responsible Role Type:** Presale Manager

**Access Difficulty:** Medium. Public forums are open; private groups may require membership. Influencer and official contact information requires research and direct outreach.

**Steps:**

- Identify major prepper communities: Reddit r/preppers (500k+ members), Survivalist Forum, UK Prepping forums, German 'Vorsorge' and 'Krisenvorsorge' communities (e.g., krisenvorsorge.org, similar German-language sites).
- Identify digital-forensics and privacy communities: r/privacy (500k+ members), Digital Forensics & Incident Response (DFIR) communities, corporate IT security forums, SANS community.
- Identify critical-infrastructure buyer networks: contact lists for emergency management agencies (FEMA equivalent in EU countries), utility operators, telecommunications authorities.
- Compile database: community name, contact person (if community-managed), typical member profile, engagement level (active discussions on relevant topics), posting guidelines (self-promotion rules).
- Identify 3-5 key influencers or moderators per community for pilot outreach by Month 1 (2026-11-08).
- Use list to launch presale campaigns (Prepper, Infrastructure, Privacy segments) by Month 1 (2026-11-08).

### 14. Current Estonian Tax & VAT Regulations for E-Commerce & Distance Sales

**ID:** 7b21b85e-b744-4708-8dcf-b63b22933610

**Description:** Official Estonian tax authority (Maksu- ja Tolliamet) guidance on VAT treatment for distance sales of goods to EU buyers, VAT registration thresholds, OSS (One-Stop Shop) reporting requirements, and invoicing rules. Specifies whether Faraday enclosures are subject to standard or reduced VAT, and how presale deposits are treated for tax purposes.

**Recency Requirement:** Current (2024-2026); updated annually by Estonian tax authority.

**Responsible Role Type:** Financial Officer & Legal Counsel

**Access Difficulty:** Medium. Estonian tax authority website is in Estonian; English translations available but may require professional tax-advisor consultation.

**Steps:**

- Access Maksu- ja Tolliamet website (https://www.emta.ee/) and search for 'VAT', 'e-commerce', 'distance sales', 'OSS'.
- Download guidance documents on VAT treatment for goods sold to EU customers from outside the goods place of supply.
- Contact Estonian tax advisor or accountant for clarification on: (1) VAT rate applicable to Faraday enclosures (likely standard 20%), (2) VAT registration threshold (EUR 0 if selling internationally), (3) OSS scheme requirements and reporting, (4) presale deposits (tax timing).
- Compile findings: VAT registration by Month 1 (2026-11-08) if not already registered; implement VAT tracking in accounting system; allocate EUR 2-3k for tax compliance services Year-1.
- Use findings to set presale pricing: confirm whether EUR 149 list price is gross (incl. VAT) or net.

### 15. RF Shielding Performance Benchmarks: Competitor Product Test Reports & Specifications

**ID:** 39ddbdc4-8ad9-4daa-ab64-799d3419a665

**Description:** Published or available test reports and specifications for competitor Faraday enclosures and RF-isolation products (Mission Darkness published test data, Silent Pocket claims, if available). Documents typical attenuation values by frequency band, test methodology, and claimed ranges. Source material for competitive benchmarking and design-target setting.

**Recency Requirement:** Current (2024-2026); competitor specs and test reports published within 2 years.

**Responsible Role Type:** RF Engineer & Product Manager

**Access Difficulty:** Medium. Published competitor test reports are not always freely available; may require direct request to manufacturer or access to industry databases. DIY reviews are public but may be anecdotal.

**Steps:**

- Visit Mission Darkness website (https://www.mosequipment.com/) and download any published frequency-sweep reports, test-methodology documentation, or attenuation spec sheets for competitor products (Small Faraday Boxes, Bags, Cases).
- Search for Silent Pocket (https://silent-pocket.com/) published test reports or claim substantiation documentation; extract attenuation claims if published.
- Search academic/independent review sites for any third-party RF-shielding test results on consumer Faraday products (e.g., electronics forums, DIY RF lab reports).
- Compile benchmarks: typical attenuation at 50 MHz, 100 MHz, 500 MHz, 1 GHz for comparable small metal enclosures; note test method (IEEE 299.1 or alternative).
- Use benchmark data to set Carrington Event Prep design targets: aim to match or exceed competitor attenuation, with published proof via accredited lab report.
- Document findings in RF design specification and competitive analysis by Month 1 (2026-11-08).

### 16. European Critical Infrastructure & Emergency Management Agency Contact Lists & Procurement Processes

**ID:** 3791e0bd-fe64-423b-8cf6-0b276f1ec8d3

**Description:** Directory of EU emergency-management agencies, utility operators, telecommunications authorities, and critical-infrastructure security groups. Includes typical procurement timelines (6-12 months for government/infrastructure contracts), RFQ/RFP processes, and technical-specification requirements. Source material for infrastructure-buyer outreach and pilot-agreement negotiation.

**Recency Requirement:** Current (2024-2026); contact information updated quarterly.

**Responsible Role Type:** Presale Manager

**Access Difficulty:** Medium. Government and corporate directories are public but fragmented; may require research across multiple sources (EU Commission, national government websites, industry directories).

**Steps:**

- Research EU emergency-management framework: European Commission Civil Protection, national emergency-management agencies (e.g., BBK in Germany, FEMA equivalent in other countries).
- Identify critical-infrastructure operators: utility companies (power, telecom, water), transportation authorities, financial institutions, government data centers.
- Compile contact list for 5-10 target infrastructure buyers: agency name, emergency-preparedness or IT-security contact, typical procurement timeline, budget authority.
- Research typical procurement process: are they amenable to direct pilot sales, or do they require formal RFQ/RFP? What is typical sales cycle (6-12 months)? What documentation do they require (certifications, test reports, warranty)?
- Prioritize targets by likelihood to engage in fast-track pilot by Month 3 (2027-01-08) and pilot completion by Month 5 (2027-03-08).
- Use list to launch infrastructure-buyer outreach by Month 1.5 (2026-11-23); target 1-2 pilots by Month 3 (2027-01-08).

### 17. Digital Forensics & Corporate IT Security Community Directories & Standards

**ID:** 850ed33f-b3c0-4a34-ae32-18078ca9fc12

**Description:** Directory of digital-forensics organizations, corporate IT security teams, and privacy-focused corporate buyer groups. Includes conferences (Black Hat, RSA, SANS, etc.), professional associations (DFIR, ISSA), and online communities (DFIR Slack, corporate security forums). Source material for privacy/forensics buyer outreach and understanding procurement requirements.

**Recency Requirement:** Current (2024-2026); community directories updated quarterly.

**Responsible Role Type:** Presale Manager

**Access Difficulty:** Medium. Professional directories and community memberships are public or require free registration. Corporate contact information may require research via LinkedIn or industry databases.

**Steps:**

- Research major digital-forensics and IT-security organizations: DFIR (Digital Forensics and Incident Response) community, SANS Institute, ISSA (Information Systems Security Association), Black Hat, RSA.
- Identify online communities: DFIR Slack, Reddit r/cybersecurity, r/opsec, r/privacy; corporate IT security forums (LinkedIn groups, Slack communities).
- Compile list of 10-15 potential corporate buyers: corporate security officers, forensics departments, privacy teams (target: companies in regulated industries: finance, healthcare, tech).
- Research buyer procurement requirements: do they prefer direct sales or reseller channels? What certifications or compliance documentation do they require (SOC 2, ISO 27001)? Typical budget and sales cycle (2-4 months for corporate)?
- Identify 2-3 key influencers or speakers in DFIR/IT-security communities who could become early adopters or product evangelists.
- Use list to launch privacy/forensics presale campaign by Month 1.5 (2026-11-23).