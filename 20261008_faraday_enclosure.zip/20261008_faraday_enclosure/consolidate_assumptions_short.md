# Purpose
and

# Domain
# Primary Domain
Electromagnetic Shielding Engineering

# Secondary Domains

- Precision Sheet Metal Manufacturing
- Product Certification
- Consumer Product Marketing

## Rationale
Electromagnetic Shielding Engineering is the only outcome-role candidate and owns the main success criterion: a certified, effective Faraday enclosure. EMC Testing and Product Certification are constraints; manufacturing, design, marketing and finance are subordinate methods or markets.

# Disciplines

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Electromagnetic Shielding Engineering | 5 | 5 | outcome | Core product is a certified Faraday enclosure; shielding effectiveness defines success. |
| Electromagnetic Compatibility Testing | 5 | 5 | constraint | Shielding effectiveness must be measured and verified against recognised standards for credible certification. |
| Precision Sheet Metal Manufacturing | 4 | 4 | method | Production anchored in Tallinn's ISO-certified precision-metal fabrication ecosystem. |
| Product Certification | 4 | 4 | constraint | Product must pass EMC/shielding testing and EU conformity requirements before sale. |
| Consumer Product Marketing | 4 | 4 | market | Pre-selling to prepping networks and infrastructure buyers requires niche go-to-market and demand validation. |
| Industrial Design | 4 | 4 | method | Enclosure design for phones and laptops must balance usability, aesthetics, and shielding performance. |
| Startup Financial Management | 4 | 3 | method | Staged €750k funding with cash-flow-conditional tranche requires burn control and gating. |
| Supply Chain Logistics | 3 | 3 | method | Distribution from Tallinn across Europe requires fulfilment, customs, and shipping management. |
| Crowdfunding and Presales | 3 | 3 | market | Pre-selling to prepper networks and infrastructure buyers validates demand and supports cash flow. |

# Plan Type
# Physical Location Requirement

This plan requires one or more physical locations and cannot be executed digitally.

## Explanation

The plan covers designing, certifying, manufacturing and distributing a Faraday enclosure, a hardware product requiring physical presence:

- Manufacturing: Production anchored in Tallinn, Estonia, in precision sheet-metal fabrication facilities. Requires raw materials, tooling, prototyping, production runs and quality control on site.
- Design and testing: Enclosure must be prototyped, built, fitted around real phones and laptops, and shielding effectiveness measured in an accredited EMC test laboratory with specialised equipment.
- Certification: EU conformity and EMC/shielding standards require physical samples submitted and tested.
- Distribution: Metal product shipping from Tallinn across Europe needs warehousing, packaging, fulfilment and customs handling.
- Sales and market access: Pre-selling to prepping networks and critical-infrastructure buyers benefits from in-person contact, trade shows, buyer demonstrations and site visits. Product samples required for demonstrations.
- Operations: Team needs workspace and travel to Tallinn. Self-funded €750k (user constraint) largely spent on physical tooling, production and logistics.

Online presales, financial management and marketing could be digital. However, the core outcome is a manufactured, tested and shipped physical product.

# Physical Locations
# Physical Locations

## Requirements for physical locations

- Precision sheet-metal fabrication capability (laser cutting, bending, CNC machining)
- ISO-certified precision-metal manufacturing ecosystem
- Accredited EMC/shielding testing laboratory with RF measurement chambers
- EU conformity assessment and certification support
- Cross-border logistics and warehousing access for European distribution
- Access to prepper and preparedness communities for presales and feedback
- Critical-infrastructure buyer networks and procurement contacts
- Skilled RF and shielding engineering expertise
- Low-cost production base with existing fabrication tooling
- Proximity to or integration with European supply chains

## Location 1: Estonia

Tallinn, Estonia. Precision sheet-metal fabrication facilities in Tallinn industrial district or technology parks (e.g., Ülemiste City, Tehnopol).

## Rationale

Primary manufacturing anchor. Tallinn offers low-cost, ISO-certified precision-metal ecosystem with laser-cut and bent sheet-metal capabilities. Soft tooling and design iteration fit local fabricators' flexible tooling. Proximity to Scandinavian and European markets for cross-border fulfilment.

## Location 2: European Union (multi-site testing and certification)

Accredited EMC laboratory locations in Central Europe or Northern Europe (e.g., Germany, Sweden, Netherlands, or Estonia). Independent accredited test facilities certified under EN/IEC standards for RF shielding enclosure testing.

## Rationale

Design and certification require accredited EMC testing for shielding effectiveness (IEEE 299.1 or equivalent) to meet Shielding Proof Standard decision. A single accredited lab validation is planned for the final design. Proximity to Tallinn or EU logistics hubs reduces travel and sample-shipping costs. Testing must meet critical-infrastructure procurement standards.

## Location 3: European Union (distributed buyer access)

Multiple European cities across prepper networks, emergency-response agencies, utility operators, critical-infrastructure centres, and established preparedness retailers (e.g., Germany, Scandinavia, UK, France).

## Rationale

Presale and demand validation require direct access to prepper communities and critical-infrastructure buyers for deposits, pilots, and reference customers. Buyer segment sequencing starts with prepper networks and transitions to infrastructure procurement. Distributed presence supports multi-use RF-isolation narrative and cross-border fulfilment planning. Wireless and in-person engagement with communities and procurement offices accelerates sales cycles.

## Location Summary

Tallinn, Estonia, is the anchor for sheet-metal manufacturing and design iteration, leveraging its low-cost, ISO-certified precision-metal ecosystem and soft-tooling flexibility. An accredited EMC testing laboratory within or near the EU is essential for single accredited validation of the final design against RF shielding standards, meeting critical-infrastructure procurement requirements. Distributed European locations (prepper networks, emergency-response agencies, utility operators, and established retailers) are needed for presale deposits, pilot feedback, buyer engagement, and market access. The plan is geographically anchored to Tallinn for production but requires EU-wide buyer access and testing capabilities to execute the presale-gated, staged-funding model and reach the positive cash flow required for the second tranche.

# Currency Strategy
# Currencies

- EUR: Primary currency for all budgeting, reporting, and transactions. Manufacturing anchored in Tallinn (Eurozone), accredited testing in EU, buyer network across European Union. All major costs occur naturally in EUR. User-specified budget (€750k) is already denominated in EUR, eliminating forex friction.

## Currency strategy

- All operations and revenue occur within the Eurozone and EU. Use EUR for budgeting, supplier payments, lab fees, and financial reporting.
- No foreign exchange hedging or multi-currency management required.
- Consolidate all costs and revenue in EUR quarterly and annually for tranche-gate measurement and follow-on funding decisions.


# Identify Risks
# Risk 1 - Technical & Design

Shielding effectiveness may not meet target attenuation in accredited lab testing. The plan assumes a single-SKU rigid enclosure with conductive-gasket seams designed and iterated on an in-house rig, then validated once by an accredited EMC lab. If lab results fall short of claims or reveal seam/gasket failures, the design must be reworked, but hard tooling may already be committed. Re-testing adds €8–15k per run (estimate), and each design change after certification requires re-qualification.

## Impact

Failed lab validation after tooling commitment incurs sunk hard-tooling cost (€20–40k estimate) and forces redesign or claim reduction. Re-testing and re-qualification delay revenue by 2–4 months and consume €15–30k (estimate) from Year-1 budget. Weakened claims reduce infrastructure buyer confidence and may lower presale conversion. In worst case, sunk tooling cost and redesign expenses exhaust Year-1 budget before presales mature, blocking access to the €350k follow-on.

## Likelihood

Medium

## Severity

High

## Action

Gate hard tooling release on a documented pre-test design review with the accredited lab, so the lab confirms methodology and design readiness before sample submission. Run the in-house rig validation twice (two independent seam cycles) and document attenuation across the full claimed frequency band before committing to accredited testing. Reserve €20k (estimate) of Year-1 budget explicitly for one re-test and minor redesign. Schedule the single accredited lab run no later than Month 4 (2027-02-08), so redesign time remains before presales commit shipping dates.

# Risk 2 - Financial & Cash Flow

Presale deposits may not reach the stated minimum-order threshold needed to release hard tooling, or conversion to delivered units may lag the cash-flow gate window. Prepper communities are price-sensitive and skeptical of marketing; infrastructure buyers move slowly through procurement. If deposits arrive slowly or refund requests cluster after a news cycle mentioning Carrington risk, the cash flow needed to trigger the €350k follow-on may not be met within the Year-1 window.

## Impact

Shortfall in presale deposits delays or prevents hard-tooling release, pushing first revenue beyond Month 9 (2027-07-08) and risking missed cash-flow gate by end of Year-1. A €150–250k shortfall (estimate) in presale deposits or a 3-month slip in delivered-unit receipts may leave cumulative cash flow below the tranche gate even after presale fulfillment. The €350k follow-on is withheld, halting inventory replenishment, marketing and R&D, and forcing the venture into financial constraint or wind-down.

## Likelihood

Medium

## Severity

High

## Action

Define the cash-flow gate measurement convention before launch (Month 0.5 = 2026-10-23) using trailing-quarter delivered-unit receipts only, excluding presale deposits, so presale timing does not distort the gate. Set the minimum presale threshold at €80–120k (estimate, to be refined) and commit tooling only after that threshold is met and pre-test results confirm the design. Track presale conversion and refund rates weekly and trigger a pivot if conversion falls below 40% (estimate) by Month 3 (2027-01-08). Run parallel presale campaigns in prepper networks and critical-infrastructure buyer groups from Month 0 (2026-10-08) to test both segments' deposit rates.

# Risk 3 - Market & Demand

Presale volume may skew heavily toward low-value prepper units (price-sensitive, small orders), while critical-infrastructure orders remain slow, leaving inventory of unprofitable low-margin product. The plan assumes a multi-use RF-isolation narrative to widen addressable market, but this may dilute the Carrington brand and slow niche prepper adoption if messaging is inconsistent. Alternatively, strict prepper positioning may cap unit volume well below what the €750k plan needs to reach positive cash flow.

## Impact

Prepper-skewed presales generate high unit volume but low margin (unit price €40–60 estimate, gross margin €10–20 estimate per unit), while infrastructure orders (unit price €150–300 estimate, margin €60–120 estimate) arrive slowly or not at all. Result: 3000–4000 prepper units sold at €15 margin versus 100–200 infrastructure units at €80 margin. Cumulative Year-1 revenue €60–80k (estimate) is insufficient to cover €400k Year-1 burn, and positive cash flow is not achieved, blocking the €350k follow-on. Company reaches Month 12 (2027-10-08) with depleted cash and no path to profitability.

## Likelihood

High

## Severity

High

## Action

Test the multi-use RF-isolation narrative (privacy, travel, key-fob security, digital-forensics) in parallel with Carrington messaging from Month 1 (2026-11-08). Run separate presale campaigns in prepper forums, digital-forensics communities and corporate IT security groups to measure deposit velocity and average order value by segment. If prepper conversion exceeds 70% of total presales by Month 3 (2027-01-08), pivot marketing away from Carrington and emphasize RF isolation and privacy. Set a minimum average order value (€50–100 estimate) as a go/no-go gate for continuing presales; if average order falls below €40, halt presale marketing and shift to wholesale or distribution channels. Negotiate a wholesale agreement with an established prepper retailer (consignment-free terms) as a backup channel to accelerate infrastructure-segment access.

# Risk 4 - Regulatory & Compliance

EU product-safety and consumer-protection rules applicable to the enclosure are not definitively verified. If the enclosure falls under the EMC Directive or General Product Safety Directive (applicability not verified), marketing claims that exceed measured data or tested frequency range expose the company to regulatory challenge, mandatory product recall, or fines. Reputational damage from a failed real-world Carrington event or customer complaints about shielding are difficult to insure and may exceed company reserves.

## Impact

Regulatory challenge or consumer complaint requiring claim revision or product recall incurs €30–80k (estimate) in legal fees, redesign, and retest. Uninsured liability exposure if a customer experiences device loss in an EMI event and sues for breach of warranty or misrepresentation creates potential multi-year legal cost and reputational damage. In scenario with high-profile Carrington event during Year-1 or Year-2, unmet customer expectations and social media amplification damage brand and sales momentum, reducing presale conversion and post-launch revenue by 30–50% (estimate).

## Likelihood

Medium

## Severity

High

## Action

Commission a legal opinion on applicable EU product rules (EMC Directive, General Product Safety Directive, consumer protection rules) by Month 1 (2026-11-08) (€2–5k estimate). Limit all marketing and data-sheet claims strictly to measured shielding attenuation across the tested frequency band and explicitly disclaim protection for grid-connected equipment or real-time events. Include scope statements in all sales materials: "This enclosure protects stored spare devices against RF exposure. It does not protect active equipment or prevent grid-scale events." Obtain product liability insurance covering €250–500k (estimate) in defect claims and seek clarification on whether Faraday-enclosure claims are insurable; if not, adjust liability cap in warranty terms. Publish the accredited lab report with every sale so customers see the exact measured data and frequency range tested.

# Risk 5 - Supply Chain & Production

Tallinn precision-metal fabrication base is assumed low-cost and ISO-certified, but supply-chain risk is concentrated in a single region and single supplier base. Soft tooling (laser cut and bend) is assumed flexible for iteration, but if the chosen Tallinn fabricator lacks capacity or changes pricing during Year-1, redesign or scaled production becomes difficult. Conductive-gasket materials may require import; supplier delays or quality variance in gaskets can delay production and certification.

## Impact

Tallinn fabricator capacity constraints or price increases (10–20% estimate) during Year-1 raise unit cost and reduce margins, offsetting presale cash. Loss of primary fabricator access (e.g., due to capacity reallocation or bankruptcy) forces urgent sourcing from a secondary supplier, adding 4–6 weeks (estimate) delay and potential quality re-qualification. Gasket-material supply chain disruption delays first batch shipment by 2–4 weeks (estimate), missing customer delivery promises and triggering refund requests that strain cash flow around the Month 9 (2027-07-08) cash-flow gate measurement window.

## Likelihood

Medium

## Severity

Medium

## Action

Identify and pre-qualify a secondary Tallinn-area precision-metal fabricator and gasket supplier by Month 1 (2026-11-08), with a trial laser-cut batch to confirm quality. Lock in tooling and fabrication pricing with the primary supplier for Year-1 in a signed agreement specifying capacity reservation and price caps. Source conductive-gasket material from at least two qualified suppliers (one primary, one backup) and hold a 30-day buffer stock (€5–10k estimate) of gaskets before production release. Document all sourcing risks and lead times in a supply-chain risk register reviewed monthly. If primary fabricator raises prices above 10% or signals capacity loss, trigger the secondary-supplier transition and accelerate first production run to de-risk inventory.

# Risk 6 - Operational & Execution

The plan requires RF and shielding engineering expertise that a founder-led team may lack. The plan assumes either an in-house RF engineer (salaried) or an EMC consultancy on milestone basis. A salaried hire adds €40–60k (estimate) fixed Year-1 cost; a consultancy on milestone basis incurs lumpy spending (€5–10k per milestone) and may have timeline misalignment with the presale schedule. Lack of internal expertise or external support delays prototype design and extends time to first accredited lab test, compressing the presale window and redesign buffer.

## Impact

Delayed prototype development (2–3 months slip estimate) pushes accredited lab test from Month 4 (2027-02-08) to Month 6 (2027-04-08) or later, leaving insufficient time for redesign and presale fulfillment before the Year-1 cash-flow gate. Milestone-based EMC consultancy with slow delivery or timeline misalignment adds unexpected delays and costs. Alternatively, hiring a full-time RF engineer at €50k/year (estimate) consumes 12.5% of Year-1 budget with no presale revenue to offset, straining cash and forcing cuts elsewhere (marketing, testing, or tooling).

## Likelihood

High

## Severity

Medium

## Action

Secure RF and shielding expertise by Month 0.5 (2026-10-23) using a hybrid model: engage an independent EMC consultancy on a fixed milestone basis (€20–25k estimate for design review and first accredited lab coordination) and co-develop the enclosure with an Estonian university lab (e.g., Tallinn University of Technology) in exchange for access to their RF measurement chambers and publication rights. This limits fixed headcount and early salary cost while securing technical capability and accredited lab access. Set clear milestones: prototype design by Month 2 (2026-12-08), in-house rig validation by Month 3 (2027-01-08), lab submission by Month 4 (2027-02-08), report by Month 5 (2027-03-08). If university partnership does not materialize, hire a part-time RF engineer (0.5 FTE, €25k estimate Year-1) or contract a second consultancy firm for backup.

# Risk 7 - Logistics & Distribution

The plan specifies Tallinn as the single production and shipping point for all European presales. Heavy metal enclosures (estimated 2–4 kg per unit) incur significant freight costs, especially to distant EU markets (Southern Europe, UK). Build-to-order fulfilment requires long lead times (3–4 weeks estimate from presale to shipment), which may disappoint buyers expecting immediate delivery. Buffer stock in a third-party EU warehouse reduces lead times but ties up working capital (€30–60k estimate for 500–1000 units), consuming cash needed for design, testing, and marketing.

## Impact

Freight costs add €8–15 per unit (estimate) to landed cost, reducing margins by 15–30% (estimate) depending on presale geography. Long lead times reduce presale conversion if buyers want protection 'now' rather than waiting 3–4 weeks. Buffer stock in third-party warehouse ties up €30–60k (estimate) working capital, reducing available cash for design and testing and risking cash-flow gate delay if inventory does not turn fast (sales slower than forecast). Alternatively, build-to-order delays trigger refund requests or complaints, damaging trust with early adopters during critical presale phase.

## Likelihood

Medium

## Severity

Medium

## Action

Defer buffer-stock warehousing until presale volume and conversion rate are proven (Month 6 = 2027-04-08 onward). Run first production run (500–800 units estimate, based on presale deposits) and ship directly from Tallinn on a 2–3 week build-to-order cycle, quoting delivery dates upfront in presale terms. Partner with a logistics provider (DHL, UPS, or local carrier) to negotiate volume-discount freight rates and lock in pricing for Year-1. Set presale delivery expectations clearly: "Ships within 3 weeks of order confirmation." If presale conversion exceeds 60% and average order value exceeds €80 (estimate) by Month 5 (2027-03-08), negotiate a trial 60-day buffer in a regional EU warehouse (Central Europe or Scandinavia) for 200–300 units to serve high-demand regions. Monitor inventory days outstanding (target: 30–40 days) and halt buffer stock if turnover falls below 1.5x per month.

# Risk 8 - Market & Segment Timing

The plan assumes sequencing buyers (prepper networks first, infrastructure buyers second) to prove demand and build reference customers. However, infrastructure procurement cycles are typically 6–12 months or longer, meaning a pilot or initial order may not close until Month 8–12 (2027-06-08 to 2027-10-08) or beyond the Year-1 window. If infrastructure orders do not arrive in time to contribute to the cash-flow gate measurement (end of Year-1), the positive-cash-flow condition for the €350k follow-on may not be met, even if volumes are technically healthy.

## Impact

Slow infrastructure procurement delays large reference orders until Month 9–12 (2027-07-08 to 2027-10-08) or beyond, meaning delivered-unit revenue from infrastructure arrives after the Year-1 cash-flow gate cutoff. Result: only small prepper volumes count toward the gate, and cumulative cash flow may fall short of the threshold (not yet defined in the plan) needed to unlock the €350k follow-on. Company reaches Month 12 (2027-10-08) with growing preorder backlog and production readiness but insufficient delivered-unit revenue to satisfy the gate, blocking capital access and forcing a funding crisis or restructuring.

## Likelihood

Medium

## Severity

High

## Action

Clearly define the cash-flow gate measurement window and threshold before launch (Month 0.5 = 2026-10-23), e.g., "Positive quarterly operating cash flow (delivered units only) of €30k or more in Q4 of Year-1." Sequence buyer outreach in parallel, not strictly sequentially: approach prepper networks and infrastructure buyers concurrently starting Month 1 (2026-11-08), so presale deposits arrive from both segments and infrastructure pilots close sooner. Set a "fast-track" pilot agreement with one or two infrastructure buyers by Month 3 (2027-01-08) (pilot units at cost plus 20% estimate, with delivery by Month 5 = 2027-03-08) to generate an in-time reference and revenue. If infrastructure deals stall past Month 6 (2027-04-08), pivot presale marketing to the multi-use RF-isolation narrative (privacy, travel security) to widen addressable market and accelerate adoption outside the niche prepper base. Document segment-by-segment presale and revenue tracking in a monthly dashboard shared with the tranche-gate governance team.

# Risk 9 - Financial & Burn Rate

The €400k Year-1 budget (user constraint) is allocated across design, prototyping, accredited lab fees, soft tooling, first production batch, marketing, and personnel. Spending is not explicitly sequenced in the provided plan, so there is risk of front-loading irreversible costs (hard tooling, large production runs) before proof and presales exist. Overruns in any area (lab fees, design iteration, prototyping) compress the remainder and may force cuts to marketing or testing that slow presale uptake or compromise design validation.

## Impact

Unsequenced €400k spend risks exhausting cash on design and tooling before presales materialize, leaving insufficient runway to market, fulfill presales, or absorb redesign costs. A 20% overrun (€80k estimate) in prototyping, lab fees, or tooling leaves only €320k for production, marketing, and contingency—insufficient to fund a meaningful first production batch and marketing push. Company reaches Month 9–10 (2027-07-08 to 2027-08-08) with cash depleted, presales not yet validated, and no funds to execute fulfillment or pivot, forcing early wind-down or external funding with dilution to the founder.

## Likelihood

High

## Severity

Medium

## Action

Create an explicit monthly Year-1 burn schedule (Month 0.5 = 2026-10-23) allocating the €400k across design (€30k estimate), prototyping and in-house test rig (€40k estimate), accredited lab fees (€15k estimate), soft tooling (€20k estimate), first production batch (€150–200k estimate), contingency/redesign reserve (€20k estimate), and marketing/sales (€50–75k estimate). Hold the €20k redesign reserve uncommitted until Month 5 (2027-03-08) (post lab test). Release hard-tooling spend only after presale deposits reach €80k (estimate threshold) and pre-test results confirm design, so irreversible commitments follow evidence. Track actual spend versus plan weekly; if cumulative burn exceeds plan by 10% at any milestone, trigger a review and spending freeze until the source and impact are clarified. Document carry-over assumptions: if presales are delayed, what spending will be deferred or cut?

# Risk 10 - Technical & Design

The plan specifies a single-SKU rigid folded-aluminium or steel enclosure sized to fit the largest common laptop and several phones. A single size may not accommodate the range of devices (13-inch to 17-inch laptops, various phone sizes), risking customer dissatisfaction if their device does not fit or leaves them space for accessories. Alternatively, offering multiple sizes within the single-SKU constraint requires multiple tooling variants, which violates the single-SKU goal and raises re-qualification cost.

## Impact

Fit-and-finish complaints for devices that are marginal fits (too tight, no space for cables) reduce presale conversion and trigger returns, raising refund cost and damaging reputation. A rigid enclosure sized for a 15-inch laptop may not fit 17-inch devices or may leave a 13-inch device with excessive rattle and potential shielding loss at seams. If 30–50% (estimate) of presale orders are returned or complained about due to fit, refund cost and reputational damage reduce future presale conversion and sales momentum by 20–40% (estimate).

## Likelihood

Medium

## Severity

Medium

## Action

In the design phase (Month 1–2 = 2026-11-08 to 2026-12-08), publish a detailed size-and-fit guide showing which laptop models and phone sizes fit the enclosure. Test the prototype fit against the three most common laptop sizes (13-inch, 15-inch, 17-inch) and five major phone models; document pass/fail with photos. In presale materials, explicitly state "This enclosure fits laptops up to 17 inches (maximum internal dimensions: 420 x 280 x 50 mm estimate) and phones up to 6.5 inches". Offer a 30-day no-questions refund for fit-related returns within the first 100 units sold as a trust-builder during launch phase. If fit complaints exceed 10% of orders by Month 7 (2027-05-08), commission a follow-on smaller SKU variant (e.g., phone-only pouch) for Month 9+ release, keeping the launch single SKU but enabling a family variant later.

# Risk 11 - Organizational & Governance

The plan is founder-led and self-funded, with a staged €350k follow-on conditional on positive cash flow. No governance structure is defined for deciding when the cash-flow gate is met, what constitutes "positive cash flow", or who makes the tranche release decision. Ambiguity creates risk of dispute, founder delay, or inconsistent interpretation of the gate condition, especially if a cash-flow measurement window is missed or results are borderline.

## Impact

Unclear cash-flow gate definition leads to founder second-guessing or advisory-board disagreement on gate release, delaying the €350k tranche decision into Month 13–14 (2027-11-08 to 2027-12-08) when competitive and market timing pressures mount. Lack of clarity on presale refund policy and delivery obligations creates founder liability if presale customers demand refunds due to long lead times or fit issues. Founder burnout from solo operations and continuous fundraising/gate-measurement work increases risk of operational errors, missed deadlines, and poor decision-making in Month 6–12 (2027-04-08 to 2027-10-08) as cash pressure rises.

## Likelihood

Medium

## Severity

Medium

## Action

Draft and document the cash-flow gate measurement convention by Month 0.5 (2026-10-23) (e.g., "Positive operating cash flow measured on delivered-unit revenue only, trailing 3-month average of €25k+, measured end of Year-1 Q4"). Establish a simple governance checkpoint: founder + one external advisor (e.g., accountant or experienced advisor) will measure and sign off on gate result by Month 12.5 (2027-10-23). Publish this convention and checkpoint plan publicly in presale terms and marketing, so all stakeholders understand the gate logic upfront. Create a written presale terms document (refund policy, delivery timelines, contact escalation path) by Month 1 (2026-11-08), so presale customers know their rights and the founder has clear obligations. If founder capacity becomes strained by Month 6 (2027-04-08) (operations, fundraising, gate measurement), hire a part-time operations or finance person (10–15 hrs/week, €200–300/week estimate) to handle fulfillment, refunds, and cash-flow tracking, freeing founder for strategy and presale work.

# Risk 12 - Technical & Certification

The plan assumes one accredited EMC lab validation for the final design, using the report as the public credibility basis for all sales claims. However, the applicable standard for small enclosures (IEEE 299.1 or equivalent) is not verified; if the chosen lab recommends a different or more stringent standard, the test methodology and cost may differ from plan assumptions. Additionally, if the lab uses a different frequency range or attenuation threshold than the enclosure design targets, results may fall short of marketing claims.

## Impact

Lab recommends a higher-cost or longer-duration test standard (e.g., full MIL-STD-285 instead of IEEE 299.1 estimate), adding €10–20k (estimate) and 4–8 weeks (estimate) to the certification timeline. Test results show attenuation below marketing claims in certain frequency bands (e.g., lower attenuation at 50–100 MHz than claimed), requiring claim revision or design change. Revision forces either (a) a second lab test (€8–15k estimate, 6–8 weeks) or (b) a narrower frequency-range claim that weakens market positioning and infrastructure buyer credibility.

## Likelihood

Medium

## Severity

High

## Action

By Month 0.5 (2026-10-23), contact 2–3 accredited EMC laboratories (e.g., in Germany, Sweden, Netherlands) and request a pre-engagement consultation (often free or low-cost) to clarify applicable standards, test methodology, cost, and timeline for a small Faraday enclosure. Document the lab's recommendation for the applicable standard and frequency range. Choose the lab based on (a) cost predictability, (b) timeline fit (committed report delivery by Month 5 = 2027-03-08), and (c) willingness to engage in design consultation before formal submission. Request a design-readiness review (€2–3k estimate) before submitting samples, so the lab confirms that the design is test-ready and gives feedback on likely attenuation before costly sample submission. Lock in test cost and timeline in a statement of work by Month 1.5 (2026-11-23), so no surprises emerge in Month 4 (2027-02-08).

# Risk 13 - Financial & Funding

The plan relies on presale deposits (refundable) and positive Year-1 cash flow to unlock the €350k follow-on tranche. If presale deposits are refundable and a news cycle (e.g., solar-storm hype or lack thereof) shifts demand, presale refund requests may spike, consuming deposits that were counted as cash flow. Additionally, if the positive-cash-flow gate is defined loosely (e.g., including presale deposits as cash), it creates a perverse incentive to commit follow-on spending before presales are actually fulfilled, leaving real cash-flow exposure.

## Impact

Presale refund spike (20–30% of deposits estimate if Carrington narrative fades) reduces available cash by €20–40k at a critical point (Month 8–9 = 2027-06-08 to 2027-07-08) when production tooling must be committed. Alternatively, if presale deposits are counted as "positive cash flow" but aren't yet delivered, the €350k follow-on is released before fulfillment obligations are met, and if fulfillment then slips, the company has spent the follow-on tranche on ongoing operations and has no capital for inventory replenishment or growth, leaving it underfunded.

## Likelihood

Medium

## Severity

High

## Action

Define presale deposits as "liabilities, not cash flow" in the accounting framework from Month 0.5 (2026-10-23). Measure positive cash flow using only delivered-unit revenue (invoiced and paid), not presale deposits. Hold presale deposits in a separate earmarked account and do not use them for operational spending; ring-fence them exclusively for fulfilling presale orders, so refunds do not trap operational cash. Set a presale deposit refund cap: if cumulative refunds exceed 15% (estimate) of total deposits by Month 8 (2027-06-08), trigger a pivot in marketing narrative or buyer-segment strategy to re-attract and stabilize demand. Document a monthly cash reconciliation (operational cash vs. presale liability) and share it with an advisor or accountant to catch any drift in definitions before gate measurement.

# Risk 14 - Market & Competitive

The Faraday enclosure market for consumers is small and niche (preppers, privacy advocates, digital-forensics professionals). If a competitor enters with better branding, lower price, or equivalent performance during Year-1 or early Year-2, the Carrington Event Prep product may lose presale momentum and market-access advantages. Additionally, if a large retailer (e.g., Amazon, specialty preparedness retailer) launches its own private-label Faraday enclosure, it can undercut price and capture channel access faster than a self-funded startup.

## Impact

Competitive product entry reduces presale conversion by 20–40% (estimate) as early adopters split between brands. Price competition compresses margins, forcing choices between (a) accepting lower profit per unit, (b) cutting marketing spend to preserve cash, or (c) exiting low-margin segments. Market share loss in Year-1 reduces the reference-customer credibility and sales momentum needed to close infrastructure deals in Year-2, lowering the cash-flow gate result and delaying or blocking the €350k follow-on tranche.

## Likelihood

Low

## Severity

Medium

## Action

Establish a brand and positioning differentiation starting Month 1 (2026-11-08): emphasize the multi-use RF-isolation narrative (privacy, travel, security) alongside Carrington prep, so the product appeals beyond disaster preppers and is less vulnerable to a niche competitor. Build a community around early adopters and infrastructure pilots to create switching cost and lock-in (e.g., annual verification service, community forums). Monitor competitor landscape monthly and trigger a strategic pivot if a credible competitor launches within 6 months: either (a) emphasize manufacturing locality ("Designed and made in Estonia"), (b) add a services layer (shielding verification, fit consulting), or (c) open a second market segment (e.g., corporate IT security) to diversify revenue. Document IP and design choices (e.g., specific seam design, gasket materials) that are defensible and difficult to replicate quickly.

# Risk 15 - Operational & Execution

The plan specifies a small, founder-led team without detailed staffing or decision-making structure. Managing design, prototyping, supplier coordination in Tallinn, accredited lab engagement, presale marketing, and fulfillment across multiple geographies and functions is intensive work. Founder burnout, illness, or personal circumstance (family, visa, legal) could halt execution for weeks and create cascading delays in critical paths.

## Impact

Founder absence (illness, family emergency) during Month 4–5 (2027-02-08 to 2027-03-08) (critical lab submission and design-review period) delays accredited lab engagement by 2–4 weeks (estimate), pushing lab report from Month 5 (2027-03-08) to Month 6–7 (2027-04-08 to 2027-05-08). Consequent delays compress the presale and production timeline, reducing the window for resolving issues before the Year-1 cash-flow gate. Burnout in Month 8–10 (2027-06-08 to 2027-08-08) (high-stress presale fulfillment period) leads to poor decision-making, missed deadlines, or quality oversights in production that damage customer experience and reduce repeat sales. Visa or personal constraint affecting Tallinn access prevents hands-on supplier coordination and quality control during early production runs.

## Likelihood

Low

## Severity

Medium

## Action

Establish a backup operations contact by Month 1 (2026-11-08) (part-time advisor or operations person with authority to make decisions if founder is unavailable). Document critical decision paths and escalation procedures for key suppliers, lab contacts, and customer support so another person can step in. Create a detailed timeline and decision-checklist document by Month 1 (2026-11-08) so the plan is not held only in the founder's head. Plan for Tallinn visits in advance: schedule visits in Month 1 (2026-11-08) (supplier identification), Month 2–3 (2026-12-08 to 2027-01-08) (design review with fabricator), Month 4–5 (2027-02-08 to 2027-03-08) (pre-test design confirmation), and Month 7–8 (2027-05-08 to 2027-06-08) (first production quality control), so visits are concentrated and planned rather than reactive. Arrange for a local Tallinn-based liaison (e.g., part-time engineering contact, local accountant) to handle ongoing supplier communication if founder is unavailable for extended periods.

# Risk Summary

Carrington Event Prep is a self-funded, capital-constrained, two-tranche hardware venture (€400k Year-1, €350k follow-on gated on positive cash flow) anchored in Tallinn manufacturing and presale-validated demand. The most critical risks are: (1) Shielding validation and redesign cost – a failed accredited lab test after tooling commitment forces costly re-qualification or sunk loss; (2) Insufficient presale volume or cash-flow gate misalignment – niche prepper demand may not generate enough deposits or delivered-unit revenue to unlock the €350k follow-on within the Year-1 window, stranding the venture; (3) Long infrastructure sales cycles and claim-substantiation exposure – slow procurement and weak claim-to-evidence match under EU consumer law create delivery pressure against testing time and reputational risk. These risks interact: strict cash-flow gate timing pressures presales and fulfilment speed, which shortens the design-iteration window and increases redesign risk. Mitigation depends on clear sequencing: cheap in-house iteration before any hard tooling, explicit deposit thresholds tied to test results, and a multi-use narrative (RF isolation, not just Carrington prep) to widen the reachable market and ease the cash-flow gate.

# Make Assumptions
# Budget Allocation & Hard Tooling Gate

## Financial Sequencing

Year-1 €400k budget allocation:

- Design and prototyping: €70k
- In-house test rig and iteration: €40k
- Accredited lab fees: €15k
- Soft tooling: €20k
- First production batch: €150–200k
- Marketing and sales: €75k
- Redesign reserve: €20k

Hard tooling releases only after presale deposits reach €80–120k (proposed threshold) and pre-test results confirm design readiness.

## Financial Feasibility & Burn Sequencing Assessment

Front-loading design (€110k estimate) and accredited lab (€15k) enables cheap iteration before hard tooling locks in the design. Deferring production tooling until presale deposits arrive reduces sunk-cost risk.

Risk: €20k redesign reserve may be insufficient for major rework; recommend increasing to €30k and reducing marketing budget if presales perform strongly.

Risk: if presale deposits lag (Months 5–6 = 2027-03-08 to 2027-04-08), hard-tooling release slips into Months 7–8 (2027-05-08 to 2027-06-08), compressing production and fulfillment window before cash-flow gate measurement (Month 12 = 2027-10-08).

Recommend monthly cash tracking and a defined decision gate (Month 5 = 2027-03-08) to either commit tooling or pivot marketing.

# Presale Delivery Timeline & Customer Communication

## Timeline & Lead Times

Initial presales operate on a 2–3 week (estimate) build-to-order cycle from order confirmation to shipment. No buffer inventory is held until presale volume and conversion rate are proven (Month 6 = 2027-04-08 estimate).

Delivery expectations are explicitly communicated in all presale materials to manage customer expectations and reduce refund risk.

## Timeline & Milestones Assessment

Build-to-order with 2–3 week lead times is feasible if accredited lab report arrives by Month 5 (2027-03-08) and first production batch is committed by Month 6 (2027-04-08).

Risk: if presale conversion is slow or concentrated in later months (Months 8–10 = 2027-06-08 to 2027-08-08), build-to-order lead times may extend into the cash-flow gate measurement window (Month 12 = 2027-10-08), delaying delivered-unit revenue that counts toward the €350k tranche condition.

Mitigation: set a presale cutoff date (e.g., Month 8 = 2027-06-08) after which new orders are deferred to a post-gate window, ensuring fulfillment of early orders before gate measurement. Document delivery timelines in a presale SLA by Month 1 (2026-11-08).

# Year-1 Staffing & Supplier Coordination

## Staffing Model

Year-1 team is founder-led with contractor support:

- Independent EMC consultancy: €20–25k (estimate), milestone-based, for RF design and lab coordination
- Co-development partnership with Estonian university lab for in-house rig and measurement access
- No full-time hire of RF engineers
- Part-time operations person: 0.5 FTE or 10–15 hrs/week, €200–300/week (estimate), added by Month 6 (2027-04-08) if presale volume warrants

Tallinn supplier coordination and quality control are founder responsibilities, with quarterly in-person visits (Months 1, 3, 5, 7–8).

## Resources & Personnel Assessment

Hybrid consultant and university-partnership model limits fixed salary cost (€20–25k vs. €40–60k for salaried RF engineer) and preserves cash runway.

Risk: university timelines may not align with commercial deadlines; milestone-based consultancy fees are lumpy and may require front-loading. Founder-led Tallinn coordination requires intensive travel and domain expertise beyond typical commercial-software backgrounds.

Risk: if university partner is slow or unavailable, prototype development compresses and accredited lab submission is delayed (impact: Month 4 = 2027-02-08 → Month 6 = 2027-04-08, losing 2 months of redesign buffer).

Mitigation: lock in written milestone agreements with both university and consultant by Month 0.5 (2026-10-23), including penalty clauses and backup plans. If university partnership fails to materialize by Month 1.5 (2026-11-23), hire a part-time RF engineer immediately to stay on track.

# EU Compliance & Regulatory Framework

## Applicable Regulations

Enclosure likely falls under the General Product Safety Directive (not verified; legal opinion commissioned by Month 1 = 2026-11-08, €2–5k estimate).

Marketing claims are strictly limited to measured shielding attenuation across the tested frequency band.

Scope statement: 'This enclosure protects stored spare devices against RF exposure. It does not protect active equipment or prevent grid-scale events.'

Product liability insurance: €250–500k (estimate) for defect claims; insurability of Faraday-enclosure claims is clarified during Year-1.

No voluntary CE marking or additional certification is pursued in Year-1; accredited lab report serves as public credibility basis.

## Governance & Regulations Assessment

Strict claim-to-evidence match minimizes regulatory risk and consumer-law exposure.

Risk: applicability of specific EU directives is not verified. If product falls under the EMC Directive, CE marking or notified-body assessment may be required, adding €10–30k and 8–12 weeks to timeline.

Risk: if real-world Carrington event occurs during Year-1 or Year-2 and customer losses occur, uninsured liability and reputational damage could exceed reserves.

Mitigation: commission legal opinion immediately (Month 0.5 = 2026-10-23), lock in product liability insurance terms by Month 2 (2026-12-08), and publish the accredited lab report with every unit sold. Document all claim-limiting language in a compliance checklist reviewed monthly.

# Cash-Flow Gate Measurement & Release Criteria

## Gate Definition

Positive cash flow is measured on trailing-quarter operating revenue from delivered units only, excluding presale deposits. Threshold: €25–30k (estimate) quarterly operating surplus by end of Year-1 (Month 12 = 2027-10-08).

Presale deposits are held in separate earmarked account and classified as liabilities, not cash flow.

Governance: founder + one external advisor measure and sign off on gate result by Month 12.5 (2027-10-23). Convention is published in presale terms and marketing upfront.

## Safety & Risk Management Assessment (Gate Control)

Strict, transparent gate definition protects against moral hazard and ensures €350k follow-on is released only when real traction is proven.

Risk: quarterly threshold of €25–30k is modest (estimate) and may be achievable on modest prepper volume (~300–500 units at €60–80 average unit margin = ~€20–40k quarterly), but if infrastructure orders arrive slowly, delivered-unit revenue may lag deposits by 2–3 months, pushing gate measurement into Months 13–14 (2027-11-08 to 2027-12-08) and creating governance ambiguity.

Mitigation: clarify gate measurement window (last quarter of Year-1: Oct–Dec 2027) and decision deadline (end of Month 12.5 = 2027-10-23) in a written charter by Month 0.5 (2026-10-23). If measurement falls between -€5k and +€25k (ambiguous), establish tiebreaker rule upfront (e.g., founder retains discretion to extend runway 90 days and re-measure).

# Environmental & Sustainability Positioning

## Product & Manufacturing Commitments

Product uses aluminum or steel sheet-metal (both recyclable), conductive gaskets (material TBD), and minimal non-metal components. Packaging is designed for reusability or recyclability (cardboard, no foam estimate).

No explicit sustainability certification or carbon-neutral claim is pursued in Year-1; environmental impact is positioned as incidental (metal enclosure is durable, reusable, and avoids planned obsolescence).

Manufacturing is anchored in Tallinn, a EU jurisdiction with strict waste and environmental regulations, providing indirect ESG credibility. Supplier environmental compliance is assumed through ISO certification of Tallinn fabricators (not explicitly audited in Year-1).

## Environmental Impact Assessment

Durable metal enclosure has lower lifecycle environmental impact than single-use electronics, providing subtle but credible environmental argument. No explicit certification pursued, so environmental positioning is secondary to performance.

Risk: if competitors or regulatory pressure emerge around sustainability, lack of explicit environmental claims or supply-chain transparency could be a weakness. Freight cost and environmental impact of shipping heavy boxes across Europe (2–4 kg per unit, €8–15 per unit estimated environmental cost) may become presales objection if green positioning grows.

Mitigation: by Month 3 (2027-01-08), commission quick lifecycle assessment (LCA) or carbon footprint estimate (~€2–5k, not verified) to quantify impact and establish baseline. Document material sourcing and supplier ESG compliance in supply-chain transparency sheet. Consider offering carbon-offset shipping or take-back recycling program for end-of-life units by Year-2 if presale volume warrants.

# Presale Buyer Segments & Demand Strategy

## Segment Targeting

Presale segments are approached in parallel starting Month 1 (2026-11-08):

- Prepper networks and online communities: deposit rate 40–50% (estimate), average order value €50–70, conversion timeline 4–6 weeks (estimate)
- Critical-infrastructure and emergency-planning pilots: rate 30–40% (estimate), order value €200–300+, timeline 8–12 weeks (estimate)
- Digital-forensics and privacy advocates: rate 35–45% (estimate), order value €80–150, timeline 5–8 weeks (estimate)

Total presale target: €80–120k deposits across all segments by Month 6 (2027-04-08) to trigger hard-tooling release.

Segment sequencing is data-driven: if prepper deposits dominate early, marketing pivots to multi-use RF-isolation narrative to attract higher-value infrastructure and privacy segments.

## Stakeholder Involvement Assessment

Parallel segment outreach maximizes presale velocity and provides diverse reference customers; it avoids sequential risk where prepper-first sequencing may not generate sufficient infrastructure volume or high-value orders needed for positive cash flow.

Risk: parallel campaigns require distinct messaging (disaster prep vs. privacy vs. operations continuity), risking brand dilution if executed poorly. If prepper segment dominates (70–80% of deposits estimate) while infrastructure pilots stall, company ends up with high unit volume but low margin, leaving cash-flow gate exposure.

Risk: if infrastructure pilots move slowly (Months 9–12 = 2027-07-08 to 2027-10-08 or beyond), their revenue arrives after gate measurement window, contributing nothing to Year-1 cash flow.

Mitigation: by Month 3 (2027-01-08), measure deposit velocity and average order value by segment and track presale conversion rate (target: 40–50% overall estimate). If prepper conversion exceeds 70% of total by Month 4 (2027-02-08), pivot marketing and presale focus to infrastructure and privacy segments. Establish fast-track pilot agreement with one or two infrastructure buyers by Month 3 (2027-01-08) (pilot units at cost plus 20%, delivery by Month 5 = 2027-03-08) to generate in-time reference and revenue.

# Fulfillment & Logistics Infrastructure

## Production & Fulfillment Model

Initial presale fulfillment (Months 6–9 = 2027-04-08 to 2027-07-08) is build-to-order and shipped directly from Tallinn on a 2–3 week cycle (no buffer inventory).

If presale volume proves sustainable and conversion reaches 60% (estimate) with average order value exceeding €80 (estimate) by Month 5 (2027-03-08), trial buffer of 200–300 units is contracted with regional EU logistics provider (Central Europe or Scandinavia) for Months 8–9 (2027-06-08 to 2027-07-08) onward.

Buffer inventory working capital: €30–60k (estimate), released only after presale deposits confirm demand. Target inventory turnover: 1.5x per month (30–40 day inventory cycle estimate).

## Operational Systems Assessment

Build-to-order model minimizes working-capital tie-up and protects cash during scarce Year-1 window, but risks longer lead times (2–3 weeks vs. 2–3 days with buffer stock) and may reduce presale conversion if customers demand faster delivery.

Deferring buffer inventory until Months 8–9 (2027-06-08 to 2027-07-08) compresses integration window: if logistics provider setup is delayed or performance is poor, presale customers experience delays and refund rates may spike, damaging cash flow just before gate measurement.

Risk: freight costs from Tallinn are €8–15 per unit (estimate) to distant EU markets, reducing margins by 15–30% (estimate). If presale geography skews toward Southern Europe or UK, freight cost can exceed presale margin and force indefinite build-to-order, delaying delivery and reducing satisfaction.

Mitigation: by Month 2 (2026-12-08), survey presale interest by EU region to forecast geographic concentration. If >40% of presale interest is in distant markets, negotiate split logistics model (buffer in Central Europe for local delivery, direct from Tallinn for Northern Europe) by Month 7 (2027-05-08). Lock in freight pricing with carriers by Month 1.5 (2026-11-23). Monitor inventory days outstanding weekly starting Month 7 (2027-05-08); if turnover falls below 1.2x per month or average lead time exceeds 3.5 weeks, trigger review of buffer sizing or logistics provider performance.

# Distill Assumptions
# Faraday Enclosure Product Plan

## Project Overview

Single-SKU rigid folded-aluminium/steel Faraday enclosure for common laptops and phones. Manufacturing based in Tallinn, Estonia, leveraging low-cost ISO-certified precision-metal ecosystem. Self-funded with €750k capital in two stages: €400k Year-1, €350k conditional on positive cash flow.

## Year-1 Budget Allocation

- Design and prototyping: €70k
- In-house rig: €40k
- Accredited lab testing: €15k
- Soft tooling: €20k
- Production batch: €150–200k
- Marketing: €75k
- Reserve: €20k

## Design and Validation

- EMC consultancy (€20–25k, milestone-based) provides RF design guidance
- University partnership supplies in-house rig and measurement access; milestone agreements locked by Month 0.5 (2026-10-23) with penalty clauses and backup hiring plan
- If university partnership fails by Month 1.5 (2026-11-23), part-time RF engineer hired immediately
- Redesign reserve may increase from €20k to €30k if accredited lab testing reveals major rework
- Accredited lab validation report targeted for Month 5 (2027-03-08); report published with every unit sold as public credibility basis
- Gate measurement convention published upfront; founder and external advisor sign off by Month 12.5 (2027-10-23)

## Compliance and Legal

- Legal opinion commissioned by Month 1 (2026-11-08) to verify General Product Safety Directive applicability (not verified)
- No voluntary CE marking or additional certification pursued in Year-1
- Product liability insurance (€250–500k estimate) obtained; insurability of Faraday claims to be clarified during Year-1
- Scope statement: 'Protects stored spare devices against RF exposure; does not protect active equipment or prevent grid-scale events'
- Marketing claims strictly limited to measured shielding attenuation across tested frequency band

## Hard Tooling Gate

Hard tooling released only after presale deposits reach €80–120k (proposed threshold) and pre-test results confirm design readiness. If presale deposits lag, hard-tooling release slips, compressing production/fulfillment before cash-flow gate at Month 12 (2027-10-08).

## Presale Strategy

- Target: €80–120k deposits by Month 6 (2027-04-08) to trigger hard-tooling release
- Presale cutoff date established (e.g., Month 8 = 2027-06-08) to ensure early-order fulfillment before gate measurement
- Parallel segment outreach to preppers (40–50% deposit rate, €50–70 average order value), infrastructure (30–40%, €200–300+), and privacy/forensics (35–45%, €80–150)
- Data-driven pivots if prepper volume dominates (>70%) by Month 4 (2027-02-08)
- Fast-track pilot agreement with 1–2 infrastructure buyers by Month 3 (2027-01-08); pilot units at cost + 20%, delivery Month 5 (2027-03-08)
- Presale SLA with delivery timeline documented by Month 1 (2026-11-08) to manage customer expectations and reduce refund risk
- Presale geographic survey by Month 2 (2026-12-08) to forecast freight cost impact (€8–15 per unit) and buffer-stock location

## Production and Fulfillment

- Build-to-order fulfillment with 2–3 week lead times; no buffer inventory until presale volume proven
- First production batch committed by Month 6 (2027-04-08) if presale thresholds met
- Buffer inventory (200–300 units) contracted with EU logistics provider only if presale conversion reaches 60% and average order value exceeds €80 by Month 5 (2027-03-08)
- Inventory turnover target: 1.5x per month (30–40 day cycle estimate)

## Cash Flow and Operations

- Positive cash flow measured on trailing-quarter delivered-unit revenue only, excluding presale deposits; threshold approximately €25–30k quarterly
- Monthly cash tracking and decision gate at Month 5 (2027-03-08) to either commit tooling or pivot marketing if presale momentum weak
- Founder-led with part-time operations added Month 6 (2027-04-08) if presale volume warrants
- Quarterly Tallinn supplier visits by founder

## Environmental and Supply Chain

- Lifecycle assessment or carbon footprint estimate commissioned by Month 3 (2027-01-08) (~€2–5k estimate)
- Material sourcing and supplier ESG compliance documented in supply-chain transparency sheet by Month 3 (2027-01-08)

## Market Positioning

Multi-use RF-isolation positioning (disaster prep, privacy, key-fob security, forensics) widens addressable market beyond preppers.

# Review Assumptions
# Carrington Event Prep - Expert Review

## Domain of Review
Hardware product development and venture capital management, specializing in capital-constrained early-stage hardware startups with staged funding and demand-gated design commitments.

## Issue 1: Missing Accredited Lab Standard Selection and Cost Confirmation Before Design Freeze

The plan assumes single accredited EMC lab validation using an applicable standard (proposed IEEE 299.1, not verified). No pre-engagement consultation is documented; chosen standard, frequency range, attenuation threshold, cost (budget: €15k estimate), and timeline (target: Month 5 = 2027-03-08) are not confirmed with an actual lab. Lab recommendation for MIL-STD-285 or higher-cost variant could cause €10–20k overruns (estimate) and 4–8 week timeline slips (estimate), compressing redesign buffer and presale window. Failed lab test after soft tooling commitment forces costly re-qualification (€8–15k per run estimate) and delays revenue past cash-flow gate measurement window.

### Recommendation

By Month 0.5 (2026-10-23), contact 2–3 accredited labs (Germany, Sweden, Netherlands, or Estonia) for no-cost pre-engagement consultation documenting applicable standard, test methodology, frequency range, cost (locked), timeline (committed report by Month 5 = 2027-03-08), and design-readiness review scope. Select lab based on cost predictability and timeline alignment. Request design-readiness review (€2–3k estimate) before sample submission (Month 4 = 2027-02-08) for test-readiness confirmation and attenuation feedback. Lock cost and timeline in statement of work by Month 1.5 (2026-11-23). If lab cannot commit by Month 5 (2027-03-08), identify secondary lab immediately. Reserve additional €10k (increase redesign reserve from €20k to €30k) for one re-test if initial results fall short.

### Sensitivity

Baseline lab cost: €15k, timeline: 6 weeks (Month 4–5 = 2027-02-08 to 2027-03-08). If lab cost exceeds budget by 50% (€7.5k overrun), Year-1 testing/design spend rises to €77k, reducing production batch budget from €150–200k to €142–192k and risking unit-cost inflation. If lab report delays from Month 5 (2027-03-08) to Month 7 (2027-05-08) (2-month slip), presale fulfillment window compresses from 3 months to 1 month before cash-flow gate (Month 12 = 2027-10-08), increasing delivery-fail risk and refund exposure by 20–30% (estimate). Second lab run (€12k additional) after redesign would reduce Year-1 discretionary spend to €65k and push decision gate to Month 6.5 (2027-04-23), requiring hard-tooling commit on presale deposits alone with no design-confirmation buffer.

## Issue 2: Missing Definition of 'Positive Cash Flow' and Presale-Deposit Accounting

The plan states €350k follow-on is conditional on positive cash flow but does not define what counts as cash flow (delivered-unit revenue only, or including presale deposits?), threshold (proposed €25–30k quarterly estimate), or measurement window (end of Year-1 Q4). Presale deposits are refundable; news-cycle shift could spike refund requests (20–30% estimate), consuming deposits counted as cash. If presale deposits are treated as 'cash flow' in loose accounting, €350k follow-on is released before fulfillment obligations are met; fulfillment slips then force spend of follow-on cash on operations, leaving company underfunded for inventory replenishment. If gate rule is not documented before launch, founder and advisors may dispute result at Month 12 (2027-10-08), delaying decision and creating governance ambiguity.

### Recommendation

By Month 0.5 (2026-10-23), draft and publish written cash-flow gate measurement convention before launch. Define: 'Positive cash flow is measured on trailing-quarter operating revenue from delivered units only, excluding presale deposits. Threshold: cumulative quarterly surplus of €25–30k by Month 12 (2027-10-08). Presale deposits are classified as liabilities and held in separate earmarked account; may not be used for operational spending and are ring-fenced for fulfillment only.' Publish convention in all presale terms and marketing so stakeholders understand gate logic. Establish governance: founder + one external advisor (accountant or experienced mentor) measure and sign off by Month 12.5 (2027-10-23). If result falls between -€5k and +€25k (ambiguous), establish tiebreaker rule (e.g., founder retains discretion to extend runway 90 days and re-measure, or tranche released on advisor recommendation). Track presale deposits, refund rate, and operating revenue separately in monthly cash dashboard shared with advisor.

### Sensitivity

Baseline threshold: €25–30k quarterly operating surplus. If presale refund rate climbs to 25% (vs. 15% baseline estimate) due to delivery delays, operating cash flow falls by €20–40k (for €150k presale base), potentially missing gate by €5–15k. If delivery-window cutoff is not established, orders placed in Month 9–10 (2027-07-08 to 2027-08-08) may not be delivered until Month 11–12 (2027-09-08 to 2027-10-08) or later, causing gate measurement to miss in-time revenue by €10–30k (estimate for 100–300 units at €60–80 margin). If presale deposits are loosely counted as cash flow, €120k deposit inflow is treated as positive cash flow, triggering €350k release prematurely; then €30–40k of refunds and fulfillment costs consume cash without revenue offset, leaving Year-2 underfunded.

## Issue 3: Missing Demand Validation Plan if Presale Deposits Skew Toward Low-Margin Prepper Units

The plan assumes parallel presale outreach to preppers (€50–70 AOV, 40–50% deposit rate estimate), infrastructure buyers (€200–300+ AOV, 30–40% rate estimate), and privacy/forensics (€80–150 AOV, 35–45% rate estimate). No contingency is documented if prepper conversion dominates (70–80% of total deposits estimate) while infrastructure pilots move slowly (8–12 week cycles, possibly extending past Year-1). Result: high unit volume (3000–4000 prepper units at €10–20 margin estimate) but low cash flow (€60–80k Year-1 estimate), compared to 100–200 infrastructure units at €60–120 margin (€8–24k Year-1 estimate). Cumulative cash flow may fall short of €25–30k quarterly gate threshold even if presale volume appears healthy. Infrastructure revenue arriving in Month 9–12 (2027-07-08 to 2027-10-08) may not be invoiced and paid in time to count toward gate measurement, leaving cash-flow gate dependent entirely on prepper margin, which is insufficient.

### Recommendation

By Month 1.5 (2026-11-23), establish separate presale campaigns and tracking for each buyer segment (prepper networks, infrastructure, privacy/forensics) with distinct messaging and contact lists. Track deposit velocity, deposit rate, average order value, and estimated gross margin by segment weekly starting Month 1 (2026-11-08). By Month 3 (2027-01-08), measure which segment is dominating deposits; if prepper segment exceeds 70% of total, trigger immediate pivot: increase marketing spend and presale focus on infrastructure and privacy segments by reallocating €10–15k from prepper channels. Establish 'fast-track' pilot agreement with 1–2 infrastructure buyers by Month 3 (2027-01-08)—pilot units at cost plus 20% (estimate), delivery by Month 5 (2027-03-08)—to generate in-time revenue and reference status. If infrastructure orders do not close by Month 6 (2027-04-08), widen multi-use RF-isolation narrative (privacy, travel security, key-fob protection) in marketing to attract higher-value corporate IT and digital-forensics buyers. Set presale cutoff date (Month 8 = 2027-06-08) after which new orders defer to post-gate window, ensuring early-order fulfillment and cash receipt before Month 12 (2027-10-08) gate measurement.

### Sensitivity

Baseline: 40% prepper, 30% infrastructure, 30% privacy/forensics by deposit mix. If prepper mix climbs to 75% by Month 4 (2027-02-08), cumulative presale deposits of €120k imply: ~€60k prepper (3000 units × €20 avg margin), ~€30k infrastructure (100 units × €100 avg margin), ~€30k privacy (250 units × €50 avg margin) = ~€120k total presale. Delivered-unit cash flow Year-1 (Month 6–12 = 2027-04-08 to 2027-10-08): prepper fulfillment (2000 units delivered by Month 12 = 2027-10-08) = €40k, infrastructure (50 units) = €5k, privacy (150 units) = €7.5k = ~€52.5k total. If infrastructure delivery slips to Month 13+, cash flow falls to ~€47.5k, still meeting €25–30k gate. But if delivery lead times slip to 4 weeks and presale cutoff is Month 8 (2027-06-08), only orders from Month 1–8 (2026-11-08 to 2027-06-08) are fulfilled by Month 12 (2027-10-08); orders from Month 9–10 (2027-07-08 to 2027-08-08) deliver in Month 13+, missing gate. Presale volume concentrated in Month 7–10 (2027-05-08 to 2027-08-08) due to marketing ramp can cause gate miss entirely.

## Review Conclusion

Carrington Event Prep faces three critical missing assumptions that could derail the capital-constrained €750k launch. First, accredited lab selection and cost confirmation are deferred; higher-cost standard or timeline slip (€10–20k overrun, 2–4 week delay estimate) compresses redesign buffer and presale window, risking sunk tooling cost if lab results fail. Second, cash-flow gate measurement rule is not defined: presale deposits are refundable and may obscure weak underlying unit profitability, and loose accounting definition could release €350k follow-on before fulfillment is proven, leaving Year-2 underfunded. Third, demand validation lacks contingency for prepper-heavy presales (70–80% of deposits) with insufficient infrastructure volume to support positive cash flow; infrastructure sales cycles (8–12 weeks) may extend past Year-1, leaving gate dependent on thin prepper margins. All three issues interact: vague gate definition masks demand-mix risk, while lab delays compress window to prove both design and demand before hard tooling locks in.

Mitigation: lock lab selection and cost by Month 0.5 (2026-10-23); publish gate measurement convention upfront; run parallel segment presale campaigns with weekly tracking and contingency pivots if prepper conversion exceeds 70% by Month 3 (2027-01-08). Establish presale cutoff date (Month 8 = 2027-06-08) to ensure early-order fulfillment before gate measurement, and negotiate infrastructure fast-track pilots by Month 3 (2027-01-08) to bring revenue in-time.