## Positive Constraints

- Project: Carrington Event Prep – design, certify, and distribute a Faraday enclosure for phones and laptops
- Total funding of €750k, self-funded by the user
- Two-stage funding: €400k Year-1 burn
- €350k follow-on funding conditional on positive cash flow
- Single-SKU product
- Manufacturing anchored in Tallinn, Estonia
- Exploit Tallinn's low-cost, ISO-certified precision-metal ecosystem
- Pre-sell the product to European prepping networks
- Pre-sell the product to critical-infrastructure buyers
- Product must be certified
- Project start ASAP (Month 0 = 2026-10-08)
- Use month offsets (e.g., Month 3 = 2027-01-08) for time references; do not write calendar dates
- Mark figures that are not user constraints or established benchmarks as estimates or proposed thresholds
- Write in impersonal planning-document voice

## Negative Constraints

- Defer server-grade cages until market traction and sustainable cash flow are proven
- Do not offer more than one SKU
- Do not present invented numbers as facts
- Do not turn example values from input documents (e.g. ...) into requirements
- Do not refer to yourself or your own process (no 'I', 'my knowledge', etc.)
- Do not write calendar dates
