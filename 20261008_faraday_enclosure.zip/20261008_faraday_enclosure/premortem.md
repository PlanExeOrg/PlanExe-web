A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | An accredited lab will accept IEEE 299.1 or equivalent (not verified), at the EUR 15k cap, with a report by Month 5 (2027-03-08), and the design will pass first time. | Hold calls with 2-3 accredited EMC labs by Month 0.5 (2026-10-23). Get written confirmation of standard, frequency band, fixed price, re-test terms and report date. | Any lab requires a costlier standard, quotes above EUR 20k (estimate), or cannot commit to a report by Month 6 (2027-04-08). |
| A2 | The multi-use RF-isolation story will draw enough non-prepper buyers at a realised price of EUR 120 or more per unit to hold the EUR 67 contribution (estimate) and pass the EUR 25k gate. | Launch three segment landing pages by Month 1 (2026-11-08). Run 10-15 buyer interviews per segment and track deposits, average price and refunds weekly. | By Month 3 (2027-01-08), prepper deposits exceed 70% of total, or realised average price is below EUR 120, or conversion is below 40% (proposed thresholds). |
| A3 | Tallinn fabricators and gasket suppliers will hold EUR 70 unit cost (estimate) and deliver capacity on time, so 1,500 units ship by Month 12 (2027-10-08) within the zero-headroom production line. | Obtain fixed-price written quotes from 2-3 Tallinn fabricators and 2 gasket suppliers by Month 1 (2026-11-08). Run a 50-100 unit trial batch with a secondary fabricator by Month 2 (2026-12-08). | Quotes imply unit cost above EUR 77 (estimate), lead times above 3 weeks, or no capacity reservation for 800 units. |
| A4 | The EMC Directive does not apply and no CE marking is needed, and product-liability insurance covering RF-shielding claims is obtainable at a premium that fits inside the EUR 75k marketing/sales/operations line. | Commission the legal opinion and request quotes from 2-3 insurers by Month 1 (2026-11-08). Ask each insurer in writing whether shielding-performance claims are covered or excluded. | Counsel says CE or notified-body work is required (+10-30k, estimate), or every insurer excludes shielding claims, or the premium exceeds EUR 15k per year (proposed threshold). |
| A5 | The founder, with part-time and contract support, can run design, lab, Tallinn suppliers, presale and cash governance in parallel without critical-path slips, and the university and consultancy deliver on commercial timelines. | By Month 0.5 (2026-10-23), obtain signed milestone agreements with penalty clauses from the EMC consultancy and TalTech, including IP terms. Map founder hours per week against the Month 0-6 (2026-10-08 to 2027-04-08) critical path. | No signed university agreement by Month 1.5 (2026-11-23), IP terms unresolved, or founder workload exceeds 50 hours per week (proposed threshold) in the plan. |
| A6 | Buyers will accept the honest scope statement (stored spare devices only) and the 15% refund cap will hold, so published, narrow claims do not suppress conversion or trigger trust damage after a news cycle or incident. | Show the exact scope statement and conditional-gate wording to 10-15 buyers per segment in interviews by Month 1 (2026-11-08). Test two landing-page variants, with and without prominent scope text. | Presale conversion drops by 25% or more (proposed threshold) with prominent scope text, or over 30% of interviewees say the scope makes the product not worth buying. |
| A7 | The 160k production line and 0k headroom can absorb the working-capital strain of building 800 units for batch 1 before delivered receipts arrive, without ring-fenced deposits paying unit cost. | Build a month-by-month cash model for Months 5-12 (2027-03-08 to 2027-10-08) with deposits excluded. Agree supplier payment terms with the Tallinn fabricator by Month 1 (2026-11-08). | The model shows cumulative gross Year-1 outlay above EUR 400k (user constraint), or the fabricator requires payment upfront for more than 50% (proposed threshold) of batch 1. |
| A8 | The seam and gasket design will keep its measured attenuation after repeated lid cycles and across production units, so the one accredited report stays valid for every unit sold. | Cycle three prototype lids 500 times (estimate) on the in-house rig by Month 3 (2027-01-08). Re-measure attenuation at 50 MHz, 100 MHz, 500 MHz and 1 GHz after set intervals. | Attenuation drops by more than 6 dB (proposed threshold) after cycling, or unit-to-unit variation in the trial batch exceeds 5 dB (proposed threshold). |
| A9 | Competitors, including established Faraday brands and retailer private labels, will not undercut the EUR 149 list price (estimate) or outspend the venture on community reach during Year-1. | By Month 1 (2026-11-08), catalogue EU prices, published test data and delivery times of at least 8 (proposed threshold) competing products. Buy two for benchmark measurement on the rig. | Two or more comparable products with published test data sell at or below EUR 110 (proposed threshold) in the EU, or buyers in interviews name a cheaper alternative as sufficient. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Reserve That Evaporated | Process/Financial | A1 | Founder (with EMC consultancy lead) | CRITICAL (15/25) |
| FM2 | The Seam That Would Not Seal | Technical/Logistical | A3 | Supply Chain & Manufacturing Coordinator | HIGH (12/25) |
| FM3 | The Prepper Crowd That Paid Too Little | Market/Human | A2 | Presale & Demand Validation Manager | CRITICAL (20/25) |
| FM4 | The Unfunded Stamp | Process/Financial | A4 | Regulatory Compliance & Legal Advisor | HIGH (12/25) |
| FM5 | The Rig That Never Calibrated | Technical/Logistical | A5 | RF & Electromagnetic Shielding Engineer (EMC consultancy lead) | CRITICAL (16/25) |
| FM6 | The Fine Print That Killed the Pitch | Market/Human | A6 | Presale & Demand Validation Manager | HIGH (12/25) |
| FM7 | The Batch That Ate the Runway | Process/Financial | A7 | Financial Management & Cash-Flow Governance Officer | CRITICAL (15/25) |
| FM8 | The Gasket That Wore Thin | Technical/Logistical | A8 | RF & Electromagnetic Shielding Engineer | CRITICAL (15/25) |
| FM9 | The Cheaper Cage Next Door | Market/Human | A9 | Presale & Demand Validation Manager | HIGH (12/25) |


### Failure Modes

#### FM1 - The Reserve That Evaporated

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Founder (with EMC consultancy lead)
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- No signed lab statement of work, so cost and standard are unconfirmed.
- A costlier standard (+10-20k, estimate) plus a re-test (8-15k, estimate) reaches up to 35k against the 20k reserve.
- Production headroom is 0k, so the 15k gap has no funding source.
- Report slips to about Month 7 (2027-05-08). Tooling and batch 1 slip, and deposits drift into refunds.
- The 90-day gate extension is likely.

##### Early Warning Signs
- No signed lab statement of work by Month 1.5 (2026-11-23)
- Lab quote above EUR 15k at pre-engagement
- In-house rig results differ by more than 5% between the two seam cycles
- Design-readiness review flags attenuation shortfall in any claimed band

##### Tripwires
- Lab quote >= EUR 20k (estimate)
- Report date committed later than Month 6 (2027-04-08)
- Redesign reserve drawn >= EUR 8k before Month 5 (2027-03-08)

##### Response Playbook
- Contain: Freeze all discretionary spend and hold hard tooling and batch-1 commitments until a revised lab date is signed.
- Assess: Within 5 business days, cost the worst case (standard change plus re-test) against the reserve and name a funding source for any gap.
- Respond: Raise the reserve to 30k by cutting marketing 10k, switch to the pre-qualified backup lab, or narrow claims to the tested band, and notify presale customers of the new dates.


**STOP RULE:** Cancel or pivot if the unfunded lab and redesign gap exceeds EUR 15k (estimate) and no funding decision is signed by Month 6 (2027-04-08).

---

#### FM2 - The Seam That Would Not Seal

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A3
- **Owner**: Supply Chain & Manufacturing Coordinator
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Fabricator quotes land above the EUR 70 unit-cost assumption (estimate).
- Gasket lots vary or arrive 2-4 weeks late (estimate).
- Seam compression and flatness vary between batches, so the production unit differs from the tested sample.
- Batch 1 slips past Month 8 (2027-06-08).
- Delivered revenue falls out of the gate window, and refunds follow.

##### Early Warning Signs
- Trial-batch tolerance outside +/-0.1 mm (estimate)
- Gasket lead time quoted above 3 weeks
- Fabricator price revision requested before contract signature
- Seam attenuation drops after repeated lid cycles on the rig

##### Tripwires
- Unit cost quote >= EUR 77 (estimate)
- Trial-batch reject rate >= 5%
- Gasket delivery late by >= 14 days

##### Response Playbook
- Contain: Stop releasing further production orders to the failing source and quarantine out-of-tolerance units and gasket lots.
- Assess: Within 5 business days, run the secondary fabricator's trial parts and gasket lots through the rig and recompute unit cost and delivery dates.
- Respond: Activate the secondary fabricator and backup gasket supplier, re-sequence batch 1, and update presale customers on revised delivery dates.


**STOP RULE:** Pivot sourcing or cancel if no qualified fabricator can deliver 800 units at or below EUR 85 unit cost (estimate) by Month 7 (2027-05-08).

---

#### FM3 - The Prepper Crowd That Paid Too Little

- **Archetype**: Market/Human
- **Root Cause**: Assumption A2
- **Owner**: Presale & Demand Validation Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- Carrington media attention draws price-sensitive preppers who dominate early deposits.
- Forensics, privacy and infrastructure buyers are slow or unconvinced.
- Realised margin falls toward EUR 15 per unit (estimate), so a 750-unit quarter yields -8.75k.
- Messaging split across segments dilutes the brand.
- The news cycle fades and refunds rise.
- The gate fails and the 350k tranche is withheld.

##### Early Warning Signs
- Prepper share of deposits rising week over week
- Infrastructure pilots unsigned by Month 3 (2027-01-08)
- Average realised price drifting below EUR 120
- Refund requests citing scope or fit

##### Tripwires
- Prepper deposits > 70% of total at Month 3 (2027-01-08)
- Presale conversion < 40% at Month 3 (2027-01-08)
- Average realised price < EUR 120 (proposed threshold)

##### Response Playbook
- Contain: Halt spend on the prepper channel and pause new presale price promotions.
- Assess: Within 5 business days, recompute margin and gate arithmetic by segment using weekly deposit, price and refund data.
- Respond: Reallocate EUR 10-15k to infrastructure and privacy segments, close the fast-track pilots, and extend presale to Month 8 (2027-06-08) at most with no hard tooling.


**STOP RULE:** Withhold hard tooling and review wind-down if net deposits are below EUR 80k at Month 8 (2027-06-08).

---

#### FM4 - The Unfunded Stamp

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Regulatory Compliance & Legal Advisor
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Legal opinion finds the EMC Directive applies (not verified).
- CE or notified-body work costs 10-30k (estimate) and adds 8-12 weeks.
- Production headroom is 0k and the 20k reserve is earmarked for redesign.
- Month 6 (2027-04-08) tooling date is missed.
- Insurers exclude shielding claims, leaving liability uninsured.
- Presale launch is delayed or claims are narrowed.

##### Early Warning Signs
- Legal opinion not delivered by Month 1 (2026-11-08)
- Counsel flags EMC Directive as probably applicable
- Insurer quote carries an RF-claim exclusion
- Premium quote above EUR 15k per year (proposed threshold)

##### Tripwires
- Estimated CE cost >= EUR 10k (estimate)
- Insurance terms not locked by Month 2.5 (2026-12-23)
- Compliance delay >= 8 weeks

##### Response Playbook
- Contain: Pause presale launch and hard-tooling commitments until the legal opinion and insurance terms are in writing.
- Assess: Within 5 business days, cost CE scope and premium against the 75k operations line and the 20k reserve, and name the funding source.
- Respond: Fund CE from the reserve and a marketing cut, or defer launch claims to a narrower scope, and reset the schedule with presale customers informed.


**STOP RULE:** Pivot or cancel if CE and insurance gaps exceed EUR 30k (estimate) with no signed funding decision by Month 3 (2027-01-08).

---

#### FM5 - The Rig That Never Calibrated

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: RF & Electromagnetic Shielding Engineer (EMC consultancy lead)
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- University agreement stalls on IP or scheduling.
- In-house rig is built late or reads inconsistently.
- Two independent seam cycles are not finished by Month 3 (2027-01-08).
- Design-readiness review slips past Month 4 (2027-02-08).
- Founder overload delays supplier and lab coordination.
- Lab submission slides and the report misses Month 6 (2027-04-08).

##### Early Warning Signs
- Rig not validated against reference shields by Month 2.5 (2026-12-23)
- University IP terms unsigned at Month 1.5 (2026-11-23)
- Rig readings vary between runs
- Founder missing weekly status calls

##### Tripwires
- Rig validation incomplete at Month 3 (2027-01-08)
- Run-to-run attenuation variance > 5% (proposed threshold)
- Milestone slip >= 3 weeks

##### Response Playbook
- Contain: Stop adding design changes and freeze the current prototype geometry for rig re-calibration.
- Assess: Within 5 business days, compare rig readings with a reference shield and list which milestones depend on the university.
- Respond: Hire the part-time RF engineer fallback, move measurements to a rented chamber, and reset lab submission with the backup date.


**STOP RULE:** Pivot to an accredited-lab-only iteration path or cancel if no validated rig data exist by Month 4 (2027-02-08).

---

#### FM6 - The Fine Print That Killed the Pitch

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Presale & Demand Validation Manager
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Buyers read the scope statement as admitting the product does not protect against a real event.
- Conversion falls once scope and conditional-gate wording are prominent.
- Forum critics frame the narrow claim as a weak product.
- Refunds rise above the 15% cap as the news cycle fades.
- Deposits fall short of 80k and tooling is not released.

##### Early Warning Signs
- Landing page with scope text converts far below the variant without it
- Forum threads questioning real-event value
- Refund reasons citing scope mismatch
- Deposit velocity falling week over week

##### Tripwires
- Cumulative refunds > 15% of deposits by Month 8 (2027-06-08)
- Conversion down >= 25% on scope-prominent page (proposed threshold)
- Net deposits < EUR 50k at Month 4 (2027-02-08) (proposed threshold)

##### Response Playbook
- Contain: Freeze new claim wording changes and pause forum campaigns that invite real-event comparisons.
- Assess: Within 5 business days, code refund and complaint reasons by segment and compare conversion across scope-text variants.
- Respond: Reframe around measured RF isolation for forensics and privacy, keep the scope statement unchanged, and offer refunds to affected presale buyers.


**STOP RULE:** Review wind-down if net deposits are below EUR 80k at Month 8 (2027-06-08) (proposed threshold).

---

#### FM7 - The Batch That Ate the Runway

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Financial Management & Cash-Flow Governance Officer
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Batch 1 (800 units) is program-financed while deposits stay ring-fenced.
- Fabricator and gasket payments fall due weeks before delivered receipts.
- Zero production headroom leaves no buffer for price rises or late shipments.
- Reserve is drawn to cover timing gaps and then lab or redesign costs.
- Gross outlay approaches the EUR 400k cap before the gate window opens.
- Tranche timing and batch 2 are put at risk.

##### Early Warning Signs
- Supplier terms require more than 50% payment upfront
- Cash model shows negative free cash before Month 9 (2027-07-08)
- Reserve drawn for non-redesign items
- Unit quotes above EUR 70 (estimate)

##### Tripwires
- Cumulative outlay >= EUR 340k (proposed threshold) before Month 9 (2027-07-08)
- Redesign reserve drawn >= EUR 10k for non-lab items
- Supplier upfront payment demand >= 50%

##### Response Playbook
- Contain: Freeze new purchase orders and marketing commitments, and hold batch 2 until cash position is reconciled.
- Assess: Within 5 business days, rebuild the weekly cash model with actual invoices and name the peak funding gap.
- Respond: Split batch 1 into smaller releases, renegotiate payment terms, or decide in writing whether deposits may fund matching unit cost.


**STOP RULE:** Cancel or pivot if projected gross Year-1 outlay exceeds EUR 400k (user constraint) with no signed decision to resize batch 1 by Month 7 (2027-05-08).

---

#### FM8 - The Gasket That Wore Thin

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: RF & Electromagnetic Shielding Engineer
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Gasket compression set and lid flatness drift with repeated opening.
- Production units differ from the tested sample.
- Attenuation falls in the lower bands after weeks of use.
- Published report no longer matches delivered units.
- Returns, warranty claims and claim-substantiation exposure follow.
- Re-qualification costs land after hard tooling is committed.

##### Early Warning Signs
- Rig attenuation falls between lid-cycle checkpoints
- Gasket lots show varying compression force
- Trial batch flatness outside tolerance
- Spot tests on shipped units differ from report

##### Tripwires
- Attenuation drop > 6 dB after cycling (proposed threshold)
- Unit-to-unit variation > 5 dB (proposed threshold)
- Spot-test failures >= 3% of sampled units (proposed threshold)

##### Response Playbook
- Contain: Stop shipping units from the affected lot and quarantine remaining stock and gasket lots.
- Assess: Within 5 business days, re-measure a sample of 20 units (estimate) on the rig and compare them with the accredited report.
- Respond: Change gasket material or compression spec, re-qualify with the lab within the reserve, and issue corrected claims to affected buyers.


**STOP RULE:** Halt sales and review cancellation if shipped units cannot hold the published attenuation within 6 dB after one design correction by Month 9 (2027-07-08).

---

#### FM9 - The Cheaper Cage Next Door

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Presale & Demand Validation Manager
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Established brands or retailer private labels offer similar products at lower prices.
- Community influencers favour incumbents with a track record.
- Realised price is pushed below the EUR 120 halt threshold.
- Contribution margin shrinks toward the EUR 15 downside case.
- Deposit velocity slows and refunds rise.
- Gate headroom of 5.25k disappears.

##### Early Warning Signs
- Competitor listings under EUR 110 (proposed threshold)
- Forum threads recommending rivals
- Discount requests from pilot buyers
- Falling deposit velocity week over week

##### Tripwires
- Realised average price < EUR 120 (proposed threshold)
- Two competing products <= EUR 110 (proposed threshold)
- Presale conversion < 40% at Month 3 (2027-01-08)

##### Response Playbook
- Contain: Stop price discounts and pause paid campaigns that compare price directly with rivals.
- Assess: Within 5 business days, compare competitor data sheets and prices with the accredited report and recompute segment margin.
- Respond: Shift emphasis to published test data and Tallinn origin, target forensics and infrastructure buyers, and test a services add-on such as re-verification.


**STOP RULE:** Withhold hard tooling and review wind-down if net deposits are below EUR 80k at Month 8 (2027-06-08) (proposed threshold).
