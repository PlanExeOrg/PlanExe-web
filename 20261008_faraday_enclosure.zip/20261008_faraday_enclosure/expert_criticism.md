# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Product-Liability, EU Compliance & Claim Substantiation Counsel

**Knowledge**: EU product-safety directives (EMC Directive 2014/30/EU, General Product Safety Directive 2001/95/EC), Faraday enclosure regulatory classification (not verified in plan), product-liability insurance (insurability of RF shielding claims), consumer-law claim exposure, warranty and scope-limitation language

**Why**: The plan's claim scope (stored spare devices only) and proof standard (one accredited lab report published with every unit) are the bulwark against consumer-law and liability exposure, but applicable EU rules and insurability are not verified. This expert delivers a legal opinion by Month 1 (2026-11-08) on whether EMC Directive or CE marking applies, drafts claim-scope language and fit-guide disclaimers before presale launch, and locks product-liability insurance terms (EUR 250-500k, insurability not verified) by Month 2.5 (2026-12-23). A 10-30k unfunded CE requirement or uninsurable claims would breach the Year-1 budget and jeopardize the launch.

**What**: Commission and deliver a legal opinion on EMC Directive applicability, General Product Safety Directive scope, CE marking requirement, and liability exposure under EU consumer-protection law by Month 1 (2026-11-08). Draft claim-scope language limiting marketing to measured attenuation and tested frequency range. Obtain a product-liability insurance quote and lock terms by Month 2.5 (2026-12-23). Review all presale marketing, fit guide and warranty terms for compliance.

**Skills**: EU product regulatory law, product-liability insurance negotiation, consumer-protection compliance, claim substantiation and evidence requirements, warranty and disclaimer drafting, notified-body assessment process

**Search**: EU EMC Directive Faraday enclosure, CE marking requirements RF shielding, product liability insurance electromagnetic, EU consumer law warranty claims

## 1.1 Primary Actions

- By Month 0.5 (2026-10-23 14:00), publish a written cash-flow gate measurement convention stating: 'Positive cash flow = trailing-quarter operating revenue from delivered units only, excluding presale deposits. Deposits remain liabilities. Threshold ≥ EUR 25k. Measured by Month 12.5 (2027-10-23). Tiebreak rule: founder + external advisor sign off jointly, decision published within 5 business days.' Define presale cutoff at Month 8 (2027-06-08) to ensure fulfillment completes before gate measurement (Months 9–12 = 2027-07-08 to 2027-10-08).
- By Month 0.5 (2026-10-23 08:00), contact 2–3 accredited EMC laboratories (Germany, Sweden, Netherlands, Estonia) for no-cost pre-engagement consultation confirming applicable standard (IEEE 299.1 or alternative), frequency range (100 kHz–1 GHz), fixed cost (EUR 15k cap; identify overrun trigger), and report delivery date (Month 5 = 2027-03-08, latest Month 6 = 2027-04-08). By Month 1.5 (2026-11-23 17:00), sign a statement of work with chosen lab specifying cost, timeline, retest provision, and penalty for slip. Pre-qualify a secondary lab by Month 2 (2026-12-08) as fallback.
- By Month 1 (2026-11-08 09:00), establish three separate presale campaign channels (Prepper Networks, Infrastructure Buyers, Privacy/Forensics) with distinct landing pages and weekly segment tracking. By Month 3 (2027-01-08 16:00), publish a weekly deposit tracker by segment (count, value, refund rate). If Prepper deposits exceed 70% of total, immediately reallocate EUR 10–15k from Prepper to Infrastructure and Privacy marketing. Negotiate 1–2 fast-track infrastructure pilots (10–20 units, EUR 84/unit, delivery Month 5 = 2027-03-08) by Month 3 (2027-01-08 12:00).
- By Month 1 (2026-11-08 17:00), commission a legal opinion on EU product-safety applicability (EMC Directive 2014/30/EU, General Product Safety Directive 2001/95/EC) confirming whether CE marking or notified-body assessment is required. Draft scope-limitation language for marketing: 'Protects stored spare devices only. Does not protect active grid-connected equipment or guarantee protection in an actual electromagnetic event.' Lock product-liability insurance (EUR 250–500k coverage) terms by Month 2.5 (2026-12-23 15:00).
- By Month 0.5 (2026-10-23 10:00), create a detailed monthly Year-1 budget spend plan allocating EUR 400k (Months 0–2 = 2026-10-08 to 2026-12-08: EUR 110k design/rig; Months 2–5 = 2026-12-08 to 2027-03-08: EUR 35k lab/soft tooling; Months 5–12 = 2027-03-08 to 2027-10-08: EUR 255k production/marketing/reserve). Hold all hard-tooling spend uncommitted until both conditions are met: presale deposits ≥ EUR 80k AND accredited lab pre-test results confirm design readiness (Month 5 = 2027-03-08). Establish monthly cash-burn reviews at Months 5 and 8 (2027-03-08 and 2027-06-08); if spend exceeds plan >10%, freeze discretionary spending pending review.
- By Month 1 (2026-11-08 12:00), pre-qualify a secondary precision-metal fabricator in Tallinn/Estonia with ISO certification and laser/CNC capability. Conduct a trial batch (50–100 units) by Month 2 (2026-12-08 14:00) testing laser-cut accuracy (±0.1 mm). Lock primary-supplier pricing and capacity (Year-1 batches, cost caps ±10%, 30-day notice for changes) in a signed agreement by Month 1 (2026-11-08 15:00). Identify conductive-gasket suppliers (primary + backup) by Month 1.5 (2026-11-23 16:00) and hold 30-day buffer stock (EUR 5–10k inventory) before production release.

## 1.2 Secondary Actions

- By Month 1 (2026-11-08 11:00), draft and publish presale terms covering order placement, refund policy (30-day money-back for fit/quality issues, 10-business-day refund processing), delivery SLA (ships 2–3 weeks of confirmation, 4–5 week estimated delivery), and escalation path (48-hour response target). Publish a detailed Product Fit Guide (photographs, internal dimensions 420 × 280 × 50 mm estimate, laptop/phone compatibility examples, explicit 'Does Not Fit' examples) by Month 1.5 (2026-11-23 13:00). Link presale terms and fit guide on all presale landing pages and in packaging.
- By Month 4 (2027-02-08 10:00), prepare a design-readiness dossier for the accredited laboratory documenting: material (aluminium/steel, thickness), seam/lid closure (gasket type, compression, cycle repeatability), in-house rig attenuation (key frequencies: 50 MHz, 100 MHz, 500 MHz, 1 GHz, three independent prototypes), and test plan (frequency range, attenuation threshold, acceptance criteria). Submit dossier by Month 4.5 (2027-02-23 14:00) and request technical review by Month 5 (2027-03-08 10:00). If design-readiness review reveals attenuation shortfall in critical bands, implement by Month 5 (2027-03-08 17:00) either: (A) narrow marketing claim scope (e.g., 'protects 100 MHz–1 GHz, reduced effectiveness below 100 MHz'), or (B) commission design iteration with re-qualification in Month 6 (2027-04-08).
- By Month 2 (2026-12-08 16:00), raise the redesign reserve from EUR 20k to EUR 30k by cutting marketing by EUR 10k, or document the decision to accept the EUR 15k worst-case gap (retest + costlier standard) and identify fallback funding source. If neither is acceptable, decide by Month 1 (2026-11-08) whether to: reduce first-batch size, extend presale cutoff to Month 10 (2027-08-08), or delay hard-tooling release until deposits exceed EUR 120k.
- By Month 3 (2027-01-08 16:00), if Prepper presale deposits exceed 70% of total, set a presale price reduction trigger: if realised average order value drifts below EUR 115 (estimate, 77% of EUR 149 list), halt new presale orders and reallocate remaining marketing budget (EUR 10–15k) to Infrastructure and Privacy segments. By Month 6 (2027-04-08 15:00), if presale refund rate exceeds 20% (estimate), trigger a reputational-risk review: analyse complaint patterns, assess messaging accuracy, and adjust fit guide or pricing if necessary.
- By Month 1.5 (2026-11-23 16:00), maintain a live supply-chain risk register (spreadsheet) documenting fabricator lead times, gasket supplier availability, pricing, and capacity headroom. Update monthly. If primary supplier signals price increase >10% (estimate) or capacity loss by Month 6 (2027-04-08 12:00), transition to secondary supplier and accelerate first production run 2–4 weeks if feasible to de-risk inventory.
- By Month 5.5 (2027-03-23 12:00), submit formal test samples to accredited lab and execute validation. Upon report completion (target Month 5 = 2027-03-08 end, latest Month 6 = 2027-04-08), immediately publish full frequency-sweep report and archive for delivery with every unit sold. If report is delayed beyond Month 6 (2027-04-08), notify all presale customers of revised delivery timeline and offer refund option. By Month 7 (2027-05-08 16:00), track fit complaints; if >10% of orders, investigate root cause (undersized design, manufacturing variance, or customer misunderstanding) and document resolution path.
- By Month 6 (2027-04-08 14:00) and Month 8 (2027-06-08 14:00), conduct cash-flow review gates. If cumulative spend exceeds plan >10% (EUR 40k at Month 5 = 2027-03-08; EUR 120k at Month 8 = 2027-06-08), freeze discretionary spending and preserve EUR 30k minimum runway for unexpected redesign or retest. By Month 12.5 (2027-10-23 10:00), founder + external advisor jointly sign off on cash-flow gate result; publish decision (pass/fail/ambiguous + tiebreak) within 5 business days. If result is ambiguous (–5k to +25k), extend measurement to 90 days and re-measure if conditions permit.

## 1.3 Follow Up Consultation

In the next consultation, address: (1) Accredited lab confirmation—name, cost, report date, and fallback if overrun. (2) Legal opinion on EMC Directive applicability and CE-marking exposure; insurance quote and terms by Month 2.5 (2026-12-23). (3) Demand-mix validation—week-1 presale segment tracking results and pivot decision framework. (4) Deposit accounting detail—whether ring-fenced deposits may pay unit cost of matching orders, and how this interacts with the gate rule. (5) Usage of EUR 350k follow-on if gate passes (inventory, SKU variants, marketing, or buffer-stock footprint). (6) Founder capacity and RF expertise sourcing—EMC consultancy milestone dates and university lab IP/timeline terms. (7) Presale refund policy and fit-complaint escalation thresholds, with weekly complaint log. Revisit the cash-flow gate convention and monthly spend plan for sign-off.

## 1.4.A Issue - Cash-Flow Gate Definition Is Ambiguous and Exposes the Founder to Moral Hazard

The plan states the gate threshold is '≥ EUR 25k' operating surplus in the trailing quarter (Months 9–12 = 2027-07-08 to 2027-10-08), but does not explicitly exclude presale deposits from this calculation. The canonical facts define deposits as 'liabilities held in a separate earmarked account,' yet the arithmetic for the gate ('750 units × EUR 67 = EUR 30.25k') does not specify whether this includes deposit-funded orders or only cash-paid units. If deposits are counted as inflows, the EUR 350k tranche may be released before fulfillment obligations are proven, leaving Year-2 underfunded if refund cascades occur. The tiebreak rule ('ambiguous –5k to +25k: founder may extend 90 days') is vague and invites dispute.

### 1.4.B Tags

- cash-flow-gate-ambiguity
- deposit-accounting-unclear
- moral-hazard-presale
- tranche-release-risk
- governance-void

### 1.4.C Mitigation

By Month 0.5 (2026-10-23), publish a written cash-flow gate convention stating: 'Positive cash flow = trailing-quarter operating receipts from delivered units ONLY (net of refunds), excluding all presale deposits. Deposits remain liabilities in an earmarked account and never count as operating cash.' Set a presale cutoff at Month 8 (2027-06-08) to ensure early-order fulfillment completes before gate measurement (Months 9–12 = 2027-07-08 to 2027-10-08). Define the tiebreak rule: if Month 12.5 (2027-10-23) result is –5k to +25k, founder + external advisor jointly sign off; decision is documented and published within 5 business days. Lock product-liability insurance terms by Month 2.5 (2026-12-23) so the tranche release does not depend on unverified insurability.

### 1.4.D Consequence

Without clarity, presale deposits may masquerade as operating cash, triggering premature release of EUR 350k before fulfillment is complete. If refunds spike (15–30% estimate), Year-2 liquidity collapses and the founder's capital is exposed to a second stage with no reserves. Reputational damage and potential regulatory scrutiny (consumer-protection breach) follow if the rule is changed after presale. The ambiguity also makes it impossible to audit the gate decision at Month 12.5 (2027-10-23).

### 1.4.E Root Cause

The plan treats deposits as a financial input (funding tooling) but does not reconcile this with the gate rule (cash flow = operating receipts only). The scenario narrative ('Prove, Pre-Sell, Then Tool') assumes deposits trigger tooling but does not specify whether deposits themselves count toward the gate threshold. This is a governance gap, not a technical one: the plan is silent on who decides the interpretation if ambiguity arises.

## 1.5.A Issue - Accredited EMC Lab Selection and Cost Remain Unverified; Standard Applicability and Retest Fallback Are Unfunded

The plan assumes IEEE 299.1 or equivalent standard (not verified) and a fixed EUR 15k lab cost with a Month 5 (2027-03-08) report date, but no accredited laboratory has been contacted. The 'pre-project assessment' flags this as a 'mandatory' Month 0.5 (2026-10-23) action, yet no statement of work exists. If the lab quotes a costlier standard (MIL-STD-285 or similar, +10–20k estimate) or a longer lead time (8–12 weeks estimate), the EUR 20k redesign reserve is exhausted and there is no funding source. A failed first test (8–15k retest cost, +2 months delay estimate) would compress the presale fulfillment window and likely force a 90-day gate extension. The worst case (retest + costlier standard = 35k) leaves a EUR 15k unfunded gap against zero production headroom.

### 1.5.B Tags

- lab-cost-unverified
- standard-applicability-unverified
- retest-unfunded
- schedule-risk-high
- contingency-exhaustion

### 1.5.C Mitigation

By Month 0.5 (2026-10-23 08:00), contact 2–3 accredited EMC labs (Germany, Sweden, Netherlands, Estonia) for no-cost pre-engagement consultation confirming: (1) applicable standard (IEEE 299.1 or alternative for small shielding enclosures), (2) frequency range (100 kHz–1 GHz estimate), (3) fixed cost (EUR 15k cap; identify overrun trigger), and (4) committed report delivery (Month 5 = 2027-03-08, latest Month 6 = 2027-04-08). By Month 1.5 (2026-11-23 17:00), sign a statement of work with chosen lab specifying cost, timeline, retest provision (if attenuation falls short), and penalty for slip (EUR 500/week estimate, credited against invoice). Pre-qualify a secondary lab by Month 2 (2026-12-08) as fallback. Raise the redesign reserve to EUR 30k by cutting marketing by EUR 10k if the worst-case gap (35k) is to be absorbed.

### 1.5.D Consequence

If lab cost overruns by EUR 10–20k or timeline slips by 4–8 weeks, the design-readiness window (Months 2–4 = 2026-12-08 to 2027-02-08) is compressed and presale fulfillment must accelerate to meet the Month 8 (2027-06-08) cutoff. A failed first test forces a redesign, burning EUR 8–15k within the reserve and leaving EUR 5–12k for any other overrun. No funding path exists for a costlier standard or second retest, so the Month 6 (2027-04-08) latest report date is likely missed and hard tooling slips by 8–12 weeks, making the Month 12 (2027-10-08) cash-flow gate mathematically unachievable (insufficient time to deliver 1,500 units and collect payment). The tranche is withheld and the founder must decide between wind-down or unfunded extension.

### 1.5.E Root Cause

The plan assumes a EUR 15k, Month 5 (2027-03-08) lab-report delivery as a fixed fact, but this has never been confirmed with an actual lab. The pre-project assessment correctly flags this as 'mandatory by Month 0.5 (2026-10-23),' but the plan does not show evidence that this action has been initiated. The EUR 20k redesign reserve is notionally shared between design iteration and retest fallback, but a retest alone (8–15k) can exhaust it, leaving no margin for a costlier standard or unforeseen redesign. The plan also lacks a documented escalation path: if the lab quotes overrun, who decides whether to accept higher cost, pivot to a cheaper (possibly weaker) standard, or halt presale launch?

## 1.6.A Issue - Demand-Mix Risk and Cash-Flow Gate Survivability Are Underspecified; Prepper-Only Volumes Are Insufficient for Positive Cash Flow

The plan aspires to a 'multi-use RF-isolation product' positioning (forensics, privacy, travel security) to widen the addressable market, but no evidence of demand for these segments exists. The canonical facts define the base case as '750 units per quarter' at EUR 67 contribution margin, yielding EUR 30.25k operating surplus (just EUR 5.25k above the EUR 25k gate). But if presale deposits prove heavily skewed toward low-margin prepper sales (EUR 15 margin estimate, vs. EUR 67 base case), 750 units yield only EUR 11.25k contribution per quarter, missing the gate by EUR 13.75k. The plan mentions a 'demand pivot trigger' at Month 3 (2027-01-08) if prepper deposits exceed 70%, but this is informal; no weekly segment tracking, no SLA for pivot execution, and no fallback pricing or marketing budget reallocation are documented. Infrastructure pilots are proposed at Month 3 (2027-01-08) delivery by Month 5 (2027-03-08), but infrastructure procurement cycles typically run 12–16 weeks, so even fast-track pilots may not deliver revenue before Month 12 (2027-10-08) gate measurement.

### 1.6.B Tags

- demand-mix-unproven
- killer-app-missing
- margin-collapse-risk
- gate-failure-mode
- infrastructure-sales-cycle-long
- pivot-trigger-informal

### 1.6.C Mitigation

By Month 1 (2026-11-08 09:00), establish three separate presale campaign channels: Prepper Networks (Carrington/solar-storm narrative, EUR 50–70 average order value estimate), Infrastructure Buyers (business continuity, EUR 200–300+ AOV estimate), and Privacy/Forensics (travel security, EUR 80–150 AOV estimate). Create distinct landing pages and deposit tracking by segment. By Month 3 (2027-01-08 16:00), publish a weekly tracker (deposit count, value, refund rate by segment). If Prepper deposits exceed 70% of total, immediately reallocate EUR 10–15k from Prepper marketing to Infrastructure and Privacy. Negotiate 1–2 'fast-track' infrastructure pilots (10–20 units, delivery Month 5 = 2027-03-08, pilot feedback Month 6 = 2027-04-08) by Month 3 (2027-01-08). Set a minimum average realized price target: EUR 120 per unit (80% of list); if realized price drifts below EUR 115, halt presale and pivot narrative. Document the pivot decision framework in writing by Month 1 (2026-11-08).

### 1.6.D Consequence

If demand is prepper-heavy (>70% deposits) and margin averages EUR 15 per unit, the gate is missed by EUR 13.75k per quarter (estimate). Year-2 does not open; the founder has either to wind down or fund Year-2 from personal capital, reducing the founder's capital reserve from EUR 750k toward EUR 400k (Year-1 burn) + unbudgeted extension. Reputational damage follows if presale buyers experience long delays or partial refunds due to cash-flow stress. The plan's staged-funding model (EUR 350k conditional on gate pass) collapses, leaving no capital for buffer stock, marketing scale-up, or SKU variants. Infrastructure and privacy segments, which have higher willingness to pay, remain untapped because early cash went to low-margin prepper fulfillment.

### 1.6.E Root Cause

The plan positions the product as 'multi-use RF isolation' to widen the market, but presale messaging and routing are not designed to test this. There is no documented evidence of demand from forensics, privacy, or corporate travel-security buyers, only a SWOT assumption that these segments 'can be developed.' The plan also assumes that 750 units per quarter is achievable across all segments, but does not stress-test what happens if one segment dominates. The 'demand pivot trigger' at Month 3 (2027-01-08) is mentioned in SWOT but not in the project plan's action list; it is therefore treated as informal intention rather than a binding execution commitment. The infrastructure pilot timeline (delivery Month 5 = 2027-03-08, feedback Month 6 = 2027-04-08) is also optimistic given typical procurement lead times.

---

# 2 Expert: EMC Test Engineering & Shielding Design Consultant

**Knowledge**: RF shielding design, Faraday enclosure performance, IEEE 299.1 and MIL-STD-285 testing standards, seam and gasket engineering, accredited EMC laboratory workflows, frequency-sweep testing, attenuation measurement

**Why**: The plan's technical credibility rests on Shielding Proof Standard (Decision 1) and Enclosure Architecture (Decision 3). This expert bridges design iteration and lab validation: confirms prototype attenuation via the in-house rig, coaches the founder on design trade-offs (seam vs. gasket vs. aperture closure), and coordinates the accredited lab pre-test review (Month 4–5 = 2027-02-08 to 2027-03-08) to catch attenuation shortfalls before formal testing. Without this, a failed lab run (8–15k re-test cost, +2 month delay) consumes the 20k reserve and misses the Month 6 (2027-04-08) report deadline, jeopardizing presale and hard-tooling release.

**What**: By Month 2 (2026-12-08), design and build the in-house shielding test rig, then run two independent prototype seam cycles (Month 3 = 2027-01-08) documenting attenuation at key frequencies (50 MHz, 100 MHz, 500 MHz, 1 GHz) against claimed band. Confirm lab applicability and design-readiness criteria. Coordinate the accredited lab design-review meeting (Month 4.5 = 2027-02-23) and technical feedback, then advise on iteration or claim-scope narrowing if results diverge.

**Skills**: Prototype RF measurement, enclosure seam design optimization, gasket-compression mechanics, test-rig construction, EMC standard interpretation, lab sample preparation, attenuation trade-off analysis

**Search**: Faraday enclosure RF shielding design consultant, EMC laboratory IEEE 299.1 testing, prototype RF measurement rig, shielding effectiveness gasket seam

## 2.1 Primary Actions

- By Month 0.5 (2026-10-23 08:00): Contact 2–3 accredited EMC labs (DEKRA, TÜV, SGS, or local Estonian equivalent) for no-cost pre-engagement consultation. Request written quote specifying standard (IEEE 299.1, IEC 61000-4-3, or MIL-STD-285), cost cap (lock at EUR 15k; document any overrun risk), frequency range tested (e.g., 100 kHz to 1 GHz), and fixed report-delivery date (Month 5 = 2027-03-08 latest). Secure signed statement of work by Month 1.5 (2026-11-23 17:00) with contractual penalty for schedule slip (e.g., EUR 500/week, credited to invoice).
- By Month 0.5 (2026-10-23 14:00): Draft and publish a written cash-flow gate measurement rule binding founder + external advisor. Specify: Positive cash flow = trailing-quarter operating revenue from delivered units only (not presale deposits); threshold EUR 25k or revised target; measurement window Months 9–12 (2027-07-08 to 2027-10-08); presale deposits held in earmarked account, excluded from all operational spending; presale-order cutoff Month 8 (2027-06-08) in all marketing terms. Implement separate bank account and ledger for deposits by Month 1 (2026-11-08). Weekly tracking dashboard by Month 2 (2026-12-08).
- By Month 1 (2026-11-08 09:00): Establish three distinct presale campaigns: Prepper Networks (solar-storm, continuity messaging), Infrastructure Buyers (emergency-response procurement), Privacy/Forensics (corporate IT, travel-security angle). Use separate landing pages, CTAs, and contact tracking for each segment. Measure weekly: deposit count, total value, AOV, and conversion time by segment. Document pivot trigger: if Prepper deposits exceed 70% by Month 3 (2027-01-08), reallocate EUR 10–15k to Infrastructure and Privacy channels and negotiate 1–2 fast-track infrastructure pilots (10–20 units at EUR 84/unit, delivery Month 5 = 2027-03-08).
- By Month 1 (2026-11-08 17:00): Engage a product-compliance attorney licensed in the EU to deliver a written legal opinion by Month 1 (2026-11-08 end) addressing: EMC Directive 2014/30/EU applicability, General Product Safety Directive 2001/95/EC applicability, whether CE marking or notified-body assessment is required, and liability exposure under EU consumer law if shielding claims are exceeded in a real event. Obtain a preliminary product-liability insurance quote (EUR 250–500k coverage) by Month 2 (2026-12-08); lock insurance terms by Month 2.5 (2026-12-23 15:00).
- By Month 1.5 (2026-11-23 17:00): Secure signed statement of work with the chosen accredited EMC lab, specifying fixed cost (EUR 15k, or revised cap), test standard, report-delivery date (Month 5 = 2027-03-08, latest Month 6 = 2027-04-08), re-test provision if results are out of spec, and contractual penalties for schedule slip. Identify and pre-qualify a secondary lab as a 6–8 week fallback by Month 2 (2026-12-08).
- By Month 2 (2026-12-08): Establish separate bank account and accounting ledger for presale deposits, held exclusively for customer refunds and fulfillment obligations. Lock product-liability insurance terms and publish insurance certificate with presale terms. Implement weekly presale tracking dashboard (deposits, refunds, segment distribution, AOV) shared with external advisor.

## 2.2 Secondary Actions

- By Month 0.5 (2026-10-23 10:00): Create a detailed monthly Year-1 budget spend plan allocating EUR 400k as: Months 0–2 (2026-10-08 to 2026-12-08) (design EUR 70k, in-house rig EUR 40k); Months 2–5 (2026-12-08 to 2027-03-08) (lab EUR 15k, soft tooling EUR 20k); Months 5–12 (2027-03-08 to 2027-10-08) (production EUR 150–200k, marketing EUR 75k, redesign reserve EUR 20k, contingency EUR 5k). Hold hard-tooling and full-production-batch spend uncommitted until both conditions are met: presale deposits ≥ EUR 80k AND accredited lab pre-test confirms design readiness (Month 5 = 2027-03-08). Establish monthly cash-burn review gates at Month 5 (2027-03-08) and Month 8 (2027-06-08); if cumulative spend exceeds plan by >10%, freeze discretionary spending and review variance.
- By Month 1 (2026-11-08 12:00): Identify and pre-qualify a secondary precision-metal fabricator in Tallinn or Estonia with ISO certification and laser-cutting/CNC-bending capability. Conduct a trial batch (50–100 units estimate) by Month 2 (2026-12-08), testing dimensional accuracy (±0.1 mm estimate) and consistency vs. primary fabricator. Source conductive-gasket material from two qualified suppliers (primary and backup) by Month 1.5 (2026-11-23); hold minimum 30-day buffer stock (EUR 5–10k estimate) before production release to prevent supply disruption. Lock Year-1 fabrication pricing and capacity with primary supplier in a signed agreement by Month 1 (2026-11-08 15:00), specifying unit-cost caps (no increase >10% estimate without 30-day notice) and contractual remedy for delays (e.g., EUR 500/week credit).
- By Month 1 (2026-11-08 11:00): Draft and publish a written presale terms document covering: order placement, 30-day refund guarantee for fit/quality, delivery SLA (ships within 2–3 weeks, estimated delivery 4–5 weeks), escalation path with 48-hour response target, and device-fit responsibility disclaimer. Publish a detailed Product Fit Guide by Month 1.5 (2026-11-23 13:00) with dimensions (420 x 280 x 50 mm estimate, internal) and photographs showing which devices fit/do not fit. Implement presale-complaint escalation: if fit complaints exceed 10% by Month 7 (2027-05-08), investigate root cause; if refund rate exceeds 20% by Month 6 (2027-04-08), trigger messaging review.
- By Month 1 (2026-11-08): Establish a supply-chain risk register documenting fabricator lead times, gasket pricing, capacity headroom, and supply signals. Update monthly. If primary supplier signals price increase >10% or capacity loss by Month 6 (2027-04-08), trigger transition to secondary supplier and accelerate first production run by 2–4 weeks to de-risk inventory.
- By Month 2 (2026-12-08): Commission the lab design-readiness review (EUR 2–3k estimate, 2-week turnaround) to confirm prototype attenuation vs. marketing claims across key frequencies (50 MHz, 100 MHz, 500 MHz, 1 GHz). If results fall short, decide by Month 5 (2027-03-08 end): either narrow marketing-claim scope to exclude weak bands or commit to design iteration and re-qualification (1-month delay). Publish the accredited lab report (full frequency sweep, attenuation table, test conditions) as part of presale marketing and with every unit sold.
- By Month 3 (2027-01-08 12:00): Negotiate 1–2 fast-track infrastructure or privacy pilot agreements (10–20 units at EUR 84/unit, delivery Month 5 = 2027-03-08, pilot feedback by Month 6 = 2027-04-08) with reference rights. If presale conversion is <40% by Month 3 (2027-01-08), pivot: reduce presale price 15–20% (estimate) or extend presale to Month 10 (2027-08-08) with no hard tooling commitment.
- By Month 4 (2027-02-08 10:00): Submit design-readiness dossier to accredited lab documenting enclosure material, seam/closure design, prototype attenuation from in-house rig (three independent builds), test plan, and images. Request technical review meeting by Month 5 (2027-03-08 10:00). If review reveals attenuation shortfalls in key bands, decide: (A) narrow claim scope or (B) iterate design and re-qualify by Month 6 (2027-04-08).
- By Month 6 (2027-04-08 16:00): If net presale deposits fall short of EUR 80k, do not release hard tooling. Trigger strategic pivot: reduce presale price 15–20%, reallocate EUR 10–15k to Infrastructure and Privacy marketing, or extend presale to Month 8 (2027-06-08 maximum). If still <EUR 80k at Month 8 (2027-06-08), expect EUR 350k tranche to be withheld; founder reviews options (wind-down, extension, external funding).
- By Month 8 (2027-06-08 16:00): Close presale-order window; all new orders go to regular fulfillment channel. Ensure all early presale orders are fulfilled and revenue is received by Month 12 (2027-10-08) gate measurement to avoid timing distortions. Monitor refund requests; if cumulative refunds exceed 15% of deposits, investigate root cause and adjust messaging/fulfillment.

## 2.3 Follow Up Consultation

In the next consultation, the following topics must be addressed to move from strategic planning to execution: (1) Lab Selection Finalization: present cost quotes and timeline confirmations from 2–3 candidate accredited labs; confirm the chosen standard (IEEE 299.1 or alternative) and signed statement of work by Month 1.5 (2026-11-23). (2) Cash-Flow Gate Governance: review the published gate rule with the external advisor to confirm alignment and sign-off authority. (3) Presale Segment Testing: confirm the landing-page campaigns, messaging, and weekly tracking dashboard for the three buyer segments, and document the Month 3 (2027-01-08) pivot trigger in writing. (4) Legal and Compliance: present the legal opinion on EMC Directive and product-safety applicability, and confirm the product-liability insurance quote and exclusions. (5) Supply Chain: confirm secondary fabricator trial results and gasket-supplier pre-qualification, and lock primary-supplier pricing and capacity agreement. (6) Prototype Design-Readiness: confirm that in-house rig testing is on track for Month 3 (2027-01-08), with attenuation data ready for lab pre-engagement. (7) Year-2 Strategy: clarify intended use of the EUR 350k tranche (inventory, buffer stock, SKU variants, marketing, or R&D) to guide Month-12 gate assessment and fund allocation decisions.

## 2.4.A Issue - Accredited EMC Lab Standard and Cost Are Unconfirmed; No Signed Statement of Work Yet

The plan assumes IEEE 299.1 or equivalent testing at EUR 15k, fixed cost, with a Month 5 (2027-03-08) report. Neither the applicable standard nor the cost has been locked via signed statement of work. Pre-engagement contacts have not been made. If the chosen lab requires MIL-STD-285 (+10–20k) or if IEEE 299.1 is deemed inapplicable and a costlier alternative is mandated, the 20k redesign reserve is consumed entirely, leaving zero contingency for any re-test failure. A re-test alone (8–15k) consumes the reserve and forces a 90-day extension or hard tranche dependency.

### 2.4.B Tags

- lab-cost-uncertainty
- standard-applicability-unverified
- no-statement-of-work
- schedule-risk
- contingency-consumed

### 2.4.C Mitigation

Execute the following by Month 0.5 (2026-10-23): Contact 2–3 accredited EMC labs (DEKRA, TÜV, SGS, or Estonia-based equivalent) for no-cost pre-engagement consultation. Request written quote specifying: standard (IEEE 299.1, IEC, MIL-STD-285, or alternative), frequency range, cost cap (EUR 15k maximum; document overrun), and fixed report-delivery date (Month 5 = 2027-03-08 latest). Secure signed statement of work by Month 1.5 (2026-11-23) with contractual penalty (EUR 500/week delay estimate, credited to invoice). Identify and pre-qualify a secondary lab by Month 2 (2026-12-08) as a 6-week fallback. Budget increase to EUR 25k (from 15k) to absorb a likely 50% cost overrun and reduce reserve pressure.

### 2.4.D Consequence

Without lab cost certainty and a signed contract, the venture faces a USD 10–20k surprise in Month 4–5 (2027-02-08 to 2027-03-08), compressing the redesign buffer to near zero. A re-test failure then forces a 90-day extension (report in Month 7 or 8 = 2027-05-08, 2027-06-08), which misses the Month 6 (2027-04-08) hard-tooling gate and delays presale fulfillment into July–August (2027-07 to 2027-08). Revenue slides to Month 10–11 (2027-08 to 2027-09), and the Month 12.5 (2027-10-23) cash-flow gate measurement becomes tight or fails if only 500–600 units ship by Month 12 (2027-10-08). Founder capital is at risk if the 350k tranche is withheld.

### 2.4.E Root Cause

Lab selection was deferred pending accredited-lab engagement. The plan lacks a backlog of candidate labs, written cost confirmations, and contractual penalty clauses for schedule slip. No pre-engagement consultation has documented the applicable standard for a small RF enclosure. The assumption of a single lab trial is fragile: if the first lab reports in Month 6 or 7 (2027-04-08, 2027-05-08) (not Month 5 = 2027-03-08), hard tooling and presale fulfillment are jeopardised.

## 2.5.A Issue - Cash-Flow Gate Measurement Rule Is Not Yet Published; Presale Deposits Risk Being Miscounted as Operating Cash

The plan defines the gate as EUR 25k (proposed threshold) trailing-quarter operating surplus, excluding presale deposits. However, no published written rule exists that binds the founder, advisor, or other stakeholders. Presale deposits are held as liabilities in principle but are at risk of being reclassified or spent operationally if no separate accounting is enforced. If deposits are counted as cash flow (a tempting misclassification when cash is tight in Months 7–9 = 2027-05-08 to 2027-07-08), the EUR 350k tranche is released prematurely, before fulfillment obligations are proven. This creates a cascade risk: refunds spike in Year-2 (20–30% estimate) due to fit or delivery issues, deposits are exhausted, and the fund is undercapitalized for Year-2 operations.

### 2.5.B Tags

- gate-rule-not-published
- deposit-accounting-ambiguous
- moral-hazard
- year2-funding-risk
- no-external-governance

### 2.5.C Mitigation

Draft and publish the cash-flow gate measurement rule in writing by Month 0.5 (2026-10-23). Rule must specify: (1) Positive cash flow = trailing-quarter operating revenue from delivered units only (not deposits), minus direct unit costs and recurring opex. (2) Threshold = EUR 25k (or revised target). (3) Measurement window = Months 9–12 end (2027-07-08 to 2027-10-08). (4) Presale deposits excluded entirely, held in earmarked account, used for refunds only. (5) Sign-off by founder + one external advisor by Month 12.5 (2027-10-23). Implement separate bank account and accounting ledger for deposits by Month 1 (2026-11-08). Publish presale-order cutoff (Month 8 = 2027-06-08) in all presale marketing and terms; orders after Month 8 (2027-06-08) defer to regular channel. Weekly tracking of deposits, refunds, and operating cash in a dashboard shared with advisor, starting Month 2 (2026-12-08).

### 2.5.D Consequence

Loose or misunderstood gate rule creates moral hazard: if deposits are counted as cash flow in Month 12 (2027-10-08) measurement, EUR 350k follow-on is released prematurely based on undelivered customer obligations. If fulfillment slips or refund rate exceeds 15% in Year-2 (estimate), deposits are consumed, Year-2 cash reserve is depleted, and the venture is underfunded for operations and inventory. Founder faces reputational damage, potential breach-of-contract claims from customers if refund processing slips, and a forced wind-down or emergency funding request in Quarter-2 Year-2 (Month 15 = 2028-01-08). External advisor may challenge gate sign-off if rule is ambiguous, delaying release of the 350k tranche into Month 1–2 (2026-11-08 to 2026-12-08) Year-2.

### 2.5.E Root Cause

The gate convention was defined conceptually but not published as a binding governance document. No separate bank account or accounting ledger has been established for deposits. The founder has not signed off on the rule with an external advisor, and there is no public commitment to the rule that would resist informal pressure to redefine it if deposits look weak. The presale cutoff (Month 8 = 2027-06-08) is stated but not integrated into presale-marketing terms or contractual documents.

## 2.6.A Issue - Presale Demand Mix Is Unvalidated; Prepper-Only Scenario Leads to Negative Cash Flow and Gate Failure

The plan assumes a multi-use positioning (preppers, infrastructure, privacy/forensics) to reach the EUR 25k (proposed threshold) cash-flow gate. However, no presale testing has been conducted. If presale deposits skew toward preppers (>70% of total by Month 3 = 2027-01-08), unit margin collapses: prepper average order value is EUR 50–70 (estimate) at EUR 10–20 margin (estimate) per unit, vs. infrastructure EUR 200–300 AOV at EUR 60–120 margin (estimate). A prepper-only year generates EUR 60–80k (estimate) revenue on 800–1000 units, contributing EUR 8–20k operating surplus before opex, failing the EUR 25k gate. The plan correctly identifies this risk but has no early-detection mechanism or pre-committed pivot strategy.

### 2.6.B Tags

- demand-mix-unvalidated
- prepper-margin-collapse
- no-early-detection
- pivot-rule-not-committed
- gate-failure-risk

### 2.6.C Mitigation

By Month 1 (2026-11-08), establish three distinct presale landing pages and campaigns: Prepper Networks (forums, solar-storm narrative), Infrastructure Buyers (continuity-of-operations, procurement contacts), Privacy/Forensics (corporate IT, data-protection angle). Use distinct messaging, CTAs, and contact paths for each. Measure weekly: deposit count, total value, average order value, and conversion time by segment. Target combined deposits EUR 80–120k by Month 6 (2027-04-08), distributed: Prepper 30–40%, Infrastructure 35–45%, Privacy/Forensics 25–35%. By Month 3 (2027-01-08), if Prepper deposits exceed 70% of total, trigger immediate marketing pivot: reallocate EUR 10–15k from Prepper channels to Infrastructure and Privacy messaging. Negotiate 1–2 fast-track infrastructure or privacy pilots (10–20 units, cost +20% = EUR 84/unit) by Month 3 (2027-01-08), delivery Month 5 (2027-03-08), with reference rights. If combined non-prepper deposits remain <30% by Month 4 (2027-02-08), reduce presale price 15–20% (estimate) to broaden appeal or halt presale marketing and pivot to wholesale or direct sales channels.

### 2.6.D Consequence

Without segment-mix validation and early pivoting, presale deposits will concentrate in preppers by Month 3–4 (2027-01-08 to 2027-02-08), locking the venture into a low-margin product mix. Revenue in Months 7–12 (2027-05-08 to 2027-10-08) will be EUR 60–80k (estimate) at margin EUR 8–20k, falling EUR 5–17k short of the EUR 25k gate (proposed threshold). Gate failure results: EUR 350k tranche is withheld, Year-2 operations are underfunded (EUR 80k opex against zero surplus), and the founder must choose between wind-down or a costly marketing pivot and inventory restock using personal capital or external debt. Additionally, founder reputation and stakeholder trust are damaged by a missed gate that was predicted but not actively mitigated.

### 2.6.E Root Cause

Presale segment testing has not been designed or launched. Marketing messaging is not yet segmented by buyer type, so presale inbound will reflect organic interest (heavily prepper-leaning, given Carrington media cycles) rather than deliberate segment-mix targeting. No weekly tracking dashboard exists to measure segment contribution, and no pivot trigger has been contractually documented with the founder. The plan acknowledges that 'broad or multi-use positioning raises the claim-substantiation burden' but defers segment selection to Month 3 (2027-01-08) without a pre-committed decision rule.

---

# 3 Expert: Hardware Supply-Chain & Tallinn Manufacturing Operations Manager

**Knowledge**: Precision sheet-metal fabrication, laser cutting and CNC bending, Estonia/Tallinn fabricator ecosystem, tooling (soft vs. hard), gasket and conductive-material sourcing, production quality control, European freight logistics, supplier risk management

**Why**: The plan anchors production on Tallinn's low-cost ISO-certified base (Tallinn Production Model, Decision 6), but supply-chain concentration and material sourcing are under-specified. This expert mitigates three high-impact risks: (1) fabric-ator price increases (10–20% estimate) or capacity loss, which erodes the EUR 67 margin and threatens cash-flow gate; (2) conductive-gasket material delays (2–4 weeks estimate), which compress presale fulfillment window; (3) soft-tooling cost overruns and hard-tooling readiness (threshold is EUR 30k estimate, range 20–40k), which consume the production-line budget. By Month 1 (2026-11-08), this expert pre-qualifies secondary fabricators, locks primary-supplier pricing and capacity in a signed agreement, secures gasket buffer stock, and establishes monthly lead-time reviews.

**What**: Contact and pre-qualify 1–2 secondary sheet-metal fabricators in Tallinn/Estonia/Latvia by Month 1 (2026-11-08). Run a trial 50–100 unit batch with the secondary by Month 2 (2026-12-08) to confirm laser accuracy (±0.1 mm estimate), burr removal, and dimensional consistency. Secure conductive-gasket sourcing from primary and backup suppliers by Month 1.5 (2026-11-23) with minimum 30-day buffer stock. Lock primary-fabricator pricing (unit cost cap, no increase >10% estimate without 30-day notice), capacity reservation (500–1,000 units Year-1) and contractual remedies (e.g., EUR 500/week delay credit) in a signed agreement by Month 1 (2026-11-08).

**Skills**: Supplier qualification and contracting, sheet-metal fabrication process (laser, bending, finishing), ISO 9001 quality auditing, soft vs. hard tooling cost modeling, inventory buffer-stock planning, logistics cost analysis, European freight consolidation

**Search**: Tallinn Estonia sheet metal precision fabricator laser CNC, conductive gasket supplier EMI shielding, supply chain risk management manufacturing, hard soft tooling cost comparison

## 3.1 Primary Actions

- Lock accredited EMC lab selection, standard (IEEE 299.1 or confirmed equivalent), cost (€15k cap), and report delivery date (Month 5 = 2027-03-08) via signed statement of work by Month 1.5 (2026-11-23). Conduct pre-engagement consultation (€2–3k) by Month 1 (2026-11-08) to confirm test methodology and applicability. Commission design-readiness review by Month 4 (2027-02-08) to catch attenuation shortfalls before formal submission.
- Draft, publish, and sign the cash-flow gate measurement convention by Month 0.5 (2026-10-23) specifying: operating cash surplus = delivered-unit receipts minus direct cost minus recurring opex; presale deposits excluded and held as liabilities in earmarked account; threshold €25k quarterly (Months 9–12 = 2027-07-08 to 2027-10-08); measured and signed by founder + external advisor by Month 12.5 (2027-10-23). Establish presale cutoff Month 8 (2027-06-08) and implement weekly tracking dashboard (deposits, refunds, operating cash).
- Run three parallel presale campaigns by Month 1 (2026-11-08) testing killer-app candidates: forensics/travel-security, continuity-of-operations, and prepper. Measure weekly segment deposits, AOV, and refund rate. By Month 3 (2027-01-08), identify the segment with >€120 AOV and >40% deposit share. Reallocate €10–15k marketing spend to the winning segment. Negotiate fast-track infrastructure pilot agreements (10–20 units, €84/unit, delivery Month 5 = 2027-03-08) with at least one buyer by Month 3 (2027-01-08) to lock early reference revenue.
- Obtain written legal opinion on EU product-safety rule applicability (EMC Directive, General Product Safety Directive, CE marking requirement, and consumer-protection exposure) by Month 1 (2026-11-08). Lock product-liability insurance terms (€250–500k estimate) by Month 2.5 (2026-12-23); confirm insurability of shielding claims. Draft scope statement ('protects stored spare devices only; no grid protection') and publish with presale materials and accredited lab report.
- Pre-qualify secondary Tallinn precision-metal fabricator (laser cut, CNC bend, ISO-certified) and conduct trial batch (50–100 units) by Month 2 (2026-12-08). Lock primary fabricator pricing and capacity in signed agreement by Month 1 (2026-11-08) specifying: unit cost cap (no increase >10% without 30-day notice), reserved capacity (500–1,000 units Year-1), and delay remedy (€500/week estimate credit). Source conductive-gasket material from primary + secondary supplier by Month 1.5 (2026-11-23); hold minimum 30-day buffer stock (€5–10k estimate) before production release.
- Create detailed monthly Year-1 burn schedule by Month 0.5 (2026-10-23) allocating €400k as: Months 0–2 (2026-10-08 to 2026-12-08): €110k (design €70k, in-house rig €40k); Months 2–5 (2026-12-08 to 2027-03-08): €35k (lab €15k, soft tooling €20k); Months 5–12 (2027-03-08 to 2027-10-08): €255k (production €150–200k estimate, marketing €75k, reserve €20k). Gate all hard tooling spend until presale deposits ≥€80k (proposed threshold) AND accredited lab pre-test confirms design (Month 5 = 2027-03-08). Establish monthly cash-burn review gates (Month 5 = 2027-03-08 and Month 8 = 2027-06-08) with >10% variance freeze trigger (€40k at Month 5 = 2027-03-08, €120k at Month 8 = 2027-06-08). Preserve €30k minimum runway for redesign or retest by Month 5 (2027-03-08).

## 3.2 Secondary Actions

- Establish presale refund policy and delivery SLA by Month 1 (2026-11-08): 30-day money-back guarantee for fit/quality, refunds issued within 10 business days; ships within 2–3 weeks; estimated delivery 4–5 weeks. Publish detailed product fit guide (internal dimensions 420×280×50 mm estimate, laptop sizes 13–17 inch, phone 4.5–6.5 inch) with photographs by Month 1.5 (2026-11-23). Link fit guide and SLA on all presale pages; require acceptance before purchase.
- Implement presale complaint and refund tracking by Month 1 (2026-11-08). If fit complaints exceed 10% by Month 7 (2027-05-08), investigate root cause (undersized design, manufacturing variance, customer misunderstanding) and plan smaller-SKU variant or redesign post-gate. If refund rate exceeds 20% by Month 6 (2027-04-08), audit messaging and adjust presale pricing or narrative to reduce expectations and restore trust.
- Conduct design-readiness dossier review with accredited lab by Month 4 (2027-02-08). Document enclosure material (aluminium/steel, thickness, grade), seam/lid design (gasket type, compression, cycle repeatability), in-house rig attenuation (50 MHz, 100 MHz, 500 MHz, 1 GHz at three independent prototype builds), and test plan. If design-readiness review shows attenuation shortfall in a frequency band, narrow marketing claims to tested band (exclude weak frequencies) or commission minor redesign with re-qualification in Month 6 (2027-04-08).
- Establish governance escalation rule for ambiguous Month 12.5 (2027-10-23) gate measurement by Month 0.5 (2026-10-23): if trailing-quarter operating cash is between −€5k and +€25k, tiebreaker decision is made by external advisor or founder + advisor consensus within 5 business days; decision documented and published. If gate passes, release €350k tranche and define allocation (inventory, marketing, R&D, buffer stock, SKU variants). If gate fails, founder decides on wind-down, extension, or additional capital injection.
- Maintain live supply-chain risk register updated monthly (lead times, pricing, capacity headroom, supplier signals). If primary fabricator signals price increase >10% (estimate) or capacity loss by Month 6 (2027-04-08), trigger transition to secondary supplier and accelerate first production run by 2–4 weeks to avoid supply disruption before cash-flow gate. Hold monthly supplier review calls and document all pricing or capacity commitments in writing.
- By Month 3 (2027-01-08), if presale deposits remain below €80k target, trigger strategic pivot: reduce presale pricing by 15–20% (estimate), reallocate €10–15k from contingency to marketing (privacy and infrastructure segments, not just preppers), or extend presale window by 4 weeks (to Month 10 = 2027-08-08). Document pivot decision framework in writing by Month 1 (2026-11-08) so triggers are objective and actionable.
- Publish accredited lab shielding report and Customer Scope Sheet (1–2 pages, measured frequency range, attenuation at key frequencies, liability disclaimer) with every presale unit sold and post online. Include full frequency-sweep report (digital copy in packaging, downloadable link). Demonstrate claim substantiation and reduce consumer-law exposure by showing good-faith validation.

## 3.3 Follow Up Consultation

Month 1 (2026-11-08): confirm lab agreement signed, legal opinion received, insurance quote locked, and presale campaigns live across three segments with week-1 deposit tracking. Month 3 (2027-01-08): review segment deposit velocity and AOV; identify killer app; confirm infrastructure pilot agreements; assess presale conversion rate and trigger pivot if <40% or AOV <€120. Month 5 (2027-03-08): accredited lab report delivered and design-readiness confirmed; presale deposits assessed against €80k threshold; hard-tooling decision gated. Month 6 (2027-04-08): first batch committed and production underway; refund rate and fit-complaint monitoring in place. Month 9 (2027-07-08): presale fulfillment on track; cash-flow measurement window opens. Month 12.5 (2027-10-23): gate sign-off with founder and advisor; tranche release or wind-down decision.

## 3.4.A Issue - Cash-Flow Gate Threshold Unrealistic Without Killer Application

The €25k quarterly cash-flow gate (proposed threshold) requires 672 units/quarter at €67 margin, but the plan offers no proven killer application to drive demand. The base case of 750 units/quarter leaves only €5.25k headroom (estimate). A prepper-only mix at €15/unit margin (proposed range) yields €8.75k quarterly loss, failing the gate. Multi-use RF-isolation positioning is broad and untested. Without segment testing by Month 3 (2027-01-08), demand will skew toward low-margin preppers, missing the gate and withholding the €350k tranche.

### 3.4.B Tags

- demand_risk
- gate_arithmetic
- missing_killer_app
- margin_compression
- segment_validation

### 3.4.C Mitigation

By Month 3 (2027-01-08), run parallel presale campaigns for three candidate killer apps: forensics/travel-security, continuity-of-operations, and prepper. Measure deposit velocity and realized price for each. Identify the segment with >€120 AOV and >40% deposit share by Month 3 (2027-01-08). Reallocate €10–15k marketing spend to the winning segment. Establish infrastructure pilot agreements (10–20 units, €84/unit, delivery Month 5 = 2027-03-08) to lock early revenue. If no segment exceeds €120 AOV by Month 6 (2027-04-08), pivot pricing or accept gate failure and 90-day extension.

### 3.4.D Consequence

If demand remains prepper-dominated (€15/unit margin), quarterly cash flow is negative €8.75k (estimate). The €350k tranche is withheld. Year-2 funding disappears and the venture faces wind-down or founder self-injection of additional capital. Reputation and refund cascades follow if margins force price cuts or delivery slips.

### 3.4.E Root Cause

The plan names three buyer segments (prepper, infrastructure, privacy) but tests none. Positioning as multi-use RF-isolation is theoretically attractive but operationally vague. No customer research, no pilot agreements, and no early evidence of willingness to pay at €120+ per unit. The gate threshold was set on spreadsheet math (750 units) rather than validated demand, leaving no margin for forecast error.

## 3.5.A Issue - Accredited Lab Cost, Timeline and Re-Test Risk Underfunded and Unmitigated

The €15k accredited lab budget (fixed) assumes a single successful test. A re-test (€8–15k estimate) consumes the entire €20k redesign reserve. A costlier standard (MIL-STD-285, not verified; €10–20k estimate) or both triggers a €15k gap with zero production headroom. A failed seam design or gasket performance would force choice: cut the follow-on batch, defer hard tooling (4–8 weeks slip), or accept tranche-dependent delay. No signed lab statement of work, no pre-engagement confirmation of standard or cost, and no secondary lab backup exist by Month 0.5 (2026-10-23).

### 3.5.B Tags

- lab_cost_risk
- reserve_exhaustion
- standard_uncertainty
- retest_fallback
- schedule_compression

### 3.5.C Mitigation

By Month 0.5 (2026-10-23), contact 2–3 accredited EMC labs (Germany, Sweden, Estonia). Obtain signed statement of work by Month 1.5 (2026-11-23) specifying: standard (IEEE 299.1 or equivalent applicability confirmed), frequency range, cost cap (€15k locked), report delivery (Month 5 = 2027-03-08), and re-test provision (included or capped at €10k). Commission design-readiness review (€2–3k) by Month 4 (2027-02-08) to catch attenuation shortfalls before formal testing. Pre-qualify secondary lab by Month 2 (2026-12-08). Increase redesign reserve to €30k by cutting marketing €10k if worst-case lab cost or standard risk is confirmed.

### 3.5.D Consequence

Lab cost or standard surprise delays the report by 4–8 weeks (to Month 7 = 2027-05-08), missing the Month 6 (2027-04-08) tooling gate. Hard tooling and batch 1 slip by 4–8 weeks, compressing the presale fulfillment window (Months 6–9 = 2027-04-08 to 2027-07-08 to Months 8–10 = 2027-06-08 to 2027-08-08) and likely triggering the 90-day gate extension (Month 12 = 2027-10-08 measurement becomes Month 15 = 2028-01-08). Refund pressure rises as delivery slips. A €15k lab gap consumes the reserve, leaving zero contingency for any other overrun.

### 3.5.E Root Cause

Lab selection and cost are downstream decisions in the plan, not locked at Month 0–1 (2026-10-08 to 2026-11-08). IEEE 299.1 applicability is assumed but not verified. No contingency path exists if the standard is rejected or a costlier alternative is required. The €20k reserve is declared but not allocated, and re-test and standard escalation scenarios are acknowledged but not costed into the plan upfront. Founder has not engaged labs pre-project to confirm cost and timeline.

## 3.6.A Issue - Presale Deposit Accounting and Cash-Flow Gate Definition Missing; Moral Hazard Risk

The cash-flow gate rule is not written. The plan states deposits are liabilities but does not define whether they pay unit cost, count toward the gate, or remain untouched. If presale deposits (€80–120k proposed target) are miscounted as operating cash, the €350k tranche is released before fulfillment and refunds are proven. If deposits are excluded, a €80k presale yields zero cash-flow contribution, and 750 quarterly units at €67 margin yield €30.25k—barely above the €25k gate with no cushion. No presale cutoff date, refund policy, or weekly accounting dashboard exists. Risk of moral hazard: founder conflates deposit inflows with operating surplus.

### 3.6.B Tags

- gate_definition
- deposit_accounting
- moral_hazard
- refund_exposure
- cash_classification

### 3.6.C Mitigation

By Month 0.5 (2026-10-23), write and publish the cash-flow gate convention: 'Operating cash surplus = delivered-unit revenue minus unit cost minus recurring opex. Presale deposits excluded; held in earmarked liability account, not touched for operations. Threshold €25k quarterly (Months 9–12 = 2027-07-08 to 2027-10-08). Measured and signed Month 12.5 (2027-10-23) by founder + external advisor.' Establish presale cutoff Month 8 (2027-06-08) in all marketing materials. Implement weekly tracking: deposit balance, refunds, and operating cash in a consolidated dashboard. Ring-fence deposits separately; any refund >€5k requires advisor review. Document governance escalation if Month 12 (2027-10-08) result falls between −€5k and +€25k (tiebreak by advisor).

### 3.6.D Consequence

If deposits are miscounted as cash flow, €350k is released prematurely while fulfillment obligations remain. Refunds spike and Year-2 funding evaporates, leaving the venture underfunded and vulnerable to cascading refund requests. Founder's capital is at risk. Regulatory review of presale terms exposes non-compliant accounting, damaging credibility. If deposits are correctly excluded but no cutoff exists, new orders trickle in through Month 12 (2027-10-08), distorting the gate measurement window.

### 3.6.E Root Cause

The plan states the gate rule conceptually but leaves the written convention as an open decision. Deposit classification, accounting treatment, and refund policy are noted but not formalized. No weekly tracking process or escalation rule is defined. Founder lacks a clear written rule to reference when presale deposits arrive, creating room for rationalization.

---

# 4 Expert: Presale & Demand-Validation Strategist

**Knowledge**: Hardware presale campaign design, multi-segment demand testing (prepper, infrastructure, privacy/forensics), deposit mechanics and refund policy, landing-page optimization and A/B testing, early-adopter community engagement, sales-cycle modeling by buyer segment, conversion rate and average-order-value benchmarking

**Why**: Presale and Demand Validation Mechanism (Decision 4) is the hub decision: it gates hard tooling (EUR 30k), informs Buyer Segment Sequencing (Decision 8), and feeds the cash-flow gate. The plan targets EUR 80k net deposits by Month 6 (2027-04-08) across three segments (prepper, infrastructure, privacy), but segment demand mix is untested and demand-pivot triggers are weak. If prepper deposits exceed 70% by Month 3 (2027-01-08), marketing budget (EUR 75k annually estimate) must shift to infrastructure and privacy. Without real-time tracking and early detection, prepper-only volume (EUR 60–80k Year-1 estimate at EUR 10–20 margin) will fail the EUR 25k cash-flow gate. This expert designs segment-specific campaigns, runs weekly tracking, and executes pivot decisions by Month 3 (2027-01-08).

**What**: By Month 1 (2026-11-08), set up three separate presale landing pages and messaging tracks (prepper solar-storm narrative; infrastructure continuity-of-operations kit; privacy/forensics RF-isolation for travel security). Implement weekly deposit tracker by segment (count, value, refund requests, average order value) starting Month 1 (2026-11-08). By Month 3 (2027-01-08), analyze conversion rate and segment mix; if prepper exceeds 70% of deposits, immediately reallocate EUR 10–15k marketing budget from prepper to infrastructure and privacy. Negotiate 1–2 fast-track infrastructure pilots (10–20 units at EUR 84/unit, delivery Month 5 = 2027-03-08) by Month 3 (2027-01-08).

**Skills**: Presale campaign copywriting and landing-page design, A/B testing and conversion optimization, customer-segment targeting and messaging, refund-rate analysis and trend spotting, sales-cycle forecasting by buyer type, pilot-customer qualification and relationship management

**Search**: hardware presale campaign multi-segment demand testing, landing page conversion optimization deposit, critical infrastructure sales cycle forecasting, customer refund rate reduction strategy

## 4.1 Primary Actions

- By Month 0.5 (2026-10-23 14:00), draft and publish the written Cash-Flow Gate Measurement Convention in final form, defining operating revenue (delivered-unit invoices only), presale deposits (escrow, excluded), threshold (€25k trailing-quarter surplus), measurement window (Months 9–12 = 2027-07-08 to 2027-10-08), presale cutoff (Month 8 = 2027-06-08), and external-advisor audit requirement by Month 12.5 (2027-10-23). Implement weekly accounting dashboard (deposits, invoices, refunds, operating cash) to be reviewed with advisor monthly. This eliminates moral hazard and governance ambiguity on tranche release.
- By Month 0.5 (2026-10-23 10:00), contact 2–3 accredited EMC laboratories (Sweden, Germany, Netherlands, Estonia) with pre-engagement consultation request to verify applicable standard (IEEE 299.1 or alternative), test frequency range, fixed cost (€15k cap), and committed report delivery (Month 5 = 2027-03-08, no later than Month 6 = 2027-04-08). By Month 1.5 (2026-11-23 17:00), sign a statement of work with chosen lab specifying fixed cost, delivery date, design-readiness review (€2–3k, 2-week turnaround by Month 4 = 2027-02-08), penalty clause (€500/week credit if slip >1 week), and re-test provision (one re-test in €15k cap). Pre-qualify backup lab by Month 2 (2026-12-08). This locks the critical-path dependency and protects the redesign reserve.
- By Month 1 (2026-11-08 09:00), commission customer research (interviews with 10–15 buyers per segment, landing-page A/B tests for three narratives: Carrington preparedness, forensics/compliance, privacy/travel security). Measure conversion rate, deposit-to-inquiry ratio, and average order value by segment weekly starting Month 1 (2026-11-08). By Month 3 (2027-01-08 16:00), identify the segment with highest deposit velocity and willingness to pay (target €120+ per unit). By Month 1.5 (2026-11-23 14:00), freeze a single flagship narrative and allocate 60% of presale marketing budget to that segment. This validates demand and eliminates segment-dilution risk.
- By Month 0.5 (2026-10-23 10:00), create a detailed monthly Year-1 spend plan allocating €400k across design (€70k Months 0–2 = 2026-10-08 to 2026-12-08), in-house rig (€40k Months 0–2 = 2026-10-08 to 2026-12-08), lab fees (€15k Months 2–5 = 2026-12-08 to 2027-03-08), soft tooling (€20k Months 2–5 = 2026-12-08 to 2027-03-08), production batch (€150–200k Months 5–12 = 2027-03-08 to 2027-10-08), marketing/sales/ops (€75k), redesign reserve (€20k, uncommitted until Month 5 = 2027-03-08). Hold all hard tooling and full production batch spending uncommitted until presale deposits ≥€80k AND lab pre-test results confirm design readiness (Month 5 = 2027-03-08). Establish monthly cash-burn review gates at Months 5 and 8 (2027-03-08 and 2027-06-08): freeze discretionary spending if cumulative overrun >10% (€40k at Month 5 = 2027-03-08, €120k at Month 8 = 2027-06-08). Preserve minimum €30k redesign contingency. This enforces stage-gate discipline and prevents irreversible spend before evidence.
- By Month 1 (2026-11-08 14:00), commission a product-compliance attorney (EU expertise, EMC Directive and General Product Safety Directive focus) to deliver a written legal opinion addressing: (1) EMC Directive applicability, (2) CE marking requirement, (3) applicable harmonized standards, (4) consumer-protection rules and warranty exposure, (5) liability scope if shielding claims are exceeded in a real event. By Month 2 (2026-12-08 16:00), obtain a preliminary product-liability insurance quote (€250–500k coverage estimate); insurer must confirm Faraday-enclosure claims are insurable and identify exclusions. Lock insurance terms by Month 2.5 (2026-12-23 15:00). Publish scope-limitation language (legal-approved) on all presale materials and packaging: 'This enclosure protects stored spare devices against RF exposure. It does not protect active equipment or guarantee protection in an actual Carrington-class solar storm.' This mitigates regulatory, liability, and claim-substantiation risk.

## 4.2 Secondary Actions

- By Month 1 (2026-11-08 12:00), identify and pre-qualify one secondary precision-metal fabricator in Tallinn or nearby (Estonia, Latvia) with ISO certification and laser/CNC capability. Conduct trial batch (50–100 units) by Month 2 (2026-12-08 14:00) to test accuracy (±0.1 mm tolerance) and consistency. By Month 1 (2026-11-08 15:00), lock Year-1 fabrication pricing and capacity reservation with primary supplier (signed agreement): unit cost caps (no increase >10% without 30-day notice), reserved capacity (500–1,000 units), contractual remedy (€500/week credit for delays >5 days). Source conductive-gasket material from two qualified suppliers by Month 1.5 (2026-11-23 16:00); hold 30-day buffer stock (€5–10k estimate) before production release. Maintain live supply-chain risk register (lead times, pricing, capacity, supplier signals); if primary supplier signals price increase >10% or capacity loss by Month 6 (2027-04-08 12:00), trigger transition to secondary and accelerate first production run by 2–4 weeks. This de-risks fabrication and prevents supply-chain cascades.
- By Month 1 (2026-11-08 11:00), draft and publish presale terms covering: presale order process, 30-day refund-for-fit/quality guarantee, 2–3 week ship SLA (4–5 week estimated delivery), escalation path (48-hour response), and device-fit disclaimer. By Month 1.5 (2026-11-23 13:00), publish a detailed Product Fit Guide with photos and dimensions (internal 420 x 280 x 50 mm estimate), showing which laptop models (13", 15", 17" examples) and phone sizes (4.5"–6.5" estimate) fit, and explicit 'Does Not Fit' examples. Link Fit Guide on all presale pages and in packaging. By Month 7 (2027-05-08 16:00), if fit complaints exceed 10% of orders, investigate root cause and determine remediation (size variant, redesign, or refund program). If refund rate exceeds 20% by Month 6 (2027-04-08 15:00), trigger messaging review and adjust presale pricing or positioning if necessary. This manages customer expectations and reduces refund cascades.
- By Month 1 (2026-11-08 09:00), establish three separate presale tracking channels (Prepper Networks, Infrastructure Buyers, Privacy/Forensics) with distinct landing pages and value propositions. Measure weekly: deposit count, total deposit value, refund requests, average order value by segment. Target combined deposits €80–120k by Month 6 (2027-04-08 17:00); segment targets: Prepper 40–50% deposit rate / €50–70 AOV, Infrastructure 30–40% / €200–300+ AOV, Privacy/Forensics 35–45% / €80–150 AOV. By Month 3 (2027-01-08 16:00), if Prepper segment exceeds 70% of total deposit value, reallocate €10–15k from Prepper to Infrastructure and Privacy channels; pivot messaging to emphasize business-continuity and data-protection angles. By Month 3 (2027-01-08 12:00), negotiate 'fast-track' pilot agreements with 1–2 infrastructure buyers: 10–20 units at cost plus 20% (€84/unit estimate), delivery Month 5 (2027-03-08 15:00), feedback by Month 6 (2027-04-08 12:00), with reference-use and testimonial rights. This validates demand mix and generates early infrastructure revenue.
- By Month 4 (2027-02-08 10:00), prepare a design-readiness dossier for the accredited lab documenting: enclosure material (aluminium/steel, thickness), seam/lid closure design (gasket type, compression, cycle repeatability), in-house rig performance (attenuation values at 50 MHz, 100 MHz, 500 MHz, 1 GHz across three prototype builds), test plan, and prototype photos. Submit dossier by Month 4.5 (2027-02-23 14:00) and request technical review meeting (Month 5 = 2027-03-08 10:00) to confirm design readiness and obtain preliminary attenuation feedback. If design-readiness review shows attenuation shortfall in one or more frequency bands, by Month 5 (2027-03-08 17:00) choose: (A) narrow marketing-claim scope to exclude weak bands, or (B) commit to design iteration and re-qualification (1-month delay, Month 6 = 2027-04-08). Document decision and proceed to formal sample submission. This prevents failed formal testing and protects the redesign reserve.
- By Month 1 (2026-11-08 15:00), create a written decision framework documenting presale-shortfall pivot options: if deposits <€80k by Month 6 (2027-04-08 16:00), trigger one of three actions: (A) reduce presale pricing by 15–20%, (B) reallocate €10–15k from tooling budget to marketing (privacy/infrastructure segments), or (C) extend presale window to Month 10 (2027-08-08) at most. If deposits remain <€80k at Month 8 (2027-06-08), no hard tooling is released and tranche is expected to be withheld; founder reviews wind-down options. Document trigger conditions and pivot options so team and advisor agree upfront on decision points rather than improvising under cash pressure.
- By Month 6 (2027-04-08 12:00), publish the full accredited lab shielding report (full frequency-sweep data, attenuation table at key frequencies, test conditions) with every unit sold (digital copy in packaging, online accessible). Create a Customer Scope Sheet (1–2 pages) restating measured frequency range, attenuation values (not extrapolated), and liability disclaimer. Ensure all presale and post-sale marketing links to the lab report and scope sheet to demonstrate claim substantiation and reduce consumer-law exposure. This builds credibility and transparency with buyers and regulators.

## 4.3 Follow Up Consultation

At the next consultation (propose Month 1 = 2026-11-08), bring: (1) signed lab statement of work with fixed cost €15k, delivery Month 5 (2027-03-08), and penalty clause; (2) written Cash-Flow Gate Measurement Convention approved by external advisor; (3) legal opinion (draft) on EMC Directive and product-safety applicability, and preliminary insurance quote; (4) presale landing-page A/B test results (conversion rate, deposit-to-inquiry ratio, average order value by segment); (5) customer research findings (willingness to pay, procurement timeline by segment); (6) monthly Year-1 spend plan with presale-shortfall pivot options and decision triggers. Key discussion topics: (A) confirm which buyer segment has validated demand and wins 60% marketing budget allocation by Month 1.5 (2026-11-23); (B) review lab pre-engagement consultation (standard applicability, cost, timeline); (C) review legal opinion and set scope-limitation language for all presale materials; (D) establish external-advisor role in monthly cash-burn and Month 12.5 (2027-10-23) gate sign-off; (E) confirm supply-chain pre-qualification (secondary fabricator, gasket suppliers, pricing locks). Core risk: missing any of these five actions compresses the presale window and invites the €10–35k lab overrun, supply shock, or demand-mix skew to derail the €400k plan and cash-flow gate by Month 6–8 (2027-04-08 to 2027-06-08).

## 4.4.A Issue - Killer Application Undefined—Demand Signal Is Fragmented Across Three Untested Segments

The plan positions the enclosure across three buyer segments (Prepper, Infrastructure, Privacy/Forensics) without evidence that any single segment will dominate or sustain positive cash flow. Presale messaging is split and diluted. Month 3 (2027-01-08) tracking is proposed but no pre-commitment commercial validation (landing-page tests, customer interviews, willingness-to-pay research) has been done. This leaves the €80k deposit gate at risk of being met by low-margin prepper units (€15/unit estimated) that cannot support the €25k cash-flow threshold. Infrastructure procurement cycles are too slow for Year-1 closure; Privacy/Forensics buyers are unvalidated. Without a clear flagship buyer persona locked by Month 1 (2026-11-08), presale marketing will scatter cash and messaging, missing the presale window.

### 4.4.B Tags

- demand_validation_incomplete
- segment_prioritization_missing
- messaging_dilution
- killer_app_unvalidated

### 4.4.C Mitigation

By Month 0.5 (2026-10-23), commission two customer research activities in parallel: (A) interview 10–15 prepper, infrastructure, and forensics buyers on willingness to pay, procurement timeline, and feature priority; (B) design three separate landing-page tests (one per segment) with distinct value propositions (Carrington preparedness vs. forensics/compliance vs. privacy/travel security) and measure conversion rate and deposit-to-inquiry ratio weekly by segment. By Month 1 (2026-11-08), identify which segment has the shortest sales cycle, highest willingness to pay (target €120+ per unit), and fastest deposit velocity. Allocate 60% of presale marketing budget to that segment; treat other segments as secondary. Lock a single flagship narrative by Month 1.5 (2026-11-23) and freeze messaging changes to preserve coherence.

### 4.4.D Consequence

Without a validated killer app, presale deposits will likely skew prepper-heavy (low margin €15/unit), cash flow will fall short of the €25k gate by €10–20k, the €350k tranche is withheld, and the venture winds down or enters an unplanned 90-day gate extension with no clear path to sustainability. Wasted presale marketing spend (~€20–30k estimate) and reputational confusion (prepper vs. corporate messaging) will dilute brand equity and credibility with later infrastructure buyers.

### 4.4.E Root Cause

The strategic context assumes multi-use RF-isolation positioning but has not validated which use case buyers will actually pay for or commit to first. The plan was designed as a risk-hedging portfolio (three segments) rather than a commitment to a single compelling narrative. Without real customer signal before presale launch, the Presale and Demand Validation Mechanism becomes a lottery bet on segment mix, not a signal of true demand.

## 4.5.A Issue - Cash-Flow Gate Definition Is Ambiguous on Presale Deposit Treatment—Moral Hazard Risk on €350k Tranche Release

The plan states that 'presale deposits are liabilities' and 'excluded from the cash-flow gate,' but does not define whether a deposit can be netted against the unit cost of the matching order for cash-accounting purposes. The gate rule is 'operating cash surplus ≥ €25k quarterly,' but it is unclear whether deposits held in escrow count as inflows when the unit ships, or only when the unit is paid post-delivery. If deposits are counted as cash on shipment, a vendor who collects €80k in deposits for 535 units can ship 400 units in Q4, net €60k in cash flow (400 × €149 – 400 × €82 from deposits minus €20k opex), and trigger the tranche release even though only 400 units of the 1,500-unit Year-1 plan were delivered. This creates a perverse incentive to game the gate by front-loading presales and under-delivering before Month 12.5 (2027-10-23), leaving Year-2 obligations unfunded.

### 4.5.B Tags

- gate_definition_ambiguous
- deposit_accounting_unclear
- moral_hazard_tranche_release
- cash_flow_measurement_loophole

### 4.5.C Mitigation

By Month 0.5 (2026-10-23), publish a written Cash-Flow Gate Measurement Convention that explicitly defines: (1) 'Operating revenue' = cash received from customers for delivered and accepted units (invoiced, not deposited). (2) 'Presale deposits' = held in earmarked escrow account, not counted as revenue until unit ships and invoice is issued. (3) 'Measurement window' = Months 9–12 (2027-07-08 to 2027-10-08) trailing quarter; measure as: (total delivered-unit invoices received minus direct unit costs and recurring opex) ≥ €25k by Month 12.5 (2027-10-23). (4) 'Presale cutoff' = no new deposits accepted after Month 8 (2027-06-08); existing deposits can be fulfilled post-cutoff but no new liabilities are created. (5) Implement weekly accounting dashboard tracking deposits (escrow), delivered units (invoiced), refund requests, and operating cash separately. Have external advisor audit the gate measurement by Month 12.5 (2027-10-23) before tranche release.

### 4.5.D Consequence

Ambiguous gate definition creates regulatory and founder-liability risk: if the €350k is released on ambiguous cash-flow signal and Year-2 refund or fulfillment obligations exceed expectation, the founder may be accused of gaming the gate or misrepresenting cash flow to stakeholders. Loose definition also incentivizes under-delivery in Q4 to boost short-term cash-flow appearance, leaving customer commitments unfunded and creating refund cascades. This could trigger reputational damage, legal exposure under consumer-protection rules, and loss of founder credibility.

### 4.5.E Root Cause

The plan distinguishes presale deposits as 'liabilities' but does not operationalize that distinction in the gate-measurement logic. The €25k gate was sized on a 750-unit/quarter base case assumption (€30.25k estimate), but that math assumes all 750 units are delivered and invoiced in the gate window. If deposits inflate the appearance of cash flow without corresponding delivery, the math breaks down. The founder has not published a clear governance rule before presale launch, so buyers and stakeholders may have different mental models of what 'positive cash flow' means.

## 4.6.A Issue - Accredited Lab Cost, Timeline, and Standard Are Not Locked—€10–20k Overrun and 4–8 Week Slip Compress Design and Presale Window

The plan states 'one accredited EMC validation' with a €15k cost cap and Month 5 (2027-03-08) delivery, but no statement of work has been signed, no specific laboratory has been selected, and the applicable standard (IEEE 299.1 or equivalent) is not verified by any lab. Lab consultation feedback is treated as a future action ('contact 2–3 labs by Month 0.5 = 2026-10-23'). Without a signed fixed-price, fixed-date agreement by Month 1.5 (2026-11-23), a €10–20k cost overrun (lab charges €25–35k instead of €15k) and a 4–8 week schedule slip (report arrives Month 7 = 2027-05-08 instead of Month 5 = 2027-03-08) are realistic risks. This compresses the redesign buffer (the 20k reserve is consumed), delays hard-tooling release past Month 6 (2027-04-08), and leaves only 2–3 months to deliver 1,500 units by Month 12 (2027-10-08), making the delivery commitment impossible. The presale cutoff at Month 8 (2027-06-08) becomes unachievable if the lab report is not in hand until Month 7 (2027-05-08).

### 4.6.B Tags

- lab_standard_unverified
- lab_cost_unfixed
- lab_timeline_not_committed
- schedule_risk_high
- presale_window_compressed

### 4.6.C Mitigation

By Month 0.5 (2026-10-23), contact 2–3 accredited EMC laboratories (Sweden, Germany, Netherlands, Estonia recommended) with a pre-engagement consultation request: provide a no-cost technical review of the test methodology (IEEE 299.1 or alternative standard for small enclosures), frequency range (100 kHz–1 GHz estimated), test cost (fixed cap €15k), and committed report delivery date. Request design-readiness review (€2–3k estimate, 2-week turnaround) by Month 4 (2027-02-08) to confirm prototype meets test requirements before formal sample submission. By Month 1.5 (2026-11-23), sign a fixed-price statement of work with chosen lab specifying: cost cap €15k (with penalty clause: €500/week credit against invoice if delivery slips >1 week past Month 5 = 2027-03-08), delivery date Month 5 (2027-03-08, latest Month 6 = 2027-04-08), and re-test provision (if design fails initial test, one re-test included in €15k cap, additional re-tests at €8–10k each). Pre-qualify a backup lab by Month 2 (2026-12-08) with similar terms, usable if primary lab delays.

### 4.6.D Consequence

Without a locked lab agreement, the €20k redesign reserve is at risk of being consumed entirely by lab overruns, leaving zero contingency for any other Year-1 surprise (supplier price increase, production defect, refund spike). A 4–8 week lab delay (realistic without a signed SoW) pushes the report to Month 7 (2027-05-08), which misses the hard-tooling gate decision at Month 6 (2027-04-08), delays first-batch production from Month 7 (2027-05-08) to Month 9 (2027-07-08), and leaves only 1 month to deliver 1,500 units before the Month 12 (2027-10-08) cash-flow gate measurement. This is operationally impossible, forcing the presale cutoff to slip or the delivery commitment to break, triggering refund requests and gate failure.

### 4.6.E Root Cause

The plan assumes standard academic planning practice (build the prototype, then shop for a lab), but does not lock cost and timeline until Month 1.5 (2026-11-23), which is already 6 weeks into the Year-1 window. Accredited labs operate on booked schedules and fixed pricing; waiting until Month 1 (2026-11-08) to confirm availability and cost is too late to ensure Month 5 (2027-03-08) delivery without paying premium expedited fees (€5–10k estimate for rush handling). The plan does not treat the lab as a critical-path dependency with upfront commitment; instead it treats it as a variable cost to be negotiated later, which is incompatible with a fixed €400k cap and tight delivery timeline.

---

# 5 Expert: Financial Modeler & Cash-Flow Gate Auditor

**Knowledge**: Hardware product unit economics, cash-flow modeling and waterfall analysis, working-capital management (presale deposits, inventory, payables), Year-1 burn sequencing and monthly cash reviews, contingency and reserve accounting, cash-flow gate rule design and measurement, tranche-release governance, sensitivity analysis and downside scenarios

**Why**: The plan's viability hinges on three financial gatekeeping decisions: (1) Year-1 Burn Sequencing (Decision 5) orders EUR 400k (user constraint) to protect redesign flexibility, but free contingency is only EUR 20k (estimate) with zero production headroom; (2) Cash-Flow Gate Measurement Convention (Decision 10) defines when EUR 350k follow-on unlocks, but the rule is not yet published and presale deposits are unclassified (open decision: whether they fund unit cost); (3) presale deposits must fund hard tooling at EUR 80k (proposed threshold), but deposit-to-revenue timing is unclear (refund cap 15% by Month 8 = 2027-06-08; presale cutoff Month 8 = 2027-06-08). A lab re-test (8–15k estimate) plus a costlier standard (10–20k estimate) creates a 35k scenario against 20k reserve—a 15k gap with no source. This expert publishes the cash-flow gate rule before presale launch (Month 0.5 = 2026-10-23), runs monthly cash reviews at design milestones (Months 2, 5, 8, 12 = 2026-12-08, 2027-03-08, 2027-06-08, 2027-10-08), and flags variances >10% for decision.

**What**: By Month 0.5 (2026-10-23), draft and publish the cash-flow gate measurement convention: operating cash surplus = receipts from delivered units minus direct unit costs minus recurring opex (presale deposits excluded); threshold EUR 25k (proposed threshold) trailing-quarter surplus; measurement window Months 9–12 (2027-07-08 to 2027-10-08); sign-off by founder + external advisor by Month 12.5 (2027-10-23). Establish separate accounting for presale deposits (liabilities, earmarked account). Create detailed monthly Year-1 budget spend plan (Months 0–12 = 2026-10-08 to 2027-10-08) and cash-burn reserve hierarchy. Run monthly cash reviews at Months 2, 5, 8, 12 (2026-12-08, 2027-03-08, 2027-06-08, 2027-10-08) (design, pre-test, presale gate, cash-flow gate); flag variances >10% (EUR 40k Month 5 = 2027-03-08, EUR 120k Month 8 = 2027-06-08) and freeze discretionary spending pending variance explanation.

**Skills**: Monthly cash waterfall modeling, working-capital forecasting (payables, inventory, deposits), contingency reserve accounting and release triggers, gate rule definition and tiebreak governance, sensitivity analysis and worst-case scenarios, fund-tranche release criteria and audit trail

**Search**: hardware startup cash flow modeling Year 1 burn, presale deposit accounting liability, contingency reserve management manufacturing, cash gate trigger definition funding tranche

## 5.1 Primary Actions

- By Month 0.5 (2026-10-23), contact 2–3 accredited EMC labs and lock a signed statement of work specifying test standard, cost (€15k cap), design-readiness review (€2–3k, Month 4 = 2027-02-08), and report delivery date (Month 5 = 2027-03-08, no later than Month 6 = 2027-04-08). Confirm standard applicability (IEEE 299.1 or alternative) with lab before committing.
- By Month 0.5 (2026-10-23), draft and publish the cash-flow gate convention in writing, defining: (a) operating cash flow = delivered-unit receipts minus unit cost minus opex, excluding presale deposits; (b) threshold €25–30k quarterly (Month 9–12 = 2027-07-08 to 2027-10-08); (c) presale cutoff Month 8 (2027-06-08); (d) tiebreak rule (ambiguous ±5k range); founder + external advisor sign-off by Month 12.5 (2027-10-23).
- By Month 1 (2026-11-08), establish three presale tracking channels (Prepper, Infrastructure, Privacy/Forensics) with separate landing pages, deposit tracking, and weekly dashboard. Define pivot trigger: if prepper deposits exceed 70% by Month 3 (2027-01-08), reallocate €10–15k marketing budget to infrastructure and privacy, and negotiate 1–2 fast-track infrastructure pilots (10–20 units, delivery Month 5 = 2027-03-08).
- By Month 1 (2026-11-08), commission legal opinion on EU product-rule applicability (EMC Directive, General Product Safety Directive, CE marking requirements, liability exposure) and obtain preliminary product-liability insurance quote (€250–500k estimate). Lock insurance terms by Month 2.5 (2026-12-23).
- By Month 0.5 (2026-10-23), allocate the €20k redesign reserve explicitly as uncommitted contingency, held separate from all other spend. If lab cost or standard escalates, decide immediately whether to (a) raise reserve to €30k by cutting marketing €10k, (b) defer follow-on batch by €5–10k, or (c) extend gate measurement by 90 days if redesign is triggered after Month 5 (2027-03-08).

## 5.2 Secondary Actions

- By Month 1 (2026-11-08), pre-qualify a secondary precision-metal fabricator in Tallinn/Estonia with ISO certification and run a trial batch (50–100 units) to confirm tolerance and quality parity. Lock primary fabricator pricing and capacity in a signed agreement with penalty clauses for price increases >10% or delays >5 days.
- By Month 1.5 (2026-11-23), source conductive-gasket material from two qualified suppliers and hold 30-day buffer stock (€5–10k estimate in inventory) before production release to prevent supply disruption.
- By Month 1 (2026-11-08), publish presale terms of service, including: 30-day money-back guarantee (fit/quality), delivery SLA (ships within 2–3 weeks, estimated delivery 4–5 weeks, date range quoted at order), escalation path (48-hour response target), and device-fit responsibility disclaimer (customer verifies compatibility using published fit guide).
- By Month 1.5 (2026-11-23), publish a Product Fit Guide with photographs and dimensions (internal ~420 × 280 × 50 mm estimate), showing which laptop models (13", 15", 17" examples) and phone sizes (4.5"–6.5" estimate) fit, with explicit "Does Not Fit" examples (e.g., MacBook Pro 16-inch) to set realistic expectations.
- By Month 4 (2027-02-08), submit a design-readiness dossier to the accredited lab documenting materials, seam/lid design, in-house rig attenuation results (at 50 MHz, 100 MHz, 500 MHz, 1 GHz across three prototype builds), and test plan. Request preliminary feedback on attenuation expectations vs. marketing claims.
- By Month 6 (2027-04-08), establish a weekly cash-burn review gate: if cumulative spend exceeds plan by >10% (€40k at Month 5 = 2027-03-08, €120k at Month 8 = 2027-06-08), freeze discretionary spending and investigate variance. Preserve minimum €30k (estimate) runway for unexpected redesign or retest.
- By Month 3 (2027-01-08), measure presale segment mix weekly and publish tracker to founder and advisor. If prepper deposits exceed 70%, trigger marketing pivot (€10–15k reallocation to infrastructure and privacy) and negotiate infrastructure pilots with fast-track delivery (Month 5 = 2027-03-08).
- By Month 8 (2027-06-08), set presale-order cutoff date in all presale materials and customer communications, ensuring early-order fulfillment is completed and revenue is received before Month 12 (2027-10-08) gate measurement window.

## 5.3 Follow Up Consultation

Next review: Month 1 (2026-11-08). Agenda: (1) Accredited lab statement of work signed or pending; confirm cost, standard, report date. (2) Cash-flow gate convention published and founder/advisor sign-off obtained. (3) Presale channels live; first week of deposit data reviewed; segment targeting confirmed. (4) Legal opinion on product-rule applicability received; insurance quote locked. (5) Secondary fabricator trial batch in progress; gasket supplier and buffer stock secured. (6) Design prototype ready for lab pre-engagement review (Month 4 = 2027-02-08 target). (7) Contingency reserve segregated and decision rule for escalation documented. Escalate any lab cost or schedule signals >10% variance immediately; segment demand data informs Month 3 (2027-01-08) pivot decision.

## 5.4.A Issue - Cash-Flow Gate Definition Remains Dangerously Loose; Presale Deposits Risk Miscounting as Operating Cash

The plan states deposits are 'liabilities' but does not bind the gate rule in writing before presale launch. Without explicit pre-published definition, there is moral hazard: deposits received early can be rationalized as 'cash flow' when the gate is measured, triggering premature release of the €350k tranche before fulfillment obligations are proven. If 30% of deposits convert to refunds in Months 10-12 (2027-08-08 to 2027-10-08), the operating cash will be negative and the refund liability will exhaust the presale account. Ambiguity creates founder conflict-of-interest: personal interest in declaring gate success can override rigorous accounting.

### 5.4.B Tags

- gate_governance
- presale_accounting
- moral_hazard
- tranche_release_risk

### 5.4.C Mitigation

By Month 0.5 (2026-10-23), draft and publish the cash-flow gate convention in writing, signed by founder and reviewed by an external advisor. Define: (a) 'operating cash flow' = receipts from delivered and paid units minus direct unit cost minus recurring opex, excluding all presale deposits; (b) threshold €25k quarterly surplus (Month 9-12 = 2027-07-08 to 2027-10-08 period); (c) presale cutoff at Month 8 (2027-06-08) ensuring early orders clear fulfillment and refund by gate measurement; (d) tiebreak rule for ambiguous results (±5k of threshold). Establish separate earmarked account for deposits with weekly tracking dashboard. Lock insurance by Month 2.5 (2026-12-23) to clarify refund liability coverage.

### 5.4.D Consequence

Without a pre-published, binding gate rule, the founder may release €350k based on deposit inflows that are later consumed by refund requests, leaving Year-2 underfunded and exposed to refund cascades. Regulatory or advisor challenge to gate sign-off could delay or block tranche release, stranding inventory and marketing spend. Reputational damage if refunds surge and customers perceive breach of cash-flow promise.

### 5.4.E Root Cause

The plan acknowledges gate risk but defers the governance definition to 'Month 0.5 (2026-10-23)' as an action item rather than a non-negotiable prerequisite. Presale deposit mechanics and exclusion from cash-flow definition are stated as decisions but not yet locked in signed documentation. Founder may lack motivation to write a rule that could block their own tranche release if cash-flow target is missed.

## 5.5.A Issue - Presale Demand Mix Tracking and Segment Pivot Logic Are Undefined; Prepper Over-Concentration Risk Is Unmitigated

The plan correctly identifies that prepper volumes alone (€60-80k Year-1 estimate at €10-20 margin per unit) fall short of the €25-30k (estimate) cash-flow gate. However, no mechanism exists to detect and correct this risk before hard-tooling commitment (Month 6 = 2027-04-08). Without weekly segment tracking and a decision trigger at Month 3 (2027-01-08), the founder will not know whether prepper deposits dominate until after tooling is committed. A pivot to infrastructure or privacy segments at Month 3 (2027-01-08) allows corrective marketing spend reallocation (€10-15k budget shift), but the plan does not define trigger conditions, segment tracking channels, or decision authority.

### 5.5.B Tags

- demand_validation
- segment_mix_risk
- margin_squeeze
- gate_threshold

### 5.5.C Mitigation

By Month 1 (2026-11-08), establish three separate presale landing pages and deposit tracking channels: Prepper (Carrington/solar-storm narrative), Infrastructure (continuity-of-operations kit), Privacy/Forensics (RF-isolation and data-protection angle). Track weekly: deposit count, total value, average order value (AOV), and refund requests by segment. Publish a live tracker dashboard for founder and advisor review. Define trigger: at Month 3 (2027-01-08), if prepper deposits exceed 70% of total, immediately reallocate €10-15k marketing budget to infrastructure and privacy, launch parallel pilots (1-2 infrastructure buyers, 10-20 units, delivery by Month 5 = 2027-03-08), and measure corrective impact by Month 6 (2027-04-08).

### 5.5.D Consequence

If prepper deposits dominate (70%+) and the founder does not detect until Month 6 (2027-04-08), hard tooling is already committed. Presale-funded production then ramps on low-margin units (€15/unit estimate), leaving quarterly surplus at €11-15k, below the €25-30k (estimate) gate. Cash flow misses gate, tranche is withheld, and inventory carrying cost eats remaining cash, forcing wind-down or distressed asset sale. Year-2 product development and market expansion (€350k allocated) never begins.

### 5.5.E Root Cause

The plan identifies the risk ('prepper-heavy demand is low-margin') and proposes a mitigation ('shift marketing if preppers exceed 70%') but does not operationalize it. No presale channel exists yet, no weekly tracking discipline is defined, and no pivot decision rule (threshold, authority, budget reallocation) is formalized. Founder lacks early-warning system, so corrective action window (Months 3-6 = 2027-01-08 to 2027-04-08) is lost.

## 5.6.A Issue - Accredited Lab Selection, Cost, and Timeline Are Not Locked; Cost or Schedule Slip Jeopardizes Design Iteration Buffer and Presale Fulfillment Window

The plan caps accredited EMC lab cost at €15k and targets a report by Month 5 (2027-03-08), but no lab has been contacted, no standard (IEEE 299.1 or alternative) has been confirmed, and no signed statement of work exists. A €10-20k cost overrun (estimate) or 4-8 week delay compresses the design-iteration buffer (only €20k redesign reserve) and the fulfillment window before the Month 8 (2027-06-08) presale cutoff. If the lab requires a costlier standard (e.g., MIL-STD-285, not verified) or a re-test after failed initial results, the reserve is depleted and €15k+ is unfunded. The plan acknowledges this fallback risk but has not locked any mitigation.

### 5.6.B Tags

- lab_cost_uncertainty
- schedule_compression
- redesign_reserve_risk
- test_standard_applicability

### 5.6.C Mitigation

By Month 0.5 (2026-10-23), contact 2-3 accredited EMC laboratories (Germany, Sweden, Netherlands, Estonia) for no-cost pre-engagement consultation confirming applicable RF shielding standard, frequency range (e.g., 100 kHz to 1 GHz), cost cap (lock at €15k or identify overrun source), and committed report delivery date (Month 5 = 2027-03-08). Request design-readiness review (€2-3k estimate, 2-week turnaround) to be delivered by Month 4 (2027-02-08), confirming prototype meets test methodology and providing preliminary attenuation feedback. Secure signed statement of work by Month 1.5 (2026-11-23) specifying cost, timeline, re-test provision, and penalty for schedule slip (e.g., €500/week credited against invoice). Pre-qualify secondary lab by Month 2 (2026-12-08) as backup.

### 5.6.D Consequence

Lab cost surprise (€10-20k overrun estimate) or delay (+4-8 weeks estimate) exhausts the €20k redesign reserve, leaving zero contingency for design iteration or re-qualification. If attenuation falls short of marketing claims after first test, re-test is unfunded and hard-tooling commitment is delayed past Month 6 (2027-04-08) gate, triggering presale cutoff extension and cash-flow gate risk. If lab requires CE/notified-body work (€10-30k estimate, not budgeted) on top of testing, funding gap grows to €25-50k with zero production headroom to absorb it.

### 5.6.E Root Cause

The plan treats lab selection as a background activity ('by Month 0.5 = 2026-10-23' action item) rather than a critical path blocker. No pre-engagement has occurred, no standard has been validated with a lab, and no cost or schedule risk reserve has been segregated. The plan assumes IEEE 299.1 applicability without verification and treats re-test risk as a 'fallback' rather than a base-case planning scenario.