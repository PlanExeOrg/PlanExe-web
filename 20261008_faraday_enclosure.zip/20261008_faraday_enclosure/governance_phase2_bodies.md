### 1. Project Steering Committee

**Rationale for Inclusion:** Capital-constrained, two-tranche hardware venture with high strategic and financial risk. The EUR 400k Year-1 cap and conditional EUR 350k follow-on create non-negotiable decision gates: tooling release gated on presale deposits and lab validation, and tranche release gated on measured positive cash flow. A Steering Committee provides strategic oversight of the sequencing decisions (Shielding Proof Standard, Year-1 Burn, Presale Validation, Cash-Flow Gate) and ensures evidence-gated spending protects the founder's personal capital. Essential for a solo-funded founder facing irreversible commitments.

**Responsibilities:**

- Approve the cash-flow gate measurement convention and define positive-cash-flow threshold (Month 0.5 = 2026-10-23)
- Approve Year-1 budget allocation across design, lab, tooling, production and marketing; monitor spending vs. plan and approve material changes (>10% variance)
- Gate the hard-tooling release decision: confirm presale deposits ≥ EUR 80k, accredited lab pre-test readiness, and in-house rig validation before tooling is committed (Month 5–6 = 2027-03-08 to 2027-04-08)
- Review and approve any spending above EUR 5k outside the original allocation or any EUR 20k redesign reserve drawdown
- Approve segment-sequencing pivots if presale deposits are prepper-heavy (>70% by Month 3 = 2027-01-08) or total conversion falls below 40% (estimated threshold)
- Measure and approve cash-flow gate result (EUR 25k threshold, proposed) at Month 12.5 (2027-10-23) and recommend tranche release or withheld decision to founder

**Initial Setup Actions:**

- Draft and publish the written cash-flow gate measurement convention (definition, threshold, measurement window, tiebreak rule) by Month 0.5 (2026-10-23)
- Create the monthly Year-1 burn schedule (EUR 400k allocation across design, lab, tooling, production, marketing, reserves) by Month 0.5 (2026-10-23)
- Recruit one external advisor (accountant or experienced mentor) to co-sign gate result and serve as independent second opinion on tranche release
- Establish monthly cash-reconciliation review cadence with founder and advisor
- Document decision-escalation thresholds (e.g., hard-tooling gate logic, spending freeze triggers, pivot decision criteria) in a written governance charter by Month 0.5 (2026-10-23)

**Membership:**

- Founder / project principal
- External financial advisor (accountant or experienced mentor, independent)

**Decision Rights:** Strategic decisions above EUR 5k and all gate decisions (tooling release, spending freeze triggers, tranche measurement, segment pivots). Threshold: Any decision affecting the EUR 400k cap, presale validation, or cash-flow gate outcome. Decisions below EUR 5k (routine supplies, marketing micro-adjustments) are delegated to operations.

**Decision Mechanism:** Consensus preferred; if consensus cannot be reached on the gate result (Month 12.5 = 2027-10-23), founder has final authority (tiebreak) to release tranche or withhold. For operational decisions above EUR 5k, founder proposes and advisor signs off or escalates to full committee within 3 business days. For gate result, written measurement record is prepared by Month 12.5 (2027-10-23) and both founder and advisor sign off, or document dissent.

**Meeting Cadence:** Monthly (typically 1 hour, last week of month). Emergency meetings on request if spending variance exceeds 10%, presale conversion falls below 40% (estimated), or cash balance threatens runway. Special review at Month 5 (2027-03-08) for lab-report assessment and tooling gate decision.

**Typical Agenda Items:**

- Actual vs. budgeted spending (design, lab, tooling, production, marketing) and variance explanation
- Presale deposit velocity, refund rate, and segment mix (prepper, infrastructure, privacy); pivot triggers assessed
- Lab status and pre-test readiness (Month 4–5 = 2027-02-08 to 2027-03-08)
- Hard-tooling gate decision criteria confirmed (deposits ≥ EUR 80k, lab pre-test OK, in-house rig passed twice) (Month 5–6 = 2027-03-08 to 2027-04-08)
- Quarterly cash-flow projection and months of runway remaining
- Any unbudgeted items, overruns, or requests to reallocate reserve funds

**Escalation Path:** All unresolved strategic issues (gate disputes, major budget changes, segment pivots, tranche decisions) escalate to founder with advisor concurrence. If founder and advisor cannot agree on gate result, the dissent is documented and founder retains decision authority; the decision is recorded in writing with both parties' signatures. No escalation beyond this structure exists (no board, no external funder); the founder is the ultimate decision-maker within the framework.
### 2. Design and Certification Working Group

**Rationale for Inclusion:** Shielding effectiveness and EMC validation are the core technical risks. The plan gates hard tooling on accredited lab pre-test confirmation and in-house rig validation, meaning design iteration and certification readiness directly drive the tooling release (Month 5–6 = 2027-03-08 to 2027-04-08). This group oversees the critical path: prototype design, in-house shielding rig (two independent cycles), accredited lab engagement, and any design changes forced by lab results. It also manages the EUR 20k redesign reserve and ensures claim-to-evidence alignment for compliance.

**Responsibilities:**

- Coordinate prototype design and RF shielding analysis with the independent EMC consultancy (EUR 20–25k, milestone-based)
- Oversee the in-house shielding test rig setup, validation methodology, and execution of two independent seam cycles by Month 3 (2027-01-08)
- Manage the accredited EMC laboratory engagement: select lab, obtain fixed-cost statement of work by Month 1.5 (2026-11-23), conduct design-readiness review (Month 4 = 2027-02-08), submit samples, and receive report (Month 5 = 2027-03-08)
- Assess lab pre-test results for design readiness; if readiness is not confirmed, escalate redesign scope and cost impact to Steering Committee
- If accredited lab results fall short of claims or show design issues, manage the redesign trade-off: scope (claim narrowing) vs. rework (cost and timeline impact) vs. retry
- Ensure all marketing claims and scope statements are aligned with measured lab data; publish the accredited lab report with every unit sold
- Track compliance with the single-SKU rigid-metal enclosure architecture and flag any design changes that require re-qualification

**Initial Setup Actions:**

- Lock the EMC consultancy milestone agreement with fixed deliverables, cost (EUR 20–25k cap) and timeline (prototype review Month 2 = 2026-12-08, lab coordination Month 4 = 2027-02-08) by Month 0.5 (2026-10-23)
- Finalize the university lab co-development partnership with written agreement covering measurement access, rig capital (EUR 5–10k estimate), consumables budget, timeline and IP/publication rights by Month 0.5 (2026-10-23)
- If university partnership is not confirmed by Month 1.5 (2026-11-23), hire a part-time RF engineer (0.5 FTE, EUR 25k Year-1 estimate) immediately to preserve design timeline
- Conduct pre-engagement consultations with 2–3 accredited EMC labs (Germany, Sweden, Netherlands, or Estonia) to confirm applicable standard, frequency range, test methodology and cost by Month 0.5 (2026-10-23)
- Select the accredited lab and obtain fixed-cost statement of work (cost locked, report delivery date locked) by Month 1.5 (2026-11-23)
- Define design-readiness criteria and in-house rig validation pass/fail rules by Month 1 (2026-11-08)

**Membership:**

- Founder (project lead, design decisions)
- Independent EMC consultancy (RF design and lab coordination, milestone-based)
- Estonian university lab partner (in-house rig and measurement support, co-development)
- Accredited EMC laboratory (external, test execution and report)
- Part-time RF engineer if university partnership fails (backup, 0.5 FTE from Month 1.5 = 2026-11-23 onward)

**Decision Rights:** Technical design decisions within scope (seam design, gasket materials, internal fit, frequency range claims, scope statement) up to EUR 5k per change. Lab selection and statement-of-work approval (all terms, cost, timeline). Any design change or redesign scope that impacts cost >EUR 1k or timeline >2 weeks escalates to Steering Committee. Claim-to-evidence alignment (marketing scope statement and frequency-band disclaimers) is binding; no claim is published without this group's sign-off.

**Decision Mechanism:** Consensus among founder, consultancy and lab (if lab is engaged). If consultancy and founder disagree on design feasibility or cost, the lab pre-engagement review (Month 4 = 2027-02-08) is the tiebreaker: if the lab confirms readiness, design proceeds; if lab raises concerns, founder and consultancy jointly assess rework scope or claim narrowing. Any decision to increase the redesign reserve or reallocate budget escalates to Steering Committee.

**Meeting Cadence:** Bi-weekly (60–90 minutes, Mondays 10:00 AM or by agreement). Monthly deep-dive reviews at Month 2, 4, and 5 (2026-12-08, 2027-02-08, 2027-03-08) for prototype, lab pre-test and report assessment. Ad-hoc emergency meetings if design issues emerge that threaten Month 5 (2027-03-08) report deadline.

**Typical Agenda Items:**

- Prototype design status and RF analysis progress (consultancy)
- In-house rig setup and validation results (two independent cycles) (university lab)
- Accredited lab pre-engagement status: standard selection, frequency range, cost and timeline (lab liaison)
- Design-readiness assessment: does design meet lab expectations? Any red flags? (Month 4–5 = 2027-02-08 to 2027-03-08)
- Lab report summary: attenuation data, frequency range tested, any design-revision recommendations, re-test cost/timeline if needed (Month 5 = 2027-03-08)
- Claim-to-evidence review: are all marketing claims and scope statements aligned with measured lab data?
- Redesign scope and cost impact if lab results require changes

**Escalation Path:** Any design change or redesign scope that impacts EUR 400k budget or tooling-gate timeline (Month 5–6 = 2027-03-08 to 2027-04-08) escalates to Steering Committee with full cost/timeline impact documentation. If lab recommends a costlier standard (MIL-STD-285 vs. IEEE 299.1 estimate) or design revision requiring re-test, escalate with two scenarios: (a) proceed with costlier path and fund from EUR 20k reserve (or 30k if redesign reserve is raised) or seek timeline extension, (b) narrow claims and avoid re-test. Steering Committee approves which path to take within 3 business days.
### 3. Compliance and Liability Committee

**Rationale for Inclusion:** A passive Faraday enclosure sold against rare, extreme threats (solar storm, electromagnetic pulse) creates claim-substantiation and consumer-protection exposure. The plan limits claims to measured attenuation and includes scope statements (protects stored spare devices only), but applicability of EU product-safety rules, EMC Directive, and consumer-law liability are not verified. This committee ensures (1) legal risk is identified and managed (legal opinion by Month 1 = 2026-11-08), (2) product claims align with measured evidence (monthly compliance audit), (3) product-liability insurance is in place and covers Faraday-specific risks, and (4) regulatory requirements are tracked and met.

**Responsibilities:**

- Commission and review a legal opinion on applicable EU product-safety rules (General Product Safety Directive, EMC Directive, consumer-protection rules) by Month 1 (2026-11-08) and document findings (EUR 2–5k estimate)
- Define the scope statement (protects stored spare devices against RF exposure; does not protect active equipment or prevent grid-scale events) and ensure it appears in all marketing, presale terms and product materials
- Lock product-liability insurance coverage (EUR 250–500k estimated limits) by Month 2.5 (2026-12-23), confirm Faraday-enclosure claims are insurable, and document coverage limits and exclusions
- Conduct monthly claim-substantiation audit: verify all marketing claims (attenuation values, frequency band, protective scope) are supported by accredited lab data or measured evidence and that frequency-range disclaimers are published
- If EU directive applicability requires CE marking or notified-body assessment, document the requirement and cost/timeline impact (EUR 10–30k estimate, 8–12 weeks estimate) by Month 2 (2026-12-08) and escalate to Steering Committee
- Maintain a compliance checklist (claim limiting, scope statement, insurance status, lab report publication, presale terms) and flag any drift in compliance at each monthly review
- Establish a claim-revision protocol: if a product fails or if new regulatory guidance is issued, assess whether claims or scope statement must be revised; escalate any required revision to Steering Committee and Design & Certification group

**Initial Setup Actions:**

- Identify legal counsel with expertise in EU product-safety and consumer-protection law (prefer local Estonian counsel or EU generalist) by Month 0.5 (2026-10-23)
- Commission legal opinion on General Product Safety Directive, EMC Directive applicability, and consumer-protection duties by Month 1 (2026-11-08); budget EUR 2–5k estimate
- Draft the scope statement ('Protects stored spare devices against RF exposure; does not protect active equipment or prevent grid-scale events') and publish in all presale terms and marketing materials by Month 1 (2026-11-08)
- Identify and engage product-liability insurers who will cover Faraday-enclosure or RF-shielding products; lock coverage terms (limits, exclusions, premium) by Month 2.5 (2026-12-23)
- Create a compliance checklist (claim limiting, scope statement, lab report, insurance status, presale terms, warranty limits) and assign a reviewer (founder or part-time operations person) to audit monthly
- Publish the accredited lab report executive summary (attenuation data, frequency band tested, scope of testing) publicly with every unit sold by Month 5 (2027-03-08) onward

**Membership:**

- Founder (compliance owner, decision-maker)
- External legal counsel (EU product law expertise, for opinion and advice)
- Product-liability insurer (coverage assessment and terms)
- Design & Certification group liaison (to align lab report and claims)

**Decision Rights:** Legal opinions on regulatory applicability are binding: if the EMC Directive applies or CE marking is required, the cost and timeline are escalated to Steering Committee as a mandatory gate decision. Scope statement and claim limitations are binding: no marketing material is published without Compliance Committee sign-off. Product-liability insurance terms (limits, exclusions) are approved and locked by Month 2.5 (2026-12-23). Monthly compliance audits are advisory: if drift is detected (e.g., a salesperson mentions protection during grid-scale events), the committee flags it and founder must correct it within 3 business days or escalate to Steering Committee.

**Decision Mechanism:** Consensus between founder and legal counsel on legal-opinion findings and implications. If legal counsel and founder disagree on regulatory requirement interpretation, a second legal opinion is obtained (cost borne by Year-1 budget) and Steering Committee is notified. Insurance terms are agreed between founder and insurer; if insurer requires claim narrowing or exclusions, Steering Committee approves the trade-off (narrower claims vs. lower premium). Compliance audits are reviewed by founder and flagged findings are corrected or escalated within 3 business days.

**Meeting Cadence:** Monthly (45–60 minutes, tied to Steering Committee calendar). Special reviews at Month 1 (2026-11-08) for legal-opinion receipt, Month 2.5 (2026-12-23) for insurance lock-in, and Month 5 (2027-03-08) for lab-report and claim-alignment review.

**Typical Agenda Items:**

- Legal opinion status and findings (Month 1 = 2026-11-08)
- Insurance quotes and coverage terms; lock-in decision (Month 2–3 = 2026-12-08 to 2027-01-08)
- Compliance checklist review: claim limiting, scope statement, warranty terms, presale SLA
- Monthly claim audit: sample presale marketing, website, email communications; verify scope statement and frequency-band disclaimers are present
- Lab report alignment with claims: does measured attenuation support all marketing claims? Any narrowing needed?
- Any regulatory guidance updates or customer complaints received; assess claim-revision risk
- Post-gate: customer returns, warranty claims, or RF-event exposure and lessons learned

**Escalation Path:** If legal counsel advises that the EMC Directive applies and CE marking is required, or if product-liability insurer declines coverage or imposes significant exclusions, escalate immediately to Steering Committee with full cost and timeline impact (EUR 10–30k estimate, 8–12 weeks estimate for CE work). If a customer complaint or product failure occurs, escalate to Steering Committee and Design & Certification group to assess claim-revision risk and reputational impact. If a regulatory agency contacts the company, escalate to legal counsel and Steering Committee immediately.
### 4. Presale and Revenue Validation Committee

**Rationale for Inclusion:** The cash-flow gate depends on delivered-unit revenue of EUR 25k quarterly (proposed threshold) by Month 12 (2027-10-08). Presale-deposit velocity, segment mix, conversion rate and delivery lead times directly determine whether this gate is met. The plan assumes parallel presale campaigns across preppers, infrastructure buyers and privacy/forensics segments, with data-driven pivots if prepper mix exceeds 70% (estimated) by Month 3 (2027-01-08). This committee owns presale validation: deposit tracking, segment analysis, demand-pivot triggers, and delivery promise management. It bridges presale commitment and delivered-unit revenue.

**Responsibilities:**

- Design and launch parallel presale campaigns targeting preppers (40–50% estimated deposit rate), infrastructure buyers (30–40% estimated rate) and privacy/forensics (35–45% estimated rate) by Month 1 (2026-11-08)
- Track net presale deposits (gross deposits minus refunds) weekly; maintain a separate earmarked account and ensure deposits are never used for operating spending
- Monitor deposit velocity, refund rate, average order value and segment mix; identify which segment is dominating deposits
- Assess demand-pivot triggers monthly: if prepper deposits exceed 70% of total by Month 3 (2027-01-08), reallocate EUR 10–15k marketing spend from prepper to infrastructure/privacy channels
- Establish fast-track pilot agreements with 1–2 infrastructure buyers by Month 3 (2027-01-08) (pilot units at cost plus 20% estimate, delivery Month 5 = 2027-03-08) to generate in-time reference and revenue
- Gate hard-tooling release: confirm net presale deposits ≥ EUR 80k (proposed threshold) and in-house rig validation complete by Month 5–6 (2027-03-08 to 2027-04-08)
- Manage presale delivery promises: set presale cutoff date at Month 8 (2027-06-08); all orders before cutoff must be delivered by Month 12 (2027-10-08) to count toward cash-flow gate
- Track delivered-unit revenue (invoiced and paid) separately from presale deposits; monthly cash-flow dashboard shows operational revenue vs. presale liability
- If presale conversion falls below 40% (estimated) by Month 3 (2027-01-08) or average order value falls below EUR 50 (estimated), escalate pivot or stop-rule recommendation to Steering Committee

**Initial Setup Actions:**

- Identify prepper forums, online communities and mailing lists; draft prepper-focused presale campaign messaging and landing page by Month 0.5 (2026-10-23)
- Identify critical-infrastructure and emergency-planning buyer contacts (government agencies, utilities, facility operators); draft infrastructure-focused messaging and pilot proposal template by Month 0.5 (2026-10-23)
- Identify digital-forensics, privacy-advocacy and corporate IT security communities; draft multi-use RF-isolation messaging by Month 0.5 (2026-10-23)
- Set up presale deposit account (earmarked, separate from operating cash) and document deposit ring-fencing policy and refund-approval workflow by Month 0.5 (2026-10-23)
- Launch all three presale campaigns by Month 1 (2026-11-08); track deposits, refunds and segment mix in a weekly dashboard
- Develop presale terms document and delivery SLA (build-to-order, 2–3 week lead time, 30-day refund window) by Month 1 (2026-11-08); publish in all presale materials
- Set the hard-tooling gate criteria in writing by Month 1 (2026-11-08): 'Hard tooling releases when net presale deposits ≥ EUR 80k AND accredited lab pre-test confirms design readiness AND in-house rig validation passes twice'

**Membership:**

- Founder (presale strategy and buyer relationship lead)
- Part-time operations person (presale platform and deposit tracking, added Month 1 = 2026-11-08 or earlier if volume warrants)
- External advisor liaison (to monitor segment mix and pivot triggers)

**Decision Rights:** Presale campaign messaging and buyer outreach are founder-approved; no campaign material is published without founder sign-off. Presale terms (deposit refund policy, delivery lead time, scope statements) are locked by Month 1 (2026-11-08) and binding. Hard-tooling gate decision (deposits ≥ EUR 80k confirmation) is approved by Steering Committee based on this group's weekly dashboard and Month 5–6 (2027-03-08 to 2027-04-08) gate-readiness assessment. Any decision to pivot marketing spend (e.g., shift EUR 10–15k from prepper to infrastructure channels) is approved by Steering Committee within 3 business days of the Month 3 (2027-01-08) trigger assessment. Presale delivery cutoff date (Month 8 = 2027-06-08) is fixed by Month 2 (2026-12-08).

**Decision Mechanism:** Consensus among founder and operations/advisor on weekly presale dashboard findings and weekly pivot recommendations. If founder and advisor disagree on whether the 70% prepper threshold has been crossed (Month 3 = 2027-01-08), the data (deposit count and value by segment) is reviewed together and a decision is made within 3 business days; if still unresolved, Steering Committee is asked to adjudicate. Hard-tooling gate confirmation (deposits ≥ EUR 80k) is documented in writing with founder and advisor sign-off by Month 5.5 (2027-03-23).

**Meeting Cadence:** Weekly (30–45 minutes, Mondays 9:00 AM or by agreement) for presale dashboard review. Monthly deep-dive reviews (60 minutes, tied to Steering Committee calendar) at Months 1, 3, 6, 9, 12 (2026-11-08, 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08). Emergency meeting if presale conversion rate drops to <30% (estimated) in any given week or refund rate spikes above 20% (estimated) in a month.

**Typical Agenda Items:**

- Weekly presale deposits and refunds: gross, net, and segment mix (prepper, infrastructure, privacy/forensics)
- Deposit velocity trend and extrapolation to the EUR 80k gate target by Month 6 (2027-04-08)
- Average order value and revenue impact by segment; margin contribution estimate
- Refund requests: reasons (fit, delivery time, changed mind, news cycle) and approval/denial decisions
- Marketing campaign performance by segment: cost per deposit, conversion rate, messaging resonance
- Segment pivot assessment (Month 3 = 2027-01-08): is prepper mix > 70%? Recommend reallocation?
- Infrastructure pilot status: agreements signed? Delivery date confirmed? Reference credibility?
- Presale delivery queue and lead-time forecast; identify any risk of missing the Month 8 (2027-06-08) cutoff or Month 12 (2027-10-08) gate measurement
- Cash-flow gate projection: based on current deposits and delivery pace, will EUR 25k quarterly threshold be met by Month 12 (2027-10-08)?

**Escalation Path:** If presale deposits fall below EUR 80k by Month 6 (2027-04-08), escalate to Steering Committee with a stop-rule recommendation: either extend presale to Month 8 (2027-06-08) and delay hard tooling, or pivot channel/messaging urgently, or (if still below EUR 80k at Month 8 = 2027-06-08) withhold hard tooling and prepare for wind-down or founder capital contribution. If presale conversion falls below 40% (estimated) by Month 3 (2027-01-08) or average order value falls below EUR 50 (estimated), escalate to Steering Committee with contingency options: reposition narrative, shift channels, or halt presale marketing. If refund rate exceeds 20% (estimated) by Month 6 (2027-04-08), escalate delivery or messaging issues to Steering Committee and Design & Certification group. If infrastructure pilots stall past Month 6 (2027-04-08), escalate to founder with recommendation to widen multi-use RF-isolation narrative (privacy, travel, corporate security) in marketing to accelerate higher-value segments.
### 5. Production and Supply Chain Committee

**Rationale for Inclusion:** The plan commits to hard tooling only after presale deposits reach EUR 80k (proposed threshold) and design is validated by accredited lab (Month 5–6 = 2027-03-08 to 2027-04-08). Once tooling is released, production execution is time-critical: first batch (800 units) must be delivered by Months 7–8 (2027-05-08 to 2027-06-08) to support fulfillment before the cash-flow gate measurement window (Months 9–12 = 2027-07-08 to 2027-10-08). This committee manages the Tallinn production model, supplier coordination, soft and hard tooling, inventory, quality control and freight logistics. It also owns supply-chain risk mitigation (secondary fabricator, gasket buffer stock) and cost management within the EUR 160k production-line budget.

**Responsibilities:**

- Identify and pre-qualify primary Tallinn precision-metal fabricator and secondary backup fabricator by Month 1 (2026-11-08); conduct trial laser-cut batches to confirm quality
- Lock primary fabricator pricing and capacity agreement (soft tooling, hard tooling, and production batches) with signed contract specifying price caps, delivery dates and capacity reservation by Month 1.5 (2026-11-23)
- Identify and qualify conductive-gasket material suppliers (primary and backup); hold 30-day buffer stock (EUR 5–10k estimate) before production release
- Manage hard-tooling release: confirm presale deposits ≥ EUR 80k and accredited lab pre-test OK by Month 5–6 (2027-03-08 to 2027-04-08); submit hard-tooling order and lock commitment by Month 6 (2027-04-08)
- Manage first production batch (800 units): schedule production runs to meet delivery dates (Months 7–8 = 2027-05-08 to 2027-06-08) for presale fulfillment
- Coordinate with presale fulfillment: ensure production batch 1 (800 units) is available for delivery to customers by Month 7 (2027-05-08) and follow-on batches (700 units) by Month 9 (2027-07-08)
- Manage outbound freight logistics: negotiate volume-discount rates with DHL, UPS or local carrier and lock pricing for Year-1 by Month 1.5 (2026-11-23); track landed cost (EUR 8–15 per unit estimate) and freight variance
- Monitor actual unit cost (EUR 70 estimate) vs. budget (EUR 105k for 1,500 units); flag cost inflation and adjust order sizes if margins compress
- Conduct monthly supplier and fabricator reviews: lead times, quality (defect rates), price stability. If primary fabricator raises prices >10% or signals capacity loss, trigger secondary-supplier transition immediately
- Quality control: inspect initial production batches for seam integrity, gasket contact, fit and shielding margin. Flag any quality issues that may impact lab claims or customer satisfaction

**Initial Setup Actions:**

- Identify and contact 2–3 Tallinn precision-metal fabricators by Month 0.5 (2026-10-23); request quotes for soft tooling (laser cut, bend) and hard tooling (progressive die or equivalent)
- Order trial laser-cut samples from primary and secondary fabricators by Month 0.5 (2026-10-23); assess fit, tolerance and finish by Month 1 (2026-11-08)
- Lock primary fabricator soft-tooling and hard-tooling pricing in signed agreement by Month 1.5 (2026-11-23), specifying price caps, delivery windows and capacity reservation
- Identify conductive-gasket suppliers (primary and backup, qualified for RF shielding) by Month 0.5 (2026-10-23); order samples and confirm material specs, lead times and pricing by Month 1 (2026-11-08)
- Pre-qualify secondary Tallinn fabricator with a signed backup agreement by Month 1.5 (2026-11-23) in case primary supplier fails
- Negotiate freight pricing with DHL, UPS and local carriers; lock volume rates by Month 1.5 (2026-11-23)
- Create a production schedule and quality-control checklist by Month 2 (2026-12-08) for soft-tooling trials, hard-tooling release and batch production

**Membership:**

- Founder (supplier relationships, production decisions, quality sign-off)
- Primary Tallinn fabricator (manufacturing partner)
- Secondary backup fabricator (contingency)
- Gasket material suppliers (primary and backup)
- Freight logistics partner (DHL, UPS, or local carrier)
- Part-time operations person (supply-chain tracking, quality inspections, inventory management, added Month 1 = 2026-11-08 or earlier)

**Decision Rights:** Hard-tooling release is approved by Steering Committee (gates on presale deposits and lab validation); once approved, production schedule is founder-approved and binding on fabricators (signed purchase order). Supplier pricing and terms (cost caps, delivery dates, capacity) are locked by Month 1.5 (2026-11-23); any price increase >10% (estimated) triggers a secondary-supplier assessment by this committee and a decision recommendation to Steering Committee. Quality-control decisions (accept/reject batches, investigate defects) are made by founder and operations person; any defect that impacts lab claims or customer fit escalates to Design & Certification group. Production-batch delays >2 weeks (estimated) that threaten presale delivery dates escalate to Steering Committee.

**Decision Mechanism:** Consensus among founder, primary fabricator and operations on production schedule and quality standards. If primary fabricator signals a price increase or capacity loss, founder and operations assess secondary-supplier readiness and recommend transition timing to Steering Committee within 3 business days. If a batch quality issue emerges, founder and operations investigate with the fabricator and decide on remediation (rework, scrap, or design change); major rework (>5% of batch) escalates to Design & Certification group and Steering Committee.

**Meeting Cadence:** Bi-weekly (45–60 minutes, Tuesdays 10:00 AM or by agreement) for supplier status, production progress and quality reviews. Monthly deep-dive reviews (90 minutes, tied to Steering Committee calendar) at Months 2, 4, 6, 8, 10, 12 (2026-12-08, 2027-02-08, 2027-04-08, 2027-06-08, 2027-08-08, 2027-10-08). Emergency meeting if a supplier fails to deliver on schedule or if quality defects emerge.

**Typical Agenda Items:**

- Primary fabricator status: soft-tooling progress, hard-tooling design review, production schedule (Month 4–6 = 2027-02-08 to 2027-04-08)
- Hard-tooling gate readiness (Month 5–6 = 2027-03-08 to 2027-04-08): presale deposits confirmed, lab pre-test OK? Ready to release tooling?
- Production batch schedule: Batch 1 (800 units) delivery date (Months 7–8 = 2027-05-08 to 2027-06-08), follow-on batches (Months 8–12 = 2027-06-08 to 2027-10-08)
- Actual unit cost vs. budget (EUR 70 estimate); any cost inflation identified?
- Gasket material supply: sufficient buffer stock in place? Lead time stable?
- Freight logistics: volume rates locked? Landed cost on track?
- Quality control: initial batch inspection, defect findings, corrective actions
- Secondary fabricator status: backup agreement in place? Capability confirmed?
- Supply-chain risk register: any supplier concentration, lead-time or capacity risks emerging?

**Escalation Path:** Any supplier price increase >10% (estimated) or capacity loss signals triggers an urgent secondary-supplier assessment and transition recommendation to Steering Committee within 3 business days. Production-batch delays >2 weeks (estimated) that threaten delivery dates (Months 7–8 = 2027-05-08 to 2027-06-08 for Batch 1) escalate to Steering Committee with contingency options (expedite fees, secondary fabricator, delivery timeline adjustment). Any quality defect affecting >5% of a batch or any defect impacting lab claims escalates to Design & Certification group and Steering Committee with impact assessment and remediation cost. If hard-tooling costs exceed EUR 30k (estimate, budgeted EUR 30k) by >20% (EUR 6k overrun), escalate to Steering Committee with a decision on whether to absorb overrun from redesign reserve or reallocate from other lines.
### 6. Financial Governance and Gate Measurement Committee

**Rationale for Inclusion:** The EUR 350k follow-on tranche is conditional on positive cash flow (EUR 25k quarterly operating surplus, proposed threshold, measured end of Year-1 Month 12 = 2027-10-08). This gate is non-negotiable; it protects the founder's personal capital and enforces evidence-gated spending discipline. This committee owns cash-flow accounting, monthly cash reconciliation, gate-measurement methodology, and the final sign-off decision at Month 12.5 (2027-10-23). It also monitors burn rate vs. budget, presale-deposit liability segregation, and any unbudgeted spending that threatens the EUR 400k cap or gate outcome.

**Responsibilities:**

- Maintain the written cash-flow gate measurement convention (definition: operating revenue from delivered units only, excluding presale deposits; threshold: EUR 25k quarterly surplus; measurement window: Months 9–12 = 2027-07-08 to 2027-10-08; tiebreak rule if ambiguous) agreed at Month 0.5 (2026-10-23)
- Track monthly actual spending vs. Year-1 budget allocation (EUR 400k across design, lab, tooling, production, marketing, reserves); report variance monthly and flag any category exceeding ±10%
- Segregate presale deposits as liabilities in a separate earmarked account; ensure zero operating withdrawals from deposit account and all refunds are documented
- Calculate and publish monthly cash-flow dashboard: Year-1 budget allocation vs. actuals, presale deposits (gross and refunds), operating revenue (delivered units invoiced and paid minus direct costs and recurring opex), and months of runway remaining
- Measure trailing-quarter operating cash flow (Months 9–12 = 2027-07-08 to 2027-10-08) using delivered-unit revenue only, subtract direct unit costs (EUR 82 per unit estimate: EUR 70 cost plus EUR 12 freight) and recurring opex (EUR 20k per quarter estimate), and calculate surplus
- At Month 12 (2027-10-08), document the gate result in writing: revenue, costs, opex, and calculated surplus (or deficit). If result is ambiguous (-EUR 5k to +EUR 25k estimate), apply the tiebreak rule (founder may extend 90 days and re-measure, or founder retains discretion)
- Obtain sign-off from founder and external advisor by Month 12.5 (2027-10-23) on gate result and tranche release recommendation
- If gate is met (surplus ≥ EUR 25k), recommend release of EUR 350k follow-on to founder. If gate is not met (surplus < EUR 25k), recommend withholding and document decision rationale

**Initial Setup Actions:**

- Draft and publish the written cash-flow gate measurement convention by Month 0.5 (2026-10-23), including: definition of operating cash flow (delivered-unit revenue only, no presale deposits), threshold (EUR 25k proposed quarterly surplus), measurement window (Months 9–12 = 2027-07-08 to 2027-10-08), and tiebreak rule (founder discretion if -EUR 5k to +EUR 25k estimate)
- Create the monthly Year-1 burn schedule (EUR 400k allocation: design/prototyping/EMC consultancy EUR 70k, in-house rig EUR 40k, accredited lab EUR 15k, soft tooling EUR 20k, production line EUR 160k, marketing/sales/operations EUR 75k, redesign reserve EUR 20k) by Month 0.5 (2026-10-23)
- Set up separate earmarked presale-deposit account (not commingled with operational cash); document ring-fencing policy and refund-approval workflow by Month 0.5 (2026-10-23)
- Create monthly cash-reconciliation template showing: budget allocation vs. actuals (by category), presale deposits (gross, refunds, net), delivered-unit revenue (units, price, gross), direct costs and opex, operating cash flow, and months of runway by Month 1 (2026-11-08)
- Recruit external financial advisor (accountant or experienced mentor) to review monthly reconciliation quarterly (Months 3, 6, 9, 12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08) and co-sign gate result at Month 12.5 (2027-10-23) by Month 0.5 (2026-10-23)
- Define unit cost and margin assumptions for gate calculation: EUR 70 per unit (estimate), EUR 12 freight (estimate), EUR 149 list price (estimate), contribution EUR 67 per unit (estimate), recurring opex EUR 20k per quarter (estimate) by Month 0.5 (2026-10-23)

**Membership:**

- Founder (cash-flow owner, tranche decision authority)
- External financial advisor (accountant or experienced mentor, independent, gate co-sign authority)
- Part-time operations/finance person (monthly cash reconciliation, invoice tracking, deposit accounting, added Month 1 = 2026-11-08 or earlier)

**Decision Rights:** The cash-flow gate measurement convention is locked by Month 0.5 (2026-10-23) and binding; it cannot be changed after launch. Monthly budget variance reporting (category overage >10%) is flagged and requires founder approval for any reallocation. Presale-deposit accounting (segregation, refund approvals, liability classification) is fixed and audited monthly. The gate result (EUR 25k threshold calculation) is determined mechanically on delivered-unit revenue by Month 12 (2027-10-08); if result is unambiguous (clearly ≥EUR 25k or clearly <EUR 25k), founder and advisor sign off within 3 business days. If result is ambiguous (-EUR 5k to +EUR 25k estimate), the tiebreak rule applies: founder retains discretion to extend runway 90 days and re-measure, or founder decides tranche release based on advisor guidance.

**Decision Mechanism:** Founder and external advisor jointly review monthly cash reconciliation; any variance >10% in a budget category is discussed and founder approves reallocation or spending freeze within 3 business days. Presale-deposit accounting is audited monthly by operations/finance person and reviewed by advisor quarterly; if drift is detected (e.g., operational spending from deposit account), it is flagged immediately and corrected. Gate result is calculated independently by operations/finance person and reviewed by both founder and advisor by Month 12 (2027-10-08); calculation is documented with supporting invoices and payment records from 10–15% sample of delivered units. If founder and advisor cannot agree on gate result interpretation (e.g., whether a pending invoice should be counted as 'paid'), the calculation is escalated to the external financial advisor for tiebreak within 3 business days of Month 12 (2027-10-08).

**Meeting Cadence:** Monthly (60 minutes, last week of month, within 7 days of month-end) for cash reconciliation review. Quarterly (90 minutes, tied to Steering Committee calendar) at Months 3, 6, 9, 12 (2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08) for deep-dive variance analysis and advisor sign-off on progress toward gate. Special gate-measurement meeting at Month 12.5 (2027-10-23) for final result sign-off and tranche decision.

**Typical Agenda Items:**

- Monthly budget allocation vs. actuals: design, lab, tooling, production, marketing spend and variance explanation
- Presale deposits: gross received, refunds approved and paid, net deposits held
- Delivered units: count, invoiced, paid (sample audit of 10–15% of receipts to confirm cash payment)
- Quarterly cash-flow calculation: delivered-unit revenue, less direct costs (EUR 82 per unit estimate), less recurring opex (EUR 20k per quarter estimate), equals operating surplus
- Months of runway: based on actual burn rate vs. budget, how many months of cash remains if spending continues at current pace?
- Any unbudgeted spending, overruns, or contingency draws (redesign reserve, contingency); impact on EUR 400k cap
- Presale deposit liability: verified in separate account? Zero operating withdrawals? Refund policy complied with?
- Gate projection: based on Year-1 performance, will the EUR 25k quarterly surplus threshold be met by Month 12 (2027-10-08)?
- At Month 12.5 (2027-10-23): gate result sign-off (delivered units, costs, opex, surplus calculation) and tranche release recommendation

**Escalation Path:** Any budget category exceeding plan by >10% (estimated) or any unplanned spending >EUR 5k is flagged and escalated to Steering Committee for approval of reallocation or spending freeze within 3 business days. If actual cash burn is running >10% above Year-1 budget by Month 6 (2027-04-08), a spending-freeze review is triggered and Steering Committee approves cuts or deferral of presale marketing or operations spend to stay within the EUR 400k cap. If presale deposits are misused (operational spending from deposit account detected), the issue is escalated immediately to founder for correction and Steering Committee is notified. If gate-measurement result falls below EUR 25k by Month 12 (2027-10-08), founder and advisor assess the root cause (insufficient delivered-unit volume, higher-than-expected refunds, cost inflation) and decide whether to pursue the 90-day extension (tiebreak rule) or accept tranche withheld. If EUR 400k Year-1 cap is exceeded by Month 11 (2027-09-08), an emergency spending freeze is implemented and Steering Committee is convened within 48 hours to authorize additional founder capital contribution or accept reduced headcount/activities.