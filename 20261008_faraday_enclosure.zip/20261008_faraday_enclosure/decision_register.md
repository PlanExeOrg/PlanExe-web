**4 open decisions: 2 high and 2 medium severity.** The deposit share and use rule is urgent and must be decided by Month 0.5 (2026-10-23), before any presale deposit. The gate-quarter volume source must be decided by Month 5 (2027-03-08), and the Year-1 opex split by Month 1 (2026-11-08). Before then, design, rig building and lab pre-engagement can proceed safely, but no deposits should be taken.

| # | Decision | Severity | Owner | Decide by | Blocks |
|---|---|---|---|---|---|
| 1 | Deposit share and deposit-use rule | 🔴 High | Founder with the external advisor (gate convention signatories) | Month 0.5 (2026-10-23), because the signed gate convention must exist before any deposit is taken. | Presale launch (Month 1 = 2026-11-08) and the written gate convention |
| 2 | Source of gate-quarter volume | 🔴 High | Project Steering Committee (founder with advisor) | Month 5 (2027-03-08), so a demand test can run before the Month 6 (2027-04-08) tooling decision. | Month 6 (2027-04-08) tooling release and the Month 12.5 (2027-10-23) gate |
| 3 | Year-1 opex within the 75k line | 🟡 Medium | Founder with the external advisor | Month 1 (2026-11-08), when the burn schedule is fixed and insurance terms are due (Month 2.5 = 2026-12-23). | Monthly burn schedule and insurance terms lock (Month 2.5 = 2026-12-23) |
| 4 | Allocation of the EUR 350k tranche | 🟡 Medium | Founder with the external advisor | Month 9 (2027-07-08), before the gate window opens, to allow procurement planning. | Release and use of the EUR 350k after the Month 12.5 (2027-10-23) sign-off |

## 1. Deposit share and deposit-use rule (🔴 High)

**Decision:** What share of the EUR 149 price is a presale deposit, and may ring-fenced deposits pay the unit cost of matching orders?

**Why it is open:** Canonical deposit_use_open_decision is OPEN. The pitch assumes full EUR 149 deposits and an 'EUR 120 effective' price. Reviews 9-11 and 14 say it is undecided. The accounting rule says deposits are never used for operating spending.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Partial deposit; deposits stay ring-fenced and do not pay unit cost. | Lowest refund exposure. The 160k production line stays fully program-financed within the 400k cap. Presale cash is smaller, but the EUR 80k net-deposit gate is still measured on deposits. | Gate convention; pitch (drop 'EUR 120 effective'); deposit_use_open_decision. |
| B. Full-price deposit; ring-fenced, not used for unit cost. | Strongest demand signal for the EUR 80k tooling gate. Refund liability is larger. The 400k cap and 0k headroom are unchanged. | Gate convention; deposit_accounting_rule; pitch wording. |
| C. Deposits may fund matching unit cost, by timing only. | Eases working capital against the 105k unit-cost portion. Raises refund and liability risk, and conflicts with the current accounting rule. The cap stays 400k. | deposit_accounting_rule; unit_financing_baseline; refund cap wording. |

- **If nobody decides:** Presale launch (Month 1 = 2026-11-08) is delayed; no deposits are taken under an undefined rule.
- **Owner:** Founder with the external advisor (gate convention signatories)
- **Decide by:** Month 0.5 (2026-10-23), because the signed gate convention must exist before any deposit is taken.
- **Blocks:** Presale launch (Month 1 = 2026-11-08) and the written gate convention

## 2. Source of gate-quarter volume (🔴 High)

**Decision:** Where will the roughly 750 units delivered and paid in Months 9-12 (2027-07-08 to 2027-10-08) come from, and do deposits convert to gate receipts at delivery?

**Why it is open:** Presale evidence (EUR 80-120k, about 540-805 units) lands before the Month 9-12 (2027-07-08 to 2027-10-08) window, and presales close at Month 8 (2027-06-08). No demand test exists for the post-cutoff orders. Pitch says 800 units by Month 8 (2027-06-08); canonical says 750 in Months 7-8 (2027-05-08 to 2027-06-08).

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Define post-cutoff ordinary orders, wholesale and pilots as the source, and add a demand test before Month 6 (2027-04-08). | Adds test effort inside the marketing line. Makes the 672-unit gate requirement testable. Batch 1 is aligned to 750 in Months 7-8 (2027-05-08 to 2027-06-08). | batch1_and_year1_volume; pitch metrics; Review 13 #3. |
| B. Count delivered presale units as gate receipts when delivered, and shift deliveries into Months 9-12 (2027-07-08 to 2027-10-08). | Uses presale demand for the gate. Delays fulfilment and raises refund and lead-time risk, since refunds close at Month 8.5 (2027-06-23). | cash_flow_gate_definition; presale_cutoff_and_lead_time; delivery schedule. |
| C. Keep the current text and treat the gate as a risk. | Gate pass is unsupported by evidence. A shortfall leads to the -5k to +25k extension or withholding the 350k. | None; a documented risk only. |

- **If nobody decides:** The 750 gate-quarter units remain without a demand source, and the gate is likely to be missed or extended 90 days.
- **Owner:** Project Steering Committee (founder with advisor)
- **Decide by:** Month 5 (2027-03-08), so a demand test can run before the Month 6 (2027-04-08) tooling decision.
- **Blocks:** Month 6 (2027-04-08) tooling release and the Month 12.5 (2027-10-23) gate

## 3. Year-1 opex within the 75k line (🟡 Medium)

**Decision:** Which recurring and one-off items count as Year-1 cost inside the 75k line, and which are cut or deferred to Year 2?

**Why it is open:** Recurring opex is 80k per year, more than the 75k line before the one-offs (legal, LCA, premium, part-time ops). The insurance premium is both estimated at 8k and 'not estimated'. Self-audit 12 suggests deferring the 12k re-verification.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Defer re-verification and part of marketing to Year 2; restate the 75k breakdown. | Keeps the 400k cap. Lowers Year-1 marketing and may reduce presale volume. | unbudgeted_items_absorbed; recurring_opex_eur; the single insurance estimate. |
| B. Hold the 75k and cut one-offs (LCA, part-time ops). | Reduces compliance and operations coverage. Cuts to this line also feed the reserve top-up. | unbudgeted_items_absorbed; staffing_model. |
| C. Fund the excess from the founder's other capital or the 20k reserve. | Reduces free contingency below 20k, or exceeds the 400k cap. | year1_budget_allocation_eur; redesign_reserve_eur. |

- **If nobody decides:** The 75k line is overrun and spending is cut ad hoc, which hits marketing and the 10k reserve top-up.
- **Owner:** Founder with the external advisor
- **Decide by:** Month 1 (2026-11-08), when the burn schedule is fixed and insurance terms are due (Month 2.5 = 2026-12-23).
- **Blocks:** Monthly burn schedule and insurance terms lock (Month 2.5 = 2026-12-23)

## 4. Allocation of the EUR 350k tranche (🟡 Medium)

**Decision:** How should the EUR 350k follow-on be allocated if the gate passes (inventory, marketing, R&D, buffer stock)?

**Why it is open:** tranche_use_open_decision is OPEN. Post-gate items (buffer stock 30-60k estimate, phone-only SKU) are outside the 400k cap and need the tranche or receipts.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Inventory and marketing first; buffer stock and SKU variant only on triggers. | Protects cash. Slower expansion of the buffer-stock trial. | tranche_use_open_decision; post_gate_items_outside_cap. |
| B. Include a buffer stock and a smaller SKU variant from Month 12.5 (2027-10-23). | Faster growth and more exposure if demand is weak. | tranche_use_open_decision; product_scope. |
| C. Defer allocation until the Month 12.5 (2027-10-23) sign-off. | Keeps flexibility. Planning for Months 9-12 (2027-07-08 to 2027-10-08) purchasing stays uncertain. | None until Month 12.5 (2027-10-23). |

- **If nobody decides:** The allocation is decided at gate sign-off (Month 12.5 = 2027-10-23). If the gate fails, the 350k is not released.
- **Owner:** Founder with the external advisor
- **Decide by:** Month 9 (2027-07-08), before the gate window opens, to allow procurement planning.
- **Blocks:** Release and use of the EUR 350k after the Month 12.5 (2027-10-23) sign-off

## Choices made on your behalf

Set when the scenario was selected, not by you. Confirm or change them.

| Lever | Chosen | Strongest alternative | Why it matters | Revisit by |
|---|---|---|---|---|
| Shielding proof standard | Build an in-house rig, then buy one accredited lab validation of the final design. | Test production-representative units at an accredited lab and publish full reports per unit (Pioneer's Gambit). | It sets the lab cost (EUR 15k) and the Month 5-6 (2027-03-08 to 2027-04-08) tooling gate. | Month 5 (2027-03-08) lab result |
| Threat narrative and claim scope | Position as multi-use RF isolation (privacy, travel, forensics), with disaster preparedness as one use case. | A narrow prepper solar-storm claim (Capital Shield). | It drives the segment mix, price and the cash-flow gate. | Month 3 (2027-01-08) demand check |
| Enclosure architecture | Rigid folded aluminium or steel enclosure with a continuous conductive-gasket seam. | Hybrid frame with replaceable seal cartridge. | It keeps tooling and re-qualification cost small. | Month 3 (2027-01-08) rig validation |
| Presale and demand validation | Refundable-deposit presale through prepper communities, with a minimum EUR 80k threshold before tooling. | Paid infrastructure pilots only, or retailer wholesale. | It gates the irreversible 30k tooling spend. | Month 6 (2027-04-08) tooling decision |
| Year-1 burn sequencing | Front-load design and soft tooling; defer hard tooling and the main run until pre-test results and presales exist. | Commit early to production tooling, or hold a larger reserve outside spending. | It controls sunk-cost risk against the 400k cap. | Month 6 (2027-04-08) tooling release |
